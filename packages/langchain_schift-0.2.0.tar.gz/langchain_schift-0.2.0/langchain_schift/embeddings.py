"""Schift embedding model integration for LangChain."""

from __future__ import annotations

import os
from typing import List, Optional

from langchain_core.embeddings import Embeddings


class SchiftEmbeddings(Embeddings):
    """LangChain Embeddings wrapper for Schift embed API.

    Usage::

        from langchain_schift import SchiftEmbeddings

        embeddings = SchiftEmbeddings(api_key="sch_xxx")
        vectors = embeddings.embed_documents(["hello", "world"])
        query_vec = embeddings.embed_query("hello")

    With a specific model and reduced dimensions::

        embeddings = SchiftEmbeddings(
            api_key="sch_xxx",
            model="openai/text-embedding-3-large",
            dimensions=256,
        )
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: str = "schift-embed-1",
        dimensions: Optional[int] = None,
        base_url: str = "https://api.schift.io/v1",
    ) -> None:
        """Initialize SchiftEmbeddings.

        Args:
            api_key: Schift API key. Falls back to SCHIFT_API_KEY env var.
            model: Embedding model ID (e.g. ``"openai/text-embedding-3-small"``).
                Defaults to ``"schift-embed-1"``.
            dimensions: Optional output dimensionality. If None, the model
                default is used.
            base_url: Schift API base URL.
        """
        try:
            from schift import Schift
        except ImportError as e:
            raise ImportError(
                "Could not import schift python package. "
                "Please install it with: pip install schift"
            ) from e

        resolved_key = api_key or os.environ.get("SCHIFT_API_KEY", "")
        if not resolved_key:
            raise ValueError(
                "API key required. Pass api_key= or set SCHIFT_API_KEY."
            )
        self._client = Schift(api_key=resolved_key, base_url=base_url)
        self._model = model
        self._dimensions = dimensions

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of documents.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of embedding vectors, one per input text.
        """
        if not texts:
            return []
        result = self._client.embed.batch(
            texts, model=self._model, dimensions=self._dimensions
        )
        # EmbedModule.batch returns numpy NDArray; convert to nested list.
        if hasattr(result, "tolist"):
            return result.tolist()
        return [list(row) for row in result]

    def embed_query(self, text: str) -> List[float]:
        """Embed a single query string.

        Args:
            text: Query text to embed.

        Returns:
            Embedding vector as a list of floats.
        """
        result = self._client.embed(
            text, model=self._model, dimensions=self._dimensions
        )
        # EmbedModule.__call__ returns numpy NDArray; convert to list.
        if hasattr(result, "tolist"):
            return result.tolist()
        return list(result)
