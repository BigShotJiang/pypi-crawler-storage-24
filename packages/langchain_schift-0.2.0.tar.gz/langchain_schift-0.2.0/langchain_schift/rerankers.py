"""Schift reranker integration for LangChain."""

from __future__ import annotations

import os
from typing import List, Optional, Sequence

from langchain_core.callbacks import Callbacks
from langchain_core.documents import Document
from langchain_core.documents.compressor import BaseDocumentCompressor


class SchiftReranker(BaseDocumentCompressor):
    """LangChain Document Compressor using Schift rerank API.

    Wraps the Schift ``/rerank`` endpoint as a LangChain
    ``BaseDocumentCompressor``, which means it can be used directly with
    ``ContextualCompressionRetriever``.

    Usage::

        from langchain_schift import SchiftReranker

        reranker = SchiftReranker(api_key="sch_xxx", top_k=5)
        reranked = reranker.compress_documents(docs, query="search query")

    With ContextualCompressionRetriever::

        from langchain.retrievers import ContextualCompressionRetriever

        retriever = ContextualCompressionRetriever(
            base_compressor=SchiftReranker(api_key="sch_xxx", top_k=5),
            base_retriever=base_retriever,
        )
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        top_k: int = 5,
        base_url: str = "https://api.schift.io/v1",
    ) -> None:
        """Initialize SchiftReranker.

        Args:
            api_key: Schift API key. Falls back to SCHIFT_API_KEY env var.
            model: Optional reranker model ID. If None, the server default is
                used.
            top_k: Maximum number of documents to return after reranking.
            base_url: Schift API base URL.
        """
        try:
            from schift import Schift
        except ImportError as e:
            raise ImportError(
                "Could not import schift python package. "
                "Please install it with: pip install schift"
            ) from e

        resolved_key = api_key or os.environ.get("SCHIFT_API_KEY", "")
        if not resolved_key:
            raise ValueError(
                "API key required. Pass api_key= or set SCHIFT_API_KEY."
            )
        self._client = Schift(api_key=resolved_key, base_url=base_url)
        self._model = model
        self._top_k = top_k

    def compress_documents(
        self,
        documents: Sequence[Document],
        query: str,
        callbacks: Optional[Callbacks] = None,
    ) -> Sequence[Document]:
        """Rerank documents by relevance to the query.

        Documents are scored by the Schift rerank API and returned in
        descending relevance order, truncated to ``top_k``.  Each returned
        document has ``relevance_score`` added to its metadata.

        Args:
            documents: Sequence of LangChain Documents to rerank.
            query: Query string used for relevance scoring.
            callbacks: Optional LangChain callbacks (unused, accepted for
                interface compatibility).

        Returns:
            Sequence of Documents sorted by descending relevance score,
            with ``relevance_score`` added to each document's metadata.
        """
        if not documents:
            return []

        doc_dicts = [
            {
                "id": doc.metadata.get("id", str(i)),
                "text": doc.page_content,
            }
            for i, doc in enumerate(documents)
        ]

        kwargs = {"top_k": self._top_k}
        if self._model is not None:
            kwargs["model"] = self._model

        response = self._client.rerank(
            query=query,
            documents=doc_dicts,
            **kwargs,
        )

        # The SDK returns the full API response dict:
        # {"results": [{"id": ..., "text": ..., "relevance_score": ...,
        #               "index": ...}, ...], "model": ...}
        raw_results = response.get("results", []) if isinstance(response, dict) else response

        reranked: List[Document] = []
        for result in raw_results:
            if isinstance(result, dict):
                idx = result.get("index", 0)
                relevance_score = float(result.get("relevance_score", 0.0))
            else:
                # Support pydantic model objects returned by future SDK versions.
                idx = getattr(result, "index", 0)
                relevance_score = float(getattr(result, "relevance_score", 0.0))

            if idx < len(documents):
                original = documents[idx]
                new_metadata = {**original.metadata, "relevance_score": relevance_score}
                reranked.append(
                    Document(page_content=original.page_content, metadata=new_metadata)
                )

        return reranked
