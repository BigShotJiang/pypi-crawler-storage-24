"""Sophos Central firewall groups."""
