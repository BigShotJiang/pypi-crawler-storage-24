"""Compound await expressions: f(await g(await h()))."""

import asyncio
from pathlib import Path

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "compound_await"


async def add_one(x: int) -> int:
    print(f"  [add_one] {x} → {x + 1}")
    return x + 1


async def double(x: int) -> int:
    print(f"  [double] {x} → {x * 2}")
    return x * 2


async def multiply(a: int, b: int) -> int:
    print(f"  [multiply] {a} * {b} → {a * b}")
    return a * b


@resumable
async def nested_workflow(x: int) -> int:
    result = await double(await add_one(x))
    return result


@resumable
async def multi_arg_workflow(x: int) -> int:
    result = await multiply(await add_one(x), await double(x))
    return result


async def main():
    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    print("=== Nested compound await: double(add_one(x)) ===")
    async with attempt(store, id="nested"):
        result = await nested_workflow(5)
    print(f"  Result: {result}  (add_one(5)=6, double(6)=12)\n")

    print("=== Multi-arg compound await: multiply(add_one(x), double(x)) ===")
    async with attempt(store, id="multi"):
        result = await multi_arg_workflow(5)
    print(f"  Result: {result}  (add_one(5)=6, double(5)=10, multiply(6,10)=60)\n")

    print("--- Generated source (nested) ---")
    print(nested_workflow.__generated_source__)
    print("\n--- Generated source (multi-arg) ---")
    print(multi_arg_workflow.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
