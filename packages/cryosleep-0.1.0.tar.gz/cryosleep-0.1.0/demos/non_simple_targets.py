"""Await assigned to non-simple targets: tuple unpack, subscript, attribute."""

import asyncio
from dataclasses import dataclass, field
from pathlib import Path

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "non_simple_targets"


async def fetch_pair(x: int) -> tuple[int, int]:
    print(f"  [fetch_pair] → ({x}, {x * 3})")
    return (x, x * 3)


async def compute_score(x: int) -> float:
    print(f"  [compute_score] → {x * 1.5}")
    return x * 1.5


@dataclass
class Profile:
    scores: list[float] = field(default_factory=lambda: [0.0, 0.0])
    label: str = ""


@resumable
async def tuple_unpack_workflow(x: int) -> tuple[int, int]:
    a, b = await fetch_pair(x)
    return (a, b)


@resumable
async def subscript_workflow(x: int) -> list[float]:
    results = [0.0, 0.0]
    results[0] = await compute_score(x)
    results[1] = await compute_score(x + 10)
    return results


@resumable
async def attribute_workflow(x: int) -> Profile:
    profile = Profile()
    profile.label = "active"
    profile.scores[0] = await compute_score(x)
    profile.scores[1] = await compute_score(x + 10)
    return profile


async def main():
    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    print("=== Tuple unpack: a, b = await fetch_pair(x) ===")
    async with attempt(store, id="tuple"):
        result = await tuple_unpack_workflow(5)
    print(f"  Result: {result}\n")

    print("=== Subscript: results[i] = await compute_score(x) ===")
    async with attempt(store, id="subscript"):
        result = await subscript_workflow(5)
    print(f"  Result: {result}\n")

    print("=== Attribute: profile.scores[i] = await compute_score(x) ===")
    async with attempt(store, id="attribute"):
        result = await attribute_workflow(5)
    print(f"  Result: {result}\n")

    print("--- Generated source (tuple unpack) ---")
    print(tuple_unpack_workflow.__generated_source__)
    print("\n--- Generated source (subscript) ---")
    print(subscript_workflow.__generated_source__)
    print("\n--- Generated source (attribute) ---")
    print(attribute_workflow.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
