"""For-loop with awaits inside the body."""

import asyncio
from pathlib import Path

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "loop"


async def process_item(item: int) -> int:
    print(f"  [process] item={item} → {item * 10}")
    return item * 10


async def summarize(results: list[int]) -> int:
    total = sum(results)
    print(f"  [summarize] {results} → total={total}")
    return total


@resumable
async def loop_workflow(items: list[int]) -> int:
    results: list[int] = []
    for item in items:
        r = await process_item(item)
        results.append(r)
    total = await summarize(results)
    return total


async def main():
    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    print("=== Loop workflow ===")
    async with attempt(store, id="loop"):
        result = await loop_workflow([1, 2, 3])
    print(f"  Result: {result}\n")

    print("--- Generated source ---")
    print(loop_workflow.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
