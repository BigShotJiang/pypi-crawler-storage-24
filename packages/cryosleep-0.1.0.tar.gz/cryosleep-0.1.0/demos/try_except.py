"""Try/except with awaits in both paths."""

import asyncio
from pathlib import Path

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "try_except"


async def risky_call(x: int) -> int:
    if x < 0:
        raise ValueError(f"negative value: {x}")
    return x * 2


async def safe_fallback(x: int) -> int:
    print(f"  [fallback] abs({x}) = {abs(x)}")
    return abs(x)


@resumable
async def try_workflow(x: int) -> int:
    try:
        a = await risky_call(x)
    except ValueError:
        a = await safe_fallback(x)
    return a


async def main():
    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    print("=== Try/except (no error) ===")
    async with attempt(store, id="ok"):
        result = await try_workflow(5)
    print(f"  Result: {result}\n")

    print("=== Try/except (with error) ===")
    async with attempt(store, id="err"):
        result = await try_workflow(-3)
    print(f"  Result: {result}\n")

    print("--- Generated source ---")
    print(try_workflow.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
