"""Try/except/finally with awaits in the finally block."""

import asyncio
from pathlib import Path
from typing import Any

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "try_finally"


async def risky_call(x: int) -> int:
    if x < 0:
        raise ValueError(f"negative value: {x}")
    return x * 2


async def safe_fallback(x: int) -> int:
    print(f"  [fallback] abs({x}) = {abs(x)}")
    return abs(x)


async def log_completion(label: str) -> str:
    msg = f"completed:{label}"
    print(f"  [cleanup] {msg}")
    return msg


@resumable
async def finally_workflow(x: int) -> dict[str, Any]:
    try:
        a = await risky_call(x)
    except ValueError:
        a = await safe_fallback(x)
    finally:
        cleanup = await log_completion("done")
    return {"value": a, "cleanup": cleanup}


async def main():
    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    print("=== Try/except/finally (no error) ===")
    async with attempt(store, id="ok"):
        result = await finally_workflow(5)
    print(f"  Result: {result}\n")

    print("=== Try/except/finally (with error) ===")
    async with attempt(store, id="err"):
        result = await finally_workflow(-3)
    print(f"  Result: {result}\n")

    print("--- Generated source ---")
    print(finally_workflow.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
