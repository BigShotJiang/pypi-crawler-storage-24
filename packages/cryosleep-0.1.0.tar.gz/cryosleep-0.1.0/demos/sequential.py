"""Sequential awaits with crash-and-resume."""

import asyncio
from pathlib import Path
from typing import Any

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "sequential"

_should_crash = False

User = dict[str, Any]


async def fetch_user(user_id: int) -> User:
    print(f"  [step 1] Fetching user {user_id}...")
    return {"id": user_id, "name": "Alice", "email": "alice@example.com"}


async def enrich_profile(user: User) -> User:
    if _should_crash:
        print(f"  [step 2] CRASH while enriching {user['name']}!")
        raise RuntimeError("database connection lost")
    print(f"  [step 2] Enriching profile for {user['name']}...")
    return {**user, "score": 42, "tier": "gold"}


async def send_welcome(profile: User) -> str:
    print(f"  [step 3] Sending welcome to {profile['email']}...")
    return f"Welcome email sent to {profile['email']}"


@resumable
async def onboard_user(user_id: int) -> str:
    user = await fetch_user(user_id)
    profile = await enrich_profile(user)
    result = await send_welcome(profile)
    return result


async def main():
    global _should_crash

    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    print("=== Fresh run ===")
    async with attempt(store, id="onboard-alice"):
        result = await onboard_user(1)
    print(f"  Result: {result}\n")

    # Crash mid-run, then resume
    print("=== Crash simulation ===")
    _should_crash = True
    try:
        async with attempt(store, id="crash"):
            await onboard_user(1)
    except RuntimeError as e:
        print(f"  Caught: {e}")

    cp = await store.get("crash")
    assert cp is not None
    print(f"  Checkpoint saved at block {cp.block!r}")
    print(f"  Locals: {cp.locals_snapshot}\n")

    _should_crash = False
    print("=== Resume after crash ===")
    async with attempt(store, id="crash"):
        result = await onboard_user(1)
    print(f"  Result: {result}\n")

    print("--- Generated source ---")
    print(onboard_user.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
