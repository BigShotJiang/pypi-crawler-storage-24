"""Async for loop with per-iteration checkpointing."""

import asyncio
from pathlib import Path

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "async_for"


class AsyncRange:
    """A picklable async iterator that yields 0..n-1."""

    def __init__(self, n: int) -> None:
        self.n = n
        self.i = 0

    def __aiter__(self) -> "AsyncRange":
        return self

    async def __anext__(self) -> int:
        if self.i >= self.n:
            raise StopAsyncIteration
        val = self.i
        self.i += 1
        return val


async def process_item(item: int) -> int:
    print(f"  [process] item={item} → {item * 10}")
    return item * 10


@resumable
async def async_for_workflow(n: int) -> list[int]:
    results: list[int] = []
    async for item in AsyncRange(n):
        r = await process_item(item)
        results.append(r)
    return results


async def main():
    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    print("=== Async for workflow ===")
    async with attempt(store, id="async-for"):
        result = await async_for_workflow(4)
    print(f"  Result: {result}\n")

    print("--- Generated source ---")
    print(async_for_workflow.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
