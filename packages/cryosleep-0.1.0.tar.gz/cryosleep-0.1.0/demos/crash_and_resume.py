"""Crash-and-resume with checkpoint inspection.

Run twice to see the full lifecycle:

    python demos/crash_and_resume.py crash
    python demos/crash_and_resume.py fixed
"""

import argparse
import asyncio
import traceback
from pathlib import Path
from typing import Any

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "crash_and_resume"

_should_crash = False

Order = dict[str, Any]


async def validate_order(order_id: str) -> Order:
    print(f"  [step 1] Validating order {order_id}...")
    return {"id": order_id, "item": "Widget", "qty": 3, "total": 29.97}


async def charge_payment(order: Order) -> Order:
    if _should_crash:
        print(f"  [step 2] CRASH charging payment for order {order['id']}!")
        raise RuntimeError("payment gateway timeout")
    print(f"  [step 2] Charging ${order['total']:.2f} for order {order['id']}...")
    return {**order, "paid": True, "txn": "txn-00817"}


async def ship_order(order: Order) -> str:
    print(f"  [step 3] Shipping {order['qty']}x {order['item']}...")
    return f"Order {order['id']} shipped (tracking: SHP-{order['id'].upper()})"


@resumable
async def process_order(order_id: str) -> str:
    order = await validate_order(order_id)
    order = await charge_payment(order)
    result = await ship_order(order)
    return result


async def main():
    global _should_crash

    parser = argparse.ArgumentParser(description="Crash-and-resume demo")
    parser.add_argument(
        "mode",
        choices=["crash", "fixed"],
        help="'crash' to simulate a failure, 'fixed' to resume from it",
    )
    args = parser.parse_args()

    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    if args.mode == "crash":
        # Clean up any leftover checkpoint so this is idempotent
        await store.delete("order-42")

        _should_crash = True
        print("=== Running workflow (will crash at step 2) ===")
        try:
            async with attempt(store, id="order-42"):
                await process_order("42")
        except RuntimeError as exc:
            print(f"  Caught: {exc}\n")
            print(traceback.format_exc())

        print("=== Inspecting checkpoint ===")
        cp = await store.get("order-42")
        assert cp is not None
        print(f"  Resume: block {cp.block!r}")
        print(f"  Locals: {cp.locals_snapshot}")
        print(f"  Args:   {cp.args}")
        print("\nCheckpoint is on disk — run 'fixed' to resume.\n")

    else:
        print("=== Resuming workflow (step 2 fixed) ===")
        _should_crash = False
        async with attempt(store, id="order-42"):
            result = await process_order("42")
        print(f"  Result: {result}\n")

        cp = await store.get("order-42")
        if cp is not None:
            print("  Checkpoint still on disk (unexpected)")
        else:
            print("  Checkpoint cleaned up after success.\n")

        print("--- Generated state machine ---")
        print(process_order.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
