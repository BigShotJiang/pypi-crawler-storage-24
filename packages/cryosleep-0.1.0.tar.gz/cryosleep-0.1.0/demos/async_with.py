"""Async context manager with checkpoint/resume support."""

import asyncio
from pathlib import Path

from key_value.aio.stores.disk import DiskStore

from cryosleep import CheckpointStore, attempt, resumable

STORE_DIR = Path(__file__).parent / "store" / "async_with"


class AsyncResource:
    """A picklable async context manager for demonstration."""

    def __init__(self, name: str) -> None:
        self.name = name

    async def __aenter__(self) -> str:
        print(f"  [enter] acquired {self.name}")
        return self.name

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> bool:
        print(f"  [exit] released {self.name} (exc={exc_type})")
        return False


async def use_resource(name: str) -> str:
    result = f"used:{name}"
    print(f"  [use] {result}")
    return result


@resumable
async def async_with_workflow(name: str) -> str:
    result = ""
    async with AsyncResource(name) as resource:
        result = await use_resource(resource)
    return result


async def main():
    store = CheckpointStore(DiskStore(directory=STORE_DIR))

    print("=== Async with workflow ===")
    async with attempt(store, id="awith"):
        result = await async_with_workflow("db-conn")
    print(f"  Result: {result}\n")

    print("--- Generated source ---")
    print(async_with_workflow.__generated_source__)


if __name__ == "__main__":
    asyncio.run(main())
