"""Tests for the async with construct: lifting, compilation, parity, resume, traceback."""

from __future__ import annotations

import traceback
from types import TracebackType
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- Stubs referenced in @resumable functions (AST-transformed) ---


def mgr() -> Any: ...


async def process(x: Any) -> Any: ...


# --- Async context manager helpers ---


class AsyncCM:
    """A picklable async context manager for testing."""

    def __init__(self, value: int) -> None:
        self.value = value
        self.entered = False
        self.exited = False
        self.exit_exc: BaseException | None = None

    async def __aenter__(self) -> int:
        self.entered = True
        return self.value

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> bool:
        self.exited = True
        self.exit_exc = exc_val
        return False


class SuppressingAsyncCM:
    """A picklable async context manager that suppresses exceptions."""

    def __init__(self, value: int) -> None:
        self.value = value

    async def __aenter__(self) -> int:
        return self.value

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> bool:
        return True


async def make_cm(value: int) -> AsyncCM:
    return AsyncCM(value)


async def make_suppressing_cm(value: int) -> SuppressingAsyncCM:
    return SuppressingAsyncCM(value)


# --- Async step helpers ---


async def double(x: int) -> int:
    return x * 2


async def risky(x: int) -> int:
    if x < 0:
        raise ValueError("negative")
    return x


async def multiply(a: int, b: int) -> int:
    return a * b


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def async_with_workflow(value: int) -> int:
    result = 0
    cm = await make_cm(value)
    async with cm as v:
        result = await double(v)
    return result


@resumable
async def async_with_exception_propagation(value: int) -> int:
    result = 0
    cm = await make_cm(value)
    async with cm as v:
        result = await risky(v)
    return result


@resumable
async def async_with_exception_suppression(value: int) -> int:
    result = 0
    cm = await make_suppressing_cm(value)
    async with cm as v:
        result = await risky(v)
    return result


@resumable
async def nested_async_with_workflow(a: int, b: int) -> int:
    result = 0
    cm_a = await make_cm(a)
    cm_b = await make_cm(b)
    async with cm_a as va:
        async with cm_b as vb:
            result = await multiply(va, vb)
    return result


@resumable
async def async_with_boom_workflow(value: int) -> int:
    result = 0
    cm = await make_cm(value)
    async with cm as v:
        result = await boom(v)
    return result  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_async_with_produces_aenter_aexit(self):
        result = lift("""
            async def f():
                async with mgr() as v:
                    pass
        """)
        assert "__aenter__" in result
        assert "__aexit__" in result

    def test_async_with_as_clause(self):
        result = lift("""
            async def f():
                async with mgr() as v:
                    use(v)
        """)
        assert "v = await" in result
        assert "__aenter__" in result

    def test_async_with_no_as_clause(self):
        result = lift("""
            async def f():
                async with mgr():
                    pass
        """)
        assert "__aenter__" in result
        assert "__aexit__" in result

    def test_async_with_counter_increments(self):
        result = lift("""
            async def f():
                async with a() as x:
                    pass
                async with b() as y:
                    pass
        """)
        assert "_cm_0" in result
        assert "_cm_1" in result

    def test_async_with_multiple_items(self):
        result = lift("""
            async def f():
                async with a() as x, b() as y:
                    pass
        """)
        assert "__aenter__" in result
        assert "_cm_0" in result
        assert "_cm_1" in result

    def test_async_with_exception_handling(self):
        result = lift("""
            async def f():
                async with mgr() as v:
                    pass
        """)
        assert "BaseException" in result
        assert "__aexit__" in result

    def test_async_with_body_preserved(self):
        result = lift("""
            async def f():
                async with mgr() as v:
                    result = await process(v)
        """)
        assert "await process(v)" in result

    def test_async_for_inside_async_with(self):
        result = lift("""
            async def f():
                async with mgr() as v:
                    async for item in v:
                        pass
        """)
        assert "__aenter__" in result
        assert "__anext__" in result

    def test_multi_item_async_with(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            async with mgr() as a, mgr() as b:  # noqa: F841  # pyright: ignore[reportGeneralTypeIssues,reportUnusedVariable]
                c = 1  # noqa: F841  # pyright: ignore[reportUnusedVariable]
                r = await process(x)  # pyright: ignore[reportUnknownArgumentType]
            return r  # pyright: ignore[reportPossiblyUnbound]

        assert "match _block" in workflow.__generated_source__


class TestCompilation:
    def test_async_with_compiles_through_pipeline(self):
        @resumable
        async def workflow() -> (
            int
        ):  # pragma: no cover  # pyright: ignore[reportReturnType]
            async with mgr() as v:  # pyright: ignore[reportGeneralTypeIssues]
                r = await process(v)  # pyright: ignore[reportUnknownArgumentType]
            return r

        assert hasattr(workflow, "_transformed")
        assert "match _block" in workflow.__generated_source__

    def test_async_with_generates_valid_python(self):
        @resumable
        async def workflow() -> (
            int
        ):  # pragma: no cover  # pyright: ignore[reportReturnType]
            async with mgr() as v:  # pyright: ignore[reportGeneralTypeIssues]
                r = await process(v)  # pyright: ignore[reportUnknownArgumentType]
            return r

        compile(workflow.__generated_source__, "<test>", "exec")


class TestParity:
    async def test_basic_execution(self, assert_parity: AssertParity):
        result = await assert_parity(async_with_workflow, 5)
        assert result == 10

    async def test_exception_propagation_success(self, assert_parity: AssertParity):
        result = await assert_parity(async_with_exception_propagation, 5)
        assert result == 5

    async def test_exception_propagation_raises(self):
        from cryosleep.attempt import attempt
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        with pytest.raises(ValueError, match="negative"):
            await async_with_exception_propagation(-3)
        store = CheckpointStore(MemoryStore())
        with pytest.raises(ValueError, match="negative"):
            async with attempt(store, id="r1"):
                await async_with_exception_propagation(-3)

    async def test_exception_suppression(self, assert_parity: AssertParity):
        result = await assert_parity(async_with_exception_suppression, -3)
        assert result == 0

    async def test_nested_async_with(self, assert_parity: AssertParity):
        result = await assert_parity(nested_async_with_workflow, 3, 4)
        assert result == 12


class TestResume:
    async def test_resume_mid_async_with(self):
        from cryosleep.attempt import attempt
        from cryosleep.storage import Checkpoint
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        store = CheckpointStore(MemoryStore())
        saved: list[Checkpoint] = []
        original_put = store.put

        async def capture(key: str, value: Checkpoint) -> None:
            saved.append(value)
            await original_put(key, value)

        store.put = capture  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await async_with_workflow(5)

        last_cp = saved[-1]
        await store.put("r2", last_cp)
        async with attempt(store, id="r2"):
            result = await async_with_workflow(5)
        assert result == 10


class TestTraceback:
    async def test_traceback_points_to_async_with_body(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(async_with_boom_workflow, value=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "async_with_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
