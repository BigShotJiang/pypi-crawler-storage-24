from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from key_value.aio.stores.memory import MemoryStore

from cryosleep.attempt import attempt
from cryosleep.storage import Checkpoint, StaleCheckpointError
from cryosleep.storage import CheckpointStore
from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity


async def fake_step1(x: int) -> int:
    return x + 1


async def fake_step2(x: int) -> int:
    return x * 2


async def fake_step3(x: int) -> int:
    return x + 100


@resumable
async def three_step_workflow(x: int) -> int:
    a = await fake_step1(x)
    b = await fake_step2(a)
    c = await fake_step3(b)
    return c


class TestFreshRun:
    async def test_produces_correct_result(self, assert_parity: AssertParity):
        result = await assert_parity(three_step_workflow, 10)
        # step1: 10+1=11, step2: 11*2=22, step3: 22+100=122
        assert result == 122

    async def test_cleans_up_checkpoint_on_completion(self):
        store = CheckpointStore(MemoryStore())
        async with attempt(store, id="r1"):
            await three_step_workflow(10)
        assert await store.get("r1") is None

    async def test_checkpoints_after_each_step(self):
        store = CheckpointStore(MemoryStore())
        saved_blocks: list[str] = []
        original_put = store.put

        async def tracking_put(key: str, value: Checkpoint) -> None:
            saved_blocks.append(value.block)
            await original_put(key, value)

        store.put = tracking_put  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await three_step_workflow(10)
        assert len(saved_blocks) == 3


class TestResume:
    async def test_resumes_from_midpoint(self):
        store = CheckpointStore(MemoryStore())

        saved: list[Checkpoint] = []
        original_put = store.put

        async def capture_put(key: str, value: Checkpoint) -> None:
            saved.append(value)
            await original_put(key, value)

        store.put = capture_put  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await three_step_workflow(10)

        first_cp = saved[0]
        await store.put("r2", first_cp)

        async with attempt(store, id="r2"):
            result = await three_step_workflow(10)
        assert result == 122

    async def test_resumes_from_last_step(self):
        store = CheckpointStore(MemoryStore())

        saved: list[Checkpoint] = []
        original_put = store.put

        async def capture_put(key: str, value: Checkpoint) -> None:
            saved.append(value)
            await original_put(key, value)

        store.put = capture_put  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await three_step_workflow(10)

        last_cp = saved[-1]
        await store.put("r2", last_cp)

        async with attempt(store, id="r2"):
            result = await three_step_workflow(10)
        assert result == 122

    async def test_stale_version_raises(self):
        store = CheckpointStore(MemoryStore())
        cp = Checkpoint(
            function_ref="test:workflow",
            block="entry_0",
            args={"x": 10},
            locals_snapshot={"a": 11, "x": 10},
            version="wrong-version",
        )
        await store.put("r1", cp)

        with pytest.raises(StaleCheckpointError):
            async with attempt(store, id="r1"):
                await three_step_workflow(10)


_crash_step2_call_count = 0


async def _crashing_step2(x: int) -> int:
    global _crash_step2_call_count
    _crash_step2_call_count += 1
    if _crash_step2_call_count == 1:
        raise RuntimeError("simulated crash")
    return x * 2


@resumable
async def _crash_workflow(x: int) -> int:  # pragma: no cover
    a = await fake_step1(x)
    b = await _crashing_step2(a)
    c = await fake_step3(b)
    return c


class TestCrashAndResume:
    async def test_crash_mid_run_then_resume(self):
        global _crash_step2_call_count
        _crash_step2_call_count = 0

        store = CheckpointStore(MemoryStore())

        with pytest.raises(RuntimeError, match="simulated crash"):
            async with attempt(store, id="r1"):
                await _crash_workflow(5)

        cp = await store.get("r1")
        assert cp is not None

        async with attempt(store, id="r1"):
            result = await _crash_workflow(5)
        # step1: 5+1=6, step2: 6*2=12, step3: 12+100=112
        assert result == 112


@resumable
async def _inner_workflow(x: int) -> int:
    return await fake_step1(x)


@resumable
async def _outer_workflow(x: int) -> int:
    return await _inner_workflow(x)


class TestDirectCall:
    async def test_no_attempt_calls_original(self):
        result = await three_step_workflow(10)
        assert result == 122

    async def test_nested_produces_correct_result(self):
        store = CheckpointStore(MemoryStore())
        async with attempt(store, id="nested"):
            result = await _outer_workflow(10)
        assert result == 11


@resumable
async def _inner_step(x: int) -> int:
    a = await fake_step1(x)
    b = await fake_step2(a)
    return b


@resumable
async def _outer_with_inner(x: int) -> int:  # pragma: no cover
    mid = await _inner_step(x)
    result = await fake_step3(mid)
    return result


_inner_crash_count = 0


async def _crashing_inner_step(x: int) -> int:
    global _inner_crash_count
    _inner_crash_count += 1
    if _inner_crash_count == 1:
        raise RuntimeError("inner crash")
    return x * 2


@resumable
async def _inner_crashable(x: int) -> int:  # pragma: no cover
    a = await fake_step1(x)
    b = await _crashing_inner_step(a)
    return b


@resumable
async def _outer_with_crashable(x: int) -> int:  # pragma: no cover
    mid = await _inner_crashable(x)
    result = await fake_step3(mid)
    return result


@resumable
async def _level_c(x: int) -> int:
    return await fake_step1(x)


@resumable
async def _level_b(x: int) -> int:  # pragma: no cover
    return await _level_c(x)


@resumable
async def _level_a(x: int) -> int:  # pragma: no cover
    return await _level_b(x)


@resumable
async def _outer_loop(items: list[int]) -> list[int]:  # pragma: no cover
    results: list[int] = []
    for item in items:
        val = await _inner_step(item)
        results.append(val)
    return results


class TestNestedResumable:
    async def test_nested_creates_child_checkpoint(self):
        store = CheckpointStore(MemoryStore())
        saved_keys: list[str] = []
        original_put = store.put

        async def tracking_put(key: str, value: Checkpoint) -> None:
            saved_keys.append(key)
            await original_put(key, value)

        store.put = tracking_put  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await _outer_with_inner(10)

        child_keys = [k for k in saved_keys if "/" in k]
        assert len(child_keys) > 0
        assert all(k.startswith("r1/") for k in child_keys)

    async def test_nested_cleans_up_on_completion(self):
        store = CheckpointStore(MemoryStore())
        saved_keys: list[str] = []
        original_put = store.put

        async def tracking_put(key: str, value: Checkpoint) -> None:
            saved_keys.append(key)
            await original_put(key, value)

        store.put = tracking_put  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await _outer_with_inner(10)

        for key in saved_keys:
            assert await store.get(key) is None

    async def test_nested_crash_and_resume(self):
        global _inner_crash_count
        _inner_crash_count = 0

        store = CheckpointStore(MemoryStore())

        with pytest.raises(RuntimeError, match="inner crash"):
            async with attempt(store, id="r1"):
                await _outer_with_crashable(5)

        # The inner's partial progress is preserved as a child checkpoint
        child_keys = [k for k in await _all_keys(store) if k.startswith("r1/")]
        assert len(child_keys) > 0

        # On resume the outer reruns from scratch, but inner resumes from
        # its checkpoint — fake_step1 doesn't re-execute
        async with attempt(store, id="r1"):
            result = await _outer_with_crashable(5)
        # step1: 5+1=6, step2: 6*2=12, step3: 12+100=112
        assert result == 112

    async def test_deeply_nested(self):
        store = CheckpointStore(MemoryStore())
        saved_keys: list[str] = []
        original_put = store.put

        async def tracking_put(key: str, value: Checkpoint) -> None:
            saved_keys.append(key)
            await original_put(key, value)

        store.put = tracking_put  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            result = await _level_a(10)

        assert result == 11
        depth_counts = [k.count("/") for k in saved_keys]
        assert max(depth_counts) >= 2

    async def test_nested_in_loop(self):
        store = CheckpointStore(MemoryStore())
        async with attempt(store, id="r1"):
            result = await _outer_loop([1, 2, 3])

        # inner_step: step1(x)+1 -> step2(x+1)*2
        # 1: step1=2, step2=4; 2: step1=3, step2=6; 3: step1=4, step2=8
        assert result == [4, 6, 8]
        assert await store.get("r1") is None

    async def test_parity_with_nesting(self, assert_parity: AssertParity):
        result = await assert_parity(_outer_with_inner, 10)
        # step1: 10+1=11, step2: 11*2=22, step3: 22+100=122
        assert result == 122


async def _all_keys(store: CheckpointStore) -> list[str]:
    """List all keys in the underlying store."""
    kv = store._kv  # pyright: ignore[reportPrivateUsage]
    return await kv.keys()  # type: ignore[union-attr]


class TestContextVarCleanup:
    async def test_cleaned_up_on_exception(self):
        from cryosleep.attempt import _current_attempt  # pyright: ignore[reportPrivateUsage]

        store = CheckpointStore(MemoryStore())
        with pytest.raises(RuntimeError, match="boom"):
            async with attempt(store, id="fail"):
                raise RuntimeError("boom")
        assert _current_attempt.get() is None
