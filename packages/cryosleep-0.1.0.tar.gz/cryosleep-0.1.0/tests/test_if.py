"""Tests for the if/elif/else construct: lifting, CFG, parity, resume, traceback."""

from __future__ import annotations

import ast
import traceback
from typing import TYPE_CHECKING

import pytest

from cryosleep.analysis import CFGBuilder
from cryosleep.codegen import generate_state_machine
from cryosleep.types import AwaitAndCheckpoint, ConditionalJump
from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift, parse_async_func


# --- Stubs for AST-only analysis ---


async def step1(x: int) -> int: ...
async def step2(x: int) -> int: ...


# --- CFG sample functions ---


async def await_in_conditional(x: int) -> int:  # pragma: no cover
    if x > 0:
        a = await step1(x)
    else:
        a = await step2(x)
    return a


# --- Async step helpers ---


async def add_one(x: int) -> int:
    return x + 1


async def double(x: int) -> int:
    return x * 2


async def negate(x: int) -> int:
    return -x


async def check(x: int) -> bool:
    return x > 0


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def conditional_workflow(x: int) -> int:
    if x > 0:
        a = await add_one(x)
    else:
        a = await negate(x)
    b = await double(a)
    return b


@resumable
async def loop_in_conditional(x: int, items: list[int]) -> list[int]:
    if x > 0:
        results: list[int] = []
        for item in items:
            r = await double(item)
            results.append(r)
    else:
        results = []
        for item in items:
            r = await negate(item)
            results.append(r)
    return results


@resumable
async def if_await_test(x: int) -> str:
    if await check(x):
        result = await double(x)
        return f"positive:{result}"
    return "non-positive"


@resumable
async def if_await_test_else(x: int) -> str:
    if await check(x):
        result = await double(x)
    else:
        result = await double(-x)
    return f"result:{result}"


@resumable
async def if_boom_workflow(x: int) -> int:
    if x > 0:
        a = await boom(x)
    else:
        a = await double(x)  # pragma: no cover
    return a  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_if_await_in_test(self):
        result = lift("""
            async def f():
                if await g():
                    pass
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result
        assert "if _await_tmp_" in result

    def test_if_await_in_test_with_body_awaits(self):
        result = lift("""
            async def f():
                if await should_proceed():
                    a = await do_work()
        """)
        assert "= await should_proceed()" in result
        assert "if _await_tmp_" in result
        assert "await do_work()" in result

    def test_lifts_inside_if_body(self):
        result = lift("""
            async def f():
                if True:
                    f(await g())
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result


class TestCFG:
    def test_conditional_produces_branch_blocks(self):
        node = parse_async_func(await_in_conditional)
        cfg = CFGBuilder().build(node)
        entry = cfg.blocks[cfg.entry]
        assert isinstance(entry.terminator, ConditionalJump)

    def test_conditional_both_branches_have_await(self):
        node = parse_async_func(await_in_conditional)
        cfg = CFGBuilder().build(node)
        entry = cfg.blocks[cfg.entry]
        assert isinstance(entry.terminator, ConditionalJump)
        true_block = cfg.blocks[entry.terminator.true_label]
        false_block = cfg.blocks[entry.terminator.false_label]
        assert isinstance(true_block.terminator, AwaitAndCheckpoint)
        assert isinstance(false_block.terminator, AwaitAndCheckpoint)

    def test_conditional_generates_valid_python(self):
        node = parse_async_func(await_in_conditional)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_block_with_no_terminator_stmts(self):
        async def fn(x: int) -> int:  # pragma: no cover
            if x > 0:
                a = await step1(x)
            else:
                a = await step1(0)
            return a

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")


class TestParity:
    async def test_true_branch(self, assert_parity: AssertParity):
        result = await assert_parity(conditional_workflow, 5)
        assert result == 12

    async def test_false_branch(self, assert_parity: AssertParity):
        result = await assert_parity(conditional_workflow, -3)
        assert result == 6

    async def test_loop_in_true_branch(self, assert_parity: AssertParity):
        result = await assert_parity(loop_in_conditional, 1, [10, 20])
        assert result == [20, 40]

    async def test_loop_in_false_branch(self, assert_parity: AssertParity):
        result = await assert_parity(loop_in_conditional, -1, [10, 20])
        assert result == [-10, -20]

    async def test_if_await_true_branch(self, assert_parity: AssertParity):
        result = await assert_parity(if_await_test, 5)
        assert result == "positive:10"

    async def test_if_await_false_branch(self, assert_parity: AssertParity):
        result = await assert_parity(if_await_test, -3)
        assert result == "non-positive"

    async def test_if_await_else_true(self, assert_parity: AssertParity):
        result = await assert_parity(if_await_test_else, 5)
        assert result == "result:10"

    async def test_if_await_else_false(self, assert_parity: AssertParity):
        result = await assert_parity(if_await_test_else, -3)
        assert result == "result:6"


class TestResume:
    async def test_resume_after_conditional(self):
        from cryosleep.attempt import attempt
        from cryosleep.storage import Checkpoint
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        store = CheckpointStore(MemoryStore())
        saved: list[Checkpoint] = []
        original_put = store.put

        async def capture(key: str, value: Checkpoint) -> None:
            saved.append(value)
            await original_put(key, value)

        store.put = capture  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await conditional_workflow(5)

        last_cp = saved[-1]
        await store.put("r2", last_cp)
        async with attempt(store, id="r2"):
            result = await conditional_workflow(5)
        assert result == 12


class TestGenerated:
    def test_conditional_source_readable(self):
        source = conditional_workflow.__generated_source__
        assert "match _block" in source
        assert "while True" in source


class TestTraceback:
    async def test_traceback_points_to_if_branch(self, run_transformed: RunTransformed):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(if_boom_workflow, x=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "if_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
        assert frame.line is not None
        assert "boom" in frame.line
