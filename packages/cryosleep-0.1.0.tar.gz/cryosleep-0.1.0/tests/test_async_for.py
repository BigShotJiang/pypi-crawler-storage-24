"""Tests for the async for construct: lifting, compilation, parity, resume, traceback."""

from __future__ import annotations

import traceback
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- Stubs referenced in @resumable functions (AST-transformed) ---


def aiter() -> Any: ...


async def process(x: Any) -> Any: ...


# --- Async iterator helpers ---


class AsyncRange:
    """A picklable async iterator that yields 0..n-1."""

    def __init__(self, n: int) -> None:
        self.n = n
        self.i = 0

    def __aiter__(self) -> AsyncRange:
        return self

    async def __anext__(self) -> int:
        if self.i >= self.n:
            raise StopAsyncIteration
        val = self.i
        self.i += 1
        return val


class AsyncEmpty:
    """A picklable async iterator that yields nothing."""

    def __aiter__(self) -> AsyncEmpty:
        return self

    async def __anext__(self) -> int:
        raise StopAsyncIteration


def async_range(n: int) -> AsyncRange:
    return AsyncRange(n)


def async_empty() -> AsyncEmpty:
    return AsyncEmpty()


# --- Async step helpers ---


async def double(x: int) -> int:
    return x * 2


async def identity(x: Any) -> Any:
    return x


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def async_for_workflow(n: int) -> list[int]:
    results: list[int] = []
    async for item in async_range(n):
        r = await double(item)
        results.append(r)
    return results


@resumable
async def async_for_empty_workflow(n: int) -> list[int]:
    results: list[int] = []
    async for item in async_empty():
        r = await double(item)  # pragma: no cover
        results.append(r)  # pragma: no cover
    return results


@resumable
async def async_for_break_workflow(n: int) -> list[int]:
    results: list[int] = []
    async for item in async_range(n):
        if item >= 3:
            break
        r = await double(item)
        results.append(r)
    return results


@resumable
async def async_for_continue_workflow(n: int) -> list[int]:
    results: list[int] = []
    async for item in async_range(n):
        if item % 2 == 0:
            continue
        r = await double(item)
        results.append(r)
    return results


@resumable
async def async_for_else_exhausted(n: int) -> str:
    results: list[int] = []
    async for item in async_range(n):
        r = await double(item)
        results.append(r)
    else:
        marker = await identity("completed")
    return marker


@resumable
async def async_for_else_with_break(n: int) -> str:
    marker = "no-else"
    async for item in async_range(n):
        if item >= 2:
            break
        _r = await double(item)
    else:
        marker = await identity("completed")
    return marker


@resumable
async def async_for_else_empty(n: int) -> str:
    async for item in async_range(n):
        _r = await double(item)  # pragma: no cover
    else:
        marker = await identity("completed")
    return marker


@resumable
async def async_for_boom_workflow(n: int) -> list[int]:
    results: list[int] = []
    async for item in async_range(n):
        r = await boom(item)
        results.append(r)  # pragma: no cover
    return results  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_async_for_produces_while_loop(self):
        result = lift("""
            async def f():
                async for item in expr:
                    pass
        """)
        assert "__aiter__" in result
        assert "__anext__" in result
        assert "while True" in result
        assert "StopAsyncIteration" in result

    def test_async_for_preserves_target(self):
        result = lift("""
            async def f():
                async for item in expr:
                    use(item)
        """)
        assert "item = await" in result
        assert "__anext__" in result

    def test_async_for_tuple_target(self):
        result = lift("""
            async def f():
                async for a, b in pairs:
                    pass
        """)
        assert "__anext__" in result
        assert "a, b" in result

    def test_async_for_counter_increments(self):
        result = lift("""
            async def f():
                async for x in a:
                    pass
                async for y in b:
                    pass
        """)
        assert "_aiter_0" in result
        assert "_aiter_1" in result

    def test_async_for_body_preserved(self):
        result = lift("""
            async def f():
                async for item in expr:
                    result = await process(item)
        """)
        assert "await process(item)" in result

    def test_async_with_inside_async_for(self):
        result = lift("""
            async def f():
                async for item in items:
                    async with mgr(item) as v:
                        pass
        """)
        assert "__anext__" in result
        assert "__aenter__" in result


class TestCompilation:
    def test_async_for_compiles_through_pipeline(self):
        @resumable
        async def workflow() -> (
            int
        ):  # pragma: no cover  # pyright: ignore[reportReturnType]
            async for item in aiter():  # pyright: ignore[reportGeneralTypeIssues]
                r = await process(item)  # pyright: ignore[reportUnknownArgumentType]
            return r  # pyright: ignore[reportPossiblyUnboundVariable]

        assert hasattr(workflow, "_transformed")
        assert "match _block" in workflow.__generated_source__

    def test_async_for_generates_valid_python(self):
        @resumable
        async def workflow() -> (
            int
        ):  # pragma: no cover  # pyright: ignore[reportReturnType]
            async for item in aiter():  # pyright: ignore[reportGeneralTypeIssues]
                r = await process(item)  # pyright: ignore[reportUnknownArgumentType]
            return r  # pyright: ignore[reportPossiblyUnboundVariable]

        compile(workflow.__generated_source__, "<test>", "exec")


class TestParity:
    async def test_basic_execution(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_workflow, 4)
        assert result == [0, 2, 4, 6]

    async def test_empty_iterable(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_empty_workflow, 0)
        assert result == []

    async def test_break_in_async_for(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_break_workflow, 10)
        assert result == [0, 2, 4]

    async def test_no_break_in_async_for(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_break_workflow, 2)
        assert result == [0, 2]

    async def test_continue_in_async_for(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_continue_workflow, 6)
        assert result == [2, 6, 10]

    async def test_else_runs_on_exhaustion(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_else_exhausted, 3)
        assert result == "completed"

    async def test_else_skipped_on_break(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_else_with_break, 5)
        assert result == "no-else"

    async def test_else_runs_when_no_break(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_else_with_break, 2)
        assert result == "completed"

    async def test_else_runs_on_empty_iterator(self, assert_parity: AssertParity):
        result = await assert_parity(async_for_else_empty, 0)
        assert result == "completed"


class TestResume:
    async def test_resume_mid_async_for(self):
        from cryosleep.attempt import attempt
        from cryosleep.storage import Checkpoint
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        store = CheckpointStore(MemoryStore())
        saved: list[Checkpoint] = []
        original_put = store.put

        async def capture(key: str, value: Checkpoint) -> None:
            saved.append(value)
            await original_put(key, value)

        store.put = capture  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await async_for_workflow(3)

        first_cp = saved[0]
        await store.put("r2", first_cp)
        async with attempt(store, id="r2"):
            result = await async_for_workflow(3)
        assert result == [0, 2, 4]


class TestTraceback:
    async def test_traceback_points_to_async_for_body(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(async_for_boom_workflow, n=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "async_for_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
        assert frame.line is not None
        assert "boom" in frame.line
