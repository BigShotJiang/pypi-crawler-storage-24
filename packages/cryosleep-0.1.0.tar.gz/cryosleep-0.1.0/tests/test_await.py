"""Tests for the basic await construct: lifting, CFG, parity, traceback."""

from __future__ import annotations

import ast
import traceback
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.analysis import CFGBuilder
from cryosleep.codegen import generate_state_machine
from cryosleep.types import AwaitAndCheckpoint, UnsupportedAwaitPattern
from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift, parse_async_func


# --- Stubs for AST-only analysis (never executed) ---


async def step1(x: int) -> int: ...
async def step2(x: int) -> int: ...
async def step3(x: int) -> int: ...


# --- Sample functions for CFG analysis ---


async def simple_three_steps(x: int) -> int:  # pragma: no cover
    a = await step1(x)
    b = await step2(a)
    c = await step3(b)
    return c


async def with_pre_stmts(x: int) -> int:  # pragma: no cover
    y = x + 1
    a = await step1(y)
    z = a * 2
    b = await step2(z)
    return b


# --- Async step helpers for parity tests ---


async def add_one(x: int) -> int:
    return x + 1


async def double(x: int) -> int:
    return x * 2


async def multiply(a: int, b: int) -> int:
    return a * b


async def identity(x: Any) -> Any:
    return x


async def pair(a: int) -> tuple[int, int]:
    return (a, a + 10)


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Compound await workflows ---


@resumable
async def compound_await_in_call(x: int) -> int:
    result = await double(await add_one(x))
    return result


@resumable
async def multiple_compound_awaits(x: int) -> int:
    result = await multiply(await add_one(x), await double(x))
    return result


@resumable
async def return_await_workflow(x: int) -> int:
    return await add_one(x)


@resumable
async def compound_await_in_loop(items: list[int]) -> list[int]:
    results: list[int] = []
    for item in items:
        r = await double(await add_one(item))
        results.append(r)
    return results


# --- Non-simple target workflows ---


@resumable
async def tuple_unpack_workflow(x: int) -> Any:
    a, b = await pair(x)
    result = await identity((a, b))
    return result


# --- Traceback workflows ---


@resumable
async def simple_workflow(x: int) -> int:
    a = await identity(x)
    b = await boom(a)
    return b  # pragma: no cover


@resumable
async def multi_step(x: int) -> int:
    a = await identity(x)
    b = await identity(a)
    c = await boom(b)
    return c  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_simple_await_unchanged(self):
        result = lift("""
            async def f():
                a = await g()
        """)
        assert "a = await g()" in result

    def test_standalone_await_unchanged(self):
        result = lift("""
            async def f():
                await g()
        """)
        assert "await g()" in result

    def test_call_with_awaited_arg(self):
        result = lift("""
            async def f():
                f(await g())
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result
        assert "f(_await_tmp_" in result

    def test_multiple_awaits_in_one_expr(self):
        result = lift("""
            async def f():
                f(await g(), await h())
        """)
        assert result.count("= await") == 2
        assert "f(_await_tmp_" in result

    def test_nested_await(self):
        result = lift("""
            async def f():
                f(await g(await h()))
        """)
        lines = [line.strip() for line in result.split("\n") if "await" in line]
        assert len(lines) >= 2
        assert lines[0].endswith("= await h()")

    def test_await_in_binop(self):
        result = lift("""
            async def f():
                z = x + await y()
        """)
        assert "_await_tmp_" in result
        assert "= await y()" in result
        assert "z = x + _await_tmp_" in result

    def test_await_in_return(self):
        result = lift("""
            async def f():
                return await g()
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result
        assert "return _await_tmp_" in result

    def test_await_in_augassign(self):
        result = lift("""
            async def f():
                x += await g()
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result
        assert "x += _await_tmp_" in result

    def test_await_in_fstring(self):
        result = lift("""
            async def f():
                s = f"{await g()}"
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result

    def test_await_in_list_literal(self):
        result = lift("""
            async def f():
                x = [1, await g()]
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result
        assert "[1, _await_tmp_" in result

    def test_tuple_unpack_await(self):
        result = lift("""
            async def f():
                a, b = await g()
        """)
        assert "_await_tmp_0 = await g()" in result
        assert "a, b = _await_tmp_0" in result

    def test_subscript_await(self):
        result = lift("""
            async def f():
                x[0] = await g()
        """)
        assert "_await_tmp_0 = await g()" in result
        assert "x[0] = _await_tmp_0" in result

    def test_attribute_await(self):
        result = lift("""
            async def f():
                obj.x = await g()
        """)
        assert "_await_tmp_0 = await g()" in result
        assert "obj.x = _await_tmp_0" in result

    def test_simple_name_await_unchanged(self):
        result = lift("""
            async def f():
                a = await g()
        """)
        assert "a = await g()" in result
        assert "_await_tmp_" not in result

    def test_rejects_await_in_generator_expression(self):
        with pytest.raises(UnsupportedAwaitPattern, match="generator expression"):
            lift("""
                async def f():
                    x = list(await g(i) for i in items)
            """)

    def test_annassign_simple_await(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            a: int = await step1(x)
            return a

        assert "match _block" in workflow.__generated_source__

    def test_return_compound_await(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            return await step1(await step1(x))

        source = workflow.__generated_source__
        assert "_await_tmp_" in source

    def test_annassign_compound_await(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            a: int = await step1(await step1(x))
            return a

        source = workflow.__generated_source__
        assert "_await_tmp_" in source

    def test_annassign_non_name_target_simple_await(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            a: int = await step1(await step1(x))
            return a

        source = workflow.__generated_source__
        assert "_await_tmp_" in source


class TestCFG:
    def test_three_steps_produces_blocks(self):
        node = parse_async_func(simple_three_steps)
        cfg = CFGBuilder().build(node)
        assert len(cfg.blocks) >= 4

    def test_three_steps_entry_is_await(self):
        node = parse_async_func(simple_three_steps)
        cfg = CFGBuilder().build(node)
        entry = cfg.blocks[cfg.entry]
        assert isinstance(entry.terminator, AwaitAndCheckpoint)
        assert entry.terminator.target == "a"

    def test_three_steps_args(self):
        node = parse_async_func(simple_three_steps)
        cfg = CFGBuilder().build(node)
        assert cfg.args == ["x"]

    def test_three_steps_all_vars(self):
        node = parse_async_func(simple_three_steps)
        cfg = CFGBuilder().build(node)
        assert {"x", "a", "b", "c"} <= cfg.all_vars

    def test_pre_stmts_in_block(self):
        node = parse_async_func(with_pre_stmts)
        cfg = CFGBuilder().build(node)
        entry = cfg.blocks[cfg.entry]
        assert len(entry.stmts) == 1

    def test_generates_valid_python(self):
        node = parse_async_func(simple_three_steps)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_has_match_dispatch(self):
        node = parse_async_func(simple_three_steps)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        assert "match _block" in source

    def test_has_checkpoint_calls(self):
        node = parse_async_func(simple_three_steps)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        assert "_checkpoint_fn" in source

    def test_has_locals_restore(self):
        node = parse_async_func(simple_three_steps)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        assert "_locals.get('a'" in source
        assert "_locals.get('b'" in source

    def test_annassign_await(self):
        async def fn(x: int) -> int:  # pragma: no cover
            a: int = await step1(x)
            return a

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        assert len(cfg.blocks) >= 2

    def test_non_name_target_in_assign_raises(self):
        source = (
            "async def fn(x):\n    obj.attr = await step1(x)\n    return obj.attr\n"
        )
        tree = ast.parse(source)
        node = tree.body[0]
        assert isinstance(node, ast.AsyncFunctionDef)
        with pytest.raises(UnsupportedAwaitPattern):
            CFGBuilder().build(node)

    def test_non_name_target_in_annassign_raises(self):
        source = "async def fn(x):\n    obj.attr: int = await step1(x)\n    return obj.attr\n"
        tree = ast.parse(source)
        node = tree.body[0]
        assert isinstance(node, ast.AsyncFunctionDef)
        with pytest.raises(UnsupportedAwaitPattern):
            CFGBuilder().build(node)

    def test_label_without_numeric_suffix(self):
        async def fn(x: int) -> int:  # pragma: no cover
            a = await step1(x)
            return a

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        cfg.blocks["custom_label"] = cfg.blocks[cfg.entry]
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")


class TestDecorator:
    def test_decorated_function_has_transformed(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            a = await step1(x)
            return a

        assert hasattr(workflow, "_transformed")

    def test_decorated_function_has_generated_source(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            a = await step1(x)
            return a

        assert hasattr(workflow, "__generated_source__")

    def test_decorated_function_has_source_version(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            a = await step1(x)
            return a

        assert hasattr(workflow, "_source_version")

    def test_rejects_non_async(self):
        with pytest.raises(TypeError, match="async"):

            @resumable  # pyright: ignore[reportArgumentType]
            def not_async(  # pyright: ignore[reportUnusedFunction]
                x: int,
            ) -> int:  # pragma: no cover
                return x


class TestParity:
    async def test_compound_await_in_call(self, assert_parity: AssertParity):
        result = await assert_parity(compound_await_in_call, 5)
        assert result == 12

    async def test_multiple_compound_awaits(self, assert_parity: AssertParity):
        result = await assert_parity(multiple_compound_awaits, 5)
        assert result == 60

    async def test_return_await(self, assert_parity: AssertParity):
        result = await assert_parity(return_await_workflow, 5)
        assert result == 6

    async def test_compound_await_in_loop(self, assert_parity: AssertParity):
        result = await assert_parity(compound_await_in_loop, [1, 2, 3])
        assert result == [4, 6, 8]

    def test_generated_source_shows_lifting(self):
        source = compound_await_in_call.__generated_source__
        assert "_await_tmp_" in source

    async def test_tuple_unpack_await(self, assert_parity: AssertParity):
        result = await assert_parity(tuple_unpack_workflow, 5)
        assert result == (5, 15)


class TestTraceback:
    async def test_traceback_shows_original_file(self, run_transformed: RunTransformed):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(simple_workflow, x=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "simple_workflow")
        assert frame is not None
        assert frame.filename == __file__

    async def test_traceback_shows_function_name(self, run_transformed: RunTransformed):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(simple_workflow, x=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "simple_workflow")
        assert frame is not None
        assert frame.name == "simple_workflow"

    async def test_traceback_points_to_failing_await(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(simple_workflow, x=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "simple_workflow")
        assert frame is not None
        assert frame.line is not None
        assert "boom" in frame.line

    async def test_traceback_points_to_correct_line_in_multi_step(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(multi_step, x=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "multi_step")
        assert frame is not None
        assert frame.line is not None
        assert "boom" in frame.line
