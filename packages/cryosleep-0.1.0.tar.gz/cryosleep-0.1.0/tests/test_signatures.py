"""Tests for function signature features in resumable functions."""

from __future__ import annotations

import traceback
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame


# --- Helpers ---


async def step(x: Any) -> Any:
    return x


async def boom(x: Any) -> Any:
    raise RuntimeError("kaboom")


# --- Workflows with varied signatures ---


@resumable
async def positional_only_workflow(host: str, port: int, /) -> str:
    h = await step(host)
    p = await step(port)
    return f"{h}:{p}"


@resumable
async def keyword_only_workflow(url: str, *, timeout: int = 30) -> str:
    u = await step(url)
    t = await step(timeout)
    return f"{u} (timeout={t})"


@resumable
async def default_values_workflow(base: int, multiplier: int = 3) -> int:
    b = await step(base)
    return b * multiplier


@resumable
async def varargs_workflow(*items: int) -> int:
    total = 0
    for item in items:
        total += await step(item)
    return total


@resumable
async def kwargs_workflow(**options: str) -> str:
    parts: list[str] = []
    for key in sorted(options):
        val = await step(options[key])
        parts.append(f"{key}={val}")
    return ", ".join(parts)


@resumable
async def mixed_signature_workflow(
    a: int, b: int, /, c: int = 0, *rest: int, flag: bool = False
) -> dict[str, Any]:
    va = await step(a)
    vb = await step(b)
    vc = await step(c)
    return {"a": va, "b": vb, "c": vc, "rest": rest, "flag": flag}


@resumable
async def positional_only_boom(x: int, /) -> int:
    result = await boom(x)
    return result  # pragma: no cover


# --- Tests ---


class TestPositionalOnly:
    async def test_positional_only(self, assert_parity: AssertParity):
        result = await assert_parity(positional_only_workflow, "localhost", 8080)
        assert result == "localhost:8080"


class TestKeywordOnly:
    async def test_keyword_only_with_default(self, assert_parity: AssertParity):
        result = await assert_parity(keyword_only_workflow, "https://example.com")
        assert result == "https://example.com (timeout=30)"

    async def test_keyword_only_explicit(self, assert_parity: AssertParity):
        result = await assert_parity(
            keyword_only_workflow, "https://example.com", timeout=5
        )
        assert result == "https://example.com (timeout=5)"


class TestDefaultValues:
    async def test_uses_default(self, assert_parity: AssertParity):
        result = await assert_parity(default_values_workflow, 10)
        assert result == 30

    async def test_overrides_default(self, assert_parity: AssertParity):
        result = await assert_parity(default_values_workflow, 10, 5)
        assert result == 50


class TestVarargs:
    async def test_varargs(self, assert_parity: AssertParity):
        result = await assert_parity(varargs_workflow, 1, 2, 3)
        assert result == 6

    async def test_varargs_empty(self, assert_parity: AssertParity):
        result = await assert_parity(varargs_workflow)
        assert result == 0


class TestKwargs:
    async def test_kwargs(self, assert_parity: AssertParity):
        result = await assert_parity(kwargs_workflow, x="hello", y="world")
        assert result == "x=hello, y=world"

    async def test_kwargs_empty(self, assert_parity: AssertParity):
        result = await assert_parity(kwargs_workflow)
        assert result == ""


class TestMixedSignature:
    async def test_mixed(self, assert_parity: AssertParity):
        result = await assert_parity(mixed_signature_workflow, 1, 2, 3, 4, 5, flag=True)
        assert result == {"a": 1, "b": 2, "c": 3, "rest": (4, 5), "flag": True}

    async def test_mixed_minimal(self, assert_parity: AssertParity):
        result = await assert_parity(mixed_signature_workflow, 1, 2)
        assert result == {"a": 1, "b": 2, "c": 0, "rest": (), "flag": False}


class TestTraceback:
    async def test_traceback_points_to_signature_function(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(positional_only_boom, x=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "positional_only_boom")
        assert frame is not None
        assert frame.filename == __file__
        assert frame.line is not None
        assert "boom" in frame.line
