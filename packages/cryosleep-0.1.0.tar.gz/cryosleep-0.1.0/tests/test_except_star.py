"""Tests for the except* construct: lifting, parity, resume, traceback."""

from __future__ import annotations

import traceback
from typing import TYPE_CHECKING

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- Step helpers ---


async def double(x: int) -> int:
    return x * 2


async def handle_value_error(eg: BaseExceptionGroup[ValueError]) -> str:
    return f"handled {len(eg.exceptions)} ValueError(s)"


async def handle_type_error(eg: BaseExceptionGroup[TypeError]) -> str:
    return f"handled {len(eg.exceptions)} TypeError(s)"


async def noop() -> None:
    pass


async def get_message() -> str:
    return "cleanup done"


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def single_handler_matches(x: int) -> str:
    try:
        raise ExceptionGroup("eg", [ValueError(x)])
    except* ValueError as eg:
        result = await handle_value_error(eg)
    return result


@resumable
async def single_handler_no_match(x: int) -> str:
    try:
        raise ExceptionGroup("eg", [TypeError(x)])
    except* ValueError as eg:
        result = await handle_value_error(eg)  # pragma: no cover
    return result  # pragma: no cover


@resumable
async def multiple_handlers(x: int) -> list[str]:
    results: list[str] = []
    try:
        raise ExceptionGroup("eg", [ValueError(x), TypeError(x)])
    except* ValueError as eg:
        results.append(await handle_value_error(eg))
    except* TypeError as eg:
        results.append(await handle_type_error(eg))
    return results


@resumable
async def bare_exception_matched(x: int) -> str:
    try:
        raise ValueError(x)
    except* ValueError as eg:
        result = await handle_value_error(eg)
    return result


@resumable
async def bare_exception_not_matched(x: int) -> str:
    try:
        raise TypeError(x)
    except* ValueError as eg:
        result = await handle_value_error(eg)  # pragma: no cover
    return result  # pragma: no cover


@resumable
async def handler_raises_new(x: int) -> str:
    try:
        raise ExceptionGroup("eg", [ValueError(x)])
    except* ValueError:
        raise RuntimeError("handler failed")
    return "unreachable"  # pragma: no cover


@resumable
async def handler_bare_reraise(x: int) -> str:
    try:
        raise ExceptionGroup("eg", [ValueError(x)])
    except* ValueError:
        raise
    return "unreachable"  # pragma: no cover


@resumable
async def except_star_with_else(x: int) -> str:
    try:
        await noop()
    except* ValueError as eg:  # pragma: no cover
        result = await handle_value_error(eg)
    else:
        result = await get_message()
    return result


@resumable
async def except_star_with_finally(x: int) -> list[str]:
    log: list[str] = []
    try:
        raise ExceptionGroup("eg", [ValueError(x)])
    except* ValueError as eg:
        log.append(await handle_value_error(eg))
    finally:
        log.append(await get_message())
    return log


@resumable
async def except_star_no_as_name(x: int) -> str:
    try:
        raise ExceptionGroup("eg", [ValueError(x)])
    except* ValueError:
        result = await get_message()
    return result


@resumable
async def except_star_await_in_body(x: int) -> int:
    try:
        raise ExceptionGroup("eg", [ValueError(x)])
    except* ValueError as eg:
        vals = list(eg.exceptions)
        result = await double(vals[0].args[0])
    return result


@resumable
async def except_star_partial_match(x: int) -> str:
    """Only ValueError matches; TypeError propagates."""
    try:
        raise ExceptionGroup("eg", [ValueError(x), TypeError(x)])
    except* ValueError as eg:
        result = await handle_value_error(eg)
    return result  # pragma: no cover


@resumable
async def except_star_boom_workflow(x: int) -> int:
    try:
        raise ExceptionGroup("eg", [ValueError(x)])
    except* ValueError:
        result = await boom(x)
    return result  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_except_star_with_await_desugared(self):
        result = lift("""
            async def f():
                try:
                    x = await g()
                except* ValueError as eg:
                    await handle(eg)
        """)
        assert "except*" not in result
        assert ".split(ValueError)" in result

    def test_except_star_without_await_desugared(self):
        result = lift("""
            async def f():
                try:
                    x = 1
                except* ValueError:
                    pass
        """)
        assert "except*" not in result
        assert ".split(ValueError)" in result


class TestSingleHandler:
    async def test_matches(self, assert_parity: AssertParity):
        result = await assert_parity(single_handler_matches, 42)
        assert result == "handled 1 ValueError(s)"

    async def test_no_match_propagates(self):
        from cryosleep.attempt import attempt
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        with pytest.raises(ExceptionGroup):
            await single_handler_no_match(42)
        store = CheckpointStore(MemoryStore())
        with pytest.raises(ExceptionGroup):
            async with attempt(store, id="r1"):
                await single_handler_no_match(42)


class TestMultipleHandlers:
    async def test_both_match(self, assert_parity: AssertParity):
        result = await assert_parity(multiple_handlers, 42)
        assert len(result) == 2
        assert result[0] == "handled 1 ValueError(s)"
        assert result[1] == "handled 1 TypeError(s)"


class TestBareException:
    async def test_bare_matched(self, assert_parity: AssertParity):
        result = await assert_parity(bare_exception_matched, 42)
        assert result == "handled 1 ValueError(s)"

    async def test_bare_not_matched_propagates(self):
        from cryosleep.attempt import attempt
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        with pytest.raises(TypeError):
            await bare_exception_not_matched(42)
        store = CheckpointStore(MemoryStore())
        with pytest.raises(TypeError):
            async with attempt(store, id="r1"):
                await bare_exception_not_matched(42)


class TestHandlerErrors:
    async def test_handler_raises_new(self):
        from cryosleep.attempt import attempt
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        with pytest.raises(RuntimeError, match="handler failed"):
            await handler_raises_new(42)
        store = CheckpointStore(MemoryStore())
        with pytest.raises(RuntimeError, match="handler failed"):
            async with attempt(store, id="r1"):
                await handler_raises_new(42)

    async def test_handler_bare_reraise(self):
        from cryosleep.attempt import attempt
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        with pytest.raises(ExceptionGroup):
            await handler_bare_reraise(42)
        store = CheckpointStore(MemoryStore())
        with pytest.raises(ExceptionGroup):
            async with attempt(store, id="r1"):
                await handler_bare_reraise(42)


class TestElseFinally:
    async def test_else_runs_when_no_exception(self, assert_parity: AssertParity):
        result = await assert_parity(except_star_with_else, 42)
        assert result == "cleanup done"

    async def test_finally_always_runs(self, assert_parity: AssertParity):
        result = await assert_parity(except_star_with_finally, 42)
        assert len(result) == 2
        assert result[0] == "handled 1 ValueError(s)"
        assert result[1] == "cleanup done"


class TestMisc:
    async def test_no_as_name(self, assert_parity: AssertParity):
        result = await assert_parity(except_star_no_as_name, 42)
        assert result == "cleanup done"

    async def test_await_in_handler_body(self, assert_parity: AssertParity):
        result = await assert_parity(except_star_await_in_body, 5)
        assert result == 10

    async def test_partial_match_propagates_unhandled(self):
        from cryosleep.attempt import attempt
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        with pytest.raises(ExceptionGroup) as exc_info:
            await except_star_partial_match(42)
        assert any(isinstance(e, TypeError) for e in exc_info.value.exceptions)
        store = CheckpointStore(MemoryStore())
        with pytest.raises(ExceptionGroup):
            async with attempt(store, id="r1"):
                await except_star_partial_match(42)


class TestResume:
    async def test_resume_mid_handler(self):
        from cryosleep.attempt import attempt
        from cryosleep.storage import Checkpoint
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        store = CheckpointStore(MemoryStore())
        saved: list[Checkpoint] = []
        original_put = store.put

        async def capture(key: str, value: Checkpoint) -> None:
            saved.append(value)
            await original_put(key, value)

        store.put = capture  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            result = await except_star_await_in_body(5)
        assert result == 10

        first_cp = saved[0]
        await store.put("r2", first_cp)
        async with attempt(store, id="r2"):
            result = await except_star_await_in_body(5)
        assert result == 10


class TestTraceback:
    async def test_traceback_points_to_except_star_handler(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(except_star_boom_workflow, x=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "except_star_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
