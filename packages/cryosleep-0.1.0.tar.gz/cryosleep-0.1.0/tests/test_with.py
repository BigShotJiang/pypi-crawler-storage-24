"""Tests for the sync with construct (with awaits in body): lifting, parity, traceback."""

from __future__ import annotations

import traceback
from types import TracebackType
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- Stubs for AST-only analysis ---


async def step1(x: int) -> int: ...


# --- Sync context manager helpers ---


class SyncCM:
    """A picklable sync context manager for testing."""

    def __init__(self, value: int) -> None:
        self.value = value
        self.entered = False
        self.exited = False
        self.exit_exc: BaseException | None = None

    def __enter__(self) -> int:
        self.entered = True
        return self.value

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> bool:
        self.exited = True
        self.exit_exc = exc_val
        return False


class SuppressingSyncCM:
    """A sync context manager that suppresses exceptions."""

    def __init__(self, value: int) -> None:
        self.value = value

    def __enter__(self) -> int:
        return self.value

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> bool:
        return True


# --- Async step helpers ---


async def double(x: int) -> int:
    return x * 2


async def risky(x: int) -> int:
    if x < 0:
        raise ValueError("negative")
    return x


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def sync_with_await_in_body(value: int) -> int:
    cm = SyncCM(value)
    with cm as v:
        result = await double(v)
    return result  # pyright: ignore[reportPossiblyUnboundVariable]


@resumable
async def sync_with_as_clause(value: int) -> dict[str, Any]:
    cm = SyncCM(value)
    with cm as v:
        r = await double(v)
    return {"result": r, "entered": cm.entered, "exited": cm.exited}  # pyright: ignore[reportPossiblyUnboundVariable]


@resumable
async def sync_with_multiple_items(a: int, b: int) -> int:
    cm_a = SyncCM(a)
    cm_b = SyncCM(b)
    with cm_a as va, cm_b as vb:
        result = await double(va + vb)
    return result  # pyright: ignore[reportPossiblyUnboundVariable]


@resumable
async def sync_with_exception_in_body(value: int) -> int:
    cm = SyncCM(value)
    result = 0
    try:
        with cm as v:
            result = await risky(v)
    except ValueError:
        result = -1
    return result


@resumable
async def sync_with_suppressing(value: int) -> int:
    cm = SuppressingSyncCM(value)
    result = 0
    with cm as v:
        result = await risky(v)
    return result


@resumable
async def sync_with_boom_workflow(value: int) -> int:
    cm = SyncCM(value)
    with cm as v:
        result = await boom(v)
    return result  # pragma: no cover  # pyright: ignore[reportPossiblyUnboundVariable]


# --- Tests ---


class TestLifting:
    def test_sync_with_containing_await_desugars(self):
        result = lift("""
            async def f():
                with mgr() as v:
                    x = await g()
        """)
        assert "__enter__" in result
        assert "__exit__" in result
        assert "_scm_" in result

    def test_sync_with_no_await_stays_unchanged(self):
        result = lift("""
            async def f():
                with mgr() as v:
                    x = 1
        """)
        assert "__enter__" not in result
        assert "with mgr() as v" in result

    def test_sync_with_multiple_items(self):
        result = lift("""
            async def f():
                with a() as x, b() as y:
                    z = await g()
        """)
        assert "_scm_0" in result
        assert "_scm_1" in result

    def test_sync_with_no_as_clause(self):
        result = lift("""
            async def f():
                with mgr():
                    x = await g()
        """)
        assert "__enter__" in result
        assert "__exit__" in result

    def test_with_body_lifting(self):
        @resumable
        async def workflow(x: int) -> int:  # pragma: no cover
            with open("/dev/null") as f:  # noqa: SIM115, F841  # pyright: ignore[reportUnusedVariable]
                a = await step1(x)
            return a

        assert "match _block" in workflow.__generated_source__


class TestParity:
    async def test_basic_execution(self, assert_parity: AssertParity):
        result = await assert_parity(sync_with_await_in_body, 5)
        assert result == 10

    async def test_as_clause(self, assert_parity: AssertParity):
        result = await assert_parity(sync_with_as_clause, 5)
        assert result == {"result": 10, "entered": True, "exited": True}

    async def test_multiple_items(self, assert_parity: AssertParity):
        result = await assert_parity(sync_with_multiple_items, 3, 4)
        assert result == 14

    async def test_exception_in_body(self, assert_parity: AssertParity):
        result = await assert_parity(sync_with_exception_in_body, -3)
        assert result == -1

    async def test_exception_in_body_success(self, assert_parity: AssertParity):
        result = await assert_parity(sync_with_exception_in_body, 5)
        assert result == 5

    async def test_suppressing_cm(self, assert_parity: AssertParity):
        result = await assert_parity(sync_with_suppressing, -3)
        assert result == 0

    async def test_suppressing_cm_success(self, assert_parity: AssertParity):
        result = await assert_parity(sync_with_suppressing, 5)
        assert result == 5


class TestTraceback:
    async def test_traceback_points_to_with_body(self, run_transformed: RunTransformed):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(sync_with_boom_workflow, value=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "sync_with_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
