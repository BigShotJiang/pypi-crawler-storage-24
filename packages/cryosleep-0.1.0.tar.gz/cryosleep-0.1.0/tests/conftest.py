from collections.abc import Coroutine
from typing import Any, Protocol

import pytest

from key_value.aio.stores.memory import MemoryStore

from cryosleep.attempt import attempt
from cryosleep.storage import CheckpointStore
from cryosleep.transform import ResumableFunction


class AssertParity(Protocol):
    def __call__(
        self, fn: ResumableFunction, *args: Any, **kwargs: Any
    ) -> Coroutine[Any, Any, Any]: ...


@pytest.fixture
def assert_parity() -> AssertParity:
    """Assert a @resumable function produces the same result via direct call and attempt."""

    async def _assert(fn: ResumableFunction, *args: Any, **kwargs: Any) -> Any:
        direct = await fn(*args, **kwargs)
        store = CheckpointStore(MemoryStore())
        async with attempt(store, id="parity"):
            via_attempt = await fn(*args, **kwargs)
        assert direct == via_attempt, f"direct={direct!r}, attempt={via_attempt!r}"
        return direct

    return _assert  # type: ignore[return-value]


class RunTransformed(Protocol):
    def __call__(
        self, fn: ResumableFunction, **kwargs: Any
    ) -> Coroutine[Any, Any, Any]: ...


@pytest.fixture
def run_transformed() -> RunTransformed:
    """Call a transformed function directly with a no-op checkpoint."""

    async def _run(fn: ResumableFunction, **kwargs: Any) -> Any:
        async def noop(**_kw: Any) -> None:
            pass

        def noop_scope(_label: str) -> None:
            pass

        return await fn._transformed(  # pyright: ignore[reportPrivateUsage]
            _checkpoint_fn=noop, _set_call_scope=noop_scope, **kwargs
        )

    return _run  # type: ignore[return-value]
