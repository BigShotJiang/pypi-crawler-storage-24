"""Tests for comprehension desugaring: lifting, parity, traceback."""

from __future__ import annotations

import traceback
from typing import TYPE_CHECKING

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- AST-level tests ---


class TestListCompLifting:
    def test_await_in_element(self):
        result = lift("""
            async def f():
                x = [await g(i) for i in items]
        """)
        assert "_comp_tmp_0 = []" in result
        assert "for i in items:" in result
        assert "await g(i)" in result
        assert "_comp_tmp_0.append(" in result
        assert "x = _comp_tmp_0" in result

    def test_await_in_iterable(self):
        result = lift("""
            async def f():
                x = [i for i in await fetch()]
        """)
        assert "_comp_tmp_" in result
        assert "await fetch()" in result

    def test_await_in_filter(self):
        result = lift("""
            async def f():
                x = [i for i in items if await pred(i)]
        """)
        assert "_comp_tmp_" in result
        assert "await pred(i)" in result

    def test_multiple_generators(self):
        result = lift("""
            async def f():
                x = [await f(a, b) for a in xs for b in ys]
        """)
        assert "_comp_tmp_" in result
        assert "for a in xs:" in result
        assert "for b in ys:" in result

    def test_no_await_unchanged(self):
        result = lift("""
            async def f():
                x = [i * 2 for i in items]
        """)
        assert "_comp_tmp_" not in result
        assert "[i * 2 for i in items]" in result

    def test_await_with_non_await_filter(self):
        result = lift("""
            async def f():
                x = [await g(i) for i in items if pred(i)]
        """)
        assert "_comp_tmp_" in result
        assert "if pred(i):" in result
        assert "await g(i)" in result

    def test_no_await_alongside_await(self):
        result = lift("""
            async def f():
                x = f([i for i in items], await g())
        """)
        assert "_comp_tmp_" not in result
        assert "[i for i in items]" in result


class TestSetCompLifting:
    def test_no_await_alongside_await(self):
        result = lift("""
            async def f():
                x = f({i for i in items}, await g())
        """)
        assert "_comp_tmp_" not in result
        assert "{i for i in items}" in result

    def test_await_in_element(self):
        result = lift("""
            async def f():
                x = {await g(i) for i in items}
        """)
        assert "_comp_tmp_0 = set()" in result
        assert "for i in items:" in result
        assert "await g(i)" in result
        assert "_comp_tmp_0.add(" in result
        assert "x = _comp_tmp_0" in result


class TestDictCompLifting:
    def test_no_await_alongside_await(self):
        result = lift("""
            async def f():
                x = f({k: v for k, v in pairs}, await g())
        """)
        assert "_comp_tmp_" not in result
        assert "{k: v for k, v in pairs}" in result

    def test_await_in_value(self):
        result = lift("""
            async def f():
                x = {k: await fetch(k) for k in keys}
        """)
        assert "_comp_tmp_0 = {}" in result
        assert "for k in keys:" in result
        assert "await fetch(k)" in result
        assert "_comp_tmp_0[k]" in result
        assert "x = _comp_tmp_0" in result

    def test_await_in_key(self):
        result = lift("""
            async def f():
                x = {await make_key(v): v for v in vals}
        """)
        assert "_comp_tmp_" in result
        assert "await make_key(v)" in result


# --- Async step helpers ---


async def double(x: int) -> int:
    return x * 2


async def is_even(x: int) -> bool:
    return x % 2 == 0


async def fetch_items() -> list[int]:
    return [1, 2, 3, 4, 5]


async def make_key(v: int) -> str:
    return f"key_{v}"


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def list_comp_await_element() -> list[int]:
    result = [await double(i) for i in [1, 2, 3]]
    return result


@resumable
async def list_comp_await_filter() -> list[int]:
    result = [await double(i) for i in [1, 2, 3, 4, 5] if await is_even(i)]
    return result


@resumable
async def list_comp_await_iterable() -> list[int]:
    result = [i for i in await fetch_items()]
    return result


@resumable
async def set_comp_await_element() -> set[int]:
    result = {await double(i) for i in [1, 2, 3]}
    return result


@resumable
async def dict_comp_await_value() -> dict[int, int]:
    result = {k: await double(k) for k in [1, 2, 3]}
    return result


@resumable
async def dict_comp_await_key() -> dict[str, int]:
    result = {await make_key(v): v for v in [1, 2, 3]}
    return result


@resumable
async def list_comp_multiple_generators() -> list[int]:
    result = [await double(a + b) for a in [1, 2] for b in [10, 20]]
    return result


@resumable
async def list_comp_boom_workflow() -> list[int]:
    result = [await boom(i) for i in [1]]
    return result  # pragma: no cover


# --- Parity tests ---


class TestListCompParity:
    async def test_await_element(self, assert_parity: AssertParity):
        result = await assert_parity(list_comp_await_element)
        assert result == [2, 4, 6]

    async def test_await_filter(self, assert_parity: AssertParity):
        result = await assert_parity(list_comp_await_filter)
        assert result == [4, 8]

    async def test_await_iterable(self, assert_parity: AssertParity):
        result = await assert_parity(list_comp_await_iterable)
        assert result == [1, 2, 3, 4, 5]

    async def test_multiple_generators(self, assert_parity: AssertParity):
        result = await assert_parity(list_comp_multiple_generators)
        assert result == [22, 42, 24, 44]


class TestSetCompParity:
    async def test_await_element(self, assert_parity: AssertParity):
        result = await assert_parity(set_comp_await_element)
        assert result == {2, 4, 6}


class TestDictCompParity:
    async def test_await_value(self, assert_parity: AssertParity):
        result = await assert_parity(dict_comp_await_value)
        assert result == {1: 2, 2: 4, 3: 6}

    async def test_await_key(self, assert_parity: AssertParity):
        result = await assert_parity(dict_comp_await_key)
        assert result == {"key_1": 1, "key_2": 2, "key_3": 3}


class TestTraceback:
    async def test_traceback_points_to_comprehension(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(list_comp_boom_workflow)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "list_comp_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
