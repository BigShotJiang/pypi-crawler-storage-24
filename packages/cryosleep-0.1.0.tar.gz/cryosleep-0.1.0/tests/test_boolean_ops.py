"""Tests for BoolOp short-circuit preservation: lifting, parity, traceback."""

from __future__ import annotations

import traceback
from typing import TYPE_CHECKING

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- AST-level tests ---


class TestOrLifting:
    def test_or_await_right(self):
        result = lift("""
            async def f():
                x = cached() or await fetch()
        """)
        assert "_sc_tmp_0 = cached()" in result
        assert "if not _sc_tmp_0:" in result
        assert "= await fetch()" in result
        assert "x = _sc_tmp_0" in result

    def test_or_await_left_unchanged(self):
        result = lift("""
            async def f():
                x = await fetch() or default()
        """)
        assert "_sc_tmp_" not in result

    def test_chained_or(self):
        result = lift("""
            async def f():
                x = a() or await b() or await c()
        """)
        assert "_sc_tmp_0 = a()" in result
        assert result.count("if not _sc_tmp_0:") == 2
        assert "await b()" in result
        assert "await c()" in result

    def test_chained_or_mixed(self):
        result = lift("""
            async def f():
                x = a() or await b() or c()
        """)
        assert "_sc_tmp_0 = a()" in result
        assert result.count("if not _sc_tmp_0:") == 2
        assert "await b()" in result
        assert "_sc_tmp_0 = c()" in result


class TestAndLifting:
    def test_and_await_right(self):
        result = lift("""
            async def f():
                x = check() and await fetch()
        """)
        assert "_sc_tmp_0 = check()" in result
        assert "if _sc_tmp_0:" in result
        assert "= await fetch()" in result
        assert "x = _sc_tmp_0" in result


class TestNestedBoolOpLifting:
    def test_nested_and_inside_or(self):
        result = lift("""
            async def f():
                x = (check() and await inner()) or await outer()
        """)
        assert "_sc_tmp_" in result
        assert "await inner()" in result
        assert "await outer()" in result


class TestNoAwaitBoolOpUnchanged:
    def test_no_await_boolop_unchanged(self):
        result = lift("""
            async def f():
                x = a() or b()
        """)
        assert "_sc_tmp_" not in result
        assert "x = a() or b()" in result


# --- Async step helpers ---


async def cached_truthy() -> str:
    return "cached"


async def cached_falsy() -> str:
    return ""


async def fetch_value() -> str:
    return "fetched"


async def check_truthy() -> bool:
    return True


async def check_falsy() -> bool:
    return False


async def fallback_a() -> str:
    return ""


async def fallback_b() -> str:
    return "b"


async def boom() -> str:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def or_truthy_left() -> str:
    result = await cached_truthy() or await fetch_value()
    return result


@resumable
async def or_falsy_left() -> str:
    result = await cached_falsy() or await fetch_value()
    return result


@resumable
async def and_falsy_left() -> str | bool:
    result = await check_falsy() and await fetch_value()
    return result


@resumable
async def and_truthy_left() -> str | bool:
    result = await check_truthy() and await fetch_value()
    return result


@resumable
async def chained_or() -> str:
    result = await fallback_a() or await fallback_b() or await fetch_value()
    return result


@resumable
async def boolop_boom_workflow() -> str:
    result = await cached_falsy() or await boom()
    return result  # pragma: no cover


# --- Parity tests ---


class TestOrParity:
    async def test_truthy_left(self, assert_parity: AssertParity):
        result = await assert_parity(or_truthy_left)
        assert result == "cached"

    async def test_falsy_left(self, assert_parity: AssertParity):
        result = await assert_parity(or_falsy_left)
        assert result == "fetched"


class TestAndParity:
    async def test_falsy_left(self, assert_parity: AssertParity):
        result = await assert_parity(and_falsy_left)
        assert result is False

    async def test_truthy_left(self, assert_parity: AssertParity):
        result = await assert_parity(and_truthy_left)
        assert result == "fetched"


class TestChainedParity:
    async def test_chained_or(self, assert_parity: AssertParity):
        result = await assert_parity(chained_or)
        assert result == "b"


class TestTraceback:
    async def test_traceback_points_to_boolop(self, run_transformed: RunTransformed):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(boolop_boom_workflow)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "boolop_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
