"""Tests for try/except/finally: lifting, CFG, parity, resume, traceback."""

from __future__ import annotations

import ast
import traceback
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.analysis import CFGBuilder
from cryosleep.codegen import generate_state_machine
from cryosleep.types import AwaitAndCheckpoint
from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift, parse_async_func


# --- Stubs for AST-only analysis ---


async def step1(x: int) -> int: ...


# --- CFG sample functions ---


async def await_in_try(x: int) -> int:  # pragma: no cover
    try:
        a = await step1(x)
    except Exception:
        a = 0
    return a


async def await_in_finally(x: int) -> int:  # pragma: no cover
    a = 0
    try:
        a = await step1(x)
    finally:
        b = await step1(a)
    return b


async def await_in_try_except_finally(x: int) -> int:  # pragma: no cover
    a = 0
    try:
        a = await step1(x)
    except ValueError:
        a = 0
    finally:
        b = await step1(a)
    return b


# --- Async step helpers ---


async def add_one(x: int) -> int:
    return x + 1


async def double(x: int) -> int:
    return x * 2


async def identity(x: Any) -> Any:
    return x


async def risky(x: int) -> int:
    if x < 0:
        raise ValueError("negative")
    return x


async def fallback(x: int) -> int:
    return abs(x)


async def cleanup_step(x: str) -> str:
    return f"cleaned:{x}"


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def try_workflow(x: int) -> int:
    try:
        a = await risky(x)
    except ValueError:
        a = await fallback(x)
    b = await double(a)
    return b


@resumable
async def finally_success_workflow(x: int) -> dict[str, Any]:
    cleanup_done = False
    try:
        a = await add_one(x)
    finally:
        result = await cleanup_step("done")
        cleanup_done = True
    return {"value": a, "cleanup": result, "cleanup_done": cleanup_done}


@resumable
async def finally_exception_workflow(x: int) -> dict[str, Any]:
    cleanup_done = False
    try:
        a = await risky(x)
    finally:
        result = await cleanup_step("done")
        cleanup_done = True
    return {
        "value": a,
        "cleanup": result,
        "cleanup_done": cleanup_done,
    }  # pragma: no cover


@resumable
async def try_except_finally_caught_workflow(x: int) -> dict[str, Any]:
    cleanup_done = False
    try:
        a = await risky(x)
    except ValueError:
        a = await fallback(x)
    finally:
        result = await cleanup_step("done")
        cleanup_done = True
    return {"value": a, "cleanup": result, "cleanup_done": cleanup_done}


@resumable
async def try_except_finally_uncaught_workflow(x: int) -> dict[str, Any]:
    cleanup_done = False
    try:
        a = await risky(x)
    except TypeError:
        a = 999  # pragma: no cover
    finally:
        result = await cleanup_step("done")
        cleanup_done = True
    return {
        "value": a,
        "cleanup": result,
        "cleanup_done": cleanup_done,
    }  # pragma: no cover


@resumable
async def try_else_workflow(x: int) -> dict[str, Any]:
    result = "no-else"
    try:
        a = await risky(x)
    except ValueError:
        a = await fallback(x)
    else:
        result = await identity("success")
    return {"value": a, "result": result}


@resumable
async def try_else_finally_workflow(x: int) -> dict[str, Any]:
    result = "no-else"
    cleanup = "none"
    try:
        a = await risky(x)
    except ValueError:
        a = await fallback(x)
    else:
        result = await identity("success")
    finally:
        cleanup = await cleanup_step("done")
    return {"value": a, "result": result, "cleanup": cleanup}


@resumable
async def try_boom_workflow(x: int) -> int:
    a = await boom(x)
    return a  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_lifts_inside_try_body(self):
        result = lift("""
            async def f():
                try:
                    f(await g())
                except Exception:
                    pass
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result


class TestCFG:
    def test_try_produces_handler_blocks(self):
        node = parse_async_func(await_in_try)
        cfg = CFGBuilder().build(node)
        except_blocks = [label for label in cfg.blocks if label.startswith("except_")]
        assert len(except_blocks) == 1

    def test_try_body_await_has_exception_handlers(self):
        node = parse_async_func(await_in_try)
        cfg = CFGBuilder().build(node)
        blocks_with_handlers = [
            b
            for b in cfg.blocks.values()
            if isinstance(b.terminator, AwaitAndCheckpoint) and b.exception_handlers
        ]
        assert len(blocks_with_handlers) == 1
        assert len(blocks_with_handlers[0].exception_handlers) == 1

    def test_try_finally_produces_finally_blocks(self):
        node = parse_async_func(await_in_finally)
        cfg = CFGBuilder().build(node)
        labels = set(cfg.blocks.keys())
        assert any("finally_body" in label for label in labels)
        assert any("finally_normal" in label for label in labels)
        assert any("finally_catch" in label for label in labels)
        assert any("finally_exit" in label for label in labels)
        assert any("finally_reraise" in label for label in labels)

    def test_try_finally_await_has_catchall_handler(self):
        node = parse_async_func(await_in_finally)
        cfg = CFGBuilder().build(node)
        for block in cfg.blocks.values():
            if isinstance(block.terminator, AwaitAndCheckpoint):
                if block.exception_handlers:
                    catchall = block.exception_handlers[-1]
                    assert catchall.type_expr is None or (
                        isinstance(catchall.type_expr, ast.Name)
                        and catchall.type_expr.id == "BaseException"
                    )
                    return
        pytest.fail(
            "no await block with BaseException catch-all found"
        )  # pragma: no cover

    def test_try_except_finally_produces_all_blocks(self):
        node = parse_async_func(await_in_try_except_finally)
        cfg = CFGBuilder().build(node)
        labels = set(cfg.blocks.keys())
        assert any("except" in label for label in labels)
        assert any("finally_body" in label for label in labels)

    def test_try_finally_generates_valid_python(self):
        node = parse_async_func(await_in_finally)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_try_except_finally_generates_valid_python(self):
        node = parse_async_func(await_in_try_except_finally)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_try_generates_valid_python(self):
        node = parse_async_func(await_in_try)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_stmts_after_try_except(self):
        async def fn(x: int) -> int:  # pragma: no cover
            try:
                a = await step1(x)
            except ValueError:
                a = 0
            b = await step1(a)
            return b

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_stmts_after_try_finally(self):
        async def fn(x: int) -> int:  # pragma: no cover
            try:
                _a = await step1(x)  # pyright: ignore[reportUnusedVariable]
            finally:
                b = await step1(0)
            c = await step1(b)
            return c

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_try_except_as_last_stmt(self):
        async def fn(x: int) -> None:  # pragma: no cover
            try:
                await step1(x)
            except ValueError:
                pass

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        compile(ast.unparse(module), "<test>", "exec")

    def test_try_finally_as_last_stmt(self):
        async def fn(x: int) -> None:  # pragma: no cover
            try:
                await step1(x)
            finally:
                await step1(0)

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        compile(ast.unparse(module), "<test>", "exec")

    def test_raise_non_name_exc_falls_through(self):
        source = (
            'async def fn(x):\n    a = await step1(x)\n    raise ValueError("oops")\n'
        )
        tree = ast.parse(source)
        node = tree.body[0]
        assert isinstance(node, ast.AsyncFunctionDef)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        compile(ast.unparse(module), "<test>", "exec")


class TestParity:
    async def test_no_exception(self, assert_parity: AssertParity):
        result = await assert_parity(try_workflow, 5)
        assert result == 10

    async def test_exception_caught(self, assert_parity: AssertParity):
        result = await assert_parity(try_workflow, -3)
        assert result == 6

    async def test_finally_runs_on_success(self, assert_parity: AssertParity):
        result = await assert_parity(finally_success_workflow, 5)
        assert result == {
            "value": 6,
            "cleanup": "cleaned:done",
            "cleanup_done": True,
        }

    async def test_finally_runs_on_exception(self):
        from cryosleep.attempt import attempt
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        with pytest.raises(ValueError, match="negative"):
            await finally_exception_workflow(-3)
        store = CheckpointStore(MemoryStore())
        with pytest.raises(ValueError, match="negative"):
            async with attempt(store, id="r1"):
                await finally_exception_workflow(-3)

    async def test_try_except_finally_caught(self, assert_parity: AssertParity):
        result = await assert_parity(try_except_finally_caught_workflow, -3)
        assert result == {
            "value": 3,
            "cleanup": "cleaned:done",
            "cleanup_done": True,
        }

    async def test_try_except_finally_uncaught(self):
        from cryosleep.attempt import attempt
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        with pytest.raises(ValueError, match="negative"):
            await try_except_finally_uncaught_workflow(-3)
        store = CheckpointStore(MemoryStore())
        with pytest.raises(ValueError, match="negative"):
            async with attempt(store, id="r1"):
                await try_except_finally_uncaught_workflow(-3)

    async def test_try_else_no_exception(self, assert_parity: AssertParity):
        result = await assert_parity(try_else_workflow, 5)
        assert result == {"value": 5, "result": "success"}

    async def test_try_else_exception_caught(self, assert_parity: AssertParity):
        result = await assert_parity(try_else_workflow, -3)
        assert result == {"value": 3, "result": "no-else"}

    async def test_try_else_finally_else_runs(self, assert_parity: AssertParity):
        result = await assert_parity(try_else_finally_workflow, 5)
        assert result == {
            "value": 5,
            "result": "success",
            "cleanup": "cleaned:done",
        }

    async def test_try_else_finally_else_skipped(self, assert_parity: AssertParity):
        result = await assert_parity(try_else_finally_workflow, -3)
        assert result == {
            "value": 3,
            "result": "no-else",
            "cleanup": "cleaned:done",
        }


class TestResume:
    async def test_finally_resume(self):
        from cryosleep.attempt import attempt
        from cryosleep.storage import Checkpoint
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        store = CheckpointStore(MemoryStore())
        saved: list[Checkpoint] = []
        original_put = store.put

        async def capture(key: str, value: Checkpoint) -> None:
            saved.append(value)
            await original_put(key, value)

        store.put = capture  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            result = await finally_success_workflow(5)
        assert result["cleanup_done"] is True

        last_cp = saved[-1]
        await store.put("r2", last_cp)
        async with attempt(store, id="r2"):
            result = await finally_success_workflow(5)
        assert result["cleanup_done"] is True


class TestGenerated:
    def test_try_source_readable(self):
        source = try_workflow.__generated_source__
        assert "match _block" in source
        assert "except ValueError" in source


class TestTraceback:
    async def test_traceback_points_to_try_body(self, run_transformed: RunTransformed):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(try_boom_workflow, x=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "try_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
        assert frame.line is not None
        assert "boom" in frame.line
