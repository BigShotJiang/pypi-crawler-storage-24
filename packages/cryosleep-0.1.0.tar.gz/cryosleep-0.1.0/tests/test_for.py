"""Tests for the for-loop construct: lifting, CFG, parity, resume, traceback."""

from __future__ import annotations

import ast
import traceback
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.analysis import CFGBuilder
from cryosleep.codegen import generate_state_machine
from cryosleep.types import AwaitAndCheckpoint, ForIter, UnsupportedAwaitPattern
from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift, parse_async_func


# --- Stubs for AST-only analysis ---


async def step1(x: int) -> int: ...


# --- CFG sample function ---


async def await_in_loop(x: int) -> list[int]:  # pragma: no cover
    results: list[int] = []
    for i in range(x):
        r = await step1(i)
        results.append(r)
    return results


# --- Async step helpers ---


async def double(x: int) -> int:
    return x * 2


async def identity(x: Any) -> Any:
    return x


async def risky(x: int) -> int:
    if x < 0:
        raise ValueError("negative")
    return x


async def fallback(x: int) -> int:
    return abs(x)


async def fetch_list(n: int) -> list[int]:
    return list(range(n))


async def process(x: int) -> int:
    return x + 10


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def loop_workflow(items: list[int]) -> list[int]:
    results: list[int] = []
    for item in items:
        r = await double(item)
        results.append(r)
    total = await identity(results)
    return total


@resumable
async def break_workflow(items: list[int]) -> list[int]:
    results: list[int] = []
    for item in items:
        if item < 0:
            break
        r = await double(item)
        results.append(r)
    return results


@resumable
async def continue_workflow(items: list[int]) -> list[int]:
    results: list[int] = []
    for item in items:
        if item < 0:
            continue
        r = await double(item)
        results.append(r)
    return results


@resumable
async def try_in_loop(items: list[int]) -> list[int]:
    results: list[int] = []
    for item in items:
        try:
            r = await risky(item)
        except ValueError:
            r = await fallback(item)
        results.append(r)
    return results


@resumable
async def for_await_iter(n: int) -> list[int]:
    results: list[int] = []
    for x in await fetch_list(n):
        r = await process(x)
        results.append(r)
    return results


@resumable
async def for_await_iter_empty(n: int) -> list[int]:
    results: list[int] = []
    for x in await fetch_list(n):
        r = await process(x)
        results.append(r)
    total = await double(len(results))
    return [total]


@resumable
async def for_tuple_target(pairs: list[tuple[int, int]]) -> list[int]:
    results: list[int] = []
    for a, b in pairs:
        r = await double(a + b)
        results.append(r)
    return results


@resumable
async def for_nested_tuple_target(
    items: list[tuple[int, tuple[int, int]]],
) -> list[int]:
    results: list[int] = []
    for a, (b, c) in items:
        r = await double(a + b + c)
        results.append(r)
    return results


@resumable
async def for_else_no_break(items: list[int]) -> str:
    results: list[int] = []
    for item in items:
        r = await double(item)
        results.append(r)
    else:
        marker = await identity("completed")
    return marker


@resumable
async def for_else_with_break(items: list[int]) -> str:
    marker = "no-else"
    for item in items:
        if item < 0:
            break
        _r = await double(item)
    else:
        marker = await identity("completed")
    return marker


@resumable
async def for_else_empty(items: list[int]) -> str:
    for item in items:
        _r = await double(item)  # pragma: no cover
    else:
        marker = await identity("completed")
    return marker


@resumable
async def for_boom_workflow(items: list[int]) -> list[int]:
    results: list[int] = []
    for item in items:
        r = await boom(item)
        results.append(r)  # pragma: no cover
    return results  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_for_await_in_iter(self):
        result = lift("""
            async def f():
                for x in await fetch_list():
                    pass
        """)
        assert "_await_tmp_" in result
        assert "= await fetch_list()" in result
        assert "for x in _await_tmp_" in result

    def test_for_await_in_iter_with_body_awaits(self):
        result = lift("""
            async def f():
                for x in await fetch_list():
                    r = await process(x)
        """)
        assert "= await fetch_list()" in result
        assert "for x in _await_tmp_" in result
        assert "await process(x)" in result

    def test_lifts_inside_for_body(self):
        result = lift("""
            async def f():
                for i in items:
                    f(await g(i))
        """)
        assert "_await_tmp_" in result
        assert "= await g(i)" in result

    def test_tuple_target_desugared(self):
        result = lift("""
            async def f():
                for a, b in items:
                    x = await g(a, b)
        """)
        assert "_for_target_" in result
        assert "a, b = _for_target_" in result

    def test_nested_tuple_target_desugared(self):
        result = lift("""
            async def f():
                for a, (b, c) in items:
                    x = await g(a, b, c)
        """)
        assert "_for_target_" in result
        assert "a, (b, c) = _for_target_" in result

    def test_simple_target_unchanged(self):
        result = lift("""
            async def f():
                for x in items:
                    a = await g(x)
        """)
        assert "_for_target_" not in result
        assert "for x in items" in result


class TestCFG:
    def test_for_loop_produces_iter_block(self):
        node = parse_async_func(await_in_loop)
        cfg = CFGBuilder().build(node)
        has_for_iter = any(
            isinstance(b.terminator, ForIter) for b in cfg.blocks.values()
        )
        assert has_for_iter

    def test_for_loop_body_has_await(self):
        node = parse_async_func(await_in_loop)
        cfg = CFGBuilder().build(node)
        for block in cfg.blocks.values():
            if isinstance(block.terminator, ForIter):
                body_block = cfg.blocks[block.terminator.body_label]
                assert isinstance(body_block.terminator, AwaitAndCheckpoint)

    def test_loop_generates_valid_python(self):
        node = parse_async_func(await_in_loop)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_break_outside_loop_raises(self):
        source = "async def fn(x):\n    a = await step1(x)\n    break\n"
        tree = ast.parse(source)
        node = tree.body[0]
        assert isinstance(node, ast.AsyncFunctionDef)
        with pytest.raises(
            UnsupportedAwaitPattern, match="break/continue outside loop"
        ):
            CFGBuilder().build(node)

    def test_non_simple_for_target_raises(self):
        source = "async def fn(items):\n    for a, b in items:\n        r = await step1(a)\n    return r\n"
        tree = ast.parse(source)
        node = tree.body[0]
        assert isinstance(node, ast.AsyncFunctionDef)
        with pytest.raises(
            UnsupportedAwaitPattern, match="for-loop target must be a simple variable"
        ):
            CFGBuilder().build(node)


class TestParity:
    async def test_processes_all_items(self, assert_parity: AssertParity):
        result = await assert_parity(loop_workflow, [1, 2, 3])
        assert result == [2, 4, 6]

    async def test_empty_list(self, assert_parity: AssertParity):
        result = await assert_parity(loop_workflow, [])
        assert result == []

    async def test_break_stops_loop(self, assert_parity: AssertParity):
        result = await assert_parity(break_workflow, [1, 2, -1, 3])
        assert result == [2, 4]

    async def test_no_break(self, assert_parity: AssertParity):
        result = await assert_parity(break_workflow, [1, 2, 3])
        assert result == [2, 4, 6]

    async def test_continue_skips_item(self, assert_parity: AssertParity):
        result = await assert_parity(continue_workflow, [1, -2, 3])
        assert result == [2, 6]

    async def test_mixed_success_and_failure(self, assert_parity: AssertParity):
        result = await assert_parity(try_in_loop, [5, -3, 10])
        assert result == [5, 3, 10]

    async def test_iterates_fetched_list(self, assert_parity: AssertParity):
        result = await assert_parity(for_await_iter, 3)
        assert result == [10, 11, 12]

    async def test_empty_fetched_list(self, assert_parity: AssertParity):
        result = await assert_parity(for_await_iter, 0)
        assert result == []

    async def test_with_post_loop_await(self, assert_parity: AssertParity):
        result = await assert_parity(for_await_iter_empty, 3)
        assert result == [6]

    async def test_empty_with_post_loop(self, assert_parity: AssertParity):
        result = await assert_parity(for_await_iter_empty, 0)
        assert result == [0]

    async def test_tuple_unpack(self, assert_parity: AssertParity):
        result = await assert_parity(for_tuple_target, [(1, 2), (3, 4)])
        assert result == [6, 14]

    async def test_tuple_unpack_empty(self, assert_parity: AssertParity):
        result = await assert_parity(for_tuple_target, [])
        assert result == []

    async def test_nested_unpack(self, assert_parity: AssertParity):
        result = await assert_parity(
            for_nested_tuple_target, [(1, (2, 3)), (4, (5, 6))]
        )
        assert result == [12, 30]

    async def test_for_else_runs_on_normal_exit(self, assert_parity: AssertParity):
        result = await assert_parity(for_else_no_break, [1, 2, 3])
        assert result == "completed"

    async def test_for_else_skipped_on_break(self, assert_parity: AssertParity):
        result = await assert_parity(for_else_with_break, [1, 2, -1, 3])
        assert result == "no-else"

    async def test_for_else_runs_when_no_break(self, assert_parity: AssertParity):
        result = await assert_parity(for_else_with_break, [1, 2, 3])
        assert result == "completed"

    async def test_for_else_runs_on_empty_iterable(self, assert_parity: AssertParity):
        result = await assert_parity(for_else_empty, [])
        assert result == "completed"


class TestResume:
    async def test_resume_mid_loop(self):
        from cryosleep.attempt import attempt
        from cryosleep.storage import Checkpoint
        from key_value.aio.stores.memory import MemoryStore
        from cryosleep.storage import CheckpointStore

        store = CheckpointStore(MemoryStore())
        saved: list[Checkpoint] = []
        original_put = store.put

        async def capture(key: str, value: Checkpoint) -> None:
            saved.append(value)
            await original_put(key, value)

        store.put = capture  # type: ignore[assignment]
        async with attempt(store, id="r1"):
            await loop_workflow([10, 20, 30])

        first_cp = saved[0]
        await store.put("r2", first_cp)
        async with attempt(store, id="r2"):
            result = await loop_workflow([10, 20, 30])
        assert result == [20, 40, 60]


class TestGenerated:
    def test_loop_source_readable(self):
        source = loop_workflow.__generated_source__
        assert "match _block" in source
        assert "len(" in source


class TestTraceback:
    async def test_traceback_points_to_loop_body(self, run_transformed: RunTransformed):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(for_boom_workflow, items=[1])

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "for_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
        assert frame.line is not None
        assert "boom" in frame.line
