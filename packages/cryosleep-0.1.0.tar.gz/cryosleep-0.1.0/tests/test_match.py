"""Tests for the match/case construct: lifting, CFG, parity, traceback."""

from __future__ import annotations

import ast
import textwrap
import traceback
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.analysis import CFGBuilder
from cryosleep.codegen import generate_state_machine
from cryosleep.types import MatchJump
from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- Stubs for AST-only analysis ---


async def step1(x: int) -> int: ...
async def step2(x: int) -> int: ...
async def step3(x: int) -> int: ...


# --- CFG sample function ---


async def await_in_match(x: int) -> int:  # pragma: no cover
    match x:
        case 1:
            a = await step1(x)
        case 2:
            a = await step2(x)
        case _:
            a = await step3(x)
    return a


# --- Async step helpers ---


async def double(x: int) -> int:
    return x * 2


async def negate(x: int) -> int:
    return -x


async def identity(x: Any) -> Any:
    return x


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def match_literal(command: str) -> int:
    match command:
        case "double":
            result = await double(5)
        case "negate":
            result = await negate(5)
        case _:
            result = await identity(0)
    return result


@resumable
async def match_wildcard_only(x: int) -> int:
    match x:
        case _:
            result = await double(x)
    return result


@resumable
async def match_with_capture(value: Any) -> str:
    match value:
        case int() as n:
            result = await identity(f"int:{n}")
        case str() as s:
            result = await identity(f"str:{s}")
        case _:
            result = await identity("other")
    return result


@resumable
async def match_no_matching_case(x: int) -> int:
    result = 0
    match x:  # pyright: ignore[reportMatchNotExhaustive]
        case 999:
            result = await double(x)  # pragma: no cover
    total = await identity(result)
    return total


@resumable
async def match_after_stmts(x: int) -> int:
    a = await double(x)
    match a:
        case 10:
            result = await negate(a)
        case _:
            result = await identity(a)
    b = await double(result)
    return b


@resumable
async def match_boom_workflow(command: str) -> int:
    result = await boom(1)
    return result  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_match_body_compound_await_lifted(self):
        result = lift("""
            async def f():
                match x:
                    case 1:
                        f(await g())
        """)
        assert "_await_tmp_" in result
        assert "= await g()" in result

    def test_match_multiple_cases_lifted(self):
        result = lift("""
            async def f():
                match x:
                    case 1:
                        a = await g()
                    case 2:
                        b = await h()
        """)
        assert "await g()" in result
        assert "await h()" in result


class TestCFG:
    def _parse(self, fn: Any) -> ast.AsyncFunctionDef:
        import inspect

        source = textwrap.dedent(inspect.getsource(fn))
        tree = ast.parse(source)
        node = tree.body[0]
        assert isinstance(node, ast.AsyncFunctionDef)
        return node

    def test_match_produces_match_jump(self):
        node = self._parse(await_in_match)
        cfg = CFGBuilder().build(node)
        entry = cfg.blocks[cfg.entry]
        assert isinstance(entry.terminator, MatchJump)
        assert len(entry.terminator.cases) == 3

    def test_match_case_bodies_have_await(self):
        from cryosleep.types import AwaitAndCheckpoint

        node = self._parse(await_in_match)
        cfg = CFGBuilder().build(node)
        entry = cfg.blocks[cfg.entry]
        assert isinstance(entry.terminator, MatchJump)
        for mc in entry.terminator.cases:
            case_block = cfg.blocks[mc.target_label]
            assert isinstance(case_block.terminator, AwaitAndCheckpoint)

    def test_match_generates_valid_python(self):
        node = self._parse(await_in_match)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_match_as_last_stmt(self):
        source = textwrap.dedent("""\
            async def fn(x):
                match x:
                    case 1:
                        a = await step1(x)
                        return a
                    case _:
                        return 0
        """)
        tree = ast.parse(source)
        node = tree.body[0]
        assert isinstance(node, ast.AsyncFunctionDef)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        compile(ast.unparse(module), "<test>", "exec")

    def test_match_mapping_rest_tracked(self):
        source = textwrap.dedent("""\
            async def fn(x):
                match x:
                    case {"key": v, **rest}:
                        a = await step1(v)
                        return a
                    case _:
                        return 0
        """)
        tree = ast.parse(source)
        node = tree.body[0]
        assert isinstance(node, ast.AsyncFunctionDef)
        cfg = CFGBuilder().build(node)
        assert "rest" in cfg.all_vars
        assert "v" in cfg.all_vars


class TestParity:
    async def test_first_case(self, assert_parity: AssertParity):
        result = await assert_parity(match_literal, "double")
        assert result == 10

    async def test_second_case(self, assert_parity: AssertParity):
        result = await assert_parity(match_literal, "negate")
        assert result == -5

    async def test_wildcard_case(self, assert_parity: AssertParity):
        result = await assert_parity(match_literal, "unknown")
        assert result == 0

    async def test_wildcard_only(self, assert_parity: AssertParity):
        result = await assert_parity(match_wildcard_only, 7)
        assert result == 14

    async def test_capture_int(self, assert_parity: AssertParity):
        result = await assert_parity(match_with_capture, 42)
        assert result == "int:42"

    async def test_capture_str(self, assert_parity: AssertParity):
        result = await assert_parity(match_with_capture, "hello")
        assert result == "str:hello"

    async def test_capture_other(self, assert_parity: AssertParity):
        result = await assert_parity(match_with_capture, [1, 2])
        assert result == "other"

    async def test_no_matching_case(self, assert_parity: AssertParity):
        result = await assert_parity(match_no_matching_case, 5)
        assert result == 0

    async def test_match_with_surrounding_awaits_negate(
        self, assert_parity: AssertParity
    ):
        result = await assert_parity(match_after_stmts, 5)
        assert result == -20

    async def test_match_with_surrounding_awaits_identity(
        self, assert_parity: AssertParity
    ):
        result = await assert_parity(match_after_stmts, 3)
        assert result == 12


class TestTraceback:
    async def test_traceback_points_to_match_case(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(match_boom_workflow, command="boom")

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "match_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
        assert frame.line is not None
        assert "boom" in frame.line
