import pytest

from key_value.aio.stores.memory import MemoryStore

from cryosleep.storage import Checkpoint
from cryosleep.storage import CheckpointStore


@pytest.fixture
def sample_checkpoint() -> Checkpoint:
    return Checkpoint(
        function_ref="mymod:workflow",
        block="after_await_1",
        args={"x": 10},
        locals_snapshot={"x": 10, "a": 5},
        version="v1",
    )


class TestMemoryStore:
    async def test_put_and_get(self, sample_checkpoint: Checkpoint):
        store = CheckpointStore(MemoryStore())
        await store.put("run-1", sample_checkpoint)
        loaded = await store.get("run-1")
        assert loaded == sample_checkpoint

    async def test_get_missing_returns_none(self):
        store = CheckpointStore(MemoryStore())
        assert await store.get("nope") is None

    async def test_delete(self, sample_checkpoint: Checkpoint):
        store = CheckpointStore(MemoryStore())
        await store.put("run-1", sample_checkpoint)
        result = await store.delete("run-1")
        assert result is True
        assert await store.get("run-1") is None

    async def test_delete_missing_returns_false(self):
        store = CheckpointStore(MemoryStore())
        result = await store.delete("nope")
        assert result is False
