import pytest

from cryosleep.storage import Checkpoint, StaleCheckpointError


def test_version_from_source_is_deterministic():
    src = "async def f(x):\n    a = await step(x)\n    return a\n"
    v1 = Checkpoint.version_from_source(src)
    v2 = Checkpoint.version_from_source(src)
    assert v1 == v2


def test_version_changes_when_source_changes():
    v1 = Checkpoint.version_from_source("async def f(): pass")
    v2 = Checkpoint.version_from_source("async def f(): return 1")
    assert v1 != v2


def test_stale_checkpoint_error():
    with pytest.raises(StaleCheckpointError, match="source has changed"):
        raise StaleCheckpointError("source has changed since checkpoint")
