"""Tests for ternary (if-expression) desugaring: lifting, parity, traceback."""

from __future__ import annotations

import traceback
from typing import TYPE_CHECKING

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- AST-level tests ---


class TestIfExpAwaitInBody:
    def test_await_in_true_branch(self):
        result = lift("""
            async def f():
                x = (await fetch()) if should_fetch else default
        """)
        assert "_ifexp_tmp_0" in result
        assert "if should_fetch:" in result
        assert "await fetch()" in result
        assert "x = _ifexp_tmp_0" in result

    def test_await_in_false_branch(self):
        result = lift("""
            async def f():
                x = primary if ready else (await fallback())
        """)
        assert "_ifexp_tmp_0" in result
        assert "if ready:" in result
        assert "await fallback()" in result
        assert "x = _ifexp_tmp_0" in result

    def test_await_in_both_branches(self):
        result = lift("""
            async def f():
                x = (await a()) if cond else (await b())
        """)
        assert "_ifexp_tmp_0" in result
        assert "if cond:" in result
        assert "await a()" in result
        assert "await b()" in result
        assert "x = _ifexp_tmp_0" in result


class TestIfExpAwaitInCondition:
    def test_await_in_condition(self):
        result = lift("""
            async def f():
                x = true_val if (await check()) else false_val
        """)
        assert "_ifexp_tmp_0" in result
        assert "await check()" in result
        assert "x = _ifexp_tmp_0" in result

    def test_await_in_condition_and_body(self):
        result = lift("""
            async def f():
                x = (await fetch()) if (await check()) else default
        """)
        assert "_ifexp_tmp_0" in result
        assert "await check()" in result
        assert "await fetch()" in result
        assert "x = _ifexp_tmp_0" in result


class TestNoAwaitIfExpUnchanged:
    def test_no_await_ifexp_unchanged(self):
        result = lift("""
            async def f():
                x = a() if cond else b()
        """)
        assert "_ifexp_tmp_" not in result
        assert "a() if cond else b()" in result

    def test_no_await_ifexp_alongside_await(self):
        result = lift("""
            async def f():
                x = f(a() if cond else b(), await g())
        """)
        assert "_ifexp_tmp_" not in result
        assert "a() if cond else b()" in result


# --- Async step helpers ---


async def check_truthy() -> bool:
    return True


async def check_falsy() -> bool:
    return False


async def fetch_value() -> str:
    return "fetched"


async def fallback_value() -> str:
    return "fallback"


async def boom() -> str:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def ternary_true_branch() -> str:
    result = (await fetch_value()) if True else "default"
    return result


@resumable
async def ternary_false_branch() -> str:
    result = (await fetch_value()) if False else "default"
    return result


@resumable
async def ternary_await_in_else() -> str:
    result = "primary" if False else (await fallback_value())
    return result


@resumable
async def ternary_both_branches() -> str:
    result = (await fetch_value()) if True else (await fallback_value())
    return result


@resumable
async def ternary_both_branches_else() -> str:
    result = (await fetch_value()) if False else (await fallback_value())
    return result


@resumable
async def ternary_await_in_condition() -> str:
    result = "yes" if (await check_truthy()) else "no"
    return result


@resumable
async def ternary_await_in_condition_false() -> str:
    result = "yes" if (await check_falsy()) else "no"
    return result


@resumable
async def ternary_await_everywhere() -> str:
    result = (
        (await fetch_value()) if (await check_truthy()) else (await fallback_value())
    )
    return result


@resumable
async def ternary_boom_workflow() -> str:
    result = (await boom()) if True else "safe"
    return result  # pragma: no cover


# --- Parity tests ---


class TestTernaryTrueBranch:
    async def test_condition_true(self, assert_parity: AssertParity):
        result = await assert_parity(ternary_true_branch)
        assert result == "fetched"

    async def test_condition_false(self, assert_parity: AssertParity):
        result = await assert_parity(ternary_false_branch)
        assert result == "default"


class TestTernaryFalseBranch:
    async def test_await_in_else(self, assert_parity: AssertParity):
        result = await assert_parity(ternary_await_in_else)
        assert result == "fallback"


class TestTernaryBothBranches:
    async def test_true_path(self, assert_parity: AssertParity):
        result = await assert_parity(ternary_both_branches)
        assert result == "fetched"

    async def test_false_path(self, assert_parity: AssertParity):
        result = await assert_parity(ternary_both_branches_else)
        assert result == "fallback"


class TestTernaryAwaitInCondition:
    async def test_condition_truthy(self, assert_parity: AssertParity):
        result = await assert_parity(ternary_await_in_condition)
        assert result == "yes"

    async def test_condition_falsy(self, assert_parity: AssertParity):
        result = await assert_parity(ternary_await_in_condition_false)
        assert result == "no"


class TestTernaryAwaitEverywhere:
    async def test_all_positions(self, assert_parity: AssertParity):
        result = await assert_parity(ternary_await_everywhere)
        assert result == "fetched"


class TestTraceback:
    async def test_traceback_points_to_ternary(self, run_transformed: RunTransformed):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(ternary_boom_workflow)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "ternary_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
