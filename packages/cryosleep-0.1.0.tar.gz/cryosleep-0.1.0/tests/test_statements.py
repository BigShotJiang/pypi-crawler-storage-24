"""Tests for lifting awaits from raise, assert, delete: lifting, parity, traceback."""

from __future__ import annotations

import traceback
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift


# --- Helpers ---


async def get_error() -> Exception:
    return ValueError("boom")


async def validate(data: int) -> bool:
    return data > 0


async def get_message() -> str:
    return "validation failed"


async def get_index() -> int:
    return 1


# --- AST-level lifting tests ---


class TestRaiseLifting:
    def test_raise_await_lifted(self):
        result = lift("""
            async def f():
                raise await get_error()
        """)
        assert "_await_tmp_" in result
        assert "= await get_error()" in result
        assert "raise _await_tmp_" in result

    def test_raise_compound_await_lifted(self):
        result = lift("""
            async def f():
                raise ValueError(await get_message())
        """)
        assert "_await_tmp_" in result
        assert "= await get_message()" in result
        assert "raise ValueError(_await_tmp_" in result

    def test_raise_from_await_lifted(self):
        result = lift("""
            async def f():
                raise ValueError() from await get_error()
        """)
        assert "_await_tmp_" in result
        assert "= await get_error()" in result
        assert "raise ValueError() from _await_tmp_" in result

    def test_raise_no_await_unchanged(self):
        result = lift("""
            async def f():
                raise ValueError("oops")
        """)
        assert "_await_tmp_" not in result
        assert "raise ValueError('oops')" in result


class TestAssertLifting:
    def test_assert_test_await_lifted(self):
        result = lift("""
            async def f():
                assert await validate(data)
        """)
        assert "_await_tmp_" in result
        assert "= await validate(data)" in result
        assert "assert _await_tmp_" in result

    def test_assert_msg_await_lifted(self):
        result = lift("""
            async def f():
                assert x > 0, await get_message()
        """)
        assert "_await_tmp_" in result
        assert "= await get_message()" in result
        assert "assert x > 0, _await_tmp_" in result

    def test_assert_both_await_lifted(self):
        result = lift("""
            async def f():
                assert await validate(x), await get_message()
        """)
        assert result.count("= await") == 2

    def test_assert_no_await_unchanged(self):
        result = lift("""
            async def f():
                assert x > 0, "must be positive"
        """)
        assert "_await_tmp_" not in result


class TestDeleteLifting:
    def test_del_subscript_await_lifted(self):
        result = lift("""
            async def f():
                del container[await get_index()]
        """)
        assert "_await_tmp_" in result
        assert "= await get_index()" in result
        assert "del container[_await_tmp_" in result

    def test_del_no_await_unchanged(self):
        result = lift("""
            async def f():
                del container[0]
        """)
        assert "_await_tmp_" not in result


# --- Workflows ---


@resumable
async def raise_await_workflow() -> str:
    try:
        raise await get_error()
    except ValueError as e:
        return str(e)


@resumable
async def assert_await_workflow(data: int) -> bool:
    assert await validate(data)
    return True


@resumable
async def assert_msg_await_workflow(data: int) -> bool:
    assert await validate(data), await get_message()
    return True


@resumable
async def del_await_workflow() -> list[Any]:
    items = [10, 20, 30]
    del items[await get_index()]
    return items


@resumable
async def raise_boom_workflow() -> str:
    raise await get_error()


# --- Parity tests ---


class TestRaiseAwaitParity:
    async def test_raise_await(self, assert_parity: AssertParity):
        result = await assert_parity(raise_await_workflow)
        assert result == "boom"


class TestAssertAwaitParity:
    async def test_assert_passing(self, assert_parity: AssertParity):
        result = await assert_parity(assert_await_workflow, 5)
        assert result is True

    async def test_assert_failing(self):
        with pytest.raises(AssertionError):
            await assert_await_workflow(-1)

    async def test_assert_msg_passing(self, assert_parity: AssertParity):
        result = await assert_parity(assert_msg_await_workflow, 5)
        assert result is True


class TestDeleteAwaitParity:
    async def test_del_await(self, assert_parity: AssertParity):
        result = await assert_parity(del_await_workflow)
        assert result == [10, 30]


class TestTraceback:
    async def test_traceback_points_to_raise(self, run_transformed: RunTransformed):
        with pytest.raises(ValueError) as exc_info:
            await run_transformed(raise_boom_workflow)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "raise_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
