"""Tests for the while-loop construct: lifting, CFG, parity, traceback."""

from __future__ import annotations

import ast
import traceback
from typing import TYPE_CHECKING, Any

import pytest

from cryosleep.analysis import CFGBuilder
from cryosleep.codegen import generate_state_machine
from cryosleep.transform import resumable

if TYPE_CHECKING:
    from conftest import AssertParity, RunTransformed

from helpers import extract_function_frame, lift, parse_async_func


# --- Stubs for AST-only analysis ---


async def step1(x: int) -> int: ...


# --- Async step helpers ---


async def add_one(x: int) -> int:
    return x + 1


async def identity(x: Any) -> Any:
    return x


async def has_more(items: list[int], idx: int) -> bool:
    return idx < len(items)


async def get_item(items: list[int], idx: int) -> int:
    return items[idx]


async def double(x: int) -> int:
    return x * 2


async def check(x: int) -> bool:
    return x > 0


async def boom(x: int) -> int:
    raise RuntimeError("kaboom")


# --- Workflows ---


@resumable
async def while_workflow(n: int) -> int:
    total = 0
    i = 0
    while i < n:
        r = await add_one(i)
        total = total + r
        i = i + 1
    result = await identity(total)
    return result


@resumable
async def while_await_test(items: list[int]) -> list[int]:
    results: list[int] = []
    idx = 0
    while await has_more(items, idx):
        val = await get_item(items, idx)
        r = await double(val)
        results.append(r)
        idx = idx + 1
    return results


@resumable
async def while_await_zero_iterations(x: int) -> int:
    total = 0
    while await check(x):
        total = total + 1
        x = x - 1
    return total


@resumable
async def while_else_normal(n: int) -> str:
    i = 0
    while i < n:
        _r = await add_one(i)
        i = i + 1
    else:
        marker = await identity("completed")
    return marker


@resumable
async def while_else_with_break(n: int) -> str:
    marker = "no-else"
    i = 0
    while i < n:
        if i >= 2:
            break
        _r = await add_one(i)
        i = i + 1
    else:
        marker = await identity("completed")
    return marker


@resumable
async def while_else_zero_iterations(n: int) -> str:
    i = 0
    while i < n:
        _r = await add_one(i)  # pragma: no cover
        i = i + 1  # pragma: no cover
    else:
        marker = await identity("completed")
    return marker


@resumable
async def while_boom_workflow(n: int) -> int:
    total = 0
    i = 0
    while i < n:
        total += await boom(i)
        i += 1  # pragma: no cover
    return total  # pragma: no cover


# --- Tests ---


class TestLifting:
    def test_while_await_in_test(self):
        result = lift("""
            async def f():
                while await has_more():
                    pass
        """)
        assert "while True" in result
        assert "= await has_more()" in result
        assert "break" in result

    def test_while_await_in_test_with_body_awaits(self):
        result = lift("""
            async def f():
                while await has_more():
                    item = await get_next()
        """)
        assert "while True" in result
        assert "= await has_more()" in result
        assert "break" in result
        assert "await get_next()" in result

    def test_while_await_preserves_else(self):
        result = lift("""
            async def f():
                while await has_more():
                    pass
                else:
                    a = await done()
        """)
        assert "_done_0" in result
        assert "while not _done_0" in result
        assert "continue" in result
        assert "await done()" in result


class TestCFG:
    def test_stmts_after_while(self):
        async def fn(x: int) -> int:  # pragma: no cover
            a = 0
            i = 0
            while i < x:
                a = await step1(i)
                i = i + 1
            b = await step1(a)
            return b

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        source = ast.unparse(module)
        compile(source, "<test>", "exec")

    def test_while_as_last_stmt(self):
        async def fn(x: int) -> None:  # pragma: no cover
            while x > 0:
                x = await step1(x)

        node = parse_async_func(fn)
        cfg = CFGBuilder().build(node)
        module = generate_state_machine(cfg)
        compile(ast.unparse(module), "<test>", "exec")


class TestParity:
    async def test_while_loop(self, assert_parity: AssertParity):
        result = await assert_parity(while_workflow, 3)
        assert result == 6

    async def test_while_zero_iterations(self, assert_parity: AssertParity):
        result = await assert_parity(while_workflow, 0)
        assert result == 0

    async def test_while_await_processes_all(self, assert_parity: AssertParity):
        result = await assert_parity(while_await_test, [10, 20, 30])
        assert result == [20, 40, 60]

    async def test_while_await_empty_list(self, assert_parity: AssertParity):
        result = await assert_parity(while_await_test, [])
        assert result == []

    async def test_while_await_counts_down(self, assert_parity: AssertParity):
        result = await assert_parity(while_await_zero_iterations, 3)
        assert result == 3

    async def test_while_await_zero_iterations(self, assert_parity: AssertParity):
        result = await assert_parity(while_await_zero_iterations, 0)
        assert result == 0

    async def test_while_else_runs_on_condition_false(
        self, assert_parity: AssertParity
    ):
        result = await assert_parity(while_else_normal, 3)
        assert result == "completed"

    async def test_while_else_skipped_on_break(self, assert_parity: AssertParity):
        result = await assert_parity(while_else_with_break, 5)
        assert result == "no-else"

    async def test_while_else_runs_when_no_break(self, assert_parity: AssertParity):
        result = await assert_parity(while_else_with_break, 2)
        assert result == "completed"

    async def test_while_else_runs_on_zero_iterations(
        self, assert_parity: AssertParity
    ):
        result = await assert_parity(while_else_zero_iterations, 0)
        assert result == "completed"


class TestTraceback:
    async def test_traceback_points_to_while_body(
        self, run_transformed: RunTransformed
    ):
        with pytest.raises(RuntimeError) as exc_info:
            await run_transformed(while_boom_workflow, n=1)

        tb = traceback.TracebackException.from_exception(exc_info.value)
        frame = extract_function_frame(tb, "while_boom_workflow")
        assert frame is not None
        assert frame.filename == __file__
        assert frame.line is not None
        assert "boom" in frame.line
