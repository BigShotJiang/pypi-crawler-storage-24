"""Verify that CheckpointStore works with py-key-value backends."""

from pathlib import Path

import pytest

from key_value.aio.protocols.key_value import AsyncKeyValueProtocol
from key_value.aio.stores.disk import DiskStore
from key_value.aio.stores.memory import MemoryStore

from cryosleep.attempt import attempt
from cryosleep.storage import AsyncKeyValueProtocol as OurProtocol
from cryosleep.storage import CheckpointStore
from cryosleep.transform import resumable


async def step_a(x: int) -> int:
    return x + 1


async def step_b(x: int) -> int:
    return x * 2


@resumable
async def two_step(x: int) -> int:
    a = await step_a(x)
    b = await step_b(a)
    return b


_crash_count = 0


async def crashing_step(x: int) -> int:
    global _crash_count
    _crash_count += 1
    if _crash_count == 1:
        raise RuntimeError("boom")
    return x * 2


@resumable
async def crashing_workflow(x: int) -> int:  # pragma: no cover
    a = await step_a(x)
    b = await crashing_step(a)
    return b


@pytest.fixture
def memory_store() -> CheckpointStore:
    return CheckpointStore(MemoryStore())


@pytest.fixture
def disk_store(tmp_path: Path) -> CheckpointStore:
    return CheckpointStore(DiskStore(directory=tmp_path / "checkpoints"))


class TestProtocolCompat:
    def test_our_protocol_is_subset_of_py_key_value(self):
        """Our AsyncKeyValueProtocol's methods are a subset of py-key-value's."""
        our_methods = {
            name
            for name in dir(OurProtocol)
            if not name.startswith("_") and callable(getattr(OurProtocol, name))
        }
        their_methods = {
            name
            for name in dir(AsyncKeyValueProtocol)
            if not name.startswith("_")
            and callable(getattr(AsyncKeyValueProtocol, name))
        }
        assert our_methods <= their_methods

    def test_memory_store_satisfies_our_protocol(self):
        assert isinstance(MemoryStore(), OurProtocol)

    def test_disk_store_satisfies_our_protocol(self, tmp_path: Path):
        assert isinstance(DiskStore(directory=tmp_path / "compat"), OurProtocol)


class TestMemoryBackend:
    async def test_fresh_run(self, memory_store: CheckpointStore):
        async with attempt(memory_store, id="run-1"):
            result = await two_step(5)
        assert result == 12

    async def test_crash_and_resume(self, memory_store: CheckpointStore):
        global _crash_count
        _crash_count = 0

        with pytest.raises(RuntimeError, match="boom"):
            async with attempt(memory_store, id="run-1"):
                await crashing_workflow(5)

        async with attempt(memory_store, id="run-1"):
            result = await crashing_workflow(5)
        # step_a: 5+1=6, crashing_step: 6*2=12
        assert result == 12


class TestDiskBackend:
    async def test_fresh_run(self, disk_store: CheckpointStore):
        async with attempt(disk_store, id="run-1"):
            result = await two_step(5)
        assert result == 12

    async def test_crash_and_resume(self, disk_store: CheckpointStore):
        global _crash_count
        _crash_count = 0

        with pytest.raises(RuntimeError, match="boom"):
            async with attempt(disk_store, id="run-1"):
                await crashing_workflow(5)

        async with attempt(disk_store, id="run-1"):
            result = await crashing_workflow(5)
        assert result == 12
