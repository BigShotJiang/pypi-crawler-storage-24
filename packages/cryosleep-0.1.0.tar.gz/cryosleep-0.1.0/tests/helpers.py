"""Shared test helpers importable by test modules."""

import ast
import inspect
import textwrap
import traceback
from typing import Any

from cryosleep.lifting import lift_awaits


def lift(source: str) -> str:
    """Parse an async def, lift awaits, return unparsed body."""
    tree = ast.parse(textwrap.dedent(source))
    func = tree.body[0]
    assert isinstance(func, ast.AsyncFunctionDef)
    lifted = lift_awaits(func)
    return ast.unparse(lifted)


def parse_async_func(fn: Any) -> ast.AsyncFunctionDef:
    """Parse a function's source into an AST node."""
    source = textwrap.dedent(inspect.getsource(fn))
    tree = ast.parse(source)
    node = tree.body[0]
    assert isinstance(node, ast.AsyncFunctionDef)
    return node


def extract_function_frame(
    tb: traceback.TracebackException, fn_name: str
) -> traceback.FrameSummary | None:
    """Find the traceback frame for a given function name."""
    for frame in tb.stack:
        if frame.name == fn_name:
            return frame
    return None  # pragma: no cover
