# cryosleep

Resumable async functions for Python.

Decorate an `async def` with `@resumable`, wrap the call in an `attempt`, and
cryosleep checkpoints after every `await`. If the process dies mid-flight, the
next attempt picks up where it left off — completed steps don't re-execute.

```python
from cryosleep import CheckpointStore, attempt, resumable

@resumable
async def process_order(order_id: str) -> str:
    order = await validate_order(order_id)     # step 1
    order = await charge_payment(order)         # step 2 — crashes here
    confirmation = await ship_order(order)      # step 3
    return confirmation
```

If the first run crashes at step 2, a checkpoint is saved. The next run with the
same `id` skips step 1, retries step 2, and continues from there:

```python
store = CheckpointStore(backend)

async with attempt(store, id="order-42"):
    result = await process_order("42")
```

No replay. No event sourcing. Just Python's AST machinery turning your function
into a state machine that knows where it stopped.

## Install

```
uv add cryosleep
```

## Bring your own store

`CheckpointStore` wraps any [py-key-value](https://github.com/strawgate/py-key-value)
backend. Anything with `get`/`put`/`delete` works — memory, disk, Redis, S3:

```python
from key_value.aio.stores.memory import MemoryStore
from key_value.aio.stores.disk import DiskStore

# In-memory (tests, prototyping)
store = CheckpointStore(MemoryStore())

# On disk (single-machine durability)
store = CheckpointStore(DiskStore(directory="./checkpoints"))
```

## What you can put in a resumable function

The `@resumable` decorator handles all of Python's async control flow. Loops,
conditionals, `try`/`except`/`finally`, `match`/`case`, `async for`, `async
with`, comprehensions, tuple unpacking, `*args`/`**kwargs` — it all works.
Constructs are arbitrarily nestable.

```python
@resumable
async def complex_workflow(items: list[str]) -> list[str]:
    results = []
    for item in items:
        try:
            result = await process(item)
        except ValueError:
            result = await fallback(item)
        results.append(result)
    return results
```

Each `await` is a checkpoint boundary. If this crashes after processing 3 of 5
items, the next attempt resumes at item 4.

## Limitations

- All locals at each `await` must be `cloudpickle`-able. If something isn't
  serializable, the checkpoint fails.
- Callables in the body must be importable from `fn.__globals__`. Closures and
  lambdas won't resolve.
- Changing the function source between checkpoint and resume raises
  `StaleCheckpointError`. There's no checkpoint migration.
- `await` inside generator expressions is rejected at decoration time. They're
  lazy iterators with no clear checkpoint semantics.

## How it works

The `@resumable` decorator, at decoration time, parses your function's AST,
builds a control flow graph, and generates a `while True` / `match _block:`
dispatch loop. Each `await` is a block boundary with a checkpoint. On resume,
the generated code jumps directly to the right block and restores locals from
the snapshot.

Inspect the generated code with `fn.__generated_source__`.

See [DESIGN.md](DESIGN.md) for the full architecture.
