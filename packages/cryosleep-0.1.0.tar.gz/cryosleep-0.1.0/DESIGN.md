# cryosleep — Design Document

Resumable async functions for Python.

## What is this?

cryosleep explores whether Python's native async machinery can support **durable
execution**: saving enough state at `await` points to resume a function in a
different process. It uses
**AST transformation** to turn `async def` functions into state machines — no
replay, no frame serialization.

## The core idea

The user writes normal async functions:

```python
@resumable
async def my_workflow(x: int) -> int:
    a = await step1(x)
    b = await step2(a)
    c = await step3(b)
    return c
```

The `@resumable` decorator, at decoration time:

1. Parses the function source via `ast`
2. **Desugars** complex syntax (`async for`, `async with`, `except*`, sync
   `with` containing awaits) into lower-level equivalents
3. **Lifts** awaits out of compound expressions (`f(await g())`, ternaries,
   comprehensions, BoolOps) into simple assignment statements
4. Builds a **control flow graph** (CFG) of basic blocks, where every `await`
   is a block boundary with a checkpoint
5. **Generates** a `while True` / `match _block:` dispatch loop
6. On resume, jumps directly to the right block, restores locals from a
   persisted snapshot

**What gets persisted**: function ref (module + qualname), original args, block
label, locals snapshot at that point, source hash (for staleness detection).
Serialization uses cloudpickle via `CheckpointStore`, with each field stored
individually in the underlying key-value backend.

## Package structure

```
src/cryosleep/
    __init__.py              # Public API surface
    types.py                 # CFG types: BasicBlock, terminators, ControlFlowGraph
    desugaring.py            # Syntax rewrites: async for/with, sync with, for targets, raise
    desugaring_trystar.py    # except* → BaseExceptionGroup.split() desugaring
    lifting.py               # Extract awaits from compound expressions into simple assignments
    analysis.py              # CFG builder: walks lifted AST into basic blocks
    codegen.py               # AST code generation from CFG
    storage.py               # Checkpoint dataclass, AsyncKeyValueProtocol, CheckpointStore
    transform.py             # @resumable decorator (ties the pipeline together)
    attempt.py               # attempt() context manager — the execution engine
tests/
    helpers.py               # Shared test utilities (lift, parse_async_func, etc.)
    conftest.py              # pytest fixtures (assert_parity, run_transformed)
    test_<construct>.py      # Per-construct tests (await, if, for, while, try, match, etc.)
    test_attempt.py          # attempt context manager + resume behavior
    test_checkpoint.py       # Checkpoint dataclass + version hashing
    test_storage.py          # CheckpointStore serialization
    test_py_key_value_compat.py  # Protocol + backend compatibility
```

## Transformation pipeline

### Desugaring (`desugaring.py`, `desugaring_trystar.py`)

Before lifting or CFG construction, complex syntax is rewritten into forms the
downstream passes already handle:

- `TryStarRewriter` — rewrites `except*` into `except BaseException` with
  manual `BaseExceptionGroup.split()` calls
- `ForTargetRewriter` — rewrites tuple/complex for-loop targets into a temp
  variable plus unpacking assignment
- `AsyncForRewriter` — rewrites `async for` into `while`/`try`/`except` with
  explicit `__anext__` calls
- `AsyncWithRewriter` — rewrites `async with` into `__aenter__`/`__aexit__`
  protocol calls via `desugar_cm`
- `SyncWithRewriter` — same treatment for sync `with` blocks that contain awaits
- `RaiseSimplifier` — rewrites `raise <expr>` into `tmp = <expr>; raise tmp`
  inside try blocks (the CFG builder only routes `raise <Name>`)

### Lifting (`lifting.py`)

The CFG builder expects every `await` to appear as the value of a simple
assignment (`x = await f()`) or a standalone expression (`await f()`). The
lifter rewrites compound expressions so this holds:

- `f(await g(await h()))` becomes three sequential assignments
- `(await a()) if cond else (await b())` becomes an if/else with a temp variable
- `x or await y()` preserves short-circuit semantics via conditional if-chains
- Comprehensions with awaits become explicit loops
- Awaits in `if`/`while`/`for` test expressions get extracted into preceding
  assignments

### Analysis (`analysis.py`)

`CFGBuilder` walks the lifted `AsyncFunctionDef` and produces a
`ControlFlowGraph`: a dict of `BasicBlock`s connected by terminators.

**Terminators** describe how control leaves a block:
- `AwaitAndCheckpoint` — await an expression, save a checkpoint, jump to successor
- `Jump` — unconditional goto
- `ConditionalJump` — branch on a test expression
- `ForIter` — test loop index against list length
- `ReturnValue` — return from the function
- `Raise` — raise with exception handler routing
- `MatchJump` — structural pattern matching dispatch

The builder handles `if`/`elif`/`else`, `for`, `while`, `break`, `continue`,
`try`/`except`/`finally`, `match`/`case`, and `raise`. It tracks cumulative
assigned variables for checkpoint snapshots. Blocks inside a `try` scope carry
`exception_handlers` so codegen can wrap their await in `try`/`except`.

Exception handler temporaries (`except SomeError as e`) are tracked separately
via `exc_tmp_vars` and excluded from checkpoint snapshots, since Python deletes
these variables when the except block exits.

### Codegen (`codegen.py`)

`generate_state_machine(cfg)` takes a `ControlFlowGraph` and emits an
`ast.Module` containing the transformed async function. The function body is a
preamble (block/locals restoration) followed by `while True: match _block:` with
a case per block.

Before each await, the generated code calls `_set_call_scope(block_label)` so
that nested `@resumable` calls can derive their own checkpoint ID from the
parent's current position.

### Storage (`storage.py`)

- `Checkpoint(function_ref, block, args, locals_snapshot, version)` — frozen
  dataclass. `version` = sha256 of the function's source; mismatch on resume
  raises `StaleCheckpointError`
- `AsyncKeyValueProtocol` — shadows
  [py-key-value](https://github.com/strawgate/py-key-value)'s protocol
  (`get`/`put`/`delete`) so we don't need it at runtime
- `CheckpointStore` — wraps any `AsyncKeyValueProtocol` backend with
  cloudpickle + base64 serialization; any py-key-value store (MemoryStore,
  DiskStore, Redis, S3, etc.) plugs in directly

### Transform (`transform.py`)

`@resumable` ties the pipeline together: parse → desugar → lift → CFG → codegen
→ compile → exec. The generated code is compiled with the original source
filename and remapped line numbers so that tracebacks point back to the original
`await` expressions.

Attaches `_transformed`, `__generated_source__`, `_source_version`, and `_cfg`
to the wrapper function. Outside an `attempt`, the wrapper calls through to the
original async function. Inside one, it delegates to the state machine.

### Attempt (`attempt.py`)

`attempt(store, id=...)` — async context manager that activates checkpointing:

1. Sets a `ContextVar` so `@resumable` wrappers know they're inside an attempt
2. On each `@resumable` call, loads any existing checkpoint and validates the
   source version
3. Injects the checkpoint callback (with `copy.deepcopy` on the locals snapshot
   to handle mutable values)
4. Cleans up the checkpoint on successful completion

**Nested resumable functions** get their own checkpoints, keyed by position in
the parent's CFG. Two context vars carry this:

- `_checkpoint_parent` — the current execution's checkpoint ID
- `_call_site` — the block label about to be awaited

A child's checkpoint ID is `{parent_id}/{call_site}`, producing a hierarchical
key like `order-42/block_3/block_7`. Each `@resumable` in the call tree
checkpoints independently, so a crash in a nested function only loses that
function's progress.

## Generated code

For a simple sequential workflow, the decorator generates something like:

```python
async def my_workflow(x=None, _resume_state=None, _checkpoint_fn=None, _set_call_scope=None):
    _block = _resume_state.block if _resume_state else 'entry_0'
    _locals = _resume_state.locals_snapshot if _resume_state else {}
    x = _locals.get('x', x)
    a = _locals.get('a', None)
    ...

    while True:
        match _block:
            case 'entry_0':
                _set_call_scope('entry_0')
                a = await step1(x)
                await _checkpoint_fn(block='after_await_2', ...)
                _block = 'after_await_2'
                continue
            case 'after_await_2':
                _set_call_scope('after_await_2')
                b = await step2(a)
                await _checkpoint_fn(block='after_await_3', ...)
                _block = 'after_await_3'
                continue
            ...
```

Conditionals become forking edges, loops become back-edges with explicit
index/items variables, try/except wraps the await in a try block that redirects
to handler blocks on exception. You can inspect this via
`fn.__generated_source__`.
