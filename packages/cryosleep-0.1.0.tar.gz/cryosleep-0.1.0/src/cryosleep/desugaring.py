"""Desugar complex syntax into simpler constructs the CFG builder handles.

These rewriters run before the lifting and CFG passes, converting higher-level
syntax into lower-level equivalents that the CFG builder already handles.
"""

import ast


def contains_await(node: ast.AST) -> bool:
    for child in ast.walk(node):
        if isinstance(child, ast.Await):
            return True
    return False


# --- Shared context manager desugaring ---


def desugar_cm(
    context_expr: ast.expr,
    optional_vars: ast.expr | None,
    body: list[ast.stmt],
    enter_attr: str,
    exit_attr: str,
    is_async: bool,
    var_prefix: str,
    counter: int,
    lineno: int,
) -> list[ast.stmt]:
    """Build the desugared form of a with/async with statement.

    Both sync and async context managers desugar to the same structure:
    assign CM, call enter, try/except body with exit in both paths.
    The only difference is whether the enter/exit calls are awaited.
    """
    cm_var = f"{var_prefix}{counter}"
    exc_flag = f"{var_prefix}exc_{counter}"
    err_var = f"{var_prefix}err_{counter}"
    exit_res_var = f"{var_prefix}exit_res_{counter}"

    def _maybe_await(expr: ast.expr) -> ast.expr:
        return ast.Await(value=expr) if is_async else expr

    stmts: list[ast.stmt] = []

    # cm_var = EXPR
    stmts.append(
        ast.Assign(
            targets=[ast.Name(id=cm_var, ctx=ast.Store())],
            value=context_expr,
            lineno=lineno,
        )
    )

    # VAR = [await] cm.__enter__()
    enter_call = _maybe_await(
        ast.Call(
            func=ast.Attribute(
                value=ast.Name(id=cm_var, ctx=ast.Load()),
                attr=enter_attr,
                ctx=ast.Load(),
            ),
            args=[],
            keywords=[],
        )
    )
    if optional_vars is not None:
        stmts.append(
            ast.Assign(targets=[optional_vars], value=enter_call, lineno=lineno)
        )
    else:
        stmts.append(ast.Expr(value=enter_call, lineno=lineno))

    # exc_flag = False
    stmts.append(
        ast.Assign(
            targets=[ast.Name(id=exc_flag, ctx=ast.Store())],
            value=ast.Constant(value=False),
            lineno=lineno,
        )
    )

    # try: BODY except BaseException as err: ...
    err_name = ast.Name(id=err_var, ctx=ast.Load())
    exit_exc_call = _maybe_await(
        ast.Call(
            func=ast.Attribute(
                value=ast.Name(id=cm_var, ctx=ast.Load()),
                attr=exit_attr,
                ctx=ast.Load(),
            ),
            args=[
                ast.Call(
                    func=ast.Name(id="type", ctx=ast.Load()),
                    args=[err_name],
                    keywords=[],
                ),
                err_name,
                ast.Attribute(value=err_name, attr="__traceback__", ctx=ast.Load()),
            ],
            keywords=[],
        )
    )

    handler_body: list[ast.stmt] = [
        ast.Assign(
            targets=[ast.Name(id=exc_flag, ctx=ast.Store())],
            value=ast.Constant(value=True),
            lineno=lineno,
        ),
        ast.Assign(
            targets=[ast.Name(id=exit_res_var, ctx=ast.Store())],
            value=exit_exc_call,
            lineno=lineno,
        ),
        ast.If(
            test=ast.UnaryOp(
                op=ast.Not(),
                operand=ast.Name(id=exit_res_var, ctx=ast.Load()),
            ),
            body=[
                ast.Raise(exc=ast.Name(id=err_var, ctx=ast.Load()), cause=None),
            ],
            orelse=[],
        ),
    ]

    stmts.append(
        ast.Try(
            body=body,
            handlers=[
                ast.ExceptHandler(
                    type=ast.Name(id="BaseException", ctx=ast.Load()),
                    name=err_var,
                    body=handler_body,
                ),
            ],
            orelse=[],
            finalbody=[],
        )
    )

    # if not exc_flag: [await] cm.__exit__(None, None, None)
    exit_normal = _maybe_await(
        ast.Call(
            func=ast.Attribute(
                value=ast.Name(id=cm_var, ctx=ast.Load()),
                attr=exit_attr,
                ctx=ast.Load(),
            ),
            args=[
                ast.Constant(value=None),
                ast.Constant(value=None),
                ast.Constant(value=None),
            ],
            keywords=[],
        )
    )
    stmts.append(
        ast.If(
            test=ast.UnaryOp(
                op=ast.Not(),
                operand=ast.Name(id=exc_flag, ctx=ast.Load()),
            ),
            body=[ast.Expr(value=exit_normal, lineno=lineno)],
            orelse=[],
        )
    )

    for s in stmts:
        ast.fix_missing_locations(s)
    return stmts


# --- Async for ---


class ForTargetRewriter(ast.NodeTransformer):
    """Desugar non-simple for-loop targets into a temp variable + unpacking."""

    def __init__(self) -> None:
        self._counter = 0

    def visit_For(self, node: ast.For) -> ast.For:
        self.generic_visit(node)
        if isinstance(node.target, ast.Name):
            return node
        tmp = f"_for_target_{self._counter}"
        self._counter += 1
        unpack = ast.Assign(
            targets=[node.target],
            value=ast.Name(id=tmp, ctx=ast.Load()),
            lineno=getattr(node, "lineno", 0),
        )
        ast.fix_missing_locations(unpack)
        node.target = ast.Name(id=tmp, ctx=ast.Store())
        node.body = [unpack, *node.body]
        return node


class AsyncForRewriter(ast.NodeTransformer):
    """Desugar `async for` into while/try/except with explicit __anext__."""

    def __init__(self) -> None:
        self._counter = 0

    def visit_AsyncFor(self, node: ast.AsyncFor) -> list[ast.stmt]:
        self.generic_visit(node)
        aiter_var = f"_aiter_{self._counter}"
        self._counter += 1
        ln = getattr(node, "lineno", 0)

        aiter_assign = ast.Assign(
            targets=[ast.Name(id=aiter_var, ctx=ast.Store())],
            value=ast.Call(
                func=ast.Attribute(value=node.iter, attr="__aiter__", ctx=ast.Load()),
                args=[],
                keywords=[],
            ),
            lineno=ln,
        )

        anext_await = ast.Assign(
            targets=[node.target],
            value=ast.Await(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Name(id=aiter_var, ctx=ast.Load()),
                        attr="__anext__",
                        ctx=ast.Load(),
                    ),
                    args=[],
                    keywords=[],
                ),
            ),
            lineno=ln,
        )

        if node.orelse:
            done_var = f"_done_{self._counter}"
            stmts: list[ast.stmt] = [
                ast.Assign(
                    targets=[ast.Name(id=done_var, ctx=ast.Store())],
                    value=ast.Constant(value=False),
                    lineno=ln,
                ),
                aiter_assign,
            ]
            stop_handler = ast.ExceptHandler(
                type=ast.Name(id="StopAsyncIteration", ctx=ast.Load()),
                name=None,
                body=[
                    ast.Assign(
                        targets=[ast.Name(id=done_var, ctx=ast.Store())],
                        value=ast.Constant(value=True),
                        lineno=ln,
                    ),
                    ast.Continue(),
                ],
            )
            while_loop = ast.While(
                test=ast.UnaryOp(
                    op=ast.Not(),
                    operand=ast.Name(id=done_var, ctx=ast.Load()),
                ),
                body=[
                    ast.Try(
                        body=[anext_await],
                        handlers=[stop_handler],
                        orelse=[],
                        finalbody=[],
                    ),
                    *node.body,
                ],
                orelse=node.orelse,
            )
        else:
            stmts = [aiter_assign]
            stop_handler = ast.ExceptHandler(
                type=ast.Name(id="StopAsyncIteration", ctx=ast.Load()),
                name=None,
                body=[ast.Break()],
            )
            while_loop = ast.While(
                test=ast.Constant(value=True),
                body=[
                    ast.Try(
                        body=[anext_await],
                        handlers=[stop_handler],
                        orelse=[],
                        finalbody=[],
                    ),
                    *node.body,
                ],
                orelse=[],
            )

        for s in stmts:
            ast.fix_missing_locations(s)
        ast.fix_missing_locations(while_loop)
        return [*stmts, while_loop]


# --- Async with ---


def visit_stmts(
    transformer: ast.NodeTransformer, stmts: list[ast.stmt]
) -> list[ast.stmt]:
    result: list[ast.stmt] = []
    for stmt in stmts:
        visited: ast.AST | list[ast.stmt] = transformer.visit(stmt)
        if isinstance(visited, list):
            result.extend(visited)
        else:  # pragma: no cover
            result.append(visited)  # type: ignore[arg-type]
    return result


class AsyncWithRewriter(ast.NodeTransformer):
    """Desugar `async with` into explicit __aenter__/__aexit__ calls."""

    def __init__(self) -> None:
        self._counter = 0

    def visit_AsyncWith(self, node: ast.AsyncWith) -> list[ast.stmt]:
        self.generic_visit(node)

        if len(node.items) > 1:
            inner = ast.AsyncWith(items=node.items[1:], body=node.body)
            ast.copy_location(inner, node)
            node.items = [node.items[0]]
            node.body = [inner]
            node.body = visit_stmts(self, node.body)

        item = node.items[0]
        self._counter += 1
        return desugar_cm(
            context_expr=item.context_expr,
            optional_vars=item.optional_vars,
            body=node.body,
            enter_attr="__aenter__",
            exit_attr="__aexit__",
            is_async=True,
            var_prefix="_cm_",
            counter=self._counter - 1,
            lineno=getattr(node, "lineno", 0),
        )


# --- Sync with ---


class SyncWithRewriter(ast.NodeTransformer):
    """Desugar sync `with` containing awaits into __enter__/__exit__ + try."""

    def __init__(self) -> None:
        self._counter = 0

    def visit_With(self, node: ast.With) -> ast.With | list[ast.stmt]:
        self.generic_visit(node)

        if not contains_await(node):
            return node

        if len(node.items) > 1:
            inner = ast.With(items=node.items[1:], body=node.body)
            ast.copy_location(inner, node)
            node.items = [node.items[0]]
            node.body = [inner]
            node.body = visit_stmts(self, node.body)

        item = node.items[0]
        self._counter += 1
        return desugar_cm(
            context_expr=item.context_expr,
            optional_vars=item.optional_vars,
            body=node.body,
            enter_attr="__enter__",
            exit_attr="__exit__",
            is_async=False,
            var_prefix="_scm_",
            counter=self._counter - 1,
            lineno=getattr(node, "lineno", 0),
        )


# --- Raise simplifier ---


class RaiseSimplifier(ast.NodeTransformer):
    """Rewrite ``raise <expr>`` into ``tmp = <expr>; raise tmp`` inside try.

    The CFG builder only models ``raise <Name>`` as a Raise terminator with
    exception handler routing.  Complex raise expressions inside try blocks
    fall through as regular statements, escaping the state machine's
    try/except dispatch.  This pass normalizes those raises so the CFG
    builder can route them.
    """

    def __init__(self) -> None:
        self._counter = 0
        self._in_try = False

    def visit_Try(self, node: ast.Try) -> ast.Try:
        old = self._in_try
        self._in_try = True
        self.generic_visit(node)
        self._in_try = old
        return node

    def visit_Raise(self, node: ast.Raise) -> ast.Raise | list[ast.stmt]:
        if not self._in_try:
            return node
        if node.exc is None or isinstance(node.exc, ast.Name):
            return node
        tmp = f"_raise_tmp_{self._counter}"
        self._counter += 1
        ln = getattr(node, "lineno", 0)
        assign = ast.Assign(
            targets=[ast.Name(id=tmp, ctx=ast.Store())],
            value=node.exc,
            lineno=ln,
        )
        new_raise = ast.Raise(exc=ast.Name(id=tmp, ctx=ast.Load()), cause=node.cause)
        ast.copy_location(new_raise, node)
        ast.fix_missing_locations(assign)
        return [assign, new_raise]
