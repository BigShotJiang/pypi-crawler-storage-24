"""Data types for the control flow graph representation."""

import ast
from dataclasses import dataclass, field
from typing import Union


class UnsupportedAwaitPattern(Exception):
    pass


# --- Exception handler info (for codegen) ---


@dataclass
class ExceptionHandlerInfo:
    type_expr: ast.expr | None
    name: str | None
    handler_label: str
    preamble_stmts: list[ast.stmt] = field(default_factory=lambda: list[ast.stmt]())


# --- Terminators ---


@dataclass
class AwaitAndCheckpoint:
    target: str
    await_expr: ast.expr
    successor: str
    live_vars: set[str]


@dataclass
class Jump:
    target: str


@dataclass
class ConditionalJump:
    test: ast.expr
    true_label: str
    false_label: str


@dataclass
class ForIter:
    items_var: str
    idx_var: str
    loop_var: str
    body_label: str
    exit_label: str


@dataclass
class ReturnValue:
    value: ast.expr | None


@dataclass
class Raise:
    exc_var: str


@dataclass
class MatchCase:
    pattern: ast.pattern
    guard: ast.expr | None
    target_label: str


@dataclass
class MatchJump:
    subject: ast.expr
    cases: list[MatchCase]
    fallthrough_label: str


Terminator = Union[
    AwaitAndCheckpoint,
    Jump,
    ConditionalJump,
    ForIter,
    ReturnValue,
    Raise,
    MatchJump,
]


# --- Basic block and CFG ---


@dataclass
class BasicBlock:
    label: str
    stmts: list[ast.stmt] = field(default_factory=lambda: list[ast.stmt]())
    terminator: Terminator | None = None
    exception_handlers: list[ExceptionHandlerInfo] = field(
        default_factory=lambda: list[ExceptionHandlerInfo]()
    )


@dataclass
class ControlFlowGraph:
    name: str
    entry: str
    blocks: dict[str, BasicBlock]
    args: list[str]
    all_vars: set[str]
    exc_tmp_vars: set[str] = field(default_factory=set[str])


def all_param_names(args: ast.arguments) -> list[str]:
    """Collect all parameter names from an ast.arguments node."""
    names = [a.arg for a in args.posonlyargs]
    names.extend(a.arg for a in args.args)
    if args.vararg:
        names.append(args.vararg.arg)
    names.extend(a.arg for a in args.kwonlyargs)
    if args.kwarg:
        names.append(args.kwarg.arg)
    return names
