import ast
import functools
import inspect
import textwrap
from collections.abc import Callable, Coroutine
from typing import Any, Protocol, runtime_checkable

from cryosleep.analysis import CFGBuilder
from cryosleep.attempt import _current_attempt
from cryosleep.types import ControlFlowGraph, UnsupportedAwaitPattern
from cryosleep.storage import Checkpoint
from cryosleep.codegen import generate_state_machine
from cryosleep.lifting import lift_awaits


@runtime_checkable
class ResumableFunction(Protocol):
    """A function decorated with @resumable."""

    __name__: str
    __module__: str
    __qualname__: str
    __globals__: dict[str, Any]
    _transformed: Callable[..., Coroutine[Any, Any, Any]]
    __generated_source__: str
    _source_version: str
    _cfg: ControlFlowGraph

    def __call__(self, *args: Any, **kwargs: Any) -> Coroutine[Any, Any, Any]: ...


def fixup_line_numbers(module: ast.Module, func_lineno: int, line_offset: int) -> None:
    """Remap generated AST line numbers to point back to the original source."""
    for node in ast.walk(module):
        if hasattr(node, "lineno") and node.lineno == 0:
            node.lineno = func_lineno
        if hasattr(node, "end_lineno"):
            if node.end_lineno == 0 or (
                hasattr(node, "lineno") and node.end_lineno < node.lineno
            ):
                node.end_lineno = node.lineno
    ast.increment_lineno(module, line_offset)


def resumable(fn: Callable[..., Coroutine[Any, Any, Any]]) -> ResumableFunction:
    if not inspect.iscoroutinefunction(fn):
        raise TypeError(f"{fn.__name__} must be an async function")

    source = textwrap.dedent(inspect.getsource(fn))
    tree = ast.parse(source)
    func_node = tree.body[0]
    assert isinstance(func_node, ast.AsyncFunctionDef)

    source_file = inspect.getsourcefile(fn)
    _, start_line = inspect.getsourcelines(fn)
    func_lineno = func_node.lineno

    # Strip the @resumable decorator to avoid infinite recursion
    func_node.decorator_list = [
        d
        for d in func_node.decorator_list
        if not (isinstance(d, ast.Name) and d.id == "resumable")
    ]

    func_node = lift_awaits(func_node)

    builder = CFGBuilder()
    cfg = builder.build(func_node)
    module = generate_state_machine(cfg)
    generated_source = ast.unparse(module)

    fixup_line_numbers(module, func_lineno, start_line - 1)
    filename = source_file or f"<cryosleep:{fn.__name__}>"
    code = compile(module, filename, "exec")
    namespace: dict[str, Any] = {}
    exec(code, fn.__globals__, namespace)  # noqa: S102

    transformed = namespace[fn.__name__]

    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        active = _current_attempt.get()
        if active is not None:
            return await active._execute(wrapper, args, kwargs)
        return await fn(*args, **kwargs)

    wrapper._transformed = transformed  # type: ignore[attr-defined]
    wrapper.__generated_source__ = generated_source  # type: ignore[attr-defined]
    wrapper._source_version = Checkpoint.version_from_source(source)  # type: ignore[attr-defined]
    wrapper._cfg = cfg  # type: ignore[attr-defined]

    return wrapper  # type: ignore[return-value]


__all__ = ["ResumableFunction", "UnsupportedAwaitPattern", "resumable"]
