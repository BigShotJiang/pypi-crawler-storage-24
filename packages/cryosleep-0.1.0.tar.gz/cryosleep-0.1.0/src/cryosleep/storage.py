import base64
import hashlib
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

import cloudpickle


class StaleCheckpointError(Exception):
    pass


@dataclass(frozen=True)
class Checkpoint:
    function_ref: str
    block: str
    args: dict[str, Any]
    locals_snapshot: dict[str, Any]
    version: str

    @staticmethod
    def version_from_source(source: str) -> str:
        return hashlib.sha256(source.encode()).hexdigest()


@runtime_checkable
class AsyncKeyValueProtocol(Protocol):
    """Shadowing py-key-value's AsyncKeyValueProtocol so we don't need it at runtime."""

    async def get(self, key: str) -> dict[str, Any] | None: ...
    async def put(self, key: str, value: dict[str, Any]) -> None: ...
    async def delete(self, key: str) -> bool: ...


class CheckpointStore:
    """Wraps any key-value store with cloudpickle serialization for Checkpoint."""

    def __init__(self, key_value: AsyncKeyValueProtocol) -> None:
        self._kv = key_value

    async def get(self, key: str) -> Checkpoint | None:
        raw = await self._kv.get(key)
        if raw is None:
            return None
        return Checkpoint(
            function_ref=raw["function_ref"],
            block=raw["block"],
            version=raw["version"],
            args=unpickle_dict(raw["args"]),
            locals_snapshot=unpickle_dict(raw["locals_snapshot"]),
        )

    async def put(self, key: str, value: Checkpoint) -> None:
        await self._kv.put(
            key,
            {
                "function_ref": value.function_ref,
                "block": value.block,
                "version": value.version,
                "args": pickle_dict(value.args),
                "locals_snapshot": pickle_dict(value.locals_snapshot),
            },
        )

    async def delete(self, key: str) -> bool:
        return await self._kv.delete(key)


def pickle_dict(d: dict[str, Any]) -> dict[str, str]:
    return {k: base64.b64encode(cloudpickle.dumps(v)).decode() for k, v in d.items()}


def unpickle_dict(d: dict[str, Any]) -> dict[str, Any]:
    return {k: cloudpickle.loads(base64.b64decode(v)) for k, v in d.items()}
