import copy
import inspect
from contextvars import ContextVar
from typing import Any

from cryosleep.storage import Checkpoint, CheckpointStore, StaleCheckpointError

_current_attempt: ContextVar["attempt | None"] = ContextVar(
    "_current_attempt", default=None
)
_checkpoint_parent: ContextVar[str] = ContextVar("_checkpoint_parent", default="")
_call_site: ContextVar[str] = ContextVar("_call_site", default="")


class ResumeState:
    def __init__(self, block: str, locals_snapshot: dict[str, Any]) -> None:
        self.block = block
        self.locals_snapshot = locals_snapshot


class attempt:
    """Context manager that activates checkpointing for @resumable calls."""

    def __init__(self, store: CheckpointStore, *, id: str) -> None:
        self._store = store
        self._id = id

    async def __aenter__(self) -> "attempt":
        self._token = _current_attempt.set(self)
        return self

    async def __aexit__(
        self,
        _exc_type: type[BaseException] | None,
        _exc_val: BaseException | None,
        _exc_tb: Any,
    ) -> None:
        _current_attempt.reset(self._token)

    async def _execute(
        self, fn: Any, args: tuple[Any, ...], kwargs: dict[str, Any]
    ) -> Any:
        from cryosleep.transform import ResumableFunction

        assert isinstance(fn, ResumableFunction)

        parent_id = _checkpoint_parent.get()
        call_site = _call_site.get()
        if parent_id:
            my_id = f"{parent_id}/{call_site}"
        else:
            my_id = self._id

        function_ref = f"{fn.__module__}:{fn.__qualname__}"
        source_version = fn._source_version  # pyright: ignore[reportPrivateUsage]

        checkpoint = await self._store.get(my_id)

        if checkpoint is not None and checkpoint.version != source_version:
            raise StaleCheckpointError(
                f"source has changed since checkpoint "
                f"(checkpoint={checkpoint.version!r}, current={source_version!r})"
            )

        resume_state = None
        if checkpoint is not None:
            resume_state = ResumeState(
                block=checkpoint.block,
                locals_snapshot=checkpoint.locals_snapshot,
            )

        sig = inspect.signature(fn)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        bound_args = dict(bound.arguments)

        store = self._store
        checkpoint_id = my_id

        async def checkpoint_fn(*, block: str, locals_snapshot: dict[str, Any]) -> None:
            cp = Checkpoint(
                function_ref=function_ref,
                block=block,
                args=bound_args,
                locals_snapshot=copy.deepcopy(locals_snapshot),
                version=source_version,
            )
            await store.put(checkpoint_id, cp)

        parent_token = _checkpoint_parent.set(my_id)
        scope_token = _call_site.set("")

        def set_call_scope(label: str) -> None:
            _call_site.set(label)

        try:
            result = await fn._transformed(  # pyright: ignore[reportPrivateUsage]
                _resume_state=resume_state,
                _checkpoint_fn=checkpoint_fn,
                _set_call_scope=set_call_scope,
                **bound_args,
            )
        finally:
            _checkpoint_parent.reset(parent_token)
            _call_site.reset(scope_token)

        await self._store.delete(my_id)
        return result
