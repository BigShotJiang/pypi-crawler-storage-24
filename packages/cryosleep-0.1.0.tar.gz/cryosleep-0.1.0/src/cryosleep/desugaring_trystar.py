"""Desugar ``try/except*`` into ``try/except`` with manual group splitting.

Rewrites every ``ast.TryStar`` into an ``ast.Try`` that catches
``BaseException``, wraps non-group exceptions, and uses
``BaseExceptionGroup.split()`` to dispatch to each handler.
"""

import ast


class TryStarRewriter(ast.NodeTransformer):
    """Desugar all ``ast.TryStar`` nodes into plain ``ast.Try``."""

    def __init__(self) -> None:
        self._counter = 0

    def visit_TryStar(self, node: ast.TryStar) -> ast.Try:  # type: ignore[attr-defined]
        self.generic_visit(node)
        ln = getattr(node, "lineno", 0)
        idx = self._counter
        self._counter += 1

        tmp = f"__star_tmp_{idx}"
        group = f"__star_group_{idx}"
        unhandled = f"__star_unhandled_{idx}"
        raised = f"__star_raised_{idx}"

        catch_body: list[ast.stmt] = []

        # __star_group = (tmp if isinstance(tmp, BEG) else BEG('', [tmp]))
        catch_body.append(
            ast.Assign(
                targets=[name_store(group)],
                value=ast.IfExp(
                    test=ast.Call(
                        func=name_load("isinstance"),
                        args=[name_load(tmp), name_load("BaseExceptionGroup")],
                        keywords=[],
                    ),
                    body=name_load(tmp),
                    orelse=ast.Call(
                        func=name_load("BaseExceptionGroup"),
                        args=[
                            ast.Constant(value=""),
                            ast.Tuple(elts=[name_load(tmp)], ctx=ast.Load()),
                        ],
                        keywords=[],
                    ),
                ),
                lineno=ln,
            )
        )

        # __star_unhandled = __star_group
        catch_body.append(
            ast.Assign(
                targets=[name_store(unhandled)],
                value=name_load(group),
                lineno=ln,
            )
        )

        # __star_raised = []
        catch_body.append(
            ast.Assign(
                targets=[name_store(raised)],
                value=ast.List(elts=[], ctx=ast.Load()),
                lineno=ln,
            )
        )

        for h_idx, handler in enumerate(node.handlers):
            catch_body.extend(
                build_handler_block(handler, h_idx, idx, group, unhandled, raised, ln)
            )

        catch_body.extend(build_reraise(idx, tmp, unhandled, raised, ln))

        outer_handler = ast.ExceptHandler(
            type=name_load("BaseException"),
            name=tmp,
            body=catch_body,
        )

        result = ast.Try(
            body=node.body,
            handlers=[outer_handler],
            orelse=node.orelse,
            finalbody=node.finalbody,
        )
        ast.copy_location(result, node)
        ast.fix_missing_locations(result)
        return result


def name_load(name: str) -> ast.Name:
    return ast.Name(id=name, ctx=ast.Load())


def name_store(name: str) -> ast.Name:
    return ast.Name(id=name, ctx=ast.Store())


def build_handler_block(
    handler: ast.ExceptHandler,
    h_idx: int,
    star_idx: int,
    group: str,
    unhandled: str,
    raised: str,
    ln: int,
) -> list[ast.stmt]:
    """Build the split/match/dispatch block for one except* handler."""
    match = f"__star_match_{star_idx}_{h_idx}"
    herr = f"__star_herr_{star_idx}_{h_idx}"
    stmts: list[ast.stmt] = []

    # if unhandled is not None: match, unhandled = unhandled.split(ExcType)
    # else: match = None
    split_call = ast.Call(
        func=ast.Attribute(value=name_load(unhandled), attr="split", ctx=ast.Load()),
        args=[handler.type] if handler.type else [name_load("BaseException")],
        keywords=[],
    )
    stmts.append(
        ast.If(
            test=ast.Compare(
                left=name_load(unhandled),
                ops=[ast.IsNot()],
                comparators=[ast.Constant(value=None)],
            ),
            body=[
                ast.Assign(
                    targets=[
                        ast.Tuple(
                            elts=[name_store(match), name_store(unhandled)],
                            ctx=ast.Store(),
                        )
                    ],
                    value=split_call,
                    lineno=ln,
                ),
            ],
            orelse=[
                ast.Assign(
                    targets=[name_store(match)],
                    value=ast.Constant(value=None),
                    lineno=ln,
                ),
            ],
        )
    )

    # Build handler body: assign as-name, rewrite bare raises, then body
    handler_body: list[ast.stmt] = []
    if handler.name:
        handler_body.append(
            ast.Assign(
                targets=[name_store(handler.name)],
                value=name_load(match),
                lineno=ln,
            )
        )
    handler_body.extend(rewrite_bare_raises(handler.body, match))

    # Inner try wraps the handler body to catch errors (including re-raises)
    inner_except_body: list[ast.stmt] = [
        # if herr is match: merge back into unhandled (bare re-raise)
        ast.If(
            test=ast.Compare(
                left=name_load(herr),
                ops=[ast.Is()],
                comparators=[name_load(match)],
            ),
            body=[
                ast.If(
                    test=ast.Compare(
                        left=name_load(unhandled),
                        ops=[ast.Is()],
                        comparators=[ast.Constant(value=None)],
                    ),
                    body=[
                        ast.Assign(
                            targets=[name_store(unhandled)],
                            value=name_load(match),
                            lineno=ln,
                        ),
                    ],
                    orelse=[
                        ast.Assign(
                            targets=[name_store(unhandled)],
                            value=ast.Call(
                                func=ast.Attribute(
                                    value=name_load(group),
                                    attr="derive",
                                    ctx=ast.Load(),
                                ),
                                args=[
                                    ast.BinOp(
                                        left=ast.Call(
                                            func=name_load("list"),
                                            args=[
                                                ast.Attribute(
                                                    value=name_load(match),
                                                    attr="exceptions",
                                                    ctx=ast.Load(),
                                                )
                                            ],
                                            keywords=[],
                                        ),
                                        op=ast.Add(),
                                        right=ast.Call(
                                            func=name_load("list"),
                                            args=[
                                                ast.Attribute(
                                                    value=name_load(unhandled),
                                                    attr="exceptions",
                                                    ctx=ast.Load(),
                                                )
                                            ],
                                            keywords=[],
                                        ),
                                    )
                                ],
                                keywords=[],
                            ),
                            lineno=ln,
                        ),
                    ],
                ),
            ],
            orelse=[
                # handler raised something new — collect it
                ast.Expr(
                    value=ast.Call(
                        func=ast.Attribute(
                            value=name_load(raised),
                            attr="append",
                            ctx=ast.Load(),
                        ),
                        args=[name_load(herr)],
                        keywords=[],
                    )
                ),
            ],
        ),
    ]

    # if match is not None: try: <body> except herr: ...
    dispatch = ast.If(
        test=ast.Compare(
            left=name_load(match),
            ops=[ast.IsNot()],
            comparators=[ast.Constant(value=None)],
        ),
        body=[
            ast.Try(
                body=handler_body,
                handlers=[
                    ast.ExceptHandler(
                        type=name_load("BaseException"),
                        name=herr,
                        body=inner_except_body,
                    )
                ],
                orelse=[],
                finalbody=[],
            )
        ],
        orelse=[],
    )
    stmts.append(dispatch)
    return stmts


def rewrite_bare_raises(stmts: list[ast.stmt], match_var: str) -> list[ast.stmt]:
    """Rewrite bare ``raise`` into ``raise <match_var>`` in handler body.

    Since we can't rely on sys.exc_info() in the desugared form, bare raises
    inside except* handlers need to explicitly re-raise the matched sub-group.
    """
    rewriter = BareRaiseRewriter(match_var)
    return [rewriter.visit(s) for s in stmts]


class BareRaiseRewriter(ast.NodeTransformer):
    """Replace bare ``raise`` with ``raise <match_var>``."""

    def __init__(self, match_var: str) -> None:
        self._match_var = match_var

    def visit_Raise(self, node: ast.Raise) -> ast.Raise:
        if node.exc is None:
            return ast.Raise(
                exc=name_load(self._match_var),
                cause=None,
            )
        return node

    def visit_Try(self, node: ast.Try) -> ast.Try:  # pragma: no cover
        return node

    def visit_FunctionDef(
        self, node: ast.FunctionDef
    ) -> ast.FunctionDef:  # pragma: no cover
        return node

    def visit_AsyncFunctionDef(  # pragma: no cover
        self, node: ast.AsyncFunctionDef
    ) -> ast.AsyncFunctionDef:
        return node


def build_reraise(
    star_idx: int,
    tmp: str,
    unhandled: str,
    raised: str,
    ln: int,
) -> list[ast.stmt]:
    """Build the tail that re-raises unhandled + handler-raised exceptions."""
    all_var = f"__star_all_{star_idx}"
    stmts: list[ast.stmt] = []

    # __star_all = list(__star_raised)
    stmts.append(
        ast.Assign(
            targets=[name_store(all_var)],
            value=ast.Call(
                func=name_load("list"),
                args=[name_load(raised)],
                keywords=[],
            ),
            lineno=ln,
        )
    )

    # if unhandled is not None: __star_all.append(unhandled)
    stmts.append(
        ast.If(
            test=ast.Compare(
                left=name_load(unhandled),
                ops=[ast.IsNot()],
                comparators=[ast.Constant(value=None)],
            ),
            body=[
                ast.Expr(
                    value=ast.Call(
                        func=ast.Attribute(
                            value=name_load(all_var),
                            attr="append",
                            ctx=ast.Load(),
                        ),
                        args=[name_load(unhandled)],
                        keywords=[],
                    )
                )
            ],
            orelse=[],
        )
    )

    # if __star_all:
    #     if not isinstance(tmp, BEG) and not raised:
    #         raise tmp                                 # bare → re-raise bare
    #     if len(__star_all) == 1:
    #         raise __star_all[0]                       # single item → unwrap
    #     raise BaseExceptionGroup('', __star_all)      # combine
    reraise_body: list[ast.stmt] = [
        # bare exception, nothing handled → re-raise the original
        ast.If(
            test=ast.BoolOp(
                op=ast.And(),
                values=[
                    ast.UnaryOp(
                        op=ast.Not(),
                        operand=ast.Call(
                            func=name_load("isinstance"),
                            args=[
                                name_load(tmp),
                                name_load("BaseExceptionGroup"),
                            ],
                            keywords=[],
                        ),
                    ),
                    ast.UnaryOp(op=ast.Not(), operand=name_load(raised)),
                ],
            ),
            body=[ast.Raise(exc=name_load(tmp), cause=None)],
            orelse=[],
        ),
        # single item → raise directly (preserves group or bare type)
        ast.If(
            test=ast.Compare(
                left=ast.Call(
                    func=name_load("len"),
                    args=[name_load(all_var)],
                    keywords=[],
                ),
                ops=[ast.Eq()],
                comparators=[ast.Constant(value=1)],
            ),
            body=[
                ast.Raise(
                    exc=ast.Subscript(
                        value=name_load(all_var),
                        slice=ast.Constant(value=0),
                        ctx=ast.Load(),
                    ),
                    cause=None,
                ),
            ],
            orelse=[],
        ),
        # multiple items → combine into group
        ast.Raise(
            exc=ast.Call(
                func=name_load("BaseExceptionGroup"),
                args=[ast.Constant(value=""), name_load(all_var)],
                keywords=[],
            ),
            cause=None,
        ),
    ]
    stmts.append(ast.If(test=name_load(all_var), body=reraise_body, orelse=[]))

    return stmts
