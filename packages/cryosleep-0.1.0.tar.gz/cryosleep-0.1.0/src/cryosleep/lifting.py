"""Await-lifting: rewrite compound await expressions into simple assignments.

Transforms expressions like `f(await g(await h()))` into:

    _await_tmp_0 = await h()
    _await_tmp_1 = await g(_await_tmp_0)
    f(_await_tmp_1)

After this pass, every `await` appears only as the value of a simple
assignment or standalone expression — the form that `is_await_stmt` in the
CFG builder already handles.
"""

import ast

from cryosleep.desugaring import (
    AsyncForRewriter,
    AsyncWithRewriter,
    ForTargetRewriter,
    RaiseSimplifier,
    SyncWithRewriter,
    contains_await,
)
from cryosleep.desugaring_trystar import TryStarRewriter
from cryosleep.types import UnsupportedAwaitPattern


def lift_awaits(node: ast.AsyncFunctionDef) -> ast.AsyncFunctionDef:
    """Rewrite `node` so every await is in a simple statement position."""
    reject_unliftable(node)
    TryStarRewriter().visit(node)
    ForTargetRewriter().visit(node)
    AsyncForRewriter().visit(node)
    AsyncWithRewriter().visit(node)
    SyncWithRewriter().visit(node)
    RaiseSimplifier().visit(node)
    ast.fix_missing_locations(node)
    lifter = AwaitLifter()
    lifter.visit(node)
    ast.fix_missing_locations(node)
    return node


def reject_unliftable(node: ast.AsyncFunctionDef) -> None:
    """Raise on await patterns we can't safely lift."""
    for child in ast.walk(node):
        if isinstance(child, ast.GeneratorExp) and contains_await(child):
            raise UnsupportedAwaitPattern(
                "await inside a generator expression is not supported"
            )


class ExpressionAwaitExtractor(ast.NodeTransformer):
    """Walk an expression bottom-up, replacing Awaits with temp var refs."""

    def __init__(self) -> None:
        self.prefix_stmts: list[ast.stmt] = []
        self._counter = 0
        self._sc_counter = 0

    def visit_Await(self, node: ast.Await) -> ast.AST:
        # Visit children first (bottom-up)
        self.generic_visit(node)
        tmp = f"_await_tmp_{self._counter}"
        self._counter += 1
        self.prefix_stmts.append(
            ast.Assign(
                targets=[ast.Name(id=tmp, ctx=ast.Store())],
                value=node,
                lineno=getattr(node, "lineno", 0),
            )
        )
        return ast.Name(id=tmp, ctx=ast.Load())

    def visit_BoolOp(self, node: ast.BoolOp) -> ast.AST:
        if not any(contains_await(v) for v in node.values[1:]):
            return self.generic_visit(node)

        first = self.visit(node.values[0])

        sc_tmp = f"_sc_tmp_{self._sc_counter}"
        self._sc_counter += 1

        self.prefix_stmts.append(
            ast.Assign(
                targets=[ast.Name(id=sc_tmp, ctx=ast.Store())],
                value=first,
                lineno=0,
            )
        )

        is_or = isinstance(node.op, ast.Or)

        for value in node.values[1:]:
            if contains_await(value):
                inner = ExpressionAwaitExtractor()
                inner._counter = self._counter
                inner._sc_counter = self._sc_counter
                visited = inner.visit(value)
                self._counter = inner._counter
                self._sc_counter = inner._sc_counter

                body: list[ast.stmt] = [
                    *inner.prefix_stmts,
                    ast.Assign(
                        targets=[ast.Name(id=sc_tmp, ctx=ast.Store())],
                        value=visited,
                        lineno=0,
                    ),
                ]
            else:
                visited = self.visit(value)
                body = [
                    ast.Assign(
                        targets=[ast.Name(id=sc_tmp, ctx=ast.Store())],
                        value=visited,
                        lineno=0,
                    ),
                ]

            if is_or:
                test: ast.expr = ast.UnaryOp(
                    op=ast.Not(),
                    operand=ast.Name(id=sc_tmp, ctx=ast.Load()),
                )
            else:
                test = ast.Name(id=sc_tmp, ctx=ast.Load())

            self.prefix_stmts.append(ast.If(test=test, body=body, orelse=[]))

        return ast.Name(id=sc_tmp, ctx=ast.Load())

    def visit_IfExp(self, node: ast.IfExp) -> ast.AST:
        if not contains_await(node):
            return self.generic_visit(node)

        tmp = f"_ifexp_tmp_{self._counter}"
        self._counter += 1

        # Awaits in the condition always execute — extract them first
        test = self.visit(node.test)

        def _build_branch(expr: ast.expr) -> list[ast.stmt]:
            if contains_await(expr):
                inner = ExpressionAwaitExtractor()
                inner._counter = self._counter
                inner._sc_counter = self._sc_counter
                visited = inner.visit(expr)
                self._counter = inner._counter
                self._sc_counter = inner._sc_counter
                return [
                    *inner.prefix_stmts,
                    ast.Assign(
                        targets=[ast.Name(id=tmp, ctx=ast.Store())],
                        value=visited,
                        lineno=0,
                    ),
                ]
            return [
                ast.Assign(
                    targets=[ast.Name(id=tmp, ctx=ast.Store())],
                    value=expr,
                    lineno=0,
                ),
            ]

        self.prefix_stmts.append(
            ast.If(
                test=test,
                body=_build_branch(node.body),
                orelse=_build_branch(node.orelse),
            )
        )
        return ast.Name(id=tmp, ctx=ast.Load())

    def _extract_sub_expr(self, expr: ast.expr) -> tuple[ast.expr, list[ast.stmt]]:
        """Extract awaits from a sub-expression via an inner extractor."""
        if not contains_await(expr):
            return expr, []
        inner = ExpressionAwaitExtractor()
        inner._counter = self._counter
        inner._sc_counter = self._sc_counter
        visited = inner.visit(expr)
        self._counter = inner._counter
        self._sc_counter = inner._sc_counter
        return visited, inner.prefix_stmts

    def _build_comp_loops(
        self,
        generators: list[ast.comprehension],
        inner_body: list[ast.stmt],
    ) -> list[ast.stmt]:
        """Build nested for/if from comprehension generators, inside-out."""
        body = inner_body
        for gen in reversed(generators):
            for if_clause in reversed(gen.ifs):
                if contains_await(if_clause):
                    visited_test, if_prefix = self._extract_sub_expr(if_clause)
                    body = [
                        *if_prefix,
                        ast.If(test=visited_test, body=body, orelse=[]),
                    ]
                else:
                    body = [ast.If(test=if_clause, body=body, orelse=[])]

            iter_prefix: list[ast.stmt] = []
            iter_expr = gen.iter
            if contains_await(gen.iter):
                iter_expr, iter_prefix = self._extract_sub_expr(gen.iter)

            for_loop = ast.For(
                target=gen.target,
                iter=iter_expr,
                body=body,
                orelse=[],
            )
            body = [*iter_prefix, for_loop]
        return body

    def _desugar_comp(
        self,
        comp_tmp: str,
        generators: list[ast.comprehension],
        init_value: ast.expr,
        inner_body: list[ast.stmt],
    ) -> ast.Name:
        """Shared tail for visit_*Comp: init tmp, build loops, return name."""
        loops = self._build_comp_loops(generators, inner_body)
        self.prefix_stmts.append(
            ast.Assign(
                targets=[ast.Name(id=comp_tmp, ctx=ast.Store())],
                value=init_value,
                lineno=0,
            )
        )
        self.prefix_stmts.extend(loops)
        return ast.Name(id=comp_tmp, ctx=ast.Load())

    def _method_call_stmt(self, obj: str, method: str, arg: ast.expr) -> ast.Expr:
        """Build `obj.method(arg)` as a statement."""
        return ast.Expr(
            value=ast.Call(
                func=ast.Attribute(
                    value=ast.Name(id=obj, ctx=ast.Load()),
                    attr=method,
                    ctx=ast.Load(),
                ),
                args=[arg],
                keywords=[],
            )
        )

    def visit_ListComp(self, node: ast.ListComp) -> ast.AST:
        if not contains_await(node):
            return self.generic_visit(node)
        comp_tmp = f"_comp_tmp_{self._counter}"
        self._counter += 1
        elt, elt_prefix = self._extract_sub_expr(node.elt)
        append = self._method_call_stmt(comp_tmp, "append", elt)
        return self._desugar_comp(
            comp_tmp,
            node.generators,
            ast.List(elts=[], ctx=ast.Load()),
            [*elt_prefix, append],
        )

    def visit_SetComp(self, node: ast.SetComp) -> ast.AST:
        if not contains_await(node):
            return self.generic_visit(node)
        comp_tmp = f"_comp_tmp_{self._counter}"
        self._counter += 1
        elt, elt_prefix = self._extract_sub_expr(node.elt)
        add = self._method_call_stmt(comp_tmp, "add", elt)
        return self._desugar_comp(
            comp_tmp,
            node.generators,
            ast.Call(
                func=ast.Name(id="set", ctx=ast.Load()),
                args=[],
                keywords=[],
            ),
            [*elt_prefix, add],
        )

    def visit_DictComp(self, node: ast.DictComp) -> ast.AST:
        if not contains_await(node):
            return self.generic_visit(node)
        comp_tmp = f"_comp_tmp_{self._counter}"
        self._counter += 1
        key, key_prefix = self._extract_sub_expr(node.key)
        value, value_prefix = self._extract_sub_expr(node.value)
        assign = ast.Assign(
            targets=[
                ast.Subscript(
                    value=ast.Name(id=comp_tmp, ctx=ast.Load()),
                    slice=key,
                    ctx=ast.Store(),
                )
            ],
            value=value,
            lineno=0,
        )
        return self._desugar_comp(
            comp_tmp,
            node.generators,
            ast.Dict(keys=[], values=[]),
            [*key_prefix, *value_prefix, assign],
        )


def is_simple_await_stmt(stmt: ast.stmt) -> bool:
    """True if stmt is already an await in simple position."""
    if isinstance(stmt, ast.Assign) and isinstance(stmt.value, ast.Await):
        if len(stmt.targets) != 1 or not isinstance(stmt.targets[0], ast.Name):
            return False
        return not contains_await(stmt.value.value)
    if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.value, ast.Await):
        if not isinstance(stmt.target, ast.Name):  # pragma: no cover
            return False
        return not contains_await(stmt.value.value)
    if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Await):
        return not contains_await(stmt.value.value)
    return False


def needs_lifting(stmt: ast.stmt) -> bool:
    """True if stmt contains awaits that aren't in simple position."""
    if is_simple_await_stmt(stmt):
        return False
    return contains_await(stmt)


def lift_stmt(stmt: ast.stmt) -> list[ast.stmt]:
    """Expand a single statement into prefix assignments + rewritten stmt."""
    if not needs_lifting(stmt):
        return [stmt]

    if isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Await):
        # return await f() — just the top-level await, no nesting
        if not contains_await(stmt.value.value):
            extractor = ExpressionAwaitExtractor()
            new_val = extractor.visit(stmt.value)
            stmt.value = new_val
            return [*extractor.prefix_stmts, stmt]

    if isinstance(stmt, ast.Return) and stmt.value is not None:
        extractor = ExpressionAwaitExtractor()
        stmt.value = extractor.visit(stmt.value)
        return [*extractor.prefix_stmts, stmt]

    if isinstance(stmt, ast.AugAssign):
        extractor = ExpressionAwaitExtractor()
        stmt.value = extractor.visit(stmt.value)
        return [*extractor.prefix_stmts, stmt]

    if isinstance(stmt, ast.Assign):
        extractor = ExpressionAwaitExtractor()
        stmt.value = extractor.visit(stmt.value)
        return [*extractor.prefix_stmts, stmt]

    if isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
        extractor = ExpressionAwaitExtractor()
        stmt.value = extractor.visit(stmt.value)
        return [*extractor.prefix_stmts, stmt]

    if isinstance(stmt, ast.Expr):
        extractor = ExpressionAwaitExtractor()
        stmt.value = extractor.visit(stmt.value)
        return [*extractor.prefix_stmts, stmt]

    if isinstance(stmt, ast.Raise) and stmt.exc is not None:
        extractor = ExpressionAwaitExtractor()
        stmt.exc = extractor.visit(stmt.exc)
        if stmt.cause is not None:
            stmt.cause = extractor.visit(stmt.cause)
        return [*extractor.prefix_stmts, stmt]

    if isinstance(stmt, ast.Assert):
        extractor = ExpressionAwaitExtractor()
        stmt.test = extractor.visit(stmt.test)
        if stmt.msg is not None:
            stmt.msg = extractor.visit(stmt.msg)
        return [*extractor.prefix_stmts, stmt]

    if isinstance(stmt, ast.Delete):
        extractor = ExpressionAwaitExtractor()
        stmt.targets = [extractor.visit(t) for t in stmt.targets]
        return [*extractor.prefix_stmts, stmt]

    return [stmt]


class AwaitLifter(ast.NodeTransformer):
    """Statement-level transformer that expands compound awaits."""

    def __init__(self) -> None:
        self._while_counter = 0

    def _expand_body(self, stmts: list[ast.stmt]) -> list[ast.stmt]:
        result: list[ast.stmt] = []
        for stmt in stmts:
            visited: ast.AST | list[ast.stmt] = self.visit(stmt)
            if isinstance(visited, list):
                for s in visited[:-1]:
                    result.extend(lift_stmt(s))
                result.extend(lift_stmt(visited[-1]))
            else:
                assert isinstance(visited, ast.stmt)
                result.extend(lift_stmt(visited))
        return result

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> ast.AST:
        node.body = self._expand_body(node.body)
        return node

    def visit_If(self, node: ast.If) -> ast.If | list[ast.stmt]:
        node.body = self._expand_body(node.body)
        node.orelse = self._expand_body(node.orelse)
        if contains_await(node.test):
            extractor = ExpressionAwaitExtractor()
            node.test = extractor.visit(node.test)
            return [*extractor.prefix_stmts, node]
        return node

    def visit_For(self, node: ast.For) -> ast.For | list[ast.stmt]:
        node.body = self._expand_body(node.body)
        node.orelse = self._expand_body(node.orelse)
        if contains_await(node.iter):
            extractor = ExpressionAwaitExtractor()
            node.iter = extractor.visit(node.iter)
            return [*extractor.prefix_stmts, node]
        return node

    def visit_While(self, node: ast.While) -> ast.While | list[ast.stmt]:
        node.body = self._expand_body(node.body)
        node.orelse = self._expand_body(node.orelse)
        if not contains_await(node.test):
            return node
        extractor = ExpressionAwaitExtractor()
        new_test = extractor.visit(node.test)
        if node.orelse:
            # Use a done flag so the else clause still fires on normal exit
            done_var = f"_done_{self._while_counter}"
            self._while_counter += 1
            guard_if = ast.If(
                test=ast.UnaryOp(op=ast.Not(), operand=new_test),
                body=[
                    ast.Assign(
                        targets=[ast.Name(id=done_var, ctx=ast.Store())],
                        value=ast.Constant(value=True),
                        lineno=0,
                    ),
                    ast.Continue(),
                ],
                orelse=[],
            )
            node.body = [*extractor.prefix_stmts, guard_if, *node.body]
            node.test = ast.UnaryOp(
                op=ast.Not(),
                operand=ast.Name(id=done_var, ctx=ast.Load()),
            )
            init = ast.Assign(
                targets=[ast.Name(id=done_var, ctx=ast.Store())],
                value=ast.Constant(value=False),
                lineno=0,
            )
            return [init, node]
        else:
            guard_if = ast.If(
                test=ast.UnaryOp(op=ast.Not(), operand=new_test),
                body=[ast.Break()],
                orelse=[],
            )
            node.body = [*extractor.prefix_stmts, guard_if, *node.body]
            node.test = ast.Constant(value=True)
            return node

    def visit_Try(self, node: ast.Try) -> ast.AST:
        node.body = self._expand_body(node.body)
        for handler in node.handlers:
            handler.body = self._expand_body(handler.body)
        node.orelse = self._expand_body(node.orelse)
        node.finalbody = self._expand_body(node.finalbody)
        return node

    def visit_With(self, node: ast.With) -> ast.AST:
        node.body = self._expand_body(node.body)
        return node

    def visit_Match(self, node: ast.Match) -> ast.AST:
        for case in node.cases:
            case.body = self._expand_body(case.body)
        return node
