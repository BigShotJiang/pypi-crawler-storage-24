import ast
from typing import Any

from cryosleep.types import (
    AwaitAndCheckpoint,
    BasicBlock,
    ConditionalJump,
    ControlFlowGraph,
    ForIter,
    Jump,
    MatchJump,
    Raise,
    ReturnValue,
)


def generate_state_machine(cfg: ControlFlowGraph) -> ast.Module:
    body: list[ast.stmt] = []

    # _block = _resume_state.block if _resume_state else "entry_0"
    body.append(
        assign(
            "_block",
            ifexp(
                name("_resume_state"),
                attr("_resume_state", "block"),
                const(cfg.entry),
            ),
        )
    )

    # _locals = _resume_state.locals_snapshot if _resume_state else {}
    body.append(
        assign(
            "_locals",
            ifexp(
                name("_resume_state"),
                attr("_resume_state", "locals_snapshot"),
                ast.Dict(keys=[], values=[]),
            ),
        )
    )

    # Restore args from _locals with param defaults
    for arg in cfg.args:
        body.append(
            assign(
                arg,
                call(
                    attr("_locals", "get"),
                    [const(arg), name(arg)],
                ),
            )
        )

    # Restore non-arg variables from _locals with None defaults
    for var in sorted(cfg.all_vars - set(cfg.args)):
        body.append(
            assign(
                var,
                call(
                    attr("_locals", "get"),
                    [const(var), const(None)],
                ),
            )
        )

    # Build match cases
    cases: list[ast.match_case] = []
    for label in ordered_labels(cfg):
        block = cfg.blocks[label]
        case_body = emit_block(block)
        cases.append(
            ast.match_case(
                pattern=ast.MatchValue(value=const(label)),
                guard=None,
                body=case_body,
            )
        )

    match_stmt = ast.Match(subject=name("_block"), cases=cases)
    body.append(ast.While(test=const(True), body=[match_stmt], orelse=[]))

    # Build async function
    params = [ast.arg(arg=a) for a in cfg.args]
    params.extend(
        [
            ast.arg(arg="_resume_state"),
            ast.arg(arg="_checkpoint_fn"),
            ast.arg(arg="_set_call_scope"),
        ]
    )

    func = ast.AsyncFunctionDef(
        name=cfg.name,
        args=ast.arguments(
            posonlyargs=[],
            args=params,
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[const(None)] * (len(cfg.args) + 3),
        ),
        body=body,
        decorator_list=[],
        returns=None,
        type_params=[],
    )

    module = ast.Module(body=[func], type_ignores=[])
    ast.fix_missing_locations(module)
    return module


def emit_block(block: BasicBlock) -> list[ast.stmt]:
    body: list[ast.stmt] = list(block.stmts)
    term = block.terminator

    if isinstance(term, Jump):
        body.append(assign("_block", const(term.target)))
        body.append(ast.Continue())

    elif isinstance(term, ConditionalJump):
        body.append(
            ast.If(
                test=term.test,
                body=[assign("_block", const(term.true_label))],
                orelse=[assign("_block", const(term.false_label))],
            )
        )
        body.append(ast.Continue())

    elif isinstance(term, ForIter):
        body.append(
            ast.If(
                test=ast.Compare(
                    left=name(term.idx_var),
                    ops=[ast.Lt()],
                    comparators=[call(name("len"), [name(term.items_var)])],
                ),
                body=[
                    assign(
                        term.loop_var,
                        ast.Subscript(
                            value=name(term.items_var),
                            slice=name(term.idx_var),
                            ctx=ast.Load(),
                        ),
                    ),
                    assign("_block", const(term.body_label)),
                ],
                orelse=[
                    assign("_block", const(term.exit_label)),
                ],
            )
        )
        body.append(ast.Continue())

    elif isinstance(term, AwaitAndCheckpoint):
        await_stmts = emit_await_and_checkpoint(term, block.label)

        if block.exception_handlers:
            except_clauses: list[ast.ExceptHandler] = []
            for handler_info in block.exception_handlers:
                handler_body: list[ast.stmt] = list(handler_info.preamble_stmts)
                handler_body.extend(
                    [
                        assign("_block", const(handler_info.handler_label)),
                        ast.Continue(),
                    ]
                )
                except_clauses.append(
                    ast.ExceptHandler(
                        type=handler_info.type_expr,
                        name=handler_info.name,
                        body=handler_body,
                    )
                )
            body.append(
                ast.Try(
                    body=await_stmts,
                    handlers=except_clauses,
                    orelse=[],
                    finalbody=[],
                )
            )
        else:
            body.extend(await_stmts)

    elif isinstance(term, MatchJump):
        match_cases: list[ast.match_case] = []
        has_wildcard = False
        for mc in term.cases:
            if (
                isinstance(mc.pattern, ast.MatchAs)
                and mc.pattern.name is None
                and mc.guard is None
            ):
                has_wildcard = True
            match_cases.append(
                ast.match_case(
                    pattern=mc.pattern,
                    guard=mc.guard,
                    body=[assign("_block", const(mc.target_label))],
                )
            )
        if not has_wildcard:
            match_cases.append(
                ast.match_case(
                    pattern=ast.MatchAs(pattern=None, name=None),
                    guard=None,
                    body=[assign("_block", const(term.fallthrough_label))],
                )
            )
        body.append(ast.Match(subject=term.subject, cases=match_cases))
        body.append(ast.Continue())

    elif isinstance(term, Raise):
        raise_stmt = ast.Raise(
            exc=ast.Name(id=term.exc_var, ctx=ast.Load()),
            cause=None,
        )
        if block.exception_handlers:
            except_clauses: list[ast.ExceptHandler] = []
            for handler_info in block.exception_handlers:
                handler_body: list[ast.stmt] = list(handler_info.preamble_stmts)
                handler_body.extend(
                    [
                        assign("_block", const(handler_info.handler_label)),
                        ast.Continue(),
                    ]
                )
                except_clauses.append(
                    ast.ExceptHandler(
                        type=handler_info.type_expr,
                        name=handler_info.name,
                        body=handler_body,
                    )
                )
            body.append(
                ast.Try(
                    body=[raise_stmt],
                    handlers=except_clauses,
                    orelse=[],
                    finalbody=[],
                )
            )
        else:
            body.append(raise_stmt)

    elif isinstance(term, ReturnValue):  # pragma: no branch
        body.append(ast.Return(value=term.value))

    if not body:  # pragma: no cover
        body.append(ast.Pass())

    return body


def emit_await_and_checkpoint(
    term: AwaitAndCheckpoint, block_label: str
) -> list[ast.stmt]:
    stmts: list[ast.stmt] = []

    stmts.append(
        ast.Expr(
            value=call(name("_set_call_scope"), [const(block_label)]),
        )
    )

    stmts.append(
        ast.Assign(
            targets=[name_store(term.target)],
            value=ast.Await(value=term.await_expr),
            lineno=getattr(term.await_expr, "lineno", 0),
        )
    )

    snapshot_dict = ast.Dict(
        keys=[const(v) for v in sorted(term.live_vars)],
        values=[name(v) for v in sorted(term.live_vars)],
    )
    stmts.append(
        ast.Expr(
            value=ast.Await(
                value=call(
                    name("_checkpoint_fn"),
                    [],
                    [
                        ast.keyword(arg="block", value=const(term.successor)),
                        ast.keyword(arg="locals_snapshot", value=snapshot_dict),
                    ],
                )
            )
        )
    )

    stmts.append(assign("_block", const(term.successor)))
    stmts.append(ast.Continue())

    return stmts


def ordered_labels(cfg: ControlFlowGraph) -> list[str]:
    labels = list(cfg.blocks.keys())

    def sort_key(label: str) -> int:
        parts = label.rsplit("_", 1)
        if len(parts) == 2 and parts[1].isdigit():
            return int(parts[1])
        return 999

    return sorted(labels, key=sort_key)


# --- AST helper constructors ---


def name(id: str) -> ast.Name:
    return ast.Name(id=id, ctx=ast.Load())


def name_store(id: str) -> ast.Name:
    return ast.Name(id=id, ctx=ast.Store())


def const(value: Any) -> ast.Constant:
    return ast.Constant(value=value)


def attr(value: str, attr: str) -> ast.Attribute:
    return ast.Attribute(value=name(value), attr=attr, ctx=ast.Load())


def assign(target: str, value: ast.expr) -> ast.Assign:
    return ast.Assign(targets=[name_store(target)], value=value, lineno=0)


def call(
    func: ast.expr,
    args: list[ast.expr] | None = None,
    keywords: list[ast.keyword] | None = None,
) -> ast.Call:
    return ast.Call(func=func, args=args or [], keywords=keywords or [])


def ifexp(test: ast.expr, body: ast.expr, orelse: ast.expr) -> ast.IfExp:
    return ast.IfExp(test=test, body=body, orelse=orelse)
