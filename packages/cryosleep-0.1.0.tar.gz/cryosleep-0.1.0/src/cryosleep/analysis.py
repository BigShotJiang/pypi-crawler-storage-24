"""CFG builder: decompose async functions into basic blocks."""

import ast

from cryosleep.types import (
    AwaitAndCheckpoint,
    BasicBlock,
    ConditionalJump,
    ControlFlowGraph,
    ExceptionHandlerInfo,
    ForIter,
    Jump,
    MatchCase,
    MatchJump,
    Raise,
    ReturnValue,
    UnsupportedAwaitPattern,
    all_param_names,
)


def is_await_stmt(stmt: ast.stmt) -> bool:
    if isinstance(stmt, (ast.Assign, ast.AnnAssign)):
        return isinstance(stmt.value, ast.Await)
    return isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Await)


class CFGBuilder:
    def __init__(self) -> None:
        self._blocks: dict[str, BasicBlock] = {}
        self._counter: int = 0
        self._assigned_vars: set[str] = set()
        self._exc_tmp_vars: set[str] = set()
        self._loop_stack: list[tuple[str, str]] = []
        self._try_stack: list[list[ExceptionHandlerInfo]] = []

    def build(self, node: ast.AsyncFunctionDef) -> ControlFlowGraph:
        args = all_param_names(node.args)
        self._assigned_vars = set(args)

        entry = self._fresh("entry")
        exit_label = self._fresh("exit")
        self._blocks[exit_label] = BasicBlock(
            label=exit_label, terminator=ReturnValue(value=None)
        )

        self._process_stmts(node.body, entry, exit_label)

        return ControlFlowGraph(
            name=node.name,
            entry=entry,
            blocks=self._blocks,
            args=args,
            all_vars=set(self._assigned_vars),
            exc_tmp_vars=set(self._exc_tmp_vars),
        )

    def _fresh(self, prefix: str) -> str:
        label = f"{prefix}_{self._counter}"
        self._counter += 1
        block = BasicBlock(label=label)
        self._blocks[label] = block
        return label

    def _process_stmts(
        self,
        stmts: list[ast.stmt],
        current_label: str,
        successor_label: str,
    ) -> None:
        block = self._blocks[current_label]

        for i, stmt in enumerate(stmts):
            if isinstance(stmt, ast.Return):
                block.terminator = ReturnValue(value=stmt.value)
                return

            if is_await_stmt(stmt):
                target, await_expr = self._extract_await(stmt)
                self._assigned_vars.add(target)

                remaining = stmts[i + 1 :]
                cont_label = (
                    self._fresh("after_await") if remaining else successor_label
                )

                block.terminator = AwaitAndCheckpoint(
                    target=target,
                    await_expr=await_expr,
                    successor=cont_label,
                    live_vars=self._assigned_vars - self._exc_tmp_vars,
                )
                if self._try_stack:
                    block.exception_handlers = list(self._try_stack[-1])

                if remaining:
                    self._process_stmts(remaining, cont_label, successor_label)
                return

            if isinstance(stmt, ast.If):
                self._process_if(stmt, stmts[i + 1 :], current_label, successor_label)
                return

            if isinstance(stmt, ast.For):
                self._process_for(stmt, stmts[i + 1 :], current_label, successor_label)
                return

            if isinstance(stmt, ast.While):
                self._process_while(
                    stmt, stmts[i + 1 :], current_label, successor_label
                )
                return

            if isinstance(stmt, ast.Try):
                self._process_try(stmt, stmts[i + 1 :], current_label, successor_label)
                return

            if isinstance(stmt, ast.Match):
                self._process_match(
                    stmt, stmts[i + 1 :], current_label, successor_label
                )
                return

            if isinstance(stmt, (ast.Break, ast.Continue)):
                self._process_break_continue(stmt, block)
                return

            if isinstance(stmt, ast.Raise) and stmt.exc is not None:
                if isinstance(stmt.exc, ast.Name):
                    block.terminator = Raise(exc_var=stmt.exc.id)
                    if self._try_stack:
                        block.exception_handlers = list(self._try_stack[-1])
                    return

            self._track_assignments(stmt)
            block.stmts.append(stmt)

        if block.terminator is None:  # pragma: no branch
            block.terminator = Jump(target=successor_label)

    def _process_if(
        self,
        node: ast.If,
        remaining: list[ast.stmt],
        current_label: str,
        successor_label: str,
    ) -> None:
        block = self._blocks[current_label]
        join_label = self._fresh("if_join") if remaining else successor_label

        true_label = self._fresh("if_true")
        false_label = self._fresh("if_false") if node.orelse else join_label

        block.terminator = ConditionalJump(
            test=node.test,
            true_label=true_label,
            false_label=false_label,
        )

        self._process_stmts(node.body, true_label, join_label)
        if node.orelse:
            self._process_stmts(node.orelse, false_label, join_label)

        if remaining:
            self._process_stmts(remaining, join_label, successor_label)

    def _process_for(
        self,
        node: ast.For,
        remaining: list[ast.stmt],
        current_label: str,
        successor_label: str,
    ) -> None:
        block = self._blocks[current_label]

        if not isinstance(node.target, ast.Name):
            raise UnsupportedAwaitPattern("for-loop target must be a simple variable")

        after_label = self._fresh("for_after") if remaining else successor_label
        else_label = self._fresh("for_else") if node.orelse else after_label

        items_var = f"_items_{self._counter}"
        idx_var = f"_idx_{self._counter}"
        self._assigned_vars.update([items_var, idx_var, node.target.id])

        test_label = self._fresh("for_test")
        body_label = self._fresh("for_body")
        continue_label = self._fresh("for_continue")

        block.stmts.append(
            ast.Assign(
                targets=[ast.Name(id=items_var, ctx=ast.Store())],
                value=ast.Call(
                    func=ast.Name(id="list", ctx=ast.Load()),
                    args=[node.iter],
                    keywords=[],
                ),
                lineno=0,
            )
        )
        block.stmts.append(
            ast.Assign(
                targets=[ast.Name(id=idx_var, ctx=ast.Store())],
                value=ast.Constant(value=0),
                lineno=0,
            )
        )
        block.terminator = Jump(target=test_label)

        self._blocks[test_label].terminator = ForIter(
            items_var=items_var,
            idx_var=idx_var,
            loop_var=node.target.id,
            body_label=body_label,
            exit_label=else_label,
        )

        self._loop_stack.append((continue_label, after_label))
        self._process_stmts(node.body, body_label, continue_label)
        self._loop_stack.pop()

        cont_block = self._blocks[continue_label]
        cont_block.stmts.append(
            ast.AugAssign(
                target=ast.Name(id=idx_var, ctx=ast.Store()),
                op=ast.Add(),
                value=ast.Constant(value=1),
            )
        )
        cont_block.terminator = Jump(target=test_label)

        if node.orelse:
            self._process_stmts(node.orelse, else_label, after_label)

        if remaining:
            self._process_stmts(remaining, after_label, successor_label)

    def _process_while(
        self,
        node: ast.While,
        remaining: list[ast.stmt],
        current_label: str,
        successor_label: str,
    ) -> None:
        block = self._blocks[current_label]
        after_label = self._fresh("while_after") if remaining else successor_label
        else_label = self._fresh("while_else") if node.orelse else after_label

        test_label = self._fresh("while_test")
        body_label = self._fresh("while_body")

        block.terminator = Jump(target=test_label)

        self._blocks[test_label].terminator = ConditionalJump(
            test=node.test,
            true_label=body_label,
            false_label=else_label,
        )

        self._loop_stack.append((test_label, after_label))
        self._process_stmts(node.body, body_label, test_label)
        self._loop_stack.pop()

        if node.orelse:
            self._process_stmts(node.orelse, else_label, after_label)

        if remaining:
            self._process_stmts(remaining, after_label, successor_label)

    def _process_try(
        self,
        node: ast.Try,
        remaining: list[ast.stmt],
        current_label: str,
        successor_label: str,
    ) -> None:
        block = self._blocks[current_label]
        if node.finalbody:
            self._process_try_finally(node, remaining, block, successor_label)
            return

        # try/except (no finally)
        join_label = self._fresh("try_join") if remaining else successor_label
        else_label = self._fresh("try_else") if node.orelse else join_label

        handler_infos = self._build_handler_infos(node.handlers)

        try_body_label = self._fresh("try_body")
        block.terminator = Jump(target=try_body_label)

        self._try_stack.append(handler_infos)
        self._process_stmts(node.body, try_body_label, else_label)
        self._try_stack.pop()

        if node.orelse:
            self._process_stmts(node.orelse, else_label, join_label)

        for handler, info in zip(node.handlers, handler_infos):
            self._process_stmts(handler.body, info.handler_label, join_label)

        if remaining:
            self._process_stmts(remaining, join_label, successor_label)

    def _process_try_finally(
        self,
        node: ast.Try,
        remaining: list[ast.stmt],
        block: BasicBlock,
        successor_label: str,
    ) -> None:
        join_label = self._fresh("try_join") if remaining else successor_label

        exc_var = f"_exc_{self._counter}"
        self._assigned_vars.add(exc_var)

        finally_normal = self._fresh("finally_normal")
        finally_catch = self._fresh("finally_catch")
        finally_body = self._fresh("finally_body")
        finally_exit = self._fresh("finally_exit")
        finally_reraise = self._fresh("finally_reraise")

        exc_tmp_var = f"_exc_tmp_{self._counter}"
        catchall_info = ExceptionHandlerInfo(
            type_expr=ast.Name(id="BaseException", ctx=ast.Load()),
            name=exc_tmp_var,
            handler_label=finally_catch,
            preamble_stmts=[
                ast.Assign(
                    targets=[ast.Name(id=exc_var, ctx=ast.Store())],
                    value=ast.Name(id=exc_tmp_var, ctx=ast.Load()),
                    lineno=0,
                ),
            ],
        )

        except_handler_infos = self._build_handler_infos(node.handlers)
        full_handlers = except_handler_infos + [catchall_info]

        try_body_label = self._fresh("try_body")
        block.terminator = Jump(target=try_body_label)

        else_label = self._fresh("try_else") if node.orelse else finally_normal

        self._try_stack.append(full_handlers)
        self._process_stmts(node.body, try_body_label, else_label)
        self._try_stack.pop()

        if node.orelse:
            self._try_stack.append([catchall_info])
            self._process_stmts(node.orelse, else_label, finally_normal)
            self._try_stack.pop()

        self._try_stack.append([catchall_info])
        for handler, info in zip(node.handlers, except_handler_infos):
            self._process_stmts(handler.body, info.handler_label, finally_normal)
        self._try_stack.pop()

        normal_block = self._blocks[finally_normal]
        normal_block.stmts.append(
            ast.Assign(
                targets=[ast.Name(id=exc_var, ctx=ast.Store())],
                value=ast.Constant(value=None),
                lineno=0,
            )
        )
        normal_block.terminator = Jump(target=finally_body)

        catch_block = self._blocks[finally_catch]
        catch_block.terminator = Jump(target=finally_body)

        self._process_stmts(node.finalbody, finally_body, finally_exit)

        exit_block = self._blocks[finally_exit]
        exit_block.terminator = ConditionalJump(
            test=ast.Compare(
                left=ast.Name(id=exc_var, ctx=ast.Load()),
                ops=[ast.IsNot()],
                comparators=[ast.Constant(value=None)],
            ),
            true_label=finally_reraise,
            false_label=join_label,
        )

        reraise_block = self._blocks[finally_reraise]
        reraise_block.terminator = Raise(exc_var=exc_var)

        if remaining:
            self._process_stmts(remaining, join_label, successor_label)

    def _build_handler_infos(
        self,
        handlers: list[ast.ExceptHandler],
    ) -> list[ExceptionHandlerInfo]:
        infos: list[ExceptionHandlerInfo] = []
        for h in handlers:
            label = self._fresh("except")
            if not h.name:
                infos.append(
                    ExceptionHandlerInfo(
                        type_expr=h.type, name=h.name, handler_label=label
                    )
                )
                continue
            self._assigned_vars.add(h.name)
            tmp = f"_exc_tmp_{self._counter}"
            self._assigned_vars.add(tmp)
            self._exc_tmp_vars.add(tmp)
            preamble: list[ast.stmt] = [
                ast.Assign(
                    targets=[ast.Name(id=h.name, ctx=ast.Store())],
                    value=ast.Name(id=tmp, ctx=ast.Load()),
                    lineno=0,
                )
            ]
            infos.append(
                ExceptionHandlerInfo(
                    type_expr=h.type,
                    name=tmp,
                    handler_label=label,
                    preamble_stmts=preamble,
                )
            )
        return infos

    def _process_match(
        self,
        node: ast.Match,
        remaining: list[ast.stmt],
        current_label: str,
        successor_label: str,
    ) -> None:
        block = self._blocks[current_label]
        join_label = self._fresh("match_join") if remaining else successor_label

        has_wildcard = any(
            isinstance(c.pattern, ast.MatchAs) and c.pattern.name is None
            for c in node.cases
        )
        cases: list[MatchCase] = []
        for case in node.cases:
            case_label = self._fresh("match_case")
            self._track_pattern_vars(case.pattern)
            cases.append(
                MatchCase(
                    pattern=case.pattern, guard=case.guard, target_label=case_label
                )
            )
            self._process_stmts(case.body, case_label, join_label)
        fallthrough = join_label if has_wildcard else self._fresh("match_fall")
        if fallthrough != join_label:
            self._blocks[fallthrough].terminator = Jump(target=join_label)
        block.terminator = MatchJump(
            subject=node.subject, cases=cases, fallthrough_label=fallthrough
        )
        if remaining:
            self._process_stmts(remaining, join_label, successor_label)

    def _track_pattern_vars(self, pattern: ast.pattern) -> None:
        for node in ast.walk(pattern):
            if isinstance(node, (ast.MatchAs, ast.MatchStar)):
                if node.name is not None:
                    self._assigned_vars.add(node.name)
            elif isinstance(node, ast.MatchMapping) and node.rest is not None:
                self._assigned_vars.add(node.rest)

    def _process_break_continue(self, stmt: ast.stmt, block: BasicBlock) -> None:
        if not self._loop_stack:
            raise UnsupportedAwaitPattern("break/continue outside loop")

        continue_label, break_label = self._loop_stack[-1]
        if isinstance(stmt, ast.Continue):
            block.terminator = Jump(target=continue_label)
        else:
            block.terminator = Jump(target=break_label)

    def _extract_await(self, stmt: ast.stmt) -> tuple[str, ast.expr]:
        if isinstance(stmt, ast.Assign) and isinstance(stmt.value, ast.Await):
            target = stmt.targets[0]
            if isinstance(target, ast.Name):
                return target.id, stmt.value.value
            raise UnsupportedAwaitPattern("await must be assigned to a simple variable")
        if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.value, ast.Await):
            if isinstance(stmt.target, ast.Name):
                return stmt.target.id, stmt.value.value
            raise UnsupportedAwaitPattern("await must be assigned to a simple variable")
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Await):
            discard_var = f"_discard_{self._counter}"
            self._assigned_vars.add(discard_var)
            return discard_var, stmt.value.value
        raise UnsupportedAwaitPattern(
            "await must be assigned to a simple variable"
        )  # pragma: no cover

    def _track_assignments(self, stmt: ast.stmt) -> None:
        for child in ast.walk(stmt):
            if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                self._assigned_vars.add(child.id)
