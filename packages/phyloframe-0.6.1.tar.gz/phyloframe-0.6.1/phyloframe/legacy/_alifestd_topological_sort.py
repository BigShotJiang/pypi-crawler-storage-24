import argparse
from collections import Counter
import logging
import os

import joinem
from joinem._dataframe_cli import _add_parser_base, _run_dataframe_cli
import numpy as np
import pandas as pd

from .._auxlib._begin_prod_logging import begin_prod_logging
from .._auxlib._delegate_polars_implementation import (
    delegate_polars_implementation,
)
from .._auxlib._format_cli_description import format_cli_description
from .._auxlib._get_phyloframe_version import get_phyloframe_version
from .._auxlib._jit import jit
from .._auxlib._log_context_duration import log_context_duration
from ._alifestd_has_contiguous_ids import alifestd_has_contiguous_ids
from ._alifestd_parse_ancestor_ids import alifestd_parse_ancestor_ids
from ._alifestd_try_add_ancestor_id_col import alifestd_try_add_ancestor_id_col
from ._alifestd_try_add_ancestor_list_col import (
    alifestd_try_add_ancestor_list_col,
)


@jit(nopython=True)
def _topological_sort_fast_path(ancestor_ids: np.ndarray) -> np.ndarray:
    """Topological sort for contiguous ids using Kahn's algorithm."""
    n = len(ancestor_ids)
    # Count children for each node
    num_children = np.zeros(n, dtype=np.int64)
    for i, ancestor_id in enumerate(ancestor_ids):
        if ancestor_id != i:
            num_children[ancestor_id] += 1

    # Initialize queue with leaves (nodes with no children)
    queue = np.empty(n, dtype=np.int64)
    head = 0
    tail = 0
    for i, nc in enumerate(num_children):
        if nc == 0:
            queue[tail] = i
            tail += 1

    # Process queue in reverse (leaves first)
    result = np.empty(n, dtype=np.int64)
    pos = n - 1
    while head < tail:
        node = queue[head]
        head += 1
        result[pos] = node
        pos -= 1
        ancestor = ancestor_ids[node]
        if ancestor != node:
            num_children[ancestor] -= 1
            if num_children[ancestor] == 0:
                queue[tail] = ancestor
                tail += 1

    return result


def alifestd_topological_sort(
    phylogeny_df: pd.DataFrame,
    mutate: bool = False,
) -> pd.DataFrame:
    """Sort rows so all organisms follow members of their `ancestor_list`.

    Input dataframe is not mutated by this operation unless `mutate` set True.
    If mutate set True, operation does not occur in place; still use return
    value to get transformed phylogeny dataframe.
    """

    if not mutate:
        phylogeny_df = phylogeny_df.copy()

    # Fast path for contiguous ids with ancestor_id
    phylogeny_df = alifestd_try_add_ancestor_id_col(
        phylogeny_df,
        mutate=True,
    )
    if "ancestor_id" in phylogeny_df and alifestd_has_contiguous_ids(
        phylogeny_df
    ):
        ancestor_ids = phylogeny_df["ancestor_id"].to_numpy()
        order = _topological_sort_fast_path(ancestor_ids)
        return phylogeny_df.iloc[order].reset_index(drop=True)

    has_ancestor_list = "ancestor_list" in phylogeny_df
    if not has_ancestor_list:
        phylogeny_df = alifestd_try_add_ancestor_list_col(
            phylogeny_df, mutate=True
        )

    phylogeny_df.set_index("id", drop=False, inplace=True)

    unsorted_ids = set(phylogeny_df["id"])
    internal_ids_refcounts = Counter(
        id
        for ancestor_list_str in phylogeny_df["ancestor_list"]
        for id in alifestd_parse_ancestor_ids(ancestor_list_str)
    )
    internal_ids_set = set(internal_ids_refcounts.keys())

    reverse_sorted_ids = []
    while unsorted_ids:
        leaf_ids = unsorted_ids - internal_ids_set
        reverse_sorted_ids.extend(leaf_ids)
        unsorted_ids -= leaf_ids

        leaf_parent_counts = Counter(
            id
            for ancestor_list_str in phylogeny_df.loc[[*leaf_ids]][
                "ancestor_list"
            ]
            for id in alifestd_parse_ancestor_ids(ancestor_list_str)
        )
        internal_ids_refcounts.subtract(leaf_parent_counts)

        for leaf_parent_id in leaf_parent_counts.keys():
            refcount = internal_ids_refcounts[leaf_parent_id]
            assert refcount >= 0
            if refcount == 0:
                internal_ids_set.remove(leaf_parent_id)
                del internal_ids_refcounts[leaf_parent_id]

    assert set(reverse_sorted_ids) == set(phylogeny_df["id"])
    res = phylogeny_df.loc[reverse_sorted_ids[::-1], :].reset_index(drop=True)

    if not has_ancestor_list:
        res.drop(columns=["ancestor_list"], inplace=True)

    return res


_raw_description = f"""{os.path.basename(__file__)} | (phyloframe v{get_phyloframe_version()}/joinem v{joinem.__version__})

Sort rows so all organisms follow members of their `ancestor_list`.

Data is assumed to be in alife standard format.

Additional Notes
================
- Use `--eager-read` if modifying data file inplace.

- This CLI entrypoint is experimental and may be subject to change.
"""


def _create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        add_help=False,
        allow_abbrev=False,
        description=format_cli_description(_raw_description),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser = _add_parser_base(
        parser=parser,
        dfcli_module="phyloframe.legacy._alifestd_topological_sort",
        dfcli_version=get_phyloframe_version(),
    )
    return parser


if __name__ == "__main__":
    begin_prod_logging()

    parser = _create_parser()
    args, __ = parser.parse_known_args()
    with log_context_duration(
        "phyloframe.legacy._alifestd_topological_sort", logging.info
    ):
        _run_dataframe_cli(
            base_parser=parser,
            output_dataframe_op=delegate_polars_implementation()(
                alifestd_topological_sort,
            ),
        )
