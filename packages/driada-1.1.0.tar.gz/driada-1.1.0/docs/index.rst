.. DRIADA documentation master file

Welcome to DRIADA's documentation!
===================================

**DRIADA** (Dimensionality Reduction for Integrated Activity Data Analysis) is a comprehensive Python library for analyzing neural population activity through the lens of both single-neuron selectivity and population-level dimensionality reduction.

.. toctree::
   :maxdepth: 2
   :caption: Getting Started

   installation
   quickstart
   examples

.. toctree::
   :maxdepth: 2
   :caption: API Reference

   api/intense
   api/dim_reduction
   api/dimensionality
   api/integration
   api/experiment
   api/information
   api/network
   api/recurrence
   api/rsa
   api/utils
   api/gdrive

.. toctree::
   :maxdepth: 1
   :caption: Additional Information

   changelog
   contributing
   license

Key features
------------

* **INTENSE Analysis**: Information-theoretic selectivity analysis for single neurons
* **Dimensionality Reduction**: Comprehensive suite including PCA, UMAP, Isomap, autoencoders, and more
* **Network Analysis**: Graph-based analysis of neural connectivity and dynamics
* **Recurrence Analysis**: Delay embedding, recurrence plots, RQA, visibility graphs, and ordinal partition networks for nonlinear dynamics
* **Integration Framework**: Seamlessly connect single-neuron selectivity with population manifolds
* **RSA**: Representational Similarity Analysis for comparing neural representations
* **Information Theory**: Entropy and mutual information estimators with advanced corrections
* **Synthetic Data**: Generate controlled datasets with known ground truth
* **Visualization Tools**: Rich plotting utilities for neural data exploration

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`