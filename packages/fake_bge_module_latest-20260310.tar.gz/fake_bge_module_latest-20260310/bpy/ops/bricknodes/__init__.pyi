import typing
import collections.abc
import typing_extensions
import numpy.typing as npt
import bpy.stub_internal.rna_enums

def add_game_prop(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Adds a property available to the UPBGE

    :return: Result of the operator call.
    """

def move_game_prop(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
    direction: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Move Game Property

    :param index: index, (in [-inf, inf], optional)
    :param direction: direction, (optional, never None)
    :return: Result of the operator call.
    """

def remove_game_prop(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove this property

    :param index: index, (in [-inf, inf], optional)
    :return: Result of the operator call.
    """
