import typing
import collections.abc
import typing_extensions
import numpy.typing as npt
import bpy.stub_internal.rna_enums

def add_component(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    component: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add a python Component to the selected object

    :param component: Component Name, Add this Component to the current object (optional)
    :return: Result of the operator call.
    """

def add_game_property(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Adds a property available to the UPBGE

    :return: Result of the operator call.
    """

def add_global_category(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add a global value category

    :return: Result of the operator call.
    """

def add_global_property(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add a value accessible from anywhere

    :return: Result of the operator call.
    """

def add_logic_tree_property(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Adds a property available to the UPBGE

    :return: Result of the operator call.
    """

def add_portal_in(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    portal_name: str | None = "Portal",
    mode: typing.Literal[
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"
    ]
    | None = "1",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Create a new portal

    :param portal_name: Portal Name, (optional, never None)
    :param mode: Socket Type, (optional)
    :return: Result of the operator call.
    """

def add_portal_out(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    portal_name: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Create a new portal

    :param portal_name: Portal Name, (optional, never None)
    :return: Result of the operator call.
    """

def add_socket(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    socket_type: str | None = "NLListItemSocket",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add a socket to this node

    :param socket_type: socket_type, (optional, never None)
    :return: Result of the operator call.
    """

def add_template(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    nl_template_name: str | None = "",
    owner: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Add a template

    :param nl_template_name: nl_template_name, (optional, never None)
    :param owner: owner, (optional, never None)
    :return: Result of the operator call.
    """

def apply_logic_tree(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    owner: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Apply the current tree to the selected objects.

    :param owner: owner, (optional, never None)
    :return: Result of the operator call.
    """

def audio_system(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Select the object this tree is applied to

    :return: Result of the operator call.
    """

def custom_mainloop(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Use a custom Mainloop for this scene

    :return: Result of the operator call.
    """

def custom_mainloop_tree(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Use a custom Mainloop for this scene

    :return: Result of the operator call.
    """

def custom_node_templates(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Load Custom Logic Node Templates

    :return: Result of the operator call.
    """

def edit_custom_node(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Edit Custom Logic Node

    :param index: index, (in [-inf, inf], optional)
    :return: Result of the operator call.
    """

def find_logic_tree(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    tree_name: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Edit

    :param tree_name: tree_name, (optional, never None)
    :return: Result of the operator call.
    """

def generate_code(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    uplogic_installed: bool | None = False,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Force generation of code, needed only after updating or if encountering issues

    :param uplogic_installed: uplogic_installed, (optional)
    :return: Result of the operator call.
    """

def generate_project(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Generate basic structure for a new project

    :return: Result of the operator call.
    """

def get_owner(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    applied_object: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Select the object this tree is applied to

    :param applied_object: applied_object, (optional, never None)
    :return: Result of the operator call.
    """

def install_pyfmodex(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """NOTE: This may take a few seconds and requires internet connection.

    :return: Result of the operator call.
    """

def install_upbge_stubs(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Downloads the latest version of the upbge-stubs module to support autocomplet in your IDE.NOTE: This may take a few seconds and requires internet connection.

    :return: Result of the operator call.
    """

def install_uplogic(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Downloads the latest version of the uplogic module required for running logic nodes.NOTE: This may take a few seconds and requires internet connection.

    :return: Result of the operator call.
    """

def key_selector(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    keycode: str | None = "",
    is_socket: bool | None = True,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Undocumented, consider contributing.

    :param keycode: keycode, (optional, never None)
    :param is_socket: is_socket, (optional)
    :return: Result of the operator call.
    """

def load_font(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    filepath: str | None = "",
    filter_glob: str | None = "*.ttf;*.otf;",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Load an image file

    :param filepath: File Path, Filepath used for importing the file (optional, never None)
    :param filter_glob: filter_glob, (optional, never None)
    :return: Result of the operator call.
    """

def load_image(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    filepath: str | None = "",
    filter_glob: str | None = "*.jpg;*.png;*.jpeg;*.JPEG;",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Load an image file

    :param filepath: File Path, Filepath used for importing the file (optional, never None)
    :param filter_glob: filter_glob, (optional, never None)
    :return: Result of the operator call.
    """

def load_sound(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    filepath: str | None = "",
    filter_glob: str | None = "*.wav;*.mp3;*.ogg*",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Load a sound file

    :param filepath: File Path, Filepath used for importing the file (optional, never None)
    :param filter_glob: filter_glob, (optional, never None)
    :return: Result of the operator call.
    """

def move_game_property(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
    direction: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Move Game Property

    :param index: index, (in [-inf, inf], optional)
    :param direction: direction, (optional, never None)
    :return: Result of the operator call.
    """

def node_search(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    node: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Search for registered Logic Nodes

    :param node: node, (optional)
    :return: Result of the operator call.
    """

def open_donate(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Please consider supporting this Add-On

    :return: Result of the operator call.
    """

def open_github(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Get involved with development

    :return: Result of the operator call.
    """

def open_upbge_docs(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """UPBGE API Documentation

    :return: Result of the operator call.
    """

def open_upbge_manual(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Manual on engine and node usage

    :return: Result of the operator call.
    """

def pack_new_tree(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    new_tree_name: str | None = "NewTree",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Convert selected Nodes to a new tree. Will be applied to selected object.
    WARNING: All Nodes connected to selection must be selected too

        :param new_tree_name: New Tree Name, (optional, never None)
        :return: Result of the operator call.
    """

def register_custom_node(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    text_name: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Register Custom Logic Node

    :param text_name: Node, Register a node defined in a python file (optional)
    :return: Result of the operator call.
    """

def reload_components(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Reload all components applied to this object

    :return: Result of the operator call.
    """

def reload_texts(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Reload all externally saved scripts

    :return: Result of the operator call.
    """

def remove_custom_node(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove Custom Logic Node

    :param index: index, (in [-inf, inf], optional)
    :return: Result of the operator call.
    """

def remove_game_property(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove this property

    :param index: index, (in [-inf, inf], optional)
    :return: Result of the operator call.
    """

def remove_global_category(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove a global value category

    :return: Result of the operator call.
    """

def remove_global_property(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove a value accessible from anywhere

    :return: Result of the operator call.
    """

def remove_logic_tree_property(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    prop_index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove a value accessible from anywhere

    :param prop_index: prop_index, (in [-inf, inf], optional)
    :return: Result of the operator call.
    """

def remove_socket(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove this socket

    :return: Result of the operator call.
    """

def reset_empty_scale(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Reset the volume scale

    :return: Result of the operator call.
    """

def save_custom_node(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    index: int | None = 0,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Save Custom Logic Node

    :param index: index, (in [-inf, inf], optional)
    :return: Result of the operator call.
    """

def start_ui_preview(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Show this canvas and its children. Children are determined by connected Widget sockets, Condition sockets dont matter

    :return: Result of the operator call.
    """

def unapply_logic_tree(
    execution_context: int | str | None = None,
    undo: bool | None = None,
    /,
    *,
    tree_name: str | None = "",
    from_obj_name: str | None = "",
) -> set[Literal[bpy.stub_internal.rna_enums.OperatorReturnItems]]:
    """Remove the tree from the selected objects

    :param tree_name: tree_name, (optional, never None)
    :param from_obj_name: from_obj_name, (optional, never None)
    :return: Result of the operator call.
    """
