# Charting with quantmod

The charting module is a lightweight wrapper that combines the power of Plotly with the flexibility of Pandas, making it easy to create clean, interactive plots with minimal code.

## Usage

```python
import pandas as pd
from quantmod import charts

df = pd.DataFrame({...})
df.iplot(kind="line")
```

## Available Chart Types

- line
- scatter
- ohlc
- candlestick
- subplots
- histogram
- bar
- heatmap
- box
- pie
- treemap
- overlay
- normalized
- surface

> **Note:** Importing `quantmod.charts` automatically adds `iplot()` to all pandas DataFrames and Series. 