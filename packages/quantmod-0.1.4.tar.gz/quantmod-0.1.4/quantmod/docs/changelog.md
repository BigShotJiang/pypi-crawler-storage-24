# Change Log

## 0.1.4

- replaced `BlackScholesOptionPricing` with Generalized Black-Scholes (GBS) framework
  - added `BlackScholes`, `Merton`, `Black76`, `GarmanKohlhagen` models
  - added `price_option()` convenience factory
  - added `OptionGreeks` dataclass with all prices and first-order Greeks
  - `BlackScholesOptionPricing` retained as a deprecated backward-compatible shim
- upgraded Monte Carlo engine (`MonteCarloOptionPricing`)
  - added Sobol quasi-random sampler (`sampler='sobol'`) for faster convergence
  - added antithetic variates variance reduction for pseudo-random mode
  - added all four barrier types: up-and-out, up-and-in, down-and-out, down-and-in
  - added American option pricing via Longstaff-Schwartz regression
  - added `MonteCarloResult` dataclass (price, std error, 95% CI, metadata)
  - parameters renamed: `nsims` → `n_simulations`, `timestep` → `n_steps`

  0.1.3

---

- added db module
- updated timeseries module for pandas 2.x

  0.1.2

---

- updated derivatives module

  0.1.1

---

- updated derivatives module
- updated chart module

  0.1.0

---

- updated risk module
- updated derivatives module

  0.0.9

---

- updated pie plots
- added surface plots

  0.0.8

---

- updated README

  0.0.7

---

- added interactive charting module
- added indicator examples
- bug fixes

  0.0.6

---

- updated Monte Carlo methods
- updated NSE option data module

  0.0.5

---

- added option chain analysis for India
- added binomial option pricing model
- updated VaR calculation and backtester
- bug fixes

  0.0.4

---

- updated multi level index for data download
- updated column positioning for data download

  0.0.3

---

- package data included
- bug fixes

  0.0.2

---

- added technical indicators
- bug fixes and refactoring

  0.0.1

---

- migration from quantmod-python to quantmod
- added historical data loader
- support for SPX & NIFTY in dataloader
