# Welcome!

quantmod is inspired by the popular R package of the same name, reimagined for the modern Python data stack.

It provides a lightweight, structured toolkit for financial time-series ingestion, storage, and analysis, designed for data scientists, analysts, and AI practitioners.

quantmod emphasizes ease of use, reproducibility, and rapid experimentation, making it well-suited for exploratory research, machine-learning pipelines, and data-driven prototyping. Its clean, Pythonic interface helps users move quickly from raw market data to structured analysis and insight.


[![PyPI Downloads](https://static.pepy.tech/badge/quantmod)](https://pepy.tech/projects/quantmod)

## User installation
The easiest way to install quantmod is using pip:

```bash
pip install quantmod
```

## Modules

* [charts](charts.md)
* [database](db.md)
* [datasets](datasets.md)
* [derivatives](derivatives.md)
* [indicators](indicators.md)
* [markets](markets.md)
* [models](models.md) 
* [risk](risk.md)
* [timeseries](timeseries.md)  

## Quickstart

```py
# Retrieves market data & ticker object
from quantmod.markets import getData, getTicker

# Database module
from quantmod.db import QuantmodDB

# Charting module
import quantmod.charts

# Option pricing — GBS models (Black-Scholes, Merton, Black-76, Garman-Kohlhagen)
from quantmod.models import OptionInputs, BlackScholes, price_option

# Monte Carlo pricing (European, Asian, Barrier, American)
from quantmod.models import MonteCarloOptionPricing, OptionType, ExerciseStyle, BarrierType

# Calculates price return of different time periods
from quantmod.timeseries import *

# Technical indicators
from quantmod.indicators import ATR

# Derivatives functions
from quantmod.derivatives import maxpain

# Datasets functions
from quantmod.datasets import fetch_historical_data
```
<br>
Note: quantmod is currently under active development, and anticipate ongoing enhancements and additions. The aim is to continually improve the package and expand its capabilities to meet the evolving needs of the community.

## Examples
Refer to the [examples](user-guide/examples/optionpricing.md) section for more details.

## Changelog
The list of changes to quantmod between each release can be found [here](changelog.md)

## Community
[Join the quantmod server](https://discord.com/invite/DXQyezbJ) to share feature requests, report bugs, and discuss the package.

## Legal 
`quatmod` is distributed under the **Apache Software License**. See the [LICENSE.txt](https://www.apache.org/licenses/LICENSE-2.0.txt) file in the release for details. 

The package is developed and maintained by [Kannan Singaravelu](https://kannansingaravelu.com).