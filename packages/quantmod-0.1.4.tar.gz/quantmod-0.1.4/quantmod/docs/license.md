# Legal 

`quatmod-python` is distributed under the **Apache Software License**. See the [LICENSE.txt](https://www.apache.org/licenses/LICENSE-2.0.txt) file in the release for details.