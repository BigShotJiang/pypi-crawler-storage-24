Retrieves market data and ticker objects from Yahoo Finance via `quantmod.markets`.

```py
from quantmod.markets import getData, getTicker

# Get stock price data — by period
aapl = getData('AAPL', period='5d')
print(aapl)

# Get stock price data — by date range
aapl = getData('AAPL', start_date='2024-01-01', end_date='2024-12-31')

# Get multiple tickers
df = getData(['AAPL', 'MSFT', 'TSLA'], period='1mo')

# Get intraday data (last 60 days only)
df = getData('AAPL', period='5d', interval='1h')

# Get ticker object
spy = getTicker('SPY')

# Access ticker attributes
print(spy.options[:5])          # available expiry dates
print(spy.info['longName'])     # fund/company name
```
