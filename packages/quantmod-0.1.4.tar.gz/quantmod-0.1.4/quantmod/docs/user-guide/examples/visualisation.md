The charting module provides interactive visualizations that are super quick, super clean, and super smooth to use. It combines the power of plotly with the flexibility of pandas for easy plotting. When you import the quantmod charting module, all pandas DataFrame and Series objects gain a new `.iplot()` method, similar to pandas’ built-in .plot().

- In **Jupyter notebooks**, interactive plots display inline automatically when you call `df.iplot(...)`

- In **Python scripts**, interactive plots open in your default web browser. For best results, set:
    ```py
    import plotly.io as pio
    pio.renderers.default = "browser"
    fig = df.iplot(...)
    fig.show()
    ```

- In **headless environments** (e.g., servers), save plots to HTML files:
    ```py
    fig = df.iplot(...)
    fig.write_html("plot.html")
    ```

- Available Chart Types:
    - `line`
    - `scatter`
    - `ohlc`
    - `candlestick`
    - `subplots`
    - `histogram`
    - `bar"`
    - `heatmap`
    - `box`
    - `pie`
    - `treemap`
    - `overlay`
    - `normalized`
    - `surface`

```py
# Interactive Charting Examples
import pandas as pd
import quantmod.charts 
from quantmod.timeseries.performance import dailyReturn, volatility

# Load multiple stocks  
df = pd.read_csv('data.csv', index_col=0, parse_dates=True)

# Load Option grid
option_grid = pd.read_csv("fdm_grid.csv", index_col=0)

# Calculate daily returns
daily_returns = dailyReturn(df)

# Load single stock data
df1 = pd.read_csv('titan.csv', index_col=0, parse_dates=True)

# Calculate Statistics
ret = daily_returns.mean() * 252 * 100
vol = volatility(daily_returns) * 100
stats = pd.DataFrame({"AnnRet": ret, "AnnVol": vol})

# Line Chart
df.iplot(kind="line", y="ITC", color='cornflowerblue', title="Line Chart")

# Scatter Plot
daily_returns.iplot(kind="scatter", x="ICICIBANK", y="ITC", color="green", title="Scatter Plot")

# OHLC Plot
df1.iplot(kind="ohlc", title="OHLC Chart")

# Candlestick Plot
df1.iplot(kind="candlestick", title="Candle Chart")

# Overlay Chart
df[["ICICIBANK", "ITC"]].iplot(kind="overlay", secondary_y="ICICIBANK", title="ICICIBANK & ITC Overlay Chart")

# Subplots
df[['ITC', 'ICICIBANK']].iplot(kind="subplots", showlegend=True, title=" ITC & ICICBank Subplots")

# Subplots for multiple stocks
daily_returns.iloc[:,:4].iplot(kind="subplots", showlegend=True, title="Stock Returns")

# Normalised Plot
df.iplot(kind="normalized", title="Normalized Prices")

# Histogram 
daily_returns.iplot(kind="histogram")

# Histogram without overlap
daily_returns.iloc[:,:4].iplot(kind="histogram", overlap=False, showlegend=True)

# Box Plot
daily_returns.iplot(kind="box", showlegend=True, title="Box Plot Analysis")

# Bar Charts
stats.iplot(kind="bar", showlegend=True, title="Annualised Return & Volatility")

# Pie Charts
ret.to_frame("Annual Return").iplot(kind="pie", showlegend=True, title="Annual Return Share by Stock")

# Heatmap
corrmatrix = daily_returns.corr()
corrmatrix.iplot(kind="heatmap", colorscale="Jet", title="Correlation Plot")

# Treemap
stats.iplot(kind="treemap", labels=stats.index, parents=[""] * len(stats), values="AnnRet", title="Treemap of Annualised Returns")

# Surface plot
fig = option_grid.iplot(kind="surface", xaxis_title='Maturity', yaxis_title='Spot', zaxis_title="Option Value", title="Option Value Surface")

```