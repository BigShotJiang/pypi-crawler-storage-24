Timeseries expects data in the yahoo finance format: OHLC[A]V. Calculates price return of different time period.

```py
from quantmod.markets import getData
from quantmod.timeseries import *

df = getData('SPY', period='2y')

# Get period returns for a specific frequency
# use "period" to specify the frequency
# valid frequency: week, month, quarter, annual, all. 
# None defaults to daily
print(f"Periodic Return: {periodReturn(df.Close, period='week')}")

# Alternatively derive retuns as specified below
# get daily returns
print(f"Daily Return: {dailyReturn(df.Close)}")

# get weekly returns
print(f"Weekly Return: {weeklyReturn(df.Close)}")

# get quarterly returns
print(f"Quarterly Return: {quarterlyReturn(df.Close)}")

# get monthly returns
print(f"Monthly Return: {monthlyReturn(df.Close)}")

# get annual returns
print(f"Annual Return: {annualReturn(df.Close)}")

# get all returns : daily, weekly, quarterly, monthly and annual 
print(f"All Return: {allReturn(df.Close)}")

```