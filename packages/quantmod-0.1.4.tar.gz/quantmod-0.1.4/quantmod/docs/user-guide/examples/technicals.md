Easily add technical indicators to financial time series. Quantmod makes it simple to compute ATR, RSI, MACD, Bollinger Bands, and Averages — with clean, Pandas-native syntax.

```py
from quantmod.markets import getData
from quantmod.indicators import *

df = getData('AAPL', period='250d') 
print(df)

# ATR
df['ATR'] = ATR(df)

# SMA
df['SMA'] = SMA(df['Close'], 10)

# EMA
df['EMA'] = SMA(df['Close'], 10)

# Bollinger Bands
df['BBANDS_L'] = BBands(df['Close'],5,2)[0]
df['BBANDS_M'] = BBands(df['Close'],5,2)[1]
df['BBANDS_U'] = BBands(df['Close'],5,2)[2]

# RSI
df['RSI'] = RSI(df['Close'], 14)

# MACD
df['MACD'] = MACD(df['Close'], 5, 12, 26)[0]

```