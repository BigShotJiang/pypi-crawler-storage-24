Retrieves option data from NSE for a instruments and expiry date. 

```py
"""
NSE Option Chain Analysis Example
==================================

This example demonstrates how to use the OptionData class to:
1. Fetch option chain data for a given symbol and expiry
2. Calculate Put-Call ratio
3. Find maximum pain strike price
4. Get synthetic futures price
5. Access individual option quotes

Date Format
----------
Expiry dates should be in format 'dd-mmm-yyyy' where:
- dd: two-digit day
- mmm: first 3 letters of month name, capitalized (Jan, Feb, Mar, etc.)
- yyyy: four-digit year
Example: '24-Apr-2025'
"""

from quantmod.derivatives import OptionData

# Example usage
if __name__ == "__main__":
    # Get option chain for specified expiry
    expiration = "24-Apr-2025"  # Format: dd-mmm-yyyy (e.g., 24-Apr-2025)
    opt = OptionData("NIFTY", expiration)

    # print call option data
    print(f"Call Option Data: \n {opt.get_call_option_data.head(2)}")
    # print option quote
    print(f"Option Quote: {opt.get_option_quote(22500, 'CE', 'buy')}")
    # print synthetic future price
    print(f"Synthetic Future Price: {opt.get_synthetic_future_price(22500)}")
    # print put call ratio
    print(f"Put Call Ratio: {opt.get_put_call_ratio}")
    # print maximum pain strike
    print(f"Maximum Pain Strike: {opt.get_maximum_pain_strike}")

```