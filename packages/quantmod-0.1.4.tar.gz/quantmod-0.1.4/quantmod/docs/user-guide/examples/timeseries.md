Timeseries expects data in the yahoo finance format: OHLC[A]V. Module offers a variety of tools to handle most common modeling and feature engineering needs.

```py
from quantmod.markets import getData
from quantmod.timeseries import *

df = getData('AAPL', period='5d') 
print(df)

# lag: return previous value of the timeseries
print(f" Previous Value: {lag(df.Close, period=1)}") 

# lead: return next value of the timeseries
print(f" Next Value: {lead(df.Close, period=1)}")   

# fist: return first value of the timeseries
print(f" First Value: {first(df.Close)}")   

# last: return last value of the timeseries
print(f" Last Value: {last(df.Close)}")

# gap: measure gap up / down in percentage
print(f" Gap Percentage: {Gap(df)}")

```