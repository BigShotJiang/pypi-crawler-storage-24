Fetches historical data from quantmod

```py
import pandas as pd
from quantmod.datasets import fetch_historical_data

# Fetches historical data
df = fetch_historical_data(symbol='SPX')

# Prints the first 5 rows of the DataFrame
print(df.head())

```