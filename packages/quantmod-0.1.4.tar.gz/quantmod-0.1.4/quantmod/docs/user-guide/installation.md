# Installation

## pip

```bash
pip install quantmod
```

## uv

```bash
uv add quantmod
```

## From source

```bash
git clone https://github.com/kannansingaravelu/quantmod.git
cd quantmod
uv sync
```
