import pandas as pd
from pydantic import BaseModel, Field, confloat
from typing import List, Optional


class RiskInputs(BaseModel):
    """
    Validated input parameters for VaR and CVaR calculations.

    Attributes
    ----------
    confidence_level : float
        Confidence level for VaR (e.g. 0.95 for 95%). Must be in [0.90, 1.0].
    num_simulations : int, optional
        Number of Monte Carlo simulations. Must be in [1000, 100000].
        Default 10000.
    portfolio_weights : list of float, optional
        Asset weights in the portfolio. Each weight must be in [0, 1].
        Pass ``None`` for single-stock calculations.
    portfolio_returns : pd.DataFrame
        Historical log-returns. Columns are assets; rows are dates.
    is_single_stock : bool, optional
        Set to ``True`` when analysing a single asset. Default ``False``.

    Raises
    ------
    ValidationError
        If any parameter fails its constraint.
    """

    confidence_level: float = Field(
        ..., ge=0.90, le=1.0, description="The confidence level for the VaR calculation"
    )
    num_simulations: int = Field(
        10000, ge=1000, le=100000, description="Number of Monte Carlo simulations"
    )
    portfolio_weights: Optional[List[confloat(ge=0, le=1)]] = Field(
        None, description="Weights of assets in the portfolio (None for single stock)"
    )
    portfolio_returns: pd.DataFrame = Field(
        ..., description="Historical returns of portfolio assets or single stock"
    )
    is_single_stock: bool = Field(
        False, description="Flag to indicate single stock calculation"
    )

    # allow Pydantic to accept arbitrary Python types that are not part of the standard Pydantic types.
    class Config:
        arbitrary_types_allowed = True
