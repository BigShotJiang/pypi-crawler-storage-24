import pandas as pd
import yfinance as yf
from typing import Union, List


def getData(
    tickers: Union[str, List[str]],
    start_date: str | None = None,
    end_date: str | None = None,
    period: str | None = None,
    interval: str = "1d",
) -> pd.DataFrame:
    """
    Retrieve OHLCV market data for one or more tickers via yfinance.

    Parameters
    ----------
    tickers : str or list[str]
        Ticker symbol or list of ticker symbols.
    start_date : str, optional
        Start date in ``YYYY-MM-DD`` format. Cannot be used with ``period``.
    end_date : str, optional
        End date in ``YYYY-MM-DD`` format. Cannot be used with ``period``.
    period : str, optional
        Rolling lookback period. Cannot be used with ``start_date``/``end_date``.
        Valid values: ``1d``, ``5d``, ``1mo``, ``3mo``, ``6mo``, ``1y``,
        ``2y``, ``5y``, ``10y``, ``ytd``, ``max``.
    interval : str, optional
        Bar interval. Default ``"1d"``. Intraday intervals (< ``1d``) are
        limited to the last 60 days by Yahoo Finance.
        Valid values: ``1m``, ``2m``, ``5m``, ``15m``, ``30m``, ``60m``,
        ``90m``, ``1h``, ``1d``, ``5d``, ``1wk``, ``1mo``, ``3mo``.

    Returns
    -------
    pd.DataFrame
        DataFrame indexed by date with columns:
        ``Open``, ``High``, ``Low``, ``Close``, ``Volume``.

    Raises
    ------
    ValueError
        If both ``period`` and ``start_date``/``end_date`` are provided.

    Examples
    --------
    >>> from quantmod.markets import getData
    >>> df = getData("AAPL", start_date="2024-01-01", end_date="2024-12-31")
    >>> df = getData(["AAPL", "MSFT"], period="6mo")
    >>> df = getData("TSLA", period="1mo", interval="1h")
    """
    if period and (start_date or end_date):
        raise ValueError("Use either period OR start_date/end_date, not both.")

    data = yf.download(
        tickers,
        start=start_date,
        end=end_date,
        auto_adjust=True,
        progress=False,
        multi_level_index=False,
        period=period,
        interval=interval,
    )

    return data[["Open", "High", "Low", "Close", "Volume"]]


def getTicker(ticker: str) -> yf.Ticker:
    """
    Return a ``yfinance.Ticker`` object for a given symbol.

    The ``Ticker`` object exposes a wide range of fundamental and market data
    attributes, including ``info``, ``history``, ``dividends``, ``splits``,
    ``financials``, ``balance_sheet``, ``cashflow``, ``earnings``,
    ``options``, ``option_chain``, ``recommendations``, and ``news``.

    Parameters
    ----------
    ticker : str
        Ticker symbol (e.g. ``"AAPL"``, ``"^NSEI"``).

    Returns
    -------
    yf.Ticker
        yfinance Ticker object.

    Examples
    --------
    >>> from quantmod.markets import getTicker
    >>> t = getTicker("AAPL")
    >>> t.info["longName"]
    'Apple Inc.'
    >>> t.dividends
    """
    return yf.Ticker(ticker)
