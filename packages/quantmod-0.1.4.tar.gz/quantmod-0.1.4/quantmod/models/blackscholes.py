"""
Backward-compatibility shim for BlackScholesOptionPricing.

.. deprecated::
    ``BlackScholesOptionPricing`` has been superseded by the Generalized
    Black-Scholes framework in :mod:`quantmod.models.gbs`.

    Please migrate to :class:`~quantmod.models.BlackScholes`, which
    provides identical analytical prices and Greeks plus support for the
    Merton, Black-76, and Garman-Kohlhagen models::

        # Old
        from quantmod.models import BlackScholesOptionPricing
        bsop = BlackScholesOptionPricing(inputs)
        print(bsop.call_price, bsop.put_price)

        # New — drop-in replacement
        from quantmod.models import BlackScholes
        bs = BlackScholes(inputs)
        print(bs.call_price, bs.put_price)
        print(bs.results())          # rich OptionGreeks dataclass

Copyright 2024 Kannan Singaravelu — Apache License 2.0
"""

import warnings

from .gbs import BlackScholes
from .optioninputs import OptionInputs


class BlackScholesOptionPricing(BlackScholes):
    """
    .. deprecated::
        Use :class:`~quantmod.models.BlackScholes` instead.

    Thin backward-compatibility wrapper around
    :class:`~quantmod.models.BlackScholes`.  All attributes (``call_price``,
    ``put_price``, ``call_delta``, ``put_delta``, ``gamma``, ``vega``,
    ``call_theta``, ``put_theta``, ``call_rho``, ``put_rho``, ``impvol``)
    are inherited unchanged.

    Parameters
    ----------
    inputs : OptionInputs
        Option parameters — see :class:`~quantmod.models.OptionInputs`.

    Examples
    --------
    >>> from quantmod.models import OptionInputs, BlackScholesOptionPricing
    >>> bsop = BlackScholesOptionPricing(
    ...     OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20)
    ... )
    >>> bsop.call_price
    10.4506...
    """

    def __init__(self, inputs: OptionInputs) -> None:
        warnings.warn(
            "BlackScholesOptionPricing is deprecated and will be removed in a "
            "future release. Use quantmod.models.BlackScholes instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        super().__init__(inputs)
