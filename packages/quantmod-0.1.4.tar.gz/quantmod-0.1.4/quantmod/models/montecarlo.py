"""
Monte Carlo Option Pricing
==========================
Supports European, Asian (arithmetic average), American (Longstaff-Schwartz),
and Barrier (all four types) options with:

  - Standard pseudo-random (Mersenne Twister) sampling
  - Quasi-random Sobol sequence sampling for faster convergence
  - Antithetic variates variance reduction (pseudo-random mode)
  - Broadie-Glasserman-Kou (1997) continuity correction for discrete barriers

Barrier types supported
-----------------------
- Up-and-Out   : expires worthless if spot breaches barrier from below
- Up-and-In    : activates only if spot breaches barrier from below
- Down-and-Out : expires worthless if spot breaches barrier from above
- Down-and-In  : activates only if spot breaches barrier from above

Copyright 2024 Kannan Singaravelu — Apache License 2.0
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal, Optional

import numpy as np
from scipy.stats import norm
from scipy.stats.qmc import Sobol

from .optioninputs import BarrierType, ExerciseStyle, OptionInputs, OptionType


# ══════════════════════════════════════════════════════════════════════════════
# Results Container
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class MonteCarloResult:
    """
    Results from a Monte Carlo option pricing run.

    Attributes
    ----------
    price : float
        Estimated option price (discounted expected payoff).
    std_error : float
        Standard error of the Monte Carlo estimate.
    confidence_interval : tuple[float, float]
        95% confidence interval (lower, upper).
    n_simulations : int
        Number of simulation paths used.
    sampler : str
        Sampling method: ``'pseudo'`` or ``'sobol'``.
    """

    price:               float
    std_error:           float
    confidence_interval: tuple
    n_simulations:       int
    sampler:             str

    def __str__(self) -> str:
        lo, hi = self.confidence_interval
        return (
            f"{'─'*50}\n"
            f"  Monte Carlo Option Price\n"
            f"{'─'*50}\n"
            f"  Price          : {self.price:>12.6f}\n"
            f"  Std Error      : {self.std_error:>12.6f}\n"
            f"  95% CI         : [{lo:.6f}, {hi:.6f}]\n"
            f"  Simulations    : {self._n_simulations:>12,d}\n"
            f"  Sampler        : {self.sampler}\n"
            f"{'─'*50}"
        )


# ══════════════════════════════════════════════════════════════════════════════
# Monte Carlo Pricing Engine
# ══════════════════════════════════════════════════════════════════════════════

class MonteCarloOptionPricing:
    """
    Monte Carlo option pricing engine.

    Supports multiple exercise styles, sampling methods, and variance-reduction
    techniques under a unified interface.

    Supported exercise styles
    -------------------------
    - **European**  : standard payoff at expiry.
    - **Asian**     : payoff based on the arithmetic average of the price path.
    - **Barrier**   : all four barrier types (up-and-out, up-and-in,
                      down-and-out, down-and-in) with optional cash rebate.
    - **American**  : early-exercise via Longstaff-Schwartz (2001) least-squares
                      regression.

    Sampling methods
    ----------------
    - **pseudo** : Mersenne Twister pseudo-random numbers; fast and broadly
                   applicable.  Antithetic variates are applied when
                   ``antithetic=True`` (default) to halve variance at no extra
                   simulation cost.
    - **sobol**  : Scrambled Sobol quasi-random sequence (via
                   ``scipy.stats.qmc.Sobol``).  Provides O(1/N) convergence
                   vs O(1/√N) for pseudo-random, particularly effective for
                   smooth payoffs (European, Asian).  ``n_simulations`` is
                   automatically rounded up to the nearest power of 2.

    Parameters
    ----------
    inputs : OptionInputs
        Validated option parameters (spot, strike, rate, ttm, volatility).
    n_simulations : int, optional
        Number of simulation paths.  For Sobol, rounded up to the nearest
        power of 2.  Default: ``10_000``.
    n_steps : int, optional
        Number of time steps per path.  Higher values improve barrier and
        Asian pricing accuracy.  Default: ``252`` (one trading year).
    option_type : OptionType or str, optional
        ``'call'`` or ``'put'``.  Default: ``OptionType.CALL``.
    exercise_style : ExerciseStyle or str, optional
        ``'european'``, ``'asian'``, ``'barrier'``, or ``'american'``.
        Default: ``ExerciseStyle.EUROPEAN``.
    barrier_level : float, optional
        Barrier level.  **Required** when ``exercise_style='barrier'``.
    barrier_rebate : float, optional
        Cash amount paid when an out-barrier is breached.  Default: ``0.0``.
    barrier_type : BarrierType or str, optional
        One of ``'up_and_out'``, ``'up_and_in'``, ``'down_and_out'``,
        ``'down_and_in'``.  **Required** when ``exercise_style='barrier'``.
    sampler : {'pseudo', 'sobol'}, optional
        Random number generator.  Default: ``'pseudo'``.
    seed : int, optional
        Random seed for reproducibility.  Applies to pseudo-random only.
        Default: ``None``.
    antithetic : bool, optional
        Apply antithetic variates (pseudo-random only).  Default: ``True``.


    Raises
    ------
    ValueError
        If ``barrier_level`` or ``barrier_type`` is missing when
        ``exercise_style='barrier'``, or if an unsupported style is requested.

    Examples
    --------
    European call — pseudo-random with antithetic variates:

    >>> from quantmod.models import OptionInputs, MonteCarloOptionPricing, OptionType
    >>> inputs = OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20)
    >>> mc = MonteCarloOptionPricing(inputs, n_simulations=100_000,
    ...                              option_type=OptionType.CALL)
    >>> print(mc.results())

    Up-and-out barrier call — Sobol quasi-random:

    >>> from quantmod.models import BarrierType, ExerciseStyle
    >>> mc = MonteCarloOptionPricing(
    ...     inputs,
    ...     n_simulations=16_384,
    ...     option_type=OptionType.CALL,
    ...     exercise_style=ExerciseStyle.BARRIER,
    ...     barrier_level=120.0,
    ...     barrier_type=BarrierType.UP_AND_OUT,
    ...     sampler='sobol',
    ... )
    >>> print(mc.results())

    Asian call (arithmetic average):

    >>> mc = MonteCarloOptionPricing(
    ...     inputs,
    ...     n_simulations=50_000,
    ...     option_type=OptionType.CALL,
    ...     exercise_style=ExerciseStyle.ASIAN,
    ... )
    >>> print(mc.results())

    American put — Longstaff-Schwartz:

    >>> mc = MonteCarloOptionPricing(
    ...     inputs,
    ...     n_simulations=50_000,
    ...     n_steps=100,
    ...     option_type=OptionType.PUT,
    ...     exercise_style=ExerciseStyle.AMERICAN,
    ... )
    >>> print(mc.results())
    """

    def __init__(
        self,
        inputs: OptionInputs,
        n_simulations: int = 10_000,
        n_steps: int = 252,
        option_type: OptionType = OptionType.CALL,
        exercise_style: ExerciseStyle = ExerciseStyle.EUROPEAN,
        barrier_level: Optional[float] = None,
        barrier_rebate: float = 0.0,
        barrier_type: Optional[BarrierType] = None,
        sampler: Literal["pseudo", "sobol"] = "pseudo",
        seed: Optional[int] = None,
        antithetic: bool = True,
    ) -> None:
        self._inputs        = inputs
        self._S             = inputs.spot
        self._K             = inputs.strike
        self._r             = inputs.rate
        self._t             = inputs.ttm
        self._sigma         = inputs.volatility
        self._n_steps       = n_steps
        self._sampler       = sampler.lower()
        self._seed          = seed
        self._antithetic    = antithetic and (self._sampler == "pseudo")
        self._barrier_level  = barrier_level
        self._barrier_rebate = barrier_rebate

        # Sobol requires n_simulations to be a power of 2
        if self._sampler == "sobol":
            n_simulations = self._next_power_of_two(n_simulations)
        self._n_simulations = n_simulations

        # Normalise enum arguments — accept plain strings for convenience
        self._option_type    = OptionType(option_type)        if isinstance(option_type, str)    else option_type
        self._exercise_style = ExerciseStyle(exercise_style)  if isinstance(exercise_style, str) else exercise_style
        self._barrier_type   = BarrierType(barrier_type)      if isinstance(barrier_type, str)   else barrier_type

        self._validate()

        self._result = self._price()

    # ── Validation ────────────────────────────────────────────────────────────

    def _validate(self) -> None:
        if self._exercise_style == ExerciseStyle.BARRIER:
            if self._barrier_level is None:
                raise ValueError(
                    "barrier_level is required when exercise_style='barrier'."
                )
            if self._barrier_type is None:
                raise ValueError(
                    "barrier_type is required when exercise_style='barrier'."
                )
            if self._barrier_level <= 0:
                raise ValueError("barrier_level must be a positive number.")
        if self._n_simulations <= 0:
            raise ValueError("n_simulations must be a positive integer.")
        if self._n_steps <= 0:
            raise ValueError("n_steps must be a positive integer.")
        if self._sampler not in ("pseudo", "sobol"):
            raise ValueError("sampler must be 'pseudo' or 'sobol'.")

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _next_power_of_two(n: int) -> int:
        """Return the smallest power of 2 that is ≥ n."""
        return 1 if n <= 1 else 2 ** math.ceil(math.log2(n))

    # ── Sampling ──────────────────────────────────────────────────────────────

    def _generate_normals(self) -> np.ndarray:
        """
        Generate standard normal random variates of shape
        ``(n_simulations, n_steps)``.

        For **pseudo-random** sampling with antithetic variates, ``n_simulations/2``
        base paths are generated and their negatives appended; the final array
        still has shape ``(n_simulations, n_steps)``.

        For **Sobol** sampling, a scrambled Sobol sequence is generated in
        ``n_steps`` dimensions and transformed through the probit function
        (``scipy.stats.norm.ppf``).

        Returns
        -------
        np.ndarray
            Array of shape ``(n_simulations, n_steps)``.
        """
        if self._sampler == "sobol":
            engine = Sobol(d=self._n_steps, scramble=True, seed=self._seed)
            u = engine.random(self._n_simulations)         # uniform on (0, 1)
            u = np.clip(u, 1e-10, 1.0 - 1e-10)           # guard against ±∞ ppf
            return norm.ppf(u)                            # (n_sims, n_steps)

        rng = np.random.default_rng(self._seed)
        n   = self._n_simulations // 2 if self._antithetic else self._n_simulations
        z   = rng.standard_normal((n, self._n_steps))
        return np.vstack([z, -z]) if self._antithetic else z

    # ── Path Simulation ───────────────────────────────────────────────────────

    def _simulate_paths(self, z: np.ndarray) -> np.ndarray:
        """
        Simulate Geometric Brownian Motion price paths.

        Uses the log-return form to avoid compounding floating-point errors:

            S(t+Δt) = S(t) · exp[(r - σ²/2)·Δt + σ·√Δt·Z]

        Parameters
        ----------
        z : np.ndarray
            Standard normal variates of shape ``(n_simulations, n_steps)``.

        Returns
        -------
        np.ndarray
            Price paths of shape ``(n_simulations, n_steps + 1)``.
            Column 0 is the initial spot price ``S``.
        """
        dt        = self._t / self._n_steps
        drift     = (self._r - 0.5 * self._sigma ** 2) * dt
        diffusion = self._sigma * np.sqrt(dt) * z                   # (n_sims, n_steps)
        cum_log   = np.cumsum(drift + diffusion, axis=1)             # (n_sims, n_steps)
        paths     = self._S * np.exp(
            np.hstack([np.zeros((self._n_simulations, 1)), cum_log])
        )                                                             # (n_sims, n_steps+1)
        return paths

    # ── Payoff Calculators ────────────────────────────────────────────────────

    def _vanilla_payoff(self, prices: np.ndarray) -> np.ndarray:
        """
        Standard European payoff at given prices.

        Parameters
        ----------
        prices : np.ndarray
            Array of underlying prices (shape: ``(n_simulations,)``).

        Returns
        -------
        np.ndarray
            Payoff array of shape ``(n_simulations,)``.
        """
        if self._option_type == OptionType.CALL:
            return np.maximum(prices - self._K, 0.0)
        return np.maximum(self._K - prices, 0.0)

    def _barrier_payoff(self, paths: np.ndarray) -> np.ndarray:
        """
        Compute barrier option payoffs for all four barrier types.

        Applies the Broadie-Glasserman-Kou (1997) continuity correction to
        account for discrete-time monitoring.  The correction shifts the
        effective barrier slightly:

        - Up-barrier  :  B_eff = B · exp(+β·σ·√Δt)
        - Down-barrier:  B_eff = B · exp(−β·σ·√Δt)

        where β = 0.5826 (ζ(½) / √(2π)).

        Parameters
        ----------
        paths : np.ndarray
            Price paths of shape ``(n_simulations, n_steps + 1)``.

        Returns
        -------
        np.ndarray
            Payoff vector of shape ``(n_simulations,)``.

        Notes
        -----
        The four barrier types and their knock conditions:

        +------------------+----------+---------------------------+
        | Type             | Trigger  | Payoff when triggered     |
        +==================+==========+===========================+
        | up_and_out       | max ≥ B  | rebate (option knocked    |
        |                  |          | out)                      |
        +------------------+----------+---------------------------+
        | up_and_in        | max ≥ B  | vanilla (option activated)|
        +------------------+----------+---------------------------+
        | down_and_out     | min ≤ B  | rebate (option knocked    |
        |                  |          | out)                      |
        +------------------+----------+---------------------------+
        | down_and_in      | min ≤ B  | vanilla (option activated)|
        +------------------+----------+---------------------------+
        """
        _BETA    = 0.5826   # Broadie-Glasserman-Kou constant
        dt       = self._t / self._n_steps
        σ        = self._sigma
        B        = self._barrier_level
        rebate   = self._barrier_rebate
        terminal = paths[:, -1]
        vanilla  = self._vanilla_payoff(terminal)

        if self._barrier_type == BarrierType.UP_AND_OUT:
            B_eff   = B * np.exp(+_BETA * σ * np.sqrt(dt))
            crossed = np.max(paths, axis=1) >= B_eff
            return np.where(crossed, rebate, vanilla)

        if self._barrier_type == BarrierType.UP_AND_IN:
            B_eff   = B * np.exp(+_BETA * σ * np.sqrt(dt))
            crossed = np.max(paths, axis=1) >= B_eff
            return np.where(crossed, vanilla, rebate)

        if self._barrier_type == BarrierType.DOWN_AND_OUT:
            B_eff   = B * np.exp(-_BETA * σ * np.sqrt(dt))
            crossed = np.min(paths, axis=1) <= B_eff
            return np.where(crossed, rebate, vanilla)

        if self._barrier_type == BarrierType.DOWN_AND_IN:
            B_eff   = B * np.exp(-_BETA * σ * np.sqrt(dt))
            crossed = np.min(paths, axis=1) <= B_eff
            return np.where(crossed, vanilla, rebate)

        raise ValueError(f"Unsupported barrier type: {self._barrier_type}")

    def _asian_payoff(self, paths: np.ndarray) -> np.ndarray:
        """
        Compute arithmetic-average Asian option payoffs.

        The payoff is based on the arithmetic mean of the simulated price path
        (excluding the initial spot at t=0), rather than the terminal price.
        This averaging effect makes Asian options cheaper than their European
        equivalents and reduces sensitivity to spot price manipulation near expiry.

        Parameters
        ----------
        paths : np.ndarray
            Price paths of shape ``(n_simulations, n_steps + 1)``.

        Returns
        -------
        np.ndarray
            Payoff vector of shape ``(n_simulations,)``.
        """
        avg_price = np.mean(paths[:, 1:], axis=1)   # arithmetic mean, exclude t=0
        return self._vanilla_payoff(avg_price)

    def _american_payoff(self, paths: np.ndarray) -> np.ndarray:
        """
        Price an American option via Longstaff-Schwartz (2001) least-squares MC.

        The algorithm works backwards from expiry.  At each time step, for
        paths that are in-the-money, it regresses discounted future cash flows
        onto a basis of Laguerre-like polynomial features
        ``{1, x, x²}`` (where x = S/K), and exercises early wherever the
        immediate intrinsic value exceeds the estimated continuation value.

        Parameters
        ----------
        paths : np.ndarray
            Price paths of shape ``(n_simulations, n_steps + 1)``.

        Returns
        -------
        np.ndarray
            Discounted payoff for each path of shape ``(n_simulations,)``.

        References
        ----------
        Longstaff, F. A., & Schwartz, E. S. (2001). Valuing American Options
        by Simulation: A Simple Least-Squares Approach. *The Review of
        Financial Studies*, 14(1), 113–147.
        """
        dt   = self._t / self._n_steps
        disc = np.exp(-self._r * dt)

        if self._option_type == OptionType.CALL:
            intrinsic = lambda s: np.maximum(s - self._K, 0.0)  # noqa: E731
        else:
            intrinsic = lambda s: np.maximum(self._K - s, 0.0)  # noqa: E731

        # Initialise cash flows at expiry
        cashflow = intrinsic(paths[:, -1])

        for step in range(self._n_steps - 1, 0, -1):
            spot = paths[:, step]
            itm  = intrinsic(spot) > 0

            # Discount existing cash flows one step
            cashflow *= disc

            if not itm.any():
                continue

            # Polynomial basis in normalised spot (Laguerre-inspired)
            x     = spot[itm] / self._K
            basis = np.column_stack([np.ones_like(x), x, x ** 2])
            y     = cashflow[itm]   # already discounted one step above

            coef, *_ = np.linalg.lstsq(basis, y, rcond=None)
            continuation = basis @ coef

            # Early exercise where intrinsic > estimated continuation
            ex_itm   = intrinsic(spot[itm]) > continuation
            itm_idx  = np.where(itm)[0]
            ex_global                    = np.zeros(self._n_simulations, dtype=bool)
            ex_global[itm_idx[ex_itm]]   = True

            cashflow[ex_global] = intrinsic(spot[ex_global])

        # Final discount from step 1 back to t=0
        return cashflow * disc

    # ── Main Pricing Dispatcher ───────────────────────────────────────────────

    def _price(self) -> MonteCarloResult:
        """
        Run the simulation and return a :class:`MonteCarloResult`.

        Returns
        -------
        MonteCarloResult
        """
        z     = self._generate_normals()
        paths = self._simulate_paths(z)
        disc  = np.exp(-self._r * self._t)

        if self._exercise_style == ExerciseStyle.EUROPEAN:
            discounted = disc * self._vanilla_payoff(paths[:, -1])

        elif self._exercise_style == ExerciseStyle.ASIAN:
            discounted = disc * self._asian_payoff(paths)

        elif self._exercise_style == ExerciseStyle.BARRIER:
            discounted = disc * self._barrier_payoff(paths)

        elif self._exercise_style == ExerciseStyle.AMERICAN:
            discounted = self._american_payoff(paths)

        else:
            raise ValueError(f"Unsupported exercise style: {self._exercise_style}")

        price   = float(np.mean(discounted))
        std_err = float(np.std(discounted, ddof=1) / np.sqrt(self._n_simulations))
        z95     = 1.95996   # norm.ppf(0.975)
        ci      = (price - z95 * std_err, price + z95 * std_err)

        return MonteCarloResult(
            price               = price,
            std_error           = std_err,
            confidence_interval = ci,
            n_simulations       = self._n_simulations,
            sampler             = self._sampler,
        )

    def results(self) -> MonteCarloResult:
        """
        Return the pricing result as a :class:`MonteCarloResult` dataclass.

        Provides a consistent interface with the GBS models
        (e.g. :meth:`~quantmod.models.BlackScholes.results`).

        Returns
        -------
        MonteCarloResult
            Pricing result with price, std_error, confidence_interval,
            n_simulations, and sampler.

        Examples
        --------
        >>> from quantmod.models import OptionInputs, MonteCarloOptionPricing
        >>> inputs = OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20)
        >>> mc = MonteCarloOptionPricing(inputs, n_simulations=50_000)
        >>> print(mc.results())
        """
        return self._result
