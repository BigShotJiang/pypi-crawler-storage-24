# Quantmod Python Package
# https://kannansingaravelu.com/
#
# Copyright 2024 Kannan Singaravelu
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .optioninputs import OptionInputs, OptionType, ExerciseStyle, BarrierType
from .gbs import (
    GeneralizedBlackScholes,
    BlackScholes,
    Merton,
    Black76,
    GarmanKohlhagen,
    OptionGreeks,
    price_option,
)
from .montecarlo import MonteCarloOptionPricing, MonteCarloResult
from .binomial import BinomialOptionPricing

# Backward compatibility — deprecated, use BlackScholes
from .blackscholes import BlackScholesOptionPricing


__all__ = [
    # Inputs / enums
    "OptionInputs",
    "OptionType",
    "ExerciseStyle",
    "BarrierType",
    # GBS pricing models
    "GeneralizedBlackScholes",
    "BlackScholes",
    "Merton",
    "Black76",
    "GarmanKohlhagen",
    "OptionGreeks",
    "price_option",
    # Monte Carlo
    "MonteCarloOptionPricing",
    "MonteCarloResult",
    # Binomial tree
    "BinomialOptionPricing",
    # Deprecated — kept for backward compatibility
    "BlackScholesOptionPricing",
]
