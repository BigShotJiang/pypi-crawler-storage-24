"""
Generalized Black-Scholes (GBS) Framework
==========================================
All input validation is handled by OptionInputs (and its subclasses).
Models are selected by the cost-of-carry parameter b:

    Model               b value       Use case
    ──────────────────────────────────────────────────────────
    BlackScholes        b = r         Non-dividend paying stock
    Merton              b = r - q     Stock/index with div yield q
    Black76             b = 0         Futures / forward contracts
    GarmanKohlhagen     b = r_d-r_f   FX / currency options

Generalized pricing (Haug, 2007):
    d1 = [ln(S/K) + (b + σ²/2)·t] / (σ√t)
    d2 = d1 - σ√t
    C  = S·e^{(b-r)t}·N(d1) - K·e^{-rt}·N(d2)
    P  = K·e^{-rt}·N(-d2)   - S·e^{(b-r)t}·N(-d1)

Put-call parity:  C - P = S·e^{(b-r)t} - K·e^{-rt}

Copyright 2024 Kannan Singaravelu — Apache License 2.0
"""

from __future__ import annotations

import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq
from typing import Optional, Tuple
from dataclasses import dataclass, field

from .optioninputs import OptionInputs


# ══════════════════════════════════════════════════════════════════════════════
# Results Container
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class OptionGreeks:
    """
    Prices and all first-order Greeks for a European option.

    All sensitivities are expressed per unit of *parameter* change:

    Attributes
    ----------
    model : str
        Human-readable model name (e.g. "Black-Scholes").
    d1 : float
        Standardised moneyness-adjusted parameter d1.
    d2 : float
        d2 = d1 - σ√t.
    call_price : float
        Theoretical call option price.
    put_price : float
        Theoretical put option price.
    call_delta : float
        ∂C/∂S — sensitivity of call price to $1 move in spot.
    put_delta : float
        ∂P/∂S — sensitivity of put price to $1 move in spot.
    gamma : float
        ∂²C/∂S² = ∂²P/∂S² — rate of change of delta per $1 move in spot.
    vega : float
        ∂C/∂σ = ∂P/∂σ — price change per **1% (0.01)** change in volatility.
    call_theta : float
        ∂C/∂t — call price decay per **calendar day**.
    put_theta : float
        ∂P/∂t — put price decay per **calendar day**.
    call_rho : float
        ∂C/∂r — call price change per **1% (0.01)** change in domestic rate.
    put_rho : float
        ∂P/∂r — put price change per **1% (0.01)** change in domestic rate.
    implied_vol : float
        Implied volatility backed out from market price (if supplied);
        otherwise equals the input volatility.
    call_phi : float, optional
        ∂C/∂q or ∂C/∂r_f — call price change per 1% change in the secondary
        rate (dividend yield for Merton, foreign rate for Garman-Kohlhagen).
    put_phi : float, optional
        Corresponding put sensitivity to the secondary rate.
    """

    model:       str
    d1:          float
    d2:          float
    call_price:  float
    put_price:   float
    call_delta:  float
    put_delta:   float
    gamma:       float
    vega:        float
    call_theta:  float
    put_theta:   float
    call_rho:    float
    put_rho:     float
    implied_vol: float
    call_phi:    Optional[float] = field(default=None)
    put_phi:     Optional[float] = field(default=None)

    def __str__(self) -> str:
        lines = [
            f"{'─'*54}",
            f"  {self.model}",
            f"{'─'*54}",
            f"  d1 = {self.d1:>10.6f}    d2 = {self.d2:>10.6f}",
            f"{'─'*54}",
            f"  {'':22s}  {'Call':>10}  {'Put':>10}",
            f"  {'Price':22s}  {self.call_price:>10.4f}  {self.put_price:>10.4f}",
            f"  {'Delta':22s}  {self.call_delta:>10.6f}  {self.put_delta:>10.6f}",
            f"  {'Gamma':22s}  {self.gamma:>10.6f}  {self.gamma:>10.6f}",
            f"  {'Vega (per 1%)':22s}  {self.vega:>10.6f}  {self.vega:>10.6f}",
            f"  {'Theta (per day)':22s}  {self.call_theta:>10.6f}  {self.put_theta:>10.6f}",
            f"  {'Rho (per 1%)':22s}  {self.call_rho:>10.6f}  {self.put_rho:>10.6f}",
        ]
        if self.call_phi is not None:
            lines.append(
                f"  {'Phi (per 1%)':22s}  {self.call_phi:>10.6f}  {self.put_phi:>10.6f}"
            )
        lines += [
            f"{'─'*54}",
            f"  Implied Vol : {self.implied_vol:.6f}  ({self.implied_vol*100:.3f}%)",
            f"{'─'*54}",
        ]
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# Base: Generalized Black-Scholes Engine
# ══════════════════════════════════════════════════════════════════════════════

class GeneralizedBlackScholes:
    """
    Core GBS pricing engine.

    Concrete model subclasses pass validated ``OptionInputs`` and set the
    cost-of-carry ``b``.  Subclasses override ``_rho()`` and ``_clone()``
    where the relationship between *b* and *r* differs from the default
    (∂b/∂r = 1).

    Parameters
    ----------
    inputs : OptionInputs
        Validated option inputs (Pydantic model).
    carry : float
        Cost-of-carry *b*.  Set by each concrete subclass.

    Notes
    -----
    The generalised pricing formula (Haug, 2007) unifies Black-Scholes,
    Merton, Black-76, and Garman-Kohlhagen through a single carry parameter:

        d1 = [ln(S/K) + (b + σ²/2)·t] / (σ√t)
        d2 = d1 - σ√t
        C  = S·e^{(b-r)t}·N(d1)  -  K·e^{-rt}·N(d2)
        P  = K·e^{-rt}·N(-d2)    -  S·e^{(b-r)t}·N(-d1)
    """

    MODEL_NAME = "Generalized Black-Scholes"

    def __init__(self, inputs: OptionInputs, carry: float) -> None:
        self._inputs   = inputs
        self._S        = inputs.spot
        self._K        = inputs.strike
        self._r        = inputs.rate
        self._b        = carry
        self._t        = inputs.ttm
        self._sigma    = inputs.volatility
        self._mkt_call = inputs.callprice
        self._mkt_put  = inputs.putprice
        self._compute()

    # ── Core computation ──────────────────────────────────────────────────────

    def _compute(self) -> None:
        self._sqrt_t       = np.sqrt(self._t)
        self._disc         = np.exp(-self._r * self._t)
        self._carry_factor = np.exp((self._b - self._r) * self._t)

        self._d1 = (
            np.log(self._S / self._K) + (self._b + 0.5 * self._sigma ** 2) * self._t
        ) / (self._sigma * self._sqrt_t)
        self._d2 = self._d1 - self._sigma * self._sqrt_t

        # Order matters: _rho() for Black-76 uses prices, so prices computed first
        self.call_price, self.put_price = self._price()
        self.call_delta, self.put_delta = self._delta()
        self.gamma                      = self._gamma()
        self.vega                       = self._vega()
        self.call_theta, self.put_theta = self._theta()
        self.call_rho,   self.put_rho   = self._rho()
        self.impvol                     = self._impvol()

    # ── Pricing ───────────────────────────────────────────────────────────────

    def _price(self) -> Tuple[float, float]:
        cf, disc = self._carry_factor, self._disc
        call = self._S * cf   * norm.cdf(self._d1)  - self._K * disc * norm.cdf(self._d2)
        put  = self._K * disc * norm.cdf(-self._d2) - self._S * cf   * norm.cdf(-self._d1)
        return call, put

    # ── Greeks ────────────────────────────────────────────────────────────────

    def _delta(self) -> Tuple[float, float]:
        """
        Delta — ∂C/∂S and ∂P/∂S.

        Returns
        -------
        Tuple[float, float]
            (call_delta, put_delta).
        """
        cf = self._carry_factor
        return cf * norm.cdf(self._d1), cf * (norm.cdf(self._d1) - 1.0)

    def _gamma(self) -> float:
        """
        Gamma — ∂²C/∂S² (identical for call and put by put-call parity).

        Returns
        -------
        float
        """
        return (
            self._carry_factor * norm.pdf(self._d1)
            / (self._S * self._sigma * self._sqrt_t)
        )

    def _vega(self) -> float:
        """
        Vega — price change per 1% (0.01) change in volatility.

        Returns
        -------
        float
        """
        return self._S * self._carry_factor * norm.pdf(self._d1) * self._sqrt_t / 100.0

    def _theta(self) -> Tuple[float, float]:
        """
        Theta — daily time decay, derived analytically.

        Formula
        -------
        Call Θ = [ -S·cf·n(d1)·σ/(2√t)  - (r-b)·S·cf·N(d1)  - r·K·disc·N(d2)  ] / 365
        Put  Θ = [ -S·cf·n(d1)·σ/(2√t)  + (r-b)·S·cf·N(-d1) + r·K·disc·N(-d2) ] / 365

        Returns
        -------
        Tuple[float, float]
            (call_theta, put_theta) expressed in price-per-calendar-day.
        """
        cf          = self._carry_factor
        common      = -self._S * cf * norm.pdf(self._d1) * self._sigma / (2.0 * self._sqrt_t)
        carry_drift = (self._r - self._b) * self._S * cf

        call_theta = (
            common
            - carry_drift * norm.cdf(self._d1)
            - self._r * self._K * self._disc * norm.cdf(self._d2)
        ) / 365.0

        put_theta = (
            common
            + carry_drift * norm.cdf(-self._d1)
            + self._r * self._K * self._disc * norm.cdf(-self._d2)
        ) / 365.0

        return call_theta, put_theta

    def _rho(self) -> Tuple[float, float]:
        """
        Rho — price change per 1% (0.01) change in domestic rate.

        Default assumes ∂b/∂r = 1 (applies to Black-Scholes and Merton).
        Black-76 overrides this since *r* only appears in the discount factor.

        Returns
        -------
        Tuple[float, float]
            (call_rho, put_rho).
        """
        call_rho =  self._K * self._t * self._disc * norm.cdf(self._d2)  / 100.0
        put_rho  = -self._K * self._t * self._disc * norm.cdf(-self._d2) / 100.0
        return call_rho, put_rho

    # ── Implied Volatility ────────────────────────────────────────────────────

    def _impvol(self) -> float:
        """
        Compute implied volatility using Brent's root-finding method.

        If no market price (``callprice`` or ``putprice``) was supplied,
        returns the input volatility unchanged.  Returns ``np.nan`` if the
        solver cannot converge (e.g. market price is below intrinsic value).

        Returns
        -------
        float
            Implied volatility in decimal form, or ``np.nan`` on failure.
        """
        if self._mkt_call is None and self._mkt_put is None:
            return self._sigma

        def objective(sigma: float) -> float:
            clone = self._clone(volatility=sigma)
            if self._mkt_call is not None:
                return clone.call_price - self._mkt_call
            return clone.put_price - self._mkt_put

        try:
            iv = brentq(objective, a=1e-5, b=5.0, xtol=1e-9, rtol=1e-9, maxiter=500)
            return max(iv, 1e-5)
        except ValueError:
            return np.nan

    def _clone(self, **overrides) -> "GeneralizedBlackScholes":
        """
        Return a fresh instance with updated parameters (used for IV solving).

        Market prices are always stripped so clones never recurse into _impvol.
        Subclasses override to preserve their concrete type and carry logic.

        Parameters
        ----------
        **overrides
            Field values to override in the cloned ``OptionInputs``.

        Returns
        -------
        GeneralizedBlackScholes
        """
        data = self._inputs.model_dump()
        data.update(overrides)
        data["callprice"] = None
        data["putprice"]  = None
        new_inputs = type(self._inputs)(**data)
        return type(self)(new_inputs)

    # ── Results ───────────────────────────────────────────────────────────────

    def results(self) -> OptionGreeks:
        """
        Return all computed prices and Greeks as an :class:`OptionGreeks` dataclass.

        Returns
        -------
        OptionGreeks
        """
        return OptionGreeks(
            model       = self.MODEL_NAME,
            d1          = self._d1,
            d2          = self._d2,
            call_price  = self.call_price,
            put_price   = self.put_price,
            call_delta  = self.call_delta,
            put_delta   = self.put_delta,
            gamma       = self.gamma,
            vega        = self.vega,
            call_theta  = self.call_theta,
            put_theta   = self.put_theta,
            call_rho    = self.call_rho,
            put_rho     = self.put_rho,
            implied_vol = self.impvol,
        )

    def __repr__(self) -> str:
        return (
            f"{self.MODEL_NAME}("
            f"S={self._S}, K={self._K}, r={self._r:.4f}, "
            f"b={self._b:.4f}, t={self._t:.4f}, σ={self._sigma:.4f})"
        )


# ══════════════════════════════════════════════════════════════════════════════
# Black-Scholes  ──  b = r
# ══════════════════════════════════════════════════════════════════════════════

class BlackScholes(GeneralizedBlackScholes):
    """
    Classic Black-Scholes (1973) model for European options on
    non-dividend-paying stock.

    Sets carry b = r, so carry_factor = e^{(b-r)t} = 1 and all GBS formulas
    collapse to the standard Black-Scholes expressions.

    Parameters
    ----------
    inputs : OptionInputs
        Validated option parameters (spot, strike, rate, ttm, volatility).
        Optional: callprice or putprice for implied-volatility calculation.

    Examples
    --------
    >>> from quantmod.models import OptionInputs, BlackScholes
    >>> bs = BlackScholes(OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20))
    >>> print(bs.results())
    """

    MODEL_NAME = "Black-Scholes"

    def __init__(self, inputs: OptionInputs) -> None:
        super().__init__(inputs, carry=inputs.rate)

    def _clone(self, **overrides) -> "BlackScholes":
        data = self._inputs.model_dump()
        data.update(overrides)
        data["callprice"] = data["putprice"] = None
        return BlackScholes(OptionInputs(**data))


# ══════════════════════════════════════════════════════════════════════════════
# Merton  ──  b = r − q
# ══════════════════════════════════════════════════════════════════════════════

class Merton(GeneralizedBlackScholes):
    """
    Merton (1973) continuous-dividend model for options on stocks or
    indices with a known continuous dividend yield *q*.

    Sets carry b = r - q, so carry_factor = e^{-qt}.

    Additional Greek
    ----------------
    Phi (∂C/∂q and ∂P/∂q) — price change per 1% change in dividend yield.
    Accessible via ``results().call_phi`` and ``results().put_phi``.

    Parameters
    ----------
    inputs : OptionInputs
        Must include ``dividend_yield`` (default 0.0 in OptionInputs).

    Examples
    --------
    >>> from quantmod.models import OptionInputs, Merton
    >>> mt = Merton(OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0,
    ...                          volatility=0.20, dividend_yield=0.03))
    >>> print(mt.results())
    """

    MODEL_NAME = "Merton (Dividend Yield)"

    def __init__(self, inputs: OptionInputs) -> None:
        self._q = inputs.dividend_yield
        super().__init__(inputs, carry=inputs.rate - inputs.dividend_yield)
        self._compute_phi()

    def _compute_phi(self) -> None:
        div_disc      = np.exp(-self._q * self._t)
        self.call_phi = -self._S * self._t * div_disc * norm.cdf(self._d1)  / 100.0
        self.put_phi  =  self._S * self._t * div_disc * norm.cdf(-self._d1) / 100.0

    def _clone(self, **overrides) -> "Merton":
        data = self._inputs.model_dump()
        data.update(overrides)
        data["callprice"] = data["putprice"] = None
        return Merton(OptionInputs(**data))

    def results(self) -> OptionGreeks:
        res          = super().results()
        res.call_phi = self.call_phi
        res.put_phi  = self.put_phi
        return res


# ══════════════════════════════════════════════════════════════════════════════
# Black-76  ──  b = 0
# ══════════════════════════════════════════════════════════════════════════════

class Black76(GeneralizedBlackScholes):
    """
    Black (1976) model for European options on futures or forward contracts.

    ``spot`` is interpreted as the futures/forward price *F*.
    Sets carry b = 0, so carry_factor = e^{-rt}.

    Simplified pricing:
        Call = e^{-rt}·[F·N(d1) − K·N(d2)]
        Put  = e^{-rt}·[K·N(−d2) − F·N(−d1)]

    Rho for Black-76 is different from Black-Scholes because *F* is an
    independent market observable; only the discount factor depends on *r*:
        ∂C/∂r = −t·C / 100
        ∂P/∂r = −t·P / 100

    Parameters
    ----------
    inputs : OptionInputs
        ``spot`` should contain the futures/forward price F.

    Examples
    --------
    >>> from quantmod.models import OptionInputs, Black76
    >>> b76 = Black76(OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20))
    >>> print(b76.results())
    """

    MODEL_NAME = "Black-76"

    def __init__(self, inputs: OptionInputs) -> None:
        super().__init__(inputs, carry=0.0)

    def _rho(self) -> Tuple[float, float]:
        # _price() is called before _rho() inside _compute(), so prices are available
        return (
            -self._t * self.call_price / 100.0,
            -self._t * self.put_price  / 100.0,
        )

    def _clone(self, **overrides) -> "Black76":
        data = self._inputs.model_dump()
        data.update(overrides)
        data["callprice"] = data["putprice"] = None
        return Black76(OptionInputs(**data))


# ══════════════════════════════════════════════════════════════════════════════
# Garman-Kohlhagen  ──  b = r_d − r_f
# ══════════════════════════════════════════════════════════════════════════════

class GarmanKohlhagen(GeneralizedBlackScholes):
    """
    Garman-Kohlhagen (1983) model for European FX options.

    Sets carry b = r_d - r_f, so carry_factor = e^{-r_f·t}.

    Two rate sensitivities are exposed:

    - **Rho** (∂C/∂r_d): sensitivity to domestic rate (via ``results().call_rho``).
    - **Phi** (∂C/∂r_f): sensitivity to foreign rate (via ``results().call_phi``).

    Parameters
    ----------
    inputs : OptionInputs
        Must include ``foreign_rate`` r_f.  ``spot`` is the FX spot rate
        (domestic units per one unit of foreign currency).

    Examples
    --------
    >>> from quantmod.models import OptionInputs, GarmanKohlhagen
    >>> gk = GarmanKohlhagen(OptionInputs(
    ...     spot=1.10, strike=1.10, rate=0.03, ttm=0.25,
    ...     volatility=0.08, foreign_rate=0.01,
    ... ))
    >>> print(gk.results())
    """

    MODEL_NAME = "Garman-Kohlhagen"

    def __init__(self, inputs: OptionInputs) -> None:
        self._rf = inputs.foreign_rate
        super().__init__(inputs, carry=inputs.rate - inputs.foreign_rate)
        self._compute_phi()

    def _compute_phi(self) -> None:
        foreign_disc  = np.exp(-self._rf * self._t)
        self.call_phi = -self._S * self._t * foreign_disc * norm.cdf(self._d1)  / 100.0
        self.put_phi  =  self._S * self._t * foreign_disc * norm.cdf(-self._d1) / 100.0

    def _clone(self, **overrides) -> "GarmanKohlhagen":
        data = self._inputs.model_dump()
        data.update(overrides)
        data["callprice"] = data["putprice"] = None
        return GarmanKohlhagen(OptionInputs(**data))

    def results(self) -> OptionGreeks:
        res          = super().results()
        res.call_phi = self.call_phi
        res.put_phi  = self.put_phi
        return res


# ══════════════════════════════════════════════════════════════════════════════
# Convenience Factory
# ══════════════════════════════════════════════════════════════════════════════

def price_option(
    model: str,
    spot: float,
    strike: float,
    rate: float,
    ttm: float,
    volatility: float,
    *,
    dividend_yield: float = 0.0,
    foreign_rate:   float = 0.0,
    callprice: Optional[float] = None,
    putprice:  Optional[float] = None,
) -> OptionGreeks:
    """
    Convenience factory that selects and prices an option using the specified model.

    All inputs are validated by the appropriate ``OptionInputs`` subclass before
    pricing.  Returns an :class:`OptionGreeks` dataclass with all prices and
    first-order Greeks.

    Parameters
    ----------
    model : str
        Model selector.  Accepted values (case-insensitive):

        - ``"bs"`` or ``"black_scholes"``   → :class:`BlackScholes`
        - ``"merton"`` or ``"div"``          → :class:`Merton`
        - ``"b76"`` or ``"black76"``         → :class:`Black76`
        - ``"gk"`` or ``"garman_kohlhagen"`` → :class:`GarmanKohlhagen`

    spot : float
        Current underlying price (or futures price for Black-76; spot rate for GK).
    strike : float
        Option strike price.
    rate : float
        Domestic risk-free rate as a decimal (e.g. 0.05 for 5%).
    ttm : float
        Time to maturity in years (e.g. 0.25 for 3 months).
    volatility : float
        Implied volatility as a decimal (e.g. 0.20 for 20%).
    dividend_yield : float, optional
        Continuous dividend yield (Merton model only). Default: 0.0.
    foreign_rate : float, optional
        Foreign risk-free rate (Garman-Kohlhagen only). Default: 0.0.
    callprice : float, optional
        Observed market call price; triggers implied-volatility calculation.
    putprice : float, optional
        Observed market put price; triggers implied-volatility calculation.

    Returns
    -------
    OptionGreeks
        Dataclass containing call/put prices and all Greeks.

    Raises
    ------
    ValueError
        If an unknown model string is provided.

    Examples
    --------
    >>> from quantmod.models import price_option
    >>> res = price_option("bs", spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20)
    >>> print(res)

    >>> res = price_option("merton", spot=100, strike=100, rate=0.05, ttm=1.0,
    ...                    volatility=0.20, dividend_yield=0.03)

    >>> res = price_option("gk", spot=1.10, strike=1.10, rate=0.03, ttm=0.25,
    ...                    volatility=0.08, foreign_rate=0.01)
    """
    base = dict(
        spot=spot, strike=strike, rate=rate, ttm=ttm, volatility=volatility,
        callprice=callprice, putprice=putprice,
    )
    key = model.lower().replace("-", "_").replace(" ", "_")

    if key in ("bs", "black_scholes"):
        return BlackScholes(OptionInputs(**base)).results()

    elif key in ("merton", "dividend", "div"):
        return Merton(OptionInputs(**base, dividend_yield=dividend_yield)).results()

    elif key in ("b76", "black76", "black_76"):
        return Black76(OptionInputs(**base)).results()

    elif key in ("gk", "garman_kohlhagen", "fx"):
        return GarmanKohlhagen(
            OptionInputs(**base, foreign_rate=foreign_rate)
        ).results()

    raise ValueError(
        f"Unknown model '{model}'. "
        f"Choose from: 'bs', 'merton', 'b76', 'gk'."
    )


# ══════════════════════════════════════════════════════════════════════════════
# Sanity checks
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":

    def pcp_check(label, C, P, fwd, disc_K):
        diff = abs((C - P) - (fwd - disc_K))
        status = "✓" if diff < 1e-10 else f"✗  (diff={diff:.2e})"
        print(f"  PCP {label}: C-P={C-P:.8f}  fwd-K·disc={fwd-disc_K:.8f}  {status}")

    print("\n" + "═"*54 + "\n  BLACK-SCHOLES  (b = r)\n" + "═"*54)
    bs = BlackScholes(OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20))
    print(bs.results())
    pcp_check("BS", bs.call_price, bs.put_price, 100, 100 * np.exp(-0.05))

    print("\n" + "═"*54 + "\n  MERTON  (b = r−q, q=3%)\n" + "═"*54)
    mt = Merton(OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0,
                             volatility=0.20, dividend_yield=0.03))
    print(mt.results())
    pcp_check("Merton", mt.call_price, mt.put_price,
              100 * np.exp(-0.03), 100 * np.exp(-0.05))

    print("\n" + "═"*54 + "\n  BLACK-76  (b = 0)\n" + "═"*54)
    b76 = Black76(OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20))
    print(b76.results())
    pcp_check("B76", b76.call_price, b76.put_price,
              100 * np.exp(-0.05), 100 * np.exp(-0.05))

    print("\n" + "═"*54 + "\n  GARMAN-KOHLHAGEN  (b = r_d-r_f)\n" + "═"*54)
    gk = GarmanKohlhagen(OptionInputs(
        spot=1.10, strike=1.10, rate=0.03, ttm=0.25,
        volatility=0.08, foreign_rate=0.01,
    ))
    print(gk.results())
    pcp_check("GK", gk.call_price, gk.put_price,
              1.10 * np.exp(-0.01 * 0.25), 1.10 * np.exp(-0.03 * 0.25))

    print("\n" + "═"*54 + "\n  IV ROUND-TRIP  (σ=0.20, seed σ=0.35)\n" + "═"*54)
    true_price = BlackScholes(
        OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0, volatility=0.20)
    ).call_price
    recovered = BlackScholes(
        OptionInputs(spot=100, strike=100, rate=0.05, ttm=1.0,
                     volatility=0.35, callprice=true_price)
    ).impvol
    print(f"  True call price : {true_price:.8f}")
    print(f"  Recovered IV    : {recovered:.8f}  (target: 0.20000000)  "
          f"{'✓' if abs(recovered - 0.20) < 1e-8 else '✗'}")
