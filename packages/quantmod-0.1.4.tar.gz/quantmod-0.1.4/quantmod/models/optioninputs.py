from pydantic import BaseModel, Field
from enum import Enum
from typing import Optional

class OptionType(str, Enum):
    """Enum for option types"""
    CALL = "call"
    PUT = "put"

    @classmethod
    def from_string(cls, s: str):
        """Convert string to OptionType"""
        s = s.upper()
        if s in ("CE", "CALL", "C"): return cls.CALL
        elif s in ("PE", "PUT", "P"):
            return cls.PUT
        raise ValueError(f"Invalid option type: {s}")
    
class ExerciseStyle(str, Enum):
    ASIAN = "asian"
    BARRIER = "barrier"
    EUROPEAN = "european"
    AMERICAN = "american"
    
    @classmethod
    def from_string(cls, s: str):
        """Convert string to OptionType"""
        s = s.upper()
        if s in ("asian", "Asian", "ASIAN"):
            return cls.ASIAN
        elif s in ("barrier", "Barrier", "BARRIER"):
            return cls.BARRIER
        elif s in ("european", "European", "EUROPEAN"):
            return cls.EUROPEAN
        elif s in ("american", "American", "AMERICAN"):
            return cls.AMERICAN
        raise ValueError(f"Invalid Exercise Style: {s}")

class BarrierType(str, Enum):
    UP_AND_OUT = "up_and_out"
    UP_AND_IN = "up_and_in"
    DOWN_AND_OUT = "down_and_out"
    DOWN_AND_IN = "down_and_in"

    @classmethod
    def from_string(cls, s: str):
        """Convert string to BarrierType"""
        s = s.upper()
        if s in ("up_and_out", "Up_and_out", "UP_AND_OUT"):
            return cls.UP_AND_OUT
        elif s in ("up_and_in", "Up_and_in", "UP_AND_IN"):
            return cls.UP_AND_IN
        elif s in ("down_and_out", "Down_and_out", "DOWN_AND_OUT"):
            return cls.DOWN_AND_OUT
        elif s in ("down_and_in", "Down_and_in", "DOWN_AND_IN"):
            return cls.DOWN_AND_IN
        raise ValueError(f"Invalid Barrier Type: {s}")


class OptionInputs(BaseModel):
    """
    Validated input parameters for option pricing models.

    Attributes
    ----------
    spot : float
        Current price of the underlying asset. Must be > 0.
    strike : float
        Strike price of the option. Must be > 0.
    rate : float
        Domestic risk-free interest rate as a decimal (e.g. 0.05 for 5%).
        Must be in [0, 1].
    ttm : float
        Time to maturity in years (e.g. 0.25 for 3 months). Must be > 0.
    volatility : float
        Implied volatility as a decimal (e.g. 0.20 for 20%). Must be > 0.
    callprice : float, optional
        Observed market price of the call option. When provided, implied
        volatility is back-solved from this price.
    putprice : float, optional
        Observed market price of the put option. When provided, implied
        volatility is back-solved from this price.
    dividend_yield : float, optional
        Continuous dividend yield as a decimal. Default 0.0.
        Used by the Merton model: b = r - q.
    foreign_rate : float, optional
        Foreign risk-free rate as a decimal. Default 0.0.
        Used by the Garman-Kohlhagen model: b = r - r_f.

    Raises
    ------
    ValidationError
        If any parameter fails its constraint (e.g. spot <= 0, rate > 1).
    """

    spot:           float          = Field(...,        gt=0,        description="Spot price of the underlying asset")
    strike:         float          = Field(...,        gt=0,        description="Strike price of the option")
    rate:           float          = Field(...,        ge=0, le=1,  description="Domestic risk-free rate (decimal)")
    ttm:            float          = Field(...,        gt=0,        description="Time to maturity in years")
    volatility:     float          = Field(...,        gt=0,        description="Volatility of the underlying asset (decimal)")
    callprice:      Optional[float] = Field(default=None, ge=0,     description="Market price of the call option")
    putprice:       Optional[float] = Field(default=None, ge=0,     description="Market price of the put option")
    dividend_yield: float          = Field(default=0.0, ge=0, le=1, description="Continuous dividend yield q (decimal). Merton model: b = r - q.")
    foreign_rate:   float          = Field(default=0.0, ge=-1, le=1, description="Foreign risk-free rate r_f (decimal). Garman-Kohlhagen: b = r - r_f.")