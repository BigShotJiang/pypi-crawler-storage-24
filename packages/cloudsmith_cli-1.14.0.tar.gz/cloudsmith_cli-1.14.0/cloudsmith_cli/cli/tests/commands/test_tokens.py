from unittest.mock import patch

import click
import pytest

from cloudsmith_cli.cli.commands.tokens import list_tokens, refresh
from cloudsmith_cli.core.api.exceptions import ApiException

from .conftest import MockToken


@pytest.mark.usefixtures("set_api_host_env_var")
class TestListTokensCommand:

    def test_list_tokens_success(self, runner):
        """Test successful listing of tokens."""
        mock_tokens = [
            MockToken(
                key="abc123", created="2025-01-01T00:00:00Z", slug_perm="token-1"
            ),
            MockToken(
                key="def456", created="2025-01-02T00:00:00Z", slug_perm="token-2"
            ),
        ]

        with patch("cloudsmith_cli.core.api.user.list_user_tokens") as mock_list_tokens:
            mock_list_tokens.return_value = mock_tokens
            result = runner.invoke(list_tokens, [], catch_exceptions=False)

        assert result.exit_code == 0
        assert "Retrieving API tokens... OK" in result.output
        assert "Token: abc123" in result.output
        assert "Created: 2025-01-01T00:00:00Z" in result.output
        assert "slug_perm: token-1" in result.output
        assert "Token: def456" in result.output
        assert "Created: 2025-01-02T00:00:00Z" in result.output
        assert "slug_perm: token-2" in result.output

    def test_list_tokens_error(self, runner):
        """Test error handling when listing tokens fails."""
        with patch("cloudsmith_cli.core.api.user.list_user_tokens") as mock_list_tokens:
            # Use ApiException for proper error handling
            mock_list_tokens.side_effect = ApiException("API error")
            result = runner.invoke(list_tokens, [], catch_exceptions=True)

        assert result.exit_code != 0

        # The error message might be in different places depending on how the exception is raised
        # Note: stderr is mixed into output with default CliRunner
        error_content = str(getattr(result, "exception", "")) + result.output
        assert (
            "API error" in error_content
            or "Failed to retrieve API tokens" in error_content
        )


@pytest.mark.usefixtures("set_api_host_env_var")
class TestRefreshTokenCommand:
    """Test suite for the 'tokens refresh' command."""

    def test_refresh_token_with_slug(self, runner):
        """Test successful refreshing of a token with a provided slug."""
        mock_new_token = MockToken(
            key="new_token_123",
            created="2025-01-03T00:00:00Z",
            slug_perm="token-refresh",
        )

        with patch(
            "cloudsmith_cli.core.api.user.refresh_user_token"
        ) as mock_refresh_token:
            mock_refresh_token.return_value = mock_new_token
            result = runner.invoke(refresh, ["token-refresh"], catch_exceptions=False)

        assert result.exit_code == 0
        assert "Refreshing token token-refresh... OK" in result.output
        assert "New token value: new_token_123" in result.output
        mock_refresh_token.assert_called_once_with("token-refresh")

    def test_refresh_token_error(self, runner):
        """Test error handling when refreshing a token fails."""
        with patch(
            "cloudsmith_cli.core.api.user.refresh_user_token"
        ) as mock_refresh_token:
            # Use ApiException for proper error handling
            mock_refresh_token.side_effect = ApiException("API error")
            result = runner.invoke(refresh, ["token-error"], catch_exceptions=True)

        assert result.exit_code != 0

        # The error message might be in different places depending on how the exception is raised
        # Note: stderr is mixed into output with default CliRunner
        error_content = str(getattr(result, "exception", "")) + result.output
        assert (
            "API error" in error_content
            or "Failed to refresh the token" in error_content
        )

    def test_refresh_token_list_error(self, runner):
        """Test error handling when listing tokens fails during refresh."""
        with patch("cloudsmith_cli.core.api.user.list_user_tokens") as mock_list_tokens:
            # Use ApiException for proper error handling
            mock_list_tokens.side_effect = ApiException("API error")
            result = runner.invoke(refresh, [], catch_exceptions=True)

        assert result.exit_code != 0

        # The error message might be in different places depending on how the exception is raised
        # Note: stderr is mixed into output with default CliRunner
        error_content = str(getattr(result, "exception", "")) + result.output
        assert (
            "API error" in error_content
            or "Failed to refresh the token" in error_content
        )


@pytest.mark.usefixtures("set_api_host_env_var")
class TestRequestApiKeyFunction:
    """Test suite for the request_api_key helper function."""

    def test_request_api_key_creates_new_token(self):
        """Test successful creation of a new token."""
        from cloudsmith_cli.cli.commands.tokens import request_api_key

        mock_token = MockToken(
            key="ck_new_token_123",
            created="2026-02-06T00:00:00Z",
            slug_perm="new-token",
        )

        class MockOpts:
            debug = False
            output = None
            verbose = False

        with patch(
            "cloudsmith_cli.core.api.user.create_user_token_saml"
        ) as mock_create:
            mock_create.return_value = mock_token

            ctx = click.Context(click.Command("test"), info_name="test")
            result = request_api_key(ctx, MockOpts(), save_config=False)

        assert result is not None
        assert result.key == "ck_new_token_123"

    def test_request_api_key_rotates_existing_token(self):
        """Test automatic rotation when token already exists."""
        from cloudsmith_cli.cli.commands.tokens import request_api_key

        existing_token = MockToken(
            key="ck_old_token",
            created="2026-01-01T00:00:00Z",
            slug_perm="existing-token",
        )
        new_token = MockToken(
            key="ck_rotated_token",
            created="2026-02-06T00:00:00Z",
            slug_perm="existing-token",
        )

        class MockOpts:
            debug = False
            output = None
            verbose = False

        # Create an exception that indicates token already exists
        duplicate_error = ApiException("Duplicate token error")
        duplicate_error.status = 400
        duplicate_error.detail = "User has already created an API key"

        with patch(
            "cloudsmith_cli.core.api.user.create_user_token_saml"
        ) as mock_create, patch(
            "cloudsmith_cli.core.api.user.list_user_tokens"
        ) as mock_list, patch(
            "cloudsmith_cli.core.api.user.refresh_user_token"
        ) as mock_refresh:
            mock_create.side_effect = duplicate_error
            mock_list.return_value = [existing_token]
            mock_refresh.return_value = new_token

            ctx = click.Context(click.Command("test"), info_name="test")
            result = request_api_key(ctx, MockOpts(), save_config=False)

        assert result is not None
        assert result.key == "ck_rotated_token"
