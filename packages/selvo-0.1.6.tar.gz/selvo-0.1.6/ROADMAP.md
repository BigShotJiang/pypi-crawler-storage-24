# selvo — Roadmap & High-Value Additions

> Current state: 5 sprints complete (~12,400 lines). 21 CLI commands, 15 MCP tools,
> 7 output formats, 28 analysis enrichers, native Slack/PagerDuty, policy-as-code,
> dependency confusion detection, time-series trends.

---

## Tier 1 — Already shipped

| Feature | Module | Notes |
|---|---|---|
| CVE/CVSS v4.0/EPSS/KEV enrichment | `analysis/cve`, `cvss`, `epss`, `exploit` | Full pipeline |
| SARIF 2.1.0 output | `reporters/sarif` | GitHub Code Scanning compatible |
| 11-format lockfile input | `discovery/lockfile` | requirements → Cargo → go.sum |
| Policy-as-code engine | `analysis/policy` | YAML gates, CVE allow-list, SLA enforcement |
| Time-series trend store + sparklines | `analysis/trend` | SQLite-backed, SVG in HTML |
| Slack Block Kit + PagerDuty Events v2 | `analysis/watcher` | URL-scheme dispatch |
| Dependency confusion + typosquatting | `analysis/dep_confusion` | Lev-1, version confusion, namespace |
| `selvo test` CI regression gate | `cli` | Baseline diff + policy check in one step |
| GHA composite action | `.github/actions/selvo-scan` | SARIF upload, KEV/score gate |

---

## Tier 2 — Highest remaining value

### 1. Reachability Analysis

**What:** Filter CVEs to only those reachable from the actual call graph of the target
application or system. 60–80% of CVEs in transitive dependencies are not callable
from user code. Eliminating them is the single largest noise-reduction available.

**Why it matters commercially:** It's the most common objection from developers ("we
ship that package but we never call the vulnerable function"). Endor Labs built a
$70M Series B almost entirely on this argument.

**Implementation plan:**

- **Go:** Wrap `govulncheck -json ./...` — it already does call-graph reachability.
  Parse output and cross-reference with selvo's CVE list to mark `reachable: bool`.
- **Python:** Use `importlib.util` + `ast.walk` to trace `import` chains from an
  entrypoint file. For deeper analysis, wrap `pyright --outputjson` call graph data
  or `pyan3` (static call graph).
- **Rust:** Wrap `cargo-audit` — it supports reachability via `cargo-geiger` for
  unsafe reachability, though CVE-level call graphs require `cargo-vet` integration.
- **Java/JVM:** Wrap `dependency-check` with call graph mode or integrate with
  `diff-jars`.

**New fields on `PackageRecord`:**
```python
reachable: bool = False
reachability_source: str = ""        # "govulncheck" | "pyast" | "unknown"
reachable_cves: list[str] = field(default_factory=list)
unreachable_cves: list[str] = field(default_factory=list)
```

**New CLI:** `selvo scan --entrypoint main.py --reachability`

**Scoring impact:** Unreachable CVEs should reduce `max_epss` contribution by 80%
and remove the package from `block_on_weaponized` unless at least one weaponized CVE
is reachable.

**Effort:** ~400 lines + subprocess wrappers. Medium complexity.

---

### 2. `selvo fix` — Automated Remediation PR

**What:** Given a scored package with a known fix version, open a real upstream PR
that bumps the dependency version, adds a CVE reference in the commit message, and
links the selvo report as a comment.

**Why it matters:** Closes the detection→remediation loop with zero human steps.
This is what transforms selvo from a reporting tool into an autonomous security agent.
No comparable open-source tool does this for system packages (Dependabot only handles
manifest files, not distro packages).

**Implementation plan:**

- **`analysis/fix.py`** — core logic:
  - Determine the fix version (from `upstream_version` or OSV `fixed` field)
  - Clone the upstream repo (shallow, `--depth 1`)
  - Create a branch `selvo/fix-CVE-XXXX-YYYY`
  - Update the relevant version file (`setup.cfg`, `Cargo.toml`, `go.mod`, `debian/changelog`)
  - Commit: `fix(CVE-XXXX-YYYY): bump {pkg} to {fix_ver}\n\nFixes: {nvd_url}`
  - Open PR via GitHub API (requires `GITHUB_TOKEN`)
  - Post comment linking selvo HTML report

- **`selvo fix`** CLI command:
  ```
  selvo fix --package openssl --cve CVE-2024-XXXXX --ecosystem debian
  selvo fix --top 5                    # fix top 5 scored packages automatically
  selvo fix --dry-run                  # show what would be done, no write
  ```

- **Safety gates** (use existing `patch_safety.py`):
  - Require `patch_safety_score >= 0.7` before auto-opening a PR
  - Require fix version validated by `enrich_versions` against Repology
  - Flag if fix also introduces a new CVE (circular fix problem)

**Effort:** ~600 lines. High complexity but extremely high value.

---

### 3. Compliance Mapping (NIST 800-53 / FedRAMP / SOC 2)

**What:** Tag each CVE finding with the compliance control(s) it violates, and
generate audit-ready reports in structured formats.

**Why it matters commercially:** This is the enterprise gate-opener. No Fortune 500
or government customer can adopt a tool that doesn't speak GRC. A single mapping
file turns selvo reports into FedRAMP-ready artifacts. This is mostly metadata work
with zero algorithmic complexity — very high ROI per line of code.

**Mapping schema** (`data/compliance_map.json`):

```json
{
  "CWE-79":  {"nist": ["SI-10"], "soc2": ["CC6.1"], "pci": ["6.3.2"]},
  "CWE-89":  {"nist": ["SI-10", "AC-3"], "soc2": ["CC6.1"], "pci": ["6.3.2"]},
  "CWE-787": {"nist": ["SI-16"], "soc2": ["CC7.1"]},
  "network_exposure": {"nist": ["SC-7", "AC-17"], "fedramp": ["SC-7(5)"]},
  "kev_listed": {"nist": ["SI-5", "RA-5"], "fedramp": ["RA-5(2)"], "dod": ["CM-7"]},
  "sla_breach": {"nist": ["RA-5", "SI-2"], "soc2": ["CC7.4"], "pci": ["6.3.3"]}
}
```

**New module:** `analysis/compliance.py`

```python
@dataclass
class ComplianceFinding:
    package: str
    cve_id: str
    frameworks: list[str]       # ["NIST 800-53", "FedRAMP", "SOC 2 CC"]
    controls: list[str]         # ["SI-2", "RA-5(2)"]
    severity: str
    remediation_required_by: str  # ISO 8601 date from SLA engine

def map_controls(packages: list[PackageRecord], framework: str = "all") -> list[ComplianceFinding]:
    ...
```

**New reporter:** `reporters/compliance.py`
- Output formats: JSON (for GRC tools), XLSX (for auditors), PDF via `reportlab`
- Report title, org name, assessment date as CLI options

**New CLI:** `selvo compliance --framework fedramp --out fedramp-audit.json`

**Effort:** ~500 lines + the mapping data file (~300 entries). Low-medium complexity.

---

## Tier 3 — Platform moats / enterprise requirements

### 4. SLSA Provenance Attestation Verification

**What:** For packages that publish SLSA build attestations (most CNCF/Google projects,
Sigstore-signed distributions), verify the attestation chain before marking a package
as trusted. Surface unverified packages as a distinct risk class.

**Why it matters:** SLSA Level 2+ is required for FedRAMP High and DoD IL4+ deployments
as of 2025 OMB guidance. No open-source scanner currently verifies SLSA attestations
inline with CVE data. This is a genuine differentiator.

**Implementation plan:**

- **`analysis/slsa.py`** — attestation verifier:
  - Check for `*.sigstore` or `*.intoto.jsonl` alongside package artifacts
  - Verify against Sigstore's public-good transparency log (`rekor.sigstore.dev`)
  - Extract SLSA predicate: builder ID, build type, source ref, digest
  - Validate source ref matches upstream repo (cross-reference with `upstream_repo`)
  - Assign SLSA level: 0 (none), 1 (docs), 2 (hosted), 3 (hardened)

- **New fields:**
  ```python
  slsa_level: int = 0         # 0–3
  slsa_builder: str = ""      # e.g. "https://github.com/slsa-framework/slsa-github-generator"
  slsa_verified: bool = False
  slsa_source_ref: str = ""
  ```

- **Policy integration:** `block.slsa_level_min: 2` in `selvo.policy.yml` —
  block builds if any critical package has SLSA level below threshold

- **New CLI:** `selvo attest --package openssl` — show attestation chain

**Effort:** ~400 lines + Sigstore client. Medium complexity.

---

### 5. OSV Local Mirror / Air-Gap Mode

**What:** Sync the full OSV vulnerability database locally (Google's `osv.dev` publishes
a GCS bucket export, ~2GB compressed) and serve CVE lookups from local SQLite instead
of the network. This makes scans 5–10× faster and enables fully air-gapped deployments.

**Why it matters:** Air-gap is a hard requirement for classified government environments.
It also makes the tool usable in CI without rate-limit concerns and removes the network
dependency that currently makes the pipeline 3–5 minutes.

**Implementation plan:**

- **`selvo sync`** command:
  ```
  selvo sync osv            # download/update OSV DB (~2GB → ~400MB SQLite)
  selvo sync osv --ecosystems debian,alpine
  selvo sync epss           # cache full FIRST-EPSS CSV locally
  ```

- **`analysis/osv_local.py`**:
  - Download via `gsutil` or direct HTTP from `https://osv-vulnerabilities.storage.googleapis.com/`
  - Parse into SQLite: `(id, ecosystem, package, introduced, fixed, aliases, severity_json)`
  - Replace `enrich_cve`'s OSV API calls with local DB lookups (10–100ms vs 2–5s per package)

- **Modified `analysis/epss.py`**: Detect local EPSS CSV and use it instead of API

- **Cache coherence**: `selvo sync --check` shows DB age; watcher integration refreshes
  OSV nightly

**Effort:** ~500 lines + schema migration. Low-medium complexity.

---

### 6. VS Code Extension

**What:** An extension that shows inline CVE annotations on `import` statements and
lock file entries directly in the editor, with hover cards showing EPSS, KEV status,
and blast radius. One-click `selvo fix` integration.

**Why it matters:** Developer adoption. Every tool in this category has a VS Code
extension because that's where developers spend their time. Snyk, Dependabot, Socket —
they all have one. The IDE surface is where the "shift left" story gets sold.

**Implementation plan:**

- **Language:** TypeScript (VS Code extension API)
- **Architecture:** Extension calls `selvo scan --format json` as a subprocess on
  save/open, caches results, decorates editor with:
  - 🔴 Red underline on `import openssl` / `requires = ["requests"]` when CVEs found
  - Hover card: package name, CVE count, max CVSS, EPSS, KEV badge, `selvo fix` button
  - Status bar: "selvo: 3 CVEs · 1 KEV" with quick panel

- **Trigger conditions:** On file save for `requirements.txt`, `Cargo.toml`,
  `package.json`, `go.mod`, `Gemfile`. On demand via command palette.

- **Settings:**
  ```json
  "selvo.path": "/usr/local/bin/selvo",
  "selvo.policy": "${workspaceFolder}/selvo.policy.yml",
  "selvo.autoScan": true,
  "selvo.minCvssDecorate": 7.0
  ```

- **Marketplace:** Publish as `selvo-security.selvo` on VS Code Marketplace

**Effort:** ~800 lines TypeScript + packaging. Medium-high complexity.

---

### 7. SaaS API + Multi-Tenant Mode

**What:** Deploy the existing FastAPI server as a multi-tenant hosted service where
orgs send SBOMs or lock files and get back scored reports as JSON/SARIF. Add API
key auth, per-org rate limiting, and a simple web dashboard.

**Why it matters:** This is the primary GTM lever. Zero-ops for customers. Supports
the `$500–2,000/org/month` pricing model. The API already exists — what's missing is
auth, tenancy, and a billing hook.

**Implementation plan:**

- **`api/auth.py`**: API key middleware (HMAC-SHA256 tokens stored in Postgres/SQLite)
  ```python
  async def verify_api_key(x_api_key: str = Header(...)) -> OrgContext:
      ...
  ```

- **`api/tenancy.py`**: Per-org result isolation — all snapshots/metrics keyed by `org_id`

- **`api/billing.py`**: Stripe webhook handler for plan gating (free: 5 scans/day,
  pro: unlimited, enterprise: custom SLA)

- **Web dashboard**: Single-page React app (or server-side with Jinja2 + htmx) showing
  the HTML report inline, org scan history, policy status

- **Deployment**: Docker Compose with selvo-api + Caddy (TLS) + Postgres;
  `helm/` chart for Kubernetes

**Effort:** ~1,200 lines Python + frontend. High complexity but direct revenue path.

---

### 8. WinGet / Homebrew / Chocolatey Ecosystem Support

**What:** Extend discovery to Windows and macOS package managers. Required to address
mixed-fleet enterprise customers where the CISO owns both Linux servers and developer
endpoints.

**New discovery modules:**
- `discovery/winget.py` — query WinGet REST API + `winget search --source winget --json`
- `discovery/homebrew.py` — query `formulae.brew.sh` JSON API
- `discovery/chocolatey.py` — query `community.chocolatey.org` V2 OData API

**Complexity notes:**
- WinGet CVE coverage is sparse (mapped via NVD CPE, not ecosystem-native)
- Homebrew packages often have no distro-specific backports — raw upstream version only
- Blast radius model is less meaningful on developer endpoints vs. production servers
- Tycho: recommend scoping these as `--ecosystem winget/homebrew` with a
  "beta/limited coverage" warning

**Effort:** ~600 lines per ecosystem module. Low complexity per module.

---

## Strategic Considerations

### Positioning vs. competitors

| Tool | CVE depth | Blast radius | Policy-as-code | SLSA | Reachability | Linux-native |
|---|---|---|---|---|---|---|
| **selvo** | EPSS+KEV+CVSS v4 | ✅ transitive rdeps | ✅ | Roadmap | Roadmap | ✅ |
| Grype | Basic | ❌ | ❌ | ❌ | ❌ | Partial |
| Snyk | Good | ❌ | Paid tier | ❌ | Basic | ❌ |
| Endor Labs | Good | ❌ | Paid | ❌ | ✅ | ❌ |
| Chainguard | Minimal | ❌ | ❌ | ✅ | ❌ | ✅ container |

Adding **reachability** + **SLSA** puts selvo in a category of one for Linux system packages.

### Build order recommendation

```
Q2 2026   Reachability (Go + Python)   → noise reduction, developer trust
Q2 2026   Compliance mapping           → enterprise sales unblock
Q3 2026   OSV local mirror             → air-gap + speed (10× faster scans)
Q3 2026   selvo fix (auto-PR)          → detection→remediation loop closed
Q4 2026   SLSA attestation             → FedRAMP/DoD market entry
Q4 2026   SaaS API + auth              → revenue
2027      VS Code extension            → developer adoption
2027      WinGet/Homebrew/Chocolatey   → mixed-fleet enterprise
```

### Data moat

Every `selvo analyze` run saves time-series metrics. A network of deployed selvo
instances (anonymised, opt-in) would produce a real-time signal layer — packages
whose EPSS is jumping across many orgs simultaneously could trigger early
warning alerts before CISA formally KEV-lists them. This is the Cloudflare threat
intelligence model applied to Linux package risk. At scale, this data asset is worth
more than the tool itself.

### Acquisition profile

The acquirers most likely to pay a premium:

| Acquirer | Reason | Est. multiple |
|---|---|---|
| **GitHub / Microsoft** | Native integration with Actions + Dependabot | 8–12× ARR |
| **Wiz** | Cloud workload + OS-level risk in one pane | 10–15× ARR |
| **Palo Alto (Prisma)** | Fills Linux gap in CNAPP portfolio | 8–12× ARR |
| **Chainguard** | Deep linux expertise, needs CVE scoring depth | Strategic |
| **Cisco (Panoptica)** | Supply chain + container security expansion | 6–10× ARR |

The SLSA + compliance + reachability combination is the feature set that moves selvo from
"interesting tool" to "strategic acquisition". None of those three are easily externally
acquirable — they require the Linux package graph context selvo has spent 5 sprints building.

---

## Open technical debt

| Item | Priority | File(s) |
|---|---|---|
| `enrich_scorecard` not wired into `fleet` or `scan` sub-pipelines | Low | `cli.py` lines 529–600 |
| `dep_confusion.py` currently sets attrs with `object.__setattr__` hack on frozen dataclasses | Medium | `dep_confusion.py:198` |
| HTML reporter `__CODUP_TREND_HTML__` injects raw HTML — should be escaped in `<script>` context | Low | `reporters/html.py` |
| `watcher.py` PagerDuty connector has no deduplication key — multiple alerts for same package possible | Medium | `watcher.py:_post_pagerduty` |
| `analysis/policy.py` has no schema validation — malformed YAML silently applies defaults | Medium | `policy.py:_parse_policy` |
| `selvo fix` does not exist yet — `patch.py` only surfaces opportunities, doesn't act | High | `analysis/patch.py` |
| No test suite — `pytest` skeleton exists but zero test files written | High | `tests/` (missing) |
| `trend.py` metrics table has no retention policy — grows unbounded | Low | `cache.py:_ensure_metrics_table` |
