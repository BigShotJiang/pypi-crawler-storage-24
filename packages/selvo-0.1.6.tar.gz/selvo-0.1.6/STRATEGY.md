# selvo — Go-to-Market Strategy

> March 9, 2026. Solo technical founder. Zero revenue, zero distribution.
> One goal: first paying customer. Everything else is secondary.

---

## The Gap

Snyk, Endor Labs, Socket, and Mend.io all scan *application* dependencies — `package.json`, `requirements.txt`, `pom.xml`. **None of them scan Linux system packages** — the `apt`/`dnf`/`pacman` layer running on every production server.

selvo is the missing layer. The pitch: *"Snyk tells you your Node app has a vuln. selvo tells you the OS underneath it has been exploitable for 23 years."*

The precise gap: Snyk Container scans OS packages *inside Docker image layers at build time*. No competitor scans Linux system packages **on live host systems** via the running package manager (`apt`/`dnf`/`pacman`) at fleet scale. selvo scans the live host — what is actually installed and running, not what was in the image when it was built.

The live proof: https://sethc5.github.io/selvo-report — zlib with 13 CVEs, 37,000 reverse dependencies, 8,396 days SLA-overdue. No sign-up required.

---

## What Is Actually Shipped vs. Aspirational

| Component | Status |
|---|---|
| CLI (`selvo analyze`, `selvo compliance`, etc.) | ✅ Shipped, functional |
| FastAPI server + auth + billing endpoints | ✅ Code exists, **not deployed anywhere** |
| Stripe webhook/checkout handler | ✅ Code exists, **no Stripe account, no products** |
| Helm chart | ✅ YAML real, placeholder `your-org` URLs throughout |
| GitHub Action (`selvo-scan`) | ✅ Real, complete, **not published to Marketplace** |
| VS Code extension | ✅ Substantially implemented (~506 lines): scanner subprocess, editor decorators (underlines), hover cards (CVSS/EPSS/KEV/blast-radius), status bar badge, fix command — **not published to Marketplace** |
| Compliance mapping (NIST/FedRAMP/SOC2/PCI/DoD) | ✅ Real, 33 CWEs mapped. **Caveat:** `compliance_map.json` has `nist`/`soc2`/`pci` keys per CWE — FedRAMP and DoD IL4 route through NIST 800-53 as a proxy; they are not independent control mappings. |
| SARIF, VEX, CycloneDX SBOM output | ✅ Real |
| OSV local / air-gap mode | ✅ Real |
| Public report page | ✅ Live at https://sethc5.github.io/selvo-report (auto-updates daily) |
| Paying customer | ❌ Zero |
| Deployed API | ❌ Zero |
| Published PyPI package | ❌ Zero |
| Published VSCode/Marketplace listings | ❌ Zero |

The honest starting position: strong tool, zero distribution, zero revenue.

---

## Competitor Pricing (verified March 2026)

| Competitor | Model | Price | Coverage gap |
|---|---|---|---|
| **Snyk** | Per contributing developer | Free → $25/dev/mo → $1,260/dev/yr enterprise | App deps only; FedRAMP = extra cost add-on |
| **Socket** | Per developer | $25/dev/mo → $50/dev/mo → custom | npm/PyPI malware focus; no OS layer |
| **Endor Labs** | Quote only | Not published | Reachability SCA; no OS layer; FedRAMP testimonial = demand signal |
| **Mend.io** | Per contributing developer | Up to $1,000/dev/yr | App deps + SAST; no OS layer |

**Key signal:** Endor Labs' marquee testimonial is a FedRAMP compliance team praising CVE noise reduction. That is selvo's buyer, and selvo covers live host packages that Endor doesn't touch.

---

## Ideal Customer Profile (ICP)

- **Company size:** 200–2,000 employees
- **Infrastructure:** 10–500 Linux servers (EC2, GCP VMs, bare metal, or containerized)
- **Existing tools:** Already paying for SCA tooling (Snyk, Mend) — proves dedicated security budget exists
- **Buyer:** DevSecOps engineer, Platform Security engineer, or Security Engineering Lead
- **Pain signal:** "We know our app deps, but we have no idea what's running on our base images or servers"
- **Disqualifier:** Fewer than 10 servers, no paid security tooling budget, macOS-only stack

> **Note:** Reference customer targets (Internet Archive, Mozilla, EFF) are below the ICP employee floor but are high-visibility OSS organizations. They are pursued for public credibility and quotes, not as revenue accounts.

---

## The Six Paths

---

### Path 1 — Fleet Scanning SaaS *(execute first)*
**Hypothesis:** Give the CLI away free, sell cloud features (fleet view, trend history, policy enforcement) via API subscription.

**Pricing (per-server, not per-seat):**
- Up to 25 servers: **$299/mo** ($3,588 ACV)
- Up to 100 servers: **$799/mo** ($9,588 ACV)
- Unlimited (enterprise): **$2,499/mo** ($29,988 ACV)

**Evaluation path:** Free: `selvo analyze` via CLI, unlimited. Trial: 14-day full API access, no credit card, activated by email (manual gate for qualification). Paid: subscribe at fleet tier, cancel anytime.

#### FOR
- Lowest friction to first dollar. Stripe + Fly.io + `selvo api` can go live in < 1 week with zero new code.
- Self-serve means no sales calls to close. Infrastructure teams understand per-server pricing immediately — it maps to their cost model.
- OSS CLI creates organic inbound — issues, stars, PR contributors who become advocates.
- Cost structure is minimal (~$370 first year). Every dollar after the first subscriber is nearly pure margin.
- The API auth/billing/dashboard code is already written. This is the closest path to deployment.

#### AGAINST
- Security buyers at companies worth targeting don't expense $299/mo SaaS without a security review, procurement process, and legal sign-off on data handling. The deal that closes easily is the one not worth closing.
- A motivated engineer will run `selvo analyze` in a cron job and store output in S3 for $0.02/mo.
  - *Rejoinder:* True for a solo engineer. The organizational gate is different: a team managing 200 servers needs shared visibility, trend deltas ("this server regressed since Tuesday"), policy enforcement (block deployments when KEV score exceeds threshold), an audit trail for SOC 2/FedRAMP evidence, and SARIF integration with existing GRC tooling. S3 files solve one person's curiosity. The platform sells to the organization.
- The current dashboard is an API — the HTML UI (Bootstrap 5 + htmx, 5 pages: overview/packages/CVEs/trends/keys) is server-rendered Python and works, but needs the API deployed to be visible to anyone.

#### VERDICT
**Do this first, but as infrastructure — not as primary revenue.** Deploy the API because you need it regardless. Set up Stripe because you need it regardless. Don't bet the first 6 months on self-serve subscriptions alone; pair it with a compliance engagement to reach fundable MRR.

---

### Path 2 — Compliance-as-a-Feature *(highest ACV)*
**Hypothesis:** Sell compliance mapping reports (FedRAMP, SOC 2, PCI) to CISOs as a scoping/audit tool. High ACV, professional services wrapper.

**Target ACV:** $15k–$80k/yr

**Buying process:**
1. **Entry:** CISO or Security Engineering Lead pursuing FedRAMP Ready, SOC 2 Type II, or PCI DSS.
2. **POC:** Free 2-hour scoping call + 48-hour proof of value — run `selvo compliance` against their manifest, deliver a Markdown or HTML report mapping packages to the relevant control framework (~3 hours of work; worth $4k–$8k of consultant time to them). **FedRAMP-specific note:** The CLI supports the `fedramp` framework flag, but `compliance_map.json` routes it through NIST 800-53 — it is not an independent direct-mapping to FedRAMP High/Moderate controls. Disclosed upfront; adding direct FedRAMP High control rows is ~8–12 hours of data entry.
3. **Proposal:** Annual contract for recurring compliance mapping + quarterly reports + update advisory ($15k–$30k/yr first contract).
4. **When they ask for SOC 2 on selvo itself:** Read-only manifest operation, no data leaving their environment, Bonterms-based DPA provided (bonterms.com, ~2 hours to adapt). The SLA objection is harder: there is no support infrastructure. Be explicit in proposals — solo operation, best-effort SLA, 90-day out clause. This is not a dealbreaker for a pilot but it must not be hidden.

#### FOR
- This is where the money actually is. A $30k annual contract is achievable in a focused email + call sequence with a CISO. You need 2 of them to have fundable MRR.
- SARIF → GRC tool integration (ServiceNow, Archer) is a real workflow no OSS CLI offers out of the box.
- FedRAMP scoping is painful and manual. A tool that generates a pre-formatted control evidence package saves 40–80 hours of consultant time — $4k–$8k of value at consultant rates, easily priced at $15k/yr.
- Air-gap/OSV local mode is a hard requirement for DoD/FedRAMP High environments. selvo has it. Snyk and Mend require internet access for their scanning infrastructure.
- Tennessee has a meaningful defense contractor and healthcare compliance ecosystem (Booz Allen regional offices, SAIC, DXC) within the Nashville → DC corridor.

#### AGAINST
- Enterprise sales is a completely different job than building a tool. You need a champion inside the org, legal review of your own data practices, a BAA if healthcare is involved.
- Minimum 60–120 day sales cycle. You could do everything right and not see a dollar for 4 months.
- "NIST 800-53 compliance mapping" is a feature 6 other tools claim. The differentiation has to be demonstrated through POCs, which means professional services time for free.

#### VERDICT
**Best long-term ACV, hardest short-term path. Do not lead with this.** Get one paying SaaS customer first so you can say "we have customers" in the enterprise conversation.

---

### Path 3 — VS Code Extension Marketplace
**Hypothesis:** Publish the extension free, gate cloud policy enforcement and team scans behind a subscription.

**Projection:** 10k installs → 0.5–1% paid conversion (realistic for unknown publisher) at $8–20/mo = ~$400–$2k MRR per 10k installs

#### FOR
- VS Code has 35M+ monthly active users. Extensions that solve a real pain compound organically.
- Developer discovery has no CAC if it trends on the marketplace.
- Publishing is a 2-hour task (register publisher account, `vsce publish`). The extension is substantially implemented.
- The extension already delivers inline CVE decorators, hover cards (CVSS/EPSS/KEV/blast-radius on hover), and a status bar badge — the free-tier developer experience is real, not aspirational.
- Paid gate: cloud policy enforcement and team scan sync require the SaaS backend; the auth call-out point already exists in the code.

#### AGAINST
- 10k installs targeting Linux package management is not fast. Realistic velocity without paid promotion: 50–200 installs/week — that's 1–2 years to 10k.
- Paid conversion for an unknown publisher: 0.5–1%. The 2–4% figures that circulate apply to established publishers with brand recognition.
- The remote API path in the extension is fully wired: `selvo.apiUrl` and `selvo.apiKey` are declared settings; the extension calls the API instead of the local CLI when `apiUrl` is set. No additional VS Code code to write — the same blocker as Path 1: the API must be deployed.
- VS Code Marketplace does not handle payments. The SaaS backend is still required for the paid tier.

#### VERDICT
**Publish it now (2–4 hours, zero cost) — the editor experience is complete and functional.** Once the API is deployed (Path 1, Week 1–2), users who paste their API key into `selvo.apiUrl` / `selvo.apiKey` settings get remote scans automatically — the call path is already in the code.

---

### Path 4 — GitHub Actions Marketplace *(PLG flywheel)*
**Hypothesis:** Publish `selvo-scan` free; every CI run is a growth touchpoint. Monetize via org-level policy gating.

**Monetization:** org-level policy gate (fleet dashboard, SARIF upload, policy enforcement) — not per-repo metering

#### FOR
- The GitHub Action is the most complete distribution artifact in the repo. It handles SBOM input, Grype/Trivy import, PR commenting, and exit-code gating. It is ready to publish today.
- CI integration is sticky. Once `selvo-scan` is in a `.github/workflows/`, removing it requires deliberate effort.
- GitHub Marketplace has 35M+ repositories as an addressable audience. Discovery is algorithmic and organic.
- The usage signal (every workflow run) maps directly to the buyer's pain. Visible on every PR.
- Distribution via GitHub CI is zero-marginal-cost and scales with the ecosystem.

#### AGAINST
- Free CI actions are extremely hard to monetize after the fact. Developers treat them as a utility — organizational inertia to add a paid CI step is high (procurement, secrets management for API keys).
- Trivy and Grype are permanently free for app-layer scanning. They don't scan OS packages, but they occupy the "free scanner in CI" mindset, making selvo's positioning harder to communicate in a Marketplace listing.
- Dependabot scans `npm`, `pip`, `rubygems` — not `apt`/`dnf`/`pacman`. It is not a competitor. Position alongside it as the missing OS layer, not against it.
- Org-level billing infrastructure doesn't exist yet. Building it is weeks of work.

#### VERDICT
**Publish to Marketplace immediately — it is the best top-of-funnel asset and costs nothing to ship.** Gate on org-level features that require the SaaS backend. The action is the hook; the platform is the upgrade.

---

### Path 5 — Managed Helm / On-Prem Enterprise *(year 2+, not 2026)*
**Hypothesis:** Sell support contracts + policy template libraries to defense contractors and banks that won't use SaaS.

**Target ACV:** $25k–$100k/yr site license

#### FOR
- DoD IL4/IL6 environments genuinely cannot send data to a third-party SaaS. The air-gap story is real and the budget exists.
- Support contracts are highly predictable revenue with built-in renewal pressure.
- No direct competition from Snyk/Mend in the air-gap + Linux-native segment.

#### AGAINST
- The Helm chart has `your-org` placeholders and has never been deployed. Enterprise on-prem requires a hardened, production-validated deployment.
- On-prem deals require: legal entity, E&O + cyber liability insurance, reference customers, support SLA documentation, a ticketing system, and 40–80 page security questionnaires. None of that exists.
- 6–18 month sales cycle for a cold on-prem deal.
- As a solo founder, you cannot staff a $50k support contract. One critical incident means 18-hour days.

#### VERDICT
**Do not pursue in year 1.** The right entry is inbound — if you close a FedRAMP compliance deal (Path 2) and they ask "can we run it ourselves," that's the moment to scope it.

---

### Path 6 — Reference Customer → Pre-Seed Capital
**Hypothesis:** Land a credible org (Internet Archive, Mozilla, CISA) as a free/pilot customer. Use the name to raise $500k–$2M pre-seed.

#### FOR
- A public quote from a recognizable org changes every subsequent sales conversation.
- Linux Foundation sandbox/incubation is achievable and is a durable signal to enterprise buyers.
- The public report at https://sethc5.github.io/selvo-report is a concrete, low-friction first ask: "Would you run this against your stack and give us a public quote?" The auto-updating repo proves the pipeline is real.

#### AGAINST
- CISA procurement, even for free tools, involves legal review, security questionnaires, and a multi-month process with no guaranteed outcome.
- A realistic pre-seed for a solo technical founder at this stage: $500k–$2M at $4–8M valuation. An unpaid pilot adds credibility but doesn't move the valuation needle on its own — ARR does.
- Linux Foundation incubation is a real signal but it doesn't pay your server bill.
- This path requires BD skillset orthogonal to the engineering work that's actually needed right now.

#### VERDICT
**Opportunistic only.** If a warm intro to CISA or LF appears, take it. Do not cold-email as a primary strategy. A reference customer negotiated from a position of existing revenue is worth far more than one negotiated from desperation.

---

## Cross-Cutting Decisions

### License: Apache 2.0 vs. BSL 1.1

| | Apache 2.0 everywhere | Apache CLI + BSL api/ |
|---|---|---|
| **Developer trust** | Maximum | Reduced — BSL is controversial post-HashiCorp |
| **Forkability concern** | Real but unlikely at current size | Mitigated for the API layer |
| **Sales friction** | Zero | Legal review required at enterprises |
| **Engineering cost** | Zero | File headers + LICENSE-BSL.txt + SPDX updates |
| **Signal to VCs** | Neutral | Slightly negative (seen as defensive) |

**Verdict:** Apache 2.0 throughout. The execution moat (data freshness, ecosystem breadth, integration quality) is more durable than a license restriction at this stage. Revisit BSL only if a well-funded competitor begins directly copying the API layer.

---

### Payment Processor: Stripe vs. Paddle

| | Stripe | Paddle |
|---|---|---|
| **Code already written** | ✅ Yes | ❌ No |
| **US tax (Tennessee)** | Stripe Tax handles it | Paddle MoR handles it |
| **EU VAT** | Your responsibility | Paddle MoR handles it |
| **Fee** | 2.9% + $0.30 | 5% + $0.50 |
| **Enterprise credibility** | High | Medium |
| **Setup time to first charge** | 1–2 hours | 3–5 hours (new integration) |

**Verdict:** Stripe. Enable Stripe Tax on day 1. Revisit if EU customers exceed 20% of revenue.

---

### CIS Controls: Add Now vs. Wait

**Add now if:** A prospect asked for it, or you're targeting mid-market (1k–10k employees) companies in the next 90 days.

**Wait if:** Near-term pipeline is federal/government-adjacent (FedRAMP, DoD) where NIST 800-53 is the only framework that matters.

Data entry cost: ~4 hours to map 33 CWEs to CIS Controls v8. Code cost: ~30 minutes.

**Verdict:** Wait for a prospect to ask. Don't add it speculatively.

---

## Execution Sequence

**The opening move:** Find companies already paying Snyk. They have budget, understand SCA, and have the obvious gap. Ask: *"What scans your OS packages?"* The answer is nothing. Charge $299/mo. Lead with https://sethc5.github.io/selvo-report. "Want this running against your actual fleet?"

### Week 1–2: Ship What's Done (~13 hours, zero new code)
1. Deploy the API on Fly.io. Set `SELVO_API_AUTH=1`. < 4 hours.
2. Create Stripe account. Create 3 products: Fleet-25 ($299/mo), Fleet-100 ($799/mo), Fleet-Unlimited ($2,499/mo). Enable Stripe Tax. Wire env vars, run test checkout. < 3 hours.
3. Publish `selvo-scan` to GitHub Actions Marketplace. < 2 hours.
4. Publish `selvo-security` VS Code extension. Editor-side (decorators, hover cards, status bar, fix command) is complete. Wire backend auth before marketing the paid policy gate, but publish now for the install metric. < 2 hours.
5. Publish selvo to PyPI (release workflow exists, cut a v0.1.0 tag). < 2 hours.

After this week: deployed API, live payment flow, two Marketplace listings, PyPI package. That's a fundable demo.

### Week 3–4: First Conversations
6. Reach out to Internet Archive + Mozilla with the public report link; offer a free compliance mapping for their stack; ask for a public quote.
7. Post https://github.com/sethc5/selvo-report in 3 communities: HackerNews "Show HN", r/netsec, CNCF Slack #security. Goal: 100 GitHub stars, 50 action installs.
8. Reach out to 10 DevSecOps engineers — prioritize those at companies already paying Snyk. Lead with the live report: "I can run this against your stack." Ask if they'd pay $299/mo for the fleet dashboard.

### Month 2: First Dollar
9. First paying customer at $299/mo or above. Realistic timeline from first cold contact to payment at this price: 3–6 weeks. Contacts made in Week 3–4 are pipeline for Month 2, not Month 1. Do not take sub-$299 to get a number on the board — the price is the signal. If someone won't pay $299/mo they won't renew.

### Month 2–3: Compliance Wedge
10. With 1 paying customer as reference, approach 3 mid-market companies about a compliance mapping engagement ($5k–$15k).
11. Write one blog post: *"How selvo maps your apt/dnf packages to FedRAMP controls"* — the SEO asset for the compliance buyer.

### Month 4–6: Raise
12. At $2k–$5k MRR or one closed compliance engagement, begin investor conversations. Pre-seed rounds take 2–3 months from first meeting to close — start Month 4, target close Month 6.

| Milestone | Gate |
|---|---|
| Week 1: Stripe test-mode checkout works | Payment integration is validated; ready to go live after API deploys |
| Week 2: API live on Fly.io + Stripe live-mode wired | First paying customer is possible |
| Week 3: VS Code extension published | Install metric starts |
| Month 2: First $299/mo subscriber | Proof of willingness-to-pay |
| Month 3: $5k–$15k compliance deal | Real ACV, enterprise conversations unlocked |
| Month 6: Pre-seed closed | Capital to hire |

---

## IP Protection

| Decision | Action |
|---|---|
| **Trademark** | File USPTO TEAS Plus, Class 42 (SaaS), ~$250–350. Check `tmsearch.uspto.gov` first — common law rights already established by public use. |
| **Patent** | Skip. Alice Corp. invalidation risk is high for software analytics; $8–15k non-provisional cost. Moat is execution speed, data freshness, ecosystem breadth. |
| **License** | Apache 2.0 throughout. Maximizes developer trust, eliminates legal review friction in enterprise sales. BSL 1.1 on the roadmap only if a well-funded competitor directly copies the server infrastructure. |

---

## Cost Structure

| Item | Cost |
|---|---|
| Data (OSV, EPSS, NVD, CISA KEV, Repology, OSS-Fuzz, Scorecard, GitHub API) | $0 |
| Fly.io (2× shared-cpu-1x, 256 MB RAM) | ~$3–7/mo |
| Cloudflare (CDN + DDoS, free tier) | $0 |
| Stripe (2.9% + $0.30/transaction) + Stripe Tax | Variable |
| Business email (Google Workspace) | $6/mo |
| Tennessee LLC filing | $50 one-time + ~$300/yr registered agent |
| Domain | ~$15/yr |
| **Total fixed burn** | **~$370 first year, ~$330/yr thereafter** |
| **Break-even** | **One $299/mo subscriber** |

---

## Reference Customer Targets *(for credibility, not revenue — listed by probability of first contact converting)*

1. **Internet Archive** — small team, real Linux infra, visible brand, historically receptive to OSS tooling. 2–4 weeks.
2. **Mozilla** — open-source infra mandate, active security team, formal FLOSS engagement program. 4–8 weeks.
3. **EFF** — mission-aligned, small senior engineering team, high-visibility. 4–8 weeks.
4. **Linux Foundation** — formal sandbox/incubation process; a named LF project is a durable signal. 3–6 months.
5. **CISA** — highest leverage if it lands; government procurement is 6–12 months minimum. Warm intro only.

Outreach: lead with the public report, offer a free compliance mapping, ask for a public quote — not a contract.

---

## Comparable Valuations

| Company | Valuation | Notes |
|---|---|---|
| Snyk | $7.4B | Broadest OSS security platform; app deps only |
| Chainguard | $1.12B | Supply chain / hardened container images |
| Endor Labs | $70M | Reachability-focused SCA — closest comp; no OS layer |
| Mend.io (fka WhiteSource) | ~$1B | SCA for enterprises; app deps only |
| Socket | Private | Supply chain malware detection; npm/PyPI focus |

**Positioning:** Linux-native, OS-layer-first, blast-radius scoring. Every competitor covers application dependencies. selvo covers the live OS underneath — what is actually installed and running on each host, not what was in the image at build time. The buyer is platform and infrastructure security teams — not generic AppSec. Endor Labs at $70M with no OS coverage is the realistic near-term comp; the FedRAMP + air-gap angle is the path to exceeding it.

---

## Realistic Valuation Basis

Ground truth from the March 2025 codebase audit (see FEATURES.md):

| Signal | Reality |
|---|---|
| ARR | $0 |
| Paying customers | 0 |
| Deployed API | No |
| Published packages | No (PyPI, VS Code, GitHub Marketplace all unpublished) |
| Live public demo | ✅ https://sethc5.github.io/selvo-report (auto-updates daily) |
| CLI commands | ✅ 23, all functional, 165 tests passing (0.34s) |
| API endpoints | ✅ 29, with multi-tenant auth, billing hooks, async job queue — undeployed |
| Discovery ecosystems | ✅ 13 scrapers (apt, rpm, pacman, Alpine, NixOS, Homebrew, Chocolatey, Winget, container, lockfile, SBOM, Grype/Trivy import) |
| Output formats | ✅ 7 (terminal, JSON, Markdown, HTML, SARIF 2.1.0, CycloneDX SBOM, VEX) |
| VS Code extension | ✅ 506 lines, substantially implemented: scanner, decorators, hover cards, status bar — not published |
| GitHub Action | ✅ 193 lines, complete, not published to Marketplace |
| MCP server | ✅ 14 tools, 1,057 lines — Claude/LLM integration functional |
| Air-gap / offline mode | ✅ OSV local SQLite mirror, fully offline capable |
| Compliance mapping | ✅ 33 CWEs → NIST/SOC2/PCI direct; FedRAMP/DoD proxy through NIST |
| Helm chart | ⚠️ Real YAML, `your-org` placeholders, never deployed |
| Team | Solo technical founder |
| Legal entity | None filed |

**Honest pre-money range (March 2026, zero revenue):** $1–3M angel / pre-seed. The technical depth is real; the distribution is zero. Those are simultaneous risk flags.

**What moves the number meaningfully:**

| Event | Valuation impact |
|---|---|
| PyPI + VS Code + GitHub Marketplace published | +visibility, +$500k narrative |
| First $299/mo paying customer | +proof-of-willingness-to-pay, $2–4M range |
| $2k MRR | $3–5M pre-money realistic |
| One $15k compliance engagement | $4–7M, enterprise motion credible |
| Named reference customer (Internet Archive, Mozilla) | $3–5M, narrative anchored |
| $5k+ MRR + reference customer | $5–8M pre-money, pre-seed closeable |

**The honest sentence:** selvo is a substantially built tool with zero distribution. First 6 months are entirely about converting "built" into "shipped and used" — not about the valuation number.

---

## What to Ignore in 2026

- On-prem Helm enterprise sales (Path 5) — not until a Path 1 or 2 reference customer exists
- Metered per-repo CI billing — Trivy and Grype are permanently free at that layer; per-repo pricing cannot win
- BSL license changes — execution moat > license moat at current scale
- CIS Controls mapping — add when a prospect asks, not before
- CISA cold outreach — opportunistic only
- Pre-seed fundraising before Month 4 — one paying customer first; fundraising from traction is materially easier

---

*The core error in a multi-path strategy is diffusing effort. Pick the motion. The motion is: ship what's done, get one paying customer at $299/mo, use that to unlock the next thing.*
