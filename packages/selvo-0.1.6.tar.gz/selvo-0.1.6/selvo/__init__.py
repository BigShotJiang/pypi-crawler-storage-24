"""selvo — Linux Core Dependency Mapper & Update Prioritizer."""
