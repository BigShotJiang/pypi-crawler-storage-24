"""Check Debian/Ubuntu security tracker to filter already-resolved CVEs."""
from __future__ import annotations

from typing import Optional

import httpx

from selvo.discovery.base import PackageRecord

# Full JSON dump of Debian security tracker — keyed by CVE ID
_DST_URL = "https://security-tracker.debian.org/tracker/data/json"
_DST_CACHE: Optional[dict] = None  # module-level cache so we only fetch once per run


async def _load_dst(client: httpx.AsyncClient) -> dict:
    global _DST_CACHE
    if _DST_CACHE is not None:
        return _DST_CACHE
    try:
        resp = await client.get(_DST_URL, timeout=30.0, follow_redirects=True)
        resp.raise_for_status()
        _DST_CACHE = resp.json()
    except Exception:
        _DST_CACHE = {}
    return _DST_CACHE or {}


def _is_resolved(cve_id: str, pkg_name: str, tracker_data: dict) -> bool:
    """Return True if Debian reports the CVE as resolved for this package."""
    cve_entry = tracker_data.get(cve_id, {})
    # DST format: {CVE: {pkg_name: {releases: {suite: {status: ..., urgency: ...}}}}}
    pkg_entry = cve_entry.get(pkg_name, {})
    releases = pkg_entry.get("releases", {})
    for suite_data in releases.values():
        status = suite_data.get("status", "")
        if status in ("resolved", "end-of-life"):
            return True
    return False


async def filter_resolved_cves(packages: list[PackageRecord]) -> list[PackageRecord]:
    """
    Remove CVE IDs that Debian has already resolved from each package's cve_ids list.
    Packages with no remaining CVEs keep their record but score lower.
    Only applies to debian/ubuntu ecosystem packages.
    """
    deb_packages = [p for p in packages if p.ecosystem in ("debian", "ubuntu")]
    if not deb_packages:
        return packages

    async with httpx.AsyncClient() as client:
        tracker = await _load_dst(client)

    if not tracker:
        return packages  # API unavailable — keep everything

    for pkg in deb_packages:
        open_cves = [
            cve for cve in pkg.cve_ids
            if not _is_resolved(cve, pkg.name, tracker)
        ]
        resolved_count = len(pkg.cve_ids) - len(open_cves)
        pkg.cve_ids = open_cves
        if resolved_count:
            pkg.description = (pkg.description + f" [{resolved_count} CVE(s) already resolved in Debian]").strip()

    return packages
