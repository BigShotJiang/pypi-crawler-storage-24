"""CVE enrichment via the OSV.dev API."""
from __future__ import annotations

import asyncio
import re
from typing import Optional

import httpx

from selvo.discovery.base import PackageRecord
from selvo.analysis import cache as _cache
from selvo.analysis.debian_index import DebianIndex, load_debian_index

_OSV_QUERY_URL = "https://api.osv.dev/v1/query"
_TTL = 86400  # 24 hours
# OSV allows ~10 req/s; cap concurrency so we don't hammer it
_SEM = asyncio.Semaphore(8)

# Matches canonical CVE IDs and GitHub Security Advisories.
_CVE_RE = re.compile(r"^(CVE-\d{4}-\d+|GHSA-[0-9a-z-]+)$", re.IGNORECASE)

# Many OSV ecosystems (Debian, Red Hat, …) use distro-specific advisory IDs
# like DEBIAN-CVE-2024-5535, DSA-1234, RHSA-2024:1234. The canonical CVE ID is
# sometimes embedded in the advisory ID itself (DEBIAN-CVE-*) and is always
# available in the `aliases` list of the vuln object.
_DEBIAN_CVE_RE = re.compile(r"^DEBIAN-(CVE-\d{4}-\d+)$", re.IGNORECASE)


def _extract_real_cves(vuln: dict) -> list[str]:
    """Extract canonical CVE/GHSA IDs from an OSV vuln object.

    Checks both the primary ``id`` and the ``aliases`` list so that
    distro-wrapped advisories (DEBIAN-CVE-*, DSA-*, RHSA-*, …) still
    contribute their underlying CVE ID.
    """
    ids: list[str] = []
    primary = vuln.get("id", "")
    if _CVE_RE.match(primary):
        ids.append(primary)
    else:
        # e.g. DEBIAN-CVE-2024-5535  →  CVE-2024-5535
        m = _DEBIAN_CVE_RE.match(primary)
        if m:
            ids.append(m.group(1).upper())
    for alias in vuln.get("aliases", []):
        if _CVE_RE.match(alias):
            ids.append(alias.upper() if alias.upper().startswith("CVE-") else alias)
    return ids


async def _fetch_cves(
    pkg: PackageRecord,
    client: httpx.AsyncClient,
    deb_index: Optional[DebianIndex] = None,
) -> list[str]:
    """Query OSV.dev for known vulnerabilities affecting a package.

    When a package has been merged across ecosystems (ecosystem field contains
    commas, e.g. "debian,ubuntu,fedora"), we query each distinct OSV ecosystem
    and union the results so packages like openssl/curl/gzip get their CVEs.

    For the Debian ecosystem OSV uses **source** package names (e.g. "bzip2",
    "expat", "glibc") rather than binary package names ("libbz2-1.0",
    "libexpat1", "libc6").  We resolve the name via the DebianIndex before
    querying so CVEs are not missed due to the binary↔source name mismatch.
    """
    # Map selvo/discovery ecosystem names → OSV ecosystem names.
    # Only include ecosystems that OSV actually tracks; Arch and NixOS do not
    # have dedicated OSV ecosystem entries, so advisories for those distros
    # are captured by querying the upstream ecosystem (Debian/Red Hat/Alpine).
    ecosystem_map = {
        "debian": "Debian",
        "ubuntu": "Ubuntu",
        "fedora": "Red Hat",
        "alpine": "Alpine",
        # arch and nixos intentionally omitted – not in OSV ecosystem list
    }

    # Resolve unique OSV ecosystems from the (possibly comma-joined) pkg.ecosystem
    parts = [e.strip() for e in pkg.ecosystem.split(",")]
    osv_ecosystems = list(dict.fromkeys(
        ecosystem_map[e] for e in parts if e in ecosystem_map
    ))
    if not osv_ecosystems:
        osv_ecosystems = ["Debian"]  # safe fallback

    all_ids: list[str] = []
    for osv_eco in osv_ecosystems:
        # For Debian, OSV indexes by SOURCE package name, not binary.
        # Resolve binary → source (e.g. libbz2-1.0 → bzip2, libc6 → glibc).
        # If the discovery name is already a source name (e.g. "openssl") the
        # lookup returns it unchanged.
        if osv_eco == "Debian" and deb_index is not None:
            osv_pkg_name = deb_index.source_name(pkg.name)
        else:
            osv_pkg_name = pkg.name

        cache_key = f"osv:{osv_eco}:{osv_pkg_name}"
        cached = _cache.get(cache_key)
        if cached is not None:
            all_ids.extend(cached)
            continue

        payload: dict = {"package": {"name": osv_pkg_name, "ecosystem": osv_eco}}
        if pkg.version and pkg.version != "unknown":
            payload["version"] = pkg.version

        try:
            async with _SEM:
                resp = await client.post(_OSV_QUERY_URL, json=payload, timeout=10.0)
                resp.raise_for_status()
            data = resp.json()
            ids: list[str] = []
            for vuln in data.get("vulns", []):
                ids.extend(_extract_real_cves(vuln))
            # Deduplicate within this ecosystem before caching
            ids = list(dict.fromkeys(ids))
            _cache.set_cache(cache_key, ids, _TTL)
            all_ids.extend(ids)
        except Exception:
            pass

    # Deduplicate preserving order
    seen: set[str] = set()
    result = []
    for vid in all_ids:
        if vid not in seen:
            seen.add(vid)
            result.append(vid)
    return result


async def enrich_cve(packages: list[PackageRecord]) -> list[PackageRecord]:
    """Annotate each PackageRecord with CVE IDs from OSV.dev.

    Loads the Debian package index first so CVE queries for Debian packages
    can translate binary package names to source package names (as required
    by the OSV Debian ecosystem).

    Packages that share a Debian source (e.g. libuuid1 and libblkid1 both
    come from util-linux) are grouped so OSV is queried only once per
    (ecosystem, source) combination.  Without this deduplication, concurrent
    asyncio.gather tasks would race to write the same cache key.
    """
    from collections import defaultdict

    deb_index = await load_debian_index()

    # Group packages by their canonical OSV lookup name to avoid duplicate
    # concurrent requests for binaries that share a source package.
    group_key_to_pkgs: dict[tuple[str, str], list[PackageRecord]] = defaultdict(list)
    for pkg in packages:
        primary_eco = pkg.ecosystem.split(",")[0].strip()
        if primary_eco == "debian":
            src = deb_index.source_name(pkg.name)
        else:
            src = pkg.name
        group_key_to_pkgs[(primary_eco, src)].append(pkg)

    # One representative per unique (ecosystem, source) key
    representatives = [group[0] for group in group_key_to_pkgs.values()]

    async with httpx.AsyncClient() as client:
        tasks = [_fetch_cves(rep, client, deb_index) for rep in representatives]
        results = await asyncio.gather(*tasks)

    # Distribute CVE lists back to every package in each source group
    for rep, cve_ids in zip(representatives, results):
        primary_eco = rep.ecosystem.split(",")[0].strip()
        src = deb_index.source_name(rep.name) if primary_eco == "debian" else rep.name
        for pkg in group_key_to_pkgs[(primary_eco, src)]:
            pkg.cve_ids = list(cve_ids)

    return packages
