"""
Container image scanning — extract OS package inventory from Docker images
without requiring a running Docker daemon.

Two modes:
  1. docker inspect   — use `docker inspect <image>` output (reads container FS)
                        Requires Docker CLI. Works for locally-pulled images.

  2. Manifest / layer analysis  — parse an OCI image layout or tarball exported
                        via `docker save`. Reads the OS release file and installed
                        package database from the layer tar.
                        Does NOT require Docker daemon.

Usage:
    from selvo.discovery.container import packages_from_docker_image
    packages = packages_from_docker_image("ubuntu:24.04")

    # Or from a saved tarball:
    from selvo.discovery.container import packages_from_image_tar
    packages = packages_from_image_tar("/path/to/image.tar")

Returns list[PackageRecord] with version_source="container".
"""
from __future__ import annotations

import io
import json
import logging
import subprocess
import tarfile
from pathlib import Path
from typing import Optional

from selvo.discovery.base import PackageRecord

log = logging.getLogger(__name__)


# ── Docker inspect / exec ─────────────────────────────────────────────────────

def _run(cmd: list[str]) -> Optional[str]:
    """Run a shell command and return stdout, or None on error."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            return result.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        log.debug("Command failed %s: %s", cmd[:3], exc)
    return None


def _dpkg_output_to_packages(output: str, ecosystem: str) -> list[PackageRecord]:
    """Parse `dpkg-query -W -f='${Package}\t${Version}\t${Description}\n'` output."""
    records = []
    for line in output.splitlines():
        parts = line.split("\t", 2)
        if len(parts) < 2:
            continue
        name, version = parts[0].strip(), parts[1].strip()
        desc = parts[2].strip()[:200] if len(parts) > 2 else ""
        if name and version and version != "<none>":
            records.append(PackageRecord(
                name=name,
                ecosystem=ecosystem,
                version=version,
                description=desc,
                version_source="container",
            ))
    return records


def _rpm_output_to_packages(output: str) -> list[PackageRecord]:
    """Parse `rpm -qa --queryformat '%{NAME}\t%{VERSION}-%{RELEASE}\n'` output."""
    records = []
    for line in output.splitlines():
        parts = line.split("\t", 1)
        if len(parts) < 2:
            continue
        name, version = parts[0].strip(), parts[1].strip()
        if name and version:
            records.append(PackageRecord(
                name=name,
                ecosystem="fedora",
                version=version,
                version_source="container",
            ))
    return records


def _apk_output_to_packages(output: str) -> list[PackageRecord]:
    """Parse `apk info -v` output: name-version pairs."""
    records = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        # apk info -v: pkgname-ver-rel format
        # Try to split at last dash-digit boundary
        import re
        m = re.match(r"^(.+)-(\d[^\s]*).*$", line)
        if m:
            records.append(PackageRecord(
                name=m.group(1),
                ecosystem="alpine",
                version=m.group(2),
                version_source="container",
            ))
    return records


def packages_from_docker_image(image: str) -> list[PackageRecord]:
    """
    Detect the OS inside a Docker container and extract its installed packages.

    Pulls the image if not present (via `docker run --rm`).
    Requires Docker CLI and Docker daemon access.

    Args:
        image:  Docker image reference (e.g. 'ubuntu:24.04', 'debian:bookworm-slim').

    Returns:
        list[PackageRecord] with version_source='container'.
    """
    # Detect OS to choose the right package manager
    os_release = _run(["docker", "run", "--rm", "--entrypoint", "cat", image, "/etc/os-release"])
    if not os_release:
        raise RuntimeError(f"Cannot read /etc/os-release from image '{image}'. Is Docker running?")

    os_id = ""
    for line in os_release.splitlines():
        if line.startswith("ID="):
            os_id = line.split("=", 1)[1].strip().strip('"').lower()
            break

    if os_id in ("debian", "ubuntu"):
        eco = "ubuntu" if os_id == "ubuntu" else "debian"
        out = _run([
            "docker", "run", "--rm", "--entrypoint", "dpkg-query",
            image, "-W", "-f=${Package}\t${Version}\t${Description}\n"
        ])
        return _dpkg_output_to_packages(out or "", eco)

    elif os_id in ("fedora", "centos", "rhel", "rocky", "alma"):
        out = _run([
            "docker", "run", "--rm", "--entrypoint", "rpm",
            image, "-qa", "--queryformat", "%{NAME}\t%{VERSION}-%{RELEASE}\n"
        ])
        return _rpm_output_to_packages(out or "")

    elif os_id == "alpine":
        out = _run(["docker", "run", "--rm", "--entrypoint", "apk", image, "info", "-v"])
        return _apk_output_to_packages(out or "")

    else:
        raise RuntimeError(
            f"Unsupported OS ID '{os_id}' in image '{image}'. "
            "selvo supports debian, ubuntu, fedora/rhel, and alpine containers."
        )


# ── Tarball / OCI layout analysis ────────────────────────────────────────────

def _read_file_from_layer(layer_tar: tarfile.TarFile, path: str) -> Optional[str]:
    """Try to read a file path from a layer tarball, returning text or None."""
    # OCI layer paths may have './' prefix or not
    for candidate in (path, "./" + path, path.lstrip("/")):
        try:
            member = layer_tar.getmember(candidate)
            f = layer_tar.extractfile(member)
            if f:
                return f.read().decode("utf-8", errors="replace")
        except KeyError:
            pass
    return None


def _parse_dpkg_status(status_text: str, ecosystem: str) -> list[PackageRecord]:
    """
    Parse a dpkg status file (var/lib/dpkg/status) into PackageRecord list.
    Format: RFC822-style records separated by blank lines.
    """
    records = []
    current: dict[str, str] = {}
    for line in status_text.splitlines():
        if line == "" or line == "\n":
            if current.get("Package") and current.get("Status", "").endswith("installed"):
                version = current.get("Version", "unknown")
                records.append(PackageRecord(
                    name=current["Package"],
                    ecosystem=ecosystem,
                    version=version,
                    description=current.get("Description", "")[:200],
                    version_source="container",
                ))
            current = {}
        elif ":" in line and not line.startswith(" "):
            k, _, v = line.partition(":")
            current[k.strip()] = v.strip()
    return records


def packages_from_image_tar(tar_path: str | Path) -> list[PackageRecord]:
    """
    Extract OS packages from a Docker image tarball (`docker save image > image.tar`).

    Does NOT require a running Docker daemon — reads the tarball directly.

    Args:
        tar_path:  Path to the image tar file.

    Returns:
        list[PackageRecord] with version_source='container'.
    """
    path = Path(tar_path)
    records: list[PackageRecord] = []

    with tarfile.open(path, "r:*") as outer:
        # Read manifest.json to get layer order
        try:
            manifest_f = outer.extractfile("manifest.json")
            manifest = json.loads(manifest_f.read()) if manifest_f else []
        except (KeyError, json.JSONDecodeError):
            manifest = []

        layer_paths: list[str] = []
        if manifest and isinstance(manifest, list):
            for entry in manifest:
                layer_paths.extend(entry.get("Layers", []))

        # Try each layer in order, last-writer-wins for package DB
        dpkg_status: Optional[str] = None
        os_id = ""

        for layer_path in reversed(layer_paths):
            try:
                layer_member = outer.getmember(layer_path)
                layer_f = outer.extractfile(layer_member)
                if not layer_f:
                    continue
                with tarfile.open(fileobj=io.BytesIO(layer_f.read()), mode="r:*") as layer:
                    # Detect OS
                    if not os_id:
                        os_rel = _read_file_from_layer(layer, "etc/os-release")
                        if os_rel:
                            for line in os_rel.splitlines():
                                if line.startswith("ID="):
                                    os_id = line.split("=", 1)[1].strip().strip('"').lower()
                                    break

                    # Try dpkg status
                    if not dpkg_status:
                        dpkg_status = _read_file_from_layer(layer, "var/lib/dpkg/status")

            except (KeyError, tarfile.TarError):
                pass

        if dpkg_status:
            eco = "ubuntu" if os_id == "ubuntu" else "debian"
            records = _parse_dpkg_status(dpkg_status, eco)
        elif not records:
            raise RuntimeError(
                "Could not find dpkg/rpm package database in image tarball. "
                "selvo currently supports debian/ubuntu-based images from tarballs."
            )

    return records
