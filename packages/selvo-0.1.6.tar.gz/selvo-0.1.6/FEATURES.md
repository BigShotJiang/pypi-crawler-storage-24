# selvo — What Is Actually Built

> Audit as of March 9, 2026 (post-`01e3e66`). Every item here is verified against the source code.
> "Functional" means it runs and produces output. It does not mean battle-tested in production.

---

## CLI (`selvo/cli.py`, 2,033 lines)

All 23 commands are implemented end-to-end. They work. Shipped.

| Command | What it does | Notes |
|---|---|---|
| `selvo analyze` | Discovers top packages per ecosystem, fetches CVEs, scores by blast radius + EPSS + exploit maturity, ranks | Core pipeline. Functional. |
| `selvo compliance` | Maps CVE findings to NIST 800-53, FedRAMP High, SOC 2, PCI-DSS v4.0, DoD IL4 | 33 CWEs mapped in `data/compliance_map.json`. Functional. |
| `selvo fleet` | SSH into a list of hosts, collect installed packages, merge into worst-case fleet view, full CVE pipeline. `--dry-run` validates SSH + PM detection without collecting data. | Functional. Never run against a real fleet. |
| `selvo sla` | Classifies packages into ok/warn/breach/critical bands by CVSS + days-open against configurable SLA | Functional. |
| `selvo scan` | Ingests CycloneDX SBOM, SPDX SBOM, Grype JSON, Trivy JSON, lock files (requirements.txt, package-lock.json, Cargo.lock, go.sum, Gemfile.lock, etc.), Docker image, Docker image tar | Functional. |
| `selvo trend` | Shows CVE count, KEV count, score over time from SQLite history | Requires ≥2 prior `analyze` runs. Functional. |
| `selvo diff` | Shows delta since last snapshot | Functional. |
| `selvo policy` | Policy-as-code enforcement via `selvo.policy.yml`; block/warn gates on KEV, CVSS, EPSS, SLA. `--format json` emits structured JSON for CI pipelines. | Functional. |
| `selvo test` | Risk regression gate — fails CI if posture worsened since baseline | Functional. |
| `selvo watch` | Continuous monitoring daemon with Slack Block Kit + PagerDuty Events v2 webhook alerts. All delivery paths have 3-attempt exponential backoff (2s/4s). | Functional (daemon mode). Not production-deployed. |
| `selvo deps` | Dependency confusion, namespace hijacking, typosquatting detection via Levenshtein-1 + PyPI/npm cross-check | Functional. |
| `selvo attest` | SLSA provenance verification via Sigstore Rekor; assigns SLSA level 0–3 per package | Functional. |
| `selvo patch` | Surfaces upstream PR/patch opportunities | Functional. |
| `selvo fix` | Opens upstream GitHub PRs to fix CVEs in top-scored packages | Functional. Requires GitHub PAT. |
| `selvo graph` | Builds and displays dependency graph via networkx | Functional. |
| `selvo discover` | Discovers most-used packages per ecosystem | Functional. |
| `selvo distro-compare` | Compares package versions across distros, shows supply-chain lag | Functional. |
| `selvo sla` | SLA breach reporting | Functional. |
| `selvo sync` | Downloads OSV, NVD, EPSS databases for offline/air-gap operation | Functional. |
| `selvo scan` | SBOM/container/lockfile input pipeline | Functional. |
| `selvo cache` | SQLite cache inspection and management | Functional. |
| `selvo api` | Starts FastAPI + uvicorn REST API server | Functional. Not deployed anywhere. |
| `selvo api-key` | Manages API keys for the SaaS REST API | Functional. |

---

## Discovery Ecosystems (`selvo/discovery/`)

| Ecosystem | Source | Lines | Status |
|---|---|---|---|
| Debian | packages.debian.org / Packages.gz | 74 | Functional |
| Ubuntu | Same as Debian | 74 | Functional |
| Fedora | Koji build system | 34 | Functional |
| Arch Linux | archlinux.org pkg API | 56 | Functional |
| Alpine Linux | pkgs.alpinelinux.org | 134 | Functional |
| NixOS | search.nixos.org | 125 | Functional |
| Homebrew | formulae.brew.sh | 130 | Functional |
| Chocolatey | community.chocolatey.org | 143 | Functional |
| Winget | winget-pkgs GitHub manifest | 115 | Functional |
| Container images | Docker daemon + tarball (no daemon) | 267 | Functional |
| Lock files | requirements.txt, package-lock.json, Cargo.lock, go.sum, Gemfile.lock, composer.json, *.csproj | 458 | Functional |
| SBOM (CycloneDX/SPDX) | JSON parse | 198 | Functional |
| Grype/Trivy JSON import | JSON parse | 201 | Functional |

---

## Analysis Pipeline (`selvo/analysis/`)

| Module | What it does | Lines | Status |
|---|---|---|---|
| `cve.py` | Fetches CVEs from OSV API per package | 174 | Functional |
| `epss.py` | Fetches EPSS probability scores from FIRST API | 162 | Functional |
| `cvss.py` | CVSS v3 score parsing + severity band | — | Functional |
| `exploit.py` | Exploit maturity scoring (weaponized/PoC/none) | — | Functional |
| `sla.py` | SLA breach classification | 156 | Functional |
| `compliance.py` | CWE → framework control mapping | 264 | Functional. 33 CWEs mapped. All CWEs have direct `nist`, `fedramp`, `dod`, `soc2`, `pci` control IDs — no NIST proxy for FedRAMP/DoD. |
| `fleet.py` | SSH host scanning + fleet merge + `dry_run_fleet()` connectivity validator | 313 | Functional |
| `osv_local.py` | OSV local mirror (SQLite, offline/air-gap) | 338 | Functional |
| `reachability.py` | Code reachability analysis (Go: govulncheck, Python: AST walk, Node.js: package.json + require/import regex scan) | 285 | Functional for Go/Python/Node.js; other stacks return "unknown" |
| `policy.py` | Policy-as-code engine | 398 | Functional |
| `trend.py` | Historical trend from SQLite snapshots | — | Functional |
| `upstream.py` | Upstream version tracking | — | Functional |
| `scorecard.py` | OpenSSF Scorecard integration | — | Functional |
| `ossfuzz.py` | OSS-Fuzz coverage data | — | Functional |
| `slsa.py` | SLSA provenance via Sigstore Rekor | — | Functional |
| `dep_confusion.py` | Dependency confusion detection | — | Functional |
| `distro_compare.py` | Cross-distro version lag | — | Functional |
| `watcher.py` | Watch daemon + Slack Block Kit / PagerDuty Events v2 / generic webhook alerts. 3-attempt exponential backoff on all delivery paths. | — | Functional |
| `llm.py` | LLM normalization (optional, for noisy package names) | — | Functional (requires API key) |
| `local_context.py` | Detects locally installed packages for reachability hint | — | Functional |
| `patch.py` / `patch_safety.py` | Upstream patch opportunity surfacing | — | Functional |
| `changelog.py` | Changelog scraping | — | Functional |
| `github.py` | GitHub API integration for upstream tracking | — | Functional |
| `advisories.py` | Advisory aggregation | — | Functional |
| `cve_timeline.py` | CVE age / timeline data | — | Functional |
| `graph_metrics.py` | networkx-based graph centrality metrics | — | Functional |
| `rdeps.py` | Reverse dependency count | — | Functional |
| `versions.py` | Version gap calculation | — | Functional |
| `fix.py` | PR opening logic | — | Functional |
| `collapse.py` | Binary→source package collapse | — | Functional |
| `cache.py` | SQLite cache layer | — | Functional |

---

## Scoring Engine (`selvo/prioritizer/scorer.py`, 164 lines)

Composite weighted score across:
- Version gap (semver distance)
- EPSS probability
- CVSS severity
- Transitive reverse dependency count (blast radius)
- Direct reverse dependency count
- Betweenness centrality (graph)
- Download/usage weight
- Exploit exposure
- Exploit maturity (weaponized > PoC > none)

---

## API Server (`selvo/api/`, ~700 lines total)

Not deployed. Code is complete. 29 endpoints. Dashboard supports `SELVO_OFFLINE_ASSETS=1` env var for air-gap/DoD IL4 deployments (inline CSS + fetch-based htmx substitute, no CDN calls).

| Category | Endpoints |
|---|---|
| Health / status | `GET /api/v1/status` |
| Package data | `GET /packages`, `GET /packages/{name}`, `GET /snapshot` |
| CVE / exploits | `GET /cves`, `GET /exploits`, `GET /advisories` |
| Patch | `GET /patch-plan` |
| Diff / trend | `GET /diff` |
| SLA | `GET /sla` |
| Analysis jobs | `POST /analyze` (async), `GET /jobs/{job_id}` |
| Fleet | `POST /fleet/scan` (async) |
| SBOM scan | `POST /scan` (async) |
| Reports | `GET /report.sarif`, `GET /report.vex` |
| Orgs / keys | `POST /orgs`, `GET /orgs/{id}/keys`, `POST/DELETE /orgs/{id}/keys/{hash}` |
| Billing | `POST /billing/checkout`, `POST /billing/webhook` |
| Dashboard (HTML) | `/dash/overview`, `/dash/packages`, `/dash/cves`, `/dash/trends`, `/dash/keys` |

Auth: HMAC-SHA256 API key verification on all data endpoints.
Multi-tenancy: per-org SQLite snapshot isolation via `selvo/api/tenancy.py`.
Billing: Stripe checkout session creation + webhook event handler (subscription created/updated/deleted/payment failed).

---

## MCP Server (`selvo/mcp_server.py`, 1,057 lines)

14 MCP tools for Claude/LLM integration:
`analyze_packages`, `get_snapshot`, `check_local_risk`, `describe_package`, `list_cves`, `get_upstream_watchlist`, `patch_plan`, `fleet_scan`, `distro_lag`, `check_exploits`, `get_epss_velocity`, `get_distro_patch_dates`, `get_sla_report`, `check_advisories`, `get_changelog_summary`

README documents Claude Desktop config block (`mcpServers` JSON) and the full tool list. Direct run: `uvx selvo mcp`.

---

## Output Reporters (`selvo/reporters/`)

| Format | Lines | Notes |
|---|---|---|
| Terminal (Rich table) | 188 | Functional |
| JSON | 50 | Functional |
| Markdown | 55 | Functional |
| HTML | 505 | Functional — used for public Pages report |
| SARIF 2.1.0 | 266 | Functional — GitHub Security tab compatible |
| CycloneDX SBOM | 109 | Functional |
| VEX (CycloneDX VEX) | 182 | Functional |

No PDF reporter. The output chain is: terminal / JSON / Markdown / HTML / SARIF / SBOM / VEX.

---

## GitHub Action (`.github/actions/selvo-scan/action.yml`, 193 lines)

Complete, published-ready. Marketplace `branding` block added (`icon: shield`, `color: red`). Inputs:
- `ecosystem` (debian/ubuntu/fedora/arch/alpine/nixos/all)
- `limit` (max packages)
- `fail-on-kev` (exit 1 if KEV-listed CVE found)
- `fail-on-weaponized` (exit 1 if weaponized exploit)
- `min-score` (exit 1 if composite score exceeds threshold)
- `post-comment` (post PR comment with risk table via GITHUB_TOKEN)
- `selvo-version`, `extra-args`

Not published to GitHub Marketplace. Branding is now set — submission requires clicking through marketplace.github.com with a tag push.

---

## VS Code Extension (`vscode-extension/src/extension.ts`, 506 lines)

Not scaffolded — substantially implemented. Includes:
- Scanner: runs `selvo scan --format json` as subprocess (or remote API call), caches results per workspace folder
- Decorator: applies underlines + status-bar icons to vulnerable package references in supported files
- HoverProvider: rich MDString hover card showing CVSS, EPSS, KEV status, blast radius, `selvo fix` button
- StatusBar: "⚡ selvo: N CVEs · K KEV" summary
- Commands: scan, scanWorkspace, fix, clearCache, openDashboard, **setApiKey**
- API key stored in VS Code Secret Storage (`context.secrets`); plaintext `selvo.apiKey` setting deprecated with migration notice
- Supported file patterns: requirements.txt, Pipfile, pyproject.toml, package.json, package-lock.json, yarn.lock, Cargo.toml, Cargo.lock, go.mod, go.sum, Gemfile, pom.xml, build.gradle, composer.json, *.csproj, packages.config

Not published to VS Code Marketplace. Secret Storage requirement unblocks Marketplace submission.

---

## Helm Chart (`helm/selvo/`)

Complete YAML. All `your-org` placeholders replaced with `sethc5` / `selvo.dev` in `Chart.yaml` (home, sources, maintainer email) and `values.yaml` (image repository). Never deployed. Requires container image to exist in a real registry before use.

---

## Policy-as-Code (`selvo.policy.yml`, `selvo/analysis/policy.py`)

YAML-driven policy file. Gates: block on KEV, weaponized exploits, min CVSS, min EPSS, min composite score. Warn gates: PoC, high CVSS, EPSS threshold. CVE allow-list with expiry dates. Slack + PagerDuty notification hooks. 398-line enforcement engine. `selvo policy check --format json` emits structured JSON (`passed`, `blocked[]`, `warnings[]`, `allowed_cves[]`) for CI pipeline consumption.

---

## CI / Release Pipelines (`.github/workflows/`)

| Workflow | Trigger | What it does |
|---|---|---|
| `ci.yml` | push / PR | pytest, ruff, mypy |
| `pages.yml` | weekly / push to main | `selvo analyze` → HTML report → GitHub Pages |
| `release.yml` | `v*` tag push | build sdist+wheel → PyPI (OIDC trusted publishing); build VSIX → VS Code Marketplace (if `VSCE_PUBLISH=true`) |
| `docker.yml` | push to main / `v*` tag | multi-arch (amd64+arm64) Docker build → `ghcr.io/sethc5/selvo` |

All workflows are complete. External accounts/secrets still required for PyPI, VS Code Marketplace, and GHCR publishing.

---

## Tests (`tests/`, 165 tests)

Covers: API auth, billing webhook, compliance mapping, dashboard per-org isolation, discovery endpoints, OSV local, policy engine, reachability, scorer, SLSA. All 165 pass in 0.34s.

---

## What Does Not Exist

| Item | Reality |
|---|---|
| PDF reporter | Not implemented. HTML and Markdown are the closest outputs. |
| Container image in any registry | No Docker Hub, GHCR, or ECR image exists. |
| Deployed API | No Fly.io, Railway, or any cloud deployment. |
| Stripe account | No account, no products, no test-mode configured. |
| PyPI package | Not published. |
| GitHub Actions Marketplace listing | Not published. |
| VS Code Marketplace listing | Not published. |
| ~~FedRAMP/DoD control mappings missing~~ | Fixed. All 33 CWEs now have direct `fedramp` and `dod` control IDs in `compliance_map.json`. `--framework fedramp` and `--framework dod` no longer proxy through NIST. |
| LLC / legal entity | Not filed. |
| Domain / business email | `selvo.dev` used in Helm chart; no confirmed registration or MX. |
