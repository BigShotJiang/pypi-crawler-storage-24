"""TMS MCP Server — exposes TMS task management tools to Claude Code."""

import sys
import os

# Ensure the package root is importable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mcp.server.fastmcp import FastMCP

from tools import auth, organizations, projects, tasks, users
import resources

mcp = FastMCP(
    "tms",
    instructions=(
        "TMS (Task Management System) tools for managing organizations, projects, and tasks. "
        "Before using any tool, authenticate with tms_login using your email and password."
    ),
)

# Register all tool modules
auth.register(mcp)
organizations.register(mcp)
projects.register(mcp)
tasks.register(mcp)
users.register(mcp)

# Register resources
resources.register(mcp)

if __name__ == "__main__":
    mcp.run(transport="stdio")
