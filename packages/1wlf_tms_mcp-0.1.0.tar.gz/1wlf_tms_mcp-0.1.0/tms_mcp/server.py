"""TMS MCP Server — exposes TMS task management tools to Claude Code."""

from mcp.server.fastmcp import FastMCP

from tms_mcp.tools import auth, organizations, projects, tasks, users
from tms_mcp import resources

mcp = FastMCP(
    "tms",
    instructions=(
        "TMS (Task Management System) tools for managing organizations, projects, and tasks. "
        "Before using any tool, authenticate with tms_login using your email and password."
    ),
)

# Register all tool modules
auth.register(mcp)
organizations.register(mcp)
projects.register(mcp)
tasks.register(mcp)
users.register(mcp)

# Register resources
resources.register(mcp)
