"""MCP resource definitions for browsing TMS data."""

import json

from api_client import ApiError, client


def register(mcp):
    @mcp.resource("tms://me")
    async def get_current_user() -> str:
        """Current authenticated user info."""
        try:
            data = await client.get("/auth/me")
            return json.dumps(data, indent=2, default=str)
        except ApiError as e:
            return str(e)

    @mcp.resource("tms://organizations")
    async def list_organizations() -> str:
        """All organizations the user belongs to."""
        try:
            data = await client.get("/organizations/")
            return json.dumps(data, indent=2, default=str)
        except ApiError as e:
            return str(e)

    @mcp.resource("tms://organizations/{org_id}/projects")
    async def list_org_projects(org_id: int) -> str:
        """Projects within a specific organization."""
        try:
            data = await client.get("/projects/", organization_id=org_id)
            return json.dumps(data, indent=2, default=str)
        except ApiError as e:
            return str(e)

    @mcp.resource("tms://projects/{project_id}/tasks")
    async def list_project_tasks(project_id: int) -> str:
        """All tasks in a specific project."""
        try:
            data = await client.get("/tasks/", project_id=project_id)
            return json.dumps(data, indent=2, default=str)
        except ApiError as e:
            return str(e)
