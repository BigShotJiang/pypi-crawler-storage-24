# image-data-extracter

Python library (and optional API) that extracts metadata from an image file.

## Features
- Basic metadata: format, dimensions, mode, color profile info, file size, hashes
- EXIF metadata (when present), including GPS and orientation
- CLI: print JSON metadata for a local file
- Optional FastAPI endpoint: upload an image and get metadata back

## Install (local)
```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -U pip
python3 -m pip install -e ".[api]"
```

## Library usage
```python
from image_data_extractor import extract_metadata

metadata = extract_metadata("path/to/image.jpg")
print(metadata["image"]["width"], metadata["image"]["height"])
```

## CLI usage
```bash
python3 -m image_data_extractor path/to/image.jpg --pretty
```

## API usage (optional)
```bash
python3 -m pip install -e ".[api]"
uvicorn app.main:app --reload
```

Then POST a multipart upload:
```bash
curl -s \
  -F "file=@path/to/image.jpg" \
  "http://127.0.0.1:8000/metadata?pretty=1"
```

## Web UI (optional)
When the API is running, open:
- `http://127.0.0.1:8000/` (upload UI)
- `http://127.0.0.1:8000/docs` (Swagger)

## Development
```bash
python3 -m pip install -e ".[dev,api]"
pytest -q
```
