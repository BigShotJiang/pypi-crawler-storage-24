from __future__ import annotations

import argparse
import json
import sys

from .extractor import extract_metadata


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="imeta", description="Extract image metadata as JSON.")
    p.add_argument("path", help="Path to an image file")
    p.add_argument("--no-exif", action="store_true", help="Disable EXIF extraction")
    p.add_argument("--include-icc", action="store_true", help="Include ICC profile (base64)")
    p.add_argument("--no-hashes", action="store_true", help="Disable hashing (md5/sha256)")
    p.add_argument("--pretty", action="store_true", help="Pretty-print JSON")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    try:
        result = extract_metadata(
            args.path,
            include_exif=not args.no_exif,
            include_icc=args.include_icc,
            compute_hashes=not args.no_hashes,
        )
    except Exception as exc:  # noqa: BLE001
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if args.pretty:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(json.dumps(result))
    return 0

