from __future__ import annotations

import base64
from datetime import datetime
from typing import Any


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def to_jsonable(value: Any) -> Any:
    if value is None:
        return None

    if isinstance(value, (str, int, float, bool)):
        return value

    if isinstance(value, bytes):
        # Avoid dumping raw binary; keep it JSON-safe.
        return {"encoding": "base64", "data": _b64(value), "length": len(value)}

    if isinstance(value, datetime):
        return value.isoformat()

    # PIL rationals and similar numeric wrappers
    if hasattr(value, "numerator") and hasattr(value, "denominator"):
        try:
            return float(value)
        except Exception:  # noqa: BLE001
            return str(value)

    if isinstance(value, (list, tuple, set)):
        return [to_jsonable(v) for v in value]

    if isinstance(value, dict):
        return {str(k): to_jsonable(v) for k, v in value.items()}

    return str(value)

