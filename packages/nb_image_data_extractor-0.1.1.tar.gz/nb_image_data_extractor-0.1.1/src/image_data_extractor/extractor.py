from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from datetime import datetime
from io import BytesIO
from typing import Any, BinaryIO, Dict, Union

try:
    from PIL import Image, UnidentifiedImageError
    from PIL.ExifTags import GPSTAGS, TAGS
except ModuleNotFoundError:  # pragma: no cover
    Image = None  # type: ignore[assignment]
    UnidentifiedImageError = Exception  # type: ignore[assignment]
    GPSTAGS = {}  # type: ignore[assignment]
    TAGS = {}  # type: ignore[assignment]

from ._json import to_jsonable


_FORMAT_TO_MIME = {
    "JPEG": "image/jpeg",
    "PNG": "image/png",
    "GIF": "image/gif",
    "WEBP": "image/webp",
    "TIFF": "image/tiff",
    "BMP": "image/bmp",
    "ICO": "image/x-icon",
    "HEIF": "image/heif",
    "HEIC": "image/heic",
    "AVIF": "image/avif",
}


@dataclass(frozen=True)
class ExtractOptions:
    include_exif: bool = True
    include_icc: bool = False
    compute_hashes: bool = True


PathOrFile = Union[str, os.PathLike[str], BinaryIO]


def _read_all(fileobj: BinaryIO, max_bytes: int | None = None) -> bytes:
    data = fileobj.read()
    if max_bytes is not None and len(data) > max_bytes:
        raise ValueError(f"Input too large (>{max_bytes} bytes).")
    return data


def _maybe_stat_size(path: str | os.PathLike[str]) -> int | None:
    try:
        return os.stat(path).st_size
    except Exception:  # noqa: BLE001
        return None


def _hashes(data: bytes) -> dict[str, str]:
    return {
        "md5": hashlib.md5(data).hexdigest(),  # noqa: S324
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def _exif_dict(image: Image.Image) -> dict[str, Any]:
    exif = image.getexif()
    if not exif:
        return {}

    out: dict[str, Any] = {}
    gps_out: dict[str, Any] = {}

    for tag_id, value in exif.items():
        tag_name = TAGS.get(tag_id, str(tag_id))
        if tag_name == "GPSInfo" and isinstance(value, dict):
            for gps_id, gps_value in value.items():
                gps_name = GPSTAGS.get(gps_id, str(gps_id))
                gps_out[gps_name] = gps_value
        else:
            out[tag_name] = value

    if gps_out:
        out["GPSInfo"] = gps_out

    return out


def _parse_datetime(exif: dict[str, Any]) -> dict[str, str]:
    # Common EXIF datetime keys: DateTimeOriginal, DateTimeDigitized, DateTime
    result: dict[str, str] = {}
    for key in ("DateTimeOriginal", "DateTimeDigitized", "DateTime"):
        value = exif.get(key)
        if not value:
            continue
        if isinstance(value, str):
            # EXIF typically uses "YYYY:MM:DD HH:MM:SS"
            try:
                dt = datetime.strptime(value, "%Y:%m:%d %H:%M:%S")
                result[key] = dt.isoformat()
            except Exception:  # noqa: BLE001
                result[key] = value
        else:
            result[key] = str(value)
    return result


def extract_metadata(
    source: PathOrFile,
    *,
    filename: str | None = None,
    include_exif: bool = True,
    include_icc: bool = False,
    compute_hashes: bool = True,
) -> Dict[str, Any]:
    """
    Extract metadata from an image path or binary file-like object.

    Returns a JSON-serializable dict.
    """
    options = ExtractOptions(
        include_exif=include_exif,
        include_icc=include_icc,
        compute_hashes=compute_hashes,
    )

    if Image is None:  # pragma: no cover
        raise ImportError('Missing dependency "Pillow". Install with: python3 -m pip install Pillow')

    data: bytes | None = None
    file_size_bytes: int | None = None
    display_name: str | None = filename

    if isinstance(source, (str, os.PathLike)):
        path = os.fspath(source)
        display_name = display_name or os.path.basename(path)
        file_size_bytes = _maybe_stat_size(path)
        with open(path, "rb") as f:
            data = _read_all(f)
    else:
        # Accept file-like; best-effort read all bytes so we can hash.
        display_name = display_name or getattr(source, "name", None)
        # Try to avoid breaking callers that want to re-use the stream.
        try:
            if hasattr(source, "seek") and hasattr(source, "tell"):
                pos = source.tell()
                source.seek(0)
                data = _read_all(source)
                source.seek(pos)
            else:
                data = _read_all(source)
        except Exception:  # noqa: BLE001
            # Fallback: attempt a plain read without seeking.
            data = _read_all(source)

        file_size_bytes = len(data)

    if data is None:
        raise ValueError("No input data.")

    try:
        image = Image.open(BytesIO(data))
        image.load()
    except UnidentifiedImageError as exc:
        raise ValueError("Unsupported or invalid image.") from exc

    fmt = image.format or "UNKNOWN"
    mime = _FORMAT_TO_MIME.get(fmt)

    result: dict[str, Any] = {
        "file": {
            "filename": display_name,
            "size_bytes": file_size_bytes,
            "mime_type": mime,
            "format": fmt,
        },
        "image": {
            "width": image.width,
            "height": image.height,
            "mode": image.mode,
        },
        "hashes": _hashes(data) if options.compute_hashes else None,
        "exif": None,
        "warnings": [],
    }

    # Extra info provided by Pillow decoders.
    info_out: dict[str, Any] = {}
    for key, value in (image.info or {}).items():
        if key == "icc_profile" and not options.include_icc:
            info_out[key] = {"skipped": True, "reason": "icc_profile disabled"}
        elif key == "exif":
            # The raw EXIF bytes; we expose parsed EXIF below when enabled.
            info_out[key] = {"skipped": True, "reason": "raw exif bytes omitted"}
        else:
            info_out[key] = to_jsonable(value)
    if options.include_icc and "icc_profile" in (image.info or {}):
        icc = image.info.get("icc_profile")
        if isinstance(icc, (bytes, bytearray)):
            info_out["icc_profile"] = {
                "encoding": "base64",
                "length": len(icc),
                "data": to_jsonable(bytes(icc))["data"],  # type: ignore[index]
            }
    if info_out:
        result["image"]["info"] = info_out

    if options.include_exif:
        exif = _exif_dict(image)
        if exif:
            parsed_dt = _parse_datetime(exif)
            if parsed_dt:
                exif["_datetime"] = parsed_dt
            result["exif"] = to_jsonable(exif)
        else:
            result["exif"] = {}
            result["warnings"].append("No EXIF metadata found.")
    else:
        result["exif"] = {"skipped": True}

    return result
