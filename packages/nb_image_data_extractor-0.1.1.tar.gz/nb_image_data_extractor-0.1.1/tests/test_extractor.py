import io

import pytest


PIL = pytest.importorskip("PIL")


def test_extract_metadata_from_bytesio():
    from PIL import Image

    from image_data_extractor import extract_metadata

    buf = io.BytesIO()
    Image.new("RGB", (32, 16), color=(255, 0, 0)).save(buf, format="PNG")
    buf.seek(0)

    meta = extract_metadata(buf, filename="test.png")
    assert meta["file"]["filename"] == "test.png"
    assert meta["file"]["format"] == "PNG"
    assert meta["image"]["width"] == 32
    assert meta["image"]["height"] == 16
    assert meta["hashes"]["sha256"]

