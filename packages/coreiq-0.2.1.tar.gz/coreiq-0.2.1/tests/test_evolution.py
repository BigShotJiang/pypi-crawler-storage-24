"""Tests for evolution module."""
import pytest

from coreiq.evolution.bandit import PromptBandit
from coreiq.evolution.dicl import ExampleStore, Example
from coreiq.evolution.finetune import FinetuneDataset, TrainingPair


# ── Bandit ────────────────────────────────────────────────────────────────────

def test_bandit_selects_from_variants():
    bandit = PromptBandit(["v1", "v2", "v3"])
    selected = bandit.select()
    assert selected in ["v1", "v2", "v3"]


def test_bandit_learns_winner():
    bandit = PromptBandit(["good", "bad"])
    # Give good variant 100 successes
    for _ in range(100):
        bandit.reward("good", 1.0)
        bandit.reward("bad", 0.0)
    assert bandit.best() == "good"


def test_bandit_stats_keys():
    bandit = PromptBandit(["v1", "v2"])
    bandit.reward("v1", 1.0)
    stats = bandit.stats()
    assert len(stats) == 2
    assert all("variant_id" in s and "win_rate" in s for s in stats)


def test_bandit_add_variant():
    bandit = PromptBandit(["v1"])
    bandit.add_variant("v2")
    assert bandit.select() in ["v1", "v2"]


# ── DICL / ExampleStore ───────────────────────────────────────────────────────

def test_example_store_add_and_retrieve():
    store = ExampleStore()
    store.add(Example(id="e1", input="What is the capital of France?", output="Paris"))
    store.add(Example(id="e2", input="What is the capital of Germany?", output="Berlin"))
    results = store.retrieve("capital of France", k=1)
    assert len(results) == 1
    assert results[0].id == "e1"


def test_example_store_to_messages():
    store = ExampleStore()
    store.add(Example(id="e1", input="Hello", output="Hi there"))
    examples = store.retrieve("Hello", k=1)
    msgs = store.to_messages(examples)
    assert len(msgs) == 2
    assert msgs[0]["role"] == "user"
    assert msgs[1]["role"] == "assistant"


def test_example_store_remove():
    store = ExampleStore()
    store.add(Example(id="e1", input="test", output="result"))
    assert len(store) == 1
    removed = store.remove("e1")
    assert removed is True
    assert len(store) == 0


def test_example_store_empty_retrieve():
    store = ExampleStore()
    results = store.retrieve("anything", k=3)
    assert results == []


# ── FinetuneDataset ───────────────────────────────────────────────────────────

def test_finetune_add_pair():
    ds = FinetuneDataset()
    ds.add(TrainingPair(prompt="Q: what?", completion="A: this."))
    assert len(ds) == 1


def test_finetune_from_thumbs_up():
    ds = FinetuneDataset()
    pair = ds.add_from_feedback(
        prompt="Hello", completion="Hi",
        signal="thumbs_up",
    )
    assert pair is not None
    assert pair.quality_score == 1.0


def test_finetune_from_thumbs_down_skipped():
    ds = FinetuneDataset()
    pair = ds.add_from_feedback(
        prompt="Hello", completion="Hi",
        signal="thumbs_down",
    )
    assert pair is None
    assert len(ds) == 0


def test_finetune_from_correction():
    ds = FinetuneDataset()
    pair = ds.add_from_feedback(
        prompt="What is 2+2?", completion="5",
        signal="correction", correction="4",
    )
    assert pair is not None
    assert pair.completion == "4"


def test_finetune_export_jsonl(tmp_path):
    ds = FinetuneDataset()
    ds.add(TrainingPair(prompt="Q", completion="A", quality_score=1.0))
    path = str(tmp_path / "train.jsonl")
    count = ds.export_jsonl(path, fmt="openai")
    assert count == 1
    import json
    with open(path) as f:
        record = json.loads(f.read().strip())
    assert "messages" in record
    assert record["messages"][0]["role"] == "user"


def test_finetune_stats():
    ds = FinetuneDataset(min_quality_score=0.7)
    ds.add(TrainingPair(prompt="A", completion="B", quality_score=0.9))
    ds.add(TrainingPair(prompt="C", completion="D", quality_score=0.3))
    stats = ds.stats
    assert stats["total"] == 2
    assert stats["ready"] == 1


# ── Evolution SDK ─────────────────────────────────────────────────────────────

@pytest.fixture()
def _reset_evo_writer(tmp_path, monkeypatch):
    monkeypatch.setenv("COREIQ_DB_PATH", str(tmp_path / "evo_test.db"))
    import coreiq.store.writer as w
    import coreiq.store.db as db
    w._writer = None
    db._shared_conn = None
    db._shared_conn_path = None
    yield
    w._writer = None
    db._shared_conn = None
    db._shared_conn_path = None


def test_evolution_sdk_add_and_select(_reset_evo_writer):
    from coreiq.evolution.sdk import EvolutionSDK
    sdk = EvolutionSDK()
    sdk.add_variant("v1")
    sdk.add_variant("v2")
    result = sdk.select()
    assert result is not None
    assert result.id in ("v1", "v2")


def test_evolution_sdk_record_outcome_updates_best(_reset_evo_writer):
    from coreiq.evolution.sdk import EvolutionSDK
    sdk = EvolutionSDK()
    sdk.add_variant("good")
    sdk.add_variant("bad")
    for _ in range(20):
        sdk.record_outcome("good", "thumbs_up")
        sdk.record_outcome("bad", "thumbs_down")
    best = sdk.best()
    assert best is not None
    assert best.id == "good"


def test_evolution_sdk_persist_survives_restart(_reset_evo_writer):
    from coreiq.evolution.sdk import EvolutionSDK
    sdk = EvolutionSDK()
    sdk.add_variant("v1")
    for _ in range(10):
        sdk.record_outcome("v1", "thumbs_up")

    # Simulate restart: create fresh SDK (new _bandit = None, reloads from DB)
    sdk2 = EvolutionSDK()
    best = sdk2.best()
    assert best is not None
    assert best.id == "v1"
    assert best.samples == 10


def test_evolution_sdk_add_variant_with_prompt(_reset_evo_writer):
    from coreiq.evolution.sdk import EvolutionSDK
    sdk = EvolutionSDK()
    sdk.add_variant("v1", prompt="You are a helpful assistant.")
    sdk.add_variant("v2", prompt="You are a concise expert.")
    result = sdk.select()
    assert result is not None
    assert result.prompt in ("You are a helpful assistant.", "You are a concise expert.")
    assert result.prompt == sdk.get_prompt(result.id)


def test_evolution_sdk_best_returns_prompt(_reset_evo_writer):
    from coreiq.evolution.sdk import EvolutionSDK
    sdk = EvolutionSDK()
    sdk.add_variant("good", prompt="Be helpful")
    sdk.add_variant("bad", prompt="Be terse")
    for _ in range(20):
        sdk.record_outcome("good", "thumbs_up")
        sdk.record_outcome("bad", "thumbs_down")
    best = sdk.best()
    assert best is not None
    assert best.id == "good"
    assert best.prompt == "Be helpful"


def test_evolution_sdk_get_prompt(_reset_evo_writer):
    from coreiq.evolution.sdk import EvolutionSDK
    sdk = EvolutionSDK()
    sdk.add_variant("v1", prompt="Hello prompt")
    assert sdk.get_prompt("v1") == "Hello prompt"
    assert sdk.get_prompt("nonexistent") == ""


def test_evolution_sdk_add_variant_no_prompt(_reset_evo_writer):
    from coreiq.evolution.sdk import EvolutionSDK
    sdk = EvolutionSDK()
    sdk.add_variant("v1")
    result = sdk.select()
    assert result is not None
    assert result.prompt == ""


# ── Budget integration in adapters ───────────────────────────────────────────

def test_openai_adapter_budget_called():
    from unittest.mock import MagicMock, patch
    from coreiq.models.adapters.openai import create_chat_completion

    mock_client = MagicMock()
    mock_usage = MagicMock()
    mock_usage.prompt_tokens = 100
    mock_usage.completion_tokens = 50
    mock_choice = MagicMock()
    mock_choice.finish_reason = "stop"
    mock_response = MagicMock()
    mock_response.usage = mock_usage
    mock_response.choices = [mock_choice]
    mock_client.chat.completions.create.return_value = mock_response

    mock_budget = MagicMock()

    with patch("coreiq.models.adapters.openai.get_writer") as mock_writer:
        mock_writer.return_value = MagicMock()
        create_chat_completion(
            mock_client,
            model="gpt-4",
            messages=[{"role": "user", "content": "hi"}],
            budget=mock_budget,
        )

    mock_budget.record.assert_called_once_with(tokens=150)


def test_anthropic_adapter_budget_called():
    from unittest.mock import MagicMock, patch
    from coreiq.models.adapters.anthropic import create_message

    mock_client = MagicMock()
    mock_usage = MagicMock()
    mock_usage.input_tokens = 200
    mock_usage.output_tokens = 80
    mock_response = MagicMock()
    mock_response.usage = mock_usage
    mock_response.stop_reason = "end_turn"
    mock_client.messages.create.return_value = mock_response

    mock_budget = MagicMock()

    with patch("coreiq.models.adapters.anthropic.get_writer") as mock_writer:
        mock_writer.return_value = MagicMock()
        create_message(
            mock_client,
            model="claude-sonnet-4-6",
            messages=[{"role": "user", "content": "hi"}],
            budget=mock_budget,
        )

    mock_budget.record.assert_called_once_with(tokens=280)
