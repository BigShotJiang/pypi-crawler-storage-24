"""Tests for context-variable trace propagation."""
import pytest
import uuid

from coreiq.tracing import trace, get_current_trace_id


@pytest.fixture(autouse=True)
def _reset_writer(tmp_path, monkeypatch):
    monkeypatch.setenv("COREIQ_DB_PATH", str(tmp_path / "test.db"))
    import coreiq.store.writer as w
    import coreiq.store.db as db
    w._writer = None
    db._shared_conn = None
    db._shared_conn_path = None
    yield
    w._writer = None
    db._shared_conn = None
    db._shared_conn_path = None


def test_trace_sets_trace_id():
    with trace("my-task") as span:
        assert get_current_trace_id() == span.id
        assert isinstance(span.id, str)
        assert len(span.id) == 36  # UUID


def test_trace_resets_after_exit():
    with trace("task"):
        pass
    assert get_current_trace_id() is None


def test_trace_nesting():
    with trace("outer") as outer:
        outer_id = get_current_trace_id()
        with trace("inner") as inner:
            assert get_current_trace_id() == inner.id
            assert inner.id != outer.id
        assert get_current_trace_id() == outer_id


def test_log_event_auto_picks_trace_id():
    import coreiq
    from coreiq.store.writer import get_writer

    with trace("auto-trace") as span:
        eid = coreiq.log_event("step inside trace")

    writer = get_writer()
    row = writer._conn.execute("SELECT trace_id FROM events WHERE id=?", (eid,)).fetchone()
    assert row["trace_id"] == span.id


def test_log_event_explicit_trace_id_wins():
    import coreiq
    from coreiq.store.writer import get_writer

    explicit_id = str(uuid.uuid4())
    with trace("some-trace"):
        eid = coreiq.log_event("event with explicit", trace_id=explicit_id)

    writer = get_writer()
    row = writer._conn.execute("SELECT trace_id FROM events WHERE id=?", (eid,)).fetchone()
    assert row["trace_id"] == explicit_id
