"""Tests for EventWriter — store/writer.py"""
import pytest
import uuid
from pathlib import Path
import tempfile

from coreiq.store.writer import EventWriter


@pytest.fixture
def writer(tmp_path):
    db = tmp_path / "test.db"
    return EventWriter(db_path=db)


def test_insert_trace(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="gpt-4o", provider="openai",
        input_tok=100, output_tok=50, latency_ms=420,
    )
    row = writer._conn.execute("SELECT * FROM traces WHERE id=?", (tid,)).fetchone()
    assert row is not None
    assert row["model"] == "gpt-4o"
    assert row["input_tok"] == 100
    assert row["latency_ms"] == 420
    assert row["finish_reason"] == "stop"


def test_insert_cache_event(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="gpt-4o", provider="openai",
        input_tok=10, output_tok=5, latency_ms=100,
    )
    writer.insert_cache_event(trace_id=tid, hit=True, similarity=0.95, saved_tok=200)
    row = writer._conn.execute("SELECT * FROM cache_events WHERE trace_id=?", (tid,)).fetchone()
    assert row["hit"] == 1
    assert row["similarity"] == pytest.approx(0.95)


def test_insert_tool_call(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="claude-sonnet-4-6", provider="anthropic",
        input_tok=50, output_tok=20, latency_ms=300,
    )
    writer.insert_tool_call(trace_id=tid, tool_name="search", args_json='{"q":"test"}')
    row = writer._conn.execute("SELECT * FROM tool_calls WHERE trace_id=?", (tid,)).fetchone()
    assert row["tool_name"] == "search"
    assert row["valid"] == 1


def test_insert_feedback(writer):
    eid = str(uuid.uuid4())
    writer.insert_feedback(response_id=eid, signal="thumbs_up", value=1.0)
    row = writer._conn.execute("SELECT * FROM feedback WHERE response_id=?", (eid,)).fetchone()
    assert row["signal"] == "thumbs_up"
    assert row["value"] == 1.0


def test_insert_evolution(writer):
    vid = "variant-abc"
    writer.insert_evolution(variant_id=vid, phase="explore", win_rate=0.62, samples=50)
    row = writer._conn.execute("SELECT * FROM evolution WHERE variant_id=?", (vid,)).fetchone()
    assert row["phase"] == "explore"
    assert row["win_rate"] == pytest.approx(0.62)


def test_insert_query_recon(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="gpt-4o-mini", provider="openai",
        input_tok=30, output_tok=15, latency_ms=200,
    )
    writer.insert_query_recon(
        trace_id=tid,
        original="What is the capital of France?",
        reconstructed="Capital of France?",
        similarity=0.88,
    )
    row = writer._conn.execute("SELECT * FROM query_recon WHERE trace_id=?", (tid,)).fetchone()
    assert row["original"] == "What is the capital of France?"
    assert row["similarity"] == pytest.approx(0.88)


def test_insert_event_returns_id(writer):
    eid = writer.insert_event(message="Server started", level="info", source="test")
    assert isinstance(eid, str)
    assert len(eid) == 36  # UUID


def test_insert_event_metadata(writer):
    eid = writer.insert_event(
        message="Cache miss",
        level="debug",
        metadata={"query": "hello", "latency_ms": 5},
        source="cache",
    )
    row = writer._conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    assert row["level"] == "debug"
    assert "query" in row["meta_json"]


def test_upsert_trace(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="gpt-4o", provider="openai",
        input_tok=10, output_tok=5, latency_ms=100,
    )
    # Insert again with same ID (REPLACE semantics)
    writer.insert_trace(
        id=tid, model="gpt-4o", provider="openai",
        input_tok=999, output_tok=5, latency_ms=100,
    )
    rows = writer._conn.execute("SELECT * FROM traces WHERE id=?", (tid,)).fetchall()
    assert len(rows) == 1
    assert rows[0]["input_tok"] == 999
