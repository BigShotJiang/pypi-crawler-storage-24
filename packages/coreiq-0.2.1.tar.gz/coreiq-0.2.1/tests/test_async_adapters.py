"""Tests for async provider adapters."""
import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# OpenAI async adapter
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_openai_async_creates_trace():
    usage = SimpleNamespace(prompt_tokens=10, completion_tokens=20)
    choice = SimpleNamespace(finish_reason="stop")
    response = SimpleNamespace(usage=usage, choices=[choice])

    mock_client = MagicMock()
    mock_client.chat.completions.create = AsyncMock(return_value=response)

    writer = MagicMock()
    with patch("coreiq.models.adapters.openai.get_writer", return_value=writer):
        from coreiq.models.adapters.openai import async_create_chat_completion
        result = await async_create_chat_completion(
            mock_client, model="gpt-4", messages=[{"role": "user", "content": "hi"}],
            trace_id="t-openai-1",
        )

    assert result is response
    writer.insert_trace.assert_called_once()
    call_kw = writer.insert_trace.call_args
    assert call_kw.kwargs["id"] == "t-openai-1"
    assert call_kw.kwargs["provider"] == "openai"
    assert call_kw.kwargs["input_tok"] == 10
    assert call_kw.kwargs["output_tok"] == 20


@pytest.mark.asyncio
async def test_openai_async_records_error_trace():
    mock_client = MagicMock()
    mock_client.chat.completions.create = AsyncMock(side_effect=RuntimeError("boom"))

    writer = MagicMock()
    with patch("coreiq.models.adapters.openai.get_writer", return_value=writer):
        from coreiq.models.adapters.openai import async_create_chat_completion
        with pytest.raises(RuntimeError):
            await async_create_chat_completion(
                mock_client, model="gpt-4", messages=[], trace_id="t-err",
            )

    assert writer.insert_trace.call_args.kwargs["finish_reason"] == "error"


# ---------------------------------------------------------------------------
# Anthropic async adapter
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_anthropic_async_creates_trace():
    usage = SimpleNamespace(input_tokens=5, output_tokens=15)
    response = SimpleNamespace(usage=usage, stop_reason="end_turn")

    mock_client = MagicMock()
    mock_client.messages.create = AsyncMock(return_value=response)

    writer = MagicMock()
    with patch("coreiq.models.adapters.anthropic.get_writer", return_value=writer):
        from coreiq.models.adapters.anthropic import async_create_message
        result = await async_create_message(
            mock_client, model="claude-3", messages=[{"role": "user", "content": "hi"}],
            trace_id="t-anth-1",
        )

    assert result is response
    call_kw = writer.insert_trace.call_args.kwargs
    assert call_kw["provider"] == "anthropic"
    assert call_kw["input_tok"] == 5
    assert call_kw["output_tok"] == 15


# ---------------------------------------------------------------------------
# vLLM async adapter
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_vllm_async_creates_trace():
    resp_data = {
        "usage": {"prompt_tokens": 8, "completion_tokens": 12},
        "choices": [{"finish_reason": "stop"}],
    }

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = resp_data

    mock_http = AsyncMock()
    mock_http.post.return_value = mock_response
    mock_http.__aenter__ = AsyncMock(return_value=mock_http)
    mock_http.__aexit__ = AsyncMock(return_value=False)

    writer = MagicMock()
    with patch("coreiq.models.adapters.vllm.get_writer", return_value=writer), \
         patch("httpx.AsyncClient", return_value=mock_http):
        from coreiq.models.adapters.vllm import async_create_chat_completion
        result = await async_create_chat_completion(
            "http://localhost:8000", model="llama-70b", messages=[], trace_id="t-vllm-1",
        )

    assert result == resp_data
    call_kw = writer.insert_trace.call_args.kwargs
    assert call_kw["provider"] == "vllm"
    assert call_kw["input_tok"] == 8


# ---------------------------------------------------------------------------
# SGLang async adapter
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_sglang_async_creates_trace():
    resp_data = {
        "usage": {"prompt_tokens": 6, "completion_tokens": 14},
        "choices": [{"finish_reason": "stop"}],
    }

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = resp_data

    mock_http = AsyncMock()
    mock_http.post.return_value = mock_response
    mock_http.__aenter__ = AsyncMock(return_value=mock_http)
    mock_http.__aexit__ = AsyncMock(return_value=False)

    writer = MagicMock()
    with patch("coreiq.models.adapters.sglang.get_writer", return_value=writer), \
         patch("httpx.AsyncClient", return_value=mock_http):
        from coreiq.models.adapters.sglang import async_create_chat_completion
        result = await async_create_chat_completion(
            "http://localhost:30000", model="mixtral", messages=[], trace_id="t-sglang-1",
        )

    assert result == resp_data
    call_kw = writer.insert_trace.call_args.kwargs
    assert call_kw["provider"] == "sglang"
    assert call_kw["input_tok"] == 6
