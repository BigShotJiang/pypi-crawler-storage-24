"""Tests for tool registry, validator, and router."""
import json
import pytest

from coreiq.tools.registry import ToolRegistry, ToolSpec
from coreiq.tools.validator import ToolValidator, ValidationResult
from coreiq.tools.router import ToolRouter


SAMPLE_TOOLS = [
    {
        "name": "search_web",
        "description": "Search the internet for current information",
        "parameters": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "run_sql",
        "description": "Execute a SQL query against the database",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "database": {"type": "string"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "send_email",
        "description": "Send an email to a recipient",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "string"},
                "subject": {"type": "string"},
                "body": {"type": "string"},
            },
            "required": ["to", "subject", "body"],
        },
    },
]


# ── Registry ──────────────────────────────────────────────────────────────────

def test_registry_register_and_get():
    reg = ToolRegistry()
    reg.register(SAMPLE_TOOLS)
    assert len(reg) == 3
    spec = reg.get("run_sql")
    assert spec is not None
    assert spec.name == "run_sql"
    assert "SQL" in spec.description


def test_registry_get_unknown_returns_none():
    reg = ToolRegistry()
    reg.register(SAMPLE_TOOLS)
    assert reg.get("nonexistent") is None


def test_registry_names():
    reg = ToolRegistry()
    reg.register(SAMPLE_TOOLS)
    names = reg.names()
    assert "search_web" in names
    assert "run_sql" in names


def test_registry_no_name_raises():
    from coreiq.exceptions import ValidationError
    reg = ToolRegistry()
    with pytest.raises(ValidationError, match="non-empty"):
        reg.register([{"description": "no name"}])


def test_registry_description_too_long_raises():
    from coreiq.exceptions import ValidationError
    reg = ToolRegistry()
    with pytest.raises(ValidationError, match="2000"):
        reg.register([{"name": "x", "description": "x" * 2001}])


# ── Validator ─────────────────────────────────────────────────────────────────

def _make_validator():
    reg = ToolRegistry()
    reg.register(SAMPLE_TOOLS)
    return ToolValidator(reg)


def test_validate_unknown_tool():
    v = _make_validator()
    result = v.validate("make_coffee", '{}')
    assert result.valid is False
    assert result.layer == "name"


def test_validate_bad_json():
    v = _make_validator()
    result = v.validate("search_web", '{bad json}')
    assert result.valid is False
    assert result.layer == "json"


def test_validate_missing_required_arg():
    v = _make_validator()
    result = v.validate("search_web", '{}')  # missing "query"
    assert result.valid is False
    assert result.layer == "args"
    assert "query" in result.error


def test_validate_valid_call():
    v = _make_validator()
    result = v.validate("search_web", json.dumps({"query": "what is the weather?"}))
    assert result.valid is True
    assert result.layer == "ok"


def test_validate_email_all_required():
    v = _make_validator()
    result = v.validate("send_email", json.dumps({"to": "a@b.com", "subject": "Hi", "body": "Hello"}))
    assert result.valid is True


def test_validate_email_missing_body():
    v = _make_validator()
    result = v.validate("send_email", json.dumps({"to": "a@b.com", "subject": "Hi"}))
    assert result.valid is False
    assert result.layer == "args"


# ── Router ────────────────────────────────────────────────────────────────────

def test_router_returns_at_most_top_k():
    reg = ToolRegistry()
    reg.register(SAMPLE_TOOLS)
    router = ToolRouter(reg)
    results = router.select("find me orders", top_k=2)
    assert len(results) <= 2


def test_router_empty_registry():
    reg = ToolRegistry()
    router = ToolRouter(reg)
    results = router.select("query", top_k=5)
    assert results == []


def test_router_token_savings():
    reg = ToolRegistry()
    reg.register(SAMPLE_TOOLS)  # 3 tools
    router = ToolRouter(reg)

    # Select 1 tool — savings = (3-1) * 200 = 400
    selected = [reg.all()[0]]
    savings = router.token_savings(selected, tokens_per_tool=200)
    assert savings == 400


def test_router_token_savings_no_savings_when_all_selected():
    reg = ToolRegistry()
    reg.register(SAMPLE_TOOLS)
    router = ToolRouter(reg)
    savings = router.token_savings(reg.all(), tokens_per_tool=200)
    assert savings == 0


# ── Keyword fallback ─────────────────────────────────────────────────────────

MANY_TOOLS = [
    {"name": "search_web", "description": "Search the internet for web pages and results"},
    {"name": "run_sql", "description": "Execute a SQL query against the database"},
    {"name": "send_email", "description": "Send an email to a recipient"},
    {"name": "read_file", "description": "Read a local file from disk"},
    {"name": "write_file", "description": "Write content to a local file"},
    {"name": "web_scraper", "description": "Scrape data from a web page"},
    {"name": "database_backup", "description": "Create a backup of the database"},
    {"name": "image_resize", "description": "Resize an image to given dimensions"},
    {"name": "translate_text", "description": "Translate text between languages"},
    {"name": "calendar_event", "description": "Create a calendar event"},
]


def _make_keyword_router():
    reg = ToolRegistry()
    reg.register(MANY_TOOLS)
    return ToolRouter(reg), reg


def test_keyword_select_web_search():
    router, _ = _make_keyword_router()
    results = router.select("search for web pages", top_k=3)
    names = [r.name for r in results]
    # search_web and web_scraper should rank highest (have "search" or "web" in name/desc)
    assert names[0] in ("search_web", "web_scraper")
    assert names[1] in ("search_web", "web_scraper")


def test_keyword_select_database_query():
    router, _ = _make_keyword_router()
    results = router.select("database query", top_k=3)
    names = [r.name for r in results]
    # database_backup has "database" in name (double bonus) + description
    # run_sql has "database" in description
    assert "database_backup" in names[:2]
    assert "run_sql" in names[:2]


def test_keyword_select_empty_query():
    router, reg = _make_keyword_router()
    results = router.select("", top_k=3)
    # Empty query → first top_k tools in registration order
    assert len(results) == 3
    assert results == reg.all()[:3]


def test_keyword_name_match_higher_priority():
    """Name matches should score higher than description-only matches."""
    router, _ = _make_keyword_router()
    results = router.select("web", top_k=3)
    names = [r.name for r in results]
    # web_scraper has "web" in name (gets double bonus) AND description
    # search_web has "web" in name (gets double bonus) AND description
    # Both should outrank tools that only have "web" in description
    assert "web_scraper" in names[:2]
    assert "search_web" in names[:2]


def test_keyword_select_respects_top_k():
    router, _ = _make_keyword_router()
    results = router.select("search for web pages", top_k=2)
    assert len(results) == 2


# ── Client integration ────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _reset_writer(tmp_path, monkeypatch):
    monkeypatch.setenv("COREIQ_DB_PATH", str(tmp_path / "test.db"))
    import coreiq.store.writer as w
    w._writer = None
    yield
    w._writer = None


def test_client_tools_register_and_validate():
    from coreiq.client import CoreIQClient
    client = CoreIQClient()
    client.tools.register(SAMPLE_TOOLS)
    result = client.tools.validate("run_sql", json.dumps({"query": "SELECT 1"}))
    assert result.valid is True


def test_client_tools_validate_unknown():
    from coreiq.client import CoreIQClient
    client = CoreIQClient()
    client.tools.register(SAMPLE_TOOLS)
    result = client.tools.validate("brew_coffee", '{}')
    assert result.valid is False
    assert result.layer == "name"


def test_client_tools_select():
    from coreiq.client import CoreIQClient
    client = CoreIQClient()
    client.tools.register(SAMPLE_TOOLS)
    results = client.tools.select("find database records", top_k=2)
    assert len(results) <= 2


def test_count_tokens():
    from coreiq.performance.cache import count_tokens
    # Should return a positive integer for any text
    n = count_tokens("Hello, how are you today?")
    assert isinstance(n, int)
    assert n > 0
