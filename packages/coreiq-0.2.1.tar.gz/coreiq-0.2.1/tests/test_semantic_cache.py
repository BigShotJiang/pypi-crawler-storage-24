"""Tests for InMemorySemanticCache."""
import threading
import time
from unittest.mock import patch

import pytest

from coreiq.performance.cache import CacheEntry, InMemorySemanticCache


@pytest.fixture
def cache():
    c = InMemorySemanticCache(max_size=5, ttl_seconds=3600)
    # Force no embeddings model for deterministic tests
    c._model = False
    return c


MSGS_A = [{"role": "user", "content": "Hello world"}]
MSGS_B = [{"role": "user", "content": "Something else entirely"}]


class TestExactMatch:
    def test_put_then_get_returns_hit(self, cache):
        cache.put(MSGS_A, response="resp-a", tokens_used=100)
        entry = cache.get(MSGS_A)
        assert entry is not None
        assert entry.response == "resp-a"
        assert entry.tokens_used == 100

    def test_case_insensitive_match(self, cache):
        cache.put([{"role": "user", "content": "Hello World"}], response="r1")
        entry = cache.get([{"role": "user", "content": "hello world"}])
        assert entry is not None
        assert entry.response == "r1"


class TestMiss:
    def test_get_nonexistent_returns_none(self, cache):
        result = cache.get(MSGS_B)
        assert result is None

    def test_miss_after_different_put(self, cache):
        cache.put(MSGS_A, response="resp-a")
        result = cache.get(MSGS_B)
        assert result is None


class TestLRUEviction:
    def test_oldest_evicted_when_over_max_size(self):
        c = InMemorySemanticCache(max_size=3, ttl_seconds=3600)
        c._model = False

        msgs = [[{"role": "user", "content": f"msg-{i}"}] for i in range(4)]
        for i, m in enumerate(msgs):
            c.put(m, response=f"resp-{i}")

        # msg-0 should be evicted (oldest)
        assert c.get(msgs[0]) is None
        # msg-1, msg-2, msg-3 should still be present
        for i in (1, 2, 3):
            assert c.get(msgs[i]) is not None

    def test_recently_accessed_not_evicted(self):
        c = InMemorySemanticCache(max_size=3, ttl_seconds=3600)
        c._model = False

        msgs = [[{"role": "user", "content": f"msg-{i}"}] for i in range(3)]
        for i, m in enumerate(msgs):
            c.put(m, response=f"resp-{i}")

        # Access msg-0 to make it recent
        c.get(msgs[0])

        # Add a 4th — msg-1 should be evicted (oldest untouched)
        c.put([{"role": "user", "content": "msg-3"}], response="resp-3")
        assert c.get(msgs[0]) is not None
        assert c.get(msgs[1]) is None


class TestTTLExpiry:
    def test_expired_entries_removed(self):
        c = InMemorySemanticCache(max_size=10, ttl_seconds=1)
        c._model = False
        c.put(MSGS_A, response="resp-a")
        time.sleep(1.1)
        result = c.get(MSGS_A)
        assert result is None


class TestStats:
    def test_hit_miss_counts(self, cache):
        cache.put(MSGS_A, response="r")
        cache.get(MSGS_A)  # hit
        cache.get(MSGS_B)  # miss
        cache.get(MSGS_B)  # miss

        s = cache.stats
        assert s["hit_count"] == 1
        assert s["miss_count"] == 2
        assert s["hit_rate"] == pytest.approx(1 / 3, abs=0.01)
        assert s["size"] == 1
        assert s["max_size"] == 5
        assert s["has_embeddings"] is False

    def test_initial_stats_zero(self, cache):
        s = cache.stats
        assert s["hit_count"] == 0
        assert s["miss_count"] == 0
        assert s["hit_rate"] == 0.0


class TestThreadSafety:
    def test_concurrent_puts_and_gets(self):
        c = InMemorySemanticCache(max_size=200, ttl_seconds=3600)
        c._model = False
        errors = []

        def writer(start):
            try:
                for i in range(start, start + 50):
                    c.put([{"role": "user", "content": f"q-{i}"}], response=f"r-{i}")
            except Exception as e:
                errors.append(e)

        def reader(start):
            try:
                for i in range(start, start + 50):
                    c.get([{"role": "user", "content": f"q-{i}"}])
            except Exception as e:
                errors.append(e)

        threads = []
        for base in (0, 50, 100, 150):
            threads.append(threading.Thread(target=writer, args=(base,)))
            threads.append(threading.Thread(target=reader, args=(base,)))

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert not errors, f"Thread errors: {errors}"


class TestClear:
    def test_clear_empties_cache(self, cache):
        cache.put(MSGS_A, response="r1")
        cache.put(MSGS_B, response="r2")
        assert cache.stats["size"] == 2

        cache.clear()
        assert cache.stats["size"] == 0
        assert cache.get(MSGS_A) is None
        assert cache.get(MSGS_B) is None


class TestCacheEntry:
    def test_defaults(self):
        e = CacheEntry(response="x", key="k")
        assert e.embedding is None
        assert e.tokens_used == 0
        assert e.timestamp > 0
