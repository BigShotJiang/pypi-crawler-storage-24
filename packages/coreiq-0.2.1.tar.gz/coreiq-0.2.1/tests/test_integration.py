"""Integration tests — end-to-end flows through real SQLite DB."""
import json
import uuid
from unittest.mock import patch

import pytest

from coreiq.store.writer import EventWriter
from coreiq.store.db import init_schema, create_connection


@pytest.fixture
def writer(tmp_path):
    """Create a fresh EventWriter backed by a temp DB."""
    db_path = tmp_path / "test.db"
    w = EventWriter(db_path)
    return w


@pytest.fixture
def _mock_writer(writer):
    """Patch get_writer and get_shared_connection to use temp DB."""
    with patch("coreiq.store.writer.get_writer", return_value=writer), \
         patch("coreiq.store.db.get_shared_connection", return_value=writer._conn), \
         patch("coreiq.evolution.sdk.get_shared_connection", return_value=writer._conn), \
         patch("coreiq.evolution.sdk.get_writer", return_value=writer), \
         patch("coreiq.evolution.feedback.get_writer", return_value=writer), \
         patch("coreiq.status.get_shared_connection", return_value=writer._conn):
        yield


class TestEventRoundtrip:
    def test_write_and_read_back(self, writer):
        eid = writer.insert_event(
            message="user signed up",
            level="info",
            metadata={"plan": "pro"},
            source="auth",
            trace_id="t-123",
        )
        row = writer._conn.execute(
            "SELECT * FROM events WHERE id = ?", (eid,)
        ).fetchone()
        assert row is not None
        assert row["message"] == "user signed up"
        assert row["level"] == "info"
        assert json.loads(row["meta_json"]) == {"plan": "pro"}
        assert row["source"] == "auth"
        assert row["trace_id"] == "t-123"


class TestFeedbackEvolutionFlow:
    @pytest.mark.usefixtures("_mock_writer")
    def test_feedback_to_evolution(self, writer):
        from coreiq.evolution.feedback import FeedbackRecorder
        from coreiq.evolution.sdk import EvolutionSDK

        recorder = FeedbackRecorder()
        recorder.thumbs_up("resp-1")

        evo = EvolutionSDK()
        evo.add_variant("v-alpha")
        evo.add_variant("v-beta")
        evo.record_outcome("v-alpha", "thumbs_up")
        evo.record_outcome("v-alpha", "thumbs_up")
        evo.record_outcome("v-beta", "thumbs_down")

        best = evo.best()
        assert best is not None
        assert best.id == "v-alpha"
        assert best.win_rate > 0.5

        # Verify bandit_state persisted to DB
        rows = writer._conn.execute("SELECT * FROM bandit_state").fetchall()
        assert len(rows) == 2


class TestToolRegisterValidateSelect:
    def test_register_validate(self):
        from coreiq.tools.registry import ToolRegistry
        from coreiq.tools.validator import ToolValidator

        reg = ToolRegistry()
        reg.register([
            {
                "name": "search",
                "description": "Search the web",
                "parameters": {
                    "required": ["query"],
                    "properties": {
                        "query": {"type": "string"},
                        "limit": {"type": "integer"},
                    },
                },
            },
            {
                "name": "calculate",
                "description": "Do math",
                "parameters": {
                    "required": ["expression"],
                    "properties": {"expression": {"type": "string"}},
                },
            },
        ])
        assert len(reg) == 2

        validator = ToolValidator(reg)

        # Valid call
        r = validator.validate("search", '{"query": "hello", "limit": 5}')
        assert r.valid is True

        # Unknown tool
        r = validator.validate("unknown", '{}')
        assert r.valid is False
        assert r.layer == "name"

        # Missing required arg
        r = validator.validate("search", '{}')
        assert r.valid is False
        assert r.layer == "args"

        # Wrong type
        r = validator.validate("search", '{"query": 123}')
        assert r.valid is False
        assert "expected type" in r.error


class TestTracePropagation:
    def test_trace_and_event_linked(self, writer):
        trace_id = str(uuid.uuid4())
        writer.insert_trace(
            id=trace_id, model="gpt-4o", provider="openai",
            input_tok=100, output_tok=50, latency_ms=200,
        )
        eid = writer.insert_event(
            message="traced event", trace_id=trace_id,
        )
        trace_row = writer._conn.execute(
            "SELECT * FROM traces WHERE id = ?", (trace_id,)
        ).fetchone()
        event_row = writer._conn.execute(
            "SELECT * FROM events WHERE id = ?", (eid,)
        ).fetchone()
        assert trace_row is not None
        assert event_row is not None
        assert event_row["trace_id"] == trace_id


class TestStatusWithSeededData:
    @pytest.mark.usefixtures("_mock_writer")
    def test_build_status(self, writer):
        from coreiq.status import build_status

        # Seed traces
        writer.insert_trace(
            id="t1", model="gpt-4o", provider="openai",
            input_tok=100, output_tok=50, latency_ms=150,
        )
        # Seed feedback
        writer.insert_feedback(response_id="r1", signal="thumbs_up", value=1.0)
        # Seed cache events
        writer.insert_cache_event(trace_id="t1", hit=True, saved_tok=500)
        writer.insert_cache_event(trace_id="t1", hit=False)
        # Seed tool calls
        writer.insert_tool_call(trace_id="t1", tool_name="search", args_json='{}', valid=True)
        writer.insert_tool_call(trace_id="t1", tool_name="bad", args_json='x', valid=False, error="invalid")
        # Seed evolution
        writer.insert_evolution(variant_id="v1", phase="testing", win_rate=0.7, samples=30)

        report = build_status()
        assert report.cache_hit_rate == 0.5
        assert report.token_savings_7d == 500
        assert report.best_variant_id == "v1"
        assert report.best_variant_win_rate == 0.7
        assert report.tool_error_count == 1
        assert report.tool_error_rate == 0.5
        assert report.evolution_phase == "testing"
        assert report.samples_to_promote == 20
