"""Tests for StatusReport and build_status."""
import pytest
import json


@pytest.fixture(autouse=True)
def _reset(tmp_path, monkeypatch):
    monkeypatch.setenv("COREIQ_DB_PATH", str(tmp_path / "test.db"))
    import coreiq.store.writer as w
    import coreiq.store.db as db
    w._writer = None
    db._shared_conn = None
    db._shared_conn_path = None
    yield
    w._writer = None
    db._shared_conn = None
    db._shared_conn_path = None


def test_build_status_returns_report():
    from coreiq.status import build_status, StatusReport
    report = build_status()
    assert isinstance(report, StatusReport)


def test_status_repr_contains_expected_sections():
    from coreiq.status import build_status
    r = build_status()
    text = repr(r)
    assert "Cache hit rate" in text
    assert "Token savings" in text
    assert "Tool errors" in text
    assert "Evolution phase" in text


def test_status_to_dict_has_keys():
    from coreiq.status import build_status
    d = build_status().to_dict()
    assert "cache_hit_rate" in d
    assert "token_savings_7d" in d
    assert "best_variant_id" in d
    assert "tool_error_count" in d
    assert "evolution_phase" in d


def test_status_to_json_is_valid():
    from coreiq.status import build_status
    j = build_status().to_json()
    data = json.loads(j)
    assert isinstance(data, dict)
    assert "cache_hit_rate" in data


def test_status_with_seeded_data():
    from coreiq.store.writer import get_writer
    writer = get_writer()
    import uuid
    tid = str(uuid.uuid4())
    writer.insert_trace(id=tid, model="gpt-4o", provider="openai",
                        input_tok=100, output_tok=50, latency_ms=300)
    writer.insert_cache_event(trace_id=tid, hit=True, similarity=0.95, saved_tok=500)
    writer.insert_cache_event(trace_id=tid, hit=False, similarity=0.3)

    from coreiq.status import build_status
    report = build_status()
    assert report.cache_hit_rate == 0.5  # 1 hit / 2 events
    assert report.token_savings_7d == 500


def test_client_status_method():
    from coreiq.client import CoreIQClient
    client = CoreIQClient()
    report = client.status()
    assert report is not None
    text = repr(report)
    assert "CoreIQ Status" in text
