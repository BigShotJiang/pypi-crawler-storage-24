"""Tool call validator — three-layer schema checking."""
import json
from dataclasses import dataclass
from typing import Optional

from .registry import ToolRegistry


_TYPE_MAP = {
    "string": str,
    "integer": int,
    "number": (int, float),
    "boolean": bool,
    "array": list,
    "object": dict,
}


def _type_matches(val, json_type: str) -> bool:
    expected = _TYPE_MAP.get(json_type)
    if expected is None:
        return True
    return isinstance(val, expected)


@dataclass
class ValidationResult:
    valid: bool
    layer: str  # "name" | "json" | "args" | "ok"
    error: Optional[str] = None


class ToolValidator:
    """Validates tool calls against registered schemas."""

    def __init__(self, registry: ToolRegistry):
        self._registry = registry

    def validate(self, tool_name: str, args_json: str) -> ValidationResult:
        """Validate a tool call against the registry.

        Layer 1 (name): Is this tool registered?
        Layer 2 (json): Is args_json valid JSON?
        Layer 3 (args): Do args satisfy the schema's required fields?
        """
        # Layer 1: name check
        spec = self._registry.get(tool_name)
        if spec is None:
            known = self._registry.names()
            hint = f" Known tools: {known[:5]}" if known else ""
            return ValidationResult(
                valid=False, layer="name",
                error=f"Unknown tool: '{tool_name}'.{hint}"
            )

        # Layer 2: JSON parse
        try:
            if isinstance(args_json, str):
                args = json.loads(args_json)
            else:
                args = args_json
        except json.JSONDecodeError as e:
            return ValidationResult(valid=False, layer="json", error=f"Invalid JSON: {e}")

        # Layer 3: required args
        if spec.parameters and isinstance(args, dict):
            required = spec.parameters.get("required", [])
            for req in required:
                if req not in args:
                    return ValidationResult(
                        valid=False, layer="args",
                        error=f"Missing required argument: '{req}'"
                    )

            # Layer 3b: type validation
            properties = spec.parameters.get("properties", {})
            for key, val in args.items():
                if key in properties:
                    expected_type = properties[key].get("type")
                    if expected_type and not _type_matches(val, expected_type):
                        return ValidationResult(
                            valid=False, layer="args",
                            error=f"'{key}' expected type '{expected_type}', got {type(val).__name__}"
                        )

        return ValidationResult(valid=True, layer="ok")
