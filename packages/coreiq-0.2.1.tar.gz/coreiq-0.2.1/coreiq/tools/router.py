"""Semantic tool router — embedding-based top-K tool selection."""
import math
from typing import List

from .registry import ToolRegistry, ToolSpec

try:
    from sentence_transformers import SentenceTransformer
    _HAS_EMBEDDINGS = True
except ImportError:
    _HAS_EMBEDDINGS = False


def _cosine_sim(a: list, b: list) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class ToolRouter:
    """Selects the most relevant tools for a query using embeddings.

    Requires: pip install 'coreiq[embeddings]'
    Falls back gracefully to returning all tools if not installed.
    """

    _MODEL_NAME = "all-MiniLM-L6-v2"

    def __init__(self, registry: ToolRegistry):
        self._registry = registry
        self._model = None
        self._embeddings: dict = {}
        self._registry_version = -1

    def _get_model(self):
        if self._model is None and _HAS_EMBEDDINGS:
            self._model = SentenceTransformer(self._MODEL_NAME)
        return self._model

    def _ensure_embeddings(self) -> bool:
        model = self._get_model()
        if model is None:
            return False
        if self._registry.version != self._registry_version:
            self._embeddings.clear()
            self._registry_version = self._registry.version
        for spec in self._registry.all():
            if spec.name not in self._embeddings:
                text = f"{spec.name}: {spec.description}"
                self._embeddings[spec.name] = model.encode(text).tolist()
        return True

    def _keyword_select(self, query: str, top_k: int) -> List[ToolSpec]:
        """Fallback: score tools by keyword overlap with query."""
        query_words = set(query.lower().split())
        if not query_words:
            return self._registry.all()[:top_k]
        scored = []
        for spec in self._registry.all():
            text = f"{spec.name.replace('_', ' ')} {spec.description}".lower()
            text_words = set(text.split())
            overlap = len(query_words & text_words)
            name_words = set(spec.name.replace('_', ' ').lower().split())
            name_overlap = len(query_words & name_words)
            score = overlap + name_overlap * 2  # name matches worth double
            scored.append((score, spec))
        scored.sort(key=lambda x: -x[0])
        return [spec for _, spec in scored[:top_k]]

    def select(self, query: str, top_k: int = 5) -> List[ToolSpec]:
        """Return the top_k most relevant tools for query.

        Uses cosine similarity over sentence-transformer embeddings.
        Falls back to keyword matching if embeddings unavailable.
        """
        all_tools = self._registry.all()
        if not all_tools:
            return []

        if not _HAS_EMBEDDINGS or not self._ensure_embeddings():
            return self._keyword_select(query, top_k)

        model = self._get_model()
        query_emb = model.encode(query).tolist()

        scored = [
            (_cosine_sim(query_emb, self._embeddings[spec.name]), spec)
            for spec in all_tools
            if spec.name in self._embeddings
        ]
        scored.sort(key=lambda x: -x[0])
        return [spec for _, spec in scored[:top_k]]

    def token_savings(self, selected: List[ToolSpec], tokens_per_tool: int = 200) -> int:
        """Estimate tokens saved by sending selected tools vs all tools."""
        total = len(self._registry)
        sent = len(selected)
        return max(0, (total - sent) * tokens_per_tool)
