"""Tool schema registry — register and look up tool definitions."""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..exceptions import ValidationError


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)


class ToolRegistry:
    """Stores tool definitions and provides fast lookup."""

    def __init__(self):
        self._tools: Dict[str, ToolSpec] = {}
        self._version = 0

    @property
    def version(self) -> int:
        return self._version

    def register(self, tools: List[Dict[str, Any]]) -> None:
        """Register tool specs. Each dict: {name, description, parameters}."""
        for t in tools:
            name = t.get("name", "").strip()
            if not name:
                raise ValidationError("Tool must have a non-empty 'name'")
            description = t.get("description", "")
            if len(description) > 2000:
                raise ValidationError(f"Tool '{name}' description exceeds 2000 chars")
            self._tools[name] = ToolSpec(
                name=name,
                description=description,
                parameters=t.get("parameters", {}),
            )
        self._version += 1

    def get(self, name: str) -> Optional[ToolSpec]:
        return self._tools.get(name)

    def all(self) -> List[ToolSpec]:
        return list(self._tools.values())

    def names(self) -> List[str]:
        return list(self._tools.keys())

    def __len__(self) -> int:
        return len(self._tools)
