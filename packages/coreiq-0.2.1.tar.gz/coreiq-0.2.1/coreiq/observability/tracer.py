import uuid
from typing import Optional

from ..store.writer import get_writer


class Tracer:
    def record_request(
        self,
        *,
        model: str,
        provider: str,
        input_tok: int,
        output_tok: int,
        latency_ms: int,
        finish_reason: str = "stop",
        cache_hit: bool = False,
        request_id: Optional[str] = None,
    ) -> str:
        rid = request_id or str(uuid.uuid4())
        get_writer().insert_trace(
            id=rid,
            model=model,
            provider=provider,
            input_tok=input_tok,
            output_tok=output_tok,
            latency_ms=latency_ms,
            finish_reason=finish_reason,
            cache_hit=cache_hit,
        )
        return rid


_tracer: Optional[Tracer] = None


def get_tracer() -> Tracer:
    global _tracer
    if _tracer is None:
        _tracer = Tracer()
    return _tracer
