from fastapi import APIRouter, Query
from typing import Optional
import sqlite3
import json
from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/traces", tags=["traces"])


def _conn() -> sqlite3.Connection:
    return get_shared_connection()


@router.get("")
def list_traces(
    limit: int = Query(50, le=500),
    offset: int = 0,
    provider: Optional[str] = None,
    cache_hit: Optional[int] = None,
    finish_reason: Optional[str] = None,
    from_ts: Optional[str] = Query(None, alias="from"),
):
    conn = _conn()
    where, params = [], []
    if provider:
        where.append("provider = ?")
        params.append(provider)
    if cache_hit is not None:
        where.append("cache_hit = ?")
        params.append(cache_hit)
    if finish_reason:
        where.append("finish_reason = ?")
        params.append(finish_reason)
    if from_ts:
        where.append("ts >= ?")
        params.append(from_ts)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"SELECT * FROM traces {clause} ORDER BY ts DESC LIMIT ? OFFSET ?",
        params + [limit, offset]
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/{trace_id}")
def get_trace(trace_id: str):
    conn = _conn()
    row = conn.execute("SELECT * FROM traces WHERE id = ?", (trace_id,)).fetchone()
    if not row:
        from fastapi import HTTPException
        raise HTTPException(404, "Trace not found")
    result = dict(row)

    # Parse meta_json
    if result.get("meta_json"):
        try:
            result["meta"] = json.loads(result["meta_json"])
        except Exception:
            result["meta"] = {}
    else:
        result["meta"] = {}

    result["tool_calls"] = [dict(r) for r in conn.execute(
        "SELECT * FROM tool_calls WHERE trace_id = ?", (trace_id,)
    ).fetchall()]
    result["cache_events"] = [dict(r) for r in conn.execute(
        "SELECT * FROM cache_events WHERE trace_id = ?", (trace_id,)
    ).fetchall()]
    result["query_recon"] = [dict(r) for r in conn.execute(
        "SELECT * FROM query_recon WHERE trace_id = ?", (trace_id,)
    ).fetchall()]
    # Join feedback linked to this trace
    result["feedback"] = [dict(r) for r in conn.execute(
        "SELECT * FROM feedback WHERE response_id = ?", (trace_id,)
    ).fetchall()]
    return result
