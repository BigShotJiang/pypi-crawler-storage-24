from fastapi import APIRouter, Query
from typing import Optional
import sqlite3
from pydantic import BaseModel, field_validator
from ...store.db import get_shared_connection
from ...store.writer import get_writer

router = APIRouter(prefix="/api/feedback", tags=["feedback"])

_VALID_SIGNALS = {"thumbs_up", "thumbs_down", "score", "correction"}


def _conn() -> sqlite3.Connection:
    return get_shared_connection()


class FeedbackCreate(BaseModel):
    response_id: str
    signal: str
    value: float = 0.0
    dimension: Optional[str] = None
    correction: Optional[str] = None

    @field_validator("response_id")
    @classmethod
    def response_id_nonempty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("response_id must not be empty")
        return v.strip()

    @field_validator("signal")
    @classmethod
    def signal_valid(cls, v: str) -> str:
        if v not in _VALID_SIGNALS:
            raise ValueError(f"signal must be one of {sorted(_VALID_SIGNALS)}")
        return v


@router.post("", status_code=201)
def create_feedback(body: FeedbackCreate):
    writer = get_writer()
    writer.insert_feedback(
        response_id=body.response_id,
        signal=body.signal,
        value=body.value,
        dimension=body.dimension,
        correction=body.correction,
    )
    return {"ok": True}


@router.get("/summary")
def feedback_summary():
    conn = _conn()
    rows = conn.execute("SELECT signal, COUNT(*) as n, AVG(value) as avg_val FROM feedback GROUP BY signal").fetchall()
    result = {"thumbs_up": 0, "thumbs_down": 0, "avg_score": 0.0}
    for r in rows:
        if r["signal"] == "thumbs_up":
            result["thumbs_up"] = r["n"]
        elif r["signal"] == "thumbs_down":
            result["thumbs_down"] = r["n"]
        elif r["signal"] == "score":
            result["avg_score"] = round(r["avg_val"] or 0, 2)
    return result


@router.get("")
def list_feedback(
    limit: int = Query(50, le=500),
    offset: int = 0,
    signal: Optional[str] = None,
):
    conn = _conn()
    where, params = [], []
    if signal:
        where.append("f.signal = ?")
        params.append(signal)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"""SELECT f.*,
               t.model as trace_model,
               t.provider as trace_provider,
               t.latency_ms as trace_latency_ms,
               t.finish_reason as trace_finish_reason
           FROM feedback f
           LEFT JOIN traces t ON t.id = f.response_id
           {clause}
           ORDER BY f.ts DESC LIMIT ? OFFSET ?""",
        params + [limit, offset]
    ).fetchall()
    return [dict(r) for r in rows]
