from fastapi import APIRouter, Query
from typing import Optional
import json
import sqlite3
from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/events", tags=["events"])


def _conn() -> sqlite3.Connection:
    return get_shared_connection()


@router.get("")
def list_events(
    limit: int = Query(100, le=1000),
    offset: int = 0,
    level: Optional[str] = None,
    source: Optional[str] = None,
    trace_id: Optional[str] = None,
    from_ts: Optional[str] = Query(None, alias="from"),
):
    conn = _conn()
    where, params = [], []
    if level:
        where.append("level = ?")
        params.append(level)
    if source:
        where.append("source = ?")
        params.append(source)
    if trace_id:
        where.append("trace_id = ?")
        params.append(trace_id)
    if from_ts:
        where.append("ts >= ?")
        params.append(from_ts)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"SELECT * FROM events {clause} ORDER BY ts DESC LIMIT ? OFFSET ?",
        params + [limit, offset]
    ).fetchall()
    result = []
    for r in rows:
        row = dict(r)
        if row.get("meta_json"):
            try:
                row["metadata"] = json.loads(row["meta_json"])
            except Exception:
                row["metadata"] = {}
        else:
            row["metadata"] = {}
        result.append(row)
    return result


@router.get("/summary")
def events_summary():
    conn = _conn()
    total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    by_level = {
        row["level"]: row["cnt"]
        for row in conn.execute(
            "SELECT level, COUNT(*) as cnt FROM events GROUP BY level"
        ).fetchall()
    }
    return {"total": total, "by_level": by_level}
