from fastapi import APIRouter, Query
import sqlite3
from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/cache", tags=["cache"])


def _conn() -> sqlite3.Connection:
    return get_shared_connection()


@router.get("/stats")
def cache_stats():
    conn = _conn()
    row = conn.execute("""
        SELECT
            COUNT(*) as total,
            SUM(hit) as hits,
            COUNT(*) - SUM(hit) as misses,
            SUM(CASE WHEN hit=1 THEN saved_tok ELSE 0 END) as saved_tokens
        FROM cache_events
    """).fetchone()
    total = row["total"] or 0
    hits = row["hits"] or 0
    misses = row["misses"] or 0
    saved_tok = row["saved_tokens"] or 0
    return {
        "hit_rate": round(hits / total, 4) if total else 0,
        "total_hits": hits,
        "total_misses": misses,
        "saved_tokens": saved_tok,
        "savings_pct": round(saved_tok / max(saved_tok + (misses * 500), 1), 4),
        "estimated_savings_usd": round(saved_tok / 1000 * 0.003, 4),
    }


@router.get("/events")
def list_cache_events(limit: int = Query(100, le=500), offset: int = 0):
    conn = _conn()
    rows = conn.execute(
        """SELECT ce.*,
               SUBSTR(qr.original, 1, 80) as query_preview
           FROM cache_events ce
           LEFT JOIN query_recon qr ON qr.trace_id = ce.trace_id
           ORDER BY ce.ts DESC LIMIT ? OFFSET ?""",
        (limit, offset)
    ).fetchall()
    return [dict(r) for r in rows]
