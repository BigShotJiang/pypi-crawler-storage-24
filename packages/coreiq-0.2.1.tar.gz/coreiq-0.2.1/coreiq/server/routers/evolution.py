from fastapi import APIRouter
import sqlite3
from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/evolution", tags=["evolution"])


def _conn() -> sqlite3.Connection:
    return get_shared_connection()


@router.get("/status")
def evolution_status():
    conn = _conn()
    row = conn.execute("SELECT phase, COUNT(*) as n FROM evolution GROUP BY phase ORDER BY n DESC LIMIT 1").fetchone()
    stats = conn.execute("SELECT COUNT(*) as total, SUM(promoted) as promoted FROM evolution").fetchone()
    return {
        "current_phase": row["phase"] if row else "observing",
        "total_variants": stats["total"] or 0,
        "promoted": stats["promoted"] or 0,
    }


@router.get("/variants")
def list_variants():
    conn = _conn()
    rows = conn.execute("SELECT * FROM evolution ORDER BY ts DESC").fetchall()
    return [dict(r) for r in rows]


@router.get("/compare")
def compare_variants():
    conn = _conn()
    rows = conn.execute("SELECT * FROM evolution ORDER BY win_rate DESC").fetchall()
    variants = [dict(r) for r in rows]
    winner = variants[0]["variant_id"] if variants else None
    return {
        "variants": variants,
        "winner": winner,
        "what_evolving": None,
    }
