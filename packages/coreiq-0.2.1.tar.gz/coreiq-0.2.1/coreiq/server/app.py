import json
import logging
import time
from collections import defaultdict
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .routers import traces, cache, tool_calls, feedback, evolution, query_recon, optimiser, events
from ..store.db import create_connection, get_shared_connection, init_schema
from ..config import (
    get_api_key, get_host, get_port, get_log_level,
    get_log_json, get_cors_origins, get_rate_limit,
)

# ── Logging ───────────────────────────────────────────────────────────────────

def _configure_logging() -> None:
    if get_log_json():
        class JsonFormatter(logging.Formatter):
            def format(self, record: logging.LogRecord) -> str:
                return json.dumps({
                    "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
                    "level": record.levelname,
                    "logger": record.name,
                    "msg": record.getMessage(),
                    **({"exc": self.formatException(record.exc_info)} if record.exc_info else {}),
                })
        handler = logging.StreamHandler()
        handler.setFormatter(JsonFormatter())
        logging.root.handlers = [handler]
        logging.root.setLevel(logging.INFO)
    else:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )

_configure_logging()
logger = logging.getLogger("coreiq.server")


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    conn = create_connection()
    init_schema(conn)
    logger.info("CoreIQ server started — DB initialised")
    yield
    logger.info("CoreIQ server shutting down")


# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="CoreIQ Dashboard API",
    version="0.2.1",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=get_cors_origins(),
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)


# ── Rate limiting ─────────────────────────────────────────────────────────────

# NOTE: In-memory rate limit state — resets on server restart.
# For persistent rate limiting, use an external store (Redis, etc.).
_rate_buckets: dict[str, list[float]] = defaultdict(list)
_server_start = time.monotonic()


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    limit = get_rate_limit()
    normalized = request.url.path.rstrip("/").lower()
    if limit > 0 and normalized.startswith("/api"):
        # Stricter limits during first 60s after startup (burst protection)
        now = time.monotonic()
        if now - _server_start < 60.0:
            limit = limit // 2 or 1
        ip = request.client.host if request.client else "unknown"
        window = _rate_buckets[ip]
        # Slide window: keep only timestamps within the last 60s
        cutoff = now - 60.0
        _rate_buckets[ip] = [t for t in window if t > cutoff]
        if len(_rate_buckets[ip]) >= limit:
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded. Try again in a minute."},
                headers={"Retry-After": "60"},
            )
        _rate_buckets[ip].append(now)
    return await call_next(request)


# ── Auth ──────────────────────────────────────────────────────────────────────

@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    required_key = get_api_key()
    normalized = request.url.path.rstrip("/").lower()
    if required_key and normalized.startswith("/api"):
        # Skip auth on health — needed for Docker healthcheck without a key
        if normalized == "/api/health":
            return await call_next(request)
        provided = request.headers.get("X-API-Key") or request.query_params.get("api_key")
        if provided != required_key:
            return JSONResponse(status_code=401, content={"detail": "Unauthorized"})
    return await call_next(request)


# ── Global error handler ──────────────────────────────────────────────────────

@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled exception on %s: %s", request.url.path, exc, exc_info=True)
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


# ── Routers ───────────────────────────────────────────────────────────────────

app.include_router(traces.router)
app.include_router(cache.router)
app.include_router(tool_calls.router)
app.include_router(feedback.router)
app.include_router(evolution.router)
app.include_router(query_recon.router)
app.include_router(optimiser.router)
app.include_router(events.router)


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/api/health", tags=["meta"])
def health():
    return {"status": "ok", "version": "0.2.1"}


# ── Overview ──────────────────────────────────────────────────────────────────

@app.get("/api/overview", tags=["meta"])
def overview():
    conn = get_shared_connection()
    traces_row = conn.execute(
        "SELECT COUNT(*) as n, AVG(latency_ms) as avg_lat FROM traces"
    ).fetchone()
    cache_row = conn.execute(
        "SELECT COUNT(*) as total, SUM(hit) as hits, SUM(CASE WHEN hit=1 THEN saved_tok ELSE 0 END) as saved FROM cache_events"
    ).fetchone()
    fb_row = conn.execute(
        "SELECT signal, COUNT(*) as n, AVG(value) as avg_val FROM feedback GROUP BY signal"
    ).fetchall()
    fb = {r["signal"]: {"n": r["n"], "avg": r["avg_val"]} for r in fb_row}
    total = cache_row["total"] or 0
    hits = cache_row["hits"] or 0
    n_traces = traces_row["n"] or 0
    fr_rows = conn.execute(
        "SELECT finish_reason, COUNT(*) as n FROM traces GROUP BY finish_reason ORDER BY n DESC"
    ).fetchall()
    finish_reasons = {r["finish_reason"]: r["n"] for r in fr_rows}
    error_count = finish_reasons.get("error", 0)
    lat_rows = conn.execute("SELECT latency_ms FROM traces ORDER BY latency_ms").fetchall()
    lats = [r["latency_ms"] for r in lat_rows if r["latency_ms"] is not None]

    def percentile(lst, p):
        if not lst:
            return 0
        return lst[min(int(len(lst) * p / 100), len(lst) - 1)]

    provider_rows = conn.execute(
        "SELECT provider, COUNT(*) as n FROM traces GROUP BY provider"
    ).fetchall()

    return {
        "total_requests": n_traces,
        "avg_latency_ms": round(traces_row["avg_lat"] or 0, 1),
        "p50_latency_ms": percentile(lats, 50),
        "p95_latency_ms": percentile(lats, 95),
        "p99_latency_ms": percentile(lats, 99),
        "cache_hit_rate": round(hits / total, 4) if total else 0,
        "saved_tokens": cache_row["saved"] or 0,
        "thumbs_up": fb.get("thumbs_up", {}).get("n", 0),
        "thumbs_down": fb.get("thumbs_down", {}).get("n", 0),
        "avg_score": round(fb.get("score", {}).get("avg", 0) or 0, 2),
        "error_rate": round(error_count / n_traces, 4) if n_traces else 0,
        "finish_reasons": finish_reasons,
        "provider_split": {r["provider"]: r["n"] for r in provider_rows},
    }


# ── Entry point ───────────────────────────────────────────────────────────────

def start():
    import uvicorn
    dashboard_dist = Path(__file__).parent.parent.parent.parent / "dashboard" / "dist"
    if dashboard_dist.exists():
        app.mount("/", StaticFiles(directory=str(dashboard_dist), html=True), name="static")
    uvicorn.run(
        app,
        host=get_host(),
        port=get_port(),
        log_level=get_log_level(),
    )


if __name__ == "__main__":
    start()
