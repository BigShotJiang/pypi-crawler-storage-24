"""Policy enforcement — allowlists, denylists, and cost limits."""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PolicyViolation(Exception):
    rule: str
    detail: str

    def __str__(self) -> str:
        return f"Policy violation [{self.rule}]: {self.detail}"


@dataclass
class Policy:
    name: str
    allowed_models: list[str] = field(default_factory=list)
    denied_models: list[str] = field(default_factory=list)
    max_input_tokens: Optional[int] = None
    max_output_tokens: Optional[int] = None
    max_cost_usd: Optional[float] = None
    allowed_providers: list[str] = field(default_factory=list)

    def check_model(self, model: str) -> None:
        """Raise PolicyViolation if model is not permitted."""
        if self.denied_models and model in self.denied_models:
            raise PolicyViolation("denied_model", f"Model '{model}' is on the denylist")
        if self.allowed_models and model not in self.allowed_models:
            raise PolicyViolation("allowed_model", f"Model '{model}' is not on the allowlist")

    def check_tokens(self, input_tok: int, output_tok: int) -> None:
        """Raise PolicyViolation if token counts exceed limits."""
        if self.max_input_tokens and input_tok > self.max_input_tokens:
            raise PolicyViolation(
                "max_input_tokens",
                f"Input {input_tok} exceeds limit {self.max_input_tokens}",
            )
        if self.max_output_tokens and output_tok > self.max_output_tokens:
            raise PolicyViolation(
                "max_output_tokens",
                f"Output {output_tok} exceeds limit {self.max_output_tokens}",
            )

    def check_provider(self, provider: str) -> None:
        """Raise PolicyViolation if provider is not permitted."""
        if self.allowed_providers and provider not in self.allowed_providers:
            raise PolicyViolation(
                "allowed_provider",
                f"Provider '{provider}' is not on the allowlist",
            )


# Module-level default policy (permissive — override via set_default_policy)
_default_policy: Optional[Policy] = None


def get_default_policy() -> Optional[Policy]:
    return _default_policy


def set_default_policy(policy: Optional[Policy]) -> None:
    global _default_policy
    _default_policy = policy
