"""Compliance checks — data retention, PII handling, consent verification."""
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Optional


@dataclass
class RetentionPolicy:
    """Define how long different data types are kept."""
    traces_days: int = 90
    feedback_days: int = 365
    events_days: int = 30
    cache_events_days: int = 30


@dataclass
class ComplianceViolation(Exception):
    check: str
    detail: str

    def __str__(self) -> str:
        return f"Compliance violation [{self.check}]: {self.detail}"


def check_retention(ts: str, max_age_days: int) -> bool:
    """Return True if record is within retention window."""
    try:
        record_time = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
        return record_time >= cutoff
    except (ValueError, AttributeError):
        return True  # Can't parse — assume compliant


def purge_expired_records(conn, retention: Optional[RetentionPolicy] = None) -> dict:
    """Delete records outside their retention window. Returns counts per table."""
    policy = retention or RetentionPolicy()
    now = datetime.now(timezone.utc)
    counts: dict[str, int] = {}

    table_map = {
        "traces":        policy.traces_days,
        "feedback":      policy.feedback_days,
        "events":        policy.events_days,
        "cache_events":  policy.cache_events_days,
    }
    for table, days in table_map.items():
        cutoff = (now - timedelta(days=days)).isoformat()
        cur = conn.execute(f"DELETE FROM {table} WHERE ts < ?", (cutoff,))
        counts[table] = cur.rowcount

    conn.commit()
    return counts


@dataclass
class ConsentRecord:
    subject_id: str
    purpose: str
    granted: bool
    granted_at: Optional[str] = None
    expires_at: Optional[str] = None

    def is_valid(self) -> bool:
        if not self.granted:
            return False
        if self.expires_at:
            try:
                exp = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
                return datetime.now(timezone.utc) < exp
            except ValueError:
                return False
        return True
