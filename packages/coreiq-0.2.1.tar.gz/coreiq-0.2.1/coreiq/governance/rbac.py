"""Role-Based Access Control for CoreIQ operations."""
from dataclasses import dataclass, field

OPERATIONS = {
    "trace:read", "trace:write",
    "feedback:read", "feedback:write",
    "evolution:read", "evolution:write",
    "cache:read", "cache:write",
    "events:read", "events:write",
    "admin",
}

_ROLE_DEFAULTS: dict[str, set[str]] = {
    "viewer":    {"trace:read", "feedback:read", "cache:read", "events:read"},
    "operator":  {"trace:read", "trace:write", "feedback:read", "feedback:write",
                  "cache:read", "cache:write", "events:read", "events:write",
                  "evolution:read"},
    "admin":     set(OPERATIONS),
}


@dataclass
class Role:
    name: str
    permissions: set[str] = field(default_factory=set)

    @classmethod
    def from_preset(cls, name: str) -> "Role":
        perms = _ROLE_DEFAULTS.get(name)
        if perms is None:
            raise ValueError(f"Unknown role preset '{name}'. Known: {list(_ROLE_DEFAULTS)}")
        return cls(name=name, permissions=set(perms))

    def can(self, operation: str) -> bool:
        return "admin" in self.permissions or operation in self.permissions

    def require(self, operation: str) -> None:
        if not self.can(operation):
            raise PermissionError(f"Role '{self.name}' lacks permission for '{operation}'")


@dataclass
class Principal:
    id: str
    role: Role

    def can(self, operation: str) -> bool:
        return self.role.can(operation)

    def require(self, operation: str) -> None:
        self.role.require(operation)
