class CoreIQError(Exception):
    pass


class ValidationError(CoreIQError):
    pass


class DatabaseError(CoreIQError):
    pass


class ConfigError(CoreIQError):
    pass
