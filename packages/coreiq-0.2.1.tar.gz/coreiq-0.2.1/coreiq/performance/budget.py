"""Token/cost budget enforcement — track and enforce spending limits."""
import threading
from dataclasses import dataclass
from typing import Optional


@dataclass
class BudgetExceeded(Exception):
    dimension: str
    used: float
    limit: float

    def __str__(self) -> str:
        return f"Budget exceeded [{self.dimension}]: used={self.used:.2f}, limit={self.limit:.2f}"


@dataclass
class BudgetConfig:
    max_tokens_per_minute: Optional[int] = None
    max_cost_per_hour_usd: Optional[float] = None
    max_requests_per_minute: Optional[int] = None


class BudgetTracker:
    """Thread-safe rolling budget tracker (sliding window)."""

    def __init__(self, config: BudgetConfig):
        self._config = config
        self._lock = threading.Lock()
        import collections
        self._token_window: collections.deque = collections.deque()
        self._cost_window: collections.deque = collections.deque()
        self._req_window: collections.deque = collections.deque()

    def record(self, *, tokens: int = 0, cost_usd: float = 0.0) -> None:
        """Record usage and raise BudgetExceeded if any limit is breached."""
        import time
        now = time.monotonic()
        with self._lock:
            # Purge stale entries
            minute_ago = now - 60
            hour_ago = now - 3600
            while self._token_window and self._token_window[0][0] < minute_ago:
                self._token_window.popleft()
            while self._req_window and self._req_window[0][0] < minute_ago:
                self._req_window.popleft()
            while self._cost_window and self._cost_window[0][0] < hour_ago:
                self._cost_window.popleft()

            # Add new entries
            self._token_window.append((now, tokens))
            self._cost_window.append((now, cost_usd))
            self._req_window.append((now, 1))

            # Check limits
            if self._config.max_tokens_per_minute:
                used = sum(t for _, t in self._token_window)
                if used > self._config.max_tokens_per_minute:
                    raise BudgetExceeded("tokens_per_minute", used, self._config.max_tokens_per_minute)

            if self._config.max_cost_per_hour_usd:
                used_cost = sum(c for _, c in self._cost_window)
                if used_cost > self._config.max_cost_per_hour_usd:
                    raise BudgetExceeded("cost_per_hour_usd", used_cost, self._config.max_cost_per_hour_usd)

            if self._config.max_requests_per_minute:
                used_reqs = len(self._req_window)
                if used_reqs > self._config.max_requests_per_minute:
                    raise BudgetExceeded("requests_per_minute", used_reqs, self._config.max_requests_per_minute)

    @property
    def stats(self) -> dict:
        import time
        now = time.monotonic()
        with self._lock:
            return {
                "tokens_last_minute": sum(t for ts, t in self._token_window if ts > now - 60),
                "requests_last_minute": sum(1 for ts, _ in self._req_window if ts > now - 60),
                "cost_last_hour_usd": round(sum(c for ts, c in self._cost_window if ts > now - 3600), 6),
            }
