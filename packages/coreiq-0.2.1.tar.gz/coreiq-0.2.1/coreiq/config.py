"""Central configuration via environment variables."""
import os
from pathlib import Path


def get_db_path() -> Path:
    raw = os.environ.get("COREIQ_DB_PATH", "")
    if raw:
        return Path(raw)
    return Path.home() / ".coreiq" / "coreiq.db"


def get_api_key() -> str | None:
    """If set, all /api/* requests must include X-API-Key: <value> header."""
    return os.environ.get("COREIQ_API_KEY") or None


def get_host() -> str:
    return os.environ.get("COREIQ_HOST", "127.0.0.1")


def get_port() -> int:
    return int(os.environ.get("COREIQ_PORT", "7823"))


def get_log_level() -> str:
    return os.environ.get("COREIQ_LOG_LEVEL", "info").lower()


def get_log_json() -> bool:
    """If true, emit logs as JSON (for structured log aggregators)."""
    return os.environ.get("COREIQ_LOG_JSON", "").lower() in ("1", "true", "yes")


def get_cors_origins() -> list[str]:
    """Comma-separated allowed CORS origins. Defaults to localhost dev server."""
    raw = os.environ.get("COREIQ_CORS_ORIGINS", "")
    if raw:
        return [o.strip() for o in raw.split(",") if o.strip()]
    return ["http://localhost:5173"]


def get_rate_limit() -> int:
    """Max requests per minute per IP. 0 = disabled."""
    return int(os.environ.get("COREIQ_RATE_LIMIT", "0"))
