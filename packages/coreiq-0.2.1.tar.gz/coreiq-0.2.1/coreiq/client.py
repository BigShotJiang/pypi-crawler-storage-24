from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, Dict, Literal, Optional

from .store.writer import get_writer

_logger = logging.getLogger("coreiq")

if TYPE_CHECKING:
    from .evolution.feedback import FeedbackRecorder
    from .evolution.sdk import EvolutionSDK
    from .security.scanner import ScanResult
    from .performance.budget import BudgetTracker
    from .performance.cache import InMemorySemanticCache
    from .performance.router import ModelRouter
    from .status import StatusReport

Level = Literal["debug", "info", "warning", "error", "critical"]
_VALID_LEVELS = {"debug", "info", "warning", "error", "critical"}
_KNOWN_PROVIDERS = {"openai", "anthropic", "vllm", "sglang"}


class _ToolsInterface:
    """Unified interface for tool registration, validation, and routing."""

    def __init__(self, registry, validator, router):
        self._registry = registry
        self._validator = validator
        self._router = router

    def register(self, tools) -> None:
        self._registry.register(tools)

    def validate(self, tool_name: str, args_json: str):
        return self._validator.validate(tool_name, args_json)

    def select(self, query: str, top_k: int = 5):
        return self._router.select(query, top_k)

    def token_savings(self, selected, tokens_per_tool: int = 200) -> int:
        return self._router.token_savings(selected, tokens_per_tool)

    def __len__(self) -> int:
        return len(self._registry)


class CoreIQClient:
    def __init__(self, db_path=None, api_key=None, log_level="info", provider="openai", model="gpt-4o"):
        from .exceptions import ConfigError
        if provider not in _KNOWN_PROVIDERS:
            raise ConfigError(f"provider must be one of {sorted(_KNOWN_PROVIDERS)}, got '{provider}'")
        if log_level not in _VALID_LEVELS:
            raise ConfigError(f"log_level must be one of {sorted(_VALID_LEVELS)}, got '{log_level}'")
        self.db_path = db_path
        self.api_key = api_key
        self.log_level = log_level
        self.provider = provider
        self.model = model
        self._feedback: FeedbackRecorder | None = None
        self._evolution: EvolutionSDK | None = None
        self._tools_registry = None
        self._tools_validator = None
        self._tools_router = None
        self._cache: InMemorySemanticCache | None = None
        self._budget: BudgetTracker | None = None
        self._router: ModelRouter | None = None

    def __enter__(self) -> CoreIQClient:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        """Flush pending writes and release resources."""
        try:
            get_writer().flush()
            self._closed = True
        except Exception:
            pass

    @property
    def feedback(self) -> FeedbackRecorder:
        if self._feedback is None:
            from .evolution.feedback import get_feedback_recorder
            self._feedback = get_feedback_recorder()
        return self._feedback

    @property
    def evolution(self) -> EvolutionSDK:
        if self._evolution is None:
            from .evolution.sdk import EvolutionSDK
            self._evolution = EvolutionSDK()
        return self._evolution

    @property
    def tools(self) -> _ToolsInterface:
        if self._tools_registry is None:
            from .tools.registry import ToolRegistry
            from .tools.validator import ToolValidator
            from .tools.router import ToolRouter
            self._tools_registry = ToolRegistry()
            self._tools_validator = ToolValidator(self._tools_registry)
            self._tools_router = ToolRouter(self._tools_registry)
        return _ToolsInterface(self._tools_registry, self._tools_validator, self._tools_router)

    @property
    def cache(self) -> "InMemorySemanticCache":
        if self._cache is None:
            from .performance.cache import InMemorySemanticCache
            self._cache = InMemorySemanticCache()
        return self._cache

    def scan(self, messages: list[dict]) -> ScanResult:
        """Scan messages for injection, PII, and output violations."""
        from .security.scanner import scan_messages
        return scan_messages(messages)

    def scan_and_redact(self, messages: list[dict]) -> tuple:
        """Scan messages and return (ScanResult, redacted_messages).

        Combines security scanning with PII redaction in one call::

            result, clean_msgs = client.scan_and_redact(messages)
            if result.clean:
                response = llm.call(messages=clean_msgs)
        """
        from .security.scanner import scan_and_redact
        return scan_and_redact(messages)

    @property
    def budget(self) -> BudgetTracker:
        if self._budget is None:
            from .performance.budget import BudgetTracker, BudgetConfig
            self._budget = BudgetTracker(BudgetConfig())
        return self._budget

    @property
    def router(self) -> ModelRouter:
        if self._router is None:
            from .performance.router import ModelRouter
            self._router = ModelRouter(default_model=self.model)
        return self._router

    def log_event(
        self,
        message: str,
        metadata: Optional[Dict[str, Any]] = None,
        *,
        level: Level = "info",
        source: Optional[str] = None,
        trace_id: Optional[str] = None,
        **extra: Any,
    ) -> str:
        """Log a structured event to the CoreIQ store.

        Args:
            message:  Human-readable description of the event.
            metadata: Arbitrary key/value pairs attached to the event.
            level:    Severity — "debug", "info", "warning", "error", "critical".
            source:   Optional origin label (e.g. module name, agent ID).
            trace_id: Optionally link this event to an existing trace.
            **extra:  Extra key/value pairs merged into metadata.

        Returns:
            The generated event ID (UUID string).
        """
        if trace_id is None:
            from .tracing import get_current_trace_id
            trace_id = get_current_trace_id()
        if extra:
            metadata = {**(metadata or {}), **extra}
        _validate_level(level)
        try:
            return get_writer().insert_event(
                message=message,
                metadata=metadata,
                level=level,
                source=source,
                trace_id=trace_id,
            )
        except Exception as e:
            _logger.error("Failed to write event: %s", e)
            from .exceptions import DatabaseError
            raise DatabaseError(f"Failed to log event: {e}") from e

    def query_events(
        self,
        *,
        level: Optional[str] = None,
        source: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict]:
        """Query stored events programmatically.

        Args:
            level:  Filter by level (debug, info, warning, error, critical).
            source: Filter by source label.
            limit:  Max rows to return (default 100).

        Returns:
            List of event dicts with keys: id, level, message, metadata, source, trace_id, ts.
        """
        from .store.db import get_shared_connection
        conn = get_shared_connection()
        where, params = [], []
        if level:
            where.append("level = ?")
            params.append(level)
        if source:
            where.append("source = ?")
            params.append(source)
        clause = ("WHERE " + " AND ".join(where)) if where else ""
        rows = conn.execute(
            f"SELECT * FROM events {clause} ORDER BY ts DESC LIMIT ?",
            (*params, limit),
        ).fetchall()
        return [
            {
                "id": r["id"], "level": r["level"], "message": r["message"],
                "metadata": json.loads(r["meta_json"]) if r["meta_json"] else None,
                "source": r["source"], "trace_id": r["trace_id"], "ts": r["ts"],
            }
            for r in rows
        ]

    def status(self) -> "StatusReport":
        """Return a zero-token system health summary (last 7 days).

        Usage::

            status = client.status()
            print(status)             # human-readable
            status.to_dict()          # machine-readable
        """
        from .status import build_status
        return build_status()

    def _record_tool_call(
        self,
        trace_id: str,
        tool_name: str,
        args: Dict[str, Any],
        valid: bool = True,
        error: Optional[str] = None,
    ) -> None:
        get_writer().insert_tool_call(
            trace_id=trace_id,
            tool_name=tool_name,
            args_json=json.dumps(args),
            valid=valid,
            error=error,
        )


def _validate_level(level: str) -> str:
    if level not in _VALID_LEVELS:
        from .exceptions import ValidationError
        raise ValidationError(f"level must be one of {sorted(_VALID_LEVELS)}, got '{level}'")
    return level


def log_event(
    message: str,
    metadata: Optional[Dict[str, Any]] = None,
    *,
    level: Level = "info",
    source: Optional[str] = None,
    trace_id: Optional[str] = None,
    **extra: Any,
) -> str:
    """Module-level convenience wrapper for logging a structured event.

    Usage::

        import coreiq
        coreiq.log_event("user signed up", {"plan": "pro", "user_id": "u_123"})
        coreiq.log_event("payment failed", {"amount": 49.99}, level="error")
        coreiq.log_event("signup", plan="pro", user_id="u1")
    """
    if trace_id is None:
        from .tracing import get_current_trace_id
        trace_id = get_current_trace_id()
    if extra:
        metadata = {**(metadata or {}), **extra}
    _validate_level(level)
    try:
        return get_writer().insert_event(
            message=message,
            metadata=metadata,
            level=level,
            source=source,
            trace_id=trace_id,
        )
    except Exception as e:
        _logger.error("Failed to write event: %s", e)
        from .exceptions import DatabaseError
        raise DatabaseError(f"Failed to log event: {e}") from e
