"""Context-variable trace propagation for CoreIQ."""
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Optional


_current_trace_id: ContextVar[Optional[str]] = ContextVar('_current_trace_id', default=None)


def get_current_trace_id() -> Optional[str]:
    """Return the trace_id active in the current async/thread context."""
    return _current_trace_id.get()


@dataclass
class TraceSpan:
    id: str
    name: str


@contextmanager
def trace(name: str, trace_id: Optional[str] = None):
    """Context manager that sets a trace_id for all nested CoreIQ calls.

    Usage::

        with coreiq.trace("agent-task") as span:
            coreiq.log_event("step 1")  # auto-carries span.id as trace_id
    """
    tid = trace_id or str(uuid.uuid4())
    token = _current_trace_id.set(tid)
    span = TraceSpan(id=tid, name=name)
    try:
        yield span
    finally:
        _current_trace_id.reset(token)
