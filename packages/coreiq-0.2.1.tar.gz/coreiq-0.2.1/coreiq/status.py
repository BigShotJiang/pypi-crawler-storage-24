"""Zero-token system health summary — pure DB aggregation, no LLM calls."""
import json
from dataclasses import dataclass, asdict
from typing import Optional

from .store.db import get_shared_connection, init_schema


@dataclass
class StatusReport:
    cache_hit_rate: float
    cache_hit_rate_delta: float
    token_savings_7d: int
    token_savings_usd: float
    best_variant_id: Optional[str]
    best_variant_win_rate: float
    best_variant_samples: int
    tool_error_count: int
    tool_error_rate: float
    evolution_phase: str
    samples_to_promote: int

    PROMOTE_THRESHOLD: int = 50

    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("PROMOTE_THRESHOLD", None)
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    def __repr__(self) -> str:
        arrow = "\u2191" if self.cache_hit_rate_delta >= 0 else "\u2193"
        delta_pct = abs(self.cache_hit_rate_delta * 100)
        lines = [
            "CoreIQ Status (last 7 days)",
            "\u2500" * 35,
            f"Cache hit rate:    {self.cache_hit_rate*100:.0f}%   {arrow} {delta_pct:.0f}% vs last week",
            f"Token savings:     {self.token_savings_7d:,} tokens  (${self.token_savings_usd:.2f} saved)",
        ]
        if self.best_variant_id:
            lines.append(
                f"Best variant:      {self.best_variant_id}  "
                f"({self.best_variant_win_rate*100:.0f}% win rate, {self.best_variant_samples} samples)"
            )
        else:
            lines.append("Best variant:      none yet")
        lines.append(
            f"Tool errors:       {self.tool_error_count} invalid calls "
            f"({self.tool_error_rate*100:.1f}% error rate)"
        )
        if self.samples_to_promote > 0:
            lines.append(
                f"Evolution phase:   {self.evolution_phase} "
                f"(need {self.samples_to_promote} more samples to promote)"
            )
        else:
            lines.append(f"Evolution phase:   {self.evolution_phase}")
        lines.append("\u2500" * 35)
        return "\n".join(lines)


def build_status() -> StatusReport:
    """Build a StatusReport from DB aggregation. Zero LLM tokens."""
    conn = get_shared_connection()
    init_schema(conn)

    # Cache hit rate + token savings (last 7 days)
    r = conn.execute("""
        SELECT
            COALESCE(AVG(CASE WHEN hit=1 THEN 1.0 ELSE 0.0 END), 0.0) AS hit_rate,
            COALESCE(SUM(CASE WHEN hit=1 THEN saved_tok ELSE 0 END), 0) AS saved_tok
        FROM cache_events
        WHERE ts >= datetime('now', '-7 days')
    """).fetchone()
    hit_rate = float(r["hit_rate"]) if r else 0.0
    saved_tok = int(r["saved_tok"]) if r else 0

    # Prior period hit rate for delta
    r_prior = conn.execute("""
        SELECT COALESCE(AVG(CASE WHEN hit=1 THEN 1.0 ELSE 0.0 END), 0.0) AS hit_rate
        FROM cache_events
        WHERE ts >= datetime('now', '-14 days') AND ts < datetime('now', '-7 days')
    """).fetchone()
    prior_rate = float(r_prior["hit_rate"]) if r_prior else 0.0
    delta = hit_rate - prior_rate

    # Cost at $3/1M tokens (GPT-4o input approx)
    cost = (saved_tok / 1_000_000) * 3.0

    # Best non-promoted variant
    best_row = conn.execute("""
        SELECT variant_id, win_rate, samples FROM evolution
        WHERE promoted = 0
        ORDER BY win_rate DESC LIMIT 1
    """).fetchone()
    best_id = best_row["variant_id"] if best_row else None
    best_wr = float(best_row["win_rate"]) if best_row else 0.0
    best_samples = int(best_row["samples"]) if best_row else 0

    # Tool call errors
    tc = conn.execute("""
        SELECT
            COUNT(*) AS total,
            COALESCE(SUM(CASE WHEN valid=0 THEN 1 ELSE 0 END), 0) AS errors
        FROM tool_calls
        WHERE ts >= datetime('now', '-7 days')
    """).fetchone()
    total_tc = int(tc["total"]) if tc else 0
    error_tc = int(tc["errors"]) if tc else 0
    error_rate = error_tc / total_tc if total_tc > 0 else 0.0

    # Evolution phase
    phase_row = conn.execute("""
        SELECT phase FROM evolution ORDER BY ts DESC LIMIT 1
    """).fetchone()
    phase = phase_row["phase"] if phase_row else "observing"

    samples_to_promote = max(0, 50 - best_samples)

    return StatusReport(
        cache_hit_rate=hit_rate,
        cache_hit_rate_delta=delta,
        token_savings_7d=saved_tok,
        token_savings_usd=cost,
        best_variant_id=best_id,
        best_variant_win_rate=best_wr,
        best_variant_samples=best_samples,
        tool_error_count=error_tc,
        tool_error_rate=error_rate,
        evolution_phase=phase,
        samples_to_promote=samples_to_promote,
    )
