"""Model registry — central catalog of known models and their capabilities."""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ModelSpec:
    id: str
    provider: str
    context_window: int
    input_cost_per_1k: float   # USD
    output_cost_per_1k: float  # USD
    supports_tools: bool = True
    supports_vision: bool = False
    max_output_tokens: Optional[int] = None
    tags: list[str] = field(default_factory=list)

    def estimate_cost(self, input_tok: int, output_tok: int) -> float:
        return (input_tok / 1000 * self.input_cost_per_1k
                + output_tok / 1000 * self.output_cost_per_1k)


_REGISTRY: dict[str, ModelSpec] = {
    # OpenAI
    "gpt-4o": ModelSpec(
        id="gpt-4o", provider="openai", context_window=128_000,
        input_cost_per_1k=0.005, output_cost_per_1k=0.015,
        supports_vision=True, tags=["flagship", "vision"],
    ),
    "gpt-4o-mini": ModelSpec(
        id="gpt-4o-mini", provider="openai", context_window=128_000,
        input_cost_per_1k=0.00015, output_cost_per_1k=0.0006,
        supports_vision=True, tags=["fast", "cheap"],
    ),
    "gpt-3.5-turbo": ModelSpec(
        id="gpt-3.5-turbo", provider="openai", context_window=16_385,
        input_cost_per_1k=0.0005, output_cost_per_1k=0.0015,
        tags=["legacy"],
    ),
    # Anthropic
    "claude-opus-4-6": ModelSpec(
        id="claude-opus-4-6", provider="anthropic", context_window=200_000,
        input_cost_per_1k=0.015, output_cost_per_1k=0.075,
        supports_vision=True, tags=["flagship"],
    ),
    "claude-sonnet-4-6": ModelSpec(
        id="claude-sonnet-4-6", provider="anthropic", context_window=200_000,
        input_cost_per_1k=0.003, output_cost_per_1k=0.015,
        supports_vision=True, tags=["balanced"],
    ),
    "claude-haiku-4-5-20251001": ModelSpec(
        id="claude-haiku-4-5-20251001", provider="anthropic", context_window=200_000,
        input_cost_per_1k=0.00025, output_cost_per_1k=0.00125,
        supports_vision=True, tags=["fast", "cheap"],
    ),
}


def get_model(model_id: str) -> Optional[ModelSpec]:
    return _REGISTRY.get(model_id)


def register_model(spec: ModelSpec) -> None:
    _REGISTRY[spec.id] = spec


def list_models(provider: Optional[str] = None, tag: Optional[str] = None) -> list[ModelSpec]:
    models = list(_REGISTRY.values())
    if provider:
        models = [m for m in models if m.provider == provider]
    if tag:
        models = [m for m in models if tag in m.tags]
    return models
