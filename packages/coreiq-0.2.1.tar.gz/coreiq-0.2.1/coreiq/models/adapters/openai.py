"""OpenAI adapter — wraps openai.OpenAI with CoreIQ tracing."""
import time
from typing import Any, Optional

from ...store.writer import get_writer


def create_chat_completion(
    client,
    *,
    model: str,
    messages: list[dict],
    trace_id: Optional[str] = None,
    budget=None,
    **kwargs,
) -> Any:
    """
    Call client.chat.completions.create() and record a trace.
    client: openai.OpenAI or AsyncOpenAI instance (sync version).
    Returns the completion object unchanged.
    """
    import uuid
    t_id = trace_id or str(uuid.uuid4())
    start = time.monotonic()
    try:
        response = client.chat.completions.create(model=model, messages=messages, **kwargs)
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage", None)
        finish = response.choices[0].finish_reason if response.choices else "stop"
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="openai",
            input_tok=usage.prompt_tokens if usage else 0,
            output_tok=usage.completion_tokens if usage else 0,
            latency_ms=latency_ms,
            finish_reason=finish or "stop",
        )
        if budget and usage:
            try:
                budget.record(tokens=usage.prompt_tokens + usage.completion_tokens)
            except Exception:
                pass  # don't fail the call if budget tracking fails
        return response
    except Exception:
        latency_ms = int((time.monotonic() - start) * 1000)
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="openai",
            input_tok=0,
            output_tok=0,
            latency_ms=latency_ms,
            finish_reason="error",
        )
        raise


async def async_create_chat_completion(
    client,
    *,
    model: str,
    messages: list[dict],
    trace_id: Optional[str] = None,
    **kwargs,
) -> Any:
    """Async version — call client.chat.completions.create() and record a trace."""
    import uuid
    t_id = trace_id or str(uuid.uuid4())
    start = time.monotonic()
    try:
        response = await client.chat.completions.create(model=model, messages=messages, **kwargs)
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage", None)
        finish = response.choices[0].finish_reason if response.choices else "stop"
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="openai",
            input_tok=usage.prompt_tokens if usage else 0,
            output_tok=usage.completion_tokens if usage else 0,
            latency_ms=latency_ms,
            finish_reason=finish or "stop",
        )
        return response
    except Exception:
        latency_ms = int((time.monotonic() - start) * 1000)
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="openai",
            input_tok=0,
            output_tok=0,
            latency_ms=latency_ms,
            finish_reason="error",
        )
        raise
