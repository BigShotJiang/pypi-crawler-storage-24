"""SGLang adapter — calls SGLang OpenAI-compatible endpoint with CoreIQ tracing."""
import time
import uuid
from typing import Any, Optional

from ...store.writer import get_writer


def create_chat_completion(
    base_url: str,
    *,
    model: str,
    messages: list[dict],
    api_key: str = "sglang",
    trace_id: Optional[str] = None,
    **kwargs,
) -> Any:
    """
    Call a SGLang OpenAI-compatible endpoint using httpx.
    Returns the parsed JSON response dict.
    """
    import httpx

    t_id = trace_id or str(uuid.uuid4())
    url = base_url.rstrip("/") + "/v1/chat/completions"
    payload = {"model": model, "messages": messages, **kwargs}
    start = time.monotonic()
    try:
        resp = httpx.post(url, json=payload, headers={"Authorization": f"Bearer {api_key}"}, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = data.get("usage", {})
        choices = data.get("choices", [{}])
        finish = choices[0].get("finish_reason", "stop") if choices else "stop"
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="sglang",
            input_tok=usage.get("prompt_tokens", 0),
            output_tok=usage.get("completion_tokens", 0),
            latency_ms=latency_ms,
            finish_reason=finish,
        )
        return data
    except Exception:
        latency_ms = int((time.monotonic() - start) * 1000)
        get_writer().insert_trace(
            id=t_id, model=model, provider="sglang",
            input_tok=0, output_tok=0, latency_ms=latency_ms, finish_reason="error",
        )
        raise


async def async_create_chat_completion(
    base_url: str,
    *,
    model: str,
    messages: list[dict],
    api_key: str = "sglang",
    trace_id: Optional[str] = None,
    **kwargs,
) -> dict:
    """Async version — call a SGLang endpoint using httpx.AsyncClient."""
    import httpx

    t_id = trace_id or str(uuid.uuid4())
    url = base_url.rstrip("/") + "/v1/chat/completions"
    payload = {"model": model, "messages": messages, **kwargs}
    start = time.monotonic()
    try:
        async with httpx.AsyncClient() as http:
            resp = await http.post(url, json=payload, headers={"Authorization": f"Bearer {api_key}"}, timeout=60)
            resp.raise_for_status()
            data = resp.json()
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = data.get("usage", {})
        choices = data.get("choices", [{}])
        finish = choices[0].get("finish_reason", "stop") if choices else "stop"
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="sglang",
            input_tok=usage.get("prompt_tokens", 0),
            output_tok=usage.get("completion_tokens", 0),
            latency_ms=latency_ms,
            finish_reason=finish,
        )
        return data
    except Exception:
        latency_ms = int((time.monotonic() - start) * 1000)
        get_writer().insert_trace(
            id=t_id, model=model, provider="sglang",
            input_tok=0, output_tok=0, latency_ms=latency_ms, finish_reason="error",
        )
        raise
