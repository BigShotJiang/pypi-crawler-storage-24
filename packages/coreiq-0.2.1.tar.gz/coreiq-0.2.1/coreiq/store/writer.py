import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from .db import create_connection, init_schema
from ..config import get_db_path


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class EventWriter:
    def __init__(self, db_path: Optional[Path] = None):
        self._lock = threading.Lock()
        self._conn = create_connection(db_path or get_db_path())
        init_schema(self._conn)
        self._buffer: list = []
        self._buffer_limit = 50
        self._flush_interval = 0.5  # seconds
        self._timer: Optional[threading.Timer] = None
        self._start_flush_timer()

    def _start_flush_timer(self):
        self._timer = threading.Timer(self._flush_interval, self._auto_flush)
        self._timer.daemon = True
        self._timer.start()

    def _auto_flush(self):
        with self._lock:
            self._flush_unlocked()
        self._start_flush_timer()

    def _flush_unlocked(self):
        """Flush buffer while lock is held."""
        if not self._buffer:
            return
        for sql, params in self._buffer:
            self._conn.execute(sql, params)
        self._conn.commit()
        self._buffer.clear()

    def flush(self):
        """Public flush — force all buffered writes to disk."""
        with self._lock:
            self._flush_unlocked()

    def close(self):
        """Flush and close. Called on shutdown."""
        if self._timer:
            self._timer.cancel()
        self.flush()

    def _buffer_write(self, sql: str, params: tuple) -> None:
        """Append a write to the buffer and flush if limit reached. Caller holds lock."""
        self._buffer.append((sql, params))
        if len(self._buffer) >= self._buffer_limit:
            self._flush_unlocked()

    def insert_trace(self, *, id: str, model: str, provider: str,
                     input_tok: int, output_tok: int, latency_ms: int,
                     finish_reason: str = "stop", cache_hit: bool = False,
                     ts: Optional[str] = None,
                     meta_json: Optional[str] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO traces VALUES (?,?,?,?,?,?,?,?,?,?)",
                (id, model, provider, input_tok, output_tok, latency_ms,
                 finish_reason, int(cache_hit), ts or _now(), meta_json)
            )

    def insert_cache_event(self, *, trace_id: str, hit: bool,
                           similarity: float = 0.0, saved_tok: int = 0,
                           backend: str = "memory", ts: Optional[str] = None,
                           id: Optional[str] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO cache_events VALUES (?,?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), trace_id, int(hit), similarity,
                 saved_tok, backend, ts or _now())
            )

    def insert_tool_call(self, *, trace_id: str, tool_name: str,
                         args_json: str, valid: bool = True,
                         error: Optional[str] = None,
                         ts: Optional[str] = None,
                         id: Optional[str] = None,
                         result_json: Optional[str] = None,
                         duration_ms: Optional[int] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO tool_calls VALUES (?,?,?,?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), trace_id, tool_name, args_json,
                 int(valid), error, ts or _now(), result_json, duration_ms)
            )

    def insert_feedback(self, *, response_id: str, signal: str,
                        value: float = 0.0, dimension: Optional[str] = None,
                        correction: Optional[str] = None,
                        ts: Optional[str] = None,
                        id: Optional[str] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO feedback VALUES (?,?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), response_id, signal, value,
                 dimension, correction, ts or _now())
            )

    def insert_evolution(self, *, variant_id: str, phase: str,
                         win_rate: float = 0.0, samples: int = 0,
                         promoted: bool = False, ts: Optional[str] = None,
                         id: Optional[str] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO evolution VALUES (?,?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), variant_id, phase, win_rate,
                 samples, int(promoted), ts or _now())
            )

    def insert_query_recon(self, *, trace_id: str, original: str,
                           reconstructed: str, similarity: float = 0.0,
                           ts: Optional[str] = None,
                           id: Optional[str] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO query_recon VALUES (?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), trace_id, original, reconstructed,
                 similarity, ts or _now())
            )

    def insert_event(self, *, message: str,
                     level: str = "info",
                     metadata: Optional[Dict[str, Any]] = None,
                     source: Optional[str] = None,
                     trace_id: Optional[str] = None,
                     ts: Optional[str] = None,
                     id: Optional[str] = None) -> str:
        event_id = id or str(uuid.uuid4())
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO events VALUES (?,?,?,?,?,?,?)",
                (event_id, level, message,
                 json.dumps(metadata) if metadata else None,
                 source, trace_id, ts or _now())
            )
        return event_id

    def persist_bandit_state(self, arms: dict) -> None:
        """Persist bandit alpha/beta weights. arms: {variant_id: (alpha, beta)}
        Immediate commit — not buffered (consistency-critical)."""
        now = _now()
        with self._lock:
            self._flush_unlocked()  # flush pending buffer first
            for vid, (alpha, beta) in arms.items():
                self._conn.execute(
                    "INSERT OR REPLACE INTO bandit_state(variant_id, alpha, beta, updated_at) VALUES(?,?,?,?)",
                    (vid, alpha, beta, now)
                )
            self._conn.commit()


_writer: Optional[EventWriter] = None
_writer_lock = threading.Lock()


def get_writer() -> EventWriter:
    global _writer
    if _writer is None:
        with _writer_lock:
            if _writer is None:
                _writer = EventWriter()
    return _writer
