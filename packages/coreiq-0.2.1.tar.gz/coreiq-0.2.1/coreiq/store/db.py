import sqlite3
import threading
from pathlib import Path

from ..config import get_db_path

_shared_conn: sqlite3.Connection | None = None
_shared_conn_path: str | None = None
_shared_conn_lock = threading.Lock()


def create_connection(db_path: Path | None = None) -> sqlite3.Connection:
    if db_path is None:
        db_path = get_db_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def get_shared_connection() -> sqlite3.Connection:
    """Return a shared read connection. Re-creates if the DB path has changed."""
    global _shared_conn, _shared_conn_path
    current_path = str(get_db_path())
    if _shared_conn is None or _shared_conn_path != current_path:
        with _shared_conn_lock:
            if _shared_conn is None or _shared_conn_path != current_path:
                _shared_conn = create_connection()
                _shared_conn_path = current_path
    return _shared_conn


def init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS traces (
            id          TEXT PRIMARY KEY,
            model       TEXT,
            provider    TEXT,
            input_tok   INTEGER,
            output_tok  INTEGER,
            latency_ms  INTEGER,
            finish_reason TEXT,
            cache_hit   INTEGER DEFAULT 0,
            ts          TEXT,
            meta_json   TEXT
        );

        CREATE TABLE IF NOT EXISTS cache_events (
            id          TEXT PRIMARY KEY,
            trace_id    TEXT REFERENCES traces(id),
            hit         INTEGER,
            similarity  REAL,
            saved_tok   INTEGER,
            backend     TEXT,
            ts          TEXT
        );

        CREATE TABLE IF NOT EXISTS tool_calls (
            id          TEXT PRIMARY KEY,
            trace_id    TEXT REFERENCES traces(id),
            tool_name   TEXT,
            args_json   TEXT,
            valid       INTEGER DEFAULT 1,
            error       TEXT,
            ts          TEXT,
            result_json TEXT,
            duration_ms INTEGER
        );

        CREATE TABLE IF NOT EXISTS feedback (
            id          TEXT PRIMARY KEY,
            response_id TEXT,
            signal      TEXT,
            value       REAL,
            dimension   TEXT,
            correction  TEXT,
            ts          TEXT
        );

        CREATE TABLE IF NOT EXISTS evolution (
            id          TEXT PRIMARY KEY,
            variant_id  TEXT,
            phase       TEXT,
            win_rate    REAL,
            samples     INTEGER,
            promoted    INTEGER DEFAULT 0,
            ts          TEXT
        );

        CREATE TABLE IF NOT EXISTS query_recon (
            id          TEXT PRIMARY KEY,
            trace_id    TEXT REFERENCES traces(id),
            original    TEXT,
            reconstructed TEXT,
            similarity  REAL,
            ts          TEXT
        );

        CREATE TABLE IF NOT EXISTS events (
            id          TEXT PRIMARY KEY,
            level       TEXT DEFAULT 'info',
            message     TEXT NOT NULL,
            meta_json   TEXT,
            source      TEXT,
            trace_id    TEXT,
            ts          TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_traces_ts ON traces(ts);
        CREATE INDEX IF NOT EXISTS idx_traces_provider ON traces(provider);
        CREATE INDEX IF NOT EXISTS idx_tool_calls_name ON tool_calls(tool_name);
        CREATE INDEX IF NOT EXISTS idx_feedback_signal ON feedback(signal);
        CREATE INDEX IF NOT EXISTS idx_cache_events_trace ON cache_events(trace_id);
        CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
        CREATE INDEX IF NOT EXISTS idx_events_level ON events(level);

        CREATE TABLE IF NOT EXISTS bandit_state (
            variant_id  TEXT PRIMARY KEY,
            alpha       REAL DEFAULT 1.0,
            beta        REAL DEFAULT 1.0,
            updated_at  TEXT
        );

        CREATE TABLE IF NOT EXISTS optimiser_config (
            key         TEXT PRIMARY KEY,
            value       TEXT,
            updated_at  TEXT
        );

        CREATE TABLE IF NOT EXISTS deploy_history (
            id              TEXT PRIMARY KEY,
            config_snapshot TEXT,
            environment     TEXT,
            deployed_at     TEXT,
            note            TEXT
        );
    """)
    # Migration: add new columns to existing DBs
    for ddl in [
        "ALTER TABLE traces ADD COLUMN meta_json TEXT",
        "ALTER TABLE tool_calls ADD COLUMN result_json TEXT",
        "ALTER TABLE tool_calls ADD COLUMN duration_ms INTEGER",
        "CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts)",
        "CREATE INDEX IF NOT EXISTS idx_events_level ON events(level)",
    ]:
        try:
            conn.execute(ddl)
        except Exception:
            pass
    conn.commit()
