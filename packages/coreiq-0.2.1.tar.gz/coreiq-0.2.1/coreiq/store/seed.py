"""Generate realistic fake events into ~/.coreiq/coreiq.db for dashboard dev."""
import random
import uuid
import json
from datetime import datetime, timezone, timedelta

from .writer import EventWriter
from .db import get_db_path


PROVIDERS = ["openai", "anthropic", "openai", "anthropic", "openai"]
MODELS = {
    "openai": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo"],
    "anthropic": ["claude-3-5-sonnet-20241022", "claude-3-haiku-20240307"],
}
TOOL_NAMES = ["get_weather", "search_docs", "query_db", "send_email", "calc_price"]
PHASES = ["observing", "experimenting", "promoting"]
VARIANTS = ["variant-alpha", "variant-beta", "variant-gamma"]
SIGNALS = ["thumbs_up", "thumbs_down", "score"]
DIMENSIONS = ["accuracy", "helpfulness", "tone", None]

USER_MSGS = [
    "What is the weather forecast for San Francisco this weekend?",
    "Find me documentation about JWT authentication in our system.",
    "How do I write a SQL query to get all users who signed up this month?",
    "Send a status report to the engineering team about this week's deployment.",
    "Calculate the total price for an order of 10 units at $14.99 each with 8% tax.",
    "Summarize the latest changes in the authentication module.",
    "What are the top 5 errors in production logs from the last 24 hours?",
    "Generate a weekly summary report for the executive team.",
    "Look up the API rate limits for our third-party payment provider.",
    "Help me debug this TypeScript error: Type 'string' is not assignable to type 'number'.",
]

ASSISTANT_MSGS = [
    "The weather in San Francisco this weekend looks mild — Saturday will be 62°F with some morning fog clearing by noon, Sunday partly cloudy at 65°F. No rain expected.",
    "I found the JWT authentication documentation. Your system uses HS256 signing with a 24-hour expiry. The middleware is in `src/auth/jwt.middleware.ts` and tokens are validated on every protected route.",
    "Here's the SQL query for users who signed up this month:\n```sql\nSELECT id, email, created_at FROM users\nWHERE created_at >= DATE_TRUNC('month', CURRENT_DATE)\nORDER BY created_at DESC;\n```",
    "Status report sent to engineering@company.com. Subject: 'Deployment Status – Week 47'. I summarized the 3 services deployed, 2 hotfixes, and current uptime at 99.94%.",
    "For 10 units at $14.99 each: subtotal $149.90, tax (8%) $11.99, **total $161.89**.",
    "The authentication module had 3 changes this week: added refresh token rotation, fixed a session expiry edge case, and updated the OAuth2 scopes for Google SSO.",
    "Top 5 production errors (last 24h): (1) NullPointerException in PaymentService ×47, (2) DB connection timeout ×23, (3) 429 rate limit from Stripe ×18, (4) JWT expiry not handled ×12, (5) S3 upload timeout ×8.",
    "Weekly executive summary drafted. Highlights: 98.7% uptime, 12% increase in API throughput, 3 new features shipped, 0 P0 incidents.",
    "The payment provider (Stripe) rate limits: 100 req/s in test mode, 100 req/s in live mode per API key. Webhooks are separate at 1000/s. Recommend implementing exponential backoff.",
    "The TypeScript error occurs because `userId` is typed as `number` in the interface but you're passing `req.params.id` which is always a `string`. Fix: `const userId = parseInt(req.params.id, 10);`",
]

TOOL_ARGS = {
    "get_weather": [
        {"city": "San Francisco", "units": "fahrenheit", "days": 3},
        {"city": "New York", "units": "celsius", "days": 7},
        {"city": "London", "units": "celsius", "days": 2},
    ],
    "search_docs": [
        {"query": "JWT authentication middleware", "limit": 5},
        {"query": "OAuth2 scopes configuration", "limit": 10},
        {"query": "rate limiting best practices", "limit": 5},
    ],
    "query_db": [
        {"table": "users", "filter": "created_at >= '2024-01-01'", "limit": 100},
        {"table": "orders", "filter": "status = 'pending'", "limit": 50},
        {"table": "events", "filter": "level = 'error'", "limit": 200},
    ],
    "send_email": [
        {"to": "engineering@company.com", "subject": "Weekly Status Report", "template": "weekly_summary"},
        {"to": "cto@company.com", "subject": "Incident Report", "template": "incident_summary"},
        {"to": "team@company.com", "subject": "Deployment Complete", "template": "deploy_notify"},
    ],
    "calc_price": [
        {"quantity": 10, "unit_price": 14.99, "tax_rate": 0.08},
        {"quantity": 5, "unit_price": 99.00, "tax_rate": 0.10},
        {"quantity": 100, "unit_price": 2.49, "tax_rate": 0.07},
    ],
}

TOOL_RESULTS = {
    "get_weather": [
        {"status": "ok", "forecast": [{"day": "Saturday", "temp_f": 62, "condition": "Partly cloudy"}]},
        {"status": "ok", "forecast": [{"day": "Monday", "temp_c": 18, "condition": "Sunny"}]},
    ],
    "search_docs": [
        {"status": "ok", "results": [{"title": "JWT Setup Guide", "path": "docs/auth/jwt.md", "score": 0.94}]},
        {"status": "ok", "results": [{"title": "OAuth2 Config", "path": "docs/auth/oauth2.md", "score": 0.89}]},
    ],
    "query_db": [
        {"status": "ok", "rows": 42, "sample": [{"id": 1, "email": "user@example.com"}]},
        {"status": "ok", "rows": 7, "sample": [{"id": 101, "status": "pending", "amount": 49.99}]},
    ],
    "send_email": [
        {"status": "sent", "message_id": "msg_abc123", "accepted": ["engineering@company.com"]},
        {"status": "sent", "message_id": "msg_def456", "accepted": ["cto@company.com"]},
    ],
    "calc_price": [
        {"status": "ok", "subtotal": 149.90, "tax": 11.99, "total": 161.89},
        {"status": "ok", "subtotal": 495.00, "tax": 49.50, "total": 544.50},
    ],
}

TOOL_ERRORS = [
    "ValidationError: missing required field 'location'",
    "ValidationError: 'quantity' must be a positive integer",
    "TimeoutError: database query exceeded 5000ms",
    "AuthError: API key expired or invalid",
    "RateLimitError: exceeded 100 requests per minute",
]

CACHE_BACKENDS = ["redis", "memory", "disk"]

ORIGINALS = [
    "What is the weather today?",
    "Find me docs about authentication",
    "How do I query the database for recent signups?",
    "Send a status report to the team",
    "Calculate the price for 10 units",
    "Summarize last week's production incidents",
    "What are the current API rate limits?",
    "Debug this TypeScript compilation error",
]

RECONSTRUCTED_SUFFIXES = [
    " [semantic: reformulated as direct query]",
    " [semantic: expanded with context]",
    " [semantic: compressed to key terms]",
    " [semantic: normalized to canonical form]",
]

CORRECTIONS = [
    "The answer was missing the tax calculation breakdown. Should show subtotal, tax amount, and total separately.",
    "The SQL query used the wrong date function — should use DATE_TRUNC for PostgreSQL, not DATE_FORMAT.",
    "Response didn't mention the retry logic needed for rate limit errors.",
    "The weather forecast was for the wrong city — user asked for SF not NY.",
    "Email was sent to the wrong distribution list.",
    "The documentation link provided was outdated — the auth module was refactored in v2.3.",
]


def random_ts(days_ago: int = 7) -> str:
    delta = timedelta(seconds=random.randint(0, days_ago * 86400))
    return (datetime.now(timezone.utc) - delta).isoformat()


def seed(n_traces: int = 200, clear: bool = False):
    db_path = get_db_path()
    writer = EventWriter(db_path)

    if clear:
        conn = writer._conn
        for table in ["query_recon", "tool_calls", "cache_events", "feedback", "evolution", "traces"]:
            conn.execute(f"DELETE FROM {table}")
        conn.commit()

    trace_ids = []

    # Traces
    for _ in range(n_traces):
        tid = str(uuid.uuid4())
        trace_ids.append(tid)
        provider = random.choice(PROVIDERS)
        model = random.choice(MODELS[provider])
        cache_hit = random.random() < 0.60
        input_tok = random.randint(100, 4000)
        output_tok = random.randint(50, 1500)
        finish_reason = random.choice(["stop", "stop", "stop", "length", "tool_calls", "error"])
        cost_per_input = {"openai": 0.000005, "anthropic": 0.000003}.get(provider, 0.000004)
        cost_per_output = {"openai": 0.000015, "anthropic": 0.000015}.get(provider, 0.000012)
        cost_usd = round(input_tok * cost_per_input + output_tok * cost_per_output, 6)
        user_msg = random.choice(USER_MSGS)
        assistant_msg = random.choice(ASSISTANT_MSGS)
        meta = {"cost_usd": cost_usd, "user_msg": user_msg, "assistant_msg": assistant_msg}
        writer.insert_trace(
            id=tid,
            model=model,
            provider=provider,
            input_tok=input_tok,
            output_tok=output_tok,
            latency_ms=random.randint(200, 8000),
            finish_reason=finish_reason,
            cache_hit=cache_hit,
            ts=random_ts(),
            meta_json=json.dumps(meta),
        )
        # Cache event
        backend = random.choice(CACHE_BACKENDS)
        writer.insert_cache_event(
            trace_id=tid,
            hit=cache_hit,
            similarity=random.uniform(0.85, 1.0) if cache_hit else random.uniform(0.3, 0.7),
            saved_tok=random.randint(100, 1500) if cache_hit else 0,
            backend=backend,
        )
        # Query recon (50% of traces)
        if random.random() < 0.5:
            orig = random.choice(ORIGINALS)
            writer.insert_query_recon(
                trace_id=tid,
                original=orig,
                reconstructed=orig + random.choice(RECONSTRUCTED_SUFFIXES),
                similarity=random.uniform(0.75, 0.99),
            )

    # Tool calls (~50)

    target_counts = {"get_weather": 15, "search_docs": 12, "query_db": 10, "send_email": 8, "calc_price": 7}
    for tool, count in target_counts.items():
        for _ in range(count):
            valid = random.random() < 0.85
            args = random.choice(TOOL_ARGS[tool])
            result = random.choice(TOOL_RESULTS[tool]) if valid else None
            writer.insert_tool_call(
                trace_id=random.choice(trace_ids),
                tool_name=tool,
                args_json=json.dumps(args),
                valid=valid,
                error=None if valid else random.choice(TOOL_ERRORS),
                result_json=json.dumps(result) if result else None,
                duration_ms=random.randint(50, 3000) if valid else random.randint(5, 500),
            )

    # Feedback (~30)
    for _ in range(30):
        signal = random.choice(SIGNALS)
        tid = random.choice(trace_ids)
        writer.insert_feedback(
            response_id=tid,
            signal=signal,
            value=random.uniform(1, 5) if signal == "score" else (1.0 if signal == "thumbs_up" else 0.0),
            dimension=random.choice(DIMENSIONS),
            correction=random.choice(CORRECTIONS) if signal == "thumbs_down" and random.random() < 0.6 else None,
        )

    # Evolution variants
    for i, variant in enumerate(VARIANTS):
        writer.insert_evolution(
            variant_id=variant,
            phase=PHASES[i % len(PHASES)],
            win_rate=random.uniform(0.45, 0.72),
            samples=random.randint(20, 200),
            promoted=(i == 0),
        )

    # Log events (~40)
    EVENT_TEMPLATES = [
        ("info",     "server started",              {"version": "1.2.0", "env": "production"},     "startup"),
        ("info",     "request completed",           {"latency_ms": 312, "status": 200},            "api"),
        ("info",     "cache warmed",                {"entries": 84, "backend": "redis"},           "cache"),
        ("info",     "model fallback triggered",    {"from": "gpt-4o", "to": "gpt-4o-mini"},      "router"),
        ("info",     "user session started",        {"user_id": "u_1042", "plan": "pro"},          "auth"),
        ("info",     "prompt variant selected",     {"variant": "variant-beta", "score": 0.71},   "evolution"),
        ("warning",  "high latency detected",       {"latency_ms": 7800, "threshold_ms": 5000},   "api"),
        ("warning",  "token budget 80% used",       {"used": 3200, "limit": 4000},                "budget"),
        ("warning",  "cache miss rate elevated",    {"miss_rate": 0.62, "window": "1h"},          "cache"),
        ("warning",  "rate limit approaching",      {"requests": 950, "limit": 1000},             "api"),
        ("error",    "tool call failed",            {"tool": "query_db", "error": "timeout"},     "agent"),
        ("error",    "payment processing failed",   {"amount": 49.99, "reason": "card_declined"}, "billing"),
        ("error",    "model request rejected",      {"model": "gpt-4o", "code": 429},             "router"),
        ("error",    "database connection lost",    {"host": "db.internal", "retry": 3},          "store"),
        ("critical", "memory limit exceeded",       {"used_mb": 2048, "limit_mb": 2000},          "runtime"),
        ("critical", "unhandled exception in agent",{"traceback": "RuntimeError: ...", "fatal": True}, "agent"),
        ("debug",    "embedding computed",          {"dims": 1536, "model": "text-embedding-3"},  "cache"),
        ("debug",    "similarity score computed",   {"score": 0.847, "query_len": 42},            "cache"),
        ("debug",    "prompt rendered",             {"tokens": 512, "variant": "v2"},             "evolution"),
    ]
    for _ in range(40):
        tmpl = random.choice(EVENT_TEMPLATES)
        level, message, metadata, source = tmpl
        # jitter numeric metadata values slightly
        meta = {k: (round(v * random.uniform(0.8, 1.2), 2) if isinstance(v, (int, float)) else v)
                for k, v in metadata.items()}
        writer.insert_event(
            message=message,
            level=level,
            metadata=meta,
            source=source,
            trace_id=random.choice(trace_ids) if random.random() < 0.4 else None,
        )

    print(f"Seeded {n_traces} traces, 52 tool calls, 30 feedback records, 3 evolution variants, 40 events.")
    print(f"DB: {db_path}")


if __name__ == "__main__":
    seed(clear=True)
