from .client import CoreIQClient, log_event
from .exceptions import CoreIQError, ValidationError, DatabaseError, ConfigError
from .evolution.feedback import FeedbackSignal
from .status import StatusReport
from .testing import MockCoreIQ, assert_event_logged
from .security import PromptInjectionError, OutputViolationError
from .governance import PolicyViolation, ComplianceViolation
from .performance import BudgetExceeded
from .tools import ToolSpec, ValidationResult
from .evolution.sdk import VariantResult

try:
    from .tracing import trace  # noqa: F401
    _has_tracing = True
except ImportError:
    _has_tracing = False

__version__ = "0.2.1"

__all__ = [
    "__version__",
    "CoreIQClient",
    "log_event",
    "CoreIQError",
    "ValidationError",
    "DatabaseError",
    "ConfigError",
    "FeedbackSignal",
    "StatusReport",
    "MockCoreIQ",
    "assert_event_logged",
    "PromptInjectionError",
    "OutputViolationError",
    "PolicyViolation",
    "ComplianceViolation",
    "BudgetExceeded",
    "ToolSpec",
    "ValidationResult",
    "VariantResult",
]

if _has_tracing:
    __all__.append("trace")
