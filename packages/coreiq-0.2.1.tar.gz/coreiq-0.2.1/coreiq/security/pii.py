"""PII detection and redaction."""
import re
from dataclasses import dataclass
from typing import Optional

@dataclass
class PIIPattern:
    name: str
    pattern: str
    replacement: str = "[REDACTED]"


_DEFAULT_PATTERNS: list[PIIPattern] = [
    PIIPattern("email",       r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",  "[EMAIL]"),
    PIIPattern("phone_us",    r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b", "[PHONE]"),
    PIIPattern("ssn",         r"\b\d{3}-\d{2}-\d{4}\b",                               "[SSN]"),
    PIIPattern("credit_card", r"\b(?:\d{4}[-\s]?){3}\d{4}\b",                         "[CARD]"),
    PIIPattern("ip_address",  r"\b\d{1,3}(?:\.\d{1,3}){3}\b",                         "[IP]"),
]


def redact_pii(
    text: str,
    patterns: Optional[list[PIIPattern]] = None,
    *,
    placeholder: Optional[str] = None,
) -> str:
    """Redact PII from text. Returns redacted string."""
    active = patterns if patterns is not None else _DEFAULT_PATTERNS
    for p in active:
        repl = placeholder if placeholder is not None else p.replacement
        text = re.sub(p.pattern, repl, text, flags=re.IGNORECASE)
    return text


def detect_pii(text: str, patterns: Optional[list[PIIPattern]] = None) -> list[str]:
    """Return list of PII type names found in text."""
    active = patterns if patterns is not None else _DEFAULT_PATTERNS
    found = []
    for p in active:
        if re.search(p.pattern, text, flags=re.IGNORECASE):
            found.append(p.name)
    return found
