"""Full request/response scanner combining injection, PII, and output checks."""
from dataclasses import dataclass, field
from typing import Sequence

from .injection import scan_for_injection
from .pii import detect_pii, redact_pii
from .output_guard import check_output, GuardRule


@dataclass
class ScanResult:
    clean: bool
    injection_flags: list[dict] = field(default_factory=list)
    pii_found: list[str] = field(default_factory=list)
    output_violations: list[str] = field(default_factory=list)

    @property
    def issues(self) -> list[str]:
        issues = []
        if self.injection_flags:
            issues.append(f"injection:{len(self.injection_flags)}")
        if self.pii_found:
            issues.append(f"pii:{','.join(self.pii_found)}")
        if self.output_violations:
            issues.append(f"output:{','.join(self.output_violations)}")
        return issues


def scan_messages(
    messages: Sequence[dict],
    *,
    check_pii: bool = True,
    output_rules: list[GuardRule] | None = None,
) -> ScanResult:
    """Scan a conversation for injection, PII, and output violations."""
    injection_flags = scan_for_injection(messages)

    pii_found: list[str] = []
    if check_pii:
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                for p in detect_pii(content):
                    if p not in pii_found:
                        pii_found.append(p)

    output_violations: list[str] = []
    for msg in messages:
        if msg.get("role") == "assistant":
            content = msg.get("content", "")
            if isinstance(content, str):
                output_violations.extend(
                    check_output(content, output_rules, raise_on_violation=False)
                )

    clean = not injection_flags and not pii_found and not output_violations
    return ScanResult(
        clean=clean,
        injection_flags=injection_flags,
        pii_found=pii_found,
        output_violations=output_violations,
    )


def scan_and_redact(
    messages: Sequence[dict],
    *,
    check_pii: bool = True,
    output_rules: list[GuardRule] | None = None,
) -> tuple[ScanResult, list[dict]]:
    """Scan and return redacted messages in one call.

    Returns (ScanResult, redacted_messages) where PII in user/assistant
    content is replaced with placeholders like [EMAIL], [PHONE], [SSN].
    """
    result = scan_messages(messages, check_pii=check_pii, output_rules=output_rules)
    redacted = []
    for msg in messages:
        msg_copy = dict(msg)
        content = msg_copy.get("content", "")
        if isinstance(content, str) and check_pii:
            msg_copy["content"] = redact_pii(content)
        redacted.append(msg_copy)
    return result, redacted
