"""Prompt injection detection."""
import re
from typing import Sequence

# Patterns that commonly appear in prompt injection attacks
_INJECTION_PATTERNS = [
    r"ignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions?",
    r"disregard\s+(?:all\s+)?(?:previous|prior|above)\s+instructions?",
    r"forget\s+(?:everything|all)\s+(?:you\s+)?(?:were\s+)?told",
    r"you\s+are\s+now\s+(?:a\s+)?(?:DAN|jailbreak|unrestricted)",
    r"new\s+system\s+(?:prompt|instruction)",
    r"<\s*(?:system|SYSTEM)\s*>",
    r"\[(?:SYSTEM|INST|SYS)\]",
    r"act\s+as\s+if\s+you\s+have\s+no\s+restrictions",
]

_COMPILED = [re.compile(p, re.IGNORECASE) for p in _INJECTION_PATTERNS]


class PromptInjectionError(ValueError):
    def __init__(self, pattern: str, text: str):
        self.pattern = pattern
        self.text = text
        super().__init__(f"Potential prompt injection detected: '{pattern}'")


def check_prompt_injection(text: str, *, raise_on_detect: bool = True) -> bool:
    """Return True if injection detected; raise PromptInjectionError if raise_on_detect=True."""
    for compiled in _COMPILED:
        m = compiled.search(text)
        if m:
            if raise_on_detect:
                raise PromptInjectionError(m.group(), text)
            return True
    return False


def scan_for_injection(messages: Sequence[dict]) -> list[dict]:
    """Scan a list of chat messages; return list of flagged messages with matched pattern."""
    flagged = []
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            for compiled, pattern in zip(_COMPILED, _INJECTION_PATTERNS):
                if compiled.search(content):
                    flagged.append({"role": msg.get("role"), "pattern": pattern})
                    break
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    for compiled, pattern in zip(_COMPILED, _INJECTION_PATTERNS):
                        if compiled.search(block.get("text", "")):
                            flagged.append({"role": msg.get("role"), "pattern": pattern})
                            break
    return flagged
