from enum import Enum
from typing import Optional

from ..store.writer import get_writer


class FeedbackSignal(str, Enum):
    THUMBS_UP = "thumbs_up"
    THUMBS_DOWN = "thumbs_down"
    SCORE = "score"
    CORRECTION = "correction"


class FeedbackRecorder:
    def record(
        self,
        *,
        response_id: str,
        signal: str,
        value: float = 0.0,
        dimension: Optional[str] = None,
        correction: Optional[str] = None,
    ) -> None:
        get_writer().insert_feedback(
            response_id=response_id,
            signal=signal,
            value=value,
            dimension=dimension,
            correction=correction,
        )

    def thumbs_up(self, response_id: str, dimension: Optional[str] = None) -> None:
        self.record(response_id=response_id, signal="thumbs_up", value=1.0, dimension=dimension)

    def thumbs_down(self, response_id: str, dimension: Optional[str] = None, correction: Optional[str] = None) -> None:
        self.record(response_id=response_id, signal="thumbs_down", value=0.0, dimension=dimension, correction=correction)

    def score(self, response_id: str, value: float, dimension: Optional[str] = None) -> None:
        self.record(response_id=response_id, signal="score", value=value, dimension=dimension)


_recorder: Optional[FeedbackRecorder] = None


def get_feedback_recorder() -> FeedbackRecorder:
    global _recorder
    if _recorder is None:
        _recorder = FeedbackRecorder()
    return _recorder
