"""DICL — Dynamic In-Context Learning: select best few-shot examples at runtime."""
from dataclasses import dataclass, field


@dataclass
class Example:
    id: str
    input: str
    output: str
    metadata: dict = field(default_factory=dict)
    score: float = 1.0  # quality/relevance weight


class ExampleStore:
    """In-memory store of labeled examples with cosine-similarity retrieval."""

    def __init__(self):
        self._examples: list[Example] = []

    def add(self, example: Example) -> None:
        self._examples.append(example)

    def remove(self, example_id: str) -> bool:
        before = len(self._examples)
        self._examples = [e for e in self._examples if e.id != example_id]
        return len(self._examples) < before

    def retrieve(
        self,
        query: str,
        *,
        k: int = 3,
        min_score: float = 0.0,
    ) -> list[Example]:
        """
        Retrieve top-k examples by simple TF-IDF-inspired Jaccard similarity.
        In production, replace with embedding-based retrieval.
        """
        query_tokens = set(query.lower().split())
        scored: list[tuple[float, Example]] = []
        for ex in self._examples:
            if ex.score < min_score:
                continue
            ex_tokens = set(ex.input.lower().split())
            if not query_tokens and not ex_tokens:
                sim = 1.0
            elif not query_tokens or not ex_tokens:
                sim = 0.0
            else:
                intersection = query_tokens & ex_tokens
                union = query_tokens | ex_tokens
                sim = len(intersection) / len(union)
            scored.append((sim * ex.score, ex))

        scored.sort(key=lambda x: -x[0])
        return [ex for _, ex in scored[:k]]

    def to_messages(self, examples: list[Example]) -> list[dict]:
        """Convert examples to alternating user/assistant message pairs."""
        messages = []
        for ex in examples:
            messages.append({"role": "user", "content": ex.input})
            messages.append({"role": "assistant", "content": ex.output})
        return messages

    def __len__(self) -> int:
        return len(self._examples)
