"""SDK interface for Evolution — Thompson sampling variant selection."""
import threading
from dataclasses import dataclass
from typing import Optional

from .bandit import PromptBandit
from ..store.writer import get_writer
from ..store.db import get_shared_connection


@dataclass
class VariantResult:
    id: str
    prompt: str
    win_rate: float
    samples: int


class EvolutionSDK:
    """High-level evolution API on CoreIQClient.

    Usage::

        variant = client.evolution.select()
        response = llm.call(prompt=variant.prompt)
        client.evolution.record_outcome(variant.id, "thumbs_up")
    """

    def __init__(self):
        self._bandit: Optional[PromptBandit] = None
        self._prompts: dict[str, str] = {}
        self._lock = threading.RLock()

    def _get_bandit(self) -> PromptBandit:
        if self._bandit is None:
            with self._lock:
                if self._bandit is None:
                    self._bandit = _load_bandit_from_db()
        return self._bandit

    def select(self) -> Optional[VariantResult]:
        """Thompson sampling — select a variant for the next request."""
        with self._lock:
            bandit = self._get_bandit()
            if not bandit.has_arms():
                return None
            variant_id = bandit.select()
            arm = bandit.get_arm(variant_id)
            return VariantResult(
                id=variant_id,
                prompt=self._prompts.get(variant_id, ""),
                win_rate=arm.win_rate if arm else 0.0,
                samples=arm.samples if arm else 0,
            )

    def record_outcome(self, variant_id: str, signal) -> None:
        """Record a feedback outcome and update bandit weights."""
        if hasattr(signal, 'value'):
            signal = signal.value
        reward = 1.0 if signal in ("thumbs_up", "score") else 0.0
        with self._lock:
            bandit = self._get_bandit()
            bandit.reward(variant_id, reward)
            _persist_bandit_to_db(bandit)

    def best(self) -> Optional[VariantResult]:
        """Return the current best variant by win rate."""
        with self._lock:
            bandit = self._get_bandit()
            best_id = bandit.best()
            if not best_id:
                return None
            arm = bandit.get_arm(best_id)
            return VariantResult(
                id=best_id,
                prompt=self._prompts.get(best_id, ""),
                win_rate=arm.win_rate if arm else 0.0,
                samples=arm.samples if arm else 0,
            )

    def promote(self, variant_id: str) -> None:
        """Lock in a variant as the winner (writes to evolution table)."""
        with self._lock:
            bandit = self._get_bandit()
            arm = bandit.get_arm(variant_id)
            win_rate = arm.win_rate if arm else 0.0
            samples = arm.samples if arm else 0
            get_writer().insert_evolution(
                variant_id=variant_id,
                phase="promoted",
                win_rate=win_rate,
                samples=samples,
                promoted=True,
            )
            _persist_bandit_to_db(bandit)

    def add_variant(self, variant_id: str, prompt: str = "") -> None:
        """Register a new variant with the bandit."""
        with self._lock:
            self._prompts[variant_id] = prompt
            bandit = self._get_bandit()
            bandit.add_variant(variant_id)
            _persist_bandit_to_db(bandit)

    def get_prompt(self, variant_id: str) -> str:
        """Return the registered prompt for a variant."""
        return self._prompts.get(variant_id, "")

    def new_experiment(self) -> None:
        """Start a fresh experiment — clears all bandit state and prompts.

        Use this to isolate a new A/B test from previous experiments::

            client.evolution.new_experiment()
            client.evolution.add_variant("v1", prompt="...")
            client.evolution.add_variant("v2", prompt="...")
        """
        with self._lock:
            self._bandit = PromptBandit([])
            self._prompts.clear()

    def prune(self, max_age_days: int = 90) -> int:
        """Delete bandit_state rows older than max_age_days. Returns count deleted."""
        from datetime import datetime, timezone, timedelta
        cutoff = (datetime.now(timezone.utc) - timedelta(days=max_age_days)).isoformat()
        conn = get_shared_connection()
        cursor = conn.execute("DELETE FROM bandit_state WHERE updated_at < ?", (cutoff,))
        conn.commit()
        return cursor.rowcount


def _load_bandit_from_db() -> PromptBandit:
    """Load persisted bandit state from DB."""
    conn = get_shared_connection()

    # Try bandit_state table first
    try:
        rows = conn.execute(
            "SELECT variant_id, alpha, beta FROM bandit_state"
        ).fetchall()
    except Exception:
        rows = []

    bandit = PromptBandit([])
    for row in rows:
        bandit.restore_arm(row["variant_id"], float(row["alpha"]), float(row["beta"]))

    # Also seed any variants from evolution table not yet in bandit_state
    try:
        ev_rows = conn.execute("SELECT DISTINCT variant_id FROM evolution").fetchall()
        for r in ev_rows:
            vid = r["variant_id"]
            if bandit.get_arm(vid) is None:
                bandit.add_variant(vid)
    except Exception:
        pass

    return bandit


def _persist_bandit_to_db(bandit: PromptBandit) -> None:
    """Persist bandit alpha/beta weights to DB for restart survival."""
    arms = {vid: (arm.alpha, arm.beta) for vid, arm in bandit.items()}
    get_writer().persist_bandit_state(arms)
