"""Multi-armed bandit for prompt variant selection (Thompson sampling)."""
import random
from dataclasses import dataclass
from typing import Optional


@dataclass
class Arm:
    variant_id: str
    alpha: float = 1.0  # successes + 1 (Beta prior)
    beta: float = 1.0   # failures + 1 (Beta prior)

    @property
    def win_rate(self) -> float:
        return self.alpha / (self.alpha + self.beta)

    @property
    def samples(self) -> int:
        return int(self.alpha + self.beta - 2)

    def sample(self) -> float:
        """Draw from Beta(alpha, beta) — Thompson sampling."""
        return random.betavariate(self.alpha, self.beta)

    def update(self, reward: float) -> None:
        """Update with a reward in [0, 1]."""
        self.alpha += reward
        self.beta += (1.0 - reward)


class PromptBandit:
    """
    Thompson-sampling bandit for prompt variant A/B/n testing.
    Each variant_id maps to a Beta-distribution arm.
    """

    def __init__(self, variant_ids: list[str]):
        self._arms: dict[str, Arm] = {vid: Arm(variant_id=vid) for vid in variant_ids}

    def select(self) -> str:
        """Return the variant_id with the highest Thompson sample."""
        return max(self._arms.values(), key=lambda a: a.sample()).variant_id

    def reward(self, variant_id: str, value: float) -> None:
        """Record a reward (0.0–1.0) for a variant."""
        if variant_id not in self._arms:
            self._arms[variant_id] = Arm(variant_id=variant_id)
        self._arms[variant_id].update(max(0.0, min(1.0, value)))

    def add_variant(self, variant_id: str) -> None:
        if variant_id not in self._arms:
            self._arms[variant_id] = Arm(variant_id=variant_id)

    def stats(self) -> list[dict]:
        return [
            {
                "variant_id": arm.variant_id,
                "win_rate": round(arm.win_rate, 4),
                "samples": arm.samples,
                "alpha": arm.alpha,
                "beta": arm.beta,
            }
            for arm in sorted(self._arms.values(), key=lambda a: -a.win_rate)
        ]

    def has_arms(self) -> bool:
        return bool(self._arms)

    def get_arm(self, variant_id: str) -> Optional[Arm]:
        return self._arms.get(variant_id)

    def items(self):
        """Iterate (variant_id, Arm) pairs."""
        return self._arms.items()

    def restore_arm(self, variant_id: str, alpha: float, beta: float) -> None:
        """Restore a persisted arm state."""
        self._arms[variant_id] = Arm(variant_id=variant_id, alpha=alpha, beta=beta)

    def best(self) -> Optional[str]:
        """Return the variant with the highest current win_rate."""
        if not self._arms:
            return None
        return max(self._arms.values(), key=lambda a: a.win_rate).variant_id
