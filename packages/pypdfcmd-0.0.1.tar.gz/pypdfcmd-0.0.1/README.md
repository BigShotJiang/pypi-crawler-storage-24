# pypdfcmd

pypdfcmd 是一個 PDF 命令工具集，基於 pypdf 庫。

## 功能

- 移除 PDF 密碼保護
- 支援命令行操作
- 未來將加入更多 PDF 相關指令

## 安裝

```bash
pip install pypdfcmd
```

## 使用方法

### 作為 Python 函式庫使用

```python
from pypdfcmd import remove_password

remove_password("input.pdf", "your_password")
```

### 直接使用命令行

```bash
pdfunlock
```

會提示你輸入 PDF 檔案路徑和密碼。

## 輸出

輸出檔案固定為 `output.pdf`（與輸入檔案相同目錄）

## 依賴

- Python 3.6+
- pypdf

## 授權

MIT License
