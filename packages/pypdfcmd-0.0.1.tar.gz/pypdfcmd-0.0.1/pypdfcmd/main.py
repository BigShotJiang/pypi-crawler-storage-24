#!/usr/bin/env python3
"""PDF 密碼移除工具 / PDF Password Removal Tool"""

import os
import sys
from pathlib import Path

from pypdf import PdfReader, PdfWriter


def remove_password(input_file: str, password: str):
    """移除 PDF 密碼保護 / Remove PDF password protection"""
    try:
        reader = PdfReader(input_file, password=password)
        writer = PdfWriter()

        for page in reader.pages:
            writer.add_page(page)

        # 取得原始檔名，產生新檔名 / Get original filename, generate new filename
        path = Path(input_file)
        output_file = path.parent / f"{path.stem}_unlocked{path.suffix}"

        writer.write(output_file)
        return True, str(output_file)

    except Exception as e:
        return False, str(e)


def main():
    """命令行入口 / Command line entry"""
    password = input("請輸入密碼 / Enter password: ").strip()

    if not password:
        print("請輸入密碼 / Please enter password")
        return

    # 取得目前目錄所有 PDF 檔案 / Get all PDF files in current directory
    pdf_files = list(Path(".").glob("*.pdf"))

    if not pdf_files:
        print("目前目錄沒有 PDF 檔案 / No PDF files in current directory")
        return

    print(f"找到 {len(pdf_files)} 個 PDF 檔案 / Found {len(pdf_files)} PDF files\n")

    unlocked_count = 0
    skip_count = 0
    error_count = 0

    for pdf_file in pdf_files:
        print(f"處理 / Processing: {pdf_file.name} ... ", end="")

        try:
            # 先嘗試用密碼開啟，檢查是否真的有密碼保護
            # Try to open with password, check if it's actually encrypted
            reader = PdfReader(pdf_file, password=password)

            # 檢查是否真的需要密碼 / Check if password is actually required
            if reader.is_encrypted:
                success, result = remove_password(str(pdf_file), password)
                if success:
                    print(f"成功解鎖 / Unlocked -> {Path(result).name}")
                    unlocked_count += 1
                else:
                    print(f"錯誤 / Error: {result}")
                    error_count += 1
            else:
                print("跳過（無密碼保護）/ Skipped (no password)")
                skip_count += 1

        except Exception as e:
            print("密碼錯誤或無法處理 / Wrong password or cannot process")
            error_count += 1

    print(f"\n完成 / Done!")
    print(f"  解鎖成功 / Unlocked: {unlocked_count}")
    print(f"  跳過（無密碼）/ Skipped: {skip_count}")
    print(f"  失敗 / Failed: {error_count}")


if __name__ == "__main__":
    main()
