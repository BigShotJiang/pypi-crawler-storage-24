import setuptools

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setuptools.setup(
    name="pypdfcmd",
    version="0.0.1",
    author="Wing",
    author_email="tomt99688@gmail.com",
    description="PDF 命令工具集",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Wing9897/pypdfcmd",
    packages=setuptools.find_packages(),
    install_requires=["pypdf>=4.0.0"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "pdfunlock = pypdfcmd.main:main",
        ]
    },
)
