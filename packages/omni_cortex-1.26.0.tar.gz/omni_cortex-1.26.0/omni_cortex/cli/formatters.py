"""Output formatters for CLI — JSON vs human-readable."""

import json
from typing import Any

import click


def output_json(data: Any) -> None:
    """Print data as JSON to stdout."""
    click_echo(json.dumps(data, indent=2, default=str))


def click_echo(message: str) -> None:
    """Echo message, handling broken pipes gracefully."""
    try:
        click.echo(message)
    except (BrokenPipeError, OSError):
        pass


def memory_to_dict(memory: Any) -> dict:
    """Convert a Memory object to a serializable dict."""
    return {
        "id": memory.id,
        "content": memory.content,
        "type": memory.type,
        "tags": memory.tags or [],
        "context": memory.context,
        "created_at": memory.created_at,
        "updated_at": memory.updated_at,
        "last_accessed": memory.last_accessed,
        "access_count": memory.access_count,
        "importance_score": memory.importance_score,
        "manual_importance": memory.manual_importance,
        "status": memory.status,
        "source_session_id": memory.source_session_id,
        "project_path": memory.project_path,
    }


def format_memory_human(memory: Any, verbose: bool = False) -> str:
    """Format a single memory for human-readable output."""
    lines = [
        f"[{memory.type}] {memory.id}",
        f"  {memory.content[:200]}{'...' if len(memory.content) > 200 else ''}",
    ]
    if memory.tags:
        lines.append(f"  Tags: {', '.join(memory.tags)}")
    lines.append(f"  Importance: {memory.importance_score:.0f}/100 | Status: {memory.status}")
    if verbose:
        lines.append(f"  Created: {memory.created_at}")
        lines.append(f"  Accessed: {memory.access_count} times")
        if memory.context:
            lines.append(f"  Context: {memory.context[:150]}...")
    return "\n".join(lines)


def format_memories_human(memories: list, total: int | None = None) -> str:
    """Format a list of memories for human-readable output."""
    if not memories:
        return "No memories found."

    header = f"Memories ({len(memories)}"
    if total is not None and total > len(memories):
        header += f" of {total}"
    header += ")"

    lines = [header, ""]
    for mem in memories:
        lines.append(format_memory_human(mem))
        lines.append("")

    return "\n".join(lines)


def session_to_dict(session: Any) -> dict:
    """Convert a Session object to a serializable dict."""
    return {
        "id": session.id,
        "project_path": session.project_path,
        "started_at": session.started_at,
        "ended_at": session.ended_at,
        "summary": session.summary,
    }


def activity_to_dict(activity: Any) -> dict:
    """Convert an Activity object to a serializable dict."""
    return {
        "id": activity.id,
        "session_id": activity.session_id,
        "timestamp": activity.timestamp,
        "event_type": activity.event_type,
        "tool_name": activity.tool_name,
        "duration_ms": activity.duration_ms,
        "success": activity.success,
        "error_message": activity.error_message,
        "file_path": activity.file_path,
    }
