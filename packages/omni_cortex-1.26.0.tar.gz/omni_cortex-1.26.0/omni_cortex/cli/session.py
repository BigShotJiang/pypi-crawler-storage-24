"""Session commands: start, end, context."""

import click

from .formatters import click_echo, output_json, session_to_dict


def _get_conn():
    from ..database.connection import get_connection

    return get_connection()


def _is_json(ctx, json_output):
    ctx.ensure_object(dict)
    if json_output:
        ctx.obj["json"] = True
    return ctx.obj.get("json", False)


@click.group("session")
def session_commands():
    """Session management (start, end, context)."""
    pass


@session_commands.command("start")
@click.option("--id", "session_id", default=None, help="Custom session ID")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def start_cmd(ctx, session_id, json_output):
    """Start a new session."""
    from ..models.session import SessionCreate, create_session
    from ..config import get_project_path

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    project_path = str(get_project_path())

    data = SessionCreate(session_id=session_id, project_path=project_path)
    session = create_session(conn, data)

    if use_json:
        output_json(session_to_dict(session))
    else:
        click_echo(f"Session started: {session.id}")
        click_echo(f"Project: {session.project_path}")


@session_commands.command("end")
@click.argument("session_id")
@click.option("--summary", "-s", default=None, help="Session summary")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def end_cmd(ctx, session_id, summary, json_output):
    """End a session."""
    from ..models.session import end_session, get_session_summary

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    session = end_session(conn, session_id=session_id, summary=summary)

    if not session:
        click_echo(f"Session not found: {session_id}")
        raise SystemExit(1)

    sess_summary = get_session_summary(conn, session_id)

    if use_json:
        data = session_to_dict(session)
        if sess_summary:
            data["stats"] = {
                "total_activities": sess_summary.total_activities,
                "total_memories_created": sess_summary.total_memories_created,
                "tools_used": sess_summary.tools_used or {},
                "files_modified": sess_summary.files_modified or [],
            }
        output_json(data)
    else:
        click_echo(f"Session ended: {session.id}")
        if sess_summary:
            click_echo(f"  Activities: {sess_summary.total_activities}")
            click_echo(f"  Memories created: {sess_summary.total_memories_created}")


@session_commands.command("context")
@click.option("--count", "-n", default=5, help="Number of past sessions")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def context_cmd(ctx, count, json_output):
    """Get context from previous sessions."""
    from ..models.session import get_recent_sessions, get_session_summary
    from ..config import get_project_path

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    project_path = str(get_project_path())

    sessions = get_recent_sessions(conn, project_path=project_path, limit=count)

    if not sessions:
        click_echo("No previous sessions found.")
        return

    if use_json:
        result = []
        for sess in sessions:
            data = session_to_dict(sess)
            summary = get_session_summary(conn, sess.id)
            if summary:
                data["stats"] = {
                    "total_activities": summary.total_activities,
                    "total_memories_created": summary.total_memories_created,
                }
            result.append(data)
        output_json(result)
    else:
        click_echo(f"Recent sessions ({len(sessions)})")
        click_echo("")
        for sess in sessions:
            ended = sess.ended_at or "active"
            click_echo(f"  {sess.id}")
            click_echo(f"    Started: {sess.started_at}")
            click_echo(f"    Ended: {ended}")
            if sess.summary:
                click_echo(f"    Summary: {sess.summary[:100]}...")
            click_echo("")
