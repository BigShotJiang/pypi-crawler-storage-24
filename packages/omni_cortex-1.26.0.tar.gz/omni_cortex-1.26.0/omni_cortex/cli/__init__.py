"""Omni-Cortex CLI — memory backbone for Claude Code."""

import os

import click

from .memory import (
    recall_cmd,
    remember_cmd,
    get_cmd,
    list_cmd,
    update_cmd,
    forget_cmd,
    link_cmd,
)
from .session import session_commands
from .search import search_commands
from .bulk import batch_remember_cmd, export_cmd, prune_cmd, stats_cmd


@click.group()
@click.option("--project", default=None, help="Project path (default: cwd)")
@click.option("--json", "json_output", is_flag=True, help="JSON output for piping")
@click.version_option(package_name="omni-cortex")
@click.pass_context
def main(ctx: click.Context, project: str | None, json_output: bool) -> None:
    """Omni-Cortex CLI — memory backbone for Claude Code.

    Store, search, and manage memories across projects.
    All commands support --json for pipe-friendly output.
    """
    project_path = project or os.getcwd()

    # Set env var so all downstream config calls resolve correctly
    os.environ["CLAUDE_PROJECT_DIR"] = str(project_path)

    # Initialize database
    from ..database.connection import init_database

    init_database()

    ctx.ensure_object(dict)
    ctx.obj["json"] = json_output
    ctx.obj["project"] = project_path


# Register top-level memory commands
main.add_command(recall_cmd, "recall")
main.add_command(remember_cmd, "remember")
main.add_command(get_cmd, "get")
main.add_command(list_cmd, "list")
main.add_command(update_cmd, "update")
main.add_command(forget_cmd, "forget")
main.add_command(link_cmd, "link")

# Register top-level bulk commands
main.add_command(batch_remember_cmd, "batch-remember")
main.add_command(export_cmd, "export")
main.add_command(prune_cmd, "prune")
main.add_command(stats_cmd, "stats")

# Register command groups
main.add_command(session_commands)
main.add_command(search_commands)
