"""Memory commands: recall, remember, get, list, update, forget, link."""

import click

from .formatters import (
    click_echo,
    format_memories_human,
    format_memory_human,
    memory_to_dict,
    output_json,
)


def _get_conn():
    """Get the project database connection."""
    from ..database.connection import get_connection

    return get_connection()


def _is_json(ctx, json_output):
    """Check if JSON output requested from either subcommand or parent."""
    ctx.ensure_object(dict)
    if json_output:
        ctx.obj["json"] = True
    return ctx.obj.get("json", False)


@click.command("recall")
@click.argument("query")
@click.option("--limit", "-n", default=10, help="Max results")
@click.option("--tags", "-t", default=None, help="Filter by tags (comma-separated)")
@click.option("--type", "type_filter", default=None, help="Filter by memory type")
@click.option("--mode", default="keyword", type=click.Choice(["keyword", "semantic", "hybrid"]))
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def recall_cmd(ctx, query, limit, tags, type_filter, mode, json_output):
    """Search memories by query."""
    from ..search.hybrid import search

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    tags_list = [t.strip() for t in tags.split(",")] if tags else None

    results = search(
        conn, query=query, mode=mode, type_filter=type_filter,
        tags_filter=tags_list, limit=limit,
    )

    if use_json:
        output_json([
            {**memory_to_dict(mem), "keyword_score": kw, "semantic_score": sem}
            for mem, kw, sem in results
        ])
    else:
        if not results:
            click_echo("No memories found.")
            return
        lines = [f"Search results for '{query}' ({len(results)})", ""]
        for mem, kw, sem in results:
            lines.append(format_memory_human(mem))
            lines.append(f"  Score: keyword={kw:.2f} semantic={sem:.2f}")
            lines.append("")
        click_echo("\n".join(lines))


@click.command("remember")
@click.argument("content")
@click.option("--tags", "-t", default=None, help="Tags (comma-separated)")
@click.option("--type", "mem_type", default="general", help="Memory type")
@click.option("--importance", "-i", default=None, type=int, help="Importance 1-100")
@click.option("--context", "-c", default=None, help="Additional context")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def remember_cmd(ctx, content, tags, mem_type, importance, context, json_output):
    """Store a new memory."""
    from ..models.memory import MemoryCreate, create_memory
    from ..config import get_project_path, get_session_id
    from ..database.sync import sync_memory_to_global

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    tags_list = [t.strip() for t in tags.split(",")] if tags else []
    project_path = str(get_project_path())

    data = MemoryCreate(
        content=content, tags=tags_list, type=mem_type,
        importance=importance, context=context,
    )

    memory = create_memory(conn, data, project_path=project_path, session_id=get_session_id())

    sync_memory_to_global(
        memory_id=memory.id, content=memory.content, memory_type=memory.type,
        tags=memory.tags or [], context=memory.context,
        importance_score=memory.importance_score, status=memory.status,
        project_path=project_path, created_at=memory.created_at,
        updated_at=memory.updated_at,
    )

    if use_json:
        output_json(memory_to_dict(memory))
    else:
        click_echo(f"Created: {memory.id}")
        click_echo(f"  Type: {memory.type}")
        click_echo(f"  Tags: {', '.join(memory.tags or [])}")
        click_echo(f"  Importance: {memory.importance_score:.0f}/100")


@click.command("get")
@click.argument("memory_id")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def get_cmd(ctx, memory_id, json_output):
    """Retrieve a memory by ID."""
    from ..models.memory import get_memory

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    memory = get_memory(conn, memory_id)

    if not memory:
        click_echo(f"Memory not found: {memory_id}")
        raise SystemExit(1)

    if use_json:
        output_json(memory_to_dict(memory))
    else:
        click_echo(format_memory_human(memory, verbose=True))


@click.command("list")
@click.option("--limit", "-n", default=20, help="Max results")
@click.option("--offset", default=0, help="Pagination offset")
@click.option("--tags", "-t", default=None, help="Filter by tags (comma-separated)")
@click.option("--type", "type_filter", default=None, help="Filter by memory type")
@click.option("--status", "status_filter", default=None, help="Filter by status")
@click.option("--sort", "sort_by", default="last_accessed", type=click.Choice(["last_accessed", "created_at", "importance_score", "access_count"]))
@click.option("--order", "sort_order", default="desc", type=click.Choice(["asc", "desc"]))
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def list_cmd(ctx, limit, offset, tags, type_filter, status_filter, sort_by, sort_order, json_output):
    """List memories with filters."""
    from ..models.memory import list_memories

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    tags_list = [t.strip() for t in tags.split(",")] if tags else None

    memories, total = list_memories(
        conn, type_filter=type_filter, tags_filter=tags_list,
        status_filter=status_filter, sort_by=sort_by, sort_order=sort_order,
        limit=limit, offset=offset,
    )

    if use_json:
        output_json({
            "memories": [memory_to_dict(m) for m in memories],
            "total": total, "limit": limit, "offset": offset,
        })
    else:
        click_echo(format_memories_human(memories, total))


@click.command("update")
@click.argument("memory_id")
@click.option("--content", default=None, help="New content")
@click.option("--context", default=None, help="New context")
@click.option("--tags", default=None, help="Replace all tags (comma-separated)")
@click.option("--add-tags", default=None, help="Tags to add (comma-separated)")
@click.option("--remove-tags", default=None, help="Tags to remove (comma-separated)")
@click.option("--status", default=None, help="New status")
@click.option("--importance", default=None, type=int, help="New importance 1-100")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def update_cmd(ctx, memory_id, content, context, tags, add_tags, remove_tags, status, importance, json_output):
    """Update a memory."""
    from ..models.memory import MemoryUpdate, update_memory, get_memory, create_version
    from ..config import load_config
    import json as json_mod

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    config = load_config()

    if config.versioning_enabled:
        existing = get_memory(conn, memory_id)
        if existing and (content is not None or tags is not None):
            create_version(
                conn, memory_id, old_content=existing.content,
                old_context=existing.context,
                old_tags=json_mod.dumps(existing.tags) if existing.tags else None,
                old_importance=existing.importance_score,
                changed_by="cli", change_reason="CLI update",
            )

    data = MemoryUpdate(
        content=content, context=context,
        tags=[t.strip() for t in tags.split(",")] if tags else None,
        add_tags=[t.strip() for t in add_tags.split(",")] if add_tags else None,
        remove_tags=[t.strip() for t in remove_tags.split(",")] if remove_tags else None,
        status=status, importance=importance,
    )

    memory = update_memory(conn, memory_id, data)

    if not memory:
        click_echo(f"Memory not found: {memory_id}")
        raise SystemExit(1)

    if use_json:
        output_json(memory_to_dict(memory))
    else:
        click_echo(f"Updated: {memory.id}")


@click.command("forget")
@click.argument("memory_id")
@click.option("--force", is_flag=True, help="Skip confirmation")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def forget_cmd(ctx, memory_id, force, json_output):
    """Delete a memory."""
    from ..models.memory import get_memory, delete_memory
    from ..database.sync import delete_memory_from_global

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()

    if not force:
        memory = get_memory(conn, memory_id)
        if not memory:
            click_echo(f"Memory not found: {memory_id}")
            raise SystemExit(1)
        click_echo(format_memory_human(memory))
        if not click.confirm("Delete this memory?"):
            click_echo("Cancelled.")
            return

    deleted = delete_memory(conn, memory_id)
    if deleted:
        delete_memory_from_global(memory_id)
        if use_json:
            output_json({"deleted": memory_id})
        else:
            click_echo(f"Deleted: {memory_id}")
    else:
        click_echo(f"Memory not found: {memory_id}")
        raise SystemExit(1)


@click.command("link")
@click.argument("source_id")
@click.argument("target_id")
@click.option("--type", "rel_type", default="related_to", type=click.Choice(["related_to", "supersedes", "derived_from", "contradicts"]))
@click.option("--strength", default=1.0, type=float, help="Relationship strength 0.0-1.0")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def link_cmd(ctx, source_id, target_id, rel_type, strength, json_output):
    """Link two memories with a relationship."""
    from ..models.relationship import create_relationship

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    result = create_relationship(conn, source_id, target_id, rel_type, strength)

    if isinstance(result, dict) and "error" in result:
        click_echo(f"Error: memories not found: {result['missing_ids']}")
        raise SystemExit(1)
    elif result is None:
        click_echo("Relationship already exists.")
    else:
        if use_json:
            output_json({
                "id": result.id, "source": result.source_memory_id,
                "target": result.target_memory_id,
                "type": result.relationship_type, "strength": result.strength,
            })
        else:
            click_echo(f"Linked: {source_id} --[{rel_type}]--> {target_id}")
