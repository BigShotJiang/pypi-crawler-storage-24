"""Search commands: search (global), tags, timeline, activities."""

import json as json_mod

import click

from .formatters import (
    activity_to_dict,
    click_echo,
    memory_to_dict,
    output_json,
)


def _get_conn():
    from ..database.connection import get_connection

    return get_connection()


def _is_json(ctx, json_output):
    ctx.ensure_object(dict)
    if json_output:
        ctx.obj["json"] = True
    return ctx.obj.get("json", False)


@click.group("search")
def search_commands():
    """Search memories, tags, timeline, and activities."""
    pass


@search_commands.command("query")
@click.argument("query")
@click.option("--global", "global_search", is_flag=True, help="Search across all projects")
@click.option("--limit", "-n", default=20, help="Max results")
@click.option("--tags", "-t", default=None, help="Filter by tags (comma-separated)")
@click.option("--type", "type_filter", default=None, help="Filter by memory type")
@click.option("--project", "project_filter", default=None, help="Filter by project path (global only)")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def query_cmd(ctx, query, global_search, limit, tags, type_filter, project_filter, json_output):
    """Search memories by query (use --global for cross-project)."""
    use_json = _is_json(ctx, json_output)
    tags_list = [t.strip() for t in tags.split(",")] if tags else None

    if global_search:
        from ..database.sync import search_global_memories

        results = search_global_memories(
            query=query, type_filter=type_filter, tags_filter=tags_list,
            project_filter=project_filter, limit=limit,
        )

        if use_json:
            output_json(results)
        else:
            if not results:
                click_echo(f"No global results for: {query}")
                return
            click_echo(f"Global search results ({len(results)})")
            click_echo("")
            for mem in results:
                click_echo(f"  [{mem['type']}] {mem['id']}")
                click_echo(f"    {mem['content'][:200]}...")
                click_echo(f"    Project: {mem.get('project_path', 'unknown')}")
                if mem.get("tags"):
                    click_echo(f"    Tags: {', '.join(mem['tags'])}")
                click_echo(f"    Score: {mem.get('score', 0):.2f}")
                click_echo("")
    else:
        from ..search.hybrid import search as hybrid_search

        results = hybrid_search(
            conn=_get_conn(), query=query, type_filter=type_filter,
            tags_filter=tags_list, limit=limit,
        )

        if use_json:
            output_json([
                {**memory_to_dict(mem), "keyword_score": kw, "semantic_score": sem}
                for mem, kw, sem in results
            ])
        else:
            if not results:
                click_echo(f"No results for: {query}")
                return
            click_echo(f"Search results ({len(results)})")
            click_echo("")
            for mem, kw, sem in results:
                click_echo(f"  [{mem.type}] {mem.id}")
                click_echo(f"    {mem.content[:200]}...")
                if mem.tags:
                    click_echo(f"    Tags: {', '.join(mem.tags)}")
                click_echo(f"    Score: kw={kw:.2f} sem={sem:.2f}")
                click_echo("")


@search_commands.command("tags")
@click.option("--min-count", default=1, type=int, help="Minimum usage count")
@click.option("--limit", "-n", default=50, help="Max tags to return")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def tags_cmd(ctx, min_count, limit, json_output):
    """List all tags with usage counts."""
    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT tags FROM memories
        WHERE tags IS NOT NULL AND tags != '[]'
    """)

    tag_counts: dict[str, int] = {}
    for row in cursor.fetchall():
        tags_val = row["tags"]
        if tags_val:
            if isinstance(tags_val, str):
                tags_val = json_mod.loads(tags_val)
            for tag in tags_val:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1

    filtered = [
        (tag, count) for tag, count in tag_counts.items() if count >= min_count
    ]
    filtered.sort(key=lambda x: x[1], reverse=True)
    filtered = filtered[:limit]

    if use_json:
        output_json({tag: count for tag, count in filtered})
    else:
        if not filtered:
            click_echo("No tags found.")
            return
        click_echo(f"Tags ({len(filtered)})")
        click_echo("")
        for tag, count in filtered:
            click_echo(f"  {tag}: {count}")


@search_commands.command("timeline")
@click.option("--days", "-d", default=7, type=int, help="Number of days to show")
@click.option("--limit", "-n", default=50, help="Max items")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def timeline_cmd(ctx, days, limit, json_output):
    """Show activity timeline."""
    from datetime import datetime, timedelta, timezone

    from ..models.activity import get_activities
    from ..models.memory import list_memories

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    memories, _ = list_memories(conn, sort_by="created_at", sort_order="desc", limit=limit)
    activities, _ = get_activities(conn, since=since, limit=limit)

    timeline = []
    for mem in memories:
        timeline.append({
            "timestamp": mem.created_at, "type": "memory",
            "subtype": mem.type, "id": mem.id, "content": mem.content[:150],
        })
    for act in activities:
        timeline.append({
            "timestamp": act.timestamp, "type": "activity",
            "subtype": act.event_type, "id": act.id,
            "content": act.tool_name or act.event_type,
        })

    timeline.sort(key=lambda x: x["timestamp"], reverse=True)
    timeline = timeline[:limit]

    if use_json:
        output_json(timeline)
    else:
        if not timeline:
            click_echo("No recent activity.")
            return
        click_echo(f"Timeline (last {days} days, {len(timeline)} items)")
        click_echo("")
        for item in timeline:
            icon = "M" if item["type"] == "memory" else "A"
            click_echo(f"  [{icon}] {item['timestamp'][:19]}")
            click_echo(f"      {item['subtype']}: {item['content']}")
            click_echo("")


@search_commands.command("activities")
@click.option("--since", default=None, help="Since date (ISO 8601)")
@click.option("--tool", "tool_name", default=None, help="Filter by tool name")
@click.option("--event", "event_type", default=None, help="Filter by event type")
@click.option("--limit", "-n", default=50, help="Max results")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def activities_cmd(ctx, since, tool_name, event_type, limit, json_output):
    """Query activity log."""
    from ..models.activity import get_activities

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    activities, total = get_activities(
        conn, event_type=event_type, tool_name=tool_name,
        since=since, limit=limit,
    )

    if use_json:
        output_json({
            "activities": [activity_to_dict(a) for a in activities],
            "total": total,
        })
    else:
        if not activities:
            click_echo("No activities found.")
            return
        click_echo(f"Activities ({len(activities)} of {total})")
        click_echo("")
        for act in activities:
            status = "OK" if act.success else "FAIL"
            click_echo(f"  [{status}] {act.timestamp[:19]} {act.event_type}")
            if act.tool_name:
                click_echo(f"      Tool: {act.tool_name}")
            if act.error_message:
                click_echo(f"      Error: {act.error_message[:100]}")
            click_echo("")
