"""Bulk operations: batch-remember, export, prune, stats."""

import json as json_mod
import sys
from datetime import datetime, timedelta, timezone

import click

from .formatters import click_echo, memory_to_dict, output_json


def _get_conn():
    from ..database.connection import get_connection

    return get_connection()


def _is_json(ctx, json_output):
    ctx.ensure_object(dict)
    if json_output:
        ctx.obj["json"] = True
    return ctx.obj.get("json", False)


@click.command("batch-remember")
@click.option("--file", "input_file", default=None, type=click.Path(exists=True), help="JSON/JSONL file (default: stdin)")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def batch_remember_cmd(ctx, input_file, json_output):
    """Batch create memories from JSON/JSONL input.

    Input format (one per line for JSONL, or array for JSON):
    {"content": "...", "tags": ["a","b"], "type": "general", "importance": 50}
    """
    from ..models.memory import MemoryCreate, create_memory
    from ..config import get_project_path, get_session_id
    from ..database.sync import sync_memory_to_global

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    project_path = str(get_project_path())
    session_id = get_session_id()

    if input_file:
        with open(input_file, "r", encoding="utf-8") as f:
            raw = f.read().strip()
    else:
        if sys.stdin.isatty():
            click_echo("Provide JSON/JSONL via stdin or --file")
            raise SystemExit(1)
        raw = sys.stdin.read().strip()

    items = []
    if raw.startswith("["):
        items = json_mod.loads(raw)
    else:
        for line in raw.splitlines():
            line = line.strip()
            if line:
                items.append(json_mod.loads(line))

    created = []
    errors = []

    for i, item in enumerate(items):
        try:
            tags = item.get("tags", [])
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",")]

            data = MemoryCreate(
                content=item["content"], tags=tags,
                type=item.get("type", "general"),
                importance=item.get("importance"),
                context=item.get("context"),
            )

            memory = create_memory(conn, data, project_path=project_path, session_id=session_id)

            sync_memory_to_global(
                memory_id=memory.id, content=memory.content, memory_type=memory.type,
                tags=memory.tags or [], context=memory.context,
                importance_score=memory.importance_score, status=memory.status,
                project_path=project_path, created_at=memory.created_at,
                updated_at=memory.updated_at,
            )

            created.append(memory.id)
        except Exception as e:
            errors.append({"index": i, "error": str(e)})

    if use_json:
        output_json({
            "created": len(created), "errors": len(errors),
            "ids": created, "error_details": errors,
        })
    else:
        click_echo(f"Created: {len(created)} | Errors: {len(errors)}")
        if errors:
            for err in errors[:5]:
                click_echo(f"  Error at index {err['index']}: {err['error']}")

    if errors:
        _log_batch_errors(errors, "batch-remember")


@click.command("export")
@click.option("--tags", "-t", default=None, help="Filter by tags (comma-separated)")
@click.option("--type", "type_filter", default=None, help="Filter by memory type")
@click.option("--status", "status_filter", default=None, help="Filter by status")
@click.option("--format", "fmt", default="json", type=click.Choice(["json", "jsonl", "csv"]))
@click.option("--output", "-o", default=None, type=click.Path(), help="Output file (default: stdout)")
@click.option("--limit", "-n", default=1000, help="Max memories to export")
@click.pass_context
def export_cmd(ctx, tags, type_filter, status_filter, fmt, output, limit):
    """Export memories to JSON, JSONL, or CSV."""
    from ..models.memory import list_memories

    conn = _get_conn()
    tags_list = [t.strip() for t in tags.split(",")] if tags else None

    memories, total = list_memories(
        conn, type_filter=type_filter, tags_filter=tags_list,
        status_filter=status_filter, limit=limit,
    )

    dicts = [memory_to_dict(m) for m in memories]

    if fmt == "json":
        content = json_mod.dumps(dicts, indent=2, default=str)
    elif fmt == "jsonl":
        content = "\n".join(json_mod.dumps(d, default=str) for d in dicts)
    elif fmt == "csv":
        import csv
        import io

        buf = io.StringIO()
        if dicts:
            writer = csv.DictWriter(buf, fieldnames=dicts[0].keys())
            writer.writeheader()
            for d in dicts:
                row = {**d, "tags": ",".join(d.get("tags", []))}
                writer.writerow(row)
        content = buf.getvalue()

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(content)
        click_echo(f"Exported {len(dicts)} memories to {output}")
    else:
        click_echo(content)


@click.command("prune")
@click.option("--older-than", "older_than", default=None, help="Prune memories older than (e.g., 30d, 90d)")
@click.option("--status", "status_filter", default=None, help="Prune by status (e.g., archived, outdated)")
@click.option("--min-importance", default=None, type=int, help="Prune below this importance score")
@click.option("--dry-run", is_flag=True, help="Show what would be deleted without deleting")
@click.option("--force", is_flag=True, help="Skip confirmation")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def prune_cmd(ctx, older_than, status_filter, min_importance, dry_run, force, json_output):
    """Prune memories matching filters."""
    from ..models.memory import delete_memory
    from ..database.sync import delete_memory_from_global

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    cursor = conn.cursor()

    where_clauses = []
    params: list = []

    if older_than:
        days = int(older_than.rstrip("d"))
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        where_clauses.append("created_at < ?")
        params.append(cutoff)

    if status_filter:
        where_clauses.append("status = ?")
        params.append(status_filter)

    if min_importance is not None:
        where_clauses.append("importance_score < ?")
        params.append(float(min_importance))

    if not where_clauses:
        click_echo("Specify at least one filter: --older-than, --status, or --min-importance")
        raise SystemExit(1)

    where_sql = " AND ".join(where_clauses)
    cursor.execute(f"SELECT id, content, type, importance_score, created_at FROM memories WHERE {where_sql}", params)
    candidates = cursor.fetchall()

    if not candidates:
        click_echo("No memories match the filter criteria.")
        return

    if dry_run:
        if use_json:
            output_json({
                "dry_run": True, "would_delete": len(candidates),
                "ids": [row["id"] for row in candidates],
            })
        else:
            click_echo(f"Would delete {len(candidates)} memories (dry run):")
            for row in candidates[:20]:
                click_echo(f"  {row['id']} [{row['type']}] imp={row['importance_score']:.0f} {row['content'][:80]}...")
            if len(candidates) > 20:
                click_echo(f"  ... and {len(candidates) - 20} more")
        return

    if not force:
        click_echo(f"About to delete {len(candidates)} memories.")
        if not click.confirm("Continue?"):
            click_echo("Cancelled.")
            return

    deleted = 0
    for row in candidates:
        if delete_memory(conn, row["id"]):
            delete_memory_from_global(row["id"])
            deleted += 1

    if use_json:
        output_json({"deleted": deleted})
    else:
        click_echo(f"Deleted: {deleted} memories")


@click.command("stats")
@click.option("--json", "json_output", is_flag=True, default=False, help="JSON output")
@click.pass_context
def stats_cmd(ctx, json_output):
    """Show memory statistics."""
    from ..config import get_project_db_path

    use_json = _is_json(ctx, json_output)
    conn = _get_conn()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) as cnt FROM memories")
    total = cursor.fetchone()["cnt"]

    cursor.execute("SELECT type, COUNT(*) as cnt FROM memories GROUP BY type ORDER BY cnt DESC")
    by_type = {row["type"]: row["cnt"] for row in cursor.fetchall()}

    cursor.execute("SELECT status, COUNT(*) as cnt FROM memories GROUP BY status ORDER BY cnt DESC")
    by_status = {row["status"]: row["cnt"] for row in cursor.fetchall()}

    cursor.execute("SELECT tags FROM memories WHERE tags IS NOT NULL AND tags != '[]'")
    tag_counts: dict[str, int] = {}
    for row in cursor.fetchall():
        tags_val = row["tags"]
        if tags_val and isinstance(tags_val, str):
            for tag in json_mod.loads(tags_val):
                tag_counts[tag] = tag_counts.get(tag, 0) + 1
    top_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]

    cursor.execute("SELECT COUNT(*) as cnt FROM sessions")
    total_sessions = cursor.fetchone()["cnt"]

    cursor.execute("SELECT COUNT(*) as cnt FROM activities")
    total_activities = cursor.fetchone()["cnt"]

    db_path = get_project_db_path()
    db_size = db_path.stat().st_size if db_path.exists() else 0
    db_size_mb = db_size / (1024 * 1024)

    cursor.execute("SELECT MAX(timestamp) as latest FROM activities")
    row = cursor.fetchone()
    last_activity = row["latest"] if row else None

    if use_json:
        output_json({
            "total_memories": total, "total_sessions": total_sessions,
            "total_activities": total_activities,
            "by_type": by_type, "by_status": by_status,
            "top_tags": dict(top_tags),
            "db_size_bytes": db_size, "db_size_mb": round(db_size_mb, 2),
            "last_activity": last_activity,
        })
    else:
        click_echo("Omni-Cortex Statistics")
        click_echo("")
        click_echo(f"  Memories:   {total}")
        click_echo(f"  Sessions:   {total_sessions}")
        click_echo(f"  Activities: {total_activities}")
        click_echo(f"  DB Size:    {db_size_mb:.2f} MB")
        if last_activity:
            click_echo(f"  Last Activity: {last_activity[:19]}")
        click_echo("")
        click_echo("  By Type:")
        for t, c in by_type.items():
            click_echo(f"    {t}: {c}")
        click_echo("")
        click_echo("  By Status:")
        for s, c in by_status.items():
            click_echo(f"    {s}: {c}")
        click_echo("")
        if top_tags:
            click_echo("  Top Tags:")
            for tag, count in top_tags:
                click_echo(f"    {tag}: {count}")


def _log_batch_errors(errors, operation):
    """Log batch errors to .omni-cortex/script_errors.jsonl."""
    from ..config import get_project_db_dir
    from ..utils.timestamps import now_iso

    error_file = get_project_db_dir() / "script_errors.jsonl"
    try:
        with open(error_file, "a", encoding="utf-8") as f:
            for err in errors:
                entry = {
                    "script": "cortex-cli", "operation": operation,
                    "index": err.get("index"), "error": err.get("error"),
                    "timestamp": now_iso(),
                }
                f.write(json_mod.dumps(entry) + "\n")
    except OSError:
        pass
