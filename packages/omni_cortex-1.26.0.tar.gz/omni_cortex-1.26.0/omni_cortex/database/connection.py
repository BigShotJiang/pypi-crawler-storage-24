"""SQLite connection management for Omni Cortex."""

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

from ..config import get_global_db_dir, get_global_db_path, get_project_db_dir, get_project_db_path
from .schema import SCHEMA_VERSION, get_schema_sql

# Thread-local storage for connections
_local = threading.local()

# Connection cache by path
_connections: dict[str, sqlite3.Connection] = {}
_lock = threading.Lock()

# Retry settings for database-locked errors
_RETRY_ATTEMPTS = 5
_RETRY_BACKOFF_MS = [200, 500, 1000, 2000, 4000]


def _configure_connection(conn: sqlite3.Connection) -> None:
    """Configure a SQLite connection with optimal settings.

    Key concurrency settings for multi-terminal environments:
    - WAL mode: allows concurrent readers + one writer (vs default journal which blocks all)
    - busy_timeout 30s: wait up to 30s for locks instead of failing immediately
    - auto_vacuum INCREMENTAL: reclaim space without exclusive VACUUM lock
    - wal_autocheckpoint 100: checkpoint WAL every 100 pages (default 1000 can grow large)
    """
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")  # 30s timeout for concurrent access
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA cache_size = -64000")  # 64MB cache
    conn.execute("PRAGMA wal_autocheckpoint = 100")  # Checkpoint more frequently (default 1000)


def get_connection(db_path: Path | None = None, is_global: bool = False) -> sqlite3.Connection:
    """Get a database connection, creating it if necessary.

    Args:
        db_path: Explicit path to database file
        is_global: If True and no db_path, use global database

    Returns:
        SQLite connection
    """
    if db_path is None:
        db_path = get_global_db_path() if is_global else get_project_db_path()

    path_str = str(db_path)

    with _lock:
        if path_str not in _connections:
            # Ensure directory exists
            db_path.parent.mkdir(parents=True, exist_ok=True)

            # Create connection
            conn = sqlite3.connect(path_str, check_same_thread=False)
            _configure_connection(conn)
            _connections[path_str] = conn

        return _connections[path_str]


def init_database(db_path: Path | None = None, is_global: bool = False) -> sqlite3.Connection:
    """Initialize the database with schema.

    Args:
        db_path: Explicit path to database file
        is_global: If True and no db_path, use global database

    Returns:
        SQLite connection
    """
    if db_path is None:
        if is_global:
            db_path = get_global_db_path()
            db_dir = get_global_db_dir()
        else:
            db_path = get_project_db_path()
            db_dir = get_project_db_dir()
    else:
        db_dir = db_path.parent

    # Ensure directory exists
    db_dir.mkdir(parents=True, exist_ok=True)

    conn = get_connection(db_path)

    # Check if schema needs initialization
    cursor = conn.cursor()

    # Check if tables exist
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='memories'")
    if cursor.fetchone() is None:
        # Apply schema
        conn.executescript(get_schema_sql())

        # Record schema version
        from ..utils.timestamps import now_iso

        cursor.execute(
            "INSERT OR REPLACE INTO schema_migrations (version, applied_at) VALUES (?, ?)",
            (SCHEMA_VERSION, now_iso()),
        )
        conn.commit()

    # Apply any pending migrations (handles existing DBs missing newer tables)
    # Lazy import to avoid circular dependency (migrations imports get_connection)
    from .migrations import migrate as _run_migrations, needs_migration
    if needs_migration(conn):
        _run_migrations(db_path, is_global)

    return conn


def close_connection(db_path: Path | None = None, is_global: bool = False) -> None:
    """Close a database connection.

    Args:
        db_path: Explicit path to database file
        is_global: If True and no db_path, use global database
    """
    if db_path is None:
        db_path = get_global_db_path() if is_global else get_project_db_path()

    path_str = str(db_path)

    with _lock:
        if path_str in _connections:
            _connections[path_str].close()
            del _connections[path_str]


def close_all_connections() -> None:
    """Close all database connections."""
    with _lock:
        for conn in _connections.values():
            conn.close()
        _connections.clear()


@contextmanager
def transaction(conn: sqlite3.Connection):
    """Context manager for database transactions with retry on lock."""
    import time as _time

    for attempt in range(_RETRY_ATTEMPTS):
        try:
            yield conn
            conn.commit()
            return
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and attempt < _RETRY_ATTEMPTS - 1:
                conn.rollback()
                _time.sleep(_RETRY_BACKOFF_MS[attempt] / 1000)
                continue
            conn.rollback()
            raise
        except Exception:
            conn.rollback()
            raise
    # Should not reach here, but safety fallback
    return  # pragma: no cover


def execute_with_retry(
    conn: sqlite3.Connection,
    sql: str,
    params: tuple = (),
    commit: bool = True,
) -> sqlite3.Cursor:
    """Execute SQL with retry-on-lock backoff.

    Use this for write operations that may encounter concurrent access.
    Read operations typically don't need this (WAL allows concurrent reads).

    Args:
        conn: Database connection
        sql: SQL statement to execute
        params: Query parameters
        commit: Whether to commit after execution

    Returns:
        Cursor with results
    """
    import time as _time

    cursor = conn.cursor()
    for attempt in range(_RETRY_ATTEMPTS):
        try:
            cursor.execute(sql, params)
            if commit:
                conn.commit()
            return cursor
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and attempt < _RETRY_ATTEMPTS - 1:
                _time.sleep(_RETRY_BACKOFF_MS[attempt] / 1000)
                continue
            raise
    return cursor  # pragma: no cover
