"""Extreme SQLite concurrency stress test — finds the breaking point.

Escalates pressure in rounds:
  Round 1: 10 threads, 100 writes each (baseline)
  Round 2: 25 threads, 100 writes each (busy project day)
  Round 3: 50 threads, 100 writes each (absurd)
  Round 4: 100 threads, 50 writes each (nuclear)
  Round 5: 50 threads mixed read/write + WAL checkpoint spam

Each round reports errors, throughput, and latency.
"""
import sqlite3, threading, time, os, statistics

db = os.path.join(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd()), ".omni-cortex", "cortex.db")
print(f"Target: {db}")
print("=" * 60)

def run_round(name, num_threads, ops_per_thread, mixed=False):
    errors = []
    latencies = []
    lock_waits = [0]  # mutable counter

    def worker(tid):
        c = sqlite3.connect(db)
        c.execute("PRAGMA journal_mode = WAL")
        c.execute("PRAGMA busy_timeout = 30000")
        for i in range(ops_per_thread):
            t0 = time.perf_counter()
            for att in range(5):
                try:
                    if mixed and i % 3 == 0:
                        # Read operation
                        c.execute("SELECT COUNT(*) FROM activities").fetchone()
                    elif mixed and i % 7 == 0:
                        # WAL checkpoint (simulates prune)
                        c.execute("PRAGMA wal_checkpoint(PASSIVE)")
                    else:
                        # Write operation
                        c.execute(
                            "INSERT INTO activities (id, timestamp, event_type, tool_name) VALUES (?, ?, ?, ?)",
                            (f"extreme_{tid}_{i}_{int(time.time()*1000000)}", "2026-03-09T00:00:00", "stress_test", "ExtremeTest"))
                        c.commit()
                    break
                except sqlite3.OperationalError as e:
                    if "locked" in str(e) and att < 4:
                        lock_waits[0] += 1
                        time.sleep(0.05 * (att + 1))
                        continue
                    errors.append(f"t{tid}: {e}")
            latencies.append(time.perf_counter() - t0)
        c.close()

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(num_threads)]
    t_start = time.perf_counter()
    for t in threads: t.start()
    for t in threads: t.join(timeout=120)
    elapsed = time.perf_counter() - t_start

    total_ops = num_threads * ops_per_thread
    p50 = statistics.median(latencies) * 1000 if latencies else 0
    p99 = sorted(latencies)[int(len(latencies) * 0.99)] * 1000 if latencies else 0
    p_max = max(latencies) * 1000 if latencies else 0

    status = "PASS" if len(errors) == 0 else f"FAIL ({len(errors)} errors)"
    print(f"\n{'=' * 60}")
    print(f"  {name}")
    print(f"  {num_threads} threads x {ops_per_thread} ops = {total_ops} total")
    print(f"  Status:     {status}")
    print(f"  Time:       {elapsed:.2f}s ({total_ops/elapsed:.0f} ops/sec)")
    print(f"  Latency:    p50={p50:.1f}ms  p99={p99:.1f}ms  max={p_max:.1f}ms")
    print(f"  Lock waits: {lock_waits[0]} retries")
    if errors:
        print(f"  First 3 errors: {errors[:3]}")
    print(f"{'=' * 60}")
    return len(errors)

# Run escalating rounds
total_errors = 0
total_errors += run_round("Round 1: Baseline (10 threads)", 10, 100)
total_errors += run_round("Round 2: Busy day (25 threads)", 25, 100)
total_errors += run_round("Round 3: Absurd (50 threads)", 50, 100)
total_errors += run_round("Round 4: Nuclear (100 threads)", 100, 50)
total_errors += run_round("Round 5: Mixed R/W + checkpoints (50 threads)", 50, 100, mixed=True)

# Cleanup
c = sqlite3.connect(db)
c.execute("DELETE FROM activities WHERE tool_name = 'ExtremeTest'")
c.commit()
cleaned = c.total_changes
c.close()

print(f"\n{'#' * 60}")
print(f"  TOTAL ERRORS ACROSS ALL ROUNDS: {total_errors}")
print(f"  Cleaned up {cleaned} test rows")
if total_errors == 0:
    print("  VERDICT: Database handles extreme concurrency perfectly")
else:
    print(f"  VERDICT: Breaking point found — {total_errors} failures")
print(f"{'#' * 60}")
