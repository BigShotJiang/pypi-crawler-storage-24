"""Stress test for SQLite concurrency — simulates 10 terminal sessions hammering cortex.db."""
import sqlite3, threading, time, os

db = os.path.join(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd()), ".omni-cortex", "cortex.db")
print(f"Targeting: {db}")
errors = []

def hammer(tid):
    c = sqlite3.connect(db)
    c.execute("PRAGMA journal_mode = WAL")
    c.execute("PRAGMA busy_timeout = 30000")
    for i in range(50):
        for att in range(5):
            try:
                c.execute("INSERT INTO activities (id, timestamp, event_type, tool_name) VALUES (?, ?, ?, ?)",
                    (f"stress_{tid}_{i}_{int(time.time()*1000)}", "2026-03-09T00:00:00", "stress_test", "StressTest"))
                c.commit(); break
            except sqlite3.OperationalError as e:
                if "locked" in str(e) and att < 4:
                    time.sleep(0.1 * (att + 1)); continue
                errors.append(f"t{tid}: {e}")
    c.close()

threads = [threading.Thread(target=hammer, args=(i,)) for i in range(10)]
print("Starting 10 concurrent writers (50 inserts each)...")
for t in threads: t.start()
for t in threads: t.join(timeout=60)
print(f"Done. Errors: {len(errors)}")
if errors: print("First 5:", errors[:5])

# Cleanup
c = sqlite3.connect(db)
c.execute("DELETE FROM activities WHERE tool_name = 'StressTest'")
c.commit()
print(f"Cleaned up {c.total_changes} stress test rows")
c.close()
