# make_circle_redge

## API Definition

```python
def make_circle_redge(center: Tuple[float, float, float], radius: float, normal: Tuple[float, float, float] = (0, 0, 1)) -> Edge
```

*Source: operations.py*

## Description

Create a circular edge.
