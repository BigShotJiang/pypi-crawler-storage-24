# translate_shape

## API Definition

```python
def translate_shape(shape: AnyShape, vector: Tuple[float, float, float]) -> AnyShape
```

*Source: operations.py*

## Description

Translate a shape by an offset vector.
