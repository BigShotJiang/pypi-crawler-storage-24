# make_circle_rwire

## API Definition

```python
def make_circle_rwire(center: Tuple[float, float, float], radius: float, normal: Tuple[float, float, float] = (0, 0, 1)) -> Wire
```

*Source: operations.py*

## Description

Create a circular wire.
