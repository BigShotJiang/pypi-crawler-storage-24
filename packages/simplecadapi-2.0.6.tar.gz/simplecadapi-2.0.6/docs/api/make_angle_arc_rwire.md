# make_angle_arc_rwire

## API Definition

```python
def make_angle_arc_rwire(center: Tuple[float, float, float], radius: float, start_angle: float, end_angle: float, normal: Tuple[float, float, float] = (0, 0, 1)) -> Wire
```

*Source: operations.py*

## Description

Create a wire containing an arc defined by a center, radius, and angle range.
