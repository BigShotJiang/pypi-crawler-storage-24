# RIPER - ASE Calculator for TURBOMOLE's RIPER Module

An ASE (Atomic Simulation Environment) calculator interface for TURBOMOLE's
RIPER module, enabling DFT calculations for molecular and periodic systems
(1D, 2D, 3D periodicity).

## Installation

```bash
pip install riper
```