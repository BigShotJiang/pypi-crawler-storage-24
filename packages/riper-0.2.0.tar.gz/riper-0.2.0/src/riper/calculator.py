"""
ASE Calculator for TURBOMOLE's RIPER module.

This module provides the main RIPERCalculator class that interfaces
ASE with TURBOMOLE's RIPER module for DFT calculations on molecular
and periodic systems.
"""

import os
import subprocess
import shutil
import numpy as np
import warnings

from ase.calculators.calculator import Calculator, all_changes

from riper.io import write_coord, write_control, read_energy, read_forces, read_stress
from riper.utils import get_periodicity


class RIPERConvergenceError(Exception):
    """Exception raised when RIPER calculation does not converge."""
    pass


class RIPERConvergenceWarning(UserWarning):
    """Warning issued when RIPER calculation does not converge."""
    pass


def check_convergence(output_file):
    """
    Check if RIPER calculation converged.

    Parameters
    ----------
    output_file : str
        Path to the RIPER output file.

    Returns
    -------
    tuple
        (converged: bool, message: str or None)
        converged is True if calculation converged, False otherwise.
        message contains the convergence error message if not converged.
    """
    convergence_failure_patterns = [
        "did not converge",
        "NOT CONVERGED",
        "SCF NOT CONVERGED",
        "CONVERGENCE NOT REACHED",
        "convergence not achieved",
        "exceeded maximum number of iterations",
        "SCF FAILED",
    ]
    
    convergence_success_patterns = [
        "convergence criteria satisfied",
        "SCF CONVERGED",
        "total energy converged",
    ]
    
    try:
        with open(output_file, "r") as f:
            content = f.read()
            content_lower = content.lower()
    except FileNotFoundError:
        return False, f"Output file '{output_file}' not found"
    
    # Check for failure patterns
    for pattern in convergence_failure_patterns:
        if pattern.lower() in content_lower:
            # Extract the line containing the error for more context
            for line in content.split('\n'):
                if pattern.lower() in line.lower():
                    return False, line.strip()
            return False, f"Calculation {pattern}"
    
    return True, None


class RIPERCalculator(Calculator):
    """
    ASE Calculator for TURBOMOLE's RIPER module.

    Supports molecular (0D) and periodic (1D, 2D, 3D) DFT calculations.
    The periodicity is automatically determined from the atoms object's pbc property.

    Parameters
    ----------
    basis : str or None
        Orbital basis set. If None, defaults to "def2-SVP" for non-periodic
        and "pob-DZVP-rev2" for periodic systems.
    auxbasis : str
        Auxiliary basis set for density fitting. Default: "universal".
    functional : str
        Exchange-correlation functional. Default: "pbe".
    nkpoints : list of int
        k-point grid for periodic directions. Default: [2, 2, 2].
        Only the first N values are used where N = number of periodic directions.
    charge : int
        Total system charge. Default: 0.
    uks : bool
        Use unrestricted Kohn-Sham (open-shell). Default: False.
    smear : bool
        Use Gaussian smearing for metals. Default: False.
    sigma : float
        Smearing width in Hartree (only used if smear=True). Default: 0.01.
    riper_command : str
        Command to invoke riper. Default: "riper".
        Can be "riper", "riper_smp", "riper_omp", or a full path.
    directory : str
        Working directory for the calculation. Default: "." (current directory).
    extra_keywords : dict
        Additional keywords to add to the $riper section.
        Example: {"lmaxmom": "30", "lpcg": "on"}
    convergence_check : str
        How to handle convergence failures. Options:
        - "error": Raise RIPERConvergenceError (default)
        - "warning": Issue a warning but continue
        - "ignore": Do not check convergence

    Examples
    --------
    >>> from ase.build import bulk
    >>> from riper import RIPERCalculator
    >>>
    >>> si = bulk('Si', 'diamond', a=5.43)
    >>> calc = RIPERCalculator(functional="pbe", nkpoints=[4, 4, 4])
    >>> si.calc = calc
    >>> energy = si.get_potential_energy()
    """

    implemented_properties = ["energy", "forces", "stress"]

    # Default parameters
    default_parameters = {
        "basis": None,        # Will be set based on periodicity
        "auxbasis": "universal",
        "functional": "pbe",
        "nkpoints": [2, 2, 2],
        "charge": 0,
        "uks": False,
        "smear": False,
        "sigma": 0.01,
        "riper_command": "riper",
        "extra_keywords": {},
        "convergence_check": "error",
    }

    def __init__(
        self,
        basis=None,
        auxbasis="universal",
        functional="pbe",
        nkpoints=None,
        charge=0,
        uks=False,
        smear=False,
        sigma=0.01,
        riper_command="riper",
        directory=".",
        extra_keywords=None,
        convergence_check="error",
        **kwargs,
    ):
        super().__init__(directory=directory, **kwargs)

        self.parameters["basis"] = basis
        self.parameters["auxbasis"] = auxbasis
        self.parameters["functional"] = functional
        self.parameters["nkpoints"] = nkpoints if nkpoints is not None else [2, 2, 2]
        self.parameters["charge"] = charge
        self.parameters["uks"] = uks
        self.parameters["smear"] = smear
        self.parameters["sigma"] = sigma
        self.parameters["riper_command"] = riper_command
        self.parameters["extra_keywords"] = extra_keywords if extra_keywords is not None else {}
        self.parameters["convergence_check"] = convergence_check

        if convergence_check not in ("error", "warning", "ignore"):
            raise ValueError(
                f"convergence_check must be 'error', 'warning', or 'ignore', "
                f"got '{convergence_check}'"
            )

        self._iteration = 0
        self.converged = None  # Track convergence status of last calculation

    def calculate(self, atoms=None, properties=None, system_changes=all_changes):
        """
        Perform a RIPER calculation.

        Parameters
        ----------
        atoms : ase.Atoms
            The atoms object to calculate.
        properties : list of str
            Properties to calculate. Can include "energy", "forces", "stress".
        system_changes : list of str
            List of changes since last calculation.
        """
        if properties is None:
            properties = self.implemented_properties

        super().calculate(atoms, properties, system_changes)

        self._iteration += 1
        self.converged = None  # Reset convergence status

        # Determine periodicity from atoms object
        npdir = get_periodicity(self.atoms)

        # Set default basis based on periodicity if not explicitly provided
        basis = self.parameters["basis"]
        if basis is None:
            basis = "def2-SVP" if npdir == 0 else "pob-DZVP-rev2"

        # Determine if stress calculation is needed
        calculate_stress = "stress" in properties and npdir > 0

        # Build parameter dict for control file generation
        params = {
            "basis": basis,
            "auxbasis": self.parameters["auxbasis"],
            "functional": self.parameters["functional"],
            "nkpoints": self.parameters["nkpoints"],
            "periodicity": npdir,
            "charge": self.parameters["charge"],
            "uks": self.parameters["uks"],
            "smear": self.parameters["smear"],
            "sigma": self.parameters["sigma"],
            "calculate_stress": calculate_stress,
            "extra_keywords": self.parameters["extra_keywords"],
        }

        # Write input files
        workdir = self.directory
        os.makedirs(workdir, exist_ok=True)

        coord_path = os.path.join(workdir, "coord")
        write_coord(self.atoms, filepath=coord_path)
        write_control(self.atoms, params, directory=workdir)

        # Run RIPER
        riper_cmd = self.parameters["riper_command"]
        output_file = os.path.join(workdir, "riper.out")

        try:
            with open(output_file, "w") as fout:
                result = subprocess.run(
                    riper_cmd,
                    shell=True,
                    cwd=workdir,
                    stdout=fout,
                    stderr=subprocess.STDOUT,
                )
        except Exception as e:
            raise RuntimeError(f"Failed to run RIPER command '{riper_cmd}': {e}")

        if result.returncode != 0:
            raise RuntimeError(
                f"RIPER calculation failed with exit code {result.returncode}. "
                f"Check '{output_file}' for details."
            )

        # Check convergence
        convergence_mode = self.parameters["convergence_check"]
        if convergence_mode != "ignore":
            converged, conv_message = check_convergence(output_file)
            self.converged = converged
            
            if not converged:
                error_msg = (
                    f"RIPER calculation did not converge. "
                    f"Details: {conv_message}. "
                    f"Check '{output_file}' for more information."
                )
                
                if convergence_mode == "error":
                    raise RIPERConvergenceError(error_msg)
                elif convergence_mode == "warning":
                    warnings.warn(error_msg, RIPERConvergenceWarning)
        else:
            self.converged = True  # Assume converged if not checking

        # Read energy
        energy = read_energy(output_file)
        self.results["energy"] = energy

        # Read forces (riper calculates forces by default)
        gradient_file = os.path.join(workdir, "gradient")
        if os.path.exists(gradient_file):
            forces = read_forces(gradient_file, len(self.atoms))
            self.results["forces"] = forces
        elif "forces" in properties:
            raise RuntimeError(
                "Forces requested but gradient file not found. "
                "Make sure 'lenonly' is not set in extra_keywords."
            )

        # Read stress (only for periodic systems with $optcell)
        if calculate_stress:
            # Need to read from control file which riper updates with $gradlatt
            orig_dir = os.getcwd()
            try:
                os.chdir(workdir)
                stress = read_stress(output_file, self.atoms)
                self.results["stress"] = stress
            finally:
                os.chdir(orig_dir)

    def clean(self, keep_output=False):
        """
        Remove temporary files from the working directory.

        Parameters
        ----------
        keep_output : bool
            If True, keep the riper.out file.
        """
        workdir = self.directory
        files_to_remove = ["gradient", "energy", "statistics", "ddens",
                           "errvec", "oldfock", "mos", "alpha", "beta",
                           "RIPER.BANDS", "RIPER.BANDS.OCCUPATIONS"]

        if not keep_output:
            files_to_remove.append("riper.out")

        for fname in files_to_remove:
            fpath = os.path.join(workdir, fname)
            if os.path.exists(fpath):
                os.remove(fpath)