"""
Utility functions for unit conversions and helper operations.
"""

import numpy as np

# ============================================================================
# Unit conversion constants
# ============================================================================

# Length
ANGSTROM_TO_BOHR = 1.8897259886
BOHR_TO_ANGSTROM = 1.0 / ANGSTROM_TO_BOHR

# Energy
HARTREE_TO_EV = 27.211386245988

# Force: Hartree/Bohr -> eV/Angstrom
HARTREE_PER_BOHR_TO_EV_PER_ANGSTROM = HARTREE_TO_EV / BOHR_TO_ANGSTROM  # ~51.422


def get_periodicity(atoms):
    """
    Determine the number of periodic directions from the atoms object.

    RIPER convention:
        - pbc along x -> 1D
        - pbc along x, y -> 2D
        - pbc along x, y, z -> 3D

    Parameters
    ----------
    atoms : ase.Atoms
        The atoms object.

    Returns
    -------
    int
        Number of periodic directions (0, 1, 2, or 3).
    """
    pbc = atoms.pbc
    return int(np.sum(pbc))


def cell_to_lattice_vectors(atoms, npdir):
    """
    Extract lattice vectors from the ASE atoms object for a given periodicity.

    For RIPER:
        - 3D: three 3D vectors (9 components)
        - 2D: two 2D vectors in the xy-plane (4 components)
        - 1D: one scalar value (length along x-axis)

    Parameters
    ----------
    atoms : ase.Atoms
        The atoms object with cell defined.
    npdir : int
        Number of periodic directions.

    Returns
    -------
    list of list of float
        Lattice vectors in Bohr. For 1D: [[ax]], for 2D: [[ax,ay],[bx,by]],
        for 3D: [[ax,ay,az],[bx,by,bz],[cx,cy,cz]].
    """
    cell = atoms.cell[:] * ANGSTROM_TO_BOHR  # Convert to Bohr

    if npdir == 3:
        return [cell[0].tolist(), cell[1].tolist(), cell[2].tolist()]
    elif npdir == 2:
        # 2D: only xy components of vectors a and b
        return [cell[0][:2].tolist(), cell[1][:2].tolist()]
    elif npdir == 1:
        # 1D: length of vector a (along x)
        return [[cell[0][0]]]
    else:
        return []