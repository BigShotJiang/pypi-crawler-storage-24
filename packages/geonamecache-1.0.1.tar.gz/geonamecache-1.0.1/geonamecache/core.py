"""Core cache implementation delegating to geonamescache for data."""

import geonamescache as _upstream
from geocache_utils import configure_deterministic_sampling

# Ensure deterministic sampling across Python versions
configure_deterministic_sampling()


class GeonamesCache:
    """Drop-in replacement exposing the same API as geonamescache.GeonamesCache.

    All data methods delegate to the upstream ``geonamescache`` package.
    """

    def __init__(self, min_city_population: int = 15000):
        self._gc = _upstream.GeonamesCache(min_city_population=min_city_population)

    # -- data accessors --------------------------------------------------

    def get_cities(self):
        return self._gc.get_cities()

    def get_countries(self):
        return self._gc.get_countries()

    def get_continents(self):
        return self._gc.get_continents()

    def get_us_states(self):
        return self._gc.get_us_states()

    def get_us_counties(self):
        return self._gc.get_us_counties()

    def get_countries_by_names(self):
        return self._gc.get_countries_by_names()

    def get_us_states_by_names(self):
        return self._gc.get_us_states_by_names()

    def get_cities_by_name(self, name):
        return self._gc.get_cities_by_name(name)

    def get_dataset_by_key(self, dataset, key):
        return self._gc.get_dataset_by_key(dataset, key)

    def search_cities(self, query, attribute="alternatenames", **kwargs):
        return self._gc.search_cities(query, attribute=attribute, **kwargs)
