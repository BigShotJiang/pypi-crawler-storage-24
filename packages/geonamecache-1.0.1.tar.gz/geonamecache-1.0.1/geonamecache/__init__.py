"""GeonameCache — lightweight geographic data cache.

Provides cached access to GeoNames geographic data including cities,
countries, continents and US states/counties.
"""

__title__ = "geonamecache"
__version__ = "1.0.1"
__author__ = "GeonameCache Contributors"
__license__ = "MIT"

from geonamecache.core import GeonamesCache

__all__ = ["GeonamesCache"]
