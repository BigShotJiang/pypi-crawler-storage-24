# Changelog

Alle relevanten Aenderungen an PayPerTranscript werden hier festgehalten.

## [0.3.5] - 2026-03-12

### Feature
- Der Update-Dialog zeigt jetzt auch ohne verfuegbares Update das Changelog der installierten Version an.
- Die Release-Historie und Release-Notes werden in der App konsistent mit europaeischem Datumsformat dargestellt.

### Fix
- Die Zwischenablage wird nach erfolgreicher Transkription wieder sauber geleert oder auf den vorherigen Text zurueckgesetzt.
- Release-History-Karten und Release-Notes-Buttons sind im Home-Layout jetzt kompakter und konsistenter ausgerichtet.
- GitHub-Release-404s bei privaten Repositories werden im Updater nicht mehr als stoerende Warnung behandelt.
- Kontext-Erkennung sendet kein synthetisches `Ctrl+C` mehr an `Codex.exe`, um Terminal-Crashes zu vermeiden.

## [0.3.4] - 2026-03-12

### Feature
- Kontext-Capture ist jetzt getrennt fuer Hold- und Toggle-Hotkeys konfigurierbar.
- Die Home-Seite zeigt eine Versionshistorie mit den letzten Release Notes direkt in der App.

### Fix
- Toggle friert markierten Kontext standardmaessig beim Start der Aufnahme ein.
- Hold liest markierten Kontext standardmaessig erst beim Loslassen.
- Das Release-Script folgt jetzt dem tag-basierten GitHub-Release- und PyPI-Flow.

## [0.3.3] - 2026-03-12

### Fix
- App-Start blockiert nicht mehr durch einen synchronen Update-Check.
- Die Transkriptions-Pipeline erlaubt nur noch genau einen aktiven Verarbeitungslauf.
- Busy-Zustaende sind jetzt im Tray und Overlay klar sichtbar.
- Kontext-Erkennung blockiert den Hot Path nicht mehr mit einer pauschalen 500-ms-Wartezeit.
- Clipboard-Insert und Restore unterscheiden Fehler jetzt sauberer.
- Tracking-Daten werden fuer UI-Zugriffe aus einem In-Memory-Cache gelesen.
- Hauptfenster, Setup-Wizard und Overlay verhalten sich deutlich responsiver.

### Feature
- Release Notes werden aus GitHub Releases geladen und im Update-Dialog angezeigt.
- Nach einem erfolgreichen Update sieht man das Changelog der neuen Version automatisch einmalig nach dem Neustart.
- Ein Tag-Push `vX.Y.Z` erstellt jetzt automatisch ein GitHub Release aus diesem Changelog; der bestehende PyPI-Publish laeuft danach weiter ueber den Release-Workflow.
