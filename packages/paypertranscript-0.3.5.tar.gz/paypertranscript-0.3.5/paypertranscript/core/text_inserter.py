"""Clipboard-basierte Texteinfuegung fuer PayPerTranscript.

Sichert die Zwischenablage, kopiert den Text, simuliert Ctrl+V,
und stellt die alte Zwischenablage wieder her.
"""

import time
from collections.abc import Iterator

import pyautogui

from paypertranscript.core.clipboard_manager import (
    ClipboardTextSnapshot,
    restore_clipboard_text,
    set_clipboard_text,
    snapshot_clipboard_text,
)
from paypertranscript.core.logging import get_logger

log = get_logger("core.text_inserter")

# pyautogui: Kein FAILSAFE (App laeuft im Hintergrund),
# keine Pause zwischen Aktionen (Latenz minimieren)
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0


# Clipboard-Wiederherstellung: Retry-Konfiguration
_CLIPBOARD_RESTORE_RETRIES = 3
_CLIPBOARD_RESTORE_DELAY = 0.05  # 50ms zwischen Versuchen
_PASTE_SETTLE_DELAY = 0.05


class ClipboardWriteError(RuntimeError):
    """Clipboard konnte nicht mit neuem Text beschrieben werden."""


class PasteDispatchError(RuntimeError):
    """Paste-Hotkey konnte nicht an die Ziel-App gesendet werden."""


def _restore_clipboard(snapshot: ClipboardTextSnapshot) -> None:
    """Stellt Text-Clipboard wieder her mit Retry-Logik."""
    if not snapshot.captured:
        return

    for attempt in range(1, _CLIPBOARD_RESTORE_RETRIES + 1):
        if restore_clipboard_text(snapshot):
            return

        if attempt < _CLIPBOARD_RESTORE_RETRIES:
            time.sleep(_CLIPBOARD_RESTORE_DELAY)
        else:
            log.warning(
                "Zwischenablage konnte nicht wiederhergestellt werden (nach %d Versuchen)",
                _CLIPBOARD_RESTORE_RETRIES,
            )


def _set_clipboard_or_raise(text: str) -> None:
    if not set_clipboard_text(text):
        raise ClipboardWriteError("Clipboard konnte nicht beschrieben werden")


def _dispatch_paste_or_raise() -> None:
    try:
        pyautogui.hotkey("ctrl", "v")
    except Exception as e:
        raise PasteDispatchError("Paste-Hotkey konnte nicht gesendet werden") from e
    time.sleep(_PASTE_SETTLE_DELAY)


def insert_text(text: str) -> None:
    """Fuegt Text an der aktuellen Cursor-Position ein.

    Ablauf:
    1. Aktuelle Zwischenablage sichern
    2. Text in Zwischenablage kopieren
    3. Ctrl+V simulieren
    4. 50ms warten (Ziel-App verarbeitet Paste)
    5. Alte Zwischenablage wiederherstellen

    Args:
        text: Der einzufuegende Text.
    """
    if not text:
        log.warning("insert_text aufgerufen mit leerem Text - uebersprungen")
        return

    # 1. Aktuelle Zwischenablage sichern
    old_clipboard = snapshot_clipboard_text()

    try:
        # 2. Text in Zwischenablage kopieren
        _set_clipboard_or_raise(text)

        # 3. Ctrl+V simulieren
        _dispatch_paste_or_raise()

        log.info("Text eingefuegt (%d Zeichen)", len(text))

    except ClipboardWriteError as e:
        log.error("Text-Einfuegung fehlgeschlagen (clipboard write): %s", e)
        raise
    except PasteDispatchError as e:
        log.error("Text-Einfuegung fehlgeschlagen (paste dispatch): %s", e)
        raise
    except Exception as e:
        log.error("Text-Einfuegung fehlgeschlagen (unerwartet): %s", e)
        raise

    finally:
        # 5. Alte Zwischenablage wiederherstellen
        _restore_clipboard(old_clipboard)


# Intervall (Sekunden) zwischen Chunk-Pastes bei Streaming-Typing
_STREAM_INTERVAL = 0.15


def insert_text_streaming(chunks: Iterator[str]) -> str:
    """Fuegt Text chunk-weise an der Cursor-Position ein (Live-Typing).

    Chunks werden gesammelt und in ~150ms-Intervallen per Clipboard+Paste
    eingefuegt. Bei Fehler wird der gesamte gesammelte Text als Fallback
    komplett eingefuegt.

    Args:
        chunks: Iterator der Text-Chunks (z.B. von LLM-Streaming).

    Returns:
        Der insgesamt eingefuegte Text.
    """
    old_clipboard = snapshot_clipboard_text()

    buffer = ""
    total_inserted = 0
    full_text_parts: list[str] = []
    attempted_buffer_paste = False

    try:
        last_paste = time.monotonic()
        for chunk in chunks:
            full_text_parts.append(chunk)
            buffer += chunk
            now = time.monotonic()
            if now - last_paste >= _STREAM_INTERVAL and buffer:
                attempted_buffer_paste = True
                _set_clipboard_or_raise(buffer)
                _dispatch_paste_or_raise()
                total_inserted += len(buffer)
                buffer = ""
                attempted_buffer_paste = False
                last_paste = now

        # Restlichen Buffer einfuegen
        if buffer:
            attempted_buffer_paste = True
            _set_clipboard_or_raise(buffer)
            _dispatch_paste_or_raise()
            total_inserted += len(buffer)
            attempted_buffer_paste = False

        log.info("Streaming-Text eingefuegt (%d Zeichen)", total_inserted)

    except ClipboardWriteError as e:
        log.error("Streaming-Einfuegung fehlgeschlagen (clipboard write): %s", e)
        if buffer and not attempted_buffer_paste:
            try:
                _set_clipboard_or_raise(buffer)
                _dispatch_paste_or_raise()
                total_inserted += len(buffer)
                buffer = ""
            except Exception as fallback_error:
                log.error("Streaming-Fallback fehlgeschlagen: %s", fallback_error)
    except PasteDispatchError as e:
        log.error("Streaming-Einfuegung fehlgeschlagen (paste dispatch): %s", e)
    except Exception as e:
        log.error("Streaming-Einfuegung fehlgeschlagen (unerwartet): %s", e)
        if buffer and not attempted_buffer_paste:
            try:
                _set_clipboard_or_raise(buffer)
                _dispatch_paste_or_raise()
                total_inserted += len(buffer)
                buffer = ""
            except Exception as fallback_error:
                log.error("Streaming-Fallback fehlgeschlagen: %s", fallback_error)

    finally:
        _restore_clipboard(old_clipboard)

    return "".join(full_text_parts)
