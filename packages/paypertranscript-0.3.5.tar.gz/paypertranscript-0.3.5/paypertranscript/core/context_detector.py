"""Kontext-Erkennung fuer PayPerTranscript.

Prueft ob im aktiven Fenster Text markiert ist (via Clipboard-Sentinel + Ctrl+C).
Der erkannte Text wird dem LLM als Kontext mitgegeben, z.B. fuer Antworten auf E-Mails.

Die Erkennung laeuft parallel zum STT-API-Call und fuegt 0ms zusaetzliche Latenz hinzu.
"""

from __future__ import annotations

import ctypes
import threading
import time
from concurrent.futures import Future

import pyautogui

from paypertranscript.core.clipboard_manager import (
    ClipboardSnapshot,
    get_clipboard_sequence_number,
    get_clipboard_text,
    restore_clipboard,
    set_clipboard_text,
    snapshot_clipboard,
)
from paypertranscript.core.config import ConfigManager
from paypertranscript.core.logging import get_logger
from paypertranscript.core.window_detector import WindowInfo

log = get_logger("core.context_detector")

# Sentinel: Null-Bytes koennen nicht in normalem Clipboard-Text vorkommen
_SENTINEL = "\x00__PPT_SENTINEL__\x00"

# Timeout nach Ctrl+C bis Clipboard-Aenderung erwartet wird (ms)
_CLIPBOARD_WAIT_TIMEOUT_MS = 90

# Polling-Intervall fuer Clipboard-Updates (ms)
_CLIPBOARD_POLL_MS = 5

# Timeout fuer Modifier-Release-Wait (ms)
_MODIFIER_RELEASE_TIMEOUT_MS = 180

# Polling-Intervall fuer Modifier-Release-Wait (ms)
_MODIFIER_POLL_MS = 5

# Virtual-Key-Codes fuer Modifier-Keys (Win32)
_VK_MODIFIERS = (
    0x10,  # VK_SHIFT
    0x11,  # VK_CONTROL
    0x12,  # VK_MENU (Alt)
    0x5B,  # VK_LWIN
    0x5C,  # VK_RWIN
)

# Terminal-Prozesse in denen Ctrl+C nicht gesendet werden darf (SIGINT-Gefahr)
_DEFAULT_TERMINAL_BLOCKLIST = frozenset({
    "cmd.exe", "powershell.exe", "pwsh.exe",
    "windowsterminal.exe", "mintty.exe", "bash.exe",
    "wsl.exe", "conhost.exe", "alacritty.exe",
    "wezterm-gui.exe", "hyper.exe", "codex.exe",
})


def detect_selected_text(
    window: WindowInfo | None,
    config: ConfigManager,
    cancel_event: threading.Event | None = None,
) -> str:
    """Prueft ob im aktiven Fenster Text markiert ist und gibt ihn zurueck.

    Ablauf:
    1. Feature-Flag und Terminal-Blocklist pruefen
    2. Clipboard sichern -> Sentinel setzen -> Ctrl+C -> Clipboard lesen -> wiederherstellen
    3. Wenn Clipboard != Sentinel: markierter Text gefunden

    Gibt in ALLEN Fehler-/Abbruch-Faellen "" zurueck - wirft nie Exceptions.
    Die Pipeline wird dadurch nie blockiert oder gestoert.

    Args:
        window: Info ueber das aktive Fenster (fuer Blocklist-Check).
        config: ConfigManager-Instanz.
        cancel_event: Optionales Event zum Abbrechen der Erkennung.

    Returns:
        Markierter Text oder "" wenn nichts markiert / Fehler / deaktiviert.
    """
    t_start = time.perf_counter()

    try:
        # 1. Feature-Flag pruefen
        if not config.get("context.detect_selection", True):
            log.debug("Context detection disabled by config")
            return ""

        # 2. Abbruch pruefen
        if cancel_event and cancel_event.is_set():
            log.debug("Context detection cancelled before start")
            return ""

        # 3. Terminal-Blocklist pruefen
        if window and window.process_name:
            process_lower = window.process_name.lower()
            blocklist = config.get("context.terminal_blocklist", [])
            blocklist_lower = {p.lower() for p in blocklist}
            # Auch Default-Blocklist pruefen
            blocklist_lower.update(p.lower() for p in _DEFAULT_TERMINAL_BLOCKLIST)

            if process_lower in blocklist_lower:
                log.debug(
                    "Context detection skipped: terminal process '%s'",
                    window.process_name,
                )
                return ""

            log.debug(
                "Context detection started for window '%s'",
                window.process_name,
            )
        else:
            log.debug("Context detection started (no window info)")

        # 4. Clipboard sichern
        original_clipboard = snapshot_clipboard()
        log.debug("Clipboard snapshot captured (%d formats)", len(original_clipboard.formats))

        # 5. Sentinel auf Clipboard setzen
        if not set_clipboard_text(_SENTINEL):
            log.warning("Context detection: clipboard write failed")
            return ""
        log.debug("Sentinel placed on clipboard")
        sentinel_sequence = get_clipboard_sequence_number()

        # 6. Abbruch pruefen
        if cancel_event and cancel_event.is_set():
            _restore_clipboard(original_clipboard)
            log.debug("Context detection cancelled before Ctrl+C")
            return ""

        # 7. Warten bis Modifier-Keys losgelassen sind (noetig fuer Toggle-Hotkey:
        #    User haelt noch Ctrl+Alt -> Ctrl+C wuerde als Ctrl+Alt+C ankommen)
        _wait_for_modifiers_released()

        # 8. Ctrl+C senden
        pyautogui.hotkey("ctrl", "c")
        t_ctrlc = time.perf_counter()
        log.debug("Ctrl+C sent (%.1fms after start)", (t_ctrlc - t_start) * 1000)

        # 9. Kurz pollen bis Clipboard aktualisiert wurde
        _wait_for_clipboard_update(sentinel_sequence)

        # 10. Clipboard lesen
        clipboard_content = get_clipboard_text()

        t_read = time.perf_counter()
        log.debug(
            "Clipboard read after Ctrl+C (%.1fms after start)",
            (t_read - t_start) * 1000,
        )

        # 11. Auswerten: Hat Ctrl+C den Sentinel ueberschrieben?
        if clipboard_content == _SENTINEL:
            # Sentinel unveraendert -> nichts war markiert
            _restore_clipboard(original_clipboard)
            t_end = time.perf_counter()
            log.debug("No text selected (%.1fms total)", (t_end - t_start) * 1000)
            return ""

        # Text war markiert!
        selected_text = clipboard_content.strip()

        # 12. Original-Clipboard wiederherstellen
        _restore_clipboard(original_clipboard)

        t_end = time.perf_counter()
        if selected_text:
            log.info(
                "Selected text detected: %d chars (%.1fms total)",
                len(selected_text),
                (t_end - t_start) * 1000,
            )
        else:
            log.debug("No text selected (empty after strip, %.1fms total)", (t_end - t_start) * 1000)

        return selected_text

    except Exception as e:
        t_end = time.perf_counter()
        log.warning(
            "Context detection failed (%.1fms): %s",
            (t_end - t_start) * 1000,
            e,
        )
        return ""


def _wait_for_modifiers_released() -> None:
    """Wartet bis alle Modifier-Keys (Ctrl, Alt, Shift, Win) losgelassen sind.

    Noetig fuer Toggle-Hotkey: Der User haelt noch Ctrl+Alt wenn die
    Context-Detection startet. Ctrl+C waehrend Ctrl+Alt gehalten wird,
    wuerde als Ctrl+Alt+C interpretiert und Copy nicht ausloesen.

    Beim Hold-Hotkey sind die Keys bereits losgelassen -> returned sofort.
    """
    user32 = ctypes.windll.user32
    deadline = time.perf_counter() + _MODIFIER_RELEASE_TIMEOUT_MS / 1000

    while time.perf_counter() < deadline:
        if not any(user32.GetAsyncKeyState(vk) & 0x8000 for vk in _VK_MODIFIERS):
            return
        time.sleep(_MODIFIER_POLL_MS / 1000)

    # Timeout: Modifier immer noch gehalten - trotzdem weitermachen
    log.debug(
        "Modifier keys still held after %dms timeout",
        _MODIFIER_RELEASE_TIMEOUT_MS,
    )


def _wait_for_clipboard_update(previous_sequence: int) -> bool:
    """Pollt kurz auf eine Clipboard-Aenderung nach Ctrl+C."""
    if previous_sequence <= 0:
        return False

    deadline = time.perf_counter() + _CLIPBOARD_WAIT_TIMEOUT_MS / 1000
    while time.perf_counter() < deadline:
        if get_clipboard_sequence_number() != previous_sequence:
            return True
        time.sleep(_CLIPBOARD_POLL_MS / 1000)
    return False


def _restore_clipboard(snapshot: ClipboardSnapshot) -> None:
    """Stellt den Clipboard-Inhalt wieder her (best-effort)."""
    restored = restore_clipboard(snapshot)
    if not restored and snapshot.formats:
        log.warning("Context detection: clipboard restore incomplete")


def detect_selected_text_async(
    window: WindowInfo | None,
    config: ConfigManager,
    cancel_event: threading.Event | None = None,
) -> Future[str]:
    """Startet detect_selected_text() in einem daemon-Thread.

    Args:
        window: Info ueber das aktive Fenster.
        config: ConfigManager-Instanz.
        cancel_event: Optionales Event zum Abbrechen.

    Returns:
        Future[str] das den markierten Text (oder "") enthaelt.
    """
    future: Future[str] = Future()

    def _worker() -> None:
        try:
            result = detect_selected_text(window, config, cancel_event)
            future.set_result(result)
        except Exception as e:
            future.set_exception(e)

    thread = threading.Thread(
        target=_worker,
        daemon=True,
        name="context-detector",
    )
    thread.start()
    return future
