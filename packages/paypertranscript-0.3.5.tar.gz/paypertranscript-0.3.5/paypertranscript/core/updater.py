"""Auto-Update von PyPI und Release Notes von GitHub."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import urllib.request
from urllib.error import HTTPError
from dataclasses import dataclass
from pathlib import Path

from packaging.version import InvalidVersion, Version

from paypertranscript.core.logging import get_logger

log = get_logger("core.updater")

PYPI_URL = "https://pypi.org/pypi/PayPerTranscript/json"
GITHUB_REPO = "nikovdany/PayPerTranscript"
GITHUB_RELEASES_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases"
GITHUB_LATEST_RELEASE_URL = f"{GITHUB_RELEASES_URL}/latest"
TIMEOUT = 10
CHANGELOG_PATH = Path(__file__).resolve().parents[2] / "CHANGELOG.md"


@dataclass(slots=True)
class ReleaseInfo:
    """Release-Metadaten fuer Update-Checks und Changelog-Anzeige."""

    version: str
    notes: str = ""
    html_url: str = ""
    published_at: str = ""


def _parse_version(v: str) -> Version:
    """Parst eine PEP440-Version fuer Vergleich."""
    return Version(v.strip())


def _fetch_json(url: str) -> dict | list | None:
    """Laedt ein JSON-Dokument mit schlanken Standard-Headern."""
    try:
        req = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": "PayPerTranscript-Updater",
            },
        )
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return json.loads(resp.read())
    except HTTPError as e:
        if e.code == 404 and url.startswith(GITHUB_RELEASES_URL):
            log.debug("GitHub Release-Endpunkt noch nicht verfuegbar: %s", url)
            return None
        log.warning("JSON konnte nicht geladen werden (%s): %s", url, e)
        return None
    except Exception as e:
        log.warning("JSON konnte nicht geladen werden (%s): %s", url, e)
        return None


def _normalize_release_version(tag: str | None) -> str:
    """Normalisiert einen GitHub-Tag wie v0.3.3 auf 0.3.3."""
    if not tag:
        return ""
    version = tag.strip()
    if version.lower().startswith("v"):
        version = version[1:]
    return version


def _parse_release_info(payload: dict | None) -> ReleaseInfo | None:
    """Erzeugt ein ReleaseInfo aus einem GitHub-Release-Payload."""
    if not isinstance(payload, dict):
        return None
    version = _normalize_release_version(str(payload.get("tag_name", "")))
    if not version:
        return None
    return ReleaseInfo(
        version=version,
        notes=str(payload.get("body", "") or "").strip(),
        html_url=str(payload.get("html_url", "") or ""),
        published_at=str(payload.get("published_at", "") or ""),
    )


def _load_local_changelog() -> str:
    """Liest das lokale CHANGELOG fuer Offline-Fallbacks."""
    try:
        return CHANGELOG_PATH.read_text(encoding="utf-8")
    except OSError as e:
        log.warning("Lokales CHANGELOG konnte nicht gelesen werden: %s", e)
        return ""


def _extract_changelog_section(changelog_text: str, version: str) -> tuple[str, str]:
    """Extrahiert den Abschnitt und das Datum fuer eine Version aus dem lokalen CHANGELOG."""
    normalized = _normalize_release_version(version)
    if not normalized:
        return "", ""

    lines = changelog_text.splitlines()
    start = None
    published_at = ""

    for index, line in enumerate(lines):
        if line.startswith("## ") and f"[{normalized}]" in line:
            start = index
            if " - " in line:
                published_at = line.rsplit(" - ", 1)[-1].strip()
            break

    if start is None:
        return "", ""

    end = len(lines)
    for index in range(start + 1, len(lines)):
        if lines[index].startswith("## "):
            end = index
            break

    return "\n".join(lines[start:end]).strip(), published_at


def _parse_local_release_history(limit: int) -> list[ReleaseInfo]:
    """Liest die letzten Versionen aus dem lokalen CHANGELOG als Fallback."""
    changelog_text = _load_local_changelog()
    if not changelog_text:
        return []

    releases: list[ReleaseInfo] = []
    lines = changelog_text.splitlines()

    for line in lines:
        if not line.startswith("## ["):
            continue
        version = line.split("[", 1)[1].split("]", 1)[0].strip()
        notes, published_at = _extract_changelog_section(changelog_text, version)
        releases.append(
            ReleaseInfo(
                version=version,
                notes=notes,
                published_at=published_at,
            )
        )
        if len(releases) >= limit:
            break

    return releases


def _release_notes_fallback(version: str) -> str:
    """Generischer Fallback fuer fehlende Release Notes."""
    return (
        f"# Version {version}\n\n"
        "- Dieses Update wurde installiert.\n"
        "- Fuer diese Version sind aktuell keine Release Notes hinterlegt."
    )


def format_release_date(raw_value: str) -> str:
    """Formatiert GitHub- oder CHANGELOG-Daten im europaeischen Stil."""
    if not raw_value:
        return "Datum unbekannt"

    try:
        if "T" in raw_value:
            from datetime import datetime

            dt = datetime.fromisoformat(raw_value.replace("Z", "+00:00"))
            return dt.strftime("%d.%m.%Y")
        from datetime import datetime

        dt = datetime.strptime(raw_value, "%Y-%m-%d")
        return dt.strftime("%d.%m.%Y")
    except ValueError:
        return raw_value


def normalize_release_notes(notes: str) -> str:
    """Normalisiert uebliche Abschnittstitel auf den ueblichen Release-Jargon."""
    replacements = {
        "### Neu fuer Updates": "### Feature",
        "### Neu für Updates": "### Feature",
        "### Neu": "### Feature",
        "### Verbessert": "### Fix",
    }

    normalized = notes or ""
    for old, new in replacements.items():
        normalized = normalized.replace(old, new)
    normalized = re.sub(
        r"(## \[[^\]]+\] - )(\d{4}-\d{2}-\d{2})",
        lambda match: f"{match.group(1)}{format_release_date(match.group(2))}",
        normalized,
    )
    return normalized


def get_latest_version() -> str | None:
    """Fragt PyPI nach der neuesten Version. Gibt None bei Fehler/Timeout."""
    try:
        req = urllib.request.Request(PYPI_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            data = json.loads(resp.read())
        return data["info"]["version"]
    except Exception as e:
        log.warning("PyPI-Version konnte nicht abgefragt werden: %s", e)
        return None


def get_latest_release_info() -> ReleaseInfo | None:
    """Holt die neueste Release-Info, mit PyPI-Fallback fuer die Version."""
    release_info = _parse_release_info(_fetch_json(GITHUB_LATEST_RELEASE_URL))
    if release_info is not None:
        return release_info

    latest_version = get_latest_version()
    if latest_version:
        return ReleaseInfo(version=latest_version)
    return None


def get_release_notes(version: str) -> str:
    """Liest Release Notes fuer eine bestimmte Version von GitHub."""
    normalized = _normalize_release_version(version)
    if not normalized:
        return ""

    for tag in (f"v{normalized}", normalized):
        payload = _fetch_json(f"{GITHUB_RELEASES_URL}/tags/{tag}")
        release_info = _parse_release_info(payload if isinstance(payload, dict) else None)
        if release_info is not None:
            return release_info.notes or _release_notes_fallback(release_info.version)

    local_notes, _published_at = _extract_changelog_section(_load_local_changelog(), normalized)
    if local_notes:
        return local_notes

    return _release_notes_fallback(normalized)


def get_recent_releases(limit: int = 5) -> list[ReleaseInfo]:
    """Liefert die letzten GitHub-Releases, mit lokalem CHANGELOG als Fallback."""
    safe_limit = max(1, limit)
    payload = _fetch_json(f"{GITHUB_RELEASES_URL}?per_page={safe_limit}")
    if isinstance(payload, list):
        releases: list[ReleaseInfo] = []
        for item in payload:
            if not isinstance(item, dict):
                continue
            if item.get("draft") or item.get("prerelease"):
                continue
            release_info = _parse_release_info(item)
            if release_info is not None:
                releases.append(release_info)
            if len(releases) >= safe_limit:
                return releases

    return _parse_local_release_history(safe_limit)


def is_update_available(current: str, latest: str) -> bool:
    """True wenn latest > current (Semver-Vergleich)."""
    try:
        return _parse_version(latest) > _parse_version(current)
    except (InvalidVersion, TypeError, AttributeError):
        return False


def install_update() -> bool:
    """Fuehrt pip install --upgrade aus. Gibt True bei Erfolg."""
    try:
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--upgrade",
                "--disable-pip-version-check",
                "PayPerTranscript",
            ],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            log.info("Update erfolgreich installiert")
            return True
        log.error("pip install fehlgeschlagen: %s", result.stderr)
        return False
    except Exception as e:
        log.error("Update-Installation fehlgeschlagen: %s", e)
        return False


def restart_app() -> None:
    """Startet die App neu (neuer Prozess, aktueller wird beendet)."""
    entry = shutil.which("paypertranscript")
    if entry:
        subprocess.Popen([entry])
    else:
        subprocess.Popen([sys.executable, "-m", "paypertranscript"])
    log.info("App wird neu gestartet...")
    sys.exit(0)
