"""Windows clipboard snapshot/restore helpers.

Designed for low-latency clipboard preservation during context detection and paste
operations. The implementation preserves clipboard formats best-effort by copying
raw global-memory payloads for each available format.
"""

from __future__ import annotations

import ctypes
import threading
import time
from dataclasses import dataclass
from typing import Final

from paypertranscript.core.logging import get_logger

log = get_logger("core.clipboard_manager")

if ctypes.sizeof(ctypes.c_void_p) == 8:
    _SIZE_T = ctypes.c_uint64
else:
    _SIZE_T = ctypes.c_uint32

_user32 = ctypes.WinDLL("user32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

_user32.OpenClipboard.argtypes = [ctypes.c_void_p]
_user32.OpenClipboard.restype = ctypes.c_int
_user32.CloseClipboard.argtypes = []
_user32.CloseClipboard.restype = ctypes.c_int
_user32.EmptyClipboard.argtypes = []
_user32.EmptyClipboard.restype = ctypes.c_int
_user32.EnumClipboardFormats.argtypes = [ctypes.c_uint]
_user32.EnumClipboardFormats.restype = ctypes.c_uint
_user32.GetClipboardData.argtypes = [ctypes.c_uint]
_user32.GetClipboardData.restype = ctypes.c_void_p
_user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
_user32.SetClipboardData.restype = ctypes.c_void_p
_user32.IsClipboardFormatAvailable.argtypes = [ctypes.c_uint]
_user32.IsClipboardFormatAvailable.restype = ctypes.c_int
_user32.GetClipboardSequenceNumber.argtypes = []
_user32.GetClipboardSequenceNumber.restype = ctypes.c_uint

_kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, _SIZE_T]
_kernel32.GlobalAlloc.restype = ctypes.c_void_p
_kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
_kernel32.GlobalLock.restype = ctypes.c_void_p
_kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
_kernel32.GlobalUnlock.restype = ctypes.c_int
_kernel32.GlobalSize.argtypes = [ctypes.c_void_p]
_kernel32.GlobalSize.restype = _SIZE_T
_kernel32.GlobalFree.argtypes = [ctypes.c_void_p]
_kernel32.GlobalFree.restype = ctypes.c_void_p

_GMEM_MOVEABLE: Final[int] = 0x0002
_CF_UNICODETEXT: Final[int] = 13

_OPEN_RETRIES: Final[int] = 5
_OPEN_DELAY_SECONDS: Final[float] = 0.002

_lock = threading.RLock()


@dataclass(frozen=True)
class ClipboardFormatPayload:
    """Raw bytes for a single clipboard format."""

    format_id: int
    data: bytes


@dataclass(frozen=True)
class ClipboardSnapshot:
    """Clipboard snapshot containing copied format payloads."""

    sequence_number: int
    formats: tuple[ClipboardFormatPayload, ...]


@dataclass(frozen=True)
class ClipboardTextSnapshot:
    """Text-only clipboard snapshot for safer paste/restore flows."""

    has_text: bool
    text: str
    captured: bool = True


_EMPTY_SNAPSHOT = ClipboardSnapshot(sequence_number=0, formats=())


def get_clipboard_sequence_number() -> int:
    """Return the current clipboard sequence number or 0 on failure."""
    try:
        return int(_user32.GetClipboardSequenceNumber())
    except Exception:
        return 0


def _open_clipboard() -> bool:
    for attempt in range(_OPEN_RETRIES):
        if _user32.OpenClipboard(None):
            return True
        if attempt < _OPEN_RETRIES - 1:
            time.sleep(_OPEN_DELAY_SECONDS)
    return False


def _copy_hglobal(handle: ctypes.c_void_p) -> bytes | None:
    size = int(_kernel32.GlobalSize(handle))
    if size < 0:
        return None

    ptr = _kernel32.GlobalLock(handle)
    if not ptr:
        return None

    try:
        if size == 0:
            return b""
        raw = (ctypes.c_ubyte * size).from_address(ptr)
        return bytes(raw)
    finally:
        _kernel32.GlobalUnlock(handle)


def _alloc_hglobal(data: bytes) -> ctypes.c_void_p:
    size = max(len(data), 1)
    handle = _kernel32.GlobalAlloc(_GMEM_MOVEABLE, size)
    if not handle:
        return ctypes.c_void_p()

    ptr = _kernel32.GlobalLock(handle)
    if not ptr:
        _kernel32.GlobalFree(handle)
        return ctypes.c_void_p()

    try:
        if data:
            ctypes.memmove(ptr, data, len(data))
        if size > len(data):
            ctypes.memset(ptr + len(data), 0, size - len(data))
    finally:
        _kernel32.GlobalUnlock(handle)

    return handle


def snapshot_clipboard() -> ClipboardSnapshot:
    """Capture the current clipboard in a best-effort, format-preserving way."""
    start = time.perf_counter()
    with _lock:
        if not _open_clipboard():
            log.debug("Clipboard snapshot skipped: OpenClipboard failed")
            return _EMPTY_SNAPSHOT

        try:
            sequence_number = int(_user32.GetClipboardSequenceNumber())
            payloads: list[ClipboardFormatPayload] = []

            fmt = 0
            while True:
                fmt = int(_user32.EnumClipboardFormats(fmt))
                if fmt == 0:
                    break

                handle = _user32.GetClipboardData(fmt)
                if not handle:
                    continue

                copied = _copy_hglobal(handle)
                if copied is None:
                    continue

                payloads.append(ClipboardFormatPayload(format_id=fmt, data=copied))

            snapshot = ClipboardSnapshot(
                sequence_number=sequence_number,
                formats=tuple(payloads),
            )
            elapsed_ms = (time.perf_counter() - start) * 1000
            log.debug(
                "Clipboard snapshot: %d formats in %.2fms",
                len(snapshot.formats),
                elapsed_ms,
            )
            return snapshot
        finally:
            _user32.CloseClipboard()


def restore_clipboard(snapshot: ClipboardSnapshot) -> bool:
    """Restore a previously captured clipboard snapshot."""
    start = time.perf_counter()
    with _lock:
        if not _open_clipboard():
            log.warning("Clipboard restore failed: OpenClipboard failed")
            return False

        try:
            if not _user32.EmptyClipboard():
                log.warning("Clipboard restore failed: EmptyClipboard failed")
                return False

            restored_count = 0
            for payload in snapshot.formats:
                handle = _alloc_hglobal(payload.data)
                if not handle:
                    continue

                result = _user32.SetClipboardData(payload.format_id, handle)
                if not result:
                    _kernel32.GlobalFree(handle)
                    continue

                restored_count += 1

            elapsed_ms = (time.perf_counter() - start) * 1000
            log.debug(
                "Clipboard restore: %d/%d formats in %.2fms",
                restored_count,
                len(snapshot.formats),
                elapsed_ms,
            )
            return restored_count == len(snapshot.formats)
        finally:
            _user32.CloseClipboard()


def get_clipboard_text() -> str:
    """Read UTF-16 text from clipboard if available."""
    with _lock:
        if not _open_clipboard():
            return ""

        try:
            if not _user32.IsClipboardFormatAvailable(_CF_UNICODETEXT):
                return ""

            handle = _user32.GetClipboardData(_CF_UNICODETEXT)
            if not handle:
                return ""

            ptr = _kernel32.GlobalLock(handle)
            if not ptr:
                return ""

            try:
                return ctypes.wstring_at(ptr) or ""
            finally:
                _kernel32.GlobalUnlock(handle)
        finally:
            _user32.CloseClipboard()


def set_clipboard_text(text: str) -> bool:
    """Replace clipboard contents with UTF-16 text."""
    utf16 = text.encode("utf-16-le") + b"\x00\x00"

    with _lock:
        if not _open_clipboard():
            return False

        try:
            if not _user32.EmptyClipboard():
                return False

            handle = _alloc_hglobal(utf16)
            if not handle:
                return False

            result = _user32.SetClipboardData(_CF_UNICODETEXT, handle)
            if not result:
                _kernel32.GlobalFree(handle)
                return False

            return True
        finally:
            _user32.CloseClipboard()


def clear_clipboard() -> bool:
    """Clear clipboard contents without writing replacement text."""
    with _lock:
        if not _open_clipboard():
            return False

        try:
            return bool(_user32.EmptyClipboard())
        finally:
            _user32.CloseClipboard()


def snapshot_clipboard_text() -> ClipboardTextSnapshot:
    """Capture only the current clipboard text, if any."""
    with _lock:
        if not _open_clipboard():
            return ClipboardTextSnapshot(captured=False, has_text=False, text="")

        try:
            if not _user32.IsClipboardFormatAvailable(_CF_UNICODETEXT):
                return ClipboardTextSnapshot(captured=True, has_text=False, text="")

            handle = _user32.GetClipboardData(_CF_UNICODETEXT)
            if not handle:
                return ClipboardTextSnapshot(captured=True, has_text=False, text="")

            ptr = _kernel32.GlobalLock(handle)
            if not ptr:
                return ClipboardTextSnapshot(captured=True, has_text=False, text="")

            try:
                return ClipboardTextSnapshot(
                    captured=True,
                    has_text=True,
                    text=ctypes.wstring_at(ptr) or "",
                )
            finally:
                _kernel32.GlobalUnlock(handle)
        finally:
            _user32.CloseClipboard()


def restore_clipboard_text(snapshot: ClipboardTextSnapshot) -> bool:
    """Restore a text snapshot, or clear temporary paste text when none existed."""
    if not snapshot.captured:
        return True
    if snapshot.has_text:
        return set_clipboard_text(snapshot.text)
    return clear_clipboard()
