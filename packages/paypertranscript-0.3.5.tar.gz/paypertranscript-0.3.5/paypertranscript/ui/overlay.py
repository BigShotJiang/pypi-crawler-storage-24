"""Status-Overlay fuer PayPerTranscript.

Modernes, rahmenloses Overlay mit Glassmorphism-Effekt.
Zeigt Audio-Visualizer, Lade-Dots, Erfolgs-, Busy- und Fehlermeldungen.
"""

import math
import random

from PySide6.QtCore import QEasingCurve, Property, QPropertyAnimation, QRectF, QTimer, Qt, Slot
from PySide6.QtGui import (
    QColor,
    QCursor,
    QFont,
    QFontMetrics,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QRadialGradient,
)
from PySide6.QtWidgets import QApplication, QWidget

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.logging import get_logger

log = get_logger("ui.overlay")

# -- Dimensionen --
_COMPACT_WIDTH = 150
_COMPACT_HEIGHT = 34
_COMPACT_RADIUS = 17
_MESSAGE_MIN_WIDTH = 180
_MESSAGE_MAX_WIDTH = 360

# -- Farbpalette --
_BG_COLOR = QColor(18, 18, 24, 230)
_BORDER_COLOR = QColor(255, 255, 255, 30)
_WHITE = QColor(255, 255, 255)
_GREEN = QColor(52, 211, 153)
_RED = QColor(248, 113, 113)
_TEXT_PRIMARY = QColor(255, 255, 255, 220)
_TEXT_DIM = QColor(255, 255, 255, 100)

# -- Timing --
_FPS_INTERVAL = 16
_FADE_IN_MS = 120
_FADE_OUT_MS = 200
_DONE_SHOW_MS = 700
_DONE_MSG_SHOW_MS = 1200
_ERROR_SHOW_MS = 2500
_BUSY_SHOW_MS = 1000

# -- Visualizer --
_BAR_COUNT = 5
_BAR_W = 3.0
_BAR_GAP = 3.0
_BAR_MAX_H = 18
_BAR_MIN_H = 2.5
_SMOOTHING = 0.35
_VISUAL_GAIN = 30.0

# -- Pulsing Dots --
_DOT_COUNT = 3
_DOT_RADIUS = 2.5
_DOT_GAP = 9.0
_DOT_PHASE_OFFSET = 0.7


class StatusOverlay(QWidget):
    """Modernes, rahmenloses Status-Overlay mit Glow-Effekten."""

    RECORDING = "recording"
    TRANSCRIBING = "transcribing"
    FORMATTING = "formatting"
    DONE = "done"
    DONE_MESSAGE = "done_message"
    BUSY = "busy"
    ERROR = "error"

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config = config
        self._state: str | None = None
        self._error_message = ""
        self._done_message = ""
        self._busy_message = ""

        self._tick = 0
        self._amplitude = 0.0
        self._bar_heights = [0.0] * _BAR_COUNT

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.resize(_COMPACT_WIDTH, _COMPACT_HEIGHT)

        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(_FPS_INTERVAL)
        self._anim_timer.timeout.connect(self._on_tick)

        self._window_opacity = 1.0
        self._fade_anim = QPropertyAnimation(self, b"overlayOpacity")
        self._fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade_anim.finished.connect(self._on_fade_finished)
        self._fading_out = False

        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._start_fade_out)

    def _get_overlay_opacity(self) -> float:
        return self._window_opacity

    def _set_overlay_opacity(self, value: float) -> None:
        self._window_opacity = max(0.0, min(1.0, value))
        self.setWindowOpacity(self._window_opacity)

    overlayOpacity = Property(float, _get_overlay_opacity, _set_overlay_opacity)

    @Slot()
    def show_recording(self) -> None:
        self._switch_state(self.RECORDING)

    @Slot()
    def show_transcribing(self) -> None:
        self._switch_state(self.TRANSCRIBING)

    @Slot()
    def show_formatting(self) -> None:
        self._switch_state(self.FORMATTING)

    @Slot()
    def show_done(self) -> None:
        self._switch_state(self.DONE)
        self._hide_timer.start(_DONE_SHOW_MS)

    @Slot(str)
    def show_done_message(self, message: str) -> None:
        self._done_message = message
        self._switch_state(self.DONE_MESSAGE)
        self._hide_timer.start(_DONE_MSG_SHOW_MS)

    @Slot(str)
    def show_busy(self, message: str) -> None:
        self._busy_message = message
        self._switch_state(self.BUSY)
        self._hide_timer.start(_BUSY_SHOW_MS)

    @Slot(str)
    def show_error(self, message: str) -> None:
        self._error_message = message
        self._switch_state(self.ERROR)
        self._hide_timer.start(_ERROR_SHOW_MS)

    def set_amplitude(self, value: float) -> None:
        self._amplitude = max(0.0, min(1.0, value))

    @Slot()
    def dismiss(self) -> None:
        self._hide_timer.stop()
        self._anim_timer.stop()
        self._fade_anim.stop()
        self._fading_out = False
        self._state = None
        self.hide()

    def _switch_state(self, new_state: str) -> None:
        old = self._state
        previous_size = self.size()
        self._state = new_state
        self._fading_out = False
        self._hide_timer.stop()
        self._fade_anim.stop()

        if new_state != old:
            self._tick = 0

        needs_anim = new_state in (
            self.RECORDING,
            self.TRANSCRIBING,
            self.FORMATTING,
            self.BUSY,
        )
        if needs_anim and not self._anim_timer.isActive():
            self._anim_timer.start()
        elif not needs_anim:
            self._anim_timer.stop()

        self._resize_for_state(new_state)
        size_changed = previous_size != self.size()

        if not self.isVisible() or old is None:
            self._position()
            self.setWindowOpacity(0.0)
            self._window_opacity = 0.0
            self.show()
            self._fade_in()
        elif size_changed:
            self._position()

        self.update()
        log.debug("Overlay: %s -> %s", old, new_state)

    def _resize_for_state(self, state: str) -> None:
        if state in (self.RECORDING, self.TRANSCRIBING, self.FORMATTING, self.DONE):
            self.resize(_COMPACT_WIDTH, _COMPACT_HEIGHT)
            return

        if state == self.DONE_MESSAGE:
            message = self._done_message or "OK"
            font = QFont("Segoe UI", 8)
            lead_padding = 38
        elif state == self.ERROR:
            message = self._error_message or "Fehler"
            font = QFont("Segoe UI", 8)
            lead_padding = 38
        else:
            message = self._busy_message or "Verarbeite noch"
            font = QFont("Segoe UI", 8)
            lead_padding = 30

        metrics = QFontMetrics(font)
        rough_width = min(
            _MESSAGE_MAX_WIDTH - lead_padding - 16,
            max(120, metrics.horizontalAdvance(message)),
        )
        width = max(_MESSAGE_MIN_WIDTH, min(_MESSAGE_MAX_WIDTH, lead_padding + rough_width + 20))
        text_width = max(100, width - lead_padding - 18)
        bounds = metrics.boundingRect(
            0,
            0,
            text_width,
            220,
            int(Qt.TextFlag.TextWordWrap),
            message,
        )
        height = max(_COMPACT_HEIGHT, bounds.height() + 18)
        self.resize(width, height)

    def _position(self) -> None:
        cursor_pos = QCursor.pos()
        mode = self._config.get("general.overlay_position", "mouse_cursor")

        screen = QApplication.screenAt(cursor_pos)
        if not screen:
            screen = QApplication.primaryScreen()
        if not screen:
            return
        geo = screen.availableGeometry()

        if mode == "bottom_center":
            x = geo.x() + (geo.width() - self.width()) // 2
            y = geo.y() + geo.height() - self.height() - 80
        else:
            x = cursor_pos.x() - self.width() // 2
            y = cursor_pos.y() - self.height() - 16
            x = max(geo.x(), min(x, geo.x() + geo.width() - self.width()))
            y = max(geo.y(), min(y, geo.y() + geo.height() - self.height()))

        self.move(x, y)

    def _fade_in(self) -> None:
        self._fading_out = False
        self._fade_anim.stop()
        self._fade_anim.setDuration(_FADE_IN_MS)
        self._fade_anim.setStartValue(0.0)
        self._fade_anim.setEndValue(1.0)
        self._fade_anim.start()

    def _start_fade_out(self) -> None:
        self._fading_out = True
        self._fade_anim.stop()
        self._fade_anim.setDuration(_FADE_OUT_MS)
        self._fade_anim.setStartValue(self.windowOpacity())
        self._fade_anim.setEndValue(0.0)
        self._fade_anim.start()

    def _on_fade_finished(self) -> None:
        if self._fading_out:
            self._state = None
            self._fading_out = False
            self._anim_timer.stop()
            self.hide()

    def _on_tick(self) -> None:
        self._tick += 1
        if self._state == self.RECORDING:
            self._update_bars()
        self.update()

    def _update_bars(self) -> None:
        amp = min(1.0, self._amplitude * _VISUAL_GAIN)
        for i in range(len(self._bar_heights)):
            target = amp * random.uniform(0.4, 1.3)
            target = max(0.0, min(1.0, target))
            self._bar_heights[i] += (target - self._bar_heights[i]) * _SMOOTHING

    def paintEvent(self, event: object) -> None:
        if self._state is None:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        self._draw_bg(painter)

        if self._state == self.RECORDING:
            self._draw_recording(painter)
        elif self._state in (self.TRANSCRIBING, self.FORMATTING):
            self._draw_processing(painter)
        elif self._state == self.DONE:
            self._draw_done(painter)
        elif self._state == self.DONE_MESSAGE:
            self._draw_done_message(painter)
        elif self._state == self.BUSY:
            self._draw_busy(painter)
        elif self._state == self.ERROR:
            self._draw_error(painter)

        painter.end()

    def _draw_bg(self, painter: QPainter) -> None:
        width = self.width()
        height = self.height()
        radius = min(_COMPACT_RADIUS, height / 2)
        pill = QPainterPath()
        pill.addRoundedRect(QRectF(0, 0, width, height), radius, radius)

        painter.fillPath(pill, _BG_COLOR)
        painter.setPen(QPen(_BORDER_COLOR, 1.0))
        painter.drawRoundedRect(QRectF(0.5, 0.5, width - 1, height - 1), radius, radius)

    def _draw_recording(self, painter: QPainter) -> None:
        total_width = _BAR_COUNT * _BAR_W + (_BAR_COUNT - 1) * _BAR_GAP
        start_x = (self.width() - total_width) / 2
        center_y = self.height() / 2

        painter.setPen(Qt.PenStyle.NoPen)

        for index, bar_height in enumerate(self._bar_heights):
            height = _BAR_MIN_H + bar_height * (_BAR_MAX_H - _BAR_MIN_H)
            x = start_x + index * (_BAR_W + _BAR_GAP)
            y = center_y - height / 2

            gradient = QLinearGradient(x, y + height, x, y)
            gradient.setColorAt(0.0, QColor(255, 255, 255, 140))
            gradient.setColorAt(1.0, _WHITE)
            painter.setBrush(gradient)
            painter.drawRoundedRect(QRectF(x, y, _BAR_W, height), _BAR_W / 2, _BAR_W / 2)

    def _draw_processing(self, painter: QPainter) -> None:
        label = "Transkribiere..." if self._state == self.TRANSCRIBING else "Formatiere..."
        dots_total_width = (_DOT_COUNT - 1) * _DOT_GAP + _DOT_RADIUS * 2
        content_width = dots_total_width + 12 + len(label) * 6.5
        start_x = max(_COMPACT_RADIUS + 6, (self.width() - content_width) / 2)
        center_y = self.height() / 2
        time_offset = self._tick * _FPS_INTERVAL / 1000.0

        for index in range(_DOT_COUNT):
            x = start_x + _DOT_RADIUS + index * _DOT_GAP
            phase = time_offset * 4.0 - index * _DOT_PHASE_OFFSET
            bounce = max(0.0, math.sin(phase)) ** 2
            y = center_y - bounce * 5
            dot_color = QColor(255, 255, 255, int(80 + bounce * 175))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(dot_color)
            painter.drawEllipse(
                QRectF(x - _DOT_RADIUS, y - _DOT_RADIUS, _DOT_RADIUS * 2, _DOT_RADIUS * 2)
            )

        text_x = start_x + dots_total_width + 12
        font = QFont("Segoe UI", 9)
        font.setWeight(QFont.Weight.Medium)
        painter.setFont(font)
        painter.setPen(QPen(_TEXT_DIM))
        painter.drawText(
            QRectF(text_x, 0, self.width() - text_x - 10, self.height()),
            Qt.AlignmentFlag.AlignVCenter,
            label,
        )

    def _draw_busy(self, painter: QPainter) -> None:
        label = self._busy_message or "Verarbeite noch"
        center_y = self.height() / 2
        start_x = 16
        time_offset = self._tick * _FPS_INTERVAL / 1000.0

        for index in range(_DOT_COUNT):
            x = start_x + _DOT_RADIUS + index * _DOT_GAP
            phase = time_offset * 4.0 - index * _DOT_PHASE_OFFSET
            bounce = max(0.0, math.sin(phase)) ** 2
            y = center_y - bounce * 4
            dot_color = QColor(255, 255, 255, int(80 + bounce * 175))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(dot_color)
            painter.drawEllipse(
                QRectF(x - _DOT_RADIUS, y - _DOT_RADIUS, _DOT_RADIUS * 2, _DOT_RADIUS * 2)
            )

        font = QFont("Segoe UI", 8)
        font.setWeight(QFont.Weight.Medium)
        painter.setFont(font)
        painter.setPen(QPen(_TEXT_PRIMARY))
        painter.drawText(
            QRectF(42, 6, self.width() - 54, self.height() - 12),
            Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextWordWrap,
            label,
        )

    def _draw_done(self, painter: QPainter) -> None:
        center_x = self.width() / 2
        center_y = self.height() / 2

        glow = QRadialGradient(center_x, center_y, 18)
        glow_color = QColor(_GREEN)
        glow_color.setAlpha(35)
        glow.setColorAt(0.0, glow_color)
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(glow)
        painter.drawEllipse(QRectF(center_x - 18, center_y - 18, 36, 36))

        pen = QPen(
            _GREEN,
            2.0,
            Qt.PenStyle.SolidLine,
            Qt.PenCapStyle.RoundCap,
            Qt.PenJoinStyle.RoundJoin,
        )
        painter.setPen(pen)
        painter.drawLine(int(center_x - 6), int(center_y), int(center_x - 2), int(center_y + 5))
        painter.drawLine(int(center_x - 2), int(center_y + 5), int(center_x + 7), int(center_y - 4))

    def _draw_done_message(self, painter: QPainter) -> None:
        icon_x = 24
        center_y = self.height() / 2

        glow = QRadialGradient(icon_x, center_y, 12)
        glow_color = QColor(_GREEN)
        glow_color.setAlpha(30)
        glow.setColorAt(0.0, glow_color)
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(glow)
        painter.drawEllipse(QRectF(icon_x - 12, center_y - 12, 24, 24))

        pen = QPen(
            _GREEN,
            2.0,
            Qt.PenStyle.SolidLine,
            Qt.PenCapStyle.RoundCap,
            Qt.PenJoinStyle.RoundJoin,
        )
        painter.setPen(pen)
        painter.drawLine(int(icon_x - 6), int(center_y), int(icon_x - 2), int(center_y + 5))
        painter.drawLine(int(icon_x - 2), int(center_y + 5), int(icon_x + 7), int(center_y - 4))

        font = QFont("Segoe UI", 8)
        font.setWeight(QFont.Weight.Medium)
        painter.setFont(font)
        painter.setPen(QPen(_TEXT_PRIMARY))
        painter.drawText(
            QRectF(icon_x + 14, 6, self.width() - icon_x - 24, self.height() - 12),
            Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextWordWrap,
            self._done_message or "OK",
        )

    def _draw_error(self, painter: QPainter) -> None:
        icon_x = 24
        center_y = self.height() / 2

        glow = QRadialGradient(icon_x, center_y, 12)
        glow_color = QColor(_RED)
        glow_color.setAlpha(30)
        glow.setColorAt(0.0, glow_color)
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(glow)
        painter.drawEllipse(QRectF(icon_x - 12, center_y - 12, 24, 24))

        pen = QPen(_RED, 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.drawLine(int(icon_x - 4), int(center_y - 4), int(icon_x + 4), int(center_y + 4))
        painter.drawLine(int(icon_x + 4), int(center_y - 4), int(icon_x - 4), int(center_y + 4))

        font = QFont("Segoe UI", 8)
        font.setWeight(QFont.Weight.Medium)
        painter.setFont(font)
        painter.setPen(QPen(_TEXT_PRIMARY))
        painter.drawText(
            QRectF(icon_x + 14, 6, self.width() - icon_x - 24, self.height() - 12),
            Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextWordWrap,
            self._error_message or "Fehler",
        )
