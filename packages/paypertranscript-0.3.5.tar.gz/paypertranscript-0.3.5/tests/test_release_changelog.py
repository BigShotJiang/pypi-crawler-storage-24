import unittest

from scripts.extract_changelog import extract_version_section


class ReleaseChangelogTests(unittest.TestCase):
    def test_extract_version_section_accepts_prefixed_tag(self) -> None:
        changelog = (
            "# Changelog\n\n"
            "## [0.3.4] - 2026-03-12\n"
            "- Erstes Update\n\n"
            "## [0.3.3] - 2026-03-10\n"
            "- Aelterer Eintrag\n"
        )

        section = extract_version_section(changelog, "v0.3.4")

        self.assertIn("## [0.3.4] - 2026-03-12", section)
        self.assertIn("- Erstes Update", section)
        self.assertNotIn("0.3.3", section)
