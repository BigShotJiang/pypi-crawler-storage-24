import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest import mock

from paypertranscript.core import config as config_module
from paypertranscript.core.atomic_io import atomic_write_text
from paypertranscript.core.session_logger import SessionLogger


class AtomicAndSessionLoggerTests(unittest.TestCase):
    def _unique_file(self, suffix: str) -> Path:
        return Path(f"._test_{uuid.uuid4().hex}{suffix}")

    def _unique_dir(self) -> Path:
        return Path(f"._test_dir_{uuid.uuid4().hex}")

    def test_atomic_write_text_persists_content(self) -> None:
        path = self._unique_file("_config.json")
        try:
            with mock.patch("paypertranscript.core.atomic_io.os.fsync"):
                atomic_write_text(path, '{"ok": true}')
            self.assertEqual(path.read_text(encoding="utf-8"), '{"ok": true}')
        finally:
            if path.exists():
                path.unlink()

    def test_atomic_write_text_cleans_temp_file_on_failure(self) -> None:
        path = self._unique_file("_tracking.json")
        try:
            with (
                mock.patch("paypertranscript.core.atomic_io.os.fsync"),
                mock.patch("paypertranscript.core.atomic_io.os.replace", side_effect=OSError("boom")),
            ):
                with self.assertRaises(OSError):
                    atomic_write_text(path, "{}")

            leftovers = list(path.parent.glob(f".{path.name}.*.tmp"))
            self.assertEqual(leftovers, [])
        finally:
            if path.exists():
                path.unlink()

    def test_config_save_uses_atomic_write(self) -> None:
        root = self._unique_dir()
        root.mkdir(parents=True, exist_ok=True)
        try:
            with (
                mock.patch.object(config_module, "APPDATA_DIR", root),
                mock.patch.object(config_module, "CONFIG_FILE", root / "config.json"),
                mock.patch.object(config_module, "AUDIO_DIR", root / "audio"),
            ):
                manager = config_module.ConfigManager()
                with mock.patch("paypertranscript.core.config.atomic_write_text") as write_mock:
                    manager._save()

                write_mock.assert_called_once()
                self.assertEqual(write_mock.call_args.args[0], root / "config.json")
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_session_logger_keeps_legacy_entries_compatible(self) -> None:
        tracking_file = self._unique_file("_legacy_tracking.json")
        try:
            tracking_file.write_text(
                json.dumps(
                    {
                        "sessions": [
                            {
                                "timestamp": "2025-01-01T00:00:00+00:00",
                                "audio_duration_seconds": 1.0,
                                "total_cost_usd": 0.001,
                            }
                        ],
                        "totals": {"session_count": 1},
                    }
                ),
                encoding="utf-8",
            )

            logger = SessionLogger(tracking_file=tracking_file)
            self.assertEqual(len(logger.get_sessions()), 1)

            logger.log_session(
                {
                    "timestamp": "2025-01-01T00:01:00+00:00",
                    "audio_duration_seconds": 2.0,
                    "billed_seconds": 2.0,
                    "stt_cost_usd": 0.01,
                    "llm_cost_usd": 0.02,
                    "total_cost_usd": 0.03,
                    "transcript_text": "hello",
                }
            )

            data = json.loads(tracking_file.read_text(encoding="utf-8"))
            self.assertEqual(len(data["sessions"]), 2)
            self.assertEqual(data["sessions"][0]["audio_duration_seconds"], 1.0)
            self.assertEqual(data["sessions"][1]["transcript_text"], "hello")
        finally:
            if tracking_file.exists():
                tracking_file.unlink()

    def test_session_logger_serves_reads_from_cache(self) -> None:
        tracking_file = self._unique_file("_cache_tracking.json")
        try:
            logger = SessionLogger(tracking_file=tracking_file)
            logger.log_session(
                {
                    "timestamp": "2025-01-01T00:01:00+00:00",
                    "audio_duration_seconds": 2.0,
                    "billed_seconds": 2.0,
                    "stt_cost_usd": 0.01,
                    "llm_cost_usd": 0.02,
                    "total_cost_usd": 0.03,
                }
            )

            with mock.patch.object(
                logger,
                "_read_tracking",
                side_effect=AssertionError("Cache-Leser duerfen keine Disk-Reads ausloesen"),
            ):
                sessions = logger.get_sessions()
                totals = logger.get_totals()

            self.assertEqual(len(sessions), 1)
            self.assertEqual(totals["session_count"], 1)
            self.assertAlmostEqual(totals["total_cost_usd"], 0.03)
        finally:
            if tracking_file.exists():
                tracking_file.unlink()
