import builtins
import sys
import types
import unittest
from unittest import mock

import paypertranscript.__main__ as main_module


class MainEntrypointTests(unittest.TestCase):
    def test_main_starts_ui_without_importing_updater(self) -> None:
        app_instance = mock.Mock()
        app_instance.run.return_value = 7

        fake_logging = types.ModuleType("paypertranscript.core.logging")
        fake_logging.setup_logging = mock.Mock()

        fake_ui_app = types.ModuleType("paypertranscript.ui.app")
        fake_ui_app.PayPerTranscriptApp = mock.Mock(return_value=app_instance)

        real_import = builtins.__import__

        def guarded_import(name: str, globals=None, locals=None, fromlist=(), level=0):
            if name == "paypertranscript.core.updater":
                raise AssertionError("Updater darf beim Startup nicht synchron importiert werden")
            return real_import(name, globals, locals, fromlist, level)

        with (
            mock.patch.dict(
                sys.modules,
                {
                    "paypertranscript.core.logging": fake_logging,
                    "paypertranscript.ui.app": fake_ui_app,
                },
            ),
            mock.patch.object(main_module, "_load_dotenv"),
            mock.patch("sys.exit") as exit_mock,
            mock.patch("builtins.__import__", side_effect=guarded_import),
        ):
            main_module.main()

        fake_logging.setup_logging.assert_called_once_with(debug=False)
        fake_ui_app.PayPerTranscriptApp.assert_called_once_with()
        app_instance.run.assert_called_once_with()
        exit_mock.assert_called_once_with(7)
