import unittest
from types import SimpleNamespace
from unittest import mock

from PySide6.QtWidgets import QApplication

from paypertranscript.ui.main_window import MainWindow
from paypertranscript.ui.setup_wizard import SetupWizard


class _FakeConfig:
    def get(self, _key: str, default: object = None) -> object:
        return default

    def update(self, _payload: dict[str, object]) -> None:
        return None


class _RecordingConfig:
    def __init__(self) -> None:
        self.update_calls: list[dict[str, object]] = []

    def update(self, payload: dict[str, object]) -> None:
        self.update_calls.append(payload)


class UiResponsiveAndWizardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._app = QApplication.instance() or QApplication([])

    def test_main_window_has_minimum_size_without_fixed_width(self) -> None:
        window = MainWindow(
            config=_FakeConfig(),
            hotkey_listener=None,
            session_logger=None,
            get_last_transcription=lambda: None,
        )
        self.addCleanup(window.close)

        self.assertEqual(window.minimumWidth(), 760)
        self.assertEqual(window.minimumHeight(), 560)
        self.assertGreater(window.maximumWidth(), window.minimumWidth())
        self.assertGreater(window.maximumHeight(), window.minimumHeight())

    def test_setup_wizard_has_minimum_size_without_fixed_width(self) -> None:
        wizard = SetupWizard(_FakeConfig())
        self.addCleanup(wizard.close)

        self.assertEqual(wizard.minimumWidth(), 620)
        self.assertEqual(wizard.minimumHeight(), 520)
        self.assertGreater(wizard.maximumWidth(), wizard.minimumWidth())
        self.assertGreater(wizard.maximumHeight(), wizard.minimumHeight())

    def test_setup_wizard_finish_saves_with_single_bundled_update(self) -> None:
        config = _RecordingConfig()
        wizard = SimpleNamespace(
            _config=config,
            _api_key="gsk_test",
            _language="en",
            _hold_hotkey=["ctrl", "cmd"],
            _toggle_hotkey=None,
            _words=["OpenAI", "Groq"],
            accept=mock.Mock(),
        )

        with mock.patch("paypertranscript.ui.setup_wizard.save_api_key") as save_key:
            SetupWizard._finish(wizard)

        save_key.assert_called_once_with("gsk_test")
        self.assertEqual(
            config.update_calls,
            [
                {
                    "general": {
                        "language": "en",
                        "hold_hotkey": ["ctrl", "cmd"],
                        "toggle_hotkey": None,
                    },
                    "words": {
                        "misspelled_words": ["OpenAI", "Groq"],
                    },
                }
            ],
        )
        wizard.accept.assert_called_once_with()
