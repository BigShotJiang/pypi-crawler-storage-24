import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from paypertranscript.pipeline.transcription import TranscriptionPipeline


class _FakeConfig:
    def __init__(self, values: dict[str, object]) -> None:
        self.values = values

    def get(self, key: str, default: object = None) -> object:
        return self.values.get(key, default)


class _FakeSessionLogger:
    def __init__(self) -> None:
        self.logged: list[dict[str, object]] = []

    def log_session(self, session: dict[str, object]) -> None:
        self.logged.append(session)


class _FakeSTT:
    def __init__(self, text: str) -> None:
        self.text = text

    def transcribe(self, audio_path: Path, language: str, prompt: str = "") -> str:
        return self.text


class _PendingContextFuture:
    def __init__(self) -> None:
        self.result_calls = 0

    def done(self) -> bool:
        return False

    def result(self) -> str:
        self.result_calls += 1
        raise AssertionError("Ein unfertiger Kontext darf nicht abgefragt werden")


class PipelinePrivacyAndTranscriptTests(unittest.TestCase):
    def test_log_session_respects_save_transcripts_flag(self) -> None:
        window = SimpleNamespace(process_name="notepad.exe", window_title="Note")

        logger_false = _FakeSessionLogger()
        pipe_false = TranscriptionPipeline(
            stt_provider=_FakeSTT("ok"),
            config=_FakeConfig({"data.save_transcripts": False, "general.language": "de"}),
            session_logger=logger_false,
        )
        pipe_false._log_session(
            audio_duration=1.0,
            llm_used=False,
            llm_input_tokens=0,
            llm_output_tokens=0,
            window=window,
            category_key="",
            transcript_text="SECRET",
        )
        self.assertNotIn("transcript_text", logger_false.logged[0])

        logger_true = _FakeSessionLogger()
        pipe_true = TranscriptionPipeline(
            stt_provider=_FakeSTT("ok"),
            config=_FakeConfig({"data.save_transcripts": True, "general.language": "de"}),
            session_logger=logger_true,
        )
        pipe_true._log_session(
            audio_duration=1.0,
            llm_used=False,
            llm_input_tokens=0,
            llm_output_tokens=0,
            window=window,
            category_key="",
            transcript_text="SECRET",
        )
        self.assertEqual(logger_true.logged[0]["transcript_text"], "SECRET")

    def test_hallucination_log_does_not_include_text_content(self) -> None:
        hallucination = "Thanks for watching and subtitles by"
        pipe = TranscriptionPipeline(
            stt_provider=_FakeSTT(hallucination),
            config=_FakeConfig({
                "general.language": "de",
                "words.misspelled_words": [],
                "formatting.window_mappings": {},
            }),
            llm_provider=None,
            session_logger=None,
        )

        with mock.patch("paypertranscript.pipeline.transcription.log.info") as info_log:
            pipe.process(Path("sample.wav"), audio_duration=1.0)

        joined = "\n".join(" ".join(map(str, c.args)) for c in info_log.call_args_list)
        self.assertIn("Halluzination erkannt", joined)
        self.assertNotIn(hallucination, joined)

    def test_pending_context_future_is_skipped_without_waiting(self) -> None:
        future = _PendingContextFuture()
        pipe = TranscriptionPipeline(
            stt_provider=_FakeSTT("Hallo Welt"),
            config=_FakeConfig({
                "general.language": "de",
                "words.misspelled_words": [],
                "formatting.window_mappings": {},
            }),
            llm_provider=None,
            session_logger=None,
        )

        with mock.patch("paypertranscript.pipeline.transcription.insert_text") as insert_mock:
            pipe.process(
                Path("sample.wav"),
                audio_duration=1.0,
                context_future=future,
            )

        insert_mock.assert_called_once_with("Hallo Welt")
        self.assertEqual(future.result_calls, 0)
