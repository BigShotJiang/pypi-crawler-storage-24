import threading
import unittest

import numpy as np

from paypertranscript.core.recorder import AudioRecorder


class RecorderThreadSafetyTests(unittest.TestCase):
    def test_stop_recording_is_safe_against_parallel_callback(self) -> None:
        recorder = AudioRecorder()
        recorder.start_recording()

        frame = np.ones((64, 1), dtype=np.int16)
        recorder._audio_callback(frame, 64, None, 0)

        stop_event = threading.Event()
        errors: list[Exception] = []

        def callback_loop() -> None:
            try:
                while not stop_event.is_set():
                    recorder._audio_callback(frame, 64, None, 0)
            except Exception as exc:  # pragma: no cover - failure path
                errors.append(exc)

        thread = threading.Thread(target=callback_loop, daemon=True)
        thread.start()

        audio = recorder.stop_recording()
        stop_event.set()
        thread.join(timeout=1.0)

        self.assertEqual(errors, [])
        self.assertIsNotNone(audio)

        before = len(recorder._frames)
        recorder._audio_callback(frame, 64, None, 0)
        self.assertEqual(len(recorder._frames), before)
