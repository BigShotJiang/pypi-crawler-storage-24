import unittest
from unittest import mock

from paypertranscript.core import updater


class UpdaterVersionTests(unittest.TestCase):
    def test_pep440_version_comparisons(self) -> None:
        self.assertTrue(updater.is_update_available("0.3.1rc1", "0.3.1"))
        self.assertTrue(updater.is_update_available("0.3.1", "0.3.1.post1"))
        self.assertFalse(updater.is_update_available("0.3.1", "0.3.1rc1"))

    def test_invalid_versions_return_false(self) -> None:
        self.assertFalse(updater.is_update_available("0.3.1", "invalid"))
        self.assertFalse(updater.is_update_available("invalid", "0.3.1"))

    def test_parse_release_info_normalizes_v_prefix(self) -> None:
        release_info = updater._parse_release_info(
            {
                "tag_name": "v0.3.4",
                "body": "# Version 0.3.4\n\n- Notes",
                "html_url": "https://example.com/release",
                "published_at": "2026-03-12T10:00:00Z",
            }
        )

        self.assertIsNotNone(release_info)
        assert release_info is not None
        self.assertEqual(release_info.version, "0.3.4")
        self.assertEqual(release_info.published_at, "2026-03-12T10:00:00Z")
        self.assertIn("Notes", release_info.notes)

    def test_get_release_notes_uses_local_changelog_before_generic_fallback(self) -> None:
        local_changelog = (
            "# Changelog\n\n"
            "## [0.3.4] - 2026-03-12\n"
            "- Lokaler Eintrag\n"
        )
        with (
            mock.patch("paypertranscript.core.updater._fetch_json", return_value=None),
            mock.patch("paypertranscript.core.updater._load_local_changelog", return_value=local_changelog),
        ):
            notes = updater.get_release_notes("0.3.4")

        self.assertIn("Lokaler Eintrag", notes)

    def test_get_recent_releases_uses_local_history_as_fallback(self) -> None:
        local_changelog = (
            "# Changelog\n\n"
            "## [0.3.4] - 2026-03-12\n"
            "- Neues Feature\n\n"
            "## [0.3.3] - 2026-03-11\n"
            "- Aelterer Eintrag\n"
        )
        with (
            mock.patch("paypertranscript.core.updater._fetch_json", return_value=None),
            mock.patch("paypertranscript.core.updater._load_local_changelog", return_value=local_changelog),
        ):
            releases = updater.get_recent_releases(limit=2)

        self.assertEqual([release.version for release in releases], ["0.3.4", "0.3.3"])
        self.assertEqual(releases[0].published_at, "2026-03-12")

    def test_get_recent_releases_filters_github_payload(self) -> None:
        payload = [
            {"tag_name": "v0.3.4", "body": "- First", "published_at": "2026-03-12T10:00:00Z"},
            {"tag_name": "v0.3.3", "body": "- Second", "draft": True},
            {"tag_name": "v0.3.2", "body": "- Third", "published_at": "2026-03-10T10:00:00Z"},
        ]
        with mock.patch("paypertranscript.core.updater._fetch_json", return_value=payload):
            releases = updater.get_recent_releases(limit=2)

        self.assertEqual([release.version for release in releases], ["0.3.4", "0.3.2"])

    def test_normalize_release_notes_maps_german_headings(self) -> None:
        notes = "### Neu\n- A\n\n### Verbessert\n- B\n\n### Neu fuer Updates\n- C"
        normalized = updater.normalize_release_notes(notes)

        self.assertIn("### Feature", normalized)
        self.assertIn("### Fix", normalized)
        self.assertNotIn("### Neu", normalized)

    def test_normalize_release_notes_formats_iso_dates_in_headings(self) -> None:
        notes = "## [0.3.3] - 2026-03-12\n\n### Verbessert\n- A"

        normalized = updater.normalize_release_notes(notes)

        self.assertIn("## [0.3.3] - 12.03.2026", normalized)
