import unittest
import uuid
from pathlib import Path
from unittest import mock

from paypertranscript.providers.groq_provider import GroqSTTProvider


class _FakeTranscriptions:
    def create(self, **kwargs: object) -> str:
        return "transcribed"


class _FakeAudio:
    def __init__(self) -> None:
        self.transcriptions = _FakeTranscriptions()


class _FakeClient:
    def __init__(self) -> None:
        self.audio = _FakeAudio()


class GroqProviderLoggingTests(unittest.TestCase):
    def test_prompt_content_is_not_logged(self) -> None:
        wav = Path(f"._test_audio_{uuid.uuid4().hex}.wav")
        wav.write_bytes(b"0" * 45)
        secret_prompt = "VERY_SECRET_PROMPT"

        try:
            with mock.patch("paypertranscript.providers.groq_provider.groq.Groq", return_value=_FakeClient()):
                provider = GroqSTTProvider(api_key="dummy")
                with mock.patch("paypertranscript.providers.groq_provider.log.debug") as debug_log:
                    result = provider.transcribe(wav, language="de", prompt=secret_prompt)

            self.assertEqual(result, "transcribed")
            self.assertTrue(debug_log.called)
            joined_calls = "\n".join(" ".join(map(str, c.args)) for c in debug_log.call_args_list)
            self.assertNotIn(secret_prompt, joined_calls)
        finally:
            if wav.exists():
                wav.unlink()
