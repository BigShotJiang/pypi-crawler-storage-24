import ctypes
import unittest
from types import SimpleNamespace
from unittest import mock

from paypertranscript.core import clipboard_manager as cm
from paypertranscript.core.clipboard_manager import (
    ClipboardFormatPayload,
    ClipboardSnapshot,
    ClipboardTextSnapshot,
)


class ClipboardManagerFormatTests(unittest.TestCase):
    def test_snapshot_captures_multiple_formats(self) -> None:
        enum_map = {0: 1, 1: 2, 2: 3, 3: 0}
        handle_map = {1: 101, 2: 102, 3: 103}
        payload_map = {101: b"txt", 102: b"html", 103: b"img"}

        fake_user32 = SimpleNamespace(
            EnumClipboardFormats=lambda fmt: enum_map.get(fmt, 0),
            GetClipboardData=lambda fmt: handle_map.get(fmt, 0),
            GetClipboardSequenceNumber=lambda: 42,
            CloseClipboard=lambda: 1,
        )

        with (
            mock.patch.object(cm, "_open_clipboard", return_value=True),
            mock.patch.object(cm, "_user32", fake_user32),
            mock.patch.object(cm, "_copy_hglobal", side_effect=lambda handle: payload_map[handle]),
        ):
            snapshot = cm.snapshot_clipboard()

        self.assertEqual(snapshot.sequence_number, 42)
        self.assertEqual([p.format_id for p in snapshot.formats], [1, 2, 3])
        self.assertEqual([p.data for p in snapshot.formats], [b"txt", b"html", b"img"])

    def test_restore_clipboard_is_best_effort_for_all_formats(self) -> None:
        snapshot = ClipboardSnapshot(
            sequence_number=1,
            formats=(
                ClipboardFormatPayload(format_id=1, data=b"a"),
                ClipboardFormatPayload(format_id=2, data=b"b"),
            ),
        )

        set_data = mock.Mock(side_effect=[ctypes.c_void_p(1001), ctypes.c_void_p(0)])
        fake_user32 = SimpleNamespace(
            EmptyClipboard=lambda: 1,
            SetClipboardData=set_data,
            CloseClipboard=lambda: 1,
        )
        fake_kernel32 = SimpleNamespace(GlobalFree=mock.Mock())

        with (
            mock.patch.object(cm, "_open_clipboard", return_value=True),
            mock.patch.object(cm, "_user32", fake_user32),
            mock.patch.object(cm, "_kernel32", fake_kernel32),
            mock.patch.object(cm, "_alloc_hglobal", side_effect=[ctypes.c_void_p(11), ctypes.c_void_p(12)]),
        ):
            restored = cm.restore_clipboard(snapshot)

        self.assertFalse(restored)
        self.assertEqual(set_data.call_count, 2)

    def test_restore_clipboard_text_clears_when_snapshot_was_empty(self) -> None:
        fake_user32 = SimpleNamespace(
            EmptyClipboard=mock.Mock(return_value=1),
            CloseClipboard=lambda: 1,
        )

        with (
            mock.patch.object(cm, "_open_clipboard", return_value=True),
            mock.patch.object(cm, "_user32", fake_user32),
        ):
            restored = cm.restore_clipboard_text(
                ClipboardTextSnapshot(has_text=False, text="", captured=True)
            )

        self.assertTrue(restored)
        fake_user32.EmptyClipboard.assert_called_once_with()

    def test_snapshot_clipboard_text_marks_open_failure_as_uncaptured(self) -> None:
        with mock.patch.object(cm, "_open_clipboard", return_value=False):
            snapshot = cm.snapshot_clipboard_text()

        self.assertFalse(snapshot.captured)
        self.assertFalse(snapshot.has_text)
        self.assertEqual(snapshot.text, "")
