import unittest
from types import SimpleNamespace
from unittest import mock

from paypertranscript.core.clipboard_manager import (
    ClipboardFormatPayload,
    ClipboardSnapshot,
    ClipboardTextSnapshot,
)
from paypertranscript.core.context_detector import detect_selected_text
from paypertranscript.core.text_inserter import insert_text, insert_text_streaming


class _FakeConfig:
    def __init__(self, values: dict[str, object]) -> None:
        self.values = values

    def get(self, key: str, default: object = None) -> object:
        return self.values.get(key, default)


class ClipboardIntegrationTests(unittest.TestCase):
    def test_context_detection_skips_codex_terminal_by_default(self) -> None:
        cfg = _FakeConfig({
            "context.detect_selection": True,
            "context.terminal_blocklist": [],
        })
        window = SimpleNamespace(process_name="Codex.exe")

        with mock.patch("paypertranscript.core.context_detector.snapshot_clipboard") as snapshot_mock:
            result = detect_selected_text(window, cfg)

        self.assertEqual(result, "")
        snapshot_mock.assert_not_called()

    def test_context_detection_uses_snapshot_and_restore(self) -> None:
        snapshot = ClipboardSnapshot(
            sequence_number=7,
            formats=(ClipboardFormatPayload(format_id=13, data=b"abc"),),
        )
        cfg = _FakeConfig({
            "context.detect_selection": True,
            "context.terminal_blocklist": [],
        })
        window = SimpleNamespace(process_name="notepad.exe")

        with (
            mock.patch("paypertranscript.core.context_detector.snapshot_clipboard", return_value=snapshot),
            mock.patch("paypertranscript.core.context_detector.set_clipboard_text", return_value=True),
            mock.patch("paypertranscript.core.context_detector.get_clipboard_text", return_value="selected"),
            mock.patch("paypertranscript.core.context_detector.restore_clipboard", return_value=True) as restore_mock,
            mock.patch("paypertranscript.core.context_detector._wait_for_modifiers_released"),
            mock.patch("paypertranscript.core.context_detector.pyautogui.hotkey"),
            mock.patch("paypertranscript.core.context_detector.time.sleep"),
        ):
            result = detect_selected_text(window, cfg)

        self.assertEqual(result, "selected")
        restore_mock.assert_called_once_with(snapshot)

    def test_insert_text_has_no_extra_sleep(self) -> None:
        snapshot = ClipboardTextSnapshot(has_text=True, text="old")
        sleep_calls: list[float] = []

        with (
            mock.patch("paypertranscript.core.text_inserter.snapshot_clipboard_text", return_value=snapshot),
            mock.patch("paypertranscript.core.text_inserter.set_clipboard_text", return_value=True),
            mock.patch("paypertranscript.core.text_inserter.restore_clipboard_text", return_value=True),
            mock.patch("paypertranscript.core.text_inserter.pyautogui.hotkey"),
            mock.patch("paypertranscript.core.text_inserter.time.sleep", side_effect=lambda s: sleep_calls.append(s)),
        ):
            insert_text("hello")

        self.assertEqual(sleep_calls, [0.05])

    def test_insert_text_clears_temporary_clipboard_when_original_was_empty(self) -> None:
        snapshot = ClipboardTextSnapshot(has_text=False, text="", captured=True)

        with (
            mock.patch("paypertranscript.core.text_inserter.snapshot_clipboard_text", return_value=snapshot),
            mock.patch("paypertranscript.core.text_inserter.set_clipboard_text", return_value=True),
            mock.patch("paypertranscript.core.text_inserter.restore_clipboard_text", return_value=True) as restore_mock,
            mock.patch("paypertranscript.core.text_inserter.pyautogui.hotkey"),
            mock.patch("paypertranscript.core.text_inserter.time.sleep"),
        ):
            insert_text("hello")

        restore_mock.assert_called_once_with(snapshot)

    def test_insert_text_streaming_returns_full_inserted_text(self) -> None:
        snapshot = ClipboardTextSnapshot(has_text=True, text="old")

        with (
            mock.patch("paypertranscript.core.text_inserter.snapshot_clipboard_text", return_value=snapshot),
            mock.patch("paypertranscript.core.text_inserter.set_clipboard_text", return_value=True) as set_mock,
            mock.patch("paypertranscript.core.text_inserter.restore_clipboard_text", return_value=True) as restore_mock,
            mock.patch("paypertranscript.core.text_inserter.pyautogui.hotkey"),
            mock.patch("paypertranscript.core.text_inserter.time.sleep"),
        ):
            text = insert_text_streaming(iter(["ab", "cd"]))

        self.assertEqual(text, "abcd")
        self.assertGreaterEqual(set_mock.call_count, 1)
        restore_mock.assert_called_once_with(snapshot)
