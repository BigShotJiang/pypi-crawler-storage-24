import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from PySide6.QtCore import Qt

from paypertranscript.core.hotkey import HotkeyListener
from paypertranscript.pipeline.transcription import STATUS_DONE
from paypertranscript.ui.app import PayPerTranscriptApp, _RecordingSession
from paypertranscript.ui.pages.settings_page import SettingsPage


class _FakeConfig:
    def __init__(self, values: dict[str, object] | None = None) -> None:
        self.values = values or {}
        self.set_calls: list[tuple[str, object]] = []
        self.update_calls: list[dict[str, object]] = []

    def get(self, key: str, default: object = None) -> object:
        return self.values.get(key, default)

    def set(self, key: str, value: object) -> None:
        self.values[key] = value
        self.set_calls.append((key, value))

    def update(self, payload: dict[str, object]) -> None:
        self.update_calls.append(payload)
        for section, values in payload.items():
            if isinstance(values, dict):
                for key, value in values.items():
                    self.values[f"{section}.{key}"] = value


class _FakeTimer:
    def __init__(self) -> None:
        self.interval = 0
        self._active = False
        self.start_calls = 0
        self.stop_calls = 0

    def setInterval(self, value: int) -> None:
        self.interval = value

    def isActive(self) -> bool:
        return self._active

    def start(self) -> None:
        self._active = True
        self.start_calls += 1

    def stop(self) -> None:
        self._active = False
        self.stop_calls += 1


def _emit_signal() -> SimpleNamespace:
    return SimpleNamespace(emit=mock.Mock())


class HotkeySettingsTimerTests(unittest.TestCase):
    def test_hotkey_listener_disables_toggle_when_none(self) -> None:
        listener = HotkeyListener(
            hold_hotkey=["ctrl", "cmd"],
            toggle_hotkey=["ctrl", "alt"],
            on_hold_start=lambda: None,
            on_hold_stop=lambda: None,
            on_toggle=lambda: None,
        )

        listener.update_hotkeys(toggle_hotkey=None)

        self.assertEqual(listener._toggle_keys, [])
        self.assertEqual(listener._toggle_modifier_groups, [])

    def test_settings_page_toggle_none_updates_listener_immediately(self) -> None:
        cfg = _FakeConfig()
        listener = mock.Mock()
        page = SimpleNamespace(
            _updating=False,
            _config=cfg,
            _hotkey_listener=listener,
        )

        SettingsPage._on_toggle_hotkey_changed(page, 0)

        self.assertIn(("general.toggle_hotkey", None), cfg.set_calls)
        listener.update_hotkeys.assert_called_once_with(toggle_hotkey=None)

    def test_settings_page_context_callbacks_update_config(self) -> None:
        cfg = _FakeConfig()
        page = SimpleNamespace(
            _updating=False,
            _config=cfg,
        )

        SettingsPage._on_detect_selection_changed(page, Qt.CheckState.Unchecked.value)
        SettingsPage._on_hold_context_timing_changed(page, 1)
        SettingsPage._on_toggle_context_timing_changed(page, 1)

        self.assertIn(("context.detect_selection", False), cfg.set_calls)
        self.assertIn(("context.hold_capture_timing", "start"), cfg.set_calls)
        self.assertIn(("context.toggle_capture_timing", "end"), cfg.set_calls)

    def test_settings_page_update_callbacks_fire(self) -> None:
        cfg = _FakeConfig()
        callback = mock.Mock()
        page = SimpleNamespace(
            _updating=False,
            _config=cfg,
            _on_update_settings_changed=callback,
        )

        SettingsPage._on_auto_update_changed(page, Qt.CheckState.Checked.value)
        SettingsPage._on_interval_changed(page, 6)

        self.assertIn(("updates.auto_update", True), cfg.set_calls)
        self.assertIn(("updates.check_interval_hours", 6), cfg.set_calls)
        self.assertEqual(callback.call_count, 2)

    def test_app_update_timer_reconfigures_live(self) -> None:
        cfg = _FakeConfig({
            "updates.check_interval_hours": "2",
            "updates.auto_update": True,
        })
        timer = _FakeTimer()
        app = SimpleNamespace(_config=cfg, _update_timer=timer)

        PayPerTranscriptApp._apply_update_timer_from_config(app)

        self.assertEqual(timer.interval, 2 * 3600 * 1000)
        self.assertTrue(timer.isActive())
        self.assertEqual(timer.start_calls, 1)

        cfg.values["updates.auto_update"] = False
        cfg.values["updates.check_interval_hours"] = 0
        PayPerTranscriptApp._apply_update_timer_from_config(app)

        self.assertEqual(timer.interval, 1 * 3600 * 1000)
        self.assertFalse(timer.isActive())
        self.assertEqual(timer.stop_calls, 1)

    def test_begin_recording_session_is_blocked_while_processing(self) -> None:
        recorder = SimpleNamespace(
            is_recording=False,
            start_recording=mock.Mock(),
        )
        app = SimpleNamespace(
            _recorder=recorder,
            _is_processing_active=lambda: True,
            _show_busy_feedback=mock.Mock(),
        )

        PayPerTranscriptApp._begin_recording_session(app, "hold")

        recorder.start_recording.assert_not_called()
        app._show_busy_feedback.assert_called_once_with("Verarbeite noch")

    def test_toggle_start_preloads_context_when_configured(self) -> None:
        recorder = SimpleNamespace(is_recording=False, start_recording=mock.Mock())
        app = SimpleNamespace(
            _recorder=recorder,
            _is_processing_active=lambda: False,
            _show_busy_feedback=mock.Mock(),
            _capture_timing_for_mode=lambda _mode: "start",
            _start_context_capture=mock.Mock(),
            _config=_FakeConfig({"general.sound_enabled": False}),
            _audio_manager=SimpleNamespace(play_sound=mock.Mock()),
            _signals=SimpleNamespace(recording_started=_emit_signal()),
            _recording_session=None,
        )

        with mock.patch(
            "paypertranscript.ui.app.get_foreground_window",
            return_value=SimpleNamespace(process_name="notepad.exe", window_title="Notes"),
        ):
            PayPerTranscriptApp._begin_recording_session(app, "toggle")

        recorder.start_recording.assert_called_once()
        app._start_context_capture.assert_called_once()
        self.assertIsNotNone(app._recording_session)
        self.assertEqual(app._recording_session.trigger_mode, "toggle")

    def test_finish_recording_session_uses_existing_context_future(self) -> None:
        future = mock.Mock()
        cancel_event = threading.Event()
        recorder = SimpleNamespace(
            is_recording=True,
            stop_recording=mock.Mock(return_value=[0] * 16000),
            save_wav=mock.Mock(),
        )
        app = SimpleNamespace(
            _recorder=recorder,
            _recording_session=_RecordingSession(
                trigger_mode="toggle",
                window=SimpleNamespace(process_name="notepad.exe", window_title="Notes"),
                context_future=future,
                context_cancel=cancel_event,
            ),
            _config=_FakeConfig({"general.sound_enabled": False}),
            _audio_manager=SimpleNamespace(
                play_sound=mock.Mock(),
                generate_temp_path=mock.Mock(return_value=Path("temp.wav")),
            ),
            _signals=SimpleNamespace(
                recording_stopped=_emit_signal(),
                processing_error=_emit_signal(),
            ),
            _try_begin_processing_job=mock.Mock(return_value=7),
            _finish_processing_job=mock.Mock(),
            _set_active_context_cancel=mock.Mock(),
            _start_context_capture=mock.Mock(),
            _capture_timing_for_mode=lambda _mode: "start",
            _pipeline=SimpleNamespace(process_async=mock.Mock()),
        )

        PayPerTranscriptApp._finish_recording_session(app, "toggle")

        app._start_context_capture.assert_not_called()
        app._set_active_context_cancel.assert_called_once_with(7, cancel_event)
        kwargs = app._pipeline.process_async.call_args.kwargs
        self.assertIs(kwargs["context_future"], future)
        self.assertEqual(app._recording_session, None)

    def test_finish_recording_session_starts_context_at_end(self) -> None:
        created_future = mock.Mock()
        recorder = SimpleNamespace(
            is_recording=True,
            stop_recording=mock.Mock(return_value=[0] * 16000),
            save_wav=mock.Mock(),
        )
        app = SimpleNamespace(
            _recorder=recorder,
            _recording_session=_RecordingSession(
                trigger_mode="hold",
                window=SimpleNamespace(process_name="outlook.exe", window_title="Mail"),
            ),
            _config=_FakeConfig({"general.sound_enabled": False}),
            _audio_manager=SimpleNamespace(
                play_sound=mock.Mock(),
                generate_temp_path=mock.Mock(return_value=Path("temp.wav")),
            ),
            _signals=SimpleNamespace(
                recording_stopped=_emit_signal(),
                processing_error=_emit_signal(),
            ),
            _try_begin_processing_job=mock.Mock(return_value=9),
            _finish_processing_job=mock.Mock(),
            _set_active_context_cancel=mock.Mock(),
            _capture_timing_for_mode=lambda _mode: "end",
            _pipeline=SimpleNamespace(process_async=mock.Mock()),
        )

        def _start_capture(session: _RecordingSession) -> None:
            session.context_future = created_future
            session.context_cancel = threading.Event()

        app._start_context_capture = _start_capture

        PayPerTranscriptApp._finish_recording_session(app, "hold")

        kwargs = app._pipeline.process_async.call_args.kwargs
        self.assertIs(kwargs["context_future"], created_future)
        app._set_active_context_cancel.assert_called_once()

    def test_stale_pipeline_status_is_ignored(self) -> None:
        app = SimpleNamespace(
            _is_job_active=lambda _job_id: False,
            _signals=SimpleNamespace(
                processing_started=_emit_signal(),
                formatting_started=_emit_signal(),
                processing_done=_emit_signal(),
                processing_error=_emit_signal(),
            ),
            _finish_processing_job=mock.Mock(),
        )

        PayPerTranscriptApp._on_pipeline_status(app, 3, STATUS_DONE)

        app._signals.processing_done.emit.assert_not_called()
        app._finish_processing_job.assert_not_called()

    def test_release_notes_are_shown_once_after_update(self) -> None:
        cfg = _FakeConfig({
            "updates.last_seen_version": "0.3.3",
            "updates.pending_release_version": "0.3.5",
            "updates.pending_release_notes": "# Version 0.3.5\n\n- Neues Changelog",
        })
        tray = mock.Mock()
        app = SimpleNamespace(
            _config=cfg,
            _tray=tray,
        )

        PayPerTranscriptApp._maybe_show_release_notes_after_update(app)

        tray.show_release_notes.assert_called_once_with(
            current_version="0.3.5",
            previous_version="0.3.3",
            notes="# Version 0.3.5\n\n- Neues Changelog",
        )
        self.assertEqual(
            cfg.update_calls[-1],
            {
                "updates": {
                    "last_seen_version": "0.3.5",
                    "pending_release_version": "",
                    "pending_release_notes": "",
                }
            },
        )

    def test_manual_update_check_without_update_emits_current_release_notes(self) -> None:
        emit = _emit_signal()
        app = SimpleNamespace(
            _available_update_version="0.3.5",
            _available_update_notes="stale",
            _signals=SimpleNamespace(
                auto_update_requested=_emit_signal(),
                update_available=_emit_signal(),
                update_not_available=emit,
            ),
            _can_auto_install_update=lambda: False,
        )

        with (
            mock.patch("paypertranscript.__version__", "0.3.4"),
            mock.patch(
                "paypertranscript.core.updater.get_latest_release_info",
                return_value=SimpleNamespace(version="0.3.4", notes=""),
            ),
            mock.patch("paypertranscript.core.updater.is_update_available", return_value=False),
            mock.patch("paypertranscript.core.updater.get_release_notes", return_value="# Version 0.3.4"),
        ):
            PayPerTranscriptApp._do_update_check(app, manual=True)

        emit.emit.assert_called_once_with(True, "# Version 0.3.4")
        self.assertEqual(app._available_update_version, "")
        self.assertEqual(app._available_update_notes, "")
