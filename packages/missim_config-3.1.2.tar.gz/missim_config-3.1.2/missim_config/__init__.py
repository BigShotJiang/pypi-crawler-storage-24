# IMPORTANT
# After changing this file, run `missim generate`
# To re-generate the json schemas

from enum import Enum
from typing import Literal
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field
from fluxconf import ConfigIO, VersionedBaseModel


class Mode(str, Enum):
    UE_EDITOR = "ue-editor"
    UE_STANDALONE = "ue-standalone"
    LOW_FIDELITY = "low-fidelity"

    def __str__(self):
        return self.value


class LogLevel(str, Enum):
    INFO = "info"
    DEBUG = "debug"

    def __str__(self):
        return self.value


class AuthCredential(BaseModel):
    username: str = Field(
        description="Username for authentication",
    )
    hashed_password: str = Field(
        description="BCrypt hash of password for authentication",
    )


class Proxy(BaseModel):
    enabled: bool = Field(
        default=True,
        description="Whether the proxy is enabled",
    )
    http_port: int = Field(
        default=80,
        description="HTTP port for the proxy server",
    )
    https_port: int = Field(
        default=443,
        description="HTTPS port for the proxy server",
    )
    auth_credentials: list[AuthCredential] = Field(
        default_factory=list,
        description="List of authentication credentials",
    )


class DiscoverySimple(BaseModel):
    own_ip: str = Field(
        default="0.0.0.0",
        description="IP/host/interface address of the primary network interface. This is where DDS traffic will route to.",
    )


class DiscoveryFastDDS(BaseModel):
    with_discovery_server: bool = Field(
        default=True, description="Run the discovery server. It will bind to 0.0.0.0:11811"
    )
    discovery_server_ip: str = Field(
        default="0.0.0.0",
        description="IP/host/interface of the discovery server. Assumes port of 11811",
    )
    own_ip: str = Field(
        default="0.0.0.0",
        description="IP/host/interface address of the primary network interface. This is where DDS traffic will route to.",
    )


class DiscoveryZenoh(BaseModel):
    with_router: bool = Field(default=True, description="Start the zenoh router")
    router_peers: list[str] = Field(
        default_factory=list,
        description="Remote router IPs/hostnames for mesh peering. Port 7447 is assumed.",
    )
    router_config: dict = Field(
        default_factory=dict,
        description="Override dict deep-merged into the zenoh router config.",
    )
    session_config: dict = Field(
        default_factory=dict,
        description="Override dict deep-merged into the zenoh session config.",
    )


class DiscoveryEasy(BaseModel):
    base_address: str = Field(
        default="127.0.0.1",
        description="Base address for easy discovery",
    )


class Discovery(BaseModel):
    type: Literal["simple", "fastdds", "zenoh", "easy"] = Field(
        default="simple",
        description="Discovery mechanism to use",
    )
    ros_domain_id: int = Field(
        default=0,
        description="ROS domain ID",
    )
    simple: DiscoverySimple = Field(default_factory=DiscoverySimple)
    fastdds: DiscoveryFastDDS = Field(default_factory=DiscoveryFastDDS)
    zenoh: DiscoveryZenoh = Field(default_factory=DiscoveryZenoh)
    easy: DiscoveryEasy = Field(default_factory=DiscoveryEasy)


class MissimConfig(VersionedBaseModel):
    model_config = ConfigDict(
        json_encoders={
            Mode: lambda v: v.value,
            LogLevel: lambda v: v.value,
        },
    )
    log_level: LogLevel = LogLevel.INFO
    mode: Mode = Mode.LOW_FIDELITY
    components: dict = Field(default_factory=dict)
    prod: bool = False
    log_directory: str = "~/greenroom/missim/logs"
    recording_directory: str = "~/greenroom/missim/recordings"
    charts_directory: str = "~/greenroom/charts"
    discovery: Discovery = Field(
        default_factory=Discovery,
    )
    proxy: Proxy = Field(
        default_factory=Proxy,
        description="Proxy configuration",
    )


class MissimConfigIO(ConfigIO[MissimConfig]):
    file_name = "missim.yml"
    config_type = MissimConfig
    schema_url = "https://greenroom-robotics.github.io/missim/schemas/missim.schema.json"
    migrations_dir = Path(__file__).parent / "migrations"
    always_include_fields = ["version"]


config_io = MissimConfigIO(Path.home() / ".config" / "greenroom")
