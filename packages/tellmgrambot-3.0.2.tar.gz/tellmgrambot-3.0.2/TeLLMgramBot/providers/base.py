from abc import ABC, abstractmethod

class ContextLengthExceededError(Exception):
    """Raised when a request exceeds the model's context window."""
    pass

class ProviderAuthError(Exception):
    """Raised when an API key is invalid or missing."""
    pass

class ProviderConnectionError(Exception):
    """Raised when the provider's API cannot be reached."""
    pass

class LLMProvider(ABC):
    """Abstract base class for LLM provider implementations."""

    @abstractmethod
    async def complete(self, model: str, messages: list[dict]) -> str:
        """
        Send messages to the model and return the response text.

        Raises:
            ContextLengthExceededError: if the request exceeds the model's context window.
            ProviderAuthError: if authentication fails.
            ProviderConnectionError: if the API cannot be reached.
        """
        pass

    @abstractmethod
    async def count_tokens(self, model: str, messages: list[dict]) -> int:
        """
        Count the number of tokens in the given messages for the specified model.

        Args:
            model: The model name (e.g., 'gpt-4o', 'claude-sonnet-4-6').
            messages: List of message dictionaries with 'role' and 'content' keys.

        Returns:
            The total token count for the messages.
        """
        pass
