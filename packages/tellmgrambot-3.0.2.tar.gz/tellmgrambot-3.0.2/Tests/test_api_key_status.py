import os
import unittest
from unittest.mock import patch, MagicMock
from TeLLMgramBot.initialize import ApiKeyStatus, init_keys, print_api_key_status, _model_provider

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

TELEGRAM_KEY = 'TELLMGRAMBOT_TELEGRAM_API_KEY'
VIRUSTOTAL_KEY = 'TELLMGRAMBOT_VIRUSTOTAL_API_KEY'
OPENAI_KEY = 'TELLMGRAMBOT_OPENAI_API_KEY'
ANTHROPIC_KEY = 'TELLMGRAMBOT_ANTHROPIC_API_KEY'

BASE_ENV = {
    TELEGRAM_KEY: 'tg-key',
    VIRUSTOTAL_KEY: 'vt-key',
    OPENAI_KEY: 'openai-key',
    ANTHROPIC_KEY: 'anthropic-key',
}

OPENAI_CONFIG = {'chat_model': 'gpt-5-mini', 'url_model': 'gpt-5'}
ANTHROPIC_CONFIG = {'chat_model': 'claude-sonnet-4-6', 'url_model': 'claude-haiku-4-5'}
MIXED_CONFIG = {'chat_model': 'gpt-5-mini', 'url_model': 'claude-haiku-4-5'}

def _make_requires_provider(config: dict):
    """Build a _requires_provider return value from a config dict."""
    needs = {'openai': False, 'anthropic': False}
    for field in ('chat_model', 'url_model'):
        model = config.get(field, '')
        if model.startswith('claude-'):
            needs['anthropic'] = True
        elif model:
            needs['openai'] = True
    return needs

# ---------------------------------------------------------------------------
# _model_provider helper
# ---------------------------------------------------------------------------

class TestModelProvider(unittest.TestCase):
    """Tests for _model_provider() — maps a model name string to its provider name."""

    def test_openai_model(self):
        """A gpt-* model name must return 'openai'."""
        self.assertEqual(_model_provider('gpt-5-mini'), 'openai')

    def test_anthropic_model(self):
        """A claude-* model name must return 'anthropic'."""
        self.assertEqual(_model_provider('claude-sonnet-4-6'), 'anthropic')

    def test_empty_model(self):
        """An empty string must return None (no provider required)."""
        self.assertIsNone(_model_provider(''))

    def test_none_model(self):
        """None must return None (no provider required)."""
        self.assertIsNone(_model_provider(None))

# ---------------------------------------------------------------------------
# ApiKeyStatus defaults
# ---------------------------------------------------------------------------

class TestApiKeyStatusDefaults(unittest.TestCase):
    """Tests for ApiKeyStatus dataclass default values."""

    def test_all_features_enabled_by_default(self):
        """A freshly constructed ApiKeyStatus must have all features enabled and no disabled reasons."""
        fm = ApiKeyStatus()
        self.assertTrue(fm.chat_enabled)
        self.assertTrue(fm.url_analysis_enabled)
        self.assertEqual(fm.disabled_reasons, {})

# ---------------------------------------------------------------------------
# init_keys — all keys present
# ---------------------------------------------------------------------------

class TestInitKeysAllPresent(unittest.TestCase):
    """Tests for init_keys() when all required API keys are present."""

    @patch('TeLLMgramBot.initialize.read_yaml', return_value=OPENAI_CONFIG)
    @patch('TeLLMgramBot.initialize._requires_provider', return_value=_make_requires_provider(OPENAI_CONFIG))
    @patch('TeLLMgramBot.initialize.read_text', return_value='fake-key')
    @patch('TeLLMgramBot.initialize.generate_file_path')
    @patch('os.path.exists', return_value=True)
    def test_all_features_enabled_when_all_keys_present(self, mock_exists, mock_gen, mock_read, mock_req, mock_yaml):
        """All features must be enabled when all API keys are available."""
        with patch.dict(os.environ, BASE_ENV, clear=False):
            fm = init_keys()
        self.assertTrue(fm.chat_enabled)
        self.assertTrue(fm.url_analysis_enabled)
        self.assertEqual(fm.disabled_reasons, {})

# ---------------------------------------------------------------------------
# init_keys — Telegram key missing → sys.exit
# ---------------------------------------------------------------------------

class TestInitKeysTelegramMissing(unittest.TestCase):
    """Tests for init_keys() hard exit when the Telegram key is missing."""

    @patch('TeLLMgramBot.initialize.read_yaml', return_value=OPENAI_CONFIG)
    @patch('TeLLMgramBot.initialize._requires_provider', return_value=_make_requires_provider(OPENAI_CONFIG))
    @patch('TeLLMgramBot.initialize.generate_file_path')
    @patch('os.path.exists', return_value=False)
    def test_exits_when_telegram_key_missing(self, mock_exists, mock_gen, mock_req, mock_yaml):
        """init_keys() must call sys.exit() when the Telegram API key is absent — it is always required."""
        env = {k: v for k, v in BASE_ENV.items() if k != TELEGRAM_KEY}
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop(TELEGRAM_KEY, None)
            with self.assertRaises(SystemExit):
                init_keys()

# ---------------------------------------------------------------------------
# init_keys — provider key missing → feature disabled
# ---------------------------------------------------------------------------

class TestInitKeysProviderMissing(unittest.TestCase):
    """Tests for init_keys() graceful degradation when a provider key (OpenAI/Anthropic) is missing."""

    @patch('TeLLMgramBot.initialize.read_yaml', return_value=OPENAI_CONFIG)
    @patch('TeLLMgramBot.initialize._requires_provider', return_value=_make_requires_provider(OPENAI_CONFIG))
    @patch('TeLLMgramBot.initialize.generate_file_path')
    @patch('os.path.exists', return_value=False)
    def test_chat_disabled_when_openai_key_missing(self, mock_exists, mock_gen, mock_req, mock_yaml):
        """Missing OpenAI key must disable both chat and URL analysis when an OpenAI model is configured."""
        env = {k: v for k, v in BASE_ENV.items() if k != OPENAI_KEY}
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop(OPENAI_KEY, None)
            fm = init_keys()
        self.assertFalse(fm.chat_enabled)
        self.assertFalse(fm.url_analysis_enabled)
        self.assertIn('chat', fm.disabled_reasons)

    @patch('TeLLMgramBot.initialize.read_yaml', return_value=ANTHROPIC_CONFIG)
    @patch('TeLLMgramBot.initialize._requires_provider', return_value=_make_requires_provider(ANTHROPIC_CONFIG))
    @patch('TeLLMgramBot.initialize.generate_file_path')
    @patch('os.path.exists', return_value=False)
    def test_chat_disabled_when_anthropic_key_missing(self, mock_exists, mock_gen, mock_req, mock_yaml):
        """Missing Anthropic key must disable both chat and URL analysis when a Claude model is configured."""
        env = {k: v for k, v in BASE_ENV.items() if k != ANTHROPIC_KEY}
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop(ANTHROPIC_KEY, None)
            fm = init_keys()
        self.assertFalse(fm.chat_enabled)
        self.assertFalse(fm.url_analysis_enabled)
        self.assertIn('chat', fm.disabled_reasons)

    @patch('TeLLMgramBot.initialize.read_yaml', return_value=OPENAI_CONFIG)
    @patch('TeLLMgramBot.initialize._requires_provider', return_value=_make_requires_provider(OPENAI_CONFIG))
    def test_does_not_exit_when_only_provider_key_missing(self, mock_req, mock_yaml):
        """init_keys() must not call sys.exit() when only a provider key is missing — graceful degradation."""
        env = {k: v for k, v in BASE_ENV.items() if k != OPENAI_KEY}
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop(OPENAI_KEY, None)
            with patch('TeLLMgramBot.initialize.generate_file_path'):
                with patch('os.path.exists', return_value=False):
                    try:
                        fm = init_keys()
                    except SystemExit:
                        self.fail("init_keys() should not exit when only a provider key is missing")

# ---------------------------------------------------------------------------
# init_keys — VirusTotal key missing → virustotal + url_analysis disabled
# ---------------------------------------------------------------------------

class TestInitKeysVirusTotalMissing(unittest.TestCase):
    """Tests for init_keys() graceful degradation when the VirusTotal key is missing."""

    @patch('TeLLMgramBot.initialize.read_yaml', return_value=OPENAI_CONFIG)
    @patch('TeLLMgramBot.initialize._requires_provider', return_value=_make_requires_provider(OPENAI_CONFIG))
    @patch('TeLLMgramBot.initialize.generate_file_path')
    @patch('os.path.exists', return_value=False)
    def test_virustotal_and_url_analysis_disabled_when_vt_key_missing(self, mock_exists, mock_gen, mock_req, mock_yaml):
        """Missing VirusTotal key must disable url_analysis while leaving chat enabled."""
        env = {k: v for k, v in BASE_ENV.items() if k != VIRUSTOTAL_KEY}
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop(VIRUSTOTAL_KEY, None)
            fm = init_keys()
        self.assertTrue(fm.chat_enabled)
        self.assertFalse(fm.url_analysis_enabled)
        self.assertIn('url_analysis', fm.disabled_reasons)

# ---------------------------------------------------------------------------
# init_keys — both provider and VirusTotal keys missing
# ---------------------------------------------------------------------------

class TestInitKeysBothProviderAndVTMissing(unittest.TestCase):
    """Tests for init_keys() when both the provider key and VirusTotal key are missing."""

    @patch('TeLLMgramBot.initialize.read_yaml', return_value=OPENAI_CONFIG)
    @patch('TeLLMgramBot.initialize._requires_provider', return_value=_make_requires_provider(OPENAI_CONFIG))
    @patch('TeLLMgramBot.initialize.generate_file_path')
    @patch('os.path.exists', return_value=False)
    def test_url_analysis_disabled_when_both_provider_and_vt_keys_missing(self, mock_exists, mock_gen, mock_req, mock_yaml):
        """When both the provider key and VirusTotal key are missing, url_analysis must be disabled with the provider key cited as the reason."""
        env = {k: v for k, v in BASE_ENV.items() if k not in (OPENAI_KEY, VIRUSTOTAL_KEY)}
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop(OPENAI_KEY, None)
            os.environ.pop(VIRUSTOTAL_KEY, None)
            fm = init_keys()
        self.assertFalse(fm.chat_enabled)
        self.assertFalse(fm.url_analysis_enabled)
        self.assertIn('openai', fm.disabled_reasons.get('url_analysis', ''))

# ---------------------------------------------------------------------------
# print_api_key_status output
# ---------------------------------------------------------------------------

class TestPrintApiKeyStatus(unittest.TestCase):
    """Tests for print_api_key_status() startup output formatting."""

    def test_all_enabled_output(self):
        """When all features are enabled, output must contain ENABLED and no DISABLED lines."""
        fm = ApiKeyStatus()
        with patch('builtins.print') as mock_print:
            print_api_key_status(fm)
        output = ' '.join(str(c) for c in [call.args[0] for call in mock_print.call_args_list])
        self.assertIn('ENABLED', output)
        self.assertNotIn('DISABLED', output)

    def test_disabled_feature_shows_reason(self):
        """A disabled feature must appear as DISABLED with its reason string in the output."""
        fm = ApiKeyStatus(
            chat_enabled=False,
            disabled_reasons={'chat': 'missing openai API key'}
        )
        with patch('builtins.print') as mock_print:
            print_api_key_status(fm)
        output = ' '.join(str(call.args[0]) for call in mock_print.call_args_list)
        self.assertIn('DISABLED', output)
        self.assertIn('missing openai API key', output)

if __name__ == '__main__':
    unittest.main()
