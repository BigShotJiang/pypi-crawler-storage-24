import os
import unittest
import openai
import anthropic
from unittest.mock import AsyncMock, MagicMock, patch
from TeLLMgramBot.providers.base import (
    ContextLengthExceededError,
    ProviderAuthError,
    ProviderConnectionError,
)
from TeLLMgramBot.providers.factory import get_provider
from TeLLMgramBot.providers.openai_provider import OpenAIProvider
from TeLLMgramBot.providers.anthropic_provider import AnthropicProvider
from TeLLMgramBot.initialize import _requires_provider

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _reset_factory():
    """Clear the factory's singleton cache between tests."""
    import TeLLMgramBot.providers.factory as _factory
    _factory._providers.clear()

def _reset_provider_clients():
    """Reset class-level singleton clients so each test starts clean."""
    OpenAIProvider._client = None
    OpenAIProvider._encodings = {}
    AnthropicProvider._client = None

# ---------------------------------------------------------------------------
# Provider factory routing
# ---------------------------------------------------------------------------

class TestProviderFactoryRouting(unittest.TestCase):
    """Tests for get_provider() routing logic in factory.py."""

    def setUp(self):
        _reset_factory()
        _reset_provider_clients()

    def test_claude_prefix_returns_anthropic_provider(self):
        """claude-* model names must route to AnthropicProvider."""
        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            provider = get_provider('claude-sonnet-4-6')
        self.assertIsInstance(provider, AnthropicProvider)

    def test_claude_opus_prefix_returns_anthropic_provider(self):
        """Any claude- variant must route to AnthropicProvider."""
        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            provider = get_provider('claude-opus-4-6')
        self.assertIsInstance(provider, AnthropicProvider)

    def test_gpt_prefix_returns_openai_provider(self):
        """gpt-* model names must route to OpenAIProvider."""
        with patch.dict(os.environ, {'TELLMGRAMBOT_OPENAI_API_KEY': 'test-key'}):
            provider = get_provider('gpt-4o')
        self.assertIsInstance(provider, OpenAIProvider)

    def test_unknown_prefix_returns_openai_provider(self):
        """Non-claude model names must default to OpenAIProvider."""
        with patch.dict(os.environ, {'TELLMGRAMBOT_OPENAI_API_KEY': 'test-key'}):
            provider = get_provider('some-other-model')
        self.assertIsInstance(provider, OpenAIProvider)

    def test_anthropic_singleton_same_instance_returned(self):
        """Repeated calls for claude-* models must return the same instance."""
        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            p1 = get_provider('claude-sonnet-4-6')
            p2 = get_provider('claude-haiku-4-5')
        self.assertIs(p1, p2)

    def test_openai_singleton_same_instance_returned(self):
        """Repeated calls for gpt-* models must return the same instance."""
        with patch.dict(os.environ, {'TELLMGRAMBOT_OPENAI_API_KEY': 'test-key'}):
            p1 = get_provider('gpt-4o')
            p2 = get_provider('gpt-5')
        self.assertIs(p1, p2)

    def test_anthropic_and_openai_are_different_instances(self):
        """Anthropic and OpenAI providers must be distinct objects."""
        with patch.dict(os.environ, {
            'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key',
            'TELLMGRAMBOT_OPENAI_API_KEY': 'test-key',
        }):
            ap = get_provider('claude-sonnet-4-6')
            op = get_provider('gpt-4o')
        self.assertIsNot(ap, op)

# ---------------------------------------------------------------------------
# ContextLengthExceededError
# ---------------------------------------------------------------------------

class TestContextLengthExceededError(unittest.IsolatedAsyncioTestCase):
    """Verify ContextLengthExceededError is raised by each provider's complete()."""

    def setUp(self):
        _reset_provider_clients()

    async def test_openai_raises_context_length_exceeded(self):
        """OpenAIProvider.complete() must raise ContextLengthExceededError on context overflow."""
        provider = OpenAIProvider()
        bad_request = openai.BadRequestError(
            message="maximum context length exceeded reduce the length of messages",
            response=MagicMock(status_code=400, headers={}),
            body={'error': {'message': 'maximum context length exceeded reduce the length of messages'}},
        )

        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(side_effect=bad_request)

        with patch.dict(os.environ, {'TELLMGRAMBOT_OPENAI_API_KEY': 'test-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                with self.assertRaises(ContextLengthExceededError):
                    await provider.complete('gpt-4o', [{'role': 'user', 'content': 'hi'}])

    async def test_openai_unrelated_bad_request_not_swallowed(self):
        """OpenAIProvider.complete() must re-raise non-context BadRequestError as-is."""
        provider = OpenAIProvider()
        bad_request = openai.BadRequestError(
            message="content policy violation",
            response=MagicMock(status_code=400, headers={}),
            body={'error': {'message': 'content policy violation'}},
        )

        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(side_effect=bad_request)

        with patch.dict(os.environ, {'TELLMGRAMBOT_OPENAI_API_KEY': 'test-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                with self.assertRaises(openai.BadRequestError):
                    await provider.complete('gpt-4o', [{'role': 'user', 'content': 'hi'}])

    async def test_anthropic_raises_context_length_exceeded_on_too_long(self):
        """AnthropicProvider.complete() must raise ContextLengthExceededError when error says 'too long'."""
        provider = AnthropicProvider()
        bad_request = anthropic.BadRequestError(
            message="prompt is too long",
            response=MagicMock(status_code=400, headers={}),
            body={'type': 'error', 'error': {'type': 'invalid_request_error', 'message': 'prompt is too long'}},
        )

        mock_client = MagicMock()
        mock_client.messages.create = AsyncMock(side_effect=bad_request)

        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                with self.assertRaises(ContextLengthExceededError):
                    await provider.complete('claude-sonnet-4-6', [{'role': 'user', 'content': 'hi'}])

    async def test_anthropic_raises_context_length_exceeded_on_context(self):
        """AnthropicProvider.complete() must raise ContextLengthExceededError when error says 'context'."""
        provider = AnthropicProvider()
        bad_request = anthropic.BadRequestError(
            message="context window exceeded",
            response=MagicMock(status_code=400, headers={}),
            body={'type': 'error', 'error': {'type': 'invalid_request_error', 'message': 'context window exceeded'}},
        )

        mock_client = MagicMock()
        mock_client.messages.create = AsyncMock(side_effect=bad_request)

        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                with self.assertRaises(ContextLengthExceededError):
                    await provider.complete('claude-sonnet-4-6', [{'role': 'user', 'content': 'hi'}])

# ---------------------------------------------------------------------------
# AnthropicProvider system message extraction
# ---------------------------------------------------------------------------

class TestAnthropicSystemMessageExtraction(unittest.IsolatedAsyncioTestCase):
    """Verify that system messages are extracted and passed as the system= param."""

    def setUp(self):
        _reset_provider_clients()
        self.provider = AnthropicProvider()
        mock_content = MagicMock()
        mock_content.type = 'text'
        mock_content.text = 'response'
        mock_response = MagicMock()
        mock_response.content = [mock_content]
        self.mock_client = MagicMock()
        self.mock_client.messages.create = AsyncMock(return_value=mock_response)

    async def test_system_message_extracted_from_messages(self):
        """System role messages must be passed as system= param, not in messages list."""
        messages = [
            {'role': 'system', 'content': 'You are a helpful assistant.'},
            {'role': 'user', 'content': 'Hello'},
        ]

        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            with patch.object(self.provider, '_get_client', return_value=self.mock_client):
                await self.provider.complete('claude-sonnet-4-6', messages)

        call_kwargs = self.mock_client.messages.create.call_args.kwargs
        self.assertEqual(call_kwargs.get('system'), 'You are a helpful assistant.')
        for msg in call_kwargs.get('messages', []):
            self.assertNotEqual(msg.get('role'), 'system')

    async def test_non_system_messages_pass_through_unchanged(self):
        """User and assistant messages must be forwarded to the API unmodified."""
        messages = [
            {'role': 'user', 'content': 'Tell me a joke'},
            {'role': 'assistant', 'content': 'Why did the chicken...'},
            {'role': 'user', 'content': 'Ha! Another one?'},
        ]

        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            with patch.object(self.provider, '_get_client', return_value=self.mock_client):
                await self.provider.complete('claude-sonnet-4-6', messages)

        call_kwargs = self.mock_client.messages.create.call_args.kwargs
        self.assertEqual(call_kwargs['messages'], messages)
        self.assertNotIn('system', call_kwargs)

    async def test_no_system_key_passed_when_no_system_message(self):
        """When messages contain no system role, system= must not be included in the API call."""
        messages = [{'role': 'user', 'content': 'Ping'}]

        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            with patch.object(self.provider, '_get_client', return_value=self.mock_client):
                await self.provider.complete('claude-sonnet-4-6', messages)

        call_kwargs = self.mock_client.messages.create.call_args.kwargs
        self.assertNotIn('system', call_kwargs)

    async def test_count_tokens_extracts_system_message(self):
        """count_tokens() must also extract system messages per Anthropic API design."""
        provider = AnthropicProvider()

        mock_token_response = MagicMock()
        mock_token_response.input_tokens = 42

        mock_beta = MagicMock()
        mock_beta.messages.count_tokens = AsyncMock(return_value=mock_token_response)
        mock_client = MagicMock()
        mock_client.beta = mock_beta

        messages = [
            {'role': 'system', 'content': 'Be concise.'},
            {'role': 'user', 'content': 'Hi'},
        ]

        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                token_count = await provider.count_tokens('claude-sonnet-4-6', messages)

        self.assertEqual(token_count, 42)
        call_kwargs = mock_client.beta.messages.count_tokens.call_args.kwargs
        self.assertEqual(call_kwargs.get('system'), 'Be concise.')
        for msg in call_kwargs.get('messages', []):
            self.assertNotEqual(msg.get('role'), 'system')

# ---------------------------------------------------------------------------
# OpenAI provider error mapping
# ---------------------------------------------------------------------------

class TestOpenAIProviderErrorMapping(unittest.IsolatedAsyncioTestCase):
    """Auth and connection errors from OpenAI must map to shared provider exceptions."""

    def setUp(self):
        _reset_provider_clients()

    async def test_auth_error_maps_to_provider_auth_error(self):
        """openai.AuthenticationError must be raised as ProviderAuthError."""
        provider = OpenAIProvider()
        auth_err = openai.AuthenticationError(
            message="Incorrect API key provided",
            response=MagicMock(status_code=401, headers={}),
            body={'error': {'message': 'Incorrect API key provided', 'type': 'invalid_request_error'}},
        )

        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(side_effect=auth_err)

        with patch.dict(os.environ, {'TELLMGRAMBOT_OPENAI_API_KEY': 'bad-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                with self.assertRaises(ProviderAuthError):
                    await provider.complete('gpt-4o', [{'role': 'user', 'content': 'hi'}])

    async def test_connection_error_maps_to_provider_connection_error(self):
        """openai.APIConnectionError must be raised as ProviderConnectionError."""
        provider = OpenAIProvider()
        conn_err = openai.APIConnectionError(request=MagicMock())

        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(side_effect=conn_err)

        with patch.dict(os.environ, {'TELLMGRAMBOT_OPENAI_API_KEY': 'test-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                with self.assertRaises(ProviderConnectionError):
                    await provider.complete('gpt-4o', [{'role': 'user', 'content': 'hi'}])

    def test_missing_api_key_raises_provider_auth_error(self):
        """Calling _get_client() with no API key env var must raise ProviderAuthError."""
        provider = OpenAIProvider()
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(ProviderAuthError):
                provider._get_client()

# ---------------------------------------------------------------------------
# Anthropic provider error mapping
# ---------------------------------------------------------------------------

class TestAnthropicProviderErrorMapping(unittest.IsolatedAsyncioTestCase):
    """Auth and connection errors from Anthropic must map to shared provider exceptions."""

    def setUp(self):
        _reset_provider_clients()

    async def test_auth_error_maps_to_provider_auth_error(self):
        """anthropic.AuthenticationError must be raised as ProviderAuthError."""
        provider = AnthropicProvider()
        auth_err = anthropic.AuthenticationError(
            message="Invalid API key",
            response=MagicMock(status_code=401, headers={}),
            body={'type': 'error', 'error': {'type': 'authentication_error', 'message': 'Invalid API key'}},
        )

        mock_client = MagicMock()
        mock_client.messages.create = AsyncMock(side_effect=auth_err)

        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'bad-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                with self.assertRaises(ProviderAuthError):
                    await provider.complete('claude-sonnet-4-6', [{'role': 'user', 'content': 'hi'}])

    async def test_connection_error_maps_to_provider_connection_error(self):
        """anthropic.APIConnectionError must be raised as ProviderConnectionError."""
        provider = AnthropicProvider()
        conn_err = anthropic.APIConnectionError(request=MagicMock())

        mock_client = MagicMock()
        mock_client.messages.create = AsyncMock(side_effect=conn_err)

        with patch.dict(os.environ, {'TELLMGRAMBOT_ANTHROPIC_API_KEY': 'test-key'}):
            with patch.object(provider, '_get_client', return_value=mock_client):
                with self.assertRaises(ProviderConnectionError):
                    await provider.complete('claude-sonnet-4-6', [{'role': 'user', 'content': 'hi'}])

    def test_missing_api_key_raises_provider_auth_error(self):
        """Calling _get_client() with no API key env var must raise ProviderAuthError."""
        provider = AnthropicProvider()
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(ProviderAuthError):
                provider._get_client()

# ---------------------------------------------------------------------------
# _requires_provider() in initialize.py
# ---------------------------------------------------------------------------

class TestRequiresProvider(unittest.TestCase):
    """Tests for _requires_provider() config-reading logic in initialize.py."""

    def test_claude_chat_model_requires_anthropic(self):
        """A claude-* chat_model must require only the anthropic key."""
        config = {'chat_model': 'claude-sonnet-4-6', 'url_model': ''}
        with patch('TeLLMgramBot.initialize.read_yaml', return_value=config):
            result = _requires_provider('/fake/config.yaml')
        self.assertTrue(result['anthropic'])
        self.assertFalse(result['openai'])

    def test_gpt_chat_model_requires_openai(self):
        """A gpt-* chat_model must require only the openai key."""
        config = {'chat_model': 'gpt-4o', 'url_model': ''}
        with patch('TeLLMgramBot.initialize.read_yaml', return_value=config):
            result = _requires_provider('/fake/config.yaml')
        self.assertTrue(result['openai'])
        self.assertFalse(result['anthropic'])

    def test_mixed_models_requires_both(self):
        """One claude-* and one gpt-* model must require both provider keys."""
        config = {'chat_model': 'claude-sonnet-4-6', 'url_model': 'gpt-4o'}
        with patch('TeLLMgramBot.initialize.read_yaml', return_value=config):
            result = _requires_provider('/fake/config.yaml')
        self.assertTrue(result['openai'])
        self.assertTrue(result['anthropic'])

    def test_both_claude_models_requires_only_anthropic(self):
        """When both models are claude-*, only anthropic is required."""
        config = {'chat_model': 'claude-sonnet-4-6', 'url_model': 'claude-haiku-4-5'}
        with patch('TeLLMgramBot.initialize.read_yaml', return_value=config):
            result = _requires_provider('/fake/config.yaml')
        self.assertTrue(result['anthropic'])
        self.assertFalse(result['openai'])

    def test_both_gpt_models_requires_only_openai(self):
        """When both models are gpt-*, only openai is required."""
        config = {'chat_model': 'gpt-4o', 'url_model': 'gpt-5'}
        with patch('TeLLMgramBot.initialize.read_yaml', return_value=config):
            result = _requires_provider('/fake/config.yaml')
        self.assertTrue(result['openai'])
        self.assertFalse(result['anthropic'])

    def test_missing_config_falls_back_to_both(self):
        """An unreadable config must fall back to requiring both provider keys."""
        with patch('TeLLMgramBot.initialize.read_yaml', side_effect=FileNotFoundError):
            result = _requires_provider('/nonexistent/config.yaml')
        self.assertTrue(result['openai'])
        self.assertTrue(result['anthropic'])

    def test_empty_config_requires_neither(self):
        """An empty config dict (no model fields) must not require either provider."""
        with patch('TeLLMgramBot.initialize.read_yaml', return_value={}):
            result = _requires_provider('/fake/config.yaml')
        self.assertFalse(result['openai'])
        self.assertFalse(result['anthropic'])

    def test_none_config_falls_back_to_neither(self):
        """A config that returns None (empty file) must not require either provider (no exception)."""
        with patch('TeLLMgramBot.initialize.read_yaml', return_value=None):
            result = _requires_provider('/fake/config.yaml')
        self.assertFalse(result['openai'])
        self.assertFalse(result['anthropic'])

if __name__ == '__main__':
    unittest.main()
