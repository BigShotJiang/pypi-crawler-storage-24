"""
Unit tests for Conversation class with SQLite database backing.

Tests cover database initialization, message insertion/loading, deletion, private mode management,
and Conversation class integration with the database layer.
"""
import os
import tempfile
import unittest
from unittest.mock import AsyncMock, patch
import TeLLMgramBot.database as database
from TeLLMgramBot.conversation import Conversation

def _use_temp_db(test_instance):
    """Create a temporary DB file and point the database module at it for test isolation."""
    tmp = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
    tmp.close()
    test_instance._db_file = tmp.name
    database._DB_PATH = tmp.name

def _cleanup_temp_db(test_instance):
    """Reset database module and delete temporary DB file."""
    database._DB_PATH = None
    try:
        os.unlink(test_instance._db_file)
    except OSError:
        pass

# ---------------------------------------------------------------------------
# Database initialisation
# ---------------------------------------------------------------------------

class TestDatabaseInit(unittest.IsolatedAsyncioTestCase):
    """Tests for database initialization and schema creation."""

    def setUp(self):
        _use_temp_db(self)

    def tearDown(self):
        _cleanup_temp_db(self)

    async def test_init_db_creates_messages_table(self):
        await database.init_db()
        import aiosqlite
        async with aiosqlite.connect(self._db_file) as db:
            async with db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='messages'"
            ) as cur:
                row = await cur.fetchone()
        self.assertIsNotNone(row)

    async def test_init_db_creates_private_mode_table(self):
        await database.init_db()
        import aiosqlite
        async with aiosqlite.connect(self._db_file) as db:
            async with db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='private_mode'"
            ) as cur:
                row = await cur.fetchone()
        self.assertIsNotNone(row)

    async def test_init_db_is_idempotent(self):
        await database.init_db()
        await database.init_db()  # second call must not raise

# ---------------------------------------------------------------------------
# Insert and load messages
# ---------------------------------------------------------------------------

class TestDatabaseInsertLoad(unittest.IsolatedAsyncioTestCase):
    """Tests for message insertion and loading from database."""

    def setUp(self):
        _use_temp_db(self)

    def tearDown(self):
        _cleanup_temp_db(self)

    async def asyncSetUp(self):
        await database.init_db()

    async def test_insert_and_load_round_trip(self):
        await database.insert_message(100, 1, 'alice', 'user', 'Hello')
        rows = await database.load_messages_for_chat(100)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0], {'role': 'user', 'content': 'Hello'})

    async def test_load_returns_chronological_order(self):
        await database.insert_message(200, 1, 'alice', 'user', 'First')
        await database.insert_message(200, 2, 'bot', 'assistant', 'Second')
        rows = await database.load_messages_for_chat(200)
        self.assertEqual([r['content'] for r in rows], ['First', 'Second'])

    async def test_load_excludes_private_when_flag_set(self):
        await database.insert_message(300, 1, 'alice', 'user', 'Public msg')
        await database.insert_message(300, 1, 'alice', 'user', 'Private msg', is_private=True)
        rows = await database.load_messages_for_chat(300, exclude_private=True)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['content'], 'Public msg')

    async def test_load_includes_private_when_flag_not_set(self):
        await database.insert_message(400, 1, 'alice', 'user', 'Public msg')
        await database.insert_message(400, 1, 'alice', 'user', 'Private msg', is_private=True)
        rows = await database.load_messages_for_chat(400)
        self.assertEqual(len(rows), 2)

    async def test_load_empty_chat_returns_empty_list(self):
        rows = await database.load_messages_for_chat(999)
        self.assertEqual(rows, [])

    async def test_load_messages_for_user_uses_user_id_as_chat_id(self):
        # Private chat: chat_id == user_id
        await database.insert_message(42, 42, 'alice', 'user', 'Private hello')
        rows = await database.load_messages_for_user(42)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['content'], 'Private hello')

    async def test_load_messages_for_user_excludes_private(self):
        await database.insert_message(77, 77, 'bob', 'user', 'Not secret')
        await database.insert_message(77, 77, 'bob', 'user', 'Secret', is_private=True)
        rows = await database.load_messages_for_user(77, exclude_private=True)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['content'], 'Not secret')

    async def test_multiple_users_in_group_all_loaded(self):
        group_chat_id = -100
        await database.insert_message(group_chat_id, 1, 'alice', 'user', 'Alice says hi')
        await database.insert_message(group_chat_id, 2, 'bob', 'user', 'Bob says hello')
        rows = await database.load_messages_for_chat(group_chat_id)
        self.assertEqual(len(rows), 2)

# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------

class TestDatabaseDelete(unittest.IsolatedAsyncioTestCase):
    """Tests for message deletion by user_id across all chats."""

    def setUp(self):
        _use_temp_db(self)

    def tearDown(self):
        _cleanup_temp_db(self)

    async def asyncSetUp(self):
        await database.init_db()

    async def test_delete_for_user_removes_only_that_user(self):
        group = -200
        await database.insert_message(group, 1, 'alice', 'user', 'Alice msg')
        await database.insert_message(group, 2, 'bob', 'user', 'Bob msg')
        await database.delete_messages_for_user(1)
        rows = await database.load_messages_for_chat(group)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['content'], 'Bob msg')

    async def test_delete_for_user_removes_across_all_chats(self):
        await database.insert_message(100, 5, 'eve', 'user', 'Private msg')
        await database.insert_message(-500, 5, 'eve', 'user', 'Group msg')
        await database.delete_messages_for_user(5)
        private_rows = await database.load_messages_for_chat(100)
        group_rows = await database.load_messages_for_chat(-500)
        self.assertEqual(private_rows, [])
        self.assertEqual(group_rows, [])

# ---------------------------------------------------------------------------
# Private mode
# ---------------------------------------------------------------------------

class TestDatabasePrivateMode(unittest.IsolatedAsyncioTestCase):
    """Tests for per-user private mode state management."""

    def setUp(self):
        _use_temp_db(self)

    def tearDown(self):
        _cleanup_temp_db(self)

    async def asyncSetUp(self):
        await database.init_db()

    async def test_get_private_mode_default_false(self):
        result = await database.get_private_mode(999)
        self.assertFalse(result)

    async def test_set_private_mode_on(self):
        await database.set_private_mode(1, True)
        self.assertTrue(await database.get_private_mode(1))

    async def test_set_private_mode_off(self):
        await database.set_private_mode(1, True)
        await database.set_private_mode(1, False)
        self.assertFalse(await database.get_private_mode(1))

    async def test_private_mode_upsert_does_not_duplicate(self):
        await database.set_private_mode(10, True)
        await database.set_private_mode(10, False)
        await database.set_private_mode(10, True)
        import aiosqlite
        async with aiosqlite.connect(self._db_file) as db:
            async with db.execute(
                "SELECT COUNT(*) FROM private_mode WHERE user_id = 10"
            ) as cur:
                row = await cur.fetchone()
        self.assertEqual(row[0], 1)

    async def test_private_mode_independent_per_user(self):
        await database.set_private_mode(1, True)
        await database.set_private_mode(2, False)
        self.assertTrue(await database.get_private_mode(1))
        self.assertFalse(await database.get_private_mode(2))

# ---------------------------------------------------------------------------
# Conversation class — DB-backed behaviour
# ---------------------------------------------------------------------------

def _make_conversation(chat_id: int, chat_type: str = 'private') -> Conversation:
    """Create a test Conversation with a dummy system prompt. TokenLimits and error logging are mocked."""
    return Conversation(chat_id, chat_type, 'You are a test bot.', 'gpt-4o-mini')

class TestConversationDbBacked(unittest.IsolatedAsyncioTestCase):
    """Tests for Conversation class integration with SQLite database backing."""

    def setUp(self):
        _use_temp_db(self)
        # Patch generate_error_path so Conversation.__init__ does not need TELLMGRAMBOT_ERRORLOGS_PATH
        self._ep_patcher = patch('TeLLMgramBot.conversation.generate_error_path', return_value='/dev/null')
        self._ep_patcher.start()
        # Patch TokenLimits so Conversation.__init__ does not need TELLMGRAMBOT_CONFIGS_PATH
        self._tgpt_patcher = patch('TeLLMgramBot.conversation.TokenLimits')
        self._tgpt_patcher.start()

    def tearDown(self):
        self._tgpt_patcher.stop()
        self._ep_patcher.stop()
        _cleanup_temp_db(self)

    async def asyncSetUp(self):
        await database.init_db()

    def _token_mock(self, return_value: int):
        """Return a patcher that makes get_message_token_count return a fixed int."""
        return patch.object(Conversation, 'get_message_token_count', new_callable=AsyncMock, return_value=return_value)

    async def test_add_user_message_persists_to_db(self):
        conv = _make_conversation(10)
        with self._token_mock(50):
            await conv.add_user_message('Hello', user_id=1, username='alice')
        rows = await database.load_messages_for_chat(10)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0], {'role': 'user', 'content': 'Hello'})

    async def test_add_user_message_appends_to_memory(self):
        conv = _make_conversation(11)
        with self._token_mock(50):
            await conv.add_user_message('Hi', user_id=1, username='alice')
        self.assertEqual(len(conv.messages), 2)
        self.assertEqual(conv.messages[1], {'role': 'user', 'content': 'Hi'})

    async def test_add_user_message_private_flag(self):
        conv = _make_conversation(12)
        with self._token_mock(50):
            await conv.add_user_message('Secret', user_id=1, username='alice', is_private=True)
        rows = await database.load_messages_for_chat(12, exclude_private=True)
        self.assertEqual(rows, [])

    async def test_add_assistant_message_persists_to_db(self):
        conv = _make_conversation(20)
        with self._token_mock(50):
            await conv.add_assistant_message('Hello back', bot_user_id=99, bot_username='test_bot')
        rows = await database.load_messages_for_chat(20)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0], {'role': 'assistant', 'content': 'Hello back'})

    async def test_get_past_interaction_loads_from_db(self):
        await database.insert_message(30, 1, 'alice', 'user', 'Old message')
        await database.insert_message(30, 99, 'bot', 'assistant', 'Old reply')
        conv = _make_conversation(30)
        with self._token_mock(100):
            result = await conv.get_past_interaction(500, user_id=1)
        self.assertTrue(result)
        self.assertTrue(conv._has_past_interaction)
        self.assertEqual(len(conv.messages), 3)  # system + 2 loaded

    async def test_get_past_interaction_empty_returns_false(self):
        conv = _make_conversation(31)
        with self._token_mock(0):
            result = await conv.get_past_interaction(500, user_id=1)
        self.assertFalse(result)
        self.assertEqual(len(conv.messages), 1)  # system only

    async def test_get_past_interaction_respects_token_limit(self):
        # Insert 3 messages; loading is newest-first so Msg 3 is tried first
        await database.insert_message(40, 1, 'alice', 'user', 'Msg 1')
        await database.insert_message(40, 99, 'bot', 'assistant', 'Msg 2')
        await database.insert_message(40, 1, 'alice', 'user', 'Msg 3')
        conv = _make_conversation(40)
        # token count = len(conv.messages) * 100
        # system(1) + Msg3(1) = 2 msgs = 200 tokens < 250 → fits
        # system(1) + Msg3(1) + Msg2(1) = 3 msgs = 300 tokens > 250 → blocked
        async def dynamic_token_count():
            return len(conv.messages) * 100
        with patch.object(Conversation, 'get_message_token_count', side_effect=dynamic_token_count):
            result = await conv.get_past_interaction(250, user_id=1)
        self.assertTrue(result)
        # Only Msg3 (newest) fits: system + Msg3 = 2 messages
        self.assertEqual(len(conv.messages), 2)

    async def test_get_past_interaction_group_excludes_private(self):
        await database.insert_message(-100, 1, 'alice', 'user', 'Group msg')
        await database.insert_message(-100, 1, 'alice', 'user', 'Private msg', is_private=True)
        conv = _make_conversation(-100, chat_type='group')
        with self._token_mock(100):
            await conv.get_past_interaction(500, user_id=1)
        # Only the non-private message should be loaded
        contents = [m['content'] for m in conv.messages if m['role'] != 'system']
        self.assertIn('Group msg', contents)
        self.assertNotIn('Private msg', contents)

    async def test_get_past_interaction_private_chat_includes_private(self):
        # Private chat: chat_id == user_id == 5
        await database.insert_message(5, 5, 'alice', 'user', 'Normal msg')
        await database.insert_message(5, 5, 'alice', 'user', 'Private msg', is_private=True)
        conv = _make_conversation(5, chat_type='private')
        with self._token_mock(100):
            await conv.get_past_interaction(500, user_id=5)
        contents = [m['content'] for m in conv.messages if m['role'] != 'system']
        self.assertIn('Normal msg', contents)
        self.assertIn('Private msg', contents)

    async def test_get_past_interaction_idempotent(self):
        await database.insert_message(50, 1, 'alice', 'user', 'Hello')
        conv = _make_conversation(50)
        with self._token_mock(100):
            await conv.get_past_interaction(500, user_id=1)
            msg_count_first = len(conv.messages)
            await conv.get_past_interaction(500, user_id=1)
            msg_count_second = len(conv.messages)
        self.assertEqual(msg_count_first, msg_count_second)

    async def test_clear_interaction_resets_memory(self):
        conv = _make_conversation(60)
        with self._token_mock(50):
            await conv.add_user_message('Hi', user_id=1, username='alice')
        await conv.clear_interaction(user_id=1)
        self.assertEqual(len(conv.messages), 1)
        self.assertFalse(conv._has_past_interaction)

    async def test_clear_interaction_deletes_user_db_rows(self):
        # Use a group chat: only the user's rows are removed, bot rows remain
        conv = _make_conversation(-70, chat_type='group')
        with self._token_mock(50):
            await conv.add_user_message('Hi', user_id=1, username='alice')
            await conv.add_assistant_message('Hello', bot_user_id=99, bot_username='bot')
        await conv.clear_interaction(user_id=1)
        # User's row gone; assistant row (user_id=99) still present
        rows = await database.load_messages_for_chat(-70)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['role'], 'assistant')

    async def test_clear_interaction_private_chat_wipes_all_rows(self):
        # Private chat: all messages (user + bot) are deleted
        conv = _make_conversation(71, chat_type='private')
        with self._token_mock(50):
            await conv.add_user_message('Hi', user_id=1, username='alice')
            await conv.add_assistant_message('Hello', bot_user_id=99, bot_username='bot')
        await conv.clear_interaction(user_id=1)
        rows = await database.load_messages_for_chat(71)
        self.assertEqual(len(rows), 0)

    async def test_prune_conversation_only_affects_memory(self):
        await database.insert_message(80, 1, 'alice', 'user', 'Msg A')
        await database.insert_message(80, 99, 'bot', 'assistant', 'Msg B')
        conv = _make_conversation(80)
        with self._token_mock(100):
            await conv.get_past_interaction(500, user_id=1)
        self.assertEqual(len(conv.messages), 3)
        # Prune with a very tight limit — forces removal from memory
        call_count = 0
        async def shrinking_count():
            nonlocal call_count
            call_count += 1
            return max(0, 300 - call_count * 150)
        with patch.object(Conversation, 'get_message_token_count', side_effect=shrinking_count):
            await conv.prune_conversation(50)
        # Memory shrunk; DB unchanged
        db_rows = await database.load_messages_for_chat(80)
        self.assertEqual(len(db_rows), 2)

# ---------------------------------------------------------------------------
# Bidirectional cross-pollination — load_full_user_context
# ---------------------------------------------------------------------------

class TestBidirectionalContext(unittest.IsolatedAsyncioTestCase):
    """Tests for load_full_user_context bidirectional cross-pollination behaviour."""

    def setUp(self):
        _use_temp_db(self)

    def tearDown(self):
        _cleanup_temp_db(self)

    async def asyncSetUp(self):
        await database.init_db()

    async def test_private_history_included_in_group_context(self):
        """User's private messages appear when loading group context."""
        user_id = 10
        private_chat_id = user_id  # Telegram guarantee: private chat_id == user_id
        group_chat_id = -999
        await database.insert_message(private_chat_id, user_id, 'alice', 'user', 'Private thought')
        await database.insert_message(group_chat_id, user_id, 'alice', 'user', 'Group hello')
        rows = await database.load_full_user_context(user_id, group_chat_id)
        contents = [r['content'] for r in rows]
        self.assertIn('Private thought', contents)
        self.assertIn('Group hello', contents)

    async def test_group_history_included_in_private_context(self):
        """User's group messages appear when loading private context."""
        user_id = 20
        private_chat_id = user_id
        group_chat_id = -888
        await database.insert_message(group_chat_id, user_id, 'bob', 'user', 'Group memory')
        await database.insert_message(private_chat_id, user_id, 'bob', 'user', 'Private question')
        rows = await database.load_full_user_context(user_id, private_chat_id)
        contents = [r['content'] for r in rows]
        self.assertIn('Group memory', contents)
        self.assertIn('Private question', contents)

    async def test_other_users_group_messages_included(self):
        """Other users' messages in the current group are included for context."""
        user_id = 30
        group_chat_id = -777
        await database.insert_message(group_chat_id, user_id, 'carol', 'user', 'Carol msg')
        await database.insert_message(group_chat_id, 99, 'dave', 'user', 'Dave msg')
        rows = await database.load_full_user_context(user_id, group_chat_id)
        contents = [r['content'] for r in rows]
        self.assertIn('Carol msg', contents)
        self.assertIn('Dave msg', contents)

    async def test_private_mode_messages_excluded_in_group_context(self):
        """Private-mode messages are excluded when exclude_private=True (group context)."""
        user_id = 40
        private_chat_id = user_id
        group_chat_id = -666
        await database.insert_message(private_chat_id, user_id, 'eve', 'user', 'Public thought')
        await database.insert_message(private_chat_id, user_id, 'eve', 'user', 'Secret thought', is_private=True)
        rows = await database.load_full_user_context(user_id, group_chat_id, exclude_private=True)
        contents = [r['content'] for r in rows]
        self.assertIn('Public thought', contents)
        self.assertNotIn('Secret thought', contents)

    async def test_private_mode_messages_included_in_private_context(self):
        """Private-mode messages are included when exclude_private=False (private context)."""
        user_id = 50
        private_chat_id = user_id
        await database.insert_message(private_chat_id, user_id, 'frank', 'user', 'Normal msg')
        await database.insert_message(private_chat_id, user_id, 'frank', 'user', 'Private msg', is_private=True)
        rows = await database.load_full_user_context(user_id, private_chat_id, exclude_private=False)
        contents = [r['content'] for r in rows]
        self.assertIn('Normal msg', contents)
        self.assertIn('Private msg', contents)

    async def test_empty_history_returns_empty_list(self):
        """User with no history returns an empty list."""
        rows = await database.load_full_user_context(999, -555)
        self.assertEqual(rows, [])

    async def test_results_in_chronological_order(self):
        """Messages from multiple chats are merged in created_at order."""
        user_id = 60
        private_chat_id = user_id
        group_chat_id = -444
        await database.insert_message(private_chat_id, user_id, 'gina', 'user', 'First')
        await database.insert_message(group_chat_id, user_id, 'gina', 'user', 'Second')
        await database.insert_message(private_chat_id, user_id, 'gina', 'user', 'Third')
        rows = await database.load_full_user_context(user_id, group_chat_id)
        contents = [r['content'] for r in rows]
        self.assertEqual(contents, ['First', 'Second', 'Third'])

if __name__ == '__main__':
    unittest.main()
