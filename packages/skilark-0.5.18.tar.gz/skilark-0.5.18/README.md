# skilark

Your career intelligence companion. Skilark delivers daily coding challenges, market signals, and job search — all based on what employers actually look for.

Available on the command line and [Telegram](https://t.me/MySkilarkBot).

## Install

```bash
pip install skilark
```

Requires Python 3.11+.

## Quick start

```bash
skilark              # launch the TUI
skilark today        # jump straight into a challenge
skilark fit "backend engineer python"  # find matching jobs
skilark signals      # this week's market intelligence
skilark status       # see your streak and progress
skilark config       # change your topics
skilark link         # link to your Telegram account
```

On first run, pick the topics you want to sharpen — Python, Go, Kubernetes, System Design, and 30+ more. Then run `skilark` to launch the full-screen TUI.

## What's inside

- **Drill** — Quiz topics and coding problems side by side. Track progress and accuracy per topic. Solve LeetCode-style problems in an inline editor with `Ctrl+R` to run tests locally.
- **Market Signals** — 2,500+ weekly signals: hiring surges, WARN Act filings, salary insights, and company news.
- **Find My Fit** — Semantic job search across 50,000+ listings. Salary ranges, summaries, and one-click open.
- **Profile** — Set your role, language, career direction, and self-description to personalize job search results.

## Keyboard shortcuts

| Key | Action |
|-----|--------|
| `1`-`4` | Switch tabs (Drill, Signals, Jobs, Profile) |
| `t` | Cycle themes (20+ built-in) |
| `/` | Filter current view |
| `o` | Open URL in browser |
| `qq` | Quit |
| `?` | Help |

## Cross-platform

Use `skilark link` to connect your CLI and Telegram accounts. Your streak and progress sync across both.

## Changelog

### 0.5.15

- Self-description field in Profile — used to personalize job search results
- Signals sorted newest-first by timestamp
- Drill UI refinement — side-by-side browser, session persistence

### 0.3.4

- Running `skilark` with no arguments now shows an interactive menu
- All commands discoverable without reading docs

### 0.3.3

- Improved `skilark fit` output — shows title, company, and location for each match
- Results sorted by relevance

### 0.3.2

- Security hardening for config file handling and API communication

### 0.3.1

- Added `skilark fit` command — find matching jobs by description or resume upload
- Compact and detailed output modes (`--detail`)

### 0.3.0

- Added `skilark signals` command — weekly market intelligence (hiring surges, salary insights)
- Use `--all` to see every signal

### 0.2.0

- Added Telegram bot integration
- New `skilark link` command to connect CLI and Telegram accounts
- Synced streaks and progress across platforms

### 0.1.0

- Initial release — interactive challenges, streaks, adaptive difficulty
