"""skilark feedback — send feedback to the Skilark team."""

from rich.console import Console
from rich.prompt import Prompt

from skilark_cli.client import SkilarkClient
from skilark_cli.config_store import ConfigStore


def run() -> None:
    """Prompt for feedback and submit it to the API."""
    console = Console()
    console.print("[bold]Send Feedback[/bold]\n")

    message = Prompt.ask("What's on your mind? (max 2000 chars)").strip()
    if not message:
        console.print("[dim]No feedback entered.[/dim]")
        return

    if len(message) > 2000:
        console.print("[red]Message too long — max 2000 characters.[/red]")
        return

    store = ConfigStore()
    config = store.load()
    client = SkilarkClient(base_url=config["api_url"])

    try:
        client.send_feedback(message)
        console.print("[green]Thanks for your feedback![/green]")
    except Exception:
        console.print("[red]Failed to send feedback. Please try again later.[/red]")
