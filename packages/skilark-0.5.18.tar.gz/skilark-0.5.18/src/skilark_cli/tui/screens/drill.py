"""Drill screen — browser-first view with quiz topics, coding categories, and drills."""

import json
import logging
from pathlib import Path

log = logging.getLogger(__name__)

from rich.syntax import Syntax
from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.widgets import Input, Static, TextArea

from skilark_cli.answer_checker import check_answer
from skilark_cli.client import SkilarkClient
from skilark_cli.executor import build_python_harness, run_code_local
from skilark_cli.tui.constants import DIFFICULTY_STARS
from skilark_cli.tui.errors import friendly_error_message
from skilark_cli.tui.widgets.browser_view import BrowserView
from skilark_cli.tui.widgets.coding_list_view import CodingListView


# Language mapping for Pygments syntax highlighting (quiz mode).
_LANG_MAP = {
    "python": "python", "go": "go", "java": "java",
    "javascript": "javascript", "typescript": "typescript",
    "rust": "rust", "c": "c", "cpp": "cpp", "sql": "sql",
    "spark": "python", "pytorch": "python", "spring-boot": "java",
    "kubernetes": "yaml", "docker": "dockerfile", "terraform": "hcl",
    "cicd": "yaml", "bash": "bash", "linux": "bash",
    "redis": "bash", "airflow": "python",
}

# Languages available for coding problems (order for L cycling).
_CODING_LANGUAGES = ["python"]


def _ensure_parsed(value, fallback_type: type = list):
    """Parse a JSON string into a Python object, or return as-is if already parsed.

    Returns fallback_type() (empty list or dict) on failure.
    """
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return fallback_type()
    return value if value is not None else fallback_type()


class DrillPane(Vertical, can_focus=True):
    """Daily drill — browser-first with quiz topics, coding categories, and drills."""

    BINDINGS = [
        Binding("b", "go_back", "Back", show=True),
        Binding("h", "show_hint", "Hint", show=True),
        Binding("s", "skip", "Skip", show=True),
        Binding("n", "next_challenge", "Next", show=True),
        Binding("m", "toggle_mode", "Mode", show=True),
        Binding("r", "random_quiz", "Random", show=False),
        Binding("R", "random_code", "RandCode", show=False),
        Binding("a", "toggle_show_all", "ShowAll", show=False),
        Binding("ctrl+r", "run_code", "Run", show=False),
    ]

    # Seconds of inactivity before editor changes are autosaved to cache.
    AUTOSAVE_DELAY: float = 5.0

    def __init__(
        self,
        client: SkilarkClient | None = None,
        topics: list[str] | None = None,
        coding_language: str | None = None,
        code_cache_dir: Path | None = None,
        autosave_delay: float | None = None,
        config_store=None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.client = client
        self._config_store = config_store
        self.topics = topics or []
        if autosave_delay is not None:
            self.AUTOSAVE_DELAY = autosave_delay
        # Navigation stack: "browser" | "quiz" | "list" | "code"
        self._nav_stack: list[str] = ["browser"]
        self._current_topic: str | None = None
        self._current_category: str | None = None
        # Quiz mode state
        self._challenge: dict | None = None
        self._hints: list[str] = []
        self._hint_idx: int = 0
        self._day: int = 1
        self._answered: bool = False
        self._stats_loaded: bool = False
        self._pending_answer: str = ""
        # Mode state
        self._mode: str = "quiz"  # "quiz" or "code"
        # Code mode state
        self._coding_language: str = coding_language if coding_language in _CODING_LANGUAGES else "python"
        self._coding_problem: dict | None = None
        self._coding_hints: list[str] = []
        self._coding_hint_idx: int = 0
        self._code_answered: bool = False
        # Code cache
        from skilark_cli.code_cache import CodeCache
        self._code_cache = CodeCache(
            language=self._coding_language,
            config_dir=code_cache_dir,
        )
        # Snapshot of editor text, kept in sync via on_text_area_changed.
        self._editor_text_snapshot: str = ""
        # Last code string that was run via ctrl+r, used for dedup on submit.
        self._last_run_code: str = ""
        # Handle for the active debounce timer; reset on each keystroke.
        self._autosave_timer: "Timer | None" = None

    def compose(self) -> ComposeResult:
        # Browser view (default)
        yield BrowserView(id="drill-browser")
        yield CodingListView(id="drill-coding-list")
        # Shared
        yield Static("Loading...", id="drill-loading")
        yield Static("", id="drill-empty")
        yield Static("", id="drill-header")
        # Quiz mode widgets
        yield Static("", id="drill-question")
        yield Static("", id="drill-code")
        yield Static("", id="drill-choices")
        yield Static("[dim]Tab to focus answer[/dim]", id="drill-status")
        yield Input(placeholder="Your answer (Tab to focus, Esc for shortcuts)", id="drill-answer")
        yield Static("", id="drill-hint")
        yield Static("", id="drill-result")
        yield Static("Were you actually right? [y/n]", id="drill-self-correct")
        # Code mode widgets
        yield Static("", id="drill-description")
        yield TextArea("", language="python", id="drill-editor")
        yield Static("", id="drill-code-status")
        yield Static("", id="drill-test-results")

    def activate(self) -> None:
        """Called when this pane becomes the active tab.

        Re-establishes the correct internal view state and footer bindings,
        and re-renders browser DataTables which may lose visual rows when
        the parent pane's display is toggled off/on.
        """
        if not self.is_attached:
            return
        current = self._nav_stack[-1] if self._nav_stack else "browser"
        self._show_view(current)
        if current == "browser":
            browser = self.query_one("#drill-browser", BrowserView)
            if browser.quiz_items or browser.category_items:
                browser.refresh_tables()
            else:
                self._fetch_browser_data()
        self._update_footer_bindings()

    def on_mount(self) -> None:
        # Hide everything initially
        for widget_id in [
            "#drill-coding-list",
            "#drill-empty", "#drill-header",
            "#drill-question", "#drill-code", "#drill-choices",
            "#drill-status", "#drill-answer",
            "#drill-hint", "#drill-result", "#drill-self-correct",
            "#drill-description", "#drill-editor",
            "#drill-code-status", "#drill-test-results",
        ]:
            self.query_one(widget_id).display = False
        # Editor config
        editor = self.query_one("#drill-editor", TextArea)
        editor.show_line_numbers = True
        editor.tab_behavior = "indent"
        # Restore saved state or start in browser view
        saved = self._config_store.get_drill_state() if self._config_store else None
        if saved and saved.get("view") != "browser":
            self._restore_saved_state(saved)
        else:
            self.query_one("#drill-browser").display = True
            self._fetch_browser_data()

    def _restore_saved_state(self, saved: dict) -> None:
        """Restore navigation from saved drill state."""
        view = saved.get("view", "browser")
        topic = saved.get("topic")
        category = saved.get("category")
        problem_id = saved.get("problem_id")

        if view == "quiz" and topic:
            self._navigate_to_quiz(topic)
        elif view == "list" and category:
            self._navigate_to_code_list(category)
        elif view == "code" and problem_id:
            if category:
                self._current_category = category
                self._nav_stack.append("list")
            self._navigate_to_code(problem_id)
        else:
            self.query_one("#drill-browser").display = True

    # ── Navigation ────────────────────────────────────────

    def _navigate_to_quiz(self, topic: str) -> None:
        """Switch from browser to quiz mode for a specific topic."""
        self._current_topic = topic
        self._nav_stack.append("quiz")
        self._show_view("quiz")
        self._mode = "quiz"
        self._fetch_challenge()
        self._update_footer_bindings()

    def _navigate_to_code_list(self, category: str) -> None:
        """Switch from browser to coding problem list."""
        self._current_category = category
        self._nav_stack.append("list")
        self._show_view("list")
        self._fetch_coding_list()
        self._update_footer_bindings()

    def _navigate_to_code(self, problem_id: str) -> None:
        """Switch from problem list to code editor."""
        self._nav_stack.append("code")
        self._show_view("code")
        self._mode = "code"
        self._fetch_coding_problem_by_id(problem_id)
        self._update_footer_bindings()

    def _navigate_back(self) -> None:
        """Pop navigation stack."""
        if len(self._nav_stack) <= 1:
            return
        leaving = self._nav_stack.pop()
        current = self._nav_stack[-1]
        # Save editor state if leaving code view
        if leaving == "code" and self._coding_problem:
            self._code_cache.save_current(
                self._coding_problem["id"], self._editor_text_snapshot
            )
        self._show_view(current)
        if current == "browser":
            # Only refresh if a completion happened (quiz answered or code solved)
            if self._answered or self._code_answered:
                self._fetch_browser_data()
                self._answered = False
                self._code_answered = False
        self._update_footer_bindings()

    def _show_view(self, view: str) -> None:
        """Show only the widgets for the given view."""
        if not self.is_attached:
            return
        self.query_one("#drill-browser").display = (view == "browser")
        self.query_one("#drill-coding-list").display = (view == "list")
        # Quiz widgets
        quiz_ids = [
            "#drill-header", "#drill-question", "#drill-code", "#drill-choices",
            "#drill-status", "#drill-answer", "#drill-hint", "#drill-result",
            "#drill-self-correct",
        ]
        for wid in quiz_ids:
            self.query_one(wid).display = (view == "quiz")
        # Code widgets
        code_ids = [
            "#drill-description", "#drill-editor",
            "#drill-code-status", "#drill-test-results",
        ]
        for wid in code_ids:
            self.query_one(wid).display = (view == "code")
        # Loading/empty always hidden (shown by workers as needed)
        self.query_one("#drill-loading").display = False
        self.query_one("#drill-empty").display = False

    # ── Browser data fetch ────────────────────────────────

    @work(thread=True, exit_on_error=False)
    def _fetch_browser_data(self) -> None:
        """Fetch topics + categories for browser view."""
        self.app.call_from_thread(self._set_loading, True)
        if not self.client:
            self.app.call_from_thread(self._set_loading, False)
            return
        try:
            topics = self.client.get_challenge_topics()
            categories = self.client.get_coding_categories()
        except Exception as exc:
            log.warning("Failed to load browser data: %s", exc)
            self.app.call_from_thread(self._show_fetch_error, friendly_error_message(exc))
            return
        self.app.call_from_thread(self._display_browser, topics, categories)

    def _display_browser(self, topics: list[dict], categories: list[dict]) -> None:
        if not self.is_attached:
            return
        self._set_loading(False)
        browser = self.query_one("#drill-browser", BrowserView)
        browser.load(topics, categories, self.topics)

    # ── Coding list fetch ─────────────────────────────────

    @work(thread=True, exit_on_error=False)
    def _fetch_coding_list(self) -> None:
        self.app.call_from_thread(self._set_loading, True)
        if not self.client or not self._current_category:
            self.app.call_from_thread(self._set_loading, False)
            return
        try:
            problems = self.client.get_coding_problems_by_category(self._current_category)
        except Exception as exc:
            log.warning("Failed to load problem list: %s", exc)
            self.app.call_from_thread(self._show_fetch_error, friendly_error_message(exc))
            return
        self.app.call_from_thread(self._display_coding_list, problems)

    def _display_coding_list(self, problems: list[dict]) -> None:
        if not self.is_attached:
            return
        self._set_loading(False)
        view = self.query_one("#drill-coding-list", CodingListView)
        view.load(self._current_category or "", problems)

    # ── Message handlers (from browser/list widgets) ──────

    def on_browser_view_topic_selected(self, event: BrowserView.TopicSelected) -> None:
        self._navigate_to_quiz(event.topic)

    def on_browser_view_category_selected(self, event: BrowserView.CategorySelected) -> None:
        self._navigate_to_code_list(event.category)

    def on_coding_list_view_problem_selected(self, event: CodingListView.ProblemSelected) -> None:
        self._navigate_to_code(event.problem_id)

    # ── Shared helpers ────────────────────────────────────

    @work(thread=True, exit_on_error=False)
    def _fetch_challenge(self) -> None:
        self.app.call_from_thread(self._set_loading, True)
        try:
            if self.client is None:
                self.app.call_from_thread(self._display_challenge, None)
                return

            # Get day count from stats on first load
            if not self._stats_loaded:
                try:
                    stats = self.client.get_stats()
                    self._day = stats.get("total_completed", 0) + 1
                except Exception:
                    self._day = 1

            challenge = self.client.get_next_challenge(
                self.topics, topic=self._current_topic
            )
            self.app.call_from_thread(self._display_challenge, challenge)
        except Exception as exc:
            log.debug("failed to fetch challenge", exc_info=True)
            self.app.call_from_thread(self._show_fetch_error, friendly_error_message(exc))

    @work(thread=True, exit_on_error=False)
    def _fetch_coding_problem(self) -> None:
        self.app.call_from_thread(self._set_loading, True)
        try:
            if self.client is None:
                self.app.call_from_thread(self._display_coding_problem, None)
                return

            if not self._stats_loaded:
                try:
                    stats = self.client.get_stats()
                    self._day = stats.get("total_completed", 0) + 1
                except Exception:
                    self._day = 1

            # Coding problems are all topic=dsa; ensure it's in the filter
            coding_topics = list(set(self.topics + ["dsa"]))
            problem = self.client.get_next_coding_problem(
                coding_topics, self._coding_language,
                category=self._current_category,
            )
            self.app.call_from_thread(self._display_coding_problem, problem)
        except Exception as exc:
            log.debug("failed to fetch coding problem", exc_info=True)
            self.app.call_from_thread(self._show_fetch_error, friendly_error_message(exc))

    @work(thread=True, exit_on_error=False)
    def _fetch_coding_problem_by_id(self, problem_id: str) -> None:
        """Fetch a specific coding problem by ID."""
        self.app.call_from_thread(self._set_loading, True)
        if not self.client:
            self.app.call_from_thread(self._set_loading, False)
            return
        try:
            problem = self.client.get_coding_problem_by_id(problem_id)
        except Exception as exc:
            log.warning("Failed to load coding problem: %s", exc)
            self.app.call_from_thread(self._show_fetch_error, friendly_error_message(exc))
            return
        self.app.call_from_thread(self._display_coding_problem, problem)

    def _show_fetch_error(self, message: str) -> None:
        """Show a user-friendly error instead of the empty-state message."""
        if not self.is_attached:
            return
        self._set_loading(False)
        self._hide_all_content()
        empty = self.query_one("#drill-empty", Static)
        empty.update(message)
        empty.display = True

    def _set_loading(self, show: bool) -> None:
        if self.is_attached:
            self.query_one("#drill-loading").display = show

    def _hide_all_content(self) -> None:
        """Hide all content widgets (both modes). Loading/empty handled separately."""
        if not self.is_attached:
            return
        for widget_id in [
            "#drill-browser", "#drill-coding-list",
            "#drill-header",
            "#drill-question", "#drill-code", "#drill-choices",
            "#drill-status", "#drill-answer",
            "#drill-hint", "#drill-result", "#drill-self-correct",
            "#drill-description", "#drill-editor",
            "#drill-code-status", "#drill-test-results",
        ]:
            self.query_one(widget_id).display = False

    # ── Quiz mode ─────────────────────────────────────────

    def _display_challenge(self, challenge: dict | None) -> None:
        if not self.is_attached:
            return
        self._stats_loaded = True
        self._set_loading(False)
        self._answered = False
        self._hint_idx = 0
        self._hide_all_content()

        # Reset hint widget text
        self.query_one("#drill-hint", Static).update("")
        self.query_one("#drill-result", Static).update("")

        if challenge is None:
            self._challenge = None
            empty = self.query_one("#drill-empty", Static)
            empty.update("No more challenges available for your topics.")
            empty.display = True
            return

        self._challenge = challenge
        self.query_one("#drill-empty").display = False

        self._hints = _ensure_parsed(challenge.get("hints"))

        # Header: Day N · source · title
        source = challenge.get("source", "")
        title = challenge.get("title", "")
        header = self.query_one("#drill-header", Static)
        header.update(f"Day {self._day} \u00b7 {source} \u00b7 {title}")
        header.display = True

        # Question
        question = challenge.get("question", "")
        q_widget = self.query_one("#drill-question", Static)
        q_widget.update(question)
        q_widget.display = bool(question)

        # Code (Rich Syntax for proper highlighting)
        code = challenge.get("code_display") or ""
        code_widget = self.query_one("#drill-code", Static)
        if code.strip():
            lang = _LANG_MAP.get(source.lower(), "text")
            code_widget.update(
                Syntax(code, lang, theme="monokai", line_numbers=False)
            )
            code_widget.display = True
        else:
            code_widget.display = False

        # Multiple choice
        challenge_type = challenge.get("challenge_type", "predict_output")
        choices = _ensure_parsed(challenge.get("choices"))

        choices_widget = self.query_one("#drill-choices", Static)
        if challenge_type == "multiple_choice" and choices:
            choices_widget.update("\n".join(choices))
            choices_widget.display = True
        else:
            choices_widget.display = False

        # Status hint and answer input
        self.query_one("#drill-status").display = True
        answer_input = self.query_one("#drill-answer", Input)
        answer_input.value = ""
        answer_input.display = True

    # ── Code mode ─────────────────────────────────────────

    def _display_coding_problem(self, problem: dict | None) -> None:
        if not self.is_attached:
            return
        self._stats_loaded = True
        self._set_loading(False)
        self._code_answered = False
        self._coding_hint_idx = 0
        self._hide_all_content()

        # Reset hint widget
        self.query_one("#drill-hint", Static).update("")

        if problem is None:
            self._coding_problem = None
            empty = self.query_one("#drill-empty", Static)
            empty.update("No coding problems available. Press [bold]b[/bold] to go back.")
            empty.display = True
            return

        self._coding_problem = problem
        self.query_one("#drill-empty").display = False

        # Parse hints
        hints = problem.get("hints") or []
        if isinstance(hints, list):
            self._coding_hints = hints
        else:
            self._coding_hints = []

        # Header: Day N · ★★☆ · title · [Code]
        difficulty = problem.get("difficulty", 1)
        stars = DIFFICULTY_STARS.get(difficulty, "★☆☆")
        title = problem.get("title", "")
        header = self.query_one("#drill-header", Static)
        header.update(f"Day {self._day} \u00b7 {stars} \u00b7 {title} \u00b7 \\[Code]")
        header.display = True

        # Description
        desc = problem.get("description", "")
        desc_widget = self.query_one("#drill-description", Static)
        desc_widget.update(desc)
        desc_widget.display = True

        # Editor — load from cache or starter code
        languages = _ensure_parsed(problem.get("languages"), dict)
        lang_data = languages.get(self._coding_language, {})
        starter_code = lang_data.get("starter_code", "")

        cached = self._code_cache.load(problem["id"])
        editor_code = cached["current"] if cached["current"] else starter_code

        editor = self.query_one("#drill-editor", TextArea)
        editor.text = editor_code
        self._editor_text_snapshot = editor_code
        editor.display = True
        editor.focus()

        # Status line
        self.query_one("#drill-code-status").display = True

        # Clear previous test results
        results_widget = self.query_one("#drill-test-results", Static)
        results_widget.update("")
        results_widget.display = False

    # ── Input handling ────────────────────────────────────

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        """Keep editor text snapshot in sync and trigger debounced autosave."""
        if event.text_area.id == "drill-editor":
            self._editor_text_snapshot = event.text_area.text
            if self._mode == "code" and self._coding_problem:
                if self._autosave_timer is not None:
                    self._autosave_timer.stop()
                self._autosave_timer = self.set_timer(
                    self.AUTOSAVE_DELAY, self._autosave_current
                )

    def _autosave_current(self) -> None:
        """Save current editor text to cache (called by debounce timer)."""
        if self._mode == "code" and self._coding_problem:
            self._code_cache.save_current(
                self._coding_problem["id"], self._editor_text_snapshot
            )
        self._autosave_timer = None

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "drill-answer" and not self._answered:
            self._check_answer(event.value.strip())

    def _check_answer(self, user_answer: str) -> None:
        if not user_answer or not self._challenge:
            return

        expected = self._challenge.get("expected_answer", "")
        correct = check_answer(user_answer, expected)
        self._answered = True

        # Hide answer input and status, move focus to pane for n/y/n keys
        self.query_one("#drill-answer").display = False
        self.query_one("#drill-status").display = False
        self.screen.set_focus(self)

        explanation = self._challenge.get("explanation", "")
        deep_link = self._challenge.get("deep_link", "")

        result = self.query_one("#drill-result", Static)

        if correct:
            lines = ["Correct!", "", explanation]
            if deep_link:
                lines.append(f"\n-> {deep_link}")
            result.update("\n".join(lines))
            result.display = True
            self._record_completion(user_answer, correct=True, self_corrected=False)
        else:
            lines = [f"Not quite. The answer is: {expected}", "", explanation]
            if deep_link:
                lines.append(f"\n-> {deep_link}")
            result.update("\n".join(lines))
            result.display = True
            # Wait for self-correct y/n before recording
            self.query_one("#drill-self-correct").display = True
            self._pending_answer = user_answer

    def on_key(self, event) -> None:
        # Escape to unfocus input or editor
        if event.key == "escape":
            answer_input = self.query_one("#drill-answer", Input)
            if answer_input.has_focus:
                self.screen.set_focus(self)
                event.prevent_default()
                event.stop()
                return
            editor = self.query_one("#drill-editor", TextArea)
            if editor.has_focus:
                self.screen.set_focus(self)
                event.prevent_default()
                event.stop()
                return

        # Language cycling (code mode, only when editor not focused)
        if event.key == "L" and self._mode == "code":
            editor = self.query_one("#drill-editor", TextArea)
            if not editor.has_focus:
                self._cycle_language()
                event.prevent_default()
                event.stop()
                return

        # Handle self-correct y/n
        self_correct = self.query_one("#drill-self-correct")
        if self_correct.display and event.key in ("y", "n"):
            self_corrected = event.key == "y"
            correct = self_corrected
            self_correct.display = False
            self._record_completion(
                self._pending_answer, correct=correct, self_corrected=self_corrected
            )
            event.prevent_default()
            event.stop()

    def _cycle_language(self) -> None:
        """Cycle through available coding languages."""
        try:
            idx = _CODING_LANGUAGES.index(self._coding_language)
        except ValueError:
            idx = 0
        self._coding_language = _CODING_LANGUAGES[(idx + 1) % len(_CODING_LANGUAGES)]
        if self._coding_problem:
            self._display_coding_problem(self._coding_problem)

    # ── Completion recording ──────────────────────────────

    def _record_completion(
        self, answer: str, *, correct: bool, self_corrected: bool
    ) -> None:
        if self._challenge:
            self._submit_completion(
                self._challenge["id"], answer, correct, self_corrected
            )

    @work(thread=True, exit_on_error=False)
    def _submit_completion(
        self, challenge_id: str, answer: str, correct: bool, self_corrected: bool
    ) -> None:
        try:
            if self.client:
                self.client.complete_challenge(
                    challenge_id,
                    answer=answer,
                    correct=correct,
                    self_corrected=self_corrected,
                )
        except Exception:
            pass  # Best-effort recording

    # ── Code execution ────────────────────────────────────

    def action_run_code(self) -> None:
        """Run the user's code from the editor against test cases."""
        if self._mode != "code" or not self._coding_problem or self._code_answered:
            return
        user_code = self.query_one("#drill-editor", TextArea).text
        self._execute_code(user_code)

    @work(thread=True, exit_on_error=False)
    def _execute_code(self, user_code: str) -> None:
        """Run code in a background thread."""
        problem = self._coding_problem
        if not problem:
            return

        self.app.call_from_thread(self._show_running)

        languages = _ensure_parsed(problem.get("languages"), dict)
        lang_data = languages.get(self._coding_language, {})
        function_name = lang_data.get("function_name", "solution")

        test_cases = _ensure_parsed(problem.get("test_cases"))

        harness = build_python_harness(user_code, function_name, test_cases)
        result = run_code_local("python", harness)

        self._last_run_code = user_code
        self.app.call_from_thread(self._display_test_results, result)

    def _show_running(self) -> None:
        if not self.is_attached:
            return
        results_widget = self.query_one("#drill-test-results", Static)
        results_widget.update("[dim]Running...[/dim]")
        results_widget.display = True

    def _display_test_results(self, result: dict) -> None:
        if not self.is_attached:
            return

        results_widget = self.query_one("#drill-test-results", Static)

        error = result.get("error")
        if error:
            results_widget.update(f"[red]Error:[/red] {error}")
            results_widget.display = True
            return

        lines = []
        cases = result.get("results", [])
        hidden_passed = 0
        hidden_total = 0
        for r in cases:
            if r.get("hidden"):
                hidden_total += 1
                if r["passed"]:
                    hidden_passed += 1
                continue
            marker = "[green]✓[/green]" if r["passed"] else "[red]✗[/red]"
            line = f"  {marker} Case {r['case'] + 1}"
            if not r["passed"]:
                line += f": expected {r['expected']}, got {r['actual']}"
            lines.append(line)

        if hidden_total > 0:
            marker = "[green]✓[/green]" if hidden_passed == hidden_total else "[red]✗[/red]"
            lines.append(f"  {marker} {hidden_passed}/{hidden_total} hidden tests")

        passed = result.get("passed_count", 0)
        total = result.get("total_count", 0)
        all_passed = result.get("all_passed", False)

        if all_passed:
            lines.insert(0, f"[green bold]All {total} tests passed![/green bold]")
            self._code_answered = True
        else:
            lines.insert(0, f"[yellow]{passed}/{total} tests passed[/yellow]")

        results_widget.update("\n".join(lines))
        results_widget.display = True

        if all_passed:
            explanation = self._coding_problem.get("explanation", "") if self._coding_problem else ""
            if explanation:
                hint = self.query_one("#drill-hint", Static)
                hint.update(explanation)
                hint.display = True

        user_code = self._last_run_code
        if self._coding_problem:
            pid = self._coding_problem["id"]
            if all_passed:
                is_new = self._code_cache.is_new_pass(pid, user_code)
            else:
                is_new = self._code_cache.is_new_attempt(pid, user_code)
            if is_new:
                self._code_cache.record_attempt(pid, user_code, passed=all_passed)
                self._submit_coding_result(passed, total, all_passed)

        if all_passed and self._coding_problem:
            self._code_cache.clear_current(self._coding_problem["id"])

    @work(thread=True, exit_on_error=False)
    def _submit_coding_result(self, passed_count: int, total_count: int, all_passed: bool = True) -> None:
        try:
            if self.client and self._coding_problem:
                self.client.submit_coding_problem(
                    self._coding_problem["id"],
                    language=self._coding_language,
                    all_passed=all_passed,
                    passed_count=passed_count,
                    total_count=total_count,
                )
        except Exception:
            pass

    # ── Actions ───────────────────────────────────────────

    def action_go_back(self) -> None:
        self._navigate_back()

    def action_toggle_show_all(self) -> None:
        if self._nav_stack[-1] == "browser":
            self.query_one("#drill-browser", BrowserView).toggle_show_all()

    def action_random_quiz(self) -> None:
        if not self._nav_stack or self._nav_stack[-1] not in ("browser", "list"):
            return
        if self._nav_stack[-1] == "browser":
            # Random quiz from configured topics (no single-topic filter)
            self._current_topic = None
            self._nav_stack = ["browser", "quiz"]
            self._show_view("quiz")
            self._mode = "quiz"
            self._fetch_challenge()
            self._update_footer_bindings()
        elif self._nav_stack[-1] == "list":
            view = self.query_one("#drill-coding-list", CodingListView)
            pid = view.get_random_unsolved_id()
            if pid:
                self._navigate_to_code(pid)

    def action_random_code(self) -> None:
        if not self._nav_stack or self._nav_stack[-1] != "browser":
            return
        self._current_category = None
        self._nav_stack = ["browser", "code"]
        self._show_view("code")
        self._mode = "code"
        self._fetch_coding_problem()
        self._update_footer_bindings()

    def action_toggle_mode(self) -> None:
        """Toggle between quiz and code mode (legacy, works in quiz/code views)."""
        current = self._nav_stack[-1]
        if current == "quiz":
            # Switch to code mode in-place
            self._mode = "code"
            self._nav_stack[-1] = "code"
            self._hide_all_content()
            self._fetch_coding_problem()
        elif current == "code":
            # Save editor text before switching
            if self._coding_problem:
                self._code_cache.save_current(
                    self._coding_problem["id"], self._editor_text_snapshot
                )
            self._mode = "quiz"
            self._nav_stack[-1] = "quiz"
            self._hide_all_content()
            self._fetch_challenge()
        self._update_footer_bindings()

    def _update_footer_bindings(self) -> None:
        """Push view-aware bindings to the footer."""
        from skilark_cli.tui.app import FooterBar

        try:
            footer = self.app.query_one(FooterBar)
        except Exception:
            return

        current = self._nav_stack[-1]
        if current == "browser":
            bindings = [
                Binding("r", "random_quiz", "Random", show=True),
                Binding("R", "random_code", "RandCode", show=True),
                Binding("a", "toggle_show_all", "ShowAll", show=True),
            ]
        elif current == "quiz":
            bindings = [
                Binding("b", "go_back", "Back", show=True),
                Binding("h", "show_hint", "Hint", show=True),
                Binding("s", "skip", "Skip", show=True),
                Binding("n", "next_challenge", "Next", show=True),
                Binding("m", "toggle_mode", "Mode", show=True),
            ]
        elif current == "list":
            bindings = [
                Binding("b", "go_back", "Back", show=True),
                Binding("r", "random_quiz", "Random", show=True),
            ]
        elif current == "code":
            bindings = [
                Binding("b", "go_back", "Back", show=True),
                Binding("h", "show_hint", "Hint", show=True),
                Binding("n", "next_challenge", "Next", show=True),
                Binding("m", "toggle_mode", "Mode", show=True),
                Binding("ctrl+r", "run_code", "Run", show=True),
            ]
        else:
            bindings = list(self.BINDINGS)
        footer.set_context_bindings(bindings)

    def on_unmount(self) -> None:
        """Flush editor cache and save drill nav state on teardown."""
        if self._mode == "code" and self._coding_problem and not self._code_answered:
            self._code_cache.save_current(
                self._coding_problem["id"], self._editor_text_snapshot
            )
        # Save drill navigation state for session restore
        if self._config_store:
            current_view = self._nav_stack[-1] if self._nav_stack else "browser"
            if current_view == "browser":
                self._config_store.clear_drill_state()
            else:
                state = {
                    "view": current_view,
                    "topic": self._current_topic,
                    "category": self._current_category,
                    "problem_id": self._coding_problem["id"] if self._coding_problem else None,
                }
                self._config_store.save_drill_state(state)

    def action_show_hint(self) -> None:
        if self._mode == "code":
            self._show_coding_hint()
            return
        if self._answered:
            return
        hint_widget = self.query_one("#drill-hint", Static)
        if not self._hints:
            hint_widget.update("No hints available for this challenge.")
        elif self._hint_idx < len(self._hints):
            hint_widget.update(self._hints[self._hint_idx])
            self._hint_idx += 1
        else:
            hint_widget.update("No more hints.")
        hint_widget.display = True

    def _show_coding_hint(self) -> None:
        if self._code_answered:
            return
        hint_widget = self.query_one("#drill-hint", Static)
        if not self._coding_hints:
            hint_widget.update("No hints available.")
        elif self._coding_hint_idx < len(self._coding_hints):
            hint_widget.update(self._coding_hints[self._coding_hint_idx])
            self._coding_hint_idx += 1
        else:
            hint_widget.update("No more hints.")
        hint_widget.display = True

    def action_skip(self) -> None:
        if self._mode == "code":
            if self._code_answered:
                return
            if self._coding_problem:
                self._code_cache.save_current(
                    self._coding_problem["id"], self._editor_text_snapshot
                )
            self._fetch_coding_problem()
            return
        if self._answered:
            return
        self._fetch_challenge()

    def action_next_challenge(self) -> None:
        """Fetch next challenge in current topic/category."""
        if self._nav_stack[-1] == "quiz" and self._answered:
            self._answered = False
            self._day += 1
            self._fetch_challenge()
        elif self._nav_stack[-1] == "code" and self._code_answered:
            self._code_answered = False
            self._day += 1
            self._fetch_coding_problem()
