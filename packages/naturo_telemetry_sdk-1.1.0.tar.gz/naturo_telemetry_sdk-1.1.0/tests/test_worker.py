from __future__ import annotations

import json
import os
import tempfile
import time
from unittest.mock import MagicMock

from naturo_telemetry_sdk.config import AuthConfig, QueueConfig, SDKConfig
from naturo_telemetry_sdk.reporter import HttpReporter
from naturo_telemetry_sdk.worker import QueueItem, ReportWorker


def _make_config(**overrides) -> SDKConfig:
    defaults = {
        "app_id": "test-app",
        "app_name": "test",
        "report_base_url": "https://example.com/api/v1/ingest",
        "auth": AuthConfig(type="none"),
    }
    defaults.update(overrides)
    return SDKConfig(**defaults)


def test_enqueued_items_are_sent():
    config = _make_config()
    reporter = MagicMock(spec=HttpReporter)
    worker = ReportWorker(config, reporter)

    worker.enqueue("/runs/start", {"test": True})
    time.sleep(0.5)
    worker.shutdown(timeout=2.0)

    reporter.post.assert_called_once_with("/runs/start", {"test": True})


def test_multiple_items_consumed():
    config = _make_config()
    reporter = MagicMock(spec=HttpReporter)
    worker = ReportWorker(config, reporter)

    worker.enqueue("/logs/batch", {"items": [1]})
    worker.enqueue("/metrics/batch", {"items": [2]})
    worker.enqueue("/records/batch", {"items": [3]})
    time.sleep(0.5)
    worker.shutdown(timeout=2.0)

    assert reporter.post.call_count == 3


def test_drop_oldest_strategy():
    config = _make_config(
        queue=QueueConfig(max_queue_size=2, overflow_strategy="drop_oldest")
    )
    reporter = MagicMock(spec=HttpReporter)
    # Don't start the worker thread so items stay in queue
    worker = ReportWorker.__new__(ReportWorker)
    worker.config = config
    worker.reporter = reporter
    worker._stop = __import__("threading").Event()

    import queue as queue_mod
    worker._q = queue_mod.Queue(maxsize=2)

    # Fill queue
    worker.enqueue("/a", {"a": 1})
    worker.enqueue("/b", {"b": 2})
    # This should drop "/a" (oldest)
    worker.enqueue("/c", {"c": 3})

    items = []
    while not worker._q.empty():
        items.append(worker._q.get_nowait())

    endpoints = [item.endpoint for item in items]
    assert "/a" not in endpoints
    assert "/b" in endpoints
    assert "/c" in endpoints


def test_drop_newest_strategy():
    config = _make_config(
        queue=QueueConfig(max_queue_size=2, overflow_strategy="drop_newest")
    )
    reporter = MagicMock(spec=HttpReporter)
    worker = ReportWorker.__new__(ReportWorker)
    worker.config = config
    worker.reporter = reporter
    worker._stop = __import__("threading").Event()

    import queue as queue_mod
    worker._q = queue_mod.Queue(maxsize=2)

    worker.enqueue("/a", {"a": 1})
    worker.enqueue("/b", {"b": 2})
    # This should be dropped (newest)
    worker.enqueue("/c", {"c": 3})

    items = []
    while not worker._q.empty():
        items.append(worker._q.get_nowait())

    endpoints = [item.endpoint for item in items]
    assert "/a" in endpoints
    assert "/b" in endpoints
    assert "/c" not in endpoints


def test_failed_post_persists_to_disk():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
        persist_path = f.name

    try:
        config = _make_config(
            queue=QueueConfig(persist_path=persist_path)
        )
        reporter = MagicMock(spec=HttpReporter)
        reporter.post.side_effect = Exception("connection failed")
        worker = ReportWorker(config, reporter)

        worker.enqueue("/logs/batch", {"items": [{"msg": "hello"}]})
        time.sleep(0.5)
        worker.shutdown(timeout=2.0)

        with open(persist_path, "r") as f:
            lines = f.readlines()
        assert len(lines) >= 1
        persisted = json.loads(lines[0])
        assert persisted["endpoint"] == "/logs/batch"
    finally:
        os.unlink(persist_path)


def test_shutdown_drains_queue():
    config = _make_config()
    reporter = MagicMock(spec=HttpReporter)
    worker = ReportWorker(config, reporter)

    for i in range(5):
        worker.enqueue(f"/endpoint-{i}", {"i": i})

    worker.shutdown(timeout=5.0)
    assert reporter.post.call_count == 5


def test_recover_persisted_items():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
        persist_path = f.name
        for i in range(3):
            f.write(json.dumps({"endpoint": f"/recovered-{i}", "payload": {"i": i}}) + "\n")

    try:
        config = _make_config(
            queue=QueueConfig(persist_path=persist_path)
        )
        reporter = MagicMock(spec=HttpReporter)
        worker = ReportWorker(config, reporter)

        time.sleep(0.5)
        worker.shutdown(timeout=2.0)

        endpoints = [call[0][0] for call in reporter.post.call_args_list]
        for i in range(3):
            assert f"/recovered-{i}" in endpoints

        # Persist file should be cleaned up
        assert not os.path.exists(persist_path)
    finally:
        if os.path.exists(persist_path):
            os.unlink(persist_path)
