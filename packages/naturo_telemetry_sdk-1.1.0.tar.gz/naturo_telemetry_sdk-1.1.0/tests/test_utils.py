from __future__ import annotations

from naturo_telemetry_sdk.utils import (
    backoff_seconds,
    default_hostname,
    default_ip,
    gen_id,
    redact_value,
    utc_now_iso,
)


def test_utc_now_iso_returns_iso_string():
    result = utc_now_iso()
    assert "T" in result
    assert "+" in result or "Z" in result or "UTC" in result.upper()


def test_gen_id_without_prefix():
    result = gen_id()
    assert len(result) == 32
    assert result.isalnum()


def test_gen_id_with_prefix():
    result = gen_id("run_")
    assert result.startswith("run_")
    assert len(result) == 32 + 4


def test_gen_id_uniqueness():
    ids = {gen_id() for _ in range(100)}
    assert len(ids) == 100


def test_default_hostname_returns_string():
    result = default_hostname()
    assert isinstance(result, str)
    assert len(result) > 0


def test_default_ip_returns_string():
    result = default_ip()
    assert isinstance(result, str)
    assert len(result) > 0


def test_backoff_seconds_exponential_growth():
    b1 = backoff_seconds(attempt=1, base_ms=500, max_ms=10000, jitter=False)
    b2 = backoff_seconds(attempt=2, base_ms=500, max_ms=10000, jitter=False)
    b3 = backoff_seconds(attempt=3, base_ms=500, max_ms=10000, jitter=False)
    assert b1 == 0.5
    assert b2 == 1.0
    assert b3 == 2.0


def test_backoff_seconds_max_cap():
    result = backoff_seconds(attempt=20, base_ms=500, max_ms=10000, jitter=False)
    assert result == 10.0


def test_backoff_seconds_jitter_range():
    results = [
        backoff_seconds(attempt=1, base_ms=1000, max_ms=10000, jitter=True)
        for _ in range(50)
    ]
    assert all(0.001 <= r <= 1.5 for r in results)
    assert len(set(results)) > 1


def test_redact_value_simple_dict():
    data = {"password": "secret123", "name": "test"}
    keys = {"password"}
    result = redact_value(data, keys)
    assert result == {"password": "***REDACTED***", "name": "test"}


def test_redact_value_nested_dict():
    data = {"outer": {"token": "abc", "value": 1}}
    keys = {"token"}
    result = redact_value(data, keys)
    assert result == {"outer": {"token": "***REDACTED***", "value": 1}}


def test_redact_value_list():
    data = {"items": [{"password": "x"}, {"name": "y"}]}
    keys = {"password"}
    result = redact_value(data, keys)
    assert result == {"items": [{"password": "***REDACTED***"}, {"name": "y"}]}


def test_redact_value_case_insensitive():
    data = {"Password": "secret", "TOKEN": "abc"}
    keys = {"password", "token"}
    result = redact_value(data, keys)
    assert result["Password"] == "***REDACTED***"
    assert result["TOKEN"] == "***REDACTED***"


def test_redact_value_preserves_non_matching():
    data = {"safe_key": "value", "nested": {"also_safe": 42}}
    keys = {"password"}
    result = redact_value(data, keys)
    assert result == data


def test_redact_value_primitive():
    assert redact_value("hello", {"password"}) == "hello"
    assert redact_value(42, {"password"}) == 42
    assert redact_value(None, {"password"}) is None
