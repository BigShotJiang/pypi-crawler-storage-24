from __future__ import annotations

from naturo_telemetry_sdk import AuthConfig, ObservabilitySDK, SDKConfig


def make_config() -> SDKConfig:
    return SDKConfig(
        app_id="3651",
        app_name="xhs_creator",
        app_version="1.0.0",
        env="dev",
        report_base_url="https://example.com/api/v1/ingest",
        auth=AuthConfig(type="none"),
    )


def test_start_and_finish_run() -> None:
    sdk = ObservabilitySDK.init(make_config())
    sent: list[tuple[str, dict]] = []
    sdk._worker.enqueue = lambda endpoint, payload: sent.append((endpoint, payload))  # type: ignore[attr-defined]

    ctx = sdk.start_run(task_id="task-1", platform="xiaohongshu")
    sdk.log("info", "hello")
    sdk.metric("records_fetched", 12)
    sdk.report_records(data_type="note", records=[{"record_key": "n1", "data": {"title": "t"}}])
    sdk.finish_run(status="success", summary={"records_fetched": 12})
    sdk.shutdown()

    endpoints = [x[0] for x in sent]
    assert "/runs/start" in endpoints
    assert "/logs/batch" in endpoints
    assert "/metrics/batch" in endpoints
    assert "/records/batch" in endpoints
    assert "/runs/finish" in endpoints
    assert ctx.run_id is not None


def test_redact_sensitive_fields() -> None:
    sdk = ObservabilitySDK.init(make_config())
    sent: list[tuple[str, dict]] = []
    sdk._worker.enqueue = lambda endpoint, payload: sent.append((endpoint, payload))  # type: ignore[attr-defined]

    sdk.start_run(task_id="task-2")
    sdk.log("info", "test", extra={"token": "abc", "nested": {"password": "123"}})
    sdk.flush()
    sdk.shutdown()

    logs_payload = next(p for e, p in sent if e == "/logs/batch")
    item = logs_payload["payload"]["items"][0]
    assert item["extra"]["token"] == "***REDACTED***"
    assert item["extra"]["nested"]["password"] == "***REDACTED***"
