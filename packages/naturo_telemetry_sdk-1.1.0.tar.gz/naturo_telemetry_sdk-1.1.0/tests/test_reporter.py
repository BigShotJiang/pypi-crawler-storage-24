from __future__ import annotations

from unittest.mock import MagicMock, patch

import requests

from naturo_telemetry_sdk.config import AuthConfig, SDKConfig
from naturo_telemetry_sdk.reporter import HttpReporter


def _make_config(**overrides) -> SDKConfig:
    defaults = {
        "app_id": "test-app",
        "app_name": "test",
        "report_base_url": "https://example.com/api/v1/ingest",
        "auth": AuthConfig(type="none"),
    }
    defaults.update(overrides)
    return SDKConfig(**defaults)


def test_post_success():
    config = _make_config()
    reporter = HttpReporter(config)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    with patch.object(reporter.session, "post", return_value=mock_resp) as mock_post:
        reporter.post("/runs/start", {"key": "value"})
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        assert "/runs/start" in call_args[0][0]


def test_retry_on_non_2xx():
    config = _make_config()
    reporter = HttpReporter(config)

    mock_resp = MagicMock()
    mock_resp.status_code = 500
    with patch.object(reporter.session, "post", return_value=mock_resp) as mock_post:
        reporter.post("/logs/batch", {"items": []})
        assert mock_post.call_count == config.retry.max_attempts


def test_retry_on_request_exception():
    config = _make_config()
    reporter = HttpReporter(config)

    with patch.object(
        reporter.session, "post", side_effect=requests.RequestException("connection error")
    ) as mock_post:
        reporter.post("/logs/batch", {"items": []})
        assert mock_post.call_count == config.retry.max_attempts


def test_bearer_auth_header():
    config = _make_config(auth=AuthConfig(type="bearer", token="test-token-123"))
    reporter = HttpReporter(config)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    with patch.object(reporter.session, "post", return_value=mock_resp) as mock_post:
        reporter.post("/runs/start", {})
        headers = mock_post.call_args[1]["headers"]
        assert headers["Authorization"] == "Bearer test-token-123"


def test_api_key_auth_header():
    config = _make_config(
        auth=AuthConfig(type="api_key", api_key="nsk_test_key", api_key_header="X-API-Key")
    )
    reporter = HttpReporter(config)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    with patch.object(reporter.session, "post", return_value=mock_resp) as mock_post:
        reporter.post("/runs/start", {})
        headers = mock_post.call_args[1]["headers"]
        assert headers["X-API-Key"] == "nsk_test_key"


def test_hmac_auth_headers():
    config = _make_config(
        auth=AuthConfig(type="hmac", sign_secret="my-secret")
    )
    reporter = HttpReporter(config)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    with patch.object(reporter.session, "post", return_value=mock_resp) as mock_post:
        reporter.post("/runs/start", {"data": "test"})
        headers = mock_post.call_args[1]["headers"]
        assert "X-Signature" in headers
        assert "X-Signature-Timestamp" in headers
        assert len(headers["X-Signature"]) == 64  # SHA-256 hex


def test_no_auth_headers_when_none():
    config = _make_config(auth=AuthConfig(type="none"))
    reporter = HttpReporter(config)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    with patch.object(reporter.session, "post", return_value=mock_resp) as mock_post:
        reporter.post("/runs/start", {})
        headers = mock_post.call_args[1]["headers"]
        assert "Authorization" not in headers
        assert "X-API-Key" not in headers
        assert "X-Signature" not in headers


def test_respects_max_attempts_config():
    from naturo_telemetry_sdk.config import RetryConfig

    config = _make_config()
    config.retry = RetryConfig(max_attempts=5, backoff_base_ms=10, backoff_max_ms=50)
    reporter = HttpReporter(config)

    mock_resp = MagicMock()
    mock_resp.status_code = 503
    with patch.object(reporter.session, "post", return_value=mock_resp) as mock_post:
        reporter.post("/logs/batch", {})
        assert mock_post.call_count == 5


def test_close_closes_session():
    config = _make_config()
    reporter = HttpReporter(config)

    with patch.object(reporter.session, "close") as mock_close:
        reporter.close()
        mock_close.assert_called_once()
