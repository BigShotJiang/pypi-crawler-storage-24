﻿# naturo-telemetry-sdk

A production-oriented SDK for collecting execution logs and data records from RPA apps, then reporting them to a remote service.

## Install

```bash
pip install naturo-telemetry-sdk
```

## Quick Start

```python
from naturo_telemetry_sdk import ObservabilitySDK, SDKConfig, AuthConfig

sdk = ObservabilitySDK.init(
    SDKConfig(
        app_id="3651",
        app_name="xhs_creator",
        app_version="1.0.0",
        env="prod",
        report_base_url="https://naturo-sync.example.com/api/v1/ingest",
        auth=AuthConfig(type="bearer", token="your-token"),
    )
)

run = sdk.start_run(task_id="task-001", platform="xiaohongshu", tags={"customer": "demo"})
sdk.log("info", "job started", step="bootstrap")
sdk.metric("records_fetched", 120)
sdk.report_records(
    data_type="note",
    records=[{"record_key": "note_1", "data": {"title": "hello"}}],
)
sdk.finish_run(status="success", summary={"records_fetched": 120, "records_written": 118})
sdk.shutdown()
```

## API Endpoints Expected by SDK

- `POST {report_base_url}/runs/start`
- `POST {report_base_url}/runs/finish`
- `POST {report_base_url}/logs/batch`
- `POST {report_base_url}/metrics/batch`
- `POST {report_base_url}/records/batch`

Each endpoint should return JSON. Any non-2xx response will be retried by the SDK.

## Security

Sensitive fields are redacted by default, including: `password`, `secret`, `token`, `cookie`, `authorization`.

## License

MIT
