#!/usr/bin/env bash
set -euo pipefail

# ── Config ────────────────────────────────────────────────────────
PKG_NAME="naturo-telemetry-sdk"

# Alibaba Cloud Generic Repo
ORG_ID="60e6a151511ecd228819850f"
REPO_NAME="flow_generic_repo"
API_BASE="https://packages.aliyun.com/api/protocol/${ORG_ID}/generic/${REPO_NAME}/files"
CRED_USER="${ALIYUN_PKG_USER:-681968388eb9d570799467fc}"
CRED_PASS="${ALIYUN_PKG_PASS:-gfF)SlNP0lFv}"

# PyPI
PYPI_TOKEN="${PYPI_TOKEN:-}"

# ── Usage ─────────────────────────────────────────────────────────
usage() {
    echo "Usage: $0 [--bump patch|minor|major] [--target pypi|aliyun|both]"
    echo ""
    echo "Options:"
    echo "  --bump <type>    Bump version before publishing (patch/minor/major)"
    echo "  --target <dest>  Where to publish (default: pypi)"
    echo "                     pypi   - PyPI public registry"
    echo "                     aliyun - Alibaba Cloud generic repo"
    echo "                     both   - Both PyPI and Alibaba Cloud"
    echo ""
    echo "Examples:"
    echo "  $0                        # publish current version to PyPI"
    echo "  $0 --bump patch           # 1.0.0 -> 1.0.1, publish to PyPI"
    echo "  $0 --bump minor --target both  # bump minor, publish everywhere"
    exit 0
}

# ── Parse args ────────────────────────────────────────────────────
TARGET="pypi"
DO_BUMP=""
BUMP_TYPE=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --bump)   DO_BUMP=1; BUMP_TYPE="${2:-patch}"; shift 2 ;;
        --target) TARGET="${2:-pypi}"; shift 2 ;;
        --help|-h) usage ;;
        *) echo "Unknown option: $1"; usage ;;
    esac
done

# ── Read version from pyproject.toml ──────────────────────────────
VERSION=$(python -c "
import re, pathlib
text = pathlib.Path('pyproject.toml').read_text()
m = re.search(r'^version\s*=\s*\"(.+?)\"', text, re.M)
print(m.group(1))
")

echo "Publishing ${PKG_NAME} v${VERSION}"
echo "──────────────────────────────────────"

# ── Optional: bump version ────────────────────────────────────────
if [[ -n "$DO_BUMP" ]]; then
    IFS='.' read -r MAJOR MINOR PATCH <<< "$VERSION"
    case "$BUMP_TYPE" in
        major) MAJOR=$((MAJOR + 1)); MINOR=0; PATCH=0 ;;
        minor) MINOR=$((MINOR + 1)); PATCH=0 ;;
        patch) PATCH=$((PATCH + 1)) ;;
        *) echo "Invalid bump type: $BUMP_TYPE (use major/minor/patch)"; exit 1 ;;
    esac
    NEW_VERSION="${MAJOR}.${MINOR}.${PATCH}"
    sed -i "s/^version = \"${VERSION}\"/version = \"${NEW_VERSION}\"/" pyproject.toml
    VERSION="$NEW_VERSION"
    echo "Bumped to v${VERSION}"
fi

# ── Clean & Build ─────────────────────────────────────────────────
echo "Building..."
rm -rf dist/
python -m build --quiet

WHL=$(ls dist/*.whl)
TAR=$(ls dist/*.tar.gz)
WHL_NAME=$(basename "$WHL")
TAR_NAME=$(basename "$TAR")

echo "Built: ${WHL_NAME}, ${TAR_NAME}"

# ── Upload to PyPI ────────────────────────────────────────────────
upload_pypi() {
    echo "Publishing to PyPI..."
    PYTHONIOENCODING=utf-8 twine upload dist/* \
        -u __token__ \
        -p "${PYPI_TOKEN}" \
        --disable-progress-bar
    echo "  PyPI: https://pypi.org/project/${PKG_NAME}/${VERSION}/"
}

# ── Upload to Alibaba Cloud ──────────────────────────────────────
upload_aliyun() {
    echo "Publishing to Alibaba Cloud..."
    for FILE in "$WHL" "$TAR"; do
        FILE_NAME=$(basename "$FILE")
        RESP=$(curl -sf -u "${CRED_USER}:${CRED_PASS}" \
            -X POST \
            "${API_BASE}/${PKG_NAME}/${FILE_NAME}?version=${VERSION}&fileName=${FILE_NAME}&versionDescription=v${VERSION}" \
            -H "Content-Type: application/octet-stream" \
            -T "$FILE")
        SUCCESS=$(echo "$RESP" | python -c "import sys,json; print(json.load(sys.stdin).get('successful', False))")
        if [[ "$SUCCESS" == "True" ]]; then
            echo "  Uploaded: ${FILE_NAME}"
        else
            echo "  FAILED:   ${FILE_NAME}"
            echo "  Response: ${RESP}"
            exit 1
        fi
    done
}

# ── Execute ───────────────────────────────────────────────────────
case "$TARGET" in
    pypi)
        [[ -z "$PYPI_TOKEN" ]] && { echo "Error: set PYPI_TOKEN env var"; exit 1; }
        upload_pypi
        ;;
    aliyun)
        upload_aliyun
        ;;
    both)
        [[ -z "$PYPI_TOKEN" ]] && { echo "Error: set PYPI_TOKEN env var"; exit 1; }
        upload_pypi
        upload_aliyun
        ;;
    *) echo "Unknown target: $TARGET (use pypi/aliyun/both)"; exit 1 ;;
esac

# ── Done ──────────────────────────────────────────────────────────
echo "──────────────────────────────────────"
echo "Published ${PKG_NAME} v${VERSION} -> ${TARGET}"
echo ""
echo "Install:"
echo "  pip install ${PKG_NAME}==${VERSION}"
