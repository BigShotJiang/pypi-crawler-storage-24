from __future__ import annotations

import json
import logging
import os
import queue
import threading
from dataclasses import dataclass
from typing import Any, Dict

from .config import SDKConfig
from .reporter import HttpReporter

log = logging.getLogger(__name__)


@dataclass
class QueueItem:
    endpoint: str
    payload: Dict[str, Any]


class ReportWorker:
    def __init__(self, config, reporter):
        # type: (SDKConfig, HttpReporter) -> None
        self.config = config
        self.reporter = reporter
        self._q = queue.Queue(maxsize=max(1, config.queue.max_queue_size))
        self._stop = threading.Event()
        self._recover_persisted()
        self._thread = threading.Thread(target=self._run, daemon=True, name="obs-report-worker")
        self._thread.start()

    def enqueue(self, endpoint, payload):
        # type: (str, Dict[str, Any]) -> None
        item = QueueItem(endpoint=endpoint, payload=payload)
        strategy = self.config.queue.overflow_strategy
        if strategy == "block":
            self._q.put(item)
            return
        if strategy == "drop_newest":
            if self._q.full():
                self._persist(item)
                return
            self._q.put_nowait(item)
            return
        # drop_oldest
        if self._q.full():
            try:
                dropped = self._q.get_nowait()
                self._persist(dropped)
            except queue.Empty:
                pass
        self._q.put_nowait(item)

    def shutdown(self, timeout=5.0):
        # type: (float) -> None
        self._stop.set()
        self._thread.join(timeout=timeout)

    def _run(self):
        # type: () -> None
        while not self._stop.is_set() or not self._q.empty():
            try:
                item = self._q.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                self.reporter.post(item.endpoint, item.payload)
            except Exception:
                self._persist(item)

    def _recover_persisted(self):
        # type: () -> None
        path = self.config.queue.persist_path
        if not path or not os.path.exists(path):
            return
        try:
            recovered = 0
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        item = QueueItem(endpoint=data["endpoint"], payload=data["payload"])
                        self._q.put_nowait(item)
                        recovered += 1
                    except (json.JSONDecodeError, KeyError, queue.Full):
                        continue
            os.remove(path)
            if recovered:
                log.info("Recovered %d persisted telemetry items", recovered)
        except Exception:
            log.debug("Failed to recover persisted items", exc_info=True)

    def _persist(self, item):
        # type: (QueueItem) -> None
        path = self.config.queue.persist_path
        if not path:
            return
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps({"endpoint": item.endpoint, "payload": item.payload}, ensure_ascii=False) + "\n")
        except Exception:
            return
