from __future__ import annotations

import copy
import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal


def _to_dict(obj: Any) -> Any:
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {k: _to_dict(v) for k, v in dataclasses.asdict(obj).items()}
    if isinstance(obj, dict):
        return {k: _to_dict(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_to_dict(v) for v in obj]
    return obj


@dataclass
class AuthConfig:
    type: Literal["none", "bearer", "api_key", "hmac"] = "bearer"
    token: Optional[str] = None
    api_key: Optional[str] = None
    api_key_header: str = "X-API-Key"
    sign_secret: Optional[str] = None


@dataclass
class RetryConfig:
    max_attempts: int = 3
    backoff_base_ms: int = 500
    backoff_max_ms: int = 10000
    jitter: bool = True


@dataclass
class BatchConfig:
    max_batch_size: int = 50
    flush_interval_ms: int = 2000


@dataclass
class QueueConfig:
    max_queue_size: int = 5000
    overflow_strategy: Literal["drop_oldest", "drop_newest", "block"] = "drop_oldest"
    persist_path: Optional[str] = None


_DEFAULT_REDACT_FIELDS = [
    "password",
    "secret",
    "token",
    "access_token",
    "refresh_token",
    "cookie",
    "authorization",
    "app_secret",
    "webhook_secret",
]


@dataclass
class SDKConfig:
    app_id: str = ""
    app_name: str = ""
    report_base_url: str = ""

    app_version: str = "0.0.0"
    env: Literal["dev", "staging", "prod"] = "prod"
    auth: AuthConfig = field(default_factory=AuthConfig)

    enabled: bool = True
    service_name: Optional[str] = None
    instance_id: Optional[str] = None
    hostname: Optional[str] = None
    ip: Optional[str] = None
    timezone: str = "Asia/Shanghai"

    timeout_ms: int = 3000
    retry: RetryConfig = field(default_factory=RetryConfig)
    batch: BatchConfig = field(default_factory=BatchConfig)
    queue: QueueConfig = field(default_factory=QueueConfig)

    redact_fields: List[str] = field(default_factory=lambda: list(_DEFAULT_REDACT_FIELDS))
    default_tags: Dict[str, str] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RunContext:
    run_id: Optional[str] = None
    task_id: Optional[str] = None
    trace_id: Optional[str] = None
    platform: Optional[str] = None
    tenant_code: Optional[str] = None
    user_id: Optional[str] = None
    account_id: Optional[str] = None
    tags: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return _to_dict(self)
