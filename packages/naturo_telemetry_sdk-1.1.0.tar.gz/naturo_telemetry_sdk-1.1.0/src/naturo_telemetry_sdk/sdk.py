from __future__ import annotations

import atexit
import threading
import time
from typing import Any, Dict, List, Optional

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal

from .config import RunContext, SDKConfig
from .reporter import HttpReporter
from .utils import default_hostname, default_ip, gen_id, redact_value, utc_now_iso
from .worker import ReportWorker


class ObservabilitySDK:
    def __init__(self, config):
        # type: (SDKConfig) -> None
        self.config = config
        if not self.config.instance_id:
            self.config.instance_id = "{}-{}".format(default_hostname(), gen_id()[:8])
        if not self.config.hostname:
            self.config.hostname = default_hostname()
        if not self.config.ip:
            self.config.ip = default_ip()

        self._reporter = HttpReporter(config)
        self._worker = ReportWorker(config, self._reporter)
        self._ctx = RunContext()
        self._redact_keys = {k.lower() for k in self.config.redact_fields}

        self._log_buffer = []  # type: List[Dict[str, Any]]
        self._metric_buffer = []  # type: List[Dict[str, Any]]
        self._record_buffer = []  # type: List[Dict[str, Any]]
        self._lock = threading.Lock()
        self._stop_flush = threading.Event()
        self._flush_thread = threading.Thread(target=self._flush_loop, daemon=True, name="obs-flush-worker")
        self._flush_thread.start()
        atexit.register(self.shutdown)

    @classmethod
    def init(cls, config):
        # type: (SDKConfig) -> ObservabilitySDK
        return cls(config)

    @property
    def context(self):
        # type: () -> RunContext
        return self._ctx

    def start_run(
        self,
        task_id=None,       # type: Optional[str]
        platform=None,      # type: Optional[str]
        trace_id=None,      # type: Optional[str]
        tags=None,           # type: Optional[Dict[str, str]]
        run_id=None,         # type: Optional[str]
        tenant_code=None,    # type: Optional[str]
        user_id=None,        # type: Optional[str]
        account_id=None,     # type: Optional[str]
    ):
        # type: (...) -> RunContext
        merged_tags = dict(self.config.default_tags)
        if tags:
            merged_tags.update(tags)
        self._ctx = RunContext(
            run_id=run_id or gen_id("run_"),
            task_id=task_id,
            platform=platform,
            trace_id=trace_id or gen_id("trace_")[:20],
            tags=merged_tags,
            tenant_code=tenant_code,
            user_id=user_id,
            account_id=account_id,
        )
        self._worker.enqueue("/runs/start", self._base_payload({"context": self._ctx.to_dict()}))
        return self._ctx

    def finish_run(
        self,
        status="success",   # type: str
        summary=None,        # type: Optional[Dict[str, Any]]
        error=None,          # type: Optional[str]
    ):
        # type: (...) -> None
        self.flush()
        payload = {
            "context": self._ctx.to_dict(),
            "status": status,
            "summary": summary or {},
            "error": error,
            "finished_at": utc_now_iso(),
        }
        self._worker.enqueue("/runs/finish", self._base_payload(payload))

    def log(
        self,
        level,       # type: str
        message,     # type: str
        step=None,   # type: Optional[str]
        extra=None,  # type: Optional[Dict[str, Any]]
    ):
        # type: (...) -> None
        item = {
            "ts": utc_now_iso(),
            "level": level,
            "message": message,
            "step": step,
            "extra": extra or {},
            "context": self._ctx.to_dict(),
        }
        with self._lock:
            self._log_buffer.append(self._sanitize(item))
            if len(self._log_buffer) >= self.config.batch.max_batch_size:
                self._flush_logs_locked()

    def error(self, message, err=None, step=None, extra=None):
        # type: (str, Optional[Exception], Optional[str], Optional[Dict[str, Any]]) -> None
        payload = dict(extra or {})
        if err is not None:
            payload["error_type"] = type(err).__name__
            payload["error_text"] = str(err)
        self.log("error", message, step=step, extra=payload)

    def metric(self, name, value, tags=None):
        # type: (str, float, Optional[Dict[str, str]]) -> None
        item = {
            "ts": utc_now_iso(),
            "name": name,
            "value": value,
            "tags": tags or {},
            "context": self._ctx.to_dict(),
        }
        with self._lock:
            self._metric_buffer.append(self._sanitize(item))
            if len(self._metric_buffer) >= self.config.batch.max_batch_size:
                self._flush_metrics_locked()

    def report_records(self, data_type="", records=None):
        # type: (str, Optional[List[Dict[str, Any]]]) -> None
        for record in (records or []):
            item = {
                "ts": utc_now_iso(),
                "data_type": data_type,
                "record_key": record.get("record_key"),
                "data": record.get("data", {}),
                "context": self._ctx.to_dict(),
            }
            with self._lock:
                self._record_buffer.append(self._sanitize(item))
                if len(self._record_buffer) >= self.config.batch.max_batch_size:
                    self._flush_records_locked()

    def flush(self):
        # type: () -> None
        with self._lock:
            self._flush_logs_locked()
            self._flush_metrics_locked()
            self._flush_records_locked()

    def shutdown(self):
        # type: () -> None
        if self._stop_flush.is_set():
            return
        self._stop_flush.set()
        self.flush()
        self._flush_thread.join(timeout=2.0)
        self._worker.shutdown(timeout=5.0)
        self._reporter.close()

    def _flush_loop(self):
        # type: () -> None
        interval = max(0.2, self.config.batch.flush_interval_ms / 1000.0)
        while not self._stop_flush.is_set():
            time.sleep(interval)
            self.flush()

    def _flush_logs_locked(self):
        # type: () -> None
        if not self._log_buffer:
            return
        payload = {"items": self._log_buffer}
        self._worker.enqueue("/logs/batch", self._base_payload(payload))
        self._log_buffer = []

    def _flush_metrics_locked(self):
        # type: () -> None
        if not self._metric_buffer:
            return
        payload = {"items": self._metric_buffer}
        self._worker.enqueue("/metrics/batch", self._base_payload(payload))
        self._metric_buffer = []

    def _flush_records_locked(self):
        # type: () -> None
        if not self._record_buffer:
            return
        payload = {"items": self._record_buffer}
        self._worker.enqueue("/records/batch", self._base_payload(payload))
        self._record_buffer = []

    def _base_payload(self, payload):
        # type: (Dict[str, Any]) -> Dict[str, Any]
        return {
            "app": {
                "app_id": self.config.app_id,
                "app_name": self.config.app_name,
                "app_version": self.config.app_version,
                "env": self.config.env,
                "service_name": self.config.service_name,
                "instance_id": self.config.instance_id,
                "hostname": self.config.hostname,
                "ip": self.config.ip,
                "timezone": self.config.timezone,
            },
            "payload": payload,
            "sent_at": utc_now_iso(),
        }

    def _sanitize(self, payload):
        # type: (Dict[str, Any]) -> Dict[str, Any]
        return redact_value(payload, self._redact_keys)
