from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any, Dict

import requests

from .config import SDKConfig
from .utils import backoff_seconds


class HttpReporter:
    def __init__(self, config):
        # type: (SDKConfig) -> None
        self.config = config
        self.session = requests.Session()

    def close(self):
        # type: () -> None
        self.session.close()

    def post(self, endpoint, payload):
        # type: (str, Dict[str, Any]) -> None
        url = "{}{}".format(str(self.config.report_base_url).rstrip("/"), endpoint)
        headers = self._build_headers(payload)
        body = json.dumps(payload, ensure_ascii=False)

        max_attempts = max(1, self.config.retry.max_attempts)
        for attempt in range(1, max_attempts + 1):
            try:
                response = self.session.post(
                    url,
                    data=body.encode("utf-8"),
                    headers=headers,
                    timeout=self.config.timeout_ms / 1000.0,
                )
                if 200 <= response.status_code < 300:
                    return
            except requests.RequestException:
                pass

            if attempt < max_attempts:
                time.sleep(
                    backoff_seconds(
                        attempt=attempt,
                        base_ms=self.config.retry.backoff_base_ms,
                        max_ms=self.config.retry.backoff_max_ms,
                        jitter=self.config.retry.jitter,
                    )
                )

    def _build_headers(self, payload):
        # type: (Dict[str, Any]) -> Dict[str, str]
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "naturo-telemetry-sdk/{}".format(self.config.app_version),
        }
        auth = self.config.auth
        if auth.type == "bearer" and auth.token:
            headers["Authorization"] = "Bearer {}".format(auth.token)
        elif auth.type == "api_key" and auth.api_key:
            headers[auth.api_key_header] = auth.api_key
        elif auth.type == "hmac" and auth.sign_secret:
            ts = str(int(time.time()))
            msg = "{}.{}".format(ts, json.dumps(payload, ensure_ascii=False, sort_keys=True))
            sig = hmac.new(auth.sign_secret.encode("utf-8"), msg.encode("utf-8"), hashlib.sha256).hexdigest()
            headers["X-Signature-Timestamp"] = ts
            headers["X-Signature"] = sig
        return headers
