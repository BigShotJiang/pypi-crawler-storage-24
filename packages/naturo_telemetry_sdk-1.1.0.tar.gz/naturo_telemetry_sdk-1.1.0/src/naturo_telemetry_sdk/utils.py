from __future__ import annotations

import random
import socket
import uuid
from datetime import datetime, timezone
from typing import Any, Set


def utc_now_iso():
    # type: () -> str
    return datetime.now(timezone.utc).isoformat()


def gen_id(prefix=""):
    # type: (str) -> str
    token = uuid.uuid4().hex
    return "{}{}".format(prefix, token) if prefix else token


def default_hostname():
    # type: () -> str
    try:
        return socket.gethostname()
    except Exception:
        return "unknown-host"


def default_ip():
    # type: () -> str
    try:
        return socket.gethostbyname(socket.gethostname())
    except Exception:
        return "0.0.0.0"


def backoff_seconds(attempt, base_ms, max_ms, jitter):
    # type: (int, int, int, bool) -> float
    raw = min(max_ms, base_ms * (2 ** max(0, attempt - 1)))
    if jitter:
        raw = int(raw * random.uniform(0.8, 1.2))
    return max(0.001, raw / 1000.0)


def redact_value(value, keys):
    # type: (Any, Set[str]) -> Any
    if isinstance(value, dict):
        out = {}  # type: dict
        for k, v in value.items():
            if k.lower() in keys:
                out[k] = "***REDACTED***"
            else:
                out[k] = redact_value(v, keys)
        return out
    if isinstance(value, list):
        return [redact_value(v, keys) for v in value]
    return value
