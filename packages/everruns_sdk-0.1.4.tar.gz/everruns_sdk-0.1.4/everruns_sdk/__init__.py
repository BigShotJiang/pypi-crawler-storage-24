"""Everruns SDK for Python

A typed client for the Everruns API.

Quick Start:
    >>> from everruns_sdk import Everruns
    >>> client = Everruns()  # uses EVERRUNS_API_KEY
    >>> agent = await client.agents.create("Assistant", "You are helpful.")
"""

from everruns_sdk.auth import ApiKey
from everruns_sdk.client import Everruns
from everruns_sdk.errors import (
    ApiError,
    AuthenticationError,
    EverrunsError,
    NotFoundError,
    RateLimitError,
)
from everruns_sdk.models import (
    Agent,
    AgentCapabilityConfig,
    CapabilityInfo,
    ContentPart,
    Controls,
    Event,
    ExternalActor,
    InitialFile,
    Message,
    Session,
    ToolCallInfo,
    extract_tool_calls,
    generate_agent_id,
    generate_harness_id,
)

__all__ = [
    "Everruns",
    "ApiKey",
    "EverrunsError",
    "ApiError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "Agent",
    "AgentCapabilityConfig",
    "CapabilityInfo",
    "Session",
    "Message",
    "Event",
    "ExternalActor",
    "InitialFile",
    "ContentPart",
    "Controls",
    "ToolCallInfo",
    "extract_tool_calls",
    "generate_agent_id",
    "generate_harness_id",
]

__version__ = "0.1.0"
