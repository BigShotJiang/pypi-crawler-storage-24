def main():
    print("Hello from collimate!")


if __name__ == "__main__":
    main()
