# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Shared MCP server instance.

Both the local (stdio) and remote (streamable-http) entry points set the
`mcp` variable here before importing tools. All tool modules import `mcp`
from this module so they register on whichever server is running.
"""

from mcp.server.fastmcp import FastMCP

mcp: FastMCP | None = None


def set_mcp(instance: FastMCP) -> None:
    """Set the global MCP server instance. Must be called before importing tools."""
    global mcp
    mcp = instance


def get_mcp() -> FastMCP:
    """Get the global MCP server instance.

    Falls back to importing from server.py if not explicitly set.
    This ensures backward compatibility when tools are imported
    directly (e.g., in tests) without going through an entry point.
    """
    global mcp
    if mcp is None:
        from trent_mcp.server import mcp as server_mcp

        mcp = server_mcp
    return mcp
