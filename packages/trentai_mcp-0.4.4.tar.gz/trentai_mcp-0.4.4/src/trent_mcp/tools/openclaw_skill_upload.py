# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""OpenClaw skill packaging and upload tool for Trent MCP Server.

Packages installed skills and custom code from the OpenClaw workspace
as .skill ZIP archives and uploads them to Trent via presigned S3 URLs
for deep security analysis.
"""

import hashlib
import logging
from pathlib import Path
from typing import Annotated

from mcp.server.fastmcp import Context
from pydantic import Field

from trent_mcp.mcp_instance import get_mcp
from trent_mcp.tools.appsec import _get_shared_client

mcp = get_mcp()

logger = logging.getLogger(__name__)

SOURCE_NAME = "HumberAgent OpenClaw Skill Upload"
MAX_SKILL_SIZE_BYTES = 50 * 1024 * 1024  # 50MB client-side limit


def _compute_sha256(content: bytes) -> str:
    """Compute SHA256 digest in the format expected by the backend."""
    return f"sha256:{hashlib.sha256(content).hexdigest()}"


@mcp.tool()
async def upload_openclaw_skills(
    openclaw_workspace_path: Annotated[
        str | None,
        Field(
            description="Path to OpenClaw workspace directory. Defaults to ~/.openclaw/workspace. "
            "This is where skills and custom code are located."
        ),
    ] = None,
    ctx: Context | None = None,
) -> dict:
    """
    Package and upload OpenClaw skills and custom code for deep security analysis.

    Scans the OpenClaw workspace for installed skills and custom code projects,
    packages each as a .skill ZIP archive, and uploads them to Trent via
    presigned S3 URLs. Uses SHA256 digest-based deduplication to skip
    unchanged skills.

    Call this after audit_openclaw_setup to enable deep skill code analysis.
    The .skill files are left in the workspace after upload.
    """
    from trent_mcp.openclaw.package_skills import scan_workspace

    if ctx:
        await ctx.info("Packaging OpenClaw skills and custom code...")
        await ctx.report_progress(progress=5, total=100)

    # --- Package skills ---
    workspace_arg = Path(openclaw_workspace_path) if openclaw_workspace_path else None
    try:
        skills = scan_workspace(workspace=workspace_arg)
    except Exception as e:
        logger.error("Failed to scan workspace: %s", e, exc_info=True)
        return {
            "source": SOURCE_NAME,
            "error": True,
            "message": f"Failed to scan workspace: {e}",
        }

    if not skills:
        return {
            "source": SOURCE_NAME,
            "skills": [],
            "summary": {
                "total": 0,
                "uploaded": 0,
                "skipped": 0,
                "failed": 0,
                "too_large": 0,
            },
            "message": "No skills or custom code found in workspace.",
        }

    if ctx:
        await ctx.info(f"Found {len(skills)} skill(s). Starting upload...")
        await ctx.report_progress(progress=10, total=100)

    # --- Upload each skill ---
    client = _get_shared_client()
    results = []
    counts = {"uploaded": 0, "skipped": 0, "failed": 0, "too_large": 0}

    for i, skill in enumerate(skills):
        skill_name = skill["name"]
        skill_slug = skill["slug"]
        skill_path = Path(skill["skill_file_path"])
        skill_size = skill["skill_size_bytes"]

        # Progress: 10-90% range across skills
        progress = 10 + int((i / len(skills)) * 80)
        if ctx:
            await ctx.info(f"Uploading {skill_name} ({i + 1}/{len(skills)})...")
            await ctx.report_progress(progress=progress, total=100)

        # Check client-side size limit
        if skill_size > MAX_SKILL_SIZE_BYTES:
            size_mb = skill_size / (1024 * 1024)
            limit_mb = MAX_SKILL_SIZE_BYTES / (1024 * 1024)
            results.append(
                {
                    "name": skill_name,
                    "slug": skill_slug,
                    "type": skill["type"],
                    "status": "too_large",
                    "size_bytes": skill_size,
                    "s3_url": None,
                    "error": f"Skill too large: {size_mb:.1f}MB (limit: {limit_mb:.0f}MB)",
                }
            )
            counts["too_large"] += 1
            continue

        try:
            file_bytes = skill_path.read_bytes()
        except OSError as e:
            results.append(
                {
                    "name": skill_name,
                    "slug": skill_slug,
                    "type": skill["type"],
                    "status": "failed",
                    "size_bytes": skill_size,
                    "s3_url": None,
                    "error": f"Cannot read skill file: {e}",
                }
            )
            counts["failed"] += 1
            continue

        digest = _compute_sha256(file_bytes)

        try:
            upload_info = await client.prepare_document_upload(
                name=skill_slug,
                doc_type="openclaw_config",
                doc_format="zip",
                digest=digest,
            )
        except Exception as e:
            logger.warning("Failed to prepare upload for %s: %s", skill_slug, e)
            results.append(
                {
                    "name": skill_name,
                    "slug": skill_slug,
                    "type": skill["type"],
                    "status": "failed",
                    "size_bytes": skill_size,
                    "s3_url": None,
                    "error": f"Upload preparation failed: {e}",
                }
            )
            counts["failed"] += 1
            continue

        # Check server-side size limit
        max_size = upload_info.get("max_size_bytes")
        if max_size and skill_size > max_size:
            size_mb = skill_size / (1024 * 1024)
            limit_mb = max_size / (1024 * 1024)
            results.append(
                {
                    "name": skill_name,
                    "slug": skill_slug,
                    "type": skill["type"],
                    "status": "too_large",
                    "size_bytes": skill_size,
                    "s3_url": None,
                    "error": f"Exceeds server limit: {size_mb:.1f}MB (max: {limit_mb:.1f}MB)",
                }
            )
            counts["too_large"] += 1
            continue

        s3_url = upload_info.get("s3_url")

        if upload_info.get("skipped_upload"):
            results.append(
                {
                    "name": skill_name,
                    "slug": skill_slug,
                    "type": skill["type"],
                    "status": "skipped",
                    "size_bytes": skill_size,
                    "s3_url": s3_url,
                    "error": None,
                }
            )
            counts["skipped"] += 1
            continue

        try:
            await client.upload_content_to_presigned_url(
                upload_url=upload_info["upload_url"],
                content=file_bytes,
                content_type="application/zip",
            )
            results.append(
                {
                    "name": skill_name,
                    "slug": skill_slug,
                    "type": skill["type"],
                    "status": "uploaded",
                    "size_bytes": skill_size,
                    "s3_url": s3_url,
                    "error": None,
                }
            )
            counts["uploaded"] += 1
        except Exception as e:
            logger.warning("Failed to upload %s: %s", skill_slug, e)
            results.append(
                {
                    "name": skill_name,
                    "slug": skill_slug,
                    "type": skill["type"],
                    "status": "failed",
                    "size_bytes": skill_size,
                    "s3_url": s3_url,
                    "error": f"S3 upload failed: {e}",
                }
            )
            counts["failed"] += 1

    if ctx:
        uploaded = counts["uploaded"]
        skipped = counts["skipped"]
        failed = counts["failed"]
        too_large = counts["too_large"]
        await ctx.info(
            f"Upload complete: {uploaded} uploaded, {skipped} skipped, "
            f"{failed} failed, {too_large} too large"
        )
        await ctx.report_progress(progress=100, total=100)

    return {
        "source": SOURCE_NAME,
        "skills": results,
        "summary": {
            "total": len(skills),
            **counts,
        },
    }
