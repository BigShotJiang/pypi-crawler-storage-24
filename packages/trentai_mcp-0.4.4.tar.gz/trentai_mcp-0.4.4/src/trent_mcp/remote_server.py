# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Remote MCP server entry point for Streamable HTTP transport (AWS Fargate)."""

import logging

from mcp.server.auth.settings import AuthSettings
from mcp.server.fastmcp import FastMCP
from pydantic import AnyHttpUrl
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from trent_mcp import __version__
from trent_mcp.auth.token_verifier import Auth0TokenVerifier
from trent_mcp.config import get_remote_config
from trent_mcp.logging_sanitizer import configure_logging
from trent_mcp.mcp_instance import set_mcp

logger = logging.getLogger(__name__)


def create_remote_server() -> FastMCP:
    """Create and configure the remote MCP server with Auth0 authentication."""
    config = get_remote_config()

    # Configure structured logging with credential sanitization
    configure_logging(config.log_level)

    logger.info(
        f"Initializing remote MCP server: stage={config.stage}, "
        f"port={config.port}, transport={config.transport}"
    )

    # Create token verifier for Auth0 JWT validation
    token_verifier = Auth0TokenVerifier(
        issuer=config.auth0_issuer,
        audience=config.auth0_audience,
    )

    # Create FastMCP server with Auth0 as the authorization server.
    # FastMCP automatically:
    # - Serves /.well-known/oauth-protected-resource (RFC 9728)
    # - Returns 401 + WWW-Authenticate header on unauthenticated requests
    # - Validates Bearer tokens via our token_verifier
    # Import instructions from server module (avoid duplication)
    from trent_mcp.server import INSTRUCTIONS

    mcp = FastMCP(
        name="trent",
        instructions=INSTRUCTIONS,
        token_verifier=token_verifier,
        auth=AuthSettings(
            issuer_url=AnyHttpUrl(config.auth0_issuer),
            resource_server_url=AnyHttpUrl("https://mcp.trent.ai"),
            required_scopes=[],
        ),
        host="0.0.0.0",
        port=config.port,
        stateless_http=True,
        log_level=config.log_level,
    )

    # Register as global instance so tools can find it
    set_mcp(mcp)

    # Health check endpoint (unauthenticated — required for ALB health checks)
    @mcp.custom_route("/health", methods=["GET"])
    async def health_check(request: Request) -> Response:
        return JSONResponse(
            {"status": "ok", "version": __version__, "transport": config.transport},
        )

    # Register MCP tools (must happen after set_mcp)
    import trent_mcp.tools  # noqa: F401

    logger.info("Remote MCP server configured with Auth0 authentication")
    return mcp


def main():
    """Run the remote MCP server with Streamable HTTP transport."""
    server = create_remote_server()
    server.run(transport="streamable-http")


if __name__ == "__main__":
    main()
