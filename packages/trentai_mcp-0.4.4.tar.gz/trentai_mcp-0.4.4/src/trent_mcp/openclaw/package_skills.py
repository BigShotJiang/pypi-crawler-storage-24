#!/usr/bin/env python3
"""
package_skills.py

Scans the OpenClaw workspace, identifies custom code and installed skills,
packages each as a .skill file (zip), and prints a JSON summary.

Discovery rules:
  - workspace root: any dir or file that looks like code (heuristic-based)
  - workspace/skills/: recursively finds skill dirs (contain SKILL.md)
  - Skips itself, venv/node_modules, empty dirs, and known config-only files
"""

import hashlib
import json
import os
import pathlib
import re
import sys
import zipfile

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

WORKSPACE = pathlib.Path(
    os.environ.get("OPENCLAW_WORKSPACE", pathlib.Path.home() / ".openclaw/workspace")
)
OUTPUT_DIR = WORKSPACE

# Dirs that are never code
SKIP_DIRS = {
    "venv",
    "__pycache__",
    ".git",
    "node_modules",
    ".clawhub",
    ".learnings",
    ".openclaw",
}

# Root-level names that are workspace config, not user code
WORKSPACE_CONFIG_NAMES = {
    "AGENTS.md",
    "SOUL.md",
    "USER.md",
    "TOOLS.md",
    "IDENTITY.md",
    "HEARTBEAT.md",
    "MEMORY.md",
    "memory",
    "main.sqlite",
    "package_skills.py",  # this script itself
}

# File extensions considered "code"
CODE_EXTENSIONS = {
    ".py",
    ".sh",
    ".js",
    ".ts",
    ".rb",
    ".go",
    ".rs",
    ".java",
    ".cpp",
    ".c",
    ".cs",
    ".php",
    ".swift",
    ".kt",
    ".r",
    ".lua",
}

# Min number of code files for a directory to be considered a project
MIN_CODE_FILES = 1


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def should_skip_dir(name: str) -> bool:
    return name in SKIP_DIRS or name.startswith(".")


def is_code_file(path: pathlib.Path) -> bool:
    return path.is_file() and path.suffix.lower() in CODE_EXTENSIONS


def count_code_files(directory: pathlib.Path) -> int:
    """Recursively count code files, skipping venv-like dirs."""
    count = 0
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if not should_skip_dir(d)]
        count += sum(1 for f in files if pathlib.Path(f).suffix.lower() in CODE_EXTENSIONS)
    return count


def dir_is_empty_or_data_only(directory: pathlib.Path) -> bool:
    """True if dir has no code files at all."""
    return count_code_files(directory) == 0


def parse_skill_frontmatter(skill_md: pathlib.Path) -> dict:
    """
    Parse YAML-ish front-matter from SKILL.md (--- block at top).
    Returns dict with 'name' and 'description' if found.
    """
    if not skill_md.exists():
        return {}
    content = skill_md.read_text(encoding="utf-8", errors="replace")
    if not content.startswith("---"):
        return {}

    end = content.find("---", 3)
    if end < 0:
        return {}

    fm_text = content[3:end]
    result = {}

    # Handle multi-line description (> or | block scalars, or plain)
    # Collect all lines after 'description:' until next key
    lines = fm_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.match(r"^(\w[\w-]*):\s*(.*)", line)
        if m:
            key = m.group(1).lower()
            val = m.group(2).strip()
            if val in (">", "|", ""):
                # Multi-line: collect indented continuation lines
                parts = []
                i += 1
                while i < len(lines):
                    next_line = lines[i]
                    if next_line.startswith("  ") or next_line.startswith("\t"):
                        parts.append(next_line.strip())
                        i += 1
                    else:
                        break
                result[key] = " ".join(parts)
                continue
            else:
                result[key] = val.strip("'\"")
        i += 1

    return result


def read_meta(skill_dir: pathlib.Path) -> dict:
    meta_path = skill_dir / "_meta.json"
    if meta_path.exists():
        try:
            return json.loads(meta_path.read_text())
        except Exception:
            pass
    return {}


def file_hash(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()[:12]


def zip_directory(source_dir: pathlib.Path, output_path: pathlib.Path) -> int:
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_dir):
            dirs[:] = [d for d in dirs if not should_skip_dir(d)]
            for file in sorted(files):
                fp = pathlib.Path(root) / file
                arcname = fp.relative_to(source_dir.parent)
                zf.write(fp, arcname)
    return output_path.stat().st_size


def zip_file(source_file: pathlib.Path, output_path: pathlib.Path) -> int:
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(source_file, source_file.name)
    return output_path.stat().st_size


def find_skill_dirs_recursive(base: pathlib.Path) -> list[pathlib.Path]:
    """
    Recursively find directories containing SKILL.md under base.
    Stops descending once a SKILL.md is found (a skill won't contain another skill).
    """
    found = []
    for entry in sorted(base.iterdir()):
        if not entry.is_dir() or should_skip_dir(entry.name):
            continue
        if (entry / "SKILL.md").exists():
            found.append(entry)
        else:
            found.extend(find_skill_dirs_recursive(entry))
    return found


# ---------------------------------------------------------------------------
# Main scan
# ---------------------------------------------------------------------------


def scan_workspace(workspace: pathlib.Path | None = None) -> list[dict]:
    ws = workspace or WORKSPACE
    output_dir = ws
    results = []
    packaged_paths = set()

    # -----------------------------------------------------------------------
    # 1. Skills directory — recursive discovery
    # -----------------------------------------------------------------------
    skills_dir = ws / "skills"
    if skills_dir.is_dir():
        for skill_dir in find_skill_dirs_recursive(skills_dir):
            slug = skill_dir.name
            skill_file = output_dir / f"{slug}.skill"
            already_exists = skill_file.exists()
            meta = read_meta(skill_dir)
            fm = parse_skill_frontmatter(skill_dir / "SKILL.md")

            size = zip_directory(skill_dir, skill_file)
            packaged_paths.add(skill_dir)

            results.append(
                {
                    "name": fm.get("name", slug),
                    "slug": slug,
                    "type": "installed-skill",
                    "description": fm.get("description", "(no description)"),
                    "source": str(skill_dir.relative_to(ws)),
                    "skill_file": skill_file.name,
                    "skill_file_path": str(skill_file),
                    "skill_size_bytes": size,
                    "version": meta.get("version"),
                    "origin": "clawhub" if meta.get("ownerId") else "custom",
                    "status": "re-packaged" if already_exists else "newly-packaged",
                }
            )

    # -----------------------------------------------------------------------
    # 2. Workspace root — skill dirs and code projects/files
    # -----------------------------------------------------------------------
    for entry in sorted(ws.iterdir()):
        # Skip config, hidden, already-processed, .skill outputs
        if entry.name in WORKSPACE_CONFIG_NAMES:
            continue
        if entry.name.startswith("."):
            continue
        if entry.suffix == ".skill":
            continue
        if entry in packaged_paths:
            continue

        slug = entry.stem if entry.is_file() else entry.name
        skill_file = output_dir / f"{slug}.skill"
        already_exists = skill_file.exists()

        if entry.is_dir():
            # Skip dirs with no code files
            if dir_is_empty_or_data_only(entry):
                continue
            # Skip the skills/ dir itself (handled above)
            if entry.name == "skills":
                continue

            is_skill = (entry / "SKILL.md").exists()
            fm = parse_skill_frontmatter(entry / "SKILL.md") if is_skill else {}
            meta = read_meta(entry) if is_skill else {}

            size = zip_directory(entry, skill_file)
            results.append(
                {
                    "name": fm.get("name", slug),
                    "slug": slug,
                    "type": "skill-directory" if is_skill else "code-project",
                    "description": fm.get("description", "(no SKILL.md)"),
                    "source": str(entry.relative_to(ws)),
                    "skill_file": skill_file.name,
                    "skill_file_path": str(skill_file),
                    "skill_size_bytes": size,
                    "version": meta.get("version"),
                    "origin": "clawhub" if meta.get("ownerId") else "custom",
                    "status": "re-packaged" if already_exists else "newly-packaged",
                }
            )

        elif entry.is_file() and is_code_file(entry):
            size = zip_file(entry, skill_file)
            results.append(
                {
                    "name": slug,
                    "slug": slug,
                    "type": "standalone-script",
                    "description": "(single file)",
                    "source": str(entry.relative_to(ws)),
                    "skill_file": skill_file.name,
                    "skill_file_path": str(skill_file),
                    "skill_size_bytes": size,
                    "version": None,
                    "origin": "custom",
                    "status": "re-packaged" if already_exists else "newly-packaged",
                }
            )

    return results


def main():
    print(f"Scanning workspace: {WORKSPACE}", file=sys.stderr)
    results = scan_workspace()
    print(json.dumps(results, indent=2))

    newly = sum(1 for r in results if r["status"] == "newly-packaged")
    repkg = sum(1 for r in results if r["status"] == "re-packaged")
    print(f"\n{len(results)} item(s): {newly} new, {repkg} re-packaged.", file=sys.stderr)


if __name__ == "__main__":
    main()
