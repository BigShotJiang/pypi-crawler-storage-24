# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Collects system-level metadata for OpenClaw security audits.

Gathers OS info, hardware type, multi-user status, OpenClaw channels,
and installed skills. All output is redacted for secrets before emission.
"""

import json
import logging
import platform
import re
import subprocess
from pathlib import Path
from typing import Any

from trent_mcp import __version__
from trent_mcp.openclaw.openclaw_config.secret_redactor import SecretRedactor

logger = logging.getLogger(__name__)

SUBPROCESS_TIMEOUT = 10  # seconds
DEFAULT_OPENCLAW_PATH = Path.home() / ".openclaw"

# macOS system directories to exclude from user counting
MACOS_SYSTEM_DIRS = {"Shared", ".localized", "Guest"}
# Linux system directories to exclude from user counting
LINUX_SYSTEM_DIRS = {"lost+found"}
# Windows system directories to exclude from user counting
WINDOWS_SYSTEM_DIRS = {"Public", "Default", "Default User", "All Users"}

# Known cloud/VM vendor strings (lowercase) -> hardware type
_VENDOR_MAP = {
    "amazon ec2": "cloud_aws",
    "amazon": "cloud_aws",
    "google compute engine": "cloud_gcp",
    "google": "cloud_gcp",
    "microsoft corporation": "cloud_azure",
    "digitalocean": "cloud_digitalocean",
    "qemu": "virtualized",
    "kvm": "virtualized",
    "vmware": "virtualized",
    "virtualbox": "virtualized",
    "xen": "virtualized",
    "parallels": "virtualized",
}


def detect_os() -> dict[str, Any]:
    """Detect operating system type and version.

    Returns dict with os_type, version, arch, and optionally distro (Linux).
    Never includes hostname.
    """
    os_type = platform.system()  # Darwin, Linux, Windows
    result: dict[str, Any] = {
        "os_type": os_type,
        "version": platform.release(),
        "arch": platform.machine(),
    }

    if os_type == "Darwin":
        mac_ver = platform.mac_ver()[0]
        if mac_ver:
            result["version"] = mac_ver

    elif os_type == "Linux":
        result["distro"] = _read_linux_distro()

    elif os_type == "Windows":
        win_ver = platform.version()
        if win_ver:
            result["version"] = win_ver

    return result


def _read_linux_distro() -> str | None:
    """Read distro name from /etc/os-release."""
    os_release = Path("/etc/os-release")
    if not os_release.is_file():
        return None
    try:
        content = os_release.read_text(encoding="utf-8", errors="replace")
        for line in content.splitlines():
            if line.startswith("PRETTY_NAME="):
                value = line.split("=", 1)[1].strip().strip('"')
                return value
        return None
    except OSError:
        return None


def detect_hardware() -> dict[str, Any]:
    """Detect underlying hardware type (mac/pc/cloud/virtualized).

    Returns dict with type, arch, cpu_brand, and virtualized flag.
    """
    os_type = platform.system()
    arch = platform.machine()
    result: dict[str, Any] = {
        "type": "pc",  # default
        "arch": arch,
        "cpu_brand": None,
        "virtualized": False,
    }

    if os_type == "Darwin":
        result["type"] = "mac"
        result["cpu_brand"] = _read_sysctl_cpu_brand()

    elif os_type == "Linux":
        vendor = _read_dmi_file("sys_vendor")
        product = _read_dmi_file("product_name")

        # Check vendor against known cloud/VM providers
        hw_type = _classify_vendor(vendor, product)
        if hw_type:
            result["type"] = hw_type
            result["virtualized"] = True
        else:
            # Check /proc/cpuinfo for hypervisor flag
            if _has_hypervisor_flag():
                result["type"] = "virtualized"
                result["virtualized"] = True

        result["cpu_brand"] = _read_proc_cpu_brand()

    elif os_type == "Windows":
        result["cpu_brand"] = platform.processor() or None
        wmic_info = _read_wmic_info()
        if wmic_info:
            hw_type = _classify_vendor(
                wmic_info.get("manufacturer", ""),
                wmic_info.get("model", ""),
            )
            if hw_type:
                result["type"] = hw_type
                result["virtualized"] = True

    return result


def _read_sysctl_cpu_brand() -> str | None:
    """Read CPU brand string on macOS via sysctl."""
    try:
        proc = subprocess.run(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            capture_output=True,
            text=True,
            timeout=SUBPROCESS_TIMEOUT,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return None


def _read_dmi_file(name: str) -> str | None:
    """Read a DMI identification file on Linux."""
    path = Path(f"/sys/class/dmi/id/{name}")
    try:
        if path.is_file():
            return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        pass
    return None


def _classify_vendor(vendor: str | None, product: str | None) -> str | None:
    """Classify hardware type from vendor/product strings."""
    for text in (vendor, product):
        if not text:
            continue
        lower = text.lower()
        for pattern, hw_type in _VENDOR_MAP.items():
            if pattern in lower:
                return hw_type
    return None


def _has_hypervisor_flag() -> bool:
    """Check /proc/cpuinfo for hypervisor flag (Linux)."""
    cpuinfo = Path("/proc/cpuinfo")
    try:
        if cpuinfo.is_file():
            content = cpuinfo.read_text(encoding="utf-8", errors="replace")
            for line in content.splitlines():
                if line.startswith("flags") and "hypervisor" in line:
                    return True
    except OSError:
        pass
    return False


def _read_proc_cpu_brand() -> str | None:
    """Read CPU model name from /proc/cpuinfo (Linux)."""
    cpuinfo = Path("/proc/cpuinfo")
    try:
        if cpuinfo.is_file():
            content = cpuinfo.read_text(encoding="utf-8", errors="replace")
            for line in content.splitlines():
                if line.startswith("model name"):
                    parts = line.split(":", 1)
                    if len(parts) == 2:
                        return parts[1].strip()
    except OSError:
        pass
    return None


def _read_wmic_info() -> dict[str, str] | None:
    """Read manufacturer/model from wmic on Windows."""
    try:
        proc = subprocess.run(
            ["wmic", "computersystem", "get", "manufacturer,model", "/format:list"],
            capture_output=True,
            text=True,
            timeout=SUBPROCESS_TIMEOUT,
        )
        if proc.returncode == 0:
            result = {}
            for line in proc.stdout.splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    result[key.strip().lower()] = value.strip()
            return result if result else None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return None


def detect_user_mode() -> dict[str, Any]:
    """Detect whether system is multi-user, single-user, or dedicated.

    Scans home directories. Returns count only — no usernames.
    """
    os_type = platform.system()
    result: dict[str, Any] = {
        "mode": "dedicated",
        "user_count": 0,
        "detection_method": "home_directory_scan",
    }

    if os_type == "Darwin":
        home_dir = Path("/Users")
        exclude = MACOS_SYSTEM_DIRS
    elif os_type == "Linux":
        home_dir = Path("/home")
        exclude = LINUX_SYSTEM_DIRS
    elif os_type == "Windows":
        home_dir = Path("C:/Users")
        exclude = WINDOWS_SYSTEM_DIRS
    else:
        result["detection_method"] = "unsupported_os"
        return result

    try:
        entries = [
            e
            for e in home_dir.iterdir()
            if e.is_dir() and e.name not in exclude and not e.name.startswith(".")
        ]
        user_count = len(entries)
    except (OSError, PermissionError) as e:
        logger.warning("Cannot read %s: %s", home_dir, e)
        result["detection_method"] = "home_directory_scan_failed"
        return result

    result["user_count"] = user_count
    if user_count == 0:
        result["mode"] = "dedicated"
    elif user_count == 1:
        result["mode"] = "single-user"
    else:
        result["mode"] = "multi-user"

    return result


# --- Channel parsing ---

# Matches lines like: "- Telegram default: not configured, token=none, enabled"
_CHANNEL_RE = re.compile(r"^-\s+(\S+)\s+(\S+):\s*(.+)$")
# Matches lines like: "- anthropic:default (token)"
_AUTH_RE = re.compile(r"^-\s+(\S+)\s+\((\w+)\)$")


def detect_channels() -> dict[str, Any]:
    """Run `openclaw channels list` and parse output.

    Returns channel info, auth providers, and doctor warnings.
    Handles missing binary, timeouts, and parse failures gracefully.
    """
    result: dict[str, Any] = {
        "channels": [],
        "auth_providers": [],
        "doctor_warnings": [],
        "channel_count": 0,
        "command_error": None,
        "parse_error": None,
    }

    try:
        proc = subprocess.run(
            ["openclaw", "channels", "list"],
            capture_output=True,
            text=True,
            timeout=SUBPROCESS_TIMEOUT,
        )
        stdout = proc.stdout
    except FileNotFoundError:
        result["command_error"] = "openclaw binary not found"
        return result
    except subprocess.TimeoutExpired:
        result["command_error"] = f"command timed out after {SUBPROCESS_TIMEOUT}s"
        return result
    except OSError as e:
        result["command_error"] = str(e)
        return result

    try:
        _parse_channel_output(stdout, result)
    except Exception as e:
        logger.warning("Failed to parse openclaw channels output: %s", e)
        result["parse_error"] = str(e)

    result["channel_count"] = len(result["channels"])
    return result


def _parse_channel_output(stdout: str, result: dict[str, Any]) -> None:
    """Parse the structured output of `openclaw channels list`."""
    section = None  # "doctor", "channels", "auth"

    for line in stdout.splitlines():
        stripped = line.strip()

        # Detect doctor warnings section
        if "Doctor warnings" in line:
            section = "doctor"
            continue

        # Detect channel section header
        if stripped.startswith("Chat channels:"):
            section = "channels"
            continue

        # Detect auth section header
        if stripped.startswith("Auth providers"):
            section = "auth"
            continue

        # Skip box-drawing decoration lines
        if stripped.startswith(("│", "├", "╮", "╯", "◇")) or stripped == "":
            # But extract doctor warning text from inside the box
            if section == "doctor" and stripped.startswith("│"):
                warning_text = stripped.lstrip("│").strip()
                if warning_text and not warning_text.startswith(("─", "╮", "╯", "├")):
                    # Accumulate multi-line warnings
                    if result["doctor_warnings"] and not warning_text.startswith("-"):
                        result["doctor_warnings"][-1] += " " + warning_text
                    elif warning_text.startswith("- "):
                        result["doctor_warnings"].append(warning_text[2:])
            continue

        # Parse channel lines
        if section == "channels":
            m = _CHANNEL_RE.match(stripped)
            if m:
                name, profile, details = m.group(1), m.group(2), m.group(3)
                enabled = "enabled" in details.lower()
                # Extract status (everything before the first comma, minus known tokens)
                status_parts = [
                    p.strip()
                    for p in details.split(",")
                    if p.strip().lower() not in ("enabled", "disabled")
                    and not p.strip().startswith("token=")
                    and not p.strip().startswith("bot=")
                    and not p.strip().startswith("app=")
                ]
                status = ", ".join(status_parts) if status_parts else "configured"

                result["channels"].append(
                    {
                        "name": name,
                        "profile": profile,
                        "status": status,
                        "enabled": enabled,
                    }
                )
            continue

        # Parse auth provider lines
        if section == "auth":
            m = _AUTH_RE.match(stripped)
            if m:
                result["auth_providers"].append({"name": m.group(1), "type": m.group(2)})
            continue


def detect_skills(openclaw_path: Path | None = None) -> dict[str, Any]:
    """List installed skills from managed and workspace directories.

    Only collects directory names — does not read file contents.
    """
    base_path = (openclaw_path or DEFAULT_OPENCLAW_PATH).expanduser()
    skills: list[dict[str, str]] = []
    errors: list[str] = []

    skill_dirs = [
        ("managed", base_path / "skills"),
        ("workspace", base_path / "workspace" / "skills"),
    ]

    for source, skills_dir in skill_dirs:
        if not skills_dir.is_dir():
            continue
        try:
            for entry in sorted(skills_dir.iterdir()):
                if entry.is_dir() and not entry.name.startswith("."):
                    skills.append({"name": entry.name, "source": source})
        except OSError as e:
            errors.append(f"Cannot read {skills_dir}: {e}")

    managed_count = sum(1 for s in skills if s["source"] == "managed")
    workspace_count = sum(1 for s in skills if s["source"] == "workspace")

    result: dict[str, Any] = {
        "skills": skills,
        "managed_count": managed_count,
        "workspace_count": workspace_count,
    }
    if errors:
        result["errors"] = errors
    return result


def collect_system_analysis(openclaw_path: Path | None = None) -> dict[str, Any]:
    """Collect all system analysis data with secret redaction.

    Assembles OS, hardware, user mode, channels, and skills info.
    Applies SecretRedactor to the full result before returning.
    """
    errors: list[str] = []

    os_info = detect_os()
    hardware_info = detect_hardware()
    user_mode = detect_user_mode()
    channel_info = detect_channels()
    skills_info = detect_skills(openclaw_path=openclaw_path)

    # Collect errors from sub-results
    if channel_info.get("command_error"):
        errors.append(f"channels: {channel_info['command_error']}")
    if channel_info.get("parse_error"):
        errors.append(f"channels parse: {channel_info['parse_error']}")
    if skills_info.get("errors"):
        errors.extend(skills_info.pop("errors"))
    if user_mode.get("detection_method", "").endswith("_failed"):
        errors.append("user mode detection failed")

    result: dict[str, Any] = {
        "schema_version": "1.0",
        "os": os_info,
        "hardware": hardware_info,
        "user_mode": user_mode,
        "channels": channel_info,
        "skills": skills_info,
        "errors": errors,
    }

    # Apply secret redaction
    redactor = SecretRedactor()
    result = redactor.redact(result)
    result["redacted_paths"] = redactor.redacted_paths

    return result


def main() -> None:
    """CLI entry point for trent-openclaw-sysinfo."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="trent-openclaw-sysinfo",
        description="Collect system analysis for OpenClaw security audit.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--path",
        type=str,
        default=None,
        help="Path to OpenClaw config directory (default: ~/.openclaw)",
    )
    args = parser.parse_args()

    path_arg = Path(args.path) if args.path else None
    result = collect_system_analysis(openclaw_path=path_arg)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
