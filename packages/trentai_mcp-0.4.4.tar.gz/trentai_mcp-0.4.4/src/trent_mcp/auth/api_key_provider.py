# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""API key provider for headless authentication."""

import os

from trent_mcp.config import TRENT_API_KEY_FILE


def _read_key_file() -> str | None:
    """Read API key from ~/.trent/api-key if it exists and is secure."""
    try:
        if not TRENT_API_KEY_FILE.is_file() or TRENT_API_KEY_FILE.is_symlink():
            return None
        key = TRENT_API_KEY_FILE.read_text().strip()
        return key if key else None
    except OSError:
        return None


def get_api_key() -> str | None:
    """
    Get API key from file or environment variable.

    Checks in order:
    1. ~/.trent/api-key (file-based, set by openclaw-trent-setup)
    2. TRENT_API_KEY environment variable

    Returns the key if found, otherwise None.
    When None, callers should fall back to OAuth PKCE flow.
    """
    key = _read_key_file()
    if key:
        return key

    key = os.environ.get("TRENT_API_KEY", "").strip()
    return key if key else None
