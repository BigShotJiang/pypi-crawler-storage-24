# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Auth0 JWT and API key verification for remote MCP server."""

import logging

import jwt as pyjwt
from jwt import PyJWKClient
from mcp.server.auth.provider import AccessToken

logger = logging.getLogger(__name__)


class Auth0TokenVerifier:
    """
    Verifies Auth0-issued JWTs and Trent API keys.

    Implements the MCP TokenVerifier protocol so FastMCP can validate
    Bearer tokens on incoming requests.

    JWT validation:
    - RS256 signature verification using Auth0 JWKS
    - Issuer and audience validation
    - Expiration checking

    API key validation:
    - Tokens starting with "trent_" are treated as API keys
    - Validated against DynamoDB + KMS HMAC (same as Lambda Authorizer)
    - Results cached for 5 minutes
    """

    def __init__(self, issuer: str, audience: str):
        self._issuer = issuer
        self._audience = audience
        self._jwks_client = PyJWKClient(
            f"{self._issuer}.well-known/jwks.json",
            cache_jwk_set=True,
            lifespan=3600,
        )

    async def verify_token(self, token: str) -> AccessToken | None:
        """Verify a Bearer token (JWT or API key) and return AccessToken if valid."""
        if token.startswith("trent_"):
            return await self._verify_api_key(token)
        return await self._verify_jwt(token)

    async def _verify_jwt(self, token: str) -> AccessToken | None:
        """Verify an Auth0-issued JWT."""
        try:
            signing_key = self._jwks_client.get_signing_key_from_jwt(token)

            payload = pyjwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=self._audience,
                issuer=self._issuer,
            )

            return AccessToken(
                token=token,
                client_id=payload.get("sub", "unknown"),
                scopes=payload.get("scope", "").split(),
                expires_at=payload.get("exp"),
            )
        except pyjwt.ExpiredSignatureError:
            logger.warning("JWT expired")
            return None
        except pyjwt.InvalidTokenError as e:
            logger.warning(f"JWT validation failed: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error during JWT verification: {e}")
            return None

    async def _verify_api_key(self, api_key: str) -> AccessToken | None:
        """
        Accept a Trent API key for token passthrough.

        Phase 1: Basic format validation only. The API key is forwarded to
        downstream APIs (chat.trent.ai, api.trent.ai) which perform full
        validation via Lambda Authorizer (DynamoDB + KMS HMAC). This matches
        the local MCP behavior where the key is also forwarded without
        local validation.

        Phase 2: Add DynamoDB + KMS HMAC validation here (same as Lambda
        Authorizer) so the remote server rejects invalid keys early.
        """
        if not api_key or len(api_key) < 10:
            logger.warning("API key too short or empty")
            return None

        logger.info("Accepting API key for downstream passthrough validation")
        return AccessToken(
            token=api_key,
            client_id="api_key_user",
            scopes=[],
        )
