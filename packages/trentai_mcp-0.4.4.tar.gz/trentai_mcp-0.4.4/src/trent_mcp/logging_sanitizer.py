# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Logging sanitizer to scrub credentials and PII from log output."""

import logging
import re

# Patterns to redact from log messages
_SENSITIVE_PATTERNS = [
    # Bearer tokens
    (re.compile(r"Bearer\s+[A-Za-z0-9\-._~+/]+=*", re.IGNORECASE), "Bearer [REDACTED]"),
    # Trent API keys
    (re.compile(r"trent_[A-Za-z0-9]{10,}"), "trent_[REDACTED]"),
    # JWT-like tokens (three base64 segments separated by dots)
    (re.compile(r"eyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+"), "[JWT_REDACTED]"),
    # Authorization header values
    (
        re.compile(r'(?i)(authorization["\s:]+)\S+'),
        r"\1[REDACTED]",
    ),
]


class SanitizingFilter(logging.Filter):
    """Logging filter that redacts sensitive values from log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = sanitize(record.msg)
        if record.args:
            if isinstance(record.args, dict):
                record.args = {k: sanitize(str(v)) for k, v in record.args.items()}
            elif isinstance(record.args, tuple):
                record.args = tuple(sanitize(str(a)) for a in record.args)
        return True


def sanitize(text: str) -> str:
    """Redact sensitive patterns from a string."""
    for pattern, replacement in _SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def configure_logging(level: str = "INFO") -> None:
    """Configure structured logging with credential sanitization for the remote server."""
    log_level = getattr(logging, level.upper(), logging.INFO)

    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter(
            fmt='{"timestamp":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s","message":"%(message)s"}',
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    )
    handler.addFilter(SanitizingFilter())

    root = logging.getLogger()
    root.setLevel(log_level)
    root.handlers.clear()
    root.addHandler(handler)
