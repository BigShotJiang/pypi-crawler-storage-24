# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""Configuration management for Trent MCP Server."""

import os
from dataclasses import dataclass
from pathlib import Path

# Trent config directory and API key file
TRENT_CONFIG_DIR = Path.home() / ".trent"
TRENT_API_KEY_FILE = TRENT_CONFIG_DIR / "api-key"


@dataclass
class MCPConfig:
    """Configuration for the MCP server."""

    chat_api_url: str
    agent_api_url: str
    auth0_domain: str
    auth0_client_id: str
    auth0_audience: str
    project_name: str | None
    claude_model: str | None


@dataclass
class RemoteMCPConfig:
    """Configuration for the remote MCP server (Streamable HTTP on Fargate)."""

    chat_api_url: str
    agent_api_url: str
    auth0_issuer: str
    auth0_audience: str
    port: int
    transport: str
    log_level: str
    stage: str
    tool_timeout_seconds: int
    max_response_size_bytes: int


def get_config() -> MCPConfig:
    """
    Load configuration from environment variables.

    Environment Variables:
        TRENT_CHAT_API_URL (or HUMBER_CHAT_API_URL): Chat/AppSec Advisor API URL (streaming, default: https://chat.trent.ai)
        TRENT_AGENT_API_URL (or HUMBER_AGENT_API_URL): Project/Analysis API URL (REST, default: https://api.trent.ai)
        AUTH0_DOMAIN: Auth0 domain for OAuth
        AUTH0_CLIENT_ID: Auth0 client ID for OAuth
        AUTH0_AUDIENCE: Auth0 audience for OAuth
        TRENT_PROJECT_NAME: Override auto-detected project name (optional).
            When not set, the server auto-detects by matching git remote URL
            against Trent projects.
        CLAUDE_MODEL: Claude model identifier (e.g., "claude-opus-4-6") for logging
    """
    return MCPConfig(
        chat_api_url=os.environ.get("TRENT_CHAT_API_URL")
        or os.environ.get("HUMBER_CHAT_API_URL", "https://chat.trent.ai"),
        agent_api_url=os.environ.get("TRENT_AGENT_API_URL")
        or os.environ.get("HUMBER_AGENT_API_URL", "https://api.trent.ai"),
        auth0_domain=os.getenv("AUTH0_DOMAIN", "trent-ai-prod.us.auth0.com"),
        auth0_client_id=os.getenv("AUTH0_CLIENT_ID", "Jd1HSd5aa30qHOW4JevkWeanwIlG7A1f"),
        auth0_audience=os.getenv("AUTH0_AUDIENCE", "https://api.trent.ai/v1"),
        project_name=os.getenv("TRENT_PROJECT_NAME"),
        claude_model=os.getenv("CLAUDE_MODEL"),
    )


def get_remote_config() -> RemoteMCPConfig:
    """
    Load configuration for the remote MCP server.

    Environment Variables:
        TRENT_CHAT_API_URL: Downstream streaming chat API URL
        TRENT_AGENT_API_URL: Downstream agent API URL
        AUTH0_ISSUER: Auth0 issuer URL (e.g., "https://trent-ai.us.auth0.com/")
        AUTH0_AUDIENCE: Auth0 audience for JWT validation
        PORT: Server port (default: 8080)
        TRENT_MCP_TRANSPORT: Transport type (default: streamable-http)
        LOG_LEVEL: Logging level (default: INFO)
        STAGE: Deployment stage (default: Development)
        MCP_TOOL_TIMEOUT_SECONDS: Tool execution timeout (default: 120)
        MCP_MAX_RESPONSE_SIZE_BYTES: Max downstream response size (default: 10MB)
    """
    return RemoteMCPConfig(
        chat_api_url=os.environ.get("TRENT_CHAT_API_URL")
        or os.environ.get("HUMBER_CHAT_API_URL", "https://chat.trent.ai"),
        agent_api_url=os.environ.get("TRENT_AGENT_API_URL")
        or os.environ.get("HUMBER_AGENT_API_URL", "https://api.trent.ai"),
        auth0_issuer=os.getenv("AUTH0_ISSUER", "https://trent-ai-prod.us.auth0.com/"),
        auth0_audience=os.getenv("AUTH0_AUDIENCE", "https://api.trent.ai/v1"),
        port=int(os.getenv("PORT", "8080")),
        transport=os.getenv("TRENT_MCP_TRANSPORT", "streamable-http"),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
        stage=os.getenv("STAGE", "Development"),
        tool_timeout_seconds=int(os.getenv("MCP_TOOL_TIMEOUT_SECONDS", "120")),
        max_response_size_bytes=int(os.getenv("MCP_MAX_RESPONSE_SIZE_BYTES", "10485760")),
    )
