# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""CLI for managing Trent API keys.

Usage:
    trent-api-key create [--expiry-days N] [--scopes SCOPE ...]
    trent-api-key list
    trent-api-key revoke <key_id>

Scopes:
    mcp:openclaw - Chat-only access (default, for OpenClaw headless audit)
"""

import argparse
import asyncio
import sys

import httpx

from trent_mcp.auth.token_manager import TokenManager
from trent_mcp.config import get_config


def _get_auth_header() -> str:
    """Get Bearer token via OAuth PKCE (requires browser)."""
    config = get_config()
    tm = TokenManager(
        auth0_domain=config.auth0_domain,
        client_id=config.auth0_client_id,
        audience=config.auth0_audience,
    )
    token = tm.get_token_or_authenticate()
    return f"Bearer {token}"


async def _request(method: str, path: str, json_data: dict | None = None) -> dict:
    """Make authenticated request to the agent API."""
    config = get_config()
    url = f"{config.agent_api_url}/v1/humber-agent{path}"
    auth = _get_auth_header()

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.request(
            method,
            url,
            headers={"Authorization": auth, "Content-Type": "application/json"},
            json=json_data,
        )
        resp.raise_for_status()
        return resp.json()


def _cmd_create(args: argparse.Namespace) -> None:
    """Create a new API key."""
    body = {"expiry_days": args.expiry_days, "scopes": args.scopes}

    try:
        result = asyncio.run(_request("POST", "/api-keys", json_data=body))
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            print("Authentication failed. Please log in again.", file=sys.stderr)
        else:
            print(f"Error: {e.response.status_code} — {e.response.text}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    api_key = result.get("api_key", "")
    expires_at = result.get("expires_at", "")

    print("\nAPI key created successfully!\n")
    print(f"  Key:     {api_key}")
    print(f"  Expires: {expires_at}")
    print("\nSave this key — it will not be shown again.")
    print("\nTo use with MCP, set the environment variable:")
    print(f'  export TRENT_API_KEY="{api_key}"')
    print("\nOr add to your .mcp.json env section:")
    print(f'  "TRENT_API_KEY": "{api_key}"')


def _cmd_list(args: argparse.Namespace) -> None:
    """List API keys for the current tenant."""
    try:
        result = asyncio.run(_request("GET", "/api-keys"))
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            print("Authentication failed. Please log in again.", file=sys.stderr)
        else:
            print(f"Error: {e.response.status_code} — {e.response.text}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    keys = result.get("api_keys", [])
    if not keys:
        print("No API keys found.")
        return

    print(f"\n{'KEY ID':<16} {'STATUS':<10} {'SCOPES':<20} {'EXPIRES'}")
    print("-" * 62)
    for k in keys:
        key_id = k.get("key_id", "")
        status = k.get("status", "")
        scopes = ",".join(k.get("scopes", []))
        expires = k.get("expires_at", "—") or "—"
        print(f"{key_id:<16} {status:<10} {scopes:<20} {expires}")


def _cmd_revoke(args: argparse.Namespace) -> None:
    """Revoke an API key."""
    try:
        asyncio.run(_request("POST", f"/api-keys/{args.key_id}/revoke"))
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            print(f"Key not found: {args.key_id}", file=sys.stderr)
        elif e.response.status_code == 401:
            print("Authentication failed. Please log in again.", file=sys.stderr)
        else:
            print(f"Error: {e.response.status_code} — {e.response.text}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"API key {args.key_id} revoked.")


def main():
    """Entry point for trent-api-key CLI."""
    parser = argparse.ArgumentParser(
        prog="trent-api-key",
        description="Manage Trent API keys for headless MCP authentication.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # create
    create_parser = sub.add_parser("create", help="Create a new API key")
    create_parser.add_argument(
        "--expiry-days",
        type=int,
        default=30,
        help="Key expiry in days, 1-90 (default: 30)",
    )
    create_parser.add_argument(
        "--scopes",
        nargs="+",
        default=["mcp:openclaw"],
        help="Scopes for the API key (default: mcp:openclaw).",
    )

    # list
    sub.add_parser("list", help="List your API keys")

    # revoke
    revoke_parser = sub.add_parser("revoke", help="Revoke an API key")
    revoke_parser.add_argument("key_id", help="The key ID to revoke")

    args = parser.parse_args()

    commands = {
        "create": _cmd_create,
        "list": _cmd_list,
        "revoke": _cmd_revoke,
    }
    commands[args.command](args)
