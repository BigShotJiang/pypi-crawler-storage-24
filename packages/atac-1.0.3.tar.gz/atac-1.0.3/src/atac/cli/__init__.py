"""ATaC CLI package."""

