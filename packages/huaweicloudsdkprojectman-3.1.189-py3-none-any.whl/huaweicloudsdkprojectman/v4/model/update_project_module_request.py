# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateProjectModuleRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'project_id': 'str',
        'module_id': 'int',
        'body': 'UpdateProjectModuleRequestBody'
    }

    attribute_map = {
        'project_id': 'project_id',
        'module_id': 'module_id',
        'body': 'body'
    }

    def __init__(self, project_id=None, module_id=None, body=None):
        r"""UpdateProjectModuleRequest

        The model defined in huaweicloud sdk

        :param project_id: devcloud项目的32位id
        :type project_id: str
        :param module_id: 模块id
        :type module_id: int
        :param body: Body of the UpdateProjectModuleRequest
        :type body: :class:`huaweicloudsdkprojectman.v4.UpdateProjectModuleRequestBody`
        """
        
        

        self._project_id = None
        self._module_id = None
        self._body = None
        self.discriminator = None

        self.project_id = project_id
        self.module_id = module_id
        if body is not None:
            self.body = body

    @property
    def project_id(self):
        r"""Gets the project_id of this UpdateProjectModuleRequest.

        devcloud项目的32位id

        :return: The project_id of this UpdateProjectModuleRequest.
        :rtype: str
        """
        return self._project_id

    @project_id.setter
    def project_id(self, project_id):
        r"""Sets the project_id of this UpdateProjectModuleRequest.

        devcloud项目的32位id

        :param project_id: The project_id of this UpdateProjectModuleRequest.
        :type project_id: str
        """
        self._project_id = project_id

    @property
    def module_id(self):
        r"""Gets the module_id of this UpdateProjectModuleRequest.

        模块id

        :return: The module_id of this UpdateProjectModuleRequest.
        :rtype: int
        """
        return self._module_id

    @module_id.setter
    def module_id(self, module_id):
        r"""Sets the module_id of this UpdateProjectModuleRequest.

        模块id

        :param module_id: The module_id of this UpdateProjectModuleRequest.
        :type module_id: int
        """
        self._module_id = module_id

    @property
    def body(self):
        r"""Gets the body of this UpdateProjectModuleRequest.

        :return: The body of this UpdateProjectModuleRequest.
        :rtype: :class:`huaweicloudsdkprojectman.v4.UpdateProjectModuleRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this UpdateProjectModuleRequest.

        :param body: The body of this UpdateProjectModuleRequest.
        :type body: :class:`huaweicloudsdkprojectman.v4.UpdateProjectModuleRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateProjectModuleRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
