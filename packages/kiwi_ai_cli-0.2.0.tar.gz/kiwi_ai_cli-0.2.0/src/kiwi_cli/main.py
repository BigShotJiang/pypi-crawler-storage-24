#!/usr/bin/env python3
"""
Kiwi AI CLI Agent — connects to the server via WebSocket and executes
terminal commands on behalf of the LLM agent.

Authenticates with email and password.

Usage:
    kiwi connect --server local
    kiwi connect --server dev
    kiwi connect --server wss://custom.server.com
    kiwi connect --server dev --scope full
    kiwi connect --server dev --allow /path/to/extra/dir
"""

import argparse
import asyncio
import getpass
import json
import os
import re
import shlex
import signal
import subprocess
import sys
import re

IS_WINDOWS = sys.platform == "win32"

if not IS_WINDOWS:
    import fcntl
    import pty
    import struct
    import termios

import httpx
import websockets

MAX_OUTPUT_BYTES = 50 * 1024  # 50KB cap on command output

# Sentinel must match the server-side terminal_tool.py so blocked commands
# are detected as "completed" instead of timing out.
_SENTINEL = "__CMD_DONE__"

_UNIX_SENTINEL_SUFFIX = re.compile(
    rf"""\s*(?:;|&&)\s*echo\s+{re.escape(_SENTINEL)}\$\?{re.escape(_SENTINEL)}\s*$""",
    re.IGNORECASE,
)

_WINDOWS_SENTINEL_SUFFIX = re.compile(
    rf"""\s*&\s*echo\s+{re.escape(_SENTINEL)}!?ERRORLEVEL!?{re.escape(_SENTINEL)}\s*$""",
    re.IGNORECASE,
)

_WINDOWS_SENTINEL_RESULT = re.compile(
    rf"{re.escape(_SENTINEL)}(-?\d+){re.escape(_SENTINEL)}",
    re.IGNORECASE,
)

def _clean_cmd_for_display(data: str) -> str:
    """Strip the sentinel wrapper from a PTY input command for display."""
    cmd = data.strip()
    # Remove sentinel suffix: '; echo __CMD_DONE__$?__CMD_DONE__' (Unix)
    # or '& echo __CMD_DONE__!ERRORLEVEL!__CMD_DONE__' (Windows)    
    idx = cmd.find(_SENTINEL)
    if idx > 0:
        cmd = cmd[:idx]
        # Remove the separator before the sentinel ('; echo ' or '& echo ')
        for sep in ("; echo ", "& echo "):
            if cmd.endswith(sep):
                cmd = cmd[:-len(sep)]
                break
            # Handle without space
            if cmd.endswith(sep.rstrip()):
                cmd = cmd[:-len(sep.rstrip())]
                break
    return cmd.strip()


SERVER_PRESETS = {
    "app": {"ws": "wss://api.meetkiwi.ai", "http": "https://api.meetkiwi.ai"},
    "dev": {"ws": "wss://dev.api.myautobots.com", "http": "https://dev.api.myautobots.com"},
    "local": {"ws": "ws://localhost:8000", "http": "http://localhost:8000"},
}

# ---------------------------------------------------------------------------
# ANSI colors
# ---------------------------------------------------------------------------

RESET = "\033[0m"
BOLD = "\033[1m"

# Brand color — ANSI cyan (works reliably across all terminals)
C = "\033[36m"
CB = "\033[1;36m"
GREY = "\033[90m"
RED = "\033[91m"
YELLOW = "\033[93m"
GREEN = "\033[92m"


# ---------------------------------------------------------------------------
# Banner — Kiwi logo (from SVG) + KIWI AI text side by side
# ---------------------------------------------------------------------------

# Logo: 32 wide x 16 tall (half-block, perfectly symmetric from SVG)
LOGO = [
    "              ▄██▄              ",
    "              ████              ",
    "    ▄██▄▄     ████     ▄▄██▄    ",
    "    ▀█████▄   █▀▀█   ▄█████▀   ",
    "     ▀███▀▀█  ████  █▀▀███▀    ",
    "       ▀█▄  █ ████ █  ▄█▀      ",
    "          ▀▀▄██████▄▀▀         ",
    "▄██████▀▀█▄██████████▄█▀▀██████▄",
    "▀██████▄▄█▀██████████▀█▄▄██████▀",
    "          ▄▄▀██████▀▄▄         ",
    "       ▄█▀  █ ████ █  ▀█▄      ",
    "     ▄███▄▄█  ████  █▄▄███▄    ",
    "    ▄█████▀   █▄▄█   ▀█████▄   ",
    "    ▀██▀▀     ████     ▀▀██▀   ",
    "              ████              ",
    "              ▀██▀              ",
]

# Text: 6 tall
TEXT = [
    "██╗  ██╗██╗██╗    ██╗██╗     █████╗ ██╗",
    "██║ ██╔╝██║██║    ██║██║    ██╔══██╗██║",
    "█████╔╝ ██║██║ █╗ ██║██║    ███████║██║",
    "██╔═██╗ ██║██║███╗██║██║    ██╔══██║██║",
    "██║  ██╗██║╚███╔███╔╝██║    ██║  ██║██║",
    "╚═╝  ╚═╝╚═╝ ╚══╝╚══╝ ╚═╝    ╚═╝  ╚═╝╚═╝",
]

TAGLINE = "Terminal Agent for AI-Powered Automation"


def print_banner():
    """Print the Kiwi AI startup banner."""
    print()

    # Side-by-side: logo (16 lines) with text (6 lines) vertically centered
    gap = "  "
    text_start = 5
    logo_w = 33

    for i, logo_line in enumerate(LOGO):
        padded_logo = logo_line.ljust(logo_w)
        text_idx = i - text_start
        if 0 <= text_idx < len(TEXT):
            row = f"{padded_logo}{gap}{TEXT[text_idx]}"
        elif text_idx == len(TEXT) + 1:
            row = f"{padded_logo}{gap}{TAGLINE}"
        else:
            row = padded_logo

        print(f"  {CB}{row}{RESET}")

    print(f"  {GREY}{'━' * 72}{RESET}")
    print()


def print_status(icon: str, message: str, color: str = C):
    """Print a styled status line."""
    print(f"  {color}{icon}{RESET}  {message}")


def print_section(title: str):
    """Print a section header."""
    print(f"\n  {CB}{title}{RESET}")
    print(f"  {GREY}{'─' * 40}{RESET}")


def print_cmd_log(request_id: str, message: str, success: bool | None = None):
    """Print a command execution log line."""
    tag = f"{GREY}[{request_id[:8]}]{RESET}"
    if success is True:
        icon = f"{GREEN}>{RESET}"
    elif success is False:
        icon = f"{RED}x{RESET}"
    else:
        icon = f"{C}>{RESET}"
    print(f"  {icon} {tag} {message}")


def print_pty_log(session_id: str, message: str, level: str = "info"):
    """Print a PTY session log line."""
    tag = f"{GREY}[PTY {session_id[:8]}]{RESET}"
    if level == "error":
        icon = f"{RED}x{RESET}"
    elif level == "success":
        icon = f"{GREEN}>{RESET}"
    else:
        icon = f"{C}~{RESET}"
    print(f"  {icon} {tag} {message}")


# ---------------------------------------------------------------------------
# Path validator for restricted mode
# ---------------------------------------------------------------------------

# Regex to detect Windows absolute paths like C:\ or D:/
_WIN_ABS_PATH = re.compile(r'^[A-Za-z]:[/\\]')
# Regex to detect UNC paths like \\server\share
_UNC_PATH = re.compile(r'^\\\\')
# Windows environment variables like %USERPROFILE%
_WIN_ENV_VAR = re.compile(r'%([^%]+)%')

# Regex patterns to find paths embedded anywhere in a command string
_EMBEDDED_UNIX_PATH = re.compile(r'(?:^|[\s\'";=])(/[^\s\'";|&>]+)')
_EMBEDDED_HOME_PATH = re.compile(r'(?:^|[\s\'";=])(~[^\s\'";|&>]*)')
_EMBEDDED_WIN_PATH = re.compile(r'(?:^|[\s\'";=])([A-Za-z]:[/\\][^\s\'";|&>]*)')
_EMBEDDED_UNC_PATH = re.compile(r'(?:^|[\s\'";=])(\\\\[^\s\'";|&>]+)')
_EMBEDDED_DOTDOT = re.compile(r'(?:^|[\s\'";=])(\.\.[/\\][^\s\'";|&>]*)')


def _scan_paths(command: str) -> list[str]:
    """Scan the raw command string for embedded path patterns."""
    paths = []
    patterns = [_EMBEDDED_HOME_PATH, _EMBEDDED_WIN_PATH, _EMBEDDED_UNC_PATH, _EMBEDDED_DOTDOT]
    # Unix absolute paths don't exist on Windows; /x tokens are command flags
    if not IS_WINDOWS:
        patterns.insert(0, _EMBEDDED_UNIX_PATH)
    for pattern in patterns:
        for m in pattern.finditer(command):
            p = m.group(1).rstrip(";|&'\"")
            if not p:
                continue
            # Skip standard system device paths
            if p in _SAFE_PATHS:
                continue
            paths.append(p)
    return paths


def _get_process_cwd(pid: int) -> str | None:
    """Get the current working directory of a process by PID."""
    try:
        import psutil
        return psutil.Process(pid).cwd()
    except Exception:
        return None


def validate_command(
    command: str, allowed_dirs: list[str], pid: int | None = None
) -> tuple[bool, str]:
    """Check if a command references paths outside the allowed directories.

    Returns (True, "") if allowed, (False, reason) if blocked.
    """
    # Use the shell's actual cwd for resolving relative paths (e.g. ..)
    base_dir = allowed_dirs[0]
    if pid is not None:
        real_cwd = _get_process_cwd(pid)
        if real_cwd:
            base_dir = real_cwd

    # Token-based extraction
    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()

    candidates = []
    for token in tokens:
        path = _extract_path(token)
        if path is not None:
            candidates.append((path, False))

    # Regex scan for embedded paths (catches paths inside quoted strings)
    for path in _scan_paths(command):
        candidates.append((path, True))

    # Deduplicate
    seen = set()
    for path, from_regex in candidates:
        if path in seen:
            continue
        seen.add(path)
        resolved = _resolve_path(path, base_dir)
        if resolved is None:
            continue
        # Regex-scanned paths may be string literals (e.g. echo "hello /world"),
        # so only flag them if the path actually exists on disk.
        if from_regex and not os.path.exists(resolved):
            continue
        if not _is_within_allowed(resolved, allowed_dirs):
            return False, (
                f"Restricted: '{path}' resolves to '{resolved}' "
                f"which is outside the allowed directories"
            )

    return True, ""


_SAFE_PATHS = frozenset({
    "/dev/null", "/dev/stdin", "/dev/stdout", "/dev/stderr",
    "/dev/zero", "/dev/random", "/dev/urandom", "/dev/tty",
})


def _extract_path(token: str) -> str | None:
    """Extract a file path from a token, or None if it doesn't look like one."""
    # Strip trailing shell metacharacters (;, &&, ||, |, &)
    token = token.rstrip(";|&")
    if not token:
        return None
    # Strip common shell prefixes that precede paths in redirections
    for prefix in (">", ">>", "<", "2>", "2>>", "&>", "&>>"):
        if token.startswith(prefix) and len(token) > len(prefix):
            token = token[len(prefix):]
            break

    # Whitelist standard system device paths
    if token in _SAFE_PATHS:
        return None

    # Home directory references
    if token.startswith("~"):
        return token

    # Unix absolute paths (skip on Windows — /x tokens are command flags like /d, /b, /ad)
    if token.startswith("/"):
        if IS_WINDOWS:
            return None
        return token

    # Windows absolute paths
    if IS_WINDOWS:
        if _WIN_ABS_PATH.match(token):
            return token
        if _UNC_PATH.match(token):
            return token
        # Expand %VAR% and check
        expanded = _WIN_ENV_VAR.sub(_expand_win_var, token)
        if expanded != token and (_WIN_ABS_PATH.match(expanded) or expanded.startswith("/")):
            return expanded

    # Relative paths with .. traversal
    if ".." in token.split(os.sep) or ".." in token.split("/"):
        return token

    return None


def _expand_win_var(match: re.Match) -> str:
    """Expand a Windows %VAR% environment variable."""
    return os.environ.get(match.group(1), match.group(0))


def _resolve_path(path: str, base_dir: str) -> str | None:
    """Resolve a path to its real absolute location."""
    try:
        # Expand ~ to home directory
        path = os.path.expanduser(path)

        # Make relative paths absolute against base_dir
        if not os.path.isabs(path):
            path = os.path.join(base_dir, path)

        # Normalize (resolve ..) and resolve symlinks
        return os.path.realpath(path)
    except (OSError, ValueError):
        return None


def _is_within_allowed(resolved_path: str, allowed_dirs: list[str]) -> bool:
    """Check if a resolved path is within any of the allowed directories."""
    resolved = os.path.normcase(resolved_path)
    # macOS filesystem is typically case-insensitive
    if sys.platform == "darwin":
        resolved = resolved.lower()
    for allowed in allowed_dirs:
        allowed_norm = os.path.normcase(allowed)
        if sys.platform == "darwin":
            allowed_norm = allowed_norm.lower()
        if resolved == allowed_norm or resolved.startswith(allowed_norm + os.sep):
            return True
    return False


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------

async def login(http_base_url: str, email: str, password: str) -> str:
    """Authenticate with email/password and return the JWT access token."""
    url = f"{http_base_url}/v1/auth/token"
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            url,
            data={"username": email, "password": password},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if resp.status_code != 200:
            detail = resp.text
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                pass
            raise Exception(f"Login failed (HTTP {resp.status_code}): {detail}")

        body = resp.json()
        token = body.get("access_token")
        if not token:
            raise Exception(f"No access_token in response: {body}")
        return token


async def run_command(
    command: str,
    timeout: int = 120,
    mode: str = "restricted",
    allowed_dirs: list[str] | None = None,
) -> dict:
    """Execute a shell command and return stdout, stderr, exit_code."""
    # Validate in restricted mode
    if mode == "restricted" and allowed_dirs:
        ok, reason = validate_command(command, allowed_dirs)
        if not ok:
            return {"stdout": "", "stderr": reason, "exit_code": 1}

    try:
        cwd = allowed_dirs[0] if allowed_dirs else None
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
        )
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(), timeout=timeout
        )
        stdout = stdout_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_BYTES]
        stderr = stderr_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_BYTES]
        return {"stdout": stdout, "stderr": stderr, "exit_code": proc.returncode}
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        return {"stdout": "", "stderr": f"Command timed out after {timeout}s", "exit_code": -1}
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "exit_code": -1}


if not IS_WINDOWS:

    class PTYProcess:
        """Manages a single interactive PTY session (Unix/macOS only)."""

        def __init__(self, session_id: str, command: str, cols: int = 120, rows: int = 40):
            self.session_id = session_id
            self.command = command
            self.cols = cols
            self.rows = rows
            self.master_fd = None
            self.slave_fd = None
            self.proc = None
            self._read_task = None

        async def start(self, ws, cwd: str | None = None):
            """Spawn the PTY process and begin reading output."""
            self.master_fd, self.slave_fd = pty.openpty()

            winsize = struct.pack("HHHH", self.rows, self.cols, 0, 0)
            fcntl.ioctl(self.slave_fd, termios.TIOCSWINSZ, winsize)

            self.proc = await asyncio.create_subprocess_exec(
                "/bin/sh", "-c", self.command,
                stdin=self.slave_fd,
                stdout=self.slave_fd,
                stderr=self.slave_fd,
                preexec_fn=os.setsid,
                cwd=cwd,
            )

            os.close(self.slave_fd)
            self.slave_fd = None

            flags = fcntl.fcntl(self.master_fd, fcntl.F_GETFL)
            fcntl.fcntl(self.master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

            self._read_task = asyncio.create_task(self._read_loop(ws))

        async def _read_loop(self, ws):
            """Read output from master fd and send over WebSocket."""
            loop = asyncio.get_event_loop()
            try:
                while True:
                    try:
                        data = await loop.run_in_executor(None, self._blocking_read)
                        if data is None:
                            break
                        # Echo output to stdout for observability
                        for line in data.splitlines():
                            print_cmd_log(self.session_id, line)
                        await ws.send(json.dumps({
                            "type": "pty_output",
                            "session_id": self.session_id,
                            "data": data,
                        }))
                    except OSError:
                        break
                    except Exception as e:
                        print_pty_log(self.session_id, f"Read error: {e}", "error")
                        break

                if self.proc:
                    try:
                        exit_code = await asyncio.wait_for(self.proc.wait(), timeout=5.0)
                    except asyncio.TimeoutError:
                        self.proc.kill()
                        exit_code = -1
                else:
                    exit_code = -1

                await ws.send(json.dumps({
                    "type": "pty_exited",
                    "session_id": self.session_id,
                    "exit_code": exit_code,
                }))
            except Exception as e:
                try:
                    await ws.send(json.dumps({
                        "type": "pty_error",
                        "session_id": self.session_id,
                        "error": str(e),
                    }))
                except Exception:
                    pass

        def _blocking_read(self) -> str | None:
            """Blocking read from master fd. Returns None on EOF."""
            import select
            while True:
                ready, _, _ = select.select([self.master_fd], [], [], 0.5)
                if ready:
                    try:
                        data = os.read(self.master_fd, 4096)
                        if not data:
                            return None
                        return data.decode("utf-8", errors="replace")
                    except OSError:
                        return None
                if self.proc and self.proc.returncode is not None:
                    try:
                        data = os.read(self.master_fd, 4096)
                        if data:
                            return data.decode("utf-8", errors="replace")
                    except OSError:
                        pass
                    return None

        async def send_input(self, data: str) -> None:
            """Write data to the PTY master fd."""
            if self.master_fd is not None:
                os.write(self.master_fd, data.encode("utf-8"))

        async def close(self) -> None:
            """Terminate the process and clean up fds."""
            if self._read_task and not self._read_task.done():
                self._read_task.cancel()
                try:
                    await self._read_task
                except asyncio.CancelledError:
                    pass

            if self.proc and self.proc.returncode is None:
                try:
                    self.proc.terminate()
                    await asyncio.wait_for(self.proc.wait(), timeout=3.0)
                except (asyncio.TimeoutError, ProcessLookupError):
                    try:
                        self.proc.kill()
                    except ProcessLookupError:
                        pass

            if self.master_fd is not None:
                try:
                    os.close(self.master_fd)
                except OSError:
                    pass
                self.master_fd = None

            if self.slave_fd is not None:
                try:
                    os.close(self.slave_fd)
                except OSError:
                    pass
                self.slave_fd = None




class PipeProcess:
    """Manages a persistent shell session using subprocess pipes (Windows-compatible)."""

    def __init__(
        self,
        session_id: str,
        command: str,
        cols: int = 120,
        rows: int = 40,
        mode: str = "restricted",
        allowed_dirs: list[str] | None = None,
    ):
        self.session_id = session_id
        self.command = command
        self.cols = cols
        self.rows = rows
        self.proc = None
        self._read_task = None
        self.cwd = None

        self.mode = mode
        self.allowed_dirs = allowed_dirs or []
        self.ws = None

        self._timeout_task: asyncio.Task | None = None
        self._sentinel_buffer = ""

    async def start(self, ws, cwd: str | None = None):
        """Spawn the shell process with piped stdin/stdout."""
        self.cwd = cwd
        self.ws = ws
        self._sentinel_buffer = ""

        if IS_WINDOWS:
            shell = os.environ.get("COMSPEC", "cmd.exe")
            self.proc = await asyncio.create_subprocess_exec(
                shell,
                "/Q",      # echo off
                "/D",      # disable AutoRun scripts/registry hooks
                "/V:ON",   # delayed expansion (!VAR!)
                "/K",      # keep shell alive for persistent session
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                cwd=cwd,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            )
        else:
            shell = self.command
            self.proc = await asyncio.create_subprocess_exec(
                shell,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                cwd=cwd,
            )

        self._read_task = asyncio.create_task(self._read_loop(ws))

    def _cancel_timeout(self) -> None:
        if self._timeout_task and not self._timeout_task.done():
            self._timeout_task.cancel()
        self._timeout_task = None

    def arm_timeout(self, timeout_s: int | None) -> None:
        """Arm/reset the watchdog for the current command."""
        self._cancel_timeout()

        if not timeout_s or timeout_s <= 0:
            return

        self._timeout_task = asyncio.create_task(self._timeout_watchdog(timeout_s))

    def _maybe_clear_timeout_from_output(self, decoded: str) -> None:
        """
        Completion sentinel may arrive split across chunks, so keep a rolling buffer.
        """
        if not decoded:
            return

        self._sentinel_buffer = (self._sentinel_buffer + decoded)[-512:]

        if _WINDOWS_SENTINEL_RESULT.search(self._sentinel_buffer):
            self._cancel_timeout()
            self._sentinel_buffer = ""

    async def _send_started_message(self) -> None:
        if not self.ws:
            return

        started_msg = {
            "type": "pty_started",
            "session_id": self.session_id,
            "platform": sys.platform,
            "mode": self.mode,
        }
        if self.mode == "restricted" and self.allowed_dirs:
            started_msg["allowed_dirs"] = self.allowed_dirs

        await self.ws.send(json.dumps(started_msg))

    async def _timeout_watchdog(self, timeout_s: int) -> None:
        try:
            await asyncio.sleep(timeout_s)

            if not self.proc or self.proc.returncode is not None:
                return

            print_pty_log(
                self.session_id,
                f"Command timed out after {timeout_s}s; sending Ctrl+C/Break",
                "error",
            )

            interrupted = False
            try:
                interrupted = await self.interrupt()
            except Exception:
                interrupted = False

            # On Windows persistent cmd sessions, restart is the safest way to guarantee
            # the shell is usable again after an interrupt/timeout.
            restarted = await self.restart(self.ws)

            if restarted and self.ws:
                await self.ws.send(json.dumps({
                    "type": "pty_output",
                    "session_id": self.session_id,
                    "data": (
                        f"\r\nCommand timed out after {timeout_s}s. "
                        f"Sent Ctrl+C/Break and restarted shell.\r\n"
                        f"{_SENTINEL}130{_SENTINEL}\r\n"
                    ),
                }))
                await self._send_started_message()
                print_pty_log(
                    self.session_id,
                    "Timed out, interrupted, and restarted",
                    "success",
                )
            elif self.ws:
                await self.ws.send(json.dumps({
                    "type": "pty_error",
                    "session_id": self.session_id,
                    "error": (
                        f"Command timed out after {timeout_s}s; "
                        f"interrupt={interrupted}, restart failed"
                    ),
                }))
                print_pty_log(
                    self.session_id,
                    "Timeout interrupt failed and restart failed",
                    "error",
                )

        except asyncio.CancelledError:
            pass

    async def _read_loop(self, ws):
        """Read output from stdout and send over WebSocket."""
        try:
            while True:
                if not self.proc or not self.proc.stdout:
                    break

                data = await self.proc.stdout.read(4096)
                if not data:
                    break

                decoded = data.decode("utf-8", errors="replace")

                # Cancel watchdog once sentinel completion appears
                self._maybe_clear_timeout_from_output(decoded)

                # Echo output to stdout for observability
                for line in decoded.splitlines():
                    print_cmd_log(self.session_id, line)

                await ws.send(json.dumps({
                    "type": "pty_output",
                    "session_id": self.session_id,
                    "data": decoded,
                }))

            if self.proc:
                try:
                    exit_code = await asyncio.wait_for(self.proc.wait(), timeout=5.0)
                except asyncio.TimeoutError:
                    try:
                        self.proc.kill()
                    except ProcessLookupError:
                        pass
                    exit_code = -1
            else:
                exit_code = -1

            await ws.send(json.dumps({
                "type": "pty_exited",
                "session_id": self.session_id,
                "exit_code": exit_code,
            }))
        except asyncio.CancelledError:
            raise
        except Exception as e:
            try:
                await ws.send(json.dumps({
                    "type": "pty_error",
                    "session_id": self.session_id,
                    "error": str(e),
                }))
            except Exception:
                pass

    async def send_input(self, data: str) -> None:
        """Write data to the process stdin."""
        if self.proc and self.proc.stdin and self.proc.returncode is None:
            self.proc.stdin.write(data.encode("utf-8"))
            await self.proc.stdin.drain()

    async def interrupt(self) -> bool:
        """
        Abort the current command as best as possible.

        On Windows:
        1. Try CTRL_BREAK_EVENT (best available equivalent here)
        2. Fall back to killing child processes
        """
        if not self.proc or self.proc.returncode is not None:
            return False

        if IS_WINDOWS:
            try:
                self.proc.send_signal(signal.CTRL_BREAK_EVENT)
                await asyncio.sleep(0.4)
                return True
            except Exception:
                pass

        try:
            import psutil
            parent = psutil.Process(self.proc.pid)
            children = parent.children(recursive=True)

            for child in children:
                try:
                    child.kill()
                except psutil.NoSuchProcess:
                    pass

            psutil.wait_procs(children, timeout=2)
            return len(children) > 0
        except Exception:
            return False

    async def restart(self, ws, cwd: str | None = None) -> bool:
        """
        Kill the shell and spawn a new one in the same working directory.
        """
        target_cwd = cwd or self.cwd

        if target_cwd is None and self.proc and self.proc.pid:
            try:
                import psutil
                target_cwd = psutil.Process(self.proc.pid).cwd()
            except Exception:
                pass

        await self.close()

        try:
            await self.start(ws, target_cwd)
            return True
        except Exception:
            return False

    async def close(self) -> None:
        """Terminate the process and clean up."""
        self._cancel_timeout()

        if self._read_task and not self._read_task.done():
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
            self._read_task = None

        if self.proc and self.proc.returncode is None:
            try:
                self.proc.terminate()
                await asyncio.wait_for(self.proc.wait(), timeout=3.0)
            except (asyncio.TimeoutError, ProcessLookupError):
                try:
                    self.proc.kill()
                except ProcessLookupError:
                    pass
                except Exception:
                    pass

        self.proc = None



def _strip_existing_completion_wrapper(data: str) -> str:
    if not data:
        return data
    stripped = data.rstrip("\r\n")
    stripped = _UNIX_SENTINEL_SUFFIX.sub("", stripped)
    stripped = _WINDOWS_SENTINEL_SUFFIX.sub("", stripped)
    return stripped.strip()

_UNIX_PRINTF_NEWLINE_SUFFIX = re.compile(
    r"""\s*(?:;|&&)\s*printf\s+['"]\\n['"]\s*$""",
    re.IGNORECASE,
)

def _normalize_windows_input(data: str) -> str:
    """
    Windows persistent shell runs in cmd.exe, so strip Unix-only suffixes
    like '; printf "\\n"' before wrapping with the Windows sentinel.
    """
    if not data:
        return data

    stripped = _strip_existing_completion_wrapper(data)
    stripped = _UNIX_PRINTF_NEWLINE_SUFFIX.sub("", stripped)
    return stripped.strip()

def _ensure_windows_persistent_completion(data: str) -> str:
    if not IS_WINDOWS:
        return data

    if not data:
        return data

    base = _normalize_windows_input(data)

    # Empty or wrapper-only input: do not send a broken command
    if not base:
        return f"echo {_SENTINEL}0{_SENTINEL}\r\n"

    return f"{base} & echo {_SENTINEL}!ERRORLEVEL!{_SENTINEL}\r\n"

async def connect(
    ws_url: str,
    token: str,
    mode: str = "restricted",
    allowed_dirs: list[str] | None = None,
):
    """Connect to the server WebSocket and process commands."""
    ws_endpoint = f"{ws_url}/v1/terminal/ws/connect"
    print_status("~", f"Connecting to {BOLD}{ws_endpoint}{RESET}", C)

    try:
        async with websockets.connect(ws_endpoint) as ws:
            await ws.send(json.dumps({"type": "auth", "token": token}))
            auth_resp = json.loads(await ws.recv())

            if auth_resp.get("type") == "error":
                print_status("x", f"Auth failed: {auth_resp.get('message')}", RED)
                return

            if auth_resp.get("type") == "auth_ok":
                user_id = auth_resp.get('user_id', 'unknown')
                print_status(">", f"Connected as {BOLD}{user_id}{RESET}", GREEN)
            else:
                print_status("x", f"Unexpected response: {auth_resp}", RED)
                return

            print()
            if mode == "restricted" and allowed_dirs:
                mode_label = f"{GREEN}restricted{RESET}"
                print(f"  {C}Ready{RESET} {GREY}| Mode: {mode_label} {GREY}| Ctrl+C to disconnect{RESET}")
                for d in allowed_dirs:
                    print(f"         {GREY}Allowed: {d}{RESET}")
            else:
                mode_label = f"{YELLOW}unrestricted{RESET}"
                print(f"  {C}Ready{RESET} {GREY}| Mode: {mode_label} {GREY}| Ctrl+C to disconnect{RESET}")
            print(f"  {GREY}{'─' * 50}{RESET}")
            print()

            active_pty_sessions: dict[str, PTYProcess] = {}

            try:
                async for message in ws:
                    msg = json.loads(message)
                    msg_type = msg.get("type")

                    if msg_type == "command":
                        request_id = msg.get("request_id", "")
                        command = msg.get("command", "")
                        print_cmd_log(request_id, f"$ {BOLD}{command}{RESET}")

                        result = await run_command(
                            command,
                            mode=mode,
                            allowed_dirs=allowed_dirs,
                        )
                        exit_code = result["exit_code"]
                        success = exit_code == 0
                        status_text = (
                            f"{GREEN}OK{RESET}" if success
                            else f"{RED}FAILED (exit {exit_code}){RESET}"
                        )
                        print_cmd_log(request_id, status_text, success)

                        await ws.send(json.dumps({
                            "type": "result",
                            "request_id": request_id,
                            **result,
                        }))

                    elif msg_type == "pty_start":
                        session_id = msg.get("session_id", "")
                        command = msg.get("command", "bash")
                        display_command = os.environ.get("COMSPEC", "cmd.exe") if IS_WINDOWS else command
                        print_pty_log(session_id, f"Starting: {BOLD}{display_command}{RESET}")
                        cols = msg.get("cols", 120)
                        rows = msg.get("rows", 40)
                        print_pty_log(session_id, f"Starting: {BOLD}{command}{RESET}")

                        try:
                            if IS_WINDOWS:
                                pty_proc = PipeProcess(
                                    session_id,
                                    command,
                                    cols,
                                    rows,
                                    mode=mode,
                                    allowed_dirs=allowed_dirs,
                                )
                            else:
                                pty_proc = PTYProcess(session_id, command, cols, rows)
                            cwd = allowed_dirs[0] if allowed_dirs else None
                            await pty_proc.start(ws, cwd=cwd)
                            active_pty_sessions[session_id] = pty_proc
                            started_msg = {
                                "type": "pty_started",
                                "session_id": session_id,
                                "platform": sys.platform,
                                "mode": mode,
                            }
                            if mode == "restricted" and allowed_dirs:
                                started_msg["allowed_dirs"] = allowed_dirs
                            await ws.send(json.dumps(started_msg))
                            print_pty_log(session_id, "Started", "success")
                        except Exception as e:
                            print_pty_log(session_id, f"Failed: {e}", "error")
                            await ws.send(json.dumps({
                                "type": "pty_error",
                                "session_id": session_id,
                                "error": str(e),
                            }))

                    elif msg_type == "pty_input":
                        session_id = msg.get("session_id", "")
                        data = msg.get("data", "")
                        display_cmd = _clean_cmd_for_display(data)
                        if display_cmd:
                            print_pty_log(session_id, f"$ {BOLD}{display_cmd}{RESET}")

                        pty_proc = active_pty_sessions.get(session_id)
                        if pty_proc:
                            # Validate the original command before any Windows wrapper is added
                            if mode == "restricted" and allowed_dirs:
                                pty_pid = pty_proc.proc.pid if pty_proc.proc else None
                                ok, reason = validate_command(data, allowed_dirs, pid=pty_pid)
                                if not ok:
                                    err_msg = (
                                        f"\r\n{reason}\r\n"
                                        f"{_SENTINEL}1{_SENTINEL}\r\n"
                                    )
                                    await ws.send(json.dumps({
                                        "type": "pty_output",
                                        "session_id": session_id,
                                        "data": err_msg,
                                    }))
                                    print_pty_log(session_id, f"Blocked: {reason}", "error")
                                    continue
                            
                            try:
                                data_to_send = data

                                # Windows persistent sessions must always emit the sentinel.
                                # If the server forgot to wrap the command, fix it here.
                                if IS_WINDOWS and isinstance(pty_proc, PipeProcess):
                                    data_to_send = _ensure_windows_persistent_completion(data)

                                await pty_proc.send_input(data_to_send)

                                # Arm watchdog only for persistent Windows sessions.
                                # Prefer an explicit timeout from server; fallback to 120s if you want.
                                if IS_WINDOWS and isinstance(pty_proc, PipeProcess):
                                    timeout_s = msg.get("timeout_sec")
                                    if timeout_s is not None:
                                        try:
                                            timeout_s = int(timeout_s)
                                        except Exception:
                                            timeout_s = None

                                    if timeout_s is None:
                                        timeout_s = 40

                                    pty_proc.arm_timeout(timeout_s)

                            except Exception as e:
                                print_pty_log(session_id, f"Input error: {e}", "error")

                        else:
                            print_pty_log(session_id, "Input for unknown session", "error")


                    elif msg_type == "pty_close":
                        session_id = msg.get("session_id", "")
                        pty_proc = active_pty_sessions.pop(session_id, None)
                        if pty_proc:
                            print_pty_log(session_id, "Closing")
                            await pty_proc.close()
                        else:
                            print_pty_log(session_id, "Close for unknown session", "error")

                    elif msg_type == "pty_interrupt":
                        session_id = msg.get("session_id", "")
                        pty_proc = active_pty_sessions.get(session_id)

                        if not pty_proc:
                            print_pty_log(session_id, "Interrupt for unknown session", "error")
                            continue

                        print_pty_log(session_id, "Interrupt requested")

                        interrupted = False
                        try:
                            if hasattr(pty_proc, "interrupt"):
                                interrupted = await pty_proc.interrupt()
                        except Exception:
                            interrupted = False

                        if IS_WINDOWS and hasattr(pty_proc, "restart"):
                            restarted = await pty_proc.restart(ws)
                            if restarted:
                                await ws.send(json.dumps({
                                    "type": "pty_output",
                                    "session_id": session_id,
                                    "data": f"\r\nInterrupted; shell restarted.\r\n{_SENTINEL}130{_SENTINEL}\r\n",
                                }))

                                started_msg = {
                                    "type": "pty_started",
                                    "session_id": session_id,
                                    "platform": sys.platform,
                                    "mode": mode,
                                }
                                if mode == "restricted" and allowed_dirs:
                                    started_msg["allowed_dirs"] = allowed_dirs

                                await ws.send(json.dumps(started_msg))
                                print_pty_log(session_id, "Interrupted and restarted", "success")
                            else:
                                await ws.send(json.dumps({
                                    "type": "pty_error",
                                    "session_id": session_id,
                                    "error": "Interrupt failed and restart failed",
                                }))
                                print_pty_log(session_id, "Interrupt failed and restart failed", "error")
                        else:
                            status = "interrupt sent" if interrupted else "no child processes found"
                            print_pty_log(session_id, f"Interrupt: {status}")


                    elif msg_type == "pty_restart":
                        session_id = msg.get("session_id", "")
                        pty_proc = active_pty_sessions.get(session_id)
                        if pty_proc:
                            print_pty_log(session_id, "Restarting...")
                            success = await pty_proc.restart(ws)
                            if success:
                                started_msg = {
                                    "type": "pty_started",
                                    "session_id": session_id,
                                    "platform": sys.platform,
                                    "mode": mode,
                                }
                                if mode == "restricted" and allowed_dirs:
                                    started_msg["allowed_dirs"] = allowed_dirs
                                await ws.send(json.dumps(started_msg))
                                print_pty_log(session_id, "Restarted", "success")
                            else:
                                await ws.send(json.dumps({
                                    "type": "pty_error",
                                    "session_id": session_id,
                                    "error": "Restart failed",
                                }))
                        else:
                            print_pty_log(session_id, "Restart for unknown session", "error")

                    elif msg_type == "ping":
                        await ws.send(json.dumps({"type": "pong"}))

                    else:
                        print_status("?", f"Unknown message: {msg_type}", YELLOW)
            finally:
                for sid, pty_proc in active_pty_sessions.items():
                    try:
                        await pty_proc.close()
                    except Exception:
                        pass

    except websockets.exceptions.ConnectionClosed as e:
        print()
        print_status("!", f"Connection closed: {e}", YELLOW)
    except ConnectionRefusedError:
        print()
        print_status("x", f"Could not connect to {ws_endpoint}. Is the server running?", RED)
    except Exception as e:
        print()
        print_status("x", f"Error: {e}", RED)


def main():
    parser = argparse.ArgumentParser(
        description="Kiwi AI CLI Agent — execute terminal commands for LLM agents"
    )
    subparsers = parser.add_subparsers(dest="command")

    connect_parser = subparsers.add_parser("connect", help="Connect to the server")
    connect_parser.add_argument(
        "--server",
        default="app",
        help=(
            "Server to connect to. Use a preset name (app, dev, local) "
            "or a full URL (e.g. https://custom.server.com). "
            "Presets: app=api.meetkiwi.ai, dev=dev.api.myautobots.com, "
            "local=localhost:8000 (default: app)"
        ),
    )
    connect_parser.add_argument(
        "--email",
        default=None,
        help="Email address (will prompt if not provided)",
    )
    connect_parser.add_argument(
        "--token",
        default=None,
        help="Access token to skip login (used by autobots-tui for shared auth)",
    )
    connect_parser.add_argument(
        "--scope",
        choices=["restricted", "full"],
        default="restricted",
        help="Execution scope. restricted (default) limits commands to the current directory.",
    )
    connect_parser.add_argument(
        "--allow",
        action="append",
        dest="allow_dirs",
        default=[],
        metavar="PATH",
        help="Additional allowed directory (can be specified multiple times).",
    )

    args = parser.parse_args()

    if args.command == "connect":
        print_banner()

        preset = SERVER_PRESETS.get(args.server)
        if preset:
            ws_url = preset["ws"]
            http_url = preset["http"]
        else:
            url = args.server.rstrip("/")
            if url.startswith("wss://"):
                ws_url = url
                http_url = url.replace("wss://", "https://", 1)
            elif url.startswith("ws://"):
                ws_url = url
                http_url = url.replace("ws://", "http://", 1)
            elif url.startswith("https://"):
                http_url = url
                ws_url = url.replace("https://", "wss://", 1)
            elif url.startswith("http://"):
                http_url = url
                ws_url = url.replace("http://", "ws://", 1)
            else:
                http_url = f"https://{url}"
                ws_url = f"wss://{url}"

        server_label = args.server if args.server in SERVER_PRESETS else "custom"
        print_status(">", f"Server: {BOLD}{server_label}{RESET} ({http_url})", C)

        # Build allowed_dirs list
        mode = args.scope
        allowed_dirs = None
        if mode == "restricted":
            allowed_dirs = [os.path.realpath(os.getcwd())]
            for d in args.allow_dirs:
                resolved = os.path.realpath(d)
                if not os.path.isdir(resolved):
                    print_status("x", f"Directory not found: {d}", RED)
                    sys.exit(1)
                if resolved not in allowed_dirs:
                    allowed_dirs.append(resolved)

            print_status(">", f"Mode: {BOLD}restricted{RESET}", C)
            for d in allowed_dirs:
                print_status(" ", f"  Allowed: {d}", GREY)
        else:
            print_status(">", f"Mode: {BOLD}unrestricted{RESET}", YELLOW)

        print()

        loop = asyncio.new_event_loop()

        provided_token = args.token or os.environ.get("KIWI_AUTH_TOKEN")
        if provided_token:
            # Use provided token — skip interactive login
            token = provided_token
            print_section("Authentication")
            print_status(">", "Using provided access token", GREEN)
        else:
            print_section("Authentication")
            email = args.email
            if email:
                print_status(">", f"Email: {email}", GREY)
            else:
                email = input(f"  {C}>{RESET}  Email: ")
            password = getpass.getpass(f"  {C}>{RESET}  Password: ")
            print()

            print_status("~", f"Authenticating with {BOLD}{http_url}{RESET}...", C)
            try:
                token = loop.run_until_complete(login(http_url, email, password))
                print_status(">", "Login successful!", GREEN)
            except Exception as e:
                print_status("x", f"Login failed: {e}", RED)
                loop.close()
                sys.exit(1)

        print_section("Connection")

        _shutting_down = False

        def shutdown():
            nonlocal _shutting_down
            if _shutting_down:
                os._exit(0)
            _shutting_down = True
            print()
            print_status("!", "Disconnecting...", YELLOW)
            for task in asyncio.all_tasks(loop):
                task.cancel()

        signal.signal(signal.SIGINT, lambda *_: shutdown())

        try:
            loop.run_until_complete(connect(ws_url, token, mode=mode, allowed_dirs=allowed_dirs))
        except asyncio.CancelledError:
            pass
        finally:
            loop.close()
            print()
            print(f"  {GREY}{'─' * 50}{RESET}")
            print_status(">", "Disconnected. Goodbye!", C)
            print()
    else:
        print_banner()
        parser.print_help()


if __name__ == "__main__":
    main()
