"""Kiwi AI CLI Agent — connect your local machine to AI-powered automation."""

__version__ = "0.1.0"
