---
title: AI Agent 跑远端任务总超时？remote-sandbox-mcp 安装与使用指南
author: db.xiang
cover: /Users/xiangdebin/Documents/code/remotesandboxmcp/docs/cover.png
source_url: https://pypi.org/project/remote-sandbox-mcp/
---

# AI Agent 跑远端任务总超时？remote-sandbox-mcp 安装与使用指南

如果你已经开始让 Codex、Claude 之类的 AI Agent 直接参与开发，很快就会遇到一个现实问题：本地环境不够用，远端任务又不稳定。

常见情况是：

- 要跑远端 GPU 机器
- 单次工具调用有超时，长任务容易中断
- SSH 断开后，任务状态不好追
- 多台机器同时存在时，不知道该让 Agent 选哪台

`remote-sandbox-mcp` 做的事情很直接：把远端 SSH 服务器封装成一个可被 Agent 调用的 MCP Server，让 AI 可以用统一工具去选机器、传代码、跑命令、查日志、取回结果。

它的核心能力包括：

- 多沙箱管理
- 持久 SSH 会话
- 短任务和长任务分流执行
- 基于 `tmux` 的后台任务
- 本地 watchdog 持续监控
- 本地与远端目录双向同步

这篇文章不讲概念营销，直接按三个问题来写：

1. 怎么安装
2. 怎么使用
3. Skill 在里面解决什么问题

## 一、怎么安装

这个项目已经发布到 PyPI，最简单的方式是直接安装。

```bash
pip install remote-sandbox-mcp
# 或
uv tool install remote-sandbox-mcp
```

如果你用的是 Claude Code，也可以直接添加成 MCP：

### 单沙箱

```bash
claude mcp add remote-sandbox \
  -e REMOTE_HOST=192.168.9.16 \
  -e REMOTE_PORT=22 \
  -e REMOTE_USER=your_user \
  -e REMOTE_PASSWORD=your_password \
  -- uvx remote-sandbox-mcp
```

### 多沙箱

```bash
claude mcp add remote-sandbox \
  -e REMOTE_SANDBOX_LIST='[{"name":"A100","host":"192.168.9.15","port":22,"user":"ubuntu","password":"xxx"},{"name":"H100","host":"192.168.9.16","port":22,"user":"ubuntu","password":"xxx"}]' \
  -- uvx remote-sandbox-mcp
```

安装完成后可以先验证：

```bash
claude mcp list
```

如果你用的是 Codex，推荐在 MCP 配置里直接指向安装后的命令：

```toml
[mcp_servers."remote-sandbox"]
command = "/absolute/path/to/remote-sandbox-mcp"
enabled = true

[mcp_servers."remote-sandbox".env]
REMOTE_SANDBOX_LIST = '[{"name":"A100","host":"192.168.9.15","port":22,"user":"ubuntu","password":"xxx"},{"name":"H100","host":"192.168.9.16","port":22,"user":"ubuntu","password":"xxx"}]'
```

如果你不确定二进制路径，也可以直接走 Python 模块入口：

```toml
[mcp_servers."remote-sandbox"]
command = "/absolute/path/to/python"
args = ["-m", "remote_sandbox_mcp.server"]
enabled = true
```

## 二、怎么配置

这个项目支持单沙箱和多沙箱两种配置方式，也支持密码和私钥两种认证方式。

### 单沙箱

```bash
export REMOTE_HOST=1.2.3.4
export REMOTE_PORT=22
export REMOTE_USER=your_user
export REMOTE_PASSWORD=your_password
```

或者使用私钥：

```bash
export REMOTE_HOST=1.2.3.4
export REMOTE_USER=your_user
export REMOTE_KEY_FILE=~/.ssh/id_ed25519
export REMOTE_KEY_PASSPHRASE=
```

### 多沙箱

```bash
export REMOTE_SANDBOX_LIST='[
  {"name": "gpu1", "host": "10.0.0.1", "user": "ubuntu", "password": "secret1"},
  {"name": "gpu2", "host": "10.0.0.2", "user": "ubuntu", "key_file": "~/.ssh/id_ed25519"},
  {"name": "L20",  "host": "10.0.0.3", "user": "root",   "key_file": "~/.ssh/id_rsa", "key_passphrase": "mypass"}
]'
```

几个常用字段：

- `name`：沙箱名称
- `host`：SSH 地址
- `port`：SSH 端口，默认 `22`
- `user`：登录用户
- `password`：密码认证
- `key_file`：私钥认证
- `key_passphrase`：私钥口令

如果你的代码目录很大，还可以留意这两个上传阈值：

- `REMOTE_SANDBOX_INLINE_SYNC_MAX_FILES`
- `REMOTE_SANDBOX_INLINE_SYNC_MAX_BYTES`

超过阈值时，`sync_local_to_remote` 会自动切到后台 worker，而不是继续阻塞当前调用。

## 三、怎么用

这部分只看最常见的用法。

### 1. 先检查机器状态

多沙箱场景下，第一步通常不是直接执行命令，而是先看资源情况：

- `list_sandboxes(check_resources=true)`
- `select_sandbox(sandbox_name=...)`
- `get_active_sandbox()`

这样 Agent 可以先选择更空闲的机器，再把任务发过去。

### 2. 短任务直接执行

短任务适合用 `exec_bash`，比如环境检查、快速测试、安装依赖。

参数重点是：

- `command`
- `cwd`
- `timeout_s`
- `sandbox_name`

这个接口适合明显短于两分钟的任务。因为很多 MCP Client 会对单次 `tools/call` 施加额外超时，长任务不建议继续走这里。

### 3. 长任务走后台

长任务应该走 `exec_bash_background`，例如：

- 模型训练
- 长时间构建
- 批处理脚本
- 需要持续产生日志的任务

这个接口会做几件事：

- 在远端 `tmux` 里启动任务
- 把输出写入日志
- 返回 `tmux_session`
- 默认登记 watchdog
- 返回 `watch_id` 作为后续查询句柄

后续就用 `check_background_task(watch_id=...)` 轮询状态，不要一直阻塞等待。

典型流程如下：

```text
list_sandboxes(check_resources=true)
-> select_sandbox(...)
-> sync_local_to_remote(...)
-> exec_bash_background(...)
-> check_background_task(watch_id=...)
-> read_remote_file(...)
-> sync_remote_to_local(...)
```

### 4. 文件如何同步

文件相关常用工具有四个：

- `sync_local_to_remote`
- `check_file_transfer_task`
- `read_remote_file`
- `sync_remote_to_local`

其中 `sync_local_to_remote` 现在不是简单的“一把传完”。如果文件很多或者目录太大，它会自动切到后台同步，避免一次工具调用直接超时。

这对于代码仓库、数据目录、构建产物都比较实用。

## 四、Skill 在这里做什么

如果只有 MCP 工具，Agent 虽然“能用”，但不一定“会正确用”。

这个仓库里专门提供了一条 Skill：

`skills/remote-sandbox-script-exec/SKILL.md`

它做的事情很明确，就是把远端执行流程固定下来。按照这条 Skill，Agent 在处理脚本、测试、构建任务时，会优先遵循下面这条链路：

1. 先查看多台沙箱负载
2. 选择当前最空闲的机器
3. 在远端准备 `uv` 运行环境
4. 同步本地代码到远端
5. 短任务使用 `exec_bash`
6. 长任务先准备 checkpoint、run script、resume script
7. 再通过 `exec_bash_background` 启动
8. 后续统一通过 `watch_id` 轮询

这个 Skill 最大的作用，不是新增接口，而是减少 Agent 的误操作。

比如它会约束：

- 长任务不能直接当短任务跑
- 长任务要优先考虑 checkpoint 和 resume
- 后台任务启动后不要重复创建
- 连接短暂失败后要继续查原任务，而不是再起一个新任务

所以这里可以把两者的关系理解成：

- MCP 负责提供能力
- Skill 负责规定正确用法

## 五、几个值得知道的技术细节

如果你只想尽快用起来，其实看到这里就够了。下面这部分是项目内部实现上比较关键的几个点。

### 1. 长连接而不是每次重新 SSH

项目为每个沙箱维持持久 SSH 会话，并带有健康检查和重连逻辑。这样做的好处是减少频繁建连的开销，也降低了短时间内多次调用时的不稳定性。

### 2. 双层超时控制

`exec_bash` 不只是客户端超时，远端也会配合 `timeout` 做超时兜底。这样可以避免“客户端超时了，但远端命令其实还在继续跑”的问题。

### 3. 长任务默认带监控链路

`exec_bash_background` 会把长任务放进 `tmux`，并通过日志、`watch_id`、watchdog 建立后续观测链路。即使 Codex 或 Claude 当前会话结束了，监控也不一定立刻丢。

### 4. 上传大目录时自动切后台

这是一个很实用的细节。很多 MCP 工具在处理大目录时真正的问题不是“不能传”，而是“调用窗口太短”。这个项目在文件数或字节数超过阈值时自动切后台 worker，能明显减少传输时卡死的问题。

## 六、适合什么场景

如果你的需求只是偶尔 SSH 到一台机器上跑一条命令，这个项目不一定是必须的。

它更适合下面这些场景：

- 让 AI Agent 使用远端 GPU 服务器
- 让 Agent 稳定执行长时间构建或测试
- 多台机器并存，需要自动选择更空闲的节点
- 需要把日志、checkpoint、结果文件完整带回本地
- 希望在 Codex 和 Claude 之间复用同一套远端执行能力

## 结语

`remote-sandbox-mcp` 可以把“远端 SSH 机器”变成“AI Agent 可调用的执行沙箱”，而 Skill 进一步把执行流程约束成可重复、可恢复的工作流。

如果你当前正卡在“Agent 能写代码，但远端执行不稳定”这个问题上，这个项目值得直接试一遍。
