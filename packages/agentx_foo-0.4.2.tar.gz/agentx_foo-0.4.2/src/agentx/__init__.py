"""AgentX - Native compiled Python agent framework."""

__version__ = "0.4.2"
