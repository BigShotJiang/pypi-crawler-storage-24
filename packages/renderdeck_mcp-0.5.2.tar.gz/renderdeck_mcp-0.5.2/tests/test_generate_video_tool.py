"""Unit tests for renderdeck_mcp.tools.generate_video.

All external dependencies are mocked — no real filesystem, ffmpeg, or edge-tts calls.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

PROMPT_WITH_NARRATION = """\
# Test Deck

## General
Test context.

---

## Slide 01 — Introduction
A test image prompt.

### Speaker Notes
**Say:** Welcome to the test presentation.
**Time:** 30 seconds

---

## Slide 02 — Main Point
Another image prompt.

### Speaker Notes
**Say:** This is the main point of the talk.
**Say:** Let me elaborate on this further.
"""

PROMPT_NO_NARRATION = """\
# Test Deck

## General
Test context.

---

## Slide 01 — No Say Lines
A test image prompt.

### Speaker Notes
Just regular notes, no Say lines.
"""

FAKE_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TARGET_CHECK_FFMPEG = "renderdeck_mcp.tools.generate_video.check_ffmpeg"
_TARGET_GENERATE_TTS = "renderdeck_mcp.tools.generate_video._generate_tts"
_TARGET_MAKE_SEGMENT = "renderdeck_mcp.tools.generate_video._make_segment"
_TARGET_CONCAT = "renderdeck_mcp.tools.generate_video._concat_segments"
_TARGET_CACHE_BASE = "renderdeck_mcp.tools.generate_video._CACHE_BASE_DIR"
_TARGET_SHUTIL_COPY2 = "renderdeck_mcp.tools.generate_video.shutil.copy2"

# Fake MP3 header (>100 bytes so it passes validation)
FAKE_MP3 = b"\xff\xfb\x90\x00" + b"\x00" * 200


async def _valid_tts_mock(narration: str, voice: str, output_path: Path) -> None:
    """Mock TTS that writes a valid-size fake MP3."""
    output_path.write_bytes(FAKE_MP3)


def _setup_cache_dir(tmp_path: Path, project_name: str, slide_count: int) -> Path:
    """Create a fake cache directory with slide PNGs.

    Uses zero-padded slide numbers (slide_01.png) to match parser output.
    """
    cache_dir = tmp_path / project_name
    cache_dir.mkdir(parents=True)
    for i in range(1, slide_count + 1):
        # Parser returns zero-padded slide numbers like "01", "02"
        (cache_dir / f"slide_{i:02d}.png").write_bytes(FAKE_PNG)
    return tmp_path


# ---------------------------------------------------------------------------
# TC-01: Successful 2-slide video generation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc01_successful_video_generation(tmp_path: Path) -> None:
    """Full pipeline: 2 slides with narration produce a video."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    # Create a fake output file so stat() works
    def _fake_concat(segments: list[Path], out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"\x00" * 1024 * 1024)  # 1 MB fake
        return None

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, side_effect=_valid_tts_mock),
        patch(_TARGET_MAKE_SEGMENT, return_value=None),
        patch(_TARGET_CONCAT, side_effect=_fake_concat),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
            voice="aria",
        )

    assert result["status"] == "ok"
    assert result["slide_count"] == 2
    assert result["voice_used"] == "en-US-AriaNeural"
    assert "output_path" in result
    assert "video_size_mb" in result


# ---------------------------------------------------------------------------
# TC-02: Missing ffmpeg returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc02_missing_ffmpeg_returns_error() -> None:
    """If ffmpeg is not available, return clear error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    with patch(
        _TARGET_CHECK_FFMPEG, return_value="ffmpeg not found. Install with: brew install ffmpeg"
    ):
        result = await run_generate_video(
            project_name="test",
            slide_prompt_content=PROMPT_WITH_NARRATION,
        )

    assert result["status"] == "error"
    assert "ffmpeg" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-03: Missing cache directory returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc03_missing_cache_dir_returns_error(tmp_path: Path) -> None:
    """Non-existent cache directory produces error with guidance."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_CACHE_BASE, tmp_path),
    ):
        result = await run_generate_video(
            project_name="nonexistent_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
        )

    assert result["status"] == "error"
    assert "cache" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-04: No narration in slides returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc04_no_narration_returns_error(tmp_path: Path) -> None:
    """Slides without **Say:** lines produce error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 1)

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_NO_NARRATION,
        )

    assert result["status"] == "error"
    assert "narration" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-05: Empty prompt returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc05_empty_prompt_returns_error() -> None:
    """Empty prompt content produces error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    with patch(_TARGET_CHECK_FFMPEG, return_value=None):
        result = await run_generate_video(
            project_name="test",
            slide_prompt_content="",
        )

    assert result["status"] == "error"
    assert "no slides" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-06: Voice alias resolution
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc06_voice_alias_resolved(tmp_path: Path) -> None:
    """Voice alias 'roger' resolves to 'en-US-RogerNeural'."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    def _fake_concat(segments: list[Path], out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"\x00" * 1024)
        return None

    tts_voices_used: list[str] = []

    async def _tracking_tts(narration: str, voice: str, output_path: Path) -> None:
        tts_voices_used.append(voice)
        output_path.write_bytes(FAKE_MP3)

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, side_effect=_tracking_tts),
        patch(_TARGET_MAKE_SEGMENT, return_value=None),
        patch(_TARGET_CONCAT, side_effect=_fake_concat),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
            voice="roger",
        )

    assert result["status"] == "ok"
    assert result["voice_used"] == "en-US-RogerNeural"
    # Verify TTS was called with the resolved voice
    for v in tts_voices_used:
        assert v == "en-US-RogerNeural"


# ---------------------------------------------------------------------------
# TC-07: Slide range filtering
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc07_slide_range_filtering(tmp_path: Path) -> None:
    """Slide range '1' processes only slide 1."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    def _fake_concat(segments: list[Path], out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"\x00" * 1024)
        return None

    def _fake_copy2(src: str, dst: str) -> None:
        Path(dst).parent.mkdir(parents=True, exist_ok=True)
        Path(dst).write_bytes(b"\x00" * 1024)

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, side_effect=_valid_tts_mock),
        patch(_TARGET_MAKE_SEGMENT, return_value=None),
        patch(_TARGET_SHUTIL_COPY2, side_effect=_fake_copy2),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
            slides="1",
        )

    assert result["status"] == "ok"
    assert result["slide_count"] == 1


# ---------------------------------------------------------------------------
# TC-08: Invalid slide range returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc08_invalid_slide_range_returns_error(tmp_path: Path) -> None:
    """Slide range outside deck bounds produces error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            slides="99-100",
        )

    assert result["status"] == "error"
    assert "range" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-09: parse_slide_range unit tests
# ---------------------------------------------------------------------------


def test_tc09_parse_slide_range() -> None:
    """parse_slide_range handles ranges, lists, and combinations."""
    from renderdeck_mcp.tools.generate_video import parse_slide_range

    assert parse_slide_range("1-3", 5) == [1, 2, 3]
    assert parse_slide_range("2,5,7", 10) == [2, 5, 7]
    assert parse_slide_range("1-3,7", 10) == [1, 2, 3, 7]
    # Out of range filtered
    assert parse_slide_range("1-3", 2) == [1, 2]
    assert parse_slide_range("99", 5) == []


# ---------------------------------------------------------------------------
# TC-10: FFmpeg segment error propagates
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc10_ffmpeg_segment_error_propagates(tmp_path: Path) -> None:
    """FFmpeg failure during segment creation returns error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, side_effect=_valid_tts_mock),
        patch(_TARGET_MAKE_SEGMENT, return_value="FFmpeg segment error: encoding failed"),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
        )

    assert result["status"] == "error"
    assert "ffmpeg" in str(result["message"]).lower()


# ===========================================================================
# EXE-1095 regression tests: FFmpeg hangs on 0-byte TTS audio
# ===========================================================================


# ---------------------------------------------------------------------------
# TC-11: Zero-byte TTS cache is invalidated and regenerated (EXE-1095)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc11_zero_byte_tts_cache_invalidated(tmp_path: Path) -> None:
    """A 0-byte cached TTS MP3 should be regenerated, not reused (EXE-1095)."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    tts_dir = tmp_path / "test_project" / "tts_cache"
    tts_dir.mkdir(parents=True)

    # Pre-seed a 0-byte MP3 (simulates edge-tts silent failure)
    zero_mp3 = tts_dir / "slide_01.mp3"
    zero_mp3.write_bytes(b"")

    output_mp4 = tmp_path / "output.mp4"

    tts_called_for_slide_01 = False

    async def _fake_tts(narration: str, voice: str, output_path: Path) -> None:
        nonlocal tts_called_for_slide_01
        if "slide_01" in str(output_path):
            tts_called_for_slide_01 = True
        # Write a valid-size fake MP3
        output_path.write_bytes(b"\xff\xfb\x90\x00" + b"\x00" * 200)

    def _fake_concat(segments: list[Path], out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"\x00" * 1024)
        return None

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, side_effect=_fake_tts),
        patch(_TARGET_MAKE_SEGMENT, return_value=None),
        patch(_TARGET_CONCAT, side_effect=_fake_concat),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
            voice="aria",
        )

    assert result["status"] == "ok"
    # The 0-byte file should have triggered re-generation
    assert tts_called_for_slide_01, "TTS should be re-called for 0-byte cached MP3"


# ---------------------------------------------------------------------------
# TC-12: Slide with bad audio after TTS is skipped, not passed to FFmpeg (EXE-1095)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc12_bad_audio_slide_skipped(tmp_path: Path) -> None:
    """If TTS produces a 0-byte file, the slide is skipped (not sent to FFmpeg)."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    async def _failing_tts(narration: str, voice: str, output_path: Path) -> None:
        if "slide_01" in str(output_path):
            # Simulate edge-tts failure: write 0 bytes
            output_path.write_bytes(b"")
        else:
            output_path.write_bytes(b"\xff\xfb\x90\x00" + b"\x00" * 200)

    segment_images_used: list[str] = []

    def _tracking_make_segment(
        image_path: Path, audio_path: Path, out_path: Path, duration: float | None = None
    ) -> str | None:
        segment_images_used.append(image_path.name)
        return None

    def _fake_copy2(src: str, dst: str) -> None:
        Path(dst).parent.mkdir(parents=True, exist_ok=True)
        Path(dst).write_bytes(b"\x00" * 1024)

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, side_effect=_failing_tts),
        patch(_TARGET_MAKE_SEGMENT, side_effect=_tracking_make_segment),
        patch(_TARGET_SHUTIL_COPY2, side_effect=_fake_copy2),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
            voice="aria",
        )

    assert result["status"] == "ok"
    # Slide 01 should be skipped — only slide 02 sent to FFmpeg
    assert "slide_01.png" not in segment_images_used
    assert result["slide_count"] == 1
    assert "skipped" in result


# ---------------------------------------------------------------------------
# TC-13: FFmpeg subprocess timeout is caught (EXE-1095)
# ---------------------------------------------------------------------------


def test_tc13_make_segment_timeout_caught() -> None:
    """_make_segment catches subprocess.TimeoutExpired and returns error."""
    import subprocess as sp

    from renderdeck_mcp.tools.generate_video import _make_segment

    with patch(
        "renderdeck_mcp.tools.generate_video.subprocess.run",
        side_effect=sp.TimeoutExpired(cmd=["ffmpeg"], timeout=120),
    ):
        err = _make_segment(Path("img.png"), Path("audio.mp3"), Path("out.mp4"), duration=5.0)

    assert err is not None
    assert "timeout" in err.lower()


def test_tc13b_concat_segments_timeout_caught(tmp_path: Path) -> None:
    """_concat_segments catches subprocess.TimeoutExpired and returns error."""
    import subprocess as sp

    from renderdeck_mcp.tools.generate_video import _concat_segments

    seg = tmp_path / "seg.mp4"
    seg.write_bytes(b"\x00" * 100)

    with patch(
        "renderdeck_mcp.tools.generate_video.subprocess.run",
        side_effect=sp.TimeoutExpired(cmd=["ffmpeg"], timeout=180),
    ):
        err = _concat_segments([seg], tmp_path / "out.mp4")

    assert err is not None
    assert "timeout" in err.lower()


def test_tc13c_get_audio_duration_timeout_returns_none() -> None:
    """_get_audio_duration returns None on subprocess timeout."""
    import subprocess as sp

    from renderdeck_mcp.tools.generate_video import _get_audio_duration

    with patch(
        "renderdeck_mcp.tools.generate_video.subprocess.run",
        side_effect=sp.TimeoutExpired(cmd=["ffprobe"], timeout=30),
    ):
        result = _get_audio_duration(Path("audio.mp3"))

    assert result is None
