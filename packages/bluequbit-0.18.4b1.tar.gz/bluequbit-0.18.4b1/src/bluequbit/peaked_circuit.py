"""PeakedCircuit result object returned by BQClient.get_peaked_circuit()."""

from __future__ import annotations

from qiskit import QuantumCircuit


class PeakedCircuit:
    """Represents a peaked circuit fetched from the BlueQubit backend.

    Attributes:
        circuit: The Qiskit QuantumCircuit reconstructed from the QASM string.
        key: The peak bitstring associated with the circuit.
        metadata: A string describing the version or provenance of the circuit.
        qasm_str: The raw QASM string of the circuit.
    """

    def __init__(self, data: dict[str, str]) -> None:
        """Initialize a PeakedCircuit from the backend response dict.

        :param data: Dictionary with keys ``qasm_str``, ``key``, and ``metadata``.
        """
        #: str: raw QASM string
        self.qasm_str: str = data["qasm_str"]

        #: QuantumCircuit: the reconstructed Qiskit circuit
        self.circuit: QuantumCircuit = QuantumCircuit.from_qasm_str(self.qasm_str)

        #: str: peak bitstring
        self.key: str = data["key"]

        #: str: version/provenance metadata
        self.metadata: str = data["metadata"]

    def __repr__(self) -> str:
        return (
            f"PeakedCircuit(key={self.key!r}, metadata={self.metadata!r}, "
            f"num_qubits={self.circuit.num_qubits})"
        )
