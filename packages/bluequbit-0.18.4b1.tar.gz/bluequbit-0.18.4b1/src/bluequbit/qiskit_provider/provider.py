from __future__ import annotations

from .backend import BlueQubitBackendV2


class BlueQubitProvider:
    """A Qiskit provider for accessing BlueQubit backend.

    :param api_token: API token of the user. If ``None``, the token will be looked
                      in the environment variable BLUEQUBIT_API_TOKEN.
    :param backend: BlueQubit backend to use. If ``None``, a new backend will be created
                    using the API token.
    """

    def __init__(
        self, *, api_token: str | None = None, backend: BlueQubitBackendV2 | None = None
    ):
        super().__init__()
        self.api_token = api_token
        self.backend = backend
        if self.backend is not None:
            assert self.api_token is None

    def get_backend(self, execution_mode: str | None = None):
        """
        :param execution_mode: Execution mode. Can be ``"cloud"``, ``"local"`` or ``None``.
                           If ``None``, the environment variable
                           BLUEQUBIT_EXECUTION_MODE will be used if set, otherwise
                           ``"cloud"`` will be used.
        """
        if self.backend is None:
            self.backend = BlueQubitBackendV2(
                api_token=self.api_token, execution_mode=execution_mode
            )
        return self.backend
