"""QSO-Graph Auth — persona and credential management for MCP servers."""

__version__ = "0.1.0"
