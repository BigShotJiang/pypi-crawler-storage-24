"""CLI package for qso-graph-auth."""

from __future__ import annotations

from .root import main

__all__ = ["main"]
