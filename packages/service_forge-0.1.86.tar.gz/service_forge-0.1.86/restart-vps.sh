#!/bin/bash

ssh -p 6000 zcc@vps.shiweinan.com << 'EOF'
cd /home/zcc/service-forge || exit 1
git pull
export SF_REGISTRY_LOCAL_ADDRESS=172.16.10.164:37920/library
./build.sh --local
EOF
