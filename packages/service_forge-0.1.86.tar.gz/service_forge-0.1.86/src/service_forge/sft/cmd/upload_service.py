import typer
import re
import subprocess
from pathlib import Path
from typing import Optional
from service_forge.sft.util.logger import log_error, log_success
from service_forge.sft.file.sft_file_manager import sft_file_manager
from service_forge.sft.util.assert_util import assert_dir_exists, assert_file_exists
from service_forge.sft.config.sf_metadata import load_metadata, save_metadata

def upload_service(project_path: str, version: Optional[str] = None, server_url: Optional[str] = None) -> None:
    project_dir = Path(project_path).resolve()
    assert_dir_exists(project_dir)
    
    metadata_path = project_dir / "sf-meta.yaml"
    assert_file_exists(metadata_path)
    # 保存原始 sf-meta.yaml 文本，以便在打包后恢复（删除临时写入的 git 信息）
    original_metadata_text = None
    try:
        original_metadata_text = metadata_path.read_text(encoding='utf-8')
    except Exception as e:
        # 不要因无法读取原文而中断上传流程，记录错误即可
        log_error(f"Failed to read original sf-meta.yaml content: {e}")
    
    try:
        meta_data = load_metadata(str(metadata_path))
    except Exception as e:
        log_error(f"Failed to read sf-meta.yaml: {e}")
        raise typer.Exit(1)
    
    # Override version if provided
    if version is not None:
        meta_data.version = version
        try:
            save_metadata(meta_data, str(metadata_path))
        except Exception as e:
            log_error(f"Failed to update metadata version: {e}")
            raise typer.Exit(1)
    # capture git branch and short sha (if project dir is a git repo) and persist into sf-meta.yaml
    def _sanitize_label_value(v: str, max_len: int = 63) -> str:
        if v is None:
            return ""
        vv = str(v).strip()
        vv = re.sub(r"[\s/]+", "-", vv)
        vv = re.sub(r"[^0-9A-Za-z_.-]", "", vv)
        vv = vv.lower()
        if len(vv) > max_len:
            vv = vv[:max_len]
        return vv

    try:
        res = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=str(project_dir), capture_output=True, text=True, check=True)
        git_branch = _sanitize_label_value(res.stdout)
    except Exception:
        git_branch = None
    try:
        res2 = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=str(project_dir), capture_output=True, text=True, check=True)
        git_sha = _sanitize_label_value(res2.stdout)
    except Exception:
        git_sha = None

    if git_branch:
        meta_data.git_branch = git_branch
    if git_sha:
        meta_data.git_sha = git_sha
    try:
        save_metadata(meta_data, str(metadata_path))
    except Exception as e:
        log_error(f"Failed to save metadata with git info: {e}")
        # not fatal
        
    try:
        tar_file = sft_file_manager.create_tar(project_dir, meta_data.name, meta_data.version)
    except Exception as e:
        log_error(f"Failed to create tar file: {e}")
        raise typer.Exit(1)

    # 打包成功后，恢复原始的 sf-meta.yaml 内容（移除临时写入的 git_branch/git_sha）
    if original_metadata_text is not None:
        try:
            metadata_path.write_text(original_metadata_text, encoding='utf-8')
        except Exception as e:
            log_error(f"Failed to restore original sf-meta.yaml after packaging: {e}")

    log_success(f"Packaging successful: {tar_file}")

    # upload to the service
    try:
        sft_file_manager.upload_tar(tar_file, server_url)
    except Exception as e:
        log_error(f"Failed to upload tar file: {e}")
        raise typer.Exit(1)
