"""em2er.py

Self-contained mapper to seed ResIPy k.mesh.df['res0'] from EMI data.
Includes the helper `local_grid_to_utm_along_line` so no external geometry
utilities are required.

Exports:
- local & UTM grid (either via 'local_grid_to_utm_along_line' or 'direct_local_grid_to_um_along_line')
- Informed ERI mesh (via em2er_map)
"""

from typing import Tuple, Optional, Dict, Any
import numpy as np
import pandas as pd
from numpy.polynomial import Polynomial as P
import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from scipy.interpolate import griddata
from math import ceil, floor

def local_grid_to_utm_along_line(mesh_df: pd.DataFrame,
                                 utm_pair1: Tuple[float, float],
                                 utm_pair2: Tuple[float, float]) -> pd.DataFrame:
    """
    Convert local mesh (X, Y) coordinates into UTM (easting, northing)
    along a line defined by two UTM points.

    Parameters
    ----------
    mesh_df : DataFrame with at least ['X', 'Y']
    utm_pair1, utm_pair2 : tuples (easting, northing)

    Returns
    -------
    DataFrame with columns ['easting', 'northing']
    """
    x1, y1 = utm_pair1
    x2, y2 = utm_pair2

    dx = float(x2 - x1)
    dy = float(y2 - y1)
    L = float(np.hypot(dx, dy))
    if L == 0:
        raise ValueError("utm_pair1 and utm_pair2 cannot be the same point.")

    ux, uy = dx / L, dy / L  # unit vector along the line

    # Rotation + translation (note: +X along line; +Y to the left)
    easting = x1 + mesh_df["X"] * ux - mesh_df["Y"] * uy
    northing = y1 + mesh_df["X"] * uy + mesh_df["Y"] * ux

    return pd.DataFrame({"easting": easting, "northing": northing})


def direct_local_grid_to_utm_along_line(local_grid_df, coord_list, polyDeg=3, numSamples=1000, lineLength=95, correctCoords=False, checkLine=False, saveElec=False, elecPath=None):
    
    if (max(coord_list['x']) - min(coord_list['x'])) > (max(coord_list['y']) - min(coord_list['y'])):
        func = P.fit(coord_list['x'], coord_list['y'], polyDeg)
        xx, yy = func.linspace(len(coord_list))
        sampX, sampY = func.linspace(numSamples)
        if checkLine:
            plt.plot(coord_list['x'], coord_list['y'], 'o', label='Original Points')
            plt.plot(xx, yy, lw=2, label='Interpolated Line')
            plt.gca().set_aspect('equal')
            plt.legend(loc='upper right', bbox_to_anchor=(1.05, 1))
            plt.show()
            plt.close()
    else:
        func = P.fit(coord_list['y'], coord_list['x'], polyDeg)
        yy, xx = func.linspace(len(coord_list))
        sampY, sampX = func.linspace(numSamples)
        if checkLine:
            plt.plot(coord_list['y'], coord_list['x'], 'o', label='Original Points')
            plt.plot(yy, xx, lw=2, label='Interpolated Line')
            plt.gca().set_aspect('equal')
            plt.legend(loc='upper right', bbox_to_anchor=(1, 1.6))
            plt.show()
            plt.close()
    
    if correctCoords:
        coord_list['x'], coord_list['y'] = xx, yy
    
    linePos = np.zeros(numSamples)
    linePos = np.sqrt((sampX**2)+(sampY**2))
    if linePos[0] > linePos[-1]:
        relLinePos = abs((linePos - max(linePos)) / (max(linePos)-min(linePos)))
    else:
        relLinePos = (linePos - min(linePos)) / (max(linePos)-min(linePos))
    relLinePos *= lineLength
    
    elecDf = pd.DataFrame(np.transpose([relLinePos, np.zeros(numSamples)]), columns=['x', 'z'])
    
    tree = cKDTree(elecDf[['x', 'z']])
    dist, idx = tree.query(local_grid_df[['X', 'Z']])

    for i in range(0, len(local_grid_df)):
        local_grid_df.loc[i, ['x', 'y']] = [sampX[idx[i]], sampY[idx[i]]]

    if saveElec:
        coord_list.to_csv(elecPath + 'corrElecCoords.csv', index=False)
        
    if correctCoords:
        return local_grid_df, coord_list
    else:
        return local_grid_df

class em2er_map:
    """
    Map EMI inversion values onto a mesh for ERI inversion.

    Parameters
    ----------
    mesh : pd.DataFrame or path to .csv
        Dataframe or .csv to file with mesh information. 
        Must have 'X', 'Y', and 'Z' columns and a column for starting resistivity.
    resCol : str
        Name of column in 'mesh' that contains starting resistivity values
    elecUTM : pd.DataFrame
        Copy of electrodes from inversion project (k.elec) with UTM 'x', 'y', and 'z'
    emicsv : str
        Path to the EMI .csv (X, Y, Depth, Linear Resistivity columns present)
    linearOrPoly : str
        Define whether to use a linear or polynomial interpolation to convert UTM to local coordintes
    alphaomega : Tuple[int, int]
        Positional indexes into elecUTM to define the line direction.
        Defaults to the first and last index of elecUTM but should be the start and end of your survey line (start elec index, end elec index)
        Only used for local grid to UTM transformation and if linearOrPoly == 'linear'.
    elecSpacing : float
        Electrode spacing used in survey. Used to determine survey length. Default is 1.
    polydeg : int
        Polynomial degree to use for electrode interpolation (if linearOrInterp != 'linear'). Default is 3.
    mapvars : dict
        Passed to testcalib.DataMapper(num_neighbors=2, max_distance_xy=5, max_distance_z=0.3) for ease of updating this function down the line.
    emires_col : str
        Column from the mapped dataframe to use for res0 merge
        (default: "_Linear Resistivity_arithmetic_mean", other options available in the DataMapper function).
    keep_cols : Optional[Tuple[str, str, str]]
        Coordinate column names (default: ('X','Y','Z')), optional.
    meshobj : Optional[resipy.project]
        ResIPy Project object. Will be used in place of 'mesh' parameter and will return informed mesh already applied to Project.
        Your ResIPy inversion project mesh and electrodes must already be defined
    """

    def __init__(
        self,
        mesh: pd.DataFrame or str,
        resCol: str,
        elecUTM: pd.DataFrame,
        emicsv: str,
        linearOrPoly: str,
        alphaomega: Tuple[int, int] = [0, 1],
        elecSpacing: float = 1,
        polydeg: int = 3,
        mapvars: Optional[Dict[str, Any]] = dict(num_neighbors=5, max_distance_xy=5, max_distance_z=0.3),
        emires_col: Optional[str] = "_Linear Resistivity_arith",
        keep_cols: Optional[Tuple[str, str, str]] = ("X", "Y", "Z"),
        meshobj: Optional = None
    ):
        if type(mesh) == str:
            self.mesh = pd.read_csv(mesh)
        elif self.meshobj is not None:
            mesh = self.meshobj.mesh.df
        else:
            self.mesh = mesh
            
        self.elecUTM = elecUTM
        self.emicsv = emicsv
        self.linearOrPoly = linearOrPoly
        self.alphaomega = alphaomega
        self.elecSpacing = elecSpacing
        self.polydeg = polydeg
        self.mapvars = mapvars
        self.emires_col = emires_col
        self.keep_cols = keep_cols
        self.meshobj = meshobj

        self.survLen = (len(elecUTM)-1) * self.elecSpacing

        #populated during run()
        self.utm_pair1: Optional[Tuple[float, float]] = None
        self.utm_pair2: Optional[Tuple[float, float]] = None
        self.meshUTM: Optional[pd.DataFrame] = None
        self.emi_inv: Optional[pd.DataFrame] = None
        self.emi2mesh: Optional[pd.DataFrame] = None
        self.dist = None

    def prep_mesh_utm(self): #convert electrode positions to UTM from just electrode numbers
        if self.linearOrPoly == 'linear':
            i1, i2 = self.alphaomega
            self.utm_pair1 = (self.elecUTM['x'].iloc[i1], self.elecUTM['y'].iloc[i1])
            self.utm_pair2 = (self.elecUTM['x'].iloc[i2], self.elecUTM['y'].iloc[i2])
    
            #convert local grid points to UTM coordinates along the line
            xyData_UTM = local_grid_to_utm_along_line(self.mesh.copy(), self.utm_pair1, self.utm_pair2)
            
            meshUTM = pd.concat([self.mesh.copy(), xyData_UTM], axis=1)
            meshUTM = meshUTM.rename(columns={'easting': 'x', 'northing': 'y'})

        else:
            meshUTM = direct_local_grid_to_utm_along_line(self.mesh, self.elecUTM, self.polydeg, lineLength=self.survLen, checkLine=True)
        #standardize coordinate naming and de-duplicate
        meshUTM = meshUTM.loc[:, ~meshUTM.columns.duplicated()]

        #remove unnecessary columns
        meshUTM = meshUTM[['X', 'Y', 'Z', 'x', 'y']]
        self.meshUTM = meshUTM

    def load_emi(self): #load EMI csv
        emi_inv = pd.read_csv(self.emicsv)
        #match column names expected by mapping function
        emi_inv = emi_inv.rename(columns={'X': 'x', 'Y': 'y', 'Depth': 'Z'})
        self.emi_inv = emi_inv

    def map_to_mesh(self):
        #import testcalib function, needs to be available outside this script
        from er2em import DataMapper

	#map EMI data to ERI mesh using select parameters
        mapper = DataMapper(**self.mapvars) 
        emi2mesh, dist = mapper.mapXYZ(self.meshUTM, [self.emi_inv], [''])
        self.emi2mesh = emi2mesh.copy()
        self.dist = dist

    def fill_missing(self, fillstrat='mean', res0fill=None, interpMeth='nearest', interpBounds=None, check=False, plotParams={'vmin': None, 'vmax': None, 'cmap': 'viridis'}):
        
        """
        fillstrat : {"mean","value","interp", "none"}
            How to fill NaNs after mapping. "mean" fills each column with its column mean.
            "value" uses `res0fill`. "interpolate" uses scipy.griddata to fill using spatial interpolation, passing 'interpMeth' to griddata. "none" leaves NaNs.
        res0fill : Optional[float] #fill with a particular value
            Value for fillstrat="value".
        interpMeth : Optional[str]
            Interpolation method to pass to scipy.griddata. Either 'nearest', 'linear', or 'cubic'. Default is 'nearest'. See scipy documentation for more information.
        interpBounds: Optional[List[Tuple[float, float], Tuple[float, float]]]
            X and Z bounds, respectively, to limit interpolation range. Defaults to [(-0.25 * survey length, 1.25 x survey length), (-(survey length/4), Max mesh Z-coordinate)].
        check: Optional[bool]
            If True, will plot an interpolated version of the informed mesh.
        plotParams: Optional[dict]
            Dictionary used to set 'vmin', 'vmax', and 'cmap' parameters for plot if 'check' is True.
        """
        if self.emi2mesh is None:
            return
        df = self.emi2mesh.copy()

        cols_to_exclude = set(self.keep_cols)
        data_cols = [c for c in df.columns if c not in cols_to_exclude]

        if fillstrat == "mean":         # Fill res0 data columns with arithmetic mean
            for col in data_cols:
                if pd.api.types.is_numeric_dtype(df[col]):
                    df[col] = df[col].fillna(df[col].mean())
        elif fillstrat == "value":         # Fill res0 data columns with user-defined value
            df[data_cols] = df[data_cols].fillna(res0fill)
        elif fillstrat == 'interp':         # Interpolate values in to fill in emires_col using scipy.griddata
            from matplotlib import colors
            
            interpBounds = [(0 - (self.survLen*0.25), self.survLen*1.25), (-(self.survLen/4), self.emi2mesh['Z'].max())]
            
            if plotParams['vmin'] is None:
                plotParams['vmin'] = ceil(df[self.emires_col].min())
            if plotParams['vmax'] is None:
                plotParams['vmax'] = floor(df[self.emires_col].max())
            
            grid_x = np.linspace(interpBounds[0][0], interpBounds[0][1], 1000)
            grid_z = -np.geomspace(abs(interpBounds[1][1]), abs(interpBounds[1][0]), 200)
            
            Xgrid, Zgrid = np.meshgrid(grid_x, grid_z)
            grid_values = griddata((df['X'], df['Z']), df[self.emires_col], (Xgrid, Zgrid), method=interpMeth)
            gridValDf = pd.DataFrame(grid_values, index = grid_z, columns = grid_x)
            
            survNan = df.loc[(df['X'] >= grid_x[0]) & (df['X'] <= grid_x[-1]) & (df['Z'] <= grid_z[0]) & (df['Z'] >= grid_z[-1]) & (df[self.emires_col].isnull())]
            
            if check:
                fig, ax = plt.subplots(layout='constrained')
                
                mesh = ax.pcolormesh(Xgrid, Zgrid, grid_values, norm=colors.LogNorm(vmin=plotParams['vmin'], vmax=plotParams['vmax']), cmap=plotParams['cmap'])
                
                cbar = plt.colorbar(mesh, ax=ax, location='bottom', shrink=0.75, aspect=25, extend='both')
                cbar.set_label(self.emires_col)
                cbTicks = np.geomspace(plotParams['vmin'], plotParams['vmax'], 5)
                cbar.set_ticks(cbTicks)
                cbLabels = [str(round(t, 2)) for t in cbTicks] # Format as strings
                cbar.set_ticklabels(cbLabels)
                cbar.ax.tick_params(which='minor', labelbottom=False) 

                ax.set_title('Interpolated Mesh')
                ax.set_xlabel('Length (m)')
                ax.set_ylabel('Depth (m)')

                plt.show()
            
            for index, row in survNan.iterrows():
                xs = abs((grid_x - row['X']))
                zs = abs((grid_z - row['Z']))
                xi = np.where(xs == xs.min())[0][0]
                zi = np.where(zs == zs.min())[0][0]
                
                df.loc[index, self.emires_col] = gridValDf.loc[grid_z[zi], grid_x[xi]]
            
            df[self.emires_col] = df[self.emires_col].fillna(df[self.emires_col].mean())
            
        elif fillstrat == "none":
            pass
        else:
            raise ValueError(f"Unknown fillstrat: {self.fillstrat}")

        self.emi2mesh = df

    def merge_into_mesh(self):
        if self.emi2mesh is None:
            return

        #take coordinates and corresponding EMI values to be mapped
        needed_cols = list(self.keep_cols) + [self.emires_col]
        missing = [c for c in needed_cols if c not in self.emi2mesh.columns]
        if missing:
            raise KeyError(f"Expected mapped columns missing: {missing}. "
                           f"Available: {list(self.emi2mesh.columns)}")
	
	#merge EMI values onto the ERI mesh
        merged = pd.merge(
            self.k.mesh.df,
            self.emi2mesh[needed_cols],
            on=list(self.keep_cols),
            how='left'
        )

        #overwrite all res0 values previously in the ERI mesh
        if self.resCol not in merged.columns:
            merged[self.resCol] = pd.NA
        merged[self.resCol] = merged[self.emires_col].combine_first(merged[self.resCol])

        merged = merged.drop(columns=[self.emires_col])
        if self.meshobj is not None:
            self.meshobj.mesh.df = merged
        else:
            self.meshobj = merged

    def run(self) -> Dict[str, Any]:
        """
        Execute the package and update k.mesh.df in place with default settings.
        """
        self.prep_mesh_utm()
        self.load_emi()
        self.map_to_mesh()
        self.fill_missing()
        self.merge_into_mesh()

        if self.meshobj is not None:
            return {
                'utm_pair1': self.utm_pair1,
                'utm_pair2': self.utm_pair2,
                'meshUTM': self.meshUTM,
                'emi_inv': self.emi_inv,
                'emi2mesh': self.emi2mesh,
                'dist': self.dist
            }
        else:
            return {
                'utm_pair1': self.utm_pair1,
                'utm_pair2': self.utm_pair2,
                'meshUTM': self.meshUTM,
                'emi_inv': self.emi_inv,
                'emi2mesh': self.emi2mesh,
                'dist': self.dist,
                'informedMesh': self.meshobj
            }


__all__ = ["local_grid_to_utm_along_line", "direct_local_grid_to_utm_along_line", "em2er_map"]