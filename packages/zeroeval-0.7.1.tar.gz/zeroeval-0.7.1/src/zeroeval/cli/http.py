from __future__ import annotations

import os
from typing import Any

import requests

from .config import load_config
from .errors import EXIT_AUTH_ERROR, EXIT_REMOTE_ERROR, EXIT_USER_ERROR, CLIError


def require_project_id(project_id: str | None) -> str:
    if not project_id:
        raise CLIError(
            "--project-id is required for this command. "
            "Run `zeroeval setup` to auto-configure, pass it explicitly, "
            "or set ZEROEVAL_PROJECT_ID.",
            exit_code=EXIT_USER_ERROR,
        )
    return project_id


class ZeroEvalAPI:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 60.0,
    ) -> None:
        cfg = load_config()
        self._api_key = api_key or os.getenv("ZEROEVAL_API_KEY") or cfg.get("api_key")
        if not self._api_key:
            raise CLIError(
                "ZEROEVAL_API_KEY not set. Run `zeroeval setup` or export the variable.",
                exit_code=EXIT_AUTH_ERROR,
            )
        self._base_url = (
            base_url
            or os.getenv("ZEROEVAL_BASE_URL")
            or os.getenv("ZEROEVAL_API_URL")
            or cfg.get("api_base_url")
            or "https://api.zeroeval.com"
        ).rstrip("/")
        self._timeout = timeout

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        try:
            resp = requests.request(
                method,
                url,
                headers=self._headers(),
                params=params,
                json=json_body,
                timeout=self._timeout,
            )
        except requests.RequestException as exc:
            raise CLIError(
                f"Network error calling ZeroEval API: {exc}",
                exit_code=EXIT_REMOTE_ERROR,
            ) from exc

        if resp.status_code in (401, 403):
            raise CLIError(
                f"Authentication/authorization failed ({resp.status_code}).",
                exit_code=EXIT_AUTH_ERROR,
                details=_safe_json(resp),
            )
        if resp.status_code >= 400:
            raise CLIError(
                f"API request failed ({resp.status_code}) for {path}.",
                exit_code=EXIT_REMOTE_ERROR,
                details=_safe_json(resp),
            )

        if resp.status_code == 204:
            return {"ok": True}

        return _safe_json(resp)

    # Datasets
    def list_datasets(self, *, limit: int, offset: int) -> Any:
        return self._request(
            "GET",
            "/v1/datasets",
            params={"limit": limit, "offset": offset},
        )

    def get_dataset(self, dataset: str) -> Any:
        return self._request("GET", f"/v1/datasets/{dataset}")

    def list_dataset_versions(self, dataset: str) -> Any:
        return self._request("GET", f"/v1/datasets/{dataset}/versions")

    def get_dataset_rows(
        self,
        dataset: str,
        *,
        version: int | None,
        subset: str | None,
        limit: int,
        offset: int,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if version is not None:
            params["version_number"] = version
        if subset:
            params["subset"] = subset
        return self._request("GET", f"/v1/datasets/{dataset}/data", params=params)

    # Evals
    def list_evals(
        self,
        *,
        dataset_id: str | None,
        status: str | None,
        limit: int,
        offset: int,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if dataset_id:
            params["dataset_id"] = dataset_id
        if status:
            params["status"] = status
        return self._request("GET", "/v1/evals", params=params)

    def get_eval(self, eval_id: str) -> Any:
        return self._request("GET", f"/v1/evals/{eval_id}")

    def get_eval_summary(self, eval_id: str) -> Any:
        return self._request("GET", f"/v1/evals/{eval_id}/summary")

    def get_eval_results(
        self,
        eval_id: str,
        *,
        repetition: int | None,
        limit: int,
        offset: int,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if repetition is not None:
            params["repetition"] = repetition
        return self._request("GET", f"/v1/evals/{eval_id}/results", params=params)

    def list_eval_scorers(self, eval_id: str) -> Any:
        return self._request("GET", f"/v1/evals/{eval_id}/scorers")

    def get_eval_scores(
        self,
        eval_id: str,
        scorer_id: str,
        *,
        limit: int,
        offset: int,
    ) -> Any:
        return self._request(
            "GET",
            f"/v1/evals/{eval_id}/scorers/{scorer_id}/scores",
            params={"limit": limit, "offset": offset},
        )

    def get_trace(self, trace_id: str) -> Any:
        return self._request("GET", "/traces", params={"id": trace_id, "limit": 1})

    def get_spans_for_trace(self, trace_id: str, *, limit: int, offset: int) -> Any:
        return self._request(
            "GET",
            "/spans",
            params={"trace_id": trace_id, "limit": limit, "offset": offset},
        )

    # ---- Monitoring (project-scoped) ----

    def monitoring_stats(
        self, project_id: str, entity_type: str, *, params: dict[str, Any] | None = None,
    ) -> Any:
        return self._request(
            "GET", f"/projects/{project_id}/monitoring/{entity_type}/stats", params=params,
        )

    def monitoring_facets(
        self, project_id: str, entity_type: str, *, params: dict[str, Any] | None = None,
    ) -> Any:
        return self._request(
            "GET", f"/projects/{project_id}/monitoring/{entity_type}/facets", params=params,
        )

    def object_search(self, project_id: str, *, params: dict[str, Any] | None = None) -> Any:
        return self._request("POST", f"/v1/objects/search", json_body={"project_id": project_id, **(params or {})})

    def list_sessions(self, project_id: str, *, params: dict[str, Any] | None = None) -> Any:
        return self._request("GET", "/sessions", params={"project_id": project_id, **(params or {})})

    def get_session(self, project_id: str, session_id: str) -> Any:
        return self._request("GET", "/sessions", params={"project_id": project_id, "id": session_id, "limit": 1})

    def list_traces(self, project_id: str, *, params: dict[str, Any] | None = None) -> Any:
        return self._request("GET", "/traces", params={"project_id": project_id, **(params or {})})

    def get_trace_by_id(self, project_id: str, trace_id: str) -> Any:
        return self._request("GET", "/traces", params={"project_id": project_id, "id": trace_id, "limit": 1})

    def list_spans(self, project_id: str, *, params: dict[str, Any] | None = None) -> Any:
        return self._request("GET", "/spans", params={"project_id": project_id, **(params or {})})

    def get_span(self, project_id: str, span_id: str) -> Any:
        return self._request("GET", "/spans", params={"project_id": project_id, "id": span_id, "limit": 1})

    # ---- Judges (project-scoped) ----

    def list_judges(self, project_id: str) -> Any:
        return self._request("GET", f"/signals/projects/{project_id}/automations")

    def get_judge(self, project_id: str, judge_id: str) -> Any:
        return self._request("GET", f"/signals/projects/{project_id}/automations/{judge_id}")

    def create_judge(self, project_id: str, body: dict[str, Any]) -> Any:
        return self._request("POST", f"/signals/projects/{project_id}/automations", json_body=body)

    def judge_evaluations(
        self, project_id: str, judge_id: str, *, params: dict[str, Any] | None = None,
    ) -> Any:
        return self._request(
            "GET", f"/projects/{project_id}/judges/{judge_id}/evaluations", params=params,
        )

    def judge_criteria(self, project_id: str, judge_id: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/judges/{judge_id}/criteria")

    def judge_insights(self, project_id: str, judge_id: str, *, force: bool = False) -> Any:
        params: dict[str, Any] = {}
        if force:
            params["force"] = "true"
        return self._request("GET", f"/projects/{project_id}/judges/{judge_id}/insights", params=params or None)

    def judge_performance(self, project_id: str, judge_id: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/judges/{judge_id}/performance")

    def judge_calibration(self, project_id: str, judge_id: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/judges/{judge_id}/calibration-status")

    def judge_metrics_by_version(self, project_id: str, judge_id: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/judges/{judge_id}/metrics-by-version")

    def upsert_span_feedback(self, project_id: str, span_id: str, body: dict[str, Any]) -> Any:
        return self._request("POST", f"/projects/{project_id}/spans/{span_id}/feedback", json_body=body)

    # ---- Prompts (project-scoped + /v1) ----

    def list_prompts(self, project_id: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/prompts")

    def get_prompt_by_slug(self, slug: str, *, version: int | None = None, tag: str | None = None) -> Any:
        params: dict[str, Any] = {}
        if version is not None:
            params["version"] = version
        if tag is not None:
            params["tag"] = tag
        return self._request("GET", f"/v1/prompts/{slug}", params=params or None)

    def list_prompt_versions(self, project_id: str, slug: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/prompts/{slug}/versions")

    def list_prompt_tags(self, project_id: str, slug: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/prompts/{slug}/tags")

    def create_prompt_completion_feedback(
        self, slug: str, completion_id: str, body: dict[str, Any],
    ) -> Any:
        return self._request(
            "POST", f"/v1/prompts/{slug}/completions/{completion_id}/feedback", json_body=body,
        )

    # ---- Tuning tasks ----

    def list_tuning_tasks(self, project_id: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/tuning/tasks")

    # ---- Optimization (project-scoped, task-backed) ----

    def list_optimization_runs(self, project_id: str, task_id: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/tuning/tasks/{task_id}/dspy-runs")

    def get_optimization_run(self, project_id: str, task_id: str, run_id: str) -> Any:
        return self._request("GET", f"/projects/{project_id}/tuning/tasks/{task_id}/dspy-runs/{run_id}")

    def start_optimization_run(self, project_id: str, task_id: str, body: dict[str, Any]) -> Any:
        return self._request(
            "POST", f"/projects/{project_id}/tuning/tasks/{task_id}/dspy-runs", json_body=body,
        )

    def adopt_optimization_run(
        self, project_id: str, task_id: str, run_id: str, body: dict[str, Any] | None = None,
    ) -> Any:
        return self._request(
            "POST",
            f"/projects/{project_id}/tuning/tasks/{task_id}/dspy-runs/{run_id}/adopt",
            json_body=body or {},
        )


def _safe_json(response: requests.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        return {"raw": response.text}

