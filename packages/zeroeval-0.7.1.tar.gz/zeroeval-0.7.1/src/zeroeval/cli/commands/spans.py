from __future__ import annotations

import argparse
from typing import Any

from ..context import CLIContext
from ..http import ZeroEvalAPI, require_project_id
from ..query import apply_query


def _api(args: argparse.Namespace, ctx: CLIContext) -> ZeroEvalAPI:
    return ZeroEvalAPI(base_url=ctx.api_base_url, timeout=ctx.timeout)


def cmd_spans_list(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    params: dict[str, Any] = {"limit": args.limit, "offset": args.offset}
    if args.start_date:
        params["start_date"] = args.start_date
    if args.end_date:
        params["end_date"] = args.end_date
    rows = _api(args, ctx).list_spans(project_id, params=params)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_spans_get(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    row = _api(args, ctx).get_span(project_id, args.span_id)
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def register_spans_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]):
    spans = subparsers.add_parser("spans", help="Span inspection commands")
    span_sub = spans.add_subparsers(dest="spans_command", required=True)

    p_list = span_sub.add_parser("list", help="List spans")
    p_list.add_argument("--start-date", default=None)
    p_list.add_argument("--end-date", default=None)
    p_list.add_argument("--limit", type=int, default=50)
    p_list.add_argument("--offset", type=int, default=0)
    p_list.add_argument("--where", action="append", default=[])
    p_list.add_argument("--select", default=None)
    p_list.add_argument("--order", default=None)
    p_list.set_defaults(handler=cmd_spans_list)

    p_get = span_sub.add_parser("get", help="Get span by ID")
    p_get.add_argument("span_id", help="Span ID")
    p_get.add_argument("--where", action="append", default=[])
    p_get.add_argument("--select", default=None)
    p_get.add_argument("--order", default=None)
    p_get.set_defaults(handler=cmd_spans_get)
