from __future__ import annotations

import argparse
from typing import Any

from ..context import CLIContext
from ..http import ZeroEvalAPI, require_project_id
from ..query import apply_query


def _api(args: argparse.Namespace, ctx: CLIContext) -> ZeroEvalAPI:
    return ZeroEvalAPI(base_url=ctx.api_base_url, timeout=ctx.timeout)


def cmd_sessions_list(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    params: dict[str, Any] = {"limit": args.limit, "offset": args.offset}
    if args.start_date:
        params["start_date"] = args.start_date
    if args.end_date:
        params["end_date"] = args.end_date
    rows = _api(args, ctx).list_sessions(project_id, params=params)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_sessions_get(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    row = _api(args, ctx).get_session(project_id, args.session_id)
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def register_sessions_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]):
    sessions = subparsers.add_parser("sessions", help="Session inspection commands")
    sess_sub = sessions.add_subparsers(dest="sessions_command", required=True)

    p_list = sess_sub.add_parser("list", help="List sessions")
    p_list.add_argument("--start-date", default=None)
    p_list.add_argument("--end-date", default=None)
    p_list.add_argument("--limit", type=int, default=50)
    p_list.add_argument("--offset", type=int, default=0)
    p_list.add_argument("--where", action="append", default=[])
    p_list.add_argument("--select", default=None)
    p_list.add_argument("--order", default=None)
    p_list.set_defaults(handler=cmd_sessions_list)

    p_get = sess_sub.add_parser("get", help="Get session by ID")
    p_get.add_argument("session_id", help="Session ID")
    p_get.add_argument("--where", action="append", default=[])
    p_get.add_argument("--select", default=None)
    p_get.add_argument("--order", default=None)
    p_get.set_defaults(handler=cmd_sessions_get)
