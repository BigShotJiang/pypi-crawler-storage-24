from __future__ import annotations

import argparse
from typing import Any

from ..context import CLIContext
from ..http import ZeroEvalAPI, require_project_id
from ..query import apply_query


def _api(args: argparse.Namespace, ctx: CLIContext) -> ZeroEvalAPI:
    return ZeroEvalAPI(base_url=ctx.api_base_url, timeout=ctx.timeout)


def cmd_traces_list(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    params: dict[str, Any] = {"limit": args.limit, "offset": args.offset}
    if args.start_date:
        params["start_date"] = args.start_date
    if args.end_date:
        params["end_date"] = args.end_date
    rows = _api(args, ctx).list_traces(project_id, params=params)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_traces_get(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    row = _api(args, ctx).get_trace_by_id(project_id, args.trace_id)
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_traces_spans(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    params: dict[str, Any] = {
        "trace_id": args.trace_id,
        "limit": args.limit,
        "offset": args.offset,
    }
    rows = _api(args, ctx).list_spans(project_id, params=params)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def register_traces_commands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
):
    traces = subparsers.add_parser("traces", help="Trace inspection commands")
    trace_sub = traces.add_subparsers(dest="traces_command", required=True)

    p_list = trace_sub.add_parser("list", help="List traces")
    p_list.add_argument("--start-date", default=None)
    p_list.add_argument("--end-date", default=None)
    p_list.add_argument("--limit", type=int, default=50)
    p_list.add_argument("--offset", type=int, default=0)
    p_list.add_argument("--where", action="append", default=[])
    p_list.add_argument("--select", default=None)
    p_list.add_argument("--order", default=None)
    p_list.set_defaults(handler=cmd_traces_list)

    p_get = trace_sub.add_parser("get", help="Get trace by ID")
    p_get.add_argument("trace_id", help="Trace ID")
    p_get.add_argument("--where", action="append", default=[])
    p_get.add_argument("--select", default=None)
    p_get.add_argument("--order", default=None)
    p_get.set_defaults(handler=cmd_traces_get)

    p_spans = trace_sub.add_parser("spans", help="Get spans for a trace")
    p_spans.add_argument("trace_id", help="Trace ID")
    p_spans.add_argument("--limit", type=int, default=100)
    p_spans.add_argument("--offset", type=int, default=0)
    p_spans.add_argument("--where", action="append", default=[])
    p_spans.add_argument("--select", default=None)
    p_spans.add_argument("--order", default=None)
    p_spans.set_defaults(handler=cmd_traces_spans)
