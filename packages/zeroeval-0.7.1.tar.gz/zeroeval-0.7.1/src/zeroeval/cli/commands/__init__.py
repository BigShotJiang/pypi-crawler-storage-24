from .auth import register_auth_commands
from .datasets import register_datasets_commands
from .evals import register_evals_commands
from .judges import register_judges_commands
from .optimize import register_optimize_commands
from .prompts import register_prompts_commands
from .sessions import register_sessions_commands
from .spans import register_spans_commands
from .spec import register_spec_commands
from .traces import register_traces_commands

__all__ = [
    "register_auth_commands",
    "register_datasets_commands",
    "register_evals_commands",
    "register_judges_commands",
    "register_optimize_commands",
    "register_prompts_commands",
    "register_sessions_commands",
    "register_spans_commands",
    "register_spec_commands",
    "register_traces_commands",
]

