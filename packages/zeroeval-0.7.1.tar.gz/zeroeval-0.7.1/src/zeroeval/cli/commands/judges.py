from __future__ import annotations

import argparse
import json
from typing import Any

from ..context import CLIContext
from ..errors import CLIError, EXIT_USER_ERROR
from ..http import ZeroEvalAPI, require_project_id
from ..query import apply_query


def _api(args: argparse.Namespace, ctx: CLIContext) -> ZeroEvalAPI:
    return ZeroEvalAPI(base_url=ctx.api_base_url, timeout=ctx.timeout)


def cmd_judges_list(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    result = _api(args, ctx).list_judges(project_id)
    rows = result.get("automations", result)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_judges_get(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    row = _api(args, ctx).get_judge(project_id, args.judge_id)
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_judges_evaluations(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.start_date:
        params["start_date"] = args.start_date
    if args.end_date:
        params["end_date"] = args.end_date
    if args.evaluation_result is not None:
        params["evaluation_result"] = args.evaluation_result
    if args.feedback_state:
        params["feedback_state"] = args.feedback_state
    result = _api(args, ctx).judge_evaluations(
        project_id, args.judge_id, params=params
    )
    rows = result.get("evaluations", result) if isinstance(result, dict) else result
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_judges_criteria(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    return _api(args, ctx).judge_criteria(project_id, args.judge_id)


def cmd_judges_insights(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    return _api(args, ctx).judge_insights(
        project_id, args.judge_id, force=args.force
    )


def cmd_judges_performance(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    return _api(args, ctx).judge_performance(project_id, args.judge_id)


def cmd_judges_calibration(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    return _api(args, ctx).judge_calibration(project_id, args.judge_id)


def cmd_judges_versions(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    return _api(args, ctx).judge_metrics_by_version(project_id, args.judge_id)


def cmd_judges_create(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    if args.prompt:
        prompt_text = args.prompt
    elif args.prompt_file:
        with open(args.prompt_file, encoding="utf-8") as f:
            prompt_text = f.read()
    else:
        raise CLIError(
            "One of --prompt or --prompt-file is required.",
            exit_code=EXIT_USER_ERROR,
        )
    tag_filters: dict[str, list[str]] = {}
    for tag_arg in args.tag or []:
        if "=" in tag_arg:
            key, vals = tag_arg.split("=", 1)
            tag_filters[key.strip()] = [v.strip() for v in vals.split(",") if v.strip()]
    body: dict[str, Any] = {
        "name": args.name,
        "sample_rate": args.sample_rate,
        "filter": {
            "object_type": "span",
            "properties": {
                "kind": "llm",
                "backfill": args.backfill,
            },
        },
        "template": prompt_text,
        "evaluation_type": args.evaluation_type,
        "temperature": args.temperature,
    }
    if tag_filters:
        body["filter"]["properties"]["tags"] = tag_filters
        body["filter"]["properties"]["tagMatchMode"] = args.tag_match
    if args.evaluation_type == "scored":
        body["score_min"] = args.score_min
        body["score_max"] = args.score_max
        if args.pass_threshold is not None:
            body["pass_threshold"] = args.pass_threshold
    if args.target_prompt_id:
        body["target_prompt_id"] = args.target_prompt_id
    return _api(args, ctx).create_judge(project_id, body)


def cmd_judges_feedback_create(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    if args.thumbs_up and args.thumbs_down:
        raise CLIError(
            "Specify exactly one of --thumbs-up or --thumbs-down.",
            exit_code=EXIT_USER_ERROR,
        )
    if not args.thumbs_up and not args.thumbs_down:
        raise CLIError(
            "One of --thumbs-up or --thumbs-down is required.",
            exit_code=EXIT_USER_ERROR,
        )
    body: dict[str, Any] = {"thumbs_up": args.thumbs_up}
    if args.reason:
        body["reason"] = args.reason
    if args.expected_output:
        body["expected_output"] = args.expected_output
    if args.expected_score is not None:
        body["expected_score"] = args.expected_score
    if args.score_direction:
        body["score_direction"] = args.score_direction
    if args.criteria_feedback:
        body["criteria_feedback"] = json.loads(args.criteria_feedback)
    return _api(args, ctx).upsert_span_feedback(
        project_id, args.span_id, body
    )


def register_judges_commands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    judges = subparsers.add_parser("judges", help="Judge/automation commands")
    judges_sub = judges.add_subparsers(dest="judges_command", required=True)

    p_list = judges_sub.add_parser("list", help="List judges")
    p_list.add_argument("--where", action="append", default=[])
    p_list.add_argument("--select", default=None)
    p_list.add_argument("--order", default=None)
    p_list.set_defaults(handler=cmd_judges_list)

    p_get = judges_sub.add_parser("get", help="Get judge metadata")
    p_get.add_argument("judge_id")
    p_get.add_argument("--where", action="append", default=[])
    p_get.add_argument("--select", default=None)
    p_get.add_argument("--order", default=None)
    p_get.set_defaults(handler=cmd_judges_get)

    p_evaluations = judges_sub.add_parser("evaluations", help="List judge evaluations")
    p_evaluations.add_argument("judge_id")
    p_evaluations.add_argument("--limit", type=int, default=100)
    p_evaluations.add_argument("--offset", type=int, default=0)
    p_evaluations.add_argument("--start-date", default=None)
    p_evaluations.add_argument("--end-date", default=None)
    p_evaluations.add_argument(
        "--evaluation-result",
        choices=["true", "false"],
        default=None,
    )
    p_evaluations.add_argument("--feedback-state", default=None)
    p_evaluations.add_argument("--where", action="append", default=[])
    p_evaluations.add_argument("--select", default=None)
    p_evaluations.add_argument("--order", default=None)
    p_evaluations.set_defaults(handler=cmd_judges_evaluations)

    p_criteria = judges_sub.add_parser("criteria", help="Get judge criteria")
    p_criteria.add_argument("judge_id")
    p_criteria.set_defaults(handler=cmd_judges_criteria)

    p_insights = judges_sub.add_parser("insights", help="Get judge insights")
    p_insights.add_argument("judge_id")
    p_insights.add_argument("--force", action="store_true")
    p_insights.set_defaults(handler=cmd_judges_insights)

    p_performance = judges_sub.add_parser("performance", help="Get judge performance")
    p_performance.add_argument("judge_id")
    p_performance.set_defaults(handler=cmd_judges_performance)

    p_calibration = judges_sub.add_parser("calibration", help="Get judge calibration")
    p_calibration.add_argument("judge_id")
    p_calibration.set_defaults(handler=cmd_judges_calibration)

    p_versions = judges_sub.add_parser("versions", help="Get judge metrics by version")
    p_versions.add_argument("judge_id")
    p_versions.set_defaults(handler=cmd_judges_versions)

    p_create = judges_sub.add_parser("create", help="Create a judge")
    p_create.add_argument("--name", required=True)
    p_create.add_argument("--prompt", default=None)
    p_create.add_argument("--prompt-file", default=None)
    p_create.add_argument("--target-prompt-id", default=None)
    p_create.add_argument("--sample-rate", type=float, default=1.0)
    p_create.add_argument("--backfill", type=int, default=100)
    p_create.add_argument("--tag", action="append", default=[])
    p_create.add_argument(
        "--tag-match",
        choices=["all", "any"],
        default="all",
    )
    p_create.add_argument(
        "--evaluation-type",
        choices=["binary", "scored"],
        default="binary",
    )
    p_create.add_argument("--score-min", type=float, default=0.0)
    p_create.add_argument("--score-max", type=float, default=10.0)
    p_create.add_argument("--pass-threshold", type=float, default=None)
    p_create.add_argument("--temperature", type=float, default=0.0)
    p_create.set_defaults(handler=cmd_judges_create)

    p_feedback = judges_sub.add_parser("feedback", help="Feedback commands")
    feedback_sub = p_feedback.add_subparsers(dest="judges_feedback_command", required=True)

    p_feedback_create = feedback_sub.add_parser("create", help="Create span feedback")
    p_feedback_create.add_argument("--span-id", required=True)
    p_feedback_create.add_argument("--thumbs-up", action="store_true")
    p_feedback_create.add_argument("--thumbs-down", action="store_true")
    p_feedback_create.add_argument("--reason", default=None)
    p_feedback_create.add_argument("--expected-output", default=None)
    p_feedback_create.add_argument("--expected-score", type=float, default=None)
    p_feedback_create.add_argument(
        "--score-direction",
        choices=["too_high", "too_low"],
        default=None,
    )
    p_feedback_create.add_argument("--criteria-feedback", default=None)
    p_feedback_create.set_defaults(handler=cmd_judges_feedback_create)
