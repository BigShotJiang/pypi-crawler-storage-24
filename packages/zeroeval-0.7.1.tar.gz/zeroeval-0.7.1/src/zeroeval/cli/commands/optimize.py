from __future__ import annotations

import argparse
import json
from typing import Any

from ..context import CLIContext
from ..http import ZeroEvalAPI, require_project_id
from ..output import confirm_or_abort
from ..query import apply_query


def _api(args: argparse.Namespace, ctx: CLIContext) -> ZeroEvalAPI:
    return ZeroEvalAPI(base_url=ctx.api_base_url, timeout=ctx.timeout)


def _resolve_judge_task_id(api: ZeroEvalAPI, project_id: str, judge_id: str) -> str:
    judge = api.get_judge(project_id, judge_id)
    task_id = judge.get("task_id")
    if not task_id:
        from ..errors import CLIError, EXIT_USER_ERROR

        raise CLIError(
            f"Judge {judge_id} has no linked tuning task.",
            exit_code=EXIT_USER_ERROR,
        )
    return task_id


# ---- Prompt optimization ----

def cmd_optimize_prompt_list(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    rows = _api(args, ctx).list_optimization_runs(project_id, args.task_id)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_optimize_prompt_get(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    row = _api(args, ctx).get_optimization_run(
        project_id, args.task_id, args.run_id
    )
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_optimize_prompt_start(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    body: dict[str, Any] = {"optimizer_type": args.optimizer_type}
    if args.config:
        body.update(json.loads(args.config))
    return _api(args, ctx).start_optimization_run(project_id, args.task_id, body)


def cmd_optimize_prompt_promote(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    confirm_or_abort(ctx, "Promote this optimization run to production?", yes=args.yes)
    return _api(args, ctx).adopt_optimization_run(
        project_id, args.task_id, args.run_id
    )


# ---- Judge optimization ----

def cmd_optimize_judge_list(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    api = _api(args, ctx)
    task_id = _resolve_judge_task_id(api, project_id, args.judge_id)
    rows = api.list_optimization_runs(project_id, task_id)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_optimize_judge_get(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    api = _api(args, ctx)
    task_id = _resolve_judge_task_id(api, project_id, args.judge_id)
    row = api.get_optimization_run(project_id, task_id, args.run_id)
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_optimize_judge_start(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    api = _api(args, ctx)
    task_id = _resolve_judge_task_id(api, project_id, args.judge_id)
    body: dict[str, Any] = {"optimizer_type": args.optimizer_type}
    if args.config:
        body.update(json.loads(args.config))
    return api.start_optimization_run(project_id, task_id, body)


def cmd_optimize_judge_promote(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    api = _api(args, ctx)
    task_id = _resolve_judge_task_id(api, project_id, args.judge_id)
    confirm_or_abort(ctx, "Promote this optimization run to production?", yes=args.yes)
    return api.adopt_optimization_run(project_id, task_id, args.run_id)


def register_optimize_commands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    optimize = subparsers.add_parser("optimize", help="Optimization lifecycle commands")
    opt_sub = optimize.add_subparsers(dest="optimize_target", required=True)

    # Prompt optimization
    p_prompt = opt_sub.add_parser("prompt", help="Prompt optimization commands")
    prompt_sub = p_prompt.add_subparsers(dest="optimize_prompt_command", required=True)

    p_prompt_list = prompt_sub.add_parser("list", help="List optimization runs for a task")
    p_prompt_list.add_argument("task_id")
    p_prompt_list.add_argument("--where", action="append", default=[])
    p_prompt_list.add_argument("--select", default=None)
    p_prompt_list.add_argument("--order", default=None)
    p_prompt_list.set_defaults(handler=cmd_optimize_prompt_list)

    p_prompt_get = prompt_sub.add_parser("get", help="Get optimization run details")
    p_prompt_get.add_argument("task_id")
    p_prompt_get.add_argument("run_id")
    p_prompt_get.add_argument("--where", action="append", default=[])
    p_prompt_get.add_argument("--select", default=None)
    p_prompt_get.add_argument("--order", default=None)
    p_prompt_get.set_defaults(handler=cmd_optimize_prompt_get)

    p_prompt_start = prompt_sub.add_parser("start", help="Start an optimization run")
    p_prompt_start.add_argument("task_id")
    p_prompt_start.add_argument(
        "--optimizer-type",
        choices=["quick_refine", "dspy_bootstrap", "dspy_gepa"],
        default="quick_refine",
    )
    p_prompt_start.add_argument("--config", default=None)
    p_prompt_start.set_defaults(handler=cmd_optimize_prompt_start)

    p_prompt_promote = prompt_sub.add_parser("promote", help="Promote run to production")
    p_prompt_promote.add_argument("task_id")
    p_prompt_promote.add_argument("run_id")
    p_prompt_promote.add_argument("--yes", action="store_true")
    p_prompt_promote.set_defaults(handler=cmd_optimize_prompt_promote)

    # Judge optimization
    p_judge = opt_sub.add_parser("judge", help="Judge optimization commands")
    judge_sub = p_judge.add_subparsers(dest="optimize_judge_command", required=True)

    p_judge_list = judge_sub.add_parser("list", help="List optimization runs for a judge")
    p_judge_list.add_argument("judge_id")
    p_judge_list.add_argument("--where", action="append", default=[])
    p_judge_list.add_argument("--select", default=None)
    p_judge_list.add_argument("--order", default=None)
    p_judge_list.set_defaults(handler=cmd_optimize_judge_list)

    p_judge_get = judge_sub.add_parser("get", help="Get optimization run details")
    p_judge_get.add_argument("judge_id")
    p_judge_get.add_argument("run_id")
    p_judge_get.add_argument("--where", action="append", default=[])
    p_judge_get.add_argument("--select", default=None)
    p_judge_get.add_argument("--order", default=None)
    p_judge_get.set_defaults(handler=cmd_optimize_judge_get)

    p_judge_start = judge_sub.add_parser("start", help="Start an optimization run")
    p_judge_start.add_argument("judge_id")
    p_judge_start.add_argument(
        "--optimizer-type",
        choices=["quick_refine", "dspy_bootstrap", "dspy_gepa"],
        default="quick_refine",
    )
    p_judge_start.add_argument("--config", default=None)
    p_judge_start.set_defaults(handler=cmd_optimize_judge_start)

    p_judge_promote = judge_sub.add_parser("promote", help="Promote run to production")
    p_judge_promote.add_argument("judge_id")
    p_judge_promote.add_argument("run_id")
    p_judge_promote.add_argument("--yes", action="store_true")
    p_judge_promote.set_defaults(handler=cmd_optimize_judge_promote)
