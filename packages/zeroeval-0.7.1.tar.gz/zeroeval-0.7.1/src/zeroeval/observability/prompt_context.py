"""Trace-scoped prompt metadata context.

Stores the most recently resolved prompt metadata so that all spans created
within the same trace automatically inherit prompt/task linkage attributes.
The context is keyed by trace_id to prevent leaking metadata across unrelated
traces on the same thread.
"""
from __future__ import annotations

import threading
from typing import Any, Optional


_lock = threading.Lock()

_prompt_metadata_by_trace: dict[str, dict[str, Any]] = {}


def set_prompt_metadata(trace_id: str, metadata: dict[str, Any]) -> None:
    """Register prompt metadata for *trace_id*.

    Subsequent calls to :func:`get_prompt_metadata` with the same *trace_id*
    will return a copy of *metadata*.
    """
    with _lock:
        _prompt_metadata_by_trace[trace_id] = metadata.copy()


def get_prompt_metadata(trace_id: Optional[str]) -> Optional[dict[str, Any]]:
    """Return the prompt metadata registered for *trace_id*, or ``None``."""
    if not trace_id:
        return None
    with _lock:
        md = _prompt_metadata_by_trace.get(trace_id)
        return md.copy() if md else None


def clear_prompt_metadata(trace_id: str) -> None:
    """Remove prompt metadata for *trace_id* (called on trace cleanup)."""
    with _lock:
        _prompt_metadata_by_trace.pop(trace_id, None)
