import logging
import os
from typing import Optional, Union

import requests

from .span import Signal, Span
from .tracer import tracer

logger = logging.getLogger(__name__)


def _infer_signal_type(value: Union[str, bool, int, float]) -> str:
    return Signal._infer_signal_type(value)


def _normalize_signal_payload(
    signals: dict[str, Union[str, bool, int, float]],
    signal_types: Optional[dict[str, str]] = None,
) -> list[dict[str, Union[str, bool, int, float]]]:
    payloads: list[dict[str, Union[str, bool, int, float]]] = []
    for name, value in signals.items():
        signal_type = (signal_types or {}).get(name) or _infer_signal_type(value)
        normalized = Signal(name=name, value=value, signal_type=signal_type)
        payloads.append(
            {
                "name": name,
                "value": normalized.value,
                "signal_type": normalized.signal_type,
            }
        )
    return payloads


def _send_signals_immediately(
    entity_type: str,
    entity_id: str,
    signals: dict[str, Union[str, bool, int, float]],
    signal_types: Optional[dict[str, str]] = None,
) -> bool:
    """
    Private helper to send a batch of signals for a single entity immediately.
    """
    # Get configuration from environment
    api_url = os.getenv("ZEROEVAL_API_URL", "https://api.zeroeval.com")
    api_key = os.getenv("ZEROEVAL_API_KEY")

    if not all([api_key, api_url]):
        logger.warning(
            "Cannot send signals. Missing ZEROEVAL_API_KEY or ZEROEVAL_API_URL."
        )
        return False

    # Prepare payload
    endpoint = f"{api_url}/signals/bulk"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    api_payloads = [
        {
            "entity_type": entity_type,
            "entity_id": entity_id,
            "name": payload["name"],
            "value": payload["value"],
            "signal_type": payload["signal_type"],
        }
        for payload in _normalize_signal_payload(signals, signal_types)
    ]
    payload = {"signals": api_payloads}

    # Send immediately and log status
    try:
        logger.info(
            f"Sending {len(signals)} signals for {entity_type}:{entity_id} immediately..."
        )
        response = requests.post(endpoint, json=payload, headers=headers, timeout=5.0)
        logger.info(
            f"Response for {entity_type}:{entity_id}: HTTP {response.status_code}"
        )
        response.raise_for_status()  # Raise exception for 4xx/5xx errors
        return True
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to send signals for {entity_type}:{entity_id}: {e}")
        return False


def set_signal(
    target: Union[Span, str],
    signals: dict[str, Union[str, bool, int, float]],
    *,
    immediate: bool = True,
    signal_types: Optional[dict[str, str]] = None,
    target_type: Optional[str] = None,
) -> bool:
    """
    Attach or send signals for a given span, trace, or session.

    For `Span` targets, signals are always attached to the in-memory span so they
    travel with normal span flushing. Immediate delivery can be enabled separately
    with `immediate=True`.

    Args:
        target: The entity to attach signals to. Can be a `Span` object,
                a `trace_id` string, or a `session_id` string.
        signals: A dictionary of signal names to values.
        immediate: When True, send signals directly to the backend right away.
        signal_types: Optional per-signal explicit type overrides.

    Returns:
        True if the signals were attached/sent successfully, False otherwise.
    """
    if not isinstance(signals, dict) or not signals:
        logger.warning("No signals provided, nothing to send.")
        return True

    # Determine entity type and ID from the target
    entity_type = target_type or "session"  # Default assumption
    entity_id = None

    if isinstance(target, Span):
        entity_type = "span"
        entity_id = target.span_id

        for signal_name, signal_value in signals.items():
            target.set_signal(
                signal_name,
                signal_value,
                signal_type=(signal_types or {}).get(signal_name),
            )

        logger.debug(
            "Attached %d signals to span %s", len(signals), entity_id
        )
    elif isinstance(target, str):
        entity_id = target
        if target_type == "trace" or tracer.is_active_trace(target):
            entity_type = "trace"
    else:
        raise TypeError(
            f"Unsupported target type '{type(target).__name__}' for signal. Must be Span or str."
        )

    if not immediate:
        return True

    return _send_signals_immediately(
        entity_type,
        entity_id,
        signals,
        signal_types=signal_types,
    )


def _resolve_default_target() -> Union[Span, str]:
    current_span = tracer.get_current_span()
    if current_span is not None:
        return current_span
    current_trace = tracer.get_current_trace()
    if current_trace:
        return current_trace
    raise RuntimeError(
        "No active span or trace found for signal emission. "
        "Call emit_signal() from inside a traced task/span, or pass an explicit target."
    )


def emit_signals(
    signals: dict[str, Union[str, bool, int, float]],
    *,
    target: Union[Span, str, None] = None,
    signal_types: Optional[dict[str, str]] = None,
    immediate: Optional[bool] = None,
) -> bool:
    """
    Emit runtime signals during task execution.

    By default, signals attach to the current span if one exists, otherwise the
    current trace. Span-targeted emissions default to buffered span delivery
    (`immediate=False`) so task signals flush with the span payload once.
    """
    resolved_target = target if target is not None else _resolve_default_target()
    if immediate is None:
        immediate = not isinstance(resolved_target, Span)
    return set_signal(
        resolved_target,
        signals,
        immediate=immediate,
        signal_types=signal_types,
        target_type="trace"
        if isinstance(resolved_target, str) and resolved_target == tracer.get_current_trace()
        else None,
    )


def emit_signal(
    name: str,
    value: Union[str, bool, int, float],
    *,
    target: Union[Span, str, None] = None,
    signal_type: Optional[str] = None,
    immediate: Optional[bool] = None,
) -> bool:
    """Emit a single runtime signal during task execution."""
    signal_types = {name: signal_type} if signal_type else None
    return emit_signals(
        {name: value},
        target=target,
        signal_types=signal_types,
        immediate=immediate,
    )
