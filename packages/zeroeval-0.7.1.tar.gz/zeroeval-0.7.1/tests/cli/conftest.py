from __future__ import annotations

import io
import json
import sys
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import dataclass, field
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from zeroeval.cli.main import main as cli_main


@dataclass
class CLIResult:
    exit_code: int
    stdout: str
    stderr: str

    def json(self) -> Any:
        return json.loads(self.stdout)


@dataclass
class FakeResponse:
    status_code: int = 200
    _json: Any = field(default_factory=dict)
    text: str = ""

    def json(self) -> Any:
        return self._json


def run_cli(*args: str, env: dict[str, str] | None = None) -> CLIResult:
    env = env or {}
    env.setdefault("ZEROEVAL_API_KEY", "sk_test_fake")

    out = io.StringIO()
    err = io.StringIO()
    exit_code = 0

    with (
        patch.dict("os.environ", env, clear=False),
        patch("sys.argv", ["zeroeval", *args]),
        redirect_stdout(out),
        redirect_stderr(err),
    ):
        try:
            exit_code = cli_main()
        except SystemExit as e:
            exit_code = e.code if isinstance(e.code, int) else 1

    return CLIResult(
        exit_code=exit_code or 0,
        stdout=out.getvalue(),
        stderr=err.getvalue(),
    )


def stub_api_response(status_code: int = 200, json_body: Any = None) -> FakeResponse:
    return FakeResponse(
        status_code=status_code,
        _json=json_body if json_body is not None else {},
        text=json.dumps(json_body) if json_body is not None else "{}",
    )
