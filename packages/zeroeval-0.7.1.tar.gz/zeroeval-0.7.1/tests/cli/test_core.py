from __future__ import annotations

from unittest.mock import patch

from .conftest import run_cli, stub_api_response


def _empty_config(*_args, **_kwargs):
    return {}


class TestParserBuilds:
    def test_help_exits_zero(self):
        result = run_cli("--help")
        assert result.exit_code == 0
        assert "zeroeval" in result.stdout.lower()

    def test_all_top_level_commands_registered(self):
        result = run_cli("--help")
        for cmd in [
            "auth",
            "datasets",
            "evals",
            "judges",
            "optimize",
            "prompts",
            "sessions",
            "spans",
            "spec",
            "traces",
        ]:
            assert cmd in result.stdout, f"Command '{cmd}' missing from top-level help"


class TestProjectIdEnforcement:
    def test_sessions_list_requires_project_id_when_no_config(self):
        with (
            patch("requests.request", return_value=stub_api_response()),
            patch("zeroeval.cli.context.load_config", return_value={}),
        ):
            result = run_cli("sessions", "list")
        assert result.exit_code == 2
        assert "project-id" in result.stderr.lower()

    def test_judges_list_requires_project_id_when_no_config(self):
        with (
            patch("requests.request", return_value=stub_api_response()),
            patch("zeroeval.cli.context.load_config", return_value={}),
        ):
            result = run_cli("judges", "list")
        assert result.exit_code == 2
        assert "project-id" in result.stderr.lower()

    def test_prompts_list_requires_project_id_when_no_config(self):
        with (
            patch("requests.request", return_value=stub_api_response()),
            patch("zeroeval.cli.context.load_config", return_value={}),
        ):
            result = run_cli("prompts", "list")
        assert result.exit_code == 2
        assert "project-id" in result.stderr.lower()


class TestProjectIdResolutionChain:
    def test_flag_takes_precedence_over_config(self):
        cfg = {"api_key": "sk_test", "project_id": "from-config"}
        with (
            patch("requests.request", return_value=stub_api_response(200, [])),
            patch("zeroeval.cli.context.load_config", return_value=cfg),
        ):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "from-flag",
                "sessions",
                "list",
            )
        assert result.exit_code == 0

    def test_config_project_id_used_as_fallback(self):
        cfg = {"api_key": "sk_test", "project_id": "from-config"}
        with (
            patch("requests.request", return_value=stub_api_response(200, [])),
            patch("zeroeval.cli.context.load_config", return_value=cfg),
        ):
            result = run_cli("--output", "json", "sessions", "list")
        assert result.exit_code == 0

    def test_env_takes_precedence_over_config(self):
        cfg = {"api_key": "sk_test", "project_id": "from-config"}
        with (
            patch("requests.request", return_value=stub_api_response(200, [])),
            patch("zeroeval.cli.context.load_config", return_value=cfg),
        ):
            result = run_cli(
                "--output",
                "json",
                "sessions",
                "list",
                env={"ZEROEVAL_PROJECT_ID": "from-env"},
            )
        assert result.exit_code == 0


class TestAuthSetResolvesProject:
    def test_auth_set_persists_project_id(self):
        resolve_resp = stub_api_response(
            200, {"project_id": "proj-123", "project_name": "My Project"}
        )
        saved_configs = []

        def capture_save(config):
            saved_configs.append(dict(config))
            from pathlib import Path

            return Path("/tmp/fake-config.json")

        with (
            patch("zeroeval.cli.commands.auth.load_config", return_value={}),
            patch("zeroeval.cli.commands.auth.save_config", side_effect=capture_save),
            patch("requests.post", return_value=resolve_resp),
        ):
            result = run_cli(
                "--output", "json", "auth", "set", "--api-key", "sk_test_key"
            )

        assert result.exit_code == 0
        data = result.json()
        assert data.get("project_id") == "proj-123"
        assert data.get("project_name") == "My Project"
        assert saved_configs[-1]["project_id"] == "proj-123"

    def test_auth_set_works_when_resolve_fails(self):
        saved_configs = []

        def capture_save(config):
            saved_configs.append(dict(config))
            from pathlib import Path

            return Path("/tmp/fake-config.json")

        with (
            patch("zeroeval.cli.commands.auth.load_config", return_value={}),
            patch("zeroeval.cli.commands.auth.save_config", side_effect=capture_save),
            patch("requests.post", side_effect=Exception("network error")),
        ):
            result = run_cli(
                "--output", "json", "auth", "set", "--api-key", "sk_test_key"
            )

        assert result.exit_code == 0
        assert "project_id" not in saved_configs[-1]

    def test_auth_set_ignores_malformed_project_resolution_payload(self):
        saved_configs = []

        def capture_save(config):
            saved_configs.append(dict(config))
            from pathlib import Path

            return Path("/tmp/fake-config.json")

        with (
            patch("zeroeval.cli.commands.auth.load_config", return_value={}),
            patch("zeroeval.cli.commands.auth.save_config", side_effect=capture_save),
            patch(
                "requests.post",
                return_value=stub_api_response(200, {"project_name": "Missing ID"}),
            ),
        ):
            result = run_cli(
                "--output", "json", "auth", "set", "--api-key", "sk_test_key"
            )

        assert result.exit_code == 0
        data = result.json()
        assert data["configured"]["project_id"] is False
        assert "project_id" not in data
        assert "project_id" not in saved_configs[-1]


class TestAuthShowIncludesProject:
    def test_auth_show_displays_project_id(self):
        cfg = {
            "api_key": "sk_test",
            "project_id": "proj-123",
            "project_name": "My Project",
        }
        with patch("zeroeval.cli.commands.auth.load_config", return_value=cfg):
            result = run_cli("--output", "json", "auth", "show")

        assert result.exit_code == 0
        data = result.json()
        assert data["values"]["project_id"] == "proj-123"
        assert data["values"]["project_name"] == "My Project"
        assert data["configured"]["project_id"] is True


class TestOutputContract:
    def test_json_output_is_valid_json(self):
        with patch("requests.request", return_value=stub_api_response(200, [])):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "sessions",
                "list",
            )
        assert result.exit_code == 0
        parsed = result.json()
        assert isinstance(parsed, list)

    def test_error_on_stderr(self):
        with patch("zeroeval.cli.context.load_config", return_value={}):
            result = run_cli("sessions", "list")
        assert result.exit_code != 0
        assert result.stderr


class TestSpecIntegrity:
    def test_spec_cli_returns_commands(self):
        result = run_cli("spec", "cli")
        assert result.exit_code == 0
        data = result.json()
        assert "commands" in data
        assert isinstance(data["commands"], list)
        assert len(data["commands"]) > 0

    def test_spec_command_lookup(self):
        result = run_cli("spec", "command", "auth set")
        assert result.exit_code == 0
        data = result.json()
        assert data.get("path") == "auth set"


class TestExistingCommandsUnbroken:
    def test_auth_show_no_crash(self):
        result = run_cli("auth", "show")
        assert result.exit_code == 0

    def test_datasets_list_with_api_key(self):
        with patch("requests.request", return_value=stub_api_response(200, [])):
            result = run_cli("--output", "json", "datasets", "list")
        assert result.exit_code == 0
