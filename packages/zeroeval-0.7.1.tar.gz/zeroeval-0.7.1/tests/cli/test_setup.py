from __future__ import annotations

from unittest.mock import patch

from zeroeval.cli.setup import _resolve_project_from_key

from .conftest import stub_api_response


class TestResolveProjectFromKey:
    def test_returns_none_when_response_lacks_project_id(self):
        with patch(
            "requests.post",
            return_value=stub_api_response(200, {"project_name": "Missing ID"}),
        ):
            result = _resolve_project_from_key("sk_test_key")

        assert result is None
