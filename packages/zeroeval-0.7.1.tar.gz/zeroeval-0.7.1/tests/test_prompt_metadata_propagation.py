"""Tests for prompt metadata propagation to manual spans.

Ensures that once ze.prompt() or the OpenAI integration registers prompt
metadata for a trace, all subsequent spans in the same trace inherit
the metadata in their attributes automatically.
"""
import pytest

from zeroeval.observability import span
from zeroeval.observability.tracer import Tracer
from zeroeval.observability.prompt_context import (
    set_prompt_metadata,
    get_prompt_metadata,
    clear_prompt_metadata,
)


SAMPLE_METADATA = {
    "task": "support-ops-copilot",
    "variables": {},
    "zeroeval": {
        "task": "support-ops-copilot",
        "prompt_slug": "support-ops-copilot",
        "prompt_version": 1,
        "prompt_version_id": "pv-uuid-123",
        "content_hash": "abc123",
    },
}


@pytest.mark.core
def test_child_span_inherits_prompt_metadata(tracer: Tracer):
    """A child span created after prompt metadata is registered should carry
    `attributes.task` and `attributes.zeroeval`."""
    with span(name="root") as root_span:
        set_prompt_metadata(root_span.trace_id, SAMPLE_METADATA)

        with span(name="child", kind="llm") as child_span:
            pass

    tracer.flush()
    writer = tracer._writer
    child = next(s for s in writer.spans if s["name"] == "child")

    assert child["attributes"]["task"] == "support-ops-copilot"
    assert child["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"


@pytest.mark.core
def test_active_span_updated_when_metadata_set_mid_span(tracer: Tracer):
    """When prompt metadata is set while a span is already active, the currently
    active span should also receive the metadata (mirrors the demo pattern where
    resolve-ticket starts before ze.prompt runs)."""
    with span(name="root") as root_span:
        assert "task" not in root_span.attributes

        set_prompt_metadata(root_span.trace_id, SAMPLE_METADATA)
        for key, val in SAMPLE_METADATA.items():
            if key not in root_span.attributes:
                root_span.attributes[key] = val

        assert root_span.attributes["task"] == "support-ops-copilot"

    tracer.flush()
    writer = tracer._writer
    root = next(s for s in writer.spans if s["name"] == "root")
    assert root["attributes"]["task"] == "support-ops-copilot"


@pytest.mark.core
def test_prompt_metadata_cleared_between_traces(tracer: Tracer):
    """Prompt metadata for one trace must not leak into the next trace."""
    with span(name="trace1-root") as s1:
        set_prompt_metadata(s1.trace_id, SAMPLE_METADATA)
        with span(name="trace1-child") as c1:
            pass

    with span(name="trace2-root") as s2:
        with span(name="trace2-child") as c2:
            pass

    tracer.flush()
    writer = tracer._writer

    t1_child = next(s for s in writer.spans if s["name"] == "trace1-child")
    assert t1_child["attributes"]["task"] == "support-ops-copilot"

    t2_child = next(s for s in writer.spans if s["name"] == "trace2-child")
    assert "task" not in t2_child["attributes"]


@pytest.mark.core
def test_explicit_attributes_override_prompt_context(tracer: Tracer):
    """Span-level explicit attributes take precedence over inherited prompt
    metadata."""
    with span(name="root") as root_span:
        set_prompt_metadata(root_span.trace_id, SAMPLE_METADATA)

        with span(name="override", kind="llm", attributes={"task": "custom-task"}) as child:
            pass

    tracer.flush()
    writer = tracer._writer
    child = next(s for s in writer.spans if s["name"] == "override")
    assert child["attributes"]["task"] == "custom-task"


@pytest.mark.core
def test_prompt_context_module_isolation():
    """Low-level prompt_context module: set/get/clear lifecycle."""
    tid = "test-trace-id-isolation"

    assert get_prompt_metadata(tid) is None

    set_prompt_metadata(tid, SAMPLE_METADATA)
    md = get_prompt_metadata(tid)
    assert md is not None
    assert md["task"] == "support-ops-copilot"

    clear_prompt_metadata(tid)
    assert get_prompt_metadata(tid) is None


@pytest.mark.core
def test_demo_shape_full_flow(tracer: Tracer):
    """Reproduce the demo shape: root span -> ze.prompt sets context ->
    auto OpenAI span (simulated) -> manual card span. Both non-root spans
    should carry prompt metadata."""
    with span(name="resolve-ticket") as root:
        set_prompt_metadata(root.trace_id, SAMPLE_METADATA)
        for key, val in SAMPLE_METADATA.items():
            if key not in root.attributes:
                root.attributes[key] = val

        with span(name="openai.chat.completions.create", kind="llm",
                   attributes={
                       "task": "support-ops-copilot",
                       "zeroeval": SAMPLE_METADATA["zeroeval"],
                       "variables": {},
                   }):
            pass

        with span(name="generate-customer-card", kind="llm",
                   tags={"has_customer_card": "true"}):
            pass

    tracer.flush()
    writer = tracer._writer

    openai_span = next(s for s in writer.spans if s["name"] == "openai.chat.completions.create")
    card_span = next(s for s in writer.spans if s["name"] == "generate-customer-card")

    assert openai_span["attributes"]["task"] == "support-ops-copilot"
    assert openai_span["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"

    assert card_span["attributes"]["task"] == "support-ops-copilot"
    assert card_span["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"
    assert card_span["tags"]["has_customer_card"] == "true"
