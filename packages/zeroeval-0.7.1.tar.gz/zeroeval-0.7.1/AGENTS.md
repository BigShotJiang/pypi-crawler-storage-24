# AGENTS.md

This file provides guidance to Codex (Codex.ai/code) when working with code in this repository.

## Project Overview

ZeroEval SDK — Python SDK for AI experiment tracking, evaluation, and observability. Supports dataset management, experiment execution, tracing (via OpenTelemetry), prompt versioning, A/B testing, and auto-instrumentation of LLM frameworks (OpenAI, Gemini, LangChain, LangGraph, etc.).

## Commands

```bash
# Install dependencies
uv sync --group dev

# Run all tests
uv run pytest tests/

# Run core tests only
uv run pytest tests/core/ -v --tb=short

# Run a single test file
uv run pytest tests/core/test_tracer.py

# Run performance tests (skipped by default)
uv run pytest tests/performance/ --runperformance -v --tb=short

# Formatting
uv run ruff format --check --diff .
uv run ruff format .              # auto-fix

# Linting
uv run ruff check .
uv run ruff check . --fix         # auto-fix

# Type checking
uv run mypy src/zeroeval --show-error-codes

# Multi-Python testing (3.9–3.13)
uv run tox --parallel auto
```

## Architecture

### Source layout (`src/zeroeval/`)

- **`__init__.py`** — Public API surface. The module aliases itself as `ze` (`ze = sys.modules[__name__]`) so users write `ze.init()`, `ze.span()`, etc.
- **`core/`** — Experiment engine: `Dataset`, `@task`, `@evaluation` (row/column/run modes), `@column_metric`, `@run_metric`, `init()`, reader/writer for backend communication.
- **`observability/`** — Tracing system: singleton `Tracer`, `Span` class, `@span` decorator, `choose()` (A/B testing), `set_signal()`. Spans are buffered and flushed in batches to the backend via OTLP.
- **`observability/integrations/`** — Auto-instrumentation for frameworks. Each integration subpackage (openai, gemini, langchain, langgraph, httpx, pydanticai, vocode) patches client libraries to emit spans. Managed by a registry (`registry.py`) with `BaseIntegration` interface.
- **`client.py`** — `ZeroEval` client for Prompt Library access (fetch/version prompts, log completions, send feedback).
- **`cli/`** — Agent-first CLI entrypoint:
  - `zeroeval setup` (interactive auth setup)
  - `zeroeval auth ...` (non-interactive global auth configuration)
  - `zeroeval datasets ...` (read-only dataset inspection)
  - `zeroeval evals ...` (read-only eval/run inspection)
  - `zeroeval spec ...` (machine-readable command/parameter manual dump)
- **`providers.py`** — OpenTelemetry provider configuration.
- **`types.py`** — `Prompt` dataclass and related types.

### Key patterns

- **Decorator-based API**: `@task`, `@evaluation`, `@span`, `@column_metric`, `@run_metric` are the primary user-facing decorators.
- **Singleton Tracer**: `tracer` is a thread-safe singleton managing the Session > Trace > Span hierarchy.
- **Module-as-namespace**: The top-level `zeroeval` module is aliased as `ze`, so all public API is accessed via `ze.*`.
- **Lazy integration loading**: Framework integrations are auto-detected and patched only when the corresponding library is installed.
- **Dot notation access**: `DotDict` allows `row.column_name` syntax on dataset rows.

## Code Quality

- **Ruff** for formatting and linting (line-length 88, target py39, rules: E, F, UP, B, SIM, I).
- **MyPy** for type checking.
- Python **3.9–3.13** compatibility required.
- CI runs quality checks + tests across the full Python version matrix.

## Testing & Documentation Requirements

- Run tests after every modification. New features must have tests.
- For SDK changes, check `/docs/tracing/sdks/python/` and update documentation accordingly.
