# NeuroStack Vault Optimization Plan

**Phase goal:** Implement highest-impact vault optimizations from stochastic consensus review -- fix broken retrieval, populate missing data, reduce token waste, and activate dormant neuroscience features.

**Total:** 6 plans across 4 waves. Estimated ~4 hours Claude execution time.

**Architectural constraint:** NeuroStack NEVER modifies vault files. The vault is a read-only Markdown source. All computed metadata (frontmatter, status, tags, excitability) lives in SQLite (`~/.local/share/neurostack/`). Memory writeback goes to NeuroStack-owned storage, not the vault.

---

## Wave Structure

| Wave | Plans | Parallel | Autonomous |
|------|-------|----------|------------|
| 0 | Plan 00 | no | yes |
| 1 | Plan 01, Plan 02 | yes | yes, yes |
| 2 | Plan 03, Plan 04 | yes | yes, yes |
| 3 | Plan 05 | -- | no (checkpoint) |

---

## Plan 00 — Enforce read-only vault guarantee (Wave 0)

**Objective:** Make the "never touches your vault files" claim unconditionally true. SQLite becomes the source of truth for all NeuroStack-managed metadata. The vault is read-only input.

**Files modified:**
- `src/neurostack/schema.py`
- `src/neurostack/cli.py`
- `src/neurostack/server.py`
- `src/neurostack/vault_writer.py`
- `src/neurostack/watcher.py`
- `src/neurostack/search.py`
- `tests/test_schema.py`

**Depends on:** nothing

### Task 1: Add `note_metadata` table for SQLite-owned metadata

**Files:** `src/neurostack/schema.py`, `tests/test_schema.py`

**Action:**
Add a new table that stores NeuroStack-managed metadata independently of vault file frontmatter. This is the foundation for read-only vault operation.

```sql
CREATE TABLE IF NOT EXISTS note_metadata (
    note_path TEXT PRIMARY KEY,
    status TEXT DEFAULT 'active',          -- active/dormant/reference
    tags TEXT,                              -- JSON array, generated if file has none
    note_type TEXT DEFAULT 'permanent',     -- permanent/literature/project/daily
    actionable INTEGER DEFAULT 0,
    compositional INTEGER DEFAULT 0,
    date_added TEXT,                        -- when NeuroStack first saw this note
    FOREIGN KEY (note_path) REFERENCES notes(path) ON DELETE CASCADE
);
```

Add as a schema migration (v11). The migration should populate `note_metadata` from existing `notes.frontmatter` for all current notes — one-time backfill.

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/test_schema.py -x -v
```

**Done:** `note_metadata` table exists with data backfilled from existing frontmatter.

### Task 2: Refactor `onboard` to be vault-read-only

**Files:** `src/neurostack/cli.py`

**Action:**
Currently `cmd_onboard()` (cli.py:1069) writes frontmatter directly into `.md` files (line 1140: `md.write_text(new_fm + content)`). Refactor to:

1. Parse notes as before (detect missing frontmatter, guess type from location, derive tags from parent dir)
2. Instead of writing to the `.md` file, insert into `note_metadata`:
   ```python
   conn.execute(
       "INSERT OR IGNORE INTO note_metadata (note_path, status, tags, note_type, date_added) VALUES (?, ?, ?, ?, ?)",
       (rel_path, "active", json.dumps(tags), note_type, today),
   )
   ```
3. Still generate `index.md` files — these are NeuroStack scaffolding, not user vault files. But gate behind a `--scaffold` flag (off by default). Print a message: "Use --scaffold to create index.md and structural directories."
4. Add a `--write-frontmatter` flag for users who explicitly want frontmatter injected into their files (opt-in, not default). Print a warning: "This will modify your vault files."

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/ -k onboard -x -v
```

**Done:** `neurostack onboard /path/to/notes` indexes notes without modifying any files. Metadata lives in SQLite.

### Task 3: Move VaultWriter output to NeuroStack-owned storage

**Files:** `src/neurostack/vault_writer.py`, `src/neurostack/server.py`, `src/neurostack/cli.py`

**Action:**
Currently `VaultWriter` writes memory `.md` files into the vault directory (`{vault_root}/memories/`). Move to NeuroStack-owned storage:

1. Change `VaultWriter.__init__` default path from `vault_root / writeback_path` to `~/.local/share/neurostack/memories/`
2. Update `server.py` (line 52) where `_writer` is constructed — pass the new path
3. Update `cli.py` where `VaultWriter` is constructed (line 947)
4. The `_check_containment` method should validate against the new base path, not vault_root
5. Add a config key `writeback_path` defaulting to `~/.local/share/neurostack/memories/` (overridable for users who want vault writeback)

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/ -x -v
```

**Done:** `vault_remember` writes to `~/.local/share/neurostack/memories/`, not inside the vault.

### Task 4: Update search to read from `note_metadata` with file-frontmatter fallback

**Files:** `src/neurostack/search.py`, `src/neurostack/watcher.py`

**Action:**
The excitability boost in `hybrid_search()` (line 475-485) reads `status` from `notes.frontmatter`. Update to:

1. Prefer `note_metadata.status` over `notes.frontmatter` parsed status
2. In the batched frontmatter query (from Plan 02), join with `note_metadata`:
   ```sql
   SELECT n.path, n.frontmatter, nm.status AS meta_status
   FROM notes n LEFT JOIN note_metadata nm ON n.path = nm.note_path
   WHERE n.path IN (...)
   ```
3. Use `meta_status` if present, fall back to frontmatter-parsed status

Update `watcher.py` to populate `note_metadata` when indexing new files:
- When a new note is indexed, insert into `note_metadata` using frontmatter values if present, or defaults if not
- When re-indexing, do NOT overwrite existing `note_metadata` — file frontmatter provides initial values, SQLite overrides persist

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/test_search.py -x -v
```

**Done:** Search reads status from `note_metadata` table. Watcher populates metadata on first index without overwriting overrides. Vault files are never modified.

---

## Plan 01 — Fix FTS5 recall + remove JSON indent bloat (Wave 1)

**Objective:** Fix the two most impactful code-only changes: FTS5 implicit-AND destroying recall, and `indent=2` wasting 24% of MCP response tokens.

**Files modified:**
- `src/neurostack/search.py`
- `src/neurostack/server.py`
- `tests/test_search.py`

**Depends on:** nothing

### Task 1: Fix FTS5 implicit-AND recall failure (TDD)

**Files:** `src/neurostack/search.py`, `tests/test_search.py`

**Behavior (write tests first):**
- `fts_search(conn, "neuroscience brain cognition")` returns results (currently 1 due to AND)
- Multi-word queries join tokens with `OR` not implicit `AND`
- Single-word queries still work correctly
- `triple_fts_search` also uses `OR` joining (same bug at line ~568)
- Queries with special characters still safely escaped

**Action:**
In `search.py`, function `fts_search()` (line 108), change the `safe_query` construction from:
```python
safe_query = " ".join(
    '"' + word.replace('"', '') + '"'
    for word in query.split()
    if word and not word.startswith("-")
)
```
to:
```python
safe_query = " OR ".join(
    '"' + word.replace('"', '') + '"'
    for word in query.split()
    if word and not word.startswith("-")
)
```

Apply the identical fix to `triple_fts_search()` (line ~568) which has the same pattern.

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/test_search.py -x -v
```

**Done:** Multi-word FTS5 queries return OR-joined results. `vault_search("neuroscience brain cognition")` returns relevant hits instead of empty/1 result.

### Task 2: Remove indent=2 from MCP JSON responses

**Files:** `src/neurostack/server.py`

**Action:**
Replace all 16 instances of `json.dumps(..., indent=2)` with `json.dumps(...)` in `server.py`. These are MCP tool return values consumed by Claude, not human-readable output. The `indent=2` adds ~24% character overhead (~266 tokens/response).

Specific lines to change: 99, 128, 162, 237, 282, 302, 351, 386, 431, 507, 687, 917, 938, 967, 1012, 1036.

For the one instance using `default=str` (line 938: `json.dumps(result, indent=2, default=str)`), keep the `default=str` kwarg: `json.dumps(result, default=str)`.

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && ! grep -n 'indent=2' src/neurostack/server.py
```

**Done:** Zero instances of `indent=2` in server.py. MCP responses are compact JSON.

---

## Plan 02 — Batch N+1 queries in search hot path (Wave 1)

**Objective:** Eliminate ~100-310 individual SQL queries per search by batching hotness lookups, frontmatter reads, and result enrichment into `WHERE IN` queries.

**Files modified:**
- `src/neurostack/search.py`

**Depends on:** nothing

### Task 1: Batch hotness scoring in hybrid_search

**Files:** `src/neurostack/search.py`

**Action:**
The hotness blend loop (lines 466-469) calls `hotness_score()` per result, each doing 1-2 SQL queries. Replace with a batch function:

1. Add a new function `batch_hotness_scores(conn, note_paths, half_life_days=30.0) -> dict[str, float]` that:
   - Fetches all usage rows in one query: `SELECT note_path, used_at FROM note_usage WHERE note_path IN (...) ORDER BY note_path, used_at DESC`
   - Groups by note_path, computes the same sigmoid * decay formula per group
   - Returns `{note_path: score}` dict

2. In `hybrid_search()`, before the hotness blend loop, collect all note_paths from `valid_results`, call `batch_hotness_scores()` once, then use the returned dict in the loop.

3. Similarly, batch the excitability boost (lines 474-485) which does a per-result `SELECT frontmatter FROM notes WHERE path = ?`. Replace with a single query:
   ```sql
   SELECT path, frontmatter FROM notes WHERE path IN (...)
   ```
   Build a `{path: frontmatter}` dict and look up in the loop.

4. Batch `_to_search_results()` (lines 521-553) which does 2 individual queries per result (title + summary). Replace with:
   ```sql
   SELECT path, title FROM notes WHERE path IN (...)
   SELECT note_path, summary_text FROM summaries WHERE note_path IN (...)
   ```
   Build dicts and look up per result.

Keep `hotness_score()` (the single-note version) for backward compatibility -- it's used by `get_dormancy_report()` and the CLI.

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/test_search.py -x -v
```

**Done:** `hybrid_search()` issues ~5-8 SQL queries total instead of ~100-310. Search latency does not regress.

---

## Plan 03 — Wire auto-record usage + excitability demotion (Wave 2)

**Objective:** Make the CREB excitability model functional: auto-record usage when search returns results, and automatically demote notes that have decayed below threshold.

**Files modified:**
- `src/neurostack/search.py`
- `src/neurostack/server.py`
- `tests/test_search.py`

**Depends on:** Plan 00 (needs `note_metadata` table), Plan 02 (uses batched hotness scores)

### Task 1: Auto-record usage in hybrid_search return path

**Files:** `src/neurostack/search.py`, `src/neurostack/server.py`

**Action:**
The `note_usage` table has 0 rows because `record_usage()` is only called via explicit MCP tool / CLI command. Wire it into the search return path:

1. In `hybrid_search()`, after deduplication and before returning results (after line ~518), insert usage records for the returned note_paths:
   ```python
   # Auto-record usage for returned results
   returned_paths = [r["note_path"] for r in deduped[:top_k]]
   if returned_paths:
       conn.executemany(
           "INSERT INTO note_usage (note_path) VALUES (?)",
           [(p,) for p in returned_paths],
       )
       conn.commit()
   ```

2. Do NOT add recording to `fts_search()` or `triple_fts_search()` -- these are internal building blocks, not user-facing search.

3. Do NOT add recording to `_to_search_results()` -- it would double-count since hybrid_search calls it.

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/test_search.py -x -v
```

**Done:** `note_usage` table accumulates rows as vault_search is used. `hotness_score()` starts returning non-zero values.

### Task 2: Implement automated excitability demotion

**Files:** `src/neurostack/search.py`, `src/neurostack/server.py`

**Action:**
Currently `get_dormancy_report()` reads data but never writes back. The excitability model (CREB) is decorative. Add a demotion function and wire it into a periodic trigger:

1. Add `run_excitability_demotion(conn, threshold=0.05, half_life_days=30.0) -> dict` to `search.py`:
   - Call `get_dormancy_report(conn, threshold, half_life_days, limit=0)` to get dormant notes
   - For each dormant note, update the `note_metadata` table: `UPDATE note_metadata SET status = 'dormant' WHERE note_path = ? AND status = 'active'`
   - For each never-used note older than 90 days (check `indexed_at`), demote in `note_metadata` if currently `"active"`
   - Return `{"demoted": N, "paths": [...]}` for logging
   - Vault .md files are NEVER modified -- all status changes are in `note_metadata` only

2. Wire into `vault_stats()` in server.py as a side-effect: after computing stats, call `run_excitability_demotion(conn)`. This is a natural periodic trigger since Claude calls `vault_stats()` regularly. Keep it non-blocking (wrap in try/except, log failures).

3. Also expose as CLI command by adding to the existing `cmd_decay` function in cli.py: add a `--demote` flag that calls `run_excitability_demotion()` and prints results.

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/test_search.py -x -v
```

**Done:** Notes with decayed hotness below 0.05 get automatically demoted from `status:active` to `status:dormant` in `note_metadata`. Vault files are untouched. Excitability boost (1.15x) now correctly favors genuinely active notes.

---

## Plan 04 — Data population tasks (Wave 2)

**Objective:** Run CLI commands to populate missing data: community summaries, memory embeddings/dedup, and missing triples. These are data operations, not code changes.

**Files modified:** none (data-only operations on SQLite DB)

**Depends on:** Plan 01 (FTS5 fix must be in place before backfill uses search)

### Task 1: Build community summaries

**Action:**
Run community summarization to populate the 54 detected but unsummarized communities. This requires Ollama to be running.

```bash
cd /home/raphasouthall/tools/neurostack

# Verify communities exist but lack summaries
uv run neurostack stats | grep -i communit

# Build summaries (requires Ollama at localhost:11434)
uv run neurostack communities build --summarize

# Verify summaries populated
uv run neurostack communities query "what topics are covered in the vault"
```

If Ollama is not running, start it first: `systemctl --user start ollama` or check `curl -s http://localhost:11434/api/tags`.

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run python -c "
from neurostack.schema import get_db, DB_PATH
conn = get_db(DB_PATH)
total = conn.execute('SELECT COUNT(*) as c FROM communities').fetchone()['c']
summarized = conn.execute('SELECT COUNT(*) as c FROM communities WHERE summary IS NOT NULL').fetchone()['c']
print(f'Communities: {summarized}/{total} summarized')
assert summarized > 0, 'No communities summarized'
"
```

**Done:** `vault_communities("what neuroscience topics are covered")` returns a thematic synthesized answer instead of empty.

### Task 2: Backfill memory embeddings and deduplicate

**Action:**
31/60 memories lack embeddings. After backfilling, run semantic dedup to identify and merge duplicate clusters.

```bash
cd /home/raphasouthall/tools/neurostack

# Check current state
uv run python -c "
from neurostack.schema import get_db, DB_PATH
conn = get_db(DB_PATH)
total = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
with_emb = conn.execute('SELECT COUNT(*) FROM memories WHERE embedding IS NOT NULL').fetchone()[0]
print(f'Memories: {with_emb}/{total} have embeddings')
"

# Backfill missing embeddings
uv run python -c "
from neurostack.schema import get_db, DB_PATH
from neurostack.embedder import get_embedding, embedding_to_blob
from neurostack.config import get_config
cfg = get_config()
conn = get_db(DB_PATH)
rows = conn.execute('SELECT memory_id, content FROM memories WHERE embedding IS NULL').fetchall()
print(f'Backfilling {len(rows)} memories...')
for r in rows:
    try:
        emb = get_embedding(r['content'], base_url=cfg.embed_url)
        blob = embedding_to_blob(emb)
        conn.execute('UPDATE memories SET embedding = ? WHERE memory_id = ?', (blob, r['memory_id']))
        conn.commit()
        print(f'  Embedded memory {r[\"memory_id\"]}')
    except Exception as e:
        print(f'  Failed memory {r[\"memory_id\"]}: {e}')
print('Done')
"

# Find and list duplicate clusters for manual review
uv run python -c "
from neurostack.schema import get_db, DB_PATH
from neurostack.memories import find_similar_memories
from neurostack.config import get_config
cfg = get_config()
conn = get_db(DB_PATH)
rows = conn.execute('SELECT memory_id, content, entity_type FROM memories ORDER BY memory_id').fetchall()
seen = set()
clusters = []
for r in rows:
    if r['memory_id'] in seen:
        continue
    similar = find_similar_memories(conn, r['content'], threshold=0.85, exclude_ids=[r['memory_id']], embed_url=cfg.embed_url)
    if similar:
        cluster = [r['memory_id']] + [m.memory_id for m, _ in similar]
        for mid in cluster:
            seen.add(mid)
        clusters.append({'target': r['memory_id'], 'duplicates': [m.memory_id for m, _ in similar], 'content_preview': r['content'][:80]})
print(f'Found {len(clusters)} duplicate clusters')
for c in clusters:
    print(f'  Keep {c[\"target\"]}, merge: {c[\"duplicates\"]} — {c[\"content_preview\"]}')
"
```

Review the duplicate clusters output. Then merge each cluster using the NeuroStack merge API:
```bash
# For each cluster, merge source into target:
# uv run neurostack memories merge <target_id> <source_id>
```

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run python -c "
from neurostack.schema import get_db, DB_PATH
conn = get_db(DB_PATH)
total = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
with_emb = conn.execute('SELECT COUNT(*) FROM memories WHERE embedding IS NOT NULL').fetchone()[0]
print(f'Memories: {with_emb}/{total} have embeddings')
assert with_emb == total, f'{total - with_emb} memories still missing embeddings'
assert total < 55, f'Expected dedup to reduce from 60, got {total}'
"
```

**Done:** All memories have embeddings. Duplicate clusters merged down from ~60 to ~40 unique memories.

### Task 3: Backfill missing triples

**Action:**
34 notes (9% of vault) are missing triples, excluding them from the triples-first path in auto depth mode.

```bash
cd /home/raphasouthall/tools/neurostack

# Identify notes missing triples
uv run python -c "
from neurostack.schema import get_db, DB_PATH
conn = get_db(DB_PATH)
missing = conn.execute('''
    SELECT n.path FROM notes n
    WHERE NOT EXISTS (SELECT 1 FROM triples t WHERE t.note_path = n.path)
    ORDER BY n.path
''').fetchall()
print(f'{len(missing)} notes missing triples:')
for r in missing:
    print(f'  {r[\"path\"]}')
"

# Backfill triples for missing notes
uv run neurostack backfill --triples-only
```

Note: `neurostack backfill` may not have a `--triples-only` flag. Check available flags with `uv run neurostack backfill --help`. If not available, use the full backfill which handles both summaries and triples for notes that need them.

**Verify:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run python -c "
from neurostack.schema import get_db, DB_PATH
conn = get_db(DB_PATH)
total = conn.execute('SELECT COUNT(*) FROM notes').fetchone()[0]
with_triples = conn.execute('SELECT COUNT(DISTINCT note_path) FROM triples').fetchone()[0]
coverage = with_triples / total * 100
print(f'Triple coverage: {with_triples}/{total} ({coverage:.1f}%)')
assert coverage > 95, f'Triple coverage {coverage:.1f}% below 95% target'
"
```

**Done:** Triple coverage >95%. Auto-depth triples-first path includes previously excluded notes.

---

## Plan 05 — End-to-end verification (Wave 3)

**Objective:** Verify all optimizations work together and no regressions introduced.

**Depends on:** Plans 01, 02, 03, 04

### Task 1: Run full test suite

**Action:**
```bash
cd /home/raphasouthall/tools/neurostack && uv run pytest tests/ -x -v
```

**Done:** All existing tests pass. No regressions.

### Task 2 (checkpoint:human-verify): Verify search and community queries

**What was built:** FTS5 OR-joining, community summaries, batched search, auto usage recording, excitability demotion, memory dedup, triple backfill.

**How to verify:**

1. Test FTS5 recall fix:
```bash
cd /home/raphasouthall/tools/neurostack
uv run neurostack search "neuroscience brain cognition" --top-k 5
```
Expected: Multiple relevant results (was returning 0-1 before).

2. Test community queries:
```bash
uv run neurostack communities query "what neuroscience topics are covered in the vault"
```
Expected: Thematic synthesized answer (was returning empty before).

3. Test search records usage:
```bash
uv run python -c "
from neurostack.schema import get_db, DB_PATH
conn = get_db(DB_PATH)
count = conn.execute('SELECT COUNT(*) FROM note_usage').fetchone()[0]
print(f'Usage records: {count}')
"
```
Expected: Non-zero usage records from the searches above.

4. Test token efficiency (spot check one MCP response):
```bash
uv run python -c "
from neurostack.server import vault_stats
import json
# vault_stats returns a JSON string -- verify no indent
result = vault_stats()
assert '\n' not in result or result.count('\n') < 3, 'Response still has indent formatting'
print('Compact JSON confirmed')
print(f'Response length: {len(result)} chars')
"
```

5. Check memory state:
```bash
uv run neurostack memories stats
```

**Resume signal:** Type "approved" or describe issues found.

---

## Dependency Graph

```
Plan 00 (Read-only vault) ──┐
                             ├──> Plan 01 (FTS5 + JSON indent)  ──┐
                             │                                     ├──> Plan 04 (Data population) ──┐
                             ├──> Plan 02 (Batch N+1 queries)  ──┤                                  ├──> Plan 05 (Verify)
                             │                                     └──> Plan 03 (Usage + demotion) ──┘
                             └──────────────────────────────────────────> Plan 03 (needs note_metadata)
```

## Deferred (medium-term, not in this phase)

These items had 2-3/5 consensus (divergence) and require design work:
- Replay consolidation at session_end (item 9)
- Memory-to-vault-note promotion pipeline (item 10)
- vault-oracle migration consolidation (item 11)

## Must-Haves

**Observable truths:**
- Multi-word vault_search returns relevant results (not empty)
- vault_communities returns thematic answers (not empty)
- Search latency <= 100ms (no regression from 50ms baseline)
- MCP responses are compact JSON (no indent whitespace)
- note_usage table accumulates rows during normal search
- Dormant notes get demoted from active status automatically

**Required artifacts:**
- `src/neurostack/schema.py` — `note_metadata` table (v11 migration), backfill from existing frontmatter
- `src/neurostack/search.py` — OR-joined FTS5 queries, batch_hotness_scores(), auto-record usage, run_excitability_demotion() writing to `note_metadata`
- `src/neurostack/server.py` — compact json.dumps(), demotion wired into vault_stats()
- `src/neurostack/cli.py` — `onboard` writes to `note_metadata` not vault files
- `src/neurostack/vault_writer.py` — writes to `~/.local/share/neurostack/memories/` not vault
- `src/neurostack/watcher.py` — populates `note_metadata` on first index, preserves overrides
- `tests/test_search.py` — tests for OR-joined FTS5 behavior
- `tests/test_schema.py` — tests for note_metadata migration

**Key links:**
- `note_metadata` table is source of truth for status/tags (if missing: excitability falls back to file frontmatter)
- `fts_search()` safe_query uses `" OR "` join (if broken: recall drops to AND-only)
- `hybrid_search()` -> `INSERT INTO note_usage` (if broken: hotness scores stay 0)
- `vault_stats()` -> `run_excitability_demotion()` writes to `note_metadata` (if broken: CREB model stays decorative)
- `VaultWriter` targets `~/.local/share/neurostack/memories/` (if wrong: vault read-only guarantee broken)
- `cmd_onboard()` writes to `note_metadata` not `.md` files (if wrong: vault read-only guarantee broken)
- Community summaries populated in DB (if empty: vault_communities returns nothing)

**Architectural invariant:**
NeuroStack NEVER writes to, modifies, or creates files inside the user's vault directory. The vault is a read-only Markdown source. All computed state lives in `~/.local/share/neurostack/`.
