"""
Utility functions for the Nirmi Events SDK
"""

import math
import re
import logging
from typing import Optional
import requests

logger = logging.getLogger(__name__)


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between two coordinates in kilometers using Haversine formula"""
    R = 6371  # Earth's radius in kilometers
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    return R * c


def get_city_from_coordinates(lat: float, lng: float, google_api_key: Optional[str] = None) -> Optional[str]:
    """Reverse geocode coordinates to get city name using Google Geocoding API
    
    Returns the city name in lowercase for consistent matching
    """
    try:
        if not google_api_key:
            logger.warning("Google API key not found for reverse geocoding")
            return None
        
        url = "https://maps.googleapis.com/maps/api/geocode/json"
        params = {
            "latlng": f"{lat},{lng}",
            "key": google_api_key,
            "language": "en"
        }
        
        response = requests.get(url, params=params, timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get("results"):
                # Try multiple methods to extract city name
                for result in data.get("results", []):
                    address_components = result.get("address_components", [])
                    
                    # First priority: locality (city)
                    for component in address_components:
                        types = component.get("types", [])
                        if "locality" in types:
                            city_name = component.get("long_name", "").strip()
                            if city_name:
                                logger.debug(f"Found city from locality: {city_name}")
                                return city_name.lower()
                    
                    # Second priority: administrative_area_level_2 or administrative_area_level_1
                    for component in address_components:
                        types = component.get("types", [])
                        if "administrative_area_level_2" in types or "administrative_area_level_1" in types:
                            city_name = component.get("long_name", "").strip()
                            if city_name and len(city_name.split()) <= 3:
                                logger.debug(f"Found city from administrative area: {city_name}")
                                return city_name.lower()
                
                # Fallback: Extract from formatted address
                first_result = data.get("results", [])[0]
                formatted = first_result.get("formatted_address", "")
                if formatted:
                    parts = [p.strip() for p in formatted.split(",")]
                    if parts:
                        for part in parts[:2]:
                            if part and not any(char.isdigit() for char in part):
                                logger.debug(f"Found city from formatted address: {part}")
                                return part.lower()
        else:
            logger.warning(f"Geocoding API returned status {response.status_code}")
    except Exception as e:
        logger.error(f"Reverse geocoding error: {e}")
    return None


def city_to_eventbrite_slug(city: str) -> str:
    """Convert city name to Eventbrite location slug format"""
    slug = city.lower().strip()
    slug = re.sub(r'[^\w\s-]', '', slug)
    slug = re.sub(r'[-\s]+', '-', slug)
    return slug


def deduplicate_events(events: list) -> list:
    """Deduplicate events - only remove obvious duplicates (same event with VIP/package variations)
    
    Only deduplicates when events have nearly identical names (just VIP/package differences)
    and are at the same venue. Keeps distinct events separate.
    """
    if not events:
        return []
    
    def get_base_name(name: str) -> str:
        """Get base name, removing only obvious VIP/package suffixes"""
        normalized = name.lower().strip()
        if re.search(r'\s*(vip|package).*$', normalized, re.IGNORECASE):
            normalized = re.sub(r'\s*[|–-]\s*(vip|package).*$', '', normalized, flags=re.IGNORECASE)
            normalized = re.sub(r'\s+(vip|package).*$', '', normalized, flags=re.IGNORECASE)
        return normalized.strip()
    
    seen = {}
    deduplicated = []
    
    for event in events:
        name = event.get('name', '')
        venue = event.get('venue_name', '').lower().strip()
        base_name = get_base_name(name)
        key = f"{base_name}|{venue}"
        
        if key in seen:
            existing_event = seen[key]
            existing_name_lower = existing_event.get('name', '').lower()
            current_name_lower = name.lower()
            
            if re.search(r'\b(vip|package)\b', current_name_lower) and not re.search(r'\b(vip|package)\b', existing_name_lower):
                logger.debug(f"Skip duplicate: '{name}' (VIP variant)")
                continue
            elif re.search(r'\b(vip|package)\b', existing_name_lower) and not re.search(r'\b(vip|package)\b', current_name_lower):
                logger.debug(f"Replace duplicate: keeping base '{name}'")
                deduplicated.remove(existing_event)
                deduplicated.append(event)
                seen[key] = event
                continue
        
        deduplicated.append(event)
        seen[key] = event
    
    return deduplicated
