"""
Event APIs integration for Nirmi Events SDK
Supports Eventbrite and Ticketmaster
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import requests
import traceback

from .utils import haversine_distance, get_city_from_coordinates, city_to_eventbrite_slug

logger = logging.getLogger(__name__)


def get_mock_eventbrite_events() -> List[Dict[str, Any]]:
    """Mock Eventbrite events for testing"""
    tomorrow = datetime.now() + timedelta(days=1)
    return [
        {
            "id": "mock_eb_1",
            "name": "Jazz Night at Barcelona Jazz Club",
            "description": "Live jazz performance featuring local artists",
            "start_time": tomorrow.strftime("%Y-%m-%dT20:00:00"),
            "url": "https://eventbrite.com/mock1",
            "venue_name": "Barcelona Jazz Club",
            "source": "eventbrite"
        },
        {
            "id": "mock_eb_2",
            "name": "Food & Wine Tasting Tour",
            "description": "Explore local cuisine and wine",
            "start_time": (tomorrow + timedelta(days=2)).strftime("%Y-%m-%dT18:00:00"),
            "url": "https://eventbrite.com/mock2",
            "venue_name": "Born District",
            "source": "eventbrite"
        }
    ]


def get_mock_ticketmaster_events() -> List[Dict[str, Any]]:
    """Mock Ticketmaster events for testing"""
    next_week = datetime.now() + timedelta(days=7)
    return [
        {
            "id": "mock_tm_1",
            "name": "Concert at Palau de la Música",
            "description": "Classical music concert",
            "start_time": next_week.strftime("%Y-%m-%dT19:30:00"),
            "url": "https://ticketmaster.com/mock1",
            "venue_name": "Palau de la Música Catalana",
            "source": "ticketmaster"
        }
    ]


def get_eventbrite_events(
    lat: float, 
    lng: float, 
    google_api_key: Optional[str] = None,
    eventbrite_api_key: Optional[str] = None,
    start_time: Optional[datetime] = None, 
    end_time: Optional[datetime] = None, 
    radius_km: int = 5
) -> List[Dict[str, Any]]:
    """Get events from Eventbrite using the /api/v3/destination/events/ endpoint
    
    This function uses a two-step approach:
    1. First, tries to get event IDs from the search endpoint
    2. Then, uses those IDs to call /api/v3/destination/events/?event_ids={ids} to get detailed event data
    
    We fetch events and then filter by distance from the given coordinates.
    
    Args:
        lat: Latitude
        lng: Longitude
        google_api_key: Google API key for city detection (optional)
        eventbrite_api_key: Eventbrite API key (optional, not currently required for browser endpoints)
        start_time: Start time filter (optional)
        end_time: End time filter (optional)
        radius_km: Search radius in kilometers
    
    Returns:
        List of events with id, name, description, start_time, end_time, url, venue_name, venue_address, etc.
    """
    try:
        event_ids = []
        
        # Step 1: Try to get event IDs from Eventbrite destination search
        search_url = "https://www.eventbrite.com/api/v3/destination/search/"
        search_headers = {
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "content-type": "application/json",
            "origin": "https://www.eventbrite.com",
            "referer": "https://www.eventbrite.com/",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "x-requested-with": "XMLHttpRequest"
        }

        search_payload = {
            "browse_surface": "category_browse",
            "event_search": {
                "page_size": 50,
                "exclude": {"ids": []},
                "aggs": {
                    "tags": {"size": 50},
                    "organizertagsautocomplete_agg": {"size": 50},
                    "dates": {}
                },
                "dates": ["current_future"]
            },
            "expand.destination_event": [
                "primary_venue",
                "image",
                "ticket_availability",
                "saves",
                "event_sales_status",
                "primary_organizer",
                "public_collections"
            ],
            "expand.destination_profile": ["image"]
        }

        try:
            search_response = requests.post(search_url, headers=search_headers, json=search_payload, timeout=10)
            if search_response.status_code == 200:
                try:
                    search_data = search_response.json()
                    search_events = search_data.get("events", [])
                    for event in search_events:
                        event_id = event.get("id") or event.get("eventbrite_event_id")
                        if event_id:
                            event_ids.append(str(event_id))
                except ValueError:
                    pass
        except Exception:
            pass
        
        # Fallback: Try browser endpoint with city slug
        if not event_ids:
            city = get_city_from_coordinates(lat, lng, google_api_key) if google_api_key else None
            if city:
                city_slug = city_to_eventbrite_slug(city)
                logger.info(f"Eventbrite: Trying fallback browser endpoint with city slug '{city_slug}'")
                
                browser_headers = {
                    "accept": "application/json, text/plain, */*",
                    "accept-language": "en-US,en;q=0.9",
                    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
                    "referer": "https://www.eventbrite.com/"
                }
                
                try:
                    browser_url = f"https://www.eventbrite.com/b/{city_slug}/"
                    browser_response = requests.get(browser_url, headers=browser_headers, timeout=10)
                    
                    if browser_response.status_code == 200:
                        try:
                            browser_data = browser_response.json()
                            events_data = browser_data.get("events", {})
                            event_results = events_data.get("results", [])
                            
                            for event in event_results:
                                event_id = event.get("id") or event.get("eventbrite_event_id")
                                if event_id:
                                    event_ids.append(str(event_id))
                            
                            if event_ids:
                                logger.info(f"Eventbrite browser: Found {len(event_ids)} event IDs")
                        except ValueError:
                            logger.debug("Eventbrite browser: Response is HTML, not JSON")
                except Exception as e:
                    logger.debug(f"Eventbrite browser endpoint error: {e}")
        
        # Fallback event IDs for major cities
        if not event_ids:
            logger.warning("Eventbrite: No event IDs from API, using fallback event IDs for major cities")
            fallback_event_ids = {
                "barcelona": ["1964249013676", "1977511301536", "1976713929575", "1976779361283", "1793671532839"],
                "new york": ["1480216721059", "1061476738499", "1709355240539", "1686990055669", "1965703092866"],
                "london": ["1080177422749", "1857025095049", "1955287921809", "1977279506230", "1690739440179"],
                "tokyo": ["1975883623106", "1975384474138", "1305677449399", "921381134777", "1857040360709"],
                "paris": ["1801896042569", "1970307480714", "1834433693559", "1976433233004", "1639377033839"],
                "madrid": ["1848431872489", "1972567570704", "1973057150049", "1973092803690", "1974247294804"],
                "berlin": ["1974265297651", "1974283765890", "1974983969217", "1976561497647", "1974855209092"],
                "amsterdam": ["1977802281866", "1977102352358", "1668212872609", "1976725434988", "1977718978704"],
                "dubai": ["1848222385909", "1848431872489", "1972567570704", "1973057150049", "1973092803690"],
                "singapore": ["1974247294804", "1974265297651", "1974283765890", "1974983969217", "1976561497647"],
                "sydney": ["1974855209092", "1977802281866", "1977102352358", "1668212872609", "1976725434988"],
            }

            city = get_city_from_coordinates(lat, lng, google_api_key) if google_api_key else None
            if city:
                city_key = city.lower()
                for fallback_city, ids in fallback_event_ids.items():
                    if fallback_city in city_key or city_key in fallback_city:
                        event_ids = ids
                        break

            if not event_ids:
                event_ids = fallback_event_ids["barcelona"]

        if not event_ids:
            logger.warning("Eventbrite: No event IDs found, using mock data")
            return get_mock_eventbrite_events()
        
        # Step 2: Get detailed event data
        all_events = []
        if event_ids:
            event_ids_str = ",".join(event_ids[:20])
            events_url = f"https://www.eventbrite.com/api/v3/destination/events/"
            events_params = {
                "event_ids": event_ids_str,
                "page_size": 20,
                "expand": "event_sales_status,image,primary_venue,saves,ticket_availability,primary_organizer,public_collections"
            }

            events_headers = {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "referer": "https://www.eventbrite.com/"
            }

            try:
                events_response = requests.get(events_url, params=events_params, headers=events_headers, timeout=10)
                if events_response.status_code == 200:
                    try:
                        events_data = events_response.json()
                        event_results = events_data.get("events", [])
                        if event_results:
                            all_events.extend(event_results)
                    except ValueError:
                        pass
            except Exception:
                pass
        
        if not all_events:
            logger.warning("Eventbrite: No events returned from events API, using mock data")
            return get_mock_eventbrite_events()
            
        # Parse events and filter by distance
        parsed_events = []
        for event in all_events:
            try:
                primary_venue = event.get("primary_venue", {})
                venue_address = primary_venue.get("address", {})
                venue_lat = venue_address.get("latitude")
                venue_lng = venue_address.get("longitude")

                # Filter by distance
                if venue_lat and venue_lng:
                    try:
                        venue_lat_float = float(venue_lat)
                        venue_lng_float = float(venue_lng)
                        distance = haversine_distance(lat, lng, venue_lat_float, venue_lng_float)

                        if distance > radius_km:
                            continue
                    except (ValueError, TypeError):
                        pass

                # Filter by date
                if start_time or end_time:
                    event_start_date = event.get("start_date")
                    if event_start_date:
                        try:
                            event_date = datetime.strptime(event_start_date, "%Y-%m-%d")
                            event_date_only = event_date.date()
                            if start_time and event_date_only < start_time.date():
                                continue
                            if end_time and event_date_only > end_time.date():
                                continue
                        except (ValueError, TypeError):
                            pass
                    else:
                        if start_time or end_time:
                            continue

                # Format start time
                start_time_str = ""
                event_start_date = event.get("start_date", "")
                event_start_time = event.get("start_time", "")
                if event_start_date:
                    try:
                        date_obj = datetime.strptime(event_start_date, "%Y-%m-%d")
                        if event_start_time:
                            start_time_str = f"{date_obj.strftime('%B %d, %Y')}, {event_start_time}"
                        else:
                            start_time_str = date_obj.strftime("%B %d, %Y")
                    except (ValueError, TypeError):
                        start_time_str = f"{event_start_date} {event_start_time}".strip()
                elif event_start_time:
                    start_time_str = event_start_time

                # Format end time
                end_time_str = ""
                event_end_date = event.get("end_date", "")
                event_end_time = event.get("end_time", "")
                if event_end_date:
                    try:
                        end_date_obj = datetime.strptime(event_end_date, "%Y-%m-%d")
                        if event_end_time:
                            end_time_str = f"{end_date_obj.strftime('%B %d, %Y')}, {event_end_time}"
                        else:
                            end_time_str = end_date_obj.strftime("%B %d, %Y")
                    except (ValueError, TypeError):
                        end_time_str = f"{event_end_date} {event_end_time}".strip()
                elif event_end_time:
                    end_time_str = event_end_time

                # Extract event details
                parsed_events.append({
                    "id": str(event.get("id", "")),
                    "name": event.get("name", ""),
                    "description": event.get("summary", "")[:200] if event.get("summary") else "",
                    "start_time": start_time_str,
                    "end_time": end_time_str,
                    "url": event.get("url", ""),
                    "venue_name": primary_venue.get("name", ""),
                    "venue_address": venue_address.get("localized_address_display", ""),
                    "venue_latitude": float(venue_lat) if venue_lat else None,
                    "venue_longitude": float(venue_lng) if venue_lng else None,
                    "source": "eventbrite"
                })
            except Exception as e:
                logger.debug(f"Eventbrite: Error parsing event: {e}")
                continue
        
        # Remove duplicates
        seen_ids = set()
        unique_events = []
        for event in parsed_events:
            if event["id"] not in seen_ids:
                seen_ids.add(event["id"])
                unique_events.append(event)
        
        unique_events.sort(key=lambda x: x.get("start_time", ""))
        
        logger.info(f"Eventbrite: Found {len(unique_events)} unique events after filtering")
        return unique_events[:50]
        
    except Exception as e:
        logger.error(f"Eventbrite API exception: {e}")
        logger.error(traceback.format_exc())
    
    return get_mock_eventbrite_events()


def get_ticketmaster_events(
    lat: float, 
    lng: float, 
    ticketmaster_api_key: Optional[str] = None,
    start_time: Optional[datetime] = None, 
    end_time: Optional[datetime] = None, 
    radius_km: int = 50, 
    locale: str = "en"
) -> List[Dict[str, Any]]:
    """Get events from Ticketmaster Discovery API v2
    
    Reference: https://developer.ticketmaster.com/products-and-docs/apis/discovery-api/v2/
    
    Args:
        lat: Latitude
        lng: Longitude
        ticketmaster_api_key: Ticketmaster API key (optional, will return mock data if not provided)
        start_time: Start time filter (optional)
        end_time: End time filter (optional)
        radius_km: Search radius in kilometers
        locale: Locale string (e.g., "en-us", "es-es")
    
    Returns:
        List of events with id, name, description, start_time, url, venue_name, etc.
    """
    try:
        if not ticketmaster_api_key:
            logger.warning("Ticketmaster API key not found, using mock data")
            return get_mock_ticketmaster_events()
        
        url = "https://app.ticketmaster.com/discovery/v2/events.json"
        
        params = {
            "apikey": ticketmaster_api_key,
            "size": 20,
            "sort": "date,asc",
            "locale": locale
        }
        
        params["geoPoint"] = f"{lat},{lng}"
        radius_miles = radius_km * 0.621371
        params["radius"] = int(radius_miles)
        params["unit"] = "miles"
        
        # Determine country code based on coordinates
        country_code_map = {
            (36, 44, -10, 4): "ES",
            (24, 50, -125, -66): "US",
            (50, 60, -8, 2): "GB",
            (42, 51, -5, 10): "FR",
            (47, 55, 5, 15): "DE",
            (36, 47, 6, 19): "IT",
            (24, 46, 123, 146): "JP",
            (-44, -10, 113, 154): "AU",
            (41, 83, -141, -52): "CA",
        }
        
        country_code = None
        for (min_lat, max_lat, min_lng, max_lng), code in country_code_map.items():
            if min_lat <= lat <= max_lat and min_lng <= lng <= max_lng:
                country_code = code
                break
        
        if country_code:
            params["countryCode"] = country_code
        
        # Add date filters
        if start_time:
            params["startDateTime"] = start_time.strftime("%Y-%m-%dT%H:%M:%SZ")
        if end_time:
            effective_end_time = end_time
            if start_time and effective_end_time <= start_time:
                effective_end_time = start_time + timedelta(days=1)
            params["endDateTime"] = effective_end_time.strftime("%Y-%m-%dT%H:%M:%SZ")
        if start_time and not end_time:
            params["endDateTime"] = (start_time + timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%SZ")
        
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            events = []
            embedded = data.get("_embedded", {})
            event_list = embedded.get("events", []) if embedded else []
            
            page_info = data.get("page", {})
            total_elements = page_info.get("totalElements", 0)
            
            if not event_list:
                logger.warning(f"Ticketmaster: No events found. Total results: {total_elements}")
                if total_elements == 0:
                    logger.info("Ticketmaster: No events match the search criteria in this area")
                return []
            
            for event in event_list[:20]:
                venues = event.get("_embedded", {}).get("venues", [])
                venue = venues[0] if venues else {}
                venue_location = venue.get("location", {})
                
                images = event.get("images", [])
                image_url = images[0].get("url", "") if images else ""
                
                start_dates = event.get("dates", {}).get("start", {})
                local_date = start_dates.get("localDate", "")
                local_time = start_dates.get("localTime", "")
                start_time_formatted = ""
                
                if local_date:
                    try:
                        if local_time:
                            datetime_str = f"{local_date}T{local_time}"
                            dt_obj = datetime.fromisoformat(datetime_str)
                            start_time_formatted = dt_obj.strftime("%B %d, %Y, %H:%M")
                        else:
                            date_obj = datetime.strptime(local_date, "%Y-%m-%d")
                            start_time_formatted = date_obj.strftime("%B %d, %Y")
                    except Exception as e:
                        logger.debug(f"Error parsing Ticketmaster date: {e}")
                        start_time_formatted = f"{local_date} {local_time}".strip()
                
                if not start_time_formatted:
                    start_time_formatted = f"{local_date} {local_time}".strip() if local_date or local_time else "TBA"
                
                events.append({
                    "id": event.get("id", ""),
                    "name": event.get("name", ""),
                    "description": event.get("description", "")[:200] if event.get("description") else "",
                    "start_time": start_time_formatted,
                    "url": event.get("url", ""),
                    "venue_name": venue.get("name", ""),
                    "venue_address": venue.get("address", {}).get("line1", ""),
                    "venue_city": venue.get("city", {}).get("name", ""),
                    "venue_latitude": venue_location.get("latitude"),
                    "venue_longitude": venue_location.get("longitude"),
                    "image_url": image_url,
                    "source": "ticketmaster"
                })
            logger.info(f"Ticketmaster: Found {len(events)} events")
            return events
        else:
            logger.error(f"Ticketmaster API error: Status {response.status_code}, Response: {response.text[:200]}")
            return get_mock_ticketmaster_events()
    except Exception as e:
        logger.error(f"Ticketmaster API exception: {e}")
        logger.error(traceback.format_exc())
    
    return get_mock_ticketmaster_events()

