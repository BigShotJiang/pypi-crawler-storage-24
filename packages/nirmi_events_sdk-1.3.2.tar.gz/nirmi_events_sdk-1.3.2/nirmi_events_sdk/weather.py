"""
Weather API integration for Nirmi Events SDK
"""

import logging
from typing import Dict, Any, Optional
import requests

logger = logging.getLogger(__name__)


def get_weather_data(
    lat: float, 
    lng: float, 
    weather_api_key: Optional[str] = None
) -> Dict[str, Any]:
    """Get current weather data for the location using coordinates
    
    Args:
        lat: Latitude
        lng: Longitude
        weather_api_key: OpenWeather API key (optional, will return mock data if not provided)
    
    Returns:
        Dictionary with weather data: description, temperature, humidity, wind_speed
    """
    try:
        if not weather_api_key:
            logger.warning("Weather API key not found, using mock data")
            return {"description": "sunny", "temperature": 22, "humidity": 60, "wind_speed": 5}
        
        url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lng}&appid={weather_api_key}&units=metric"
        response = requests.get(url, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            return {
                "description": data.get("weather", [{}])[0].get("description", "clear"),
                "temperature": round(data.get("main", {}).get("temp", 22)),
                "humidity": data.get("main", {}).get("humidity", 60),
                "wind_speed": data.get("wind", {}).get("speed", 5)
            }
    except Exception as e:
        logger.error(f"Weather API error: {e}")
    
    return {"description": "sunny", "temperature": 22, "humidity": 60, "wind_speed": 5}

