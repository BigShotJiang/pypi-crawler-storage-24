"""
Data models for the Nirmi Events SDK
"""

from typing import Optional, List
from pydantic import BaseModel


class LocationData(BaseModel):
    """Location data model"""
    latitude: float
    longitude: float
    city: Optional[str] = None
    hotel_name: Optional[str] = None


class GuestContext(BaseModel):
    """Guest metadata from PMS / WiPass — all fields optional, filled as available."""
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    nationality: Optional[str] = None
    language: Optional[str] = None
    check_in: Optional[str] = None
    check_out: Optional[str] = None
    room_type: Optional[str] = None
    loyalty_tier: Optional[str] = None
    trip_type: Optional[str] = None
    guests_count: Optional[int] = None
    has_children: Optional[bool] = None
    special_occasions: Optional[str] = None
    dietary: Optional[str] = None
    notes: Optional[str] = None


class HotelVenue(BaseModel):
    """A venue inside the hotel (restaurant, bar, spa, etc.)."""
    name: str
    type: str
    cuisine: Optional[str] = None
    price_tier: Optional[str] = None
    hours: Optional[str] = None
    description: Optional[str] = None
    booking_info: Optional[str] = None


class HotelConfig(BaseModel):
    """Hotel configuration — passed once at Client init."""
    hotel_name: str
    brand: str
    venues: List[HotelVenue] = []
    competitor_brands: List[str] = []
    concierge_personality: Optional[str] = None
