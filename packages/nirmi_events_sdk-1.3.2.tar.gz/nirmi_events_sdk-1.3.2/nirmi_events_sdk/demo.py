"""
nirmi AI Concierge — Interactive Demo
======================================
Built-in CLI wizard. No Python coding required.

    pip install nirmi-events-sdk
    nirmi-demo
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional
import requests
from nirmi_events_sdk import Client, HotelConfig, HotelVenue, GuestContext

NIRMI_API_URL = "https://www.nirmi.ai"
ACTIVATION_FILE = Path.home() / ".nirmi" / "activation"


# ── Default hotel config (Grand Hyatt Barcelona) ──

DEFAULT_VENUES = [
    HotelVenue(
        name="Maymanta",
        type="restaurant",
        cuisine="Peruvian",
        price_tier="€€€€",
        hours="13:00–16:00, 20:00–23:30",
        description="Michelin Guide 2025 restaurant. Bold Peruvian cuisine with skyline views from the rooftop.",
        booking_info="Reservations required — ask concierge or dial ext. 410"
    ),
    HotelVenue(
        name="Leña by Dani García",
        type="restaurant",
        cuisine="Contemporary wood-fired",
        price_tier="€€€€",
        hours="13:00–16:00, 20:00–23:30",
        description="Celebrity chef Dani García's wood-fired concept. Bold flavours, fire-cooked meats and fish.",
        booking_info="Reservations required — ask concierge or dial ext. 420"
    ),
    HotelVenue(
        name="Sofía Bar & Tapas",
        type="bar",
        hours="11:00–01:00",
        description="Vibrant tapas bar in the hotel lobby. Catalan bites, cocktails, and live ambient music.",
        booking_info="Walk-in welcome"
    ),
    HotelVenue(
        name="Philosofia Café",
        type="cafe",
        hours="7:00–11:00",
        description="All-day café with specialty coffee, pastries, and light bites.",
        booking_info="Walk-in welcome"
    ),
    HotelVenue(
        name="Grand Hyatt Spa",
        type="spa",
        hours="8:00–21:00",
        description="Full-service luxury spa: massages, facials, hammam, and indoor pool.",
        booking_info="Book 24h in advance — ext. 500"
    ),
]

DEFAULT_COMPETITORS = [
    "Marriott", "Sheraton", "Hilton", "Waldorf", "W Hotel",
    "Four Seasons", "Mandarin", "Ritz-Carlton", "InterContinental",
    "Novotel", "Sofitel", "Melia", "NH Hotel", "Ibis", "Accor"
]


def _load_activation() -> Optional[str]:
    """Load saved activation code from ~/.nirmi/activation"""
    try:
        if ACTIVATION_FILE.exists():
            return ACTIVATION_FILE.read_text().strip()
    except OSError:
        pass
    return None


def _save_activation(code: str):
    """Save activation code to ~/.nirmi/activation"""
    try:
        ACTIVATION_FILE.parent.mkdir(parents=True, exist_ok=True)
        ACTIVATION_FILE.write_text(code)
    except OSError:
        pass


def _verify_activation(code: str) -> bool:
    """Verify activation code against the nirmi backend."""
    try:
        resp = requests.post(
            f"{NIRMI_API_URL}/activate",
            json={"code": code},
            timeout=5
        )
        return resp.status_code == 200
    except requests.RequestException:
        return False


def activate():
    """Activation gate — exits if invalid."""
    saved = _load_activation()
    if saved and _verify_activation(saved):
        return

    clear()
    print()
    print("  ╔══════════════════════════════════════════════╗")
    print("  ║   nirmi — AI Concierge                       ║")
    print("  ╚══════════════════════════════════════════════╝")
    print()
    print("  Activation required")
    print("  ───────────────────")
    print()
    print("  Enter your nirmi activation code.")
    print("  Don't have one? Contact info@narmiai.com")
    print()

    for attempt in range(3):
        code = input("  Activation code: ").strip()
        if not code:
            continue
        if _verify_activation(code):
            _save_activation(code)
            print()
            print("  Activated successfully.")
            print()
            return
        else:
            remaining = 2 - attempt
            if remaining > 0:
                print(f"  Invalid code. {remaining} attempt{'s' if remaining > 1 else ''} remaining.")
            else:
                print()
                print("  Invalid activation code.")
                print("  Contact info@narmiai.com for access.")
                print()
                sys.exit(1)

    sys.exit(1)


def clear():
    print("\033[2J\033[H", end="")


def prompt(label, default=""):
    suffix = f" [{default}]" if default else ""
    val = input(f"  {label}{suffix}: ").strip()
    return val if val else default


def choose(label, options):
    print(f"  {label}")
    for i, opt in enumerate(options, 1):
        print(f"    {i}. {opt}")
    while True:
        val = input(f"  Choice [1-{len(options)}]: ").strip()
        if val.isdigit() and 1 <= int(val) <= len(options):
            return options[int(val) - 1]
        print(f"    Please enter 1-{len(options)}")


def main():
    """Entry point for the nirmi-demo CLI command."""

    parser = argparse.ArgumentParser(
        prog="nirmi-demo",
        description="nirmi AI Concierge — Interactive Demo",
        epilog=(
            "How it works:\n"
            "  1. Hotel setup    — API key, hotel name, brand, city, coordinates\n"
            "  2. Guest check-in — name, nationality, trip type, dates, dietary needs\n"
            "  3. Live chat      — ask nirmi anything, get personalised recommendations\n"
            "\n"
            "The AI adapts to guest context: nationality, trip type, dietary needs,\n"
            "checkout date (won't suggest events after you leave), and special occasions.\n"
            "\n"
            "Output includes:\n"
            "  • AI message      — personalised, context-aware response\n"
            "  • Recommendations — restaurants, bars, attractions with ratings & booking info\n"
            "  • Events          — concerts, shows, festivals with dates, venues & ticket URLs\n"
            "  • Weather         — current conditions for the city\n"
            "\n"
            "Type 'json' after any response to see the raw API output.\n"
            "\n"
            "Examples:\n"
            "  nirmi-demo                     Launch with defaults (Grand Hyatt Barcelona)\n"
            "  nirmi-demo --api-key nk_xxx    Use a specific API key\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--hotel", default="Grand Hyatt Barcelona", help="Hotel name")
    parser.add_argument("--brand", default="hyatt", help="Hotel brand")
    parser.add_argument("--city", default="Barcelona", help="City name")
    parser.add_argument("--lat", type=float, default=41.3822, help="Hotel latitude")
    parser.add_argument("--lng", type=float, default=2.1206, help="Hotel longitude")
    parser.add_argument("--version", action="version", version=f"nirmi-events-sdk {__import__('nirmi_events_sdk').__version__}")

    args = parser.parse_args()

    # ── Activation gate ──

    activate()

    # ── Hotel setup ──

    clear()
    print()
    print("  ╔══════════════════════════════════════════════╗")
    print("  ║   nirmi — AI Concierge Demo                  ║")
    print("  ╚══════════════════════════════════════════════╝")
    print()
    print("  Hotel setup")
    print("  ───────────")
    print()

    api_key = prompt("API key", "nk_hyatt_demo_2026")
    hotel_name = prompt("Hotel name", args.hotel)
    brand = prompt("Brand", args.brand)
    city = prompt("City", args.city)
    lat_str = prompt("Latitude", str(args.lat))
    lng_str = prompt("Longitude", str(args.lng))

    lat = float(lat_str)
    lng = float(lng_str)

    client = Client(
        api_key=api_key,
        hotel_config=HotelConfig(
            hotel_name=hotel_name,
            brand=brand,
            venues=DEFAULT_VENUES,
            competitor_brands=DEFAULT_COMPETITORS,
            concierge_personality=(
                f"You are nirmi, the {hotel_name} AI concierge. "
                f"You are warm, elegant, and knowledgeable about {city}. "
                f"Always recommend {hotel_name} venues first when relevant. "
                "Never suggest restaurants or bars inside competitor hotels. "
                "Keep responses concise, personal, and actionable."
            )
        )
    )

    # ── Guest check-in ──

    clear()
    print()
    print("  ╔══════════════════════════════════════════════╗")
    print(f"  ║   nirmi — {hotel_name:<36}║")
    print("  ╚══════════════════════════════════════════════╝")
    print()
    print("  Guest check-in")
    print("  ──────────────")
    print()

    first_name = prompt("First name")
    last_name = prompt("Last name", "")
    nationality = prompt("Nationality", "")

    trip_type = choose("Trip type:", ["business", "couple", "family", "solo", "group"])

    check_in = prompt("Check-in date (YYYY-MM-DD)", datetime.now().strftime("%Y-%m-%d"))
    check_out = prompt("Check-out date (YYYY-MM-DD)", "")

    dietary = prompt("Dietary needs (or press Enter to skip)", "")

    has_children = False
    guests_count = 1
    if trip_type == "family":
        has_children_input = prompt("Travelling with children? (y/n)", "y")
        has_children = has_children_input.lower() in ("y", "yes")
        guests_count_input = prompt("Party size", "4")
        guests_count = int(guests_count_input) if guests_count_input.isdigit() else 4
    elif trip_type == "couple":
        guests_count = 2
    elif trip_type == "group":
        guests_count_input = prompt("Party size", "6")
        guests_count = int(guests_count_input) if guests_count_input.isdigit() else 6

    special = ""
    if trip_type == "couple":
        special = prompt("Any special occasion? (anniversary, birthday, etc.)", "")

    notes = prompt("Anything else we should know? (or Enter to skip)", "")

    guest = GuestContext(
        first_name=first_name,
        last_name=last_name if last_name else None,
        nationality=nationality if nationality else None,
        trip_type=trip_type,
        check_in=check_in,
        check_out=check_out if check_out else None,
        dietary=dietary if dietary else None,
        has_children=has_children,
        guests_count=guests_count if guests_count > 1 else None,
        special_occasions=special if special else None,
        notes=notes if notes else None,
    )

    # ── Live chat ──

    clear()
    print()
    print(f"  Welcome, {first_name}. You're checked in.")
    print(f"  {hotel_name} — {check_in}" + (f" to {check_out}" if check_out else ""))
    print()
    print("  Ask nirmi anything. Type 'quit' to check out.")
    print("  ──────────────────────────────────────────────")
    print()

    history = []

    while True:
        try:
            msg = input(f"  {first_name}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\n  Thank you for staying with us. Goodbye!\n")
            break

        if not msg:
            continue
        if msg.lower() in ("quit", "exit", "q"):
            print("\n  Thank you for staying with us. Goodbye!\n")
            break

        try:
            result = client.chat(
                message=msg,
                latitude=lat,
                longitude=lng,
                city=city,
                guest=guest,
                conversation_history=history
            )

            # Display the AI message
            ai_message = result.get("message", "I'm sorry, I couldn't process that.")
            print()
            print(f"  nirmi: {ai_message}")
            print()

            # Show recommendations summary
            recs = result.get("recommendations", [])
            if recs:
                print("  ┌─ Recommendations ─────────────────────────")
                for r in recs:
                    source_tag = f"[{r.get('source', '')}]"
                    cuisine = f" · {r['cuisine']}" if r.get('cuisine') else ""
                    price = f" · {r.get('price_tier', '')}" if r.get('price_tier') else ""
                    rating = f" · {r['rating']}/5" if r.get('rating') else ""
                    url = f"\n  │   ↳ {r['url']}" if r.get('url') else ""
                    booking = f"\n  │   ↳ {r['booking_info']}" if r.get('booking_info') else ""
                    print(f"  │  {r['name']} {source_tag}{cuisine}{price}{rating}{url}{booking}")
                print("  └─────────────────────────────────────────────")
                print()

            # Show events
            events = result.get("events", [])
            if events:
                print("  ┌─ Events ──────────────────────────────────")
                for e in events:
                    name = e.get("n") or e.get("name", "")
                    start = e.get("st") or e.get("start_time", "")
                    venue = e.get("vn") or e.get("venue_name", "")
                    url = e.get("u") or e.get("url", "")
                    source = e.get("s") or e.get("source", "")
                    source_tag = ""
                    if source:
                        source_tag = f" [{source}]"
                    line = f"  │  {name}"
                    if start:
                        line += f" · {start}"
                    line += source_tag
                    print(line)
                    if venue:
                        print(f"  │   ↳ {venue}")
                    if url:
                        print(f"  │   ↳ {url}")
                print("  └─────────────────────────────────────────────")
                print()

            # Show weather
            weather = result.get("weather")
            if weather and isinstance(weather, dict):
                desc = weather.get("description", "")
                temp = weather.get("temp")
                if desc or temp:
                    weather_line = "  ☁ Weather: "
                    if desc:
                        weather_line += desc.capitalize()
                    if temp:
                        weather_line += f", {temp}°C"
                    print(weather_line)
                    print()

            # Update conversation history
            history.append({"user": msg, "assistant": ai_message})

            # Show raw JSON toggle
            show_json = input("  [Enter to continue, 'json' to see raw response]: ").strip()
            if show_json.lower() == "json":
                print()
                print(json.dumps(result, indent=2, ensure_ascii=False))
                print()

        except Exception as e:
            print(f"\n  Error: {e}\n")


if __name__ == "__main__":
    main()
