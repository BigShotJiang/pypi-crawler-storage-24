"""
Google Places API integration for Nirmi Events SDK
"""

import logging
from typing import List, Dict, Any, Optional
import requests

logger = logging.getLogger(__name__)


def get_mock_places(place_type: str) -> List[Dict[str, Any]]:
    """Fallback mock places for testing"""
    if place_type == "restaurant":
        return [
            {"id": "mock_rest_1", "name": "Cal Pep", "rating": 4.5, "price_level": 3, "vicinity": "Born", "latitude": 41.382, "longitude": 2.183},
            {"id": "mock_rest_2", "name": "Disfrutar", "rating": 4.8, "price_level": 4, "vicinity": "Eixample", "latitude": 41.390, "longitude": 2.162},
        ]
    else:
        return [
            {"id": "mock_attr_1", "name": "Sagrada Familia", "rating": 4.7, "vicinity": "Eixample", "latitude": 41.403, "longitude": 2.174},
            {"id": "mock_attr_2", "name": "Park Güell", "rating": 4.4, "vicinity": "Gràcia", "latitude": 41.414, "longitude": 2.152},
        ]


def get_nearby_places(
    lat: float, 
    lng: float, 
    google_api_key: Optional[str] = None,
    place_type: str = "tourist_attraction", 
    radius: int = 2000, 
    keyword: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Get nearby places from Google Places API
    
    Args:
        lat: Latitude
        lng: Longitude
        google_api_key: Google Places API key (optional, will return mock data if not provided)
        place_type: Type of place (restaurant, tourist_attraction, etc.)
        radius: Search radius in meters
        keyword: Optional keyword for more specific searches (e.g., "sushi", "italian")
    
    Returns:
        List of places with id, name, rating, price_level, types, vicinity, latitude, longitude
    """
    try:
        if not google_api_key:
            logger.warning("Google API key not found, using mock data")
            return get_mock_places(place_type)
        
        # Use Text Search API for keyword-based searches
        if keyword:
            url = "https://maps.googleapis.com/maps/api/place/textsearch/json"
            params = {
                "query": keyword,
                "location": f"{lat},{lng}",
                "radius": radius,
                "key": google_api_key
            }
            logger.info(f"Using Text Search API with query: {keyword}")
        else:
            # Use Nearby Search API for general type-based searches
            url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
            params = {
                "location": f"{lat},{lng}",
                "radius": radius,
                "type": place_type,
                "key": google_api_key
            }
        
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            places = []
            for place in data.get("results", [])[:5]:
                places.append({
                    "id": place.get("place_id", ""),
                    "name": place.get("name", ""),
                    "rating": place.get("rating", 0),
                    "price_level": place.get("price_level", 2),
                    "types": place.get("types", []),
                    "vicinity": place.get("vicinity", ""),
                    "latitude": place.get("geometry", {}).get("location", {}).get("lat"),
                    "longitude": place.get("geometry", {}).get("location", {}).get("lng")
                })
            logger.info(f"Found {len(places)} places with keyword='{keyword}', type='{place_type}'")
            return places
    except Exception as e:
        logger.error(f"Google Places API error: {e}")
    
    return get_mock_places(place_type)

