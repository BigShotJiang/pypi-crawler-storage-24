"""
Main controller for OpenClaw Secure operations.
Orchestrates detection, backup, and mode switching.
"""

import os
import platform
import signal
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, Optional

import psutil
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

from .backup import ConfigBackup
from .detector import OpenClawDetector
from .docker_backend import DockerBackend

console = Console()


class OpenClawSecureController:
    """Main controller for secure mode operations."""

    # State file to track what was running before enable
    STATE_FILE = Path.home() / ".openclaw-secure" / "state.json"

    def __init__(self):
        self.detector = OpenClawDetector()
        self.docker: Optional[DockerBackend] = None
        self._init_docker_backend()

    def _init_docker_backend(self) -> None:
        """Initialize Docker backend with proper paths."""
        config_dir = self.detector.get_config_dir()
        workspace_dir = self.detector.get_workspace_dir()
        cache_dir = self.detector.get_cache_dir()
        self.docker = DockerBackend(config_dir, workspace_dir, cache_dir)

    def _save_state(self, previous_mode: str, previous_container: str = None) -> None:
        """Save current state before enabling secure mode."""
        import json

        self.STATE_FILE.parent.mkdir(parents=True, exist_ok=True)

        state = {
            "previous_mode": previous_mode,  # "local", "docker", or "none"
            "previous_container": previous_container,  # container name if docker
            "timestamp": time.time(),
            "config_dir": str(self.detector.get_config_dir()),
        }

        self.STATE_FILE.write_text(json.dumps(state, indent=2))

    def _load_state(self) -> Dict[str, Any]:
        """Load saved state."""
        import json

        if not self.STATE_FILE.exists():
            return {}

        try:
            return json.loads(self.STATE_FILE.read_text())
        except Exception:
            return {}

    def _clear_state(self) -> None:
        """Clear saved state."""
        if self.STATE_FILE.exists():
            self.STATE_FILE.unlink()

    def enable_secure_mode(
        self,
        create_backup: bool = True,
        network_mode: str = "none",
        host_port: int = None,
        sandbox_mode: str = None,
        auto_confirm: bool = False,
        disable_device_auth: bool = False,
    ) -> bool:
        """
        Enable secure mode by stopping local OpenClaw and starting Docker container.

        Returns True on success, False on failure (with automatic rollback).
        """
        # 1. Check Docker is available
        docker_check = self.detector.check_docker_available()
        if not docker_check["available"]:
            console.print("[red]X Docker not found. Please install Docker Desktop:[/red]")
            console.print("   [cyan]https://docs.docker.com/get-docker/[/cyan]")
            return False

        if not docker_check["running"]:
            console.print("[red]X Docker daemon not running.[/red]")
            console.print(
                "   Start Docker Desktop or run: [cyan]sudo systemctl start docker[/cyan]"
            )
            return False

        # 2. Check for existing secure container
        if self.docker.is_container_running():
            console.print("[yellow]!  Secure container already running.[/yellow]")
            console.print(f"   Access at: [cyan]http://127.0.0.1:{self.docker.PORT}[/cyan]")
            return True

        # 3. Check if OpenClaw config exists
        config_dir = self.detector.get_config_dir()
        config_file = config_dir / "openclaw.json"
        
        if not config_file.exists():
            console.print(
                Panel.fit(
                    "[bold yellow]OPENCLAW NOT DETECTED[/bold yellow]\n"
                    "No existing OpenClaw configuration found.",
                    border_style="yellow",
                )
            )
            
            if auto_confirm:
                # Create fresh config with user selections
                console.print("[dim]   Creating fresh OpenClaw configuration...[/dim]")
                sandbox_for_fresh = sandbox_mode_internal if sandbox_mode_internal else "non-main"
                self._create_fresh_config(port=host_port, sandbox_mode=sandbox_for_fresh)
            else:
                from rich.prompt import Confirm, IntPrompt
                
                console.print("\n[bold]Options:[/bold]")
                console.print("   1. Create fresh OpenClaw config")
                console.print("   2. Specify existing config location")
                console.print("   3. Cancel and install OpenClaw first")
                
                choice = IntPrompt.ask(
                    "   What would you like to do?",
                    choices=["1", "2", "3"],
                    default=1,
                )
                
                if choice == 1:
                    console.print("[dim]   Creating fresh OpenClaw configuration...[/dim]")
                    # Use the selected sandbox mode and port for fresh config
                    sandbox_for_fresh = sandbox_mode_internal if sandbox_mode_internal else "non-main"
                    self._create_fresh_config(port=host_port, sandbox_mode=sandbox_for_fresh)
                    console.print("[green]   + Fresh config created[/green]")
                elif choice == 2:
                    from rich.prompt import Prompt
                    new_path = Prompt.ask("   Enter config directory path")
                    if new_path and Path(new_path).exists():
                        import os
                        os.environ["OPENCLAW_CONFIG_PATH"] = new_path
                        self._init_docker_backend()
                    else:
                        console.print("[red]X Path not found. Please install OpenClaw first.[/red]")
                        console.print("   [cyan]https://openclaw.ai/install[/cyan]")
                        return False
                else:
                    console.print("[yellow]Please install OpenClaw first:[/yellow]")
                    console.print("   [cyan]https://openclaw.ai/install[/cyan]")
                    console.print("\nThen run: [cyan]openclaw-secure enable[/cyan]")
                    return False

        # 4. Find and display current state
        current = self.detector.find_running_gateway()

        console.print(
            Panel.fit(
                "[bold blue]OPENCLAW SECURITY MODE ACTIVATION[/bold blue]\n"
                "Moving your OpenClaw into a secure, sandboxed container",
                border_style="blue",
            )
        )

        if current:
            if current["type"] == "local":
                console.print(
                    f"[yellow]!  Local OpenClaw detected (PID: {current['pid']})[/yellow]"
                )
                console.print(
                    "   This process will be [bold]STOPPED[/bold] to start the secure container."
                )
            elif current["type"] == "docker":
                console.print(
                    f"[yellow]!  Docker OpenClaw detected ({current['container_name']})[/yellow]"
                )
                console.print("   This container will be replaced with the secure container.")
        else:
            console.print("[dim]i  No running OpenClaw gateway detected.[/dim]")

        console.print("\n[bold]LIST What will happen:[/bold]")
        console.print("   1. Stop current OpenClaw gateway (if running)")
        console.print("   2. Start OpenClaw in Docker container")
        console.print(
            "   3. Mount your config: [cyan]~/.config/openclaw[/cyan] ([bold green]read-write[/bold green])"
        )
        console.print("   4. Mount your workspace: [cyan]~/.openclaw/workspace[/cyan]")
        console.print("   5. All agent execution will be sandboxed")

        console.print("\n[bold]OK What is preserved:[/bold]")
        console.print("   ? API keys and credentials")
        console.print("   ? Custom settings and extensions")
        console.print("   ? Conversation history")
        console.print("   ? Everything remains [bold green]EDITABLE[/bold green]")

        console.print("\n[bold]PWR Security changes:[/bold]")
        console.print("   ? Agent tools run in isolated containers")
        console.print("   ? Filesystem restricted to workspace")
        if network_mode == "none":
            console.print(f"   ? Network: [cyan]{network_mode}[/cyan] (no external access)")
        else:
            console.print(f"   ? Network: [cyan]{network_mode}[/cyan] (isolated, ports exposed)")

        # 4. Port selection
        console.print("\n[bold]WEB Port Configuration:[/bold]")

        # Check if current port is in use
        current_port = host_port if host_port else self.docker.PORT
        port_in_use = self._is_port_in_use(current_port)
        suggested_port = current_port + 1 if port_in_use else current_port

        if auto_confirm:
            # Non-interactive mode: use defaults or provided values
            if port_in_use and host_port is None:
                # Auto-stop container using default port and use default
                self._stop_container_using_port(current_port)
                host_port = current_port
            else:
                host_port = host_port if host_port else suggested_port
                if self._is_port_in_use(host_port):
                    self._stop_container_using_port(host_port)
            console.print(f"   Using port: {host_port}")
        else:
            if port_in_use:
                # Check if it's a container and offer to stop it
                conflicting = self._find_container_using_port(current_port)
                if conflicting:
                    console.print(f"   Port {current_port} is used by container '{conflicting}'.")
                    if Confirm.ask(f"   Stop '{conflicting}' and use port {current_port}?", default=True):
                        self._stop_container_using_port(current_port)
                        host_port = current_port
                    else:
                        console.print(f"   Suggested alternative: {suggested_port}")
                        from rich.prompt import IntPrompt
                        port_choice = IntPrompt.ask(
                            "   Which port to use for the secure container?",
                            default=suggested_port,
                        )
                        host_port = port_choice
                else:
                    console.print(f"   Port {current_port} is currently in use by another process.")
                    console.print(f"   Suggested alternative: {suggested_port}")
                    from rich.prompt import IntPrompt
                    port_choice = IntPrompt.ask(
                        "   Which port to use for the secure container?",
                        default=suggested_port,
                    )
                    host_port = port_choice
            else:
                console.print(f"   Default port: {current_port}")
                from rich.prompt import IntPrompt
                port_choice = IntPrompt.ask(
                    "   Which port to use for the secure container?",
                    default=current_port,
                )
                host_port = port_choice

            # Validate port
            if host_port < 1024 or host_port > 65535:
                console.print("[red]X Invalid port. Must be between 1024 and 65535.[/red]")
                return False

            # Final check - if port still in use, ask to proceed
            if self._is_port_in_use(host_port):
                console.print(f"[yellow]!  Port {host_port} is still in use.[/yellow]")
                if not Confirm.ask("   Continue anyway?", default=False):
                    return False
        
        console.print(f"[green]   + Will use port: {host_port}[/green]")

        # 5. Sandbox Mode Selection
        sandbox_mode_internal = sandbox_mode  # Use provided value or None
        
        # Define CLI to internal mapping
        sandbox_modes_cli = {
            "chat-only": "non-main",
            "maximum": "all",
            "none": "off",
        }
        
        if sandbox_mode_internal is None and auto_confirm:
            # Non-interactive default: chat-only mode (use internal value)
            sandbox_mode_internal = "non-main"
            console.print(f"[green]   + Sandbox mode: chat-only (default)[/green]")
        elif sandbox_mode_internal is None:
            # Interactive mode - prompt user
            console.print("\n[bold]SEC Sandbox Mode:[/bold]")
            console.print("   Protects your computer from AI-generated code.")
            console.print("")
            console.print("   [cyan]1. Chat Only[/cyan] (Recommended)")
            console.print("      ? Main conversation: Fast, on your computer")
            console.print("      ? AI tasks/agents: Isolated in containers")
            console.print("      ? Best balance of speed and safety")
            console.print("")
            console.print("   [cyan]2. Maximum Security[/cyan]")
            console.print("      ? EVERYTHING in isolated containers")
            console.print("      ? Slower but maximum protection")
            console.print("      ? Good for untrusted code")
            console.print("")
            console.print("   [cyan]3. No Sandbox[/cyan]")
            console.print("      ? Everything runs directly on your computer")
            console.print("      ? Fastest but least secure")

            from rich.prompt import IntPrompt

            sandbox_choice = IntPrompt.ask(
                "   Select sandbox mode",
                choices=["1", "2", "3"],
                default=1,
            )

            sandbox_modes_map = {
                1: "non-main",  # Chat on host, agents in sandbox
                2: "all",  # Everything in sandbox
                3: "off",  # No sandbox
            }
            sandbox_mode_internal = sandbox_modes_map.get(sandbox_choice, "non-main")
        else:
            # Non-interactive mode - convert CLI value to internal value
            sandbox_modes_cli = {
                "chat-only": "non-main",
                "maximum": "all",
                "none": "off",
            }
            sandbox_mode_internal = sandbox_modes_cli.get(sandbox_mode_internal.lower(), "non-main")
            console.print(f"[green]   + Sandbox mode: {sandbox_mode}[/green]")

        if sandbox_mode_internal == "non-main":
            console.print("[green]   + Chat Only mode selected[/green]")
        elif sandbox_mode_internal == "all":
            console.print("[green]   + Maximum Security mode selected[/green]")
        else:
            console.print("[yellow]   !  Sandbox disabled[/yellow]")

        console.print("\n[bold]<-> How to return to normal mode:[/bold]")
        console.print("   Run: [cyan]openclaw-secure disable[/cyan]")

        console.print("\n[bold]SOS If something goes wrong:[/bold]")
        console.print("   Run: [cyan]openclaw-secure emergency-restore[/cyan]")
        console.print(
            "   Or manually: [cyan]docker stop openclaw-secure && openclaw gateway[/cyan]"
        )

        # 4. Create backup if requested
        if create_backup:
            if auto_confirm:
                # Non-interactive: create backup without asking
                backup = ConfigBackup(self.detector.get_config_dir())
                backup_path = backup.create_backup()
                if backup_path:
                    size_kb = backup_path.stat().st_size / 1024
                    console.print(
                        f"[green]+ Backup created: {backup_path.name} ({size_kb:.1f} KB)[/green]"
                    )
            else:
                console.print("")
                if Confirm.ask("Create safety backup of config files?", default=True):
                    backup = ConfigBackup(self.detector.get_config_dir())
                    backup_path = backup.create_backup()
                    if backup_path:
                        size_kb = backup_path.stat().st_size / 1024
                        console.print(
                            f"[green]+ Backup created: {backup_path.name} ({size_kb:.1f} KB)[/green]"
                        )
                    else:
                        console.print("[yellow]!  No config files found to backup[/yellow]")

        # 5. Confirm
        if not auto_confirm:
            console.print("")
            if not Confirm.ask("Proceed with enabling secure mode?", default=False):
                console.print("[yellow]X Cancelled. No changes made.[/yellow]")
                return False

        # 6. Save state and stop existing OpenClaw
        try:
            if current:
                # Save what we're about to stop so we can restore it later
                previous_container = (
                    current.get("container_name") if current["type"] == "docker" else None
                )
                self._save_state(
                    previous_mode=current["type"], previous_container=previous_container
                )

                if current["type"] == "local":
                    console.print("\n[yellow]? Stopping local gateway...[/yellow]")
                    self._stop_local_gateway(current["pid"])
                elif current["type"] == "docker":
                    container_name = current.get("container_name", "openclaw-docker")
                    console.print(f"\n[yellow]? Stopping container '{container_name}'...[/yellow]")
                    self._stop_docker_container(container_name)

                # Also stop our secure container if it exists (in case of conflict)
                if self.docker.is_container_running():
                    console.print("[yellow]? Stopping secure container...[/yellow]")
                    self.docker.stop_container()

                # Wait for port release (for the selected port)
                if not self._wait_for_port_release(host_port, timeout=30):
                    console.print(
                        f"[red]X Port {host_port} still in use. Cannot start secure container.[/red]"
                    )
                    console.print(
                        "[yellow]   You may need to stop other services manually.[/yellow]"
                    )
                    return False

                console.print("[green]+ Stopped successfully[/green]")

            # 7. Configure sandbox and gateway in openclaw.json
            if sandbox_mode_internal != "off":
                console.print("\n[blue]CFG Configuring sandbox settings...[/blue]")
                self._configure_sandbox(sandbox_mode_internal, host_port, disable_device_auth)
                console.print("[green]+ Sandbox configured[/green]")
            elif disable_device_auth:
                # Even if sandbox is off, we may need to configure device auth
                console.print("\n[blue]CFG Configuring gateway settings...[/blue]")
                self._configure_sandbox("off", host_port, disable_device_auth)
                console.print("[green]+ Gateway configured[/green]")

            # 8. Start secure container
            console.print("\n[blue]DOCKER Starting secure container...[/blue]")

            # Check if we should use docker-compose or docker run
            if self.docker.has_compose_file():
                console.print("[dim]   Using docker-compose...[/dim]")
                success = self.docker.start_with_compose(network_mode=network_mode)
                if not success:
                    raise RuntimeError("docker-compose failed to start container")
            else:
                console.print("[dim]   Using docker run...[/dim]")
                try:
                    success = self.docker.start_container(
                        network_mode=network_mode,
                        host_port=host_port,
                    )
                except RuntimeError as e:
                    # Re-raise with full error details
                    raise RuntimeError(f"Docker run failed: {e}")

            if not success:
                # Get logs for debugging
                console.print("[yellow]   Container started but health check failed.[/yellow]")
                logs = self.docker.get_container_logs(tail=20)
                if logs:
                    console.print("[dim]   Container logs:[/dim]")
                    for line in logs.split("\n")[:10]:
                        console.print(f"     {line}")
                raise RuntimeError("Container health check failed")

            # Verify mounts are working
            mounts = self.docker.verify_mounts()
            if not all(mounts.values()):
                console.print("[yellow]!  Some mounts may have issues:[/yellow]")
                for name, ok in mounts.items():
                    status = "[green]OK[/green]" if ok else "[red]FAILED[/red]"
                    console.print(f"   {name}: {status}")

            # Wait for the gateway to fully initialize
            console.print("\n[dim]   Waiting for gateway to be ready...[/dim]")
            time.sleep(5)
            
            # Get the actual dashboard URL with token from container
            console.print("\n[blue]WEB Getting dashboard URL...[/blue]")
            dashboard_url = self._get_dashboard_url(host_port)
            
            # Auto-approve pending devices in background (don't block)
            console.print("\n[blue]DEV Checking for pending devices...[/blue]")
            import threading
            approval_thread = threading.Thread(
                target=self._auto_approve_devices,
                daemon=True
            )
            approval_thread.start()
            
            console.print(
                Panel.fit(
                    f"[bold green]OK SUCCESS: Secure mode enabled[/bold green]\n\n"
                    f"[bold]Click to open:[/bold] [link={dashboard_url}][cyan]{dashboard_url}[/cyan][/link]\n\n"
                    f"Container: [cyan]openclaw-secure[/cyan]\n"
                    f"[dim]Config: {self.detector.get_config_dir()} (read-write)[/dim]\n\n"
                    f"To disable: [cyan]openclaw-secure disable[/cyan]",
                    border_style="green",
                )
            )

            # Auto-open browser
            console.print("[dim]Opening browser...[/dim]")
            self._open_browser(dashboard_url)

            return True

        except Exception as e:
            console.print(f"\n[red]X ERROR: {e}[/red]")
            console.print("\n[yellow]<-> Attempting automatic rollback...[/yellow]")
            self.emergency_restore()
            return False

    def disable_secure_mode(self) -> bool:
        """Disable secure mode and restore previous setup."""
        console.print(
            Panel.fit("[bold blue]OPEN RETURNING TO NORMAL MODE[/bold blue]", border_style="blue")
        )

        # Load saved state to know what to restore
        state = self._load_state()
        previous_mode = state.get("previous_mode", "local")
        previous_container = state.get("previous_container")

        # Check if container is running
        if not self.docker.is_container_running():
            console.print("[yellow]!  No secure container running.[/yellow]")

            # Check if something is already running
            current = self.detector.find_running_gateway()
            if current:
                console.print(
                    f"[green]+ {current['type'].title()} gateway already running.[/green]"
                )
                return True
            else:
                # Nothing running, start based on saved state
                if previous_mode == "docker" and previous_container:
                    console.print(
                        f"[blue]<-> Starting previous container '{previous_container}'...[/blue]"
                    )
                    return self._restart_previous_container(previous_container)
                else:
                    console.print("[blue]<-> Starting local gateway...[/blue]")
                    return self._start_local_gateway()

        console.print("\n[bold]LIST What will happen:[/bold]")
        console.print("   1. Stop secure container 'openclaw-secure'")

        if previous_mode == "docker" and previous_container:
            console.print(f"   2. Restart previous container '{previous_container}'")
        else:
            console.print("   2. Start local OpenClaw gateway")

        console.print("   3. All your settings and edits are preserved")

        console.print("\n[bold]<-> How to go back to secure mode:[/bold]")
        console.print("   Run: [cyan]openclaw-secure enable[/cyan]")

        if not Confirm.ask("\nProceed with disabling secure mode?", default=True):
            console.print("[yellow]X Cancelled. Secure mode still active.[/yellow]")
            return False

        try:
            # Stop secure container
            console.print("\n[yellow]? Stopping secure container...[/yellow]")
            if self.docker.stop_container():
                console.print("[green]+ Container stopped[/green]")
            else:
                console.print("[yellow]!  Container may not have stopped cleanly[/yellow]")

            # Restore based on saved state
            if previous_mode == "docker" and previous_container:
                console.print(f"\n[blue]<-> Restarting '{previous_container}'...[/blue]")
                success = self._restart_previous_container(previous_container)
            else:
                console.print("\n[blue]<-> Starting local gateway...[/blue]")
                success = self._start_local_gateway()

            if success:
                self._clear_state()  # Clear state after successful restore
                console.print(
                    Panel.fit(
                        "[bold green]OK SUCCESS: Previous mode restored[/bold green]\n\n"
                        f"OpenClaw is running in {previous_mode} mode again.\n"
                        "All your config edits are preserved.",
                        border_style="green",
                    )
                )
                return True
            else:
                # If local gateway fails to start but we successfully stopped the container,
                # that's still a partial success - the user can start it manually
                console.print("[yellow]!  Could not automatically start previous mode[/yellow]")
                console.print("\n[yellow]The secure container was stopped. To start OpenClaw manually:[/yellow]")
                if previous_mode == "docker" and previous_container:
                    console.print(f"   [cyan]docker start {previous_container}[/cyan]")
                else:
                    console.print("   [cyan]openclaw gateway[/cyan]")
                console.print("\n[dim]Or re-enable secure mode:[/dim]")
                console.print("   [cyan]openclaw-secure enable[/cyan]")
                return True  # Return True since container was stopped (main goal achieved)

        except Exception as e:
            console.print(f"\n[red]X ERROR: {e}[/red]")
            console.print("\n[yellow]SOS Manual recovery:[/yellow]")
            console.print("   [cyan]docker stop openclaw-secure[/cyan]")
            console.print("   [cyan]openclaw gateway[/cyan]")
            return False

    def emergency_restore(self) -> bool:
        """Emergency recovery - force stop everything and restore local mode."""
        console.print(
            Panel.fit(
                "[bold red]SOS EMERGENCY RESTORE[/bold red]\n"
                "Force stopping all OpenClaw processes and restoring local mode",
                border_style="red",
            )
        )

        # 1. Force kill container
        console.print("\n[yellow]Force stopping container...[/yellow]")
        try:
            subprocess.run(
                ["docker", "kill", self.docker.CONTAINER_NAME],
                capture_output=True,
                timeout=5,
            )
            subprocess.run(
                ["docker", "rm", "-f", self.docker.CONTAINER_NAME],
                capture_output=True,
                timeout=5,
            )
            console.print("[green]+ Container force-stopped[/green]")
        except Exception:
            pass

        # 2. Kill local process if any
        console.print("[yellow]Checking for local processes...[/yellow]")
        current = self.detector.find_running_gateway()
        if current and current.get("type") == "local":
            try:
                os.kill(current["pid"], signal.SIGKILL)
                console.print("[green]+ Local process killed[/green]")
            except Exception:
                pass

        time.sleep(2)

        # 3. Fix permissions on config (in case Docker messed them up)
        console.print("[yellow]Fixing permissions...[/yellow]")
        config_dir = self.detector.get_config_dir()
        if config_dir.exists() and platform.system() != "Windows":
            try:
                subprocess.run(
                    ["chmod", "-R", "u+rw", str(config_dir)],
                    capture_output=True,
                    timeout=10,
                )
                console.print("[green]+ Permissions fixed[/green]")
            except Exception:
                pass

        # 4. Start local gateway
        console.print("\n[blue]GO Starting local gateway...[/blue]")
        if self._start_local_gateway():
            console.print(
                Panel.fit(
                    "[bold green]OK EMERGENCY RESTORE COMPLETE[/bold green]\n\n"
                    "OpenClaw has been restored and is running locally.\n"
                    f"Access at: [cyan]http://127.0.0.1:{self.docker.PORT}[/cyan]",
                    border_style="green",
                )
            )
            return True
        else:
            console.print("[red]X Could not automatically start gateway.[/red]")
            console.print("\n[yellow]Try manually:[/yellow]")
            console.print("   [cyan]openclaw gateway[/cyan]")
            return False

    def get_status(self) -> Dict[str, Any]:
        """Get current status of OpenClaw installations."""
        status = {
            "container_running": self.docker.is_container_running(),
            "local_running": False,
            "local_pid": None,
            "docker_available": False,
            "docker_version": None,
        }

        # Check local process
        current = self.detector.find_running_gateway()
        if current:
            if current["type"] == "local":
                status["local_running"] = True
                status["local_pid"] = current["pid"]
            elif current["type"] == "docker":
                # Some other docker container (not ours)
                pass

        # Check Docker
        docker_check = self.detector.check_docker_available()
        status["docker_available"] = docker_check["available"] and docker_check["running"]
        status["docker_version"] = docker_check.get("version")

        return status

    def _stop_local_gateway(self, pid: int, timeout: int = 10) -> bool:
        """Gracefully stop local OpenClaw gateway."""
        try:
            process = psutil.Process(pid)

            # Try graceful shutdown first
            process.terminate()
            process.wait(timeout=timeout)
            return True

        except psutil.TimeoutExpired:
            # Force kill
            try:
                process.kill()
                process.wait(timeout=5)
                return True
            except Exception:
                return False
        except psutil.NoSuchProcess:
            return True  # Already dead
        except Exception:
            return False

    def _start_local_gateway(self) -> bool:
        """Start local OpenClaw gateway."""
        try:
            # Check if already running
            current = self.detector.find_running_gateway()
            if current and current.get("type") == "local":
                console.print("[green]+ Local gateway already running[/green]")
                return True

            # Try to start openclaw gateway
            # Use Popen to not block, and redirect output
            # On Windows, use shell=True for better compatibility
            import platform
            use_shell = platform.system() == "Windows"
            subprocess.Popen(
                "openclaw gateway" if use_shell else ["openclaw", "gateway"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,  # Don't die when parent dies
                shell=use_shell,
            )

            # Wait for it to start (check port and process)
            console.print("[dim]   Waiting for gateway to start...[/dim]")
            for attempt in range(10):  # Wait up to 10 seconds
                time.sleep(1)
                
                # Check if port is listening
                if self._is_port_in_use(self.docker.PORT):
                    # Verify it's a local process
                    current = self.detector.find_running_gateway()
                    if current and current.get("type") == "local":
                        console.print(f"[green]+ Gateway running (PID: {current['pid']})[/green]")
                        return True

            console.print("[yellow]!  Gateway may not have started properly[/yellow]")
            return False

        except Exception as e:
            console.print(f"[red]X Error starting gateway: {e}[/red]")
            return False

    def _configure_sandbox(self, mode: str, port: int = 18789, disable_device_auth: bool = False) -> bool:
        """
        Configure sandbox mode and gateway binding in openclaw.json.
        Preserves all existing config (models, settings, etc.) and only updates
        the necessary keys for secure container operation.

        Args:
            mode: "all", "non-main", or "off"
            port: Port for the gateway to bind to (default: 18789)
            disable_device_auth: If True, disables device pairing (security risk!)
        """
        try:
            import json

            config_dir = self.detector.get_config_dir()
            config_file = config_dir / "openclaw.json"

            # Load existing config or create new
            if config_file.exists():
                config = json.loads(config_file.read_text())
                console.print(f"[dim]   Merging with existing config: {config_file}[/dim]")
            else:
                config = {}

            # Ensure agents structure exists
            if "agents" not in config:
                config["agents"] = {}
            if "defaults" not in config["agents"]:
                config["agents"]["defaults"] = {}
            if "sandbox" not in config["agents"]["defaults"]:
                config["agents"]["defaults"]["sandbox"] = {}

            # Set sandbox mode
            config["agents"]["defaults"]["sandbox"]["mode"] = mode

            # Set Docker sandbox settings (using valid OpenClaw keys only)
            if "docker" not in config["agents"]["defaults"]["sandbox"]:
                config["agents"]["defaults"]["sandbox"]["docker"] = {}

            docker_config = config["agents"]["defaults"]["sandbox"]["docker"]
            # Only use recognized keys - image and network are standard
            docker_config["image"] = "ghcr.io/openclaw/sandbox:latest"
            docker_config["network"] = "none"  # Block network by default

            # Remove invalid keys if they exist from previous runs
            docker_config.pop("workspaceAccess", None)
            docker_config.pop("resources", None)

            # Configure gateway binding for containerized mode
            # This is the key fix - we need to bind to 0.0.0.0 inside the container
            # so that Docker can forward ports from the host
            if "gateway" not in config:
                config["gateway"] = {}
            
            # Preserve existing gateway config but update necessary keys
            config["gateway"]["bind"] = "custom"
            config["gateway"]["customBindHost"] = "0.0.0.0"
            config["gateway"]["port"] = port
            
            # Preserve existing auth token if present, otherwise OpenClaw will generate one
            if "auth" not in config["gateway"]:
                config["gateway"]["auth"] = {"mode": "token"}

            # Configure control UI settings
            if "controlUi" not in config["gateway"]:
                config["gateway"]["controlUi"] = {}
            
            # Add allowed origins for the container setup
            config["gateway"]["controlUi"]["allowedOrigins"] = [
                f"http://localhost:{port}",
                f"http://127.0.0.1:{port}",
                f"http://0.0.0.0:{port}"
            ]

            # Optionally disable device auth (NOT recommended for security)
            if disable_device_auth:
                console.print("[bold red]WARNING: Disabling device authentication![/bold red]")
                console.print("[yellow]   This allows ANY device on your network to connect.[/yellow]")
                config["gateway"]["controlUi"]["dangerouslyDisableDeviceAuth"] = True
            else:
                # Remove the disable flag if it exists (re-enable device auth)
                config["gateway"]["controlUi"].pop("dangerouslyDisableDeviceAuth", None)

            # Write config back
            config_file.write_text(json.dumps(config, indent=2))

            return True
        except Exception as e:
            console.print(f"[yellow]!  Could not configure sandbox: {e}[/yellow]")
            return False

    def _create_fresh_config(self, port: int = 18789, sandbox_mode: str = "non-main") -> bool:
        """Create a minimal fresh OpenClaw configuration for new users."""
        try:
            import json
            import time
            from pathlib import Path

            config_dir = self.detector.get_config_dir()
            config_file = config_dir / "openclaw.json"
            
            # Ensure directory exists
            config_dir.mkdir(parents=True, exist_ok=True)
            
            # Create workspace and cache directories
            (config_dir / "workspace").mkdir(exist_ok=True)
            (config_dir / ".cache").mkdir(exist_ok=True)
            
            # Generate a random token
            import secrets
            token = secrets.token_urlsafe(32)
            
            # Minimal fresh config with user selections
            fresh_config = {
                "meta": {
                    "lastTouchedVersion": "2026.3.24",
                    "lastTouchedAt": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
                },
                "wizard": {
                    "lastRunAt": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
                    "lastRunVersion": "2026.3.24",
                    "lastRunCommand": "onboard",
                    "lastRunMode": "local"
                },
                "models": {
                    "mode": "merge",
                    "providers": {}
                },
                "agents": {
                    "defaults": {
                        "model": {
                            "primary": "anthropic/claude-3-5-sonnet-20241022"
                        },
                        "workspace": "/home/node/.openclaw/workspace",
                        "sandbox": {
                            "mode": sandbox_mode,
                            "docker": {
                                "image": "ghcr.io/openclaw/sandbox:latest",
                                "network": "none"
                            }
                        }
                    }
                },
                "commands": {
                    "native": "auto",
                    "nativeSkills": "auto",
                    "restart": True,
                    "ownerDisplay": "raw"
                },
                "gateway": {
                    "bind": "custom",
                    "customBindHost": "0.0.0.0",
                    "port": port,
                    "auth": {
                        "mode": "token",
                        "token": token
                    }
                },
                "session": {
                    "dmScope": "per-channel-peer"
                }
            }
            
            config_file.write_text(json.dumps(fresh_config, indent=2))
            console.print(f"[green]   + Created fresh config: {config_file}[/green]")
            console.print("[dim]   Note: You'll need to add your API keys in the dashboard[/dim]")
            return True
            
        except Exception as e:
            console.print(f"[red]X Failed to create fresh config: {e}[/red]")
            return False

    def _stop_docker_container(self, container_name: str) -> bool:
        """Stop a Docker container by name."""
        try:
            # Try graceful stop first
            result = subprocess.run(
                ["docker", "stop", "-t", "10", container_name],
                capture_output=True,
                text=True,
                timeout=15,
            )

            # Note: We don't remove the container so it can be restarted later
            return result.returncode == 0
        except Exception:
            return False

    def _restart_previous_container(self, container_name: str) -> bool:
        """Restart a previously stopped Docker container."""
        try:
            # First check if container still exists
            check = subprocess.run(
                ["docker", "inspect", "-f", "{{.State.Status}}", container_name],
                capture_output=True,
                text=True,
                timeout=5,
            )
            
            if check.returncode != 0:
                # Container doesn't exist anymore (was removed)
                console.print(
                    f"[yellow]!  Previous container '{container_name}' no longer exists.[/yellow]"
                )
                console.print("[blue]<-> Starting local gateway instead...[/blue]")
                return self._start_local_gateway()
            
            result = subprocess.run(
                ["docker", "start", container_name],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode == 0:
                # Wait a moment for it to start
                time.sleep(3)
                return True
            else:
                console.print(
                    f"[yellow]!  Failed to start '{container_name}': {result.stderr}[/yellow]"
                )
                return False
        except Exception as e:
            console.print(f"[red]X Error starting container: {e}[/red]")
            return False

    def _is_port_in_use(self, port: int) -> bool:
        """Check if a port is currently in use."""
        import socket

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex(("127.0.0.1", port))
            sock.close()
            return result == 0  # Port is in use if connect succeeds
        except Exception:
            return False

    def _find_container_using_port(self, port: int) -> Optional[str]:
        """Find which Docker container is using a specific port."""
        try:
            result = subprocess.run(
                ["docker", "ps", "--format", "{{.Names}}|{{.Ports}}"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode != 0:
                return None
            
            for line in result.stdout.strip().split("\n"):
                if "|" in line:
                    name, ports = line.split("|", 1)
                    # Check if port is in the ports string (e.g., "0.0.0.0:18789->18789/tcp")
                    if f":{port}->" in ports or f"->{port}/" in ports:
                        return name
            return None
        except Exception:
            return None

    def _stop_container_using_port(self, port: int) -> bool:
        """Stop any container using the specified port."""
        container = self._find_container_using_port(port)
        if container:
            console.print(f"[yellow]!  Stopping container '{container}' using port {port}...[/yellow]")
            try:
                subprocess.run(
                    ["docker", "stop", "-t", "5", container],
                    capture_output=True,
                    timeout=10,
                )
                subprocess.run(
                    ["docker", "rm", container],
                    capture_output=True,
                    timeout=5,
                )
                console.print(f"[green]+ Stopped '{container}'[/green]")
                return True
            except Exception as e:
                console.print(f"[red]X Failed to stop container: {e}[/red]")
                return False
        return True  # No container using port

    def _open_browser(self, url: str) -> bool:
        """Open browser to the specified URL."""
        try:
            import webbrowser
            webbrowser.open(url)
            return True
        except Exception:
            # Fallback for different platforms
            try:
                if platform.system() == "Windows":
                    os.system(f'start "" "{url}"')
                elif platform.system() == "Darwin":  # macOS
                    os.system(f'open "{url}"')
                else:  # Linux
                    os.system(f'xdg-open "{url}"')
                return True
            except Exception:
                return False

    def _get_dashboard_url(self, port: int) -> str:
        """Get the dashboard URL with token from the container."""
        url = f"http://127.0.0.1:{port}"
        try:
            result = subprocess.run(
                ["docker", "exec", self.docker.CONTAINER_NAME,
                 "openclaw", "dashboard", "--no-open"],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=30,
            )
            if result.returncode == 0:
                # Extract URL from output (format: "Dashboard URL: http://...")
                import re
                url_match = re.search(r'(https?://[^\s]+)', result.stdout)
                if url_match:
                    # Replace 0.0.0.0 with 127.0.0.1 for localhost access
                    url = url_match.group(1).replace("0.0.0.0", "127.0.0.1")
        except Exception:
            pass
        return url

    def _auto_approve_devices(self) -> None:
        """Automatically approve all pending devices."""
        try:
            # First, list devices to see pending ones
            result = subprocess.run(
                ["docker", "exec", self.docker.CONTAINER_NAME,
                 "openclaw", "devices", "list"],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=10,
            )
            
            if result.returncode != 0:
                return
            
            output = result.stdout
            
            # Check if there are pending devices
            if "Pending" not in output:
                console.print("[dim]   No pending devices to approve[/dim]")
                return
            
            # Extract pending device request IDs from the table
            # The format shows request IDs in the first column of pending section
            import re
            
            # Find all pending request IDs (UUID format)
            pending_ids = re.findall(r'([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})', output)
            
            if not pending_ids:
                console.print("[dim]   No pending device requests found[/dim]")
                return
            
            console.print(f"[yellow]   Found {len(pending_ids)} pending device(s)[/yellow]")
            
            # Approve each pending device
            for device_id in pending_ids:
                console.print(f"   Approving [cyan]{device_id}[/cyan]...", end=" ")
                approve_result = subprocess.run(
                    ["docker", "exec", self.docker.CONTAINER_NAME,
                     "openclaw", "devices", "approve", device_id],
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    timeout=10,
                )
                if approve_result.returncode == 0:
                    console.print("[green]OK[/green]")
                else:
                    console.print("[red]FAILED[/red]")
                    
        except Exception as e:
            console.print(f"[dim]   Could not auto-approve devices: {e}[/dim]")

    def _wait_for_port_release(self, port: int, timeout: int = 30) -> bool:
        """Wait for a port to be released."""
        import socket

        start = time.time()
        while time.time() - start < timeout:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                result = sock.connect_ex(("127.0.0.1", port))
                sock.close()

                if result != 0:  # Port is free
                    return True

                time.sleep(1)
            except Exception:
                time.sleep(1)

        return False
