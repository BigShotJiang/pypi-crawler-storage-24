"""
Selective backup of valuable OpenClaw configuration files.
Only backs up irreplaceable configs, not cache or temporary files.
"""

import os
import tarfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Files that contain irreplaceable user data (API keys, settings, etc.)
VALUABLE_FILES = {
    # Main configuration
    "openclaw.json": "Main configuration file",
    "settings.json": "Settings file",
    "settings.yaml": "Settings file (YAML)",
    "paired.json": "Pairing information",
    "identity": "User identity",
    "update-check.json": "Update check data",
}

# Directories to backup (contain user data)
VALUABLE_DIRECTORIES = {
    "credentials": "Channel credentials (Telegram, WhatsApp, Discord, etc.)",
    "workspace": "Skills, memories, prompts",
    "agents": "Agent session data",
    "canvas": "Canvas data",
    "completions": "Completion history",
    "memory": "Memory data",
    "devices": "Device configurations",
    "identity": "Identity directory",
}

# Files/directories to NEVER backup (rebuildable or temporary)
EXCLUDED_PATTERNS = [
    ".cache",
    "cache",
    "logs",
    "log",
    "tmp",
    "temp",
    "*.log",
    "*.tmp",
    "*.temp",
    "__pycache__",
    "node_modules",
]


class ConfigBackup:
    """Manages selective backup of OpenClaw configuration."""

    def __init__(self, config_dir: Path):
        self.config_dir = Path(config_dir)
        self.backup_dir = Path.home() / ".openclaw-secure" / "backups"
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def create_backup(self) -> Optional[Path]:
        """
        Create a selective backup of valuable config files only.
        Returns path to backup file or None if nothing to backup.
        """
        files_to_backup = self._find_valuable_files()

        if not files_to_backup:
            return None

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = self.backup_dir / f"openclaw-backup-{timestamp}.tar.gz"

        # Create tarball
        with tarfile.open(backup_file, "w:gz") as tar:
            for file_path, rel_path in files_to_backup:
                tar.add(file_path, arcname=rel_path)

        # Set read-only permissions
        os.chmod(backup_file, 0o600)

        # Clean old backups (keep last 5)
        self._cleanup_old_backups()

        return backup_file

    def _find_valuable_files(self) -> List[Tuple[Path, str]]:
        """Find all valuable config files to backup."""
        files_to_backup = []

        if not self.config_dir.exists():
            return files_to_backup

        # Look for specific valuable files
        for filename, description in VALUABLE_FILES.items():
            filepath = self.config_dir / filename
            if filepath.is_file():
                rel_path = filepath.relative_to(self.config_dir)
                files_to_backup.append((filepath, str(rel_path)))

        # Look for valuable directories
        for dirname, description in VALUABLE_DIRECTORIES.items():
            dirpath = self.config_dir / dirname
            if dirpath.is_dir():
                # Add all files in this directory
                for file_path in dirpath.rglob("*"):
                    if file_path.is_file() and not self._is_excluded(file_path):
                        rel_path = file_path.relative_to(self.config_dir)
                        files_to_backup.append((file_path, str(rel_path)))

        # Also find any JSON/YAML config files not explicitly listed
        for file_path in self.config_dir.iterdir():
            if file_path.is_file() and file_path.suffix in [".json", ".yaml", ".yml"]:
                rel_path = file_path.relative_to(self.config_dir)
                # Check if already added
                if not any(f[1] == str(rel_path) for f in files_to_backup):
                    files_to_backup.append((file_path, str(rel_path)))

        return files_to_backup

    def _is_excluded(self, path: Path) -> bool:
        """Check if path should be excluded from backup."""
        path_str = str(path).lower()

        for pattern in EXCLUDED_PATTERNS:
            if pattern.lower() in path_str:
                return True

        return False

    def _cleanup_old_backups(self, keep: int = 5) -> None:
        """Keep only the most recent backups."""
        backups = sorted(self.backup_dir.glob("openclaw-backup-*.tar.gz"))

        if len(backups) > keep:
            for old_backup in backups[:-keep]:
                old_backup.unlink()

    def list_backups(self) -> List[Dict[str, any]]:
        """List available backups with metadata."""
        backups = []

        for backup_file in sorted(self.backup_dir.glob("openclaw-backup-*.tar.gz"), reverse=True):
            stat = backup_file.stat()
            backups.append(
                {
                    "path": backup_file,
                    "name": backup_file.name,
                    "size_kb": stat.st_size / 1024,
                    "created": datetime.fromtimestamp(stat.st_mtime),
                }
            )

        return backups

    def restore_backup(self, backup_path: Path) -> bool:
        """Restore configuration from a backup file."""
        if not backup_path.exists():
            return False

        # Ensure config directory exists
        self.config_dir.mkdir(parents=True, exist_ok=True)

        # Extract backup
        with tarfile.open(backup_path, "r:gz") as tar:
            tar.extractall(path=self.config_dir)

        return True

    def verify_backup_integrity(self, backup_path: Path) -> bool:
        """Verify a backup file can be opened and contains valid files."""
        try:
            with tarfile.open(backup_path, "r:gz") as tar:
                # Check if we can list members
                members = tar.getmembers()
                if not members:
                    return False

                # Verify at least one config file exists
                config_files = [m for m in members if m.name.endswith((".json", ".yaml", ".yml"))]
                return len(config_files) > 0
        except Exception:
            return False

    def get_backup_summary(self, backup_path: Path) -> Dict[str, any]:
        """Get a summary of what's in a backup file."""
        try:
            with tarfile.open(backup_path, "r:gz") as tar:
                members = tar.getmembers()

                files = [m.name for m in members if m.isfile()]
                dirs = [m.name for m in members if m.isdir()]

                return {
                    "valid": True,
                    "file_count": len(files),
                    "directory_count": len(dirs),
                    "files": files[:20],  # First 20 files
                    "has_openclaw_json": any("openclaw.json" in f for f in files),
                    "has_credentials": any("credentials" in f for f in files),
                    "has_workspace": any("workspace" in f for f in files),
                }
        except Exception as e:
            return {"valid": False, "error": str(e)}
