"""
Allow running with `python -m openclaw_secure`
"""

from .cli import main

if __name__ == "__main__":
    main()
