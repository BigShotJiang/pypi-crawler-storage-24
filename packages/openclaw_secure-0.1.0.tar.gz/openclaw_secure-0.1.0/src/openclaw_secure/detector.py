"""
Detect OpenClaw installations and running processes.
Cross-platform support for Linux, macOS, and Windows.
Uses system commands to locate config files.
"""

import os
import platform
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional


class OpenClawDetector:
    """Detects OpenClaw installations, processes, and configuration."""

    def __init__(self):
        self.system = platform.system()

    def find_openclaw_binary(self) -> Optional[str]:
        """Find openclaw binary in PATH."""
        return shutil.which("openclaw")

    def find_running_gateway(self) -> Optional[Dict[str, Any]]:
        """Find running OpenClaw gateway process or container."""
        # First check for Docker container
        container = self._find_docker_container()
        if container:
            return {
                "type": "docker",
                "container_name": container["name"],
                "container_id": container["id"],
                "status": container["status"],
            }

        # Then check for local process using psutil if available
        try:
            import psutil

            for proc in psutil.process_iter(["pid", "name", "cmdline"]):
                try:
                    cmdline = proc.info.get("cmdline") or []
                    cmdline_str = " ".join(cmdline).lower()

                    if any(x in cmdline_str for x in ["openclaw-gateway", "openclaw gateway"]):
                        return {
                            "type": "local",
                            "pid": proc.info["pid"],
                            "cmdline": cmdline,
                        }
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except ImportError:
            pass

        # Fallback: check using pgrep
        try:
            result = subprocess.run(
                ["pgrep", "-f", "openclaw-gateway"],
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0 and result.stdout.strip():
                pid = int(result.stdout.strip().split()[0])
                return {"type": "local", "pid": pid, "cmdline": ["openclaw-gateway"]}
        except Exception:
            pass

        return None

    def _find_docker_container(self) -> Optional[Dict[str, str]]:
        """Check if OpenClaw is running in Docker."""
        try:
            result = subprocess.run(
                [
                    "docker",
                    "ps",
                    "--filter",
                    "name=openclaw",
                    "--format",
                    "{{.Names}}|{{.ID}}|{{.Status}}",
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )

            if result.returncode == 0 and result.stdout.strip():
                lines = result.stdout.strip().split("\n")
                for line in lines:
                    parts = line.split("|")
                    if len(parts) >= 2 and "openclaw" in parts[0].lower():
                        return {
                            "name": parts[0],
                            "id": parts[1],
                            "status": parts[2] if len(parts) > 2 else "unknown",
                        }
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

        return None

    def _search_for_config(self) -> Optional[Path]:
        """
        Use system commands to find openclaw.json config file.
        This is more reliable than hardcoded paths.
        """
        # Search in common locations first (faster)
        common_paths = [
            Path.home() / ".openclaw",
        ]
        
        # On Windows, also search common project locations
        if self.system == "Windows":
            # Add common project directories (non-recursive check)
            common_paths.extend([
                Path.home() / "Documents" / "openclaw",
                Path.home() / "Projects" / "openclaw",
                Path("G:") / "Python Projects" / "openclaw_privacy" / "openclaw-docker" / "config",
                Path("C:") / "openclaw",
            ])

        for base_path in common_paths:
            if base_path.exists():
                # Look for openclaw.json directly
                json_file = base_path / "openclaw.json"
                if json_file.exists():
                    return base_path

                # Search one level deep
                try:
                    for subdir in base_path.iterdir():
                        if subdir.is_dir():
                            json_file = subdir / "openclaw.json"
                            if json_file.exists():
                                return subdir
                except PermissionError:
                    continue

        # Try using find command (Linux/macOS/WSL)
        if self.system in ["Linux", "Darwin"]:
            try:
                result = subprocess.run(
                    [
                        "find",
                        str(Path.home()),
                        "-maxdepth",
                        "3",
                        "-name",
                        "openclaw.json",
                        "2>/dev/null",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    shell=False,
                )
                if result.returncode == 0 and result.stdout.strip():
                    path = Path(result.stdout.strip().split("\n")[0])
                    return path.parent
            except Exception:
                pass

        # Try using locate command if available
        try:
            result = subprocess.run(
                ["locate", "openclaw.json"],
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0 and result.stdout.strip():
                # Filter to likely config paths
                lines = result.stdout.strip().split("\n")
                for line in lines:
                    if ".openclaw" in line or "config" in line.lower():
                        return Path(line).parent
        except Exception:
            pass

        return None

    def get_config_dir(self) -> Path:
        """
        Get OpenClaw configuration directory.

        Uses multiple strategies:
        1. Environment variables (OPENCLAW_CONFIG_PATH, OPENCLAW_HOME)
        2. Search using system commands
        3. Platform-specific defaults
        """
        # Check OPENCLAW_CONFIG_PATH (points to file or dir)
        if "OPENCLAW_CONFIG_PATH" in os.environ:
            config_path = Path(os.environ["OPENCLAW_CONFIG_PATH"])
            if config_path.is_file():
                return config_path.parent
            return config_path

        # Check OPENCLAW_HOME
        if "OPENCLAW_HOME" in os.environ:
            return Path(os.environ["OPENCLAW_HOME"])

        # Try to find using search
        found = self._search_for_config()
        if found:
            return found

        # Platform-specific defaults as fallback
        if self.system == "Windows":
            return Path.home() / ".openclaw"
        elif self.system == "Darwin":
            return Path.home() / ".openclaw"
        else:
            # Linux and others
            return Path.home() / ".openclaw"

    def get_workspace_dir(self) -> Path:
        """Get OpenClaw workspace directory."""
        # Check environment variable
        if "OPENCLAW_WORKSPACE" in os.environ:
            return Path(os.environ["OPENCLAW_WORKSPACE"])

        # Try to find workspace within config
        config_dir = self.get_config_dir()
        workspace = config_dir / "workspace"
        if workspace.exists():
            return workspace

        # Fallback: return expected location
        return config_dir / "workspace"

    def get_cache_dir(self) -> Path:
        """Get OpenClaw cache directory."""
        # Check XDG_CACHE_HOME
        if "XDG_CACHE_HOME" in os.environ:
            return Path(os.environ["XDG_CACHE_HOME"]) / "openclaw"

        # Platform-specific
        if self.system == "Windows":
            return Path.home() / ".openclaw" / ".cache"
        elif self.system == "Darwin":
            return Path.home() / ".openclaw" / ".cache"
        else:
            # Linux: prefer XDG location
            xdg_cache = Path.home() / ".cache" / "openclaw"
            if xdg_cache.exists():
                return xdg_cache
            return Path.home() / ".openclaw" / ".cache"

    def find_openclaw_json(self) -> Optional[Path]:
        """Find openclaw.json config file."""
        config_dir = self.get_config_dir()
        json_file = config_dir / "openclaw.json"
        if json_file.exists():
            return json_file
        return None

    def check_docker_available(self) -> Dict[str, Any]:
        """Check if Docker is available and running."""
        result = {
            "available": False,
            "running": False,
            "version": None,
            "errors": [],
        }

        if not shutil.which("docker"):
            result["errors"].append("Docker not found in PATH")
            return result

        result["available"] = True

        try:
            version_result = subprocess.run(
                ["docker", "version", "--format", "{{.Server.Version}}"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            if version_result.returncode == 0:
                result["running"] = True
                result["version"] = version_result.stdout.strip()
            else:
                result["errors"].append("Docker daemon not running")
        except Exception as e:
            result["errors"].append(str(e))

        return result

    def get_full_config_structure(self) -> Dict[str, Path]:
        """Get full OpenClaw configuration structure."""
        config_dir = self.get_config_dir()

        return {
            "config_dir": config_dir,
            "openclaw_json": config_dir / "openclaw.json",
            "workspace": config_dir / "workspace",
            "credentials": config_dir / "credentials",
            "agents": config_dir / "agents",
            "canvas": config_dir / "canvas",
            "completions": config_dir / "completions",
            "identity": config_dir / "identity",
            "logs": config_dir / "logs",
            "memory": config_dir / "memory",
            "devices": config_dir / "devices",
            "cache": self.get_cache_dir(),
        }
