"""
Docker backend for running OpenClaw in a secure container.
Uses OpenClaw's official images and standards.
"""

import os
import platform
import subprocess
import time
from pathlib import Path
from typing import Dict


class DockerBackend:
    """Manages OpenClaw Docker container using official OpenClaw standards."""

    CONTAINER_NAME = "openclaw-secure"
    IMAGE = "ghcr.io/openclaw/openclaw:latest"
    PORT = 18789

    def __init__(self, config_dir: Path, workspace_dir: Path, cache_dir: Path):
        self.config_dir = config_dir
        self.workspace_dir = workspace_dir
        self.cache_dir = cache_dir
        self.system = platform.system()
        self._compose_file: Path = None

    def find_compose_file(self) -> Path:
        """
        Look for docker-compose.yml or compose.yml in common locations.
        Returns the path if found, None otherwise.
        """
        if self._compose_file:
            return self._compose_file

        # Common locations to check
        search_paths = [
            Path.cwd() / "docker-compose.yml",
            Path.cwd() / "compose.yml",
            Path.cwd() / "docker-compose.yaml",
            Path.cwd() / "compose.yaml",
            Path.home() / ".openclaw" / "docker-compose.yml",
            Path.home() / ".openclaw" / "compose.yml",
            self.config_dir / "docker-compose.yml",
            self.config_dir / "compose.yml",
        ]

        for path in search_paths:
            if path.exists():
                self._compose_file = path
                return path

        return None

    def has_compose_file(self) -> bool:
        """Check if a docker-compose file exists."""
        return self.find_compose_file() is not None

    def start_with_compose(self, network_mode: str = "none") -> bool:
        """
        Start OpenClaw using docker-compose if a compose file exists.
        """
        compose_file = self.find_compose_file()
        if not compose_file:
            return False

        try:
            # Change to compose file directory
            cwd = compose_file.parent

            # Pull latest images
            subprocess.run(
                ["docker-compose", "pull"],
                cwd=cwd,
                capture_output=True,
                timeout=120,
            )

            # Start with security environment variables
            env = os.environ.copy()
            env["OPENCLAW_SANDBOX"] = "1"
            env["OPENCLAW_SANDBOX_MODE"] = "all"

            if network_mode == "none":
                # Need to modify compose or use network_mode in command
                pass

            result = subprocess.run(
                ["docker-compose", "up", "-d"],
                cwd=cwd,
                env=env,
                capture_output=True,
                text=True,
                timeout=60,
            )

            return result.returncode == 0
        except Exception:
            return False

    def stop_with_compose(self) -> bool:
        """
        Stop OpenClaw using docker-compose.
        """
        compose_file = self.find_compose_file()
        if not compose_file:
            return False

        try:
            cwd = compose_file.parent
            result = subprocess.run(
                ["docker-compose", "down"],
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.returncode == 0
        except Exception:
            return False

    def is_container_running(self) -> bool:
        """Check if our secure container is running."""
        try:
            result = subprocess.run(
                [
                    "docker",
                    "ps",
                    "--filter",
                    f"name={self.CONTAINER_NAME}",
                    "--format",
                    "{{.Names}}",
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return self.CONTAINER_NAME in result.stdout
        except Exception:
            return False

    def stop_container(self, force: bool = False) -> bool:
        """Stop the secure container."""
        try:
            cmd = ["docker", "stop"]
            if force:
                cmd.append("-t")
                cmd.append("0")
            cmd.append(self.CONTAINER_NAME)

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            # Also remove the container
            subprocess.run(
                ["docker", "rm", self.CONTAINER_NAME],
                capture_output=True,
                timeout=10,
            )

            return result.returncode == 0
        except Exception:
            return False

    def start_container(
        self,
        network_mode: str = "none",
        sandbox_mode: str = "all",
        host_port: int = None,
        container_port: int = 18789,
    ) -> bool:
        """
        Start OpenClaw in a secure Docker container.

        Uses OpenClaw's official image with secure defaults.

        Args:
            network_mode: Docker network mode (none, bridge)
            sandbox_mode: OpenClaw sandbox mode (all, non-main, off)
            host_port: Port on host to map (default: 18789)
            container_port: Port inside container (default: 18789)
        """
        # Ensure directories exist
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.workspace_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # Use default port if not specified
        if host_port is None:
            host_port = self.PORT

        # Convert Windows paths to forward slashes for Docker
        # Docker on Windows accepts both, but forward slashes are safer
        def to_docker_path(path: Path) -> str:
            path_str = str(path)
            if self.system == "Windows":
                # Convert backslashes to forward slashes
                path_str = path_str.replace("\\", "/")
            return path_str

        config_path = to_docker_path(self.config_dir)
        workspace_path = to_docker_path(self.workspace_dir)
        cache_path = to_docker_path(self.cache_dir)

        # Build docker run command following OpenClaw standards
        # Use simple port mapping (without 127.0.0.1) for better Windows compatibility
        cmd = [
            "docker",
            "run",
            "-d",
            "--restart", "unless-stopped",  # Keep container running across restarts
            "--name",
            self.CONTAINER_NAME,
            "-p",
            f"{host_port}:{container_port}",
            # Mount config (read-write for API key updates)
            "-v",
            f"{config_path}:/home/node/.openclaw:rw",
            # Mount workspace
            "-v",
            f"{workspace_path}:/home/node/.openclaw/workspace:rw",
            # Mount cache
            "-v",
            f"{cache_path}:/home/node/.openclaw/.cache:rw",
        ]

        # Mount Docker socket for sandbox mode (Docker-out-of-Docker)
        # Only on Linux/macOS - Windows Docker Desktop handles this differently
        if self.system != "Windows":
            cmd.extend(
                [
                    "-v",
                    "/var/run/docker.sock:/var/run/docker.sock",
                ]
            )

        # Add remaining options
        cmd.extend(
            [
                # Security options
                "--security-opt",
                "no-new-privileges:true",
                "--cap-drop",
                "ALL",
                "--read-only",
                "--tmpfs",
                "/tmp:noexec,nosuid,size=100m",
                "--tmpfs",
                "/home/node/.openclaw/tmp:noexec,nosuid,size=50m",
            ]
        )

        # Handle UID/GID mapping for Linux
        if self.system == "Linux":
            uid = os.getuid()
            gid = os.getgid()
            cmd.extend(["--user", f"{uid}:{gid}"])

        # Environment variables for OpenClaw
        # Note: Gateway binding is configured via openclaw.json (written by _configure_sandbox)
        # not via environment variables - OpenClaw reads gateway config from the config file
        env_vars = {
            # Sandbox settings
            "OPENCLAW_SANDBOX": "1",
            "OPENCLAW_SANDBOX_MODE": sandbox_mode,
            # Node environment
            "NODE_ENV": "production",
        }

        for key, value in env_vars.items():
            cmd.extend(["-e", f"{key}={value}"])

        # Network mode
        # Note: --network none blocks ALL networking including port forwarding
        # Use bridge mode (default) to allow port access while still isolating
        if network_mode == "none":
            # For true network isolation, we'd use --network none
            # But this breaks port forwarding, so we skip it
            # The container still has limited network access via bridge
            pass
        elif network_mode == "bridge":
            # Default bridge network - isolated but allows port forwarding
            pass

        # Add the image
        cmd.append(self.IMAGE)

        # Run the container
        # On Windows, use shell=True to properly handle argument parsing
        use_shell = self.system == "Windows"
        if use_shell:
            # Convert command list to string for shell execution
            cmd_str = subprocess.list2cmdline(cmd)
            result = subprocess.run(cmd_str, capture_output=True, text=True, shell=True)
        else:
            result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            error_msg = "Failed to start container:\n"
            error_msg += f"Command: {' '.join(cmd)}\n"
            error_msg += f"Exit code: {result.returncode}\n"
            error_msg += f"Stdout: {result.stdout}\n"
            error_msg += f"Stderr: {result.stderr}"
            raise RuntimeError(error_msg)

        # Wait for container to be healthy
        return self._wait_for_healthy(timeout=60, port=container_port)

    def _wait_for_healthy(self, timeout: int = 60, port: int = None) -> bool:
        """Wait for container to be running."""
        start = time.time()

        while time.time() - start < timeout:
            try:
                # Check if container is running using docker inspect
                result = subprocess.run(
                    ["docker", "inspect", "-f", "{{.State.Running}}", self.CONTAINER_NAME],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )

                if result.returncode == 0 and result.stdout.strip() == "true":
                    return True

                # Check if container exited/failed
                status_result = subprocess.run(
                    ["docker", "inspect", "-f", "{{.State.Status}}", self.CONTAINER_NAME],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if status_result.returncode == 0:
                    status = status_result.stdout.strip()
                    if status in ["exited", "dead"]:
                        return False

                time.sleep(2)

            except subprocess.TimeoutExpired:
                continue
            except Exception:
                time.sleep(2)

        return False

    def get_container_logs(self, tail: int = 50) -> str:
        """Get container logs for debugging."""
        try:
            result = subprocess.run(
                ["docker", "logs", "--tail", str(tail), self.CONTAINER_NAME],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return result.stdout + result.stderr
        except Exception as e:
            return f"Failed to get logs: {e}"

    def pull_latest_image(self) -> bool:
        """Pull the latest OpenClaw image."""
        try:
            result = subprocess.run(
                ["docker", "pull", self.IMAGE],
                capture_output=True,
                text=True,
                timeout=300,
            )
            return result.returncode == 0
        except Exception:
            return False

    def verify_mounts(self) -> Dict[str, bool]:
        """Verify that all required mounts are working."""
        mounts = {
            "config": False,
            "workspace": False,
            "cache": False,
        }

        try:
            # Check if config is readable
            result = subprocess.run(
                ["docker", "exec", self.CONTAINER_NAME, "ls", "/home/node/.openclaw"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            mounts["config"] = result.returncode == 0

            # Check if workspace is readable
            result = subprocess.run(
                ["docker", "exec", self.CONTAINER_NAME, "ls", "/home/node/.openclaw/workspace"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            mounts["workspace"] = result.returncode == 0

            # Check if cache is writable
            result = subprocess.run(
                [
                    "docker",
                    "exec",
                    self.CONTAINER_NAME,
                    "touch",
                    "/home/node/.openclaw/.cache/test",
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            mounts["cache"] = result.returncode == 0

        except Exception:
            pass

        return mounts
