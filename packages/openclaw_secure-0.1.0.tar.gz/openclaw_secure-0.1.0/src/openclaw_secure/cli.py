"""
Command-line interface for openclaw-secure.
Provides commands to enable, disable, and manage secure mode.
"""

import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .backup import ConfigBackup
from .controller import OpenClawSecureController
from .detector import OpenClawDetector

console = Console()


@click.group()
@click.version_option(version="0.1.0", prog_name="openclaw-secure")
def cli() -> None:
    """
    SEC openclaw-secure - Run OpenClaw in a secure, sandboxed container.

    Moves your existing OpenClaw installation into a Docker container
    with enhanced security while preserving all your configuration,
    API keys, and history.

    Your config files remain fully editable - update API keys anytime!

    Quick start:
        openclaw-secure enable    # Switch to secure mode
        openclaw-secure disable   # Return to normal mode
        openclaw-secure status    # Check current mode
    """
    pass


@cli.command()
@click.option(
    "--no-backup",
    is_flag=True,
    help="Skip creating safety backup of config files.",
)
@click.option(
    "--network",
    type=click.Choice(["none", "bridge"], case_sensitive=False),
    default="bridge",
    help="Network mode for container (bridge=isolated with ports, none=blocked but breaks ports).",
)
@click.option(
    "--port",
    type=int,
    default=None,
    help="Port to use for the secure container (default: 18789 or next available).",
)
@click.option(
    "--sandbox",
    type=click.Choice(["chat-only", "maximum", "none"], case_sensitive=False),
    default=None,
    help="Sandbox mode: chat-only (recommended), maximum security, or none.",
)
@click.option(
    "--yes", "-y",
    is_flag=True,
    help="Skip all confirmations (non-interactive mode).",
)
@click.option(
    "--disable-device-auth",
    is_flag=True,
    help="[DANGER] Disable device pairing. Only use on trusted networks!",
)
@click.option(
    "--config",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    default=None,
    help="Path to OpenClaw config directory (default: auto-detect ~/.openclaw).",
)
def enable(no_backup: bool, network: str, port: int, sandbox: str, yes: bool, disable_device_auth: bool, config: Path) -> None:
    """
    Enable secure mode - move OpenClaw into a sandboxed Docker container.

    This will:
    1. Stop your current OpenClaw gateway (if running)
    2. Start OpenClaw in a secure Docker container
    3. Mount your config and workspace (read-write)
    4. Enable agent sandboxing for all tool execution

    Your API keys, settings, and history are preserved and editable.

    \b
    Examples:
        openclaw-secure enable                     # Enable with defaults
        openclaw-secure enable --port 8080         # Use custom port
        openclaw-secure enable -y --sandbox maximum # Non-interactive max security
    """
    # Set config path if provided
    if config:
        import os
        os.environ["OPENCLAW_CONFIG_PATH"] = str(config)
    
    controller = OpenClawSecureController()
    
    # Show detected config path and allow override if interactive
    detected_config = controller.detector.get_config_dir()
    if not yes:  # Interactive mode
        console.print(f"\n[bold]CFG Config directory:[/bold]")
        console.print(f"   Detected: [cyan]{detected_config}[/cyan]")
        from rich.prompt import Confirm
        if Confirm.ask("   Use a different config path?", default=False):
            from rich.prompt import Prompt
            new_path = Prompt.ask("   Enter config directory path")
            if new_path:
                import os
                os.environ["OPENCLAW_CONFIG_PATH"] = new_path
                # Re-initialize detector with new path
                controller = OpenClawSecureController()
    else:
        console.print(f"[dim]i  Config: {detected_config}[/dim]")
    
    success = controller.enable_secure_mode(
        create_backup=not no_backup,
        network_mode=network,
        host_port=port,
        sandbox_mode=sandbox,
        auto_confirm=yes,
        disable_device_auth=disable_device_auth,
    )
    sys.exit(0 if success else 1)


@cli.command()
def disable() -> None:
    """
    Disable secure mode - return to local OpenClaw installation.

    This will:
    1. Stop the secure Docker container
    2. Start your local OpenClaw gateway
    3. Preserve all config changes made in secure mode

    \b
    If the automatic disable fails, run:
        openclaw-secure emergency-restore
    """
    controller = OpenClawSecureController()
    success = controller.disable_secure_mode()
    sys.exit(0 if success else 1)


@cli.command()
def status() -> None:
    """
    Show current OpenClaw mode and status.

    Displays whether OpenClaw is running in secure (Docker) mode
    or normal (local) mode, along with Docker availability.
    """
    controller = OpenClawSecureController()

    status_info = controller.get_status()

    console.print(
        Panel.fit("[bold blue]FIND OPENCLAW SECURE MODE STATUS[/bold blue]", border_style="blue")
    )

    # Determine current mode
    if status_info["container_running"] and status_info["local_running"]:
        mode = "[yellow]!  CONFLICT[/yellow]"
        description = "Both container AND local gateway running!"
        recommendation = "Run: openclaw-secure disable"
    elif status_info["container_running"]:
        mode = "[bold green]SEC SECURE (Docker)[/bold green]"
        description = "Running in sandboxed container"
        recommendation = "To return to normal: openclaw-secure disable"
    elif status_info["local_running"]:
        mode = "[cyan]OPEN NORMAL (Local)[/cyan]"
        description = "Running as standard local installation"
        recommendation = "To enable secure mode: openclaw-secure enable"
    else:
        mode = "[dim]? NOT RUNNING[/dim]"
        description = "No OpenClaw gateway detected"
        recommendation = "Start with: openclaw gateway OR openclaw-secure enable"

    # Create status table
    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan")
    table.add_column("Value")

    table.add_row("Mode", mode)
    table.add_row("Status", description)

    if status_info["local_pid"]:
        table.add_row("Local PID", str(status_info["local_pid"]))

    # Docker status
    if status_info["docker_available"]:
        docker_status = f"[green]+ Available[/green] (v{status_info['docker_version']})"
    else:
        docker_status = "[red]X Not available[/red]"
    table.add_row("Docker", docker_status)

    console.print(table)

    # Show recommendation
    console.print(f"\n[bold]?[/bold] {recommendation}")

    # Show help
    console.print("\n[dim]Commands:[/dim]")
    console.print("  [cyan]openclaw-secure enable[/cyan]   - Switch to secure mode")
    console.print("  [cyan]openclaw-secure disable[/cyan]  - Return to normal mode")
    console.print("  [cyan]openclaw-secure status[/cyan]   - Show this status")

    sys.exit(0)


@cli.command()
@click.option(
    "--list",
    "list_backups",
    is_flag=True,
    help="List available backups instead of restoring.",
)
@click.option(
    "--backup-file",
    type=click.Path(exists=True, path_type=str),
    help="Specific backup file to restore (from --list).",
)
def emergency_restore(list_backups: bool, backup_file: Optional[str]) -> None:
    """
    SOS Emergency restore - recover when normal operations fail.

    This command:
    1. Force stops ALL OpenClaw processes (container and local)
    2. Optionally restores config from a backup
    3. Fixes file permissions
    4. Restarts local OpenClaw gateway

    \b
    Use this when:
    - 'disable' command fails or hangs
    - Container crashes and won't stop
    - Permission errors after switching modes
    - You need to force back to a working state

    \b
    Examples:
        openclaw-secure emergency-restore         # Auto-restore
        openclaw-secure emergency-restore --list  # See backups
        openclaw-secure emergency-restore --backup-file /path/to/backup.tar.gz
    """
    detector = OpenClawDetector()

    if list_backups:
        # List available backups
        backup_mgr = ConfigBackup(detector.get_config_dir())
        backups = backup_mgr.list_backups()

        if not backups:
            console.print("[yellow]No backups found.[/yellow]")
            console.print(f"\nBackup location: {backup_mgr.backup_dir}")
            return

        console.print("[bold]Available backups:[/bold]\n")

        table = Table(show_header=True)
        table.add_column("#", style="cyan")
        table.add_column("Name")
        table.add_column("Size", justify="right")
        table.add_column("Created")

        for i, backup in enumerate(backups, 1):
            table.add_row(
                str(i),
                backup["name"],
                f"{backup['size_kb']:.1f} KB",
                backup["created"].strftime("%Y-%m-%d %H:%M"),
            )

        console.print(table)
        console.print(f"\n[dim]Location: {backup_mgr.backup_dir}[/dim]")
        return

    if backup_file:
        # Restore specific backup
        backup_mgr = ConfigBackup(detector.get_config_dir())

        console.print(f"[yellow]Restoring from: {backup_file}[/yellow]")

        if backup_mgr.restore_backup(Path(backup_file)):
            console.print("[green]+ Config restored successfully[/green]")
        else:
            console.print("[red]? Failed to restore backup[/red]")
            sys.exit(1)

    # Perform emergency restore
    controller = OpenClawSecureController()
    success = controller.emergency_restore()
    sys.exit(0 if success else 1)


@cli.command()
@click.option(
    "--no-open",
    is_flag=True,
    help="Print URL instead of opening browser.",
)
def dashboard(no_open: bool) -> None:
    """
    WEB Open OpenClaw dashboard in browser.
    
    Gets the authenticated dashboard URL with token and opens it
    in your default browser. The dashboard runs inside the secure
    container but is accessible via localhost.
    
    \b
    Examples:
        openclaw-secure dashboard           # Open browser automatically
        openclaw-secure dashboard --no-open # Just print the URL
    """
    controller = OpenClawSecureController()
    
    # Check if secure container is running
    if not controller.docker.is_container_running():
        console.print("[red]X Secure container is not running.[/red]")
        console.print("   Run: [cyan]openclaw-secure enable[/cyan]")
        sys.exit(1)
    
    # Get the port from the running container
    port = controller.docker.PORT
    
    console.print("[blue]WEB Getting dashboard URL...[/blue]")
    
    # Try to get the dashboard URL with token from inside the container
    # The CLI inside the container knows the correct token
    url = None
    try:
        import subprocess
        result = subprocess.run(
            ["docker", "exec", controller.docker.CONTAINER_NAME, 
             "openclaw", "dashboard", "--no-open"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=10,
        )
        if result.returncode == 0:
            # Extract URL from output (last line usually contains the URL)
            lines = result.stdout.strip().split("\n")
            for line in reversed(lines):
                if "http://" in line or "https://" in line:
                    url = line.strip()
                    break
    except Exception:
        pass
    
    # Fallback: construct URL manually and try to get token from config
    if not url:
        url = f"http://127.0.0.1:{port}"
        try:
            import subprocess
            import re
            # Try to get token from container logs
            result = subprocess.run(
                ["docker", "logs", controller.docker.CONTAINER_NAME],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=5,
            )
            # Look for token in logs
            token_match = re.search(r'token=([a-f0-9]+)', result.stdout)
            if token_match:
                token = token_match.group(1)
                url = f"http://127.0.0.1:{port}/?token={token}"
        except Exception:
            pass
    
    if no_open:
        console.print(f"[cyan]{url}[/cyan]")
    else:
        console.print(f"[green]+ Opening:[/green] [cyan]{url}[/cyan]")
        controller._open_browser(url)
        console.print("\n[yellow]Note:[/yellow] If you see 'token mismatch' error:")
        console.print("   1. Run: [cyan]openclaw-secure dashboard --no-open[/cyan]")
        console.print("   2. Copy the full URL with token")
        console.print("   3. Paste it into your browser address bar")


@cli.command(context_settings=dict(ignore_unknown_options=True))
@click.argument("command", nargs=-1, required=True)
def exec(command: tuple) -> None:
    """
    EXEC Run OpenClaw CLI commands inside the secure container.
    
    This allows you to run OpenClaw CLI commands directly inside the running
    container. Useful for checking status, listing agents, etc.
    
    \b
    Examples:
        openclaw-secure exec agents list                # List agents
        openclaw-secure exec agents add my-agent        # Add an agent
        openclaw-secure exec --version                  # Check version
    
    For interactive commands (like onboard), use docker directly:
        docker exec -it openclaw-secure openclaw onboard
    """
    # Simple container check without full controller initialization
    container_name = "openclaw-secure"
    try:
        import subprocess
        check_result = subprocess.run(
            ["docker", "ps", "--filter", f"name={container_name}", "--format", "{{.Names}}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if container_name not in check_result.stdout:
            console.print("[red]X Secure container is not running.[/red]")
            console.print("   Run: [cyan]openclaw-secure enable[/cyan]")
            sys.exit(1)
    except Exception as e:
        console.print(f"[red]X Error checking container: {e}[/red]")
        sys.exit(1)
    
    # Build the command
    cmd_list = list(command)
    full_cmd = ["docker", "exec", container_name, "openclaw"] + cmd_list
    
    # Run the command directly without Rich console (avoids potential conflicts)
    try:
        result = subprocess.run(
            full_cmd,
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=60,
        )
        if result.stdout:
            print(result.stdout, end='')
        if result.stderr:
            print(result.stderr, file=sys.stderr, end='')
        sys.exit(result.returncode)
    except subprocess.TimeoutExpired:
        print("Error: Command timed out", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


@cli.command()
@click.option(
    "--approve",
    type=str,
    default=None,
    help="Approve a pending device by ID.",
)
@click.option(
    "--list", "list_devices",
    is_flag=True,
    help="List all devices and their status.",
)
def devices(approve: Optional[str], list_devices: bool) -> None:
    """
    DEV Manage device pairing for the secure container.
    
    When you first connect to the dashboard, your browser needs to be
    approved as a trusted device. Use this command to list pending
    devices and approve them.
    
    \b
    Examples:
        openclaw-secure devices --list                    # See all devices
        openclaw-secure devices --approve <device_id>     # Approve a device
    """
    controller = OpenClawSecureController()
    
    # Check if secure container is running
    if not controller.docker.is_container_running():
        console.print("[red]X Secure container is not running.[/red]")
        console.print("   Run: [cyan]openclaw-secure enable[/cyan]")
        sys.exit(1)
    
    if approve:
        # Approve a specific device
        console.print(f"[blue]Approving device: {approve}...[/blue]")
        try:
            import subprocess
            result = subprocess.run(
                ["docker", "exec", controller.docker.CONTAINER_NAME,
                 "openclaw", "devices", "approve", approve],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=10,
            )
            if result.returncode == 0:
                console.print(f"[green]+ Device {approve} approved[/green]")
            else:
                console.print(f"[red]X Failed to approve: {result.stderr}[/red]")
                sys.exit(1)
        except Exception as e:
            console.print(f"[red]X Error: {e}[/red]")
            sys.exit(1)
    elif list_devices:
        # List all devices
        console.print("[blue]Listing devices...[/blue]")
        try:
            import subprocess
            result = subprocess.run(
                ["docker", "exec", controller.docker.CONTAINER_NAME,
                 "openclaw", "devices", "list"],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=10,
            )
            # Print raw output to avoid unicode issues with Rich on Windows
            # Replace problematic unicode characters
            clean_stdout = result.stdout.encode('ascii', 'replace').decode('ascii')
            clean_stderr = result.stderr.encode('ascii', 'replace').decode('ascii') if result.stderr else ""
            print(clean_stdout)
            if clean_stderr:
                print(clean_stderr)
        except Exception as e:
            console.print(f"[red]X Error: {e}[/red]")
            sys.exit(1)
    else:
        # Default: show help
        console.print("[dim]Use --list to see devices or --approve <id> to approve[/dim]")
        console.print("\nTo manage devices, run one of:")
        console.print("  [cyan]openclaw-secure devices --list[/cyan]")
        console.print("  [cyan]openclaw-secure devices --approve <device_id>[/cyan]")


@cli.command()
def doctor() -> None:
    """
    CFG Diagnostic tool - check OpenClaw and Docker setup.

    Runs various checks to diagnose issues with:
    - Docker installation and permissions
    - OpenClaw installation
    - Config file integrity
    - Network connectivity
    """
    console.print(
        Panel.fit("[bold blue]CFG OPENCLAW-SECURE DOCTOR[/bold blue]", border_style="blue")
    )

    detector = OpenClawDetector()
    all_ok = True

    # Check 1: Docker
    console.print("\n[bold]1. Docker Check[/bold]")
    docker_check = detector.check_docker_available()

    if docker_check["available"] and docker_check["running"]:
        console.print(f"   [green]+[/green] Docker available (v{docker_check['version']})")
    elif docker_check["available"]:
        console.print("   [red]X[/red] Docker installed but not running")
        console.print("     Start Docker Desktop or: sudo systemctl start docker")
        all_ok = False
    else:
        console.print("   [red]X[/red] Docker not found")
        console.print("     Install: https://docs.docker.com/get-docker/")
        all_ok = False

    # Check 2: OpenClaw binary
    console.print("\n[bold]2. OpenClaw Binary Check[/bold]")
    binary = detector.find_openclaw_binary()

    if binary:
        console.print(f"   [green]+[/green] Found: {binary}")
    else:
        console.print("   [red]X[/red] openclaw command not found in PATH")
        console.print("     Install: https://docs.openclaw.ai/install")
        all_ok = False

    # Check 3: Config directory
    console.print("\n[bold]3. Config Directory Check[/bold]")
    config_dir = detector.get_config_dir()
    openclaw_json = detector.find_openclaw_json()

    if config_dir.exists():
        console.print(f"   [green]+[/green] Config directory found: {config_dir}")

        # Check for openclaw.json (main config file)
        if openclaw_json:
            console.print("     [green]+[/green] Found: openclaw.json")
        else:
            console.print(f"     [yellow]?[/yellow] openclaw.json not found in {config_dir}")
            console.print("       Run openclaw once to initialize config")

        # Check for other important directories
        important_dirs = ["credentials", "workspace", "agents"]
        for dirname in important_dirs:
            dirpath = config_dir / dirname
            if dirpath.exists():
                console.print(f"     [green]+[/green] Found: {dirname}/")
    else:
        console.print(f"   [yellow]?[/yellow] Config directory not found: {config_dir}")
        console.print("     Searched using find/locate commands")
        console.print("     Run openclaw once to initialize config")

    # Check 4: Port availability
    console.print("\n[bold]4. Port Check[/bold]")
    import socket

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(("127.0.0.1", 18789))
        sock.close()

        if result == 0:
            console.print("   [yellow]?[/yellow] Port 18789 is in use")
            console.print("     Something may already be running on this port")
        else:
            console.print("   [green]+[/green] Port 18789 is available")
    except Exception as e:
        console.print(f"   [red]X[/red] Could not check port: {e}")

    # Summary
    console.print("\n" + "=" * 50)
    if all_ok:
        console.print("[bold green]+ All checks passed![/bold green]")
        console.print("You can run: [cyan]openclaw-secure enable[/cyan]")
    else:
        console.print("[bold yellow]? Some checks failed[/bold yellow]")
        console.print("Please fix the issues above before enabling secure mode.")


def main() -> None:
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
