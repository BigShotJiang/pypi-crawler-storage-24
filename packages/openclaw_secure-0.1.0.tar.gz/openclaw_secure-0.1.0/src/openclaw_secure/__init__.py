"""
OpenClaw Secure - Secure mode switcher for OpenClaw.

Moves your existing OpenClaw installation into a sandboxed Docker container
while preserving all configuration, credentials, and history.
"""

__version__ = "0.1.0"
__author__ = "OpenClaw Secure Team"
__license__ = "MIT"
