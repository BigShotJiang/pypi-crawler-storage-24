# Development Setup

This guide shows how to run `openclaw-secure` locally from source code.

## Prerequisites

- Python 3.10+
- Docker Desktop
- Git

## Clone and Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/openclaw-secure.git
cd openclaw-secure

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Linux/Mac)
source venv/bin/activate

# Install in editable mode
pip install -e .

# Install development dependencies
pip install -e ".[dev]"
```

## Running Locally

After installation, the `openclaw-secure` command is available:

```bash
# Check it works
openclaw-secure --help

# Run in interactive mode
openclaw-secure enable

# Run with auto-confirmation
openclaw-secure enable --yes
```

## Project Structure

```
openclaw-secure/
├── src/
│   └── openclaw_secure/
│       ├── __init__.py
│       ├── cli.py           # CLI commands
│       ├── controller.py    # Main logic
│       ├── docker_backend.py # Docker operations
│       ├── detector.py      # Config detection
│       └── backup.py        # Backup management
├── tests/
├── pyproject.toml
├── README.md
├── setup.md
└── publish.md
```

## Development Workflow

```bash
# Make code changes
# ...

# Reinstall (if you change dependencies)
pip install -e .

# Test the command
openclaw-secure status

# Run tests (if you have tests)
pytest

# Type checking
mypy src/openclaw_secure

# Linting
ruff check src/openclaw_secure
```

## Testing Changes

1. **Make your changes** in `src/openclaw_secure/`

2. **Reinstall** if needed:
   ```bash
   pip install -e .
   ```

3. **Test the command**:
   ```bash
   # Stop any running container
   docker stop openclaw-secure
   docker rm openclaw-secure
   
   # Test enable
   openclaw-secure enable --yes --no-backup
   
   # Check status
   openclaw-secure status
   
   # Test disable
   openclaw-secure disable
   ```

## Debugging

Add debug output to the code:

```python
# In controller.py or other files
from rich.console import Console
console = Console()

console.print(f"[dim]Debug: config_dir = {config_dir}[/dim]")
```

Run with verbose output:
```bash
openclaw-secure enable 2>&1
```

## Building Package Locally

```bash
# Install build tools
pip install build twine

# Build package
python -m build

# Check the built package
twine check dist/*
```

## Uninstall Local Version

```bash
# Deactivate virtual environment
deactivate

# Remove virtual environment
rm -rf venv  # Linux/Mac
rmdir /s venv  # Windows

# Or uninstall from global Python
pip uninstall openclaw-secure
```

## Common Issues

### "Command not found"
Make sure virtual environment is activated.

### "Docker not available"
Start Docker Desktop first.

### Permission errors (Linux/Mac)
Add your user to docker group or use sudo.

### Config not found
Set `OPENCLAW_CONFIG_PATH` environment variable:
```bash
export OPENCLAW_CONFIG_PATH="/path/to/config"  # Linux/Mac
set OPENCLAW_CONFIG_PATH="C:\path\to\config"   # Windows
```
