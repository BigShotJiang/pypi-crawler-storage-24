"""Tests for controller module."""

from openclaw_secure.controller import OpenClawSecureController


class TestOpenClawSecureController:
    """Test cases for OpenClawSecureController."""

    def test_controller_initialization(self):
        """Test that controller initializes properly."""
        controller = OpenClawSecureController()
        assert controller is not None
        assert controller.detector is not None
        assert controller.docker is not None

    def test_get_status_structure(self):
        """Test that get_status returns expected structure."""
        controller = OpenClawSecureController()
        status = controller.get_status()

        assert isinstance(status, dict)
        assert "container_running" in status
        assert "local_running" in status
        assert "docker_available" in status
        assert isinstance(status["container_running"], bool)
        assert isinstance(status["local_running"], bool)

    def test_wait_for_port_release_invalid_port(self):
        """Test waiting for invalid port."""
        controller = OpenClawSecureController()
        # Port 0 is technically invalid for this use case
        # Should return False quickly
        result = controller._wait_for_port_release(0, timeout=1)
        # Result depends on implementation, but shouldn't crash
        assert isinstance(result, bool)
