"""Tests for Docker backend module."""

import tempfile
from pathlib import Path

from openclaw_secure.docker_backend import DockerBackend


class TestDockerBackend:
    """Test cases for DockerBackend."""

    def test_backend_initialization(self):
        """Test that backend initializes properly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = Path(tmpdir) / "config"
            workspace = Path(tmpdir) / "workspace"
            cache = Path(tmpdir) / "cache"

            backend = DockerBackend(config, workspace, cache)

            assert backend.config_dir == config
            assert backend.workspace_dir == workspace
            assert backend.cache_dir == cache
            assert backend.CONTAINER_NAME == "openclaw-secure"

    def test_is_container_running_no_docker(self):
        """Test container check when Docker isn't available."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = Path(tmpdir) / "config"
            workspace = Path(tmpdir) / "workspace"
            cache = Path(tmpdir) / "cache"

            backend = DockerBackend(config, workspace, cache)

            # Should return False when Docker isn't available
            result = backend.is_container_running()
            assert result is False
