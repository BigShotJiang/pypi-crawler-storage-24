"""Tests for OpenClaw detection module."""

from openclaw_secure.detector import OpenClawDetector


class TestOpenClawDetector:
    """Test cases for OpenClawDetector."""

    def test_detector_initialization(self):
        """Test that detector initializes properly."""
        detector = OpenClawDetector()
        assert detector is not None
        assert detector.system in ["Linux", "Darwin", "Windows"]

    def test_find_openclaw_binary(self):
        """Test finding OpenClaw binary."""
        detector = OpenClawDetector()
        # May or may not find it depending on test environment
        binary = detector.find_openclaw_binary()
        # Just verify it doesn't crash
        assert binary is None or isinstance(binary, str)

    def test_get_config_dir(self):
        """Test config directory detection."""
        detector = OpenClawDetector()
        config_dir = detector.get_config_dir()
        assert config_dir is not None
        # Config dir name could be '.openclaw' or 'openclaw'
        assert "openclaw" in config_dir.name

    def test_get_workspace_dir(self):
        """Test workspace directory detection."""
        detector = OpenClawDetector()
        workspace_dir = detector.get_workspace_dir()
        assert workspace_dir is not None
        assert workspace_dir.name == "workspace"

    def test_get_cache_dir(self):
        """Test cache directory detection."""
        detector = OpenClawDetector()
        cache_dir = detector.get_cache_dir()
        assert cache_dir is not None
        # Cache dir should be in a cache location (parent path contains 'cache')
        assert "cache" in str(cache_dir).lower()

    def test_check_docker_available(self):
        """Test Docker availability check."""
        detector = OpenClawDetector()
        result = detector.check_docker_available()

        assert "available" in result
        assert "running" in result
        assert "version" in result
        assert "errors" in result
        assert isinstance(result["available"], bool)
