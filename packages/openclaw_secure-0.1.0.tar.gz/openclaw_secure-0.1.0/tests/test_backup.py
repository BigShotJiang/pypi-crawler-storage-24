"""Tests for backup module."""

import tempfile
from pathlib import Path

from openclaw_secure.backup import ConfigBackup


class TestConfigBackup:
    """Test cases for ConfigBackup."""

    def test_backup_initialization(self):
        """Test backup manager initialization."""
        with tempfile.TemporaryDirectory() as tmpdir:
            backup = ConfigBackup(Path(tmpdir))
            assert backup.config_dir == Path(tmpdir)
            assert backup.backup_dir.exists()

    def test_find_valuable_files_empty(self):
        """Test finding files in empty directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            backup = ConfigBackup(Path(tmpdir))
            files = backup._find_valuable_files()
            assert files == []

    def test_find_valuable_files_with_config(self):
        """Test finding files with config present."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            # Create a settings file
            (config_dir / "settings.json").write_text('{"test": true}')

            backup = ConfigBackup(config_dir)
            files = backup._find_valuable_files()

            assert len(files) > 0
            assert any("settings.json" in str(f[1]) for f in files)

    def test_is_excluded(self):
        """Test exclusion logic."""
        with tempfile.TemporaryDirectory() as tmpdir:
            backup = ConfigBackup(Path(tmpdir))

            # Cache should be excluded
            assert backup._is_excluded(Path("/path/to/.cache/file")) is True
            # Logs should be excluded
            assert backup._is_excluded(Path("/path/to/logs/file.log")) is True
            # Normal files should not be excluded
            assert backup._is_excluded(Path("/path/to/settings.json")) is False

    def test_list_backups_empty(self):
        """Test listing backups when none exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            backup = ConfigBackup(Path(tmpdir))
            backups = backup.list_backups()
            assert backups == []

    def test_verify_backup_integrity_nonexistent(self):
        """Test verifying non-existent backup."""
        with tempfile.TemporaryDirectory() as tmpdir:
            backup = ConfigBackup(Path(tmpdir))
            result = backup.verify_backup_integrity(Path("/nonexistent/file.tar.gz"))
            assert result is False
