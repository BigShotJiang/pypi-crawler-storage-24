# Publishing to PyPI

This guide shows how to publish `openclaw-secure` to PyPI.

## Prerequisites

- PyPI account: https://pypi.org/account/register/
- API token from PyPI (recommended over password)
- Project configured in `pyproject.toml`

## Setup

### 1. Install Build Tools

```bash
pip install build twine
```

### 2. Configure PyPI Credentials

**Option A: Using .pypirc file**

Create `~/.pypirc` (Linux/Mac) or `%USERPROFILE%\.pypirc` (Windows):

```ini
[pypi]
username = __token__
password = pypi-your-api-token-here
```

**Option B: Using environment variable**

```bash
export PYPI_API_TOKEN="pypi-your-api-token-here"
```

## Build and Publish

### Step 1: Update Version

Edit `pyproject.toml` and bump the version:

```toml
[project]
version = "0.1.1"  # Increment this
```

### Step 2: Clean Old Builds

```bash
# Remove old build artifacts
rm -rf dist/ build/ *.egg-info  # Linux/Mac
del /s /q dist\ build\ *.egg-info  # Windows
```

### Step 3: Build Package

```bash
python -m build
```

This creates:
- `dist/openclaw_secure-0.1.1.tar.gz` (source distribution)
- `dist/openclaw_secure-0.1.1-py3-none-any.whl` (wheel)

### Step 4: Verify Build

```bash
twine check dist/*
```

Should output:
```
Checking dist/openclaw_secure-0.1.1-py3-none-any.whl: PASSED
Checking dist/openclaw_secure-0.1.1.tar.gz: PASSED
```

### Step 5: Test on TestPyPI (Optional but Recommended)

```bash
twine upload --repository testpypi dist/*
```

Test installation:
```bash
pip install --index-url https://test.pypi.org/simple/ openclaw-secure
```

### Step 6: Publish to PyPI

```bash
twine upload dist/*
```

Or with explicit credentials:
```bash
twine upload -u __token__ -p $PYPI_API_TOKEN dist/*
```

## Verify Installation

After publishing, test the public package:

```bash
# Create fresh environment
python -m venv test_env
source test_env/bin/activate  # or test_env\Scripts\activate on Windows

# Install from PyPI
pip install openclaw-secure

# Test
openclaw-secure --version
openclaw-secure --help
```

## Publishing with pipx (for users)

Once published, users can install with:

```bash
# Install with pipx (recommended)
pipx install openclaw-secure

# Upgrade
pipx upgrade openclaw-secure

# Uninstall
pipx uninstall openclaw-secure
```

## GitHub Actions (Automated Publishing)

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    
    - name: Build package
      run: python -m build
    
    - name: Publish to PyPI
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: twine upload dist/*
```

Add `PYPI_API_TOKEN` to GitHub repository secrets.

## Versioning Guide

Follow semantic versioning (MAJOR.MINOR.PATCH):

- **MAJOR**: Breaking changes (1.0.0)
- **MINOR**: New features, backwards compatible (0.2.0)
- **PATCH**: Bug fixes (0.1.1)

## Troubleshooting

### "File already exists"
Version wasn't bumped. Update version in `pyproject.toml`.

### "Invalid API Token"
- Make sure you're using `__token__` as username
- Token must have "Upload" scope

### "Metadata validation failed"
Run `twine check dist/*` and fix any issues.

### Package not found after upload
Wait 5-10 minutes for PyPI CDN to propagate.

## Release Checklist

- [ ] Version bumped in `pyproject.toml`
- [ ] `CHANGELOG.md` updated (if you have one)
- [ ] README.md is current
- [ ] Tests pass
- [ ] Build succeeds (`python -m build`)
- [ ] Package passes check (`twine check dist/*`)
- [ ] Published to PyPI (`twine upload dist/*`)
- [ ] Installation tested (`pip install openclaw-secure`)
- [ ] Git tag created (`git tag v0.1.1`)
- [ ] Git tag pushed (`git push origin v0.1.1`)
