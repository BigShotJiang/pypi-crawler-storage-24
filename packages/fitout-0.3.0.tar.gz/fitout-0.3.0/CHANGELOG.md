# Changelog

## v0.3.0 (2026-03-21)

#### New Features

* (importers): add weight info importer and tests
* (importers): add exercise info importer and tests
#### Fixes

* (doc): Adding requirements files, to help developers.

Full set of changes: [`v0.2.0...v0.3.0`](https://github.com/kev-m/FitOut/compare/v0.2.0...v0.3.0)

## v0.2.0 (2026-03-20)

#### New Features

* (heartrate): Caching files to speed up reading of heart-rate data.
* (core): add get_raw_sessions to BaseImporter as abstract method
* (sleep): add get_raw_sessions to extract all sleep events including naps
#### Fixes

* (doc): Updating documentation to reflect using ZIP files directly.

Full set of changes: [`v0.1.1...v0.2.0`](https://github.com/kev-m/FitOut/compare/v0.1.1...v0.2.0)

## v0.1.1 (2024-11-25)

#### Fixes

* Fixed bug with importers directory being in the wrong location.

Full set of changes: [`v0.1.0...v0.1.1`](https://github.com/kev-m/FitOut/compare/v0.1.0...v0.1.1)

## v0.1.0 (2024-11-21)

#### New Features

* Added basic support for heart rate reporting.

Full set of changes: [`v0.0.10...v0.1.0`](https://github.com/kev-m/FitOut/compare/v0.0.10...v0.1.0)

## v0.0.10 (2024-11-20)

#### Fixes

* Handling missing data at the end of the list.
* Handle gaps in the resting heart rate data.
* Fixing runtime error in the plotting example.
* Fixing Takeout URLs, compatible with the ZIP file handler.
* Fixing Takeout URLs, compatible with the ZIP file handler.

Full set of changes: [`v0.0.9...v0.0.10`](https://github.com/kev-m/FitOut/compare/v0.0.9...v0.0.10)

## v0.0.9 (2024-11-16)

#### Fixes

* Adding ZIP-file support.

Full set of changes: [`v0.0.8...v0.0.9`](https://github.com/kev-m/FitOut/compare/v0.0.8...v0.0.9)

## v0.0.8 (2024-11-15)

#### Fixes

* Documenting API and minor bugfixes.

Full set of changes: [`v0.0.7...v0.0.8`](https://github.com/kev-m/FitOut/compare/v0.0.7...v0.0.8)

## v0.0.7 (2024-11-13)

#### Fixes

* Add sleep summary data.

Full set of changes: [`v0.0.6...v0.0.7`](https://github.com/kev-m/FitOut/compare/v0.0.6...v0.0.7)

## v0.0.6 (2024-11-13)

#### Fixes

* Implement changes to support basic sleep reporting
* Trivial splitting functionality into files

Full set of changes: [`v0.0.5...v0.0.6`](https://github.com/kev-m/FitOut/compare/v0.0.5...v0.0.6)

## v0.0.5 (2024-11-10)

#### Fixes

* Adding some data cleanup routines.

Full set of changes: [`v0.0.4...v0.0.5`](https://github.com/kev-m/FitOut/compare/v0.0.4...v0.0.5)

## v0.0.4 (2024-11-10)

#### Fixes

* Improving detectin of JSON files for resting heart rate.

Full set of changes: [`v0.0.3...v0.0.4`](https://github.com/kev-m/FitOut/compare/v0.0.3...v0.0.4)

## v0.0.3 (2024-11-09)

#### Fixes

* Various bug fixes

Full set of changes: [`v0.0.2...v0.0.3`](https://github.com/kev-m/FitOut/compare/v0.0.2...v0.0.3)

## v0.0.2 (2024-11-09)

#### Fixes

* Fixing instructions.

Full set of changes: [`v0.0.1...v0.0.2`](https://github.com/kev-m/FitOut/compare/v0.0.1...v0.0.2)

## v0.0.1 (2024-11-09)

#### Fixes

* Initial commit.
