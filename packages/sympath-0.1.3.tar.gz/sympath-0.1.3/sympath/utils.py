"""Utility helpers for Sympath."""

import os
from pathlib import Path

# Extensions considered executable on Windows.
# Empty string catches extensionless binaries on Unix.
EXECUTABLE_EXTENSIONS = {".exe", ".cmd", ".bat", ".ps1", ".sh", ""}


def is_executable(path: Path) -> bool:
    """Return True if *path* looks like an executable."""
    if os.name == "nt":
        return path.suffix.lower() in EXECUTABLE_EXTENSIONS
    return os.access(path, os.X_OK)
