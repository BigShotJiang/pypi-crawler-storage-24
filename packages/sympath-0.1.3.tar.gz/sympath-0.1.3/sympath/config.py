"""Configuration loading and persistence for Sympath."""

import json
from pathlib import Path

CONFIG_PATH = Path.home() / ".sympath.json"

DEFAULT_CONFIG = {
    "default": None,
    "folders": {},
}


def load_config() -> dict:
    """Load configuration from disk, or return defaults."""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return dict(DEFAULT_CONFIG)


def save_config(cfg: dict) -> None:
    """Persist configuration to disk."""
    CONFIG_PATH.parent.mkdir(exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
