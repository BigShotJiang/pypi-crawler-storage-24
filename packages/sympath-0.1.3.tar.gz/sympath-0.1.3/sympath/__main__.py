"""Allow running sympath as ``python -m sympath``."""

from sympath.cli import main

main()
