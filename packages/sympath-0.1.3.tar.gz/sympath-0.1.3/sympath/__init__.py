"""Sympath — a powerful symlink-based path manager."""

__version__ = "0.1.0"
