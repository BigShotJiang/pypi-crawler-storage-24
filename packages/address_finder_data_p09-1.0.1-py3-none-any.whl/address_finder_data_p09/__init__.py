import importlib.resources as _ir
from pathlib import Path as _P

# Chunk metadata
CANONICAL_NAME = 'transliteration.dat'
FILE_CHUNK_INDEX = 0
TOTAL_FILE_CHUNKS = 1
CHUNK_SHA256 = '3ae09bd7fed21c0dadf49ffdb1a7f797d8516deddcecf30b3c0392d5cd89a12a'
FILE_ORIGINAL_SIZE = 19570085

def chunk_path() -> _P:
    """Return path to the raw compressed chunk file."""            try:
        ref = _ir.files(__name__) / "data" / "chunk.bin"
        return _P(str(ref))
    except AttributeError:
        import pkg_resources
        return _P(pkg_resources.resource_filename(__name__, "data/chunk.bin"))
