"""Jinja2 template rendering for quber-workflow."""

from pathlib import Path
from typing import Dict

import jinja2


class TemplateRenderer:
    """Handles Jinja2 template rendering for workflow files."""

    def __init__(self, template_dir: Path):
        """Initialize renderer with template directory.

        Args:
            template_dir: Path to directory containing Jinja2 templates
        """
        self.template_dir = template_dir
        self.env = jinja2.Environment(
            loader=jinja2.FileSystemLoader(str(template_dir)),
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True,
        )

    def render_template(self, template_path: str, context: Dict) -> str:
        """Render a single template file.

        Args:
            template_path: Relative path to template file within template_dir
            context: Template context dictionary

        Returns:
            Rendered template content
        """
        template = self.env.get_template(template_path)
        return template.render(**context)

    def render_to_file(
        self, template_path: str, output_path: Path, context: Dict
    ) -> None:
        """Render template and write to output file.

        Args:
            template_path: Relative path to template file within template_dir
            output_path: Path where rendered file should be written
            context: Template context dictionary
        """
        content = self.render_template(template_path, context)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content)
