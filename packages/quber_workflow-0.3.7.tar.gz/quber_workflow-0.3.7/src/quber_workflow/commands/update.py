"""Update quber workflow files to latest version."""

from pathlib import Path

from rich.console import Console
from rich.prompt import Confirm

from ..config import WorkflowConfig

console = Console()


def run_update() -> None:
    """Update workflow files to the latest version from the package.

    Reads saved config from .claude/.quber-workflow.yaml, then re-renders
    all templates and re-copies all static files. Also refreshes devcontainer
    files if .devcontainer/ exists.
    """
    target = Path.cwd()
    config_path = target / ".claude" / ".quber-workflow.yaml"

    if not config_path.exists():
        console.print("[bold red]No .claude/.quber-workflow.yaml found![/bold red]")
        console.print("Run [cyan]quber-workflow init[/cyan] first.")
        return

    config = WorkflowConfig.from_yaml(config_path)

    console.print(f"[dim]Project: {config.project_name} ({config.repo_name})[/dim]")
    if not Confirm.ask("Update workflow files to latest version?"):
        console.print("[yellow]Update cancelled[/yellow]")
        return

    from .init import run_init

    run_init(config)

    # Also refresh devcontainer files if they exist
    devcontainer_dir = target / ".devcontainer"
    if devcontainer_dir.exists():
        console.print("\n[bold yellow]Updating devcontainer files...[/bold yellow]")
        from .devcontainer import run_devcontainer

        run_devcontainer(config)
