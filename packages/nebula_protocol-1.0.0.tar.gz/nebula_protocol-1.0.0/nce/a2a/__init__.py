"""A2A protocol integration."""
