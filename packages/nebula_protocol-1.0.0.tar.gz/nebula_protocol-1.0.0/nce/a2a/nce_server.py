"""NCE-aware A2A server wrapper."""

from __future__ import annotations

import logging

from nce.crdt.composite_state import StateDelta
from nce.crdt.vector_clock import VectorClock
from nce.sync.state_bus import StateBus

logger = logging.getLogger(__name__)


class NCEServer:
    """A2A server extended with NCE state sync capabilities.

    Provides the server-side handlers for NCE delta push/pull endpoints.
    Intended to be wired into a FastAPI router or similar ASGI framework.
    """

    def __init__(self, state_bus: StateBus) -> None:
        """Initialize the NCE server.

        Args:
            state_bus: Local state bus for this agent node.
        """
        self._bus = state_bus

    async def handle_push(self, delta: StateDelta) -> dict[str, object]:
        """Handle an incoming delta push from a client.

        Applies the delta through the causal barrier and returns an
        acknowledgement with the updated local vector clock.

        Args:
            delta: The StateDelta pushed by the client.

        Returns:
            Dict with ``status`` and the local ``vector_clock`` after merge.
        """
        await self._bus.receive_delta(delta)
        local_vc = self._bus.query_state().vector_clock
        logger.debug("NCEServer received delta from %s", delta.origin_agent)
        return {"status": "ok", "vector_clock": local_vc.model_dump()}

    async def handle_pull(self, since_vc: VectorClock) -> dict[str, object]:
        """Handle a delta pull request from a client.

        Extracts local mutations since the client's last known VC and
        returns them as a delta payload.

        Args:
            since_vc: The client's last known vector clock.

        Returns:
            Dict with the outbound StateDelta.
        """
        delta = self._bus.extract_delta_since(since_vc)
        return {"delta": delta.model_dump(mode="json")}

    async def handle_sync(
        self,
        from_agent: str,
        peer_vc: VectorClock,
        inbound_delta: StateDelta,
    ) -> dict[str, object]:
        """Handle a bidirectional gossip sync request.

        Applies the inbound delta and returns the local delta since peer_vc.

        Args:
            from_agent: ID of the requesting agent.
            peer_vc: The peer's last known vector clock (for outbound delta).
            inbound_delta: The delta pushed by the peer.

        Returns:
            Dict with the outbound ``delta`` for the peer.
        """
        await self._bus.receive_delta(inbound_delta)
        outbound = self._bus.extract_delta_since(peer_vc)
        logger.debug("NCEServer sync with %s", from_agent)
        return {"delta": outbound.model_dump(mode="json")}
