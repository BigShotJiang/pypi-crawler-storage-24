"""NCE-aware A2A client wrapper."""

from __future__ import annotations

import logging

import httpx

from nce.crdt.composite_state import StateDelta
from nce.crdt.vector_clock import VectorClock
from nce.sync.state_bus import StateBus

logger = logging.getLogger(__name__)


class NCEClient:
    """A2A client extended with NCE state sync capabilities.

    Wraps a StateBus and provides methods to push/pull deltas with
    a remote NCE-capable A2A server.  Actual A2A task invocation is
    stubbed - the focus is the NCE state layer.
    """

    def __init__(self, state_bus: StateBus, server_endpoint: str) -> None:
        """Initialize the NCE client.

        Args:
            state_bus: Local state bus for this agent.
            server_endpoint: Base URL of the remote NCE/A2A server.
        """
        self._bus = state_bus
        self._server = server_endpoint.rstrip("/")
        self._remote_vc: VectorClock = VectorClock()

    async def push_delta(self) -> bool:
        """Push the local delta (since last known remote VC) to the server.

        Returns:
            True if the push succeeded, False on error.
        """
        delta = self._bus.extract_delta_since(self._remote_vc)
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(
                    f"{self._server}/nce/delta",
                    json=delta.model_dump(mode="json"),
                )
                resp.raise_for_status()
                self._remote_vc = delta.to_vc
                return True
        except Exception as exc:
            logger.warning("NCEClient push_delta failed: %s", exc)
            return False

    async def pull_delta(self) -> StateDelta | None:
        """Pull the remote delta since our current vector clock.

        Returns:
            StateDelta from the server, or None on error.
        """
        local_vc = self._bus.query_state().vector_clock
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(
                    f"{self._server}/nce/delta",
                    params={"since": local_vc.model_dump_json()},
                )
                resp.raise_for_status()
                delta = StateDelta.model_validate(resp.json())
                await self._bus.receive_delta(delta)
                return delta
        except Exception as exc:
            logger.warning("NCEClient pull_delta failed: %s", exc)
            return None

    async def sync(self) -> bool:
        """Perform a full bidirectional sync with the server.

        Returns:
            True if both push and pull succeeded.
        """
        pushed = await self.push_delta()
        pulled = await self.pull_delta()
        return pushed and pulled is not None
