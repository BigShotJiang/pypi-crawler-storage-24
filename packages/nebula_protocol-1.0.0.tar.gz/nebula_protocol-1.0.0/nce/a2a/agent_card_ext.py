"""NCE extension for Agent Cards."""

from __future__ import annotations

from pydantic import BaseModel, Field


class NCEExtension(BaseModel):
    """NCE protocol extension fields for A2A Agent Cards.

    Agents that support NCE advertise this extension in their card so
    peers can discover compatible sync capabilities.
    """

    version: str = "0.1.0"
    crdt_types: list[str] = Field(
        default_factory=lambda: [
            "VectorClock",
            "TaskStatus",
            "ObservedBeliefRegister",
            "CapabilitySet",
        ]
    )
    sync_interval_ms: int = 500
    compliance_mode: str = "article12"

    model_config = {"frozen": True}


_NCE_EXTENSION_KEY = "nce"


def extend_agent_card(card: dict[str, object], config: NCEExtension) -> dict[str, object]:
    """Add the NCE extension to an existing A2A Agent Card.

    Merges the NCE extension into the card's ``extensions`` dict (or
    creates it if absent), leaving all other card fields untouched.

    Args:
        card: Existing A2A Agent Card as a plain dict.
        config: NCEExtension configuration to embed.

    Returns:
        New card dict with the NCE extension added.
    """
    updated = dict(card)
    raw_ext = updated.get("extensions", {})
    extensions: dict[str, object] = dict(raw_ext) if isinstance(raw_ext, dict) else {}
    extensions[_NCE_EXTENSION_KEY] = config.model_dump()
    updated["extensions"] = extensions
    return updated


def has_nce_support(card: dict[str, object]) -> bool:
    """Check whether an Agent Card declares NCE support.

    Args:
        card: A2A Agent Card as a plain dict.

    Returns:
        True if the card contains a valid NCE extension.
    """
    extensions = card.get("extensions", {})
    if not isinstance(extensions, dict):
        return False
    return _NCE_EXTENSION_KEY in extensions


def get_nce_config(card: dict[str, object]) -> NCEExtension | None:
    """Extract the NCEExtension from an Agent Card, if present.

    Args:
        card: A2A Agent Card as a plain dict.

    Returns:
        NCEExtension instance, or None if not present.
    """
    extensions = card.get("extensions", {})
    if not isinstance(extensions, dict):
        return None
    nce_data = extensions.get(_NCE_EXTENSION_KEY)
    if not isinstance(nce_data, dict):
        return None
    return NCEExtension.model_validate(nce_data)
