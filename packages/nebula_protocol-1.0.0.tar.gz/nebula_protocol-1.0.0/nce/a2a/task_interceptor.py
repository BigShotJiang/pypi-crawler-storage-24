"""Intercept A2A task lifecycle events."""

from __future__ import annotations

import logging
from typing import Any

from nce.crdt.observation_proof import ObservationProof
from nce.crdt.task_status import StatusLevel
from nce.sync.state_bus import StateBus

logger = logging.getLogger(__name__)


class TaskInterceptor:
    """Maps A2A task lifecycle events to CRDT state updates.

    Wraps a StateBus and translates high-level A2A task events
    (submit, update, complete, fail) into CRDT merge operations.
    This is the bridge between the A2A protocol and NCE state.
    """

    def __init__(self, state_bus: StateBus) -> None:
        """Initialize with a shared StateBus.

        Args:
            state_bus: The shared state bus for this agent node.
        """
        self._bus = state_bus

    async def on_task_submit(
        self,
        task_id: str,
        metadata: dict[str, str] | None = None,
    ) -> None:
        """Handle a task submission (sets status to PENDING).

        Args:
            task_id: The A2A task ID.
            metadata: Optional metadata from the task submission.
        """
        await self._bus.update_task(
            task_id=task_id,
            status=StatusLevel.PENDING,
            metadata=metadata,
        )
        logger.debug("Task %s: PENDING", task_id)

    async def on_task_assign(
        self,
        task_id: str,
        metadata: dict[str, str] | None = None,
    ) -> None:
        """Handle task assignment (sets status to ASSIGNED).

        Args:
            task_id: The A2A task ID.
            metadata: Optional assignment metadata.
        """
        await self._bus.update_task(
            task_id=task_id,
            status=StatusLevel.ASSIGNED,
            metadata=metadata,
        )
        logger.debug("Task %s: ASSIGNED", task_id)

    async def on_task_start(
        self,
        task_id: str,
        metadata: dict[str, str] | None = None,
    ) -> None:
        """Handle task start (sets status to IN_PROGRESS).

        Args:
            task_id: The A2A task ID.
            metadata: Optional metadata.
        """
        await self._bus.update_task(
            task_id=task_id,
            status=StatusLevel.IN_PROGRESS,
            metadata=metadata,
        )
        logger.debug("Task %s: IN_PROGRESS", task_id)

    async def on_task_status_update(
        self,
        task_id: str,
        status: StatusLevel,
        observation: ObservationProof | None = None,
        metadata: dict[str, str] | None = None,
    ) -> None:
        """Handle an arbitrary task status update.

        Args:
            task_id: The A2A task ID.
            status: New StatusLevel.
            observation: Optional ObservationProof for provenance.
            metadata: Optional metadata.
        """
        await self._bus.update_task(
            task_id=task_id,
            status=status,
            observation=observation,
            metadata=metadata,
        )

    async def on_task_complete(
        self,
        task_id: str,
        result: Any | None = None,
        observation: ObservationProof | None = None,
    ) -> None:
        """Handle successful task completion (sets status to COMPLETED).

        Args:
            task_id: The A2A task ID.
            result: Optional result payload (stored in metadata as JSON string).
            observation: Optional ObservationProof of the completion state.
        """
        import json

        meta = {"result": json.dumps(result, default=str)} if result is not None else None
        await self._bus.update_task(
            task_id=task_id,
            status=StatusLevel.COMPLETED,
            observation=observation,
            metadata=meta,
        )
        logger.debug("Task %s: COMPLETED", task_id)

    async def on_task_fail(
        self,
        task_id: str,
        error: str | None = None,
        observation: ObservationProof | None = None,
    ) -> None:
        """Handle task failure (sets status to FAILED).

        Args:
            task_id: The A2A task ID.
            error: Optional error description (stored in metadata).
            observation: Optional ObservationProof for audit trail.
        """
        meta = {"error": error} if error else None
        await self._bus.update_task(
            task_id=task_id,
            status=StatusLevel.FAILED,
            observation=observation,
            metadata=meta,
        )
        logger.debug("Task %s: FAILED - %s", task_id, error)

    async def on_task_cancel(
        self,
        task_id: str,
        reason: str | None = None,
    ) -> None:
        """Handle task cancellation (sets status to CANCELLED).

        Args:
            task_id: The A2A task ID.
            reason: Optional cancellation reason (stored in metadata).
        """
        meta = {"reason": reason} if reason else None
        await self._bus.update_task(
            task_id=task_id,
            status=StatusLevel.CANCELLED,
            metadata=meta,
        )
        logger.debug("Task %s: CANCELLED - %s", task_id, reason)
