"""JSON serialization for CRDTs."""

import json
from datetime import datetime
from typing import Any


def _default_encoder(obj: Any) -> Any:
    """JSON encoder for types not natively serializable."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, set):
        return sorted(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def to_json(obj: Any) -> str:
    """Serialize object to compact canonical JSON string.

    Args:
        obj: JSON-serializable object (supports datetime and set).

    Returns:
        Compact JSON string with sorted keys.
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=_default_encoder)


def from_json(data: str) -> Any:
    """Deserialize JSON string.

    Args:
        data: JSON string.

    Returns:
        Deserialized Python object.
    """
    return json.loads(data)


def model_to_canonical(model: Any) -> str:
    """Convert a Pydantic model to a canonical JSON string for hashing.

    Args:
        model: Pydantic BaseModel instance.

    Returns:
        Canonical JSON string suitable for hashing.
    """
    return to_json(model.model_dump(mode="json"))
