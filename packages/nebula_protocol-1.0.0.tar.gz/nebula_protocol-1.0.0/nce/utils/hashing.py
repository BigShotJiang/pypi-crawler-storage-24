"""SHA-256 + HMAC helpers."""

import hashlib
import hmac
import json
from typing import Any


def sha256_hex(data: str | bytes) -> str:
    """Compute SHA-256 hash, returning hex digest.

    Args:
        data: String or bytes to hash.

    Returns:
        Lowercase hex string of SHA-256 digest.
    """
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def sha256_json(obj: Any) -> str:
    """Compute SHA-256 hash of a JSON-serializable object.

    Args:
        obj: Any JSON-serializable Python object.

    Returns:
        Lowercase hex string of SHA-256 digest.
    """
    serialized = json.dumps(obj, sort_keys=True, separators=(",", ":"))
    return sha256_hex(serialized)


def hmac_sha256(secret: str, message: str) -> str:
    """Compute HMAC-SHA256 signature.

    Args:
        secret: Secret key as string.
        message: Message to sign as string.

    Returns:
        Lowercase hex string of HMAC-SHA256 digest.
    """
    return hmac.new(
        secret.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def verify_hmac_sha256(secret: str, message: str, signature: str) -> bool:
    """Verify an HMAC-SHA256 signature using constant-time comparison.

    Args:
        secret: Secret key as string.
        message: Original message as string.
        signature: Expected signature hex string.

    Returns:
        True if signature is valid, False otherwise.
    """
    expected = hmac_sha256(secret, message)
    return hmac.compare_digest(expected, signature)
