"""State bus pub/sub coordinator."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from nce.crdt.belief_register import ObservedBeliefRegister
from nce.crdt.composite_state import CompositeState, StateDelta
from nce.crdt.observation_proof import ObservationProof
from nce.crdt.task_status import StatusLevel, TaskStatus
from nce.crdt.vector_clock import VectorClock
from nce.sync.causal_barrier import CausalBarrier
from nce.sync.delta_engine import DeltaEngine
from nce.sync.gossip import GossipProtocol
from nce.utils.hashing import sha256_hex

logger = logging.getLogger(__name__)


class StateBus:
    """Main coordination layer for NCE state management.

    Ties together DeltaEngine, CausalBarrier, GossipProtocol, and
    (optionally) a FlightRecorder for EU AI Act Article 12 logging.
    All mutating operations increment the agent's vector clock.
    """

    def __init__(
        self,
        agent_id: str,
        sync_interval_ms: int = 500,
        flight_recorder: Any | None = None,
    ) -> None:
        """Initialize the state bus for a single agent.

        Args:
            agent_id: Unique identifier for this agent node.
            sync_interval_ms: Gossip sync interval in milliseconds.
            flight_recorder: Optional FlightRecorder for compliance logging.
        """
        self._agent_id = agent_id
        self._state = CompositeState(agent_id=agent_id)
        self._barrier = CausalBarrier()
        self._gossip = GossipProtocol(sync_interval_ms=sync_interval_ms)
        self._engine = DeltaEngine()
        self._flight_recorder = flight_recorder
        self._lock = asyncio.Lock()

    # ── State Mutations ────────────────────────────────────────────────────

    async def update_task(
        self,
        task_id: str,
        status: StatusLevel,
        observation: ObservationProof | None = None,
        metadata: dict[str, str] | None = None,
    ) -> None:
        """Update a task's status using the CRDT merge.

        Args:
            task_id: ID of the task to update.
            status: New StatusLevel to set.
            observation: Optional ObservationProof for provenance.
            metadata: Optional key-value metadata to attach.
        """
        async with self._lock:
            new_vc = self._state.vector_clock.increment(self._agent_id)
            task = TaskStatus(
                task_id=task_id,
                status=status,
                assigned_agent=self._agent_id,
                observation_proof=observation,
                vector_clock=new_vc,
                metadata=metadata or {},
            )
            if task_id in self._state.tasks:
                merged = self._state.tasks[task_id].merge(task)
                self._state.tasks[task_id] = merged
            else:
                self._state.tasks[task_id] = task
            self._state.vector_clock = new_vc

            if self._flight_recorder:
                old_task = self._state.tasks.get(task_id)
                self._flight_recorder.record_state_mutation(
                    event_type="task_update",
                    state_before_hash=sha256_hex(str(old_task.status) if old_task else "None"),
                    state_after_hash=sha256_hex(str(status)),
                    vector_clock=new_vc,
                    observation_proof=observation,
                    task_id=task_id,
                    status=str(status),
                )

    async def update_belief(
        self,
        key: str,
        value: Any,
        observation: ObservationProof | None = None,
    ) -> None:
        """Update a belief register using the CRDT merge.

        Args:
            key: Belief key (e.g., ``"inventory:SKU-001"``).
            value: New value (any JSON-compatible type).
            observation: Optional ObservationProof for provenance.
        """
        async with self._lock:
            new_vc = self._state.vector_clock.increment(self._agent_id)
            old_belief = self._state.beliefs.get(key)
            belief = ObservedBeliefRegister(
                key=key,
                value=value,
                write_vc=new_vc,
                vector_clock=new_vc,
                observation_proof=observation,
                updated_by=self._agent_id,
            )
            if key in self._state.beliefs:
                merged = self._state.beliefs[key].merge(belief)
                self._state.beliefs[key] = merged
            else:
                self._state.beliefs[key] = belief
            self._state.vector_clock = new_vc

            if self._flight_recorder:
                state_before = str(old_belief.value) if old_belief else "None"
                state_after = str(value)
                self._flight_recorder.record_state_mutation(
                    event_type="belief_update",
                    state_before_hash=sha256_hex(state_before),
                    state_after_hash=sha256_hex(state_after),
                    vector_clock=new_vc,
                    observation_proof=observation,
                    key=key,
                )

    async def add_capability(self, capability: str) -> None:
        """Add a capability to the OR-Set.

        Args:
            capability: Capability string to add.
        """
        async with self._lock:
            self._state.capabilities = self._state.capabilities.add(capability)

    async def remove_capability(self, capability: str) -> None:
        """Remove a capability from the OR-Set.

        Args:
            capability: Capability string to remove.
        """
        async with self._lock:
            self._state.capabilities = self._state.capabilities.remove(capability)

    # ── State Queries ──────────────────────────────────────────────────────

    def query_state(self) -> CompositeState:
        """Return a snapshot of the current composite state.

        Returns:
            The current CompositeState (not a copy - treat as read-only).
        """
        return self._state

    def get_belief(self, key: str) -> Any:
        """Get the current value of a belief register.

        Args:
            key: Belief key to query.

        Returns:
            The current value, or None if not yet observed.
        """
        belief = self._state.beliefs.get(key)
        return belief.value if belief else None

    def get_task(self, task_id: str) -> TaskStatus | None:
        """Get the current status of a task.

        Args:
            task_id: Task ID to query.

        Returns:
            TaskStatus or None if task not known.
        """
        return self._state.tasks.get(task_id)

    # ── Delta Sync ─────────────────────────────────────────────────────────

    async def receive_delta(self, delta: StateDelta) -> None:
        """Process an incoming delta through the causal barrier.

        Validates ObservationProof signatures, then buffers out-of-order deltas
        and applies them in causal order.

        Args:
            delta: Incoming StateDelta from a peer.
        """
        for belief in delta.beliefs.values():
            if belief.observation_proof is not None:
                proof = belief.observation_proof
                # Derive expected secret: in simulation uses f"secret-{agent_id}".
                # Production deployments should inject secrets via config or PKI.
                expected_secret = f"secret-{proof.agent_id}"
                if not proof.validate_signature(expected_secret):
                    logger.warning(
                        "Invalid ObservationProof signature for belief %s from agent %s",
                        belief.key,
                        belief.updated_by,
                    )
        deliverable = self._barrier.receive(delta)
        async with self._lock:
            for d in deliverable:
                self._state = self._engine.apply_delta(self._state, d)

    def receive_delta_sync(self, delta: StateDelta) -> None:
        """Process an incoming delta synchronously (simulation / single-threaded use).

        Bypasses both the asyncio Lock and the CausalBarrier.  Safe to call
        from a single-threaded simulation loop where:
        - There are no concurrent coroutines accessing the bus simultaneously.
        - Deltas arrive in causal order (sequential tick-based simulation).

        Validates ObservationProof signatures for beliefs that carry proofs.
        Under the crash-fault model, invalid proofs are logged as warnings but
        still applied (agents are assumed honest; this would be a reject in a
        Byzantine model).

        Args:
            delta: Incoming StateDelta from a peer.
        """
        for belief in delta.beliefs.values():
            if belief.observation_proof is not None:
                proof = belief.observation_proof
                expected_secret = f"secret-{proof.agent_id}"
                if not proof.validate_signature(expected_secret):
                    logger.warning(
                        "Invalid ObservationProof signature for belief %s from agent %s "
                        "(crash-fault model: applying anyway)",
                        belief.key,
                        belief.updated_by,
                    )
        self._state = self._engine.apply_delta(self._state, delta)

    def extract_delta_since(self, since_vc: VectorClock) -> StateDelta:
        """Extract a delta for a peer that knows state up to since_vc.

        Args:
            since_vc: The peer's last known vector clock.

        Returns:
            StateDelta with only mutations newer than since_vc.
        """
        return self._engine.extract_delta(self._state, since_vc)

    # ── Lifecycle ──────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the background gossip loop."""
        await self._gossip.start(
            get_state=lambda: self._state,
            on_delta=self.receive_delta,
        )

    async def stop(self) -> None:
        """Stop the background gossip loop."""
        await self._gossip.stop()

    def register_peer(self, peer_id: str, endpoint: str) -> None:
        """Register a remote peer endpoint for gossip.

        Args:
            peer_id: Unique peer identifier.
            endpoint: HTTP endpoint of the peer's NCE server.
        """
        self._gossip.register_peer(peer_id, endpoint)
