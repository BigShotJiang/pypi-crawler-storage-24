"""Anti-entropy gossip protocol."""

from __future__ import annotations

import asyncio
import logging
import random
from collections.abc import Callable, Coroutine
from typing import Any

import httpx

from nce.crdt.composite_state import CompositeState, StateDelta
from nce.crdt.vector_clock import VectorClock

logger = logging.getLogger(__name__)


class GossipProtocol:
    """Anti-entropy gossip for eventually-consistent CRDT state sync.

    Periodically picks a random peer, pushes the local delta since that
    peer's last known vector clock, and receives their delta in return.
    """

    def __init__(self, sync_interval_ms: int = 500) -> None:
        """Initialize the gossip protocol.

        Args:
            sync_interval_ms: Milliseconds between gossip cycles.
        """
        self._sync_interval_ms = sync_interval_ms
        self._peers: dict[str, str] = {}  # peer_id -> endpoint URL
        self._peer_vcs: dict[str, VectorClock] = {}  # last known VC per peer
        self._task: asyncio.Task[None] | None = None
        self._running = False

    def register_peer(self, peer_id: str, endpoint: str) -> None:
        """Register a remote peer for gossip.

        Args:
            peer_id: Unique identifier for the peer.
            endpoint: HTTP endpoint URL for the peer's NCE server.
        """
        self._peers[peer_id] = endpoint
        if peer_id not in self._peer_vcs:
            self._peer_vcs[peer_id] = VectorClock()

    def unregister_peer(self, peer_id: str) -> None:
        """Remove a peer from the gossip ring.

        Args:
            peer_id: Peer to unregister.
        """
        self._peers.pop(peer_id, None)
        self._peer_vcs.pop(peer_id, None)

    async def sync_cycle(self, local_state: CompositeState) -> list[StateDelta]:
        """Run one gossip cycle: pick a random peer and exchange deltas.

        Args:
            local_state: The current local CompositeState to sync from.

        Returns:
            List of StateDelta received from the peer (may be empty).
        """
        if not self._peers:
            return []

        peer_id = random.choice(list(self._peers))
        endpoint = self._peers[peer_id]
        peer_vc = self._peer_vcs.get(peer_id, VectorClock())

        # Extract what's new since peer's last known VC
        outbound_delta = local_state.extract_delta(peer_vc)

        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(
                    f"{endpoint}/sync",
                    json={
                        "from_agent": local_state.agent_id,
                        "peer_vc": peer_vc.model_dump(),
                        "delta": outbound_delta.model_dump(mode="json"),
                    },
                )
                resp.raise_for_status()
                data = resp.json()
                inbound_delta = StateDelta.model_validate(data["delta"])
                # Update our record of what this peer knows
                self._peer_vcs[peer_id] = local_state.vector_clock.merge(inbound_delta.to_vc)
                return [inbound_delta]
        except Exception as exc:
            logger.warning("Gossip sync to %s failed: %s", peer_id, exc)
            return []

    async def start(
        self,
        get_state: Callable[[], CompositeState],
        on_delta: Callable[[StateDelta], Coroutine[Any, Any, None]],
    ) -> None:
        """Start the background gossip loop.

        Args:
            get_state: Callable that returns the current local state.
            on_delta: Async callback called with each received delta.
        """
        self._running = True
        self._task = asyncio.create_task(self._loop(get_state, on_delta))

    async def stop(self) -> None:
        """Stop the background gossip loop and await its completion."""
        self._running = False
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _loop(
        self,
        get_state: Callable[[], CompositeState],
        on_delta: Callable[[StateDelta], Coroutine[Any, Any, None]],
    ) -> None:
        """Internal gossip loop body.

        Args:
            get_state: Callable that returns the current local state.
            on_delta: Async callback called with each received delta.
        """
        while self._running:
            await asyncio.sleep(self._sync_interval_ms / 1000.0)
            try:
                deltas = await self.sync_cycle(get_state())
                for delta in deltas:
                    await on_delta(delta)
            except Exception as exc:
                logger.error("Gossip loop error: %s", exc)
