"""Message buffering for causal delivery."""

from __future__ import annotations

from nce.crdt.composite_state import StateDelta
from nce.crdt.vector_clock import VectorClock


class CausalBarrier:
    """Buffers out-of-order deltas and delivers them in causal order.

    A delta is deliverable when its ``from_vc`` is causally dominated by
    (i.e., <= ) the set of already-delivered vector clocks.  Out-of-order
    deltas are held in the buffer until their causal dependencies arrive.
    """

    def __init__(self) -> None:
        """Initialize with an empty delivered clock and buffer."""
        self._delivered: VectorClock = VectorClock()
        self._buffer: list[StateDelta] = []

    def receive(self, delta: StateDelta) -> list[StateDelta]:
        """Accept an incoming delta and return all now-deliverable deltas.

        Args:
            delta: The incoming delta to buffer or deliver.

        Returns:
            Ordered list of deltas ready for delivery (may include buffered ones).
        """
        self._buffer.append(delta)
        return self._drain()

    def _drain(self) -> list[StateDelta]:
        """Drain the buffer, returning all causally-ready deltas in order.

        Returns:
            List of deltas whose causal dependencies are satisfied.
        """
        delivered: list[StateDelta] = []
        changed = True
        while changed:
            changed = False
            remaining: list[StateDelta] = []
            for delta in self._buffer:
                if delta.from_vc <= self._delivered:
                    delivered.append(delta)
                    self._delivered = self._delivered.merge(delta.to_vc)
                    changed = True
                else:
                    remaining.append(delta)
            self._buffer = remaining
        return delivered

    @property
    def delivered_vc(self) -> VectorClock:
        """Return the current delivered vector clock.

        Returns:
            The vector clock representing all delivered knowledge.
        """
        return self._delivered

    @property
    def buffer_size(self) -> int:
        """Return the number of buffered (not-yet-deliverable) deltas.

        Returns:
            Count of pending buffered deltas.
        """
        return len(self._buffer)
