"""Delta sync + A2A extension."""
