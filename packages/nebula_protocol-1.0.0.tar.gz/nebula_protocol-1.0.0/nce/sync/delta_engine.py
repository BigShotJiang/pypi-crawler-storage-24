"""Delta extraction and application."""

from __future__ import annotations

from nce.crdt.composite_state import CompositeState, StateDelta
from nce.crdt.vector_clock import VectorClock


_CHARS_PER_TOKEN = 4


class DeltaEngine:
    """Extracts and applies incremental state deltas for efficient sync.

    Rather than transmitting full state on each sync, the DeltaEngine
    computes only the mutations since a given vector clock (the delta),
    which dramatically reduces token cost.
    """

    @staticmethod
    def extract_delta(state: CompositeState, since_vc: VectorClock) -> StateDelta:
        """Extract state mutations since the given vector clock.

        Args:
            state: The current local CompositeState.
            since_vc: The last known vector clock of the recipient.

        Returns:
            StateDelta containing only entries newer than since_vc.
        """
        return state.extract_delta(since_vc)

    @staticmethod
    def apply_delta(state: CompositeState, delta: StateDelta) -> CompositeState:
        """Apply an incoming delta to the local state.

        Args:
            state: The current local CompositeState.
            delta: The incoming delta to apply.

        Returns:
            New CompositeState with delta applied.
        """
        return state.apply_delta(delta)

    @staticmethod
    def compute_token_cost(delta: StateDelta) -> int:
        """Estimate token cost of transmitting a delta (~4 chars per token).

        Args:
            delta: The delta whose transmission cost to estimate.

        Returns:
            Estimated number of tokens required to transmit this delta.
        """
        import json

        def _default(obj: object) -> object:
            if hasattr(obj, "model_dump"):
                return obj.model_dump(mode="json")
            return str(obj)

        serialized = json.dumps(delta.model_dump(mode="json"), default=_default)
        return max(1, len(serialized) // _CHARS_PER_TOKEN)
