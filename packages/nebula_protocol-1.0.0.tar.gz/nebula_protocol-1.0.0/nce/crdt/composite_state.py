"""Product lattice combining all CRDTs."""

from __future__ import annotations

from pydantic import BaseModel, Field

from nce.crdt.belief_register import ObservedBeliefRegister
from nce.crdt.capability_set import CapabilitySet
from nce.crdt.task_status import TaskStatus
from nce.crdt.vector_clock import VectorClock


class StateDelta(BaseModel):
    """Incremental state update since a given vector clock.

    Used for efficient delta-sync: only transmit changed entries
    instead of the full state.
    """

    from_vc: VectorClock
    to_vc: VectorClock
    tasks: dict[str, TaskStatus] = Field(default_factory=dict)
    beliefs: dict[str, ObservedBeliefRegister] = Field(default_factory=dict)
    capabilities: CapabilitySet | None = None
    origin_agent: str = ""


class CompositeState(BaseModel):
    """Product lattice: the full replicated state for one agent node.

    Merging two CompositeStates merges each sub-CRDT independently,
    taking the union of keys. This is itself a CRDT (commutative,
    associative, idempotent).
    """

    tasks: dict[str, TaskStatus] = Field(default_factory=dict)
    beliefs: dict[str, ObservedBeliefRegister] = Field(default_factory=dict)
    capabilities: CapabilitySet = Field(default_factory=CapabilitySet)
    agent_id: str
    vector_clock: VectorClock = Field(default_factory=VectorClock)

    model_config = {"frozen": False}

    def merge(self, other: "CompositeState") -> "CompositeState":
        """Merge two CompositeStates, returning the joined state.

        Commutative, associative, and idempotent.

        Args:
            other: Another CompositeState to merge with.

        Returns:
            New CompositeState representing the merged state.
        """
        merged_tasks: dict[str, TaskStatus] = dict(self.tasks)
        for task_id, other_task in other.tasks.items():
            if task_id in merged_tasks:
                merged_tasks[task_id] = merged_tasks[task_id].merge(other_task)
            else:
                merged_tasks[task_id] = other_task

        merged_beliefs: dict[str, ObservedBeliefRegister] = dict(self.beliefs)
        for key, other_belief in other.beliefs.items():
            if key in merged_beliefs:
                merged_beliefs[key] = merged_beliefs[key].merge(other_belief)
            else:
                merged_beliefs[key] = other_belief

        merged_caps = self.capabilities.merge(other.capabilities)
        merged_vc = self.vector_clock.merge(other.vector_clock)

        return CompositeState(
            tasks=merged_tasks,
            beliefs=merged_beliefs,
            capabilities=merged_caps,
            agent_id=self.agent_id,
            vector_clock=merged_vc,
        )

    def extract_delta(self, since: VectorClock) -> StateDelta:
        """Extract mutations that occurred after the given vector clock.

        A task or belief is included in the delta if its own vector clock
        is NOT causally dominated by (i.e., not <= ) the since clock.

        Args:
            since: Vector clock marking the last known state of the recipient.

        Returns:
            StateDelta containing only entries newer than since.
        """
        delta_tasks: dict[str, TaskStatus] = {}
        for task_id, task in self.tasks.items():
            if not (task.vector_clock <= since):
                delta_tasks[task_id] = task

        delta_beliefs: dict[str, ObservedBeliefRegister] = {}
        for key, belief in self.beliefs.items():
            if not (belief.vector_clock <= since):
                delta_beliefs[key] = belief

        # Always include capabilities in delta (they have no per-entry VC)
        return StateDelta(
            from_vc=since,
            to_vc=self.vector_clock,
            tasks=delta_tasks,
            beliefs=delta_beliefs,
            capabilities=self.capabilities,
            origin_agent=self.agent_id,
        )

    def apply_delta(self, delta: StateDelta) -> "CompositeState":
        """Apply an incoming delta, merging new data into this state.

        Args:
            delta: The StateDelta to apply.

        Returns:
            New CompositeState with delta applied.
        """
        patch = CompositeState(
            tasks=delta.tasks,
            beliefs=delta.beliefs,
            capabilities=delta.capabilities if delta.capabilities is not None else CapabilitySet(),
            agent_id=delta.origin_agent,
            vector_clock=delta.to_vc,
        )
        return self.merge(patch)
