"""ObservationProof dataclass + validation."""

from __future__ import annotations

import json
from datetime import datetime, timezone

from pydantic import BaseModel

from nce.utils.hashing import hmac_sha256, sha256_hex, verify_hmac_sha256


class ObservationProof(BaseModel):
    """Cryptographic proof that an agent observed a specific data source.

    Provides provenance for CRDT values - proves which agent observed
    what data at what time, with an HMAC signature for integrity.
    """

    agent_id: str
    timestamp: datetime
    source_hash: str
    observation_hash: str
    signature: str

    model_config = {"frozen": True}

    @classmethod
    def create(
        cls,
        agent_id: str,
        agent_secret: str,
        source_uri: str,
        request_params: dict[str, object],
        response_body: str,
    ) -> "ObservationProof":
        """Create and sign an observation proof.

        Computes SHA-256 hashes of the source URI+params and response body,
        then signs the combined data with HMAC-SHA256.

        Args:
            agent_id: ID of the observing agent.
            agent_secret: HMAC signing secret for this agent.
            source_uri: URI of the data source observed.
            request_params: Query parameters used in the observation request.
            response_body: Raw response body as string.

        Returns:
            Signed ObservationProof instance.
        """
        timestamp = datetime.now(tz=timezone.utc)
        source_data = json.dumps(
            {"uri": source_uri, "params": request_params},
            sort_keys=True,
            separators=(",", ":"),
        )
        source_hash = sha256_hex(source_data)
        observation_hash = sha256_hex(response_body)

        message = f"{agent_id}|{timestamp.isoformat()}|{source_hash}|{observation_hash}"
        signature = hmac_sha256(agent_secret, message)

        return cls(
            agent_id=agent_id,
            timestamp=timestamp,
            source_hash=source_hash,
            observation_hash=observation_hash,
            signature=signature,
        )

    def validate_signature(self, agent_secret: str) -> bool:
        """Verify the HMAC-SHA256 signature of this proof.

        Args:
            agent_secret: HMAC secret for the agent that created this proof.

        Returns:
            True if signature is valid, False otherwise.
        """
        message = (
            f"{self.agent_id}|{self.timestamp.isoformat()}"
            f"|{self.source_hash}|{self.observation_hash}"
        )
        return verify_hmac_sha256(agent_secret, message, self.signature)
