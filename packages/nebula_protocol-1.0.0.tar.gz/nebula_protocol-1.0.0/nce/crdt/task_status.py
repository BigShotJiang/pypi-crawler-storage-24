"""TaskStatus lattice CRDT."""

from __future__ import annotations

from enum import IntEnum

from pydantic import BaseModel, Field

from nce.crdt.observation_proof import ObservationProof
from nce.crdt.vector_clock import VectorClock


class StatusLevel(IntEnum):
    """Task lifecycle states forming a monotone lattice (higher = further along)."""

    PENDING = 0
    ASSIGNED = 1
    IN_PROGRESS = 2
    COMPLETED = 3
    FAILED = 4
    CANCELLED = 5


class TaskStatus(BaseModel):
    """CRDT representing the status of a distributed task.

    Merge rules (in priority order):
    1. Higher StatusLevel wins.
    2. Equal status + causal ordering: causally later vector_clock wins.
    3. Concurrent + equal status: lexicographically larger agent_id wins.
    4. vector_clock always merges (component-wise max) regardless of winner.
    5. metadata always merges (union, winner overrides conflicts).
    """

    task_id: str
    status: StatusLevel
    assigned_agent: str | None = None
    observation_proof: ObservationProof | None = None
    vector_clock: VectorClock = Field(default_factory=VectorClock)
    metadata: dict[str, str] = Field(default_factory=dict)

    model_config = {"frozen": True}

    def merge(self, other: "TaskStatus") -> "TaskStatus":
        """Merge two TaskStatus CRDTs, returning the joined value.

        Commutative, associative, and idempotent.

        Args:
            other: Another TaskStatus for the same task.

        Returns:
            New TaskStatus representing the merged state.

        Raises:
            ValueError: If task_ids differ.
        """
        if self.task_id != other.task_id:
            raise ValueError(
                f"Cannot merge TaskStatus with different task_ids: "
                f"{self.task_id!r} vs {other.task_id!r}"
            )

        merged_vc = self.vector_clock.merge(other.vector_clock)
        merged_meta = {**self.metadata, **other.metadata}

        # Determine winner
        if self.status != other.status:
            # Higher status wins
            winner = self if self.status > other.status else other
        elif not self.vector_clock.is_concurrent(other.vector_clock):
            # Same status, causal ordering: pick causally later
            winner = self if other.vector_clock <= self.vector_clock else other
        else:
            # Concurrent + equal status: lexicographic agent_id tiebreak
            self_agent = self.assigned_agent or ""
            other_agent = other.assigned_agent or ""
            winner = self if self_agent >= other_agent else other

        merged_meta.update(winner.metadata)

        return TaskStatus(
            task_id=self.task_id,
            status=winner.status,
            assigned_agent=winner.assigned_agent,
            observation_proof=winner.observation_proof,
            vector_clock=merged_vc,
            metadata=merged_meta,
        )
