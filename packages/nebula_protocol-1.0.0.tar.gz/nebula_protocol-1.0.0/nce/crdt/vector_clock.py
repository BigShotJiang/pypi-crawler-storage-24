"""Vector clock implementation."""

from __future__ import annotations

from pydantic import BaseModel, Field


class VectorClock(BaseModel):
    """Immutable vector clock for causal ordering in distributed systems.

    A vector clock tracks the logical time of each agent. Component-wise
    max is the join (merge) operation, making this a lattice.
    """

    clock: dict[str, int] = Field(default_factory=dict)

    model_config = {"frozen": True}

    def model_post_init(self, __context: object) -> None:
        """Normalize clock by removing zero-valued entries."""
        # Use object.__setattr__ because the model is frozen
        object.__setattr__(self, "clock", {k: v for k, v in self.clock.items() if v > 0})

    def increment(self, agent_id: str) -> "VectorClock":
        """Return a new clock with agent_id's counter incremented by 1.

        Args:
            agent_id: The agent whose counter to increment.

        Returns:
            New VectorClock with updated counter.
        """
        new_clock = dict(self.clock)
        new_clock[agent_id] = new_clock.get(agent_id, 0) + 1
        return VectorClock(clock=new_clock)

    def merge(self, other: "VectorClock") -> "VectorClock":
        """Return component-wise maximum of two vector clocks (join operation).

        This is commutative, associative, and idempotent.

        Args:
            other: Another VectorClock to merge with.

        Returns:
            New VectorClock with component-wise max values.
        """
        all_keys = set(self.clock) | set(other.clock)
        merged = {k: max(self.clock.get(k, 0), other.clock.get(k, 0)) for k in all_keys}
        return VectorClock(clock=merged)

    def __le__(self, other: object) -> bool:
        """Causal ordering: self <= other iff all components of self <= other.

        Args:
            other: Another VectorClock.

        Returns:
            True if self causally precedes or equals other.
        """
        if not isinstance(other, VectorClock):
            return NotImplemented
        return all(self.clock.get(k, 0) <= other.clock.get(k, 0) for k in self.clock)

    def __lt__(self, other: object) -> bool:
        """Strict causal ordering: self < other iff self <= other and self != other.

        Args:
            other: Another VectorClock.

        Returns:
            True if self strictly causally precedes other.
        """
        if not isinstance(other, VectorClock):
            return NotImplemented
        return self <= other and self != other

    def __ge__(self, other: object) -> bool:
        """Reverse causal ordering: self >= other iff other <= self.

        Args:
            other: Another VectorClock.

        Returns:
            True if other causally precedes or equals self.
        """
        if not isinstance(other, VectorClock):
            return NotImplemented
        return other <= self

    def __gt__(self, other: object) -> bool:
        """Strict reverse causal ordering.

        Args:
            other: Another VectorClock.

        Returns:
            True if other strictly causally precedes self.
        """
        if not isinstance(other, VectorClock):
            return NotImplemented
        return other < self

    def is_concurrent(self, other: "VectorClock") -> bool:
        """Check if two clocks are concurrent (neither causally precedes the other).

        Args:
            other: Another VectorClock to compare.

        Returns:
            True if neither clock causally precedes the other.
        """
        return not (self <= other) and not (other <= self)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, VectorClock):
            return NotImplemented
        return self.clock == other.clock

    def __hash__(self) -> int:
        return hash(tuple(sorted(self.clock.items())))
