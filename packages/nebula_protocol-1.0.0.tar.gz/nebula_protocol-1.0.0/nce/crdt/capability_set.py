"""CapabilitySet (OR-Set)."""

from __future__ import annotations

import uuid

from pydantic import BaseModel, Field


class CapabilitySet(BaseModel):
    """Observed-Remove Set (OR-Set) for agent capabilities.

    Add-wins: if a concurrent add and remove happen, the add wins because
    each add generates a fresh unique tag not covered by removes.

    Internally tracks:
    - adds: capability -> set of unique tags (one per add operation)
    - removes: set of tombstoned tags
    """

    adds: dict[str, set[str]] = Field(default_factory=dict)
    removes: set[str] = Field(default_factory=set)

    model_config = {"frozen": False}

    def add(self, capability: str) -> "CapabilitySet":
        """Add a capability with a fresh unique tag.

        Args:
            capability: Capability name to add.

        Returns:
            New CapabilitySet with the capability added.
        """
        new_adds = {k: set(v) for k, v in self.adds.items()}
        if capability not in new_adds:
            new_adds[capability] = set()
        new_adds[capability].add(str(uuid.uuid4()))
        return CapabilitySet(adds=new_adds, removes=set(self.removes))

    def remove(self, capability: str) -> "CapabilitySet":
        """Remove a capability by tombstoning all its current tags.

        Args:
            capability: Capability name to remove.

        Returns:
            New CapabilitySet with the capability removed.
        """
        new_removes = set(self.removes)
        if capability in self.adds:
            new_removes.update(self.adds[capability])
        return CapabilitySet(adds={k: set(v) for k, v in self.adds.items()}, removes=new_removes)

    def contains(self, capability: str) -> bool:
        """Check if a capability has any live (non-tombstoned) tags.

        Args:
            capability: Capability name to check.

        Returns:
            True if the capability has at least one live tag.
        """
        tags = self.adds.get(capability, set())
        return bool(tags - self.removes)

    def elements(self) -> set[str]:
        """Return all live capabilities (those with at least one non-tombstoned tag).

        Returns:
            Set of capability names that are currently active.
        """
        return {cap for cap in self.adds if self.contains(cap)}

    def merge(self, other: "CapabilitySet") -> "CapabilitySet":
        """Merge two CapabilitySets (union of adds and removes).

        Commutative, associative, and idempotent.
        Add-wins: a concurrent add generates a fresh tag not covered by removes.

        Args:
            other: Another CapabilitySet to merge with.

        Returns:
            New CapabilitySet representing the merged state.
        """
        all_caps = set(self.adds) | set(other.adds)
        merged_adds: dict[str, set[str]] = {}
        for cap in all_caps:
            merged_adds[cap] = set(self.adds.get(cap, set())) | set(other.adds.get(cap, set()))
        merged_removes = set(self.removes) | set(other.removes)
        return CapabilitySet(adds=merged_adds, removes=merged_removes)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, CapabilitySet):
            return NotImplemented
        return self.adds == other.adds and self.removes == other.removes

    def __hash__(self) -> int:
        adds_frozen = tuple((k, tuple(sorted(v))) for k, v in sorted(self.adds.items()))
        removes_frozen = tuple(sorted(self.removes))
        return hash((adds_frozen, removes_frozen))
