"""ObservedBeliefRegister (LWW + proof)."""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, Field, model_validator

from nce.crdt.observation_proof import ObservationProof
from nce.crdt.vector_clock import VectorClock


class ObservedBeliefRegister(BaseModel):
    """Last-Write-Wins register augmented with cryptographic observation proofs.

    Two vector clocks are tracked:
    - ``write_vc``: Immutable write-time clock. Set when value is written,
      kept from the winner during merge. Used for causal ordering decisions.
    - ``vector_clock``: Sync clock. Always merges (component-wise max).
      Used for delta extraction in CompositeState.

    Merge rules (in priority order):
    1. Strictly causally later ``write_vc`` wins.
    2. Equal or concurrent ``write_vc``: later observation_proof.timestamp wins.
    3. Equal timestamps (or no proofs): lexicographically larger agent_id wins.
    4. Equal agent_id: deterministic value hash as final tiebreaker.
    5. ``vector_clock`` always merges (component-wise max).
    """

    key: str
    value: Any
    write_vc: VectorClock = Field(default_factory=VectorClock)
    vector_clock: VectorClock = Field(default_factory=VectorClock)
    observation_proof: ObservationProof | None = None
    updated_by: str

    model_config = {"frozen": True, "arbitrary_types_allowed": True}

    @model_validator(mode="after")
    def _sync_write_vc(self) -> "ObservedBeliefRegister":
        """If write_vc not explicitly set (equals default empty), copy from vector_clock."""
        if not self.write_vc.clock and self.vector_clock.clock:
            object.__setattr__(self, "write_vc", self.vector_clock)
        return self

    def merge(self, other: "ObservedBeliefRegister") -> "ObservedBeliefRegister":
        """Merge two ObservedBeliefRegisters for the same key.

        Commutative, associative, and idempotent.

        Args:
            other: Another ObservedBeliefRegister for the same key.

        Returns:
            New ObservedBeliefRegister representing the merged state.

        Raises:
            ValueError: If keys differ.
        """
        if self.key != other.key:
            raise ValueError(
                f"Cannot merge ObservedBeliefRegister with different keys: "
                f"{self.key!r} vs {other.key!r}"
            )

        # Sync VC always merges (for delta extraction)
        merged_sync_vc = self.vector_clock.merge(other.vector_clock)

        # Winner selection uses immutable write_vc
        if other.write_vc < self.write_vc:
            winner = self
        elif self.write_vc < other.write_vc:
            winner = other
        else:
            # Equal or concurrent write_vc: deterministic total-order tiebreaker
            winner = self._tiebreak(other)

        return ObservedBeliefRegister(
            key=self.key,
            value=winner.value,
            write_vc=winner.write_vc,
            vector_clock=merged_sync_vc,
            observation_proof=winner.observation_proof,
            updated_by=winner.updated_by,
        )

    def _tiebreak(self, other: "ObservedBeliefRegister") -> "ObservedBeliefRegister":
        """Deterministic total-order tiebreaker for equal/concurrent write_vc.

        Order:
        1. Sum of write_vc clock values (higher = more observed events = wins).
           This is monotone with causal order: if a < c causally, sum(a) < sum(c),
           ensuring c always beats a regardless of concurrent b.
        2. Observation proof timestamp (newer wins).
        3. updated_by agent_id (lexicographically larger wins).
        4. Value hash (final deterministic tiebreak).

        Args:
            other: The competing register.

        Returns:
            The winner according to the total order.
        """
        # Primary: sum of write_vc components (monotone with causal order)
        self_sum = sum(self.write_vc.clock.values())
        other_sum = sum(other.write_vc.clock.values())
        if self_sum != other_sum:
            return self if self_sum > other_sum else other

        # Secondary: observation proof timestamp
        self_ts = self.observation_proof.timestamp if self.observation_proof else None
        other_ts = other.observation_proof.timestamp if other.observation_proof else None
        if self_ts is not None and other_ts is not None and self_ts != other_ts:
            return self if self_ts > other_ts else other

        # Tertiary: agent_id lexicographic order
        if self.updated_by != other.updated_by:
            return self if self.updated_by > other.updated_by else other

        # Final: deterministic value comparison
        self_val = json.dumps(self.value, sort_keys=True, default=str)
        other_val = json.dumps(other.value, sort_keys=True, default=str)
        return self if self_val >= other_val else other
