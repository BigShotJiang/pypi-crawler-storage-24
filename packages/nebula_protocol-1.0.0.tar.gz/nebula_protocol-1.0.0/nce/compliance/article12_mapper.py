"""EU AI Act field mapping."""

from __future__ import annotations

from nce.compliance.flight_recorder import ComplianceEvent

# Article 12 required fields for logging obligations
_ARTICLE12_REQUIRED_FIELDS: list[str] = [
    "event_id",
    "timestamp",
    "agent_id",
    "event_type",
    "session_period_start",
    "reference_database",
    "input_data_match",
    "state_before_hash",
    "state_after_hash",
    "vector_clock",
]

# Mapping from internal event_type to Article 12 category
_EVENT_TYPE_MAP: dict[str, str] = {
    "task_update": "automated_decision",
    "task_complete": "automated_decision_final",
    "task_fail": "automated_decision_error",
    "belief_update": "data_input_change",
    "capability_add": "capability_grant",
    "capability_remove": "capability_revoke",
    "state_mutation": "state_change",
    "sync_received": "data_transfer",
}


def map_to_article12(event: ComplianceEvent) -> dict[str, object]:
    """Map an internal ComplianceEvent to Article 12 required field format.

    Args:
        event: Internal ComplianceEvent to map.

    Returns:
        Dict with Article 12 field names mapped to their values.
    """
    return {
        "log_record_id": event.event_id,
        "timestamp_utc": event.timestamp.isoformat(),
        "system_identifier": event.agent_id,
        "event_category": _EVENT_TYPE_MAP.get(event.event_type, event.event_type),
        "operational_period_start": event.session_period_start.isoformat(),
        "operational_period_end": (
            event.session_period_end.isoformat() if event.session_period_end else None
        ),
        "reference_database_hash": event.reference_database,
        "input_data_fingerprint": event.input_data_match,
        "human_oversight_identifier": event.human_verifier,
        "causal_state_vector": (event.vector_clock.model_dump() if event.vector_clock else None),
        "state_snapshot_before": event.state_before_hash,
        "state_snapshot_after": event.state_after_hash,
    }


def compute_compliance_score(events: list[ComplianceEvent]) -> float:
    """Compute the percentage of required Article 12 fields populated.

    Calculates coverage across all events: what fraction of the required
    fields have non-None values on average.

    Args:
        events: List of ComplianceEvents to score.

    Returns:
        Float in [0.0, 1.0] representing coverage (1.0 = 100%).
    """
    if not events:
        return 0.0

    # Prefer scoring only origin events (those with observation proofs)
    origin_events = [e for e in events if e.observation_proof is not None]
    scoring_events = origin_events if origin_events else events

    total_score = 0.0
    for event in scoring_events:
        populated = sum(
            1 for field in _ARTICLE12_REQUIRED_FIELDS if getattr(event, field, None) is not None
        )
        total_score += populated / len(_ARTICLE12_REQUIRED_FIELDS)

    return total_score / len(scoring_events)
