"""Append-only audit log."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field

from nce.crdt.observation_proof import ObservationProof
from nce.crdt.vector_clock import VectorClock
from nce.utils.hashing import sha256_hex


class ComplianceEvent(BaseModel):
    """A single EU AI Act Article 12 compliance event record.

    All fields map directly to Article 12 logging requirements.
    The ``session_period`` captures the operational window; ``reference_database``
    and ``input_data_match`` provide data provenance hashes.
    """

    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=timezone.utc))
    agent_id: str
    event_type: str
    session_period_start: datetime
    session_period_end: datetime | None = None
    reference_database: str | None = None  # source_hash from ObservationProof
    input_data_match: str | None = None  # observation_hash from ObservationProof
    human_verifier: str | None = None
    vector_clock: VectorClock | None = None
    observation_proof: ObservationProof | None = None
    state_before_hash: str | None = None
    state_after_hash: str | None = None
    extra: dict[str, Any] = Field(default_factory=dict)

    model_config = {"frozen": True}


class FlightRecorder:
    """Append-only audit log for EU AI Act Article 12 compliance.

    Events are stored in-memory in append-only fashion.  Use
    :meth:`seal` to get a cryptographic hash of the full event log,
    and :meth:`generate_article12_report` for a structured report.
    """

    def __init__(self, agent_id: str) -> None:
        """Initialize the flight recorder for a specific agent.

        Args:
            agent_id: ID of the agent this recorder tracks.
        """
        self._agent_id = agent_id
        self._events: list[ComplianceEvent] = []
        self._session_start = datetime.now(tz=timezone.utc)

    def record(self, event: ComplianceEvent) -> None:
        """Append a compliance event to the log.

        Args:
            event: The ComplianceEvent to record (append-only).
        """
        self._events.append(event)

    def record_state_mutation(
        self,
        event_type: str,
        state_before_hash: str,
        state_after_hash: str,
        vector_clock: VectorClock | None = None,
        observation_proof: ObservationProof | None = None,
        human_verifier: str | None = None,
        **extra: Any,
    ) -> ComplianceEvent:
        """Record a state mutation event with Article 12 fields.

        Args:
            event_type: Type descriptor (e.g. ``"task_update"``, ``"belief_update"``).
            state_before_hash: SHA-256 of the state snapshot before this mutation.
            state_after_hash: SHA-256 of the state snapshot after this mutation.
            vector_clock: Optional VectorClock at time of mutation.
            observation_proof: Optional proof of data provenance.
            human_verifier: Optional human reviewer identifier.
            **extra: Additional fields stored in ``extra``.

        Returns:
            The recorded ComplianceEvent.
        """
        event = ComplianceEvent(
            agent_id=self._agent_id,
            event_type=event_type,
            session_period_start=self._session_start,
            session_period_end=datetime.now(tz=timezone.utc),
            reference_database=observation_proof.source_hash if observation_proof else None,
            input_data_match=observation_proof.observation_hash if observation_proof else None,
            human_verifier=human_verifier,
            vector_clock=vector_clock,
            observation_proof=observation_proof,
            state_before_hash=state_before_hash,
            state_after_hash=state_after_hash,
            extra=extra,
        )
        self.record(event)
        return event

    def record_event(self, event_type: str, **kwargs: Any) -> ComplianceEvent:
        """Record a generic compliance event with arbitrary extra fields.

        This convenience method is used by :class:`~nce.sync.state_bus.StateBus`
        to log protocol events (e.g. ``task_update``, ``belief_update``) that
        do not yet have full state-before/after hashes available.

        Args:
            event_type: Type descriptor (e.g. ``"task_update"``).
            **kwargs: Stored verbatim in ``extra``.

        Returns:
            The recorded ComplianceEvent.
        """
        event = ComplianceEvent(
            agent_id=self._agent_id,
            event_type=event_type,
            session_period_start=self._session_start,
            session_period_end=datetime.now(tz=timezone.utc),
            extra=kwargs,
        )
        self.record(event)
        return event

    def seal(self) -> str:
        """Compute a cryptographic hash over all recorded events.

        Hashes full event content (agent_id, event_type, state hashes, proofs)
        not just IDs and timestamps, so tampered event bodies are detected.

        Returns:
            SHA-256 hex digest of concatenated event content.
        """
        parts = [
            (
                f"{e.event_id}:{e.timestamp.isoformat()}:{e.agent_id}:{e.event_type}"
                f":{e.state_before_hash or ''}:{e.state_after_hash or ''}"
                f":{e.reference_database or ''}:{e.input_data_match or ''}"
            )
            for e in self._events
        ]
        return sha256_hex("|".join(parts))

    def query(self, start: datetime, end: datetime) -> list[ComplianceEvent]:
        """Query events within a time range.

        Args:
            start: Inclusive start datetime (UTC).
            end: Inclusive end datetime (UTC).

        Returns:
            List of ComplianceEvents with timestamps in [start, end].
        """
        return [e for e in self._events if start <= e.timestamp <= end]

    def all_events(self) -> list[ComplianceEvent]:
        """Return all recorded events.

        Returns:
            All ComplianceEvents in insertion order.
        """
        return list(self._events)

    def generate_article12_report(self) -> dict[str, Any]:
        """Generate a structured EU AI Act Article 12 compliance report.

        Returns:
            Dict containing agent_id, event_count, seal, and serialized events.
        """
        return {
            "agent_id": self._agent_id,
            "session_start": self._session_start.isoformat(),
            "report_generated": datetime.now(tz=timezone.utc).isoformat(),
            "event_count": len(self._events),
            "seal": self.seal(),
            "events": [e.model_dump(mode="json") for e in self._events],
        }

    def __len__(self) -> int:
        return len(self._events)
