"""Queryable log storage."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from nce.compliance.flight_recorder import ComplianceEvent, FlightRecorder

_RETENTION_DAYS = 180  # Article 19 minimum retention


class ComplianceStore:
    """Persistent compliance event storage with 180-day retention (Article 19).

    Wraps a SQLite database (or in-memory DB if no path given) to provide
    durable append-only storage of ComplianceEvents with automatic purging
    of records older than the retention window.
    """

    def __init__(self, db_path: str | Path | None = None) -> None:
        """Initialize the compliance store.

        Args:
            db_path: Path to SQLite database file, or None for in-memory.
        """
        self._db_path = str(db_path) if db_path else ":memory:"
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._init_schema()

    def _init_schema(self) -> None:
        """Create the events table if it does not exist."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS compliance_events (
                event_id TEXT PRIMARY KEY,
                timestamp TEXT NOT NULL,
                agent_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                payload TEXT NOT NULL
            )
        """)
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_timestamp ON compliance_events(timestamp)"
        )
        self._conn.commit()

    def store(self, event: ComplianceEvent) -> None:
        """Persist a compliance event.

        Args:
            event: The ComplianceEvent to store.
        """
        self._conn.execute(
            "INSERT OR IGNORE INTO compliance_events VALUES (?, ?, ?, ?, ?)",
            (
                event.event_id,
                event.timestamp.isoformat(),
                event.agent_id,
                event.event_type,
                event.model_dump_json(),
            ),
        )
        self._conn.commit()

    def store_from_recorder(self, recorder: FlightRecorder) -> int:
        """Bulk-store all events from a FlightRecorder.

        Args:
            recorder: FlightRecorder whose events to persist.

        Returns:
            Number of events stored.
        """
        events = recorder.all_events()
        for event in events:
            self.store(event)
        return len(events)

    def query(
        self,
        start: datetime,
        end: datetime,
        agent_id: str | None = None,
        event_type: str | None = None,
    ) -> list[ComplianceEvent]:
        """Query events by time range and optional filters.

        Args:
            start: Inclusive start datetime (UTC).
            end: Inclusive end datetime (UTC).
            agent_id: Optional filter by agent ID.
            event_type: Optional filter by event type.

        Returns:
            List of matching ComplianceEvents in timestamp order.
        """
        sql = """
            SELECT payload FROM compliance_events
            WHERE timestamp >= ? AND timestamp <= ?
        """
        params: list[Any] = [start.isoformat(), end.isoformat()]
        if agent_id:
            sql += " AND agent_id = ?"
            params.append(agent_id)
        if event_type:
            sql += " AND event_type = ?"
            params.append(event_type)
        sql += " ORDER BY timestamp ASC"

        cursor = self._conn.execute(sql, params)
        return [ComplianceEvent.model_validate_json(row[0]) for row in cursor]

    def query_all(
        self,
        agent_id: str | None = None,
        event_type: str | None = None,
    ) -> list[ComplianceEvent]:
        """Query all events within the Article 19 retention window.

        Convenience wrapper around :meth:`query` that spans the full 180-day
        retention period.  Use this when no specific time range is needed (e.g.
        the ``/compliance/report`` API endpoint).

        Args:
            agent_id: Optional filter by agent ID.
            event_type: Optional filter by event type.

        Returns:
            List of matching ComplianceEvents in timestamp order.
        """
        now = datetime.now(tz=timezone.utc)
        start = now - timedelta(days=_RETENTION_DAYS)
        return self.query(start, now, agent_id=agent_id, event_type=event_type)

    def purge_expired(self) -> int:
        """Delete events older than the 180-day Article 19 retention window.

        Returns:
            Number of records deleted.
        """
        cutoff = (datetime.now(tz=timezone.utc) - timedelta(days=_RETENTION_DAYS)).isoformat()
        cursor = self._conn.execute("DELETE FROM compliance_events WHERE timestamp < ?", (cutoff,))
        self._conn.commit()
        return cursor.rowcount

    def count(self) -> int:
        """Return the total number of stored events.

        Returns:
            Event count.
        """
        cursor = self._conn.execute("SELECT COUNT(*) FROM compliance_events")
        row = cursor.fetchone()
        return int(row[0]) if row else 0

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()
