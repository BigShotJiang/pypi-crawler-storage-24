"""NCE: Nebula Convergent Engine - Core package."""

__version__ = "1.0.0"
