"""Benchmark suite for paper metrics.

Runs all four baselines (no_sync, full_context, central_coordinator, nce),
exports per-baseline CSVs, and writes consolidated paper tables to
``docs/paper/tables/``.
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import math
import random
import statistics
from pathlib import Path

from simulation.baselines.central_coordinator import run_central_coordinator_baseline
from simulation.baselines.full_context import run_full_context_baseline
from simulation.baselines.no_sync import run_no_sync_baseline
from simulation.config import SimulationConfig
from simulation.network.metrics_collector import MetricsCollector, SimulationReport
from simulation.run_simulation import run_nce_simulation


# ---------------------------------------------------------------------------
# Per-baseline helpers
# ---------------------------------------------------------------------------


def _make_metrics(report: SimulationReport) -> MetricsCollector:
    """Reconstruct a MetricsCollector from a SimulationReport for export.

    Args:
        report: Completed simulation report.

    Returns:
        MetricsCollector populated with the report's key metrics.
    """
    m = MetricsCollector(report.baseline)
    m.phantom_commitments = report.phantom_commitments
    m.total_transactions = report.total_transactions
    for lat in [report.convergence_p50_ms, report.convergence_p95_ms, report.convergence_p99_ms]:
        if lat and lat != float("inf"):
            m.convergence_latencies.append(lat)
    if report.avg_token_cost_per_sync:
        m.token_costs.append(int(report.avg_token_cost_per_sync))
    m.compliance_scores.append(report.avg_compliance_score)
    return m


def _fmt_conv(v: float) -> str:
    if v == 0.0 or math.isinf(v):
        return "N/A"
    return f"{v:.0f} ms"


def _fmt_tokens(v: float) -> str:
    if v == 0.0:
        return "0"
    return f"~{v:,.0f}"


def _fmt_avail(v: float) -> str:
    return f"{v:.0f}%"


def _fmt_art12(v: float) -> str:
    return f"{v * 100:.0f}%"


def _phantom_rate(r: SimulationReport) -> str:
    total = r.total_transactions + r.phantom_commitments
    if total == 0:
        return "0"
    rate = r.phantom_commitments / total * 100
    return f"{r.phantom_commitments} ({rate:.1f}%)"


# ---------------------------------------------------------------------------
# Consolidated table writers
# ---------------------------------------------------------------------------


def _write_comparison_csv(reports: dict[str, SimulationReport], output_dir: Path) -> None:
    """Write the primary comparison table as a CSV file.

    Args:
        reports: Mapping of baseline name to SimulationReport.
        output_dir: Directory to write the CSV into.
    """
    rows = []
    for name, r in reports.items():
        rows.append(
            {
                "baseline": name,
                "total_transactions": r.total_transactions,
                "phantom_commitments": r.phantom_commitments,
                "phantom_rate_pct": (
                    round(
                        r.phantom_commitments
                        / max(1, r.total_transactions + r.phantom_commitments)
                        * 100,
                        2,
                    )
                ),
                "convergence_p50_ms": round(r.convergence_p50_ms, 1)
                if not math.isinf(r.convergence_p50_ms)
                else "N/A",
                "convergence_p95_ms": round(r.convergence_p95_ms, 1)
                if not math.isinf(r.convergence_p95_ms)
                else "N/A",
                "convergence_p99_ms": round(r.convergence_p99_ms, 1)
                if not math.isinf(r.convergence_p99_ms)
                else "N/A",
                "avg_token_cost_per_sync": round(r.avg_token_cost_per_sync, 0),
                "peak_token_cost_per_sync": round(r.peak_token_cost_per_sync, 0),
                "availability_pct": round(r.availability_pct, 1),
                "avg_compliance_score_pct": round(r.avg_compliance_score * 100, 1),
            }
        )

    path = output_dir / "baseline_comparison.csv"
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"  Wrote {path}")


def _write_convergence_csv(reports: dict[str, SimulationReport], output_dir: Path) -> None:
    """Write convergence latency percentiles for all baselines.

    Args:
        reports: Mapping of baseline name to SimulationReport.
        output_dir: Directory to write the CSV into.
    """
    path = output_dir / "convergence_latency.csv"
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["baseline", "p50_ms", "p95_ms", "p99_ms"])
        for name, r in reports.items():
            writer.writerow(
                [
                    name,
                    "N/A" if math.isinf(r.convergence_p50_ms) else round(r.convergence_p50_ms, 1),
                    "N/A" if math.isinf(r.convergence_p95_ms) else round(r.convergence_p95_ms, 1),
                    "N/A" if math.isinf(r.convergence_p99_ms) else round(r.convergence_p99_ms, 1),
                ]
            )
    print(f"  Wrote {path}")


def _write_token_cost_csv(reports: dict[str, SimulationReport], output_dir: Path) -> None:
    """Write token cost comparison CSV.

    Args:
        reports: Mapping of baseline name to SimulationReport.
        output_dir: Directory to write the CSV into.
    """
    path = output_dir / "token_cost_comparison.csv"
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["baseline", "avg_tokens_per_sync", "peak_tokens_per_sync"])
        for name, r in reports.items():
            writer.writerow(
                [name, round(r.avg_token_cost_per_sync), round(r.peak_token_cost_per_sync)]
            )
    print(f"  Wrote {path}")


def _write_phantom_csv(reports: dict[str, SimulationReport], output_dir: Path) -> None:
    """Write phantom commitment counts CSV.

    Args:
        reports: Mapping of baseline name to SimulationReport.
        output_dir: Directory to write the CSV into.
    """
    path = output_dir / "phantom_commitments.csv"
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            ["baseline", "total_transactions", "phantom_commitments", "phantom_rate_pct"]
        )
        for name, r in reports.items():
            total = r.total_transactions + r.phantom_commitments
            rate = round(r.phantom_commitments / max(1, total) * 100, 2)
            writer.writerow([name, r.total_transactions, r.phantom_commitments, rate])
    print(f"  Wrote {path}")


def _write_availability_csv(reports: dict[str, SimulationReport], output_dir: Path) -> None:
    """Write availability and compliance coverage CSV.

    Args:
        reports: Mapping of baseline name to SimulationReport.
        output_dir: Directory to write the CSV into.
    """
    path = output_dir / "availability_compliance.csv"
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["baseline", "availability_pct", "art12_coverage_pct"])
        for name, r in reports.items():
            writer.writerow(
                [name, round(r.availability_pct, 1), round(r.avg_compliance_score * 100, 1)]
            )
    print(f"  Wrote {path}")


def _write_summary_md(
    reports: dict[str, SimulationReport],
    output_dir: Path,
    per_seed_reports: dict[str, list[SimulationReport]] | None = None,
) -> None:
    """Write a paper-ready Markdown summary table.

    When per_seed_reports is provided, table cells show mean+/-std.

    Args:
        reports: Mapping of baseline name to (aggregated) SimulationReport.
        output_dir: Directory to write summary.md into.
        per_seed_reports: Optional per-seed reports for std deviation display.
    """
    if per_seed_reports is None:
        per_seed_reports = {}

    order = ["no_sync", "full_context", "central_coordinator", "nce"]
    present = [k for k in order if k in reports]

    labels = {
        "no_sync": "No Sync",
        "full_context": "Full Context",
        "central_coordinator": "Central",
        "nce": "**NCE (ours)**",
    }

    def _with_std(k: str, val_str: str, attr: str) -> str:
        """Append +/-std if multi-seed data is available."""
        if k not in per_seed_reports:
            return val_str
        std = _compute_std(per_seed_reports[k], attr)
        if std > 0:
            return f"{val_str} (+/-{std:.0f})"
        return val_str

    lines: list[str] = []
    lines.append("# NCE Benchmark Results\n")
    lines.append(
        f"Transactions per baseline: {next(iter(reports.values())).total_transactions:,}\n"
    )
    if per_seed_reports:
        n_seeds = len(next(iter(per_seed_reports.values())))
        lines.append(f"Seeds per baseline: {n_seeds}\n")
    lines.append("")

    # Table 1: Core comparison
    lines.append("## Table 1 - Protocol Comparison\n")
    header = "| Metric | " + " | ".join(labels[k] for k in present) + " |"
    sep = "|--------|" + "|".join("------" for _ in present) + "|"
    lines.append(header)
    lines.append(sep)

    def row(metric: str, vals: list[str]) -> str:
        return f"| {metric} | " + " | ".join(vals) + " |"

    lines.append(row("Phantom Commits", [_phantom_rate(reports[k]) for k in present]))
    lines.append(
        row(
            "Conv. p99 (ms)",
            [
                _with_std(k, _fmt_conv(reports[k].convergence_p99_ms), "convergence_p99_ms")
                for k in present
            ],
        )
    )
    lines.append(
        row(
            "Tokens/sync (avg)",
            [
                _with_std(
                    k, _fmt_tokens(reports[k].avg_token_cost_per_sync), "avg_token_cost_per_sync"
                )
                for k in present
            ],
        )
    )
    lines.append(row("Availability", [_fmt_avail(reports[k].availability_pct) for k in present]))
    lines.append(
        row(
            "Art.12 Coverage",
            [
                _with_std(k, _fmt_art12(reports[k].avg_compliance_score), "avg_compliance_score")
                for k in present
            ],
        )
    )
    lines.append("")

    # Table 2: Convergence latency breakdown
    lines.append("## Table 2 - Convergence Latency Percentiles\n")
    lines.append("| Baseline | p50 (ms) | p95 (ms) | p99 (ms) |")
    lines.append("|----------|----------|----------|----------|")
    for k in present:
        r = reports[k]
        lines.append(
            f"| {labels[k]} "
            f"| {_fmt_conv(r.convergence_p50_ms)} "
            f"| {_fmt_conv(r.convergence_p95_ms)} "
            f"| {_fmt_conv(r.convergence_p99_ms)} |"
        )
    lines.append("")

    # Table 3: Token cost
    lines.append("## Table 3 - Token Cost per Sync Round\n")
    lines.append("| Baseline | Avg Tokens | Peak Tokens | vs Full-Context |")
    lines.append("|----------|-----------|-------------|-----------------|")
    fc_avg = reports.get("full_context", reports[present[0]]).avg_token_cost_per_sync
    for k in present:
        r = reports[k]
        if fc_avg > 0 and r.avg_token_cost_per_sync > 0:
            savings = (1 - r.avg_token_cost_per_sync / fc_avg) * 100
            vs = f"{savings:+.0f}%"
        else:
            vs = "N/A"
        lines.append(
            f"| {labels[k]} "
            f"| {_fmt_tokens(r.avg_token_cost_per_sync)} "
            f"| {_fmt_tokens(r.peak_token_cost_per_sync)} "
            f"| {vs} |"
        )
    lines.append("")

    path = output_dir / "summary.md"
    with open(path, "w") as f:
        f.write("\n".join(lines))
    print(f"  Wrote {path}")


# ---------------------------------------------------------------------------
# Multi-seed helpers
# ---------------------------------------------------------------------------

_DEFAULT_SEEDS: list[int] = [42, 7, 137]


def _run_with_seeds(
    run_fn: object,
    config: SimulationConfig,
    seeds: list[int],
    total_transactions: int,
    is_async: bool = False,
) -> list[SimulationReport]:
    """Run a baseline function multiple times with different random seeds.

    Args:
        run_fn: Baseline runner (sync or async callable).
        config: Simulation configuration.
        seeds: List of random seeds to use.
        total_transactions: Transactions per run.
        is_async: Whether run_fn is async.

    Returns:
        List of SimulationReports, one per seed.
    """
    reports = []
    for seed in seeds:
        random.seed(seed)
        if is_async:
            report = asyncio.run(run_fn(config, total_transactions))
        else:
            report = run_fn(config, total_transactions)
        reports.append(report)
    return reports


def _aggregate_reports(reports: list[SimulationReport], baseline: str) -> SimulationReport:
    """Compute mean values across multiple seed runs.

    Args:
        reports: List of per-seed SimulationReports.
        baseline: Baseline name for the aggregated report.

    Returns:
        A single SimulationReport with mean metric values.
    """
    m = MetricsCollector(baseline)
    m.total_transactions = round(statistics.mean(r.total_transactions for r in reports))
    m.phantom_commitments = round(statistics.mean(r.phantom_commitments for r in reports))

    for r in reports:
        if not math.isinf(r.convergence_p99_ms):
            m.convergence_latencies.append(r.convergence_p99_ms)
        m.token_costs.append(int(r.avg_token_cost_per_sync))
        m.compliance_scores.append(r.avg_compliance_score)

    report = m.report()
    # Preserve mean availability from per-seed reports; baselines that track downtime
    # override the MetricsCollector default of 100.0, but _aggregate_reports builds a
    # fresh MetricsCollector that loses those overrides.
    avg_avail = statistics.mean(r.availability_pct for r in reports)
    report.__dict__["availability_pct"] = avg_avail
    return report


def _compute_std(reports: list[SimulationReport], attr: str) -> float:
    """Compute standard deviation for a metric across seed runs.

    Args:
        reports: List of per-seed SimulationReports.
        attr: Attribute name on SimulationReport.

    Returns:
        Standard deviation (0.0 if fewer than 2 reports).
    """
    vals = [getattr(r, attr) for r in reports]
    vals = [v for v in vals if not math.isinf(v)]
    if len(vals) < 2:
        return 0.0
    return statistics.stdev(vals)


# ---------------------------------------------------------------------------
# Main benchmark runner
# ---------------------------------------------------------------------------


def run_all_benchmarks(
    config: SimulationConfig,
    output_dir: Path,
    total_transactions: int = 1000,
    seeds: list[int] | None = None,
) -> dict[str, SimulationReport]:
    """Run all four baselines and export paper artifacts.

    Args:
        config: Simulation configuration.
        output_dir: Directory to write CSV tables and PNG figures.
        total_transactions: Transactions per baseline.
        seeds: Random seeds for multi-seed runs. None for single run.

    Returns:
        Dict mapping baseline name to SimulationReport.
    """
    reports: dict[str, SimulationReport] = {}
    per_seed_reports: dict[str, list[SimulationReport]] = {}

    baselines: list[tuple[str, object, bool]] = [
        ("no_sync", run_no_sync_baseline, False),
        ("full_context", run_full_context_baseline, False),
        ("central_coordinator", run_central_coordinator_baseline, False),
        ("nce", run_nce_simulation, True),
    ]

    for name, run_fn, is_async in baselines:
        print(f"Running {name} baseline...")
        if seeds and len(seeds) > 1:
            seed_reports = _run_with_seeds(run_fn, config, seeds, total_transactions, is_async)
            per_seed_reports[name] = seed_reports
            reports[name] = _aggregate_reports(seed_reports, name)
        else:
            seed = seeds[0] if seeds else None
            if seed is not None:
                random.seed(seed)
            if is_async:
                reports[name] = asyncio.run(run_fn(config, total_transactions))
            else:
                reports[name] = run_fn(config, total_transactions)

    # Per-baseline artifact directories
    for name, report in reports.items():
        sub = output_dir / name
        sub.mkdir(parents=True, exist_ok=True)
        _make_metrics(report).export_for_paper(sub)

    # Consolidated tables
    print("\nWriting consolidated paper tables...")
    _write_comparison_csv(reports, output_dir)
    _write_convergence_csv(reports, output_dir)
    _write_token_cost_csv(reports, output_dir)
    _write_phantom_csv(reports, output_dir)
    _write_availability_csv(reports, output_dir)
    _write_summary_md(reports, output_dir, per_seed_reports)

    return reports


def main() -> None:
    """Entry point for benchmark CLI."""
    parser = argparse.ArgumentParser(description="NCE Benchmark Suite")
    parser.add_argument("--output", default="docs/paper/tables", help="Output directory")
    parser.add_argument("--transactions", type=int, default=1000)
    parser.add_argument("--seeds", type=int, default=3, help="Number of seeds for multi-seed runs")
    args = parser.parse_args()

    config = SimulationConfig()
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    seeds = _DEFAULT_SEEDS[: args.seeds]
    reports = run_all_benchmarks(config, output_dir, args.transactions, seeds=seeds)

    print("\nDone. Results summary:")
    for name, r in reports.items():
        print(
            f"  {name:25s}  phantoms={r.phantom_commitments:4d}"
            f"  p99={_fmt_conv(r.convergence_p99_ms):8s}"
            f"  tokens={r.avg_token_cost_per_sync:7,.0f}"
            f"  avail={r.availability_pct:.0f}%"
            f"  art12={r.avg_compliance_score * 100:.0f}%"
        )


if __name__ == "__main__":
    main()
