"""Jitter, packet loss, partitions."""

from __future__ import annotations

import asyncio
import random
from typing import TYPE_CHECKING

from nce.crdt.composite_state import StateDelta
from simulation.config import SimulationConfig

if TYPE_CHECKING:
    from simulation.agents.base_agent import BaseAgent


class ChaosEngine:
    """Injects network chaos: jitter, packet loss, and partitions.

    Used to test NCE convergence under adverse network conditions,
    matching the simulation's configured chaos parameters.
    """

    def __init__(self, config: SimulationConfig) -> None:
        """Initialize the chaos engine.

        Args:
            config: Simulation configuration with chaos parameters.
        """
        self._config = config
        self._partitions: dict[frozenset[str], float] = {}  # pair -> end_time

    async def delay_message(self, delta: StateDelta) -> StateDelta | None:
        """Apply random jitter and packet loss to a message.

        Args:
            delta: The delta to (possibly) delay or drop.

        Returns:
            The original delta after delay, or None if dropped (packet loss).
        """
        # Packet loss
        if random.random() * 100 < self._config.packet_loss_pct:
            return None

        # Jitter
        jitter_min, jitter_max = self._config.jitter_ms
        if jitter_max > 0:
            delay_ms = random.uniform(jitter_min, jitter_max)
            await asyncio.sleep(delay_ms / 1000.0)

        return delta

    def check_partition(self, agent_a: "BaseAgent", agent_b: "BaseAgent") -> bool:
        """Check whether two agents are currently partitioned.

        Args:
            agent_a: First agent.
            agent_b: Second agent.

        Returns:
            True if a partition currently exists between these agents.
        """
        key = frozenset([agent_a.agent_id, agent_b.agent_id])
        end_time = self._partitions.get(key, 0.0)
        return asyncio.get_event_loop().time() < end_time

    def inject_partition(self, agents: list["BaseAgent"], duration_s: float) -> None:
        """Force a network partition among a set of agents.

        Creates a partition between all pairs in the given agent list
        lasting for the specified duration.

        Args:
            agents: Agents to partition from each other.
            duration_s: Duration of the partition in seconds.
        """
        now = asyncio.get_event_loop().time()
        end_time = now + duration_s
        for i, a in enumerate(agents):
            for b in agents[i + 1 :]:
                key = frozenset([a.agent_id, b.agent_id])
                self._partitions[key] = end_time

    def maybe_inject_random_partition(self, agents: list["BaseAgent"]) -> None:
        """Probabilistically inject a random partition.

        Uses the configured ``partition_probability`` to decide whether
        to inject a 5-30 second partition among a random subset of agents.

        Args:
            agents: Pool of agents to potentially partition.
        """
        if random.random() < self._config.partition_probability and len(agents) >= 2:
            subset_size = random.randint(2, min(len(agents), 4))
            subset = random.sample(agents, subset_size)
            duration = random.uniform(5.0, 30.0)
            self.inject_partition(subset, duration)
