"""Latency, throughput, phantom tracking."""

from __future__ import annotations

import csv
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class SimulationReport:
    """Aggregated simulation metrics for paper output."""

    baseline: str
    total_transactions: int
    phantom_commitments: int
    convergence_p50_ms: float
    convergence_p95_ms: float
    convergence_p99_ms: float
    avg_token_cost_per_sync: float
    peak_token_cost_per_sync: float
    avg_proof_size_bytes: float
    avg_compliance_score: float
    availability_pct: float
    throughput_timeline: list[tuple[float, int]]


class MetricsCollector:
    """Tracks simulation metrics for paper artifact generation.

    All metrics are append-only except ``phantom_commitments`` and
    ``total_transactions`` which are incremented in-place.
    """

    def __init__(self, baseline: str = "nce") -> None:
        """Initialize the collector.

        Args:
            baseline: Name of the simulation baseline being measured.
        """
        self.baseline = baseline
        self.convergence_latencies: list[float] = []
        self.phantom_commitments: int = 0
        self.total_transactions: int = 0
        self.token_costs: list[int] = []
        self.proof_sizes_bytes: list[int] = []
        self.compliance_scores: list[float] = []
        self.throughput_timeline: list[tuple[float, int]] = []
        self._start_time = time.monotonic()
        self._last_throughput_ts = time.monotonic()
        self._last_throughput_tx = 0

    def record_convergence(self, latency_ms: float) -> None:
        """Record a convergence latency measurement.

        Args:
            latency_ms: Time from mutation to full convergence in ms.
        """
        self.convergence_latencies.append(latency_ms)

    def record_token_cost(self, tokens: int) -> None:
        """Record token cost of one sync round.

        Args:
            tokens: Number of tokens for this sync.
        """
        self.token_costs.append(tokens)

    def record_proof_size(self, size_bytes: int) -> None:
        """Record the serialized size of an ObservationProof.

        Args:
            size_bytes: Size in bytes.
        """
        self.proof_sizes_bytes.append(size_bytes)

    def record_compliance_score(self, score: float) -> None:
        """Record an Article 12 compliance score.

        Args:
            score: Float in [0, 1].
        """
        self.compliance_scores.append(score)

    def record_throughput_snapshot(self) -> None:
        """Snapshot current throughput (transactions per second)."""
        now = time.monotonic()
        elapsed = now - self._last_throughput_ts
        if elapsed > 0:
            tx_delta = self.total_transactions - self._last_throughput_tx
            tps = tx_delta / elapsed
            self.throughput_timeline.append((now - self._start_time, int(tps)))
            self._last_throughput_ts = now
            self._last_throughput_tx = self.total_transactions

    def _percentile(self, data: list[float], pct: float) -> float:
        """Compute a percentile of a sorted list.

        Args:
            data: List of float values.
            pct: Percentile in (0, 100].

        Returns:
            The pct-th percentile value.
        """
        if not data:
            return 0.0
        sorted_data = sorted(data)
        idx = int(len(sorted_data) * pct / 100) - 1
        return sorted_data[max(0, idx)]

    def report(self) -> SimulationReport:
        """Generate the aggregated simulation report.

        Returns:
            SimulationReport with p50/p95/p99 and totals.
        """
        return SimulationReport(
            baseline=self.baseline,
            total_transactions=self.total_transactions,
            phantom_commitments=self.phantom_commitments,
            convergence_p50_ms=self._percentile(self.convergence_latencies, 50),
            convergence_p95_ms=self._percentile(self.convergence_latencies, 95),
            convergence_p99_ms=self._percentile(self.convergence_latencies, 99),
            avg_token_cost_per_sync=(
                sum(self.token_costs) / len(self.token_costs) if self.token_costs else 0.0
            ),
            peak_token_cost_per_sync=max(self.token_costs) if self.token_costs else 0.0,
            avg_proof_size_bytes=(
                sum(self.proof_sizes_bytes) / len(self.proof_sizes_bytes)
                if self.proof_sizes_bytes
                else 0.0
            ),
            avg_compliance_score=(
                sum(self.compliance_scores) / len(self.compliance_scores)
                if self.compliance_scores
                else 0.0
            ),
            availability_pct=100.0,  # Updated by baselines that track downtime
            throughput_timeline=self.throughput_timeline,
        )

    def export_for_paper(self, output_dir: str | Path) -> None:
        """Write CSV tables and (if matplotlib available) PNG figures.

        Args:
            output_dir: Directory to write paper artifacts to.
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        report = self.report()

        # Convergence latency CSV
        if self.convergence_latencies:
            _write_csv(
                output_path / "convergence_latency.csv",
                ["latency_ms"],
                [[x] for x in self.convergence_latencies],
            )

        # Token cost CSV
        if self.token_costs:
            _write_csv(
                output_path / "token_cost_comparison.csv",
                ["baseline", "tokens"],
                [[report.baseline, c] for c in self.token_costs],
            )

        # Baseline comparison row
        _write_csv(
            output_path / "baseline_comparison.csv",
            [
                "baseline",
                "phantom_commitments",
                "convergence_p99_ms",
                "avg_token_cost",
                "availability_pct",
                "avg_compliance_score",
            ],
            [
                [
                    report.baseline,
                    report.phantom_commitments,
                    report.convergence_p99_ms,
                    report.avg_token_cost_per_sync,
                    report.availability_pct,
                    report.avg_compliance_score,
                ]
            ],
        )

        # Throughput timeline CSV
        if self.throughput_timeline:
            _write_csv(
                output_path / "throughput_timeline.csv",
                ["elapsed_s", "tps"],
                list(self.throughput_timeline),
            )

        _try_plot_figures(output_path, self)


def _write_csv(path: Path, headers: list[str], rows: list[list[Any]]) -> None:
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)


def _try_plot_figures(output_dir: Path, collector: MetricsCollector) -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return

    # Latency distribution
    if collector.convergence_latencies:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.hist(collector.convergence_latencies, bins=20, color="#3B82F6", edgecolor="white")
        ax.set_xlabel("Convergence Latency (ms)")
        ax.set_ylabel("Count")
        ax.set_title(f"Convergence Latency Distribution - {collector.baseline}")
        fig.tight_layout()
        fig.savefig(output_dir / "latency_distribution.png", dpi=150)
        plt.close(fig)

    # Token cost bar chart
    if collector.token_costs:
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(["NCE"], [sum(collector.token_costs) / len(collector.token_costs)], color="#10B981")
        ax.set_ylabel("Avg Tokens per Sync")
        ax.set_title("Token Cost")
        fig.tight_layout()
        fig.savefig(output_dir / "token_cost_bar.png", dpi=150)
        plt.close(fig)

    # Throughput timeline
    if collector.throughput_timeline:
        ts, tps = zip(*collector.throughput_timeline)
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.fill_between(ts, tps, alpha=0.6, color="#8B5CF6")
        ax.set_xlabel("Elapsed (s)")
        ax.set_ylabel("Transactions / s")
        ax.set_title("Throughput Timeline")
        fig.tight_layout()
        fig.savefig(output_dir / "throughput_timeline.png", dpi=150)
        plt.close(fig)
