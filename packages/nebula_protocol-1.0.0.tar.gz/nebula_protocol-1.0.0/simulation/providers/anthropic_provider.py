"""Anthropic Claude simulator."""
