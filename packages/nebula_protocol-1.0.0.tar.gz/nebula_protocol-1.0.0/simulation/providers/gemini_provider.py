"""Google Gemini simulator."""
