"""Abstract provider interface."""
