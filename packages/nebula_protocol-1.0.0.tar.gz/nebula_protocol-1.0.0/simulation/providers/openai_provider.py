"""OpenAI GPT-4o simulator."""
