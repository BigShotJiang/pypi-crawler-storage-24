"""Inventory team (3 agents)."""

from __future__ import annotations

import random

from nce.crdt.observation_proof import ObservationProof
from simulation.agents.base_agent import BaseAgent
from simulation.config import SimulationConfig


class InventoryAgent(BaseAgent):
    """Simulates warehouse inventory observation.

    On each tick, picks a random SKU, "observes" the warehouse API
    (simulated), and writes the stock count to the NCE belief register.
    """

    def __init__(
        self,
        agent_id: str,
        provider: str,
        config: SimulationConfig,
        ground_truth: dict[str, int],
    ) -> None:
        """Initialize the inventory agent.

        Args:
            agent_id: Unique agent identifier.
            provider: LLM provider name.
            config: Simulation configuration.
            ground_truth: Shared mutable dict mapping SKU -> current stock.
        """
        super().__init__(agent_id, provider, config)
        self._ground_truth = ground_truth

    async def run_tick(self, tick: int) -> None:
        """Observe a random SKU and publish its stock count.

        Periodic reconciliation with the external warehouse system. Order agents
        also publish belief updates on commit, so this serves as a background
        refresh that catches any external stock changes.

        Args:
            tick: Current simulation tick.
        """
        sku = random.choice(self.config.skus)
        stock = self._ground_truth.get(sku, 0)

        proof = ObservationProof.create(
            agent_id=self.agent_id,
            agent_secret=f"secret-{self.agent_id}",
            source_uri=f"warehouse://api/inventory/{sku}",
            request_params={"sku": sku, "tick": tick},
            response_body=f'{{"stock": {stock}}}',
        )

        await self.bus.update_belief(
            key=f"inventory:{sku}",
            value=stock,
            observation=proof,
        )
        # Gossip handled centrally in the simulation loop
