"""Abstract agent with NCE state."""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod

from nce.sync.state_bus import StateBus
from simulation.config import SimulationConfig

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """Abstract base class for simulation agents.

    Each agent has its own StateBus and participates in gossip-style
    delta sync.  Subclasses implement :meth:`run_tick` to process one
    simulation tick.
    """

    def __init__(
        self,
        agent_id: str,
        provider: str,
        config: SimulationConfig,
    ) -> None:
        """Initialize the agent.

        Args:
            agent_id: Unique identifier for this agent.
            provider: LLM provider name (openai / anthropic / gemini).
            config: Simulation configuration.
        """
        self.agent_id = agent_id
        self.provider = provider
        self.config = config
        self.bus = StateBus(agent_id=agent_id)
        self._peers: list["BaseAgent"] = []
        self._running = False
        self._tick_count = 0
        self.lag_ms: float = 0.0

    def register_peers(self, peers: list["BaseAgent"]) -> None:
        """Register peer agents for direct delta exchange.

        Args:
            peers: List of other agents to sync with.
        """
        self._peers = [p for p in peers if p.agent_id != self.agent_id]

    def sync_with_peers(self) -> None:
        """Push deltas to all registered peers (synchronous, simulation-safe).

        Uses :meth:`~nce.sync.state_bus.StateBus.receive_delta_sync` to avoid
        asyncio lock overhead in the single-threaded simulation event loop.
        Short-circuits when the peer's vector clock already matches ours —
        this avoids O(n_beliefs) extraction when nothing has changed.
        """
        my_vc = self.bus.query_state().vector_clock
        for peer in self._peers:
            peer_vc = peer.bus.query_state().vector_clock
            if peer_vc == my_vc:
                continue  # Already in sync — skip expensive delta extraction
            delta = self.bus.extract_delta_since(peer_vc)
            if delta.tasks or delta.beliefs or delta.capabilities:
                peer.bus.receive_delta_sync(delta)

    @abstractmethod
    async def run_tick(self, tick: int) -> None:
        """Execute one simulation tick.

        Args:
            tick: Current tick number.
        """

    async def start(self) -> None:
        """Start the agent's main loop."""
        self._running = True
        await self._main_loop()

    async def stop(self) -> None:
        """Stop the agent's main loop."""
        self._running = False

    async def _main_loop(self) -> None:
        """Internal main loop: alternates between tick and sync."""
        while self._running:
            await self.run_tick(self._tick_count)
            self._tick_count += 1
            # Simulate provider latency
            import random

            mean, std = self.config.provider_latencies.get(self.provider, (100.0, 50.0))
            delay_ms = max(0.0, random.gauss(mean, std))
            self.lag_ms = delay_ms
            await asyncio.sleep(delay_ms / 1000.0)
