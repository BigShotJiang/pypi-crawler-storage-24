"""Order team (3 agents)."""

from __future__ import annotations

import random
from typing import Any

from nce.crdt.task_status import StatusLevel
from simulation.agents.base_agent import BaseAgent
from simulation.config import SimulationConfig


class OrderAgent(BaseAgent):
    """Processes customer orders - the critical phantom commitment prevention agent.

    Checks the NCE belief register for inventory BEFORE committing an order.
    A phantom commitment occurs when an order is placed but the ground-truth
    stock is already 0 (stale NCE state led to a false positive).
    """

    def __init__(
        self,
        agent_id: str,
        provider: str,
        config: SimulationConfig,
        ground_truth: dict[str, int],
        metrics: Any,
    ) -> None:
        """Initialize the order agent.

        Args:
            agent_id: Unique agent identifier.
            provider: LLM provider name.
            config: Simulation configuration.
            ground_truth: Shared mutable dict mapping SKU -> current stock.
            metrics: MetricsCollector for recording phantom commitments.
        """
        super().__init__(agent_id, provider, config)
        self._ground_truth = ground_truth
        self._metrics = metrics
        self._order_count = 0

    async def run_tick(self, tick: int) -> None:
        """Attempt to place an order for a random SKU.

        Reads inventory from NCE state, and only commits if NCE says stock > 0.
        Checks ground truth to detect phantom commitments.

        Args:
            tick: Current simulation tick.
        """
        sku = random.choice(self.config.skus)
        # Read inventory from NCE belief register (the "local view").
        # If no causal belief has been delivered for this SKU yet, treat as
        # unavailable — NCE requires a causally-delivered observation before
        # any order can be placed (causal barrier semantics).
        state = self.bus.query_state()
        inv_belief = state.beliefs.get(f"inventory:{sku}")
        if inv_belief is None:
            return  # No causal belief delivered; NCE holds the order

        nce_stock = inv_belief.value
        if nce_stock <= 0:
            return  # NCE says out of stock - correctly rejected

        # Ground-truth check (simulates the actual reservation system commit).
        # NCE's event-driven InventoryAgent observes every stock change and
        # re-publishes immediately, so CRDT belief tracks ground truth closely.
        actual_stock = self._ground_truth.get(sku, 0)

        if actual_stock <= 0:
            # PHANTOM: CRDT belief not yet updated after depletion (propagation gap).
            self._metrics.phantom_commitments += 1
            return

        # Commit the order atomically and immediately publish the updated belief.
        # Publishing here is the core phantom-prevention mechanism: the CRDT belief
        # is updated in the same tick as the commit, so gossip propagates the depletion
        # to all peers before their next order attempt.
        new_stock = actual_stock - 1
        self._ground_truth[sku] = new_stock
        await self.bus.update_belief(f"inventory:{sku}", new_stock)

        self._order_count += 1
        # Reuse a single task ID per agent to prevent unbounded CRDT state growth.
        # The task register would otherwise accumulate O(n_transactions) entries,
        # making extract_delta O(n_transactions) and the simulation O(n²).
        order_id = f"order-{self.agent_id}-current"

        await self.bus.update_task(order_id, StatusLevel.COMPLETED)
        self._metrics.total_transactions += 1
