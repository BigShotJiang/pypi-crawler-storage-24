"""Compliance team (3 agents)."""

from __future__ import annotations


from nce.compliance.article12_mapper import compute_compliance_score
from nce.compliance.flight_recorder import FlightRecorder
from nce.crdt.vector_clock import VectorClock
from simulation.agents.base_agent import BaseAgent
from simulation.config import SimulationConfig


class ComplianceAgent(BaseAgent):
    """Monitors state transitions for regulatory compliance.

    Observes state changes in the NCE bus, records Article 12 events
    to a FlightRecorder, and periodically publishes the compliance score.
    """

    def __init__(
        self,
        agent_id: str,
        provider: str,
        config: SimulationConfig,
    ) -> None:
        """Initialize the compliance agent.

        Args:
            agent_id: Unique agent identifier.
            provider: LLM provider name.
            config: Simulation configuration.
        """
        super().__init__(agent_id, provider, config)
        self._recorder = FlightRecorder(agent_id=agent_id)
        self._last_vc = VectorClock()

    async def run_tick(self, tick: int) -> None:
        """Check for new state changes and record compliance events.

        Args:
            tick: Current simulation tick.
        """
        state = self.bus.query_state()

        # Record a compliance event for each new task/belief change
        if state.vector_clock != self._last_vc:
            from nce.utils.hashing import sha256_json

            state_hash = sha256_json(
                {
                    "tasks": len(state.tasks),
                    "beliefs": len(state.beliefs),
                    "vc": state.vector_clock.clock,
                }
            )
            self._recorder.record_state_mutation(
                event_type="state_mutation",
                state_before_hash=sha256_json({"vc": self._last_vc.clock}),
                state_after_hash=state_hash,
                vector_clock=state.vector_clock,
            )

            # Also record origin events for beliefs with observation proofs
            # Only emit for beliefs whose write_vc is not dominated by last_vc
            for key, belief in state.beliefs.items():
                if belief.observation_proof is not None and not (belief.write_vc <= self._last_vc):
                    self._recorder.record_state_mutation(
                        event_type="belief_update",
                        state_before_hash=sha256_json({"vc": self._last_vc.clock}),
                        state_after_hash=state_hash,
                        vector_clock=state.vector_clock,
                        observation_proof=belief.observation_proof,
                    )

            self._last_vc = state.vector_clock

        # Publish compliance score to NCE beliefs — throttled to every 20 ticks
        # to avoid O(n_events²) compute_compliance_score over the simulation run.
        if tick % 20 == 0:
            events = self._recorder.all_events()
            if events:
                score = compute_compliance_score(events)
                await self.bus.update_belief(
                    key=f"compliance:score:{self.agent_id}",
                    value=score,
                )

    def get_recorder(self) -> FlightRecorder:
        """Return this agent's FlightRecorder.

        Returns:
            The FlightRecorder instance.
        """
        return self._recorder
