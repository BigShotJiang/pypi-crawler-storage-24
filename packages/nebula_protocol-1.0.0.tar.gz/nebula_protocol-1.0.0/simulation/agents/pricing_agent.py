"""Pricing team (3 agents)."""

from __future__ import annotations

import random

from nce.crdt.observation_proof import ObservationProof
from simulation.agents.base_agent import BaseAgent


class PricingAgent(BaseAgent):
    """Computes and publishes dynamic prices based on inventory levels.

    Reads the inventory from the NCE belief register and applies a simple
    supply/demand heuristic: low stock → higher price.
    """

    async def run_tick(self, tick: int) -> None:
        """Compute and publish a price for a random SKU.

        Args:
            tick: Current simulation tick.
        """
        sku = random.choice(self.config.skus)
        state = self.bus.query_state()

        # Read inventory from NCE state (may be stale - that's OK, CRDT converges)
        inv_belief = state.beliefs.get(f"inventory:{sku}")
        stock = inv_belief.value if inv_belief else self.config.initial_stock

        # Simple pricing: base price scaled inversely with stock
        base_price = 100.0
        stock_ratio = max(0.1, stock / max(1, self.config.initial_stock))
        price = round(base_price / stock_ratio, 2)

        proof = ObservationProof.create(
            agent_id=self.agent_id,
            agent_secret=f"secret-{self.agent_id}",
            source_uri=f"pricing://compute/{sku}",
            request_params={"sku": sku, "stock": stock},
            response_body=f'{{"price": {price}}}',
        )

        await self.bus.update_belief(
            key=f"price:{sku}",
            value=price,
            observation=proof,
        )
        # Gossip handled centrally in the simulation loop (targeted inv→order only)
