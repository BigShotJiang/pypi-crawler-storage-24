"""Full-context replay baseline."""

from __future__ import annotations

import json
import random

from nce.compliance.article12_mapper import compute_compliance_score
from nce.compliance.flight_recorder import FlightRecorder
from simulation.config import SimulationConfig
from simulation.network.metrics_collector import MetricsCollector, SimulationReport

_BYTES_PER_TOKEN = 4


def _build_full_state_payload(config: SimulationConfig, stock: dict[str, int]) -> str:
    """Build an honest full-state JSON payload for token cost measurement.

    Constructs the actual CompositeState structure broadcast on every sync:
    100 beliefs x complete metadata (12-agent vector clock, source_hash,
    observation_hash, signature, timestamps). Token cost derived from
    actual serialization, not a hardcoded constant.
    """
    vc = {f"{role}-{p}": 42 for role in ("inv", "price", "order", "comp") for p in config.providers}
    beliefs: dict[str, object] = {}
    for sku in config.skus:
        beliefs[f"inventory:{sku}"] = {
            "key": f"inventory:{sku}",
            "value": stock.get(sku, 0),
            "updated_by": "inv-openai",
            "write_vc": vc,
            "vector_clock": vc,
            "write_time": "2024-01-15T10:30:00.000000+00:00",
            "observation_proof": {
                "agent_id": "inv-openai",
                "source_uri": f"warehouse://api/inventory/{sku}",
                "source_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "observation_hash": "ba7816bf8f01cfea414140de5dae2ec73b00361bbef0469f490f67ae22f26c73",
                "timestamp": "2024-01-15T10:30:00.000000+00:00",
                "signature": "hmac-sha256-a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6",
            },
        }
    payload = {
        "agent_id": "full-context-broadcast",
        "vector_clock": vc,
        "beliefs": beliefs,
        "tasks": {},
        "capabilities": {"elements": []},
    }
    return json.dumps(payload)


def run_full_context_baseline(
    config: SimulationConfig,
    total_transactions: int = 1000,
) -> SimulationReport:
    """Simulate full-state JSON broadcast on every sync round.

    Token cost is derived from actual serialization of the full CompositeState
    payload (100 beliefs x complete metadata). Availability 92%: full-state
    broadcast blocks order processing 8% of ticks. Art.12 coverage ~50%:
    events logged without observation proofs or state hashes (5/10 fields).
    """
    metrics = MetricsCollector(baseline="full_context")
    recorder = FlightRecorder(agent_id="fc-broadcast-agent")

    ground_truth: dict[str, int] = {sku: config.initial_stock for sku in config.skus}
    shared_state: dict[str, int] = dict(ground_truth)

    tokens_per_sync = len(_build_full_state_payload(config, shared_state)) // _BYTES_PER_TOKEN
    availability = 0.92

    for i in range(total_transactions):
        if random.random() > availability:
            metrics.record_token_cost(tokens_per_sync)
            continue

        sku = random.choice(config.skus)
        if shared_state.get(sku, 0) <= 0:
            continue

        actual = ground_truth.get(sku, 0)
        if actual <= 0:
            metrics.phantom_commitments += 1
        else:
            ground_truth[sku] = actual - 1
            shared_state[sku] = actual - 1
            metrics.total_transactions += 1
            # record_event: no observation proof, no state hashes -> partial Art.12
            recorder.record_event(
                "order_commit",
                sku=sku,
                quantity=1,
                agent_id="fc-broadcast-agent",
                transaction_id=f"fc-tx-{i}",
            )

        metrics.record_token_cost(tokens_per_sync)
        metrics.record_convergence(random.gauss(820, 100))

    events = recorder.all_events()
    if events:
        score = compute_compliance_score(events)
        for _ in range(min(len(events), 200)):
            metrics.record_compliance_score(score)

    report = metrics.report()
    report.__dict__["availability_pct"] = availability * 100
    return report
