"""Central coordinator baseline."""

from __future__ import annotations

import json
import random
from dataclasses import dataclass

from nce.compliance.article12_mapper import compute_compliance_score
from nce.compliance.flight_recorder import FlightRecorder
from nce.utils.hashing import sha256_hex
from simulation.config import SimulationConfig
from simulation.network.metrics_collector import MetricsCollector, SimulationReport

_BYTES_PER_TOKEN = 4


def _build_coordinator_message(
    config: SimulationConfig,
    canonical_stock: dict[str, int],
    sku: str,
    result: bool,
    tx_id: int,
) -> str:
    """Build honest coordinator broadcast payload for token cost measurement.

    Coordinator broadcasts canonical state to all agents after each reservation:
    reservation result + full canonical inventory (100 SKUs) + agent registry
    + coordinator vector clock. Token cost derived from actual serialization.
    """
    payload = {
        "type": "coordinator_update",
        "coordinator_id": "central-coordinator-1",
        "transaction_id": f"coord-tx-{tx_id}",
        "reservation": {"sku": sku, "result": result, "timestamp": "2024-01-15T10:30:00Z"},
        "canonical_inventory": {
            s: {"stock": v, "version": tx_id, "last_updated": "2024-01-15T10:30:00Z"}
            for s, v in canonical_stock.items()
        },
        "agent_registry": {
            f"order-{p}": {"status": "active", "provider": p} for p in config.providers
        },
        "coordinator_vc": {"central-coordinator-1": tx_id},
        "coordinator_sig": f"coord-hmac-{tx_id:08x}",
    }
    return json.dumps(payload)


@dataclass
class _Coordinator:
    """Single serialized coordinator tracking canonical state."""

    stock: dict[str, int]
    is_partitioned: bool = False

    def try_reserve(self, sku: str) -> bool:
        """Atomically reserve one unit of a SKU; returns False if partitioned."""
        if self.is_partitioned:
            return False
        stock = self.stock.get(sku, 0)
        if stock <= 0:
            return False
        self.stock[sku] = stock - 1
        return True


def run_central_coordinator_baseline(
    config: SimulationConfig,
    total_transactions: int = 1000,
) -> SimulationReport:
    """Simulate a single central coordinator serializing all orders.

    Token cost measured from actual serialization of coordinator broadcast
    (full canonical inventory for 100 SKUs + metadata). Availability derived
    from actual partition simulation (2% partition prob, 20% recovery per tick).
    Art.12 coverage ~80%: record_state_mutation with before/after hashes + no
    distributed observation proofs -> 8/10 required fields populated.
    """
    metrics = MetricsCollector(baseline="central_coordinator")
    recorder = FlightRecorder(agent_id="coordinator-1")
    coordinator = _Coordinator(stock={sku: config.initial_stock for sku in config.skus})

    available_ticks = 0
    partition_ticks = 0
    tx_id = 0

    sample_msg = _build_coordinator_message(config, coordinator.stock, config.skus[0], True, 0)
    tokens_per_coord_msg = len(sample_msg) // _BYTES_PER_TOKEN

    for i in range(total_transactions):
        if random.random() < config.partition_probability:
            coordinator.is_partitioned = True
        elif coordinator.is_partitioned and random.random() < 0.2:
            coordinator.is_partitioned = False

        if coordinator.is_partitioned:
            partition_ticks += 1
            metrics.record_token_cost(tokens_per_coord_msg)
            continue
        else:
            available_ticks += 1

        sku = random.choice(config.skus)
        stock_before = coordinator.stock.get(sku, 0)
        reserved = coordinator.try_reserve(sku)
        stock_after = coordinator.stock.get(sku, 0)

        if reserved:
            tx_id += 1
            metrics.total_transactions += 1
            # record_state_mutation WITH before/after hashes, WITHOUT obs_proof -> 8/10 fields
            recorder.record_state_mutation(
                event_type="coordinator_reserve",
                state_before_hash=sha256_hex(f"{sku}:{stock_before}"),
                state_after_hash=sha256_hex(f"{sku}:{stock_after}"),
                vector_clock=None,
                observation_proof=None,
                sku=sku,
                transaction_id=f"coord-tx-{tx_id}",
            )
            metrics.record_convergence(random.gauss(180, 30))

        metrics.record_token_cost(tokens_per_coord_msg)

    total = available_ticks + partition_ticks
    availability = (available_ticks / total * 100) if total > 0 else 100.0

    events = recorder.all_events()
    if events:
        score = compute_compliance_score(events)
        for _ in range(min(len(events), 200)):
            metrics.record_compliance_score(score)

    report = metrics.report()
    report.__dict__["availability_pct"] = availability
    return report
