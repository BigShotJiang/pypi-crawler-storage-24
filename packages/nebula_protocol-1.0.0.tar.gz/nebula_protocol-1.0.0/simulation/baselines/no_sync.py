"""No synchronization baseline."""

from __future__ import annotations

import random

from simulation.config import SimulationConfig
from simulation.network.metrics_collector import MetricsCollector, SimulationReport


def run_no_sync_baseline(
    config: SimulationConfig,
    total_transactions: int = 1000,
) -> SimulationReport:
    """Simulate agents operating without ANY synchronization.

    Expected outcome: ~2-3% phantom commitment rate due to stale state.
    Agents never sync, so each has its own independent view of inventory.

    Args:
        config: Simulation configuration.
        total_transactions: Number of order attempts to simulate.

    Returns:
        SimulationReport with phantom commitment statistics.
    """
    metrics = MetricsCollector(baseline="no_sync")

    # Ground truth stock
    ground_truth: dict[str, int] = {sku: config.initial_stock for sku in config.skus}

    # Each agent has a stale local view (initialized at start, never updated)
    num_order_agents = 3
    agent_views: list[dict[str, int]] = [
        {sku: config.initial_stock for sku in config.skus} for _ in range(num_order_agents)
    ]

    for _ in range(total_transactions):
        sku = random.choice(config.skus)
        agent_idx = random.randint(0, num_order_agents - 1)
        local_view = agent_views[agent_idx]

        local_stock = local_view.get(sku, 0)
        if local_stock <= 0:
            continue  # Agent knows it's out of stock (stale, but says no)

        actual_stock = ground_truth.get(sku, 0)

        if actual_stock <= 0:
            # Phantom: agent's stale view said stock > 0, but reality is 0.
            # The agent experiences an order failure and updates its own view
            # (learns the item is gone) — but does NOT propagate to other agents.
            metrics.phantom_commitments += 1
            local_view[sku] = max(0, local_view[sku] - 1)
        else:
            ground_truth[sku] = actual_stock - 1
            # Agent updates own local view on successful sale (knows it sold one)
            local_view[sku] = local_view[sku] - 1
            metrics.total_transactions += 1

        metrics.record_token_cost(0)  # No sync = no tokens
        metrics.record_compliance_score(0.0)  # No logging

    metrics.record_convergence(float("inf"))  # Never converges
    return metrics.report()
