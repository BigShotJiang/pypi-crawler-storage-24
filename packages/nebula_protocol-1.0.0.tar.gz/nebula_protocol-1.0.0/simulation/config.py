"""Simulation parameters."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SimulationConfig:
    """Configuration for the e-commerce multi-agent simulation.

    All time values are in milliseconds unless noted otherwise.
    """

    num_agents: int = 12  # 4 per provider (inventory, pricing, order, compliance)
    total_transactions: int = 50_000
    transactions_per_second: int = 100
    num_skus: int = 100
    initial_stock: int = 50
    jitter_ms: tuple[int, int] = (0, 200)
    packet_loss_pct: float = 5.0
    partition_probability: float = 0.02
    sync_interval_ms: int = 500
    baseline: str = "nce"  # "nce" | "no_sync" | "full_context" | "central_coordinator"

    # Provider latency profiles (mean_ms, stddev_ms)
    provider_latencies: dict[str, tuple[float, float]] = field(
        default_factory=lambda: {
            "openai": (80.0, 40.0),
            "anthropic": (100.0, 50.0),
            "gemini": (120.0, 60.0),
        }
    )

    @property
    def skus(self) -> list[str]:
        """Return the list of SKU identifiers.

        Returns:
            List of SKU strings like ``["SKU-001", "SKU-002", ...]``.
        """
        return [f"SKU-{i:03d}" for i in range(1, self.num_skus + 1)]

    @property
    def providers(self) -> list[str]:
        """Return list of provider names.

        Returns:
            List of provider name strings.
        """
        return list(self.provider_latencies.keys())
