"""Double-sell phantom commitment."""
