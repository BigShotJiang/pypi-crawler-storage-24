"""Stale-price phantom commitment."""
