"""FastAPI app + WebSocket endpoint."""

from __future__ import annotations

import asyncio
import json
import random
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from api.models.schemas import AgentStateSchema, ComplianceEventSchema, SimulationStateSchema
from api.routes.compliance import router as compliance_router
from api.routes.simulation import _results as _sim_results
from api.routes.simulation import router as simulation_router

# Benchmark constants: measured from make bench-paper (5,000 tx × 3 seeds [42, 7, 137])
# Used as fallback until actual simulations are run via POST /simulate.
_FC_TOKENS_BENCHMARK = 26_114
_NCE_TOKENS_BENCHMARK = 697

# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

_PROVIDERS = ["openai", "anthropic", "gemini"]
_ROLES = ["inventory", "pricing", "order", "compliance"]


def _build_agent_states(chaos: bool) -> list[AgentStateSchema]:
    states: list[AgentStateSchema] = []
    for role in _ROLES:
        for provider in _PROVIDERS:
            pool = (
                ["synced", "synced", "buffering", "partitioned"]
                if chaos
                else ["synced", "synced", "synced", "buffering"]
            )
            status = random.choice(pool)  # noqa: S311 - not crypto
            states.append(
                AgentStateSchema(
                    id=f"{role}-{provider}",
                    provider=provider,
                    role=role,
                    status=status,
                    lag_ms=random.randint(0, 400 if chaos else 120),  # noqa: S311
                    transactions=random.randint(0, 200),  # noqa: S311
                )
            )
    return states


# Shared simulation state (mutated by the background ticker)
_sim_state = SimulationStateSchema()
_connections: set[WebSocket] = set()

_COMPLIANCE_MESSAGES = [
    "Delta merged (inv:SKU-{sku})",
    "Proof validated for price upd",
    "Art.12 event emitted",
    "Belief register updated",
    "Capability set sync",
]


def _build_compliance_event(tick: int) -> ComplianceEventSchema:
    msg = random.choice(_COMPLIANCE_MESSAGES)  # noqa: S311
    sku = random.randint(1000, 9999)  # noqa: S311
    return ComplianceEventSchema(
        id=f"evt-{tick}",
        ts=__import__("datetime").datetime.now().strftime("%H:%M:%S"),
        message=msg.format(sku=sku) if "{sku}" in msg else msg,
    )


async def _simulation_ticker() -> None:
    """Background task: advances demo simulation state every 100ms."""
    art12 = 0.0
    while True:
        await asyncio.sleep(0.1)
        if not _sim_state.is_running:
            continue

        chaos = _sim_state.chaos_active
        new_tx = random.randint(3, 12)  # noqa: S311 scaled for 100ms

        # Update shared state in-place (no lock needed - single async loop)
        _sim_state.tick += 1
        _sim_state.elapsed_s = round(_sim_state.elapsed_s + 0.1, 1)
        _sim_state.transactions += new_tx
        _sim_state.phantom_commitments = 0
        _sim_state.convergence_p99_ms = round(250 + random.random() * 150, 1)  # noqa: S311
        # Use actual simulation results if available (populated by POST /simulate),
        # else fall back to benchmark constants from make bench-paper.
        nce_result = _sim_results.get("nce")
        fc_result = _sim_results.get("full_context")
        nce_tokens = nce_result.avg_token_cost_per_sync if nce_result else _NCE_TOKENS_BENCHMARK
        fc_tokens = fc_result.avg_token_cost_per_sync if fc_result else _FC_TOKENS_BENCHMARK
        # ±3% jitter simulates per-tick delta size variation (more active ticks = larger delta)
        jitter = int(random.gauss(0, nce_tokens * 0.03))  # noqa: S311
        _sim_state.token_cost_last_sync = max(1, round(nce_tokens) + jitter)
        _sim_state.token_saved_pct = (
            round((1 - nce_tokens / fc_tokens) * 100, 1) if fc_tokens > 0 else 0.0
        )
        art12 = min(100.0, art12 + random.random() * 0.5)  # noqa: S311
        _sim_state.art12_coverage_pct = round(art12, 1)
        _sim_state.agent_states = _build_agent_states(chaos)

        # Histogram: 10 bins 0-50, 50-100, ..., 400-500, 500+
        hist = list(_sim_state.convergence_histogram)
        bin_idx = min(9, int(_sim_state.convergence_p99_ms / 50))
        hist[bin_idx] = hist[bin_idx] + 1
        _sim_state.convergence_histogram = hist[-10:] if len(hist) > 10 else hist

        # Throughput: rolling 60s
        tps = new_tx / 0.1
        tl = list(_sim_state.throughput_timeline)
        tl.append([_sim_state.elapsed_s, round(tps, 1)])
        _sim_state.throughput_timeline = [p for p in tl if p[0] >= _sim_state.elapsed_s - 60][-600:]

        # Compliance events (max 50)
        evt = _build_compliance_event(_sim_state.tick)
        evts = [evt] + list(_sim_state.compliance_events)[:49]
        _sim_state.compliance_events = evts

        if _connections:
            payload = _sim_state.model_dump()
            dead: set[WebSocket] = set()
            for ws in _connections:
                try:
                    await ws.send_text(json.dumps(payload))
                except Exception:  # noqa: BLE001
                    dead.add(ws)
            _connections.difference_update(dead)


@asynccontextmanager
async def _lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    task = asyncio.create_task(_simulation_ticker())
    yield
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(
    title="Nebula Convergence Engine API",
    description="REST + WebSocket backend for the NCE dashboard.",
    version="0.1.0",
    lifespan=_lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(simulation_router)
app.include_router(compliance_router)


# ---------------------------------------------------------------------------
# Control endpoints
# ---------------------------------------------------------------------------


@app.post("/control/start")
async def start_simulation() -> dict:
    """Start the live demo simulation ticker."""
    _sim_state.is_running = True
    return {"status": "started"}


@app.post("/control/stop")
async def stop_simulation() -> dict:
    """Pause the live demo simulation ticker."""
    _sim_state.is_running = False
    return {"status": "stopped"}


@app.post("/control/reset")
async def reset_simulation() -> dict:
    """Reset simulation state to initial values."""
    global _sim_state  # noqa: PLW0603
    _sim_state = SimulationStateSchema()
    return {"status": "reset"}


@app.post("/control/chaos")
async def toggle_chaos() -> dict:
    """Toggle chaos mode (introduces partitions and high lag)."""
    _sim_state.chaos_active = not _sim_state.chaos_active
    return {"chaos_active": _sim_state.chaos_active}


# ---------------------------------------------------------------------------
# WebSocket endpoint
# ---------------------------------------------------------------------------


@app.websocket("/ws/simulation")
async def ws_simulation(ws: WebSocket) -> None:
    """Stream simulation state updates to connected dashboard clients.

    On connect, immediately sends the current state snapshot.
    Subsequent updates arrive every 500ms while ``is_running`` is True.
    """
    await ws.accept()
    _connections.add(ws)
    # Send current snapshot immediately on connect
    try:
        await ws.send_text(json.dumps(_sim_state.model_dump()))
        while True:
            # Keep connection alive; ticker sends updates proactively
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        _connections.discard(ws)
