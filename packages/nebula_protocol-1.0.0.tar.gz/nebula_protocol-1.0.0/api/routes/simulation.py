"""POST /simulate, GET /results"""

from __future__ import annotations

import asyncio
from typing import Any

from fastapi import APIRouter, HTTPException

from api.models.schemas import SimulateRequest, SimulateResponse
from api.routes.compliance import _store as _compliance_store
from simulation.baselines.central_coordinator import run_central_coordinator_baseline
from simulation.baselines.full_context import run_full_context_baseline
from simulation.baselines.no_sync import run_no_sync_baseline
from simulation.config import SimulationConfig
from simulation.run_simulation import run_nce_simulation_with_recorders

router = APIRouter(prefix="/simulate", tags=["simulation"])

# In-memory results store (keyed by baseline name)
_results: dict[str, Any] = {}


@router.post("", response_model=SimulateResponse)
async def run_simulation(req: SimulateRequest) -> SimulateResponse:
    """Run a single simulation baseline and return aggregated metrics.

    Args:
        req: Simulation request with baseline choice and transaction count.

    Returns:
        SimulateResponse with phantom commits, convergence p99, token cost,
        availability, and compliance coverage.

    Raises:
        HTTPException: 400 if baseline is unknown.
    """
    cfg = SimulationConfig()

    if req.baseline == "nce":
        report, compliance_agents = await run_nce_simulation_with_recorders(cfg, req.transactions)
        for ca in compliance_agents:
            _compliance_store.store_from_recorder(ca.get_recorder())
    elif req.baseline == "no_sync":
        report = await asyncio.get_event_loop().run_in_executor(
            None, run_no_sync_baseline, cfg, req.transactions
        )
    elif req.baseline == "full_context":
        report = await asyncio.get_event_loop().run_in_executor(
            None, run_full_context_baseline, cfg, req.transactions
        )
    elif req.baseline == "central_coordinator":
        report = await asyncio.get_event_loop().run_in_executor(
            None, run_central_coordinator_baseline, cfg, req.transactions
        )
    else:
        raise HTTPException(status_code=400, detail=f"Unknown baseline: {req.baseline}")

    _results[req.baseline] = report
    return SimulateResponse(
        baseline=report.baseline,
        total_transactions=report.total_transactions,
        phantom_commitments=report.phantom_commitments,
        convergence_p99_ms=report.convergence_p99_ms,
        avg_token_cost_per_sync=report.avg_token_cost_per_sync,
        availability_pct=report.availability_pct,
        avg_compliance_score=report.avg_compliance_score,
    )


@router.get("/results", response_model=list[SimulateResponse])
async def get_results() -> list[SimulateResponse]:
    """Return all cached simulation results from this server session.

    Returns:
        List of SimulateResponse for each baseline run so far.
    """
    return [
        SimulateResponse(
            baseline=r.baseline,
            total_transactions=r.total_transactions,
            phantom_commitments=r.phantom_commitments,
            convergence_p99_ms=r.convergence_p99_ms,
            avg_token_cost_per_sync=r.avg_token_cost_per_sync,
            availability_pct=r.availability_pct,
            avg_compliance_score=r.avg_compliance_score,
        )
        for r in _results.values()
    ]
