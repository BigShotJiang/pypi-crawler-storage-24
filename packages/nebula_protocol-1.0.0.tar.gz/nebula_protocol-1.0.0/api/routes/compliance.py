"""GET /compliance/report"""

from __future__ import annotations

from fastapi import APIRouter

from api.models.schemas import ComplianceReportSchema
from nce.compliance.article12_mapper import (
    _ARTICLE12_REQUIRED_FIELDS,
    compute_compliance_score,
    map_to_article12,
)
from nce.compliance.compliance_store import ComplianceStore

router = APIRouter(prefix="/compliance", tags=["compliance"])

# Module-level store shared with the server lifetime
_store = ComplianceStore()


@router.get("/report", response_model=ComplianceReportSchema)
async def get_compliance_report() -> ComplianceReportSchema:
    """Return an Article 12 compliance coverage report.

    Queries all events stored in the in-process ComplianceStore and reports:
    - total event count
    - coverage percentage (fields present / required)
    - which fields are present / missing
    - up to 5 sample events

    Returns:
        ComplianceReportSchema with coverage metrics.
    """
    events = _store.query_all()

    if not events:
        return ComplianceReportSchema(
            total_events=0,
            coverage_pct=0.0,
            fields_present=[],
            fields_missing=list(_ARTICLE12_REQUIRED_FIELDS),
            sample_events=[],
        )

    score = compute_compliance_score(events)
    mapped = [map_to_article12(e) for e in events]

    # Identify which required fields are consistently present
    fields_present = [
        f for f in _ARTICLE12_REQUIRED_FIELDS if all(row.get(f) not in (None, "") for row in mapped)
    ]
    fields_missing = [f for f in _ARTICLE12_REQUIRED_FIELDS if f not in fields_present]

    return ComplianceReportSchema(
        total_events=len(events),
        coverage_pct=round(score * 100, 1),
        fields_present=fields_present,
        fields_missing=fields_missing,
        sample_events=mapped[:5],
    )
