"""Pydantic models for API."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class AgentStateSchema(BaseModel):
    """Live state of a single simulated agent."""

    id: str
    provider: str
    role: str
    status: Literal["synced", "buffering", "partitioned"]
    lag_ms: int
    transactions: int


class ComplianceEventSchema(BaseModel):
    """Single compliance log entry for Art.12."""

    id: str
    ts: str  # ISO timestamp
    message: str  # e.g. "Delta merged (inv:SKU-4421)"


class SimulationStateSchema(BaseModel):
    """Snapshot of the running simulation broadcast via WebSocket."""

    tick: int = 0
    elapsed_s: float = 0.0
    transactions: int = 0
    phantom_commitments: int = 0
    convergence_p99_ms: float = 0.0
    token_cost_last_sync: int = 0
    token_saved_pct: float = 0.0
    art12_coverage_pct: float = 0.0
    agent_states: list[AgentStateSchema] = Field(default_factory=list)
    compliance_events: list[ComplianceEventSchema] = Field(default_factory=list)
    convergence_histogram: list[int] = Field(default_factory=lambda: [0] * 10)
    throughput_timeline: list[list[float]] = Field(default_factory=list)  # [[elapsed_s, tps], ...]
    is_running: bool = False
    chaos_active: bool = False


class SimulateRequest(BaseModel):
    """Request body for POST /simulate."""

    transactions: int = Field(default=1000, ge=1, le=100_000)
    baseline: Literal["nce", "no_sync", "full_context", "central_coordinator"] = "nce"
    chaos: bool = False


class SimulateResponse(BaseModel):
    """Response after a simulation run completes."""

    baseline: str
    total_transactions: int
    phantom_commitments: int
    convergence_p99_ms: float
    avg_token_cost_per_sync: float
    availability_pct: float
    avg_compliance_score: float


class ComplianceReportSchema(BaseModel):
    """Subset of Article 12 compliance report for the API."""

    total_events: int
    coverage_pct: float
    fields_present: list[str]
    fields_missing: list[str]
    sample_events: list[dict]
