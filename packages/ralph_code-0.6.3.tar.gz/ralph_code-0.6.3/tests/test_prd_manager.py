"""Unit tests for ralph/prd_manager.py - PRD management."""

import pytest
from pathlib import Path

from ralph.prd_manager import PRD, PRDManager, PRDQuestion, slugify


class TestSlugify:
    """Tests for the slugify function."""

    def test_lowercase_conversion(self) -> None:
        """Test that text is converted to lowercase."""
        assert slugify("Hello World") == "hello-world"

    def test_spaces_to_hyphens(self) -> None:
        """Test that spaces are converted to hyphens."""
        assert slugify("my feature name") == "my-feature-name"

    def test_underscores_to_hyphens(self) -> None:
        """Test that underscores are converted to hyphens."""
        assert slugify("my_feature_name") == "my-feature-name"

    def test_removes_special_characters(self) -> None:
        """Test that special characters are removed."""
        assert slugify("feature!@#$%name") == "featurename"

    def test_removes_multiple_hyphens(self) -> None:
        """Test that multiple consecutive hyphens are collapsed."""
        assert slugify("my---feature") == "my-feature"

    def test_strips_leading_trailing_hyphens(self) -> None:
        """Test that leading/trailing hyphens are removed."""
        assert slugify("-feature-") == "feature"

    def test_limits_length(self) -> None:
        """Test that output is limited to 50 characters."""
        long_text = "a" * 100
        assert len(slugify(long_text)) <= 50

    def test_handles_empty_string(self) -> None:
        """Test handling of empty string."""
        assert slugify("") == ""

    def test_handles_only_special_chars(self) -> None:
        """Test handling of string with only special characters."""
        assert slugify("!@#$%") == ""


class TestPRDQuestion:
    """Tests for the PRDQuestion dataclass."""

    def test_create_simple_question(self) -> None:
        """Test creating a simple question without options."""
        question = PRDQuestion(question="What is the scope?")

        assert question.question == "What is the scope?"
        assert question.options is None
        assert question.answer is None

    def test_create_question_with_options(self) -> None:
        """Test creating a question with multiple choice options."""
        question = PRDQuestion(
            question="Choose a framework:",
            options=["React", "Vue", "Angular"]
        )

        assert question.options == ["React", "Vue", "Angular"]

    def test_create_question_with_answer(self) -> None:
        """Test creating a question with an answer."""
        question = PRDQuestion(
            question="What color?",
            answer="Blue"
        )

        assert question.answer == "Blue"


class TestPRD:
    """Tests for the PRD dataclass."""

    def test_from_txt_file(self, tmp_path: Path) -> None:
        """Test creating an unspecced PRD from a .txt file."""
        txt_file = tmp_path / "my-feature.txt"
        txt_file.write_text("This is a feature description")

        prd = PRD.from_txt_file(txt_file)

        assert prd.name == "my-feature"
        assert prd.is_specced is False
        assert prd.status == "unspecced"
        assert prd.description == "This is a feature description"

    def test_from_md_file_basic(self, tmp_path: Path) -> None:
        """Test creating a specced PRD from a basic .md file."""
        md_file = tmp_path / "feature.md"
        md_file.write_text("""# PRD: My Feature

## State
- Ready to Implement

## Description
This is the feature description.
""")

        prd = PRD.from_md_file(md_file)

        assert prd.name == "My Feature"
        assert prd.is_specced is True
        assert prd.status == "pending"

    def test_from_md_file_with_questions(self, tmp_path: Path) -> None:
        """Test creating a PRD with open questions."""
        md_file = tmp_path / "feature.md"
        md_file.write_text("""# PRD: Feature with Questions

## State
- Open Questions
What is the scope?
Which database to use? ["PostgreSQL", "MySQL", "SQLite"]
""")

        prd = PRD.from_md_file(md_file)

        assert prd.status == "questions"
        assert len(prd.questions) == 2
        assert prd.questions[0].question == "What is the scope?"
        assert prd.questions[1].options == ["PostgreSQL", "MySQL", "SQLite"]

    def test_from_md_file_with_status_marker(self, tmp_path: Path) -> None:
        """Test PRD with HTML status marker."""
        md_file = tmp_path / "feature.md"
        md_file.write_text("""# PRD: Completed Feature

## State
- Ready to Implement

<!-- STATUS: completed -->
""")

        prd = PRD.from_md_file(md_file)

        assert prd.status == "completed"

    def test_start(self, tmp_path: Path) -> None:
        """Test starting a PRD."""
        txt_file = tmp_path / "feature.txt"
        txt_file.write_text("description")
        prd = PRD.from_txt_file(txt_file)

        prd.start()

        assert prd.status == "in_progress"
        assert prd.started_at is not None

    def test_complete(self, tmp_path: Path) -> None:
        """Test completing a PRD."""
        txt_file = tmp_path / "feature.txt"
        txt_file.write_text("description")
        prd = PRD.from_txt_file(txt_file)

        prd.complete()

        assert prd.status == "completed"
        assert prd.completed_at is not None

    def test_error(self, tmp_path: Path) -> None:
        """Test marking a PRD as errored."""
        txt_file = tmp_path / "feature.txt"
        txt_file.write_text("description")
        prd = PRD.from_txt_file(txt_file)

        prd.error("Something failed")

        assert prd.status == "errored"

    def test_content_property(self, tmp_path: Path) -> None:
        """Test content property returns file content."""
        txt_file = tmp_path / "feature.txt"
        txt_file.write_text("Full content here")
        prd = PRD.from_txt_file(txt_file)

        assert prd.content == "Full content here"


class TestPRDManager:
    """Tests for the PRDManager class."""

    def test_init_creates_prd_dir(self, tmp_path: Path) -> None:
        """Test that PRDManager creates the PRDs directory by default."""
        manager = PRDManager(tmp_path)

        assert manager.prd_dir == tmp_path / "PRDs"
        assert (tmp_path / "PRDs").exists()

    def test_init_uses_legacy_prd_dir_if_present(self, tmp_path: Path) -> None:
        """Test that PRDManager supports the legacy singular PRD directory."""
        legacy_dir = tmp_path / "PRD"
        legacy_dir.mkdir()

        manager = PRDManager(tmp_path)

        assert manager.prd_dir == legacy_dir

    def test_loads_txt_files(self, tmp_path: Path) -> None:
        """Test loading .txt PRD files."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature1.txt").write_text("Feature 1 description")
        (prd_dir / "feature2.txt").write_text("Feature 2 description")

        manager = PRDManager(tmp_path)

        assert len(manager.get_all_prds()) == 2

    def test_loads_md_files(self, tmp_path: Path) -> None:
        """Test loading .md PRD files."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("""# PRD: Feature
## State
- Ready to Implement
""")

        manager = PRDManager(tmp_path)

        assert len(manager.get_specced_prds()) == 1

    def test_get_unspecced_prds(self, tmp_path: Path) -> None:
        """Test getting only unspecced PRDs."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "unspecced.txt").write_text("unspecced")
        (prd_dir / "specced.md").write_text("# PRD\n## State\n- Ready")

        manager = PRDManager(tmp_path)

        unspecced = manager.get_unspecced_prds()
        assert len(unspecced) == 1
        assert unspecced[0].is_specced is False

    def test_get_pending_prds(self, tmp_path: Path) -> None:
        """Test getting pending PRDs."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "pending.md").write_text("# PRD\n## State\n- Ready to Implement")

        manager = PRDManager(tmp_path)

        pending = manager.get_pending_prds()
        assert len(pending) == 1
        assert pending[0].status == "pending"

    def test_get_questions_prds(self, tmp_path: Path) -> None:
        """Test getting PRDs with questions."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "questions.md").write_text("# PRD\n## State\n- Open Questions\nWhat scope?")

        manager = PRDManager(tmp_path)

        with_questions = manager.get_questions_prds()
        assert len(with_questions) == 1
        assert with_questions[0].status == "questions"

    def test_get_prd_by_id(self, tmp_path: Path) -> None:
        """Test getting a PRD by its ID."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.txt").write_text("description")

        manager = PRDManager(tmp_path)
        prd = manager.get_all_prds()[0]

        found = manager.get_prd_by_id(prd.id)
        assert found is not None
        assert found.id == prd.id

    def test_get_prd_by_id_not_found(self, tmp_path: Path) -> None:
        """Test getting a nonexistent PRD returns None."""
        manager = PRDManager(tmp_path)

        found = manager.get_prd_by_id("nonexistent-id")
        assert found is None

    def test_spec_prd(self, tmp_path: Path) -> None:
        """Test converting an unspecced PRD to specced."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.txt").write_text("description")

        manager = PRDManager(tmp_path)
        prd = manager.get_unspecced_prds()[0]

        new_prd = manager.spec_prd(prd, """# PRD: Feature
## State
- Ready to Implement
""")

        assert new_prd.is_specced is True
        assert not (prd_dir / "feature.txt").exists()
        assert (prd_dir / "feature.md").exists()

    def test_spec_prd_already_specced_raises(self, tmp_path: Path) -> None:
        """Test that spec_prd raises for already specced PRD."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("# PRD\n## State\n- Ready")

        manager = PRDManager(tmp_path)
        prd = manager.get_specced_prds()[0]

        with pytest.raises(ValueError, match="already specced"):
            manager.spec_prd(prd, "new content")

    def test_update_prd_status(self, tmp_path: Path) -> None:
        """Test updating a PRD's status."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("# PRD\n## State\n- Ready to Implement")

        manager = PRDManager(tmp_path)
        prd = manager.get_specced_prds()[0]

        manager.update_prd_status(prd, "completed")

        assert prd.status == "completed"
        content = (prd_dir / "feature.md").read_text()
        assert "<!-- STATUS: completed -->" in content

    def test_answer_prd_questions(self, tmp_path: Path) -> None:
        """Test answering PRD questions."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("""# PRD: Feature
## State
- Open Questions
What is the scope?
Which database?
""")

        manager = PRDManager(tmp_path)
        prd = manager.get_questions_prds()[0]

        learnings = manager.answer_prd_questions(prd, ["Full scope", "PostgreSQL"])

        assert prd.status == "pending"
        assert len(prd.questions) == 0
        assert len(learnings) == 2
        content = (prd_dir / "feature.md").read_text()
        assert "A: Full scope" in content

    def test_reload(self, tmp_path: Path) -> None:
        """Test reloading PRDs from disk."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.txt").write_text("description")

        manager = PRDManager(tmp_path)
        assert len(manager.get_all_prds()) == 1

        # Add another file
        (prd_dir / "feature2.txt").write_text("another")

        manager.reload()
        assert len(manager.get_all_prds()) == 2

    def test_prd_id_stable_across_reload(self, tmp_path: Path) -> None:
        """Test that PRD IDs are deterministic for the same file path."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("# PRD: Feature\n## State\n- Ready to Implement")

        manager = PRDManager(tmp_path)
        first = manager.get_specced_prds()[0].id

        manager.reload()
        second = manager.get_specced_prds()[0].id

        assert first == second

    def test_get_stats(self, tmp_path: Path) -> None:
        """Test getting PRD statistics."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "unspecced.txt").write_text("unspecced")
        (prd_dir / "pending.md").write_text("# PRD\n## State\n- Ready to Implement")
        (prd_dir / "questions.md").write_text("# PRD\n## State\n- Open Questions\nWhat?")

        manager = PRDManager(tmp_path)
        stats = manager.get_stats()

        assert stats["unspecced"] == 1
        assert stats["pending"] == 1
        assert stats["questions"] == 1
        assert stats["in_progress"] == 0
        assert stats["completed"] == 0
        assert stats["errored"] == 0

    def test_get_in_progress_prd(self, tmp_path: Path) -> None:
        """Test getting the in-progress PRD."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("# PRD\n## State\n- Ready\n<!-- STATUS: in_progress -->")

        manager = PRDManager(tmp_path)
        in_progress = manager.get_in_progress_prd()

        assert in_progress is not None
        assert in_progress.status == "in_progress"

    def test_get_completed_prds(self, tmp_path: Path) -> None:
        """Test getting completed PRDs."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "done.md").write_text("# PRD\n## State\n- Ready\n<!-- STATUS: completed -->")

        manager = PRDManager(tmp_path)
        completed = manager.get_completed_prds()

        assert len(completed) == 1
        assert completed[0].status == "completed"

    def test_get_errored_prds(self, tmp_path: Path) -> None:
        """Test getting errored PRDs."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "failed.md").write_text("# PRD\n## State\n- Ready\n<!-- STATUS: errored -->")

        manager = PRDManager(tmp_path)
        errored = manager.get_errored_prds()

        assert len(errored) == 1
        assert errored[0].status == "errored"
