"""Unit tests for ralph/colors.py - Nord Theme color constants."""

import pytest

from ralph.colors import (
    # Polar Night
    NORD0, NORD1, NORD2, NORD3,
    POLAR_NIGHT_0, POLAR_NIGHT_1, POLAR_NIGHT_2, POLAR_NIGHT_3,
    BG_PRIMARY, BG_SECONDARY, BG_HIGHLIGHT, BG_COMMENT,
    # Snow Storm
    NORD4, NORD5, NORD6,
    SNOW_STORM_0, SNOW_STORM_1, SNOW_STORM_2,
    FG_PRIMARY, FG_BRIGHT, FG_BRIGHTEST,
    # Frost
    NORD7, NORD8, NORD9, NORD10,
    FROST_TEAL, FROST_CYAN, FROST_LIGHT_BLUE, FROST_BLUE,
    ACCENT_PRIMARY, ACCENT_SECONDARY, ACCENT_TERTIARY, ACCENT_BUTTON,
    # Aurora
    NORD11, NORD12, NORD13, NORD14, NORD15,
    AURORA_RED, AURORA_ORANGE, AURORA_YELLOW, AURORA_GREEN, AURORA_PURPLE,
    STATE_ERROR, STATE_WARNING, STATE_PENDING, STATE_SUCCESS, STATE_INFO,
    # Collection
    ALL_NORD_COLORS,
)


class TestPolarNightColors:
    """Tests for Polar Night (background) colors."""

    def test_nord0_is_hex(self) -> None:
        """Test NORD0 is a valid hex color."""
        assert NORD0.startswith("#")
        assert len(NORD0) == 7

    def test_nord_polar_night_values(self) -> None:
        """Test all Polar Night colors have expected values."""
        assert NORD0 == "#2E3440"
        assert NORD1 == "#3B4252"
        assert NORD2 == "#434C5E"
        assert NORD3 == "#4C566A"

    def test_polar_night_aliases(self) -> None:
        """Test semantic aliases match base colors."""
        assert POLAR_NIGHT_0 == NORD0
        assert POLAR_NIGHT_1 == NORD1
        assert POLAR_NIGHT_2 == NORD2
        assert POLAR_NIGHT_3 == NORD3

    def test_background_aliases(self) -> None:
        """Test functional background aliases."""
        assert BG_PRIMARY == NORD0
        assert BG_SECONDARY == NORD1
        assert BG_HIGHLIGHT == NORD2
        assert BG_COMMENT == NORD3


class TestSnowStormColors:
    """Tests for Snow Storm (foreground) colors."""

    def test_snow_storm_values(self) -> None:
        """Test all Snow Storm colors have expected values."""
        assert NORD4 == "#D8DEE9"
        assert NORD5 == "#E5E9F0"
        assert NORD6 == "#ECEFF4"

    def test_snow_storm_aliases(self) -> None:
        """Test semantic aliases match base colors."""
        assert SNOW_STORM_0 == NORD4
        assert SNOW_STORM_1 == NORD5
        assert SNOW_STORM_2 == NORD6

    def test_foreground_aliases(self) -> None:
        """Test functional foreground aliases."""
        assert FG_PRIMARY == NORD4
        assert FG_BRIGHT == NORD5
        assert FG_BRIGHTEST == NORD6


class TestFrostColors:
    """Tests for Frost (accent) colors."""

    def test_frost_values(self) -> None:
        """Test all Frost colors have expected values."""
        assert NORD7 == "#8FBCBB"
        assert NORD8 == "#88C0D0"
        assert NORD9 == "#81A1C1"
        assert NORD10 == "#5E81AC"

    def test_frost_aliases(self) -> None:
        """Test semantic aliases match base colors."""
        assert FROST_TEAL == NORD7
        assert FROST_CYAN == NORD8
        assert FROST_LIGHT_BLUE == NORD9
        assert FROST_BLUE == NORD10

    def test_accent_aliases(self) -> None:
        """Test functional accent aliases."""
        assert ACCENT_PRIMARY == NORD8
        assert ACCENT_SECONDARY == NORD7
        assert ACCENT_TERTIARY == NORD9
        assert ACCENT_BUTTON == NORD10


class TestAuroraColors:
    """Tests for Aurora (state) colors."""

    def test_aurora_values(self) -> None:
        """Test all Aurora colors have expected values."""
        assert NORD11 == "#BF616A"
        assert NORD12 == "#D08770"
        assert NORD13 == "#EBCB8B"
        assert NORD14 == "#A3BE8C"
        assert NORD15 == "#B48EAD"

    def test_aurora_aliases(self) -> None:
        """Test semantic aliases match base colors."""
        assert AURORA_RED == NORD11
        assert AURORA_ORANGE == NORD12
        assert AURORA_YELLOW == NORD13
        assert AURORA_GREEN == NORD14
        assert AURORA_PURPLE == NORD15

    def test_state_aliases(self) -> None:
        """Test functional state aliases."""
        assert STATE_ERROR == NORD11
        assert STATE_WARNING == NORD12
        assert STATE_PENDING == NORD13
        assert STATE_SUCCESS == NORD14
        assert STATE_INFO == NORD15


class TestAllNordColors:
    """Tests for the ALL_NORD_COLORS collection."""

    def test_contains_16_colors(self) -> None:
        """Test that ALL_NORD_COLORS contains all 16 Nord colors."""
        assert len(ALL_NORD_COLORS) == 16

    def test_order_is_correct(self) -> None:
        """Test that colors are in NORD0-NORD15 order."""
        expected = (
            NORD0, NORD1, NORD2, NORD3,
            NORD4, NORD5, NORD6,
            NORD7, NORD8, NORD9, NORD10,
            NORD11, NORD12, NORD13, NORD14, NORD15,
        )
        assert ALL_NORD_COLORS == expected

    def test_all_are_valid_hex(self) -> None:
        """Test that all colors are valid hex format."""
        for color in ALL_NORD_COLORS:
            assert color.startswith("#"), f"{color} doesn't start with #"
            assert len(color) == 7, f"{color} is not 7 characters"
            # Verify hex digits
            int(color[1:], 16)  # Will raise if invalid hex
