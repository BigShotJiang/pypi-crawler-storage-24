"""Unit tests for ralph/config.py - Configuration management."""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from ralph.config import Config, DEFAULT_CONFIG, get_config


class TestDefaultConfig:
    """Tests for DEFAULT_CONFIG values."""

    def test_default_harness(self) -> None:
        """Test default harness is claude."""
        assert DEFAULT_CONFIG["harness"] == "claude"

    def test_default_worker_model(self) -> None:
        """Test default worker model is opus."""
        assert DEFAULT_CONFIG["worker_model"] == "opus"

    def test_default_summary_model(self) -> None:
        """Test default summary model is haiku."""
        assert DEFAULT_CONFIG["summary_model"] == "haiku"

    def test_default_harness_timeout(self) -> None:
        """Test default harness timeout is set."""
        assert DEFAULT_CONFIG["harness_timeout_seconds"] == 1800

    def test_default_non_interactive_max_turns(self) -> None:
        """Test default non-interactive turn cap is set."""
        assert DEFAULT_CONFIG["non_interactive_max_turns"] == 12

    def test_default_max_iterations(self) -> None:
        """Test default max iterations is 10."""
        assert DEFAULT_CONFIG["max_iterations"] == 10

    def test_default_max_story_attempts(self) -> None:
        """Test default max story attempts is 3."""
        assert DEFAULT_CONFIG["max_story_attempts"] == 3

    def test_default_branch_prefix(self) -> None:
        """Test default branch prefix is ralph."""
        assert DEFAULT_CONFIG["branch_prefix"] == "ralph"

    def test_default_on_error(self) -> None:
        """Test default error mode is block."""
        assert DEFAULT_CONFIG["on_error"] == "block"

    def test_default_pause_after_tasks(self) -> None:
        """Test unattended mode does not pause after task generation."""
        assert DEFAULT_CONFIG["pause_after_tasks"] is False


class TestConfigInit:
    """Tests for Config initialization."""

    def test_creates_config_from_empty(self, tmp_path: Path) -> None:
        """Test Config initializes with defaults when no file exists."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()

            assert config.harness == DEFAULT_CONFIG["harness"]
            assert config.worker_model == DEFAULT_CONFIG["worker_model"]

    def test_loads_existing_config(self, tmp_path: Path) -> None:
        """Test Config loads from existing file."""
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps({
            "harness": "codex",
            "worker_model": "gpt-5.2-codex",
            "summary_model": "gpt-5.2",
        }))

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()

            assert config.harness == "codex"
            assert config.worker_model == "gpt-5.2-codex"

    def test_handles_corrupted_file(self, tmp_path: Path) -> None:
        """Test Config handles corrupted JSON file."""
        config_path = tmp_path / "config.json"
        config_path.write_text("not valid json {{{")

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()

            # Should fall back to defaults
            assert config.harness == DEFAULT_CONFIG["harness"]


class TestConfigMigration:
    """Tests for configuration migration."""

    def test_migrates_claude_binary_to_harness(self, tmp_path: Path) -> None:
        """Test migration from claude_binary to harness."""
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps({
            "claude_binary": "/usr/bin/custom-claude"
        }))

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()

            assert config.harness == "/usr/bin/custom-claude"

    def test_migrates_model_to_worker_model(self, tmp_path: Path) -> None:
        """Test migration from model to worker_model."""
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps({
            "model": "sonnet"
        }))

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()

            assert config.worker_model == "sonnet"

    def test_sets_codex_defaults_for_codex_harness(self, tmp_path: Path) -> None:
        """Test that codex harness gets codex model defaults."""
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps({
            "harness": "codex"
        }))

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()

            assert config.worker_model == "gpt-5.3-codex"
            assert config.summary_model == "gpt-5.1-codex-mini"


class TestConfigProperties:
    """Tests for Config property getters and setters."""

    def test_harness_getter_setter(self, tmp_path: Path) -> None:
        """Test harness property get and set."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.harness = "/custom/harness"

            assert config.harness == "/custom/harness"

    def test_worker_model_getter_setter(self, tmp_path: Path) -> None:
        """Test worker_model property get and set."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.worker_model = "opus"

            assert config.worker_model == "opus"

    def test_summary_model_getter_setter(self, tmp_path: Path) -> None:
        """Test summary_model property get and set."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.summary_model = "haiku"

            assert config.summary_model == "haiku"

    def test_max_iterations_getter_setter(self, tmp_path: Path) -> None:
        """Test max_iterations property get and set."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.max_iterations = 20

            assert config.max_iterations == 20

    def test_max_iterations_minimum_is_1(self, tmp_path: Path) -> None:
        """Test max_iterations enforces minimum of 1."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.max_iterations = 0

            assert config.max_iterations == 1

    def test_max_story_attempts_getter_setter(self, tmp_path: Path) -> None:
        """Test max_story_attempts property get and set."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.max_story_attempts = 5

            assert config.max_story_attempts == 5

    def test_max_story_attempts_minimum_is_1(self, tmp_path: Path) -> None:
        """Test max_story_attempts enforces minimum of 1."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.max_story_attempts = -1

            assert config.max_story_attempts == 1

    def test_auto_spec_without_oversight_getter_setter(self, tmp_path: Path) -> None:
        """Test auto_spec_without_oversight property."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.auto_spec_without_oversight = False

            assert config.auto_spec_without_oversight is False

    def test_wait_on_rate_limit_getter_setter(self, tmp_path: Path) -> None:
        """Test wait_on_rate_limit property."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.wait_on_rate_limit = False

            assert config.wait_on_rate_limit is False

    def test_pause_on_completion_getter_setter(self, tmp_path: Path) -> None:
        """Test pause_on_completion property."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.pause_on_completion = False

            assert config.pause_on_completion is False

    def test_always_build_tests_getter_setter(self, tmp_path: Path) -> None:
        """Test always_build_tests property."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.always_build_tests = True

            assert config.always_build_tests is True

    def test_branch_prefix_getter_setter(self, tmp_path: Path) -> None:
        """Test branch_prefix property."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.branch_prefix = "feature"

            assert config.branch_prefix == "feature"

    def test_on_error_getter_setter(self, tmp_path: Path) -> None:
        """Test on_error property."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.on_error = "retry"

            assert config.on_error == "retry"

    def test_on_error_validates_value(self, tmp_path: Path) -> None:
        """Test on_error rejects invalid values."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()

            with pytest.raises(ValueError, match="Invalid error mode"):
                config.on_error = "invalid"  # type: ignore


class TestConfigMethods:
    """Tests for Config methods."""

    def test_to_dict_returns_copy(self, tmp_path: Path) -> None:
        """Test to_dict returns a copy of the config."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            result = config.to_dict()

            # Modifying result shouldn't affect config
            result["harness"] = "modified"
            assert config.harness != "modified"

    def test_to_dict_contains_all_keys(self, tmp_path: Path) -> None:
        """Test to_dict contains all expected keys."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            result = config.to_dict()

            for key in DEFAULT_CONFIG:
                assert key in result

    def test_reset_to_defaults(self, tmp_path: Path) -> None:
        """Test reset_to_defaults restores all defaults."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.harness = "custom"
            config.max_iterations = 99

            config.reset_to_defaults()

            assert config.harness == DEFAULT_CONFIG["harness"]
            assert config.max_iterations == DEFAULT_CONFIG["max_iterations"]


class TestConfigPersistence:
    """Tests for Config persistence to disk."""

    def test_setter_saves_to_disk(self, tmp_path: Path) -> None:
        """Test that setting a property saves to disk."""
        config_path = tmp_path / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.harness = "new-harness"

            # Read file directly to verify
            saved_data = json.loads(config_path.read_text())
            assert saved_data["harness"] == "new-harness"

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        """Test that save creates parent directories if needed."""
        config_path = tmp_path / "subdir" / "config.json"

        with patch('ralph.config.get_config_path', return_value=config_path):
            config = Config()
            config.harness = "test"

            assert config_path.exists()


class TestGetConfig:
    """Tests for get_config singleton function."""

    def test_returns_config_instance(self) -> None:
        """Test get_config returns a Config instance."""
        # Reset the global
        import ralph.config
        ralph.config._config = None

        config = get_config()
        assert isinstance(config, Config)

    def test_returns_same_instance(self) -> None:
        """Test get_config returns the same instance on subsequent calls."""
        import ralph.config
        ralph.config._config = None

        config1 = get_config()
        config2 = get_config()

        assert config1 is config2
