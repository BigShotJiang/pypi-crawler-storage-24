"""Unit tests for ralph/app.py - RalphApp class."""

import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch

from rich.panel import Panel
from questionary import Style

from ralph.app import RalphApp, main, RALPH_ART, RALPH_ART_SMALL, MENU_STYLE
from ralph.workflow import WorkflowState


class TestRalphAppInit:
    """Tests for RalphApp initialization."""

    def test_init_with_path(self, tmp_path: Path) -> None:
        """Test initialization with a valid project directory."""
        app = RalphApp(tmp_path)

        assert app.project_dir == tmp_path.resolve()
        assert app.debug is False
        assert app._workflow is None
        assert app._running is False
        assert app._last_output == ""
        assert app._live is None
        assert app._state_message == ""
        assert app._harness_available is False

    def test_init_with_debug_flag(self, tmp_path: Path) -> None:
        """Test initialization with debug mode enabled."""
        app = RalphApp(tmp_path, debug=True)

        assert app.debug is True

    def test_init_resolves_relative_path(self) -> None:
        """Test that relative paths are resolved to absolute."""
        relative_path = Path(".")
        app = RalphApp(relative_path)

        assert app.project_dir.is_absolute()
        assert app.project_dir == relative_path.resolve()

    def test_init_creates_console(self, tmp_path: Path) -> None:
        """Test that Console is created during init."""
        app = RalphApp(tmp_path)

        assert app.console is not None

    def test_init_creates_spinner(self, tmp_path: Path) -> None:
        """Test that RichSpinner is created during init."""
        app = RalphApp(tmp_path)

        assert app._spinner is not None


class TestGetStatusKey:
    """Tests for _get_status_key method."""

    def test_returns_tuple(self, tmp_path: Path, mock_workflow: MagicMock) -> None:
        """Test that status key is a tuple."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow

        key = app._get_status_key()

        assert isinstance(key, tuple)

    def test_key_includes_workflow_state(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that status key includes workflow state."""
        app = RalphApp(tmp_path)
        mock_workflow.state = WorkflowState.IMPLEMENTING
        app._workflow = mock_workflow

        key = app._get_status_key()

        assert WorkflowState.IMPLEMENTING in key

    def test_key_changes_when_state_changes(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that key changes when workflow state changes."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow

        mock_workflow.state = WorkflowState.IDLE
        key1 = app._get_status_key()

        mock_workflow.state = WorkflowState.IMPLEMENTING
        key2 = app._get_status_key()

        assert key1 != key2

    def test_key_includes_current_task_id(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that key includes current task ID when present."""
        app = RalphApp(tmp_path)
        mock_task = MagicMock()
        mock_task.id = "task-123"
        mock_workflow.current_task = mock_task
        app._workflow = mock_workflow

        key = app._get_status_key()

        assert "task-123" in key

    def test_key_includes_state_message(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that key includes state message."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow
        app._state_message = "Processing task..."

        key = app._get_status_key()

        assert "Processing task..." in key


class TestUpdateLive:
    """Tests for _update_live method."""

    def test_no_update_when_live_is_none(self, tmp_path: Path) -> None:
        """Test that nothing happens when _live is None."""
        app = RalphApp(tmp_path)
        app._live = None

        # Should not raise
        app._update_live()

    def test_updates_when_content_changes(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that live display is updated when content changes."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow
        mock_live = MagicMock()
        app._live = mock_live
        app._last_status_key = ("old", "key")

        with patch.object(app, '_build_live_status', return_value="new_panel"):
            app._update_live()

        mock_live.update.assert_called_once_with("new_panel")

    def test_no_update_when_content_unchanged(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that live display is not updated when content unchanged."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow
        mock_live = MagicMock()
        app._live = mock_live

        # Set the same key that will be computed
        same_key = app._get_status_key()
        app._last_status_key = same_key

        app._update_live()

        mock_live.update.assert_not_called()


class TestOnStateChange:
    """Tests for _on_state_change callback."""

    def test_sets_message_when_provided(self, tmp_path: Path) -> None:
        """Test that custom message is set when provided."""
        app = RalphApp(tmp_path)

        with patch.object(app, '_update_live'):
            app._on_state_change(WorkflowState.IMPLEMENTING, "Custom message")

        assert app._state_message == "Custom message"

    def test_uses_default_message_when_empty(self, tmp_path: Path) -> None:
        """Test that default message is used when message is empty."""
        app = RalphApp(tmp_path)

        with patch.object(app, '_update_live'):
            with patch(
                'ralph.app.SPINNER_MESSAGES',
                {WorkflowState.IMPLEMENTING: "Default message"}
            ):
                app._on_state_change(WorkflowState.IMPLEMENTING, "")

        assert app._state_message == "Default message"

    def test_calls_update_live(self, tmp_path: Path) -> None:
        """Test that _update_live is called after state change."""
        app = RalphApp(tmp_path)

        with patch.object(app, '_update_live') as mock_update:
            app._on_state_change(WorkflowState.IDLE, "message")

        mock_update.assert_called_once()


class TestOnOutput:
    """Tests for _on_output callback."""

    def test_sets_last_output(self, tmp_path: Path) -> None:
        """Test that last output is updated."""
        app = RalphApp(tmp_path)

        with patch.object(app, '_update_live'):
            app._on_output("New output message")

        assert app._last_output == "New output message"

    def test_calls_update_live(self, tmp_path: Path) -> None:
        """Test that _update_live is called after output."""
        app = RalphApp(tmp_path)

        with patch.object(app, '_update_live') as mock_update:
            app._on_output("message")

        mock_update.assert_called_once()


class TestGetWorkflow:
    """Tests for _get_workflow lazy initialization."""

    def test_creates_workflow_on_first_call(self, tmp_path: Path) -> None:
        """Test that workflow is created on first call."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.WorkflowEngine') as MockEngine:
            mock_wf = MagicMock()
            MockEngine.return_value = mock_wf

            result = app._get_workflow()

            MockEngine.assert_called_once()
            assert result is mock_wf

    def test_returns_cached_workflow(self, tmp_path: Path) -> None:
        """Test that subsequent calls return the same workflow."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.WorkflowEngine') as MockEngine:
            mock_wf = MagicMock()
            MockEngine.return_value = mock_wf

            result1 = app._get_workflow()
            result2 = app._get_workflow()

            MockEngine.assert_called_once()  # Only created once
            assert result1 is result2

    def test_passes_correct_arguments(self, tmp_path: Path) -> None:
        """Test that workflow is created with correct arguments."""
        app = RalphApp(tmp_path, debug=True)

        with patch('ralph.app.WorkflowEngine') as MockEngine:
            app._get_workflow()

            MockEngine.assert_called_once_with(
                tmp_path.resolve(),
                debug=True,
                on_state_change=app._on_state_change,
                on_output=app._on_output,
                use_spinner=False,
            )


class TestValidateHarness:
    """Tests for _validate_harness method."""

    def test_returns_true_when_harness_available(self, tmp_path: Path) -> None:
        """Test returns True when harness is available."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = True
            mock_from_config.return_value = mock_harness

            result = app._validate_harness()

            assert result is True
            assert app._harness_available is True

    def test_returns_false_when_skipped(self, tmp_path: Path) -> None:
        """Test returns False when harness unavailable and user skips."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = False
            mock_from_config.return_value = mock_harness

            with patch('ralph.app.HarnessDetector') as MockDetector:
                mock_detector = MagicMock()
                mock_detector.detect_all.return_value = []
                MockDetector.return_value = mock_detector

                with patch('ralph.app.questionary.select') as mock_select:
                    mock_select.return_value.ask.return_value = "skip"

                    result = app._validate_harness()

                    assert result is False
                    assert app._harness_available is False

    def test_returns_false_when_cancelled(self, tmp_path: Path) -> None:
        """Test returns False when user cancels selection."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = False
            mock_from_config.return_value = mock_harness

            with patch('ralph.app.HarnessDetector') as MockDetector:
                mock_detector = MagicMock()
                mock_detector.detect_all.return_value = []
                MockDetector.return_value = mock_detector

                with patch('ralph.app.questionary.select') as mock_select:
                    mock_select.return_value.ask.return_value = None

                    result = app._validate_harness()

                    assert result is False

    def test_offers_alternatives_when_detected(self, tmp_path: Path) -> None:
        """Test that alternatives are offered when detected."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = False
            mock_from_config.return_value = mock_harness

            with patch('ralph.app.HarnessDetector') as MockDetector:
                mock_detector = MagicMock()
                alt_harness = MagicMock()
                alt_harness.name = "codex"
                alt_harness.path = "/usr/bin/codex"
                mock_detector.detect_all.return_value = [alt_harness]
                MockDetector.return_value = mock_detector

                with patch('ralph.app.questionary.select') as mock_select:
                    # User selects the alternative
                    mock_select.return_value.ask.return_value = "/usr/bin/codex"

                    result = app._validate_harness()

                    # Should have updated the harness
                    assert app._config.harness == "/usr/bin/codex"


class TestBuildStatusPanel:
    """Tests for _build_status_panel method."""

    def test_returns_panel(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that a Panel is returned."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow

        result = app._build_status_panel()

        assert isinstance(result, Panel)

    def test_shows_prd_stats(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that PRD stats are included in panel."""
        app = RalphApp(tmp_path)
        mock_workflow.prd_manager.get_stats.return_value = {
            'unspecced': 2, 'questions': 1, 'pending': 5,
            'in_progress': 1, 'completed': 3, 'errored': 0
        }
        app._workflow = mock_workflow

        result = app._build_status_panel()

        # Panel should be created with stats
        assert result is not None

    def test_shows_questions_indicator(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that questions indicator is shown when in QUESTIONS state."""
        app = RalphApp(tmp_path)
        mock_workflow.state = WorkflowState.QUESTIONS
        mock_workflow.prd_manager.get_stats.return_value = {
            'unspecced': 0, 'questions': 2, 'pending': 0,
            'in_progress': 0, 'completed': 0, 'errored': 0
        }
        app._workflow = mock_workflow

        result = app._build_status_panel()

        assert result is not None

    def test_shows_paused_indicator(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that paused indicator is shown when workflow is paused."""
        app = RalphApp(tmp_path)
        mock_workflow.state = WorkflowState.PAUSED
        mock_workflow.is_paused = True
        app._workflow = mock_workflow

        result = app._build_status_panel()

        assert result is not None

    def test_shows_harness_unavailable(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that harness unavailable indicator is shown."""
        app = RalphApp(tmp_path)
        app._harness_available = False
        app._workflow = mock_workflow

        result = app._build_status_panel()

        assert result is not None

    def test_shows_error_message(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that error message is shown when present."""
        app = RalphApp(tmp_path)
        mock_workflow.error_message = "Something went wrong"
        app._workflow = mock_workflow

        result = app._build_status_panel()

        assert result is not None

    def test_shows_story_progress(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that story progress is shown when stories exist."""
        app = RalphApp(tmp_path)
        mock_workflow.get_story_progress.return_value = (5, 10, 50)
        app._workflow = mock_workflow

        result = app._build_status_panel()

        assert result is not None


class TestMainMenu:
    """Tests for _main_menu method."""

    def test_limited_menu_without_harness(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that limited menu is shown when harness unavailable."""
        app = RalphApp(tmp_path)
        app._harness_available = False
        app._workflow = mock_workflow

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "quit"

            app._main_menu()

            call_args = mock_select.call_args
            choices = call_args[1]['choices']
            choice_values = [c['value'] for c in choices]

            # Should not have workflow-related options
            assert "run" not in choice_values
            assert "pause" not in choice_values
            assert "resume" not in choice_values

    def test_shows_answer_with_questions(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that answer option is shown when PRDs have questions."""
        app = RalphApp(tmp_path)
        app._harness_available = True
        mock_workflow.state = WorkflowState.QUESTIONS
        mock_workflow.get_prds_with_questions.return_value = [MagicMock()]
        app._workflow = mock_workflow

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "answer"

            app._main_menu()

            call_args = mock_select.call_args
            choices = call_args[1]['choices']
            choice_values = [c['value'] for c in choices]

            assert "answer" in choice_values

    def test_shows_resume_when_paused(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that resume option is shown when workflow is paused."""
        app = RalphApp(tmp_path)
        app._harness_available = True
        mock_workflow.state = WorkflowState.PAUSED
        mock_workflow.is_paused = True
        mock_workflow.get_prds_with_questions.return_value = []
        app._workflow = mock_workflow

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "resume"

            app._main_menu()

            call_args = mock_select.call_args
            choices = call_args[1]['choices']
            choice_values = [c['value'] for c in choices]

            assert "resume" in choice_values

    def test_shows_run_when_idle(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that run option is shown when workflow is idle."""
        app = RalphApp(tmp_path)
        app._harness_available = True
        mock_workflow.state = WorkflowState.IDLE
        mock_workflow.is_paused = False
        mock_workflow.get_prds_with_questions.return_value = []
        app._workflow = mock_workflow

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "run"

            app._main_menu()

            call_args = mock_select.call_args
            choices = call_args[1]['choices']
            choice_values = [c['value'] for c in choices]

            assert "run" in choice_values

    def test_shows_stories_when_available(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that stories option is shown when stories exist."""
        app = RalphApp(tmp_path)
        app._harness_available = True
        mock_workflow.story_manager.has_tasks.return_value = True
        mock_workflow.get_prds_with_questions.return_value = []
        app._workflow = mock_workflow

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "stories"

            app._main_menu()

            call_args = mock_select.call_args
            choices = call_args[1]['choices']
            choice_values = [c['value'] for c in choices]

            assert "stories" in choice_values


class TestSetHarness:
    """Tests for _set_harness method."""

    def test_sets_config_harness(self, tmp_path: Path) -> None:
        """Test that harness path is set in config."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = True
            mock_harness.name = "claude"
            mock_harness.is_model_supported.return_value = True
            mock_from_config.return_value = mock_harness

            app._set_harness("/usr/bin/claude")

            assert app._config.harness == "/usr/bin/claude"

    def test_sets_available_true_when_valid(self, tmp_path: Path) -> None:
        """Test that _harness_available is True when harness is valid."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = True
            mock_harness.name = "claude"
            mock_harness.is_model_supported.return_value = True
            mock_from_config.return_value = mock_harness

            app._set_harness("/usr/bin/claude")

            assert app._harness_available is True

    def test_sets_available_false_when_invalid(self, tmp_path: Path) -> None:
        """Test that _harness_available is False when harness is invalid."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = False
            mock_harness.name = "invalid"
            mock_harness.is_model_supported.return_value = True
            mock_from_config.return_value = mock_harness

            app._set_harness("/nonexistent/path")

            assert app._harness_available is False

    def test_updates_worker_model(self, tmp_path: Path) -> None:
        """Test that worker model is updated when not supported by new harness."""
        app = RalphApp(tmp_path)
        app._config.worker_model = "unsupported-model"

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = True
            mock_harness.name = "claude"
            mock_harness.is_model_supported.return_value = False
            mock_harness.get_default_worker_model.return_value = "sonnet"
            mock_harness.get_default_summary_model.return_value = "haiku"
            mock_from_config.return_value = mock_harness

            app._set_harness("/usr/bin/claude")

            assert app._config.worker_model == "sonnet"

    def test_updates_summary_model(self, tmp_path: Path) -> None:
        """Test that summary model is updated when not supported."""
        app = RalphApp(tmp_path)
        app._config.summary_model = "unsupported-model"

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.is_available = True
            mock_harness.name = "claude"
            mock_harness.is_model_supported.return_value = False
            mock_harness.get_default_worker_model.return_value = "sonnet"
            mock_harness.get_default_summary_model.return_value = "haiku"
            mock_from_config.return_value = mock_harness

            app._set_harness("/usr/bin/claude")

            assert app._config.summary_model == "haiku"


class TestBuildLiveStatus:
    """Tests for _build_live_status method."""

    def test_returns_panel(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that a Panel is returned."""
        app = RalphApp(tmp_path)
        mock_workflow.state = WorkflowState.IMPLEMENTING
        app._workflow = mock_workflow

        result = app._build_live_status()

        assert isinstance(result, Panel)

    def test_shows_current_prd(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that current PRD is shown in live status."""
        app = RalphApp(tmp_path)
        mock_workflow.state = WorkflowState.IMPLEMENTING
        mock_task = MagicMock()
        mock_task.name = "test-prd"
        mock_workflow.current_task = mock_task
        app._workflow = mock_workflow

        result = app._build_live_status()

        assert result is not None

    def test_shows_current_story(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that current story is shown in live status."""
        app = RalphApp(tmp_path)
        mock_workflow.state = WorkflowState.IMPLEMENTING
        mock_story = MagicMock()
        mock_story.id = "US-001"
        mock_story.title = "Test Story"
        mock_workflow.current_story = mock_story
        app._workflow = mock_workflow

        result = app._build_live_status()

        assert result is not None

    def test_shows_spinner_for_active(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that spinner is shown for active workflow states."""
        app = RalphApp(tmp_path)
        app._state_message = "Processing..."
        mock_workflow.state = WorkflowState.IMPLEMENTING
        mock_workflow.is_paused = False
        app._workflow = mock_workflow

        result = app._build_live_status()

        assert result is not None

    def test_advances_spinner_frame(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that spinner frame is advanced for active states."""
        app = RalphApp(tmp_path)
        mock_workflow.state = WorkflowState.IMPLEMENTING
        mock_workflow.is_paused = False
        app._workflow = mock_workflow

        initial_frame = app._spinner.current_frame

        # Build live status multiple times
        app._build_live_status()
        frame_after_first = app._spinner.current_frame

        app._build_live_status()
        frame_after_second = app._spinner.current_frame

        # Frames should advance (may wrap around)
        # At least verify the method doesn't crash
        assert frame_after_first is not None
        assert frame_after_second is not None


class TestMain:
    """Tests for the main entry point function."""

    def test_uses_cwd_when_no_path(self) -> None:
        """Test that current directory is used when no path provided."""
        with patch('ralph.app.RalphApp') as MockApp:
            mock_app = MagicMock()
            MockApp.return_value = mock_app

            with patch('ralph.app.Path.cwd') as mock_cwd:
                mock_cwd.return_value = Path("/test/path")

                main()

                MockApp.assert_called_once_with(Path("/test/path"), debug=False)

    def test_uses_provided_path(self, tmp_path: Path) -> None:
        """Test that provided path is used."""
        with patch('ralph.app.RalphApp') as MockApp:
            mock_app = MagicMock()
            MockApp.return_value = mock_app

            main(project_dir=tmp_path)

            MockApp.assert_called_once_with(tmp_path, debug=False)

    def test_passes_debug_flag(self, tmp_path: Path) -> None:
        """Test that debug flag is passed to RalphApp."""
        with patch('ralph.app.RalphApp') as MockApp:
            mock_app = MagicMock()
            MockApp.return_value = mock_app

            main(project_dir=tmp_path, debug=True)

            MockApp.assert_called_once_with(tmp_path, debug=True)

    def test_calls_run(self, tmp_path: Path) -> None:
        """Test that run() is called on the app."""
        with patch('ralph.app.RalphApp') as MockApp:
            mock_app = MagicMock()
            MockApp.return_value = mock_app

            main(project_dir=tmp_path)

            mock_app.run.assert_called_once()


class TestConstants:
    """Tests for module-level constants."""

    def test_ralph_art_content(self) -> None:
        """Test that RALPH_ART contains expected ASCII art elements."""
        assert "●" in RALPH_ART  # Eyes
        assert "I'm helping!" in RALPH_ART

    def test_ralph_art_small_content(self) -> None:
        """Test that RALPH_ART_SMALL contains expected elements."""
        assert "o o" in RALPH_ART_SMALL  # Eyes
        assert "I'm helping!" in RALPH_ART_SMALL

    def test_menu_style_type(self) -> None:
        """Test that MENU_STYLE is a questionary Style object."""
        assert isinstance(MENU_STYLE, Style)
