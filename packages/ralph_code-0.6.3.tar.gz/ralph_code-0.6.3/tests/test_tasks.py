"""Unit tests for ralph/tasks.py - Task management."""

import json
import pytest
from pathlib import Path
from unittest.mock import patch

from ralph.tasks import Task, TaskManager


class TestTask:
    """Tests for the Task class."""

    def test_create_task_basic(self) -> None:
        """Test creating a basic task."""
        task = Task(name="Test Task")

        assert task.name == "Test Task"
        assert task.id is not None
        assert task.status == "pending"
        assert task.description == ""
        assert task.prerequisites == []
        assert task.acceptance_criteria == []

    def test_create_task_with_all_fields(self) -> None:
        """Test creating a task with all fields."""
        task = Task(
            name="Full Task",
            id="test-id",
            description="A description",
            status="in_progress",
            prerequisites=["prereq-1"],
            acceptance_criteria=["criterion 1"],
            files_to_modify=["file.py"],
            notes="Some notes",
        )

        assert task.id == "test-id"
        assert task.description == "A description"
        assert task.status == "in_progress"
        assert task.prerequisites == ["prereq-1"]

    def test_from_thin(self) -> None:
        """Test creating a thin task from description."""
        task = Task.from_thin("Quick task description")

        assert task.name == "Quick task description"
        assert task.is_thin is True
        assert task.is_specced is False

    def test_from_dict_string(self) -> None:
        """Test creating a task from a string (thin task)."""
        task = Task.from_dict("Thin task")

        assert task.name == "Thin task"
        assert task.is_thin is True

    def test_from_dict_full(self) -> None:
        """Test creating a task from a dictionary."""
        data = {
            "id": "task-123",
            "name": "Full Task",
            "description": "Description",
            "status": "pending",
            "prerequisites": ["p1"],
            "acceptance_criteria": ["c1"],
            "files_to_modify": ["f1.py"],
            "notes": "notes",
            "created_at": "2024-01-01T00:00:00",
        }

        task = Task.from_dict(data)

        assert task.id == "task-123"
        assert task.name == "Full Task"
        assert task.is_thin is False
        assert task.is_specced is True

    def test_to_dict(self) -> None:
        """Test converting task to dictionary."""
        task = Task(
            name="Test",
            id="test-id",
            description="desc",
            status="pending",
        )

        result = task.to_dict()

        assert result["id"] == "test-id"
        assert result["name"] == "Test"
        assert result["description"] == "desc"
        assert result["status"] == "pending"

    def test_to_serializable_thin(self) -> None:
        """Test that thin task serializes to string."""
        task = Task.from_thin("Thin task")

        result = task.to_serializable()

        assert result == "Thin task"

    def test_to_serializable_specced(self) -> None:
        """Test that specced task serializes to dict."""
        task = Task(name="Full", description="desc")

        result = task.to_serializable()

        assert isinstance(result, dict)

    def test_spec(self) -> None:
        """Test converting thin task to specced."""
        task = Task.from_thin("Thin task")

        task.spec(
            description="Full description",
            acceptance_criteria=["c1", "c2"],
            files_to_modify=["file.py"],
        )

        assert task.is_thin is False
        assert task.is_specced is True
        assert task.description == "Full description"

    def test_start(self) -> None:
        """Test starting a task."""
        task = Task(name="Test")

        task.start()

        assert task.status == "in_progress"
        assert task.started_at is not None

    def test_complete(self) -> None:
        """Test completing a task."""
        task = Task(name="Test")

        task.complete()

        assert task.status == "completed"
        assert task.completed_at is not None

    def test_error(self) -> None:
        """Test marking task as errored."""
        task = Task(name="Test")

        task.error("Something went wrong")

        assert task.status == "errored"
        assert "Something went wrong" in task.notes


class TestTaskManager:
    """Tests for the TaskManager class."""

    def test_init_creates_empty_list(self, tmp_path: Path) -> None:
        """Test initialization with no tasks file."""
        manager = TaskManager(tmp_path)

        assert manager.tasks == []

    def test_loads_existing_tasks(self, tmp_path: Path) -> None:
        """Test loading existing tasks from file."""
        ralph_dir = tmp_path / ".ralph"
        ralph_dir.mkdir()
        tasks_data = {
            "tasks": [
                {
                    "id": "12345678-1234-1234-1234-123456789abc",
                    "name": "Task 1",
                    "description": "Desc",
                    "status": "pending",
                    "prerequisites": [],
                    "acceptance_criteria": [],
                    "files_to_modify": [],
                    "notes": "",
                    "created_at": "2024-01-01T00:00:00",
                }
            ]
        }
        (ralph_dir / "tasks.json").write_text(json.dumps(tasks_data))

        manager = TaskManager(tmp_path)

        assert len(manager.tasks) == 1
        assert manager.tasks[0].name == "Task 1"

    def test_add_thin_task(self, tmp_path: Path) -> None:
        """Test adding a thin task."""
        manager = TaskManager(tmp_path)

        task = manager.add_thin_task("Quick task")

        assert task.is_thin is True
        assert len(manager.tasks) == 1
        # Verify saved
        assert (tmp_path / ".ralph" / "tasks.json").exists()

    def test_add_full_task(self, tmp_path: Path) -> None:
        """Test adding a fully specified task."""
        manager = TaskManager(tmp_path)

        task = manager.add_full_task(
            name="Full Task",
            description="Description",
            acceptance_criteria=["c1"],
        )

        assert task.is_specced is True
        assert task.description == "Description"

    def test_get_task_by_id(self, tmp_path: Path) -> None:
        """Test getting task by ID."""
        manager = TaskManager(tmp_path)
        task = manager.add_thin_task("Task")

        found = manager.get_task_by_id(task.id)

        assert found is not None
        assert found.id == task.id

    def test_get_task_by_id_not_found(self, tmp_path: Path) -> None:
        """Test getting non-existent task returns None."""
        manager = TaskManager(tmp_path)

        found = manager.get_task_by_id("nonexistent")

        assert found is None

    def test_get_unspecced_tasks(self, tmp_path: Path) -> None:
        """Test getting unspecced (thin) tasks."""
        manager = TaskManager(tmp_path)
        manager.add_thin_task("Thin task")
        manager.add_full_task("Full task", "desc")

        unspecced = manager.get_unspecced_tasks()

        assert len(unspecced) == 1
        assert unspecced[0].is_thin is True

    def test_get_specced_tasks(self, tmp_path: Path) -> None:
        """Test getting specced tasks."""
        manager = TaskManager(tmp_path)
        manager.add_thin_task("Thin task")
        manager.add_full_task("Full task", "desc")

        specced = manager.get_specced_tasks()

        assert len(specced) == 1
        assert specced[0].is_specced is True

    def test_get_pending_tasks(self, tmp_path: Path) -> None:
        """Test getting pending tasks."""
        manager = TaskManager(tmp_path)
        manager.add_full_task("Pending", "desc")
        task2 = manager.add_full_task("Completed", "desc")
        task2.complete()
        manager.update_task(task2)

        pending = manager.get_pending_tasks()

        assert len(pending) == 1
        assert pending[0].name == "Pending"

    def test_get_pending_tasks_respects_prerequisites(self, tmp_path: Path) -> None:
        """Test that pending tasks with unmet prerequisites are excluded."""
        manager = TaskManager(tmp_path)
        task1 = manager.add_full_task("Task 1", "desc")
        task2 = manager.add_full_task(
            "Task 2", "desc",
            prerequisites=[task1.id],
        )

        pending = manager.get_pending_tasks()

        # Only task1 should be pending (task2 has unmet prereq)
        assert len(pending) == 1
        assert pending[0].id == task1.id

    def test_get_in_progress_task(self, tmp_path: Path) -> None:
        """Test getting the in-progress task."""
        manager = TaskManager(tmp_path)
        task = manager.add_full_task("Task", "desc")
        task.start()
        manager.update_task(task)

        in_progress = manager.get_in_progress_task()

        assert in_progress is not None
        assert in_progress.status == "in_progress"

    def test_get_completed_tasks(self, tmp_path: Path) -> None:
        """Test getting completed tasks."""
        manager = TaskManager(tmp_path)
        task = manager.add_full_task("Task", "desc")
        task.complete()
        manager.update_task(task)

        completed = manager.get_completed_tasks()

        assert len(completed) == 1

    def test_get_errored_tasks(self, tmp_path: Path) -> None:
        """Test getting errored tasks."""
        manager = TaskManager(tmp_path)
        task = manager.add_full_task("Task", "desc")
        task.error("Failed")
        manager.update_task(task)

        errored = manager.get_errored_tasks()

        assert len(errored) == 1

    def test_update_task(self, tmp_path: Path) -> None:
        """Test updating a task."""
        manager = TaskManager(tmp_path)
        task = manager.add_full_task("Task", "desc")

        task.description = "Updated description"
        manager.update_task(task)

        # Reload and verify
        manager2 = TaskManager(tmp_path)
        updated = manager2.get_task_by_id(task.id)
        assert updated is not None
        assert updated.description == "Updated description"

    def test_update_task_not_found_raises(self, tmp_path: Path) -> None:
        """Test updating nonexistent task raises error."""
        manager = TaskManager(tmp_path)
        fake_task = Task(name="Fake", id="nonexistent")

        with pytest.raises(ValueError, match="Task not found"):
            manager.update_task(fake_task)

    def test_remove_task(self, tmp_path: Path) -> None:
        """Test removing a task."""
        manager = TaskManager(tmp_path)
        task = manager.add_full_task("Task", "desc")

        result = manager.remove_task(task.id)

        assert result is True
        assert len(manager.tasks) == 0

    def test_remove_task_not_found(self, tmp_path: Path) -> None:
        """Test removing nonexistent task returns False."""
        manager = TaskManager(tmp_path)

        result = manager.remove_task("nonexistent")

        assert result is False

    def test_get_stats(self, tmp_path: Path) -> None:
        """Test getting task statistics."""
        manager = TaskManager(tmp_path)
        manager.add_thin_task("Thin")
        task1 = manager.add_full_task("Pending", "desc")
        task2 = manager.add_full_task("Completed", "desc")
        task2.complete()
        manager.update_task(task2)

        stats = manager.get_stats()

        assert stats["unspecced"] == 1
        assert stats["pending"] == 1
        assert stats["completed"] == 1
        assert stats["in_progress"] == 0
        assert stats["errored"] == 0

    def test_handles_corrupted_file(self, tmp_path: Path) -> None:
        """Test handling of corrupted tasks file."""
        ralph_dir = tmp_path / ".ralph"
        ralph_dir.mkdir()
        (ralph_dir / "tasks.json").write_text("invalid json {{{")

        manager = TaskManager(tmp_path)

        # Should start with empty list
        assert manager.tasks == []
