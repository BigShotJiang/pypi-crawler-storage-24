"""Unit tests for ralph/user_stories.py - User Story management."""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from ralph.user_stories import UserStory, TasksFile, UserStoryManager


class TestUserStory:
    """Tests for the UserStory dataclass."""

    def test_from_dict_basic(self) -> None:
        """Test creating a UserStory from a dictionary."""
        data = {
            "id": "US-001",
            "title": "Test Story",
            "description": "A test description",
            "acceptanceCriteria": ["Criterion 1", "Criterion 2"],
            "priority": 1,
        }

        story = UserStory.from_dict(data)

        assert story.id == "US-001"
        assert story.title == "Test Story"
        assert story.description == "A test description"
        assert story.acceptance_criteria == ["Criterion 1", "Criterion 2"]
        assert story.priority == 1
        assert story.passes is False
        assert story.blocked is False
        assert story.attempts == 0

    def test_from_dict_with_all_fields(self) -> None:
        """Test creating a UserStory with all optional fields."""
        data = {
            "id": "US-002",
            "title": "Full Story",
            "description": "Description",
            "acceptanceCriteria": ["Criterion"],
            "priority": 2,
            "passes": True,
            "blocked": False,
            "needsIntervention": True,
            "notes": "Some notes",
            "attempts": 3,
        }

        story = UserStory.from_dict(data)

        assert story.passes is True
        assert story.needs_intervention is True
        assert story.notes == "Some notes"
        assert story.attempts == 3

    def test_to_dict(self) -> None:
        """Test converting UserStory to dictionary."""
        story = UserStory(
            id="US-001",
            title="Test",
            description="Desc",
            acceptance_criteria=["C1"],
            priority=1,
            passes=True,
            notes="notes",
            attempts=2,
        )

        result = story.to_dict()

        assert result["id"] == "US-001"
        assert result["title"] == "Test"
        assert result["acceptanceCriteria"] == ["C1"]
        assert result["passes"] is True
        assert result["notes"] == "notes"
        assert result["attempts"] == 2

    def test_to_dict_includes_blocked_when_true(self) -> None:
        """Test that blocked is included in dict when True."""
        story = UserStory(
            id="US-001",
            title="Test",
            description="Desc",
            acceptance_criteria=["C1"],
            priority=1,
            blocked=True,
        )

        result = story.to_dict()

        assert result["blocked"] is True

    def test_to_dict_excludes_blocked_when_false(self) -> None:
        """Test that blocked is excluded from dict when False."""
        story = UserStory(
            id="US-001",
            title="Test",
            description="Desc",
            acceptance_criteria=["C1"],
            priority=1,
            blocked=False,
        )

        result = story.to_dict()

        assert "blocked" not in result

    def test_mark_passing(self) -> None:
        """Test marking a story as passing."""
        story = UserStory(
            id="US-001",
            title="Test",
            description="Desc",
            acceptance_criteria=["C1"],
            priority=1,
        )

        story.mark_passing()

        assert story.passes is True

    def test_mark_failed(self) -> None:
        """Test marking a story as failed."""
        story = UserStory(
            id="US-001",
            title="Test",
            description="Desc",
            acceptance_criteria=["C1"],
            priority=1,
        )

        story.mark_failed("Test failed")

        assert story.passes is False
        assert story.attempts == 1
        assert "Test failed" in story.notes

    def test_mark_failed_multiple_times(self) -> None:
        """Test marking a story as failed multiple times."""
        story = UserStory(
            id="US-001",
            title="Test",
            description="Desc",
            acceptance_criteria=["C1"],
            priority=1,
        )

        story.mark_failed("First failure")
        story.mark_failed("Second failure")

        assert story.attempts == 2
        assert "Attempt 1" in story.notes
        assert "Attempt 2" in story.notes

    def test_get_prompt(self) -> None:
        """Test generating implementation prompt."""
        story = UserStory(
            id="US-001",
            title="Login Feature",
            description="Implement user login",
            acceptance_criteria=["User can enter credentials", "System validates"],
            priority=1,
        )

        prompt = story.get_prompt()

        assert "US-001" in prompt
        assert "Login Feature" in prompt
        assert "Implement user login" in prompt
        assert "User can enter credentials" in prompt

    def test_get_prompt_includes_notes(self) -> None:
        """Test that prompt includes notes from previous attempts."""
        story = UserStory(
            id="US-001",
            title="Test",
            description="Desc",
            acceptance_criteria=["C1"],
            priority=1,
            notes="Previous attempt notes",
        )

        prompt = story.get_prompt()

        assert "Previous attempt notes" in prompt
        assert "Notes from Previous Attempts" in prompt


class TestTasksFile:
    """Tests for the TasksFile dataclass."""

    def test_from_dict(self) -> None:
        """Test creating TasksFile from dictionary."""
        data = {
            "project": "test-project",
            "branchName": "ralph/test-feature",
            "description": "Test description",
            "prdFile": "PRD/test.md",
            "userStories": [
                {
                    "id": "US-001",
                    "title": "Story 1",
                    "description": "Desc",
                    "acceptanceCriteria": ["C1"],
                    "priority": 1,
                    "passes": False,
                }
            ],
        }

        tasks_file = TasksFile.from_dict(data)

        assert tasks_file.project == "test-project"
        assert tasks_file.branch_name == "ralph/test-feature"
        assert len(tasks_file.user_stories) == 1

    def test_to_dict(self) -> None:
        """Test converting TasksFile to dictionary."""
        story = UserStory(
            id="US-001",
            title="Test",
            description="Desc",
            acceptance_criteria=["C1"],
            priority=1,
        )
        tasks_file = TasksFile(
            project="test",
            branch_name="ralph/test-feature",
            description="desc",
            prd_file="PRD/test.md",
            user_stories=[story],
        )

        result = tasks_file.to_dict()

        assert result["project"] == "test"
        assert result["branchName"] == "ralph/test-feature"
        assert result["prdFile"] == "PRD/test.md"
        assert len(result["userStories"]) == 1

    def test_get_next_story(self) -> None:
        """Test getting the next story to implement."""
        story1 = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=2,
        )
        story2 = UserStory(
            id="US-002", title="S2", description="D",
            acceptance_criteria=["C"], priority=1,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story1, story2],
        )

        next_story = tasks_file.get_next_story()

        # Should return lowest priority first
        assert next_story is not None
        assert next_story.id == "US-002"

    def test_get_next_story_skips_passed(self) -> None:
        """Test that passed stories are skipped."""
        story1 = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=1, passes=True,
        )
        story2 = UserStory(
            id="US-002", title="S2", description="D",
            acceptance_criteria=["C"], priority=2,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story1, story2],
        )

        next_story = tasks_file.get_next_story()

        assert next_story is not None
        assert next_story.id == "US-002"

    def test_get_next_story_skips_blocked(self) -> None:
        """Test that blocked stories are skipped."""
        story1 = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=1, blocked=True,
        )
        story2 = UserStory(
            id="US-002", title="S2", description="D",
            acceptance_criteria=["C"], priority=2,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story1, story2],
        )

        next_story = tasks_file.get_next_story()

        assert next_story is not None
        assert next_story.id == "US-002"

    def test_get_next_story_skips_max_attempts(self) -> None:
        """Test that stories at max attempts are skipped."""
        story1 = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=1, attempts=3,
        )
        story2 = UserStory(
            id="US-002", title="S2", description="D",
            acceptance_criteria=["C"], priority=2, attempts=0,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story1, story2],
        )

        next_story = tasks_file.get_next_story(max_attempts=3)

        assert next_story is not None
        assert next_story.id == "US-002"

    def test_get_next_story_none_available(self) -> None:
        """Test when no stories are available."""
        story = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=1, passes=True,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story],
        )

        next_story = tasks_file.get_next_story()

        assert next_story is None

    def test_get_progress(self) -> None:
        """Test getting progress counts."""
        story1 = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=1, passes=True,
        )
        story2 = UserStory(
            id="US-002", title="S2", description="D",
            acceptance_criteria=["C"], priority=2, passes=False,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story1, story2],
        )

        completed, total = tasks_file.get_progress()

        assert completed == 1
        assert total == 2

    def test_get_progress_percent(self) -> None:
        """Test getting progress percentage."""
        story1 = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=1, passes=True,
        )
        story2 = UserStory(
            id="US-002", title="S2", description="D",
            acceptance_criteria=["C"], priority=2,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story1, story2],
        )

        percent = tasks_file.get_progress_percent()

        assert percent == 50

    def test_get_progress_percent_empty(self) -> None:
        """Test progress percentage with no stories."""
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[],
        )

        percent = tasks_file.get_progress_percent()

        assert percent == 0

    def test_is_complete(self) -> None:
        """Test checking if all stories are complete."""
        story1 = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=1, passes=True,
        )
        story2 = UserStory(
            id="US-002", title="S2", description="D",
            acceptance_criteria=["C"], priority=2, passes=True,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story1, story2],
        )

        assert tasks_file.is_complete() is True

    def test_is_not_complete(self) -> None:
        """Test checking incomplete stories."""
        story1 = UserStory(
            id="US-001", title="S1", description="D",
            acceptance_criteria=["C"], priority=1, passes=True,
        )
        story2 = UserStory(
            id="US-002", title="S2", description="D",
            acceptance_criteria=["C"], priority=2, passes=False,
        )
        tasks_file = TasksFile(
            project="test", branch_name="b", description="d",
            prd_file="", user_stories=[story1, story2],
        )

        assert tasks_file.is_complete() is False


class TestUserStoryManager:
    """Tests for the UserStoryManager class."""

    def test_init_no_tasks_file(self, tmp_path: Path) -> None:
        """Test initialization with no tasks.json."""
        manager = UserStoryManager(tmp_path)

        assert manager.has_tasks() is False
        assert manager.get_tasks_file() is None

    def test_loads_existing_tasks(self, tmp_path: Path) -> None:
        """Test loading existing tasks.json."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "Test",
            "userStories": [
                {
                    "id": "US-001",
                    "title": "Story",
                    "description": "Desc",
                    "acceptanceCriteria": ["C1"],
                    "priority": 1,
                    "passes": False,
                }
            ],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        manager = UserStoryManager(tmp_path)

        assert manager.has_tasks() is True
        assert len(manager.get_tasks_file().user_stories) == 1  # type: ignore

    def test_handles_corrupted_file(self, tmp_path: Path) -> None:
        """Test handling of corrupted tasks.json."""
        (tmp_path / "tasks.json").write_text("not valid json")

        manager = UserStoryManager(tmp_path)

        assert manager.has_tasks() is False

    def test_create_from_json(self, tmp_path: Path) -> None:
        """Test creating tasks from JSON string."""
        manager = UserStoryManager(tmp_path)
        tasks_json = json.dumps({
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "Test",
            "userStories": [
                {
                    "id": "US-001",
                    "title": "Story",
                    "description": "Desc",
                    "acceptanceCriteria": ["C1"],
                    "priority": 1,
                    "passes": False,
                }
            ],
        })

        result = manager.create_from_json(tasks_json, "PRD/test.md")

        assert manager.has_tasks() is True
        assert result.prd_file == "PRD/test.md"
        assert (tmp_path / "tasks.json").exists()

    def test_get_next_story(self, tmp_path: Path) -> None:
        """Test getting next story through manager."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "userStories": [
                {"id": "US-001", "title": "S", "description": "D",
                 "acceptanceCriteria": ["C"], "priority": 1, "passes": False},
            ],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        manager = UserStoryManager(tmp_path)
        story = manager.get_next_story()

        assert story is not None
        assert story.id == "US-001"

    def test_update_story(self, tmp_path: Path) -> None:
        """Test updating a story."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "userStories": [
                {"id": "US-001", "title": "S", "description": "D",
                 "acceptanceCriteria": ["C"], "priority": 1, "passes": False},
            ],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        manager = UserStoryManager(tmp_path)
        story = manager.get_next_story()
        assert story is not None
        story.passes = True

        manager.update_story(story)

        # Reload and verify
        manager.reload()
        updated_story = manager.get_tasks_file().user_stories[0]  # type: ignore
        assert updated_story.passes is True

    def test_get_progress(self, tmp_path: Path) -> None:
        """Test getting progress through manager."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "userStories": [
                {"id": "US-001", "title": "S1", "description": "D",
                 "acceptanceCriteria": ["C"], "priority": 1, "passes": True},
                {"id": "US-002", "title": "S2", "description": "D",
                 "acceptanceCriteria": ["C"], "priority": 2, "passes": False},
            ],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        manager = UserStoryManager(tmp_path)
        completed, total = manager.get_progress()

        assert completed == 1
        assert total == 2

    def test_get_branch_name(self, tmp_path: Path) -> None:
        """Test getting branch name."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/my-feature",
            "description": "d",
            "userStories": [],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        manager = UserStoryManager(tmp_path)

        assert manager.get_branch_name() == "ralph/my-feature"

    def test_clear(self, tmp_path: Path) -> None:
        """Test clearing tasks."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "userStories": [],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        manager = UserStoryManager(tmp_path)
        manager.clear()

        assert not (tmp_path / "tasks.json").exists()
        assert manager.has_tasks() is False

    def test_archive(self, tmp_path: Path) -> None:
        """Test archiving tasks."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "userStories": [],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))
        archive_dir = tmp_path / "archive"

        manager = UserStoryManager(tmp_path)
        manager.archive(archive_dir)

        assert (archive_dir / "tasks.json").exists()

    def test_get_prd_file(self, tmp_path: Path) -> None:
        """Test getting PRD file path."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "prdFile": "PRD/feature.md",
            "userStories": [],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        manager = UserStoryManager(tmp_path)

        assert manager.get_prd_file() == "PRD/feature.md"

    def test_is_complete(self, tmp_path: Path) -> None:
        """Test checking completion through manager."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "userStories": [
                {"id": "US-001", "title": "S", "description": "D",
                 "acceptanceCriteria": ["C"], "priority": 1, "passes": True},
            ],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        manager = UserStoryManager(tmp_path)

        assert manager.is_complete() is True
