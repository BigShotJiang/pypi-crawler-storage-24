"""Unit tests for ralph/workflow.py - Workflow engine."""

import json
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch

from ralph.workflow import (
    WorkflowState,
    VerificationStatus,
    WorkflowEngine,
    SPINNER_STATES,
    SPINNER_MESSAGES,
)
from ralph.user_stories import UserStory


class TestWorkflowState:
    """Tests for WorkflowState enum."""

    def test_all_states_defined(self) -> None:
        """Test that all expected states are defined."""
        expected_states = [
            "idle", "speccing", "questions", "converting", "picking",
            "implementing", "reviewing", "testing", "committing",
            "archiving", "paused", "error",
        ]
        actual_states = [s.value for s in WorkflowState]
        for state in expected_states:
            assert state in actual_states

    def test_state_values_are_lowercase(self) -> None:
        """Test that all state values are lowercase strings."""
        for state in WorkflowState:
            assert state.value == state.value.lower()


class TestVerificationStatus:
    """Tests for VerificationStatus enum."""

    def test_all_statuses_defined(self) -> None:
        """Test that all verification statuses are defined."""
        assert VerificationStatus.PASSES.value == "passes"
        assert VerificationStatus.FAILS.value == "fails"
        assert VerificationStatus.BLOCKED.value == "blocked"


class TestSpinnerStates:
    """Tests for SPINNER_STATES set."""

    def test_spinner_states_contains_active_states(self) -> None:
        """Test that spinner states include active workflow states."""
        assert WorkflowState.SPECCING in SPINNER_STATES
        assert WorkflowState.IMPLEMENTING in SPINNER_STATES
        assert WorkflowState.TESTING in SPINNER_STATES
        assert WorkflowState.COMMITTING in SPINNER_STATES

    def test_spinner_states_excludes_idle(self) -> None:
        """Test that idle states don't show spinner."""
        assert WorkflowState.IDLE not in SPINNER_STATES
        assert WorkflowState.PAUSED not in SPINNER_STATES
        assert WorkflowState.QUESTIONS not in SPINNER_STATES


class TestSpinnerMessages:
    """Tests for SPINNER_MESSAGES dict."""

    def test_messages_for_spinner_states(self) -> None:
        """Test that all spinner states have messages."""
        for state in SPINNER_STATES:
            assert state in SPINNER_MESSAGES
            assert len(SPINNER_MESSAGES[state]) > 0


class TestWorkflowEngineInit:
    """Tests for WorkflowEngine initialization."""

    def test_init_sets_project_dir(self, tmp_path: Path) -> None:
        """Test that project directory is stored."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.project_dir == tmp_path

    def test_init_default_state_is_idle(self, tmp_path: Path) -> None:
        """Test that initial state is IDLE."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.state == WorkflowState.IDLE

    def test_init_with_debug_flag(self, tmp_path: Path) -> None:
        """Test initialization with debug mode."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path, debug=True)
            assert engine.debug is True

    def test_init_with_callbacks(self, tmp_path: Path) -> None:
        """Test initialization with callbacks."""
        on_state = MagicMock()
        on_output = MagicMock()

        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(
                tmp_path,
                on_state_change=on_state,
                on_output=on_output,
            )

            assert engine.on_state_change is on_state
            assert engine.on_output is on_output


class TestWorkflowEngineProperties:
    """Tests for WorkflowEngine properties."""

    def test_state_property(self, tmp_path: Path) -> None:
        """Test state property returns current state."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.state == WorkflowState.IDLE

    def test_is_paused_property(self, tmp_path: Path) -> None:
        """Test is_paused property."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.is_paused is False

    def test_current_task_property(self, tmp_path: Path) -> None:
        """Test current_task property."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.current_task is None

    def test_current_story_property(self, tmp_path: Path) -> None:
        """Test current_story property."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.current_story is None

    def test_error_message_property(self, tmp_path: Path) -> None:
        """Test error_message property."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.error_message == ""

    def test_completed_this_session_property(self, tmp_path: Path) -> None:
        """Test completed_this_session property."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.completed_this_session == 0


class TestWorkflowEngineManagers:
    """Tests for WorkflowEngine manager access."""

    def test_prd_manager_property(self, tmp_path: Path) -> None:
        """Test prd_manager property returns PRDManager."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.prd_manager is not None

    def test_story_manager_property(self, tmp_path: Path) -> None:
        """Test story_manager property returns UserStoryManager."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            assert engine.story_manager is not None


class TestWorkflowStatePersistence:
    """Tests for workflow state persistence."""

    def test_saves_state_to_disk(self, tmp_path: Path) -> None:
        """Test that state is saved to disk."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            engine._set_state(WorkflowState.SPECCING)

            state_path = tmp_path / ".ralph" / "state.json"
            assert state_path.exists()

    def test_loads_state_from_disk(self, tmp_path: Path) -> None:
        """Test that state is loaded from disk on init."""
        # Create a state file
        ralph_dir = tmp_path / ".ralph"
        ralph_dir.mkdir(parents=True)
        state_data = {
            "state": "paused",
            "paused": True,
            "iteration": 5,
        }
        (ralph_dir / "state.json").write_text(json.dumps(state_data))

        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)

            assert engine.state == WorkflowState.PAUSED
            assert engine.is_paused is True

    def test_handles_corrupted_state_file(self, tmp_path: Path) -> None:
        """Test handling of corrupted state file."""
        ralph_dir = tmp_path / ".ralph"
        ralph_dir.mkdir(parents=True)
        (ralph_dir / "state.json").write_text("invalid json {{{")

        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)

            # Should default to IDLE
            assert engine.state == WorkflowState.IDLE


class TestWorkflowPauseResume:
    """Tests for workflow pause/resume functionality."""

    def test_pause(self, tmp_path: Path) -> None:
        """Test pausing the workflow."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            engine.pause()

            assert engine.is_paused is True

    def test_resume(self, tmp_path: Path) -> None:
        """Test resuming the workflow."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            engine.pause()
            engine.resume()

            assert engine.is_paused is False


class TestWorkflowStateCallbacks:
    """Tests for workflow state change callbacks."""

    def test_state_change_callback_called(self, tmp_path: Path) -> None:
        """Test that state change callback is called."""
        callback = MagicMock()

        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path, on_state_change=callback)
            engine._set_state(WorkflowState.SPECCING, "test message")

            callback.assert_called()
            args = callback.call_args[0]
            assert args[0] == WorkflowState.SPECCING

    def test_output_callback(self, tmp_path: Path) -> None:
        """Test that output callback works."""
        callback = MagicMock()

        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path, on_output=callback)
            engine._output("test output")

            callback.assert_called_once_with("test output")


class TestWorkflowGetters:
    """Tests for workflow getter methods."""

    def test_get_prds_with_questions(self, tmp_path: Path) -> None:
        """Test getting PRDs that have questions."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "questions.md").write_text("# PRD\n## State\n- Open Questions\nWhat scope?")

        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            prds = engine.get_prds_with_questions()

            assert len(prds) == 1

    def test_get_story_progress(self, tmp_path: Path) -> None:
        """Test getting story progress."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "userStories": [
                {"id": "US-001", "title": "S1", "description": "D",
                 "acceptanceCriteria": ["C"], "priority": 1, "passes": True},
                {"id": "US-002", "title": "S2", "description": "D",
                 "acceptanceCriteria": ["C"], "priority": 2, "passes": False},
            ],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            completed, total, percent = engine.get_story_progress()

            assert completed == 1
            assert total == 2
            assert percent == 50

    def test_get_story_progress_no_tasks(self, tmp_path: Path) -> None:
        """Test story progress with no tasks file."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            completed, total, percent = engine.get_story_progress()

            assert completed == 0
            assert total == 0
            assert percent == 0


class TestWorkflowStep:
    """Tests for workflow step execution."""

    def test_step_returns_false_when_paused(self, tmp_path: Path) -> None:
        """Test that step returns False when paused."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            engine.pause()

            result = engine.step()

            assert result is False

    def test_step_returns_false_when_idle_no_work(self, tmp_path: Path) -> None:
        """Test that step returns False when no work to do."""
        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)

            result = engine.step()

            # With no PRDs, should return False
            assert result is False


class TestWorkflowAnswerQuestions:
    """Tests for answering PRD questions."""

    def test_answer_questions(self, tmp_path: Path) -> None:
        """Test answering PRD questions."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("""# PRD: Feature
## State
- Open Questions
What is the scope?
""")

        with patch('ralph.workflow.HarnessRunner'):
            engine = WorkflowEngine(tmp_path)
            prds = engine.get_prds_with_questions()
            assert len(prds) == 1

            engine.answer_questions(prds[0], ["Full scope"])

            # Reload and check
            engine.prd_manager.reload()
            prds_after = engine.get_prds_with_questions()
            assert len(prds_after) == 0


class TestWorkflowRegressions:
    """Regression tests for workflow edge cases."""

    def test_parse_files_to_stage_handles_markdown_bullets(self, tmp_path: Path) -> None:
        """Test parser accepts bullet lists from model output."""
        with patch("ralph.workflow.HarnessRunner"):
            engine = WorkflowEngine(tmp_path)

        files = engine._parse_files_to_stage(
            "FILES_TO_STAGE:\n- src/a.py\n* src/b.py\n# note\nNONE"
        )
        assert files == ["src/a.py", "src/b.py"]

    def test_handle_error_skip_marks_prd_errored_and_continues(self, tmp_path: Path) -> None:
        """Test skip mode marks PRD errored and returns continue signal."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("# PRD: Feature\n## State\n- Ready to Implement")

        with patch("ralph.workflow.HarnessRunner"):
            engine = WorkflowEngine(tmp_path)

        engine._config = MagicMock(on_error="skip")
        prd = engine.prd_manager.get_specced_prds()[0]
        engine._current_prd = prd

        should_continue = engine._handle_error("conversion failed", prd)

        engine.prd_manager.reload()
        updated = engine.prd_manager.get_specced_prds()[0]
        assert should_continue is True
        assert updated.status == "errored"
        assert engine.current_prd is None

    def test_commit_story_blocks_when_pre_staged_changes_exist(self, tmp_path: Path) -> None:
        """Test commit safety gate blocks when there are pre-staged files."""
        with patch("ralph.workflow.HarnessRunner"):
            engine = WorkflowEngine(tmp_path)

        engine._git_manager = MagicMock()
        engine._git_manager.has_staged_changes.return_value = True
        engine._git_manager.get_staged_files.return_value = ["unrelated.py"]
        engine._git_manager.get_unstaged_files.return_value = []

        story = UserStory(
            id="US-001",
            title="Story",
            description="desc",
            acceptance_criteria=["criterion"],
            priority=1,
        )
        committed = engine._commit_story(story)

        assert committed is False
        engine._git_manager.commit_staged.assert_not_called()

    def test_step_does_not_mark_story_passed_if_commit_fails(self, tmp_path: Path) -> None:
        """Test story remains unpassed when commit fails after verification."""
        tasks_data = {
            "project": "test",
            "branchName": "ralph/test-feature",
            "description": "d",
            "userStories": [
                {
                    "id": "US-001",
                    "title": "S1",
                    "description": "D",
                    "acceptanceCriteria": ["C"],
                    "priority": 1,
                    "passes": False,
                }
            ],
        }
        (tmp_path / "tasks.json").write_text(json.dumps(tasks_data))

        with patch("ralph.workflow.HarnessRunner"):
            engine = WorkflowEngine(tmp_path)

        engine._implement_story = MagicMock(return_value=True)
        engine._verify_story = MagicMock(return_value=(VerificationStatus.PASSES, "ok"))
        engine._commit_story = MagicMock(return_value=False)
        engine._ensure_git_branch = MagicMock()

        result = engine.step()
        engine.story_manager.reload()
        story = engine.story_manager.get_tasks_file().user_stories[0]  # type: ignore[union-attr]

        assert result is False
        assert story.passes is False
        assert engine.state == WorkflowState.ERROR
        assert engine.is_paused is True

    def test_step_stops_when_conversion_pauses_workflow(self, tmp_path: Path) -> None:
        """Test step returns False when conversion succeeds but requests pause."""
        prd_dir = tmp_path / "PRD"
        prd_dir.mkdir()
        (prd_dir / "feature.md").write_text("# PRD: Feature\n## State\n- Ready to Implement")

        with patch("ralph.workflow.HarnessRunner"):
            engine = WorkflowEngine(tmp_path)

        def _fake_convert(_prd: object) -> bool:
            engine._paused = True
            engine._set_state(WorkflowState.PAUSED, "Tasks created for review")
            return True

        engine._convert_prd_to_tasks = MagicMock(side_effect=_fake_convert)
        engine._ensure_git_branch = MagicMock()

        result = engine.step()

        assert result is False
        assert engine.state == WorkflowState.PAUSED
        engine._ensure_git_branch.assert_not_called()
