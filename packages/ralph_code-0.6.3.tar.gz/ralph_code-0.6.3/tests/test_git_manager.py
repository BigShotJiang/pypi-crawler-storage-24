"""Unit tests for ralph/git_manager.py - Git operations."""

import subprocess
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from ralph.git_manager import GitManager, GitError


class TestGitManagerInit:
    """Tests for GitManager initialization."""

    def test_init_stores_project_dir(self, tmp_path: Path) -> None:
        """Test that project directory is stored."""
        manager = GitManager(tmp_path)

        assert manager.project_dir == tmp_path


class TestRunGit:
    """Tests for low-level git command execution."""

    @patch("ralph.git_manager.subprocess.run", side_effect=FileNotFoundError())
    def test_run_git_handles_missing_git(self, _mock_run: MagicMock, tmp_path: Path) -> None:
        """Test a missing git executable raises GitError."""
        manager = GitManager(tmp_path)

        with pytest.raises(GitError, match="Git executable not found on PATH"):
            manager._run_git("status")


class TestIsGitRepo:
    """Tests for is_git_repo method."""

    def test_is_git_repo_true(self, tmp_path: Path) -> None:
        """Test detecting a git repository."""
        # Initialize a real git repo
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)

        assert manager.is_git_repo() is True

    def test_is_git_repo_false(self, tmp_path: Path) -> None:
        """Test detecting non-git directory."""
        manager = GitManager(tmp_path)

        assert manager.is_git_repo() is False


class TestInitRepo:
    """Tests for init_repo method."""

    def test_init_repo_creates_git_dir(self, tmp_path: Path) -> None:
        """Test initializing a new git repository."""
        manager = GitManager(tmp_path)

        manager.init_repo()

        assert (tmp_path / ".git").exists()

    def test_init_repo_idempotent(self, tmp_path: Path) -> None:
        """Test that init_repo doesn't fail if already a repo."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        manager = GitManager(tmp_path)

        # Should not raise
        manager.init_repo()


class TestGetCurrentBranch:
    """Tests for get_current_branch method."""

    def test_get_current_branch(self, tmp_path: Path) -> None:
        """Test getting current branch name."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        # Create initial commit so branch exists
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)
        branch = manager.get_current_branch()

        # Could be 'main' or 'master' depending on git config
        assert branch in ["main", "master"]


class TestBranchExists:
    """Tests for branch_exists method."""

    def test_branch_exists_local(self, tmp_path: Path) -> None:
        """Test checking if local branch exists."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "branch", "feature"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)

        assert manager.branch_exists("feature") is True
        assert manager.branch_exists("nonexistent") is False


class TestCreateBranch:
    """Tests for create_branch method."""

    def test_create_branch(self, tmp_path: Path) -> None:
        """Test creating a new branch."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)
        manager.create_branch("new-feature")

        assert manager.branch_exists("new-feature") is True

    def test_create_branch_already_exists(self, tmp_path: Path) -> None:
        """Test that creating existing branch is a no-op."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "branch", "existing"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)

        # Should not raise
        manager.create_branch("existing")


class TestCheckoutBranch:
    """Tests for checkout_branch method."""

    def test_checkout_existing_branch(self, tmp_path: Path) -> None:
        """Test checking out an existing branch."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "branch", "feature"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)
        manager.checkout_branch("feature")

        assert manager.get_current_branch() == "feature"

    def test_checkout_creates_new_branch(self, tmp_path: Path) -> None:
        """Test that checkout creates branch if it doesn't exist."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)
        manager.checkout_branch("new-branch")

        assert manager.get_current_branch() == "new-branch"


class TestHasConflictingBranch:
    """Tests for _has_conflicting_branch method."""

    def test_detects_prefix_conflict(self, tmp_path: Path) -> None:
        """Test detecting conflicting branch names."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "branch", "ralph"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)

        # 'ralph/feature' conflicts with 'ralph'
        conflict = manager._has_conflicting_branch("ralph/feature")
        assert conflict == "ralph"

    def test_no_conflict_when_clear(self, tmp_path: Path) -> None:
        """Test no conflict with unrelated branches."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)

        conflict = manager._has_conflicting_branch("feature/new")
        assert conflict is None


class TestHasChanges:
    """Tests for has_changes method."""

    def test_has_changes_true(self, tmp_path: Path) -> None:
        """Test detecting uncommitted changes."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        # Create new uncommitted file
        (tmp_path / "new.txt").write_text("new content")

        manager = GitManager(tmp_path)

        assert manager.has_changes() is True

    def test_has_changes_false(self, tmp_path: Path) -> None:
        """Test no changes when clean."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)

        assert manager.has_changes() is False


class TestExcludePatterns:
    """Tests for EXCLUDE_PATTERNS and _should_stage."""

    def test_excludes_ralph_dir(self, tmp_path: Path) -> None:
        """Test that .ralph/ files are excluded."""
        manager = GitManager(tmp_path)

        assert manager._should_stage(".ralph/state.json") is False

    def test_excludes_claude_dir(self, tmp_path: Path) -> None:
        """Test that .claude/ files are excluded."""
        manager = GitManager(tmp_path)

        assert manager._should_stage(".claude/config.json") is False

    def test_excludes_progress_md(self, tmp_path: Path) -> None:
        """Test that progress.md is excluded."""
        manager = GitManager(tmp_path)

        assert manager._should_stage("progress.md") is False

    def test_excludes_learnings_md(self, tmp_path: Path) -> None:
        """Test that learnings.md is excluded."""
        manager = GitManager(tmp_path)

        assert manager._should_stage("learnings.md") is False

    def test_excludes_log_files(self, tmp_path: Path) -> None:
        """Test that *.log files are excluded."""
        manager = GitManager(tmp_path)

        assert manager._should_stage("debug.log") is False

    def test_excludes_pyc_files(self, tmp_path: Path) -> None:
        """Test that *.pyc files are excluded."""
        manager = GitManager(tmp_path)

        assert manager._should_stage("module.pyc") is False

    def test_excludes_env_file(self, tmp_path: Path) -> None:
        """Test that .env is excluded."""
        manager = GitManager(tmp_path)

        assert manager._should_stage(".env") is False

    def test_allows_normal_files(self, tmp_path: Path) -> None:
        """Test that normal files are allowed."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        manager = GitManager(tmp_path)

        assert manager._should_stage("src/main.py") is True
        assert manager._should_stage("README.md") is True


class TestGetStageableFiles:
    """Tests for get_stageable_files method."""

    def test_returns_modified_files(self, tmp_path: Path) -> None:
        """Test getting list of stageable files."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        (tmp_path / "new.py").write_text("new content")

        manager = GitManager(tmp_path)
        files = manager.get_stageable_files()

        assert "new.py" in files

    def test_excludes_ralph_files(self, tmp_path: Path) -> None:
        """Test that ralph files are excluded from stageable."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        (tmp_path / "progress.md").write_text("progress")
        (tmp_path / "new.py").write_text("new")

        manager = GitManager(tmp_path)
        files = manager.get_stageable_files()

        assert "new.py" in files
        assert "progress.md" not in files


class TestCommit:
    """Tests for commit methods."""

    def test_commit(self, tmp_path: Path) -> None:
        """Test creating a commit."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)
        commit_hash = manager.commit("Test commit")

        assert commit_hash is not None
        assert len(commit_hash) == 40  # SHA-1 hash length

    def test_commit_all(self, tmp_path: Path) -> None:
        """Test staging all and committing."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        (tmp_path / "new.py").write_text("new content")

        manager = GitManager(tmp_path)
        commit_hash = manager.commit_all("Add new file")

        assert commit_hash is not None
        assert manager.has_changes() is False

    def test_commit_all_no_changes(self, tmp_path: Path) -> None:
        """Test commit_all with no changes returns None."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)
        result = manager.commit_all("No changes")

        assert result is None


class TestGetDiff:
    """Tests for get_diff method."""

    def test_get_diff(self, tmp_path: Path) -> None:
        """Test getting diff of changes."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        test_file = tmp_path / "code.py"
        test_file.write_text("original content")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)
        # Modify the tracked file
        test_file.write_text("modified content here")

        manager = GitManager(tmp_path)
        diff = manager.get_diff()

        assert "modified content here" in diff

    def test_get_diff_staged_only_uses_staged_files(self, tmp_path: Path) -> None:
        """Test staged diffs ignore separate unstaged changes."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)

        staged_file = tmp_path / "staged.py"
        unstaged_file = tmp_path / "unstaged.py"
        staged_file.write_text("before staged")
        unstaged_file.write_text("before unstaged")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], cwd=tmp_path, capture_output=True)

        staged_file.write_text("after staged")
        unstaged_file.write_text("after unstaged")
        subprocess.run(["git", "add", "staged.py"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)
        diff = manager.get_diff(staged=True)

        assert "after staged" in diff
        assert "after unstaged" not in diff


class TestGetUnstagedFiles:
    """Tests for get_unstaged_files method."""

    def test_get_unstaged_files_deduplicates_results(self, tmp_path: Path) -> None:
        """Test duplicate file names are collapsed while preserving order."""
        manager = GitManager(tmp_path)

        with patch.object(
            manager,
            "_run_git",
            side_effect=[
                MagicMock(stdout="a.py\nb.py\n"),
                MagicMock(stdout="b.py\nc.py\n"),
            ],
        ):
            files = manager.get_unstaged_files()

        assert files == ["a.py", "b.py", "c.py"]


class TestGetLastCommitMessage:
    """Tests for get_last_commit_message method."""

    def test_get_last_commit_message(self, tmp_path: Path) -> None:
        """Test getting the last commit message."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=tmp_path, capture_output=True)
        (tmp_path / "test.txt").write_text("test")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit message"], cwd=tmp_path, capture_output=True)

        manager = GitManager(tmp_path)
        message = manager.get_last_commit_message()

        assert message == "Initial commit message"


class TestGitError:
    """Tests for GitError exception."""

    def test_git_error_is_exception(self) -> None:
        """Test that GitError is an Exception."""
        error = GitError("Test error")
        assert isinstance(error, Exception)
        assert str(error) == "Test error"
