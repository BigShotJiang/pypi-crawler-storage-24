"""Unit tests for ralph/storage.py - Platform-specific storage paths."""

import pytest
from pathlib import Path
from unittest.mock import patch

from ralph.storage import (
    APP_NAME,
    get_app_data_dir,
    get_config_path,
    get_project_ralph_dir,
    get_project_tasks_path,
    get_project_state_path,
    get_project_logs_dir,
    get_progress_md_path,
    get_learnings_md_path,
    get_summarised_notes_path,
)


class TestAppName:
    """Tests for the APP_NAME constant."""

    def test_app_name_value(self) -> None:
        """Test that APP_NAME has the expected value."""
        assert APP_NAME == "ralph-coding"


class TestGetAppDataDir:
    """Tests for get_app_data_dir function."""

    def test_returns_path(self) -> None:
        """Test that get_app_data_dir returns a Path object."""
        result = get_app_data_dir()
        assert isinstance(result, Path)

    def test_creates_directory(self) -> None:
        """Test that the directory is created if it doesn't exist."""
        result = get_app_data_dir()
        assert result.exists()
        assert result.is_dir()

    def test_contains_app_name(self) -> None:
        """Test that the path contains the app name."""
        result = get_app_data_dir()
        assert APP_NAME in str(result)


class TestGetConfigPath:
    """Tests for get_config_path function."""

    def test_returns_path(self) -> None:
        """Test that get_config_path returns a Path object."""
        result = get_config_path()
        assert isinstance(result, Path)

    def test_ends_with_config_json(self) -> None:
        """Test that the path ends with config.json."""
        result = get_config_path()
        assert result.name == "config.json"

    def test_parent_is_app_data_dir(self) -> None:
        """Test that the parent directory is the app data dir."""
        result = get_config_path()
        assert result.parent == get_app_data_dir()


class TestGetProjectRalphDir:
    """Tests for get_project_ralph_dir function."""

    def test_returns_path(self, tmp_path: Path) -> None:
        """Test that get_project_ralph_dir returns a Path object."""
        result = get_project_ralph_dir(tmp_path)
        assert isinstance(result, Path)

    def test_creates_directory(self, tmp_path: Path) -> None:
        """Test that the .ralph directory is created."""
        result = get_project_ralph_dir(tmp_path)
        assert result.exists()
        assert result.is_dir()

    def test_is_named_ralph(self, tmp_path: Path) -> None:
        """Test that the directory is named .ralph."""
        result = get_project_ralph_dir(tmp_path)
        assert result.name == ".ralph"

    def test_parent_is_project_dir(self, tmp_path: Path) -> None:
        """Test that the parent is the project directory."""
        result = get_project_ralph_dir(tmp_path)
        assert result.parent == tmp_path


class TestGetProjectTasksPath:
    """Tests for get_project_tasks_path function."""

    def test_returns_path(self, tmp_path: Path) -> None:
        """Test that get_project_tasks_path returns a Path object."""
        result = get_project_tasks_path(tmp_path)
        assert isinstance(result, Path)

    def test_ends_with_tasks_json(self, tmp_path: Path) -> None:
        """Test that the path ends with tasks.json."""
        result = get_project_tasks_path(tmp_path)
        assert result.name == "tasks.json"

    def test_is_in_ralph_dir(self, tmp_path: Path) -> None:
        """Test that tasks.json is inside .ralph directory."""
        result = get_project_tasks_path(tmp_path)
        assert result.parent == get_project_ralph_dir(tmp_path)


class TestGetProjectStatePath:
    """Tests for get_project_state_path function."""

    def test_returns_path(self, tmp_path: Path) -> None:
        """Test that get_project_state_path returns a Path object."""
        result = get_project_state_path(tmp_path)
        assert isinstance(result, Path)

    def test_ends_with_state_json(self, tmp_path: Path) -> None:
        """Test that the path ends with state.json."""
        result = get_project_state_path(tmp_path)
        assert result.name == "state.json"

    def test_is_in_ralph_dir(self, tmp_path: Path) -> None:
        """Test that state.json is inside .ralph directory."""
        result = get_project_state_path(tmp_path)
        assert result.parent == get_project_ralph_dir(tmp_path)


class TestGetProjectLogsDir:
    """Tests for get_project_logs_dir function."""

    def test_returns_path(self, tmp_path: Path) -> None:
        """Test that get_project_logs_dir returns a Path object."""
        result = get_project_logs_dir(tmp_path)
        assert isinstance(result, Path)

    def test_creates_directory(self, tmp_path: Path) -> None:
        """Test that the logs directory is created."""
        result = get_project_logs_dir(tmp_path)
        assert result.exists()
        assert result.is_dir()

    def test_is_named_logs(self, tmp_path: Path) -> None:
        """Test that the directory is named logs."""
        result = get_project_logs_dir(tmp_path)
        assert result.name == "logs"

    def test_is_in_ralph_dir(self, tmp_path: Path) -> None:
        """Test that logs is inside .ralph directory."""
        result = get_project_logs_dir(tmp_path)
        assert result.parent == get_project_ralph_dir(tmp_path)


class TestGetProgressMdPath:
    """Tests for get_progress_md_path function."""

    def test_returns_path(self, tmp_path: Path) -> None:
        """Test that get_progress_md_path returns a Path object."""
        result = get_progress_md_path(tmp_path)
        assert isinstance(result, Path)

    def test_ends_with_progress_md(self, tmp_path: Path) -> None:
        """Test that the path ends with progress.md."""
        result = get_progress_md_path(tmp_path)
        assert result.name == "progress.md"

    def test_is_in_project_root(self, tmp_path: Path) -> None:
        """Test that progress.md is in the project root."""
        result = get_progress_md_path(tmp_path)
        assert result.parent == tmp_path


class TestGetLearningsMdPath:
    """Tests for get_learnings_md_path function."""

    def test_returns_path(self, tmp_path: Path) -> None:
        """Test that get_learnings_md_path returns a Path object."""
        result = get_learnings_md_path(tmp_path)
        assert isinstance(result, Path)

    def test_ends_with_learnings_md(self, tmp_path: Path) -> None:
        """Test that the path ends with learnings.md."""
        result = get_learnings_md_path(tmp_path)
        assert result.name == "learnings.md"

    def test_is_in_project_root(self, tmp_path: Path) -> None:
        """Test that learnings.md is in the project root."""
        result = get_learnings_md_path(tmp_path)
        assert result.parent == tmp_path


class TestGetSummarisedNotesPath:
    """Tests for get_summarised_notes_path function."""

    def test_returns_path(self, tmp_path: Path) -> None:
        """Test that get_summarised_notes_path returns a Path object."""
        result = get_summarised_notes_path(tmp_path)
        assert isinstance(result, Path)

    def test_ends_with_summarised_notes_txt(self, tmp_path: Path) -> None:
        """Test that the path ends with summarised_notes.txt."""
        result = get_summarised_notes_path(tmp_path)
        assert result.name == "summarised_notes.txt"

    def test_is_in_ralph_dir(self, tmp_path: Path) -> None:
        """Test that summarised_notes.txt is inside .ralph directory."""
        result = get_summarised_notes_path(tmp_path)
        assert result.parent == get_project_ralph_dir(tmp_path)
