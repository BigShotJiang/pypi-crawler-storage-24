"""Integration tests for ralph/app.py interactive methods."""

import pytest
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, patch

from rich.console import Console

from ralph.app import RalphApp
from ralph.workflow import WorkflowState


class TestShowHeader:
    """Integration tests for _show_header method."""

    def test_displays_ralph_art(self, tmp_path: Path) -> None:
        """Test that header displays Ralph ASCII art."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        app._show_header()

        result = output.getvalue()
        assert "RALPH CODING" in result
        assert "I'm helping!" in result

    def test_displays_project_name(self, tmp_path: Path) -> None:
        """Test that header shows project directory name."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        app._show_header()

        result = output.getvalue()
        assert tmp_path.name in result


class TestShowPrdList:
    """Integration tests for _show_prd_list method."""

    def test_empty_message_no_prds(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that empty message is shown when no PRDs exist."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow
        mock_workflow.prd_manager.get_all_prds.return_value = []

        app._show_prd_list()

        result = output.getvalue()
        assert "No PRDs yet" in result

    def test_shows_prd_table(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_prd: MagicMock
    ) -> None:
        """Test that PRD table is displayed with PRDs."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow
        mock_workflow.prd_manager.get_all_prds.return_value = [mock_prd]

        app._show_prd_list()

        result = output.getvalue()
        assert "PRDs" in result
        assert "test-feature" in result
        assert "pending" in result

    def test_shows_correct_status_colors(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that different statuses are shown correctly."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow

        # Create PRDs with different statuses
        prds = []
        for status in ["pending", "in_progress", "completed", "errored"]:
            prd = MagicMock()
            prd.name = f"prd-{status}"
            prd.status = status
            prd.is_specced = True
            prds.append(prd)

        mock_workflow.prd_manager.get_all_prds.return_value = prds

        app._show_prd_list()

        result = output.getvalue()
        for status in ["pending", "in_progress", "completed", "errored"]:
            assert status in result


class TestShowAddTaskMenu:
    """Integration tests for _show_add_task_menu method."""

    def test_cancel_no_create(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that cancelling doesn't create a PRD."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "cancel"

            app._show_add_task_menu()

            # PRD manager should not be called
            mock_workflow.prd_manager.reload.assert_not_called()

    def test_creates_thin_prd(self, tmp_project: Path) -> None:
        """Test creating a thin PRD with valid name and description."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_project)
        app.console = console

        prd_dir = tmp_project / "PRDs"

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "thin"

            with patch('ralph.app.questionary.text') as mock_text:
                mock_text.return_value.ask.side_effect = [
                    "my-feature",
                    "Feature description"
                ]

                with patch.object(app, '_get_workflow') as mock_get_wf:
                    mock_wf = MagicMock()
                    mock_wf.prd_manager.prd_dir = prd_dir
                    mock_get_wf.return_value = mock_wf

                    app._show_add_task_menu()

                    # Check PRD was created
                    prd_file = prd_dir / "my-feature.txt"
                    assert prd_file.exists()
                    assert prd_file.read_text() == "Feature description"

    def test_none_name_no_create(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that None name (Ctrl+C) doesn't create PRD."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "thin"

            with patch('ralph.app.questionary.text') as mock_text:
                mock_text.return_value.ask.return_value = None  # User cancelled

                app._show_add_task_menu()

                mock_workflow.prd_manager.reload.assert_not_called()

    def test_empty_description_no_create(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that empty description doesn't create PRD."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "thin"

            with patch('ralph.app.questionary.text') as mock_text:
                # Name provided but description empty
                mock_text.return_value.ask.side_effect = ["my-feature", ""]

                app._show_add_task_menu()

                mock_workflow.prd_manager.reload.assert_not_called()


class TestShowSettingsMenu:
    """Integration tests for _show_settings_menu method."""

    def test_back_exits(self, tmp_path: Path) -> None:
        """Test that selecting 'back' exits the settings menu."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "back"

            app._show_settings_menu()

            # Should only be called once (then exits)
            assert mock_select.call_count == 1

    def test_toggle_auto_spec(self, tmp_path: Path) -> None:
        """Test toggling auto_spec_without_oversight setting."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        initial_value = app._config.auto_spec_without_oversight

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = ["auto_spec", "back"]

            app._show_settings_menu()

            assert app._config.auto_spec_without_oversight == (not initial_value)

    def test_toggle_rate_limit(self, tmp_path: Path) -> None:
        """Test toggling wait_on_rate_limit setting."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        initial_value = app._config.wait_on_rate_limit

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = ["rate_limit", "back"]

            app._show_settings_menu()

            assert app._config.wait_on_rate_limit == (not initial_value)

    def test_change_max_iterations(self, tmp_path: Path) -> None:
        """Test changing max_iterations setting."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = ["max_iter", "back"]

            with patch('ralph.app.questionary.text') as mock_text:
                mock_text.return_value.ask.return_value = "50"

                app._show_settings_menu()

                assert app._config.max_iterations == 50

    def test_change_branch_prefix(self, tmp_path: Path) -> None:
        """Test changing branch_prefix setting."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = ["branch_prefix", "back"]

            with patch('ralph.app.questionary.text') as mock_text:
                mock_text.return_value.ask.return_value = "feature"

                app._show_settings_menu()

                assert app._config.branch_prefix == "feature"


class TestShowModelSelection:
    """Integration tests for _show_model_selection method."""

    def test_shows_supported_models(self, tmp_path: Path) -> None:
        """Test that supported models are shown."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.name = "claude"
            mock_harness.get_supported_models.return_value = [
                ("haiku", "Light"),
                ("sonnet", "Standard"),
                ("opus", "Standard"),
            ]
            mock_from_config.return_value = mock_harness

            with patch('ralph.app.questionary.select') as mock_select:
                mock_select.return_value.ask.return_value = "cancel"

                app._show_model_selection("worker")

                # Check that select was called with model choices
                call_args = mock_select.call_args
                choices = call_args[1]['choices']
                choice_values = [c.value for c in choices]

                assert "haiku" in choice_values
                assert "sonnet" in choice_values
                assert "opus" in choice_values

    def test_cancel_no_change(self, tmp_path: Path) -> None:
        """Test that cancel keeps current model."""
        app = RalphApp(tmp_path)
        original_model = app._config.worker_model

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.name = "claude"
            mock_harness.get_supported_models.return_value = [
                ("haiku", "Light"),
                ("sonnet", "Standard"),
            ]
            mock_from_config.return_value = mock_harness

            with patch('ralph.app.questionary.select') as mock_select:
                mock_select.return_value.ask.return_value = "cancel"

                app._show_model_selection("worker")

                assert app._config.worker_model == original_model

    def test_selects_new_model(self, tmp_path: Path) -> None:
        """Test that selecting a model updates the config."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._config.worker_model = "sonnet"

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.name = "claude"
            mock_harness.get_supported_models.return_value = [
                ("haiku", "Light"),
                ("sonnet", "Standard"),
                ("opus", "Standard"),
            ]
            mock_from_config.return_value = mock_harness

            with patch('ralph.app.questionary.select') as mock_select:
                mock_select.return_value.ask.return_value = "opus"

                app._show_model_selection("worker")

                assert app._config.worker_model == "opus"

    def test_fallback_text_input(self, tmp_path: Path) -> None:
        """Test text input for custom harness with no models."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        with patch('ralph.app.Harness.from_config') as mock_from_config:
            mock_harness = MagicMock()
            mock_harness.name = "custom"
            mock_harness.get_supported_models.return_value = []  # No predefined models
            mock_from_config.return_value = mock_harness

            with patch('ralph.app.questionary.text') as mock_text:
                mock_text.return_value.ask.return_value = "custom-model"

                app._show_model_selection("worker")

                assert app._config.worker_model == "custom-model"


class TestShowHarnessSelection:
    """Integration tests for _show_harness_selection method."""

    def test_shows_detected_harnesses(self, tmp_path: Path) -> None:
        """Test that detected harnesses are shown in the menu."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.HarnessDetector') as MockDetector:
            mock_detector = MagicMock()
            mock_harness = MagicMock()
            mock_harness.name = "claude"
            mock_harness.path = "/usr/bin/claude"
            mock_detector.detect_all.return_value = [mock_harness]
            MockDetector.return_value = mock_detector

            with patch('ralph.app.questionary.select') as mock_select:
                mock_select.return_value.ask.return_value = "cancel"

                app._show_harness_selection()

                call_args = mock_select.call_args
                choices = call_args[1]['choices']
                choice_names = [c['name'] for c in choices]

                # Should include the detected harness
                assert any("claude" in name for name in choice_names)

    def test_auto_detect_option(self, tmp_path: Path) -> None:
        """Test that auto-detect option is available."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.HarnessDetector') as MockDetector:
            mock_detector = MagicMock()
            mock_detector.detect_all.return_value = []
            MockDetector.return_value = mock_detector

            with patch('ralph.app.questionary.select') as mock_select:
                mock_select.return_value.ask.return_value = "cancel"

                app._show_harness_selection()

                call_args = mock_select.call_args
                choices = call_args[1]['choices']
                choice_values = [c['value'] for c in choices]

                assert "auto-detect" in choice_values

    def test_custom_path_option(self, tmp_path: Path) -> None:
        """Test that custom path option is available."""
        app = RalphApp(tmp_path)

        with patch('ralph.app.HarnessDetector') as MockDetector:
            mock_detector = MagicMock()
            mock_detector.detect_all.return_value = []
            MockDetector.return_value = mock_detector

            with patch('ralph.app.questionary.select') as mock_select:
                mock_select.return_value.ask.return_value = "cancel"

                app._show_harness_selection()

                call_args = mock_select.call_args
                choices = call_args[1]['choices']
                choice_values = [c['value'] for c in choices]

                assert "custom" in choice_values


class TestShowManageStories:
    """Integration tests for _show_manage_stories method."""

    def test_no_stories_message(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that message is shown when no stories exist."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow
        mock_workflow.story_manager.has_tasks.return_value = False

        app._show_manage_stories()

        result = output.getvalue()
        assert "No stories to manage" in result

    def test_lists_stories(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_story: MagicMock
    ) -> None:
        """Test that stories are listed for selection."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow
        mock_workflow.story_manager.has_tasks.return_value = True

        mock_tasks_file = MagicMock()
        mock_tasks_file.user_stories = [mock_story]
        mock_workflow.story_manager.get_tasks_file.return_value = mock_tasks_file

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "back"

            app._show_manage_stories()

            # First select should list stories
            call_args = mock_select.call_args
            choices = call_args[1]['choices']
            choice_names = [c['name'] for c in choices]

            assert any("US-001" in name for name in choice_names)

    def test_mark_passed(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_story: MagicMock
    ) -> None:
        """Test marking a story as passed."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow
        mock_workflow.story_manager.has_tasks.return_value = True

        mock_tasks_file = MagicMock()
        mock_tasks_file.user_stories = [mock_story]
        mock_workflow.story_manager.get_tasks_file.return_value = mock_tasks_file

        with patch('ralph.app.questionary.select') as mock_select:
            # First select: choose story, second: mark passed, third: back, fourth: back
            mock_select.return_value.ask.side_effect = [
                "US-001",  # Select story
                "pass",    # Mark as passed
                "back",    # Back from story actions
                "back",    # Back to main menu
            ]

            app._show_manage_stories()

            assert mock_story.passes is True
            mock_workflow.story_manager.update_story.assert_called()

    def test_unblock_story(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_story: MagicMock
    ) -> None:
        """Test unblocking a story."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow
        mock_workflow.story_manager.has_tasks.return_value = True

        mock_story.blocked = True
        mock_story.passes = False
        mock_tasks_file = MagicMock()
        mock_tasks_file.user_stories = [mock_story]
        mock_workflow.story_manager.get_tasks_file.return_value = mock_tasks_file

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = [
                "US-001",   # Select story
                "unblock",  # Unblock
                "back",     # Back from story
                "back",     # Back to main
            ]

            app._show_manage_stories()

            assert mock_story.blocked is False
            assert mock_story.attempts == 0


class TestViewStoryNotes:
    """Integration tests for _view_story_notes method."""

    def test_no_notes_message(
        self, tmp_path: Path, mock_story: MagicMock
    ) -> None:
        """Test that message is shown when story has no notes."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        mock_story.notes = ""

        app._view_story_notes(mock_story)

        result = output.getvalue()
        assert "No notes" in result

    def test_shows_notes_with_pager(
        self, tmp_path: Path, mock_story: MagicMock
    ) -> None:
        """Test that notes are shown using pager."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        mock_story.notes = "These are test notes\n" * 10

        with patch.object(console, 'pager') as mock_pager:
            mock_context = MagicMock()
            mock_pager.return_value.__enter__ = MagicMock(return_value=mock_context)
            mock_pager.return_value.__exit__ = MagicMock(return_value=False)

            app._view_story_notes(mock_story)

            mock_pager.assert_called_once()


class TestShowAnswerQuestions:
    """Integration tests for _show_answer_questions method."""

    def test_no_questions_message(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that message is shown when no questions exist."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow
        mock_workflow.get_prds_with_questions.return_value = []

        app._show_answer_questions()

        result = output.getvalue()
        assert "No PRDs have open questions" in result

    def test_answers_free_form(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_prd: MagicMock
    ) -> None:
        """Test answering free-form questions."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow

        mock_question = MagicMock()
        mock_question.question = "What is the feature scope?"
        mock_question.options = []  # Free-form
        mock_prd.questions = [mock_question]
        mock_workflow.get_prds_with_questions.return_value = [mock_prd]

        with patch('ralph.app.questionary.text') as mock_text:
            mock_text.return_value.ask.return_value = "Full scope answer"

            with patch('ralph.app.questionary.confirm') as mock_confirm:
                mock_confirm.return_value.ask.return_value = True

                app._show_answer_questions()

                mock_workflow.answer_questions.assert_called_once()

    def test_answers_multiple_choice(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_prd: MagicMock
    ) -> None:
        """Test answering multiple choice questions."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow

        mock_question = MagicMock()
        mock_question.question = "Which option?"
        mock_question.options = ["Option A", "Option B", "Option C"]
        mock_prd.questions = [mock_question]
        mock_workflow.get_prds_with_questions.return_value = [mock_prd]

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.return_value = "Option B"

            with patch('ralph.app.questionary.confirm') as mock_confirm:
                mock_confirm.return_value.ask.return_value = True

                app._show_answer_questions()

                mock_workflow.answer_questions.assert_called_once()
                # Verify the answer was "Option B"
                call_args = mock_workflow.answer_questions.call_args
                answers = call_args[0][1]
                assert "Option B" in answers


class TestRunWorkflow:
    """Integration tests for _run_workflow method."""

    def test_resumes_if_paused(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that paused workflow is resumed."""
        app = RalphApp(tmp_path)
        app._workflow = mock_workflow
        mock_workflow.is_paused = True
        mock_workflow.step.return_value = False  # Complete immediately

        with patch('ralph.app.Live'):
            app._run_workflow()

        mock_workflow.resume.assert_called_once()

    def test_shows_completion_message(
        self, tmp_path: Path, mock_workflow: MagicMock
    ) -> None:
        """Test that completion message is shown."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console
        app._workflow = mock_workflow
        mock_workflow.is_paused = False
        mock_workflow.state = WorkflowState.IDLE
        mock_workflow.step.return_value = False  # Complete immediately
        mock_workflow.prd_manager.get_stats.return_value = {
            'unspecced': 0, 'questions': 0, 'pending': 0,
            'in_progress': 0, 'completed': 5, 'errored': 0
        }

        with patch('ralph.app.Live'):
            app._run_workflow()

        result = output.getvalue()
        assert "All PRDs completed" in result


@pytest.mark.integration
class TestEditAcceptanceCriteria:
    """Integration tests for acceptance criteria editing."""

    def test_edit_single_criterion(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_story: MagicMock
    ) -> None:
        """Test editing a single criterion."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        mock_story.acceptance_criteria = ["Original criterion"]

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = [
                "edit",  # Select edit action
                0,       # Select first criterion
                "done",  # Done editing
            ]

            with patch('ralph.app.questionary.text') as mock_text:
                mock_text.return_value.ask.return_value = "Updated criterion"

                app._edit_acceptance_criteria(mock_story, mock_workflow)

                assert mock_story.acceptance_criteria[0] == "Updated criterion"
                mock_workflow.story_manager.update_story.assert_called()

    def test_add_criterion(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_story: MagicMock
    ) -> None:
        """Test adding a new criterion."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        mock_story.acceptance_criteria = ["Existing criterion"]

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = [
                "add",   # Select add action
                "done",  # Done editing
            ]

            with patch('ralph.app.questionary.text') as mock_text:
                mock_text.return_value.ask.return_value = "New criterion"

                app._edit_acceptance_criteria(mock_story, mock_workflow)

                assert len(mock_story.acceptance_criteria) == 2
                assert "New criterion" in mock_story.acceptance_criteria

    def test_remove_criterion(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_story: MagicMock
    ) -> None:
        """Test removing a criterion."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        mock_story.acceptance_criteria = ["Criterion 1", "Criterion 2"]

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = [
                "remove",  # Select remove action
                0,         # Remove first criterion
                "done",    # Done editing
            ]

            app._edit_acceptance_criteria(mock_story, mock_workflow)

            assert len(mock_story.acceptance_criteria) == 1
            assert "Criterion 2" in mock_story.acceptance_criteria

    def test_cannot_remove_last_criterion(
        self, tmp_path: Path, mock_workflow: MagicMock, mock_story: MagicMock
    ) -> None:
        """Test that last criterion cannot be removed."""
        output = StringIO()
        console = Console(file=output, force_terminal=True, width=80)

        app = RalphApp(tmp_path)
        app.console = console

        mock_story.acceptance_criteria = ["Only criterion"]

        with patch('ralph.app.questionary.select') as mock_select:
            mock_select.return_value.ask.side_effect = [
                "remove",  # Select remove action
                "done",    # Done (should show error first)
            ]

            app._edit_acceptance_criteria(mock_story, mock_workflow)

            # Should still have the criterion
            assert len(mock_story.acceptance_criteria) == 1
            result = output.getvalue()
            assert "Cannot remove the last criterion" in result
