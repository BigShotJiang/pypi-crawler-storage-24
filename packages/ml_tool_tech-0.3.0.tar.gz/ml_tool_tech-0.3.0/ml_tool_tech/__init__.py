# ml_tool_tech package
# Usage in Google Colab:
#   from ml_tool_tech import tech2   -> injects Practical 2 code into next cell
#   from ml_tool_tech import tech4   -> injects Practical 4 code into next cell
#   from ml_tool_tech import tech5   -> injects Practical 5 code into next cell
#   from ml_tool_tech import tech6   -> injects Practical 6 code into next cell
# All practicals are also saved to ml_practicals.ipynb automatically.
