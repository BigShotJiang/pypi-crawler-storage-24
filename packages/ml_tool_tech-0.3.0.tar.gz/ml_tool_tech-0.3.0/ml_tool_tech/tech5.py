from ml_tool_tech._core import load_practical
load_practical(5)
