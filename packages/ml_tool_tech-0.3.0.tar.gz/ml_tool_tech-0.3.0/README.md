# ml-tool-tech

A Python package to inject ML practical codes directly into Google Colab cells and auto-save them to a notebook.

## Installation

```bash
pip install ml-tool-tech
```

## Usage in Google Colab

Just import the practical you want in a cell:

```python
from ml_tool_tech import tech2
```

This will:
- **Inject** the Practical 2 code into the next Colab cell automatically
- **Save** the code to `ml_practicals.ipynb` in your current directory

## Available Practicals

| Import | Practical |
|--------|-----------|
| `from ml_tool_tech import tech2` | Practical 2 - Linear Regression |
| `from ml_tool_tech import tech4` | Practical 4 - Logistic Regression |
| `from ml_tool_tech import tech5` | Practical 5 - ANOVA |
| `from ml_tool_tech import tech6` | Practical 6 - Decision Tree |

## License

MIT
