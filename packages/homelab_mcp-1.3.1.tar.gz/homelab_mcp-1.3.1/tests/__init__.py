"""Test suite for Homelab MCP Server."""
