"""Integration tests for MCP homelab server."""
