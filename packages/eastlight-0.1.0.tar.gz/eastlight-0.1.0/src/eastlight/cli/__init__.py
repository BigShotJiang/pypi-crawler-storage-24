"""CLI interface for EastLight."""
