# BizAnalyticsAI

**Advanced Data Analysis & Business Intelligence Library for Python**

[![PyPI version](https://badge.fury.io/py/bizanalyticsai.svg)](https://pypi.org/project/bizanalyticsai/)
[![Python Versions](https://img.shields.io/pypi/pyversions/bizanalyticsai.svg)](https://pypi.org/project/bizanalyticsai/)
[![License: MIT](https://img.shields.io/badge/License-MIT-purple.svg)](LICENSE)
[![Tests](https://github.com/bizanalyticsai/bizanalyticsai-python/actions/workflows/publish.yml/badge.svg)](https://github.com/bizanalyticsai/bizanalyticsai-python/actions)

BizAnalyticsAI é uma biblioteca Python avançada para análise de grandes volumes de dados de negócios. Combina ferramentas estatísticas, KPIs financeiros, simulação de Monte Carlo, análise de coorte, clustering, forecasting de séries temporais e geração automática de relatórios — tudo em uma API fluente e intuitiva.

---

## Instalação

```bash
pip install bizanalyticsai
```

Com suporte a Supabase:
```bash
pip install bizanalyticsai[supabase]
```

Instalação completa (inclui XGBoost, LightGBM, Prophet):
```bash
pip install bizanalyticsai[full]
```

---

## Início Rápido

```python
import bizanalyticsai as bai

# ── Carregar e limpar dados ──────────────────────────────────────────────────
df = bai.read_csv("vendas.csv")
df = bai.clean(df)

# ── Perfil dos dados ─────────────────────────────────────────────────────────
profile = df.profile()
print(f"Rows: {profile['shape']['rows']:,} | Cols: {profile['shape']['cols']}")

desc = bai.describe(df)
print(desc)   # stats + insights automáticos

# ── KPIs Financeiros ─────────────────────────────────────────────────────────
kpis = bai.finance.kpis(
    df,
    revenue_col="revenue",
    cost_col="cost",
    customer_col="customer_id",
    date_col="date",
    cac=350,
    monthly_churn_pct=4.5,
)
print(kpis.summary())
print("Investable?", kpis.is_investable())   # LTV/CAC ≥ 3, margin ≥ 60%, payback ≤ 24mo

# ── Simulação Monte Carlo ────────────────────────────────────────────────────
mc = bai.finance.montecarlo(
    initial_revenue=50_000,
    growth_pct=8,
    fixed_costs=20_000,
    variable_cost_pct=25,
    initial_investment=300_000,
    months=24,
    iterations=10_000,
    seed=42,
)
print(mc.summary())
# P10: -124.500  |  P50: 342.800  |  P90: 1.2M  |  Bankruptcy: 4.2%

# ── Análise de Churn & LTV ───────────────────────────────────────────────────
churn = bai.finance.churn(df, customer_col="customer_id", date_col="date")
print(churn.summary())

# ── Cohort Retention ─────────────────────────────────────────────────────────
retention = bai.finance.cohort_retention(df, "customer_id", "date", "M")
print(retention.head())

# ── Segmentação RFM ──────────────────────────────────────────────────────────
rfm = bai.ml.rfm_segments(df, "customer_id", "date", "revenue")
print(rfm["segment"].value_counts())

# ── Detecção de Anomalias ────────────────────────────────────────────────────
anomalies = bai.ml.detect_anomalies(df, method="isolation_forest")
print(anomalies.summary())

# ── Forecasting de Séries Temporais ─────────────────────────────────────────
import pandas as pd
monthly_revenue = df.set_index("date")["revenue"].resample("M").sum()
forecast = bai.timeseries.forecast(monthly_revenue, horizon=6, method="holtwinters")
print(forecast.forecast)

# ── Market Sizing ────────────────────────────────────────────────────────────
market = bai.market.tam_sam_som(tam=5e9, sam_pct=12, som_pct=8)
print(market.summary())

# ── Probabilidade de Sucesso ─────────────────────────────────────────────────
sp = bai.market.success_probability(
    segment="Tecnologia / SaaS",
    margin_pct=65, payback_months=12, cac_ratio=3.8,
    churn_rate=3, market_size=2e9, growth_trend=2,
    team_score=4, has_revenue=True, has_customers=True,
)
print(f"{sp['emoji']} {sp['label']}: {sp['score']}/100")

# ── Relatório HTML ───────────────────────────────────────────────────────────
bai.report.summary_report(df, output="report.html")
```

---

## Módulos

| Módulo | Descrição |
|---|---|
| `bai.io` | Leitura de CSV, JSON, Excel, Parquet, SQL, Supabase |
| `bai.clean` | Limpeza, normalização, outliers, encoding |
| `bai.stats` | Estatísticas descritivas, correlação, distribuições |
| `bai.finance` | MRR/ARR, LTV, CAC, Churn, Monte Carlo, Coorte, Break-Even |
| `bai.ml` | Clustering (K-Means, DBSCAN), RFM, detecção de anomalias |
| `bai.timeseries` | Holt-Winters, ARIMA, SARIMA, trend, sazonalidade |
| `bai.market` | TAM/SAM/SOM, benchmarks por setor, probabilidade de sucesso |
| `bai.viz` | Gráficos Plotly e Matplotlib (bar, line, scatter, heatmap) |
| `bai.report` | Relatórios HTML, Markdown e JSON automatizados |
| `BizFrame` | DataFrame com métodos de BI embutidos |
| `Pipeline` | Pipeline declarativo com timing por etapa |

---

## Pipeline Declarativo

```python
from bizanalyticsai import Pipeline, read_csv, clean, normalize, remove_outliers

result = (
    Pipeline("etl_vendas")
    .read(read_csv, "vendas.csv")
    .step("clean",      clean)
    .step("outliers",   remove_outliers)
    .step("normalize",  lambda df: normalize(df, cols=["revenue"], method="minmax"))
    .filter("revenue > 0")
    .select("customer_id", "revenue", "cost", "date")
    .sort("revenue", ascending=False)
    .limit(10_000)
    .run()
)

print(result.pipeline.report())
```

---

## CLI

```bash
# Perfil de dados
bizai profile dados.csv

# Relatório HTML
bizai report dados.csv --output report.html --title "Análise de Vendas"

# Simulação Monte Carlo
bizai montecarlo \
  --revenue 50000 \
  --growth 8 \
  --fixed-costs 20000 \
  --investment 300000 \
  --months 24

# Versão
bizai version
```

---

## Monte Carlo — Detalhes

A simulação usa o método **Box-Muller** para gerar números aleatórios gaussianos sem dependências externas. Em cada iteração:

1. Receita é perturbada: `actualRevenue = revenue × N(1, σ)`
2. Custos calculados: `totalCost = fixedCosts + actualRevenue × variablePct`
3. Fluxo de caixa: `cash += actualRevenue - totalCost`
4. Crescimento: `revenue *= (1 + N(growthPct, 0.02))`
5. Falência se `cash < -3 × investimento inicial`

Retorna: P10, P25, P50, P75, P90, média, desvio padrão, % de falência.

---

## Benchmarks por Setor

A biblioteca inclui benchmarks para 9 setores brasileiros baseados em dados reais (SaaStr, ChartMogul, Bessemer, McKinsey, CB Insights):

| Setor | Churn/mês | LTV/CAC médio | Margem Bruta | Taxa Sucesso 5a |
|---|---|---|---|---|
| Tecnologia / SaaS | 3.2% | 3.5× | 72% | 22% |
| E-commerce | 6.5% | 2.2× | 38% | 18% |
| Saúde | 2.5% | 4.2× | 55% | 28% |
| Educação | 4.8% | 2.8× | 60% | 20% |
| Indústria | 1.8% | 4.5× | 30% | 32% |

---

## Deploy para PyPI

### Configuração Trusted Publisher (recomendado — sem API keys)

1. Acesse [pypi.org/manage/account/publishing](https://pypi.org/manage/account/publishing/)
2. Adicione um novo publisher:
   - **PyPI project name**: `bizanalyticsai`
   - **Owner**: seu usuário GitHub
   - **Repository**: `bizanalyticsai-python`
   - **Workflow**: `publish.yml`
   - **Environment**: `pypi`

3. Crie a tag e faça push:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```
   O GitHub Actions fará o build, testes e publish automaticamente.

### Publicação manual

```bash
pip install build twine
python -m build
twine upload dist/*          # PyPI
twine upload --repository testpypi dist/*   # TestPyPI
```

### Testando a instalação

```bash
pip install --index-url https://test.pypi.org/simple/ bizanalyticsai
# ou após o publish oficial:
pip install bizanalyticsai
```

---

## Requisitos

- Python ≥ 3.9
- numpy ≥ 1.24
- pandas ≥ 2.0
- scipy ≥ 1.10
- scikit-learn ≥ 1.3
- statsmodels ≥ 0.14
- matplotlib ≥ 3.7
- plotly ≥ 5.15
- rich ≥ 13.0
- jinja2 ≥ 3.1
- pyarrow ≥ 12.0

---

## Licença

MIT — veja [LICENSE](LICENSE).

---

*BizAnalyticsAI © 2024 — [bizanalyticsai.com.br](https://bizanalyticsai.com.br)*
