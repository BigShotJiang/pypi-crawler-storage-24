"""
BizAnalyticsAI — Advanced Data Analysis & Business Intelligence Library
=======================================================================

A powerful Python library for analyzing large volumes of business data,
computing financial KPIs, running Monte Carlo simulations, cohort analysis,
clustering, time-series forecasting, and generating automated reports.

Quick start::

    import bizanalyticsai as bai

    # Load and clean data
    df = bai.read_csv("sales.csv")
    df = bai.clean(df)

    # Financial KPIs
    kpis = bai.finance.kpis(df, revenue_col="revenue", cost_col="cost")
    print(kpis.summary())

    # Monte Carlo simulation
    mc = bai.finance.montecarlo(
        initial_revenue=50_000,
        growth_pct=8,
        fixed_costs=20_000,
        months=24,
        iterations=10_000,
    )
    print(mc.p50, mc.p90)

    # Churn & LTV
    churn = bai.finance.churn(df, customer_col="customer_id", date_col="date")
    print(churn.monthly_rate, churn.ltv)

    # Market analysis
    market = bai.market.tam_sam_som(tam=1e9, sam_pct=10, som_pct=5)

    # AI-driven clustering
    segments = bai.ml.cluster(df, n_clusters=4)

    # Generate report
    bai.report.html(segments, output="report.html")
"""

__version__ = "1.0.0"
__author__  = "BizAnalyticsAI"
__license__ = "MIT"

# ── Public surface ─────────────────────────────────────────────────────────────
from bizanalyticsai.io.readers      import read_csv, read_json, read_excel, read_parquet, read_sql
from bizanalyticsai.clean.cleaner   import clean, normalize, fill_missing, remove_outliers, encode
from bizanalyticsai.stats.descriptive import describe, correlation_matrix, distribution, percentiles
from bizanalyticsai import finance, ml, timeseries, market, report, viz
from bizanalyticsai.core.pipeline   import Pipeline
from bizanalyticsai.core.dataframe  import BizFrame

__all__ = [
    # I/O
    "read_csv", "read_json", "read_excel", "read_parquet", "read_sql",
    # Cleaning
    "clean", "normalize", "fill_missing", "remove_outliers", "encode",
    # Stats
    "describe", "correlation_matrix", "distribution", "percentiles",
    # Modules
    "finance", "ml", "timeseries", "market", "report", "viz",
    # Core classes
    "Pipeline", "BizFrame",
]
