# Downstream AGENTS Snippet

Copy the block below into a downstream repo's `AGENTS.md` if that repo depends on `infra-screenshot`.

```md
## infra-screenshot

This repo depends on `infra-screenshot`. Prefer its shared screenshot helpers before writing custom Playwright or Selenium runners, local capture CLIs, or ad-hoc batching loops.

- Local CLI batch capture: `screenshot local --input jobs.jsonl --output-dir ./out`
- Programmatic Playwright capture: `from screenshot import capture_screenshots_async`
- Programmatic Selenium capture: `from screenshot import capture_screenshots_async_selenium`
- Batch orchestration: `from screenshot import ScreenshotService, ScreenshotJob`
- Local runtime backends: `from screenshot.backends import build_local_screenshot_service`
- Storage backends: `from screenshot import LocalStorageBackend, CloudStorageBackend, AsyncStorageBackend`

Discovery:
- Check `screenshot.capabilities` for a task-oriented capability index.
- If this repo vendors or submodules `infra-screenshot`, also read its `CAPABILITIES.md`.

Constraints:
- Prefer public `screenshot` imports over internal module paths.
- Prefer `result.outcome` for operational status and `result.has_artifacts` when partial artifacts matter.
```
