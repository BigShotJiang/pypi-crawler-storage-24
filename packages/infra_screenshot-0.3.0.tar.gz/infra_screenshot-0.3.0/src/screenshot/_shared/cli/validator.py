"""Validation helpers for CLI derived job specs."""

from __future__ import annotations

from ..._models_artifacts import ScreenshotArtifactsRequest
from ...models import ScreenshotOptions

SUPPORTED_BACKENDS = {"playwright", "selenium"}

__all__ = ["SUPPORTED_BACKENDS", "validate_backend_choice"]


def validate_backend_choice(
    selected_backend: str,
    options: ScreenshotOptions,
    artifacts: ScreenshotArtifactsRequest,
) -> None:
    """Ensure the requested backend is supported for the resolved options."""

    backend = selected_backend.strip().lower()
    if backend not in SUPPORTED_BACKENDS:
        supported = ", ".join(sorted(SUPPORTED_BACKENDS))
        raise ValueError(
            f"backend '{selected_backend}' is not supported yet; available backends: {supported}"
        )
    if backend == "selenium" and artifacts.motion_snapshot is not None:
        raise ValueError(
            "backend 'selenium' does not support motion snapshots; "
            "use the Playwright backend for 'artifacts.motion_snapshot'"
        )
    _ = options
