"""Batch capture example built on ScreenshotService."""

from __future__ import annotations

import asyncio
from pathlib import Path

from screenshot import ScreenshotJob, ScreenshotOptions
from screenshot.backends import build_local_screenshot_service
from screenshot.models import CaptureOptions


async def main() -> None:
    options = ScreenshotOptions(
        capture=CaptureOptions(
            enabled=True,
            viewports=("desktop",),
            depth=0,
            scroll=False,
            full_page=False,
        )
    )
    jobs = [
        ScreenshotJob(
            job_id="example-home",
            url="https://example.com",
            output_root=Path("batch-output"),
            options=options,
        ),
        ScreenshotJob(
            job_id="python-home",
            url="https://www.python.org",
            output_root=Path("batch-output"),
            options=options,
        ),
    ]
    service = build_local_screenshot_service(concurrency=2, backend="playwright")
    batch = await service.capture_async(jobs)
    print(batch.outcome_counts)


if __name__ == "__main__":
    asyncio.run(main())
