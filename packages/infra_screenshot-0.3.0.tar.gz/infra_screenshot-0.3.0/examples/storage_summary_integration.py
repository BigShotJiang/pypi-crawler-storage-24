"""Storage backend and batch-summary integration example."""

from __future__ import annotations

import asyncio
from pathlib import Path

from screenshot import LocalStorageBackend, ScreenshotJob, ScreenshotOptions
from screenshot.backends import build_local_screenshot_service
from screenshot.models import CaptureOptions


async def main() -> None:
    options = ScreenshotOptions(
        capture=CaptureOptions(
            enabled=True,
            viewports=("desktop",),
            depth=0,
            scroll=False,
            full_page=False,
        )
    )
    storage = LocalStorageBackend()
    service = build_local_screenshot_service(
        concurrency=1,
        backend="playwright",
        storage=storage,
    )
    batch = await service.capture_async(
        [
            ScreenshotJob(
                job_id="example-storage",
                url="https://example.com",
                output_root=Path("storage-output"),
                options=options,
            )
        ]
    )
    summary_path = storage.write_json(Path("storage-output/summary.json"), batch.to_dict())
    first_result = batch.results[0]
    print(summary_path, first_result.outcome.value, first_result.has_artifacts)


if __name__ == "__main__":
    asyncio.run(main())
