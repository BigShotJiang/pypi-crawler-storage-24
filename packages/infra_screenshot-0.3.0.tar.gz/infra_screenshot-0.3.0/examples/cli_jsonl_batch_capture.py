"""Generate a nested JSONL batch file for `screenshot local`.

This example prepares a small `screenshot_options/v2` JSONL input file with
job metadata, backend selection, and a summary-file destination. It does not
run the CLI automatically; instead it prints the exact command so callers can
inspect or edit the generated batch before capture.
"""

from __future__ import annotations

import json
import shlex
from pathlib import Path

# Keep generated batch files self-describing even though the current CLI only
# supports this nested options shape.
OPTIONS_SCHEMA_VERSION = "screenshot_options/v2"


def _job_record(
    *,
    job_id: str,
    url: str,
    backend: str,
    campaign: str,
    output_root: Path,
) -> dict[str, object]:
    return {
        "job_id": job_id,
        "url": url,
        "backend": backend,
        "metadata": {
            "campaign": campaign,
            "source": "cli-jsonl-example",
        },
        "artifacts": {
            "html_snapshot": {"path": str(output_root / f"{job_id}.html")},
            "motion_snapshot": {"path": str(output_root / f"{job_id}.gif"), "duration_s": 2.0},
        },
        "options": {
            "schema_version": OPTIONS_SCHEMA_VERSION,
            "capture": {
                "enabled": True,
                "max_pages": 1,
                "depth": 0,
                "viewports": ["desktop", "mobile"],
                "post_nav_wait_s": 0.5,
                "timeout_s": 30.0,
            },
            "browser": {
                "allow_autoplay": False,
                "hide_overlays": True,
                "disable_animations": True,
            },
        },
    }


def main() -> None:
    output_root = Path("cli-jsonl-example")
    input_path = output_root / "jobs.jsonl"
    summary_path = output_root / "summary.json"
    capture_root = output_root / "artifacts"

    output_root.mkdir(parents=True, exist_ok=True)

    records = [
        _job_record(
            job_id="marketing-home",
            url="https://example.com",
            backend="playwright",
            campaign="spring-launch",
            output_root=output_root / "aux-artifacts",
        ),
        _job_record(
            job_id="python-home",
            url="https://www.python.org",
            backend="playwright",
            campaign="docs-refresh",
            output_root=output_root / "aux-artifacts",
        ),
    ]

    with input_path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    command = [
        "screenshot",
        "local",
        "--input",
        str(input_path),
        "--output-dir",
        str(capture_root),
        "--summary-file",
        str(summary_path),
        "--backend",
        "playwright",
    ]

    print(f"Wrote {input_path}")
    print("Run:")
    print(" ".join(shlex.quote(part) for part in command))


if __name__ == "__main__":
    main()
