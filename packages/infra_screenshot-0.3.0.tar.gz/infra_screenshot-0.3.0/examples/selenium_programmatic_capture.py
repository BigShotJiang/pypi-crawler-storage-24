"""Programmatic Selenium capture example."""

from __future__ import annotations

import asyncio
from pathlib import Path

from screenshot import (
    ScreenshotCaptureOutcome,
    ScreenshotOptions,
    capture_screenshots_async_selenium,
)
from screenshot.models import CaptureOptions


async def main() -> None:
    options = ScreenshotOptions(
        capture=CaptureOptions(
            enabled=True,
            viewports=("desktop",),
            depth=0,
            scroll=False,
            full_page=False,
        )
    )
    result = await capture_screenshots_async_selenium(
        "example-selenium",
        "https://example.com",
        store_dir=Path("selenium-output"),
        partition_date=None,
        options=options,
    )
    if result.outcome is ScreenshotCaptureOutcome.SUCCESS:
        print(f"Captured {result.captured} screenshot(s)")
    elif result.outcome is ScreenshotCaptureOutcome.PARTIAL:
        print(f"Partially captured {result.captured} screenshot(s)")
        for error in result.errors:
            print(f"Partial failure: {error.message}")
    else:
        for error in result.errors:
            print(f"Capture failed: {error.message}")


if __name__ == "__main__":
    asyncio.run(main())
