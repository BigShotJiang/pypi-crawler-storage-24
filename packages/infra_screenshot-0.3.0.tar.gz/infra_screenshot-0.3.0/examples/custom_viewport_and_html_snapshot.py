"""Programmatic capture example with a custom viewport and HTML snapshot."""

from __future__ import annotations

import asyncio
from pathlib import Path

from screenshot import (
    HtmlSnapshotRequest,
    ScreenshotArtifactsRequest,
    ScreenshotCaptureOutcome,
    ScreenshotOptions,
    capture_screenshots_async,
)
from screenshot.models import CaptureOptions


async def main() -> None:
    output_root = Path("custom-viewport-output")
    html_snapshot_path = output_root / "html" / "landing-page.html"

    options = ScreenshotOptions(
        capture=CaptureOptions(
            enabled=True,
            depth=0,
            scroll=False,
            full_page=False,
            viewports=(
                {
                    "name": "landing",
                    "viewport": {"width": 1600, "height": 900},
                    "device_scale_factor": 1.25,
                    "is_mobile": False,
                },
            ),
        )
    )

    result = await capture_screenshots_async(
        "custom-viewport",
        "https://example.com",
        store_dir=output_root,
        partition_date=None,
        options=options,
        artifacts=ScreenshotArtifactsRequest(
            html_snapshot=HtmlSnapshotRequest(path=html_snapshot_path)
        ),
        job_metadata={"campaign": "landing-refresh", "source": "example"},
    )
    if result.outcome is ScreenshotCaptureOutcome.SUCCESS:
        print(
            f"Captured {result.captured} screenshot(s)",
            html_snapshot_path,
            result.metadata_path,
        )
    elif result.outcome is ScreenshotCaptureOutcome.PARTIAL:
        print(
            f"Partially captured {result.captured} screenshot(s)",
            html_snapshot_path,
            result.metadata_path,
        )
        for error in result.errors:
            print(f"Partial failure: {error.message}")
    else:
        for error in result.errors:
            print(f"Capture failed: {error.message}")


if __name__ == "__main__":
    asyncio.run(main())
