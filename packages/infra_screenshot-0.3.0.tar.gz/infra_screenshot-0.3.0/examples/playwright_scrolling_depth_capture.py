"""Programmatic Playwright capture with scrolling and link-follow depth.

Use this pattern when you want to start from one URL, follow first-level links
up to a small page budget, and capture full-page screenshots after scrolling.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from screenshot import ScreenshotCaptureOutcome, ScreenshotOptions, capture_screenshots_async
from screenshot.models import CaptureOptions


async def main() -> None:
    options = ScreenshotOptions(
        capture=CaptureOptions(
            enabled=True,
            viewports=("desktop",),
            depth=1,
            max_pages=3,
            scroll=True,
            full_page=True,
            scroll_step_delay_ms=150,
            max_scroll_steps=20,
            post_nav_wait_s=0.5,
            pre_capture_wait_s=0.3,
        )
    )

    result = await capture_screenshots_async(
        "example-scroll-depth",
        "https://example.com",
        store_dir=Path("scroll-depth-output"),
        partition_date=None,
        options=options,
    )

    if result.outcome is ScreenshotCaptureOutcome.SUCCESS:
        print(
            f"Captured {result.captured} screenshot(s) with depth={options.capture.depth} "
            f"and max_pages={options.capture.max_pages}"
        )
    elif result.outcome is ScreenshotCaptureOutcome.PARTIAL:
        print(
            f"Partially captured {result.captured} screenshot(s) with depth="
            f"{options.capture.depth} and max_pages={options.capture.max_pages}"
        )
        for error in result.errors:
            print(f"Partial failure: {error.message}")
    else:
        for error in result.errors:
            print(f"Capture failed: {error.message}")


if __name__ == "__main__":
    asyncio.run(main())
