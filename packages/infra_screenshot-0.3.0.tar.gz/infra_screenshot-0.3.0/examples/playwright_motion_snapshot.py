"""Programmatic Playwright capture with an auxiliary GIF motion snapshot.

Requires the optional ``motion`` extra:

    uv pip install "infra-screenshot[playwright,motion]"
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from screenshot import (
    MotionSnapshotRequest,
    ScreenshotArtifactsRequest,
    ScreenshotCaptureOutcome,
    ScreenshotOptions,
    capture_screenshots_async,
)
from screenshot.models import CaptureOptions


async def main() -> None:
    output_root = Path("playwright-motion-output")
    motion_path = output_root / "artifacts" / "landing-page.gif"

    options = ScreenshotOptions(
        capture=CaptureOptions(
            enabled=True,
            depth=0,
            scroll=False,
            full_page=False,
            viewports=("desktop",),
            post_nav_wait_s=0.0,
            pre_capture_wait_s=0.0,
        )
    )

    result = await capture_screenshots_async(
        "playwright-motion",
        "https://example.com",
        store_dir=output_root,
        partition_date=None,
        options=options,
        artifacts=ScreenshotArtifactsRequest(
            motion_snapshot=MotionSnapshotRequest(
                path=motion_path,
                duration_s=2.0,
                fps=4,
            )
        ),
        job_metadata={"source": "example", "artifact": "motion-snapshot"},
    )

    motion_result = result.artifacts.motion_snapshot
    if result.outcome is ScreenshotCaptureOutcome.SUCCESS:
        print(
            f"Captured {result.captured} screenshot(s)",
            motion_result.path if motion_result else None,
            result.metadata_path,
        )
    elif result.outcome is ScreenshotCaptureOutcome.PARTIAL:
        print(
            f"Partially captured {result.captured} screenshot(s)",
            motion_result.path if motion_result else None,
            result.metadata_path,
        )
        for error in result.errors:
            print(f"Partial failure: {error.message}")
    else:
        for error in result.errors:
            print(f"Capture failed: {error.message}")


if __name__ == "__main__":
    asyncio.run(main())
