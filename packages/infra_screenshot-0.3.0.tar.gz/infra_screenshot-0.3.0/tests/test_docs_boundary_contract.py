from __future__ import annotations

from pathlib import Path


def test_public_docs_and_examples_do_not_reference_removed_private_or_legacy_apis() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    targets = [
        repo_root / "README.md",
        repo_root / "AGENTS.md",
        repo_root / "CAPABILITIES.md",
        *sorted((repo_root / "docs").glob("*.md")),
        *sorted((repo_root / "agent-snippets").glob("*.md")),
        *sorted((repo_root / "examples").glob("*.py")),
        *sorted((repo_root / "skills").glob("*/*.md")),
        *sorted((repo_root / "skills").glob("*/*.yaml")),
        *sorted((repo_root / "skills").glob("*/*/*.yaml")),
    ]

    forbidden_patterns = (
        "from screenshot._internal import",
        "screenshot._internal",
        "from screenshot.cli import build_local_screenshot_service",
        "ScreenshotResourceResult",
        "ScreenshotResourceOutcome",
        "ScreenshotResourceError",
    )

    for path in targets:
        content = path.read_text(encoding="utf-8")
        for pattern in forbidden_patterns:
            assert (
                pattern not in content
            ), f"{path.relative_to(repo_root)} still references {pattern}"
