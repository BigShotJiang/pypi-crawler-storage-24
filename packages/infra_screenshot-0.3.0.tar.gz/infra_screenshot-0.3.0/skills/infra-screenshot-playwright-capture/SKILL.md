---
name: infra-screenshot-playwright-capture
description: Use when working with Playwright-backed screenshot capture, timeout budgets, viewport configuration, or partial-result handling.
---

# infra-screenshot-playwright-capture

Use this skill when the task is about Playwright-backed screenshot capture, programmatic options, or diagnosing capture/runtime behavior.

## Preferred imports

- `from screenshot import capture_screenshots_async, capture_screenshots`
- `from screenshot import KNOWN_VIEWPORTS`
- `from screenshot.models import CaptureOptions, MotionSnapshotRequest, ScreenshotArtifactsRequest, ScreenshotOptions`

## Selection guide

- Use `capture_screenshots_async` from async code and `capture_screenshots` from synchronous entry points.
- Use `CaptureOptions` for viewports, scrolling, timeout budgets, full-page capture, and retry counts.
- Use `ScreenshotArtifactsRequest` for auxiliary HTML or GIF artifact output.
- Use `KNOWN_VIEWPORTS` when you need the shipped preset names and sizes.
- Use this backend by default unless Selenium-specific browser behavior is required.

## Important behavior

- `result.outcome` distinguishes `success`, `partial`, `failed`, and `skipped`.
- Partial results can preserve artifacts and metadata after outer timeout handling.
- Explicit custom viewport dictionaries are validated and honored.
- URL normalization, timeout budgets, and browser compatibility flags are shared policy decisions; avoid reimplementing them outside the runner.

## Read next when needed

- [CAPABILITIES.md](../../CAPABILITIES.md)
- [README.md](../../README.md)
- [src/screenshot/playwright_runner.py](../../src/screenshot/playwright_runner.py)
- [src/screenshot/capabilities.py](../../src/screenshot/capabilities.py)
- [examples/custom_viewport_and_html_snapshot.py](../../examples/custom_viewport_and_html_snapshot.py)
- [examples/playwright_motion_snapshot.py](../../examples/playwright_motion_snapshot.py)
- [examples/playwright_programmatic_capture.py](../../examples/playwright_programmatic_capture.py)
- [examples/playwright_scrolling_depth_capture.py](../../examples/playwright_scrolling_depth_capture.py)
- [tests/test_playwright_runner.py](../../tests/test_playwright_runner.py)
- [tests/test_shared_utils.py](../../tests/test_shared_utils.py)
