---
name: infra-screenshot-local-cli
description: Use when working with the local screenshot CLI, JSONL batch inputs, backend selection, or summary-file behavior.
---

# infra-screenshot-local-cli

Use this skill when the task is about local screenshot capture via the CLI, especially `screenshot local`, JSONL inputs, batch summaries, or backend selection.

## Preferred entrypoints

- `screenshot local --input jobs.jsonl --output-dir ./out`
- `screenshot local --urls https://example.com --output-dir ./out`
- `from screenshot.backends import build_local_screenshot_service`

## Selection guide

- Use `--input` for many sites or when each line needs its own metadata.
- Use repeated `--urls` flags for small ad-hoc local runs.
- Use `--summary-file` when another tool needs machine-readable outcomes.
- Use `--site-concurrency` for site-level parallelism and `--max-viewport-concurrency` for per-page viewport parallelism.
- Use the Playwright backend by default; use Selenium only when Chrome/driver parity is specifically required.

## Important behavior

- Each non-empty JSONL line must be a JSON object with a non-empty string `url`.
- The CLI exits non-zero when any job outcome is `partial` or `failed`.
- Partial jobs can still keep artifacts; inspect summary `outcome` fields instead of treating exit `0` as the only signal.
- Mixed backend selections are rejected within a single CLI batch.

## Read next when needed

- [CAPABILITIES.md](../../CAPABILITIES.md)
- [README.md](../../README.md)
- [examples/cli_jsonl_batch_capture.py](../../examples/cli_jsonl_batch_capture.py)
- [src/screenshot/cli.py](../../src/screenshot/cli.py)
- [src/screenshot/cli_utils.py](../../src/screenshot/cli_utils.py)
- [tests/test_screenshot_cli.py](../../tests/test_screenshot_cli.py)
- [tests/test_screenshot_cli_utils.py](../../tests/test_screenshot_cli_utils.py)
- [tests/test_cli_parser.py](../../tests/test_cli_parser.py)
