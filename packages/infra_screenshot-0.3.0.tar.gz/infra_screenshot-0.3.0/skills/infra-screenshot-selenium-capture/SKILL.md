---
name: infra-screenshot-selenium-capture
description: Use when working with Selenium-backed screenshot capture, Chrome/driver configuration, or backend parity with Playwright.
---

# infra-screenshot-selenium-capture

Use this skill when the task is about Selenium-backed screenshot capture, Chrome options, or comparing Selenium behavior with the Playwright backend.

## Preferred imports

- `from screenshot import capture_screenshots_async_selenium`
- `from screenshot.models import CaptureOptions, ScreenshotOptions`

## Selection guide

- Use Selenium when the workflow specifically needs Chrome/driver behavior rather than the default Playwright runtime.
- Use `CaptureOptions` for page depth, viewports, scrolling, and capture budgets; the same public options model is shared with Playwright.
- Prefer shared browser compatibility levels instead of adding one-off Chrome flags in callers.

## Important behavior

- Selenium uses the same normalized URL and compatibility-policy contracts where feasible.
- Missing Selenium dependencies are reported as structured dependency failures instead of import-time crashes.
- Outcome semantics match the Playwright backend: inspect `result.outcome` instead of inferring status from counts alone.
- Autoplay mutations only run when autoplay is enabled.

## Read next when needed

- [CAPABILITIES.md](../../CAPABILITIES.md)
- [README.md](../../README.md)
- [src/screenshot/selenium_runner.py](../../src/screenshot/selenium_runner.py)
- [examples/selenium_programmatic_capture.py](../../examples/selenium_programmatic_capture.py)
- [tests/test_selenium_runner.py](../../tests/test_selenium_runner.py)
- [tests/test_shared_utils.py](../../tests/test_shared_utils.py)
