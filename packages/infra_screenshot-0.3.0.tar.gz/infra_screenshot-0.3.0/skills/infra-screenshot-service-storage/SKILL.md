---
name: infra-screenshot-service-storage
description: Use when working with ScreenshotService, multi-job orchestration, storage backends, or batch summary integration.
---

# infra-screenshot-service-storage

Use this skill when the task is about multi-job screenshot execution, storage backend integration, or turning batch results into summary payloads.

## Preferred imports

- `from screenshot import ScreenshotService, ScreenshotJob, ScreenshotOptions`
- `from screenshot import LocalStorageBackend, CloudStorageBackend, AsyncStorageBackend`
- `from screenshot.backends import build_local_screenshot_service`

## Selection guide

- Use `ScreenshotService` when a caller already has a backend implementation or wants direct async control.
- Use `build_local_screenshot_service()` when the caller wants a ready-made local Playwright/Selenium service.
- Use `LocalStorageBackend` for ordinary filesystem output and summary writing.

## Important behavior

- Batch results preserve input order even when concurrency is greater than one.
- Batch failures include `partial` and `failed` outcomes; use `successes`, `failures`, `partials`, and `skipped` intentionally.
- Job-level and batch-level cancellation tokens are combined before dispatch to the backend.
- `ScreenshotBatchResult.to_dict()` is the preferred machine-readable summary payload.

## Read next when needed

- [CAPABILITIES.md](../../CAPABILITIES.md)
- [README.md](../../README.md)
- [src/screenshot/service.py](../../src/screenshot/service.py)
- [src/screenshot/backends.py](../../src/screenshot/backends.py)
- [src/screenshot/_shared/storage.py](../../src/screenshot/_shared/storage.py)
- [examples/service_batch_capture.py](../../examples/service_batch_capture.py)
- [examples/storage_summary_integration.py](../../examples/storage_summary_integration.py)
- [tests/test_common_screenshot_service.py](../../tests/test_common_screenshot_service.py)
