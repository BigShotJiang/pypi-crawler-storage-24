## How to use

Use collection link:

```bash
./dspace_wgetter.py https://dspace.nplg.gov.ge/handle/1234/511565
```

Also available at https://pypi.org/project/dspace_wgetter/

![screenshot](screenshot.webp)
