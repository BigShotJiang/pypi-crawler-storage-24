from yta_video_opengl.pipeline import _OpenGLPipeline
from yta_video_opengl.node_processor import _OpenGLNodeProcessor
from yta_video_opengl.context import _OpenGLFrameContext
from yta_video_opengl.texture.utils import TextureUtils
from yta_editor_nodes_common import _Node
from typing import Union, Mapping

import moderngl


# TODO: This class will be adapted to all our custom ones
class _OpenGLNode(_Node):
    """
    *For internal use only*

    Instanciable OpenGL node. Holds only parameters and
    timing.

    This node will instantiated as many times as
    different changes we want to apply with the same
    node, and will internally use the same singleton
    instance to actually apply the changes (due to a
    performance motivation).

    A static or initial uniform is an uniform that will
    not change during the different executions of the
    node. A dynamic uniform is an uniform that we set
    for that specific execution, which could be a 
    progress during a transition, for example.

    An nstantiable OpenGL node that encapsulates
    parameters, timing, and uniform state, delegating
    the actual GPU execution to a shared node processor.
    It merges static and per-execution dynamic uniforms,
    prepares the frame context and input textures, and
    produces an output texture at the requested
    resolution.
    """

    mandatory_inputs = []
    optional_inputs = []

    def __init__(
        self,
        opengl_pipeline: _OpenGLPipeline,
        **initial_uniforms
    ):
        # TODO: Describe with the doc
        self._opengl_pipeline = opengl_pipeline
        """
        *For internal use only*

        The pipeline that contains the shaders to be
        executed.
        """
        self._opengl_node_processor = _OpenGLNodeProcessor.get(
            opengl_context = self._opengl_pipeline.context
        )
        """
        *For internal use only*

        The node processor that will handle the inputs
        to be processed by the pipeline shaders and
        obtain the expected result.
        """
        self._static_uniforms = initial_uniforms.copy()
        """
        *For internal useo nly*

        The uniforms that are passed when instantiating
        this class and will be used everytime we call
        the `process` method, unless they are
        overwritten by the dynamic one (passed when
        calling the `process` method).
        """

    def _get_textures_map(
        self,
        inputs: dict[str, moderngl.Texture]
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc. The input must be called
        `base_input`.
        """
        textures = {}

        for key, value in inputs.items():
            # None values are simply omitted
            if value is None:
                continue

            textures[key.replace('_input', '_texture')] = value

        return textures

    def _validate_inputs(
        self,
        inputs: dict[str, moderngl.Texture]
    ) -> None:
        return super()._validate_inputs(
            inputs = inputs,
            type = moderngl.Texture
        )

    def process(
        self,
        inputs: Mapping[str, moderngl.Texture],
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        Process the `inputs` provided and get an output
        of the given `output_size` by using the
        `**dynamic_uniforms` if needed.

        This method must be overwritten in any specific
        node type implementation, modifying the name of
        the input textures and the way we pass them to
        the `_get_textures_map` method, that can be also
        different for each specific node type.
        """
        # Validate mandatory and optional inputs
        self._validate_inputs(inputs)

        textures_map = self._get_textures_map(inputs)

        return self._process_common(
            textures_map = textures_map,
            output_size = output_size,
            **dynamic_uniforms
        )

    def _process_common(
        self,
        textures_map: dict,
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        *For internal use only*

        The part of the processing part that all the nodes
        have in common, useful to avoid repeating the code
        and customizing only the really different part of
        code.

        The only thing that should change when calling this
        method internally is the `textures_map`, which is
        special for the different type of nodes we have.
        """
        # Preserve original size or force the one passed
        # as parameter
        # TODO: Maybe this should change
        output_size = (
            TextureUtils.get_size_from_texture(next(iter(textures_map.values())))
            if output_size is None else
            output_size
        )

        frame_context = _OpenGLFrameContext(
            opengl_context = self._opengl_pipeline.context,
            output_size = output_size
        )

        # Combine uniforms but dynamic ones are a priority
        uniforms = {
            **self._static_uniforms,
            **dynamic_uniforms
        }

        return self._opengl_node_processor.execute(
            opengl_pipeline = self._opengl_pipeline,
            opengl_frame_context = frame_context,
            textures_map = textures_map,
            uniforms = uniforms
        )