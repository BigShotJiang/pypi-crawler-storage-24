"""
Old code that I preserve for a while because it
is being used in old libraries, but will be
removed soon.

This implementation was deprecated because the
use of the singleton was wrong because when
we instantiate a new one with new parameters,
the previous one was being updated even before
being executed, preserving only the last
parameters defined and being applied always
with those ones.
"""