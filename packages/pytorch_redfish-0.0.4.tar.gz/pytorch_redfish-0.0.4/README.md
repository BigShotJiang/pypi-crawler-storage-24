# PyTorch RedFish

![PyPI version](https://img.shields.io/pypi/v/pytorch-redfish.svg)

[//]: # ([![Documentation Status]&#40;https://readthedocs.org/projects/pytorch-redfish/badge/?version=latest&#41;]&#40;https://pytorch-redfish.readthedocs.io/en/latest/?version=latest&#41;)

PyTorch implementation of the RedFish algorithm for training neural nets

* PyPI package: https://pypi.org/project/pytorch-redfish/
* Free software: GNU GPLv3
* Documentation: [docs](docs/index.md)

[//]: # (* Documentation: https://pytorch-redfish.readthedocs.io.)

## Features

* Update neural network weights using RedFish algorithm
* Compatible with PyTorch framework
* Easy to integrate into existing PyTorch projects

## Commentary

This version is still in development, and is not ready for production use.
The API may change without deprecation, and there may be bugs. Use at your own risk.
Additionally, there are multiple features in the optimizer that are still being evaluated, but decided to leave in case
you want to try them. they are not fully tested, they might be buggy and may be removed in the future.


## References

* Fabio Robayo. _A General Framework for Practical Application of Natural Gradient Descent in Large-Scale Deep Learning_. PhD Thesis, Stony Brook University, 2025.

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
