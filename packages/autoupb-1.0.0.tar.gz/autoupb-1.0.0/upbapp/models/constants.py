# 定义标样的参考数值
# 参考 Horstwood et al.(2016) 给出的结果
from uncertainties import ufloat
import numpy as np

# 衰变常数
LAMBDA_U238 = np.log(2) / 4468. # u238 half-life for denominator 
LAMBDA_U235 = np.log(2) / 704. # u235 half-life for denominator 
LAMBDA_Th232 = np.log(2) / 1405.
AGE_THRESHOLD = 1100  #
# LAMBDA_Pa231 = 2.10 * 10 ** (-5)  # Rempfer2017epsl
# LAMBDA_Th230 = 9.17 * 10 ** (-6)  # Cheng2013epsl
U8U5=137.818
def STD(std: str):
    '''
    Choose the Standard zircon used for calibration.
    Return ufloat type of STDr68, STDr75, STDr76
    '''
    if 'gj' in std.lower():
        # # Ratios of GJ-1 zircon.
        STDu8u5 = 137.824
        STDr68 = ufloat(0.09786, 0.000032)
        STDr75 = ufloat(0.81117, 0.000264)
        STDr76 = ufloat(0.060139, 0.000009)
        STDa68 = ufloat(601.86, 0.37)
        STDa75 = ufloat(603.11, 0.30)
        STDa76 = ufloat(607.70, 0.67)
    elif '915' in std.lower():
        # Ratios of 91500 zircon
        STDu8u5 = 137.818
        STDr68 = ufloat(0.17937, 0.000036)
        STDr75 = ufloat(1.8525, 0.000611)
        STDr76 = ufloat(0.074941, 0.000011)
        STDa68 = ufloat(1063.51, 0.39)
        STDa75 = ufloat(1064.32, 0.44)
        STDa76 = ufloat(1066.01, 0.61)
    else: 
        print('Not a standard name!')
    return STDu8u5, STDr68, STDr75, STDr76, STDa68, STDa75, STDa76

