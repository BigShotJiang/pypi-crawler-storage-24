## 用于自动处理LA-ICP-MS的U-Pb同位素数据 - 模型层
import re
import os
import shutil
import csv
import numpy as np
import math
# 引入GPU计算
cp = None
try:
    import cupy as cp

    _HAS_CUPY_GLOBAL = True
except ImportError:
    print("cupy is not available, using numpy instead for BestSegment")
    _HAS_CUPY_GLOBAL = False

from datetime import datetime
from patsy import dmatrix
from upbapp.models import autoUPb as au, constants as cs
import statsmodels.api as sm
from uncertainties import unumpy
from sklearn.preprocessing import SplineTransformer
from matplotlib.patches import Ellipse
import lmfit
from scipy.interpolate import interp1d
from scipy.interpolate import CubicSpline
# from scipy.optimize import curve_fit
# from scipy.optimize import leastsq
from scipy import stats
# 衰变常数
LAMBDA_U238 = np.log(2) / 4468. # u238 half-life for denominator 
LAMBDA_U235 = np.log(2) / 704. # u235 half-life for denominator 
LAMBDA_Th232 = np.log(2) / 1405.
# LAMBDA_Pa231 = 2.10 * 10 ** (-5)  # Rempfer2017epsl
# LAMBDA_Th230 = 9.17 * 10 ** (-6)  # Cheng2013epsl
U8U5=137.818
# 阈值
AGE_THRESHOLD = 1100.  #
##################################################################
## File input and output
##################################################################

class DataProcessor:
    def reset(self):
        """
        清空所有计算缓存和导入的数据，恢复到初始状态。
        """
        # 1. 清空基础数据
        self.sample_names = None
        self.sample_types = None
        self.datetimes = None
        self.time_eff = None
        self.signals_eff = None
        
        # 2. 清空中间计算结果 (Downhole, Drift 等)
        self.r68_dh = None
        self.r75_dh = None
        self.r76_dh = None
        self.r68_dh_dc = None
        self.r75_dh_dc = None
        self.r76_dh_dc = None
        
        # 3. 清空最佳区间缓存
        self.C_Bseg = None
        self.id_Bseg = None
        self.ends_Bseg = None
        
        # 4. 如果你有 drift_results 字典，也清空
        if hasattr(self, 'drift_results'):
            self.drift_results = {'68': None, '75': None, '76': None}
            
        # 5. 重置有效性掩码 (后面问题 1 会用到)
        self.is_valid = None 
        
        print("🧹 数据缓存已全部清空，准备接收新数据！")
    def __init__(self):
         # 衰变常数
        self.LAMBDA_U238 = np.log(2) / 4468.
        self.LAMBDA_U235 = np.log(2) / 704.
        self.LAMBDA_Th232 = np.log(2) / 1405.
        self.U8U5 = 137.818
        self.AGE_THRESHOLD = 1100.
        # 将全局变量存入实例变量，防止作用域问题
        self.has_cupy = _HAS_CUPY_GLOBAL
        self.signals = None
        self.spots = None
        self.datetimes = None
        self.sample_types = None

        # Cutoff 结果
        self.cutoffs = None
        self.cutoff_spots = None

        # BkgSeparate 结果
        self.time_bkg = None
        self.signals_bkg = None
        self.time_eff = None
        self.signals_eff = None

        # BkgSubstract 结果
        self.signals_eff_bs = None  # 最终扣除背景的信号
        self.time_bkg_abs = None
        self.bkg_fits = None
        self.bkg_fits_conf95 = None

        # RatioUPb 结果
        self.r68 = None
        self.r75 = None
        self.r76 = None

        # Downhole Fit 结果
        self.r68_dh = None
        self.r75_dh = None
        self.r76_dh = None
        self.downhole_fit_68_params = None  # 拟合参数
        self.downhole_fit_75_params = None  # 拟合参数
        # [新增] 用于存储最佳区间的计算结果
        self.r68_dh_dc = None
        self.r75_dh_dc = None
        self.r76_dh_dc = None
        
        # [新增] 用于存储最佳区间的计算结果
        self.r68_dh_bseg = None
        self.r75_dh_bseg = None
        self.r76_dh_bseg = None
        
        # [新增] 最佳区间校正后的结果
        self.r68_dh_bseg_dc = None
        self.r75_dh_bseg_dc = None
        self.r76_dh_bseg_dc = None
        # [新增/补全] 必须添加这个容器，否则无法保存结果
        self.final_results = {
            'ratios': {}, 
            'ages': {},   
            'rho': None,  
            'spots': None 
        }
        # [新增] 专门用来记忆用户手动调整过的区间 { '样品名': (start_idx, end_idx) }
        self.custom_cutoffs = {}
    def update_constants_from_std(self, std_dict):
        """
        [关键逻辑] 接收来自 Controller 的指令，
        同步更新计算过程中用到的关键常数。
        """
        if not std_dict:
            return
            
        # 动态更新 U8/U5 比值 (例如 GJ-1 传入 137.824)
        if 'u8u5' in std_dict:
            # 如果 std_dict['u8u5'] 是 ufloat，取 .n
            val = std_dict['u8u5']
            self.U8U5 = val.n if hasattr(val, 'n') else val
            
        print(f"DataProcessor constants updated: U8U5 set to {self.U8U5}")
    def readfile(self, filepath, signal_row_from, signal_row_to,
                 datetime_row, datetime_pattern, datetime_format):
        with open(filepath, mode='r') as data:
            s_data = []
            csv_reader = csv.reader(data)
            t_data = None
            for index, row in enumerate(csv_reader):
                if not isinstance(row, list):
                    continue

                if index == datetime_row:
                    dt_match = re.search(datetime_pattern, str(row), re.IGNORECASE)
                    if dt_match:
                        t_data = datetime.strptime(dt_match.group(), datetime_format)
                    else:
                        try:
                            file_time = os.path.getmtime(filepath)
                            t_data = datetime.fromtimestamp(file_time)
                        except:
                            t_data = datetime.now()
                if index >= signal_row_from and index <= signal_row_to:
                    s_data.append(row)

            if not s_data:
                print(f"警告：文件 {filepath} 中没有找到数据行")
            if t_data is None:
                t_data = datetime.now()
        return s_data, t_data

    def read_files(self, folder_path, signal_row_from=4, signal_row_to=None,
                   datetime_row=2, datetime_pattern=None, datetime_format=None,
                   sample_config=None):
        if not os.path.exists(folder_path):
            raise FileNotFoundError(f"Folder not found: {folder_path}")

        all_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
        all_files.sort()

        total_files = len(all_files)
        if total_files == 0:
            return None, None, None, None

        first_file_path = os.path.join(folder_path, all_files[0])
        target_col_indices = []
        target_col_names = []

        try:
            with open(first_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                header_index = signal_row_from - 1
                if header_index < len(lines):
                    headers = lines[header_index].strip().split(',')
                    for idx, col_name in enumerate(headers):
                        if idx == 1 or idx == 2:
                            continue
                        target_col_indices.append(idx)
                        clean_name = col_name.split('[')[0].strip()
                        target_col_names.append(clean_name)
        except Exception as e:
            print(f"Error parsing header: {e}")
            target_col_indices = None
            target_col_names = ['Time', 'Hg202', 'Pb204', 'Pb206', 'Pb207', 'Pb208', 'Th232', 'U238']

        signals_list = []
        spots = []
        datetimes = []
        all_sample_types = []

        if sample_config is None:
            sample_config = {}
        primary_std = sample_config.get('primary', '').lower()
        sec_val = sample_config.get('secondary', [])
        secondary_stds = [s.lower() for s in (sec_val if isinstance(sec_val, list) else str(sec_val).split(',')) if s]
        unk_val = sample_config.get('unknowns', [])
        unknowns = [u.lower() for u in (unk_val if isinstance(unk_val, list) else str(unk_val).split(',')) if u]

        import re
        dt_regex = re.compile(datetime_pattern) if datetime_pattern else None

        for filename in all_files:
            file_path = os.path.join(folder_path, filename)
            spot_name = os.path.splitext(filename)[0]

            try:
                spot_lower = spot_name.lower()
                sample_type = 'Unknown (Other)'

                if primary_std and spot_lower.startswith(primary_std):
                    sample_type = f'Standard ({primary_std.upper()})'
                elif any(spot_lower.startswith(s) for s in secondary_stds):
                    prefix = next(s for s in secondary_stds if spot_lower.startswith(s))
                    sample_type = f'Reference ({prefix.upper()})'
                elif any(spot_lower.startswith(u) for u in unknowns):
                    prefix = next(u for u in unknowns if spot_lower.startswith(u))
                    sample_type = f'Unknown ({prefix.upper()})'

                valid_data_lines = []
                file_datetime = None

                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                    if dt_regex and datetime_row < len(lines):
                        target_line = lines[datetime_row]
                        match = dt_regex.search(target_line)
                        if match:
                            try:
                                from datetime import datetime
                                file_datetime = datetime.strptime(match.group(), datetime_format)
                            except ValueError:
                                pass

                    start_idx = signal_row_from
                    for i in range(start_idx, len(lines)):
                        line = lines[i].strip()
                        if not line or ',' not in line:
                            break
                        valid_data_lines.append(line)

                if file_datetime is None:
                    from datetime import datetime
                    file_datetime = datetime.now()

                if valid_data_lines:
                    data = np.genfromtxt(valid_data_lines, delimiter=',', usecols=target_col_indices)
                    if signal_row_to:
                        rows_to_read = signal_row_to - signal_row_from
                        if data.shape[0] > rows_to_read:
                            data = data[:rows_to_read, :]

                    if data is not None and data.size > 0:
                        if data.ndim == 1:
                            data = data.reshape(1, -1)
                        signals_list.append(data)
                        spots.append(spot_name)
                        datetimes.append(file_datetime)
                        all_sample_types.append(sample_type)

            except Exception as e:
                print(f"Error reading file {filename}: {e}")

        if not signals_list:
            print("No valid data read.")
            return None, None, None, None

        min_rows = min(d.shape[0] for d in signals_list)
        signals_array = np.array([d[:min_rows, :] for d in signals_list])

        self.signals = signals_array.transpose(1, 2, 0)

        datetimes_arr = np.array(datetimes, dtype='datetime64[s]')
        order = np.argsort(datetimes_arr)

        self.signals = self.signals[:, :, order]
        self.spots = np.array(spots)[order]
        self.datetimes = datetimes_arr[order]
        self.sample_types = np.array(all_sample_types)[order]

        return self.signals, self.spots, self.datetimes, target_col_names

    def slide_windows(self, signal_1d, winsize=3):
        sub_windows = np.arange(winsize) + np.arange(signal_1d.shape[0] - winsize + 1).reshape(-1, 1)
        return signal_1d[sub_windows]

    def auto_cutoff(self, signals, spots, isotope: int, slope_winsize=3, mean_winsize=5):
        cutoff1, cutoff2, cutoff3 = 0, 0, 0
        cutoff1_spot, cutoff2_spot, cutoff3_spot = "N/A", "N/A", "N/A"
        for i, spot in enumerate(spots):
            if signals.shape[0] <= max(slope_winsize, mean_winsize) + 5:
                continue
            slope_windows = self.slide_windows(signals[:, isotope, i], winsize=slope_winsize)
            slopes = np.polynomial.polynomial.polyfit(range(slope_winsize), slope_windows.T, deg=1)[1]
            mean_windows = self.slide_windows(signals[:, isotope, i], winsize=mean_winsize)
            means = np.mean(mean_windows, axis=1)
            if means.size == 0:
                continue
            means_max = np.argmax(means)
            slopes_half_left = slopes[:means_max]
            slopes_half_right = slopes[means_max:]
            slopes_half_left_max = np.argmax(np.abs(slopes_half_left)) if slopes_half_left.size > 0 else 0
            slopes_half_right_max = np.argmax(
                np.abs(slopes_half_right)) + means_max if slopes_half_right.size > 0 else means_max

            if i == 0 or cutoff1_spot == "N/A":
                cutoff1 = slopes_half_left_max
                cutoff1_spot = spot
                cutoff2 = means_max
                cutoff2_spot = spot
                cutoff3 = slopes_half_right_max
                cutoff3_spot = spot
            else:
                if means_max > cutoff2 and means_max < signals.shape[0] * 0.3:
                    cutoff2 = means_max
                    cutoff2_spot = spot
                if slopes_half_left_max < cutoff1 and slopes_half_left_max < cutoff2:
                    cutoff1 = slopes_half_left_max
                    cutoff1_spot = spot
                if slopes_half_right_max > signals.shape[0] * 0.9 and slopes_half_right_max < cutoff3:
                    cutoff3 = slopes_half_right_max
                    cutoff3_spot = spot
        self.cutoffs = [cutoff1, cutoff2, cutoff3]
        self.cutoff_spots = [cutoff1_spot, cutoff2_spot, cutoff3_spot]
        return self.cutoffs, self.cutoff_spots

    def signal_plot(self, ax, signals: np.ndarray, datetimes: np.ndarray, spots: np.ndarray,
                    spotname: str, isotopes: list, signaltitle: list,
                    log=False, abstime=False,
                    cutoffs=None, cutoff_spots=None):
        try:
            spot_idx = np.where(spots == spotname)[0][0]
        except IndexError:
            ax.text(0.5, 0.5, f"Sample '{spotname}' not found",
                    ha='center', va='center', transform=ax.transAxes)
            return

        sample_signal = signals[:, :, spot_idx]
        time_x = sample_signal[:, 0]
        ax.set_xlabel("Time (s)")

        for i, iso_idx in enumerate(isotopes):
            if iso_idx < sample_signal.shape[1]:
                label = signaltitle[i] if i < len(signaltitle) else f"Ch{iso_idx}"
                ax.plot(time_x, sample_signal[:, iso_idx], label=label, lw=1.0)

        if cutoffs is not None and len(cutoffs) == 3:
            colors = ['k', 'r', 'r']
            try:
                time_cutoff1 = time_x[cutoffs[0]]
                time_cutoff2 = time_x[cutoffs[1]]
                time_cutoff3 = time_x[cutoffs[2]]
            except IndexError:
                time_cutoff1, time_cutoff2, time_cutoff3 = None, None, None

            if time_cutoff1 is not None:
                ax.axvline(x=time_cutoff1, color=colors[0], linestyle='--')
                ax.axvline(x=time_cutoff2, color=colors[1], linestyle='--')
                ax.axvline(x=time_cutoff3, color=colors[2], linestyle='--')

        ax.set_title(f"Sample: {spotname}")
        ax.set_ylabel("Intensity (cps)")
        if log: ax.set_yscale('log')
        ax.legend(loc='upper right', fontsize='small')
        ax.grid(True, which='both', linestyle='--')
        ax.figure.tight_layout()

    def time_abs2ref(self, time_abs):
        referece_time = np.datetime64('2020-01-01T00:00:00')
        time_ref = (time_abs - referece_time) / np.timedelta64(1, 's')
        return time_ref

    def time_ref2abs(self, time_ref):
        referece_time = np.datetime64('2020-01-01T00:00:00')
        time_abs = referece_time + time_ref.astype('timedelta64[s]')
        return time_abs

    def time_series(self, datetimes, time):
        dts = self.time_abs2ref(datetimes)
        timeSeries_ref = np.hstack([dts[:, np.newaxis]] * time.shape[0]) + time
        timeSeries_abs = self.time_ref2abs(timeSeries_ref)
        return timeSeries_ref, timeSeries_abs

    def bkg_separate(self, signals, cutoffs):
        self.signals_eff = signals[cutoffs[1]:cutoffs[2], :, :]
        self.time_eff = self.signals_eff[:, 0, 0]
        self.signals_bkg = signals[:cutoffs[0], :, :]
        self.time_bkg = self.signals_bkg[:, 0, 0]
        return self.time_bkg, self.signals_bkg, self.time_eff, self.signals_eff

    def bkg_substract(self, datetimes: np.ndarray, signals: np.ndarray, cutoffs: list, dof=4):
        self.bkg_separate(signals, cutoffs)
        
        timeBkg = self.time_bkg
        signalsBkg = self.signals_bkg
        timeEff = self.time_eff
        signalsEff = self.signals_eff

        # 2. 【加入物理拦截网】防止用户把背景结束点设得太小（比如设成了 0 或 1）
        if timeBkg is None or len(timeBkg) < 3:
            current_len = len(timeBkg) if timeBkg is not None else 0
            raise ValueError(f"Critical Error: Too few valid background data points (only {current_len} remaining).\n"
                             f"Please increase the first value (Background End) in 'Manual Cutoff Settings'. ")

        timeBkgRef, self.time_bkg_abs = self.time_series(datetimes, timeBkg)
        timeEffRef, _ = self.time_series(datetimes, timeEff)
        X_bk = np.mean(timeBkgRef, axis=1)

        spline_func = SplineTransformer(n_knots=6, degree=3, include_bias=True)
        X_bk_basis = spline_func.fit_transform(X_bk.reshape(-1, 1))
        X_bk_basis_const = sm.add_constant(X_bk_basis)
        X_sp = timeEffRef.ravel()
        X_sp_basis = spline_func.fit_transform(X_sp.reshape(-1, 1))
        X_sp_basis_const = sm.add_constant(X_sp_basis)

        self.signals_eff_bs = signalsEff[:, 0:1, :]
        self.bkg_fits = np.empty((1, X_bk.shape[0]))
        self.bkg_fits_conf95 = np.empty((1, X_bk.shape[0], 2))

        for isotope in range(1, signalsEff.shape[1]):
            Y_bk = np.mean(signalsBkg[:, isotope, :], axis=0)
            BsFit = sm.OLS(Y_bk, X_bk_basis_const).fit()
            BsFit_pred = BsFit.get_prediction(X_bk_basis_const)
            Yfit = unumpy.uarray(BsFit_pred.predicted, BsFit_pred.se)
            Yfit_conf95 = BsFit_pred.conf_int(obs=False, alpha=0.05)
            self.bkg_fits = np.concatenate((self.bkg_fits, Yfit[np.newaxis, :]), axis=0)
            self.bkg_fits_conf95 = np.concatenate((self.bkg_fits_conf95, Yfit_conf95[np.newaxis, :, :]), axis=0)
            Y_sp = BsFit.get_prediction(X_sp_basis_const)
            bs = signalsEff[:, isotope, :].T.ravel() - Y_sp.predicted
            bs.resize(signalsEff.shape[2], signalsEff.shape[0])
            self.signals_eff_bs = np.concatenate((self.signals_eff_bs, bs.T[:, np.newaxis, :]), axis=1)

        print(f"Bkg subtracted: Eff_BS shape {self.signals_eff_bs.shape}")
        return self.time_eff, self.signals_eff_bs

    def bkg_plot(self, ax, timeBkgAbs, signalsBkg, spots,
                 bkgFits, bkgFits_conf95, signaltitle, isotope: int):
        if timeBkgAbs is None or signalsBkg is None or bkgFits is None:
            ax.text(0.5, 0.5, "Background data not calculated yet",
                    ha='center', va='center', transform=ax.transAxes)
            return

        if isotope >= signalsBkg.shape[1] or isotope >= bkgFits.shape[0]:
            if bkgFits.shape[0] > 0:
                isotope = min(isotope, bkgFits.shape[0] - 1)
            else:
                return

        lines = ax.plot(timeBkgAbs.T, signalsBkg[:, isotope, :], color='b', alpha=0.5, zorder=1)
        if lines:
            lines[0].set_label('Background Signals')

        tm = timeBkgAbs.shape[1] // 2
        ax.plot(timeBkgAbs[:, tm].ravel(), unumpy.nominal_values(bkgFits[isotope, :]),
                color='r', label='Background spline fitting', zorder=3)

        ax.fill_between(timeBkgAbs[:, tm].ravel(),
                        bkgFits_conf95[isotope, :, 0],
                        bkgFits_conf95[isotope, :, 1],
                        color='red', lw=0., alpha=0.2, label='95% Confidence intervals', zorder=2)

        y_min, y_max = ax.get_ylim()
        y_ann = y_min + 0.25 * (y_max - y_min)

        for i, spot in enumerate(spots):
            x_pos = timeBkgAbs[i, tm]
            if i % 2 == 0:
                ax.annotate(text=spot, xy=(x_pos, y_ann),
                            xytext=(-15, 0), textcoords='offset pixels', rotation=90)
            else:
                ax.annotate(text=spot, xy=(x_pos, y_ann),
                            xytext=(5, 0), textcoords='offset pixels', rotation=90)

        ax.legend(loc='upper right', frameon=False, fontsize='small')
        ax.set_xlabel('Time Series')
        ax.set_ylabel('Count per second')
        title_text = "background signals and spline fitting"
        if signaltitle and isotope < len(signaltitle):
            title_text = f"{signaltitle[isotope]} {title_text}"
        ax.set_title(title_text)
        ax.figure.tight_layout()

    def ratio_upb(self, signals, pb206: int, pb207: int, u238: int):
        self.r68 = (signals[:, pb206, :] / signals[:, u238, :])
        self.r75 = (signals[:, pb207, :] * self.U8U5 / signals[:, u238, :])
        self.r76 = (signals[:, pb207, :] / signals[:, pb206, :])
        return self.r68, self.r75, self.r76

    def ratio_stack(self, ratio: np.ndarray, standard_name: str):
        std_indices = np.where(self.sample_types == standard_name)[0]
        if std_indices.size == 0:
            raise ValueError(f"没有找到名为 '{standard_name}' 的标样，无法堆叠。")
        ratio_std_only = ratio[:, std_indices]
        ratioMean = np.mean(ratio_std_only, axis=1)
        ratioSE = np.std(ratio_std_only, axis=1) / np.sqrt(ratio_std_only.shape[1])
        ratioStacked = unumpy.uarray(ratioMean, ratioSE)

        return ratioStacked

    def downhole_fit(self, timeEff: np.ndarray, ratioStack: np.ndarray, curve='convex'):
        Y = unumpy.nominal_values(ratioStack)
        Ye = unumpy.std_devs(ratioStack)
        X = timeEff

        def exp_func(x, a, b, c):
            return a + b * np.exp(c * x)

        exp_model = lmfit.Model(exp_func)

        exp_params_concave = exp_model.make_params(
            a={'value': np.min(Y), 'min': np.min(Y) / 2.0, 'max': 2.0 * np.max(Y)},
            b={'value': np.max(Y) - np.min(Y), 'min': -np.max(Y), 'max': np.max(Y) - np.min(Y)},
            c={'value': 1.0 / (np.max(X) - np.min(X))})
        
        result_concave = exp_model.fit(Y, exp_params_concave, weights=1.0 / Ye ** 2,
                                       method='leastsq', scale_covar=False, x=X)

        exp_params_convex = exp_model.make_params(
            a={'value': np.max(Y), 'min': np.min(Y) / 2.0, 'max': 2.0 * np.max(Y)},
            b={'value': -np.max(Y), 'min': -np.max(Y), 'max': np.max(Y) - np.min(Y)},
            c={'value': -1.0 / (np.max(X) - np.min(X))})
        
        result_convex = exp_model.fit(Y, exp_params_convex, weights=1.0 / Ye ** 2,
                                      method='leastsq', scale_covar=False, x=X)

        if curve == 'convex':
            dely = result_convex.eval_uncertainty(sigma=2)
            result = result_convex
        elif curve == 'concave':
            dely = result_concave.eval_uncertainty(sigma=2)
            result = result_concave
        else:
            raise ValueError("curve param should be convex or concave")

        DhFit = result.best_fit
        DhFitParams = result.uvars
        DhFitConf95 = np.array([result.best_fit - dely, result.best_fit + dely]).T
        DhFitResid = result.residual

        return DhFit, DhFitParams, DhFitConf95, DhFitResid

    def ratio_plot(self, ax, timeEff: np.ndarray, ratio: np.ndarray, ratio_err: np.ndarray = None,
                   Yfit: np.ndarray = None, Yfit_conf: np.ndarray = None,
                   ylabel='Ratio', title='Signal Ratios'):
        lines = ax.plot(timeEff, ratio, color='b', lw=0.5, alpha=0.5, zorder=1, label='Stacked Ratio')
        ax.set_title(title)
        ax.set_xlabel('Time in Second')
        ax.set_ylabel(ylabel)

        if ratio_err is not None:
            ax.errorbar(timeEff, ratio, ratio_err, fmt='none', ecolor='b', alpha=.25, zorder=2, label='Std Dev')
        if Yfit is not None:
            ax.plot(timeEff, Yfit, label='Downhole Fit Curve', color='r', zorder=3)
        if Yfit_conf is not None:
            ax.fill_between(timeEff, Yfit_conf[:, 0], Yfit_conf[:, 1],
                            lw=0., label='95% Confidence', color='red', alpha=0.2, zorder=4)

        ax.legend(loc='upper left', frameon=False, fontsize='small')
        ax.figure.tight_layout()

    def resid_plot(self, ax, YfitResid, bins=30, title='Residue of Downhole Fitting'):
        resid_dw = sm.stats.stattools.durbin_watson(YfitResid, axis=0)
        resid_jb, _, _, _ = sm.stats.stattools.jarque_bera(YfitResid, axis=0)

        kde_resid = sm.nonparametric.KDEUnivariate(YfitResid)
        kde_resid.fit(kernel='gau', fft=False, weights=None, bw='normal_reference', adjust=1.5)

        ax.hist(YfitResid, bins=bins, density=True,
                weights=None, stacked=True, color='g', alpha=0.25, label='Fitting Residue')
        ax.plot(kde_resid.support, kde_resid.density, color='g', lw=1, label='KDE')
        ax.legend(loc='upper left', frameon=False, fontsize='small')

        text = 'Durbin Watson: {:.2f}'.format(resid_dw) + '\n' + 'Jarque Bera: {:.2f}'.format(resid_jb)
        x_text = ax.get_xlim()[0] + 0.62 * (ax.get_xlim()[1] - ax.get_xlim()[0])
        y_text = ax.get_ylim()[0] + 0.88 * (ax.get_ylim()[1] - ax.get_ylim()[0])
        ax.text(x_text, y_text, text, fontsize='small')
        ax.set_title(title)
        ax.figure.tight_layout()

    def downhole_plot_combined(self, fig, timeEff, ratio_stacked,
                               fit_curve, fit_ci, fit_resid,
                               ylabel, title_prefix):
        ax1 = fig.add_subplot(121)
        ax2 = fig.add_subplot(122)

        self.ratio_plot(
            ax1,
            timeEff,
            unumpy.nominal_values(ratio_stacked),
            unumpy.std_devs(ratio_stacked),
            Yfit=fit_curve,
            Yfit_conf=fit_ci,
            ylabel=ylabel,
            title=f'{title_prefix} Fitting'
        )

        if fit_resid is not None:
            self.resid_plot(
                ax2,
                fit_resid,
                bins=20,
                title=f'{title_prefix} Residue'
            )
        fig.tight_layout()

    def apply_downhole_calibration(self, timeEff: np.ndarray, fit_params: dict, ratio: np.ndarray):
        a = fit_params['a']
        b = fit_params['b']
        c = fit_params['c']
        X = timeEff
        Yfit = a + b * unumpy.exp(c * X)
        try:
            ratio_dh = ratio * a / Yfit[:, np.newaxis]
            print(f"Downhole calibration applied. Shape: {ratio_dh.shape}")
            return ratio_dh
        except Exception as e:
            print(f"Error applying calibration: {e}")
            return None
    # ----------------------------------------------------------------------
    # [替换] 漂移拟合函数 (基于您提供的代码)
    # ----------------------------------------------------------------------
    def drift_fit(self, datetimes, rDh, dof=None, n_knots=None, outer=[]):
        """
        Fit the age or ratio drifting of the standard spots (K-) through time series.
        """
        try:
            # 1. 时间轴转换
            # 对应 X_avg = TimeAbs2Ref(datetimes)
            X_avg = self.time_abs2ref(datetimes)

            # 2. 计算加权平均 (Y轴数据)
            # 对应 Y_avg,_ = WeightedAverage(rDh)
            # 注意：这里 rDh 应该是 2D 数组 (Time x Spots)
            if rDh.ndim == 2:
                Y_avg_u, _ = self.weighted_average(rDh, err='internal')
            else:
                # 兼容 Best Segment 的 1D 数据情况
                Y_avg_u = rDh

            Y_avg = unumpy.nominal_values(Y_avg_u)

            # 3. 处理 Outlier (outer)
            if len(outer) != 0:
                X_avg = np.delete(X_avg, outer)
                Y_avg = np.delete(Y_avg, outer)

            # 4. 构建样条基函数
            if (n_knots is not None) and (dof is None):
                # 使用 SplineTransformer
                # 确保 n_knots 不超过数据点数量
                effective_knots = min(n_knots, len(Y_avg) - 1) if len(Y_avg) > 1 else 1
                spline_func = SplineTransformer(n_knots=effective_knots, degree=3, include_bias=True)
                X_avg_basis = spline_func.fit_transform(X_avg.reshape(-1, 1))
                
                # 为了生成预测曲线，我们需要覆盖整个时间范围的基函数
                # (这里稍微扩展一下逻辑，以便绘图曲线能覆盖所有点)
                # 但核心拟合还是基于 X_avg_basis
                
            elif (n_knots is None) and (dof is not None):
                # 使用 patsy
                from patsy import dmatrix  # 确保引入
                X_avg_basis = dmatrix("bs(x, df=dof, degree=3, include_intercept=False)", {"x": X_avg})
            else:
                # 默认回退方案
                if n_knots is None: n_knots = 6
                effective_knots = min(n_knots, len(Y_avg) - 1) if len(Y_avg) > 1 else 1
                spline_func = SplineTransformer(n_knots=effective_knots, degree=3, include_bias=True)
                X_avg_basis = spline_func.fit_transform(X_avg.reshape(-1, 1))

            # 5. 执行拟合
            X_avg_basis_const = sm.add_constant(X_avg_basis)
            DcFit = sm.OLS(Y_avg, X_avg_basis_const).fit()

            # 6. 生成预测曲线 (用于绘图和返回)
            # 我们直接用拟合模型对输入点进行预测
            DcFit_pred = DcFit.get_prediction(X_avg_basis_const)
            DcFitCurve = DcFit_pred.predicted
            DcFitCurveConf95 = DcFit_pred.conf_int(obs=False, alpha=0.05)

            # [关键] 为了兼容 Controller 的 update_drift_plot，
            # 我们需要返回 5 个值: (Model, Curve, Conf, X_axis, Y_axis)
            return DcFit, DcFitCurve, DcFitCurveConf95, X_avg, Y_avg

        except Exception as e:
            print(f"Configuration error in drift_fit: {e}")
            import traceback
            traceback.print_exc()
            return None, None, None, None, None

    # ----------------------------------------------------------------------
    # [替换] 加权平均函数 (基于您提供的代码)
    # ----------------------------------------------------------------------
    def weighted_average(self, a_r_array, err='internal'):
        """
        Calculate the weighted average for 2D age (a) or ratio (r) matrix
        """
        # 分离数值与不确定度
        values = unumpy.nominal_values(a_r_array)
        uncertainties = unumpy.std_devs(a_r_array)

        # 统计有效个数
        counts = np.sum(~unumpy.isnan(a_r_array), axis=0)
        dof = np.maximum(1, counts - 1)

        # 方差的倒数作为权重值
        # [修改] 使用 np.divide 安全除法，处理 uncertainties=0 的情况
        with np.errstate(divide='ignore', invalid='ignore'):
            weights = np.divide(1.0, uncertainties ** 2, where=uncertainties != 0)
            weights[np.isnan(weights)] = 0
            
            # [补充] 如果某列全是 0 误差（纯数值情况），则退化为算术平均
            # 检查 sum_weights 是否为 0
            temp_sum = np.sum(weights, axis=0)
            if np.ndim(temp_sum) == 0:
                if temp_sum == 0: weights = np.ones_like(values)
            else:
                zero_weight_cols = (temp_sum == 0)
                if np.any(zero_weight_cols):
                    # 将这些列的权重设为 1
                    # 注意：维度匹配问题，weights是2D，zero_weight_cols是1D
                    weights[:, zero_weight_cols] = 1.0

        # 计算加权平均
        sum_weights = np.nansum(weights, axis=0)
        
        with np.errstate(divide='ignore', invalid='ignore'):
            mean = np.nansum(weights * values, axis=0) / sum_weights

            # 计算 MSWD
            mswd = np.nansum(weights * (values - mean) ** 2, axis=0) / dof

            # 计算内部标准误差
            se_internal = np.sqrt(1.0 / sum_weights)

        # 检查 MSWD > 1
        inflation_factor = np.maximum(1.0, mswd)
        
        # 计算外部标准误差
        se_external = se_internal * np.sqrt(inflation_factor)

        # 处理无效值 (sum_weights == 0)
        if np.ndim(mean) > 0:
            invalid = (sum_weights == 0)
            mean[invalid] = np.nan
            se_internal[invalid] = np.nan
            se_external[invalid] = np.nan
        elif sum_weights == 0:
             return ufloat(np.nan, np.nan), np.nan

        # 组合成 uncertainties 类型
        if err == 'internal':
            a_r_arrayAvg = unumpy.uarray(mean, se_internal)
            return a_r_arrayAvg, mswd
        elif err == 'external':
            a_r_arrayAvg = unumpy.uarray(mean, se_external)
            return a_r_arrayAvg, mswd
        else:
            raise ValueError("The err param should be internal or external!")
    def drift_fit_plot(self, ax, datetimes, time_eff, r_data_2d, spots, curve, conf, outer=[], ylabels='Ratio'):
        """
        完全复刻 autoUPb.DriftFitPlot 的绘图逻辑：
        绘制每个 spot 的 2D 信号轨迹 (Spaghetti plot)，并覆盖拟合曲线。
        """
        if curve is None: return

        # 1. 还原 2D 绝对时间轴 (用于绘制每个 spot 的轨迹)
        # 使用与 autoUPb 相同的 TimeSeries 逻辑
        _, time_eff_abs = self.time_series(datetimes, time_eff)

        # 2. 获取数值 (从 2D unumpy 数组中提取 nominal_values)
        if isinstance(r_data_2d, np.ndarray) and r_data_2d.dtype == object:  # Check if uarray
            values = unumpy.nominal_values(r_data_2d)
        else:
            values = r_data_2d  # Assume it's already nominal if not uarray

        # 3. 绘制 Inner Spots (蓝色)
        mask = np.ones(len(datetimes), dtype=bool)
        if outer:
            mask[outer] = False

        # 注意：matplotlib plot 接受 (time_eff_abs.T, values) 这种形式来一次性绘制多条线
        inner_lines = ax.plot(time_eff_abs.T[:, mask], values[:, mask], color='b', lw=0.5, alpha=0.6)

        # 4. 绘制 Outer Spots (橙色)
        if outer:
            outer_lines = ax.plot(time_eff_abs.T[:, outer], values[:, outer], color='orange', lw=0.5, alpha=0.6)

        # 5. 绘制拟合曲线 (红色)
        # 还原 curve 的时间轴 (mean time)
        # 注意：curve 对应的是 datetimes 这个 1D 时间轴
        ax.plot(datetimes, curve, color='r', lw=2, label='Spline fitting', zorder=10)

        # 6. 绘制置信区间
        ax.fill_between(datetimes, conf[:, 0], conf[:, 1],
                        color='red', lw=0., alpha=0.2, label='95% Confidence intervals', zorder=9)

        # 7. 标注 Spot 名字
        # 寻找每个 spot 轨迹的最低点作为标注位置，与 autoUPb 逻辑一致
        for i, spot in enumerate(spots):
            x = datetimes[i]
            y = np.nanmin(values[:, i])
            if i % 2 == 0:
                ax.annotate(text=spot, xy=(x, y), xytext=(-15, 0),
                            textcoords='offset pixels', rotation=90, fontsize=8)
            else:
                ax.annotate(text=spot, xy=(x, y), xytext=(5, 0),
                            textcoords='offset pixels', rotation=90, fontsize=8)

        # 8. 图例与标签
        handles, labels = ax.get_legend_handles_labels()
        # 手动添加 Inner/Outer 的图例说明
        # 创建虚拟的 Line2D 对象用于图例显示颜色
        from matplotlib.lines import Line2D
        custom_lines = [Line2D([0], [0], color='b', lw=2),
                        Line2D([0], [0], color='r', lw=2)]
        custom_labels = ['Used Signals', 'Spline fitting']

        if outer:
            custom_lines.insert(1, Line2D([0], [0], color='orange', lw=2))
            custom_labels.insert(1, 'Removed Signals')

        ax.legend(custom_lines, custom_labels, loc='upper right', frameon=False, fontsize='small')

        ax.set_xlabel('Time Series')
        ax.set_ylabel(ylabels)
        ax.set_title(f'Drift Fit: {ylabels}')

    def drift_cali(self, dc_fit_model, datetimes_all, time_eff, r_dh_all, std_val, n_knots=None):
        """
        执行漂移校正 (复刻 autoUPb.DriftCali)
        """
        try:
            time_eff_ref, _ = self.time_series(datetimes_all, time_eff)
            if n_knots is None: n_knots = 6
            dts = self.time_abs2ref(datetimes_all)
            T_matrix = time_eff[:, np.newaxis] + dts[np.newaxis, :]
            X_flat = T_matrix.ravel(order='F')

            st = SplineTransformer(n_knots=n_knots, degree=3, include_bias=True)
            X_basis_f = st.fit_transform(X_flat.reshape(-1, 1))
            X_basis_const_f = sm.add_constant(X_basis_f)

            pred_res_f = dc_fit_model.get_prediction(X_basis_const_f)
            drift_y_f = unumpy.uarray(pred_res_f.predicted, pred_res_f.se)

            r_dh_flat = r_dh_all.ravel(order='F')
            r_dh_dc_flat = r_dh_flat * (std_val / drift_y_f)
            r_dh_dc = r_dh_dc_flat.reshape(r_dh_all.shape, order='F')

            print(f"Drift Calibration Done. Shape: {r_dh_dc.shape}")
            return r_dh_dc
        except Exception as e:
            print(f"Error in drift_cali: {e}")
            return None

    def age_upb(self, r68, r75):

        # 1. 对 206Pb/238U (r68) 进行消毒
        noms_68 = unumpy.nominal_values(r68)
        stds_68 = unumpy.std_devs(r68)
        noms_68 = np.where(noms_68 <= -1, np.nan, noms_68)
        safe_r68 = unumpy.uarray(noms_68, stds_68)

        # 2. 对 207Pb/235U (r75) 进行消毒
        noms_75 = unumpy.nominal_values(r75)
        stds_75 = unumpy.std_devs(r75)
        noms_75 = np.where(noms_75 <= -1, np.nan, noms_75)
        safe_r75 = unumpy.uarray(noms_75, stds_75)

        # 3. 安全计算最终年龄
        a68 = unumpy.log(safe_r68 + 1.) / self.LAMBDA_U238
        a75 = unumpy.log(safe_r75 + 1.) / self.LAMBDA_U235
        
        return a68, a75

    def solve_76_age_mc(self, r76_array):
        """复刻 autoUPb.Solve76ageMC"""
        u5u8 = 1.0 / self.U8U5
        num_samples = 10000
        age_min = 1.0
        age_max = 4500.

        random_ages = np.linspace(age_min, age_max, num_samples)
        random_ratios = u5u8 * (
                    (np.exp(self.LAMBDA_U235 * random_ages) - 1) / (np.exp(self.LAMBDA_U238 * random_ages) - 1))
        ratio_to_age = interp1d(random_ratios, random_ages, kind='linear', fill_value='extrapolate')

        a76_means = []
        a76_stds = []

        # 兼容单个值或数组输入
        iterable_r76 = r76_array if isinstance(r76_array, (list, np.ndarray)) else [r76_array]

        for r76 in iterable_r76:
            mean_r76 = r76.n
            std_r76 = r76.s
            if std_r76 <= 0 or np.isnan(std_r76):
                sampled_ages = np.array([ratio_to_age(mean_r76)])
            else:
                sampled_ratios = np.random.normal(loc=mean_r76, scale=std_r76, size=num_samples)
                sampled_ratios[sampled_ratios < 0] = np.nan
                sampled_ages = ratio_to_age(sampled_ratios)

            a76_means.append(np.nanmean(sampled_ages))
            a76_stds.append(np.nanstd(sampled_ages))

        return unumpy.uarray(a76_means, a76_stds)

    def covariance_75_68(self, r68, r75, r76):
        """复刻 autoUPb.Covariance75to68"""
        Sr75 = unumpy.std_devs(r75) / unumpy.nominal_values(r75)
        Sr68 = unumpy.std_devs(r68) / unumpy.nominal_values(r68)
        Sr76 = unumpy.std_devs(r76) / unumpy.nominal_values(r76)
        rho_r75r68 = (Sr75 ** 2 + Sr68 ** 2 - Sr76 ** 2) / (2 * Sr75 * Sr68)
        cov_r75r68 = rho_r75r68 * unumpy.std_devs(r75) * unumpy.std_devs(r68)
        return cov_r75r68, rho_r75r68

# 内插T-W谐和图,计算r68对应的谐和线上的r76比值
    def InterpR68toR76(self,r68, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5):
        num_samples = 1000  
        age_min = 0.1           
        age_max = 4500.
        u5u8 = 1./u8u5
        r86 = 1./r68
        # Generate random ages
        # Use linspace for better interpolation
        sample_ages = np.linspace(age_max, age_min, num_samples) 
        # Compute the model Pb207/Pb206 ratio for each age (vectorized) 
        sample_r86 = 1./np.expm1(la_u238 * sample_ages)
        sample_r76 = u5u8 * (np.expm1(la_u235 * sample_ages)  / np.expm1(la_u238 * sample_ages))
        # 基于立方样条构建内插函数
        f = CubicSpline(x=sample_r86, y=sample_r76, extrapolate=True)
        # 应用内插函数
        x = unumpy.nominal_values(r86)
        # 误差要单独传播
        x_err = unumpy.std_devs(r86)
        y = f(x)
        dy_dx = f.derivative()(x)
        # 误差传播公式
        y_err = np.abs(dy_dx) * x_err
        r76 = unumpy.uarray(y, y_err)
        return r76

    # 内插T-W谐和图,计算r76对应的谐和线上的r68比值
    def InterpR76toR68(self,r76, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5):
        num_samples = 1000  
        age_min = 0.1           
        age_max = 4500.
        u5u8 = 1./u8u5
        # Generate random ages
        # Use linspace for better interpolation
        sample_ages = np.linspace(age_min, age_max, num_samples) 
        # Compute the model Pb207/Pb206 ratio for each age (vectorized) 
        sample_r86 = 1./np.expm1(la_u238 * sample_ages)
        sample_r76 = u5u8 * (np.expm1(la_u235 * sample_ages)  / np.expm1(la_u238 * sample_ages))
        # 基于立方样条构建内插函数
        f = CubicSpline(x=sample_r76, y=sample_r86, extrapolate=True)
        # 应用内插函数
        x = unumpy.nominal_values(r76)
        # 误差要单独传播
        x_err = unumpy.std_devs(r76)
        y = f(x)
        dy_dx = f.derivative()(x)
        # 误差传播公式
        y_err = np.abs(dy_dx) * x_err
        r86 = unumpy.uarray(y, y_err)
        return 1./r86
        
    # 计算r68对应的谐和线上的r75比值（直接根据年龄公式计算最简单）
    def InterpR68toR75(self,r68,la_u235=LAMBDA_U235, la_u238=LAMBDA_U238):
            # 计算理想（谐和线上）的点位
            ratio= la_u235/la_u238
            r75 = unumpy.exp(ratio * unumpy.log(r68 + 1)) -1
            return r75
        
    # 计算r75对应的谐和线上的r68比值（直接根据年龄公式计算最简单）
    def InterpR75toR68(self,r75,la_u235=LAMBDA_U235, la_u238=LAMBDA_U238):
            # 计算理想（谐和线上）的点位
            ratio = la_u238/la_u235
        
            # 1. 拆解带有误差的 ufloat 数组，提取名义值(noms)和标准差(stds)
            noms = unumpy.nominal_values(r75)
            stds = unumpy.std_devs(r75)
            
            # 2. 核心防御：找出所有 <= -1 的非法数据，将其名义值强制设为 np.nan
            # 这样既避免了 log 崩溃，又能让这段废数据在挑选最佳积分段时自然落选
            noms = np.where(noms <= -1, np.nan, noms)
            
            # 3. 重新组装成安全的 uncertainties 数组
            safe_r75 = unumpy.uarray(noms, stds)
            
            # 4. 执行原有的对数和指数计算
            r68 = unumpy.exp(ratio * unumpy.log(safe_r75 + 1)) - 1
            return r68

    # upbapp/models/data_processor.py

    #   不协和度判断不好标样
    # def draw_ellipse(self, ax, rX, rY, cov_rXrY, spot, ellConf=0.95, inOuter=False, type='wetherill'):
    #     """
    #     绘制误差椭圆
    #     新增 type 参数: 'wetherill' 或 'tw'，用于控制 Outlier (Outer) 标注的位置逻辑
    #     """
    #     # 1. 构建协方差矩阵
    #     cov = [[rX.s**2, cov_rXrY], [cov_rXrY, rY.s**2]]
        
    #     # 2. 计算特征值和特征向量
    #     vals, vecs = np.linalg.eigh(cov)
        
    #     # 3. 计算旋转角度 (转为度)
    #     theta = np.degrees(np.arctan2(vecs[0, 1], vecs[0, 0]))
        
    #     # 4. 计算长短轴 (卡方分布置信度)
    #     width, height = 2 * np.sqrt(stats.chi2.ppf(ellConf, 2) * np.abs(vals))
        
    #     # 5. 绘图逻辑
    #     if inOuter:
    #         # 远离中心的点 (Outer): 红色虚线或特定样式
    #         ellipse = Ellipse((rX.n, rY.n), width, height, angle=theta,
    #                           edgecolor='r', facecolor='none', linewidth=0.5)
            
    #         # 复刻 autoUPb 的标注逻辑
    #         rXc = 0
    #         if type == 'wetherill':
    #             rXc = unumpy.nominal_values(self.interp_r75_to_r68(rX)) # 需确保有此内插逻辑，如果没有可简化
    #         elif type == 'tw':
    #             # TW图的内插逻辑: rXc 是谐和线上的 X 值
    #             # 简单处理：仅根据相对位置标注
    #             pass 
            
    #         # 简单标注逻辑 (左侧或右侧)
    #         ax.annotate(spot, xy=(rX.n, rY.n), xytext=(-50, 0), 
    #                     textcoords='offset pixels', color='r', fontsize=8)
    #     else:
    #         # 正常点: 蓝色半透明填充
    #         ellipse = Ellipse((rX.n, rY.n), width, height, angle=theta,
    #                           edgecolor='k', facecolor='b', alpha=0.2, linewidth=0.5)
        
    #     ax.add_patch(ellipse)
    def draw_ellipse(self, ax, rX, rY, cov_rXrY, spot, ellConf=0.95, inOuter=False, type='wetherill'):
        """
        绘制误差椭圆
        修正版：移除了导致报错的内插逻辑，专注实现剔除点(Outer)的红色高亮显示。
        """
        from matplotlib.patches import Ellipse
        import numpy as np
        from scipy import stats

        # 1. 构建协方差矩阵
        cov = [[rX.s**2, cov_rXrY], [cov_rXrY, rY.s**2]]
        
        # 2. 计算特征值和特征向量
        vals, vecs = np.linalg.eigh(cov)
        
        # 3. 计算旋转角度 (转为度)
        theta = np.degrees(np.arctan2(vecs[0, 1], vecs[0, 0]))
        
        # 4. 计算长短轴 (卡方分布置信度)
        width, height = 2 * np.sqrt(stats.chi2.ppf(ellConf, 2) * np.abs(vals))
        
        # 5. 绘图逻辑
        if inOuter:
            # 💥 被剔除的坏点 (Outer): 醒目的红色虚线，内部透明，画在最上层
            ellipse = Ellipse((rX.n, rY.n), width, height, angle=theta,
                              edgecolor='red', facecolor='none', 
                              linestyle='--', linewidth=1.5, zorder=3)
            
            # 简单粗暴的标注逻辑：直接把名字标在椭圆右上角一点点
            ax.annotate(spot, xy=(rX.n, rY.n), xytext=(5, 5), 
                        textcoords='offset pixels', color='red', fontsize=8, zorder=4)
        else:
            # ✅ 正常的好点 (Inner): 黑色边框，蓝色半透明填充，画在下层
            ellipse = Ellipse((rX.n, rY.n), width, height, angle=theta,
                              edgecolor='k', facecolor='b', 
                              alpha=0.2, linewidth=0.5, zorder=2)
        
        ax.add_patch(ellipse)
    def concordia_plot(self, ax, r68, r75, r76, spots, title, is_detrital=False, is_valid_mask=None):
        """
        [主绘图函数] Wetherill 谐和图
        """
        if r68 is None or len(r68) == 0: return

        # 【新增】：如果没有传入掩码，默认全都是好点
        if is_valid_mask is None:
            is_valid_mask = np.ones(len(r68), dtype=bool)

        # 1. 确定绘图范围
        r68_values = unumpy.nominal_values(r68)
        valid = r68_values > 0
        if not np.any(valid): return

        r68_max_age = np.log(np.max(r68_values[valid]) + 1.) / self.LAMBDA_U238
        r68_min_age = np.log(np.min(r68_values[valid]) + 1.) / self.LAMBDA_U238

        age_range_up = math.ceil(r68_max_age / 10.) * 10 + math.ceil(r68_max_age * .01) * 10
        age_range_down = math.floor(r68_min_age / 10.) * 10 - math.ceil(r68_min_age * .01) * 10
        age_range_down = max(0, age_range_down)

        interval = (age_range_up - age_range_down) / 10.
        if interval == 0: interval = 100
        age_range = np.arange(age_range_down, age_range_up + interval, interval)

        # 2. 画谐和线
        r75Con = np.expm1(age_range * self.LAMBDA_U235)
        r68Con = np.expm1(age_range * self.LAMBDA_U238)

        ax.plot(r75Con, r68Con, color='k', lw=0.5, zorder=1)
        ax.scatter(r75Con, r68Con, marker='o', s=10, edgecolors='k', linewidths=0.5, facecolors='w', zorder=2)

        for i in range(len(r75Con)):
            ax.annotate(f"{age_range[i]:.0f}", xy=(r75Con[i], r68Con[i]),
                        xytext=(-20, 0), textcoords='offset pixels', fontsize=8)

        # 3. 计算统计值并标注
        if not is_detrital:
            # 【关键修改】：只用没被剔除的“好点”来计算加权平均和 MSWD！
            r68_good = r68[is_valid_mask]
            r75_good = r75[is_valid_mask]
            r76_good = r76[is_valid_mask]

            if len(r68_good) > 0:
                r68avg, mswd68 = self.weighted_average(r68_good)
                r75avg, mswd75 = self.weighted_average(r75_good)
                r76avg, mswd76 = self.weighted_average(r76_good)

                a68avg, a75avg = self.age_upb(r68avg, r75avg)
                a76avg = self.solve_76_age_mc(np.atleast_1d(r76avg))[0]

                text = (f'$^{{206}}$Pb/$^{{238}}$U Age: {a68avg:.1fP} ({mswd68:.1f})\n'
                        f'$^{{207}}$Pb/$^{{235}}$U Age: {a75avg:.1fP} ({mswd75:.1f})\n'
                        f'$^{{207}}$Pb/$^{{206}}$Pb Age: {a76avg:.1fP} ({mswd76:.1f})')

                ax.text(0.05, 0.75, text, transform=ax.transAxes, fontsize=9)

        # 4. 画椭圆
        cov_r75r68, _ = self.covariance_75_68(r68, r75, r76)
        
        for i in range(len(r75)):
            # 【关键修改】：如果 is_valid_mask 是 False，is_rejected 就是 True
            # inOuter=True 会让底层的 draw_ellipse 把它画成红色/虚线！
            is_rejected = not is_valid_mask[i] 
            self.draw_ellipse(ax, r75[i], r68[i], cov_r75r68[i], spots[i],
                              ellConf=0.95, inOuter=is_rejected)

        ax.set_title(title)
        ax.set_ylabel('$^{206}$Pb/$^{238}$U')
        ax.set_xlabel('$^{207}$Pb/$^{235}$U')
        ax.set_box_aspect(1)


    def concordia_plot_tw(self, ax, r68, r75, r76, spots, title, is_detrital=True, is_valid_mask=None):
        """
        [修正版] Tera-Wasserburg U-Pb Concordia Plot
        """
        if r68 is None or len(r68) == 0: return

        if is_valid_mask is None:
            is_valid_mask = np.ones(len(r68), dtype=bool)

        r68_values = unumpy.nominal_values(r68)
        valid_r68 = (r68_values > 0) & np.isfinite(r68_values)
        if not np.any(valid_r68): return

        r68_max_age = np.log(np.max(r68_values[valid_r68]) + 1.) / self.LAMBDA_U238
        r68_min_age = np.log(np.min(r68_values[valid_r68]) + 1.) / self.LAMBDA_U238

        age_range_up = math.ceil(r68_max_age / 10.) * 10 + math.ceil(r68_max_age * .01) * 10
        age_range_down = math.floor(r68_min_age / 10.) * 10 - math.ceil(r68_min_age * .01) * 10
        age_range_down = max(0, age_range_down)
        
        age_range_interval = math.ceil((age_range_up - age_range_down) / 100.) * 10
        if age_range_interval == 0: age_range_interval = 100
        age_range = np.arange(age_range_down, age_range_up, age_range_interval)

        r75Con = np.expm1(age_range * self.LAMBDA_U235)
        r68Con = np.expm1(age_range * self.LAMBDA_U238)
        
        with np.errstate(divide='ignore', invalid='ignore'):
            r86Con = 1. / r68Con
            r76Con = (r75Con / r68Con) / self.U8U5
        
        ax.plot(r86Con, r76Con, color='k', lw=0.5, zorder=1)
        ax.scatter(r86Con, r76Con, marker='o', s=10, edgecolors='k', linewidths=0.5, facecolors='w', zorder=2)

        n_points = len(r86Con)
        step = max(1, n_points // 12)
        for i in range(n_points):
            if i % step == 0 and np.isfinite(r86Con[i]) and np.isfinite(r76Con[i]):
                ax.annotate(f"{age_range[i]:.0f}", xy=(r86Con[i], r76Con[i]),
                            xytext=(-25, 5), textcoords='offset pixels', fontsize=8)

        if not is_detrital:
            try:
                # 【关键修改】：提取好点算统计
                r68_good = r68[is_valid_mask]
                r75_good = r75[is_valid_mask]
                r76_good = r76[is_valid_mask]

                if len(r68_good) > 0:
                    r68avg, mswd68 = self.weighted_average(r68_good)
                    r75avg, mswd75 = self.weighted_average(r75_good)
                    r76avg, mswd76 = self.weighted_average(r76_good)

                    a68avg, a75avg = self.age_upb(r68avg, r75avg)
                    a76avg = self.solve_76_age_mc(np.atleast_1d(r76avg))[0]

                    text = (f'$^{{206}}$Pb/$^{{238}}$U Age: {a68avg:.1fP} ({mswd68:.1f})\n'
                            f'$^{{207}}$Pb/$^{{235}}$U Age: {a75avg:.1fP} ({mswd75:.1f})\n'
                            f'$^{{207}}$Pb/$^{{206}}$Pb Age: {a76avg:.1fP} ({mswd76:.1f})')
                    ax.text(0.65, 0.85, text, transform=ax.transAxes, fontsize=8)
            except:
                pass

        cov_r86r76, _ = self.covariance_86_76(r68, r75, r76)
        with np.errstate(divide='ignore'):
            r86 = 1. / r68

        for i in range(len(r86)):
            if np.isfinite(unumpy.nominal_values(r86[i])) and np.isfinite(unumpy.nominal_values(r76[i])):
                # 【关键修改】：传递剔除状态
                is_rejected = not is_valid_mask[i]
                self.draw_ellipse(ax, r86[i], r76[i], cov_r86r76[i], spots[i],
                                  ellConf=0.95, inOuter=is_rejected, type='tw')

        ax.set_title(title)
        ax.set_ylabel('$^{207}$Pb/$^{206}$Pb')
        ax.set_xlabel('$^{238}$U/$^{206}$Pb')
        ax.set_box_aspect(1)

    # === 辅助函数：如果 data_processor.py 里还没有 covariance_86_76，请补上 ===
    def covariance_86_76(self, r68, r75, r76):
        """
        计算 T-W 图需要的协方差 (近似计算)
        """
        r87 = 1./(r76 * r68)
        Sr87 = unumpy.std_devs(r87) / unumpy.nominal_values(r87)
        r86 = 1./ r68
        Sr86 = unumpy.std_devs(r86) / unumpy.nominal_values(r86)
        Sr76 = unumpy.std_devs(r76) / unumpy.nominal_values(r76)  
        
        # error correlation
        rho_r86r76 = (Sr86**2 + Sr76**2 - Sr87**2) / (2 * Sr86 * Sr76) 
        # covariance
        cov_r86r76 = rho_r86r76 * unumpy.std_devs(r86) * unumpy.std_devs(r76)
        return cov_r86r76, rho_r86r76
# [在 DataProcessor 类中添加以下方法]  12.23
# 构建系数矩阵，设置最小的信号数 minwidth
    def CoeffMatrix(self,minwidth: int, signals: np.ndarray):
        '''
        Build a coefficient matrix (with only 0 and 1) for all possible singal segments. The segments can be got from multiplication of the signal set and ent coefficient matrix.
        
        AUGMENTS:
        minwidth: integar. Minimal width (number of signals) of the segments. Usually 1/3 of the effective signals.
        signals: 3d numpy array of signals.

        RETURNS:
        C3d: 3d numpy array of coefficient (with only 0 and 1). length = possible segments, width = effective signals, depth = spots.
        end3d: 3d numpy array. Start and end index of the segments. length = possible segments, width = 2, depth = spots.
        
        '''
        # 系数矩阵的width取决于minwidth
        width = signals.shape[0]
        depth = signals.shape[2]
        C2d = []
        ends2d = []
        for j in range(minwidth, width):  # 选择的信号个数从 minwidth 到 maxwidth
            for i in range(width - j):  # 区间的起始位置
                C2d_row = np.full(width, np.nan) # 构建nan矩阵
                C2d_row[i:i + j] = 1  # 将对应位置填充为 1
                ends2d.append([i,i + j]) #信号区间的首末位置
                C2d.append(C2d_row)
        C3d = np.repeat(np.array(C2d)[:, :, np.newaxis], depth, axis=2)
        ends3d = np.repeat(np.array(ends2d)[:, :, np.newaxis], depth, axis=2)
        return C3d, ends3d

    # ---------------------------------------
    # 输入比值，利用系数矩阵提取信号区间（常规方法）
    # ---------------------------------------
    def Segments(self,ratios, C):
        '''
        Age calculation (weighted mean and standard deviation) for each segment. For Segment comparison in the next step.

        AUGMENTS:
        ages: 2d unumpy array. Isotope ages for each effective signal. 
        C: 3d numpy array. Coefficient matrix of all possible segments for each spot.

        RETURNS:
        segs_mean: 2d numpy array. Mean ages of all possible segments for each spot.
        segs_se: 2d numpy array. Standard error of all possible segments for each spot.
        
        '''
        # 分离信号点比值与不确定度
        values = unumpy.nominal_values(ratios)
        uncertainties = unumpy.std_devs(ratios)
        # 将2d的年龄矩阵转换为3d后再与系数矩阵相乘
        segs_va = C * values[np.newaxis, :, :] 
        segs_uc = C * uncertainties[np.newaxis, :, :]
        # 取方差的倒数作为权重值
        weight = np.where((~np.isnan(segs_uc)) & (segs_uc != 0),
                        1.0 / (segs_uc ** 2),
                        0.0)
        sum_weights = np.nansum(weight,axis=1)
        # 计算加权平均
        segs_mean = np.nansum(weight*segs_va,axis=1) / sum_weights
        return segs_mean

    # 获得所有可能的连续信号区间
    def BestSegment(self,C, r68, r75, r76, threshold = AGE_THRESHOLD, la_u238=LAMBDA_U238):
        '''
        Find the best segment (with high concordance) for each spot after comparison of all segments. Run this function may take several minutes or tens of minutes, which depends on physical memory of the computer.  

        AUGMENTS:
        C: 3d numpy array. Coefficient matrix of all possible segments for each spot.
        a68: 2d unumpy array. 206Pb/238U ages of all signals for each spot.
        a75: 2d unumpy array. 207Pb/235U ages of all signals for each spot.
        
        RETURNS:
        a68Bseg: 2d unumpy array. 206Pb/238U ages of the best segment for each spot. 
        a75Bseg: 2d unumpy array. 207Pb/235U ages of the best segment for each spot. 
        id_Bseg: int.  Index of the best segment in all segments.
        
        '''
        # 68年龄为基准
        threshold_r86 = np.expm1(la_u238 * threshold)
        r75_68 = self.InterpR75toR68(r75)
        r76_68 = self.InterpR76toR68(r76)
        segs68_mean = self.Segments(r68, C)
        segs75_68_mean = self.Segments(r75_68, C)
        segs76_68_mean = self.Segments(r76_68, C)
        # # 根据68和75年龄的近似度（谐和度），寻找最佳的连续信号区间的索引
        id_Bseg_68_75 = np.argmin (np.abs(segs68_mean - segs75_68_mean), axis=0)
        id_Bseg_68_76 = np.argmin (np.abs(segs68_mean - segs76_68_mean), axis=0)
        # 比较
        condition = segs68_mean.mean(axis=0) > threshold_r86
        id_Bseg = np.where(condition, id_Bseg_68_76, id_Bseg_68_75)
        print (f'The best segment has been selected from {segs68_mean.shape[0]} potential segments.')
        # # 75年龄为基准
        # r68_75 = InterpR68toR75(r68)
        # segs75_mean = Segments(r75, C)
        # segs68_75_mean = Segments(r68_75, C)
        # id_Bseg_75_68_gpu = cp.argmin (cp.abs(segs68_75_mean - segs75_mean), axis=0)
        
        # 76 年龄为基准

        # 提取最佳区间的系数
        # [修改后] 使用 stack 并指定 axis=1，生成 (Time, Spots) 形状
        C_Bseg = np.stack([C[x, :, i] for i, x in enumerate(id_Bseg)], axis=1)
        return C_Bseg, id_Bseg

    # ---------------------------------------
    # 输入比值，利用系数矩阵提取信号区间（GPU方法）
    # ---------------------------------------
    def SegmentsGPU(self,ratios, C):
        # 拆出数值与不确定度（numpy arrays）
        values = unumpy.nominal_values(ratios)      # shape (N, P)
        uncertainties = unumpy.std_devs(ratios)     # shape (N, P)

        # 将 C 与 values/uncertainties 拷到 GPU
        C_gpu = cp.asarray(C)
        values_gpu = cp.asarray(values)
        uncertainties_gpu = cp.asarray(uncertainties)

        # 将2d的年龄矩阵转换为3d后再与系数矩阵相乘
        segs_va = C_gpu * values_gpu[cp.newaxis, :, :]
        segs_uc = C_gpu * uncertainties_gpu[cp.newaxis, :, :]
        
        # 取方差的倒数作为权重值
        weight = cp.where((~cp.isnan(segs_uc)) & (segs_uc != 0),
                        1.0 / (segs_uc ** 2),
                        0.0)
        sum_weights = cp.nansum(weight,axis=1)
        # 计算加权平均
        segs_mean = cp.nansum(weight*segs_va,axis=1) / sum_weights
        return segs_mean


    # 获得所有可能的连续信号区间
    def BestSegmentGPU(self,C, r68, r75, r76, threshold = AGE_THRESHOLD, la_u238=LAMBDA_U238):
        '''
        Find the best segment (with high concordance) for each spot after comparison of all segments. Run this function may take several minutes or tens of minutes, which depends on physical memory of the computer.  

        AUGMENTS:
        C: 3d numpy array. Coefficient matrix of all possible segments for each spot.
        a68: 2d unumpy array. 206Pb/238U ages of all signals for each spot.
        a75: 2d unumpy array. 207Pb/235U ages of all signals for each spot.
        
        RETURNS:
        a68Bseg: 2d unumpy array. 206Pb/238U ages of the best segment for each spot. 
        a75Bseg: 2d unumpy array. 207Pb/235U ages of the best segment for each spot. 
        id_Bseg: int.  Index of the best segment in all segments.
        
        '''
        # 68年龄为基准
        threshold_r86 = np.expm1(la_u238 * threshold)
        r75_68 = self.InterpR75toR68(r75)
        r76_68 = self.InterpR76toR68(r76)
        segs68_mean = self.SegmentsGPU(r68, C)
        segs75_68_mean = self.SegmentsGPU(r75_68, C)
        segs76_68_mean = self.SegmentsGPU(r76_68, C)
        # # 根据68和75年龄的近似度（谐和度），寻找最佳的连续信号区间的索引
        id_Bseg_68_75_gpu = cp.argmin (cp.abs(segs68_mean - segs75_68_mean), axis=0)
        id_Bseg_68_76_gpu = cp.argmin (cp.abs(segs68_mean - segs76_68_mean), axis=0)
        # 比较
        condition = segs68_mean.mean(axis=0) > threshold_r86
        id_Bseg_gpu = cp.where(condition, id_Bseg_68_76_gpu, id_Bseg_68_75_gpu)
        print (f'The best segment has been selected from {segs68_mean.shape[0]} potential segments.')

        # # 75年龄为基准
        # r68_75 = InterpR68toR75(r68)
        # segs75_mean = SegmentsGPU(r75, C)
        # segs68_75_mean = SegmentsGPU(r68_75, C)
        # id_Bseg_75_68_gpu = cp.argmin (cp.abs(segs68_75_mean - segs75_mean), axis=0)
        
        # 76 年龄为基准

        # 从gpu换回到cpu
        id_Bseg = cp.asnumpy(id_Bseg_gpu)
        # [修改后]
        C_Bseg = np.stack([C[x, :, i] for i, x in enumerate(id_Bseg)], axis=1)
        return C_Bseg, id_Bseg
    # [新增] 专门用于最佳区间（1D Spot数据）的漂移校正
    def drift_cali_spots(self, dc_fit_model, datetimes, r_spot_values, std_ref_val, n_knots=None):
        """
        针对 1D 数组（每个 Spot 一个值）进行漂移校正
        """
        try:
            # 1. 准备时间轴 (X轴) - 与 drift_fit 保持一致
            ref = np.datetime64('2020-01-01')
            x_abs = (datetimes - ref) / np.timedelta64(1, 's')
            
            if n_knots is None: n_knots = 6

            # 2. 构建样条基函数
            st = SplineTransformer(n_knots=n_knots, degree=3, include_bias=True)
            # 注意：fit_transform 需要 2D 输入 (N, 1)
            X_basis = st.fit_transform(x_abs.reshape(-1, 1))
            X_basis_const = sm.add_constant(X_basis)

            # 3. 预测每个 Spot 时间点上的仪器漂移值
            pred_res = dc_fit_model.get_prediction(X_basis_const)
            drift_y = unumpy.uarray(pred_res.predicted, pred_res.se)

            # 4. 执行校正: Corrected = Measured * (Standard_Ref / Drift_Value)
            r_corrected = r_spot_values * (std_ref_val / drift_y)

            print(f"Spot-based Drift Calibration Done. Shape: {r_corrected.shape}")
            return r_corrected
            
        except Exception as e:
            print(f"Error in drift_cali_spots: {e}")
            import traceback
            traceback.print_exc()
            return None
        
    # ----------------------------------------------------------------------
    # [新增] 不谐和度计算与年龄分布绘图 (移植自 autoUPb)   1.11
    # ----------------------------------------------------------------------
    def wetherill_scale(self, age_min, age_max):
        """近似计算Wetherill谐和图对数形式下的X-Y轴的比例"""
        ages = np.linspace(age_min, age_max, 1000)
        r68 = np.expm1(ages * self.LAMBDA_U238)
        r75 = np.expm1(ages * self.LAMBDA_U235)
        
        # 避免 log(0)
        r68[r68 <= 0] = 1e-10
        r75[r75 <= 0] = 1e-10
        
        DX = max(np.log(r75)) - min(np.log(r75))
        DY = max(np.log(r68)) - min(np.log(r68))
        return DY / DX

    def tera_wasserburg_scale(self, age_min, age_max):
        """近似计算TW谐和图对数形式下的X-Y轴的比例"""
        ages = np.linspace(age_min, age_max, 1000)
        # 防止除以零
        with np.errstate(divide='ignore', invalid='ignore'):
            r76 = 1.0 / self.U8U5 * np.expm1(self.LAMBDA_U235 * ages) / np.expm1(self.LAMBDA_U238 * ages)
            r86 = 1.0 / np.expm1(ages * self.LAMBDA_U238)
        
        # 清洗无效值
        valid = (r76 > 0) & (r86 > 0)
        if not np.any(valid): return 1.0
        
        r76 = r76[valid]
        r86 = r86[valid]
        
        DX = max(np.log(r86)) - min(np.log(r86))
        DY = max(np.log(r76)) - min(np.log(r76))
        return DY / DX

    # [关键修正] 必须包含 r68, r75, r76 参数
    def discordance(self, a68, a75, a76, r68=None, r75=None, r76=None, threshold=AGE_THRESHOLD, calcu='relative'):
        """
        计算不谐和度 (Discordance) 并确定最终年龄 (Final Age)
        Arguments:
            r68, r75, r76: 用于计算 Aitchison 距离的比值数据
        """
        a68_n = unumpy.nominal_values(a68)
        a75_n = unumpy.nominal_values(a75)
        a76_n = unumpy.nominal_values(a76)
        
        disc_percentage = np.zeros_like(a68_n, dtype=float)
        
        # 判断使用哪个年龄：< threshold 使用 68年龄，>= threshold 使用 76年龄
        condition_up = a76_n >= threshold
        condition_down = ~condition_up
        
        # 1. 确定最终优选年龄 (Final Age)
        final_age = a68.copy()
        if np.any(condition_up):
             final_age[condition_up] = a76[condition_up]

        # 2. 计算不谐和度
        if calcu == 'relative':
            # 年龄 > 阈值：使用 (1 - Age206_238 / Age207_206) * 100
            if np.any(condition_up):
                # 避免除以0
                with np.errstate(divide='ignore', invalid='ignore'):
                    disc_percentage[condition_up] = np.abs(1 - a68_n[condition_up] / a76_n[condition_up]) * 100
            
            # 年龄 < 阈值：使用 (1 - Age207_235 / Age206_238) * 100
            if np.any(condition_down):
                with np.errstate(divide='ignore', invalid='ignore'):
                    disc_percentage[condition_down] = np.abs(1 - a75_n[condition_down] / a68_n[condition_down]) * 100

        # 3. 计算 Aitchison 距离 (Log空间)
        elif calcu == 'aitchison':
            if all(x is not None for x in [r68, r75, r76]):
                r68_n = unumpy.nominal_values(r68)
                with np.errstate(divide='ignore'): r86_n = 1.0 / r68_n
                r76_n = unumpy.nominal_values(r76)
                r75_n = unumpy.nominal_values(r75)
                
                scale_76_86 = self.tera_wasserburg_scale(threshold, 4500.)
                scale_68_75 = self.wetherill_scale(10., threshold)
                
                # 计算理想点
                r86_76_n = np.zeros_like(r86_n)
                r76_68_n = np.zeros_like(r76_n)
                r68_75_n = np.zeros_like(r68_n)
                r75_68_n = np.zeros_like(r75_n)

                if np.any(condition_up):
                    r86_76_n[condition_up] = 1.0 / np.expm1(a76_n[condition_up] * self.LAMBDA_U238)
                    r76_68_n[condition_up] = (1.0 / self.U8U5) * (np.expm1(self.LAMBDA_U235 * a68_n[condition_up]) / np.expm1(self.LAMBDA_U238 * a68_n[condition_up]))
                
                if np.any(condition_down):
                    r68_75_n[condition_down] = np.expm1(a75_n[condition_down] * self.LAMBDA_U238)
                    r75_68_n[condition_down] = np.expm1(a68_n[condition_down] * self.LAMBDA_U235)

                # 计算距离
                if np.any(condition_up):
                    with np.errstate(divide='ignore', invalid='ignore'):
                        dx86 = np.abs(np.log(r86_n[condition_up]) - np.log(r86_76_n[condition_up])) / np.sqrt(2)
                        dy76 = np.abs(np.log(r76_n[condition_up]) - np.log(r76_68_n[condition_up])) * scale_76_86 / np.sqrt(2)
                        ratio = dy76 / dx86
                        disc_percentage[condition_up] = dx86 * np.sin(np.arctan(ratio)) * 100
                
                if np.any(condition_down):
                    with np.errstate(divide='ignore', invalid='ignore'):
                        dx75 = np.abs(np.log(r75_n[condition_down]) - np.log(r75_68_n[condition_down])) / np.sqrt(2)
                        dy68 = np.abs(np.log(r68_n[condition_down]) - np.log(r68_75_n[condition_down])) * scale_68_75 / np.sqrt(2)
                        ratio = dy68 / dx75
                        disc_percentage[condition_down] = dy68 * np.sin(np.arctan(ratio)) * 100
            else:
                print("Warning: Ratios needed for aitchison discordance, using 0.")
        
        # 处理可能的 NaN
        disc_percentage = np.nan_to_num(disc_percentage, nan=0.0)
        return disc_percentage, final_age

    def age_dist_plot(self, ax, datetimes, age_array, disc_percentage, spots, 
                        disc_threshold=0., outer=[], ylabel='Age', title=''):
        """
        [专业版] 绘制年龄分布图：支持红色高亮剔除点，并自动计算/显示加权平均值。
        """
        if age_array is None or len(age_array) == 0: return

        # 1. 准备基础数据
        values = unumpy.nominal_values(age_array)
        errors = unumpy.std_devs(age_array)
        
        # 2. 分离“好点”和“坏点”
        all_indices = np.arange(len(age_array))
        outer_set = set(outer)
        good_mask = np.array([i not in outer_set for i in all_indices])
        bad_mask = ~good_mask

        # 3. 计算加权平均值 (仅针对好点！)
        stats_text = ""
        if np.any(good_mask):
            good_ages = age_array[good_mask]
            # 调用你 model 里的加权平均函数
            avg_val, mswd = self.weighted_average(good_ages)
            # 计算对应的年龄和误差
            stats_text = f"Weighted Mean: {avg_val:.1fP}\nMSWD: {mswd:.1f}\nn: {len(good_ages)}/{len(age_array)}"

        # 4. 绘图：先画好点 (带颜色映射)
        if np.any(good_mask):
            sc = ax.scatter(datetimes[good_mask], values[good_mask], 
                            c=disc_percentage[good_mask], cmap='plasma', 
                            marker='s', s=35, edgecolor='k', linewidths=0.5, zorder=3, label='Included')
            ax.errorbar(datetimes[good_mask], values[good_mask], yerr=errors[good_mask], 
                        ecolor='k', fmt='None', elinewidth=1, capsize=2, zorder=2)

        # 5. 绘图：再画被剔除的“坏点” (红色虚线框)
        if np.any(bad_mask):
            ax.scatter(datetimes[bad_mask], values[bad_mask], 
                       facecolors='none', edgecolors='red', 
                       marker='s', s=40, linewidths=1.5, linestyle='--', zorder=5, label='Excluded')
            ax.errorbar(datetimes[bad_mask], values[bad_mask], yerr=errors[bad_mask], 
                        ecolor='red', fmt='None', elinewidth=1, alpha=0.6, zorder=4)

        # 6. 在图上标注统计信息 (左上角)
        if stats_text:
            ax.text(0.02, 0.8, stats_text, transform=ax.transAxes, 
                    bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'),
                    fontsize=9, verticalalignment='top', zorder=6)

        # 7. 标注样品号 (保持你的交替逻辑，但剔除的点用红字)
        for i in range(len(spots)):
            color = 'red' if bad_mask[i] else 'black'
            # 只有当符合 disc_threshold 或本身是坏点时才标注名字
            if disc_threshold == 0. or disc_percentage[i] > disc_threshold or bad_mask[i]:
                xytext = (-15, 0) if i % 2 == 0 else (5, 0)
                ax.annotate(text=spots[i], xy=(datetimes[i], values[i]), 
                            xytext=xytext, textcoords='offset pixels', 
                            rotation=90, fontsize=8, color=color)

        # 8. Colorbar 和常规配置 (保持不变)
        if np.any(good_mask):
            cbar_ax = ax.inset_axes([0.02, 0.85, 0.15, 0.03]) 
            cbar = ax.figure.colorbar(sc, cax=cbar_ax, orientation='horizontal')
            cbar.set_label('Discordance (%)', fontsize=8)
            cbar.ax.tick_params(labelsize=7)

        ax.set_xlabel('Time Series')
        ax.set_ylabel(ylabel) 
        if title: ax.set_title(title)