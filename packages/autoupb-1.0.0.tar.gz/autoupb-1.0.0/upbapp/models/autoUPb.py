## 用于自动处理LA-ICP-MS的U-Pb同位素数据
# 注意：此文件已更新为使用MVC架构
# 主要功能现在由models、views和controllers目录下的模块实现

# 导入主程序并运行
if __name__ == "__main__":
    import sys
    import os
    
    # 添加当前目录到Python路径
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    
    # 导入并运行主程序
    try:
        from __main__ import main
        main()
    except ImportError as e:
        print(f"无法导入主程序: {e}")
        print("请确保models、views和controllers目录存在且包含必要的文件")
        
        # 为了保持向后兼容性，保留原始功能的导入
        # 以下是原始功能的导入部分
        
import re
import os
import shutil
import csv
import math
import numpy as np
import pandas as pd
# 引入GPU计算
import cupy as cp

from datetime import datetime
from uncertainties import unumpy

import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter
from matplotlib.patches import Ellipse
from matplotlib.ticker import MaxNLocator

from patsy import dmatrix
import statsmodels.api as sm
import lmfit
from sklearn.preprocessing import SplineTransformer


from scipy.interpolate import interp1d
from scipy.interpolate import CubicSpline
# from scipy.optimize import curve_fit
# from scipy.optimize import leastsq
from scipy import stats

# 衰变常数
LAMBDA_U238 = np.log(2) / 4468. # u238 half-life for denominator 
LAMBDA_U235 = np.log(2) / 704. # u235 half-life for denominator 
LAMBDA_Th232 = np.log(2) / 1405.
# LAMBDA_Pa231 = 2.10 * 10 ** (-5)  # Rempfer2017epsl
# LAMBDA_Th230 = 9.17 * 10 ** (-6)  # Cheng2013epsl
U8U5=137.818
# 阈值
AGE_THRESHOLD = 1100.  #
##################################################################
## File input and output
##################################################################

# 从文件读取数据和日期时间
def readfile(filepath, signal_row_from, signal_row_to,
             datetime_row, datetime_pattern, datetime_format):
    '''
    Read the file (.csv) from Angilent ICP-MS.
    
    ARGUMENTS:
    filepath: a string of the file path. 
    signal_row_from: index number (row number -1) for the first row of the data
    signal_row_to: index number (row number -1) for the last row of the data
    datetime_row: index number (row number -1) for the row of the datetime 
    datetime_pattern: regular expression defined by re module for searching date and time from the csv file
    datetime_format: the parse format defined by datetime module, see https://docs.python.org/3/library/datetime.html#strftime-strptime-behavior
    
    RETURNS:
    s_data: list with data rows.
    t_data: datetime object. 
    '''
# 读取数据文件
    with open(filepath, mode='r') as data:
        s_data = []
        csv_reader = csv.reader(data)
        for index, row in enumerate(csv_reader):
            if index == datetime_row: # 日期时间行
                # 根据时间样式提取日期和时间
                dt = re.search(datetime_pattern, str(row), re.IGNORECASE)
                t_data= datetime.strptime(dt.group(), datetime_format)
            if index >= signal_row_from and index <= signal_row_to: # 数据行
                s_data.append(row)
            else: 
                continue
    return s_data, t_data
    
# 导入目录中的所有数据文件，保存为三个数组，signals，spots，datatimes 分别存储信号，样品号和时间
def ReadFiles(folderpath, signal_row_from: int, signal_row_to: int, 
              datetime_row: int, datetime_pattern: str, datetime_format: str):
    '''
    Read a batch of csv files (e.g., Angilent ICP-MS) from a folder.
    
    ARGUMENTS:
    folderpath: string of the folder path. 
    signal_row_from: index number (row number -1) for the first row of the data
    signal_row_to: index number (row number -1) for the last row of the data
    datetime_row: index number (row number -1) for the row of the datetime 
    datetime_pattern: regular expression defined by re module for searching date and time from the csv file
    datetime_format: the parse format defined by datetime module, see https://docs.python.org/3/library/datetime.html#strftime-strptime-behavior
    
    RETURNS:
    signals: 3d numpy array (ordered). length = signal rows, width = signal columns, depth = spots
    spots: 1d numpy array (ordered). Spot names, length = spots
    datetimes: 1d numpy array (ordered). Absolute time in datetime format. length = spots
    '''
    deldir = os.path.join(folderpath,'.ipynb_checkpoints')
    if os.path.exists(deldir):
        shutil.rmtree(deldir)
    files = os.listdir(folderpath)
    files.sort()
    for idx, file in enumerate(files):
        # 读取数据和日期时间
        s_data, t_data = readfile(filepath = os.path.join(folderpath, file), 
                                  signal_row_from = signal_row_from, 
                                  signal_row_to=signal_row_to,
                                  datetime_row = datetime_row, 
                                  datetime_pattern = datetime_pattern, 
                                  datetime_format= datetime_format)
        # 读取文件名样品号
        spot = file.rstrip('.csv')
        if idx == 0: # 初始化存储数据的数组
            signals = np.atleast_3d(np.array(s_data,dtype = 'float64')) # 3d数组
            spots = np.array([spot])
            datetimes = np.array(t_data,dtype='datetime64[s]')
        else: # 追加数组元素
            signals = np.concatenate((signals,np.atleast_3d(np.array(s_data,dtype = 'float64'))),axis=2) 
            spots = np.append(spots,[spot])
            datetimes = np.append(datetimes,np.array(t_data,dtype='datetime64[s]'))
        order = np.argsort(datetimes)
    return signals[:,:,order], spots[order], datetimes[order]

# 将计算结果写入csv文件
def WriteCsv(filepath: str, spots: np.ndarray, ends:np.ndarray, id_Bseg: np.ndarray,
                cutoffs: list, r68BsegAvg, r75BsegAvg, r76BsegAvg, 
             a68BsegAvg, a75BsegAvg, a76BsegAvg, outer = []):
    '''
    Write the results, including spot names, best segments, isotope ages and ratios with uncertainties, to a csv file.

    
    '''
    outer_list= []
    for i in range(len(spots)):
        if i in outer:
            outer_list.append('*')
        else: outer_list.append('')
    with open(filepath, "w") as file:
        file.write('Spot, Best segment, \
        r68, r68_err, r75, r75_err, r76, r76_err, \
        a68, a68_err, a75, a75_err, a76, a76_err' + '\n')
        for idx, spot in enumerate(spots):  
            row= (f'{outer_list[idx]}'+ f'{spot}, '+ 
                 f'{ends[id_Bseg[idx],:,idx] + cutoffs[1]}' + # Cutoff excluded
                  f'={str(ends[id_Bseg[idx],:,idx][1]- ends[id_Bseg[idx],:,idx][0])}, ' + 
                  '{:.4f}, '.format(r68BsegAvg[idx].n) + '{:.4f}, '.format(r68BsegAvg[idx].s) +
                  '{:.4f}, '.format(r75BsegAvg[idx].n) + '{:.4f}, '.format(r75BsegAvg[idx].s) +
                  '{:.4f}, '.format(r76BsegAvg[idx].n) + '{:.4f}, '.format(r76BsegAvg[idx].s) +
                  '{:.1f}, '.format(a68BsegAvg[idx].n) + '{:.1f}, '.format(a68BsegAvg[idx].s) +
                  '{:.1f}, '.format(a75BsegAvg[idx].n) + '{:.1f}, '.format(a75BsegAvg[idx].s) + 
                  '{:.1f}, '.format(a76BsegAvg[idx].n) + '{:.1f}'.format(a76BsegAvg[idx].s)) + '\n'
            file.write(row)

    
##################################################################
## Automatic Signal Cutoff
##################################################################

# 获取一维矩阵的滑动窗口
def SlideWindows(signal_1d, winsize = 3):
    sub_windows = np.arange(winsize) + np.arange(signal_1d.shape[0]-winsize+1).reshape(-1,1)
    return signal_1d[sub_windows]

# 寻找cutoff
def AutoCutoff(signals, spots, isotope: int, slope_winsize = 3, mean_winsize =5):    
    '''
    Find suitable cutoffs (applied to every spot) for background and effective signals. The numbers of slope_winsize and mean_winsize depend on how many signals each spot has. Larger numbers for more signals and smaller numbers for less signals. 
    
    ARGUMENTS:
    signals: 3d numpy array of signals
    spots: 1d numpy array of spot names
    isotope: index number of isotope column
    slope_winsize: slide window size for signal slopes calculation.
    mean_winsize: slide windwow size for signal means calculation.
    
    RETURNS:
    cutoffs: list of the three cutoffs
    cutoffs_spots: list of the spots that used for cutoffs.
    '''
    for i, spot in enumerate(spots):
        # 求滑动窗口内的信号变化（坡度）
        slope_windows = SlideWindows(signals[:,isotope,i], winsize = slope_winsize)
        slopes = np.polynomial.polynomial.polyfit(range(slope_winsize), slope_windows.T, deg=1)[1]
        # 求滑动窗口内的信号均值
        mean_windows = SlideWindows(signals[:,isotope,i], winsize = mean_winsize)
        means = np.mean(mean_windows, axis=1)
        # 按照信号均值的大小由大到小排序
        means_max = np.argmax(means)
        # 根据最大信号均值出现的位置分割信号坡度
        slopes_half_left = slopes[:means_max]
        slopes_half_right = slopes[means_max:]
        # 再将分割后的信号坡度，按照坡度由大到小排序
        slopes_half_left_max =np.argmax(np.abs(slopes_half_left))
        slopes_half_right_max =np.argmax(np.abs(slopes_half_right)) + means_max
        # 对于每个spot都执行相同的上述代码，从中找出最合适值的cutoff
        # cutoff1截取背景，cutoff2是有效信号起始点，cutoff3是有效信号结束点
        if i == 0:
            cutoff1 = slopes_half_left_max
            cutoff1_spot = spot
            cutoff2 = means_max
            cutoff2_spot = spot
            cutoff3 = slopes_half_right_max
            cutoff3_spot = spot
        else:
            if  means_max > cutoff2 and means_max < signals.shape[0]*0.3:
                cutoff2 = means_max
                cutoff2_spot = spot
            if  slopes_half_left_max < cutoff1 and slopes_half_left_max < cutoff2:
                cutoff1 = slopes_half_left_max
                cutoff1_spot = spot
            if  slopes_half_right_max > signals.shape[0]*0.9 and slopes_half_right_max < cutoff3:
                cutoff3 = slopes_half_right_max
                cutoff3_spot = spot
        # print(slopes_half_left_max, means_max, slopes_half_right_max)
    cutoffs = [cutoff1, cutoff2, cutoff3]
    cutoffs_spots = [cutoff1_spot,cutoff2_spot,cutoff3_spot]
    return cutoffs, cutoffs_spots 

# 画时间-信号图的函数（从3d numpy数组）
# 选择样品画信号图
def SignalPlot(signals:np.ndarray, datetimes: np.ndarray, spots: np.ndarray, 
               spotname: str, isotopes: list, signaltitle: list, 
               log = False, abstime = True, cutoffs=None, cutoff_spots=None, figsize=(20,4) ):
    '''
    Plot the signals for given spot (spotname). X-axis can be absolute time (in datetime format) or reference time (in second). Y-axis can be normal or logarithmic
    
    ARGUMENTS:
    singals: 3d array with data.
    datetimes: 1d array with date and times. 
    spots: 1d array with spot names.
    spotname: the index of the given spot.
    isotopes: the list of isotopes that will be shown in the figure.
    singaltitle: the title list of data.
    log: if true, use log y-axis 
    abstime: if ture, use absolute time in datetime format
    cutoffs: list of the three cutoffs
    cutoffs_spots: list of the spots that used for cutoffs.

    NO RETURN
    '''
    fig, ax = plt.subplots( figsize = figsize )
    spotidx_array = np.where(spots == spotname)
    spotidx = spotidx_array[0][0]
    if abstime == True:
        # 将np.datetime64 转换为 matplotlib可识别的日期和时间格式
        # 坐标时间 = 起始时间 + 信号时间(0列)
        time = datetimes[spotidx] + (signals[:,0,spotidx] * 1e9).astype('timedelta64[ns]')
        # 日期转换为 datetime 格式后在进行格式化输出
        date = datetime.utcfromtimestamp(datetimes[spotidx].astype(int))
        date_fmt = date.strftime("%Y-%m-%d %H:")
        ax.xaxis.set_major_formatter(DateFormatter("%M:%S"))
        ax.annotate(date_fmt,
                    xy=(-.1, -.1), xycoords='axes fraction',
                    horizontalalignment='left', verticalalignment='bottom')
        ax.xaxis.set_label_text('Time')
    else: 
        time = signals[:,0,spotidx] 
        ax.xaxis.set_label_text('Time in second')
    for idx, isotope in enumerate(isotopes):
        signal = signals[:,isotope,spotidx]
        ax.plot (time, signal, label = signaltitle[isotope])
        # signalplot.set_label ()
    # 画图
    # 选择画是否画log图
    if log == False: 
        ax.set_yscale('linear') # 206
    else: 
        ax.set_yscale('log')
    ax.yaxis.set_label_text(' Counts per second')
    ax.set_title('spot: '+spots[spotidx])
    # 添加日期
    if cutoffs is not None and cutoff_spots is not None:
        text=['Background End', 'Effective Signal Start (Max)', 'Effective Signal End']
        for i,cutoff in enumerate(cutoffs):
            ax.axvline(x = time[cutoff], color='k', linestyle='--' )
            ax.annotate(text=text[i],xy=(time[cutoff],50), 
                        xytext=(-15,0),textcoords='offset pixels', rotation=90)
            ax.annotate(text=cutoff_spots[i],xy=(time[cutoff],50), 
                        xytext=(5,0),textcoords='offset pixels', rotation=90)
    ax.legend(loc = 'upper left', frameon= False) 
    plt.show()

##################################################################
## Time transformation Functions
##################################################################
def TimeAbs2Ref(time_abs):
    # 设置参考时间点，能够减少一点数量级
    referece_time = np.datetime64('2020-01-01T00:00:00')
    # 转换为float时间
    time_ref = (time_abs - referece_time) / np.timedelta64(1, 's')
    return time_ref
    
def TimeRef2Abs(time_ref):
    # 设置参考时间点，与上面referece_time保持一致
    referece_time = np.datetime64('2020-01-01T00:00:00')
    time_abs = referece_time + time_ref.astype('timedelta64[s]')
    return time_abs
    
# 将单个spot的时间与datetimes叠加，构成连续的时间序列，用于拟合
def TimeSeries(datetimes, time):
    '''
    Integrate the signal time into spot time series.
    
    ARGUMENTS:
    datetimes: 1D numpy array. Time series of the total spots.
    time: 2D numpy array. Singal time (second).
    
    RETURNS:
    timeSeries_ref: 1D numpy array. Integrated Time series in second. 
    timeSeries_abs: 1D numpy array. Integrated Time series in datetime format.
    '''
    # 转换为float时间
    dts = TimeAbs2Ref(datetimes)
    # 将dts转置后对列进行扩展，再与timeBK相加，得到背景的参考时间，用来进行拟合运算
    timeSeries_ref = np.hstack([dts[:, np.newaxis]] * time.shape[0]) + time
    # 加回参考时间，就可以得到绝对时间
    timeSeries_abs = TimeRef2Abs(timeSeries_ref)
    return timeSeries_ref, timeSeries_abs

# 根据时间间隔，选择邻近的spots进行平均，化简样品数量，用于曲线拟合
def NearestNeighbor(datetimes, signals, isRatio = False):
    '''
    Reduce the number of signals or ratios by nearest neighbor average on time series. Better used for curve fitting. 
    
    ARGUMENTS:
    datetimes: 1D numpy array of absolute time series (in datetime format).
    signals: 1D unumpy uarray (ratio) or numpy array (signal). Signals or ratios with the same shape as datetimes.
    isRatio: If true, signals is the ratio with uncertainties. 

    RETURNS:
    datetimes_reduced: 1D numpy array. New datetimes that has been reduced. 
    signals_reduced: 1D numpy array. Reduced signals with the same shape as datetimes_reduced.
    '''
    dts = TimeAbs2Ref(datetimes)
    # 计算每两个signals之间的时间间隔
    delta = np.diff(dts) # 由于时间顺序增加，所以delta总是正
    # 从delta的间隔，排序后可以找出大值组与小值组的分界
    delta_delta = np.sort(np.abs(np.diff(delta)))
    # 分界点处是大值组的最小值，用来限定delta
    ids = np.where(delta >= np.max(np.diff(delta_delta)))[0]
    # 最后一个spots要手动添加进去
    if ids[-1] != dts.shape[0]:
        ids = np.insert(ids, ids.shape[0], dts.shape[0]-1)
    # 化简后的时间数列
    datetimes_reduced = TimeRef2Abs(dts[ids])
    # 分离数值和不确定度
    values = unumpy.nominal_values(signals)
    uncertainties = unumpy.std_devs(signals)
    # 空的list存放化简结果
    signals_reduced_values=[]
    signals_reduced_uncertainties=[]
    for i in range(ids.shape[0]):
        a2 = ids[i]+1
        if i == 0:
            a1 = 0
        else:
            a1 = ids[i-1]+1 
        # ratio 为带不确定度的比值，采用加权平均的方式计算平均值
        if isRatio== True:
            weights = 1 / uncertainties[a1:a2]**2
            mean = np.sum(weights * values[a1:a2])/np.sum(weights)
            sd = np.sqrt(np.sum(weights  * (values[a1:a2]-mean)**2) / np.sum(weights))
            se = sd/ np.sqrt(a2-a1+1)
            signals_reduced_values.append(mean)
            signals_reduced_uncertainties.append(sd)
        else:
            mean = np.mean(signals[a1:a2])
            signals_reduced_values.append(mean)
    if isRatio == True:
        signals_reduced = unumpy.uarray(signals_reduced_values,signals_reduced_uncertainties)
    else:
        signals_reduced = np.array(signals_reduced_values)
    return datetimes_reduced, signals_reduced

##################################################################
## Background Substraction
##################################################################  
# 分离背景信号和样品信号
def BkgSeparate(signals,cutoffs):
    '''
    Separate the effective and background signals.
    
    ARGUMENTS:
    singals: 3d array with data.
    cutoffs: list of the three cutoffs
    
    RETURN:
    timeBkg: 1d array of reference time (in second) of background
    signalsBkg: 3d array of background signals
    timeEff: 1d array of reference time (in second) of effective signals
    signalsEff: 3d array of effective signals
    '''
    # 截取信号部分
    signalsEff = signals[cutoffs[1]:cutoffs[2], : , :] 
    timeEff = signalsEff[:,0,0] # 因为所有的spot时间轴都是一致的，取第一个spot的第一列的时间替代
    # 截取背景
    signalsBkg = signals[:cutoffs[0], : , :]
    timeBkg = signalsBkg[:,0,0]
    return timeBkg, signalsBkg, timeEff,signalsEff
    
# 对背景进行曲线拟合，并从信号中减去
def BkgSubstract(datetimes: np.ndarray, signals: np.ndarray, cutoffs: list, dof = 4):
    '''
    Subustract background curve from the effective signals. The curve is fitted using spline function by Statsmodels module using ordinary least squares (OLS). The design matrix of the cubic spline function (degree=3) is firstly built by Pasty module
    
    ARGUMENTS:
    datetimes: 1d numpy array of absolute time (in datetime format).
    signals: 3d numpy array of signals.  
    cutoffs: list of the three cutoffs. 
    dof: degree of freedom for spline fitting.
    
    RETURNS:
    timeEff: 1d numpy array. Reference time (in second) of effective signals
    signalsEffBs: 3d numpy array. Effective signals after background substraction.
    timeBkgAbs: 1d numpy array. Absolute time (in datetime format) of background signals for plotting.
    signalsBkg: 3d numpy array. Background signals.
    bkgFits: 1d numpy array. Spline fitting curve for background signals.
    bkgFits_conf95: 2d numpy array. Confidence interval of spline fitting.
    
    '''
    # 调用函数分离信号与背景
    timeBkg, signalsBkg, timeEff,signalsEff = BkgSeparate(signals,cutoffs)
    # 所有spots构成连续时间
    timeBkgRef, timeBkgAbs =  TimeSeries(datetimes, timeBkg)
    timeEffRef, timeEffAbs =  TimeSeries(datetimes, timeEff)
    # 对每个spot的背景信号进行平均，转换为1D矩阵
    X_bk = np.mean(timeBkgRef,axis =1)
    # # 使用patsy建立背景信号X样条函数
    # X_basis = dmatrix("bs(x, df=dof, degree=3, include_intercept=False)", {"x": X})
    # 使用SplineTransformer构建样条函数
    spline_func = SplineTransformer(n_knots=6, degree=3, include_bias=True)
    # 为背景信号构建样条基函数，并为statsmodel拟合添加常数项
    X_bk_basis = spline_func.fit_transform(X_bk.reshape(-1, 1))
    X_bk_basis_const = sm.add_constant(X_bk_basis)
    # 所有样品信号（混合了背景信号）
    X_sp = timeEffRef.ravel()
    # # 使用patsy建立样品信号（混合了背景信号）X_sp的样条函数
    # X_sp_basis = dmatrix("bs(x, df=dof, degree=3, include_intercept=False)", {"x": X_sp})
    # 为样品信号（混合了背景信号）构建样条基函数，并为statsmodel拟合添加常数项
    X_sp_basis = spline_func.fit_transform(X_sp.reshape(-1, 1))
    X_sp_basis_const = sm.add_constant(X_sp_basis)
    # 初始化背景信号矩阵
    signalsEffBs = signalsEff[:,0:1,:] 
    # 初始化包含所有同位素的拟合曲线矩阵
    bkgFits = np.empty((1, X_bk.shape[0])) # 首行保持为空
    bkgFits_conf95 = np.empty((1, X_bk.shape[0], 2))
    # 针对每个同位素都要进行背景减去
    for isotope in range(1, signalsEff.shape[1]): #第一列是时间列，从第二列开始是同位素
        # 所有spots背景信号均值，组合形成时间连续信号
        Y_bk = np.mean(signalsBkg[:,isotope,:], axis=0)
        # 基于背景信号最小二乘法建立样条拟合模型
        BsFit = sm.OLS(Y_bk, X_bk_basis_const).fit()
        # 拟合的背景信号，用于存储并可以绘图
        BsFit_pred = BsFit.get_prediction(X_bk_basis_const)
        Yfit = unumpy.uarray(BsFit_pred.predicted, BsFit_pred.se)
        Yfit_conf95 = BsFit_pred.conf_int(obs=False,alpha=0.05)
        # 组合成不同元素的背景拟合曲线（时间连续），用于绘图
        bkgFits = np.concatenate((bkgFits,Yfit[np.newaxis,:]), axis=0)
        bkgFits_conf95 = np.concatenate((bkgFits_conf95, Yfit_conf95[np.newaxis, :, :]), axis=0)
        # 对样品信号（混合了背景信号）应用拟合模型，得到样品中的背景信号拟合值
        Y_sp = BsFit.get_prediction(X_sp_basis_const)
        # 从样品信号（混合了背景信号）中减去背景信号拟合值
        bs = signalsEff[:,isotope,:].T.ravel() - Y_sp.predicted
        # 背景减去后的样品信号重新归入样品信号矩阵
        bs.resize(signalsEff.shape[2],signalsEff.shape[0])
        signalsEffBs = np.concatenate((signalsEffBs, bs.T[:,np.newaxis,:]), axis=1)
    return timeEff, signalsEffBs, timeBkgAbs, signalsBkg, bkgFits, bkgFits_conf95   #, Ynews
    
# 绘制背景信号图
# bkgCurves 参数为带误差的 unumpy.uarray 类型
def BkgPlot(timeBkgAbs: np.ndarray, signalsBkg: np.ndarray, spots: np.ndarray, 
            bkgFits, bkgFits_conf95: np.ndarray, signaltitle: list, isotope: int, figsize = (20,4) ):
    '''
    Plot background signals with fitting curve. The curve is fitted using spline method. 
    
    ARGUMENTS:
    timeBkgAbs: 1d numpy array. Absolute time (in datetime format) of background signals for plotting.
    signalsBkg: 3d numpy array. Background signals.
    spots: 1d numpy array. Names of all the spots.
    bkgFits: 1d numpy array. Spline fitting curve for background signals.
    bkgFits_conf95: 2d numpy array. Confidence interval of spline fitting.
    
    '''
    fig, ax = plt.subplots( figsize =figsize )
    # 画背景信号图，x和y都是2D矩阵，以xy的列作为
    lines=ax.plot(timeBkgAbs.T,signalsBkg[:,isotope,:],color='b')
    lines[0].set_label ('Background Signals')
    # 画拟合线
    # 采用时间中值作为x值
    tm = timeBkgAbs.shape[1]//2
    ax.plot (timeBkgAbs[:,tm].ravel(),unumpy.nominal_values(bkgFits[isotope,:]), 
             color='r', label = 'Background spline fitting')
    # 画置信区间
    ax.fill_between(timeBkgAbs[:,tm].ravel(), bkgFits_conf95[isotope,:,0], bkgFits_conf95[isotope,:,1],
                     color='red', lw = 0., alpha=0.2, label='95% Confidence intervals')
    # 标注样品号, 纵向位置占25%
    y_ann = ax.get_ylim()[0] + 0.25 * (ax.get_ylim()[1] - ax.get_ylim()[0])
    for i, spot in enumerate(spots):
        if i % 2 == 0:
            ax.annotate(text=spot,xy=(timeBkgAbs[i,tm], y_ann), 
                            xytext=(-15,0),textcoords='offset pixels', rotation=90)
        else:
            ax.annotate(text=spot,xy=(timeBkgAbs[i,tm], y_ann), 
                            xytext=(5,0),textcoords='offset pixels', rotation=90)
    ax.legend(loc = 'upper right', frameon= False)
    ax.xaxis.set_label_text('Time Series')
    ax.yaxis.set_label_text('Count per second')
    ax.set_title(f'{signaltitle[isotope]} background signals and spline fitting')
    plt.show()

##################################################################
## Isotope Ratios Calculation
##################################################################  
# 计算U-Pb信号比值
def RatioUPb(signals: np.ndarray, pb206: int, pb207: int, u238: int, u8u5=U8U5):
    '''
    Calculate U/Pb Ratio. 
    
    ARGUMENTS:
    signals: 3d array of signals.  
    pb206, pb207, u238: index column number for these isotopes
    u8u5: constant value for 238U/235U
    
    RETURNS:
    r68: 2d array of 206Pb/238U for all spots
    r75: 2d array of 207Pb/235U for all spots
    '''
    r68 = (signals[:,pb206,:] / signals[:,u238,:])
    r75 = (signals[:,pb207,:] * u8u5 / signals[:,u238,:])
    r76 = (signals[:,pb207,:] / signals[:,pb206,:])
    return r68, r75, r76

# 通过75和68的比值计算76比值
def RatioPbPb(Ratio68: np.ndarray, Ratio75: np.ndarray, u8u5=U8U5):
    '''
    Calculate Pb/Pb Ratio from U/Pb ratio. 
    
    ARGUMENTS:
    Ratio68: 2d array of 206Pb/238U for all spots
    Ratio75: 2d array of 207Pb/235U for all spots
    u8u5: ufloat. Constant value for 238U/235U
    
    r76: 2d array of 206Pb/207Pb for all spots
    '''
    u5u8 = 1.0/u8u5
    r76 = (Ratio75 / Ratio68) * u5u8
    return r76
    
# 内插T-W谐和图,计算r68对应的谐和线上的r76比值
def InterpR68toR76(r68, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5):
    num_samples = 1000  
    age_min = 0.1           
    age_max = 4500.
    u5u8 = 1./u8u5
    r86 = 1./r68
    # Generate random ages
    # Use linspace for better interpolation
    sample_ages = np.linspace(age_max, age_min, num_samples) 
    # Compute the model Pb207/Pb206 ratio for each age (vectorized) 
    sample_r86 = 1./np.expm1(la_u238 * sample_ages)
    sample_r76 = u5u8 * (np.expm1(la_u235 * sample_ages)  / np.expm1(la_u238 * sample_ages))
    # 基于立方样条构建内插函数
    f = CubicSpline(x=sample_r86, y=sample_r76, extrapolate=True)
    # 应用内插函数
    x = unumpy.nominal_values(r86)
    # 误差要单独传播
    x_err = unumpy.std_devs(r86)
    y = f(x)
    dy_dx = f.derivative()(x)
    # 误差传播公式
    y_err = np.abs(dy_dx) * x_err
    r76 = unumpy.uarray(y, y_err)
    return r76

# 内插T-W谐和图,计算r76对应的谐和线上的r68比值
def InterpR76toR68(r76, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5):
    num_samples = 1000  
    age_min = 0.1           
    age_max = 4500.
    u5u8 = 1./u8u5
    # Generate random ages
    # Use linspace for better interpolation
    sample_ages = np.linspace(age_min, age_max, num_samples) 
    # Compute the model Pb207/Pb206 ratio for each age (vectorized) 
    sample_r86 = 1./np.expm1(la_u238 * sample_ages)
    sample_r76 = u5u8 * (np.expm1(la_u235 * sample_ages)  / np.expm1(la_u238 * sample_ages))
    # 基于立方样条构建内插函数
    f = CubicSpline(x=sample_r76, y=sample_r86, extrapolate=True)
    # 应用内插函数
    x = unumpy.nominal_values(r76)
    # 误差要单独传播
    x_err = unumpy.std_devs(r76)
    y = f(x)
    dy_dx = f.derivative()(x)
    # 误差传播公式
    y_err = np.abs(dy_dx) * x_err
    r86 = unumpy.uarray(y, y_err)
    return 1./r86
    
# 计算r68对应的谐和线上的r75比值（直接根据年龄公式计算最简单）
def InterpR68toR75(r68,la_u235=LAMBDA_U235, la_u238=LAMBDA_U238):
        # 计算理想（谐和线上）的点位
        ratio= la_u235/la_u238
        r75 = unumpy.exp(ratio * unumpy.log(r68 + 1)) -1
        return r75
    
# 计算r75对应的谐和线上的r68比值（直接根据年龄公式计算最简单）
def InterpR75toR68(r75,la_u235=LAMBDA_U235, la_u238=LAMBDA_U238):
        # 计算理想（谐和线上）的点位
        ratio = la_u238/la_u235
        r68 = unumpy.exp(ratio * unumpy.log(r75 + 1)) -1
        return r68
    
##################################################################
## Down-hole Calibration
##################################################################   
# 计算（标样）比值的平均值（仅用于downhole校正）
def RatioStack(ratio: np.ndarray):
    '''
    The ratios of the standard samples (with known ages) are stacked and vertically averaged according to Paton et al.(2010).
    
    ARGUMENTS:
    ratio: 2d numpy array. Ratios of singals of each spot. 

    RETURNS:
    ratioStack: 1d unumpy array. Average ratios of stacked spots at reference time.
    '''
    ratioMean = np.mean(ratio,axis = 1)
    ratioSE = np.std(ratio,axis = 1)/np.sqrt(ratio.shape[1])
    ratioStack = unumpy.uarray(ratioMean, ratioSE)
    return ratioStack

# Downhole拟合，返回拟合结果的校正（归一化）因子与残差
# 采用非线性函数 y = a + b * Exp(c*x)  拟合downhole分馏的数据
# 拟合与校正合二为一，待测样品


# # 采用Statsmodel的线性回归算法，需要先将非线性指数函数转换为线性函数
# def DownholeFit(timeEff: np.ndarray, ratioStack: np.ndarray):
#     '''
#     Fit the downhole fractionation caused by laser ablation using exponential function y = a + b * Exp(cx). The ratios of the standard samples (with known ages) are stacked and averaged according to Paton et al.(2010). The function is fitted by Statsmodels module using weighted least squares (WLS).
    
#     ARGUMENTS:
#     timeEff: 1D numpy array. Effective time of the signals after cutoff (in second).
#     ratioStack: 1D unumpy uarray. Averaged ratios of stacked spots returned from RatioStack().
#     typeCal: int. default=1: factors for both scale (to STD reference value) and calibration (for downhole). 2. factors for only scale (to STD reference value).
    
#     RETURNS:
#     ratioStackFit: 1D unumpy uarray. Fitting values (curve) of stacked ratios.
#     ratioStackFitConf95: 2D numpy array. Confidential interval of the fitting curve. Two columns where the first column is the lower limit and the second column is the upper limit.
#     ratioStackFitResid: 1D unumpy uarray. Residuals of the fitting. 
    
#     '''
#     # 拟合 y = a + b * Exp(c*x) 
#     # 先将其转化为拟合 y-a = y'= b * Exp(cx)
#     # 两侧取对数 ln(y')=ln(b) + cx ，先对 ln (y') 进行拟合
#     # 根据标样的参考值求得 a，由 y= a + exp ln(y')得到 y的拟合值
#     # 将指数函数拟合转化为ln形式的线性回归问题, 
#     ln_ratioStack = unumpy.log(ratioStack)
#     ln_Y = unumpy.nominal_values(ln_ratioStack)#
#     ln_Ye = unumpy.std_devs(ln_ratioStack)
#     X = timeEff
#     X_dm = sm.add_constant(X) # 设计矩阵（加了常数项）
#     # 利用方差倒数作为加权项，进行线性回归
#     ratioStackFit = sm.WLS(ln_Y, X_dm, weights = 1/ln_Ye**2).fit()
#     # ratioStackFit = sm.OLS(ln_Y, X_dm).fit()
#     # 基于x_dm的预测结果（对象）
#     ratioStackFit_pred = ratioStackFit.get_prediction(X_dm)
#     # 提取置信区间（95%）
#     ln_Yfit_conf95 = ratioStackFit_pred.conf_int(obs=False,alpha=0.05)
#     # 提取回归结果和标准差
#     ln_Yfit = unumpy.uarray(ratioStackFit_pred.predicted, ratioStackFit_pred.se)
#     # 再将线性回归结果ln(y')转化（连同不确定度）
#     DhFit = unumpy.exp(ln_Yfit)
#     # 包括置信区间
#     DhFitConf95 = np.exp(ln_Yfit_conf95)
#     # 计算残差
#     DhFitResid = DhFit - ratioStack
#     return DhFit, DhFitConf95, DhFitResid

    
#     # #只归一化到标样的参考比值，但不校正
#     # elif typeCal == 2:
#     #     Dhfit_pred = Dhfit.get_prediction(X_dm[-1])
#     #     ln_Yfit = unumpy.uarray(DHfit_pred.predicted, DHfit_pred.se)
#     #     Yfit = unumpy.exp(ln_Yfit)
#     #     Dhfactor_ = STDratio / Yfit 
#     #     Dhfactor = np.repeat(Dhfactor_, timeEff.shape[0])
#     #     return Dhfactor

# 采用lmfit的算法，直接进行非线性指数函数的回归
def DownholeFit(timeEff: np.ndarray, ratioStack: np.ndarray, curve='convex'):
    '''
    Fit the downhole fractionation caused by laser ablation using exponential function y = a + b * Exp(cx). The ratios of the standard samples (with known ages) are stacked and averaged according to Paton et al.(2010). The function is fitted by Statsmodels module using weighted least squares (WLS).
    
    ARGUMENTS:
    timeEff: 1D numpy array. Effective time of the signals after cutoff (in second).
    ratioStack: 1D unumpy uarray. Averaged ratios of stacked spots returned from RatioStack().
    typeCal: int. default=1: factors for both scale (to STD reference value) and calibration (for downhole). 2. factors for only scale (to STD reference value).
    
    RETURNS:
    ratioStackFit: 1D unumpy uarray. Fitting values (curve) of stacked ratios.
    ratioStackFitConf95: 2D numpy array. Confidential interval of the fitting curve. Two columns where the first column is the lower limit and the second column is the upper limit.
    ratioStackFitResid: 1D unumpy uarray. Residuals of the fitting. 
    
    '''
    # 设定拟合数据X，Y，提取标样比值的平均值和误差 
    Y = unumpy.nominal_values(ratioStack)
    Ye = unumpy.std_devs(ratioStack)
    X = timeEff
    # 构建拟合函数 y = a + b * Exp(cx)
    def exp_func(x, a, b, c):
        return a + b * np.exp(c * x)
    # 基于函数创建拟合模型
    exp_model = lmfit.Model(exp_func)
    # 设定参数的初始值、最小值、最大值。这步非常关键，直接决定拟合结果。
    # 参考desmos.com数学工具观察参数的取值范围对曲线的影响。
    # 上凹型的拟合曲线，b为正，c为正，a取小值
    exp_params_concave = exp_model.make_params(
        a = {'value': np.min(Y),'min':np.min(Y)/2.0,'max':2.0*np.max(Y)},
        b = {'value': np.max(Y)-np.min(Y),'min':-np.max(Y),'max':np.max(Y)-np.min(Y)},
        c = {'value': 1.0/(np.max(X)-np.min(X))})
    # 上凹型曲线拟合，采用最小二乘法，并考虑Y的误差
    result_concave = exp_model.fit(Y, exp_params_concave, weights=1.0/Ye**2, 
                           method='leastsq', scale_covar=False, x=X)
    # 上凸型的拟合曲线，b为负，c为负，a取大值
    exp_params_convex = exp_model.make_params(
        a = {'value': np.max(Y),'min':np.min(Y)/2.0,'max':2.0*np.max(Y)},
        b = {'value': -np.max(Y),'min':-np.max(Y),'max':np.max(Y)-np.min(Y)},
        c = {'value': -1.0/(np.max(X)-np.min(X))})
    # 上凸型曲线拟合，
    result_convex = exp_model.fit(Y, exp_params_convex, weights=1.0/Ye**2, 
                           method='leastsq', scale_covar=False, x=X)
    
    ###########################################################
    # # 根据不确定度判断哪种类型（上凸还是上凹型）曲线拟合更精确
    # dely_concave = result_concave.eval_uncertainty(sigma=1)
    # dely_convex = result_convex.eval_uncertainty(sigma=1)
    # if np.mean(dely_concave) < np.mean(dely_convex):
    #     dely = result_convex.eval_uncertainty(sigma=1)
    #     result = result_convex
    #     curve = "Convex"
    # else:
    #     dely = result_concave.eval_uncertainty(sigma=1)
    #     result = result_concave
    #     curve = "Concave" 
       
    ##########################################################
    # 默认采用上凸型曲线拟合
    if curve == 'convex':
        dely = result_convex.eval_uncertainty(sigma=2)
        result = result_convex
    elif curve == 'concave':
        dely = result_concave.eval_uncertainty(sigma=2)
        result = result_concave
    else:
        raise ValueError("curve param should be convex or concave")
    ###########################################################
    # print(result.fit_report())
    # 显示并输出拟合结果和参数
    DhFit_output =pd.DataFrame({
        "Curve": [curve],
        "a": [result.uvars['a']],
        "b": [result.uvars['b']],
        "c": [result.uvars['c']],
        "Iter": [result.nfev]})
    # 设置pandas显示输出所有列
    pd.set_option('display.max_columns', None)
    # 设置输出3位小数
    pd.set_option('display.float_format', '{:.3f}'.format)
    print(DhFit_output.to_string(index=False),
          '\n ----------------------------------------------------')
    # 导出拟合值
    DhFit = result.best_fit
    # 导出参数
    DhFitParams = result.uvars
    # 导出置信区间
    DhFitConf95 = np.array([result.best_fit - dely, result.best_fit + dely]).T
    # 导出残差
    DhFitResid = result.residual

    return DhFit, DhFitParams, DhFitConf95, DhFitResid

# 绘制spot比值随接收时间的变化
def RatioPlot(ax, timeEff: np.ndarray, ratio: np.ndarray, ratio_err: np.ndarray = None, 
              Yfit: np.ndarray= None, Yfit_conf: np.ndarray = None, # 第一列为下界，第二列为上界
              xlabel ='Time in Second', ylabel='Ratio', 
              linelabel = None, 
              ci_label= '95% Confidence intervals', title='Signal Ratios'):
    '''
    Plot ratios (with error bars) vs reference time for given spot (or stacked spots). Fitting curve can also be ploted with the ratios.

    ARGUMENTS:
    timeEff: 1d array of reference time (in second) of effective signals
    ratio: 1d numpy array of ratio
    ratio_err: 1d numpy array of ratio error.
    Yfit: 1d numpy array. y-value of fitting curve.
    Yfit_conf: 2d numpy array. confidential interval (upper and lower limit) of fitting curve 
    '''
    lines = ax.plot (timeEff, ratio, color = 'b', lw = 0.5, alpha = 0.5, zorder =1)   
    ax.set_title(title)
    ax.xaxis.set_label_text(xlabel)
    ax.yaxis.set_label_text(ylabel)
    # errorbar支持单条（均值）
    if ratio_err is not None:
        ax.errorbar(timeEff, ratio, ratio_err, label='Original ratio std', color='b',alpha=.25,zorder =2)
    # 画拟合线
    if Yfit is not None:
        ax.plot(timeEff, Yfit, label='Downhole calibration curve', color='r', zorder=3)
    # 画置信区间
    if Yfit_conf is not None:
        ax.fill_between(timeEff, Yfit_conf[:,0], Yfit_conf[:,1],
                     lw=0., label=ci_label,color='r',alpha=.25,zorder=4)
    if linelabel is not None:
        lines[0].set_label (linelabel)
        ax.legend(loc = 'upper left', frameon= False)
    # 添加日期
    return ax

# 绘制拟合残差图
def ResidPlot(ax, YfitResid, bins=30, title='Residue of Downhole Fitting'):
    '''
    Plot residuals statistic histogram and KDE to evaluate the quality of downhole fitting. Two parameters, Durbin Watson and Jarque Bera are calculated.

    ARGUMENTS:
    FitResid: 1d numpy array. Residues of the fitting curve.
    bins: integer. Nnumber of equal-width bins in the range of the histogram.

    '''
    # 计算残差图统计数据的参数
    resid_dw = sm.stats.stattools.durbin_watson(YfitResid, axis=0)
    resid_jb,_,_,_ = sm.stats.stattools.jarque_bera(YfitResid, axis=0)
    # 计算KDE曲线
    kde_resid = sm.nonparametric.KDEUnivariate(YfitResid)
    kde_resid.fit(kernel='gau',fft=False, weights=None,bw='normal_reference', adjust=1.5)
    # 画直方图
    ax.hist(YfitResid, bins=bins, density=True, 
         weights=None,stacked=True, color='g', alpha=0.25, label='Fitting Residue')
    # 画KDE图
    ax.plot(kde_resid.support, kde_resid.density, color='g', lw=1, label = 'KDE')
    ax.legend(loc = 'upper left', frameon= False)
    # 标注统计参数
    text = 'Durbin Watson: {:.2f}'.format(resid_dw) + ' (1.2~2.5)'+ '\n' + 'Jarque Bera: {:.2f}'.format(resid_jb)+' (~0)' 
    # (0.5,0.88)是标注位置
    x_text = ax.get_xlim()[0] + 0.62 * (ax.get_xlim()[1] - ax.get_xlim()[0])
    y_text = ax.get_ylim()[0] + 0.88 * (ax.get_ylim()[1] - ax.get_ylim()[0])
    ax.text(x_text, y_text, text)
    ax.set_title(title)
    return ax

def DownholeFitPlots(timeEff, ratioStacks, DhFits, 
                     DhFitCIs, DhFitResids, ylabels, 
                     figwidth =20):
    # 获取列表的长度
    lengths = set([len(ratioStacks),len(DhFits),len(DhFitCIs), 
                   len(DhFitResids),len(ylabels)])
    # 确认输入的变量列表是否长度一致
    if len(lengths) > 1:
        raise ValueError("All varibels must have the same length")
    # 根据输入的变量列表确定绘图行数
    rows = len(ratioStacks)
    fig, axs = plt.subplots(rows, 2, 
                            figsize = (figwidth, 3*(figwidth/2-2)))
    # 循环绘图
    for i in range(0,rows):
        ax_left = axs[i, 0]
        ax_right = axs[i, 1]
        RatioPlot(ax_left, timeEff, 
                  ratio = unumpy.nominal_values(ratioStacks[i]), 
                  ratio_err = unumpy.std_devs(ratioStacks[i]), 
                  Yfit = DhFits[i],
                  Yfit_conf = DhFitCIs[i],
                  ylabel = ylabels[i],
                  xlabel = 'Time in second',
                  linelabel='Original Ratio Mean',
                  ci_label='95% Confidential intervals',
                  title='Downhole Fitting')
        ResidPlot(ax_right, YfitResid =DhFitResids[i], 
                     bins = 20, 
                     title = 'Residue of Downhole Fitting')
    plt.show()


# Downhole比值校正，即乘以归一化因子
def DownholeCali(timeEff, DhFitParams, ratio):
    '''
    Do downhole Calibration by multiply the factors for each ratio.
    arguments:
    DhFit: 1D unumpy uarray. Fitting values (curve) of stacked ratios.
    ratio: 2D numpy array. Time-related ratios of each spot needed to be calculated. 
    return:
    ratioDh: 2D unumpy uarray. Ratios of each spots after downhole calibration.
    '''
    # 校正参数
    X = timeEff
    a = DhFitParams['a']
    b = DhFitParams['b']
    c = DhFitParams['c']
    # 校正曲线
    Yfit = a + b * unumpy.exp(c * X) 
    # 计算比值的校正值
    ratioDh = ratio * a / Yfit[:, np.newaxis]
    return ratioDh
    


# 批量绘制 Downhole校正的所有图件
def DownholeCaliPlots(timeEff, ratios, ratioDhs, ylabels, figwidth=20):
    '''
    Plot figure pairs for original ratios and downhole calibrated.
   
    ARGUMENTS:
    timeEff: 1d array of reference time (in second) of effective signals
    ratios: list of 2D unumpy uarray. Ratios of Original signal  .
    ratioDhs: list of 2D unumpy uarray. Ratios aftter downhole calibration.
    ylabels: list of string. 
    figwidth: float or int.
    '''
    # 获取变量列表的长度
    lengths = set([len(ratios),len(ratioDhs),len(ylabels)])
    # 确认输入的变量列表是否长度一致
    if len(lengths) > 1:
        raise ValueError("All varibels must have the same length")
    # 根据输入的变量列表确定绘图行数
    rows = len(ratios)
    fig, axs = plt.subplots(rows, 2, 
                            figsize = (figwidth, 3*(figwidth/2-2)))
    # 循环绘图
    for i in range(0,rows):
        ax_left = axs[i, 0]
        ax_right = axs[i, 1]
        RatioPlot(ax_left, timeEff,
                  ratio = ratios[i],
                  ylabel = ylabels[i],
                  title='Original Signal Ratios')
        RatioPlot(ax_right, timeEff, 
                  ratio = unumpy.nominal_values(ratioDhs[i]), 
                  ylabel = ylabels[i],
                  title='Downhole Calibrated Signal Ratios')
    plt.show()

##################################################################
## Age Calculation
##################################################################   

# 由比值计算年龄
def AgeUPb(r68, r75, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238):
    a68 = unumpy.log (r68 + 1.) / la_u238
    a75 = unumpy.log (r75+ 1.) / la_u235
    return a68, a75

# 由年龄计算比值，少用
def Age2Ratio(a68, a75, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5):
    r68 = unumpy.expm1(a68 * la_u238)
    r75 = unumpy.expm1(a75 * la_u235)
    r76 = RatioPbPb(r68, r75, u8u5)
    # r76 = (1/u8u5) * (unumpy.expm1(la_u235 * a76) / unumpy.expm1(la_u238 * a76))
    return r68, r75, r76

# # 利用scipy的功能求解，但是无法使用uncertainties
# # 故此函数未使用
# def AgePbPb(r76, la_u235, la_u238, u8u5):
#     r76_values = unumpy.nominal_values(r76)
#     def func(a, r):
#         return abs(u8u5 * r - (np.exp(la_u235 * a) - 1) / (np.exp(la_u238 * a) - 1))
#     # 数值求解76年龄
#     a76_list = []
#     for i, r in enumerate(r76_values):
#         a = 1 / la_u238 * np.log(r + 1)  # initial time for calculation
#         a76 = leastsq(func, a, args=(r))[0][0]
#         a76_list.append(a76)
#     return a76_list

# 用Monte Carlo 法求解pb207/pb206年龄的数值函数
def Solve76ageMC(r76_array, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5):
    # 设置随机参数
    u5u8 = 1.0/u8u5
    num_samples = 100000  
    age_min = 1.0           
    age_max = 4500.
    # Generate random ages
    random_ages = np.linspace(age_min, age_max, num_samples)  # Use linspace for better interpolation
    # Compute the model Pb207/Pb206 ratio for each age (vectorized)
    random_ratios = u5u8 * ((np.exp(la_u235 * random_ages) - 1) / (np.exp(la_u238 * random_ages) - 1))
    # Create an interpolation function to map ratios to ages
    ratio_to_age = interp1d(random_ratios, random_ages, kind='linear', fill_value='extrapolate')
    # Compute best ages with uncertainties
    a76_means = []
    a76_stds = []
    for r76 in r76_array:
        mean_r76 = unumpy.nominal_values(r76)
        std_r76 = unumpy.std_devs(r76)
        if std_r76 <= 0 or np.isnan(std_r76):
            # 如果没有不确定性，直接插值并设置 std=0
            sampled_ages = np.array([ratio_to_age(mean_r76)])
        else:
            # 从正态分布中随机采样 N 次
            sampled_ratios = np.random.normal(loc=mean_r76, 
                                              scale=std_r76, 
                                              size=num_samples)
            # sampled_ratios = np.linspace(mean_r76-std_r76, 
            #                              mean_r76+std_r76, 
            #                              num_samples)
            # 过滤掉不可能的负值
            sampled_ratios[sampled_ratios < 0] = np.nan
            # 使用插值函数将所有采样比值转换为年龄
            sampled_ages = ratio_to_age(sampled_ratios)
            # 最佳年龄
        a76_means.append(np.mean(sampled_ages))
        a76_stds.append(np.std(sampled_ages))
    a76_array = unumpy.uarray(np.array(a76_means), np.array(a76_stds))
    return a76_array

# 考虑uncertainties情况下，求解pb207/pb206年龄的数值函数#
def Solve76ageNewton(r76_array, init, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5, max_iter=500, tol=1e-8):
    '''
    Numerical solving the 206Pb/207Pb ages with uncertainties from their ratios.
    
    ARGUMENTS:
    r76_array: 1d unumpy array. Ratios of 206Pb/207Pb.
    init: 1d unumpy array. Usually the 206Pb/238U ages are used.
    la_u235: float. Constant for 235U decay.
    la_u238: float. Constant for 238U decay.
    u8u5: float. Constant of 238U/235U ratio. It can be an ufloat with uncertainties if needed.

    RETURN:
    solution: 1d unumpy array. Ages of 206Pb/207Pb.
    '''
    u5u8 = 1.0/u8u5
    values_array = np.empty_like(unumpy.nominal_values(r76_array))
    uncertainties_array = np.empty_like(unumpy.std_devs(r76_array))
    # 避免单个值的错误提示
    init_array = unumpy.uarray(np.array(unumpy.nominal_values(init)),np.array(unumpy.std_devs(init)))
    for idx in np.ndindex(r76_array.shape):
        r76 = r76_array[idx]
        a76 = init_array[idx]
        for i in range(max_iter):
            a = unumpy.expm1(la_u235 * a76)
            b = unumpy.expm1(la_u238 * a76)
            c = unumpy.exp(la_u235*a76)
            d = unumpy.exp(la_u238*a76)
            # 76年龄计算 F(a76)
            F = u5u8*a/b - r76
            # 求一阶导数 F'(a76)
            dF = u5u8*(la_u235*c*b-la_u238*d*a) / b**2
            if abs(dF) < tol:
                # Fallback to a small gradient step if derivative is too small
                step_size = 0.01  # Small step size for gradient fallback
                new_a76 = a76 - step_size * F
            else:
                # Newton's update
                newton_step = F / dF
                # Limit the step size to avoid large jumps
                max_step = 1  # Maximum allowed step size
                if abs(newton_step) > max_step:
                    newton_step = max_step * np.sign(newton_step)
                new_a76 = a76 - newton_step
            # # Newton's 更新
            # new_a76 = a76 - (F / dF)
            # 收敛项
            values = unumpy.nominal_values(new_a76)
            uncertainties = unumpy.std_devs(new_a76)
            diff = np.max(np.abs(values - unumpy.nominal_values(a76)))
            # 判断收敛
            if diff < tol:
                break
            a76 = new_a76
        values_array[idx] = values
        uncertainties_array[idx] = uncertainties
    solution = unumpy.uarray(values_array,uncertainties_array)
    return solution

# 过滤掉错误的信号点，令其为nan
def FilterByUPbAge(a68, a75, r68, r75):
    '''
    Replace the ages that are obviously not reasonable by NaN. e.g., less than 0 or larger than 4400 Ma.
    
    ARGUMENTS:
    a68: unumpy array. Ages of 206Pb/238U.
    a75: unumpy array. Ages of 207Pb/235U.
    r68: unumpy array. Ratios of 207Pb/235U.
    r75: unumpy array. Ratios of 207Pb/235U.

    RETURN:
    The same arrays already filtered.
    '''
    nominal_values = [unumpy.nominal_values(uarr) for uarr in (a68, a75)]
    valid_masks = np.array([(values >= 1) & (values <= 4400) for values in nominal_values])
    if valid_masks.any() == False:
        with np.errstate(invalid='ignore'): # 避免出现nan和nan比较时产生的警告
            for (valid, a, r) in zip(valid_masks, (a68, a75), (r68, r75)):
                a[~valid] = np.nan 
                print(a[~valid], 'is bad age')
                r[~valid] = np.nan
                print(r[~valid], 'bad ratio')
    return a68, a75, r68, r75

##################################################################
## Best Segment extraction
##################################################################   

# 构建系数矩阵，设置最小的信号数 minwidth
def CoeffMatrix(minwidth: int, signals: np.ndarray):
    '''
    Build a coefficient matrix (with only 0 and 1) for all possible singal segments. The segments can be got from multiplication of the signal set and ent coefficient matrix.
    
    AUGMENTS:
    minwidth: integar. Minimal width (number of signals) of the segments. Usually 1/3 of the effective signals.
    signals: 3d numpy array of signals.

    RETURNS:
    C3d: 3d numpy array of coefficient (with only 0 and 1). length = possible segments, width = effective signals, depth = spots.
    end3d: 3d numpy array. Start and end index of the segments. length = possible segments, width = 2, depth = spots.
    
    '''
    # 系数矩阵的width取决于minwidth
    width = signals.shape[0]
    depth = signals.shape[2]
    C2d = []
    ends2d = []
    for j in range(minwidth, width):  # 选择的信号个数从 minwidth 到 maxwidth
        for i in range(width - j):  # 区间的起始位置
            C2d_row = np.full(width, np.nan) # 构建nan矩阵
            C2d_row[i:i + j] = 1  # 将对应位置填充为 1
            ends2d.append([i,i + j]) #信号区间的首末位置
            C2d.append(C2d_row)
    C3d = np.repeat(np.array(C2d)[:, :, np.newaxis], depth, axis=2)
    ends3d = np.repeat(np.array(ends2d)[:, :, np.newaxis], depth, axis=2)
    return C3d, ends3d

# ---------------------------------------
# 输入比值，利用系数矩阵提取信号区间（常规方法）
# ---------------------------------------
def Segments(ratios, C):
    '''
    Age calculation (weighted mean and standard deviation) for each segment. For Segment comparison in the next step.

    AUGMENTS:
    ages: 2d unumpy array. Isotope ages for each effective signal. 
    C: 3d numpy array. Coefficient matrix of all possible segments for each spot.

    RETURNS:
    segs_mean: 2d numpy array. Mean ages of all possible segments for each spot.
    segs_se: 2d numpy array. Standard error of all possible segments for each spot.
    
    '''
    # 分离信号点比值与不确定度
    values = unumpy.nominal_values(ratios)
    uncertainties = unumpy.std_devs(ratios)
    # 将2d的年龄矩阵转换为3d后再与系数矩阵相乘
    segs_va = C * values[np.newaxis, :, :] 
    segs_uc = C * uncertainties[np.newaxis, :, :]
    # 取方差的倒数作为权重值
    weight = np.where((~np.isnan(segs_uc)) & (segs_uc != 0),
                      1.0 / (segs_uc ** 2),
                      0.0)
    sum_weights = np.nansum(weight,axis=1)
    # 计算加权平均
    segs_mean = np.nansum(weight*segs_va,axis=1) / sum_weights
    return segs_mean

# 获得所有可能的连续信号区间
def BestSegment(C, r68, r75, r76, threshold = AGE_THRESHOLD, la_u238=LAMBDA_U238):
    '''
    Find the best segment (with high concordance) for each spot after comparison of all segments. Run this function may take several minutes or tens of minutes, which depends on physical memory of the computer.  

    AUGMENTS:
    C: 3d numpy array. Coefficient matrix of all possible segments for each spot.
    a68: 2d unumpy array. 206Pb/238U ages of all signals for each spot.
    a75: 2d unumpy array. 207Pb/235U ages of all signals for each spot.
    
    RETURNS:
    a68Bseg: 2d unumpy array. 206Pb/238U ages of the best segment for each spot. 
    a75Bseg: 2d unumpy array. 207Pb/235U ages of the best segment for each spot. 
    id_Bseg: int.  Index of the best segment in all segments.
    
    '''
    # 68年龄为基准
    threshold_r86 = np.expm1(la_u238 * threshold)
    r75_68 = InterpR75toR68(r75)
    r76_68 = InterpR76toR68(r76)
    segs68_mean = Segments(r68, C)
    segs75_68_mean = Segments(r75_68, C)
    segs76_68_mean = Segments(r76_68, C)
    # # 根据68和75年龄的近似度（谐和度），寻找最佳的连续信号区间的索引
    id_Bseg_68_75 = np.argmin (np.abs(segs68_mean - segs75_68_mean), axis=0)
    id_Bseg_68_76 = np.argmin (np.abs(segs68_mean - segs76_68_mean), axis=0)
    # 比较
    condition = segs68_mean.mean(axis=0) > threshold_r86
    id_Bseg = np.where(condition, id_Bseg_68_76, id_Bseg_68_75)
    print (f'The best segment has been selected from {segs68_mean.shape[0]} potential segments.')
    # # 75年龄为基准
    # r68_75 = InterpR68toR75(r68)
    # segs75_mean = Segments(r75, C)
    # segs68_75_mean = Segments(r68_75, C)
    # id_Bseg_75_68_gpu = cp.argmin (cp.abs(segs68_75_mean - segs75_mean), axis=0)
    
    # 76 年龄为基准

    # 提取最佳区间的系数
    C_Bseg = np.dstack([C[x, :, i] for i, x in enumerate(id_Bseg)])
    return C_Bseg, id_Bseg

# ---------------------------------------
# 输入比值，利用系数矩阵提取信号区间（GPU方法）
# ---------------------------------------
def SegmentsGPU(ratios, C):
    # 拆出数值与不确定度（numpy arrays）
    values = unumpy.nominal_values(ratios)      # shape (N, P)
    uncertainties = unumpy.std_devs(ratios)     # shape (N, P)

    # 将 C 与 values/uncertainties 拷到 GPU
    C_gpu = cp.asarray(C)
    values_gpu = cp.asarray(values)
    uncertainties_gpu = cp.asarray(uncertainties)

    # 将2d的年龄矩阵转换为3d后再与系数矩阵相乘
    segs_va = C_gpu * values_gpu[cp.newaxis, :, :]
    segs_uc = C_gpu * uncertainties_gpu[cp.newaxis, :, :]
    
    # 取方差的倒数作为权重值
    weight = cp.where((~cp.isnan(segs_uc)) & (segs_uc != 0),
                      1.0 / (segs_uc ** 2),
                      0.0)
    sum_weights = cp.nansum(weight,axis=1)
    # 计算加权平均
    segs_mean = cp.nansum(weight*segs_va,axis=1) / sum_weights
    return segs_mean


# 获得所有可能的连续信号区间
def BestSegmentGPU(C, r68, r75, r76, threshold = AGE_THRESHOLD, la_u238=LAMBDA_U238):
    '''
    Find the best segment (with high concordance) for each spot after comparison of all segments. Run this function may take several minutes or tens of minutes, which depends on physical memory of the computer.  

    AUGMENTS:
    C: 3d numpy array. Coefficient matrix of all possible segments for each spot.
    a68: 2d unumpy array. 206Pb/238U ages of all signals for each spot.
    a75: 2d unumpy array. 207Pb/235U ages of all signals for each spot.
    
    RETURNS:
    a68Bseg: 2d unumpy array. 206Pb/238U ages of the best segment for each spot. 
    a75Bseg: 2d unumpy array. 207Pb/235U ages of the best segment for each spot. 
    id_Bseg: int.  Index of the best segment in all segments.
    
    '''
    # 68年龄为基准
    threshold_r86 = np.expm1(la_u238 * threshold)
    r75_68 = InterpR75toR68(r75)
    r76_68 = InterpR76toR68(r76)
    segs68_mean = SegmentsGPU(r68, C)
    segs75_68_mean = SegmentsGPU(r75_68, C)
    segs76_68_mean = SegmentsGPU(r76_68, C)
    # # 根据68和75年龄的近似度（谐和度），寻找最佳的连续信号区间的索引
    id_Bseg_68_75_gpu = cp.argmin (cp.abs(segs68_mean - segs75_68_mean), axis=0)
    id_Bseg_68_76_gpu = cp.argmin (cp.abs(segs68_mean - segs76_68_mean), axis=0)
    # 比较
    condition = segs68_mean.mean(axis=0) > threshold_r86
    id_Bseg_gpu = cp.where(condition, id_Bseg_68_76_gpu, id_Bseg_68_75_gpu)
    print (f'The best segment has been selected from {segs68_mean.shape[0]} potential segments.')

    # # 75年龄为基准
    # r68_75 = InterpR68toR75(r68)
    # segs75_mean = SegmentsGPU(r75, C)
    # segs68_75_mean = SegmentsGPU(r68_75, C)
    # id_Bseg_75_68_gpu = cp.argmin (cp.abs(segs68_75_mean - segs75_mean), axis=0)
    
    # 76 年龄为基准

    # 从gpu换回到cpu
    id_Bseg = cp.asnumpy(id_Bseg_gpu)
    # 提取最佳区间的系数
    C_Bseg = np.dstack([C[x, :, i] for i, x in enumerate(id_Bseg)])
    return C_Bseg, id_Bseg



    
# 对最佳区间计算加权平均和不确定度
# 参考 Mclean et al.(2011)的方法
def WeightedAverage(a_r_array, err = 'internal'):
    '''
    Calculate the weighted average for 2D age (a) or ratio (r) matrix
    ARGUMENT:
    a_r_array: 2D unumpy uarray type.
    RETURN:
    a_r_arrayAvg: unumpy uarray type. 
    a_r_arrayMSWD: Mean Square Weighted Deviation.
    '''
    # 分离信号点年龄值与不确定度
    values = unumpy.nominal_values(a_r_array)
    uncertainties = unumpy.std_devs(a_r_array)
    # 统计有效个数
    counts = np.sum(~unumpy.isnan(a_r_array), axis=0)  
    dof = np.maximum(1, counts - 1)
    # 方差的倒数作为权重值
    weights = np.divide(1.0, uncertainties**2, where = uncertainties!=0)
    weights[np.isnan(weights)] = 0
    # 计算加权平均
    sum_weights = np.nansum(weights, axis=0)
    # sum_weights_safe = np.where(sum_weights == 0, 1, sum_weights)     # 避免除以零
    mean = np.nansum(weights * values,axis=0) / sum_weights
    # 计算 Mean Square Weighted Deviation 
    mswd = np.nansum(weights * (values - mean)**2, axis=0) / dof
    # # 计算加权平均的标准差
    # a_r_arraySD = np.sqrt(np.nansum(weights * (values - a_r_arrayMEAN)**2, axis=0) / np.nansum(weights, axis=0))
    # # 计算标准误差
    # a_r_arraySE = a_r_arraySD / np.sqrt(counts)
    # 计算内部标准误差
    se_internal = np.sqrt(1.0 / sum_weights)
    # 检查 MSWD > 1，如果需要，则作为超额方差
    inflation_factor = np.maximum(1.0, mswd)
    # 计算外部标准误差
    se_external = se_internal * np.sqrt(inflation_factor)
    # 组合成uncertainties类型
    if err == 'internal':
        a_r_arrayAvg = unumpy.uarray(mean, se_internal)
        return a_r_arrayAvg, mswd
    elif err == 'external':
        a_r_arrayAvg = unumpy.uarray(mean, se_external)
        return a_r_arrayAvg, mswd
    else:
        raise ValueError("The err param should be internal or external!")

# 计算所有年龄和比值的加权平均
def BestSegmentAvg(C_Bseg,  *a_r_arrays):
    """
    Calculate the weighted average of the best segment for any number of isotope age matrices.
    
    Parameters
    ----------
    C_Bseg : np.ndarray
        Coefficient of best signal interval
    *a_r :  unumpy.uarray
        One or more age or ratio matrices
    
    Returns
    -------
    tuple of unumpy.uarray
        Weighted average results for each provided age matrix.
    """
    results = []
    with np.errstate(invalid='ignore'):
        for i, a_r_array in enumerate(a_r_arrays):
            # 检查维度匹配
            assert C_Bseg.shape[1] == a_r_array.shape[0], "dimension not match!"
            # 将3D矩阵转化为2D与a_r相乘
            # weighted_seg = np.sum(C_Bseg * a_r_array[np.newaxis, :, :], axis=0)
            a_r_array_Bseg = C_Bseg[0]*a_r_array
            # 计算加权平均
            avg, _ = WeightedAverage(a_r_array_Bseg)
            results.append(avg)

    return tuple(results)
    

##################################################################
## Instrument drifting calibration
##################################################################  


# # 采用scikit-learn构建样条函数拟合标样，并对仪器漂移校正
# def DriftFit(datetimes, a_rBsegAvg, dof = None, n_knots = None):
#     '''
#     Fit the age or ratio drifting of the standard spots (K-) through time series. The drifting curve is fitted with cubic spline function by Statsmodels module using ordinary least squares (OLS). The design matrix of the cubic spline function is built by Pasty module.  
    
#     ARGUMENTS:
#     Kdatetimes: 1D numpy array. Absolute datetimes of standard (known) spots
#     Ka_KrBsegAvg: 1D unumpy uarray. Ages or Ratios of standard (known) spots
#     dof: degree of freedom for cubic spline function.

#     RETURN:
#     DcFit: Statsmodel objects
#     '''
#     # # 利用近邻域对邻近的spots求平均
#     # Kdatetimes_nn, Ka_KrBsegAvg_nn = NearestNeighbor(Kdatetimes, Ka_KrBsegAvg, isRatio=True)
#     # print(Kdatetimes.shape)
    
#     # 确认输入的参数中包含了dof或n_knots
#     try:
#         # 转换为float时间
#         X = TimeAbs2Ref(datetimes)
#         Y =  unumpy.nominal_values(a_rBsegAvg)
#         # Yweights = 1.0 / unumpy.std_devs(Ka_KrBsegAvg_nn)**2
#         if (n_knots is not None) and (dof is None):
#             # 使用SplineTransformer构建样条函数
#             spline_func = SplineTransformer(n_knots=n_knots, degree=3, include_bias=True)
#             # 构建样条基函数
#             X_basis = spline_func.fit_transform(X.reshape(-1, 1))
#         elif (n_knots is None) and (dof is not None):
#             # 使用patsy构建样条基函数
#             X_basis = dmatrix("bs(x, df=dof, degree=3,  include_intercept=False)", {"x": X})
#         else:
#             raise ValueError("Either dof or n_knots should be needed as input!")
#         # 添加statsmodel线性拟合需要的常数项
#         X_basis_const = sm.add_constant(X_basis)
#         # 使用statsmodel的最小二乘法建立样条曲线拟合
#         DcFit = sm.OLS(Y, X_basis_const).fit()
#         # DcFit = sm.WLS(Ynn, Xnn_basis, weights = Yweights).fit()
#         return DcFit
#     except ValueError as e:
#         print(f"Configuration error: {e}")
        
# 采用scikit-learn构建样条函数拟合标样，并对仪器漂移校正
def DriftFit(datetimes, rDh, dof = None, n_knots = None, outer=[]):
    '''
    Fit the age or ratio drifting of the standard spots (K-) through time series. The drifting curve is fitted with cubic spline function by Statsmodels module using ordinary least squares (OLS). The design matrix of the cubic spline function is built by Pasty module.  
    
    ARGUMENTS:
    Kdatetimes: 1D numpy array. Absolute datetimes of standard (known) spots
    Ka_KrBsegAvg: 1D unumpy uarray. Ages or Ratios of standard (known) spots
    dof: degree of freedom for cubic spline function.

    RETURN:
    DcFit: Statsmodel objects
    '''
    # # 利用近邻域对邻近的spots求平均
    # Kdatetimes_nn, Ka_KrBsegAvg_nn = NearestNeighbor(Kdatetimes, Ka_KrBsegAvg, isRatio=True)
    # print(Kdatetimes.shape)
    
    # 确认输入的参数中包含了dof或n_knots
    try:
        # Y =  unumpy.nominal_values(rDh.ravel())
        # 针对每个spot
        X_avg = TimeAbs2Ref(datetimes)
        Y_avg,_ = WeightedAverage(rDh)
        Y_avg = unumpy.nominal_values(Y_avg)
        if len(outer)!=0:
            X_avg = np.delete(X_avg, outer)
            Y_avg = np.delete(Y_avg, outer)
        # Yweights = 1.0 / unumpy.std_devs(Ka_KrBsegAvg_nn)**2
        if (n_knots is not None) and (dof is None):
            # 使用SplineTransformer构建样条函数
            spline_func = SplineTransformer(n_knots=n_knots, degree=3, include_bias=True)
            # 构建样条基函数
            X_avg_basis = spline_func.fit_transform(X_avg.reshape(-1, 1))
        elif (n_knots is None) and (dof is not None):
            # 使用patsy构建样条基函数
            X_avg_basis = dmatrix("bs(x, df=dof, degree=3,  include_intercept=False)", {"x": X_avg})
        else:
            raise ValueError("Either dof or n_knots should be needed as input!")
        # 添加statsmodel线性拟合需要的常数项
        X_avg_basis_const = sm.add_constant(X_avg_basis)
        # 使用statsmodel的最小二乘法建立样条拟合模型
        DcFit = sm.OLS(Y_avg, X_avg_basis_const).fit()
        # DcFit = sm.WLS(Ynn, Xnn_basis, weights = Yweights).fit()
        # 获得在signal和spot位置的拟合值
        DcFit_X_avg = DcFit.get_prediction(X_avg_basis_const)
        # 画图所需的值
        DcFitCurve = DcFit_X_avg.predicted 
        DcFitCurveConf95 = DcFit_X_avg.conf_int(obs=False,alpha=0.05) 
        # 返回的rDhDc还需要变为原来的二维形态
        return DcFit, DcFitCurve, DcFitCurveConf95
    except ValueError as e:
        print(f"Configuration error: {e}")



def DriftCali(DcFit, datetimes, timeEff, rDh, STDr,  dof=None, n_knots=None):
    '''
    Drifting calibration of the unknown spots using fitted ages or ratios of the standard spots. 
    
    ARGUMENTS:
    DcFit: Statsmodels regression result.
    datetimes: 1D numpy array. Absolute datetimes of standard spots.
    a_rBsegAvg: 1D unumpy uarray. age or ratios of unknown spots for calibration.
    STDa_r: 1D unumpy uarray. age or ratios of the standard spots.
    cali: 1) self: DcFit is from the ratio itself. 
          2) 68to75: using r68 DcFit to calibrate r75. 
          3) 68to76: using r68 DcFit to calibrate r76.
    dof: degree of freedom for cubic spline function. Must be same as the value of DriftFit().
    
    RETURNS:
    a_rBsegAvgDc: 1D unumpy array. Calibrated age or ratio of the unknown spots.
    DcFitCurve: 1D numpy array. Fitted drifting curve (Y) of the age or ratio. 
    DcFitCurveConf95: 2D numpy array. Upper and Lower limit (Y+/-) of the confidence interval of the fitted drifting curve.
    '''
    try:
        # 针对每个signal, 转换为float时间
        timeEffRef, _ =  TimeSeries(datetimes, timeEff)
        X = timeEffRef.ravel()
        if (n_knots is not None) and (dof is None):
            # 使用SplineTransformer构建样条函数
            spline_func = SplineTransformer(n_knots=n_knots, degree=3, include_bias=True)
            # 构建样条基函数
            X_basis = spline_func.fit_transform(X.reshape(-1, 1))
        elif (n_knots is None) and (dof is not None):
            # 使用patsy构建样条基函数
            X_basis = dmatrix("bs(x, df=dof, degree=3,  include_intercept=False)", {"x": X})
        else:
            raise ValueError("Either dof or n_knots should be needed as input!")
        # 添加statsmodel线性拟合需要的常数项
        X_basis_const = sm.add_constant(X_basis)
        # 获得在signal和spot位置的拟合值
        DcFit_X = DcFit.get_prediction(X_basis_const)
        # 根据标样值对每个signal进行校正
        DcFit_Y = unumpy.uarray(DcFit_X.predicted, DcFit_X.se)
        rDhDc = rDh.ravel(order='F') * (STDr / DcFit_Y)
        return rDhDc.reshape(rDh.shape,order='F')
    except ValueError as e:
        print(f"Configuration error: {e}")

    
# bkgCurves 参数为带误差的 unumpy.uarray 类型
def DriftFitPlot(datetimes, timeEff,rDhDc, spots, DcFitCurve, DcFitCurveConf95, outer=[],
                 ylabels ='$^{206}$Pb/$^{238}$U',figsize = (20,4)):
    '''
    Plot Drifting calibration of the unknown spots using fitted ages or ratios of the standard spots. 
    
    ARGUMENTS:
    Kdatetimes: 1D numpy array. Absolute datetimes of standard spots.
    Ka_KrBsegAvg: 1D unumpy uarray. age or ratios of standard spots.
    Kspots: 1D numpy array. Names of the standard spots.
    DcFitCurve: 1D numpy array. Fitted drifting curve (Y) of the age or ratio. 
    DcFitCurveConf95: 2D numpy array. Upper and Lower limit (Y+/-) of the confidence interval of the fitted drifting curve.
    outer: list of the spot index that will be deleted for . 
    
    RETURNS:
    a_rBsegAvgDc: 1D unumpy array. Calibrated age or ratio of the unknown spots.
    DcFitCurve: 1D numpy array. Drifting curve of the age or ratio. 
    DcFitCurveConf95: 2D numpy array. Upper and Lower limit of the confidence interval of the drifting curve.
    '''
    fig, ax = plt.subplots(figsize =figsize)
    # 分离2d array数值和不确定度
    timeEffRef, timeEffAbs =  TimeSeries(datetimes, timeEff)
    values = unumpy.nominal_values(rDhDc)
    # uncertainties = unumpy.std_devs(rDhDc)
    # 画每个spot的比值或年龄
    # ax.errorbar(Kdatetimes, values, uncertainties, 
    #             color = 'b', marker='s',markersize =5, linestyle='None',zorder=1)
    # 用datetimes和spots构建outer
    mask = np.ones_like(datetimes, dtype=bool)   
    mask[outer] = False               # 要删除的列设为 False
    inner = ax.plot(timeEffAbs.T[:,mask], values[:,mask], color = 'b')
    outer = ax.plot(timeEffAbs.T[:,outer], values[:,outer], color = 'orange')
    # 画拟合线
    ax.plot(datetimes, DcFitCurve, color = 'r', label='Spline fitting')
    # 画置信区间
    ax.fill_between(datetimes, DcFitCurveConf95[:,0], DcFitCurveConf95[:, 1],
                     color='red', lw = 0., alpha=0.2, label='95% Confidence intervals')
    # 标注样品号
    for i, spot in enumerate(spots):
        x = datetimes[i]
        y = np.nanmin(values[:,i])
        if i % 2 == 0:
            ax.annotate(text=spot,xy=(x, y), xytext=(-15,0),
                        textcoords='offset pixels', rotation=90)
        else:
            ax.annotate(text=spot,xy=(x, y), xytext=(5,0),
                        textcoords='offset pixels', rotation=90)
    handles, labels = ax.get_legend_handles_labels()
    if len(outer) != 0:
        ax.legend(handles +[inner[0]]+[outer[0]], 
                  labels+['Used Signals']+['Removed Signals'],
                  loc = 'upper right', frameon= False)
    else:
        ax.legend(handles +[inner[0]], 
                  labels+['Used Signals'],
                  loc = 'upper right', frameon= False)
    ax.xaxis.set_label_text('Time Series')
    ax.yaxis.set_label_text(ylabels)
    # ax.set_ylim(1,2)
    ax.set_title('Drift Fitting and Calibration')
    plt.show()

# 删除异常点，如严重不谐和的点，或76比值为负值的点, 仅限于拟合时使用
def DeleteSpots(datetimes, spots, a_r68, a_r75, a_r76, Outer=[]):
    '''
    Delete spots if they do not have good result (on concordia diagram). The drifting will be calibrated again using updated spots.
    ARGUMENT:
    datetimes: 1D numpy array. Absolute datetimes of all the spots
    spots: 1D numpy array. names of all the spots 
    a68: 1D unumpy array. Ages of 206Pb/238U.
    a75: 1D unumpy array. Ages of 207Pb/235U.
    '''
    a_r68Ot=np.delete(a_r68, Outer)
    a_r75Ot=np.delete(a_r75, Outer)
    a_r76Ot=np.delete(a_r76, Outer)
    spotsOt=np.delete(spots, Outer)
    datetimesOt=np.delete(datetimes, Outer)
    return datetimesOt, spotsOt, a_r68Ot, a_r75Ot,a_r76Ot

# 对于漂移校正完成后，发现严重不谐和的点，或76比值为负值的点, 仅限于拟合时使用
def RemoveSpots(datetimes, spots, *rDhDcs,Outer=[]):
    '''
    Delete spots if they do not have good result (on concordia diagram). The drifting will be calibrated again using updated spots.
    ARGUMENT:
    datetimes: 1D numpy array. Absolute datetimes of all the spots
    spots: 1D numpy array. names of all the spots 
    a68: 1D unumpy array. Ages of 206Pb/238U.
    a75: 1D unumpy array. Ages of 207Pb/235U.
    '''
    spotsOt=np.delete(spots, Outer)
    datetimesOt=np.delete(datetimes, Outer)
    results = [datetimesOt,spotsOt]
    for rDhDc in rDhDcs:
        rDhDcOt = np.delete(rDhDc, Outer, axis=1)
        results.append(rDhDcOt)
    return tuple(results)

##################################################################
## Plot U-Pb concordia diagram
##################################################################  

# 近似计算协方差和不确定度相关系数, 根据 Schmita 和 Schoene（2007）近似计算协方差
def Covariance75to68(r68, r75, r76):
    '''
    Calculate the covariance and correlation coefficient betweeen Pb207/U235 and Pb206/U238 for U-Pb ploting. Using the method given by Schmita & Schoene (2007). 
    
    ARGUMENTS:
    r75: 1D unumpy uarray. Ratios of Pb207/U235.
    r68: 1D unumpy uarray. Ratios of Pb206/U238.
    r76: 1D unumpy uarray. Ratios of Pb207/Pb206
    
    RETURNS:
    cov_r75r68: 1D numpy array. Covariance between Pb207/U235 and Pb206/U238.
    rho_r75r68: 1D numpy array. Correlation coefficient betweeen Pb207/U235 and Pb206/U238.
    
    '''
    # 相对值
    Sr75 = unumpy.std_devs(r75) / unumpy.nominal_values(r75)
    Sr68 = unumpy.std_devs(r68) / unumpy.nominal_values(r68)
    Sr76 = unumpy.std_devs(r76) / unumpy.nominal_values(r76)  
    # 近似计算相关系数 error correlation
    rho_r75r68 = (Sr75**2 + Sr68**2 - Sr76**2) / (2 * Sr75 * Sr68) 
    # 近似计算协方差covariance
    cov_r75r68 = rho_r75r68 * unumpy.std_devs(r75) * unumpy.std_devs(r68)
    return cov_r75r68, rho_r75r68

# 近似计算协方差和不确定度相关系数, 根据 Schmita 和 Schoene（2007）近似计算协方差
def Covariance86to76(r68, r75, r76):
    '''
    Calculate the covariance and correlation coefficient betweeen Pb207/U235 and Pb206/U238 for U-Pb ploting. Using the method given by Schmita & Schoene (2007). 
    
    ARGUMENTS:
    r75: 1D unumpy uarray. Ratios of Pb207/U235.
    r68: 1D unumpy uarray. Ratios of Pb206/U238.
    r76: 1D unumpy uarray. Ratios of Pb207/Pb206
    
    RETURNS:
    cov_r86r76: 1D numpy array. Covariance between Pb207/U235 and Pb206/U238.
    rho_r86r76: 1D numpy array. Correlation coefficient betweeen Pb207/U235 and Pb206/U238.
    
    '''
    # 相对值
    r87 = 1./(r76 * r68)
    Sr87 = unumpy.std_devs(r87) / unumpy.nominal_values(r87)
    r86 = 1./ r68
    Sr86 = unumpy.std_devs(r86) / unumpy.nominal_values(r86)
    Sr76 = unumpy.std_devs(r76) / unumpy.nominal_values(r76)  
    # 近似计算相关系数 error correlation
    rho_r86r76 = (Sr86**2 + Sr76**2 - Sr87**2) / (2 * Sr86 * Sr76) 
    # 近似计算协方差covariance
    cov_r86r76 = rho_r86r76 * unumpy.std_devs(r86) * unumpy.std_devs(r76)
    return cov_r86r76, rho_r86r76
    
# 在U-Pb谐和图上添加加权平均后的年龄结果，包括不确定度 和 MSDW的计算结果
def UPbconText(ax, r68, r75, r76, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5,
               err = 'internal', Xproportion =0.02, Yproportion=0.8):
    '''
    Calculate the covariance and correlation coefficient betweeen Pb207/U235 and Pb206/U238 for U-Pb ploting. Using the method given by Schmita & Schoene (2007). 
    
    ARGUMENTS:
    r75: 1D unumpy uarray. Ratios of Pb207/U235.
    r68: 1D unumpy uarray. Ratios of Pb206/U238.
    r76: 1D unumpy uarray. Ratios of Pb207/Pb206
    
    RETURNS:
    cov_r75r68: 1D numpy array. Covariance between Pb207/U235 and Pb206/U238.
    rho_r75r68: 1D numpy array. Correlation coefficient betweeen Pb207/U235 and Pb206/U238.
    
    '''
    r68avg, r68avgMSWD = WeightedAverage(r68,err=err)
    r75avg, r75avgMSWD = WeightedAverage(r75,err=err)
    r76avg, r76avgMSWD = WeightedAverage(r76,err=err)
    # 标注加权平均年龄均值、SE和MSDW
    # 求解68和75年龄
    a68avg, a75avg = AgeUPb(r68avg, r75avg, la_u235, la_u238)
    # r76avg = unumpy.uarray([unumpy.nominal_values(r76avg)], [unumpy.std_devs(r76avg)])
    r76avg = np.atleast_1d(r76avg)
    # 求解76年龄
    a76avg= Solve76ageMC(r76avg, la_u235, la_u238, u8u5)
    # 标注的格式
    text = '$^{206}$Pb/$^{238}$U Age: ' + '{:.1fP}'.format(a68avg) + \
            ' ({:.1f})'.format(r68avgMSWD) +'\n' + \
            '$^{207}$Pb/$^{235}$U Age: ' + '{:.1fP}'.format(a75avg) + \
            ' ({:.1f})'.format(r75avgMSWD) + '\n' +\
            '$^{207}$Pb/$^{206}$Pb Age: ' + '{:.1fP}'.format(a76avg[0]) + \
            ' ({:.1f})'.format(r76avgMSWD)
    # 标注位置占图面的百分比
    axWidth = ax.get_xlim()[1] - ax.get_xlim()[0]
    axHeight = ax.get_ylim()[1] - ax.get_ylim()[0]
    x_text = ax.get_xlim()[0] + Xproportion * axWidth
    y_text = ax.get_ylim()[0] + Yproportion * axHeight
    ax.text(x_text, y_text, text, fontsize=8)
    # 远离均值中心的spot，被视为Outer
    return ax

# 排除误差椭圆偏离均值较大的点
def UPbconOuter(rX_array, rY_array, nOuter):
    '''
    Calculate the distance between each spot and the weighted average then set exclusion with the number of outer. 
    
    ARGUMENTS:
    r75: 1D unumpy uarray. Ratios of Pb207/U235.
    r68: 1D unumpy uarray. Ratios of Pb206/U238.
    nOuter: int. Number of outer for exclusion.
    
    RETURNS:
    Outer: list. Spot index list for exclusion.
    
    '''
    rX_array_avg,_ = WeightedAverage(rX_array)
    rY_array_avg,_ = WeightedAverage(rY_array)
    if nOuter != 0:
        distance = unumpy.sqrt((rX_array - rX_array_avg)**2 + (rY_array - rY_array_avg)**2)
        # 比较每个spot（标样）距离均值中心的远近
        Outer = np.argsort(distance)[::-1][:nOuter]
        Outer = Outer.tolist()
    else: Outer = []
    return Outer

  
# 画U-Pb谐和图上的spot误差椭圆
def UPbconSingleEllipse(ax, rX, rY, cov_rXrY, spot, ellConf=0.95, inOuter=True, type='wetherill'):
    '''
    Plot error ellipse for single spot on Wetherill concordian plot. 
    
    ARGUMENTS:
    r75: ufloat. Ratios of Pb207/U235.
    r68: ufloat. Ratios of Pb206/U238.
    cov_r75r68: ufloat. Covariance between Pb207/U235 and Pb206/U238.
    spot: str. spot name.
    la_u235: float. Constant for 235U decay
    la_u238: float. Constant for 238U decay
    ellConf: float. Confidence level for chi-square distribution of 2 degrees of freedom.
    inOuter: Boolean. if the spot is in Outer list, it is True.
    
    '''
    # 由自带的不确定度平方（方差）和协方差组合成协方差矩阵
    cov = ([rX.s**2, cov_rXrY], [cov_rXrY, rY.s**2])
    # 求解协方差矩阵的特征值与特征向量，由于上面的协方差是近似计算得到，因此vals中可能会有负值
    vals, vecs = np.linalg.eigh(cov)
    # 椭圆旋转角度
    theta = np.arctan2(vecs[0,1],vecs[0,0])/np.pi*180
    # 椭圆的长短轴是协方差矩阵特征值的开方，误差椭圆通常使用chi方分布函数算置信度
    width, height =  np.sqrt(stats.chi2.ppf(ellConf, 2) * np.abs(vals))
    # 分情况画误差椭圆
    # 如果spot在Outer的list中，画椭圆并标注spot的名字
    if inOuter==True: 
        # 远离加权平均中心的点被视为Outer点
        ellipse = Ellipse((rX.n, rY.n), width, height, angle=theta, 
                      edgecolor = 'r', facecolor='none',linewidth=.5)
        if type == 'wetherill':
            rXc = InterpR75toR68(rX)
        elif type == 'tw':
            rXc = InterpR68toR76(1.0/rX)
        if  rX.n > rXc: # 谐和线上部的outer点标注在左侧
            ax.annotate(spot, xy=(rX.n, rY.n), xytext=(-80,0), textcoords='offset pixels',color='r',fontsize =8)
        elif rX.n <= rXc: # 谐和线下部的outer点标注在左侧
            ax.annotate(spot, xy=(rX.n, rY.n), xytext=(40,0), textcoords='offset pixels',color='r',fontsize =8)
    # 如果spot不在Outer的list中，直接画椭圆
    else:
        ellipse = Ellipse((rX.n, rY.n), width, height, angle=theta, 
                          edgecolor = 'k', facecolor='b',alpha=.2, linewidth=0.5)
    ax.add_patch(ellipse)
    return ax

# 画 Wetherill U-Pb 谐和图
def UPbWetherillPlot(r68, r75, r76, spots, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5, 
               title='Wetherill U-Pb Concordia Plot',
               figsize=(6,5), isDetrital=True, err='internal', nOuter=0):
    '''
    Plot Wetherill U-Pb concodia 
    ARGUMENT:
    r75: 1D numpy array. 207Pb/235U ratios of spots
    r68: 1D numpy array. 206Pb/238U ratios of spots
    r76: 1D numpy array. 207Pb/206Pb ratios of spots
    la_u235: float. Constant for 235U decay
    la_u238: float. Constant for 238U decay
    u8u5: float. constant value for 238U/235U
    title: figure title string
    isDetrital: Boolean. If it is False, there will be weighted average age calculated.
    RETURN:
    Outer: list. Index of the spots that are farest out of the weighted average.
    '''
    # 画U-Pb谐和线
    fig, ax = plt.subplots(figsize = figsize)
    # 确定谐和线的年龄分布范围
    r68_values = unumpy.nominal_values(r68)
    r68_max_age = np.log (np.max(r68_values) + 1.) / la_u238
    r68_min_age = np.log (np.min(r68_values) + 1.) / la_u238
    age_range_up = math.ceil(r68_max_age / 10.) * 10 + math.ceil(r68_max_age * .01)*10
    age_range_down = math.floor(r68_min_age / 10.) * 10 - math.ceil(r68_min_age * .01)*10
    age_range_interval = math.ceil((age_range_up - age_range_down) / 100.) *10
    # print (age_range_up, age_range_down, age_range_interval)
    age_range = np.arange(age_range_down, age_range_up, age_range_interval)
    # 由年龄分布范围计算得到X轴（75）和Y（68）轴比值分布范围
    r75Con = np.expm1(age_range * la_u235)
    r68Con = np.expm1(age_range * la_u238)
    # 画线
    ax.plot(r75Con, r68Con, color='k', lw=0.5, zorder=1)
    # 画点
    ax.scatter(r75Con, r68Con, marker='o', s=10, edgecolors='k', linewidths=0.5, facecolors='w',zorder=2)
    # 标注年龄
    for i in range(len(r75Con)): 
        ax.annotate(age_range[i], xy = (r75Con[i], r68Con[i]),
                    xytext=(-30,0), textcoords='offset pixels',fontsize=8)
    if isDetrital == False:       
        UPbconText(ax, r68, r75, r76, la_u235, la_u238, u8u5, err=err, Xproportion =0.02, Yproportion=0.8)
    # 计算协方差
    cov_r75r68, _ = Covariance75to68(r68, r75, r76)
    # 画不确定度椭圆
    if nOuter != 0:        
        Outer = UPbconOuter(r68, r75,nOuter=nOuter)
    else: Outer = []
    for i in range(r75.shape[0]):
        if i in Outer:
            UPbconSingleEllipse(ax, r75[i], r68[i], cov_r75r68[i], spots[i], 
                                ellConf=0.95, inOuter=True, type='wetherill')
        else:
            UPbconSingleEllipse(ax, r75[i], r68[i], cov_r75r68[i], spots[i], 
                                ellConf=0.95,inOuter=False, type='wetherill')
    ax.set_title(title)
    ax.yaxis.set_label_text('$^{206}$Pb/$^{238}$U')
    ax.xaxis.set_label_text('$^{207}$Pb/$^{235}$U')
    # 返回要去掉的spot点，用于后续的拟合
    if len(Outer)!= 0:
        return Outer
    plt.show()

# 画 Wetherill U-Pb 谐和图
def UPbTeraWasserburgPlot(r68, r75,r76,spots, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5, 
               title='Wetherill U-Pb Concordia Plot',
               figsize=(6,5), isDetrital=True,err='internal', nOuter=0):
    '''
    Plot Tera-Wasserburg U-Pb concodia 
    ARGUMENT:
    r75: 1D numpy array. 207Pb/235U ratios of spots
    r68: 1D numpy array. 206Pb/238U ratios of spots
    r76: 1D numpy array. 207Pb/206Pb ratios of spots
    la_u235: float. Constant for 235U decay
    la_u238: float. Constant for 238U decay
    u8u5: float. constant value for 238U/235U
    title: figure title string
    isDetrital: Boolean. If it is False, there will be weighted average age calculated.
    RETURN:
    Outer: list. Index of the spots that are farest out of the weighted average.
    '''
    # 画U-Pb谐和线
    fig, ax = plt.subplots(figsize = figsize)
    # 根据68年龄确定谐和线的范围
    r68_values = unumpy.nominal_values(r68)
    r68_max_age = np.log (np.max(r68_values) + 1.) / la_u238
    r68_min_age = np.log (np.min(r68_values) + 1.) / la_u238
    age_range_up = math.ceil(r68_max_age / 10.) * 10 + math.ceil(r68_max_age * .01)*10
    age_range_down = math.floor(r68_min_age / 10.) * 10 - math.ceil(r68_min_age * .01)*10
    age_range_interval = math.ceil((age_range_up - age_range_down) / 100.) *10
    # print (age_range_up, age_range_down, age_range_interval)
    age_range = np.arange(age_range_down, age_range_up, age_range_interval)
    # 由年龄分布范围计算得到X轴（86）和Y（76）轴比值分布范围
    r75Con = np.expm1(age_range * la_u235)
    r68Con = np.expm1(age_range * la_u238)
    r86Con = 1. / r68Con
    r76Con = (r75Con / r68Con) / u8u5
    # 画线
    ax.plot(r86Con, r76Con, color='k', lw=0.5, zorder=1)
    # 画点
    ax.scatter(r86Con, r76Con, marker='o', s=10, edgecolors='k', linewidths=0.5, facecolors='w',zorder=2)
    # 标注年龄
    for i in range(len(r86Con)): 
        ax.annotate(age_range[i], xy = (r86Con[i], r76Con[i]),
                    xytext=(-30,0), textcoords='offset pixels',fontsize=8)
    if isDetrital == False:       
        UPbconText(ax, r68, r75, r76, la_u235, la_u238, u8u5, err=err, Xproportion =0.55, Yproportion=0.8)
    # 计算协方差
    cov_r86r76, _ = Covariance86to76(r68, r75, r76)
    # 计算r86
    r86 = 1./r68
    # 画不确定度椭圆
    if nOuter != 0:        
        Outer = UPbconOuter(r86,r76, nOuter=nOuter)
    else: Outer = []
    for i in range(r86.shape[0]):
        if i in Outer:
            UPbconSingleEllipse(ax, r86[i], r76[i], cov_r86r76[i], spots[i], 
                                ellConf=0.95, inOuter=True, type = 'tw')
        else:
            UPbconSingleEllipse(ax, r86[i], r76[i], cov_r86r76[i], spots[i], 
                                ellConf=0.95, inOuter=False, type = 'tw')
    ax.set_title(title)
    ax.yaxis.set_label_text('$^{207}$Pb/$^{206}$Pb')
    ax.xaxis.set_label_text('$^{238}$U/$^{206}$Pb')
    # 返回要去掉的spot点，用于后续的拟合
    if len(Outer)!= 0:
        return Outer
    plt.show()


##################################################################
## Calculate discordance
##################################################################  

# 近似计算Wetherill谐和图对数形式下的X-Y轴的比例，用于归一化
def WetherillScale(age_min, age_max, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5 ):
    ages = np.linspace(age_min, age_max, 1000)
    r68 = np.expm1(ages * LAMBDA_U238)
    r75 = np.expm1(ages * LAMBDA_U235)
    DX = max(np.log(r75))-min(np.log(r75))
    DY = max(np.log(r68))-min(np.log(r68))
    scale = DY/DX
    return scale
    
# 近似计算TW谐和图对数形式下的X-Y轴的比例，用于归一化
def TeraWasserburgScale(age_min, age_max, la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5 ):
    ages = np.linspace(age_min, age_max, 1000)
    r76 = 1.0/U8U5 * np.expm1(la_u235 * ages) / np.expm1(la_u238 * ages)
    r86 = 1.0/np.expm1(ages * la_u238)
    DX = max(np.log(r86))-min(np.log(r86))
    DY = max(np.log(r76))-min(np.log(r76))
    scale = DY/DX
    return scale
    

def Discordance(a68, a75, a76,  r68=None, r75=None, r76=None, 
                la_u235=LAMBDA_U235, la_u238=LAMBDA_U238, u8u5=U8U5, 
                threshold = AGE_THRESHOLD, calcu = 'relative'):
    a68_n = unumpy.nominal_values(a68)
    a76_n = unumpy.nominal_values(a76)
    a75_n = unumpy.nominal_values(a75)
    discPercentage = np.empty_like(a68_n, dtype=float)
    down = a76_n < threshold
    up = a76_n >= threshold
    # 最终年龄
    finalAge = a68.copy()
    finalAge[up] = a76[up].copy()
    # 计算常规相对谐和度
    if calcu == 'relative':
            discPercentage[up] = np.abs(1- a68_n[up]/a76_n[up])*100
            discPercentage[down] = np.abs(1- a75_n[down]/a68_n[down])*100
    # 计算log空间下的谐和图上的 Aitchison 距离
    if calcu == 'aitchison':
        # acorrding to Pieter Vermeesch's IsoplotR (2021) 
        if all(x is not None for x in [r68, r75, r76]):
            r68_n = unumpy.nominal_values(r68)
            r86_n = 1.0/r68_n
            r76_n = unumpy.nominal_values(r76)
            r75_n = unumpy.nominal_values(r75)
            # 计算谐和图坐标尺度因子
            scale_76_86 = TeraWasserburgScale(threshold, 4500.)
            scale_68_75 = WetherillScale(10., threshold)
            # 坐标点
            r86_76_n = np.empty_like(r86_n, dtype=float)
            r76_68_n = np.empty_like(r76_n, dtype=float)
            r68_75_n = np.empty_like(r68_n, dtype=float)
            r75_68_n = np.empty_like(r75_n, dtype=float)
            #按照threshold划分区域计算坐标点
            r86_76_n[up] = 1.0/unumpy.expm1(a76_n[up] * la_u238)
            r76_68_n[up] = (1.0/u8u5) * (unumpy.expm1(la_u235 * a68_n[up]) / unumpy.expm1(la_u238 * a68_n[up]))
            r68_75_n[down] = unumpy.expm1(a75_n[down] * la_u238)
            r75_68_n[down] = unumpy.expm1(a68_n[down] * la_u235)
            # 计算距离
            dx86 = np.empty_like(r86_n, dtype=float)
            dy76 = np.empty_like(r76_n, dtype=float)
            dy68 = np.empty_like(r68_n, dtype=float)
            dx75 = np.empty_like(r75_n, dtype=float)
            # 进行归一化处理，垂直距离为1的情况下等腰三角形的斜边sqrt(2)
            dx86[up] = np.abs(np.log(r86_n[up])-np.log(r86_76_n[up]))/np.sqrt(2)
            dy76[up] = np.abs(np.log(r76_n[up])-np.log(r76_68_n[up])) * scale_76_86 / np.sqrt(2) # x轴的长度是y轴的1.21倍,
            discPercentage[up] = dx86[up]* np.sin(np.atan(dy76[up]/dx86[up]))*100
            # 
            dx75[down] = np.abs(np.log(r75_n[down])-np.log(r75_68_n[down]))/np.sqrt(2) 
            dy68[down] = np.abs(np.log(r68_n[down])-np.log(r68_75_n[down])) * scale_68_75 / np.sqrt(2) 
            discPercentage[down] = dy68[down]* np.sin(np.atan(dy68[down]/dx75[down]))*100       
        else:
            raise ValueError('Ratios are needed for calculate the discordance!')
    return discPercentage, finalAge

# 画每个spot的最终年龄结果分布
def AgeDistPlot(datetimes, a_rBsegAvg, discPercentage, spots, 
                discThreshold=0., outer=[], ylabel ='$^{206}$Pb/$^{238}$U',figsize = (20,4)):
    '''
    Plot age distribution of all the spots in time series.
    ARGUMENT:
    datetimes: 1D numpy array. Absolute datetimes of all the spots
    a_rBsegAvg: 1D unumpy uarray. age or ratios of all the spots.
    spots: 1D numpy array. names of all the spots 
    outer: list. Index of the spots that will be highlight in plot by red color
    title: figure title string
    '''
    fig, ax = plt.subplots( figsize =figsize)
    # 分离数值和不确定度
    values = unumpy.nominal_values(a_rBsegAvg)
    uncertainties = unumpy.std_devs(a_rBsegAvg)
    # 画每个spot的比值或年龄
    sc = ax.scatter(datetimes, values, c=discPercentage, cmap='plasma', marker='s',s=30, edgecolor='None', zorder=2)
    # (x, y, yerr=y_err, fmt='none', ecolor='gray', alpha=0.7, capsize=3, zorder=1)
    ax.errorbar(datetimes, values, uncertainties, ecolor = 'k', fmt='None',zorder=1)
    if len(outer) != 0:
        ax.errorbar(datetimes[outer], values[outer], uncertainties[outer], 
                    color = 'grey', marker='s',markersize =5, linestyle='None',zorder=3)
    # 标注样品号
    if discThreshold == 0.:
        for i in range(0,len(spots)):
            if i % 2 == 0:
                ax.annotate(text=spots[i],xy=(datetimes[i], values[i]), 
                                xytext=(-15,0),textcoords='offset pixels', rotation=90)
            else:
                ax.annotate(text=spots[i],xy=(datetimes[i], values[i]), 
                                xytext=(5,0),textcoords='offset pixels', rotation=90)
    else:
        mask = discPercentage > discThreshold
        for i in np.where(mask)[0]:
            if i % 2 == 0:
                ax.annotate(text=spots[i], xy=(datetimes[i], values[i]), xytext=(-15,0),textcoords='offset pixels', rotation=90)
            else:
                ax.annotate(text=spots[i],xy=(datetimes[i], values[i]), xytext=(5,0),textcoords='offset pixels', rotation=90)
    # 配置colorbar
    cbar_ax = fig.add_axes([0.14, 0.82, 0.1, 0.02])  # [left, bottom, width, height]
    cbar = fig.colorbar(sc, cax=cbar_ax, orientation='horizontal')
    cbar.set_label('Discordance (%)')
    cbar.locator = MaxNLocator(nbins=6)  # Set the number of ticks
    cbar.update_ticks()  # Update the ticks to apply the changes
    
    ax.xaxis.set_label_text('Time Series')
    ax.yaxis.set_label_text(ylabel + ' Age (Ma)') # or 'Ratio'
    # ax.set_title(title)
    plt.show()







