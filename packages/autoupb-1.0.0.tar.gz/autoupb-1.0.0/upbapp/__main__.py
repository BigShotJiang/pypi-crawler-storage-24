## 用于自动处理LA-ICP-MS的U-Pb同位素数据 - 主程序
import sys
import os
import configparser
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QCoreApplication

# 设置中文字体支持
QCoreApplication.setApplicationName("AutoUPb")

# 导入MVC组件
from upbapp.models.data_processor import DataProcessor
from upbapp.views.main_view import MainView
from upbapp.controllers.main_controller import MainController


def load_config():
    """读取配置文件"""
    config_path = os.path.join(os.path.dirname(__file__), 'config.ini')
    if not os.path.exists(config_path):
        # 如果文件不存在，创建一个默认的
        print(f"未找到 {config_path}，将创建默认配置文件。")
        config = configparser.ConfigParser()
        config['SampleTypes'] = {
            'primary_standard_prefix': '91500',
            'secondary_standard_prefixes': 'QH, GJ-1',
            'unknown_prefixes': 'SD750'
        }
        # --- 修复：指定 UTF-8 编码写入 ---
        with open(config_path, 'w', encoding='utf-8') as configfile:
            config.write(configfile)

    # 读取文件
    config = configparser.ConfigParser()

    # --- 修复：指定 UTF-8 编码读取 ---
    try:
        config.read(config_path, encoding='utf-8')
    except Exception as e:
        print(f"读取 config.ini 时出错: {e}")
        # 尝试使用 'gbk' 作为备用
        try:
            config.read(config_path, encoding='gbk')
        except Exception as e2:
            print(f"使用 gbk 读取也失败: {e2}")
            return None  # 无法加载配置

    return config


def main():
    # 创建Qt应用程序实例
    app = QApplication(sys.argv)

    # --- 加载配置 ---
    config = load_config()
    if config is None:
        # 如果配置加载失败，可以在这里显示一个错误消息并退出
        print("错误：无法加载 config.ini 文件，程序将退出。")
        # (这里可以添加一个 QMessageBox)
        return
    # --------------------

    # 创建模型、视图和控制器
    model = DataProcessor()
    view = MainView()
    # --- 将配置传递给控制器 ---
    controller = MainController(model, view, config)

    # 设置菜单操作
    controller.setup_menu_actions()

    # 显示主窗口
    view.show()

    # 运行应用程序主循环
    sys.exit(app.exec())


if __name__ == "__main__":
    main()