## 用于自动处理LA-ICP-MS的U-Pb同位素数据 - 控制器层
from PyQt6.QtCore import QObject, pyqtSlot
from PyQt6.QtWidgets import QMenu, QApplication
from PyQt6.QtGui import QAction
import os
import numpy as np
from uncertainties import unumpy, ufloat
import configparser
from upbapp.views.settings_dialog import SettingsDialog
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from upbapp.models.data_processor import DataProcessor
    from upbapp.views.main_view import MainView
from upbapp.models.constants import STD  # 确保路径正确
class MainController(QObject):
    def __init__(self, model: 'DataProcessor', view: 'MainView', config):
        super().__init__()
        self.model = model
        self.view = view
        self.config = config
        self.connect_signals()

        self.ISOTOPE_MAP = {
            'Time': 0, 'Pb206': 1, 'Pb207': 2, 'Pb208': 3, 'Th232': 4, 'U238': 5
        }
        self.PLOT_ISOTOPES = ['Pb206', 'Pb207', 'Pb208', 'Th232', 'U238']
        self.CUTOFF_ISOTOPE = 'U238'
        self.BKG_PLOT_ISOTOPE = 'U238'
# 增加一个独立记忆字典，记录每个比值专属的曲线类型
        self.curve_memory = {
            '206Pb/238U': 'convex',
            '207Pb/235U': 'convex',
            '207Pb/206Pb': 'convex'
        }
        # 初始化漂移拟合结果容器
        self.drift_results = {
            '68': None,
            '75': None,
            '76': None
        }
    def update_standard_reference(self):
        """
        动态获取当前主标样的参考值，并存入 model。
        """
        # 1. 获取当前设置的标样名 (例如 '91500' 或 'GJ-1')
        primary_prefix = self.config.get('SampleTypes', 'primary_standard_prefix', fallback='91500').strip()
        
        # 2. 调用 STD 获取数值
        res = STD(primary_prefix)
        
        # 3. 防呆逻辑：如果没找到，默认回退到 91500
        if res is None:
            print(f"⚠️ 找不到标样 {primary_prefix}，回退到 91500")
            res = STD('91500')
            primary_prefix = '91500'

        # 4. 将所有数值封装进 model.std_ref 字典中
        self.model.std_ref = {
            'name': primary_prefix,
            'u8u5': res[0],
            'r68': res[1],  # 这是一个 ufloat 对象
            'r75': res[2],
            'r76': res[3],
            'age68': res[4],
            'age75': res[5],
            'age76': res[6]
        }
        print(f"🎯 全局标样参考值已更新为: {primary_prefix}")
# [新增] 最佳区间的漂移拟合结果容器
        self.drift_results_bseg = {
            '68': None,
            '75': None,
            '76': None
        }
        # 存储使用的节点数，供校正时使用
        self.drift_knots = 6

    def get_iso_index(self, name):
        return self.ISOTOPE_MAP.get(name, -1)

    def get_iso_name_list(self, names):
        return [self.ISOTOPE_MAP.get(name, -1) for name in names]

    def connect_signals(self):
        self.view.file_import_requested.connect(self.import_data)
        self.view.auto_cutoff_requested.connect(self.perform_auto_cutoff)
        self.view.interactive_cutoff_requested.connect(self.perform_interactive_cutoff)
        self.view.sample_selected.connect(self.on_sample_selected)
        self.view.group_expanded.connect(self.on_group_expanded)
        self.view.group_collapsed.connect(self.on_group_collapsed)
        self.view.btn_calc_bkg.clicked.connect(self.perform_bkg_subtraction)
        self.view.btn_calc_downhole.clicked.connect(self.perform_downhole_calibration)
        if hasattr(self.view, 'bkg_isotope_selector'):
            self.view.bkg_isotope_selector.currentTextChanged.connect(self.on_bkg_isotope_changed)

        # 1. 当切换 68/75 预览时，触发“回忆”逻辑
        if hasattr(self.view, 'downhole_ratio_selector'):
            self.view.downhole_ratio_selector.currentTextChanged.connect(self.on_ratio_changed)

        # 2. 当修改当前曲线类型时，触发“保存记忆”逻辑
        if hasattr(self.view, 'combo_curve_type'):
            self.view.combo_curve_type.currentTextChanged.connect(self.on_curve_changed)
            
        # 当点击刷新按钮时，重新拟合和画图
        #if hasattr(self.view, 'btn_refit_dh'):
            #self.view.btn_refit_dh.clicked.connect(self.update_downhole_calibration)

        if hasattr(self.view, 'btn_next_step'):
            self.view.btn_next_step.clicked.connect(self.on_apply_downhole_settings)

        if hasattr(self.view, 'drift_ratio_selector'):
            self.view.drift_ratio_selector.currentTextChanged.connect(self.update_drift_plot)

        # [新增] 连接交互式组件
        if hasattr(self.view, 'interactive_cutoff'):
            self.view.interactive_cutoff.cutoff_changed.connect(self.on_interactive_cutoff_changed)

        # 连接 Apply Calibration 按钮
        if hasattr(self.view, 'btn_apply_drift'):
            self.view.btn_apply_drift.clicked.connect(self.perform_drift_calibration)
        # 连接 Next -> Concordia 按钮
        if hasattr(self.view, 'btn_next_concordia'):
            self.view.btn_next_concordia.clicked.connect(self.calculate_concordia_data)

        # [连接新按钮] 只计算最佳区间
        if hasattr(self.view, 'btn_best_segment'):
            self.view.btn_best_segment.clicked.connect(self.run_best_segment_only)
            
        #最优区间    
        # [新增绑定]
        if hasattr(self.view, 'btn_drift_fit_bseg'):
            self.view.btn_drift_fit_bseg.clicked.connect(self.perform_drift_fitting_bseg)
            
        if hasattr(self.view, 'btn_apply_cali_bseg'):
            self.view.btn_apply_cali_bseg.clicked.connect(self.perform_drift_calibration_bseg)
        # [新增] 连接模式切换信号
        if hasattr(self.view, 'drift_mode_selector'):
            self.view.drift_mode_selector.currentTextChanged.connect(self.update_drift_plot)
            
        # === 谐和图部分 ===
        # 连接绘图按钮
        if hasattr(self.view, 'btn_draw_concordia'):
            self.view.btn_draw_concordia.clicked.connect(self.calculate_concordia_data)
        
        # (可选) 如果希望下拉框改变时自动刷新，也可以解开下面的注释
        if hasattr(self.view, 'combo_concordia_mode'):
            self.view.combo_concordia_mode.currentTextChanged.connect(self.calculate_concordia_data)
        if hasattr(self.view, 'combo_concordia_type'):
            self.view.combo_concordia_type.currentTextChanged.connect(self.calculate_concordia_data)
        # 连接 Scatter 页面的两个下拉框
        if hasattr(self.view, 'age_dist_selector'):
            self.view.age_dist_selector.currentTextChanged.connect(self.update_age_dist_plot)
            
        # [新增] 连接 Filter 下拉框
        if hasattr(self.view, 'scatter_filter_selector'):
            self.view.scatter_filter_selector.currentTextChanged.connect(self.update_age_dist_plot)
        # === 【新增】：连接 View 层发来的“剔除/恢复”信号 ===
        if hasattr(self.view, 'sample_toggled_signal'):
            self.view.sample_toggled_signal.connect(self.toggle_sample_validity)

    from PyQt6.QtCore import pyqtSlot
    import numpy as np

    @pyqtSlot(str)  
    def toggle_sample_validity(self, sample_name):
        """
        处理剔除请求，现在通过样品名来精确定位。
        """
        if not hasattr(self.model, 'is_valid') or self.model.is_valid is None:
            print("❌ 错误：is_valid 掩码不存在！")
            return

        # 1. 在模型的数据列表里，找到这个名字对应的索引位置
        spots_list = list(self.model.spots)
        if sample_name not in spots_list:
            print(f"❌ 错误：在模型中找不到样品 [{sample_name}]")
            return
            
        sample_index = spots_list.index(sample_name)

        # 2. 翻转状态
        new_status = not self.model.is_valid[sample_index]
        self.model.is_valid[sample_index] = new_status

        # 3. 通知 View 更新视觉
        if hasattr(self.view, 'update_sample_visual'):
            self.view.update_sample_visual(sample_name, new_status)

        # 4. 打印和提示
        status_str = " (Valid)" if new_status else " (Excluded)"
        print(f"🛠️ 数据点 [{sample_name}] (索引:{sample_index}) 状态更新为: {status_str}")

        if not new_status:
            self.view.show_message(
                "状态更新", 
                f"已剔除点位: {sample_name}\n\n请重新执行 'Drift Fit' 以生成不包含此点的校正曲线。", 
                "info"
            )
    @pyqtSlot(str)
    def on_bkg_isotope_changed(self, isotope_name):
        if not isotope_name:
            return

        self.BKG_PLOT_ISOTOPE = isotope_name

        if self.model.bkg_fits is not None:
            idx = self.get_iso_index(isotope_name)
            if idx != -1:
                iso_names_list = list(self.ISOTOPE_MAP.keys())
                self.view.plot_to_view(
                    'bkg_subtraction',
                    (self.model.bkg_plot,),
                    self.model.time_bkg_abs,
                    self.model.signals_bkg,
                    self.model.spots,
                    self.model.bkg_fits,
                    self.model.bkg_fits_conf95,
                    iso_names_list,
                    idx
                )

    @pyqtSlot(str)
    def import_data(self, folder_path=None):
        if not folder_path:
            folder_path = self.view.show_directory_dialog("Select Data Folder")

        if not folder_path:
            return

        try:
            if hasattr(self.model, 'reset'):
                self.model.reset()
            s_row_from = self.config.getint('Data', 'signal_row_from', fallback=4)
            default_dt_pattern = r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}'

            sample_config = {
                'primary': self.config.get('SampleTypes', 'primary_standard_prefix', fallback='91500').strip(),
                'secondary': [s.strip() for s in
                              self.config.get('SampleTypes', 'secondary_standard_prefixes', fallback='').split(',') if
                              s.strip()],
                'unknowns': [u.strip() for u in
                             self.config.get('SampleTypes', 'unknown_prefixes', fallback='SD750').split(',') if
                             u.strip()]
            }

            signals, spots, datetimes, columns = self.model.read_files(
                folder_path,
                signal_row_from=s_row_from,
                datetime_pattern=default_dt_pattern,
                datetime_format='%Y-%m-%d %H:%M:%S',
                sample_config=sample_config
            )

            if signals is not None:
                print(f"Data Loaded. Columns detected: {columns}")
                # === 【新增 2：初始化所有样品的“通行证”(掩码)】 ===
                import numpy as np
                self.model.is_valid = np.ones(len(spots), dtype=bool)
                # =================================================

                # === 【新增 3：同步更新标样数值，确保用的是最新配置】 ===
                if hasattr(self, 'update_standard_reference'):
                    self.update_standard_reference()
                # =================================================
                if hasattr(self.view, 'bkg_isotope_selector'):
                    self.view.bkg_isotope_selector.blockSignals(True)
                    self.view.bkg_isotope_selector.clear()
                    iso_list = [col for col in columns if col != 'Time']
                    self.view.bkg_isotope_selector.addItems(iso_list)

                    default_idx = self.view.bkg_isotope_selector.findText('U238')
                    if default_idx != -1:
                        self.view.bkg_isotope_selector.setCurrentIndex(default_idx)
                    self.view.bkg_isotope_selector.blockSignals(False)

                self.ISOTOPE_MAP = {name: i for i, name in enumerate(columns)}
                self.PLOT_ISOTOPES = [col for col in columns if 'Time' not in col]

                if self.model.sample_types is not None:
                    self.view.update_sample_list(self.model.spots, self.model.sample_types)
                else:
                    self.view.update_sample_list(self.model.spots, [])

                self.view.show_message("Success", f"Successfully imported {len(spots)} samples")
            else:
                self.view.show_message("Warning", "No valid data found", "warning")

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"An error occurred while importing data: {str(e)}", "error")

    @pyqtSlot()
    def perform_auto_cutoff(self):
        try:
            if self.model.signals is None or self.model.spots is None:
                self.view.show_message("Warning", "Please import data first", "warning")
                return

            idx = self.get_iso_index(self.CUTOFF_ISOTOPE)
            if idx == -1:
                self.view.show_message("Error", f"Isotope not found: {self.CUTOFF_ISOTOPE}", "error")
                return

            cutoffs_list, cutoff_spots_list = self.model.auto_cutoff(
                signals=self.model.signals,
                spots=self.model.spots,
                isotope=idx
            )
            self.view.show_message("Success", f"Global cutoff calculation completed: {cutoffs_list}")

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"An error occurred during automatic processing: {str(e)}", "error")

    @pyqtSlot()
    def perform_bkg_subtraction(self):
        try:
            # 1. 防呆：如果没有 Cutoff (不管是自动还是手动的)，拒绝执行
            if self.model.cutoffs is None or len(self.model.cutoffs) < 3:
                self.view.show_message("Wait", "Please set Cutoffs (Auto or Manual) first.", "warning")
                return

            print("开始计算并扣除背景...")
            self.model.bkg_substract(
                datetimes=self.model.datetimes,
                signals=self.model.signals,
                cutoffs=self.model.cutoffs,
                dof=4
            )

            idx = self.get_iso_index(self.BKG_PLOT_ISOTOPE)
            if idx == -1: idx = 1
            iso_names_list = list(self.ISOTOPE_MAP.keys())

            self.view.plot_to_view(
                'bkg_subtraction',
                (self.model.bkg_plot,),
                self.model.time_bkg_abs,
                self.model.signals_bkg,
                self.model.spots,
                self.model.bkg_fits,
                self.model.bkg_fits_conf95,
                iso_names_list,
                idx
            )
            
            # 【核心修改】：删除了原有的 self.perform_downhole_calibration()
            # 把它变成一个友好的引导提示
            self.view.show_message(
                "Success", 
                "Background subtraction completed!\nPlease proceed to the 'Downhole' tab and click 'Calc & Draw Downhole'.", 
                "success"
            )

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"An error occurred during background subtraction: {str(e)}", "error")

    @pyqtSlot()
    def perform_downhole_calibration(self):
        try:
            # 1. 防呆：如果没有背景扣除后的数据，拒绝执行
            if not hasattr(self.model, 'signals_eff_bs') or self.model.signals_eff_bs is None:
                self.view.show_message("Warning", "No background data found. Please run 'Calc & Draw Bkg' first.", "warning")
                return

            if 'Pb206' not in self.ISOTOPE_MAP or 'U238' not in self.ISOTOPE_MAP:
                self.view.show_message("Error", "The key isotope (Pb206/U238) was not found. Please check data columns.", "error")
                return

            print("开始进行 Downhole 分馏计算...")
            self.model.ratio_upb(
                signals=self.model.signals_eff_bs,
                pb206=self.get_iso_index('Pb206'),
                pb207=self.get_iso_index('Pb207'),
                u238=self.get_iso_index('U238')
            )

            self.model.r68_dh = None
            self.model.r75_dh = None
            self.model.r76_dh = None

            self.view.downhole_ratio_selector.setCurrentText('206Pb/238U')
            
            # 这里保留你原来的画图/拟合逻辑
            self.update_downhole_calibration()

            self.view.show_message(
                "Success",
                "Downhole data calculated and plotted.\nPlease verify the curve type, then click 'Next -> Drift'.",
                "success"
            )

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"Failed to calculate Downhole data: {str(e)}", "error")

    @pyqtSlot()
    def on_apply_downhole_settings(self):
        try:
            if self.model.r68 is None:
                self.view.show_message("Warning", "No ratio data available. Please execute previous steps first.", "warning")
                return

            curve_68 = self.view.combo_curve_68.currentText() if hasattr(self.view, 'combo_curve_68') else 'convex'
            curve_75 = self.view.combo_curve_75.currentText() if hasattr(self.view, 'combo_curve_75') else 'convex'

            primary_prefix = self.config.get('SampleTypes', 'primary_standard_prefix', fallback='91500').strip().upper()
            primary_std_name = f'Standard ({primary_prefix})'

            print(f"Applying Downhole Settings: 68={curve_68}, 75={curve_75}")

            try:
                r68_stack = self.model.ratio_stack(self.model.r68, primary_std_name)
                _, params_68, _, _ = self.model.downhole_fit(self.model.time_eff, r68_stack, curve=curve_68)
                self.model.r68_dh = self.model.apply_downhole_calibration(self.model.time_eff, params_68,
                                                                          self.model.r68)
                self.model.downhole_fit_68_params = params_68
            except Exception as e:
                print(f"Failed to calibrate r68: {e}")
                self.view.show_message("Error", f"206Pb/238U calibration failed: {e}", "error")
                return

            try:
                r75_stack = self.model.ratio_stack(self.model.r75, primary_std_name)
                _, params_75, _, _ = self.model.downhole_fit(self.model.time_eff, r75_stack, curve=curve_75)
                self.model.r75_dh = self.model.apply_downhole_calibration(self.model.time_eff, params_75,
                                                                          self.model.r75)
                self.model.downhole_fit_75_params = params_75
            except Exception as e:
                print(f"Failed to calibrate r75: {e}")
                self.view.show_message("Error", f"207Pb/235U calibration failed: {e}", "error")
                return
 
            if self.model.r68_dh is not None and self.model.r75_dh is not None:
                # 1. 确保中央大脑已初始化
                if not hasattr(self.model, 'std_ref') or self.model.std_ref is None:
                    self.update_standard_reference()
                
                # 2. 从 model 动态获取当前标样的 U8/U5 比值
                U8U5 = self.model.std_ref['u8u5']
                self.model.r76_dh = (self.model.r75_dh / self.model.r68_dh) * (1.0 / U8U5)
                print("Calculated r76_dh successfully.")

            self.view.show_message("Success", "Downhole settings applied!\nStarting drift calibration...")

            self.perform_drift_fitting()

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"Error applying settings: {str(e)}", "error")

    @pyqtSlot(str)
    def on_ratio_changed(self, selected_ratio):
        """当用户切换预览图 (比如从 68 切到 75) 时触发"""
        # 1. 从记忆字典里，把 75 专属的曲线类型拿出来
        saved_curve = self.curve_memory.get(selected_ratio, 'convex')
        
        # 2. 悄悄把界面上的下拉框变成记忆里的值！
        # 极其重要：必须用 blockSignals 堵住信号，否则界面改变会无限死循环触发拟合
        if hasattr(self.view, 'combo_curve_type'):
            self.view.combo_curve_type.blockSignals(True)
            self.view.combo_curve_type.setCurrentText(saved_curve)
            self.view.combo_curve_type.blockSignals(False)
            
        # 3. 带着正确的参数去重新画图
        self.update_downhole_calibration()

    @pyqtSlot(str)
    def on_curve_changed(self, selected_curve):
        """当用户手动修改下拉框 (比如把 68 的 convex 改成 concave) 时触发"""
        # 1. 知道当前在改哪个比值
        current_ratio = self.view.downhole_ratio_selector.currentText()
        
        # 2. 把新设置存入记忆字典，永久保留！
        self.curve_memory[current_ratio] = selected_curve
        
        # 3. 带着新参数去重新画图
        self.update_downhole_calibration()
    @pyqtSlot()
    def update_downhole_calibration(self):
        try:
            if getattr(self.model, 'r68', None) is None:
                return

            # 1. 知道用户现在正在看哪张图
            selected_ratio = self.view.downhole_ratio_selector.currentText()
            
            selected_curve = self.curve_memory.get(selected_ratio, 'convex')

            # 3. 仅仅根据比值，分配对应的数据
            if '206Pb/238U' in selected_ratio:
                ratio_data = self.model.r68
                ylabel = '206Pb/238U Ratio'
            elif '207Pb/235U' in selected_ratio:
                ratio_data = self.model.r75
                ylabel = '207Pb/235U Ratio'
            elif '207Pb/206Pb' in selected_ratio:
                ratio_data = self.model.r76
                ylabel = '207Pb/206Pb Ratio'
            else:
                return

            if ratio_data is None: return

            # ---- 以下代码完全保留你的原汁原味逻辑 ----
            primary_prefix = self.config.get('SampleTypes', 'primary_standard_prefix', fallback='').strip().upper()
            primary_std_name = f'Standard ({primary_prefix})'

            try:
                ratio_stacked_std = self.model.ratio_stack(ratio=ratio_data, standard_name=primary_std_name)
            except ValueError as ve:
                print(f"Preview warning: {ve}")
                return

            (fit_curve, fit_params, fit_ci, fit_resid) = self.model.downhole_fit(
                timeEff=self.model.time_eff,
                ratioStack=ratio_stacked_std,
                curve=selected_curve
            )

            a_val = fit_params.get('a', 0)
            b_val = fit_params.get('b', 0)
            c_val = fit_params.get('c', 0)
            params_text = f"a={a_val:.4f}, b={b_val:.4f}, c={c_val:.4f}"
            if hasattr(self.view, 'downhole_params_label'):
                self.view.downhole_params_label.setText(f"Params: {params_text}")

            self.view.plot_figure_to_view(
                'downhole_calib',
                (self.model.downhole_plot_combined,),
                self.model.time_eff,
                ratio_stacked_std,
                fit_curve,
                fit_ci,
                fit_resid,
                ylabel,
                f'{selected_ratio}'
            )
        except Exception as e:
            print(f"Error updating downhole plot: {e}")
    def calculate_spot_stats(self, data_2d):
        try:
            means = np.nanmean(data_2d, axis=0)
            stds = np.nanstd(data_2d, axis=0)
            counts = np.sum(~np.isnan(data_2d), axis=0)
            sems = stds / np.sqrt(np.maximum(1, counts))
            return unumpy.uarray(means, sems)
        except Exception as e:
            print(f"Error calculating stats: {e}")
            return None

    @pyqtSlot()
    def perform_drift_fitting(self):
        try:
            if self.model.r68_dh is None:
                self.view.show_message("Warning", "Please apply the correction in the Downhole interface by clicking 'Next -> Drift' first.", "warning")
                return

            print("Starting Drift Fitting (Mode: Full Segment)...")

            # 1. 获取标样索引
            primary_prefix = self.config.get('SampleTypes', 'primary_standard_prefix', fallback='91500').strip()
            std_name = f'Standard ({primary_prefix.upper()})'
            is_std = (self.model.sample_types == std_name) & self.model.is_valid
            
            # 2. 获取标样的时间和原始数据 (2D)
            Ktime = self.model.datetimes[is_std]
            Kspots = self.model.spots[is_std]

            # [关键] 直接获取切片后的 2D 原始数据 (Time x Spots)
            # 不要在这里调用 calculate_spot_stats 或 weighted_average
            r68_raw = self.model.r68_dh[:, is_std]
            r75_raw = self.model.r75_dh[:, is_std]
            r76_raw = self.model.r76_dh[:, is_std]

            # 3. 设置节点数
            n_std_found = np.sum(is_std)
            if n_std_found >= 6:
                n_knots = 6
            else:
                n_knots = max(3, int(n_std_found / 1.5))
            self.drift_knots = n_knots

            # 4. 执行拟合 (直接传入 2D 原始数据 r68_raw)
            # r68
            res68 = self.model.drift_fit(Ktime, r68_raw, n_knots=n_knots)
            if res68 and res68[0] is not None:
                # 存储结果: (Model, Curve, Conf, X_avg, Y_avg, Ktime, Kspots, RawData)
                # 注意：res68 包含了前5个，我们补上后3个用于绘图
                self.drift_results['68'] = (*res68, Ktime, Kspots, r68_raw)
            else:
                print("Drift fit failed for 68")

            # r75
            res75 = self.model.drift_fit(Ktime, r75_raw, n_knots=n_knots)
            if res75 and res75[0] is not None:
                self.drift_results['75'] = (*res75, Ktime, Kspots, r75_raw)

            # r76
            res76 = self.model.drift_fit(Ktime, r76_raw, n_knots=n_knots)
            if res76 and res76[0] is not None:
                self.drift_results['76'] = (*res76, Ktime, Kspots, r76_raw)

            # 5. 更新界面
            if self.drift_results['68']:
                if hasattr(self.view, 'drift_ratio_selector'):
                    self.view.drift_ratio_selector.setCurrentText('206Pb/238U')
                self.update_drift_plot()
                self.view.show_message("Success", f"Drift fitting completed (n_knots={n_knots})!")
            else:
                self.view.show_message("Warning", "Fitting failed.", "warning")

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"Drift fitting failed: {str(e)}", "error")
    @pyqtSlot()
    def perform_drift_calibration(self):
        """
        [常规流程] 执行漂移校正 (Apply Calibration)
        应用 drift_fit 计算出的样条曲线对所有样品进行校正。
        """
        try:
            # 1. 检查是否已完成拟合
            if not self.drift_results['68']:
                self.view.show_message("Warning", "Please run Drift Fit successfully first.", "warning")
                return

            print("Starting Drift Calibration (Full Segment)...")

            # 2. 获取标样参考值 (Standard Reference Values)
            
            # 检查中央大脑是否已经有标样数据，如果没有，立刻强制更新一次
            if not hasattr(self.model, 'std_ref') or self.model.std_ref is None:
                print("Model.std_ref is missing. Initializing standard reference...")
                self.update_standard_reference()

            
            std_ref_values = {
                'r68': self.model.std_ref['r68'],
                'r75': self.model.std_ref['r75'],
                'r76': self.model.std_ref['r76']
            }
            
            current_std_name = self.model.std_ref['name']
            print(f"Applying Drift Calibration using reference values of [{current_std_name}]")
    

            # 3. 执行校正 (调用 model.drift_cali)
            # 注意：这里的输入 r68_dh 现在是带误差的 uarray，drift_cali 会正确传播误差
            
            # --- Calibrate 206Pb/238U (68) ---
            dc_fit_model_68 = self.drift_results['68'][0] # 获取拟合模型对象
            self.model.r68_dh_dc = self.model.drift_cali(
                dc_fit_model_68,
                self.model.datetimes,
                self.model.time_eff,
                self.model.r68_dh,
                std_ref_values['r68'],
                n_knots=self.drift_knots
            )

            # --- Calibrate 207Pb/235U (75) ---
            dc_fit_model_75 = self.drift_results['75'][0]
            self.model.r75_dh_dc = self.model.drift_cali(
                dc_fit_model_75,
                self.model.datetimes,
                self.model.time_eff,
                self.model.r75_dh,
                std_ref_values['r75'],
                n_knots=self.drift_knots
            )

            # --- Calibrate 207Pb/206Pb (76) ---
            dc_fit_model_76 = self.drift_results['76'][0]
            self.model.r76_dh_dc = self.model.drift_cali(
                dc_fit_model_76,
                self.model.datetimes,
                self.model.time_eff,
                self.model.r76_dh,
                std_ref_values['r76'],
                n_knots=self.drift_knots
            )

            # 4. 完成反馈
            self.view.show_message("Success", "Drift correction completed!\nData updated. Please click 'Next -> Concordia' to view the results.")
            print("Drift Calibration Finished.")

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"Drift correction failed: {str(e)}", "error")

# [新增方法] 最佳区间计算
   # ... (保留前面的 import 和 init)

    # ----------------------------------------------------------------------
    # 1. 修正 Best Segment 计算逻辑 (解决结果不一致问题)
    # ----------------------------------------------------------------------
    @pyqtSlot()
    def run_best_segment_only(self):
        """
        [终极稳定版] 分组合并策略：
        完美复刻 Jupyter 中针对不同样品分批运行的逻辑，避免底层数学库崩溃。
        """
        if self.model.r68_dh is None:
            self.view.show_message("Error", "Downhole data is missing. Calculation cannot proceed.", "error")
            return

        self.view.show_message("Running", "Running Best Segment analysis in grouped batch mode...", "info")
        
        try:
            import numpy as np
            
            # =======================================================
            # 1. 准备搜索数据 (维持不变)
            # =======================================================
            r68_search = self.model.r68_dh_dc
            r75_search = self.model.r75_dh_dc
            r76_search = self.model.r76_dh_dc

            # 如果没有现成的搜索数据，进行临时校正计算
            if r68_search is None:
                print("未找到现成的校正数据，尝试基于当前标样进行临时计算...")
                
                # 1. 确保中央大脑 (std_ref) 已就绪
                if not hasattr(self.model, 'std_ref') or self.model.std_ref is None:
                    self.update_standard_reference()
                
                # 2. 直接从中央大脑拿数值 (.n 取 float 部分)
                std_ref_values = {
                    'r68': self.model.std_ref['r68'].n,
                    'r75': self.model.std_ref['r75'].n,
                    'r76': self.model.std_ref['r76'].n
                }
                
                # 3. 获取当前标样的名字，用于后续的样品类型过滤 (is_std)
                current_p_name = self.model.std_ref['name'].upper()
                
                # 动态识别标样点
                # 逻辑：如果样品类型里包含当前主标样的名字，就认为是标样
                is_std = np.array([current_p_name in str(s).upper() for s in self.model.sample_types])
                
                if not any(is_std):
                    print(f"⚠️ Warning: No samples found matching primary standard [{current_p_name}]")
                    # 这里可以抛个异常或者做保底处理
                
                Ktime = self.model.datetimes[is_std]

                # ... 后面的 quick_cali 逻辑保持不变 ...

                def quick_cali(r_dh, r_std, ref):
                    fit = self.model.drift_fit(Ktime, r_std, n_knots=self.drift_knots)
                    if fit and fit[0]:
                        return self.model.drift_cali(fit[0], self.model.datetimes, self.model.time_eff, r_dh, ref, self.drift_knots)
                    return r_dh

                r68_search = quick_cali(self.model.r68_dh, self.model.r68_dh[:, is_std], std_ref_values['r68'])
                r75_search = quick_cali(self.model.r75_dh, self.model.r75_dh[:, is_std], std_ref_values['r75'])
                r76_search = quick_cali(self.model.r76_dh, self.model.r76_dh[:, is_std], std_ref_values['r76'])

            # =======================================================
            # 2. 对样品进行“兵分三路”的分组
            # =======================================================
            bseg_widths = getattr(self.model, 'bseg_widths', [15, 15, 15]) 
            num_samples = len(self.model.sample_types)
            
            p_prefix = self.config.get('SampleTypes', 'primary_standard_prefix', fallback='').strip().upper()
            s_prefix = self.config.get('SampleTypes', 'secondary_standard_prefix', fallback='').strip().upper()
            
            idx_std, idx_ref, idx_unk = [], [], []
            for i, s_name in enumerate(self.model.sample_types):
                s_name_upper = str(s_name).upper()
                if p_prefix and p_prefix in s_name_upper: idx_std.append(i)
                elif s_prefix and s_prefix in s_name_upper: idx_ref.append(i)
                else: idx_unk.append(i)
                    
            # 定义执行队列：(组名, 属于该组的样品索引, 该组对应的最小宽度)
            run_queue = [
                ("Primary Standard", idx_std, bseg_widths[0]),
                ("Secondary Reference", idx_ref, bseg_widths[1]),
                ("Unknown Samples", idx_unk, bseg_widths[2])
            ]

            # =======================================================
            # 3. 循环三遍：执行计算并“摘取果实”拼合
            # =======================================================
            time_steps = self.model.r68_dh.shape[0]
            # 最终的拼图底板
            final_C_Bseg = np.zeros((time_steps, num_samples))
            final_id_Bseg = np.zeros(num_samples, dtype=int)
            results_ends = []
            max_n_seg = 0
            
            target_signals = self.model.signals_eff

            for group_name, indices, min_w in run_queue:
                if not indices: continue # 某组没样品就跳过
                    
                print(f"-> 正在计算 {group_name} (共 {len(indices)} 个), 门槛: {min_w}s")
                
                # 让底层毫无负担地跑一次完整计算
                C3d_full, ends3d_full = self.model.CoeffMatrix(minwidth=min_w, signals=target_signals)
                
                if self.model.has_cupy:
                    C_B_full, id_B_full = self.model.BestSegmentGPU(
                        C3d_full, r68_search, r75_search, r76_search,
                        threshold=self.model.AGE_THRESHOLD, la_u238=self.model.LAMBDA_U238
                    )
                else:
                    C_B_full, id_B_full = self.model.BestSegment(
                        C3d_full, r68_search, r75_search, r76_search,
                        threshold=self.model.AGE_THRESHOLD, la_u238=self.model.LAMBDA_U238
                    )
                    
                # 【核心缝合逻辑】只把属于这个组的样品结果，贴到最终底板上！
                for idx in indices:
                    final_C_Bseg[:, idx] = C_B_full[:, idx]
                    final_id_Bseg[idx] = id_B_full[idx]
                    
                results_ends.append((indices, ends3d_full))
                if ends3d_full.shape[0] > max_n_seg:
                    max_n_seg = ends3d_full.shape[0]

            # 缝合 ends3d 记录 (补齐长度以便 Spreadsheet 统一读取)
            final_ends_Bseg = np.zeros((max_n_seg, 2, num_samples))
            for indices, ends3d_full in results_ends:
                n_seg = ends3d_full.shape[0]
                for idx in indices:
                    final_ends_Bseg[:n_seg, :, idx] = ends3d_full[:, :, idx]

            # 存入模型
            self.model.C_Bseg = final_C_Bseg
            self.model.id_Bseg = final_id_Bseg
            self.model.ends_Bseg = final_ends_Bseg

            # =======================================================
            # 4. 容错警告与遮罩应用
            # =======================================================
            # 检查是否有全军覆没的样品（C_Bseg 整列都是 0）
            failed_idx = np.where(np.sum(final_C_Bseg, axis=0) == 0)[0]
            if len(failed_idx) > 0:
                failed_names = [self.model.sample_types[i] for i in failed_idx]
                msg = f"注意：有 {len(failed_idx)} 个样品无法找到长度达到门槛的最佳区间！\n它们将被剔除为 NaN。\n涉及样品: {', '.join(map(str, failed_names[:5]))} ..."
                print(msg)
                if hasattr(self.view, 'show_message'):
                    self.view.show_message("Threshold Warning", msg, "warning")

            print("Step 3: Masking raw data...")
            mask = final_C_Bseg.copy().astype(float)
            mask[mask == 0] = np.nan
            
            self.model.r68_dh_bseg = self.model.r68_dh * mask
            self.model.r75_dh_bseg = self.model.r75_dh * mask
            self.model.r76_dh_bseg = self.model.r76_dh * mask

            print(f"✅ Bseg Data Prepared. Shape: {self.model.r68_dh_bseg.shape}")
            self.view.show_message(
                "Success",
                "Grouped Optimal interval selection completed!\nPlease click 'Drift Fit (Best Seg)' to apply.",
                "info"
            )

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"Calculation failed: {str(e)}", "error")
    # ----------------------------------------------------------------------
    # 2. 修正 Drift 绘图 (解决闪退问题)
    # ----------------------------------------------------------------------
    @pyqtSlot(str)
    def update_drift_plot(self, text=None):
        if not hasattr(self.view, 'drift_ratio_selector'): return
        
        # 1. 获取当前模式 (Full / Best)
        mode = 'Full Segment'
        if hasattr(self.view, 'drift_mode_selector'):
            mode = self.view.drift_mode_selector.currentText()

        # 2. 获取当前选择的同位素比值
        sel = self.view.drift_ratio_selector.currentText()
        ratio_key = '68'
        ylabel = '$^{206}$Pb/$^{238}$U'

        if '207Pb/235U' in sel:
            ratio_key = '75'
            ylabel = '$^{207}$Pb/$^{235}$U'
        elif '207Pb/206Pb' in sel:
            ratio_key = '76'
            ylabel = '$^{207}$Pb/$^{206}$Pb'
            
        # 3. 根据模式获取数据
        res = None
        if mode == 'Best Segment':
            # 检查是否有最佳区间结果
            if hasattr(self, 'drift_results_bseg') and self.drift_results_bseg.get(ratio_key) is not None:
                res = self.drift_results_bseg.get(ratio_key)
            else:
                # [关键修正] 数据缺失时的处理
                # 1. 弹出提示
                self.view.show_message("Notice", "Best-segment fitting data is not available.\nPlease run 'Run Best Segment' and 'Drift Fit (Best Seg)' first.", "warning")
                
                # 2. 定义一个清空画板的内部函数
                def clear_plot(ax):
                    ax.text(0.5, 0.5, "No Best Segment Data", 
                            ha='center', va='center', fontsize=14, color='gray')
                    ax.set_xticks([])
                    ax.set_yticks([])
                
                # 3. 强制刷新视图为空白状态
                self.view.plot_to_view('drift_calib', clear_plot)
                return
        else:
            # Full Segment 模式
            res = self.drift_results.get(ratio_key)
            if res is None:
                # 如果全区间也没数据（比如还没做第一步），也可以选择清空
                return

        if res is None: return

        # 4. 解包数据并绘图
        (DcFit, Curve, Conf, X_avg, Y_avg, Ktime, Kspots, RawData) = res

                # 绘制全区间 (2D 面条线)
        self.view.plot_to_view(
            'drift_calib',
            self.model.drift_fit_plot, 
            Ktime, self.model.time_eff, RawData, Kspots, Curve, Conf, [], ylabel
                )
    # ----------------------------------------------------------------------
    # 3. 修正 谐和图逻辑 (单图 + 双下拉框智能选择)
    # ----------------------------------------------------------------------
    # upbapp/controllers/main_controller.py

    # upbapp/controllers/main_controller.py

    @pyqtSlot()
    def calculate_concordia_data(self):
        try:
            # 1. 下拉框初始化 (保持不变)
            if self.view.combo_concordia_type.count() < 3:
                self.view.combo_concordia_type.blockSignals(True)
                self.view.combo_concordia_type.clear()
                fixed_items = ["Standards", "References", "Unknowns"]
                self.view.combo_concordia_type.addItems(fixed_items)
                self.view.combo_concordia_type.blockSignals(False)

            # 2. 获取选项
            mode = self.view.combo_concordia_mode.currentText()
            filter_type = self.view.combo_concordia_type.currentText()

            # 3. 准备数据源 (保持不变)
            r68_source, r75_source, r76_source = None, None, None
            if mode == 'Best Segment':
                if self.model.r68_dh_bseg_dc is None:
                    self.view.show_message("Notice", "No best-segment correction data found.", "warning")
                    return
                r68_source = self.model.r68_dh_bseg_dc
                r75_source = self.model.r75_dh_bseg_dc
                r76_source = self.model.r76_dh_bseg_dc
            else:
                if self.model.r68_dh_dc is None:
                    self.view.show_message("Notice", "No full-interval correction data found.", "warning")
                    return
                r68_source = self.model.r68_dh_dc
                r75_source = self.model.r75_dh_dc
                r76_source = self.model.r76_dh_dc

            # 4. 降维 (保持不变)
            r68_avg, _ = self.model.weighted_average(r68_source, err='external')
            r75_avg, _ = self.model.weighted_average(r75_source, err='external')
            r76_avg, _ = self.model.weighted_average(r76_source, err='external')

            # 5. 筛选 (保持不变)
            mask = np.zeros(len(self.model.spots), dtype=bool)
            s_types = self.model.sample_types.astype(str)
            if filter_type == "Standards":
                mask = np.char.find(s_types, 'Standard') != -1
            elif filter_type == "References":
                mask = np.char.find(s_types, 'Reference') != -1
            elif filter_type == "Unknowns":
                mask = np.char.find(s_types, 'Unknown') != -1
            
            if not np.any(mask):
                self.view.show_message("Notice", f"No samples found for category '{filter_type}'.", "info")
                return

            r68_plot = r68_avg[mask]
            r75_plot = r75_avg[mask]
            r76_plot = r76_avg[mask]
            spots_plot = self.model.spots[mask]

            # 6. 控制统计信息显示
            # 通常：Unknowns 不显示统计，Standard/Reference 显示
            is_detrital_plot = (filter_type == "Unknowns")

            # === [关键修改] 分别绘制两种类型的图 ===

            # 提取出你要画的这批数据对应的掩码
            # 假设你通过某种条件(比如 filter_idx) 过滤出了 r68_plot
            # 那么你同样需要用这个 filter_idx 过滤出 is_valid 掩码：
            valid_mask_plot = self.model.is_valid[mask]
            # (注意：上面的 filter_idx 是你提取 r68_plot 时的索引。如果你没做过滤，直接用 self.model.is_valid 即可)

            # 左图 (concordia1): Wetherill Plot (标准图)
            self.view.plot_to_view(
                'concordia1',
                self.model.concordia_plot,
                r68_plot, r75_plot, r76_plot,
                spots_plot,
                f'Wetherill Plot ({filter_type})', 
                is_detrital=is_detrital_plot,
                is_valid_mask=valid_mask_plot  # <--- 把掩码传进去！
            )

            # 右图 (concordia2): Tera-Wasserburg Plot
            self.view.plot_to_view(
                'concordia2',
                self.model.concordia_plot_tw,
                r68_plot, r75_plot, r76_plot,
                spots_plot,
                f'Tera-Wasserburg Plot ({filter_type})', 
                is_detrital=is_detrital_plot,
                is_valid_mask=valid_mask_plot  # <--- 同理传进去！
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"Failed to plot the Concordia diagram: {str(e)}", "error")

    @pyqtSlot()
    def perform_drift_fitting_bseg(self):
        """
        [缺失找回] 最佳区间模式下的漂移拟合
        """
        try:
            # 1. 检查数据
            if self.model.r68_dh_bseg is None:
                self.view.show_message("Warning", "Please run Best Segment (Run Best Segment) first.", "warning")
                return

            print("Starting Drift Fitting (Mode: Best Segment)...")
            
            # 2. 识别标样
            primary_prefix = self.config.get('SampleTypes', 'primary_standard_prefix', fallback='91500').strip()
            std_name = f'Standard ({primary_prefix.upper()})'
            is_std = (self.model.sample_types == std_name)
            
            if np.sum(is_std) < 4:
                self.view.show_message("Error", "Not enough standard samples (<4) for fitting.", "error")
                return

            # 3. 准备数据 (提取标样的最佳区间数据)
            Ktime = self.model.datetimes[is_std]
            Kspots = self.model.spots[is_std]
            
            # 注意：r68_dh_bseg 是 2D 数组 (Time x Spots)，含 NaN
            # drift_fit 函数能自动处理含 NaN 的数据
            r68_std = self.model.r68_dh_bseg[:, is_std]
            r75_std = self.model.r75_dh_bseg[:, is_std]
            r76_std = self.model.r76_dh_bseg[:, is_std]

            # 4. 执行拟合
            n_knots = self.drift_knots 

            # 拟合 68
            res68 = self.model.drift_fit(Ktime, r68_std, n_knots=n_knots)
            if res68 and res68[1] is not None:
                # 存入结果: (Model, Curve, Conf, X_avg, Y_avg, Ktime, Kspots, RawData)
                self.drift_results_bseg['68'] = (*res68, Ktime, Kspots, r68_std)

            # 拟合 75
            res75 = self.model.drift_fit(Ktime, r75_std, n_knots=n_knots)
            if res75 and res75[1] is not None:
                self.drift_results_bseg['75'] = (*res75, Ktime, Kspots, r75_std)
                
            # 拟合 76
            res76 = self.model.drift_fit(Ktime, r76_std, n_knots=n_knots)
            if res76 and res76[1] is not None:
                self.drift_results_bseg['76'] = (*res76, Ktime, Kspots, r76_std)

            self.view.show_message("Success", "Best-segment drift fitting completed!")
            self.update_drift_plot()

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"Fitting failed: {str(e)}", "error")
# [新增槽函数] 最佳区间：执行漂移拟合
    # 复用 self.model.drift_fit，但输入数据改为 r68_dh_bseg
    # ----------------------------------------------------------------------
    @pyqtSlot()
    def perform_drift_calibration_bseg(self):
        """
        [修正版] 执行最佳区间漂移校正
        修正点：在计算年龄前，先对 2D 数据进行加权平均降维，避免 AttributeError
        """
        try:
            # 1. 检查拟合结果
            if not self.drift_results_bseg['68']:
                self.view.show_message("Warning", "Please run Best-Segment Drift Fit first.", "warning")
                return

            print("Starting Drift Calibration (Mode: Best Segment)...")
            
            # 2. 获取标样参考值 (Standard Reference Values)
            
            if not hasattr(self.model, 'std_ref') or self.model.std_ref is None:
                self.update_standard_reference()
                
            # 直接引用 model 里的数据，不要再手写数字
            std_ref_values = {
                'r68': self.model.std_ref['r68'],
                'r75': self.model.std_ref['r75'],
                'r76': self.model.std_ref['r76']
            }
            
            current_name = self.model.std_ref['name']
            print(f"Calibration active: Using [{current_name}] standard values.")
    
            # 3. 执行校正 (生成 2D 结果，保留波形用于后续可能的分析)
            # 68
            self.model.r68_dh_bseg_dc = self.model.drift_cali_spots(
                self.drift_results_bseg['68'][0], 
                self.model.datetimes, 
                self.model.r68_dh_bseg, 
                std_ref_values['r68'], 
                n_knots=self.drift_knots
            )
            # 75
            self.model.r75_dh_bseg_dc = self.model.drift_cali_spots(
                self.drift_results_bseg['75'][0], 
                self.model.datetimes, 
                self.model.r75_dh_bseg, 
                std_ref_values['r75'], 
                n_knots=self.drift_knots
            )
            # 76
            self.model.r76_dh_bseg_dc = self.model.drift_cali_spots(
                self.drift_results_bseg['76'][0], 
                self.model.datetimes, 
                self.model.r76_dh_bseg, 
                std_ref_values['r76'], 
                n_knots=self.drift_knots
            )

            # ==========================================================
            # [关键修正] 先降维 (2D -> 1D)，再计算年龄
            # ==========================================================
            print("Calculating Weighted Means (Reducing 2D to 1D)...")
            
            # 使用 external 误差 (包含 MSWD 扩展)
            # rXX_mean 是 1D uarray (每个 Spot 一个 ufloat)
            r68_mean, _ = self.model.weighted_average(self.model.r68_dh_bseg_dc, err='external')
            r75_mean, _ = self.model.weighted_average(self.model.r75_dh_bseg_dc, err='external')
            r76_mean, _ = self.model.weighted_average(self.model.r76_dh_bseg_dc, err='external')

            print("Calculating Ages and Discordance...")

            # (1) 计算常规 U-Pb 年龄 (传入 1D 均值)
            a68_final, a75_final = self.model.age_upb(r68_mean, r75_mean)
            
            # (2) 计算 207/206 年龄 (Monte Carlo)
            # 这里的 r76_mean 是 1D uarray，solve_76_age_mc 可以正确处理
            a76_final = self.model.solve_76_age_mc(r76_mean)
            
            # (3) 计算协方差 (传入 1D 均值)
            _, rho = self.model.covariance_75_68(r68_mean, r75_mean, r76_mean)

            # (4) 计算不谐和度与最终年龄 (使用 1D 数据)
            disc_pct, final_age = self.model.discordance(
                a68_final, a75_final, a76_final,
                r68=r68_mean,
                r75=r75_mean,
                r76=r76_mean,
                threshold=self.model.AGE_THRESHOLD, 
                calcu='relative'
            )

            # 5. 保存结果至 final_results
            self.model.final_results['spots'] = self.model.spots
            # 建议：final_results 里存 1D 均值，方便导出表格
            self.model.final_results['ratios'] = {
                '68': r68_mean, 
                '75': r75_mean, 
                '76': r76_mean
            }
            self.model.final_results['ages'] = {
                '68': a68_final, 
                '75': a75_final, 
                '76': a76_final, 
                'final': final_age
            }
            self.model.final_results['rho'] = rho
            self.model.final_results['discordance'] = disc_pct

            self.view.show_message("Success", "Best-segment correction and age calculation completed!\nResults saved.")
            self.update_spreadsheet_table()
            # 6. 自动刷新年龄分布图
            if hasattr(self, 'update_age_dist_plot'):
                self.update_age_dist_plot()
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.view.show_message("Error", f"Correction failed: {str(e)}", "error")

    # ----------------------------------------------------------------------
    # [新增槽函数] 最佳区间：执行漂移校正
    # 使用新写的 self.model.drift_cali_spots
    # ----------------------------------------------------------------------
    from PyQt6.QtCore import pyqtSlot
    import numpy as np

    @pyqtSlot(str)
    def update_age_dist_plot(self, text=None):
        """
        [增强版] 绘制年龄分布图
        新增：将被用户右键剔除的样品点传递给 outer 参数，在图上标红并排除。
        """
        if 'ages' not in self.model.final_results or not self.model.final_results['ages']:
            return 

        age_sel = '206Pb/238U Age'
        if hasattr(self.view, 'age_dist_selector'):
            age_sel = self.view.age_dist_selector.currentText()
        
        filter_sel = 'All Samples'
        if hasattr(self.view, 'scatter_filter_selector'):
            filter_sel = self.view.scatter_filter_selector.currentText()

        ages_data = None
        ylabel = 'Age (Ma)'
        
        if '206Pb/238U' in age_sel:
            ages_data = self.model.final_results['ages']['68']
            ylabel = '$^{206}$Pb/$^{238}$U Age (Ma)'
        elif '207Pb/235U' in age_sel:
            ages_data = self.model.final_results['ages']['75']
            ylabel = '$^{207}$Pb/$^{235}$U Age (Ma)'
        elif '207Pb/206Pb' in age_sel:
            ages_data = self.model.final_results['ages']['76']
            ylabel = '$^{207}$Pb/$^{206}$Pb Age (Ma)'
        elif 'Final' in age_sel:
            ages_data = self.model.final_results['ages']['final']
            ylabel = 'Final Age (Ma)'

        disc_pct = self.model.final_results.get('discordance', np.zeros(len(ages_data)))
        spots = self.model.final_results.get('spots', self.model.spots)
        datetimes = self.model.datetimes
        s_types = self.model.sample_types.astype(str)

        mask = np.zeros(len(ages_data), dtype=bool)
        dynamic_threshold = 0.0 

        if filter_sel == 'All Samples':
            mask[:] = True
            dynamic_threshold = 0.0 
        elif filter_sel == 'Standards':
            mask = np.char.find(s_types, 'Standard') != -1
            dynamic_threshold = 0.0 
        elif filter_sel == 'Unknowns':
            mask = np.char.find(s_types, 'Unknown') != -1
            dynamic_threshold = 10.0 
        elif filter_sel == 'References':
            mask = np.char.find(s_types, 'Reference') != -1
            dynamic_threshold = 0.0 

        if not np.any(mask):
            self.view.show_message("Info", f"No samples found for category '{filter_sel}'.", "info")
            self.view.plot_to_view('scatter', lambda ax: ax.text(0.5, 0.5, "No Data", ha='center'))
            return

        plot_datetimes = datetimes[mask]
        plot_ages = ages_data[mask]
        plot_disc = disc_pct[mask]
        plot_spots = spots[mask]
        
        # =========================================================
        # 【新增核心逻辑】：从掩码中揪出“坏点”的索引，准备传给绘图器
        # =========================================================
        outer_indices = []
        if hasattr(self.model, 'is_valid') and self.model.is_valid is not None:
            # 提取当前筛选类别（比如所有 Unknowns）的有效性状态
            current_valid_mask = self.model.is_valid[mask]
            
            # np.where(~current_valid_mask)[0] 会返回所有 False 的相对索引位置
            # 比如 [0, 5, 12] 表示这批点里的第 1、6、13 个点是被剔除的
            outer_indices = np.where(~current_valid_mask)[0].tolist()
        # =========================================================

        title = f'{age_sel} Distribution ({filter_sel})'

        if ages_data is not None:
            self.view.plot_to_view(
                'scatter',
                self.model.age_dist_plot,
                plot_datetimes, 
                plot_ages,      
                plot_disc,      
                plot_spots,     
                disc_threshold=dynamic_threshold, 
                
                # 【关键修改】：将找出的坏点索引列表传给 outer 参数！
                outer=outer_indices, 
                
                ylabel=ylabel,
                title=title
            )
# --- 方法 1: 响应交互式拖动 ---
    @pyqtSlot(int, int)
    def on_interactive_cutoff_changed(self, start_idx, end_idx):
        if not hasattr(self, 'current_sample_name') or self.current_sample_name is None: return
        
        # [关键] 只要拖了滑块，就记在小本本上
        if not hasattr(self.model, 'custom_cutoffs'):
            self.model.custom_cutoffs = {}
        self.model.custom_cutoffs[self.current_sample_name] = (start_idx, end_idx)

        try:
            idx = np.where(self.model.spots == self.current_sample_name)[0][0]
            # 瞬间执行“全套校正”
            res = self.calculate_single_spot(idx, start_idx, end_idx)
            
            if res:
                self.view.interactive_cutoff.plot_concordia(
                    res['r68'], res['r75'], res['r76'],
                    res['age68'], res['age75'], res['age76'],
                    res['disc'],
                    title=f"Manual Calibrated: {self.current_sample_name}"
                )
        except Exception as e:
            print(f"Interactive update failed: {e}")
            import traceback
            traceback.print_exc()

    # --- 方法 2: 样品选择逻辑 ---
    @pyqtSlot(str)
    def on_sample_selected(self, sample_name):
        self.current_sample_name = sample_name 
        try:
            if self.model.signals is None: return
            
            if hasattr(self.view, 'interactive_cutoff'):
                idx = np.where(self.model.spots == sample_name)[0][0]
                time_axis = self.model.signals[:, 0, idx]
                
                # 【修复核心 1】：重新打包所有的同位素信号，传给左侧图表显示
                signals_dict = {}
                for iso in ['Pb206', 'Pb207', 'Pb208', 'Th232', 'U238']:
                    iso_idx = self.get_iso_index(iso)
                    if iso_idx != -1:
                        signals_dict[iso] = self.model.signals[:, iso_idx, idx]
                
                start, end = 20, len(time_axis) - 10
                current_cutoffs = None # 用于画三根黑色虚线
                
                # 优先级 3: 全局自动截断
                if self.model.cutoffs is not None and len(self.model.cutoffs) >= 3:
                    current_cutoffs = self.model.cutoffs # 【修复核心 2】：获取全局基线
                    start = self.model.cutoffs[1]
                    end = self.model.cutoffs[2]

                # 优先级 2: 最佳区间 Best Segment
                if hasattr(self.model, 'ends_Bseg') and self.model.ends_Bseg is not None:
                    try:
                        b_start = int(self.model.ends_Bseg[self.model.id_Bseg[idx], 0, idx])
                        b_end = int(self.model.ends_Bseg[self.model.id_Bseg[idx], 1, idx])
                        if self.model.cutoffs is not None:
                             offset = self.model.cutoffs[1] if isinstance(self.model.cutoffs, list) else 0
                             start = b_start + offset
                             end = b_end + offset
                    except: pass
                    
                # 优先级 1: 手动微调记录 (最高优先级)
                if hasattr(self.model, 'custom_cutoffs') and sample_name in self.model.custom_cutoffs:
                    start, end = self.model.custom_cutoffs[sample_name]

                # 【修复核心 3】：把完整的信号字典和三根虚线重新传给视图
                self.view.interactive_cutoff.plot_signal(
                    time_axis, signals_dict, start, end, cutoffs=current_cutoffs, title=sample_name
                )
                
                # 画完左边，顺便触发一下右边谐和图的更新
                self.on_interactive_cutoff_changed(start, end)

        except Exception as e:
            print(f"Error selecting sample: {e}")
            import traceback
            traceback.print_exc()
    # --- 方法 3: 单点瞬间全自动计算 ---
    def calculate_single_spot(self, spot_idx, start_idx, end_idx):
        m = self.model
        if m.signals is None: return None
        
        try:
            # 1. 切片与背景扣除
            raw_slice = m.signals[start_idx:end_idx, :, spot_idx]
            bkg_end = m.cutoffs[0] if (m.cutoffs and isinstance(m.cutoffs, list)) else 10
            bkg_mean = np.mean(m.signals[:bkg_end, :, spot_idx], axis=0)
            
            net_signals = raw_slice - bkg_mean
            net_signals[net_signals <= 0] = 1e-9 
            
            idx_206 = self.get_iso_index('Pb206')
            idx_207 = self.get_iso_index('Pb207')
            idx_238 = self.get_iso_index('U238')
            
            # 1. 确保中央大脑已初始化
            if not hasattr(self.model, 'std_ref') or self.model.std_ref is None:
                self.update_standard_reference()
            
            # 2. 提取动态 U8/U5
            U8U5 = self.model.std_ref['u8u5']

            # 3. 计算原始比值
            r68_raw = net_signals[:, idx_206] / net_signals[:, idx_238]
            
            
            r75_raw = (net_signals[:, idx_207] / net_signals[:, idx_238]) * U8U5
            
            r76_raw = net_signals[:, idx_207] / net_signals[:, idx_206]
            
            print(f"Raw ratios calculated using U8U5={U8U5} (Standard: {self.model.std_ref['name']})")
            
            # 2. Downhole 校正 (修复时间轴错位)
            time_axis = m.signals[:, 0, spot_idx]
            # 【修复1】：找到激光真正开打的时间，算相对深度！
            laser_start_idx = m.cutoffs[1] if (m.cutoffs and len(m.cutoffs) > 1) else 15
            t_dh = time_axis[start_idx:end_idx] - time_axis[laser_start_idx] 
            
            import uncertainties.unumpy as unumpy
            
            def apply_dh(params, raw_r, t):
                if not params: return raw_r
                factor = (params['a'] + params['b'] * unumpy.exp(params['c'] * t)) / params['a']
                return raw_r / factor

            r68_dh = apply_dh(m.downhole_fit_68_params, r68_raw, t_dh)
            r75_dh = apply_dh(m.downhole_fit_75_params, r75_raw, t_dh)
            r76_dh = r76_raw 
            
            # 加权平均降维
            r68_mean = ufloat(np.mean(unumpy.nominal_values(r68_dh)), np.std(unumpy.nominal_values(r68_dh))/np.sqrt(max(1, len(r68_dh))))
            r75_mean = ufloat(np.mean(unumpy.nominal_values(r75_dh)), np.std(unumpy.nominal_values(r75_dh))/np.sqrt(max(1, len(r75_dh))))
            r76_mean = ufloat(np.mean(unumpy.nominal_values(r76_dh)), np.std(unumpy.nominal_values(r76_dh))/np.sqrt(max(1, len(r76_dh))))

            # 3. 仪器漂移校正 (Drift)
            r68_final, r75_final, r76_final = r68_mean, r75_mean, r76_mean
            
            # 【修复2】：复制成 2 个点，骗过 sklearn 的 Spline 要求，确保 Drift 被执行！
            # 这里的 m 应该是你的 self.model
            datetimes_spot_pad = np.array([m.datetimes[spot_idx], m.datetimes[spot_idx] + 1])
            r68_n_pad = np.array([r68_mean.n, r68_mean.n])
            r75_n_pad = np.array([r75_mean.n, r75_mean.n])
            
            # 【核心重构】：彻底删除硬编码，改用动态参考值
            # 确保 model 里已经有 std_ref 字典
            if not hasattr(m, 'std_ref') or m.std_ref is None:
                self.update_standard_reference() 
            
            # 这里我们取 .n (数值部分)，因为后面的计算通常不需要 ufloat 结构
            std_ref = {
                'r68': m.std_ref['r68'].n, 
                'r75': m.std_ref['r75'].n, 
                'r76': m.std_ref['r76'].n
            }
            
            # 顺便打个日志，方便调试看有没有跑错标样
            # print(f"DEBUG: Spot {spot_idx} is using {m.std_ref['name']} ref values.")

            drift_res = getattr(self, 'drift_results_bseg', self.drift_results)
            if drift_res.get('68') is None: drift_res = self.drift_results

            if drift_res.get('68') and drift_res['68'][0]:
                r68_final_arr = m.drift_cali_spots(drift_res['68'][0], datetimes_spot_pad, r68_n_pad, std_ref['r68'], n_knots=self.drift_knots)
                if r68_final_arr is not None: r68_final = ufloat(r68_final_arr[0].n, r68_mean.s) # 只取第 0 个结果

            if drift_res.get('75') and drift_res['75'][0]:
                r75_final_arr = m.drift_cali_spots(drift_res['75'][0], datetimes_spot_pad, r75_n_pad, std_ref['r75'], n_knots=self.drift_knots)
                if r75_final_arr is not None: r75_final = ufloat(r75_final_arr[0].n, r75_mean.s)

            # 4. 年龄计算与覆盖内存
            a68, a75 = m.age_upb(np.array([r68_final]), np.array([r75_final]))
            a76 = [ufloat(0,0)]
            r76_val = r76_final.n if hasattr(r76_final, 'n') else r76_final
            if r76_val > 0 and not np.isnan(r76_val):
                try: a76 = m.solve_76_age_mc(np.array([r76_final]))
                except: pass
                
            disc, f_age = m.discordance(a68, a75, a76, r68=np.array([r68_final]), r75=np.array([r75_final]), r76=np.array([r76_final]))

            # 【覆写内存】
            try:
                if hasattr(m, 'final_results') and m.final_results.get('ratios'):
                    m.final_results['ratios']['68'][spot_idx] = r68_final
                    m.final_results['ratios']['75'][spot_idx] = r75_final
                    m.final_results['ratios']['76'][spot_idx] = r76_final
                    m.final_results['ages']['68'][spot_idx] = a68[0]
                    m.final_results['ages']['75'][spot_idx] = a75[0]
                    m.final_results['ages']['76'][spot_idx] = a76[0]
                    m.final_results['ages']['final'][spot_idx] = f_age[0]
                    m.final_results['discordance'][spot_idx] = disc[0]

                if getattr(m, 'r68_dh_dc', None) is not None: m.r68_dh_dc[:, spot_idx] = r68_final
                if getattr(m, 'r75_dh_dc', None) is not None: m.r75_dh_dc[:, spot_idx] = r75_final
                if getattr(m, 'r76_dh_dc', None) is not None: m.r76_dh_dc[:, spot_idx] = r76_final
            except Exception as e_mem:
                print(f"Memory write skipped: {e_mem}")

            return {
                'r68': r68_final, 'r75': r75_final, 'r76': r76_final,
                'age68': a68[0], 'age75': a75[0], 'age76': a76[0],
                'disc': disc[0]
            }
        except Exception as e:
            print(f"Single spot calculation failed: {e}")
            import traceback
            traceback.print_exc()
            return None
    @pyqtSlot()
    def perform_interactive_cutoff(self):
        self.view.show_message("Info", "Interactive cutoff feature is coming soon.")

    @pyqtSlot(str)
    def on_group_expanded(self, group_name):
        pass

    @pyqtSlot(str)
    def on_group_collapsed(self, group_name):
        pass

    def setup_menu_actions(self):
        menubar = self.view.menuBar()
        file_menu = menubar.findChild(QMenu, 'menuFile')
        if file_menu:
            import_action = QAction("import", self.view)
            import_action.triggered.connect(self.on_import_menu_clicked)
            file_menu.addAction(import_action)

            settings_action = QAction("setting...", self.view)
            settings_action.triggered.connect(self.on_settings_menu_clicked)
            file_menu.addAction(settings_action)

            save_action = QAction("export", self.view)
            save_action.triggered.connect(self.on_save_menu_clicked)
            file_menu.addAction(save_action)

        data_menu = menubar.findChild(QMenu, 'menuSettings') 
        if data_menu:
            # 手动 Cutoff 动作
            cutoff_action = QAction("Manual Cutoff Settings...", self.view)
            cutoff_action.triggered.connect(self.on_manual_cutoff_clicked)
            data_menu.addAction(cutoff_action)
            
            # [第 6 点预留] 最佳区间参数设置
            bseg_setting_action = QAction("Best Segment Parameters...", self.view)
            bseg_setting_action.triggered.connect(self.on_bseg_settings_clicked)
            data_menu.addAction(bseg_setting_action)
    @pyqtSlot()
    def on_settings_menu_clicked(self):
        dialog = SettingsDialog(self.config, self.view)
        if dialog.exec():
            new_settings = dialog.get_settings()
            try:
                if 'SampleTypes' not in self.config: self.config['SampleTypes'] = {}
                self.config['SampleTypes']['primary_standard_prefix'] = new_settings['SampleTypes'][
                    'primary_standard_prefix']
                self.config['SampleTypes']['secondary_standard_prefixes'] = new_settings['SampleTypes'][
                    'secondary_standard_prefixes']
                self.config['SampleTypes']['unknown_prefixes'] = new_settings['SampleTypes']['unknown_prefixes']

                if 'Analysis' not in self.config: self.config['Analysis'] = {}
                self.config['Analysis']['downhole_fit_curve'] = new_settings['Analysis']['downhole_fit_curve']

                config_path = os.path.join(os.path.dirname(__file__), '..', 'config.ini')
                with open(config_path, 'w', encoding='utf-8') as configfile:
                    self.config.write(configfile)
                self.view.show_message("Success", "Settings saved. Changes will take effect upon the next data import.")
            except Exception as e:
                self.view.show_message("Error", f"Failed to save settings: {e}", "error")
    @pyqtSlot()
    def on_bseg_settings_clicked(self):
        # 1. 尝试从模型获取当前的三种宽度，如果没有则提供默认值 (比如都是 15)
        current_w = getattr(self.model, 'bseg_widths', [10, 10, 10])
        
        from upbapp.views.main_view import BsegSettingsDialog
        dialog = BsegSettingsDialog(current_w, self.view)
        
        if dialog.exec():
            # 2. 获取这三个新值，存成一个列表或字典
            new_widths = dialog.get_widths()
            
            # 存入 model 中！
            self.model.bseg_widths = new_widths
            
            print(f"✅ 最佳区间最小宽度更新 -> 标样:{new_widths[0]}, 质控:{new_widths[1]}, 未知:{new_widths[2]}")
    @pyqtSlot()
    def on_manual_cutoff_clicked(self):
        m = self.model
        
        # 1. 检查最原始的 signals
        if not hasattr(m, 'signals') or m.signals is None:
            if hasattr(self.view, 'show_message'):
                self.view.show_message("Wait", "Please import data first.", "warning")
            return

        import numpy as np
        
        # 2. 【核心修复】：严禁使用 time_eff！
        # 必须使用与原始 signals 长度一致的原始时间数组
        time_array = getattr(m, 'time', None)
        
        # 容错：如果找不到 time，尝试用 datetimes（有时 datetimes 是二维的，取第一列即可）
        if time_array is None:
            dt = getattr(m, 'datetimes', None)
            if dt is not None:
                time_array = dt[:, 0] if dt.ndim > 1 else dt
        
        # 终极保底：如果还是找不到，直接生成一个和原始数据点数一样长的整数数组 (0, 1, 2...)
        total_points = m.signals.shape[0] if m.signals.ndim > 0 else 300
        if time_array is None or len(time_array) != total_points:
            time_array = np.arange(total_points)

        # 3. 基础索引逻辑
        if not hasattr(m, 'cutoffs') or m.cutoffs is None or len(m.cutoffs) < 3:
            current_indices = [int(total_points * 0.1), int(total_points * 0.15), int(total_points * 0.8)]
        else:
            current_indices = [int(i) for i in m.cutoffs] 

        # --- 以下代码保持不变 ---
        current_times = [float(time_array[i]) for i in current_indices]

        from upbapp.views.main_view import CutoffInputDialog 
        dialog = CutoffInputDialog(current_times, self.view)
        
        if dialog.exec():
            new_times = dialog.get_values()
            new_times.sort()
            
            new_indices = []
            for t_val in new_times:
                # 在完整的原始时间数组里寻找最近的索引
                idx = (np.abs(time_array - t_val)).argmin()
                new_indices.append(int(idx))
            
            m.cutoffs = new_indices
            print(f"✅ 手动强制设定 Cutoff (Time): {new_times} -> (Indices): {new_indices}")
            
            if hasattr(self, 'update_current_plot'):
                self.update_current_plot()

            if hasattr(self.view, 'show_message'):
                self.view.show_message(
                    "Success", 
                    "Manual cutoffs applied successfully!\n"
                    "Please proceed DIRECTLY to the 'Background Subtraction' step.", 
                    "success"
                )
    def on_import_menu_clicked(self):
        dir_path = self.view.show_directory_dialog("Select Data Directory")
        if dir_path: self.import_data(dir_path)

    @pyqtSlot()
    def on_save_menu_clicked(self):
        m = self.model
        
        if not hasattr(m, 'spots') or m.spots is None:
            if hasattr(self.view, 'show_message'):
                self.view.show_message("Warning", "No data to export.", "warning")
            return

        from PyQt6.QtWidgets import QFileDialog
        import numpy as np # 确保导入了 numpy

        filepath, _ = QFileDialog.getSaveFileName(
            self.view, "Export U-Pb Results", "UPb_Results.csv", "CSV Files (*.csv)"
        )
        if not filepath: return 

        try:
            # 【关键修改 1】：提取真实的有效性掩码
            # 如果还没有 is_valid（例如刚导数还没计算），则默认全为 True
            is_valid_mask = getattr(m, 'is_valid', np.ones(len(m.spots), dtype=bool))

            with open(filepath, "w", encoding='utf-8-sig') as file:
                # 【关键修改 2】：在表头增加 "Status" 列
                file.write('Spot, Status, Best segment, r68, r68_err, r75, r75_err, r76, r76_err, a68, a68_err, a75, a75_err, a76, a76_err\n')
                
                for idx, spot in enumerate(m.spots):
                    # 判断该点状态
                    is_row_valid = is_valid_mask[idx]
                    status_str = "Included" if is_row_valid else "REJECTED"
                    
                    # --- 获取截取区间 (保持你原本逻辑) ---
                    start, end = 20, 100
                    if hasattr(m, 'cutoffs') and m.cutoffs is not None and len(m.cutoffs) >= 3:
                        start, end = m.cutoffs[1], m.cutoffs[2]
                    if hasattr(m, 'ends_Bseg') and m.ends_Bseg is not None:
                        try:
                            b_start = int(m.ends_Bseg[m.id_Bseg[idx], 0, idx])
                            b_end = int(m.ends_Bseg[m.id_Bseg[idx], 1, idx])
                            offset = m.cutoffs[1] if isinstance(m.cutoffs, list) else 0
                            start, end = b_start + offset, b_end + offset
                        except: pass
                    if hasattr(m, 'custom_cutoffs') and spot in m.custom_cutoffs:
                        start, end = m.custom_cutoffs[spot]

                    seg_str = f"[{start}-{end}]"

                    # --- 提取数值 (保持你原本逻辑) ---
                    def safe_get(group, subkey, index, is_age=False):
                        val = None
                        try:
                            if hasattr(m, 'final_results') and m.final_results.get(group):
                                fr_spots = list(m.final_results.get('spots', m.spots))
                                if spot in fr_spots:
                                    fr_idx = fr_spots.index(spot)
                                    val = m.final_results[group][subkey][fr_idx]
                                else:
                                    val = m.final_results[group][subkey][index]
                        except: pass
                        return val

                    def get_n_s(val):
                        if val is None: return 0.0, 0.0
                        if hasattr(val, 'n') and hasattr(val, 's'): return val.n, val.s
                        return float(val), 0.0

                    r68 = safe_get('ratios', '68', idx)
                    r75 = safe_get('ratios', '75', idx); r76 = safe_get('ratios', '76', idx)
                    a68 = safe_get('ages', '68', idx, True)
                    a75 = safe_get('ages', '75', idx, True); a76 = safe_get('ages', '76', idx, True)

                    r68_n, r68_s = get_n_s(r68); r75_n, r75_s = get_n_s(r75); r76_n, r76_s = get_n_s(r76)
                    a68_n, a68_s = get_n_s(a68); a75_n, a75_s = get_n_s(a75); a76_n, a76_s = get_n_s(a76)

                    # 【关键修改 3】：拼装这一行，加入 Status 列
                    # 如果是被剔除的点，我们在名字前面再加一个星号 '*'，双重保险
                    display_spot = f"*{spot}" if not is_row_valid else spot
                    
                    row = (f"{display_spot}, {status_str}, {seg_str}, "
                           f"{r68_n:.4f}, {r68_s:.4f}, "
                           f"{r75_n:.4f}, {r75_s:.4f}, "
                           f"{r76_n:.4f}, {r76_s:.4f}, "
                           f"{a68_n:.1f}, {a68_s:.1f}, "
                           f"{a75_n:.1f}, {a75_s:.1f}, "
                           f"{a76_n:.1f}, {a76_s:.1f}\n")
                    
                    file.write(row)
            
            if hasattr(self.view, 'show_message'):
                self.view.show_message("Success", f"Results exported.\nRejected samples are marked as 'REJECTED'.", "success")
            
        except Exception as e:
            if hasattr(self.view, 'show_message'):
                self.view.show_message("Export Failed", f"Error: {e}", "error")

    from PyQt6.QtCore import pyqtSlot

    @pyqtSlot()
    def update_spreadsheet_table(self):
        m = self.model
        
        # 1. 基础检查
        if not hasattr(m, 'spots') or m.spots is None:
            return
        if not hasattr(self.view, 'results_table') or self.view.results_table is None:
            return

        from PyQt6.QtGui import QStandardItemModel, QStandardItem, QColor, QFont, QBrush
        from PyQt6.QtCore import Qt

        # 关闭排序，防止灌入数据时界面“跳舞”
        self.view.results_table.setSortingEnabled(False)
        
        # 2. 准备表头
        headers = ['Spot', 'Best Segment', 'r68', 'r68_err', 'r75', 'r75_err', 'r76', 'r76_err', 
                   'a68', 'a68_err', 'a75', 'a75_err', 'a76', 'a76_err']
        
        # 3. 创建模型
        table_model = QStandardItemModel(len(m.spots), len(headers))
        table_model.setHorizontalHeaderLabels(headers)

        # =========================================================
        # 4. 【核心修正】从模型中提取真实的有效性掩码
        # =========================================================
        # 如果 is_valid 还没建立（比如刚导数），默认全选 True
        import numpy as np
        is_valid_mask = getattr(m, 'is_valid', np.ones(len(m.spots), dtype=bool))
        
        # 为了在名字前加个标记（可选），如果是剔除点，名字前加个 "✘ "
        # =========================================================

        # 5. 开始遍历灌装数据
        for idx, spot in enumerate(m.spots):
            # --- (A) 确定该行是否有效 ---
            is_row_valid = is_valid_mask[idx]

            # --- (B) 获取截取区间 (保持你原本逻辑) ---
            start, end = 20, 100
            if hasattr(m, 'cutoffs') and m.cutoffs is not None and len(m.cutoffs) >= 3:
                start, end = m.cutoffs[1], m.cutoffs[2]
            if hasattr(m, 'ends_Bseg') and m.ends_Bseg is not None:
                try:
                    b_start = int(m.ends_Bseg[m.id_Bseg[idx], 0, idx])
                    b_end = int(m.ends_Bseg[m.id_Bseg[idx], 1, idx])
                    offset = m.cutoffs[1] if isinstance(m.cutoffs, list) else 0
                    start, end = b_start + offset, b_end + offset
                except: pass
            if hasattr(m, 'custom_cutoffs') and spot in m.custom_cutoffs:
                start, end = m.custom_cutoffs[spot]

            seg_str = f"[{start}-{end}]" # 简化显示，节省表格空间

            # --- (C) 安全获取比值和年龄 ---
            def safe_get(group, subkey, index, is_age=False):
                val = None
                try:
                    if hasattr(m, 'final_results') and m.final_results.get(group):
                        fr_spots = list(m.final_results.get('spots', m.spots))
                        if spot in fr_spots:
                            fr_idx = fr_spots.index(spot)
                            val = m.final_results[group][subkey][fr_idx]
                        else:
                            val = m.final_results[group][subkey][index]
                except: pass
                return val

            def get_n_s(val):
                if val is None: return 0.0, 0.0
                if hasattr(val, 'n') and hasattr(val, 's'): return val.n, val.s
                return float(val), 0.0

            # 提取各项数值...
            r68 = safe_get('ratios', '68', idx)
            r75 = safe_get('ratios', '75', idx)
            r76 = safe_get('ratios', '76', idx)
            a68 = safe_get('ages', '68', idx, True)
            a75 = safe_get('ages', '75', idx, True)
            a76 = safe_get('ages', '76', idx, True)

            r68_n, r68_s = get_n_s(r68); r75_n, r75_s = get_n_s(r75); r76_n, r76_s = get_n_s(r76)
            a68_n, a68_s = get_n_s(a68); a75_n, a75_s = get_n_s(a75); a76_n, a76_s = get_n_s(a76)

            # --- (D) 整理数据列表 ---
            prefix = "" if is_row_valid else "✘ "
            row_data = [
                f"{prefix}{spot}", seg_str,
                f"{r68_n:.4f}", f"{r68_s:.4f}", f"{r75_n:.4f}", f"{r75_s:.4f}", f"{r76_n:.4f}", f"{r76_s:.4f}",
                f"{a68_n:.1f}", f"{a68_s:.1f}", f"{a75_n:.1f}", f"{a75_s:.1f}", f"{a76_n:.1f}", f"{a76_s:.1f}"
            ]

            # --- (E) 写入 Model 并渲染样式 ---
            for col_idx, text in enumerate(row_data):
                item = QStandardItem()
                
                # 设置文本数据
                try:
                    num_val = float(text)
                    item.setData(num_val, Qt.ItemDataRole.DisplayRole)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                except ValueError:
                    item.setData(text, Qt.ItemDataRole.DisplayRole)
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)

                # 💡 【渲染样式】：如果是被剔除的行
                if not is_row_valid:
                    item.setForeground(QBrush(QColor("#cc0000"))) # 深红色
                    item.setBackground(QBrush(QColor("#f2f2f2"))) # 浅灰色背景
                    font = item.font()
                    font.setStrikeOut(True) # 加删除线
                    item.setFont(font)
                else:
                    # 恢复正常样式，防止排序后样式错乱
                    item.setForeground(QBrush(QColor("black")))
                    item.setBackground(QBrush(QColor("white")))
                    font = item.font()
                    font.setStrikeOut(False)
                    item.setFont(font)

                table_model.setItem(idx, col_idx, item)

        self.view.results_table.setModel(table_model)
        self.view.results_table.setSortingEnabled(True)
        print("✅ Spreadsheet 数据同步更新完毕！")