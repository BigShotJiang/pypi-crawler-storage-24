# 控制器包
from .main_controller import MainController

__all__ = ['MainController']