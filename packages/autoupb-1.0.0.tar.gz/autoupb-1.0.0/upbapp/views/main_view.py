## 用于自动处理LA-ICP-MS的U-Pb同位素数据 - 视图层
from PyQt6.QtWidgets import (QMainWindow, QTableView, QGraphicsView, QTreeWidget,
                             QTreeWidgetItem, QPushButton, QTabWidget, QMessageBox,
                             QVBoxLayout, QWidget, QMenu, QHBoxLayout, QLabel,
                             QComboBox, QGroupBox)
from PyQt6.QtWidgets import QTreeWidgetItemIterator # 用于全局搜索那个样品
from PyQt6.QtCore import Qt, QSortFilterProxyModel, pyqtSignal
from PyQt6.QtGui import QStandardItemModel, QStandardItem, QAction
from PyQt6 import uic
from PyQt6.QtGui import QColor, QBrush, QFont 
# 或者从 PySide6 / PyQt5 导入，取决于你用的库
# 或者 from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QTableWidget, QVBoxLayout, QHeaderView, QAbstractItemView
import pyqtgraph as pg
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
import re
import os
import sys
from PyQt6.QtWidgets import *
from matplotlib.widgets import SpanSelector
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from PyQt6.QtWidgets import QSizePolicy
from uncertainties import ufloat 

class CutoffInputDialog(QDialog):
    def __init__(self, current_times, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Manual Cutoff Settings (Time in seconds)")
        layout = QFormLayout(self)
        
        # 改回带小数点的 QDoubleSpinBox
        from PyQt6.QtWidgets import QDoubleSpinBox
        self.spin_bkg_end = QDoubleSpinBox()
        self.spin_sig_start = QDoubleSpinBox()
        self.spin_sig_end = QDoubleSpinBox()
        
        # 恢复后缀 "s"，范围设置，保留 1 位小数
        for i, spin in enumerate([self.spin_bkg_end, self.spin_sig_start, self.spin_sig_end]):
            spin.setRange(0.0, 9999.9)
            spin.setDecimals(1)
            spin.setSuffix(" s")
            spin.setValue(float(current_times[i]))
            
        layout.addRow("Background End (Time):", self.spin_bkg_end)
        layout.addRow("Signal Start (Time):", self.spin_sig_start)
        layout.addRow("Signal End (Time):", self.spin_sig_end)
        
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addRow(self.buttons)

    def get_values(self):
        return [self.spin_bkg_end.value(), self.spin_sig_start.value(), self.spin_sig_end.value()]

class BsegSettingsDialog(QDialog):
    def __init__(self, current_widths, parent=None):
        """current_widths 应该是一个包含3个数值的列表或元组：[标样, 质控样, 未知样]"""
        super().__init__(parent)
        self.setWindowTitle("Best Segment Settings")
        layout = QFormLayout(self)
        
        from PyQt6.QtWidgets import QSpinBox # 假设宽度是点数(整数)，如果需要小数请换成 QDoubleSpinBox
        
        self.spin_std = QSpinBox()   # Primary Standard (标样)
        self.spin_ref = QSpinBox()   # Reference/Secondary (质控样)
        self.spin_unk = QSpinBox()   # Unknowns (未知样)
        
        # 批量设置：范围 1~1000，不要任何单位
        for i, spin in enumerate([self.spin_std, self.spin_ref, self.spin_unk]):
            spin.setRange(1, 1000)
            spin.setValue(int(current_widths[i]))
            
        layout.addRow("Primary Standard Width:", self.spin_std)
        layout.addRow("Reference/Secondary Width:", self.spin_ref)
        layout.addRow("Unknown Sample Width:", self.spin_unk)
        
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addRow(self.buttons)

    def get_widths(self):
        # 返回三个值的列表
        return [self.spin_std.value(), self.spin_ref.value(), self.spin_unk.value()]
class InteractiveCutoffWidget(QWidget):
    # 信号：发送 (start_index, end_index)
    cutoff_changed = pyqtSignal(int, int) 

    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QHBoxLayout(self)
        
        # ==========================================
        # --- 左侧：信号截断编辑区 (改为 PyQtGraph) ---
        # ==========================================
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        
        # 创建 PyQtGraph 画布
        self.pg_plot = pg.PlotWidget(title="Interactive Cutoff")
        self.pg_plot.setBackground('w') # 设置白底
        self.pg_plot.setLabel('left', "CPS")
        self.pg_plot.setLabel('bottom', "Time (s)")
        self.pg_plot.setLogMode(y=False) # Y轴默认对数显示
        self.pg_plot.addLegend(offset=(10, 10))
        left_layout.addWidget(self.pg_plot)
        
        # 初始化一个可拖拽的区间选择器 (LinearRegionItem)
        # ==========================================
        # 优化区间选择器 (LinearRegionItem) 的交互手感
        # ==========================================
        # 1. 普通状态下的边界线：黄色，线宽加粗到 3
        edge_pen = pg.mkPen(color=(255, 255, 0, 200), width=3)
        
        # 2. 鼠标悬停时的边界线：变红，线宽加粗到 5 (极大地增加抓取成功率和视觉反馈)
        hover_pen = pg.mkPen(color=(255, 0, 0, 255), width=5)
        
        # 3. 中间块的填充色：半透明黄色 (保持地学软件的经典配色)
        region_brush = pg.mkBrush(color=(255, 255, 0, 50))
        
        # 4. 重新初始化，注入灵魂
        self.region = pg.LinearRegionItem(
            [0, 1], 
            pen=edge_pen, 
            hoverPen=hover_pen, 
            brush=region_brush
        )
        self.region.setZValue(10)
        self.region.setZValue(10)
        # 绑定拖拽完成事件
        self.region.sigRegionChangeFinished.connect(self._on_region_changed)
        
        # 记录当前绘图的曲线
        self.curve = None
        self.current_time_array = None

        # ==========================================
        # --- 右侧：实时谐和图 (保留 Matplotlib) ---
        # ==========================================
        self.fig_concordia = plt.figure()
        self.canvas_concordia = FigureCanvas(self.fig_concordia)
        self.toolbar_concordia = NavigationToolbar(self.canvas_concordia, self)
        self.fig_concordia.subplots_adjust(left=0.2, bottom=0.2, right=0.9, top=0.9)
        
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.addWidget(self.toolbar_concordia)
        right_layout.addWidget(self.canvas_concordia)
        
        # 设置左右比例 2:1
        self.layout.addWidget(left_panel, 2)
        self.layout.addWidget(right_panel, 1)

    def plot_signal(self, time, signals_dict, start_idx, end_idx, cutoffs=None, title=""):
        self.current_time_array = time
        
        # 参照原代码修改标题样式
        self.pg_plot.setTitle(f"spot: {title}", color='k', size='11pt')
        self.pg_plot.clear() # 清空旧曲线和标记

        # 重新添加黄色的交互区间选择器
        self.pg_plot.addItem(self.region)

        import numpy as np
        from PyQt6.QtCore import Qt

        # 1. 绘制所有同位素信号线
        # 使用科研绘图常用的区分色
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']
        color_idx = 0
        for name, signal in signals_dict.items():
            pen_color = colors[color_idx % len(colors)]
            # 参照原代码绘制并加入图例(name)
            self.pg_plot.plot(time, signal, pen=pg.mkPen(color=pen_color, width=1.5), name=name)
            color_idx += 1

        # 2. 绘制自动截断线 (完全参照原代码的样式：黑色虚线 + 垂直文本)
        if cutoffs is not None and len(cutoffs) == 3:
            try:
                # 黑色虚线 (color='k', linestyle='--')
                pen_dash = pg.mkPen('k', style=Qt.PenStyle.DashLine, width=1.5)
                
                # 配置文本标签：
                # position=0.85 表示文字靠在上方 85% 的高度
                # fill 设置一个半透明白色背景，防止文字被密集的信号线遮挡看不清
                label_opts = {'position': 0.85, 'color': 'k', 'fill': (255, 255, 255, 180)}
                
                line_bkg = pg.InfiniteLine(pos=time[cutoffs[0]], angle=90, pen=pen_dash, 
                                           label='Background End', labelOpts=label_opts)
                line_start = pg.InfiniteLine(pos=time[cutoffs[1]], angle=90, pen=pen_dash, 
                                             label='Effective Signal Start (Max)', labelOpts=label_opts)
                line_end = pg.InfiniteLine(pos=time[cutoffs[2]], angle=90, pen=pen_dash, 
                                           label='Effective Signal End', labelOpts=label_opts)

                self.pg_plot.addItem(line_bkg)
                self.pg_plot.addItem(line_start)
                self.pg_plot.addItem(line_end)
            except IndexError:
                pass

        # 3. 确保交互滑块不越界，并设置位置
        start_idx = max(0, min(start_idx, len(time)-1))
        end_idx = max(0, min(end_idx, len(time)-1))
        self.region.setRegion([time[start_idx], time[end_idx]])
        view_box = self.pg_plot.getViewBox()
        
        # 开启 X 轴和 Y 轴的完全自动缩放，确保所有数据点都在视野内
        view_box.enableAutoRange(axis='xy', enable=True)
        
        # 给上下左右都留出 5% 的空白边缘，防止最高的信号尖峰顶到天花板，或者底部的坐标轴文字被切掉
        view_box.setDefaultPadding(0.05)
        
        # 加上网格线，帮助用户更好地看清 CPS 数值所在的层级
        self.pg_plot.showGrid(x=True, y=True, alpha=0.3)
    def _on_region_changed(self):
        """当用户拖拽完成时触发，将时间转换为索引并发送信号"""
        if self.current_time_array is None:
            return
            
        # 获取当前选择器的时间范围
        min_x, max_x = self.region.getRegion()
        
        import numpy as np
        # 找到最接近这两个时间点的数组索引
        idx_start = (np.abs(self.current_time_array - min_x)).argmin()
        idx_end = (np.abs(self.current_time_array - max_x)).argmin()
        
        # 触发重新计算
        self.cutoff_changed.emit(idx_start, idx_end)

    def plot_concordia(self, r68, r75, r76, age68, age75, age76, disc, title="Real-time"):
        self.fig_concordia.clear()
        ax = self.fig_concordia.add_subplot(111)
        
        import numpy as np
        import math
        from scipy import stats
        from matplotlib.patches import Ellipse
        
        # 衰变常数 (与你 data_processor.py 保持绝对一致)
        la238 = np.log(2) / 4468.
        la235 = np.log(2) / 704.
        
        # ---------------------------------------------------------
        # 1. 动态生成原汁原味的年龄刻度 (复刻你的 concordia_plot 逻辑)
        # ---------------------------------------------------------
        current_age = age68.n if (age68 is not None and age68.n > 0) else 1000
        
        # 以前后 50~100 Ma 为边界，生成刻度
        age_range_up = math.ceil(current_age / 10.) * 10 + 100
        age_range_down = math.floor(current_age / 10.) * 10 - 100
        age_range_down = max(0, age_range_down)
        
        interval = (age_range_up - age_range_down) / 5.
        if interval <= 0: interval = 50
        age_range = np.arange(age_range_down, age_range_up + interval, interval)
        
        # 画谐和线和空心圆
        r75Con = np.expm1(age_range * la235)
        r68Con = np.expm1(age_range * la238)
        
        # 完全使用你原代码里的样式参数
        ax.plot(r75Con, r68Con, color='k', lw=0.5, zorder=1)
        ax.scatter(r75Con, r68Con, marker='o', s=10, edgecolors='k', linewidths=0.5, facecolors='w', zorder=2)
        
        for i in range(len(r75Con)):
            ax.annotate(f"{age_range[i]:.0f}", xy=(r75Con[i], r68Con[i]),
                        xytext=(-20, 0), textcoords='offset pixels', fontsize=8)

        # ---------------------------------------------------------
        # 2. 原汁原味的误差椭圆计算 (复刻你的 draw_ellipse 和 covariance_75_68)
        # ---------------------------------------------------------
        if r68.n > 0 and r75.n > 0 and r76.n > 0:
            # 近似计算协方差
            Sr75 = r75.s / r75.n
            Sr68 = r68.s / r68.n
            Sr76 = r76.s / r76.n
            rho = (Sr75**2 + Sr68**2 - Sr76**2) / (2 * Sr75 * Sr68)
            cov_r75r68 = rho * r75.s * r68.s
            
            # 构建协方差矩阵并计算特征值 (完全照搬你的 draw_ellipse 数学逻辑)
            cov_matrix = [[r75.s**2, cov_r75r68], [cov_r75r68, r68.s**2]]
            vals, vecs = np.linalg.eigh(cov_matrix)
            theta = np.degrees(np.arctan2(vecs[0, 1], vecs[0, 0]))
            
            # 95% 置信区间
            width, height = 2 * np.sqrt(stats.chi2.ppf(0.95, 2) * np.abs(vals))
            
            # 画一个带有红色边缘的半透明椭圆（突出显示当前正在交互的点）
            ellipse = Ellipse((r75.n, r68.n), width, height, angle=theta,
                              edgecolor='k', facecolor='b', alpha=0.2, linewidth=0.5, zorder=3)
            ax.add_patch(ellipse)
            # 在中心画个小十字
            ax.plot(r75.n, r68.n, 'r+', markersize=6, zorder=4)
        # ---------------------------------------------------------
        # 3. 界面卡片与样式调整
        # ---------------------------------------------------------
        info_text = (f"Age 6/8: {age68.n:.1f} Ma\n"
                     f"Age 7/5: {age75.n:.1f} Ma\n"
                     f"Age 7/6: {age76.n:.1f} Ma\n"
                     f"Disc: {disc:.1f}%")
        
        ax.text(0.05, 0.95, info_text, transform=ax.transAxes, verticalalignment='top', fontsize=9,
                bbox=dict(boxstyle='round', facecolor='white', alpha=0.9), zorder=5)
        
        # 坐标轴和标题，保持 1:1 比例
        ax.set_xlabel('$^{207}$Pb/$^{235}$U')
        ax.set_ylabel('$^{206}$Pb/$^{238}$U')
        ax.set_title(title, fontsize=10)
        ax.set_box_aspect(1) # 这行代码也是你原文件里用来让图表保持正方形的
        
        # 动态聚焦视角，避免空白太大
        if r68.n > 0 and r75.n > 0:
            x_margin = r75.n * 0.15
            y_margin = r68.n * 0.15
            ax.set_xlim(max(0, r75.n - x_margin), r75.n + x_margin)
            ax.set_ylim(max(0, r68.n - y_margin), r68.n + y_margin)

        self.canvas_concordia.draw()
class MainView(QMainWindow):
    sample_toggled_signal = pyqtSignal(str)
    file_import_requested = pyqtSignal(str)
    auto_cutoff_requested = pyqtSignal()
    interactive_cutoff_requested = pyqtSignal()
    sample_selected = pyqtSignal(str)
    group_expanded = pyqtSignal(str)
    group_collapsed = pyqtSignal(str)

    def get_button_style(self, base_color="#E0E0E0", hover_color="#D5D5D5", pressed_color="#C0C0C0", text_color="#000000"):
        """
        生成带有 3D 按压手感和悬停反馈的专业按钮样式表 (QSS)
        """
        return f"""
            QPushButton {{
                background-color: {base_color};
                color: {text_color};
                font-weight: bold;
                padding: 6px 12px;
                border: 1px solid #A0A0A0;
                border-radius: 4px;
            }}
            QPushButton:hover {{
                background-color: {hover_color};
                border: 1px solid #808080;
            }}
            QPushButton:pressed {{
                background-color: {pressed_color};
                padding-top: 8px;    /* 核心：按下时的物理下沉感 */
                padding-bottom: 4px;
            }}
            QPushButton:disabled {{
                background-color: #F0F0F0;
                color: #A0A0A0;
                border: 1px solid #D0D0D0;
            }}
        """
    def __init__(self):
        super().__init__()
        ui_path = os.path.join(os.path.dirname(__file__), '..', 'ui', 'autoUPb.ui')
        if not os.path.exists(ui_path):
            QMessageBox.critical(self, "错误", f"UI文件未找到: {ui_path}")
            return
        uic.loadUi(ui_path, self)

        self.sample_list_widget = self.findChild(QTreeWidget, 'listWidget')
        if not self.sample_list_widget:
            self.sample_list_widget = QTreeWidget()
            central_widget = self.centralWidget()
            if central_widget and central_widget.layout():
                central_widget.layout().addWidget(self.sample_list_widget)

        if self.sample_list_widget:
            self.sample_list_widget.setHeaderLabel("Sample and spot list")
            self.sample_list_widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            self.sample_list_widget.customContextMenuRequested.connect(self.show_sample_context_menu)
        self.table_view = self.findChild(QTableView, 'tableView')
        self.tab_widget = self.findChild(QTabWidget, 'tabWidget')
        self.interactive_button = self.findChild(QPushButton, 'pushButton')
        self.automatic_button = self.findChild(QPushButton, 'pushButton_2')
        self.setup_ui_layout()
        self.init_graphics_views()
        self.connect_signals()
    # === 【新增 3】：生成并显示右键菜单 ===
    def show_sample_context_menu(self, pos):
        item = self.sample_list_widget.itemAt(pos)
        if item is None:
            return

        menu = QMenu(self)
        toggle_action = menu.addAction("delete / restore")
        action = menu.exec(self.sample_list_widget.viewport().mapToGlobal(pos))

        if action == toggle_action:
            # 【关键修改】：直接获取这个节点的文字（也就是样品名）
            sample_name = item.text(0)
            print(f"🚀 发射信号，目标样品: {sample_name}")
            self.sample_toggled_signal.emit(sample_name)
            
    def update_sample_visual(self, sample_name, is_valid):
        """通过样品名遍历树，找到它并修改长相"""
        iterator = QTreeWidgetItemIterator(self.sample_list_widget)
        while iterator.value():
            item = iterator.value()
            if item.text(0) == sample_name: # 找到了！
                font = item.font(0)
                font.setStrikeOut(not is_valid)
                item.setFont(0, font)

                color = QColor("black") if is_valid else QColor("red")
                item.setForeground(0, QBrush(color))
                break # 找到了就停止搜索
            iterator += 1
    def init_graphics_views(self):
        # 定义界面上各个 tab 对应的 placeholder widget
        placeholders = {
            'auto_cutoff': self.findChild(QWidget, 'graphicsView'),
            'bkg_subtraction': self.findChild(QWidget, 'graphicsView_2'),
            'downhole_calib': self.findChild(QWidget, 'graphicsView_3'),
            'drift_calib': self.findChild(QWidget, 'graphicsView_4'),
            'concordia1': self.findChild(QWidget, 'graphicsView_5'),
            'scatter': self.findChild(QWidget, 'graphicsView_7')
        }

        self.canvases = {}
        self.figures = {}
        self.toolbars = {}

        for name, placeholder in placeholders.items():
            if placeholder is None:
                continue
            # === [新增] 1. 拦截 auto_cutoff，植入交互式组件 ===
            if name == 'auto_cutoff':
                self.interactive_cutoff = InteractiveCutoffWidget()
                
                # 替换界面上的原占位符
                parent = placeholder.parentWidget()
                layout = parent.layout()
                if layout is None:
                    layout = QVBoxLayout(parent)

                if layout.indexOf(placeholder) != -1:
                    layout.replaceWidget(placeholder, self.interactive_cutoff)
                else:
                    layout.addWidget(self.interactive_cutoff)

                placeholder.hide()
                # 注册到 self.figures 字典（如果其他地方需要用）
                # 注意：interactive_cutoff 内部有两个 figure，这里可以存 signal 的那个
                self.figures['auto_cutoff'] = self.interactive_cutoff.fig_concordia
                # 跳过后续默认逻辑
                continue
# === 特殊处理：谐和图 (Concordia) 区域 ===
            if name == 'concordia1':
                # 1. 创建主容器
                container = QWidget()
                container_layout = QVBoxLayout(container)
                container_layout.setContentsMargins(0, 0, 0, 0)

                # 2. 创建工具栏 (Top Control Panel)
                ctrl_layout = QHBoxLayout()
                
                # Mode Selector [修正变量名]
                ctrl_layout.addWidget(QLabel("Mode:"))
                self.combo_concordia_mode = QComboBox() # 修正：与 Controller 保持一致
                self.combo_concordia_mode.addItems(['Full Segment', 'Best Segment'])
                ctrl_layout.addWidget(self.combo_concordia_mode)
                ctrl_layout.addSpacing(15)

                # Filter Selector
                ctrl_layout.addWidget(QLabel("Filter:"))
                self.combo_concordia_type = QComboBox() # 修正：与 Controller 保持一致
                ctrl_layout.addWidget(self.combo_concordia_type)
                ctrl_layout.addSpacing(15)

                # Draw Button
                self.btn_draw_concordia = QPushButton("Draw Concordia")
                self.btn_draw_concordia.setStyleSheet(self.get_button_style(
                    base_color="#d4f1c5", hover_color="#c2e6b1", pressed_color="#a8d492"
                ))
                ctrl_layout.addWidget(self.btn_draw_concordia)

                ctrl_layout.addStretch()
                container_layout.addLayout(ctrl_layout)

                # 3. 创建双图布局 (Side-by-Side Plots)
                plots_layout = QHBoxLayout()
                
                # --- 左图 (Wetherill) ---
                fig1 = plt.figure()
                canvas1 = FigureCanvas(fig1)
                toolbar1 = NavigationToolbar(canvas1, self)
                
                left_widget = QWidget()
                left_layout = QVBoxLayout(left_widget)
                left_layout.setContentsMargins(0,0,0,0)
                left_layout.addWidget(toolbar1)
                left_layout.addWidget(canvas1)
                
                # --- 右图 (Tera-Wasserburg) ---
                fig2 = plt.figure()
                canvas2 = FigureCanvas(fig2)
                toolbar2 = NavigationToolbar(canvas2, self)
                
                right_widget = QWidget()
                right_layout = QVBoxLayout(right_widget)
                right_layout.setContentsMargins(0,0,0,0)
                right_layout.addWidget(toolbar2)
                right_layout.addWidget(canvas2)

                plots_layout.addWidget(left_widget)
                plots_layout.addWidget(right_widget)
                
                container_layout.addLayout(plots_layout)

                # 4. 注册到系统字典中
                self.figures['concordia1'] = fig1
                self.canvases['concordia1'] = canvas1
                self.toolbars['concordia1'] = toolbar1
                
                self.figures['concordia2'] = fig2
                self.canvases['concordia2'] = canvas2
                self.toolbars['concordia2'] = toolbar2

                # 5. 替换界面上的原占位符 [安全替换逻辑]
                parent = placeholder.parentWidget()
                
                # 获取父布局，如果没有则创建一个
                layout = parent.layout()
                if layout is None:
                    layout = QVBoxLayout(parent)

                # 安全替换或添加
                if layout.indexOf(placeholder) != -1:
                    layout.replaceWidget(placeholder, container)
                else:
                    layout.addWidget(container)

                placeholder.hide()
                continue # 谐和图处理完毕，跳过后面的通用逻辑
            fig = plt.figure()
            canvas = FigureCanvas(fig)
            toolbar = NavigationToolbar(canvas, self)

            container = QWidget()
            container_layout = QVBoxLayout(container)
            container_layout.setContentsMargins(0, 0, 0, 0)

            # === 背景扣除界面工具栏 ===
            if name == 'bkg_subtraction':
                ctrl_layout = QHBoxLayout()
                label = QLabel("Select Isotope:")
                self.bkg_isotope_selector = QComboBox()
                ctrl_layout.addWidget(label)
                ctrl_layout.addWidget(self.bkg_isotope_selector)
                ctrl_layout.addSpacing(20)
                # [新增] 独立计算背景按钮 (绿色主题)
                self.btn_calc_bkg = QPushButton("Calc & Draw Bkg")
                self.btn_calc_bkg.setStyleSheet(self.get_button_style(
                    base_color="#d4f1c5", hover_color="#c2e6b1", pressed_color="#a8d492"
                ))
                ctrl_layout.addWidget(self.btn_calc_bkg)
                ctrl_layout.addStretch()
                container_layout.addLayout(ctrl_layout)

            # === Downhole 校正界面工具栏 ===
            elif name == 'downhole_calib':
                ctrl_layout = QHBoxLayout()
                
                # 1. 保留预览比值切换
                ctrl_layout.addWidget(QLabel("Preview:"))
                self.downhole_ratio_selector = QComboBox()
                self.downhole_ratio_selector.addItems(['206Pb/238U', '207Pb/235U', '207Pb/206Pb'])
                ctrl_layout.addWidget(self.downhole_ratio_selector)

                ctrl_layout.addSpacing(20)
                self.btn_calc_downhole = QPushButton("Calc & Draw Downhole")
                self.btn_calc_downhole.setStyleSheet(self.get_button_style(
                    base_color="#FFFACD", hover_color="#FFF0A0", pressed_color="#FFE066"
                ))
                ctrl_layout.addWidget(self.btn_calc_downhole)
                # 2. 【核心修改】用一个全局下拉框替换原来的 68/75/76 三个下拉框
                ctrl_layout.addWidget(QLabel("Curve Type:"))
                self.combo_curve_type = QComboBox()
                self.combo_curve_type.addItems(['convex', 'concave'])
                ctrl_layout.addWidget(self.combo_curve_type)

                ctrl_layout.addSpacing(20)
                
                # 3. 重新拟合按钮 (我把它取消注释并加进布局里了，方便用户调完曲线类型后一键重算)
                #self.btn_refit_dh = QPushButton("🔄 重新拟合分馏曲线")
                #ctrl_layout.addWidget(self.btn_refit_dh)
                
                # 4. 下一步按钮
                self.btn_next_step = QPushButton("Next -> Drift")
                self.btn_next_step.setStyleSheet(self.get_button_style(
                    base_color="#D0E8FF", hover_color="#BBDDFF", pressed_color="#99CCFF"
                ))
                ctrl_layout.addWidget(self.btn_next_step)
                
                # 5. 参数展示标签
                self.downhole_params_label = QLabel("Params: N/A")
                self.downhole_params_label.setStyleSheet("color: blue; font-weight: bold; margin-left: 10px;")
                ctrl_layout.addWidget(self.downhole_params_label)

                ctrl_layout.addStretch()
                container_layout.addLayout(ctrl_layout)

# === 年龄分布图 (Scatter) 界面工具栏 ===
            elif name == 'scatter':
                ctrl_layout = QHBoxLayout()
                
                # 1. 年龄类型选择 (原有的)
                ctrl_layout.addWidget(QLabel("Age Type:"))
                self.age_dist_selector = QComboBox()
                self.age_dist_selector.addItems([
                    '206Pb/238U Age', 
                    '207Pb/235U Age', 
                    '207Pb/206Pb Age',
                    'Final Age'
                ])
                ctrl_layout.addWidget(self.age_dist_selector)
                
                ctrl_layout.addSpacing(20)

                # 2. [新增] 样品筛选选择 (Filter Selector)
                ctrl_layout.addWidget(QLabel("Filter:"))
                self.scatter_filter_selector = QComboBox()
                # 添加选项
                self.scatter_filter_selector.addItems([
                    'All Samples', 
                    'Standards', 
                    'Unknowns', 
                    'References'
                ])
                ctrl_layout.addWidget(self.scatter_filter_selector)
                
                ctrl_layout.addStretch()
                container_layout.addLayout(ctrl_layout)
                
                # 创建画布
                container_layout.addWidget(toolbar)
                container_layout.addWidget(canvas)
                
                # 替换占位符
                parent = placeholder.parentWidget()
                layout = parent.layout()
                if layout is None: layout = QVBoxLayout(parent)
                
                if layout.indexOf(placeholder) != -1:
                    layout.replaceWidget(placeholder, container)
                else:
                    layout.addWidget(container)
                placeholder.hide()
                
                # 注册
                self.figures[name] = fig
                self.canvases[name] = canvas
                self.toolbars[name] = toolbar
                continue
            # === 漂移校正界面工具栏 ===
            elif name == 'drift_calib':
                ctrl_layout = QHBoxLayout()
                # [新增] 模式选择下拉框
                ctrl_layout.addWidget(QLabel("Mode:"))
                self.drift_mode_selector = QComboBox()
                self.drift_mode_selector.addItems(['Full Segment', 'Best Segment'])
                ctrl_layout.addWidget(self.drift_mode_selector)
                
                ctrl_layout.addSpacing(10) # 间距
                
                ctrl_layout.addWidget(QLabel("Select Ratio:"))
                self.drift_ratio_selector = QComboBox()
                self.drift_ratio_selector.addItems(['206Pb/238U', '207Pb/235U', '207Pb/206Pb'])
                ctrl_layout.addWidget(self.drift_ratio_selector)

                # 应用校正按钮
                ctrl_layout.addSpacing(20)
                self.btn_apply_drift = QPushButton("Apply Calibration")
                self.btn_apply_drift.setStyleSheet(self.get_button_style(
                    base_color="#d4f1c5", hover_color="#c2e6b1", pressed_color="#a8d492"
                ))
                ctrl_layout.addWidget(self.btn_apply_drift)

                # 下一步按钮
                ctrl_layout.addSpacing(20)
                self.btn_next_concordia = QPushButton("Next -> Concordia")
                self.btn_next_concordia.setStyleSheet(self.get_button_style(
                    base_color="#D0E8FF", hover_color="#BBDDFF", pressed_color="#99CCFF"
                ))
                ctrl_layout.addWidget(self.btn_next_concordia)
                
                ctrl_layout.addSpacing(20)
                self.btn_best_segment = QPushButton("Best Segment")  # 创建新按钮，设置按钮文本为"Best Segment"
                self.btn_best_segment.setStyleSheet(self.get_button_style(
                    base_color="#FFFACD", hover_color="#FFF0A0", pressed_color="#FFE066"
                ))
                ctrl_layout.addWidget(self.btn_best_segment)  # 将新按钮添加到布局中
                # 添加分割间距
                ctrl_layout.addSpacing(20)

                # 新按钮 1: 最佳区间漂移拟合
                self.btn_drift_fit_bseg = QPushButton("Drift Fit (Best Seg)")
                # 使用淡黄色区分最佳区间的功能
                self.btn_drift_fit_bseg.setStyleSheet(self.get_button_style(
                    base_color="#FFFACD", hover_color="#FFF0A0", pressed_color="#FFE066"
                ))
                ctrl_layout.addWidget(self.btn_drift_fit_bseg)

                # 新按钮 2: 最佳区间应用校正
                self.btn_apply_cali_bseg = QPushButton("Apply Cali (Best Seg)")
                self.btn_apply_cali_bseg.setStyleSheet(self.get_button_style(
                    base_color="#FFEC8B", hover_color="#FFD700", pressed_color="#DAA520"
                ))
                ctrl_layout.addWidget(self.btn_apply_cali_bseg)

                ctrl_layout.addStretch()
                container_layout.addLayout(ctrl_layout)


            container_layout.addWidget(toolbar)
            container_layout.addWidget(canvas)

            # 替换 UI 文件中的占位 Widget
            parent = placeholder.parentWidget()
            layout = parent.layout()
            if layout is None:
                layout = QVBoxLayout(parent)

            if layout.indexOf(placeholder) != -1:
                layout.replaceWidget(placeholder, container)
            else:
                layout.addWidget(container)

            placeholder.hide()

            self.figures[name] = fig
            self.canvases[name] = canvas
            self.toolbars[name] = toolbar

        self.results_table = self.findChild(QTableView, 'tableView')
        
        if self.results_table is not None:
            self.results_table.setAlternatingRowColors(True) 
            self.results_table.setStyleSheet("alternate-background-color: #f5f5f5; background-color: white;")
            self.results_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            self.results_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            
            header = self.results_table.horizontalHeader()
            header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
            header.setStretchLastSection(True)
            self.results_table.setSortingEnabled(True)
            
            print("✅ 成功接管 QTableView (Spreadsheet)！")
    def setup_ui_layout(self):
        central_widget = self.centralWidget()
        list_group = self.findChild(QGroupBox, 'groupBox_2')
        btn_group = self.findChild(QGroupBox, 'groupBox')
        tab_widget = self.findChild(QTabWidget, 'tabWidget')
        title_label = self.findChild(QLabel, 'label')

        if not central_widget:
            return

        if central_widget.layout() is None:
            main_layout = QHBoxLayout(central_widget)

            left_layout = QVBoxLayout()
            if list_group:
                left_layout.addWidget(list_group)
                list_group.setSizePolicy(
                    list_group.sizePolicy().horizontalPolicy(),
                    list_group.sizePolicy().verticalPolicy()
                )
            if btn_group:
                left_layout.addWidget(btn_group)
                btn_group.setMaximumHeight(150)

            right_layout = QVBoxLayout()
            if tab_widget:
                right_layout.addWidget(tab_widget)
            if title_label:
                right_layout.addWidget(title_label)
                title_label.setMaximumHeight(40)

            main_layout.addLayout(left_layout, 1)
            main_layout.addLayout(right_layout, 4)

        spreadsheet_tab = self.findChild(QWidget, 'tab_7')
        table_view = self.findChild(QTableView, 'tableView')

        if spreadsheet_tab and table_view:
            if spreadsheet_tab.layout() is None:
                tab_layout = QVBoxLayout(spreadsheet_tab)
                tab_layout.addWidget(table_view)
                tab_layout.setContentsMargins(0, 0, 0, 0)

    def connect_signals(self):
        if self.interactive_button:
            self.interactive_button.clicked.connect(self.interactive_cutoff_requested.emit)
        if self.automatic_button:
            self.automatic_button.clicked.connect(self.auto_cutoff_requested.emit)

        if self.sample_list_widget:
            self.sample_list_widget.itemClicked.connect(self.on_item_clicked)
            self.sample_list_widget.itemExpanded.connect(self.on_item_expanded)
            self.sample_list_widget.itemCollapsed.connect(self.on_item_collapsed)

    def on_item_clicked(self, item, column):
        if item.data(0, Qt.ItemDataRole.UserRole) == 'sample':
            sample_name = item.text(0)
            self.sample_selected.emit(sample_name)

    def on_item_expanded(self, item):
        if item.data(0, Qt.ItemDataRole.UserRole) == 'group':
            group_name = item.text(0).split(' ')[0]
            self.group_expanded.emit(group_name)

    def on_item_collapsed(self, item):
        if item.data(0, Qt.ItemDataRole.UserRole) == 'group':
            group_name = item.text(0).split(' ')[0]
            self.group_collapsed.emit(group_name)

    def update_sample_list(self, samples, sample_types):
        if not self.sample_list_widget:
            return

        self.sample_list_widget.clear()
        groups = {}
        unique_types = []
        for stype in sample_types:
            if stype not in unique_types:
                unique_types.append(stype)
                groups[stype] = []

        for sample, stype in zip(samples, sample_types):
            if stype in groups:
                groups[stype].append(sample)

        for group_name in unique_types:
            group_samples = groups[group_name]
            if not group_samples:
                continue

            group_item = QTreeWidgetItem([f"{group_name} ({len(group_samples)})"])
            group_item.setData(0, Qt.ItemDataRole.UserRole, 'group')

            for sample in sorted(group_samples):
                sample_item = QTreeWidgetItem([sample])
                sample_item.setData(0, Qt.ItemDataRole.UserRole, 'sample')
                group_item.addChild(sample_item)

            self.sample_list_widget.addTopLevelItem(group_item)
        self.sample_list_widget.expandAll()

    def plot_to_view(self, view_name, plot_func, *args, **kwargs):
        if view_name in self.figures:
            fig = self.figures[view_name]
            fig.clear()

            # [关键] 始终创建一个 subplot ax 供绘图函数使用
            ax = fig.add_subplot(111)

            if isinstance(plot_func, tuple):
                plot_func[0](ax, *args, **kwargs)
            else:
                plot_func(ax, *args, **kwargs)

            self.canvases[view_name].draw()

    def show_message(self, title, message, message_type='info'):
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)

        if message_type == 'info':
            msg_box.setIcon(QMessageBox.Icon.Information)
        elif message_type == 'warning':
            msg_box.setIcon(QMessageBox.Icon.Warning)
        elif message_type == 'error':
            msg_box.setIcon(QMessageBox.Icon.Critical)

        msg_box.exec()

    def show_directory_dialog(self, title="Select Directory"):
        from PyQt6.QtWidgets import QFileDialog
        dir_path = QFileDialog.getExistingDirectory(self, title, "")
        return dir_path

    def plot_figure_to_view(self, view_name, plot_func, *args, **kwargs):
        if view_name in self.figures:
            fig = self.figures[view_name]
            fig.clear()

            if isinstance(plot_func, tuple):
                plot_func[0](fig, *args, **kwargs)
            else:
                plot_func(fig, *args, **kwargs)

            self.canvases[view_name].draw()