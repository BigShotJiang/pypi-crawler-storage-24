## 用于自动处理LA-ICP-MS的U-Pb同位素数据 - 设置对话框
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QFormLayout, QLineEdit,
                             QDialogButtonBox, QLabel, QComboBox)
from PyQt6.QtCore import Qt


class SettingsDialog(QDialog):
    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("软件设置")

        # --- 布局 ---
        layout = QVBoxLayout(self)

        # 顶部说明
        description = QLabel("在这里配置样品名称前缀，用于自动分类。")
        description.setWordWrap(True)
        layout.addWidget(description)

        # 表单布局
        form_layout = QFormLayout()

        # --- 样品类型配置 ---
        self.primary_std_edit = QLineEdit()
        self.secondary_stds_edit = QLineEdit()
        self.unknowns_edit = QLineEdit()

        form_layout.addRow("主要标样 (Primary Standard):", self.primary_std_edit)
        form_layout.addRow("次要标样 (Secondary, 逗号隔开):", self.secondary_stds_edit)
        form_layout.addRow("已知样品 (Unknowns, 逗号隔开):", self.unknowns_edit)

        # --- 孔内分馏校正配置 ---
        self.downhole_fit_edit = QComboBox()
        self.downhole_fit_edit.addItems(['convex', 'concave'])
        form_layout.addRow("Downhole拟合曲线 (Fit Curve):", self.downhole_fit_edit)

        layout.addLayout(form_layout)

        # --- OK 和 Cancel 按钮 ---
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)  # 'OK'
        button_box.rejected.connect(self.reject)  # 'Cancel'
        layout.addWidget(button_box)

        # 加载当前配置
        self.load_settings()

    def load_settings(self):
        """从 config 对象加载设置到输入框"""
        # 样品类型
        self.primary_std_edit.setText(self.config.get('SampleTypes', 'primary_standard_prefix', fallback=''))
        self.secondary_stds_edit.setText(self.config.get('SampleTypes', 'secondary_standard_prefixes', fallback=''))
        self.unknowns_edit.setText(self.config.get('SampleTypes', 'unknown_prefixes', fallback=''))

        # 拟合曲线
        curve_type = self.config.get('Analysis', 'downhole_fit_curve', fallback='convex')
        self.downhole_fit_edit.setCurrentText(curve_type)

    def get_settings(self):
        """获取输入框中的新设置"""
        return {
            'SampleTypes': {
                'primary_standard_prefix': self.primary_std_edit.text().strip(),
                'secondary_standard_prefixes': self.secondary_stds_edit.text().strip(),
                'unknown_prefixes': self.unknowns_edit.text().strip(),
            },
            'Analysis': {
                'downhole_fit_curve': self.downhole_fit_edit.currentText()
            }
        }