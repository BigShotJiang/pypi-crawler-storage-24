from setuptools import setup, find_packages

setup(
    name='autoupb',                 # 你的软件库名字
    version='1.0.0',                # 版本号
    packages=find_packages(),       # 自动寻找你的代码包
    entry_points={
        'console_scripts': [
            'autoupb=main:main',    
        ],
    },
)