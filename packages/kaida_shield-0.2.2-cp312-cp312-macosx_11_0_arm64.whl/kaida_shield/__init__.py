"""Kaida Shield"""

__version__ = "0.2.2"

# ── Public API ────────────────────────────────────────────────────────────────

from .shield import Shield, ShieldConfig, ShieldMode

from .policy_engine import (
    Policy,
    PolicyEvaluator,
    PolicyLoader,
    PolicyTemplates,
    Verdict,
)

from .quarantine import QuarantineManager

from .pre_scanner import (
    InputScanner,
    ScanResult,
    ThreatLevel,
)

from .anomaly_detector import AnomalyDetector, AnomalyAlert, AnomalyConfig

# Convenience alias
PolicyEngine = PolicyEvaluator

__all__ = [
    "Shield",
    "ShieldConfig",
    "ShieldMode",
    "Policy",
    "PolicyEvaluator",
    "PolicyEngine",
    "PolicyLoader",
    "PolicyTemplates",
    "Verdict",
    "QuarantineManager",
    "InputScanner",
    "ScanResult",
    "ThreatLevel",
    "AnomalyDetector",
    "AnomalyAlert",
    "AnomalyConfig",
]
