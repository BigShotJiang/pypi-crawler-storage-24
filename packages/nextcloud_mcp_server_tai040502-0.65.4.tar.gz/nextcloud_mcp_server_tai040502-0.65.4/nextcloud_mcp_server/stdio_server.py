"""
Nextcloud MCP Server - STDIO Mode

Simple entrypoint for running the Nextcloud MCP server in stdio mode.
Designed for Docker containers and direct integration with AI assistants.

Environment Variables:
    NEXTCLOUD_HOST: Nextcloud instance URL (required)
    NEXTCLOUD_USERNAME: Nextcloud username (required)
    NEXTCLOUD_PASSWORD: Nextcloud password (required)
    NEXTCLOUD_VERIFY_SSL: Verify SSL certificates (default: true)

Usage:
    python stdio_server.py
"""

import logging
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP

from nextcloud_mcp_server.client import NextcloudClient
from nextcloud_mcp_server.config import setup_logging
from nextcloud_mcp_server.server import (
    configure_calendar_tools,
    configure_contacts_tools,
    configure_cookbook_tools,
    configure_deck_tools,
    configure_news_tools,
    configure_notes_tools,
    configure_sharing_tools,
    configure_tables_tools,
    configure_webdav_tools,
)

# Setup logging to stderr (stdout is reserved for MCP JSON-RPC)
setup_logging()
logger = logging.getLogger(__name__)


def validate_env():
    """Validate required environment variables."""
    required = ["NEXTCLOUD_HOST", "NEXTCLOUD_USERNAME", "NEXTCLOUD_PASSWORD"]
    missing = [var for var in required if not os.environ.get(var)]
    if missing:
        logger.error(
            "Missing required environment variables: %s", ", ".join(missing)
        )
        sys.exit(1)


class StdioAppContext:
    """Application context for stdio BasicAuth mode."""

    def __init__(self, client: NextcloudClient):
        self.client = client


@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[StdioAppContext]:
    """Manage application lifecycle for stdio BasicAuth mode."""
    logger.info("Starting Nextcloud MCP server in stdio mode")
    client = NextcloudClient.from_env()
    logger.info("Nextcloud client initialized successfully")

    try:
        yield StdioAppContext(client=client)
    finally:
        logger.info("Shutting down Nextcloud MCP server")
        await client.close()


def create_server() -> FastMCP:
    """Create and configure the FastMCP server."""
    validate_env()

    mcp = FastMCP(
        "Nextcloud MCP",
        lifespan=app_lifespan,
    )

    # Register all tool modules
    configure_notes_tools(mcp)
    configure_calendar_tools(mcp)
    configure_contacts_tools(mcp)
    configure_webdav_tools(mcp)
    configure_cookbook_tools(mcp)
    configure_deck_tools(mcp)
    configure_tables_tools(mcp)
    configure_sharing_tools(mcp)
    configure_news_tools(mcp)

    logger.info("All Nextcloud tools registered successfully")
    return mcp


def main():
    """Main entrypoint."""
    logger.info("Nextcloud MCP Server (stdio mode)")
    mcp = create_server()
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
