"""Utility functions for the Nextcloud MCP server."""
