# Nextcloud MCP Server (STDIO Mode)

Model Context Protocol (MCP) server for Nextcloud integration - enables AI assistants to interact with Nextcloud data.

This is a **stdio mode** package designed for seamless Python execution (`uv tool run`) or Docker container deployment with AI assistants.

## Features

- **Notes** - Create, read, update, delete, search notes
- **Calendar** - Manage calendar events (CalDAV)
- **Contacts** - Manage contacts (CardDAV)
- **WebDAV** - Upload, download, manage files and folders
- **Deck** - Manage Kanban boards
- **Cookbook** - Manage recipes
- **Tables** - Manage data tables
- **Sharing** - Share files and folders
- **News** - Read RSS feeds

## Local / PyPI Usage (Recommended)

You can run this Server completely free of installation via `uv tool run` (or `uvx`) if `uv` is installed:

```bash
uv tool run nextcloud-mcp-server-tai040502
```

## MCP Client Configuration

For AI assistant integration (Claude Desktop, Gemini, etc.):

#### Using UV
```json
{
  "nextcloud-mcp-server": {
    "command": "uvx",
    "args": [
      "nextcloud-mcp-server-tai040502"
    ],
    "env": {
      "NEXTCLOUD_HOST": "https://your-nextcloud.example.com",
      "NEXTCLOUD_USERNAME": "admin",
      "NEXTCLOUD_PASSWORD": "your-password"
    }
  }
}
```

#### Using Docker
```json
{
  "nextcloud-mcp-server": {
    "command": "docker",
    "args": [
      "run", "-i", "--rm",
      "-e", "NEXTCLOUD_HOST=https://your-nextcloud.example.com",
      "-e", "NEXTCLOUD_USERNAME=admin",
      "-e", "NEXTCLOUD_PASSWORD=your-password",
      "tai040502/nextcloud-mcp-server:latest"
    ]
  }
}
```

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `NEXTCLOUD_HOST` | Yes | Nextcloud instance URL |
| `NEXTCLOUD_USERNAME` | Yes | Nextcloud username |
| `NEXTCLOUD_PASSWORD` | Yes | Nextcloud password |
| `NEXTCLOUD_VERIFY_SSL` | No | Verify SSL certificates (default: `true`) |
