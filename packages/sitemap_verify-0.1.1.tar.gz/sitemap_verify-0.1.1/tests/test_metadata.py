from __future__ import annotations

from pathlib import Path

from sitemap_verify.loader import USER_AGENT


def test_user_agent_version_matches_project_version() -> None:
    pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
    lines = pyproject.read_text(encoding="utf-8").splitlines()
    version_line = next(
        line
        for line in lines
        if line.startswith("version = ")
    )
    project_version = version_line.split('"')[1]

    assert f"sitemap-verify/{project_version} " in USER_AGENT
