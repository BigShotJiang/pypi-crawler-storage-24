from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def _run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "sitemap_verify.cli", *args],
        capture_output=True,
        text=True,
        check=False,
    )


def test_cli_e2e_google_profile_json_output(tmp_path: Path) -> None:
    sitemap = tmp_path / "google-e2e.xml"
    sitemap.write_text(
        """
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
                xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
          <url>
            <loc>https://example.com/gallery</loc>
            <changefreq>daily</changefreq>
            <priority>0.9</priority>
            <image:image />
          </url>
          <url>
            <loc>https://example.com/gallery?ref=feed</loc>
          </url>
        </urlset>
        """,
        encoding="utf-8",
    )

    result = _run_cli(
        "check",
        str(sitemap),
        "--engine",
        "google",
        "--no-check-reachability",
        "--format",
        "json",
        "--no-show-progress",
    )

    assert result.returncode == 1
    payload = json.loads(result.stdout)
    codes = {item["code"] for item in payload["diagnostics"]}
    assert "google_changefreq_ignored" in codes
    assert "google_priority_ignored" in codes
    assert "google_image_missing_loc" in codes
    assert "best_practice_possible_canonical_variant" in codes


def test_cli_e2e_bing_profile_and_resume(tmp_path: Path) -> None:
    sitemap = tmp_path / "bing-e2e.xml"
    store = tmp_path / "bing-e2e.sqlite3"
    sitemap.write_text(
        """
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
          <url>
            <loc>https://example.com/article</loc>
          </url>
        </urlset>
        """,
        encoding="utf-8",
    )

    first = _run_cli(
        "check",
        str(sitemap),
        "--engine",
        "bing",
        "--no-check-reachability",
        "--format",
        "json",
        "--store",
        str(store),
        "--no-show-progress",
    )
    assert first.returncode == 0
    first_payload = json.loads(first.stdout)
    first_codes = {item["code"] for item in first_payload["diagnostics"]}
    assert "bing_lastmod_recommended" in first_codes
    assert "bing_indexnow_recommended" in first_codes

    second = _run_cli(
        "check",
        str(sitemap),
        "--engine",
        "bing",
        "--no-check-reachability",
        "--format",
        "json",
        "--resume-from",
        str(store),
        "--no-show-progress",
    )
    assert second.returncode == 0
    second_payload = json.loads(second.stdout)
    second_codes = {item["code"] for item in second_payload["diagnostics"]}
    assert "bing_lastmod_recommended" in second_codes
    assert "bing_indexnow_recommended" in second_codes
