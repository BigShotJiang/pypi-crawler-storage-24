# Changelog

All notable changes to this project should be documented in this file.

## [Unreleased]

## [0.1.1] - 2026-03-23

- Added SQLite-backed validation persistence to reduce runtime memory growth
- Added `--store` and `--resume-from` support for interrupted run recovery
- Switched final report export to rebuild from persisted SQLite data
- Added persistence and resume regression tests
- Added `google` and `bing` sitemap validation profiles to the CLI and library API
- Added Google image, video, news, and hreflang sitemap extension checks
- Added end-to-end coverage for engine profile output and resume flows
- Fixed Windows SQLite report naming when long targets would exceed practical path limits

## [0.1.0] - 2026-03-13

- Added the initial project skeleton
- Added sitemap validation package and CLI
- Added tests, lint configuration, and GitHub workflow
- Added GitHub issue and pull request templates
