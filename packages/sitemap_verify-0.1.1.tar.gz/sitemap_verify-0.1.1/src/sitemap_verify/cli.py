from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path
from typing import Callable

from .service import validate_target


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate and inspect sitemap targets.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    check = subparsers.add_parser("check", help="Validate a sitemap target")
    check.add_argument("target", help="Local path, URL, or domain")
    check.add_argument("--mode", choices=["auto", "path", "url", "domain"], default="auto")
    check.add_argument(
        "--engine",
        choices=["google", "bing"],
        help="Validate search-engine-specific rules and best practices",
    )
    check.add_argument("--no-recursive", action="store_true")
    check.add_argument("--max-depth", type=int, default=3)
    check.add_argument("--max-sitemaps", type=int, default=200)
    check.add_argument("--check-reachability", dest="check_reachability", action="store_true")
    check.add_argument("--no-check-reachability", dest="check_reachability", action="store_false")
    check.set_defaults(check_reachability=True)
    check.add_argument("--concurrency", type=int, default=20)
    check.add_argument("--timeout", type=float, default=10.0)
    check.add_argument(
        "--probe-method",
        choices=["auto", "head", "get"],
        default="get",
        help="HTTP method strategy for URL reachability checks",
    )
    check.add_argument("--format", choices=["text", "json"], default="text")
    check.add_argument("--output", type=Path, help="Write report to a file path")
    check.add_argument(
        "--store",
        type=Path,
        help="Persist validation data to a SQLite file",
    )
    check.add_argument(
        "--resume-from",
        type=Path,
        help="Resume an interrupted validation from an existing SQLite file",
    )
    check.add_argument("--log-file", type=Path, help="Write runtime logs to a file")
    check.add_argument("--verbose", action="store_true", help="Enable verbose logs")
    check.add_argument(
        "--show-progress",
        dest="show_progress",
        action="store_true",
        help="Print intermediate progress messages to stderr",
    )
    check.add_argument(
        "--no-show-progress",
        dest="show_progress",
        action="store_false",
        help="Disable intermediate progress messages",
    )
    check.set_defaults(show_progress=True)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.command != "check":
        raise ValueError(f"Unsupported command: {args.command}")

    _configure_logging(verbose=args.verbose, log_file=args.log_file)
    progress = _build_progress_callback(enabled=args.show_progress)
    report = asyncio.run(
        validate_target(
            args.target,
            mode=args.mode,
            engine=args.engine,
            recursive=not args.no_recursive,
            max_depth=args.max_depth,
            max_sitemaps=args.max_sitemaps,
            check_reachability=args.check_reachability,
            probe_method=args.probe_method,
            concurrency=args.concurrency,
            timeout=args.timeout,
            store_path=args.store,
            resume_from=args.resume_from,
            progress_callback=progress,
        )
    )

    rendered = _render_report(report=report, output_format=args.format)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
        logging.getLogger(__name__).info("Report written to %s", args.output)

    print(rendered)
    return 1 if report.has_errors else 0


def _render_report(*, report, output_format: str) -> str:
    if output_format == "json":
        return json.dumps(report.model_dump(), indent=2)

    lines: list[str] = [
        f"target: {report.target}",
        f"input_kind: {report.input_kind}",
        f"sitemaps_checked: {report.summary.sitemaps_checked}",
        f"urls_discovered: {report.summary.urls_discovered}",
        f"urls_checked: {report.summary.urls_checked}",
        f"errors: {report.summary.errors}",
        f"warnings: {report.summary.warnings}",
    ]
    if report.diagnostics:
        lines.append("diagnostics:")
        for item in report.diagnostics:
            location = f" [{item.location}]" if item.location else ""
            lines.append(f"- {item.level} {item.code}: {item.message}{location}")

    return "\n".join(lines)


def _configure_logging(*, verbose: bool, log_file: Path | None) -> None:
    handlers: list[logging.Handler] = []
    if verbose:
        handlers.append(logging.StreamHandler(sys.stderr))
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    if not handlers:
        return

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        handlers=handlers,
        force=True,
    )


def _build_progress_callback(*, enabled: bool) -> Callable[[str], None] | None:
    if not enabled:
        return None

    def _printer(message: str) -> None:
        print(f"[progress] {message}", file=sys.stderr)

    return _printer


if __name__ == "__main__":
    raise SystemExit(main())
