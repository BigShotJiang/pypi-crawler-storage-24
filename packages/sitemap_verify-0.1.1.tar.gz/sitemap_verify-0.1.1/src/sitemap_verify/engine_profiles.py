from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from urllib import parse

from lxml import etree

from .models import (
    GOOGLE_IMAGE_NAMESPACE,
    GOOGLE_NEWS_NAMESPACE,
    GOOGLE_VIDEO_NAMESPACE,
    XHTML_NAMESPACE,
    Diagnostic,
    EngineProfile,
    ParsedSitemap,
)


@dataclass(slots=True)
class EngineValidationContext:
    document: ParsedSitemap
    urls: list[str]
    child_sitemaps: list[str]
    robots_discovered: bool = False


def validate_engine_profile(
    engine: EngineProfile | None,
    context: EngineValidationContext,
) -> list[Diagnostic]:
    if engine is None:
        return []
    if engine == "google":
        return _validate_google_profile(context)
    return _validate_bing_profile(context)


def _validate_google_profile(context: EngineValidationContext) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []
    diagnostics.extend(_validate_google_general(context))
    diagnostics.extend(_validate_google_images(context.document))
    diagnostics.extend(_validate_google_videos(context.document))
    diagnostics.extend(_validate_google_news(context.document))
    diagnostics.extend(_validate_google_hreflang(context.document))
    return diagnostics


def _validate_bing_profile(context: EngineValidationContext) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []
    for entry in context.document.entries:
        location = entry.location
        if entry.lastmod is None and context.document.kind == "urlset":
            diagnostics.append(
                Diagnostic(
                    level="warn",
                    code="bing_lastmod_recommended",
                    message=(
                        "Bing recommends accurate lastmod values and prefers "
                        "precise freshness signals."
                    ),
                    location=location,
                )
            )
        if entry.changefreq:
            diagnostics.append(
                Diagnostic(
                    level="warn",
                    code="bing_changefreq_low_value",
                    message="Bing largely ignores changefreq; rely on accurate lastmod instead.",
                    location=location,
                )
            )
        if entry.priority:
            diagnostics.append(
                Diagnostic(
                    level="warn",
                    code="bing_priority_low_value",
                    message="Bing largely ignores priority values in sitemaps.",
                    location=location,
                )
            )

    if context.document.kind == "urlset" and context.urls:
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="bing_indexnow_recommended",
                message=(
                    "Bing recommends pairing sitemaps with IndexNow for "
                    "faster discovery of added, updated, or deleted URLs."
                ),
                location=context.document.source,
            )
        )

    return diagnostics


def _validate_google_general(context: EngineValidationContext) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []
    normalized_urls: dict[tuple[str, str, str], list[str]] = {}

    for entry in context.document.entries:
        if entry.changefreq:
            diagnostics.append(
                Diagnostic(
                    level="warn",
                    code="google_changefreq_ignored",
                    message="Google ignores changefreq values in sitemaps.",
                    location=entry.location,
                )
            )
        if entry.priority:
            diagnostics.append(
                Diagnostic(
                    level="warn",
                    code="google_priority_ignored",
                    message="Google ignores priority values in sitemaps.",
                    location=entry.location,
                )
            )
        if context.document.kind == "urlset" and not entry.lastmod:
            diagnostics.append(
                Diagnostic(
                    level="warn",
                    code="google_lastmod_recommended",
                    message=(
                        "Google recommends lastmod when it is consistently "
                        "and verifiably accurate."
                    ),
                    location=entry.location,
                )
            )
        if not entry.loc:
            continue
        key = _canonical_variant_key(entry.loc)
        normalized_urls.setdefault(key, []).append(entry.loc)

    for variants in normalized_urls.values():
        unique_variants = sorted(set(variants))
        if len(unique_variants) <= 1:
            continue
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="best_practice_possible_canonical_variant",
                message=(
                    "Sitemap includes multiple URL variants that may "
                    "represent the same canonical page; "
                    "Google recommends listing preferred canonical URLs only."
                ),
                location=unique_variants[0],
            )
        )

    if len(context.urls) >= 45_000:
        diagnostics.append(
            Diagnostic(
                level="warn",
                code="google_large_sitemap_recommend_index",
                message=(
                    "Google recommends splitting large sitemap sets with a "
                    "sitemap index before reaching file limits."
                ),
                location=context.document.source,
            )
        )

    return diagnostics


def _validate_google_images(document: ParsedSitemap) -> list[Diagnostic]:
    root = document.xml_root
    if root is None:
        return []

    diagnostics: list[Diagnostic] = []
    ns = {"sm": root.nsmap.get(None), "image": GOOGLE_IMAGE_NAMESPACE}
    for url_index, url_node in enumerate(root.findall("sm:url", namespaces=ns), start=1):
        image_nodes = url_node.findall("image:image", namespaces=ns)
        if len(image_nodes) > 1000:
            diagnostics.append(
                Diagnostic(
                    level="error",
                    code="google_image_too_many_entries",
                    message="A single URL entry may include at most 1000 image:image tags.",
                    location=f"{document.source}::url[{url_index}]",
                )
            )
        for image_index, image_node in enumerate(image_nodes, start=1):
            location = f"{document.source}::url[{url_index}]::image[{image_index}]"
            image_loc = _child_text(image_node, GOOGLE_IMAGE_NAMESPACE, "loc")
            if not image_loc:
                diagnostics.append(
                    Diagnostic(
                        level="error",
                        code="google_image_missing_loc",
                        message="Google image sitemap entries require image:loc.",
                        location=location,
                    )
                )
            for deprecated in ("caption", "geo_location", "title", "license"):
                if _has_child(image_node, GOOGLE_IMAGE_NAMESPACE, deprecated):
                    diagnostics.append(
                        Diagnostic(
                            level="warn",
                            code=f"google_image_deprecated_{deprecated}",
                            message=(
                                f"Google no longer documents image:{deprecated} "
                                "and recommends removing it."
                            ),
                            location=location,
                        )
                    )
    return diagnostics


def _validate_google_videos(document: ParsedSitemap) -> list[Diagnostic]:
    root = document.xml_root
    if root is None:
        return []

    diagnostics: list[Diagnostic] = []
    ns = {"sm": root.nsmap.get(None), "video": GOOGLE_VIDEO_NAMESPACE}
    for url_index, url_node in enumerate(root.findall("sm:url", namespaces=ns), start=1):
        page_loc = _child_text(url_node, root.nsmap.get(None), "loc")
        video_nodes = url_node.findall("video:video", namespaces=ns)
        for video_index, video_node in enumerate(video_nodes, start=1):
            location = f"{document.source}::url[{url_index}]::video[{video_index}]"
            if not _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, "thumbnail_loc"):
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_missing_thumbnail",
                        "Google video sitemap entries require video:thumbnail_loc.",
                        location,
                    )
                )
            if not _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, "title"):
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_missing_title",
                        "Google video sitemap entries require video:title.",
                        location,
                    )
                )
            description = _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, "description")
            if not description:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_missing_description",
                        "Google video sitemap entries require video:description.",
                        location,
                    )
                )
            elif len(description) > 2048:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_description_too_long",
                        "Google limits video:description to 2048 characters.",
                        location,
                    )
                )

            content_loc = _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, "content_loc")
            player_loc = _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, "player_loc")
            if not content_loc and not player_loc:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_missing_content_or_player",
                        (
                            "Google video sitemap entries require either "
                            "video:content_loc or video:player_loc."
                        ),
                        location,
                    )
                )
            if page_loc and content_loc and content_loc == page_loc:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_content_matches_page",
                        "video:content_loc must not match the parent loc URL.",
                        location,
                    )
                )
            if page_loc and player_loc and player_loc == page_loc:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_player_matches_page",
                        "video:player_loc must not match the parent loc URL.",
                        location,
                    )
                )

            duration = _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, "duration")
            if duration and not _int_in_range(duration, 1, 28_800):
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_invalid_duration",
                        "video:duration must be an integer from 1 to 28800 seconds.",
                        location,
                    )
                )

            rating = _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, "rating")
            if rating and not _float_in_range(rating, 0.0, 5.0):
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_invalid_rating",
                        "video:rating must be a float between 0.0 and 5.0.",
                        location,
                    )
                )

            for field_name in ("family_friendly", "requires_subscription", "live"):
                value = _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, field_name)
                if value and value not in {"yes", "no"}:
                    diagnostics.append(
                        _diag(
                            "error",
                            f"google_video_invalid_{field_name}",
                            f"video:{field_name} must be yes or no.",
                            location,
                        )
                    )

            uploader = _child_text(video_node, GOOGLE_VIDEO_NAMESPACE, "uploader")
            if uploader and len(uploader) > 255:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_uploader_too_long",
                        "video:uploader must not exceed 255 characters.",
                        location,
                    )
                )

            tag_count = len(video_node.findall(f"{{{GOOGLE_VIDEO_NAMESPACE}}}tag"))
            if tag_count > 32:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_video_too_many_tags",
                        "Google allows at most 32 video:tag values per video.",
                        location,
                    )
                )

            restriction = video_node.find(f"{{{GOOGLE_VIDEO_NAMESPACE}}}restriction")
            if restriction is not None:
                relationship = (restriction.get("relationship") or "").strip()
                if relationship not in {"allow", "deny"}:
                    diagnostics.append(
                        _diag(
                            "error",
                            "google_video_invalid_restriction_relationship",
                            "video:restriction requires relationship=allow or deny.",
                            location,
                        )
                    )

            platform = video_node.find(f"{{{GOOGLE_VIDEO_NAMESPACE}}}platform")
            if platform is not None:
                relationship = (platform.get("relationship") or "").strip()
                if relationship not in {"allow", "deny"}:
                    diagnostics.append(
                        _diag(
                            "error",
                            "google_video_invalid_platform_relationship",
                            "video:platform requires relationship=allow or deny.",
                            location,
                        )
                    )
                supported = {"web", "mobile", "tv"}
                actual = {part for part in (platform.text or "").split() if part}
                if actual and not actual.issubset(supported):
                    diagnostics.append(
                        _diag(
                            "error",
                            "google_video_invalid_platform_values",
                            "video:platform only supports web, mobile, and tv values.",
                            location,
                        )
                    )

            for deprecated in ("category", "gallery_loc", "price", "tvshow"):
                if _has_child(video_node, GOOGLE_VIDEO_NAMESPACE, deprecated):
                    diagnostics.append(
                        _diag(
                            "warn",
                            f"google_video_deprecated_{deprecated}",
                            (
                                f"Google no longer documents video:{deprecated} "
                                "and recommends removing it."
                            ),
                            location,
                        )
                    )
    return diagnostics


def _validate_google_news(document: ParsedSitemap) -> list[Diagnostic]:
    root = document.xml_root
    if root is None:
        return []

    diagnostics: list[Diagnostic] = []
    ns = {"sm": root.nsmap.get(None), "news": GOOGLE_NEWS_NAMESPACE}
    news_nodes = root.findall("sm:url/news:news", namespaces=ns)
    if len(news_nodes) > 1000:
        diagnostics.append(
            Diagnostic(
                level="error",
                code="google_news_too_many_entries",
                message="A Google news sitemap may contain at most 1000 news:news entries.",
                location=document.source,
            )
        )

    now = datetime.now(timezone.utc)
    for url_index, url_node in enumerate(root.findall("sm:url", namespaces=ns), start=1):
        news_entries = url_node.findall("news:news", namespaces=ns)
        if len(news_entries) > 1:
            diagnostics.append(
                _diag(
                    "error",
                    "google_news_multiple_entries",
                    "Each URL may include at most one news:news element.",
                    f"{document.source}::url[{url_index}]",
                )
            )
        for news_index, news_node in enumerate(news_entries, start=1):
            location = f"{document.source}::url[{url_index}]::news[{news_index}]"
            publication = news_node.find(f"{{{GOOGLE_NEWS_NAMESPACE}}}publication")
            if publication is None:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_news_missing_publication",
                        "Google news entries require news:publication.",
                        location,
                    )
                )
                continue
            name = _child_text(publication, GOOGLE_NEWS_NAMESPACE, "name")
            if not name:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_news_missing_name",
                        "Google news entries require news:name.",
                        location,
                    )
                )
            language = _child_text(publication, GOOGLE_NEWS_NAMESPACE, "language")
            if not language:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_news_missing_language",
                        "Google news entries require news:language.",
                        location,
                    )
                )
            elif not _is_valid_news_language(language):
                diagnostics.append(
                    _diag(
                        "error",
                        "google_news_invalid_language",
                        (
                            "news:language must use supported ISO 639 language "
                            "codes; use zh-cn or zh-tw for Chinese news sitemaps."
                        ),
                        location,
                    )
                )

            publication_date = _child_text(news_node, GOOGLE_NEWS_NAMESPACE, "publication_date")
            if not publication_date:
                diagnostics.append(
                    _diag(
                        "error",
                        "google_news_missing_publication_date",
                        "Google news entries require news:publication_date.",
                        location,
                    )
                )
            else:
                parsed_date = _parse_w3c_datetime(publication_date)
                if parsed_date is None:
                    diagnostics.append(
                        _diag(
                            "error",
                            "google_news_invalid_publication_date",
                            "news:publication_date must be a valid W3C datetime value.",
                            location,
                        )
                    )
                elif parsed_date < now - timedelta(days=2):
                    diagnostics.append(
                        _diag(
                            "warn",
                            "google_news_outdated_article",
                            (
                                "Google recommends keeping only the last two days "
                                "of articles in a news sitemap or removing the "
                                "news metadata from older entries."
                            ),
                            location,
                        )
                    )

            if not _child_text(news_node, GOOGLE_NEWS_NAMESPACE, "title"):
                diagnostics.append(
                    _diag(
                        "error",
                        "google_news_missing_title",
                        "Google news entries require news:title.",
                        location,
                    )
                )
    return diagnostics


def _validate_google_hreflang(document: ParsedSitemap) -> list[Diagnostic]:
    root = document.xml_root
    if root is None:
        return []

    diagnostics: list[Diagnostic] = []
    ns = {"sm": root.nsmap.get(None), "xhtml": XHTML_NAMESPACE}
    url_nodes = root.findall("sm:url", namespaces=ns)
    if not url_nodes:
        return diagnostics

    href_map: dict[str, set[str]] = {}
    for url_index, url_node in enumerate(url_nodes, start=1):
        loc = _child_text(url_node, root.nsmap.get(None), "loc")
        if not loc:
            continue
        alternates: set[str] = set()
        for link_node in url_node.findall("xhtml:link", namespaces=ns):
            href = (link_node.get("href") or "").strip()
            rel = (link_node.get("rel") or "").strip()
            hreflang = (link_node.get("hreflang") or "").strip()
            location = f"{document.source}::url[{url_index}]::xhtml:link"
            if rel != "alternate":
                diagnostics.append(
                    _diag(
                        "error",
                        "google_hreflang_invalid_rel",
                        (
                            "xhtml:link entries in sitemap hreflang annotations "
                            "must use rel=alternate."
                        ),
                        location,
                    )
                )
            if not href or not _is_absolute_url(href):
                diagnostics.append(
                    _diag(
                        "error",
                        "google_hreflang_invalid_href",
                        "hreflang sitemap links must use fully-qualified absolute URLs.",
                        location,
                    )
                )
                continue
            if not hreflang or not _is_valid_hreflang(hreflang):
                diagnostics.append(
                    _diag(
                        "error",
                        "google_hreflang_invalid_code",
                        (
                            "hreflang values in sitemap links must use valid "
                            "language-region codes or x-default."
                        ),
                        location,
                    )
                )
            alternates.add(href)
        if alternates and loc not in alternates:
            diagnostics.append(
                _diag(
                    "warn",
                    "google_hreflang_missing_self_reference",
                    "Google recommends each hreflang cluster include the current URL itself.",
                    f"{document.source}::url[{url_index}]",
                )
            )
        href_map[loc] = alternates

    for loc, alternates in href_map.items():
        for href in alternates:
            target_links = href_map.get(href)
            if target_links is None:
                continue
            if loc not in target_links:
                diagnostics.append(
                    Diagnostic(
                        level="warn",
                        code="google_hreflang_missing_return_link",
                        message=(
                            "Google may ignore hreflang annotations without "
                            "reciprocal return links."
                        ),
                        location=loc,
                    )
                )
                break
    return diagnostics


def _diag(level: str, code: str, message: str, location: str) -> Diagnostic:
    return Diagnostic(level=level, code=code, message=message, location=location)


def _child_text(node: etree._Element, namespace: str | None, local_name: str) -> str:
    tag = f"{{{namespace}}}{local_name}" if namespace else local_name
    child = node.find(tag)
    if child is None or child.text is None:
        return ""
    return child.text.strip()


def _has_child(node: etree._Element, namespace: str, local_name: str) -> bool:
    return node.find(f"{{{namespace}}}{local_name}") is not None


def _int_in_range(value: str, minimum: int, maximum: int) -> bool:
    try:
        parsed = int(value)
    except ValueError:
        return False
    return minimum <= parsed <= maximum


def _float_in_range(value: str, minimum: float, maximum: float) -> bool:
    try:
        parsed = float(value)
    except ValueError:
        return False
    return minimum <= parsed <= maximum


def _canonical_variant_key(url: str) -> tuple[str, str, str]:
    parsed = parse.urlsplit(url)
    host = (parsed.hostname or parsed.netloc).lower()
    path = parsed.path.rstrip("/") or "/"
    return host, path, parsed.fragment


def _parse_w3c_datetime(value: str) -> datetime | None:
    cleaned = value.strip()
    if not cleaned:
        return None
    try:
        if len(cleaned) == 10:
            return datetime.fromisoformat(cleaned).replace(tzinfo=timezone.utc)
        return datetime.fromisoformat(cleaned.replace("Z", "+00:00"))
    except ValueError:
        return None


def _is_valid_news_language(value: str) -> bool:
    candidate = value.lower()
    if candidate in {"zh-cn", "zh-tw"}:
        return True
    parts = candidate.split("-")
    if not 1 <= len(parts) <= 2:
        return False
    if not parts[0].isalpha() or not 2 <= len(parts[0]) <= 3:
        return False
    if len(parts) == 2 and not (parts[1].isalpha() and len(parts[1]) == 2):
        return False
    return True


def _is_valid_hreflang(value: str) -> bool:
    candidate = value.lower()
    if candidate == "x-default":
        return True
    parts = candidate.split("-")
    if len(parts) == 1:
        return parts[0].isalpha() and len(parts[0]) in {2, 3}
    if len(parts) == 2:
        return parts[0].isalpha() and len(parts[0]) in {2, 3} and parts[1].isalnum()
    if len(parts) == 3:
        return (
            parts[0].isalpha()
            and len(parts[0]) in {2, 3}
            and parts[1].isalnum()
            and parts[2].isalnum()
        )
    return False


def _is_absolute_url(value: str) -> bool:
    parsed = parse.urlsplit(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)
