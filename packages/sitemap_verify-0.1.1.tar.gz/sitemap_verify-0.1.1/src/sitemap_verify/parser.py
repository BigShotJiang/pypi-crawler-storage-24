from __future__ import annotations

import feedparser
from lxml import etree

from .models import (
    GOOGLE_IMAGE_NAMESPACE,
    GOOGLE_NEWS_NAMESPACE,
    GOOGLE_VIDEO_NAMESPACE,
    XHTML_NAMESPACE,
    DocumentKind,
    ParsedSitemap,
    SitemapEntry,
)

SUPPORTED_EXTENSION_NAMESPACES = {
    GOOGLE_IMAGE_NAMESPACE,
    GOOGLE_VIDEO_NAMESPACE,
    GOOGLE_NEWS_NAMESPACE,
    XHTML_NAMESPACE,
}


def parse_sitemap_document(
    content: str,
    *,
    source: str,
    uncompressed_size: int,
    is_gzipped: bool,
) -> ParsedSitemap:
    stripped = content.lstrip()
    if stripped.startswith("<"):
        return _parse_xml_document(
            content,
            source=source,
            uncompressed_size=uncompressed_size,
            is_gzipped=is_gzipped,
        )

    return _parse_text_document(
        content,
        source=source,
        uncompressed_size=uncompressed_size,
        is_gzipped=is_gzipped,
    )


def _parse_xml_document(
    content: str,
    *,
    source: str,
    uncompressed_size: int,
    is_gzipped: bool,
) -> ParsedSitemap:
    try:
        root = etree.fromstring(content.encode("utf-8"))
    except etree.XMLSyntaxError as exc:
        raise ValueError(f"Invalid XML: {exc}") from exc

    root_name = _local_name(root.tag)
    namespace = _namespace(root.tag)
    if root_name in {"urlset", "sitemapindex"}:
        return _parse_sitemap_xml(
            root,
            source=source,
            uncompressed_size=uncompressed_size,
            is_gzipped=is_gzipped,
            root_name=root_name,
            namespace=namespace,
        )
    if root_name in {"rss", "feed"}:
        return _parse_feed_document(
            content,
            source=source,
            uncompressed_size=uncompressed_size,
            is_gzipped=is_gzipped,
            explicit_kind="rss" if root_name == "rss" else "atom",
        )

    raise ValueError(
        "Unsupported sitemap root element. Expected urlset, sitemapindex, rss, or feed."
    )


def _parse_sitemap_xml(
    root: etree._Element,
    *,
    source: str,
    uncompressed_size: int,
    is_gzipped: bool,
    root_name: str,
    namespace: str | None,
) -> ParsedSitemap:
    kind: DocumentKind = "urlset" if root_name == "urlset" else "sitemapindex"

    item_tag = "url" if root_name == "urlset" else "sitemap"
    allowed_fields = {"loc", "lastmod"} if root_name == "sitemapindex" else {
        "loc",
        "lastmod",
        "changefreq",
        "priority",
    }
    entries: list[SitemapEntry] = []
    unknown_tags: list[str] = []

    for index, child in enumerate(root, start=1):
        child_name = _local_name(child.tag)
        if child_name != item_tag:
            unknown_tags.append(child_name)
            continue

        entry = SitemapEntry(location=f"{source}::{item_tag}[{index}]")
        seen_fields: set[str] = set()
        for grandchild in child:
            field_name = _local_name(grandchild.tag)
            field_value = (grandchild.text or "").strip()
            field_namespace = _namespace(grandchild.tag)
            if field_namespace in SUPPORTED_EXTENSION_NAMESPACES:
                continue
            if field_name not in allowed_fields:
                entry.unknown_tags.append(field_name)
                continue
            if field_name in seen_fields:
                entry.duplicate_fields.append(field_name)
                continue

            seen_fields.add(field_name)
            if field_name == "loc":
                entry.loc = field_value
                entry.has_loc = True
            elif field_name == "lastmod":
                entry.lastmod = field_value
            elif field_name == "changefreq":
                entry.changefreq = field_value
            elif field_name == "priority":
                entry.priority = field_value

        entries.append(entry)

    return ParsedSitemap(
        kind=kind,
        source=source,
        entries=entries,
        namespace=namespace,
        uncompressed_size=uncompressed_size,
        is_gzipped=is_gzipped,
        unknown_tags=unknown_tags,
        xml_root=root,
    )


def _parse_text_document(
    content: str,
    *,
    source: str,
    uncompressed_size: int,
    is_gzipped: bool,
) -> ParsedSitemap:
    entries: list[SitemapEntry] = []
    for line_number, line in enumerate(content.splitlines(), start=1):
        value = line.strip()
        if not value:
            continue
        entries.append(
            SitemapEntry(
                location=f"{source}::line[{line_number}]",
                loc=value,
                has_loc=True,
            )
        )

    return ParsedSitemap(
        kind="text",
        source=source,
        entries=entries,
        uncompressed_size=uncompressed_size,
        is_gzipped=is_gzipped,
    )


def _parse_feed_document(
    content: str,
    *,
    source: str,
    uncompressed_size: int,
    is_gzipped: bool,
    explicit_kind: DocumentKind,
) -> ParsedSitemap:
    feed = feedparser.parse(content)
    entries: list[SitemapEntry] = []
    kind: DocumentKind = explicit_kind

    if feed.version.startswith("atom"):
        kind = "atom"
    elif feed.version.startswith("rss"):
        kind = "rss"

    for index, item in enumerate(feed.entries, start=1):
        value = (item.get("link") or "").strip()
        entries.append(
            SitemapEntry(
                location=f"{source}::entry[{index}]",
                loc=value,
                has_loc=True,
                lastmod=(item.get("updated") or item.get("published") or None),
            )
        )

    return ParsedSitemap(
        kind=kind,
        source=source,
        entries=entries,
        uncompressed_size=uncompressed_size,
        is_gzipped=is_gzipped,
    )


def _local_name(tag: str) -> str:
    if tag.startswith("{"):
        return tag.rsplit("}", 1)[-1]
    return tag


def _namespace(tag: str) -> str | None:
    if tag.startswith("{"):
        return tag[1:].split("}", 1)[0]
    return None
