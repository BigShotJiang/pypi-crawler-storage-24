# 2026-03-24-uv-lock-environment-drift

## Summary

Release alignment work accidentally committed environment-specific `uv.lock` source URL rewrites after running `uv` on a machine configured with a mirror index. The fix removed that history, restored the lockfile, and documented stricter checks before commit.

## What Went Wrong

- Ran `uv` during a version-alignment task that did not explicitly require dependency or lockfile updates.
- Allowed `uv.lock` to be staged even though the diff only reflected environment-specific registry drift.
- Created a release PR whose lockfile changes were unrelated to the intended version metadata fix.

## Root Cause

- Failed to separate package execution/build verification from dependency-lock maintenance.
- Missed that local `uv` index configuration can rewrite `uv.lock` source and artifact URLs without any real dependency change.
- Did not perform a final lockfile-specific diff review before commit.

## Correct Fix

- Rewrote the release branch history to remove the bad commit that included `uv.lock` mirror URL changes.
- Reapplied only the intended release metadata updates without carrying any lockfile diff.
- Added this lesson so future changes treat `uv.lock` as sensitive to environment drift.

## Prevention Checklist

- Unless the task explicitly requires lockfile or dependency resolution updates, do not include `uv`-generated `uv.lock` changes in the commit.
- Before every commit, inspect `uv.lock` separately; if the diff only shows environment-specific source URL drift, restore the file.
- Treat registry URL rewrites in `uv.lock` as suspicious until confirmed to be intentionally required by the task.
- Keep version-metadata fixes scoped to project files such as `pyproject.toml`, runtime version strings, and changelog entries.

## Signals To Notice Earlier

- The task only asked for version alignment, not dependency upgrades or lock refresh.
- `uv.lock` changed hundreds of lines while package versions stayed the same.
- The diff replaced `https://pypi.org/simple` with a machine-specific mirror URL, indicating environment influence rather than project intent.

## Related Files

- `uv.lock`
- `pyproject.toml`
- `src/sitemap_verify/loader.py`
- `docs/agent-lessons/2026-03-24-uv-lock-environment-drift.md`
