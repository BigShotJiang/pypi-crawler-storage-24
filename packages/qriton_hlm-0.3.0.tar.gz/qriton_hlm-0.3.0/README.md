# Qriton HLM — Energy Language

**Program neural networks by shaping energy landscapes.**

The first tool that lets you directly program a neural network's behavior —
not train, not fine-tune, not prompt-engineer. **Program.**

```
$ qriton-hlm -c model.pt

hlm:model> capture 5 polite Thank you so much for your help
  Captured L5: "Thank you so much for your help"
  Energy: -12.34 | Basin: True (cos=0.97, 23 iters)
  -> Added to concept 'polite' (1 samples)

hlm:model> capture 5 polite I really appreciate your patience
  -> Added to concept 'polite' (2 samples)

hlm:model> inject-concept 5 polite 0.1
  Before: 200 basins, concept is basin: False
  After:  201 basins (+1), concept is basin: True
  >> Concept successfully injected!

hlm:model> apply 5
hlm:model> generate Tell me about the weather
  I'd be happy to share! The weather today is...
```

## Install

```bash
pip install qriton-hlm
```

## What is this?

Every AI framework today has one way to change model behavior: **training**.
Qriton HLM adds a second: **surgery**.

| Operation | What it does |
|-----------|-------------|
| `capture` | Extract what a concept looks like in the model's brain |
| `inject-concept` | Program a captured concept as a new attractor |
| `remove-concept` | Remove a concept from the model |
| `survey` | Map all attractors in a layer |
| `inject` / `remove` / `move` | Low-level basin manipulation |

This only works because HLM uses polynomial Hopfield dynamics that create
**multiple stable basins** per layer. Transformers can't do this — their
softmax attention collapses to a single attractor.

## CLI Commands

```
load <path>                           Load a checkpoint
info                                  Show model info
survey <layer>                        Find all basins in a layer
survey-all                            Survey every layer
capture <layer> <concept> <text>      Capture a concept from text
inject-concept <layer> <concept> [s]  Inject captured concept as basin
remove-concept <layer> <concept> [s]  Remove captured concept
concepts                              List captured concepts
inject <layer> <seed> [str]           Low-level: inject basin at seed
remove <layer> <seed> [str]           Low-level: remove closest basin
move <layer> <seed> [str]             Low-level: move closest basin
verify <layer> <seed>                 Check if target is a basin
apply <layer>                         Write modified W to live model
restore <layer>                       Undo modifications
restore-all                           Restore all layers
status                                Show which layers are modified
generate <prompt>                     Generate text with current model
set <param> <value>                   Set parameter (beta, strength, ...)
diff <layer>                          Show W matrix change stats
save <path>                           Save modified W matrices
history                               Show operation log
```

## Python API

```python
from qriton_hlm import BasinSurgeon

surgeon = BasinSurgeon.from_checkpoint("model.pt", device="cuda")

# Capture what a concept looks like in the model
surgeon.capture(layer=5, text="Thank you so much", concept_name="polite")
surgeon.capture(layer=5, text="I really appreciate it", concept_name="polite")

# Inject that concept as a new attractor
result = surgeon.inject_concept(layer=5, concept_name="polite", strength=0.1)
print(f"Concept injected: {result['exists_after']}")

# Apply to live model and generate
surgeon.apply(layer=5)
```

## Compatibility

Works with any PyTorch checkpoint that contains `hopfield.W` parameters:
- HLM2/HLM3 language models
- HLM-Spatial (LIDAR, Medical3D, Industrial3D)
- HLM-Audio (STT, TTS)
- Any model using PolyHopfieldLayer

## Requirements

- Python >= 3.9
- PyTorch >= 2.0
- NumPy

## License

Apache 2.0 — Qriton Technologies S.R.L.
