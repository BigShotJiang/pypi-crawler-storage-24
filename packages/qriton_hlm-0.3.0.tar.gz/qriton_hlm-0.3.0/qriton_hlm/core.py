"""
qriton_hlm.core — Basin surgery for polynomial Hopfield networks.

No external dependencies beyond torch and numpy.
Works with any checkpoint that has `hopfield.W` parameters.
"""

import time

import numpy as np
import torch
import torch.nn.functional as F


# ── Polynomial interaction ───────────────────────────────────────────

def poly_interaction(x, degree=3):
    """Polynomial interaction function for Hopfield dynamics."""
    return torch.sign(x) * torch.abs(x) ** (degree - 1)


# ── Energy computation ──────────────────────────────────────────────

def compute_energy(x, W, degree=3):
    """Compute Hopfield energy at state x. Lower = more stable."""
    fx = poly_interaction(x, degree)
    kinetic = -1.0 / degree * torch.sum(torch.abs(x) ** degree)
    potential = 0.5 * x @ W @ fx
    return (kinetic + potential).item()


# ── Basin discovery ──────────────────────────────────────────────────

def find_basins(W, d_model, degree=3, num_inits=200, max_iter=100,
                tau_start=0.9, tau_end=0.1, beta=7.0, eps=5e-3,
                device='cpu'):
    """Discover basins by converging from random initial states.

    Returns: (unique_basins, basin_ids, trajectories)
    """
    basins = []
    trajectories = []

    for i in range(num_inits):
        x = torch.randn(d_model, device=device)
        x = x / x.norm()

        trajectory = [x.clone()]
        for t in range(max_iter):
            tau = tau_start + (tau_end - tau_start) * (t / max_iter)
            fx = poly_interaction(x, degree)
            h = W @ fx
            x_new = (1 - tau) * x + tau * torch.tanh(beta * h)
            trajectory.append(x_new.clone())

            delta = (x_new - x).norm() / (x.norm() + 1e-8)
            if delta < eps:
                break
            x = x_new

        basins.append(x.detach())
        trajectories.append(trajectory)

    # Cluster basins by cosine similarity
    unique_basins = []
    basin_ids = []
    for b in basins:
        found = False
        for j, ub in enumerate(unique_basins):
            cos_sim = F.cosine_similarity(
                b.unsqueeze(0), ub.unsqueeze(0)).item()
            if cos_sim > 0.95:
                basin_ids.append(j)
                found = True
                break
        if not found:
            basin_ids.append(len(unique_basins))
            unique_basins.append(b)

    return unique_basins, basin_ids, trajectories


# ── Basin surgery operations ─────────────────────────────────────────

def inject_basin(W, target, degree=3, strength=1.0):
    """Inject a new basin at target point."""
    target = target / target.norm()
    ft = poly_interaction(target, degree)
    w_scale = torch.linalg.norm(W, ord=2).item()
    return W + strength * w_scale * torch.outer(ft, target)


def remove_basin(W, target, degree=3, strength=1.0):
    """Remove/weaken a basin at target point."""
    target = target / target.norm()
    ft = poly_interaction(target, degree)
    w_scale = torch.linalg.norm(W, ord=2).item()
    return W - strength * w_scale * torch.outer(ft, target)


def move_basin(W, source, destination, degree=3, strength=1.0):
    """Move a basin from source to destination.

    Equivalent to remove(source) + inject(destination).
    """
    W = remove_basin(W, source, degree, strength)
    W = inject_basin(W, destination, degree, strength)
    return W


# ── Verification ─────────────────────────────────────────────────────

def verify_basin_exists(W, target, degree=3, max_iter=100,
                        tau_start=0.9, tau_end=0.1, beta=7.0,
                        eps=5e-3, cos_threshold=0.9):
    """Verify that a basin exists near target.

    Initializes near target with small perturbation and checks
    if convergence returns to target (cos_sim > threshold).

    Returns: (is_basin: bool, final_state, cos_similarity, num_iters)
    """
    target = target / target.norm()
    x = target + 0.1 * torch.randn_like(target)
    x = x / x.norm()

    for t in range(max_iter):
        tau = tau_start + (tau_end - tau_start) * (t / max_iter)
        fx = poly_interaction(x, degree)
        h = W @ fx
        x_new = (1 - tau) * x + tau * torch.tanh(beta * h)

        delta = (x_new - x).norm() / (x.norm() + 1e-8)
        if delta < eps:
            break
        x = x_new

    cos_sim = F.cosine_similarity(
        x.unsqueeze(0), target.unsqueeze(0)).item()
    return cos_sim > cos_threshold, x, cos_sim, t + 1


# ── Checkpoint loading ───────────────────────────────────────────────

def load_W_from_checkpoint(checkpoint_path, layer=0, device='cpu'):
    """Extract weight matrix W from any checkpoint with hopfield.W keys.

    Works with HLM2, HLM3, HLM-Spatial, HLM-Audio, or any model
    that uses PolyHopfieldLayer.

    Returns: (W tensor, d_model int)
    """
    ckpt = torch.load(checkpoint_path, map_location=device, weights_only=False)
    state = ckpt.get('model_state', ckpt.get('model', ckpt))

    w_key = f'blocks.{layer}.hopfield.W'
    if w_key not in state:
        for key in state:
            if f'.{layer}.' in key and '.W' in key and 'hopfield' in key:
                w_key = key
                break
        else:
            available = [k for k in state if 'W' in k and 'hopfield' in k]
            raise KeyError(f"W not found at {w_key}. Available: {available}")

    W = state[w_key].to(device)
    return W, W.shape[0]


def count_hopfield_layers(checkpoint_path):
    """Count number of Hopfield layers in a checkpoint."""
    ckpt = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    state = ckpt.get('model_state', ckpt.get('model', ckpt))
    return len([k for k in state if 'hopfield.W' in k])


# ── BasinSurgeon — high-level API ────────────────────────────────────

class BasinSurgeon:
    """High-level API for energy landscape programming.

    Example:
        surgeon = BasinSurgeon.from_checkpoint("model.pt", device="cuda")
        print(surgeon.survey(layer=0))
        surgeon.inject(layer=0, seed=42, strength=0.1)
        surgeon.apply(layer=0)
        print(surgeon.diff(layer=0))
        surgeon.restore(layer=0)
    """

    def __init__(self, device='cpu'):
        self.device = device
        self._w_cache = {}       # layer -> current W
        self._w_backups = {}     # layer -> original W
        self._checkpoint_path = None
        self._model = None       # optional: full model for text gen
        self._tokenizer = None
        self._config = None
        self._history = []

        self._concepts = {}     # name -> {'states': [...], 'centroid': tensor}
        self.params = {
            'beta': 7.0,
            'inits': 200,
            'strength': 0.1,
            'degree': 3,
        }

    @classmethod
    def from_checkpoint(cls, path, device='cpu'):
        """Create a BasinSurgeon from a checkpoint file."""
        surgeon = cls(device=device)
        surgeon._checkpoint_path = path
        return surgeon

    @classmethod
    def from_W(cls, W, device='cpu'):
        """Create a BasinSurgeon from a raw W matrix."""
        surgeon = cls(device=device)
        surgeon._w_cache[0] = W.to(device)
        return surgeon

    def get_W(self, layer=0):
        """Get W matrix for a layer."""
        if layer in self._w_cache:
            return self._w_cache[layer]
        if self._checkpoint_path:
            W, _ = load_W_from_checkpoint(
                self._checkpoint_path, layer, self.device)
            self._w_cache[layer] = W
            return W
        raise ValueError(f"No W available for layer {layer}")

    def num_layers(self):
        if self._checkpoint_path:
            return count_hopfield_layers(self._checkpoint_path)
        return len(self._w_cache)

    def _make_target(self, seed, d_model):
        gen = torch.Generator(device='cpu')
        gen.manual_seed(int(seed))
        target = torch.randn(d_model, generator=gen).to(self.device)
        return target / target.norm()

    def survey(self, layer=0):
        """Survey basins of a layer. Returns dict with results."""
        W = self.get_W(layer)
        d = W.shape[0]
        t0 = time.time()
        basins, ids, trajectories = find_basins(
            W, d, num_inits=int(self.params['inits']),
            beta=self.params['beta'], device=self.device)
        elapsed = time.time() - t0

        results = {
            'layer': layer,
            'num_basins': len(basins),
            'num_inits': int(self.params['inits']),
            'basins': basins,
            'basin_ids': ids,
            'trajectories': trajectories,
            'elapsed': elapsed,
            'energies': [compute_energy(b, W) for b in basins],
            'populations': [ids.count(i) for i in range(len(basins))],
        }
        self._history.append(('survey', layer, results['num_basins']))
        return results

    def inject(self, layer=0, seed=42, strength=None):
        """Inject a new basin. Returns dict with before/after stats."""
        strength = strength or self.params['strength']
        W = self.get_W(layer)
        d = W.shape[0]
        target = self._make_target(seed, d)

        exists_before, _, cos_before, _ = verify_basin_exists(
            W, target, beta=self.params['beta'])
        W_new = inject_basin(W, target, strength=strength)
        exists_after, _, cos_after, _ = verify_basin_exists(
            W_new, target, beta=self.params['beta'])

        self._w_cache[layer] = W_new
        self._history.append(('inject', layer, seed, strength))

        return {
            'layer': layer, 'seed': seed, 'strength': strength,
            'existed_before': exists_before, 'cos_before': cos_before,
            'exists_after': exists_after, 'cos_after': cos_after,
            'W_before': W, 'W_after': W_new, 'target': target,
        }

    def remove(self, layer=0, seed=42, strength=None):
        """Remove closest basin to seed target."""
        strength = strength or self.params['strength']
        W = self.get_W(layer)
        d = W.shape[0]
        target = self._make_target(seed, d)

        basins, _, _ = find_basins(
            W, d, num_inits=100, beta=self.params['beta'], device=self.device)
        if basins:
            sims = [F.cosine_similarity(target.unsqueeze(0), b.unsqueeze(0)).item()
                    for b in basins]
            target = basins[int(np.argmax(sims))]

        W_new = remove_basin(W, target, strength=strength)
        exists_after, _, cos_after, _ = verify_basin_exists(
            W_new, target, beta=self.params['beta'])

        self._w_cache[layer] = W_new
        self._history.append(('remove', layer, seed, strength))

        return {
            'layer': layer, 'exists_after': exists_after,
            'cos_after': cos_after, 'W_after': W_new,
        }

    def move(self, layer=0, seed=42, strength=None):
        """Move closest basin to a new location."""
        strength = strength or self.params['strength']
        W = self.get_W(layer)
        d = W.shape[0]

        source_target = self._make_target(seed, d)
        basins, _, _ = find_basins(
            W, d, num_inits=100, beta=self.params['beta'], device=self.device)
        source = source_target
        if basins:
            sims = [F.cosine_similarity(source_target.unsqueeze(0), b.unsqueeze(0)).item()
                    for b in basins]
            source = basins[int(np.argmax(sims))]

        dest = self._make_target(int(seed) + 1000, d)
        W_new = move_basin(W, source, dest, strength=strength)
        self._w_cache[layer] = W_new
        self._history.append(('move', layer, seed, strength))
        return {'layer': layer, 'W_after': W_new}

    def verify(self, layer=0, seed=42):
        """Check if a target seed point is a basin."""
        W = self.get_W(layer)
        d = W.shape[0]
        target = self._make_target(seed, d)
        exists, final, cos, iters = verify_basin_exists(
            W, target, beta=self.params['beta'])
        energy = compute_energy(final, W)
        return {
            'is_basin': exists, 'cos': cos, 'iters': iters, 'energy': energy,
        }

    def apply(self, layer=0):
        """Apply cached W to a live model (if loaded).

        For standalone usage, this is a no-op since surgery already
        modifies the cached W. For HLM3 models loaded with load_model(),
        this writes W back to model.blocks[layer].hopfield.W.data.
        """
        if self._model is not None and hasattr(self._model, 'blocks'):
            W_new = self.get_W(layer)
            W_live = self._model.blocks[layer].hopfield.W
            if layer not in self._w_backups:
                self._w_backups[layer] = W_live.data.clone()
            with torch.no_grad():
                W_live.data.copy_(W_new)
            self._history.append(('apply', layer))
            return True
        return False

    def restore(self, layer=0):
        """Restore a layer to its original checkpoint W."""
        if layer in self._w_backups:
            if self._model and hasattr(self._model, 'blocks'):
                with torch.no_grad():
                    self._model.blocks[layer].hopfield.W.data.copy_(
                        self._w_backups[layer])
            self._w_cache[layer] = self._w_backups[layer].clone()
            del self._w_backups[layer]
            self._history.append(('restore', layer))
            return True
        # If no backup but we have checkpoint, reload from disk
        if self._checkpoint_path and layer in self._w_cache:
            W, _ = load_W_from_checkpoint(
                self._checkpoint_path, layer, self.device)
            self._w_cache[layer] = W
            self._history.append(('restore', layer))
            return True
        return False

    def restore_all(self):
        """Restore all layers."""
        restored = []
        for l in list(self._w_backups.keys()):
            self.restore(l)
            restored.append(l)
        return restored

    def capture(self, layer, text, concept_name=None):
        """Run text through the model and capture the converged Hopfield state.

        This is how you extract what a concept "looks like" in the energy
        landscape. The converged state at a given layer IS the concept's
        representation — the basin the input falls into.

        Args:
            layer: which Hopfield layer to capture from
            text: input text (requires model + tokenizer loaded)
            concept_name: if given, accumulate into a named concept

        Returns: dict with converged state, energy, basin info
        """
        if self._model is None or self._tokenizer is None:
            raise RuntimeError("capture requires a loaded model. Use load_model() first.")

        # Tokenize
        tokens = self._tokenizer.encode(text)
        input_ids = torch.tensor([tokens], device=self.device)

        # Hook to capture the Hopfield state after convergence
        captured = {}
        def hook_fn(module, input, output):
            if isinstance(output, dict) and 'state' in output:
                captured['state'] = output['state'].detach()
            elif isinstance(output, torch.Tensor):
                captured['state'] = output.detach()

        block = self._model.blocks[layer]
        handle = block.hopfield.register_forward_hook(hook_fn)

        with torch.no_grad():
            self._model(input_ids)

        handle.remove()

        if 'state' not in captured:
            raise RuntimeError(f"Could not capture state from layer {layer}")

        # Average across sequence positions to get a single concept vector
        state = captured['state']
        if state.dim() == 3:
            state = state.squeeze(0).mean(dim=0)  # [seq, dim] -> [dim]
        elif state.dim() == 2:
            state = state.mean(dim=0)
        state = state / state.norm()

        W = self.get_W(layer)
        energy = compute_energy(state, W)
        is_basin, _, cos, iters = verify_basin_exists(
            W, state, beta=self.params['beta'])

        result = {
            'state': state,
            'energy': energy,
            'is_basin': is_basin,
            'cos_similarity': cos,
            'converge_iters': iters,
            'text': text,
            'layer': layer,
        }

        # Accumulate into named concept
        if concept_name:
            if concept_name not in self._concepts:
                self._concepts[concept_name] = {'states': [], 'centroid': None}
            self._concepts[concept_name]['states'].append(state)
            # Recompute centroid
            states = torch.stack(self._concepts[concept_name]['states'])
            centroid = states.mean(dim=0)
            centroid = centroid / centroid.norm()
            self._concepts[concept_name]['centroid'] = centroid
            result['concept'] = concept_name
            result['num_samples'] = len(self._concepts[concept_name]['states'])

        self._history.append(('capture', layer, text[:40], concept_name))
        return result

    def inject_concept(self, layer, concept_name, strength=None):
        """Inject a captured concept as a new basin.

        First capture examples with capture(), then inject the averaged
        concept vector as a new attractor in the energy landscape.

        Args:
            layer: target layer
            concept_name: name of previously captured concept
            strength: injection strength (default: self.params['strength'])
        """
        if concept_name not in self._concepts:
            raise ValueError(f"Unknown concept '{concept_name}'. "
                           f"Use capture() first. Known: {list(self._concepts.keys())}")

        concept = self._concepts[concept_name]
        if concept['centroid'] is None:
            raise ValueError(f"Concept '{concept_name}' has no samples yet")

        strength = strength or self.params['strength']
        target = concept['centroid'].to(self.device)
        W = self.get_W(layer)

        exists_before, _, cos_before, _ = verify_basin_exists(
            W, target, beta=self.params['beta'])
        W_new = inject_basin(W, target, strength=strength)
        exists_after, _, cos_after, _ = verify_basin_exists(
            W_new, target, beta=self.params['beta'])

        self._w_cache[layer] = W_new
        self._history.append(('inject_concept', layer, concept_name, strength))

        return {
            'concept': concept_name,
            'num_samples': len(concept['states']),
            'layer': layer,
            'strength': strength,
            'existed_before': exists_before,
            'cos_before': cos_before,
            'exists_after': exists_after,
            'cos_after': cos_after,
        }

    def remove_concept(self, layer, concept_name, strength=None):
        """Remove a concept's basin from the energy landscape."""
        if concept_name not in self._concepts:
            raise ValueError(f"Unknown concept '{concept_name}'")

        strength = strength or self.params['strength']
        target = self._concepts[concept_name]['centroid'].to(self.device)
        W = self.get_W(layer)

        W_new = remove_basin(W, target, strength=strength)
        exists_after, _, cos_after, _ = verify_basin_exists(
            W_new, target, beta=self.params['beta'])

        self._w_cache[layer] = W_new
        self._history.append(('remove_concept', layer, concept_name, strength))

        return {
            'concept': concept_name,
            'exists_after': exists_after,
            'cos_after': cos_after,
        }

    def list_concepts(self):
        """List all captured concepts."""
        return {name: len(c['states']) for name, c in self._concepts.items()}

    def diff(self, layer=0):
        """Show W diff stats vs original."""
        if layer not in self._w_backups:
            if not self._checkpoint_path:
                return None
            W_orig, _ = load_W_from_checkpoint(
                self._checkpoint_path, layer, self.device)
        else:
            W_orig = self._w_backups[layer]

        W_curr = self.get_W(layer)
        delta = W_curr - W_orig
        return {
            'frobenius': delta.norm().item(),
            'max_abs': delta.abs().max().item(),
            'mean_abs': delta.abs().mean().item(),
            'spectral_orig': torch.linalg.norm(W_orig, ord=2).item(),
            'spectral_curr': torch.linalg.norm(W_curr, ord=2).item(),
            'relative_pct': delta.norm().item() / W_orig.norm().item() * 100,
        }
