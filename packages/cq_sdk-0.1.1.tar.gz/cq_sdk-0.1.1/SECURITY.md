# Security Policy

## Supported Versions

This project is in early development. Please report vulnerabilities against the latest release and/or `main`.

## Reporting a Vulnerability

If you discover a security vulnerability in cq, please report it responsibly by emailing **security@mozilla.ai**.

Do **not** open a public GitHub issue for security vulnerabilities.

Please include the following in your report:

- Project name and version (or commit SHA)
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Proof of concept (optional but helpful)

## Our Commitment

- We will acknowledge receipt of your report within 2 business days.
- We will provide an initial assessment within 5 business days.
- We will keep you informed of our progress as we work toward a fix.
- With your permission, we will credit you in the release notes.

## Public Disclosure

We follow a coordinated disclosure approach. We ask that you do not disclose the vulnerability publicly until a fix has been confirmed and a disclosure timeline has been agreed upon. For critical issues, we aim to resolve and disclose within 30 days.

## Scope

This policy applies to all cq repos and components, e.g.

- [cq](https://github.com/mozilla-ai/cq/)
- [cq Proto](https://github.com/mozilla-ai/cq-proto/)
- [cq Go](https://github.com/mozilla-ai/cq-go/)
- [cq Python](https://github.com/mozilla-ai/cq-python/)
- ...

Thank you for helping us keep cq secure.
