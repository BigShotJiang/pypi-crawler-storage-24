# MoXing (模型)

直接运行 Ollama 模型，有时更快。

## 安装

```bash
pip install moxing
```

## 使用

```bash
# 查看 Ollama 模型
moxing ollama list

# 运行模型
moxing ollama serve carstenuhlig/omnicoder-9b

# 交互式选择
moxing ollama list --select
```

## 性能对比

Apple M4 上测试 `carstenuhlig/omnicoder-9b`：

| 框架 | 速度 |
|------|------|
| Ollama | ~10 tokens/s |
| MoXing | ~15 tokens/s |

## 工作原理

MoXing 读取 Ollama 的 GGUF 文件，用 llama.cpp 运行。

```
Ollama manifest -> GGUF blob -> llama.cpp -> OpenAI API
```

## 兼容性

### 已验证成功

- carstenuhlig/omnicoder-9b
- Qwen2.5 系列
- Llama 3.x 系列
- Mistral 系列

### 已知不成功

- lfm2.5-thinking

**直接尝试你的模型，能跑就跑，不能跑就用 Ollama。**

## CLI 命令

| 命令 | 说明 |
|------|------|
| `moxing ollama list` | 列出 Ollama 模型 |
| `moxing ollama serve <model>` | 运行模型 |
| `moxing ollama info <model>` | 查看模型详情 |
| `moxing serve <model.gguf>` | 运行 GGUF 文件 |
| `moxing bench <model>` | 性能测试 |
| `moxing check <model>` | 检查兼容性 |

## License

MIT