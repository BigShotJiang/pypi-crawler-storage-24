from typing import List, Optional, Type

from crewai.tools import BaseTool
from docapi import DocAPI
from pydantic import BaseModel, Field


class PDFInput(BaseModel):
    html: str = Field(description="HTML content to render as PDF")
    output_path: str = Field(default="output.pdf", description="File path for the output PDF")
    format: str = Field(default="A4", description="Page format (e.g. A4, Letter)")
    landscape: bool = Field(default=False, description="Use landscape orientation")


class ScreenshotInput(BaseModel):
    url: Optional[str] = Field(default=None, description="URL of the webpage to capture")
    html: Optional[str] = Field(default=None, description="HTML content to render and capture")
    output_path: str = Field(default="screenshot.png", description="File path for the output image")
    width: int = Field(default=1280, description="Viewport width in pixels")
    height: int = Field(default=800, description="Viewport height in pixels")


class InvoiceInput(BaseModel):
    from_name: str = Field(description="Seller / sender name")
    to_name: str = Field(description="Buyer / recipient name")
    line_items: List[dict] = Field(description="List of line-item dicts with 'description', 'quantity', and 'unit_price'")
    output_path: str = Field(default="invoice.pdf", description="File path for the output PDF")
    from_email: Optional[str] = Field(default=None, description="Seller email")
    to_email: Optional[str] = Field(default=None, description="Buyer email")
    invoice_number: Optional[str] = Field(default=None, description="Invoice number")
    date: Optional[str] = Field(default=None, description="Invoice date")
    due_date: Optional[str] = Field(default=None, description="Payment due date")
    currency_symbol: str = Field(default="$", description="Currency symbol")
    tax_percent: Optional[float] = Field(default=None, description="Tax percentage")
    notes: Optional[str] = Field(default=None, description="Additional notes")


class DocAPIPDFTool(BaseTool):
    name: str = "DocAPI PDF Generator"
    description: str = (
        "Generate a PDF from HTML content using DocAPI's headless Chromium renderer. "
        "Full CSS support including Flexbox, Grid, and Google Fonts. "
        "Use when you need to create a PDF document from HTML."
    )
    args_schema: Type[BaseModel] = PDFInput
    api_key: str

    def _run(self, html: str, output_path: str = "output.pdf", format: str = "A4", landscape: bool = False) -> str:
        try:
            data = DocAPI(self.api_key).pdf(html, format=format, landscape=landscape)
            with open(output_path, "wb") as f:
                f.write(data)
            return f"PDF saved to {output_path} ({len(data)} bytes)"
        except Exception as e:
            return f"Error generating PDF: {e}"


class DocAPIScreenshotTool(BaseTool):
    name: str = "DocAPI Screenshot Capture"
    description: str = (
        "Capture a screenshot of a webpage URL or HTML content as PNG or JPEG. "
        "Use when you need a visual capture of a website or rendered HTML."
    )
    args_schema: Type[BaseModel] = ScreenshotInput
    api_key: str

    def _run(
        self,
        url: Optional[str] = None,
        html: Optional[str] = None,
        output_path: str = "screenshot.png",
        width: int = 1280,
        height: int = 800,
    ) -> str:
        try:
            data = DocAPI(self.api_key).screenshot(url=url, html=html, width=width, height=height)
            with open(output_path, "wb") as f:
                f.write(data)
            return f"Screenshot saved to {output_path} ({len(data)} bytes)"
        except Exception as e:
            return f"Error capturing screenshot: {e}"


class DocAPIInvoiceTool(BaseTool):
    name: str = "DocAPI Invoice Generator"
    description: str = (
        "Generate a professional invoice PDF from structured data — seller, buyer, "
        "line items, tax, and notes. Use when you need to create a formatted invoice document."
    )
    args_schema: Type[BaseModel] = InvoiceInput
    api_key: str

    def _run(
        self,
        from_name: str = "",
        to_name: str = "",
        line_items: Optional[List[dict]] = None,
        output_path: str = "invoice.pdf",
        from_email: Optional[str] = None,
        to_email: Optional[str] = None,
        invoice_number: Optional[str] = None,
        date: Optional[str] = None,
        due_date: Optional[str] = None,
        currency_symbol: str = "$",
        tax_percent: Optional[float] = None,
        notes: Optional[str] = None,
    ) -> str:
        try:
            from_ = {"name": from_name}
            if from_email:
                from_["email"] = from_email

            to = {"name": to_name}
            if to_email:
                to["email"] = to_email

            kwargs: dict = {
                "from_": from_,
                "to": to,
                "line_items": line_items or [],
                "currency_symbol": currency_symbol,
            }
            if invoice_number is not None:
                kwargs["invoice_number"] = invoice_number
            if date is not None:
                kwargs["date"] = date
            if due_date is not None:
                kwargs["due_date"] = due_date
            if tax_percent is not None:
                kwargs["tax_percent"] = tax_percent
            if notes is not None:
                kwargs["notes"] = notes

            data = DocAPI(self.api_key).invoice(**kwargs)
            with open(output_path, "wb") as f:
                f.write(data)
            return f"Invoice saved to {output_path} ({len(data)} bytes)"
        except Exception as e:
            return f"Error generating invoice: {e}"
