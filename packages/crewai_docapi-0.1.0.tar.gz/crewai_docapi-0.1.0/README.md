# crewai-docapi

CrewAI tools for [DocAPI](https://docapi.com) — generate PDFs, screenshots, and invoices from your AI agents.

## Install

```bash
pip install crewai-docapi
```

## Quick start

```python
from crewai import Agent
from crewai_docapi import DocAPIPDFTool, DocAPIScreenshotTool, DocAPIInvoiceTool

pdf_tool = DocAPIPDFTool(api_key="your-api-key")
screenshot_tool = DocAPIScreenshotTool(api_key="your-api-key")
invoice_tool = DocAPIInvoiceTool(api_key="your-api-key")

agent = Agent(
    role="Document Creator",
    goal="Generate PDFs, screenshots, and invoices",
    tools=[pdf_tool, screenshot_tool, invoice_tool],
)
```

## Documentation

See the [DocAPI docs](https://docapi.com/docs) for full API reference.
