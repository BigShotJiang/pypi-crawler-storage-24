"""
Custom Django model managers.
"""
