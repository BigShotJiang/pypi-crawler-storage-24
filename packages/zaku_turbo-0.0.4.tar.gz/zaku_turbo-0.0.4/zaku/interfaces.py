from io import BytesIO
from time import time, perf_counter
from types import SimpleNamespace
from typing import Literal, Any, Coroutine, Dict, Union, TYPE_CHECKING, Tuple

import msgpack
import numpy as np
import logging

logger = logging.getLogger(__name__)
if TYPE_CHECKING:
    import redis
    import torch

# MongoDB removed - Pure Redis + S3 architecture


ZType = Literal["numpy.ndarray", "torch.Tensor", "generic"]


class ZData:
    @staticmethod
    def encode(data: Union["torch.Tensor", np.ndarray]):
        """This converts arrays and tensors to z-format."""
        T = type(data)
        from PIL.Image import Image

        if isinstance(data, Image):
            # we always move to CPU
            with BytesIO() as buffer:
                # use the format of the Image object, default to PNG.
                data.save(buffer, format=data.format or "PNG")
                binary = buffer.getvalue()

            return dict(ztype="image", b=binary)
        elif T is np.ndarray:
            # need to support other numpy array types, including mask.
            binary = data.tobytes()
            return dict(
                ztype="numpy.ndarray",
                b=binary,
                dtype=str(data.dtype),
                shape=data.shape,
            )
        elif T.__name__ == "Tensor" and T.__module__.startswith("torch"):
            import torch
            # we always move to CPU
            np_v = data.cpu().numpy()
            binary = np_v.tobytes()
            return dict(
                ztype="torch.Tensor",
                b=binary,
                dtype=str(np_v.dtype),
                shape=np_v.shape,
            )
        else:
            return data
            # return dict(ztype="generic", b=data)

    @staticmethod
    def get_ztype(data: Dict) -> Union[ZType, None]:
        """check if it is z-payload"""
        if type(data) is dict and "ztype" in data:
            return data["ztype"]

    @staticmethod
    def decode(zdata):
        T = ZData.get_ztype(zdata)
        if not T:
            return zdata
        elif T == "image":
            from PIL import Image

            buff = BytesIO(zdata["b"])
            image = Image.open(buff)
            return image

        elif T == "numpy.ndarray":
            # need to support other numpy array types, including mask.
            array = np.frombuffer(zdata["b"], dtype=zdata["dtype"])
            array = array.reshape(zdata["shape"])
            return array
        elif T == "torch.Tensor":
            import torch
            array = np.frombuffer(zdata["b"], dtype=zdata["dtype"])
            # we copy the array because the buffered version is non-writable.
            array = array.reshape(zdata["shape"]).copy()
            torch_array = torch.Tensor(array)
            return torch_array
        else:
            raise TypeError(f"ZData type {T} is not supported")


class Payload(SimpleNamespace):
    # class attributes are not serialized.
    greedy = True
    """Set to False to avoid greedy convertion, and make it go faster"""

    def __init__(self, _greedy=None, **payload):
        if _greedy:
            self.greedy = _greedy

        super().__init__(**payload)

    def serialize(self):
        payload = self.__dict__
        # we serialize components key value pairs
        if self.greedy:
            data = {k: ZData.encode(v) for k, v in payload.items()}
            data["_greedy"] = self.greedy
            msg = msgpack.packb(data, use_bin_type=True)
        else:
            msg = msgpack.packb(payload, use_bin_type=True)
        return msg

    @staticmethod
    def deserialize(msg: bytes):
        """Rehydrate the payload to a plain dict for compatibility with existing callers"""
        data = msgpack.unpackb(msg)

        if data.get("_greedy"):
            del data["_greedy"]
            for k, v in data.items():
                data[k] = ZData.decode(v)
            return data

        return data

    @staticmethod
    def deserialize_unpacked(unpacked) -> Dict:
        """Rehydrate the payload to a plain dict from an unpacked msgpack generator."""
        if unpacked.get("_greedy"):
            del unpacked["_greedy"]
            data = {}
            for k, v in unpacked.items():
                data[k] = ZData.decode(v)

            return data
        return unpacked


class Job(SimpleNamespace):
    created_ts: float
    status: Literal[
        None, "created", "in_progress", "completed", "failed"] = "created"
    grab_ts: float = None
    completed_ts: float = None  # Timestamp when task completed/failed
    error: str = None  # Error message if status is "failed"

    # S3 reference fields (Pure Redis + S3 architecture)
    s3_key: str = None
    s3_bucket: str = None
    size: int = 0

    # Generic metadata field - users can put anything here
    metadata: dict = None  # User-defined metadata (task_name, submitted_by, etc.)

    # value: Any = None
    # payload: bytes = None
    # """This is the binary encoding from the msgpack. """
    # ttl: float = None

    @staticmethod
    async def create_queue(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            name, *, prefix):
        """Create queue data structures (List + ZSet, no RedisSearch needed)"""
        # Initialize queue structures
        # Redis List and Sorted Set are created automatically on first use
        # This method is kept for API compatibility but is essentially a no-op
        list_key = f"{prefix}:{{{name}}}:pending"
        zset_key = f"{prefix}:{{{name}}}:processing"

        # Ensure keys exist (idempotent - won't affect existing data)
        p = r.pipeline()
        p.exists(list_key)
        p.exists(zset_key)
        await p.execute()

        return True

    @staticmethod
    async def remove_queue(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue, *, prefix):
        """Remove all queue data structures"""
        list_key = f"{prefix}:{{{queue}}}:pending"
        zset_key = f"{prefix}:{{{queue}}}:processing"

        # Delete list and sorted set
        await r.delete(list_key, zset_key)

        # Delete all job metadata
        pattern = f"{prefix}:{{{queue}}}:*"
        async for key in r.scan_iter(pattern):
            await r.unlink(key)

        return True

    @staticmethod
    async def add(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue: str,
            *,
            prefix: str,
            payload: bytes = None,
            s3_key: str = None,  # S3 key
            s3_bucket: str = None,  # S3 bucket
            size: int = 0,  # payload size
            job_id: str = None,
            metadata: dict = None,  # User-defined metadata (任何自定义字段)
    ) -> str:
        # Pure Redis + S3 architecture: Store S3 reference directly in Redis
        import json
        from uuid import uuid4

        # Generate job_id if not provided
        used_job_id = job_id or str(uuid4()).replace("-", "")[:24]

        # Create job with S3 reference and user metadata
        job = Job(
            created_ts=time(),
            status="created",
            s3_key=s3_key,
            s3_bucket=s3_bucket or "zaku-payloads",
            size=size,
            metadata=metadata or {},  # User can put anything here
        )

        entry_key = f"{prefix}:{{{queue}}}:{used_job_id}"
        list_key = f"{prefix}:{{{queue}}}:pending"

        # Lua script for atomic operation: JSON.SET + RPUSH
        lua_script = """
        local entry_key = KEYS[1]
        local list_key = KEYS[2]
        local job_data = ARGV[1]
        local job_id = ARGV[2]

        -- Set JSON metadata (includes S3 reference)
        redis.call('JSON.SET', entry_key, '.', job_data)
        -- Push to pending list
        redis.call('RPUSH', list_key, job_id)

        return true
        """

        job_data_str = json.dumps(vars(job))
        await r.eval(lua_script, 2, entry_key, list_key, job_data_str,
                     used_job_id)

        return used_job_id

    @staticmethod
    async def count_files(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue, *, prefix) -> int:
        """Count pending jobs using LLEN (O(1) operation, much faster than FT.SEARCH)"""
        list_key = f"{prefix}:{{{queue}}}:pending"
        count = await r.llen(list_key)
        return count

    @staticmethod
    async def take(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue, *, prefix) -> Tuple[Any, Any]:
        # Lua script for atomic RPOP + ZADD + JSON.SET
        # This eliminates concurrent conflicts by using atomic RPOP

        lua_script = """
        local list_key = KEYS[1]
        local zset_key = KEYS[2]
        local prefix = ARGV[1]
        local queue = ARGV[2]
        local current_time = tonumber(ARGV[3])

        -- Atomic pop from pending list (RPOP removes from tail)
        local job_id = redis.call('RPOP', list_key)

        if not job_id then
            return {nil}
        end

        -- Build entry key for JSON metadata
        local entry_key = prefix .. ":{" .. queue .. "}:" .. job_id

        -- Update status in JSON metadata
        redis.call('JSON.SET', entry_key, '$.status', '"in_progress"')
        redis.call('JSON.SET', entry_key, '$.grab_ts', current_time)

        -- Add to processing sorted set with grab_ts as score (for timeout detection)
        redis.call('ZADD', zset_key, current_time, job_id)

        return {job_id}
        """

        list_key = f"{prefix}:{{{queue}}}:pending"
        zset_key = f"{prefix}:{{{queue}}}:processing"
        current_time = time()

        # Execute Lua script
        result = await r.eval(lua_script, 2, list_key, zset_key, prefix, queue,
                              str(current_time))

        if not result or result[0] is None:
            return None, None

        job_id = result[0].decode() if isinstance(result[0], bytes) else \
            result[0]

        # Retrieve S3 reference from Redis JSON (Pure Redis + S3 architecture)
        metadata = None
        try:
            entry_key = f"{prefix}:{{{queue}}}:{job_id}"
            job_data = await r.json().get(entry_key)

            if job_data:
                # Extract S3 metadata from Redis JSON
                metadata = {
                    "_s3_key": job_data.get("s3_key"),
                    "_s3_bucket": job_data.get("s3_bucket", "zaku-payloads"),
                    "_size": job_data.get("size", 0),
                }
        except Exception as e:
            logger.warning(
                f"Failed to retrieve S3 reference from Redis for job {job_id}: {e}")

        return job_id, metadata

    @staticmethod
    async def publish(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue: str,
            *,
            payload: bytes,
            topic_id: str,
            prefix: str,
    ) -> Coroutine:
        """Publish a job to a key (Pure Redis + S3 architecture)

        For PubSub messages, payload is published directly to Redis.
        For large payloads in task queues, use S3 storage instead.
        """
        entry_key = f"{prefix}:{{{queue}}}.topics:{topic_id}"
        subscribers = await r.publish(entry_key, payload)
        return subscribers

    # todo: implement streaming mode.
    @staticmethod
    async def subscribe(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue: str,
            *,
            topic_id: str,
            prefix: str,
            timeout: float = 0.1,
    ) -> str:
        """Returns the first non-empty message."""
        topic_name = f"{prefix}:{{{queue}}}.topics:{topic_id}"

        end_time = perf_counter() + timeout

        async with r.pubsub() as pb:
            await pb.subscribe(topic_name)

            while perf_counter() < end_time:
                message = await pb.get_message(
                    ignore_subscribe_messages=True,
                    timeout=min(0.1, timeout),
                )
                if message is None:
                    pass
                elif message["type"] == "message":
                    # Pure Redis + S3 architecture: return message data directly
                    return message["data"]

    @staticmethod
    async def subscribe_stream(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue: str,
            *,
            topic_id: str,
            prefix: str,
            timeout: float = 0.1,
    ):
        topic_name = f"{prefix}:{{{queue}}}.topics:{topic_id}"

        end_time = perf_counter() + timeout

        async with r.pubsub() as pb:
            await pb.subscribe(topic_name)

            while perf_counter() < end_time:
                message = await pb.get_message(
                    ignore_subscribe_messages=True,
                    timeout=min(0.1, timeout),
                )
                if message is None:
                    pass
                elif message["type"] == "message":
                    # Pure Redis + S3 architecture: yield message data directly
                    yield message["data"]

    @staticmethod
    async def remove(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            job_id, queue, *, prefix):
        """
        Removes both Redis metadata and S3 object reference.
        """

        if job_id == "*":
            try:
                list_key = f"{prefix}:{{{queue}}}:pending"
                zset_key = f"{prefix}:{{{queue}}}:processing"
                entry_pattern = f"{prefix}:{{{queue}}}:*"

                # Only clear Redis data
                await r.delete(list_key, zset_key)

                keys_to_delete = []
                redis_count = 0

                async for key in r.scan_iter(entry_pattern, count=1000):
                    if not key.endswith(b':pending') and not key.endswith(
                            b':processing'):
                        keys_to_delete.append(key)

                        if len(keys_to_delete) >= 1000:
                            await r.unlink(*keys_to_delete)
                            redis_count += len(keys_to_delete)
                            keys_to_delete.clear()

                if keys_to_delete:
                    await r.unlink(*keys_to_delete)
                    redis_count += len(keys_to_delete)

                logger.info(
                    f"Redis cleanup: {redis_count} keys deleted (S3 cleanup handled by client)")
                return True

            except Exception as e:
                logger.error(f"Queue cleanup failed: {e}")
                return False

        # Remove single job (Redis only, S3 cleanup handled by client)
        entry_key = f"{prefix}:{{{queue}}}:{job_id}"

        # Remove from Redis using Lua script for atomicity
        lua_script = """
        local list_key = KEYS[1]
        local zset_key = KEYS[2]
        local entry_key = KEYS[3]
        local job_id = ARGV[1]

        -- Remove from pending list (if exists)
        redis.call('LREM', list_key, 0, job_id)

        -- Remove from processing set (if exists)
        redis.call('ZREM', zset_key, job_id)

        -- Delete JSON metadata
        redis.call('DEL', entry_key)

        return true
        """

        list_key = f"{prefix}:{{{queue}}}:pending"
        zset_key = f"{prefix}:{{{queue}}}:processing"

        await r.eval(lua_script, 3, list_key, zset_key, entry_key, job_id)

        logger.info(
            f"Redis cleanup for job {job_id} (S3 cleanup handled by client)")
        return True

    @staticmethod
    async def complete_task(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            job_id: str,
            queue: str,
            status: str,
            completed_ts: float,
            error: str = None,
            *,
            prefix: str,
            ttl_days: int = 15
    ):
        """Mark a task as completed or failed, keep in Redis for TTL days.

        Args:
            r: Redis client
            job_id: Job identifier
            queue: Queue name
            status: "completed" or "failed"
            completed_ts: Completion timestamp
            error: Error message if failed
            prefix: Redis key prefix
            ttl_days: Days to keep the task in Redis (default: 15)

        Strategy:
        1. Update status, completed_ts, error in Redis JSON
        2. Remove from processing zset
        3. Add to completed/failed zset (for querying)
        4. Set TTL on entry key (auto-cleanup after 15 days)
        """
        entry_key = f"{prefix}:{{{queue}}}:{job_id}"
        processing_key = f"{prefix}:{{{queue}}}:processing"
        completed_key = f"{prefix}:{{{queue}}}:{status}"  # completed or failed zset

        # Lua script for atomic update
        lua_script = """
        local entry_key = KEYS[1]
        local processing_key = KEYS[2]
        local completed_key = KEYS[3]
        local job_id = ARGV[1]
        local status = ARGV[2]
        local completed_ts = tonumber(ARGV[3])
        local error_msg = ARGV[4]
        local ttl_seconds = tonumber(ARGV[5])

        -- Update status and completed_ts
        redis.call('JSON.SET', entry_key, '$.status', '"' .. status .. '"')
        redis.call('JSON.SET', entry_key, '$.completed_ts', completed_ts)

        -- Set error if provided
        if error_msg ~= "" then
            redis.call('JSON.SET', entry_key, '$.error', '"' .. error_msg .. '"')
        end

        -- Remove from processing zset
        redis.call('ZREM', processing_key, job_id)

        -- Add to completed/failed zset (sorted by completion time)
        redis.call('ZADD', completed_key, completed_ts, job_id)

        -- Set TTL on entry key (auto-cleanup)
        redis.call('EXPIRE', entry_key, ttl_seconds)

        return 1
        """

        ttl_seconds = ttl_days * 24 * 3600
        error_msg = error or ""

        await r.eval(
            lua_script,
            3,
            entry_key,
            processing_key,
            completed_key,
            job_id,
            status,
            str(completed_ts),
            error_msg,
            str(ttl_seconds)
        )

        logger.info(
            f"Task {job_id} marked as {status}, will expire in {ttl_days} days")
        return True

    @staticmethod
    async def list_tasks(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue: str,
            *,
            prefix: str,
            status: str = "all",
            limit: int = 20
    ) -> list:
        """List tasks from a queue.

        Args:
            r: Redis client
            queue: Queue name (required)
            prefix: Redis key prefix
            status: Filter by status - "all", "pending", "in_progress", "completed", "failed"
            limit: Maximum number of tasks to return (default: 20)

        Returns:
            List of task dicts with full metadata
        """
        tasks = []

        # Determine which sets to query based on status filter
        if status == "all":
            # Query all status sets
            sets_to_query = ["pending", "processing", "completed", "failed"]
        elif status == "in_progress":
            sets_to_query = ["processing"]
        else:
            sets_to_query = [status]

        # Collect job_ids from all relevant sets
        job_ids = []
        for status_name in sets_to_query:
            if status_name == "pending":
                # Pending is a list, get all items
                list_key = f"{prefix}:{{{queue}}}:pending"
                pending_ids = await r.lrange(list_key, 0, -1)
                job_ids.extend(
                    [jid.decode() if isinstance(jid, bytes) else jid for jid in
                     pending_ids])
            else:
                # Others are sorted sets, get by score (time) descending
                set_key = f"{prefix}:{{{queue}}}:{status_name}"
                items = await r.zrevrange(set_key, 0, -1)
                job_ids.extend(
                    [jid.decode() if isinstance(jid, bytes) else jid for jid in
                     items])

        # Limit the number of job_ids
        job_ids = job_ids[:limit]

        # Fetch metadata for each job
        for job_id in job_ids:
            entry_key = f"{prefix}:{{{queue}}}:{job_id}"
            try:
                job_data = await r.json().get(entry_key)
                if job_data:
                    # Add job_id to the result
                    job_data["job_id"] = job_id
                    tasks.append(job_data)
            except Exception as e:
                logger.warning(
                    f"Failed to fetch metadata for job {job_id}: {e}")
                continue

        return tasks

    @staticmethod
    async def get_task(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue: str,
            job_id: str,
            *,
            prefix: str
    ) -> dict:
        """Get a single task's full metadata.

        Args:
            r: Redis client
            queue: Queue name
            job_id: Job identifier
            prefix: Redis key prefix

        Returns:
            Task dict with full metadata, or None if not found
        """
        entry_key = f"{prefix}:{{{queue}}}:{job_id}"
        try:
            job_data = await r.json().get(entry_key)
            if job_data:
                job_data["job_id"] = job_id
                return job_data
            return None
        except Exception as e:
            logger.error(f"Failed to fetch task {job_id}: {e}")
            return None

    @staticmethod
    async def append_log(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue: str,
            job_id: str,
            message: str,
            *,
            prefix: str,
            max_lines: int = 100,
            ttl_days: int = 15
    ) -> bool:
        """Append a log message to task logs (keep latest 100 lines).

        Args:
            r: Redis client
            queue: Queue name
            job_id: Job identifier
            message: Log message to append
            prefix: Redis key prefix
            max_lines: Maximum number of log lines to keep (default: 100)
            ttl_days: Days to keep logs (default: 15)

        Returns:
            True if successful

        Storage:
            - Redis List: zaku:{queue}:{job_id}:logs
            - LPUSH: Insert at head (newest first)
            - LTRIM: Keep only latest max_lines
            - EXPIRE: Auto-delete after ttl_days
        """
        from datetime import datetime

        logs_key = f"{prefix}:{{{queue}}}:{job_id}:logs"

        # Add timestamp to message
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        log_line = f"[{timestamp}] {message}"

        # Lua script for atomic LPUSH + LTRIM + EXPIRE
        lua_script = """
        local logs_key = KEYS[1]
        local log_line = ARGV[1]
        local max_lines = tonumber(ARGV[2])
        local ttl_seconds = tonumber(ARGV[3])

        -- Insert at head (newest first)
        redis.call('LPUSH', logs_key, log_line)

        -- Keep only latest max_lines
        redis.call('LTRIM', logs_key, 0, max_lines - 1)

        -- Set TTL
        redis.call('EXPIRE', logs_key, ttl_seconds)

        return 1
        """

        ttl_seconds = ttl_days * 24 * 3600

        try:
            await r.eval(
                lua_script,
                1,
                logs_key,
                log_line,
                str(max_lines),
                str(ttl_seconds)
            )
            return True
        except Exception as e:
            logger.error(f"Failed to append log for job {job_id}: {e}")
            return False

    @staticmethod
    async def get_logs(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue: str,
            job_id: str,
            *,
            prefix: str,
            lines: int = 100
    ) -> str:
        """Get task logs.

        Args:
            r: Redis client
            queue: Queue name
            job_id: Job identifier
            prefix: Redis key prefix
            lines: Number of lines to retrieve (default: 100, max: 100)

        Returns:
            Log content as string (newest first)
        """
        logs_key = f"{prefix}:{{{queue}}}:{job_id}:logs"

        try:
            # Get logs (0 to lines-1, newest first since we LPUSH)
            log_lines = await r.lrange(logs_key, 0, min(lines, 100) - 1)

            if not log_lines:
                return ""

            # Decode and join (reverse to show oldest first)
            lines_decoded = [
                line.decode() if isinstance(line, bytes) else line
                for line in log_lines
            ]
            # Reverse to show oldest first
            lines_decoded.reverse()

            return "\n".join(lines_decoded)
        except Exception as e:
            logger.error(f"Failed to get logs for job {job_id}: {e}")
            return ""

    @staticmethod
    async def reset(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            job_id, queue, *, prefix):
        """Reset a single job back to pending (used by mark_reset)

        IMPORTANT: Only resets jobs that are actually in the processing set.
        If job is already in pending or doesn't exist in processing, does nothing.
        This prevents duplicate entries in the pending list.
        """

        # Lua script: Check ZREM result, only RPUSH if job was in processing
        lua_script = """
        local zset_key = KEYS[1]
        local list_key = KEYS[2]
        local entry_key = KEYS[3]
        local job_id = ARGV[1]

        -- Try to remove from processing set
        local removed = redis.call('ZREM', zset_key, job_id)

        -- Only push back to pending if it was actually in processing
        if removed > 0 then
            redis.call('RPUSH', list_key, job_id)
            redis.call('JSON.SET', entry_key, '$.status', '"created"')
            redis.call('JSON.DEL', entry_key, '$.grab_ts')
            return 1  -- Success: job was reset
        else
            -- Job was not in processing, don't add to pending
            return 0  -- No-op: job wasn't in processing
        end
        """

        zset_key = f"{prefix}:{{{queue}}}:processing"
        list_key = f"{prefix}:{{{queue}}}:pending"
        entry_key = f"{prefix}:{{{queue}}}:{job_id}"

        result = await r.eval(lua_script, 3, zset_key, list_key, entry_key,
                              job_id)

        return result == 1  # Return True if job was actually reset

    @staticmethod
    async def unstale_tasks(
            r: Union["redis.asyncio.Redis", "redis.sentinel.asyncio.Redis"],
            queue, *, prefix, ttl=None):
        """Reset stale jobs from processing back to pending using ZRANGEBYSCORE for timeout detection"""

        zset_key = f"{prefix}:{{{queue}}}:processing"

        if ttl:
            # Get jobs that have been processing too long (grab_ts < current_time - ttl)
            cutoff_time = time() - ttl
            stale_jobs = await r.zrangebyscore(zset_key, 0, cutoff_time)
        else:
            # Reset all in-progress jobs
            stale_jobs = await r.zrange(zset_key, 0, -1)

        if not stale_jobs:
            return []

        # Lua script for atomic reset: ZREM + RPUSH + JSON.SET for multiple jobs
        lua_script = """
        local zset_key = KEYS[1]
        local list_key = KEYS[2]
        local prefix = ARGV[1]
        local queue = ARGV[2]

        local reset_count = 0
        for i = 3, #ARGV do
            local job_id = ARGV[i]

            -- Remove from processing set
            redis.call('ZREM', zset_key, job_id)

            -- Push back to pending list
            redis.call('RPUSH', list_key, job_id)

            -- Update status in JSON
            local entry_key = prefix .. ":{" .. queue .. "}:" .. job_id
            redis.call('JSON.SET', entry_key, '$.status', '"created"')
            redis.call('JSON.DEL', entry_key, '$.grab_ts')

            reset_count = reset_count + 1
        end

        return reset_count
        """

        list_key = f"{prefix}:{{{queue}}}:pending"

        # Decode job IDs
        job_ids = [j.decode() if isinstance(j, bytes) else j for j in
                   stale_jobs]

        # Execute Lua script with all job IDs
        result = await r.eval(lua_script, 2, zset_key, list_key, prefix, queue,
                              *job_ids)

        return result
