import asyncio

import loguru
import msgpack
import redis

from aiohttp import web
import uvloop
from params_proto.v2.proto import Proto, ParamsProto, Flag
from dotenv import load_dotenv

try:
    from zaku.base import Server
    from zaku.interfaces import Job
except Exception:
    from base import Server
    from interfaces import Job

load_dotenv()

logger = loguru.logger

asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())


class Redis(ParamsProto, prefix="redis", cli_parse=False):
    """Redis Configuration for the TaskServer class.

    We support both direct connection to a single redis server,
        and a high availability setup using Redis Sentinel.
        The latter require setting up a replica set
        and a group of sentinels.

    Single Redis Server Usage
    =========================

    .. code-block:: shell

        # Put this into an .env file
        REDIS_HOST=localhost
        REDIS_PORT=6379
        REDIS_PASSWORD=xxxxxxxxxxxxxxxxxxx
        REDIS_DB=0

    CLI Options::

        --redis.host      :str 'localhost'
        --redis.port      :int 6379
        --redis.password  :any None
        --redis.db        :any 0

    Sentinel Usage (High availability setup)
    ========================================

    .. code-block:: shell

        # Put this into an .env file
        SENTINEL_HOSTs=host1:port1,host2:port2  # <=== Notice it is plural.
                                                #   This is a comma separated list of hosts.
        SENTINEL_PASSWORD=xxxxxxxxxxxxxxxxxxx.  # <=== This is the password for the sentinels.

        sentinel_cluster_name=primary           # <=== This is the name of the redis cluster.
        SENTINEL_DB=0                           # <=== This is the logical database.

    CLI Options::

        --redis.sentinel_hosts     :str 'localhost'
        --redis.sentinel_password  :any None
        --redis.sentinel_db        :any 0

    Common Errors:
    ==============

    Setting keepalive: ConnectionError is due to timeout. See below for more infomation.

    https://devcenter.heroku.com/articles/ah-redis-stackhero#:~:text=The%20error%20%E2%80%9Credis.,and%20the%20connection%20closes%20automatically
    """

    host: str = Proto("localhost", env="REDIS_HOST")
    port: int = Proto(6379, env="REDIS_PORT")
    password: str = Proto(env="REDIS_PASSWORD")

    # todo: add support for cluster mode without sentinel.
    sentinel_hosts: str = Proto(
        env="SENTINEL_HOSTS",
        help="comma separated list of redis hosts. Example: host1:port1,host2:port2,host3:port3."
    )
    sentinel_password: str = Proto(password, env="SENTINEL_PASSWORD")

    cluster_name = Proto("primary", env="SENTINEL_CLUSTER_NAME")
    shuffle: bool = Proto(False, env="REDIS_SHUFFLE",
                          help="shuffle the sentinel hosts on init.")
    ssl: bool = Proto(False, env="REDIS_SSL",
                      help="use SSL to connect to redis sentinel.")
    db: int = Proto(0, env="REDIS_DB",
                    help="The logical redis database, from 0 - 15.")

    # connection arguments
    health_check_interval = 10
    socket_connect_timeout = 5
    retry_on_timeout = True
    socket_keepalive = True

    def __post_init__(self, _deps=None):
        if self.sentinel_hosts:
            import random

            self.sentinel_hosts = [h.split(":") for h in
                                   self.sentinel_hosts.split(",")]

            if self.shuffle:
                self.sentinel_hosts = random.shuffle(self.sentinel_hosts,
                                                     key=lambda x: hash(x))

            self.sentinel = redis.asyncio.sentinel.Sentinel(
                self.sentinel_hosts,
                password=self.sentinel_password,
                health_check_interval=self.health_check_interval,
                socket_connect_timeout=self.socket_connect_timeout,
                retry_on_timeout=self.retry_on_timeout,
                socket_keepalive=self.socket_keepalive,
            )

            self.connection = self.sentinel.master_for(self.cluster_name,
                                                       password=self.password,
                                                       db=self.db)

        else:
            self.connection = redis.asyncio.Redis(
                password=self.password,
                db=self.db,
                host=self.host,
                port=self.port,
                health_check_interval=self.health_check_interval,
                socket_connect_timeout=self.socket_connect_timeout,
                socket_keepalive=self.socket_keepalive,
                ssl=True if self.ssl in ("True", "true", True) else False,
            )


# MongoDB removed - Pure Redis + S3 architecture


class S3Storage(ParamsProto, prefix="s3", cli_parse=False):
    """S3 Storage Configuration for the TaskServer class.

    S3 is used for storing large payloads (> 10MB).

    Usage
    =====

    .. code-block:: shell

        # Put this into an .env file
        S3_BUCKET=zaku-payloads
        S3_REGION=us-east-1
        AWS_ACCESS_KEY_ID=xxxxxxxxxxxx
        AWS_SECRET_ACCESS_KEY=xxxxxxxxxxxx

    CLI Options::

        --s3.bucket    :str 'zaku-payloads'
        --s3.region    :str 'us-east-1'
    """

    bucket: str = Proto("zaku-payloads", env="S3_BUCKET")
    region: str = Proto("us-east-1", env="S3_REGION")


class TaskServer(ParamsProto, Server):
    """TaskServer

    This is the server that maintains the Task Queue.

    Usage

    .. code-block:: python

        app = TaskServer()
        app.run()

    CLI Options

    .. code-block:: shell

        python -m zaku.server --help

        -h, --help            show this help message and exit
        --prefix            :str 'Zaku-task-queues'
        --queue-len         :int 100
        --host              :str 'localhost'
                              set to 0.0.0.0 to enable remote (not localhost) connections.
        --port              :int 9000
        --cors              :str 'https://vuer.ai,https://dash.ml,http://lo...
        --cert              :str None the path to the SSL certificate
        --key               :str None the path to the SSL key
        --ca-cert           :str None the trusted root CA certificates
        --REQUEST-MAX-SIZE  :int 100000000 the maximum packet size
        --free-port         :bool False
                              kill process squatting target port if True.
        --static-root       :str '.'
        --verbose           :bool False
                              show the list of configurations during launch if True.

    """

    prefix = "Zaku-task-queues"

    # Queue Parameters
    queue_len = 100  # use a max length to avoid the memory from blowing up.

    # Server Parameters
    host: str = Proto(
        "0.0.0.0",
        help="set to 0.0.0.0 to enable remote (not localhost) connections.",
        env="ZAKU_HOST"
    )
    port: int = Proto(
        9000,
        env="ZAKU_PORT"
    )
    cors: str = "https://vuer.ai,https://dash.ml,http://localhost:8000,http://127.0.0.1:8000,*"

    # SSL Parameters
    cert: str = Proto(None, dtype=str, help="the path to the SSL certificate")
    key: str = Proto(None, dtype=str, help="the path to the SSL key")
    ca_cert: str = Proto(None, dtype=str,
                         help="the trusted root CA certificates")

    REQUEST_MAX_SIZE: int = Proto(100_000_000, env="WEBSOCKET_MAX_SIZE",
                                  help="the maximum packet size")

    free_port: bool = Flag("kill process squatting target port if True.")
    static_root: str = "."
    verbose = Flag("show the list of configurations during launch if True.")

    def print_info(self):
        logger.info("========= Arguments =========")
        for k, v in vars(self).items():
            logger.info(f" {k} = {v},")
        logger.info("-----------------------------")

    def __post_init__(self, _deps=None):
        if self.verbose:
            self.print_info()

        Server.__post_init__(self)

        self.redis_wrapper = Redis(_deps)
        self.redis = self.redis_wrapper.connection
        # Initialize S3 for large payload storage (Pure Redis + S3 architecture)
        self.s3_wrapper = S3Storage(_deps)
        # Defer async initialization to aiohttp on_startup hook

    async def create_queue(self, request: web.Request):
        data = await request.json()
        try:
            await Job.create_queue(self.redis, **data, prefix=self.prefix)
        except Exception as e:
            # the error handling here is not ideal.
            return web.Response(text="ERROR: " + str(e), status=200)

        return web.Response(text="OK")

    async def add_job(self, request: web.Request):
        msg = await request.read()
        data = msgpack.unpackb(msg)
        # print("==>", data)
        job_id = await Job.add(self.redis, prefix=self.prefix, **data)
        # Return msgpack so client can parse without errors
        return web.Response(
            body=msgpack.packb({"job_id": job_id}, use_bin_type=True),
            status=200)

    async def publish_job(self, request: web.Request):
        msg = await request.read()
        data = msgpack.unpackb(msg)
        # print("==>", data)
        num_subscribers = await Job.publish(self.redis, prefix=self.prefix,
                                            **data)
        # todo: return the number of subscribers.
        return web.Response(text=str(num_subscribers), status=200)

    async def reset_handler(self, request: web.Request):
        data = await request.json()
        # print("==>", data)
        await Job.reset(self.redis, **data, prefix=self.prefix)
        return web.Response(text="OK")

    async def remove_handler(self, request: web.Request):
        data = await request.json()
        # print("remove ==>", data)
        await Job.remove(self.redis, **data, prefix=self.prefix)
        return web.Response(text="OK")

    async def count_files_handler(self, request):
        # Both sync and async clients send JSON in the body
        try:
            data = await request.json()
        except:
            data = {}

        try:
            counts = await Job.count_files(self.redis, **data,
                                           prefix=self.prefix)
        except redis.exceptions.ResponseError as e:
            if "No such index" in str(e):
                return web.Response(status=200)
            raise e

        msg = msgpack.packb({"counts": counts}, use_bin_type=True)
        return web.Response(body=msg, status=200)

    async def take_handler(self, request):
        # Support both JSON and msgpack for backward compatibility
        content_type = request.content_type
        if content_type == 'application/json' or 'json' in content_type:
            data = await request.json()
        else:
            # Default to msgpack (binary)
            msg = await request.read()
            if msg:
                data = msgpack.unpackb(msg)
            else:
                data = {}

        try:
            job_id, payload = await Job.take(self.redis, **data,
                                             prefix=self.prefix)
        except redis.exceptions.ResponseError as e:
            if "No such index" in str(e):
                return web.Response(status=200)
                # return web.Response(text="no such index", status=404)
            raise e

        if payload:
            msg = msgpack.packb({"job_id": job_id, "payload": payload},
                                use_bin_type=True)
            return web.Response(body=msg, status=200)

        return web.Response(status=200)

    async def unstale_handler(self, request: web.Request):
        data = await request.json()
        # print("take ==> data", data)
        await Job.unstale_tasks(self.redis, **data, prefix=self.prefix)

        return web.Response(text="OK", status=200)

    async def complete_task_handler(self, request: web.Request):
        """Mark a task as completed or failed (kept in Redis for 15 days)."""
        job_id = request.match_info.get('job_id')
        data = await request.json()

        try:
            await Job.complete_task(
                self.redis,
                job_id=job_id,
                queue=data['queue'],
                status=data.get('status', 'completed'),
                completed_ts=data.get('completed_ts', 0),
                error=data.get('error'),
                prefix=self.prefix,
                ttl_days=15
            )
            return web.Response(text="OK", status=200)
        except Exception as e:
            logger.error(f"Failed to complete task {job_id}: {e}")
            return web.Response(text=f"ERROR: {str(e)}", status=500)

    async def list_tasks_handler(self, request: web.Request):
        """List tasks from a queue.

        Query parameters:
            queue (required): Queue name
            status (optional): Filter by status - "all" (default), "pending", "in_progress", "completed", "failed"
            limit (optional): Max tasks to return (default: 20)
        """
        params = request.rel_url.query

        # Validate required parameter
        queue = params.get('queue')
        if not queue:
            return web.Response(text="ERROR: queue parameter is required", status=400)

        # Optional parameters
        status_filter = params.get('status', 'all')
        limit = int(params.get('limit', 20))

        try:
            tasks = await Job.list_tasks(
                self.redis,
                queue=queue,
                prefix=self.prefix,
                status=status_filter,
                limit=limit
            )

            return web.json_response({
                "tasks": tasks,
                "total": len(tasks),
                "queue": queue,
                "status_filter": status_filter
            })
        except Exception as e:
            logger.error(f"Failed to list tasks: {e}")
            return web.Response(text=f"ERROR: {str(e)}", status=500)

    async def get_task_handler(self, request: web.Request):
        """Get a single task's metadata.

        Path: /tasks/{job_id}
        Query parameters:
            queue (required): Queue name
        """
        job_id = request.match_info.get('job_id')
        params = request.rel_url.query

        queue = params.get('queue')
        if not queue:
            return web.Response(text="ERROR: queue parameter is required", status=400)

        try:
            task = await Job.get_task(
                self.redis,
                queue=queue,
                job_id=job_id,
                prefix=self.prefix
            )

            if not task:
                return web.Response(text=f"Task {job_id} not found", status=404)

            return web.json_response(task)
        except Exception as e:
            logger.error(f"Failed to get task {job_id}: {e}")
            return web.Response(text=f"ERROR: {str(e)}", status=500)

    async def get_task_logs_handler(self, request: web.Request):
        """Get task logs.

        Path: /tasks/{job_id}/logs
        Query parameters:
            queue (required): Queue name
            lines (optional): Number of lines to return (default: 100, max: 100)
        """
        job_id = request.match_info.get('job_id')
        params = request.rel_url.query

        queue = params.get('queue')
        if not queue:
            return web.Response(text="ERROR: queue parameter is required", status=400)

        lines = int(params.get('lines', 100))

        try:
            logs = await Job.get_logs(
                self.redis,
                queue=queue,
                job_id=job_id,
                prefix=self.prefix,
                lines=lines
            )

            return web.Response(
                text=logs,
                content_type="text/plain"
            )
        except Exception as e:
            logger.error(f"Failed to get logs for task {job_id}: {e}")
            return web.Response(text=f"ERROR: {str(e)}", status=500)

    async def append_task_log_handler(self, request: web.Request):
        """Append a log message to task logs (for worker use).

        Path: /tasks/{job_id}/logs
        Body: {"queue": "...", "message": "..."}
        """
        job_id = request.match_info.get('job_id')
        data = await request.json()

        queue = data.get('queue')
        message = data.get('message')

        if not queue or not message:
            return web.Response(text="ERROR: queue and message are required", status=400)

        try:
            success = await Job.append_log(
                self.redis,
                queue=queue,
                job_id=job_id,
                message=message,
                prefix=self.prefix
            )

            if success:
                return web.Response(text="OK", status=200)
            else:
                return web.Response(text="ERROR: Failed to append log", status=500)
        except Exception as e:
            logger.error(f"Failed to append log for task {job_id}: {e}")
            return web.Response(text=f"ERROR: {str(e)}", status=500)

    async def subscribe_one_handler(self, request):
        data = await request.json()

        payload = await Job.subscribe(self.redis, **data, prefix=self.prefix)

        if payload:
            return web.Response(body=payload, status=200)

        return web.Response(status=200)

    async def subscribe_streaming_handler(self, request) -> web.StreamResponse:
        data = await request.json()

        async def stream_response(response):
            try:
                async for payload in Job.subscribe_stream(self.redis, **data,
                                                          prefix=self.prefix):
                    # use msgpack.Unpacker to determin the end of message.
                    await response.write(payload)

                await response.write_eof()

            except ConnectionResetError:
                logger.info("client disconnected.")
                return response

            return response

        response = web.StreamResponse(
            status=200,
            reason="OK",
            headers={"Content-Type": "text/plain"},
        )
        await response.prepare(request)
        await stream_response(response)
        return response

    def setup_server(self):
        import os

        # use the same endpoint for websocket and file serving.
        self._route("/queues", self.create_queue, method="PUT")
        self._route("/tasks", self.add_job, method="PUT")
        self._route("/tasks", self.take_handler, method="POST")
        self._route("/tasks", self.list_tasks_handler, method="GET")
        self._route("/tasks/counts", self.count_files_handler, method="GET")
        self._route("/tasks/reset", self.reset_handler, method="POST")
        self._route("/tasks", self.remove_handler, method="DELETE")
        self._route("/tasks/unstale", self.unstale_handler, method="PUT")

        # Task management endpoints
        self._route("/tasks/{job_id}/complete", self.complete_task_handler, method="PUT")
        self._route("/tasks/{job_id}", self.get_task_handler, method="GET")
        self._route("/tasks/{job_id}/logs", self.get_task_logs_handler, method="GET")
        self._route("/tasks/{job_id}/logs", self.append_task_log_handler, method="POST")

        self._route("/publish", self.publish_job, method="PUT")
        self._route("/subscribe_one", self.subscribe_one_handler,
                    method="POST")
        self._route("/subscribe_stream", self.subscribe_streaming_handler,
                    method="POST")

        # serve local files via /static endpoint
        self._static("/static", self.static_root)
        logger.info("Serving file://" + os.path.abspath(self.static_root),
                    "at", "/static")

        # Ensure async dependencies are initialized when the app starts
        self.app.on_startup.append(self._on_startup)

        return self.app

    async def _on_startup(self, app):
        # Initialize external services within the running event loop
        await self.check_redis_available(self.redis)
        # S3 is managed by clients, server only handles Redis

    async def check_redis_available(self, client: redis.Redis):
        try:
            await client.ping()
            logger.info(f"Redis server is connected")
        except Exception as e:
            logger.error(f"Redis unavailable: {e}")
            raise

    def run(self, kill=None, *args, **kwargs):
        if kill or self.free_port:
            import time
            from killport import kill_ports

            kill_ports(ports=[self.port])
            time.sleep(0.01)

        self.setup_server()
        logger.info(f"serving at {self.host}:{self.port}")
        super().run()


def entry_point():
    TaskServer().run()


async def get_app():
    """This is sued by gunicorn to run the server in worker mode."""
    return TaskServer().setup_server()


if __name__ == "__main__":
    entry_point()
