"""
Zaku Async Client - asynchronous high-performance client

Supports:
- Direct S3 upload/download (bypass the server)
- Batch concurrent downloads (fetch N tasks at once and download concurrently)
- Fully asynchronous API
"""

import os
import asyncio
import msgpack
import aiohttp
import aioboto3
from typing import Optional, Dict, List, Tuple, Any, Callable, Awaitable
from bson import ObjectId
import logging as logger

from zaku.schemas import TrainingJob


class AsyncZakuClient:
    """Asynchronous Zaku client - maximize throughput"""

    def __init__(
            self,
            uri: str,
            queue_name: str,
            s3_bucket: Optional[str] = None,
            s3_region: str = "us-east-1",
            session: Optional[aiohttp.ClientSession] = None,
            max_s3_concurrency: int = 100,
            max_server_concurrency: int = 100,
            enable_s3_accelerate: bool = False
    ):
        self.uri = uri
        self.queue_name = queue_name
        self.s3_bucket = s3_bucket or os.getenv("S3_BUCKET", "zaku-payloads")
        self.s3_region = s3_region
        self.enable_s3_accelerate = enable_s3_accelerate
        self._session = session
        self._own_session = session is None
        self.s3_session = aioboto3.Session()
        self._s3_client = None
        self._own_s3_client = True
        self._s3_semaphore = asyncio.Semaphore(max_s3_concurrency)
        self._server_semaphore = asyncio.Semaphore(max_server_concurrency)

    async def __aenter__(self):
        if self._own_session:
            timeout = aiohttp.ClientTimeout(total=300, connect=120,
                                            sock_read=120)
            connector = aiohttp.TCPConnector(
                limit=1000,
                limit_per_host=1000,
                ttl_dns_cache=600,
                keepalive_timeout=60,
                force_close=False,
                enable_cleanup_closed=True
            )
            self._session = aiohttp.ClientSession(timeout=timeout,
                                                  connector=connector)

        if self._s3_client is None:
            from aiobotocore.config import AioConfig

            # Build config parameters with increased timeouts
            config_params = {
                'max_pool_connections': 1000,
                'retries': {'max_attempts': 3, 'mode': 'adaptive'},
                'connect_timeout': 60,  # 60 seconds for connection
                'read_timeout': 300  # 5 minutes for reading (large files)
            }

            # Enable S3 Transfer Acceleration if requested
            if self.enable_s3_accelerate:
                config_params['s3'] = {'use_accelerate_endpoint': True}

            config = AioConfig(**config_params)

            self._s3_client = await self.s3_session.client(
                "s3",
                region_name=self.s3_region,
                config=config
            ).__aenter__()

        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._own_session and self._session:
            await self._session.close()

        if self._own_s3_client and self._s3_client:
            await self._s3_client.__aexit__(exc_type, exc_val, exc_tb)
            self._s3_client = None

    async def add_task(
            self,
            payload: Any,
            job_id: Optional[str] = None,
            metadata: Optional[Dict] = None
    ) -> str:
        """Add a task - upload payload to S3 + send metadata to server

        Args:
            payload: Task data (will be serialized as Payload)
            job_id: Optional custom job_id
            metadata: User-defined metadata (task_name, submitted_by, etc.)

        Returns:
            job_id
        """
        from zaku.interfaces import Payload as PayloadClass

        # 1. Serialize payload (Payload supports numpy/torch)
        p = PayloadClass(**payload) if isinstance(payload,
                                                  dict) else PayloadClass(
            data=payload)
        payload_bytes = p.serialize()

        # 2. Generate job_id and s3_key
        used_job_id = job_id if job_id else str(ObjectId())
        s3_key = f"zaku/{self.queue_name}/{used_job_id}"

        # 3. Upload to S3 with semaphore to limit concurrency
        async with self._s3_semaphore:
            await self._s3_client.put_object(
                Bucket=self.s3_bucket,
                Key=s3_key,
                Body=payload_bytes,
                Metadata={
                    "job-id": used_job_id,
                    "queue": self.queue_name,
                    "size": str(len(payload_bytes))
                }
            )

        # 4. Send metadata to server (limit concurrent requests to avoid connection issues)
        data = {
            "queue": self.queue_name,
            "s3_key": s3_key,
            "s3_bucket": self.s3_bucket,
            "size": len(payload_bytes),
            "job_id": used_job_id,
            "metadata": metadata or {}  # User-defined metadata
        }

        async with self._server_semaphore:
            async with self._session.put(
                    f"{self.uri}/tasks",
                    data=msgpack.packb(data, use_bin_type=True)
            ) as resp:
                result = msgpack.unpackb(await resp.read(), raw=False)
                return result["job_id"]

    async def take_task(self) -> Tuple[Optional[str], Optional[Dict]]:
        """Retrieve a single task (returns only metadata, does not download payload)

        Returns:
            (job_id, metadata) where metadata contains _s3_key
        """
        data = {"queue": self.queue_name}

        async with self._session.post(
                f"{self.uri}/tasks",
                data=msgpack.packb(data, use_bin_type=True)
        ) as resp:
            if resp.status != 200:
                return None, None

            content = await resp.read()
            if len(content) == 0:
                return None, None

            result = msgpack.unpackb(content, raw=False)
            job_id = result.get("job_id")
            payload = result.get("payload")

            # Check if payload is already a dict or needs unpacking
            if payload:
                if isinstance(payload, bytes):
                    metadata = msgpack.unpackb(payload, raw=False)
                else:
                    metadata = payload
            else:
                metadata = None

            return job_id, metadata

    async def take_batch(self, count: int) -> List[
        Tuple[Optional[str], Optional[Dict]]]:
        """Batch retrieve task metadata (concurrent, high-performance)

        Args:
            count: Number of tasks to retrieve (user-defined threshold)

        Returns:
            [(job_id, metadata), ...]
        """
        take_tasks = [self.take_task() for _ in range(count)]
        results = await asyncio.gather(*take_tasks, return_exceptions=True)
        batch = []
        for result in results:
            if isinstance(result, Exception):
                continue
            job_id, metadata = result
            if job_id and metadata:
                batch.append((job_id, metadata))

        return batch

    async def download_payload(self, s3_key: str) -> bytes:
        """Download a single payload from S3

        Args:
            s3_key: S3 object key

        Returns:
            payload bytes
        """
        async with self._s3_semaphore:
            response = await self._s3_client.get_object(
                Bucket=self.s3_bucket,
                Key=s3_key,
            )
            body = bytearray()
            stream = response["Body"]
            try:
                async for chunk in stream.iter_chunks(
                        chunk_size=1024 * 1024):  # 1MB
                    body.extend(chunk)
            finally:
                stream.close()
            return bytes(body)

    async def download_payloads(self, s3_keys: List[str]) -> List[bytes]:
        """Concurrently download multiple payloads (key performance optimization)

        Args:
            s3_keys: List of S3 keys

        Returns:
            [payload_bytes, ...]
        """
        tasks = [self.download_payload(key) for key in s3_keys]
        payloads = await asyncio.gather(*tasks)
        return payloads

    async def mark_done(
            self,
            job_id: str,
            status: str = "completed",
            error: Optional[str] = None
    ) -> bool:
        """Mark a task as completed or failed and keep in Redis for 15 days.

        Args:
            job_id: Task ID
            status: Status to set ("completed" or "failed"), default "completed"
            error: Error message if status is "failed" (optional)

        Returns:
            whether it succeeded

        Strategy:
        1. Update status in Redis metadata (keep for 15 days)
        2. Delete S3 payload (save costs)
        3. Move from processing to completed/failed zset
        """
        from time import time

        # Validate status
        if status not in ["completed", "failed"]:
            raise ValueError(
                f"Invalid status: {status}. Must be 'completed' or 'failed'")

        # 1. Update status via complete API
        data = {
            "queue": self.queue_name,
            "job_id": job_id,
            "status": status,
            "completed_ts": time()
        }
        if error:
            data["error"] = error

        async with self._session.put(
                f"{self.uri}/tasks/{job_id}/complete",
                json=data
        ) as resp:
            if resp.status != 200:
                logger.error(f"Failed to mark job {job_id} as {status}")
                return False

        # 2. Delete S3 payload to save costs
        s3_key = f"zaku/{self.queue_name}/{job_id}"
        try:
            await self._s3_client.delete_object(
                Bucket=self.s3_bucket,
                Key=s3_key
            )
            logger.debug(f"Deleted S3 payload for job {job_id}")
        except Exception as e:
            logger.warning(f"Failed to delete S3 object {s3_key}: {e}")

        return True

    async def append_log(self, job_id: str, message: str) -> bool:
        """Append a log message to task logs.

        Args:
            job_id: Task ID
            message: Log message to append

        Returns:
            True if successful

        Note:
            - Logs are stored in Redis (latest 100 lines)
            - Logs expire after 15 days
            - Timestamp is added automatically by server
        """
        try:
            data = {
                "queue": self.queue_name,
                "message": message
            }
            async with self._session.post(
                    f"{self.uri}/tasks/{job_id}/logs",
                    json=data
            ) as resp:
                if resp.status == 200:
                    return True
                else:
                    logger.warning(
                        f"Failed to append log: {await resp.text()}")
                    return False
        except Exception as e:
            logger.warning(f"Failed to append log for job {job_id}: {e}")
            return False

    async def list_tasks(self, status: str = "all", limit: int = 20) -> dict:
        """List tasks in the queue.

        Args:
            status: Filter by status ("all", "pending", "in_progress", "completed", "failed")
            limit: Maximum number of tasks to return

        Returns:
            Dict with task list and metadata
        """
        params = {
            "queue": self.queue_name,
            "status": status,
            "limit": limit
        }
        async with self._session.get(
                f"{self.uri}/tasks",
                params=params
        ) as resp:
            if resp.status == 200:
                return await resp.json()
            else:
                logger.error(f"Failed to list tasks: {await resp.text()}")
                return {"tasks": [], "total": 0}

    async def get_task(self, job_id: str) -> dict:
        """Get details of a single task.

        Args:
            job_id: Task ID

        Returns:
            Task details dict
        """
        params = {"queue": self.queue_name}
        async with self._session.get(
                f"{self.uri}/tasks/{job_id}",
                params=params
        ) as resp:
            if resp.status == 200:
                return await resp.json()
            else:
                logger.error(
                    f"Failed to get task {job_id}: {await resp.text()}")
                return {}

    async def get_logs(self, job_id: str, lines: int = 100) -> str:
        """Get logs for a task.

        Args:
            job_id: Task ID
            lines: Number of log lines to retrieve (max 100)

        Returns:
            Log text
        """
        params = {
            "queue": self.queue_name,
            "lines": lines
        }
        async with self._session.get(
                f"{self.uri}/tasks/{job_id}/logs",
                params=params
        ) as resp:
            if resp.status == 200:
                return await resp.text()
            else:
                logger.error(
                    f"Failed to get logs for task {job_id}: {await resp.text()}")
                return ""

    async def mark_reset(self, job_id: str) -> bool:
        """Reset task status

        Args:
            job_id: Task ID

        Returns:
            whether it succeeded
        """
        data = {"queue": self.queue_name, "job_id": job_id}

        async with self._session.post(
                f"{self.uri}/tasks/reset",
                json=data
        ) as resp:
            return resp.status == 200

    async def queue_length(self) -> Optional[int]:
        """Get queue length

        Returns:
            Number of tasks in the queue or None if unavailable
        """
        data = {"queue": self.queue_name}

        async with self._session.get(
                f"{self.uri}/tasks/counts",
                json=data
        ) as resp:
            content = await resp.read()
            if not content:
                return None
            result = msgpack.unpackb(content, raw=False)
            return result.get("counts", 0)

    async def clear_queue(self) -> bool:
        """Thoroughly clean the queue (all data in Redis + S3)

        Strategy:
        1、 Delete all tasks in Redis via server API
        2、 Delete all S3 objects under the queue prefix
        Returns:
            whether it succeeded
        """
        try:
            data = {"queue": self.queue_name, "job_id": "*"}
            async with self._session.delete(
                    f"{self.uri}/tasks",
                    json=data
            ) as resp:
                redis_success = resp.status == 200

            if not redis_success:
                logger.error(
                    f"Redis cleanup failed for queue '{self.queue_name}'")
                return False

            logger.info(f"Redis cleanup success for queue '{self.queue_name}'")
            s3_count = await self.clear_s3_prefix()
            logger.info(f"Client-side S3 cleanup: {s3_count} objects deleted")

            logger.info(
                f"Queue '{self.queue_name}' cleared: Redis=success, S3={s3_count}")
            return True

        except Exception as e:
            logger.error(f"Queue cleanup failed: {e}")
            return False

    async def clear_s3_prefix(self, prefix: Optional[str] = None) -> int:
        """Clear all S3 objects under a prefix (useful for cleanup)

        Args:
            prefix: S3 prefix to clear, defaults to zaku/{queue_name}/

        Returns:
            number of deleted objects
        """
        if prefix is None:
            prefix = f"zaku/{self.queue_name}/"

        keys_to_delete = []
        paginator = self._s3_client.get_paginator('list_objects_v2').paginate(
            Bucket=self.s3_bucket,
            Prefix=prefix
        )
        async for page in paginator:
            for obj in page.get('Contents', []):
                keys_to_delete.append(obj['Key'])

        if not keys_to_delete:
            logger.info(f"No S3 objects found under prefix {prefix}")
            return 0

        logger.info(
            f"Found {len(keys_to_delete)} S3 objects to delete under prefix {prefix}")

        async def delete_batch(batch_keys, batch_num):
            response = await self._s3_client.delete_objects(
                Bucket=self.s3_bucket,
                Delete={'Objects': [{'Key': k} for k in batch_keys]}
            )
            deleted = len(response.get('Deleted', []))
            logger.info(f"Deleted batch {batch_num}: {deleted} objects")
            return deleted

        delete_tasks = []
        for i in range(0, len(keys_to_delete), 1000):
            batch = keys_to_delete[i:i + 1000]
            batch_num = i // 1000 + 1
            delete_tasks.append(delete_batch(batch, batch_num))
        semaphore = asyncio.Semaphore(10)

        async def limited_delete(task):
            async with semaphore:
                return await task

        results = await asyncio.gather(
            *[limited_delete(task) for task in delete_tasks],
            return_exceptions=True
        )
        deleted_count = 0
        for r in results:
            if not isinstance(r, Exception) and isinstance(r, int):
                deleted_count += r

        logger.info(
            f"Total deleted: {deleted_count}/{len(keys_to_delete)} S3 objects")
        return deleted_count

    async def init_queue(self) -> bool:
        """Initialize the queue

        Returns:
            whether it succeeded
        """
        async with self._session.put(
                f"{self.uri}/queues",
                json={"name": self.queue_name}
        ) as resp:
            return resp.status == 200

    async def publish(self, payload: Any, topic_id: Optional[str] = None) -> \
            Optional[int]:
        """Publish a message to a topic

        Args:
            payload: Message data
            topic_id: Optional topic ID

        Returns:
            number of messages or None
        """
        from uuid import uuid4

        if topic_id is None:
            topic_id = str(uuid4())

        payload_bytes = msgpack.packb(payload, use_bin_type=True)

        data = {
            "queue": self.queue_name,
            "topic_id": topic_id,
            "payload": payload_bytes,
        }

        async with self._session.put(
                f"{self.uri}/publish",
                data=msgpack.packb(data, use_bin_type=True)
        ) as resp:
            if resp.status == 200:
                try:
                    text = await resp.text()
                    return int(text)
                except Exception:
                    return None
            return None

    async def subscribe_one(self, topic_id: str, timeout: float = 0.1) -> \
            Optional[Any]:
        """Subscribe for a single message

        Args:
            topic_id: Topic ID
            timeout: Timeout in seconds

        Returns:
            message data or None
        """
        async with self._session.post(
                f"{self.uri}/subscribe_one",
                json={"queue": self.queue_name, "topic_id": topic_id,
                      "timeout": timeout}
        ) as resp:
            if resp.status != 200:
                return None

            content = await resp.read()
            if not content:
                return None

            return msgpack.unpackb(content, raw=False)

    async def subscribe_stream(self, topic_id: str, timeout: float = 0.1):
        """Subscribe to a message stream (async generator)

        Args:
            topic_id: Topic ID
            timeout: Timeout in seconds

        Yields:
            message data
        """
        async with self._session.post(
                f"{self.uri}/subscribe_stream",
                json={"queue": self.queue_name, "topic_id": topic_id,
                      "timeout": timeout}
        ) as resp:
            resp.raise_for_status()
            unpacker = msgpack.Unpacker()

            async for chunk in resp.content.iter_chunked(8192):
                unpacker.feed(chunk)
                for unpacked in unpacker:
                    yield msgpack.unpackb(msgpack.packb(unpacked), raw=False)

    async def unstale_tasks(self, ttl: int = 300) -> bool:
        """Clean up stale tasks

        Args:
            ttl: Time-to-live in seconds

        Returns:
            whether it succeeded
        """
        async with self._session.put(
                f"{self.uri}/tasks/unstale",
                json={"queue": self.queue_name, "ttl": ttl}
        ) as resp:
            return resp.status == 200


class TaskQAsync:
    """Asynchronous task queue client - compatible with legacy API

    Example usage:
        async with TaskQAsync(name="my-queue") as queue:
            # Add a task
            job_id = await queue.add({"data": ...})

            # Batch fetch + concurrent download
            batch = await queue.take_batch(100)
            s3_keys = [meta["_s3_key"] for _, meta in batch]
            payloads = await queue.download_payloads(s3_keys)

            # Process
            for (job_id, meta), payload_bytes in zip(batch, payloads):
                payload = msgpack.unpackb(payload_bytes, raw=False)
                process(payload)
                await queue.mark_done(job_id)
    """

    def __init__(
            self,
            name: str,
            uri: Optional[str] = None,
            s3_bucket: Optional[str] = None,
            s3_region: str = "us-east-1",
            max_s3_concurrency: int = 100,
            max_server_concurrency: int = 100,
            enable_s3_accelerate: bool = False
    ):
        # Load environment variables first
        from dotenv import load_dotenv
        load_dotenv()

        self.name = name
        self.uri = uri or os.getenv("ZAKU_URI", "http://localhost:9000")
        # Update S3 settings from environment
        self.s3_bucket = s3_bucket or os.getenv("S3_BUCKET", "zaku-payloads")
        self.s3_region = os.getenv("S3_REGION", s3_region)
        self.max_s3_concurrency = max_s3_concurrency
        self.max_server_concurrency = max_server_concurrency
        self.enable_s3_accelerate = enable_s3_accelerate
        self._client = None

    async def __aenter__(self):
        self._client = AsyncZakuClient(
            uri=self.uri,
            queue_name=self.name,
            s3_bucket=self.s3_bucket,
            s3_region=self.s3_region,
            max_s3_concurrency=self.max_s3_concurrency,
            max_server_concurrency=self.max_server_concurrency,
            enable_s3_accelerate=self.enable_s3_accelerate
        )
        await self._client.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._client:
            await self._client.__aexit__(exc_type, exc_val, exc_tb)

    async def add(
            self,
            value: Any,
            job_id: Optional[str] = None,
            key: Optional[str] = None,
            metadata: Optional[Dict] = None
    ) -> str:
        """Add a task

        Args:
            value: Task data
            job_id: Optional task ID
            key: Alternative task ID (legacy compatibility)
            metadata: User-defined metadata (task_name, submitted_by, etc.)

        Returns:
            job_id
        """
        # Support legacy API key parameter
        used_job_id = job_id or key
        return await self._client.add_task(value, used_job_id, metadata)

    async def add_training_job(self, value: TrainingJob,
                               metadata: Optional[Dict] = None) -> str:
        from dataclasses import asdict
        """Add a training job (wrapper for add)"""
        return await self.add(asdict(value), metadata=metadata)

    async def take(self) -> Tuple[Optional[str], Optional[Any]]:
        """Retrieve a task (returns only metadata)"""
        return await self._client.take_task()

    async def take_batch(self, count: int) -> List[
        Tuple[Optional[str], Optional[Dict]]]:
        """Batch retrieve task metadata"""
        return await self._client.take_batch(count)

    async def download_from_s3(self, s3_key: str) -> bytes:
        """Download a single payload from S3"""
        return await self._client.download_payload(s3_key)

    async def download_payloads(self, s3_keys: List[str]) -> List[bytes]:
        """Concurrently download payloads"""
        return await self._client.download_payloads(s3_keys)

    async def mark_done(
            self,
            job_id: str,
            status: str = "completed",
            error: Optional[str] = None
    ) -> bool:
        """Mark task as completed or failed"""
        return await self._client.mark_done(job_id, status, error)

    async def mark_reset(self, job_id: str) -> bool:
        """Reset task"""
        return await self._client.mark_reset(job_id)

    async def append_log(self, job_id: str, message: str) -> bool:
        """Append log message to task"""
        return await self._client.append_log(job_id, message)

    async def list_tasks(self, status: str = "all", limit: int = 20) -> dict:
        """List tasks in the queue.

        Args:
            status: Filter by status ("all", "pending", "in_progress", "completed", "failed")
            limit: Maximum number of tasks to return

        Returns:
            Dict with task list and metadata
        """
        return await self._client.list_tasks(status, limit)

    async def get_task(self, job_id: str) -> dict:
        """Get details of a single task.

        Args:
            job_id: Task ID

        Returns:
            Task details dict
        """
        return await self._client.get_task(job_id)

    async def get_logs(self, job_id: str, lines: int = 100) -> str:
        """Get logs for a task.

        Args:
            job_id: Task ID
            lines: Number of log lines to retrieve (max 100)

        Returns:
            Log text
        """
        return await self._client.get_logs(job_id, lines)

    async def queue_length(self) -> Optional[int]:
        """Queue length"""
        return await self._client.queue_length()

    async def clear_queue(self) -> bool:
        """
        Thoroughly clean the queue (all data in Redis + S3, executed concurrently)
        """
        return await self._client.clear_queue()

    async def clear_s3_prefix(self, prefix: Optional[str] = None) -> int:
        """Clear all S3 objects under a prefix (useful for cleanup residual objects)

        Args:
            prefix: S3 prefix to clear, defaults to zaku/{queue_name}/

        Returns:
            number of deleted objects

        Example:
            # Clear all S3 objects for this queue
            deleted = await queue.clear_s3_prefix()
            print(f"Deleted {deleted} residual S3 objects")
        """
        return await self._client.clear_s3_prefix(prefix)

    # Advanced API for batch consumption
    async def consume_batch(
            self,
            count: int,
            processor: Callable[[Any], Awaitable[bool]],
            auto_mark_done: bool = True
    ) -> int:
        """Consume tasks in batch (high-performance mode)

        Args:
            count: Number of tasks to fetch in one batch
            processor: Async processing function async def process(payload) -> bool
            auto_mark_done: Whether to auto mark tasks as done

        Returns:
            Number of successfully processed tasks

        Example:
            async def process(payload):
                # processing logic
                return True

            processed = await queue.consume_batch(100, process)
        """
        # Stage 1: Batch fetch metadata (fast)
        batch = await self.take_batch(count)
        if not batch:
            return 0

        # Stage 2: Extract s3_keys
        s3_keys = [meta.get("_s3_key") for _, meta in batch if
                   meta.get("_s3_key")]

        # Stage 3: Concurrently download payloads
        payloads = await self.download_payloads(s3_keys)

        # Stage 4: Process tasks
        success_count = 0
        for (job_id, meta), payload_bytes in zip(batch, payloads):
            try:
                payload = msgpack.unpackb(payload_bytes, raw=False)
                result = await processor(payload)

                if result and auto_mark_done:
                    await self.mark_done(job_id)
                    success_count += 1
            except Exception as e:
                print(f"Error processing job {job_id}: {e}")
                # Reset task on error
                await self.mark_reset(job_id)

        return success_count

    # ================== Legacy-compatible methods ==================

    async def init_queue(self, name: Optional[str] = None) -> bool:
        """Initialize queue

        Args:
            name: Optional queue name

        Returns:
            whether it succeeded
        """
        if name:
            self.name = name
            self._client.queue_name = name
        return await self._client.init_queue()

    async def count(self) -> Optional[int]:
        """Get number of tasks in the queue (legacy-compatible)

        Returns:
            Number of tasks, or None if queue doesn't exist
        """
        return await self.queue_length()

    def __len__(self):
        """Return queue length (requires async context)

        Note: Due to async limitations, prefer using await queue.count()
        """
        import warnings
        warnings.warn(
            "len(queue) is not supported in async context. Use 'await queue.count()' instead.",
            DeprecationWarning
        )
        return 0

    def print_info(self):
        """Print queue configuration info"""
        print("=============================")
        print(f" name = {self.name}")
        print(f" uri = {self.uri}")
        print(f" s3_bucket = {self.s3_bucket}")
        print(f" s3_region = {self.s3_region}")
        print("=============================")

    # ================== PubSub methods ==================

    async def publish(self, value: Dict, *, topic: Optional[str] = None) -> \
            Optional[int]:
        """Publish a message to a topic

        Args:
            value: Message data
            topic: Optional topic ID

        Returns:
            Number of messages or None
        """
        return await self._client.publish(value, topic_id=topic)

    async def subscribe_one(self, topic: str, timeout: float = 0.1) -> \
            Optional[Any]:
        """Subscribe and wait for a single message

        Args:
            topic: Topic ID
            timeout: Timeout in seconds

        Returns:
            Message data or None
        """
        return await self._client.subscribe_one(topic, timeout)

    async def subscribe_stream(self, topic: str, timeout: float = 0.1):
        """Subscribe to a message stream

        Args:
            topic: Topic ID
            timeout: Timeout in seconds

        Yields:
            Message data
        """
        async for message in self._client.subscribe_stream(topic, timeout):
            yield message

    # ================== RPC methods ==================

    async def rpc(self, *args, _timeout: float = 1.0, **kwargs) -> Optional[
        Any]:
        """RPC call (request-response pattern)

        Args:
            *args: positional arguments
            _timeout: timeout in seconds
            **kwargs: keyword arguments

        Returns:
            response data
        """
        from uuid import uuid4

        request_id = uuid4()
        topic_name = f"rpc-{request_id}"

        # Add request to queue
        await self.add({
            "_request_id": topic_name,
            "_args": args,
            **kwargs,
        })

        # Wait for response
        return await self.subscribe_one(topic_name, timeout=_timeout)

    async def rpc_stream(self, *args, _timeout: float = 1.0, **kwargs):
        """RPC streaming call

        Args:
            *args: positional arguments
            _timeout: timeout in seconds
            **kwargs: keyword arguments

        Yields:
            response data
        """
        from uuid import uuid4

        request_id = uuid4()
        topic_name = f"rpc-{request_id}"

        # Add request to queue
        await self.add({
            "_request_id": topic_name,
            "_args": args,
            **kwargs,
        })

        # Stream responses
        async for response in self.subscribe_stream(topic_name,
                                                    timeout=_timeout):
            yield response

    # ================== Gather methods (MapReduce pattern) ==================

    async def gather(
            self,
            jobs: list,
            gather_tokens: Optional[set] = None,
            prefix: str = "{self.name}.return-queue"
    ):
        """Submit multiple jobs and track completion status (MapReduce pattern)

        Args:
            jobs: List of jobs
            gather_tokens: Optional set of tracking tokens
            prefix: Return queue name prefix

        Returns:
            (is_done, gather_tokens) - is_done is a checker function, gather_tokens is the tracking set

        Example:
            jobs = [{"seed": i} for i in range(30)]
            is_done, tokens = await queue.gather(jobs)

            # Poll to check completion
            if await is_done(blocking=True):
                print("All jobs completed!")
        """
        from uuid import uuid4

        r_id = uuid4()
        r_queue_name = prefix.format(self=self, r_id=r_id)
        gather_queue = TaskQAsync(name=r_queue_name, uri=self.uri,
                                  s3_bucket=self.s3_bucket)
        await gather_queue.__aenter__()

        gather_tokens = gather_tokens or set()

        # Submit all jobs
        for job in jobs:
            gather_token = f"gather-{uuid4()}"
            gather_tokens.add(gather_token)

            r_spec = {
                "_gather_id": r_queue_name,
                "_gather_token": gather_token,
            }

            await self.add({**r_spec, **job})

        async def is_done(blocking: bool = False, sleep: float = 0.1) -> bool:
            """Check whether all jobs are completed

            Args:
                blocking: Whether to block until completion
                sleep: Polling interval in seconds

            Returns:
                whether all jobs are completed
            """
            nonlocal gather_queue, gather_tokens

            job = True
            while gather_tokens and (blocking or job):
                ret = await gather_queue.take()
                if ret is None or ret[0] is None:
                    job = None
                    if blocking:
                        await asyncio.sleep(sleep)
                    continue

                job_id, metadata = ret

                # Download payload
                if metadata and "_s3_key" in metadata:
                    s3_key = metadata["_s3_key"]
                    payloads = await gather_queue.download_payloads([s3_key])
                    job_data = msgpack.unpackb(payloads[0], raw=False)
                else:
                    job_data = metadata

                await gather_queue.mark_done(job_id)

                try:
                    gt = job_data["_gather_token"]
                except KeyError:
                    await gather_queue.clear_queue()
                    raise

                try:
                    gather_tokens.remove(gt)
                except KeyError:
                    pass

            return not gather_tokens

        return is_done, gather_tokens

    async def gather_one(
            self,
            job: dict,
            gather_tokens: Optional[set] = None,
            **kwargs
    ):
        """Submit a single job and track completion status

        Args:
            job: Single job
            gather_tokens: Optional tracking token set
            **kwargs: Additional parameters

        Returns:
            (is_done, gather_tokens)
        """
        return await self.gather(jobs=[job], gather_tokens=gather_tokens,
                                 **kwargs)

    # ================== Context manager helpers ==================

    def pop(self):
        """Async context manager for popping a job

        Example:
            async with queue.pop() as job:
                if job:
                    process(job)
        """
        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def _pop_context():
            job_tuple = await self.take()
            if not job_tuple or job_tuple[0] is None:
                yield None
                return

            job_id, metadata = job_tuple

            # Download payload
            job_data = None
            if metadata and "_s3_key" in metadata:
                try:
                    from zaku.interfaces import Payload as PayloadClass
                    s3_key = metadata["_s3_key"]
                    payload_bytes = await self.download_from_s3(s3_key)
                    job_data = PayloadClass.deserialize(payload_bytes)
                except Exception as e:
                    await self.mark_reset(job_id)
                    raise e

            try:
                yield job_data
            except SystemExit as e:
                await self.mark_done(job_id)
                raise e
            except Exception as e:
                await self.mark_reset(job_id)
                raise e

            await self.mark_done(job_id)

        return _pop_context()

    async def unstale_tasks(self, ttl: int = 300) -> bool:
        """Clean up stale tasks

        Args:
            ttl: Time-to-live in seconds

        Returns:
            whether it succeeded
        """
        return await self._client.unstale_tasks(ttl)

    # ================== Async For Style Methods (High Performance) ==================

    async def iter_consume(
            self,
            batch_size: int = 10,
            auto_mark_done: bool = True,
            prefetch: bool = True
    ):
        """Stream consume tasks using async for syntax (high-performance with prefetching)

        Internally uses high-performance gather() for concurrent operations,
        while providing clean async for syntax for iteration.

        Args:
            batch_size: Number of tasks to fetch per batch
            auto_mark_done: Automatically mark tasks as done after yielding
            prefetch: Prefetch next batch while processing current batch (improves throughput)

        Yields:
            (job_id, payload_dict) tuples

        Example:
            # Simple usage
            async for job_id, payload in queue.iter_consume(batch_size=100):
                process(payload)
                # Automatically marked as done

            # Manual mark_done
            async for job_id, payload in queue.iter_consume(batch_size=100, auto_mark_done=False):
                if process(payload):
                    await queue.mark_done(job_id)
                else:
                    await queue.mark_reset(job_id)
        """
        next_batch_task = None

        while True:
            # Get tasks (from prefetch or fresh fetch)
            if prefetch and next_batch_task:
                batch = await next_batch_task
            else:
                batch = await self.take_batch(batch_size)

            if not batch:
                break

            # Prefetch next batch while processing current (improves throughput)
            if prefetch:
                next_batch_task = asyncio.create_task(
                    self.take_batch(batch_size))

            # Download payloads (concurrent with gather)
            s3_keys = [meta["_s3_key"] for _, meta in batch if
                       meta.get("_s3_key")]
            if not s3_keys:
                continue

            payloads = await self.download_payloads(s3_keys)

            # Yield tasks one by one
            for (job_id, _), payload_bytes in zip(batch, payloads):
                try:
                    payload = msgpack.unpackb(payload_bytes, raw=False)
                    yield job_id, payload

                    if auto_mark_done:
                        await self.mark_done(job_id)

                except Exception as e:
                    await self.mark_reset(job_id)
                    raise e

    async def iter_tasks(self, batch_size: int = 10, download: bool = False):
        """Stream tasks using async for syntax (metadata only or with payload)

        Args:
            batch_size: Number of tasks to fetch per batch
            download: Whether to download payloads (default False for lightweight iteration)

        Yields:
            If download=False: (job_id, metadata_dict)
            If download=True: (job_id, payload_dict)

        Example:
            # Lightweight: only metadata (no S3 download)
            async for job_id, metadata in queue.iter_tasks(batch_size=100):
                print(f"Task {job_id}: {metadata['_s3_key']}")

            # With payload download
            async for job_id, payload in queue.iter_tasks(batch_size=100, download=True):
                process(payload)
                await queue.mark_done(job_id)
        """
        while True:
            batch = await self.take_batch(batch_size)
            if not batch:
                break

            if download:
                # Download payloads
                s3_keys = [meta["_s3_key"] for _, meta in batch if
                           meta.get("_s3_key")]
                if s3_keys:
                    payloads = await self.download_payloads(s3_keys)

                    for (job_id, _), payload_bytes in zip(batch, payloads):
                        payload = msgpack.unpackb(payload_bytes, raw=False)
                        yield job_id, payload
            else:
                # Metadata only (lightweight)
                for job_id, metadata in batch:
                    yield job_id, metadata

    async def iter_download_stream(self, s3_keys: List[str],
                                   batch_size: int = 100):
        """Stream payloads as they download (memory-efficient for large datasets)

        Uses asyncio.as_completed to yield results as soon as they're ready,
        rather than waiting for entire batch.

        Args:
            s3_keys: List of S3 keys to download
            batch_size: Concurrent download batch size

        Yields:
            (s3_key, payload_bytes) tuples as each download completes

        Example:
            s3_keys = [meta["_s3_key"] for _, meta in batch]
            async for s3_key, payload_bytes in queue.iter_download_stream(s3_keys):
                payload = msgpack.unpackb(payload_bytes, raw=False)
                process(payload)
        """
        for i in range(0, len(s3_keys), batch_size):
            batch_keys = s3_keys[i:i + batch_size]

            # Create wrapper coroutines that return both key and payload
            async def download_with_key(key):
                payload = await self.download_from_s3(key)
                return key, payload

            # Create tasks with key embedded
            tasks = [download_with_key(key) for key in batch_keys]

            # Yield as soon as each download completes
            for coro in asyncio.as_completed(tasks):
                s3_key, payload_bytes = await coro
                yield s3_key, payload_bytes

    async def watch_queue(self, interval: float = 1.0,
                          stop_when_empty: bool = False):
        """Monitor queue size over time using async for

        Args:
            interval: Polling interval in seconds
            stop_when_empty: Stop iteration when queue becomes empty

        Yields:
            Queue length at each poll

        Example:
            # Monitor until queue is empty
            async for count in queue.watch_queue(interval=0.5, stop_when_empty=True):
                print(f"Queue size: {count}")

            # Continuous monitoring
            async for count in queue.watch_queue(interval=2.0):
                print(f"Current queue size: {count}")
                if count > 10000:
                    print("Warning: queue is getting large!")
        """
        while True:
            count = await self.count()
            yield count

            if stop_when_empty and count == 0:
                break

            await asyncio.sleep(interval)

    async def gather_stream(
            self,
            jobs: list,
            prefix: str = "{self.name}.return-queue"
    ):
        """Submit jobs and stream results as they complete (MapReduce pattern)

        Args:
            jobs: List of jobs to submit
            prefix: Return queue name prefix

        Yields:
            (gather_token, result_payload) as each job completes

        Example:
            jobs = [{"seed": i, "task": "train"} for i in range(100)]
            async for token, result in queue.gather_stream(jobs):
                print(f"Job {token} completed: {result}")
        """
        from uuid import uuid4

        r_id = uuid4()
        r_queue_name = prefix.format(self=self, r_id=r_id)
        gather_queue = TaskQAsync(
            name=r_queue_name,
            uri=self.uri,
            s3_bucket=self.s3_bucket,
            s3_region=self.s3_region
        )
        await gather_queue.__aenter__()

        try:
            gather_tokens = set()

            # Submit all jobs
            for job in jobs:
                gather_token = f"gather-{uuid4()}"
                gather_tokens.add(gather_token)
                await self.add({
                    "_gather_id": r_queue_name,
                    "_gather_token": gather_token,
                    **job
                })

            # Stream results as they complete
            while gather_tokens:
                ret = await gather_queue.take()
                if ret[0] is None:
                    await asyncio.sleep(0.1)
                    continue

                job_id, metadata = ret

                # Download payload
                if metadata and "_s3_key" in metadata:
                    s3_key = metadata["_s3_key"]
                    payloads = await gather_queue.download_payloads([s3_key])
                    job_data = msgpack.unpackb(payloads[0], raw=False)
                else:
                    job_data = metadata

                await gather_queue.mark_done(job_id)

                token = job_data.get("_gather_token")
                if token:
                    gather_tokens.discard(token)
                    yield token, job_data

        finally:
            # Cleanup gather queue
            await gather_queue.__aexit__(None, None, None)
