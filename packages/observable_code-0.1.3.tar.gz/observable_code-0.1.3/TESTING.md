# Testing Guide

Quick reference for running tests on `observable-codes-python`.

## Setup

```bash
# 1. Install package in editable mode with dev dependencies
pip install -e ".[dev]"

# 2. Verify pytest is installed
pytest --version
```

## Run Tests

```bash
# Run all tests
pytest

# Run only P0 (critical) tests
pytest -m p0

# Run specific test file
pytest tests/test_graceful_degradation.py

# Run specific test
pytest tests/test_graceful_degradation.py::test_function_runs_when_no_credentials

# Run with coverage
pytest --cov=observable

# Detailed coverage report
pytest --cov=observable --cov-report=html
# Then open: htmlcov/index.html
```

## Common Options

```bash
# Verbose output (show test names)
pytest -v

# Very verbose (show print statements)
pytest -vv -s

# Stop on first failure
pytest -x

# Show local variables on failure
pytest -l

# Run last failed tests
pytest --lf

# Debug with pdb on failure
pytest --pdb
```

## Test Markers

```bash
# Only critical tests (fast feedback)
pytest -m p0

# Exclude slow tests
pytest -m "not slow"

# Only P0 and P1 tests
pytest -m "p0 or p1"
```

## Coverage Requirements

Minimum coverage thresholds (enforced in pytest.ini):

- **Overall:** 85%
- **Critical modules:** 95%
  - `observable/_client.py`
  - `observable/__init__.py`
  - `observable/_config.py`

Check coverage:
```bash
pytest --cov=observable --cov-fail-under=85
```

## Test Structure

```
tests/
├── conftest.py                    # Shared fixtures
├── test_graceful_degradation.py   # P0 - Most critical
├── test_decorator_sync.py         # P0 - Core decorator
├── test_http_client.py            # P0 - HTTP errors
├── test_config.py                 # P0 - Config resolution
└── test_exceptions.py             # P0 - Exception handling
```

## Quick Checks

Before committing:
```bash
# 1. Run P0 tests (must pass)
pytest -m p0

# 2. Check coverage
pytest --cov=observable --cov-report=term-missing

# 3. Run all tests
pytest
```

## CI/CD

Tests run automatically in CI on:
- Push to main
- Pull requests
- All Python versions: 3.8, 3.9, 3.10, 3.11, 3.12

## Troubleshooting

### "No module named 'observable'"
```bash
pip install -e .
```

### "ModuleNotFoundError: No module named 'responses'"
```bash
pip install -e ".[dev]"
```

### Tests hanging
- Check if SDK is blocking (violates fire-and-forget principle)
- Use `pytest --timeout=5` to kill hanging tests

### Coverage too low
```bash
# See which lines are missing
pytest --cov=observable --cov-report=term-missing
```

## Writing Tests

See [tests/README.md](tests/README.md) for detailed guide.

Quick template:
```python
import pytest

@pytest.mark.p0
def test_my_feature(mock_api_success, env_with_session_id):
    """Test description."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "result"

    result = my_function()

    assert result == "result"
    assert len(mock_api_success.calls) == 1
```

---

For full documentation, see:
- [tests/README.md](tests/README.md) - Test suite documentation
- [TEST_IMPLEMENTATION_SUMMARY.md](TEST_IMPLEMENTATION_SUMMARY.md) - What's been implemented
