"""
P0 - Decorator Sync Function Tests

Tests for the @observable.track() decorator on synchronous functions.
This is the primary interface for the SDK.
"""

import pytest
import time


@pytest.mark.p0
def test_basic_decorator_usage(mock_api_success, env_with_session_id):
    """Test decorator on simple sync function."""
    import observable

    @observable.track("my_job")
    def simple_function():
        return "result"

    result = simple_function()
    assert result == "result"

    # Should have posted event to API
    assert len(mock_api_success.calls) == 1
    request = mock_api_success.calls[0].request
    assert request.method == "POST"
    assert "Bearer env-session-uuid-abcd" in request.headers.get("Authorization", "")


@pytest.mark.p0
def test_decorator_captures_function_name(mock_api_success, env_with_session_id):
    """Test decorator captures the event name."""
    import observable
    import json

    @observable.track("custom_event_name")
    def my_function():
        return "done"

    my_function()

    # Check posted payload
    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["name"] == "custom_event_name"


@pytest.mark.p0
def test_decorator_captures_completed_status(mock_api_success, env_with_session_id):
    """Test decorator captures status='completed' on success."""
    import observable
    import json

    @observable.track("test_job")
    def successful_function():
        return "success"

    successful_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["status"] == "completed"


@pytest.mark.p0
def test_decorator_captures_failed_status(mock_api_success, env_with_session_id):
    """Test decorator captures status='failed' on exception."""
    import observable
    import json

    @observable.track("test_job")
    def failing_function():
        raise ValueError("Something went wrong")

    # Exception should be re-raised
    with pytest.raises(ValueError, match="Something went wrong"):
        failing_function()

    # Should still post event with status='failed'
    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["status"] == "failed"


@pytest.mark.p0
def test_decorator_captures_duration(mock_api_success, env_with_session_id):
    """Test decorator captures function duration in milliseconds."""
    import observable
    import json

    @observable.track("slow_job")
    def slow_function():
        time.sleep(0.1)  # Sleep 100ms
        return "done"

    slow_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert "duration_ms" in request_body
    duration = request_body["duration_ms"]

    # Should be roughly 100ms (allow margin for overhead)
    assert 80 < duration < 200, f"Duration was {duration}ms, expected ~100ms"


@pytest.mark.p0
def test_decorator_captures_timestamp(mock_api_success, env_with_session_id):
    """Test decorator captures ISO 8601 timestamp."""
    import observable
    import json
    from datetime import datetime

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert "timestamp" in request_body
    timestamp = request_body["timestamp"]

    # Should be valid ISO 8601 format
    parsed = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    assert isinstance(parsed, datetime)


@pytest.mark.p0
def test_decorator_preserves_return_value(mock_api_success, env_with_session_id):
    """Test decorator does not modify function return value."""
    import observable

    @observable.track("test_job")
    def returns_complex_value():
        return {"data": [1, 2, 3], "status": "ok"}

    result = returns_complex_value()

    assert result == {"data": [1, 2, 3], "status": "ok"}


@pytest.mark.p0
def test_decorator_reraises_exceptions(mock_api_success, env_with_session_id):
    """Test decorator re-raises exceptions after tracking."""
    import observable

    @observable.track("test_job")
    def raises_custom_exception():
        raise RuntimeError("Custom error message")

    with pytest.raises(RuntimeError) as exc_info:
        raises_custom_exception()

    assert str(exc_info.value) == "Custom error message"


@pytest.mark.p0
def test_decorator_captures_exception_info(mock_api_success, env_with_session_id):
    """Test decorator captures exception type and message on failure."""
    import observable
    import json

    @observable.track("test_job")
    def raises_error():
        raise ValueError("Test error message")

    with pytest.raises(ValueError):
        raises_error()

    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert request_body["status"] == "failed"
    assert "error" in request_body
    assert "ValueError" in request_body["error"]["type"]
    assert "Test error message" in request_body["error"]["message"]


@pytest.mark.p0
def test_decorator_without_event_name_uses_function_name(mock_api_success, env_with_session_id):
    """Test decorator without arguments uses function name as event name."""
    import observable
    import json

    @observable.track()
    def my_custom_function_name():
        return "done"

    my_custom_function_name()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["name"] == "my_custom_function_name"


@pytest.mark.p0
def test_decorator_with_explicit_event_name(mock_api_success, env_with_session_id):
    """Test decorator with explicit event name."""
    import observable
    import json

    @observable.track("explicit_name")
    def actual_function_name():
        return "done"

    actual_function_name()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["name"] == "explicit_name"


@pytest.mark.p0
def test_decorator_on_function_with_no_return(mock_api_success, env_with_session_id):
    """Test decorator on function that returns None."""
    import observable

    executed = []

    @observable.track("void_function")
    def no_return():
        executed.append(True)
        # No return statement

    result = no_return()

    assert result is None
    assert executed == [True]


@pytest.mark.p0
def test_decorator_on_function_with_arguments(mock_api_success, env_with_session_id):
    """Test decorator preserves function arguments."""
    import observable

    @observable.track("test_job")
    def func_with_args(a, b, c=3):
        return a + b + c

    result = func_with_args(1, 2)
    assert result == 6

    result = func_with_args(1, 2, c=10)
    assert result == 13


@pytest.mark.p0
def test_decorator_on_function_with_kwargs(mock_api_success, env_with_session_id):
    """Test decorator preserves keyword arguments."""
    import observable

    @observable.track("test_job")
    def func_with_kwargs(**kwargs):
        return kwargs

    result = func_with_kwargs(x=1, y=2, z=3)
    assert result == {"x": 1, "y": 2, "z": 3}


@pytest.mark.p0
def test_multiple_decorated_functions(mock_api_success, env_with_session_id):
    """Test multiple decorated functions can be called."""
    import observable

    @observable.track("job_one")
    def func_one():
        return "one"

    @observable.track("job_two")
    def func_two():
        return "two"

    result1 = func_one()
    result2 = func_two()

    assert result1 == "one"
    assert result2 == "two"

    # Should have posted 2 events
    assert len(mock_api_success.calls) == 2


@pytest.mark.p0
def test_decorated_function_called_multiple_times(mock_api_success, env_with_session_id):
    """Test same decorated function can be called multiple times."""
    import observable

    @observable.track("repeatable_job")
    def repeatable():
        return "result"

    result1 = repeatable()
    result2 = repeatable()
    result3 = repeatable()

    assert result1 == result2 == result3 == "result"

    # Should have posted 3 events
    assert len(mock_api_success.calls) == 3
