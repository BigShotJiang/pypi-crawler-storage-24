# Observable Code Python SDK - Test Suite

Comprehensive test suite for `observable-codes-python`.

## Quick Start

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run all tests
pytest

# Run only P0 (critical) tests
pytest -m p0

# Run with coverage
pytest --cov=observable --cov-report=term-missing

# Run specific test file
pytest tests/test_graceful_degradation.py
```

## Test Structure

```
tests/
├── conftest.py                    # Shared fixtures
├── test_graceful_degradation.py   # P0 - Most critical tests
├── test_decorator_sync.py         # P0 - Sync decorator tests
├── test_http_client.py            # P0 - HTTP error handling
├── test_config.py                 # P0 - Config resolution
└── test_exceptions.py             # P0 - Exception handling
```

## Test Priorities

### P0 - Critical (Must Pass Before Any Release)

These tests validate the core contract: **"Decorated functions always run, regardless of SDK state."**

- **test_graceful_degradation.py** (13 tests) - Most critical
- **test_decorator_sync.py** (19 tests) - Core functionality
- **test_http_client.py** (19 tests) - Network error handling
- **test_config.py** (17 tests) - Credential resolution
- **test_exceptions.py** (17 tests) - Exception handling

**Total P0 tests: ~85**

### Running P0 Tests Only

```bash
pytest -m p0
```

All P0 tests must pass before any code can be released.

## Test Philosophy

### 1. Never Block User Code

The SDK must NEVER block or crash decorated functions. Every test validates this.

```python
@observable.track("job")
def user_function():
    return "success"

# Must return "success" even if:
# - No credentials configured
# - API is down
# - Network timeout
# - Rate limited
# - Any SDK error
```

### 2. Graceful Degradation

All failures must be silent or warn to stderr only (never crash).

### 3. Fire-and-Forget

Event posting happens in background thread - must not delay function return.

## Key Test Fixtures

### API Mocking

```python
def test_example(mock_api_success):
    # API returns 200 OK
    ...

def test_failure(mock_api_401):
    # API returns 401 Unauthorized
    ...
```

Available mocks:
- `mock_api_success` - 200 OK
- `mock_api_401` - 401 Unauthorized
- `mock_api_429` - 429 Rate Limited
- `mock_api_500` - 500 Server Error
- `mock_api_timeout` - Network timeout
- `mock_api_connection_error` - Connection refused
- `mock_api_malformed_json` - Invalid JSON response

### Config Fixtures

```python
def test_example(mock_config_file):
    # ~/.observable-code/config.json created
    ...

def test_example(env_with_session_id):
    # OBSERVABLE_CODE_SESSION_ID env var set
    ...
```

Available config fixtures:
- `mock_config_file` - Global config (~/.observable-code/config.json)
- `mock_project_config` - Project config (.observable-code)
- `invalid_config_file` - Malformed JSON config
- `env_with_session_id` - Session ID in env var
- `env_with_api_key` - API key in env var
- `env_with_custom_api_url` - Custom API URL

### Auto-Cleanup

```python
@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    # Automatically removes Observable env vars before each test
```

All tests start with clean environment.

## Coverage Goals

- **Overall: 85%+** (enforced in pytest.ini)
- **Critical modules: 95%+**
  - `observable/_client.py` - HTTP posting
  - `observable/__init__.py` - Public API
  - `observable/_config.py` - Credential resolution

## Running Tests in CI

```yaml
# .github/workflows/test.yml
- name: Run tests
  run: |
    pytest --cov=observable --cov-report=xml --cov-fail-under=85
```

## Test Markers

```python
@pytest.mark.p0    # Priority 0 - Critical
@pytest.mark.p1    # Priority 1 - Important
@pytest.mark.p2    # Priority 2 - Polish
@pytest.mark.slow  # Tests taking >1 second
```

Run specific markers:
```bash
pytest -m p0          # Only P0 tests
pytest -m "not slow"  # Skip slow tests
```

## Writing New Tests

### Example Test Structure

```python
import pytest

@pytest.mark.p0
def test_feature_name(mock_api_success, env_with_session_id):
    """
    Test description.

    Validates: What this test proves.
    """
    import observable

    @observable.track("test_job")
    def my_function():
        return "result"

    result = my_function()

    assert result == "result"
    assert len(mock_api_success.calls) == 1
```

### Naming Convention

- Test files: `test_*.py`
- Test functions: `test_*`
- Descriptive names: `test_decorator_captures_duration`

### Best Practices

1. **One assertion per test** (when possible)
2. **Clear test names** that describe what's being tested
3. **Add priority marker** (@pytest.mark.p0/p1/p2)
4. **Use fixtures** instead of manual setup
5. **Test both success and failure** paths

## Debugging Failed Tests

```bash
# Verbose output
pytest -v

# Show local variables in failures
pytest -l

# Stop on first failure
pytest -x

# Show print statements
pytest -s

# Debug with pdb
pytest --pdb
```

## Common Issues

### Import Errors

Make sure to install in editable mode:
```bash
pip install -e .
```

### Mock Not Working

Ensure mock is activated in test signature:
```python
def test_example(mock_api_success):  # ← Must include as parameter
    ...
```

### Environment Variables Leaking

The `clean_env` fixture (autouse=True) cleans env vars automatically.
If tests interfere, check they're using fixtures correctly.

## Next Steps

After P0 tests are passing:

1. **P1 tests** - Decorator async, CLI, pairing flow
2. **P2 tests** - Edge cases, compatibility
3. **Integration tests** - End-to-end workflows
4. **Performance tests** - Benchmarks

## Questions?

See the full test plan:
- [python-sdk-test-plan.md](../../../brainstorm/brainstorm/observable-code/python-sdk-test-plan.md)

---

**Test Suite Version:** 1.0
**Last Updated:** 2026-02-27
