"""
P0 - Graceful Degradation Tests

THE MOST CRITICAL TESTS IN THE ENTIRE SUITE.

These tests validate the core contract of the Observable SDK:
"Decorated functions ALWAYS run, regardless of SDK state."

If these tests fail, the SDK is fundamentally broken and cannot be released.
"""

import pytest
import time


@pytest.mark.p0
def test_function_runs_when_no_credentials(capsys):
    """
    CRITICAL: Function must run when no credentials are configured.

    This is the most common case for first-time users who haven't
    run `observable setup` yet.
    """
    import observable

    # Track execution
    executed = []

    @observable.track("test_job")
    def my_function():
        executed.append(True)
        return "success"

    # Function should run despite no credentials
    result = my_function()

    assert result == "success"
    assert executed == [True]

    # Should warn to stderr (not crash)
    stderr = capsys.readouterr().err
    assert "observable" in stderr.lower() or "credential" in stderr.lower()


@pytest.mark.p0
def test_function_runs_when_api_unreachable(mock_api_connection_error):
    """
    CRITICAL: Function must run when API is unreachable (connection refused).

    Network failures must never block user code.
    """
    import observable

    # Configure valid credentials (so SDK attempts to post)
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "test-session-123"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    executed = []

    @observable.track("test_job")
    def my_function():
        executed.append(True)
        return "success"

    # Function should run despite connection error
    result = my_function()

    assert result == "success"
    assert executed == [True]


@pytest.mark.p0
def test_function_runs_when_network_timeout(mock_api_timeout):
    """
    CRITICAL: Function must run when API times out.

    Slow networks must never block user code.
    """
    import observable
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "test-session-123"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    executed = []

    @observable.track("test_job")
    def my_function():
        executed.append(True)
        return "success"

    result = my_function()

    assert result == "success"
    assert executed == [True]


@pytest.mark.p0
def test_function_runs_when_session_expired(mock_api_401):
    """
    CRITICAL: Function must run when session is expired (401 Unauthorized).

    Expired credentials must never break production code.
    """
    import observable
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "expired-session"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    executed = []

    @observable.track("test_job")
    def my_function():
        executed.append(True)
        return "success"

    result = my_function()

    assert result == "success"
    assert executed == [True]


@pytest.mark.p0
def test_function_runs_when_rate_limited(mock_api_429, capsys):
    """
    CRITICAL: Function must run when rate limited (429 Too Many Requests).

    Hitting event limits must not block user code.
    Should warn user to upgrade.
    """
    import observable
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "test-session-123"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    executed = []

    @observable.track("test_job")
    def my_function():
        executed.append(True)
        return "success"

    result = my_function()

    assert result == "success"
    assert executed == [True]

    # Should warn about rate limit
    stderr = capsys.readouterr().err
    assert "limit" in stderr.lower() or "upgrade" in stderr.lower()


@pytest.mark.p0
def test_function_runs_when_server_error(mock_api_500):
    """
    CRITICAL: Function must run when API returns 500 Internal Server Error.

    Server failures must never block user code.
    """
    import observable
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "test-session-123"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    executed = []

    @observable.track("test_job")
    def my_function():
        executed.append(True)
        return "success"

    result = my_function()

    assert result == "success"
    assert executed == [True]


@pytest.mark.p0
def test_function_runs_when_malformed_api_response(mock_api_malformed_json):
    """
    CRITICAL: Function must run when API returns malformed JSON.

    Bad API responses must never block user code.
    """
    import observable
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "test-session-123"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    executed = []

    @observable.track("test_job")
    def my_function():
        executed.append(True)
        return "success"

    result = my_function()

    assert result == "success"
    assert executed == [True]


@pytest.mark.p0
def test_function_return_value_always_preserved(mock_api_connection_error):
    """
    CRITICAL: Decorated function return value must be preserved.

    The decorator must be transparent - it should not modify the return value.
    """
    import observable
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "test-session-123"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    @observable.track("test_job")
    def returns_string():
        return "hello"

    @observable.track("test_job")
    def returns_int():
        return 42

    @observable.track("test_job")
    def returns_dict():
        return {"key": "value"}

    @observable.track("test_job")
    def returns_none():
        return None

    assert returns_string() == "hello"
    assert returns_int() == 42
    assert returns_dict() == {"key": "value"}
    assert returns_none() is None


@pytest.mark.p0
def test_function_exception_always_reraised(mock_api_connection_error):
    """
    CRITICAL: Exceptions in decorated functions must be re-raised.

    The decorator must not swallow exceptions - caller must see them.
    """
    import observable
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "test-session-123"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    @observable.track("test_job")
    def raises_value_error():
        raise ValueError("test error")

    @observable.track("test_job")
    def raises_key_error():
        raise KeyError("missing_key")

    # Exceptions should propagate
    with pytest.raises(ValueError, match="test error"):
        raises_value_error()

    with pytest.raises(KeyError, match="missing_key"):
        raises_key_error()


@pytest.mark.p0
def test_decorator_never_blocks_execution(mock_api_success, measure_time):
    """
    CRITICAL: Decorator overhead must be minimal (fire-and-forget).

    Event posting happens in background - should not delay function execution.
    """
    import observable
    import os
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "test-session-123"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    @observable.track("fast_job")
    def instant_function():
        return "done"

    with measure_time() as timer:
        result = instant_function()

    assert result == "done"

    # Decorator overhead should be < 10ms (very generous)
    # Event posting happens in background thread
    assert timer.elapsed_ms < 10, f"Decorator took {timer.elapsed_ms}ms - too slow!"


@pytest.mark.p0
def test_warnings_go_to_stderr_not_stdout(capsys):
    """
    CRITICAL: SDK warnings must go to stderr, never stdout.

    stdout contamination breaks scripts that parse output.
    """
    import observable

    # No credentials - should warn
    @observable.track("test_job")
    def my_function():
        print("actual output")
        return "success"

    result = my_function()

    captured = capsys.readouterr()

    # User output should be in stdout
    assert "actual output" in captured.out

    # SDK warnings should be in stderr only
    assert "observable" not in captured.out.lower()
    assert "credential" not in captured.out.lower()


@pytest.mark.p0
def test_sdk_never_raises_exceptions():
    """
    CRITICAL: SDK internal errors must never propagate to user code.

    All SDK exceptions must be caught internally.
    """
    import observable
    import os

    # Deliberately break things
    os.environ["OBSERVABLE_CODE_SESSION_ID"] = "not-a-valid-session"
    os.environ["OBSERVABLE_CODE_API_URL"] = "https://observable.codes"

    @observable.track("test_job")
    def my_function():
        return "success"

    # Should not raise, even with broken config
    result = my_function()
    assert result == "success"
