"""
P0 - Config Resolution Tests

Tests for credential resolution from environment variables and config files.

Resolution order (highest priority first):
1. OBSERVABLE_CODE_API_KEY environment variable (account mode)
2. OBSERVABLE_CODE_SESSION_ID environment variable (anonymous mode)
3. .observable-code file in project directory
4. ~/.observable-code/config.json (global config)
5. Nothing found → warn and continue
"""

import pytest
import json
import os


@pytest.mark.p0
def test_reads_api_key_from_environment(monkeypatch, mock_api_success):
    """Test API key from environment variable takes highest priority."""
    import observable

    monkeypatch.setenv("OBSERVABLE_CODE_API_KEY", "obscode_sk_test123")
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    # Should use API key in Authorization header
    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert auth_header == "Bearer obscode_sk_test123"


@pytest.mark.p0
def test_reads_session_id_from_environment(monkeypatch, mock_api_success):
    """Test session ID from environment variable (anonymous mode)."""
    import observable

    monkeypatch.setenv("OBSERVABLE_CODE_SESSION_ID", "session-from-env-123")
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert auth_header == "Bearer session-from-env-123"


@pytest.mark.p0
def test_api_key_takes_precedence_over_session_id(monkeypatch, mock_api_success):
    """Test API key has priority over session ID."""
    import observable

    # Set both
    monkeypatch.setenv("OBSERVABLE_CODE_API_KEY", "obscode_sk_priority")
    monkeypatch.setenv("OBSERVABLE_CODE_SESSION_ID", "session-lower-priority")
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    # Should use API key (higher priority)
    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert auth_header == "Bearer obscode_sk_priority"


@pytest.mark.p0
def test_reads_global_config_file(mock_config_file, mock_api_success):
    """Test reads session ID from ~/.observable-code/config.json."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    # Should use session ID from config file
    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert auth_header == "Bearer test-session-uuid-1234"


@pytest.mark.p0
def test_reads_project_config_file(mock_project_config, mock_api_success):
    """Test reads session ID from .observable-code in project directory."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    # Should use session ID from project config
    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert auth_header == "Bearer project-session-uuid-5678"


@pytest.mark.p0
def test_env_var_overrides_config_file(mock_config_file, monkeypatch, mock_api_success):
    """Test environment variable takes precedence over config file."""
    import observable

    # Env var should win
    monkeypatch.setenv("OBSERVABLE_CODE_SESSION_ID", "env-wins")

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert auth_header == "Bearer env-wins"


@pytest.mark.p0
def test_graceful_handling_when_no_credentials(capsys):
    """Test warns to stderr when no credentials found."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    # Should still run function
    result = my_function()
    assert result == "success"

    # Should warn to stderr
    stderr = capsys.readouterr().err
    assert len(stderr) > 0  # Some warning should be present
    # Ideally contains "observable" or "credentials" or "setup"


@pytest.mark.p0
def test_invalid_json_in_config_file_warns_and_continues(invalid_config_file, capsys):
    """Test invalid JSON in config file warns but doesn't crash."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    # Should still run despite bad config
    result = my_function()
    assert result == "success"

    # Should warn about invalid config
    stderr = capsys.readouterr().err
    # May contain warning about config file


@pytest.mark.p0
def test_empty_env_var_is_ignored(monkeypatch, mock_config_file, mock_api_success):
    """Test empty string environment variables are ignored."""
    import observable

    # Empty env vars should be treated as "not set"
    monkeypatch.setenv("OBSERVABLE_CODE_SESSION_ID", "")

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    # Should fall back to config file
    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert auth_header == "Bearer test-session-uuid-1234"


@pytest.mark.p0
def test_config_file_with_missing_session_id_key(tmp_path, monkeypatch, capsys):
    """Test config file without session_id key warns and continues."""
    import observable

    # Create config file with wrong key
    config_dir = tmp_path / ".observable-code"
    config_dir.mkdir()
    config_file = config_dir / "config.json"
    config_file.write_text(json.dumps({"wrong_key": "value"}))

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))

    @observable.track("test_job")
    def my_function():
        return "success"

    result = my_function()
    assert result == "success"


@pytest.mark.p0
def test_empty_config_file_warns_and_continues(tmp_path, monkeypatch, capsys):
    """Test empty config file warns but doesn't crash."""
    import observable

    # Create empty config file
    config_dir = tmp_path / ".observable-code"
    config_dir.mkdir()
    config_file = config_dir / "config.json"
    config_file.write_text(json.dumps({}))

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))

    @observable.track("test_job")
    def my_function():
        return "success"

    result = my_function()
    assert result == "success"


@pytest.mark.p0
def test_custom_api_url_from_env(monkeypatch):
    """Test custom API base URL can be configured via env var."""
    import observable

    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://custom.observable.codes")
    monkeypatch.setenv("OBSERVABLE_CODE_SESSION_ID", "test-123")

    # SDK should read this env var
    # Actual HTTP call will be tested with appropriate mock


@pytest.mark.p0
def test_api_key_format_validation(monkeypatch, mock_api_success):
    """Test API keys with obscode_sk_ prefix are accepted."""
    import observable

    # Standard format
    monkeypatch.setenv("OBSERVABLE_CODE_API_KEY", "obscode_sk_abc123def456")
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert "obscode_sk_" in auth_header


@pytest.mark.p0
def test_session_id_uuid_format(monkeypatch, mock_api_success):
    """Test session IDs in UUID format are accepted."""
    import observable

    # UUID v4 format
    monkeypatch.setenv("OBSERVABLE_CODE_SESSION_ID", "550e8400-e29b-41d4-a716-446655440000")
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")
    assert "550e8400-e29b-41d4-a716-446655440000" in auth_header
