"""
P0 - Exception Handling Tests

Tests for exception handling in decorated functions.

Critical requirements:
1. Exceptions must be re-raised after tracking
2. Exception type, message, and stack trace must be preserved
3. Exception info must be captured in event payload
"""

import pytest
import traceback


@pytest.mark.p0
def test_exception_is_reraised(mock_api_success, env_with_session_id):
    """Test decorated function exceptions are re-raised."""
    import observable

    @observable.track("test_job")
    def raises_exception():
        raise ValueError("Test error")

    with pytest.raises(ValueError, match="Test error"):
        raises_exception()


@pytest.mark.p0
def test_exception_type_is_preserved(mock_api_success, env_with_session_id):
    """Test exception type is exactly preserved."""
    import observable

    class CustomException(Exception):
        pass

    @observable.track("test_job")
    def raises_custom():
        raise CustomException("Custom error message")

    with pytest.raises(CustomException) as exc_info:
        raises_custom()

    assert type(exc_info.value) is CustomException
    assert str(exc_info.value) == "Custom error message"


@pytest.mark.p0
def test_exception_message_is_preserved(mock_api_success, env_with_session_id):
    """Test exception message is exactly preserved."""
    import observable

    @observable.track("test_job")
    def raises_with_message():
        raise RuntimeError("Very specific error message")

    with pytest.raises(RuntimeError) as exc_info:
        raises_with_message()

    assert str(exc_info.value) == "Very specific error message"


@pytest.mark.p0
def test_exception_stack_trace_is_preserved(mock_api_success, env_with_session_id):
    """Test exception stack trace is preserved for debugging."""
    import observable

    @observable.track("test_job")
    def deeply_nested():
        def level_1():
            def level_2():
                def level_3():
                    raise ValueError("Deep error")
                return level_3()
            return level_2()
        return level_1()

    with pytest.raises(ValueError) as exc_info:
        deeply_nested()

    # Stack trace should show nested functions
    tb_str = "".join(traceback.format_tb(exc_info.tb))
    assert "level_1" in tb_str
    assert "level_2" in tb_str
    assert "level_3" in tb_str


@pytest.mark.p0
def test_exception_captured_in_event_payload(mock_api_success, env_with_session_id):
    """Test exception info is included in event payload."""
    import observable
    import json

    @observable.track("test_job")
    def raises_error():
        raise ValueError("Captured error")

    with pytest.raises(ValueError):
        raises_error()

    # Event should still be posted
    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert request_body["status"] == "failed"
    assert "error" in request_body

    error_info = request_body["error"]
    assert "type" in error_info
    assert "message" in error_info

    assert "ValueError" in error_info["type"]
    assert "Captured error" in error_info["message"]


@pytest.mark.p0
def test_multiple_exception_types(mock_api_success, env_with_session_id):
    """Test different exception types are all handled correctly."""
    import observable

    @observable.track("value_error")
    def raises_value_error():
        raise ValueError("value error")

    @observable.track("key_error")
    def raises_key_error():
        raise KeyError("missing_key")

    @observable.track("type_error")
    def raises_type_error():
        raise TypeError("type error")

    @observable.track("runtime_error")
    def raises_runtime_error():
        raise RuntimeError("runtime error")

    # All should re-raise
    with pytest.raises(ValueError):
        raises_value_error()

    with pytest.raises(KeyError):
        raises_key_error()

    with pytest.raises(TypeError):
        raises_type_error()

    with pytest.raises(RuntimeError):
        raises_runtime_error()

    # All should post events
    assert len(mock_api_success.calls) == 4


@pytest.mark.p0
def test_exception_in_nested_decorators(mock_api_success, env_with_session_id):
    """Test exception handling with multiple decorators stacked."""
    import observable

    def custom_decorator(func):
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper

    @observable.track("test_job")
    @custom_decorator
    def decorated_function():
        raise ValueError("Nested error")

    with pytest.raises(ValueError, match="Nested error"):
        decorated_function()


@pytest.mark.p0
def test_exception_with_no_message(mock_api_success, env_with_session_id):
    """Test exceptions without messages are handled."""
    import observable

    @observable.track("test_job")
    def raises_empty_exception():
        raise ValueError()  # No message

    with pytest.raises(ValueError):
        raises_empty_exception()


@pytest.mark.p0
def test_exception_with_complex_message(mock_api_success, env_with_session_id):
    """Test exceptions with complex multi-line messages."""
    import observable

    @observable.track("test_job")
    def raises_complex():
        raise ValueError("""
        This is a multi-line error message
        with special characters: @#$%^&*()
        and Unicode: 你好 🎉
        """)

    with pytest.raises(ValueError):
        raises_complex()


@pytest.mark.p0
def test_exception_after_partial_execution(mock_api_success, env_with_session_id):
    """Test exceptions raised mid-function are tracked correctly."""
    import observable

    side_effects = []

    @observable.track("partial_job")
    def partially_executes():
        side_effects.append("step 1")
        side_effects.append("step 2")
        raise ValueError("Failed at step 3")
        side_effects.append("step 3")  # Should not execute

    with pytest.raises(ValueError):
        partially_executes()

    # Partial execution should have happened
    assert side_effects == ["step 1", "step 2"]

    # Event should still be posted with failure status
    import json
    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["status"] == "failed"


@pytest.mark.p0
def test_exception_during_api_post_does_not_suppress_user_exception(
    mock_api_connection_error, env_with_session_id
):
    """
    CRITICAL: If API posting fails, user exception must still be raised.

    SDK errors must never suppress user code exceptions.
    """
    import observable

    @observable.track("test_job")
    def user_function_that_fails():
        raise ValueError("User error - must be visible")

    # User exception should be raised, NOT SDK's connection error
    with pytest.raises(ValueError, match="User error - must be visible"):
        user_function_that_fails()


@pytest.mark.p0
def test_exception_with_cause_chain(mock_api_success, env_with_session_id):
    """Test exceptions with __cause__ chain are preserved."""
    import observable

    @observable.track("test_job")
    def raises_chained():
        try:
            raise ValueError("Original error")
        except ValueError as e:
            raise RuntimeError("Wrapped error") from e

    with pytest.raises(RuntimeError) as exc_info:
        raises_chained()

    assert str(exc_info.value) == "Wrapped error"
    assert exc_info.value.__cause__ is not None
    assert isinstance(exc_info.value.__cause__, ValueError)


@pytest.mark.p0
def test_system_exit_is_not_caught(mock_api_success_optional, env_with_session_id):
    """Test SystemExit exceptions are NOT caught (allow clean shutdown)."""
    import observable

    @observable.track("test_job")
    def calls_system_exit():
        raise SystemExit(0)

    with pytest.raises(SystemExit):
        calls_system_exit()


@pytest.mark.p0
def test_keyboard_interrupt_is_not_caught(mock_api_success_optional, env_with_session_id):
    """Test KeyboardInterrupt is NOT caught (allow Ctrl+C)."""
    import observable

    @observable.track("test_job")
    def interrupted():
        raise KeyboardInterrupt()

    with pytest.raises(KeyboardInterrupt):
        interrupted()


@pytest.mark.p0
def test_base_exception_subclasses_are_reraised(mock_api_success_optional, env_with_session_id):
    """Test BaseException subclasses (like SystemExit) are re-raised."""
    import observable

    class CustomBaseException(BaseException):
        pass

    @observable.track("test_job")
    def raises_base_exception():
        raise CustomBaseException("Critical error")

    with pytest.raises(CustomBaseException):
        raises_base_exception()
