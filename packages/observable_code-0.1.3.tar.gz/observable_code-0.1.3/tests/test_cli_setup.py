"""
P1 - CLI Setup Command Tests

Tests for `observable setup` command - the first-time pairing wizard.
"""

import pytest
import responses
import json
from unittest.mock import Mock, patch, MagicMock


@pytest.mark.p1
def test_setup_command_creates_session(mock_session_creation, monkeypatch):
    """Test setup command creates new session via API."""
    from observable._cli import main

    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):  # Choice: QR code
            with patch('observable._pairing.wait_for_pairing', return_value=True):
                # Mock QR display
                with patch('observable._pairing.display_qr'):
                    try:
                        main()
                    except SystemExit:
                        pass

    # Should have called session creation API
    assert len(mock_session_creation.calls) >= 1


@pytest.mark.p1
def test_setup_command_saves_config(tmp_path, monkeypatch, mock_session_creation):
    """Test setup command saves session ID to config file."""
    from observable._cli import main

    # Mock home directory
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):
            with patch('observable._pairing.wait_for_pairing', return_value=True):
                with patch('observable._pairing.display_qr'):
                    try:
                        main()
                    except SystemExit:
                        pass

    # Config file should be created
    config_file = tmp_path / ".observable-code" / "config.json"

    # May or may not exist depending on implementation
    # If it does, should contain session_id


@pytest.mark.p1
def test_setup_generates_qr_code(mock_session_creation, monkeypatch):
    """Test setup command generates QR code for pairing."""
    from observable._cli import main

    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    qr_displayed = []

    def mock_display_qr(data):
        qr_displayed.append(data)

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):
            with patch('observable._pairing.wait_for_pairing', return_value=True):
                with patch('observable._pairing.display_qr', side_effect=mock_display_qr):
                    try:
                        main()
                    except SystemExit:
                        pass

    # QR should have been displayed
    # assert len(qr_displayed) > 0


@pytest.mark.p1
def test_setup_qr_contains_pairing_token():
    """Test QR code contains pairing token in correct format."""
    from observable._pairing import generate_qr_data

    pairing_token = "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"

    qr_data = generate_qr_data(pairing_token)

    # Should be in format: obsapp://pair?token=<token>
    assert qr_data.startswith("obsapp://pair?token=")
    assert pairing_token in qr_data


@pytest.mark.p1
def test_setup_waits_for_pairing_confirmation(mock_session_creation, monkeypatch):
    """Test setup polls for pairing confirmation."""
    from observable._cli import main

    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    poll_count = []

    def mock_wait_for_pairing(session_id, timeout=600):
        poll_count.append(1)
        return True  # Paired successfully

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):
            with patch('observable._pairing.wait_for_pairing', side_effect=mock_wait_for_pairing):
                with patch('observable._pairing.display_qr'):
                    try:
                        main()
                    except SystemExit:
                        pass

    # Should have waited for pairing
    assert len(poll_count) > 0


@pytest.mark.p1
def test_setup_timeout_handling(mock_session_creation, monkeypatch):
    """Test setup handles pairing timeout gracefully."""
    from observable._cli import main

    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    def mock_wait_timeout(session_id, timeout=600):
        return False  # Timeout - not paired

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):
            with patch('observable._pairing.wait_for_pairing', side_effect=mock_wait_timeout):
                with patch('observable._pairing.display_qr'):
                    try:
                        main()
                    except SystemExit as e:
                        # May exit with error code
                        pass


@pytest.mark.p1
def test_setup_session_creation_error_handling(monkeypatch):
    """Test setup handles session creation API errors."""
    from observable._cli import main

    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    with responses.RequestsMock() as rsps:
        # Mock session creation failure
        rsps.add(
            responses.POST,
            "https://observable.codes/api/sessions",
            json={"error": "Server error"},
            status=500,
        )

        with patch('sys.argv', ['observable', 'setup']):
            with patch('builtins.input', return_value='1'):
                try:
                    main()
                except SystemExit:
                    pass  # Expected to exit on error


@pytest.mark.p1
def test_setup_displays_success_message(mock_session_creation, capsys, monkeypatch):
    """Test setup displays success message when paired."""
    from observable._cli import main

    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):
            with patch('observable._pairing.wait_for_pairing', return_value=True):
                with patch('observable._pairing.display_qr'):
                    try:
                        main()
                    except SystemExit:
                        pass

    # Should print success message
    # captured = capsys.readouterr()
    # assert "paired" in captured.out.lower() or "success" in captured.out.lower()


@pytest.mark.p1
def test_setup_non_interactive_environment_fails_gracefully(monkeypatch):
    """Test setup fails gracefully in non-interactive environment."""
    from observable._cli import main

    # Simulate non-interactive (no input)
    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', side_effect=EOFError):
            try:
                main()
            except (SystemExit, EOFError):
                pass  # Expected


@pytest.mark.p1
def test_setup_config_file_permissions(tmp_path, monkeypatch, mock_session_creation):
    """Test setup creates config file with appropriate permissions."""
    from observable._cli import main

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):
            with patch('observable._pairing.wait_for_pairing', return_value=True):
                with patch('observable._pairing.display_qr'):
                    try:
                        main()
                    except SystemExit:
                        pass

    config_file = tmp_path / ".observable-code" / "config.json"

    if config_file.exists():
        # File should exist and be readable
        assert config_file.is_file()


@pytest.mark.p1
def test_setup_wizard_presents_options(capsys):
    """Test setup wizard presents pairing options."""
    from observable._cli import main

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', side_effect=KeyboardInterrupt):  # User cancels
            try:
                main()
            except (SystemExit, KeyboardInterrupt):
                pass

    # Should have prompted for choice
    # captured = capsys.readouterr()
    # Should show options like "1. Scan QR code" or "2. Sign in"


@pytest.mark.p1
def test_setup_qr_pairing_token_is_128_bit():
    """Test pairing token is 128-bit (32 hex chars)."""
    from observable._pairing import generate_pairing_token

    token = generate_pairing_token()

    # Should be 32 hex characters (128 bits)
    assert len(token) == 32
    assert all(c in '0123456789abcdef' for c in token.lower())


@pytest.mark.p1
def test_setup_creates_config_directory_if_missing(tmp_path, monkeypatch, mock_session_creation):
    """Test setup creates ~/.observable-code directory if it doesn't exist."""
    from observable._cli import main

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    # Ensure directory doesn't exist
    config_dir = tmp_path / ".observable-code"
    assert not config_dir.exists()

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):
            with patch('observable._pairing.wait_for_pairing', return_value=True):
                with patch('observable._pairing.display_qr'):
                    try:
                        main()
                    except SystemExit:
                        pass

    # Directory should be created
    # assert config_dir.exists()


@pytest.mark.p1
def test_setup_handles_existing_config_gracefully(mock_config_file, mock_session_creation, monkeypatch):
    """Test setup handles existing config file gracefully."""
    from observable._cli import main

    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")

    # Config already exists
    assert mock_config_file.exists()

    with patch('sys.argv', ['observable', 'setup']):
        with patch('builtins.input', return_value='1'):
            with patch('observable._pairing.wait_for_pairing', return_value=True):
                with patch('observable._pairing.display_qr'):
                    try:
                        main()
                    except SystemExit:
                        pass

    # Should handle existing config (may ask to overwrite, or create new session)
