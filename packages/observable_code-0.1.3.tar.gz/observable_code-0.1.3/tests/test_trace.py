"""
P1 - Trace Tests

Tests for observable.trace() - attaching structured data to events.
"""

import pytest


@pytest.mark.p1
def test_trace_attaches_data_to_event(mock_api_success, env_with_session_id):
    """Test observable.trace() attaches data to current event."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("user_id", 12345)
        observable.trace("operation", "batch_process")
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert "traces" in request_body
    assert request_body["traces"]["user_id"] == 12345
    assert request_body["traces"]["operation"] == "batch_process"


@pytest.mark.p1
def test_trace_with_string_value(mock_api_success, env_with_session_id):
    """Test trace with string value."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("environment", "production")
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["environment"] == "production"


@pytest.mark.p1
def test_trace_with_integer_value(mock_api_success, env_with_session_id):
    """Test trace with integer value."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("count", 42)
        observable.trace("batch_size", 1000)
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["count"] == 42
    assert request_body["traces"]["batch_size"] == 1000


@pytest.mark.p1
def test_trace_with_float_value(mock_api_success, env_with_session_id):
    """Test trace with float value."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("amount", 99.99)
        observable.trace("percentage", 0.75)
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["amount"] == 99.99
    assert request_body["traces"]["percentage"] == 0.75


@pytest.mark.p1
def test_trace_with_boolean_value(mock_api_success, env_with_session_id):
    """Test trace with boolean value."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("is_verified", True)
        observable.trace("has_errors", False)
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["is_verified"] is True
    assert request_body["traces"]["has_errors"] is False


@pytest.mark.p1
def test_trace_with_none_value(mock_api_success, env_with_session_id):
    """Test trace with None value."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("optional_field", None)
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["optional_field"] is None


@pytest.mark.p1
def test_trace_with_dict_value(mock_api_success, env_with_session_id):
    """Test trace with dictionary value."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("metadata", {"version": "1.0", "source": "api"})
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["metadata"] == {"version": "1.0", "source": "api"}


@pytest.mark.p1
def test_trace_with_list_value(mock_api_success, env_with_session_id):
    """Test trace with list value."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("item_ids", [1, 2, 3, 4, 5])
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["item_ids"] == [1, 2, 3, 4, 5]


@pytest.mark.p1
def test_multiple_trace_calls_accumulate(mock_api_success, env_with_session_id):
    """Test multiple trace calls accumulate in same event."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("key1", "value1")
        observable.trace("key2", "value2")
        observable.trace("key3", "value3")
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    traces = request_body["traces"]

    assert traces["key1"] == "value1"
    assert traces["key2"] == "value2"
    assert traces["key3"] == "value3"


@pytest.mark.p1
def test_trace_overwrites_previous_value_for_same_key(mock_api_success, env_with_session_id):
    """Test trace overwrites previous value if same key used."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("status", "pending")
        observable.trace("status", "processing")
        observable.trace("status", "completed")
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)

    # Last value wins
    assert request_body["traces"]["status"] == "completed"


@pytest.mark.p1
def test_trace_called_outside_tracked_function_warns(capsys):
    """Test trace called outside tracked function warns or no-ops gracefully."""
    import observable

    # Call trace without active tracking context
    observable.trace("orphan_key", "orphan_value")

    # Should not crash
    # May warn to stderr


@pytest.mark.p1
def test_trace_with_non_json_serializable_data_warns(mock_api_success, env_with_session_id, capsys):
    """Test trace with non-JSON-serializable data warns and skips."""
    import observable
    import json

    class CustomObject:
        pass

    @observable.track("test_job")
    def my_function():
        # This should warn or be skipped
        observable.trace("custom_obj", CustomObject())
        # This should work
        observable.trace("valid_key", "valid_value")
        return "done"

    my_function()

    # May warn to stderr about non-serializable data
    # Should still post event (with valid_key, without custom_obj)


@pytest.mark.p1
def test_trace_with_empty_key_warns(mock_api_success, env_with_session_id):
    """Test trace with empty string key warns or is rejected."""
    import observable

    @observable.track("test_job")
    def my_function():
        observable.trace("", "value")  # Empty key
        return "done"

    my_function()

    # Should handle gracefully (warn or skip)


@pytest.mark.p1
def test_trace_isolation_between_concurrent_calls(mock_api_success, env_with_session_id):
    """Test trace data doesn't leak between concurrent function calls."""
    import observable
    import json
    import threading

    @observable.track("concurrent_job")
    def concurrent_function(thread_id):
        observable.trace("thread_id", thread_id)
        observable.trace("unique_value", f"value_{thread_id}")
        return thread_id

    # Run multiple threads concurrently
    threads = []
    for i in range(5):
        t = threading.Thread(target=concurrent_function, args=(i,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    # Should have 5 events posted
    assert len(mock_api_success.calls) == 5

    # Each event should have isolated trace data
    # (Can't easily verify this without more complex mocking)


@pytest.mark.p1
@pytest.mark.asyncio
async def test_trace_with_async_function(mock_api_success, env_with_session_id):
    """Test trace works with async functions."""
    import observable
    import json
    import asyncio

    @observable.track("async_job")
    async def async_function():
        observable.trace("async_key", "async_value")
        await asyncio.sleep(0.01)
        return "done"

    await async_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["async_key"] == "async_value"


@pytest.mark.p1
def test_trace_with_very_large_payload_warns(mock_api_success, env_with_session_id, capsys):
    """Test trace with very large payload warns or truncates."""
    import observable

    # Create large string (1MB)
    large_string = "x" * (1024 * 1024)

    @observable.track("test_job")
    def my_function():
        observable.trace("large_data", large_string)
        return "done"

    my_function()

    # May warn about size
    # Should still complete without crashing


@pytest.mark.p1
def test_trace_with_nested_dict(mock_api_success, env_with_session_id):
    """Test trace with nested dictionary structures."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("config", {
            "database": {
                "host": "localhost",
                "port": 5432,
                "options": {"ssl": True, "timeout": 30}
            },
            "cache": {
                "enabled": True,
                "ttl": 3600
            }
        })
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    config = request_body["traces"]["config"]

    assert config["database"]["host"] == "localhost"
    assert config["database"]["options"]["ssl"] is True
    assert config["cache"]["enabled"] is True


@pytest.mark.p1
def test_trace_with_unicode_characters(mock_api_success, env_with_session_id):
    """Test trace handles Unicode characters correctly."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("message", "Hello 世界 🎉")
        observable.trace("emoji", "✅ 🚀 💯")
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["message"] == "Hello 世界 🎉"
    assert request_body["traces"]["emoji"] == "✅ 🚀 💯"


@pytest.mark.p1
def test_trace_with_special_characters(mock_api_success, env_with_session_id):
    """Test trace handles special characters in keys and values."""
    import observable
    import json

    @observable.track("test_job")
    def my_function():
        observable.trace("key-with-dashes", "value")
        observable.trace("key_with_underscores", "value")
        observable.trace("special_chars", "@#$%^&*()")
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["traces"]["key-with-dashes"] == "value"
    assert request_body["traces"]["key_with_underscores"] == "value"
    assert request_body["traces"]["special_chars"] == "@#$%^&*()"
