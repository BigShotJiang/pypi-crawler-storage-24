"""
P1 - Event Tests

Tests for observable.event() - manual standalone events without decorators.
"""

import pytest


@pytest.mark.p1
def test_event_sends_standalone_event(mock_api_success, env_with_session_id):
    """Test observable.event() sends standalone event without decorator."""
    import observable
    import json

    observable.event("payment_received")

    # Should post event
    assert len(mock_api_success.calls) == 1

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["name"] == "payment_received"


@pytest.mark.p1
def test_event_with_no_metadata(mock_api_success, env_with_session_id):
    """Test event with just event name (no metadata)."""
    import observable
    import json

    observable.event("user_logged_in")

    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert request_body["name"] == "user_logged_in"
    # Should have basic fields
    assert "timestamp" in request_body


@pytest.mark.p1
def test_event_with_keyword_arguments(mock_api_success, env_with_session_id):
    """Test event with keyword arguments as metadata."""
    import observable
    import json

    observable.event("order_placed", order_id=12345, amount=99.99, currency="USD")

    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert request_body["name"] == "order_placed"
    # Metadata should be included
    assert "order_id" in request_body or "metadata" in request_body


@pytest.mark.p1
def test_event_with_string_metadata(mock_api_success, env_with_session_id):
    """Test event with string metadata values."""
    import observable

    observable.event("deployment_started", environment="production", version="1.2.3")

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_with_integer_metadata(mock_api_success, env_with_session_id):
    """Test event with integer metadata values."""
    import observable

    observable.event("batch_processed", count=1000, duration_seconds=45)

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_with_float_metadata(mock_api_success, env_with_session_id):
    """Test event with float metadata values."""
    import observable

    observable.event("price_updated", old_price=19.99, new_price=24.99)

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_with_boolean_metadata(mock_api_success, env_with_session_id):
    """Test event with boolean metadata values."""
    import observable

    observable.event("feature_toggled", enabled=True, notify_users=False)

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_with_dict_metadata(mock_api_success, env_with_session_id):
    """Test event with dictionary metadata."""
    import observable

    observable.event(
        "user_registered",
        user_info={"email": "test@example.com", "plan": "pro"}
    )

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_with_list_metadata(mock_api_success, env_with_session_id):
    """Test event with list metadata."""
    import observable

    observable.event("items_processed", item_ids=[1, 2, 3, 4, 5])

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_without_active_tracking_context(mock_api_success, env_with_session_id):
    """Test event can be called outside of tracked function."""
    import observable

    # Call directly, not inside decorator
    observable.event("standalone_event", key="value")

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_multiple_events_in_sequence(mock_api_success, env_with_session_id):
    """Test multiple events can be fired in sequence."""
    import observable

    observable.event("event_1", step=1)
    observable.event("event_2", step=2)
    observable.event("event_3", step=3)

    # Should post 3 events
    assert len(mock_api_success.calls) == 3


@pytest.mark.p1
def test_event_inside_tracked_function(mock_api_success, env_with_session_id):
    """Test event can be called inside a tracked function."""
    import observable

    @observable.track("main_job")
    def my_function():
        observable.event("checkpoint_reached", checkpoint="halfway")
        return "done"

    my_function()

    # Should post 2 events: decorator event + manual event
    assert len(mock_api_success.calls) == 2


@pytest.mark.p1
def test_event_captures_timestamp(mock_api_success, env_with_session_id):
    """Test event captures timestamp."""
    import observable
    import json
    from datetime import datetime

    observable.event("timed_event")

    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert "timestamp" in request_body
    # Should be valid ISO 8601
    parsed = datetime.fromisoformat(request_body["timestamp"].replace("Z", "+00:00"))
    assert isinstance(parsed, datetime)


@pytest.mark.p1
def test_event_with_empty_event_name_warns(mock_api_success, env_with_session_id, capsys):
    """Test event with empty string name warns or is rejected."""
    import observable

    observable.event("")

    # Should handle gracefully (warn or skip)


@pytest.mark.p1
def test_event_with_very_long_name(mock_api_success, env_with_session_id):
    """Test event with very long event name."""
    import observable

    long_name = "event_" + "x" * 500

    observable.event(long_name)

    # Should handle (may truncate or warn)
    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_with_special_characters_in_name(mock_api_success, env_with_session_id):
    """Test event name with special characters."""
    import observable

    observable.event("event:with:colons")
    observable.event("event-with-dashes")
    observable.event("event_with_underscores")

    assert len(mock_api_success.calls) == 3


@pytest.mark.p1
def test_event_with_unicode_in_name(mock_api_success, env_with_session_id):
    """Test event name with Unicode characters."""
    import observable

    observable.event("事件_event_🎉")

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_with_non_json_serializable_metadata_warns(mock_api_success, env_with_session_id, capsys):
    """Test event with non-JSON-serializable metadata warns."""
    import observable

    class CustomObject:
        pass

    observable.event("test_event", custom_obj=CustomObject(), valid_key="valid_value")

    # May warn about non-serializable data
    # Should still attempt to post event (with valid_key)


@pytest.mark.p1
def test_event_graceful_degradation_no_credentials(capsys):
    """Test event works without credentials (graceful degradation)."""
    import observable

    observable.event("orphan_event", key="value")

    # Should not crash
    # May warn to stderr


@pytest.mark.p1
def test_event_graceful_degradation_api_error(mock_api_connection_error, env_with_session_id):
    """Test event handles API errors gracefully."""
    import observable

    observable.event("test_event", key="value")

    # Should not crash


@pytest.mark.p1
@pytest.mark.asyncio
async def test_event_from_async_context(mock_api_success, env_with_session_id):
    """Test event can be called from async context."""
    import observable
    import asyncio

    async def async_function():
        observable.event("async_event", async_key="async_value")
        await asyncio.sleep(0.01)

    await async_function()

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_with_nested_metadata(mock_api_success, env_with_session_id):
    """Test event with nested dictionary metadata."""
    import observable

    observable.event(
        "complex_event",
        metadata={
            "level1": {
                "level2": {
                    "level3": "deep_value"
                }
            }
        }
    )

    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
def test_event_does_not_block(mock_api_success, env_with_session_id, measure_time):
    """Test event() is fire-and-forget (does not block)."""
    import observable

    with measure_time() as timer:
        observable.event("instant_event")

    # Should return immediately
    assert timer.elapsed_ms < 10


@pytest.mark.p1
def test_event_with_none_metadata_values(mock_api_success, env_with_session_id):
    """Test event with None values in metadata."""
    import observable

    observable.event("test_event", optional_field=None, present_field="value")

    assert len(mock_api_success.calls) == 1
