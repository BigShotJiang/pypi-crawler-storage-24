"""
P1 - Decorator Async Function Tests

Tests for @observable.track() decorator on async functions.
"""

import pytest
import asyncio


@pytest.mark.p1
@pytest.mark.asyncio
async def test_basic_async_decorator(mock_api_success, env_with_session_id):
    """Test decorator on simple async function."""
    import observable

    @observable.track("async_job")
    async def async_function():
        await asyncio.sleep(0.01)
        return "async result"

    result = await async_function()
    assert result == "async result"

    # Should post event
    assert len(mock_api_success.calls) == 1


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_captures_status_completed(mock_api_success, env_with_session_id):
    """Test async decorator captures status='completed' on success."""
    import observable
    import json

    @observable.track("async_job")
    async def successful_async():
        await asyncio.sleep(0.01)
        return "success"

    await successful_async()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["status"] == "completed"


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_captures_status_failed(mock_api_success, env_with_session_id):
    """Test async decorator captures status='failed' on exception."""
    import observable
    import json

    @observable.track("async_job")
    async def failing_async():
        await asyncio.sleep(0.01)
        raise ValueError("Async error")

    with pytest.raises(ValueError, match="Async error"):
        await failing_async()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    assert request_body["status"] == "failed"


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_captures_duration(mock_api_success, env_with_session_id):
    """Test async decorator captures duration."""
    import observable
    import json
    import time

    @observable.track("slow_async")
    async def slow_async():
        await asyncio.sleep(0.1)  # 100ms
        return "done"

    await slow_async()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    duration = request_body["duration_ms"]

    # Should be roughly 100ms
    assert 80 < duration < 200


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_preserves_return_value(mock_api_success, env_with_session_id):
    """Test async decorator preserves return value."""
    import observable

    @observable.track("async_job")
    async def returns_dict():
        await asyncio.sleep(0.01)
        return {"key": "value", "count": 42}

    result = await returns_dict()
    assert result == {"key": "value", "count": 42}


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_reraises_exceptions(mock_api_success, env_with_session_id):
    """Test async decorator re-raises exceptions."""
    import observable

    @observable.track("async_job")
    async def raises_async():
        await asyncio.sleep(0.01)
        raise RuntimeError("Async exception")

    with pytest.raises(RuntimeError, match="Async exception"):
        await raises_async()


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_with_arguments(mock_api_success, env_with_session_id):
    """Test async decorator preserves function arguments."""
    import observable

    @observable.track("async_job")
    async def async_with_args(a, b, c=3):
        await asyncio.sleep(0.01)
        return a + b + c

    result = await async_with_args(1, 2)
    assert result == 6

    result = await async_with_args(1, 2, c=10)
    assert result == 13


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_with_kwargs(mock_api_success, env_with_session_id):
    """Test async decorator preserves keyword arguments."""
    import observable

    @observable.track("async_job")
    async def async_with_kwargs(**kwargs):
        await asyncio.sleep(0.01)
        return kwargs

    result = await async_with_kwargs(x=1, y=2, z=3)
    assert result == {"x": 1, "y": 2, "z": 3}


@pytest.mark.p1
@pytest.mark.asyncio
async def test_multiple_concurrent_async_calls(mock_api_success, env_with_session_id):
    """Test multiple async functions running concurrently."""
    import observable

    @observable.track("concurrent_job")
    async def concurrent_task(task_id):
        await asyncio.sleep(0.05)
        return f"task_{task_id}"

    # Run 5 tasks concurrently
    results = await asyncio.gather(
        concurrent_task(1),
        concurrent_task(2),
        concurrent_task(3),
        concurrent_task(4),
        concurrent_task(5),
    )

    assert results == ["task_1", "task_2", "task_3", "task_4", "task_5"]

    # Should have posted 5 events
    assert len(mock_api_success.calls) == 5


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_event_posting_does_not_block(mock_api_success, env_with_session_id, measure_time):
    """Test async event posting uses asyncio.create_task (non-blocking)."""
    import observable

    @observable.track("instant_async")
    async def instant_async():
        return "done"

    with measure_time() as timer:
        result = await instant_async()

    assert result == "done"

    # Should return quickly (not waiting for HTTP)
    assert timer.elapsed_ms < 20  # Generous allowance for async overhead


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_on_function_with_no_return(mock_api_success, env_with_session_id):
    """Test async decorator on function with no return value."""
    import observable

    executed = []

    @observable.track("void_async")
    async def no_return():
        await asyncio.sleep(0.01)
        executed.append(True)

    result = await no_return()

    assert result is None
    assert executed == [True]


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_decorator_captures_exception_info(mock_api_success, env_with_session_id):
    """Test async decorator captures exception type and message."""
    import observable
    import json

    @observable.track("async_job")
    async def raises_error():
        await asyncio.sleep(0.01)
        raise ValueError("Async error message")

    with pytest.raises(ValueError):
        await raises_error()

    request_body = json.loads(mock_api_success.calls[0].request.body)

    assert request_body["status"] == "failed"
    assert "error" in request_body
    assert "ValueError" in request_body["error"]["type"]
    assert "Async error message" in request_body["error"]["message"]


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_graceful_degradation_no_credentials(capsys):
    """Test async decorator works without credentials (graceful degradation)."""
    import observable

    @observable.track("async_job")
    async def my_async():
        await asyncio.sleep(0.01)
        return "success"

    result = await my_async()
    assert result == "success"

    # Should warn to stderr
    stderr = capsys.readouterr().err
    assert len(stderr) > 0


@pytest.mark.p1
@pytest.mark.asyncio
async def test_async_graceful_degradation_api_error(mock_api_connection_error, env_with_session_id):
    """Test async decorator handles API errors gracefully."""
    import observable

    @observable.track("async_job")
    async def my_async():
        await asyncio.sleep(0.01)
        return "success"

    result = await my_async()
    assert result == "success"
