"""
Shared pytest fixtures for observable-codes-python SDK tests.

This file provides common fixtures used across all test files.
"""

import pytest
import responses
import json
from pathlib import Path
from typing import Dict, Any


# ============================================================================
# Config File Fixtures
# ============================================================================

@pytest.fixture
def mock_config_file(tmp_path, monkeypatch):
    """Create a temporary config file for testing."""
    config_dir = tmp_path / ".observable-code"
    config_dir.mkdir()
    config_file = config_dir / "config.json"
    config_data = {
        "session_id": "test-session-uuid-1234",
        "api_url": "https://observable.codes"
    }
    config_file.write_text(json.dumps(config_data))

    # Monkeypatch the _config module's constants to use tmp_path
    from observable import _config
    monkeypatch.setattr(_config, "_CONFIG_DIR", config_dir)
    monkeypatch.setattr(_config, "_CONFIG_FILE", config_file)

    return config_file


@pytest.fixture
def mock_project_config(tmp_path, monkeypatch):
    """Create a project-level .observable-code file."""
    # Create global config directory structure
    config_dir = tmp_path / ".observable-code"
    config_dir.mkdir()
    config_file = config_dir / "config.json"
    config_data = {
        "session_id": "project-session-uuid-5678",
        "api_url": "https://observable.codes"
    }
    config_file.write_text(json.dumps(config_data))

    # Monkeypatch the _config module's constants to use tmp_path
    from observable import _config
    monkeypatch.setattr(_config, "_CONFIG_DIR", config_dir)
    monkeypatch.setattr(_config, "_CONFIG_FILE", config_file)

    return config_file


@pytest.fixture
def invalid_config_file(tmp_path, monkeypatch):
    """Create a config file with invalid JSON."""
    config_dir = tmp_path / ".observable-code"
    config_dir.mkdir()
    config_file = config_dir / "config.json"
    config_file.write_text("{ invalid json }")

    # Monkeypatch the _config module's constants to use tmp_path
    from observable import _config
    monkeypatch.setattr(_config, "_CONFIG_DIR", config_dir)
    monkeypatch.setattr(_config, "_CONFIG_FILE", config_file)

    return config_file


# ============================================================================
# API Mock Fixtures
# ============================================================================

@pytest.fixture
def mock_api_success():
    """Mock successful API response for event posting."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/events",
            json={"success": True, "event_id": "evt_123"},
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_api_success_optional():
    """Mock successful API response but don't assert all requests are fired.

    Use this for tests where the decorated function may not complete (e.g., raises BaseException).
    """
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/events",
            json={"success": True, "event_id": "evt_123"},
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_api_401():
    """Mock 401 Unauthorized response."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/events",
            json={"error": "Unauthorized", "message": "Invalid session ID"},
            status=401,
        )
        yield rsps


@pytest.fixture
def mock_api_429():
    """Mock 429 Rate Limited response."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/events",
            json={
                "error": "Rate limit exceeded",
                "message": "Daily event limit reached. Upgrade at observable.codes."
            },
            status=429,
        )
        yield rsps


@pytest.fixture
def mock_api_500():
    """Mock 500 Server Error response."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/events",
            json={"error": "Internal server error"},
            status=500,
        )
        yield rsps


@pytest.fixture
def mock_api_timeout():
    """Mock API timeout."""
    import requests
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/events",
            body=requests.exceptions.Timeout("Request timed out"),
        )
        yield rsps


@pytest.fixture
def mock_api_connection_error():
    """Mock connection refused / network down."""
    import requests
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/events",
            body=requests.exceptions.ConnectionError("Connection refused"),
        )
        yield rsps


@pytest.fixture
def mock_api_malformed_json():
    """Mock API returns invalid JSON."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/events",
            body="{ invalid json response }",
            status=200,
        )
        yield rsps


# ============================================================================
# Session/Pairing Mock Fixtures
# ============================================================================

@pytest.fixture
def mock_session_creation():
    """Mock session creation API response."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "https://observable.codes/api/sessions",
            json={
                "sessionId": "new-session-uuid-9999",
                "pairingToken": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6",
                "status": "pending",
                "expiresAt": "2026-02-27T12:00:00Z"
            },
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_pairing_poll_pending():
    """Mock pairing status poll - still pending."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://observable.codes/api/sessions/new-session-uuid-9999",
            json={
                "sessionId": "new-session-uuid-9999",
                "status": "pending"
            },
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_pairing_poll_active():
    """Mock pairing status poll - paired successfully."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            "https://observable.codes/api/sessions/new-session-uuid-9999",
            json={
                "sessionId": "new-session-uuid-9999",
                "status": "active",
                "pairedDevice": "iPhone 15 Pro"
            },
            status=200,
        )
        yield rsps


# ============================================================================
# Environment Variable Fixtures
# ============================================================================

@pytest.fixture(autouse=True)
def clean_env(monkeypatch, request):
    """
    Automatically clean Observable env vars before each test.

    This ensures tests start with a clean slate and don't interfere
    with each other.
    """
    monkeypatch.delenv("OBSERVABLE_CODE_API_KEY", raising=False)
    monkeypatch.delenv("OBSERVABLE_CODE_SESSION_ID", raising=False)
    monkeypatch.delenv("OBSERVABLE_CODE_API_URL", raising=False)
    monkeypatch.delenv("OBSERVABLE_DEBUG", raising=False)

    # Enable synchronous test mode for deterministic HTTP mocking
    monkeypatch.setenv("OBSERVABLE_TEST_MODE", "1")

    # Reset the warning flag so each test can trigger warnings
    from observable import _client
    _client._warned_no_credentials = False


@pytest.fixture
def env_with_session_id(monkeypatch):
    """Set OBSERVABLE_CODE_SESSION_ID in environment."""
    monkeypatch.setenv("OBSERVABLE_CODE_SESSION_ID", "env-session-uuid-abcd")
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")


@pytest.fixture
def env_with_api_key(monkeypatch):
    """Set OBSERVABLE_CODE_API_KEY in environment."""
    monkeypatch.setenv("OBSERVABLE_CODE_API_KEY", "obscode_sk_1234567890abcdef")
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://observable.codes")


@pytest.fixture
def env_with_custom_api_url(monkeypatch):
    """Set custom API base URL."""
    monkeypatch.setenv("OBSERVABLE_CODE_API_URL", "https://custom.api.test/v1")


# ============================================================================
# Stderr Capture Fixtures
# ============================================================================

@pytest.fixture
def capture_stderr(capsys):
    """
    Helper to capture stderr output.

    Returns a function that can be called to get current stderr.
    """
    def get_stderr():
        captured = capsys.readouterr()
        return captured.err

    return get_stderr


# ============================================================================
# Timing Fixtures
# ============================================================================

@pytest.fixture
def measure_time():
    """
    Measure execution time of a code block.

    Usage:
        with measure_time() as timer:
            # code to measure

        assert timer.elapsed_ms < 100  # ensure took less than 100ms
    """
    import time

    class Timer:
        def __init__(self):
            self.start = None
            self.end = None

        def __enter__(self):
            self.start = time.time()
            return self

        def __exit__(self, *args):
            self.end = time.time()

        @property
        def elapsed_ms(self):
            if self.start is None or self.end is None:
                return None
            return (self.end - self.start) * 1000

    return Timer


# ============================================================================
# Pytest Configuration
# ============================================================================

def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers", "p0: Priority 0 - Critical tests (must pass before any release)"
    )
    config.addinivalue_line(
        "markers", "p1: Priority 1 - Important tests (must pass before public release)"
    )
    config.addinivalue_line(
        "markers", "p2: Priority 2 - Polish tests (nice to have)"
    )
    config.addinivalue_line(
        "markers", "slow: Tests that take >1 second to run"
    )
