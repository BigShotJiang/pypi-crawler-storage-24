"""
P0 - HTTP Client Error Handling Tests

Tests for HTTP event posting and error handling.
Critical: All network errors must fail silently without blocking user code.
"""

import pytest
import json


@pytest.mark.p0
def test_successful_event_post(mock_api_success, env_with_session_id):
    """Test successful HTTP POST to /api/events."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    my_function()

    # Verify request was made
    assert len(mock_api_success.calls) == 1

    request = mock_api_success.calls[0].request
    assert request.url == "https://observable.codes/api/events"
    assert request.method == "POST"


@pytest.mark.p0
def test_authorization_header_with_session_id(mock_api_success, env_with_session_id):
    """Test Authorization header includes session ID (anonymous mode)."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")

    assert auth_header is not None
    assert auth_header == "Bearer env-session-uuid-abcd"


@pytest.mark.p0
def test_authorization_header_with_api_key(mock_api_success, env_with_api_key):
    """Test Authorization header includes API key (account mode)."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request = mock_api_success.calls[0].request
    auth_header = request.headers.get("Authorization")

    assert auth_header is not None
    assert auth_header == "Bearer obscode_sk_1234567890abcdef"


@pytest.mark.p0
def test_request_includes_all_required_fields(mock_api_success, env_with_session_id):
    """Test request payload includes all required event fields."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request_body = json.loads(mock_api_success.calls[0].request.body)

    # Required fields
    assert "name" in request_body
    assert "status" in request_body
    assert "duration_ms" in request_body
    assert "timestamp" in request_body

    assert request_body["name"] == "test_job"
    assert request_body["status"] == "completed"
    assert isinstance(request_body["duration_ms"], (int, float))
    assert isinstance(request_body["timestamp"], str)


@pytest.mark.p0
def test_request_timeout_silently_fails(mock_api_timeout, env_with_session_id, capsys):
    """Test network timeout fails silently without blocking function."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    # Should not raise, should return normally
    result = my_function()
    assert result == "success"

    # May warn to stderr (optional)
    # But should NOT crash


@pytest.mark.p0
def test_connection_error_silently_fails(mock_api_connection_error, env_with_session_id):
    """Test connection refused fails silently."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    result = my_function()
    assert result == "success"


@pytest.mark.p0
def test_401_unauthorized_warns_and_continues(mock_api_401, env_with_session_id, capsys):
    """Test 401 Unauthorized warns to stderr but function continues."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    result = my_function()
    assert result == "success"

    # Should warn about invalid session
    stderr = capsys.readouterr().err
    # May contain warning (implementation dependent)


@pytest.mark.p0
def test_429_rate_limited_warns_and_continues(mock_api_429, env_with_session_id, capsys):
    """Test 429 Rate Limited warns about upgrade but function continues."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    result = my_function()
    assert result == "success"

    # Should warn about rate limit
    stderr = capsys.readouterr().err
    # Ideally contains "limit" or "upgrade"
    # assert "limit" in stderr.lower() or "upgrade" in stderr.lower()


@pytest.mark.p0
def test_500_server_error_silently_fails(mock_api_500, env_with_session_id):
    """Test 500 Internal Server Error fails silently."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    result = my_function()
    assert result == "success"


@pytest.mark.p0
def test_malformed_json_response_silently_fails(mock_api_malformed_json, env_with_session_id):
    """Test malformed JSON response fails silently."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "success"

    result = my_function()
    assert result == "success"


@pytest.mark.p0
def test_fire_and_forget_behavior(mock_api_success, env_with_session_id, measure_time):
    """
    Test event posting is fire-and-forget (background thread).

    Function should return immediately without waiting for API response.
    """
    import observable

    @observable.track("instant_job")
    def instant_function():
        return "done"

    with measure_time() as timer:
        result = instant_function()

    assert result == "done"

    # Function should return in < 10ms (not waiting for HTTP)
    assert timer.elapsed_ms < 10, f"Function took {timer.elapsed_ms}ms - not fire-and-forget!"


@pytest.mark.p0
def test_custom_api_url(env_with_custom_api_url):
    """Test custom API base URL can be configured."""
    import os

    # Test that env var is read
    api_url = os.environ.get("OBSERVABLE_CODE_API_URL")
    assert api_url == "https://custom.api.test/v1"


@pytest.mark.p0
def test_request_content_type_is_json(mock_api_success, env_with_session_id):
    """Test request Content-Type is application/json."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request = mock_api_success.calls[0].request
    content_type = request.headers.get("Content-Type")

    assert content_type == "application/json"


@pytest.mark.p0
def test_event_payload_is_valid_json(mock_api_success, env_with_session_id):
    """Test event payload is valid JSON."""
    import observable

    @observable.track("test_job")
    def my_function():
        return "done"

    my_function()

    request_body = mock_api_success.calls[0].request.body

    # Should be parseable as JSON
    parsed = json.loads(request_body)
    assert isinstance(parsed, dict)


@pytest.mark.p0
def test_duration_is_positive_integer(mock_api_success, env_with_session_id):
    """Test duration_ms is always a positive number."""
    import observable

    @observable.track("instant_job")
    def instant():
        return "done"

    instant()

    request_body = json.loads(mock_api_success.calls[0].request.body)
    duration = request_body["duration_ms"]

    assert isinstance(duration, (int, float))
    assert duration >= 0


@pytest.mark.p0
def test_status_is_valid_enum(mock_api_success, env_with_session_id):
    """Test status is either 'completed' or 'failed'."""
    import observable

    @observable.track("success_job")
    def success():
        return "ok"

    @observable.track("fail_job")
    def failure():
        raise ValueError("error")

    success()

    try:
        failure()
    except ValueError:
        pass

    # Check both requests
    assert len(mock_api_success.calls) == 2

    success_body = json.loads(mock_api_success.calls[0].request.body)
    fail_body = json.loads(mock_api_success.calls[1].request.body)

    assert success_body["status"] == "completed"
    assert fail_body["status"] == "failed"
