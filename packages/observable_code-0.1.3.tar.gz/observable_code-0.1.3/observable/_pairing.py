"""
Session creation, QR rendering, and pairing poll loop.
"""

from __future__ import annotations

import secrets
import sys
import time
from typing import Tuple

import requests


def generate_pairing_token() -> str:
    """Generate a 128-bit (32 hex character) pairing token."""
    return secrets.token_hex(16)


def generate_qr_data(pairing_token: str) -> str:
    """Generate QR code data URL for pairing."""
    return f"obsapp://pair?token={pairing_token}"


def create_session(api_url: str) -> Tuple[str, str]:
    """
    POST /api/sessions — create a new session.
    Returns (session_id, pairing_token).
    Raises RuntimeError on failure.
    """
    try:
        resp = requests.post(f"{api_url}/api/sessions", timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return data["sessionId"], data["pairingToken"]
    except requests.RequestException as exc:
        raise RuntimeError(f"Failed to reach API at {api_url}: {exc}") from exc
    except (KeyError, ValueError) as exc:
        raise RuntimeError(f"Unexpected API response: {exc}") from exc


def render_qr(pairing_token: str) -> None:
    """Print a QR code to the terminal encoding obsapp://pair?token=<token>."""
    url = f"obsapp://pair?token={pairing_token}"
    try:
        import qrcode

        qr = qrcode.QRCode(border=2)
        qr.add_data(url)
        qr.make(fit=True)
        qr.print_ascii(invert=True)
    except ImportError:
        # qrcode not available — print the URL as plain text fallback
        print(f"\nScan this URL with the Observable Code app:\n  {url}\n")


def poll_for_pairing(api_url: str, session_id: str, timeout: int = 120) -> bool:
    """
    Poll GET /api/sessions/{id}/status every 2 seconds until paired or timeout.
    Returns True if paired, False if timed out.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            resp = requests.get(
                f"{api_url}/api/sessions/{session_id}/status",
                timeout=5,
            )
            if resp.ok and resp.json().get("status") == "paired":
                return True
        except requests.RequestException:
            pass  # transient error — keep polling

        # Animate a simple waiting indicator
        print(".", end="", flush=True)
        time.sleep(2)

    print()  # newline after dots
    return False


# Aliases for test compatibility
def wait_for_pairing(session_id: str, timeout: int = 600) -> bool:
    """Alias for poll_for_pairing that matches test expectations."""
    # Use default API URL from environment or fallback
    import os
    api_url = os.environ.get("OBSERVABLE_CODE_API_URL", "https://observable.codes")
    return poll_for_pairing(api_url, session_id, timeout)


def display_qr(data: str) -> None:
    """Alias for render_qr that accepts QR data directly."""
    # Extract token from QR data if it's a full URL
    if "token=" in data:
        token = data.split("token=")[1]
        render_qr(token)
    else:
        render_qr(data)
