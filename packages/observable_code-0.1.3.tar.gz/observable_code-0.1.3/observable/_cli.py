"""
CLI entry point for observable-code.

Commands:
  observable setup      — first-time pairing wizard
  observable pair       — re-pair with a new phone
  observable show-key   — print current session ID
  observable status     — check if current session is paired
"""

from __future__ import annotations

import argparse
import sys

from . import _config, _pairing
from ._client import _resolve_api_url, _resolve_session_id


def _cmd_setup(args: argparse.Namespace, overwrite: bool = False) -> None:
    api_url = _resolve_api_url()

    existing = _config.load().get("session_id")
    if existing and not overwrite:
        print(f"Already paired. Session ID: {existing}")
        print("Run `observable pair` to pair with a new phone.")
        return

    print(f"Connecting to {api_url} ...")
    try:
        session_id, pairing_token = _pairing.create_session(api_url)
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    print("\nScan this QR code with the Observable Code app:\n")
    _pairing.render_qr(pairing_token)
    print("\nWaiting for your phone to scan", end="", flush=True)

    paired = _pairing.poll_for_pairing(api_url, session_id)

    if paired:
        _config.save({"session_id": session_id})
        print("Paired! Your session ID has been saved.")
        print(f"\nSession ID: {session_id}")
        print("\nAdd this to your environment to skip the wizard:")
        print(f"  export OBSERVABLE_CODE_SESSION_ID={session_id}")
    else:
        print(
            "\nTimed out waiting for pairing. Run `observable pair` to try again.",
            file=sys.stderr,
        )
        sys.exit(1)


def _cmd_pair(args: argparse.Namespace) -> None:
    _cmd_setup(args, overwrite=True)


def _cmd_show_key(args: argparse.Namespace) -> None:
    session_id = _resolve_session_id()
    if session_id:
        print(session_id)
    else:
        print(
            "No session ID found. Run `observable setup` to pair your phone.",
            file=sys.stderr,
        )
        sys.exit(1)


def _cmd_status(args: argparse.Namespace) -> None:
    import requests

    session_id = _resolve_session_id()
    if not session_id:
        print(
            "No session ID found. Run `observable setup` to pair your phone.",
            file=sys.stderr,
        )
        sys.exit(1)

    api_url = _resolve_api_url()
    try:
        resp = requests.get(
            f"{api_url}/api/sessions/{session_id}/status",
            timeout=5,
        )
        if resp.ok:
            status = resp.json().get("status", "unknown")
            print(f"Session status: {status}")
            if status != "paired":
                sys.exit(1)
        else:
            print(f"API returned {resp.status_code}: {resp.text}", file=sys.stderr)
            sys.exit(1)
    except requests.RequestException as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


def main() -> None:
    from . import __version__

    parser = argparse.ArgumentParser(
        prog="observable",
        description="observable-code CLI — pair your phone and manage sessions",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    subparsers = parser.add_subparsers(dest="command", metavar="<command>")
    subparsers.required = True

    subparsers.add_parser("setup", help="First-time pairing wizard")
    subparsers.add_parser("pair", help="Re-pair with a new phone")
    subparsers.add_parser("show-key", help="Print current session ID")
    subparsers.add_parser("status", help="Check if current session is paired")

    args = parser.parse_args()

    commands = {
        "setup": _cmd_setup,
        "pair": _cmd_pair,
        "show-key": _cmd_show_key,
        "status": _cmd_status,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
