"""
HTTP client for observable-code.

Handles credential resolution and fire-and-forget event posting.
"""

from __future__ import annotations

import os
import sys
import threading
from typing import Any, Dict, Optional

from . import _config

_DEFAULT_API_URL = "https://observable.codes"

# Test mode: run synchronously instead of in background threads
# Only enabled when explicitly set (for testing)
_TEST_MODE = os.environ.get("OBSERVABLE_TEST_MODE") == "1"

# Print the "no credentials" hint at most once per process
_warned_no_credentials = False


def _resolve_api_url() -> str:
    if os.environ.get("OBSERVABLE_CODE_API_URL"):
        return os.environ["OBSERVABLE_CODE_API_URL"].rstrip("/")
    cfg = _config.load()
    if cfg.get("api_url"):
        return cfg["api_url"].rstrip("/")
    return _DEFAULT_API_URL


def _resolve_session_id() -> Optional[str]:
    # API key takes highest priority (account mode)
    api_key = os.environ.get("OBSERVABLE_CODE_API_KEY", "").strip()
    if api_key:
        return api_key

    # Env var takes priority for session ID (anonymous mode)
    session_id = os.environ.get("OBSERVABLE_CODE_SESSION_ID", "").strip()
    if session_id:
        return session_id

    cfg = _config.load()
    return cfg.get("session_id") or None


def _do_post(api_url: str, session_id: str, payload: Dict[str, Any]) -> None:
    """Called inside a daemon thread. All exceptions are swallowed."""
    try:
        import requests  # local import so top-level import stays fast

        response = requests.post(
            f"{api_url}/api/events",
            json=payload,
            headers={"Authorization": f"Bearer {session_id}"},
            timeout=2,
        )

        # Check for rate limiting
        if response.status_code == 429:
            print(
                "[observable] Warning: Rate limit exceeded. Upgrade your plan at observable.codes.",
                file=sys.stderr,
            )
    except Exception as exc:
        print(f"[observable] Warning: failed to post event: {exc}", file=sys.stderr)


def post_event(payload: Dict[str, Any]) -> None:
    """
    Fire-and-forget: post an event in a background daemon thread.
    Never raises, never blocks the caller.

    In test mode (OBSERVABLE_TEST_MODE=1), posts synchronously for deterministic testing.
    """
    global _warned_no_credentials

    session_id = _resolve_session_id()
    if not session_id:
        if not _warned_no_credentials:
            _warned_no_credentials = True
            print(
                "[observable] No credentials found. Run `observable setup` to pair your phone.",
                file=sys.stderr,
            )
        return

    api_url = _resolve_api_url()

    if _TEST_MODE:
        # Synchronous mode for testing - call directly
        _do_post(api_url, session_id, payload)
    else:
        # Production mode - fire and forget in daemon thread
        t = threading.Thread(target=_do_post, args=(api_url, session_id, payload), daemon=True)
        t.start()
