"""
observable-code — instant observability for developers shipping fast.

Usage:

    import observable

    @observable.track("daily_backup")
    def run_backup():
        ...

    @observable.track("fetch_data")
    async def fetch():
        ...

    with observable.track("batch_job"):
        ...

    observable.event("payment_received", amount=99.99, currency="USD")

    observable.trace("order_id", order_id)   # attached to next track() call
"""

from __future__ import annotations

__version__ = "0.1.3"

import asyncio
import functools
import threading
import time
from contextlib import contextmanager
from typing import Any, Callable, Optional

from . import _client

# Thread-local storage for trace() key-value pairs
_trace_local = threading.local()


def _get_traces() -> dict:
    if not hasattr(_trace_local, "data"):
        _trace_local.data = {}
    return _trace_local.data


def _pop_traces() -> Optional[dict]:
    data = _get_traces()
    if not data:
        return None
    _trace_local.data = {}
    return data


class _Tracker:
    """
    Returned by track(name). Supports:
      - use as a decorator on sync or async functions
      - use as a context manager (sync only)
    """

    def __init__(self, name: str) -> None:
        self._name = name

    # --- decorator ---

    def __call__(self, fn: Callable) -> Callable:
        if asyncio.iscoroutinefunction(fn):
            return self._wrap_async(fn)
        return self._wrap_sync(fn)

    def _wrap_sync(self, fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.monotonic()
            try:
                result = fn(*args, **kwargs)
                duration_ms = int((time.monotonic() - start) * 1000)
                _client.post_event(self._build_payload("completed", duration_ms))
                return result
            except Exception as exc:
                duration_ms = int((time.monotonic() - start) * 1000)
                _client.post_event(
                    self._build_payload(
                        "failed",
                        duration_ms,
                        error_type=type(exc).__name__,
                        error_message=str(exc),
                    )
                )
                raise

        return wrapper

    def _wrap_async(self, fn: Callable) -> Callable:
        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.monotonic()
            try:
                result = await fn(*args, **kwargs)
                duration_ms = int((time.monotonic() - start) * 1000)
                _client.post_event(self._build_payload("completed", duration_ms))
                return result
            except Exception as exc:
                duration_ms = int((time.monotonic() - start) * 1000)
                _client.post_event(
                    self._build_payload(
                        "failed",
                        duration_ms,
                        error_type=type(exc).__name__,
                        error_message=str(exc),
                    )
                )
                raise

        return wrapper

    # --- context manager ---

    def __enter__(self) -> "_Tracker":
        self._cm_start = time.monotonic()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        duration_ms = int((time.monotonic() - self._cm_start) * 1000)
        if exc_type is None:
            _client.post_event(self._build_payload("completed", duration_ms))
        else:
            _client.post_event(
                self._build_payload(
                    "failed",
                    duration_ms,
                    error_type=exc_type.__name__ if exc_type else None,
                    error_message=str(exc_val) if exc_val else None,
                )
            )
        # Do not suppress exceptions

    # --- payload builder ---

    def _build_payload(
        self,
        status: str,
        duration_ms: int,
        error_type: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> dict:
        from datetime import datetime, timezone

        payload: dict = {
            "name": self._name,
            "status": status,
            "duration_ms": duration_ms,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if error_type and error_message:
            payload["error"] = {
                "type": error_type,
                "message": error_message,
            }
        traces = _pop_traces()
        if traces:
            payload["traces"] = traces
        return payload


def track(name: Optional[str] = None) -> _Tracker:
    """
    Track a function or block of code.

    Can be used as a decorator or a context manager:

        @observable.track("job_name")
        def my_job(): ...

        @observable.track()  # Uses function name
        def my_job(): ...

        with observable.track("job_name"):
            ...
    """
    if name is None:
        # When used as @observable.track() without args,
        # return a function that will extract the function name
        def decorator(fn: Callable) -> Callable:
            tracker = _Tracker(fn.__name__)
            return tracker(fn)
        return decorator
    return _Tracker(name)


def trace(key: str, value: Any) -> None:
    """
    Attach a key-value pair to the next track() call in this thread.

    Useful for adding structured context (e.g. record counts, IDs) to events.
    Values are cleared after each tracked call.

        observable.trace("records_processed", 500)
        observable.trace("order_id", order_id)
    """
    _get_traces()[key] = value


def event(name: str, status: str = "completed", **kwargs: Any) -> None:
    """
    Manually post an event without wrapping a function.

        observable.event("payment_received", amount=99.99, currency="USD")
    """
    from datetime import datetime, timezone

    payload: dict = {
        "name": name,
        "status": status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if kwargs:
        payload["metadata"] = kwargs
    _client.post_event(payload)
