"""
Config file management for observable-code.

Reads/writes ~/.observable-code/config.json.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict

_CONFIG_DIR = Path.home() / ".observable-code"
_CONFIG_FILE = _CONFIG_DIR / "config.json"


def load() -> Dict[str, Any]:
    """Return the config dict, or {} if the file doesn't exist or is invalid."""
    try:
        with open(_CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def save(data: Dict[str, Any]) -> None:
    """Write data to the config file, merging with any existing values."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    current = load()
    current.update(data)
    # Write atomically via a temp file in the same directory
    fd, tmp_path = tempfile.mkstemp(dir=_CONFIG_DIR, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(current, f, indent=2)
        os.replace(tmp_path, _CONFIG_FILE)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
