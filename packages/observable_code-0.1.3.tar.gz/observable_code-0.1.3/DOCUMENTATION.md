# Documentation Guide

This document explains how to generate and use the API documentation for `observable-codes-python`.

## Documentation Structure

The SDK uses Python docstrings following the **NumPy/SciPy documentation style** for consistency with scientific Python libraries.

### Public API Documentation

The main public API is documented in `observable/__init__.py`:

- `track()` - Decorator for tracking function execution
- `trace()` - Attach structured data to events
- `event()` - Send standalone events
- `track` (context manager) - Track code blocks with `with` statement

## Generating HTML Documentation

### Option 1: Using pydoc (Built-in)

```bash
# Generate HTML for single module
python -m pydoc -w observable

# Start interactive documentation server
python -m pydoc -p 8080
# Then visit: http://localhost:8080/observable
```

### Option 2: Using pdoc (Recommended)

```bash
# Install pdoc
pip install pdoc3

# Generate HTML documentation
pdoc --html --output-dir docs observable

# Interactive server with auto-reload
pdoc --http :8080 observable
```

### Option 3: Using Sphinx (Advanced)

For full documentation website with tutorials:

```bash
# Install Sphinx
pip install sphinx sphinx-rtd-theme

# Initialize Sphinx
cd docs
sphinx-quickstart

# Build HTML
make html
```

## Documentation Style Guide

### Docstring Format

We use **NumPy/SciPy style** docstrings:

```python
def function_name(param1: str, param2: int = 0) -> str:
    """
    Brief one-line description.

    Extended description with more details about what this function does,
    its purpose, and any important behavior.

    Parameters
    ----------
    param1 : str
        Description of param1.
    param2 : int, optional
        Description of param2. Default is 0.

    Returns
    -------
    str
        Description of return value.

    Raises
    ------
    ValueError
        When param1 is empty.
    TypeError
        When param2 is not an integer.

    Examples
    --------
    Basic usage::

        result = function_name("hello", 42)

    Advanced usage::

        result = function_name("world", param2=100)

    Notes
    -----
    - Important implementation detail 1
    - Important implementation detail 2

    See Also
    --------
    related_function : Related functionality
    """
    pass
```

### Key Sections

**Required:**
- Brief description (first line)
- Parameters (if any)
- Returns (if not None)
- Examples (at least one)

**Optional:**
- Extended description
- Raises (if function can raise exceptions)
- Notes (important behavior)
- See Also (related functions)
- Warnings (deprecated features, gotchas)

## Viewing Documentation

### In Python REPL

```python
import observable

# View module docstring
help(observable)

# View function docstring
help(observable.track)
help(observable.trace)
help(observable.event)

# Quick docstring
print(observable.track.__doc__)
```

### In IPython/Jupyter

```python
import observable

# View docstring
observable.track?

# View source code + docstring
observable.track??
```

### In IDE (VS Code, PyCharm)

- Hover over function name
- Ctrl+Click to jump to definition
- Ctrl+Q (PyCharm) or Ctrl+Shift+Space (VS Code) for quick docs

## Examples in Documentation

All docstrings include working code examples:

### Good Example Format

```python
"""
Examples
--------
Basic usage::

    @observable.track("job_name")
    def my_function():
        return "done"

With structured data::

    @observable.track("process_order")
    def process_order(order_id):
        observable.trace("order_id", order_id)
        # Process order...

Error handling::

    @observable.track("risky_job")
    def risky_job():
        if error:
            raise ValueError("Failed")
        # Exception is captured and re-raised
"""
```

### Example Tests

Examples in docstrings can be tested with doctest:

```bash
python -m doctest observable/__init__.py -v
```

## Documentation Files

| File | Purpose |
|---|---|
| `observable/__init__.py` | Public API docstrings |
| `README.md` | Quick start guide |
| `DOCUMENTATION.md` | This file - how to generate docs |
| `observable/__init__.py.documented` | Reference template with full docstrings |

## Building Documentation for Release

### Before Release Checklist

- [ ] All public functions have docstrings
- [ ] All docstrings have examples
- [ ] Examples are tested with doctest
- [ ] Type hints are complete
- [ ] README is up to date

### Generate Distribution Docs

```bash
# Generate HTML docs
pdoc --html --output-dir docs observable

# Copy to distribution
cp -r docs/observable/* dist-docs/

# Or upload to Read the Docs
# (configure .readthedocs.yml)
```

## Type Hints

Type hints serve as inline documentation:

```python
from typing import Optional, Any, Callable

def track(name: Optional[str] = None) -> Callable:
    """Decorator to track function execution."""
    pass

def trace(key: str, value: Any) -> None:
    """Attach structured data to event."""
    pass
```

IDEs use these for:
- Autocomplete
- Type checking
- Inline documentation

## Common Documentation Tasks

### Add New Public Function

1. Write function with type hints
2. Add comprehensive docstring
3. Add to `__all__` in `__init__.py`
4. Include examples
5. Test examples with doctest
6. Regenerate docs

### Update Existing Function

1. Update docstring
2. Update examples if behavior changed
3. Add deprecation warning if needed
4. Regenerate docs

### Deprecate Function

```python
import warnings

def old_function():
    """
    Old function (deprecated).

    .. deprecated:: 0.2.0
        Use :func:`new_function` instead.

    Warnings
    --------
    This function is deprecated and will be removed in version 1.0.
    Use `new_function()` instead.
    """
    warnings.warn(
        "old_function is deprecated, use new_function instead",
        DeprecationWarning,
        stacklevel=2
    )
    pass
```

## Documentation Testing

### Doctest

```bash
# Test all examples in docstrings
python -m doctest observable/__init__.py

# Verbose output
python -m doctest observable/__init__.py -v
```

### Manual Testing

```bash
# Generate docs and check for warnings
pdoc --html observable 2>&1 | grep -i warning

# Check all public functions have docs
python -c "import observable; print([f for f in dir(observable) if not f.startswith('_') and not getattr(observable, f).__doc__])"
```

## Documentation Hosting

### GitHub Pages

```bash
# Generate docs
pdoc --html --output-dir docs observable

# Push to gh-pages branch
git subtree push --prefix docs origin gh-pages
```

### Read the Docs

Create `.readthedocs.yml`:

```yaml
version: 2

build:
  os: ubuntu-22.04
  tools:
    python: "3.11"

sphinx:
  configuration: docs/conf.py

python:
  install:
    - method: pip
      path: .
      extra_requirements:
        - dev
```

## Quick Reference

```bash
# View in terminal
python -m pydoc observable

# Generate HTML (built-in)
python -m pydoc -w observable

# Generate HTML (pdoc - better)
pdoc --html observable

# Interactive server
python -m pydoc -p 8080

# Test docstring examples
python -m doctest observable/__init__.py

# Check coverage
python -c "import observable; print([f for f in dir(observable) if not f.startswith('_')])"
```

---

**Good documentation is part of the product!**

All public API functions should have clear, tested examples that show real-world usage.
