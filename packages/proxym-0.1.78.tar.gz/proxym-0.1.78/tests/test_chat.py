"""Tests for the chat CLI module — formatters and helpers."""

from __future__ import annotations

import pytest

from proxym.cli.chat import _format_result, _FORMATTERS


class TestFormatResult:
    """Test response formatting for chat output."""

    def test_error_format(self):
        result = _format_result({"error": "connection refused"}, "status")
        assert "connection refused" in result

    def test_status_format(self):
        data = {
            "vms": {"count": 3},
            "accounts": {"count": 2},
            "costs": {"daily_total_usd": 1.23},
        }
        result = _format_result(data, "status")
        assert "VMs: 3" in result
        assert "Accounts: 2" in result
        assert "$1.23" in result

    def test_vms_format_empty(self):
        result = _format_result({"vms": []}, "vms")
        assert "No VMs" in result

    def test_vms_format_with_data(self):
        data = {
            "vms": [
                {"id": "windsurf-work", "state": "running", "tool": "windsurf", "project": "proxym"},
            ]
        }
        result = _format_result(data, "vms")
        assert "windsurf-work" in result
        assert "running" in result

    def test_costs_format(self):
        data = {"daily_total_usd": 2.34, "monthly_total_usd": 45.67}
        result = _format_result(data, "costs")
        assert "$2.34" in result
        assert "$45.67" in result

    def test_vm_action_format(self):
        result = _format_result({"status": "started", "vm_id": "my-vm"}, "vm_start")
        assert "started" in result
        assert "my-vm" in result

    def test_fallback_json(self):
        data = {"some": "random", "data": 42}
        result = _format_result(data, "unknown_pattern")
        assert "random" in result
        assert "42" in result


class TestFormatters:
    """Verify _FORMATTERS registry."""

    def test_all_expected_formatters_registered(self):
        expected = {"status", "vms", "costs", "vm_start", "vm_stop", "vm_create", "vm_snapshot"}
        assert expected.issubset(set(_FORMATTERS.keys()))
