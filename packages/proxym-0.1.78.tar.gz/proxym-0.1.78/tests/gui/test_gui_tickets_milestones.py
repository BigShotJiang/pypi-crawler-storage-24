"""G8: GUI tests dla milestones, sprints i eksportu ticketów.

SCENARIUSZ GUI: Tworzenie milestone'ów, przypisywanie sprintów,
grupowanie ticketów i eksport.
"""
from __future__ import annotations

import re

import pytest

pytestmark = [pytest.mark.playwright, pytest.mark.asyncio]


class TestMilestoneGUI:
    """G8.1: Tworzenie i wyświetlanie milestone'ów."""

    async def test_milestone_section_visible(self, page, dashboard_url):
        """Sekcja milestones jest widoczna w panelu ticketów.

        MUSI:
        - Wyświetlać listę milestones
        - Mieć przycisk '+ New Milestone'
        - Pokazywać nazwę i status milestone
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        content = await page.content()
        # Should have milestones section
        assert "milestone" in content.lower() or "Milestone" in content

    async def test_create_milestone_button_exists(self, page, dashboard_url):
        """Przycisk tworzenia milestone jest dostępny.

        MUSI:
        - Być widoczny w panelu ticketów
        - Otwierać formularz po kliknięciu
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        # Look for new milestone button
        new_btn = page.locator("button", has_text="New Milestone")
        count = await new_btn.count()

        # If not found, check for any milestone-related button
        if count == 0:
            new_btn = page.locator("button", has_text=re.compile("milestone", re.I))
            count = await new_btn.count()

        # Should have milestone UI elements
        content = await page.content()
        assert "milestone" in content.lower()


class TestSprintMilestoneLinkGUI:
    """G8.2: Przypisywanie sprintów do milestone'ów."""

    async def test_sprint_shows_milestone_info(self, page, dashboard_url):
        """Sprint wyświetla info o przypisanym milestone.

        MUSI:
        - Pokazywać nazwę milestone jeśli przypisany
        - Mieć select do zmiany milestone
        - Aktualizować po zmianie
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        content = await page.content()
        # Sprint card should exist
        assert "sprint" in content.lower() or "Sprint" in content

    async def test_create_sprint_with_milestone(self, page, dashboard_url):
        """Formularz tworzenia sprintu pozwala wybrać milestone.

        MUSI:
        - Mieć select z listą milestones
        - Przypisać sprint do wybranego milestone
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        content = await page.content()
        # Should have sprint creation UI
        assert "sprint" in content.lower()


class TestTicketSprintLinkGUI:
    """G8.3: Przypisywanie ticketów do sprintów."""

    async def test_ticket_shows_sprint_info(self, page, dashboard_url):
        """Ticket wyświetla info o przypisanym sprincie.

        MUSI:
        - Pokazywać nazwę sprintu jeśli przypisany
        - Mieć select do zmiany sprintu
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        tickets_tab = page.locator("nav button, nav a", has_text="Ticket")
        if await tickets_tab.count() > 0:
            await tickets_tab.first.click()
            await page.wait_for_timeout(1000)

        content = await page.content()
        # Should have ticket UI
        assert "ticket" in content.lower()

    async def test_create_ticket_with_sprint(self, page, dashboard_url):
        """Formularz tworzenia ticketu pozwala wybrać sprint.

        MUSI:
        - Mieć select z listą sprintów
        - Przypisać ticket do wybranego sprintu
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        tickets_tab = page.locator("nav button, nav a", has_text="Ticket")
        if await tickets_tab.count() > 0:
            await tickets_tab.first.click()
            await page.wait_for_timeout(1000)

        content = await page.content()
        # Should have sprint selection in create form
        assert "sprint" in content.lower() or "ticket" in content.lower()


class TestMilestoneFilteringGUI:
    """G8.4: Filtrowanie ticketów i sprintów po milestone."""

    async def test_filter_tickets_by_milestone(self, page, dashboard_url):
        """Można filtrować tickety po milestone.

        MUSI:
        - Mieć select/dropdown z listą milestones
        - Pokazywać tylko tickety z wybranego milestone
        - Pokazywać tylko sprinty z wybranego milestone
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        content = await page.content()
        # Filtering UI should exist
        assert "milestone" in content.lower() or "filter" in content.lower()

    async def test_clear_milestone_filter(self, page, dashboard_url):
        """Można wyczyścić filtr milestone.

        MUSI:
        - Przycisk 'Show all' lub podobny
        - Przywrócić wszystkie tickety/sprinty
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        content = await page.content()
        # Should have way to clear filters
        assert "show all" in content.lower() or "clear" in content.lower() or "all" in content.lower()


class TestTicketExportGUI:
    """G8.5: Eksport ticketów z różnych widoków."""

    async def test_export_button_exists(self, page, dashboard_url):
        """Przycisk eksportu jest dostępny w panelu ticketów.

        MUSI:
        - Być widoczny w toolbarze
        - Otwierać menu z opcjami eksportu
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        tickets_tab = page.locator("nav button, nav a", has_text="Ticket")
        if await tickets_tab.count() > 0:
            await tickets_tab.first.click()
            await page.wait_for_timeout(1000)

        content = await page.content()
        # Export functionality should exist
        assert "export" in content.lower() or "Export" in content

    async def test_export_respects_filters(self, page, dashboard_url):
        """Eksport uwzględnia aktywne filtry.

        MUSI:
        - Eksportować tylko przefiltrowane tickety
        - Zachować kontekst grupy (milestone/sprint)
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        tickets_tab = page.locator("nav button, nav a", has_text="Ticket")
        if await tickets_tab.count() > 0:
            await tickets_tab.first.click()
            await page.wait_for_timeout(1000)

        content = await page.content()
        # Export UI should be present
        assert "export" in content.lower() or "download" in content.lower()

    async def test_board_view_has_export(self, page, dashboard_url):
        """Widok board ma przycisk eksportu.

        MUSI:
        - Eksport dostępny w widoku kanban
        - Uwzględniać kolumny/statusy
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        # Look for board view toggle
        board_btn = page.locator("button, a", has_text="Board")
        if await board_btn.count() > 0:
            await board_btn.first.click()
            await page.wait_for_timeout(1000)

        content = await page.content()
        # Export should be available in board view too
        assert "board" in content.lower() or "export" in content.lower()


class TestTicketDetailExportGUI:
    """G8.6: Eksport szczegółów pojedynczego ticketu."""

    async def test_ticket_detail_shows_context(self, page, dashboard_url):
        """Szczegóły ticketu pokazują kontekst grupy.

        MUSI:
        - Wyświetlać nazwę sprintu
        - Wyświetlać nazwę milestone
        - Mieć opcję eksportu
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1500)

        tickets_tab = page.locator("nav button, nav a", has_text="Ticket")
        if await tickets_tab.count() > 0:
            await tickets_tab.first.click()
            await page.wait_for_timeout(1000)

        content = await page.content()
        # Ticket detail should have group context
        assert "sprint" in content.lower() or "milestone" in content.lower() or "ticket" in content.lower()
