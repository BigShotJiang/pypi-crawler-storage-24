"""Base GUI tests for dashboard — API endpoints, HTML/JSX serving."""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch

# Patch settings before importing app
with patch.dict("os.environ", {
    "AI_PROXY_MASTER_KEY": "sk-test-e2e",
    "ANTHROPIC_API_KEY": "sk-ant-test",
    "OPENAI_API_KEY": "sk-test",
    "DEEPSEEK_API_KEY": "sk-ds-test",
    "GOOGLE_AI_KEY": "AI-test",
    "OPENROUTER_API_KEY": "sk-or-test",
    "GROQ_API_KEY": "gsk-test",
    "REDIS_URL": "redis://localhost:6379/0",
}):
    from proxym.main import app


class TestDashboardBase:
    """Test suite for dashboard base functionality."""

    @pytest.fixture
    def client(self):
        """Setup test client."""
        return TestClient(app)

    def test_dashboard_ui_serves_html(self, client):
        """Test that dashboard UI serves proper HTML."""
        response = client.get("/dashboard-ui")
        
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "<!DOCTYPE html>" in response.text
        assert "Proxym Dashboard" in response.text
        assert "react" in response.text.lower()

    def test_dashboard_jsx_serves_javascript(self, client):
        """Test that JSX file serves as JavaScript."""
        response = client.get("/proxym-dashboard.jsx")
        
        assert response.status_code == 200
        ct = response.headers["content-type"]
        assert "javascript" in ct, f"Expected javascript content-type, got {ct}"
        # panel.jsx is the entry point; uses global React + component names
        assert "function Dashboard" in response.text
        assert "useDashboardData" in response.text

    def test_dashboard_api_no_auth_required(self, client):
        """Test that dashboard API endpoints don't require authentication."""
        endpoints = [
            "/dashboard/",
            "/dashboard/system",
            "/dashboard/accounts",
            "/dashboard/costs",
            "/dashboard/vms"
        ]
        
        for endpoint in endpoints:
            response = client.get(endpoint)
            assert response.status_code == 200, f"Endpoint {endpoint} should be accessible"
            assert "application/json" in response.headers["content-type"]

    def test_dashboard_system_status_structure(self, client):
        """Test system status response structure."""
        response = client.get("/dashboard/system")
        data = response.json()
        
        required_keys = ["accounts", "vms", "libvirt"]
        for key in required_keys:
            assert key in data, f"Missing key: {key}"
        
        # Check accounts structure
        accounts = data["accounts"]
        account_keys = ["daily_total_usd", "monthly_total_usd", "total_requests", "accounts_count"]
        for key in account_keys:
            assert key in accounts, f"Missing account key: {key}"
        
        # Check VMs structure
        vms = data["vms"]
        vm_keys = ["total", "running"]
        for key in vm_keys:
            assert key in vms, f"Missing VM key: {key}"

    def test_dashboard_accounts_empty(self, client, tmp_path):
        """Test accounts endpoint when no accounts configured."""
        from proxym.accounts import AccountManager
        empty_mgr = AccountManager(config_path=str(tmp_path / "empty_accounts.json"))
        with patch("proxym.dashboard._shared._acct_mgr", empty_mgr):
            response = client.get("/dashboard/accounts")
            data = response.json()
        
        assert data == {"accounts": []}

    def test_dashboard_costs_initial_state(self, client, tmp_path):
        """Test costs endpoint initial state."""
        from proxym.accounts import AccountManager
        empty_mgr = AccountManager(config_path=str(tmp_path / "empty_accounts.json"))
        with patch("proxym.dashboard._shared._acct_mgr", empty_mgr):
            response = client.get("/dashboard/costs")
            data = response.json()
        
        assert data["daily_total_usd"] == 0
        assert data["monthly_total_usd"] == 0
        assert data["total_requests"] == 0
        assert data["accounts_count"] == 0

    def test_dashboard_vms_structure(self, client):
        """Test VMs endpoint returns correct structure."""
        response = client.get("/dashboard/vms")
        data = response.json()
        
        assert "vms" in data
        assert isinstance(data["vms"], list)

    def test_dashboard_jsx_api_calls(self, client):
        """Test that dashboard JS files contain correct API call patterns."""
        # API calls are in api.js (loaded separately), panel.jsx uses components
        jsx_response = client.get("/proxym-dashboard.jsx")
        assert jsx_response.status_code == 200
        # panel.jsx references data hooks and components
        assert "useDashboardData" in jsx_response.text
        
        # api.js has the actual fetch/auth logic
        api_response = client.get("/dashboard-api.js")
        assert api_response.status_code == 200
        assert "fetch(" in api_response.text
        assert "Authorization" in api_response.text

    def test_dashboard_ui_loads_react_dependencies(self, client):
        """Test that dashboard UI loads React dependencies."""
        response = client.get("/dashboard-ui")
        content = response.text
        
        # Check for React CDN links
        assert "unpkg.com/react@18" in content
        assert "unpkg.com/react-dom@18" in content
        assert "unpkg.com/@babel/standalone" in content
        assert "cdn.tailwindcss.com" in content

    def test_dashboard_ui_has_root_element(self, client):
        """Test that dashboard UI has root element for React."""
        response = client.get("/dashboard-ui")
        content = response.text
        
        assert '<div id="root"></div>' in content

    def test_dashboard_ui_script_type_babel(self, client):
        """Test that JSX script has correct type for Babel transpilation."""
        response = client.get("/dashboard-ui")
        content = response.text
        
        assert 'type="text/babel"' in content
        assert 'src="/proxym-dashboard.jsx"' in content

    def test_dashboard_jsx_react_components(self, client):
        """Test that JSX contains React components."""
        response = client.get("/proxym-dashboard.jsx")
        jsx_content = response.text
        
        # Check for React component patterns
        assert "function " in jsx_content or "const " in jsx_content
        assert "useState" in jsx_content
        assert "useEffect" in jsx_content
        assert "return (" in jsx_content

    def test_dashboard_ui_responsive_design(self, client):
        """Test that dashboard UI is responsive."""
        response = client.get("/dashboard-ui")
        content = response.text
        
        # Check for responsive meta tag
        assert 'name="viewport"' in content
        assert 'width=device-width' in content

    def test_dashboard_security_headers(self, client):
        """Test security headers on dashboard endpoints."""
        response = client.get("/dashboard-ui")
        
        # Should not expose sensitive information
        assert "password" not in response.text.lower()
        assert "secret" not in response.text.lower()
        assert "token" not in response.text.lower() or "Bearer" in response.text

    def test_dashboard_content_type_headers(self, client):
        """Test proper content-type headers."""
        html_response = client.get("/dashboard-ui")
        assert "text/html" in html_response.headers["content-type"]
        
        jsx_response = client.get("/proxym-dashboard.jsx")
        assert "javascript" in jsx_response.headers["content-type"]
        
        api_response = client.get("/dashboard/system")
        assert "application/json" in api_response.headers["content-type"]

    def test_dashboard_performance_response_time(self, client):
        """Test dashboard endpoints response time."""
        import time
        
        endpoints = ["/dashboard/", "/dashboard/system", "/dashboard/accounts"]
        
        for endpoint in endpoints:
            start_time = time.time()
            response = client.get(endpoint)
            end_time = time.time()
            
            assert response.status_code == 200
            assert (end_time - start_time) < 1.0, f"Endpoint {endpoint} too slow: {end_time - start_time:.2f}s"

    def test_dashboard_concurrent_requests(self, client):
        """Test dashboard handles concurrent requests."""
        import threading
        import time
        
        results = []
        
        def make_request(endpoint):
            response = client.get(endpoint)
            results.append(response.status_code)
        
        threads = []
        endpoints = ["/dashboard/", "/dashboard/system", "/dashboard/accounts"]
        
        # Make concurrent requests
        start_time = time.time()
        for endpoint in endpoints:
            for _ in range(3):  # 3 concurrent requests per endpoint
                thread = threading.Thread(target=make_request, args=(endpoint,))
                threads.append(thread)
                thread.start()
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
        
        end_time = time.time()
        
        # All requests should succeed
        assert all(status == 200 for status in results)
        # Should complete within reasonable time
        assert (end_time - start_time) < 5.0

    def test_dashboard_error_handling(self, client):
        """Test dashboard error handling."""
        # Test non-existent endpoint
        response = client.get("/dashboard/nonexistent")
        assert response.status_code == 404
        
        # Test invalid method
        response = client.post("/dashboard/")
        # Should either 405 (Method Not Allowed) or 404
        assert response.status_code in [404, 405]
