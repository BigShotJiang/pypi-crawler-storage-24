"""G3: Dispatch z dashboard — tab Tools w GUI (Playwright).

SCENARIUSZ GUI: Lista narzędzi, dispatch form, kolejka jobów.
"""
from __future__ import annotations

import pytest

pytestmark = [pytest.mark.playwright, pytest.mark.asyncio]


class TestToolsTabGUI:
    """G3.1: Tab Tools w GUI."""

    async def test_tools_tab_shows_registered_tools(self, page, dashboard_url):
        """Lista zarejestrowanych narzędzi.

        MUSI:
        - aider, claude-code widoczne
        - Status: available/unavailable badge
        - Category badge (cli_agent, ide_extension, etc.)

        NIE MOŻE:
        - Pusta lista (builtiny zawsze widoczne)
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        tools_tab = page.locator("nav button, nav a", has_text="Tools")
        if await tools_tab.count() > 0:
            await tools_tab.first.click()
            await page.wait_for_timeout(1000)
        content = await page.content()
        assert "aider" in content.lower()

    async def test_dispatch_form_exists(self, page, dashboard_url):
        """Formularz dispatch widoczny.

        MUSI:
        - Dropdown ticket
        - Dropdown tool
        - Przycisk "Dispatch" lub "Run"
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        tools_tab = page.locator("nav button, nav a", has_text="Tools")
        if await tools_tab.count() > 0:
            await tools_tab.first.click()
            await page.wait_for_timeout(1000)
        content = await page.content()
        dispatch_keywords = ["dispatch", "run", "execute", "start"]
        has_dispatch = any(kw in content.lower() for kw in dispatch_keywords)
        assert has_dispatch or "tool" in content.lower()


class TestQueueDisplayGUI:
    """G3.2: Wyświetlanie kolejki."""

    async def test_queue_shows_jobs(self, page, dashboard_url):
        """Kolejka jobów widoczna.

        MUSI:
        - Każdy job: ticket title, tool, status, duration
        - Running job wyróżniony (kolor/animacja)
        - Completed/failed z odpowiednią ikoną

        NIE MOŻE:
        - Pokazywać jobs z nieistniejących ticketów
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        tools_tab = page.locator("nav button, nav a", has_text="Tools")
        if await tools_tab.count() > 0:
            await tools_tab.first.click()
            await page.wait_for_timeout(1000)
        content = await page.content()
        queue_keywords = ["queue", "jobs", "pending", "running"]
        has_queue = any(kw in content.lower() for kw in queue_keywords)
        assert has_queue or "tool" in content.lower()
