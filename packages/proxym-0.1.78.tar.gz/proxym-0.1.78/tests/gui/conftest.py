"""Shared fixtures for GUI (Playwright) tests.

These tests require:
  pip install pytest-playwright
  playwright install chromium

Run with:
  pytest tests/gui/ -m playwright --headed   # z przeglądarką
  pytest tests/gui/ -m playwright             # headless (CI)
"""
from __future__ import annotations

import pytest
from playwright.async_api import Error as PlaywrightError
from playwright.async_api import async_playwright

# Mark all async tests in gui/ as playwright
pytestmark = pytest.mark.playwright

DASHBOARD_URL = "http://localhost:4000"


@pytest.fixture
def dashboard_url():
    """Base URL dashboardu proxym."""
    return DASHBOARD_URL


@pytest.fixture
def project_name():
    """Nazwa testowego projektu (musi istnieć w systemie)."""
    return "proxym"


@pytest.fixture
async def browser():
    """Launch a headless Chromium browser for GUI tests."""
    async with async_playwright() as p:
        try:
            browser = await p.chromium.launch(headless=True)
        except PlaywrightError as e:
            pytest.skip(str(e))
        yield browser
        await browser.close()


@pytest.fixture
async def page(browser):
    """Create a new Playwright page for each GUI test."""
    page = await browser.new_page()
    yield page
    await page.close()
