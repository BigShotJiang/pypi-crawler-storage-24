"""G1: Tab Projects w przeglądarce (Playwright).

SCENARIUSZ GUI: Tab Projects — lista, dodawanie, quick task.
"""
from __future__ import annotations

import pytest

pytestmark = [pytest.mark.playwright, pytest.mark.asyncio]


class TestProjectsTabLoads:
    """G1.1: Tab Projects istnieje i ładuje się."""

    async def test_projects_tab_visible(self, page, dashboard_url):
        """Tab "Projects" widoczny w nawigacji.

        MUSI:
        - Tab "Projects" w menu
        - Kliknięcie → zmiana widoku
        - Lista projektów (lub "No projects" jeśli pusta)

        NIE MOŻE:
        - 404 na projects.jsx
        - Biały ekran po kliknięciu
        - Brak taba Projects w menu
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        tabs = await page.locator("nav button, nav a").all_text_contents()
        tab_text = " ".join(tabs).lower()
        assert "projects" in tab_text or "projekty" in tab_text

    async def test_projects_tab_shows_list(self, page, dashboard_url):
        """Lista projektów wyświetlana.

        MUSI:
        - Karty projektów z: name, source_type, stack
        - Przycisk "Add project" lub "Scan folder"
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        # Click Projects tab
        projects_tab = page.locator("nav button, nav a", has_text="Projects")
        if await projects_tab.count() > 0:
            await projects_tab.first.click()
            await page.wait_for_timeout(1000)
        content = await page.content()
        assert "projects" in content.lower() or "No projects" in content


class TestProjectsAddForm:
    """G1.2: Formularz dodawania projektu."""

    async def test_add_form_has_source_tabs(self, page, dashboard_url):
        """Formularz ma taby: Local, Git, SSH, FTP.

        MUSI:
        - Przyciski/taby do wyboru źródła
        - Pola zmieniają się po wyborze taba

        NIE MOŻE:
        - Formularz widoczny bez kliknięcia "Add"
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        # Navigate to projects
        projects_tab = page.locator("nav button, nav a", has_text="Projects")
        if await projects_tab.count() > 0:
            await projects_tab.first.click()
            await page.wait_for_timeout(500)

        # Click "Add project" button
        add_btn = page.locator("button", has_text="Add")
        if await add_btn.count() > 0:
            await add_btn.first.click()
            await page.wait_for_timeout(500)
            content = await page.content()
            # Should have source type options
            assert any(x in content.lower() for x in ["local", "git", "ssh"])


class TestProjectQuickTask:
    """G1.3: Quick task z karty projektu."""

    async def test_quick_task_inline(self, page, dashboard_url, project_name):
        """Quick task bez opuszczania karty projektu.

        MUSI:
        - Kliknij "+ Quick task" → pole tekstowe inline
        - Wpisz task → Enter → ticket created
        - Ticket widoczny w ticketach projektu

        NIE MOŻE:
        - Przekierować na inną stronę
        - Wymagać więcej niż 1 kliknięcia + wpis tekstu
        """
        pass  # Requires project to exist in running instance
