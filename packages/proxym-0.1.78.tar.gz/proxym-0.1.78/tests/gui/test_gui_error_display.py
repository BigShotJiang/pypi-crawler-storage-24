"""G5: Wyświetlanie błędów i statusów w GUI (Playwright).

SCENARIUSZ GUI: Failed banners, health alerts, repair UI.
"""
from __future__ import annotations

import pytest

pytestmark = [pytest.mark.playwright, pytest.mark.asyncio]


class TestErrorDisplayGUI:
    """G5: Wyświetlanie błędów i statusów."""

    async def test_failed_ticket_shows_error_banner(self, page, dashboard_url):
        """Ticket z status=failed ma widoczny error.

        MUSI:
        - Czerwony banner/badge "Failed"
        - Treść błędu widoczna
        - Komentarz od narzędzia z error details

        NIE MOŻE:
        - Wyglądać jak success
        - Ukrywać error za kliknięciem
        """
        pass  # Requires failed ticket in running instance

    async def test_health_alerts_visible_in_overview(self, page, dashboard_url):
        """Overview tab pokazuje aktywne alerty.

        MUSI:
        - Jeśli critical issues > 0 → czerwony alert widoczny
        - Kliknięcie → przejście do diagnostics/observability

        NIE MOŻE:
        - Ignorować critical issues
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1000)
        content = await page.content()
        # Overview should show system status or health info
        overview_keywords = ["overview", "status", "health", "system", "dashboard"]
        assert any(kw in content.lower() for kw in overview_keywords)

    async def test_repair_suggestion_displayed(self, page, dashboard_url):
        """Sugestia naprawy wyświetlona przy failed ticket.

        MUSI (jeśli repair enabled):
        - Przycisk "Auto-repair" lub "Diagnose"
        - Po kliknięciu: diagnosis + suggestion wyświetlone
        - Opcja "Apply fix" (jeśli mode=apply)

        NIE MOŻE:
        - Auto-apply bez potwierdzenia użytkownika (w GUI)
        """
        pass  # Requires repair-enabled instance with failed ticket

    async def test_diagnostics_page_accessible(self, page, dashboard_url):
        """Strona diagnostyki dostępna.

        MUSI:
        - Link/tab do diagnostyki widoczny
        - Strona ładuje się bez błędów
        """
        await page.goto(f"{dashboard_url}/dashboard-ui")
        await page.wait_for_timeout(1000)
        content = await page.content()
        diag_keywords = ["diagnos", "health", "observ", "status"]
        has_diag = any(kw in content.lower() for kw in diag_keywords)
        assert has_diag or "dashboard" in content.lower()
