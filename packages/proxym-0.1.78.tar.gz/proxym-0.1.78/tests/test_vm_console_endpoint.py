from __future__ import annotations


def test_vm_console_endpoint_missing_vm_returns_404(authed_client):
    r = authed_client.get("/api/v1/vms/does-not-exist/console")
    assert r.status_code == 404
