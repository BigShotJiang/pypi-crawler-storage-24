"""Tests for the MCP self-server endpoints."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def client():
    """Test client with only the self-MCP router mounted."""
    from fastapi import FastAPI
    from proxym.mcp.self_server import router

    app = FastAPI()
    app.include_router(router)
    return TestClient(app)


class TestSelfMCPEndpoints:
    """Smoke tests for self-MCP tool endpoints."""

    def test_vm_list_returns_json(self, client: TestClient):
        r = client.post("/mcp/self/tools/vm_list")
        assert r.status_code == 200
        data = r.json()
        assert "vms" in data or "error" in data

    def test_status_returns_json(self, client: TestClient):
        r = client.post("/mcp/self/tools/status")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, dict)

    def test_models_returns_json(self, client: TestClient):
        r = client.post("/mcp/self/tools/models")
        assert r.status_code == 200
        data = r.json()
        assert "models" in data or "error" in data

    def test_logs_returns_json(self, client: TestClient):
        r = client.post("/mcp/self/tools/logs")
        assert r.status_code == 200
        data = r.json()
        assert "logs" in data or "error" in data

    def test_account_list_returns_json(self, client: TestClient):
        r = client.post("/mcp/self/tools/account_list")
        assert r.status_code == 200
        data = r.json()
        assert "accounts" in data or "error" in data


class TestToolSchema:
    """Verify TOOL_SCHEMA structure for LLM tool calling."""

    def test_schema_is_list(self):
        from proxym.mcp.self_server import TOOL_SCHEMA
        assert isinstance(TOOL_SCHEMA, list)
        assert len(TOOL_SCHEMA) > 0

    def test_each_tool_has_required_fields(self):
        from proxym.mcp.self_server import TOOL_SCHEMA
        for tool in TOOL_SCHEMA:
            assert tool["type"] == "function"
            func = tool["function"]
            assert "name" in func
            assert "description" in func
            assert "parameters" in func

    def test_vm_create_has_required_params(self):
        from proxym.mcp.self_server import TOOL_SCHEMA
        vm_create = next(t for t in TOOL_SCHEMA if t["function"]["name"] == "vm_create")
        params = vm_create["function"]["parameters"]
        assert "tool" in params["properties"]
        assert "project" in params["properties"]
        assert "tool" in params["required"]
        assert "project" in params["required"]
