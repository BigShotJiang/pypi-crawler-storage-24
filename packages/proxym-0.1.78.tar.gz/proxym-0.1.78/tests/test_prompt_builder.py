"""Tests for prompt_builder — generating tool prompts from tickets."""

import pytest

from proxym.dashboard.tickets import Ticket, TicketType, TicketPriority, TicketStatus
from proxym.tools import ToolDefinition, ToolCategory, ToolCapability
from proxym.tools.prompt_builder import build_prompt, build_prompt_dict


@pytest.fixture
def sample_ticket():
    return Ticket(
        id="TKT-TEST01",
        title="Fix login redirect bug",
        description="Users are redirected to /home instead of /dashboard after login.",
        type=TicketType.BUG,
        priority=TicketPriority.HIGH,
        tags=["auth", "frontend"],
        files=["src/auth/login.py", "src/routes.py"],
        estimated_hours=2.0,
    )


@pytest.fixture
def aider_tool():
    return ToolDefinition(
        name="aider",
        category=ToolCategory.AGENT_CLI,
        binary="aider",
        capabilities=[ToolCapability.CODE_EDIT, ToolCapability.REFACTOR],
        modes=["code", "architect", "ask"],
        default_model="smart",
    )


@pytest.fixture
def claude_tool():
    return ToolDefinition(
        name="claude-code",
        category=ToolCategory.AGENT_CLI,
        binary="claude",
        capabilities=[ToolCapability.CODE_EDIT, ToolCapability.DEBUG],
        modes=["code", "architect", "debug", "ask"],
        default_model="smart",
    )


class TestBuildPrompt:
    def test_contains_ticket_id_and_title(self, sample_ticket, aider_tool):
        prompt = build_prompt(sample_ticket, aider_tool)
        assert "TKT-TEST01" in prompt
        assert "Fix login redirect bug" in prompt

    def test_contains_description(self, sample_ticket, aider_tool):
        prompt = build_prompt(sample_ticket, aider_tool)
        assert "redirected to /home" in prompt

    def test_contains_files(self, sample_ticket, aider_tool):
        prompt = build_prompt(sample_ticket, aider_tool)
        assert "src/auth/login.py" in prompt
        assert "src/routes.py" in prompt

    def test_contains_tags(self, sample_ticket, aider_tool):
        prompt = build_prompt(sample_ticket, aider_tool)
        assert "auth" in prompt
        assert "frontend" in prompt

    def test_bug_type_instructions(self, sample_ticket, aider_tool):
        prompt = build_prompt(sample_ticket, aider_tool)
        assert "root cause" in prompt.lower()
        assert "regression test" in prompt.lower()

    def test_feature_type_instructions(self, aider_tool):
        ticket = Ticket(id="TKT-FEAT", title="Add export CSV", type=TicketType.FEATURE)
        prompt = build_prompt(ticket, aider_tool)
        assert "implement the feature" in prompt.lower()

    def test_refactor_type_instructions(self, aider_tool):
        ticket = Ticket(id="TKT-REF", title="Extract helper", type=TicketType.REFACTOR)
        prompt = build_prompt(ticket, aider_tool)
        assert "without changing behavior" in prompt.lower()

    def test_aider_architect_mode(self, sample_ticket, aider_tool):
        prompt = build_prompt(sample_ticket, aider_tool, mode="architect")
        assert "architect" in prompt.lower()

    def test_claude_debug_mode(self, sample_ticket, claude_tool):
        prompt = build_prompt(sample_ticket, claude_tool, mode="debug")
        assert "debug" in prompt.lower()

    def test_high_priority_constraint(self, sample_ticket, aider_tool):
        prompt = build_prompt(sample_ticket, aider_tool)
        assert "high priority" in prompt.lower()

    def test_critical_priority_constraint(self, aider_tool):
        ticket = Ticket(id="TKT-CRIT", title="Crash", priority=TicketPriority.CRITICAL)
        prompt = build_prompt(ticket, aider_tool)
        assert "critical" in prompt.lower()

    def test_time_budget_constraint(self, sample_ticket, aider_tool):
        prompt = build_prompt(sample_ticket, aider_tool)
        assert "2.0h" in prompt

    def test_no_description_no_crash(self, aider_tool):
        ticket = Ticket(id="TKT-BARE", title="Bare ticket")
        prompt = build_prompt(ticket, aider_tool)
        assert "TKT-BARE" in prompt


class TestBuildPromptDict:
    def test_structure(self, sample_ticket, aider_tool):
        d = build_prompt_dict(sample_ticket, aider_tool, mode="code")
        assert d["ticket_id"] == "TKT-TEST01"
        assert d["tool"] == "aider"
        assert d["mode"] == "code"
        assert d["model"] == "smart"
        assert isinstance(d["prompt"], str)
        assert d["files"] == ["src/auth/login.py", "src/routes.py"]
        assert d["tags"] == ["auth", "frontend"]

    def test_default_mode_from_tool(self, sample_ticket, aider_tool):
        d = build_prompt_dict(sample_ticket, aider_tool)
        assert d["mode"] == "code"  # first mode in aider.modes
