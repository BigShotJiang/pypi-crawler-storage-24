"""Tests for proxym.cli.vscode — VS Code Web CLI commands."""

from __future__ import annotations

import subprocess
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from proxym.cli.vscode import (
    _find_compose_dir,
    cmd_vscode_build,
    cmd_vscode_logs,
    cmd_vscode_open,
    cmd_vscode_start,
    cmd_vscode_status,
    cmd_vscode_stop,
)


@pytest.fixture
def args():
    return SimpleNamespace()


class TestFindComposeDir:
    def test_finds_project_root(self):
        """Should find the directory containing docker-compose.yml."""
        result = _find_compose_dir()
        assert result != "."  # Should find the actual project root
        import os
        assert os.path.isfile(os.path.join(result, "docker-compose.yml"))


class TestVscodeStart:
    @patch("proxym.cli.vscode.subprocess.run")
    def test_start_success(self, mock_run, args, capsys):
        mock_run.return_value = MagicMock(returncode=0)
        cmd_vscode_start(args)
        captured = capsys.readouterr()
        assert "Starting VS Code Web" in captured.out
        assert "http://localhost:8080" in captured.out
        mock_run.assert_called_once()
        call_args = mock_run.call_args[0][0]
        assert "docker" in call_args
        assert "vscode" in call_args

    @patch("proxym.cli.vscode.subprocess.run")
    def test_start_failure(self, mock_run, args):
        mock_run.return_value = MagicMock(returncode=1)
        with pytest.raises(SystemExit) as exc_info:
            cmd_vscode_start(args)
        assert exc_info.value.code == 1


class TestVscodeStop:
    @patch("proxym.cli.vscode.subprocess.run")
    def test_stop_success(self, mock_run, args, capsys):
        mock_run.return_value = MagicMock(returncode=0)
        cmd_vscode_stop(args)
        captured = capsys.readouterr()
        assert "VS Code Web stopped" in captured.out

    @patch("proxym.cli.vscode.subprocess.run")
    def test_stop_failure(self, mock_run, args):
        mock_run.return_value = MagicMock(returncode=1)
        with pytest.raises(SystemExit):
            cmd_vscode_stop(args)


class TestVscodeOpen:
    @patch("proxym.cli.vscode.webbrowser.open")
    def test_open_calls_webbrowser(self, mock_open, args, capsys):
        cmd_vscode_open(args)
        captured = capsys.readouterr()
        assert "http://localhost:8080" in captured.out
        mock_open.assert_called_once_with("http://localhost:8080")


class TestVscodeLogs:
    @patch("proxym.cli.vscode.subprocess.run")
    def test_logs_runs_compose(self, mock_run, args):
        mock_run.return_value = MagicMock(returncode=0)
        cmd_vscode_logs(args)
        call_args = mock_run.call_args[0][0]
        assert "logs" in call_args
        assert "vscode" in call_args


class TestVscodeStatus:
    @patch("proxym.cli.vscode.subprocess.run")
    def test_status_runs_compose_ps(self, mock_run, args):
        mock_run.return_value = MagicMock(returncode=0)
        cmd_vscode_status(args)
        call_args = mock_run.call_args[0][0]
        assert "ps" in call_args
        assert "vscode" in call_args


class TestVscodeBuild:
    @patch("proxym.cli.vscode.subprocess.run")
    def test_build_success(self, mock_run, args, capsys):
        mock_run.return_value = MagicMock(returncode=0)
        cmd_vscode_build(args)
        captured = capsys.readouterr()
        assert "VS Code Web image rebuilt" in captured.out
        call_args = mock_run.call_args[0][0]
        assert "build" in call_args
        assert "--no-cache" in call_args

    @patch("proxym.cli.vscode.subprocess.run")
    def test_build_failure(self, mock_run, args):
        mock_run.return_value = MagicMock(returncode=1)
        with pytest.raises(SystemExit):
            cmd_vscode_build(args)
