# Dashboard: Voice + Routing Test + noVNC (MVP)

## Dashboard URL

Open:

- `http://localhost:4000/dashboard/`

## Ports (dev vs prod)

When you run `make dev`, the server binds to `DEV_PORT`, but settings/logging and frontend config may still reference `AI_PROXY_PORT`.

Recommended dev setup in `.env`:

- `DEV_PORT=4001`
- `AI_PROXY_PORT=4001`
- `DASHBOARD_API_URL=http://localhost:4001`
- `DEFAULT_PROXY_URL=http://localhost:4001`

Quick verification:

```bash
.venv/bin/python -c "from proxym.config import get_settings; s=get_settings(); print('dev_port=',s.dev_port,'port=',s.port,'dashboard_api_url=',s.dashboard_api_url,'default_proxy_url=',s.default_proxy_url)"
```

## Voice (Web Speech API)

### Requirements

- Chrome / Chromium / Edge (SpeechRecognition is not available in most Firefox builds)
- Microphone permission granted for the dashboard origin

### How to use

- Open Dashboard
- Go to tab: `Voice`
- Click `Start Listening`
- Speak
- The recognized text will be sent to the proxym chat completions endpoint

### Notes

- STT uses the browser Web Speech API (no server-side Whisper in this dashboard MVP)
- TTS uses the browser SpeechSynthesis

## Routing test endpoint (status-only)

This endpoint does not call external providers. It only returns configuration/routing status.

- `GET http://localhost:4000/api/v1/routing/test`

Example:

```bash
curl -s http://localhost:4000/api/v1/routing/test | jq
```

## noVNC console endpoint (MVP)

### Endpoint

- `GET http://localhost:4000/api/v1/vms/{vm_id}/console`

### What it returns

- `novnc_url` (relative URL to open in browser)
- `websocket_url` (for websockify)
- setup instructions (websockify + noVNC static files)

### Minimal local setup (example)

1. Put noVNC files under `static/novnc/` (repo root at runtime)
2. Run websockify to bridge the VM VNC port (default `5900`) into WebSocket port `6900`

Example:

```bash
pip install websockify

# from repo root:
# git clone https://github.com/novnc/noVNC static/novnc

websockify --web static/novnc 6900 localhost:5900
```

Then open `novnc_url` returned by the endpoint.
