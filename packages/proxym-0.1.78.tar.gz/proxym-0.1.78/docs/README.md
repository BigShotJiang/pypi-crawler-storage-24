<!-- code2docs:start --># proxy

![version](https://img.shields.io/badge/version-0.1.0-blue) ![python](https://img.shields.io/badge/python-%3E%3D3.11-blue) ![coverage](https://img.shields.io/badge/coverage-unknown-lightgrey) ![functions](https://img.shields.io/badge/functions-1850-green)
> **1850** functions | **141** classes | **231** files | CC̄ = 4.5

> Auto-generated project documentation from source code analysis.

**Author:** Tom Sapletta  
**License:** Apache-2.0  
**Repository:** [https://github.com/wronai/proxy](https://github.com/wronai/proxy)

## Installation

### From PyPI

```bash
pip install proxy
```

### From Source

```bash
git clone https://github.com/wronai/proxy
cd proxy
pip install -e .
```

### Optional Extras

```bash
pip install proxy[gpu]    # gpu features
pip install proxy[jetson]    # jetson features
pip install proxy[vm]    # vm features
pip install proxy[voice]    # voice features
pip install proxy[tts]    # tts features
pip install proxy[test]    # testing tools
pip install proxy[dev]    # development tools
```

## Quick Start

### CLI Usage

```bash
# Generate full documentation for your project
proxy ./my-project

# Only regenerate README
proxy ./my-project --readme-only

# Preview what would be generated (no file writes)
proxy ./my-project --dry-run

# Check documentation health
proxy check ./my-project

# Sync — regenerate only changed modules
proxy sync ./my-project
```

### Python API

```python
from proxy import generate_readme, generate_docs, Code2DocsConfig

# Quick: generate README
generate_readme("./my-project")

# Full: generate all documentation
config = Code2DocsConfig(project_name="mylib", verbose=True)
docs = generate_docs("./my-project", config=config)
```

## Generated Output

When you run `proxy`, the following files are produced:

```
<project>/
├── README.md                 # Main project README (auto-generated sections)
├── docs/
│   ├── api.md               # Consolidated API reference
│   ├── modules.md           # Module documentation with metrics
│   ├── architecture.md      # Architecture overview with diagrams
│   ├── dependency-graph.md  # Module dependency graphs
│   ├── coverage.md          # Docstring coverage report
│   ├── getting-started.md   # Getting started guide
│   ├── configuration.md    # Configuration reference
│   └── api-changelog.md    # API change tracking
├── examples/
│   ├── quickstart.py       # Basic usage examples
│   └── advanced_usage.py   # Advanced usage examples
├── CONTRIBUTING.md         # Contribution guidelines
└── mkdocs.yml             # MkDocs site configuration
```

## Configuration

Create `proxy.yaml` in your project root (or run `proxy init`):

```yaml
project:
  name: my-project
  source: ./
  output: ./docs/

readme:
  sections:
    - overview
    - install
    - quickstart
    - api
    - structure
  badges:
    - version
    - python
    - coverage
  sync_markers: true

docs:
  api_reference: true
  module_docs: true
  architecture: true
  changelog: true

examples:
  auto_generate: true
  from_entry_points: true

sync:
  strategy: markers    # markers | full | git-diff
  watch: false
  ignore:
    - "tests/"
    - "__pycache__"
```

## Sync Markers

proxy can update only specific sections of an existing README using HTML comment markers:

```markdown
<!-- proxy:start -->
# Project Title
... auto-generated content ...
<!-- proxy:end -->
```

Content outside the markers is preserved when regenerating. Enable this with `sync_markers: true` in your configuration.

## Architecture

```
proxy/
├── validate_dispatch_table_refactoring├── validate_tool_health_refactoring├── validate_tools_panel_refactoring    ├── seed_sprint8    ├── proxym-voice-chat    ├── validation_common├── utils/    ├── main        ├── quickstart        ├── advanced_usage├── validate_human_task_refactoring├── validate_refactoring    ├── proxym/        ├── ctl├── validate_tasks_panel_refactoring        ├── storage        ├── dashboard/        ├── config            ├── _users_api            ├── _system            ├── _costs            ├── _tickets_api            ├── _shared            ├── _environments_api            ├── _accounts            ├── users            ├── _projects_api        ├── cache/        ├── projects/        ├── middleware/        ├── tools/            ├── browser_profiles            ├── _infra            ├── _enums        ├── virt/            ├── _snapshot            ├── _vm_config            ├── _check            ├── _vms            ├── _project            ├── clonebox_adapter            ├── _config            ├── _orchestrator            ├── _state            ├── system            ├── browser            ├── observability            ├── diagnostics            ├── vms        ├── cli/            ├── context            ├── tickets            ├── executor            ├── _lifecycle            ├── _client            ├── voice            ├── smart_defaults            ├── tts            ├── chat            ├── vscode            ├── dsl            ├── accounts        ├── utils/            ├── get_settings            ├── messages            ├── _helpers            ├── registry        ├── mcp/        ├── providers/            ├── _tools_accounts            ├── client            ├── router            ├── _tools_tickets            ├── self_server            ├── _tools_system            ├── _tools_vm            ├── health_events        ├── observability/        ├── accounts/            ├── detector        ├── context/            ├── repair_agent            ├── watchdog            ├── _context            ├── tool_selector            ├── session            ├── _diag_proxy        ├── router/            ├── _diag_common            ├── voice_actions            ├── _diag_roo            ├── completions            ├── system            ├── observability_api            ├── strategy            ├── vscode_api        ├── api/            ├── _diag_agent            ├── diagnostics            ├── console            ├── _diag_providers            ├── _diag_vscode            ├── _pipeline            ├── _state            ├── context_api            ├── client            ├── frontend                ├── cmd_sessions_list        ├── watch/                ├── tickets_ctl            ├── _groups/                ├── diagnostics_ctl                ├── accounts_ctl                ├── projects_ctl                ├── context_ctl                ├── observability_ctl                ├── tools_ctl                ├── vscode_ctl                ├── _shared                ├── vms_ctl                ├── browser_ctl                ├── detect_chrome_profiles            ├── profiles/                ├── _claude_code                ├── do_ctl                ├── _human                ├── _result            ├── adapters/                ├── _vscode                ├── _llm_fallback                ├── _aider                ├── _base            ├── tickets/                ├── _shell                ├── _models                ├── _helpers                ├── _providers            ├── tools/                ├── TicketManagerRefactored                ├── _queue                ├── _manager                ├── HealthCheckerRefactored                ├── _lifecycle                ├── _registry                ├── _dispatch            ├── utils/                ├── _health                ├── delete_milestone                ├── _delete_item                ├── utils/                ├── delete_ticket                    ├── _aider_install_fix                    ├── delete_ticket                    ├── start_executor            ├── api        ├── proxym_tools                ├── _autofix                ├── formatters    ├── proxym-dashboard            ├── panel                ├── diagnostics                ├── voice                ├── useDashboardData                ├── voice_engine                ├── logs                ├── human                ├── ui                ├── vms                ├── tasks                ├── overview                ├── models                ├── tools                ├── projects                ├── home                ├── voice_schemas                ├── tickets                ├── system                ├── layout                ├── accounts                ├── users                ├── environments                    ├── TicketFilters                    ├── BulkOperations                ├── setup                    ├── TicketStats                    ├── TicketList                    ├── DiagConfig                    ├── TicketsPanelRefactored                    ├── helpers                    ├── DiagInfrastructure                    ├── DiagExtensions                    ├── DiagAgent                    ├── DispatchTableHeader                    ├── DiagnosticActions                    ├── ProjectInfoResolver                    ├── ToolsPanelRefactored                    ├── TicketDispatchTableRefactored                    ├── ToolsJobQueue                    ├── ToolsDispatch                    ├── DispatchTableRow                    ├── TicketStatusBadges                    ├── ProviderConfigPanel                    ├── ToolsRegistry                    ├── ToolHealthCard                    ├── DispatchActions                    ├── BulkAutoFix                    ├── ToolAvailabilityAlert                    ├── ToolHealthDisplay                    ├── TasksBoard                    ├── TasksPanelRefactored                    ├── TasksList                    ├── ToolHealthPanelRefactored                    ├── TasksTable                    ├── TasksViewControls                    ├── HumanTaskBoard                    ├── HumanTaskList                    ├── TasksRecentJobs                    ├── HumanTaskTable                    ├── HumanJobsList                    ├── HumanViewControls                    ├── HumanTaskStats├── project    ├── jetson-entrypoint    ├── setup    ├── evaluate_llm_work    ├── validate_system    ├── proxym-voice-server    ├── check_dashboard        ├── entrypoint                    ├── HumanTaskPanelRefactored        ├── main```

## API Overview

### Classes

- **`SQLiteNamespaceStore`** — —
- **`Settings`** — All settings with sensible defaults. Override via env vars or .env file.
- **`CreateUserRequest`** — —
- **`UpdateUserRequest`** — —
- **`CreateTicketReq`** — —
- **`UpdateTicketReq`** — —
- **`AssignToolReq`** — —
- **`AddCommentReq`** — —
- **`CreateSprintReq`** — —
- **`UpdateSprintReq`** — —
- **`CreateMilestoneReq`** — —
- **`UpdateMilestoneReq`** — —
- **`EnvironmentKind`** — —
- **`Environment`** — —
- **`EnvironmentCreateRequest`** — —
- **`EnvironmentUpdateRequest`** — —
- **`ToolEnvironmentAssignRequest`** — —
- **`EnvironmentRegistry`** — —
- **`CreateAccountReq`** — —
- **`BindToolReq`** — —
- **`UserRole`** — User roles in the system.
- **`User`** — A user in the system, identified by git configuration.
- **`UserManager`** — In-memory user store with SQLite persistence and git integration.
- **`AddProjectReq`** — Dodaj projekt — jedno z: path, git_url, ssh.
- **`UpdateProjectReq`** — —
- **`ScanReq`** — —
- **`FileSnapshot`** — Immutable snapshot of a single file.
- **`DeltaPayload`** — Computed delta between two context snapshots.
- **`DeltaBuffer`** — Maintains file snapshots and computes minimal diffs.
- **`SourceType`** — —
- **`ProjectStatus`** — —
- **`Project`** — Jeden projekt w systemie proxym.
- **`ProjectRegistry`** — Rejestr projektów z persystencją JSON.
- **`AuthMiddleware`** — Simple bearer token auth (matches LiteLLM master_key pattern).
- **`CostTrackingMiddleware`** — Log request timing and attach cost headers to responses.
- **`ToolCategory`** — High-level tool categories.
- **`ToolCapability`** — Capabilities a tool can advertise.
- **`ToolInstance`** — Concrete runtime instance for a registered tool.
- **`ToolDefinition`** — Describes a registered development tool.
- **`ToolRegistry`** — Singleton registry of available development tools.
- **`BrowserProfile`** — Detected browser profile on the host.
- **`AppDataSync`** — Configuration for syncing browser data into a VM.
- **`VMBackend`** — —
- **`VMState`** — —
- **`CreateVMReq`** — —
- **`SwitchProjectReq`** — —
- **`AssignToolReq`** — —
- **`CloneBoxResult`** — Result of a clonebox CLI invocation.
- **`CloneBoxAdapter`** — Adapter wrapping the clonebox CLI for VM operations.
- **`ProjectsConfig`** — Configuration for shared project mounts from the host.
- **`VMConfig`** — Configuration for a development VM.
- **`VMStatus`** — Runtime status of a VM.
- **`VMOrchestrator`** — Manages VMs for isolated dev environments.
- **`JobStatus`** — —
- **`ToolJob`** — A single tool execution job.
- **`ToolExecutor`** — Async executor for tool jobs with a bounded queue.
- **`VoiceListener`** — Local STT: microphone → text via Faster-Whisper.
- **`TTSEngine`** — Text-to-speech engine with pluggable backends.
- **`ParsedCommand`** — Result of successfully parsing a user phrase against the DSL.
- **`DSLParser`** — Parse natural language phrases into proxym API calls.
- **`MCPTransport`** — Transport protocol for MCP communication.
- **`MCPServerSpec`** — Specification of a registered MCP server.
- **`MCPRegistry`** — Registry of available MCP servers.
- **`TaskTier`** — Complexity tier that determines which model class is needed.
- **`Capability`** — —
- **`ModelSpec`** — Immutable specification for a single model deployment.
- **`AccountAddRequest`** — —
- **`MCPToolResult`** — Result of an MCP tool invocation.
- **`MCPClient`** — HTTP client for MCP server communication.
- **`MCPRouter`** — Routes tool requests to appropriate MCP servers.
- **`TicketCreateRequest`** — —
- **`TicketAssignRequest`** — —
- **`SprintCreateRequest`** — —
- **`VMCreateRequest`** — —
- **`VMActionRequest`** — —
- **`VMSnapshotRequest`** — —
- **`VMSwitchRequest`** — —
- **`Severity`** — —
- **`HealthEvent`** — Jedno zdarzenie zdrowia systemu.
- **`HealthEventStore`** — In-memory store zdarzeń z persystencją opcjonalną.
- **`ProviderType`** — —
- **`ToolType`** — —
- **`AccountCredentials`** — Credentials for a single provider account.
- **`UsageMetrics`** — Tracked usage for a single account.
- **`AccountLimits`** — Provider-imposed and user-defined limits.
- **`ToolBinding`** — Binds an account to a specific tool/IDE instance.
- **`Account`** — Single provider account with all associated data.
- **`AccountManager`** — Central account registry.
- **`RepairAgent`** — Agent naprawiający błędy w kodzie proxym za pomocą LLM.
- **`HealthWatchdog`** — Daemon sprawdzający zdrowie systemu w pętli.
- **`ProjectContext`** — Detected project context for a request.
- **`AgentSession`** — Stateful session for an agent working on a project.
- **`SessionStore`** — In-memory session store with TTL-based expiry.
- **`AnalysisResult`** — Result of content analysis.
- **`RepairRequest`** — —
- **`RoutingDecision`** — Complete routing decision with audit trail.
- **`CostLedger`** — In-memory cost ledger with Redis persistence.
- **`Router`** — Stateful router that selects the optimal model per request.
- **`CompletionPipeline`** — Structured pipeline for processing a chat completion request.
- **`DeltaWatchClient`** — Watches a directory and pushes context deltas to the proxy server.
- **`ClaudeCodeAdapter`** — Adapter for claude CLI (Anthropic Claude Code).
- **`HumanAdapter`** — Adapter for human/manual tasks — returns a result indicating manual action required.
- **`ToolResult`** — Result of a tool execution.
- **`VSCodeAdapter`** — Adapter for VS Code Web / code-server (starts container, sends task via API).
- **`AiderAdapter`** — Adapter for aider CLI.
- **`BaseAdapter`** — Base class for tool adapters.
- **`ShellAdapter`** — Generic shell adapter — runs tool binary with prompt via stdin/args.
- **`TicketStatus`** — —
- **`TicketPriority`** — —
- **`TicketType`** — —
- **`SprintStatus`** — —
- **`MilestoneStatus`** — —
- **`ToolAssignment`** — Which tool is assigned to work on a ticket.
- **`JobExecution`** — Snapshot of the latest job execution for a ticket.
- **`TicketComment`** — —
- **`Milestone`** — —
- **`Ticket`** — —
- **`Sprint`** — —
- **`ToolProviderRequest`** — —
- **`TicketFilter`** — Extracted filtering logic from TicketManager.
- **`TicketValidator`** — Extracted validation logic for ticket operations.
- **`TicketPersistence`** — Extracted persistence logic.
- **`TicketManagerRefactored`** — Refactored ticket & sprint store with separated concerns.
- **`TicketManager`** — In-memory ticket & sprint store with optional JSON persistence.
- **`HealthCheck`** — Base class for specific health checks.
- **`BinaryHealthCheck`** — Check if tool binary is available on PATH.
- **`InstanceHealthCheck`** — Check tool instances (Docker, KVM, VM).
- **`ProviderHealthCheck`** — Check provider configuration and API keys.
- **`HumanToolHealthCheck`** — Special health check for human tool category.
- **`HealthStatusCalculator`** — Calculate overall health status from diagnostics.
- **`HealthCheckerRefactored`** — Main health checker that orchestrates specific checks.
- **`DispatchRequest`** — —
- **`PreviewPromptRequest`** — —
- **`ProxymTools`** — Tools for managing proxym AI proxy from Open WebUI.
- **`AutoFixRequest`** — —

### Functions

- `main()` — Validate TicketDispatchTable refactoring.
- `main()` — Validate ToolHealth refactoring.
- `main()` — Validate ToolsPanel refactoring.
- `main()` — —
- `check_voice_deps()` — Sprawdź czy zależności głosowe są zainstalowane.
- `install_voice_deps()` — Zainstaluj zależności głosowe.
- `main()` — —
- `validate_jsx_component(file_path, expected_exports)` — Validate that a JSX component exists and has expected exports.
- `count_complexity(file_path)` — Count lines and estimate complexity of a Python file.
- `print_validation_header(title)` — Print standard validation header.
- `print_component_validation(components, base_path)` — Print validation results for a list of components.
- `print_complexity_analysis(files, base_path)` — Print complexity analysis for a list of files.
- `print_class_validation(file_path, expected_classes)` — Print validation results for expected classes in a file.
- `print_summary_footer()` — Print standard validation footer.
- `run_validation(title, components, base_path, original_file)` — Common validation runner for all refactoring scripts.
- `run_validation_main(title, components, base_path, original_file)` — Generic main() for validation scripts.
- `create_validation_main(title, components, base_path, original_file)` — Create a main validation function for refactoring scripts.
- `main()` — Validate HumanTaskPanel refactoring.
- `main()` — Validate main refactoring.
- `cli(ctx, proxy, key, fmt)` — Proxym — intelligent AI proxy with VM isolation.
- `serve(host, port, reload)` — Start the proxy server.
- `status(ctx, fmt)` — Show system status.
- `models(ctx, fmt)` — List available models.
- `chat(ctx, voice, tts)` — Interactive chat — DSL first, LLM fallback.
- `logs_cmd(ctx, lines, level)` — Show proxy logs.
- `providers_cmd(ctx)` — List configured providers and their status.
- `routing_test_cmd(ctx)` — Dry-run routing test — check which model would be selected.
- `projects_cmd(ctx)` — List available projects (shortcut for 'project list').
- `fix_cmd(ctx, description, project_name)` — Shortcut: fix a bug.  = proxym do "..." --type bug
- `refactor_cmd(ctx, description, project_name)` — Shortcut: refactor code.  = proxym do "..." --type refactor --with claude-code
- `queue_shortcut(ctx)` — Shortcut: show task queue.  = proxym tools queue
- `web_cmd(ctx, tab)` — Open dashboard in browser.  proxym web [home|projects|tasks|system|voice]
- `log_shortcut(ctx, lines)` — Shortcut: show recent logs.  = proxym logs -n 20
- `main()` — Validate TasksPanel refactoring.
- `is_sqlite_database(path)` — —
- `get_settings()` — —
- `list_users(active_only)` — List all users.
- `create_user(req)` — Create a new user.
- `sync_git_users(repo_path)` — Sync users from git commit history.
- `get_default_user()` — Get the default/delegated user.
- `set_default_user(user_id)` — Set a user as the default/delegated user.
- `get_user(user_id)` — Get a specific user.
- `update_user(user_id, req)` — Update a user.
- `delete_user(user_id)` — Delete a user.
- `dashboard_root()` — Dashboard root - redirects to system status.
- `system_status()` — Full system overview: accounts + VMs + costs + libvirt + providers + watchdog + repair.
- `list_providers()` — Show configured providers from .env and their model counts.
- `get_logs(lines, level)` — Get recent log entries from proxym log file.
- `cost_summary()` — Aggregate cost dashboard across all accounts.
- `cost_detailed()` — Per-account cost breakdown.
- `list_tools()` — Return available VM tool profiles (host/browser environments).
- `list_tickets(sprint_id, milestone_id, status, priority)` — List tickets with optional filters.
- `export_tickets(sprint_id, milestone_id, status, priority)` — Export ticket data for grouped dashboard views.
- `create_ticket(task, title, project_id, description)` — Create a new ticket. Accepts 'task' (new) or 'title' (legacy).
- `ticket_board(sprint_id, milestone_id)` — Kanban board view: tickets grouped by status columns.
- `get_ticket(ticket_id)` — Get ticket details including comments.
- `update_ticket(ticket_id, task, title, project_id)` — Update a ticket's fields.
- `delete_ticket(ticket_id)` — Delete a ticket.
- `assign_ticket_tool(ticket_id, tool, agent_mode, model)` — Assign a tool (vscode, aider, claude-code, etc.) to work on a ticket.
- `add_ticket_comment(ticket_id, author, content)` — Add a comment to a ticket (from any tool or user).
- `list_sprints(status, milestone_id)` — List sprints.
- `create_sprint(req)` — Create a new sprint.
- `get_sprint(sprint_id)` — Get sprint details with ticket stats.
- `update_sprint(sprint_id, req)` — Update sprint fields.
- `delete_sprint(sprint_id)` — Delete a sprint.
- `list_milestones(status)` — List milestones.
- `create_milestone(req)` — Create a new milestone.
- `get_milestone(milestone_id)` — Get milestone details with ticket stats.
- `update_milestone(milestone_id, req)` — Update milestone fields.
- `delete_milestone(milestone_id)` — Delete a milestone.
- `shared_accounts()` — Return the singleton AccountManager.
- `shared_vms()` — Return the singleton VMOrchestrator.
- `get_environment_registry()` — —
- `get_tool_environment_snapshot(tool_name)` — —
- `list_environments()` — —
- `list_environment_assignments()` — —
- `get_environment(environment_id)` — —
- `create_environment(req)` — —
- `update_environment(environment_id, req)` — —
- `delete_environment(environment_id)` — —
- `assign_tool_to_environment(req)` — —
- `list_accounts(provider, tag)` — —
- `create_account(req)` — —
- `get_account(account_id)` — —
- `delete_account(account_id)` — —
- `bind_tool(account_id, req)` — —
- `list_projects(status, source_type)` — Lista wszystkich projektów z informacją o przypisanych obiektach.
- `get_project(project_id)` — —
- `add_project(req)` — Dodaj projekt — po nazwie lub z pełną konfiguracją.
- `update_project(project_id, req)` — —
- `remove_project(project_id)` — —
- `scan_directory(req)` — Skanuj folder i dodaj znalezione projekty.
- `project_tickets(project_id)` — Tickety powiązane z projektem (match by id or name).
- `create_project_ticket(project_id, req)` — Stwórz ticket od razu powiązany z projektem.
- `detect_firefox_profiles()` — Detect Firefox profiles by parsing profiles.ini.
- `detect_all_profiles()` — Detect all browser profiles on the host.
- `detect_chrome_profiles()` — Detect Chrome browser profiles.
- `detect_chromium_profiles()` — Detect Chromium browser profiles.
- `generate_app_data_sync(profile, with_passwords)` — Generate an AppDataSync config for copying a profile into a VM.
- `list_vms()` — —
- `create_vm(req)` — —
- `start_vm(vm_id)` — —
- `stop_vm(vm_id, force)` — —
- `pause_vm(vm_id)` — —
- `resume_vm(vm_id)` — —
- `snapshot_vm(vm_id, name)` — —
- `switch_project(vm_id, req)` — —
- `delete_vm(vm_id)` — —
- `delete_vm_post(vm_id)` — POST variant for single VM deletion (matches frontend convention).
- `bulk_delete_vms(req)` — Delete multiple VMs by their IDs. Returns list of successfully deleted VM IDs.
- `assign_tool_to_vm(vm_id, req)` — Assign a tool to a VM. Also creates/updates a vm_local environment for this VM.
- `cmd_serve(args)` — Start the proxy server (delegates to proxym.main:cli).
- `cmd_status(args)` — Show system status (YAML or human-readable).
- `cmd_models(args)` — —
- `cmd_browser_list(args)` — List detected browser profiles on the host.
- `cmd_browser_assign(args)` — Assign a browser profile to an account.
- `cmd_browser_sync(args)` — Sync browser profile host ↔ VM.
- `cmd_browser_snapshot(args)` — Save browser state from VM as snapshot.
- `cmd_obs_errors(args)` — —
- `cmd_obs_health(args)` — —
- `cmd_obs_repair(args)` — —
- `cmd_obs_logs(args)` — —
- `cmd_tests_status(args)` — Run all diagnostic tests and show results.
- `cmd_test_vscode(args)` — Test VS Code Web connectivity.
- `cmd_test_proxy(args)` — Test LLM proxy connectivity.
- `cmd_test_providers(args)` — Check configured LLM providers.
- `cmd_test_extensions(args)` — Check installed VS Code extensions.
- `cmd_test_agent_setup(args)` — Comprehensive agent readiness check.
- `cmd_test_agent(args)` — Test agent with a simple completion.
- `cmd_vm_list(args)` — —
- `cmd_vm_create(args)` — —
- `cmd_vm_action(args)` — —
- `cmd_vm_switch(args)` — —
- `cmd_vm_open(args)` — Open SPICE viewer for a VM (virt-viewer).
- `cmd_vm_ssh(args)` — SSH into a VM (auto-detect IP via dashboard).
- `cmd_vm_logs(args)` — Show cloud-init logs and tool logs from a VM.
- `cmd_vm_delete(args)` — Delete a VM.
- `cmd_vm_console(args)` — Open web console for a VM (prints noVNC URL).
- `cmd_vm_bulk_delete(args)` — Delete multiple VMs.
- `cmd_context_delta(args)` — Push a context delta to the proxy.
- `cmd_context_detect(args)` — Detect project context from messages or paths.
- `cmd_context_stats(args)` — Show context store statistics.
- `cmd_sessions_list(args)` — List active agent sessions.
- `cmd_mcp_servers(args)` — List registered MCP servers.
- `cmd_ticket_list(args)` — List tickets with optional filters.
- `cmd_ticket_create(args)` — Create a new ticket.
- `cmd_ticket_show(args)` — Show ticket details.
- `cmd_ticket_update(args)` — Update a ticket.
- `cmd_ticket_assign(args)` — Assign a tool to a ticket.
- `cmd_ticket_comment(args)` — Add a comment to a ticket.
- `cmd_ticket_delete(args)` — Delete a ticket.
- `cmd_sprint_list(args)` — List sprints.
- `cmd_sprint_create(args)` — Create a new sprint.
- `cmd_sprint_show(args)` — Show sprint details.
- `cmd_sprint_update(args)` — Update a sprint.
- `cmd_sprint_delete(args)` — Delete a sprint.
- `cmd_board(args)` — Show kanban board.
- `make_client(base, key)` — Create HTTP client with configuration from settings.
- `print_json(data)` — —
- `print_json_if_yaml(args, data)` — Print JSON output and return True when the CLI requested YAML output.
- `print_table(rows, columns, widths)` — —
- `detect_ticket_type(task)` — Guess ticket type from natural-language task description.
- `default_priority(ticket_type)` — Return sensible default priority for a ticket type.
- `resolve_tool(ticket_type, project, explicit)` — Pick the best tool: explicit > project default > type hint.
- `resolve_project(projects, explicit)` — Find project: explicit name/id → CWD match → single → most recent.
- `cmd_chat(args)` — Interactive chat with proxym — DSL first, LLM fallback.
- `cmd_vscode_start(args)` — Start VS Code Web (docker compose --profile vscode up -d).
- `cmd_vscode_stop(args)` — Stop VS Code Web.
- `cmd_vscode_open(args)` — Open VS Code Web in the default browser.
- `cmd_vscode_logs(args)` — Show VS Code Web logs (follows).
- `cmd_vscode_status(args)` — Show VS Code Web container status.
- `cmd_vscode_build(args)` — Rebuild VS Code Web image.
- `cmd_accounts_list(args)` — —
- `cmd_accounts_add(args)` — —
- `cmd_accounts_costs(args)` — —
- `cmd_accounts_get(args)` — —
- `cmd_accounts_delete(args)` — —
- `cmd_accounts_bind_tool(args)` — —
- `get_singleton(instance_var, instance_class)` — Generic singleton getter with lazy initialization.
- `extract_system_text(messages)` — Extract the first system message's text content.
- `models_for_tier(tier, required_caps, available_providers)` — Return models suitable for a tier, sorted by effective cost ascending.
- `cheapest_model(tier, available_providers, required_caps)` — Return the single cheapest model that satisfies constraints.
- `get_model(model_id)` — —
- `tool_account_list()` — List all accounts with costs.
- `tool_account_costs()` — Cost summary per account and model.
- `tool_account_add(req)` — Add a new API account.
- `tool_ticket_list(sprint_id, status, tool)` — List tickets, optionally filtered by sprint, status, or assigned tool.
- `tool_ticket_create(req)` — Create a new ticket in the task management system.
- `tool_ticket_assign(req)` — Assign a development tool to work on a ticket.
- `tool_ticket_board(sprint_id)` — Get kanban board view of tickets grouped by status.
- `tool_sprint_create(req)` — Create a new sprint.
- `tool_status()` — Full system status: proxy, VMs, accounts, costs.
- `tool_logs(lines, level)` — Recent proxym logs.
- `tool_models()` — List available models with prices.
- `tool_vm_list()` — List all VMs with their status.
- `tool_vm_create(req)` — Create a new VM with an AI tool.
- `tool_vm_start(req)` — Start a stopped VM.
- `tool_vm_stop(req)` — Stop a running VM.
- `tool_vm_snapshot(req)` — Create a VM snapshot.
- `tool_vm_switch_project(req)` — Switch project in a running VM.
- `get_health_store()` — —
- `get_log_buffer(limit, level)` — Pobierz ostatnie logi z bufora.
- `get_error_summary()` — Podsumowanie błędów z ostatnich logów.
- `log_call()` — Dekorator logujący wywołanie, czas i błędy.
- `log_endpoint()` — Dekorator dla FastAPI endpointów — loguje request/response + timing.
- `retry_with_log(max_retries, backoff_base, retryable)` — Retry z exponential backoff i logowaniem każdej próby.
- `detect_project(messages, headers)` — Detect project context from request data.
- `select_tools(context, analysis, available_servers)` — Select MCP servers for a given project and task analysis.
- `check_llm_proxy(base_url)` — Check LLM proxy connectivity and available models.
- `analyze_request(messages)` — Analyze a chat completion request and return routing metadata.
- `vms_list()` — List VMs (alias for GET /dashboard/vms).
- `vms_start(vm_id)` — Start VM (alias for POST /dashboard/vms/{vm_id}/start).
- `vms_stop(vm_id, force)` — Stop VM (alias for POST /dashboard/vms/{vm_id}/stop).
- `vms_snapshot(vm_id, name)` — Snapshot VM (alias for POST /dashboard/vms/{vm_id}/snapshot).
- `accounts_list(provider, tag)` — List accounts (alias for GET /dashboard/accounts).
- `dashboard_costs_summary()` — Cost summary used by voice UI.
- `logs_list(lines, level)` — Recent logs (alias for GET /dashboard/logs).
- `voice_tickets(status)` — List tickets — voice-friendly summary.
- `voice_diagnose()` — Run diagnostics — voice-friendly summary.
- `check_roo_cline_config()` — Check if Roo Code is configured in VS Code settings.
- `completion()` — —
- `chat_completions(request, x_task_tier)` — OpenAI-compatible chat completions with intelligent routing.
- `get_cost_ledger()` — —
- `favicon()` — Return empty favicon to prevent 401 errors.
- `health(request, authorization, x_api_key)` — Health check with optional VM identification.
- `list_models()` — List available models (OpenAI-compatible) including model aliases.
- `budget_status()` — Return current budget usage.
- `obs_logs(limit, level)` — Ring buffer logs — ostatnie N wpisów z dekoratorów.
- `obs_errors()` — Podsumowanie błędów z ring buffer.
- `obs_health_events(limit, severity)` — Historia zdarzeń zdrowia systemu.
- `obs_health_summary()` — Aktywne problemy i podsumowanie.
- `obs_repair(req)` — Uruchom LLM repair agent na wskazanym błędzie.
- `obs_repair_from_logs()` — Auto-diagnozuj najczęstszy błąd z ring buffer.
- `obs_repair_history(limit)` — Historia napraw wykonanych przez repair agent.
- `vscode_status()` — —
- `vscode_start()` — —
- `vscode_stop()` — —
- `vscode_restart()` — —
- `vscode_logs(lines)` — —
- `vscode_build()` — —
- `check_copilot_conflict()` — Detect GitHub Copilot / Copilot Chat extension conflicts.
- `check_agent_setup(base_url)` — Comprehensive agent readiness check — config + connectivity + extension.
- `test_agent_completion()` — Test a simple completion through the proxy to verify agent functionality.
- `run_all_tests(request)` — Run all diagnostic tests and return comprehensive status.
- `test_vscode()` — Test VS Code Web connectivity.
- `test_proxy(request)` — Test LLM proxy connectivity.
- `test_roo()` — Test Roo Code configuration.
- `test_extensions()` — Check installed VS Code extensions.
- `test_providers()` — Check configured LLM providers and model aliases.
- `test_copilot()` — Detect GitHub Copilot extension conflicts.
- `test_agent_setup(request)` — Comprehensive agent readiness check.
- `test_agent()` — Test agent with a simple completion.
- `routing_test()` — Return routing status (no network calls).
- `ollama_status()` — Check Ollama connectivity and list available local models.
- `vm_console(vm_id)` — Return noVNC connection URL for a running VM.
- `check_providers_config()` — Check which LLM providers are configured with API keys.
- `check_vscode_status()` — Check if VS Code Web is running and accessible.
- `check_extensions()` — Check installed VS Code extensions via docker exec.
- `get_router()` — —
- `get_delta_buffer()` — —
- `get_mcp_router()` — —
- `get_session_store()` — —
- `get_context_payload()` — —
- `set_context_payload(payload)` — —
- `get_context_store()` — —
- `get_mcp_registry()` — —
- `receive_delta(request)` — Receive context delta from the file watcher client.
- `detect_context(request)` — Detect project context from request body (messages + headers).
- `list_sessions()` — List active agent sessions.
- `list_mcp_servers()` — List registered MCP servers.
- `context_stats()` — Return context store statistics.
- `root_redirect()` — Redirect root to dashboard.
- `dashboard_ui()` — Serve the React dashboard UI.
- `dashboard_diagnostics_jsx()` — Serve DiagnosticsPanel for testing VS Code, proxy, and agent.
- `dashboard_jsx()` — Serve the React dashboard JSX entry point.
- `get_frontend_config(request)` — Return configuration for frontend.
- `cmd_list_items(args, endpoint, item_name, columns)` — Generic command to list items from an API endpoint.
- `cmd_sessions_list(args)` — List active agent sessions.
- `cmd_mcp_servers(args)` — List registered MCP servers.
- `cli()` — CLI entry point for proxym-client.
- `ticket()` — Manage tickets (task tracking for multi-tool workflows).
- `ticket_list(ctx, status, tool, sprint)` — List tickets.
- `ticket_add(ctx, task, project, tool)` — Create a ticket (minimalistic). Example: proxym ticket add 'fix the router bug'
- `ticket_create(ctx, title, description, type)` — Create a new ticket (legacy — prefer 'ticket add').
- `ticket_update(ctx, ticket_id, title, status)` — Update a ticket.
- `ticket_assign(ctx, ticket_id, tool, mode)` — Assign a tool to work on a ticket.
- `ticket_comment(ctx, ticket_id, author, content)` — Add a comment to a ticket.
- `ticket_board(ctx, sprint)` — Show kanban board view.
- `sprint()` — Manage sprints.
- `sprint_list(ctx, status)` — List sprints.
- `sprint_create(ctx, name, goal, start)` — Create a new sprint.
- `sprint_update(ctx, sprint_id, name, status)` — Update a sprint.
- `sprint_board(ctx, sprint)` — Show kanban board view.
- `tests()` — Run system diagnostics.
- `diagnose()` — Run diagnostics to verify system health (alias for 'tests').
- `diagnose_one(ctx, test_name)` — Run a specific test (vscode|proxy|roo|extensions|providers|copilot|agent-setup|agent).
- `accounts()` — Manage accounts.
- `accounts_list(ctx)` — List accounts.
- `accounts_add(ctx, name, provider, api_key)` — Add account.
- `accounts_costs(ctx)` — Show cost breakdown.
- `accounts_get(ctx, account_id)` — Show single account details.
- `accounts_delete(ctx, account_id)` — Delete an account.
- `accounts_bind_tool(ctx, account_id, tool_type, tool_name)` — Bind a tool to an account.
- `project()` — Manage projects (local, git, SSH, FTP).
- `project_list(ctx, source_type, status)` — List registered projects.
- `project_add(ctx, path_or_url, git, ssh)` — Add a project. Accepts local path, --git URL, or --ssh user@host:/path.
- `project_scan(ctx, directory)` — Scan a directory for projects and register them.
- `project_show(ctx, project_id)` — Show project details.
- `project_remove(ctx, project_id)` — Remove a project from the registry.
- `project_task(ctx, project_name, task_text, tool)` — Create a ticket for a project (shortcut for 'ticket add --project').
- `context()` — Manage context, sessions, and MCP servers.
- `context_delta(ctx, project_id, diff_text, file)` — Push a context delta to the proxy.
- `context_detect(ctx, message, system_prompt, paths)` — Detect project context from messages or paths.
- `obs()` — Observability: logs, errors, health, repair.
- `obs_errors(ctx)` — Show error summary from ring buffer.
- `obs_health(ctx)` — Show health summary and active issues.
- `obs_logs(ctx, limit, level)` — Show recent observability logs from ring buffer.
- `obs_repair(ctx, error, mode, from_logs)` — Run LLM repair agent on an error.
- `tools()` — Manage AI development tools and job queue.
- `tools_list(ctx, category, available)` — List registered tools.
- `tools_dispatch(ctx, ticket, tool, mode)` — Dispatch a tool to work on a ticket.
- `tools_queue(ctx)` — Show job queue status.
- `tools_jobs(ctx, status, limit)` — List jobs.
- `tools_set_model(ctx, tool_name, model)` — Set the default LLM model for a tool.
- `vscode()` — Manage VS Code Web service.
- `make_args(ctx)` — Convert Click context to SimpleNamespace for legacy CLI handlers.
- `passthrough(name, handler, help_text)` — Click command: make_args(ctx) → handler(args).
- `passthrough_fmt(name, handler, help_text)` — Click command with --format option: make_args(ctx, format=fmt) → handler(args).
- `passthrough_arg(name, handler, help_text, arg_name)` — Click command with argument: make_args(ctx, arg=val, **fixed) → handler(args).
- `api_json_cmd(name, method, path, help_text)` — Click command: call API endpoint, print JSON.
- `register_commands()` — Register a batch of Click commands built from spec tuples.
- `api_json_arg_cmd(name, method, path_tpl, help_text)` — Click command with argument: call API endpoint with path arg, print JSON.
- `vm()` — Manage VMs.
- `vm_create(ctx, name, tool, account)` — Create VM.
- `vm_stop(ctx, vm_id, force)` — Stop a VM.
- `vm_snapshot(ctx, vm_id, name)` — Snapshot a VM.
- `vm_switch(ctx, vm_id, project)` — Switch project in VM.
- `vm_ssh(ctx, vm_id, user)` — SSH into VM.
- `vm_bulk_delete(ctx, vm_ids)` — Delete multiple VMs.
- `browser()` — Manage browser profiles.
- `browser_assign(ctx, profile, account)` — Assign profile to account.
- `detect_chrome_profiles()` — Detect Google Chrome profiles by parsing Local State.
- `detect_chromium_profiles()` — Detect Chromium profiles by parsing Local State.
- `get_builtin_profile(tool)` — Get the path to a built-in profile YAML for a tool.
- `list_builtin_profiles()` — List all available built-in profile names.
- `merge_profiles(base, override)` — Deep-merge two profile dicts. Override values take precedence.
- `load_profile_yaml(path)` — Load a YAML profile, with graceful fallback if PyYAML is not installed.
- `do_cmd(ctx, task, project_name, tool_name)` — One command to rule them all.
- `get_adapter(tool_name)` — Return an adapter instance for the named tool, or None.
- `register_adapter(tool_name, adapter_cls)` — Register a custom adapter class for a tool.
- `set_tool_provider(req)` — Assign an LLM provider to a specific tool.
- `get_tool_providers()` — Get current tool → provider mappings.
- `queue_status()` — Get queue summary and recent jobs.
- `list_jobs(status, limit)` — List jobs with optional status filter.
- `get_job(job_id)` — Get details for a specific job.
- `cancel_job(job_id)` — Cancel a queued job.
- `retry_job(job_id)` — Retry a failed job — re-enqueue with same parameters.
- `repair_job(job_id)` — Run auto-diagnosis on a failed job and suggest/apply fixes.
- `start_executor()` — Start the background executor loop.
- `stop_executor()` — Stop the background executor loop.
- `list_tools(category, available_only)` — List all registered tools.
- `tools_summary()` — Summary of tool availability.
- `update_tool(tool_name, body)` — Update a tool's mutable fields (default_model, default_instance, description, force_available).
- `get_tool(tool_name)` — Get details for a specific tool.
- `preview_prompt(req)` — Preview the prompt that would be sent to a tool for a ticket.
- `dispatch_job(req)` — Dispatch a tool to work on a ticket. Enqueues a job.
- `tools_healthcheck()` — Comprehensive health check for every registered tool.
- `delete_milestone(delete_func, item_id)` — Delete a milestone.
- `delete_vm(delete_func, item_id)` — Delete a VM.
- `delete_item(delete_func, item_id, not_found_msg)` — Generic delete function for tickets and sprints.
- `delete_ticket_from_dict(tickets_dict, ticket_id, save_func)` — Delete a ticket from the tickets dictionary.
- `delete_ticket_from_dict(tickets, ticket_id, save_callback)` — Delete a ticket from the tickets dictionary.
- `start_executor()` — Start the background executor loop.
- `stop_executor()` — Stop the background executor loop.
- `ct()` — —
- `get()` — —
- `body()` — —
- `post()` — —
- `payload()` — —
- `put()` — —
- `del()` — —
- `execute_autofix(req)` — Execute an automatic fix for a tool issue.
- `bulk_autofix()` — Run auto-fix for all degraded tools that support automatic fixes.
- `formatDate()` — —
- `date()` — —
- `now()` — —
- `diffMs()` — —
- `diffMins()` — —
- `diffHours()` — —
- `diffDays()` — —
- `formatDuration()` — —
- `mins()` — —
- `hours()` — —
- `days()` — —
- `formatSize()` — —
- `useState()` — —
- `useEffect()` — —
- `useCallback()` — —
- `Dashboard()` — —
- `data()` — —
- `root()` — —
- `DiagnosticsPanel()` — —
- `runTests()` — —
- `r()` — —
- `find()` — —
- `copyErrorsToClipboard()` — —
- `failedTests()` — —
- `lines()` — —
- `issues()` — —
- `VoiceHeader()` — —
- `h()` — —
- `VoiceBubbles()` — —
- `VoiceCommands()` — —
- `VoiceHistoryBox()` — —
- `u()` — —
- `SR()` — —
- `r()` — —
- `VoiceChat()` — —
- `recRef()` — —
- `abortRef()` — —
- `finish()` — —
- `handleInput()` — —
- `ctrl()` — —
- `reply()` — —
- `startListening()` — —
- `text()` — —
- `stopAll()` — —
- `onKey()` — —
- `sc()` — —
- `label()` — —
- `useHealth()` — —
- `refresh()` — —
- `h()` — —
- `useBudget()` — —
- `useModels()` — —
- `m()` — —
- `useProviders()` — —
- `p()` — —
- `useResources()` — —
- `useLogs()` — —
- `l()` — —
- `DASHBOARD_THEME_STORAGE_KEY()` — —
- `normalizeDashboardTheme()` — —
- `getInitialDashboardTheme()` — —
- `storedTheme()` — —
- `prefersDark()` — —
- `applyDashboardTheme()` — —
- `normalizedTheme()` — —
- `root()` — —
- `getUrlParams()` — —
- `params()` — —
- `DASHBOARD_VALID_TABS()` — —
- `normalizeDashboardTab()` — —
- `normalized()` — —
- `normalizeDashboardAction()` — —
- `normalizeDashboardContext()` — —
- `updateUrlParams()` — —
- `url()` — —
- `useDashboardData()` — —
- `getInitialRoute()` — —
- `hash()` — —
- `tab()` — —
- `initialRoute()` — —
- `urlParams()` — —
- `canonicalizedUrlRef()` — —
- `toggleTheme()` — —
- `currentUrl()` — —
- `currentHash()` — —
- `currentAction()` — —
- `currentContext()` — —
- `legacyTaskRoute()` — —
- `canonicalTab()` — —
- `canonicalAction()` — —
- `canonicalContext()` — —
- `setTab()` — —
- `normalizedTab()` — —
- `setSelectedProjectWithUrl()` — —
- `setSelectedTicketWithUrl()` — —
- `setSelectedToolWithUrl()` — —
- `setViewModeWithUrl()` — —
- `setContextWithUrl()` — —
- `handleHashChange()` — —
- `newTab()` — —
- `handlePopState()` — —
- `healthHook()` — —
- `budgetHook()` — —
- `modelsHook()` — —
- `providersHook()` — —
- `resourcesHook()` — —
- `logsHook()` — —
- `isUp()` — —
- `i()` — —
- `apiCall()` — —
- `r()` — —
- `err()` — —
- `matchDSL()` — —
- `t()` — —
- `m()` — —
- `captured()` — —
- `executeDSL()` — —
- `data()` — —
- `setVoiceCredentials()` — —
- `vms()` — —
- `logs()` — —
- `formatToolResult()` — —
- `fn()` — —
- `dsl()` — —
- `label()` — —
- `reply()` — —
- `langHint()` — —
- `res()` — —
- `name()` — —
- `result()` — —
- `processVoiceInput()` — —
- `dslReply()` — —
- `messages()` — —
- `msg()` — —
- `toolReply()` — —
- `useLogFilter()` — —
- `filtered()` — —
- `errorCount()` — —
- `warnCount()` — —
- `LogRow()` — —
- `LogPanel()` — —
- `handleCopy()` — —
- `text()` — —
- `ta()` — —
- `useState()` — —
- `useCallback()` — —
- `useEffect()` — —
- `useMemo()` — —
- `useHumanTasks()` — —
- `refresh()` — —
- `allTickets()` — —
- `createTask()` — —
- `result()` — —
- `completeTask()` — —
- `addComment()` — —
- `HumanTaskPanel()` — —
- `filtered()` — —
- `boardColumns()` — —
- `humanJobs()` — —
- `stats()` — —
- `handleStartStop()` — —
- `StatusBadge()` — —
- `CostBar()` — —
- `pct()` — —
- `Card()` — —
- `StateBadge()` — —
- `colors()` — —
- `useVMSort()` — —
- `sorted()` — —
- `cmp()` — —
- `r()` — —
- `useVMSelection()` — —
- `handleSelect()` — —
- `next()` — —
- `handleSelectAll()` — —
- `handleBulkAction()` — —
- `vmIds()` — —
- `VMCard()` — —
- `actions()` — —
- `VMsPanel()` — —
- `sel()` — —
- `fetchTools()` — —
- `data()` — —
- `detail()` — —
- `handleAction()` — —
- `isDelete()` — —
- `endpoint()` — —
- `res()` — —
- `msg()` — —
- `label()` — —
- `handleToolAssign()` — —
- `runningCount()` — —
- `stoppedCount()` — —
- `pausedCount()` — —
- `assignedToolName()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `useTasksData()` — —
- `refresh()` — —
- `timer()` — —
- `TaskCardHeader()` — —
- `statusColor()` — —
- `priorityColor()` — —
- `typeIcon()` — —
- `TaskCardMeta()` — —
- `job()` — —
- `resultSuccess()` — —
- `resultLabel()` — —
- `isActiveJob()` — —
- `environment()` — —
- `TaskJobBadge()` — —
- `statusIcon()` — —
- `duration()` — —
- `filesChanged()` — —
- `hasOutput()` — —
- `TaskInlineLogs()` — —
- `j()` — —
- `TaskJobError()` — —
- `TaskJobResult()` — —
- `output()` — —
- `files()` — —
- `preview()` — —
- `TaskStatusActions()` — —
- `handleStatusChange()` — —
- `TaskSelectionCheckbox()` — —
- `TaskBulkEditBar()` — —
- `selectAllRef()` — —
- `visibleIds()` — —
- `selectedVisibleCount()` — —
- `allVisibleSelected()` — —
- `someVisibleSelected()` — —
- `toolOptions()` — —
- `seen()` — —
- `name()` — —
- `handleApply()` — —
- `count()` — —
- `TaskTicketCard()` — —
- `liveJob()` — —
- `isActive()` — —
- `isDone()` — —
- `isFailed()` — —
- `QueueBar()` — —
- `byStatus()` — —
- `lower()` — —
- `CreateMilestoneForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `CreateSprintForm()` — —
- `QuickTaskCreator()` — —
- `availableSprints()` — —
- `priorityClassName()` — —
- `r()` — —
- `onKey()` — —
- `canSubmit()` — —
- `TasksPanel()` — —
- `filtered()` — —
- `result()` — —
- `q()` — —
- `boardColumns()` — —
- `handleStartStop()` — —
- `validIds()` — —
- `changed()` — —
- `next()` — —
- `toggleTicketSelection()` — —
- `toggleVisibleSelection()` — —
- `visibleSet()` — —
- `clearSelection()` — —
- `handleBulkUpdate()` — —
- `ids()` — —
- `toolPayload()` — —
- `toolName()` — —
- `CostSummary()` — —
- `BudgetCards()` — —
- `dailyUsed()` — —
- `monthlyUsed()` — —
- `SystemCard()` — —
- `ProvidersCard()` — —
- `OverviewTab()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `ModelsTable()` — —
- `exportData()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `useTools()` — —
- `refreshTools()` — —
- `data()` — —
- `refreshQueue()` — —
- `refresh()` — —
- `ToolCard()` — —
- `catClass()` — —
- `handleCardClick()` — —
- `handleModelChange()` — —
- `newModel()` — —
- `JobRow()` — —
- `statusClass()` — —
- `hasLogs()` — —
- `isFailed()` — —
- `JobDetailsPanel()` — —
- `result()` — —
- `stdout()` — —
- `stderr()` — —
- `filesChanged()` — —
- `ticketTitle()` — —
- `ticketStatus()` — —
- `execution()` — —
- `promptExcerpt()` — —
- `projectDir()` — —
- `resultSuccess()` — —
- `isActiveJob()` — —
- `stdoutLines()` — —
- `stderrLines()` — —
- `TicketDispatchTable()` — —
- `availableTools()` — —
- `unavailableTools()` — —
- `dispatchableTickets()` — —
- `loadTickets()` — —
- `loadProjects()` — —
- `handleToolSelect()` — —
- `getStatusBadgeClass()` — —
- `getPriorityBadgeClass()` — —
- `getToolCategoryClass()` — —
- `getProjectInfo()` — —
- `project()` — —
- `path()` — —
- `renderCurrentTool()` — —
- `environmentName()` — —
- `environmentTarget()` — —
- `renderStatusBadge()` — —
- `displayStatus()` — —
- `renderPriorityBadge()` — —
- `priorityClass()` — —
- `displayPriority()` — —
- `currentTool()` — —
- `toolInfo()` — —
- `projectInfo()` — —
- `QueueSummary()` — —
- `HealthTrends()` — —
- `metrics()` — —
- `now()` — —
- `oneHourAgo()` — —
- `oneDayAgo()` — —
- `recentChecks()` — —
- `dayChecks()` — —
- `toolHistory()` — —
- `statuses()` — —
- `wasOk()` — —
- `nowDegraded()` — —
- `PredictiveAlerts()` — —
- `alerts()` — —
- `queuedJobs()` — —
- `failingTools()` — —
- `stuckJobs()` — —
- `ToolHealthPanel()` — —
- `loadHealth()` — —
- `handleProviderChange()` — —
- `handleAutoFix()` — —
- `action()` — —
- `handleBulkAutoFix()` — —
- `executed()` — —
- `humanRequired()` — —
- `failed()` — —
- `isAutoFixable()` — —
- `requiresHuman()` — —
- `summary()` — —
- `tools()` — —
- `degradedCount()` — —
- `isHuman()` — —
- `isFixing()` — —
- `providerIsConfigured()` — —
- `ToolsPanel()` — —
- `handleStartStop()` — —
- `handleRetryJob()` — —
- `handleRepairJob()` — —
- `details()` — —
- `handleSelectJob()` — —
- `available()` — —
- `unavailable()` — —
- `useProjects()` — —
- `refresh()` — —
- `data()` — —
- `kind()` — —
- `path()` — —
- `current()` — —
- `MultiSelectSection()` — —
- `selectedSet()` — —
- `selectedItems()` — —
- `hasItems()` — —
- `listContent()` — —
- `value()` — —
- `checked()` — —
- `AssignmentBadge()` — —
- `TicketTable()` — —
- `ProjectCard()` — —
- `projectKey()` — —
- `assignedTools()` — —
- `assignedEnvironments()` — —
- `assignedLlms()` — —
- `assignedUsers()` — —
- `ticketCount()` — —
- `envCount()` — —
- `toolCount()` — —
- `llmCount()` — —
- `userCount()` — —
- `handleToggleTickets()` — —
- `handleDelete()` — —
- `QuickCreateProject()` — —
- `loadOptions()` — —
- `resetForm()` — —
- `toolOptions()` — —
- `seen()` — —
- `nameValue()` — —
- `modelOptions()` — —
- `userOptions()` — —
- `handleCreate()` — —
- `ProjectsPanel()` — —
- `isProjectTicketsView()` — —
- `syncProjectUrl()` — —
- `url()` — —
- `handleSelectProject()` — —
- `stats()` — —
- `useQuickDo()` — —
- `submit()` — —
- `r()` — —
- `toolInfo()` — —
- `onKey()` — —
- `canSubmit()` — —
- `QuickDoFeedback()` — —
- `color()` — —
- `QuickDoCompact()` — —
- `q()` — —
- `QuickDo()` — —
- `HealthCard()` — —
- `checks()` — —
- `total()` — —
- `ok()` — —
- `alerts()` — —
- `BudgetMiniCard()` — —
- `dailyUsed()` — —
- `monthlyUsed()` — —
- `monthlyLimit()` — —
- `remaining()` — —
- `QueueMiniCard()` — —
- `load()` — —
- `data()` — —
- `timer()` — —
- `qs()` — —
- `running()` — —
- `done()` — —
- `ms()` — —
- `ActivityRow()` — —
- `RecentActivity()` — —
- `tickets()` — —
- `jobs()` — —
- `HomeTab()` — —
- `vms()` — —
- `running()` — —
- `daily()` — —
- `monthly()` — —
- `logs()` — —
- `ids()` — —
- `routes()` — —
- `ok()` — —
- `fail()` — —
- `accounts()` — —
- `useTickets()` — —
- `refreshTickets()` — —
- `data()` — —
- `refreshSprints()` — —
- `refreshMilestones()` — —
- `refreshTools()` — —
- `refresh()` — —
- `TicketCard()` — —
- `assignedEnvironment()` — —
- `handleSprintChange()` — —
- `handleCardClick()` — —
- `handleCheckboxClick()` — —
- `handleStatusChange()` — —
- `handleAssign()` — —
- `CreateMilestoneForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `CreateTicketForm()` — —
- `CreateSprintForm()` — —
- `SprintCard()` — —
- `handleMilestoneChange()` — —
- `MilestoneCard()` — —
- `headers()` — —
- `escape()` — —
- `stringValue()` — —
- `blob()` — —
- `url()` — —
- `link()` — —
- `TicketExportMenu()` — —
- `queryString()` — —
- `params()` — —
- `fetchExport()` — —
- `downloadJSON()` — —
- `downloadCSV()` — —
- `csv()` — —
- `copyJSON()` — —
- `formatTimestamp()` — —
- `date()` — —
- `TicketHistoryItem()` — —
- `result()` — —
- `stdout()` — —
- `stderr()` — —
- `filesChanged()` — —
- `statusClass()` — —
- `success()` — —
- `execution()` — —
- `projectDir()` — —
- `promptExcerpt()` — —
- `promptLength()` — —
- `isActiveJob()` — —
- `resultLabel()` — —
- `TicketDetailPanel()` — —
- `jobHistory()` — —
- `latestJob()` — —
- `latestExecutionMetadata()` — —
- `latestProjectDir()` — —
- `latestPromptExcerpt()` — —
- `latestPromptLength()` — —
- `latestSuccess()` — —
- `latestExitCode()` — —
- `latestStdoutLines()` — —
- `latestStderrLines()` — —
- `latestFilesChanged()` — —
- `latestIsActiveJob()` — —
- `latestResultLabel()` — —
- `TicketsPanel()` — —
- `loadSelectedTicket()` — —
- `handleRefresh()` — —
- `toggleTicketSelection()` — —
- `newSet()` — —
- `selectAllTickets()` — —
- `clearSelection()` — —
- `bulkUpdateStatus()` — —
- `ids()` — —
- `bulkAssignTool()` — —
- `bulkDeleteTickets()` — —
- `visibleSprints()` — —
- `filtered()` — —
- `q()` — —
- `comparison()` — —
- `boardColumns()` — —
- `stats()` — —
- `count()` — —
- `selectedTicketSummary()` — —
- `useSystemData()` — —
- `refresh()` — —
- `SystemPanel()` — —
- `activeProviders()` — —
- `ALL_TAB_IDS()` — —
- `DashboardHeader()` — —
- `isDark()` — —
- `headerClass()` — —
- `titleClass()` — —
- `subtitleClass()` — —
- `themeLabel()` — —
- `toggleClass()` — —
- `refreshClass()` — —
- `TabNav()` — —
- `navClass()` — —
- `activeTabClass()` — —
- `inactiveTabClass()` — —
- `AccountRow()` — —
- `a()` — —
- `NewAccountForm()` — —
- `handleSubmit()` — —
- `AccountsPanel()` — —
- `handleCreate()` — —
- `useRef()` — —
- `useUsers()` — —
- `didAutoSync()` — —
- `refreshUsers()` — —
- `data()` — —
- `syncGitUsers()` — —
- `createUser()` — —
- `setDefaultUser()` — —
- `boot()` — —
- `UserCard()` — —
- `roleClass()` — —
- `CreateUserForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `UsersPanel()` — —
- `handleSetDefault()` — —
- `handleCreate()` — —
- `handleSyncGit()` — —
- `result()` — —
- `activeUsers()` — —
- `defaultUserId()` — —
- `useState()` — —
- `useEffect()` — —
- `useMemo()` — —
- `useCallback()` — —
- `instances()` — —
- `EnvironmentsPanel()` — —
- `environmentMap()` — —
- `refresh()` — —
- `resetForm()` — —
- `handleSubmit()` — —
- `payload()` — —
- `handleEdit()` — —
- `handleDelete()` — —
- `response()` — —
- `handleToolAssign()` — —
- `countsByKind()` — —
- `assignedToolCount()` — —
- `assignedInstanceCount()` — —
- `currentEnvironmentId()` — —
- `currentEnvironment()` — —
- `currentInstanceName()` — —
- `toolInstances()` — —
- `toolInstanceOptions()` — —
- `TicketFilters()` — —
- `handleReset()` — —
- `BulkOperations()` — —
- `toggleTicketSelection()` — —
- `newSet()` — —
- `selectAllTickets()` — —
- `clearSelection()` — —
- `executeBulkAction()` — —
- `ids()` — —
- `useState()` — —
- `useEffect()` — —
- `useMemo()` — —
- `EMPTY_COMPLETED()` — —
- `raw()` — —
- `parsed()` — —
- `parsedValues()` — —
- `SetupPanel()` — —
- `persisted()` — —
- `checkedCount()` — —
- `autoCount()` — —
- `manualCount()` — —
- `rootCount()` — —
- `toggleStep()` — —
- `setField()` — —
- `setSecretField()` — —
- `copyText()` — —
- `copyAllCommands()` — —
- `text()` — —
- `envSnippet()` — —
- `oneLineSummary()` — —
- `hasCommands()` — —
- `hasSudoCommands()` — —
- `TicketStats()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `url()` — —
- `link()` — —
- `downloadJSON()` — —
- `json()` — —
- `TicketList()` — —
- `DiagRooConfig()` — —
- `ok()` — —
- `badge()` — —
- `DiagProviders()` — —
- `useTicketFilters()` — —
- `result()` — —
- `q()` — —
- `comparison()` — —
- `useTicketStats()` — —
- `count()` — —
- `useTicketsData()` — —
- `refreshTickets()` — —
- `data()` — —
- `refreshSprints()` — —
- `refreshMilestones()` — —
- `refresh()` — —
- `TicketsPanelRefactored()` — —
- `filtered()` — —
- `stats()` — —
- `handleRefresh()` — —
- `toggleTicketSelection()` — —
- `newSet()` — —
- `visibleSprints()` — —
- `cls()` — —
- `DiagVSCode()` — —
- `DiagProxy()` — —
- `DiagExtensions()` — —
- `ok()` — —
- `DiagCopilot()` — —
- `DiagAgentSetup()` — —
- `DiagAgentTest()` — —
- `skipped()` — —
- `DispatchTableHeader()` — —
- `DiagnosticActions()` — —
- `isAutoFixable()` — —
- `requiresHuman()` — —
- `ProjectInfoResolver()` — —
- `getProjectInfo()` — —
- `project()` — —
- `path()` — —
- `renderProjectInfo()` — —
- `projectInfo()` — —
- `ToolsPanelRefactored()` — —
- `TicketDispatchTableRefactored()` — —
- `availableTools()` — —
- `unavailableTools()` — —
- `dispatchableTickets()` — —
- `projectResolver()` — —
- `loadTickets()` — —
- `data()` — —
- `loadProjects()` — —
- `handleToolSelect()` — —
- `ToolsJobQueue()` — —
- `handleStartStop()` — —
- `handleRetryJob()` — —
- `handleRepairJob()` — —
- `data()` — —
- `details()` — —
- `handleSelectJob()` — —
- `handleCloseJobDetails()` — —
- `ToolsDispatch()` — —
- `DispatchTableRow()` — —
- `statusBadges()` — —
- `projectResolver()` — —
- `currentTool()` — —
- `toolInfo()` — —
- `projectInfo()` — —
- `projectDir()` — —
- `TicketStatusBadges()` — —
- `getStatusBadgeClass()` — —
- `getPriorityBadgeClass()` — —
- `getToolCategoryClass()` — —
- `renderStatusBadge()` — —
- `statusClass()` — —
- `displayStatus()` — —
- `renderPriorityBadge()` — —
- `priorityClass()` — —
- `displayPriority()` — —
- `renderCurrentTool()` — —
- `ProviderConfigPanel()` — —
- `ToolsRegistry()` — —
- `available()` — —
- `unavailable()` — —
- `ToolHealthCard()` — —
- `statusClass()` — —
- `isHuman()` — —
- `DispatchActions()` — —
- `BulkAutoFix()` — —
- `ToolAvailabilityAlert()` — —
- `ToolHealthDisplay()` — —
- `summary()` — —
- `degradedCount()` — —
- `TasksBoard()` — —
- `TasksPanelRefactored()` — —
- `filtered()` — —
- `boardColumns()` — —
- `handleStartStop()` — —
- `handleViewChange()` — —
- `handleFilterChange()` — —
- `TasksList()` — —
- `ToolHealthPanelRefactored()` — —
- `loadHealth()` — —
- `data()` — —
- `handleProviderChange()` — —
- `handleAutoFix()` — —
- `action()` — —
- `result()` — —
- `handleBulkAutoFix()` — —
- `executed()` — —
- `humanRequired()` — —
- `failed()` — —
- `summary()` — —
- `tools()` — —
- `degradedCount()` — —
- `TasksTable()` — —
- `TasksViewControls()` — —
- `HumanTaskBoard()` — —
- `HumanTaskList()` — —
- `TasksRecentJobs()` — —
- `HumanTaskTable()` — —
- `HumanJobsList()` — —
- `HumanViewControls()` — —
- `HumanTaskStats()` — —
- `check()` — —
- `skip()` — —
- `api()` — —
- `parse_response()` — —
- `phase_health()` — —
- `phase_tools()` — —
- `phase_executor()` — —
- `dispatch_and_monitor()` — —
- `phase_lifecycle()` — —
- `phase_queue_logs()` — —
- `phase_tickets()` — —
- `phase_healthcheck()` — —
- `summary()` — —
- `usage()` — —
- `log_pass()` — —
- `log_fail()` — —
- `log_info()` — —
- `require_cmd()` — —
- `check_contains()` — —
- `check_status()` — —
- `main()` — —
- `print()` — —
- `HumanTaskPanelRefactored()` — —
- `filtered()` — —
- `boardColumns()` — —
- `humanJobs()` — —
- `stats()` — —
- `handleStartStop()` — —
- `handleViewChange()` — —
- `handleFilterChange()` — —
- `lifespan(app)` — —
- `cli()` — —


## Project Structure

📄 `docs.open-webui-tools.proxym_tools` (9 functions, 1 classes)
📄 `frontend.proxym-dashboard`
📄 `project`
📄 `project.examples.advanced_usage`
📄 `project.examples.quickstart`
📄 `scripts.check_dashboard` (8 functions)
📄 `scripts.evaluate_llm_work` (2 functions)
📄 `scripts.jetson-entrypoint`
📄 `scripts.proxym-voice-chat` (3 functions)
📄 `scripts.proxym-voice-server`
📄 `scripts.seed_sprint8` (1 functions)
📄 `scripts.setup`
📄 `scripts.validate_system` (11 functions)
📄 `services.vscode.entrypoint` (3 functions)
📦 `src.proxym`
📦 `src.proxym.accounts` (20 functions, 8 classes)
📦 `src.proxym.api`
📄 `src.proxym.api._diag_agent` (3 functions)
📄 `src.proxym.api._diag_common` (1 functions)
📄 `src.proxym.api._diag_providers` (1 functions)
📄 `src.proxym.api._diag_proxy` (1 functions)
📄 `src.proxym.api._diag_roo` (1 functions)
📄 `src.proxym.api._diag_vscode` (2 functions)
📄 `src.proxym.api._pipeline` (16 functions, 1 classes)
📄 `src.proxym.api._state` (6 functions)
📄 `src.proxym.api.completions` (12 functions)
📄 `src.proxym.api.console` (4 functions)
📄 `src.proxym.api.context_api` (7 functions)
📄 `src.proxym.api.diagnostics` (9 functions)
📄 `src.proxym.api.frontend` (8 functions)
📄 `src.proxym.api.observability_api` (7 functions, 1 classes)
📄 `src.proxym.api.system` (7 functions)
📄 `src.proxym.api.voice_actions` (9 functions)
📄 `src.proxym.api.vscode_api` (11 functions)
📦 `src.proxym.cache` (10 functions, 3 classes)
📦 `src.proxym.cli`
📄 `src.proxym.cli._client` (4 functions)
📦 `src.proxym.cli._groups`
📄 `src.proxym.cli._groups._shared` (7 functions)
📄 `src.proxym.cli._groups.accounts_ctl` (7 functions)
📄 `src.proxym.cli._groups.browser_ctl` (2 functions)
📄 `src.proxym.cli._groups.context_ctl` (3 functions)
📄 `src.proxym.cli._groups.diagnostics_ctl` (3 functions)
📄 `src.proxym.cli._groups.do_ctl` (8 functions)
📄 `src.proxym.cli._groups.observability_ctl` (5 functions)
📄 `src.proxym.cli._groups.projects_ctl` (7 functions)
📄 `src.proxym.cli._groups.tickets_ctl` (13 functions)
📄 `src.proxym.cli._groups.tools_ctl` (6 functions)
📄 `src.proxym.cli._groups.vms_ctl` (7 functions)
📄 `src.proxym.cli._groups.vscode_ctl` (1 functions)
📄 `src.proxym.cli.accounts` (6 functions)
📄 `src.proxym.cli.browser` (5 functions)
📄 `src.proxym.cli.chat` (12 functions)
📄 `src.proxym.cli.context` (6 functions)
📄 `src.proxym.cli.diagnostics` (7 functions)
📄 `src.proxym.cli.dsl` (8 functions, 2 classes)
📄 `src.proxym.cli.observability` (6 functions)
📄 `src.proxym.cli.smart_defaults` (4 functions)
📄 `src.proxym.cli.system` (6 functions)
📄 `src.proxym.cli.tickets` (14 functions)
📄 `src.proxym.cli.tts` (5 functions, 1 classes)
📄 `src.proxym.cli.utils.cmd_sessions_list` (3 functions)
📄 `src.proxym.cli.vms` (11 functions)
📄 `src.proxym.cli.voice` (3 functions, 1 classes)
📄 `src.proxym.cli.vscode` (8 functions)
📄 `src.proxym.config` (3 functions, 1 classes)
📦 `src.proxym.context`
📄 `src.proxym.context._context` (1 functions, 1 classes)
📄 `src.proxym.context.detector` (8 functions)
📄 `src.proxym.context.session` (12 functions, 2 classes)
📄 `src.proxym.context.tool_selector` (2 functions)
📄 `src.proxym.ctl` (15 functions)
📦 `src.proxym.dashboard`
📄 `src.proxym.dashboard._accounts` (5 functions, 2 classes)
📄 `src.proxym.dashboard._costs` (3 functions)
📄 `src.proxym.dashboard._environments_api` (33 functions, 6 classes)
📄 `src.proxym.dashboard._projects_api` (12 functions, 3 classes)
📄 `src.proxym.dashboard._shared` (2 functions)
📄 `src.proxym.dashboard._system` (4 functions)
📄 `src.proxym.dashboard._tickets_api` (20 functions, 8 classes)
📄 `src.proxym.dashboard._users_api` (9 functions, 2 classes)
📄 `src.proxym.dashboard._vms` (12 functions, 3 classes)
📄 `src.proxym.dashboard.api` (14 functions)
📄 `src.proxym.dashboard.components.accounts` (6 functions)
📄 `src.proxym.dashboard.components.diagnostics` (8 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagAgent` (3 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagConfig` (4 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagExtensions` (3 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagInfrastructure` (2 functions)
📄 `src.proxym.dashboard.components.diagnostics.helpers` (4 functions)
📄 `src.proxym.dashboard.components.environments` (31 functions)
📄 `src.proxym.dashboard.components.home` (41 functions)
📄 `src.proxym.dashboard.components.human` (18 functions)
📄 `src.proxym.dashboard.components.human.HumanJobsList` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskBoard` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskList` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskPanelRefactored` (9 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskStats` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskTable` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanViewControls` (1 functions)
📄 `src.proxym.dashboard.components.layout` (14 functions)
📄 `src.proxym.dashboard.components.logs` (9 functions)
📄 `src.proxym.dashboard.components.models` (21 functions)
📄 `src.proxym.dashboard.components.overview` (7 functions)
📄 `src.proxym.dashboard.components.projects` (55 functions)
📄 `src.proxym.dashboard.components.setup` (27 functions)
📄 `src.proxym.dashboard.components.system` (4 functions)
📄 `src.proxym.dashboard.components.tasks` (113 functions)
📄 `src.proxym.dashboard.components.tasks.TasksBoard` (1 functions)
📄 `src.proxym.dashboard.components.tasks.TasksList` (1 functions)
📄 `src.proxym.dashboard.components.tasks.TasksPanelRefactored` (6 functions)
📄 `src.proxym.dashboard.components.tasks.TasksRecentJobs` (1 functions)
📄 `src.proxym.dashboard.components.tasks.TasksTable` (1 functions)
📄 `src.proxym.dashboard.components.tasks.TasksViewControls` (1 functions)
📄 `src.proxym.dashboard.components.tickets` (102 functions)
📄 `src.proxym.dashboard.components.tickets.BulkOperations` (7 functions)
📄 `src.proxym.dashboard.components.tickets.TicketFilters` (2 functions)
📄 `src.proxym.dashboard.components.tickets.TicketList` (17 functions)
📄 `src.proxym.dashboard.components.tickets.TicketStats` (1 functions)
📄 `src.proxym.dashboard.components.tickets.TicketsPanelRefactored` (21 functions)
📄 `src.proxym.dashboard.components.tools` (125 functions)
📄 `src.proxym.dashboard.components.tools.BulkAutoFix` (1 functions)
📄 `src.proxym.dashboard.components.tools.DiagnosticActions` (3 functions)
📄 `src.proxym.dashboard.components.tools.DispatchActions` (1 functions)
📄 `src.proxym.dashboard.components.tools.DispatchTableHeader` (1 functions)
📄 `src.proxym.dashboard.components.tools.DispatchTableRow` (7 functions)
📄 `src.proxym.dashboard.components.tools.ProjectInfoResolver` (6 functions)
📄 `src.proxym.dashboard.components.tools.ProviderConfigPanel` (1 functions)
📄 `src.proxym.dashboard.components.tools.TicketDispatchTableRefactored` (10 functions)
📄 `src.proxym.dashboard.components.tools.TicketStatusBadges` (11 functions)
📄 `src.proxym.dashboard.components.tools.ToolAvailabilityAlert` (1 functions)
📄 `src.proxym.dashboard.components.tools.ToolHealthCard` (3 functions)
📄 `src.proxym.dashboard.components.tools.ToolHealthDisplay` (3 functions)
📄 `src.proxym.dashboard.components.tools.ToolHealthPanelRefactored` (15 functions)
📄 `src.proxym.dashboard.components.tools.ToolsDispatch` (1 functions)
📄 `src.proxym.dashboard.components.tools.ToolsJobQueue` (9 functions)
📄 `src.proxym.dashboard.components.tools.ToolsPanelRefactored` (1 functions)
📄 `src.proxym.dashboard.components.tools.ToolsRegistry` (3 functions)
📄 `src.proxym.dashboard.components.ui` (6 functions)
📄 `src.proxym.dashboard.components.users` (23 functions)
📄 `src.proxym.dashboard.components.vms` (35 functions)
📄 `src.proxym.dashboard.components.voice` (30 functions)
📄 `src.proxym.dashboard.components.voice_engine` (31 functions)
📄 `src.proxym.dashboard.components.voice_schemas` (10 functions)
📄 `src.proxym.dashboard.hooks.useDashboardData` (70 functions)
📄 `src.proxym.dashboard.panel` (7 functions)
📦 `src.proxym.dashboard.tickets`
📄 `src.proxym.dashboard.tickets.TicketManagerRefactored` (26 functions, 4 classes)
📄 `src.proxym.dashboard.tickets._manager` (33 functions, 1 classes)
📄 `src.proxym.dashboard.tickets._models` (4 functions, 11 classes)
📄 `src.proxym.dashboard.tickets.utils.delete_ticket` (1 functions)
📦 `src.proxym.dashboard.tools`
📄 `src.proxym.dashboard.tools.HealthCheckerRefactored` (15 functions, 7 classes)
📄 `src.proxym.dashboard.tools._autofix` (5 functions, 1 classes)
📄 `src.proxym.dashboard.tools._dispatch` (2 functions, 2 classes)
📄 `src.proxym.dashboard.tools._health` (5 functions)
📄 `src.proxym.dashboard.tools._helpers` (3 functions)
📄 `src.proxym.dashboard.tools._lifecycle` (2 functions)
📄 `src.proxym.dashboard.tools._providers` (2 functions, 1 classes)
📄 `src.proxym.dashboard.tools._queue` (8 functions)
📄 `src.proxym.dashboard.tools._registry` (5 functions)
📦 `src.proxym.dashboard.tools.utils`
📄 `src.proxym.dashboard.tools.utils._aider_install_fix` (1 functions)
📄 `src.proxym.dashboard.tools.utils.start_executor` (3 functions)
📄 `src.proxym.dashboard.users` (56 functions, 3 classes)
📦 `src.proxym.dashboard.utils`
📄 `src.proxym.dashboard.utils._delete_item` (1 functions)
📄 `src.proxym.dashboard.utils.delete_milestone` (2 functions)
📄 `src.proxym.dashboard.utils.delete_ticket` (2 functions)
📄 `src.proxym.dashboard.utils.formatters` (12 functions)
📄 `src.proxym.main` (2 functions)
📦 `src.proxym.mcp`
📄 `src.proxym.mcp._helpers` (3 functions)
📄 `src.proxym.mcp._tools_accounts` (3 functions, 1 classes)
📄 `src.proxym.mcp._tools_system` (3 functions)
📄 `src.proxym.mcp._tools_tickets` (5 functions, 3 classes)
📄 `src.proxym.mcp._tools_vm` (7 functions, 4 classes)
📄 `src.proxym.mcp.client` (4 functions, 2 classes)
📄 `src.proxym.mcp.registry` (8 functions, 3 classes)
📄 `src.proxym.mcp.router` (4 functions, 1 classes)
📄 `src.proxym.mcp.self_server`
📦 `src.proxym.middleware` (4 functions, 2 classes)
📦 `src.proxym.observability` (8 functions)
📄 `src.proxym.observability.health_events` (7 functions, 3 classes)
📄 `src.proxym.observability.repair_agent` (9 functions, 1 classes)
📄 `src.proxym.observability.watchdog` (13 functions, 1 classes)
📦 `src.proxym.projects` (14 functions, 4 classes)
📦 `src.proxym.providers` (4 functions, 3 classes)
📦 `src.proxym.router` (13 functions, 1 classes)
📄 `src.proxym.router.strategy` (19 functions, 3 classes)
📄 `src.proxym.storage` (6 functions, 1 classes)
📦 `src.proxym.tools` (19 functions, 5 classes)
📦 `src.proxym.tools.adapters` (2 functions)
📄 `src.proxym.tools.adapters._aider` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._base` (3 functions, 1 classes)
📄 `src.proxym.tools.adapters._claude_code` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._human` (2 functions, 1 classes)
📄 `src.proxym.tools.adapters._llm_fallback` (3 functions)
📄 `src.proxym.tools.adapters._result` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._shell` (2 functions, 1 classes)
📄 `src.proxym.tools.adapters._vscode` (3 functions, 1 classes)
📄 `src.proxym.tools.executor` (17 functions, 3 classes)
📦 `src.proxym.utils`
📄 `src.proxym.utils.get_settings` (1 functions)
📄 `src.proxym.utils.messages` (1 functions)
📦 `src.proxym.virt`
📄 `src.proxym.virt._check` (1 functions)
📄 `src.proxym.virt._config` (1 functions, 3 classes)
📄 `src.proxym.virt._enums` (2 classes)
📄 `src.proxym.virt._infra` (4 functions, 1 classes)
📄 `src.proxym.virt._lifecycle` (12 functions, 1 classes)
📄 `src.proxym.virt._orchestrator` (5 functions, 1 classes)
📄 `src.proxym.virt._project` (2 functions, 1 classes)
📄 `src.proxym.virt._snapshot` (4 functions, 1 classes)
📄 `src.proxym.virt._state` (5 functions, 1 classes)
📄 `src.proxym.virt._vm_config` (7 functions, 1 classes)
📄 `src.proxym.virt.browser_profiles` (12 functions, 2 classes)
📄 `src.proxym.virt.clonebox_adapter` (17 functions, 2 classes)
📦 `src.proxym.virt.profiles` (4 functions)
📄 `src.proxym.virt.utils.detect_chrome_profiles` (3 functions)
📦 `src.proxym.watch` (5 functions, 1 classes)
📄 `src.proxym.watch.client`
📦 `utils`
📄 `utils.main` (1 functions)
📄 `utils.validation_common` (9 functions)
📄 `validate_dispatch_table_refactoring` (1 functions)
📄 `validate_human_task_refactoring` (1 functions)
📄 `validate_refactoring` (1 functions)
📄 `validate_tasks_panel_refactoring` (1 functions)
📄 `validate_tool_health_refactoring` (1 functions)
📄 `validate_tools_panel_refactoring` (1 functions)

## Requirements

- Python >= >=3.11
- fastapi >=0.115.0- uvicorn [standard]>=0.30.0- httpx >=0.27.0- litellm >=1.55.0- redis >=5.0.0- pydantic >=2.9.0- pydantic-settings >=2.5.0- python-dotenv >=1.0.0- tiktoken >=0.8.0- watchfiles >=0.24.0- xxhash >=3.5.0- rich >=13.9.0- structlog >=24.4.0- pyyaml >=6.0- click >=8.1.0

## Contributing

**Contributors:**
- Tom Softreck <tom@sapletta.com>
- Tom Sapletta <tom-sapletta-com@users.noreply.github.com>

We welcome contributions! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

### Development Setup

```bash
# Clone the repository
git clone https://github.com/wronai/proxy
cd proxy

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest
```

## Documentation

- 📖 [Full Documentation](https://github.com/wronai/proxy/tree/main/docs) — API reference, module docs, architecture
- 🚀 [Getting Started](https://github.com/wronai/proxy/blob/main/docs/getting-started.md) — Quick start guide
- 📚 [API Reference](https://github.com/wronai/proxy/blob/main/docs/api.md) — Complete API documentation
- 🔧 [Configuration](https://github.com/wronai/proxy/blob/main/docs/configuration.md) — Configuration options
- 💡 [Examples](./examples) — Usage examples and code samples

### Generated Files

| Output | Description | Link |
|--------|-------------|------|
| `README.md` | Project overview (this file) | — |
| `docs/api.md` | Consolidated API reference | [View](./docs/api.md) |
| `docs/modules.md` | Module reference with metrics | [View](./docs/modules.md) |
| `docs/architecture.md` | Architecture with diagrams | [View](./docs/architecture.md) |
| `docs/dependency-graph.md` | Dependency graphs | [View](./docs/dependency-graph.md) |
| `docs/coverage.md` | Docstring coverage report | [View](./docs/coverage.md) |
| `docs/getting-started.md` | Getting started guide | [View](./docs/getting-started.md) |
| `docs/configuration.md` | Configuration reference | [View](./docs/configuration.md) |
| `docs/api-changelog.md` | API change tracking | [View](./docs/api-changelog.md) |
| `CONTRIBUTING.md` | Contribution guidelines | [View](./CONTRIBUTING.md) |
| `examples/` | Usage examples | [Browse](./examples) |
| `mkdocs.yml` | MkDocs configuration | — |

<!-- code2docs:end -->