#!/usr/bin/env python3
"""Validation script for HumanTaskPanel refactoring."""

import sys
import os

# Add parent directory to path to import utils
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.main import create_validation_main
from utils.validation_common import (
    validate_jsx_component,
    count_complexity,
    print_validation_header,
    print_complexity_analysis,
    print_summary_footer,
    run_validation,
)


def main():
    """Validate HumanTaskPanel refactoring."""
    return create_validation_main(
        title="HumanTaskPanel Refactoring",
        components={
            'HumanTaskStats.jsx': ['HumanTaskStats'],
            'HumanTaskBoard.jsx': ['HumanTaskBoard'],
            'HumanTaskList.jsx': ['HumanTaskList'],
            'HumanJobsList.jsx': ['HumanJobsList'],
            'HumanViewControls.jsx': ['HumanViewControls'],
            'HumanTaskPanelRefactored.jsx': ['HumanTaskPanelRefactored']
        },
        base_path='src/proxym/dashboard/components/human',
        original_file='src/proxym/dashboard/components/human.jsx',
        benefits_bullet='human task management'
    )

if __name__ == "__main__":
    main()
