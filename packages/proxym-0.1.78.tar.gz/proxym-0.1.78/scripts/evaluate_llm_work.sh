#!/bin/bash
# scripts/evaluate_llm_work.sh — Automatyczna ocena pracy LLM
# Uruchom: bash scripts/evaluate_llm_work.sh

set -uo pipefail
cd "$(dirname "$0")/.."

PASS=0; FAIL=0; SKIP=0

check() {
  local name="$1"; shift
  if eval "$@" >/dev/null 2>&1; then
    echo "  ✅ $name"
    PASS=$((PASS+1))
  else
    echo "  ❌ $name"
    FAIL=$((FAIL+1))
  fi
}

skip() {
  echo "  ⏭️  $1 (skipped: $2)"
  SKIP=$((SKIP+1))
}

PY="PYTHONPATH=src python3"

echo "=== Poziom 1: Pliki istnieją ==="
check "projects/__init__.py"         "test -s src/proxym/projects/__init__.py"
check "tools/__init__.py"            "test -s src/proxym/tools/__init__.py"
check "tools/adapters.py"            "test -s src/proxym/tools/adapters.py"
check "tools/executor.py"            "test -s src/proxym/tools/executor.py"
check "observability/__init__.py"    "test -s src/proxym/observability/__init__.py"
check "observability/watchdog.py"    "test -s src/proxym/observability/watchdog.py"
check "observability/repair_agent.py" "test -s src/proxym/observability/repair_agent.py"
check "dashboard/_projects_api.py"   "test -s src/proxym/dashboard/_projects_api.py"
check "dashboard/_tools_api.py"      "test -s src/proxym/dashboard/_tools_api.py"
check "dashboard/_tickets_api.py"    "test -s src/proxym/dashboard/_tickets_api.py"

echo ""
echo "=== Poziom 2: Import działa ==="
check "import proxym"                 "$PY -c 'import proxym'"
check "import proxym.projects"        "$PY -c 'from proxym.projects import ProjectRegistry'"
check "import proxym.tools"           "$PY -c 'from proxym.tools import ToolRegistry'"
check "import proxym.tools.executor"  "$PY -c 'from proxym.tools.executor import ToolExecutor'"
check "import proxym.tools.adapters"  "$PY -c 'from proxym.tools.adapters import AiderAdapter'"
check "import proxym.observability"   "$PY -c 'from proxym.observability import log_call'"
check "import proxym.observability.watchdog" "$PY -c 'from proxym.observability.watchdog import HealthWatchdog'"
check "import proxym.observability.repair_agent" "$PY -c 'from proxym.observability.repair_agent import RepairAgent'"
check "import proxym.main (FastAPI)"  "$PY -c 'from proxym.main import app; assert len(app.routes) > 10'"
check "all modules import"           "$PY -c '
import importlib, pkgutil, sys
sys.path.insert(0, \"src\")
errs = []
for info in pkgutil.walk_packages([\"src/proxym\"], prefix=\"proxym.\"):
    try: importlib.import_module(info.name)
    except Exception as e: errs.append(str(e))
assert not errs, errs
'"

echo ""
echo "=== Poziom 3: Testy jednostkowe ==="
PYTEST="$PY -m pytest -x -q"
check "test_projects.py"       "$PYTEST tests/test_projects.py"
check "test_executor.py"       "$PYTEST tests/test_executor.py"
check "test_observability.py"  "$PYTEST tests/test_observability.py"
check "test_repair_agent.py"   "$PYTEST tests/test_repair_agent.py"
check "test_tool_adapters.py"  "$PYTEST tests/test_tool_adapters.py"
check "test_tools_api.py"      "$PYTEST tests/test_tools_api.py"
check "test_tools_registry.py" "$PYTEST tests/test_tools_registry.py"
check "test_prompt_builder.py" "$PYTEST tests/test_prompt_builder.py"
check "test_tickets.py"        "$PYTEST tests/test_tickets.py"
check "test_tickets_api.py"    "$PYTEST tests/test_tickets_api.py"
check "test_cli_coverage.py"   "$PYTEST tests/test_cli_coverage.py"
check "test_project_e2e.py"    "$PYTEST tests/test_project_e2e.py"
check "e2e scenarios (all)"    "$PYTEST tests/e2e/"

echo ""
echo "=== Poziom 4: REST API (jeśli serwer działa) ==="
BASE="http://localhost:4000"
AUTH="Authorization: Bearer sk-proxy-local-dev"
if curl -sf $BASE/health >/dev/null 2>&1; then
  check "GET /health"               "curl -sf $BASE/health"
  check "GET /v1/models"            "curl -sf -H \"$AUTH\" $BASE/v1/models"
  check "GET /dashboard"            "curl -sf $BASE/dashboard"
  check "GET /dashboard/projects"   "curl -sf $BASE/dashboard/projects"
  check "GET /dashboard/tickets"    "curl -sf $BASE/dashboard/tickets"
  check "GET /dashboard/tools"      "curl -sf $BASE/dashboard/tools"
  check "GET /observability/health-summary" "curl -sf -H \"$AUTH\" $BASE/observability/health-summary"
  check "GET /observability/errors"  "curl -sf -H \"$AUTH\" $BASE/observability/errors"
  check "GET /observability/logs"    "curl -sf -H \"$AUTH\" $BASE/observability/logs"
else
  skip "REST API tests" "server not running (start with: make up)"
fi

echo ""
echo "=== Poziom 5: CLI workflow (jeśli serwer działa) ==="
PROXYM_BIN=".venv/bin/proxym"
PROXYM="$PROXYM_BIN --proxy $BASE --key sk-proxy-local-dev"
if curl -sf $BASE/health >/dev/null 2>&1 && [ -x "$PROXYM_BIN" ]; then
  # 5a. Skanuj projekty z /home/tom/github/wronai
  check "proxym project scan"       "$PROXYM project scan /home/tom/github/wronai"
  check "proxym project list"       "$PROXYM project list"

  # 5b. Utwórz ticket testowy na projekcie proxym
  TICKET_OUT=$($PROXYM ticket add 'Evaluate: test ticket — auto-created by evaluate_llm_work.sh' -p proxym --type task 2>&1)
  TICKET_ID=$(echo "$TICKET_OUT" | grep -oP 'TKT-[A-F0-9]{6}' | head -1)
  if [ -n "$TICKET_ID" ]; then
    echo "  ✅ ticket created: $TICKET_ID"
    PASS=$((PASS+1))
  else
    echo "  ❌ ticket create failed: $TICKET_OUT"
    FAIL=$((FAIL+1))
  fi

  check "proxym ticket list"         "$PROXYM ticket list 2>&1"
  check "proxym ticket board"        "$PROXYM ticket board 2>&1"

  # 5c. Observability
  check "proxym obs errors"          "$PROXYM obs errors"
  check "proxym obs health"          "$PROXYM obs health"
  check "proxym obs logs -n 5"       "$PROXYM obs logs -n 5"

  # 5d. Queue
  check "proxym q (queue)"           "$PROXYM q"

  # 5e. Dry-run dispatch
  check "proxym do --dry-run"        "$PROXYM do 'evaluate test task' --on proxym --dry-run"

  # 5f. Multi-project ticket creation
  for proj in clonebox code2llm stts toonic devix; do
    OUT=$($PROXYM ticket add "Evaluate: auto-test docs update for $proj" -p $proj --type docs 2>&1)
    TID=$(echo "$OUT" | grep -oP 'TKT-[A-F0-9]{6}' | head -1)
    if [ -n "$TID" ]; then
      echo "  ✅ ticket $proj: $TID"
      PASS=$((PASS+1))
    else
      echo "  ❌ ticket $proj failed: $OUT"
      FAIL=$((FAIL+1))
    fi
  done
else
  skip "CLI workflow tests" "server not running or proxym not installed"
fi

echo ""
echo "=== Analiza jakości ==="
# Stub tests count
STUBS=$(grep -rn '^\s*pass\s*$' tests/ --include="*.py" | grep -v __pycache__ | grep -v conftest | wc -l)
echo "  📊 Stub tests (pass only): $STUBS"

# Total test count
TOTAL=$($PY -m pytest tests/ --collect-only -q --ignore=tests/gui/ 2>/dev/null | tail -3 | grep -oP '\d+(?= test)' || echo "?")
echo "  📊 Total tests collected: $TOTAL"

echo ""
echo "================================"
echo "  PASS: $PASS  FAIL: $FAIL  SKIP: $SKIP"
if [ $((PASS+FAIL)) -gt 0 ]; then
  echo "  Score: $PASS / $((PASS+FAIL)) ($(( PASS * 100 / (PASS+FAIL) ))%)"
fi
echo "================================"

if [ $FAIL -gt 0 ]; then
  echo ""
  echo "  ⚠️  $FAIL checks failed."
  echo "  Run failed checks individually with -v for details."
  exit 1
fi
