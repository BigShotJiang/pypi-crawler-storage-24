#!/usr/bin/env python3
"""
proxym-voice-chat — Głosowy interfejs do proxym
Obsługuje STT (Speech-to-Text) i TTS (Text-to-Speech)

Użycie:
    ./proxym-voice-chat.py           # STT only
    ./proxym-voice-chat.py --tts     # STT + TTS (pełna pętla głosowa)
    ./proxym-voice-chat.py --lang en  # Język angielski
"""

import sys
import argparse
import subprocess
from pathlib import Path

# Konfiguracja
PROXY_DIR = Path("/home/tom/github/wronai/proxy")
VENV_PYTHON = PROXY_DIR / ".venv/bin/python"

def check_voice_deps():
    """Sprawdź czy zależności głosowe są zainstalowane."""
    try:
        import faster_whisper
        import sounddevice
        import numpy
        return True
    except ImportError:
        return False

def install_voice_deps():
    """Zainstaluj zależności głosowe."""
    print("📦 Instalacja zależności głosowych...")
    pip = PROXY_DIR / ".venv/bin/pip"
    subprocess.run([str(pip), "install", "faster-whisper", "sounddevice", "numpy", "-q"], check=True)
    print("✅ Zależności zainstalowane")

def main():
    parser = argparse.ArgumentParser(description="Proxym Voice Chat")
    parser.add_argument("--voice", action="store_true", default=True, help="Włącz STT (domyślnie włączone)")
    parser.add_argument("--tts", action="store_true", help="Włącz TTS (odpowiedzi głosowe)")
    parser.add_argument("--lang", default="pl", choices=["pl", "en"], help="Język (pl/en)")
    parser.add_argument("--duration", type=float, default=5.0, help="Czas nagrywania (sekundy)")
    args = parser.parse_args()

    # Sprawdź/zainstaluj zależności
    if not check_voice_deps():
        install_voice_deps()
        # Restart po instalacji
        print("🔄 Restartowanie...")
        import os
        os.execv(str(VENV_PYTHON), [str(VENV_PYTHON), __file__] + sys.argv[1:])

    # Uruchom voice chat przez CLI
    cmd = [str(VENV_PYTHON), "-m", "proxym", "chat", "--voice"]
    if args.tts:
        cmd.append("--tts")
    
    print("🎤 Proxym Voice Chat")
    print(f"   Język: {args.lang}")
    print(f"   TTS: {'TAK' if args.tts else 'NIE'}")
    print("")
    print("   Mów do mikrofonu po usłyszeniu 'Słucham...'")
    print("   Ctrl+C aby zakończyć")
    print("")
    
    try:
        subprocess.run(cmd, cwd=str(PROXY_DIR))
    except KeyboardInterrupt:
        print("\n👋 Do widzenia!")

if __name__ == "__main__":
    main()
