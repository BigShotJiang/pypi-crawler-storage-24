#!/bin/bash
# proxym-voice-server — Web server z obsługą głosową (STT + TTS)
# Uruchamia: proxym serve + voice chat w osobnych procesach

set -e

PROXY_DIR="/home/tom/github/wronai/proxy"
VENV_PYTHON="$PROXY_DIR/.venv/bin/python"
VENV_PIP="$PROXY_DIR/.venv/bin/pip"

# Kolory
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== proxym Voice Server ===${NC}"
echo ""

# Sprawdź czy zależności głosowe są zainstalowane
echo -e "${YELLOW}Sprawdzanie zależności głosowych...${NC}"
if ! $VENV_PYTHON -c "import faster_whisper, sounddevice, numpy" 2>/dev/null; then
    echo -e "${YELLOW}Instalacja zależności głosowych...${NC}"
    $VENV_PIP install faster-whisper sounddevice numpy -q
fi
echo -e "${GREEN}Zależności głosowe: OK${NC}"
echo ""

# Pobierz port z konfiguracji
DEV_PORT=$($VENV_PYTHON -c "from proxym.config import get_settings; print(get_settings().dev_port)")
DASHBOARD_PORT=4001

echo -e "${BLUE}Konfiguracja:${NC}"
echo "  DEV_PORT (API):    $DEV_PORT"
echo "  DASHBOARD_PORT:    $DASHBOARD_PORT"
echo "  Voice language:    pl (Polish)"
echo ""

# Zatrzymaj poprzednie instancje
echo -e "${YELLOW}Zatrzymywanie poprzednich instancji...${NC}"
pkill -f "proxym serve.*$DEV_PORT" 2>/dev/null || true
fuser -k $DEV_PORT/tcp 2>/dev/null || true
fuser -k $DASHBOARD_PORT/tcp 2>/dev/null || true
sleep 2

# Utwórz katalog na overlay files (jeśli nie istnieje)
mkdir -p /var/tmp/proxym-overlays
chmod 777 /var/tmp/proxym-overlays 2>/dev/null || true

echo -e "${GREEN}=== Uruchamianie serwera proxym ===${NC}"
echo -e "Dashboard: ${BLUE}http://localhost:$DASHBOARD_PORT/dashboard${NC}"
echo -e "API:       ${BLUE}http://localhost:$DEV_PORT${NC}"
echo ""
echo -e "${YELLOW}Aby użyć głosu:${NC}"
echo "  1. Otwórz nowy terminal"
echo "  2. cd $PROXY_DIR"
echo "  3. $VENV_PYTHON -m proxym chat --voice --tts"
echo ""
echo -e "${YELLOW}Logi serwera (Ctrl+C aby zatrzymać):${NC}"
echo "======================================"

# Uruchom serwer z auto-reload
cd "$PROXY_DIR"
exec $VENV_PYTHON -m proxym serve --reload --port $DEV_PORT
