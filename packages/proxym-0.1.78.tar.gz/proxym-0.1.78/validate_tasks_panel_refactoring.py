#!/usr/bin/env python3
"""Validation script for TasksPanel refactoring."""

import sys
import os

# Add parent directory to path to import utils
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.main import create_validation_main
from utils.validation_common import (
    validate_jsx_component,
    count_complexity,
    print_validation_header,
    print_complexity_analysis,
    print_summary_footer,
    run_validation,
)


def main():
    """Validate TasksPanel refactoring."""
    return create_validation_main(
        title="TasksPanel Refactoring",
        components={
            'TasksViewControls.jsx': ['TasksViewControls'],
            'TasksBoard.jsx': ['TasksBoard'],
            'TasksList.jsx': ['TasksList'],
            'TasksTable.jsx': ['TasksTable'],
            'TasksRecentJobs.jsx': ['TasksRecentJobs'],
            'TasksPanelRefactored.jsx': ['TasksPanelRefactored']
        },
        base_path='src/proxym/dashboard/components/tasks',
        original_file='src/proxym/dashboard/components/tasks.jsx',
        benefits_bullet='task management'
    )

if __name__ == "__main__":
    main()
