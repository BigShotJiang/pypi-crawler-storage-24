// =============================================================================
// DEPRECATED: This file is kept for backward compatibility only.
// The canonical source is: src/proxym/dashboard/panel.jsx
// The FastAPI server now serves panel.jsx at /proxym-dashboard.jsx
// =============================================================================
console.warn("[proxym] frontend/proxym-dashboard.jsx is deprecated. The server now serves src/proxym/dashboard/panel.jsx as the canonical source.");
