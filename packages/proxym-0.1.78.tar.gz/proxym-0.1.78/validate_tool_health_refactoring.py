#!/usr/bin/env python3
"""Validation script for ToolHealth refactoring."""

import sys
import os

# Add parent directory to path to import utils
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.main import create_validation_main
from utils.validation_common import (
    validate_jsx_component,
    count_complexity,
    print_validation_header,
    print_complexity_analysis,
    print_summary_footer,
    run_validation,
)


def main():
    """Validate ToolHealth refactoring."""
    return create_validation_main(
        title="ToolHealth Refactoring",
        components={
            'ToolHealthCard.jsx': ['ToolHealthCard'],
            'ToolHealthDisplay.jsx': ['ToolHealthDisplay'],
            'ToolHealthPanelRefactored.jsx': ['ToolHealthPanelRefactored'],
            'ToolAvailabilityAlert.jsx': ['ToolAvailabilityAlert'],
            'BulkAutoFix.jsx': ['BulkAutoFix'],
            'DiagnosticActions.jsx': ['DiagnosticActions']
        },
        base_path='src/proxym/dashboard/components/tools',
        original_file='src/proxym/dashboard/components/tools.jsx',
        benefits_bullet='health monitoring'
    )

if __name__ == "__main__":
    main()
