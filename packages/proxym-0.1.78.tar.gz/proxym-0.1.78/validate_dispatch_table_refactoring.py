#!/usr/bin/env python3
"""Validation script for TicketDispatchTable refactoring."""

import sys
import os

# Add parent directory to path to import utils
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.main import create_validation_main
from utils.validation_common import (
    validate_jsx_component,
    count_complexity,
    print_validation_header,
    print_complexity_analysis,
    print_summary_footer,
    run_validation,
)


def main():
    """Validate TicketDispatchTable refactoring."""
    return create_validation_main(
        title="TicketDispatchTable Refactoring",
        components={
            'DispatchTableHeader.jsx': ['DispatchTableHeader'],
            'DispatchTableRow.jsx': ['DispatchTableRow'],
            'TicketStatusBadges.jsx': ['TicketStatusBadges'],
            'ProjectInfoResolver.jsx': ['ProjectInfoResolver'],
            'DispatchActions.jsx': ['DispatchActions'],
            'TicketDispatchTableRefactored.jsx': ['TicketDispatchTableRefactored']
        },
        base_path='src/proxym/dashboard/components/tools',
        original_file='src/proxym/dashboard/components/tools.jsx',
        benefits_bullet='dispatch logic'
    )

if __name__ == "__main__":
    main()
