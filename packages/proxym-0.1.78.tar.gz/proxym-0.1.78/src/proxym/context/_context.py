"""ProjectContext dataclass."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ProjectContext:
    """Detected project context for a request.

    Populated by ``detector.detect_project`` from request headers,
    message content, and filesystem inspection.
    """

    project_id: str = ""               # hash(git_remote) or path-based ID
    project_root: str = ""             # e.g. ~/github/proxym
    project_name: str = ""             # basename, e.g. "proxym"
    stack: list[str] = field(default_factory=list)      # ["python", "fastapi"]
    git_remote: str = ""               # e.g. git@github.com:wronai/proxym.git
    active_mcp_servers: list[str] = field(default_factory=list)
    session_id: str = ""               # UUID of agent session
    token_budget_remaining: int = 0

    @staticmethod
    def make_project_id(path: str = "", remote: str = "") -> str:
        """Deterministic project ID from git remote or path."""
        seed = remote or path
        if not seed:
            return ""
        return hashlib.sha256(seed.encode()).hexdigest()[:12]
