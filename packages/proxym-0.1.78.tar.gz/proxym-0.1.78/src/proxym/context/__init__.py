"""Context & Tool Router — project-aware request enrichment.

Detects the active project from request headers, message content, and filesystem,
then selects appropriate MCP tools and manages agent session state.

Public API:
  ProjectContext  — dataclass describing the active project
  detect_project  — detect project from a chat completion request
  select_tools    — pick MCP servers for a given project + analysis
  AgentSession    — stateful session across requests
"""

from __future__ import annotations

from proxym.context._context import ProjectContext
from proxym.context.detector import detect_project
from proxym.context.session import AgentSession, SessionStore

__all__ = [
    "ProjectContext",
    "detect_project",
    "AgentSession",
    "SessionStore",
]
