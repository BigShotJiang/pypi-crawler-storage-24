"""API sub-package — routers split from the monolithic main.py.

Import the individual routers and include them in the FastAPI app.
"""

from proxym.api.completions import router as completions_router
from proxym.api.console import router as console_router
from proxym.api.context_api import router as context_router
from proxym.api.frontend import router as frontend_router
from proxym.api.system import router as system_router
from proxym.api.diagnostics import router as tests_router
from proxym.api.vscode_api import router as vscode_router
from proxym.api.voice_actions import router as voice_actions_router

__all__ = [
    "completions_router",
    "console_router",
    "context_router",
    "frontend_router",
    "system_router",
    "tests_router",
    "vscode_router",
    "voice_actions_router",
]
