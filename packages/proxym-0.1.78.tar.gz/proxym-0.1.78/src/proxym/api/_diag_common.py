"""Shared helpers for diagnostic checks."""
from __future__ import annotations

import httpx

# Internal port where uvicorn listens inside container (always 4000)
INTERNAL_PORT = 4000


async def _probe_first_ok(urls: list[str]) -> tuple[str | None, httpx.Response | None, str | None]:
    async with httpx.AsyncClient(timeout=5.0) as client:
        last_err: str | None = None
        for url in urls:
            try:
                resp = await client.get(url, follow_redirects=True)
                if resp.status_code < 500:
                    return url, resp, None
            except Exception as e:
                last_err = str(e)
        return None, None, last_err
