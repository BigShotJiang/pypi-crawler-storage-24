# Re-export for convenience
from proxym.watch import DeltaWatchClient

__all__ = ["DeltaWatchClient"]
