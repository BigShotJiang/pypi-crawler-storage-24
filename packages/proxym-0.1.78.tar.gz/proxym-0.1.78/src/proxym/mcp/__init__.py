"""MCP (Model Context Protocol) integration — registry, routing, and client.

Manages available MCP servers, routes tool requests to the appropriate server,
and provides an HTTP client for communicating with MCP endpoints.

Public API:
  MCPServerSpec  — specification of a registered MCP server
  MCPRegistry    — registry of available MCP servers
  MCPRouter      — routes tasks to appropriate MCP servers
  MCPClient      — HTTP client for MCP server communication
"""

from __future__ import annotations

from proxym.mcp.registry import MCPRegistry, MCPServerSpec
from proxym.mcp.router import MCPRouter
from proxym.mcp.client import MCPClient

__all__ = [
    "MCPServerSpec",
    "MCPRegistry",
    "MCPRouter",
    "MCPClient",
]
