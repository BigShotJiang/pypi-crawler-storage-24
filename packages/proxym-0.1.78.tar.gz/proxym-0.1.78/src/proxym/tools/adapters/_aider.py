"""Aider CLI adapter."""
from __future__ import annotations

from proxym.tools.adapters._base import BaseAdapter


class AiderAdapter(BaseAdapter):
    """Adapter for aider CLI."""

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        args = ["aider", "--yes-always", "--no-auto-commits"]
        if mode == "architect":
            args.append("--architect")
        if model:
            args.extend(["--model", model])
        if files:
            for f in files:
                args.append(f)
        args.extend(["--message", prompt])
        return args
