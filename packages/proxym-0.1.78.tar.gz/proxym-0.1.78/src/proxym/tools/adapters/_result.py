"""ToolResult dataclass — outcome of a tool execution."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolResult:
    """Result of a tool execution."""
    tool: str
    ticket_id: str
    exit_code: int = -1
    stdout: str = ""
    stderr: str = ""
    duration_s: float = 0
    files_changed: list[str] = field(default_factory=list)
    execution_metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def success(self) -> bool:
        return self.exit_code == 0

    def summary(self) -> dict[str, Any]:
        s = {
            "tool": self.tool,
            "ticket_id": self.ticket_id,
            "success": self.success,
            "exit_code": self.exit_code,
            "duration_s": round(self.duration_s, 2),
            "files_changed": self.files_changed,
            "stdout_lines": len(self.stdout.splitlines()),
            "stderr_lines": len(self.stderr.splitlines()),
        }
        if self.execution_metadata:
            s["execution"] = self.execution_metadata
            s["execution_metadata"] = self.execution_metadata
        return s
