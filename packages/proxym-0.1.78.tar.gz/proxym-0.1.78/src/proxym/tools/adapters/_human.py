"""Human/manual task adapter."""
from __future__ import annotations

import structlog

from proxym.tools.adapters._base import BaseAdapter
from proxym.tools.adapters._result import ToolResult

logger = structlog.get_logger()


class HumanAdapter(BaseAdapter):
    """Adapter for human/manual tasks — returns a result indicating manual action required."""

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        """Human tasks don't have CLI args."""
        return []

    async def run(
        self,
        prompt: str,
        project_dir: str,
        ticket_id: str = "",
        mode: str = "",
        model: str = "",
        files: list[str] | None = None,
        timeout: float = 30,
    ) -> ToolResult:
        """Return a result indicating this is a manual task."""
        import time
        t0 = time.monotonic()
        logger.info("human_adapter_run", tool=self.tool.name, ticket_id=ticket_id)
        duration = time.monotonic() - t0
        stdout = (
            "═══ proxym Human/Manual Task ═══\n"
            f"Tool: {self.tool.name}\n"
            f"Ticket: {ticket_id}\n"
            f"This task requires human action and cannot be executed automatically.\n"
            f"Please review the ticket and complete the required steps manually.\n"
            "═══════════════════════════════════\n"
        )
        return ToolResult(
            tool=self.tool.name,
            ticket_id=ticket_id,
            exit_code=0,
            stdout=stdout,
            stderr="",
            duration_s=duration,
            execution_metadata={"adapter": "human", "manual": True, "project_dir": project_dir},
        )
