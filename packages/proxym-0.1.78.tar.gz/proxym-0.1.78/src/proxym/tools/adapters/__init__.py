"""Tool adapters — launch and interact with AI dev tools.

Each adapter knows how to:
  1. Build CLI arguments from a prompt + config
  2. Launch the tool process
  3. Stream/capture output
  4. Report completion status
"""
from __future__ import annotations

from proxym.tools import ToolDefinition, ToolRegistry
from proxym.tools.adapters._result import ToolResult
from proxym.tools.adapters._base import BaseAdapter
from proxym.tools.adapters._aider import AiderAdapter
from proxym.tools.adapters._claude_code import ClaudeCodeAdapter
from proxym.tools.adapters._vscode import VSCodeAdapter
from proxym.tools.adapters._shell import ShellAdapter
from proxym.tools.adapters._human import HumanAdapter
from proxym.tools.adapters._llm_fallback import _llm_fallback_execute

# ── Adapter registry ─────────────────────────────────────

_ADAPTER_MAP: dict[str, type[BaseAdapter]] = {
    "aider": AiderAdapter,
    "claude-code": ClaudeCodeAdapter,
    "vscode": VSCodeAdapter,
    "roo-code": ShellAdapter,
    "cline": ShellAdapter,
    "windsurf": ShellAdapter,
    "cursor": ShellAdapter,
    "browser": ShellAdapter,
    "human": HumanAdapter,
}


def get_adapter(tool_name: str) -> BaseAdapter | None:
    """Return an adapter instance for the named tool, or None."""
    registry = ToolRegistry.get()
    tool = registry.get_tool(tool_name)
    if not tool:
        return None
    adapter_cls = _ADAPTER_MAP.get(tool_name)
    if not adapter_cls:
        return None
    return adapter_cls(tool)


def register_adapter(tool_name: str, adapter_cls: type[BaseAdapter]) -> None:
    """Register a custom adapter class for a tool."""
    _ADAPTER_MAP[tool_name] = adapter_cls


__all__ = [
    "ToolResult",
    "BaseAdapter",
    "AiderAdapter",
    "ClaudeCodeAdapter",
    "VSCodeAdapter",
    "ShellAdapter",
    "HumanAdapter",
    "get_adapter",
    "register_adapter",
    "_ADAPTER_MAP",
    "_llm_fallback_execute",
]
