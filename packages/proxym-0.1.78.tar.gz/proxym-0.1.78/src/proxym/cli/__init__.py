"""CLI sub-package — command handlers split from the monolithic ctl.py."""
