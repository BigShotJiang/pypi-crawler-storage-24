"""Click wrappers: vscode group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import vscode as vscode_cli
from proxym.cli._groups._shared import passthrough
from proxym.cli._groups._shared import register_commands


@click.group(name="vscode")
def vscode():
    """Manage VS Code Web service."""
    pass


register_commands(vscode, [
    ("start",  vscode_cli.cmd_vscode_start,  "Start VS Code Web (docker compose up vscode)."),
    ("stop",   vscode_cli.cmd_vscode_stop,   "Stop VS Code Web."),
    ("open",   vscode_cli.cmd_vscode_open,   "Open VS Code Web in browser."),
    ("logs",   vscode_cli.cmd_vscode_logs,   "Show VS Code Web logs."),
    ("status", vscode_cli.cmd_vscode_status, "Show VS Code Web container status."),
    ("build",  vscode_cli.cmd_vscode_build,  "Rebuild VS Code Web image."),
], passthrough)
