"""Click wrappers: vm group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import vms as vms_cli
from proxym.cli._groups._shared import (
    make_args as _make_args,
    passthrough,
    passthrough_arg,
)


@click.group(name="vm")
def vm():
    """Manage VMs."""
    pass


vm.add_command(passthrough("list", vms_cli.cmd_vm_list, "List VMs."))

# ── Simple vm_id passthrough commands ────────────────────────

for _name, _handler, _help in [
    ("open",    vms_cli.cmd_vm_open,    "Open SPICE viewer."),
    ("logs",    vms_cli.cmd_vm_logs,    "Show VM logs."),
    ("delete",  vms_cli.cmd_vm_delete,  "Delete a VM."),
    ("console", vms_cli.cmd_vm_console, "Open web console for a VM (prints noVNC URL)."),
]:
    vm.add_command(passthrough_arg(_name, _handler, _help, arg_name="vm_id"))

# ── VM lifecycle actions (same handler, different action) ────

for _name, _action, _help in [
    ("start",  "start",  "Start a VM."),
    ("pause",  "pause",  "Pause a VM."),
    ("resume", "resume", "Resume a VM."),
]:
    vm.add_command(passthrough_arg(_name, vms_cli.cmd_vm_action, _help, arg_name="vm_id", action=_action))

# ── Commands with extra options (kept explicit) ──────────────

@vm.command(name="create")
@click.option("--name", default="", help="VM name")
@click.option("--tool", default="", help="Tool name")
@click.option("--account", default="", help="Account ID")
@click.option("--mount", default="", help="Mount path")
@click.option("--project", default="", help="Project path")
@click.option("--cpus", type=int, default=4, help="CPU count")
@click.option("--memory", type=int, default=6144, help="Memory in MB")
@click.option("--image", default="ubuntu-24.04", help="OS image")
@click.pass_context
def vm_create(ctx: click.Context, name: str, tool: str, account: str,
              mount: str, project: str, cpus: int, memory: int, image: str):
    """Create VM."""
    args = _make_args(ctx, name=name, tool=tool, account=account, mount=mount,
                     project=project, cpus=cpus, memory=memory, image=image)
    vms_cli.cmd_vm_create(args)


@vm.command(name="stop")
@click.argument("vm_id")
@click.option("--force", is_flag=True, help="Force stop")
@click.pass_context
def vm_stop(ctx: click.Context, vm_id: str, force: bool):
    """Stop a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="stop", force=force)
    vms_cli.cmd_vm_action(args)


@vm.command(name="snapshot")
@click.argument("vm_id")
@click.option("--name", default=None, help="Snapshot name")
@click.pass_context
def vm_snapshot(ctx: click.Context, vm_id: str, name: str | None):
    """Snapshot a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="snapshot", name=name)
    vms_cli.cmd_vm_action(args)


@vm.command(name="switch")
@click.argument("vm_id")
@click.option("--project", required=True, help="Project path")
@click.pass_context
def vm_switch(ctx: click.Context, vm_id: str, project: str):
    """Switch project in VM."""
    args = _make_args(ctx, vm_id=vm_id, project=project)
    vms_cli.cmd_vm_switch(args)


@vm.command(name="ssh")
@click.argument("vm_id")
@click.option("--user", default="dev", help="SSH user")
@click.pass_context
def vm_ssh(ctx: click.Context, vm_id: str, user: str):
    """SSH into VM."""
    args = _make_args(ctx, vm_id=vm_id, user=user)
    vms_cli.cmd_vm_ssh(args)


@vm.command(name="bulk-delete")
@click.option("--vm-ids", required=True, help="Comma-separated VM IDs to delete")
@click.pass_context
def vm_bulk_delete(ctx: click.Context, vm_ids: str):
    """Delete multiple VMs."""
    args = _make_args(ctx, vm_ids=vm_ids)
    vms_cli.cmd_vm_bulk_delete(args)
