"""Click wrappers: context group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import context as context_cli
from proxym.cli._groups._shared import make_args as _make_args, passthrough_fmt


@click.group(name="context")
def context():
    """Manage context, sessions, and MCP servers."""
    pass


@context.command(name="delta")
@click.option("--project-id", default="", help="Project ID")
@click.option("--diff-text", default="", help="Diff text")
@click.option("--file", "file", default=None, help="Read diff from file")
@click.option("--version", type=int, default=None, help="Delta version")
@click.option("--token-estimate", type=int, default=None, help="Estimated tokens")
@click.pass_context
def context_delta(ctx: click.Context, project_id, diff_text, file, version, token_estimate):
    """Push a context delta to the proxy."""
    args = _make_args(ctx, project_id=project_id, diff_text=diff_text,
                     file=file, version=version, token_estimate=token_estimate)
    context_cli.cmd_context_delta(args)


@context.command(name="detect")
@click.option("--message", default=None, help="User message to detect context from")
@click.option("--system-prompt", default=None, help="System prompt")
@click.option("--paths", default=None, help="Comma-separated file paths")
@click.pass_context
def context_detect(ctx: click.Context, message, system_prompt, paths):
    """Detect project context from messages or paths."""
    args = _make_args(ctx, message=message, system_prompt=system_prompt, paths=paths)
    context_cli.cmd_context_detect(args)


for _name, _handler, _help in [
    ("stats",    context_cli.cmd_context_stats, "Show context store statistics."),
    ("sessions", context_cli.cmd_sessions_list, "List active agent sessions."),
    ("mcp",      context_cli.cmd_mcp_servers,   "List registered MCP servers."),
]:
    context.add_command(passthrough_fmt(_name, _handler, _help))
