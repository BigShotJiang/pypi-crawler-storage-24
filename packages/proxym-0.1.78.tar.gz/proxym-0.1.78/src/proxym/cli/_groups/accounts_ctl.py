"""Click wrappers: accounts group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import accounts as accounts_cli
from proxym.cli._groups._shared import make_args as _make_args


@click.group(name="accounts")
def accounts():
    """Manage accounts."""
    pass


@accounts.command(name="list")
@click.pass_context
def accounts_list(ctx: click.Context):
    """List accounts."""
    args = _make_args(ctx)
    accounts_cli.cmd_accounts_list(args)


@accounts.command(name="add")
@click.option("--name", required=True, help="Account name")
@click.option("--provider", required=True, help="Provider name")
@click.option("--api-key", default="", help="API key")
@click.option("--email", default="", help="Email")
@click.option("--daily-budget", type=float, default=5.0, help="Daily budget")
@click.option("--monthly-budget", type=float, default=60.0, help="Monthly budget")
@click.option("--tags", default="", help="Tags")
@click.pass_context
def accounts_add(ctx: click.Context, name: str, provider: str, api_key: str,
                 email: str, daily_budget: float, monthly_budget: float, tags: str):
    """Add account."""
    args = _make_args(ctx, name=name, provider=provider, api_key=api_key,
                     email=email, daily_budget=daily_budget, monthly_budget=monthly_budget, tags=tags)
    accounts_cli.cmd_accounts_add(args)


@accounts.command(name="costs")
@click.pass_context
def accounts_costs(ctx: click.Context):
    """Show cost breakdown."""
    args = _make_args(ctx)
    accounts_cli.cmd_accounts_costs(args)


@accounts.command(name="get")
@click.argument("account_id")
@click.pass_context
def accounts_get(ctx: click.Context, account_id: str):
    """Show single account details."""
    args = _make_args(ctx, account_id=account_id)
    accounts_cli.cmd_accounts_get(args)


@accounts.command(name="delete")
@click.argument("account_id")
@click.confirmation_option(prompt="Are you sure you want to delete this account?")
@click.pass_context
def accounts_delete(ctx: click.Context, account_id: str):
    """Delete an account."""
    args = _make_args(ctx, account_id=account_id)
    accounts_cli.cmd_accounts_delete(args)


@accounts.command(name="bind-tool")
@click.argument("account_id")
@click.option("--tool-type", required=True, help="Tool type (ide, browser, cli, agent)")
@click.option("--tool-name", required=True, help="Tool name (vscode, windsurf, cursor, aider, ...)")
@click.option("--vm-id", default="", help="VM ID to bind")
@click.option("--project-path", default="", help="Project path")
@click.option("--browser-profile", default="", help="Browser profile name")
@click.pass_context
def accounts_bind_tool(ctx: click.Context, account_id: str, tool_type: str,
                      tool_name: str, vm_id: str, project_path: str, browser_profile: str):
    """Bind a tool to an account."""
    args = _make_args(ctx, account_id=account_id, tool_type=tool_type,
                     tool_name=tool_name, vm_id=vm_id, project_path=project_path,
                     browser_profile=browser_profile)
    accounts_cli.cmd_accounts_bind_tool(args)
