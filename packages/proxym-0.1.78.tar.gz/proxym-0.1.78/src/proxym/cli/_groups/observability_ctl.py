"""Click wrappers: obs group — observability commands."""
from __future__ import annotations

import click

from proxym.cli import observability as obs_cli
from proxym.cli._groups._shared import make_args as _make_args


@click.group(name="obs")
def obs():
    """Observability: logs, errors, health, repair."""
    pass


@obs.command(name="errors")
@click.pass_context
def obs_errors(ctx: click.Context):
    """Show error summary from ring buffer."""
    args = _make_args(ctx)
    obs_cli.cmd_obs_errors(args)


@obs.command(name="health")
@click.pass_context
def obs_health(ctx: click.Context):
    """Show health summary and active issues."""
    args = _make_args(ctx)
    obs_cli.cmd_obs_health(args)


@obs.command(name="logs")
@click.option("-n", "--limit", default=50, type=int, help="Number of entries")
@click.option("--level", default=None, help="Filter by level")
@click.pass_context
def obs_logs(ctx: click.Context, limit: int, level: str | None):
    """Show recent observability logs from ring buffer."""
    args = _make_args(ctx, limit=limit, level=level)
    obs_cli.cmd_obs_logs(args)


@obs.command(name="repair")
@click.option("--error", default="", help="Error text to diagnose")
@click.option("--mode", default="suggest", type=click.Choice(["suggest", "apply"]), help="Repair mode")
@click.option("--from-logs", is_flag=True, help="Auto-diagnose from recent errors")
@click.pass_context
def obs_repair(ctx: click.Context, error: str, mode: str, from_logs: bool):
    """Run LLM repair agent on an error."""
    args = _make_args(ctx, error=error, mode=mode, from_logs=from_logs)
    obs_cli.cmd_obs_repair(args)
