"""Shared helpers for CLI command groups."""
from __future__ import annotations

import click


def make_args(ctx: click.Context, **kwargs):
    """Convert Click context to SimpleNamespace for legacy CLI handlers."""
    from proxym.ctl import _make_args as _ma
    return _ma(ctx, **kwargs)


# ── Command factories ────────────────────────────────────────

def passthrough(name: str, handler, help_text: str) -> click.Command:
    """Click command: make_args(ctx) → handler(args)."""
    @click.command(name=name, help=help_text)
    @click.pass_context
    def cmd(ctx: click.Context):
        args = make_args(ctx)
        handler(args)
    return cmd


def passthrough_fmt(name: str, handler, help_text: str) -> click.Command:
    """Click command with --format option: make_args(ctx, format=fmt) → handler(args)."""
    @click.command(name=name, help=help_text)
    @click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
    @click.pass_context
    def cmd(ctx: click.Context, fmt: str):
        args = make_args(ctx, format=fmt)
        handler(args)
    return cmd


def passthrough_arg(
    name: str, handler, help_text: str, arg_name: str = "id", **fixed_kwargs,
) -> click.Command:
    """Click command with argument: make_args(ctx, arg=val, **fixed) → handler(args)."""
    @click.command(name=name, help=help_text)
    @click.argument(arg_name)
    @click.pass_context
    def cmd(ctx: click.Context, **kwargs):
        args = make_args(ctx, **kwargs, **fixed_kwargs)
        handler(args)
    return cmd


def api_json_cmd(name: str, method: str, path: str, help_text: str) -> click.Command:
    """Click command: call API endpoint, print JSON."""
    @click.command(name=name, help=help_text)
    @click.pass_context
    def cmd(ctx: click.Context):
        from proxym.cli._client import make_client, print_json
        args = make_args(ctx)
        c = make_client(args.proxy, args.key)
        kw = {"json": {}} if method == "post" else {}
        r = getattr(c, method)(path, **kw)
        print_json(r.json())
    return cmd


def register_commands(group: click.Group, specs, factory, /, *factory_args, **factory_kwargs):
    """Register a batch of Click commands built from spec tuples."""
    for spec in specs:
        group.add_command(factory(*spec, *factory_args, **factory_kwargs))


def api_json_arg_cmd(
    name: str, method: str, path_tpl: str, help_text: str, arg_name: str = "id",
) -> click.Command:
    """Click command with argument: call API endpoint with path arg, print JSON."""
    @click.command(name=name, help=help_text)
    @click.argument(arg_name)
    @click.pass_context
    def cmd(ctx: click.Context, **kwargs):
        from proxym.cli._client import make_client, print_json
        args = make_args(ctx)
        c = make_client(args.proxy, args.key)
        path = path_tpl.format(**kwargs)
        kw = {"json": {}} if method == "post" else {}
        r = getattr(c, method)(path, **kw)
        print_json(r.json())
    return cmd
