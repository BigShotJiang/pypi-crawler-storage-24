"""Click wrappers: browser group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import browser as browser_cli
from proxym.cli._groups._shared import (
    make_args as _make_args,
    register_commands,
    passthrough,
    passthrough_arg,
)


@click.group(name="browser")
def browser():
    """Manage browser profiles."""
    pass


browser.add_command(passthrough("list", browser_cli.cmd_browser_list, "List host browser profiles."))

register_commands(browser, [
    ("sync",     browser_cli.cmd_browser_sync,     "Sync browser profile host <-> VM."),
    ("snapshot", browser_cli.cmd_browser_snapshot,  "Save browser state from VM."),
], passthrough_arg, arg_name="vm_id")


@browser.command(name="assign")
@click.argument("profile")
@click.option("--account", required=True, help="Account ID")
@click.pass_context
def browser_assign(ctx: click.Context, profile: str, account: str):
    """Assign profile to account."""
    args = _make_args(ctx, profile=profile, account=account)
    browser_cli.cmd_browser_assign(args)
