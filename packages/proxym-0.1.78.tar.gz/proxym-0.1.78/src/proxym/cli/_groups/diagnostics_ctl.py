"""Click wrappers: tests + diagnose groups — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import diagnostics as diag_cli
from proxym.cli._groups._shared import (
    make_args as _make_args,
    register_commands,
    passthrough,
    passthrough_fmt,
)


# ── Tests group ──────────────────────────────────────────────

@click.group(name="tests")
def tests():
    """Run system diagnostics."""
    pass


register_commands(tests, [
    ("vscode",      diag_cli.cmd_test_vscode,      "Test VS Code Web connectivity."),
    ("proxy",       diag_cli.cmd_test_proxy,        "Test LLM proxy connectivity."),
    ("agent-setup", diag_cli.cmd_test_agent_setup,  "Comprehensive agent readiness check."),
    ("agent",       diag_cli.cmd_test_agent,         "Test agent with a simple completion."),
], passthrough)

register_commands(tests, [
    ("status",     diag_cli.cmd_tests_status,     "Run all diagnostic tests."),
    ("providers",  diag_cli.cmd_test_providers,   "Check configured LLM providers."),
    ("extensions", diag_cli.cmd_test_extensions,  "Check installed VS Code extensions."),
], passthrough_fmt)


# ── Diagnose alias group ─────────────────────────────────────

@click.group(name="diagnose")
def diagnose():
    """Run diagnostics to verify system health (alias for 'tests')."""
    pass


register_commands(diagnose, [
    ("proxy",  diag_cli.cmd_test_proxy,   "Test proxy connectivity."),
    ("vscode", diag_cli.cmd_test_vscode,  "Test VS Code Web status."),
    ("agent",  diag_cli.cmd_test_agent,   "Test agent setup + completion."),
], passthrough)

register_commands(diagnose, [
    ("all",       diag_cli.cmd_tests_status,   "Run all diagnostic tests."),
    ("providers", diag_cli.cmd_test_providers, "Test provider configuration."),
], passthrough_fmt)


@diagnose.command(name="test")
@click.argument("test_name")
@click.pass_context
def diagnose_one(ctx: click.Context, test_name: str):
    """Run a specific test (vscode|proxy|roo|extensions|providers|copilot|agent-setup|agent)."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get(f"/tests/{test_name}", timeout=30)
    print_json(r.json())
