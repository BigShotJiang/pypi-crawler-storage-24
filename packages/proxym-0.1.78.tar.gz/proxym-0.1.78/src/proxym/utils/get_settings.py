"""Generic singleton utilities for lazy initialization."""

from typing import TypeVar, Type

T = TypeVar('T')


def get_singleton(instance_var: T | None, instance_class: Type[T]) -> T:
    """Generic singleton getter with lazy initialization."""
    if instance_var is None:
        instance_var = instance_class()
    return instance_var
