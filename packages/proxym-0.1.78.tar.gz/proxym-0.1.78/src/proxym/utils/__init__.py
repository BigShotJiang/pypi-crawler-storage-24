"""Shared utility functions used across proxym modules."""
