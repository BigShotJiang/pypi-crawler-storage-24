"""Helpers for working with LLM message lists."""
from __future__ import annotations


def extract_system_text(messages: list[dict]) -> str:
    """Extract the first system message's text content."""
    for msg in messages:
        if msg.get("role") == "system":
            content = msg.get("content", "")
            return content if isinstance(content, str) else ""
    return ""
