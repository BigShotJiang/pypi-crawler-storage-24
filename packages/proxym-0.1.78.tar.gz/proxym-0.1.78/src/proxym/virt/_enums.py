"""VM backend and state enumerations."""

from __future__ import annotations

from enum import Enum


class VMBackend(str, Enum):
    CLONEBOX = "clonebox"
    VIRSH = "virsh"


class VMState(str, Enum):
    STOPPED = "stopped"
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"
    CREATING = "creating"
