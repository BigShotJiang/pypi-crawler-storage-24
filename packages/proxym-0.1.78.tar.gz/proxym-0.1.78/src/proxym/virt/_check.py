"""CloneBox availability detection (cached)."""

from __future__ import annotations

_CLONEBOX_AVAILABLE: bool | None = None


def _check_clonebox() -> bool:
    """Check if clonebox is available (cached)."""
    global _CLONEBOX_AVAILABLE
    if _CLONEBOX_AVAILABLE is None:
        try:
            from proxym.virt.clonebox_adapter import CloneBoxAdapter
            _CLONEBOX_AVAILABLE = CloneBoxAdapter().is_available()
        except Exception:
            _CLONEBOX_AVAILABLE = False
    return _CLONEBOX_AVAILABLE
