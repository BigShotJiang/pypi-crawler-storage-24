"""VM Orchestrator: manage isolated dev environments via CloneBox or libvirt.

Each tool/account combo gets an isolated VM with:
  - Dedicated browser profile (preserved cache/sessions)
  - Shared code directory (virtiofs mount from host)
  - Network access through the AI proxy
  - Snapshot/restore for quick switching between projects

Architecture:
  Host (code + proxym)
    └── KVM VMs (via CloneBox or virsh)
        ├── windsurf-work       (Windsurf + browser profile A)
        ├── windsurf-oss        (Windsurf + browser profile B)
        ├── cursor-client1      (Cursor + separate account)
        └── vscode-dev          (VS Code + Roo Code)

Code is on the host, mounted read-write via virtiofs.
Browser profiles are inside the VM (isolated per account).

Backend selection:
  - If clonebox is installed → use CloneBoxAdapter (preferred)
  - Otherwise → fall back to direct virsh commands
"""

# Re-export all public symbols for backwards compatibility.
# Internal modules: _enums, _config, _check, _orchestrator

from proxym.virt._check import _check_clonebox
from proxym.virt._config import ProjectsConfig, VMConfig, VMStatus
from proxym.virt._enums import VMBackend, VMState
from proxym.virt._orchestrator import VMOrchestrator

__all__ = [
    "VMBackend",
    "VMState",
    "ProjectsConfig",
    "VMConfig",
    "VMStatus",
    "VMOrchestrator",
    "_check_clonebox",
]
