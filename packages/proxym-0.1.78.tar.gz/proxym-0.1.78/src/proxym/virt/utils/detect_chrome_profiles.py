"""Browser profile detection utilities."""

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from proxym.virt.browser_profiles import BrowserProfile

from proxym.virt.browser_profiles import _detect_chromium_family


def _detect_browser_profile(browser_name: str, config_path: str) -> list["BrowserProfile"]:
    """Generic browser profile detection function."""
    return _detect_chromium_family(
        base_dir=Path.home() / ".config" / config_path,
        browser=browser_name,
    )


def detect_chrome_profiles() -> list["BrowserProfile"]:
    """Detect Google Chrome profiles by parsing Local State."""
    return _detect_browser_profile("chrome", "google-chrome")


def detect_chromium_profiles() -> list["BrowserProfile"]:
    """Detect Chromium profiles by parsing Local State."""
    return _detect_browser_profile("chromium", "chromium")
