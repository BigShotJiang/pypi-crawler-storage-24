"""Shared singleton accessors for dashboard sub-modules."""
from __future__ import annotations

from proxym.accounts import AccountManager
from proxym.storage import DEFAULT_SQLITE_PATH
from proxym.virt import VMOrchestrator

_acct_mgr: AccountManager | None = None
_vm_orch: VMOrchestrator | None = None


def shared_accounts() -> AccountManager:
    """Return the singleton AccountManager."""
    global _acct_mgr
    if _acct_mgr is None:
        _acct_mgr = AccountManager(config_path=DEFAULT_SQLITE_PATH)
    return _acct_mgr


def shared_vms() -> VMOrchestrator:
    """Return the singleton VMOrchestrator."""
    global _vm_orch
    if _vm_orch is None:
        _vm_orch = VMOrchestrator()
    return _vm_orch
