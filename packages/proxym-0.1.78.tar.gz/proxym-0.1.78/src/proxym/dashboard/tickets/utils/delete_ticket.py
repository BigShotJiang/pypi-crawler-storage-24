"""Delete utilities for ticket dictionaries."""

from typing import Callable, Dict, Any


def delete_ticket_from_dict(
    tickets: Dict[str, Any], 
    ticket_id: str, 
    save_callback: Callable[[], None]
) -> bool:
    """Delete a ticket from the tickets dictionary.
    
    Args:
        tickets: Dictionary of tickets
        ticket_id: ID of the ticket to delete
        save_callback: Function to call to save after deletion
        
    Returns:
        True if ticket was deleted, False if not found
    """
    if ticket_id in tickets:
        del tickets[ticket_id]
        save_callback()
        return True
    return False
