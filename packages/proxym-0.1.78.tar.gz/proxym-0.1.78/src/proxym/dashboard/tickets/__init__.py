"""Tickets & Sprints — lightweight task management for multi-tool workflows.

Enables task tracking across different AI coding tools (VSCode/Roo Code,
aider, claude code, Windsurf, Cursor, etc.) via a REST API.

Data is stored in-memory with optional JSON persistence.
"""
from proxym.dashboard.tickets._models import (
    JobExecution,
    Milestone,
    MilestoneStatus,
    Sprint,
    SprintStatus,
    Ticket,
    TicketComment,
    TicketPriority,
    TicketStatus,
    TicketType,
    ToolAssignment,
)
from proxym.dashboard.tickets._manager import TicketManager

__all__ = [
    "JobExecution",
    "Milestone",
    "MilestoneStatus",
    "Sprint",
    "SprintStatus",
    "Ticket",
    "TicketComment",
    "TicketManager",
    "TicketPriority",
    "TicketStatus",
    "TicketType",
    "ToolAssignment",
]
