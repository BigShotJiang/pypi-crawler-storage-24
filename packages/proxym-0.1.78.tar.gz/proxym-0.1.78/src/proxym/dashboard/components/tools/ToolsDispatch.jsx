// ToolsDispatch - Component for tool dispatch functionality
import React from 'react';
import Card from '../Card';
import TicketDispatchTable from './TicketDispatchTableRefactored';

function ToolsDispatch({ tools, onRefresh }) {
  return (
    <Card title="Dispatch">
      <TicketDispatchTable tools={tools} onDispatch={onRefresh} />
    </Card>
  );
}

export default ToolsDispatch;
