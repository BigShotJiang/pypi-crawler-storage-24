// ProjectInfoResolver - Component for resolving and displaying project information
import React from 'react';

function ProjectInfoResolver({ projects }) {
  const getProjectInfo = (projectId) => {
    if (!projectId) {
      return { label: "—", path: "", project: null };
    }

    const project = projects.find(p => p.id === projectId) || null;
    if (!project) {
      return { label: projectId, path: "", project: null };
    }

    const path = project.local_path || project.source_path || "";
    return {
      label: project.name || projectId,
      path,
      project,
    };
  };

  const renderProjectInfo = (projectId) => {
    const projectInfo = getProjectInfo(projectId);
    
    return (
      <div className="max-w-[240px] flex flex-col gap-0.5" title={projectInfo.path || projectInfo.label}>
        <span className="text-xs font-medium text-gray-700 truncate">
          {projectInfo.label}
        </span>
        <span className="text-xs font-mono text-gray-400 truncate">
          {projectInfo.path || projectInfo.label}
        </span>
      </div>
    );
  };

  return {
    getProjectInfo,
    renderProjectInfo
  };
}

export default ProjectInfoResolver;
