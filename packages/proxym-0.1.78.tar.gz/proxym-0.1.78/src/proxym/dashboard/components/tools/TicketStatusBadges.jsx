// TicketStatusBadges - Component for rendering ticket status and priority badges
import React from 'react';

function TicketStatusBadges() {
  const getStatusBadgeClass = (status) => {
    if (status === 'done') return 'bg-emerald-100 text-emerald-700';
    if (status === 'in_progress') return 'bg-blue-100 text-blue-700';
    if (status === 'todo') return 'bg-gray-100 text-gray-700';
    return 'bg-yellow-100 text-yellow-700';
  };

  const getPriorityBadgeClass = (priority) => {
    if (priority === 'high') return 'bg-red-100 text-red-700';
    if (priority === 'medium') return 'bg-amber-100 text-amber-700';
    return 'bg-green-100 text-green-700';
  };

  const getToolCategoryClass = (category) => {
    if (category === 'agent_cli') return 'bg-purple-100 text-purple-700';
    if (category === 'ide') return 'bg-blue-100 text-blue-700';
    if (category === 'human') return 'bg-gray-100 text-gray-600';
    return 'bg-amber-100 text-amber-700';
  };

  const renderStatusBadge = (ticket) => {
    const statusClass = getStatusBadgeClass(ticket.status);
    const displayStatus = ticket.status?.replace('_', ' ') || 'todo';
    
    return (
      <span className={`text-xs px-2 py-0.5 rounded-full ${statusClass}`}>
        {displayStatus}
      </span>
    );
  };

  const renderPriorityBadge = (ticket) => {
    const priorityClass = getPriorityBadgeClass(ticket.priority);
    const displayPriority = ticket.priority || 'medium';
    
    return (
      <span className={`text-xs px-2 py-0.5 rounded ${priorityClass}`}>
        {displayPriority}
      </span>
    );
  };

  const renderCurrentTool = (currentTool, toolInfo) => {
    if (!currentTool) {
      return <span className="text-xs text-gray-400">None</span>;
    }

    return (
      <div className="flex items-center gap-1">
        <span className="text-xs font-medium">{currentTool.tool}</span>
        {currentTool.agent_mode && (
          <span className="text-xs text-gray-400">({currentTool.agent_mode})</span>
        )}
        {toolInfo && (
          <span className={`text-xs px-1.5 py-0.5 rounded ${getToolCategoryClass(toolInfo.category)}`}>
            {toolInfo.category?.replace('_', ' ')}
          </span>
        )}
      </div>
    );
  };

  return {
    renderStatusBadge,
    renderPriorityBadge,
    renderCurrentTool,
    getToolCategoryClass
  };
}

export default TicketStatusBadges;
