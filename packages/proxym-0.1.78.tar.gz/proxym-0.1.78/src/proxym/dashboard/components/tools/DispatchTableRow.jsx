// DispatchTableRow - Component for rendering individual dispatch table rows
import React from 'react';
import TicketStatusBadges from './TicketStatusBadges';
import ProjectInfoResolver from './ProjectInfoResolver';
import DispatchActions from './DispatchActions';

function DispatchTableRow({ 
  ticket, 
  tools, 
  projects, 
  isDispatching, 
  onToolSelect 
}) {
  const statusBadges = TicketStatusBadges();
  const projectResolver = ProjectInfoResolver({ projects });
  
  const currentTool = ticket.assigned_tool;
  const toolInfo = currentTool ? tools.find(t => t.name === currentTool.tool) : null;
  const projectInfo = projectResolver.getProjectInfo(ticket.project_id);
  const projectDir = projectInfo.project?.local_path || "";
  
  return (
    <tr key={ticket.id} className="border-b border-gray-100 hover:bg-gray-50">
      <td className="py-2 px-3 font-mono text-xs text-gray-600">{ticket.id}</td>
      <td className="py-2 px-3">
        <div className="max-w-[200px] truncate" title={ticket.title}>
          {ticket.title}
        </div>
      </td>
      <td className="py-2 px-3">
        {projectResolver.renderProjectInfo(ticket.project_id)}
      </td>
      <td className="py-2 px-3">
        {statusBadges.renderStatusBadge(ticket)}
      </td>
      <td className="py-2 px-3">
        {statusBadges.renderPriorityBadge(ticket)}
      </td>
      <td className="py-2 px-3">
        {statusBadges.renderCurrentTool(currentTool, toolInfo)}
      </td>
      <td className="py-2 px-3">
        <DispatchActions
          ticket={ticket}
          availableTools={tools.filter(t => t.available)}
          projectDir={projectDir}
          isDispatching={isDispatching === ticket.id}
          onToolSelect={onToolSelect}
        />
      </td>
    </tr>
  );
}

export default DispatchTableRow;
