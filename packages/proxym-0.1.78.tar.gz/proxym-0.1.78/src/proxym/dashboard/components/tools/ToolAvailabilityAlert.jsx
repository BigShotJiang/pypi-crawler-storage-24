// ToolAvailabilityAlert - Component for displaying unavailable tools alert
import React from 'react';

function ToolAvailabilityAlert({ availableTools, unavailableTools }) {
  if (unavailableTools.length === 0) {
    return null;
  }

  return (
    <div className="mb-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
      <div className="font-medium">Unavailable tools are hidden from dispatch</div>
      <div className="mt-1">
        {availableTools.length > 0
          ? `Available tools: ${availableTools.map(tool => tool.name).join(", ")}.`
          : "No tools are currently available for dispatch."}
      </div>
      <div className="mt-1 text-amber-700">
        Hidden: {unavailableTools.map(tool => tool.name).join(", ")}. Open Tool Health to see why they are unavailable.
      </div>
    </div>
  );
}

export default ToolAvailabilityAlert;
