// DispatchTableHeader - Component for dispatch table header and export functionality
import React from 'react';
import TableExport from './TableExport';

function DispatchTableHeader({ 
  dispatchableTickets, 
  getProjectInfo,
  onExport 
}) {
  return (
    <div className="flex justify-between items-center mb-3">
      <h3 className="text-sm font-semibold text-gray-700">Dispatch Tool to Ticket</h3>
      {dispatchableTickets.length > 0 && (
        <TableExport 
          data={dispatchableTickets.map(ticket => ({
            id: ticket.id,
            title: ticket.title,
            project: getProjectInfo(ticket.project_id).label,
            project_path: getProjectInfo(ticket.project_id).path,
            status: ticket.status?.replace('_', ' ') || 'todo',
            priority: ticket.priority || 'medium',
            current_tool: ticket.assigned_tool?.tool || 'None',
            tool_mode: ticket.assigned_tool?.agent_mode || '',
            description: ticket.description || ''
          }))}
          filename="tickets"
          title="Tickets"
        />
      )}
    </div>
  );
}

export default DispatchTableHeader;
