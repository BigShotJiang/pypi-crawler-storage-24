// DispatchActions - Component for handling tool dispatch actions
import React from 'react';

function DispatchActions({ 
  ticket, 
  availableTools, 
  projectDir, 
  isDispatching, 
  onToolSelect 
}) {
  return (
    <div className="flex items-center gap-1">
      <select
        value=""
        onChange={(e) => {
          if (e.target.value) {
            const [toolName, mode] = e.target.value.split(':');
            onToolSelect(ticket.id, toolName, mode, projectDir);
            e.target.value = '';
          }
        }}
        disabled={isDispatching || availableTools.length === 0}
        className="text-xs border rounded px-2 py-1 disabled:opacity-50"
      >
        <option value="">Assign tool...</option>
        {availableTools.map(tool => (
          <optgroup key={tool.name} label={tool.name}>
            <option value={`${tool.name}`}>
              {tool.name} (default mode)
            </option>
            {tool.modes?.map(mode => (
              <option key={mode} value={`${tool.name}:${mode}`}>
                {tool.name} ({mode})
              </option>
            ))}
          </optgroup>
        ))}
      </select>
      {isDispatching && (
        <span className="text-xs text-blue-600">Dispatching...</span>
      )}
    </div>
  );
}

export default DispatchActions;
