// diagnostics/helpers.jsx — Shared badge/row helpers for diagnostics cards.
// Depends on: React (global)

function _diagBadge(ok, label) {
  const cls = ok
    ? "bg-emerald-100 text-emerald-800"
    : "bg-red-100 text-red-800";
  return <span className={`px-2 py-0.5 rounded text-xs font-medium ${cls}`}>{label || (ok ? "OK" : "FAIL")}</span>;
}

function _diagWarnBadge(label) {
  return <span className="px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800">{label || "Warning"}</span>;
}

function _diagRow(label, value, mono) {
  return (
    <div className="flex justify-between text-xs py-1 border-b border-gray-100 last:border-0">
      <span className="text-gray-500">{label}</span>
      <span className={`text-gray-900 ${mono ? "font-mono" : ""}`}>{value}</span>
    </div>
  );
}
