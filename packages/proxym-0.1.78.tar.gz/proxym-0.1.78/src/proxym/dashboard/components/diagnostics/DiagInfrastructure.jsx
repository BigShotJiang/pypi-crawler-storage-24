// diagnostics/DiagInfrastructure.jsx — VS Code + LLM Proxy status cards.
// Depends on: React (global), Card (ui.jsx), _diagBadge, _diagRow (helpers.jsx)

function DiagVSCode({ t }) {
  if (!t) return null;
  return (
    <Card title="VS Code Web" badge={_diagBadge(t.reachable)}>
      {_diagRow("URL", t.url, true)}
      {_diagRow("Hasło", t.password_configured ? "skonfigurowane" : "brak")}
      {t.details?.status_code && _diagRow("HTTP status", t.details.status_code)}
      {t.details?.has_login_form && _diagRow("Formularz logowania", "dostępny")}
      {t.password && _diagRow("Hasło domyślne", t.password, true)}
      {t.details?.error && <p className="text-xs text-red-600 mt-2">{t.details.error}</p>}
    </Card>
  );
}

function DiagProxy({ t }) {
  if (!t) return null;
  return (
    <Card title="LLM Proxy" badge={_diagBadge(t.reachable)}>
      {_diagRow("URL", t.url, true)}
      {_diagRow("Modeli dostępnych", t.models_available)}
      {t.details?.health?.version && _diagRow("Wersja", t.details.health.version)}
      {t.details?.error && <p className="text-xs text-red-600 mt-2">{t.details.error}</p>}
    </Card>
  );
}
