// diagnostics/DiagConfig.jsx — Roo Code config + LLM Providers cards.
// Depends on: React (global), Card (ui.jsx), _diagBadge, _diagWarnBadge, _diagRow (helpers.jsx)

function DiagRooConfig({ t }) {
  if (!t) return null;
  const ok = t.configured && t.api_provider === "openai";
  const badge = ok
    ? _diagBadge(true)
    : t.settings_file_exists
      ? _diagWarnBadge("Niekompletna")
      : _diagBadge(false);
  return (
    <Card title="Roo Code — konfiguracja" badge={badge}>
      {_diagRow("settings.json", t.settings_file_exists ? "istnieje" : "BRAK")}
      {t.api_provider && _diagRow("apiProvider", t.api_provider)}
      {t.base_url && _diagRow("openAiBaseUrl", t.base_url, true)}
      {t.details?.model_id && _diagRow("Model", t.details.model_id)}
      {t.details?.has_api_key !== undefined && _diagRow("API Key", t.details.has_api_key ? "ustawiony" : "BRAK")}
      {t.details?.mode_configs?.length > 0 && _diagRow("Tryby", t.details.mode_configs.join(", "))}
      {t.details?.mcp_servers?.length > 0 && _diagRow("MCP Servers", t.details.mcp_servers.join(", "))}
      {t.details?.workspace_trust_disabled !== undefined && _diagRow("Workspace Trust", t.details.workspace_trust_disabled ? "wyłączony ✓" : "włączony ⚠")}
      {t.details?.color_theme && _diagRow("Theme", t.details.color_theme)}
      {!t.configured && !t.details?.error && (
        <p className="text-xs text-amber-600 mt-2">
          Agent nie jest skonfigurowany. Uruchom kontener VS Code lub sprawdź PROXYM_API_BASE / PROXYM_API_KEY w .env
        </p>
      )}
      {t.details?.error && <p className="text-xs text-red-600 mt-2">{t.details.error}</p>}
    </Card>
  );
}

function DiagProviders({ t }) {
  if (!t) return null;
  return (
    <Card title={`Providery LLM (${t.total_providers})`} badge={_diagBadge(t.all_aliases_available)}>
      <div className="mb-3">
        {t.providers?.map(p => (
          <div key={p.name} className="flex items-center justify-between text-xs py-1 border-b border-gray-100">
            <span className={`font-medium ${p.has_key || p.is_local ? "text-gray-900" : "text-gray-400"}`}>{p.name}</span>
            <span>{p.is_local ? _diagBadge(true, "local") : p.has_key ? _diagBadge(true, p.key_prefix) : _diagBadge(false, "brak klucza")}</span>
          </div>
        ))}
      </div>
      {t.aliases?.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-gray-700 mb-1">Aliasy modeli:</p>
          {t.aliases.map(a => (
            <div key={a.alias} className="flex items-center justify-between text-xs py-0.5">
              <span className="font-mono text-blue-700">{a.alias}</span>
              <span className="text-gray-500">{a.model}</span>
              {a.available ? _diagBadge(true, a.provider) : _diagBadge(false, a.provider + " ✗")}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
