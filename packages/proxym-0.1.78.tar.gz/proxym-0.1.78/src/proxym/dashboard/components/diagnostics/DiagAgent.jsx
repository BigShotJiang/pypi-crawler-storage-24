// diagnostics/DiagAgent.jsx — Agent readiness + agent test cards.
// Depends on: React (global), Card (ui.jsx), _diagBadge, _diagWarnBadge, _diagRow (helpers.jsx)

function DiagAgentSetup({ t }) {
  if (!t) return null;
  return (
    <Card title="Gotowość agenta" badge={_diagBadge(t.ready)}>
      <div className="space-y-1">
        {t.checks?.map((c, i) => (
          <div key={i} className="flex items-start gap-2 text-xs py-1 border-b border-gray-100 last:border-0">
            <span className={`mt-0.5 flex-shrink-0 ${c.pass ? "text-emerald-600" : "text-red-600"}`}>
              {c.pass ? "✓" : "✗"}
            </span>
            <div>
              <span className="font-medium text-gray-900">{c.name}</span>
              <p className="text-gray-500">{c.detail}</p>
            </div>
          </div>
        ))}
      </div>
      {t.details && (
        <div className="mt-2 text-xs text-gray-500">
          {t.details.passed}/{t.details.total_checks} sprawdzeń OK
        </div>
      )}
    </Card>
  );
}

function DiagAgentTest({ t }) {
  if (!t) return null;
  const skipped = t.details?.skipped;
  return (
    <Card title="Test agenta — LLM completion" badge={skipped ? _diagWarnBadge("Pominięto") : _diagBadge(t.success)}>
      {skipped ? (
        <p className="text-xs text-amber-600">{skipped}</p>
      ) : (
        <div>
          {_diagRow("Czas odpowiedzi", `${t.response_time_ms}ms`)}
          {t.details?.model_used && _diagRow("Model", t.details.model_used)}
          {t.details?.response && (
            <div className="mt-2 p-2 bg-gray-50 rounded text-xs font-mono text-gray-700 break-all">
              {t.details.response}
            </div>
          )}
          {t.details?.error && <p className="text-xs text-red-600 mt-2">{t.details.error}</p>}
        </div>
      )}
    </Card>
  );
}
