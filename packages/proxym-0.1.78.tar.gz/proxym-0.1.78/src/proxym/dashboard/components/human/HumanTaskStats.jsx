// HumanTaskStats - Component for displaying human task statistics
import React from 'react';

function HumanTaskStats({ stats }) {
  return (
    <div className="grid grid-cols-4 gap-2">
      <div className="bg-white rounded border p-2 text-center">
        <div className="text-lg font-bold text-gray-900">{stats.total}</div>
        <div className="text-xs text-gray-500">Total</div>
      </div>
      <div className="bg-white rounded border p-2 text-center">
        <div className="text-lg font-bold text-amber-600">
          {stats.inProgress}
        </div>
        <div className="text-xs text-gray-500">In Progress</div>
      </div>
      <div className="bg-white rounded border p-2 text-center">
        <div className="text-lg font-bold text-blue-600">
          {stats.pending}
        </div>
        <div className="text-xs text-gray-500">Pending</div>
      </div>
      <div className="bg-white rounded border p-2 text-center">
        <div className="text-lg font-bold text-emerald-600">
          {stats.done}
        </div>
        <div className="text-xs text-gray-500">Done</div>
      </div>
    </div>
  );
}

export default HumanTaskStats;
