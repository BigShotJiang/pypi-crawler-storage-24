// HumanTaskList - Component for list view of human tasks
import React from 'react';
import Card from '../Card';
import TaskTicketCard from '../TaskTicketCard';

function HumanTaskList({ filteredTasks, jobs, onRefresh }) {
  if (filteredTasks.length === 0) {
    return (
      <Card title="No human tasks">
        <p className="text-gray-400 text-sm">Use Quick Create above to create your first human task.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {filteredTasks.map(t => (
        <TaskTicketCard key={t.id} ticket={t} jobs={jobs} onRefresh={onRefresh} />
      ))}
    </div>
  );
}

export default HumanTaskList;
