// TasksList - Component for list view of tasks
import React from 'react';
import Card from '../Card';
import TaskTicketCard from '../TaskTicketCard';

function TasksList({ filteredTasks, jobs, onRefresh }) {
  if (filteredTasks.length === 0) {
    return (
      <Card title="No tasks">
        <p className="text-gray-400 text-sm">Use Quick Action above to create your first task.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {filteredTasks.map(t => (
        <TaskTicketCard key={t.id} ticket={t} jobs={jobs} onRefresh={onRefresh} />
      ))}
    </div>
  );
}

export default TasksList;
