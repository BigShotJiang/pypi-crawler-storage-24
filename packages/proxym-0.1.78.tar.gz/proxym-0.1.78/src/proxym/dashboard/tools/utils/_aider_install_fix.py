"""Aider installation fix utilities."""

import sys
import shutil


def _aider_install_fix() -> dict[str, str]:
    """Return a safer aider installation hint for the current environment."""
    for py_bin in ("python3.12", "python3.11"):
        if shutil.which(py_bin):
            return {
                "action": "install",
                "label": "Install aider",
                "command": f"{py_bin} -m pip install aider-chat",
                "description": "Install aider CLI in a Python 3.12/3.11 environment (Python 3.13 may fail to build aider-chat).",
            }

    if sys.version_info < (3, 13):
        return {
            "action": "install",
            "label": "Install aider",
            "command": "python3 -m pip install aider-chat",
            "description": "Install aider CLI in the current Python environment.",
        }

    return {
        "action": "install",
        "label": "Install aider",
        "command": "python3.12 -m pip install aider-chat",
        "description": "Install aider CLI in Python 3.12/3.11 first; Python 3.13 often fails to build aider-chat.",
    }
