"""Dashboard tools utilities."""
