"""Executor lifecycle utilities."""

from typing import Any


async def _executor_action(action: str, message: str) -> dict[str, Any]:
    """Generic executor action function."""
    from proxym.tools.executor import ToolExecutor
    executor = ToolExecutor.get()
    if action == "start":
        await executor.start()
    elif action == "stop":
        await executor.stop()
    return {"ok": True, "message": message}


async def start_executor() -> dict[str, Any]:
    """Start the background executor loop."""
    return await _executor_action("start", "Executor started")


async def stop_executor() -> dict[str, Any]:
    """Stop the background executor loop."""
    return await _executor_action("stop", "Executor stopped")
