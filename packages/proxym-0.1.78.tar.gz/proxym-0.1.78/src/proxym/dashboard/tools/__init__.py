"""Dashboard API endpoints for the Tools tab — split into focused modules.

Exposes tool registry, prompt building, job queue, and execution via REST.
"""

from fastapi import APIRouter

from proxym.dashboard.tools._registry import router as registry_router
from proxym.dashboard.tools._dispatch import router as dispatch_router
from proxym.dashboard.tools._queue import router as queue_router
from proxym.dashboard.tools._autofix import router as autofix_router
from proxym.dashboard.tools._lifecycle import router as lifecycle_router
from proxym.dashboard.tools._health import router as health_router
from proxym.dashboard.tools._providers import router as providers_router

router = APIRouter(prefix="/tools", tags=["tools"])
# Specific-prefix routers first; registry last (has catch-all /{tool_name})
router.include_router(queue_router)
router.include_router(lifecycle_router)
router.include_router(dispatch_router)
router.include_router(autofix_router)
router.include_router(health_router)
router.include_router(providers_router)
router.include_router(registry_router)
