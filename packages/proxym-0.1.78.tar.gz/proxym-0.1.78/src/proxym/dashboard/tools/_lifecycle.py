"""Executor lifecycle endpoints: start/stop."""

from typing import Any

from fastapi import APIRouter

router = APIRouter(prefix="/queue", tags=["tools"])


@router.post("/start")
async def start_executor() -> dict[str, Any]:
    """Start the background executor loop."""
    from proxym.dashboard.tools.utils.start_executor import start_executor as start_executor_util
    return await start_executor_util()


@router.post("/stop")
async def stop_executor() -> dict[str, Any]:
    """Stop the background executor loop."""
    from proxym.dashboard.tools.utils.start_executor import stop_executor as stop_executor_util
    return await stop_executor_util()
