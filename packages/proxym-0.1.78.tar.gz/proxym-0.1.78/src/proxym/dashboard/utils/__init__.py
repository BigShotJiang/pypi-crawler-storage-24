"""Dashboard utilities."""
