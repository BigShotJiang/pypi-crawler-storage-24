"""Delete utilities for milestones and VMs."""

from proxym.dashboard.utils._delete_item import _delete_item


def delete_milestone(delete_func, item_id: str):
    """Delete a milestone."""
    return _delete_item(delete_func, item_id, "Milestone not found")


def delete_vm(delete_func, item_id: str):
    """Delete a VM."""
    return _delete_item(delete_func, item_id, "VM not found")
