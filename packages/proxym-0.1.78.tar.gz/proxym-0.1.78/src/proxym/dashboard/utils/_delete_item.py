"""Generic delete utility for dashboard items."""

from fastapi import HTTPException


def _delete_item(delete_func, item_id: str, not_found_msg: str):
    """Generic delete function."""
    if delete_func(item_id):
        return {"ok": True}
    raise HTTPException(404, not_found_msg)
