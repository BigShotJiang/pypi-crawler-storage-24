"""Delete utilities for tickets and sprints."""

from proxym.dashboard.utils._delete_item import _delete_item


def delete_item(delete_func, item_id: str, not_found_msg: str):
    """Generic delete function for tickets and sprints."""
    return _delete_item(delete_func, item_id, not_found_msg)


def delete_ticket_from_dict(tickets_dict: dict, ticket_id: str, save_func=None) -> bool:
    """Delete a ticket from the tickets dictionary."""
    if ticket_id in tickets_dict:
        del tickets_dict[ticket_id]
        if save_func:
            save_func()
        return True
    return False
