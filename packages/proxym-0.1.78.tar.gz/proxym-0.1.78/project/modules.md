# proxy — Module Reference

> 22 modules | 193 functions | 36 classes

## Module Overview

| Module | Lines | Functions | Classes | CC avg | Description | Source |
|--------|-------|-----------|---------|--------|-------------|--------|
| `frontend.proxym-dashboard` | 335 | 14 | 0 | 4.6 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx) |
| `src.proxym.accounts` | 343 | 0 | 8 | 3.9 | Account manager: multi-provider credential vault with usage  | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py) |
| `src.proxym.cache` | 336 | 0 | 3 | 5.9 | Delta context buffer: watch code2llm output, send only diffs | [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py) |
| `src.proxym.config` | 83 | 1 | 1 | 2.5 | Configuration loaded from environment / .env file. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py) |
| `src.proxym.ctl` | 499 | 21 | 0 | 4.3 | Unified CLI for Proxym — AI proxy management. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py) |
| `src.proxym.dashboard` | 265 | 20 | 4 | 1.9 | Dashboard API: web panel + CLI endpoints for managing accoun | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py) |
| `src.proxym.dashboard.panel` | 330 | 14 | 0 | 4.6 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx) |
| `src.proxym.main` | 478 | 15 | 0 | 3.6 | AI Proxy — FastAPI server exposing an OpenAI-compatible API. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py) |
| `src.proxym.middleware` | 60 | 0 | 2 | 2.7 | Middleware for cost tracking, auth, and request logging. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py) |
| `src.proxym.providers` | 330 | 4 | 3 | 3.0 | Model registry: 10 providers × 15 models with cost/capabilit | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py) |
| `src.proxym.router` | 275 | 3 | 1 | 15.7 | Analyze incoming request content to determine task tier and  | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py) |
| `src.proxym.router.strategy` | 227 | 2 | 3 | 4.1 | Routing strategy: maps AnalysisResult → ModelSpec, respectin | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py) |
| `src.proxym.virt` | 616 | 1 | 6 | 4.6 | VM Orchestrator: manage isolated dev environments via CloneB | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py) |
| `src.proxym.virt.browser_profiles` | 325 | 10 | 2 | 4.0 | Browser profile detection and management for VM isolation. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py) |
| `src.proxym.virt.clonebox_adapter` | 209 | 0 | 2 | 1.9 | CloneBox adapter: wraps clonebox CLI for VM lifecycle manage | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py) |
| `src.proxym.virt.profiles` | 69 | 4 | 0 | 3.2 | CloneBox profile templates for various dev tools. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py) |
| `src.proxym.watch` | 139 | 1 | 1 | 2.2 | File watcher client: monitors code2llm output and pushes del | [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py) |

## frontend

### `frontend.proxym-dashboard` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx)

- `AccountsPanel()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L86)
- `Card()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L39)
- `CostBar()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L23)
- `ModelsTable()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L48)
- `StatusBadge()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L15)
- `VMsPanel()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L142)
- `color()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L25)
- `get()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L7)
- `h()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L191)
- `handleAction()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L143)
- `handleCreate()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L90)
- `pct()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L24)
- `post()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L8)
- `refresh()` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L190)

## src

### `src.proxym.accounts` [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py)

Account manager: multi-provider credential vault with usage tracking.

**`Account`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L159)
: Single provider account with all associated data.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `status_summary` | `` | `—` | 3 |

**`AccountCredentials`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L60)
: Credentials for a single provider account.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `to_safe_dict` | `` | `—` | 5 |

**`AccountLimits`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L115)
: Provider-imposed and user-defined limits.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `is_over_budget` | `metrics` | `—` | 5 |
| `budget_remaining` | `metrics` | `—` | 4 |

**`AccountManager`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L211)
: Central account registry.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `add_account` | `account` | `—` | 1 |
| `remove_account` | `account_id` | `—` | 2 |
| `get_account` | `account_id` | `—` | 1 |
| `list_accounts` | `provider, tag` | `—` | 7 |
| `find_cheapest_active` | `provider` | `—` | 6 |
| `record_usage` | `account_id, tokens_in, tokens_out` | `—` | 3 |
| `bind_tool` | `account_id, binding` | `—` | 2 |
| `get_all_status` | `` | `—` | 2 |
| `get_cost_summary` | `` | `—` | 10 |

**`ProviderType`** (str, Enum) [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L28)

**`ToolBinding`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L147)
: Binds an account to a specific tool/IDE instance.

**`ToolType`** (str, Enum) [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L45)

**`UsageMetrics`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L81)
: Tracked usage for a single account.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `record` | `tokens_in, tokens_out, cost_usd` | `—` | 2 |

### `src.proxym.cache` [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py)

Delta context buffer: watch code2llm output, send only diffs.

**`DeltaBuffer`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L103)
: Maintains file snapshots and computes minimal diffs.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `scan` | `` | `—` | 9 |
| `compute_delta` | `` | `—` | 20 |
| `get_stats` | `` | `—` | 3 |

**`DeltaPayload`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L70)
: Computed delta between two context snapshots.

**`FileSnapshot`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L44)
: Immutable snapshot of a single file.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `from_path` | `path` | `—` | 2 |

### `src.proxym.config` [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py)

Configuration loaded from environment / .env file.

**`Settings`** (BaseSettings) [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py#L9)
: All settings with sensible defaults. Override via env vars or .env file.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `available_providers` | `` | `—` | 3 |

- `get_settings()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py#L79)

### `src.proxym.ctl` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py)

Unified CLI for Proxym — AI proxy management.

- `cmd_accounts_add(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L129)
- `cmd_accounts_costs(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L144)
- `cmd_accounts_list(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L105)
- `cmd_browser_assign(args)` — Assign a browser profile to an account. [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L300)
- `cmd_browser_list(args)` — List detected browser profiles on the host. [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L276)
- `cmd_browser_snapshot(args)` — Save browser state from VM as snapshot. [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L324)
- `cmd_browser_sync(args)` — Sync browser profile host ↔ VM. [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L314)
- `cmd_models(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L336)
- `cmd_serve(args)` — Start the proxy server (delegates to proxym.main:cli). [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L59)
- `cmd_status(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L75)
- `cmd_vm_action(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L208)
- `cmd_vm_create(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L192)
- `cmd_vm_list(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L172)
- `cmd_vm_logs(args)` — Show cloud-init logs and tool logs from a VM. [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L256)
- `cmd_vm_open(args)` — Open SPICE viewer for a VM (virt-viewer). [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L227)
- `cmd_vm_ssh(args)` — SSH into a VM (auto-detect IP via dashboard). [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L239)
- `cmd_vm_switch(args)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L217)
- `main()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L357)

### `src.proxym.dashboard` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py)

Dashboard API: web panel + CLI endpoints for managing accounts, VMs, and costs.

**`BindToolReq`** (BaseModel) [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L56)

**`CreateAccountReq`** (BaseModel) [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L45)

**`CreateVMReq`** (BaseModel) [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L64)

**`SwitchProjectReq`** (BaseModel) [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L75)

- `bind_tool(account_id, req)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L124)
- `cost_detailed()` — Per-account cost breakdown. [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L146)
- `cost_summary()` — Aggregate cost dashboard across all accounts. [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L140)
- `create_account(req)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L90)
- `create_vm(req)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L183)
- `dashboard_root()` — Dashboard root - redirects to system status. [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L250)
- `delete_account(account_id)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L117)
- `delete_vm(vm_id)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L241)
- `get_account(account_id)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L109)
- `list_accounts(provider, tag)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L82)
- `list_vms()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L170)
- `pause_vm(vm_id)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L213)
- `resume_vm(vm_id)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L220)
- `snapshot_vm(vm_id, name)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L227)
- `start_vm(vm_id)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L199)
- `stop_vm(vm_id, force)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L206)
- `switch_project(vm_id, req)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L234)
- `system_status()` — Full system overview: accounts + VMs + costs + libvirt status. [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L255)

### `src.proxym.dashboard.panel` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx)

- `AccountsPanel()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L81)
- `Card()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L34)
- `CostBar()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L18)
- `ModelsTable()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L43)
- `StatusBadge()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L10)
- `VMsPanel()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L137)
- `color()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L20)
- `get()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L7)
- `h()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L186)
- `handleAction()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L138)
- `handleCreate()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L85)
- `pct()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L19)
- `post()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L8)
- `refresh()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L185)

### `src.proxym.main` [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py)

AI Proxy — FastAPI server exposing an OpenAI-compatible API.

- `budget_status()` — Return current budget usage. [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L226)
- `chat_completions(request, x_task_tier)` — OpenAI-compatible chat completions with intelligent routing. [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L262)
- `cli()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L460)
- `context_stats()` — Return delta buffer statistics. [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L238)
- `dashboard_jsx()` — Serve the React dashboard JSX file. [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L173)
- `dashboard_ui()` — Serve the React dashboard UI. [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L140)
- `health()` [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L135)
- `lifespan(app)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L88)
- `list_models()` — List available models (OpenAI-compatible). [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L205)
- `receive_delta(request)` — Receive context delta from the file watcher client. [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L247)

### `src.proxym.middleware` [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py)

Middleware for cost tracking, auth, and request logging.

**`AuthMiddleware`** (BaseHTTPMiddleware) [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py#L15)
: Simple bearer token auth (matches LiteLLM master_key pattern).

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `dispatch` | `request, call_next` | `—` | 5 |

**`CostTrackingMiddleware`** (BaseHTTPMiddleware) [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py#L40)
: Log request timing and attach cost headers to responses.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `dispatch` | `request, call_next` | `—` | 2 |

### `src.proxym.providers` [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py)

Model registry: 10 providers × 15 models with cost/capability metadata.

**`Capability`** (str, Enum) [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L36)

**`ModelSpec`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L47)
: Immutable specification for a single model deployment.

**`TaskTier`** (str, Enum) [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L13)
: Complexity tier that determines which model class is needed.

- `cheapest_model(tier, available_providers, required_caps)` — Return the single cheapest model that satisfies constraints. [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L322)
- `get_model(model_id)` [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L329)
- `models_for_tier(tier, required_caps, available_providers)` — Return models suitable for a tier, sorted by effective cost ascending. [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L305)

### `src.proxym.router` [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py)

Analyze incoming request content to determine task tier and required capabilities.

**`AnalysisResult`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py#L87)
: Result of content analysis.

- `analyze_request(messages)` — Analyze a chat completion request and return routing metadata. [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py#L98)

### `src.proxym.router.strategy` [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py)

Routing strategy: maps AnalysisResult → ModelSpec, respecting budget and availability.

**`CostLedger`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L40)
: In-memory cost ledger with Redis persistence.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `can_spend` | `estimated_usd` | `—` | 5 |
| `record` | `actual_usd` | `—` | 1 |

**`Router`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L89)
: Stateful router that selects the optimal model per request.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `route` | `analysis, explicit_model` | `—` | 21 |
| `record_latency` | `model_id, latency_s` | `—` | 1 |
| `record_cost` | `cost_usd` | `—` | 1 |

**`RoutingDecision`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L29)
: Complete routing decision with audit trail.

### `src.proxym.virt` [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py)

VM Orchestrator: manage isolated dev environments via CloneBox or libvirt.

**`ProjectsConfig`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L70)
: Configuration for shared project mounts from the host.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `filter_projects` | `projects` | `—` | 9 |

**`VMBackend`** (str, Enum) [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L56)

**`VMConfig`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L90)
: Configuration for a development VM.

**`VMOrchestrator`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L147)
: Manages VMs for isolated dev environments.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `create_vm` | `config` | `—` | 4 |
| `start_vm` | `vm_id` | `—` | 6 |
| `stop_vm` | `vm_id, force` | `—` | 7 |
| `pause_vm` | `vm_id` | `—` | 3 |
| `resume_vm` | `vm_id` | `—` | 3 |
| `snapshot_vm` | `vm_id, name` | `—` | 7 |
| `restore_snapshot` | `vm_id, snapshot_name` | `—` | 6 |
| `delete_vm` | `vm_id` | `—` | 6 |
| `get_status` | `vm_id` | `—` | 13 |
| `list_vms` | `` | `—` | 3 |
| `switch_project` | `vm_id, new_project_path` | `—` | 5 |
| `check_libvirt_available` | `` | `—` | 3 |

**`VMState`** (str, Enum) [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L61)

**`VMStatus`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L132)
: Runtime status of a VM.

### `src.proxym.virt.browser_profiles` [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py)

Browser profile detection and management for VM isolation.

**`AppDataSync`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L111)
: Configuration for syncing browser data into a VM.

**`BrowserProfile`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L89)
: Detected browser profile on the host.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `to_dict` | `` | `—` | 1 |

- `detect_all_profiles()` — Detect all browser profiles on the host. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L190)
- `detect_chrome_profiles()` — Detect Google Chrome profiles by parsing Local State. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L174)
- `detect_chromium_profiles()` — Detect Chromium profiles by parsing Local State. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L182)
- `detect_firefox_profiles()` — Detect Firefox profiles by parsing profiles.ini. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L123)
- `generate_app_data_sync(profile, with_passwords)` — Generate an AppDataSync config for copying a profile into a VM. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L201)

### `src.proxym.virt.clonebox_adapter` [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py)

CloneBox adapter: wraps clonebox CLI for VM lifecycle management.

**`CloneBoxAdapter`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py#L35)
: Adapter wrapping the clonebox CLI for VM operations.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `is_available` | `` | `—` | 1 |
| `version` | `` | `—` | 2 |
| `create_vm` | `name, profile_path, extra_args` | `—` | 5 |
| `start_vm` | `name` | `—` | 2 |
| `stop_vm` | `name` | `—` | 2 |
| `snapshot` | `name, snapshot_name` | `—` | 2 |
| `restore_snapshot` | `name, snapshot_name` | `—` | 1 |
| `health` | `name` | `—` | 1 |
| `delete_vm` | `name` | `—` | 2 |
| `list_vms` | `` | `—` | 1 |
| `detect` | `` | `—` | 1 |
| `export_encrypted` | `name, output_path` | `—` | 1 |
| `get_profile_path` | `tool` | `—` | 2 |
| `generate_profile_name` | `tool, account_name` | `—` | 1 |

**`CloneBoxResult`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py#L27)
: Result of a clonebox CLI invocation.

### `src.proxym.virt.profiles` [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py)

CloneBox profile templates for various dev tools.

- `get_builtin_profile(tool)` — Get the path to a built-in profile YAML for a tool. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L28)
- `list_builtin_profiles()` — List all available built-in profile names. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L36)
- `load_profile_yaml(path)` — Load a YAML profile, with graceful fallback if PyYAML is not installed. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L58)
- `merge_profiles(base, override)` — Deep-merge two profile dicts. Override values take precedence. [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L44)

### `src.proxym.watch` [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py)

File watcher client: monitors code2llm output and pushes deltas to the proxy.

**`DeltaWatchClient`** [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py#L28)
: Watches a directory and pushes context deltas to the proxy server.

| Method | Args | Returns | CC |
|--------|------|---------|----|
| `push_delta` | `` | `—` | 2 |
| `run` | `` | `—` | 5 |
| `close` | `` | `—` | 1 |

- `cli()` — CLI entry point for proxym-client. [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py#L113)
