# proxy — Docstring Coverage

🟡 **Overall coverage: 50.7%**

| Category | Documented | Total | Coverage |
|----------|-----------|-------|----------|
| Functions | 89 | 193 | 46.1% |
| Classes | 27 | 36 | 75.0% |

## Per-Module Breakdown

| Module | Functions | Classes | Coverage |
|--------|-----------|---------|----------|
| `frontend.proxym-dashboard` | 0/14 | 0/0 | 🔴 0% |
| `project` | 0/0 | 0/0 | 🟢 100% |
| `scripts.jetson-entrypoint` | 0/0 | 0/0 | 🟢 100% |
| `scripts.setup` | 0/0 | 0/0 | 🟢 100% |
| `src.proxym` | 0/0 | 0/0 | 🟢 100% |
| `src.proxym.accounts` | 0/0 | 6/8 | 🟡 75% |
| `src.proxym.cache` | 0/0 | 3/3 | 🟢 100% |
| `src.proxym.config` | 0/1 | 1/1 | 🟡 50% |
| `src.proxym.ctl` | 8/21 | 0/0 | 🔴 38% |
| `src.proxym.dashboard` | 4/20 | 0/4 | 🔴 17% |
| `src.proxym.dashboard.panel` | 0/14 | 0/0 | 🔴 0% |
| `src.proxym.main` | 10/15 | 0/0 | 🟡 67% |
| `src.proxym.middleware` | 0/0 | 2/2 | 🟢 100% |
| `src.proxym.providers` | 2/4 | 2/3 | 🟡 57% |
| `src.proxym.router` | 1/3 | 1/1 | 🟡 50% |
| `src.proxym.router.strategy` | 2/2 | 3/3 | 🟢 100% |
| `src.proxym.virt` | 1/1 | 4/6 | 🟡 71% |
| `src.proxym.virt.browser_profiles` | 10/10 | 2/2 | 🟢 100% |
| `src.proxym.virt.clonebox_adapter` | 0/0 | 2/2 | 🟢 100% |
| `src.proxym.virt.profiles` | 4/4 | 0/0 | 🟢 100% |
| `src.proxym.watch` | 1/1 | 1/1 | 🟢 100% |
| `src.proxym.watch.client` | 0/0 | 0/0 | 🟢 100% |

## Undocumented Items

- `frontend.proxym-dashboard.AccountsPanel` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:86)
- `frontend.proxym-dashboard.Card` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:39)
- `frontend.proxym-dashboard.CostBar` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:23)
- `frontend.proxym-dashboard.ModelsTable` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:48)
- `frontend.proxym-dashboard.StatusBadge` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:15)
- `frontend.proxym-dashboard.VMsPanel` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:142)
- `frontend.proxym-dashboard.color` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:25)
- `frontend.proxym-dashboard.get` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:7)
- `frontend.proxym-dashboard.h` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:191)
- `frontend.proxym-dashboard.handleAction` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:143)
- `frontend.proxym-dashboard.handleCreate` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:90)
- `frontend.proxym-dashboard.pct` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:24)
- `frontend.proxym-dashboard.post` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:8)
- `frontend.proxym-dashboard.refresh` (/home/tom/github/wronai/proxy/frontend/proxym-dashboard.jsx:190)
- `src.proxym.config.get_settings` (/home/tom/github/wronai/proxy/src/proxym/config.py:79)
- `src.proxym.ctl.cmd_accounts_add` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:129)
- `src.proxym.ctl.cmd_accounts_costs` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:144)
- `src.proxym.ctl.cmd_accounts_list` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:105)
- `src.proxym.ctl.cmd_models` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:336)
- `src.proxym.ctl.cmd_status` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:75)
- `src.proxym.ctl.cmd_vm_action` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:208)
- `src.proxym.ctl.cmd_vm_create` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:192)
- `src.proxym.ctl.cmd_vm_list` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:172)
- `src.proxym.ctl.cmd_vm_switch` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:217)
- `src.proxym.ctl.main` (/home/tom/github/wronai/proxy/src/proxym/ctl.py:357)
- `src.proxym.dashboard.bind_tool` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:124)
- `src.proxym.dashboard.create_account` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:90)
- `src.proxym.dashboard.create_vm` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:183)
- `src.proxym.dashboard.delete_account` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:117)
- `src.proxym.dashboard.delete_vm` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:241)
- `src.proxym.dashboard.get_account` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:109)
- `src.proxym.dashboard.list_accounts` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:82)
- `src.proxym.dashboard.list_vms` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:170)
- `src.proxym.dashboard.panel.AccountsPanel` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:81)
- `src.proxym.dashboard.panel.Card` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:34)
- `src.proxym.dashboard.panel.CostBar` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:18)
- `src.proxym.dashboard.panel.ModelsTable` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:43)
- `src.proxym.dashboard.panel.StatusBadge` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:10)
- `src.proxym.dashboard.panel.VMsPanel` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:137)
- `src.proxym.dashboard.panel.color` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:20)
- `src.proxym.dashboard.panel.get` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:7)
- `src.proxym.dashboard.panel.h` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:186)
- `src.proxym.dashboard.panel.handleAction` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:138)
- `src.proxym.dashboard.panel.handleCreate` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:85)
- `src.proxym.dashboard.panel.pct` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:19)
- `src.proxym.dashboard.panel.post` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:8)
- `src.proxym.dashboard.panel.refresh` (/home/tom/github/wronai/proxy/src/proxym/dashboard/panel.jsx:185)
- `src.proxym.dashboard.pause_vm` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:213)
- `src.proxym.dashboard.resume_vm` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:220)
- `src.proxym.dashboard.snapshot_vm` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:227)
- `src.proxym.dashboard.start_vm` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:199)
- `src.proxym.dashboard.stop_vm` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:206)
- `src.proxym.dashboard.switch_project` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:234)
- `src.proxym.main.cli` (/home/tom/github/wronai/proxy/src/proxym/main.py:460)
- `src.proxym.main.health` (/home/tom/github/wronai/proxy/src/proxym/main.py:135)
- `src.proxym.main.lifespan` (/home/tom/github/wronai/proxy/src/proxym/main.py:88)
- `src.proxym.providers.get_model` (/home/tom/github/wronai/proxy/src/proxym/providers/__init__.py:329)
- `src.proxym.accounts.ProviderType` (/home/tom/github/wronai/proxy/src/proxym/accounts/__init__.py:28)
- `src.proxym.accounts.ToolType` (/home/tom/github/wronai/proxy/src/proxym/accounts/__init__.py:45)
- `src.proxym.dashboard.BindToolReq` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:56)
- `src.proxym.dashboard.CreateAccountReq` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:45)
- `src.proxym.dashboard.CreateVMReq` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:64)
- `src.proxym.dashboard.SwitchProjectReq` (/home/tom/github/wronai/proxy/src/proxym/dashboard/__init__.py:75)
- `src.proxym.providers.Capability` (/home/tom/github/wronai/proxy/src/proxym/providers/__init__.py:36)
- `src.proxym.virt.VMBackend` (/home/tom/github/wronai/proxy/src/proxym/virt/__init__.py:56)
- `src.proxym.virt.VMState` (/home/tom/github/wronai/proxy/src/proxym/virt/__init__.py:61)
