"""
Quickstart — src

Minimal working examples for the most common use cases.
Run: python examples/quickstart.py
"""

from pathlib import Path
import sys

# Add the src directory to Python path for proper imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

import proxym


# ==================================================
# Example 2: Generate documentation
# ==================================================

