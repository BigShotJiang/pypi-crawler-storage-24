"""
Advanced usage — src

Shows how to use individual generators, sync, and formatters.
Run: python examples/advanced_usage.py
"""

from pathlib import Path

