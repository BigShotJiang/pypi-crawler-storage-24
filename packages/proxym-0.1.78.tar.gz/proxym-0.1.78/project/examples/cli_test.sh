#!/usr/bin/env bash
# cli_test.sh — End-to-end CLI smoke tests for proxym.
#
# Usage:
#   bash examples/cli_test.sh                  # default: http://localhost:4000
#   PROXYM_URL=http://10.0.0.5:4000 bash examples/cli_test.sh
#
# Prerequisites:
#   - proxym server running (proxym serve)
#   - proxym CLI installed (pip install -e .)
#
# What it tests:
#   1. Health / status
#   2. Project registration (local path: /home/tom/github/semcod/vallm)
#   3. Tools listing
#   4. Ticket lifecycle (create → assign → dispatch → follow)
#   5. VM listing
#   6. Environment listing
#   7. CLI "do" command (dry-run)
#   8. Job queue status

set -euo pipefail

PROXYM="${PROXYM_URL:-http://localhost:4000}"
CLI="proxym --proxy $PROXYM"
PASS=0
FAIL=0
VALLM_PATH="/home/tom/github/semcod/vallm"

# ── Helpers ──────────────────────────────────────────────────

_ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
_fail() { FAIL=$((FAIL+1)); echo "  ✗ $1"; }

_run() {
  local label="$1"; shift
  if output=$("$@" 2>&1); then
    _ok "$label"
    echo "$output"
    return 0
  else
    _fail "$label (exit $?)"
    echo "$output" | head -20
    return 1
  fi
}

_section() { echo -e "\n── $1 ────────────────────────────"; }

# ── 1. Health / Status ───────────────────────────────────────

_section "Health & Status"
_run "proxym status" $CLI status || true

# ── 2. Projects ──────────────────────────────────────────────

_section "Projects"
_run "project list" $CLI project list || true

# Register vallm if the directory exists
if [ -d "$VALLM_PATH" ]; then
  _run "project add vallm" $CLI project add "$VALLM_PATH" --name vallm --tool aider || true
else
  echo "  ⚠ Skipping: $VALLM_PATH not found"
fi

_run "project list (after add)" $CLI project list || true

# ── 3. Tools ─────────────────────────────────────────────────

_section "Tools"
_run "tools list" $CLI tools list || true
_run "tools list --available" $CLI tools list --available || true

# ── 4. Ticket lifecycle ──────────────────────────────────────

_section "Tickets"

# Create a test ticket
TICKET_OUTPUT=$($CLI do "Test ticket from cli_test.sh" --on vallm --with aider --no-run --type task --priority low 2>&1) || true
echo "$TICKET_OUTPUT"
TICKET_ID=$(echo "$TICKET_OUTPUT" | grep -oP 'Ticket \K[a-f0-9-]+' | head -1)

if [ -n "${TICKET_ID:-}" ]; then
  _ok "ticket created: $TICKET_ID"

  # Dispatch (dry-run style — use --no-wait so we don't block)
  _run "dispatch ticket" $CLI tools dispatch --ticket "$TICKET_ID" --tool aider || true
  _run "tools queue" $CLI tools queue || true
  _run "tools jobs" $CLI tools jobs --limit 5 || true
else
  _fail "ticket creation — could not extract ID"
fi

# ── 5. VMs ───────────────────────────────────────────────────

_section "VMs"
_run "vm list (via status)" $CLI status || true

# ── 6. Environments ──────────────────────────────────────────

_section "Environments (via API)"
# The CLI doesn't have dedicated environment commands yet, so use curl
_run "environments list" curl -s "$PROXYM/dashboard/environments" || true

# ── 7. Do command (dry-run) ──────────────────────────────────

_section "Do (dry-run)"
_run "do dry-run" $CLI do "refactor README" --on vallm --with aider --dry-run || true

# ── 8. Job Queue ─────────────────────────────────────────────

_section "Job Queue"
_run "queue status" $CLI tools queue || true
_run "recent jobs" $CLI tools jobs --limit 10 || true

# ── Summary ──────────────────────────────────────────────────

echo -e "\n══════════════════════════════════════════"
echo "  Results: $PASS passed, $FAIL failed"
echo "══════════════════════════════════════════"

[ "$FAIL" -eq 0 ] && exit 0 || exit 1
