# proxy — Dependency Graph

> 22 modules, 0 dependency edges

## Module Dependencies

```mermaid
graph LR
    note[No internal dependencies]
```

## Coupling Matrix

| | proxym-dashboard | project | jetson-entrypoint | setup | proxym | accounts | cache | config | ctl | dashboard | panel | main | middleware | providers | router | strategy | virt | browser_profiles | clonebox_adapter | profiles | watch | client |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **proxym-dashboard** | · |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **project** |  | · |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **jetson-entrypoint** |  |  | · |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **setup** |  |  |  | · |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **proxym** |  |  |  |  | · |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **accounts** |  |  |  |  |  | · |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **cache** |  |  |  |  |  |  | · |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **config** |  |  |  |  |  |  |  | · |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **ctl** |  |  |  |  |  |  |  |  | · |  |  |  |  |  |  |  |  |  |  |  |  |  |
| **dashboard** |  |  |  |  |  |  |  |  |  | · |  |  |  |  |  |  |  |  |  |  |  |  |
| **panel** |  |  |  |  |  |  |  |  |  |  | · |  |  |  |  |  |  |  |  |  |  |  |
| **main** |  |  |  |  |  |  |  |  |  |  |  | · |  |  |  |  |  |  |  |  |  |  |
| **middleware** |  |  |  |  |  |  |  |  |  |  |  |  | · |  |  |  |  |  |  |  |  |  |
| **providers** |  |  |  |  |  |  |  |  |  |  |  |  |  | · |  |  |  |  |  |  |  |  |
| **router** |  |  |  |  |  |  |  |  |  |  |  |  |  |  | · |  |  |  |  |  |  |  |
| **strategy** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | · |  |  |  |  |  |  |
| **virt** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | · |  |  |  |  |  |
| **browser_profiles** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | · |  |  |  |  |
| **clonebox_adapter** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | · |  |  |  |
| **profiles** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | · |  |  |
| **watch** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | · |  |
| **client** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | · |

## Fan-in / Fan-out

| Module | Fan-in | Fan-out |
|--------|--------|---------|
| `frontend.proxym-dashboard` | 0 | 0 |
| `project` | 0 | 0 |
| `scripts.jetson-entrypoint` | 0 | 0 |
| `scripts.setup` | 0 | 0 |
| `src.proxym` | 0 | 0 |
| `src.proxym.accounts` | 0 | 0 |
| `src.proxym.cache` | 0 | 0 |
| `src.proxym.config` | 0 | 0 |
| `src.proxym.ctl` | 0 | 0 |
| `src.proxym.dashboard` | 0 | 0 |
| `src.proxym.dashboard.panel` | 0 | 0 |
| `src.proxym.main` | 0 | 0 |
| `src.proxym.middleware` | 0 | 0 |
| `src.proxym.providers` | 0 | 0 |
| `src.proxym.router` | 0 | 0 |
| `src.proxym.router.strategy` | 0 | 0 |
| `src.proxym.virt` | 0 | 0 |
| `src.proxym.virt.browser_profiles` | 0 | 0 |
| `src.proxym.virt.clonebox_adapter` | 0 | 0 |
| `src.proxym.virt.profiles` | 0 | 0 |
| `src.proxym.watch` | 0 | 0 |
| `src.proxym.watch.client` | 0 | 0 |
