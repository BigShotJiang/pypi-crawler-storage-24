# proxy — API Reference

> 22 modules | 193 functions | 36 classes

## Contents

- [frontend](#frontend) (1 modules)
- [src](#src) (17 modules)

## frontend

### `frontend.proxym-dashboard` [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx)

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `AccountsPanel` | `AccountsPanel()` | 15 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L86) |
| `Card` | `Card()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L39) |
| `CostBar` | `CostBar()` | 4 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L23) |
| `ModelsTable` | `ModelsTable()` | 6 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L48) |
| `StatusBadge` | `StatusBadge()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L15) |
| `VMsPanel` | `VMsPanel()` | 12 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L142) |
| `color` | `color()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L25) |
| `get` | `get()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L7) |
| `h` | `h()` | 8 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L191) |
| `handleAction` | `handleAction()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L143) |
| `handleCreate` | `handleCreate()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L90) |
| `pct` | `pct()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L24) |
| `post` | `post()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L8) |
| `refresh` | `refresh()` | 8 | — | [source](https://github.com/wronai/proxy/blob/main/frontend/proxym-dashboard.jsx#L190) |

## src

### `src.proxym` [source](https://github.com/wronai/proxy/blob/main/src/proxym/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `Account` | 3 | Single provider account with all associated data. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L159) |
| `AccountCredentials` | 1 | Credentials for a single provider account. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L60) |
| `AccountLimits` | 2 | Provider-imposed and user-defined limits. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L115) |
| `AccountManager` | 9 | Central account registry. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L211) |
| `ProviderType` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L28) |
| `ToolBinding` | 0 | Binds an account to a specific tool/IDE instance. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L147) |
| `ToolType` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L45) |
| `UsageMetrics` | 1 | Tracked usage for a single account. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L81) |
| `DeltaBuffer` | 3 | Maintains file snapshots and computes minimal diffs. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L103) |
| `DeltaPayload` | 1 | Computed delta between two context snapshots. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L70) |
| `FileSnapshot` | 1 | Immutable snapshot of a single file. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L44) |
| `Settings` | 1 | All settings with sensible defaults. Override via env vars or .env file. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py#L9) |
| `BindToolReq` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L56) |
| `CreateAccountReq` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L45) |
| `CreateVMReq` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L64) |
| `SwitchProjectReq` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L75) |
| `AuthMiddleware` | 1 | Simple bearer token auth (matches LiteLLM master_key pattern). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py#L15) |
| `CostTrackingMiddleware` | 1 | Log request timing and attach cost headers to responses. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py#L40) |
| `Capability` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L36) |
| `ModelSpec` | 1 | Immutable specification for a single model deployment. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L47) |
| `TaskTier` | 1 | Complexity tier that determines which model class is needed. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L13) |
| `AnalysisResult` | 0 | Result of content analysis. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py#L87) |
| `CostLedger` | 4 | In-memory cost ledger with Redis persistence. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L40) |
| `Router` | 3 | Stateful router that selects the optimal model per request. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L89) |
| `RoutingDecision` | 0 | Complete routing decision with audit trail. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L29) |
| `ProjectsConfig` | 1 | Configuration for shared project mounts from the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L70) |
| `VMBackend` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L56) |
| `VMConfig` | 0 | Configuration for a development VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L90) |
| `VMOrchestrator` | 12 | Manages VMs for isolated dev environments. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L147) |
| `VMState` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L61) |
| `VMStatus` | 0 | Runtime status of a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L132) |
| `AppDataSync` | 0 | Configuration for syncing browser data into a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L111) |
| `BrowserProfile` | 1 | Detected browser profile on the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L89) |
| `CloneBoxAdapter` | 14 | Adapter wrapping the clonebox CLI for VM operations. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py#L35) |
| `CloneBoxResult` | 0 | Result of a clonebox CLI invocation. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py#L27) |
| `DeltaWatchClient` | 3 | Watches a directory and pushes context deltas to the proxy server. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py#L28) |

**`AccountLimits` methods:**

- `is_over_budget(metrics)`
- `budget_remaining(metrics)`

**`AccountManager` methods:**

- `add_account(account)`
- `remove_account(account_id)`
- `get_account(account_id)`
- `list_accounts(provider, tag)`
- `find_cheapest_active(provider)` — Find the cheapest active account for a provider (not over budget).
- `record_usage(account_id, tokens_in, tokens_out, cost_usd)`
- `bind_tool(account_id, binding)`
- `get_all_status()`
- `get_cost_summary()` — Aggregate cost summary across all accounts.

**`DeltaBuffer` methods:**

- `scan()` — Scan watch_dir and return current file snapshots.
- `compute_delta()` — Compare current files against last-sent snapshots, return delta.
- `get_stats()`

**`CostLedger` methods:**

- `can_spend(estimated_usd)`
- `record(actual_usd)`

**`Router` methods:**

- `route(analysis, explicit_model)` — Pick the best model for a request.
- `record_latency(model_id, latency_s)` — Update exponential moving average of model latency.
- `record_cost(cost_usd)`

**`VMOrchestrator` methods:**

- `create_vm(config)` — Create a new VM with overlay disk and virtiofs mount.
- `start_vm(vm_id)` — Start a VM using the appropriate backend.
- `stop_vm(vm_id, force)` — Stop a VM (graceful shutdown or force destroy).
- `pause_vm(vm_id)` — Pause (suspend) a VM.
- `resume_vm(vm_id)` — Resume a paused VM.
- `snapshot_vm(vm_id, name)` — Create a snapshot for quick restore.
- `restore_snapshot(vm_id, snapshot_name)` — Restore a previously saved snapshot.
- `delete_vm(vm_id)` — Delete a VM and all its resources.
- `get_status(vm_id)` — Get current status of a VM, querying the backend for live state.
- `list_vms()`
- `switch_project(vm_id, new_project_path)` — Hot-swap the code mount to a different project directory.
- `check_libvirt_available()` — Check if libvirt is available on this system.

**`CloneBoxAdapter` methods:**

- `is_available()` — Check if clonebox is installed and reachable.
- `version()` — Return clonebox version string, or None if not available.
- `create_vm(name, profile_path, extra_args)` — Create a VM clone from a profile.
- `start_vm(name)` — Start a VM.
- `stop_vm(name)` — Stop a VM.
- `snapshot(name, snapshot_name)` — Create a snapshot of a VM.
- `restore_snapshot(name, snapshot_name)` — Restore a VM snapshot.
- `health(name)` — Check VM health status.
- `delete_vm(name)` — Delete a VM completely.
- `list_vms()` — List all clonebox VMs.
- `detect()` — Detect current system configuration for cloning.
- `export_encrypted(name, output_path)` — Export a VM as an encrypted package.
- `get_profile_path(tool)` — Get the profile YAML path for a tool (windsurf, cursor, etc.).
- `generate_profile_name(tool, account_name)` — Generate a VM name from tool + account: e.g. 'windsurf-work-anthropic'.

**`DeltaWatchClient` methods:**

- `push_delta()` — Compute delta and push to proxy server.
- `run()` — Watch directory and push deltas on changes.
- `close()`

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `get_settings` | `get_settings()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py#L79) |
| `cmd_accounts_add` | `cmd_accounts_add(args)` | 4 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L129) |
| `cmd_accounts_costs` | `cmd_accounts_costs(args)` | 5 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L144) |
| `cmd_accounts_list` | `cmd_accounts_list(args)` | 6 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L105) |
| `cmd_browser_assign` | `cmd_browser_assign(args)` | 2 | Assign a browser profile to an account. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L300) |
| `cmd_browser_list` | `cmd_browser_list(args)` | 6 | List detected browser profiles on the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L276) |
| `cmd_browser_snapshot` | `cmd_browser_snapshot(args)` | 2 | Save browser state from VM as snapshot. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L324) |
| `cmd_browser_sync` | `cmd_browser_sync(args)` | 2 | Sync browser profile host ↔ VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L314) |
| `cmd_models` | `cmd_models(args)` | 4 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L336) |
| `cmd_serve` | `cmd_serve(args)` | 4 | Start the proxy server (delegates to proxym.main:cli). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L59) |
| `cmd_status` | `cmd_status(args)` | 7 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L75) |
| `cmd_vm_action` | `cmd_vm_action(args)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L208) |
| `cmd_vm_create` | `cmd_vm_create(args)` | 5 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L192) |
| `cmd_vm_list` | `cmd_vm_list(args)` | 3 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L172) |
| `cmd_vm_logs` | `cmd_vm_logs(args)` | 6 | Show cloud-init logs and tool logs from a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L256) |
| `cmd_vm_open` | `cmd_vm_open(args)` | 2 | Open SPICE viewer for a VM (virt-viewer). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L227) |
| `cmd_vm_ssh` | `cmd_vm_ssh(args)` | 7 | SSH into a VM (auto-detect IP via dashboard). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L239) |
| `cmd_vm_switch` | `cmd_vm_switch(args)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L217) |
| `main` | `main()` | 11 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L357) |
| `bind_tool` | `bind_tool(account_id, req)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L124) |
| `cost_detailed` | `cost_detailed()` | 2 | Per-account cost breakdown. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L146) |
| `cost_summary` | `cost_summary()` | 1 | Aggregate cost dashboard across all accounts. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L140) |
| `create_account` | `create_account(req)` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L90) |
| `create_vm` | `create_vm(req)` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L183) |
| `dashboard_root` | `dashboard_root()` | 1 | Dashboard root - redirects to system status. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L250) |
| `delete_account` | `delete_account(account_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L117) |
| `delete_vm` | `delete_vm(vm_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L241) |
| `get_account` | `get_account(account_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L109) |
| `list_accounts` | `list_accounts(provider, tag)` | 3 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L82) |
| `list_vms` | `list_vms()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L170) |
| `AccountsPanel` | `AccountsPanel()` | 15 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L81) |
| `Card` | `Card()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L34) |
| `CostBar` | `CostBar()` | 4 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L18) |
| `ModelsTable` | `ModelsTable()` | 6 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L43) |
| `StatusBadge` | `StatusBadge()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L10) |
| `VMsPanel` | `VMsPanel()` | 12 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L137) |
| `color` | `color()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L20) |
| `get` | `get()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L7) |
| `h` | `h()` | 8 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L186) |
| `handleAction` | `handleAction()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L138) |
| `handleCreate` | `handleCreate()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L85) |
| `pct` | `pct()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L19) |
| `post` | `post()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L8) |
| `refresh` | `refresh()` | 8 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L185) |
| `pause_vm` | `pause_vm(vm_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L213) |
| `resume_vm` | `resume_vm(vm_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L220) |
| `snapshot_vm` | `snapshot_vm(vm_id, name)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L227) |
| `start_vm` | `start_vm(vm_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L199) |
| `stop_vm` | `stop_vm(vm_id, force)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L206) |
| `switch_project` | `switch_project(vm_id, req)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L234) |
| `system_status` | `system_status()` | 3 | Full system overview: accounts + VMs + costs + libvirt status. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L255) |
| `budget_status` | `budget_status()` | 1 | Return current budget usage. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L226) |
| `chat_completions` | `chat_completions(request, x_task_tier)` | 17 ⚠️ | OpenAI-compatible chat completions with intelligent routing. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L262) |
| `cli` | `cli()` | 3 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L460) |
| `context_stats` | `context_stats()` | 1 | Return delta buffer statistics. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L238) |
| `dashboard_jsx` | `dashboard_jsx()` | 4 | Serve the React dashboard JSX file. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L173) |
| `dashboard_ui` | `dashboard_ui()` | 4 | Serve the React dashboard UI. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L140) |
| `health` | `health()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L135) |
| `lifespan` | `lifespan(app)` | 3 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L88) |
| `list_models` | `list_models()` | 4 | List available models (OpenAI-compatible). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L205) |
| `receive_delta` | `receive_delta(request)` | 1 | Receive context delta from the file watcher client. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L247) |
| `cheapest_model` | `cheapest_model(tier, available_providers, required_caps)` | 2 | Return the single cheapest model that satisfies constraints. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L322) |
| `get_model` | `get_model(model_id)` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L329) |
| `models_for_tier` | `models_for_tier(tier, required_caps, available_providers)` | 8 | Return models suitable for a tier, sorted by effective cost ascending. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L305) |
| `analyze_request` | `analyze_request(messages)` | 35 ⚠️ | Analyze a chat completion request and return routing metadata. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py#L98) |
| `detect_all_profiles` | `detect_all_profiles()` | 1 | Detect all browser profiles on the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L190) |
| `detect_chrome_profiles` | `detect_chrome_profiles()` | 1 | Detect Google Chrome profiles by parsing Local State. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L174) |
| `detect_chromium_profiles` | `detect_chromium_profiles()` | 1 | Detect Chromium profiles by parsing Local State. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L182) |
| `detect_firefox_profiles` | `detect_firefox_profiles()` | 9 | Detect Firefox profiles by parsing profiles.ini. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L123) |
| `generate_app_data_sync` | `generate_app_data_sync(profile, with_passwords)` | 8 | Generate an AppDataSync config for copying a profile into a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L201) |
| `get_builtin_profile` | `get_builtin_profile(tool)` | 2 | Get the path to a built-in profile YAML for a tool. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L28) |
| `list_builtin_profiles` | `list_builtin_profiles()` | 2 | List all available built-in profile names. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L36) |
| `load_profile_yaml` | `load_profile_yaml(path)` | 4 | Load a YAML profile, with graceful fallback if PyYAML is not installed. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L58) |
| `merge_profiles` | `merge_profiles(base, override)` | 5 | Deep-merge two profile dicts. Override values take precedence. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L44) |
| `cli` | `cli()` | 2 | CLI entry point for proxym-client. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py#L113) |

### `src.proxym.accounts` [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `Account` | 3 | Single provider account with all associated data. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L159) |
| `AccountCredentials` | 1 | Credentials for a single provider account. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L60) |
| `AccountLimits` | 2 | Provider-imposed and user-defined limits. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L115) |
| `AccountManager` | 9 | Central account registry. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L211) |
| `ProviderType` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L28) |
| `ToolBinding` | 0 | Binds an account to a specific tool/IDE instance. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L147) |
| `ToolType` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L45) |
| `UsageMetrics` | 1 | Tracked usage for a single account. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/accounts/__init__.py#L81) |

**`AccountLimits` methods:**

- `is_over_budget(metrics)`
- `budget_remaining(metrics)`

**`AccountManager` methods:**

- `add_account(account)`
- `remove_account(account_id)`
- `get_account(account_id)`
- `list_accounts(provider, tag)`
- `find_cheapest_active(provider)` — Find the cheapest active account for a provider (not over budget).
- `record_usage(account_id, tokens_in, tokens_out, cost_usd)`
- `bind_tool(account_id, binding)`
- `get_all_status()`
- `get_cost_summary()` — Aggregate cost summary across all accounts.

### `src.proxym.cache` [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `DeltaBuffer` | 3 | Maintains file snapshots and computes minimal diffs. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L103) |
| `DeltaPayload` | 1 | Computed delta between two context snapshots. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L70) |
| `FileSnapshot` | 1 | Immutable snapshot of a single file. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/cache/__init__.py#L44) |

**`DeltaBuffer` methods:**

- `scan()` — Scan watch_dir and return current file snapshots.
- `compute_delta()` — Compare current files against last-sent snapshots, return delta.
- `get_stats()`

### `src.proxym.config` [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `Settings` | 1 | All settings with sensible defaults. Override via env vars or .env file. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py#L9) |

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `get_settings` | `get_settings()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/config.py#L79) |

### `src.proxym.ctl` [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py)

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `cmd_accounts_add` | `cmd_accounts_add(args)` | 4 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L129) |
| `cmd_accounts_costs` | `cmd_accounts_costs(args)` | 5 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L144) |
| `cmd_accounts_list` | `cmd_accounts_list(args)` | 6 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L105) |
| `cmd_browser_assign` | `cmd_browser_assign(args)` | 2 | Assign a browser profile to an account. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L300) |
| `cmd_browser_list` | `cmd_browser_list(args)` | 6 | List detected browser profiles on the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L276) |
| `cmd_browser_snapshot` | `cmd_browser_snapshot(args)` | 2 | Save browser state from VM as snapshot. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L324) |
| `cmd_browser_sync` | `cmd_browser_sync(args)` | 2 | Sync browser profile host ↔ VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L314) |
| `cmd_models` | `cmd_models(args)` | 4 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L336) |
| `cmd_serve` | `cmd_serve(args)` | 4 | Start the proxy server (delegates to proxym.main:cli). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L59) |
| `cmd_status` | `cmd_status(args)` | 7 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L75) |
| `cmd_vm_action` | `cmd_vm_action(args)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L208) |
| `cmd_vm_create` | `cmd_vm_create(args)` | 5 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L192) |
| `cmd_vm_list` | `cmd_vm_list(args)` | 3 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L172) |
| `cmd_vm_logs` | `cmd_vm_logs(args)` | 6 | Show cloud-init logs and tool logs from a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L256) |
| `cmd_vm_open` | `cmd_vm_open(args)` | 2 | Open SPICE viewer for a VM (virt-viewer). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L227) |
| `cmd_vm_ssh` | `cmd_vm_ssh(args)` | 7 | SSH into a VM (auto-detect IP via dashboard). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L239) |
| `cmd_vm_switch` | `cmd_vm_switch(args)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L217) |
| `main` | `main()` | 11 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/ctl.py#L357) |

### `src.proxym.dashboard` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `BindToolReq` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L56) |
| `CreateAccountReq` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L45) |
| `CreateVMReq` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L64) |
| `SwitchProjectReq` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L75) |

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `bind_tool` | `bind_tool(account_id, req)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L124) |
| `cost_detailed` | `cost_detailed()` | 2 | Per-account cost breakdown. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L146) |
| `cost_summary` | `cost_summary()` | 1 | Aggregate cost dashboard across all accounts. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L140) |
| `create_account` | `create_account(req)` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L90) |
| `create_vm` | `create_vm(req)` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L183) |
| `dashboard_root` | `dashboard_root()` | 1 | Dashboard root - redirects to system status. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L250) |
| `delete_account` | `delete_account(account_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L117) |
| `delete_vm` | `delete_vm(vm_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L241) |
| `get_account` | `get_account(account_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L109) |
| `list_accounts` | `list_accounts(provider, tag)` | 3 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L82) |
| `list_vms` | `list_vms()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L170) |
| `AccountsPanel` | `AccountsPanel()` | 15 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L81) |
| `Card` | `Card()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L34) |
| `CostBar` | `CostBar()` | 4 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L18) |
| `ModelsTable` | `ModelsTable()` | 6 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L43) |
| `StatusBadge` | `StatusBadge()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L10) |
| `VMsPanel` | `VMsPanel()` | 12 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L137) |
| `color` | `color()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L20) |
| `get` | `get()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L7) |
| `h` | `h()` | 8 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L186) |
| `handleAction` | `handleAction()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L138) |
| `handleCreate` | `handleCreate()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L85) |
| `pct` | `pct()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L19) |
| `post` | `post()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L8) |
| `refresh` | `refresh()` | 8 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L185) |
| `pause_vm` | `pause_vm(vm_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L213) |
| `resume_vm` | `resume_vm(vm_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L220) |
| `snapshot_vm` | `snapshot_vm(vm_id, name)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L227) |
| `start_vm` | `start_vm(vm_id)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L199) |
| `stop_vm` | `stop_vm(vm_id, force)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L206) |
| `switch_project` | `switch_project(vm_id, req)` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L234) |
| `system_status` | `system_status()` | 3 | Full system overview: accounts + VMs + costs + libvirt status. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/__init__.py#L255) |

### `src.proxym.dashboard.panel` [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx)

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `AccountsPanel` | `AccountsPanel()` | 15 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L81) |
| `Card` | `Card()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L34) |
| `CostBar` | `CostBar()` | 4 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L18) |
| `ModelsTable` | `ModelsTable()` | 6 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L43) |
| `StatusBadge` | `StatusBadge()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L10) |
| `VMsPanel` | `VMsPanel()` | 12 ⚠️ | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L137) |
| `color` | `color()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L20) |
| `get` | `get()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L7) |
| `h` | `h()` | 8 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L186) |
| `handleAction` | `handleAction()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L138) |
| `handleCreate` | `handleCreate()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L85) |
| `pct` | `pct()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L19) |
| `post` | `post()` | 2 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L8) |
| `refresh` | `refresh()` | 8 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/dashboard/panel.jsx#L185) |

### `src.proxym.main` [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py)

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `budget_status` | `budget_status()` | 1 | Return current budget usage. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L226) |
| `chat_completions` | `chat_completions(request, x_task_tier)` | 17 ⚠️ | OpenAI-compatible chat completions with intelligent routing. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L262) |
| `cli` | `cli()` | 3 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L460) |
| `context_stats` | `context_stats()` | 1 | Return delta buffer statistics. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L238) |
| `dashboard_jsx` | `dashboard_jsx()` | 4 | Serve the React dashboard JSX file. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L173) |
| `dashboard_ui` | `dashboard_ui()` | 4 | Serve the React dashboard UI. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L140) |
| `health` | `health()` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L135) |
| `lifespan` | `lifespan(app)` | 3 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L88) |
| `list_models` | `list_models()` | 4 | List available models (OpenAI-compatible). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L205) |
| `receive_delta` | `receive_delta(request)` | 1 | Receive context delta from the file watcher client. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/main.py#L247) |

### `src.proxym.middleware` [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `AuthMiddleware` | 1 | Simple bearer token auth (matches LiteLLM master_key pattern). | [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py#L15) |
| `CostTrackingMiddleware` | 1 | Log request timing and attach cost headers to responses. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/middleware/__init__.py#L40) |

### `src.proxym.providers` [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `Capability` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L36) |
| `ModelSpec` | 1 | Immutable specification for a single model deployment. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L47) |
| `TaskTier` | 1 | Complexity tier that determines which model class is needed. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L13) |

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `cheapest_model` | `cheapest_model(tier, available_providers, required_caps)` | 2 | Return the single cheapest model that satisfies constraints. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L322) |
| `get_model` | `get_model(model_id)` | 1 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L329) |
| `models_for_tier` | `models_for_tier(tier, required_caps, available_providers)` | 8 | Return models suitable for a tier, sorted by effective cost ascending. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/providers/__init__.py#L305) |

### `src.proxym.router` [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `AnalysisResult` | 0 | Result of content analysis. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py#L87) |
| `CostLedger` | 4 | In-memory cost ledger with Redis persistence. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L40) |
| `Router` | 3 | Stateful router that selects the optimal model per request. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L89) |
| `RoutingDecision` | 0 | Complete routing decision with audit trail. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L29) |

**`CostLedger` methods:**

- `can_spend(estimated_usd)`
- `record(actual_usd)`

**`Router` methods:**

- `route(analysis, explicit_model)` — Pick the best model for a request.
- `record_latency(model_id, latency_s)` — Update exponential moving average of model latency.
- `record_cost(cost_usd)`

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `analyze_request` | `analyze_request(messages)` | 35 ⚠️ | Analyze a chat completion request and return routing metadata. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/__init__.py#L98) |

### `src.proxym.router.strategy` [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `CostLedger` | 4 | In-memory cost ledger with Redis persistence. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L40) |
| `Router` | 3 | Stateful router that selects the optimal model per request. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L89) |
| `RoutingDecision` | 0 | Complete routing decision with audit trail. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/router/strategy.py#L29) |

**`CostLedger` methods:**

- `can_spend(estimated_usd)`
- `record(actual_usd)`

**`Router` methods:**

- `route(analysis, explicit_model)` — Pick the best model for a request.
- `record_latency(model_id, latency_s)` — Update exponential moving average of model latency.
- `record_cost(cost_usd)`

### `src.proxym.virt` [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `ProjectsConfig` | 1 | Configuration for shared project mounts from the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L70) |
| `VMBackend` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L56) |
| `VMConfig` | 0 | Configuration for a development VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L90) |
| `VMOrchestrator` | 12 | Manages VMs for isolated dev environments. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L147) |
| `VMState` | 0 | — | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L61) |
| `VMStatus` | 0 | Runtime status of a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/__init__.py#L132) |
| `AppDataSync` | 0 | Configuration for syncing browser data into a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L111) |
| `BrowserProfile` | 1 | Detected browser profile on the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L89) |
| `CloneBoxAdapter` | 14 | Adapter wrapping the clonebox CLI for VM operations. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py#L35) |
| `CloneBoxResult` | 0 | Result of a clonebox CLI invocation. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py#L27) |

**`VMOrchestrator` methods:**

- `create_vm(config)` — Create a new VM with overlay disk and virtiofs mount.
- `start_vm(vm_id)` — Start a VM using the appropriate backend.
- `stop_vm(vm_id, force)` — Stop a VM (graceful shutdown or force destroy).
- `pause_vm(vm_id)` — Pause (suspend) a VM.
- `resume_vm(vm_id)` — Resume a paused VM.
- `snapshot_vm(vm_id, name)` — Create a snapshot for quick restore.
- `restore_snapshot(vm_id, snapshot_name)` — Restore a previously saved snapshot.
- `delete_vm(vm_id)` — Delete a VM and all its resources.
- `get_status(vm_id)` — Get current status of a VM, querying the backend for live state.
- `list_vms()`
- `switch_project(vm_id, new_project_path)` — Hot-swap the code mount to a different project directory.
- `check_libvirt_available()` — Check if libvirt is available on this system.

**`CloneBoxAdapter` methods:**

- `is_available()` — Check if clonebox is installed and reachable.
- `version()` — Return clonebox version string, or None if not available.
- `create_vm(name, profile_path, extra_args)` — Create a VM clone from a profile.
- `start_vm(name)` — Start a VM.
- `stop_vm(name)` — Stop a VM.
- `snapshot(name, snapshot_name)` — Create a snapshot of a VM.
- `restore_snapshot(name, snapshot_name)` — Restore a VM snapshot.
- `health(name)` — Check VM health status.
- `delete_vm(name)` — Delete a VM completely.
- `list_vms()` — List all clonebox VMs.
- `detect()` — Detect current system configuration for cloning.
- `export_encrypted(name, output_path)` — Export a VM as an encrypted package.
- `get_profile_path(tool)` — Get the profile YAML path for a tool (windsurf, cursor, etc.).
- `generate_profile_name(tool, account_name)` — Generate a VM name from tool + account: e.g. 'windsurf-work-anthropic'.

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `detect_all_profiles` | `detect_all_profiles()` | 1 | Detect all browser profiles on the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L190) |
| `detect_chrome_profiles` | `detect_chrome_profiles()` | 1 | Detect Google Chrome profiles by parsing Local State. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L174) |
| `detect_chromium_profiles` | `detect_chromium_profiles()` | 1 | Detect Chromium profiles by parsing Local State. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L182) |
| `detect_firefox_profiles` | `detect_firefox_profiles()` | 9 | Detect Firefox profiles by parsing profiles.ini. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L123) |
| `generate_app_data_sync` | `generate_app_data_sync(profile, with_passwords)` | 8 | Generate an AppDataSync config for copying a profile into a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L201) |
| `get_builtin_profile` | `get_builtin_profile(tool)` | 2 | Get the path to a built-in profile YAML for a tool. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L28) |
| `list_builtin_profiles` | `list_builtin_profiles()` | 2 | List all available built-in profile names. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L36) |
| `load_profile_yaml` | `load_profile_yaml(path)` | 4 | Load a YAML profile, with graceful fallback if PyYAML is not installed. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L58) |
| `merge_profiles` | `merge_profiles(base, override)` | 5 | Deep-merge two profile dicts. Override values take precedence. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L44) |

### `src.proxym.virt.browser_profiles` [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `AppDataSync` | 0 | Configuration for syncing browser data into a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L111) |
| `BrowserProfile` | 1 | Detected browser profile on the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L89) |

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `detect_all_profiles` | `detect_all_profiles()` | 1 | Detect all browser profiles on the host. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L190) |
| `detect_chrome_profiles` | `detect_chrome_profiles()` | 1 | Detect Google Chrome profiles by parsing Local State. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L174) |
| `detect_chromium_profiles` | `detect_chromium_profiles()` | 1 | Detect Chromium profiles by parsing Local State. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L182) |
| `detect_firefox_profiles` | `detect_firefox_profiles()` | 9 | Detect Firefox profiles by parsing profiles.ini. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L123) |
| `generate_app_data_sync` | `generate_app_data_sync(profile, with_passwords)` | 8 | Generate an AppDataSync config for copying a profile into a VM. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/browser_profiles.py#L201) |

### `src.proxym.virt.clonebox_adapter` [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `CloneBoxAdapter` | 14 | Adapter wrapping the clonebox CLI for VM operations. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py#L35) |
| `CloneBoxResult` | 0 | Result of a clonebox CLI invocation. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/clonebox_adapter.py#L27) |

**`CloneBoxAdapter` methods:**

- `is_available()` — Check if clonebox is installed and reachable.
- `version()` — Return clonebox version string, or None if not available.
- `create_vm(name, profile_path, extra_args)` — Create a VM clone from a profile.
- `start_vm(name)` — Start a VM.
- `stop_vm(name)` — Stop a VM.
- `snapshot(name, snapshot_name)` — Create a snapshot of a VM.
- `restore_snapshot(name, snapshot_name)` — Restore a VM snapshot.
- `health(name)` — Check VM health status.
- `delete_vm(name)` — Delete a VM completely.
- `list_vms()` — List all clonebox VMs.
- `detect()` — Detect current system configuration for cloning.
- `export_encrypted(name, output_path)` — Export a VM as an encrypted package.
- `get_profile_path(tool)` — Get the profile YAML path for a tool (windsurf, cursor, etc.).
- `generate_profile_name(tool, account_name)` — Generate a VM name from tool + account: e.g. 'windsurf-work-anthropic'.

### `src.proxym.virt.profiles` [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py)

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `get_builtin_profile` | `get_builtin_profile(tool)` | 2 | Get the path to a built-in profile YAML for a tool. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L28) |
| `list_builtin_profiles` | `list_builtin_profiles()` | 2 | List all available built-in profile names. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L36) |
| `load_profile_yaml` | `load_profile_yaml(path)` | 4 | Load a YAML profile, with graceful fallback if PyYAML is not installed. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L58) |
| `merge_profiles` | `merge_profiles(base, override)` | 5 | Deep-merge two profile dicts. Override values take precedence. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/virt/profiles/__init__.py#L44) |

### `src.proxym.watch` [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py)

| Class | Methods | Description | Source |
|-------|---------|-------------|--------|
| `DeltaWatchClient` | 3 | Watches a directory and pushes context deltas to the proxy server. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py#L28) |

**`DeltaWatchClient` methods:**

- `push_delta()` — Compute delta and push to proxy server.
- `run()` — Watch directory and push deltas on changes.
- `close()`

| Function | Signature | CC | Description | Source |
|----------|-----------|----|-----------  |--------|
| `cli` | `cli()` | 2 | CLI entry point for proxym-client. | [source](https://github.com/wronai/proxy/blob/main/src/proxym/watch/__init__.py#L113) |
