# Getting Started with proxy

## Prerequisites

- Python >=3.11
- pip (or your preferred package manager)
- 13 dependencies (installed automatically)

## Installation

```bash
pip install proxym
```

To install from source:

```bash
git clone https://github.com/wronai/proxy
cd proxy
pip install -e .
```

## Quick Start

### Command Line

```bash
# Generate full documentation for your project
proxy ./path/to/your/project

# Preview what would be generated (no file writes)
proxy ./path/to/your/project --dry-run

# Only regenerate README
proxy ./path/to/your/project --readme-only
```

### Python API

```python
from src.proxym.router import analyze_request

# Analyze a chat completion request and return routing metadata.
result = analyze_request("messages")
```

## What's Next

- 📖 [API Reference](api.md) — Full function and class documentation
- 🏗️ [Architecture](architecture.md) — System design and module relationships
- 📊 [Coverage Report](coverage.md) — Docstring coverage analysis
- 🔗 [Dependency Graph](dependency-graph.md) — Module dependency visualization
