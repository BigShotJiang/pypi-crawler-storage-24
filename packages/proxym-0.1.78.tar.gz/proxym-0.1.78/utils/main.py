"""Main validation utilities for refactoring scripts."""

from .validation_common import run_validation_main


def create_validation_main(title: str, components: dict, base_path: str, original_file: str, benefits_bullet: str):
    """Create a main validation function for refactoring scripts.
    
    Args:
        title: The title of the refactoring validation
        components: Dictionary mapping component files to their main components
        base_path: Base path where component files are located
        original_file: Path to the original file being refactored
        benefits_bullet: Brief description of benefits for summary
        
    Returns:
        Result of run_validation_main call
    """
    return run_validation_main(
        title=title,
        components=components,
        base_path=base_path,
        original_file=original_file,
        benefits_bullet=benefits_bullet
    )
