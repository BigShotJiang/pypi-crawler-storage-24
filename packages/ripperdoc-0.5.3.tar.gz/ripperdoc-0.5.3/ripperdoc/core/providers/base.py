"""Shared abstractions for provider clients."""

from __future__ import annotations

import asyncio
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import (
    Any,
    AsyncIterable,
    AsyncIterator,
    Awaitable,
    Callable,
    Dict,
    Iterable,
    List,
    Optional,
)

from ripperdoc.core.config import ModelProfile
from ripperdoc.core.providers.errors import ProviderMappedError, ProviderTimeoutError
from ripperdoc.core.tool import Tool
from ripperdoc.utils.log import get_logger

logger = get_logger()

ProgressCallback = Callable[[str], Awaitable[None]]


@dataclass
class ProviderResponse:
    """Normalized provider response payload."""

    content_blocks: List[Dict[str, Any]]
    usage_tokens: Dict[str, int]
    cost_usd: float
    duration_ms: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    # Error handling fields
    is_error: bool = False
    error_code: Optional[str] = None  # e.g., "permission_denied", "context_length_exceeded"
    error_message: Optional[str] = None

    @classmethod
    def create_error(
        cls,
        error_code: str,
        error_message: str,
        duration_ms: float = 0.0,
    ) -> "ProviderResponse":
        """Create an error response with a text block containing the error message."""
        return cls(
            content_blocks=[{"type": "text", "text": f"[API Error] {error_message}"}],
            usage_tokens={},
            cost_usd=0.0,
            duration_ms=duration_ms,
            is_error=True,
            error_code=error_code,
            error_message=error_message,
        )


class ProviderClient(ABC):
    """Abstract base for model provider clients."""

    @abstractmethod
    async def call(
        self,
        *,
        model_profile: ModelProfile,
        system_prompt: str,
        normalized_messages: List[Dict[str, Any]],
        tools: List[Tool[Any, Any]],
        tool_mode: str,
        stream: bool,
        progress_callback: Optional[ProgressCallback],
        request_timeout: Optional[float],
        max_retries: int,
        max_thinking_tokens: int,
    ) -> ProviderResponse:
        """Execute a model call and return a normalized response."""


def sanitize_tool_history(normalized_messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Normalize tool-call history for strict provider sequencing requirements.

    This function enforces two invariants for assistant `tool_use` turns:
    1. Drop unpaired `tool_use` blocks that have no later `tool_result`.
    2. Collapse matching `tool_result` blocks into a single immediate next user
       message after the assistant turn (Anthropic-compatible requirement).
    """

    def _part_type(part: Any) -> Any:
        if isinstance(part, dict):
            return part.get("type")
        return getattr(part, "type", None)

    def _part_tool_id(part: Any) -> str:
        if isinstance(part, dict):
            return str(part.get("tool_use_id") or part.get("id") or "")
        return str(getattr(part, "tool_use_id", None) or getattr(part, "id", None) or "")

    def _tool_result_ids(msg: Dict[str, Any]) -> set[str]:
        ids: set[str] = set()
        content = msg.get("content")
        if not isinstance(content, list):
            return ids
        for part in content:
            if _part_type(part) != "tool_result":
                continue
            tid = _part_tool_id(part)
            if tid:
                ids.add(tid)
        return ids

    # Build lookahead map to identify paired tool_use IDs.
    tool_results_after: List[set[str]] = []
    if normalized_messages:
        tool_results_after = [set() for _ in normalized_messages]
        future_ids: set[str] = set()
        for idx in range(len(normalized_messages) - 1, -1, -1):
            tool_results_after[idx] = set(future_ids)
            future_ids.update(_tool_result_ids(normalized_messages[idx]))

    sanitized: List[Dict[str, Any]] = []
    i = 0
    while i < len(normalized_messages):
        message = normalized_messages[i]
        if message.get("role") != "assistant":
            sanitized.append(message)
            i += 1
            continue

        content = message.get("content")
        if not isinstance(content, list):
            sanitized.append(message)
            i += 1
            continue

        tool_use_ids = [
            _part_tool_id(part)
            for part in content
            if _part_type(part) == "tool_use" and _part_tool_id(part)
        ]
        if not tool_use_ids:
            sanitized.append(message)
            i += 1
            continue

        future_results = tool_results_after[i] if tool_results_after else set()
        paired_ids = {tool_id for tool_id in tool_use_ids if tool_id in future_results}
        unpaired_ids = {tool_id for tool_id in tool_use_ids if tool_id not in future_results}

        filtered_content = [
            part
            for part in content
            if not (_part_type(part) == "tool_use" and _part_tool_id(part) in unpaired_ids)
        ]
        if not filtered_content:
            logger.debug(
                "[provider_clients] Dropped assistant message with unpaired tool_use blocks",
                extra={"unpaired_ids": list(unpaired_ids)},
            )
            i += 1
            continue

        sanitized.append({**message, "content": filtered_content})
        if unpaired_ids:
            logger.debug(
                "[provider_clients] Sanitized message to remove unpaired tool_use blocks",
                extra={"unpaired_ids": list(unpaired_ids)},
            )

        # No paired IDs left: nothing to fold.
        if not paired_ids:
            i += 1
            continue

        # Collect paired tool_result blocks from following user messages until we hit
        # the next assistant turn, then insert a single immediate user message.
        collected_results: List[Any] = []
        consumed_user_messages: List[Dict[str, Any]] = []
        seen_result_ids: set[str] = set()
        j = i + 1
        while j < len(normalized_messages):
            next_message = normalized_messages[j]
            if next_message.get("role") == "assistant":
                break

            if next_message.get("role") != "user":
                consumed_user_messages.append(next_message)
                j += 1
                continue

            next_content = next_message.get("content")
            if not isinstance(next_content, list):
                consumed_user_messages.append(next_message)
                j += 1
                continue

            remaining_parts: List[Any] = []
            for part in next_content:
                if _part_type(part) != "tool_result":
                    remaining_parts.append(part)
                    continue
                result_id = _part_tool_id(part)
                if result_id in paired_ids and result_id not in seen_result_ids:
                    collected_results.append(part)
                    seen_result_ids.add(result_id)
                else:
                    remaining_parts.append(part)

            if remaining_parts:
                consumed_user_messages.append({**next_message, "content": remaining_parts})
            if paired_ids.issubset(seen_result_ids):
                j += 1
                break
            j += 1

        if collected_results:
            sanitized.append({"role": "user", "content": collected_results})
        sanitized.extend(consumed_user_messages)
        i = j

    return sanitized


def sanitize_openai_tool_history(normalized_messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Normalize OpenAI chat-completions tool-call history.

    Enforces strict pairing for OpenAI-compatible message sequences:
    1. Drop assistant tool_calls that have no later matching role=tool response.
    2. Drop role=tool messages that do not correspond to an earlier assistant tool_call.
    3. If an assistant message mixes paired and unpaired tool_calls, keep only the paired subset.
    4. Fold matching role=tool messages to immediately follow the assistant tool_call turn.
    """
    tool_response_indices: Dict[str, List[int]] = {}
    for idx, message in enumerate(normalized_messages):
        if message.get("role") != "tool":
            continue
        tool_call_id = str(message.get("tool_call_id") or "").strip()
        if tool_call_id:
            tool_response_indices.setdefault(tool_call_id, []).append(idx)

    sanitized: List[Dict[str, Any]] = []
    consumed_tool_indices: set[int] = set()
    i = 0

    while i < len(normalized_messages):
        message = normalized_messages[i]
        role = message.get("role")

        if role == "tool":
            tool_call_id = str(message.get("tool_call_id") or "").strip()
            if i in consumed_tool_indices:
                i += 1
                continue
            logger.debug(
                "[provider_clients] Dropped orphan OpenAI tool response",
                extra={"message_index": i, "tool_call_id": tool_call_id},
            )
            i += 1
            continue

        if role != "assistant":
            sanitized.append(message)
            i += 1
            continue

        tool_calls = message.get("tool_calls")
        if not isinstance(tool_calls, list) or not tool_calls:
            sanitized.append(message)
            i += 1
            continue

        paired_tool_calls: List[Dict[str, Any]] = []
        paired_ids: List[str] = []
        for tool_call in tool_calls:
            if not isinstance(tool_call, dict):
                continue
            tool_call_id = str(tool_call.get("id") or "").strip()
            if not tool_call_id:
                continue
            response_positions = tool_response_indices.get(tool_call_id, [])
            if any(response_idx > i and response_idx not in consumed_tool_indices for response_idx in response_positions):
                paired_tool_calls.append(tool_call)
                paired_ids.append(tool_call_id)

        if not paired_tool_calls:
            logger.debug(
                "[provider_clients] Dropped OpenAI assistant message with unpaired tool_calls",
                extra={"message_index": i},
            )
            i += 1
            continue

        if len(paired_tool_calls) != len(tool_calls):
            logger.debug(
                "[provider_clients] Sanitized OpenAI assistant tool_calls to paired subset",
                extra={
                    "message_index": i,
                    "before_count": len(tool_calls),
                    "after_count": len(paired_tool_calls),
                },
            )

        sanitized.append({**message, "tool_calls": paired_tool_calls})

        expected_ids = set(paired_ids)
        seen_ids: set[str] = set()
        deferred_messages: List[Dict[str, Any]] = []
        j = i + 1
        while j < len(normalized_messages):
            next_message = normalized_messages[j]
            next_role = next_message.get("role")
            if next_role == "assistant":
                break

            if next_role == "tool":
                tool_call_id = str(next_message.get("tool_call_id") or "").strip()
                if tool_call_id in expected_ids and tool_call_id not in seen_ids:
                    sanitized.append(next_message)
                    consumed_tool_indices.add(j)
                    seen_ids.add(tool_call_id)
                else:
                    logger.debug(
                        "[provider_clients] Dropped orphan or duplicate OpenAI tool response",
                        extra={"message_index": j, "tool_call_id": tool_call_id},
                    )
                if expected_ids.issubset(seen_ids):
                    j += 1
                    break
                j += 1
                continue

            deferred_messages.append(next_message)
            j += 1

        sanitized.extend(deferred_messages)
        i = j

    return sanitized


def _retry_delay_seconds(attempt: int, base_delay: float = 0.5, max_delay: float = 32.0) -> float:
    """Calculate exponential backoff with jitter."""
    capped_base: float = float(min(base_delay * (2 ** max(0, attempt - 1)), max_delay))
    jitter: float = float(random.random() * 0.25 * capped_base)
    return float(capped_base + jitter)


async def iter_with_timeout(
    stream: Iterable[Any] | AsyncIterable[Any], timeout: Optional[float]
) -> AsyncIterator[Any]:
    """Yield items from an async or sync iterable, enforcing per-item timeout if provided."""
    if timeout is None or timeout <= 0:
        if hasattr(stream, "__aiter__"):
            async for item in stream:  # type: ignore[async-for]
                yield item
        else:
            for item in stream:
                yield item
        return

    if hasattr(stream, "__aiter__"):
        aiter = stream.__aiter__()  # type: ignore[attr-defined]
        while True:
            try:
                yield await asyncio.wait_for(aiter.__anext__(), timeout=timeout)  # type: ignore[attr-defined]
            except StopAsyncIteration:
                break
    else:
        iterator = iter(stream)
        while True:
            try:
                next_item = await asyncio.wait_for(
                    asyncio.to_thread(next, iterator), timeout=timeout
                )
            except StopIteration:
                break
            yield next_item


async def call_with_timeout_and_retries(
    coro_factory: Callable[[], Awaitable[Any]],
    request_timeout: Optional[float],
    max_retries: int,
) -> Any:
    """Run a coroutine with timeout and limited retries (exponential backoff)."""
    attempts = max(0, int(max_retries)) + 1
    last_error: Optional[Exception] = None

    for attempt in range(1, attempts + 1):
        try:
            if request_timeout and request_timeout > 0:
                return await asyncio.wait_for(coro_factory(), timeout=request_timeout)
            return await coro_factory()
        except (asyncio.TimeoutError, ProviderTimeoutError) as exc:
            last_error = exc
            if attempt == attempts:
                break
            delay_seconds = _retry_delay_seconds(attempt)
            logger.warning(
                "[provider_clients] Request timed out; retrying",
                extra={
                    "attempt": attempt,
                    "max_retries": attempts - 1,
                    "delay_seconds": round(delay_seconds, 3),
                },
            )
            await asyncio.sleep(delay_seconds)
        except ProviderMappedError as exc:
            if not exc.retryable:
                raise
            last_error = exc
            if attempt == attempts:
                break
            delay_seconds = _retry_delay_seconds(attempt)
            logger.warning(
                "[provider_clients] Retriable provider error; retrying",
                extra={
                    "attempt": attempt,
                    "max_retries": attempts - 1,
                    "delay_seconds": round(delay_seconds, 3),
                    "error_code": exc.error_code,
                },
            )
            await asyncio.sleep(delay_seconds)
        except asyncio.CancelledError:
            raise  # Don't suppress task cancellation
        except (RuntimeError, ValueError, TypeError, OSError, ConnectionError) as exc:
            # Non-timeout errors are not retried; surface immediately.
            raise exc
    if last_error:
        if isinstance(last_error, ProviderMappedError):
            raise last_error
        if isinstance(last_error, asyncio.TimeoutError):
            raise ProviderTimeoutError(f"Request timed out after {attempts} attempts") from last_error
        raise RuntimeError(f"Request timed out after {attempts} attempts") from last_error
    raise RuntimeError("Unexpected error executing request with retries")
