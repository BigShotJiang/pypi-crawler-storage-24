"""Hooks system for Ripperdoc.

This module provides a hook system for coding-agent workflows,
allowing users to execute custom scripts at various points in the workflow.

Hook events:
- PreToolUse: Before a tool is called (can block/allow/ask)
- PermissionRequest: When user is shown permission dialog (can allow/deny)
- PostToolUse: After a tool completes
- UserPromptSubmit: When user submits a prompt (can block)
- Notification: When a notification is sent
- Stop: When the agent stops responding (can block to continue)
- SubagentStop: When a subagent task completes (can block to continue)
- PreCompact: Before conversation compaction
- SessionStart: When a session starts or resumes
- SessionEnd: When a session ends
- WorktreeCreate: Before/when creating a hook-managed worktree
- WorktreeRemove: Before/when removing a hook-managed worktree

Configuration is stored in:
- ~/.ripperdoc/hooks.json (user)
- .ripperdoc/hooks.json (project)
- .ripperdoc/hooks.local.json (local, git-ignored)
"""

from ripperdoc.core.hooks.events import (
    HookEvent,
    HookDecision,
    HookInput,
    HookOutput,
    PreToolUseInput,
    PermissionRequestInput,
    PostToolUseInput,
    UserPromptSubmitInput,
    NotificationInput,
    StopInput,
    SubagentStopInput,
    PreCompactInput,
    SessionStartInput,
    SessionEndInput,
    WorktreeCreateInput,
    WorktreeRemoveInput,
    PreToolUseHookOutput,
    PermissionRequestHookOutput,
    PermissionRequestDecision,
    PostToolUseHookOutput,
    UserPromptSubmitHookOutput,
    SessionStartHookOutput,
)
from ripperdoc.core.hooks.config import (
    HookDefinition,
    HookMatcher,
    HooksConfig,
    load_hooks_config,
    get_merged_hooks_config,
    get_global_hooks_path,
    get_project_hooks_path,
    get_project_local_hooks_path,
)
from typing import Any

__all__ = [
    # Events
    "HookEvent",
    "HookDecision",
    "HookInput",
    "HookOutput",
    "PreToolUseInput",
    "PermissionRequestInput",
    "PostToolUseInput",
    "UserPromptSubmitInput",
    "NotificationInput",
    "StopInput",
    "SubagentStopInput",
    "PreCompactInput",
    "SessionStartInput",
    "SessionEndInput",
    "WorktreeCreateInput",
    "WorktreeRemoveInput",
    # Hook-specific outputs
    "PreToolUseHookOutput",
    "PermissionRequestHookOutput",
    "PermissionRequestDecision",
    "PostToolUseHookOutput",
    "UserPromptSubmitHookOutput",
    "SessionStartHookOutput",
    # Config
    "HookDefinition",
    "HookMatcher",
    "HooksConfig",
    "load_hooks_config",
    "get_merged_hooks_config",
    "get_global_hooks_path",
    "get_project_hooks_path",
    "get_project_local_hooks_path",
    # Executor (lazy)
    "HookExecutor",
    "LLMCallback",
    # Manager (lazy)
    "HookManager",
    "HookResult",
    "hook_manager",
    "init_hook_manager",
]


def __getattr__(name: str) -> Any:  # pragma: no cover - import-time lazy loading
    if name in {"HookExecutor", "LLMCallback"}:
        from ripperdoc.core.hooks.executor import HookExecutor, LLMCallback

        return {"HookExecutor": HookExecutor, "LLMCallback": LLMCallback}[name]
    if name in {"HookManager", "HookResult", "hook_manager", "init_hook_manager"}:
        from ripperdoc.core.hooks.manager import HookManager, HookResult, hook_manager, init_hook_manager

        return {
            "HookManager": HookManager,
            "HookResult": HookResult,
            "hook_manager": hook_manager,
            "init_hook_manager": init_hook_manager,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
