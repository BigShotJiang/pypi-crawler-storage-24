"""Configuration and hook helpers for stdio protocol handler."""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from typing import Any, Awaitable, Callable, Coroutine, Optional, cast

from ripperdoc.core.config import get_effective_config
from ripperdoc.core.tool_defaults import filter_tools_by_names
from ripperdoc.core.hooks.config import HookDefinition, HookMatcher, HooksConfig, DEFAULT_HOOK_TIMEOUT
from ripperdoc.core.hooks.events import HookOutput
from ripperdoc.core.hooks.manager import hook_manager
from ripperdoc.core.permission_engine import PermissionPreview, PermissionResult
from ripperdoc.core.permission_engine import make_permission_checker
from ripperdoc.core.plan_mode import ensure_plan_file_directory
from ripperdoc.core.system_prompt import build_system_prompt
from ripperdoc.core.system_prompt_overrides import compose_system_prompt, select_base_system_prompt
from ripperdoc.protocol.models import UserMessageData, UserStreamMessage
from ripperdoc.utils.messaging.messages import create_hook_additional_context_message
from ripperdoc.utils.memory import build_memory_instructions

from .timeouts import STDIO_HOOK_TIMEOUT_SEC

logger = logging.getLogger("ripperdoc.protocol.stdio.handler")


class StdioConfigMixin:
    _PERMISSION_MODES: set[str]
    _can_use_tool: Any | None
    _local_can_use_tool: Any | None
    _query_context: Any | None
    _custom_system_prompt: str | None
    _append_system_prompt: str | None
    _skill_instructions: str | None
    _output_style: str
    _output_language: str
    _session_id: str | None
    _sdk_hook_scope: HooksConfig | None
    _session_additional_working_dirs: set[str]
    _session_agent_prompt: str | None
    _pre_plan_mode: str | None
    _clear_context_after_turn: bool

    def _normalize_permission_mode(self, mode: Any) -> str:
        """Normalize permission mode to a supported value."""
        if isinstance(mode, str) and mode in self._PERMISSION_MODES:
            return mode
        return "default"

    def _is_bypass_permissions_mode_available(self) -> bool:
        config = get_effective_config(self._project_path)
        return not bool(getattr(config, "disable_bypass_permissions_mode", False))

    def _normalize_tool_list(self, value: Any) -> list[str] | None:
        """Normalize tool list inputs from SDK/CLI options."""
        if value is None:
            return None
        if isinstance(value, str):
            raw = value.strip()
            if raw == "":
                return []
            return [item.strip() for item in raw.split(",") if item.strip()]
        if isinstance(value, (list, tuple, set)):
            names: list[str] = []
            for item in value:
                if item is None:
                    continue
                name = str(item).strip()
                if name:
                    names.append(name)
            return names
        return None

    def _apply_tool_filters(
        self,
        tools: list[Any],
        *,
        allowed_tools: list[str] | None,  # noqa: ARG002 – permission: auto-approve
        disallowed_tools: list[str] | None,  # noqa: ARG002 – permission: auto-deny
        tools_list: list[str] | None,
    ) -> list[Any]:
        """Apply tool-set filters while keeping Task tool consistent.

        ``allowed_tools`` and ``disallowed_tools`` control permission
        auto-approval / auto-denial and do **not** affect the tool set.

        The tool set is determined by:

        * ``tools_list`` – explicit tool list (e.g. ``--tools`` CLI flag).
        * ``preset == "default"`` – adds all built-in tools.
        """
        preset = getattr(self, "_tools_preset", None)
        if tools_list is None and preset is None:
            return tools

        tool_names = [getattr(tool, "name", tool.__class__.__name__) for tool in tools]
        allow_set: set[str] | None = None

        if tools_list is not None:
            allow_set = set(tools_list)

        # "default" preset adds all built-in tools to the allow set.
        # When no explicit tools_list is provided, preserve all registered
        # tools (built-in + MCP) so that MCP servers aren't silently stripped.
        if preset == "default":
            if allow_set is None:
                return tools
            builtin_names = {name for name in tool_names if not name.startswith("mcp__")}
            allow_set = allow_set | builtin_names

        if allow_set is None:
            return tools

        return filter_tools_by_names(tools, list(allow_set))

    def _apply_permission_mode(self, mode: str) -> None:
        """Apply permission mode across query context, hooks, and permissions."""
        normalized_mode = self._normalize_permission_mode(mode)
        if normalized_mode == "bypassPermissions" and not self._is_bypass_permissions_mode_available():
            normalized_mode = "default"

        previous_mode = "default"
        if self._query_context is not None:
            previous_mode = self._normalize_permission_mode(
                getattr(self._query_context, "permission_mode", "default")
            )
        if previous_mode == "plan" and normalized_mode != "plan":
            self._pre_plan_mode = None
        yolo_mode = normalized_mode == "bypassPermissions"
        if self._query_context:
            self._query_context.yolo_mode = yolo_mode
            self._query_context.permission_mode = normalized_mode
            self._query_context.pre_plan_mode = self._pre_plan_mode

        hook_manager.set_permission_mode(normalized_mode)

        if yolo_mode and not self._disallowed_tools:
            self._local_can_use_tool = None
            self._can_use_tool = None
            self._sdk_can_use_tool_supported = True
        else:
            self._local_can_use_tool = make_permission_checker(
                self._project_path,
                yolo_mode=yolo_mode,
                permission_mode=normalized_mode,
                is_bypass_permissions_mode_available=self._is_bypass_permissions_mode_available(),
                plan_file_path=(
                    self._query_context.plan_file_path
                    if self._query_context is not None
                    else None
                ),
                session_additional_working_dirs=self._session_additional_working_dirs,
                session_allowed_tools=self._allowed_tools,
                session_disallowed_tools=self._disallowed_tools,
            )
            self._sdk_can_use_tool_supported = True

            if self._sdk_can_use_tool_enabled:

                async def sdk_can_use_tool(tool: Any, parsed_input: Any) -> PermissionResult:
                    return await self._check_tool_permissions_via_sdk(
                        tool,
                        parsed_input,
                        force_prompt=False,
                    )

                async def sdk_force_prompt(tool: Any, parsed_input: Any) -> PermissionResult:
                    return await self._check_tool_permissions_via_sdk(
                        tool,
                        parsed_input,
                        force_prompt=True,
                    )

                setattr(sdk_can_use_tool, "force_prompt", sdk_force_prompt)
                self._can_use_tool = sdk_can_use_tool
            else:
                self._can_use_tool = cast(
                    Optional[Callable[[Any, Any], Coroutine[Any, Any, PermissionResult]]],
                    self._local_can_use_tool,
                )

    def _enter_plan_mode(self) -> None:
        """Switch runtime permission mode to plan and persist previous mode."""
        current_mode = "default"
        if self._query_context is not None:
            current_mode = self._normalize_permission_mode(
                getattr(self._query_context, "permission_mode", "default")
            )
        if current_mode != "plan":
            self._pre_plan_mode = current_mode
        if self._query_context is not None and self._query_context.plan_file_path:
            ensure_plan_file_directory(self._query_context.plan_file_path)
        self._apply_permission_mode("plan")

    def _exit_plan_mode(self) -> None:
        """Restore runtime mode from pre-plan state (or default)."""
        target_mode = self._normalize_permission_mode(self._pre_plan_mode or "default")
        if target_mode == "plan":
            target_mode = "default"
        self._pre_plan_mode = None
        self._apply_permission_mode(target_mode)

    def _on_exit_plan_mode(
        self,
        *,
        plan: str,  # noqa: ARG002
        is_agent: bool = False,  # noqa: ARG002
    ) -> dict[str, Any]:
        """Non-interactive plan-exit callback for stdio sessions."""
        target_mode = self._normalize_permission_mode(self._pre_plan_mode or "default")
        if target_mode == "plan":
            target_mode = "default"
        if target_mode == "bypassPermissions" and not self._is_bypass_permissions_mode_available():
            target_mode = "default"

        self._pre_plan_mode = None
        self._apply_permission_mode(target_mode)
        if self._query_context is not None:
            self._query_context.has_exited_plan_mode = True
        # In stdio mode, keep context by default.
        self._clear_context_after_turn = False
        return {
            "approved": True,
            "permission_mode": target_mode,
            "clear_context": False,
        }

    def _coerce_bool_option(self, value: Any, default: bool) -> bool:
        """Parse flexible bool option values from SDK initialize payloads."""
        if value is None:
            return default
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"1", "true", "yes", "y", "on"}:
                return True
            if normalized in {"0", "false", "no", "n", "off"}:
                return False
        return default

    def _should_route_sdk_can_use_tool(
        self,
        tool: Any,
        parsed_input: Any,
        *,
        force_prompt: bool,
    ) -> bool:
        """Return True when SDK should be asked for approval/input."""
        if force_prompt:
            return True
        tool_name = getattr(tool, "name", "")
        if tool_name == "AskUserQuestion":
            return True
        try:
            return bool(tool.needs_permissions(parsed_input))
        except Exception:
            logger.warning(
                "[stdio] tool.needs_permissions failed for '%s'; routing to SDK can_use_tool",
                tool_name,
                exc_info=True,
            )
            return True

    async def _preview_local_can_use_tool(
        self,
        tool: Any,
        parsed_input: Any,
        *,
        force_prompt: bool,
    ) -> tuple[bool, Optional[PermissionResult], bool]:
        """Best-effort non-interactive preview using local checker internals.

        Returns:
            (has_preview, immediate_result, requires_user_input)
        """
        checker = self._local_can_use_tool
        if checker is None:
            return True, PermissionResult(result=True), False

        preview_attr = "preview_force_prompt" if force_prompt else "preview"
        preview_fn = getattr(checker, preview_attr, None)
        if not callable(preview_fn):
            return False, None, False

        preview = preview_fn(tool, parsed_input)
        if inspect.isawaitable(preview):
            preview = await preview

        if isinstance(preview, PermissionPreview):
            if preview.requires_user_input:
                return True, None, True
            if preview.result is not None:
                return True, preview.result, False
            return True, PermissionResult(result=True), False

        return False, None, False

    async def _evaluate_local_can_use_tool(
        self,
        tool: Any,
        parsed_input: Any,
        *,
        force_prompt: bool,
    ) -> PermissionResult:
        """Fallback local permission evaluation."""
        checker = self._local_can_use_tool
        if checker is None:
            return PermissionResult(result=True)

        decision_fn = checker
        if force_prompt and hasattr(checker, "force_prompt"):
            decision_fn = getattr(checker, "force_prompt")

        raw_result = decision_fn(tool, parsed_input)
        result: Any
        if inspect.isawaitable(raw_result):
            result = await cast(Awaitable[Any], raw_result)
        else:
            result = raw_result

        if isinstance(result, PermissionResult):
            return result
        if isinstance(result, tuple) and len(result) == 2:
            return PermissionResult(result=bool(result[0]), message=result[1])
        return PermissionResult(result=bool(result))

    async def _check_tool_permissions_via_sdk(
        self,
        tool: Any,
        parsed_input: Any,
        *,
        force_prompt: bool,
    ) -> PermissionResult:
        """Call SDK can_use_tool callback for approvals/clarifying questions."""
        tool_name = getattr(tool, "name", "")
        must_route_to_sdk = tool_name == "AskUserQuestion"

        if not must_route_to_sdk:
            has_preview, preview_result, requires_user_input = await self._preview_local_can_use_tool(
                tool,
                parsed_input,
                force_prompt=force_prompt,
            )
            if has_preview:
                if not requires_user_input:
                    return preview_result or PermissionResult(result=True)
            elif not self._should_route_sdk_can_use_tool(tool, parsed_input, force_prompt=force_prompt):
                return PermissionResult(result=True)

        if not self._sdk_can_use_tool_supported:
            return await self._evaluate_local_can_use_tool(
                tool, parsed_input, force_prompt=force_prompt
            )

        tool_input = (
            parsed_input.model_dump()
            if hasattr(parsed_input, "model_dump")
            else dict(parsed_input)
            if isinstance(parsed_input, dict)
            else {"value": str(parsed_input)}
        )
        tool_input = self._sanitize_for_json(tool_input)

        request_payload = {
            "name": "ripperdoc.can_use_tool",
            "arguments": {
                "tool_name": tool_name,
                "input": tool_input,
                "force_prompt": bool(force_prompt),
            },
        }
        request_timeout = 0.0 if tool_name == "AskUserQuestion" else STDIO_HOOK_TIMEOUT_SEC

        try:
            response = await self._send_control_request(
                request_payload,
                timeout=request_timeout,
            )
        except asyncio.TimeoutError:
            logger.warning(
                "[stdio] SDK can_use_tool timed out; falling back to local permissions",
            )
            self._sdk_can_use_tool_supported = False
            return await self._evaluate_local_can_use_tool(
                tool, parsed_input, force_prompt=force_prompt
            )
        except Exception as exc:
            logger.warning(
                "[stdio] SDK can_use_tool unavailable (%s); falling back to local permissions",
                exc,
            )
            self._sdk_can_use_tool_supported = False
            return await self._evaluate_local_can_use_tool(
                tool, parsed_input, force_prompt=force_prompt
            )

        if not isinstance(response, dict):
            return PermissionResult(
                result=False,
                message="Invalid can_use_tool response from SDK",
            )

        behavior = str(response.get("behavior") or response.get("decision") or "").lower()
        if behavior == "allow":
            updated_input = response.get("updatedInput")
            if updated_input is None:
                updated_input = tool_input
            return PermissionResult(result=True, updated_input=updated_input)

        if behavior == "deny":
            return PermissionResult(
                result=False,
                message=response.get("message") or "User denied this action",
            )

        return PermissionResult(
            result=False,
            message="Invalid can_use_tool response from SDK",
        )

    def _collect_hook_context_messages(self, hook_result: Any, hook_event: str) -> list[Any]:
        messages: list[Any] = []
        additional_context = getattr(hook_result, "additional_context", None)
        if additional_context:
            message = create_hook_additional_context_message(
                str(additional_context),
                hook_name=hook_event,
                hook_event=hook_event,
            )
            if message is not None:
                messages.append(message)
        return messages

    def _build_hook_notice_stream_message(
        self,
        text: str,
        hook_event: str,
        *,
        tool_name: str | None = None,
        level: str = "info",
    ) -> UserStreamMessage:
        return UserStreamMessage(
            session_id=self._session_id,
            message=UserMessageData(
                content=text,
                metadata={
                    "hook_notice": True,
                    "hook_event": hook_event,
                    "tool_name": tool_name,
                    "level": level,
                },
            ),
        )

    def _resolve_system_prompt(
        self,
        tools: list[Any],
        prompt: str,
        mcp_instructions: str | None,
        hook_instructions: list[str] | None = None,
        custom_system_prompt: str | None = None,
        append_system_prompt: str | None = None,
    ) -> str:
        """Resolve the system prompt for the current session/query."""
        additional_instructions: list[str] = []
        if self._skill_instructions:
            additional_instructions.append(self._skill_instructions)
        memory_instructions = build_memory_instructions()
        if memory_instructions:
            additional_instructions.append(memory_instructions)
        if hook_instructions:
            additional_instructions.extend([text for text in hook_instructions if text])
        base_system_prompt = select_base_system_prompt(
            agent_system_prompt=self._session_agent_prompt,
            custom_system_prompt=custom_system_prompt
            if custom_system_prompt is not None
            else self._custom_system_prompt,
        )
        effective_append_prompt = (
            append_system_prompt
            if append_system_prompt is not None
            else self._append_system_prompt
        )
        return compose_system_prompt(
            base_system_prompt=base_system_prompt,
            append_system_prompt=effective_append_prompt,
            default_prompt_factory=lambda: build_system_prompt(
                tools,
                prompt,
                {},
                additional_instructions=additional_instructions or None,
                mcp_instructions=mcp_instructions,
                output_style=self._output_style,
                output_language=self._output_language,
                project_path=self._project_path,
            ),
        )

    def _build_sdk_hook_scope(self, hooks: Any) -> HooksConfig:
        """Convert SDK hook config into a HooksConfig scope."""
        if not hooks or not isinstance(hooks, dict):
            return HooksConfig()
        parsed: dict[str, list[HookMatcher]] = {}
        for event_name, matchers in hooks.items():
            if not isinstance(matchers, list):
                continue
            parsed_matchers: list[HookMatcher] = []
            for matcher in matchers:
                if not isinstance(matcher, dict):
                    continue
                callback_ids = (
                    matcher.get("hookCallbackIds")
                    or matcher.get("hook_callback_ids")
                    or []
                )
                if not isinstance(callback_ids, list) or not callback_ids:
                    continue
                timeout = matcher.get("timeout", DEFAULT_HOOK_TIMEOUT)
                hook_defs: list[HookDefinition] = []
                for callback_id in callback_ids:
                    if not isinstance(callback_id, str) or not callback_id:
                        continue
                    hook_defs.append(
                        HookDefinition(
                            type="callback",
                            callback_id=callback_id,
                            timeout=timeout,
                        )
                    )
                if hook_defs:
                    parsed_matchers.append(
                        HookMatcher(matcher=matcher.get("matcher"), hooks=hook_defs)
                    )
            if parsed_matchers:
                parsed[event_name] = parsed_matchers
        return HooksConfig(hooks=parsed)

    def _configure_sdk_hooks(self, hooks: Any) -> None:
        """Register SDK-provided hooks for this session."""
        self._hooks = hooks or {}
        self._sdk_hook_scope = self._build_sdk_hook_scope(self._hooks)
        if self._query_context:
            self._query_context.add_hook_scope("sdk_hooks", self._sdk_hook_scope)
        if self._sdk_hook_scope and self._sdk_hook_scope.hooks:
            hook_manager.set_hook_callback(self._run_sdk_hook_callback)
        else:
            hook_manager.set_hook_callback(None)

    async def _run_sdk_hook_callback(
        self,
        callback_id: str,
        input_data: dict[str, Any],
        tool_use_id: str | None,
        timeout: float | None,
    ) -> HookOutput:
        """Invoke an SDK hook callback via control protocol."""
        safe_input = self._sanitize_for_json(input_data)
        try:
            response = await self._send_control_request(
                {
                    "name": "ripperdoc.hook_callback",
                    "arguments": {
                        "callback_id": callback_id,
                        "input": safe_input,
                        "tool_use_id": tool_use_id,
                        "timeout": timeout,
                    },
                },
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("[stdio] SDK hook callback timed out")
            return HookOutput.from_raw("", "", 1, timed_out=True)
        except Exception as exc:
            logger.error("[stdio] SDK hook callback failed: %s", exc)
            return HookOutput(error=str(exc), exit_code=1)

        if response is None:
            return HookOutput()
        if isinstance(response, dict):
            return HookOutput.from_raw(json.dumps(response), "", 0)
        return HookOutput()
