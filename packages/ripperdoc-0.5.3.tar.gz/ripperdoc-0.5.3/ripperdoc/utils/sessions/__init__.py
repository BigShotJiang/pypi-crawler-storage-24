"""Session-related utility modules."""

