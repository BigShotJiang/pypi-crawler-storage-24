"""Messaging-related utility modules."""

