"""Shell-related utility modules."""

