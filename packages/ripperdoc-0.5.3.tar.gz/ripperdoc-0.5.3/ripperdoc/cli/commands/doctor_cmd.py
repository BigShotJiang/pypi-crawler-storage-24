"""Slash command to diagnose common setup issues."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Callable, List, Optional, Tuple, cast

from rich.markup import escape
from rich.panel import Panel
from rich.table import Table

from ripperdoc.core.config import (
    ProtocolType,
    get_effective_config,
    get_project_config,
    get_ripperdoc_env_status,
    get_ripperdoc_storage_env_status,
    has_ripperdoc_env_overrides,
    has_ripperdoc_storage_env_overrides,
)
from ripperdoc.core.oauth import get_oauth_token
from ripperdoc.cli.ui.helpers import get_profile_for_pointer
from ripperdoc.utils.log import get_logger
from ripperdoc.utils.mcp import load_mcp_servers, load_mcp_servers_async
from ripperdoc.utils.self_update import get_install_metadata
from ripperdoc.utils.shell.sandbox_utils import is_sandbox_available

from .base import SlashCommand

logger = get_logger()


def _status_row(label: str, status: str, detail: str = "") -> Tuple[str, str, str]:
    """Build a (label, status, detail) tuple with icon."""
    icons = {
        "ok": "[green]✓[/green]",
        "warn": "[yellow]![/yellow]",
        "error": "[red]×[/red]",
    }
    icon = icons.get(status, "[yellow]?[/yellow]")
    return (label, icon, detail)


def _api_key_status(profile: Any) -> Tuple[str, str]:
    """Check API key presence and source."""
    protocol = cast(ProtocolType, getattr(profile, "protocol", ProtocolType.OPENAI_COMPATIBLE))
    if protocol == ProtocolType.OAUTH:
        token_name = str(getattr(profile, "oauth_token_name", "") or "")
        if token_name and get_oauth_token(token_name):
            return ("ok", f"OAuth token '{token_name}' is configured")
        if token_name:
            return ("error", f"OAuth token '{token_name}' is missing; configure it with /oauth")
        return ("error", "OAuth token missing; configure it with /oauth add <name>")

    # First check global RIPPERDOC_API_KEY
    if ripperdoc_api_key := os.getenv("RIPPERDOC_API_KEY"):
        masked = ripperdoc_api_key[:4] + "…" if len(ripperdoc_api_key) > 4 else "set"
        return ("ok", f"Found in $RIPPERDOC_API_KEY ({masked})")

    profile_key = cast(Optional[str], getattr(profile, "api_key", None))
    if profile_key:
        return ("ok", "Stored in config profile")

    return ("error", "Missing API key for active provider; set $RIPPERDOC_API_KEY or edit config")


def _model_status(project_path: Path) -> List[Tuple[str, str, str]]:
    config = get_effective_config(project_path)
    pointer = getattr(config.model_pointers, "main", "default")
    profile = get_profile_for_pointer("main")
    rows: List[Tuple[str, str, str]] = []

    if not profile:
        rows.append(
            _status_row("Model profile", "error", "No profile configured for pointer 'main'")
        )
        return rows

    if pointer not in config.model_profiles:
        rows.append(
            _status_row(
                "Model pointer",
                "warn",
                f"Pointer 'main' targets '{pointer}' which is missing; using fallback.",
            )
        )
    rows.append(
        _status_row(
            "Model",
            "ok",
            f"{profile.model} ({profile.protocol.value})",
        )
    )

    key_status, key_detail = _api_key_status(profile)
    rows.append(_status_row("API key", key_status, key_detail))
    return rows


def _onboarding_status() -> Tuple[str, str, str]:
    config = get_effective_config(Path.cwd())
    if config.has_completed_onboarding:
        return _status_row(
            "Onboarding",
            "ok",
            f"Completed (version {str(config.last_onboarding_version or 'unknown')})",
        )
    return _status_row(
        "Onboarding",
        "warn",
        "Not completed; run the CLI without flags to configure provider/model.",
    )


def _sandbox_status() -> Tuple[str, str, str]:
    available = is_sandbox_available()
    if available:
        return _status_row("Sandbox", "ok", "'srt' runtime is available")
    return _status_row("Sandbox", "warn", "Sandbox runtime not detected; commands run normally")


def _installation_status() -> Tuple[str, str, str]:
    metadata = get_install_metadata()
    status = "ok" if metadata.method in ("pip", "binary") else "warn"
    return (
        "Installation",
        status,
        f"{metadata.method_label} @ {metadata.location}",
    )


def _mcp_status(
    project_path: Path, runner: Optional[Callable[[Any], Any]] = None
) -> Tuple[List[Tuple[str, str, str]], List[str]]:
    """Return MCP status rows and errors."""
    rows: List[Tuple[str, str, str]] = []
    errors: List[str] = []

    async def _load() -> List[Any]:
        return await load_mcp_servers_async(project_path)

    try:
        if runner is None:
            servers = load_mcp_servers(project_path)
        else:
            servers = runner(_load())
    except (
        OSError,
        RuntimeError,
        ConnectionError,
        ValueError,
        TypeError,
    ) as exc:  # pragma: no cover - defensive
        logger.warning(
            "[doctor] Failed to load MCP servers: %s: %s",
            type(exc).__name__,
            exc,
            exc_info=exc,
        )
        rows.append(_status_row("MCP", "error", f"Failed to load MCP config: {exc}"))
        return rows, errors

    if not servers:
        rows.append(_status_row("MCP", "warn", "No MCP servers configured (.mcp.json)"))
        return rows, errors

    failing = [s for s in servers if getattr(s, "error", None)]
    rows.append(
        _status_row(
            "MCP",
            "ok" if not failing else "warn",
            f"{len(servers)} configured; {len(failing)} with errors",
        )
    )
    for server in failing[:5]:
        errors.append(f"{server.name}: {server.error}")
    if len(failing) > 5:
        errors.append(f"... {len(failing) - 5} more")
    return rows, errors


def _project_status(project_path: Path) -> Tuple[str, str, str]:
    try:
        config = get_project_config(project_path)
        # Access a field to ensure model parsing does not throw.
        _ = len(config.allowed_tools)
        return _status_row(
            "Project config", "ok", f".ripperdoc/config.json loaded for {project_path}"
        )
    except (
        OSError,
        IOError,
        json.JSONDecodeError,
        ValueError,
        TypeError,
    ) as exc:  # pragma: no cover - defensive
        logger.warning(
            "[doctor] Failed to load project config: %s: %s",
            type(exc).__name__,
            exc,
            exc_info=exc,
        )
        return _status_row(
            "Project config", "warn", f"Could not read .ripperdoc/config.json: {exc}"
        )


def _ripperdoc_env_status() -> List[Tuple[str, str, str]]:
    """Check RIPPERDOC_* environment variable overrides."""
    rows: List[Tuple[str, str, str]] = []
    model_env_override = has_ripperdoc_env_overrides()
    storage_env_override = has_ripperdoc_storage_env_overrides()

    if not model_env_override and not storage_env_override:
        rows.append(_status_row("Env overrides", "ok", "No RIPPERDOC_* overrides active"))
        return rows

    rows.append(_status_row("Env overrides", "ok", "RIPPERDOC_* variables detected"))

    status = get_ripperdoc_env_status()
    status.update(get_ripperdoc_storage_env_status())
    for key, value in status.items():
        rows.append(_status_row("", "ok", f"  {key}: {value}"))

    return rows


def _render_table(console: Any, rows: List[Tuple[str, str, str]]) -> None:
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Check")
    table.add_column("")
    table.add_column("Details")
    for label, status, detail in rows:
        table.add_row(label, status, escape(detail) if detail else "")
    console.print(table)


def _handle(ui: Any, _: str) -> bool:
    project_path = getattr(ui, "project_path", Path.cwd())
    results: List[Tuple[str, str, str]] = []

    results.append(_onboarding_status())
    results.append(_installation_status())
    results.extend(_model_status(project_path))

    # Check RIPPERDOC_* environment variables
    results.extend(_ripperdoc_env_status())

    project_row = _project_status(project_path)
    results.append(project_row)

    runner = getattr(ui, "run_async", None)
    mcp_rows, mcp_errors = _mcp_status(project_path, runner=runner)
    results.extend(mcp_rows)
    results.append(_sandbox_status())

    ui.console.print(Panel("Environment diagnostics", title="/doctor", border_style="cyan"))
    _render_table(ui.console, results)

    if mcp_errors:
        ui.console.print("\n[bold]MCP issues:[/bold]")
        for err in mcp_errors:
            ui.console.print(f"  • {escape(err)}")

    ui.console.print(
        "\n[dim]If a check is failing, run `ripperdoc` without flags "
        "to rerun onboarding or update ~/.ripperdoc/config.json[/dim]"
    )
    return True


command = SlashCommand(
    name="doctor",
    description="Diagnose model config, API keys, MCP, and sandbox support",
    handler=_handle,
)


__all__ = ["command"]
