from typing import Any
import os
from pathlib import Path
from typing import List, Optional, Tuple
from rich.markup import escape

from ripperdoc import __version__
from ripperdoc.cli.ui.helpers import get_profile_for_pointer
from ripperdoc.core.config import (
    ModelProfile,
    ProtocolType,
    get_effective_config,
    get_global_config_path,
)
from ripperdoc.core.managed_settings import has_managed_settings
from ripperdoc.core.oauth import get_oauth_token
from ripperdoc.utils.filesystem.config_paths import config_file_for_scope
from ripperdoc.utils.memory import MAX_CONTENT_LENGTH, MemoryFile, collect_all_memory_files

from .base import SlashCommand


def _auth_token_display(profile: Optional[ModelProfile]) -> Tuple[str, Optional[str]]:
    """Return a safe auth token summary and the env var used, if any."""
    if not profile:
        return ("Not configured", None)

    # First check global RIPPERDOC_AUTH_TOKEN
    if os.getenv("RIPPERDOC_AUTH_TOKEN"):
        return ("RIPPERDOC_AUTH_TOKEN (env)", "RIPPERDOC_AUTH_TOKEN")
    if os.getenv("RIPPERDOC_API_KEY"):
        return ("RIPPERDOC_API_KEY (env)", "RIPPERDOC_API_KEY")

    if profile.protocol == ProtocolType.OAUTH:
        token_name = getattr(profile, "oauth_token_name", None) or ""
        if token_name and get_oauth_token(token_name):
            return (f"OAuth token '{token_name}' (config)", None)
        if token_name:
            return (f"OAuth token '{token_name}' (missing)", None)
        return ("OAuth token missing", None)

    if profile.api_key or getattr(profile, "auth_token", None):
        return ("Configured in profile", None)
    return ("Missing", None)


def _api_base_display(profile: Optional[ModelProfile]) -> str:
    """Return a human-readable API base URL line."""
    if not profile:
        return "API base URL: Not configured"

    # First check global RIPPERDOC_BASE_URL
    if base_url := os.getenv("RIPPERDOC_BASE_URL"):
        return f"API base URL: {base_url} (RIPPERDOC_BASE_URL env)"

    label_map = {
        ProtocolType.ANTHROPIC: "Anthropic base URL",
        ProtocolType.OPENAI_COMPATIBLE: "OpenAI-compatible base URL",
        ProtocolType.GEMINI: "Gemini base URL",
        ProtocolType.OAUTH: "OAuth provider endpoint",
    }
    label = label_map.get(profile.protocol, "API base URL")
    if profile.protocol == ProtocolType.OAUTH:
        return f"{label}: managed automatically"
    base_url = profile.api_base

    return f"{label}: {base_url or 'default'}"


def _memory_status_lines(memory_files: List[MemoryFile]) -> List[str]:
    """Summarize AGENTS memory files and any issues."""
    if not memory_files:
        return ["None detected"]

    lines = [f"{len(memory_files)} file(s) loaded"]
    oversized = [memory for memory in memory_files if len(memory.content) > MAX_CONTENT_LENGTH]
    for memory in oversized:
        lines.append(f"! {memory.path} ({len(memory.content)} chars > {MAX_CONTENT_LENGTH})")
    return lines


def _setting_sources_summary(
    config: Any,
    profile: Optional[ModelProfile],
    memory_files: List[MemoryFile],
    auth_env_var: Optional[str],
    yolo_mode: bool,
    verbose: bool,
    project_path: Path,
) -> str:
    """Describe where settings for this session were sourced from."""
    sources: list[str] = []
    if get_global_config_path().exists():
        sources.append("User settings")

    project_config_path = config_file_for_scope(
        "project",
        "config.json",
        project_path=project_path,
    )
    if project_config_path.exists():
        sources.append("Project settings")
    local_config_path = config_file_for_scope(
        "local",
        "config.local.json",
        project_path=project_path,
    )
    if local_config_path.exists():
        sources.append("Local settings")
    if has_managed_settings():
        sources.append("Managed settings")

    if any(memory.type == "Local" for memory in memory_files):
        sources.append("Local memory")
    if any(memory.type == "Project" for memory in memory_files):
        sources.append("Project memory")
    if auth_env_var:
        sources.append("Environment variables")

    config_yolo_mode = getattr(config, "yolo_mode", False)
    config_verbose = getattr(config, "verbose", False)
    if yolo_mode != config_yolo_mode or verbose != config_verbose:
        sources.append("Command line arguments")

    if profile and profile.api_key and not auth_env_var:
        sources.append("Profile configuration")

    if not sources:
        sources.append("Defaults")

    unique_sources = list(dict.fromkeys(sources))
    return ", ".join(unique_sources)


def _handle(ui: Any, _: str) -> bool:
    config = get_effective_config(ui.project_path)
    profile = get_profile_for_pointer("main")
    memory_files = collect_all_memory_files()

    auth_summary, auth_env_var = _auth_token_display(profile)
    api_base_summary = _api_base_display(profile)
    memory_lines = _memory_status_lines(memory_files)
    setting_sources = _setting_sources_summary(
        config,
        profile,
        memory_files,
        auth_env_var,
        ui.yolo_mode,
        ui.verbose,
        ui.project_path,
    )

    model_label = profile.model if profile else "Not configured"

    ui.console.print()
    ui.console.rule()
    ui.console.print(" Status:\n")
    ui.console.print(f" Version: {__version__}")
    ui.console.print(f" Session ID: {ui.session_id}")
    ui.console.print(
        f" Permission mode: {escape(str(getattr(ui, 'permission_mode', 'default')))}"
    )
    ui.console.print(f" cwd: {Path.cwd()}")
    list_dirs = getattr(ui, "list_additional_working_directories", None)
    if callable(list_dirs):
        extra_dirs = list(list_dirs())
        if extra_dirs:
            ui.console.print(" additional dirs:")
            for directory in extra_dirs:
                ui.console.print(f"  - {escape(str(directory))}")
    ui.console.print(f" Auth token: {auth_summary}")
    ui.console.print(f" {api_base_summary}")
    ui.console.print()
    ui.console.print(f" Model: {model_label}")
    ui.console.print(f" Output style: {escape(str(getattr(ui, 'output_style', 'default')))}")
    ui.console.print(f" Output language: {escape(str(getattr(ui, 'output_language', 'auto')))}")
    ui.console.print(" Memory:")
    for line in memory_lines:
        ui.console.print(f"  {line}")
    ui.console.print(f" Setting sources: {setting_sources}")
    return True


command = SlashCommand(
    name="status",
    description="Show session status",
    handler=_handle,
)


__all__ = ["command"]
