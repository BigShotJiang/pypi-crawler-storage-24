# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VehicleLicenseResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'type': 'str',
        'number': 'str',
        'vehicle_type': 'str',
        'name': 'str',
        'address': 'str',
        'use_character': 'str',
        'model': 'str',
        'engine_no': 'str',
        'vin': 'str',
        'register_date': 'str',
        'issue_date': 'str',
        'issuing_authority': 'str',
        'file_no': 'str',
        'approved_passengers': 'str',
        'gross_mass': 'str',
        'unladen_mass': 'str',
        'approved_load': 'str',
        'dimension': 'str',
        'traction_mass': 'str',
        'remarks': 'str',
        'inspection_record': 'str',
        'code_number': 'str',
        'text_location': 'object',
        'energy_type': 'str',
        'color': 'str',
        'mandatory_scrapping_date': 'str',
        'status': 'list[str]',
        'front': 'VehicleLicenseFront',
        'back': 'VehicleLicenseBack',
        'alarm_result': 'VehicleLicenseAlarmResult',
        'alarm_confidence': 'VehicleLicenseAlarmConfidence'
    }

    attribute_map = {
        'type': 'type',
        'number': 'number',
        'vehicle_type': 'vehicle_type',
        'name': 'name',
        'address': 'address',
        'use_character': 'use_character',
        'model': 'model',
        'engine_no': 'engine_no',
        'vin': 'vin',
        'register_date': 'register_date',
        'issue_date': 'issue_date',
        'issuing_authority': 'issuing_authority',
        'file_no': 'file_no',
        'approved_passengers': 'approved_passengers',
        'gross_mass': 'gross_mass',
        'unladen_mass': 'unladen_mass',
        'approved_load': 'approved_load',
        'dimension': 'dimension',
        'traction_mass': 'traction_mass',
        'remarks': 'remarks',
        'inspection_record': 'inspection_record',
        'code_number': 'code_number',
        'text_location': 'text_location',
        'energy_type': 'energy_type',
        'color': 'color',
        'mandatory_scrapping_date': 'mandatory_scrapping_date',
        'status': 'status',
        'front': 'front',
        'back': 'back',
        'alarm_result': 'alarm_result',
        'alarm_confidence': 'alarm_confidence'
    }

    def __init__(self, type=None, number=None, vehicle_type=None, name=None, address=None, use_character=None, model=None, engine_no=None, vin=None, register_date=None, issue_date=None, issuing_authority=None, file_no=None, approved_passengers=None, gross_mass=None, unladen_mass=None, approved_load=None, dimension=None, traction_mass=None, remarks=None, inspection_record=None, code_number=None, text_location=None, energy_type=None, color=None, mandatory_scrapping_date=None, status=None, front=None, back=None, alarm_result=None, alarm_confidence=None):
        r"""VehicleLicenseResult

        The model defined in huaweicloud sdk

        :param type: 行驶证类型：  - normal: 纸质行驶证  - electronic: 电子行驶证 
        :type type: str
        :param number: 号牌号码。 
        :type number: str
        :param vehicle_type: 车辆类型。 
        :type vehicle_type: str
        :param name: 所有人。 
        :type name: str
        :param address: 住址。 
        :type address: str
        :param use_character: 使用性质。 
        :type use_character: str
        :param model: 品牌型号。 
        :type model: str
        :param engine_no: 发动机号码。 
        :type engine_no: str
        :param vin: 车辆识别代号。 
        :type vin: str
        :param register_date: 注册日期。 
        :type register_date: str
        :param issue_date: 发证日期。 
        :type issue_date: str
        :param issuing_authority: 发证机关。 
        :type issuing_authority: str
        :param file_no: 档案编码。 
        :type file_no: str
        :param approved_passengers: 核定载人数。 
        :type approved_passengers: str
        :param gross_mass: 总质量。 
        :type gross_mass: str
        :param unladen_mass: 整备质量。 
        :type unladen_mass: str
        :param approved_load: 核定载质量。 
        :type approved_load: str
        :param dimension: 外廓尺寸。 
        :type dimension: str
        :param traction_mass: 准牵引总质量。 
        :type traction_mass: str
        :param remarks: 备注。 
        :type remarks: str
        :param inspection_record: 检验记录。 
        :type inspection_record: str
        :param code_number: 条码号。 
        :type code_number: str
        :param text_location: 文本框在原图位置。输出左上、右上、右下、左下四个点坐标。  当“return_text_location”设置为“true”时才返回。 
        :type text_location: object
        :param energy_type: 能源类型。 
        :type energy_type: str
        :param color: 车身颜色。 
        :type color: str
        :param mandatory_scrapping_date: 强制报废日期。 
        :type mandatory_scrapping_date: str
        :param status: 状态。 
        :type status: list[str]
        :param front: 
        :type front: :class:`huaweicloudsdkocr.v1.VehicleLicenseFront`
        :param back: 
        :type back: :class:`huaweicloudsdkocr.v1.VehicleLicenseBack`
        :param alarm_result: 
        :type alarm_result: :class:`huaweicloudsdkocr.v1.VehicleLicenseAlarmResult`
        :param alarm_confidence: 
        :type alarm_confidence: :class:`huaweicloudsdkocr.v1.VehicleLicenseAlarmConfidence`
        """
        
        

        self._type = None
        self._number = None
        self._vehicle_type = None
        self._name = None
        self._address = None
        self._use_character = None
        self._model = None
        self._engine_no = None
        self._vin = None
        self._register_date = None
        self._issue_date = None
        self._issuing_authority = None
        self._file_no = None
        self._approved_passengers = None
        self._gross_mass = None
        self._unladen_mass = None
        self._approved_load = None
        self._dimension = None
        self._traction_mass = None
        self._remarks = None
        self._inspection_record = None
        self._code_number = None
        self._text_location = None
        self._energy_type = None
        self._color = None
        self._mandatory_scrapping_date = None
        self._status = None
        self._front = None
        self._back = None
        self._alarm_result = None
        self._alarm_confidence = None
        self.discriminator = None

        if type is not None:
            self.type = type
        if number is not None:
            self.number = number
        if vehicle_type is not None:
            self.vehicle_type = vehicle_type
        if name is not None:
            self.name = name
        if address is not None:
            self.address = address
        if use_character is not None:
            self.use_character = use_character
        if model is not None:
            self.model = model
        if engine_no is not None:
            self.engine_no = engine_no
        if vin is not None:
            self.vin = vin
        if register_date is not None:
            self.register_date = register_date
        if issue_date is not None:
            self.issue_date = issue_date
        if issuing_authority is not None:
            self.issuing_authority = issuing_authority
        if file_no is not None:
            self.file_no = file_no
        if approved_passengers is not None:
            self.approved_passengers = approved_passengers
        if gross_mass is not None:
            self.gross_mass = gross_mass
        if unladen_mass is not None:
            self.unladen_mass = unladen_mass
        if approved_load is not None:
            self.approved_load = approved_load
        if dimension is not None:
            self.dimension = dimension
        if traction_mass is not None:
            self.traction_mass = traction_mass
        if remarks is not None:
            self.remarks = remarks
        if inspection_record is not None:
            self.inspection_record = inspection_record
        if code_number is not None:
            self.code_number = code_number
        if text_location is not None:
            self.text_location = text_location
        if energy_type is not None:
            self.energy_type = energy_type
        if color is not None:
            self.color = color
        if mandatory_scrapping_date is not None:
            self.mandatory_scrapping_date = mandatory_scrapping_date
        if status is not None:
            self.status = status
        if front is not None:
            self.front = front
        if back is not None:
            self.back = back
        if alarm_result is not None:
            self.alarm_result = alarm_result
        if alarm_confidence is not None:
            self.alarm_confidence = alarm_confidence

    @property
    def type(self):
        r"""Gets the type of this VehicleLicenseResult.

        行驶证类型：  - normal: 纸质行驶证  - electronic: 电子行驶证 

        :return: The type of this VehicleLicenseResult.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this VehicleLicenseResult.

        行驶证类型：  - normal: 纸质行驶证  - electronic: 电子行驶证 

        :param type: The type of this VehicleLicenseResult.
        :type type: str
        """
        self._type = type

    @property
    def number(self):
        r"""Gets the number of this VehicleLicenseResult.

        号牌号码。 

        :return: The number of this VehicleLicenseResult.
        :rtype: str
        """
        return self._number

    @number.setter
    def number(self, number):
        r"""Sets the number of this VehicleLicenseResult.

        号牌号码。 

        :param number: The number of this VehicleLicenseResult.
        :type number: str
        """
        self._number = number

    @property
    def vehicle_type(self):
        r"""Gets the vehicle_type of this VehicleLicenseResult.

        车辆类型。 

        :return: The vehicle_type of this VehicleLicenseResult.
        :rtype: str
        """
        return self._vehicle_type

    @vehicle_type.setter
    def vehicle_type(self, vehicle_type):
        r"""Sets the vehicle_type of this VehicleLicenseResult.

        车辆类型。 

        :param vehicle_type: The vehicle_type of this VehicleLicenseResult.
        :type vehicle_type: str
        """
        self._vehicle_type = vehicle_type

    @property
    def name(self):
        r"""Gets the name of this VehicleLicenseResult.

        所有人。 

        :return: The name of this VehicleLicenseResult.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this VehicleLicenseResult.

        所有人。 

        :param name: The name of this VehicleLicenseResult.
        :type name: str
        """
        self._name = name

    @property
    def address(self):
        r"""Gets the address of this VehicleLicenseResult.

        住址。 

        :return: The address of this VehicleLicenseResult.
        :rtype: str
        """
        return self._address

    @address.setter
    def address(self, address):
        r"""Sets the address of this VehicleLicenseResult.

        住址。 

        :param address: The address of this VehicleLicenseResult.
        :type address: str
        """
        self._address = address

    @property
    def use_character(self):
        r"""Gets the use_character of this VehicleLicenseResult.

        使用性质。 

        :return: The use_character of this VehicleLicenseResult.
        :rtype: str
        """
        return self._use_character

    @use_character.setter
    def use_character(self, use_character):
        r"""Sets the use_character of this VehicleLicenseResult.

        使用性质。 

        :param use_character: The use_character of this VehicleLicenseResult.
        :type use_character: str
        """
        self._use_character = use_character

    @property
    def model(self):
        r"""Gets the model of this VehicleLicenseResult.

        品牌型号。 

        :return: The model of this VehicleLicenseResult.
        :rtype: str
        """
        return self._model

    @model.setter
    def model(self, model):
        r"""Sets the model of this VehicleLicenseResult.

        品牌型号。 

        :param model: The model of this VehicleLicenseResult.
        :type model: str
        """
        self._model = model

    @property
    def engine_no(self):
        r"""Gets the engine_no of this VehicleLicenseResult.

        发动机号码。 

        :return: The engine_no of this VehicleLicenseResult.
        :rtype: str
        """
        return self._engine_no

    @engine_no.setter
    def engine_no(self, engine_no):
        r"""Sets the engine_no of this VehicleLicenseResult.

        发动机号码。 

        :param engine_no: The engine_no of this VehicleLicenseResult.
        :type engine_no: str
        """
        self._engine_no = engine_no

    @property
    def vin(self):
        r"""Gets the vin of this VehicleLicenseResult.

        车辆识别代号。 

        :return: The vin of this VehicleLicenseResult.
        :rtype: str
        """
        return self._vin

    @vin.setter
    def vin(self, vin):
        r"""Sets the vin of this VehicleLicenseResult.

        车辆识别代号。 

        :param vin: The vin of this VehicleLicenseResult.
        :type vin: str
        """
        self._vin = vin

    @property
    def register_date(self):
        r"""Gets the register_date of this VehicleLicenseResult.

        注册日期。 

        :return: The register_date of this VehicleLicenseResult.
        :rtype: str
        """
        return self._register_date

    @register_date.setter
    def register_date(self, register_date):
        r"""Sets the register_date of this VehicleLicenseResult.

        注册日期。 

        :param register_date: The register_date of this VehicleLicenseResult.
        :type register_date: str
        """
        self._register_date = register_date

    @property
    def issue_date(self):
        r"""Gets the issue_date of this VehicleLicenseResult.

        发证日期。 

        :return: The issue_date of this VehicleLicenseResult.
        :rtype: str
        """
        return self._issue_date

    @issue_date.setter
    def issue_date(self, issue_date):
        r"""Sets the issue_date of this VehicleLicenseResult.

        发证日期。 

        :param issue_date: The issue_date of this VehicleLicenseResult.
        :type issue_date: str
        """
        self._issue_date = issue_date

    @property
    def issuing_authority(self):
        r"""Gets the issuing_authority of this VehicleLicenseResult.

        发证机关。 

        :return: The issuing_authority of this VehicleLicenseResult.
        :rtype: str
        """
        return self._issuing_authority

    @issuing_authority.setter
    def issuing_authority(self, issuing_authority):
        r"""Sets the issuing_authority of this VehicleLicenseResult.

        发证机关。 

        :param issuing_authority: The issuing_authority of this VehicleLicenseResult.
        :type issuing_authority: str
        """
        self._issuing_authority = issuing_authority

    @property
    def file_no(self):
        r"""Gets the file_no of this VehicleLicenseResult.

        档案编码。 

        :return: The file_no of this VehicleLicenseResult.
        :rtype: str
        """
        return self._file_no

    @file_no.setter
    def file_no(self, file_no):
        r"""Sets the file_no of this VehicleLicenseResult.

        档案编码。 

        :param file_no: The file_no of this VehicleLicenseResult.
        :type file_no: str
        """
        self._file_no = file_no

    @property
    def approved_passengers(self):
        r"""Gets the approved_passengers of this VehicleLicenseResult.

        核定载人数。 

        :return: The approved_passengers of this VehicleLicenseResult.
        :rtype: str
        """
        return self._approved_passengers

    @approved_passengers.setter
    def approved_passengers(self, approved_passengers):
        r"""Sets the approved_passengers of this VehicleLicenseResult.

        核定载人数。 

        :param approved_passengers: The approved_passengers of this VehicleLicenseResult.
        :type approved_passengers: str
        """
        self._approved_passengers = approved_passengers

    @property
    def gross_mass(self):
        r"""Gets the gross_mass of this VehicleLicenseResult.

        总质量。 

        :return: The gross_mass of this VehicleLicenseResult.
        :rtype: str
        """
        return self._gross_mass

    @gross_mass.setter
    def gross_mass(self, gross_mass):
        r"""Sets the gross_mass of this VehicleLicenseResult.

        总质量。 

        :param gross_mass: The gross_mass of this VehicleLicenseResult.
        :type gross_mass: str
        """
        self._gross_mass = gross_mass

    @property
    def unladen_mass(self):
        r"""Gets the unladen_mass of this VehicleLicenseResult.

        整备质量。 

        :return: The unladen_mass of this VehicleLicenseResult.
        :rtype: str
        """
        return self._unladen_mass

    @unladen_mass.setter
    def unladen_mass(self, unladen_mass):
        r"""Sets the unladen_mass of this VehicleLicenseResult.

        整备质量。 

        :param unladen_mass: The unladen_mass of this VehicleLicenseResult.
        :type unladen_mass: str
        """
        self._unladen_mass = unladen_mass

    @property
    def approved_load(self):
        r"""Gets the approved_load of this VehicleLicenseResult.

        核定载质量。 

        :return: The approved_load of this VehicleLicenseResult.
        :rtype: str
        """
        return self._approved_load

    @approved_load.setter
    def approved_load(self, approved_load):
        r"""Sets the approved_load of this VehicleLicenseResult.

        核定载质量。 

        :param approved_load: The approved_load of this VehicleLicenseResult.
        :type approved_load: str
        """
        self._approved_load = approved_load

    @property
    def dimension(self):
        r"""Gets the dimension of this VehicleLicenseResult.

        外廓尺寸。 

        :return: The dimension of this VehicleLicenseResult.
        :rtype: str
        """
        return self._dimension

    @dimension.setter
    def dimension(self, dimension):
        r"""Sets the dimension of this VehicleLicenseResult.

        外廓尺寸。 

        :param dimension: The dimension of this VehicleLicenseResult.
        :type dimension: str
        """
        self._dimension = dimension

    @property
    def traction_mass(self):
        r"""Gets the traction_mass of this VehicleLicenseResult.

        准牵引总质量。 

        :return: The traction_mass of this VehicleLicenseResult.
        :rtype: str
        """
        return self._traction_mass

    @traction_mass.setter
    def traction_mass(self, traction_mass):
        r"""Sets the traction_mass of this VehicleLicenseResult.

        准牵引总质量。 

        :param traction_mass: The traction_mass of this VehicleLicenseResult.
        :type traction_mass: str
        """
        self._traction_mass = traction_mass

    @property
    def remarks(self):
        r"""Gets the remarks of this VehicleLicenseResult.

        备注。 

        :return: The remarks of this VehicleLicenseResult.
        :rtype: str
        """
        return self._remarks

    @remarks.setter
    def remarks(self, remarks):
        r"""Sets the remarks of this VehicleLicenseResult.

        备注。 

        :param remarks: The remarks of this VehicleLicenseResult.
        :type remarks: str
        """
        self._remarks = remarks

    @property
    def inspection_record(self):
        r"""Gets the inspection_record of this VehicleLicenseResult.

        检验记录。 

        :return: The inspection_record of this VehicleLicenseResult.
        :rtype: str
        """
        return self._inspection_record

    @inspection_record.setter
    def inspection_record(self, inspection_record):
        r"""Sets the inspection_record of this VehicleLicenseResult.

        检验记录。 

        :param inspection_record: The inspection_record of this VehicleLicenseResult.
        :type inspection_record: str
        """
        self._inspection_record = inspection_record

    @property
    def code_number(self):
        r"""Gets the code_number of this VehicleLicenseResult.

        条码号。 

        :return: The code_number of this VehicleLicenseResult.
        :rtype: str
        """
        return self._code_number

    @code_number.setter
    def code_number(self, code_number):
        r"""Sets the code_number of this VehicleLicenseResult.

        条码号。 

        :param code_number: The code_number of this VehicleLicenseResult.
        :type code_number: str
        """
        self._code_number = code_number

    @property
    def text_location(self):
        r"""Gets the text_location of this VehicleLicenseResult.

        文本框在原图位置。输出左上、右上、右下、左下四个点坐标。  当“return_text_location”设置为“true”时才返回。 

        :return: The text_location of this VehicleLicenseResult.
        :rtype: object
        """
        return self._text_location

    @text_location.setter
    def text_location(self, text_location):
        r"""Sets the text_location of this VehicleLicenseResult.

        文本框在原图位置。输出左上、右上、右下、左下四个点坐标。  当“return_text_location”设置为“true”时才返回。 

        :param text_location: The text_location of this VehicleLicenseResult.
        :type text_location: object
        """
        self._text_location = text_location

    @property
    def energy_type(self):
        r"""Gets the energy_type of this VehicleLicenseResult.

        能源类型。 

        :return: The energy_type of this VehicleLicenseResult.
        :rtype: str
        """
        return self._energy_type

    @energy_type.setter
    def energy_type(self, energy_type):
        r"""Sets the energy_type of this VehicleLicenseResult.

        能源类型。 

        :param energy_type: The energy_type of this VehicleLicenseResult.
        :type energy_type: str
        """
        self._energy_type = energy_type

    @property
    def color(self):
        r"""Gets the color of this VehicleLicenseResult.

        车身颜色。 

        :return: The color of this VehicleLicenseResult.
        :rtype: str
        """
        return self._color

    @color.setter
    def color(self, color):
        r"""Sets the color of this VehicleLicenseResult.

        车身颜色。 

        :param color: The color of this VehicleLicenseResult.
        :type color: str
        """
        self._color = color

    @property
    def mandatory_scrapping_date(self):
        r"""Gets the mandatory_scrapping_date of this VehicleLicenseResult.

        强制报废日期。 

        :return: The mandatory_scrapping_date of this VehicleLicenseResult.
        :rtype: str
        """
        return self._mandatory_scrapping_date

    @mandatory_scrapping_date.setter
    def mandatory_scrapping_date(self, mandatory_scrapping_date):
        r"""Sets the mandatory_scrapping_date of this VehicleLicenseResult.

        强制报废日期。 

        :param mandatory_scrapping_date: The mandatory_scrapping_date of this VehicleLicenseResult.
        :type mandatory_scrapping_date: str
        """
        self._mandatory_scrapping_date = mandatory_scrapping_date

    @property
    def status(self):
        r"""Gets the status of this VehicleLicenseResult.

        状态。 

        :return: The status of this VehicleLicenseResult.
        :rtype: list[str]
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this VehicleLicenseResult.

        状态。 

        :param status: The status of this VehicleLicenseResult.
        :type status: list[str]
        """
        self._status = status

    @property
    def front(self):
        r"""Gets the front of this VehicleLicenseResult.

        :return: The front of this VehicleLicenseResult.
        :rtype: :class:`huaweicloudsdkocr.v1.VehicleLicenseFront`
        """
        return self._front

    @front.setter
    def front(self, front):
        r"""Sets the front of this VehicleLicenseResult.

        :param front: The front of this VehicleLicenseResult.
        :type front: :class:`huaweicloudsdkocr.v1.VehicleLicenseFront`
        """
        self._front = front

    @property
    def back(self):
        r"""Gets the back of this VehicleLicenseResult.

        :return: The back of this VehicleLicenseResult.
        :rtype: :class:`huaweicloudsdkocr.v1.VehicleLicenseBack`
        """
        return self._back

    @back.setter
    def back(self, back):
        r"""Sets the back of this VehicleLicenseResult.

        :param back: The back of this VehicleLicenseResult.
        :type back: :class:`huaweicloudsdkocr.v1.VehicleLicenseBack`
        """
        self._back = back

    @property
    def alarm_result(self):
        r"""Gets the alarm_result of this VehicleLicenseResult.

        :return: The alarm_result of this VehicleLicenseResult.
        :rtype: :class:`huaweicloudsdkocr.v1.VehicleLicenseAlarmResult`
        """
        return self._alarm_result

    @alarm_result.setter
    def alarm_result(self, alarm_result):
        r"""Sets the alarm_result of this VehicleLicenseResult.

        :param alarm_result: The alarm_result of this VehicleLicenseResult.
        :type alarm_result: :class:`huaweicloudsdkocr.v1.VehicleLicenseAlarmResult`
        """
        self._alarm_result = alarm_result

    @property
    def alarm_confidence(self):
        r"""Gets the alarm_confidence of this VehicleLicenseResult.

        :return: The alarm_confidence of this VehicleLicenseResult.
        :rtype: :class:`huaweicloudsdkocr.v1.VehicleLicenseAlarmConfidence`
        """
        return self._alarm_confidence

    @alarm_confidence.setter
    def alarm_confidence(self, alarm_confidence):
        r"""Sets the alarm_confidence of this VehicleLicenseResult.

        :param alarm_confidence: The alarm_confidence of this VehicleLicenseResult.
        :type alarm_confidence: :class:`huaweicloudsdkocr.v1.VehicleLicenseAlarmConfidence`
        """
        self._alarm_confidence = alarm_confidence

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VehicleLicenseResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
