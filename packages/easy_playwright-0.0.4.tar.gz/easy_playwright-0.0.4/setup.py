from __future__ import annotations

import os
import subprocess
import sys

from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.command.develop import develop
from setuptools.command.install import install

_BROWSER_INSTALL_DONE = False


def _get_browsers_path() -> str:
    return "/ms-playwright"


def _install_chromium() -> None:
    global _BROWSER_INSTALL_DONE
    if _BROWSER_INSTALL_DONE:
        return
    if os.environ.get("EASY_PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD") == "1":
        print("[easy_playwright] Skipping browser installation (EASY_PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1)")
        _BROWSER_INSTALL_DONE = True
        return
    browsers_path = _get_browsers_path()
    os.makedirs(browsers_path, exist_ok=True)
    env = os.environ.copy()
    env["PLAYWRIGHT_BROWSERS_PATH"] = browsers_path
    print("[easy_playwright] Installing Chromium during build/install...")
    print(f"[easy_playwright] PLAYWRIGHT_BROWSERS_PATH={browsers_path}")
    print(f"[easy_playwright] > {sys.executable} -m playwright install chromium")
    subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"], env=env)
    print(f"[easy_playwright] > {sys.executable} -m playwright install-deps chromium")
    subprocess.check_call([sys.executable, "-m", "playwright", "install-deps", "chromium"], env=env)
    _BROWSER_INSTALL_DONE = True


class BuildPyWithPlaywright(build_py):
    def run(self) -> None:
        _install_chromium()
        super().run()


class InstallWithPlaywright(install):
    def run(self) -> None:
        _install_chromium()
        super().run()


class DevelopWithPlaywright(develop):
    def run(self) -> None:
        _install_chromium()
        super().run()


setup(
    cmdclass={
        "build_py": BuildPyWithPlaywright,
        "install": InstallWithPlaywright,
        "develop": DevelopWithPlaywright,
    }
)
