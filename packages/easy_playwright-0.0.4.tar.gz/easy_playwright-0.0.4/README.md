# easy_playwright

An ultra-simple Playwright runner that executes Python snippets while reusing a persistent Chromium session across calls.

# Why ?

Traditionnal playwright MCP allow agent to call a subset of playwright functions one by one.
An alternative is to allow agent to execute arbitrary python code using playwright package to freely access full API, but it general the browser is closed after each code execution.

easy_playwright allows :
- Mandatory Chromium/deps installation during pip build/install (fails fast on error)
- Auto chromium startup and persistence
- Single tool call for agent to execute any python playwright routine
- Reusing previous session accross executions
- Easy traces and screenshots captures and storage in local folder to allow human and agent monitoring
- Auto-embedding of development workflow instructions to improve agent coding autonomy

## Installation

easy_playwright is designed to allow easy and light setup of playwright and chromium in same host (local dev machine or dev container)

> pip install -v --no-binary easy-playwright easy-playwright
(--no-binary is needed to force auto chromium installation in expected folder)

Then, add following instructions in your agent context :
```
Always use the ezpw tool to check your work. Run the following command, read the output carefully, and strictly follow the instructions provided.
> ezpw -h
```

## Persistent Chromium

The browser is started automatically if not already running. The persistent profile is stored in:

```
.playwright/runtime/chromium-profile/
```

This keeps state between calls (cookies, login session, etc.).

Tip: `playwright` reuses the first open tab if possible, otherwise it creates a new one.

## Environment variables

- `EASY_PLAYWRIGHT_DIR`: base folder (default `.playwright`).
- `EASY_PLAYWRIGHT_CDP_PORT`: CDP port (default `9222`).
- `EASY_PLAYWRIGHT_START_URL`: URL opened on startup (default `about:blank`).
- `EASY_PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD`: if `1`, do not download Chromium during `pip install`.
