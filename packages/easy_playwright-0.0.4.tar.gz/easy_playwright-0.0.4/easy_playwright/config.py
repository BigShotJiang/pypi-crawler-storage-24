from __future__ import annotations

import os
from pathlib import Path

DEFAULT_BASE_DIRNAME = ".playwright"
DEFAULT_CDP_PORT = 9222
DEFAULT_START_URL = "about:blank"
DEFAULT_HEADLESS = True
DEFAULT_WINDOW_SIZE = (1920, 1080)
DEFAULT_PLAYWRIGHT_BROWSERS_PATH = "/ms-playwright"


def get_project_dir() -> Path:
    env = os.environ.get("EASY_PLAYWRIGHT_PROJECT_DIR")
    if env:
        return Path(env).expanduser().resolve()
    return Path.cwd().resolve()


def get_base_dir(project_dir: Path) -> Path:
    env = os.environ.get("EASY_PLAYWRIGHT_DIR")
    base = Path(env).expanduser().resolve() if env else (project_dir / DEFAULT_BASE_DIRNAME)
    base.mkdir(parents=True, exist_ok=True)
    return base


def get_playwright_browsers_path() -> str:
    return DEFAULT_PLAYWRIGHT_BROWSERS_PATH


def get_runtime_dir(base_dir: Path) -> Path:
    runtime = base_dir / "runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    return runtime


def get_profile_dir(runtime_dir: Path) -> Path:
    profile = runtime_dir / "chromium-profile"
    profile.mkdir(parents=True, exist_ok=True)
    return profile


def get_export_dir(base_dir: Path) -> Path:
    exports = base_dir / "exports"
    exports.mkdir(parents=True, exist_ok=True)
    return exports


def get_log_path(runtime_dir: Path) -> Path:
    return runtime_dir / "chromium.log"
