"""Minimal Playwright runner with persistent Chromium."""

from .runner import run_snippet, ensure_chromium_running

__all__ = ["run_snippet", "ensure_chromium_running"]
__version__ = "0.4.0"
