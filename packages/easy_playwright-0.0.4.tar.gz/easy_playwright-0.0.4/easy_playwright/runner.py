from __future__ import annotations

import json
import os
import socket
from collections import deque
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.error import URLError
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

from .config import (
    DEFAULT_CDP_PORT,
    DEFAULT_HEADLESS,
    DEFAULT_START_URL,
    DEFAULT_WINDOW_SIZE,
    get_base_dir,
    get_export_dir,
    get_log_path,
    get_profile_dir,
    get_project_dir,
    get_playwright_browsers_path,
    get_runtime_dir,
)


@dataclass
class RunOptions:
    code: str
    port: Optional[int] = None
    headless: bool = DEFAULT_HEADLESS
    start_url: str = DEFAULT_START_URL
    window_size: Optional[tuple[int, int]] = DEFAULT_WINDOW_SIZE


def _fetch_cdp_version(port: int, timeout: float = 0.5) -> Optional[dict]:
    url = f"http://127.0.0.1:{port}/json/version"
    try:
        with urlopen(url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if "webSocketDebuggerUrl" in data:
            return data
        return None
    except URLError:
        return None


def _is_cdp_ready(port: int) -> bool:
    return _fetch_cdp_version(port) is not None


def _is_port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.2)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def _tail_log(path: Path, max_lines: int = 50) -> str:
    if not path.exists():
        return ""
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            lines = deque(handle, maxlen=max_lines)
        return "".join(lines)
    except Exception:
        return ""


def _wait_for_cdp(port: int, timeout: float, proc: Optional[subprocess.Popen] = None) -> None:
    start = time.time()
    while time.time() - start < timeout:
        if _is_cdp_ready(port):
            return
        if proc is not None and proc.poll() is not None:
            raise RuntimeError(f"Chromium process exited early (code {proc.returncode}).")
        time.sleep(0.25)
    raise RuntimeError(
        f"Chromium ne repond pas sur le port {port}. "
        "Verifie que le port est libre ou change-le via --port."
    )


def _apply_window_size(page, window_size: tuple[int, int]) -> None:
    width, height = window_size
    # Try to resize the real browser window (headful mode), then fall back to viewport.
    try:
        session = page.context.new_cdp_session(page)
        window_info = session.send("Browser.getWindowForTarget")
        session.send(
            "Browser.setWindowBounds",
            {
                "windowId": window_info["windowId"],
                "bounds": {"width": width, "height": height},
            },
        )
        return
    except Exception:
        pass

    try:
        page.set_viewport_size({"width": width, "height": height})
    except Exception:
        pass


def _configure_playwright_browsers_path() -> None:
    path = get_playwright_browsers_path()
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = path
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
    except Exception:
        # If path creation fails, Playwright will raise a clearer install/runtime error.
        pass


def _ensure_chromium_installed() -> Path:
    _configure_playwright_browsers_path()
    browsers_path = os.environ.get("PLAYWRIGHT_BROWSERS_PATH", "")
    with sync_playwright() as p:
        exe = Path(p.chromium.executable_path)
    if exe.exists():
        return exe

    raise RuntimeError(
        "Chromium is not installed, you have 2 choices :\n"
        "- Force chromium installation during pip install :\n" \
        "> pip install --no-binary easy-playwright easy-playwright\n"
        "- Install chromium manually :\n"
        f"> PLAYWRIGHT_BROWSERS_PATH={browsers_path} {sys.executable} -m playwright install chromium "
    )


def ensure_chromium_running(
    port: Optional[int] = None,
    headless: Optional[bool] = None,
    start_url: Optional[str] = None,
    window_size: Optional[tuple[int, int]] = None,
    base_dir: Optional[Path] = None,
) -> None:
    _configure_playwright_browsers_path()
    project_dir = get_project_dir()
    base = base_dir or get_base_dir(project_dir)
    port = port or int(os.environ.get("EASY_PLAYWRIGHT_CDP_PORT", DEFAULT_CDP_PORT))
    headless = DEFAULT_HEADLESS if headless is None else headless
    start_url = start_url or os.environ.get("EASY_PLAYWRIGHT_START_URL", DEFAULT_START_URL)

    if _is_cdp_ready(port):
        return
    if _is_port_in_use(port):
        raise RuntimeError(
            f"Le port {port} est deja utilise mais ne repond pas en CDP. "
            "Change le port ou arrete le processus qui l'utilise."
        )

    exe = _ensure_chromium_installed()
    runtime_dir = get_runtime_dir(base)
    profile_dir = get_profile_dir(runtime_dir)
    log_path = get_log_path(runtime_dir)

    args = [
        str(exe),
        f"--remote-debugging-port={port}",
        "--remote-debugging-address=127.0.0.1",
        "--remote-allow-origins=*",
        f"--user-data-dir={profile_dir}",
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-gpu",
    ]
    if headless:
        args.append("--headless")
    width, height = window_size or DEFAULT_WINDOW_SIZE
    args.append(f"--window-size={width},{height}")
    args.append(start_url)

    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = open(log_path, "a", encoding="utf-8")
    proc = subprocess.Popen(
        args,
        stdout=log_file,
        stderr=log_file,
        start_new_session=True,
    )
    log_file.close()

    timeout_env = os.environ.get("EASY_PLAYWRIGHT_CDP_TIMEOUT", "15")
    try:
        timeout = float(timeout_env)
    except ValueError:
        timeout = 15.0

    try:
        _wait_for_cdp(port, timeout=timeout, proc=proc)
    except RuntimeError as exc:
        log_tail = _tail_log(log_path)
        details = f"{exc} (see {log_path})"
        if log_tail:
            details = f"{details}\n--- chromium.log (tail) ---\n{log_tail}"
        raise RuntimeError(details) from exc


def run_snippet(options: RunOptions) -> dict:
    project_dir = get_project_dir()
    base_dir = get_base_dir(project_dir)
    export_dir = get_export_dir(base_dir)
    port = options.port or int(os.environ.get("EASY_PLAYWRIGHT_CDP_PORT", DEFAULT_CDP_PORT))

    ensure_chromium_running(
        port=port,
        headless=options.headless,
        start_url=options.start_url,
        window_size=options.window_size,
        base_dir=base_dir,
    )

    with sync_playwright() as p:
        browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
        context = browser.contexts[0] if browser.contexts else browser.new_context()
        page = context.pages[0] if context.pages else context.new_page()
        _apply_window_size(page, options.window_size or DEFAULT_WINDOW_SIZE)

        exec_error: Optional[BaseException] = None
        try:
            now_stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            scope = {
                "page": page,
                "context": context,
                "browser": browser,
                "playwright": p,
                "NOW": now_stamp,
                "EXPORT_FOLDER": export_dir,
            }
            compiled = compile(options.code, "<easy_playwright>", "exec")
            exec(compiled, scope, scope)
        except BaseException as exc:
            exec_error = exc
        finally:
            browser.close()

        if exec_error:
            raise exec_error

    return {
        "now": now_stamp,
        "export_folder": str(export_dir),
        "port": port,
    }
