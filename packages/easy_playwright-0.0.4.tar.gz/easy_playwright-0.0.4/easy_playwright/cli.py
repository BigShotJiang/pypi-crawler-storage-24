from __future__ import annotations

import argparse
import sys

from .config import DEFAULT_HEADLESS, DEFAULT_START_URL, DEFAULT_WINDOW_SIZE
from .runner import RunOptions, run_snippet


def _read_code_from_stdin() -> str:
    if sys.stdin is None or sys.stdin.isatty():
        return ""
    return sys.stdin.read()


def _parse_window_size(value: str) -> tuple[int, int]:
    try:
        width_str, height_str = value.lower().split("x", 1)
        width = int(width_str)
        height = int(height_str)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "Invalid format for --window-size. Use WIDTHxHEIGHT, for example 1920x1080."
        ) from exc

    if width <= 0 or height <= 0:
        raise argparse.ArgumentTypeError("Window size must be positive integers.")
    return (width, height)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="ezpw",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="""All-in-one tool to easily check web app behavior using playwright.
        
ezpw allows executing a playwright Python snippet within a persistent Chromium session.

Example 1 : Navigate + Screenshot
ezpw "
# NOW, EXPORT_FOLDER, playwright, page, context and browser are directly available in ezpw scope
#print(page)
#print(context)

# By default, you are on the page that was left open during the previous call, but you can change it.
# page.goto('http://127.0.0.1:8080', wait_until='networkidle')

page.fill('#name', 'Agent_IA_001')
page.click('.start-btn')
page.screenshot(path=EXPORT_FOLDER/f'screenshots/{NOW}_after_click.png', full_page=True)
"

# Example 2 : Traces capture
ezpw "
context.tracing.start(screenshots=True, snapshots=True, sources=True)
page.goto('http://127.0.0.1:8080/page_to_test', wait_until='networkidle')
context.tracing.stop(path=EXPORT_FOLDER/f'traces/{NOW}_page_to_test.zip')
"

You have access to entire playwright API.

**Iterative Test & Adjust Development Workflow**

Systematically:

- Produce the code to meet the requested requirement.  
- Use Playwright to test the application:  
  - Navigate and interact within the application to ensure everything works as expected.  
  - Capture traces and take screenshots to visually verify that the application's appearance matches the expectations.  
- Review the traces and screenshots you have generated to analyze them. Examples:  
  - Reading an image via `functions.view_image` ([https://developers.openai.com/cookbook/examples/gpt-5/codex\_prompting\_guide/](https://developers.openai.com/cookbook/examples/gpt-5/codex_prompting_guide/))  
  - Reading logs via `cat` / `sed`.  
- Adjust the code until everything functions as expected and the UI is visually clean and compliant with the requirements.

Any capture or trace must be saved and organized in the dedicated folder, as showed in examples below.
""",
    )
    parser.add_argument("code", nargs="?", help="Python code to execute.")
    parser.add_argument("--port", type=int, default=None, help="CDP port (default: 9222).")
    parser.add_argument(
        "--headless",
        action=argparse.BooleanOptionalAction,
        default=DEFAULT_HEADLESS,
        help="Run Chromium in headless mode (default: true).",
    )
    parser.add_argument(
        "--start-url",
        default=None,
        help="URL to open when Chromium starts (default: about:blank).",
    )
    parser.add_argument(
        "--window-size",
        type=_parse_window_size,
        default=DEFAULT_WINDOW_SIZE,
        help="Chromium window size in pixels as WIDTHxHEIGHT (default: 1920x1080).",
    )

    args = parser.parse_args()
    code = args.code or _read_code_from_stdin()
    if not code or not code.strip():
        parser.error("Provide code as an argument or via stdin.")

    options = RunOptions(
        code=code,
        port=args.port,
        headless=args.headless,
        start_url=args.start_url or DEFAULT_START_URL,
        window_size=args.window_size,
    )
    result = run_snippet(options)
    print(f"OK | port={result['port']} | export_folder={result['export_folder']}")


if __name__ == "__main__":
    main()
