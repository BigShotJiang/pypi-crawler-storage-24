"""Bundled Snakemake workflow assets."""
