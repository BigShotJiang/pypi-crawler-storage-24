from __future__ import annotations
"""
athena-python-xlsx - Drop-in replacement for openpyxl.

This SDK provides an openpyxl-compatible API that connects to XLSX Studio
for real-time collaboration. Use exactly the same code you would with openpyxl:

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Border, Alignment
    from openpyxl.utils import get_column_letter

    # Configure via environment variables (recommended):
    #   ATHENA_XLSX_BASE_URL=https://api.xlsx-studio.com
    #   ATHENA_XLSX_API_KEY=your-api-key

    # Create a new workbook
    wb = Workbook.create(name="My Workbook")

    # Or upload an existing file
    wb = Workbook.upload("my_data.xlsx")

    # Or connect to an existing workbook
    wb = Workbook(workbook_id="wb_123")

    # Work with sheets and cells (same API as openpyxl)
    ws = wb.active
    ws['A1'] = "Hello World!"
    ws['B1'] = 42
    ws['A1'].font = Font(bold=True, size=14)

    wb.save("output.xlsx")

For features not yet implemented, UnsupportedFeatureError is raised with
a clear message explaining what's not supported.
"""

# Main entry point
from .workbook import Workbook

# Worksheet classes
from .worksheet import Worksheet

# Cell classes
from .cell import Cell, MergedCell

# Style classes (also available via openpyxl.styles)
from .styles import (
    Font,
    PatternFill,
    Border,
    Side,
    Alignment,
    FORMAT_GENERAL,
    FORMAT_NUMBER,
    FORMAT_NUMBER_00,
    FORMAT_NUMBER_COMMA_SEPARATED1,
    FORMAT_PERCENTAGE,
    FORMAT_PERCENTAGE_00,
    FORMAT_DATE_YYYYMMDD2,
    FORMAT_DATE_DATETIME,
    FORMAT_CURRENCY_USD,
    FORMAT_CURRENCY_EUR,
)

# Utility functions (also available via openpyxl.utils)
from .utils import (
    get_column_letter,
    column_index_from_string,
    coordinate_from_string,
    cell_reference,
    range_reference,
    parse_range,
)

# Error classes
from .errors import (
    XlsxSdkError,
    UnsupportedFeatureError,
    RemoteError,
    ConflictError,
    ValidationError,
    ConnectionError,
    AuthenticationError,
    ExportError,
    RenderError,
    UploadError,
)

# ---------------------------------------------------------------------------
# Global buffer registry & flush_all
# ---------------------------------------------------------------------------
import weakref as _weakref
from typing import TYPE_CHECKING as _TYPE_CHECKING

if _TYPE_CHECKING:
    from .batching import CommandBuffer

_active_buffers: list[_weakref.ref["CommandBuffer"]] = []


def flush_all() -> None:
    """Flush all active workbook command buffers.

    Called automatically by Daytona bootstrap after user code executes.
    Also useful for scripts that create multiple Workbook instances.
    """
    alive: list[_weakref.ref["CommandBuffer"]] = []
    for ref in _active_buffers:
        buf = ref()
        if buf is not None:
            alive.append(ref)
            if buf.pending_count > 0:
                try:
                    buf.flush()
                except Exception:
                    pass
    _active_buffers[:] = alive


def load_workbook(
    filename: str,
    base_url: str | None = None,
    api_key: str | None = None,
) -> Workbook:
    """
    Load an XLSX file into XLSX Studio.

    This is the openpyxl-compatible entry point. It uploads the file
    and returns a Workbook connected to it.

    Args:
        filename: Path to the XLSX file
        base_url: Base URL of the XLSX Studio API
        api_key: Optional API key

    Returns:
        Workbook instance
    """
    return Workbook.upload(filename, base_url=base_url, api_key=api_key)


__version__ = "0.1.0"

__all__ = [
    # Main entry points
    "Workbook",
    "load_workbook",
    # Worksheet
    "Worksheet",
    # Cell
    "Cell",
    "MergedCell",
    # Styles
    "Font",
    "PatternFill",
    "Border",
    "Side",
    "Alignment",
    "FORMAT_GENERAL",
    "FORMAT_NUMBER",
    "FORMAT_NUMBER_00",
    "FORMAT_NUMBER_COMMA_SEPARATED1",
    "FORMAT_PERCENTAGE",
    "FORMAT_PERCENTAGE_00",
    "FORMAT_DATE_YYYYMMDD2",
    "FORMAT_DATE_DATETIME",
    "FORMAT_CURRENCY_USD",
    "FORMAT_CURRENCY_EUR",
    # Utils
    "get_column_letter",
    "column_index_from_string",
    "coordinate_from_string",
    "cell_reference",
    "range_reference",
    "parse_range",
    # Errors
    "XlsxSdkError",
    "UnsupportedFeatureError",
    "RemoteError",
    "ConflictError",
    "ValidationError",
    "ConnectionError",
    "AuthenticationError",
    "ExportError",
    "RenderError",
    "UploadError",
    # Flush helper
    "flush_all",
    # Version
    "__version__",
]
