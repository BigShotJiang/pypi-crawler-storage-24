"""
Style classes for openpyxl compatibility.

Provides Font, PatternFill, Border, Side, Alignment, and numbers
matching openpyxl.styles.
"""

from __future__ import annotations
from typing import Optional


class Font:
    """
    Font properties for a cell.

    Mirrors openpyxl.styles.Font.
    """

    def __init__(
        self,
        name: Optional[str] = None,
        size: Optional[float] = None,
        bold: bool = False,
        italic: bool = False,
        underline: Optional[str] = None,
        strikethrough: bool = False,
        color: Optional[str] = None,
    ):
        self.name = name
        self.size = size
        self.bold = bold
        self.italic = italic
        self.underline = underline
        self.strikethrough = strikethrough
        self.color = color

    def to_style_dict(self) -> dict:
        """Convert to command style dictionary."""
        result: dict = {}
        if self.name is not None:
            result["fontFamily"] = self.name
        if self.size is not None:
            result["fontSize"] = self.size
        if self.bold:
            result["bold"] = True
        if self.italic:
            result["italic"] = True
        if self.underline:
            result["underline"] = True
        if self.strikethrough:
            result["strikethrough"] = True
        if self.color:
            result["colorHex"] = self.color
        return result

    def __repr__(self) -> str:
        parts = []
        if self.name:
            parts.append(f"name={self.name!r}")
        if self.size:
            parts.append(f"size={self.size}")
        if self.bold:
            parts.append("bold=True")
        if self.italic:
            parts.append("italic=True")
        return f"Font({', '.join(parts)})"


class PatternFill:
    """
    Fill pattern for a cell.

    Mirrors openpyxl.styles.PatternFill.
    """

    def __init__(
        self,
        fill_type: Optional[str] = None,
        fgColor: Optional[str] = None,
        bgColor: Optional[str] = None,
        patternType: Optional[str] = None,
    ):
        self.fill_type = fill_type or patternType
        self.fgColor = fgColor
        self.bgColor = bgColor

    def to_style_dict(self) -> dict:
        """Convert to command style dictionary."""
        result: dict = {}
        if self.fgColor:
            result["bgColorHex"] = self.fgColor
        return result


class Side:
    """
    Border side specification.

    Mirrors openpyxl.styles.Side.
    """

    def __init__(
        self,
        style: Optional[str] = None,
        color: Optional[str] = None,
    ):
        self.style = style
        self.color = color

    def to_dict(self) -> dict[str, str]:
        result: dict[str, str] = {}
        if self.style:
            result["style"] = self.style
        if self.color:
            result["colorHex"] = self.color
        return result


class Border:
    """
    Cell border specification.

    Mirrors openpyxl.styles.Border.
    """

    def __init__(
        self,
        left: Optional[Side] = None,
        right: Optional[Side] = None,
        top: Optional[Side] = None,
        bottom: Optional[Side] = None,
    ):
        self.left = left
        self.right = right
        self.top = top
        self.bottom = bottom

    def to_style_dict(self) -> dict:
        """Convert to command style dictionary."""
        result: dict = {}
        if self.top:
            result["borderTop"] = self.top.to_dict()
        if self.bottom:
            result["borderBottom"] = self.bottom.to_dict()
        if self.left:
            result["borderLeft"] = self.left.to_dict()
        if self.right:
            result["borderRight"] = self.right.to_dict()
        return result


class Alignment:
    """
    Cell alignment specification.

    Mirrors openpyxl.styles.Alignment.
    """

    def __init__(
        self,
        horizontal: Optional[str] = None,
        vertical: Optional[str] = None,
        wrap_text: bool = False,
        text_rotation: int = 0,
        shrink_to_fit: bool = False,
        indent: int = 0,
    ):
        self.horizontal = horizontal
        self.vertical = vertical
        self.wrap_text = wrap_text
        self.text_rotation = text_rotation
        self.shrink_to_fit = shrink_to_fit
        self.indent = indent

    def to_style_dict(self) -> dict:
        """Convert to command style dictionary."""
        result: dict = {}
        if self.horizontal:
            result["horizontalAlignment"] = self.horizontal
        if self.vertical:
            result["verticalAlignment"] = self.vertical
        if self.wrap_text:
            result["wrapText"] = True
        return result


# Number format constants (matching openpyxl.styles.numbers)
FORMAT_GENERAL = "General"
FORMAT_NUMBER = "0"
FORMAT_NUMBER_00 = "0.00"
FORMAT_NUMBER_COMMA_SEPARATED1 = "#,##0.00"
FORMAT_PERCENTAGE = "0%"
FORMAT_PERCENTAGE_00 = "0.00%"
FORMAT_DATE_YYYYMMDD2 = "yyyy-mm-dd"
FORMAT_DATE_DATETIME = "yyyy-mm-dd h:mm:ss"
FORMAT_CURRENCY_USD = '"$"#,##0.00'
FORMAT_CURRENCY_EUR = '[$\u20ac-407]#,##0.00'
