"""
Type definitions and protocols for the XLSX SDK.
"""

from __future__ import annotations
from typing import Any, Literal, Optional, Protocol, TypedDict, Union
from dataclasses import dataclass, field


# Type aliases for IDs
WorkbookId = str
SheetId = str
CellId = str
ExportJobId = str
RenderJobId = str


# Cell data types (matching OOXML spec)
CellTypeLiteral = Literal[
    "string",
    "number",
    "boolean",
    "date",
    "formula",
    "error",
    "empty",
]


# Command types
CommandType = Literal[
    "SetCellValue",
    "SetCellStyle",
    "SetCellFormula",
    "AddSheet",
    "DeleteSheet",
    "RenameSheet",
    "SetColumnWidth",
    "SetRowHeight",
    "MergeCells",
    "UnmergeCells",
    "InsertRows",
    "InsertColumns",
    "DeleteRows",
    "DeleteColumns",
    "SetSheetProperties",
]


class CellStyle(TypedDict, total=False):
    """Cell styling options."""

    fontFamily: str
    fontSize: float
    bold: bool
    italic: bool
    underline: bool
    strikethrough: bool
    colorHex: str
    bgColorHex: str
    numberFormat: str
    horizontalAlignment: str
    verticalAlignment: str
    wrapText: bool
    borderTop: dict[str, str]
    borderBottom: dict[str, str]
    borderLeft: dict[str, str]
    borderRight: dict[str, str]


@dataclass
class CellSnapshot:
    """Snapshot of a cell's state."""

    row: int
    col: int
    value: Any
    cell_type: CellTypeLiteral
    formula: Optional[str] = None
    style: Optional[CellStyle] = None
    comment: Optional[str] = None


@dataclass
class MergedRange:
    """A merged cell range."""

    start_row: int
    start_col: int
    end_row: int
    end_col: int


@dataclass
class SheetSnapshot:
    """Snapshot of a worksheet's state."""

    id: SheetId
    index: int
    name: str
    cells: dict[str, CellSnapshot]
    merged_ranges: list[MergedRange] = field(default_factory=list)
    column_widths: dict[int, float] = field(default_factory=dict)
    row_heights: dict[int, float] = field(default_factory=dict)
    frozen_rows: int = 0
    frozen_cols: int = 0
    hidden: bool = False
    tab_color: Optional[str] = None


@dataclass
class WorkbookSnapshot:
    """Complete snapshot of a workbook's state."""

    workbook_id: WorkbookId
    name: str
    sheet_count: int
    sheets: list[SheetSnapshot]
    active_sheet_index: int = 0


class CommandsResponse(TypedDict, total=False):
    """Response from POST /commands."""

    applied: bool
    created: dict[str, list[str]]
    snapshot: WorkbookSnapshot
    error: dict[str, Any]


class ExportStatus(TypedDict, total=False):
    """Export job status."""

    job_id: ExportJobId
    status: Literal["queued", "processing", "completed", "failed"]
    download_url: Optional[str]
    error: Optional[str]


class RenderStatus(TypedDict, total=False):
    """Render job status."""

    job_id: RenderJobId
    status: Literal["queued", "processing", "completed", "failed"]
    image_url: Optional[str]
    error: Optional[str]
