"""
Cell proxy class.

Provides openpyxl-compatible Cell abstraction that operates
on remote workbooks via the XLSX Studio API.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Optional, Union

from .commands import SetCellValue, SetCellFormula, SetCellStyle
from .errors import UnsupportedFeatureError
from .typing import CellSnapshot, CellStyle
from .utils import get_column_letter, cell_reference

if TYPE_CHECKING:
    from .batching import CommandBuffer
    from .worksheet import Worksheet
    from .styles import Font, PatternFill, Border, Alignment


class Cell:
    """
    Proxy for a single cell in a worksheet.

    Provides openpyxl-compatible Cell API that reads from snapshots
    and writes via commands to the XLSX Studio API.

    Example:
        ws = wb.active
        cell = ws['A1']
        cell.value = "Hello"
        cell.font = Font(bold=True)
    """

    def __init__(
        self,
        worksheet: Worksheet,
        row: int,
        col: int,
        snapshot: Optional[CellSnapshot] = None,
    ):
        self._worksheet = worksheet
        self._row = row
        self._col = col
        self._snapshot = snapshot
        self._value: Any = snapshot.value if snapshot else None
        self._formula: Optional[str] = snapshot.formula if snapshot else None
        self._font: Optional[Font] = None
        self._fill: Optional[PatternFill] = None
        self._border: Optional[Border] = None
        self._alignment: Optional[Alignment] = None
        self._number_format: Optional[str] = None

    @property
    def _buffer(self) -> CommandBuffer:
        return self._worksheet._buffer

    @property
    def row(self) -> int:
        """1-based row number."""
        return self._row

    @property
    def column(self) -> int:
        """1-based column number."""
        return self._col

    @property
    def column_letter(self) -> str:
        """Column letter (e.g., 'A', 'B', 'AA')."""
        return get_column_letter(self._col)

    @property
    def coordinate(self) -> str:
        """Cell coordinate string (e.g., 'A1')."""
        return cell_reference(self._row, self._col)

    @property
    def value(self) -> Any:
        """Get or set the cell value."""
        return self._value

    @value.setter
    def value(self, val: Any) -> None:
        """Set the cell value, emitting a SetCellValue command."""
        self._value = val
        self._formula = None  # Setting value clears formula

        # Determine cell type
        cell_type = None
        if val is None:
            cell_type = "empty"
        elif isinstance(val, bool):
            cell_type = "boolean"
        elif isinstance(val, (int, float)):
            cell_type = "number"
        elif isinstance(val, str):
            if val.startswith("="):
                # Treat as formula
                self._formula = val
                self._buffer.add(SetCellFormula(
                    sheet_index=self._worksheet._index,
                    row=self._row,
                    col=self._col,
                    formula=val,
                ))
                return
            cell_type = "string"

        self._buffer.add(SetCellValue(
            sheet_index=self._worksheet._index,
            row=self._row,
            col=self._col,
            value=val,
            cell_type=cell_type,
        ))

    @property
    def data_type(self) -> str:
        """The data type of the cell (s=string, n=number, b=boolean, f=formula)."""
        if self._formula:
            return "f"
        if self._value is None:
            return "n"  # openpyxl default
        if isinstance(self._value, bool):
            return "b"
        if isinstance(self._value, (int, float)):
            return "n"
        return "s"

    @property
    def font(self) -> Optional[Font]:
        """Get the cell font."""
        return self._font

    @font.setter
    def font(self, value: Font) -> None:
        """Set the cell font, emitting a SetCellStyle command."""
        self._font = value
        self._emit_style_command()

    @property
    def fill(self) -> Optional[PatternFill]:
        """Get the cell fill."""
        return self._fill

    @fill.setter
    def fill(self, value: PatternFill) -> None:
        """Set the cell fill, emitting a SetCellStyle command."""
        self._fill = value
        self._emit_style_command()

    @property
    def border(self) -> Optional[Border]:
        """Get the cell border."""
        return self._border

    @border.setter
    def border(self, value: Border) -> None:
        """Set the cell border, emitting a SetCellStyle command."""
        self._border = value
        self._emit_style_command()

    @property
    def alignment(self) -> Optional[Alignment]:
        """Get the cell alignment."""
        return self._alignment

    @alignment.setter
    def alignment(self, value: Alignment) -> None:
        """Set the cell alignment, emitting a SetCellStyle command."""
        self._alignment = value
        self._emit_style_command()

    @property
    def number_format(self) -> str:
        """Get the cell number format."""
        return self._number_format or "General"

    @number_format.setter
    def number_format(self, value: str) -> None:
        """Set the cell number format."""
        self._number_format = value
        self._emit_style_command()

    @property
    def comment(self) -> Optional[str]:
        """Get the cell comment."""
        if self._snapshot:
            return self._snapshot.comment
        return None

    def _emit_style_command(self) -> None:
        """Emit a SetCellStyle command with all current style properties."""
        style: CellStyle = {}

        if self._font:
            style.update(self._font.to_style_dict())
        if self._fill:
            style.update(self._fill.to_style_dict())
        if self._border:
            style.update(self._border.to_style_dict())
        if self._alignment:
            style.update(self._alignment.to_style_dict())
        if self._number_format:
            style["numberFormat"] = self._number_format

        if style:
            self._buffer.add(SetCellStyle(
                sheet_index=self._worksheet._index,
                row=self._row,
                col=self._col,
                style=style,
            ))

    def __repr__(self) -> str:
        return f"<Cell {self._worksheet.title}.{self.coordinate}>"


class MergedCell:
    """
    A cell that is part of a merged range but is not the top-left cell.

    Matches openpyxl behavior where accessing a merged cell returns
    a MergedCell object with read-only properties.
    """

    def __init__(self, worksheet: Worksheet, row: int, col: int):
        self._worksheet = worksheet
        self._row = row
        self._col = col

    @property
    def row(self) -> int:
        return self._row

    @property
    def column(self) -> int:
        return self._col

    @property
    def coordinate(self) -> str:
        return cell_reference(self._row, self._col)

    @property
    def value(self) -> None:
        return None

    def __repr__(self) -> str:
        return f"<MergedCell {self._worksheet.title}.{self.coordinate}>"
