"""Remote font fetching utilities."""

from __future__ import annotations

import hashlib
import os
import tempfile
import urllib.request
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

MAX_FONT_SIZE = 10 * 1024 * 1024  # 10 MiB safety limit
ENV_FONT_CACHE_DIR = "SVG2OOXML_FONT_CACHE_DIR"
ENV_WEB_FONT_CACHE_DIR = "SVG2OOXML_WEB_FONT_CACHE"


def _default_cache_directory() -> Path:
    override = os.getenv(ENV_FONT_CACHE_DIR) or os.getenv(ENV_WEB_FONT_CACHE_DIR)
    if override:
        return Path(override).expanduser()
    xdg_cache = os.getenv("XDG_CACHE_HOME")
    if xdg_cache:
        return Path(xdg_cache).expanduser() / "svg2ooxml" / "fonts"
    return Path.home() / ".cache" / "svg2ooxml" / "fonts"


@dataclass(frozen=True)
class FontSource:
    """Describe a remote font resource."""

    url: str
    font_family: str
    font_weight: str = "regular"
    font_style: str = "normal"


class FontFetcher:
    """Download and cache remote font files for embedding."""

    def __init__(
        self,
        cache_directory: str | Path | None = None,
        *,
        allow_network: bool = True,
        max_download_size: int = MAX_FONT_SIZE,
    ) -> None:
        self.cache_directory = Path(cache_directory or _default_cache_directory())
        self.cache_directory.mkdir(parents=True, exist_ok=True)
        self.allow_network = allow_network
        self.max_download_size = max_download_size

    def fetch_sources(self, sources: Iterable[FontSource]) -> list[tuple[FontSource, Path]]:
        results: list[tuple[FontSource, Path]] = []
        for source in sources:
            path = self.fetch(source)
            if path is not None:
                results.append((source, path))
        return results

    def fetch(self, source: FontSource) -> Path | None:
        cache_key = self._cache_key(source.url)
        target_path = self.cache_directory / cache_key
        if target_path.exists():
            try:
                if target_path.stat().st_size > 0:
                    return target_path
                target_path.unlink(missing_ok=True)
            except Exception:
                return target_path

        if not self.allow_network:
            return None

        parsed = urlparse(source.url)
        host = parsed.netloc.lower()
        try:
            if "fonts.googleapis.com" in host:
                css_bytes = self._download_bytes(source.url)
                if css_bytes is None:
                    return None
                for font_url in self._extract_urls_from_css(css_bytes.decode("utf-8", errors="ignore")):
                    path = self._download_to_cache(font_url)
                    if path is not None:
                        return path
                return None
            return self._download_to_cache(source.url)
        except Exception:
            if target_path.exists():
                target_path.unlink(missing_ok=True)
            return None

    def _download_to_cache(self, url: str) -> Path | None:
        cache_key = self._cache_key(url)
        target_path = self.cache_directory / cache_key
        data = self._download_bytes(url)
        if data is None or not self._sanitize_font_data(data):
            return None
        tmp_path: Path | None = None
        try:
            self.cache_directory.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=self.cache_directory, delete=False) as tmp_file:
                tmp_file.write(data)
                tmp_path = Path(tmp_file.name)
            tmp_path.replace(target_path)
            return target_path
        except Exception:
            if tmp_path is not None:
                try:
                    tmp_path.unlink(missing_ok=True)
                except Exception:
                    pass
            return None

    def _download_bytes(self, url: str) -> bytes | None:
        try:
            with urllib.request.urlopen(url, timeout=15) as response:
                data = response.read(self.max_download_size + 1)
        except Exception:
            return None
        if len(data) > self.max_download_size:
            return None
        return data

    @staticmethod
    def _sanitize_font_data(data: bytes) -> bool:
        sniff = data[:32].lower()
        if b"<script" in sniff or b"<html" in sniff:
            return False
        return True

    @staticmethod
    def _extract_urls_from_css(css: str) -> list[str]:
        import re

        return [match.strip() for match in re.findall(r"url\(['\"]?(.*?)['\"]?\)", css)]

    @staticmethod
    def _cache_key(url: str) -> str:
        digest = hashlib.sha256(url.encode("utf-8")).hexdigest()
        _, ext = os.path.splitext(url)
        ext = ext.lower() if ext else ".ttf"
        return f"{digest}{ext}"


__all__ = ["FontFetcher", "FontSource", "MAX_FONT_SIZE"]
