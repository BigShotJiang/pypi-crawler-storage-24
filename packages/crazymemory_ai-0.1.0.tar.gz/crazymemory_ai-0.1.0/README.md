# Crazy Memory

World's most advanced AI memory system with adaptive hierarchies, intelligent retrieval, and temporal reasoning.

## Overview

Crazy Memory is a research-grade memory system designed to surpass existing solutions (ContextMemory, Supermemory, Mem0) through:

- **Adaptive Multi-Model Embeddings** - Fusion of text, code, and semantic embeddings
- **Temporal Memory Hierarchies** - Time-aware decay and context windows
- **Cross-Memory Reasoning** - Chain inference across related memories
- **Intelligent Compression** - Semantic summarization with knowledge preservation
- **Multi-dimensional Scoring** - Multi-dimensional relevance with uncertainty quantification
- **Living Knowledge Graph** - Dynamic relationships with version tracking
- **Adaptive Forgetting** - RL-optimized memory retention policies
- **Context-Aware Injection** - Optimal memory placement in prompts

## Architecture

```
                    CRAZY MEMORY SYSTEM

 Ingestion -> Memory Engine -> Hierarchies -> Graph -> Storage
     ↓              ↓               ↓          ↓         ↓
 Connectors    Extraction    Temporal Decay  Relations  Hybrid
 Multi-modal   Classification   Time Windows  Versioning  Tiered

 Intelligent Retrieval
  - Multi-model fusion
  - Cross-memory reasoning
  - Adaptive scoring
  - Context-aware injection
```

## Features

### Core Memory System

- **5 Memory Types**: Semantic, Episodic, Procedural, Knowledge, Context
- **6 Relationship Types**: Updates, Extends, Derives, Contradicts, Triggers, Aggregates
- **4 Storage Tiers**: Hot (Redis), Warm (PostgreSQL), Cold (Compressed), Archive
- **Multi-model embeddings**: Text, Code, Semantic fusion

### Advanced Capabilities

- **Temporal reasoning**: Time-aware decay and context windows
- **Cross-memory reasoning**: Chain inference across related memories
- **Intelligent compression**: Semantic summarization preserving knowledge
- **Adaptive forgetting**: RL-optimized retention policies
- **Contradiction resolution**: LLM-driven conflict resolution

### Integration

- **Universal connectors**: Google Drive, Notion, GitHub, Gmail, Slack, etc.
- **Multi-modal processing**: Text, PDF, images, videos, audio, code
- **Python SDK**: Async-first, type-safe client library
- **REST API**: FastAPI with OpenAPI documentation
- **MCP Server**: Model Context Protocol for AI assistants

## Installation

### Docker Deployment (Recommended)

```bash
# Clone repository
git clone https://github.com/crazymemory/crazymemory.git
cd crazymemory

# Start all services
docker compose up -d

# Access API
curl http://localhost:8000/
```

### Manual Installation

```bash
# Install dependencies
pip install -r requirements.txt

# Set up database
# PostgreSQL, Redis, and Qdrant must be running
docker compose up -d

# Configure environment
cp .env.example .env
# Edit .env with your API keys and database URLs

# Start API server
python -m crazymemory.cli
```

## Quick Start

### Basic Usage

```python
from crazymemory import CrazyMemory, MemoryType
import asyncio

async def main():
    # Initialize client
    memory = CrazyMemory()
    
    # Add memories
    memory_id = await memory.add(
        content="User prefers Python for data science",
        memory_type=MemoryType.SEMANTIC,
        importance=0.9,
        user_id="user_123"
    )
    print(f"Memory added: {memory_id}")
    
    # Search memories
    results = await memory.search(
        query="What programming language does user prefer?",
        user_id="user_123",
        limit=10
    )
    
    for result in results:
        print(f"Found: {result['content']} (score: {result['score']})")
    
    # Get user profile
    profile = await memory.get_profile("user_123")
    print(f"Static facts: {profile['static']}")
    print(f"Dynamic facts: {profile['dynamic']}")

asyncio.run(main())
```

### API Endpoints

The Crazy Memory API provides several endpoints:

- `GET /` - API information
- `GET /health` - Health check
- `GET /docs` - Interactive API documentation (Swagger UI)
- `GET /openapi.json` - OpenAPI schema

Access the interactive documentation at: `http://localhost:8000/docs`

### Docker Commands

```bash
# Build Docker image
docker build -t crazymemory/crazymemory .

# Run container
docker run -d -p 8000:8000 --name crazymemory-server crazymemory/crazymemory

# Start database services
docker compose up -d

# Check container status
docker ps

# View logs
docker logs crazymemory-server

# Stop services
docker compose down
```

## Memory Types

### Semantic Facts
Stable, long-term truths about user:
- Name, preferences, skills
- Professional background
- Long-term goals

### Episodic Bubbles
Time-bound events with automatic decay:
- Current tasks, deadlines
- Problems being solved
- Significant events

### Procedural Memories
Agent workflows and behaviors:
- Agent interaction patterns
- Task execution strategies
- Decision-making processes

### Knowledge
Agent capabilities and expertise:
- Skills and knowledge areas
- Learning patterns
- Expertise domains

### Context Windows
Scenario-specific memories:
- Project-specific context
- Conversation topics
- Temporary context

## Storage Architecture

### Multi-Tier Storage System

1. **Hot Tier (Redis)**: 24-hour TTL for recent data
2. **Warm Tier (PostgreSQL)**: 7-day TTL for active data
3. **Cold Tier (PostgreSQL)**: 30-day TTL for archival
4. **Archive**: Long-term storage with compression

### Database Services

- **PostgreSQL**: Primary database for structured storage
- **Redis**: Hot cache layer for fast access
- **Qdrant**: Vector database for semantic search

## Configuration

### Environment Variables

```bash
# PostgreSQL
POSTGRES_URL=postgresql://localhost:5432/crazymemory
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres
POSTGRES_DB=crazymemory

# Redis
REDIS_URL=redis://localhost:6379/0

# Qdrant
QDRANT_URL=http://localhost:6333

# LLM Configuration
LLM_PROVIDER=openai
LLM_MODEL=gpt-4o
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
COHERE_API_KEY=...

# Application
API_HOST=0.0.0.0
API_PORT=8000
DEBUG=true
```

## Project Status

Current implementation status:

- **Core Infrastructure**: Complete
- **Memory Engine**: Complete
- **Hybrid Storage**: Complete
- **Intelligent Retrieval**: Complete
- **Basic API**: Complete
- **Advanced Features**: Partial
- **External Connectors**: Framework ready
- **Testing**: Core functionality verified

## Development

### Project Structure

```
crazymemory/
├── packages/
│   ├── core/           # Main Python package
│   ├── embeddings/     # Multi-model embeddings
│   ├── connectors/     # External data connectors
│   └── sdk/           # TypeScript SDK
├── apps/
│   └── api/           # FastAPI server
├── examples/           # Usage examples
├── tests/             # Test suite
└── docker/            # Docker configurations
```

### Running Tests

```bash
# Run core tests
python -m pytest packages/core/tests/

# Run integration tests (requires database services)
python -m pytest tests/integration/
```

## Benchmarks

Crazy Memory targets state-of-the-art performance:

| Benchmark | Target | Status |
|-----------|---------|---------|
| LongMemEval | >90% | In development |
| LoCoMo | #1 | In development |
| ConvoMem | >90% | In development |
| Custom benchmarks | Revolutionary | In development |

## Contributing

We welcome contributions! Please ensure:

1. Code follows project style guidelines
2. Tests pass for all changes
3. Documentation is updated
4. Pull requests include clear descriptions

## License

Apache 2.0 - See LICENSE file for details.

## Support

- **Documentation**: http://crazymemory.vercel.app
- **Issues**: https://github.com/Unmesh100/crazymemory/issues
- **Discussions**: https://github.com/Unmesh100/crazymemory/discussions

---

**Give your AI the memory it deserves.**
