"""Universal external data connector framework."""

import asyncio
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional
from dataclasses import dataclass
import httpx


@dataclass
class Document:
    """Unified document structure for external data."""

    id: str
    title: str
    content: str
    url: Optional[str] = None
    source: str = ""
    source_type: str = ""
    metadata: Dict[str, Any] = None
    created_at: datetime = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
        if self.created_at is None:
            self.created_at = datetime.utcnow()


class BaseConnector(ABC):
    """Base class for external data connectors."""

    def __init__(self, credentials: Dict[str, Any]):
        self.credentials = credentials
        self.client = None

    @abstractmethod
    async def authenticate(self) -> bool:
        """Authenticate with external service."""
        pass

    @abstractmethod
    async def fetch_documents(self, **kwargs) -> List[Document]:
        """Fetch documents from external service."""
        pass

    @abstractmethod
    async def test_connection(self) -> bool:
        """Test connection to external service."""
        pass

    def get_connector_name(self) -> str:
        """Get connector name."""
        return self.__class__.__name__


class GoogleDriveConnector(BaseConnector):
    """Connector for Google Drive."""

    async def authenticate(self) -> bool:
        """Authenticate with Google Drive API."""
        # Implementation would use Google OAuth
        print(f"Authenticating with Google Drive...")
        return True

    async def fetch_documents(self, **kwargs) -> List[Document]:
        """Fetch documents from Google Drive."""
        # Implementation would use Google Drive API
        # For now, return sample documents
        return [
            Document(
                id="doc1",
                title="Sample Document",
                content="This is a sample document from Google Drive.",
                source="google_drive",
                source_type="document",
            )
        ]

    async def test_connection(self) -> bool:
        """Test Google Drive connection."""
        return await self.authenticate()


class NotionConnector(BaseConnector):
    """Connector for Notion."""

    async def authenticate(self) -> bool:
        """Authenticate with Notion API."""
        print(f"Authenticating with Notion...")
        return True

    async def fetch_documents(self, **kwargs) -> List[Document]:
        """Fetch documents from Notion."""
        # Implementation would use Notion API
        return [
            Document(
                id="notion1",
                title="Notion Page",
                content="This is a sample page from Notion.",
                source="notion",
                source_type="page",
            )
        ]

    async def test_connection(self) -> bool:
        """Test Notion connection."""
        return await self.authenticate()


class GitHubConnector(BaseConnector):
    """Connector for GitHub."""

    async def authenticate(self) -> bool:
        """Authenticate with GitHub API."""
        token = self.credentials.get("token")
        if not token:
            return False

        self.client = httpx.AsyncClient(
            headers={"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
        )

        # Test authentication
        response = await self.client.get("https://api.github.com/user")
        return response.status_code == 200

    async def fetch_documents(self, **kwargs) -> List[Document]:
        """Fetch repositories or files from GitHub."""
        if not self.client:
            return []

        repo_owner = kwargs.get("repo_owner")
        repo_name = kwargs.get("repo_name")

        if not repo_owner or not repo_name:
            return []

        # Fetch repository contents
        url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/readme"
        response = await self.client.get(url)

        if response.status_code == 200:
            data = response.json()
            return [
                Document(
                    id=f"github_{repo_owner}_{repo_name}",
                    title=f"README: {repo_name}",
                    content=data.get("content", ""),
                    url=data.get("html_url"),
                    source="github",
                    source_type="repository",
                    metadata={"repo_owner": repo_owner, "repo_name": repo_name},
                )
            ]

        return []

    async def test_connection(self) -> bool:
        """Test GitHub connection."""
        if not self.client:
            return await self.authenticate()

        response = await self.client.get("https://api.github.com/user")
        return response.status_code == 200


class SlackConnector(BaseConnector):
    """Connector for Slack."""

    async def authenticate(self) -> bool:
        """Authenticate with Slack API."""
        token = self.credentials.get("token")
        if not token:
            return False

        self.client = httpx.AsyncClient(headers={"Authorization": f"Bearer {token}"})

        return True

    async def fetch_documents(self, **kwargs) -> List[Document]:
        """Fetch messages from Slack channels."""
        if not self.client:
            return []

        channel_id = kwargs.get("channel_id")
        limit = kwargs.get("limit", 100)

        if not channel_id:
            return []

        # Fetch messages
        url = "https://slack.com/api/conversations.history"
        params = {"channel": channel_id, "limit": limit}

        response = await self.client.get(url, params=params)

        if response.status_code == 200:
            data = response.json()
            if data.get("ok"):
                messages = data.get("messages", [])
                documents = []

                for msg in messages:
                    documents.append(
                        Document(
                            id=f"slack_{msg.get('ts', '')}",
                            title=f"Slack Message",
                            content=msg.get("text", ""),
                            source="slack",
                            source_type="message",
                            metadata={
                                "channel": channel_id,
                                "user": msg.get("user"),
                                "timestamp": msg.get("ts"),
                            },
                        )
                    )

                return documents

        return []

    async def test_connection(self) -> bool:
        """Test Slack connection."""
        if not self.client:
            return await self.authenticate()

        response = await self.client.get("https://slack.com/api/auth.test")
        return response.status_code == 200


class UniversalConnector:
    """Universal connector factory and manager."""

    CONNECTORS = {
        "google_drive": GoogleDriveConnector,
        "notion": NotionConnector,
        "github": GitHubConnector,
        "slack": SlackConnector,
    }

    def __init__(self):
        self.active_connections: Dict[str, BaseConnector] = {}

    def get_connector(self, provider: str, credentials: Dict[str, Any]) -> Optional[BaseConnector]:
        """Get connector instance for provider."""
        if provider not in self.CONNECTORS:
            return None

        connector_class = self.CONNECTORS[provider]
        connector = connector_class(credentials)

        return connector

    async def create_connection(self, provider: str, credentials: Dict[str, Any]) -> Dict[str, Any]:
        """Create and authenticate a connection."""
        connector = self.get_connector(provider, credentials)

        if not connector:
            return {"success": False, "error": f"Unknown provider: {provider}"}

        # Test connection
        is_connected = await connector.test_connection()

        if is_connected:
            # Store active connection
            connection_id = f"{provider}_{datetime.utcnow().timestamp()}"
            self.active_connections[connection_id] = connector

            return {"success": True, "connection_id": connection_id, "provider": provider}
        else:
            return {"success": False, "error": "Failed to authenticate with provider"}

    async def sync_documents(self, connection_id: str, **sync_options) -> List[Document]:
        """Sync documents from a connection."""
        if connection_id not in self.active_connections:
            return []

        connector = self.active_connections[connection_id]
        documents = await connector.fetch_documents(**sync_options)

        return documents

    async def list_connections(self) -> List[Dict[str, Any]]:
        """List all active connections."""
        connections = []

        for conn_id, connector in self.active_connections.items():
            connections.append(
                {
                    "connection_id": conn_id,
                    "provider": connector.get_connector_name(),
                    "created_at": conn_id.split("_")[-1],
                }
            )

        return connections

    async def remove_connection(self, connection_id: str) -> bool:
        """Remove a connection."""
        if connection_id in self.active_connections:
            del self.active_connections[connection_id]
            return True
        return False


class MultiModalProcessor:
    """Process multi-modal content (text, images, videos, code)."""

    async def process_text(self, text: str) -> Dict[str, Any]:
        """Process text content."""
        return {
            "type": "text",
            "content": text,
            "word_count": len(text.split()),
            "char_count": len(text),
        }

    async def process_code(self, code: str, language: str) -> Dict[str, Any]:
        """Process code content."""
        lines = code.split("\n")

        return {
            "type": "code",
            "language": language,
            "content": code,
            "line_count": len(lines),
            "char_count": len(code),
        }

    async def process_image(self, image_data: bytes) -> Dict[str, Any]:
        """Process image content."""
        # Would use OCR and image understanding
        return {
            "type": "image",
            "size_bytes": len(image_data),
            "content": "Image content placeholder",
            "ocr_text": "",
        }

    async def process_video(self, video_url: str) -> Dict[str, Any]:
        """Process video content."""
        # Would use transcription and scene detection
        return {
            "type": "video",
            "url": video_url,
            "content": "Video content placeholder",
            "transcript": "",
        }

    async def process_document(
        self, document: Document, processor_config: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Process a document based on its type."""
        processor_config = processor_config or {}

        if document.source_type == "code":
            language = document.metadata.get("language", "python")
            return await self.process_code(document.content, language)

        elif document.source_type == "image":
            # Would need actual image data
            return await self.process_image(b"")

        elif document.source_type == "video":
            return await self.process_video(document.url)

        else:  # text/document
            return await self.process_text(document.content)


class IngestionPipeline:
    """Pipeline for ingesting external data into Crazy Memory."""

    def __init__(self, connector: BaseConnector, processor: MultiModalProcessor):
        self.connector = connector
        self.processor = processor
        self.connector_name = connector.get_connector_name()

    async def ingest(self, user_id: str, sync_options: Optional[Dict] = None) -> Dict[str, Any]:
        """Ingest documents from connector into memory system."""
        sync_options = sync_options or {}

        # Fetch documents
        documents = await self.connector.fetch_documents(**sync_options)

        if not documents:
            return {"success": True, "documents_ingested": 0, "memories_created": 0}

        # Process documents
        processed_docs = []
        for doc in documents:
            processed = await self.processor.process_document(doc)
            processed_docs.append({"document": doc, "processed": processed})

        # Convert to memory format
        from crazymemory.models.memory import Memory, MemoryType

        memories = []
        for item in processed_docs:
            doc = item["document"]
            processed = item["processed"]

            memory = Memory(
                content=processed["content"],
                memory_type=MemoryType.SEMANTIC,  # Default to semantic
                user_id=user_id,
                importance=0.6,
                confidence=0.7,
                tags=[doc.source, doc.source_type],
                metadata={
                    "source": doc.source,
                    "source_type": doc.source_type,
                    "source_id": doc.id,
                    "url": doc.url,
                    "processed": processed,
                },
            )
            memories.append(memory)

        return {
            "success": True,
            "connector": self.connector_name,
            "documents_ingested": len(documents),
            "memories_created": len(memories),
            "memories": memories,
        }
