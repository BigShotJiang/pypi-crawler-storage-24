"""Multi-model embedding system."""

from crazymemory.embeddings.embedding import (
    CohereEmbedding,
    EmbeddingConfig,
    EmbeddingProvider,
    MultiModelEmbeddingFusion,
    OpenAIEmbedding,
    SentenceTransformerEmbedding,
    create_embedding_fusion,
)

__all__ = [
    "EmbeddingProvider",
    "OpenAIEmbedding",
    "CohereEmbedding",
    "SentenceTransformerEmbedding",
    "EmbeddingConfig",
    "MultiModelEmbeddingFusion",
    "create_embedding_fusion",
]
