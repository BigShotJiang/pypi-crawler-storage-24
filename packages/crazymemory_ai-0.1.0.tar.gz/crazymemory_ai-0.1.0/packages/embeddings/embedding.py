"""Multi-model embedding system with fusion capabilities."""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple

import numpy as np


class EmbeddingProvider(ABC):
    """Base class for embedding providers."""

    @abstractmethod
    async def embed(self, text: str) -> List[float]:
        """Generate embedding for text."""
        pass

    @abstractmethod
    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts."""
        pass

    @abstractmethod
    def get_dimensions(self) -> int:
        """Get embedding dimensions."""
        pass

    @abstractmethod
    def get_model_name(self) -> str:
        """Get model name."""
        pass


class OpenAIEmbedding(EmbeddingProvider):
    """OpenAI embedding provider."""

    def __init__(self, api_key: str, model: str = "text-embedding-3-small"):
        from openai import AsyncOpenAI

        self.api_key = api_key
        self.model = model
        self.client = AsyncOpenAI(api_key=api_key)

        # Model dimensions
        self._dimensions = {
            "text-embedding-3-small": 1536,
            "text-embedding-3-large": 3072,
            "text-embedding-ada-002": 1536,
        }.get(model, 1536)

    async def embed(self, text: str) -> List[float]:
        """Generate embedding for text."""
        response = await self.client.embeddings.create(model=self.model, input=text)
        return response.data[0].embedding

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts."""
        response = await self.client.embeddings.create(model=self.model, input=texts)
        return [item.embedding for item in response.data]

    def get_dimensions(self) -> int:
        return self._dimensions

    def get_model_name(self) -> str:
        return self.model


class CohereEmbedding(EmbeddingProvider):
    """Cohere embedding provider."""

    def __init__(self, api_key: str, model: str = "embed-english-v3.0"):
        import cohere

        self.api_key = api_key
        self.model = model
        self.client = cohere.AsyncClient(api_key=api_key)

        self._dimensions = 1024  # Cohere embed-v3 has 1024 dimensions

    async def embed(self, text: str) -> List[float]:
        """Generate embedding for text."""
        response = await self.client.embed(
            texts=[text], model=self.model, input_type="search_document"
        )
        return response.embeddings[0]

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts."""
        response = await self.client.embed(
            texts=texts, model=self.model, input_type="search_document"
        )
        return response.embeddings

    def get_dimensions(self) -> int:
        return self._dimensions

    def get_model_name(self) -> str:
        return self.model


class SentenceTransformerEmbedding(EmbeddingProvider):
    """Sentence-Transformers embedding provider (local)."""

    def __init__(self, model: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer

        self.model_name = model
        self.model = SentenceTransformer(model)
        self._dimensions = self.model.get_sentence_embedding_dimension()

    async def embed(self, text: str) -> List[float]:
        """Generate embedding for text."""
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding.tolist()

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts."""
        embeddings = self.model.encode(texts, convert_to_numpy=True)
        return [e.tolist() for e in embeddings]

    def get_dimensions(self) -> int:
        return self._dimensions

    def get_model_name(self) -> str:
        return self.model_name


class EmbeddingConfig:
    """Configuration for embedding providers."""

    def __init__(
        self, provider: str, model: str, api_key: Optional[str] = None, weight: float = 1.0
    ):
        self.provider = provider
        self.model = model
        self.api_key = api_key
        self.weight = weight


class MultiModelEmbeddingFusion:
    """Multi-model embedding fusion system."""

    def __init__(self, configs: Dict[str, EmbeddingConfig]):
        """
        Initialize multi-model embedding system.

        Args:
            configs: Dictionary mapping model names to EmbeddingConfig
        """
        self.configs = configs
        self.providers: Dict[str, EmbeddingProvider] = {}

        # Initialize providers
        for model_name, config in configs.items():
            if config.provider == "openai":
                self.providers[model_name] = OpenAIEmbedding(
                    api_key=config.api_key, model=config.model
                )
            elif config.provider == "cohere":
                self.providers[model_name] = CohereEmbedding(
                    api_key=config.api_key, model=config.model
                )
            elif config.provider == "sentence-transformers":
                self.providers[model_name] = SentenceTransformerEmbedding(model=config.model)
            else:
                raise ValueError(f"Unknown provider: {config.provider}")

    async def generate_embeddings(
        self, text: str, models: Optional[List[str]] = None
    ) -> Dict[str, List[float]]:
        """
        Generate embeddings using multiple models.

        Args:
            text: Text to embed
            models: List of model names to use (default: all)

        Returns:
            Dictionary mapping model names to embeddings
        """
        if models is None:
            models = list(self.providers.keys())

        embeddings = {}
        for model_name in models:
            if model_name in self.providers:
                embedding = await self.providers[model_name].embed(text)
                embeddings[model_name] = embedding

        return embeddings

    async def generate_embeddings_batch(
        self, texts: List[str], models: Optional[List[str]] = None
    ) -> Dict[str, List[List[float]]]:
        """
        Generate embeddings for multiple texts using multiple models.

        Args:
            texts: List of texts to embed
            models: List of model names to use (default: all)

        Returns:
            Dictionary mapping model names to lists of embeddings
        """
        if models is None:
            models = list(self.providers.keys())

        embeddings = {}
        for model_name in models:
            if model_name in self.providers:
                batch_embeddings = await self.providers[model_name].embed_batch(texts)
                embeddings[model_name] = batch_embeddings

        return embeddings

    def fuse_embeddings(
        self, embeddings: Dict[str, List[float]], method: str = "weighted_average"
    ) -> List[float]:
        """
        Fuse multiple embeddings into a single vector.

        Args:
            embeddings: Dictionary mapping model names to embeddings
            method: Fusion method ("weighted_average", "concatenation", "max_pool")

        Returns:
            Fused embedding vector
        """
        if not embeddings:
            raise ValueError("No embeddings to fuse")

        if method == "weighted_average":
            return self._weighted_average_fusion(embeddings)
        elif method == "concatenation":
            return self._concatenation_fusion(embeddings)
        elif method == "max_pool":
            return self._max_pool_fusion(embeddings)
        else:
            raise ValueError(f"Unknown fusion method: {method}")

    def _weighted_average_fusion(self, embeddings: Dict[str, List[float]]) -> List[float]:
        """Fuse embeddings using weighted average."""
        # Normalize all embeddings to unit length
        normalized = {}
        for model_name, embedding in embeddings.items():
            norm = np.linalg.norm(embedding)
            normalized[model_name] = (
                np.array(embedding) / norm if norm > 0 else np.zeros_like(embedding)
            )

        # Calculate weighted average
        weighted_sum = None
        total_weight = 0.0

        for model_name, embedding in normalized.items():
            weight = self.configs[model_name].weight
            if weighted_sum is None:
                weighted_sum = embedding * weight
            else:
                weighted_sum += embedding * weight
            total_weight += weight

        fused = weighted_sum / total_weight if total_weight > 0 else weighted_sum
        return fused.tolist()

    def _concatenation_fusion(self, embeddings: Dict[str, List[float]]) -> List[float]:
        """Fuse embeddings by concatenation."""
        # Normalize first
        normalized = []
        for model_name, embedding in embeddings.items():
            norm = np.linalg.norm(embedding)
            if norm > 0:
                normalized.extend(np.array(embedding) / norm)
            else:
                normalized.extend(embedding)

        return normalized

    def _max_pool_fusion(self, embeddings: Dict[str, List[float]]) -> List[float]:
        """Fuse embeddings using max pooling."""
        # Normalize all embeddings
        normalized = [
            np.array(embedding) / np.linalg.norm(embedding) for embedding in embeddings.values()
        ]

        # Max pooling (element-wise max)
        max_pool = np.maximum.reduce(normalized)
        return max_pool.tolist()

    def calculate_similarity(
        self, embedding1: List[float], embedding2: List[float], method: str = "cosine"
    ) -> float:
        """
        Calculate similarity between two embeddings.

        Args:
            embedding1: First embedding
            embedding2: Second embedding
            method: Similarity method ("cosine", "dot", "euclidean")

        Returns:
            Similarity score
        """
        vec1 = np.array(embedding1)
        vec2 = np.array(embedding2)

        if method == "cosine":
            # Normalize for cosine similarity
            norm1 = np.linalg.norm(vec1)
            norm2 = np.linalg.norm(vec2)

            if norm1 == 0 or norm2 == 0:
                return 0.0

            return float(np.dot(vec1, vec2) / (norm1 * norm2))

        elif method == "dot":
            return float(np.dot(vec1, vec2))

        elif method == "euclidean":
            distance = np.linalg.norm(vec1 - vec2)
            # Convert distance to similarity (1 / (1 + distance))
            return 1.0 / (1.0 + distance)

        else:
            raise ValueError(f"Unknown similarity method: {method}")

    def get_model_info(self) -> Dict[str, Dict]:
        """Get information about all configured models."""
        info = {}
        for model_name, provider in self.providers.items():
            info[model_name] = {
                "provider": self.configs[model_name].provider,
                "model": provider.get_model_name(),
                "dimensions": provider.get_dimensions(),
                "weight": self.configs[model_name].weight,
            }
        return info


def create_embedding_fusion(settings) -> MultiModelEmbeddingFusion:
    """Create multi-model embedding fusion system from settings."""
    configs = {
        "text": EmbeddingConfig(
            provider="openai",
            model=settings.llm_model,
            api_key=settings.get_llm_api_key(),
            weight=0.4,
        ),
        "semantic": EmbeddingConfig(
            provider="openai",
            model="text-embedding-3-small",
            api_key=settings.get_llm_api_key(),
            weight=0.3,
        ),
    }

    # Add Cohere if API key is available
    if settings.cohere_api_key:
        configs["cohere"] = EmbeddingConfig(
            provider="cohere",
            model="embed-english-v3.0",
            api_key=settings.cohere_api_key,
            weight=0.3,
        )

    return MultiModelEmbeddingFusion(configs)
