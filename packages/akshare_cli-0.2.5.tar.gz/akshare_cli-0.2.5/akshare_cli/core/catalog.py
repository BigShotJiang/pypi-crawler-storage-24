#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""目录查询模块 — 基于 catalog.json 提供函数分类浏览。"""

import json
import os
from typing import Dict, List, Optional, Tuple

_catalog = None


def load_catalog() -> dict:
    """加载 catalog.json（模块级缓存）。"""
    global _catalog
    if _catalog is not None:
        return _catalog
    catalog_path = os.path.join(os.path.dirname(__file__), "..", "data", "catalog.json")
    catalog_path = os.path.normpath(catalog_path)
    with open(catalog_path, encoding="utf-8") as f:
        _catalog = json.load(f)
    return _catalog


def _resolve_node(path: str) -> Optional[dict]:
    """根据 '/' 分隔路径定位目录节点，返回 None 表示路径不存在。"""
    catalog = load_catalog()
    node = {"children": catalog["categories"]}
    if not path:
        return node
    parts = [p.strip() for p in path.split("/") if p.strip()]
    for part in parts:
        children = node.get("children", {})
        if part not in children:
            return None
        node = children[part]
    return node


def list_categories(path: str = "") -> List[Tuple[str, int]]:
    """列出子目录及其函数数量。

    返回 [(name, func_count), ...]，按名称排序。
    """
    node = _resolve_node(path)
    if node is None:
        return []
    children = node.get("children", {})
    result = []
    for name, child in children.items():
        count = _count_functions(child)
        result.append((name, count))
    return sorted(result, key=lambda x: x[0])


def _count_functions(node: dict) -> int:
    """递归统计节点下的函数总数。"""
    count = len(node.get("functions", []))
    for child in node.get("children", {}).values():
        count += _count_functions(child)
    return count


def get_functions(path: str) -> List[str]:
    """返回某目录下所有函数（含子目录递归），排序。"""
    node = _resolve_node(path)
    if node is None:
        return []
    funcs = []
    _collect_functions(node, funcs)
    return sorted(funcs)


def _collect_functions(node: dict, result: list):
    """递归收集函数名。"""
    result.extend(node.get("functions", []))
    for child in node.get("children", {}).values():
        _collect_functions(child, result)


def get_function_path(func_name: str) -> Optional[List[str]]:
    """查函数所属目录路径，返回 None 表示未找到。"""
    catalog = load_catalog()
    return catalog["func_to_path"].get(func_name)


def get_direct_functions(path: str) -> List[str]:
    """返回某目录直接包含的函数（不递归子目录）。"""
    node = _resolve_node(path)
    if node is None:
        return []
    return sorted(node.get("functions", []))
