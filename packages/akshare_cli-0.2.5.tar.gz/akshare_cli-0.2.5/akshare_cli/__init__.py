"""AKShare CLI Harness - Sub-package"""

__version__ = "0.2.5"
