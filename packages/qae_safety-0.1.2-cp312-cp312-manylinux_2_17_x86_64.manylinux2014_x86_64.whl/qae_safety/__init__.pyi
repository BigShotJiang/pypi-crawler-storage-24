"""Type stubs for the qae_safety native module (PyO3 bindings).

Provides IDE autocomplete and mypy compatibility for the QAE safety
certification kernel Python bindings.
"""

from typing import Optional

class StateDelta:
    """A single dimension of state change proposed by an action."""

    dimension: str
    from_value: float
    to_value: float

    def __init__(
        self,
        dimension: str,
        from_value: float = 0.0,
        to_value: float = 0.0,
    ) -> None: ...
    def __repr__(self) -> str: ...

class SimpleAction:
    """A simple proposed action for safety certification."""

    action_id: str
    agent_id: str
    state_deltas: list[StateDelta]

    def __init__(
        self,
        action_id: str,
        agent_id: str,
        state_deltas: Optional[list[StateDelta]] = None,
    ) -> None: ...
    def __repr__(self) -> str: ...

class CertifierConfig:
    """Configuration for the safety certifier.

    Controls the margin thresholds that determine zone classification:
    - safe_threshold: margin above which the action is Safe (default 0.6)
    - caution_threshold: margin above which the action is Caution (default 0.3)
    - block_threshold: margin at or below which the action is Blocked (default 0.1)
    """

    safe_threshold: float
    caution_threshold: float
    block_threshold: float
    warning_margin_threshold: float

    def __init__(
        self,
        safe_threshold: float = 0.6,
        caution_threshold: float = 0.3,
        block_threshold: float = 0.1,
        warning_margin_threshold: float = 0.5,
    ) -> None: ...
    def __repr__(self) -> str: ...

class SafetyCertificate:
    """Python-visible safety certificate returned by the certifier."""

    certificate_id: str
    action_id: str
    agent_id: str
    decision: str
    zone: str
    margins: dict[str, float]
    binding_constraint: Optional[str]
    drift_budget: Optional[float]
    deterministic_hash: str

    def __repr__(self) -> str: ...
    def to_json(self) -> str:
        """Serialize the certificate to a pretty-printed JSON string."""
        ...

class ConstraintChannel:
    """Base class for constraint channels.

    Subclass this to create custom constraint channels::

        class MyChannel(ConstraintChannel):
            def name(self) -> str:
                return "my_channel"
            def evaluate(self, state: list[float]) -> float:
                return 0.8  # margin in [0, 1]
            def dimension_names(self) -> list[str]:
                return ["dim1"]
    """

    def __init__(self) -> None: ...
    def name(self) -> str:
        """Human-readable name of this constraint channel."""
        ...
    def evaluate(self, state: list[float]) -> float:
        """Evaluate this constraint against the state vector.

        Must return a margin in [0, 1].
        """
        ...
    def dimension_names(self) -> list[str]:
        """Names of state dimensions this channel operates on."""
        ...

class DomainAdapter:
    """Base class for domain adapters.

    Subclass this to create custom domain adapters that plug domain-specific
    logic into the safety certification kernel::

        class MyAdapter(DomainAdapter):
            def domain_name(self) -> str:
                return "my_domain"
            def constraint_channels(self) -> list[ConstraintChannel]:
                return [MyChannel()]
            def map_action_to_state(self, action: SimpleAction) -> list[float]:
                return [1.0]
            def detect_regime_change(
                self, current: list[float], proposed: list[float]
            ) -> bool:
                return False
    """

    def __init__(self) -> None: ...
    def domain_name(self) -> str:
        """Name of the domain (e.g., 'finance', 'agentic', 'robotics')."""
        ...
    def constraint_channels(self) -> list[ConstraintChannel]:
        """Provide the constraint channels for this domain."""
        ...
    def map_action_to_state(self, action: SimpleAction) -> list[float]:
        """Map a proposed action's state deltas into a state vector."""
        ...
    def detect_regime_change(
        self, current: list[float], proposed: list[float]
    ) -> bool:
        """Detect whether the proposed state change represents a regime change."""
        ...

class AgenticAdapter:
    """Built-in agentic domain adapter.

    A convenience wrapper pre-configured with budget and rate constraint
    channels for AI agent safety certification.
    """

    def __init__(
        self, budget_limit: float = 100.0, rate_limit: float = 50.0
    ) -> None: ...
    def record_spend(self, amount: float) -> None:
        """Record spending against the budget."""
        ...
    def record_action(self) -> None:
        """Record an action against the rate limit."""
        ...
    def reset_rate_window(self) -> None:
        """Reset the rate window counter."""
        ...
    def budget_utilization(self) -> float:
        """Get current budget utilization (0.0 to 1.0)."""
        ...

class SafetyCertifier:
    """A stateful safety certifier that holds a domain adapter and configuration.

    Create once, then call ``certify()`` repeatedly::

        adapter = AgenticAdapter(budget_limit=100.0, rate_limit=50.0)
        certifier = SafetyCertifier(adapter)

        action = SimpleAction("act-1", "agent-1", [StateDelta("budget", 0.0, 50.0)])
        cert = certifier.certify(action)
        print(cert.decision)
    """

    config: CertifierConfig

    def __init__(
        self,
        adapter: "AgenticAdapter | DomainAdapter",
        config: Optional[CertifierConfig] = None,
    ) -> None: ...
    def certify(self, action: SimpleAction) -> SafetyCertificate:
        """Certify a proposed action.

        Args:
            action: A SimpleAction instance describing the proposed action.

        Returns:
            SafetyCertificate with the certification decision.
        """
        ...
    def __repr__(self) -> str: ...

def certify_action(
    adapter: "AgenticAdapter | DomainAdapter",
    action_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    deltas: Optional[dict[str, float]] = None,
    action: Optional[SimpleAction] = None,
    config: Optional[CertifierConfig] = None,
    safe_threshold: float = 0.6,
    caution_threshold: float = 0.3,
    block_threshold: float = 0.1,
) -> SafetyCertificate:
    """Certify an action using a domain adapter.

    The adapter can be either:
    - An AgenticAdapter (convenience wrapper)
    - A custom DomainAdapter subclass

    When using AgenticAdapter, pass deltas as a dict of dimension_name -> to_value.
    When using a custom DomainAdapter, pass a SimpleAction directly via the
    ``action`` parameter.

    Args:
        adapter: AgenticAdapter or DomainAdapter subclass instance.
        action_id: Unique action identifier (used with AgenticAdapter).
        agent_id: Agent identifier (used with AgenticAdapter).
        deltas: Dict of dimension_name -> to_value (used with AgenticAdapter).
        action: SimpleAction instance (used with custom DomainAdapter).
        config: CertifierConfig instance (optional, uses defaults if not provided).
        safe_threshold: Margin threshold for Safe zone (default 0.6, ignored if config set).
        caution_threshold: Margin threshold for Caution zone (default 0.3, ignored if config set).
        block_threshold: Margin threshold for Blocked (default 0.1, ignored if config set).

    Returns:
        SafetyCertificate with the certification decision.
    """
    ...
