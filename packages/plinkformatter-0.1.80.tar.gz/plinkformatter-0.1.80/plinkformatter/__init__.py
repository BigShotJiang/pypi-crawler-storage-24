__version__ = "0.1.2"

from .generate_pheno_plink_fast import run_prepare_pylmm_inputs

__all__ = ["__version__", "run_prepare_pylmm_inputs"]
