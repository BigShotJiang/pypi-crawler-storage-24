"""
Tests pour Tenxyte.
"""
