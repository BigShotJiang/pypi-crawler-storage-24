# drug-interaction-mcp

[![CI](https://github.com/pillright/drug-interaction-mcp/actions/workflows/ci.yml/badge.svg)](https://github.com/pillright/drug-interaction-mcp/actions/workflows/ci.yml)
[![PyPI](https://img.shields.io/pypi/v/drug-interaction-mcp)](https://pypi.org/project/drug-interaction-mcp/)
[![Python](https://img.shields.io/pypi/pyversions/drug-interaction-mcp)](https://pypi.org/project/drug-interaction-mcp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub stars](https://img.shields.io/github/stars/pillright/drug-interaction-mcp)](https://github.com/pillright/drug-interaction-mcp/stargazers)

**An MCP server that lets AI assistants check drug interactions against a clinically sourced database of 150+ interactions.**

## Why?

AI assistants frequently give incorrect or incomplete drug interaction advice. When someone asks "Can I take ibuprofen with warfarin?", the answer matters — it could prevent a serious bleeding event.

This MCP server gives AI assistants (Claude, ChatGPT, etc.) access to a curated, evidence-based drug interaction database sourced from FDA drug labels, NIH DailyMed, and established medical literature. Instead of guessing, the AI can query real data.

## Quick Start

### Install

```bash
pip install drug-interaction-mcp
```

Or run directly with `uvx`:

```bash
uvx drug-interaction-mcp
```

### Configure in Claude Desktop

Add to your Claude Desktop configuration file (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "drug-interactions": {
      "command": "uvx",
      "args": ["drug-interaction-mcp"]
    }
  }
}
```

That's it. Claude will now have access to drug interaction checking tools.

## Tools

### `check_interaction`

Check if there is a known interaction between two drugs.

```
check_interaction(drug_a="warfarin", drug_b="aspirin")
```

Returns severity, clinical description, mechanism of action, recommendation, and source.

**Example response:**
```json
{
  "drug_a": "warfarin",
  "drug_b": "aspirin",
  "found": true,
  "severity": "danger",
  "description": "Significantly increased risk of major bleeding events...",
  "mechanism": "Aspirin inhibits platelet aggregation via COX-1 while warfarin inhibits vitamin K-dependent clotting factors...",
  "recommendation": "Avoid combination unless specifically directed by a physician...",
  "source": "FDA Drug Label — Warfarin"
}
```

### `check_multiple`

Check all pairwise interactions among a list of drugs. Useful when reviewing a patient's full medication list.

```
check_multiple(drugs=["warfarin", "aspirin", "lisinopril", "metformin"])
```

Returns all found interactions sorted by severity (danger first), with a summary of counts.

### `search_drug`

Fuzzy search for drug names in the database. Handles partial names, typos, and brand/generic name lookups.

```
search_drug(query="prozac")
search_drug(query="warfa")
```

### `get_drug_info`

Get all known interactions for a specific drug.

```
get_drug_info(drug_name="warfarin")
```

Returns the drug name, total interaction count, and full details on every known interaction.

### `list_interactions`

List all interactions in the database, optionally filtered by severity.

```
list_interactions(severity="danger")
list_interactions(severity="all")
```

Severity levels: `"danger"`, `"warning"`, `"caution"`, `"all"`.

## Database Coverage

The embedded database includes 150+ clinically documented interactions covering:

- **Blood thinners** — warfarin, apixaban, rivaroxaban, clopidogrel + various interacting drugs
- **Cardiac drugs** — digoxin, amiodarone, beta blockers, calcium channel blockers, statins, nitrates
- **Psychiatric drugs** — SSRIs, SNRIs, MAOIs, antipsychotics, benzodiazepines, mood stabilizers
- **Antibiotics** — fluoroquinolones, macrolides, tetracyclines, metronidazole, rifampin, linezolid
- **Diabetes drugs** — metformin, insulin, sulfonylureas, SGLT2 inhibitors
- **Pain medications** — opioids, NSAIDs, acetaminophen, tramadol
- **Supplements** — St. John's Wort, ginkgo, ginseng, fish oil, iron, calcium, vitamin K/D/E, CoQ10, turmeric
- **OTC drugs** — antacids, PPIs, diphenhydramine, dextromethorphan

Each interaction includes:
- Drug name pairs (generic + brand names)
- Severity level (danger / warning / caution)
- Clinical description
- Mechanism of action
- Patient-facing recommendation
- Evidence source (FDA, NIH, etc.)

## Data Sources

- [FDA Drug Labels](https://labels.fda.gov/) — Official prescribing information
- [NIH DailyMed](https://dailymed.nlm.nih.gov/) — National Library of Medicine drug information
- [FDA Drug Safety Communications](https://www.fda.gov/drugs/drug-safety-and-availability) — Safety alerts
- [NIH Office of Dietary Supplements](https://ods.od.nih.gov/) — Supplement interaction data

## Disclaimer

**This tool is for informational and educational purposes only.** It is not a substitute for professional medical advice, diagnosis, or treatment. Always consult a qualified healthcare provider (physician, pharmacist) before making medication decisions. The database may not include all known interactions, and individual patient factors affect interaction risk.

## Development

```bash
# Clone the repository
git clone https://github.com/pillright/drug-interaction-mcp.git
cd drug-interaction-mcp

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest -v

# Run the server locally
python -m drug_interaction_mcp.server
```

## Contributing

Contributions are welcome. To add new interactions:

1. Fork the repository
2. Add interactions to `src/drug_interaction_mcp/interactions.py`
3. Ensure each interaction has: drug names, severity, description, mechanism, recommendation, and a credible source
4. Add tests for new interactions
5. Open a pull request

All interaction data must be sourced from FDA drug labels, NIH, or peer-reviewed medical literature.

## License

[MIT](LICENSE)
