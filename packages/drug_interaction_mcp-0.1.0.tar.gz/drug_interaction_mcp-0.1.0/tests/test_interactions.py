"""Tests for the drug interaction database."""

from drug_interaction_mcp.interactions import INTERACTIONS, get_all_drug_names
from drug_interaction_mcp.models import Interaction, Severity


class TestInteractionDatabase:
    """Tests for the interaction database integrity."""

    def test_minimum_interaction_count(self):
        """Database should contain at least 150 interactions."""
        assert len(INTERACTIONS) >= 150

    def test_all_interactions_are_interaction_type(self):
        """Every entry should be an Interaction dataclass."""
        for interaction in INTERACTIONS:
            assert isinstance(interaction, Interaction)

    def test_all_interactions_have_required_fields(self):
        """Every interaction must have all fields populated."""
        for i, interaction in enumerate(INTERACTIONS):
            assert len(interaction.drug_a) > 0, f"Interaction {i}: drug_a is empty"
            assert len(interaction.drug_b) > 0, f"Interaction {i}: drug_b is empty"
            assert interaction.description, f"Interaction {i}: description is empty"
            assert interaction.mechanism, f"Interaction {i}: mechanism is empty"
            assert interaction.recommendation, f"Interaction {i}: recommendation is empty"
            assert interaction.source, f"Interaction {i}: source is empty"
            assert isinstance(interaction.severity, Severity)

    def test_severity_distribution(self):
        """Should have interactions across all severity levels."""
        severities = {i.severity for i in INTERACTIONS}
        assert Severity.DANGER in severities
        assert Severity.WARNING in severities
        assert Severity.CAUTION in severities

    def test_drug_names_are_lowercase(self):
        """All drug names in the database should be lowercase."""
        for interaction in INTERACTIONS:
            for name in interaction.drug_a:
                assert name == name.lower(), f"Drug name not lowercase: {name}"
            for name in interaction.drug_b:
                assert name == name.lower(), f"Drug name not lowercase: {name}"

    def test_no_empty_drug_names(self):
        """No drug name should be empty or whitespace-only."""
        for interaction in INTERACTIONS:
            for name in interaction.drug_a + interaction.drug_b:
                assert name.strip(), "Found empty drug name"

    def test_get_all_drug_names(self):
        """get_all_drug_names should return a non-empty dict."""
        drug_map = get_all_drug_names()
        assert len(drug_map) > 50  # Should have many unique drug names
        # Each entry should be a list
        for name, aliases in drug_map.items():
            assert isinstance(name, str)
            assert isinstance(aliases, list)

    def test_well_known_interactions_present(self):
        """Key well-known interactions should exist in the database."""
        # Warfarin + aspirin
        found_warfarin_aspirin = any(
            i.matches_pair("warfarin", "aspirin") for i in INTERACTIONS
        )
        assert found_warfarin_aspirin, "Missing warfarin + aspirin interaction"

        # SSRI + MAOI
        found_ssri_maoi = any(
            i.matches_pair("fluoxetine", "phenelzine") for i in INTERACTIONS
        )
        assert found_ssri_maoi, "Missing SSRI + MAOI interaction"

        # Nitrates + sildenafil
        found_nitrate_viagra = any(
            i.matches_pair("nitroglycerin", "sildenafil") for i in INTERACTIONS
        )
        assert found_nitrate_viagra, "Missing nitrate + sildenafil interaction"

    def test_interaction_involves(self):
        """Interaction.involves should correctly identify drugs."""
        interaction = INTERACTIONS[0]  # warfarin + aspirin
        assert interaction.involves("warfarin")
        assert interaction.involves("WARFARIN")
        assert interaction.involves(" warfarin ")

    def test_interaction_matches_pair(self):
        """Interaction.matches_pair should work bidirectionally."""
        interaction = INTERACTIONS[0]
        drug_a_name = interaction.drug_a[0]
        drug_b_name = interaction.drug_b[0]
        assert interaction.matches_pair(drug_a_name, drug_b_name)
        assert interaction.matches_pair(drug_b_name, drug_a_name)

    def test_interaction_to_dict(self):
        """Interaction.to_dict should return complete dict."""
        interaction = INTERACTIONS[0]
        d = interaction.to_dict()
        assert "drug_a" in d
        assert "drug_b" in d
        assert "severity" in d
        assert "description" in d
        assert "mechanism" in d
        assert "recommendation" in d
        assert "source" in d
        assert isinstance(d["drug_a"], list)
        assert isinstance(d["drug_b"], list)
