"""Tests for the MCP server tool functions."""

from drug_interaction_mcp.server import (
    check_interaction,
    check_multiple,
    get_drug_info,
    list_interactions,
    search_drug,
)


class TestCheckInteractionTool:
    """Tests for the check_interaction MCP tool."""

    def test_known_pair(self):
        result = check_interaction("warfarin", "aspirin")
        assert result["found"] is True
        assert result["severity"] == "danger"
        assert "description" in result
        assert "mechanism" in result
        assert "recommendation" in result
        assert "source" in result
        assert "disclaimer" in result

    def test_unknown_pair(self):
        result = check_interaction("vitamin c", "zinc")
        assert result["found"] is False
        assert "disclaimer" in result

    def test_brand_names(self):
        result = check_interaction("coumadin", "advil")
        assert result["found"] is True

    def test_reverse_order(self):
        result = check_interaction("aspirin", "warfarin")
        assert result["found"] is True


class TestCheckMultipleTool:
    """Tests for the check_multiple MCP tool."""

    def test_multiple_drugs_with_interactions(self):
        result = check_multiple(["warfarin", "aspirin", "ibuprofen"])
        assert result["drugs_checked"] == ["warfarin", "aspirin", "ibuprofen"]
        assert result["total_pairs_checked"] == 3
        assert result["interactions_found"] > 0
        assert "summary" in result
        assert "interactions" in result
        assert "disclaimer" in result

    def test_summary_counts(self):
        result = check_multiple(["warfarin", "aspirin", "fish oil"])
        summary = result["summary"]
        assert "danger" in summary
        assert "warning" in summary
        assert "caution" in summary
        total = summary["danger"] + summary["warning"] + summary["caution"]
        assert total == result["interactions_found"]

    def test_no_interactions(self):
        result = check_multiple(["vitamin c", "zinc"])
        assert result["interactions_found"] == 0

    def test_single_drug(self):
        result = check_multiple(["warfarin"])
        assert result["total_pairs_checked"] == 0


class TestSearchDrugTool:
    """Tests for the search_drug MCP tool."""

    def test_search_found(self):
        result = search_drug("warfarin")
        assert result["query"] == "warfarin"
        assert result["total_results"] > 0
        assert len(result["results"]) > 0

    def test_search_partial(self):
        result = search_drug("prozac")
        assert result["total_results"] > 0

    def test_search_limit(self):
        result = search_drug("a", limit=3)
        assert result["total_results"] <= 3

    def test_search_empty(self):
        result = search_drug("")
        assert result["total_results"] == 0


class TestGetDrugInfoTool:
    """Tests for the get_drug_info MCP tool."""

    def test_known_drug(self):
        result = get_drug_info("warfarin")
        assert result["name"] == "warfarin"
        assert result["interaction_count"] > 5
        assert len(result["interactions"]) == result["interaction_count"]
        assert "disclaimer" in result

    def test_unknown_drug(self):
        result = get_drug_info("xyznonexistent")
        assert result["interaction_count"] == 0


class TestListInteractionsTool:
    """Tests for the list_interactions MCP tool."""

    def test_list_all(self):
        result = list_interactions("all")
        assert result["severity_filter"] == "all"
        assert result["total"] >= 150
        assert "disclaimer" in result

    def test_list_danger(self):
        result = list_interactions("danger")
        assert result["severity_filter"] == "danger"
        assert result["total"] > 0
        for i in result["interactions"]:
            assert i["severity"] == "danger"

    def test_list_default(self):
        result = list_interactions()
        assert result["severity_filter"] == "all"
