"""Tests for drug search and matching logic."""

from drug_interaction_mcp.models import Severity
from drug_interaction_mcp.search import (
    check_interaction,
    check_multiple_drugs,
    get_drug_info,
    list_interactions_by_severity,
    search_drug_names,
)


class TestSearchDrugNames:
    """Tests for fuzzy drug name search."""

    def test_exact_match(self):
        """Exact drug name should return score 1.0."""
        results = search_drug_names("warfarin")
        assert len(results) > 0
        assert results[0].name == "warfarin"
        assert results[0].score == 1.0

    def test_case_insensitive(self):
        """Search should be case-insensitive."""
        results = search_drug_names("WARFARIN")
        assert len(results) > 0
        assert results[0].name == "warfarin"
        assert results[0].score == 1.0

    def test_partial_match(self):
        """Partial drug name should find matches."""
        results = search_drug_names("warfa")
        assert len(results) > 0
        assert any(r.name == "warfarin" for r in results)

    def test_brand_name(self):
        """Brand names should be searchable."""
        results = search_drug_names("coumadin")
        assert len(results) > 0
        assert results[0].name == "coumadin"

    def test_limit_results(self):
        """Should respect the limit parameter."""
        results = search_drug_names("a", limit=3)
        assert len(results) <= 3

    def test_empty_query(self):
        """Empty query should return empty results."""
        results = search_drug_names("")
        assert results == []

    def test_whitespace_query(self):
        """Whitespace-only query should return empty results."""
        results = search_drug_names("   ")
        assert results == []

    def test_no_match(self):
        """Completely unrelated query should return no results."""
        results = search_drug_names("xyznonexistent12345")
        assert len(results) == 0

    def test_search_result_has_aliases(self):
        """Search results should include aliases."""
        results = search_drug_names("warfarin")
        warfarin = next((r for r in results if r.name == "warfarin"), None)
        assert warfarin is not None
        assert isinstance(warfarin.aliases, list)

    def test_search_result_to_dict(self):
        """SearchResult.to_dict should contain required fields."""
        results = search_drug_names("aspirin")
        assert len(results) > 0
        d = results[0].to_dict()
        assert "name" in d
        assert "score" in d
        assert "aliases" in d


class TestCheckInteraction:
    """Tests for pair-wise interaction checking."""

    def test_known_interaction(self):
        """Known interaction should be found."""
        result = check_interaction("warfarin", "aspirin")
        assert result.found is True
        assert result.interaction is not None
        assert result.interaction.severity == Severity.DANGER

    def test_known_interaction_reverse(self):
        """Interaction should be found regardless of order."""
        result = check_interaction("aspirin", "warfarin")
        assert result.found is True

    def test_brand_name_interaction(self):
        """Should find interaction using brand names."""
        result = check_interaction("coumadin", "advil")
        assert result.found is True

    def test_unknown_interaction(self):
        """Unknown pair should return found=False."""
        result = check_interaction("acetaminophen", "metformin")
        assert result.found is False
        assert result.interaction is None

    def test_case_insensitive(self):
        """Interaction check should be case-insensitive."""
        result = check_interaction("WARFARIN", "Aspirin")
        assert result.found is True

    def test_result_to_dict_found(self):
        """InteractionResult.to_dict for found interaction."""
        result = check_interaction("warfarin", "aspirin")
        d = result.to_dict()
        assert d["found"] is True
        assert "severity" in d
        assert "description" in d
        assert "mechanism" in d
        assert "recommendation" in d
        assert "source" in d

    def test_result_to_dict_not_found(self):
        """InteractionResult.to_dict for unknown interaction."""
        result = check_interaction("water", "air")
        d = result.to_dict()
        assert d["found"] is False
        assert "severity" not in d

    def test_ssri_maoi_danger(self):
        """SSRI + MAOI should be classified as danger."""
        result = check_interaction("fluoxetine", "phenelzine")
        assert result.found is True
        assert result.interaction is not None
        assert result.interaction.severity == Severity.DANGER

    def test_statin_grapefruit(self):
        """Statin + grapefruit should be found."""
        result = check_interaction("simvastatin", "grapefruit")
        assert result.found is True


class TestCheckMultipleDrugs:
    """Tests for multiple drug interaction checking."""

    def test_multiple_with_interactions(self):
        """Should find interactions among multiple drugs."""
        results = check_multiple_drugs(["warfarin", "aspirin", "ibuprofen"])
        assert len(results) > 0

    def test_multiple_no_interactions(self):
        """Drugs with no known interactions should return empty."""
        results = check_multiple_drugs(["vitamin c", "zinc"])
        assert len(results) == 0

    def test_single_drug(self):
        """Single drug should produce no pairs to check."""
        results = check_multiple_drugs(["warfarin"])
        assert len(results) == 0

    def test_empty_list(self):
        """Empty list should return empty results."""
        results = check_multiple_drugs([])
        assert len(results) == 0

    def test_results_sorted_by_severity(self):
        """Results should be sorted danger > warning > caution."""
        results = check_multiple_drugs(
            ["warfarin", "aspirin", "grapefruit", "simvastatin", "fish oil"]
        )
        if len(results) >= 2:
            severity_order = {"danger": 0, "warning": 1, "caution": 2}
            for i in range(len(results) - 1):
                sev_a = results[i].interaction.severity.value if results[i].interaction else "caution"
                sev_b = results[i + 1].interaction.severity.value if results[i + 1].interaction else "caution"
                assert severity_order[sev_a] <= severity_order[sev_b]

    def test_multiple_result_to_dict(self):
        """Each result in multiple check should serialize properly."""
        results = check_multiple_drugs(["warfarin", "aspirin"])
        for r in results:
            d = r.to_dict()
            assert "drug_a" in d
            assert "drug_b" in d
            assert "found" in d


class TestGetDrugInfo:
    """Tests for drug info retrieval."""

    def test_known_drug(self):
        """Known drug should return interactions."""
        info = get_drug_info("warfarin")
        assert info.name == "warfarin"
        assert len(info.interactions) > 5  # Warfarin has many interactions

    def test_unknown_drug(self):
        """Unknown drug should return zero interactions."""
        info = get_drug_info("xyznonexistent")
        assert info.name == "xyznonexistent"
        assert len(info.interactions) == 0

    def test_case_insensitive(self):
        """Should work with different casing."""
        info = get_drug_info("WARFARIN")
        assert len(info.interactions) > 0

    def test_drug_info_to_dict(self):
        """DrugInfo.to_dict should have required fields."""
        info = get_drug_info("warfarin")
        d = info.to_dict()
        assert "name" in d
        assert "interaction_count" in d
        assert "interactions" in d
        assert d["interaction_count"] == len(d["interactions"])

    def test_brand_name_lookup(self):
        """Should find interactions for brand names."""
        info = get_drug_info("prozac")
        assert len(info.interactions) > 0


class TestListInteractions:
    """Tests for listing interactions by severity."""

    def test_list_all(self):
        """Listing all should return all interactions."""
        results = list_interactions_by_severity("all")
        assert len(results) >= 150

    def test_filter_danger(self):
        """Filtering by danger should return only danger-level interactions."""
        results = list_interactions_by_severity("danger")
        assert len(results) > 0
        assert all(i.severity == Severity.DANGER for i in results)

    def test_filter_warning(self):
        """Filtering by warning should return only warning-level interactions."""
        results = list_interactions_by_severity("warning")
        assert len(results) > 0
        assert all(i.severity == Severity.WARNING for i in results)

    def test_filter_caution(self):
        """Filtering by caution should return only caution-level interactions."""
        results = list_interactions_by_severity("caution")
        assert len(results) > 0
        assert all(i.severity == Severity.CAUTION for i in results)

    def test_invalid_severity_returns_all(self):
        """Invalid severity filter should return all interactions."""
        results = list_interactions_by_severity("invalid")
        assert len(results) == len(list_interactions_by_severity("all"))
