"""Drug Interaction MCP Server — query drug interactions from AI assistants."""

__version__ = "0.1.0"
