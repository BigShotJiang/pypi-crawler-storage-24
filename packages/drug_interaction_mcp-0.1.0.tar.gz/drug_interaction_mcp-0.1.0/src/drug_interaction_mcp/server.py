"""Main MCP server for drug interaction checking."""

from __future__ import annotations

from fastmcp import FastMCP

from drug_interaction_mcp.search import (
    check_interaction as _check_interaction,
    check_multiple_drugs,
    get_drug_info as _get_drug_info,
    list_interactions_by_severity,
    search_drug_names,
)

mcp = FastMCP(
    "Drug Interaction Checker",
    instructions=(
        "Query a comprehensive database of 150+ clinically documented drug interactions. "
        "Check drug pairs, search for drugs by name, and get safety information. "
        "Sources: FDA drug labels, NIH DailyMed, established medical literature. "
        "DISCLAIMER: Not a substitute for professional medical advice."
    ),
)


@mcp.tool()
def check_interaction(drug_a: str, drug_b: str) -> dict:
    """Check if there is a known interaction between two drugs.

    Args:
        drug_a: First drug name (generic or brand name, e.g. "warfarin" or "coumadin").
        drug_b: Second drug name (generic or brand name, e.g. "aspirin" or "ibuprofen").

    Returns:
        Interaction details if found, including severity, description, mechanism,
        recommendation, and source. Returns found=False if no interaction is known.
    """
    result = _check_interaction(drug_a, drug_b)
    response = result.to_dict()
    response["disclaimer"] = (
        "This information is for educational purposes only and is not a substitute "
        "for professional medical advice. Always consult a healthcare provider."
    )
    return response


@mcp.tool()
def check_multiple(drugs: list[str]) -> dict:
    """Check all pairwise interactions among a list of drugs.

    Useful when a patient takes multiple medications and you need to check
    all possible interactions at once.

    Args:
        drugs: List of drug names to check (e.g. ["warfarin", "aspirin", "lisinopril"]).

    Returns:
        All found interactions sorted by severity (danger first),
        plus a summary with total counts by severity level.
    """
    results = check_multiple_drugs(drugs)
    interactions = [r.to_dict() for r in results]

    danger_count = sum(1 for r in results if r.interaction and r.interaction.severity.value == "danger")
    warning_count = sum(1 for r in results if r.interaction and r.interaction.severity.value == "warning")
    caution_count = sum(1 for r in results if r.interaction and r.interaction.severity.value == "caution")

    return {
        "drugs_checked": drugs,
        "total_pairs_checked": len(drugs) * (len(drugs) - 1) // 2,
        "interactions_found": len(interactions),
        "summary": {
            "danger": danger_count,
            "warning": warning_count,
            "caution": caution_count,
        },
        "interactions": interactions,
        "disclaimer": (
            "This information is for educational purposes only and is not a substitute "
            "for professional medical advice. Always consult a healthcare provider."
        ),
    }


@mcp.tool()
def search_drug(query: str, limit: int = 10) -> dict:
    """Search for drug names in the interaction database using fuzzy matching.

    Useful when you're unsure of the exact drug name spelling or want to find
    brand/generic name equivalents.

    Args:
        query: Search query — drug name or partial name (e.g. "warfa", "prozac").
        limit: Maximum number of results (default 10).

    Returns:
        List of matching drug names with relevance scores and known aliases.
    """
    results = search_drug_names(query, limit=limit)
    return {
        "query": query,
        "results": [r.to_dict() for r in results],
        "total_results": len(results),
    }


@mcp.tool()
def get_drug_info(drug_name: str) -> dict:
    """Get detailed information about a drug and all its known interactions.

    Args:
        drug_name: Name of the drug (generic or brand name, e.g. "warfarin").

    Returns:
        Drug information including all known interactions, each with severity,
        description, mechanism, recommendation, and source.
    """
    info = _get_drug_info(drug_name)
    response = info.to_dict()
    response["disclaimer"] = (
        "This information is for educational purposes only and is not a substitute "
        "for professional medical advice. Always consult a healthcare provider."
    )
    return response


@mcp.tool()
def list_interactions(severity: str = "all") -> dict:
    """List all known drug interactions, optionally filtered by severity.

    Args:
        severity: Filter level — "danger", "warning", "caution", or "all" (default).

    Returns:
        List of all matching interactions with full details.
    """
    results = list_interactions_by_severity(severity)
    return {
        "severity_filter": severity,
        "total": len(results),
        "interactions": [i.to_dict() for i in results],
        "disclaimer": (
            "This information is for educational purposes only and is not a substitute "
            "for professional medical advice. Always consult a healthcare provider."
        ),
    }


def main() -> None:
    """Entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
