"""Drug search and matching logic with fuzzy matching."""

from __future__ import annotations

from drug_interaction_mcp.interactions import INTERACTIONS, get_all_drug_names
from drug_interaction_mcp.models import (
    DrugInfo,
    Interaction,
    InteractionResult,
    SearchResult,
    Severity,
)


def _normalize(name: str) -> str:
    """Lowercase and strip whitespace from a drug name."""
    return name.lower().strip()


def _levenshtein(s: str, t: str) -> int:
    """Compute Levenshtein edit distance between two strings."""
    if len(s) < len(t):
        return _levenshtein(t, s)
    if len(t) == 0:
        return len(s)
    prev = list(range(len(t) + 1))
    for i, sc in enumerate(s):
        curr = [i + 1]
        for j, tc in enumerate(t):
            cost = 0 if sc == tc else 1
            curr.append(min(curr[j] + 1, prev[j + 1] + 1, prev[j] + cost))
        prev = curr
    return prev[len(t)]


def _similarity(a: str, b: str) -> float:
    """Return a 0-1 similarity score between two strings.

    Combines substring matching with Levenshtein distance.
    """
    a, b = _normalize(a), _normalize(b)
    if a == b:
        return 1.0
    # Substring match gets a high score
    if a in b or b in a:
        return 0.9
    # Prefix match
    common_prefix = 0
    for ca, cb in zip(a, b):
        if ca == cb:
            common_prefix += 1
        else:
            break
    prefix_score = common_prefix / max(len(a), len(b))
    # Levenshtein-based score
    dist = _levenshtein(a, b)
    max_len = max(len(a), len(b))
    lev_score = 1.0 - (dist / max_len)
    return max(prefix_score, lev_score)


def search_drug_names(query: str, limit: int = 10) -> list[SearchResult]:
    """Fuzzy search for drug names in the interaction database.

    Args:
        query: Search query (drug name or partial name).
        limit: Maximum number of results to return.

    Returns:
        List of SearchResult sorted by relevance score.
    """
    query_norm = _normalize(query)
    if not query_norm:
        return []

    drug_map = get_all_drug_names()
    scored: list[SearchResult] = []

    for name, aliases in drug_map.items():
        score = _similarity(query_norm, name)
        if score >= 0.4:
            scored.append(SearchResult(name=name, score=round(score, 3), aliases=aliases))

    # Sort by score descending, then name alphabetically
    scored.sort(key=lambda r: (-r.score, r.name))
    return scored[:limit]


def check_interaction(drug_a: str, drug_b: str) -> InteractionResult:
    """Check if there is a known interaction between two drugs.

    Args:
        drug_a: First drug name.
        drug_b: Second drug name.

    Returns:
        InteractionResult with match information.
    """
    a = _normalize(drug_a)
    b = _normalize(drug_b)

    for interaction in INTERACTIONS:
        if interaction.matches_pair(a, b):
            return InteractionResult(
                drug_a=drug_a,
                drug_b=drug_b,
                found=True,
                interaction=interaction,
            )

    return InteractionResult(drug_a=drug_a, drug_b=drug_b, found=False)


def check_multiple_drugs(drugs: list[str]) -> list[InteractionResult]:
    """Check all pairwise interactions among a list of drugs.

    Args:
        drugs: List of drug names.

    Returns:
        List of InteractionResult for all pairs that have known interactions.
    """
    results: list[InteractionResult] = []
    normalized = [_normalize(d) for d in drugs]

    for i in range(len(normalized)):
        for j in range(i + 1, len(normalized)):
            result = check_interaction(drugs[i], drugs[j])
            if result.found:
                results.append(result)

    # Sort by severity: danger first, then warning, then caution
    severity_order = {Severity.DANGER: 0, Severity.WARNING: 1, Severity.CAUTION: 2}
    results.sort(
        key=lambda r: severity_order.get(
            r.interaction.severity if r.interaction else Severity.CAUTION, 3
        )
    )
    return results


def get_drug_info(drug_name: str) -> DrugInfo:
    """Get information about a drug and all its known interactions.

    Args:
        drug_name: Name of the drug to look up.

    Returns:
        DrugInfo with all known interactions involving this drug.
    """
    name = _normalize(drug_name)
    interactions: list[Interaction] = []

    for interaction in INTERACTIONS:
        if interaction.involves(name):
            interactions.append(interaction)

    return DrugInfo(name=drug_name, interactions=interactions)


def list_interactions_by_severity(
    severity: str = "all",
) -> list[Interaction]:
    """List all interactions, optionally filtered by severity.

    Args:
        severity: Filter by severity level ("danger", "warning", "caution", "all").

    Returns:
        List of matching interactions.
    """
    if severity == "all":
        return list(INTERACTIONS)

    try:
        sev = Severity(severity.lower())
    except ValueError:
        return list(INTERACTIONS)

    return [i for i in INTERACTIONS if i.severity == sev]
