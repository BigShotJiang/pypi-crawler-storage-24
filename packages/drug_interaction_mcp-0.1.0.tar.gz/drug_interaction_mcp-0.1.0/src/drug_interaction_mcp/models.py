"""Data models for drug interactions."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Severity(str, Enum):
    """Interaction severity levels."""

    DANGER = "danger"
    WARNING = "warning"
    CAUTION = "caution"


@dataclass(frozen=True)
class Interaction:
    """A single drug-drug interaction record."""

    drug_a: tuple[str, ...]
    drug_b: tuple[str, ...]
    severity: Severity
    description: str
    mechanism: str
    recommendation: str
    source: str

    def involves(self, drug_name: str) -> bool:
        """Check if this interaction involves the given drug (case-insensitive)."""
        name = drug_name.lower().strip()
        return name in self.drug_a or name in self.drug_b

    def matches_pair(self, name_a: str, name_b: str) -> bool:
        """Check if this interaction matches the given drug pair."""
        a = name_a.lower().strip()
        b = name_b.lower().strip()
        return (a in self.drug_a and b in self.drug_b) or (
            a in self.drug_b and b in self.drug_a
        )

    def to_dict(self) -> dict:
        """Serialize to a plain dictionary."""
        return {
            "drug_a": list(self.drug_a),
            "drug_b": list(self.drug_b),
            "severity": self.severity.value,
            "description": self.description,
            "mechanism": self.mechanism,
            "recommendation": self.recommendation,
            "source": self.source,
        }


@dataclass
class InteractionResult:
    """Result of checking a drug pair."""

    drug_a: str
    drug_b: str
    found: bool
    interaction: Interaction | None = None

    def to_dict(self) -> dict:
        """Serialize to a plain dictionary."""
        result: dict = {
            "drug_a": self.drug_a,
            "drug_b": self.drug_b,
            "found": self.found,
        }
        if self.interaction:
            result["severity"] = self.interaction.severity.value
            result["description"] = self.interaction.description
            result["mechanism"] = self.interaction.mechanism
            result["recommendation"] = self.interaction.recommendation
            result["source"] = self.interaction.source
        return result


@dataclass
class DrugInfo:
    """Information about a drug and its known interactions."""

    name: str
    interactions: list[Interaction] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Serialize to a plain dictionary."""
        return {
            "name": self.name,
            "interaction_count": len(self.interactions),
            "interactions": [i.to_dict() for i in self.interactions],
        }


@dataclass
class SearchResult:
    """A drug name search result."""

    name: str
    score: float
    aliases: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Serialize to a plain dictionary."""
        return {
            "name": self.name,
            "score": self.score,
            "aliases": self.aliases,
        }
