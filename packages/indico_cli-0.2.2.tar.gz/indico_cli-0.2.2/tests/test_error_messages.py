"""Tests for improved error messages in export API commands."""

import pytest
from unittest.mock import AsyncMock

from indico_cli.indico_api import IndicoAPI, IndicoClient


def make_client(base_url="https://indico.cern.ch"):
    api = IndicoAPI(base_url)
    return IndicoClient(api)


class TestGetEventDetailsErrors:
    @pytest.mark.asyncio
    async def test_not_found_includes_browser_url(self):
        client = make_client("https://indico.cern.ch")
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.get_event_details("999999")
        assert "https://indico.cern.ch/event/999999/" in result

    @pytest.mark.asyncio
    async def test_not_found_suggests_search_by_term(self):
        client = make_client()
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.get_event_details("999999")
        assert "search-by-term" in result


class TestGetEventContributionsErrors:
    @pytest.mark.asyncio
    async def test_event_not_found_suggests_search(self):
        """When export returns empty results (event deleted/inaccessible)."""
        client = make_client("https://indico.cern.ch")
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.get_event_contributions("999999")
        assert "search-by-term" in result
        assert "https://indico.cern.ch/event/999999/" in result

    @pytest.mark.asyncio
    async def test_event_found_but_no_contributions_no_search_suggestion(self):
        """When event exists but has no contributions — don't suggest search."""
        client = make_client()
        client.api.get = AsyncMock(return_value={
            "count": 1,
            "results": [{"title": "My Event", "contributions": []}]
        })
        result = await client.get_event_contributions("12345")
        assert "search-by-term" not in result
        assert "My Event" in result


class TestSearchEventsErrors:
    @pytest.mark.asyncio
    async def test_no_results_suggests_alternatives(self):
        client = make_client("https://indico.cern.ch")
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.search_events("4648")
        assert "search-by-term" in result
        assert "https://indico.cern.ch/category/4648/" in result


class TestSearchCategoriesErrors:
    @pytest.mark.asyncio
    async def test_empty_category_includes_browser_url(self):
        client = make_client("https://indico.cern.ch")
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.search_categories("9999")
        assert "https://indico.cern.ch/category/9999/" in result
