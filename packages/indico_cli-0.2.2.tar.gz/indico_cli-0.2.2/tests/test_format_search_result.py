"""Tests for IndicoClient._format_search_result"""

from indico_cli.indico_api import IndicoAPI, IndicoClient


def make_client(base_url="https://indico.cern.ch"):
    api = IndicoAPI(base_url)
    return IndicoClient(api)


class TestContributionFormat:
    def test_displays_event_id(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
            "persons": [{"name": "Javier Resta Lopez", "affiliation": "IFIC"}],
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "Event ID: 1603008" in formatted

    def test_displays_contribution_id(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "Contribution ID: 6754636" in formatted

    def test_displays_full_url(self):
        client = make_client("https://indico.cern.ch")
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
        }
        formatted = client._format_search_result(result, "contribution", 1, "https://indico.cern.ch")
        assert "https://indico.cern.ch/event/1603008/contributions/6754636/" in formatted

    def test_displays_event_title_from_event_path(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "ISRS Meeting" in formatted

    def test_displays_persons_as_speakers(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
            "persons": [{"name": "Javier Resta Lopez", "affiliation": "IFIC"}],
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "Javier Resta Lopez" in formatted

    def test_handles_empty_event_path(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [],
            "url": "/event/1603008/contributions/6754636/",
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "Event ID: 1603008" in formatted

    def test_subcontribution_same_as_contribution(self):
        client = make_client()
        result = {
            "title": "Sub talk",
            "contribution_id": 123,
            "event_id": 456,
            "event_path": [{"id": 456, "title": "Event", "type": "event"}],
            "url": "/event/456/contributions/123/subcontributions/7/",
        }
        formatted = client._format_search_result(result, "subcontribution", 1)
        assert "Event ID: 456" in formatted


class TestEventFormat:
    def test_displays_full_url_with_base(self):
        client = make_client("https://indico.cern.ch")
        result = {
            "title": "Workshop",
            "event_id": 1603008,
            "url": "/event/1603008/",
        }
        formatted = client._format_search_result(result, "event", 1, "https://indico.cern.ch")
        assert "https://indico.cern.ch/event/1603008/" in formatted


class TestAttachmentFormat:
    def test_displays_event_id(self):
        client = make_client()
        result = {
            "filename": "Beam_dynamics_meeting.pdf",
            "attachment_id": 3147646,
            "event_id": 835981,
            "event_path": [{"id": 835981, "title": "Beam dynamics meeting", "type": "event"}],
            "url": "/event/835981/attachments/1905898/3147646/Beam_dynamics_meeting.pdf",
        }
        formatted = client._format_search_result(result, "attachment", 1)
        assert "Event ID: 835981" in formatted

    def test_displays_attachment_id(self):
        client = make_client()
        result = {
            "filename": "slides.pdf",
            "attachment_id": 999,
            "event_id": 100,
            "event_path": [{"id": 100, "title": "Event", "type": "event"}],
            "url": "/event/100/attachments/50/999/slides.pdf",
        }
        formatted = client._format_search_result(result, "attachment", 1)
        assert "Attachment ID: 999" in formatted

    def test_displays_full_url(self):
        client = make_client("https://indico.cern.ch")
        result = {
            "filename": "slides.pdf",
            "attachment_id": 999,
            "event_id": 100,
            "event_path": [{"id": 100, "title": "Event", "type": "event"}],
            "url": "/event/100/attachments/50/999/slides.pdf",
        }
        formatted = client._format_search_result(result, "attachment", 1, "https://indico.cern.ch")
        assert "https://indico.cern.ch/event/100/attachments/50/999/slides.pdf" in formatted


class TestEventNoteFormat:
    def test_displays_event_id(self):
        client = make_client()
        result = {
            "title": "Meeting notes",
            "event_id": 500,
            "event_path": [{"id": 500, "title": "Weekly sync", "type": "event"}],
        }
        formatted = client._format_search_result(result, "event_note", 1)
        assert "Event ID: 500" in formatted

    def test_displays_event_title_from_event_path(self):
        client = make_client()
        result = {
            "title": "Meeting notes",
            "event_id": 500,
            "event_path": [{"id": 500, "title": "Weekly sync", "type": "event"}],
        }
        formatted = client._format_search_result(result, "event_note", 1)
        assert "Weekly sync" in formatted
