# indico-cli

Command line interface for interacting with [Indico](https://getindico.io/) event management systems.

## Installation

```bash
# Run directly with uvx (recommended)
uvx indico-cli --help

# Or install with pip
pip install indico-cli
```

## Configuration

Set environment variables:

```bash
export INDICO_BASE_URL="https://indico.cern.ch"
export INDICO_API_TOKEN="indp_..."  # Bearer token from Indico preferences
```

Or use the `configure` command to save credentials:

```bash
indico-cli configure --base-url https://indico.cern.ch --token indp_...
```

API tokens can be generated at `<your-indico-url>/user/preferences/api`. Required scopes: `read:legacy_api`, `write:legacy_api` (for create operations), `read:user` (optional).

## Usage

### Search

```bash
# Full-text search across all content types
indico-cli search-by-term --term "machine learning"

# Search events in a category
indico-cli search-events --category-id 4648 --from-date 2025-01-01

# Browse categories
indico-cli search-categories --category-id 0
```

### Event Details

```bash
# Get event info with contributions and sessions
indico-cli event-details --event-id 137346 --contributions --sessions

# List contributions/talks
indico-cli contributions --event-id 137346 --subcontributions
```

### Files

```bash
# List and download all event files
indico-cli files --event-id 137346

# List files without downloading
indico-cli files --event-id 137346 --no-download

# Download a single attachment
indico-cli download --url "https://indico.cern.ch/event/.../file.pdf"
```

### Create Events

```bash
# Create a simple meeting
indico-cli create-event --title "Team Meeting" --category-id 4648 --type meeting \
  --start 2025-06-15T09:00:00 --end 2025-06-15T10:00:00

# Create event with full agenda from JSON file
indico-cli create-event-with-agenda --title "Workshop" --category-id 4648 \
  --type meeting --start 2025-06-15T09:00:00 --end 2025-06-15T17:00:00 \
  --agenda-file agenda.json
```

### All Commands

Run `indico-cli --help` to see all available commands, or `indico-cli <command> --help` for command-specific options.

## Claude Code Skill

A Claude Code skill is included for AI-assisted Indico workflows. It provides a single consolidated skill covering all CLI commands: searching events, browsing categories, creating events/sessions/contributions, managing timetables, downloading files, and configuring credentials.

The skill also includes guidance for multi-step workflows such as:
- Recovering from missing or deleted events by searching for alternatives
- Chaining search, download, and content extraction to answer questions from slides
- Paginating through large categories (works around the 10-event display limit)

### Install the skill

```bash
npx skills add https://gitlab.cern.ch/cern-agent-skills/indico-cli.git
```

Once installed, Claude Code will automatically use the skill whenever you ask about Indico events, conferences, meetings, or agendas. You can also invoke it directly with `/indico-skill`.

## Documentation

- [Indico HTTP API docs](https://docs.getindico.io/en/stable/http-api/)
- [Indico platform](https://getindico.io/)
