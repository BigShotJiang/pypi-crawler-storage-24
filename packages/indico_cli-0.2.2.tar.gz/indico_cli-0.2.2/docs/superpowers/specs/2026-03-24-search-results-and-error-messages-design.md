# Fix search-by-term event IDs and improve export API error messages

**Date:** 2026-03-24
**Status:** Draft

## Problem

Two issues prevent effective CLI workflows:

1. `search-by-term` returns contributions, attachments, and notes without displaying the `event_id`, so users cannot follow up with `event-details`, `contributions`, or `files` commands.
2. Export API commands (`event-details`, `contributions`, `search-events`, `search-categories`) return generic error messages when events are deleted or inaccessible, offering no recovery path.

### Root cause

The search API (`/search/api/search`) returns `event_id` and full URLs in every result, but `_format_search_result` in `indico_api.py` does not display them for contributions, attachments, or notes.

The export API (`/export/event/...`, `/export/categ/...`) works correctly with `indp_` bearer tokens. The previously reported "400 BAD REQUEST" was a misdiagnosis — the actual behavior is an empty result set (`count: 0`) for deleted or inaccessible events, with unhelpful error text.

## Search API response structure

Verified against `indico.cern.ch` on 2026-03-24. All URLs are **relative paths** (no hostname).

### Contribution result
```json
{
  "contribution_id": 6754636,
  "event_id": 1603008,
  "title": "Beam dynamics",
  "type": "contribution",
  "url": "/event/1603008/contributions/6754636/",
  "persons": [{"affiliation": "IFIC", "name": "Javier Resta Lopez"}],
  "event_path": [{"id": 1603008, "title": "ISRS Collaboration Meeting...", "type": "event", "url": "/event/1603008/"}],
  "start_dt": "2025-11-24T08:50:00+00:00",
  "location": {"venue_name": "ZOOM", "room_name": "", "address": "..."}
}
```

### Attachment result
```json
{
  "attachment_id": 3147646,
  "event_id": 835981,
  "title": "Beam dynamics meeting.pdf",
  "filename": "Beam_dynamics_meeting.pdf",
  "type": "attachment",
  "url": "/event/835981/attachments/1905898/3147646/Beam_dynamics_meeting.pdf",
  "contribution_id": null,
  "folder_id": 1905898,
  "event_path": [{"id": 835981, "title": "BE-APB-HSL Beam dynamics meeting", "type": "event", "url": "/event/835981/"}],
  "user": {"affiliation": "...", "name": "Vittorio Bencini"}
}
```

### Event result
```json
{
  "event_id": 1603008,
  "title": "ISRS Collaboration Meeting...",
  "type": "event",
  "url": "/event/1603008/"
}
```

Key observations:
- `event_id` is a **top-level integer field** on all result types
- `url` is a **relative path** — must be prefixed with `self.api.base_url` to form a full URL
- `contribution_id` (not `id`) is the contribution identifier in search results

## Changes

### 1. Display `event_id` and URL in search results

**File:** `indico_cli/indico_api.py`, method `_format_search_result` (line ~457)

`_format_search_result` currently does not have access to `base_url`. Either:
- Pass `base_url` as a parameter, or
- Store it on `IndicoClient` (it's already available via `self.api.base_url`)

The method must be updated to accept `base_url` and construct full URLs.

**Contributions/subcontributions** — before:
```
   1. Beam dynamics (ID: N/A)
      Event: ISRS Collaboration Meeting...
      Speakers: Javier Resta Lopez
```

After:
```
   1. Beam dynamics (Contribution ID: 6754636)
      Event: ISRS Collaboration Meeting... (Event ID: 1603008)
      Speakers: Javier Resta Lopez
      URL: https://indico.cern.ch/event/1603008/contributions/6754636/
```

**Attachments** — before:
```
   1. Beam_dynamics_meeting.pdf (ID: N/A)
      Event: BE-APB-HSL Beam dynamics meeting
      Type: application/pdf
```

After:
```
   1. Beam_dynamics_meeting.pdf (Attachment ID: 3147646)
      Event: BE-APB-HSL Beam dynamics meeting (Event ID: 835981)
      Type: application/pdf
      URL: https://indico.cern.ch/event/835981/attachments/1905898/3147646/Beam_dynamics_meeting.pdf
```

**Event notes** — add `Event ID: {event_id}` on the event title line, same pattern.

**Events** — already display event ID. Add URL if present.

**Categories** — no event_id, no change needed.

Field mapping for extraction:
- Contribution ID: `result.get("contribution_id")` (NOT `result.get("id")`)
- Attachment ID: `result.get("attachment_id")`
- Event ID: `result.get("event_id")`
- Event title: `result.get("event_path", [{}])[0].get("title", "")` — the search API does NOT return a flat `event_title` field; the title is nested inside `event_path[0]["title"]`. The current code tries `result.get("event_title")` which always misses. Fix to use `event_path`.
- Speakers/persons: the search API returns `persons` (list of `{"name": "...", "affiliation": "..."}`), NOT `speakers`. The current code reads `result.get("speakers")` which always misses. Fix to fall back: `result.get("speakers", result.get("persons", []))`.
- URL: `base_url + result.get("url", "")` — search API URLs are relative paths

### 2. Improve error messages in export API commands

**File:** `indico_cli/indico_api.py`

**`get_event_details`** (line ~529) — when `results` is empty:
```
Event {event_id} not found or not accessible.
Check in your browser: {base_url}/event/{event_id}/
If the event was deleted, try: search-by-term --term "<keywords>" to find similar content.
```

**`get_event_contributions`** (line ~708) — distinguish two cases:
- Event found (non-empty `event` dict) but zero contributions → keep current message (legitimate)
- Event not found (empty `event` dict) → show recovery message like `get_event_details`

**`search_events`** (line ~317) — when count is 0:
```
No events found in category {category_id}.
Browse in your browser: {base_url}/category/{category_id}/
Try adjusting --from-date/--to-date, or use search-by-term for keyword search.
```

**`search_categories`** (line ~673) — when items is empty:
```
No events found in category {category_id}.
Browse in your browser: {base_url}/category/{category_id}/
```

### 3. Update skill documentation

**File:** `skills/indico-skill/SKILL.md`

Add to "Working with Results / Chaining commands" section:

```markdown
### Using event IDs from search results

`search-by-term` returns `Event ID` for every contribution, attachment, and note result. Use this ID to drill into the event:
1. `search-by-term --term "my topic"` — find the contribution and note its Event ID
2. `event-details --event-id <ID>` — get full event info
3. `contributions --event-id <ID>` — list all contributions
4. `files --event-id <ID>` — download materials
```

## Files modified

1. `indico_cli/indico_api.py` — `_format_search_result` (+ signature change to accept `base_url`), `get_event_details`, `get_event_contributions`, `search_events`, `search_categories`
2. `skills/indico-skill/SKILL.md` — documentation update

## Testing

Manual verification:
1. Run `indico-cli search-by-term --term "beam dynamics" --limit 2` and confirm Event ID and URL appear for contributions and attachments
2. Run `indico-cli event-details --event-id 999999999` (non-existent) and confirm improved error message
3. Run `indico-cli event-details --event-id 1603008` and confirm it still works for valid events

## Out of scope

- Migrating from `/export/` to `/api/` REST endpoints (returns 405 on CERN's instance)
- Adding new CLI commands or flags
- Changing authentication flow
