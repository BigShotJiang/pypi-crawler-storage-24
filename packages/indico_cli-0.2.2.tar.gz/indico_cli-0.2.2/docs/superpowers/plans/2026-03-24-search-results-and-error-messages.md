# Search Results & Error Messages Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix `search-by-term` to display event IDs/URLs for contributions and attachments, and improve error messages in export API commands so users can recover from deleted/inaccessible events.

**Architecture:** Pure formatting changes in `IndicoClient` methods. No new endpoints, no new dependencies. The `_format_search_result` method gains a `base_url` parameter and uses correct field names from the search API. Four export API methods get improved empty-result messages with browser URLs and recovery suggestions.

**Tech Stack:** Python, pytest (new dev dependency), httpx (existing)

**Spec:** `docs/superpowers/specs/2026-03-24-search-results-and-error-messages-design.md`

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `indico_cli/indico_api.py` | Modify | Fix `_format_search_result` signature + field extraction; improve error messages in 4 methods |
| `skills/indico-skill/SKILL.md` | Modify | Document event ID in search results and drill-down workflow |
| `tests/test_format_search_result.py` | Create | Unit tests for `_format_search_result` |
| `tests/test_error_messages.py` | Create | Unit tests for empty-result error messages |
| `pyproject.toml` | Modify | Add pytest dev dependency |

---

### Task 1: Add pytest and create test infrastructure

**Files:**
- Modify: `pyproject.toml`
- Create: `tests/__init__.py`

- [ ] **Step 1: Add pytest dev dependency to pyproject.toml**

Add after the `[tool.hatch.build.hooks.vcs]` section:

Add under the `[project]` section (after `classifiers`):

```toml
[project.optional-dependencies]
dev = ["pytest>=7.0", "pytest-asyncio>=0.21"]
```

Also add at the end of the file:

```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
```

- [ ] **Step 2: Create tests package**

```bash
mkdir -p tests && touch tests/__init__.py
```

- [ ] **Step 3: Install dev dependencies**

Run: `cd /home/fvelotti/indico-cli && uv pip install -e ".[dev]"`
Expected: Successful install with pytest available

- [ ] **Step 4: Verify pytest works**

Run: `cd /home/fvelotti/indico-cli && python -m pytest --version`
Expected: pytest version printed

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml tests/__init__.py
git commit -m "chore: add pytest dev dependency and tests package"
```

---

### Task 2: Fix `_format_search_result` for contributions

**Files:**
- Create: `tests/test_format_search_result.py`
- Modify: `indico_cli/indico_api.py:457-526` (`_format_search_result` method)

- [ ] **Step 1: Write the failing tests**

Create `tests/test_format_search_result.py`:

```python
"""Tests for IndicoClient._format_search_result"""

from indico_cli.indico_api import IndicoAPI, IndicoClient


def make_client(base_url="https://indico.cern.ch"):
    api = IndicoAPI(base_url)
    return IndicoClient(api)


class TestContributionFormat:
    def test_displays_event_id(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
            "persons": [{"name": "Javier Resta Lopez", "affiliation": "IFIC"}],
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "Event ID: 1603008" in formatted

    def test_displays_contribution_id(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "Contribution ID: 6754636" in formatted

    def test_displays_full_url(self):
        client = make_client("https://indico.cern.ch")
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "https://indico.cern.ch/event/1603008/contributions/6754636/" in formatted

    def test_displays_event_title_from_event_path(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "ISRS Meeting" in formatted

    def test_displays_persons_as_speakers(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [{"id": 1603008, "title": "ISRS Meeting", "type": "event"}],
            "url": "/event/1603008/contributions/6754636/",
            "persons": [{"name": "Javier Resta Lopez", "affiliation": "IFIC"}],
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "Javier Resta Lopez" in formatted

    def test_handles_empty_event_path(self):
        client = make_client()
        result = {
            "title": "Beam dynamics",
            "contribution_id": 6754636,
            "event_id": 1603008,
            "event_path": [],
            "url": "/event/1603008/contributions/6754636/",
        }
        formatted = client._format_search_result(result, "contribution", 1)
        assert "Event ID: 1603008" in formatted

    def test_subcontribution_same_as_contribution(self):
        client = make_client()
        result = {
            "title": "Sub talk",
            "contribution_id": 123,
            "event_id": 456,
            "event_path": [{"id": 456, "title": "Event", "type": "event"}],
            "url": "/event/456/contributions/123/subcontributions/7/",
        }
        formatted = client._format_search_result(result, "subcontribution", 1)
        assert "Event ID: 456" in formatted
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd /home/fvelotti/indico-cli && python -m pytest tests/test_format_search_result.py -v`
Expected: FAIL — missing `event_id`, wrong field names

- [ ] **Step 3: Update `_format_search_result` signature and contribution/subcontribution branch**

In `indico_cli/indico_api.py`, change the method signature from:

```python
def _format_search_result(self, result: dict, search_type: str, index: int) -> str:
```

to:

```python
def _format_search_result(self, result: dict, search_type: str, index: int, base_url: str = "") -> str:
```

Then replace the contribution/subcontribution branch (lines 481-494):

```python
        elif search_type in ["contribution", "subcontribution"]:
            title = result.get("title", "No title")
            contrib_id = result.get("contribution_id", result.get("id", "N/A"))
            event_id = result.get("event_id", "N/A")
            event_path = result.get("event_path") or [{}]
            event_title = event_path[0].get("title", "")

            formatted += f"{title} (Contribution ID: {contrib_id})\n"
            if event_title:
                formatted += f"      Event: {event_title} (Event ID: {event_id})\n"
            elif event_id != "N/A":
                formatted += f"      Event ID: {event_id}\n"
            speakers = result.get("speakers", result.get("persons", []))
            if speakers:
                names = [s.get("name", f"{s.get('first_name', '')} {s.get('last_name', '')}").strip()
                        for s in speakers[:2]]
                speakers_str = ", ".join(filter(None, names))
                if speakers_str:
                    formatted += f"      Speakers: {speakers_str}\n"
            if result.get("url"):
                formatted += f"      URL: {base_url}{result['url']}\n"
```

- [ ] **Step 4: Update the caller to pass `base_url`**

In `search_events_by_term` (line ~431), change:

```python
response += self._format_search_result(result, search_type, i)
```

to:

```python
response += self._format_search_result(result, search_type, i, self.api.base_url)
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `cd /home/fvelotti/indico-cli && python -m pytest tests/test_format_search_result.py -v`
Expected: All PASS

- [ ] **Step 6: Commit**

```bash
git add indico_cli/indico_api.py tests/test_format_search_result.py
git commit -m "fix: display event ID, URL, and speakers in contribution search results"
```

---

### Task 3: Fix `_format_search_result` for attachments and event notes

**Files:**
- Modify: `tests/test_format_search_result.py`
- Modify: `indico_cli/indico_api.py:496-519`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_format_search_result.py`:

```python
class TestEventFormat:
    def test_displays_full_url_with_base(self):
        client = make_client("https://indico.cern.ch")
        result = {
            "title": "Workshop",
            "event_id": 1603008,
            "url": "/event/1603008/",
        }
        formatted = client._format_search_result(result, "event", 1, "https://indico.cern.ch")
        assert "https://indico.cern.ch/event/1603008/" in formatted


class TestAttachmentFormat:
    def test_displays_event_id(self):
        client = make_client()
        result = {
            "filename": "Beam_dynamics_meeting.pdf",
            "attachment_id": 3147646,
            "event_id": 835981,
            "event_path": [{"id": 835981, "title": "Beam dynamics meeting", "type": "event"}],
            "url": "/event/835981/attachments/1905898/3147646/Beam_dynamics_meeting.pdf",
        }
        formatted = client._format_search_result(result, "attachment", 1)
        assert "Event ID: 835981" in formatted

    def test_displays_attachment_id(self):
        client = make_client()
        result = {
            "filename": "slides.pdf",
            "attachment_id": 999,
            "event_id": 100,
            "event_path": [{"id": 100, "title": "Event", "type": "event"}],
            "url": "/event/100/attachments/50/999/slides.pdf",
        }
        formatted = client._format_search_result(result, "attachment", 1)
        assert "Attachment ID: 999" in formatted

    def test_displays_full_url(self):
        client = make_client("https://indico.cern.ch")
        result = {
            "filename": "slides.pdf",
            "attachment_id": 999,
            "event_id": 100,
            "event_path": [{"id": 100, "title": "Event", "type": "event"}],
            "url": "/event/100/attachments/50/999/slides.pdf",
        }
        formatted = client._format_search_result(result, "attachment", 1)
        assert "https://indico.cern.ch/event/100/attachments/50/999/slides.pdf" in formatted


class TestEventNoteFormat:
    def test_displays_event_id(self):
        client = make_client()
        result = {
            "title": "Meeting notes",
            "event_id": 500,
            "event_path": [{"id": 500, "title": "Weekly sync", "type": "event"}],
        }
        formatted = client._format_search_result(result, "event_note", 1)
        assert "Event ID: 500" in formatted

    def test_displays_event_title_from_event_path(self):
        client = make_client()
        result = {
            "title": "Meeting notes",
            "event_id": 500,
            "event_path": [{"id": 500, "title": "Weekly sync", "type": "event"}],
        }
        formatted = client._format_search_result(result, "event_note", 1)
        assert "Weekly sync" in formatted
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd /home/fvelotti/indico-cli && python -m pytest tests/test_format_search_result.py -v -k "Attachment or EventNote"`
Expected: FAIL — missing event_id, wrong field names

- [ ] **Step 3: Update attachment branch (lines 496-505)**

Replace:

```python
        elif search_type == "attachment":
            filename = result.get("filename", result.get("title", "No filename"))
            file_id = result.get("id", "N/A")
            event_title = result.get("event_title", "")

            formatted += f"{filename} (ID: {file_id})\n"
            if event_title:
                formatted += f"      Event: {event_title}\n"
            if result.get("content_type"):
                formatted += f"      Type: {result['content_type']}\n"
```

With:

```python
        elif search_type == "attachment":
            filename = result.get("filename", result.get("title", "No filename"))
            file_id = result.get("attachment_id", result.get("id", "N/A"))
            event_id = result.get("event_id", "N/A")
            event_path = result.get("event_path") or [{}]
            event_title = event_path[0].get("title", "")

            formatted += f"{filename} (Attachment ID: {file_id})\n"
            if event_title:
                formatted += f"      Event: {event_title} (Event ID: {event_id})\n"
            elif event_id != "N/A":
                formatted += f"      Event ID: {event_id}\n"
            if result.get("content_type"):
                formatted += f"      Type: {result['content_type']}\n"
            if result.get("url"):
                formatted += f"      URL: {base_url}{result['url']}\n"
```

- [ ] **Step 4: Update event_note branch (lines 507-519)**

Replace:

```python
        elif search_type == "event_note":
            title = result.get("title", "Note")
            note_id = result.get("id", "N/A")
            event_title = result.get("event_title", "")

            formatted += f"{title} (ID: {note_id})\n"
            if event_title:
                formatted += f"      Event: {event_title}\n"
            if result.get("html"):
                content = result["html"][:100] + "..." if len(result["html"]) > 100 else result["html"]
                # Strip HTML tags for display
                clean_content = re.sub(r'<[^>]+>', '', content)
                formatted += f"      Content: {clean_content}\n"
```

With:

```python
        elif search_type == "event_note":
            title = result.get("title", "Note")
            note_id = result.get("id", "N/A")
            event_id = result.get("event_id", "N/A")
            event_path = result.get("event_path") or [{}]
            event_title = event_path[0].get("title", "")

            formatted += f"{title} (ID: {note_id})\n"
            if event_title:
                formatted += f"      Event: {event_title} (Event ID: {event_id})\n"
            elif event_id != "N/A":
                formatted += f"      Event ID: {event_id}\n"
            if result.get("html"):
                content = result["html"][:100] + "..." if len(result["html"]) > 100 else result["html"]
                clean_content = re.sub(r'<[^>]+>', '', content)
                formatted += f"      Content: {clean_content}\n"
```

- [ ] **Step 5: Also fix event branch to include full URL with base_url**

Replace line 469-470:

```python
            if result.get("url"):
                formatted += f"      URL: {result['url']}\n"
```

With:

```python
            if result.get("url"):
                formatted += f"      URL: {base_url}{result['url']}\n"
```

And fix the event_id extraction (line 463) to prefer `event_id` (search API field name):

```python
            event_id = result.get("event_id", result.get("id", "N/A"))
```

- [ ] **Step 6: Run all tests**

Run: `cd /home/fvelotti/indico-cli && python -m pytest tests/test_format_search_result.py -v`
Expected: All PASS

- [ ] **Step 7: Commit**

```bash
git add indico_cli/indico_api.py tests/test_format_search_result.py
git commit -m "fix: display event ID and URL in attachment and event note search results"
```

---

### Task 4: Improve error messages in export API commands

**Files:**
- Create: `tests/test_error_messages.py`
- Modify: `indico_cli/indico_api.py:529-556` (`get_event_details`), `indico_cli/indico_api.py:708-735` (`get_event_contributions`), `indico_cli/indico_api.py:317-358` (`search_events`), `indico_cli/indico_api.py:673-706` (`search_categories`)

- [ ] **Step 1: Write failing tests**

Create `tests/test_error_messages.py`:

```python
"""Tests for improved error messages in export API commands."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from indico_cli.indico_api import IndicoAPI, IndicoClient


def make_client(base_url="https://indico.cern.ch"):
    api = IndicoAPI(base_url)
    return IndicoClient(api)


class TestGetEventDetailsErrors:
    @pytest.mark.asyncio
    async def test_not_found_includes_browser_url(self):
        client = make_client("https://indico.cern.ch")
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.get_event_details("999999")
        assert "https://indico.cern.ch/event/999999/" in result

    @pytest.mark.asyncio
    async def test_not_found_suggests_search_by_term(self):
        client = make_client()
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.get_event_details("999999")
        assert "search-by-term" in result


class TestGetEventContributionsErrors:
    @pytest.mark.asyncio
    async def test_event_not_found_suggests_search(self):
        """When export returns empty results (event deleted/inaccessible)."""
        client = make_client("https://indico.cern.ch")
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.get_event_contributions("999999")
        assert "search-by-term" in result
        assert "https://indico.cern.ch/event/999999/" in result

    @pytest.mark.asyncio
    async def test_event_found_but_no_contributions_no_search_suggestion(self):
        """When event exists but has no contributions — don't suggest search."""
        client = make_client()
        client.api.get = AsyncMock(return_value={
            "count": 1,
            "results": [{"title": "My Event", "contributions": []}]
        })
        result = await client.get_event_contributions("12345")
        assert "search-by-term" not in result
        assert "My Event" in result


class TestSearchEventsErrors:
    @pytest.mark.asyncio
    async def test_no_results_suggests_alternatives(self):
        client = make_client("https://indico.cern.ch")
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.search_events("4648")
        assert "search-by-term" in result
        assert "https://indico.cern.ch/category/4648/" in result


class TestSearchCategoriesErrors:
    @pytest.mark.asyncio
    async def test_empty_category_includes_browser_url(self):
        client = make_client("https://indico.cern.ch")
        client.api.get = AsyncMock(return_value={"count": 0, "results": []})
        result = await client.search_categories("9999")
        assert "https://indico.cern.ch/category/9999/" in result
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd /home/fvelotti/indico-cli && python -m pytest tests/test_error_messages.py -v`
Expected: FAIL — current messages don't include URLs or search-by-term suggestions

- [ ] **Step 3: Fix `get_event_details` empty-result message (line ~549-556)**

Replace:

```python
        if not event:
            return (
                f"Event {event_id} not found or not accessible\n\n"
                "Possible issues:\n"
                "- Invalid event ID\n"
                "- Event is private and you don't have access\n"
                "- Event may be in a restricted category"
            )
```

With:

```python
        if not event:
            return (
                f"Event {event_id} not found or not accessible.\n"
                f"Check in your browser: {self.api.base_url}/event/{event_id}/\n\n"
                "If the event was deleted or moved, try:\n"
                '  search-by-term --term "<keywords>" to find similar content.'
            )
```

- [ ] **Step 4: Fix `get_event_contributions` to distinguish empty event vs no contributions (line ~729-735)**

Replace:

```python
            event = (
                result.get("results", [{}])[0] if result.get("results") else {}
            )
            contributions = event.get("contributions", [])

            if not contributions:
                return f"No contributions found for event {event_id} ({event.get('title', 'Unknown Event')})"
```

With:

```python
            event = (
                result.get("results", [{}])[0] if result.get("results") else {}
            )

            if not event:
                return (
                    f"Event {event_id} not found or not accessible.\n"
                    f"Check in your browser: {self.api.base_url}/event/{event_id}/\n\n"
                    "If the event was deleted or moved, try:\n"
                    '  search-by-term --term "<keywords>" to find similar content.'
                )

            contributions = event.get("contributions", [])

            if not contributions:
                return f"No contributions found for event {event_id} ({event.get('title', 'Unknown Event')})"
```

- [ ] **Step 5: Fix `search_events` empty-result message (line ~339-357)**

Replace:

```python
        events = result.get("results", [])
        count = result.get("count", 0)

        response = f"Found {count} events in category {category_id}:\n\n"
```

With:

```python
        events = result.get("results", [])
        count = result.get("count", 0)

        if count == 0:
            return (
                f"No events found in category {category_id}.\n"
                f"Browse in your browser: {self.api.base_url}/category/{category_id}/\n\n"
                "Try adjusting --from-date/--to-date, or use search-by-term for keyword search."
            )

        response = f"Found {count} events in category {category_id}:\n\n"
```

- [ ] **Step 6: Fix `search_categories` empty-result message (line ~687-690)**

Replace:

```python
        items = result.get("results", [])

        response = f"Category {category_id} contents:\n\n"
        response += f"Found {len(items)} items\n\n"
```

With:

```python
        items = result.get("results", [])

        if not items:
            return (
                f"No events found in category {category_id}.\n"
                f"Browse in your browser: {self.api.base_url}/category/{category_id}/"
            )

        response = f"Category {category_id} contents:\n\n"
        response += f"Found {len(items)} items\n\n"
```

- [ ] **Step 7: Run tests**

Run: `cd /home/fvelotti/indico-cli && python -m pytest tests/test_error_messages.py -v`
Expected: All PASS

- [ ] **Step 8: Run all tests**

Run: `cd /home/fvelotti/indico-cli && python -m pytest tests/ -v`
Expected: All PASS

- [ ] **Step 9: Commit**

```bash
git add indico_cli/indico_api.py tests/test_error_messages.py
git commit -m "fix: improve error messages with browser URLs and recovery suggestions"
```

---

### Task 5: Update skill documentation

**Files:**
- Modify: `skills/indico-skill/SKILL.md`

- [ ] **Step 1: Add event ID documentation to SKILL.md**

After the "Chaining commands for deeper answers" section (after line 51 in SKILL.md), add:

```markdown
### Using event IDs from search results

`search-by-term` returns `Event ID` for every contribution, attachment, and note result. Use this ID to drill into the event:
1. `search-by-term --term "my topic"` — find the contribution and note its Event ID
2. `event-details --event-id <ID>` — get full event info
3. `contributions --event-id <ID>` — list all contributions
4. `files --event-id <ID>` — download materials
```

- [ ] **Step 2: Verify the skill file reads correctly**

Run: `cd /home/fvelotti/indico-cli && head -60 skills/indico-skill/SKILL.md`
Expected: New section visible after "Chaining commands"

- [ ] **Step 3: Run all tests one final time**

Run: `cd /home/fvelotti/indico-cli && python -m pytest tests/ -v`
Expected: All PASS

- [ ] **Step 4: Commit**

```bash
git add skills/indico-skill/SKILL.md
git commit -m "docs: document event ID in search results and drill-down workflow"
```

---

### Task 6: Manual verification

- [ ] **Step 1: Test search-by-term with real API**

Run: `cd /home/fvelotti/indico-cli && python -m indico_cli.cli search-by-term --term "beam dynamics" --limit 2`
Expected: Contributions show `Event ID: ...` and full URL. Attachments show `Event ID: ...` and download URL.

- [ ] **Step 2: Test event-details with non-existent event**

Run: `cd /home/fvelotti/indico-cli && python -m indico_cli.cli event-details --event-id 999999999`
Expected: Message includes `https://indico.cern.ch/event/999999999/` and suggests `search-by-term`.

- [ ] **Step 3: Test event-details with valid event**

Run: `cd /home/fvelotti/indico-cli && python -m indico_cli.cli event-details --event-id 1603008`
Expected: Normal output with event title, not an error.
