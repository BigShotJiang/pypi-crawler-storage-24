# python-sdk

A lightweight Python SDK that instruments AI agents with OpenTelemetry tracing via a single `init()` call. It wires up a `TracerProvider`, `BatchSpanProcessor`, and custom `PendoSpanExporter` that exports completed spans to Pendo's ingestion pipeline (`/data/agentic`) over OTLP HTTP.

Supports automatic PII redaction (email, phone, SSN) before network export, Pendo identity injection (visitor/account), and is designed for future auto-patching of LLM client libraries (Anthropic, OpenAI).

## Quick start

```python
import pendo_sdk

pendo_sdk.init(api_key="your-key", project_id="my-agent")
```
