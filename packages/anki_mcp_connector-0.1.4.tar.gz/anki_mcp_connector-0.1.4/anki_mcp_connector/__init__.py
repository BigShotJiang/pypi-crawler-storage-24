"""Anki MCP Connector - A Model Context Protocol server for Anki card creation."""

__version__ = "0.1.2"

from .server import mcp

__all__ = ["mcp"]
