"""EIP-712 payment signing for x402 protocol (USDC TransferWithAuthorization).

Produces x402 PaymentPayload v1 format compatible with @x402/core SDK:
  { x402Version: 1, scheme: "exact", network: "eip155:8453",
    payload: { signature: "0x...", authorization: { from, to, value, ... } } }

The payload is base64-encoded and sent as the `payment-signature` header.
"""

from __future__ import annotations

import base64
import json
import os
import time
from typing import Any, TypedDict

from eth_account import Account
from eth_account.messages import encode_typed_data


class PaymentAuthorization(TypedDict):
    """x402 PaymentPayload v1 format."""

    x402Version: int
    scheme: str
    network: str
    payload: dict[str, Any]


def _get_usdc_domain_name(chain_id: int) -> str:
    """Return the EIP-712 domain name for USDC on Base Mainnet."""
    return "USD Coin"


def sign_payment_authorization(
    *,
    private_key: str,
    from_address: str,
    to_address: str,
    amount: str,
    token_address: str,
    chain_id: int,
    network: str,
) -> dict[str, Any]:
    """Create an EIP-712 TransferWithAuthorization signature for USDC.

    Args:
        private_key: Hex-encoded private key (with or without 0x prefix).
        from_address: Sender wallet address.
        to_address: Recipient (merchant) address.
        amount: Amount in USDC human-readable units (e.g. "1.50").
        token_address: USDC contract address.
        chain_id: EVM chain ID (8453 for Base Mainnet).
        network: CAIP-2 network string (e.g. "eip155:8453").

    Returns:
        x402 PaymentPayload v1 dict.
    """
    # Convert human-readable amount to USDC base units (6 decimals)
    value = _parse_usdc_amount(amount)
    now = int(time.time())
    valid_after = now - 300
    valid_before = now + 3600
    nonce = "0x" + os.urandom(32).hex()

    domain_data = {
        "name": _get_usdc_domain_name(chain_id),
        "version": "2",
        "chainId": chain_id,
        "verifyingContract": token_address,
    }

    message_types = {
        "TransferWithAuthorization": [
            {"name": "from", "type": "address"},
            {"name": "to", "type": "address"},
            {"name": "value", "type": "uint256"},
            {"name": "validAfter", "type": "uint256"},
            {"name": "validBefore", "type": "uint256"},
            {"name": "nonce", "type": "bytes32"},
        ],
    }

    message_data = {
        "from": from_address,
        "to": to_address,
        "value": value,
        "validAfter": valid_after,
        "validBefore": valid_before,
        "nonce": bytes.fromhex(nonce[2:]),
    }

    signable = encode_typed_data(
        domain_data=domain_data,
        message_types=message_types,
        message_data=message_data,
    )
    signed = Account.sign_message(signable, private_key=private_key)

    # x402 PaymentPayload v1 format
    return {
        "x402Version": 1,
        "scheme": "exact",
        "network": network,
        "payload": {
            "signature": "0x" + (signed.signature.hex() if isinstance(signed.signature, bytes) else format(signed.signature, 'x')),
            "authorization": {
                "from": from_address,
                "to": to_address,
                "value": str(value),
                "validAfter": str(valid_after),
                "validBefore": str(valid_before),
                "nonce": nonce,
            },
        },
    }


def encode_payment_header(auth: dict[str, Any]) -> str:
    """Base64-encode a PaymentPayload dict for the payment-signature header."""
    return base64.b64encode(json.dumps(auth).encode()).decode()


def _parse_usdc_amount(amount: str) -> int:
    """Convert a human-readable USDC amount to base units (6 decimals).

    Examples:
        "1.50" -> 1500000
        "10"   -> 10000000
        "0.01" -> 10000
    """
    parts = amount.split(".")
    whole = int(parts[0])
    if len(parts) == 1:
        return whole * 1_000_000

    # Pad or truncate fractional part to 6 digits
    frac_str = parts[1][:6].ljust(6, "0")
    return whole * 1_000_000 + int(frac_str)
