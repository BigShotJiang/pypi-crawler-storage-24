from __future__ import annotations

import importlib
import uuid

import pytest

from optdep.core import OptionalDependencyFinder, add, optional_dependencies


@pytest.fixture(autouse=True)
def clear_optional_dependencies():
    optional_dependencies.clear()
    yield
    optional_dependencies.clear()


def test_add_registers_module_with_metadata():
    add("json", "mypkg", "speedup")

    assert optional_dependencies["json"] == ("mypkg", "speedup")


def test_add_skip_keeps_existing_value():
    add("json", "pkg_a", "a")
    add("json", "pkg_b", "b", exist_behavior="skip")

    assert optional_dependencies["json"] == ("pkg_a", "a")


def test_add_overwrite_replaces_existing_value():
    add("json", "pkg_a", "a")
    add("json", "pkg_b", "b", exist_behavior="overwrite")

    assert optional_dependencies["json"] == ("pkg_b", "b")


def test_add_error_behavior_raises_runtime_error():
    add("json")

    with pytest.raises(RuntimeError):
        add("json", exist_behavior="error")


def test_add_rejects_invalid_argument_types():
    with pytest.raises(TypeError):
        add(123)  # type: ignore[arg-type]

    with pytest.raises(TypeError):
        add("json", this_pkg_name=1)  # type: ignore[arg-type]

    with pytest.raises(TypeError):
        add("json", extra=1)  # type: ignore[arg-type]


def test_add_rejects_invalid_exist_behavior():
    add("json")

    with pytest.raises(ValueError):
        add("json", exist_behavior="invalid")  # type: ignore[arg-type]


def test_finder_raises_importerror_with_install_hint_for_missing_module():
    module_name = f"_missing_optdep_{uuid.uuid4().hex}"
    add(module_name, "mypkg", "feature_x")

    with pytest.raises(ImportError, match=r"Optional dependency .* is not installed"):
        importlib.import_module(module_name)


def test_finder_returns_spec_when_dependency_exists():
    add("json")
    finder = OptionalDependencyFinder()

    spec = finder.find_spec("json")

    assert spec is not None
