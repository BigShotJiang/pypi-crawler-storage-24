import importlib.util
import typing
import sys

__all__ = [
    'add',
    'optional_dependencies',
]

optional_dependencies: typing.Dict[str, typing.Tuple[typing.Optional[str], typing.Optional[str]]] = {}


class OptionalDependencyFinder:
    def find_spec(self, name: str, path=None, target=None):
        if name not in optional_dependencies:
            return None
        original_meta_path = sys.meta_path
        try:
            sys.meta_path = [f for f in original_meta_path if f is not self]
            spec = importlib.util.find_spec(name)
        finally:
            sys.meta_path = original_meta_path
        if spec is None:
            msg = f'Optional dependency {name} is not installed. '
            this_pkg_name, extra = optional_dependencies[name]
            if this_pkg_name is not None and extra is not None:
                msg += f'You may install it with {this_pkg_name} by: `pip install {this_pkg_name}[{extra}]`'
            raise ImportError(msg, name=name)
        return spec


def _check_str_or_none(obj: typing.Any, name: str):
    if obj is not None and not isinstance(obj, str):
        raise TypeError(f'{name} must be a str or None, got {type(obj).__name__}')


def add(
    module_name: str,
    this_pkg_name: typing.Optional[str] = None,
    extra: typing.Optional[str] = None,
    exist_behavior: typing.Literal['skip', 'overwrite', 'error'] = 'skip',
) -> None:
    if not isinstance(module_name, str):
        raise TypeError(f'module_name must be str, got {type(module_name).__name__}')
    _check_str_or_none(this_pkg_name, 'this_pkg_name')
    _check_str_or_none(extra, 'extra')

    if module_name not in optional_dependencies:
        optional_dependencies[module_name] = (this_pkg_name, extra)
        return

    if exist_behavior == 'skip':
        pass
    elif exist_behavior == 'overwrite':
        optional_dependencies[module_name] = (this_pkg_name, extra)
    elif exist_behavior == 'error':
        raise RuntimeError(f'{module_name} already exists in ')
    else:
        raise ValueError(f'exist_behavior must be one of skip, overwrite, error')


def register_hook() -> None:
    finder = OptionalDependencyFinder()
    if finder not in sys.meta_path:
        sys.meta_path.append(finder)


register_hook()
