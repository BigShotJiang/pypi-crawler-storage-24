# handle connection to/from plugin
from __future__ import annotations

from typing import Any, AsyncGenerator
import logging

from langbot_plugin.runtime.io import handler, connection
from langbot_plugin.entities.io.actions.enums import (
    PluginToRuntimeAction,
    RuntimeToPluginAction,
    RuntimeToLangBotAction,
)
from langbot_plugin.runtime import context as context_module
import asyncio
from langbot_plugin.runtime.settings import settings as runtime_settings

logger = logging.getLogger(__name__)

# Timeout for long-running operations like command execution and tool calls (3 minutes)
LONG_RUNNING_OPERATION_TIMEOUT = 180.0


class PluginConnectionHandler(handler.Handler):
    """The handler for plugin connection."""

    context: context_module.RuntimeContext

    debug_plugin: bool = False
    """If this plugin is a debug plugin."""

    stdio_process: asyncio.subprocess.Process | None = None
    """The stdio process of the plugin."""

    subprocess_on_windows_task: asyncio.Task | None = None
    """The task for the subprocess on Windows."""

    def __init__(
        self,
        connection: connection.Connection,
        context: context_module.RuntimeContext,
        stdio_process: asyncio.subprocess.Process | None = None,
        debug_plugin: bool = False,
    ):
        async def disconnect_callback(hdl: handler.Handler):
            logger.debug("disconnect_callback")
            for plugin_container in self.context.plugin_mgr.plugins:
                if plugin_container._runtime_plugin_handler == self:
                    logger.info(
                        f"Removing plugin {plugin_container.manifest.metadata.name} due to disconnect"
                    )
                    await self.context.plugin_mgr.remove_plugin_container(
                        plugin_container
                    )
                    break

        super().__init__(connection, disconnect_callback)
        self.context = context
        self.name = "FromPlugin"
        self.debug_plugin = debug_plugin
        self.stdio_process = stdio_process

        @self.action(PluginToRuntimeAction.REGISTER_PLUGIN)
        async def register_plugin(data: dict[str, Any]) -> handler.ActionResponse:

            if "prod_mode" in data and data["prod_mode"]:
                self.debug_plugin = False

            # Verify PLUGIN_DEBUG_KEY if it's set in runtime settings
            if runtime_settings.plugin_debug_key:
                # Get the debug key from plugin data
                plugin_debug_key = data.get("plugin_debug_key", "")

                if plugin_debug_key != runtime_settings.plugin_debug_key:
                    logger.warning(
                        f"Plugin debug key verification failed. Expected key does not match."
                    )
                    return handler.ActionResponse.error(
                        "Plugin debug key verification failed"
                    )

            await self.context.plugin_mgr.register_plugin(
                self, data["plugin_container"], self.debug_plugin
            )
            return handler.ActionResponse.success({})

        @self.action(PluginToRuntimeAction.REPLY_MESSAGE)
        async def reply_message(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.REPLY_MESSAGE,
                {
                    **data,
                },
                timeout=180,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_BOT_UUID)
        async def get_bot_uuid(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.GET_BOT_UUID,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.SET_QUERY_VAR)
        async def set_query_var(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.SET_QUERY_VAR,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_QUERY_VAR)
        async def get_query_var(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.GET_QUERY_VAR,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_QUERY_VARS)
        async def get_query_vars(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.GET_QUERY_VARS,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.CREATE_NEW_CONVERSATION)
        async def create_new_conversation(
            data: dict[str, Any],
        ) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.CREATE_NEW_CONVERSATION,
                {
                    "query_id": data["query_id"],
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_LANGBOT_VERSION)
        async def get_langbot_version(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.GET_LANGBOT_VERSION,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_BOTS)
        async def get_bots(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.GET_BOTS,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_BOT_INFO)
        async def get_bot_info(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.GET_BOT_INFO,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.SEND_MESSAGE)
        async def send_message(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.SEND_MESSAGE,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_LLM_MODELS)
        async def get_llm_models(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.GET_LLM_MODELS,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        # @self.action(PluginToRuntimeAction.GET_LLM_MODEL_INFO)
        # async def get_llm_model_info(data: dict[str, Any]) -> handler.ActionResponse:
        #     result = await self.context.control_handler.call_action(
        #         PluginToRuntimeAction.GET_LLM_MODEL_INFO,
        #         {
        #             **data,
        #         },
        #     )
        #     return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.INVOKE_LLM)
        async def invoke_llm(data: dict[str, Any]) -> handler.ActionResponse:
            timeout = data.pop("timeout", 15.0)
            if not isinstance(timeout, (int, float)) or timeout <= 0:
                timeout = 15.0

            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.INVOKE_LLM,
                {
                    **data,
                },
                timeout=float(timeout),
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.INVOKE_EMBEDDING)
        async def invoke_embedding(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.INVOKE_EMBEDDING,
                {
                    **data,
                },
                timeout=60,
            )
            return handler.ActionResponse.success(result)

        # ================= RAG Capability Handlers (Plugin -> Runtime -> Host) =================

        async def _proxy_rag_action(
            action: PluginToRuntimeAction,
            data: dict[str, Any],
            timeout: float = 30,
        ) -> dict[str, Any]:
            """Proxy a RAG action to the control handler with error handling.

            Raises:
                Exception: Re-raises with context if the upstream call fails.
            """
            try:
                return await self.context.control_handler.call_action(
                    action,
                    data,
                    timeout=timeout,
                )
            except Exception as e:
                logger.error(f"RAG proxy error [{action.value}]: {e}")
                raise

        @self.action(PluginToRuntimeAction.VECTOR_UPSERT)
        async def vector_upsert(data: dict[str, Any]) -> handler.ActionResponse:
            result = await _proxy_rag_action(
                PluginToRuntimeAction.VECTOR_UPSERT,
                data,
                timeout=60,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.VECTOR_SEARCH)
        async def vector_search(data: dict[str, Any]) -> handler.ActionResponse:
            result = await _proxy_rag_action(
                PluginToRuntimeAction.VECTOR_SEARCH,
                data,
                timeout=30,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.VECTOR_DELETE)
        async def vector_delete(data: dict[str, Any]) -> handler.ActionResponse:
            result = await _proxy_rag_action(
                PluginToRuntimeAction.VECTOR_DELETE,
                data,
                timeout=30,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_KNOWLEDEGE_FILE_STREAM)
        async def get_knowledge_file_stream(data: dict[str, Any]) -> handler.ActionResponse:
            """Forward file stream from LangBot to plugin via chunked transfer."""
            result = await _proxy_rag_action(
                PluginToRuntimeAction.GET_KNOWLEDEGE_FILE_STREAM,
                data,
                timeout=60,
            )
            # LangBot sent the file via FILE_CHUNK; read from local temp
            file_key = result.get("file_key", "")
            if file_key:
                file_bytes = await self.read_local_file(file_key)
                await self.delete_local_file(file_key)
                # Forward to plugin subprocess via chunked transfer
                plugin_file_key = await self.send_file(file_bytes, "")
                return handler.ActionResponse.success({"file_key": plugin_file_key})
            return handler.ActionResponse.success(result)

        # ================= Knowledge Base Query Handlers (Plugin -> Runtime -> Host) =================

        @self.action(PluginToRuntimeAction.LIST_KNOWLEDGE_BASES)
        async def list_knowledge_bases(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.LIST_KNOWLEDGE_BASES,
                data,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.RETRIEVE_KNOWLEDGE)
        async def retrieve_knowledge(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.RETRIEVE_KNOWLEDGE,
                data,
                timeout=30,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.LIST_PIPELINE_KNOWLEDGE_BASES)
        async def list_pipeline_knowledge_bases(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.LIST_PIPELINE_KNOWLEDGE_BASES,
                data,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.RETRIEVE_KNOWLEDGE_BASE)
        async def retrieve_knowledge_base(data: dict[str, Any]) -> handler.ActionResponse:
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.RETRIEVE_KNOWLEDGE_BASE,
                data,
                timeout=30,
            )
            return handler.ActionResponse.success(result)

        # ================= Parser Capability Handlers (Plugin -> Runtime -> Host) =================

        @self.action(PluginToRuntimeAction.LIST_PARSERS)
        async def list_parsers(data: dict[str, Any]) -> handler.ActionResponse:
            """Plugin requests host to list available parser plugins."""
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.LIST_PARSERS,
                data,
                timeout=30,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.INVOKE_PARSER)
        async def invoke_parser(data: dict[str, Any]) -> handler.ActionResponse:
            """Plugin requests host to invoke a parser plugin."""
            result = await self.context.control_handler.call_action(
                PluginToRuntimeAction.INVOKE_PARSER,
                data,
                timeout=300,
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.SET_PLUGIN_STORAGE)
        async def set_plugin_storage(data: dict[str, Any]) -> handler.ActionResponse:
            data["owner_type"] = "plugin"

            for plugin_container in self.context.plugin_mgr.plugins:
                if plugin_container._runtime_plugin_handler == self:
                    data["owner"] = (
                        f"{plugin_container.manifest.metadata.author}/{plugin_container.manifest.metadata.name}"
                    )
                    break

            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.SET_BINARY_STORAGE,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_PLUGIN_STORAGE)
        async def get_plugin_storage(data: dict[str, Any]) -> handler.ActionResponse:
            data["owner_type"] = "plugin"

            for plugin_container in self.context.plugin_mgr.plugins:
                if plugin_container._runtime_plugin_handler == self:
                    data["owner"] = (
                        f"{plugin_container.manifest.metadata.author}/{plugin_container.manifest.metadata.name}"
                    )
                    break

            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.GET_BINARY_STORAGE,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_PLUGIN_STORAGE_KEYS)
        async def get_plugin_storage_keys(
            data: dict[str, Any],
        ) -> handler.ActionResponse:
            data["owner_type"] = "plugin"

            for plugin_container in self.context.plugin_mgr.plugins:
                if plugin_container._runtime_plugin_handler == self:
                    data["owner"] = (
                        f"{plugin_container.manifest.metadata.author}/{plugin_container.manifest.metadata.name}"
                    )
                    break

            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.GET_BINARY_STORAGE_KEYS,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.DELETE_PLUGIN_STORAGE)
        async def delete_plugin_storage(data: dict[str, Any]) -> handler.ActionResponse:
            data["owner_type"] = "plugin"

            for plugin_container in self.context.plugin_mgr.plugins:
                if plugin_container._runtime_plugin_handler == self:
                    data["owner"] = (
                        f"{plugin_container.manifest.metadata.author}/{plugin_container.manifest.metadata.name}"
                    )
                    break

            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.DELETE_BINARY_STORAGE,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.SET_WORKSPACE_STORAGE)
        async def set_workspace_storage(data: dict[str, Any]) -> handler.ActionResponse:
            data["owner_type"] = "workspace"
            data["owner"] = "default"

            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.SET_BINARY_STORAGE,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_WORKSPACE_STORAGE)
        async def get_workspace_storage(data: dict[str, Any]) -> handler.ActionResponse:
            data["owner_type"] = "workspace"
            data["owner"] = "default"

            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.GET_BINARY_STORAGE,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_WORKSPACE_STORAGE_KEYS)
        async def get_workspace_storage_keys(
            data: dict[str, Any],
        ) -> handler.ActionResponse:
            data["owner_type"] = "workspace"
            data["owner"] = "default"

            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.GET_BINARY_STORAGE_KEYS,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.DELETE_WORKSPACE_STORAGE)
        async def delete_workspace_storage(
            data: dict[str, Any],
        ) -> handler.ActionResponse:
            data["owner_type"] = "workspace"
            data["owner"] = "default"

            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.DELETE_BINARY_STORAGE,
                {
                    **data,
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.GET_CONFIG_FILE)
        async def get_config_file(data: dict[str, Any]) -> handler.ActionResponse:
            """Get a config file by file key"""
            # Forward the request to LangBot
            result = await self.context.control_handler.call_action(
                RuntimeToLangBotAction.GET_CONFIG_FILE,
                {
                    "file_key": data["file_key"],
                },
            )
            return handler.ActionResponse.success(result)

        @self.action(PluginToRuntimeAction.LIST_COMMANDS)
        async def list_commands(data: dict[str, Any]) -> handler.ActionResponse:
            commands = await self.context.plugin_mgr.list_commands()
            return handler.ActionResponse.success(
                {"commands": [command.model_dump() for command in commands]}
            )

        @self.action(PluginToRuntimeAction.LIST_TOOLS)
        async def list_tools(data: dict[str, Any]) -> handler.ActionResponse:
            tools = await self.context.plugin_mgr.list_tools()
            return handler.ActionResponse.success(
                {"tools": [tool.model_dump() for tool in tools]}
            )

        @self.action(PluginToRuntimeAction.LIST_PLUGINS_MANIFEST)
        async def list_plugins_manifest(data: dict[str, Any]) -> handler.ActionResponse:
            return handler.ActionResponse.success(
                {
                    "plugins": [
                        plugin.model_dump()["manifest"]
                        for plugin in self.context.plugin_mgr.plugins
                    ]
                }
            )

    async def initialize_plugin(
        self, plugin_settings: dict[str, Any]
    ) -> dict[str, Any]:
        resp = await self.call_action(
            RuntimeToPluginAction.INITIALIZE_PLUGIN,
            {"plugin_settings": plugin_settings},
        )

        return resp

    async def get_plugin_container(self) -> dict[str, Any]:
        resp = await self.call_action(RuntimeToPluginAction.GET_PLUGIN_CONTAINER, {})

        return resp

    async def get_plugin_icon(self) -> dict[str, Any]:
        resp = await self.call_action(RuntimeToPluginAction.GET_PLUGIN_ICON, {})
        return resp

    async def get_plugin_readme(self, language: str) -> dict[str, Any]:
        resp = await self.call_action(
            RuntimeToPluginAction.GET_PLUGIN_README, {"language": language}
        )
        return resp

    async def get_plugin_assets_file(self, file_key: str) -> dict[str, Any]:
        resp = await self.call_action(
            RuntimeToPluginAction.GET_PLUGIN_ASSETS_FILE, {"file_key": file_key}
        )
        return resp

    async def emit_event(self, event_context: dict[str, Any]) -> dict[str, Any]:
        resp = await self.call_action(
            RuntimeToPluginAction.EMIT_EVENT,
            {"event_context": event_context},
            timeout=LONG_RUNNING_OPERATION_TIMEOUT,
        )

        return resp

    async def call_tool(
        self,
        tool_name: str,
        tool_parameters: dict[str, Any],
        session: dict[str, Any],
        query_id: int,
    ) -> dict[str, Any]:
        resp = await self.call_action(
            RuntimeToPluginAction.CALL_TOOL,
            {
                "tool_name": tool_name,
                "tool_parameters": tool_parameters,
                "session": session,
                "query_id": query_id,
            },
            timeout=LONG_RUNNING_OPERATION_TIMEOUT,
        )

        return resp

    async def execute_command(
        self, command_context: dict[str, Any]
    ) -> AsyncGenerator[dict[str, Any], None]:
        gen = self.call_action_generator(
            RuntimeToPluginAction.EXECUTE_COMMAND,
            {"command_context": command_context},
            timeout=LONG_RUNNING_OPERATION_TIMEOUT,
        )

        async for resp in gen:
            yield resp

    async def retrieve_knowledge(
        self, retriever_name: str, retrieval_context: dict[str, Any]
    ) -> dict[str, Any]:
        resp = await self.call_action(
            RuntimeToPluginAction.RETRIEVE_KNOWLEDGE,
            {"retriever_name": retriever_name, "retrieval_context": retrieval_context},
        )
        return resp

    async def shutdown_plugin(self) -> dict[str, Any]:
        """Send shutdown notification to the plugin.

        For debug plugins, this will trigger reconnection.
        For production plugins, this is just a notification before shutdown.
        """
        resp = await self.call_action(
            RuntimeToPluginAction.SHUTDOWN,
            {},
        )
        return resp

    # ================= Knowledge Engine Methods =================

    async def rag_ingest_document(self, context_data: dict[str, Any]) -> dict[str, Any]:
        """Call plugin to ingest a document."""
        resp = await self.call_action(
            RuntimeToPluginAction.INGEST_DOCUMENT,
            {"context": context_data},
            timeout=1200,  # Ingestion can be slow for large documents
        )
        return resp

    async def rag_delete_document(self, kb_id: str, document_id: str) -> dict[str, Any]:
        """Call plugin to delete a document."""
        resp = await self.call_action(
            RuntimeToPluginAction.DELETE_DOCUMENT,
            {"kb_id": kb_id, "document_id": document_id},
            timeout=30,
        )
        return resp

    async def rag_on_kb_create(
        self, kb_id: str, config: dict[str, Any]
    ) -> dict[str, Any]:
        """Notify plugin about KB creation."""
        resp = await self.call_action(
            RuntimeToPluginAction.ON_KB_CREATE,
            {"kb_id": kb_id, "config": config},
            timeout=30,
        )
        return resp

    async def rag_on_kb_delete(self, kb_id: str) -> dict[str, Any]:
        """Notify plugin about KB deletion."""
        resp = await self.call_action(
            RuntimeToPluginAction.ON_KB_DELETE, {"kb_id": kb_id}, timeout=30
        )
        return resp

    async def get_rag_capabilities(self) -> dict[str, Any]:
        """Get RAG capabilities from plugin."""
        resp = await self.call_action(
            RuntimeToPluginAction.GET_RAG_CAPABILITIES, {}, timeout=10
        )
        return resp

    # ================= Parser Methods =================

    async def parse_document(self, context_data: dict[str, Any], file_bytes: bytes) -> dict[str, Any]:
        """Call plugin to parse a document.

        Sends file content via chunked FILE_CHUNK transfer, then invokes
        the PARSE_DOCUMENT action with a file_key reference.
        """
        file_key = await self.send_file(file_bytes, "")
        context_data["file_key"] = file_key

        resp = await self.call_action(
            RuntimeToPluginAction.PARSE_DOCUMENT,
            {"context": context_data},
            timeout=300,
        )
        return resp
