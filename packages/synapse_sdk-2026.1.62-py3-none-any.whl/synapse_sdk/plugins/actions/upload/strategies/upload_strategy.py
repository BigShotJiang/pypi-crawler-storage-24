"""Upload strategies for file upload operations.

Provides strategies for uploading files to storage:
    - SyncUploadStrategy: Synchronous upload with presigned URL support
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from synapse_sdk.clients.backend.bulk_upload import PRESIGNED_UPLOAD_PROVIDERS
from synapse_sdk.plugins.actions.upload.enums import LogCode, UploadStatus
from synapse_sdk.plugins.actions.upload.strategies.base import (
    UploadConfig,
    UploadStrategy,
)

if TYPE_CHECKING:
    from synapse_sdk.plugins.actions.upload.context import UploadContext


def is_valid_file_for_upload(file_path: Path | None, *, min_size: int = 1) -> bool:
    """Check if file is valid for upload.

    Args:
        file_path: Path to the file.
        min_size: Minimum file size in bytes (default: 1, meaning non-empty).

    Returns:
        True if file exists and meets minimum size requirement.
    """
    if not file_path:
        return False
    if not hasattr(file_path, 'exists') or not file_path.exists():
        return False
    try:
        return file_path.stat().st_size >= min_size
    except (OSError, IOError, AttributeError):
        return False


class SyncUploadStrategy(UploadStrategy):
    """Synchronous upload strategy with presigned URL support.

    Automatically uses presigned URL uploads if the storage provider
    supports it, otherwise falls back to traditional upload through
    the API server.

    Supported presigned upload providers:
        - Amazon S3
        - MinIO
        - Google Cloud Storage (GCS)
        - Azure Blob Storage

    Example:
        >>> strategy = SyncUploadStrategy(context)
        >>> config = UploadConfig(chunked_threshold_mb=100)
        >>> uploaded = strategy.upload(organized_files, config)
    """

    def __init__(self, context: UploadContext):
        """Initialize with upload context.

        Args:
            context: UploadContext with client and parameters.
        """
        super().__init__(context)

    def _filter_invalid_non_required_files(
        self,
        organized_file: dict[str, Any],
        file_specs: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Remove invalid non-required files from organized file dict.

        Invalid files (empty, missing, corrupted) that are not required
        will be silently removed to allow upload to proceed with valid files.

        Args:
            organized_file: Dict with 'files' mapping spec_name to Path.
            file_specs: List of file specifications with is_required flag.

        Returns:
            Filtered organized_file with invalid non-required files removed.
        """
        required_specs = {spec['name'] for spec in file_specs if spec.get('is_required', False)}
        filtered_files: dict[str, Path] = {}

        for spec_name, file_path in organized_file.get('files', {}).items():
            is_required = spec_name in required_specs

            if is_required:
                # Required files must be included (API handles validation)
                filtered_files[spec_name] = file_path
            else:
                # Non-required: only include if valid
                if is_valid_file_for_upload(file_path):
                    filtered_files[spec_name] = file_path
                else:
                    # Log internally (not user-facing, level=None)
                    self._log(
                        LogCode.SKIPPED_INVALID_NON_REQUIRED_FILE,
                        f'{spec_name}: {file_path}',
                    )

        return {**organized_file, 'files': filtered_files}

    def upload(
        self,
        files: list[dict[str, Any]],
        config: UploadConfig,
    ) -> list[dict[str, Any]]:
        """Upload files synchronously.

        Automatically selects presigned or traditional upload based on
        storage provider capabilities. Invalid non-required files are
        filtered out before upload to prevent unnecessary failures.

        Args:
            files: List of organized file dictionaries to upload.
            config: Upload configuration.

        Returns:
            List of uploaded file information dictionaries.
        """
        if not files:
            return []

        # Get file specs to determine which files are required
        file_specs = []
        if self.context.data_collection:
            file_specs = self.context.data_collection.get('file_specifications', [])

        # Filter invalid non-required files from each organized file
        filtered_files = [self._filter_invalid_non_required_files(f, file_specs) for f in files]

        # Remove entries with no files left after filtering
        filtered_files = [f for f in filtered_files if f.get('files')]

        if not filtered_files:
            return []

        client = self.context.client

        # Check if presigned upload is supported
        # Skip presigned upload for remote paths (SynologyPath 등) - they require
        # content download first, which traditional upload handles via create_data_file
        has_remote_files = any(
            not isinstance(fp, (str, Path)) for f in filtered_files for fp in f.get('files', {}).values()
        )

        if config.use_presigned and not has_remote_files:
            try:
                storage = client.get_default_storage()
                if self._storage_supports_presigned(storage):
                    return self._upload_with_presigned_urls(filtered_files, config)
            except ValueError as e:
                self._log(
                    LogCode.FILE_UPLOAD_FAILED,
                    f'Storage configuration error, falling back to traditional upload: {e}',
                )
            except Exception as e:
                self._log(
                    LogCode.FILE_UPLOAD_FAILED,
                    f'Presigned upload check failed, falling back to traditional upload: {e}',
                )

        # Fallback to traditional upload
        return self._upload_traditional(filtered_files, config)

    def _storage_supports_presigned(self, storage: dict[str, Any]) -> bool:
        """Check if storage provider supports presigned uploads."""
        provider = storage.get('provider', '').lower()
        return provider in PRESIGNED_UPLOAD_PROVIDERS

    def _upload_with_presigned_urls(
        self,
        files: list[dict[str, Any]],
        config: UploadConfig,
    ) -> list[dict[str, Any]]:
        """Upload files using presigned URLs.

        Args:
            files: Organized files to upload.
            config: Upload configuration.

        Returns:
            List of uploaded file information.
        """
        client = self.context.client
        collection_id = self.context.params.get('data_collection')

        # Extract file paths and create mapping
        file_paths: list[Path] = []
        file_mapping: dict[Path, dict[str, Any]] = {}

        for organized_file in files:
            for file_key, file_path in organized_file.get('files', {}).items():
                if hasattr(file_path, 'exists') and file_path.exists():
                    file_paths.append(file_path)
                    file_mapping[file_path] = organized_file

        if not file_paths:
            return []

        # Build filename to path mapping for result processing
        filename_to_path = {path.name: path for path in file_paths}
        uploaded_files: list[dict[str, Any]] = []

        def on_progress(completed: int, total: int) -> None:
            self.context.set_progress(completed, total, step='upload_data_files')

        try:
            result = client.upload_files_bulk(
                file_paths,
                max_workers=config.max_workers,
                batch_size=200,
                on_progress=on_progress,
            )

            # Process results
            for file_result in result.results:
                filename = file_result.file_key.split('/')[-1] if '/' in file_result.file_key else file_result.file_key
                file_path = filename_to_path.get(filename)

                if not file_path:
                    self._log(
                        LogCode.FILE_UPLOAD_FAILED,
                        f'Received result for unknown file: {file_result.file_key}',
                    )
                    continue

                organized_file = file_mapping.get(file_path)
                if not organized_file:
                    continue

                if file_result.success:
                    self._log_status(organized_file, UploadStatus.SUCCESS)
                    uploaded_files.append({
                        'data_collection': collection_id,
                        'files': {
                            k: {'checksum': file_result.checksum, 'path': str(v)}
                            for k, v in organized_file.get('files', {}).items()
                        },
                        'meta': organized_file.get('meta', {}),
                    })
                else:
                    self._log_status(organized_file, UploadStatus.FAILED)
                    self._log(
                        LogCode.FILE_UPLOAD_FAILED,
                        f'{file_result.file_key}: {file_result.error}',
                    )

            return uploaded_files

        except Exception as e:
            self._log(
                LogCode.FILE_UPLOAD_FAILED,
                f'Presigned upload failed: {e}',
            )
            return self._upload_traditional(files, config)

    def _upload_traditional(
        self,
        files: list[dict[str, Any]],
        config: UploadConfig,
    ) -> list[dict[str, Any]]:
        """Upload files using traditional API server method.

        Args:
            files: Organized files to upload.
            config: Upload configuration.

        Returns:
            List of uploaded file information.
        """
        uploaded_files = []
        client = self.context.client
        collection_id = self.context.params.get('data_collection')

        for organized_file in files:
            try:
                use_chunked = self._requires_chunked_upload(organized_file, config)

                # Call client upload method
                uploaded = client.upload_data_file(
                    organized_file,
                    collection_id,
                    use_chunked_upload=use_chunked,
                )

                self._log_status(organized_file, UploadStatus.SUCCESS)
                uploaded_files.append(uploaded)

            except Exception as e:
                self._log_status(organized_file, UploadStatus.FAILED)
                self._log(LogCode.FILE_UPLOAD_FAILED, str(e))
                # Continue with other files

        return uploaded_files

    def _requires_chunked_upload(
        self,
        organized_file: dict[str, Any],
        config: UploadConfig,
    ) -> bool:
        """Check if any file exceeds chunked upload threshold."""
        threshold_bytes = config.chunked_threshold_mb * 1024 * 1024

        for file_path in organized_file.get('files', {}).values():
            try:
                if file_path.stat().st_size > threshold_bytes:
                    return True
            except (OSError, IOError, AttributeError):
                pass

        return False

    def _log(self, code: LogCode, message: str) -> None:
        """Log a message using the context's runtime context."""
        if hasattr(self.context, 'runtime_ctx') and self.context.runtime_ctx:
            self.context.log(code.value, {'message': message})

    def _log_status(
        self,
        organized_file: dict[str, Any],
        status: UploadStatus,
    ) -> None:
        """Log file upload status."""
        if hasattr(self.context, 'runtime_ctx') and self.context.runtime_ctx:
            self.context.log(
                LogCode.DATA_FILE_STATUS.value,
                {
                    'files': {k: str(v) for k, v in organized_file.get('files', {}).items()},
                    'status': status.value,
                },
            )


__all__ = [
    'is_valid_file_for_upload',
    'SyncUploadStrategy',
]
