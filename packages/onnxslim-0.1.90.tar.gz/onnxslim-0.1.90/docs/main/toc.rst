main
============

.. autoclass:: onnxslim.slim
