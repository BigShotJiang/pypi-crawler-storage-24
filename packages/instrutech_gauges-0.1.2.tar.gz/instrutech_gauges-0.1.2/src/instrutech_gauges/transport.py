from __future__ import annotations

import socket
from typing import Literal

import serial

from .exceptions import InstruTechError, InstruTechUnsupportedTransportOperationError


class BaseTransport:
    """Minimal transport interface used by InstruTechAsciiGauge."""

    supports_serial_reconfigure: bool = False
    command_terminator: bytes = b"\r"

    def open(self) -> None:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError

    @property
    def is_open(self) -> bool:
        raise NotImplementedError

    def write(self, data: bytes) -> None:
        raise NotImplementedError

    def read_until(self, terminator: bytes, timeout_s: float | None = None) -> bytes:
        raise NotImplementedError

    def flush_input(self) -> None:
        raise NotImplementedError

    def flush_output(self) -> None:
        raise NotImplementedError

    def set_baudrate(self, baudrate: int) -> None:
        raise InstruTechUnsupportedTransportOperationError(
            "Transport does not support runtime baudrate changes."
        )

    def set_parity(
        self,
        parity: Literal["N", "O", "E"],
        *,
        data_bits: Literal[7, 8] | None = None,
    ) -> None:
        raise InstruTechUnsupportedTransportOperationError(
            "Transport does not support runtime parity changes."
        )


class SerialTransport(BaseTransport):
    """Local serial transport (pyserial)."""

    supports_serial_reconfigure = True

    def __init__(
        self,
        port: str,
        *,
        baudrate: int = 19200,
        timeout_s: float = 0.25,
        bytesize: int = serial.EIGHTBITS,
        parity: str = serial.PARITY_NONE,
        stopbits: int = serial.STOPBITS_ONE,
    ) -> None:
        self.port = port
        self.baudrate = baudrate
        self.timeout_s = timeout_s
        self.bytesize = bytesize
        self.parity = parity
        self.stopbits = stopbits
        self._ser: serial.Serial | None = None

    def open(self) -> None:
        if self._ser is not None and self._ser.is_open:
            return
        self._ser = serial.Serial(
            port=self.port,
            baudrate=self.baudrate,
            timeout=self.timeout_s,
            write_timeout=self.timeout_s,
            bytesize=self.bytesize,
            parity=self.parity,
            stopbits=self.stopbits,
        )
        self.flush_input()
        self.flush_output()

    def close(self) -> None:
        if self._ser is not None and self._ser.is_open:
            self._ser.close()

    @property
    def is_open(self) -> bool:
        return bool(self._ser is not None and self._ser.is_open)

    def _require_open(self) -> serial.Serial:
        if self._ser is None or not self._ser.is_open:
            raise InstruTechError("SerialTransport is not open.")
        return self._ser

    def write(self, data: bytes) -> None:
        ser = self._require_open()
        ser.write(data)
        ser.flush()

    def read_until(self, terminator: bytes, timeout_s: float | None = None) -> bytes:
        ser = self._require_open()
        old_timeout = ser.timeout
        try:
            if timeout_s is not None:
                ser.timeout = timeout_s
            return ser.read_until(terminator)
        finally:
            ser.timeout = old_timeout

    def flush_input(self) -> None:
        self._require_open().reset_input_buffer()

    def flush_output(self) -> None:
        self._require_open().reset_output_buffer()

    def set_baudrate(self, baudrate: int) -> None:
        ser = self._require_open()
        ser.baudrate = baudrate
        self.baudrate = baudrate

    def set_parity(
        self,
        parity: Literal["N", "O", "E"],
        *,
        data_bits: Literal[7, 8] | None = None,
    ) -> None:
        ser = self._require_open()

        if parity == "N":
            ser.parity = serial.PARITY_NONE
            self.parity = serial.PARITY_NONE
        elif parity == "O":
            ser.parity = serial.PARITY_ODD
            self.parity = serial.PARITY_ODD
        elif parity == "E":
            ser.parity = serial.PARITY_EVEN
            self.parity = serial.PARITY_EVEN
        else:
            raise ValueError("parity must be one of 'N', 'O', 'E'")

        if data_bits is None:
            return

        if data_bits == 7:
            ser.bytesize = serial.SEVENBITS
            self.bytesize = serial.SEVENBITS
        elif data_bits == 8:
            ser.bytesize = serial.EIGHTBITS
            self.bytesize = serial.EIGHTBITS
        else:
            raise ValueError("data_bits must be 7 or 8")


class SocketTransport(BaseTransport):
    """TCP socket transport for RS485-to-Ethernet gateways."""

    supports_serial_reconfigure = False

    def __init__(
        self,
        host: str,
        port: int,
        *,
        timeout_s: float = 0.25,
        write_terminator: bytes = b"\r",
    ) -> None:
        self.host = host
        self.port = port
        self.timeout_s = timeout_s
        if not write_terminator:
            raise ValueError("write_terminator must not be empty")
        self.command_terminator = write_terminator
        self._sock: socket.socket | None = None
        self._rx_buf = bytearray()

    def open(self) -> None:
        if self._sock is not None:
            return
        sock = socket.create_connection((self.host, self.port), timeout=self.timeout_s)
        sock.settimeout(self.timeout_s)
        self._sock = sock
        self._rx_buf.clear()

    def close(self) -> None:
        if self._sock is not None:
            try:
                self._sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._sock.close()
            self._sock = None
            self._rx_buf.clear()

    @property
    def is_open(self) -> bool:
        return self._sock is not None

    def _require_open(self) -> socket.socket:
        if self._sock is None:
            raise InstruTechError("SocketTransport is not open.")
        return self._sock

    def write(self, data: bytes) -> None:
        self._require_open().sendall(data)

    def read_until(self, terminator: bytes, timeout_s: float | None = None) -> bytes:
        sock = self._require_open()
        if len(terminator) != 1:
            raise ValueError("SocketTransport.read_until expects a 1-byte terminator.")
        term = terminator[0]

        old_timeout = sock.gettimeout()
        try:
            if timeout_s is not None:
                sock.settimeout(timeout_s)

            idx = self._rx_buf.find(term)
            if idx != -1:
                out = bytes(self._rx_buf[: idx + 1])
                del self._rx_buf[: idx + 1]
                return out

            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    out = bytes(self._rx_buf)
                    self._rx_buf.clear()
                    return out
                self._rx_buf.extend(chunk)
                idx = self._rx_buf.find(term)
                if idx != -1:
                    out = bytes(self._rx_buf[: idx + 1])
                    del self._rx_buf[: idx + 1]
                    return out
        finally:
            sock.settimeout(old_timeout)

    def flush_input(self) -> None:
        self._rx_buf.clear()

    def flush_output(self) -> None:
        # no-op at this layer
        pass
