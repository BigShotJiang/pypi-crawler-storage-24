from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Literal, cast

from .exceptions import (
    InstruTechDeviceError,
    InstruTechProtocolError,
    InstruTechReconfigureError,
    InstruTechTimeoutError,
    InstruTechUnsupportedTransportOperationError,
)
from .transport import BaseTransport


@dataclass(frozen=True)
class TripPoint:
    mode: Literal["on_below", "off_above"]
    value_torr: float


class InstruTechAsciiGauge:
    """
    Public base class for InstruTech ASCII gauges.

    Subclasses typically build higher-level command methods using:
    - `query(body)` for payload responses
    - `query_float(body)` for numeric responses
    - `command_prog_ok(body)` for commands that return PROGM_OK
    """

    _SCI_RE = re.compile(r"([+\-]?\d+(?:\.\d+)?[Ee][+\-]?\d+)")

    def __init__(
        self,
        transport: BaseTransport,
        *,
        address: int = 1,
        min_cmd_interval_s: float = 0.05,
    ) -> None:
        if not (0 <= address <= 0xFF):
            raise ValueError("address must be in [0, 255]")

        self.transport = transport
        self.address = address
        self.min_cmd_interval_s = min_cmd_interval_s
        self._last_tx = 0.0

    @property
    def address_hex(self) -> str:
        return f"{self.address:02X}"

    @property
    def is_open(self) -> bool:
        return self.transport.is_open

    def open(self, *, probe: bool = True) -> None:
        self.transport.open()
        self.transport.flush_input()
        self.transport.flush_output()
        if probe:
            self._probe_ascii_protocol()

    def close(self) -> None:
        self.transport.close()

    def __enter__(self) -> "InstruTechAsciiGauge":
        self.open(probe=True)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # --------------------- wire helpers ---------------------
    def _throttle(self) -> None:
        dt = time.monotonic() - self._last_tx
        if dt < self.min_cmd_interval_s:
            time.sleep(self.min_cmd_interval_s - dt)

    def _build_command(self, body: str) -> bytes:
        return (
            f"#{self.address_hex}{body}".encode("ascii")
            + self.transport.command_terminator
        )

    def _readline_cr(self, timeout_s: float | None = None) -> str:
        raw = self.transport.read_until(b"\r", timeout_s=timeout_s)
        if not raw:
            raise InstruTechTimeoutError("Timed out waiting for response.")
        try:
            return raw.decode("ascii", errors="strict")
        except UnicodeDecodeError as exc:
            raise InstruTechProtocolError(f"Non-ASCII response: {raw!r}") from exc

    def _parse_response(self, resp: str) -> str:
        line = resp.rstrip("\r\n")
        if not line:
            raise InstruTechProtocolError("Empty response.")
        if line[0] not in {"*", "?"}:
            raise InstruTechProtocolError(f"Malformed response: {resp!r}")
        if len(line) < 3:
            raise InstruTechProtocolError(f"Malformed response: {resp!r}")

        address = line[1:3].upper()
        try:
            int(address, 16)
        except ValueError as exc:
            raise InstruTechProtocolError(
                f"Malformed address field in response: {resp!r}"
            ) from exc

        if address != self.address_hex:
            raise InstruTechProtocolError(
                f"Response address mismatch: expected {self.address_hex}, got {address}"
            )

        payload = line[3:]
        if payload.startswith("_"):
            payload = payload[1:]
        payload = payload.strip()

        if line[0] == "?":
            code = payload.split("_", 1)[0] if payload else "UNKNOWN"
            raise InstruTechDeviceError(code=code, message=payload, raw=resp)

        return payload

    @staticmethod
    def _extract_float(payload: str) -> float:
        compact = payload.replace(" ", "")
        m = InstruTechAsciiGauge._SCI_RE.search(compact)
        if m:
            return float(m.group(1))
        try:
            return float(payload.strip())
        except ValueError as exc:
            raise InstruTechProtocolError(
                f"No numeric value in payload: {payload!r}"
            ) from exc

    @staticmethod
    def _assert_prog_ok(payload: str) -> None:
        if "PROGM_OK" not in payload:
            raise InstruTechProtocolError(f"Expected PROGM_OK, got {payload!r}")

    @staticmethod
    def _payload_token(payload: str) -> str:
        return payload.strip().split("_", 1)[0].strip()

    def _send(
        self,
        body: str,
        *,
        expect_response: bool = True,
        disrupts_link: bool = False,
        opportunistic_ack_window_s: float = 0.08,
    ) -> str | None:
        self._throttle()
        self.transport.write(self._build_command(body))
        self._last_tx = time.monotonic()

        if disrupts_link:
            # Best effort capture of old-link ACK, never required for success.
            try:
                maybe = self._readline_cr(timeout_s=opportunistic_ack_window_s).strip(
                    "\n"
                )
                try:
                    _ = self._parse_response(maybe)
                except Exception:
                    pass
            except Exception:
                pass
            return None

        if not expect_response:
            return None

        resp = self._readline_cr().strip("\n")
        return self._parse_response(resp)

    # --------------------- public command primitives ---------------------
    def query(self, body: str) -> str:
        payload = self._send(body)
        assert payload is not None
        return payload

    def query_float(self, body: str) -> float:
        return self._extract_float(self.query(body))

    def command_prog_ok(self, body: str) -> None:
        self._assert_prog_ok(self.query(body))

    # --------------------- common commands ---------------------
    def read_sw_version(self) -> str:
        return self.query("VER")

    def read_pressure_torr(self) -> float:
        return self.query_float("RD")

    def set_addr_offset_and_address(self, value: int) -> None:
        if not (0 <= value <= 0xFF):
            raise ValueError("value must be in [0, 255]")
        self.command_prog_ok(f"SA{value:02X}")

    def set_span(self, value_torr: float = 760.0) -> None:
        self.command_prog_ok(f"TS{value_torr:.2E}")

    def set_zero(self, value_torr: float = 0.0) -> None:
        self.command_prog_ok(f"TZ{value_torr:.2E}")

    def set_trip_point(
        self,
        relay: Literal[1, 2],
        mode: Literal["on_below", "off_above"],
        value_torr: float,
    ) -> None:
        sign = "+" if mode == "on_below" else "-"
        value = f"{abs(value_torr):.2E}"
        cmd = "SL" if relay == 1 else "SH"
        self.command_prog_ok(f"{cmd}{sign}{value}")

    def read_trip_point(
        self,
        relay: Literal[1, 2],
        mode: Literal["on_below", "off_above"],
    ) -> TripPoint:
        sign = "+" if mode == "on_below" else "-"
        cmd = "RL" if relay == 1 else "RH"
        value = self.query_float(f"{cmd}{sign}")
        return TripPoint(mode=mode, value_torr=value)

    def factory_defaults(self) -> None:
        self.command_prog_ok("FAC")

    def reset(self) -> None:
        self._send("RST", expect_response=False)

    # --------------------- serial reconfiguration ---------------------
    def _probe_ascii_protocol(self) -> None:
        try:
            _ = self.read_sw_version()
        except (InstruTechTimeoutError, InstruTechProtocolError) as exc:
            raise InstruTechProtocolError(
                "ASCII probe failed. Wrong address or serial settings."
            ) from exc

    def _relink_probe(self, *, retries: int = 3, delay_s: float = 0.2) -> None:
        last_exc: Exception | None = None
        for _ in range(retries):
            try:
                _ = self.read_sw_version()
                return
            except Exception as exc:
                last_exc = exc
                time.sleep(delay_s)
        raise InstruTechReconfigureError(
            "Failed to re-establish communication after serial reconfiguration."
        ) from last_exc

    def _require_reconfigurable_transport(self) -> None:
        if not self.transport.supports_serial_reconfigure:
            raise InstruTechUnsupportedTransportOperationError(
                "Changing serial comm settings is disabled for TCP/socket transport."
            )

    def _before_serial_reconfigure(self) -> None:
        # Hook for devices that require an unlock command.
        return

    def set_baud(
        self,
        baud: int,
        *,
        verify: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = False,
    ) -> None:
        self._require_reconfigurable_transport()
        self._before_serial_reconfigure()

        if reset_after:
            self.command_prog_ok(f"SB{baud}")
            self.reset()
        else:
            self._send(f"SB{baud}", disrupts_link=True)

        self.transport.set_baudrate(baud)

        time.sleep(relink_delay_s)
        self.transport.flush_input()
        self.transport.flush_output()

        if verify:
            self._relink_probe(retries=relink_retries, delay_s=relink_delay_s)

    def set_parity(
        self,
        parity: Literal["N", "O", "E"],
        *,
        verify: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = False,
        data_bits: Literal[7, 8] | None = None,
    ) -> None:
        self._require_reconfigurable_transport()

        p = parity.upper()
        if p not in {"N", "O", "E"}:
            raise ValueError("parity must be one of 'N', 'O', 'E'")
        p_lit = cast(Literal["N", "O", "E"], p)

        self._before_serial_reconfigure()

        if reset_after:
            self.command_prog_ok(f"SP{p_lit}")
            self.reset()
        else:
            self._send(f"SP{p_lit}", disrupts_link=True)

        self.transport.set_parity(p_lit, data_bits=data_bits)

        time.sleep(relink_delay_s)
        self.transport.flush_input()
        self.transport.flush_output()

        if verify:
            self._relink_probe(retries=relink_retries, delay_s=relink_delay_s)

    def set_serial_comm(
        self,
        *,
        baud: int | None = None,
        parity: Literal["N", "O", "E"] | None = None,
        verify_each_step: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = False,
        parity_data_bits: Literal[7, 8] | None = None,
    ) -> None:
        self._require_reconfigurable_transport()

        if parity is not None:
            self.set_parity(
                parity,
                verify=verify_each_step,
                relink_retries=relink_retries,
                relink_delay_s=relink_delay_s,
                reset_after=reset_after,
                data_bits=parity_data_bits,
            )
        if baud is not None:
            self.set_baud(
                baud,
                verify=verify_each_step,
                relink_retries=relink_retries,
                relink_delay_s=relink_delay_s,
                reset_after=reset_after,
            )
