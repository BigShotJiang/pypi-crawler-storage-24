from __future__ import annotations

from typing import Literal

from .base import InstruTechAsciiGauge, TripPoint


class VGC301(InstruTechAsciiGauge):
    """
    InstruTech VGC301 controller driver.

    Notes from the manual:
    - Default link settings are 19200, 8N1.
    - `SB*` / `SP*` / `SA*` / `FAC` become active after `RST`.
    - ODD/EVEN parity uses 7 data bits.
    """

    def read_system_pressure_torr(self) -> float:
        return self.read_pressure_torr()

    def set_trip_point(
        self,
        relay: Literal[1, 2],
        mode: Literal["on_below", "off_above"],
        value_torr: float,
    ) -> None:
        super().set_trip_point(relay, mode, value_torr)

    def read_trip_point(
        self,
        relay: Literal[1, 2],
        mode: Literal["on_below", "off_above"],
    ) -> TripPoint:
        return super().read_trip_point(relay, mode)

    # VGC301 serial programming commands require reset to take effect.
    def set_baud(
        self,
        baud: int,
        *,
        verify: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = True,
    ) -> None:
        super().set_baud(
            baud,
            verify=verify,
            relink_retries=relink_retries,
            relink_delay_s=relink_delay_s,
            reset_after=reset_after,
        )

    def set_parity(
        self,
        parity: Literal["N", "O", "E"],
        *,
        verify: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = True,
        data_bits: Literal[7, 8] | None = None,
    ) -> None:
        p = parity.upper()
        bits = data_bits
        if bits is None:
            bits = 8 if p == "N" else 7

        super().set_parity(
            parity,
            verify=verify,
            relink_retries=relink_retries,
            relink_delay_s=relink_delay_s,
            reset_after=reset_after,
            data_bits=bits,
        )

    def set_serial_comm(
        self,
        *,
        baud: int | None = None,
        parity: Literal["N", "O", "E"] | None = None,
        verify_each_step: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = True,
    ) -> None:
        bits: Literal[7, 8] | None = None
        if parity is not None:
            bits = 8 if parity.upper() == "N" else 7

        super().set_serial_comm(
            baud=baud,
            parity=parity,
            verify_each_step=verify_each_step,
            relink_retries=relink_retries,
            relink_delay_s=relink_delay_s,
            reset_after=reset_after,
            parity_data_bits=bits,
        )
