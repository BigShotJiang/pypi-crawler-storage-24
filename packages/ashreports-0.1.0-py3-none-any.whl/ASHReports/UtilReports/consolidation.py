# ==========================================================================================
# RETAIL STOCK OPTIMIZER V6 (Size Balanced) by Tanmoy Sarkar
#
# First, generate a Combined report with season start till now date range
# then, filter it based on requirement like Season, Carryover or Ramadan, etc.
# after filtering, save filtered combined report data in a new file.
# this new file will be the input for this report.
# ==========================================================================================

import os
import pandas as pd
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox, ttk


STORES = []
COLUMNS = []
# --------------------------------------------------------------------------------------------------
# METRICS CALCULATION
# --------------------------------------------------------------------------------------------------
def calculate_metrics(df):
    metrics = []
    for s in STORES:
        stock = df[f"{s}_Stock"].sum()
        sales = df[f"{s}_Sale"].sum()
        sell_thru = sales/(sales+stock+0.0001)
        weeks_cover = 0
        if sales > 0:
            weeks_cover = stock/sales

        metrics.append({"Store":s,"Stock":int(stock),"Sales":int(sales),"Sell_thru":round(sell_thru,3),"Weeks_cover":round(weeks_cover,2)})

    return pd.DataFrame(metrics)

# --------------------------------------------------------------------------------------------------
# SIZE PRIORITY DETECTION
# --------------------------------------------------------------------------------------------------
def detect_missing_sizes(group, store):
    missing = []
    for _,r in group.iterrows():
        if r[f"{store}_Stock"] == 0:
            missing.append(r["Size"])

    return set(missing)

# --------------------------------------------------------------------------------------------------
# TRANSFER ENGINE WITH SIZE BALANCING
# --------------------------------------------------------------------------------------------------
def generate_transfers(df,min_display=2):
    transfers = []
    locked_barcodes = set()
    groups = df.groupby(["Style Code","Colour Code"])

    for (style,color),g in groups:
        summary = []
        for s in STORES:
            stock = g[f"{s}_Stock"].sum()
            sales = g[f"{s}_Sale"].sum()
            stock = max(stock, 0)
            sales = max(sales, 0)
            demand_score = sales/(stock+1)
            summary.append({"Store":s,"Stock":stock,"Sales":sales,"Demand":demand_score})

        summary_df = pd.DataFrame(summary)
        receivers = summary_df[summary_df.Sales > summary_df.Stock]
        donors = summary_df[summary_df.Stock > (summary_df.Sales + min_display)]
        receivers = receivers.sort_values("Demand",ascending=False)
        donors = donors.sort_values("Demand")

        for _,rec in receivers.iterrows():
            need = int(rec.Sales - rec.Stock)
            if need <= 0:
                continue

            receiver_missing_sizes = detect_missing_sizes(g, rec.Store)
            for _,don in donors.iterrows():
                if don.Store == rec.Store:
                    continue

                available = int(don.Stock - don.Sales - min_display)
                if available <= 0:
                    continue

                transfer_qty = min(need,available)
                donor_rows = g[g[f"{don.Store}_Stock"] > 0].copy()

                # PRIORITIZE MISSING SIZES
                donor_rows["Size_priority"] = donor_rows["Size"].apply(lambda x: 0 if x in receiver_missing_sizes else 1)
                donor_rows = donor_rows.sort_values(["Size_priority"])

                for idx,row in donor_rows.iterrows():
                    if transfer_qty <= 0:
                        break

                    barcode = row.ItemNo_
                    if barcode in locked_barcodes:
                        continue

                    size_stock = int(row[f"{don.Store}_Stock"])
                    if size_stock <= 0:
                        continue

                    move_qty = min(size_stock,transfer_qty)
                    transfers.append([barcode, style, color, row.Size, don.Store, rec.Store, move_qty])
                    locked_barcodes.add(barcode)
                    df.at[idx,f"{don.Store}_Stock"] -= move_qty
                    transfer_qty -= move_qty
                    need -= move_qty

                if need <= 0:
                    break

    transfer_df = pd.DataFrame(transfers,columns=["ItemNo_","Style Code","Color Code","Size","Transfer_from","Transfer_to","Trf_Qty"])
    return transfer_df

# --------------------------------------------------------------------------------------------------
# EXPORT FILES
# --------------------------------------------------------------------------------------------------
def export_files(transfers,folder):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    generated_files = []

    for s in STORES:
        store_df = transfers[transfers.Transfer_from == s].copy()
        if len(store_df) > 0:
            #store_df = store_df.drop_duplicates(subset=["ItemNo_"])
            file_path = os.path.join(folder,f"{s}_transfer_{timestamp}.csv")
            store_df.to_csv(file_path,index=False)
            generated_files.append(file_path)

    combined_list = []
    for f in generated_files:
        df = pd.read_csv(f)
        combined_list.append(df)

    if len(combined_list) == 0:
        return

    combined_df = pd.concat(combined_list,ignore_index=True)
    combined_df["Combo-01"] = combined_df["Transfer_to"].astype(str) + "_" + combined_df["ItemNo_"].astype(str)
    #combined_df = combined_df.drop_duplicates(subset=["Combo-01"])
    master_file = os.path.join(folder,f"All_store_transfers_{timestamp}.csv")
    combined_df.to_csv(master_file,index=False)

# --------------------------------------------------------------------------------------------------
# DASHBOARD
# --------------------------------------------------------------------------------------------------
def update_dashboard(metrics):
    for row in tree.get_children():
        tree.delete(row)

    for _,r in metrics.iterrows():
        tree.insert("","end",values=(r.Store,r.Stock,r.Sales,r.Sell_thru,r.Weeks_cover))

# --------------------------------------------------------------------------------------------------
# RUN
# --------------------------------------------------------------------------------------------------
def run_optimizer():
    global STORES
    global COLUMNS
    file_path = entry_file.get()
    country = selected_item.get()
    season = selected_season.get()
    type = selected_types.get()

    if not os.path.exists(file_path):
        messagebox.showerror("Error","Please select valid CSV file")
        return

    try:
        min_display = int(entry_display.get())
        df = pd.read_csv(file_path)
        df = df[["Brand Code","Country","ShortName","Location Type","Status","RefCode","Style Code","Colour Code","Size","Item No_","Season Code","Remarks","Cumm. SaleQty","Closing Stock"]]
        df = df.rename(columns={"Item No_":"ItemNo_", "Cumm. SaleQty":"Sale", "Closing Stock":"Stock"})
        df = df.loc[df["Status"]=="Active"]
        df = df.loc[df["Location Type"]=="Store"]
        df = df.loc[df["Country"]==country]
        df = df.loc[df["Season Code"]==season]
        df = df.loc[df["Remarks"]==type]
        
        pivot = pd.pivot_table(
            df,
            index=["ItemNo_","Style Code","Colour Code","Size"],
            columns="ShortName",
            values=["Sale","Stock"],
            aggfunc="sum",
            fill_value=0
        )
        pivot = pivot.reset_index()
        # To concatenate multi level column of pivot df
        pivot.columns = [
            f"{col[1]}_{col[0]}" if isinstance(col, tuple) else col
            for col in pivot.columns
        ]
        pivot = pivot.rename(columns={"_ItemNo_":"ItemNo_", "_Style Code":"Style Code", "_Colour Code":"Colour Code", "_Size":"Size"})
        # Populate Global column variables
        STORES = df["ShortName"].unique().tolist()
        COLUMNS = pivot.columns.tolist()
        #pivot.to_csv("abc.csv", index=False)
        metrics = calculate_metrics(pivot)
        update_dashboard(metrics)
        transfers = generate_transfers(pivot,min_display)
        export_files(transfers,"C:/Reports/Output/Consolidation")
        messagebox.showinfo("Success","Transfer optimization complete.")

    except Exception as e:
        messagebox.showerror("Error",str(e))

# --------------------------------------------------------------------------------------------------
# FILE PICKER
# --------------------------------------------------------------------------------------------------
def browse_file():
    file_path = filedialog.askopenfilename(filetypes=[("CSV Files","*.csv")])

    if file_path:
        entry_file.delete(0,tk.END)
        entry_file.insert(0,file_path)

# --------------------------------------------------------------------------------------------------
# PREPROCESS SELECTED FILE
# --------------------------------------------------------------------------------------------------
def process_file():
    global countries
    global seasons
    global types
    file_path = entry_file.get()
    df = pd.read_csv(file_path)
    tmpCountryList = df["Country"].unique().tolist()
    tmpSeasonList = df["Season Code"].unique().tolist()
    tmpTypeList = df["Remarks"].unique().tolist()

    countries = tmpCountryList
    seasons = tmpSeasonList
    types = tmpTypeList

    dropdown_display["values"] = countries
    dropdown_display.current(0)
    entry_season["values"] = seasons
    entry_season.current(0)
    entry_type["values"] = types
    entry_type.current(0)
    #print(seasons)

# --------------------------------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------------------------------
root = tk.Tk()
root.title("Stock Optimizer And Size Balance Planner")
root.geometry("560x340")
countries = ["All"]
selected_item = tk.StringVar()
seasons = ["All"]
selected_season = tk.StringVar()
types = ["All"]
selected_types = tk.StringVar()

main = tk.Frame(root,padx=10,pady=5)
main.pack(fill="both",expand=True)

lbl_file = tk.Label(main,text="Combined Report File")
lbl_file.grid(row=0,column=0, sticky="w")

entry_file = tk.Entry(main,width=45)
entry_file.grid(row=1,column=0,sticky="ew")
#---------------------------------------------------------------------
btn_browse = tk.Button(main,text="Browse",command=browse_file)
btn_browse.grid(row=1,column=1,sticky="ew", padx=2)

btn_process = tk.Button(main,text="Process",command=process_file)
btn_process.grid(row=2,column=1,sticky="ew", padx=2)

run_btn = tk.Button(main,text="Run Transfer Optimization",command=run_optimizer)    # ,height=1,width=20
run_btn.grid(row=3,column=1, sticky="ew", pady=2)
#---------------------------------------------------------------------
lbl_display = tk.Label(main,text="Minimum Display Qty")
lbl_display.grid(row=2,column=0,sticky="w",pady=(2,0))

entry_display = tk.Entry(main,width=6)
entry_display.insert(0,"2")
entry_display.grid(row=3,column=0,sticky="w")
#---------------------------------------------------------------------
# Country
lbl_country = tk.Label(main,text="Select Country")
lbl_country.grid(row=4,column=0,sticky="w",pady=(2,0))

dropdown_display = ttk.Combobox(main, textvariable=selected_item, values=countries)
dropdown_display.grid(row=5,column=0,sticky="w")
dropdown_display.current(0)
#---------------------------------------------------------------------
# Season
lbl_season = tk.Label(main,text="Select Season")
lbl_season.grid(row=4,column=1,sticky="w",pady=(2,0))

entry_season = ttk.Combobox(main, textvariable=selected_season, values=seasons)
entry_season.grid(row=5,column=1,sticky="w")
entry_season.current(0)
#---------------------------------------------------------------------
# Type
lbl_type = tk.Label(main,text="Select Type")
lbl_type.grid(row=6,column=0,sticky="w",pady=(2,0))

entry_type = ttk.Combobox(main, textvariable=selected_types, values=types)
entry_type.grid(row=7,column=0,sticky="w")
entry_type.current(0)
#---------------------------------------------------------------------
columns = ("Store","Stock","Sales","Sell Thru","Weeks Cover")
tree = ttk.Treeview(main,columns=columns,show="headings",height=5)

for col in columns:
    tree.heading(col,text=col)
    tree.column(col,width=100)

tree.grid(row=8,column=0,columnspan=2,pady=5)
root.mainloop()