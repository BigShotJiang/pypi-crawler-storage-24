# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Symbol和Hook相关功能的单元测试

测试覆盖：
- TrackableOriginalFunc: 原函数追踪
- HookHelper: Hook辅助类
- Symbol: Symbol类功能
- Inject: 字节码注入（如果bytecode库可用）
"""

import pytest
import threading
import time
from unittest.mock import Mock, MagicMock, patch

from ms_service_metric.core.module_hook import TrackableOriginalFunc
from ms_service_metric.core.hook_helper import HookHelper
from ms_service_metric.core.handler import Handler, MetricHandler, HandlerType


class TestTrackableOriginalFunc:
    """TrackableOriginalFunc类的测试"""
    
    def test_given_sync_function_when_call_then_cache_result(self):
        """
        Given: 一个同步函数
        When: 调用TrackableOriginalFunc包装器
        Then: 结果应该被缓存，重复调用返回缓存结果
        """
        # Given
        call_count = 0
        def original_func(x):
            nonlocal call_count
            call_count += 1
            return x * 2
        
        trackable = TrackableOriginalFunc(original_func)
        
        # When - 第一次调用
        result1 = trackable(5)
        
        # Then
        assert result1 == 10
        assert call_count == 1
        assert trackable.executed is True
        
        # When - 第二次调用（应该返回缓存结果）
        result2 = trackable(5)
        
        # Then - 不应该再次调用原函数
        assert result2 == 10
        assert call_count == 1  # 调用次数不变
    
    def test_given_function_raises_exception_when_call_then_cache_exception(self):
        """
        Given: 一个会抛出异常的函数
        When: 调用TrackableOriginalFunc包装器
        Then: 异常应该被缓存，重复调用抛出相同异常
        """
        # Given
        call_count = 0
        def failing_func():
            nonlocal call_count
            call_count += 1
            raise ValueError("Test error")
        
        trackable = TrackableOriginalFunc(failing_func)
        
        # When & Then - 第一次调用应该抛出异常
        with pytest.raises(ValueError, match="Test error"):
            trackable()
        
        assert call_count == 1
        assert trackable.executed is True
        assert trackable.cached_exception is not None
        
        # When & Then - 第二次调用应该抛出相同的缓存异常
        with pytest.raises(ValueError, match="Test error"):
            trackable()
        
        assert call_count == 1  # 不应该再次调用原函数
    
    def test_given_executed_trackable_when_reset_then_clear_cache(self):
        """
        Given: 已经执行过的TrackableOriginalFunc
        When: 调用reset方法
        Then: 缓存应该被清除，可以重新执行
        """
        # Given
        call_count = 0
        def original_func():
            nonlocal call_count
            call_count += 1
            return call_count
        
        trackable = TrackableOriginalFunc(original_func)
        trackable()  # 第一次执行
        assert call_count == 1
        
        # When
        trackable.reset()
        
        # Then
        assert trackable.executed is False
        assert trackable.cached_result is None
        
        # When - 重新执行
        result = trackable()
        
        # Then - 应该再次调用原函数
        assert result == 2
        assert call_count == 2
    
    def test_given_trackable_when_call_with_reset_decorator_then_auto_reset(self):
        """
        Given: TrackableOriginalFunc实例
        When: 使用call_with_reset装饰器
        Then: 每次调用前应该自动重置状态
        """
        # Given
        call_count = 0
        def original_func():
            nonlocal call_count
            call_count += 1
            return call_count
        
        trackable = TrackableOriginalFunc(original_func)
        
        @trackable.call_with_reset
        def wrapper():
            return trackable()
        
        # When - 多次调用wrapper
        result1 = wrapper()
        result2 = wrapper()
        result3 = wrapper()
        
        # Then - 每次都应该调用原函数
        assert result1 == 1
        assert result2 == 2
        assert result3 == 3
        assert call_count == 3


class TestHookHelper:
    """HookHelper类的测试"""
    
    def test_given_simple_function_when_hook_then_replace_and_recover(self):
        """
        Given: 一个简单的函数
        When: 使用HookHelper进行hook和恢复
        Then: 函数行为应该先被修改，然后恢复原状
        """
        # Given
        original_calls = []
        hook_calls = []
        
        class TestClass:
            def method(self, x):
                original_calls.append(x)
                return x * 2
        
        obj = TestClass()
        original = obj.method
        
        # Hook函数应该是一个完整的包装函数，签名是(*args, **kwargs)
        def hook_func(*args, **kwargs):
            hook_calls.append("hook")
            return original(*args, **kwargs) + 1
        
        # When - 应用hook
        helper = HookHelper(original, hook_func)
        helper.replace()
        
        # Then - 调用被hook的函数
        result = obj.method(5)
        assert result == 11  # 5*2 + 1
        assert "hook" in hook_calls
        
        # When - 恢复
        helper.recover()
        
        # Then - 函数恢复原状
        result = obj.method(5)
        assert result == 10  # 5*2
    
    def test_given_hook_applied_when_replace_again_then_ignore(self):
        """
        Given: 已经应用了hook的HookHelper
        When: 再次调用replace
        Then: 应该被忽略，不产生错误
        """
        # Given
        class TestClass:
            def method(self, x):
                return x * 2
        
        obj = TestClass()
        original = obj.method
        # Hook函数应该是完整的包装函数，签名(*args, **kwargs)
        hook_func = lambda *args, **kwargs: original(*args, **kwargs)
        
        helper = HookHelper(obj.method, hook_func)
        helper.replace()
        
        # When - 再次replace（应该被忽略）
        helper.replace()  # 不应该抛出异常
        
        # Then - 函数仍然被hook
        assert helper.is_replaced is True
        
        # 清理
        helper.recover()
    
    def test_given_no_hook_applied_when_recover_then_ignore(self):
        """
        Given: 没有应用hook的HookHelper
        When: 调用recover
        Then: 应该被忽略，不产生错误
        """
        # Given
        class TestClass:
            def method(self, x):
                return x * 2
        
        obj = TestClass()
        original = obj.method
        # Hook函数应该是完整的包装函数，签名(*args, **kwargs)
        hook_func = lambda *args, **kwargs: original(*args, **kwargs)
        
        helper = HookHelper(obj.method, hook_func)
        
        # When - 直接recover（没有先replace）
        helper.recover()  # 不应该抛出异常
        
        # Then
        assert helper.is_replaced is False


class TestHookChain:
    """HookChain 类的测试（替代 HookHelper）"""
    
    def test_given_simple_function_when_create_node_then_hook_applied(self):
        """
        Given: 一个简单的函数
        When: 使用 hook_chain 创建节点并设置 hook
        Then: 函数应该被 hook，且能正确恢复
        """
        from ms_service_metric.core.hook_chain import create_node
        
        # Given
        call_order = []
        
        def original_func(x):
            call_order.append("original")
            return x * 2
        
        # When - 创建节点
        node = create_node(original_func)
        
        # 设置 hook 函数
        def hook_func(*args, **kwargs):
            call_order.append("hook")
            return node.ori_wrap(*args, **kwargs) + 1
        
        node.set_hook_func(hook_func)
        
        # Then - 调用被 hook 的函数
        result = original_func(5)
        assert result == 11  # 5*2 + 1
        assert "hook" in call_order
        assert "original" in call_order
        
        # When - 移除节点
        node.remove()
        
        # Then - 函数恢复原状
        call_order.clear()
        result = original_func(5)
        assert result == 10  # 5*2
        assert call_order == ["original"]
    
    def test_given_multiple_nodes_when_create_then_chain_built(self):
        """
        Given: 一个函数
        When: 创建多个 hook 节点
        Then: 应该形成调用链（洋葱模型）
        """
        from ms_service_metric.core.hook_chain import create_node
        
        # Given
        call_order = []
        
        def original_func(x):
            call_order.append("original")
            return x * 2
        
        # When - 创建第一个节点
        node1 = create_node(original_func)
        
        def hook1(*args, **kwargs):
            call_order.append("hook1_before")
            result = node1.ori_wrap(*args, **kwargs)
            call_order.append("hook1_after")
            return result + 1
        
        node1.set_hook_func(hook1)
        
        # 创建第二个节点（在第一个节点之后）
        node2 = create_node(original_func)
        
        def hook2(*args, **kwargs):
            call_order.append("hook2_before")
            result = node2.ori_wrap(*args, **kwargs)
            call_order.append("hook2_after")
            return result + 10
        
        node2.set_hook_func(hook2)
        
        # Then - 调用被 hook 的函数
        result = original_func(5)
        # hook2 -> hook1 -> original -> hook1 -> hook2
        # 5*2 + 1 + 10 = 21
        assert result == 21
        assert call_order == ["hook2_before", "hook1_before", "original", "hook1_after", "hook2_after"]
        
        # 清理
        node2.remove()
        node1.remove()
    
    def test_given_chain_when_remove_middle_node_then_chain_still_works(self):
        """
        Given: 有多个节点的调用链
        When: 移除中间的节点
        Then: 链条应该仍然正常工作
        """
        from ms_service_metric.core.hook_chain import create_node
        
        # Given
        call_order = []
        
        def original_func(x):
            call_order.append("original")
            return x * 2
        
        # 创建三个节点
        node1 = create_node(original_func)
        node2 = create_node(original_func)
        node3 = create_node(original_func)
        
        def make_hook(node, name, add_value):
            def hook(*args, **kwargs):
                call_order.append(f"{name}_before")
                result = node.ori_wrap(*args, **kwargs)
                call_order.append(f"{name}_after")
                return result + add_value
            return hook
        
        node1.set_hook_func(make_hook(node1, "hook1", 1))
        node2.set_hook_func(make_hook(node2, "hook2", 10))
        node3.set_hook_func(make_hook(node3, "hook3", 100))
        
        # When - 移除中间节点 node2
        node2.remove()
        call_order.clear()
        
        # Then - 调用应该跳过 node2
        result = original_func(5)
        # 5*2 + 1 + 100 = 111
        assert result == 111
        assert "hook2_before" not in call_order
        assert "hook2_after" not in call_order
        assert "hook1_before" in call_order
        assert "hook3_before" in call_order
        
        # 清理
        node3.remove()
        node1.remove()
    
    def test_given_chain_when_remove_all_nodes_then_original_restored(self):
        """
        Given: 有多个节点的调用链
        When: 移除所有节点
        Then: 原始函数应该完全恢复
        """
        from ms_service_metric.core.hook_chain import create_node
        
        # Given
        def original_func(x):
            return x * 2
        
        # 创建多个节点
        nodes = [create_node(original_func) for _ in range(3)]
        for i, node in enumerate(nodes):
            node.set_hook_func(lambda *args, _node=node, _i=i, **kwargs: _node.ori_wrap(*args, **kwargs) + _i)
        
        # When - 移除所有节点
        for node in nodes:
            node.remove()
        
        # Then - 函数应该完全恢复
        result = original_func(5)
        assert result == 10  # 5*2，没有任何 hook 添加
    
    def test_given_concurrent_access_when_add_nodes_then_thread_safe(self):
        """
        Given: 一个函数
        When: 并发添加多个节点
        Then: 应该线程安全，链条正确
        """
        from ms_service_metric.core.hook_chain import create_node
        import threading
        
        # Given
        def original_func(x):
            return x * 2
        
        nodes = []
        lock = threading.Lock()
        
        def add_node():
            node = create_node(original_func)
            with lock:
                nodes.append(node)
            node.set_hook_func(lambda *args, _node=node, **kwargs: _node.ori_wrap(*args, **kwargs))
        
        # When - 并发添加节点
        threads = [threading.Thread(target=add_node) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # Then - 所有节点都应该存在
        assert len(nodes) == 10
        
        # 调用应该正常工作
        result = original_func(5)
        assert result == 10  # 5*2，因为所有 hook 都是透传
        
        # 清理
        for node in nodes:
            node.remove()


class TestSymbolWithHookChain:
    """Symbol类基础功能的测试"""
    
    def test_given_valid_symbol_path_when_create_then_success(self):
        """
        Given: 有效的symbol路径
        When: 创建Symbol实例
        Then: 应该成功创建并解析路径
        """
        from ms_service_metric.core.symbol import Symbol
        
        # Given
        mock_watcher = Mock()
        mock_manager = Mock()
        mock_manager.is_updating.return_value = False
        
        # When
        symbol = Symbol(
            "test.module:ClassName.method_name",
            mock_watcher,
            mock_manager
        )
        
        # Then
        assert symbol.symbol_path == "test.module:ClassName.method_name"
        assert symbol.module_path == "test.module"
        assert symbol.attr_path == "ClassName.method_name"
        assert symbol.hook_applied is False
        assert symbol.module_loaded is False
    
    def test_given_invalid_symbol_path_when_create_then_raise_error(self):
        """
        Given: 无效的symbol路径（没有冒号）
        When: 创建Symbol实例
        Then: 应该抛出SymbolError
        """
        from ms_service_metric.core.symbol import Symbol
        from ms_service_metric.core.exceptions import SymbolError
        
        # Given
        mock_watcher = Mock()
        mock_manager = Mock()
        
        # When & Then
        with pytest.raises(SymbolError):
            Symbol("invalid.path.no.colon", mock_watcher, mock_manager)
    
    def test_given_symbol_when_add_handler_then_stored(self):
        """
        Given: 一个Symbol实例
        When: 添加handler
        Then: handler应该被存储
        """
        from ms_service_metric.core.symbol import Symbol
        
        # Given
        mock_watcher = Mock()
        mock_manager = Mock()
        mock_manager.is_updating.return_value = False
        
        symbol = Symbol("test.module:Class.method", mock_watcher, mock_manager)
        
        handler = Mock(spec=Handler)
        handler.id = "test_handler"
        
        # When
        symbol.add_handler(handler)
        
        # Then
        assert symbol.has_handler("test_handler") is True
        assert symbol.get_handler("test_handler") == handler
        assert len(symbol.get_all_handlers()) == 1
    
    def test_given_symbol_with_handler_when_add_same_handler_then_ignore(self):
        """
        Given: 已经有handler的Symbol
        When: 添加相同id的handler
        Then: 应该忽略，不重复添加
        """
        from ms_service_metric.core.symbol import Symbol
        
        # Given
        mock_watcher = Mock()
        mock_manager = Mock()
        mock_manager.is_updating.return_value = False
        
        symbol = Symbol("test.module:Class.method", mock_watcher, mock_manager)
        
        handler1 = Mock(spec=Handler)
        handler1.id = "test_handler"
        
        handler2 = Mock(spec=Handler)
        handler2.id = "test_handler"  # 相同id
        
        # When
        symbol.add_handler(handler1)
        symbol.add_handler(handler2)  # 应该被忽略
        
        # Then
        assert len(symbol.get_all_handlers()) == 1
        assert symbol.get_handler("test_handler") == handler1
    
    def test_given_symbol_with_handlers_when_remove_handler_then_removed(self):
        """
        Given: 有handlers的Symbol
        When: 移除handler
        Then: handler应该被移除
        """
        from ms_service_metric.core.symbol import Symbol
        
        # Given
        mock_watcher = Mock()
        mock_manager = Mock()
        mock_manager.is_updating.return_value = False
        
        symbol = Symbol("test.module:Class.method", mock_watcher, mock_manager)
        
        handler = Mock(spec=Handler)
        handler.id = "test_handler"
        symbol.add_handler(handler)
        
        # When
        symbol.remove_handler("test_handler")
        
        # Then
        assert symbol.has_handler("test_handler") is False
        assert symbol.is_empty() is True
    
    def test_given_symbol_when_module_loaded_event_then_hook_applied(self):
        """
        Given: 有handler的Symbol，模块未加载
        When: 模块加载事件触发
        Then: 如果manager不在更新中，应该应用hook
        """
        from ms_service_metric.core.symbol import Symbol
        
        # Given
        mock_watcher = Mock()
        mock_manager = Mock()
        mock_manager.is_updating.return_value = False
        
        symbol = Symbol("builtins:str.upper", mock_watcher, mock_manager)
        
        handler = Mock(spec=Handler)
        handler.id = "test_handler"
        handler.get_hook_func = lambda target: (HandlerType.WRAP, lambda ori, *args, **kwargs: ori(*args, **kwargs))
        handler.need_locals = False
        
        symbol.add_handler(handler)
        
        # 模拟模块加载事件
        mock_event = Mock()
        mock_event.module_name = "builtins"
        
        # When
        symbol._on_module_loaded(mock_event)
        
        # Then
        assert symbol.module_loaded is True


# 如果bytecode库可用，测试注入功能
try:
    from bytecode import Bytecode, Instr
    BYTECODE_AVAILABLE = True
except ImportError:
    BYTECODE_AVAILABLE = False


@pytest.mark.skipif(not BYTECODE_AVAILABLE, reason="bytecode library not available")
class TestInject:
    """字节码注入功能的测试（需要bytecode库）"""
    
    def test_given_simple_function_when_inject_then_hooks_called(self):
        """
        Given: 一个简单的函数
        When: 使用inject_function注入hook
        Then: 入口和返回hook应该被正确调用
        """
        from ms_service_metric.core.inject import inject_function
        
        hook_calls = []
        
        def context_factory(ctx, local_values):
            class TestContext:
                def __enter__(self):
                    hook_calls.append("enter")
                    return self
                def __exit__(self, exc_type, exc_val, exc_tb):
                    hook_calls.append("exit")
                    return False
            return TestContext()
        
        def original_func(x):
            hook_calls.append(f"ori_{x}")
            return x * 2
        
        injected = inject_function(original_func, [context_factory])
        
        result = injected(5)
        
        assert "enter" in hook_calls
        assert "ori_5" in hook_calls
        assert "exit" in hook_calls
        assert result == 10
    
    def test_given_function_with_locals_when_inject_then_hooks_still_work(self):
        """
        Given: 使用locals的函数
        When: 使用inject_function注入hook
        Then: hook应该正常工作，函数返回正确结果
        
        Note: 这个测试主要验证注入不会破坏函数执行
        """
        from ms_service_metric.core.inject import inject_function
        
        hook_calls = []
        
        def context_factory(ctx, local_values):
            class TestContext:
                def __enter__(self):
                    hook_calls.append("enter")
                    return self
                def __exit__(self, exc_type, exc_val, exc_tb):
                    hook_calls.append("exit")
                    return False
            return TestContext()
        
        def original_func(x):
            y = x * 2
            z = y + 1
            return z
        
        injected = inject_function(original_func, [context_factory])
        result = injected(5)
        
        assert result == 11
        assert "enter" in hook_calls
        assert "exit" in hook_calls


class TestSymbolHookChainIntegration:
    """Symbol 使用 HookChain 的集成测试"""
    
    def test_given_symbol_when_hook_then_use_hook_chain(self):
        """
        Given: 有 handler 的 Symbol
        When: 应用 hook
        Then: 应该使用 hook_chain 而不是 HookHelper
        """
        from ms_service_metric.core.symbol import Symbol
        
        # Given
        mock_watcher = Mock()
        mock_manager = Mock()
        mock_manager.is_updating.return_value = False
        
        symbol = Symbol("builtins:str.upper", mock_watcher, mock_manager)
        
        # 创建 mock handler
        handler = Mock(spec=Handler)
        handler.id = "test_handler"
        handler.wrap_func = lambda ori, *args, **kwargs: ori(*args, **kwargs)
        handler.context_func = None
        handler.need_locals = False
        
        symbol.add_handler(handler)
        
        # When - 模拟模块加载
        mock_event = Mock()
        mock_event.module_name = "builtins"
        symbol._on_module_loaded(mock_event)
        
        # Then - 验证使用了 hook_chain
        assert symbol._hook_node is not None  # 使用 _hook_node 而不是 _hook_helper
        assert symbol.hook_applied is True
        
        # 清理
        symbol.unhook()
    
    def test_given_symbol_when_unhook_then_remove_node(self):
        """
        Given: 已经应用 hook 的 Symbol
        When: 调用 unhook
        Then: 应该移除 hook 节点
        """
        from ms_service_metric.core.symbol import Symbol
        
        # Given
        mock_watcher = Mock()
        mock_manager = Mock()
        mock_manager.is_updating.return_value = False
        
        symbol = Symbol("builtins:str.upper", mock_watcher, mock_manager)
        
        handler = Mock(spec=Handler)
        handler.id = "test_handler"
        handler.wrap_func = lambda ori, *args, **kwargs: ori(*args, **kwargs)
        handler.context_func = None
        handler.need_locals = False
        
        symbol.add_handler(handler)
        
        # 先应用 hook
        mock_event = Mock()
        mock_event.module_name = "builtins"
        symbol._on_module_loaded(mock_event)
        
        assert symbol._hook_node is not None
        
        # When - 解绑
        symbol.unhook()
        
        # Then - 节点应该被移除
        assert symbol._hook_node is None
        assert symbol.hook_applied is False
    
    def test_given_symbol_with_multiple_handlers_when_hook_then_chain_built(self):
        """
        Given: 有多个 handlers 的 Symbol
        When: 应用 hook
        Then: 应该构建正确的调用链
        """
        from ms_service_metric.core.symbol import Symbol
        from ms_service_metric.core.hook_chain import create_node
        
        # Given
        call_order = []
        
        def original_func(x):
            call_order.append("original")
            return x * 2
        
        # 直接测试调用链构建
        node = create_node(original_func)
        
        # 模拟多个 handler 构建的 hook
        def hook(*args, **kwargs):
            call_order.append("hook")
            return node.ori_wrap(*args, **kwargs) + 1
        
        node.set_hook_func(hook)
        
        # When
        result = original_func(5)
        
        # Then
        assert result == 11  # 5*2 + 1
        assert "hook" in call_order
        assert "original" in call_order
        
        # 清理
        node.remove()


class TestIntegration:
    """集成测试"""
    
    def test_given_symbol_with_wrap_handler_when_hook_then_function_wrapped(self):
        """
        Given: 带wrap handler的Symbol
        When: 应用hook
        Then: 函数应该被正确包装
        """
        from ms_service_metric.core.symbol import Symbol
        
        # Given - 创建一个可hook的测试模块
        class TestModule:
            class TestClass:
                def test_method(self, x):
                    return x * 2
        
        # 模拟watcher和manager
        mock_watcher = Mock()
        mock_manager = Mock()
        mock_manager.is_updating.return_value = False
        
        # 创建symbol
        symbol = Symbol("tests.unit.test_symbol_hook:TestIntegration.TestModule.TestClass.test_method", mock_watcher, mock_manager)
        
        # 创建handler
        handler = Mock(spec=Handler)
        handler.id = "test_handler"
        handler.wrap_func = lambda ori, *args, **kwargs: ori(*args, **kwargs) + 1
        handler.context_funcs = []
        handler.need_locals = False
        
        symbol.add_handler(handler)
        
        # 手动触发模块加载（因为我们无法真正导入）
        mock_event = Mock()
        mock_event.module_name = "tests.unit.test_symbol_hook"
        
        # 这个测试主要验证流程，实际hook需要真实模块
        # 所以我们只验证symbol状态
        symbol._module_loaded = True
        
        # When & Then - 由于无法真实导入，我们验证symbol状态
        assert symbol.module_loaded is True
        assert symbol.has_handler("test_handler") is True


class TestHandlerNeedLocalsAutoDetection:
    """Handler自动检测need_locals功能的测试"""
    
    def test_given_context_handler_with_one_param_when_classify_then_need_locals_false(self):
        """
        Given: 一个参数的context handler
        When: 创建Handler实例
        Then: 应该是context handler，need_locals=False
        """
        from ms_service_metric.core.handler import Handler, HandlerType
        
        def simple_context_handler(ctx):
            yield
        
        handler = Handler(
            name="test_handler",
            symbol_path="test.module:function",
            hook_func=simple_context_handler
        )
        
        assert handler.handler_type == HandlerType.CONTEXT
        assert handler.need_locals is False
        assert handler.context_func is not None
    
    def test_given_context_handler_with_two_params_when_classify_then_need_locals_true(self):
        """
        Given: 两个参数的context handler（第二个参数名包含local）
        When: 创建Handler实例
        Then: 应该是context handler，need_locals=True
        """
        from ms_service_metric.core.handler import Handler, HandlerType
        
        def advanced_context_handler(ctx, local_values):
            yield
        
        handler = Handler(
            name="test_handler",
            symbol_path="test.module:function",
            hook_func=advanced_context_handler
        )
        
        assert handler.handler_type == HandlerType.CONTEXT
        assert handler.need_locals is True
        assert handler.context_func is not None
    
    def test_given_context_handler_with_locals_param_when_classify_then_need_locals_true(self):
        """
        Given: 两个参数的context handler（第二个参数名包含locals）
        When: 创建Handler实例
        Then: 应该是context handler，need_locals=True
        """
        from ms_service_metric.core.handler import Handler, HandlerType
        
        def handler_with_locals(ctx, locals_dict):
            yield
        
        handler = Handler(
            name="test_handler",
            symbol_path="test.module:function",
            hook_func=handler_with_locals
        )
        
        assert handler.handler_type == HandlerType.CONTEXT
        assert handler.need_locals is True
    
    def test_given_wrap_handler_when_classify_then_need_locals_false(self):
        """
        Given: wrap handler（普通函数）
        When: 创建Handler实例
        Then: 应该是wrap handler，need_locals=False
        """
        from ms_service_metric.core.handler import Handler, HandlerType
        
        def wrap_handler(ori_func, *args, **kwargs):
            return ori_func(*args, **kwargs)
        
        handler = Handler(
            name="test_handler",
            symbol_path="test.module:function",
            hook_func=wrap_handler
        )
        
        assert handler.handler_type == HandlerType.WRAP
        assert handler.need_locals is False
        assert handler.wrap_func is not None


class TestFunctionContext:
    """FunctionContext类的测试"""
    
    def test_given_context_when_get_local_value_then_returns_value(self):
        """
        Given: 有local_values的FunctionContext
        When: 调用get方法
        Then: 应该返回对应的值
        """
        from ms_service_metric.core.utils import FunctionContext
        
        ctx = FunctionContext()
        ctx.local_values = {"x": 1, "y": 2}
        
        assert ctx.get("x") == 1
        assert ctx.get("y") == 2
        assert ctx.get("z") is None
        assert ctx.get("z", "default") == "default"
    
    def test_given_context_when_use_dict_syntax_then_returns_value(self):
        """
        Given: 有local_values的FunctionContext
        When: 使用字典语法访问
        Then: 应该返回对应的值
        """
        from ms_service_metric.core.utils import FunctionContext
        
        ctx = FunctionContext()
        ctx.local_values = {"x": 1, "y": 2}
        
        assert ctx["x"] == 1
        assert ctx["y"] == 2
    
    def test_given_context_when_check_contains_then_returns_correct(self):
        """
        Given: 有local_values的FunctionContext
        When: 使用in操作符检查
        Then: 应该返回正确的结果
        """
        from ms_service_metric.core.utils import FunctionContext
        
        ctx = FunctionContext()
        ctx.local_values = {"x": 1, "y": 2}
        
        assert "x" in ctx
        assert "y" in ctx
        assert "z" not in ctx
    
    def test_given_context_with_no_locals_when_get_then_returns_default(self):
        """
        Given: 没有local_values的FunctionContext
        When: 调用get方法
        Then: 应该返回默认值
        """
        from ms_service_metric.core.utils import FunctionContext
        
        ctx = FunctionContext()
        
        assert ctx.get("x") is None
        assert ctx.get("x", "default") == "default"
    
    def test_given_context_when_set_return_value_then_stored(self):
        """
        Given: FunctionContext实例
        When: 设置return_value
        Then: 应该正确存储
        """
        from ms_service_metric.core.utils import FunctionContext
        
        ctx = FunctionContext()
        ctx.return_value = "result"
        
        assert ctx.return_value == "result"


class TestDefaultHandlerNeedLocals:
    """默认handler的need_locals检测测试"""
    
    def test_given_config_with_expr_when_create_default_handler_then_need_locals_true(self):
        """
        Given: 包含expr字段的配置
        When: 创建默认handler
        Then: handler应该是2参数版本，need_locals=True
        """
        from ms_service_metric.core.handler import Handler
        import inspect
        
        config = {
            'metrics': [
                {'name': 'test_metric', 'type': 'counter', 'expr': 'len(items)'}
            ]
        }
        
        handler_func = Handler._create_default_handler(config)
        sig = inspect.signature(handler_func)
        params = list(sig.parameters.keys())
        
        assert len(params) == 2
        assert params[0] == 'ctx'
        assert 'local' in params[1].lower()
    
    def test_given_config_without_expr_when_create_default_handler_then_need_locals_false(self):
        """
        Given: 不包含expr字段的配置
        When: 创建默认handler
        Then: handler应该是1参数版本，need_locals=False
        """
        from ms_service_metric.core.handler import Handler
        import inspect
        
        config = {
            'metrics': [
                {'name': 'test_metric', 'type': 'timer'}
            ]
        }
        
        handler_func = Handler._create_default_handler(config)
        sig = inspect.signature(handler_func)
        params = list(sig.parameters.keys())
        
        assert len(params) == 1
        assert params[0] == 'ctx'
    
    def test_given_config_with_nested_expr_when_create_default_handler_then_need_locals_true(self):
        """
        Given: 嵌套层级中包含expr字段的配置
        When: 创建默认handler
        Then: handler应该是2参数版本，need_locals=True
        """
        from ms_service_metric.core.handler import Handler
        import inspect
        
        config = {
            'metrics': [
                {
                    'name': 'test_metric', 
                    'type': 'timer',
                    'label': [
                        {'name': 'label1', 'expr': 'status'}
                    ]
                }
            ]
        }
        
        handler_func = Handler._create_default_handler(config)
        sig = inspect.signature(handler_func)
        params = list(sig.parameters.keys())
        
        assert len(params) == 2
