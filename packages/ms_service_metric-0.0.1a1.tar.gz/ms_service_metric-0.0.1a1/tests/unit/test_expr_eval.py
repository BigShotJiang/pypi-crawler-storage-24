# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ExprEval单元测试
"""

import pytest
import math

from ms_service_metric.utils.expr_eval import ExprEval, evaluate_expression


class TestExprEval:
    """ExprEval测试类"""
    
    def test_simple_arithmetic(self):
        """测试简单算术运算"""
        evaluator = ExprEval("1 + 2")
        result = evaluator({})
        assert result == 3
    
    def test_variable_substitution(self):
        """测试变量替换"""
        evaluator = ExprEval("x + y")
        result = evaluator({"x": 10, "y": 20})
        assert result == 30
    
    def test_complex_expression(self):
        """测试复杂表达式"""
        evaluator = ExprEval("(x + y) * 2 - z / 2")
        result = evaluator({"x": 1, "y": 2, "z": 4})
        assert result == 4
    
    def test_unary_operator(self):
        """测试一元运算符"""
        evaluator = ExprEval("-x + +5")
        result = evaluator({"x": 3})
        assert result == 2
    
    def test_function_call(self):
        """测试函数调用"""
        evaluator = ExprEval("abs(-5)")
        result = evaluator({})
        assert result == 5
    
    def test_len_function(self):
        """测试len函数"""
        evaluator = ExprEval("len(items)")
        result = evaluator({"items": [1, 2, 3, 4, 5]})
        assert result == 5
    
    def test_math_function(self):
        """测试数学函数"""
        evaluator = ExprEval("sqrt(16)")
        result = evaluator({})
        assert result == 4
    
    def test_attribute_access(self):
        """测试属性访问"""
        class Obj:
            value = 42
        
        evaluator = ExprEval("obj.value")
        result = evaluator({"obj": Obj()})
        assert result == 42
    
    def test_list_subscript(self):
        """测试列表下标访问"""
        evaluator = ExprEval("items[0] + items[1]")
        result = evaluator({"items": [10, 20, 30]})
        assert result == 30
    
    def test_dict_subscript(self):
        """测试字典下标访问"""
        evaluator = ExprEval("data['key']")
        result = evaluator({"data": {"key": "value"}})
        assert result == "value"
    
    def test_undefined_variable(self):
        """测试未定义变量"""
        evaluator = ExprEval("undefined_var")
        with pytest.raises(NameError):
            evaluator({})
    
    def test_undefined_function(self):
        """测试未定义函数"""
        evaluator = ExprEval("undefined_func()")
        with pytest.raises(NameError):
            evaluator({})
    
    def test_invalid_syntax(self):
        """测试无效语法"""
        with pytest.raises(SyntaxError):
            ExprEval("1 + * 2")  # 无效语法
    
    def test_list_index_out_of_range(self):
        """测试列表索引越界"""
        evaluator = ExprEval("items[10]")
        with pytest.raises(IndexError):
            evaluator({"items": [1, 2, 3]})
    
    def test_dict_key_not_found(self):
        """测试字典键不存在"""
        evaluator = ExprEval("data['missing']")
        with pytest.raises(KeyError):
            evaluator({"data": {}})
    
    def test_nested_expression(self):
        """测试嵌套表达式"""
        evaluator = ExprEval("max(items) + min(items)")
        result = evaluator({"items": [1, 5, 3, 9, 2]})
        assert result == 10
    
    def test_string_concat(self):
        """测试字符串拼接（通过加法）"""
        evaluator = ExprEval("str(x) + '_' + str(y)")
        result = evaluator({"x": 1, "y": 2})
        assert result == "1_2"
    
    def test_register_custom_function(self):
        """测试注册自定义函数"""
        evaluator = ExprEval("custom_func(x)")
        evaluator.register_function("custom_func", lambda x: x * 2)
        result = evaluator({"x": 5})
        assert result == 10


class TestEvaluateExpression:
    """evaluate_expression便捷函数测试类"""
    
    def test_simple_evaluation(self):
        """测试简单求值"""
        result = evaluate_expression("x + y", {"x": 1, "y": 2})
        assert result == 3
    
    def test_with_functions(self):
        """测试带函数的求值"""
        result = evaluate_expression("len(items)", {"items": [1, 2, 3]})
        assert result == 3
    
    def test_real_world_example(self):
        """测试真实场景示例"""
        # 模拟metrics标签表达式
        context = {
            "ret": {"status": "success", "tokens": 100},
            "args": [{"model": "gpt-4"}]
        }
        result = evaluate_expression("ret['status']", context)
        assert result == "success"
