# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
MetricsManager单元测试
"""

import pytest
from unittest.mock import Mock, patch

from ms_service_metric.core.metrics_manager import (
    MetricsManager,
    MetricConfig,
    MetricType,
    get_metrics_manager,
    reset_metrics_manager,
)


class TestMetricConfig:
    """MetricConfig测试类"""
    
    def test_timer_config_no_expr(self):
        """测试timer类型配置自动清空expr"""
        config = MetricConfig(
            name="test_timer",
            type=MetricType.TIMER,
            expr="some_expr"
        )
        assert config.expr == ""
    
    def test_histogram_config_with_expr(self):
        """测试histogram类型配置保留expr"""
        config = MetricConfig(
            name="test_histogram",
            type=MetricType.HISTOGRAM,
            expr="len(args)"
        )
        assert config.expr == "len(args)"
    
    def test_config_with_buckets(self):
        """测试配置带buckets"""
        buckets = [0.1, 0.5, 1.0, 2.0]
        config = MetricConfig(
            name="test_histogram",
            type=MetricType.HISTOGRAM,
            buckets=buckets
        )
        assert config.buckets == buckets

    def test_config_with_label(self):
        """测试配置带label"""
        label = [{"name": "status", "expr": "ret['status']"}]
        config = MetricConfig(
            name="test_timer",
            type=MetricType.TIMER,
            label=label
        )
        assert config.labels == label

    def test_config_label_default_empty_list(self):
        """测试label默认值为空列表"""
        config = MetricConfig(
            name="test_timer",
            type=MetricType.TIMER
        )
        assert config.labels == []

    def test_config_get_method(self):
        """测试get方法兼容字典访问"""
        config = MetricConfig(
            name="test_timer",
            type=MetricType.TIMER,
            expr="",
            buckets=[0.1, 0.5]
        )
        # 测试get方法
        assert config.get('name') == "test_timer"
        assert config.get('type') == MetricType.TIMER
        assert config.get('expr') == ""
        assert config.get('buckets') == [0.1, 0.5]
        assert config.get('label') == []
        # 测试默认值
        assert config.get('nonexistent', 'default') == 'default'
        assert config.get('nonexistent') is None


class TestMetricsManager:
    """MetricsManager测试类"""
    
    def setup_method(self):
        """每个测试方法前重置manager"""
        reset_metrics_manager()
    
    def teardown_method(self):
        """每个测试方法后清理"""
        reset_metrics_manager()
    
    def test_singleton(self):
        """测试单例模式"""
        manager1 = get_metrics_manager()
        manager2 = get_metrics_manager()
        assert manager1 is manager2
    
    def test_register_timer_metric(self):
        """测试注册timer指标"""
        manager = MetricsManager()
        config = MetricConfig(
            name="test_timer",
            type=MetricType.TIMER
        )
        
        metric = manager.register_metric(config)
        assert metric is not None
        assert "test_timer" in manager.get_all_metrics()
    
    def test_register_counter_metric(self):
        """测试注册counter指标"""
        manager = MetricsManager()
        config = MetricConfig(
            name="test_counter",
            type=MetricType.COUNTER
        )
        
        metric = manager.register_metric(config)
        assert metric is not None
        assert "test_counter" in manager.get_all_metrics()
    
    def test_register_gauge_metric(self):
        """测试注册gauge指标"""
        manager = MetricsManager()
        config = MetricConfig(
            name="test_gauge",
            type=MetricType.GAUGE
        )
        
        metric = manager.register_metric(config)
        assert metric is not None
        assert "test_gauge" in manager.get_all_metrics()
    
    def test_register_histogram_metric(self):
        """测试注册histogram指标"""
        manager = MetricsManager()
        config = MetricConfig(
            name="test_histogram",
            type=MetricType.HISTOGRAM
        )
        
        metric = manager.register_metric(config)
        assert metric is not None
        assert "test_histogram" in manager.get_all_metrics()
    
    def test_register_summary_metric(self):
        """测试注册summary指标"""
        manager = MetricsManager()
        config = MetricConfig(
            name="test_summary",
            type=MetricType.SUMMARY
        )
        
        metric = manager.register_metric(config)
        assert metric is not None
        assert "test_summary" in manager.get_all_metrics()
    
    def test_metric_prefix(self):
        """测试指标前缀"""
        manager = MetricsManager()
        manager.metric_prefix = "vllm"
        
        config = MetricConfig(
            name="test_timer",
            type=MetricType.TIMER
        )
        
        metric = manager.register_metric(config)
        assert metric is not None
        assert "vllm_test_timer" in manager.get_all_metrics()
    
    def test_add_label_definition(self):
        """测试添加标签定义"""
        from ms_service_metric.handlers.builtin import _get_labels_for_metric
        
        manager = MetricsManager()
        
        manager.add_label_definition("test_metric", "status", "ret['status']")
        
        # 使用_get_labels_for_metric计算标签
        label_definitions = manager.get_label_definitions()
        labels = _get_labels_for_metric(
            "test_metric",
            {"ret": {"status": "success"}},
            label_definitions
        )
        assert labels.get("status") == "success"
    
    def test_record_metric(self):
        """测试记录指标"""
        import uuid
        manager = MetricsManager()
        
        # 使用唯一名称避免测试间冲突
        unique_name = f"test_counter_{uuid.uuid4().hex[:8]}"
        
        # 先注册指标
        config = MetricConfig(
            name=unique_name,
            type=MetricType.COUNTER
        )
        manager.register_metric(config)
        
        # 记录指标值
        manager.record_metric(unique_name, 1)
        
        # 验证指标存在（实际值验证需要mock prometheus客户端）
        assert unique_name in manager.get_all_metrics()
    
    def test_sanitize_metric_name(self):
        """测试指标名称清理"""
        manager = MetricsManager()
        
        # 测试连字符替换
        assert manager._sanitize_metric_name("test-metric") == "test_metric"
        
        # 测试数字开头
        assert manager._sanitize_metric_name("123_metric") == "fn_123_metric"
    
    def test_add_dp_label(self):
        """测试添加dp标签"""
        manager = MetricsManager()
        
        # 测试添加标签名
        labels = manager._add_dp_label_name(["status", "model"])
        assert "dp" in labels
        
        # 测试添加标签值（使用全局meta_state，默认dp_rank_id为-1）
        labels = manager._add_dp_label_value({"status": "success"})
        assert labels.get("dp") == "-1"
    
    def test_clear_metrics(self):
        """测试清除指标"""
        manager = MetricsManager()
        
        config = MetricConfig(
            name="test_metric",
            type=MetricType.COUNTER
        )
        manager.register_metric(config)
        
        assert len(manager.get_all_metrics()) > 0
        
        manager.clear_metrics()
        assert len(manager.get_all_metrics()) == 0



