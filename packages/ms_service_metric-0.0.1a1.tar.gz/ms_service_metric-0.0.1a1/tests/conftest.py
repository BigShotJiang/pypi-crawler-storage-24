# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Pytest配置和共享fixture
"""

import pytest


@pytest.fixture
def sample_config():
    """示例配置fixture"""
    return {
        "vllm.worker.model_runner:ModelRunner.execute_model": [
            {
                "name": "model_execution_timer",
                "handler": "ms_service_metric.handlers:timer_handler",
                "metrics": [
                    {
                        "name": "vllm_model_execution_duration",
                        "type": "timer"
                    }
                ]
            }
        ],
        "vllm.core.scheduler:Scheduler.schedule": [
            {
                "name": "scheduler_timer",
                "handler": "ms_service_metric.handlers:timer_handler",
                "metrics": [
                    {
                        "name": "vllm_scheduler_duration",
                        "type": "timer"
                    }
                ]
            }
        ]
    }


@pytest.fixture
def sample_handler_config():
    """示例handler配置fixture"""
    return {
        "name": "test_handler",
        "handler": "ms_service_metric.handlers:timer_handler",
        "type": "wrap",
        "min_version": "0.6.0",
        "max_version": None,
        "metrics": [
            {
                "name": "test_duration",
                "type": "timer"
            }
        ]
    }


@pytest.fixture
def sample_symbol_path():
    """示例symbol路径fixture"""
    return "test.module:TestClass.test_method"


@pytest.fixture
def cleanup_metrics():
    """清理metrics的fixture"""
    yield
    # 测试后清理
    from ms_service_metric.core.metrics_manager import reset_metrics_manager
    reset_metrics_manager()
