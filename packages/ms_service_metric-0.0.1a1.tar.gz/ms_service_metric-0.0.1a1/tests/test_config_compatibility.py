"""
配置文件兼容性测试

验证新项目的配置格式与原始配置格式兼容。
"""

import pytest
import tempfile
import os
from ms_service_metric.core.symbol_config import SymbolConfig


class TestConfigCompatibility:
    """配置兼容性测试类"""

    def test_array_format_config(self):
        """测试数组格式配置（原始格式）"""
        config_content = """
# vLLM 配置
- symbol: vllm.worker.model_runner:ModelRunner.execute_model
  handler: ms_service_metric.handlers:timer_handler
  metrics:
    - name: vllm_model_execution_duration
      type: timer
      label:
        - name: model
          expr: self.model_config.model

- symbol: vllm.core.scheduler:Scheduler.schedule
  handler: ms_service_metric.handlers:timer_handler
  metrics:
    - name: vllm_scheduler_duration
      type: timer
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            config_path = f.name
        
        try:
            symbol_config = SymbolConfig(user_config_path=config_path)
            config = symbol_config.load()  # 需要调用load()加载配置
            
            # 验证配置被正确解析
            assert "vllm.worker.model_runner:ModelRunner.execute_model" in config
            assert "vllm.core.scheduler:Scheduler.schedule" in config
            
            # 验证第一个symbol的handler
            first_symbol = config["vllm.worker.model_runner:ModelRunner.execute_model"]
            assert len(first_symbol) == 1
            assert first_symbol[0]["handler"] == "ms_service_metric.handlers:timer_handler"
            
            # 验证metrics
            assert "metrics" in first_symbol[0]
            assert first_symbol[0]["metrics"][0]["name"] == "vllm_model_execution_duration"
            
        finally:
            os.unlink(config_path)

    def test_dict_format_config(self):
        """测试字典格式配置"""
        config_content = """
vllm.worker.model_runner:ModelRunner.execute_model:
  - handler: ms_service_metric.handlers:timer_handler
    metrics:
      - name: vllm_model_execution_duration
        type: timer

vllm.core.scheduler:Scheduler.schedule:
  - handler: ms_service_metric.handlers:timer_handler
    metrics:
      - name: vllm_scheduler_duration
        type: timer
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            config_path = f.name
        
        try:
            symbol_config = SymbolConfig(user_config_path=config_path)
            config = symbol_config.load()  # 需要调用load()加载配置
            
            # 验证配置被正确解析
            assert "vllm.worker.model_runner:ModelRunner.execute_model" in config
            assert "vllm.core.scheduler:Scheduler.schedule" in config
            
        finally:
            os.unlink(config_path)

    def test_mixed_handlers_config(self):
        """测试混合handlers配置"""
        config_content = """
- symbol: test.module:function1
  handler: ms_service_metric.handlers:timer_handler
  metrics:
    - name: func1_duration
      type: timer

- symbol: test.module:function2
  handler: ms_service_metric.handlers:counter_handler
  metrics:
    - name: func2_calls
      type: counter

- symbol: test.module:function3
  handler: ms_service_metric.handlers:gauge_handler
  metrics:
    - name: func3_value
      type: gauge
      expr: len(args[0])
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            config_path = f.name
        
        try:
            symbol_config = SymbolConfig(user_config_path=config_path)
            config = symbol_config.load()  # 需要调用load()加载配置
            
            # 验证所有symbol都被解析
            assert "test.module:function1" in config
            assert "test.module:function2" in config
            assert "test.module:function3" in config
            
            # 验证handler类型
            assert config["test.module:function1"][0]["handler"] == "ms_service_metric.handlers:timer_handler"
            assert config["test.module:function2"][0]["handler"] == "ms_service_metric.handlers:counter_handler"
            assert config["test.module:function3"][0]["handler"] == "ms_service_metric.handlers:gauge_handler"
            
        finally:
            os.unlink(config_path)

    def test_config_with_version_filters(self):
        """测试带版本过滤的配置"""
        config_content = """
- symbol: test.module:function
  handler: ms_service_metric.handlers:timer_handler
  min_version: "0.5.0"
  max_version: "1.0.0"
  metrics:
    - name: func_duration
      type: timer
"""

        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            symbol_config = SymbolConfig(user_config_path=config_path)
            config = symbol_config.load()

            symbol_handlers = config["test.module:function"][0]
            assert symbol_handlers["min_version"] == "0.5.0"
            assert symbol_handlers["max_version"] == "1.0.0"

        finally:
            os.unlink(config_path)

    def test_empty_config(self):
        """测试空配置"""
        config_content = ""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            config_path = f.name
        
        try:
            symbol_config = SymbolConfig(config_path)
            config = symbol_config.get_config()
            
            assert config == {}
            
        finally:
            os.unlink(config_path)

    def test_config_with_labels(self):
        """测试带标签的配置"""
        config_content = """
- symbol: test.module:function
  handler: ms_service_metric.handlers:timer_handler
  metrics:
    - name: func_duration
      type: timer
      label:
        - name: status
          expr: ret['status']
        - name: model
          expr: args[0].model
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            config_path = f.name
        
        try:
            symbol_config = SymbolConfig(user_config_path=config_path)
            config = symbol_config.load()  # 需要调用load()加载配置
            
            metrics = config["test.module:function"][0]["metrics"]
            assert len(metrics[0]["label"]) == 2
            assert metrics[0]["label"][0]["name"] == "status"
            assert metrics[0]["label"][0]["expr"] == "ret['status']"
            
        finally:
            os.unlink(config_path)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
