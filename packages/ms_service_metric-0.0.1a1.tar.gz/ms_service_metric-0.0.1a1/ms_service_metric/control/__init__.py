"""
ms_service_metric.control - 控制端模块

提供命令行控制工具，用于动态控制metric收集的开关。
"""

from ms_service_metric.control.cli import main

__all__ = [
    "main",
]
