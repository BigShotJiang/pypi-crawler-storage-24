"""
ms_service_metric - 动态函数Hook和性能监控库

该库提供了动态函数Hook功能，用于监控和分析服务性能。
支持通过共享内存和SIGUSR1信号进行动态开关控制。

主要组件:
    - SymbolHandlerManager: 核心管理类，管理所有handler和symbol
    - SymbolConfig: 配置管理类
    - Symbol: 代表一个需要hook的符号
    - Handler: Hook处理函数包装
    - MetricsManager: Metrics管理器
    - SymbolWatcher: 模块加载/卸载监视器
    - MetricConfigWatch: 配置动态监视器

使用示例:
    >>> from ms_service_metric import SymbolHandlerManager
    >>> manager = SymbolHandlerManager()
    >>> manager.initialize()

控制命令:
    $ python -m ms_service_metric on      # 开启metric
    $ python -m ms_service_metric off     # 关闭metric
    $ python -m ms_service_metric restart # 重启metric

环境变量:
    MS_SERVICE_METRIC_SHM_NAME: 共享内存名称 (默认: /ms_service_metric_control)
    MS_SERVICE_METRIC_SEM_NAME: 信号量名称 (默认: /ms_service_metric_semaphore)
    MS_SERVICE_METRIC_MAX_PROCS: 最大进程数 (默认: 1000)
"""

__version__ = "26.0.0"
__all__ = [
    "SymbolHandlerManager",
    "SymbolConfig",
    "Symbol",
    "Handler",
    "MetricsManager",
    "SymbolWatcher",
    "MetricConfigWatch",
]

# 延迟导入，避免循环依赖
def __getattr__(name):
    if name == "SymbolHandlerManager":
        from ms_service_metric.core.symbol_handler_manager import SymbolHandlerManager
        return SymbolHandlerManager
    elif name == "SymbolConfig":
        from ms_service_metric.core.symbol_config import SymbolConfig
        return SymbolConfig
    elif name == "Symbol":
        from ms_service_metric.core.symbol import Symbol
        return Symbol
    elif name == "Handler":
        from ms_service_metric.core.handler import Handler
        return Handler
    elif name == "MetricsManager":
        from ms_service_metric.core.metrics_manager import MetricsManager
        return MetricsManager
    elif name == "SymbolWatcher":
        from ms_service_metric.core.symbol_watcher import SymbolWatcher
        return SymbolWatcher
    elif name == "MetricConfigWatch":
        from ms_service_metric.core.metric_config_watch import MetricConfigWatch
        return MetricConfigWatch
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
