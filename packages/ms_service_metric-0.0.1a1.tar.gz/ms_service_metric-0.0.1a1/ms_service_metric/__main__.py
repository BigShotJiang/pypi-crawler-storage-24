# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ms_service_metric 命令行入口

提供控制metric收集的命令行工具。

用法:
    python -m ms_service_metric on      # 开启metric收集
    python -m ms_service_metric off     # 关闭metric收集
    python -m ms_service_metric restart # 重启metric收集
    python -m ms_service_metric status  # 查看状态
"""

import sys
from ms_service_metric.control.cli import main

if __name__ == "__main__":
    sys.exit(main())
