# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Hook 链管理系统

实现双向链表管理多个 hook 函数，支持动态添加、删除和调用。
对外接口：
1. add_hook(ori_func, hook_func) -> HookNode
2. HookNode.remove() -> bool
3. HookNode.call_prev(*args, **kwargs) -> 调用上一个
"""

import threading
import logging
from enum import Enum
from typing import Callable, Optional, Dict, Any, Any

logger = logging.getLogger(__name__)


class _NoResult(Enum):
    """用于表示还没有结果的特殊枚举值"""
    NO_RESULT = object()


NO_RESULT = _NoResult.NO_RESULT


class HookNode:
    """Hook 链表节点"""
    
    def __init__(self, chain: 'HookChain', prev_node: Optional['HookNode'] = None):
        self.chain = chain
        self.hook_func = self.call_prev
        self.prev_node = prev_node
        self.next_node: Optional['HookNode'] = None
    
    @property
    def ori_wrap(self):
        return self.call_prev
    
    def set_hook_func(self, hook_func: Callable):
        self.hook_func = hook_func
    
    
    def call_prev(self, *args, **kwargs):
        """调用上一个 hook 函数"""
        if self.prev_node:
            return self.prev_node.hook_func(*args, **kwargs)
        else:
            return self.chain._call_ori_func(*args, **kwargs)
    
    def remove(self) -> bool:
        return self.chain.remove_chain_node(self)


class HookChain:
    """Hook 链表管理器"""
    
    def __init__(self, ori_func: Callable):
        self.ori_func = ori_func
        self.head: Optional[HookNode] = None
        self.tail: Optional[HookNode] = None
        self._nodes: Dict[int, HookNode] = {}
        self._lock = threading.Lock()
        self._helper = None
        self._last_result = NO_RESULT  # 保存最后一次调用的结果
        
    def set_last_result(self, result):
        """设置最后一次调用的结果
        
        供外部使用（如字节码注入的场景），用于标记已经获取到结果
        
        Args:
            result: 要保存的结果值
        """
        self._last_result = result
        return result
        
    def _call_ori_func(self, *args, **kwargs):
        """调用原始函数并保存结果
        
        如果 ori_func 抛出异常，将异常包装后保存，并重新抛出
        """
        try:
            result = self.ori_func(*args, **kwargs)
            self._last_result = result
            return result
        except Exception as e:
            # ori_func 抛出异常，保存异常并重新抛出
            self._last_result = e
            raise
        
    def remove_chain_node(self, node: HookNode) -> bool:
        """删除节点"""
        with self._lock:
            if not self._nodes.get(id(node)):
                return False
            
            if node.prev_node:
                node.prev_node.next_node = node.next_node
            else:
                self.head = node.next_node
            
            if node.next_node:
                node.next_node.prev_node = node.prev_node
            else:
                self.tail = node.prev_node
            
            del self._nodes[id(node)]
            
            # 如果链表中没有节点了，恢复原函数
            if self.tail is None and self._helper:
                self._helper.recover()
                self._helper = None
            
            return True
    
    def add_chain_node(self, insert_at_head: bool = False) -> HookNode:
        """添加节点，返回 HookNode
        
        Args:
            insert_at_head: 如果为 True，插入到链表头部；否则插入到尾部（默认）
        """
        need_replace = False
        with self._lock:
            is_empty = self.tail is None
            
            if insert_at_head and self.head:
                # 插入到头部
                new_node = HookNode(self, None)
                new_node.next_node = self.head
                self.head.prev_node = new_node
                self.head = new_node
            else:
                # 插入到尾部（默认）
                new_node = HookNode(self, self.tail)
                if self.tail:
                    self.tail.next_node = new_node
                    self.tail = new_node
                else:
                    self.head = self.tail = new_node
            
            self._nodes[id(new_node)] = new_node
            
            # 如果之前没有节点，现在有了，需要 replace
            if is_empty:
                from ms_service_metric.core.hook_helper import HookHelper
                self._helper = HookHelper(self.ori_func, self.exec_chain_closure())
                need_replace = True
            
        # 在锁外执行 replace，避免阻塞其他线程
        if need_replace:
            self._helper.replace()
        
        return new_node
    
    def exec_chain_closure(self):
        def execute_hook_chain(*args, **kwargs):
            """执行 hook 链，带有异常保护机制
            
            保护策略：
            1. 先将 _last_result 重置为 NO_RESULT
            2. 执行 hook 链
            3. 如果执行过程中发生异常：
            - 如果 _last_result 还是 NO_RESULT（说明还没调用到 ori_func），主动调用一次 ori_func 并返回
            - 如果 _last_result 是异常（说明 ori_func 抛出了异常），直接重新抛出
            - 如果 _last_result 已经有正常值（说明已经调用过 ori_func），直接返回保存的结果
            4. 如果正常执行完成，返回 hook 链的结果
            """
            # 重置结果状态
            self._last_result = NO_RESULT
            
            logger.debug(f"Executing hook chain for {self.ori_func.__name__} with args={args}, kwargs={kwargs}")
            try:
                if self.tail is None:
                    # 没有 hook 节点，直接调用原函数
                    return self.ori_func(*args, **kwargs)
                else:
                    # 执行 hook 链
                    logger.debug(f"Executing hook chain for {self.ori_func.__name__}")
                    return self.tail.hook_func(*args, **kwargs)
            except Exception as ex:
                logger.error(f"Exception occurred in hook chain for {self.ori_func.__name__}: {ex}")
                # if logger.isEnabledFor(logging.DEBUG):
                import traceback
                traceback.print_exc()
                # 发生异常，检查是否已经调用过 ori_func
                if self._last_result is NO_RESULT:
                    # 还没调用到 ori_func，主动调用一次
                    return self.ori_func(*args, **kwargs)
                elif isinstance(self._last_result, Exception):
                    # ori_func 本身抛出了异常，直接重新抛出
                    raise self._last_result
                else:
                    # 已经调用过 ori_func 并返回了正常结果，返回保存的结果
                    return self._last_result
        return execute_hook_chain


def get_chain(ori_func: Callable) -> HookChain:
    """获取或创建 HookChain（公共函数）"""
    func_id = id(ori_func)
    with _cache_lock:
        if func_id in _chain_cache:
            cached_chain = _chain_cache[func_id]
            # 同步设置到函数属性，保持缓存和属性一致
            try:
                setattr(ori_func, '_hook_chain', cached_chain)
            except AttributeError:
                pass
            return cached_chain
        
        chain = HookChain(ori_func)
        _chain_cache[func_id] = chain
        
        try:
            setattr(ori_func, '_hook_chain', chain)
            setattr(chain, '_hook_chain', chain)
        except AttributeError:
            pass
        
        return chain


# 全局链缓存
_chain_cache: Dict[int, HookChain] = {}
_cache_lock = threading.Lock()