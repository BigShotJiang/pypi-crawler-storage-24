"""
ms_service_metric.core - 核心模块

包含所有核心类和功能实现。
"""

from ms_service_metric.core.logger import get_logger, setup_logging
from ms_service_metric.core.exceptions import (
    ServiceMetricError,
    ConfigError,
    HandlerError,
    SymbolError,
    HookError,
)
from ms_service_metric.core.symbol_config import SymbolConfig
from ms_service_metric.core.symbol import Symbol
from ms_service_metric.core.handler import Handler, HandlerType
from ms_service_metric.core.hook_helper import HookHelper
from ms_service_metric.core.metrics_manager import (
    MetricsManager,
    MetricConfig,
    MetricType,
    get_metrics_manager,
)
from ms_service_metric.core.symbol_watcher import SymbolWatcher, ModuleEvent, ModuleEventType
from ms_service_metric.core.metric_config_watch import MetricConfigWatch
from ms_service_metric.core.symbol_handler_manager import SymbolHandlerManager

__all__ = [
    # 日志
    "get_logger",
    "setup_logging",
    # 异常
    "ServiceMetricError",
    "ConfigError",
    "HandlerError",
    "SymbolError",
    "HookError",
    # 配置
    "SymbolConfig",
    # Symbol和Handler
    "Symbol",
    "Handler",
    "HandlerType",
    # Hook工具
    "HookHelper",
    # 指标管理
    "MetricsManager",
    "MetricConfig",
    "MetricType",
    "get_metrics_manager",
    # 模块监视
    "SymbolWatcher",
    "ModuleEvent",
    "ModuleEventType",
    # 配置热更新
    "MetricConfigWatch",
    # 核心管理器
    "SymbolHandlerManager",
]
