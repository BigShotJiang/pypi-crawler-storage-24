# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ModuleHook: 模块Hook相关工具

职责：
- 提供TrackableOriginalFunc类用于追踪原函数执行状态
- 避免重复执行原函数

使用示例：
    trackable = TrackableOriginalFunc(original_func)
    result = trackable(*args, **kwargs)
"""

import inspect
import functools
from typing import Any, Callable, Optional

from ms_service_metric.core.logger import get_logger

logger = get_logger("module_hook")


class TrackableOriginalFunc:
    """可追踪的原函数包装器
    
    用于避免重复执行原函数。当hook函数内部已经调用了原函数，
    但在后处理逻辑中出错时，可以通过此包装器检测原函数是否已执行，
    避免在异常处理中重复调用。
    
    Attributes:
        original_func: 原始函数
        executed: 是否已执行
        cached_result: 缓存的执行结果
        cached_exception: 缓存的异常（如果执行时抛出）
    """
    
    def __init__(self, original_func: Callable):
        """初始化可追踪的原函数包装器
        
        Args:
            original_func: 原始函数
        """
        self.original_func = original_func
        self.executed = False
        self.cached_result = None
        self.cached_exception = None
        self.__name__ = getattr(original_func, "__name__", "TrackableOriginalFunc")
    
    def __call__(self, *args, **kwargs):
        """调用原函数并缓存结果
        
        支持同步和异步函数：
        - 如果是异步函数，返回协程对象
        - 如果是同步函数，直接返回结果
        
        Args:
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            原函数的返回值（同步）或协程对象（异步）
            
        Raises:
            原函数抛出的异常
        """
        cached = self._check_cached_result()
        if cached is not None:
            return cached
        
        # 检查原函数是否是异步函数
        if inspect.iscoroutinefunction(self.original_func):
            # 异步函数，返回协程对象，由调用者 await
            return self._execute_and_cache_async(*args, **kwargs)
        else:
            # 同步函数，直接执行并缓存结果
            return self._execute_and_cache_sync(*args, **kwargs)
    
    def reset(self):
        """重置执行状态
        
        用于每次新的函数调用前，确保每次调用都是独立的。
        """
        self.executed = False
        self.cached_result = None
        self.cached_exception = None
    
    def call_with_reset(self, func: Callable) -> Callable:
        """装饰器：在每次函数调用时自动重置执行状态
        
        使用此装饰器装饰wrapper函数，可以确保每次调用时都会自动重置状态。
        
        Args:
            func: 要装饰的函数（可以是同步或异步函数）
            
        Returns:
            装饰后的函数
        """
        if inspect.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                self.reset()
                return await func(*args, **kwargs)
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                self.reset()
                return func(*args, **kwargs)
            return sync_wrapper
    
    def _check_cached_result(self) -> Any:
        """检查并返回缓存的结果
        
        Returns:
            缓存的返回值，如果没有缓存返回None
            
        Raises:
            如果执行时抛出异常，重新抛出该异常
        """
        if self.executed:
            if self.cached_exception is not None:
                raise self.cached_exception
            return self.cached_result
        return None
    
    def _execute_and_cache_sync(self, *args, **kwargs) -> Any:
        """执行同步函数并缓存结果
        
        Args:
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            原函数的返回值
            
        Raises:
            原函数抛出的异常
        """
        try:
            self.cached_result = self.original_func(*args, **kwargs)
            self.executed = True
            return self.cached_result
        except Exception as e:
            self.cached_exception = e
            self.executed = True
            raise
    
    async def _execute_and_cache_async(self, *args, **kwargs) -> Any:
        """执行异步函数并缓存结果
        
        Args:
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            原函数的返回值
            
        Raises:
            原函数抛出的异常
        """
        try:
            self.cached_result = await self.original_func(*args, **kwargs)
            self.executed = True
            return self.cached_result
        except Exception as e:
            self.cached_exception = e
            self.executed = True
            raise
