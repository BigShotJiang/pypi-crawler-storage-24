# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Shared Memory Manager - 共享内存管理器

统一管理ms_service_metric的共享内存操作，包括：
- 内存布局定义
- 共享内存创建/连接/断开
- 信号量操作
- 数据读写（状态、时间戳、进程列表）
- 进程管理（添加、清理）

使用方式:
    # 在被控制进程中
    manager = SharedMemoryManager()
    manager.connect()  # 连接或创建共享内存
    manager.add_current_process()  # 添加当前进程到列表
    
    # 在控制端
    manager = SharedMemoryManager()
    manager.connect()
    manager.send_control_command(is_start=True)  # 发送控制命令
"""

import os
import signal
import threading
import time
from typing import List, Optional, Tuple, Callable

# 仅在Linux平台导入posix_ipc
try:
    import posix_ipc
    import mmap
    POSIX_IPC_AVAILABLE = True
except ImportError:
    POSIX_IPC_AVAILABLE = False

from ms_service_metric.core.logger import get_logger
from ms_service_metric.core.exceptions import SharedMemoryError

logger = get_logger("shm_manager")

# 环境变量名称
ENV_SHM_PREFIX = "MS_SERVICE_METRIC_SHM_PREFIX"
ENV_MAX_PROCS = "MS_SERVICE_METRIC_MAX_PROCS"

# 默认值
DEFAULT_SHM_PREFIX = "/ms_service_metric"
DEFAULT_MAX_PROCS = 1000

# 状态值
STATE_OFF = 0
STATE_ON = 1


class SharedMemoryLayout:
    """共享内存布局定义"""
    
    # 基础头信息大小（字节）
    HEADER_SIZE = 32
    
    # 每个进程ID占用的字节数
    PROC_ENTRY_SIZE = 4
    
    # 内存布局偏移量
    OFFSET_STATE = 0       # 状态（int32）
    OFFSET_TIMESTAMP = 4   # 时间戳（int32）
    OFFSET_PROC_HEAD = 8   # 进程列表head游标（int32）
    OFFSET_PROC_LEN = 12   # 进程列表总长度（int32）
    OFFSET_RESERVED = 16   # 保留区域开始
    OFFSET_PROC_LIST = 32  # 进程列表开始
    
    @classmethod
    def get_shm_name(cls, prefix: str = DEFAULT_SHM_PREFIX) -> str:
        """获取共享内存完整名称"""
        return f"{prefix}_control"
    
    @classmethod
    def get_sem_name(cls, prefix: str = DEFAULT_SHM_PREFIX) -> str:
        """获取信号量完整名称"""
        return f"{prefix}_semaphore"
    
    @classmethod
    def calc_memory_size(cls, max_procs: int) -> int:
        """计算共享内存大小"""
        return cls.HEADER_SIZE + max_procs * cls.PROC_ENTRY_SIZE


class SharedMemoryManager:
    """共享内存管理器
    
    封装所有共享内存和信号量的操作。
    
    Attributes:
        _shm_prefix: 共享内存名称前缀
        _max_procs: 最大进程数
        _memory_size: 共享内存大小
        _shm: 共享内存对象
        _mmap: 内存映射对象
        _sem: 信号量对象
    """
    
    # 布局常量
    OFFSET_STATE = SharedMemoryLayout.OFFSET_STATE
    OFFSET_TIMESTAMP = SharedMemoryLayout.OFFSET_TIMESTAMP
    OFFSET_PROC_HEAD = SharedMemoryLayout.OFFSET_PROC_HEAD
    OFFSET_PROC_LEN = SharedMemoryLayout.OFFSET_PROC_LEN
    OFFSET_PROC_LIST = SharedMemoryLayout.OFFSET_PROC_LIST
    PROC_ENTRY_SIZE = SharedMemoryLayout.PROC_ENTRY_SIZE
    
    # 状态常量
    STATE_OFF = STATE_OFF
    STATE_ON = STATE_ON
    
    def __init__(
        self,
        shm_prefix: Optional[str] = None,
        max_procs: Optional[int] = None
    ):
        """初始化共享内存管理器
        
        Args:
            shm_prefix: 共享内存前缀（默认从环境变量读取）
            max_procs: 最大进程数（默认从环境变量读取）
        """
        if not POSIX_IPC_AVAILABLE:
            raise SharedMemoryError("posix_ipc not available, requires Linux platform")
        
        self._shm_prefix = shm_prefix or os.environ.get(ENV_SHM_PREFIX, DEFAULT_SHM_PREFIX)
        self._max_procs = max_procs or int(os.environ.get(ENV_MAX_PROCS, DEFAULT_MAX_PROCS))
        self._memory_size = SharedMemoryLayout.calc_memory_size(self._max_procs)
        
        self._shm_name = SharedMemoryLayout.get_shm_name(self._shm_prefix)
        self._sem_name = SharedMemoryLayout.get_sem_name(self._shm_prefix)
        
        self._shm = None
        self._mmap = None
        self._sem = None
        
        logger.debug(f"SharedMemoryManager initialized: shm={self._shm_name}, max_procs={self._max_procs}")
    
    # ========== 连接管理 ==========
    
    def connect(self, create: bool = True) -> bool:
        """连接到共享内存
        
        Args:
            create: 如果不存在是否创建
            
        Returns:
            是否连接成功
        """
        try:
            # 尝试打开已存在的共享内存
            self._shm = posix_ipc.SharedMemory(self._shm_name)
            self._mmap = mmap.mmap(self._shm.fd, self._memory_size)
            logger.debug(f"Connected to existing shared memory: {self._shm_name}")
        except posix_ipc.ExistentialError:
            if not create:
                logger.error(f"Shared memory not found: {self._shm_name}")
                return False
            # 创建新的共享内存
            logger.debug(f"Creating new shared memory: {self._shm_name}")
            self._shm = posix_ipc.SharedMemory(
                self._shm_name,
                flags=posix_ipc.O_CREX,
                size=self._memory_size
            )
            self._mmap = mmap.mmap(self._shm.fd, self._memory_size)
            # 初始化为全0
            self._mmap[:] = b'\x00' * self._memory_size
        
        # 连接或创建信号量
        try:
            self._sem = posix_ipc.Semaphore(self._sem_name)
            logger.debug(f"Connected to existing semaphore: {self._sem_name}")
        except posix_ipc.ExistentialError:
            logger.debug(f"Creating new semaphore: {self._sem_name}")
            self._sem = posix_ipc.Semaphore(
                self._sem_name,
                flags=posix_ipc.O_CREX,
                initial_value=1
            )
        
        return True
    
    def disconnect(self):
        """断开连接"""
        if self._mmap:
            self._mmap.close()
            self._mmap = None
        if self._shm:
            posix_ipc.close_shared_memory(self._shm)
            self._shm = None
        if self._sem:
            self._sem.close()
            self._sem = None
        logger.debug("Disconnected from shared memory")
    
    def __enter__(self):
        """上下文管理器入口"""
        self.connect()
        return self
    
    def __exit__(self, *args):
        """上下文管理器出口"""
        self.disconnect()
    
    # ========== 信号量操作 ==========
    
    def lock(self):
        """获取信号量锁（阻塞）"""
        if self._sem:
            self._sem.acquire()
    
    def unlock(self):
        """释放信号量锁"""
        if self._sem:
            self._sem.release()
    
    def semaphore_lock(self):
        """获取信号量锁（上下文管理器）
        
        使用方式:
            with manager.semaphore_lock():
                # 临界区代码
                pass
        """
        class SemaphoreLock:
            def __init__(self, sem):
                self._sem = sem
            def __enter__(self):
                if self._sem:
                    self._sem.acquire()
            def __exit__(self, *args):
                if self._sem:
                    self._sem.release()
        return SemaphoreLock(self._sem)
    
    # ========== 基础读写 ==========
    
    def read_int(self, offset: int) -> int:
        """从共享内存读取int32"""
        if not self._mmap:
            return 0
        return int.from_bytes(self._mmap[offset:offset+4], 'little', signed=True)
    
    def write_int(self, offset: int, value: int):
        """向共享内存写入int32"""
        if not self._mmap:
            return
        self._mmap[offset:offset+4] = value.to_bytes(4, 'little', signed=True)
    
    # ========== 状态操作 ==========
    
    def get_state(self) -> int:
        """获取当前状态"""
        return self.read_int(self.OFFSET_STATE)
    
    def set_state(self, state: int):
        """设置状态"""
        self.write_int(self.OFFSET_STATE, state)
    
    def get_timestamp(self) -> int:
        """获取时间戳"""
        return self.read_int(self.OFFSET_TIMESTAMP)
    
    def set_timestamp(self, timestamp: int):
        """设置时间戳"""
        self.write_int(self.OFFSET_TIMESTAMP, timestamp)
    
    def update_state_and_timestamp(self, state: int):
        """同时更新状态和时间戳"""
        with self.semaphore_lock():
            self.set_state(state)
            self.set_timestamp(int(time.time()))
    
    # ========== 进程列表操作 ==========
    
    def get_proc_len(self) -> int:
        """获取进程列表总长度"""
        proc_len = self.read_int(self.OFFSET_PROC_LEN)
        if proc_len <= 0:
            proc_len = self._max_procs
        return proc_len
    
    def set_proc_len(self, proc_len: int):
        """设置进程列表总长度"""
        self.write_int(self.OFFSET_PROC_LEN, proc_len)
    
    def get_proc_head(self) -> int:
        """获取进程列表head游标"""
        return self.read_int(self.OFFSET_PROC_HEAD)
    
    def set_proc_head(self, head: int):
        """设置进程列表head游标"""
        self.write_int(self.OFFSET_PROC_HEAD, head)
    
    def get_proc_at(self, index: int) -> int:
        """获取指定索引的进程ID"""
        offset = self.OFFSET_PROC_LIST + index * self.PROC_ENTRY_SIZE
        return self.read_int(offset)
    
    def set_proc_at(self, index: int, pid: int):
        """设置指定索引的进程ID"""
        offset = self.OFFSET_PROC_LIST + index * self.PROC_ENTRY_SIZE
        self.write_int(offset, pid)
    
    def get_all_procs(self) -> List[int]:
        """获取所有有效进程ID（去重）"""
        proc_len = self.get_proc_len()
        procs = set()
        for i in range(proc_len):
            pid = self.get_proc_at(i)
            if pid > 0:
                procs.add(pid)
        return list(procs)
    
    def add_process(self, pid: Optional[int] = None) -> int:
        """添加进程到列表
        
        Args:
            pid: 进程ID（默认当前进程）
            
        Returns:
            写入的位置索引
        """
        if pid is None:
            pid = os.getpid()
        
        with self.semaphore_lock():
            head = self.get_proc_head()
            proc_len = self.get_proc_len()
            
            # 如果长度为0，说明是首次使用
            if proc_len == 0:
                proc_len = self._max_procs
                self.set_proc_len(proc_len)
            
            # 计算写入位置
            index = head % proc_len
            self.set_proc_at(index, pid)
            
            # 更新head游标
            new_head = (head + 1) % proc_len
            self.set_proc_head(new_head)
            
            logger.debug(f"Added process {pid} at index {index}, new_head={new_head}")
            return index
    
    def add_current_process(self) -> int:
        """添加当前进程到列表"""
        return self.add_process(os.getpid())
    
    # ========== 控制命令 ==========
    
    def send_control_command(
        self,
        is_start: bool,
        force: bool = False,
        send_signal: bool = True
    ) -> Tuple[bool, int, int, bool]:
        """发送控制命令
        
        Args:
            is_start: 控制状态，True=开启，False=关闭
            force: 是否强制执行
            send_signal: 是否发送SIGUSR1信号
            
        Returns:
            (是否成功, 成功发送信号数, 清理的无效进程数, 是否实际执行了变更)
        """
        target_state = self.STATE_ON if is_start else self.STATE_OFF
        
        with self.semaphore_lock():
            # 检查当前状态
            current_state = self.get_state()
            
            # 如果不是强制模式，且状态没有变化，则跳过
            if not force and current_state == target_state:
                action = "START" if is_start else "STOP"
                logger.info(f"State already {action}, no change needed")
                return True, 0, 0, False
            
            # 1. 先更新状态和时间戳
            self.set_state(target_state)
            self.set_timestamp(int(time.time()))
            
            # 2. 发送信号并清理无效进程
            if send_signal:
                signaled, cleaned = self._send_signals_and_cleanup()
            else:
                signaled, cleaned = 0, 0
            
            action = "START" if is_start else "STOP"
            logger.info(f"Sent {action} command to {signaled} processes, cleaned {cleaned}")
            return True, signaled, cleaned, True
    
    def _send_signals_and_cleanup(self) -> Tuple[int, int]:
        """发送信号并清理无效进程
        
        Returns:
            (成功发送信号数, 清理的无效进程数)
        """
        signaled = 0
        cleaned = 0
        proc_len = self.get_proc_len()
        
        for i in range(proc_len):
            pid = self.get_proc_at(i)
            
            if pid <= 0:
                continue
            
            try:
                os.kill(pid, signal.SIGUSR1)
                signaled += 1
                logger.debug(f"Sent SIGUSR1 to process {pid}")
            except ProcessLookupError:
                # 进程不存在，立即清理
                self.set_proc_at(i, 0)
                cleaned += 1
                logger.debug(f"Process {pid} not found, cleaned immediately")
            except PermissionError:
                logger.warning(f"Permission denied to signal process {pid}")
            except Exception as e:
                logger.warning(f"Failed to signal process {pid}: {e}")
        
        return signaled, cleaned
    
    # ========== 状态查询 ==========
    
    def get_status(self) -> dict:
        """获取完整状态信息"""
        with self.semaphore_lock():
            return {
                "state": "ON" if self.get_state() == self.STATE_ON else "OFF",
                "timestamp": self.get_timestamp(),
                "process_head": self.get_proc_head(),
                "process_list_len": self.get_proc_len(),
                "process_count": len(self.get_all_procs()),
                "processes": self.get_all_procs(),
            }


# 便捷函数
def get_shm_name(prefix: str = DEFAULT_SHM_PREFIX) -> str:
    """获取共享内存完整名称"""
    return SharedMemoryLayout.get_shm_name(prefix)


def get_sem_name(prefix: str = DEFAULT_SHM_PREFIX) -> str:
    """获取信号量完整名称"""
    return SharedMemoryLayout.get_sem_name(prefix)


__all__ = [
    # 常量
    'ENV_SHM_PREFIX',
    'ENV_MAX_PROCS',
    'DEFAULT_SHM_PREFIX',
    'DEFAULT_MAX_PROCS',
    'STATE_OFF',
    'STATE_ON',
    # 类
    'SharedMemoryLayout',
    'SharedMemoryManager',
    # 函数
    'get_shm_name',
    'get_sem_name',
]
