"""
ms_service_metric.adapters.sglang - SGLang适配器

提供对SGLang推理框架的适配支持。
"""

from ms_service_metric.adapters.sglang.adapter import (
    SGLangMetricAdapter,
    initialize_sglang_metric,
)

__all__ = [
    "SGLangMetricAdapter",
    "initialize_sglang_metric",
]
