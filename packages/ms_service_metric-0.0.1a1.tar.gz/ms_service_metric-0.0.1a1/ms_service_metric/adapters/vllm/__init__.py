"""
ms_service_metric.adapters.vllm - vLLM适配器

提供对vLLM推理框架的适配支持。
"""

from ms_service_metric.adapters.vllm.adapter import (
    VLLMMetricAdapter,
    initialize_vllm_metric,
)
from ms_service_metric.adapters.vllm.metrics_init import (
    setup_vllm_metrics,
    set_vllm_multiprocess_prometheus,
    set_vllm_registry,
    set_vllm_metric_prefix,
    VLLM_METRICS_PREFIX,
)

__all__ = [
    "VLLMMetricAdapter",
    "initialize_vllm_metric",
    # metrics_init
    "setup_vllm_metrics",
    "set_vllm_multiprocess_prometheus",
    "set_vllm_registry",
    "set_vllm_metric_prefix",
    "VLLM_METRICS_PREFIX",
]
