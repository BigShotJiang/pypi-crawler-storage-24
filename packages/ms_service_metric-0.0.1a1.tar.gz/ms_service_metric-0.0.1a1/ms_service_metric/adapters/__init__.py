"""
ms_service_metric.adapters - 框架适配器模块

提供对不同推理框架（vLLM、SGLang等）的适配支持。
"""

__all__ = []
