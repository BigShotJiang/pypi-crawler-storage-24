"""
ms_service_metric.handlers - 内置Handler模块

提供常用的内置handler函数，可用于配置中直接使用。
"""

from ms_service_metric.handlers.builtin import (
    timer_handler,
    counter_handler,
    gauge_handler,
    default_handler,
)

__all__ = [
    "timer_handler",
    "counter_handler",
    "gauge_handler",
    "default_handler",
]
