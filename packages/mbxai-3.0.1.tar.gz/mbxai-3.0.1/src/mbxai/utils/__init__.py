"""Utility functions and clients."""
