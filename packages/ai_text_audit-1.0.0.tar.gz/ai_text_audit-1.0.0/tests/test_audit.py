"""Tests for ai-text-audit."""
import pytest
from ai_text_audit import Auditor, AuditResult
from ai_text_audit.patterns import Pattern, ENGLISH_PATTERNS, CHINESE_PATTERNS


class TestPatterns:
    def test_english_patterns_loaded(self):
        assert len(ENGLISH_PATTERNS) >= 15

    def test_chinese_patterns_loaded(self):
        assert len(CHINESE_PATTERNS) >= 4

    def test_pattern_matching(self):
        pattern = ENGLISH_PATTERNS[0]  # em_dash
        assert pattern.count("This — is — a test") == 2
        assert pattern.count("No dashes here") == 0

    def test_pattern_compile_cached(self):
        pattern = ENGLISH_PATTERNS[0]
        c1 = pattern.compile()
        c2 = pattern.compile()
        assert c1 is c2  # Same compiled object


class TestAuditor:
    def setup_method(self):
        self.auditor = Auditor(language="all")

    def test_empty_text(self):
        result = self.auditor.analyze("")
        assert result.score == 0.0
        assert result.verdict == "likely_human"

    def test_human_text(self):
        text = "I went to the store today. Bought some milk and bread. The weather was cold."
        result = self.auditor.analyze(text)
        assert result.score < 30
        assert result.verdict == "likely_human"

    def test_ai_text(self):
        text = (
            "This groundbreaking tool represents a pivotal advancement in the field. "
            "It is crucial to delve into this multifaceted landscape. "
            "This stands as a testament to human ingenuity. "
            "Furthermore, it is worth noting that the comprehensive, robust, and seamless "
            "integration ensures optimal performance. "
            "I hope this helps! Let me know if you have any questions!"
        )
        result = self.auditor.analyze(text)
        assert result.score > 50
        assert len(result.patterns) >= 4
        assert result.verdict in ("possibly_ai", "likely_ai")

    def test_em_dash_detection(self):
        text = "This — is — a test — with — many — dashes"
        result = self.auditor.analyze(text)
        em_patterns = [p for p in result.patterns if p.name == "em_dash"]
        assert len(em_patterns) == 1
        assert em_patterns[0].count == 5

    def test_chinese_detection(self):
        text = "值得注意的是，这个颠覆性产品具有重大的意义。这不仅是一个工具，更是一种全新的思维方式。"
        result = self.auditor.analyze(text)
        assert result.score > 20
        cn_patterns = [p for p in result.patterns if p.name.startswith("cn_")]
        assert len(cn_patterns) >= 2

    def test_suggestions_generated(self):
        text = "I hope this helps! It is crucial to delve into this landscape."
        result = self.auditor.analyze(text)
        assert len(result.suggestions) >= 1

    def test_to_dict(self):
        text = "This is a test — with an em dash."
        result = self.auditor.analyze(text)
        d = result.to_dict()
        assert "score" in d
        assert "verdict" in d
        assert "patterns" in d
        assert isinstance(d["patterns"], list)


class TestThresholds:
    def test_custom_threshold(self):
        auditor = Auditor(threshold_ai=30, threshold_possible=15)
        text = "This — is a test."
        result = auditor.analyze(text)
        # Should work with custom thresholds
        assert result.verdict in ("likely_human", "possibly_ai", "likely_ai")


class TestIntegration:
    def test_long_text(self):
        text = "Hello world. " * 500
        auditor = Auditor()
        result = auditor.analyze(text)
        assert result.word_count == 1000
        assert result.score < 20  # No AI patterns

    def test_performance(self):
        """1000 words should analyze in < 100ms."""
        import time
        text = "This is a normal sentence about everyday things. " * 200
        auditor = Auditor()
        start = time.time()
        result = auditor.analyze(text)
        elapsed = time.time() - start
        assert elapsed < 0.1, f"Too slow: {elapsed:.3f}s"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
