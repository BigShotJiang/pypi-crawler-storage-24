"""
ai-text-audit — Detect AI writing patterns. Make text human again.

A fast, offline CLI tool and Python library that detects AI-generated
text patterns based on linguistic analysis.
"""

__version__ = "1.0.0"
__author__ = "sudabg"

from .auditor import Auditor, AuditResult
from .patterns import PATTERN_REGISTRY

__all__ = ["Auditor", "AuditResult", "PATTERN_REGISTRY"]
