# tikr-report

Báo cáo TikTok nhanh qua API — không cần trình duyệt, không cần đăng nhập.

## Cài đặt

```bash
pipx install tikr-report
```

## Sử dụng

### 1. Thiết lập

```bash
tikr setup
```

Wizard sẽ hỏi:
- **Số thread** đồng thời mỗi vòng (mặc định 5)
- **Thời gian chờ** giữa các vòng, tính bằng giây (`0` = không chờ)
- **Proxy** — API key của [proxyxoay.shop](https://proxyxoay.shop) (bỏ trống nếu không dùng)

### 2. Lấy Report URL

1. Mở TikTok trên trình duyệt, vào trang profile cần report
2. Mở **DevTools** (`F12`) → tab **Network** → xóa log (`Ctrl+L`)
3. Report thủ công 1 lần: **Actions → Report → chọn lý do → Submit**
4. Trong Network, tìm request có chứa `feedback` → chuột phải → **Copy URL**

### 3. Chạy

```bash
tikr run <report-url>
```

Hoặc chạy không tham số để chọn URL đã dùng gần đây:

```bash
tikr run
```

Kết quả mỗi vòng:

```
--- Vong 1 (5 threads) ---
  Proxy: http://42.117.243.215:10836  (con 1750s)
  Ket qua: 5 OK / 0 FAIL  (tong: 5 OK)
  Cho 120s ...
  Con lai: 01:58

--- Vong 2 (5 threads) ---
  ...
```

Dừng bất cứ lúc nào bằng `Ctrl+C` — tool hiển thị tổng kết trước khi thoát.

## Lưu ý

- **Report URL chứa session token** và sẽ hết hạn sau một thời gian. Khi gặp lỗi liên tục, lấy URL mới từ DevTools rồi chạy lại.
- Nếu dùng proxy IP whitelist (proxyxoay.shop), đảm bảo IP máy bạn đã được whitelist trong tài khoản.

## Cấu hình

Lưu tại `~/.tikr-report/settings.json`:

```json
{
  "threads": 5,
  "timeout_sec": 120,
  "proxy_key": "your_api_key_here"
}
```

## Giấy phép

MIT
