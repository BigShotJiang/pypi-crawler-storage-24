#!/usr/bin/env bash
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$DIR/.venv"
SCRIPT="$DIR/tikr_report.py"

# Tao venv neu chua co
if [ ! -f "$VENV/bin/python" ]; then
  echo "  Tao virtual environment..."
  python3 -m venv "$VENV"
fi

# Cai deps neu chua co
if ! "$VENV/bin/python" -c "import click, questionary, tls_client" 2>/dev/null; then
  echo "  Cai dependencies..."
  "$VENV/bin/pip" install -q click questionary tls-client typing_extensions
fi

exec "$VENV/bin/python" "$SCRIPT" "$@"
