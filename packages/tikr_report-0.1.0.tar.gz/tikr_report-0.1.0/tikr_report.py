"""
tikr-report — Bao cao TikTok nhanh qua API (tls_client), khong can trinh duyet.
"""
from __future__ import annotations

import json
import re
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import click
import questionary
import tls_client

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

APP_DIR = Path.home() / ".tikr-report"
SETTINGS_FILE = APP_DIR / "settings.json"
MAX_RECENT = 10


def load() -> dict:
    if not SETTINGS_FILE.exists():
        return {}
    return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))


def save(cfg: dict) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")


def add_recent(cfg: dict, url: str) -> None:
    recent = [x for x in cfg.get("recent", []) if x != url]
    recent.insert(0, url)
    cfg["recent"] = recent[:MAX_RECENT]
    save(cfg)


# ---------------------------------------------------------------------------
# Proxy (proxyxoay.shop)
# ---------------------------------------------------------------------------

_PROXY_API = "https://proxyxoay.shop/api/get.php"


class ProxyInfo:
    def __init__(self, http_url: str, expires_at: float):
        self.http_url = http_url
        self.expires_at = expires_at

    def seconds_left(self) -> int:
        return max(0, int(self.expires_at - time.time()))

    def is_expired(self, buffer: float = 60.0) -> bool:
        return time.time() >= self.expires_at - buffer


def fetch_proxy(key: str) -> ProxyInfo:
    url = f"{_PROXY_API}?key={key}&nhamang=random&tinhthanh=0&whitelist="
    req = urllib.request.Request(url, headers={"User-Agent": "tikr-report/1.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read().decode())
    if data.get("status") != 100:
        raise RuntimeError(data.get("message", str(data)))
    host, port = data["proxyhttp"].split(":")[:2]
    match = re.search(r"(\d+)s", data.get("message", ""))
    ttl = int(match.group(1)) if match else 300
    return ProxyInfo(f"http://{host}:{port}", time.time() + ttl)


# ---------------------------------------------------------------------------
# Reporter
# ---------------------------------------------------------------------------

def report_one(report_url: str, proxy_http: str | None) -> bool:
    session = tls_client.Session(client_identifier="chrome112", random_tls_extension_order=True)
    if proxy_http:
        session.proxies = {"http": proxy_http, "https": proxy_http}
    try:
        resp = session.get(report_url, timeout_seconds=15)
        return resp.status_code == 200
    except Exception:
        return False


def report_batch(report_url: str, threads: int, proxy_http: str | None) -> tuple[int, int]:
    ok = fail = 0
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futures = [ex.submit(report_one, report_url, proxy_http) for _ in range(threads)]
        for f in as_completed(futures):
            if f.result():
                ok += 1
            else:
                fail += 1
    return ok, fail


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def countdown(seconds: int) -> None:
    while seconds > 0:
        m, s = divmod(seconds, 60)
        click.echo(f"\r  Con lai: {m:02d}:{s:02d}  ", nl=False)
        time.sleep(1)
        seconds -= 1
    click.echo("\r  Bat dau vong moi ...              ")


def pick_url(cfg: dict, arg: str | None) -> str | None:
    if arg:
        return arg
    recent = cfg.get("recent", [])
    if not recent:
        return click.prompt("  Dan Report URL (tu DevTools TikTok)")
    _NEW = "__new__"
    choices = [questionary.Choice(title=u[:90], value=u) for u in recent]
    choices.append(questionary.Choice(title="-- Nhap URL moi --", value=_NEW))
    chosen = questionary.select("Chon Report URL:", choices=choices).ask()
    if chosen is None:
        return None
    if chosen == _NEW:
        return click.prompt("  Dan Report URL")
    return chosen


def get_proxy(cfg: dict) -> tuple[ProxyInfo | None, str]:
    """Lay proxy theo cau hinh. Tra ve (info, http_url_or_empty)."""
    key = cfg.get("proxy_key", "")
    if not key:
        return None, ""
    click.echo("  [proxy] Lay proxy ...")
    try:
        info = fetch_proxy(key)
        click.echo(f"  [proxy] {info.http_url}  (con {info.seconds_left()}s)")
        return info, info.http_url
    except Exception as e:
        click.echo(f"  [proxy] Loi: {e}", err=True)
        return None, ""


def refresh_if_expired(
    proxy: ProxyInfo | None, key: str
) -> tuple[ProxyInfo | None, str]:
    if not key:
        return proxy, ""
    if proxy and not proxy.is_expired():
        return proxy, proxy.http_url
    click.echo("\n  [proxy] Proxy sap het han, lay moi ...")
    try:
        new = fetch_proxy(key)
        click.echo(f"  [proxy] {new.http_url}  (con {new.seconds_left()}s)")
        return new, new.http_url
    except Exception as e:
        click.echo(f"  [proxy] Loi: {e}", err=True)
        return proxy, proxy.http_url if proxy else ""


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

@click.group()
def cli():
    """tikr-report — Bao cao TikTok nhanh qua API."""


@cli.command()
def setup():
    """Cau hinh threads, timeout va proxy."""
    cfg = load()

    click.echo("\n  TIKR — THIET LAP\n")

    # Threads
    threads = click.prompt(
        "  So thread dong thoi moi vong",
        type=int,
        default=cfg.get("threads", 5),
    )
    threads = max(1, min(threads, 100))

    # Timeout
    timeout_sec = click.prompt(
        "  Thoi gian cho giua cac vong (giay, 0 = khong cho)",
        type=int,
        default=cfg.get("timeout_sec", 120),
    )
    timeout_sec = max(0, timeout_sec)

    # Proxy
    use_proxy = questionary.confirm(
        "  Su dung proxy xoay (proxyxoay.shop)?",
        default=bool(cfg.get("proxy_key")),
    ).ask()

    proxy_key = ""
    if use_proxy:
        proxy_key = click.prompt(
            "  API key proxyxoay.shop",
            default=cfg.get("proxy_key", ""),
        ).strip()
        if proxy_key:
            click.echo("  Kiem tra proxy ...")
            try:
                info = fetch_proxy(proxy_key)
                click.echo(f"  [OK] {info.http_url}  (con {info.seconds_left()}s)")
            except Exception as e:
                click.echo(f"  [WARN] Kiem tra that bai: {e}")
                if not click.confirm("  Tiep tuc luu?", default=False):
                    return

    cfg.update({"threads": threads, "timeout_sec": timeout_sec, "proxy_key": proxy_key})
    save(cfg)

    click.echo(f"\n  Da luu:")
    click.echo(f"    Threads : {threads}")
    click.echo(f"    Timeout : {timeout_sec}s" + (" (khong cho)" if timeout_sec == 0 else ""))
    click.echo(f"    Proxy   : {'proxyxoay.shop' if proxy_key else 'Tat'}")

    click.echo("\nHuong dan lay Report URL:")
    click.echo("  1. Mo TikTok tren trinh duyet, vao trang profile can report")
    click.echo("  2. Mo DevTools (F12) → tab Network → xoa log (Ctrl+L)")
    click.echo("  3. Report thu cong 1 lan (Actions → Report → chon ly do → Submit)")
    click.echo("  4. Tim request chua 'feedback' → chuot phai → Copy URL")
    click.echo("  5. Chay: tikr run <url>")


@cli.command()
@click.argument("url", required=False)
def run(url: str | None):
    """Bao cao lien tuc bang Report URL tu DevTools."""
    cfg = load()
    if not cfg:
        click.echo("Chua co cau hinh. Chay `tikr setup` truoc.", err=True)
        sys.exit(1)

    report_url = pick_url(cfg, url)
    if not report_url:
        sys.exit(0)

    add_recent(cfg, report_url)

    threads: int = cfg.get("threads", 5)
    timeout_sec: int = cfg.get("timeout_sec", 120)
    proxy_key: str = cfg.get("proxy_key", "")

    timeout_display = f"{timeout_sec}s" if timeout_sec > 0 else "Khong cho"

    proxy, proxy_http = get_proxy(cfg)

    click.echo(f"\n  TIKR — BAT DAU")
    click.echo(f"  URL     : ...{report_url[-50:]}")
    click.echo(f"  Threads : {threads}")
    click.echo(f"  Timeout : {timeout_display}")
    click.echo(f"  Proxy   : {proxy_http or 'Tat'}\n")

    round_num = 0
    total_ok = total_fail = 0

    try:
        while True:
            round_num += 1
            proxy, proxy_http = refresh_if_expired(proxy, proxy_key)

            click.echo(f"--- Vong {round_num} ({threads} threads) ---")
            if proxy:
                click.echo(f"  Proxy: {proxy.http_url}  (con {proxy.seconds_left()}s)")

            ok, fail = report_batch(report_url, threads, proxy_http or None)
            total_ok += ok
            total_fail += fail

            click.echo(f"  Ket qua: {ok} OK / {fail} FAIL  (tong: {total_ok} OK)")

            if timeout_sec > 0:
                click.echo(f"  Cho {timeout_sec}s ...")
                countdown(timeout_sec)

    except KeyboardInterrupt:
        click.echo(f"\n\n  Da dung. Tong ket: {total_ok} OK / {total_fail} FAIL")


if __name__ == "__main__":
    cli()
