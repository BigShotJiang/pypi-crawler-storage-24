from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="urlcache2db",
    version="0.1.2",
    author="ArtOfScripting",
    description="A lightweight Python library that fetches URL content and stores it in a local SQLite database for a specified amount of time.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/artofscripting/urlcache2db",
    py_modules=["urlcache"],
    install_requires=["requests>=2.0.0"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)