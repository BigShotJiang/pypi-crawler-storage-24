import sqlite3
import time
import requests
import json
import hashlib

class URLCache:
    """
    A simple library to fetch URL content and cache it in a SQLite database.
    """
    def __init__(self, db_path="url_cache.db", expiration_seconds=3600):
        """
        Initialize the URL cache.
        
        :param db_path: Path to the SQLite database file.
        :param expiration_seconds: How long (in seconds) the cache is valid.
        """
        self.db_path = db_path
        self.expiration_seconds = expiration_seconds
        self._init_db()

    def _init_db(self):
        """Creates the cache table if it doesn't exist."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cache (
                    url TEXT PRIMARY KEY,
                    content TEXT,
                    timestamp REAL
                )
            ''')
            conn.commit()

    def _generate_cache_key(self, url, headers, data):
        """Generates a unique cache key based on url, headers, and data."""
        key_data = {
            "url": url,
            "headers": headers,
            "data": data
        }
        # Sort keys to ensure consistent serialization
        serialized = json.dumps(key_data, sort_keys=True)
        return hashlib.sha256(serialized.encode('utf-8')).hexdigest()

    def get(self, url, headers=None, data=None, verify=False, user_agent=None):
        """
        Fetch the content of the URL.
        Returns cached content if available and not expired.
        Otherwise, fetches from the web, updates the cache, and returns the content.
        """
        if user_agent:
            headers = headers or {}
            headers['User-Agent'] = user_agent
            
        cache_key = self._generate_cache_key(url, headers, data)
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT content, timestamp FROM cache WHERE url = ?', (cache_key,))
            row = cursor.fetchone()

            current_time = time.time()

            # Check if cached and not expired
            if row:
                content, timestamp = row
                if current_time - timestamp < self.expiration_seconds:
                    print(f"Returning cached data for: {url}")
                    return content

            # Fetch new content if not in cache or expired
            print(f"Fetching fresh data for: {url}")
            response = requests.get(url, headers=headers, data=data, verify=verify)
            response.raise_for_status()
            new_content = response.text

            # Update cache using UPSERT
            cursor.execute('''
                INSERT INTO cache (url, content, timestamp)
                VALUES (?, ?, ?)
                ON CONFLICT(url) DO UPDATE SET
                    content=excluded.content,
                    timestamp=excluded.timestamp
            ''', (cache_key, new_content, current_time))
            conn.commit()

            return new_content
            
    def clear_expired(self):
        """Removes expired entries from the SQLite database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cutoff_time = time.time() - self.expiration_seconds
            cursor.execute('DELETE FROM cache WHERE timestamp < ?', (cutoff_time,))
            conn.commit()
