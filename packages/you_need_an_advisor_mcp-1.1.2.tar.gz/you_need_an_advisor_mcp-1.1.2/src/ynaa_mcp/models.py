"""Pydantic models and TypedDicts for YNAB API responses.

Base models for validating and typing YNAB API response data.
All models use ``extra="ignore"`` so that additional fields returned
by the YNAB API do not cause validation errors.

TypedDicts provide lightweight structural types for raw API response
dicts where key-access patterns need type safety under pyright strict
mode, without the overhead of Pydantic validation.
"""

from typing import Any, TypedDict

from pydantic import BaseModel, ConfigDict


# ---------------------------------------------------------------------------
# TypedDict definitions for raw API response shapes (used with dict access)
# ---------------------------------------------------------------------------


class AccountsResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/accounts."""

    accounts: list[dict[str, Any]]


class AccountResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/accounts/{id}."""

    account: dict[str, Any]


class TransactionsResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/transactions."""

    transactions: list[dict[str, Any]]


class TransactionResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/transactions/{id}."""

    transaction: dict[str, Any]


class CategoriesResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/categories."""

    category_groups: list[dict[str, Any]]


class CategoryResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/categories/{id}."""

    category: dict[str, Any]


class PayeesResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/payees."""

    payees: list[dict[str, Any]]


class PayeeResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/payees/{id}."""

    payee: dict[str, Any]


class PayeeLocationsResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/payee_locations."""

    payee_locations: list[dict[str, Any]]


class PayeeLocationResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/payee_locations/{id}."""

    payee_location: dict[str, Any]


class MonthsResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/months."""

    months: list[dict[str, Any]]


class MonthResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/months/{month}."""

    month: dict[str, Any]


class MoneyMovementsResponseData(TypedDict):
    """Shape of ``data`` from GET .../money_movements."""

    money_movements: list[dict[str, Any]]


class MoneyMovementGroupsResponseData(TypedDict):
    """Shape of ``data`` from GET .../money_movement_groups."""

    money_movement_groups: list[dict[str, Any]]


class ScheduledTransactionsResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/scheduled_transactions."""

    scheduled_transactions: list[dict[str, Any]]


class ScheduledTransactionResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/scheduled_transactions/{id}."""

    scheduled_transaction: dict[str, Any]


class BudgetResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}."""

    budget: dict[str, Any]


class SettingsResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets/{id}/settings."""

    settings: dict[str, Any]


class UserResponseData(TypedDict):
    """Shape of ``data`` from GET /user."""

    user: dict[str, Any]


class BudgetsResponseData(TypedDict):
    """Shape of ``data`` from GET /budgets."""

    budgets: list[dict[str, Any]]


class CategoryGroupResponseData(TypedDict):
    """Shape of ``data`` from POST/PATCH category groups."""

    category_group: dict[str, Any]


class BatchTransactionResponseData(TypedDict, total=False):
    """Shape of ``data`` from batch transaction create/update."""

    transaction_ids: list[str]
    duplicate_import_ids: list[str]


class ErrorDetail(BaseModel):
    """A single YNAB API error detail.

    Attributes:
        id: YNAB error identifier (e.g., "404.2").
        name: Error name (e.g., "resource_not_found").
        detail: Human-readable error description.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    detail: str


class ErrorResponse(BaseModel):
    """Top-level YNAB API error response wrapper.

    Attributes:
        error: The error detail object.
    """

    model_config = ConfigDict(extra="ignore")

    error: ErrorDetail


class BudgetSummary(BaseModel):
    """Summary of a single YNAB budget.

    Attributes:
        id: Budget UUID.
        name: Budget display name.
        last_modified_on: ISO 8601 timestamp of last modification.
        first_month: First month in the budget (YYYY-MM-DD).
        last_month: Last month in the budget (YYYY-MM-DD).
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    last_modified_on: str
    first_month: str
    last_month: str


class BudgetsResponse(BaseModel):
    """Response wrapper for the GET /budgets endpoint.

    Attributes:
        budgets: List of budget summaries.
    """

    model_config = ConfigDict(extra="ignore")

    budgets: list[BudgetSummary]


class Account(BaseModel):
    """A YNAB account.

    Attributes:
        id: Account UUID.
        name: Account display name.
        type: Account type (checking, savings, etc.).
        on_budget: Whether account is on-budget.
        closed: Whether account is closed.
        balance: Current balance in dollars (converted from milliunits).
        cleared_balance: Cleared balance in dollars.
        uncleared_balance: Uncleared balance in dollars.
        note: Optional account note.
        transfer_payee_id: Payee ID for transfers to this account.
        deleted: Whether account is deleted.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    type: str
    on_budget: bool
    closed: bool
    balance: float
    cleared_balance: float
    uncleared_balance: float
    note: str | None = None
    transfer_payee_id: str | None = None
    deleted: bool


class Category(BaseModel):
    """A YNAB budget category.

    Attributes:
        id: Category UUID.
        category_group_id: Parent category group UUID.
        category_group_name: Parent category group name.
        name: Category display name.
        hidden: Whether category is hidden.
        budgeted: Budgeted amount in dollars.
        activity: Activity amount in dollars.
        balance: Balance in dollars.
        deleted: Whether category is deleted.
        note: Optional category note.
        goal_type: Goal type (TB, TBD, MF, NEED, DEBT).
        goal_target: Goal target amount in dollars.
        goal_target_month: Goal target month (YYYY-MM-DD).
        goal_percentage_complete: Goal completion percentage.
        goal_months_to_budget: Months remaining to reach goal.
        goal_under_funded: Amount under-funded in dollars.
        goal_overall_funded: Total funded toward goal in dollars.
        goal_overall_left: Amount remaining for goal in dollars.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    category_group_id: str
    category_group_name: str | None = None
    name: str
    hidden: bool
    budgeted: float
    activity: float
    balance: float
    deleted: bool
    note: str | None = None
    goal_type: str | None = None
    goal_target: float | None = None
    goal_target_month: str | None = None
    goal_percentage_complete: int | None = None
    goal_months_to_budget: int | None = None
    goal_under_funded: float | None = None
    goal_overall_funded: float | None = None
    goal_overall_left: float | None = None


class CategoryGroup(BaseModel):
    """A YNAB category group.

    Attributes:
        id: Category group UUID.
        name: Category group display name.
        hidden: Whether category group is hidden.
        deleted: Whether category group is deleted.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    hidden: bool
    deleted: bool


class CategoryGroupWithCategories(CategoryGroup):
    """A category group with its child categories.

    Attributes:
        categories: List of categories in this group.
    """

    categories: list[Category]


class SubTransaction(BaseModel):
    """A YNAB sub-transaction (split transaction component).

    Attributes:
        id: Sub-transaction UUID.
        transaction_id: Parent transaction UUID.
        amount: Amount in dollars (converted from milliunits).
        deleted: Whether sub-transaction is deleted.
        payee_id: Payee UUID.
        payee_name: Payee display name.
        category_id: Category UUID.
        category_name: Category display name.
        memo: Optional memo text.
        transfer_account_id: Account UUID if this is a transfer.
        transfer_transaction_id: Matching transfer transaction UUID.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    transaction_id: str
    amount: float
    deleted: bool
    payee_id: str | None = None
    payee_name: str | None = None
    category_id: str | None = None
    category_name: str | None = None
    memo: str | None = None
    transfer_account_id: str | None = None
    transfer_transaction_id: str | None = None


class TransactionDetail(BaseModel):
    """A detailed YNAB transaction.

    Attributes:
        id: Transaction UUID.
        date: Transaction date (YYYY-MM-DD).
        amount: Amount in dollars (converted from milliunits).
        account_id: Account UUID.
        account_name: Account display name.
        approved: Whether transaction is approved.
        cleared: Cleared status (cleared, uncleared, reconciled).
        deleted: Whether transaction is deleted.
        memo: Optional memo text.
        payee_id: Payee UUID.
        payee_name: Payee display name.
        category_id: Category UUID.
        category_name: Category display name.
        transfer_account_id: Account UUID if this is a transfer.
        transfer_transaction_id: Matching transfer transaction UUID.
        matched_transaction_id: Matched imported transaction UUID.
        import_id: Import identifier for deduplication.
        import_payee_name: Payee name from import source.
        import_payee_name_original: Original payee name from import source.
        flag_color: Transaction flag color.
        flag_name: Transaction flag name.
        debt_transaction_type: Debt transaction type (payment, etc.).
        subtransactions: List of sub-transactions (splits).
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    date: str
    amount: float
    account_id: str
    account_name: str
    approved: bool
    cleared: str
    deleted: bool
    memo: str | None = None
    payee_id: str | None = None
    payee_name: str | None = None
    category_id: str | None = None
    category_name: str | None = None
    transfer_account_id: str | None = None
    transfer_transaction_id: str | None = None
    matched_transaction_id: str | None = None
    import_id: str | None = None
    import_payee_name: str | None = None
    import_payee_name_original: str | None = None
    flag_color: str | None = None
    flag_name: str | None = None
    debt_transaction_type: str | None = None
    subtransactions: list[SubTransaction] = []


class ScheduledSubTransaction(BaseModel):
    """A YNAB scheduled sub-transaction (split component).

    Attributes:
        id: Sub-transaction UUID.
        scheduled_transaction_id: Parent scheduled transaction UUID.
        amount: Amount in dollars (converted from milliunits).
        deleted: Whether sub-transaction is deleted.
        payee_id: Payee UUID.
        payee_name: Payee display name.
        category_id: Category UUID.
        category_name: Category display name.
        memo: Optional memo text.
        transfer_account_id: Account UUID if this is a transfer.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    scheduled_transaction_id: str
    amount: float
    deleted: bool
    payee_id: str | None = None
    payee_name: str | None = None
    category_id: str | None = None
    category_name: str | None = None
    memo: str | None = None
    transfer_account_id: str | None = None


class ScheduledTransactionDetail(BaseModel):
    """A detailed YNAB scheduled transaction.

    Attributes:
        id: Scheduled transaction UUID.
        date_first: First occurrence date (YYYY-MM-DD).
        date_next: Next occurrence date (YYYY-MM-DD), None if completed.
        frequency: Recurrence frequency (never, daily, weekly, etc.).
        amount: Amount in dollars (converted from milliunits).
        account_id: Account UUID.
        account_name: Account display name.
        deleted: Whether scheduled transaction is deleted.
        payee_id: Payee UUID.
        payee_name: Payee display name.
        category_id: Category UUID.
        category_name: Category display name.
        memo: Optional memo text.
        flag_color: Flag color for the scheduled transaction.
        flag_name: Flag name for the scheduled transaction.
        transfer_account_id: Account UUID if this is a transfer.
        subtransactions: List of scheduled sub-transactions (splits).
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    date_first: str
    date_next: str | None = None
    frequency: str
    amount: float
    account_id: str
    account_name: str
    deleted: bool
    payee_id: str | None = None
    payee_name: str | None = None
    category_id: str | None = None
    category_name: str | None = None
    memo: str | None = None
    flag_color: str | None = None
    flag_name: str | None = None
    transfer_account_id: str | None = None
    subtransactions: list[ScheduledSubTransaction] = []


class Payee(BaseModel):
    """A YNAB payee.

    Attributes:
        id: Payee UUID.
        name: Payee display name.
        transfer_account_id: Account UUID if this is a transfer payee.
        deleted: Whether payee is deleted.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    transfer_account_id: str | None = None
    deleted: bool


class PayeeLocation(BaseModel):
    """A YNAB payee location (GPS data from mobile apps).

    Attributes:
        id: Payee location UUID.
        payee_id: Parent payee UUID.
        latitude: GPS latitude, or None if not set.
        longitude: GPS longitude, or None if not set.
        deleted: Whether payee location is deleted.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
    payee_id: str
    latitude: float | None = None
    longitude: float | None = None
    deleted: bool


class MonthSummary(BaseModel):
    """A YNAB budget month summary.

    Attributes:
        month: Month date string (YYYY-MM-DD).
        income: Total income in dollars.
        budgeted: Total budgeted in dollars.
        activity: Total activity in dollars.
        to_be_budgeted: Amount available to budget in dollars.
        age_of_money: Age of money in days, or None.
        deleted: Whether month is deleted.
    """

    model_config = ConfigDict(extra="ignore")

    month: str
    income: float
    budgeted: float
    activity: float
    to_be_budgeted: float
    age_of_money: int | None = None
    deleted: bool


class MonthDetail(BaseModel):
    """A YNAB budget month with category breakdown.

    Attributes:
        month: Month date string (YYYY-MM-DD).
        income: Total income in dollars.
        budgeted: Total budgeted in dollars.
        activity: Total activity in dollars.
        to_be_budgeted: Amount available to budget in dollars.
        age_of_money: Age of money in days, or None.
        categories: List of categories for this month.
    """

    model_config = ConfigDict(extra="ignore")

    month: str
    income: float
    budgeted: float
    activity: float
    to_be_budgeted: float
    age_of_money: int | None = None
    categories: list[Category] = []


class MoneyMovement(BaseModel):
    """A YNAB money movement entry (per-category).

    Attributes:
        category_name: Category display name.
        category_group_name: Category group name, or None.
        allocation: Allocation amount in dollars.
        spent: Spent amount in dollars.
        income: Income amount in dollars.
    """

    model_config = ConfigDict(extra="ignore")

    category_name: str
    category_group_name: str | None = None
    allocation: float
    spent: float
    income: float


class MoneyMovementGroup(BaseModel):
    """A YNAB money movement group entry (per-category-group).

    Attributes:
        category_group_name: Category group display name.
        allocation: Allocation amount in dollars.
        spent: Spent amount in dollars.
        income: Income amount in dollars.
    """

    model_config = ConfigDict(extra="ignore")

    category_group_name: str
    allocation: float
    spent: float
    income: float


class UserResponse(BaseModel):
    """Response for the GET /user endpoint.

    Attributes:
        id: User UUID.
    """

    model_config = ConfigDict(extra="ignore")

    id: str
