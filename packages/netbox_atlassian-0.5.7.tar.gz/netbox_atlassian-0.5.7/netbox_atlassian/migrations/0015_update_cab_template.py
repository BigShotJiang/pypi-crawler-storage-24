"""Update CAB Change Request template with presentation-aligned sections and engineer checklist."""

from django.db import migrations

NEW_CAB_CONTENT = """\
{toc}

|| Field || Value || Field || Value ||
| Change Request # | {{ change_request|default:"(CHG-XXXXXX)" }} | Submitted By | {{ submitted_by|default:"(Name)" }} |
| Change Type | {{ change_type|default:"(Normal/Standard/Emergency)" }} | Priority | {{ priority|default:"(Low/Medium/High)" }} |
| Requested Window | {{ change_window|default:"(DDMONYYYY HHMM)" }} | Duration | {{ expected_duration|default:"(X minutes)" }} |
| Impact | {{ impact_level|default:"(Low/Medium/High)" }} | Risk | {{ risk_level|default:"(Low/Medium/High)" }} |

----

h2. Engineer Checklist

* [ ] Ticket / Change Request created
* [ ] Project Goals & Drivers documented
* [ ] Overview / technical context completed
* [ ] Project Phases defined
* [ ] User Impact assessed
* [ ] Test Plans documented
* [ ] Backout Plans documented
* [ ] Proposed Work Date(s) confirmed
* [ ] Communications plan completed
* [ ] Project Team identified
* [ ] Affected systems listed
* [ ] Risk assessment completed
* [ ] CAB presentation created from sections below
* [ ] CAB presentation reviewed and submitted
* [ ] CAB decision recorded

----

h2. 1. Project Goals & Drivers

{{ goals|default:"(Describe the business goals driving this change and why it is needed now.)" }}

----

h2. 2. Overview

{{ overview|default:"(Provide technical context — current state, target state, and supporting data.)" }}

----

h2. 3. Affected Systems

|| Device || Site || Role || Model || Primary IP ||
{% for device in devices %}| {{ device.name }} | {{ device.site.name }} | {{ device.role.name }} | {% if device.device_type %}{{ device.device_type.manufacturer.name }} {{ device.device_type.model }}{% endif %} | {{ device.primary_ip4|default:"N/A" }} |
{% endfor %}

----

h2. 4. Project Phases

|| Phase || Description || Owner || Target Date ||
| Phase 1 | (Description) | (Owner) | (Date) |
| Phase 2 | (Description) | (Owner) | (Date) |
| Phase 3 | (Description) | (Owner) | (Date) |

----

h2. 5. User Impact

{{ user_impact|default:"(Describe how end users will be affected during and after the change. Include expected downtime, degraded services, and workarounds.)" }}

----

h2. 6. Test Plans

* [ ] (Test 1 — description and expected result)
* [ ] (Test 2 — description and expected result)
* [ ] (Test 3 — description and expected result)

----

h2. 7. Backout Plans

* [ ] Backout Step 1 — (Description)
* [ ] Backout Step 2 — (Description)
* [ ] Estimated backout time: {{ rollback_time|default:"(X minutes)" }}

----

h2. 8. Proposed Work Date(s)

|| Phase || Proposed Date || Window || Duration ||
| (Phase 1) | (Date) | (Start – End) | (X hours) |
| (Phase 2) | (Date) | (Start – End) | (X hours) |

----

h2. 9. Communications

|| When || Who || Method || Message ||
| Before change | (Stakeholders) | (Email / Teams / Phone) | (Change notification) |
| During change | (Operations) | (Bridge / Chat) | (Status updates) |
| After change | (Stakeholders) | (Email / Teams) | (Completion notice) |

----

h2. 10. Risk Assessment

|| Risk || Likelihood || Impact || Mitigation ||
| Service disruption | (Low/Med/High) | (Low/Med/High) | (Mitigation) |
| Rollback required | (Low/Med/High) | (Low/Med/High) | (Mitigation) |

----

h2. 11. Project Team

|| Role || Name || Contact ||
{% for c in unique_contacts %}| {{ c.role.name|default:"(Role)" }} | {{ c.contact.name }} | {{ c.contact.phone|default:"N/A" }} |
{% endfor %}

----

h2. 12. CAB Decision

|| Decision || Date || Approved By || Notes ||
| (Approved / Rejected / Deferred) | (Date) | (Name) | (Notes) |

----

h2. 13. Closeout

h3. Lessons Learned

* (Item 1)
* (Item 2)
* (Item 3)

h3. Disaster Recovery Plan Review

* [ ] Existing DR Plan Reviewed
* [ ] Existing DR Plan — No Changes Needed
* [ ] Existing DR Plan — Changes Confirmed
* DR Plan Link: (INSERT LINK HERE)
* Summary of changes: (INSERT SUMMARY HERE)

h3. System Diagram Review

* [ ] System Diagram(s) Reviewed
* [ ] Diagrams — No Changes Needed
* [ ] Diagrams — Changes Confirmed and Updated

h3. Additional Follow-Up Work

* (Follow-up item 1)
* (Follow-up item 2)

----

_Generated: {{ date }} by {{ generated_by }}_
"""


def update_cab_template(apps, schema_editor):
    DocumentTemplate = apps.get_model("netbox_atlassian", "DocumentTemplate")
    try:
        t = DocumentTemplate.objects.get(name="Standard CAB Request")
        t.content = NEW_CAB_CONTENT
        t.save()
    except DocumentTemplate.DoesNotExist:
        pass


class Migration(migrations.Migration):

    dependencies = [
        ("netbox_atlassian", "0014_add_toc_and_closeout"),
    ]

    operations = [
        migrations.RunPython(update_cab_template, reverse_code=migrations.RunPython.noop),
    ]
