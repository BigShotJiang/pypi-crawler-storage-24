# EIP

Edge Image Process.

## Install From Git
![pip-install-eip-gif](./assets/pip-install.gif)

Install directly from the official GitHub repository:

```bash
pip install eip-cli
```

Upgrade to the latest `main`:

```bash
pip install --upgrade --force-reinstall eip-cli
```

## Verify The Install

After installation, verify that the CLI and TUI both start:

```bash
eip --help
eip --tui
```

Run the current smoke-path workflow with a pre-segmented case:

```bash
eip run --input /path/to/case.image.nrrd --seg-input /path/to/case.seg.nrrd --backend none --output /path/to/out
```

## Deep Learning Runtime

`torch` and `nnUNetv2` are not installed by default.
Detect, install, and verify them from `Settings -> CLI Environment` in the TUI.

## Developer Setup

Use the WSL `Eip` conda environment for development and verification.

```bash
source ~/miniconda3/etc/profile.d/conda.sh
conda activate Eip
python -m pip install -e ".[dev]"
```

## TUI Notes

The current TUI supports:

- four top-level pages: execution, profiles, settings, and logs
- execution command detail forms from the execution hub
- recursive path completion with a visible candidate list
- keyboard path selection via `Up`, `Down`, `Tab`, `Right`, and `Esc`
- optional `Browse` button fallback that keeps TUI path entry working when GUI dialogs are disabled or unavailable
- profile-name persistence and TUI settings persistence under the local storage root
- log level filtering plus refresh interval state on the logs page
- left/right page switching and a scrollable page body container

## Current Scope

The current implementation includes:

- Git-based package installation
- CLI entrypoint and `doctor`
- config bootstrap and storage migration helpers
- logging setup and structured TUI runtime events
- NRRD read/write
- slicing
- morphology refinement and hotspot map
- centroid and polar export helpers
- built-in U-Net asset resolution
- nnU-Net command adapter
- Textual TUI shell with execution, profiles, settings, logs, recursive path input, and keyboard navigation
