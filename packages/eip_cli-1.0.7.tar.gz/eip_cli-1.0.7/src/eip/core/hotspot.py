from __future__ import annotations

import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont


_BACKGROUND = (12, 12, 12)
_LEGEND_BACKGROUND = (24, 24, 24)
_LEGEND_BORDER = (72, 72, 72)
_LABEL_FILL = (245, 245, 245)
_LABEL_STROKE = (0, 0, 0)
_ZERO_BAR = (56, 56, 56)
_HOTSPOT_RENDER_RADIUS = 2
_LABEL_AVOIDANCE_RADIUS = 10


def build_hit_map(centers: list[tuple[int, int]], shape: tuple[int, int]) -> np.ndarray:
    hit_map = np.zeros(shape, dtype=np.int32)
    for row, col in centers:
        hit_map[row, col] += 1
    return hit_map


def select_hotspot_labels(hit_map: np.ndarray, min_distance: int = 8) -> list[tuple[int, int, int]]:
    candidates = np.argwhere(hit_map > 0)
    ranked = sorted(
        ((int(row), int(col), int(hit_map[row, col])) for row, col in candidates),
        key=lambda item: (-item[2], item[0], item[1]),
    )
    accepted: list[tuple[int, int, int]] = []
    for row, col, value in ranked:
        if any(abs(row - existing_row) <= min_distance and abs(col - existing_col) <= min_distance for existing_row, existing_col, _ in accepted):
            continue
        accepted.append((row, col, value))
    return accepted


def _interpolate_channel(start: int, end: int, ratio: float) -> int:
    return int(round(start + (end - start) * ratio))


def _heat_color(value: int, max_value: int) -> tuple[int, int, int]:
    if max_value <= 0 or value <= 0:
        return _BACKGROUND
    ratio = value / max_value
    if ratio <= 0.5:
        local_ratio = ratio / 0.5
        start = (90, 24, 24)
        end = (216, 38, 38)
    else:
        local_ratio = (ratio - 0.5) / 0.5
        start = (216, 38, 38)
        end = (255, 96, 82)
    return (
        _interpolate_channel(start[0], end[0], local_ratio),
        _interpolate_channel(start[1], end[1], local_ratio),
        _interpolate_channel(start[2], end[2], local_ratio),
    )


def _marker_radius(value: int, max_value: int) -> int:
    return _HOTSPOT_RENDER_RADIUS


def _label_min_value(max_value: int) -> int:
    if max_value <= 1:
        return max_value + 1
    return max(2, int(math.ceil(max_value * 0.6)))


def _draw_legend(
    draw: ImageDraw.ImageDraw,
    main_width: int,
    legend_width: int,
    height: int,
    max_value: int,
    font: ImageFont.ImageFont | ImageFont.FreeTypeFont,
) -> None:
    left = main_width
    right = main_width + legend_width - 1
    draw.rectangle((left, 0, right, height - 1), fill=_LEGEND_BACKGROUND)
    draw.rectangle((left, 0, right, height - 1), outline=_LEGEND_BORDER)

    padding = 6 if height >= 48 else 2
    title = "Heat Value" if legend_width >= 72 else "Heat"
    draw.text(
        (left + padding, padding),
        title,
        fill=_LABEL_FILL,
        font=font,
        stroke_width=1,
        stroke_fill=_LABEL_STROKE,
    )

    title_box = draw.textbbox((left + padding, padding), title, font=font, stroke_width=1)
    bar_top = max(padding, title_box[3] + padding)
    bar_bottom = max(bar_top + 4, height - padding - 1)
    bar_right = right - padding
    bar_left = max(left + padding, bar_right - max(8, legend_width // 4))

    for y in range(bar_top, bar_bottom + 1):
        if max_value <= 0:
            color = _ZERO_BAR
        else:
            ratio = 1.0 - ((y - bar_top) / max(1, bar_bottom - bar_top))
            color = _heat_color(max(1, int(round(ratio * max_value))), max_value)
        draw.line((bar_left, y, bar_right, y), fill=color)
    draw.rectangle((bar_left, bar_top, bar_right, bar_bottom), outline=_LEGEND_BORDER)

    max_text = str(max_value)
    min_text = "0"
    max_box = draw.textbbox((0, 0), max_text, font=font, stroke_width=1)
    min_box = draw.textbbox((0, 0), min_text, font=font, stroke_width=1)
    text_left = left + padding
    max_y = min(height - (max_box[3] - max_box[1]), bar_top)
    min_y = max(0, min(height - (min_box[3] - min_box[1]), bar_bottom - (min_box[3] - min_box[1])))
    draw.text((text_left, max_y), max_text, fill=_LABEL_FILL, font=font, stroke_width=1, stroke_fill=_LABEL_STROKE)
    draw.text((text_left, min_y), min_text, fill=_LABEL_FILL, font=font, stroke_width=1, stroke_fill=_LABEL_STROKE)


def render_hotspot_preview(hit_map: np.ndarray) -> np.ndarray:
    height, width = hit_map.shape
    legend_width = max(64, min(88, max(16, width // 3)))
    image = Image.new("RGB", (width + legend_width, height), _BACKGROUND)
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    max_value = int(hit_map.max()) if hit_map.size else 0

    points = np.argwhere(hit_map > 0)
    ranked_points = sorted(
        ((int(row), int(col), int(hit_map[row, col])) for row, col in points),
        key=lambda item: (item[2], item[0], item[1]),
    )
    for row, col, value in ranked_points:
        radius = _marker_radius(value, max_value)
        color = _heat_color(value, max_value)
        draw.ellipse((col - radius, row - radius, col + radius, row + radius), fill=color)

    min_label_value = _label_min_value(max_value)
    for row, col, value in select_hotspot_labels(hit_map, min_distance=_LABEL_AVOIDANCE_RADIUS):
        if value < min_label_value:
            continue
        text = str(value)
        text_box = draw.textbbox((0, 0), text, font=font, stroke_width=1)
        text_width = text_box[2] - text_box[0]
        text_height = text_box[3] - text_box[1]
        radius = _marker_radius(value, max_value)
        text_x = col + radius + 2
        if text_x + text_width >= width:
            text_x = max(0, col - radius - text_width - 2)
        text_y = max(0, min(height - text_height, row - (text_height // 2)))
        draw.text((text_x, text_y), text, fill=_LABEL_FILL, font=font, stroke_width=1, stroke_fill=_LABEL_STROKE)

    _draw_legend(draw, width, legend_width, height, max_value, font)
    return np.asarray(image, dtype=np.uint8)
