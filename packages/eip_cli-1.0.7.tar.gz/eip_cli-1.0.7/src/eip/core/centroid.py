from __future__ import annotations

import numpy as np


def compute_mask_centroid(mask: np.ndarray) -> tuple[int, int]:
    rows, cols = np.nonzero(mask)
    if rows.size == 0:
        raise ValueError("mask is empty")
    return int(np.rint(rows.mean())), int(np.rint(cols.mean()))
