from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class CasePaths:
    root: Path
    case_id: str

    @property
    def case_dir(self) -> Path:
        return self.root / self.case_id

    @property
    def segmentation_dir(self) -> Path:
        return self.case_dir / "segmentation"
