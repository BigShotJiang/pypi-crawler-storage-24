from __future__ import annotations

import numpy as np
from scipy import ndimage as ndi
from skimage.measure import label, regionprops


def refine_slice_mask(mask: np.ndarray, min_area: int) -> np.ndarray:
    filled = ndi.binary_fill_holes(mask > 0)
    labeled = label(filled)
    refined = np.zeros_like(mask, dtype=np.uint8)
    for region in regionprops(labeled):
        if region.area >= min_area:
            refined[labeled == region.label] = 1
    return refined
