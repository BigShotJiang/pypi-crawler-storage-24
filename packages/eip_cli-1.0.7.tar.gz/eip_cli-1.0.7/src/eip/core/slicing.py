from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image


def slice_volume_to_pngs(volume: np.ndarray, output_dir: Path, stem: str) -> list[Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    outputs: list[Path] = []
    for index in range(volume.shape[2]):
        path = output_dir / f"{stem}_{index + 1:03d}.png"
        Image.fromarray(volume[:, :, index]).save(path)
        outputs.append(path)
    return outputs
