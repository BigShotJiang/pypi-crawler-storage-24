from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image

from eip.core.centroid import compute_mask_centroid
from eip.core.hotspot import build_hit_map, render_hotspot_preview
from eip.core.morphology import refine_slice_mask
from eip.core.nrrd_io import read_nrrd, write_nrrd
from eip.core.polar import pad_polar_width, render_polar_patch, to_preview_8bit
from eip.core.slicing import slice_volume_to_pngs
from eip.segmentation.nnunet_backend import NnUnetBackend
from eip.segmentation.unet_backend import BuiltinUnetBackend


SUPPORTED_BACKENDS = {"builtin-unet", "nnunetv2", "none"}
SUPPORTED_SEG_MODES = {"builtin-unet", "custom-unet", "nnunetv2", "existing-seg"}
SUPPORTED_NNUNET_SOURCES = {"registry", "model-dir"}
DEFAULT_RING_WIDTH = 8
DEFAULT_POLAR_WIDTH = 360
DEFAULT_REFINEMENT_MIN_AREA = 32


@dataclass(frozen=True)
class SegmentationOptions:
    seg_mode: str
    model_path: Path | None = None
    seg_input: Path | None = None
    nnunet_source: str | None = None
    nnunet_dataset: str | None = None
    nnunet_config: str | None = None
    nnunet_model_dir: Path | None = None
    nnunet_folds: str | None = None
    nnunet_checkpoint: str | None = None


@dataclass(frozen=True)
class CaseArtifacts:
    case_id: str
    case_dir: Path
    input_path: Path
    segmentation_path: Path | None = None
    refined_path: Path | None = None
    centroid_path: Path | None = None
    hotspot_path: Path | None = None
    polar_matrix_path: Path | None = None
    polar_preview_path: Path | None = None


@dataclass(frozen=True)
class PolarSliceSelection:
    axis: int
    axis_index: int
    image_slice: np.ndarray
    mask_slice: np.ndarray
    area: int


def normalize_segmentation_mode(seg_mode: str | None, backend: str | None) -> str:
    if seg_mode:
        if seg_mode not in SUPPORTED_SEG_MODES:
            raise ValueError(f"unsupported seg-mode: {seg_mode}")
        return seg_mode
    if backend is None:
        return "builtin-unet"
    if backend not in SUPPORTED_BACKENDS:
        raise ValueError(f"unsupported backend: {backend}")
    if backend == "none":
        return "existing-seg"
    return backend


def resolve_segmentation_options(
    *,
    seg_mode: str | None = None,
    backend: str | None = None,
    model_path: Path | None = None,
    seg_input: Path | None = None,
    nnunet_source: str | None = None,
    nnunet_dataset: str | None = None,
    nnunet_config: str | None = None,
    nnunet_model_dir: Path | None = None,
    nnunet_folds: str | None = None,
    nnunet_checkpoint: str | None = None,
) -> SegmentationOptions:
    normalized_mode = normalize_segmentation_mode(seg_mode, backend)
    if normalized_mode == "builtin-unet":
        if any((model_path, seg_input, nnunet_source, nnunet_dataset, nnunet_config, nnunet_model_dir)):
            raise ValueError("builtin-unet does not accept model or segmentation override options")
    elif normalized_mode == "custom-unet":
        if model_path is None:
            raise ValueError("model-path is required when seg-mode is custom-unet")
        if any((seg_input, nnunet_source, nnunet_dataset, nnunet_config, nnunet_model_dir)):
            raise ValueError("custom-unet only accepts model-path as its segmentation-specific option")
    elif normalized_mode == "existing-seg":
        if seg_input is None:
            raise ValueError("seg-input is required when seg-mode is existing-seg")
        if any((model_path, nnunet_source, nnunet_dataset, nnunet_config, nnunet_model_dir)):
            raise ValueError("existing-seg only accepts seg-input as its segmentation-specific option")
    elif normalized_mode == "nnunetv2":
        if nnunet_source not in SUPPORTED_NNUNET_SOURCES:
            raise ValueError("nnunet-source is required when seg-mode is nnunetv2")
        if model_path is not None or seg_input is not None:
            raise ValueError("nnunetv2 does not accept model-path or seg-input")
        if nnunet_source == "registry":
            if not nnunet_dataset or not nnunet_config:
                raise ValueError("nnunet-dataset and nnunet-config are required for nnunetv2 registry mode")
            if nnunet_model_dir is not None:
                raise ValueError("nnunet-model-dir is only valid for nnunetv2 model-dir mode")
        else:
            if nnunet_model_dir is None:
                raise ValueError("nnunet-model-dir is required for nnunetv2 model-dir mode")
            if nnunet_dataset or nnunet_config:
                raise ValueError("nnunet-dataset and nnunet-config are only valid for nnunetv2 registry mode")

    return SegmentationOptions(
        seg_mode=normalized_mode,
        model_path=model_path,
        seg_input=seg_input,
        nnunet_source=nnunet_source,
        nnunet_dataset=nnunet_dataset,
        nnunet_config=nnunet_config,
        nnunet_model_dir=nnunet_model_dir,
        nnunet_folds=nnunet_folds,
        nnunet_checkpoint=nnunet_checkpoint,
    )


def ensure_one_input(input_path: Path | None, input_dir: Path | None) -> tuple[str, Path]:
    if input_path is not None:
        return "file", input_path
    if input_dir is not None:
        return "dir", input_dir
    raise ValueError("input path or input directory is required")


def _format_input_label(kind: str, source: Path) -> str:
    return f"Input {'file' if kind == 'file' else 'directory'}: {source}"


def _format_run_success(
    kind: str,
    source: Path,
    destination: Path,
    segmentation: SegmentationOptions,
    artifacts: list[CaseArtifacts],
    ring_width: int,
) -> str:
    lines = [
        "Run completed successfully.",
        _format_input_label(kind, source),
        f"Segmentation mode: {segmentation.seg_mode}",
        f"Ring width: {ring_width}",
        f"Output directory: {destination}",
        f"Processed cases: {len(artifacts)}",
    ]
    if segmentation.seg_input is not None:
        lines.append(f"Segmentation input: {segmentation.seg_input}")
    if segmentation.model_path is not None:
        lines.append(f"Model path: {segmentation.model_path}")
    if segmentation.nnunet_source is not None:
        lines.append(f"nnU-Net source: {segmentation.nnunet_source}")
    first = artifacts[0] if artifacts else None
    if first is not None and first.polar_preview_path is not None:
        lines.append(f"Polar preview: {first.polar_preview_path}")
    return "\n".join(lines)


def _format_step_success(
    step: str,
    kind: str,
    source: Path,
    destination: Path,
    produced_label: str,
    produced_paths: list[Path],
) -> str:
    lines = [
        f"{step.capitalize()} completed successfully.",
        _format_input_label(kind, source),
        f"Output directory: {destination}",
        f"Generated {produced_label}: {len(produced_paths)}",
    ]
    if produced_paths:
        lines.append(f"First output: {produced_paths[0]}")
    return "\n".join(lines)


def _require_inputs(kind: str, source: Path, inputs: list[Path], *, label: str) -> list[Path]:
    if kind == "dir" and not inputs:
        raise ValueError(f"no input {label} were found under input directory: {source}")
    return inputs


def run_pipeline(
    input_path: Path | None,
    input_dir: Path | None,
    output: Path | None,
    seg_input: Path | None = None,
    backend: str | None = None,
    seg_mode: str | None = None,
    model_path: Path | None = None,
    nnunet_source: str | None = None,
    nnunet_dataset: str | None = None,
    nnunet_config: str | None = None,
    nnunet_model_dir: Path | None = None,
    nnunet_folds: str | None = None,
    nnunet_checkpoint: str | None = None,
    ring_width: int = DEFAULT_RING_WIDTH,
    polar_width: int = DEFAULT_POLAR_WIDTH,
    axis: str | int | None = None,
    export_all: bool = False,
    export_count: int | None = None,
    export_png: bool = False,
) -> str:
    kind, source = ensure_one_input(input_path, input_dir)
    segmentation = resolve_segmentation_options(
        seg_mode=seg_mode,
        backend=backend,
        model_path=model_path,
        seg_input=seg_input,
        nnunet_source=nnunet_source,
        nnunet_dataset=nnunet_dataset,
        nnunet_config=nnunet_config,
        nnunet_model_dir=nnunet_model_dir,
        nnunet_folds=nnunet_folds,
        nnunet_checkpoint=nnunet_checkpoint,
    )
    destination = (output or Path("output")).expanduser()
    destination.mkdir(parents=True, exist_ok=True)
    artifacts: list[CaseArtifacts] = []
    image_inputs = _require_inputs(kind, source, _collect_image_inputs(kind, source), label="image volumes")
    for image_path in image_inputs:
        case_artifacts = _run_case(
            image_path,
            destination,
            segmentation,
            ring_width=ring_width,
            polar_width=polar_width,
            axis=axis,
            export_all=export_all,
            export_count=export_count,
            export_png=export_png,
        )
        artifacts.append(case_artifacts)
    return _format_run_success(kind, source, destination, segmentation, artifacts, ring_width)


def run_step(
    step: str,
    input_path: Path | None,
    input_dir: Path | None,
    output: Path | None,
    *,
    data_path: Path | None = None,
    seg_input: Path | None = None,
    backend: str | None = None,
    seg_mode: str | None = None,
    model_path: Path | None = None,
    nnunet_source: str | None = None,
    nnunet_dataset: str | None = None,
    nnunet_config: str | None = None,
    nnunet_model_dir: Path | None = None,
    nnunet_folds: str | None = None,
    nnunet_checkpoint: str | None = None,
    ring_width: int = DEFAULT_RING_WIDTH,
    polar_width: int = DEFAULT_POLAR_WIDTH,
    axis: str | int | None = None,
    export_all: bool = False,
    export_count: int | None = None,
    export_png: bool = False,
) -> str:
    kind, source = ensure_one_input(input_path, input_dir)
    destination = (output or Path("output")).expanduser()
    destination.mkdir(parents=True, exist_ok=True)
    produced_paths: list[Path] = []

    if step == "segment":
        segmentation = resolve_segmentation_options(
            seg_mode=seg_mode,
            backend=backend,
            model_path=model_path,
            seg_input=seg_input,
            nnunet_source=nnunet_source,
            nnunet_dataset=nnunet_dataset,
            nnunet_config=nnunet_config,
            nnunet_model_dir=nnunet_model_dir,
            nnunet_folds=nnunet_folds,
            nnunet_checkpoint=nnunet_checkpoint,
        )
        image_inputs = _require_inputs(kind, source, _collect_image_inputs(kind, source), label="image volumes")
        for image_path in image_inputs:
            case_dir = _case_dir(destination, _case_id_from_path(image_path))
            _copy_input_artifact(image_path, case_dir / "input" / image_path.name)
            produced_paths.append(_segment_case(image_path, case_dir, segmentation))
        return _format_step_success(step, kind, source, destination, "segmentations", produced_paths)

    if step == "slice":
        volume_inputs = _require_inputs(kind, source, _collect_volume_inputs(kind, source), label="volumes")
        for volume_path in volume_inputs:
            case_id = _case_id_from_path(volume_path)
            case_dir = _case_dir(destination, case_id)
            preview_volume = _preview_volume(read_nrrd(volume_path))
            target_dir = case_dir / "slices" / "image"
            produced_paths.extend(slice_volume_to_pngs(preview_volume, target_dir, case_id))
        return _format_step_success(step, kind, source, destination, "slice images", produced_paths)

    if step == "refine":
        volume_inputs = _require_inputs(kind, source, _collect_volume_inputs(kind, source), label="volumes")
        for mask_path in volume_inputs:
            case_id = _case_id_from_path(mask_path)
            case_dir = _case_dir(destination, case_id)
            refined_path = _refine_mask(mask_path, case_dir)
            produced_paths.append(refined_path)
        return _format_step_success(step, kind, source, destination, "refined masks", produced_paths)

    if step == "centroid":
        volume_inputs = _require_inputs(kind, source, _collect_volume_inputs(kind, source), label="volumes")
        for mask_path in volume_inputs:
            case_id = _case_id_from_path(mask_path)
            case_dir = _case_dir(destination, case_id)
            centroid_path, hotspot_path = _write_centroid_outputs(mask_path, case_dir)
            produced_paths.extend([centroid_path, hotspot_path])
        return _format_step_success(step, kind, source, destination, "centroid artifacts", produced_paths)

    if step == "polar":
        volume_inputs = _require_inputs(kind, source, _collect_volume_inputs(kind, source), label="volumes")
        for source_path in volume_inputs:
            case_id = _case_id_from_path(source_path)
            case_dir = _case_dir(destination, case_id)
            _, preview_path = _write_polar_outputs(
                source_path,
                case_dir,
                data_path=data_path,
                ring_width=ring_width,
                polar_width=polar_width,
                axis=axis,
                export_all=export_all,
                export_count=export_count,
                export_png=export_png,
            )
            produced_paths.append(preview_path)
        return _format_step_success(step, kind, source, destination, "polar previews", produced_paths)

    raise ValueError(f"unsupported step: {step}")


def _run_case(
    image_path: Path,
    output_root: Path,
    segmentation: SegmentationOptions,
    *,
    ring_width: int,
    polar_width: int,
    axis: str | int | None,
    export_all: bool,
    export_count: int | None,
    export_png: bool,
) -> CaseArtifacts:
    case_id = _case_id_from_path(image_path)
    case_dir = _case_dir(output_root, case_id)
    _copy_input_artifact(image_path, case_dir / "input" / image_path.name)
    segmentation_path = _segment_case(image_path, case_dir, segmentation)

    image_volume = _preview_volume(read_nrrd(image_path))
    mask_volume = _mask_preview_volume(read_nrrd(segmentation_path))
    slice_volume_to_pngs(image_volume, case_dir / "slices" / "image", case_id)
    slice_volume_to_pngs(mask_volume, case_dir / "slices" / "mask", case_id)

    refined_path = _refine_mask(segmentation_path, case_dir)
    centroid_path, hotspot_path = _write_centroid_outputs(refined_path, case_dir)
    polar_matrix_path, polar_preview_path = _write_polar_outputs(
        image_path,
        case_dir,
        mask_path=refined_path,
        ring_width=ring_width,
        polar_width=polar_width,
        axis=axis,
        export_all=export_all,
        export_count=export_count,
        export_png=export_png,
    )

    return CaseArtifacts(
        case_id=case_id,
        case_dir=case_dir,
        input_path=image_path,
        segmentation_path=segmentation_path,
        refined_path=refined_path,
        centroid_path=centroid_path,
        hotspot_path=hotspot_path,
        polar_matrix_path=polar_matrix_path,
        polar_preview_path=polar_preview_path,
    )


def _collect_image_inputs(kind: str, source: Path) -> list[Path]:
    if kind == "file":
        return [source]
    return [path for path in _iter_nrrd_files(source) if _is_image_volume(path)]


def _collect_volume_inputs(kind: str, source: Path) -> list[Path]:
    if kind == "file":
        return [source]
    return list(_iter_nrrd_files(source))


def _iter_nrrd_files(source_dir: Path) -> list[Path]:
    return sorted(
        path
        for path in source_dir.rglob("*")
        if path.is_file()
        and path.suffix.lower() in {".nrrd", ".nhdr"}
        and ":Zone.Identifier" not in path.name
    )


def _is_image_volume(path: Path) -> bool:
    name = path.name
    return not any(token in name for token in (".label.", ".seg.", ".refined.", ".mask."))


def _case_dir(output_root: Path, case_id: str) -> Path:
    case_dir = output_root / "cases" / case_id
    case_dir.mkdir(parents=True, exist_ok=True)
    return case_dir


def _copy_input_artifact(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def _segment_case(image_path: Path, case_dir: Path, segmentation: SegmentationOptions) -> Path:
    output_path = case_dir / "segmentation" / f"{_case_id_from_path(image_path)}.seg.nrrd"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if segmentation.seg_mode == "existing-seg":
        if segmentation.seg_input is None:
            raise ValueError("seg-input is required when seg-mode is existing-seg")
        _copy_input_artifact(segmentation.seg_input, output_path)
        return output_path

    if segmentation.seg_mode in {"builtin-unet", "custom-unet"}:
        volume = read_nrrd(image_path)
        backend = BuiltinUnetBackend()
        weights = None if segmentation.model_path is None else str(segmentation.model_path)
        return backend.predict_volume(volume, output_path, weights=weights)

    if segmentation.seg_mode == "nnunetv2":
        return _segment_with_nnunet(image_path, output_path, segmentation)

    raise ValueError(f"unsupported segmentation mode: {segmentation.seg_mode}")


def _segment_with_nnunet(image_path: Path, output_path: Path, segmentation: SegmentationOptions) -> Path:
    with tempfile.TemporaryDirectory(prefix="eip-nnunet-input-") as temp_input, tempfile.TemporaryDirectory(
        prefix="eip-nnunet-output-"
    ) as temp_output:
        temp_input_path = Path(temp_input) / _nnunet_input_filename(image_path)
        shutil.copy2(image_path, temp_input_path)
        command = _nnunet_command(segmentation, temp_input=Path(temp_input), temp_output=Path(temp_output))
        completed = subprocess.run(command, capture_output=True, text=True, check=False)
        if completed.returncode != 0:
            stderr = completed.stderr.strip() or completed.stdout.strip() or "unknown nnU-Net error"
            raise ValueError(f"nnunetv2 execution failed: {stderr}")
        produced = sorted(Path(temp_output).glob("*.nrrd"))
        if not produced:
            raise ValueError("nnunetv2 execution finished without producing a segmentation NRRD")
        _copy_input_artifact(produced[0], output_path)
        return output_path


def _nnunet_command(segmentation: SegmentationOptions, *, temp_input: Path, temp_output: Path) -> list[str]:
    if segmentation.nnunet_source == "registry":
        backend = NnUnetBackend()
        executable = shutil.which(backend.executable)
        if executable is None:
            raise ValueError("nnUNetv2_predict is not installed or not on PATH")
        return backend.build_command(
            input_path=temp_input,
            output_dir=temp_output,
            dataset_id=segmentation.nnunet_dataset or "",
            configuration=segmentation.nnunet_config or "",
        )

    executable = shutil.which("nnUNetv2_predict_from_modelfolder")
    if executable is None:
        raise ValueError("nnUNetv2_predict_from_modelfolder is not installed or not on PATH")
    command = [
        executable,
        "-i",
        str(temp_input),
        "-o",
        str(temp_output),
        "-m",
        str(segmentation.nnunet_model_dir),
    ]
    if segmentation.nnunet_folds:
        command.extend(["-f", *[fold.strip() for fold in segmentation.nnunet_folds.split(",") if fold.strip()]])
    if segmentation.nnunet_checkpoint:
        command.extend(["-chk", segmentation.nnunet_checkpoint])
    return command


def _refine_mask(mask_path: Path, case_dir: Path, *, min_area: int = DEFAULT_REFINEMENT_MIN_AREA) -> Path:
    mask = read_nrrd(mask_path)
    refined = np.zeros_like(mask, dtype=np.uint8)
    for index in range(mask.shape[2]):
        refined[:, :, index] = refine_slice_mask(mask[:, :, index], min_area=min_area)
    refined_path = case_dir / "refine" / f"{_case_id_from_path(mask_path)}.refined.seg.nrrd"
    refined_path.parent.mkdir(parents=True, exist_ok=True)
    write_nrrd(refined_path, refined)
    return refined_path


def _write_centroid_outputs(mask_path: Path, case_dir: Path) -> tuple[Path, Path]:
    mask = read_nrrd(mask_path)
    centers: list[dict[str, int]] = []
    hotspot = np.zeros(mask.shape[:2], dtype=np.int32)
    for index in range(mask.shape[2]):
        slice_mask = mask[:, :, index]
        if not np.any(slice_mask):
            continue
        row, col = compute_mask_centroid(slice_mask)
        centers.append({"slice_index": index, "row": row, "col": col})
        hotspot += build_hit_map([(row, col)], mask.shape[:2])
    centroid_dir = case_dir / "centroid"
    centroid_dir.mkdir(parents=True, exist_ok=True)
    centroid_path = centroid_dir / f"{_case_id_from_path(mask_path)}.centroids.json"
    centroid_path.write_text(json.dumps(centers, indent=2), encoding="utf-8")
    hotspot_path = centroid_dir / f"{_case_id_from_path(mask_path)}.hotspot.png"
    Image.fromarray(render_hotspot_preview(hotspot)).save(hotspot_path)
    return centroid_path, hotspot_path


def _write_polar_outputs(
    source_path: Path,
    case_dir: Path,
    *,
    mask_path: Path | None = None,
    data_path: Path | None = None,
    ring_width: int = DEFAULT_RING_WIDTH,
    polar_width: int = DEFAULT_POLAR_WIDTH,
    axis: str | int | None = None,
    export_all: bool = False,
    export_count: int | None = None,
    export_png: bool = False,
) -> tuple[Path, Path]:
    if ring_width <= 0:
        raise ValueError("ring-width must be greater than zero")
    if polar_width < DEFAULT_POLAR_WIDTH:
        raise ValueError("polar-width must be greater than or equal to 360")
    if export_count is not None and not export_all:
        raise ValueError("count requires --all")
    if export_count is not None and export_count <= 0:
        raise ValueError("count must be greater than 0")
    image_path, resolved_mask_path = _resolve_image_and_mask(
        source_path,
        case_dir,
        mask_path=mask_path,
        data_path=data_path,
    )
    image = read_nrrd(image_path)
    mask = read_nrrd(resolved_mask_path)
    normalized_axis = _normalize_polar_axis(axis)
    selected_exports = _select_polar_slice_exports(
        image,
        mask,
        axis=normalized_axis,
        export_all=export_all,
        export_count=export_count,
    )
    max_export = _select_largest_tumor_slice(image, mask, axis=normalized_axis)
    polar_dir = case_dir / "polar"
    raw_dir = polar_dir / "raw16"
    preview_dir = polar_dir / "preview8"
    raw_dir.mkdir(parents=True, exist_ok=True)
    preview_dir.mkdir(parents=True, exist_ok=True)
    case_id = _case_id_from_path(source_path)
    matrix_path = raw_dir / f"{case_id}_polar.npy"
    preview_path = preview_dir / f"{case_id}_polar.png"
    data_dir = case_dir.parent.parent / "data" if export_png else None
    if data_dir is not None:
        data_dir.mkdir(parents=True, exist_ok=True)
    max_polar: np.ndarray | None = None
    single_polar: np.ndarray | None = None
    for selected in selected_exports:
        polar = render_polar_patch(selected.image_slice, selected.mask_slice, ring_width=ring_width)
        polar = pad_polar_width(polar, polar_width)
        indexed_stem = _polar_slice_stem(case_id, axis=normalized_axis, axis_index=selected.axis_index)
        if export_all:
            np.save(raw_dir / f"{indexed_stem}_polar.npy", polar)
            Image.fromarray(to_preview_8bit(polar)).save(preview_dir / f"{indexed_stem}_polar.png")
        else:
            single_polar = polar
        if data_dir is not None:
            _save_raw_polar_png(data_dir / f"{indexed_stem}.png", polar)
        if selected.axis_index == max_export.axis_index:
            max_polar = polar
    chosen_polar = max_polar if export_all else single_polar
    if chosen_polar is None:
        raise ValueError("selected axis does not contain any tumor slices")
    np.save(matrix_path, chosen_polar)
    Image.fromarray(to_preview_8bit(chosen_polar)).save(preview_path)
    return matrix_path, preview_path


def _resolve_image_and_mask(
    source_path: Path,
    case_dir: Path,
    *,
    mask_path: Path | None = None,
    data_path: Path | None = None,
) -> tuple[Path, Path]:
    if mask_path is not None:
        return source_path, mask_path

    if _is_mask_volume(source_path):
        image_path = _guess_image_pair(source_path, case_dir, data_path=data_path)
        if image_path is None:
            raise ValueError(_missing_paired_image_error())
        return image_path, source_path

    guessed_mask = _guess_mask_pair(source_path, case_dir)
    if guessed_mask is None:
        raise ValueError("unable to locate a paired segmentation or label volume for polar export")
    return source_path, guessed_mask


def _missing_paired_image_error() -> str:
    return "unable to locate a paired image volume for the provided mask input; use --data to specify the sample data directory"


def _guess_image_pair(mask_path: Path, case_dir: Path, *, data_path: Path | None = None) -> Path | None:
    case_id = _case_id_from_path(mask_path)
    explicit_candidates: list[Path] = []
    if data_path is not None:
        explicit_candidates = [
            data_path / f"{case_id}.image.nrrd",
            data_path / f"{case_id}.nrrd",
        ]
    candidates = [
        *explicit_candidates,
        case_dir / "input" / f"{case_id}.image.nrrd",
        mask_path.parent.parent / "input" / f"{case_id}.image.nrrd",
        mask_path.parent.parent / "input" / f"{case_id}.nrrd",
        mask_path.parent.parent / "data" / f"{case_id}.image.nrrd",
        mask_path.parent.parent / "data" / f"{case_id}.nrrd",
        mask_path.parent.parent.parent / "data" / f"{case_id}.image.nrrd",
        mask_path.parent.parent.parent / "data" / f"{case_id}.nrrd",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _guess_mask_pair(image_path: Path, case_dir: Path) -> Path | None:
    case_id = _case_id_from_path(image_path)
    candidates = [
        case_dir / "refine" / f"{case_id}.refined.seg.nrrd",
        case_dir / "segmentation" / f"{case_id}.seg.nrrd",
        image_path.parent.parent / "label" / f"{case_id}.label.nrrd",
        image_path.parent.parent / "segmentation" / f"{case_id}.seg.nrrd",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _normalize_polar_axis(axis: str | int | None) -> int:
    lookup = {
        None: 0,
        0: 0,
        1: 1,
        2: 2,
        "0": 0,
        "1": 1,
        "2": 2,
        "z": 0,
        "y": 1,
        "x": 2,
    }
    key = axis if isinstance(axis, int) else str(axis).lower() if axis is not None else None
    normalized = lookup.get(key)
    if normalized is None:
        raise ValueError("axis must be one of 0, 1, 2, z, y, or x")
    return normalized


def _polar_slice_stem(case_id: str, *, axis: int, axis_index: int) -> str:
    if axis == 0:
        return f"{case_id}_{axis_index:03d}_0_0"
    if axis == 1:
        return f"{case_id}_0_{axis_index:03d}_0"
    return f"{case_id}_0_0_{axis_index:03d}"


def _volume_axis_for_polar_axis(axis: int) -> int:
    return {0: 2, 1: 1, 2: 0}[axis]


def _slice_for_polar_axis(volume: np.ndarray, axis: int, index: int) -> np.ndarray:
    if axis == 0:
        return volume[:, :, index]
    if axis == 1:
        return volume[:, index, :]
    return volume[index, :, :]


def _select_polar_slice_exports(
    image: np.ndarray,
    mask: np.ndarray,
    *,
    axis: int,
    export_all: bool,
    export_count: int | None = None,
) -> list[PolarSliceSelection]:
    records = list(_iter_polar_slice_records(image, mask, axis=axis))
    if not records:
        raise ValueError("selected axis does not contain any tumor slices")
    if export_count is not None and not export_all:
        raise ValueError("count requires --all")
    if export_count is not None and export_count <= 0:
        raise ValueError("count must be greater than 0")
    ranked_records = sorted(records, key=lambda item: (-item.area, item.axis_index))
    if export_all and export_count is not None:
        return ranked_records[:export_count]
    if export_all:
        return ranked_records
    return [ranked_records[0]]


def _iter_polar_slice_records(image: np.ndarray, mask: np.ndarray, *, axis: int) -> list[PolarSliceSelection]:
    volume_axis = _volume_axis_for_polar_axis(axis)
    records: list[PolarSliceSelection] = []
    for index in range(mask.shape[volume_axis]):
        mask_slice = _slice_for_polar_axis(mask, axis, index)
        area = int(mask_slice.sum())
        if area <= 0:
            continue
        records.append(
            PolarSliceSelection(
                axis=axis,
                axis_index=index,
                image_slice=_slice_for_polar_axis(image, axis, index),
                mask_slice=mask_slice,
                area=area,
            )
        )
    return records


def _select_largest_tumor_slice(image: np.ndarray, mask: np.ndarray, *, axis: int) -> PolarSliceSelection:
    return _select_polar_slice_exports(image, mask, axis=axis, export_all=False)[0]


def _save_raw_polar_png(path: Path, polar: np.ndarray) -> None:
    image = Image.frombytes("I;16", (polar.shape[1], polar.shape[0]), polar.astype(np.uint16).tobytes())
    image.save(path)


def _dominant_slice_index(mask: np.ndarray) -> int:
    areas = mask.sum(axis=(0, 1))
    if not np.any(areas):
        raise ValueError("mask is empty")
    return int(np.argmax(areas))


def _preview_volume(volume: np.ndarray) -> np.ndarray:
    if volume.ndim == 2:
        return to_preview_8bit(volume)[:, :, None]
    preview = np.zeros_like(volume, dtype=np.uint8)
    for index in range(volume.shape[2]):
        preview[:, :, index] = to_preview_8bit(volume[:, :, index])
    return preview


def _mask_preview_volume(mask: np.ndarray) -> np.ndarray:
    return (mask > 0).astype(np.uint8) * 255


def _is_mask_volume(path: Path) -> bool:
    return any(token in path.name for token in (".label.", ".seg.", ".refined.", ".mask."))


def _case_id_from_path(path: Path) -> str:
    name = path.name
    for suffix in (
        ".refined.seg.nrrd",
        ".seg.nrrd",
        ".label.nrrd",
        ".image.nrrd",
        ".mask.nrrd",
        ".nrrd",
        ".nhdr",
    ):
        if name.endswith(suffix):
            return name[: -len(suffix)]
    return path.stem


def _nnunet_input_filename(path: Path) -> str:
    case_id = _case_id_from_path(path)
    match = re.fullmatch(r"(?:U?MR)(\d+)", case_id)
    if match is not None:
        case_id = f"case_{match.group(1)}"
    return f"{case_id}_0000{path.suffix}"
