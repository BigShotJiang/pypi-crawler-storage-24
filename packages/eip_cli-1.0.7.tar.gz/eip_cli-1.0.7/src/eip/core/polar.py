from __future__ import annotations

import math

import numpy as np
from scipy import ndimage as ndi

from eip.core.centroid import compute_mask_centroid


def _cross_structure() -> np.ndarray:
    return np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)


def build_ring_mask(mask: np.ndarray, ring_width: int) -> np.ndarray:
    binary = mask > 0
    if not np.any(binary):
        raise ValueError("mask is empty")
    expand_iterations = max(1, ring_width // 2)
    erosion_iterations = max(1, ring_width // 2)
    expanded = ndi.binary_dilation(binary, structure=_cross_structure(), iterations=expand_iterations)
    eroded = ndi.binary_erosion(binary, iterations=erosion_iterations)
    ring = expanded.astype(np.uint8) - eroded.astype(np.uint8)
    return ring > 0


def render_polar_patch(image: np.ndarray, mask: np.ndarray, ring_width: int, degrees: int = 360) -> np.ndarray:
    ring = build_ring_mask(mask, ring_width)
    center_row, center_col = compute_mask_centroid(ring.astype(np.uint8))
    max_radius = min(center_row, center_col, image.shape[0] - center_row - 1, image.shape[1] - center_col - 1)
    if max_radius <= 0:
        raise ValueError("mask centroid is too close to the image boundary")

    endpoints: list[tuple[int, int, int, int]] = []
    for degree in range(degrees):
        theta = math.radians(degree)
        found = None
        for radius in range(max_radius, 0, -1):
            row = int(round(center_row + radius * math.cos(theta)))
            col = int(round(center_col + radius * math.sin(theta)))
            if 0 <= row < image.shape[0] and 0 <= col < image.shape[1] and ring[row, col]:
                start_radius = max(0, radius - ring_width + 1)
                start_row = int(round(center_row + start_radius * math.cos(theta)))
                start_col = int(round(center_col + start_radius * math.sin(theta)))
                found = (start_row, start_col, row, col)
                break
        if found is None:
            found = (center_row, center_col, center_row, center_col)
        endpoints.append(found)

    polar = np.zeros((ring_width, degrees), dtype=image.dtype)
    for degree, (start_row, start_col, end_row, end_col) in enumerate(endpoints):
        rows = np.rint(np.linspace(start_row, end_row, ring_width)).astype(int)
        cols = np.rint(np.linspace(start_col, end_col, ring_width)).astype(int)
        rows = np.clip(rows, 0, image.shape[0] - 1)
        cols = np.clip(cols, 0, image.shape[1] - 1)
        polar[:, degree] = image[rows, cols]
    return polar


def pad_polar_width(polar: np.ndarray, target_width: int) -> np.ndarray:
    if target_width < 360:
        raise ValueError("polar-width must be greater than or equal to 360")

    current_width = polar.shape[1]
    if target_width == current_width:
        return polar

    diff = target_width - current_width
    left_pad = diff // 2
    right_pad = diff - left_pad
    padded = np.zeros((polar.shape[0], target_width), dtype=polar.dtype)
    padded[:, left_pad : target_width - right_pad] = polar
    return padded


def to_preview_8bit(image: np.ndarray) -> np.ndarray:
    image = image.astype(np.float32)
    min_value = float(image.min())
    max_value = float(image.max())
    if max_value <= min_value:
        return np.zeros_like(image, dtype=np.uint8)
    scaled = (image - min_value) / (max_value - min_value)
    return np.rint(scaled * 255).astype(np.uint8)
