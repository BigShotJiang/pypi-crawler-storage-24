from __future__ import annotations

from pathlib import Path

import nrrd
import numpy as np


def write_nrrd(path: Path, volume: np.ndarray) -> None:
    nrrd.write(str(path), volume)


def read_nrrd(path: Path) -> np.ndarray:
    data, _ = nrrd.read(str(path))
    return data
