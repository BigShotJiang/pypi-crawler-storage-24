from __future__ import annotations

from pathlib import Path


def complete_path_suffix(root: str, suffixes: tuple[str, ...]) -> list[str]:
    base = Path(root)
    if not base.exists():
        return []
    matches: list[str] = []
    for path in base.iterdir():
        if path.is_dir() or path.name.endswith(suffixes):
            matches.append(str(path))
    return sorted(matches)
