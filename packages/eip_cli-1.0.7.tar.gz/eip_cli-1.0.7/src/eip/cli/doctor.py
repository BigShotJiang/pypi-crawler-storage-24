from __future__ import annotations

from eip.environment import detect_runtime_environment, inspect_dependency_groups


def run_doctor() -> str:
    runtime = detect_runtime_environment()
    nnunet_group = inspect_dependency_groups(("nnunet",)).groups["nnunet"]
    nnunet_status = ",".join(f"{item.name}:{item.status}" for item in nnunet_group.items) or "missing"
    return (
        f"python={runtime.python_version} "
        f"conda_env={runtime.conda_env or 'missing'} "
        f"nnunet={nnunet_status}"
    )
