from eip.cli.app import app

__all__ = ["app"]
