from __future__ import annotations

import json

from eip.config.models import CommandDefaults, CommandProfile, ProfilesState, WorkflowProfile

ALLOWED_PROFILE_COMMANDS = ("run", "segment", "slice", "refine", "centroid", "polar")


def export_profiles_json(state: ProfilesState) -> str:
    workflow_profiles = []
    for name in state.workflow_profile_names:
        profile = state.workflow_profiles.get(name, WorkflowProfile(name=name))
        workflow_profiles.append(
            {
                "name": profile.name,
                "description": profile.description,
                "commands": {command: defaults.values for command, defaults in profile.commands.items()},
            }
        )
    command_profiles = []
    for name in state.command_profile_names:
        profile = state.command_profiles.get(name)
        if profile is None:
            continue
        command_profiles.append(
            {
                "name": profile.name,
                "command": profile.command,
                "description": profile.description,
                "values": profile.values,
            }
        )
    return json.dumps(
        {
            "schema_version": 1,
            "workflow_profiles": workflow_profiles,
            "command_profiles": command_profiles,
        },
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    )


def import_profiles_json(payload: str) -> ProfilesState:
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise ValueError("Profiles import must be a JSON object.")
    if data.get("schema_version") != 1:
        raise ValueError("Unsupported schema version.")

    workflow_section = data.get("workflow_profiles")
    command_section = data.get("command_profiles")
    if not isinstance(workflow_section, list) or not isinstance(command_section, list):
        raise ValueError("Profiles import must include workflow_profiles and command_profiles arrays.")

    workflow_profiles: dict[str, WorkflowProfile] = {}
    workflow_profile_names: list[str] = []
    for raw_profile in workflow_section:
        if not isinstance(raw_profile, dict):
            raise ValueError("Workflow profile entries must be objects.")
        name = str(raw_profile.get("name", "")).strip()
        if not name:
            raise ValueError("Workflow profile name is required.")
        raw_commands = raw_profile.get("commands") or {}
        if not isinstance(raw_commands, dict):
            raise ValueError("Workflow profile commands must be an object.")
        workflow_profiles[name] = WorkflowProfile(
            name=name,
            description=str(raw_profile.get("description", "")),
            commands={
                str(command): CommandDefaults(values={str(k): str(v) for k, v in values.items()})
                for command, values in raw_commands.items()
                if isinstance(values, dict)
            },
        )
        workflow_profile_names.append(name)

    command_profiles: dict[str, CommandProfile] = {}
    command_profile_names: list[str] = []
    for raw_profile in command_section:
        if not isinstance(raw_profile, dict):
            raise ValueError("Command profile entries must be objects.")
        name = str(raw_profile.get("name", "")).strip()
        command = str(raw_profile.get("command", "")).strip()
        if not name:
            raise ValueError("Command profile name is required.")
        if command not in ALLOWED_PROFILE_COMMANDS:
            raise ValueError(f"Unsupported command profile command: {command}")
        raw_values = raw_profile.get("values") or {}
        if not isinstance(raw_values, dict):
            raise ValueError("Command profile values must be an object.")
        command_profiles[name] = CommandProfile(
            name=name,
            command=command,
            description=str(raw_profile.get("description", "")),
            values={str(k): str(v) for k, v in raw_values.items()},
        )
        command_profile_names.append(name)

    if not workflow_profile_names:
        workflow_profile_names = ["default"]
        workflow_profiles = {"default": WorkflowProfile(name="default")}

    return ProfilesState(
        workflow_profile_names=workflow_profile_names,
        command_profile_names=command_profile_names,
        default_workflow_profile=workflow_profile_names[0],
        workflow_profiles=workflow_profiles,
        command_profiles=command_profiles,
    )
