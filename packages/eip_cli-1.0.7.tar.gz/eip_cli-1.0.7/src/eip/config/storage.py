from __future__ import annotations

import shutil
import tomllib
from datetime import UTC, datetime
from pathlib import Path
import re

from eip.config.models import (
    CommandProfile,
    ProfilesState,
    TuiSettings,
    CommandDefaults,
    StorageState,
    WorkflowProfile,
)

_DEFAULT_BOOTSTRAP = "config_version = 1\n"
_DEFAULT_PROFILES = (
    'config_version = 1\n'
    'default_workflow_profile = "default"\n'
    'workflow_profile_names = ["default"]\n'
    'command_profile_names = []\n'
    "[workflow_profiles.default]\n"
    'description = ""\n'
    "commands = {}\n"
)
_DEFAULT_SETTINGS = (
    'config_version = 1\n'
    'language = "zh_CN"\n'
    'startup_page = "execution"\n'
    'command_preview_visible = true\n'
    'time_format = "24h"\n'
    'path_completion_enabled = true\n'
    'path_completion_recursive = true\n'
    'path_completion_limit = 4\n'
    'show_hidden_paths = false\n'
    'gui_dialog_enabled = true\n'
    'gui_dialog_mode = "prefer_gui_fallback_tui"\n'
    'default_browse_behavior = "files_and_dirs"\n'
    'eip_executable = "eip"\n'
    'cli_fallback_enabled = true\n'
    'logs_refresh_interval = 1.0\n'
    'notification_timeout_seconds = 4.0\n'
    'notification_max_visible = 3\n'
    'notification_allow_stack = true\n'
)
_DEFAULT_STATE = "config_version = 1\n"


class StorageManager:
    def __init__(self, root: Path, anchor_root: Path | None = None):
        self.root = Path(root)
        self.anchor_root = self.root if anchor_root is None else Path(anchor_root)

    @classmethod
    def default(cls) -> "StorageManager":
        default_root = Path.home() / ".eip"
        return cls(default_root, anchor_root=default_root)

    def bootstrap(self) -> StorageState:
        self.anchor_root.mkdir(parents=True, exist_ok=True)
        self.root.mkdir(parents=True, exist_ok=True)

        bootstrap_path = self.anchor_root / "bootstrap.toml"
        profiles_path = self.root / "profiles.toml"
        settings_path = self.root / "settings.toml"
        state_path = self.root / "state.toml"
        log_dir = self.root / "logs"

        if not bootstrap_path.exists():
            self._write_bootstrap(active_root=self.root)
        self._ensure_toml_file(profiles_path, _DEFAULT_PROFILES)
        self._ensure_toml_file(settings_path, _DEFAULT_SETTINGS)
        self._ensure_toml_file(state_path, _DEFAULT_STATE)
        log_dir.mkdir(parents=True, exist_ok=True)

        return StorageState(
            root=self.root,
            anchor_root=self.anchor_root,
            bootstrap_path=bootstrap_path,
            profiles_path=profiles_path,
            settings_path=settings_path,
            state_path=state_path,
            log_dir=log_dir,
        )

    def migrate_active_root(self, new_root: Path) -> StorageState:
        new_root = Path(new_root)
        new_root.mkdir(parents=True, exist_ok=True)

        for name in ("profiles.toml", "settings.toml", "state.toml"):
            shutil.copy2(self.root / name, new_root / name)
        shutil.copytree(self.root / "logs", new_root / "logs", dirs_exist_ok=True)

        self.root = new_root
        self._write_bootstrap(active_root=new_root)
        return self.bootstrap()

    def load_profiles_state(self) -> ProfilesState:
        state = self.bootstrap()
        data = tomllib.loads(state.profiles_path.read_text(encoding="utf-8"))
        if "workflow_profile_names" in data or "command_profile_names" in data or "workflow_profiles" in data:
            return self._load_repository_state(data)
        return self._load_legacy_profiles_state(data)

    def save_profiles_state(self, state: ProfilesState) -> None:
        normalized_workflow_names = list(dict.fromkeys(state.workflow_profile_names or ["default"]))
        if not normalized_workflow_names:
            normalized_workflow_names = ["default"]
        normalized_command_names = list(dict.fromkeys(state.command_profile_names or []))
        normalized_default = (
            state.default_workflow_profile
            if state.default_workflow_profile in normalized_workflow_names
            else normalized_workflow_names[0]
        )
        normalized_workflow_profiles = {
            name: state.workflow_profiles.get(name, WorkflowProfile(name=name)) for name in normalized_workflow_names
        }
        normalized_command_profiles = {
            name: state.command_profiles[name]
            for name in normalized_command_names
            if name in state.command_profiles
        }
        rendered_state = ProfilesState(
            workflow_profile_names=normalized_workflow_names,
            command_profile_names=list(normalized_command_profiles),
            default_workflow_profile=normalized_default,
            workflow_profiles=normalized_workflow_profiles,
            command_profiles=normalized_command_profiles,
        )
        boot_state = self.bootstrap()
        boot_state.profiles_path.write_text(
            self._render_profiles_file(rendered_state),
            encoding="utf-8",
        )

    def load_profile_names(self) -> list[str]:
        return self.load_profiles_state().workflow_profile_names

    def save_profile_names(self, profile_names: list[str], default_profile: str = "default") -> None:
        state = self.load_profiles_state()
        ordered_names = list(dict.fromkeys(profile_names or state.workflow_profile_names or [default_profile]))
        if not ordered_names:
            ordered_names = [default_profile]
        if default_profile not in ordered_names:
            default_profile = ordered_names[0]
        state.workflow_profile_names = ordered_names
        state.default_workflow_profile = default_profile
        state.workflow_profiles = {
            name: state.workflow_profiles.get(name, WorkflowProfile(name=name)) for name in ordered_names
        }
        self.save_profiles_state(state)

    def load_settings(self) -> TuiSettings:
        state = self.bootstrap()
        data = tomllib.loads(state.settings_path.read_text(encoding="utf-8"))
        return TuiSettings(
            language=str(data.get("language", "zh_CN")),
            startup_page=str(data.get("startup_page", "execution")),
            command_preview_visible=bool(data.get("command_preview_visible", True)),
            time_format=str(data.get("time_format", "24h")),
            path_completion_enabled=bool(data.get("path_completion_enabled", True)),
            path_completion_recursive=bool(data.get("path_completion_recursive", True)),
            path_completion_limit=int(data.get("path_completion_limit", 4)),
            show_hidden_paths=bool(data.get("show_hidden_paths", False)),
            gui_dialog_enabled=bool(data.get("gui_dialog_enabled", True)),
            gui_dialog_mode=str(data.get("gui_dialog_mode", "prefer_gui_fallback_tui")),
            default_browse_behavior=str(data.get("default_browse_behavior", "files_and_dirs")),
            eip_executable=self._normalize_eip_executable(data.get("eip_executable", "eip")),
            cli_fallback_enabled=bool(data.get("cli_fallback_enabled", True)),
            logs_refresh_interval=float(data.get("logs_refresh_interval", 1.0)),
            notification_timeout_seconds=float(data.get("notification_timeout_seconds", 4.0)),
            notification_max_visible=int(data.get("notification_max_visible", 3)),
            notification_allow_stack=bool(data.get("notification_allow_stack", True)),
        )

    def save_settings(self, settings: TuiSettings) -> None:
        settings = TuiSettings(
            language=settings.language,
            startup_page=settings.startup_page,
            command_preview_visible=settings.command_preview_visible,
            time_format=settings.time_format,
            path_completion_enabled=settings.path_completion_enabled,
            path_completion_recursive=settings.path_completion_recursive,
            path_completion_limit=settings.path_completion_limit,
            show_hidden_paths=settings.show_hidden_paths,
            gui_dialog_enabled=settings.gui_dialog_enabled,
            gui_dialog_mode=settings.gui_dialog_mode,
            default_browse_behavior=settings.default_browse_behavior,
            eip_executable=self._normalize_eip_executable(settings.eip_executable),
            cli_fallback_enabled=settings.cli_fallback_enabled,
            logs_refresh_interval=settings.logs_refresh_interval,
            notification_timeout_seconds=settings.notification_timeout_seconds,
            notification_max_visible=settings.notification_max_visible,
            notification_allow_stack=settings.notification_allow_stack,
        )
        state = self.bootstrap()
        state.settings_path.write_text(
            self._render_settings_file(settings),
            encoding="utf-8",
        )

    def _normalize_eip_executable(self, value: object) -> str:
        executable = str(value).strip() if value is not None else "eip"
        if not executable:
            return "eip"
        if executable.casefold() in {"eip", "eip.exe"}:
            return executable.lower()
        return executable

    def _write_bootstrap(self, active_root: Path) -> None:
        bootstrap_path = self.anchor_root / "bootstrap.toml"
        bootstrap_path.write_text(
            _DEFAULT_BOOTSTRAP + f'active_storage_root = "{active_root}"\n',
            encoding="utf-8",
        )

    def _ensure_toml_file(self, path: Path, default_text: str) -> None:
        if path.exists():
            try:
                tomllib.loads(path.read_text(encoding="utf-8"))
                return
            except tomllib.TOMLDecodeError:
                timestamp = datetime.now(UTC).strftime("%Y%m%d%H%M%S")
                path.replace(path.with_name(f"{path.name}.corrupt-{timestamp}"))
        path.write_text(default_text, encoding="utf-8")

    def _render_profiles_file(self, state: ProfilesState) -> str:
        workflow_names = state.workflow_profile_names or ["default"]
        command_names = state.command_profile_names or []
        default_profile = (
            state.default_workflow_profile
            if state.default_workflow_profile in workflow_names
            else workflow_names[0]
        )
        quoted_workflow_names = ", ".join(f'"{name}"' for name in workflow_names)
        quoted_command_names = ", ".join(f'"{name}"' for name in command_names)
        lines = [
            "config_version = 1",
            f'default_workflow_profile = "{default_profile}"',
            f"workflow_profile_names = [{quoted_workflow_names}]",
            f"command_profile_names = [{quoted_command_names}]",
        ]
        for profile_name in workflow_names:
            profile = state.workflow_profiles.get(profile_name, WorkflowProfile(name=profile_name))
            commands = profile.commands or {}
            lines.append("")
            lines.append(f"[workflow_profiles.{self._toml_key(profile_name)}]")
            lines.append(f'description = "{profile.description}"')
            if not commands:
                lines.append("commands = {}")
                continue
            for command_name, defaults in commands.items():
                lines.append("")
                lines.append(
                    f"[workflow_profiles.{self._toml_key(profile_name)}.commands.{self._toml_key(command_name)}]"
                )
                for key, value in defaults.values.items():
                    lines.append(f'{self._toml_key(key)} = "{value}"')
        for profile_name in command_names:
            profile = state.command_profiles.get(profile_name)
            if profile is None:
                continue
            lines.append("")
            lines.append(f"[command_profiles.{self._toml_key(profile_name)}]")
            lines.append(f'command = "{profile.command}"')
            lines.append(f'description = "{profile.description}"')
            if not profile.values:
                lines.append("values = {}")
                continue
            lines.append("")
            lines.append(f"[command_profiles.{self._toml_key(profile_name)}.values]")
            for key, value in profile.values.items():
                lines.append(f'{self._toml_key(key)} = "{value}"')
        return "\n".join(lines) + "\n"

    def _load_repository_state(self, data: dict[str, object]) -> ProfilesState:
        workflow_names = [str(name) for name in data.get("workflow_profile_names") or ["default"]]
        if not workflow_names:
            workflow_names = ["default"]
        command_names = [str(name) for name in data.get("command_profile_names") or []]
        default_profile = str(data.get("default_workflow_profile", workflow_names[0]))

        workflow_profiles_section = data.get("workflow_profiles") or {}
        workflow_profiles: dict[str, WorkflowProfile] = {}
        for profile_name in workflow_names:
            profile_data = workflow_profiles_section.get(profile_name) or {}
            commands_section = profile_data.get("commands") or {}
            commands = self._parse_commands_section(commands_section)
            workflow_profiles[profile_name] = WorkflowProfile(
                name=profile_name,
                description=str(profile_data.get("description", "")),
                commands=commands,
            )

        command_profiles_section = data.get("command_profiles") or {}
        command_profiles: dict[str, CommandProfile] = {}
        for profile_name in command_names:
            profile_data = command_profiles_section.get(profile_name) or {}
            values_section = profile_data.get("values") or {}
            command_profiles[profile_name] = CommandProfile(
                name=profile_name,
                command=str(profile_data.get("command", "")),
                description=str(profile_data.get("description", "")),
                values={str(k): str(v) for k, v in values_section.items()},
            )

        return ProfilesState(
            workflow_profile_names=workflow_names,
            command_profile_names=[name for name in command_names if name in command_profiles],
            default_workflow_profile=default_profile if default_profile in workflow_names else workflow_names[0],
            workflow_profiles=workflow_profiles,
            command_profiles=command_profiles,
        )

    def _load_legacy_profiles_state(self, data: dict[str, object]) -> ProfilesState:
        profile_names = [str(name) for name in data.get("profile_names") or ["default"]]
        if not profile_names:
            profile_names = ["default"]
        default_profile = str(data.get("default_profile", profile_names[0]))
        profiles_section = data.get("profiles") or {}
        profiles: dict[str, WorkflowProfile] = {}
        for profile_name in profile_names:
            profile_data = profiles_section.get(profile_name) or {}
            commands = self._parse_commands_section(profile_data.get("commands") or {})
            profiles[profile_name] = WorkflowProfile(name=profile_name, commands=commands)
        return ProfilesState(
            workflow_profile_names=profile_names,
            default_workflow_profile=default_profile if default_profile in profile_names else profile_names[0],
            workflow_profiles=profiles,
            command_profiles={},
        )

    def _parse_commands_section(self, commands_section: dict[str, object]) -> dict[str, CommandDefaults]:
        commands: dict[str, CommandDefaults] = {}
        for command_name, command_values in commands_section.items():
            if isinstance(command_values, dict):
                commands[command_name] = CommandDefaults(values={str(k): str(v) for k, v in command_values.items()})
        return commands

    def _toml_key(self, value: str) -> str:
        if re.fullmatch(r"[A-Za-z0-9_-]+", value):
            return value
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'

    def _render_settings_file(self, settings: TuiSettings) -> str:
        return (
            "config_version = 1\n"
            f'language = "{settings.language}"\n'
            f'startup_page = "{settings.startup_page}"\n'
            f"command_preview_visible = {str(settings.command_preview_visible).lower()}\n"
            f'time_format = "{settings.time_format}"\n'
            f"path_completion_enabled = {str(settings.path_completion_enabled).lower()}\n"
            f"path_completion_recursive = {str(settings.path_completion_recursive).lower()}\n"
            f"path_completion_limit = {settings.path_completion_limit}\n"
            f"show_hidden_paths = {str(settings.show_hidden_paths).lower()}\n"
            f"gui_dialog_enabled = {str(settings.gui_dialog_enabled).lower()}\n"
            f'gui_dialog_mode = "{settings.gui_dialog_mode}"\n'
            f"default_browse_behavior = \"{settings.default_browse_behavior}\"\n"
            f'eip_executable = "{settings.eip_executable}"\n'
            f"cli_fallback_enabled = {str(settings.cli_fallback_enabled).lower()}\n"
            f"logs_refresh_interval = {settings.logs_refresh_interval}\n"
            f"notification_timeout_seconds = {settings.notification_timeout_seconds}\n"
            f"notification_max_visible = {settings.notification_max_visible}\n"
            f"notification_allow_stack = {str(settings.notification_allow_stack).lower()}\n"
        )
