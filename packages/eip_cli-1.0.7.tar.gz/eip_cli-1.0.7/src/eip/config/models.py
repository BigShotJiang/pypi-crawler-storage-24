from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class StorageState:
    root: Path
    anchor_root: Path
    bootstrap_path: Path
    profiles_path: Path
    settings_path: Path
    state_path: Path
    log_dir: Path


@dataclass(slots=True)
class CommandDefaults:
    values: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class WorkflowProfile:
    name: str
    description: str = ""
    commands: dict[str, CommandDefaults] = field(default_factory=dict)


@dataclass(slots=True)
class CommandProfile:
    name: str
    command: str
    description: str = ""
    values: dict[str, str] = field(default_factory=dict)


Profile = WorkflowProfile


@dataclass(slots=True)
class ProfilesState:
    workflow_profile_names: list[str] = field(default_factory=lambda: ["default"])
    command_profile_names: list[str] = field(default_factory=list)
    default_workflow_profile: str = "default"
    workflow_profiles: dict[str, WorkflowProfile] = field(
        default_factory=lambda: {"default": WorkflowProfile(name="default")}
    )
    command_profiles: dict[str, CommandProfile] = field(default_factory=dict)

    @property
    def profile_names(self) -> list[str]:
        return self.workflow_profile_names

    @profile_names.setter
    def profile_names(self, value: list[str]) -> None:
        self.workflow_profile_names = value

    @property
    def default_profile(self) -> str:
        return self.default_workflow_profile

    @default_profile.setter
    def default_profile(self, value: str) -> None:
        self.default_workflow_profile = value

    @property
    def profiles(self) -> dict[str, WorkflowProfile]:
        return self.workflow_profiles

    @profiles.setter
    def profiles(self, value: dict[str, WorkflowProfile]) -> None:
        self.workflow_profiles = value


@dataclass(slots=True)
class TuiSettings:
    language: str = "zh_CN"
    startup_page: str = "execution"
    command_preview_visible: bool = True
    time_format: str = "24h"
    path_completion_enabled: bool = True
    path_completion_recursive: bool = True
    path_completion_limit: int = 4
    show_hidden_paths: bool = False
    gui_dialog_enabled: bool = True
    gui_dialog_mode: str = "prefer_gui_fallback_tui"
    default_browse_behavior: str = "files_and_dirs"
    eip_executable: str = "eip"
    cli_fallback_enabled: bool = True
    logs_refresh_interval: float = 1.0
    notification_timeout_seconds: float = 4.0
    notification_max_visible: int = 3
    notification_allow_stack: bool = True
