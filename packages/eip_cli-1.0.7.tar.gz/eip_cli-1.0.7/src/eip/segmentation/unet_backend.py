from __future__ import annotations

import sys
import urllib.request
from importlib.resources import files
from pathlib import Path

import numpy as np
from scipy import ndimage as ndi

from eip.core.nrrd_io import write_nrrd

MODEL_URL = "https://github.com/SuShuheng/eip-cli/releases/download/models-v1/CP_epoch161.pth"
MODEL_FILENAME = "CP_epoch161.pth"


def get_cached_model_path() -> Path:
    """Return the path where the model is cached locally."""
    return Path.home() / ".eip" / "models" / "unet" / MODEL_FILENAME


def download_model(url: str, dest: Path) -> Path:
    """Download model file with progress display."""
    dest.parent.mkdir(parents=True, exist_ok=True)

    print(f"Downloading model from {url}...")
    print(f"Destination: {dest}")

    def progress_hook(block_num: int, block_size: int, total_size: int) -> None:
        downloaded = block_num * block_size
        if total_size > 0:
            percent = min(100, int(downloaded * 100 / total_size))
            mb_downloaded = downloaded / (1024 * 1024)
            mb_total = total_size / (1024 * 1024)
            sys.stdout.write(f"\rProgress: {percent}% ({mb_downloaded:.1f}/{mb_total:.1f} MB)")
            sys.stdout.flush()

    urllib.request.urlretrieve(url, dest, progress_hook)
    print()  # New line after progress
    print(f"Model downloaded successfully to {dest}")
    return dest


class BuiltinUnetBackend:
    def __init__(self) -> None:
        self._model_cache: dict[Path, object] = {}

    def resolve_weight_path(self, override: str | None) -> Path:
        if override:
            return Path(override)

        # 1. Check cached model in ~/.eip/models/unet/
        cached_path = get_cached_model_path()
        if cached_path.exists():
            return cached_path

        # 2. Check bundled model (for backward compatibility)
        try:
            bundled_path = Path(files("eip.assets.models.unet").joinpath(MODEL_FILENAME))
            if bundled_path.exists():
                return bundled_path
        except Exception:
            pass

        # 3. Download model to cache directory
        return download_model(MODEL_URL, cached_path)

    def predict_volume(self, volume: np.ndarray, output_path: Path, weights: str | None = None) -> Path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        weight_path = self.resolve_weight_path(weights)
        segmentation = self._predict_with_unet(volume, weight_path)
        if not np.any(segmentation):
            segmentation = self._predict_with_fallback(volume)
        write_nrrd(output_path, segmentation.astype(np.uint8))
        return output_path

    def _predict_with_unet(self, volume: np.ndarray, weight_path: Path) -> np.ndarray:
        try:
            import torch

            from eip.segmentation.unet_legacy import UNet
        except Exception:
            return np.zeros_like(volume, dtype=np.uint8)

        try:
            model = self._model(weight_path, torch, UNet)
        except Exception:
            return np.zeros_like(volume, dtype=np.uint8)

        prediction = np.zeros_like(volume, dtype=np.uint8)
        with torch.no_grad():
            for index in range(volume.shape[2]):
                image_slice = volume[:, :, index].astype(np.float32)
                normalized = self._normalize_slice(image_slice)
                tensor = torch.from_numpy(normalized)[None, None, :, :]
                logits = model(tensor)
                classes = logits.argmax(dim=1)[0].cpu().numpy().astype(np.uint8)
                prediction[:, :, index] = (classes > 0).astype(np.uint8)
        return prediction

    def _model(self, weight_path: Path, torch_module, model_cls):
        if weight_path not in self._model_cache:
            model = model_cls(n_channels=1, n_classes=3)
            state_dict = torch_module.load(weight_path, map_location="cpu")
            model.load_state_dict(state_dict)
            model.eval()
            self._model_cache[weight_path] = model
        return self._model_cache[weight_path]

    def _predict_with_fallback(self, volume: np.ndarray) -> np.ndarray:
        segmentation = np.zeros_like(volume, dtype=np.uint8)
        for index in range(volume.shape[2]):
            image_slice = volume[:, :, index].astype(np.float32)
            nonzero = image_slice[image_slice > 0]
            if nonzero.size == 0:
                continue
            threshold = float(np.percentile(nonzero, 55))
            mask = image_slice >= threshold
            mask = ndi.binary_fill_holes(mask)
            mask = ndi.binary_opening(mask, iterations=1)
            labels, count = ndi.label(mask)
            if count == 0:
                continue
            areas = ndi.sum(mask, labels, range(1, count + 1))
            largest = labels == (int(np.argmax(areas)) + 1)
            segmentation[:, :, index] = largest.astype(np.uint8)
        return segmentation

    def _normalize_slice(self, image_slice: np.ndarray) -> np.ndarray:
        nonzero = image_slice[image_slice > 0]
        if nonzero.size == 0:
            return np.zeros_like(image_slice, dtype=np.float32)
        mean = float(nonzero.mean())
        std = float(nonzero.std())
        if std <= 0:
            std = 1.0
        normalized = (image_slice - mean) / std
        return normalized.astype(np.float32)
