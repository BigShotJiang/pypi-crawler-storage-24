from __future__ import annotations

from pathlib import Path
from typing import Protocol

import numpy as np


class SegmentationBackend(Protocol):
    def predict_volume(self, volume: np.ndarray, output_path: Path) -> Path:
        ...
