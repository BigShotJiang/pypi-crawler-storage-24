from __future__ import annotations

from pathlib import Path


class NnUnetBackend:
    def __init__(self, executable: str = "nnUNetv2_predict"):
        self.executable = executable

    def build_command(self, input_path: Path, output_dir: Path, dataset_id: str, configuration: str) -> list[str]:
        return [
            self.executable,
            "-i",
            str(input_path),
            "-o",
            str(output_dir),
            "-d",
            dataset_id,
            "-c",
            configuration,
        ]
