from __future__ import annotations

import logging as pylogging
from pathlib import Path


class _DefaultFormatter(pylogging.Formatter):
    def format(self, record: pylogging.LogRecord) -> str:
        case_id = getattr(record, "case_id", "-")
        return f"{record.levelname} source={record.name} case={case_id} message={record.getMessage()}"


def build_logger(log_dir: Path, source: str) -> pylogging.Logger:
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = pylogging.getLogger(f"eip.{source}")
    logger.setLevel(pylogging.INFO)
    logger.handlers.clear()
    handler = pylogging.FileHandler(log_dir / "eip.log", encoding="utf-8")
    handler.setFormatter(_DefaultFormatter())
    logger.addHandler(handler)
    logger.propagate = False
    return logger
