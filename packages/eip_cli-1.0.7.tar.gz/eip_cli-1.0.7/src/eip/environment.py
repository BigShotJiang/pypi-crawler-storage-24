from __future__ import annotations

from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
import os
import shutil
import sys


@dataclass(slots=True)
class RuntimeEnvironment:
    python_executable: str
    python_version: str
    conda_env: str = ""
    conda_prefix: str = ""
    virtual_env: str = ""
    pip_command: tuple[str, ...] = ()


@dataclass(slots=True)
class DependencyItemReport:
    name: str
    kind: str
    status: str
    version: str = ""
    detail: str = ""


@dataclass(slots=True)
class DependencyGroupReport:
    name: str
    items: list[DependencyItemReport]


@dataclass(slots=True)
class DependencyReport:
    groups: dict[str, DependencyGroupReport]


OPTIONAL_UNINSTALL_PACKAGES = {
    "torch": ("torch",),
    "nnunet": ("nnunetv2",),
}


def find_distribution_version(name: str) -> str | None:
    try:
        return version(name)
    except PackageNotFoundError:
        return None


def detect_runtime_environment() -> RuntimeEnvironment:
    return RuntimeEnvironment(
        python_executable=sys.executable,
        python_version=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        conda_env=os.getenv("CONDA_DEFAULT_ENV", ""),
        conda_prefix=os.getenv("CONDA_PREFIX", ""),
        virtual_env=os.getenv("VIRTUAL_ENV", ""),
        pip_command=(sys.executable, "-m", "pip"),
    )


def inspect_dependency_groups(group_names: tuple[str, ...]) -> DependencyReport:
    groups: dict[str, DependencyGroupReport] = {}
    for group_name in group_names:
        groups[group_name] = DependencyGroupReport(name=group_name, items=_inspect_group(group_name))
    return DependencyReport(groups=groups)


def build_install_command(runtime: RuntimeEnvironment, report: DependencyReport) -> list[str]:
    packages: list[str] = []
    for group in report.groups.values():
        for item in group.items:
            if item.kind == "package" and item.status == "missing":
                packages.append(item.name)
    return [*runtime.pip_command, "install", *packages]


def build_uninstall_command(runtime: RuntimeEnvironment, group_name: str) -> list[str]:
    packages = OPTIONAL_UNINSTALL_PACKAGES[group_name]
    return [*runtime.pip_command, "uninstall", "-y", *packages]


def _inspect_group(group_name: str) -> list[DependencyItemReport]:
    if group_name == "torch":
        return [_package_report("torch", "torch")]
    if group_name == "nnunet":
        return [
            _package_report("nnunetv2", "nnunetv2"),
            _executable_report("nnUNetv2_predict"),
        ]
    if group_name == "base":
        return [
            _package_report("numpy", "numpy"),
            _package_report("scipy", "scipy"),
            _package_report("pynrrd", "pynrrd"),
        ]
    return []


def _package_report(display_name: str, package_name: str) -> DependencyItemReport:
    resolved_version = find_distribution_version(package_name)
    if resolved_version is None:
        return DependencyItemReport(name=display_name, kind="package", status="missing")
    return DependencyItemReport(name=display_name, kind="package", status="installed", version=resolved_version)


def _executable_report(executable_name: str) -> DependencyItemReport:
    resolved = shutil.which(executable_name)
    if resolved is None:
        return DependencyItemReport(name=executable_name, kind="executable", status="missing")
    return DependencyItemReport(name=executable_name, kind="executable", status="installed", detail=resolved)
