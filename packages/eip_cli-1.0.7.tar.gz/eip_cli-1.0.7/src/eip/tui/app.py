from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from pathlib import Path

from textual.app import App, ScreenStackError
from textual.css.query import NoMatches
from textual.notifications import Notification
from textual.widgets import Static
from textual.widgets._toast import Toast, ToastHolder, ToastRack

from eip.config.models import TuiSettings
from eip.config.storage import StorageManager
from eip.tui.i18n import I18nCatalog
from eip.tui.pages.cli_help import CliHelpScreen
from eip.tui.pages.execution import ExecutionScreen
from eip.tui.pages.logs import LogEntry, LogStore, LogsScreen
from eip.tui.pages.profiles import ProfilesScreen
from eip.tui.pages.settings import SettingsScreen
from eip.tui.widgets.path_input import PathInput


class EipApp(App):
    CSS = """
    Screen {
        layout: vertical;
        background: $surface;
    }

    Header {
        dock: top;
    }

    Footer {
        dock: bottom;
    }

    #shell {
        width: 100%;
        height: 1fr;
        padding: 1 2;
    }

    #workspace {
        width: 100%;
        height: 1fr;
    }

    #primary-nav {
        width: 28;
        min-width: 24;
        height: 1fr;
        padding: 1;
        border: round $primary;
        background: $panel;
    }

    #page-panel {
        width: 1fr;
        height: 1fr;
        padding: 1 2;
        border: round $secondary;
        background: $boost;
    }

    #page-scroll {
        width: 100%;
        height: 1fr;
    }

    .page-title {
        text-style: bold;
        margin-bottom: 1;
    }

    .subtitle {
        color: $text-muted;
        margin-bottom: 1;
    }

    .section-title {
        text-style: bold;
        margin-top: 1;
        margin-bottom: 1;
    }

    .action-row {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    .action-row Button {
        width: 1fr;
        margin-right: 1;
    }

    #primary-nav Button {
        width: 100%;
        margin-bottom: 1;
    }

    #execution-path,
    #settings-storage-path {
        margin-top: 1;
    }

    #execution-workflow-tabs,
    #profiles-tabs {
        height: auto;
    }

    #status-bar {
        margin-top: 1;
        padding-top: 1;
        border-top: hkey $panel;
        color: $text-muted;
    }

    #textual-toastrack {
        dock: top;
        align: right top;
        margin-top: 1;
        margin-bottom: 0;
    }
    """

    def __init__(self, storage_root=None):
        super().__init__()
        self.storage_root = Path(storage_root) if storage_root is not None else Path.home() / ".eip"
        self.storage = StorageManager(root=self.storage_root, anchor_root=self.storage_root)
        self.tui_settings = self.storage.load_settings()
        self.log_store = LogStore()
        self.catalog = I18nCatalog.load()

    async def on_mount(self) -> None:
        self.install_screen(
            ExecutionScreen(id="execution", path_completion_limit=self.tui_settings.path_completion_limit),
            "execution",
        )
        self.install_screen(ProfilesScreen(id="profiles", storage_root=self.storage_root), "profiles")
        self.install_screen(SettingsScreen(id="settings", storage_root=self.storage_root), "settings")
        self.install_screen(LogsScreen(id="logs", log_store=self.log_store), "logs")
        self.install_screen(CliHelpScreen(id="cli-help"), "cli-help")
        startup_screen = self.tui_settings.startup_page if self.tui_settings.startup_page in {
            "execution",
            "profiles",
            "settings",
            "logs",
            "cli-help",
        } else "execution"
        await self.push_screen(startup_screen)
        self.update_tui_settings(self.tui_settings)
        self.screen.query_one(f"#nav-{startup_screen}").focus()

    def tr(self, key: str, **kwargs) -> str:
        return self.catalog.text(self.tui_settings.language, key, **kwargs)

    def update_tui_settings(self, settings: TuiSettings) -> None:
        language_changed = settings.language != self.tui_settings.language
        self.tui_settings = settings
        for screen_name in ("execution", "settings", "profiles", "logs", "cli-help"):
            try:
                screen = self.get_screen(screen_name)
            except KeyError:
                continue
            if hasattr(screen, "path_completion_limit"):
                screen.path_completion_limit = settings.path_completion_limit
            try:
                widgets = list(screen.query(PathInput))
            except Exception:
                widgets = []
            for widget in widgets:
                widget.dialog_enabled = settings.gui_dialog_enabled
                widget.recursive = settings.path_completion_recursive
                widget.set_max_candidates(settings.path_completion_limit)
                if language_changed:
                    refresher = getattr(widget, "refresh_text", None)
                    if refresher is not None:
                        refresher()
            if hasattr(screen, "refresh_interval"):
                screen.refresh_interval = settings.logs_refresh_interval
                try:
                    screen.refresh_viewer_and_filters()
                except Exception:
                    pass
            if language_changed and hasattr(screen, "apply_runtime_settings"):
                try:
                    screen.apply_runtime_settings(settings)
                except Exception:
                    pass
        if language_changed:
            try:
                self.screen.refresh_text()
            except Exception:
                pass

    def update_storage_root(self, new_root: Path) -> None:
        self.storage_root = new_root
        self.storage = StorageManager(root=new_root, anchor_root=new_root)
        for screen_name in ("execution", "settings", "profiles", "logs", "cli-help"):
            try:
                screen = self.get_screen(screen_name)
            except KeyError:
                continue
            if hasattr(screen, "storage_root"):
                screen.storage_root = new_root
            if hasattr(screen, "storage"):
                screen.storage = self.storage
            try:
                if hasattr(screen, "_storage_label"):
                    screen.query_one("#nav-storage", Static).update(screen._storage_label())
                else:
                    screen.query_one("#nav-storage", Static).update(f"Storage: {new_root}")
            except Exception:
                pass
            try:
                widgets = list(screen.query(PathInput))
            except Exception:
                widgets = []
            for widget in widgets:
                widget.base_path = new_root
                widget.refresh_candidates()
            if screen_name == "profiles":
                screen.profiles_state = screen.storage.load_profiles_state()
                if self.screen.id == "profiles":
                    asyncio.create_task(screen._refresh_view())

    def _refresh_notifications(self) -> None:
        try:
            screen = self.screen
        except ScreenStackError:
            return
        try:
            toast_rack = screen.get_child_by_type(ToastRack)
        except NoMatches:
            return
        self.call_later(self._show_and_stabilize_toast_rack, toast_rack)

    def log_event(self, level: str, source: str, message: str, **metadata) -> None:
        self.record_feedback(
            source=source,
            action="event",
            phase="info",
            message=message,
            level=level,
            notify=False,
            **metadata,
        )

    def record_feedback(
        self,
        *,
        source: str,
        action: str,
        phase: str,
        message: str,
        level: str = "info",
        notify: bool = True,
        command: str | None = None,
        argv: list[str] | None = None,
        **metadata,
    ) -> None:
        self.log_store.append(
            LogEntry(
                timestamp=datetime.now(UTC),
                level=level,
                source=source,
                message=message,
                action=action,
                phase=phase,
                command=command,
                argv=[] if argv is None else argv,
                metadata={key: str(value) for key, value in metadata.items()},
            )
        )
        if notify and phase != "noop":
            self._show_notification(message, phase)
        try:
            self.get_screen("logs").refresh_viewer_and_filters()
        except KeyError:
            pass

    def _show_notification(self, message: str, phase: str) -> None:
        if not self.tui_settings.notification_allow_stack:
            self.clear_notifications()
        else:
            notifications = list(self._notifications)
            while len(notifications) >= self.tui_settings.notification_max_visible:
                oldest = notifications.pop(0)
                self._unnotify(oldest, refresh=False)
        timeout = self._notification_timeout_for_phase(phase)
        self._notifications.add(
            Notification(
                message=message,
                severity=self._notification_severity_for_phase(phase),
                timeout=timeout,
            )
        )
        self._refresh_notifications()

    def _stabilize_toast_rack(self, toast_rack: ToastRack) -> None:
        active_ids = {ToastRack._toast_id(notification) for notification in self._notifications}
        for holder in list(toast_rack.query(ToastHolder)):
            has_toast_child = any(isinstance(child, Toast) for child in holder.children)
            if holder.id not in active_ids or not has_toast_child:
                holder.remove()
        toast_rack.scroll_home(animate=False, force=True)

    def _show_and_stabilize_toast_rack(self, toast_rack: ToastRack) -> None:
        toast_rack.show(self._notifications)
        self.call_after_refresh(self._stabilize_toast_rack, toast_rack)

    def _notification_severity_for_phase(self, phase: str) -> str:
        if phase == "error":
            return "error"
        if phase == "cancel":
            return "warning"
        return "information"

    def _notification_timeout_for_phase(self, phase: str) -> float:
        timeout = self.tui_settings.notification_timeout_seconds
        if phase == "error":
            return max(timeout, 6.0)
        return timeout
