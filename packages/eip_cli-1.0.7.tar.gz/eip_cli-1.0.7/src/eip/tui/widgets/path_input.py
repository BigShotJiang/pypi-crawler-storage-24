from __future__ import annotations

from pathlib import Path

from textual import events
from textual.message import Message
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.widgets import Button, Input, Static

from eip.tui.i18n import I18nCatalog
from eip.tui.dialogs import choose_path

PRELOADED_CANDIDATE_LIMIT = 50


class PathInput(Vertical):
    class Changed(Message):
        def __init__(self, path_input: "PathInput") -> None:
            super().__init__()
            self.path_input = path_input

    _fallback_catalog = I18nCatalog.load()

    DEFAULT_CSS = """
    PathInput {
        height: auto;
        layers: base overlay;
        position: relative;
    }

    .path-input-row {
        width: 100%;
        height: auto;
    }

    .path-input-row Input {
        width: 1fr;
        margin-right: 1;
    }

    .path-input-browse {
        width: 12;
    }

    .path-input-dropdown {
        layer: overlay;
        offset: 0 2;
        width: 100%;
        padding: 0 1;
        border: round $panel;
        background: $panel;
    }

    .path-input-status {
        color: $text-muted;
        margin-top: 1;
    }
    """

    def __init__(
        self,
        *args,
        base_path: str | Path | None = None,
        allowed_suffixes: tuple[str, ...] = (),
        recursive: bool = True,
        max_candidates: int = 4,
        placeholder: str = "",
        value: str = "",
        dialog_enabled: bool = True,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.base_path = Path(base_path) if base_path is not None else Path.cwd()
        self.allowed_suffixes = allowed_suffixes
        self.recursive = recursive
        self.max_candidates = max_candidates
        self.placeholder = placeholder
        self.dialog_enabled = dialog_enabled
        self._value = value
        self.all_candidates: list[str] = []
        self.candidates: list[str] = []
        self.window_start = 0
        self.highlight_index = 0
        self.dropdown_visible = False
        self.dropdown_text = ""
        self.status_text = ""
        self.permission_warning = ""
        self.editor_has_focus = False

    def tr(self, key: str, **kwargs) -> str:
        try:
            return self.app.tr(key, **kwargs)
        except Exception:
            return self._fallback_catalog.text("en_US", key, **kwargs)

    def compose(self) -> ComposeResult:
        with Horizontal(classes="path-input-row"):
            yield Input(placeholder=self.placeholder, classes="path-input-editor")
            yield Button(self.tr("path_input.browse"), classes="path-input-browse")
        yield Static("", classes="path-input-dropdown")
        yield Static("", classes="path-input-status")

    def on_mount(self) -> None:
        if self._value:
            self.editor.value = self._value
        self.editor.blur()
        self.refresh_candidates()
        self.dropdown_visible = False
        self._sync_views()

    async def on_descendant_focus(self, event: events.DescendantFocus) -> None:
        sender = getattr(event, 'sender', getattr(event, '_sender', None))
        if sender is self.editor:
            self.editor_has_focus = True
            self.refresh_candidates()

    async def on_descendant_blur(self, event: events.DescendantBlur) -> None:
        sender = getattr(event, 'sender', getattr(event, '_sender', None))
        if sender is self.editor:
            self.editor_has_focus = False
            self.dropdown_visible = False
            self._sync_views()

    @property
    def editor(self) -> Input:
        return self.query_one(Input)

    @property
    def dropdown(self) -> Static:
        return self.query_one(".path-input-dropdown", Static)

    @property
    def status(self) -> Static:
        return self.query_one(".path-input-status", Static)

    @property
    def value(self) -> str:
        try:
            return self.editor.value
        except NoMatches:
            return self._value

    @value.setter
    def value(self, new_value: str) -> None:
        self._value = new_value
        try:
            self.editor.value = new_value
            self.editor.cursor_position = len(new_value)
        except NoMatches:
            return
        self.refresh_candidates()
        self.post_message(self.Changed(self))

    def on_input_changed(self, event: Input.Changed) -> None:
        self.refresh_candidates()
        self.post_message(self.Changed(self))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if "path-input-browse" not in event.button.classes:
            return
        try:
            selected = choose_path(initial=self.value or str(self.base_path), enabled=self.dialog_enabled)
        except Exception as exc:
            self._record_feedback("browse", "error", str(exc), level="error", widget_id=self.id or "")
            self.editor.focus()
            return
        if selected is not None:
            self.value = selected
            self._record_feedback("browse", "success", selected, selected_path=selected, widget_id=self.id or "")
        else:
            self._record_feedback("browse", "cancel", self.tr("path_input.browse"), level="warn", widget_id=self.id or "")
        self.editor.focus()

    def refresh_candidates(self) -> None:
        search_root, prefix = self._resolve_search_context()
        if not self._safe_exists(search_root):
            self.all_candidates = []
            self.candidates = []
            self.window_start = 0
            self.highlight_index = 0
            self.dropdown_visible = False
            self.dropdown_text = ""
            self.status_text = self.tr("path_input.not_found")
            self.permission_warning = self._permission_message(search_root)
            self._sync_views()
            return

        try:
            iterator = self._iter_candidate_paths(search_root)
        except OSError:
            self._handle_permission(search_root)
            self.all_candidates = []
            self.candidates = []
            self.window_start = 0
            self.highlight_index = 0
            self.dropdown_visible = False
            self.status_text = self.permission_warning or self.tr("path_input.not_found")
            self._sync_views()
            return
        matches: list[Path] = []
        self.permission_warning = ""
        try:
            for path in iterator:
                if not self._is_candidate(path):
                    continue
                if prefix and not path.name.startswith(prefix):
                    continue
                matches.append(path)
                if len(matches) >= PRELOADED_CANDIDATE_LIMIT:
                    break
        except OSError:
            self._handle_permission(search_root)

        matches.sort(key=lambda path: (self._path_is_file(path), len(path.relative_to(search_root).parts), str(path)))
        self.all_candidates = [str(path) for path in matches]
        self.window_start = 0
        self.candidates = self._window_candidates()
        if self.highlight_index >= len(self.candidates):
            self.highlight_index = max(0, len(self.candidates) - 1)
        self.dropdown_visible = bool(self.candidates) and self.editor_has_focus
        self.dropdown_text = self._build_dropdown_text()
        count = len(self.all_candidates)
        if self.permission_warning:
            self.status_text = self.permission_warning
        elif count:
            self.status_text = ""
        else:
            self.status_text = self.tr("path_input.no_matches")
        self._sync_views()

    def _resolve_search_context(self) -> tuple[Path, str]:
        raw_value = self.value.strip()
        if not raw_value:
            return self.base_path, ""

        typed_path = Path(raw_value).expanduser()
        if not typed_path.is_absolute():
            typed_path = (self.base_path / typed_path).resolve()

        if self._safe_exists(typed_path):
            try:
                if typed_path.is_dir():
                    return typed_path, ""
            except OSError:
                self._handle_permission(typed_path)
                return self.base_path, raw_value
        if self._safe_exists(typed_path):
            return typed_path.parent, typed_path.name

        existing_parent = typed_path.parent
        while existing_parent != existing_parent.parent and not self._safe_exists(existing_parent):
            existing_parent = existing_parent.parent
        if self._safe_exists(existing_parent):
            try:
                if existing_parent.is_dir():
                    return existing_parent, typed_path.name
            except OSError:
                self._handle_permission(existing_parent)
                return self.base_path, raw_value
        return self.base_path, raw_value

    def _iter_candidate_paths(self, search_root: Path):
        try:
            return search_root.iterdir()
        except OSError:
            raise

    def _record_feedback(self, action: str, phase: str, message: str, level: str = "info", **metadata) -> None:
        try:
            recorder = getattr(self.app, "record_feedback", None)
        except Exception:
            recorder = None
        if recorder is None:
            return
        recorder(
            source="path-input",
            action=action,
            phase=phase,
            message=message,
            level=level,
            **metadata,
        )

    def _is_candidate(self, path: Path) -> bool:
        try:
            if path.is_dir():
                return True
        except OSError:
            self._handle_permission(path)
            return False
        if not self.allowed_suffixes:
            return True
        return path.name.endswith(self.allowed_suffixes)

    def _path_is_file(self, path: Path) -> bool:
        try:
            return path.is_file()
        except OSError:
            return True

    def _build_dropdown_text(self) -> str:
        return "\n".join(
            f"{'> ' if index == self.highlight_index else '  '}{candidate}"
            for index, candidate in enumerate(self.candidates)
        )

    def _window_candidates(self) -> list[str]:
        return self.all_candidates[self.window_start : self.window_start + self.max_candidates]

    def _sync_views(self) -> None:
        try:
            dropdown = self.dropdown
        except NoMatches:
            return
        dropdown.update(self.dropdown_text)
        dropdown.display = self.dropdown_visible
        self.status.update(self.status_text)

    def _safe_exists(self, path: Path) -> bool:
        try:
            return path.exists()
        except OSError:
            self.permission_warning = self._permission_message(path)
            return False

    def _handle_permission(self, path: Path) -> None:
        self.permission_warning = self._permission_message(path)

    def _permission_message(self, path: Path) -> str:
        return self.tr("path_input.permission_denied", path=path)

    def set_max_candidates(self, max_candidates: int) -> None:
        self.max_candidates = max_candidates
        self.refresh_candidates()

    def refresh_text(self) -> None:
        self.query_one(".path-input-browse", Button).label = self.tr("path_input.browse")
        self.editor.placeholder = self.placeholder
        self.refresh_candidates()

    async def on_key(self, event: events.Key) -> None:
        if event.key == "down" and self.dropdown_visible and self.candidates:
            self._move_highlight(1)
            event.prevent_default()
            event.stop()
            return
        if event.key == "up" and self.dropdown_visible and self.candidates:
            self._move_highlight(-1)
            event.prevent_default()
            event.stop()
            return
        if event.key == "tab" and self.candidates:
            self._accept_highlighted_candidate()
            event.prevent_default()
            event.stop()
            return
        if event.key in {"escape", "esc"}:
            self.dropdown_visible = False
            self._sync_views()
            event.prevent_default()
            event.stop()

    def _move_highlight(self, delta: int) -> None:
        if not self.all_candidates:
            return
        absolute_index = self.window_start + self.highlight_index
        target_index = min(max(absolute_index + delta, 0), len(self.all_candidates) - 1)
        if delta > 0 and target_index >= self.window_start + len(self.candidates) and len(self.candidates) == self.max_candidates:
            self.window_start = min(self.window_start + 1, max(0, len(self.all_candidates) - self.max_candidates))
        elif delta < 0 and target_index < self.window_start:
            self.window_start = max(0, self.window_start - 1)
        self.candidates = self._window_candidates()
        self.highlight_index = target_index - self.window_start
        self.dropdown_text = self._build_dropdown_text()
        self._sync_views()

    def _accept_highlighted_candidate(self) -> None:
        self.editor.value = self.candidates[self.highlight_index]
        self._value = self.editor.value
        self.editor.cursor_position = len(self.editor.value)
        self.dropdown_visible = False
        self._sync_views()
        self.post_message(self.Changed(self))
