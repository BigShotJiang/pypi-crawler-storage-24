from __future__ import annotations

import tomllib
from importlib.resources import files


class I18nCatalog:
    def __init__(self, tables: dict[str, dict[str, str]]):
        self.tables = tables

    @classmethod
    def load(cls) -> "I18nCatalog":
        return cls(
            {
                "en_US": tomllib.loads(files("eip.i18n").joinpath("en_US.toml").read_text(encoding="utf-8")),
                "zh_CN": tomllib.loads(files("eip.i18n").joinpath("zh_CN.toml").read_text(encoding="utf-8")),
            }
        )

    def text(self, locale: str, key: str, **kwargs) -> str:
        table = self.tables.get(locale, {})
        template = table.get(key)
        if template is None:
            return key
        if kwargs:
            try:
                return template.format(**kwargs)
            except Exception:
                return template
        return template
