from __future__ import annotations


def choose_path(initial: str | None = None, enabled: bool = True) -> str | None:
    if not enabled:
        return None
    return initial
