from __future__ import annotations

from pathlib import Path

from eip.config.models import TuiSettings
from eip.tui.i18n import I18nCatalog

from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Header, Static


class EipScreen(Screen):
    _fallback_catalog = I18nCatalog.load()

    BINDINGS = [
        ("left", "nav_prev", "Prev"),
        ("right", "nav_next", "Next"),
        ("up", "focus_previous_widget", "Up"),
        ("down", "focus_next_widget", "Down"),
    ]

    page_key = "execution"
    page_title_key = "page_execution"
    page_subtitle_key = "page_execution.subtitle"
    active_nav = "execution"

    def tr(self, key: str, **kwargs) -> str:
        try:
            return self.app.tr(key, **kwargs)
        except Exception:
            return self._fallback_catalog.text("en_US", key, **kwargs)

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Container(id="shell"):
            with Horizontal(id="workspace"):
                with Vertical(id="primary-nav"):
                    yield Static(self.tr("nav.brand"), id="nav-brand")
                    yield Static(self.tr("nav.tagline"), id="nav-tagline", classes="subtitle")
                    yield self._nav_button("execution", self.tr("page_execution"))
                    yield self._nav_button("profiles", self.tr("page_profiles"))
                    yield self._nav_button("settings", self.tr("page_settings"))
                    yield self._nav_button("logs", self.tr("page_logs"))
                    yield self._nav_button("cli-help", self.tr("page_cli_help"))
                    yield Static(self._storage_label(), id="nav-storage", classes="subtitle")
                with Vertical(id="page-panel"):
                    yield Static(self.tr(self.page_title_key), id=f"{self.page_key}-heading", classes="page-title")
                    yield Static(self.tr(self.page_subtitle_key), id=f"{self.page_key}-subtitle", classes="subtitle")
                    with VerticalScroll(id="page-scroll"):
                        yield from self.compose_body()
                    yield Static(self.status_text(), id="status-bar")
        yield Footer()

    def compose_body(self) -> ComposeResult:
        yield Static(self.tr(self.page_title_key), id=f"{self.page_key}-body")

    def status_text(self) -> str:
        return self.tr("status.help")

    def _storage_label(self) -> str:
        storage_root = getattr(self.app, "storage_root", None)
        if storage_root is None:
            storage_root = Path.home() / ".eip"
        return self.tr("nav.storage", path=Path(storage_root))

    def _nav_button(self, target: str, label: str) -> Button:
        variant = "primary" if target == self.active_nav else "default"
        return Button(label, id=f"nav-{target}", variant=variant)

    def _page_label_key(self, target: str) -> str:
        return "page_cli_help" if target == "cli-help" else f"page_{target}"

    def on_button_pressed(self, event: Button.Pressed) -> None:
        nav_targets = {
            "nav-execution": "execution",
            "nav-profiles": "profiles",
            "nav-settings": "settings",
            "nav-logs": "logs",
            "nav-cli-help": "cli-help",
        }
        target = nav_targets.get(event.button.id or "")
        if target is None:
            return
        if self.app.screen.id != target:
            self.app.switch_screen(target)

    def action_nav_next(self) -> None:
        self._switch_relative(1)

    def action_nav_prev(self) -> None:
        self._switch_relative(-1)

    def action_focus_next_widget(self) -> None:
        self.focus_next()

    def action_focus_previous_widget(self) -> None:
        self.focus_previous()

    def _switch_relative(self, step: int) -> None:
        order = ["execution", "profiles", "settings", "logs", "cli-help"]
        current = self.app.screen.id or self.active_nav
        index = order.index(current)
        self.app.switch_screen(order[(index + step) % len(order)])

    def apply_runtime_settings(self, settings: TuiSettings) -> None:
        self.runtime_language = settings.language
        self.refresh_text()

    def refresh_text(self) -> None:
        try:
            self.query_one("#nav-brand", Static).update(self.tr("nav.brand"))
            self.query_one("#nav-tagline", Static).update(self.tr("nav.tagline"))
            for target in ("execution", "profiles", "settings", "logs", "cli-help"):
                button = self.query_one(f"#nav-{target}", Button)
                button.label = self.tr(self._page_label_key(target))
            self.query_one("#nav-storage", Static).update(self._storage_label())
            self.query_one(f"#{self.page_key}-heading", Static).update(self.tr(self.page_title_key))
            self.query_one(f"#{self.page_key}-subtitle", Static).update(self.tr(self.page_subtitle_key))
            self.query_one("#status-bar", Static).update(self.status_text())
        except Exception:
            return
