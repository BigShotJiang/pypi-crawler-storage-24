from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime

from textual.app import ComposeResult
from textual.containers import Vertical, VerticalScroll
from textual.widgets import Input, Select, Static
from textual.css.query import NoMatches

from rich.panel import Panel
from rich.table import Table

from eip.tui.layout import EipScreen


@dataclass(slots=True)
class LogEntry:
    timestamp: datetime
    level: str
    source: str
    message: str
    action: str | None = None
    phase: str | None = None
    command: str | None = None
    argv: list[str] = field(default_factory=list)
    metadata: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class LogStore:
    entries: list[LogEntry] = field(default_factory=list)

    def append(self, entry: LogEntry) -> None:
        self.entries.append(entry)


class LogsScreen(EipScreen):
    page_key = "logs"
    page_title_key = "page_logs"
    page_subtitle_key = "logs.subtitle"
    active_nav = "logs"

    CSS = """
    #logs-viewer-panel {
        height: 1fr;
    }

    #logs-viewer {
        height: auto;
        background: $surface-lighten-2;
        border: round $accent;
        padding: 1;
    }
    """

    def __init__(self, log_store: LogStore | None = None, **kwargs):
        super().__init__(**kwargs)
        self.log_store = log_store or LogStore()
        self.level_filter = "all"
        self.source_filter = "all"
        self.refresh_interval = 1.0

    def compose_body(self) -> ComposeResult:
        yield Static(self.tr("logs.section.filters"), classes="section-title", id="logs-filters-title")
        with Vertical(id="logs-filters"):
            yield Select(
                self._level_options(),
                value=self.level_filter,
                id="logs-level-filter",
                prompt=self.tr("logs.filter.level"),
            )
            yield Select(
                self._source_options(),
                value=self.source_filter,
                id="logs-source-filter",
                prompt=self.tr("logs.filter.source"),
            )
            yield Input(
                value=f"{self.refresh_interval:.1f}",
                id="logs-refresh-input",
                placeholder=self.tr("logs.filter.refresh"),
            )
        yield Static(self.tr("logs.section.viewer"), classes="section-title", id="logs-viewer-title")
        with VerticalScroll(id="logs-viewer-panel"):
            yield Static("", id="logs-viewer")
        yield Static("", id="logs-summary", classes="subtitle")
        self.refresh_viewer_and_filters()

    def _level_options(self) -> list[tuple[str, str]]:
        return [
            (self.tr("logs.option.all"), "all"),
            (self.tr("logs.option.info"), "info"),
            (self.tr("logs.option.warn"), "warn"),
            (self.tr("logs.option.error"), "error"),
        ]

    def _source_options(self) -> list[tuple[str, str]]:
        sources = {"all"}
        sources.update(entry.source for entry in self.log_store.entries)
        return [(self.tr("logs.option.all"), "all")] + sorted(
            [(source.capitalize(), source) for source in sources if source != "all"],
            key=lambda pair: pair[0],
        )

    def filter_entries(self, level: str, source: str) -> list[LogEntry]:
        return [
            entry
            for entry in self.log_store.entries
            if (level == "all" or entry.level == level)
            and (source == "all" or entry.source == source)
        ]

    def set_level_filter(self, level: str) -> None:
        self.level_filter = level
        self.refresh_viewer()

    def set_source_filter(self, source: str) -> None:
        self.source_filter = source
        self.refresh_viewer()

    def set_refresh_interval(self, interval: float) -> None:
        self.refresh_interval = interval
        self.refresh_viewer()

    def visible_entries(self) -> list[LogEntry]:
        return self.filter_entries(self.level_filter, self.source_filter)

    def refresh_viewer(self) -> None:
        try:
            viewer = self.query_one("#logs-viewer", Static)
        except NoMatches:
            return
        entries = self.visible_entries()
        table = Table.grid(padding=(0, 1))
        table.add_column(self.tr("logs.table.time"), ratio=2)
        table.add_column(self.tr("logs.table.level"), style="bold")
        table.add_column(self.tr("logs.table.source"))
        table.add_column(self.tr("logs.table.message"), ratio=3)
        if entries:
            for entry in entries:
                table.add_row(
                    self.format_timestamp(entry.timestamp),
                    entry.level.upper(),
                    entry.source,
                    entry.message,
                )
            viewer.update(Panel(table))
        else:
            viewer.update(Panel(self.tr("logs.empty")))
        try:
            summary = self.query_one("#logs-summary", Static)
            summary.update(self.tr("logs.summary", count=len(entries), refresh=self.refresh_interval))
        except NoMatches:
            pass

    def format_timestamp(self, timestamp: datetime) -> str:
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=UTC)
        return timestamp.astimezone().strftime("%Y-%m-%d %H:%M:%S")

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.select.id == "logs-level-filter":
            self.set_level_filter(event.value)
        elif event.select.id == "logs-source-filter":
            self.set_source_filter(event.value)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "logs-refresh-input":
            return
        try:
            value = float(event.value)
        except ValueError:
            return
        self.set_refresh_interval(value)

    def refresh_viewer_and_filters(self) -> None:
        try:
            level_select = self.query_one("#logs-level-filter", Select)
            level_select.options = self._level_options()
            level_select.prompt = self.tr("logs.filter.level")
            source_select = self.query_one("#logs-source-filter", Select)
            source_select.options = self._source_options()
            source_select.prompt = self.tr("logs.filter.source")
            self.query_one("#logs-refresh-input", Input).placeholder = self.tr("logs.filter.refresh")
        except NoMatches:
            pass
        self.refresh_viewer()

    def refresh_text(self) -> None:
        super().refresh_text()
        self.query_one("#logs-filters-title", Static).update(self.tr("logs.section.filters"))
        self.query_one("#logs-viewer-title", Static).update(self.tr("logs.section.viewer"))
        self.refresh_viewer_and_filters()
