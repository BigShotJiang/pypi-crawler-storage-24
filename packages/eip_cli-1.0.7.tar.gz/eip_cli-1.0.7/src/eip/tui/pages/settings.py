from __future__ import annotations

import asyncio
from dataclasses import replace
from pathlib import Path
import shlex

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Button, Input, Select, Static, Switch, TabbedContent, TabPane

from eip.config.storage import StorageManager
from eip.environment import (
    DependencyReport,
    build_install_command,
    build_uninstall_command,
    detect_runtime_environment,
    inspect_dependency_groups,
)
from eip.tui.layout import EipScreen
from eip.tui.process_runner import ProcessRunner
from eip.tui.widgets.path_input import PathInput


class SettingsScreen(EipScreen):
    DEFAULT_CSS = """
    #settings-cli-env-output-title {
        margin-top: 1;
    }

    #settings-cli-env-output-panel {
        height: 16;
        border: round $accent;
        background: $surface-lighten-2;
    }

    #settings-cli-env-output-viewer {
        height: auto;
        min-height: 14;
        padding: 1;
    }
    """

    page_key = "settings"
    page_title_key = "page_settings"
    page_subtitle_key = "settings.subtitle"
    active_nav = "settings"

    def __init__(self, storage_root: str | Path | None = None, **kwargs):
        super().__init__(**kwargs)
        self.storage_root = Path(storage_root) if storage_root is not None else Path.home() / ".eip"
        self.storage = StorageManager(root=self.storage_root, anchor_root=self.storage_root)
        self.settings = self.storage.load_settings()
        self.status_message = ""
        self._status_key = ""
        self._status_kwargs: dict[str, object] = {}
        self._path_limit_status_key = ""
        self._path_limit_status_kwargs: dict[str, object] = {}
        self._cli_environment_results = ""
        self._cli_env_last_report: DependencyReport | None = None
        self._cli_env_task_state = "idle"
        self._cli_env_task_label = ""
        self._cli_env_output_text = ""
        self._cli_env_runner: ProcessRunner | None = None
        self._cli_env_worker = None
        self._cli_env_action = ""

    def compose_body(self) -> ComposeResult:
        with TabbedContent(id="settings-tabs"):
            with TabPane(self.tr("settings.tab.general"), id="settings-tab-general"):
                yield Static(self.tr("settings.general.language"), id="settings-language-label", classes="section-title")
                yield Select(
                    [("中文", "zh_CN"), ("English", "en_US")],
                    value=self.settings.language,
                    id="settings-language",
                )
                yield Static(self.tr("settings.general.startup_page"), id="settings-startup-page-label", classes="section-title")
                yield Select(
                    self._startup_page_options(),
                    value=self.settings.startup_page,
                    id="settings-startup-page",
                )
                yield Static(self.tr("settings.general.command_preview"), id="settings-command-preview-label", classes="section-title")
                yield Switch(value=self.settings.command_preview_visible, id="settings-command-preview")
                yield Static(self.tr("settings.general.time_format"), id="settings-time-format-label", classes="section-title")
                yield Select(
                    self._time_format_options(),
                    value=self.settings.time_format,
                    id="settings-time-format",
                )
                yield Button(self.tr("settings.action.save_general"), id="settings-save-general", variant="primary")
            with TabPane(self.tr("settings.tab.storage"), id="settings-tab-storage"):
                yield Static(self.tr("settings.storage.root"), id="settings-storage-root-label", classes="section-title")
                yield PathInput(
                    id="settings-storage-path",
                    base_path=self.storage_root,
                    max_candidates=self.settings.path_completion_limit,
                )
                yield Button(self.tr("settings.action.save_storage"), id="settings-save-storage", variant="primary")
            with TabPane(self.tr("settings.tab.completion"), id="settings-tab-completion"):
                yield Static(self.tr("settings.completion.enabled"), id="settings-completion-enabled-label", classes="section-title")
                yield Switch(value=self.settings.path_completion_enabled, id="settings-completion-enabled")
                yield Static(self.tr("settings.completion.recursive"), id="settings-completion-recursive-label", classes="section-title")
                yield Switch(value=self.settings.path_completion_recursive, id="settings-completion-recursive")
                yield Static(self.tr("settings.completion.limit"), id="settings-path-limit-label", classes="section-title")
                yield Input(value=str(self.settings.path_completion_limit), id="settings-path-limit-input")
                yield Button(self.tr("settings.action.save_completion"), id="settings-save-completion", variant="primary")
                yield Static("", id="settings-path-limit-status", classes="subtitle")
            with TabPane(self.tr("settings.tab.dialogs"), id="settings-tab-dialogs"):
                yield Static(self.tr("settings.dialogs.gui_enabled"), id="settings-gui-enabled-label", classes="section-title")
                yield Switch(value=self.settings.gui_dialog_enabled, id="settings-gui-enabled")
                yield Static(self.tr("settings.dialogs.mode"), id="settings-dialog-mode-label", classes="section-title")
                yield Select(
                    self._dialog_mode_options(),
                    value=self.settings.gui_dialog_mode,
                    id="settings-dialog-mode",
                )
                yield Static(self.tr("settings.dialogs.browse_behavior"), id="settings-browse-behavior-label", classes="section-title")
                yield Select(
                    self._browse_behavior_options(),
                    value=self.settings.default_browse_behavior,
                    id="settings-browse-behavior",
                )
                yield Button(self.tr("settings.action.save_dialogs"), id="settings-save-dialogs", variant="primary")
            with TabPane(self.tr("settings.tab.integration"), id="settings-tab-integration"):
                yield Static(self.tr("settings.integration.eip_executable"), id="settings-eip-executable-label", classes="section-title")
                yield Input(value=self.settings.eip_executable, id="settings-eip-executable")
                yield Static(self.tr("settings.integration.cli_fallback"), id="settings-cli-fallback-label", classes="section-title")
                yield Switch(value=self.settings.cli_fallback_enabled, id="settings-cli-fallback")
                yield Static(self.tr("settings.integration.logs_refresh"), id="settings-logs-refresh-label", classes="section-title")
                yield Input(value=str(self.settings.logs_refresh_interval), id="settings-logs-refresh")
                yield Button(self.tr("settings.action.save_integration"), id="settings-save-integration", variant="primary")
            with TabPane(self.tr("settings.tab.notifications"), id="settings-tab-notifications"):
                yield Static(self.tr("settings.notifications.timeout"), id="settings-notification-timeout-label", classes="section-title")
                yield Input(value=f"{self.settings.notification_timeout_seconds:.1f}", id="settings-notification-timeout")
                yield Static(self.tr("settings.notifications.max_visible"), id="settings-notification-max-visible-label", classes="section-title")
                yield Input(value=str(self.settings.notification_max_visible), id="settings-notification-max-visible")
                yield Static(self.tr("settings.notifications.allow_stack"), id="settings-notification-allow-stack-label", classes="section-title")
                yield Switch(value=self.settings.notification_allow_stack, id="settings-notification-allow-stack")
                yield Button(self.tr("settings.action.save_notifications"), id="settings-save-notifications", variant="primary")
            with TabPane(self.tr("settings.tab.cli_environment"), id="settings-tab-cli-environment"):
                yield Static(self.tr("settings.cli_environment.current"), classes="section-title")
                yield Static("", id="settings-cli-env-python", classes="subtitle")
                yield Static(self.tr("settings.cli_environment.groups"), classes="section-title")
                yield Static(self.tr("settings.cli_environment.group.base"), id="settings-cli-group-base-label", classes="subtitle")
                yield Switch(value=True, id="settings-cli-group-base")
                yield Static(self.tr("settings.cli_environment.group.torch"), id="settings-cli-group-torch-label", classes="subtitle")
                yield Switch(value=False, id="settings-cli-group-torch")
                yield Static(self.tr("settings.cli_environment.group.nnunet"), id="settings-cli-group-nnunet-label", classes="subtitle")
                yield Switch(value=False, id="settings-cli-group-nnunet")
                with Horizontal(classes="action-row"):
                    yield Button(self.tr("settings.action.check_dependencies"), id="settings-cli-env-check", variant="primary")
                    yield Button(self.tr("settings.action.install_dependencies"), id="settings-cli-env-install")
                    yield Button(
                        self.tr("settings.action.cancel_install"),
                        id="settings-cli-env-cancel-install",
                        disabled=True,
                    )
                with Horizontal(classes="action-row"):
                    yield Button(self.tr("settings.action.uninstall_torch"), id="settings-cli-env-uninstall-torch")
                    yield Button(self.tr("settings.action.uninstall_nnunet"), id="settings-cli-env-uninstall-nnunet")
                yield Static(self.tr("settings.cli_environment.task_status_idle"), classes="section-title", id="settings-cli-env-task-status")
                yield Static(self.tr("settings.cli_environment.results"), classes="section-title")
                yield Static("", id="settings-cli-env-results", classes="subtitle")
                yield Static(self.tr("settings.cli_environment.terminal"), classes="section-title", id="settings-cli-env-output-title")
                with VerticalScroll(id="settings-cli-env-output-panel"):
                    yield Static(
                        self._cli_env_output_text or self.tr("settings.cli_environment.output_placeholder"),
                        id="settings-cli-env-output-viewer",
                        classes="subtitle",
                    )
        yield Static(self.status_message, id="settings-status", classes="subtitle")

    def save_settings(self, **values):
        self.settings = replace(self.settings, **values)
        self.storage.save_settings(self.settings)
        try:
            app = self.app
        except Exception:
            app = None
        if app is not None:
            updater = getattr(app, "update_tui_settings", None)
            if updater is not None:
                updater(self.settings)
            self._log_settings_change(values)
        return self.settings

    def validate_logs_refresh_interval(self, raw_value: str) -> str | None:
        try:
            value = float(raw_value)
        except ValueError:
            return self.tr("settings.validation.logs_refresh_number")
        if value <= 0:
            return self.tr("settings.validation.logs_refresh_positive")
        return None

    def validate_path_completion_limit(self, raw_value: str) -> str | None:
        try:
            value = int(raw_value)
        except ValueError:
            return self.tr("settings.validation.path_limit_whole")
        if not 1 <= value <= 20:
            return self.tr("settings.validation.path_limit_range")
        return None

    def validate_notification_timeout(self, raw_value: str) -> str | None:
        try:
            value = float(raw_value)
        except ValueError:
            return self.tr("settings.validation.notification_timeout_number")
        if value <= 0:
            return self.tr("settings.validation.notification_timeout_positive")
        return None

    def validate_notification_max_visible(self, raw_value: str) -> str | None:
        try:
            value = int(raw_value)
        except ValueError:
            return self.tr("settings.validation.notification_max_visible_range")
        if not 1 <= value <= 5:
            return self.tr("settings.validation.notification_max_visible_range")
        return None

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""
        if button_id == "settings-save-general":
            self._save_general_settings()
            return
        if button_id == "settings-save-storage":
            self._save_storage_settings()
            return
        if button_id == "settings-save-completion":
            self._save_completion_settings()
            return
        if button_id == "settings-save-dialogs":
            self._save_dialog_settings()
            return
        if button_id == "settings-save-integration":
            self._save_integration_settings()
            return
        if button_id == "settings-save-notifications":
            self._save_notification_settings()
            return
        if button_id == "settings-cli-env-check":
            self._check_cli_environment()
            return
        if button_id == "settings-cli-env-install":
            self._install_cli_environment()
            return
        if button_id == "settings-cli-env-cancel-install":
            self._cancel_cli_environment_install()
            return
        if button_id == "settings-cli-env-uninstall-torch":
            self._uninstall_cli_environment("torch")
            return
        if button_id == "settings-cli-env-uninstall-nnunet":
            self._uninstall_cli_environment("nnunet")
            return
        super().on_button_pressed(event)

    def on_mount(self) -> None:
        self._refresh_cli_environment_widgets()
        self._refresh_cli_env_action_state()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "settings-path-limit-input":
            return
        self._save_completion_settings()

    def _save_general_settings(self) -> None:
        language = self.query_one("#settings-language", Select).value
        startup_page = self.query_one("#settings-startup-page", Select).value
        command_preview = self.query_one("#settings-command-preview", Switch).value
        time_format = self.query_one("#settings-time-format", Select).value
        self.save_settings(
            language=language,
            startup_page=startup_page,
            command_preview_visible=command_preview,
            time_format=time_format,
        )
        self._set_status("settings.status.saved_general")
        self._record_feedback("save_general", "success", self.status_message)

    def _save_storage_settings(self) -> None:
        storage_path = Path(self.query_one("#settings-storage-path", PathInput).value.strip())
        if not storage_path:
            self._set_status("settings.status.storage_empty")
            self._record_feedback("save_storage", "noop", self.status_message, level="warn")
            return
        self._record_feedback("save_storage", "start", self.tr("settings.action.save_storage"), path=storage_path)
        try:
            state = self.storage.migrate_active_root(storage_path)
        except Exception as exc:
            self._set_status("settings.status.storage_failed", error=exc)
            self._record_feedback("save_storage", "error", self.status_message, level="error", path=storage_path)
            return
        self.storage_root = state.root
        self.storage = StorageManager(root=self.storage_root, anchor_root=self.storage_root)
        storage_input = self.query_one("#settings-storage-path", PathInput)
        storage_input.base_path = self.storage_root
        storage_input.refresh_candidates()
        self._set_status("settings.status.storage_migrated", path=storage_path)
        app = getattr(self, "app", None)
        if app is not None:
            updater = getattr(app, "update_storage_root", None)
            if updater is not None:
                updater(self.storage_root)
        self._log_settings_change({"storage_root": str(storage_path)})
        self._record_feedback("save_storage", "success", self.status_message, path=storage_path)

    def _save_completion_settings(self) -> None:
        enabled = self.query_one("#settings-completion-enabled", Switch).value
        recursive = self.query_one("#settings-completion-recursive", Switch).value
        limit_input = self.query_one("#settings-path-limit-input", Input)
        raw_value = limit_input.value.strip()
        error = self.validate_path_completion_limit(raw_value)
        if error is not None:
            self._set_path_limit_status("settings.path_limit.validation", message=error)
            self._record_feedback("save_completion", "noop", error, level="warn")
            return
        value = int(raw_value)
        limit_input.value = str(value)
        self.save_settings(
            path_completion_enabled=enabled,
            path_completion_recursive=recursive,
            path_completion_limit=value,
        )
        self._set_path_limit_status("settings.path_limit.saved", value=value)
        self._set_status("settings.status.saved_completion")
        self._record_feedback("save_completion", "success", self.status_message, value=value)

    def _save_dialog_settings(self) -> None:
        gui_enabled = self.query_one("#settings-gui-enabled", Switch).value
        dialog_mode = self.query_one("#settings-dialog-mode", Select).value
        browse_behavior = self.query_one("#settings-browse-behavior", Select).value
        self.save_settings(
            gui_dialog_enabled=gui_enabled,
            gui_dialog_mode=dialog_mode,
            default_browse_behavior=browse_behavior,
        )
        self._set_status("settings.status.saved_dialogs")
        self._record_feedback("save_dialogs", "success", self.status_message)

    def _save_integration_settings(self) -> None:
        executable = self.query_one("#settings-eip-executable", Input).value.strip()
        fallback = self.query_one("#settings-cli-fallback", Switch).value
        logs_input = self.query_one("#settings-logs-refresh", Input)
        raw_interval = logs_input.value.strip()
        error = self.validate_logs_refresh_interval(raw_interval)
        if error is not None:
            self._set_status("settings.status.custom", message=error)
            self._record_feedback("save_integration", "noop", error, level="warn")
            return
        interval = float(raw_interval)
        logs_input.value = f"{interval:.1f}"
        self.save_settings(
            eip_executable=executable or self.settings.eip_executable,
            cli_fallback_enabled=fallback,
            logs_refresh_interval=interval,
        )
        self._set_status("settings.status.saved_integration")
        self._record_feedback("save_integration", "success", self.status_message)

    def _save_notification_settings(self) -> None:
        timeout_input = self.query_one("#settings-notification-timeout", Input)
        max_visible_input = self.query_one("#settings-notification-max-visible", Input)
        allow_stack = self.query_one("#settings-notification-allow-stack", Switch).value
        raw_timeout = timeout_input.value.strip()
        timeout_error = self.validate_notification_timeout(raw_timeout)
        if timeout_error is not None:
            self._set_status("settings.status.custom", message=timeout_error)
            self._record_feedback("save_notifications", "noop", timeout_error, level="warn")
            return
        raw_max_visible = max_visible_input.value.strip()
        max_visible_error = self.validate_notification_max_visible(raw_max_visible)
        if max_visible_error is not None:
            self._set_status("settings.status.custom", message=max_visible_error)
            self._record_feedback("save_notifications", "noop", max_visible_error, level="warn")
            return
        timeout_value = float(raw_timeout)
        max_visible_value = int(raw_max_visible)
        timeout_input.value = f"{timeout_value:.1f}"
        max_visible_input.value = str(max_visible_value)
        self.save_settings(
            notification_timeout_seconds=timeout_value,
            notification_max_visible=max_visible_value,
            notification_allow_stack=allow_stack,
        )
        self._set_status("settings.status.saved_notifications")
        self._record_feedback("save_notifications", "success", self.status_message)

    def _selected_dependency_groups(self) -> tuple[str, ...]:
        selected: list[str] = []
        if self.query_one("#settings-cli-group-base", Switch).value:
            selected.append("base")
        if self.query_one("#settings-cli-group-torch", Switch).value:
            selected.append("torch")
        if self.query_one("#settings-cli-group-nnunet", Switch).value:
            selected.append("nnunet")
        return tuple(selected)

    def _check_cli_environment(self) -> None:
        report = inspect_dependency_groups(self._selected_dependency_groups())
        self._store_cli_env_report(report)
        lines = [self._runtime_summary()]
        for group_name, group in report.groups.items():
            lines.append(f"[{group_name}]")
            if not group.items:
                lines.append(self.tr("settings.cli_environment.empty_group"))
                continue
            for item in group.items:
                suffix = f" {item.version}" if item.version else ""
                detail = f" {item.detail}" if item.detail else ""
                lines.append(f"- {item.name}: {item.status}{suffix}{detail}")
        self._cli_environment_results = "\n".join(lines)
        self.query_one("#settings-cli-env-results", Static).update(self._cli_environment_results)
        self._refresh_cli_env_action_state()
        self._record_feedback("check_dependencies", "success", self.tr("settings.action.check_dependencies"))

    def _install_cli_environment(self) -> None:
        if self._cli_env_worker is not None and not self._cli_env_worker.done():
            return
        runtime = detect_runtime_environment()
        selected = self._selected_dependency_groups()
        report = inspect_dependency_groups(selected)
        packages = [
            item.name
            for group in report.groups.values()
            for item in group.items
            if item.kind == "package" and item.status == "missing"
        ]
        if not packages:
            self._cli_environment_results = self.tr("settings.cli_environment.install_none")
            self.query_one("#settings-cli-env-results", Static).update(self._cli_environment_results)
            self._record_feedback("install_dependencies", "noop", self._cli_environment_results, level="warn")
            return
        self._cli_env_action = "install_dependencies"
        self._record_feedback("install_dependencies", "start", self.tr("settings.action.install_dependencies"))
        command = build_install_command(runtime, report)
        self._start_cli_env_task(command, "installing")

    def _uninstall_cli_environment(self, group_name: str) -> None:
        if self._cli_env_worker is not None and not self._cli_env_worker.done():
            return
        runtime = detect_runtime_environment()
        self._cli_env_action = f"uninstall_{group_name}"
        self._record_feedback(self._cli_env_action, "start", self.tr(f"settings.action.uninstall_{group_name}"))
        command = build_uninstall_command(runtime, group_name)
        self._start_cli_env_task(command, "uninstalling")

    def _cancel_cli_environment_install(self) -> None:
        if self._cli_env_task_state != "installing":
            return
        canceled = self._runner().cancel()
        if not canceled:
            return
        self._set_cli_env_task_state("install_cancel_requested")
        self._append_cli_env_output(f"\n{self.tr('settings.action.cancel_install')}\n")
        self._record_feedback(self._cli_env_action or "install_dependencies", "cancel", self.tr("settings.action.cancel_install"), level="warn")

    def _start_cli_env_task(self, command: list[str], task_state: str) -> None:
        self._set_cli_env_task_state(task_state)
        self._begin_cli_env_terminal(command)
        self._cli_env_worker = asyncio.create_task(self._run_cli_env_command(command))

    async def _run_cli_env_command(self, command: list[str]) -> None:
        try:
            result = await self._runner().run_stream(command, on_output=self._handle_cli_env_output)
            self._append_cli_env_output(f"\n[{self.tr('execution.output.exit_code', code=result.exit_code)}]\n")
            self._check_cli_environment()
            self._record_feedback(
                self._cli_env_action or "cli_environment",
                "success" if result.exit_code == 0 else "error",
                self.tr("execution.output.exit_code", code=result.exit_code),
                level="info" if result.exit_code == 0 else "error",
            )
        except Exception as exc:
            self._append_cli_env_output(f"\n{exc}\n")
            self._record_feedback(self._cli_env_action or "cli_environment", "error", str(exc), level="error")
        finally:
            self._cli_env_worker = None
            self._set_cli_env_task_state("idle")
            self._cli_env_action = ""

    def _runtime_summary(self) -> str:
        runtime = detect_runtime_environment()
        conda_env = runtime.conda_env or self.tr("settings.cli_environment.missing")
        return self.tr(
            "settings.cli_environment.summary",
            python=runtime.python_executable,
            version=runtime.python_version,
            conda_env=conda_env,
        )

    def _refresh_cli_environment_widgets(self) -> None:
        try:
            self.query_one("#settings-cli-env-python", Static).update(self._runtime_summary())
            self.query_one("#settings-cli-env-results", Static).update(self._cli_environment_results)
            self.query_one("#settings-cli-env-task-status", Static).update(
                self.tr(f"settings.cli_environment.task_status_{self._cli_env_task_state}")
            )
            self._refresh_cli_env_output_panel()
        except Exception:
            return

    def _set_cli_env_task_state(self, state: str, label: str = "") -> None:
        self._cli_env_task_state = state
        self._cli_env_task_label = label
        try:
            self.query_one("#settings-cli-env-task-status", Static).update(
                self.tr(f"settings.cli_environment.task_status_{state}")
            )
        except Exception:
            return
        self._refresh_cli_env_action_state()

    def _append_cli_env_output(self, text: str) -> None:
        if not text:
            return
        self._cli_env_output_text += text
        self._refresh_cli_env_output_panel()

    def _begin_cli_env_terminal(self, command: list[str]) -> None:
        self._cli_env_output_text = f"$ {shlex.join(command)}\n"
        self._refresh_cli_env_output_panel()

    def _refresh_cli_env_output_panel(self) -> None:
        try:
            self._cli_env_terminal_viewer().update(
                self._cli_env_output_text or self.tr("settings.cli_environment.output_placeholder")
            )
            panel = self._cli_env_terminal_panel()
            panel.scroll_end(animate=False)
        except Exception:
            return

    def _cli_env_terminal_panel(self) -> VerticalScroll:
        return self.query_one("#settings-cli-env-output-panel", VerticalScroll)

    def _cli_env_terminal_viewer(self) -> Static:
        return self.query_one("#settings-cli-env-output-viewer", Static)

    def _append_cli_env_terminal(self, text: str) -> None:
        self._append_cli_env_output(text)

    def _refresh_cli_env_action_state(self) -> None:
        try:
            install_button = self.query_one("#settings-cli-env-install", Button)
            cancel_button = self.query_one("#settings-cli-env-cancel-install", Button)
            uninstall_torch = self.query_one("#settings-cli-env-uninstall-torch", Button)
            uninstall_nnunet = self.query_one("#settings-cli-env-uninstall-nnunet", Button)
        except Exception:
            return
        is_installing = self._cli_env_task_state == "installing"
        is_busy = self._cli_env_task_state in {"installing", "uninstalling", "install_cancel_requested"}
        install_button.disabled = is_busy
        cancel_button.disabled = not is_installing
        uninstall_torch.disabled = is_busy or not self._cli_env_package_installed("torch")
        uninstall_nnunet.disabled = is_busy or not self._cli_env_package_installed("nnunetv2")

    def _cli_env_package_installed(self, package_name: str) -> bool:
        if self._cli_env_last_report is None:
            return False
        for group in self._cli_env_last_report.groups.values():
            for item in group.items:
                if item.kind != "package":
                    continue
                if item.name != package_name:
                    continue
                return item.status == "installed"
        return False

    def _runner(self) -> ProcessRunner:
        if self._cli_env_runner is None:
            log_store = getattr(getattr(self, "app", None), "log_store", None)
            self._cli_env_runner = ProcessRunner(log_dir=self.storage_root / "logs", log_store=log_store)
        return self._cli_env_runner

    async def _handle_cli_env_output(self, stream_name: str, text: str) -> None:
        del stream_name
        self._append_cli_env_output(text)

    def _store_cli_env_report(self, report: DependencyReport) -> None:
        self._cli_env_last_report = report

    def _set_status(self, key: str, **kwargs) -> None:
        self._status_key = key
        self._status_kwargs = kwargs
        self.status_message = self.tr(key, **kwargs)
        self.query_one("#settings-status", Static).update(self.status_message)

    def _set_path_limit_status(self, key: str, **kwargs) -> None:
        self._path_limit_status_key = key
        self._path_limit_status_kwargs = kwargs
        self.query_one("#settings-path-limit-status", Static).update(self.tr(key, **kwargs))

    def _log_settings_change(self, values: dict[str, object]) -> None:
        if not values:
            return
        try:
            logger = getattr(self.app, "log_event", None)
        except AttributeError:
            logger = None
        if logger is None:
            return
        details = ", ".join(f"{key} -> {value}" for key, value in values.items())
        logger("info", "settings", self.tr("settings.log.changed", details=details))

    def _record_feedback(self, action: str, phase: str, message: str, level: str = "info", **metadata) -> None:
        try:
            recorder = getattr(self.app, "record_feedback", None)
        except AttributeError:
            recorder = None
        if recorder is None:
            return
        recorder(
            source="settings",
            action=action,
            phase=phase,
            message=message,
            level=level,
            **metadata,
        )

    def refresh_text(self) -> None:
        super().refresh_text()
        self.query_one("#settings-tab-general", TabPane).title = self.tr("settings.tab.general")
        self.query_one("#settings-tab-storage", TabPane).title = self.tr("settings.tab.storage")
        self.query_one("#settings-tab-completion", TabPane).title = self.tr("settings.tab.completion")
        self.query_one("#settings-tab-dialogs", TabPane).title = self.tr("settings.tab.dialogs")
        self.query_one("#settings-tab-integration", TabPane).title = self.tr("settings.tab.integration")
        self.query_one("#settings-tab-notifications", TabPane).title = self.tr("settings.tab.notifications")
        self.query_one("#settings-tab-cli-environment", TabPane).title = self.tr("settings.tab.cli_environment")

        self.query_one("#settings-language-label", Static).update(self.tr("settings.general.language"))
        self.query_one("#settings-startup-page-label", Static).update(self.tr("settings.general.startup_page"))
        self.query_one("#settings-command-preview-label", Static).update(self.tr("settings.general.command_preview"))
        self.query_one("#settings-time-format-label", Static).update(self.tr("settings.general.time_format"))
        self.query_one("#settings-storage-root-label", Static).update(self.tr("settings.storage.root"))
        self.query_one("#settings-completion-enabled-label", Static).update(self.tr("settings.completion.enabled"))
        self.query_one("#settings-completion-recursive-label", Static).update(self.tr("settings.completion.recursive"))
        self.query_one("#settings-path-limit-label", Static).update(self.tr("settings.completion.limit"))
        self.query_one("#settings-gui-enabled-label", Static).update(self.tr("settings.dialogs.gui_enabled"))
        self.query_one("#settings-dialog-mode-label", Static).update(self.tr("settings.dialogs.mode"))
        self.query_one("#settings-browse-behavior-label", Static).update(self.tr("settings.dialogs.browse_behavior"))
        self.query_one("#settings-eip-executable-label", Static).update(self.tr("settings.integration.eip_executable"))
        self.query_one("#settings-cli-fallback-label", Static).update(self.tr("settings.integration.cli_fallback"))
        self.query_one("#settings-logs-refresh-label", Static).update(self.tr("settings.integration.logs_refresh"))
        self.query_one("#settings-notification-timeout-label", Static).update(self.tr("settings.notifications.timeout"))
        self.query_one("#settings-notification-max-visible-label", Static).update(self.tr("settings.notifications.max_visible"))
        self.query_one("#settings-notification-allow-stack-label", Static).update(self.tr("settings.notifications.allow_stack"))
        self.query_one("#settings-cli-group-base-label", Static).update(self.tr("settings.cli_environment.group.base"))
        self.query_one("#settings-cli-group-torch-label", Static).update(self.tr("settings.cli_environment.group.torch"))
        self.query_one("#settings-cli-group-nnunet-label", Static).update(self.tr("settings.cli_environment.group.nnunet"))
        self.query_one("#settings-cli-env-output-title", Static).update(self.tr("settings.cli_environment.terminal"))

        self.query_one("#settings-startup-page", Select).options = self._startup_page_options()
        self.query_one("#settings-time-format", Select).options = self._time_format_options()
        self.query_one("#settings-dialog-mode", Select).options = self._dialog_mode_options()
        self.query_one("#settings-browse-behavior", Select).options = self._browse_behavior_options()

        self.query_one("#settings-save-general", Button).label = self.tr("settings.action.save_general")
        self.query_one("#settings-save-storage", Button).label = self.tr("settings.action.save_storage")
        self.query_one("#settings-save-completion", Button).label = self.tr("settings.action.save_completion")
        self.query_one("#settings-save-dialogs", Button).label = self.tr("settings.action.save_dialogs")
        self.query_one("#settings-save-integration", Button).label = self.tr("settings.action.save_integration")
        self.query_one("#settings-save-notifications", Button).label = self.tr("settings.action.save_notifications")
        self.query_one("#settings-cli-env-check", Button).label = self.tr("settings.action.check_dependencies")
        self.query_one("#settings-cli-env-install", Button).label = self.tr("settings.action.install_dependencies")
        self.query_one("#settings-cli-env-cancel-install", Button).label = self.tr("settings.action.cancel_install")
        self.query_one("#settings-cli-env-uninstall-torch", Button).label = self.tr("settings.action.uninstall_torch")
        self.query_one("#settings-cli-env-uninstall-nnunet", Button).label = self.tr("settings.action.uninstall_nnunet")
        if self._status_key:
            self.status_message = self.tr(self._status_key, **self._status_kwargs)
        self.query_one("#settings-status", Static).update(self.status_message)
        if self._path_limit_status_key:
            self.query_one("#settings-path-limit-status", Static).update(
                self.tr(self._path_limit_status_key, **self._path_limit_status_kwargs)
            )
        self._refresh_cli_environment_widgets()
        self._refresh_cli_env_action_state()

    def _startup_page_options(self) -> list[tuple[str, str]]:
        return [
            (self.tr("page_execution"), "execution"),
            (self.tr("page_profiles"), "profiles"),
            (self.tr("page_settings"), "settings"),
            (self.tr("page_logs"), "logs"),
            (self.tr("page_cli_help"), "cli-help"),
        ]

    def _time_format_options(self) -> list[tuple[str, str]]:
        return [(self.tr("settings.option.time_format_24h"), "24h"), (self.tr("settings.option.time_format_12h"), "12h")]

    def _dialog_mode_options(self) -> list[tuple[str, str]]:
        return [
            (self.tr("settings.option.dialog_mode_prefer_gui"), "prefer_gui_fallback_tui"),
            (self.tr("settings.option.dialog_mode_gui_only"), "gui_only"),
            (self.tr("settings.option.dialog_mode_tui_only"), "tui_only"),
        ]

    def _browse_behavior_options(self) -> list[tuple[str, str]]:
        return [
            (self.tr("settings.option.browse_behavior_files_and_dirs"), "files_and_dirs"),
            (self.tr("settings.option.browse_behavior_directories"), "directories"),
            (self.tr("settings.option.browse_behavior_files"), "files"),
        ]
