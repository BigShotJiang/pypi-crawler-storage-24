from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, Input, Select, Static, Switch, TabbedContent, TabPane

from eip.config.models import CommandDefaults, CommandProfile, ProfilesState, WorkflowProfile
from eip.config.profile_exchange import export_profiles_json, import_profiles_json
from eip.config.storage import StorageManager
from eip.tui.layout import EipScreen
from eip.tui.pages.execution_forms import FieldSpec, make_field_specs
from eip.tui.widgets.path_input import PathInput

PROFILE_COMMANDS: tuple[tuple[str, str], ...] = (
    ("run", "full_run"),
    ("segment", "segment"),
    ("slice", "slice"),
    ("refine", "refine"),
    ("centroid", "centroid"),
    ("polar", "polar"),
)


class ProfilesScreen(EipScreen):
    DEFAULT_CSS = """
    #profiles-actions-panel,
    #profiles-workflow-panel,
    #profiles-command-panel {
        height: auto;
        margin-bottom: 1;
    }

    #profiles-mode-tabs,
    #profiles-workflow-tabs,
    #profiles-command-tabs {
        height: auto;
    }

    #profiles-mode-tabs > ContentSwitcher,
    #profiles-workflow-tabs > ContentSwitcher,
    #profiles-command-tabs > ContentSwitcher {
        height: auto;
    }

    #profiles-mode-tabs TabPane,
    #profiles-workflow-tabs TabPane,
    #profiles-command-tabs TabPane {
        height: auto;
        padding-top: 1;
    }

    .profiles-editor-pane {
        height: auto;
    }
    """

    page_key = "profiles"
    page_title_key = "page_profiles"
    page_subtitle_key = "profiles.subtitle"
    active_nav = "profiles"

    def __init__(self, profile_names: list[str] | None = None, storage_root: str | Path | None = None, **kwargs):
        super().__init__(**kwargs)
        self.storage_root = Path(storage_root) if storage_root is not None else Path.home() / ".eip"
        self.storage = StorageManager(root=self.storage_root, anchor_root=self.storage_root)
        self.profiles_state = self.storage.load_profiles_state()
        if profile_names is not None:
            self.profiles_state.workflow_profile_names = profile_names
        if not self.profiles_state.workflow_profile_names:
            self.profiles_state.workflow_profile_names = ["default"]
        self.active_mode = "workflow"
        self.active_workflow_profile = ""
        self.active_command_profile = ""
        self.active_workflow_profile = self._resolve_active_workflow_profile()
        self.active_command_mode = "run"
        self.active_command_profile = self._resolve_active_command_profile()
        self.status_message = ""
        self._status_key = ""
        self._status_kwargs: dict[str, object] = {}
        self._last_export_payload = ""

    def compose_body(self) -> ComposeResult:
        with Vertical(id="profiles-actions-panel", classes="panel"):
            yield Static(self.tr("profiles.panel.actions"), classes="panel-title", id="profiles-actions-title")
            yield Input(placeholder=self.tr("profiles.input.placeholder"), id="profiles-name-input")
            yield Select(self._command_mode_options(), value=self.active_command_mode, id="profiles-command-mode")
            with Horizontal(id="profiles-actions-row-primary", classes="action-row"):
                yield Button(self.tr("profiles.action.create"), id="profiles-create")
                yield Button(self.tr("profiles.action.rename"), id="profiles-rename")
                yield Button(self.tr("profiles.action.delete"), id="profiles-delete")
            with Horizontal(id="profiles-actions-row-secondary", classes="action-row"):
                yield Button(self.tr("profiles.action.set_default"), id="profiles-set-default")
                yield Button(self.tr("profiles.action.save_current"), id="profiles-save-current")
                yield Button(self.tr("profiles.action.import"), id="profiles-import")
            with Horizontal(id="profiles-actions-row-tertiary", classes="action-row"):
                yield Button(self.tr("profiles.action.export"), id="profiles-export")
            yield PathInput(
                id="profiles-json-path",
                base_path=self.storage_root,
                allowed_suffixes=(".json",),
                placeholder=self.tr("profiles.import.placeholder"),
            )
            yield Static(self.tr("profiles.helper"), id="profiles-body", classes="subtitle")
            yield Static(self.status_message or self.tr("profiles.status.idle"), id="profiles-status", classes="subtitle")
        with TabbedContent(id="profiles-mode-tabs", initial="profiles-tab-workflow"):
            with TabPane(self.tr("profiles.tab.workflow"), id="profiles-tab-workflow"):
                yield self._build_workflow_tabs()
            with TabPane(self.tr("profiles.tab.command"), id="profiles-tab-command"):
                yield self._build_command_tabs()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""
        if button_id.startswith("nav-"):
            super().on_button_pressed(event)
            return

        name = self.query_one("#profiles-name-input", Input).value.strip()
        if button_id == "profiles-create":
            if self.active_mode == "workflow":
                profile = self.create_workflow_profile(name)
            else:
                profile = self.create_command_profile(name, self.active_command_mode)
            self._set_status("profiles.status.created", profile=getattr(profile, "name", "")) if getattr(profile, "name", "") else self._set_status("profiles.status.invalid_name")
            self._record_feedback(
                "create_profile",
                "success" if getattr(profile, "name", "") else "noop",
                self.status_message,
                level="info" if getattr(profile, "name", "") else "warn",
                profile=getattr(profile, "name", ""),
            )
            await self._refresh_view()
            return
        if button_id == "profiles-rename":
            profile = self.rename_current_profile(name)
            self._set_status("profiles.status.renamed", profile=getattr(profile, "name", "")) if getattr(profile, "name", "") else self._set_status("profiles.status.invalid_name")
            self._record_feedback(
                "rename_profile",
                "success" if getattr(profile, "name", "") else "noop",
                self.status_message,
                level="info" if getattr(profile, "name", "") else "warn",
                profile=getattr(profile, "name", ""),
            )
            await self._refresh_view()
            return
        if button_id == "profiles-delete":
            deleted = self.current_profile_name()
            self.delete_current_profile()
            self._set_status("profiles.status.deleted", profile=deleted)
            self._record_feedback("delete_profile", "success", self.status_message, profile=deleted)
            await self._refresh_view()
            return
        if button_id == "profiles-set-default":
            self.set_default_workflow_profile(self.current_profile_name())
            self._set_status("profiles.status.default_set", profile=self.current_profile_name())
            self._record_feedback("set_default_profile", "success", self.status_message, profile=self.current_profile_name())
            self._update_status_widget()
            return
        if button_id == "profiles-save-current":
            self.save_current_profile()
            self._set_status("profiles.status.saved")
            self._record_feedback("save_current_profile", "success", self.status_message, profile=self.current_profile_name())
            self._update_status_widget()
            return
        if button_id == "profiles-export":
            self._record_feedback("export_profiles", "start", self.tr("profiles.action.export"), profile=self.current_profile_name())
            self._last_export_payload = export_profiles_json(self.profiles_state)
            json_path = self.query_one("#profiles-json-path", PathInput).value.strip()
            if json_path:
                export_path = self._resolve_export_path(Path(json_path))
                export_path.write_text(self._last_export_payload, encoding="utf-8")
            self._set_status("profiles.status.exported")
            self._record_feedback("export_profiles", "success", self.status_message, profile=self.current_profile_name())
            self._update_status_widget()
            return
        if button_id == "profiles-import":
            self._record_feedback("import_profiles", "start", self.tr("profiles.action.import"))
            json_path = self.query_one("#profiles-json-path", PathInput).value.strip()
            payload = Path(json_path).read_text(encoding="utf-8") if json_path else ""
            try:
                self.profiles_state = import_profiles_json(payload)
            except ValueError as exc:
                self._set_status("profiles.status.import_failed", error=str(exc))
                self._record_feedback("import_profiles", "error", self.status_message, level="error", error=str(exc))
                self._update_status_widget()
                return
            self.active_workflow_profile = self._resolve_active_workflow_profile()
            self.active_command_profile = self._resolve_active_command_profile()
            self._persist_profiles()
            self._set_status("profiles.status.imported")
            self._record_feedback("import_profiles", "success", self.status_message)
            await self._refresh_view()
            return

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.select.id == "profiles-command-mode":
            self.active_command_mode = str(event.value)
            self.active_command_profile = self._resolve_active_command_profile()
            if self.is_mounted:
                self.call_after_refresh(self._schedule_tabs_rebuild)
            return
        self._refresh_dynamic_field_visibility()

    def on_screen_resume(self) -> None:
        self.reload_profiles_state()

    def on_tabbed_content_tab_activated(self, event: TabbedContent.TabActivated) -> None:
        if event.tabbed_content.id == "profiles-mode-tabs":
            self.active_mode = "workflow" if event.pane.id == "profiles-tab-workflow" else "command"
            return
        if event.tabbed_content.id == "profiles-workflow-tabs":
            profile_name = self._workflow_name_from_tab_id(event.pane.id or "")
            if profile_name is not None:
                self.active_workflow_profile = profile_name
                self._set_status("profiles.status.selected", profile=profile_name)
                self._update_status_widget()
            return
        if event.tabbed_content.id == "profiles-command-tabs":
            profile_name = self._command_name_from_tab_id(event.pane.id or "")
            if profile_name is not None:
                self.active_command_profile = profile_name
                self._set_status("profiles.status.selected", profile=profile_name)
                self._update_status_widget()

    def create_workflow_profile(self, name: str) -> WorkflowProfile:
        sanitized = name.strip()
        if not sanitized or sanitized in self.profiles_state.workflow_profile_names:
            return WorkflowProfile(name="")
        profile = WorkflowProfile(name=sanitized)
        self.profiles_state.workflow_profile_names.append(sanitized)
        self.profiles_state.workflow_profiles[sanitized] = profile
        self.active_workflow_profile = sanitized
        self._persist_profiles()
        return profile

    def create_command_profile(self, name: str, command: str) -> CommandProfile:
        sanitized = name.strip()
        if not sanitized or sanitized in self.profiles_state.command_profile_names:
            return CommandProfile(name="", command=command)
        profile = CommandProfile(name=sanitized, command=command)
        self.profiles_state.command_profile_names.append(sanitized)
        self.profiles_state.command_profiles[sanitized] = profile
        self.active_command_profile = sanitized
        self._persist_profiles()
        return profile

    def rename_current_profile(self, new_name: str):
        sanitized = new_name.strip()
        if not sanitized:
            return WorkflowProfile(name="") if self.active_mode == "workflow" else CommandProfile(name="", command=self.active_command_mode)
        if self.active_mode == "workflow":
            old_name = self.active_workflow_profile
            if old_name not in self.profiles_state.workflow_profile_names or (sanitized != old_name and sanitized in self.profiles_state.workflow_profile_names):
                return WorkflowProfile(name="")
            profile = self.profiles_state.workflow_profiles.pop(old_name, WorkflowProfile(name=old_name))
            updated = WorkflowProfile(name=sanitized, description=profile.description, commands=profile.commands)
            self.profiles_state.workflow_profile_names = [sanitized if name == old_name else name for name in self.profiles_state.workflow_profile_names]
            self.profiles_state.workflow_profiles[sanitized] = updated
            if self.profiles_state.default_workflow_profile == old_name:
                self.profiles_state.default_workflow_profile = sanitized
            self.active_workflow_profile = sanitized
            self._persist_profiles()
            return updated
        old_name = self.active_command_profile
        if old_name not in self.profiles_state.command_profile_names or (sanitized != old_name and sanitized in self.profiles_state.command_profile_names):
            return CommandProfile(name="", command=self.active_command_mode)
        profile = self.profiles_state.command_profiles.pop(old_name, CommandProfile(name=old_name, command=self.active_command_mode))
        updated = CommandProfile(name=sanitized, command=profile.command, description=profile.description, values=profile.values)
        self.profiles_state.command_profile_names = [sanitized if name == old_name else name for name in self.profiles_state.command_profile_names]
        self.profiles_state.command_profiles[sanitized] = updated
        self.active_command_profile = sanitized
        self._persist_profiles()
        return updated

    def delete_current_profile(self) -> None:
        if self.active_mode == "workflow":
            name = self.active_workflow_profile
            if name not in self.profiles_state.workflow_profile_names:
                return
            remaining = [item for item in self.profiles_state.workflow_profile_names if item != name]
            if not remaining:
                return
            self.profiles_state.workflow_profile_names = remaining
            self.profiles_state.workflow_profiles.pop(name, None)
            if self.profiles_state.default_workflow_profile == name:
                self.profiles_state.default_workflow_profile = remaining[0]
            self.active_workflow_profile = self._resolve_active_workflow_profile()
            self._persist_profiles()
            return
        name = self.active_command_profile
        if name not in self.profiles_state.command_profile_names:
            return
        self.profiles_state.command_profile_names = [item for item in self.profiles_state.command_profile_names if item != name]
        self.profiles_state.command_profiles.pop(name, None)
        self.active_command_profile = self._resolve_active_command_profile()
        self._persist_profiles()

    def set_default_workflow_profile(self, name: str) -> None:
        if name in self.profiles_state.workflow_profile_names:
            self.profiles_state.default_workflow_profile = name
            self.active_workflow_profile = name
            self._persist_profiles()

    def save_current_profile(self) -> None:
        if self.active_mode == "workflow":
            name = self.active_workflow_profile
            if name not in self.profiles_state.workflow_profile_names:
                return
            profile = self.profiles_state.workflow_profiles.setdefault(name, WorkflowProfile(name=name))
            commands: dict[str, CommandDefaults] = {}
            for command_name, _workflow_key in PROFILE_COMMANDS:
                values = self._collect_workflow_command_values(name, command_name)
                if values:
                    commands[command_name] = CommandDefaults(values=values)
            profile.commands = commands
            self.profiles_state.workflow_profiles[name] = profile
        else:
            name = self.active_command_profile
            if name not in self.profiles_state.command_profile_names:
                return
            values = self._collect_command_profile_values(name, self.active_command_mode)
            self.profiles_state.command_profiles[name] = CommandProfile(
                name=name,
                command=self.active_command_mode,
                values=values,
            )
        self._persist_profiles()

    def current_profile_name(self) -> str:
        return self.active_workflow_profile if self.active_mode == "workflow" else self.active_command_profile

    def refresh_text(self) -> None:
        super().refresh_text()
        self.query_one("#profiles-actions-title", Static).update(self.tr("profiles.panel.actions"))
        self.query_one("#profiles-name-input", Input).placeholder = self.tr("profiles.input.placeholder")
        self.query_one("#profiles-create", Button).label = self.tr("profiles.action.create")
        self.query_one("#profiles-rename", Button).label = self.tr("profiles.action.rename")
        self.query_one("#profiles-delete", Button).label = self.tr("profiles.action.delete")
        self.query_one("#profiles-set-default", Button).label = self.tr("profiles.action.set_default")
        self.query_one("#profiles-save-current", Button).label = self.tr("profiles.action.save_current")
        self.query_one("#profiles-import", Button).label = self.tr("profiles.action.import")
        self.query_one("#profiles-export", Button).label = self.tr("profiles.action.export")
        json_path = self.query_one("#profiles-json-path", PathInput)
        json_path.placeholder = self.tr("profiles.import.placeholder")
        json_path.refresh_text()
        self.query_one("#profiles-body", Static).update(self.tr("profiles.helper"))
        self.query_one("#profiles-tab-workflow", TabPane).title = self.tr("profiles.tab.workflow")
        self.query_one("#profiles-tab-command", TabPane).title = self.tr("profiles.tab.command")
        self.query_one("#profiles-command-mode", Select).options = self._command_mode_options()
        self._update_status_widget()
        if self.is_mounted:
            self.call_after_refresh(self._schedule_tabs_rebuild)

    def _build_workflow_tabs(self) -> TabbedContent:
        initial = self._workflow_tab_id(self.active_workflow_profile) if self.active_workflow_profile else ""
        tabs = TabbedContent(initial=initial, id="profiles-workflow-tabs")
        for profile_name in self.profiles_state.workflow_profile_names:
            tabs.compose_add_child(self._build_workflow_pane(profile_name))
        return tabs

    def _build_command_tabs(self) -> TabbedContent:
        initial = self._command_tab_id(self.active_command_profile) if self.active_command_profile else ""
        tabs = TabbedContent(initial=initial, id="profiles-command-tabs")
        names = self._command_profiles_for_mode(self.active_command_mode)
        if not names:
            tabs.compose_add_child(
                TabPane(
                    self.tr("profiles.empty"),
                    Static(self.tr("profiles.command.empty"), id="profiles-command-empty", classes="subtitle"),
                    id="profiles-command-empty-tab",
                )
            )
            return tabs
        for profile_name in names:
            tabs.compose_add_child(self._build_command_pane(profile_name))
        return tabs

    def _build_workflow_pane(self, profile_name: str) -> TabPane:
        children = [Static(self._workflow_summary(profile_name), classes="subtitle")]
        profile = self.profiles_state.workflow_profiles.get(profile_name, WorkflowProfile(name=profile_name))
        for command_name, workflow_key in PROFILE_COMMANDS:
            children.append(Static(self.tr(f"execution.workflow.{workflow_key}.label"), classes="section-title"))
            command_values = profile.commands.get(command_name, CommandDefaults()).values
            for field in make_field_specs(self._workflow_prefix(profile_name, command_name), command_name, values=command_values):
                children.append(Static(self.tr(field.label_key), id=f"{field.field_id}-label", classes="subtitle"))
                children.append(self._make_field_widget(field))
        return TabPane(
            profile_name,
            Vertical(*children, id=f"{self._workflow_tab_id(profile_name)}-pane", classes="panel profiles-editor-pane"),
            id=self._workflow_tab_id(profile_name),
        )

    def _build_command_pane(self, profile_name: str) -> TabPane:
        profile = self.profiles_state.command_profiles.get(profile_name, CommandProfile(name=profile_name, command=self.active_command_mode))
        children = [Static(profile.name, classes="subtitle")]
        for field in make_field_specs(self._command_prefix(profile_name, profile.command), profile.command, values=profile.values):
            children.append(Static(self.tr(field.label_key), id=f"{field.field_id}-label", classes="subtitle"))
            children.append(self._make_field_widget(field))
        return TabPane(
            profile_name,
            Vertical(*children, id=f"{self._command_tab_id(profile_name)}-pane", classes="panel profiles-editor-pane"),
            id=self._command_tab_id(profile_name),
        )

    def _make_field_widget(self, field: FieldSpec):
        if field.widget_type == "path":
            return PathInput(
                id=field.field_id,
                base_path=self.storage_root,
                placeholder=self.tr(field.placeholder_key) if field.placeholder_key else "",
                value=field.value,
            )
        if field.widget_type == "select":
            return Select(list(field.options), value=field.value, id=field.field_id)
        if field.widget_type == "switch":
            return Switch(value=field.value.lower() in {"1", "true", "yes", "on"}, id=field.field_id)
        return Input(
            value=field.value,
            id=field.field_id,
            placeholder=self.tr(field.placeholder_key) if field.placeholder_key else "",
        )

    def _collect_workflow_command_values(self, profile_name: str, command_name: str) -> dict[str, str]:
        values: dict[str, str] = {}
        for field in make_field_specs(self._workflow_prefix(profile_name, command_name), command_name):
            widget = self.query_one(f"#{field.field_id}")
            raw_value = self._widget_value(widget)
            if raw_value:
                values[field.value_key] = raw_value
        return values

    def _collect_command_profile_values(self, profile_name: str, command_name: str) -> dict[str, str]:
        values: dict[str, str] = {}
        for field in make_field_specs(self._command_prefix(profile_name, command_name), command_name):
            widget = self.query_one(f"#{field.field_id}")
            raw_value = self._widget_value(widget)
            if raw_value:
                values[field.value_key] = raw_value
        return values

    def _widget_value(self, widget) -> str:
        if isinstance(widget, PathInput):
            return widget.value.strip()
        if isinstance(widget, Select):
            return "" if widget.value == Select.BLANK else str(widget.value)
        if isinstance(widget, Switch):
            return "true" if widget.value else ""
        return getattr(widget, "value", "").strip()

    def _persist_profiles(self) -> None:
        self.storage.save_profiles_state(self.profiles_state)
        self._notify_execution_screen()

    def reload_profiles_state(self) -> None:
        self.profiles_state = self.storage.load_profiles_state()
        self.active_workflow_profile = self._resolve_active_workflow_profile()
        self.active_command_profile = self._resolve_active_command_profile()
        if self.is_mounted:
            self._update_status_widget()

    async def _refresh_view(self) -> None:
        self._update_status_widget()
        await self._rebuild_profile_tabs()

    async def _rebuild_profile_tabs(self) -> None:
        try:
            workflow_tabs = self.query_one("#profiles-workflow-tabs", TabbedContent)
            await workflow_tabs.clear_panes()
            for profile_name in self.profiles_state.workflow_profile_names:
                await workflow_tabs.add_pane(self._build_workflow_pane(profile_name))
            workflow_tabs.active = self._workflow_tab_id(self._resolve_active_workflow_profile())
        except Exception:
            pass
        self._refresh_dynamic_field_visibility()
        try:
            command_tabs = self.query_one("#profiles-command-tabs", TabbedContent)
            await command_tabs.clear_panes()
            names = self._command_profiles_for_mode(self.active_command_mode)
            if not names:
                await command_tabs.add_pane(
                    TabPane(
                        self.tr("profiles.empty"),
                        Static(self.tr("profiles.command.empty"), id="profiles-command-empty", classes="subtitle"),
                        id="profiles-command-empty-tab",
                    )
                )
            else:
                for profile_name in names:
                    await command_tabs.add_pane(self._build_command_pane(profile_name))
                command_tabs.active = self._command_tab_id(self._resolve_active_command_profile())
        except Exception:
            pass

    def _schedule_tabs_rebuild(self) -> None:
        asyncio.create_task(self._rebuild_profile_tabs())

    def _resolve_export_path(self, raw_path: Path) -> Path:
        if raw_path.exists() and raw_path.is_dir():
            return raw_path / f"{self.current_profile_name()}-{self._current_mode_suffix()}.json"
        if raw_path.suffix.lower() == ".json":
            return raw_path
        if raw_path.exists() and raw_path.is_file():
            return raw_path
        if raw_path.suffix:
            return raw_path
        return raw_path / f"{self.current_profile_name()}-{self._current_mode_suffix()}.json"

    def _current_mode_suffix(self) -> str:
        if self.active_mode == "workflow":
            return "workflow"
        return self.active_command_mode

    def _notify_execution_screen(self) -> None:
        try:
            execution_screen = self.app.get_screen("execution")
        except Exception:
            return
        refresher = getattr(execution_screen, "refresh_profile_sources", None)
        if refresher is None:
            return
        refresher()

    def _refresh_dynamic_field_visibility(self) -> None:
        for profile_name in self.profiles_state.workflow_profile_names:
            for command_name, _workflow_key in PROFILE_COMMANDS:
                self._refresh_fields_for_prefix(self._workflow_prefix(profile_name, command_name), command_name)
        for profile_name in self._command_profiles_for_mode(self.active_command_mode):
            self._refresh_fields_for_prefix(self._command_prefix(profile_name, self.active_command_mode), self.active_command_mode)

    def _refresh_fields_for_prefix(self, prefix: str, command_name: str) -> None:
        try:
            values = self._collect_values_for_prefix(prefix, command_name)
        except Exception:
            return
        for field in make_field_specs(prefix, command_name):
            visible = self._matches_rule(field.visible_when, values)
            display = "block" if visible else "none"
            try:
                self.query_one(f"#{field.field_id}-label", Static).styles.display = display
                self.query_one(f"#{field.field_id}").styles.display = display
            except Exception:
                continue

    def _collect_values_for_prefix(self, prefix: str, command_name: str) -> dict[str, str]:
        values: dict[str, str] = {}
        for field in make_field_specs(prefix, command_name):
            widget = self.query_one(f"#{field.field_id}")
            raw_value = self._widget_value(widget)
            if raw_value:
                values[field.value_key] = raw_value
        return values

    def _matches_rule(self, rule: str | None, values: dict[str, str]) -> bool:
        if not rule:
            return True
        for condition in rule.split(","):
            key, _, expected = condition.partition("=")
            if values.get(key.strip()) != expected.strip():
                return False
        return True

    def _resolve_active_workflow_profile(self) -> str:
        if self.active_workflow_profile in self.profiles_state.workflow_profile_names:
            return self.active_workflow_profile
        if self.profiles_state.default_workflow_profile in self.profiles_state.workflow_profile_names:
            return self.profiles_state.default_workflow_profile
        if self.profiles_state.workflow_profile_names:
            return self.profiles_state.workflow_profile_names[0]
        self.profiles_state.workflow_profile_names = ["default"]
        self.profiles_state.workflow_profiles.setdefault("default", WorkflowProfile(name="default"))
        self.profiles_state.default_workflow_profile = "default"
        return "default"

    def _resolve_active_command_profile(self) -> str:
        names = self._command_profiles_for_mode(self.active_command_mode)
        if self.active_command_profile in names:
            return self.active_command_profile
        return names[0] if names else ""

    def _command_profiles_for_mode(self, command_name: str) -> list[str]:
        return [
            name
            for name in self.profiles_state.command_profile_names
            if self.profiles_state.command_profiles.get(name, CommandProfile(name=name, command="")).command == command_name
        ]

    def _update_status_widget(self) -> None:
        if self._status_key:
            self.status_message = self.tr(self._status_key, **self._status_kwargs)
        self.query_one("#profiles-status", Static).update(self.status_message or self.tr("profiles.status.idle"))

    def _set_status(self, key: str, **kwargs) -> None:
        self._status_key = key
        self._status_kwargs = kwargs
        self.status_message = self.tr(key, **kwargs)

    def _record_feedback(self, action: str, phase: str, message: str, level: str = "info", **metadata) -> None:
        try:
            recorder = getattr(self.app, "record_feedback", None)
        except AttributeError:
            recorder = None
        if recorder is None:
            return
        recorder(
            source="profiles",
            action=action,
            phase=phase,
            message=message,
            level=level,
            **metadata,
        )

    def _workflow_summary(self, profile_name: str) -> str:
        key = "profiles.summary.default" if profile_name == self.profiles_state.default_workflow_profile else "profiles.summary.standard"
        return self.tr(key, profile=profile_name)

    def _workflow_tab_id(self, profile_name: str) -> str:
        digest = hashlib.sha1(f"workflow:{profile_name}".encode("utf-8")).hexdigest()[:8]
        return f"profiles-workflow-tab-{digest}"

    def _command_tab_id(self, profile_name: str) -> str:
        digest = hashlib.sha1(f"command:{profile_name}".encode("utf-8")).hexdigest()[:8]
        return f"profiles-command-tab-{digest}"

    def _workflow_name_from_tab_id(self, tab_id: str) -> str | None:
        for profile_name in self.profiles_state.workflow_profile_names:
            if self._workflow_tab_id(profile_name) == tab_id:
                return profile_name
        return None

    def _command_name_from_tab_id(self, tab_id: str) -> str | None:
        for profile_name in self._command_profiles_for_mode(self.active_command_mode):
            if self._command_tab_id(profile_name) == tab_id:
                return profile_name
        return None

    def _workflow_prefix(self, profile_name: str, command_name: str) -> str:
        return f"{self._workflow_tab_id(profile_name)}-{command_name}"

    def _command_prefix(self, profile_name: str, command_name: str) -> str:
        return f"{self._command_tab_id(profile_name)}-{command_name}"

    def _workflow_field_id(self, profile_name: str, command_name: str, value_key: str) -> str:
        for field in make_field_specs(self._workflow_prefix(profile_name, command_name), command_name):
            if field.value_key == value_key:
                return field.field_id
        raise KeyError(value_key)

    def _command_field_id(self, profile_name: str, command_name: str, value_key: str) -> str:
        for field in make_field_specs(self._command_prefix(profile_name, command_name), command_name):
            if field.value_key == value_key:
                return field.field_id
        raise KeyError(value_key)

    def _command_mode_options(self) -> list[tuple[str, str]]:
        return [(self.tr(f"execution.workflow.{workflow_key}.label"), command_name) for command_name, workflow_key in PROFILE_COMMANDS]
