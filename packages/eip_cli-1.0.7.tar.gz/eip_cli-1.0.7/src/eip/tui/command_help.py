from __future__ import annotations

from dataclasses import dataclass


FIELD_LABELS = {
    "input": "Input Path",
    "input_path": "Input Path",
    "input_dir": "Input Directory",
    "output": "Output Directory",
    "seg_mode": "Segmentation Mode",
    "model_path": "Model Path",
    "seg_input": "Segmentation Input",
    "nnunet_source": "nnU-Net Source",
    "nnunet_dataset": "nnU-Net Dataset",
    "nnunet_config": "nnU-Net Configuration",
    "nnunet_model_dir": "nnU-Net Model Directory",
    "nnunet_folds": "nnU-Net Folds",
    "nnunet_checkpoint": "nnU-Net Checkpoint",
    "axis": "Axis",
    "all": "All Slices",
    "count": "Slice Count",
    "png": "Raw PNG",
    "data": "Sample Data Directory",
    "ring_width": "Ring Width",
    "polar_width": "Polar Width",
}


@dataclass(frozen=True)
class CommandScenario:
    key: str
    title: str
    required_fields: tuple[str, ...]
    optional_fields: tuple[str, ...]
    summary_template: str
    examples: tuple[str, ...]
    common_errors: tuple[tuple[str, str, str], ...]


RUN_SCENARIOS = {
    "builtin-unet": CommandScenario(
        key="builtin-unet",
        title="Built-in U-Net",
        required_fields=("input",),
        optional_fields=("axis", "all", "count", "png", "ring_width", "polar_width", "output"),
        summary_template="Mode: Built-in U-Net\nRequired: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip run --input-dir "/data" --seg-mode builtin-unet --axis 1 --all --count 5 --png --ring-width 8 --polar-width 368 --output "/out"',),
        common_errors=(),
    ),
    "custom-unet": CommandScenario(
        key="custom-unet",
        title="Custom U-Net",
        required_fields=("input", "model_path"),
        optional_fields=("axis", "all", "count", "png", "ring_width", "polar_width", "output"),
        summary_template="Mode: Custom U-Net\nRequired: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip run --input-dir "/data" --seg-mode custom-unet --model-path "/models/model.pth" --all --count 5 --ring-width 8 --polar-width 368 --output "/out"',),
        common_errors=((
            "model-path is required when seg-mode is custom-unet",
            "custom-unet needs a PyTorch checkpoint file path",
            "add --model-path /path/to/model.pth",
        ),),
    ),
    "existing-seg": CommandScenario(
        key="existing-seg",
        title="Existing Segmentation",
        required_fields=("input", "seg_input"),
        optional_fields=("axis", "all", "count", "png", "ring_width", "polar_width", "output"),
        summary_template="Mode: Existing Segmentation\nRequired: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip run --input-dir "/data" --seg-mode existing-seg --seg-input "/data/case.seg.nrrd" --all --count 5 --ring-width 8 --polar-width 368 --output "/out"',),
        common_errors=(),
    ),
    "nnunetv2:registry": CommandScenario(
        key="nnunetv2:registry",
        title="nnU-Net v2 Registry",
        required_fields=("input", "nnunet_dataset", "nnunet_config"),
        optional_fields=("axis", "all", "count", "png", "nnunet_folds", "nnunet_checkpoint", "ring_width", "polar_width", "output"),
        summary_template="Mode: nnU-Net v2 (Registry)\nRequired: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip run --input-dir "/data" --seg-mode nnunetv2 --nnunet-source registry --nnunet-dataset Dataset001 --nnunet-config 3d_fullres --all --count 5 --ring-width 8 --polar-width 368 --output "/out"',),
        common_errors=(),
    ),
    "nnunetv2:model-dir": CommandScenario(
        key="nnunetv2:model-dir",
        title="nnU-Net v2 Model Directory",
        required_fields=("input", "nnunet_model_dir"),
        optional_fields=("axis", "all", "count", "png", "nnunet_folds", "nnunet_checkpoint", "ring_width", "polar_width", "output"),
        summary_template="Mode: nnU-Net v2 (Model Directory)\nRequired: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip run --input-dir "/data" --seg-mode nnunetv2 --nnunet-source model-dir --nnunet-model-dir "/models/nnunet" --all --count 5 --ring-width 8 --polar-width 368 --output "/out"',),
        common_errors=(),
    ),
}


SIMPLE_SCENARIOS = {
    "segment": CommandScenario(
        key="segment",
        title="Segment",
        required_fields=("input",),
        optional_fields=("output",),
        summary_template="Required: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip segment --input "/data/case.nrrd" --output "/out"',),
        common_errors=(),
    ),
    "slice": CommandScenario(
        key="slice",
        title="Slice",
        required_fields=("input",),
        optional_fields=("output",),
        summary_template="Required: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip slice --input "/data/case.nrrd" --output "/out"',),
        common_errors=(),
    ),
    "refine": CommandScenario(
        key="refine",
        title="Refine",
        required_fields=("input",),
        optional_fields=("output",),
        summary_template="Required: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip refine --input "/data/case.nrrd" --output "/out"',),
        common_errors=(),
    ),
    "centroid": CommandScenario(
        key="centroid",
        title="Centroid",
        required_fields=("input",),
        optional_fields=("output",),
        summary_template="Required: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip centroid --input "/data/case.nrrd" --output "/out"',),
        common_errors=(),
    ),
    "polar": CommandScenario(
        key="polar",
        title="Polar",
        required_fields=("input",),
        optional_fields=("data", "axis", "all", "count", "png", "ring_width", "polar_width", "output"),
        summary_template="Required: {required}\nOptional: {optional}\n{missing_line}",
        examples=('eip polar --input "/data/case.label.nrrd" --data "/samples" --axis 1 --all --count 5 --png --ring-width 12 --polar-width 368 --output "/out"',),
        common_errors=((
            "unable to locate a paired image volume for the provided mask input; use --data to specify the sample data directory",
            "polar needs a paired image file when input is a label or segmentation volume",
            'rerun with --data "/path/to/sample-data" or provide an image input directly',
        ),),
    ),
}


HELP_COMMAND_ORDER = ("run", "segment", "slice", "refine", "centroid", "polar", "doctor")


def field_label(key: str) -> str:
    return FIELD_LABELS.get(key, key.replace("_", " ").title())


def normalize_missing_fields(required_fields: tuple[str, ...], values: dict[str, str]) -> tuple[str, ...]:
    missing: list[str] = []
    for field in required_fields:
        if field == "input":
            if values.get("input_path") or values.get("input_dir"):
                continue
        elif values.get(field):
            continue
        missing.append(field_label(field))
    return tuple(missing)


def scenario_for_command(command: str, values: dict[str, str]) -> CommandScenario:
    if command == "run":
        seg_mode = values.get("seg_mode", "builtin-unet")
        if seg_mode == "nnunetv2":
            source = values.get("nnunet_source", "registry")
            return RUN_SCENARIOS[f"nnunetv2:{source}"]
        return RUN_SCENARIOS[seg_mode]
    if command == "segment" and values.get("seg_mode"):
        seg_mode = values.get("seg_mode", "builtin-unet")
        if seg_mode == "nnunetv2":
            source = values.get("nnunet_source", "registry")
            return RUN_SCENARIOS[f"nnunetv2:{source}"]
        return RUN_SCENARIOS[seg_mode]
    return SIMPLE_SCENARIOS[command]


def scenario_summary(command: str, values: dict[str, str], missing_labels: tuple[str, ...]) -> str:
    scenario = scenario_for_command(command, values)
    required = ", ".join(field_label(field) for field in scenario.required_fields)
    optional = ", ".join(field_label(field) for field in scenario.optional_fields) or "None"
    missing_line = f"Missing: {', '.join(missing_labels)}" if missing_labels else "Missing: None"
    return scenario.summary_template.format(required=required, optional=optional, missing_line=missing_line)
