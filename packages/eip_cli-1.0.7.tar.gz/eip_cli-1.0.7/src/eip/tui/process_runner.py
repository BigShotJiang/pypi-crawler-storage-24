from __future__ import annotations

import asyncio
import inspect
import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Callable, Awaitable

from eip.tui.pages.logs import LogEntry, LogStore


@dataclass(slots=True)
class ProcessResult:
    argv: list[str]
    exit_code: int
    stdout_text: str
    stderr_text: str


class ProcessRunner:
    def __init__(self, log_dir: Path, log_store: LogStore | None = None):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_store = log_store
        self._process: asyncio.subprocess.Process | None = None

    async def run(self, argv: list[str]) -> ProcessResult:
        result = await self.run_stream(argv, record_live_logs=False)
        self._append_log_entries(result)
        return result

    async def run_stream(
        self,
        argv: list[str],
        on_output: Callable[[str, str], object] | None = None,
        record_live_logs: bool = True,
    ) -> ProcessResult:
        self._process = await asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout_chunks: list[str] = []
        stderr_chunks: list[str] = []

        async def read_stream(stream_name: str, buffer: list[str], stream: asyncio.StreamReader | None) -> None:
            if stream is None:
                return
            pending = ""
            while True:
                chunk = await stream.read(1024)
                if not chunk:
                    break
                pending += chunk.decode()
                pending = await self._flush_stream_chunks(
                    stream_name,
                    buffer,
                    pending,
                    on_output,
                    record_live_logs,
                )
            if pending:
                buffer.append(pending)
                await self._emit_output(stream_name, pending, on_output, record_live_logs)

        await asyncio.gather(
            read_stream("stdout", stdout_chunks, self._process.stdout),
            read_stream("stderr", stderr_chunks, self._process.stderr),
        )
        exit_code = await self._process.wait()
        result = ProcessResult(
            argv=argv,
            exit_code=exit_code,
            stdout_text="".join(stdout_chunks),
            stderr_text="".join(stderr_chunks),
        )
        self._process = None
        self._write_event(result)
        return result

    async def _flush_stream_chunks(
        self,
        stream_name: str,
        buffer: list[str],
        pending: str,
        on_output: Callable[[str, str], object] | None,
        record_live_logs: bool,
    ) -> str:
        start = 0
        index = 0
        pending_length = len(pending)
        while index < pending_length:
            char = pending[index]
            if char not in "\r\n":
                index += 1
                continue
            end = index + 1
            if char == "\r" and end < pending_length and pending[end] == "\n":
                end += 1
            text = pending[start:end]
            buffer.append(text)
            await self._emit_output(stream_name, text, on_output, record_live_logs)
            start = end
            index = end
        return pending[start:]

    def cancel(self) -> bool:
        if self._process is None or self._process.returncode is not None:
            return False
        self._process.terminate()
        return True

    def _write_event(self, result: ProcessResult) -> None:
        event_path = self.log_dir / "events.jsonl"
        event = {
            "argv": result.argv,
            "exit_code": result.exit_code,
            "stdout": result.stdout_text,
            "stderr": result.stderr_text,
        }
        with event_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, ensure_ascii=False) + "\n")

    def _append_log_entries(self, result: ProcessResult) -> None:
        if self.log_store is None:
            return
        for line in result.stdout_text.splitlines():
            if line:
                self.log_store.append(
                    LogEntry(timestamp=datetime.now(UTC), level="info", source="process", message=line)
                )
        for line in result.stderr_text.splitlines():
            if line:
                self.log_store.append(
                    LogEntry(timestamp=datetime.now(UTC), level="error", source="process", message=line)
                )

    async def _emit_output(
        self,
        stream_name: str,
        text: str,
        on_output: Callable[[str, str], object] | None,
        record_live_logs: bool,
    ) -> None:
        if on_output is not None:
            maybe_result = on_output(stream_name, text)
            if inspect.isawaitable(maybe_result):
                await maybe_result
        if self.log_store is None or not record_live_logs:
            return
        level = "info" if stream_name == "stdout" else "error"
        for line in text.splitlines():
            if line:
                self.log_store.append(
                    LogEntry(timestamp=datetime.now(UTC), level=level, source="process", message=line)
                )
