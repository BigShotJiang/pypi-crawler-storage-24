#!/usr/bin/env python
"""
Test script to preview the AskUserQuestion UI with different question formats.

Usage:
    uv run python test_ask_user_ui.py
"""

import asyncio
from pathlib import Path

from src.reverse_api.engineer import ClaudeEngineer


async def test_single_select_with_descriptions():
    """Test single-select question with descriptions."""
    print("\n" + "=" * 70)
    print("TEST 1: Single-Select Question with Descriptions")
    print("=" * 70)

    engineer = ClaudeEngineer(
        run_id="test",
        har_path=Path("/tmp/test.har"),
        prompt="test",
        model="claude-sonnet-4-5",
    )

    input_params = {
        "questions": [
            {
                "question": "Which authentication method should I implement?",
                "header": "Authentication Method",
                "options": [
                    {
                        "label": "Cookie-based session",
                        "description": "Uses session cookies stored in browser",
                    },
                    {
                        "label": "Bearer token",
                        "description": "Uses JWT or API tokens in Authorization header",
                    },
                    {
                        "label": "Both methods",
                        "description": "Auto-detect and support both authentication types",
                    },
                ],
                "multiSelect": False,
            }
        ]
    }

    result = await engineer._handle_ask_user_question("AskUserQuestion", input_params)
    print(f"\nResult: {result}")


async def test_multi_select_with_descriptions():
    """Test multi-select question with descriptions."""
    print("\n" + "=" * 70)
    print("TEST 2: Multi-Select Question with Descriptions")
    print("=" * 70)

    engineer = ClaudeEngineer(
        run_id="test",
        har_path=Path("/tmp/test.har"),
        prompt="test",
        model="claude-sonnet-4-5",
    )

    input_params = {
        "questions": [
            {
                "question": "Which features should I include in the API client?",
                "header": "Feature Selection",
                "options": [
                    {
                        "label": "Automatic retry logic",
                        "description": "Retry failed requests with exponential backoff",
                    },
                    {
                        "label": "Rate limiting",
                        "description": "Throttle requests to respect API limits",
                    },
                    {
                        "label": "Response caching",
                        "description": "Cache responses to reduce API calls",
                    },
                    {
                        "label": "Detailed logging",
                        "description": "Add comprehensive debug logging",
                    },
                ],
                "multiSelect": True,
            }
        ]
    }

    result = await engineer._handle_ask_user_question("AskUserQuestion", input_params)
    print(f"\nResult: {result}")


async def test_multiple_questions():
    """Test multiple questions in one call."""
    print("\n" + "=" * 70)
    print("TEST 3: Multiple Questions in One Call")
    print("=" * 70)

    engineer = ClaudeEngineer(
        run_id="test",
        har_path=Path("/tmp/test.har"),
        prompt="test",
        model="claude-sonnet-4-5",
    )

    input_params = {
        "questions": [
            {
                "question": "Which authentication method?",
                "header": "Auth",
                "options": [
                    {"label": "Cookies", "description": "Session-based authentication"},
                    {"label": "Tokens", "description": "Token-based authentication"},
                ],
                "multiSelect": False,
            },
            {
                "question": "Should I implement retry logic?",
                "header": "Error Handling",
                "options": [
                    {
                        "label": "Yes",
                        "description": "Auto-retry with exponential backoff",
                    },
                    {"label": "No", "description": "Fail immediately on errors"},
                ],
                "multiSelect": False,
            },
            {
                "question": "Which additional features?",
                "header": "Features",
                "options": [
                    {"label": "Logging", "description": "Debug logging"},
                    {"label": "Caching", "description": "Response caching"},
                    {"label": "Metrics", "description": "Request metrics tracking"},
                ],
                "multiSelect": True,
            },
        ]
    }

    result = await engineer._handle_ask_user_question("AskUserQuestion", input_params)
    print(f"\nResult: {result}")


async def test_single_select_no_descriptions():
    """Test single-select question without descriptions."""
    print("\n" + "=" * 70)
    print("TEST 4: Single-Select Question WITHOUT Descriptions")
    print("=" * 70)

    engineer = ClaudeEngineer(
        run_id="test",
        har_path=Path("/tmp/test.har"),
        prompt="test",
        model="claude-sonnet-4-5",
    )

    input_params = {
        "questions": [
            {
                "question": "What's the primary use case?",
                "header": "Use Case",
                "options": [
                    {"label": "Web scraping"},
                    {"label": "Data extraction"},
                    {"label": "API testing"},
                    {"label": "Automation"},
                ],
                "multiSelect": False,
            }
        ]
    }

    result = await engineer._handle_ask_user_question("AskUserQuestion", input_params)
    print(f"\nResult: {result}")


async def test_multi_select_no_descriptions():
    """Test multi-select question without descriptions."""
    print("\n" + "=" * 70)
    print("TEST 5: Multi-Select Question WITHOUT Descriptions")
    print("=" * 70)

    engineer = ClaudeEngineer(
        run_id="test",
        har_path=Path("/tmp/test.har"),
        prompt="test",
        model="claude-sonnet-4-5",
    )

    input_params = {
        "questions": [
            {
                "question": "Which HTTP methods to support?",
                "header": "HTTP Methods",
                "options": [
                    {"label": "GET"},
                    {"label": "POST"},
                    {"label": "PUT"},
                    {"label": "DELETE"},
                    {"label": "PATCH"},
                ],
                "multiSelect": True,
            }
        ]
    }

    result = await engineer._handle_ask_user_question("AskUserQuestion", input_params)
    print(f"\nResult: {result}")


async def test_mixed_descriptions():
    """Test questions with mixed description availability."""
    print("\n" + "=" * 70)
    print("TEST 6: Mixed - Some Options with Descriptions, Some Without")
    print("=" * 70)

    engineer = ClaudeEngineer(
        run_id="test",
        har_path=Path("/tmp/test.har"),
        prompt="test",
        model="claude-sonnet-4-5",
    )

    input_params = {
        "questions": [
            {
                "question": "Choose your preferred approach",
                "header": "Implementation",
                "options": [
                    {
                        "label": "Simple",
                        "description": "Basic implementation with minimal features",
                    },
                    {"label": "Standard"},  # No description
                    {
                        "label": "Advanced",
                        "description": "Full-featured with all bells and whistles",
                    },
                ],
                "multiSelect": False,
            }
        ]
    }

    result = await engineer._handle_ask_user_question("AskUserQuestion", input_params)
    print(f"\nResult: {result}")


async def main():
    """Run all tests."""
    print("\n")
    print("╔" + "=" * 68 + "╗")
    print("║" + " " * 15 + "AskUserQuestion UI Test Suite" + " " * 24 + "║")
    print("╚" + "=" * 68 + "╝")
    print()
    print("This will demonstrate all question formats supported by the UI.")
    print("You can press Ctrl+C during any question to skip it.")
    print()

    tests = [
        ("Single-Select with Descriptions", test_single_select_with_descriptions),
        ("Multi-Select with Descriptions", test_multi_select_with_descriptions),
        ("Multiple Questions", test_multiple_questions),
        ("Single-Select without Descriptions", test_single_select_no_descriptions),
        ("Multi-Select without Descriptions", test_multi_select_no_descriptions),
        ("Mixed Descriptions", test_mixed_descriptions),
    ]

    print("Available tests:")
    for i, (name, _) in enumerate(tests, 1):
        print(f"  {i}. {name}")
    print(f"  {len(tests) + 1}. Run all tests")
    print()

    try:
        choice = input("Select test number (or press Enter for all): ").strip()

        if not choice:
            choice = str(len(tests) + 1)

        choice_num = int(choice)

        if 1 <= choice_num <= len(tests):
            # Run single test
            name, test_func = tests[choice_num - 1]
            await test_func()
        elif choice_num == len(tests) + 1:
            # Run all tests
            for name, test_func in tests:
                try:
                    await test_func()
                    input("\n[Press Enter to continue to next test...]")
                except KeyboardInterrupt:
                    print("\n\nTest skipped by user.")
                    continue
        else:
            print("Invalid choice.")
            return

        print("\n" + "=" * 70)
        print("Tests completed!")
        print("=" * 70)

    except ValueError:
        print("Invalid input. Please enter a number.")
    except KeyboardInterrupt:
        print("\n\nTests cancelled by user.")


if __name__ == "__main__":
    asyncio.run(main())
