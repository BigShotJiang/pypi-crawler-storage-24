#!/usr/bin/env python3
"""Test script to diagnose HAR recording issues with Google.com"""

import json
import tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

def test_har_recording():
    """Test HAR recording with different configurations for Google.com"""

    test_cases = [
        {
            "name": "Persistent context (current approach)",
            "use_persistent": True,
            "har_content": "attach",
        },
        {
            "name": "Persistent context with omit",
            "use_persistent": True,
            "har_content": "omit",
        },
        {
            "name": "Regular context with attach",
            "use_persistent": False,
            "har_content": "attach",
        },
        {
            "name": "Regular context with omit",
            "use_persistent": False,
            "har_content": "omit",
        },
    ]

    for i, test in enumerate(test_cases):
        print(f"\n{'='*60}")
        print(f"Test {i+1}: {test['name']}")
        print(f"{'='*60}")

        temp_dir = Path(tempfile.mkdtemp(prefix="har_test_"))
        har_path = temp_dir / "recording.har"
        profile_dir = temp_dir / "profile"
        profile_dir.mkdir(exist_ok=True)

        try:
            with sync_playwright() as p:
                if test["use_persistent"]:
                    print(f"Using persistent context with channel='chrome'")
                    context = p.chromium.launch_persistent_context(
                        user_data_dir=str(profile_dir),
                        channel="chrome",
                        headless=False,
                        record_har_path=str(har_path),
                        record_har_content=test["har_content"],
                        no_viewport=True,
                        args=[
                            "--start-maximized",
                            "--disable-blink-features=AutomationControlled",
                        ],
                        ignore_default_args=["--enable-automation", "--no-sandbox"],
                    )

                    # Get or create page
                    if context.pages:
                        page = context.pages[0]
                    else:
                        page = context.new_page()
                else:
                    print(f"Using regular browser with context")
                    browser = p.chromium.launch(
                        channel="chrome",
                        headless=False,
                        args=[
                            "--start-maximized",
                            "--disable-blink-features=AutomationControlled",
                        ],
                        ignore_default_args=["--enable-automation", "--no-sandbox"],
                    )

                    context = browser.new_context(
                        record_har_path=str(har_path),
                        record_har_content=test["har_content"],
                        no_viewport=True,
                    )

                    page = context.new_page()

                print("Navigating to google.com...")
                response = page.goto("https://www.google.com", wait_until="networkidle")
                print(f"Response status: {response.status}")
                print(f"Response URL: {response.url}")

                # Wait a bit for any async requests
                print("Waiting for additional requests...")
                page.wait_for_timeout(3000)

                # Try to trigger a search to generate more requests
                print("Attempting to type in search box...")
                try:
                    search_box = page.locator('textarea[name="q"]').first
                    if search_box.is_visible(timeout=2000):
                        search_box.fill("test search")
                        page.wait_for_timeout(2000)
                        print("Search query entered")
                    else:
                        print("Search box not found")
                except Exception as e:
                    print(f"Could not interact with search: {e}")

                print("Closing browser...")
                context.close()

                if not test["use_persistent"]:
                    browser.close()

                # Analyze the HAR file
                if har_path.exists():
                    har_size = har_path.stat().st_size
                    print(f"\n✓ HAR file created: {har_size} bytes")

                    with open(har_path, 'r') as f:
                        har_data = json.load(f)

                    entries = har_data.get("log", {}).get("entries", [])
                    print(f"✓ Network entries captured: {len(entries)}")

                    if entries:
                        print(f"\nFirst 5 requests:")
                        for entry in entries[:5]:
                            url = entry.get("request", {}).get("url", "N/A")
                            method = entry.get("request", {}).get("method", "N/A")
                            status = entry.get("response", {}).get("status", "N/A")
                            print(f"  {method} {status} - {url[:80]}")

                        # Check for Google-specific requests
                        google_requests = [e for e in entries if "google.com" in e.get("request", {}).get("url", "")]
                        print(f"\n✓ Google.com requests: {len(google_requests)}")

                        # Check if we captured request/response bodies
                        has_request_body = any(
                            e.get("request", {}).get("postData")
                            for e in entries
                        )
                        has_response_body = any(
                            e.get("response", {}).get("content", {}).get("text")
                            for e in entries
                        )
                        print(f"✓ Has request bodies: {has_request_body}")
                        print(f"✓ Has response bodies: {has_response_body}")
                    else:
                        print("\n⚠️  WARNING: No network entries captured!")
                        print("This indicates HAR recording is not working properly.")
                else:
                    print(f"\n✗ HAR file not created!")

        except Exception as e:
            print(f"\n✗ Error: {e}")
            import traceback
            traceback.print_exc()

        input(f"\nPress Enter to continue to next test...")

    print("\n" + "="*60)
    print("Testing complete!")
    print("="*60)

if __name__ == "__main__":
    print("HAR Recording Test for Google.com")
    print("This will open Chrome 4 times to test different configurations")
    print("Close each browser window when prompted")
    input("\nPress Enter to start tests...")
    test_har_recording()
