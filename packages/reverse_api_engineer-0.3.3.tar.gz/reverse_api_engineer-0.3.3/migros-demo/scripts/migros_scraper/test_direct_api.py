"""Test direct API call with exact headers from HAR"""
import requests
import json

# Create session
session = requests.Session()

# Headers from HAR
headers = {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'fr',
    'content-type': 'application/json',
    'migros-language': 'fr',
    'origin': 'https://www.migros.ch',
    'peer-id': 'website-js-1068.0.0',
    'referer': 'https://www.migros.ch/fr/category/fruits-legumes',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
}

session.headers.update(headers)

# Try category search
print("Testing category search...")
url = "https://www.migros.ch/product-display/public/web/v1/products/category/7494732/search"

try:
    response = session.post(url, json={}, timeout=30)
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"Success! Got {len(data.get('productIds', []))} product IDs")
        print(f"Total products: {data.get('numberOfProducts')}")
    else:
        print(f"Failed: {response.text[:200]}")
except Exception as e:
    print(f"Error: {e}")

# Try with cookies
print("\n\nTesting with generic cookies...")
session.cookies.set('visitor-id', 'test-visitor-id')

try:
    response = session.post(url, json={}, timeout=30)
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"Success! Got {len(data.get('productIds', []))} product IDs")
except Exception as e:
    print(f"Error: {e}")
