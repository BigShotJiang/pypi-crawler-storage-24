"""
Migros Product Scraper API Client (Playwright Version)

This version uses Playwright to bypass bot detection mechanisms.
It intercepts API calls made by the browser to extract product data.
"""

import json
import logging
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from playwright.async_api import async_playwright, Page, Route
import time


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class Product:
    """Data class representing a Migros product"""
    uid: int
    migros_id: str
    migros_online_id: str
    name: str
    brand: str
    title: str
    price: Optional[float] = None
    unit_price: Optional[float] = None
    images: List[str] = None
    gtins: List[str] = None
    product_url: str = ""
    breadcrumb: List[Dict] = None
    availability: str = ""

    def __post_init__(self):
        if self.images is None:
            self.images = []
        if self.gtins is None:
            self.gtins = []
        if self.breadcrumb is None:
            self.breadcrumb = []


class MigrosPlaywrightClient:
    """
    Client for interacting with Migros.ch using Playwright.

    This client uses a real browser to bypass bot detection and
    intercepts API calls to extract product data.
    """

    BASE_URL = "https://www.migros.ch"

    def __init__(self, language: str = "fr", headless: bool = True):
        """
        Initialize the Migros Playwright client.

        Args:
            language: Language code (fr, de, it)
            headless: Whether to run browser in headless mode
        """
        self.language = language
        self.headless = headless
        self.browser = None
        self.context = None
        self.page = None
        self.intercepted_data = {}

    async def __aenter__(self):
        """Async context manager entry"""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()

    async def start(self):
        """Start the browser and create a new page"""
        logger.info("Starting Playwright browser...")

        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(
            headless=self.headless,
            args=[
                '--disable-blink-features=AutomationControlled',
                '--disable-dev-shm-usage',
                '--no-sandbox'
            ]
        )

        # Create context with realistic browser settings
        self.context = await self.browser.new_context(
            viewport={'width': 1440, 'height': 900},
            locale=f'{self.language}-CH',
            timezone_id='Europe/Zurich',
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36'
        )

        self.page = await self.context.new_page()

        # Setup response listener
        self.page.on('response', self._handle_response)

        # Add stealth scripts
        await self.page.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
        """)

        logger.info("Browser started successfully")

    async def close(self):
        """Close the browser"""
        if self.page:
            await self.page.close()
        if self.context:
            await self.context.close()
        if self.browser:
            await self.browser.close()
        if hasattr(self, 'playwright'):
            await self.playwright.stop()
        logger.info("Browser closed")

    async def _handle_response(self, response):
        """
        Handle responses and capture API data.

        Args:
            response: Playwright response object
        """
        url = response.url

        try:
            # Capture specific API responses
            if 'product-display/public/web/v1/products/category' in url and response.request.method == 'POST':
                try:
                    data = await response.json()
                    self.intercepted_data['product_search'] = data
                    logger.info(f"Captured product search response: {len(data.get('productIds', []))} products")
                except Exception as e:
                    logger.debug(f"Failed to parse product search: {e}")

            elif 'product-display/public/v4/product-cards' in url and response.request.method == 'POST':
                try:
                    data = await response.json()
                    if 'product_cards' not in self.intercepted_data:
                        self.intercepted_data['product_cards'] = []
                    self.intercepted_data['product_cards'].extend(data)
                    logger.info(f"Captured product cards: {len(data)} products")
                except Exception as e:
                    logger.debug(f"Failed to parse product cards: {e}")

            elif 'product-display/public/v1/categories-breadcrumb' in url:
                try:
                    data = await response.json()
                    self.intercepted_data['category_info'] = data
                    logger.info("Captured category info")
                except Exception as e:
                    logger.debug(f"Failed to parse category info: {e}")
        except Exception as e:
            logger.debug(f"Response handler error: {e}")

    async def _intercept_request(self, route: Route):
        """
        Intercept and capture API responses.

        Args:
            route: Playwright route object
        """
        request = route.request
        url = request.url

        # Continue the request and get response
        try:
            response = await route.fetch()

            # Capture specific API responses
            if 'product-display/public/web/v1/products/category' in url and request.method == 'POST':
                try:
                    body = await response.body()
                    data = json.loads(body.decode('utf-8'))
                    self.intercepted_data['product_search'] = data
                    logger.info(f"Intercepted product search response: {len(data.get('productIds', []))} products")
                except Exception as e:
                    logger.debug(f"Failed to parse product search: {e}")

            elif 'product-display/public/v4/product-cards' in url and request.method == 'POST':
                try:
                    body = await response.body()
                    data = json.loads(body.decode('utf-8'))
                    if 'product_cards' not in self.intercepted_data:
                        self.intercepted_data['product_cards'] = []
                    self.intercepted_data['product_cards'].extend(data)
                    logger.info(f"Intercepted product cards: {len(data)} products")
                except Exception as e:
                    logger.debug(f"Failed to parse product cards: {e}")

            elif 'product-display/public/v1/categories-breadcrumb' in url:
                try:
                    body = await response.body()
                    data = json.loads(body.decode('utf-8'))
                    self.intercepted_data['category_info'] = data
                    logger.info("Intercepted category info")
                except Exception as e:
                    logger.debug(f"Failed to parse category info: {e}")

            # Fulfill the response
            await route.fulfill(response=response)
        except Exception as e:
            # If fetch fails, continue normally
            logger.debug(f"Route fetch failed: {e}")
            await route.continue_()

    async def navigate_to_category(self, slug: str):
        """
        Navigate to a category page and wait for it to load.

        Args:
            slug: Category slug (e.g., "fruits-legumes")
        """
        url = f"{self.BASE_URL}/{self.language}/category/{slug}"
        logger.info(f"Navigating to: {url}")

        self.intercepted_data = {}  # Reset intercepted data

        try:
            await self.page.goto(url, wait_until='networkidle', timeout=60000)
            logger.info("Page loaded successfully")

            # Wait a bit for API calls to complete
            await asyncio.sleep(2)

        except Exception as e:
            logger.error(f"Failed to navigate to category: {e}")
            raise

    async def scroll_and_load_more(self):
        """
        Scroll down the page to trigger loading more products.
        """
        logger.info("Scrolling to load more products...")

        # Get expected total from product search
        expected_total = 0
        if 'product_search' in self.intercepted_data:
            expected_total = self.intercepted_data['product_search'].get('numberOfProducts', 0)
            logger.info(f"Expected total products: {expected_total}")

        previous_count = 0
        no_change_count = 0
        max_iterations = 100  # Safety limit

        for iteration in range(max_iterations):
            # Aggressive scrolling - scroll to absolute bottom
            await self.page.evaluate('''
                window.scrollTo(0, document.body.scrollHeight);
            ''')
            await asyncio.sleep(0.8)

            # Also try scrolling the main content area if it exists
            try:
                await self.page.evaluate('''
                    const mainContent = document.querySelector('main') || document.querySelector('[role="main"]');
                    if (mainContent) {
                        mainContent.scrollTop = mainContent.scrollHeight;
                    }
                ''')
            except:
                pass

            # Check if more products loaded
            current_cards = self.intercepted_data.get('product_cards', [])
            current_count = len(current_cards)

            if current_count > previous_count:
                logger.info(f"Loaded {current_count}/{expected_total} products")
                previous_count = current_count
                no_change_count = 0

                # Check if we got all products
                if expected_total > 0 and current_count >= expected_total:
                    logger.info("All products loaded!")
                    break
            else:
                no_change_count += 1

            # Try to find and click "Load More" button
            try:
                # Try different possible button selectors
                load_more_selectors = [
                    'button:has-text("Charger plus")',
                    'button:has-text("Load more")',
                    'button:has-text("Mehr laden")',
                    'button:has-text("Carica altro")',
                    'button[class*="load-more"]',
                    'button[class*="LoadMore"]',
                    'button[data-testid*="load"]'
                ]

                button_found = False
                for selector in load_more_selectors:
                    try:
                        button = await self.page.query_selector(selector)
                        if button:
                            is_visible = await button.is_visible()
                            if is_visible:
                                logger.info(f"Clicking load more button: {selector}")
                                await button.scroll_into_view_if_needed()
                                await button.click()
                                await asyncio.sleep(2)
                                no_change_count = 0
                                button_found = True
                                break
                    except Exception as e:
                        logger.debug(f"Button click failed for {selector}: {e}")
                        continue

                if button_found:
                    continue

            except Exception as e:
                logger.debug(f"Load more button check failed: {e}")

            # If no change for 8 iterations, stop
            if no_change_count >= 8:
                logger.info("No more products loading, stopping scroll")
                break

        logger.info(f"Finished scrolling. Total products loaded: {len(self.intercepted_data.get('product_cards', []))}/{expected_total}")

    async def get_all_products_by_category_slug(self, slug: str) -> List[Dict[str, Any]]:
        """
        Get all products in a category by navigating with the browser.

        Args:
            slug: Category slug (e.g., "fruits-legumes")

        Returns:
            List of detailed product dictionaries
        """
        logger.info(f"Fetching all products from category: {slug}")

        # Navigate to category page
        await self.navigate_to_category(slug)

        # Scroll to load all products
        await self.scroll_and_load_more()

        # Return collected product cards
        products = self.intercepted_data.get('product_cards', [])
        logger.info(f"Total products collected: {len(products)}")

        return products

    def parse_product(self, product_data: Dict[str, Any]) -> Product:
        """
        Parse raw product data into a Product dataclass.

        Args:
            product_data: Raw product dictionary from API

        Returns:
            Product dataclass instance
        """
        # Extract price information
        price = None
        unit_price = None

        if 'offer' in product_data:
            offer = product_data['offer']
            if 'price' in offer:
                price_info = offer['price']

                # Try different price fields
                # Effective value is the actual current price
                if 'effectiveValue' in price_info:
                    price = price_info['effectiveValue']
                # Advertised value is the display price
                elif 'advertisedValue' in price_info:
                    price = price_info['advertisedValue']
                # Try item price (nested structure)
                elif 'item' in price_info and isinstance(price_info['item'], dict):
                    price = price_info['item'].get('price')
                # Sometimes price is directly in price_info
                elif 'price' in price_info and isinstance(price_info['price'], (int, float)):
                    price = price_info['price']

                # Unit price
                if 'unitPrice' in price_info:
                    unit_price = price_info['unitPrice']
                # Try base price (nested structure)
                elif 'base' in price_info and isinstance(price_info['base'], dict):
                    unit_price = price_info['base'].get('price')

        # Extract image URLs
        images = []
        if 'images' in product_data:
            images = [img.get('url', '') for img in product_data['images']]

        return Product(
            uid=product_data.get('uid'),
            migros_id=product_data.get('migrosId', ''),
            migros_online_id=product_data.get('migrosOnlineId', ''),
            name=product_data.get('name', ''),
            brand=product_data.get('brand', ''),
            title=product_data.get('title', ''),
            price=price,
            unit_price=unit_price,
            images=images,
            gtins=product_data.get('gtins', []),
            product_url=product_data.get('productUrls', ''),
            breadcrumb=product_data.get('breadcrumb', []),
            availability=product_data.get('productAvailability', '')
        )

    def save_products_to_json(
        self,
        products: List[Dict[str, Any]],
        filename: str
    ) -> None:
        """
        Save products to a JSON file.

        Args:
            products: List of product dictionaries
            filename: Output filename
        """
        logger.info(f"Saving {len(products)} products to {filename}")

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(products, f, indent=2, ensure_ascii=False)

        logger.info(f"Successfully saved products to {filename}")


async def main():
    """
    Example usage of the MigrosPlaywrightClient.
    """
    async with MigrosPlaywrightClient(language="fr", headless=True) as client:
        try:
            # Fetch products from a category
            print("\n=== Fetching products from 'fruits-legumes' category ===")
            products = await client.get_all_products_by_category_slug("fruits-legumes")

            print(f"\nFound {len(products)} products")

            # Show first 5 products as examples
            if products:
                print("\nFirst 5 products:")
                for product_data in products[:5]:
                    product = client.parse_product(product_data)
                    print(f"  - {product.name} ({product.brand}) - CHF {product.price}")

            # Save to file
            client.save_products_to_json(products, "migros_fruits_legumes.json")
            print(f"\n✓ Saved {len(products)} products to migros_fruits_legumes.json")

        except Exception as e:
            logger.error(f"Error: {e}")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
