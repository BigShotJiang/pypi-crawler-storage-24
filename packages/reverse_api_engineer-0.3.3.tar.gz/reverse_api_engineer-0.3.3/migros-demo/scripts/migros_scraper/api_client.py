"""
Migros Product Scraper API Client

This module provides a Python client for scraping product data from Migros.ch.
It can fetch all products by category, including detailed product information.
"""

import json
import logging
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class Product:
    """Data class representing a Migros product"""
    uid: int
    migros_id: str
    migros_online_id: str
    name: str
    brand: str
    title: str
    price: Optional[float] = None
    unit_price: Optional[float] = None
    images: List[str] = None
    gtins: List[str] = None
    product_url: str = ""
    breadcrumb: List[Dict] = None
    availability: str = ""

    def __post_init__(self):
        if self.images is None:
            self.images = []
        if self.gtins is None:
            self.gtins = []
        if self.breadcrumb is None:
            self.breadcrumb = []


class MigrosAPIClient:
    """
    Client for interacting with Migros.ch product API.

    This client can fetch product listings by category and retrieve detailed
    product information including prices, images, and descriptions.
    """

    BASE_URL = "https://www.migros.ch"

    def __init__(
        self,
        language: str = "fr",
        region: str = "national",
        store_type: str = "OFFLINE"
    ):
        """
        Initialize the Migros API client.

        Args:
            language: Language code (fr, de, it)
            region: Region identifier (default: "national")
            store_type: Store type filter (default: "OFFLINE")
        """
        self.language = language
        self.region = region
        self.store_type = store_type
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        """
        Create a requests session with retry strategy and proper headers.

        Returns:
            Configured requests Session object
        """
        session = requests.Session()

        # Configure retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST", "OPTIONS"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        # Set default headers to mimic a real browser
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': self.language,
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Content-Type': 'application/json',
            'migros-language': self.language,
            'peer-id': 'website-js-1068.0.0',
            'Origin': self.BASE_URL,
            'Referer': f'{self.BASE_URL}/{self.language}/category/home',
            'sec-ch-ua': '"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
        })

        return session

    def get_category_info(self, slug: str) -> Dict[str, Any]:
        """
        Get category information by slug.

        Args:
            slug: Category slug (e.g., "fruits-legumes")

        Returns:
            Dictionary containing category information

        Raises:
            requests.HTTPError: If the request fails
        """
        url = f"{self.BASE_URL}/product-display/public/v1/categories-breadcrumb"
        params = {"slug": slug}

        logger.info(f"Fetching category info for slug: {slug}")

        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            logger.info(f"Successfully fetched category info for: {slug}")
            return data
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch category info for {slug}: {e}")
            raise

    def search_products_by_category(
        self,
        category_id: int,
        offset: int = 0,
        limit: int = 100
    ) -> Dict[str, Any]:
        """
        Search for products in a specific category.

        This endpoint returns product IDs and metadata, but not full product details.
        Use get_product_cards() to fetch detailed information.

        Args:
            category_id: The numeric category ID
            offset: Pagination offset (default: 0)
            limit: Number of products to return (default: 100)

        Returns:
            Dictionary containing:
                - productIds: List of product IDs
                - items: List of product items with type
                - filters: Available filters for the category
                - categories: Subcategory information
                - numberOfProducts: Total number of products
                - offset: Current offset

        Raises:
            requests.HTTPError: If the request fails
        """
        url = f"{self.BASE_URL}/product-display/public/web/v1/products/category/{category_id}/search"

        logger.info(f"Searching products in category {category_id} (offset: {offset})")

        try:
            # The API expects an empty POST request
            response = self.session.post(url, json={}, timeout=30)
            response.raise_for_status()
            data = response.json()

            product_count = len(data.get('productIds', []))
            total_count = data.get('numberOfProducts', 0)
            logger.info(f"Found {product_count} products (total: {total_count})")

            return data
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to search products for category {category_id}: {e}")
            raise

    def get_product_cards(
        self,
        product_ids: List[int],
        date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get detailed product information for a list of product IDs.

        Args:
            product_ids: List of product UIDs
            date: Offer date in ISO format (default: current date)

        Returns:
            List of detailed product dictionaries

        Raises:
            requests.HTTPError: If the request fails
        """
        if not product_ids:
            logger.warning("No product IDs provided")
            return []

        if date is None:
            from datetime import datetime
            date = datetime.now().strftime("%Y-%m-%dT00:00:00")

        url = f"{self.BASE_URL}/product-display/public/v4/product-cards"

        payload = {
            "offerFilter": {
                "storeType": self.store_type,
                "region": self.region,
                "ongoingOfferDate": date
            },
            "productFilter": {
                "uids": product_ids
            }
        }

        logger.info(f"Fetching product cards for {len(product_ids)} products")

        try:
            response = self.session.post(url, json=payload, timeout=30)
            response.raise_for_status()
            data = response.json()
            logger.info(f"Successfully fetched {len(data)} product cards")
            return data
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch product cards: {e}")
            raise

    def get_all_products_by_category(
        self,
        category_id: int,
        batch_size: int = 100,
        delay: float = 0.5
    ) -> List[Dict[str, Any]]:
        """
        Get all products in a category with full details.

        This method handles pagination automatically and fetches detailed
        product information in batches.

        Args:
            category_id: The numeric category ID
            batch_size: Number of products to fetch per batch (default: 100)
            delay: Delay between requests in seconds (default: 0.5)

        Returns:
            List of detailed product dictionaries

        Raises:
            requests.HTTPError: If any request fails
        """
        logger.info(f"Starting to fetch all products from category {category_id}")

        all_products = []
        offset = 0

        while True:
            # Fetch product IDs for this page
            search_result = self.search_products_by_category(
                category_id=category_id,
                offset=offset
            )

            product_ids = search_result.get('productIds', [])
            total_products = search_result.get('numberOfProducts', 0)

            if not product_ids:
                logger.info("No more products to fetch")
                break

            # Fetch detailed information for these products
            product_details = self.get_product_cards(product_ids)
            all_products.extend(product_details)

            logger.info(f"Progress: {len(all_products)}/{total_products} products")

            # Check if we've fetched all products
            offset += len(product_ids)
            if offset >= total_products:
                break

            # Add delay to be respectful to the server
            time.sleep(delay)

        logger.info(f"Finished fetching {len(all_products)} total products")
        return all_products

    def get_products_by_category_slug(
        self,
        slug: str,
        batch_size: int = 100,
        delay: float = 0.5
    ) -> List[Dict[str, Any]]:
        """
        Get all products in a category using its slug.

        This is a convenience method that first resolves the slug to a category ID,
        then fetches all products.

        Args:
            slug: Category slug (e.g., "fruits-legumes")
            batch_size: Number of products to fetch per batch (default: 100)
            delay: Delay between requests in seconds (default: 0.5)

        Returns:
            List of detailed product dictionaries

        Raises:
            requests.HTTPError: If any request fails
            ValueError: If category not found
        """
        logger.info(f"Fetching products for category slug: {slug}")

        # Get category info to find the ID
        category_info = self.get_category_info(slug)

        # The API returns a list, get the first (main) category
        if not category_info:
            raise ValueError(f"Category not found for slug: {slug}")

        # Extract category ID from the breadcrumb structure
        # The category info contains nested structure, find the relevant ID
        category_id = None
        if isinstance(category_info, list) and len(category_info) > 0:
            # Get the last category in the breadcrumb (most specific)
            category_id = int(category_info[-1].get('id'))
        elif isinstance(category_info, dict):
            category_id = int(category_info.get('id'))

        if not category_id:
            raise ValueError(f"Could not extract category ID from response")

        logger.info(f"Resolved slug '{slug}' to category ID: {category_id}")

        # Fetch all products
        return self.get_all_products_by_category(
            category_id=category_id,
            batch_size=batch_size,
            delay=delay
        )

    def parse_product(self, product_data: Dict[str, Any]) -> Product:
        """
        Parse raw product data into a Product dataclass.

        Args:
            product_data: Raw product dictionary from API

        Returns:
            Product dataclass instance
        """
        # Extract price information
        price = None
        unit_price = None

        if 'offer' in product_data:
            offer = product_data['offer']
            if 'price' in offer:
                price_info = offer['price']

                # Try different price fields
                # Effective value is the actual current price
                if 'effectiveValue' in price_info:
                    price = price_info['effectiveValue']
                # Advertised value is the display price
                elif 'advertisedValue' in price_info:
                    price = price_info['advertisedValue']
                # Try item price (nested structure)
                elif 'item' in price_info and isinstance(price_info['item'], dict):
                    price = price_info['item'].get('price')
                # Sometimes price is directly in price_info
                elif 'price' in price_info and isinstance(price_info['price'], (int, float)):
                    price = price_info['price']

                # Unit price
                if 'unitPrice' in price_info:
                    unit_price = price_info['unitPrice']
                # Try base price (nested structure)
                elif 'base' in price_info and isinstance(price_info['base'], dict):
                    unit_price = price_info['base'].get('price')

        # Extract image URLs
        images = []
        if 'images' in product_data:
            images = [img.get('url', '') for img in product_data['images']]

        return Product(
            uid=product_data.get('uid'),
            migros_id=product_data.get('migrosId', ''),
            migros_online_id=product_data.get('migrosOnlineId', ''),
            name=product_data.get('name', ''),
            brand=product_data.get('brand', ''),
            title=product_data.get('title', ''),
            price=price,
            unit_price=unit_price,
            images=images,
            gtins=product_data.get('gtins', []),
            product_url=product_data.get('productUrls', ''),
            breadcrumb=product_data.get('breadcrumb', []),
            availability=product_data.get('productAvailability', '')
        )

    def save_products_to_json(
        self,
        products: List[Dict[str, Any]],
        filename: str
    ) -> None:
        """
        Save products to a JSON file.

        Args:
            products: List of product dictionaries
            filename: Output filename
        """
        logger.info(f"Saving {len(products)} products to {filename}")

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(products, f, indent=2, ensure_ascii=False)

        logger.info(f"Successfully saved products to {filename}")


def main():
    """
    Example usage of the MigrosAPIClient.
    """
    # Initialize client
    client = MigrosAPIClient(language="fr")

    # Example 1: Get products by category slug
    print("\n=== Example 1: Fetching products from 'fruits-legumes' category ===")
    try:
        products = client.get_products_by_category_slug("fruits-legumes")
        print(f"Found {len(products)} products")

        # Show first product as example
        if products:
            print("\nFirst product example:")
            product = client.parse_product(products[0])
            print(f"  Name: {product.name}")
            print(f"  Brand: {product.brand}")
            print(f"  Price: CHF {product.price}")
            print(f"  URL: {product.product_url}")

        # Save to file
        client.save_products_to_json(products, "migros_fruits_legumes.json")

    except Exception as e:
        logger.error(f"Error fetching products: {e}")

    # Example 2: Get products by specific category ID
    print("\n=== Example 2: Fetching products by category ID ===")
    try:
        category_id = 7494732  # Fruits & légumes category
        products = client.get_all_products_by_category(category_id)
        print(f"Found {len(products)} products in category {category_id}")

    except Exception as e:
        logger.error(f"Error fetching products: {e}")

    # Example 3: Get category information
    print("\n=== Example 3: Getting category information ===")
    try:
        category_info = client.get_category_info("fruits-legumes")
        print(f"Category info: {json.dumps(category_info, indent=2)[:500]}")

    except Exception as e:
        logger.error(f"Error fetching category info: {e}")


if __name__ == "__main__":
    main()
