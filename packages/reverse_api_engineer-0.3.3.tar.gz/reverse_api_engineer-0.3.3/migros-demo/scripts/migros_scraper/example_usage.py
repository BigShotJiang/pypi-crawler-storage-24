"""
Example usage of the Migros Product Scraper

This script demonstrates how to use the Playwright-based scraper
to fetch products from multiple categories.
"""

import asyncio
import json
from api_client_playwright import MigrosPlaywrightClient


async def scrape_single_category():
    """Example 1: Scrape a single category"""
    print("\n" + "="*60)
    print("Example 1: Scraping a single category")
    print("="*60)

    async with MigrosPlaywrightClient(language="fr", headless=True) as client:
        # Scrape fruits & vegetables category
        products = await client.get_all_products_by_category_slug("fruits-legumes")

        print(f"\n✅ Successfully scraped {len(products)} products")

        # Show sample products
        print("\nSample products:")
        for i, product_data in enumerate(products[:5]):
            product = client.parse_product(product_data)
            price_str = f"CHF {product.price}" if product.price else "Variable price"
            print(f"  {i+1}. {product.name} ({product.brand}) - {price_str}")

        # Save to file
        client.save_products_to_json(products, "example_fruits_legumes.json")
        print(f"\n💾 Saved to: example_fruits_legumes.json")


async def scrape_with_analysis():
    """Example 2: Scrape and analyze data"""
    print("\n" + "="*60)
    print("Example 2: Scraping with data analysis")
    print("="*60)

    async with MigrosPlaywrightClient(language="fr", headless=True) as client:
        products = await client.get_all_products_by_category_slug("fruits-legumes")

        # Analyze the data
        print(f"\n📊 Data Analysis:")
        print(f"   Total products: {len(products)}")

        # Count by brand
        from collections import Counter
        brands = Counter([p.get('brand', 'Unknown') for p in products])

        print(f"\n   Top 5 brands:")
        for brand, count in brands.most_common(5):
            print(f"     - {brand}: {count} products")

        # Price statistics
        prices = []
        for p in products:
            price_info = p.get('offer', {}).get('price', {})
            price = price_info.get('effectiveValue') or price_info.get('advertisedValue')
            if price:
                prices.append(price)

        if prices:
            avg_price = sum(prices) / len(prices)
            min_price = min(prices)
            max_price = max(prices)

            print(f"\n   Price statistics (CHF):")
            print(f"     - Average: {avg_price:.2f}")
            print(f"     - Min: {min_price:.2f}")
            print(f"     - Max: {max_price:.2f}")
            print(f"     - Products with prices: {len(prices)}/{len(products)}")


async def scrape_multiple_categories():
    """Example 3: Scrape multiple categories"""
    print("\n" + "="*60)
    print("Example 3: Scraping multiple categories")
    print("="*60)

    categories = [
        "fruits-legumes",
        # Add more categories as needed
        # "viande-poisson",
        # "pain-patisseries",
    ]

    async with MigrosPlaywrightClient(language="fr", headless=True) as client:
        all_results = {}

        for slug in categories:
            print(f"\n📦 Scraping category: {slug}")
            try:
                products = await client.get_all_products_by_category_slug(slug)
                all_results[slug] = products
                print(f"   ✅ Got {len(products)} products")
            except Exception as e:
                print(f"   ❌ Error: {e}")

        # Save all results
        with open("example_all_categories.json", "w", encoding="utf-8") as f:
            json.dump(all_results, f, indent=2, ensure_ascii=False)

        print(f"\n💾 Saved all categories to: example_all_categories.json")
        print(f"📊 Total categories scraped: {len(all_results)}")
        total_products = sum(len(products) for products in all_results.values())
        print(f"📦 Total products: {total_products}")


async def main():
    """Run all examples"""
    print("\n🚀 Migros Product Scraper - Example Usage\n")

    # Run example 1
    await scrape_single_category()

    # Wait a bit between requests
    await asyncio.sleep(2)

    # Run example 2
    await scrape_with_analysis()

    # Uncomment to run example 3
    # await asyncio.sleep(2)
    # await scrape_multiple_categories()

    print("\n" + "="*60)
    print("✅ All examples completed successfully!")
    print("="*60 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
