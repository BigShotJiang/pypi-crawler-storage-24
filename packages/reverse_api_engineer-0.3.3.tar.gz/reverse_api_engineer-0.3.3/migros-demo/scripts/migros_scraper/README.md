# Migros Product Scraper

A Python client for scraping product data from Migros.ch, the largest supermarket chain in Switzerland. This tool allows you to fetch all products by category, including detailed information such as prices, images, descriptions, and availability.

## Features

- 🛒 Fetch products from any Migros category
- 📊 Get detailed product information (prices, images, descriptions, GTINs)
- 🌐 Multi-language support (French, German, Italian)
- 💾 Save results to JSON format
- 🔁 Automatic retry on failures (requests version)
- 📝 Comprehensive logging
- 🎭 Playwright-based bypass for bot detection

## Two Implementation Options

### 1. `api_client.py` - Requests-based (Not Working)
- Uses Python `requests` library
- Fast and lightweight
- **Status:** ❌ Blocked by bot detection (403 Forbidden)
- Included for reference and documentation purposes

### 2. `api_client_playwright.py` - Browser-based (Working)
- Uses Playwright to control a real browser
- Bypasses bot detection by using actual browser context
- Intercepts API calls made by the browser
- **Status:** ✅ Working successfully
- **Limitation:** Currently captures ~100 products per category (initial page load)

## Installation

### For Simple API Client (requests-based):
```bash
pip install requests
```

**Note:** The requests-based client (`api_client.py`) will encounter 403 Forbidden errors due to bot detection. Use the Playwright version for production use.

### For Playwright-based Client (recommended):
```bash
pip install playwright
playwright install chromium
```

## Quick Start

### Using Playwright Client (Recommended)

```python
import asyncio
from api_client_playwright import MigrosPlaywrightClient

async def scrape_products():
    async with MigrosPlaywrightClient(language="fr", headless=True) as client:
        # Get all products from a category
        products = await client.get_all_products_by_category_slug("fruits-legumes")

        # Save to JSON file
        client.save_products_to_json(products, "products.json")

        print(f"Found {len(products)} products!")

# Run the async function
asyncio.run(scrape_products())
```

### Using Simple Requests Client (May not work due to bot detection)

```python
from api_client import MigrosAPIClient

# Initialize the client
client = MigrosAPIClient(language="fr")

# Get all products from a category
products = client.get_products_by_category_slug("fruits-legumes")

# Save to JSON file
client.save_products_to_json(products, "products.json")

print(f"Found {len(products)} products!")
```

**Important:** The simple requests-based client will likely encounter 403 Forbidden errors. Use the Playwright version for reliable scraping.

## API Endpoints Discovered

### 1. Category Information
**Endpoint:** `GET /product-display/public/v1/categories-breadcrumb`

Retrieves category metadata and subcategory structure.

```python
category_info = client.get_category_info("fruits-legumes")
```

### 2. Product Search by Category
**Endpoint:** `POST /product-display/public/web/v1/products/category/{categoryId}/search`

Returns a list of product IDs for a given category. This endpoint handles pagination through the offset parameter.

```python
search_result = client.search_products_by_category(
    category_id=7494732,
    offset=0
)
```

**Response structure:**
- `productIds`: Array of product IDs
- `items`: Product items with type information
- `filters`: Available filters (brand, bio, promotion, etc.)
- `categories`: Subcategory information
- `numberOfProducts`: Total count of products
- `offset`: Current pagination offset

### 3. Product Cards (Detailed Information)
**Endpoint:** `POST /product-display/public/v4/product-cards`

Fetches detailed information for a list of product IDs.

```python
products = client.get_product_cards([100020417, 100047607, 100040510])
```

**Request payload:**
```json
{
  "offerFilter": {
    "storeType": "OFFLINE",
    "region": "national",
    "ongoingOfferDate": "2026-01-26T00:00:00"
  },
  "productFilter": {
    "uids": [100020417, 100047607, 100040510]
  }
}
```

**Response includes:**
- Product UID, Migros ID, name, brand
- Pricing information (item price, unit price)
- Images and GTINs
- Availability status
- Breadcrumb navigation
- Product URLs

## Authentication

The Migros API uses **cookie-based authentication** with several tracking cookies:

- `leshopch`: Encrypted JWT token
- `visitor-id`: Visitor UUID
- `mo-guestId`: Guest session identifier
- Various analytics cookies

The client automatically handles session management through the `requests.Session` object.

### Required Headers

```python
{
    'User-Agent': 'Mozilla/5.0 ...',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'fr',  # or 'de', 'it'
    'Content-Type': 'application/json',
    'migros-language': 'fr',
    'peer-id': 'website-js-1068.0.0',
    'Origin': 'https://www.migros.ch',
    'Referer': 'https://www.migros.ch/fr/category/home'
}
```

## Usage Examples

### Example 1: Get Products by Category Slug

```python
from api_client import MigrosAPIClient

client = MigrosAPIClient(language="fr")

# Fetch all products from fruits & vegetables category
products = client.get_products_by_category_slug("fruits-legumes")

print(f"Found {len(products)} products")

# Access product details
for product in products[:5]:  # First 5 products
    print(f"{product['name']} - CHF {product.get('offer', {}).get('price', {}).get('item', {}).get('price', 'N/A')}")
```

### Example 2: Get Products by Category ID

```python
# If you know the category ID directly
category_id = 7494732  # Fruits & légumes

products = client.get_all_products_by_category(category_id)
```

### Example 3: Parse Product Data

```python
# Parse raw product data into a structured format
for raw_product in products:
    product = client.parse_product(raw_product)

    print(f"Name: {product.name}")
    print(f"Brand: {product.brand}")
    print(f"Price: CHF {product.price}")
    print(f"Images: {len(product.images)}")
    print(f"URL: {product.product_url}")
    print("-" * 50)
```

### Example 4: Multi-language Support

```python
# French
client_fr = MigrosAPIClient(language="fr")
products_fr = client_fr.get_products_by_category_slug("fruits-legumes")

# German
client_de = MigrosAPIClient(language="de")
products_de = client_de.get_products_by_category_slug("fruechte-gemuese")

# Italian
client_it = MigrosAPIClient(language="it")
products_it = client_it.get_products_by_category_slug("frutta-verdura")
```

### Example 5: Custom Configuration

```python
client = MigrosAPIClient(
    language="fr",
    region="national",  # or specific region
    store_type="OFFLINE"  # or "ONLINE"
)

# Fetch with custom batch size and delay
products = client.get_all_products_by_category(
    category_id=7494732,
    batch_size=50,  # Fetch 50 products at a time
    delay=1.0  # Wait 1 second between requests
)
```

## Product Data Structure

Each product contains the following information:

```python
{
    "uid": 100020417,
    "migrosId": "260508104100",
    "migrosOnlineId": "4458709",
    "name": "Poires",
    "brand": "Fresca",
    "title": "Fresca · Poires · Conférence",
    "productRange": "STANDARD",
    "productAvailability": "ONLINE_AND_INSTORE",
    "gtins": ["7617027541794"],
    "images": [
        {
            "cdn": "rokka",
            "url": "https://image.migros.ch/..."
        }
    ],
    "breadcrumb": [...],
    "productUrls": "https://www.migros.ch/fr/product/...",
    "offer": {
        "price": {
            "item": {"price": 2.50},
            "base": {"price": 5.00, "unit": "kg"}
        },
        "maxOrderableQuantityV2": 96
    }
}
```

## Category Slugs

Common category slugs you can use:

- `fruits-legumes` - Fruits & Vegetables
- `viande-poisson` - Meat & Fish
- `pain-patisseries` - Bread & Pastries
- `produits-laitiers-oeufs` - Dairy & Eggs
- `boissons` - Beverages
- `epicerie` - Grocery
- `surgeles` - Frozen Foods

To find more category slugs, browse the Migros website and look at the URL structure:
`https://www.migros.ch/fr/category/{slug}`

## Error Handling

The client includes comprehensive error handling:

```python
import logging

logging.basicConfig(level=logging.INFO)

try:
    client = MigrosAPIClient(language="fr")
    products = client.get_products_by_category_slug("fruits-legumes")
except requests.HTTPError as e:
    print(f"HTTP Error: {e}")
except ValueError as e:
    print(f"Value Error: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")
```

## Rate Limiting

The client includes built-in rate limiting:

- Default delay of 0.5 seconds between batch requests
- Automatic retry on failures (3 attempts with exponential backoff)
- Configurable delay parameter

## Limitations

1. **Bot Detection**: Migros implements strong bot detection. The simple requests-based client (`api_client.py`) will receive 403 Forbidden errors. **Use the Playwright version (`api_client_playwright.py`) for production use.**

2. **Initial Product Limit**: The website initially loads approximately 100 products per category. The Playwright client captures these first 100 products. To get all products, the page would need to implement infinite scroll or pagination, which requires more complex interaction with the page's JavaScript.

3. **Rate Limits**: While not officially documented, excessive requests may result in temporary blocks. Use appropriate delays.

4. **Session Expiration**: Cookies may expire. The Playwright client creates a fresh browser session for each run.

5. **Data Accuracy**: Product information (especially prices and availability) may change frequently.

6. **Regional Differences**: Some products may only be available in specific regions.

7. **Performance**: The Playwright client launches a full browser, which is slower and more resource-intensive than direct API calls.

## Troubleshooting

### Issue: Empty product list returned

**Solution**:
- Verify the category slug or ID is correct
- Check if the category exists in your language
- Try with a different category

### Issue: HTTP 403 Forbidden

**Solution**:
- The server may have detected automated access
- Try adding longer delays between requests
- Ensure User-Agent and headers are properly set
- Consider using a different IP address or proxy

### Issue: Connection timeout

**Solution**:
- Increase the timeout parameter in requests
- Check your internet connection
- The Migros server may be temporarily unavailable

## Advanced Usage

### Custom Session Configuration

```python
import requests
from api_client import MigrosAPIClient

# Create custom session
session = requests.Session()
session.proxies = {
    'http': 'http://proxy:port',
    'https': 'http://proxy:port'
}

# Override client session
client = MigrosAPIClient(language="fr")
client.session = session
```

### Batch Processing with Progress Bar

```python
from tqdm import tqdm

client = MigrosAPIClient(language="fr")

category_slugs = ["fruits-legumes", "viande-poisson", "pain-patisseries"]

all_products = {}
for slug in tqdm(category_slugs, desc="Categories"):
    try:
        products = client.get_products_by_category_slug(slug)
        all_products[slug] = products
        print(f"  {slug}: {len(products)} products")
    except Exception as e:
        print(f"  Failed to fetch {slug}: {e}")

# Save all
import json
with open("all_products.json", "w") as f:
    json.dump(all_products, f, indent=2)
```

## Contributing

This is a reverse-engineered API client. The API structure may change without notice. If you encounter issues:

1. Check if the API endpoints have changed
2. Verify headers and authentication requirements
3. Update the client accordingly

## Legal Disclaimer

This tool is for educational purposes only. Please respect Migros' Terms of Service and robots.txt. Use responsibly and avoid overwhelming their servers with requests. Consider:

- Adding appropriate delays between requests
- Caching results when possible
- Using the official API if available
- Respecting rate limits

## License

MIT License - Use at your own risk
