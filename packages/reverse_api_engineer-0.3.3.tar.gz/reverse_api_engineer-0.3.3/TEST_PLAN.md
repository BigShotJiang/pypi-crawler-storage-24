# Test Plan: Persistent Script Saving

## Quick Verification Tests

### Test 1: Native Host Saving (Happy Path)
**Prerequisites**: Native host running (`reverse-api-engineer` CLI active)

**Steps**:
1. Open Chrome extension side panel
2. Switch to Codegen mode
3. Navigate to a test page (e.g., github.com)
4. Click "Start Recording" (Play button)
5. Perform some interactions (clicks, form fills, navigation)
6. Click "Stop Recording" (Stop button)

**Expected Results**:
- ✅ Script appears in code viewer
- ✅ Green success banner shows: "✓ Saved to filesystem"
- ✅ Banner displays truncated path: `.../scripts/{run_id}/codegen_script.py`
- ✅ Clicking path copies full path to clipboard
- ✅ File exists at: `~/.reverse-api/runs/scripts/{run_id}/codegen_script.py`
- ✅ README.md exists in same directory with metadata

**Verification Commands**:
```bash
# List recent script directories
ls -lat ~/.reverse-api/runs/scripts/ | head -5

# Check script and README exist
ls -l ~/.reverse-api/runs/scripts/{run_id}/

# View README content
cat ~/.reverse-api/runs/scripts/{run_id}/README.md
```

---

### Test 2: Fallback to Browser Download
**Prerequisites**: Native host NOT running (or disconnected)

**Steps**:
1. Stop CLI tool if running
2. Open Chrome extension
3. Start codegen recording
4. Perform interactions
5. Stop recording
6. Click Download button

**Expected Results**:
- ❌ No "Saved to filesystem" banner (native host not connected)
- ✅ Download button works
- ✅ File downloads with descriptive name: `codegen_2026-02-02.py` (not `code.py`)
- ✅ File appears in browser's Downloads folder

---

### Test 3: Session Persistence
**Prerequisites**: Native host running, one codegen script already saved

**Steps**:
1. Complete a codegen recording (with native host)
2. Note the saved path shown in UI
3. Create a new session (click "+ New Session")
4. Switch back to original session (via session selector)
5. Close extension and reopen
6. Check if saved path is still shown

**Expected Results**:
- ✅ Switching to new session: saved path banner disappears
- ✅ Switching back to original: saved path banner reappears with correct path
- ✅ After reopening extension: saved path restored from session data
- ✅ Script still visible in code viewer

---

### Test 4: URL/Domain Capture in Sessions
**Prerequisites**: None

**Steps**:
1. Navigate to https://github.com
2. Create a new session
3. Check session storage

**Expected Results**:
- ✅ Session object includes `url: "https://github.com"`
- ✅ Session object includes `domain: "github.com"`

**Verification**:
```javascript
// In browser console
chrome.storage.local.get('sessions', (data) => console.log(data))
```

---

### Test 5: Multiple Sessions with Different Scripts
**Prerequisites**: Native host running

**Steps**:
1. Create Session A, record script on github.com
2. Note saved path A
3. Create Session B, record script on google.com
4. Note saved path B
5. Switch between sessions

**Expected Results**:
- ✅ Each session has unique run_id and saved path
- ✅ Scripts saved to different directories
- ✅ Switching sessions shows correct saved path for each
- ✅ Both scripts persist and are accessible

---

### Test 6: Error Handling - Invalid Run ID
**Prerequisites**: Developer mode to test edge cases

**Steps**:
1. Manually send message to native host with invalid run_id:
```javascript
// In background script console
nativeHost.saveCodegenScript('../../../etc/passwd', 'malicious', 'test.py')
```

**Expected Results**:
- ✅ Native host rejects with error: "Invalid run_id format"
- ✅ No files created outside safe directory
- ✅ UI handles error gracefully

---

### Test 7: Copy Path to Clipboard
**Prerequisites**: Script already saved

**Steps**:
1. Click on the truncated path in the success banner
2. Paste into terminal or text editor

**Expected Results**:
- ✅ Full path copied to clipboard
- ✅ Path is valid and points to actual file
- ✅ Can navigate to file using copied path

---

### Test 8: README Content Verification
**Prerequisites**: Script saved via native host

**Steps**:
1. Complete a codegen recording
2. Navigate to saved directory
3. Open README.md

**Expected Results**:
- ✅ Contains "Generated: {timestamp}" with current date/time
- ✅ Contains "Run ID: {run_id}" matching directory name
- ✅ Contains usage instructions with correct filename
- ✅ Mentions Chrome Extension as source

---

## Edge Cases

### Edge Case 1: Permission Denied
**Scenario**: `~/.reverse-api/runs/scripts/` directory is read-only

**Expected**: Error message in native host response, UI shows no saved path banner

### Edge Case 2: Concurrent Sessions
**Scenario**: Two tabs with extension open, both recording different sessions

**Expected**: Each has unique run_id, no file conflicts, correct session-specific data

### Edge Case 3: Very Long Script
**Scenario**: Record 100+ interactions generating large script

**Expected**: Full script saved correctly, no truncation, README generated

### Edge Case 4: Special Characters in URL
**Scenario**: Session created on page with unicode/emoji in URL

**Expected**: Domain extracted correctly, no crashes, valid session data

---

## Performance Tests

### Performance 1: Save Speed
**Measure**: Time from "Stop Recording" to "Saved to filesystem" banner

**Expected**: < 500ms for typical script (< 10KB)

### Performance 2: UI Responsiveness
**Verify**: UI remains responsive during save operation

**Expected**: No freezing, can interact with other UI elements

---

## Regression Tests

### Regression 1: Existing Capture Mode
**Verify**: HAR capture still works as before

**Steps**:
1. Switch to Capture mode
2. Start capture
3. Generate traffic
4. Stop capture
5. Check HAR file saved

**Expected**: No changes to capture mode functionality

### Regression 2: Chat Functionality
**Verify**: Chat with AI agent still works

**Steps**:
1. Capture traffic
2. Send chat message
3. Receive AI response

**Expected**: No interference from new codegen save feature

---

## Browser Compatibility

- ✅ Chrome (primary target)
- ✅ Edge (Chromium-based)
- ✅ Brave (Chromium-based)

**Note**: Firefox not supported (different native messaging protocol)

---

## Platform Compatibility

### macOS
- ✅ Script saving to `~/Library/Application Support/reverse-api/runs/scripts/`
- ✅ Path display uses forward slashes

### Linux
- ✅ Script saving to `~/.reverse-api/runs/scripts/`
- ✅ Path display uses forward slashes

### Windows
- ✅ Script saving to `%APPDATA%\reverse-api\runs\scripts\`
- ✅ Path display uses backslashes (platform-specific)

---

## Automated Testing (Future)

Potential test suite structure:
```bash
# Python tests for native host
pytest tests/test_native_host_codegen_save.py

# TypeScript tests for extension
npm test -- --testPathPattern=codegen-save

# E2E tests with Playwright
playwright test tests/e2e/codegen-save.spec.ts
```
