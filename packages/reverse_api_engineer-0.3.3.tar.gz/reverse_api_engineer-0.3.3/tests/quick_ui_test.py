#!/usr/bin/env python
"""
Quick test to see the AskUserQuestion UI.
This runs a single example showing both single-select and multi-select questions.

Usage:
    uv run python quick_ui_test.py
"""

import asyncio
from pathlib import Path

from src.reverse_api.engineer import ClaudeEngineer


async def main():
    """Run a quick demo of the AskUserQuestion UI."""
    print("\n╔" + "=" * 68 + "╗")
    print("║" + " " * 20 + "Quick AskUserQuestion Demo" + " " * 22 + "║")
    print("╚" + "=" * 68 + "╝\n")
    print("This demonstrates what the agent sees when asking clarifying questions.")
    print("Use arrow keys to navigate, Space/Enter to select, Ctrl+C to cancel.\n")

    engineer = ClaudeEngineer(
        run_id="demo",
        har_path=Path("/tmp/demo.har"),
        prompt="demo",
        model="claude-sonnet-4-5",
    )

    # Simulate the agent asking multiple questions
    input_params = {
        "questions": [
            {
                "question": "Which authentication method should I prioritize?",
                "header": "Authentication",
                "options": [
                    {
                        "label": "Cookie-based session",
                        "description": "Uses session cookies stored in browser",
                    },
                    {
                        "label": "Bearer token",
                        "description": "Uses JWT or API tokens in headers",
                    },
                    {
                        "label": "Both with auto-detection",
                        "description": "Support both and detect automatically",
                    },
                ],
                "multiSelect": False,
            },
            {
                "question": "Which features should I include?",
                "header": "Features",
                "options": [
                    {
                        "label": "Retry logic",
                        "description": "Auto-retry failed requests",
                    },
                    {
                        "label": "Rate limiting",
                        "description": "Throttle requests to API limits",
                    },
                    {
                        "label": "Caching",
                        "description": "Cache responses locally",
                    },
                    {
                        "label": "Debug logging",
                        "description": "Comprehensive request/response logs",
                    },
                ],
                "multiSelect": True,
            },
        ]
    }

    result = await engineer._handle_ask_user_question("AskUserQuestion", input_params)

    print("\n" + "=" * 70)
    print("Agent received your answers:")
    print("=" * 70)
    if result.get("updatedInput", {}).get("answers"):
        for question, answer in result["updatedInput"]["answers"].items():
            print(f"\nQ: {question}")
            print(f"A: {answer}")
    print("\n" + "=" * 70)
    print("Demo complete! The agent would now use these answers to generate code.")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\nDemo cancelled.\n")
