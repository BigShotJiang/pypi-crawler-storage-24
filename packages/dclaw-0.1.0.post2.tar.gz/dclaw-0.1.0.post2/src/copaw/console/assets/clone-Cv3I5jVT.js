import{at as r}from"./index-BI80uauP.js";var a=4;function n(o){return r(o,a)}export{n as c};
