import{ar as o,as as s}from"./index-BI80uauP.js";const t=(r,a)=>o.lang.round(s.parse(r)[a]);export{t as c};
