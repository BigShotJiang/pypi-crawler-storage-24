from dataclasses import dataclass

@dataclass(frozen=True)
class BaseModelDescription:
    model_name: str
    description: str


@dataclass(frozen=True)
class SparseModelDescription(BaseModelDescription):
    requires_idf: bool | None = None
    vocab_size: int | None = None
