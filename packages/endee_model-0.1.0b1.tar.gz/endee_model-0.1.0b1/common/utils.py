import os
import re
from itertools import islice
from pathlib import Path
from typing import Iterable, TypeVar

from endee_model.constants import CACHE_PATH_ENV_VAR, DEFAULT_CACHE_DIR

T = TypeVar("T")


def batch_iter(iterable: Iterable[T], size: int) -> Iterable[list[T]]:
    """Split an iterable into batches of the given size.

    >>> list(batch_iter([1, 2, 3, 4, 5], 2))
    [[1, 2], [3, 4], [5]]
    """
    source_iter = iter(iterable)
    while True:
        batch = list(islice(source_iter, size))
        if not batch:
            break
        yield batch


def resolve_cache_dir(cache_dir: str | None = None) -> Path:
    """Resolve the cache directory.

    Priority:
        1. Explicit cache_dir argument
        2. ENDEE_CACHE_PATH environment variable
        3. <system_tmp>/endee_cache
    """
    if cache_dir is None:
        cache_path = Path(os.getenv(CACHE_PATH_ENV_VAR, DEFAULT_CACHE_DIR))
    else:
        cache_path = Path(cache_dir)

    cache_path.mkdir(parents=True, exist_ok=True)
    return cache_path


def clean_text(text: str) -> str:
    """Remove non-alphanumeric characters (keeps whitespace and word chars)."""
    return re.sub(r"[^\w\s]", " ", text, flags=re.UNICODE)
