from collections import defaultdict
from typing import Any, Iterable

import mmh3
import nltk
import numpy as np
from nltk.stem import SnowballStemmer

from endee_model.common.model_description import SparseModelDescription
from endee_model.common.utils import batch_iter, resolve_cache_dir
from endee_model.sparse.sparse_embedding_base import SparseEmbedding, SparseTextEmbedding
from endee_model.sparse.utils.tokenizer import NLTKTokenizer, unicode_punctuation


SNOWBALL_LANGUAGES: list[str] = sorted(
    lang for lang in SnowballStemmer.languages if lang != "porter"
)


def bm25_languages() -> list[str]:
    """List languages available for BM25.

    Args:
        stemming: If True, return languages that also support Snowball stemming.
                  If False, return all languages available via NLTK stopwords.

    Returns:
        Sorted list of language names.
    """
    return SNOWBALL_LANGUAGES


supported_bm25_models: list[SparseModelDescription] = [
    SparseModelDescription(
        model_name="endee/bm25",
        description="BM25 sparse embeddings. Use with IDF modifier in sparse vector index.",
        requires_idf=True,
        vocab_size=0,
    ),
]


class Bm25(SparseTextEmbedding):
    """BM25 sparse embeddings with NLTK tokenization and optional Snowball stemming.

    Computes the BM25 term-frequency part per document.
    Intended to be used with an IDF modifier on the vector index side.

    BM25 TF formula:
        tf(t, d) = f(t,d) * (k+1) / (f(t,d) + k * (1 - b + b * |d| / avg_len))

    Args:
        model_name: Model identifier.
        cache_dir: Directory to cache model files.
        k: Saturation parameter. Default 1.2.
        b: Length normalisation parameter. Default 0.75.
        avg_len: Expected average document length in tokens. Default 256.0.
        language: Language for NLTK stopwords and Snowball stemmer. Default "english".
        max_token_len: Tokens longer than this are discarded. Default 40.
        disable_stemmer: If True, skip Snowball stemming — all NLTK stopword languages available.
                         If False, Snowball stemming is applied — only stemmer-supported languages.
    """

    def __init__(
        self,
        model_name: str,
        cache_dir: str | None = None,
        k: float = 1.2,
        b: float = 0.75,
        avg_len: float = 256.0,
        language: str = "english",
        max_token_len: int = 40,
        disable_stemmer: bool = False,
        **kwargs: Any,
    ):
        super().__init__(model_name, cache_dir, **kwargs)

        self.k = k
        self.b = b
        self.avg_len = avg_len
        self.language = language
        self.max_token_len = max_token_len
        self.disable_stemmer = disable_stemmer
        self.cache_dir = str(resolve_cache_dir(cache_dir))

        self._punct: set[str] = unicode_punctuation()
        self._stopwords: set[str] = set(nltk.corpus.stopwords.words(language))
        self._stemmer = None if disable_stemmer else SnowballStemmer(language)
        self._tokenizer = NLTKTokenizer

    def _normalize(self, tokens: list[str]) -> list[str]:
        """Drop punctuation, stopwords, and oversized tokens; optionally stem."""
        out: list[str] = []
        for tok in tokens:
            if tok in self._punct or tok in self._stopwords or len(tok) > self.max_token_len:
                continue
            stemmed = self._stemmer.stem(tok) if self._stemmer else tok
            if stemmed:
                out.append(stemmed)
        return out

    def embed(
        self,
        documents: list[str],
        batch_size: int = 256,
        **kwargs: Any,
    ) -> Iterable[SparseEmbedding]:
        yield from self._stream_batches(documents, batch_size)

    def query_embed(
        self,
        query: str | list[str],
        **kwargs: Any,
    ) -> Iterable[SparseEmbedding]:
        """Embed queries with uniform token weights; IDF is applied on the index side."""
        if isinstance(query, str):
            query = [query]

        for text in query:
            tokens = self._tokenizer.tokenize(text.lower())
            clean = self._normalize(tokens)
            ids = np.array(
                list({self._to_id(t) for t in clean}),
                dtype=np.int32,
            )
            yield SparseEmbedding(indices=ids, values=np.ones_like(ids, dtype=np.float32))

    def token_count(self, texts: str | list[str], **kwargs: Any) -> int:
        if isinstance(texts, str):
            texts = [texts]
        return sum(len(self._tokenizer.tokenize(t.lower())) for t in texts)

    def _stream_batches(
        self,
        documents: list[str],
        batch_size: int,
    ) -> Iterable[SparseEmbedding]:
        for batch in batch_iter(documents, batch_size):
            yield from self._embed_batch(batch)

    def _embed_batch(self, documents: list[str]) -> list[SparseEmbedding]:
        result: list[SparseEmbedding] = []
        for doc in documents:
            tokens = self._tokenizer.tokenize(doc.lower())
            clean = self._normalize(tokens)
            result.append(SparseEmbedding.from_dict(self._tf_weights(clean)))
        return result

    def _tf_weights(self, tokens: list[str]) -> dict[int, float]:
        """Compute BM25 term-frequency weights for a tokenized document."""
        counts: defaultdict[str, int] = defaultdict(int)
        for tok in tokens:
            counts[tok] += 1

        doc_len = len(tokens)
        weights: dict[int, float] = {}
        for tok, freq in counts.items():
            weights[self._to_id(tok)] = freq * (self.k + 1) / (
                freq + self.k * (1 - self.b + (self.b * (doc_len / self.avg_len)))
            )
        return weights

    @classmethod
    def _to_id(cls, token: str) -> int:
        """Map a token to a stable non-negative integer via MurmurHash3."""
        return abs(mmh3.hash(token))
