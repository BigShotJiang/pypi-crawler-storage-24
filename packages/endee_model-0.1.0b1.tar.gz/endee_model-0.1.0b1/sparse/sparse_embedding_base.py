from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np
from numpy.typing import NDArray

from endee_model.common.types import NumpyArray


@dataclass
class SparseEmbedding:
    values: NumpyArray
    indices: NDArray[np.int64] | NDArray[np.int32]

    def as_object(self) -> dict[str, NumpyArray]:
        return {
            "values": self.values,
            "indices": self.indices,
        }

    def as_dict(self) -> dict[int, float]:
        return {int(i): float(v) for i, v in zip(self.indices, self.values)}

    @classmethod
    def from_dict(cls, data: dict[int, float]) -> "SparseEmbedding":
        if not data:
            return cls(values=np.array([]), indices=np.array([]))
        indices, values = zip(*data.items())
        return cls(values=np.array(values, dtype=np.float32), indices=np.array(indices, dtype=np.int32))


class SparseTextEmbedding:
    def __init__(self, model_name: str, cache_dir: str | None = None, **kwargs: Any):
        self.model_name = model_name
        self.cache_dir = cache_dir

    def embed(
        self,
        documents: list[str],
        batch_size: int = 256,
        **kwargs: Any,
    ) -> Iterable[SparseEmbedding]:
        raise NotImplementedError()

    def query_embed(
        self,
        query: str | list[str],
        **kwargs: Any,
    ) -> Iterable[SparseEmbedding]:
        raise NotImplementedError()

    def token_count(self, texts: str | list[str], **kwargs: Any) -> int:
        raise NotImplementedError()
