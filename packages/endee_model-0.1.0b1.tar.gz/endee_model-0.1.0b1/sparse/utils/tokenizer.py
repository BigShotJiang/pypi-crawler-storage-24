import sys
import unicodedata

from nltk.tokenize import word_tokenize


def unicode_punctuation() -> set[str]:
    """Build the full set of Unicode punctuation characters."""
    return {chr(i) for i in range(sys.maxunicode) if unicodedata.category(chr(i)).startswith("P")}


class NLTKTokenizer:
    """Word tokenizer backed by NLTK's word_tokenize."""

    @staticmethod
    def tokenize(text: str) -> list[str]:
        return word_tokenize(text)
