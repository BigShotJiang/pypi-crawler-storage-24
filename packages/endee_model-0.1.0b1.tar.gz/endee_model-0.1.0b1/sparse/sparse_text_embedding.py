from typing import Any, Iterable

from endee_model.sparse.bm25 import Bm25
from endee_model.sparse.sparse_embedding_base import SparseEmbedding, SparseTextEmbedding


class SparseModel(SparseTextEmbedding):
    """Public entry point for sparse text embeddings.

    Currently wraps Bm25. Extend this class to support additional
    sparse model types in the future.

    Args:
        model_name: Model identifier (e.g. "endee/bm25").
        cache_dir: Optional path for caching model files.
        **kwargs: Additional keyword arguments forwarded to the underlying model.
    """

    def __init__(
        self,
        model_name: str,
        cache_dir: str | None = None,
        **kwargs: Any,
    ):
        super().__init__(model_name, cache_dir, **kwargs)
        self.model = Bm25(model_name, cache_dir, **kwargs)

    def embed(
        self,
        documents: list[str],
        batch_size: int = 256,
        **kwargs: Any,
    ) -> Iterable[SparseEmbedding]:
        yield from self.model.embed(documents, batch_size, **kwargs)

    def query_embed(
        self,
        query: str | list[str],
        **kwargs: Any,
    ) -> Iterable[SparseEmbedding]:
        yield from self.model.query_embed(query, **kwargs)

    def token_count(self, texts: str | list[str], **kwargs: Any) -> int:
        return self.model.token_count(texts, **kwargs)
