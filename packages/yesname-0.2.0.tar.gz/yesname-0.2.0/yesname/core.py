def say_yes(name="Akshat"):
    return f"Yes {name}"

def say_no(name="Akshat"):
    return f"No {name}"

def greet(name="Akshat"):
    return f"Hello {name}, welcome!"

def shout_yes(name="Akshat"):
    return f"YES {name.upper()}!!!"

def repeat_yes(name="Akshat", times=3):
    return " ".join([f"Yes {name}"] * times)