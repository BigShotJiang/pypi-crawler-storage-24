import argparse
from .core import say_yes, say_no, greet, shout_yes, repeat_yes

def main():
    parser = argparse.ArgumentParser(description="YesName CLI Tool")

    parser.add_argument("--name", type=str, default="Akshat")
    parser.add_argument("--mode", type=str, default="yes",
                        choices=["yes", "no", "greet", "shout", "repeat"])
    parser.add_argument("--times", type=int, default=3)

    args = parser.parse_args()

    if args.mode == "yes":
        print(say_yes(args.name))
    elif args.mode == "no":
        print(say_no(args.name))
    elif args.mode == "greet":
        print(greet(args.name))
    elif args.mode == "shout":
        print(shout_yes(args.name))
    elif args.mode == "repeat":
        print(repeat_yes(args.name, args.times))