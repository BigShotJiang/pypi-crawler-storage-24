from setuptools import setup, find_packages

setup(
    name="yesname",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'yesname=yesname.cli:main',
        ],
    },
    author="Akshat Jain",
    description="A simple CLI tool that says Yes with your name",
)