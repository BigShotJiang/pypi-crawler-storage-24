import polars as pl

lf = pl.scan_parquet("diag.parquet")
lf_death = pl.scan_parquet("death.parquet")

lf_death = lf_death.rename(
    {"PNR": "case:concept:name", "DODDATO": "start_timestamp"}
).with_columns(
    pl.lit("DØD").alias("concept:name"),
    pl.col("start_timestamp").cast(pl.Datetime("us")),
)

lf = (
    pl.concat([lf, lf_death], how="diagonal")
    .sort("start_timestamp")
    .unique(
        subset=["case:concept:name", "concept:name"], keep="first", maintain_order=True
    )
)

# Computing the average time between diagnoses for each case, excluding the death event
lf = (
    lf.with_columns(
        pl.col("start_timestamp").diff().over("case:concept:name").alias("_tmp_diff")
    )
    .with_columns(
        pl.col("_tmp_diff")
        .filter(pl.col("concept:name") != "DØD")
        .mean()
        .over("case:concept:name")
        .alias("case:avg_inter_diagnosis_time")
    )
    .drop("_tmp_diff")
)

# Compute time to death from the last diagnosis for cases that ended with death, ensuring we only compute this if there are multiple events in the case (i.e., DØD isn't the only event)
lf = lf.with_columns(
    pl.when(
        (pl.col("concept:name") == "DØD")
        & (pl.len().over("case:concept:name") > 1)  # Ensure DØD isn't the only event
    )
    .then(
        pl.col("start_timestamp")
        - pl.col("start_timestamp").shift(1).over("case:concept:name")
    )
    .otherwise(None)
    .alias("case:time_to_death_from_last_diag")
)

# Computing variants
# 1. Group by case to get the sequence of events as a "variant"
lf_tmp = (
    lf.group_by("case:concept:name")
    .agg(
        pl.col("concept:name")
        .str.join(">")
        .str.replace(r">DØD$", "")
        .alias("variants"),
        pl.col("case:avg_inter_diagnosis_time").first(),
        pl.col("case:time_to_death_from_last_diag").last(),
        (pl.col("concept:name") != "DØD").sum().alias("diagnosis_count"),
        (pl.col("concept:name") == "DØD").any().alias("died"),
    )
    .with_columns(pl.col("died").mean().over("variants").alias("mortality_kpi"))
    .drop("died")
)

lf_summary = lf_tmp.group_by("variants").agg(
    pl.col("mortality_kpi").first(),
    pl.len().alias("count"),
    pl.col("diagnosis_count").first(),
    pl.col("case:avg_inter_diagnosis_time").mean().alias("avg_avg_inter_diagnosis_time"),
    pl.col("case:time_to_death_from_last_diag")
    .mean()
    .alias("avg_inter_diagnosis_time_to_death"),
)

# Joining the KPI back to the main log for further analysis or export
patient_kpi_map = lf_tmp.select(
    [
        pl.col("case:concept:name"),
        pl.col("mortality_kpi").alias("case:mortality_kpi"),
        pl.col("case:avg_inter_diagnosis_time"),
        pl.col("case:time_to_death_from_last_diag"),
    ]
)
lf = lf.join(patient_kpi_map, on="case:concept:name", how="left")
