# Copyright 2024 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Author: Zehao Zhou  zehaozhoucase@gmail.com



import numpy as np
import scipy
import gc, os
from pyscf.lib import einsum

from pyscf.lib.misc import current_memory
# from pyscf import __config__
# MAX_MEMORY = getattr(__config__, 'MAX_MEMORY') # in MB

import re

FALLBACK_MB = 32000

MAX_MEMORY_MB = int(os.environ.get('PYSCF_MAX_MEMORY', 0))

if MAX_MEMORY_MB <= 0:
    try:
        with open('/proc/meminfo') as f:
            content = f.read()
        m = re.search(r'^MemTotal:\s+(\d+)', content, re.M)
        if m:
            kb = int(m.group(1))
            MAX_MEMORY_MB = kb // 1024
        else:
            MAX_MEMORY_MB = FALLBACK_MB
    except OSError:
        MAX_MEMORY_MB = FALLBACK_MB

MAX_MEMORY = MAX_MEMORY_MB / 1024 # in GB

def get_mem_info(words):
    rss = current_memory()[0] / 1024  # MB to GB
    memory_info = f"{words:35s} *** mem info: {rss:5.1f} / {MAX_MEMORY:5.1f} GB "
    return memory_info

def get_avail_cpumem():
    rss = current_memory()[0]  # in MB
    free_mem = MAX_MEMORY*1024 - rss
    free_mem *= 1024**2  # in bytes
    return free_mem


def TDA_diag_initial_guess(V_holder, N_states, hdiag):
    '''
    N_states is the amount of initial guesses
    sort out the smallest value of hdiag, the corresponding position in the
    initial guess set as 1.0, everywhere else set as 0.0
    '''
    hdiag = hdiag.reshape(-1,)
    Dsort = hdiag.argsort()[:N_states]
    V_holder[np.arange(N_states), Dsort] = 1.0
    return V_holder

def TDA_diag_preconditioner(residual, omega, hdiag):
    '''
    DX - XΩ = r
    '''

    N_states = np.shape(residual)[0]
    t = 1e-14

    omega = omega.reshape(-1,1)
    D = np.repeat(hdiag.reshape(1,-1), N_states, axis=0) - omega
    '''
    force all small values not in [-t,t]
    '''
    D = np.where( abs(D) < t, np.sign(D)*t, D)
    new_guess = residual/D

    return new_guess

def TDDFT_diag_preconditioner(R_x, R_y, omega, hdiag):
    '''
    preconditioners for each corresponding residual (state)
    '''
    N_states = R_x.shape[0]
    t = 1e-8
    d = np.repeat(hdiag.reshape(1,-1), N_states, axis=0)

    omega = omega.reshape(-1,1)
    D_x = d - omega
    D_x = np.where(abs(D_x) < t, np.sign(D_x)*t, D_x)
    D_x_inv = D_x**-1

    D_y = d + omega
    D_y = np.where(abs(D_y) < t, np.sign(D_y)*t, D_y)
    D_y_inv = D_y**-1

    X_new = R_x*D_x_inv
    Y_new = R_y*D_y_inv
    return X_new, Y_new


def level_shit_index(eigenvalue):
    for i in range(len(eigenvalue)):
        if eigenvalue[i] > 1e-3:
            return i



def commutator(A,B):
    commu = np.dot(A,B) - np.dot(B,A)
    return commu

def cond_number(A):
    s,u = np.linalg.eig(A)
    s = abs(s)
    cond = max(s)/min(s)
    return cond

def matrix_power(S,a, epsilon=None):
    '''X == S^a'''
    s,ket = np.linalg.eigh(S)
    # s = s**a
    if epsilon:
        if s[0] < epsilon:
            raise LinearDependencyError(f'Matrix is singular. Min eigen = {s[0]}')
        valid_indices = s >= epsilon
        s = s[valid_indices]
        ket = ket[:, valid_indices]

    s = s**a

    X = np.dot(ket*s,ket.T)

    return X

def Gram_Schmidt_bvec(V, bvec):
    '''orthonormalize vector b against all vectors in V
       b = b - (V@b.T).T @ V
       suppose V is orthonormalized
       V maybe numpy array
    '''
    if V.shape[0] == 0:
        return bvec

    else:
        # projections_coeff = einsum('ab,cb->ac', V, bvec)
        # tmp = einsum('ac,ab->cb',projections_coeff, V)
        # bvec -= tmp
        # return bvec
        n_old_vectors, A_size = V.shape
        n_new_vectors, _      = bvec.shape

        estimated_chunk_size_bytes = (A_size + n_new_vectors) * bvec.itemsize
        chunk_size = max(1, int(get_avail_cpumem() * 0.8 // estimated_chunk_size_bytes))

        for p0 in range(0, n_old_vectors, chunk_size):
            p1 = min(p0 + chunk_size, n_old_vectors)

            V_chunk = V[p0:p1, :]  # (chunk_size, A_size)

            projections_coeff = einsum('ab,cb->ac', V_chunk, bvec)  # (chunk_size, n_new_vectors)

            # bvec = einsum('ac,ab->cb', projections_coeff, V_chunk, -1 , 1, out=bvec)  # (n_new_vectors, A_size)
            tmp = einsum('ac,ab->cb', projections_coeff, V_chunk)
            del V_chunk, projections_coeff
            bvec -= tmp
            del tmp, projections_coeff, V_chunk

            gc.collect()

        return bvec



def VW_Gram_Schmidt(x, y, V, W):
    '''orthonormalize vector |x,y> against all vectors in |V,W>'''

    m = np.dot(V, x.T) + np.dot(W, y.T)

    n = np.dot(W, x.T) + np.dot(V, y.T)

    x = x - np.dot(m.T, V) - np.dot(n.T, W)

    y = y - np.dot(m.T, W) - np.dot(n.T, V)

    return x, y

def block_symmetrize(A,m,n):
    A[m:n,:m] = A[:m,m:n].T
    return A

def gen_anisotropy(a):

    # an alternative formula for anisotropy:
    # anis = (xx-yy)**2 + (yy-zz)**2 + (zz-xx)**2 + 6*(xz**2 + xy**2 + yz**2)
    # anis = 0.5*anis
    # anis = anis**0.5

    a = 0.5*(a.T + a)
    tr = (1.0/3.0)*np.trace(a)
    xx = a[0,0]
    yy = a[1,1]
    zz = a[2,2]

    xy = a[0,1]
    xz = a[0,2]
    yz = a[1,2]

    ssum = xx**2 + yy**2 + zz**2 + 2*(xy**2 + xz**2 + yz**2)
    anis = (1.5 * abs(ssum - 3*tr**2))**0.5
    return float(tr), float(anis)

def utriangle_symmetrize(A):
    upper = np.triu_indices(n=A.shape[0], k=1)
    lower = (upper[1], upper[0])
    A[lower] = A[upper]
    return A

def anti_block_symmetrize(A,m,n):
    A[m:n,:m] = -A[:m,m:n].T
    return A



def gen_VW(sub_A_holder, V_holder, W_holder, size_old, size_new, symmetry=False):
    '''

    [ V_old ] [W_old.T, W_new.T] = [VW_old,        V_old W_new.T] = [VW_old,   V_old W_new.T  ]
    [ V_new ]                      [V_new W_old.T, V_new W_new.T]   [  V_new  W_current.T     ]

    symmetry: whether sub_A is symmatric

                        V_holder (W_holder is same set up)

            |------------------------------------------------|
            |      V_old                                     |
size_old    |------------------------------------------------|  [ V_current ]
            |      V_new                                     |
size_new    |------------------------------------------------|
            |                                                |
            |      empty                                     |
            |                                                |
            |------------------------------------------------|




    sub_A_holder

                            size_old            size_new
                |---------------|-----------------|-----------------|
                |               |                 |                 |
                |               |                 |                 |
                | V_old W_old.T |  V_old W_new.T  |                 |
                |  (=sub_A_old) |                 |                 |
                |               |                 |                 |
      size_old  |---------------(V_currentW_new.T)|-----------------|
                | if symmetry:  |                 |                 |
                | V_new W_old.T |  V_new W_new.T  |                 |
                |               |                 |                 |
                |               |                 |                 |
                |               |                 |                 |
      size_new  |---------------------------------|-----------------|
                |               |                 |                 |
                |               |                 |                 |
                |               |                 |                 |
                |               |                 |                 |
                |               |                 |                 |
                |               |                 |                 |
                |---------------|-----------------|-----------------|
    '''


    # W_new = W_holder[size_old:size_new, :]

    # sub_A_tmp = dot_product_Vchunk_W(V_holder, W_new, size_bound=size_new, factor=0.6)
    sub_A_tmp = einsum('mn,ln->ml', V_holder[:size_new,:],W_holder[size_old:size_new, :])

    sub_A_holder[:size_new, size_old:size_new] = sub_A_tmp
    del sub_A_tmp
    gc.collect()

    if size_old > 0:
        if symmetry:
            sub_A_tmp = sub_A_holder[:size_old, size_old:size_new].T

            sub_A_holder[size_old:size_new, :size_old] = sub_A_tmp
            del sub_A_tmp
            gc.collect()
        else:
            # sub_A_tmp = dot_product_Vchunk_W(W_holder, V_new, size_bound=size_old, factor=0.6).T
            sub_A_tmp = einsum('mn,ln->lm', W_holder[:size_old, :], V_holder[size_old:size_new,:])
            sub_A_holder[size_old:size_new, :size_old] = sub_A_tmp
            del sub_A_tmp
            gc.collect()
    return sub_A_holder



# def dot_product_Vchunk_W(A, B, size_bound, factor=0.8):
#     '''
#     A: np.ndarray (m , n)
#     B.T: np.ndarray (l, n)
#     a = n_occ * n_vir
#     return A.dot(B.T)
#     '''
#     _,n = A.shape
#     l,n = B.shape

#     m0 = get_avail_cpumem()

#     AB = np.empty((size_bound, l), dtype=B.dtype)

#     chunk_bytes_B = (n + l) * B.itemsize
#     chunk_bytes_A = n * A.itemsize

#     # Estimate the optimal chunk size based on available memory
#     chunk_size_B = int((get_avail_cpumem() * factor ) // chunk_bytes_B)

#     chunk_size_A = int((get_avail_cpumem() * factor ) // chunk_bytes_A)
#     chunk_size = min(chunk_size_B, chunk_size_A, size_bound)

#     for p0 in range(0, size_bound, chunk_size):
#         p1 = min(p0 + chunk_size, size_bound)

#         A_chunk = A[p0:p1, :]
#         # AB_chunk = A_chunk.dot(B)
#         AB_chunk = einsum('mn,ln->ml',A_chunk,B)

#         AB[p0:p1,:] = AB_chunk
#         # np.cuda.get_current_stream().synchronize()

#         del  A_chunk, AB_chunk
#         gc.collect()

#     m1 = get_avail_cpumem()
#     m_diff = m1 - m0
#     if m_diff > 1e6:
#         pass

#     return AB


# def dot_product_xchunk_V(A, B, factor=0.8, alpha=1, beta=1, out=None):

#     '''
#     A: np.ndarray (m,n)
#     B: np.ndarray(n,l)
#     n = size_bound
#     return A.dot(B)

#                 subspace_size                           A_size
#             |-----------------||----------------------------------------------------------------|
#     n_states|-----------------||----------------------------------------------------------------|
#             |-----------------||----------------------------------------------------------------|
#                                |----------------------------------------------------------------|
#                                |----------------------------------------------------------------|
#                                |----------------------------------------------------------------|
#                                |----------------------------------------------------------------|
#         -> (n_sttates, A_size)

#     '''
#     m,n = A.shape
#     size_bound,l = B.shape
#     assert n == size_bound
#     m0 = get_avail_cpumem()
#     # alpha = A.dtype.type(alpha)
#     # beta = A.dtype.type(beta)
#     if out is None:
#         out = np.zeros((m, l), dtype=A.dtype)
#     out *= beta
#     chunk_bytes_A = (m+l) * A.itemsize
#     chunk_bytes_B = l * B.itemsize

#     # Estimate the optimal chunk size based on available memory
#     chunk_size_A = int((get_avail_cpumem() * factor ) // chunk_bytes_A)
#     chunk_size_B = int((get_avail_cpumem() * factor ) // chunk_bytes_B)


#     chunk_size = min(chunk_size_B, chunk_size_A, size_bound)

#     for p0 in range(0, size_bound, chunk_size):
#         p1 = min(p0 + chunk_size, size_bound)

#         A_chunk = A[:,p0:p1]
#         B_chunk = B[p0:p1, :]

#         # out = einsum('mn,nl->ml',A[:,p0:p1], B_chunk, alpha=alpha, beta=beta, out=out)
#         # out += alpha*einsum('mn,nl->ml',A[:,p0:p1], B_chunk)
#         tmp = einsum('mn,nl->ml',A_chunk, B_chunk)
#         del A_chunk, B_chunk
#         tmp *= alpha
#         out += tmp
#         del tmp

#         gc.collect()

#     m1 = get_avail_cpumem()
#     m_diff = m1 - m0
#     if m_diff > 1e6:
#         pass
#     return out


def gen_VP(sub_rhs_holder, V_holder, rhs, size_old, size_new):
    '''
    [ V_old ] [rhs.T] = [V_old rhs.T]
    [ V_new ]           [V_new rhs.T]
    '''
    V_new = V_holder[size_old:size_new:,:]
    # sub_rhs_holder[size_old:size_new,:] = np.dot(V_new, rhs.T)
    sub_rhs_holder[size_old:size_new,:] = einsum('mn,ln->ml', V_new, rhs)
    return sub_rhs_holder


def gen_sub_pq(V_holder, W_holder, P, Q, VP_holder, WQ_holder, WP_holder, VQ_holder, size_old, size_new):
    '''
    [ V_old ] [rhs.T] = [V_old rhs.T]
    [ V_new ]           [V_new rhs.T]
    '''
    VP_holder = gen_VP(VP_holder, V_holder, P, size_old, size_new)

    VQ_holder = gen_VP(VQ_holder, V_holder, Q, size_old, size_new)

    WP_holder = gen_VP(WP_holder, W_holder, P, size_old, size_new)

    WQ_holder = gen_VP(WQ_holder, W_holder, Q, size_old, size_new)

    p = VP_holder[:size_new,:] + WQ_holder[:size_new,:]
    q = WP_holder[:size_new,:] + VQ_holder[:size_new,:]

    return p, q, VP_holder, WQ_holder, WP_holder, VQ_holder


def gen_sub_ab(V_holder, W_holder, U1_holder, U2_holder,
              VU1_holder, WU2_holder, VU2_holder, WU1_holder,
              VV_holder, WW_holder, VW_holder,
              size_old, size_new):
    '''
    a = V U1.T + W U2.T
    b = V U2.T + W U1.T
    sigma = V V.T - W W.T
    pi = V W.T - V W.T.T


    '''

    # VU1_holder = gen_VW(VU1_holder, V_holder, U1_holder, size_old, size_new, symmetry=False)
    # VU2_holder = gen_VW(VU2_holder, V_holder, U2_holder, size_old, size_new, symmetry=False)
    # WU1_holder = gen_VW(WU1_holder, W_holder, U1_holder, size_old, size_new, symmetry=False)
    # WU2_holder = gen_VW(WU2_holder, W_holder, U2_holder, size_old, size_new, symmetry=False)

    # VV_holder = gen_VW(VV_holder, V_holder, V_holder, size_old, size_new, symmetry=False)
    # WW_holder = gen_VW(WW_holder, W_holder, W_holder, size_old, size_new, symmetry=False)
    # VW_holder = gen_VW(VW_holder, V_holder, W_holder, size_old, size_new, symmetry=False)
    gen_VW(VU1_holder, V_holder, U1_holder, size_old, size_new, symmetry=False)
    gen_VW(VU2_holder, V_holder, U2_holder, size_old, size_new, symmetry=False)
    gen_VW(WU1_holder, W_holder, U1_holder, size_old, size_new, symmetry=False)
    gen_VW(WU2_holder, W_holder, U2_holder, size_old, size_new, symmetry=False)

    gen_VW(VV_holder, V_holder, V_holder, size_old, size_new, symmetry=False)
    gen_VW(WW_holder, W_holder, W_holder, size_old, size_new, symmetry=False)
    gen_VW(VW_holder, V_holder, W_holder, size_old, size_new, symmetry=False)

    sub_A = VU1_holder[:size_new, :size_new] + WU2_holder[:size_new, :size_new]
    sub_A = utriangle_symmetrize(sub_A)

    sub_B = VU2_holder[:size_new, :size_new] + WU1_holder[:size_new, :size_new]
    sub_B = utriangle_symmetrize(sub_B)

    sigma = VV_holder[:size_new, :size_new] - WW_holder[:size_new, :size_new]
    sigma = utriangle_symmetrize(sigma)

    pi = VW_holder[:size_new, :size_new] - VW_holder[:size_new, :size_new].T

    return sub_A, sub_B, sigma, pi, VU1_holder, WU2_holder, VU2_holder, WU1_holder, VV_holder, WW_holder, VW_holder


def Gram_Schmidt_fill_holder(V, count, vecs, double = True):
    '''V is a vectors holder
       count is the amount of vectors that already sit in the holder
       nvec is amount of new vectors intended to fill in the V
       count will be final amount of vectors in V

       this version is io-efficeint
    '''
    # if count == 0:
    #     return V

    n_new_vectors, A_size = vecs.shape
    assert V.shape[1] == A_size
    assert n_new_vectors >=1
    # print('n_new_vectors', n_new_vectors)

    if count >= 1:
        ''' first GS all the vecs against V[:count, :]'''

        projections_coeff = einsum('ab,cb->ac', V[:count,:], vecs)  # (chunk_size, n_new_vectors)
        # vecs = einsum('ac,ab->cb', projections_coeff, V_chunk, -1 , 1, out=vecs)  # (n_new_vectors, A_size)

        tmp = einsum('ac,ab->cb', projections_coeff, V[:count,:])
        vecs -= tmp
        del tmp, projections_coeff

        if double:
            projections_coeff = einsum('ab,cb->ac', V[:count,:], vecs)  # (chunk_size, n_new_vectors)
            # vecs = einsum('ac,ab->cb', projections_coeff, V_chunk, -1 , 1, out=vecs)  # (n_new_vectors, A_size)
            tmp = einsum('ac,ab->cb', projections_coeff, V[:count,:])
            vecs -= tmp
            del tmp, projections_coeff
            gc.collect()

    ''' second GS vecs between themselves'''
    p0 = 0
    for i in range(n_new_vectors):
        vec = vecs[p0,:].reshape(1,-1)
        # print('vec.shape', vec.shape)
        norm = np.linalg.norm(vec)

        if norm > 1e-14:
            vec /= norm
            V[count,:] = vec

            count += 1
        else:
            p0 += 1
            continue

        if p0+1 == n_new_vectors:
            break

        other_vec = vecs[p0+1:,:]
        # print('other_vec.shape', other_vec.shape)

        projections_coeff = einsum('ab,cb->ac', vec, other_vec)
        # other_vec = einsum('ac,ab->cb',projections_coeff, vec, alpha=-1, beta=1, out=other_vec)
        tmp = einsum('ac,ab->cb', projections_coeff, vec)
        other_vec -= tmp
        del tmp, projections_coeff
        gc.collect()
        if double:
            projections_coeff = einsum('ab,cb->ac', vec, other_vec)
            # other_vec = einsum('ac,ab->cb',projections_coeff, vec, alpha=-1, beta=1, out=other_vec)
            tmp = einsum('ac,ab->cb', projections_coeff, vec)
            other_vec -= tmp
            del tmp, projections_coeff
            gc.collect()
        p0 += 1
        # return bvec
    new_count = count
    return new_count


def nKs_fill_holder(V, count, vecs, double=True):
    '''V is a vectors holder
       count is the amount of vectors that already sit in the holder
       nvec is amount of new vectors intended to fill in the V
       count will be final amount of vectors in V
    '''
    nvec = vecs.shape[0]
    for j in range(nvec):
        vec = vecs[j,:].reshape(1,-1)
        norm = np.linalg.norm(vec)
        if norm > 1e-14:
            vec = vec/norm
            V[count,:] = vec
            del vec
            gc.collect()
            count += 1

    new_count = count
    return new_count

def S_symmetry_orthogonal(x,y):
    '''symmetrically orthogonalize the vectors |x,y> and |y,x>
       as close to original vectors as possible
    '''
    x_p_y = x + y
    x_p_y_norm = np.linalg.norm(x_p_y)

    x_m_y = x - y
    x_m_y_norm = np.linalg.norm(x_m_y)

    a = x_p_y_norm/x_m_y_norm

    x_p_y = x_p_y/2
    x_m_y = x_m_y * a/2

    new_x = x_p_y + x_m_y
    new_y = x_p_y - x_m_y

    return new_x, new_y

def symmetrize(A):
    A = (A + A.T)/2
    return A

def anti_symmetrize(A):
    A = (A - A.T)/2
    return A

def check_orthonormal(A):
    '''
    define the orthonormality of a matrix A as the norm of (A.T*A - I)
    '''
    B = einsum('ij,ij->i', A, A)
    B -= 1
    return np.linalg.norm(B)


def check_anti_symmetry(A):
    '''
    check whether matrix A is anti-symmetric
    '''
    a = np.linalg.norm(A + A.T)
    return a

def VW_Gram_Schmidt_fill_holder(V_holder, W_holder, m, X_new, Y_new, double=False):
    '''
    put X_new into V, and Y_new into W
    m: the amount of vectors that already on V or W
    nvec: amount of new vectors intended to put in the V and W
    '''
    nvec = X_new.shape[0]


    for j in range(0, nvec):
        V = V_holder[:m,:]
        W = W_holder[:m,:]

        x_tmp = X_new[j,:].reshape(1,-1)
        y_tmp = Y_new[j,:].reshape(1,-1)

        x_tmp,y_tmp = VW_Gram_Schmidt(x_tmp, y_tmp, V, W)
        if double:
            x_tmp,y_tmp = VW_Gram_Schmidt(x_tmp, y_tmp, V, W)

        x_tmp,y_tmp = S_symmetry_orthogonal(x_tmp,y_tmp)

        xy_norm = (np.dot(x_tmp, x_tmp.T) + np.dot(y_tmp, y_tmp.T))**0.5


        if xy_norm > 1e-14:
            x_tmp = x_tmp/xy_norm
            y_tmp = y_tmp/xy_norm

            V_holder[m,:] = x_tmp[0,:]
            W_holder[m,:] = y_tmp[0,:]
            m += 1
        else:
            pass
    new_m = m

    return V_holder, W_holder, new_m


def VW_nKs_fill_holder(V_holder, W_holder, m, X_new, Y_new, double=False):
    nvec = X_new.shape[0]
    for j in range(0, nvec):
        x_tmp = X_new[j,:].reshape(1,-1)
        y_tmp = Y_new[j,:].reshape(1,-1)
        x_tmp,y_tmp = S_symmetry_orthogonal(x_tmp,y_tmp)
        xy_norm = (np.dot(x_tmp, x_tmp.T) + np.dot(y_tmp, y_tmp.T))**0.5
        x_tmp = x_tmp/xy_norm
        y_tmp = y_tmp/xy_norm

        if xy_norm > 1e-18:
            x_tmp = x_tmp/xy_norm
            y_tmp = y_tmp/xy_norm

            V_holder[m,:] = x_tmp[0,:]
            W_holder[m,:] = y_tmp[0,:]
            m += 1
        else:
            pass

    new_m = m
    return V_holder, W_holder, new_m


def solve_AX_Xla_B(A, omega, Q):
    '''AX - XΩ  = Q
       A, Ω, Q are known, solve X
       Q is column-wise vectors

       Au = ua -> A = uau.T , u.Tu = uu.T = I,  u is column-wise vectors
       (u a u.T) X - XΩ  = Q
       u.T (u a u.T) X - u.T XΩ  = u.T Q
       a (u.T X) - (u.T X)Ω  = (u.T Q)
       au
    '''
    Qnorm = np.linalg.norm(Q, axis=0, keepdims=True)
    Q = Q/Qnorm
    N_vectors = len(omega)
    a, u = np.linalg.eigh(A)
    uq = np.dot(u.T, Q)
    ux = np.zeros_like(Q)
    for k in range(N_vectors):
        ux[:, k] = uq[:, k]/(a - omega[k])
    X = np.dot(u, ux)
    X *= Qnorm
    return X

def solve_AX_SX(A, S):
    '''                        AX = SXΩ
                               AX = (d^-1/2 S d^-1/2) d^1/2 XΩ
        d^-1/2 A (d^-1/2 d^1/2) X = L L.T d^1/2 X Ω
        d^-1/2 A d^-1/2 L^-1.T L.T d^1/2 X   = L L.T d^1/2 X Ω
        {L^-1 d^-1/2 A d^-1/2 L^-T} {L.T d^1/2 X}  = {L.T d^1/2 X} Ω
        M Z = Z Ω
        M = L^-1 d^-1/2 A d^-1/2 L^-T
        Z = L.T d^1/2 X
        X  = d^-1/2 L^-T Z
    '''
    A = np.asarray(A)
    S = np.asarray(S)

    d = np.diag(S)
    sqrt_d_inv = np.sqrt(1.0 / d)

    precond_S = sqrt_d_inv[:, None] * S * sqrt_d_inv[None, :]
    # np.fill_diagonal(precond_S, 1.0)

    L = np.linalg.cholesky(precond_S)
    L_inv = scipy.linalg.solve_triangular(L, np.eye(L.shape[0]), lower=True)
    L_invT = L_inv.T
    M = L_inv.dot( sqrt_d_inv[:, None] * A * sqrt_d_inv[None, :] ).dot( L_invT )

    omega, Z = np.linalg.eigh(M)
    X = sqrt_d_inv[:, None] * (L_invT.dot(Z))

    DEBUG = False
    if DEBUG:
        omega_scipy, x_scipy = scipy.linalg.eigh(A, S)
        x_scipy = np.array(x_scipy)
        assert np.linalg.norm(abs(X) - abs(x_scipy)) < 1e-10
    return omega, X

def TDDFT_subspace_eigen_solver2(a, b, sigma, pi, nroots):
    ''' [ a b ] x - [ σ   π] x  Ω = 0 '''
    ''' [ b a ] y   [-π  -σ] y    = 0 '''
    original_dtype = a.dtype
    if original_dtype != np.float64:
        a = a.astype(np.float64)
        b = b.astype(np.float64)
        sigma = sigma.astype(np.float64)
        pi = pi.astype(np.float64)

    d = abs(np.diag(sigma))
    d_mh = d**(-0.5)

    s_m_p = np.einsum('i,ij,j->ij', d_mh, sigma - pi, d_mh)

    '''LU = d^−1/2 (σ − π) d^−1/2'''
    ''' A = LU '''
    L, U = scipy.linalg.lu(s_m_p, permute_l=True)
    L_inv = np.linalg.inv(L)
    U_inv = np.linalg.inv(U)


    U_invT = U_inv.T
    '''U^-T d^−1/2 (a−b) d^-1/2 U^-1 = GG^T '''
    d_amb_d = np.einsum('i,ij,j->ij', d_mh, a-b, d_mh)
    GGT = np.dot(U_invT, np.dot(d_amb_d, U_inv))

    G = np.linalg.cholesky(GGT)
    if np.any(np.isnan(G)):
        eig, eigv = np.linalg.eigh(GGT)
        if eig[0] < -1e-4:
            error_msg = (
                "GGT matrix is not positive definite.\n"
                "SCF not correctly converged is likely to cause this error.\n"
                "For example, scf converged to the wrong state.\n"
            )
            raise RuntimeError(error_msg)

    G_inv = np.linalg.inv(G)

    ''' M = G^T L^−1 d^−1/2 (a+b) d^−1/2 L^−T G '''
    d_apb_d = np.einsum('i,ij,j->ij', d_mh, a+b, d_mh)
    M = np.dot(G.T, np.dot(L_inv, np.dot(d_apb_d, np.dot(L_inv.T, G))))

    omega2, Z = np.linalg.eigh(M)
    if np.any(omega2 <= 0):
        idx = np.nonzero(omega2 > 0)[0]
        omega2 = omega2[idx[:nroots]]
        Z = Z[:,idx[:nroots]]
    else:
        omega2 = omega2[:nroots]
        Z = Z[:,:nroots]
    omega = omega2**0.5

    ''' It requires Z^T Z = 1/Ω '''
    ''' x+y = d^−1/2 L^−T GZ Ω^-0.5 '''
    ''' x−y = d^−1/2 U^−1 G^−T Z Ω^0.5 '''
    x_p_y = np.einsum('i,ik,k->ik', d_mh, L_inv.T.dot(G.dot(Z)), omega**-0.5)
    x_m_y = np.einsum('i,ik,k->ik', d_mh, U_inv.dot(G_inv.T.dot(Z)), omega**0.5)

    x = (x_p_y + x_m_y)/2
    y = x_p_y - x

    if original_dtype != np.float64:
        omega = omega.astype(original_dtype)
        x = x.astype(original_dtype)
        y = y.astype(original_dtype)
    return omega, x, y

def TDDFT_subspace_eigen_solver3(a, b, sigma, pi, k):
    ''' [ a b ] x - [ σ   π] x  Ω = 0
        [ b a ] y   [-π  -σ] y    = 0
        AT=BTΩ
        B^-1/2 A B^-1/2 B^1/2 T = B^1/2 T Ω
        MZ = Z Ω
        M = B^-1/2 A B^-1/2
        Z = B^1/2 T
    '''
    half_size = a.shape[0]
    A = np.empty((2*half_size,2*half_size))
    A[:half_size,:half_size] = a[:,:]
    A[:half_size,half_size:] = b[:,:]
    A[half_size:,:half_size] = b[:,:]
    A[half_size:,half_size:] = a[:,:]

    B = np.empty_like(A)
    B[:half_size,:half_size] = sigma[:,:]
    B[:half_size,half_size:] = pi[:,:]
    B[half_size:,:half_size] = -pi[:,:]
    B[half_size:,half_size:] = -sigma[:,:]
    #B^-1/2
    B_neg_tmp = matrix_power(B, -0.5)
    M = np.dot(B_neg_tmp, A)  # B^-1/2 A
    M = np.dot(M, B_neg_tmp)  # B^-1/2 A B^-1/2
    omega, Z = np.linalg.eigh(M)

    omega = omega[half_size:k]
    Z = Z[:, half_size:k]

    T = np.dot(B_neg_tmp, Z)
    x = T[:half_size,:]
    y = T[half_size:,:]

    return omega, x, y

def TDDFT_subspace_eigen_solver(a, b, sigma, pi, k):
    ''' [ a b ] x - [ σ   π] x  Ω = 0
        [ b a ] y   [-π  -σ] y    = 0
        AT=BTΩ
        A^1/2 T = A^-1/2 B A^-1/2 A^1/2 T Ω
        MZ = Z 1/Ω
        M = A^-1/2 B A^-1/2 A^1/2
        Z = A^1/2 T
        Z is always returned as normlized vectors, which are not what we wanted
        because Z^T Z = [x]^T A^1/2 A^1/2 [x] = [x]^T [ a b ] [x] =  [x]^T [ σ   π] x Ω = Ω
                        [y]               [y]   [y]   [ b a ] [y]    [y]   [-π  -σ] y
        therefore Z=Z*(Ω**0.5)
        k: N_states
    '''
    half_size = a.shape[0]
    A = np.empty((2*half_size,2*half_size))
    A[:half_size,:half_size] = a[:,:]
    A[:half_size,half_size:] = b[:,:]
    A[half_size:,:half_size] = b[:,:]
    A[half_size:,half_size:] = a[:,:]
    B = np.empty_like(A)
    B[:half_size,:half_size] = sigma[:,:]
    B[:half_size,half_size:] = pi[:,:]
    B[half_size:,:half_size] = -pi[:,:]
    B[half_size:,half_size:] = -sigma[:,:]
    #A^-1/2
    A_neg_tmp = matrix_power(A, -0.5, 1e-14)
    M = np.dot(A_neg_tmp, B)
    M = np.dot(M,A_neg_tmp )
    omega, Z = np.linalg.eigh(M)

    omega = 1/omega[-k:][::-1]
    Z = Z[:, -k:][:, ::-1]
    Z = Z*(omega**0.5)

    T = np.dot(A_neg_tmp, Z)
    x = T[:half_size,:]
    y = T[half_size:,:]

    return omega, x, y



def TDDFT_subspace_linear_solver(a, b, sigma, pi, p, q, omega):
    '''[ a b ] x - [ σ   π] x  Ω = p
       [ b a ] y   [-π  -σ] y    = q
       normalize the right hand side first
    '''
    pq = np.vstack((p,q))
    pqnorm = np.linalg.norm(pq, axis=0, keepdims=True)

    p = p/pqnorm
    q = q/pqnorm

    d = abs(np.diag(sigma))
    d_mh = d**(-0.5)

    ''' TODO:replace LU decompose to cholesky '''
    '''LU = d^−1/2 (σ − π) d^−1/2 '''
    s_m_p = np.einsum('i,ij,j->ij', d_mh, sigma - pi, d_mh)
    L, U = scipy.linalg.lu(s_m_p, permute_l=True)
    L_inv = np.linalg.inv(L)
    U_inv = np.linalg.inv(U)
    # L_inv = scipy.linalg.solve_triangular(L, np.eye(L.shape[0]), lower=True)
    # U_inv = scipy.linalg.solve_triangular(U, np.eye(L.shape[0]), lower=True)
    U_invT = U_inv.T
    p_p_q_tilde = np.dot(L_inv, d_mh.reshape(-1,1)*(p+q))
    p_m_q_tilde = np.dot(U_invT, d_mh.reshape(-1,1)*(p-q))

    ''' a ̃−b ̃= U^-T d^−1/2 (a−b) d^-1/2 U^-1 = GG^T'''
    d_amb_d = np.einsum('i,ij,j->ij', d_mh, a-b, d_mh)
    GGT = np.dot(U_invT, np.dot(d_amb_d, U_inv))

    G = np.linalg.cholesky(GGT)
    if np.any(np.isnan(G)):
        eig, eigv = np.linalg.eigh(GGT)
        if eig[0] < -1e-4:
            error_msg = (
                "GGT matrix is not positive definite.\n"
                "SCF not correctly converged is likely to cause this error.\n"
                "For example, scf converged to the wrong state.\n"
            )
            raise RuntimeError(error_msg)
    G_inv = np.linalg.inv(G)

    '''a ̃+ b ̃= L^−1 d^−1/2 (a+b) d^−1/2 L^−T
       M = G^T (a ̃+ b ̃) G
    '''
    d_apb_d = np.einsum('i,ij,j->ij', d_mh, a+b, d_mh)
    a_p_b_tilde = np.dot(np.dot(L_inv, d_apb_d),  L_inv.T)

    M = np.dot(np.dot(G.T, a_p_b_tilde), G)

    T = np.dot(G.T, p_p_q_tilde)
    T += np.dot(G_inv, p_m_q_tilde * omega.reshape(1,-1))

    Z = solve_AX_Xla_B(M, omega**2, T)

    '''(x ̃+ y ̃) = GZ
       x + y = d^-1/2 L^-T (x ̃+ y ̃)
       x - y = d^-1/2 U^-1 (x ̃- y ̃)
    '''
    x_p_y_tilde = np.dot(G,Z)
    x_p_y = d_mh.reshape(-1,1) * np.dot(L_inv.T, x_p_y_tilde)

    x_m_y_tilde = (np.dot(a_p_b_tilde, x_p_y_tilde) - p_p_q_tilde)/omega
    x_m_y = d_mh.reshape(-1,1) * np.dot(U_inv, x_m_y_tilde)

    x = (x_p_y + x_m_y)/2
    y = x_p_y - x
    x *= pqnorm
    y *= pqnorm
    return x, y


def TDDFT_subspace_linear_solver1(a, b, sigma, pi, p, q, omega):
    ''' [ a b ] x - [ σ   π] x  Ω = p
        [ b a ] y   [-π  -σ] y    = q
        AT - BTΩ = P

        B^-1 AT - T Ω = B^-1 R
        MT - TΩ = P
        where
        M = B^-1 A
        P = B^-1 R
    '''
    half_size = a.shape[0]

    rhs = np.vstack((p, q))
    rhs_norm = np.linalg.norm(rhs, axis=0, keepdims=True)
    rhs = rhs/rhs_norm

    A = np.empty((2*half_size,2*half_size))
    A[:half_size,:half_size] = a[:,:]
    A[:half_size,half_size:] = b[:,:]
    A[half_size:,:half_size] = b[:,:]
    A[half_size:,half_size:] = a[:,:]

    B = np.empty_like(A)
    B[:half_size,:half_size] = sigma[:,:]
    B[:half_size,half_size:] = pi[:,:]
    B[half_size:,:half_size] = -pi[:,:]
    B[half_size:,half_size:] = -sigma[:,:]

    B_inv = np.linalg.inv(B)
    M = np.dot(B_inv, A)
    R = np.dot(B_inv,rhs)

    T = scipy.linalg.solve_sylvester(M, -np.diag(omega), R)
    T *= rhs_norm

    x = T[:half_size,:]
    y = T[half_size:,:]

    return x, y


def XmY_2_XY(Z, AmB_sq, omega):
    '''given Z, (A-B)^2, omega
       return X, Y

        X-Y = (A-B)^-1/2 Z
        X+Y = (A-B)^1/2 Z omega^-1
    '''
    AmB_sq = AmB_sq.reshape(1,-1)

    '''AmB = (A - B)'''
    AmB = AmB_sq**0.5

    XmY = AmB**(-0.5) * Z

    omega = omega.reshape(-1,1)
    XpY = (AmB * XmY)/omega

    X = (XpY + XmY)/2
    Y = (XpY - XmY)/2

    return X, Y

def gen_VW_f_order(sub_A_holder, V_holder, W_holder, size_old, size_new, symmetry = True, up_triangle = False):
    '''
    [ V_old.T ] [W_old, W_new] = [VW_old,        V_old.T W_new] = [VW_old, V_current.T W_new]
    [ V_new.T ]                  [V_new.T W_old, V_new.T W_new]   [               '' ''     ]


    V_holder or W_holder

                size_old     size_new
    |--------------|--------------|------------|
    |              |              |            |
    |   V_old      |    V_new     |            |
    |              |              |            |
    |              |              |            |
    |              |              |            |
    |              |              |            |
    |        [ V_current ]        |            |
    |              |              |            |
    |              |              |            |
    |              |              |            |
    |              |              |            |
    |              |              |            |
    |              |              |            |
    |              |              |            |
    |              |              |            |
    |--------------|--------------|------------|

    sub_A_holder

                            size_old            size_new
                |---------------|-----------------|-----------------|
                |               |                 |                 |
                |    VW_old     |                 |                 |
                |               |                 |                 |
      size_old  |---------------|V_current.T W_new|-----------------|
                | V_new.T W_old |                 |                 |
                | or            |                 |                 |
                | W_new.T V_old |                 |                 |
      size_new  |---------------|-----------------|-----------------|
                |               |                 |                 |
                |               |                 |                 |
                |               |                 |                 |
                |---------------|-----------------|-----------------|
    '''

    V_current = V_holder[:,:size_new]
    W_new = W_holder[:,size_old:size_new]
    sub_A_holder[:size_new,size_old:size_new] = np.dot(V_current.T, W_new)

    if symmetry:
        sub_A_holder = block_symmetrize(sub_A_holder,size_old,size_new)
    elif not symmetry:
        if not up_triangle:
            '''
            also explicitly compute the lower triangle,
            either equal upper triangle.T or recompute
            '''
            V_new = V_holder[:,size_old:size_new]
            W_old = W_holder[:,:size_old]
            sub_A_holder[size_old:size_new,:size_old] = np.dot(V_new.T, W_old)
        elif up_triangle:
            '''
            otherwise juts let the lower triangle be zeros
            '''
            pass

    return sub_A_holder

class LinearDependencyError(RuntimeError):
    pass


if __name__ == '__main__':
    size=10
    A = abs(np.random.rand(size,size))
    A = A.dot(A.T)
    S = abs(np.random.rand(size,size))
    S = S.dot(S.T)

    solve_AX_SX(A, S)


def check_VW_orthogonality(V, W):
    '''
    check whether V and W are orthogonal

    [ V W ]  [ V W ]T  = I
    [ W V ]  [ W V ]

    V VT + W WT = I
    V WT + W VT = 0

    (W VT + V WT = 0
    W WT + V VT = I)
    '''

    VVWW = einsum('ij,kj->ik', V, V) + einsum('ij,kj->ik', W, W)
    VWTW = einsum('ij,kj->ik', V, W) + einsum('ij,kj->ik', W, V)
    norm1 = np.linalg.norm(VVWW - np.eye(VVWW.shape[0]))
    norm2 = np.linalg.norm(VWTW)
    return norm1, norm2
