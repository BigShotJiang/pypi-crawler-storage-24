"""Tests for Safari Reader."""
