"""Tests for Safari REPL."""
