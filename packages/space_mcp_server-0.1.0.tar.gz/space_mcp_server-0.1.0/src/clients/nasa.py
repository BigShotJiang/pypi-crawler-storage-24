"""NASA API Client — APOD, Mars Rovers, NeoWs und DONKI.

Alle Endpoints unter api.nasa.gov, die einen API-Key brauchen.
"""

import httpx

from src.config import settings


class NasaClient:
    """Async-Client für die NASA API (APOD, Mars, NeoWs, DONKI)."""

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=settings.http_timeout)
        self._base = settings.nasa_base_url

    @property
    def _api_key(self) -> str:
        return settings.nasa_api_key

    # --- APOD (Astronomy Picture of the Day) ---

    async def get_apod(
        self,
        date: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        count: int | None = None,
    ) -> dict | list:
        """Astronomy Picture of the Day abrufen.

        Ohne Parameter: heutiges Bild.
        Mit date: bestimmtes Datum (YYYY-MM-DD).
        Mit start_date/end_date: Datumsbereich.
        Mit count: zufällige Anzahl.
        """
        url = f"{self._base}/planetary/apod"
        params: dict = {"api_key": self._api_key}
        if date:
            params["date"] = date
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        if count:
            params["count"] = count
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    # --- Mars Rover Photos ---

    async def get_mars_photos(
        self,
        rover: str,
        sol: int | None = None,
        earth_date: str | None = None,
        camera: str | None = None,
        page: int = 1,
    ) -> dict:
        """Mars-Rover-Fotos nach Sol oder Erddatum abrufen."""
        url = f"{self._base}/mars-photos/api/v1/rovers/{rover}/photos"
        params: dict = {"api_key": self._api_key, "page": page}
        if sol is not None:
            params["sol"] = sol
        if earth_date:
            params["earth_date"] = earth_date
        if camera:
            params["camera"] = camera
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_mars_latest_photos(self, rover: str) -> dict:
        """Neueste Fotos eines Mars-Rovers abrufen."""
        url = f"{self._base}/mars-photos/api/v1/rovers/{rover}/latest_photos"
        params = {"api_key": self._api_key}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_mars_rover_manifest(self, rover: str) -> dict:
        """Missions-Manifest eines Rovers abrufen (Status, Kameras, Sol-Bereich)."""
        url = f"{self._base}/mars-photos/api/v1/manifests/{rover}"
        params = {"api_key": self._api_key}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    # --- NeoWs (Near Earth Object Web Service) ---

    async def get_neo_feed(
        self, start_date: str, end_date: str | None = None
    ) -> dict:
        """Erdnahe Objekte in einem Datumsbereich abrufen (max. 7 Tage)."""
        url = f"{self._base}/neo/rest/v1/feed"
        params: dict = {"api_key": self._api_key, "start_date": start_date}
        if end_date:
            params["end_date"] = end_date
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_neo_by_id(self, asteroid_id: str) -> dict:
        """Details zu einem bestimmten Asteroiden abrufen."""
        url = f"{self._base}/neo/rest/v1/neo/{asteroid_id}"
        params = {"api_key": self._api_key}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    # --- DONKI (Space Weather) ---

    async def get_donki_cme(
        self, start_date: str | None = None, end_date: str | None = None
    ) -> list:
        """Koronale Massenauswürfe (CME) abrufen."""
        url = f"{self._base}/DONKI/CME"
        params: dict = {"api_key": self._api_key}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_donki_flr(
        self, start_date: str | None = None, end_date: str | None = None
    ) -> list:
        """Sonneneruptionen (Solar Flares) abrufen."""
        url = f"{self._base}/DONKI/FLR"
        params: dict = {"api_key": self._api_key}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_donki_gst(
        self, start_date: str | None = None, end_date: str | None = None
    ) -> list:
        """Geomagnetische Stürme abrufen."""
        url = f"{self._base}/DONKI/GST"
        params: dict = {"api_key": self._api_key}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_donki_notifications(
        self, start_date: str | None = None, end_date: str | None = None,
        notification_type: str | None = None,
    ) -> list:
        """DONKI-Benachrichtigungen abrufen (alle Weltraumwetter-Events)."""
        url = f"{self._base}/DONKI/notifications"
        params: dict = {"api_key": self._api_key}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        if notification_type:
            params["type"] = notification_type
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def close(self):
        """HTTP-Client schließen."""
        await self._client.aclose()
