"""EONET API Client — Earth Observatory Natural Event Tracker.

Liefert aktuelle Naturereignisse (Brände, Vulkane, Stürme etc.).
Kein API-Key nötig.
"""

import httpx

from src.config import settings


class EonetClient:
    """Async-Client für die EONET v3 API (Naturereignisse)."""

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=settings.http_timeout)
        self._base = settings.eonet_base_url

    async def get_events(
        self,
        status: str | None = None,
        category: str | None = None,
        limit: int | None = None,
        days: int | None = None,
    ) -> dict:
        """Naturereignisse abrufen.

        Args:
            status: "open" oder "closed" (Standard: open)
            category: Kategorie-ID (z.B. "wildfires", "volcanoes", "severeStorms")
            limit: Maximale Anzahl Events
            days: Events der letzten N Tage
        """
        url = f"{self._base}/events"
        params: dict = {}
        if status:
            params["status"] = status
        if category:
            params["category"] = category
        if limit:
            params["limit"] = limit
        if days:
            params["days"] = days
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_categories(self) -> dict:
        """Verfügbare Event-Kategorien abrufen."""
        url = f"{self._base}/categories"
        resp = await self._client.get(url)
        resp.raise_for_status()
        return resp.json()

    async def close(self):
        """HTTP-Client schließen."""
        await self._client.aclose()
