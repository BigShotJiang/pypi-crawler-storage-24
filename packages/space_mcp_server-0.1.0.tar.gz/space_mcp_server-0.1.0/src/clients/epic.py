"""EPIC API Client — Earth Polychromatic Imaging Camera.

Liefert Fotos der Erde von DSCOVR (L1-Punkt).
Kein API-Key nötig.
"""

import httpx

from src.config import settings


class EpicClient:
    """Async-Client für die EPIC API (Erdbilder von DSCOVR)."""

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=settings.http_timeout)
        self._base = settings.epic_base_url

    async def get_latest_natural(self) -> list[dict]:
        """Neueste Natural-Color-Bilder abrufen."""
        url = f"{self._base}/api/natural"
        resp = await self._client.get(url)
        resp.raise_for_status()
        return resp.json()

    async def get_natural_by_date(self, date: str) -> list[dict]:
        """Natural-Color-Bilder für ein bestimmtes Datum (YYYY-MM-DD)."""
        url = f"{self._base}/api/natural/date/{date}"
        resp = await self._client.get(url)
        resp.raise_for_status()
        return resp.json()

    async def get_available_dates(self) -> list[dict]:
        """Verfügbare Daten für Natural-Color-Bilder abrufen."""
        url = f"{self._base}/api/natural/all"
        resp = await self._client.get(url)
        resp.raise_for_status()
        return resp.json()

    def build_image_url(self, image_name: str, date: str) -> str:
        """Bild-URL aus Name und Datum zusammenbauen.

        Datum-Format: YYYY-MM-DD wird zu YYYY/MM/DD konvertiert.
        """
        date_path = date.replace("-", "/")
        return (
            f"{self._base}/archive/natural/{date_path}/png/{image_name}.png"
        )

    async def close(self):
        """HTTP-Client schließen."""
        await self._client.aclose()
