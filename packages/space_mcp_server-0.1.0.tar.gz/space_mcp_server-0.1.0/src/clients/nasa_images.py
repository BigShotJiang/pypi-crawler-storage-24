"""NASA Image and Video Library Client.

Zugriff auf über 140.000 NASA-Bilder und -Videos.
Kein API-Key nötig.
"""

import httpx

from src.config import settings


class NasaImagesClient:
    """Async-Client für die NASA Image and Video Library."""

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=settings.http_timeout)
        self._base = settings.nasa_images_base_url

    async def search(
        self,
        query: str,
        media_type: str | None = None,
        year_start: int | None = None,
        year_end: int | None = None,
        page_size: int = 20,
        page: int = 1,
    ) -> dict:
        """NASA-Bilder und -Videos durchsuchen.

        Args:
            query: Suchbegriff (z.B. "apollo 11", "mars", "hubble")
            media_type: "image", "video" oder "audio"
            year_start: Ergebnisse ab diesem Jahr
            year_end: Ergebnisse bis zu diesem Jahr
            page_size: Ergebnisse pro Seite (Standard: 20, Max: 100)
            page: Seitennummer
        """
        url = f"{self._base}/search"
        params: dict = {"q": query, "page_size": min(page_size, 100), "page": page}
        if media_type:
            params["media_type"] = media_type
        if year_start:
            params["year_start"] = year_start
        if year_end:
            params["year_end"] = year_end
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def close(self):
        """HTTP-Client schließen."""
        await self._client.aclose()
