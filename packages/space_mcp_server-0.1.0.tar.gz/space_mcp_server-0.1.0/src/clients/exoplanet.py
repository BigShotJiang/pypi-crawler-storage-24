"""Exoplanet Archive Client — NASA Exoplanet-Datenbank.

Zugriff auf bestätigte Exoplaneten mit TAP-Query-Interface.
Kein API-Key nötig.
"""

import httpx

from src.config import settings


class ExoplanetClient:
    """Async-Client für das NASA Exoplanet Archive."""

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=settings.http_timeout)
        self._base = settings.exoplanet_base_url

    async def query(
        self,
        where: str | None = None,
        select: str = "pl_name,hostname,disc_year,pl_masse,pl_rade,pl_orbper,st_dist,discoverymethod",
        order_by: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """Exoplaneten-Datenbank abfragen (TAP-Style).

        Args:
            where: SQL-ähnliche WHERE-Klausel (z.B. "disc_year=2024")
            select: Spalten zum Abrufen (kommasepariert)
            order_by: Sortierung (z.B. "disc_year desc")
            limit: Maximale Anzahl Ergebnisse (Standard: 20)
        """
        url = f"{self._base}/TAP/sync"
        # ADQL-Query zusammenbauen
        query = f"SELECT TOP {limit} {select} FROM ps"
        if where:
            query += f" WHERE {where}"
        if order_by:
            query += f" ORDER BY {order_by}"
        params = {
            "query": query,
            "format": "json",
        }
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def close(self):
        """HTTP-Client schließen."""
        await self._client.aclose()
