"""Mars-Tools — Rover-Fotos und Missionsinformationen."""

from mcp.server.fastmcp import FastMCP

from src.analytics import track_call
from src.clients.nasa import NasaClient

# Gemeinsame Client-Instanz
_nasa = NasaClient()

# Gültige Rover-Namen
_VALID_ROVERS = {"curiosity", "perseverance", "opportunity", "spirit"}


def register_mars_tools(mcp: FastMCP):
    """Mars-bezogene MCP-Tools registrieren."""

    @mcp.tool()
    async def get_mars_rover_photos(
        rover: str = "curiosity",
        sol: int | None = None,
        earth_date: str | None = None,
        camera: str | None = None,
        limit: int = 10,
    ) -> dict:
        """Fotos von Mars-Rovern abrufen.

        Zeigt echte Fotos von der Marsoberfläche.
        Ohne sol/earth_date: neueste verfügbare Fotos.

        Args:
            rover: Rover-Name — "curiosity", "perseverance", "opportunity" oder "spirit"
            sol: Mars-Sol (Marstag seit Landung, z.B. 1000)
            earth_date: Erddatum im Format YYYY-MM-DD (alternativ zu sol)
            camera: Kamera-Kürzel (z.B. "FHAZ", "RHAZ", "MAST", "NAVCAM", "CHEMCAM")
            limit: Maximale Anzahl Fotos (Standard: 10, Maximum: 25)
        """
        track_call("get_mars_rover_photos")
        try:
            rover = rover.lower()
            if rover not in _VALID_ROVERS:
                return {
                    "error": f"Unbekannter Rover: {rover}. "
                    f"Gültige Rover: {', '.join(_VALID_ROVERS)}"
                }

            limit = min(limit, 25)

            # Wenn kein Datum angegeben, neueste Fotos abrufen
            if sol is None and earth_date is None:
                data = await _nasa.get_mars_latest_photos(rover)
                photos_raw = data.get("latest_photos", [])
            else:
                data = await _nasa.get_mars_photos(
                    rover=rover, sol=sol, earth_date=earth_date, camera=camera
                )
                photos_raw = data.get("photos", [])

            # Auf Limit beschränken
            photos_raw = photos_raw[:limit]

            photos = []
            for photo in photos_raw:
                photos.append({
                    "id": photo.get("id"),
                    "sol": photo.get("sol"),
                    "earth_date": photo.get("earth_date", ""),
                    "camera": photo.get("camera", {}).get("full_name", ""),
                    "camera_short": photo.get("camera", {}).get("name", ""),
                    "img_src": photo.get("img_src", ""),
                    "rover": photo.get("rover", {}).get("name", ""),
                })

            return {
                "rover": rover,
                "photo_count": len(photos),
                "photos": photos,
            }

        except Exception as e:
            return {"error": f"Mars-Fotos konnten nicht abgerufen werden: {e}"}

    @mcp.tool()
    async def get_mars_rover_info(
        rover: str = "curiosity",
    ) -> dict:
        """Missionsinformationen eines Mars-Rovers abrufen.

        Zeigt Status, Landedatum, Gesamtanzahl Fotos und Kamera-Liste.

        Args:
            rover: Rover-Name — "curiosity", "perseverance", "opportunity" oder "spirit"
        """
        track_call("get_mars_rover_info")
        try:
            rover = rover.lower()
            if rover not in _VALID_ROVERS:
                return {
                    "error": f"Unbekannter Rover: {rover}. "
                    f"Gültige Rover: {', '.join(_VALID_ROVERS)}"
                }

            data = await _nasa.get_mars_rover_manifest(rover)
            manifest = data.get("photo_manifest", {})

            return {
                "name": manifest.get("name", ""),
                "status": manifest.get("status", ""),
                "landing_date": manifest.get("landing_date", ""),
                "launch_date": manifest.get("launch_date", ""),
                "max_sol": manifest.get("max_sol"),
                "max_date": manifest.get("max_date", ""),
                "total_photos": manifest.get("total_photos", 0),
                "cameras": [
                    cam.get("name", "") for cam in manifest.get("cameras", [])
                    if isinstance(cam, dict)
                ],
            }

        except Exception as e:
            return {"error": f"Rover-Info konnte nicht abgerufen werden: {e}"}
