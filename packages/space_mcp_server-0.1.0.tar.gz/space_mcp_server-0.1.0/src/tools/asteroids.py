"""Asteroiden-Tools — erdnahe Objekte (NEO) tracken und analysieren."""

from mcp.server.fastmcp import FastMCP

from src.analytics import track_call
from src.clients.nasa import NasaClient

# Gemeinsame Client-Instanz
_nasa = NasaClient()


def register_asteroid_tools(mcp: FastMCP):
    """Asteroiden-bezogene MCP-Tools registrieren."""

    @mcp.tool()
    async def get_near_earth_objects(
        start_date: str,
        end_date: str | None = None,
    ) -> dict:
        """Erdnahe Asteroiden in einem Zeitraum abrufen (NeoWs).

        Zeigt Asteroiden die der Erde nahe kommen, mit Größe,
        Geschwindigkeit, Entfernung und Gefahrenbewertung.

        Args:
            start_date: Startdatum im Format YYYY-MM-DD
            end_date: Enddatum im Format YYYY-MM-DD (optional, max. 7 Tage Spanne)
        """
        track_call("get_near_earth_objects")
        try:
            data = await _nasa.get_neo_feed(
                start_date=start_date, end_date=end_date
            )

            total_count = data.get("element_count", 0)
            neo_objects = data.get("near_earth_objects", {})

            # Alle Tage zusammenführen und aufbereiten
            asteroids = []
            for date_key, day_neos in sorted(neo_objects.items()):
                for neo in day_neos:
                    # Nächste Annäherung für dieses Datum
                    close_approach = neo.get("close_approach_data", [{}])
                    approach = close_approach[0] if close_approach else {}

                    # Geschätzte Größe (Durchmesser in Metern)
                    diameter = neo.get("estimated_diameter", {}).get("meters", {})

                    asteroids.append({
                        "name": neo.get("name", ""),
                        "neo_id": neo.get("neo_reference_id", ""),
                        "is_potentially_hazardous": neo.get(
                            "is_potentially_hazardous_asteroid", False
                        ),
                        "estimated_diameter_min_m": round(
                            diameter.get("estimated_diameter_min", 0), 1
                        ),
                        "estimated_diameter_max_m": round(
                            diameter.get("estimated_diameter_max", 0), 1
                        ),
                        "close_approach_date": approach.get(
                            "close_approach_date_full", ""
                        ),
                        "velocity_km_h": round(
                            float(
                                approach.get("relative_velocity", {}).get(
                                    "kilometers_per_hour", 0
                                )
                            ),
                            1,
                        ),
                        "miss_distance_km": round(
                            float(
                                approach.get("miss_distance", {}).get(
                                    "kilometers", 0
                                )
                            ),
                            1,
                        ),
                        "miss_distance_lunar": round(
                            float(
                                approach.get("miss_distance", {}).get("lunar", 0)
                            ),
                            2,
                        ),
                    })

            # Nach Entfernung sortieren (nächste zuerst)
            asteroids.sort(key=lambda a: a.get("miss_distance_km", float("inf")))

            # Gefährliche markieren
            hazardous = [a for a in asteroids if a["is_potentially_hazardous"]]

            return {
                "start_date": start_date,
                "end_date": end_date or start_date,
                "total_count": total_count,
                "hazardous_count": len(hazardous),
                "asteroids": asteroids,
            }

        except Exception as e:
            return {"error": f"NEO-Daten konnten nicht abgerufen werden: {e}"}

    @mcp.tool()
    async def get_asteroid_details(
        asteroid_id: str,
    ) -> dict:
        """Detaillierte Informationen zu einem bestimmten Asteroiden.

        Zeigt Orbitalparameter, alle nahen Vorbeiflüge und physische Daten.

        Args:
            asteroid_id: NEO-Referenz-ID (z.B. "3542519" für Bennu)
        """
        track_call("get_asteroid_details")
        try:
            neo = await _nasa.get_neo_by_id(asteroid_id)

            # Geschätzte Größe
            diameter = neo.get("estimated_diameter", {})

            # Orbitalparameter
            orbital = neo.get("orbital_data", {})

            # Nächste Vorbeiflüge (max. 10)
            approaches = []
            for approach in neo.get("close_approach_data", [])[:10]:
                approaches.append({
                    "date": approach.get("close_approach_date_full", ""),
                    "velocity_km_h": round(
                        float(
                            approach.get("relative_velocity", {}).get(
                                "kilometers_per_hour", 0
                            )
                        ),
                        1,
                    ),
                    "miss_distance_km": round(
                        float(
                            approach.get("miss_distance", {}).get("kilometers", 0)
                        ),
                        1,
                    ),
                    "miss_distance_lunar": round(
                        float(
                            approach.get("miss_distance", {}).get("lunar", 0)
                        ),
                        2,
                    ),
                    "orbiting_body": approach.get("orbiting_body", ""),
                })

            return {
                "name": neo.get("name", ""),
                "neo_id": neo.get("neo_reference_id", ""),
                "nasa_jpl_url": neo.get("nasa_jpl_url", ""),
                "is_potentially_hazardous": neo.get(
                    "is_potentially_hazardous_asteroid", False
                ),
                "absolute_magnitude": neo.get("absolute_magnitude_h"),
                "estimated_diameter_meters": {
                    "min": round(
                        diameter.get("meters", {}).get(
                            "estimated_diameter_min", 0
                        ),
                        1,
                    ),
                    "max": round(
                        diameter.get("meters", {}).get(
                            "estimated_diameter_max", 0
                        ),
                        1,
                    ),
                },
                "estimated_diameter_km": {
                    "min": round(
                        diameter.get("kilometers", {}).get(
                            "estimated_diameter_min", 0
                        ),
                        4,
                    ),
                    "max": round(
                        diameter.get("kilometers", {}).get(
                            "estimated_diameter_max", 0
                        ),
                        4,
                    ),
                },
                "orbital_data": {
                    "orbit_id": orbital.get("orbit_id", ""),
                    "orbit_class": orbital.get("orbit_class", {}).get(
                        "orbit_class_type", ""
                    ),
                    "orbit_class_description": orbital.get("orbit_class", {}).get(
                        "orbit_class_description", ""
                    ),
                    "semi_major_axis_au": orbital.get("semi_major_axis", ""),
                    "eccentricity": orbital.get("eccentricity", ""),
                    "inclination_deg": orbital.get("inclination", ""),
                    "orbital_period_days": orbital.get("orbital_period", ""),
                    "perihelion_distance_au": orbital.get("perihelion_distance", ""),
                    "aphelion_distance_au": orbital.get("aphelion_distance", ""),
                },
                "close_approach_count": len(
                    neo.get("close_approach_data", [])
                ),
                "recent_approaches": approaches,
            }

        except Exception as e:
            return {"error": f"Asteroiden-Details konnten nicht abgerufen werden: {e}"}
