"""Erd-Tools — EPIC-Erdbilder und EONET-Naturereignisse."""

from mcp.server.fastmcp import FastMCP

from src.analytics import track_call
from src.clients.epic import EpicClient
from src.clients.eonet import EonetClient

# Gemeinsame Client-Instanzen
_epic = EpicClient()
_eonet = EonetClient()


def register_earth_tools(mcp: FastMCP):
    """Erd-bezogene MCP-Tools registrieren."""

    @mcp.tool()
    async def get_earth_imagery(
        date: str | None = None,
        limit: int = 5,
    ) -> dict:
        """Echte Fotos der Erde von NASAs DSCOVR-Satellit (EPIC-Kamera).

        Liefert Bilder der ganzen Erde aus 1,5 Millionen km Entfernung
        am Lagrange-Punkt L1. Zeigt Wolken, Kontinente und Ozeane.

        Args:
            date: Bestimmtes Datum YYYY-MM-DD (optional, Standard: neueste)
            limit: Maximale Anzahl Bilder (Standard: 5, Maximum: 20)
        """
        track_call("get_earth_imagery")
        try:
            limit = min(limit, 20)

            if date:
                data = await _epic.get_natural_by_date(date)
            else:
                data = await _epic.get_latest_natural()

            # Auf Limit beschränken
            data = data[:limit]

            images = []
            for item in data:
                image_name = item.get("image", "")
                item_date = item.get("date", "")
                # Datum für URL extrahieren (YYYY-MM-DD aus dem Datetime-String)
                date_str = item_date[:10] if item_date else ""

                # Koordinaten des Zentrums
                centroid = item.get("centroid_coordinates", {})

                images.append({
                    "image_name": image_name,
                    "date": item_date,
                    "caption": item.get("caption", ""),
                    "image_url": _epic.build_image_url(image_name, date_str),
                    "centroid_lat": centroid.get("lat"),
                    "centroid_lon": centroid.get("lon"),
                    "sun_j2000_position": item.get("sun_j2000_position", {}),
                    "lunar_j2000_position": item.get("lunar_j2000_position", {}),
                })

            return {
                "date": date or "latest",
                "image_count": len(images),
                "images": images,
            }

        except Exception as e:
            return {"error": f"EPIC-Bilder konnten nicht abgerufen werden: {e}"}

    @mcp.tool()
    async def get_natural_events(
        category: str | None = None,
        status: str = "open",
        days: int | None = None,
        limit: int = 20,
    ) -> dict:
        """Aktuelle Naturereignisse weltweit abrufen (EONET).

        Zeigt aktive Waldbrände, Vulkanausbrüche, Stürme, Überschwemmungen
        und andere Naturkatastrophen mit Koordinaten und Zeitstempel.

        Args:
            category: Kategorie — "wildfires", "volcanoes", "severeStorms",
                "seaLakeIce", "earthquakes", "floods", "landslides" (optional)
            status: "open" (aktive Events) oder "closed" (beendete)
            days: Events der letzten N Tage (optional)
            limit: Maximale Anzahl Events (Standard: 20, Maximum: 50)
        """
        track_call("get_natural_events")
        try:
            limit = min(limit, 50)

            data = await _eonet.get_events(
                status=status,
                category=category,
                limit=limit,
                days=days,
            )

            events_raw = data.get("events", [])

            events = []
            for event in events_raw:
                # Geometrie-Daten (Koordinaten) aufbereiten
                geometries = event.get("geometry", [])
                latest_geo = geometries[-1] if geometries else {}

                # Kategorien
                categories = [
                    cat.get("title", "") for cat in event.get("categories", [])
                ]

                # Quellen
                sources = [
                    {"id": src.get("id", ""), "url": src.get("url", "")}
                    for src in event.get("sources", [])
                ]

                events.append({
                    "id": event.get("id", ""),
                    "title": event.get("title", ""),
                    "categories": categories,
                    "sources": sources[:3],  # Max. 3 Quellen pro Event
                    "latest_date": latest_geo.get("date", ""),
                    "latest_coordinates": latest_geo.get("coordinates", []),
                    "geometry_type": latest_geo.get("type", ""),
                    "closed": event.get("closed"),
                })

            return {
                "status_filter": status,
                "category_filter": category or "all",
                "event_count": len(events),
                "events": events,
            }

        except Exception as e:
            return {"error": f"EONET-Ereignisse konnten nicht abgerufen werden: {e}"}
