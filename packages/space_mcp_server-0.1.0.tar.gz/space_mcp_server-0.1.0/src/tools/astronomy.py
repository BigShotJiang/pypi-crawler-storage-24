"""Astronomie-Tools — APOD, NASA-Bildersuche, Exoplaneten und Weltraumwetter."""

from mcp.server.fastmcp import FastMCP

from src.analytics import track_call
from src.clients.nasa import NasaClient
from src.clients.nasa_images import NasaImagesClient
from src.clients.exoplanet import ExoplanetClient

# Gemeinsame Client-Instanzen
_nasa = NasaClient()
_images = NasaImagesClient()
_exoplanet = ExoplanetClient()


def register_astronomy_tools(mcp: FastMCP):
    """Astronomie-bezogene MCP-Tools registrieren."""

    @mcp.tool()
    async def get_astronomy_picture(
        date: str | None = None,
        count: int | None = None,
    ) -> dict:
        """Astronomy Picture of the Day (APOD) abrufen.

        NASAs berühmtes tägliches Astronomiebild mit Erklärung.
        Ohne Parameter: heutiges Bild. Mit Datum: bestimmter Tag.
        Mit count: mehrere zufällige Bilder.

        Args:
            date: Bestimmtes Datum im Format YYYY-MM-DD (optional)
            count: Anzahl zufälliger Bilder (1-100, optional)
        """
        track_call("get_astronomy_picture")
        try:
            data = await _nasa.get_apod(date=date, count=count)

            # Einzelnes Bild aufbereiten
            if isinstance(data, dict):
                return {
                    "title": data.get("title", ""),
                    "date": data.get("date", ""),
                    "explanation": data.get("explanation", ""),
                    "url": data.get("url", ""),
                    "hdurl": data.get("hdurl", ""),
                    "media_type": data.get("media_type", ""),
                    "copyright": data.get("copyright", ""),
                }

            # Mehrere Bilder (count-Parameter)
            results = []
            for item in data:
                results.append({
                    "title": item.get("title", ""),
                    "date": item.get("date", ""),
                    "explanation": item.get("explanation", ""),
                    "url": item.get("url", ""),
                    "media_type": item.get("media_type", ""),
                })
            return {"count": len(results), "pictures": results}

        except Exception as e:
            return {"error": f"APOD konnte nicht abgerufen werden: {e}"}

    @mcp.tool()
    async def search_nasa_images(
        query: str,
        media_type: str | None = None,
        year_start: int | None = None,
        year_end: int | None = None,
        page_size: int = 10,
    ) -> dict:
        """NASAs Bild- und Video-Bibliothek durchsuchen (140.000+ Medien).

        Findet Bilder, Videos und Audiodateien aus NASAs gesamtem Archiv.

        Args:
            query: Suchbegriff (z.B. "apollo 11", "mars landing", "hubble nebula")
            media_type: Medientyp — "image", "video" oder "audio" (optional)
            year_start: Ergebnisse ab diesem Jahr (optional)
            year_end: Ergebnisse bis zu diesem Jahr (optional)
            page_size: Anzahl Ergebnisse (Standard: 10, Maximum: 100)
        """
        track_call("search_nasa_images")
        try:
            data = await _images.search(
                query=query,
                media_type=media_type,
                year_start=year_start,
                year_end=year_end,
                page_size=min(page_size, 100),
            )

            collection = data.get("collection", {})
            total = collection.get("metadata", {}).get("total_hits", 0)
            items = collection.get("items", [])

            results = []
            for item in items:
                item_data = item.get("data", [{}])[0] if item.get("data") else {}
                links = item.get("links", [{}])
                preview_url = links[0].get("href", "") if links else ""

                results.append({
                    "title": item_data.get("title", ""),
                    "description": item_data.get("description", "")[:300],
                    "date_created": item_data.get("date_created", ""),
                    "media_type": item_data.get("media_type", ""),
                    "nasa_id": item_data.get("nasa_id", ""),
                    "preview_url": preview_url,
                    "center": item_data.get("center", ""),
                })

            return {
                "query": query,
                "total_hits": total,
                "result_count": len(results),
                "results": results,
            }

        except Exception as e:
            return {"error": f"NASA-Bildersuche fehlgeschlagen: {e}"}

    @mcp.tool()
    async def get_exoplanets(
        discovery_year: int | None = None,
        discovery_method: str | None = None,
        min_mass: float | None = None,
        max_mass: float | None = None,
        limit: int = 20,
    ) -> dict:
        """Bestätigte Exoplaneten aus NASAs Exoplanet Archive suchen.

        Durchsucht die Datenbank mit über 5.000 bestätigten Exoplaneten.

        Args:
            discovery_year: Entdeckungsjahr filtern (z.B. 2024)
            discovery_method: Entdeckungsmethode (z.B. "Transit", "Radial Velocity")
            min_mass: Mindestmasse in Jupitermassen (optional)
            max_mass: Maximalmasse in Jupitermassen (optional)
            limit: Maximale Anzahl Ergebnisse (Standard: 20, Maximum: 50)
        """
        track_call("get_exoplanets")
        try:
            limit = min(limit, 50)

            # WHERE-Klausel zusammenbauen
            conditions = ["default_flag=1"]  # Nur Standard-Parametersätze
            if discovery_year:
                conditions.append(f"disc_year={discovery_year}")
            if discovery_method:
                conditions.append(f"discoverymethod='{discovery_method}'")
            if min_mass is not None:
                conditions.append(f"pl_bmasse>={min_mass}")
            if max_mass is not None:
                conditions.append(f"pl_bmasse<={max_mass}")

            where = " AND ".join(conditions)

            data = await _exoplanet.query(
                where=where,
                select="pl_name,hostname,disc_year,pl_bmasse,pl_rade,pl_orbper,sy_dist,discoverymethod",
                order_by="disc_year desc",
                limit=limit,
            )

            planets = []
            for row in data:
                planets.append({
                    "name": row.get("pl_name", ""),
                    "host_star": row.get("hostname", ""),
                    "discovery_year": row.get("disc_year"),
                    "discovery_method": row.get("discoverymethod", ""),
                    "mass_earth": row.get("pl_bmasse"),
                    "radius_earth": row.get("pl_rade"),
                    "orbital_period_days": row.get("pl_orbper"),
                    "distance_parsecs": row.get("sy_dist"),
                })

            return {
                "planet_count": len(planets),
                "planets": planets,
            }

        except Exception as e:
            return {"error": f"Exoplaneten-Abfrage fehlgeschlagen: {e}"}

    @mcp.tool()
    async def get_space_weather(
        start_date: str | None = None,
        end_date: str | None = None,
        event_type: str = "all",
    ) -> dict:
        """Aktuelle Weltraumwetter-Daten von NASAs DONKI abrufen.

        Zeigt Sonneneruptionen, koronale Massenauswürfe (CME) und
        geomagnetische Stürme. Wichtig für Satellitenoperationen und
        Polarlicht-Vorhersagen.

        Args:
            start_date: Startdatum YYYY-MM-DD (Standard: letzte 7 Tage)
            end_date: Enddatum YYYY-MM-DD (optional)
            event_type: "all", "cme" (Massenauswürfe), "flare" (Eruptionen)
                oder "storm" (geomagnetische Stürme)
        """
        track_call("get_space_weather")
        try:
            result: dict = {"event_type": event_type}

            if event_type in ("all", "cme"):
                cmes = await _nasa.get_donki_cme(
                    start_date=start_date, end_date=end_date
                )
                result["coronal_mass_ejections"] = [
                    {
                        "activity_id": cme.get("activityID", ""),
                        "start_time": cme.get("startTime", ""),
                        "source_location": cme.get("sourceLocation", ""),
                        "note": cme.get("note", "")[:200],
                        "catalog": cme.get("catalog", ""),
                    }
                    for cme in (cmes or [])[:15]
                ]
                result["cme_count"] = len(result["coronal_mass_ejections"])

            if event_type in ("all", "flare"):
                flares = await _nasa.get_donki_flr(
                    start_date=start_date, end_date=end_date
                )
                result["solar_flares"] = [
                    {
                        "flr_id": flr.get("flrID", ""),
                        "begin_time": flr.get("beginTime", ""),
                        "peak_time": flr.get("peakTime", ""),
                        "end_time": flr.get("endTime", ""),
                        "class_type": flr.get("classType", ""),
                        "source_location": flr.get("sourceLocation", ""),
                    }
                    for flr in (flares or [])[:15]
                ]
                result["flare_count"] = len(result["solar_flares"])

            if event_type in ("all", "storm"):
                storms = await _nasa.get_donki_gst(
                    start_date=start_date, end_date=end_date
                )
                result["geomagnetic_storms"] = [
                    {
                        "gst_id": gst.get("gstID", ""),
                        "start_time": gst.get("startTime", ""),
                        "kp_index": (
                            gst.get("allKpIndex", [{}])[0].get("kpIndex")
                            if gst.get("allKpIndex")
                            else None
                        ),
                        "source": (
                            gst.get("allKpIndex", [{}])[0].get("source")
                            if gst.get("allKpIndex")
                            else None
                        ),
                    }
                    for gst in (storms or [])[:15]
                ]
                result["storm_count"] = len(result["geomagnetic_storms"])

            return result

        except Exception as e:
            return {"error": f"Weltraumwetter konnte nicht abgerufen werden: {e}"}
