"""Space MCP Server — gibt AI-Agents Zugriff auf NASA- und Astronomie-Daten."""

import logging

from mcp.server.fastmcp import FastMCP

from src.tools.astronomy import register_astronomy_tools
from src.tools.mars import register_mars_tools
from src.tools.asteroids import register_asteroid_tools
from src.tools.earth import register_earth_tools
from src.analytics import track_call, get_stats

logging.basicConfig(level=logging.INFO)

# MCP-Server erstellen
mcp = FastMCP(
    "Space MCP Server",
    instructions=(
        "Gibt AI-Agents Zugriff auf NASA- und Weltraumdaten: "
        "Astronomiebilder (APOD), Mars-Rover-Fotos, erdnahe Asteroiden, "
        "Exoplaneten, Erdbilder, Naturereignisse und Weltraumwetter."
    ),
)

# Alle Tools registrieren
register_astronomy_tools(mcp)
register_mars_tools(mcp)
register_asteroid_tools(mcp)
register_earth_tools(mcp)


# Analytics-Tool — zeigt Nutzungsstatistiken
@mcp.tool()
async def get_usage_stats() -> dict:
    """Nutzungsstatistiken des MCP-Servers abrufen.

    Zeigt: Gesamtanzahl Tool-Aufrufe, Aufrufe pro Tool,
    erster und letzter Aufruf.
    """
    return get_stats()


def main():
    """Server starten (stdio-Transport für lokale Nutzung)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
