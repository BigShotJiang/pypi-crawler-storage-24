"""Konfiguration — lädt API-Keys aus .env und stellt Settings bereit."""

import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel

# .env oder keys.env aus dem Projektverzeichnis laden
_project_root = Path(__file__).resolve().parent.parent
_env_path = _project_root / "keys.env"
if not _env_path.exists():
    _env_path = _project_root / ".env"
load_dotenv(_env_path)


class Settings(BaseModel):
    """Zentrale Konfiguration für alle API-Clients."""

    # NASA API (APOD, Mars Rovers, NeoWs, DONKI)
    nasa_api_key: str = os.getenv("NASA_API_KEY", "DEMO_KEY")
    nasa_base_url: str = "https://api.nasa.gov"

    # EPIC (Earth Polychromatic Imaging Camera) — kein Key nötig
    epic_base_url: str = "https://epic.gsfc.nasa.gov"

    # EONET (Earth Observatory Natural Event Tracker) — kein Key nötig
    eonet_base_url: str = "https://eonet.gsfc.nasa.gov/api/v3"

    # NASA Image and Video Library — kein Key nötig
    nasa_images_base_url: str = "https://images-api.nasa.gov"

    # NASA Exoplanet Archive — kein Key nötig
    exoplanet_base_url: str = "https://exoplanetarchive.ipac.caltech.edu"

    # HTTP-Client Defaults
    http_timeout: float = 30.0


# Globale Settings-Instanz
settings = Settings()
