# Space MCP Server

MCP server giving AI agents access to NASA and space/astronomy data — APOD, Mars rover photos, near-Earth asteroids, exoplanets, Earth imagery, natural events, and space weather.

## Features (10 Tools)

| Tool | Description |
|------|-------------|
| `get_astronomy_picture` | NASA's Astronomy Picture of the Day (APOD) |
| `search_nasa_images` | Search NASA's 140,000+ image/video library |
| `get_exoplanets` | Query 5,000+ confirmed exoplanets |
| `get_space_weather` | Solar flares, CMEs, geomagnetic storms (DONKI) |
| `get_mars_rover_photos` | Real photos from Curiosity, Perseverance, Opportunity, Spirit |
| `get_mars_rover_info` | Rover mission status, cameras, photo counts |
| `get_near_earth_objects` | Track asteroids approaching Earth (NeoWs) |
| `get_asteroid_details` | Orbital data and close approaches for specific asteroids |
| `get_earth_imagery` | Full-Earth photos from DSCOVR satellite (EPIC) |
| `get_natural_events` | Active wildfires, volcanoes, storms worldwide (EONET) |

## Quick Start

### Install from source

```bash
git clone https://github.com/AiAgentKarl/space-mcp-server.git
cd space-mcp-server
python -m venv .venv
.venv/Scripts/activate  # Windows
# source .venv/bin/activate  # Linux/Mac
pip install -e .
```

### Configure

```bash
cp .env.example .env
# Edit .env and add your NASA API key (optional, DEMO_KEY works out of the box)
```

Get a free API key at [https://api.nasa.gov/](https://api.nasa.gov/) for higher rate limits.

### Run

```bash
space-mcp
# or
python -m src.server
```

## Claude Code Integration

Add to your `.mcp.json`:

```json
{
  "mcpServers": {
    "space": {
      "type": "stdio",
      "command": "path/to/.venv/Scripts/python.exe",
      "args": ["-m", "src.server"],
      "env": {
        "NASA_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

## API Sources

| API | Key Required | Rate Limit |
|-----|-------------|------------|
| [NASA API](https://api.nasa.gov/) (APOD, Mars, NeoWs, DONKI) | Yes (DEMO_KEY works) | 30/hour (DEMO), 1000/hour (registered) |
| [EPIC](https://epic.gsfc.nasa.gov/) | No | No limit |
| [EONET](https://eonet.gsfc.nasa.gov/) | No | No limit |
| [NASA Image Library](https://images.nasa.gov/) | No | No limit |
| [Exoplanet Archive](https://exoplanetarchive.ipac.caltech.edu/) | No | No limit |

## Architecture

```
src/
├── server.py          # FastMCP server entry point
├── config.py          # Settings & environment variables
├── analytics.py       # Usage tracking
├── clients/
│   ├── nasa.py        # NASA API (APOD, Mars, NeoWs, DONKI)
│   ├── epic.py        # EPIC Earth imagery
│   ├── eonet.py       # EONET natural events
│   ├── nasa_images.py # NASA Image Library
│   └── exoplanet.py   # Exoplanet Archive
└── tools/
    ├── astronomy.py   # APOD, image search, exoplanets, space weather
    ├── mars.py        # Mars rover photos & info
    ├── asteroids.py   # Near-Earth objects & asteroid details
    └── earth.py       # EPIC imagery & natural events
```

## License

MIT
