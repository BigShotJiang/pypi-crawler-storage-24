# Space MCP Server — Projektanweisungen

## Projektübersicht
MCP-Server der AI-Agents Zugriff auf NASA- und Astronomie-Daten gibt (APOD, Mars-Rover, Asteroiden, Exoplaneten, Erdbilder, Weltraumwetter).

## Tech Stack
- Python 3.11+
- MCP SDK (FastMCP)
- httpx (async HTTP)
- NASA API, EPIC, EONET, NASA Images, Exoplanet Archive, DONKI

## Konventionen
- Code-Kommentare auf Deutsch
- Variablennamen auf Englisch
- Ein API-Client pro Datei in `src/clients/`
- Ein Tool-Modul pro Themengruppe in `src/tools/`

## Architektur
- `src/server.py` — FastMCP Server, registriert alle Tools
- `src/config.py` — Lädt .env, stellt Settings bereit
- `src/clients/` — Async HTTP-Clients für externe APIs
- `src/tools/` — MCP-Tool-Definitionen (nutzen Clients)

## Wichtige Hinweise
- NASA DEMO_KEY: 30 Requests/Stunde, 50/Tag (pro IP)
- Eigener Key kostenlos unter https://api.nasa.gov/
- EPIC, EONET, NASA Images, Exoplanet Archive: kein Key nötig
- FastMCP: `instructions` Parameter verwenden (nicht `description`)
- Server läuft standardmäßig über stdio-Transport
