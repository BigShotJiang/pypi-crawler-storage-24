"""
Prajnyavan SDK — Phase 1
------------------------
Persistent, emotionally-weighted memory for any LLM.

Quick start:
    from prajnyavan import MemoryClient
    import openai

    mem = MemoryClient(
        base_url="http://localhost:9999",
        token="Bearer <your-token>",
        openai_api_key="sk-..."   # for embeddings
    )

    @mem.wrap_llm(user_id="user_123")
    def chat(prompt):
        return openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}]
        ).choices[0].message.content

    chat("My dog Bruno loves long walks")
    chat("What should I get Bruno?")  # AI already knows Bruno is a dog
"""

from __future__ import annotations

import functools
import json
import os
import time
from typing import Any, Callable, Dict, List, Optional

import requests


# ── Embedding providers ────────────────────────────────────────────────────

def _embed_openai(text: str, api_key: str, model: str = "text-embedding-3-small") -> List[float]:
    """Real semantic embedding via OpenAI. ~50ms, costs ~$0.00002/1K tokens."""
    import openai
    client = openai.OpenAI(api_key=api_key)
    response = client.embeddings.create(model=model, input=text)
    return response.data[0].embedding   # 1536 floats


def _embed_cohere(text: str, api_key: str, model: str = "embed-english-v3.0") -> List[float]:
    """Real semantic embedding via Cohere."""
    import cohere
    co = cohere.Client(api_key)
    response = co.embed(texts=[text], model=model, input_type="search_document")
    return response.embeddings[0]


def _embed_local(text: str, model_name: str = "all-MiniLM-L6-v2") -> List[float]:
    """Free local embedding using sentence-transformers. No API key needed."""
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer(model_name)
    return model.encode(text).tolist()


# ── Main client ────────────────────────────────────────────────────────────

class MemoryClient:
    """
    Prajnyavan memory client.

    Parameters
    ----------
    base_url : str
        URL of the running prajnyavan_service, e.g. "http://localhost:9999"
    token : str
        Bearer token from /auth/token endpoint, e.g. "Bearer eyJ..."
    openai_api_key : str, optional
        OpenAI API key for embedding generation (recommended for Phase 1)
    embedding_provider : str
        "openai" (default) | "cohere" | "local"
    embedding_model : str, optional
        Override the default model for your chosen provider
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        openai_api_key: Optional[str] = None,
        embedding_provider: str = "openai",
        embedding_model: Optional[str] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.embedding_provider = embedding_provider
        self.embedding_model = embedding_model

        # Resolve API key from parameter or environment
        self._openai_key = openai_api_key or os.environ.get("OPENAI_API_KEY")

        self.session = requests.Session()
        self.session.headers.update({
            "authorization": token,
            "content-type": "application/json",
        })

    def embed(self, text: str) -> List[float]:
        """
        Convert text to a vector embedding.
        This is the ONLY place embeddings are generated — keeps it swappable.
        """
        if self.embedding_provider == "openai":
            if not self._openai_key:
                raise ValueError(
                    "OpenAI API key required. Pass openai_api_key=... or set OPENAI_API_KEY env var."
                )
            model = self.embedding_model or "text-embedding-3-small"
            return _embed_openai(text, self._openai_key, model)

        elif self.embedding_provider == "cohere":
            cohere_key = os.environ.get("COHERE_API_KEY", "")
            model = self.embedding_model or "embed-english-v3.0"
            return _embed_cohere(text, cohere_key, model)

        elif self.embedding_provider == "local":
            model = self.embedding_model or "all-MiniLM-L6-v2"
            return _embed_local(text, model)

        else:
            raise ValueError(f"Unknown embedding provider: {self.embedding_provider}")

    # ── Core memory API ───────────────────────────────────────────────────

    def store(
        self,
        user_id: str,
        content: str,
        *,
        importance: Optional[float] = None,
        category: Optional[str] = None,
        ttl_days: Optional[int] = None,
        tags: Optional[List[str]] = None,
    ) -> str:
        """
        Store a memory for a user.

        The content is embedded here in Python (real semantic embedding),
        then sent to the Rust service with the vector attached.
        This means the Rust service never needs to call an external API.

        Returns the memory ID (UUID string).
        """
        # Generate real embedding
        embedding = self.embed(content)

        payload: Dict[str, Any] = {
            "content": content,
            "modality": "text",
            "user_id": user_id,
            "embedding": embedding,   # <-- real vector, not a hash
            "tags": tags or [],
        }
        if importance is not None:
            payload["importance"] = float(importance)
        if category:
            payload["category"] = category
        if ttl_days:
            payload["ttl_days"] = ttl_days

        resp = self.session.post(
            f"{self.base_url}/memory",
            data=json.dumps(payload),
            timeout=10
        )
        resp.raise_for_status()
        return resp.json()["id"]

    def search(
        self,
        user_id: str,
        query: str,
        *,
        k: int = 5,
        valence_bias: Optional[str] = None,  # "positive" | "negative"
        min_importance: Optional[float] = None,
        category: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Search for relevant memories for a user.

        The query is embedded here in Python, then sent to the Rust service.
        Returns top-k memories ranked by: vector_similarity × (1 + importance) × recency_decay
        """
        # Generate real embedding for the query
        embedding = self.embed(query)

        payload: Dict[str, Any] = {
            "query": query,
            "embedding": embedding,   # <-- real vector for semantic search
            "k": k,
            "filters": {"person": user_id},
        }
        if valence_bias:
            payload["filters"]["valence_bias"] = valence_bias
        if min_importance is not None:
            payload["filters"]["min_importance"] = min_importance
        if category:
            payload["filters"]["category"] = category

        resp = self.session.post(
            f"{self.base_url}/memory/search",
            data=json.dumps(payload),
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("results", [])

    def delete_user(self, user_id: str) -> int:
        """Delete ALL memories for a user. GDPR Article 17 compliance."""
        resp = self.session.delete(
            f"{self.base_url}/memory/user/{user_id}",
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("deleted", 0)

    def export_user(self, user_id: str) -> List[Dict[str, Any]]:
        """Export all memories for a user as JSON. GDPR Article 20 compliance."""
        resp = self.session.get(
            f"{self.base_url}/memory/export/{user_id}",
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("memories", [])

    def highlights(self, user_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Return the top-N most emotionally important memories for a user."""
        resp = self.session.get(
            f"{self.base_url}/memory/highlights/{user_id}",
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("highlights", [])[:limit]

    def summary(self, user_id: str, days: int = 7) -> str:
        """Return a natural language summary of a user's recent memories."""
        resp = self.session.get(
            f"{self.base_url}/memory/summary/{user_id}",
            params={"days": days},
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("summary", "")

    def explain(self, query: str) -> List[Dict[str, Any]]:
        """
        Debug tool: shows which memories would be retrieved for a query
        and why each one scored the way it did.
        """
        embedding = self.embed(query)
        payload = {"query": query, "embedding": embedding, "k": 5}
        resp = self.session.post(
            f"{self.base_url}/memory/explain",
            data=json.dumps(payload),
            timeout=10
        )
        resp.raise_for_status()
        return resp.json().get("results", [])

    # ── Decorator ─────────────────────────────────────────────────────────

    def wrap_llm(
        self,
        user_id: str,
        *,
        k: int = 5,
        valence_bias: Optional[str] = None,
        debug: bool = False,
    ):
        """
        Decorator that gives any LLM function persistent memory.

        Works with OpenAI, Claude, Gemini, Perplexity — any LLM.
        The same user_id works across all of them.

        What happens automatically:
          1. Before LLM call: retrieves top-k relevant memories, injects into prompt
          2. After LLM call: stores the interaction as a new memory (async)

        Example:
            @mem.wrap_llm(user_id="user_123")
            def chat(prompt):
                return openai_client.chat(prompt)

        debug=True returns {"result": ..., "memories_used": [...]} instead of just the string.
        """
        def decorator(fn: Callable[..., str]):
            @functools.wraps(fn)
            def wrapper(prompt: str, *args, **kwargs):
                # Step 1: retrieve relevant memories
                memories = self.search(user_id, prompt, k=k, valence_bias=valence_bias)

                # Step 2: build enriched prompt
                if memories:
                    ctx_lines = [
                        f"- ({m.get('importance', 0):.2f} importance) {m.get('content_text') or m.get('content', '')}"
                        for m in memories
                    ]
                    enriched = (
                        "Relevant memories about this user:\n"
                        + "\n".join(ctx_lines)
                        + "\n\nUser message: "
                        + prompt
                    )
                else:
                    enriched = prompt

                # Step 3: call the LLM with memory context
                result = fn(enriched, *args, **kwargs)

                # Step 4: store this interaction as a new memory
                # (fire and forget — doesn't block the response)
                try:
                    interaction = f"User said: {prompt}"
                    self.store(user_id, interaction)
                except Exception:
                    pass  # never crash the LLM call because of memory storage

                if debug:
                    return {"result": result, "memories_used": memories}
                return result

            return wrapper
        return decorator


# ── Helper: get a token from the service ──────────────────────────────────

def get_token(base_url: str, user_id: str = "developer") -> str:
    """
    Get a bearer token from the service.
    Use this once at startup and pass the token to MemoryClient.

    Example:
        token = get_token("http://localhost:9999")
        mem = MemoryClient(base_url="http://localhost:9999", token=token)
    """
    resp = requests.post(
        f"{base_url.rstrip('/')}/auth/token",
        json={"user_id": user_id, "capabilities": ["read", "write"]},
        timeout=8
    )
    resp.raise_for_status()
    return f"Bearer {resp.json()['token']}"


__all__ = ["MemoryClient", "get_token"]
