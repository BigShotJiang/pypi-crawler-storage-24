"""
Prajnyavan — persistent, emotionally-weighted memory for any LLM.

Quick start:
    pip install prajnyavan[openai]

    from prajnyavan import MemoryClient, get_token
"""

from .client import MemoryClient, get_token

__version__ = "0.1.1"
__all__ = ["MemoryClient", "get_token"]
