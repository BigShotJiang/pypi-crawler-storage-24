# Prajnyavan — The Memory Layer for AI

Persistent, emotionally-weighted memory for any LLM.  
Works with ChatGPT, Claude, Gemini, Perplexity — any model.

```python
@mem.wrap_llm(user_id="user_123")
def chat(prompt):
    return openai_client.chat(prompt)

chat("My dog Bruno loves long walks")   # Monday
chat("What should I get Bruno?")        # Friday — AI already knows Bruno is a dog
```

---

## Quickstart (5 minutes)

### Step 1 — Start the service

```bash
# Clone the repo
git clone https://github.com/yourname/prajnyavan
cd prajnyavan

# Set up environment
cp .env.example .env
# Edit .env — add your BRAIN_SECRET_KEY (any long random string)

# Start with Docker (one command)
docker-compose up -d

# Check it's running
curl http://localhost:9999/health
# → {"status": "healthy"}
```

### Step 2 — Install the Python SDK

```bash
# With OpenAI embeddings (recommended)
pip install prajnyavan[openai]

# Or with no external embeddings (free, runs locally)
pip install prajnyavan[local]
```

### Step 3 — Use it

```python
import os
from prajnyavan import MemoryClient, get_token
import openai

# Connect
token = get_token("http://localhost:9999")
mem = MemoryClient(
    base_url="http://localhost:9999",
    token=token,
    openai_api_key=os.environ["OPENAI_API_KEY"]
)

# Wrap your LLM — this one line adds persistent memory
@mem.wrap_llm(user_id="user_123")
def chat(prompt):
    return openai.OpenAI().chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    ).choices[0].message.content

# It works
chat("My dog Bruno loves long walks")
chat("What should I get Bruno for his birthday?")
# → "Since Bruno loves walks, maybe a new leash or outdoor toy!"
```

---

## Works with any LLM

```python
import anthropic

@mem.wrap_llm(user_id="user_123")   # same user_id = same memories
def chat_with_claude(prompt):
    return anthropic.Anthropic().messages.create(
        model="claude-opus-4-6",
        max_tokens=1000,
        messages=[{"role": "user", "content": prompt}]
    ).content[0].text

# Claude reads the same memories as ChatGPT
chat_with_claude("What do you know about Bruno?")
# → "Bruno is your dog who loves long walks..."
```

---

## API reference

```python
from prajnyavan import MemoryClient, get_token

token = get_token("http://localhost:9999")
mem = MemoryClient(base_url="http://localhost:9999", token=token)

# Store a memory manually
mem.store(user_id="user_123", content="User lives in Kathmandu")

# Search memories
results = mem.search(user_id="user_123", query="where does the user live?")

# Delete all memories (GDPR)
mem.delete_user(user_id="user_123")

# Export all memories (GDPR Article 20)
data = mem.export_user(user_id="user_123")

# Top emotionally important memories
highlights = mem.highlights(user_id="user_123")

# Recent memory summary
summary = mem.summary(user_id="user_123", days=7)

# Debug: see which memories fired and why
info = mem.explain("what do I know about this user?")
```

---

## Embedding providers

```python
# OpenAI (default, best quality)
mem = MemoryClient(..., embedding_provider="openai", openai_api_key="sk-...")

# Free local model (no API key, runs on your machine)
mem = MemoryClient(..., embedding_provider="local")

# Cohere
mem = MemoryClient(..., embedding_provider="cohere")
```

---

## How it works

Every message gets converted to a 1536-number vector that represents its meaning.  
When a user comes back, their new message is converted the same way, and Prajnyavan  
finds the most similar past memories mathematically — in under 100ms.

Memories that were more emotionally significant score higher, so "my mother passed away"  
will always surface above "I like pizza" even if both are equally related to the query.

---

## Requirements

- Docker (for the service)
- Python 3.9+
- OpenAI API key (for embeddings) — or run free with `embedding_provider="local"`

---

## License

MIT
