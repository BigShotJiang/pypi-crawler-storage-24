def test_wal_basic(tmp_path):
    from brain_db._native import PyWal

    wal_path = tmp_path / "demo.wal"
    wal = PyWal(str(wal_path))

    # Write two payloads
    wal.append(b"hello")
    wal.append(b"world")

    # Replay and collect
    received = []

    def collector(data):
        received.append(bytes(data))

    wal.replay(collector)

    assert received == [b"hello", b"world"]
