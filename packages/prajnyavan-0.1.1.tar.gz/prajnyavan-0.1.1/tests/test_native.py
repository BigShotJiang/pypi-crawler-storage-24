def test_hello():
    import brain_db._native as native
    assert native.hello() == "🧠 Brain‑DB is alive!"
