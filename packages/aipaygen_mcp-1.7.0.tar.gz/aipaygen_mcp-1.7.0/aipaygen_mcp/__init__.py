"""AiPayGen MCP Server — 148 AI tools for Claude, Cursor, and any MCP client."""

__version__ = "1.7.0"
