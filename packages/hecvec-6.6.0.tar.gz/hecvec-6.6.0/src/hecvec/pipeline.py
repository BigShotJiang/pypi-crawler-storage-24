"""
Pipeline: composes listdir → read → token-chunk → embed → Chroma.
One module = one responsibility: orchestrate the full slice() flow.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from time import perf_counter
from typing import Any, Literal

DbType = Literal["chroma"]

from hecvec.chroma_client import add_documents, get_client
from hecvec.chroma_list import list_collections_from_client
from hecvec.chunkers import ChunkingMethod, chunk_documents as chunk_documents_by_method
from hecvec.embeddings import embed_texts
from hecvec.env import load_openai_key
from hecvec.listdir import ListDirTextFiles
from hecvec.reading import ReadText

logger = logging.getLogger(__name__)


def _ensure_slice_logging() -> None:
    """If hecvec logging has no handlers, attach a stream handler at INFO so slice() progress is visible."""
    hecvec_logger = logging.getLogger("hecvec")
    if not hecvec_logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.INFO)
        handler.setFormatter(logging.Formatter("%(message)s"))
        hecvec_logger.setLevel(logging.INFO)
        hecvec_logger.addHandler(handler)
    elif hecvec_logger.level == logging.NOTSET:
        hecvec_logger.setLevel(logging.INFO)


def _check_chroma_deps() -> None:
    try:
        import chromadb  # noqa: F401
        from langchain_text_splitters import TokenTextSplitter  # noqa: F401
        from openai import OpenAI  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "Chroma pipeline requires chromadb and other deps. Install with:\n"
            "  pip install hecvec[chroma]\n"
            "Then run your script with the same Python (or same venv) you used to install. "
            "If you're in the HecVec repo, use: uv run python scripts/test_slice.py ..."
        ) from e


def _get_db_client(
    db: DbType,
    *,
    host: str = "localhost",
    port: int = 8000,
    user: str | None = None,
    password: str | None = None,
    **kwargs: Any,
) -> Any:
    """
    Return a database client for the given db type using the connection parameters.
    Only db="chroma" is supported; uses host and port to connect.
    """
    if db != "chroma":
        raise ValueError(f"Only db='chroma' is supported; got db={db!r}")
    _check_chroma_deps()
    return get_client(host=host, port=port, user=user, password=password)


class Slicer:
    """
    Library-only pipeline. No API.
    Call slice(path=...) to: list path → filter .txt/.md → token-chunk → push to Chroma.
    """

    def __init__(
        self,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        embedding_model: str = "text-embedding-3-small",
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        openai_api_key: str | None = None,
        dotenv_path: str | Path | None = None,
    ):
        if db != "chroma":
            raise ValueError(f"Only db='chroma' is supported; got db={db!r}")
        self.root = Path(root).resolve() if root else Path.cwd()
        self.collection_name = collection_name
        self.db = db
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.embedding_model = embedding_model
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.encoding_name = encoding_name
        self.batch_size = batch_size
        self._dotenv_path = dotenv_path
        self._openai_api_key = openai_api_key or load_openai_key(dotenv_path)

    def slice(
        self,
        path: str | Path,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run the pipeline for this instance (uses instance config)."""
        return self._slice_impl(
            path,
            root=kwargs.pop("root", self.root),
            collection_name=kwargs.pop("collection_name", self.collection_name),
            db=kwargs.pop("db", self.db),
            host=kwargs.pop("host", kwargs.pop("chroma_host", self.host)),
            port=kwargs.pop("port", kwargs.pop("chroma_port", self.port)),
            user=kwargs.pop("user", kwargs.pop("chroma_user", self.user)),
            password=kwargs.pop("password", kwargs.pop("chroma_password", self.password)),
            embedding_model=kwargs.pop("embedding_model", self.embedding_model),
            chunk_size=kwargs.pop("chunk_size", self.chunk_size),
            chunk_overlap=kwargs.pop("chunk_overlap", self.chunk_overlap),
            encoding_name=kwargs.pop("encoding_name", self.encoding_name),
            batch_size=kwargs.pop("batch_size", self.batch_size),
            chunking_method=kwargs.pop("chunking_method", "token"),
            openai_api_key=kwargs.pop("openai_api_key", self._openai_api_key),
            dotenv_path=kwargs.pop("dotenv_path", self._dotenv_path),
            **kwargs,
        )

    def collections(self, **kwargs: Any) -> list[tuple[str, int]]:
        """List all collections (name, count) using this instance's db config."""
        return self._collections_impl(
            db=kwargs.pop("db", self.db),
            host=kwargs.pop("host", kwargs.pop("chroma_host", self.host)),
            port=kwargs.pop("port", kwargs.pop("chroma_port", self.port)),
            user=kwargs.pop("user", kwargs.pop("chroma_user", self.user)),
            password=kwargs.pop("password", kwargs.pop("chroma_password", self.password)),
            **kwargs,
        )

    @classmethod
    def slice_path(
        cls,
        path: str | Path,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        embedding_model: str = "text-embedding-3-small",
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        chunking_method: ChunkingMethod = "token",
        openai_api_key: str | None = None,
        dotenv_path: str | Path | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Run the full pipeline: find path → listdir → filter .txt/.md → chunk → push to db.
        db='chroma' only; connection uses host and port. Server must be listening.
        If the resolved collection name already exists, new chunks are appended to it (not skipped).
        """
        return cls._slice_impl(
            path,
            root=root,
            collection_name=collection_name,
            db=db,
            host=host,
            port=port,
            user=user,
            password=password,
            embedding_model=embedding_model,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            encoding_name=encoding_name,
            batch_size=batch_size,
            chunking_method=chunking_method,
            openai_api_key=openai_api_key,
            dotenv_path=dotenv_path,
            **kwargs,
        )

    @classmethod
    def _slice_impl(
        cls,
        path: str | Path,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        embedding_model: str = "text-embedding-3-small",
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        chunking_method: ChunkingMethod = "token",
        openai_api_key: str | None = None,
        dotenv_path: str | Path | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        if db != "chroma":
            raise ValueError(f"Only db='chroma' is supported; got db={db!r}")
        _check_chroma_deps()
        _ensure_slice_logging()

        total_start = perf_counter()
        logger.info("[0/6] Starting slice | path=%s | method=%s | model=%s", path, chunking_method, embedding_model)

        path = Path(path).resolve()
        if not path.exists():
            raise ValueError(f"path does not exist: {path}")

        if collection_name == "hecvec":
            collection_name = path.stem if path.is_file() else path.name
        # Include chunking configuration in the collection name so reruns with a different
        # chunk_size/chunk_overlap do not collide with an existing collection.
        if chunking_method == "token":
            cfg_suffix = f"cs{chunk_size}_ov{chunk_overlap}_enc{encoding_name}"
        elif chunking_method == "text":
            cfg_suffix = f"cs{chunk_size}_ov{chunk_overlap}"
        else:
            # For semantic/llm we keep the suffix minimal since advanced knobs aren't exposed on Slicer.
            cfg_suffix = f"cs{chunk_size}"
        collection_name = f"{collection_name}_{chunking_method}_{cfg_suffix}"

        logger.info("Resolved collection name: %s", collection_name)

        stage_start = perf_counter()
        if path.is_file():
            if path.suffix.lower() not in (".txt", ".md"):
                raise ValueError(f"File must be .txt or .md: {path}")
            root = path.parent
            paths = [path]
            logger.info("Single file: %s", path)
        else:
            root = Path(root).resolve() if root else path
            if not root.is_dir():
                raise ValueError(f"path must be an existing directory: {root}")
            logger.info("Scanning directory: %s", root)
            lister = ListDirTextFiles(root=root)
            paths = lister.listdir_recursive_txt_md(path)
            if not paths:
                logger.warning("No .txt/.md files found under %s", path)
                return {"files": 0, "chunks": 0, "collection": collection_name, "message": "No .txt/.md files found"}
            logger.info("Found %d .txt/.md file(s)", len(paths))
            for p in paths[:10]:
                logger.info("  %s", p)
            if len(paths) > 10:
                logger.info("  ... and %d more", len(paths) - 10)

        logger.info("[1/6] File discovery completed in %.2fs (%d file(s))", perf_counter() - stage_start, len(paths))

        # 2/6 Chroma server check: fail fast if nothing is listening (before read/chunk/embed to save time & API cost).
        # Step 6 always writes: if the collection name already exists, new chunks are appended (concatenated).
        stage_start = perf_counter()
        logger.info("[2/6] Chroma server check | db=%s | host=%s | port=%s", db, host, port)
        client = _get_db_client(db, host=host, port=port, user=user, password=password)
        logger.info("[2/6] Server reachable at %s:%s in %.2fs (client kept for final write)", host, port, perf_counter() - stage_start)

        # 3/6 Read as text
        stage_start = perf_counter()
        logger.info("[3/6] Reading content from %d file(s)...", len(paths))
        reader = ReadText(paths)
        path_and_text = reader.read_all()
        logger.info("[3/6] Read completed in %.2fs (%d/%d file(s) read)", perf_counter() - stage_start, len(path_and_text), len(paths))
        if len(path_and_text) < len(paths):
            logger.warning("Some files could not be read and were skipped (%d skipped)", len(paths) - len(path_and_text))

        # 4/6 Chunk (token, text, semantic, or llm)
        stage_start = perf_counter()
        api_key = openai_api_key or load_openai_key(dotenv_path)
        logger.info("[4/6] Chunking | method=%s | chunk_size=%d | overlap=%d", chunking_method, chunk_size, chunk_overlap)
        ids, documents = chunk_documents_by_method(
            path_and_text,
            method=chunking_method,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            encoding_name=encoding_name,
            openai_api_key=api_key,
        )
        if not documents:
            logger.warning("[4/6] No chunks generated (empty or non-text content)")
            return {"files": len(path_and_text), "chunks": 0, "collection": collection_name}

        logger.info("[4/6] Chunking completed in %.2fs (%d chunk(s))", perf_counter() - stage_start, len(documents))

        # 5/6 Embed
        api_key = openai_api_key or load_openai_key(dotenv_path)
        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY required for embeddings. "
                "Set it in .env, pass openai_api_key=, or set the OPENAI_API_KEY env var."
            )
        stage_start = perf_counter()
        logger.info("[5/6] Generating embeddings | model=%s | batch_size=%d | chunk_count=%d", embedding_model, batch_size, len(documents))
        embeddings = embed_texts(
            documents,
            api_key=api_key,
            model=embedding_model,
            batch_size=batch_size,
        )
        logger.info("[5/6] Embeddings completed in %.2fs (%d vector(s))", perf_counter() - stage_start, len(embeddings))

        # 6/6 Push to Chroma (reuse client from server check). Always add: append into an existing collection if the name is already in use.
        stage_start = perf_counter()
        logger.info("[6/6] db=%s | host=%s | port=%s | collection=%s", db, host, port, collection_name)
        logger.info("[6/6] Writing %d document chunk(s) to collection...", len(documents))
        add_result = add_documents(client, collection_name, ids, embeddings, documents)
        if add_result["collection_existed"]:
            logger.info(
                "[6/6] Collection %r already existed — concatenating: appending these chunks to that collection (same name).",
                collection_name,
            )
        else:
            logger.info("[6/6] Collection %r did not exist before this run; created and populated.", collection_name)
        logger.info("[6/6] Chroma write completed in %.2fs", perf_counter() - stage_start)

        if add_result["collection_existed"]:
            logger.info(
                "Slice finished in %.2fs | files=%d | chunks=%d | collection=%s | appended to existing collection",
                perf_counter() - total_start,
                len(path_and_text),
                len(documents),
                collection_name,
            )
        else:
            logger.info(
                "Slice finished in %.2fs | files=%d | chunks=%d | collection=%s",
                perf_counter() - total_start,
                len(path_and_text),
                len(documents),
                collection_name,
            )

        out: dict[str, Any] = {
            "files": len(path_and_text),
            "chunks": len(documents),
            "collection": collection_name,
            "appended_to_existing": add_result["collection_existed"],
        }
        if add_result["collection_existed"]:
            out["message"] = (
                f"Collection {collection_name!r} already existed; appended {len(documents)} chunk(s) (concatenated)."
            )
        return out

    @classmethod
    def collections_server(
        cls,
        *,
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        **kwargs: Any,
    ) -> list[tuple[str, int]]:
        """
        List all collections (name, count) from the db. db='chroma' only; uses host and port.
        Returns [(collection_name, document_count), ...]. Server must be listening.
        """
        return cls._collections_impl(db=db, host=host, port=port, user=user, password=password, **kwargs)

    @classmethod
    def _collections_impl(
        cls,
        *,
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        **kwargs: Any,
    ) -> list[tuple[str, int]]:
        if db != "chroma":
            raise ValueError(f"Only db='chroma' is supported; got db={db!r}")
        client = _get_db_client(db, host=host, port=port, user=user, password=password)
        return list_collections_from_client(client)

