<!-- code2docs:start --># proxy

![version](https://img.shields.io/badge/version-0.1.0-blue) ![python](https://img.shields.io/badge/python-%3E%3D3.11-blue) ![coverage](https://img.shields.io/badge/coverage-unknown-lightgrey) ![functions](https://img.shields.io/badge/functions-2411-green)
> **2411** functions | **255** classes | **317** files | CC̄ = 4.6

> Auto-generated project documentation from source code analysis.

**Author:** Tom Sapletta  
**License:** Apache-2.0  
**Repository:** [https://github.com/wronai/proxy](https://github.com/wronai/proxy)

## Installation

### From PyPI

```bash
pip install proxy
```

### From Source

```bash
git clone https://github.com/wronai/proxy
cd proxy
pip install -e .
```

### Optional Extras

```bash
pip install proxy[gpu]    # gpu features
pip install proxy[jetson]    # jetson features
pip install proxy[vm]    # vm features
pip install proxy[voice]    # voice features
pip install proxy[tts]    # tts features
pip install proxy[test]    # testing tools
pip install proxy[dev]    # development tools
```

## Quick Start

### CLI Usage

```bash
# Generate full documentation for your project
proxy ./my-project

# Only regenerate README
proxy ./my-project --readme-only

# Preview what would be generated (no file writes)
proxy ./my-project --dry-run

# Check documentation health
proxy check ./my-project

# Sync — regenerate only changed modules
proxy sync ./my-project
```

### Python API

```python
from proxy import generate_readme, generate_docs, Code2DocsConfig

# Quick: generate README
generate_readme("./my-project")

# Full: generate all documentation
config = Code2DocsConfig(project_name="mylib", verbose=True)
docs = generate_docs("./my-project", config=config)
```

## Generated Output

When you run `proxy`, the following files are produced:

```
<project>/
├── README.md                 # Main project README (auto-generated sections)
├── docs/
│   ├── api.md               # Consolidated API reference
│   ├── modules.md           # Module documentation with metrics
│   ├── architecture.md      # Architecture overview with diagrams
│   ├── dependency-graph.md  # Module dependency graphs
│   ├── coverage.md          # Docstring coverage report
│   ├── getting-started.md   # Getting started guide
│   ├── configuration.md    # Configuration reference
│   └── api-changelog.md    # API change tracking
├── examples/
│   ├── quickstart.py       # Basic usage examples
│   └── advanced_usage.py   # Advanced usage examples
├── CONTRIBUTING.md         # Contribution guidelines
└── mkdocs.yml             # MkDocs site configuration
```

## Configuration

Create `proxy.yaml` in your project root (or run `proxy init`):

```yaml
project:
  name: my-project
  source: ./
  output: ./docs/

readme:
  sections:
    - overview
    - install
    - quickstart
    - api
    - structure
  badges:
    - version
    - python
    - coverage
  sync_markers: true

docs:
  api_reference: true
  module_docs: true
  architecture: true
  changelog: true

examples:
  auto_generate: true
  from_entry_points: true

sync:
  strategy: markers    # markers | full | git-diff
  watch: false
  ignore:
    - "tests/"
    - "__pycache__"
```

## Sync Markers

proxy can update only specific sections of an existing README using HTML comment markers:

```markdown
<!-- proxy:start -->
# Project Title
... auto-generated content ...
<!-- proxy:end -->
```

Content outside the markers is preserved when regenerating. Enable this with `sync_markers: true` in your configuration.

## Architecture

```
proxy/
            ├── hello            ├── calculator        ├── quickstart        ├── advanced_usage    ├── proxym-voice-chat    ├── seed_sprint8    ├── fix_corrupted_db    ├── proxym/        ├── project_config        ├── storage        ├── ctl            ├── webhooks            ├── _tickets_support        ├── config            ├── _events_sse        ├── dashboard/            ├── _projects_api            ├── _system            ├── _costs            ├── integrations_api            ├── orchestrator            ├── _tickets_api            ├── _shared            ├── _lifecycle            ├── _setup_api            ├── _accounts            ├── _environments_api        ├── projects/            ├── _enrichment        ├── cache/            ├── _tickets_models            ├── _definition            ├── _enums        ├── middleware/        ├── tools/            ├── startup            ├── _builtins            ├── _instance            ├── _registry            ├── browser_profiles            ├── _infra            ├── _enums        ├── virt/            ├── _snapshot            ├── _vm_config            ├── _check            ├── _vms            ├── _project            ├── clonebox_adapter            ├── _config            ├── _orchestrator            ├── _state            ├── system            ├── _cli_schema            ├── browser            ├── observability            ├── diagnostics            ├── vms        ├── cli/            ├── config_validate            ├── context            ├── _lifecycle            ├── chat            ├── _client            ├── voice            ├── smart_defaults            ├── tickets            ├── dsl            ├── tts            ├── accounts            ├── vscode            ├── executor            ├── bus        ├── providers/        ├── domain/            ├── setup        ├── utils/            ├── get_settings            ├── messages            ├── _helpers            ├── registry        ├── mcp/            ├── client            ├── _tools_accounts            ├── events            ├── _tools_tickets            ├── router            ├── _tools_system            ├── self_server            ├── _tools_vm            ├── _tools_vallm        ├── accounts/            ├── health_events        ├── observability/            ├── watchdog        ├── context/            ├── repair_agent            ├── _context            ├── detector            ├── tool_selector        ├── external/            ├── config            ├── session        ├── router/            ├── _diag_proxy            ├── _diag_common            ├── providers            ├── voice_actions            ├── _diag_roo            ├── completions            ├── system            ├── observability_api            ├── vscode_api            ├── _diag_agent        ├── api/            ├── diagnostics            ├── strategy            ├── console            ├── _pipeline            ├── _diag_providers            ├── _diag_vscode            ├── frontend            ├── _state            ├── context_api            ├── client        ├── watch/                ├── setup_commands                ├── user_commands            ├── commands/                ├── project_commands                ├── task_commands                ├── task_handler            ├── handlers/                ├── setup_handler                ├── user_handler            ├── queries/                ├── project_queries                ├── user_queries                ├── setup_queries                ├── cmd_sessions_list                ├── project_handler                ├── tickets_ctl                ├── diagnostics_ctl            ├── _groups/                ├── accounts_ctl                ├── projects_ctl                ├── context_ctl                ├── tools_ctl                ├── multi_ctl                ├── observability_ctl                ├── _shared                ├── vms_ctl            ├── external_api                ├── vscode_ctl                ├── external_ctl                ├── keys_ctl                ├── browser_ctl                ├── detect_chrome_profiles            ├── profiles/                ├── _claude_code                ├── do_ctl                ├── _human                ├── _plandex                ├── _llm_cli                ├── _result                ├── _vscode                ├── _codex            ├── adapters/                ├── _aider                ├── _goose                ├── _llm_fallback                ├── _interpreter                ├── _shell            ├── tickets/                ├── _base                ├── _models                ├── _helpers                ├── TicketManagerRefactored                ├── _providers            ├── tools/                ├── _queue                ├── HealthCheckerRefactored                ├── _health                ├── _lifecycle                ├── _manager                ├── _dispatch            ├── utils/                ├── _registry                ├── delete_milestone                ├── _delete_item                ├── _emit_event                ├── delete_ticket                ├── _api            ├── users/                ├── _permissions                ├── _models                ├── _autofix                ├── _git_sync                ├── _api_models                ├── utils/                    ├── _aider_install_fix                    ├── start_executor                    ├── delete_ticket        ├── benchmark                    ├── calculator                    ├── greeter                        ├── greeter        ├── proxym_tools            ├── types            ├── commands        ├── templates/            ├── format            ├── store                ├── Panel    ├── dashboard-sse-service            ├── api                ├── useDashboardData                ├── formatters                        ├── jobFormatters    ├── proxym-dashboard            ├── panel                ├── voice                ├── diagnostics                ├── _git_support                ├── voice_engine                ├── logs                ├── human                ├── vms                ├── ui                ├── tools                ├── tasks                ├── overview                ├── models                ├── tickets                ├── home                ├── voice_schemas                ├── projects                ├── system                ├── environments                ├── layout                ├── accounts                ├── users                ├── setup                    ├── TicketFilters                    ├── BulkOperations                    ├── TicketList                ├── integrations                    ├── TicketStats                    ├── DiagConfig                    ├── DiagExtensions                    ├── helpers                    ├── DiagInfrastructure                    ├── DiagAgent                    ├── ToolCard                    ├── TicketsPanelRefactored                    ├── JobRow                    ├── PredictiveAlerts                    ├── DiagnosticActions                    ├── DispatchTableHeader                ├── _manager                    ├── ProjectInfoResolver                    ├── ToolsJobQueue                    ├── ToolsPanelRefactored                    ├── HealthTrends                    ├── TicketStatusBadges                    ├── DispatchTableRow                    ├── TicketDispatchTableRefactored                    ├── ToolsDispatch                    ├── ProviderConfigPanel                    ├── JobDetailsPanel                    ├── ToolHealthCard                    ├── ToolsRegistry                    ├── DispatchActions                    ├── QueueSummary                    ├── ToolAvailabilityAlert                    ├── BulkAutoFix                    ├── ToolHealthDisplay                    ├── TasksBoard                    ├── TasksList                    ├── TasksTable                    ├── TasksViewControls                    ├── ToolHealthPanelRefactored                    ├── TasksRecentJobs                    ├── HumanTaskTable                    ├── HumanTaskBoard                    ├── HumanJobsList                    ├── HumanTaskList                    ├── HumanViewControls                    ├── TasksPanelRefactored                    ├── HumanTaskStats                    ├── TicketConstants                    ├── RecentJobsList                    ├── HumanTaskPanelRefactored                    ├── ProjectExport                    ├── TableExport                    ├── ViewControls                        ├── JobStatusBadge├── project                        ├── JobRow    ├── dry-run-commands    ├── cli_shell_scenario    ├── jetson-entrypoint    ├── dry-run-all-examples    ├── setup    ├── evaluate_llm_work    ├── check_dashboard    ├── proxym-voice-server        ├── entrypoint    ├── validate_system        ├── run                    ├── EditableTicketTable        ├── run        ├── run        ├── run        ├── verify        ├── main```

## API Overview

### Classes

- **`ProjectConfig`** — Parsed ``.proxym.yaml`` with sensible defaults.
- **`SQLiteNamespaceStore`** — —
- **`WebhookManager`** — Manages webhooks to external systems.
- **`Settings`** — All settings with sensible defaults. Override via env vars or .env file.
- **`AddProjectReq`** — Dodaj projekt — jedno z: path, git_url, ssh.
- **`UpdateProjectReq`** — —
- **`ScanReq`** — —
- **`WebhookRegistration`** — Webhook registration request.
- **`WebhookInfo`** — Webhook information.
- **`TicketOrchestrator`** — Orchestrates ticket status transitions based on job events.
- **`LifecycleMixin`** — Mixin providing start/stop lifecycle and singleton pattern.
- **`ToggleSetupStepReq`** — —
- **`CreateAccountReq`** — —
- **`BindToolReq`** — —
- **`EnvironmentKind`** — —
- **`Environment`** — —
- **`EnvironmentCreateRequest`** — —
- **`EnvironmentUpdateRequest`** — —
- **`ToolEnvironmentAssignRequest`** — —
- **`EnvironmentRegistry`** — —
- **`SourceType`** — —
- **`ProjectStatus`** — —
- **`Project`** — Jeden projekt w systemie proxym.
- **`ProjectRegistry`** — Rejestr projektów z persystencją JSON.
- **`FileSnapshot`** — Immutable snapshot of a single file.
- **`DeltaPayload`** — Computed delta between two context snapshots.
- **`DeltaBuffer`** — Maintains file snapshots and computes minimal diffs.
- **`CreateTicketReq`** — —
- **`UpdateTicketReq`** — —
- **`AssignToolReq`** — —
- **`AddCommentReq`** — —
- **`CreateSprintReq`** — —
- **`UpdateSprintReq`** — —
- **`CreateMilestoneReq`** — —
- **`UpdateMilestoneReq`** — —
- **`ToolDefinition`** — Describes a registered development tool.
- **`ToolCategory`** — High-level tool categories.
- **`ToolCapability`** — Capabilities a tool can advertise.
- **`AuthMiddleware`** — Simple bearer token auth (matches LiteLLM master_key pattern).
- **`CostTrackingMiddleware`** — Log request timing and attach cost headers to responses.
- **`ToolStartupOrchestrator`** — Probes tools on startup and periodically; emits SSE events.
- **`ToolInstance`** — Concrete runtime instance for a registered tool.
- **`ToolRegistry`** — Singleton registry of available development tools.
- **`BrowserProfile`** — Detected browser profile on the host.
- **`AppDataSync`** — Configuration for syncing browser data into a VM.
- **`VMBackend`** — —
- **`VMState`** — —
- **`CreateVMReq`** — —
- **`SwitchProjectReq`** — —
- **`AssignToolReq`** — —
- **`CloneBoxResult`** — Result of a clonebox CLI invocation.
- **`CloneBoxAdapter`** — Adapter wrapping the clonebox CLI for VM operations.
- **`ProjectsConfig`** — Configuration for shared project mounts from the host.
- **`VMConfig`** — Configuration for a development VM.
- **`VMStatus`** — Runtime status of a VM.
- **`VMOrchestrator`** — Manages VMs for isolated dev environments.
- **`CLICommand`** — Represents a CLI command.
- **`ConfigIssue`** — A configuration issue with severity and fix instructions.
- **`ConfigValidator`** — Validates Proxym configuration from .env file.
- **`VoiceListener`** — Local STT: microphone → text via Faster-Whisper.
- **`ParsedCommand`** — Result of successfully parsing a user phrase against the DSL.
- **`DSLParser`** — Parse natural language phrases into proxym API calls.
- **`TTSEngine`** — Text-to-speech engine with pluggable backends.
- **`JobStatus`** — —
- **`ToolJob`** — A single tool execution job.
- **`ToolExecutor`** — Async executor for tool jobs with a bounded queue.
- **`Command`** — Base class for commands (write operations).
- **`Query`** — Base class for queries (read operations).
- **`CommandBus`** — Dispatches commands to registered handlers.
- **`QueryBus`** — Dispatches queries to registered handlers.
- **`TaskTier`** — Complexity tier that determines which model class is needed.
- **`Capability`** — —
- **`ModelSpec`** — Immutable specification for a single model deployment.
- **`MCPTransport`** — Transport protocol for MCP communication.
- **`MCPServerSpec`** — Specification of a registered MCP server.
- **`MCPRegistry`** — Registry of available MCP servers.
- **`MCPToolResult`** — Result of an MCP tool invocation.
- **`MCPClient`** — HTTP client for MCP server communication.
- **`AccountAddRequest`** — —
- **`DomainEvent`** — Base class for all domain events.
- **`ProjectCreated`** — Emitted when a new project is added.
- **`ProjectUpdated`** — Emitted when a project is modified.
- **`ProjectRemoved`** — Emitted when a project is deleted.
- **`ProjectScanned`** — Emitted when a directory is scanned for projects.
- **`SetupStepToggled`** — Emitted when a setup checklist step changes state.
- **`SetupChecklistReset`** — Emitted when the setup checklist is cleared.
- **`UserCreated`** — Emitted when a new user is added (manually or from git).
- **`UserUpdated`** — Emitted when a user is modified.
- **`UserDeleted`** — Emitted when a user is removed.
- **`UsersSyncedFromGit`** — Emitted after a git-sync discovers new users.
- **`TaskCreated`** — Emitted when a task/ticket is created.
- **`TaskAssigned`** — Emitted when a task is assigned to a tool or human.
- **`TaskCompleted`** — Emitted when a task execution finishes.
- **`TaskFailed`** — Emitted when a task execution fails.
- **`TaskUpdated`** — Emitted when a task/ticket is updated.
- **`TaskDeleted`** — Emitted when a task/ticket is deleted.
- **`TaskCommentAdded`** — Emitted when a comment is added to a task/ticket.
- **`JobDispatched`** — Emitted when a job is dispatched to a tool.
- **`JobCompleted`** — Emitted when a job finishes successfully.
- **`JobFailed`** — Emitted when a job fails.
- **`TicketStatusChanged`** — Emitted when a ticket status changes.
- **`ToolReadinessProbed`** — Emitted when a tool's readiness is checked (startup or periodic).
- **`ToolStartupComplete`** — Emitted when the startup tool probe finishes for all tools.
- **`MCPToolInvoked`** — Emitted when an MCP tool is called.
- **`MCPServerRegistered`** — Emitted when an MCP server is registered.
- **`ValidationRequested`** — Emitted when code validation is requested.
- **`ValidationCompleted`** — Emitted when code validation finishes.
- **`WebhookRegistered`** — Emitted when a webhook is registered.
- **`WebhookUpdated`** — Emitted when a webhook configuration is updated.
- **`WebhookDeleted`** — Emitted when a webhook is deleted.
- **`WebhookTested`** — Emitted when a webhook test is triggered.
- **`EventStore`** — Append-only event store with optional SQLite persistence.
- **`TicketCreateRequest`** — —
- **`TicketAssignRequest`** — —
- **`SprintCreateRequest`** — —
- **`MCPRouter`** — Routes tool requests to appropriate MCP servers.
- **`VMCreateRequest`** — —
- **`VMActionRequest`** — —
- **`VMSnapshotRequest`** — —
- **`VMSwitchRequest`** — —
- **`ValidateCodeReq`** — Request to validate code.
- **`ValidateSyntaxReq`** — —
- **`ValidateSecurityReq`** — —
- **`ProviderType`** — —
- **`ToolType`** — —
- **`AccountCredentials`** — Credentials for a single provider account.
- **`UsageMetrics`** — Tracked usage for a single account.
- **`AccountLimits`** — Provider-imposed and user-defined limits.
- **`ToolBinding`** — Binds an account to a specific tool/IDE instance.
- **`Account`** — Single provider account with all associated data.
- **`AccountManager`** — Central account registry.
- **`Severity`** — —
- **`HealthEvent`** — Jedno zdarzenie zdrowia systemu.
- **`HealthEventStore`** — In-memory store zdarzeń z persystencją opcjonalną.
- **`HealthWatchdog`** — Daemon sprawdzający zdrowie systemu w pętli.
- **`RepairAgent`** — Agent naprawiający błędy w kodzie proxym za pomocą LLM.
- **`ProjectContext`** — Detected project context for a request.
- **`ProviderConfig`** — Configuration for an external provider.
- **`ExternalConfigManager`** — Manages external provider configurations.
- **`AgentSession`** — Stateful session for an agent working on a project.
- **`SessionStore`** — In-memory session store with TTL-based expiry.
- **`AnalysisResult`** — Result of content analysis.
- **`ExternalProject`** — Unified project representation across providers.
- **`ExternalIssue`** — Unified issue/ticket representation.
- **`BaseExternalProvider`** — Base class for external provider integrations.
- **`GitHubProvider`** — GitHub API integration using Personal Access Tokens.
- **`GitLabProvider`** — GitLab API integration using Personal/Project Access Tokens.
- **`JiraProvider`** — Jira API integration using API tokens.
- **`RepairRequest`** — —
- **`RoutingDecision`** — Complete routing decision with audit trail.
- **`CostLedger`** — In-memory cost ledger with Redis persistence.
- **`Router`** — Stateful router that selects the optimal model per request.
- **`CompletionPipeline`** — Structured pipeline for processing a chat completion request.
- **`DeltaWatchClient`** — Watches a directory and pushes context deltas to the proxy server.
- **`ToggleSetupStepCommand`** — Toggle or explicitly set a setup checklist step.
- **`ResetSetupChecklistCommand`** — Clear the setup checklist state.
- **`CreateUserCommand`** — Create a new user (manual or git-discovered).
- **`UpdateUserCommand`** — Update an existing user.
- **`DeleteUserCommand`** — Delete a user.
- **`SyncGitUsersCommand`** — Sync users from git commit history into the database.
- **`AddProjectCommand`** — Add a project from any source (local path, git URL, SSH, FTP, or name-only).
- **`UpdateProjectCommand`** — Update an existing project's attributes.
- **`RemoveProjectCommand`** — Remove a project from the registry.
- **`ScanDirectoryCommand`** — Scan a directory for projects and register discovered ones.
- **`CreateTaskCommand`** — Create a new task/ticket, optionally linked to a project.
- **`AssignTaskCommand`** — Assign a task to a tool or human.
- **`CompleteTaskCommand`** — Mark a task as completed (by tool or human).
- **`TaskCommandHandler`** — Handles task commands — the single write-side handler for tasks.
- **`SetupChecklistSnapshot`** — Current checklist state derived from the event log.
- **`SetupChecklistProjection`** — Event-sourced projection for dashboard setup progress.
- **`SetupCommandHandler`** — Handle setup checklist commands and emit domain events.
- **`SetupQueryHandler`** — Return the current setup checklist projection.
- **`UserCommandHandler`** — Handle user commands, delegate to UserManager, emit events.
- **`UserQueryHandler`** — Handle user read queries.
- **`ListProjectsQuery`** — List projects with optional filters.
- **`GetProjectQuery`** — Get a single project by ID or name.
- **`GetProjectTicketsQuery`** — Get tickets associated with a project.
- **`ListUsersQuery`** — List all users, optionally filtered.
- **`GetUserQuery`** — Get a single user by ID.
- **`GetDefaultUserQuery`** — Get the default/delegated user.
- **`GetGitSyncStatusQuery`** — Get the last git sync metadata.
- **`GetSetupChecklistQuery`** — Return the current setup checklist snapshot.
- **`ProjectCommandHandler`** — Handles project commands — the single write path for all project operations.
- **`ProjectQueryHandler`** — Handles project queries — the single read path for all project data.
- **`ProviderConfigRequest`** — Request to configure a provider.
- **`ProviderConfigResponse`** — Response with provider configuration.
- **`TestResult`** — Provider test result.
- **`ExternalProjectResponse`** — External project representation.
- **`ExternalIssueResponse`** — External issue representation.
- **`CreateProjectRequest`** — Request to create a project.
- **`CreateIssueRequest`** — Request to create an issue.
- **`SyncTicketRequest`** — Request to sync a ticket to external issue.
- **`ClaudeCodeAdapter`** — Adapter for claude CLI (Anthropic Claude Code).
- **`HumanAdapter`** — Adapter for human/manual tasks — returns a result indicating manual action required.
- **`PlandexAdapter`** — Adapter for Plandex CLI.
- **`LLMCliAdapter`** — Adapter for llm CLI (Simon Willison).
- **`ToolResult`** — Result of a tool execution.
- **`VSCodeAdapter`** — Adapter for VS Code Web / code-server (starts container, sends task via API).
- **`CodexAdapter`** — Adapter for OpenAI Codex CLI.
- **`AiderAdapter`** — Adapter for aider CLI.
- **`GooseAdapter`** — Adapter for Goose CLI (block/goose).
- **`InterpreterAdapter`** — Adapter for Open Interpreter CLI.
- **`ShellAdapter`** — Generic shell adapter — runs tool binary with prompt via stdin/args.
- **`BaseAdapter`** — Base class for tool adapters.
- **`TicketStatus`** — —
- **`TicketPriority`** — —
- **`TicketType`** — —
- **`SprintStatus`** — —
- **`MilestoneStatus`** — —
- **`ToolAssignment`** — Which tool is assigned to work on a ticket.
- **`JobExecution`** — Snapshot of the latest job execution for a ticket.
- **`TicketComment`** — —
- **`Milestone`** — —
- **`Ticket`** — —
- **`Sprint`** — —
- **`TicketFilter`** — Extracted filtering logic from TicketManager.
- **`TicketValidator`** — Extracted validation logic for ticket operations.
- **`TicketPersistence`** — Extracted persistence logic.
- **`TicketManagerRefactored`** — Refactored ticket & sprint store with separated concerns.
- **`ToolProviderRequest`** — —
- **`HealthCheck`** — Base class for specific health checks.
- **`BinaryHealthCheck`** — Check if tool binary is available on PATH.
- **`InstanceHealthCheck`** — Check tool instances (Docker, KVM, VM).
- **`ProviderHealthCheck`** — Check provider configuration and API keys.
- **`HumanToolHealthCheck`** — Special health check for human tool category.
- **`HealthStatusCalculator`** — Calculate overall health status from diagnostics.
- **`HealthCheckerRefactored`** — Main health checker that orchestrates specific checks.
- **`TicketManager`** — In-memory ticket & sprint store with optional JSON persistence.
- **`DispatchRequest`** — —
- **`DryRunRequest`** — —
- **`PreviewPromptRequest`** — —
- **`UserRole`** — User roles in the system.
- **`User`** — A user in the system, identified by git configuration.
- **`AutoFixRequest`** — —
- **`GitSyncMixin`** — Git-sync orchestration for UserManager (requires GitUserIdentityMixin).
- **`CreateUserRequest`** — —
- **`UpdateUserRequest`** — —
- **`Greeter`** — —
- **`Greeter`** — —
- **`ProxymTools`** — Tools for managing proxym AI proxy from Open WebUI.
- **`Todo`** — —
- **`TodoCreateInput`** — —
- **`TodoUpdateInput`** — —
- **`TodoStats`** — —
- **`TodoStore`** — —
- **`PanelProps`** — —
- **`SSEService`** — —
- **`GitUserIdentityMixin`** — Git identity and repository discovery helpers for UserManager.
- **`UserManager`** — In-memory user store with SQLite persistence and git integration.

### Functions

- `greet(name)` — Return a greeting message for the given name.
- `add(x, y)` — Return the sum of x and y.
- `subtract(x, y)` — Return the difference of x and y.
- `multiply(x, y)` — Return the product of x and y.
- `divide(x, y)` — Return the quotient of x and y. Raises ValueError on division by zero.
- `calculate(operation, x, y)` — Perform a calculation based on the operation type.
- `check_voice_deps()` — Sprawdź czy zależności głosowe są zainstalowane.
- `install_voice_deps()` — Zainstaluj zależności głosowe.
- `main()` — —
- `main()` — —
- `main()` — —
- `load_project_config(project_dir)` — Load ``.proxym.yaml`` from *project_dir*.  Returns empty config on any error.
- `is_sqlite_database(path)` — —
- `cli(ctx, proxy, key, fmt)` — Proxym — intelligent AI proxy with VM isolation.
- `serve(host, port, reload)` — Start the proxy server.
- `status(ctx, fmt)` — Show system status.
- `models(ctx, fmt)` — List available models.
- `chat(ctx, prompt, voice, tts)` — Interactive chat or generate CLI commands from NLP prompt.
- `logs_cmd(ctx, lines, level)` — Show proxy logs.
- `providers_cmd(ctx)` — List configured providers and their status.
- `routing_test_cmd(ctx)` — Dry-run routing test — check which model would be selected.
- `projects_cmd(ctx)` — List available projects (shortcut for 'project list').
- `run_cmd(ctx, task, project_name, tool_name)` — All-in-one: create ticket → dispatch → wait → analyze.
- `dispatch_shortcut(ctx, ticket_id, tool, model)` — Shortcut: dispatch a ticket.  = proxym tools dispatch TKT-XXX
- `fix_cmd(ctx, description, project_name)` — Shortcut: fix a bug.  = proxym do "..." --type bug
- `refactor_cmd(ctx, description, project_name)` — Shortcut: refactor code.  = proxym do "..." --type refactor --with claude-code
- `retry_cmd(ctx, ticket_id, tool, model)` — Re-dispatch a ticket (same task, optionally different tool/model).
- `autofix_cmd(ctx, ticket_id, tool, wait)` — Create a fix ticket from a failed job's error output and dispatch it.
- `queue_shortcut(ctx)` — Shortcut: show task queue.  = proxym tools queue
- `web_cmd(ctx, tab)` — Open dashboard in browser.  proxym web [home|projects|tasks|system|voice]
- `log_shortcut(ctx, lines)` — Shortcut: show recent logs.  = proxym logs -n 20
- `jobs_shortcut(ctx, status, limit)` — Shortcut: list jobs.  = proxym tools jobs
- `board_shortcut(ctx, sprint)` — Shortcut: show kanban board.  = proxym ticket board
- `analyze_shortcut(ctx, ticket_id)` — Shortcut: analyze ticket completion.  = proxym ticket analyze
- `config_group()` — Manage persistent proxym configuration.
- `config_set(key, value)` — Set a config value.  Example: proxym config set proxy_url http://localhost:4000
- `config_get(key)` — Show config values.  Example: proxym config get proxy_url
- `register_github_webhook(url)` — Register GitHub webhook URL.
- `register_gitlab_webhook(url)` — Register GitLab webhook URL.
- `register_jira_webhook(url)` — Register Jira webhook URL.
- `build_job_execution(job, environment_snapshot)` — —
- `build_ticket_detail(ticket_store, ticket, tool_executor_get)` — —
- `build_ticket_export_rows(ticket_store, tickets)` — —
- `enqueue_ticket_job(ticket, tool_def)` — —
- `maybe_auto_dispatch_ticket(ticket_id)` — —
- `get_settings()` — —
- `events_stream(request, token)` — SSE endpoint — streams domain events as JSON.
- `list_projects(status, source_type)` — Lista wszystkich projektów z informacją o przypisanych obiektach.
- `get_project(project_id)` — —
- `add_project(req)` — Dodaj projekt — po nazwie lub z pełną konfiguracją.
- `update_project(project_id, req)` — —
- `remove_project(project_id)` — —
- `scan_directory(req)` — Skanuj folder i dodaj znalezione projekty.
- `project_tickets(project_id)` — Tickety powiązane z projektem (match by id or name).
- `create_project_ticket(project_id, req)` — Stwórz ticket od razu powiązany z projektem.
- `export_project(project_id, include_logs)` — Export complete project data including tickets and optionally logs.
- `dashboard_root()` — Dashboard root - redirects to system status.
- `system_status()` — Full system overview: accounts + VMs + costs + libvirt + providers + watchdog + repair.
- `list_providers()` — Show configured providers from .env and their model counts.
- `get_logs(lines, level)` — Get recent log entries from proxym log file.
- `cost_summary()` — Aggregate cost dashboard across all accounts.
- `cost_detailed()` — Per-account cost breakdown.
- `list_tools()` — Return available VM tool profiles (host/browser environments).
- `list_webhooks()` — List all registered webhooks.
- `register_webhook(request)` — Register a new webhook.
- `delete_webhook(system)` — Delete a webhook registration.
- `test_webhook(system, url)` — Test a webhook by sending a test event.
- `list_tickets(sprint_id, milestone_id, status, priority)` — List tickets with optional filters.
- `export_tickets(sprint_id, milestone_id, status, priority)` — Export ticket data for grouped dashboard views.
- `create_ticket(task, title, project_id, description)` — Create a new ticket. Accepts 'task' (new) or 'title' (legacy).
- `ticket_board(sprint_id, milestone_id)` — Kanban board view: tickets grouped by status columns.
- `deduplicate_tickets(dry_run)` — Find and remove duplicate tickets.
- `get_ticket(ticket_id)` — Get ticket details including comments.
- `update_ticket(ticket_id, task, title, project_id)` — Update a ticket's fields.
- `delete_ticket(ticket_id)` — Delete a ticket.
- `assign_ticket_tool(ticket_id, tool, agent_mode, model)` — Assign a tool (vscode, aider, claude-code, etc.) to work on a ticket.
- `add_ticket_comment(ticket_id, author, content)` — Add a comment to a ticket (from any tool or user).
- `list_sprints(status, milestone_id)` — List sprints.
- `create_sprint(req)` — Create a new sprint.
- `get_sprint(sprint_id)` — Get sprint details with ticket stats.
- `update_sprint(sprint_id, req)` — Update sprint fields.
- `delete_sprint(sprint_id)` — Delete a sprint.
- `list_milestones(status)` — List milestones.
- `create_milestone(req)` — Create a new milestone.
- `get_milestone(milestone_id)` — Get milestone details with ticket stats.
- `update_milestone(milestone_id, req)` — Update milestone fields.
- `delete_milestone(milestone_id)` — Delete a milestone.
- `shared_accounts()` — Return the singleton AccountManager.
- `shared_vms()` — Return the singleton VMOrchestrator.
- `get_setup_state()` — Return the current setup checklist snapshot.
- `toggle_setup_step(step_id, req)` — Mark a setup checklist step complete/incomplete.
- `reset_setup()` — Clear the setup checklist state.
- `list_accounts(provider, tag)` — —
- `create_account(req)` — —
- `get_account(account_id)` — —
- `delete_account(account_id)` — —
- `bind_tool(account_id, req)` — —
- `get_environment_registry()` — —
- `get_tool_environment_snapshot(tool_name)` — —
- `list_environments()` — —
- `list_environment_assignments()` — —
- `get_environment(environment_id)` — —
- `create_environment(req)` — —
- `update_environment(environment_id, req)` — —
- `delete_environment(environment_id)` — —
- `assign_tool_to_environment(req)` — —
- `detect_toolchain(path)` — Return (stack, frameworks) detected from file markers at *path*.
- `enrich_npm_frameworks(path, frameworks)` — Append JS/TS frameworks detected from package.json dependencies.
- `enrich_python_frameworks(path, frameworks)` — Append Python frameworks detected from pyproject.toml content.
- `enrich_git_info(path)` — Return True if the path contains a .git directory.
- `enrich_local_project(project)` — Enrich a local project with auto-detected metadata.
- `detect_firefox_profiles()` — Detect Firefox profiles by parsing profiles.ini.
- `detect_all_profiles()` — Detect all browser profiles on the host.
- `detect_chrome_profiles()` — Detect Chrome browser profiles.
- `detect_chromium_profiles()` — Detect Chromium browser profiles.
- `generate_app_data_sync(profile, with_passwords)` — Generate an AppDataSync config for copying a profile into a VM.
- `list_vms()` — —
- `create_vm(req)` — —
- `start_vm(vm_id)` — —
- `stop_vm(vm_id, force)` — —
- `pause_vm(vm_id)` — —
- `resume_vm(vm_id)` — —
- `snapshot_vm(vm_id, name)` — —
- `switch_project(vm_id, req)` — —
- `delete_vm(vm_id)` — —
- `delete_vm_post(vm_id)` — POST variant for single VM deletion (matches frontend convention).
- `bulk_delete_vms(req)` — Delete multiple VMs by their IDs. Returns list of successfully deleted VM IDs.
- `assign_tool_to_vm(vm_id, req)` — Assign a tool to a VM. Also creates/updates a vm_local environment for this VM.
- `cmd_serve(args)` — Start the proxy server (delegates to proxym.main:cli).
- `cmd_status(args)` — Show system status (YAML or human-readable).
- `cmd_models(args)` — —
- `extract_click_params(func)` — Extract arguments and options from click-decorated function.
- `scan_command_group(group, parent_name)` — Recursively scan click command group and extract schema.
- `generate_cli_schema(cli_group)` — Generate complete CLI schema from click CLI group.
- `generate_usage_patterns(commands)` — Generate common usage patterns from commands.
- `generate_example(cmd)` — Generate example usage for a command.
- `generate_schema_multi_method(proxy_url, prefer_cache)` — Generate CLI schema using multiple methods, falling back as needed.
- `save_schema_to_file(schema, path)` — Save CLI schema to JSON file.
- `load_schema_from_file(path)` — Load CLI schema from JSON file.
- `format_schema_for_llm(schema)` — Format CLI schema as string for LLM prompt.
- `get_cli_schema(force_refresh, proxy_url, prefer_cache)` — Get CLI schema using multiple generation methods with caching.
- `refresh_cli_schema(proxy_url)` — Force refresh the CLI schema cache.
- `get_cli_schema_text()` — Get CLI schema formatted as text for LLM prompts.
- `cmd_browser_list(args)` — List detected browser profiles on the host.
- `cmd_browser_assign(args)` — Assign a browser profile to an account.
- `cmd_browser_sync(args)` — Sync browser profile host ↔ VM.
- `cmd_browser_snapshot(args)` — Save browser state from VM as snapshot.
- `cmd_obs_errors(args)` — —
- `cmd_obs_health(args)` — —
- `cmd_obs_repair(args)` — —
- `cmd_obs_logs(args)` — —
- `cmd_tests_status(args)` — Run all diagnostic tests and show results.
- `cmd_test_vscode(args)` — Test VS Code Web connectivity.
- `cmd_test_proxy(args)` — Test LLM proxy connectivity.
- `cmd_test_providers(args)` — Check configured LLM providers.
- `cmd_test_extensions(args)` — Check installed VS Code extensions.
- `cmd_test_agent_setup(args)` — Comprehensive agent readiness check.
- `cmd_test_agent(args)` — Test agent with a simple completion.
- `cmd_vm_list(args)` — —
- `cmd_vm_create(args)` — —
- `cmd_vm_action(args)` — —
- `cmd_vm_switch(args)` — —
- `cmd_vm_open(args)` — Open SPICE viewer for a VM (virt-viewer).
- `cmd_vm_ssh(args)` — SSH into a VM (auto-detect IP via dashboard).
- `cmd_vm_logs(args)` — Show cloud-init logs and tool logs from a VM.
- `cmd_vm_delete(args)` — Delete a VM.
- `cmd_vm_console(args)` — Open web console for a VM (prints noVNC URL).
- `cmd_vm_bulk_delete(args)` — Delete multiple VMs.
- `prompt_user_for_fix(issues)` — Interactive prompt to fix configuration issues.
- `validate_before_llm(interactive)` — Validate configuration before using LLM features.
- `check_config_or_exit()` — Check config and exit if invalid (for CLI commands that need LLM).
- `cmd_context_delta(args)` — Push a context delta to the proxy.
- `cmd_context_detect(args)` — Detect project context from messages or paths.
- `cmd_context_stats(args)` — Show context store statistics.
- `cmd_sessions_list(args)` — List active agent sessions.
- `cmd_mcp_servers(args)` — List registered MCP servers.
- `cmd_chat(args)` — Interactive chat with proxym — DSL first, LLM fallback, CLI generation.
- `make_client(base, key)` — Create HTTP client with configuration from settings.
- `print_json(data)` — —
- `print_json_if_yaml(args, data)` — Print JSON output and return True when the CLI requested YAML output.
- `print_table(rows, columns, widths)` — —
- `detect_ticket_type(task)` — Guess ticket type from natural-language task description.
- `default_priority(ticket_type)` — Return sensible default priority for a ticket type.
- `resolve_tool(ticket_type, project, explicit, project_config)` — Pick the best tool: explicit > .proxym.yaml > project default > type hint.
- `resolve_model(project, explicit, project_config)` — Pick model: explicit > .proxym.yaml > empty (let tool decide).
- `build_context_snippet(project_config, project_dir)` — Read context_files from .proxym.yaml and return a markdown snippet for the ticket.
- `resolve_project(projects, explicit)` — Find project: explicit name/id → CWD match → single → most recent.
- `cmd_ticket_list(args)` — List tickets with optional filters.
- `cmd_ticket_create(args)` — Create a new ticket.
- `cmd_ticket_show(args)` — Show ticket details.
- `cmd_ticket_update(args)` — Update a ticket.
- `cmd_ticket_assign(args)` — Assign a tool to a ticket.
- `cmd_ticket_comment(args)` — Add a comment to a ticket.
- `cmd_ticket_delete(args)` — Delete a ticket.
- `cmd_sprint_list(args)` — List sprints.
- `cmd_sprint_create(args)` — Create a new sprint.
- `cmd_sprint_show(args)` — Show sprint details.
- `cmd_sprint_update(args)` — Update a sprint.
- `cmd_sprint_delete(args)` — Delete a sprint.
- `cmd_ticket_dedup(args)` — Find and remove duplicate tickets.
- `cmd_ticket_analyze(args)` — Analyze whether a ticket was completed correctly.
- `cmd_board(args)` — Show kanban board.
- `cmd_accounts_list(args)` — —
- `cmd_accounts_add(args)` — —
- `cmd_accounts_costs(args)` — —
- `cmd_accounts_get(args)` — —
- `cmd_accounts_delete(args)` — —
- `cmd_accounts_bind_tool(args)` — —
- `cmd_vscode_start(args)` — Start VS Code Web (docker compose --profile vscode up -d).
- `cmd_vscode_stop(args)` — Stop VS Code Web.
- `cmd_vscode_open(args)` — Open VS Code Web in the default browser.
- `cmd_vscode_logs(args)` — Show VS Code Web logs (follows).
- `cmd_vscode_status(args)` — Show VS Code Web container status.
- `cmd_vscode_build(args)` — Rebuild VS Code Web image.
- `models_for_tier(tier, required_caps, available_providers)` — Return models suitable for a tier, sorted by effective cost ascending.
- `cheapest_model(tier, available_providers, required_caps)` — Return the single cheapest model that satisfies constraints.
- `get_model(model_id)` — —
- `find_model_by_litellm(litellm_model)` — Find a model by its litellm_model string.
- `resolve_model(model_str)` — Resolve a model string to a ModelSpec.
- `filter_models()` — Filter models by various criteria, sorted by effective cost ascending.
- `all_model_ids()` — Return all model IDs sorted by effective cost.
- `get_event_store()` — Get or create the global event store.
- `get_command_bus()` — Get or create the global command bus with registered handlers.
- `get_query_bus()` — Get or create the global query bus with registered handlers.
- `reset_buses()` — Reset buses (for testing).
- `get_singleton(instance_var, instance_class)` — Generic singleton getter with lazy initialization.
- `extract_system_text(messages)` — Extract the first system message's text content.
- `tool_account_list()` — List all accounts with costs.
- `tool_account_costs()` — Cost summary per account and model.
- `tool_account_add(req)` — Add a new API account.
- `tool_ticket_list(sprint_id, status, tool)` — List tickets, optionally filtered by sprint, status, or assigned tool.
- `tool_ticket_create(req)` — Create a new ticket in the task management system.
- `tool_ticket_assign(req)` — Assign a development tool to work on a ticket.
- `tool_ticket_board(sprint_id)` — Get kanban board view of tickets grouped by status.
- `tool_sprint_create(req)` — Create a new sprint.
- `tool_status()` — Full system status: proxy, VMs, accounts, costs.
- `tool_logs(lines, level)` — Recent proxym logs.
- `tool_models()` — List available models with prices.
- `tool_vm_list()` — List all VMs with their status.
- `tool_vm_create(req)` — Create a new VM with an AI tool.
- `tool_vm_start(req)` — Start a stopped VM.
- `tool_vm_stop(req)` — Stop a running VM.
- `tool_vm_snapshot(req)` — Create a VM snapshot.
- `tool_vm_switch_project(req)` — Switch project in a running VM.
- `tool_validate_syntax(req)` — Validate code syntax using vallm SyntaxValidator.
- `tool_validate_imports(req)` — Validate code imports using vallm ImportValidator.
- `tool_validate_security(req)` — Validate code security using vallm SecurityValidator.
- `tool_validate_code(req)` — Full code validation pipeline using multiple vallm validators.
- `get_health_store()` — —
- `get_log_buffer(limit, level)` — Pobierz ostatnie logi z bufora.
- `get_error_summary()` — Podsumowanie błędów z ostatnich logów.
- `log_call()` — Dekorator logujący wywołanie, czas i błędy.
- `log_endpoint()` — Dekorator dla FastAPI endpointów — loguje request/response + timing.
- `retry_with_log(max_retries, backoff_base, retryable)` — Retry z exponential backoff i logowaniem każdej próby.
- `detect_project(messages, headers)` — Detect project context from request data.
- `select_tools(context, analysis, available_servers)` — Select MCP servers for a given project and task analysis.
- `get_config_manager()` — Get or create the global config manager instance.
- `analyze_request(messages)` — Analyze a chat completion request and return routing metadata.
- `check_llm_proxy(base_url)` — Check LLM proxy connectivity and available models.
- `get_provider(provider, api_key, base_url, email)` — Factory function to get the right provider instance.
- `vms_list()` — List VMs (alias for GET /dashboard/vms).
- `vms_start(vm_id)` — Start VM (alias for POST /dashboard/vms/{vm_id}/start).
- `vms_stop(vm_id, force)` — Stop VM (alias for POST /dashboard/vms/{vm_id}/stop).
- `vms_snapshot(vm_id, name)` — Snapshot VM (alias for POST /dashboard/vms/{vm_id}/snapshot).
- `accounts_list(provider, tag)` — List accounts (alias for GET /dashboard/accounts).
- `dashboard_costs_summary()` — Cost summary used by voice UI.
- `logs_list(lines, level)` — Recent logs (alias for GET /dashboard/logs).
- `voice_tickets(status)` — List tickets — voice-friendly summary.
- `voice_diagnose()` — Run diagnostics — voice-friendly summary.
- `check_roo_cline_config()` — Check if Roo Code is configured in VS Code settings.
- `completion()` — —
- `chat_completions(request, x_task_tier)` — OpenAI-compatible chat completions with intelligent routing.
- `get_cost_ledger()` — —
- `favicon()` — Return empty favicon to prevent 401 errors.
- `health(request, authorization, x_api_key)` — Health check with optional VM identification.
- `list_models()` — List available models (OpenAI-compatible) including model aliases.
- `budget_status()` — Return current budget usage.
- `cli_schema()` — Return CLI schema for command discovery and auto-completion.
- `obs_logs(limit, level)` — Ring buffer logs — ostatnie N wpisów z dekoratorów.
- `obs_errors()` — Podsumowanie błędów z ring buffer.
- `obs_health_events(limit, severity)` — Historia zdarzeń zdrowia systemu.
- `obs_health_summary()` — Aktywne problemy i podsumowanie.
- `obs_repair(req)` — Uruchom LLM repair agent na wskazanym błędzie.
- `obs_repair_from_logs()` — Auto-diagnozuj najczęstszy błąd z ring buffer.
- `obs_repair_history(limit)` — Historia napraw wykonanych przez repair agent.
- `obs_domain_events(limit, event_type, aggregate_id)` — Domain events from the CQRS event store — audit trail for all state changes.
- `vscode_status()` — —
- `vscode_start()` — —
- `vscode_stop()` — —
- `vscode_restart()` — —
- `vscode_logs(lines)` — —
- `vscode_build()` — —
- `check_copilot_conflict()` — Detect GitHub Copilot / Copilot Chat extension conflicts.
- `check_agent_setup(base_url)` — Comprehensive agent readiness check — config + connectivity + extension.
- `test_agent_completion()` — Test a simple completion through the proxy to verify agent functionality.
- `run_all_tests(request)` — Run all diagnostic tests and return comprehensive status.
- `test_vscode()` — Test VS Code Web connectivity.
- `test_proxy(request)` — Test LLM proxy connectivity.
- `test_roo()` — Test Roo Code configuration.
- `test_extensions()` — Check installed VS Code extensions.
- `test_providers()` — Check configured LLM providers and model aliases.
- `test_copilot()` — Detect GitHub Copilot extension conflicts.
- `test_agent_setup(request)` — Comprehensive agent readiness check.
- `test_agent()` — Test agent with a simple completion.
- `routing_test()` — Return routing status (no network calls).
- `ollama_status()` — Check Ollama connectivity and list available local models.
- `vm_console(vm_id)` — Return noVNC connection URL for a running VM.
- `check_providers_config()` — Check which LLM providers are configured with API keys.
- `check_vscode_status()` — Check if VS Code Web is running and accessible.
- `check_extensions()` — Check installed VS Code extensions via docker exec.
- `root_redirect()` — Redirect root to dashboard.
- `dashboard_ui()` — Serve the React dashboard UI.
- `dashboard_diagnostics_jsx()` — Serve DiagnosticsPanel for testing VS Code, proxy, and agent.
- `dashboard_jsx()` — Serve the React dashboard JSX entry point.
- `get_frontend_config(request)` — Return configuration for frontend.
- `get_router()` — —
- `get_delta_buffer()` — —
- `get_mcp_router()` — —
- `get_session_store()` — —
- `get_context_payload()` — —
- `set_context_payload(payload)` — —
- `get_context_store()` — —
- `get_mcp_registry()` — —
- `receive_delta(request)` — Receive context delta from the file watcher client.
- `detect_context(request)` — Detect project context from request body (messages + headers).
- `list_sessions()` — List active agent sessions.
- `list_mcp_servers()` — List registered MCP servers.
- `context_stats()` — Return context store statistics.
- `cli()` — CLI entry point for proxym-client.
- `get_setup_projection(event_store)` — Get or create the singleton setup projection for the active event store.
- `reset_setup_projection()` — Reset the singleton projection (used by tests).
- `cmd_list_items(args, endpoint, item_name, columns)` — Generic command to list items from an API endpoint.
- `cmd_sessions_list(args)` — List active agent sessions.
- `cmd_mcp_servers(args)` — List registered MCP servers.
- `enrich_project(project)` — Add assignment counts to project payload: tickets, environments, tools, users.
- `ticket()` — Manage tickets (task tracking for multi-tool workflows).
- `ticket_list(ctx, status, tool, sprint)` — List tickets.
- `ticket_add(ctx, task, project, tool)` — Create a ticket (minimalistic). Example: proxym ticket add 'fix the router bug'
- `ticket_create(ctx, title, description, type)` — Create a new ticket (legacy — prefer 'ticket add').
- `ticket_update(ctx, ticket_id, title, status)` — Update a ticket.
- `ticket_assign(ctx, ticket_id, tool, mode)` — Assign a tool to work on a ticket.
- `ticket_comment(ctx, ticket_id, author, content)` — Add a comment to a ticket.
- `ticket_board(ctx, sprint)` — Show kanban board view.
- `ticket_dedup(ctx, execute)` — Find and remove duplicate tickets (dry run by default).
- `ticket_export(ctx, fmt, status, project)` — Export tickets to markdown or JSON.
- `sprint()` — Manage sprints.
- `sprint_list(ctx, status)` — List sprints.
- `sprint_create(ctx, name, goal, start)` — Create a new sprint.
- `sprint_update(ctx, sprint_id, name, status)` — Update a sprint.
- `sprint_board(ctx, sprint)` — Show kanban board view.
- `tests()` — Run system diagnostics.
- `diagnose()` — Run diagnostics to verify system health (alias for 'tests').
- `diagnose_one(ctx, test_name)` — Run a specific test (vscode|proxy|roo|extensions|providers|copilot|agent-setup|agent).
- `accounts()` — Manage accounts.
- `accounts_list(ctx)` — List accounts.
- `accounts_add(ctx, name, provider, api_key)` — Add account.
- `accounts_costs(ctx)` — Show cost breakdown.
- `accounts_get(ctx, account_id)` — Show single account details.
- `accounts_delete(ctx, account_id)` — Delete an account.
- `accounts_bind_tool(ctx, account_id, tool_type, tool_name)` — Bind a tool to an account.
- `project()` — Manage projects (local, git, SSH, FTP).
- `project_list(ctx, source_type, status)` — List registered projects.
- `project_add(ctx, path_or_url, git, ssh)` — Add a project. Accepts local path, --git URL, or --ssh user@host:/path.
- `project_scan(ctx, directory)` — Scan a directory for projects and register them.
- `project_show(ctx, project_id)` — Show project details.
- `project_update(ctx, project_ref, name, description)` — Update a project by id or name.
- `project_remove(ctx, project_id)` — Remove a project from the registry.
- `project_task(ctx, project_name, task_text, tool)` — Create a ticket for a project (shortcut for 'ticket add --project').
- `context()` — Manage context, sessions, and MCP servers.
- `context_delta(ctx, project_id, diff_text, file)` — Push a context delta to the proxy.
- `context_detect(ctx, message, system_prompt, paths)` — Detect project context from messages or paths.
- `tools()` — Manage AI development tools and job queue.
- `tools_list(ctx, category, available)` — List registered tools.
- `tools_dispatch(ctx, ticket, ticket_opt, tool)` — Dispatch a tool to work on a ticket.
- `tools_queue(ctx)` — Show job queue status.
- `tools_jobs(ctx, status, limit)` — List jobs.
- `tools_status(ctx)` — Combined tool dashboard: availability, model, job stats.
- `tools_set_model(ctx, tool_name, model)` — Set the default LLM model for a tool.
- `compare_cmd(ctx, task, project_name, tools_csv)` — A/B test: send same task to multiple tools and compare results.
- `batch_cmd(ctx, yaml_file, wait, analyze)` — Execute multiple tasks from a YAML file.
- `obs()` — Observability: logs, errors, health, repair.
- `obs_errors(ctx)` — Show error summary from ring buffer.
- `obs_health(ctx)` — Show health summary and active issues.
- `obs_logs(ctx, limit, level)` — Show recent observability logs from ring buffer.
- `obs_repair(ctx, error, mode, from_logs)` — Run LLM repair agent on an error.
- `make_args(ctx)` — Convert Click context to SimpleNamespace for legacy CLI handlers.
- `passthrough(name, handler, help_text)` — Click command: make_args(ctx) → handler(args).
- `passthrough_fmt(name, handler, help_text)` — Click command with --format option: make_args(ctx, format=fmt) → handler(args).
- `passthrough_arg(name, handler, help_text, arg_name)` — Click command with argument: make_args(ctx, arg=val, **fixed) → handler(args).
- `api_json_cmd(name, method, path, help_text)` — Click command: call API endpoint, print JSON.
- `register_commands()` — Register a batch of Click commands built from spec tuples.
- `api_json_arg_cmd(name, method, path_tpl, help_text)` — Click command with argument: call API endpoint with path arg, print JSON.
- `vm()` — Manage VMs.
- `vm_create(ctx, name, tool, account)` — Create VM.
- `vm_stop(ctx, vm_id, force)` — Stop a VM.
- `vm_snapshot(ctx, vm_id, name)` — Snapshot a VM.
- `vm_switch(ctx, vm_id, project)` — Switch project in VM.
- `vm_ssh(ctx, vm_id, user)` — SSH into VM.
- `vm_bulk_delete(ctx, vm_ids)` — Delete multiple VMs.
- `list_providers()` — List all configured external providers.
- `configure_provider(provider, request)` — Configure an external provider.
- `remove_provider(provider, name)` — Remove a provider configuration.
- `test_provider(provider, name)` — Test provider credentials.
- `list_external_projects(provider, config_name)` — List projects from external provider.
- `create_external_project(provider, request, config_name)` — Create a project in external provider.
- `list_external_issues(provider, project_id, state, config_name)` — List issues from external provider project.
- `create_external_issue(provider, project_id, request, config_name)` — Create an issue in external provider.
- `vscode()` — Manage VS Code Web service.
- `external_group()` — Manage external provider integrations (GitHub, GitLab, Jira).
- `external_configure(ctx, provider, api_key, base_url)` — Configure an external provider API key.
- `external_list(provider)` — List configured external providers.
- `external_test(ctx, provider, name)` — Test external provider credentials.
- `external_remove(ctx, provider, name)` — Remove an external provider configuration.
- `external_project()` — Manage projects in external providers.
- `external_project_list(ctx, provider, name)` — List projects from external provider.
- `external_project_create(ctx, provider, name, description)` — Create a new project in external provider.
- `external_project_link(ctx, project_ref, provider, external_project_id)` — Link a proxym project to an external provider project.
- `external_issue()` — Manage issues/tickets in external providers.
- `external_issue_list(ctx, provider, project_id, state)` — List issues from external provider project.
- `external_issue_create(ctx, provider, project_id, title)` — Create an issue in external provider.
- `external_issue_sync(ctx, ticket_id, provider, project_id)` — Sync a proxym ticket to external provider as an issue.
- `external_gitlab_shell()` — GitLab shell CLI integration commands.
- `gitlab_shell_exec(ctx, project_id, command, config_name)` — Execute a GitLab CLI command for a project.
- `gitlab_shell_auth(ctx, config_name)` — Authenticate glab CLI with stored credentials.
- `generate_key()` — Generate a new local API key.
- `update_env_file(env_path, new_key)` — Update the .env file with the new key.
- `keys()` — Manage local API keys for dashboard authentication.
- `generate_cmd(env_file, print_only)` — Generate a new local API key.
- `ensure_cmd(env_file)` — Ensure a valid local API key exists in .env file.
- `show_cmd(env_file, full)` — Show the current local API key from .env file.
- `init_cmd(env_file)` — Initialize development environment with valid local API key.
- `browser()` — Manage browser profiles.
- `browser_assign(ctx, profile, account)` — Assign profile to account.
- `detect_chrome_profiles()` — Detect Google Chrome profiles by parsing Local State.
- `detect_chromium_profiles()` — Detect Chromium profiles by parsing Local State.
- `get_builtin_profile(tool)` — Get the path to a built-in profile YAML for a tool.
- `list_builtin_profiles()` — List all available built-in profile names.
- `merge_profiles(base, override)` — Deep-merge two profile dicts. Override values take precedence.
- `load_profile_yaml(path)` — Load a YAML profile, with graceful fallback if PyYAML is not installed.
- `do_cmd(ctx, task, project_name, tool_name)` — One command to rule them all.
- `get_adapter(tool_name)` — Return an adapter instance for the named tool, or None.
- `register_adapter(tool_name, adapter_cls)` — Register a custom adapter class for a tool.
- `set_tool_provider(req)` — Assign an LLM provider to a specific tool.
- `get_tool_providers()` — Get current tool → provider mappings.
- `queue_status()` — Get queue summary and recent jobs.
- `list_jobs(status, limit)` — List jobs with optional status filter.
- `get_job(job_id)` — Get details for a specific job.
- `cancel_job(job_id)` — Cancel a queued job.
- `retry_job(job_id)` — Retry a failed job — re-enqueue with same parameters.
- `repair_job(job_id)` — Run auto-diagnosis on a failed job and suggest/apply fixes.
- `tools_readiness(request)` — Return cached tool readiness snapshot from the startup orchestrator.
- `tools_healthcheck()` — Comprehensive health check for every registered tool.
- `start_executor()` — Start the background executor loop.
- `stop_executor()` — Stop the background executor loop.
- `preview_prompt(req)` — Preview the prompt that would be sent to a tool for a ticket.
- `dispatch_dry_run(req)` — Pre-flight validation: check project, tool health, and dependencies without dispatching.
- `dispatch_job(req)` — Dispatch a tool to work on a ticket. Enqueues a job.
- `list_tools(category, available_only)` — List all registered tools.
- `tools_summary()` — Summary of tool availability.
- `update_tool(tool_name, body)` — Update a tool's mutable fields (default_model, default_instance, description, force_available).
- `get_tool(tool_name)` — Get details for a specific tool.
- `delete_milestone(delete_func, item_id)` — Delete a milestone.
- `delete_vm(delete_func, item_id)` — Delete a VM.
- `emit_event(event)` — Emit a domain event to the global EventStore (best-effort).
- `delete_item(delete_func, item_id, not_found_msg)` — Generic delete function for tickets and sprints.
- `delete_ticket_from_dict(tickets_dict, ticket_id, save_func)` — Delete a ticket from the tickets dictionary.
- `list_users(active_only)` — List all users.
- `create_user(req)` — Create a new user.
- `sync_git_users(repo_path)` — Sync users from git commit history.
- `get_default_user()` — Get the default/delegated user.
- `set_default_user(user_id)` — Set a user as the default/delegated user.
- `get_user(user_id)` — Get a specific user.
- `update_user(user_id, req)` — Update a user.
- `delete_user(user_id)` — Delete a user.
- `ensure_single_default(users, new_default_id)` — Unset is_default on every user except *new_default_id*.
- `resolve_default_user(users)` — Return the summary of the default active user, with first-active fallback.
- `execute_autofix(req)` — Execute an automatic fix for a tool issue.
- `bulk_autofix()` — Run auto-fix for all degraded tools that support automatic fixes.
- `start_executor()` — Start the background executor loop.
- `stop_executor()` — Stop the background executor loop.
- `delete_ticket_from_dict(tickets, ticket_id, save_callback)` — Delete a ticket from the tickets dictionary.
- `run_benchmark(commands, iterations)` — Benchmark NLP command generation speed.
- `main()` — —
- `add(a, b)` — Return the sum of a and b.
- `subtract(a, b)` — Return the difference of a and b.
- `multiply(a, b)` — Return the product of a and b.
- `divide(a, b)` — Return the quotient of a and b. Raises ValueError on division by zero.
- `store()` — —
- `addCommand()` — —
- `listCommand()` — —
- `todos()` — —
- `statsCommand()` — —
- `s()` — —
- `program()` — —
- `shortId()` — —
- `colorPriority()` — —
- `formatTodoRow()` — —
- `check()` — —
- `formatStats()` — —
- `Panel()` — —
- `PanelTitle()` — —
- `PanelContent()` — —
- `ct()` — —
- `get()` — —
- `body()` — —
- `post()` — —
- `payload()` — —
- `put()` — —
- `del()` — —
- `useHealth()` — —
- `refresh()` — —
- `h()` — —
- `useBudget()` — —
- `useModels()` — —
- `m()` — —
- `useProviders()` — —
- `p()` — —
- `useResources()` — —
- `useLogs()` — —
- `l()` — —
- `normalizeDashboardTheme()` — —
- `getInitialDashboardTheme()` — —
- `prefersDark()` — —
- `applyDashboardTheme()` — —
- `normalizedTheme()` — —
- `root()` — —
- `getUrlParams()` — —
- `params()` — —
- `DASHBOARD_VALID_TABS()` — —
- `normalizeDashboardTab()` — —
- `normalized()` — —
- `normalizeDashboardAction()` — —
- `normalizeDashboardContext()` — —
- `updateUrlParams()` — —
- `url()` — —
- `useDashboardData()` — —
- `getInitialRoute()` — —
- `hash()` — —
- `tab()` — —
- `initialRoute()` — —
- `urlParams()` — —
- `canonicalizedUrlRef()` — —
- `stateRef()` — —
- `toggleTheme()` — —
- `currentUrl()` — —
- `currentHash()` — —
- `currentAction()` — —
- `currentContext()` — —
- `legacyTaskRoute()` — —
- `canonicalTab()` — —
- `canonicalAction()` — —
- `canonicalContext()` — —
- `setTab()` — —
- `normalizedTab()` — —
- `setSelectedProjectWithUrl()` — —
- `setSelectedTicketWithUrl()` — —
- `setSelectedToolWithUrl()` — —
- `setViewModeWithUrl()` — —
- `setContextWithUrl()` — —
- `setFilterStatusWithUrl()` — —
- `setFilterAgentWithUrl()` — —
- `setSearchQueryWithUrl()` — —
- `healthHook()` — —
- `budgetHook()` — —
- `modelsHook()` — —
- `providersHook()` — —
- `resourcesHook()` — —
- `logsHook()` — —
- `isUp()` — —
- `handleKeyDown()` — —
- `tag()` — —
- `key()` — —
- `handleHashChange()` — —
- `newTab()` — —
- `handlePopState()` — —
- `i()` — —
- `formatDate()` — —
- `date()` — —
- `now()` — —
- `diffMs()` — —
- `diffMins()` — —
- `diffHours()` — —
- `diffDays()` — —
- `formatDuration()` — —
- `mins()` — —
- `hours()` — —
- `days()` — —
- `formatSize()` — —
- `jobToExportRow()` — —
- `formatDuration()` — —
- `useState()` — —
- `useEffect()` — —
- `useCallback()` — —
- `Dashboard()` — —
- `data()` — —
- `root()` — —
- `VoiceHeader()` — —
- `h()` — —
- `VoiceBubbles()` — —
- `VoiceCommands()` — —
- `VoiceHistoryBox()` — —
- `u()` — —
- `SR()` — —
- `r()` — —
- `VoiceChat()` — —
- `recRef()` — —
- `abortRef()` — —
- `finish()` — —
- `handleInput()` — —
- `ctrl()` — —
- `reply()` — —
- `startListening()` — —
- `text()` — —
- `stopAll()` — —
- `onKey()` — —
- `sc()` — —
- `label()` — —
- `DiagnosticsPanel()` — —
- `runTests()` — —
- `r()` — —
- `loadToolReadiness()` — —
- `find()` — —
- `copyErrorsToClipboard()` — —
- `failedTests()` — —
- `lines()` — —
- `issues()` — —
- `apiCall()` — —
- `r()` — —
- `err()` — —
- `matchDSL()` — —
- `t()` — —
- `m()` — —
- `captured()` — —
- `executeDSL()` — —
- `data()` — —
- `setVoiceCredentials()` — —
- `vms()` — —
- `logs()` — —
- `formatToolResult()` — —
- `fn()` — —
- `dsl()` — —
- `label()` — —
- `reply()` — —
- `langHint()` — —
- `res()` — —
- `name()` — —
- `result()` — —
- `processVoiceInput()` — —
- `dslReply()` — —
- `messages()` — —
- `msg()` — —
- `toolReply()` — —
- `useLogFilter()` — —
- `filtered()` — —
- `errorCount()` — —
- `warnCount()` — —
- `LogRow()` — —
- `LogPanel()` — —
- `handleCopy()` — —
- `text()` — —
- `ta()` — —
- `useState()` — —
- `useCallback()` — —
- `useEffect()` — —
- `useMemo()` — —
- `useHumanTasks()` — —
- `refresh()` — —
- `allTickets()` — —
- `createTask()` — —
- `result()` — —
- `completeTask()` — —
- `addComment()` — —
- `HumanTaskPanel()` — —
- `filtered()` — —
- `boardColumns()` — —
- `humanJobs()` — —
- `stats()` — —
- `handleStartStop()` — —
- `useVMSort()` — —
- `sorted()` — —
- `cmp()` — —
- `r()` — —
- `useVMSelection()` — —
- `handleSelect()` — —
- `next()` — —
- `handleSelectAll()` — —
- `handleBulkAction()` — —
- `vmIds()` — —
- `VMCard()` — —
- `actions()` — —
- `VMsPanel()` — —
- `sel()` — —
- `fetchTools()` — —
- `data()` — —
- `detail()` — —
- `handleAction()` — —
- `isDelete()` — —
- `endpoint()` — —
- `res()` — —
- `msg()` — —
- `label()` — —
- `handleToolAssign()` — —
- `runningCount()` — —
- `stoppedCount()` — —
- `pausedCount()` — —
- `StatusBadge()` — —
- `CostBar()` — —
- `pct()` — —
- `Card()` — —
- `StateBadge()` — —
- `colors()` — —
- `useTools()` — —
- `refreshTools()` — —
- `data()` — —
- `refreshQueue()` — —
- `refresh()` — —
- `toolEvents()` — —
- `unsubscribe()` — —
- `ToolsPanel()` — —
- `available()` — —
- `assignedToolName()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `useTasksData()` — —
- `refresh()` — —
- `timer()` — —
- `taskEvents()` — —
- `unsubscribe()` — —
- `TaskCardHeader()` — —
- `statusColor()` — —
- `priorityColor()` — —
- `typeIcon()` — —
- `TaskCardMeta()` — —
- `job()` — —
- `resultSuccess()` — —
- `resultLabel()` — —
- `isActiveJob()` — —
- `environment()` — —
- `TaskJobBadge()` — —
- `statusIcon()` — —
- `duration()` — —
- `filesChanged()` — —
- `hasOutput()` — —
- `TaskInlineLogs()` — —
- `j()` — —
- `TaskJobError()` — —
- `TaskJobResult()` — —
- `output()` — —
- `files()` — —
- `preview()` — —
- `TaskStatusActions()` — —
- `handleStatusChange()` — —
- `TicketDispatchButton()` — —
- `assignedTool()` — —
- `toolName()` — —
- `isActive()` — —
- `handleDispatch()` — —
- `label()` — —
- `TaskSelectionCheckbox()` — —
- `TaskBulkEditBar()` — —
- `selectAllRef()` — —
- `visibleIds()` — —
- `selectedVisibleCount()` — —
- `allVisibleSelected()` — —
- `someVisibleSelected()` — —
- `toolOptions()` — —
- `seen()` — —
- `name()` — —
- `handleApply()` — —
- `count()` — —
- `TaskTicketCard()` — —
- `liveJob()` — —
- `isDone()` — —
- `isFailed()` — —
- `QueueBar()` — —
- `byStatus()` — —
- `lower()` — —
- `CreateMilestoneForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `CreateSprintForm()` — —
- `QuickTaskCreator()` — —
- `availableSprints()` — —
- `priorityClassName()` — —
- `r()` — —
- `onKey()` — —
- `canSubmit()` — —
- `TasksPanel()` — —
- `view()` — —
- `setView()` — —
- `filterStatus()` — —
- `setFilterStatus()` — —
- `filterAgent()` — —
- `setFilterAgent()` — —
- `searchQuery()` — —
- `setSearchQuery()` — —
- `filtered()` — —
- `result()` — —
- `q()` — —
- `boardColumns()` — —
- `handleStartStop()` — —
- `validIds()` — —
- `changed()` — —
- `next()` — —
- `toggleTicketSelection()` — —
- `toggleVisibleSelection()` — —
- `visibleSet()` — —
- `clearSelection()` — —
- `handleBulkUpdate()` — —
- `ids()` — —
- `toolPayload()` — —
- `CostSummary()` — —
- `BudgetCards()` — —
- `dailyUsed()` — —
- `monthlyUsed()` — —
- `SystemCard()` — —
- `ProvidersCard()` — —
- `OverviewTab()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `ModelsTable()` — —
- `exportData()` — —
- `useTickets()` — —
- `refreshTickets()` — —
- `data()` — —
- `refreshSprints()` — —
- `refreshMilestones()` — —
- `refreshTools()` — —
- `refresh()` — —
- `ticketEvents()` — —
- `unsubscribe()` — —
- `TicketCard()` — —
- `assignedEnvironment()` — —
- `handleSprintChange()` — —
- `handleCardClick()` — —
- `handleCheckboxClick()` — —
- `handleStatusChange()` — —
- `handleAssign()` — —
- `CreateMilestoneForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `CreateTicketForm()` — —
- `CreateSprintForm()` — —
- `SprintCard()` — —
- `handleMilestoneChange()` — —
- `MilestoneCard()` — —
- `headers()` — —
- `escape()` — —
- `stringValue()` — —
- `escapeCell()` — —
- `bodyRows()` — —
- `blob()` — —
- `url()` — —
- `link()` — —
- `TicketExportMenu()` — —
- `queryString()` — —
- `params()` — —
- `fetchExport()` — —
- `downloadJSON()` — —
- `downloadCSV()` — —
- `csv()` — —
- `downloadMarkdown()` — —
- `markdown()` — —
- `copyJSON()` — —
- `formatTimestamp()` — —
- `date()` — —
- `TicketHistoryItem()` — —
- `result()` — —
- `stdout()` — —
- `stderr()` — —
- `filesChanged()` — —
- `statusClass()` — —
- `success()` — —
- `execution()` — —
- `projectDir()` — —
- `promptExcerpt()` — —
- `promptLength()` — —
- `isActiveJob()` — —
- `resultLabel()` — —
- `TicketDetailPanel()` — —
- `jobHistory()` — —
- `latestJob()` — —
- `latestExecutionMetadata()` — —
- `latestProjectDir()` — —
- `latestPromptExcerpt()` — —
- `latestPromptLength()` — —
- `latestSuccess()` — —
- `latestExitCode()` — —
- `latestStdoutLines()` — —
- `latestStderrLines()` — —
- `latestFilesChanged()` — —
- `latestIsActiveJob()` — —
- `latestResultLabel()` — —
- `TicketsPanel()` — —
- `loadSelectedTicket()` — —
- `handleRefresh()` — —
- `toggleTicketSelection()` — —
- `newSet()` — —
- `selectAllTickets()` — —
- `clearSelection()` — —
- `bulkUpdateStatus()` — —
- `ids()` — —
- `bulkAssignTool()` — —
- `bulkDeleteTickets()` — —
- `visibleSprints()` — —
- `filtered()` — —
- `q()` — —
- `comparison()` — —
- `boardColumns()` — —
- `stats()` — —
- `count()` — —
- `selectedTicketSummary()` — —
- `useQuickDo()` — —
- `submit()` — —
- `r()` — —
- `toolInfo()` — —
- `onKey()` — —
- `canSubmit()` — —
- `QuickDoFeedback()` — —
- `color()` — —
- `QuickDoCompact()` — —
- `q()` — —
- `QuickDo()` — —
- `HealthCard()` — —
- `checks()` — —
- `total()` — —
- `ok()` — —
- `alerts()` — —
- `BudgetMiniCard()` — —
- `dailyUsed()` — —
- `monthlyUsed()` — —
- `monthlyLimit()` — —
- `remaining()` — —
- `QueueMiniCard()` — —
- `load()` — —
- `data()` — —
- `timer()` — —
- `qs()` — —
- `running()` — —
- `done()` — —
- `ms()` — —
- `ActivityRow()` — —
- `RecentActivity()` — —
- `tickets()` — —
- `jobs()` — —
- `HomeTab()` — —
- `vms()` — —
- `running()` — —
- `daily()` — —
- `monthly()` — —
- `logs()` — —
- `ids()` — —
- `routes()` — —
- `ok()` — —
- `fail()` — —
- `accounts()` — —
- `useProjects()` — —
- `refresh()` — —
- `data()` — —
- `projectEvents()` — —
- `unsubscribe()` — —
- `body()` — —
- `detail()` — —
- `kind()` — —
- `path()` — —
- `current()` — —
- `MultiSelectSection()` — —
- `selectedSet()` — —
- `selectedItems()` — —
- `hasItems()` — —
- `listContent()` — —
- `value()` — —
- `checked()` — —
- `AssignmentBadge()` — —
- `TicketTable()` — —
- `loadTools()` — —
- `handleFieldChange()` — —
- `handleHoursChange()` — —
- `hours()` — —
- `handleToolChange()` — —
- `isSaving()` — —
- `ProjectCard()` — —
- `projectKey()` — —
- `assignedTools()` — —
- `assignedEnvironments()` — —
- `assignedLlms()` — —
- `assignedUsers()` — —
- `ticketCount()` — —
- `envCount()` — —
- `toolCount()` — —
- `llmCount()` — —
- `userCount()` — —
- `handleToggleTickets()` — —
- `handleDelete()` — —
- `handleEdit()` — —
- `ProjectFormUnified()` — —
- `environmentOptionsSource()` — —
- `toolOptionsSource()` — —
- `modelOptionsSource()` — —
- `userOptionsSource()` — —
- `toolOptions()` — —
- `seen()` — —
- `modelOptions()` — —
- `userOptions()` — —
- `handleSave()` — —
- `resetForm()` — —
- `handleSwitchToCreate()` — —
- `handleSwitchToEdit()` — —
- `isEditMode()` — —
- `gradientClass()` — —
- `accentColor()` — —
- `idPrefix()` — —
- `ProjectsPanel()` — —
- `isProjectTicketsView()` — —
- `loadProjectOptions()` — —
- `syncProjectUrl()` — —
- `url()` — —
- `handleSelectProject()` — —
- `handleEditProject()` — —
- `handleCancelEdit()` — —
- `handleProjectSaved()` — —
- `editingProject()` — —
- `stats()` — —
- `projectCountSuffix()` — —
- `useSystemData()` — —
- `refresh()` — —
- `SystemPanel()` — —
- `activeProviders()` — —
- `useState()` — —
- `useEffect()` — —
- `useMemo()` — —
- `useCallback()` — —
- `instances()` — —
- `EnvironmentsPanel()` — —
- `environmentMap()` — —
- `refresh()` — —
- `resetForm()` — —
- `handleSubmit()` — —
- `payload()` — —
- `handleEdit()` — —
- `handleDelete()` — —
- `response()` — —
- `handleToolAssign()` — —
- `countsByKind()` — —
- `assignedToolCount()` — —
- `assignedInstanceCount()` — —
- `currentEnvironmentId()` — —
- `currentEnvironment()` — —
- `currentInstanceName()` — —
- `toolInstances()` — —
- `toolInstanceOptions()` — —
- `ALL_TAB_IDS()` — —
- `DashboardHeader()` — —
- `isDark()` — —
- `headerClass()` — —
- `titleClass()` — —
- `subtitleClass()` — —
- `themeLabel()` — —
- `toggleClass()` — —
- `refreshClass()` — —
- `TabNav()` — —
- `navClass()` — —
- `activeTabClass()` — —
- `inactiveTabClass()` — —
- `AccountRow()` — —
- `a()` — —
- `NewAccountForm()` — —
- `handleSubmit()` — —
- `AccountsPanel()` — —
- `handleCreate()` — —
- `useRef()` — —
- `USER_EVENT_TYPES()` — —
- `useUsers()` — —
- `refreshUsers()` — —
- `data()` — —
- `syncGitUsers()` — —
- `createUser()` — —
- `setDefaultUser()` — —
- `unsubscribe()` — —
- `UserCard()` — —
- `roleClass()` — —
- `CreateUserForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `UsersPanel()` — —
- `handleSetDefault()` — —
- `handleCreate()` — —
- `handleSyncGit()` — —
- `result()` — —
- `activeUsers()` — —
- `defaultUserId()` — —
- `useState()` — —
- `useEffect()` — —
- `useCallback()` — —
- `useMemo()` — —
- `EMPTY_COMPLETED()` — —
- `SETUP_EVENT_TYPES()` — —
- `completed()` — —
- `config()` — —
- `SetupPanel()` — —
- `applySnapshot()` — —
- `refreshSetupState()` — —
- `data()` — —
- `unsubscribe()` — —
- `handleToggleStep()` — —
- `handleResetChecklist()` — —
- `checkedCount()` — —
- `autoCount()` — —
- `manualCount()` — —
- `rootCount()` — —
- `setField()` — —
- `setSecretField()` — —
- `copyText()` — —
- `copyAllCommands()` — —
- `text()` — —
- `envSnippet()` — —
- `oneLineSummary()` — —
- `lastUpdatedLabel()` — —
- `hasCommands()` — —
- `hasSudoCommands()` — —
- `TicketFilters()` — —
- `handleReset()` — —
- `BulkOperations()` — —
- `toggleTicketSelection()` — —
- `newSet()` — —
- `selectAllTickets()` — —
- `clearSelection()` — —
- `executeBulkAction()` — —
- `ids()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `url()` — —
- `link()` — —
- `downloadJSON()` — —
- `json()` — —
- `TicketList()` — —
- `useState()` — —
- `useEffect()` — —
- `useCallback()` — —
- `useMemo()` — —
- `origin()` — —
- `base()` — —
- `textarea()` — —
- `success()` — —
- `useWebhookIntegrations()` — —
- `refresh()` — —
- `data()` — —
- `timer()` — —
- `webhookEvents()` — —
- `unsubscribe()` — —
- `registerWebhook()` — —
- `url()` — —
- `response()` — —
- `deleteWebhook()` — —
- `testWebhook()` — —
- `IntegrationsPanel()` — —
- `proxymWebhookUrl()` — —
- `guide()` — —
- `handleCopyUrl()` — —
- `handleUseSuggestedUrl()` — —
- `messageClass()` — —
- `meta()` — —
- `isBusy()` — —
- `isJustTested()` — —
- `testSuccess()` — —
- `isActive()` — —
- `statusBadge()` — —
- `testIndicator()` — —
- `useExternalProviders()` — —
- `configureProvider()` — —
- `errorDetail()` — —
- `testMessage()` — —
- `removeProvider()` — —
- `testProvider()` — —
- `ExternalProviderPanel()` — —
- `activeProviders()` — —
- `selectedProvider()` — —
- `config()` — —
- `TicketStats()` — —
- `DiagRooConfig()` — —
- `ok()` — —
- `badge()` — —
- `DiagProviders()` — —
- `DiagExtensions()` — —
- `ok()` — —
- `DiagCopilot()` — —
- `cls()` — —
- `DiagVSCode()` — —
- `DiagProxy()` — —
- `DiagAgentSetup()` — —
- `DiagAgentTest()` — —
- `skipped()` — —
- `REGISTRY_MODEL_IDS()` — —
- `ToolCard()` — —
- `catClass()` — —
- `handleCardClick()` — —
- `handleModelChange()` — —
- `newModel()` — —
- `useTicketFilters()` — —
- `result()` — —
- `q()` — —
- `comparison()` — —
- `useTicketStats()` — —
- `count()` — —
- `useTicketReviewDetail()` — —
- `refreshDetail()` — —
- `data()` — —
- `useTicketsData()` — —
- `refreshTickets()` — —
- `refreshSprints()` — —
- `refreshMilestones()` — —
- `refresh()` — —
- `TicketsPanelRefactored()` — —
- `filterStatus()` — —
- `setFilterStatus()` — —
- `searchQuery()` — —
- `setSearchQuery()` — —
- `filtered()` — —
- `stats()` — —
- `handleRefresh()` — —
- `toggleTicketSelection()` — —
- `newSet()` — —
- `visibleSprints()` — —
- `auditComments()` — —
- `author()` — —
- `content()` — —
- `latestComment()` — —
- `latestJob()` — —
- `filesChanged()` — —
- `readOnlyRun()` — —
- `formatTimestamp()` — —
- `statusBadgeClass()` — —
- `isAudit()` — —
- `JobRow()` — —
- `statusClass()` — —
- `hasLogs()` — —
- `isFailed()` — —
- `PredictiveAlerts()` — —
- `alerts()` — —
- `queuedJobs()` — —
- `failingTools()` — —
- `stuckJobs()` — —
- `DiagnosticActions()` — —
- `isAutoFixable()` — —
- `requiresHuman()` — —
- `DispatchTableHeader()` — —
- `ProjectInfoResolver()` — —
- `getProjectInfo()` — —
- `project()` — —
- `path()` — —
- `renderProjectInfo()` — —
- `projectInfo()` — —
- `ToolsJobQueue()` — —
- `handleStartStop()` — —
- `handleRetryJob()` — —
- `handleRepairJob()` — —
- `data()` — —
- `details()` — —
- `handleSelectJob()` — —
- `handleCloseJobDetails()` — —
- `ToolsPanelRefactored()` — —
- `HealthTrends()` — —
- `metrics()` — —
- `now()` — —
- `oneHourAgo()` — —
- `oneDayAgo()` — —
- `recentChecks()` — —
- `dayChecks()` — —
- `toolHistory()` — —
- `statuses()` — —
- `wasOk()` — —
- `nowDegraded()` — —
- `TicketStatusBadges()` — —
- `getStatusBadgeClass()` — —
- `getPriorityBadgeClass()` — —
- `getToolCategoryClass()` — —
- `renderStatusBadge()` — —
- `statusClass()` — —
- `displayStatus()` — —
- `renderPriorityBadge()` — —
- `priorityClass()` — —
- `displayPriority()` — —
- `renderCurrentTool()` — —
- `DispatchTableRow()` — —
- `statusBadges()` — —
- `projectResolver()` — —
- `currentTool()` — —
- `toolInfo()` — —
- `projectInfo()` — —
- `projectDir()` — —
- `TicketDispatchTableRefactored()` — —
- `availableTools()` — —
- `unavailableTools()` — —
- `dispatchableTickets()` — —
- `projectResolver()` — —
- `loadTickets()` — —
- `data()` — —
- `loadProjects()` — —
- `handleToolSelect()` — —
- `ToolsDispatch()` — —
- `ProviderConfigPanel()` — —
- `JobDetailsPanel()` — —
- `result()` — —
- `stdout()` — —
- `stderr()` — —
- `filesChanged()` — —
- `isFailed()` — —
- `ticketTitle()` — —
- `ticketStatus()` — —
- `execution()` — —
- `promptExcerpt()` — —
- `projectDir()` — —
- `resultSuccess()` — —
- `isActiveJob()` — —
- `stdoutLines()` — —
- `stderrLines()` — —
- `ToolHealthCard()` — —
- `statusClass()` — —
- `isHuman()` — —
- `ToolsRegistry()` — —
- `available()` — —
- `unavailable()` — —
- `DispatchActions()` — —
- `QueueSummary()` — —
- `ToolAvailabilityAlert()` — —
- `BulkAutoFix()` — —
- `ToolHealthDisplay()` — —
- `summary()` — —
- `degradedCount()` — —
- `TasksBoard()` — —
- `TasksList()` — —
- `TasksTable()` — —
- `TasksViewControls()` — —
- `ToolHealthPanelRefactored()` — —
- `loadReadiness()` — —
- `data()` — —
- `loadHealth()` — —
- `events()` — —
- `handleProviderChange()` — —
- `handleAutoFix()` — —
- `action()` — —
- `result()` — —
- `handleBulkAutoFix()` — —
- `executed()` — —
- `humanRequired()` — —
- `failed()` — —
- `summary()` — —
- `tools()` — —
- `degradedCount()` — —
- `TasksRecentJobs()` — —
- `HumanTaskTable()` — —
- `HumanTaskBoard()` — —
- `HumanJobsList()` — —
- `HumanTaskList()` — —
- `HumanViewControls()` — —
- `TasksPanelRefactored()` — —
- `view()` — —
- `setView()` — —
- `filterStatus()` — —
- `setFilterStatus()` — —
- `filterAgent()` — —
- `setFilterAgent()` — —
- `searchQuery()` — —
- `setSearchQuery()` — —
- `filtered()` — —
- `result()` — —
- `q()` — —
- `boardColumns()` — —
- `handleStartStop()` — —
- `handleViewChange()` — —
- `handleFilterChange()` — —
- `HumanTaskStats()` — —
- `RecentJobsList()` — —
- `HumanTaskPanelRefactored()` — —
- `view()` — —
- `setView()` — —
- `filterStatus()` — —
- `setFilterStatus()` — —
- `filtered()` — —
- `boardColumns()` — —
- `humanJobs()` — —
- `stats()` — —
- `handleStartStop()` — —
- `handleViewChange()` — —
- `handleFilterChange()` — —
- `ProjectExport()` — —
- `exportProject()` — —
- `response()` — —
- `downloadJSON()` — —
- `data()` — —
- `json()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `copyToClipboard()` — —
- `content()` — —
- `button()` — —
- `originalText()` — —
- `TableExport()` — —
- `convertToCSV()` — —
- `headers()` — —
- `csvHeaders()` — —
- `csvRows()` — —
- `value()` — —
- `downloadCSV()` — —
- `csv()` — —
- `blob()` — —
- `link()` — —
- `url()` — —
- `downloadJSON()` — —
- `json()` — —
- `copyToClipboard()` — —
- `button()` — —
- `originalText()` — —
- `ViewControls()` — —
- `viewOptions()` — —
- `statusList()` — —
- `JobStatusBadge()` — —
- `color()` — —
- `JobRow()` — —
- `test_command()` — —
- `check()` — —
- `skip()` — —
- `usage()` — —
- `log_pass()` — —
- `log_fail()` — —
- `log_info()` — —
- `require_cmd()` — —
- `check_contains()` — —
- `check_status()` — —
- `main()` — —
- `print()` — —
- `api()` — —
- `parse_response()` — —
- `phase_health()` — —
- `phase_tools()` — —
- `phase_executor()` — —
- `dispatch_and_monitor()` — —
- `phase_lifecycle()` — —
- `phase_queue_logs()` — —
- `phase_tickets()` — —
- `phase_healthcheck()` — —
- `summary()` — —
- `EditableTicketTable()` — —
- `cardTitle()` — —
- `editable()` — —
- `handleStatusChange()` — —
- `handlePriorityChange()` — —
- `handleToolChange()` — —
- `handleProjectChange()` — —
- `colCount()` — —
- `isSelected()` — —
- `main()` — —
- `main()` — —
- `lifespan(app)` — —
- `cli()` — —


## Project Structure

📄 `docs.open-webui-tools.proxym_tools` (9 functions, 1 classes)
📄 `examples.cli_shell_scenario`
📄 `examples.dry-run-all-examples` (1 functions)
📄 `examples.dry-run-commands` (1 functions)
📄 `examples.multi-project-nlp.benchmark` (2 functions)
📄 `examples.multi-project-nlp.run` (2 functions)
📄 `examples.multi-project.run` (5 functions)
📄 `examples.multi-project.src.calculator.src.calculator` (4 functions)
📄 `examples.multi-project.src.greeter.src.greeter` (3 functions, 1 classes)
📄 `examples.multi-project.src.greeter.src.greeter.greeter` (3 functions, 1 classes)
📄 `examples.simple-3-tickets.run` (5 functions)
📄 `examples.todo-app-ts.run` (9 functions)
📦 `examples.todo-app-ts.templates` (1 functions)
📄 `examples.todo-app-ts.templates.commands` (6 functions)
📄 `examples.todo-app-ts.templates.format` (5 functions)
📄 `examples.todo-app-ts.templates.store` (16 functions, 1 classes)
📄 `examples.todo-app-ts.templates.types` (4 classes)
📄 `examples.todo-app-ts.verify` (25 functions)
📄 `frontend.dashboard-sse-service` (16 functions, 1 classes)
📄 `frontend.proxym-dashboard`
📄 `project`
📄 `project.examples.advanced_usage`
📄 `project.examples.quickstart`
📄 `scripts.check_dashboard` (8 functions)
📄 `scripts.evaluate_llm_work` (2 functions)
📄 `scripts.fix_corrupted_db` (1 functions)
📄 `scripts.jetson-entrypoint`
📄 `scripts.proxym-voice-chat` (3 functions)
📄 `scripts.proxym-voice-server`
📄 `scripts.seed_sprint8` (1 functions)
📄 `scripts.setup`
📄 `scripts.validate_system` (11 functions)
📄 `services.vscode.entrypoint` (5 functions)
📦 `src.proxym`
📦 `src.proxym.accounts` (20 functions, 8 classes)
📦 `src.proxym.api`
📄 `src.proxym.api._diag_agent` (5 functions)
📄 `src.proxym.api._diag_common` (1 functions)
📄 `src.proxym.api._diag_providers` (1 functions)
📄 `src.proxym.api._diag_proxy` (1 functions)
📄 `src.proxym.api._diag_roo` (4 functions)
📄 `src.proxym.api._diag_vscode` (2 functions)
📄 `src.proxym.api._pipeline` (16 functions, 1 classes)
📄 `src.proxym.api._state` (6 functions)
📄 `src.proxym.api.completions` (12 functions)
📄 `src.proxym.api.console` (4 functions)
📄 `src.proxym.api.context_api` (7 functions)
📄 `src.proxym.api.diagnostics` (9 functions)
📄 `src.proxym.api.external_api` (8 functions, 8 classes)
📄 `src.proxym.api.frontend` (11 functions)
📄 `src.proxym.api.observability_api` (8 functions, 1 classes)
📄 `src.proxym.api.system` (8 functions)
📄 `src.proxym.api.voice_actions` (9 functions)
📄 `src.proxym.api.vscode_api` (11 functions)
📦 `src.proxym.cache` (10 functions, 3 classes)
📦 `src.proxym.cli`
📄 `src.proxym.cli._cli_schema` (18 functions, 1 classes)
📄 `src.proxym.cli._client` (4 functions)
📦 `src.proxym.cli._groups`
📄 `src.proxym.cli._groups._shared` (7 functions)
📄 `src.proxym.cli._groups.accounts_ctl` (7 functions)
📄 `src.proxym.cli._groups.browser_ctl` (2 functions)
📄 `src.proxym.cli._groups.context_ctl` (3 functions)
📄 `src.proxym.cli._groups.diagnostics_ctl` (3 functions)
📄 `src.proxym.cli._groups.do_ctl` (11 functions)
📄 `src.proxym.cli._groups.external_ctl` (16 functions)
📄 `src.proxym.cli._groups.keys_ctl` (7 functions)
📄 `src.proxym.cli._groups.multi_ctl` (4 functions)
📄 `src.proxym.cli._groups.observability_ctl` (5 functions)
📄 `src.proxym.cli._groups.projects_ctl` (11 functions)
📄 `src.proxym.cli._groups.tickets_ctl` (15 functions)
📄 `src.proxym.cli._groups.tools_ctl` (8 functions)
📄 `src.proxym.cli._groups.vms_ctl` (7 functions)
📄 `src.proxym.cli._groups.vscode_ctl` (1 functions)
📄 `src.proxym.cli.accounts` (6 functions)
📄 `src.proxym.cli.browser` (5 functions)
📄 `src.proxym.cli.chat` (20 functions)
📄 `src.proxym.cli.config_validate` (15 functions, 2 classes)
📄 `src.proxym.cli.context` (6 functions)
📄 `src.proxym.cli.diagnostics` (7 functions)
📄 `src.proxym.cli.dsl` (8 functions, 2 classes)
📄 `src.proxym.cli.observability` (6 functions)
📄 `src.proxym.cli.smart_defaults` (6 functions)
📄 `src.proxym.cli.system` (6 functions)
📄 `src.proxym.cli.tickets` (16 functions)
📄 `src.proxym.cli.tts` (5 functions, 1 classes)
📄 `src.proxym.cli.utils.cmd_sessions_list` (3 functions)
📄 `src.proxym.cli.vms` (11 functions)
📄 `src.proxym.cli.voice` (3 functions, 1 classes)
📄 `src.proxym.cli.vscode` (8 functions)
📄 `src.proxym.config` (3 functions, 1 classes)
📦 `src.proxym.context`
📄 `src.proxym.context._context` (1 functions, 1 classes)
📄 `src.proxym.context.detector` (8 functions)
📄 `src.proxym.context.session` (12 functions, 2 classes)
📄 `src.proxym.context.tool_selector` (2 functions)
📄 `src.proxym.ctl` (25 functions)
📦 `src.proxym.dashboard`
📄 `src.proxym.dashboard._accounts` (5 functions, 2 classes)
📄 `src.proxym.dashboard._costs` (3 functions)
📄 `src.proxym.dashboard._environments_api` (33 functions, 6 classes)
📄 `src.proxym.dashboard._events_sse` (2 functions)
📄 `src.proxym.dashboard._lifecycle` (6 functions, 1 classes)
📄 `src.proxym.dashboard._projects_api` (16 functions, 3 classes)
📄 `src.proxym.dashboard._setup_api` (5 functions, 1 classes)
📄 `src.proxym.dashboard._shared` (2 functions)
📄 `src.proxym.dashboard._system` (4 functions)
📄 `src.proxym.dashboard._tickets_api` (21 functions)
📄 `src.proxym.dashboard._tickets_models` (8 classes)
📄 `src.proxym.dashboard._tickets_support` (8 functions)
📄 `src.proxym.dashboard._vms` (12 functions, 3 classes)
📄 `src.proxym.dashboard.api` (14 functions)
📄 `src.proxym.dashboard.components.accounts` (6 functions)
📄 `src.proxym.dashboard.components.diagnostics` (10 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagAgent` (3 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagConfig` (4 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagExtensions` (3 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagInfrastructure` (2 functions)
📄 `src.proxym.dashboard.components.diagnostics.helpers` (4 functions)
📄 `src.proxym.dashboard.components.environments` (31 functions)
📄 `src.proxym.dashboard.components.home` (41 functions)
📄 `src.proxym.dashboard.components.human` (18 functions)
📄 `src.proxym.dashboard.components.human.HumanJobsList` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskBoard` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskList` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskPanelRefactored` (13 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskStats` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanTaskTable` (1 functions)
📄 `src.proxym.dashboard.components.human.HumanViewControls` (1 functions)
📄 `src.proxym.dashboard.components.integrations` (56 functions)
📄 `src.proxym.dashboard.components.layout` (14 functions)
📄 `src.proxym.dashboard.components.logs` (9 functions)
📄 `src.proxym.dashboard.components.models` (21 functions)
📄 `src.proxym.dashboard.components.overview` (7 functions)
📄 `src.proxym.dashboard.components.projects` (83 functions)
📄 `src.proxym.dashboard.components.setup` (35 functions)
📄 `src.proxym.dashboard.components.shared.EditableTicketTable` (9 functions)
📄 `src.proxym.dashboard.components.shared.ProjectExport` (14 functions)
📄 `src.proxym.dashboard.components.shared.RecentJobsList` (1 functions)
📄 `src.proxym.dashboard.components.shared.TableExport` (19 functions)
📄 `src.proxym.dashboard.components.shared.TicketConstants`
📄 `src.proxym.dashboard.components.shared.ViewControls` (3 functions)
📄 `src.proxym.dashboard.components.shared.jobs.JobRow` (1 functions)
📄 `src.proxym.dashboard.components.shared.jobs.JobStatusBadge` (2 functions)
📄 `src.proxym.dashboard.components.shared.jobs.jobFormatters` (2 functions)
📄 `src.proxym.dashboard.components.system` (4 functions)
📄 `src.proxym.dashboard.components.tasks` (131 functions)
📄 `src.proxym.dashboard.components.tasks.TasksBoard` (1 functions)
📄 `src.proxym.dashboard.components.tasks.TasksList` (1 functions)
📄 `src.proxym.dashboard.components.tasks.TasksPanelRefactored` (16 functions)
📄 `src.proxym.dashboard.components.tasks.TasksRecentJobs` (1 functions)
📄 `src.proxym.dashboard.components.tasks.TasksTable` (1 functions)
📄 `src.proxym.dashboard.components.tasks.TasksViewControls` (1 functions)
📄 `src.proxym.dashboard.components.tickets` (110 functions)
📄 `src.proxym.dashboard.components.tickets.BulkOperations` (7 functions)
📄 `src.proxym.dashboard.components.tickets.TicketFilters` (2 functions)
📄 `src.proxym.dashboard.components.tickets.TicketList` (17 functions)
📄 `src.proxym.dashboard.components.tickets.TicketStats` (1 functions)
📄 `src.proxym.dashboard.components.tickets.TicketsPanelRefactored` (39 functions)
📄 `src.proxym.dashboard.components.tools` (10 functions)
📄 `src.proxym.dashboard.components.tools.BulkAutoFix` (1 functions)
📄 `src.proxym.dashboard.components.tools.DiagnosticActions` (3 functions)
📄 `src.proxym.dashboard.components.tools.DispatchActions` (1 functions)
📄 `src.proxym.dashboard.components.tools.DispatchTableHeader` (1 functions)
📄 `src.proxym.dashboard.components.tools.DispatchTableRow` (7 functions)
📄 `src.proxym.dashboard.components.tools.HealthTrends` (11 functions)
📄 `src.proxym.dashboard.components.tools.JobDetailsPanel` (15 functions)
📄 `src.proxym.dashboard.components.tools.JobRow` (4 functions)
📄 `src.proxym.dashboard.components.tools.PredictiveAlerts` (5 functions)
📄 `src.proxym.dashboard.components.tools.ProjectInfoResolver` (6 functions)
📄 `src.proxym.dashboard.components.tools.ProviderConfigPanel` (1 functions)
📄 `src.proxym.dashboard.components.tools.QueueSummary` (1 functions)
📄 `src.proxym.dashboard.components.tools.TicketDispatchTableRefactored` (10 functions)
📄 `src.proxym.dashboard.components.tools.TicketStatusBadges` (11 functions)
📄 `src.proxym.dashboard.components.tools.ToolAvailabilityAlert` (1 functions)
📄 `src.proxym.dashboard.components.tools.ToolCard` (6 functions)
📄 `src.proxym.dashboard.components.tools.ToolHealthCard` (3 functions)
📄 `src.proxym.dashboard.components.tools.ToolHealthDisplay` (3 functions)
📄 `src.proxym.dashboard.components.tools.ToolHealthPanelRefactored` (18 functions)
📄 `src.proxym.dashboard.components.tools.ToolsDispatch` (1 functions)
📄 `src.proxym.dashboard.components.tools.ToolsJobQueue` (9 functions)
📄 `src.proxym.dashboard.components.tools.ToolsPanelRefactored` (1 functions)
📄 `src.proxym.dashboard.components.tools.ToolsRegistry` (3 functions)
📄 `src.proxym.dashboard.components.ui` (6 functions)
📄 `src.proxym.dashboard.components.users` (23 functions)
📄 `src.proxym.dashboard.components.vms` (35 functions)
📄 `src.proxym.dashboard.components.voice` (30 functions)
📄 `src.proxym.dashboard.components.voice_engine` (31 functions)
📄 `src.proxym.dashboard.components.voice_schemas` (10 functions)
📄 `src.proxym.dashboard.hooks.useDashboardData` (79 functions)
📄 `src.proxym.dashboard.integrations_api` (4 functions, 2 classes)
📄 `src.proxym.dashboard.orchestrator` (13 functions, 1 classes)
📄 `src.proxym.dashboard.panel` (7 functions)
📦 `src.proxym.dashboard.tickets`
📄 `src.proxym.dashboard.tickets.TicketManagerRefactored` (26 functions, 4 classes)
📄 `src.proxym.dashboard.tickets._manager` (34 functions, 1 classes)
📄 `src.proxym.dashboard.tickets._models` (4 functions, 11 classes)
📄 `src.proxym.dashboard.tickets.utils.delete_ticket` (1 functions)
📦 `src.proxym.dashboard.tools`
📄 `src.proxym.dashboard.tools.HealthCheckerRefactored` (15 functions, 7 classes)
📄 `src.proxym.dashboard.tools._autofix` (5 functions, 1 classes)
📄 `src.proxym.dashboard.tools._dispatch` (4 functions, 3 classes)
📄 `src.proxym.dashboard.tools._health` (6 functions)
📄 `src.proxym.dashboard.tools._helpers` (3 functions)
📄 `src.proxym.dashboard.tools._lifecycle` (2 functions)
📄 `src.proxym.dashboard.tools._providers` (2 functions, 1 classes)
📄 `src.proxym.dashboard.tools._queue` (8 functions)
📄 `src.proxym.dashboard.tools._registry` (5 functions)
📦 `src.proxym.dashboard.tools.utils`
📄 `src.proxym.dashboard.tools.utils._aider_install_fix` (1 functions)
📄 `src.proxym.dashboard.tools.utils.start_executor` (3 functions)
📦 `src.proxym.dashboard.users`
📄 `src.proxym.dashboard.users._api` (9 functions)
📄 `src.proxym.dashboard.users._api_models` (2 classes)
📄 `src.proxym.dashboard.users._git_support` (35 functions, 1 classes)
📄 `src.proxym.dashboard.users._git_sync` (9 functions, 1 classes)
📄 `src.proxym.dashboard.users._manager` (13 functions, 1 classes)
📄 `src.proxym.dashboard.users._models` (1 functions, 2 classes)
📄 `src.proxym.dashboard.users._permissions` (2 functions)
📦 `src.proxym.dashboard.utils`
📄 `src.proxym.dashboard.utils._delete_item` (1 functions)
📄 `src.proxym.dashboard.utils._emit_event` (1 functions)
📄 `src.proxym.dashboard.utils.delete_milestone` (2 functions)
📄 `src.proxym.dashboard.utils.delete_ticket` (2 functions)
📄 `src.proxym.dashboard.utils.formatters` (12 functions)
📄 `src.proxym.dashboard.webhooks` (12 functions, 1 classes)
📦 `src.proxym.domain`
📄 `src.proxym.domain.bus` (6 functions, 4 classes)
📦 `src.proxym.domain.commands`
📄 `src.proxym.domain.commands.project_commands` (4 classes)
📄 `src.proxym.domain.commands.setup_commands` (2 classes)
📄 `src.proxym.domain.commands.task_commands` (3 classes)
📄 `src.proxym.domain.commands.user_commands` (4 classes)
📄 `src.proxym.domain.events` (15 functions, 33 classes)
📦 `src.proxym.domain.handlers`
📄 `src.proxym.domain.handlers.project_handler` (12 functions, 2 classes)
📄 `src.proxym.domain.handlers.setup_handler` (14 functions, 4 classes)
📄 `src.proxym.domain.handlers.task_handler` (5 functions, 1 classes)
📄 `src.proxym.domain.handlers.user_handler` (12 functions, 2 classes)
📦 `src.proxym.domain.queries`
📄 `src.proxym.domain.queries.project_queries` (3 classes)
📄 `src.proxym.domain.queries.setup_queries` (1 classes)
📄 `src.proxym.domain.queries.user_queries` (4 classes)
📄 `src.proxym.domain.setup` (4 functions)
📦 `src.proxym.external`
📄 `src.proxym.external.config` (9 functions, 2 classes)
📄 `src.proxym.external.providers` (40 functions, 6 classes)
📄 `src.proxym.main` (2 functions)
📦 `src.proxym.mcp`
📄 `src.proxym.mcp._helpers` (3 functions)
📄 `src.proxym.mcp._tools_accounts` (3 functions, 1 classes)
📄 `src.proxym.mcp._tools_system` (3 functions)
📄 `src.proxym.mcp._tools_tickets` (5 functions, 3 classes)
📄 `src.proxym.mcp._tools_vallm` (10 functions, 3 classes)
📄 `src.proxym.mcp._tools_vm` (7 functions, 4 classes)
📄 `src.proxym.mcp.client` (4 functions, 2 classes)
📄 `src.proxym.mcp.registry` (8 functions, 3 classes)
📄 `src.proxym.mcp.router` (4 functions, 1 classes)
📄 `src.proxym.mcp.self_server`
📦 `src.proxym.middleware` (4 functions, 2 classes)
📦 `src.proxym.observability` (8 functions)
📄 `src.proxym.observability.health_events` (7 functions, 3 classes)
📄 `src.proxym.observability.repair_agent` (9 functions, 1 classes)
📄 `src.proxym.observability.watchdog` (13 functions, 1 classes)
📄 `src.proxym.project_config` (2 functions, 1 classes)
📦 `src.proxym.projects` (14 functions, 4 classes)
📄 `src.proxym.projects._enrichment` (5 functions)
📦 `src.proxym.providers` (9 functions, 3 classes)
📦 `src.proxym.router` (13 functions, 1 classes)
📄 `src.proxym.router.strategy` (19 functions, 3 classes)
📄 `src.proxym.storage` (7 functions, 1 classes)
📦 `src.proxym.tools`
📄 `src.proxym.tools._builtins` (3 functions)
📄 `src.proxym.tools._definition` (2 functions, 1 classes)
📄 `src.proxym.tools._enums` (2 classes)
📄 `src.proxym.tools._instance` (2 functions, 1 classes)
📄 `src.proxym.tools._registry` (12 functions, 1 classes)
📦 `src.proxym.tools.adapters` (2 functions)
📄 `src.proxym.tools.adapters._aider` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._base` (5 functions, 1 classes)
📄 `src.proxym.tools.adapters._claude_code` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._codex` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._goose` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._human` (2 functions, 1 classes)
📄 `src.proxym.tools.adapters._interpreter` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._llm_cli` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._llm_fallback` (5 functions)
📄 `src.proxym.tools.adapters._plandex` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._result` (1 functions, 1 classes)
📄 `src.proxym.tools.adapters._shell` (2 functions, 1 classes)
📄 `src.proxym.tools.adapters._vscode` (3 functions, 1 classes)
📄 `src.proxym.tools.executor` (22 functions, 3 classes)
📄 `src.proxym.tools.startup` (7 functions, 1 classes)
📦 `src.proxym.utils`
📄 `src.proxym.utils.get_settings` (1 functions)
📄 `src.proxym.utils.messages` (1 functions)
📦 `src.proxym.virt`
📄 `src.proxym.virt._check` (1 functions)
📄 `src.proxym.virt._config` (1 functions, 3 classes)
📄 `src.proxym.virt._enums` (2 classes)
📄 `src.proxym.virt._infra` (4 functions, 1 classes)
📄 `src.proxym.virt._lifecycle` (12 functions, 1 classes)
📄 `src.proxym.virt._orchestrator` (5 functions, 1 classes)
📄 `src.proxym.virt._project` (2 functions, 1 classes)
📄 `src.proxym.virt._snapshot` (4 functions, 1 classes)
📄 `src.proxym.virt._state` (5 functions, 1 classes)
📄 `src.proxym.virt._vm_config` (7 functions, 1 classes)
📄 `src.proxym.virt.browser_profiles` (12 functions, 2 classes)
📄 `src.proxym.virt.clonebox_adapter` (17 functions, 2 classes)
📦 `src.proxym.virt.profiles` (4 functions)
📄 `src.proxym.virt.utils.detect_chrome_profiles` (3 functions)
📦 `src.proxym.watch` (5 functions, 1 classes)
📄 `src.proxym.watch.client`
📄 `~.github.src.calculator` (5 functions)
📄 `~.github.src.components.Panel` (3 functions)
📄 `~.github.src.hello` (1 functions)

## Requirements

- Python >= >=3.11
- fastapi >=0.115.0- uvicorn [standard]>=0.30.0- httpx >=0.27.0- litellm >=1.55.0- redis >=5.0.0- pydantic >=2.9.0- pydantic-settings >=2.5.0- python-dotenv >=1.0.0- tiktoken >=0.8.0- watchfiles >=0.24.0- xxhash >=3.5.0- rich >=13.9.0- structlog >=24.4.0- pyyaml >=6.0- click >=8.1.0

## Contributing

**Contributors:**
- Tom Softreck <tom@sapletta.com>
- Tom Sapletta <tom-sapletta-com@users.noreply.github.com>

We welcome contributions! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

### Development Setup

```bash
# Clone the repository
git clone https://github.com/wronai/proxy
cd proxy

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest
```

## Documentation

- 📖 [Full Documentation](https://github.com/wronai/proxy/tree/main/docs) — API reference, module docs, architecture
- 🚀 [Getting Started](https://github.com/wronai/proxy/blob/main/docs/getting-started.md) — Quick start guide
- 📚 [API Reference](https://github.com/wronai/proxy/blob/main/docs/api.md) — Complete API documentation
- 🔧 [Configuration](https://github.com/wronai/proxy/blob/main/docs/configuration.md) — Configuration options
- 💡 [Examples](./examples) — Usage examples and code samples

### Generated Files

| Output | Description | Link |
|--------|-------------|------|
| `README.md` | Project overview (this file) | — |
| `docs/api.md` | Consolidated API reference | [View](./docs/api.md) |
| `docs/modules.md` | Module reference with metrics | [View](./docs/modules.md) |
| `docs/architecture.md` | Architecture with diagrams | [View](./docs/architecture.md) |
| `docs/dependency-graph.md` | Dependency graphs | [View](./docs/dependency-graph.md) |
| `docs/coverage.md` | Docstring coverage report | [View](./docs/coverage.md) |
| `docs/getting-started.md` | Getting started guide | [View](./docs/getting-started.md) |
| `docs/configuration.md` | Configuration reference | [View](./docs/configuration.md) |
| `docs/api-changelog.md` | API change tracking | [View](./docs/api-changelog.md) |
| `CONTRIBUTING.md` | Contribution guidelines | [View](./CONTRIBUTING.md) |
| `examples/` | Usage examples | [Browse](./examples) |
| `mkdocs.yml` | MkDocs configuration | — |

<!-- code2docs:end -->