import toga
import os
import json
import pygame
import asyncio
import random
import requests
import subprocess
from toga.style.pack import COLUMN, ROW, Pack
import tkinter as tk
from tkinter import filedialog
from mutagen.easyid3 import EasyID3
import importlib.metadata

class PlatypusMusicPlayer(toga.App):
    def startup(self):
        # --- SETTINGS UI DEFINITION ---
        self.settings_box = toga.Box(
            style=Pack(
                direction=COLUMN, 
                flex=1, 
                background_color="#1e1e1e"
            )
        )
        self.update_button = toga.Button(
            "update",
            on_press=self.update,
        )
        settings_label = toga.Label(
            "Application Settings", 
            style=Pack(
                margin=20, 
                font_weight='bold', 
                font_size=18, 
                color="#ffffff"
            )
        )
        
        self.btn_settings_home = toga.Button(
            "Home", 
            on_press=self.exit_settings, 
            style=Pack(
                margin=10, 
                width=150
            )
        )
        check_for_update_button = toga.Button(
            "Check For Updates",
            on_press=self.check_for_update,
            style=Pack(
                margin=10, 
                width=150
            )
        )
        
        self.settings_box.add(settings_label)
        self.settings_box.add(self.btn_settings_home)
        self.settings_box.add(check_for_update_button)
       
                
        

        # --- INITIALIZE CORE ENGINE ---
        self.bg_color = "#1e1e1e"      
        self.surface_color = "#383737" 
        self.text_color = "#ffffff"    
        
        pygame.init()
        pygame.mixer.init()
        
        self.next_event = pygame.USEREVENT + 1
        pygame.mixer.music.set_endevent(self.next_event)
        
        self.filename = ""
        self.platypus_data = {
            "songs": [], 
            "playlists": []
        }
        self.current_page = "songs"
        self.on = 0
        self.editing_songs = False
        self.current_pl_active = None
        
        self.playback_queue = []
        self.original_queue = []
        self.queue_index = 0
        self.is_shuffled = False
        self.is_looping = False
        self.rename_target_idx = None

        # --- MAIN WINDOW & MENU ---
        self.main_window = toga.MainWindow(title="Platypus Music Player")

        settings_cmd = toga.Command(
            self.open_settings,
            text="Settings",
            group=toga.Group.FILE, 
            section=2
        )
        self.commands.add(settings_cmd)

        # --- UI: TOP PLAYBACK BAR ---
        self.now_playing_label = toga.Label(
            "Stopped", 
            style=Pack(
                margin_left=10, 
                flex=1, 
                font_weight='bold', 
                color=self.text_color
            )
        )
        
        self.play_pause_btn = toga.Button(
            icon="resources/play", 
            on_press=self.toggle_pause, 
            style=Pack(
                width=50, 
                height=50, 
                margin_right=5
            )
        )
        
        self.next_btn = toga.Button(
            icon="resources/next", 
            on_press=self.skip_next, 
            style=Pack(
                width=50, 
                height=50, 
                margin_right=5
            )
        )
        
        self.shuffle_btn = toga.Button(
            icon="resources/shuffleoff", 
            on_press=self.toggle_shuffle, 
            style=Pack(
                width=50, 
                height=50, 
                margin_right=5
            )
        )
        
        self.loop_btn = toga.Button(
            icon="resources/loopoff", 
            on_press=self.toggle_loop, 
            style=Pack(
                width=50, 
                height=50, 
                margin_right=5
            )
        )
        
        self.top_bar = toga.Box(
            children=[
                self.now_playing_label, 
                self.play_pause_btn, 
                self.next_btn, 
                self.shuffle_btn, 
                self.loop_btn
            ],
            style=Pack(
                direction=ROW, 
                margin=5, 
                align_items='center', 
                background_color=self.bg_color
            )
        )

        # --- UI: NAVIGATION ---
        self.btn_goto_songs = toga.Button(
            icon="resources/song", 
            on_press=self.gotosongs, 
            style=Pack(
                height=50, 
                width=50, 
                flex=1
            )
        )
        self.btn_goto_playlist = toga.Button(
            icon="resources/playlist", 
            on_press=self.gotoplaylist, 
            style=Pack(
                height=50, 
                width=50, 
                flex=1
            )
        )
        
        self.nav_bar = toga.Box(
            children=[
                self.btn_goto_songs, 
                self.btn_goto_playlist
            ],
            style=Pack(
                direction=ROW, 
                margin=5, 
                background_color=self.bg_color
            )
        )

        self.action_bar = toga.Box(
            style=Pack(
                direction=ROW, 
                margin=5, 
                background_color=self.bg_color
            )
        )

        # --- UI: LIBRARY PAGE ---
        self.song_list_box = toga.Box(
            style=Pack(
                direction=COLUMN, 
                background_color=self.bg_color
            )
        )
        
        self.btn_edit_library = toga.Button(
            "Edit Library", 
            on_press=self.toggle_edit_songs, 
            style=Pack(margin=5)
        )
        
        self.library_scroll = toga.ScrollContainer(
            content=self.song_list_box, 
            vertical=True, 
            style=Pack(
                flex=1, 
                background_color=self.bg_color
            )
        )
        
        self.library_layout = toga.Box(
            children=[
                self.btn_edit_library, 
                self.library_scroll
            ], 
            style=Pack(
                direction=COLUMN, 
                flex=1, 
                background_color=self.bg_color
            )
        )
        
        # --- UI: PLAYLIST PAGE ---
        self.playlist_list_box = toga.Box(
            style=Pack(
                direction=COLUMN, 
                background_color=self.bg_color
            )
        )
        
        self.rename_input = toga.TextInput(
            placeholder="Enter new name...", 
            style=Pack(
                flex=1, 
                margin=5
            )
        )
        
        self.btn_save_rename = toga.Button(
            "Save", 
            on_press=self.save_rename, 
            style=Pack(margin=5)
        )
        
        self.btn_cancel_rename = toga.Button(
            "Cancel", 
            on_press=self.cancel_rename, 
            style=Pack(margin=5)
        )
        
        self.rename_box = toga.Box(
            children=[
                self.rename_input, 
                self.btn_save_rename, 
                self.btn_cancel_rename
            ],
            style=Pack(
                direction=ROW, 
                visibility='hidden', 
                height=0, 
                background_color=self.bg_color
            ) 
        )
        
        self.btn_new_playlist = toga.Button(
            "+ New Playlist", 
            on_press=self.newplaylist, 
            style=Pack(margin=5)
        )
        
        self.playlist_scroll = toga.ScrollContainer(
            content=self.playlist_list_box, 
            vertical=True, 
            style=Pack(
                flex=1, 
                background_color=self.bg_color
            )
        )
        
        self.playlists_layout = toga.Box(
            children=[
                self.btn_new_playlist, 
                self.rename_box, 
                self.playlist_scroll
            ], 
            style=Pack(
                direction=COLUMN, 
                flex=1, 
                background_color=self.bg_color
            )
        )

        # --- APP ASSEMBLY ---
        self.main_layout = toga.Box(
            children=[
                self.top_bar, 
                self.nav_bar, 
                self.action_bar, 
                self.library_layout
            ],
            style=Pack(
                direction=COLUMN, 
                flex=1, 
                background_color=self.bg_color
            )
        )

        self.update_action_bar()
        self.main_window.content = self.main_layout
        self.main_window.show()
        
        asyncio.create_task(self.check_q())

    # --- SETTINGS LOGIC ---
    def open_settings(self, widget):
        self.main_window.content = self.settings_box

    def exit_settings(self, widget):
        self.main_window.content = self.main_layout

    # --- DATA & FILE PERSISTENCE ---
    def save_data(self):
        if self.filename:
            with open(self.filename, 'w') as f: 
                json.dump(self.platypus_data, f, indent=4)

    def create_new_file(self, widget):
        root = tk.Tk()
        root.withdraw()
        path = filedialog.asksaveasfilename(
            initialfile="data", 
            defaultextension=".platypus", 
            filetypes=[("Platypus Files", "*.platypus")]
        )
        if path:
            self.filename = path
            self.platypus_data = {
                "songs": [], 
                "playlists": []
            }
            self.save_data()
            self.update_action_bar()

    async def load_file(self, widget):
        root = tk.Tk()
        root.withdraw()
        path = filedialog.askopenfilename(
            filetypes=[("Platypus", "*.platypus")]
        )
        if path:
            self.filename = path
            with open(path, 'r') as f: 
                self.platypus_data = json.load(f)
            self.update_action_bar()
            await self.refresh_song_display()

    # --- REFRESH VIEWS ---
    async def refresh_song_display(self):
        for child in list(self.song_list_box.children): 
            self.song_list_box.remove(child)
            
        for path in self.platypus_data.get("songs", []):
            row = toga.Box(
                style=Pack(
                    direction=ROW, 
                    margin=2, 
                    align_items='center', 
                    background_color=self.surface_color
                )
            )
            
            lbl_title = toga.Label(
                self.get_title(path), 
                style=Pack(
                    flex=1, 
                    color=self.text_color, 
                    padding_left=5
                )
            )
            row.add(lbl_title)
            
            if self.editing_songs:
                btn_del = toga.Button(
                    "X", 
                    on_press=self.remove_song_entirely, 
                    id=f"del|{path}", 
                    style=Pack(width=40)
                )
                row.add(btn_del)
            else:
                btn_play = toga.Button(
                    "▶", 
                    on_press=self.play_single, 
                    id=f"p|{path}", 
                    style=Pack(width=40)
                )
                row.add(btn_play)
            
            self.song_list_box.add(row)
        
        self.refresh_playlist_display()

    def refresh_playlist_display(self):
        for child in list(self.playlist_list_box.children): 
            self.playlist_list_box.remove(child)
            
        for i, pl in enumerate(self.platypus_data.get("playlists", [])):
            row = toga.Box(
                style=Pack(
                    direction=ROW, 
                    margin=2, 
                    align_items='center', 
                    background_color=self.surface_color
                )
            )
            
            lbl_name = toga.Label(
                pl[0], 
                style=Pack(
                    flex=1, 
                    color=self.text_color, 
                    padding_left=5
                )
            )
            row.add(lbl_name)
            
            btn_rename = toga.Button(
                "Rename", 
                on_press=self.rename_pl, 
                id=f"rename|{i}", 
                style=Pack(margin_right=5)
            )
            
            btn_delete = toga.Button(
                "Delete", 
                on_press=self.delete_pl, 
                id=f"deletepl|{i}", 
                style=Pack(margin_right=5)
            )
            
            btn_open = toga.Button(
                "Open", 
                on_press=self.open_pl_view, 
                id=f"pl|{pl[0]}"
            )
            
            row.add(btn_rename)
            row.add(btn_delete)
            row.add(btn_open)
            self.playlist_list_box.add(row)

    # --- MUSIC ENGINE LOGIC ---
    def play_path(self, path):
        pygame.mixer.music.load(path)
        pygame.mixer.music.play()
        self.on = 1
        self.play_pause_btn.icon = "resources/pause"
        self.now_playing_label.text = f"Playing: {self.get_title(path)}"

    async def check_q(self):
        while True:
            for event in pygame.event.get():
                if event.type == self.next_event:
                    if self.playback_queue:
                        if self.is_looping: 
                            self.play_path(self.playback_queue[self.queue_index])
                        else:
                            total = len(self.playback_queue)
                            self.queue_index = (self.queue_index + 1) % total
                            self.play_path(self.playback_queue[self.queue_index])
            await asyncio.sleep(0.1)

    def toggle_pause(self, widget):
        if self.on: 
            pygame.mixer.music.pause()
            self.on = 0
            self.play_pause_btn.icon = "resources/play"
        elif self.playback_queue: 
            pygame.mixer.music.unpause()
            self.on = 1
            self.play_pause_btn.icon = "resources/pause"

    def skip_next(self, widget):
        if self.playback_queue:
            total = len(self.playback_queue)
            self.queue_index = (self.queue_index + 1) % total
            self.play_path(self.playback_queue[self.queue_index])

    def toggle_shuffle(self, widget):
        self.is_shuffled = not self.is_shuffled
        if self.is_shuffled:
            widget.icon = "resources/shuffleon"
        else:
            widget.icon = "resources/shuffleoff"
        
        if self.playback_queue:
            current = self.playback_queue[self.queue_index]
            if self.is_shuffled:
                others = [s for s in self.playback_queue if s != current]
                random.shuffle(others)
                self.playback_queue = [current] + others
                self.queue_index = 0
            else:
                self.playback_queue = list(self.original_queue)
                if current in self.playback_queue: 
                    self.queue_index = self.playback_queue.index(current)

    def toggle_loop(self, widget):
        self.is_looping = not self.is_looping
        if self.is_looping:
            widget.icon = "resources/loopon"
        else:
            widget.icon = "resources/loopoff"

    # --- PLAYBACK WRAPPERS ---
    def play_single(self, widget):
        path = widget.id.split("|")[-1]
        self.original_queue = [path]
        self.playback_queue = [path]
        self.queue_index = 0
        self.play_path(path)

    def play_playlist_full(self, widget):
        name = widget.id.split("|")[-1]
        pl = next(p for p in self.platypus_data["playlists"] if p[0] == name)
        if pl[1]:
            self.original_queue = list(pl[1])
            self.playback_queue = list(pl[1])
            self.queue_index = 0
            if self.is_shuffled: 
                self.toggle_shuffle(self.shuffle_btn)
            self.play_path(self.playback_queue[0])

    def play_from_playlist(self, widget):
        parts = widget.id.split("|")
        idx = int(parts[1])
        pl_name = parts[2]
        pl = next(p for p in self.platypus_data["playlists"] if p[0] == pl_name)
        self.original_queue = list(pl[1])
        self.playback_queue = list(pl[1])
        self.queue_index = idx
        if self.is_shuffled: 
            self.toggle_shuffle(self.shuffle_btn)
        self.play_path(self.playback_queue[self.queue_index])

    # --- PLAYLIST MANAGEMENT ---
    def open_pl_view(self, widget):
        name = widget.id.split("|")[-1]
        self.current_pl_active = name
        playlists = self.platypus_data.get("playlists", [])
        song_paths = next(p[1] for p in playlists if p[0] == name)
        
        self.detail_view = toga.Box(
            style=Pack(
                direction=COLUMN, 
                flex=1, 
                background_color=self.bg_color
            )
        )
        
        btn_bar = toga.Box(
            style=Pack(
                direction=ROW, 
                background_color=self.bg_color
            )
        )
        
        btn_bar.add(
            toga.Button(
                "Back", 
                on_press=self.exit_pl_view, 
                style=Pack(margin_right=5)
            )
        )
        
        btn_bar.add(
            toga.Button(
                "Play All", 
                on_press=self.play_playlist_full, 
                id=f"playall|{name}", 
                style=Pack(margin_right=5)
            )
        )
        
        btn_bar.add(
            toga.Button(
                "Add Song", 
                on_press=self.open_add_to_pl_screen
            )
        )
        
        self.detail_view.add(btn_bar)
        
        pl_label = toga.Label(
            f"Playlist: {name}", 
            style=Pack(
                margin=10, 
                font_weight='bold', 
                color=self.text_color
            )
        )
        self.detail_view.add(pl_label)
        
        scroll_content = toga.Box(
            style=Pack(
                direction=COLUMN, 
                background_color=self.bg_color
            )
        )
        
        for i, path in enumerate(song_paths):
            row = toga.Box(
                style=Pack(
                    direction=ROW, 
                    margin=2, 
                    align_items='center', 
                    background_color=self.surface_color
                )
            )
            
            row.add(
                toga.Label(
                    self.get_title(path), 
                    style=Pack(
                        flex=1, 
                        color=self.text_color, 
                        padding_left=5
                    )
                )
            )
            
            row.add(
                toga.Button(
                    "▶", 
                    on_press=self.play_from_playlist, 
                    id=f"plp|{i}|{name}", 
                    style=Pack(
                        width=40, 
                        margin_right=5
                    )
                )
            )
            
            row.add(
                toga.Button(
                    "X", 
                    on_press=self.remove_from_pl, 
                    id=f"rmpl|{path}", 
                    style=Pack(width=40)
                )
            )
            
            scroll_content.add(row)
            
        pl_scroller = toga.ScrollContainer(
            content=scroll_content, 
            vertical=True, 
            style=Pack(
                flex=1, 
                background_color=self.bg_color
            )
        )
        self.detail_view.add(pl_scroller)
        
        self.main_layout.remove(self.nav_bar)
        self.main_layout.remove(self.action_bar)
        
        if self.current_page == "songs":
            self.main_layout.remove(self.library_layout)
        else:
            self.main_layout.remove(self.playlists_layout)
            
        self.main_layout.add(self.detail_view)

    def exit_pl_view(self, widget):
        if hasattr(self, 'detail_view'): 
            self.main_layout.remove(self.detail_view)
            
        self.main_layout.add(self.nav_bar)
        self.main_layout.add(self.action_bar)
        
        if self.current_page == "songs":
            self.main_layout.add(self.library_layout)
        else:
            self.main_layout.add(self.playlists_layout)

    # --- HELPERS & NAVIGATION ---
    def get_title(self, path):
        try: 
            return EasyID3(path)['title'][0]
        except: 
            return os.path.basename(path)

    def gotosongs(self, widget):
        if self.current_page == "songs": 
            return
        self.main_layout.remove(self.playlists_layout)
        self.main_layout.add(self.library_layout)
        self.current_page = "songs"

    def gotoplaylist(self, widget):
        if self.current_page == "playlist": 
            return
        self.main_layout.remove(self.library_layout)
        self.main_layout.add(self.playlists_layout)
        self.current_page = "playlist"

    # --- LIBRARY EDITING ---
    def toggle_edit_songs(self, widget):
        self.editing_songs = not self.editing_songs
        if self.editing_songs:
            widget.label = "Done"
        else:
            widget.label = "Edit Library"
        asyncio.create_task(self.refresh_song_display())

    async def add_songs_to_lib(self, widget):
        root = tk.Tk()
        root.withdraw()
        files = filedialog.askopenfilenames(
            filetypes=[("Audio", "*.mp3")]
        )
        if files:
            self.platypus_data["songs"].extend(list(files))
            self.save_data()
            await self.refresh_song_display()

    def update_action_bar(self):
        for child in list(self.action_bar.children): 
            self.action_bar.remove(child)
            
        if not self.filename:
            self.action_bar.add(
                toga.Button(
                    "Import", 
                    on_press=self.load_file, 
                    style=Pack(margin_right=5)
                )
            )
            self.action_bar.add(
                toga.Button(
                    "New", 
                    on_press=self.create_new_file
                )
            )
        else:
            self.action_bar.add(
                toga.Button(
                    "Add Song to Library", 
                    on_press=self.add_songs_to_lib
                )
            )

    # --- PLAYLIST ACTIONS ---
    def newplaylist(self, widget):
        num = len(self.platypus_data['playlists']) + 1
        name = f"Playlist {num}"
        self.platypus_data['playlists'].append([name, []])
        self.save_data()
        self.refresh_playlist_display()

    def rename_pl(self, widget):
        idx_str = widget.id.split("|")[-1]
        self.rename_target_idx = int(idx_str)
        
        current_name = self.platypus_data["playlists"][self.rename_target_idx][0]
        self.rename_input.value = current_name
        
        self.rename_box.style.visibility = 'visible'
        if hasattr(self.rename_box.style, 'height'): 
            del self.rename_box.style.height 
            
        self.playlist_list_box.style.visibility = 'hidden'
        self.playlist_list_box.style.height = 0
        self.rename_input.focus()

    def save_rename(self, widget):
        new_name = self.rename_input.value.strip()
        if new_name: 
            self.platypus_data["playlists"][self.rename_target_idx][0] = new_name
            self.save_data()
        self.cancel_rename(None)

    def cancel_rename(self, widget):
        self.rename_box.style.visibility = 'hidden'
        self.rename_box.style.height = 0
        self.playlist_list_box.style.visibility = 'visible'
        
        if hasattr(self.playlist_list_box.style, 'height'): 
            del self.playlist_list_box.style.height
            
        self.refresh_playlist_display()

    async def delete_pl(self, widget):
        idx_str = widget.id.split("|")[-1]
        idx = int(idx_str)
        
        confirm = toga.QuestionDialog(
            "Delete Playlist", 
            "Are you sure you want to delete this playlist?"
        )
        
        if await self.main_window.dialog(confirm):
            self.platypus_data["playlists"].pop(idx)
            self.save_data()
            self.refresh_playlist_display()

    def remove_song_entirely(self, widget):
        path = widget.id.split("|")[-1]
        if path in self.platypus_data["songs"]: 
            self.platypus_data["songs"].remove(path)
            
        for pl in self.platypus_data["playlists"]:
            if path in pl[1]: 
                pl[1].remove(path)
                
        self.save_data()
        asyncio.create_task(self.refresh_song_display())

    def remove_from_pl(self, widget):
        path = widget.id.split("|")[-1]
        pl = next(p for p in self.platypus_data["playlists"] if p[0] == self.current_pl_active)
        
        if path in pl[1]: 
            pl[1].remove(path)
            
        self.save_data()
        self.exit_pl_view(None)
        
        # Manually trigger a re-open to refresh content
        fake_btn = toga.Button("", id=f"pl|{self.current_pl_active}")
        self.open_pl_view(fake_btn)

    def open_add_to_pl_screen(self, widget):
        self.main_layout.remove(self.detail_view)
        
        playlists = self.platypus_data["playlists"]
        current_pl = next(pl for pl in playlists if pl[0] == self.current_pl_active)
        
        self.add_songs_page = toga.Box(
            style=Pack(
                direction=COLUMN, 
                flex=1, 
                background_color=self.bg_color
            )
        )
        
        header = toga.Box(
            style=Pack(
                direction=ROW, 
                align_items='center', 
                background_color=self.bg_color
            )
        )
        
        header.add(
            toga.Button(
                "Done", 
                on_press=self.close_add_screen, 
                style=Pack(margin=5)
            )
        )
        
        title_lbl = toga.Label(
            f"Add to {self.current_pl_active}", 
            style=Pack(
                margin_left=10, 
                font_weight='bold', 
                color=self.text_color
            )
        )
        header.add(title_lbl)
        
        self.add_songs_page.add(header)
        
        list_box = toga.Box(
            style=Pack(
                direction=COLUMN, 
                background_color=self.bg_color
            )
        )
        
        for path in self.platypus_data.get("songs", []):
            if path not in current_pl[1]:
                row = toga.Box(
                    style=Pack(
                        direction=ROW, 
                        margin=2, 
                        align_items='center', 
                        background_color=self.surface_color
                    )
                )
                
                row.add(
                    toga.Label(
                        self.get_title(path), 
                        style=Pack(
                            flex=1, 
                            color=self.text_color, 
                            padding_left=5
                        )
                    )
                )
                
                row.add(
                    toga.Button(
                        "+", 
                        on_press=self.confirm_add_to_pl, 
                        id=f"addpath|{path}", 
                        style=Pack(width=40)
                    )
                )
                list_box.add(row)
        
        scroller = toga.ScrollContainer(
            content=list_box, 
            vertical=True, 
            style=Pack(
                flex=1, 
                background_color=self.bg_color
            )
        )
        self.add_songs_page.add(scroller)
        self.main_layout.add(self.add_songs_page)

    def close_add_screen(self, widget):
        self.main_layout.remove(self.add_songs_page)
        fake_btn = toga.Button("", id=f"pl|{self.current_pl_active}")
        self.open_pl_view(fake_btn)

    def confirm_add_to_pl(self, widget):
        path = widget.id.split("|")[-1]
        for pl in self.platypus_data["playlists"]:
            if pl[0] == self.current_pl_active: 
                pl[1].append(path)
                self.save_data()
        widget.enabled = False
        widget.label = "✓"
    async def check_for_update(self,widget):
        github = requests.get("https://raw.githubusercontent.com/beantheplatypus/silly-/refs/heads/main/wowo")
        
        huh = github.text.replace("\n", "")
        print(importlib.metadata.version("platypus_music_player"))
        print(huh)
        if importlib.metadata.version("platypus_music_player") != huh:
            await self.show_thing("WOW THERE BUDDY", "Theres a new update. Do you wanna update?", "yes")
            
        else:
            await self.show_thing("ur good","No New Updates","no")

    def show_update_button(self):
        self.settings_box.add(self.update_button)
    def update(self):
        import platypusmusicupdate
        platypusmusicupdate.update()
    async def show_thing(self, top, words, yes):
        
        if yes == "yes":
            if await self.main_window.dialog(toga.QuestionDialog(top, words)):
                self.update()
        else:
            
            await self.main_window.dialog(toga.InfoDialog(top, words))
def main():
    return PlatypusMusicPlayer(
        "Platypus Music Player", 
        "org.beeware.platypusmusicplayer"
    )

if __name__ == "__main__":
    app = main()
    app.main_loop()