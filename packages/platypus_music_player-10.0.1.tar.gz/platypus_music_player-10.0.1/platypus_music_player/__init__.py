from .main import main
import os
import sys
def clear_screen():
    
    if os.name == 'nt':
        
        os.system('cls')
    else:
        
        os.system('clear')
    
def start():
    clear_screen()
    """Launch the Platypus Music Player."""
    try:
        app = main()
        app.main_loop()
    except Exception as e:
        print(f"Error launching Platypus Player: {e}")

def update():
    import subprocess
    subprocess.run("pip install --upgrade platypus_music_player")
    restart_script()


def restart_script():
  
    print("Restarting...")
    
    
    os.execv(sys.executable, ['python'] + sys.argv)