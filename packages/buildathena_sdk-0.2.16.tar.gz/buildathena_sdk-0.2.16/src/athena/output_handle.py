"""OutputHandle for storage-backed block output materialization.

OutputHandle is the SDK's internal wrapper for data outputs. The harness uses it
to attach metadata and serialization details, materialize plain block returns to
storage at block boundaries, and reload them for downstream inputs.
"""

from __future__ import annotations

import hashlib
import json
import pickle
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Generic, Literal, TypeVar
from uuid import uuid4

if TYPE_CHECKING:
    from athena.storage.protocol import StorageBackend

T = TypeVar("T")


@dataclass
class OutputHandle(Generic[T]):
    """Handle to block output data that may currently exist in memory or storage.

    Within a single harness process a handle may retain `_data`, but
    block-to-block handoff still goes through storage-backed refs. Most blocks
    should return plain values or explicit ``ArtifactRef`` objects instead of
    constructing ``OutputHandle`` directly. This class exists for harness
    internals and compatibility helpers, not as a primary block-author API.
    """

    # Unique identifier for this handle
    handle_id: str = field(default_factory=lambda: str(uuid4()))

    # In-memory data (optional - may be None if only stored)
    _data: T | None = field(default=None, repr=False)

    # Storage information (populated after materialization)
    storage_key: str | None = None
    content_hash: str | None = None

    # Metadata for artifact registration
    name: str | None = None
    schema_type: str | None = None
    mime_type: str | None = None
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    # Provenance tracking
    step_id: str | None = None

    # Lineage tracking
    input_handles: list[OutputHandle[Any]] = field(default_factory=list)

    # Serialization function (defaults to JSON)
    _serializer: Callable[[T], bytes] | None = field(default=None, repr=False)
    _deserializer: Callable[[bytes], T] | None = field(default=None, repr=False)

    # Serialization format: "json" (default), "pickle", or raw "bytes"
    _format: Literal["json", "pickle", "bytes"] | None = field(default=None, repr=False)

    @classmethod
    def from_data(
        cls,
        data: T,
        name: str | None = None,
        schema_type: str | None = None,
        mime_type: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        inputs: list[OutputHandle[Any]] | None = None,
        serializer: Callable[[T], bytes] | None = None,
        deserializer: Callable[[bytes], T] | None = None,
        step_id: str | None = None,
        format: Literal["json", "pickle", "bytes"] | None = None,
    ) -> OutputHandle[T]:
        """Create an OutputHandle from in-memory data.

        The harness uses this internally for ordinary plain block return values.

        Args:
            data: The data to wrap
            name: Human-readable name for the artifact
            schema_type: Schema type identifier (e.g., "model_checkpoint", "samples")
            mime_type: MIME type if applicable
            tags: Tags for categorization
            metadata: Additional metadata
            inputs: Input handles for lineage tracking
            serializer: Custom serialization function (overrides format)
            deserializer: Custom deserialization function (overrides format)
            step_id: ID of the step/node that created this handle
            format: Serialization format - "json" (default), "pickle", or "bytes"

        Returns:
            OutputHandle wrapping the data
        """
        return cls(
            _data=data,
            name=name,
            schema_type=schema_type,
            mime_type=mime_type,
            tags=tags or [],
            metadata=metadata or {},
            step_id=step_id,
            input_handles=inputs or [],
            _serializer=serializer,
            _deserializer=deserializer,
            _format=format,
        )

    @classmethod
    def from_storage(
        cls,
        storage_key: str,
        content_hash: str,
        name: str | None = None,
        schema_type: str | None = None,
        deserializer: Callable[[bytes], T] | None = None,
        step_id: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        format: Literal["json", "pickle", "bytes"] | None = None,
    ) -> OutputHandle[T]:
        """Create an OutputHandle referencing data already in storage.

        Used when:
        - Loading artifacts from previous runs
        - Resuming a paused run
        - Loading external artifacts as inputs

        Args:
            storage_key: Key/path in storage
            content_hash: Content hash for verification
            name: Human-readable name
            schema_type: Schema type identifier
            deserializer: Custom deserialization function
            step_id: ID of the step/node that created this handle
            tags: Tags for categorization
            metadata: Additional metadata
            format: Serialization format used when data was stored

        Returns:
            OutputHandle referencing stored data
        """
        return cls(
            storage_key=storage_key,
            content_hash=content_hash,
            name=name,
            schema_type=schema_type,
            step_id=step_id,
            tags=tags or [],
            metadata=metadata or {},
            _deserializer=deserializer,
            _format=format,
        )

    @property
    def is_materialized(self) -> bool:
        """Check if data has been persisted to storage."""
        return self.storage_key is not None and self.content_hash is not None

    @property
    def has_data(self) -> bool:
        """Check if in-memory data is available."""
        return self._data is not None

    def get_data(self) -> T:
        """Get in-memory data.

        Returns data already loaded in this process. If data is not in memory,
        use ``load_data()`` with a storage backend instead.

        Returns:
            The in-memory data

        Raises:
            ValueError: If no in-memory data is available
        """
        if self._data is None:
            raise ValueError(
                "No in-memory data available. "
                "Use load_data() with a storage backend to fetch from storage."
            )
        return self._data

    def set_data(self, data: T) -> None:
        """Set in-memory data.

        Note: This clears any existing storage info since data may have changed.
        """
        self._data = data
        # Clear storage info since data may have changed
        self.storage_key = None
        self.content_hash = None

    def serialize(self) -> bytes:
        """Serialize the in-memory data to bytes.

        Uses custom serializer if provided, otherwise uses format-based
        serialization (JSON by default, pickle if specified).

        Special cases:
        - bytes: returned as-is (already serialized)

        Returns:
            Serialized bytes

        Raises:
            ValueError: If no data to serialize
        """
        if self._data is None:
            raise ValueError("No data to serialize")

        if self._serializer:
            return self._serializer(self._data)

        # Special case: bytes are already serialized
        if isinstance(self._data, bytes):
            return self._data

        # Format-based serialization
        if self._format == "pickle":
            return pickle.dumps(self._data)
        if self._format == "bytes":
            if isinstance(self._data, bytes):
                return self._data
            raise TypeError("OutputHandle format='bytes' requires bytes data")

        # Default to JSON (language-agnostic)
        return json.dumps(self._data).encode("utf-8")

    def deserialize(self, data: bytes) -> T:
        """Deserialize bytes to data.

        Uses custom deserializer if provided, otherwise uses format-based
        deserialization (JSON by default, pickle if specified).

        Args:
            data: Serialized bytes

        Returns:
            Deserialized data
        """
        if self._deserializer:
            return self._deserializer(data)

        # Format-based deserialization
        if self._format == "pickle":
            return pickle.loads(data)
        if self._format == "bytes":
            return data  # type: ignore[return-value]

        # Default to JSON (language-agnostic)
        return json.loads(data.decode("utf-8"))

    def compute_hash(self) -> str:
        """Compute content hash for the data.

        Returns:
            SHA256 hash of serialized data
        """
        serialized = self.serialize()
        return hashlib.sha256(serialized).hexdigest()

    async def materialize(self, storage: StorageBackend) -> str:
        """Persist data to storage.

        Called automatically by the harness before returning block results to
        the daemon.

        Args:
            storage: Storage backend to use

        Returns:
            Content hash of the stored data
        """
        if self.is_materialized:
            assert self.content_hash is not None  # guaranteed by is_materialized
            return self.content_hash

        # Serialize and store
        serialized = self.serialize()
        content_hash = hashlib.sha256(serialized).hexdigest()
        storage_path = await storage.put(content_hash, serialized)

        self.storage_key = storage_path
        self.content_hash = content_hash

        return content_hash

    async def load_data(self, storage: StorageBackend) -> T:
        """Load data from storage.

        If data is already in memory, returns it directly.
        Otherwise fetches from storage and caches in memory.

        Args:
            storage: Storage backend to use

        Returns:
            The data
        """
        if self._data is not None:
            return self._data

        if not self.is_materialized:
            raise ValueError("Handle has no materialized data to load")

        # Fetch from storage
        assert self.content_hash is not None  # guaranteed by is_materialized check above
        raw_data = await storage.get(self.content_hash)
        self._data = self.deserialize(raw_data)

        return self._data

    def release_memory(self) -> None:
        """Release in-memory data to free memory.

        Only safe to call after materialization.

        Raises:
            ValueError: If not yet materialized
        """
        if not self.is_materialized:
            raise ValueError("Cannot release memory before materialization")
        self._data = None
