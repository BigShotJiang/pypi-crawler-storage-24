"""Block execution context for the Athena SDK."""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import pickle
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, cast
from urllib.parse import urlparse
from uuid import UUID

import httpx

from athena._generated_schemas import ArtifactRef
from athena.output_handle import OutputHandle

logger = logging.getLogger(__name__)

# Characters allowed in event_name: alphanumeric, slash, underscore, dot, hyphen.
# Anything else (e.g. spaces) is replaced with underscores.
_EVENT_NAME_RE = re.compile(r"[^a-zA-Z0-9/_.\-]")

# Environment variable for Block API URL (set by daemon when running blocks)
ATHENA_BLOCK_API_ENV = "ATHENA_BLOCK_API"
ArtifactFormat = Literal["json", "pickle", "bytes"]
_ARTIFACT_FORMATS = {"json", "pickle", "bytes"}


def _format_literal(value: str | None) -> ArtifactFormat | None:
    if value in _ARTIFACT_FORMATS:
        return cast(ArtifactFormat, value)
    return None


def _serialize_inline_value(value: Any, fmt: ArtifactFormat) -> bytes:
    if fmt == "json":
        return json.dumps(value).encode("utf-8")
    if fmt == "pickle":
        return pickle.dumps(value)
    if not isinstance(value, bytes):
        raise TypeError("Artifact format='bytes' requires bytes data")
    return value


def _deserialize_inline_value(raw: bytes, fmt: ArtifactFormat) -> Any:
    if fmt == "json":
        return json.loads(raw.decode("utf-8"))
    if fmt == "pickle":
        return pickle.loads(raw)
    return raw


@dataclass(frozen=True)
class RegisteredArtifact:
    """Explicit publish token returned by ctx.artifacts.register()."""

    ref: ArtifactRef
    content_hash: str | None = None
    storage_key: str | None = None
    mime_type: str | None = None
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    format: ArtifactFormat | None = None

    @property
    def artifact_id(self) -> UUID:
        return self.ref.artifact_id

    @property
    def schema_type(self) -> str | None:
        return self.ref.schema_type

    @property
    def name(self) -> str | None:
        return self.ref.name

    @property
    def uri(self) -> str | None:
        return self.ref.uri

    def as_ref(self) -> ArtifactRef:
        """Return this registered artifact as a downstream ArtifactRef pointer."""
        return self.ref

    def as_data(self) -> _ArtifactDataDelivery:
        """Return this registered artifact as an auto-hydrated downstream value."""
        if self.uri:
            raise ValueError(
                "External artifacts cannot be returned as data. "
                "Return artifact.as_ref() and use ref.uri or ctx.artifacts.load(ref) downstream."
            )
        if self.content_hash is None or self.storage_key is None or self.format is None:
            raise ValueError(
                "Artifact is missing managed storage metadata or a loadable format. "
                "Register it with format= or return artifact.as_ref() instead."
            )
        return _ArtifactDataDelivery(artifact=self)

    def __str__(self) -> str:
        return str(self.ref)


@dataclass(frozen=True)
class _ArtifactDataDelivery:
    """Internal return token for delivering a registered artifact as data."""

    artifact: RegisteredArtifact


class _InputsProxy(dict[str, Any]):
    """Dict proxy that transparently unwraps OutputHandles on access.

    When a block does `ctx.inputs["name"]`, this returns the raw Python
    object instead of the OutputHandle wrapper. Internal code that needs
    the raw OutputHandles should access `_raw_inputs` directly.
    """

    def __getitem__(self, key: str) -> Any:
        value = super().__getitem__(key)
        if isinstance(value, OutputHandle) and value.has_data:
            return value.get_data()
        return value

    def get(self, key: str, default: Any = None) -> Any:  # type: ignore[override]
        try:
            return self[key]
        except KeyError:
            return default


class ArtifactManager:
    """Manager for artifact operations."""

    def __init__(self, context: BlockContext) -> None:
        self._context = context
        self._block_api_client = context._block_api_client
        self._block_api_url = context._block_api_url

    async def register(
        self,
        source: str | Path | bytes | Any | None = None,
        schema_type: str | None = None,
        *,
        local_path: str | Path | None = None,
        name: str | None = None,
        mime_type: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        input_artifacts: list[ArtifactRef | RegisteredArtifact] | None = None,
        format: ArtifactFormat | None = None,
        connection: str | None = None,
    ) -> RegisteredArtifact:
        """Register a durable artifact from a path, URI, bytes, or object."""
        source_value = source if source is not None else local_path
        if source_value is None:
            raise TypeError("register() requires a source")
        if not schema_type:
            raise TypeError("register() requires schema_type")

        input_ids = self._coerce_input_artifact_ids(input_artifacts)
        payload: dict[str, Any] = {
            "schema_type": schema_type,
            "mime_type": mime_type,
            "tags": tags or [],
            "metadata": metadata or {},
            "input_artifact_ids": input_ids,
            "run_id": str(self._context.run_id) if self._context.run_id else None,
            "step_id": self._context.step_id,
            "format": format,
        }

        artifact_name: str
        if self._is_uri_source(source_value):
            resolved_uri = self._normalize_external_uri(cast(str | Path, source_value))
            artifact_name = name or Path(urlparse(resolved_uri).path).name or "artifact"
            payload.update(
                {
                    "uri": resolved_uri,
                    "name": artifact_name,
                    "connection": connection,
                }
            )
        elif self._is_local_path_source(source_value):
            path = Path(cast(str | Path, source_value))
            if not path.exists():
                raise FileNotFoundError(f"Artifact file not found: {path}")
            artifact_name = name or path.name
            payload.update(
                {
                    "name": artifact_name,
                    "content_hash": self._calculate_hash(path),
                    "size_bytes": path.stat().st_size,
                    "local_path": str(path.absolute()),
                }
            )
        else:
            if format is None:
                raise ValueError("In-memory artifact registration requires format=")
            serialized = _serialize_inline_value(source_value, format)
            artifact_name = name or "artifact"
            payload.update(
                {
                    "name": artifact_name,
                    "content_hash": hashlib.sha256(serialized).hexdigest(),
                    "size_bytes": len(serialized),
                    "inline_bytes_b64": base64.b64encode(serialized).decode("ascii"),
                }
            )

        response = await self._block_api_client.post(
            f"{self._block_api_url}/api/artifacts",
            json=payload,
        )
        response.raise_for_status()
        data = cast(dict[str, Any], response.json())
        registered = self._build_registered_artifact(data)

        await self._context.emit_event(
            "artifact_written",
            f"artifact/{_EVENT_NAME_RE.sub('_', registered.name or artifact_name)}",
            {
                "artifact_id": str(registered.artifact_id),
                "schema_type": schema_type,
                "tags": tags or [],
            },
        )

        return registered

    async def resolve(self, ref: ArtifactRef | RegisteredArtifact) -> Path:
        """Resolve an ArtifactRef to a local file path."""
        resolved_ref = self._coerce_artifact_ref(ref)
        if resolved_ref.uri:
            raise ValueError(
                f"Artifact {resolved_ref.artifact_id} is external. Use ref.uri directly: {resolved_ref.uri}"
            )
        response = await self._block_api_client.get(
            f"{self._block_api_url}/api/artifacts/{resolved_ref.artifact_id}/resolve"
        )
        response.raise_for_status()
        data = response.json()
        return Path(data["path"])

    async def load(self, ref: ArtifactRef | RegisteredArtifact) -> Any:
        """Load and deserialize an artifact using its stored format metadata."""
        resolved_ref = self._coerce_artifact_ref(ref)
        meta = await self._fetch_artifact_meta(resolved_ref.artifact_id)
        fmt = _format_literal(meta.get("format"))
        if fmt is None:
            raise ValueError(
                f"Artifact {resolved_ref.artifact_id} has no loadable format. "
                "Use ctx.artifacts.resolve(ref) instead."
            )
        response = await self._block_api_client.get(
            f"{self._block_api_url}/api/artifacts/{resolved_ref.artifact_id}/bytes"
        )
        response.raise_for_status()
        return _deserialize_inline_value(response.content, fmt)

    async def _fetch_artifact_meta(self, artifact_id: UUID) -> dict[str, Any]:
        response = await self._block_api_client.get(
            f"{self._block_api_url}/api/artifacts/{artifact_id}/meta"
        )
        response.raise_for_status()
        return cast(dict[str, Any], response.json())

    def _build_registered_artifact(
        self,
        data: dict[str, Any],
    ) -> RegisteredArtifact:
        artifact_ref = ArtifactRef(
            artifact_id=UUID(data["id"]),
            schema_type=data.get("schema_type"),
            name=data.get("name"),
            uri=data.get("external_uri") or data.get("uri"),
        )
        storage_key: str | None = None
        storage_ref = str(data.get("storage_ref") or "")
        if storage_ref:
            _, storage_key = self._parse_storage_ref(storage_ref)
        return RegisteredArtifact(
            ref=artifact_ref,
            content_hash=data.get("content_hash"),
            storage_key=storage_key,
            mime_type=data.get("mime_type"),
            tags=list(data.get("tags") or []),
            metadata=dict(data.get("metadata") or {}),
            format=_format_literal(data.get("format")),
        )

    def _coerce_artifact_ref(self, ref: ArtifactRef | RegisteredArtifact) -> ArtifactRef:
        if isinstance(ref, RegisteredArtifact):
            return ref.ref
        return ref

    def _coerce_input_artifact_ids(
        self,
        refs: list[ArtifactRef | RegisteredArtifact] | None,
    ) -> list[str]:
        return [str(self._coerce_artifact_ref(ref).artifact_id) for ref in (refs or [])]

    def _calculate_hash(self, path: Path) -> str:
        """Calculate SHA256 hash of a file."""
        sha256 = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    def _is_uri_source(self, source: object) -> bool:
        if not isinstance(source, (str, Path)):
            return False
        if isinstance(source, Path):
            return False
        parsed = urlparse(source)
        return bool(parsed.scheme)

    def _is_local_path_source(self, source: object) -> bool:
        return isinstance(source, (str, Path)) and not self._is_uri_source(source)

    def _normalize_external_uri(self, uri: str | Path) -> str:
        """Normalize external artifact inputs into a URI string."""
        if isinstance(uri, Path):
            return f"file://{uri.absolute()}"
        uri_text = str(uri)
        parsed = urlparse(uri_text)
        if parsed.scheme:
            return uri_text
        return f"file://{Path(uri_text).absolute()}"

    def _parse_storage_ref(self, storage_ref: str) -> tuple[str, str]:
        parsed = urlparse(storage_ref)
        scheme = parsed.scheme or "local"
        if scheme == "file":
            path = parsed.path
        else:
            path = f"{parsed.netloc}{parsed.path}" if parsed.netloc else parsed.path
        return scheme, path


class BlockContext:
    """Context provided to blocks during execution.

    Inputs are upstream outputs loaded into memory for the current block
    process, plus any upstream ``ArtifactRef`` pointers that should remain
    explicit references.

    Access inputs via ctx.inputs["name"] (transparently unwraps OutputHandles).
    Access secrets via ctx.secrets["KEY"] (resolved by daemon at runtime).
    """

    def __init__(
        self,
        run_id: UUID | None = None,
        step_id: str | None = None,
        lab_id: UUID | None = None,
        inputs: dict[str, OutputHandle[Any]] | None = None,
        config: dict[str, Any] | None = None,
        secrets: dict[str, str] | None = None,
    ) -> None:
        self.run_id = run_id
        self.step_id = step_id
        self.lab_id = lab_id
        # _raw_inputs preserves the original input objects for internal access.
        self._raw_inputs: dict[str, Any] = inputs or {}
        # inputs transparently unwraps OutputHandles so blocks see raw values
        self.inputs: _InputsProxy = _InputsProxy(self._raw_inputs)
        self.config = config or {}
        self.secrets: dict[str, str] = secrets or {}

        # Configure error handling for event emission
        # Set ATHENA_FAIL_ON_EVENT_ERROR=true to fail blocks when event emission fails
        self._fail_on_event_error = (
            os.environ.get("ATHENA_FAIL_ON_EVENT_ERROR", "").lower() == "true"
        )

        # Block API is required - blocks must run through the daemon
        self._block_api_url = os.environ.get(ATHENA_BLOCK_API_ENV)
        if not self._block_api_url:
            raise RuntimeError(
                f"Block API URL not configured. Set {ATHENA_BLOCK_API_ENV} environment variable. "
                "Blocks must run through the daemon (athena sync)."
            )
        self._block_api_client = httpx.AsyncClient(timeout=30.0)
        logger.debug("Using Block API at %s", self._block_api_url)

        # Artifact manager
        self.artifacts = ArtifactManager(self)

    async def emit_metric(
        self,
        name: str,
        value: float,
        epoch: int | None = None,
        step: int | None = None,
        **labels: Any,
    ) -> None:
        """Emit a metric event."""
        payload = {
            "value": value,
            "epoch": epoch,
            "step": step,
            "labels": labels,
        }
        await self.emit_event("metric", name, payload)

    async def emit_progress(
        self,
        current: int,
        total: int,
        message: str | None = None,
    ) -> None:
        """Emit a progress event."""
        payload = {
            "current": current,
            "total": total,
            "message": message,
        }
        await self.emit_event("progress", None, payload)

    async def emit_event(
        self,
        event_type: str,
        event_name: str | None,
        payload: dict[str, Any],
    ) -> None:
        """Emit a generic event (buffered via Block API)."""
        # Sanitize event_name (replace spaces etc. with underscores)
        if event_name is not None:
            event_name = _EVENT_NAME_RE.sub("_", event_name)
        event_data = {
            "run_id": str(self.run_id) if self.run_id else None,
            "node_id": self.step_id,
            "event_type": event_type,
            "event_name": event_name,
            "payload": payload,
        }

        try:
            response = await self._block_api_client.post(
                f"{self._block_api_url}/api/events", json=event_data
            )
            response.raise_for_status()
        except httpx.HTTPError as e:
            logger.warning("Failed to emit event: %s", e)
            if self._fail_on_event_error:
                raise

    async def check_pause(self) -> bool:
        """Check if the run should be paused or this node is held (cooperative pause point).

        When the run is paused or the node is held, the Block API holds the
        response open until the run resumes / node is released, so this call
        blocks during pause. Returns True if the run is paused or the node is
        held, False otherwise.
        """
        if not self.run_id:
            return False

        try:
            url = f"{self._block_api_url}/api/runs/{self.run_id}/status"
            if self.step_id:
                url += f"?node_id={self.step_id}"
            response = await self._block_api_client.get(
                url,
                timeout=httpx.Timeout(timeout=None),  # Block API controls the wait
            )
            response.raise_for_status()
            data = response.json()
            return data.get("status") == "paused" or data.get("node_held", False)
        except httpx.HTTPError:
            return False

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._block_api_client.aclose()

    async def __aenter__(self) -> BlockContext:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
