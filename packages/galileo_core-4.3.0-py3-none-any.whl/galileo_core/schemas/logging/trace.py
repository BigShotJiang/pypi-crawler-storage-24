from typing import Literal, Optional

from pydantic import Field

from galileo_core.schemas.logging.span import (
    Span,  # noqa: F401  # to solve forward reference issues
    StepWithChildSpans,
)
from galileo_core.schemas.logging.step import (
    BaseStep,
    StepType,
    TextOrContentParts,
)


class BaseTrace(BaseStep):
    type: Literal[StepType.trace] = Field(
        default=StepType.trace, description=BaseStep.model_fields["type"].description
    )
    input: TextOrContentParts = Field(
        default="",
        description=BaseStep.model_fields["input"].description,
        union_mode="left_to_right",
    )
    redacted_input: Optional[TextOrContentParts] = Field(
        default=None,
        description=BaseStep.model_fields["redacted_input"].description,
        union_mode="left_to_right",
    )
    output: Optional[TextOrContentParts] = Field(
        default=None,
        description=BaseStep.model_fields["output"].description,
        union_mode="left_to_right",
    )
    redacted_output: Optional[TextOrContentParts] = Field(
        default=None,
        description=BaseStep.model_fields["redacted_output"].description,
        union_mode="left_to_right",
    )


class Trace(BaseTrace, StepWithChildSpans):
    pass
