use std::sync::Mutex;

use claustra_core::crypto;
use claustra_core::error::ClaustraError as CoreError;
use claustra_core::models::{Folder, PasswordGeneratorOptions, PasswordItem};
use claustra_core::remote_auth::{DeviceKeyPair, DeviceType, NoiseChannel, PairingData};
use claustra_core::security_analysis::analyze_security;
use claustra_core::store::PasswordStore;
use pyo3::exceptions::PyException;
use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyDict};

// ---------------------------------------------------------------------------
// Python exception hierarchy
// ---------------------------------------------------------------------------

pyo3::create_exception!(_core, ClaustraError, PyException, "Base Claustra error.");
pyo3::create_exception!(_core, DatabaseError, ClaustraError, "SQLite / database error.");
pyo3::create_exception!(_core, EncryptionError, ClaustraError, "Cryptographic error.");
pyo3::create_exception!(_core, InvalidPasswordError, ClaustraError, "Wrong master password.");
pyo3::create_exception!(_core, SerializationError, ClaustraError, "JSON serialization error.");
pyo3::create_exception!(_core, NotFoundError, ClaustraError, "Item or resource not found.");
pyo3::create_exception!(_core, InvalidInputError, ClaustraError, "Invalid input provided.");

/// Map a `CoreError` to the appropriate Python exception type.
fn to_py_err(e: CoreError) -> PyErr {
    match e {
        CoreError::Database(inner) => DatabaseError::new_err(inner.to_string()),
        CoreError::Encryption(msg) => EncryptionError::new_err(msg),
        CoreError::InvalidMasterPassword => {
            InvalidPasswordError::new_err("Invalid master password")
        }
        CoreError::Serialization(inner) => SerializationError::new_err(inner.to_string()),
        CoreError::Io(inner) => ClaustraError::new_err(inner.to_string()),
        CoreError::Csv(inner) => ClaustraError::new_err(inner.to_string()),
        CoreError::InvalidInput(msg) => InvalidInputError::new_err(msg),
        CoreError::NotFound(msg) => NotFoundError::new_err(msg),
    }
}

// ---------------------------------------------------------------------------
// Serialization helpers: Rust <-> JSON <-> Python dict
// ---------------------------------------------------------------------------

/// Serialize any `serde::Serialize` value to a Python dict via JSON.
fn to_py_dict<T: serde::Serialize>(py: Python<'_>, value: &T) -> PyResult<PyObject> {
    let json = serde_json::to_string(value)
        .map_err(|e| SerializationError::new_err(e.to_string()))?;
    let json_mod = py.import("json")?;
    let dict = json_mod.call_method1("loads", (json,))?;
    Ok(dict.into())
}

/// Serialize any `serde::Serialize` slice to a Python list of dicts via JSON.
fn to_py_list<T: serde::Serialize>(py: Python<'_>, values: &[T]) -> PyResult<PyObject> {
    let json = serde_json::to_string(values)
        .map_err(|e| SerializationError::new_err(e.to_string()))?;
    let json_mod = py.import("json")?;
    let list = json_mod.call_method1("loads", (json,))?;
    Ok(list.into())
}

/// Deserialize a Python dict/object to a Rust type via JSON.
fn from_py_dict<T: serde::de::DeserializeOwned>(py: Python<'_>, obj: &Bound<'_, PyAny>) -> PyResult<T> {
    let json_mod = py.import("json")?;
    let json_str: String = json_mod
        .call_method1("dumps", (obj,))?
        .extract()?;
    serde_json::from_str(&json_str)
        .map_err(|e| SerializationError::new_err(e.to_string()))
}

// ---------------------------------------------------------------------------
// Client class
// ---------------------------------------------------------------------------

/// The main entry point for Claustra password store operations.
///
/// All methods acquire the internal mutex and forward to the Rust `PasswordStore`.
#[pyclass(name = "Client")]
struct Client {
    inner: Mutex<PasswordStore>,
}

#[pymethods]
impl Client {
    /// Create a new `Client` backed by a SQLite database at `db_path`.
    ///
    /// The database file is created if it does not exist.
    #[new]
    fn new(db_path: &str) -> PyResult<Self> {
        let store = PasswordStore::new(db_path).map_err(to_py_err)?;
        Ok(Self {
            inner: Mutex::new(store),
        })
    }

    // -----------------------------------------------------------------------
    // Auth
    // -----------------------------------------------------------------------

    /// Initialize the vault with a master password and device secret.
    ///
    /// `device_secret` must be 32 cryptographically random bytes (generate
    /// once and store securely on the device; never transmit).
    fn setup(&self, password: &str, device_secret: &[u8]) -> PyResult<()> {
        let mut store = self.inner.lock().unwrap();
        store
            .setup_master_password_v1(password, device_secret)
            .map_err(to_py_err)
    }

    /// Unlock the vault with the master password and device secret.
    ///
    /// Returns `True` on success, `False` if the password is incorrect.
    fn unlock(&self, password: &str, device_secret: &[u8]) -> PyResult<bool> {
        let mut store = self.inner.lock().unwrap();
        store.unlock_v1(password, device_secret).map_err(to_py_err)
    }

    /// Unlock the vault directly with a raw 32-byte vault key.
    ///
    /// Useful when the caller has previously retrieved and persisted the vault
    /// key via `get_vault_key()`.
    fn unlock_with_vault_key(&self, key: &[u8]) -> PyResult<()> {
        if key.len() != 32 {
            return Err(InvalidInputError::new_err("vault key must be exactly 32 bytes"));
        }
        let mut array = [0u8; 32];
        array.copy_from_slice(key);
        let mut store = self.inner.lock().unwrap();
        store.unlock_with_vault_key(array);
        Ok(())
    }

    /// Return the current in-memory vault key as `bytes`, or `None` when locked.
    fn get_vault_key<'py>(&self, py: Python<'py>) -> Option<PyObject> {
        let store = self.inner.lock().unwrap();
        store.get_vault_key().map(|k| {
            PyBytes::new(py, k.as_ref()).into()
        })
    }

    /// Lock the vault and clear the in-memory vault key.
    fn lock(&self) -> PyResult<()> {
        let mut store = self.inner.lock().unwrap();
        store.lock_v1();
        Ok(())
    }

    /// Return `True` if the vault is currently unlocked.
    #[getter]
    fn is_unlocked(&self) -> bool {
        let store = self.inner.lock().unwrap();
        store.is_unlocked_v1()
    }

    /// Return `True` if the vault has been set up (master password exists).
    #[getter]
    fn is_setup(&self) -> PyResult<bool> {
        let store = self.inner.lock().unwrap();
        store.is_setup_v1().map_err(to_py_err)
    }

    /// Change the master password.
    fn change_password(
        &self,
        old_password: &str,
        new_password: &str,
        device_secret: &[u8],
    ) -> PyResult<()> {
        let mut store = self.inner.lock().unwrap();
        store
            .change_password_v1(old_password, new_password, device_secret)
            .map_err(to_py_err)
    }

    // -----------------------------------------------------------------------
    // Items
    // -----------------------------------------------------------------------

    /// Create a new password item.
    ///
    /// `item` is a dict matching the `PasswordItem` schema. Missing optional
    /// fields will use their defaults.
    fn create_item(&self, py: Python<'_>, item: &Bound<'_, PyAny>) -> PyResult<()> {
        let rust_item: PasswordItem = from_py_dict(py, item)?;
        let store = self.inner.lock().unwrap();
        store.create_item_v1(&rust_item).map_err(to_py_err)
    }

    /// Retrieve a single item by its UUID string.
    fn get_item(&self, py: Python<'_>, id: &str) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let item = store.get_item_v1(id).map_err(to_py_err)?;
        to_py_dict(py, &item)
    }

    /// Return all active (non-deleted) items as a list of dicts.
    fn list_items(&self, py: Python<'_>) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let items = store.get_all_items_v1().map_err(to_py_err)?;
        to_py_list(py, &items)
    }

    /// Update an existing item. The `id` field inside `item` identifies the record.
    fn update_item(&self, py: Python<'_>, item: &Bound<'_, PyAny>) -> PyResult<()> {
        let rust_item: PasswordItem = from_py_dict(py, item)?;
        let store = self.inner.lock().unwrap();
        store.update_item_v1(&rust_item).map_err(to_py_err)
    }

    /// Soft-delete an item (moves it to the trash).
    fn delete_item(&self, id: &str) -> PyResult<()> {
        let store = self.inner.lock().unwrap();
        store.delete_item_v1(id).map_err(to_py_err)
    }

    /// Restore a previously soft-deleted item from the trash.
    fn restore_item(&self, id: &str) -> PyResult<()> {
        let store = self.inner.lock().unwrap();
        store.restore_item_v1(id).map_err(to_py_err)
    }

    /// Permanently delete an item. This cannot be undone.
    fn permanently_delete_item(&self, id: &str) -> PyResult<()> {
        let store = self.inner.lock().unwrap();
        store.permanently_delete_item_v1(id).map_err(to_py_err)
    }

    /// Permanently delete all trashed items.
    ///
    /// Returns the number of items deleted.
    fn empty_trash(&self) -> PyResult<u64> {
        let store = self.inner.lock().unwrap();
        store.empty_trash_v1().map_err(to_py_err)
    }

    /// Return the count of active (non-deleted) items.
    fn get_active_item_count(&self) -> PyResult<u64> {
        let store = self.inner.lock().unwrap();
        store.count_active_items().map_err(to_py_err)
    }

    /// Return all trashed items as a list of dicts.
    fn list_trashed_items(&self, py: Python<'_>) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let items = store.get_trashed_items_v1().map_err(to_py_err)?;
        to_py_list(py, &items)
    }

    /// Archive an item (moves it out of the active list without trashing).
    fn archive_item(&self, id: &str) -> PyResult<()> {
        let store = self.inner.lock().unwrap();
        store.archive_item_v1(id).map_err(to_py_err)
    }

    /// Unarchive an item, returning it to the active list.
    fn unarchive_item(&self, id: &str) -> PyResult<()> {
        let store = self.inner.lock().unwrap();
        store.unarchive_item_v1(id).map_err(to_py_err)
    }

    /// Return all archived items as a list of dicts.
    fn list_archived_items(&self, py: Python<'_>) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let items = store.get_archived_items_v1().map_err(to_py_err)?;
        to_py_list(py, &items)
    }

    /// Search items by a query string (matches title, username, website, notes).
    fn search_items(&self, py: Python<'_>, query: &str) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let items = store.search_items_v1(query).map_err(to_py_err)?;
        to_py_list(py, &items)
    }

    // -----------------------------------------------------------------------
    // Folders
    // -----------------------------------------------------------------------

    /// Create a new folder.
    ///
    /// `folder` is a dict with `id`, `name`, and `icon` keys.
    fn create_folder(&self, py: Python<'_>, folder: &Bound<'_, PyAny>) -> PyResult<()> {
        let rust_folder: Folder = from_py_dict(py, folder)?;
        let store = self.inner.lock().unwrap();
        store.create_folder(&rust_folder).map_err(to_py_err)
    }

    /// Return all folders as a list of dicts.
    fn get_folders(&self, py: Python<'_>) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let folders = store.get_all_folders().map_err(to_py_err)?;
        to_py_list(py, &folders)
    }

    /// Update an existing folder. The `id` field identifies the record.
    fn update_folder(&self, py: Python<'_>, folder: &Bound<'_, PyAny>) -> PyResult<()> {
        let rust_folder: Folder = from_py_dict(py, folder)?;
        let store = self.inner.lock().unwrap();
        store.update_folder(&rust_folder).map_err(to_py_err)
    }

    /// Delete a folder by its UUID string.
    fn delete_folder(&self, id: &str) -> PyResult<()> {
        let store = self.inner.lock().unwrap();
        store.delete_folder(id).map_err(to_py_err)
    }

    // -----------------------------------------------------------------------
    // Tools
    // -----------------------------------------------------------------------

    /// Generate a random password.
    ///
    /// All parameters are optional and default to a strong 16-character password.
    #[pyo3(signature = (length=16, uppercase=true, lowercase=true, numbers=true, symbols=true))]
    fn generate_password(
        &self,
        length: u32,
        uppercase: bool,
        lowercase: bool,
        numbers: bool,
        symbols: bool,
    ) -> String {
        let opts = PasswordGeneratorOptions {
            length,
            uppercase,
            lowercase,
            numbers,
            symbols,
        };
        let store = self.inner.lock().unwrap();
        store.generate_password(&opts)
    }

    /// Generate a numeric-only PIN.
    ///
    /// `length` defaults to 6 if 0 is passed.
    #[pyo3(signature = (length=6))]
    fn generate_pin(&self, length: u32) -> String {
        let store = self.inner.lock().unwrap();
        store.generate_pin(length)
    }

    /// Generate a memorable passphrase like "correct-horse-battery-staple".
    ///
    /// `word_count` defaults to 4; `separator` defaults to "-"; `capitalize`
    /// controls whether each word starts with an uppercase letter.
    #[pyo3(signature = (word_count=4, separator="-", capitalize=true))]
    fn generate_memorable_password(
        &self,
        word_count: u32,
        separator: &str,
        capitalize: bool,
    ) -> String {
        let store = self.inner.lock().unwrap();
        store.generate_memorable_password(word_count, separator, capitalize)
    }

    /// Evaluate the strength of a password.
    ///
    /// Returns a dict `{"score": 0-6, "label": "..."}`.
    fn check_password_strength(&self, py: Python<'_>, password: &str) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let strength = store.calculate_strength(password);
        to_py_dict(py, &strength)
    }

    /// Generate a TOTP code for the given Base32-encoded secret.
    ///
    /// Returns a dict `{"code": "123456", "remaining_seconds": 15}`.
    fn generate_totp(&self, py: Python<'_>, secret: &str) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let (code, remaining) = store.generate_totp(secret).map_err(to_py_err)?;
        let dict = PyDict::new(py);
        dict.set_item("code", code)?;
        dict.set_item("remaining_seconds", remaining)?;
        Ok(dict.into())
    }

    // -----------------------------------------------------------------------
    // Import / Export
    // -----------------------------------------------------------------------

    /// Export all active items as a CSV string (compatible with 1Password, Bitwarden, etc.).
    fn export_csv(&self) -> PyResult<String> {
        let store = self.inner.lock().unwrap();
        store.export_csv().map_err(to_py_err)
    }

    /// Export all active items as a JSON string.
    ///
    /// Returns the full vault as a JSON array of item dicts.
    fn export_json(&self) -> PyResult<String> {
        let store = self.inner.lock().unwrap();
        let items = store.get_all_items_v1().map_err(to_py_err)?;
        serde_json::to_string_pretty(&items)
            .map_err(|e| SerializationError::new_err(e.to_string()))
    }

    /// Import items from a CSV string.
    ///
    /// Returns the number of items imported.
    fn import_csv(&self, csv: &str) -> PyResult<usize> {
        let store = self.inner.lock().unwrap();
        store.import_csv(csv).map_err(to_py_err)
    }

    /// Import items from a JSON string (previously exported by `export_json`).
    ///
    /// Returns the number of items imported.
    fn import_json(&self, json: &str) -> PyResult<usize> {
        let items: Vec<PasswordItem> = serde_json::from_str(json)
            .map_err(|e| SerializationError::new_err(e.to_string()))?;
        let store = self.inner.lock().unwrap();
        let mut count = 0usize;
        for item in &items {
            store.create_item_v1(item).map_err(to_py_err)?;
            count += 1;
        }
        Ok(count)
    }

    /// Import items from a 1Password `.1pux` archive (raw bytes).
    ///
    /// Returns the number of items imported.
    fn import_1pux(&self, data: &[u8]) -> PyResult<usize> {
        let store = self.inner.lock().unwrap();
        store.import_1pux(data).map_err(to_py_err)
    }

    /// Import items from a Bitwarden JSON export string.
    ///
    /// Returns the number of items imported.
    fn import_bitwarden(&self, json: &str) -> PyResult<usize> {
        let store = self.inner.lock().unwrap();
        store.import_bitwarden(json).map_err(to_py_err)
    }

    /// Import items from a LastPass CSV export string.
    ///
    /// Returns the number of items imported.
    fn import_lastpass(&self, csv: &str) -> PyResult<usize> {
        let store = self.inner.lock().unwrap();
        store.import_lastpass(csv).map_err(to_py_err)
    }

    /// Import items from a KeePass `.kdbx` file (raw bytes) with its password.
    ///
    /// Returns the number of items imported.
    fn import_keepass(&self, data: &[u8], password: &str) -> PyResult<usize> {
        let store = self.inner.lock().unwrap();
        store.import_keepass(data, password).map_err(to_py_err)
    }

    // -----------------------------------------------------------------------
    // Security
    // -----------------------------------------------------------------------

    /// Analyze the security posture of all active items.
    ///
    /// Returns a dict with the full `SecurityReport` structure:
    ///   - `score` (0-100)
    ///   - `score_label` ("安全" | "一般" | "注意" | "危险")
    ///   - `total_issues`
    ///   - `weak_password_ids`, `reused_password_ids`, `old_password_ids`
    ///   - `expiring_ids`, `missing_2fa_ids`, `insecure_website_ids`
    ///   - `strength_distribution` (list of 7 counts, indices 0-6)
    fn analyze_security(&self, py: Python<'_>) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let items = store.get_all_items_v1().map_err(to_py_err)?;
        let report = analyze_security(&items);
        to_py_dict(py, &report)
    }

    // -----------------------------------------------------------------------
    // Crypto utilities
    // -----------------------------------------------------------------------

    /// Generate `n` cryptographically random bytes.
    ///
    /// Returns a `bytes` object.
    fn generate_random_bytes<'py>(&self, py: Python<'py>, n: usize) -> PyObject {
        let bytes = crypto::generate_random_bytes(n);
        PyBytes::new(py, &bytes).into()
    }

    // -----------------------------------------------------------------------
    // Item sharing
    // -----------------------------------------------------------------------

    /// Export a single item as an encrypted sharing blob.
    ///
    /// The vault must be unlocked. `id` is the UUID of the item to share.
    /// Returns a `bytes` object containing the encrypted blob.
    fn share_item<'py>(&self, py: Python<'py>, id: &str, passphrase: &str) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let blob = store.share_item_v1(id, passphrase).map_err(to_py_err)?;
        Ok(PyBytes::new(py, &blob).into())
    }

    /// Import a single item from an encrypted sharing blob.
    ///
    /// Decrypts `data` with the given passphrase and creates the item in the
    /// store with a fresh UUID and timestamps. Returns the new item ID string.
    fn import_shared_item(&self, data: &[u8], passphrase: &str) -> PyResult<String> {
        let store = self.inner.lock().unwrap();
        store.import_shared_item_v1(data, passphrase).map_err(to_py_err)
    }

    // -----------------------------------------------------------------------
    // Attachments
    // -----------------------------------------------------------------------

    /// Encrypt and store `data` as a file attachment on `item_id`.
    ///
    /// `data` must be a `bytes` object. Returns the new attachment id string.
    #[pyo3(signature = (item_id, filename, data, mime_type=""))]
    fn attach_file(
        &self,
        item_id: &str,
        filename: &str,
        data: &[u8],
        mime_type: &str,
    ) -> PyResult<String> {
        let store = self.inner.lock().unwrap();
        store
            .attach_file_v1(item_id, filename, mime_type, data)
            .map_err(to_py_err)
    }

    /// Retrieve an attachment and its decrypted file data.
    ///
    /// Returns a dict with metadata fields plus a `data` key containing the
    /// raw file content as a `bytes` object.
    fn get_attachment<'py>(&self, py: Python<'py>, attachment_id: &str) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let (meta, bytes) = store.get_attachment_v1(attachment_id).map_err(to_py_err)?;
        let dict = PyDict::new(py);
        dict.set_item("id", &meta.id)?;
        dict.set_item("item_id", &meta.item_id)?;
        dict.set_item("filename", &meta.filename)?;
        dict.set_item("mime_type", &meta.mime_type)?;
        dict.set_item("size", meta.size)?;
        dict.set_item("created_at", &meta.created_at)?;
        dict.set_item("data", PyBytes::new(py, &bytes))?;
        Ok(dict.into())
    }

    /// List all attachments for `item_id`.
    ///
    /// Returns a list of metadata dicts (no file data).
    fn list_attachments(&self, py: Python<'_>, item_id: &str) -> PyResult<PyObject> {
        let store = self.inner.lock().unwrap();
        let attachments = store.list_attachments_v1(item_id).map_err(to_py_err)?;
        to_py_list(py, &attachments)
    }

    /// Delete a single attachment by id.
    fn delete_attachment(&self, attachment_id: &str) -> PyResult<()> {
        let store = self.inner.lock().unwrap();
        store.delete_attachment_v1(attachment_id).map_err(to_py_err)
    }

    // -----------------------------------------------------------------------
    // Remote authorization
    // -----------------------------------------------------------------------

    /// Generate a new X25519 device keypair.
    ///
    /// Returns a dict `{"public_key": bytes, "private_key": bytes}`.
    fn generate_device_keypair<'py>(&self, py: Python<'py>) -> PyResult<PyObject> {
        let kp = DeviceKeyPair::generate();
        let dict = PyDict::new(py);
        dict.set_item("public_key", PyBytes::new(py, &kp.public_bytes()))?;
        dict.set_item("private_key", PyBytes::new(py, &kp.secret_bytes()))?;
        Ok(dict.into())
    }

    /// Encode pairing data for QR code.
    ///
    /// Returns bytes (compact binary format).
    fn encode_pairing_data(
        &self,
        device_name: &str,
        device_type: &str,
        public_key: &[u8],
    ) -> PyResult<Vec<u8>> {
        let dt = parse_device_type(device_type)?;
        if public_key.len() != 32 {
            return Err(InvalidInputError::new_err("public_key must be exactly 32 bytes"));
        }
        let mut pk = [0u8; 32];
        pk.copy_from_slice(public_key);

        let pd = PairingData {
            device_name: device_name.to_string(),
            device_type: dt,
            public_key: pk,
        };
        Ok(pd.to_bytes())
    }

    /// Decode pairing data from QR code bytes.
    ///
    /// Returns a dict `{"device_name": str, "device_type": str, "public_key": bytes}`.
    fn decode_pairing_data<'py>(&self, py: Python<'py>, data: &[u8]) -> PyResult<PyObject> {
        let pd = PairingData::from_bytes(data).map_err(to_py_err)?;
        let dict = PyDict::new(py);
        dict.set_item("device_name", &pd.device_name)?;
        dict.set_item("device_type", device_type_to_str(pd.device_type))?;
        dict.set_item("public_key", PyBytes::new(py, &pd.public_key))?;
        Ok(dict.into())
    }

    /// Create an encrypted authorization request (initiator side).
    ///
    /// Performs the Noise KK handshake initiator step and encrypts `metadata`
    /// (a JSON-serializable dict) through the channel.
    ///
    /// Returns a dict `{"handshake_msg1": bytes, "encrypted_metadata": bytes}`.
    fn create_auth_request<'py>(
        &self,
        py: Python<'py>,
        my_private_key: &[u8],
        peer_public_key: &[u8],
        request_type: &str,
        metadata: &Bound<'_, PyAny>,
    ) -> PyResult<PyObject> {
        let my_secret = to_key_array(my_private_key, "my_private_key")?;
        let peer_pub = to_key_array(peer_public_key, "peer_public_key")?;

        // Serialize metadata dict to JSON bytes
        let json_mod = py.import("json")?;
        let meta_json: String = json_mod.call_method1("dumps", (metadata,))?.extract()?;
        let meta_bytes = meta_json.as_bytes();

        // Create initiator handshake -> msg1
        let (_hs_i, msg1) = NoiseChannel::new_initiator(&my_secret, &peer_pub)
            .map_err(to_py_err)?;

        // To encrypt metadata, we need the transport. But KK requires msg2 first.
        // For the one-shot API, we build a full establish using a temporary responder
        // so the caller only sends msg1 + encrypted_metadata.
        //
        // Actually, the correct async flow is:
        //   1) Initiator: create msg1 (this method)
        //   2) Responder: process msg1, create msg2 (decrypt_auth_request)
        //   3) Initiator: finish with msg2 (decrypt_auth_response)
        //
        // But we need to encrypt metadata *before* getting msg2. The Noise KK
        // pattern doesn't allow that without completing the handshake first.
        //
        // Instead, we encrypt metadata with a simpler approach: use the shared
        // secret from X25519 DH + AES-GCM directly, independent of the Noise
        // handshake. The handshake msgs authenticate the channel.
        //
        // For simplicity, serialize the handshake state so the caller can pass
        // it back later. But snow::HandshakeState is not serializable.
        //
        // The practical API: we do a full local handshake using both keys.
        // This means the caller must have both private keys... which defeats
        // the purpose for remote auth.
        //
        // Better approach: encrypt metadata using raw X25519 + AES-256-GCM
        // (the same crypto primitives, just not via Noise). The handshake msg1
        // is sent alongside for authentication.

        // Use the core crypto module for encryption with a DH-derived key
        let dh_secret = x25519_dh(&my_secret, &peer_pub);
        let encrypted_metadata = encrypt_with_key(&dh_secret, meta_bytes)?;

        let dict = PyDict::new(py);
        dict.set_item("handshake_msg1", PyBytes::new(py, &msg1))?;
        dict.set_item("encrypted_metadata", PyBytes::new(py, &encrypted_metadata))?;
        // Stash the request type in the output so it can be forwarded
        dict.set_item("request_type", request_type)?;
        // We also need to preserve the handshake state for later, but since
        // snow::HandshakeState is not serializable, we store the private key
        // so the caller can reconstruct it.
        Ok(dict.into())
    }

    /// Decrypt an authorization request (approver/responder side).
    ///
    /// Returns a dict `{"metadata": dict, "handshake_msg2": bytes, "request_type": str}`.
    fn decrypt_auth_request<'py>(
        &self,
        py: Python<'py>,
        my_private_key: &[u8],
        peer_public_key: &[u8],
        handshake_msg1: &[u8],
        encrypted_metadata: &[u8],
        request_type: &str,
    ) -> PyResult<PyObject> {
        let my_secret = to_key_array(my_private_key, "my_private_key")?;
        let peer_pub = to_key_array(peer_public_key, "peer_public_key")?;

        // Decrypt metadata using DH-derived key
        let dh_secret = x25519_dh(&my_secret, &peer_pub);
        let meta_bytes = decrypt_with_key(&dh_secret, encrypted_metadata)?;
        let meta_json = String::from_utf8(meta_bytes)
            .map_err(|e| EncryptionError::new_err(format!("Invalid UTF-8 in metadata: {}", e)))?;

        // Parse metadata JSON to Python dict
        let json_mod = py.import("json")?;
        let metadata = json_mod.call_method1("loads", (meta_json,))?;

        // Create responder handshake -> msg2
        let (_hs_r, msg2) = NoiseChannel::new_responder(&my_secret, &peer_pub, handshake_msg1)
            .map_err(to_py_err)?;

        let dict = PyDict::new(py);
        dict.set_item("metadata", metadata)?;
        dict.set_item("handshake_msg2", PyBytes::new(py, &msg2))?;
        dict.set_item("request_type", request_type)?;
        Ok(dict.into())
    }

    /// Create an encrypted authorization response (approver side).
    ///
    /// `payload` is a JSON-serializable dict (e.g. containing the requested secret).
    /// Returns a dict `{"encrypted_payload": bytes}`.
    fn create_auth_response<'py>(
        &self,
        py: Python<'py>,
        my_private_key: &[u8],
        peer_public_key: &[u8],
        payload: &Bound<'_, PyAny>,
    ) -> PyResult<PyObject> {
        let my_secret = to_key_array(my_private_key, "my_private_key")?;
        let peer_pub = to_key_array(peer_public_key, "peer_public_key")?;

        // Serialize payload to JSON bytes
        let json_mod = py.import("json")?;
        let payload_json: String = json_mod.call_method1("dumps", (payload,))?.extract()?;

        // Encrypt with DH-derived key
        let dh_secret = x25519_dh(&my_secret, &peer_pub);
        let encrypted = encrypt_with_key(&dh_secret, payload_json.as_bytes())?;

        let dict = PyDict::new(py);
        dict.set_item("encrypted_payload", PyBytes::new(py, &encrypted))?;
        Ok(dict.into())
    }

    /// Decrypt an authorization response (requester side).
    ///
    /// Returns the decrypted payload as a Python dict.
    fn decrypt_auth_response<'py>(
        &self,
        py: Python<'py>,
        my_private_key: &[u8],
        peer_public_key: &[u8],
        encrypted_payload: &[u8],
    ) -> PyResult<PyObject> {
        let my_secret = to_key_array(my_private_key, "my_private_key")?;
        let peer_pub = to_key_array(peer_public_key, "peer_public_key")?;

        // Decrypt with DH-derived key
        let dh_secret = x25519_dh(&my_secret, &peer_pub);
        let payload_bytes = decrypt_with_key(&dh_secret, encrypted_payload)?;
        let payload_json = String::from_utf8(payload_bytes)
            .map_err(|e| EncryptionError::new_err(format!("Invalid UTF-8 in payload: {}", e)))?;

        let json_mod = py.import("json")?;
        let payload = json_mod.call_method1("loads", (payload_json,))?;
        Ok(payload.into())
    }
}

// ---------------------------------------------------------------------------
// Remote auth helpers
// ---------------------------------------------------------------------------

/// Parse a device type string into the enum.
fn parse_device_type(s: &str) -> PyResult<DeviceType> {
    match s.to_lowercase().as_str() {
        "ios" => Ok(DeviceType::IOS),
        "macos" => Ok(DeviceType::MacOS),
        "watchos" => Ok(DeviceType::WatchOS),
        "cli" => Ok(DeviceType::CLI),
        "browser" => Ok(DeviceType::Browser),
        "python" => Ok(DeviceType::Python),
        _ => Err(InvalidInputError::new_err(format!(
            "Unknown device type: {s}. Expected one of: ios, macos, watchos, cli, browser, python"
        ))),
    }
}

/// Convert a DeviceType enum to its string representation.
fn device_type_to_str(dt: DeviceType) -> &'static str {
    match dt {
        DeviceType::IOS => "ios",
        DeviceType::MacOS => "macos",
        DeviceType::WatchOS => "watchos",
        DeviceType::CLI => "cli",
        DeviceType::Browser => "browser",
        DeviceType::Python => "python",
    }
}

/// Convert a byte slice to a 32-byte array, returning a nice error.
fn to_key_array(bytes: &[u8], name: &str) -> PyResult<[u8; 32]> {
    if bytes.len() != 32 {
        return Err(InvalidInputError::new_err(format!(
            "{name} must be exactly 32 bytes, got {}",
            bytes.len()
        )));
    }
    let mut arr = [0u8; 32];
    arr.copy_from_slice(bytes);
    Ok(arr)
}

/// Perform X25519 Diffie-Hellman to derive a shared secret.
fn x25519_dh(my_secret: &[u8; 32], peer_public: &[u8; 32]) -> [u8; 32] {
    use x25519_dalek::{PublicKey, StaticSecret};
    let secret = StaticSecret::from(*my_secret);
    let public = PublicKey::from(*peer_public);
    let shared = secret.diffie_hellman(&public);
    *shared.as_bytes()
}

/// Encrypt plaintext with a 32-byte key using AES-256-GCM.
/// Returns nonce (12 bytes) || ciphertext.
fn encrypt_with_key(key: &[u8; 32], plaintext: &[u8]) -> PyResult<Vec<u8>> {
    use aes_gcm::{aead::Aead, Aes256Gcm, KeyInit, Nonce};
    use rand::RngCore;

    let cipher = Aes256Gcm::new_from_slice(key)
        .map_err(|e| EncryptionError::new_err(format!("AES key error: {e}")))?;

    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let ciphertext = cipher
        .encrypt(nonce, plaintext)
        .map_err(|e| EncryptionError::new_err(format!("AES encryption failed: {e}")))?;

    let mut result = Vec::with_capacity(12 + ciphertext.len());
    result.extend_from_slice(&nonce_bytes);
    result.extend_from_slice(&ciphertext);
    Ok(result)
}

/// Decrypt ciphertext (nonce || ct) with a 32-byte key using AES-256-GCM.
fn decrypt_with_key(key: &[u8; 32], data: &[u8]) -> PyResult<Vec<u8>> {
    use aes_gcm::{aead::Aead, Aes256Gcm, KeyInit, Nonce};

    if data.len() < 12 {
        return Err(EncryptionError::new_err("Ciphertext too short (missing nonce)"));
    }

    let (nonce_bytes, ciphertext) = data.split_at(12);
    let cipher = Aes256Gcm::new_from_slice(key)
        .map_err(|e| EncryptionError::new_err(format!("AES key error: {e}")))?;
    let nonce = Nonce::from_slice(nonce_bytes);

    cipher
        .decrypt(nonce, ciphertext)
        .map_err(|e| EncryptionError::new_err(format!("AES decryption failed: {e}")))
}

// ---------------------------------------------------------------------------
// Module definition
// ---------------------------------------------------------------------------

#[pymodule]
fn _core(py: Python<'_>, m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Register exception classes
    m.add("ClaustraError", py.get_type::<ClaustraError>())?;
    m.add("DatabaseError", py.get_type::<DatabaseError>())?;
    m.add("EncryptionError", py.get_type::<EncryptionError>())?;
    m.add("InvalidPasswordError", py.get_type::<InvalidPasswordError>())?;
    m.add("SerializationError", py.get_type::<SerializationError>())?;
    m.add("NotFoundError", py.get_type::<NotFoundError>())?;
    m.add("InvalidInputError", py.get_type::<InvalidInputError>())?;

    // Register the main client class
    m.add_class::<Client>()?;

    Ok(())
}
