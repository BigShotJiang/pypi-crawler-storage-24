"""Claustra — Python SDK for the Claustra password manager.

This module re-exports the native PyO3 exception types and provides a pure-Python
``Client`` wrapper that adds batch operations, secret URI resolution, advanced
filtering, context-manager support, environment variable injection, and a
multi-vault ``VaultManager`` helper.
"""

from __future__ import annotations

import os
from pathlib import Path

from claustra import _core
from claustra._core import (
    ClaustraError,
    DatabaseError,
    EncryptionError,
    InvalidPasswordError,
    SerializationError,
    NotFoundError,
    InvalidInputError,
)

__version__ = "0.1.0"

__all__ = [
    "Client",
    "VaultManager",
    "ClaustraError",
    "DatabaseError",
    "EncryptionError",
    "InvalidPasswordError",
    "SerializationError",
    "NotFoundError",
    "InvalidInputError",
    "__version__",
]

# ---------------------------------------------------------------------------
# URI scheme constant
# ---------------------------------------------------------------------------

_URI_SCHEME = "claustra://"


# ---------------------------------------------------------------------------
# Client wrapper
# ---------------------------------------------------------------------------


class Client:
    """Python wrapper around the native ``_core.Client``.

    All methods not explicitly defined here are transparently delegated to the
    underlying native client via ``__getattr__``.

    Parameters
    ----------
    db_path:
        Path to the SQLite vault file. The file is created if it does not exist.
    """

    def __init__(self, db_path: str) -> None:
        self._client = _core.Client(db_path)

    # ------------------------------------------------------------------
    # Transparent delegation to the native client
    # ------------------------------------------------------------------

    def __getattr__(self, name: str):
        # Only called when normal attribute lookup fails, so explicitly defined
        # methods on this class take precedence.
        return getattr(self._client, name)

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *args) -> None:
        """Lock the vault when leaving the ``with`` block."""
        self._client.lock()

    # ------------------------------------------------------------------
    # Explicit pass-throughs for IDE / type-checker friendliness
    # (these merely forward to the native client; __getattr__ covers the rest)
    # ------------------------------------------------------------------

    def setup(self, password: str, device_secret: bytes) -> None:
        """Initialize the vault with a master password and device secret."""
        return self._client.setup(password, device_secret)

    def unlock(self, password: str, device_secret: bytes) -> bool:
        """Unlock the vault. Returns ``True`` on success."""
        return self._client.unlock(password, device_secret)

    def unlock_with_vault_key(self, key: bytes) -> None:
        """Unlock the vault directly with a raw 32-byte vault key."""
        return self._client.unlock_with_vault_key(key)

    def get_vault_key(self) -> bytes | None:
        """Return the current in-memory vault key, or ``None`` when locked."""
        return self._client.get_vault_key()

    def lock(self) -> None:
        """Lock the vault and clear the in-memory vault key."""
        return self._client.lock()

    @property
    def is_unlocked(self) -> bool:
        """``True`` if the vault is currently unlocked."""
        return self._client.is_unlocked

    @property
    def is_setup(self) -> bool:
        """``True`` if the vault has been initialized with a master password."""
        return self._client.is_setup

    def change_password(
        self, old_password: str, new_password: str, device_secret: bytes
    ) -> None:
        """Change the master password."""
        return self._client.change_password(old_password, new_password, device_secret)

    def create_item(self, item: dict) -> None:
        """Create a new password item from a dict matching ``PasswordItem``."""
        return self._client.create_item(item)

    def get_item(self, id: str) -> dict:
        """Retrieve a single item by its UUID string."""
        return self._client.get_item(id)

    def list_items(self) -> list[dict]:
        """Return all active (non-deleted) items."""
        return self._client.list_items()

    def update_item(self, item: dict) -> None:
        """Update an existing item (identified by its ``id`` field)."""
        return self._client.update_item(item)

    def delete_item(self, id: str) -> None:
        """Soft-delete an item (moves it to the trash)."""
        return self._client.delete_item(id)

    def restore_item(self, id: str) -> None:
        """Restore a trashed item."""
        return self._client.restore_item(id)

    def permanently_delete_item(self, id: str) -> None:
        """Permanently delete an item. This cannot be undone."""
        return self._client.permanently_delete_item(id)

    def empty_trash(self) -> int:
        """Permanently delete all trashed items. Returns the count deleted."""
        return self._client.empty_trash()

    def get_active_item_count(self) -> int:
        """Return the count of active (non-deleted) items."""
        return self._client.get_active_item_count()

    def list_trashed_items(self) -> list[dict]:
        """Return all trashed items."""
        return self._client.list_trashed_items()

    def archive_item(self, id: str) -> None:
        """Archive an item (moves it out of the active list without trashing)."""
        return self._client.archive_item(id)

    def unarchive_item(self, id: str) -> None:
        """Unarchive an item, returning it to the active list."""
        return self._client.unarchive_item(id)

    def list_archived_items(self) -> list[dict]:
        """Return all archived items."""
        return self._client.list_archived_items()

    def search_items(self, query: str) -> list[dict]:
        """Search items by a query string."""
        return self._client.search_items(query)

    def create_folder(self, folder: dict) -> None:
        """Create a new folder."""
        return self._client.create_folder(folder)

    def get_folders(self) -> list[dict]:
        """Return all folders."""
        return self._client.get_folders()

    def update_folder(self, folder: dict) -> None:
        """Update an existing folder."""
        return self._client.update_folder(folder)

    def delete_folder(self, id: str) -> None:
        """Delete a folder by its UUID string."""
        return self._client.delete_folder(id)

    def generate_password(
        self,
        length: int = 16,
        uppercase: bool = True,
        lowercase: bool = True,
        numbers: bool = True,
        symbols: bool = True,
    ) -> str:
        """Generate a random password."""
        return self._client.generate_password(length, uppercase, lowercase, numbers, symbols)

    def generate_pin(self, length: int = 6) -> str:
        """Generate a numeric-only PIN of the given length."""
        return self._client.generate_pin(length)

    def generate_memorable_password(
        self,
        word_count: int = 4,
        separator: str = "-",
        capitalize: bool = True,
    ) -> str:
        """Generate a memorable passphrase like ``Correct-Horse-Battery-Staple``."""
        return self._client.generate_memorable_password(word_count, separator, capitalize)

    def check_password_strength(self, password: str) -> dict:
        """Evaluate the strength of a password. Returns ``{score, label}``."""
        return self._client.check_password_strength(password)

    def generate_totp(self, secret: str) -> dict:
        """Generate a TOTP code. Returns ``{code, remaining_seconds}``."""
        return self._client.generate_totp(secret)

    def export_csv(self) -> str:
        """Export all active items as a CSV string."""
        return self._client.export_csv()

    def export_json(self) -> str:
        """Export all active items as a pretty-printed JSON string."""
        return self._client.export_json()

    def import_csv(self, csv: str) -> int:
        """Import items from a CSV string. Returns the count imported."""
        return self._client.import_csv(csv)

    def import_json(self, json: str) -> int:
        """Import items from a JSON string. Returns the count imported."""
        return self._client.import_json(json)

    def import_1pux(self, data: bytes) -> int:
        """Import from a 1Password ``.1pux`` archive. Returns the count imported."""
        return self._client.import_1pux(data)

    def import_bitwarden(self, json: str) -> int:
        """Import from a Bitwarden JSON export. Returns the count imported."""
        return self._client.import_bitwarden(json)

    def import_lastpass(self, csv: str) -> int:
        """Import from a LastPass CSV export. Returns the count imported."""
        return self._client.import_lastpass(csv)

    def import_keepass(self, data: bytes, password: str) -> int:
        """Import from a KeePass ``.kdbx`` file. Returns the count imported."""
        return self._client.import_keepass(data, password)

    def analyze_security(self) -> dict:
        """Analyze the security posture of all active items."""
        return self._client.analyze_security()

    def generate_random_bytes(self, n: int) -> bytes:
        """Generate ``n`` cryptographically random bytes."""
        return self._client.generate_random_bytes(n)

    def attach_file(
        self, item_id: str, filename: str, data: bytes, mime_type: str = ""
    ) -> str:
        """Encrypt and store ``data`` as a file attachment on ``item_id``.

        Returns the new attachment id string.
        """
        return self._client.attach_file(item_id, filename, data, mime_type)

    def get_attachment(self, attachment_id: str) -> dict:
        """Retrieve an attachment and its decrypted file data.

        Returns a dict with keys ``id``, ``item_id``, ``filename``,
        ``mime_type``, ``size``, ``created_at``, and ``data`` (``bytes``).
        """
        return self._client.get_attachment(attachment_id)

    def list_attachments(self, item_id: str) -> list[dict]:
        """Return metadata for all attachments on ``item_id`` (no file data)."""
        return self._client.list_attachments(item_id)

    def delete_attachment(self, attachment_id: str) -> None:
        """Delete a single attachment by id."""
        return self._client.delete_attachment(attachment_id)

    # ------------------------------------------------------------------
    # Remote authorization
    # ------------------------------------------------------------------

    def generate_device_keypair(self) -> dict:
        """Generate a new X25519 keypair for device identity.

        Returns a dict ``{"public_key": bytes, "private_key": bytes}``.
        """
        return self._client.generate_device_keypair()

    def encode_pairing_data(
        self, device_name: str, device_type: str, public_key: bytes
    ) -> bytes:
        """Encode pairing data into compact binary format for QR code."""
        return self._client.encode_pairing_data(device_name, device_type, public_key)

    def decode_pairing_data(self, data: bytes) -> dict:
        """Decode pairing data from compact binary format.

        Returns ``{"device_name": str, "device_type": str, "public_key": bytes}``.
        """
        return self._client.decode_pairing_data(data)

    def pair_device(
        self, device_name: str | None = None, device_type: str = "python"
    ) -> dict:
        """Generate a keypair and pairing data in one call.

        Returns ``{"public_key": bytes, "private_key": bytes, "qr_data": bytes}``.
        """
        import platform

        if device_name is None:
            device_name = platform.node() or "Python SDK"

        kp = self.generate_device_keypair()
        qr_data = self.encode_pairing_data(device_name, device_type, kp["public_key"])
        return {
            "public_key": kp["public_key"],
            "private_key": kp["private_key"],
            "qr_data": qr_data,
        }

    def create_auth_request(
        self,
        my_private_key: bytes,
        peer_public_key: bytes,
        request_type: str,
        metadata: dict,
    ) -> dict:
        """Create an encrypted authorization request (initiator side).

        Parameters
        ----------
        my_private_key:
            The 32-byte X25519 private key of the requesting device.
        peer_public_key:
            The 32-byte X25519 public key of the approving device.
        request_type:
            One of ``"read_item"``, ``"unlock"``, ``"export"``, ``"sensitive_op"``.
        metadata:
            A JSON-serializable dict with request details (e.g. ``{"item_id": "..."}``).

        Returns
        -------
        dict
            ``{"handshake_msg1": bytes, "encrypted_metadata": bytes, "request_type": str}``
        """
        return self._client.create_auth_request(
            my_private_key, peer_public_key, request_type, metadata
        )

    def decrypt_auth_request(
        self,
        my_private_key: bytes,
        peer_public_key: bytes,
        handshake_msg1: bytes,
        encrypted_metadata: bytes,
        request_type: str,
    ) -> dict:
        """Decrypt an authorization request (approver side).

        Returns ``{"metadata": dict, "handshake_msg2": bytes, "request_type": str}``.
        """
        return self._client.decrypt_auth_request(
            my_private_key, peer_public_key, handshake_msg1, encrypted_metadata, request_type
        )

    def create_auth_response(
        self,
        my_private_key: bytes,
        peer_public_key: bytes,
        payload: dict,
    ) -> dict:
        """Create an encrypted authorization response (approver side).

        Parameters
        ----------
        my_private_key:
            The approver's 32-byte X25519 private key.
        peer_public_key:
            The requester's 32-byte X25519 public key.
        payload:
            A JSON-serializable dict with the response data
            (e.g. ``{"password": "...", "item_id": "..."}``).

        Returns ``{"encrypted_payload": bytes}``.
        """
        return self._client.create_auth_response(my_private_key, peer_public_key, payload)

    def decrypt_auth_response(
        self,
        my_private_key: bytes,
        peer_public_key: bytes,
        encrypted_payload: bytes,
    ) -> dict:
        """Decrypt an authorization response (requester side).

        Returns the decrypted payload as a dict.
        """
        return self._client.decrypt_auth_response(
            my_private_key, peer_public_key, encrypted_payload
        )

    def request_remote_auth(
        self,
        item_id: str,
        peer_public_key: bytes,
        my_private_key: bytes,
        timeout: int = 300,
    ) -> dict:
        """Request remote authorization for accessing an item.

        This is a convenience method that builds the encrypted request data.
        In a real scenario, the returned data would be sent to the approver
        via CloudKit or another transport.

        Returns the encrypted request dict from ``create_auth_request``.
        """
        return self.create_auth_request(
            my_private_key=my_private_key,
            peer_public_key=peer_public_key,
            request_type="read_item",
            metadata={"item_id": item_id, "timeout": timeout},
        )

    def approve_remote_auth(
        self,
        request_data: dict,
        peer_public_key: bytes,
        my_private_key: bytes,
    ) -> dict:
        """Approve a remote authorization request (approver side).

        Decrypts the request metadata, fetches the requested item from the
        vault, and returns an encrypted response containing the item data.

        Parameters
        ----------
        request_data:
            The dict returned by ``create_auth_request`` / ``request_remote_auth``
            on the requester side (must contain ``handshake_msg1``,
            ``encrypted_metadata``, ``request_type``).
        peer_public_key:
            The requester's 32-byte X25519 public key.
        my_private_key:
            The approver's 32-byte X25519 private key.

        Returns
        -------
        dict
            ``{"encrypted_payload": bytes}`` — the encrypted response to
            send back to the requester.
        """
        # Step 1: Decrypt the request
        decrypted = self.decrypt_auth_request(
            my_private_key=my_private_key,
            peer_public_key=peer_public_key,
            handshake_msg1=request_data["handshake_msg1"],
            encrypted_metadata=request_data["encrypted_metadata"],
            request_type=request_data.get("request_type", "read_item"),
        )

        # Step 2: Fetch the requested item
        metadata = decrypted["metadata"]
        item_id = metadata.get("item_id")
        if item_id:
            item = self.get_item(item_id)
        else:
            item = {"error": "no item_id in request metadata"}

        # Step 3: Encrypt and return the response
        return self.create_auth_response(
            my_private_key=my_private_key,
            peer_public_key=peer_public_key,
            payload=item,
        )

    # ------------------------------------------------------------------
    # Item sharing
    # ------------------------------------------------------------------

    def share_item(self, id: str, passphrase: str) -> bytes:
        """Export a single item as an encrypted sharing blob.

        The vault must be unlocked. Returns raw ``bytes`` that can be
        transferred to another device and imported with ``import_shared_item``.
        """
        return self._client.share_item(id, passphrase)

    def import_shared_item(self, data: bytes, passphrase: str) -> str:
        """Import a single item from an encrypted sharing blob.

        Decrypts ``data`` with the given passphrase, assigns a new UUID and
        current timestamps, and creates the item in the vault.  Returns the
        new item ID string.
        """
        return self._client.import_shared_item(data, passphrase)

    # ------------------------------------------------------------------
    # Batch operations
    # ------------------------------------------------------------------

    def create_items(self, items: list[dict]) -> int:
        """Batch-create password items.

        Parameters
        ----------
        items:
            A list of dicts, each matching the ``PasswordItem`` schema.

        Returns
        -------
        int
            The number of items successfully created.
        """
        count = 0
        for item in items:
            self._client.create_item(item)
            count += 1
        return count

    def delete_items(self, ids: list[str]) -> int:
        """Batch soft-delete items (move to trash).

        Parameters
        ----------
        ids:
            List of item UUID strings to soft-delete.

        Returns
        -------
        int
            The number of items soft-deleted.
        """
        count = 0
        for item_id in ids:
            self._client.delete_item(item_id)
            count += 1
        return count

    def permanently_delete_items(self, ids: list[str]) -> int:
        """Batch permanently delete items. This cannot be undone.

        Parameters
        ----------
        ids:
            List of item UUID strings to permanently delete.

        Returns
        -------
        int
            The number of items permanently deleted.
        """
        count = 0
        for item_id in ids:
            self._client.permanently_delete_item(item_id)
            count += 1
        return count

    # ------------------------------------------------------------------
    # Filter / search enhancements
    # ------------------------------------------------------------------

    def filter_items(
        self,
        category: str | None = None,
        folder_id: str | None = None,
        tags: list[str] | None = None,
        is_favorite: bool | None = None,
        state: str = "active",
    ) -> list[dict]:
        """Return items matching all specified criteria.

        All filters are optional and combined with logical AND. Omitting a
        filter means "no restriction on that field".

        Parameters
        ----------
        category:
            One of ``"logins"``, ``"cards"``, ``"notes"``, ``"identities"``,
            ``"bank-accounts"``, ``"software-licenses"``, ``"wifi"``,
            ``"passkeys"``.  ``None`` matches any category.
        folder_id:
            UUID of the folder to restrict to.  ``None`` matches any folder.
        tags:
            If provided, only items that contain *all* of the given tags are
            returned.
        is_favorite:
            ``True`` returns only favorites; ``False`` returns only
            non-favorites; ``None`` returns both.
        state:
            ``"active"`` (default) — only non-deleted, non-archived items.
            ``"trashed"`` — only soft-deleted items.
            ``"archived"`` — only archived items.
            ``"all"`` — active and trashed combined.

        Returns
        -------
        list[dict]
            Matching items as dicts matching the ``PasswordItem`` schema.

        Raises
        ------
        ValueError
            If ``state`` is not one of ``"active"``, ``"trashed"``, ``"archived"``, ``"all"``.
        """
        if state == "active":
            items: list[dict] = self._client.list_items()
        elif state == "trashed":
            items = self._client.list_trashed_items()
        elif state == "archived":
            items = self._client.list_archived_items()
        elif state == "all":
            items = self._client.list_items() + self._client.list_trashed_items()
        else:
            raise ValueError(
                f"state must be 'active', 'trashed', 'archived', or 'all'; got {state!r}"
            )

        if category is not None:
            items = [i for i in items if i.get("category") == category]

        if folder_id is not None:
            items = [i for i in items if i.get("folder_id") == folder_id]

        if tags is not None:
            required = set(tags)
            items = [i for i in items if required.issubset(set(i.get("tags") or []))]

        if is_favorite is not None:
            items = [i for i in items if bool(i.get("is_favorite")) == is_favorite]

        return items

    # ------------------------------------------------------------------
    # Secret reference URI resolver
    # ------------------------------------------------------------------

    def resolve(self, uri: str) -> str:
        """Resolve a Claustra secret reference URI to its plaintext value.

        URI formats
        -----------
        ``claustra://<item-title>/<field>``
            where ``<field>`` is one of:

            * ``password`` — the item's password.
            * ``username`` — the item's username.
            * ``totp`` — generate and return the current TOTP code string.
            * ``website`` — the item's URL.
            * ``notes`` — the item's notes.
            * ``custom/<label>`` — value of a custom field with the given label.

        Title matching is case-insensitive. The first matching active item is used.

        Parameters
        ----------
        uri:
            A ``claustra://`` reference URI.

        Returns
        -------
        str
            The resolved plaintext secret value.

        Raises
        ------
        ValueError
            If the URI scheme is invalid or malformed.
        NotFoundError
            If no item matches the given title, or the requested field does not
            exist on the matched item.
        """
        if not uri.startswith(_URI_SCHEME):
            raise ValueError(
                f"Invalid URI scheme. Expected URI starting with {_URI_SCHEME!r}, "
                f"got {uri!r}"
            )

        # Strip scheme and split into non-empty path segments
        path = uri[len(_URI_SCHEME):]
        segments = [s for s in path.split("/") if s]

        if len(segments) < 2:
            raise ValueError(
                "URI must have at least two path components (<title>/<field>), "
                f"got {uri!r}"
            )

        title = segments[0]
        field = segments[1].lower()

        # Locate the item by title (case-insensitive, first active match wins)
        items: list[dict] = self._client.list_items()
        item: dict | None = next(
            (i for i in items if (i.get("title") or "").lower() == title.lower()),
            None,
        )
        if item is None:
            raise NotFoundError(f"No active item found with title {title!r}")

        if field == "totp":
            totp_secret = item.get("totp_secret")
            if not totp_secret:
                raise NotFoundError(
                    f"Item {title!r} does not have a TOTP secret configured"
                )
            result = self._client.generate_totp(totp_secret)
            return result["code"]

        if field == "custom":
            if len(segments) < 3:
                raise ValueError(
                    "Custom field URI must be: claustra://<title>/custom/<label>"
                )
            label = segments[2]
            custom_fields: list[dict] = item.get("custom_fields") or []
            match = next(
                (
                    cf
                    for cf in custom_fields
                    if (cf.get("label") or "").lower() == label.lower()
                ),
                None,
            )
            if match is None:
                raise NotFoundError(
                    f"Item {title!r} has no custom field with label {label!r}"
                )
            value = match.get("value")
            if value is None:
                raise NotFoundError(
                    f"Custom field {label!r} on item {title!r} has no value"
                )
            return value

        # Simple scalar fields
        _SCALAR_FIELDS = {"password", "username", "website", "notes"}
        if field not in _SCALAR_FIELDS:
            raise ValueError(
                f"Unknown field {field!r}. Valid fields: "
                + ", ".join(sorted(_SCALAR_FIELDS))
                + ", totp, custom/<label>"
            )

        value = item.get(field)
        if value is None:
            raise NotFoundError(f"Field {field!r} is not set on item {title!r}")
        return value

    # ------------------------------------------------------------------
    # SSH key convenience methods
    # ------------------------------------------------------------------

    def create_ssh_key_item(self, title: str, private_key: str, public_key: str = "",
                             key_type: str = "ed25519", folder_id: str | None = None) -> dict:
        """Create a new item specifically for storing an SSH key.

        The SSH key is stored as a custom field with field_type="ssh_key".
        Returns the created item dict.
        """
        import uuid
        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).isoformat()
        item_id = str(uuid.uuid4())

        # Generate fingerprint from public key if possible
        fingerprint = ""

        item = {
            "id": item_id,
            "title": title,
            "username": "",
            "password": "",
            "website": "",
            "notes": "",
            "category": "logins",
            "is_favorite": False,
            "is_pinned": False,
            "icon_emoji": "🔐",
            "icon_bg_color": "#6366f1",
            "tags": ["ssh-key"],
            "security_questions": [],
            "custom_fields": [
                {
                    "id": str(uuid.uuid4()),
                    "label": "SSH Private Key",
                    "value": private_key,
                    "field_type": "ssh_key",
                },
                {
                    "id": str(uuid.uuid4()),
                    "label": "SSH Public Key",
                    "value": public_key,
                    "field_type": "ssh_key_public",
                },
                {
                    "id": str(uuid.uuid4()),
                    "label": "Key Type",
                    "value": key_type,
                    "field_type": "text",
                },
            ],
            "password_history": [],
            "totp_secret": "",
            "expires_at": "",
            "created_at": now,
            "updated_at": now,
            "folder_id": folder_id,
            "deleted_at": None,
        }

        self.create_item(item)
        return item

    def get_ssh_keys(self) -> list[dict]:
        """Return all items that contain SSH key custom fields."""
        items = self.list_items()
        return [
            item for item in items
            if any(
                cf.get("field_type") == "ssh_key"
                for cf in (item.get("custom_fields") or [])
            )
        ]

    # ------------------------------------------------------------------
    # Environment variable injection
    # ------------------------------------------------------------------

    def load_env(self, mapping: dict[str, str]) -> None:
        """Resolve secret URIs and inject values into the current process environment.

        Parameters
        ----------
        mapping:
            A dict mapping environment variable names to ``claustra://`` URIs.

            Example::

                client.load_env({
                    "DB_PASSWORD": "claustra://database/password",
                    "API_KEY":     "claustra://my-api/custom/api-key",
                })

        Raises
        ------
        ValueError
            If a URI is malformed.
        NotFoundError
            If an item or field referenced by a URI cannot be found.
        """
        for env_var, uri in mapping.items():
            os.environ[env_var] = self.resolve(uri)


# ---------------------------------------------------------------------------
# VaultManager
# ---------------------------------------------------------------------------


class VaultManager:
    """Manage multiple Claustra vaults stored in a single directory.

    Each vault is a SQLite file with a ``.claustra`` extension inside
    ``base_dir``.

    Parameters
    ----------
    base_dir:
        Path to the directory that contains (or will contain) vault files.
        The directory is created automatically if it does not exist.
    """

    _EXTENSION = ".claustra"

    def __init__(self, base_dir: str) -> None:
        self._base_dir = Path(base_dir)
        self._base_dir.mkdir(parents=True, exist_ok=True)

    def _vault_path(self, name: str) -> Path:
        return self._base_dir / f"{name}{self._EXTENSION}"

    def list_vaults(self) -> list[str]:
        """Return the names of all vaults in ``base_dir``.

        Returns
        -------
        list[str]
            Vault names without the file extension, sorted alphabetically.
        """
        suffix = self._EXTENSION
        return sorted(
            p.stem
            for p in self._base_dir.iterdir()
            if p.is_file() and p.suffix == suffix
        )

    def create_vault(self, name: str) -> Client:
        """Create a new vault and return an open ``Client`` for it.

        Parameters
        ----------
        name:
            Vault name (used as the filename stem). Must not already exist.

        Returns
        -------
        Client
            An open (locked) ``Client`` pointing at the new vault.

        Raises
        ------
        FileExistsError
            If a vault with that name already exists.
        """
        path = self._vault_path(name)
        if path.exists():
            raise FileExistsError(f"Vault {name!r} already exists at {path}")
        return Client(str(path))

    def open_vault(self, name: str) -> Client:
        """Open an existing vault and return a ``Client`` for it.

        Parameters
        ----------
        name:
            Vault name (filename stem without extension).

        Returns
        -------
        Client
            An open (locked) ``Client`` pointing at the vault.

        Raises
        ------
        FileNotFoundError
            If no vault with that name exists.
        """
        path = self._vault_path(name)
        if not path.exists():
            raise FileNotFoundError(f"Vault {name!r} not found at {path}")
        return Client(str(path))

    def delete_vault(self, name: str) -> None:
        """Delete a vault file from disk.

        Parameters
        ----------
        name:
            Vault name (filename stem without extension).

        Raises
        ------
        FileNotFoundError
            If no vault with that name exists.
        """
        path = self._vault_path(name)
        if not path.exists():
            raise FileNotFoundError(f"Vault {name!r} not found at {path}")
        path.unlink()
