"""Type definitions for the dict-based Claustra API."""

from typing import Literal, TypedDict

Category = Literal[
    "logins", "cards", "notes", "identities",
    "bank-accounts", "software-licenses", "wifi", "passkeys",
]


class CustomField(TypedDict, total=False):
    id: str
    label: str
    value: str
    field_type: str


class SecurityQuestion(TypedDict, total=False):
    question: str
    answer: str


class PasswordHistoryEntry(TypedDict, total=False):
    password: str
    changed_at: str


class PasswordItem(TypedDict, total=False):
    id: str
    title: str
    username: str
    password: str
    website: str
    notes: str
    category: Category
    is_favorite: bool
    is_pinned: bool
    icon_emoji: str
    icon_bg_color: str
    tags: list[str]
    security_questions: list[SecurityQuestion]
    custom_fields: list[CustomField]
    password_history: list[PasswordHistoryEntry]
    totp_secret: str
    expires_at: str
    created_at: str
    updated_at: str
    folder_id: str | None
    deleted_at: str | None


class Folder(TypedDict, total=False):
    id: str
    name: str
    icon: str


class PasswordStrength(TypedDict):
    score: int
    label: str


class TotpResult(TypedDict):
    code: str
    remaining_seconds: int


class SecurityReport(TypedDict, total=False):
    score: int
    score_label: str
    total_issues: int
    weak_password_ids: list[str]
    reused_password_ids: list[str]
    old_password_ids: list[str]
    expiring_ids: list[str]
    missing_2fa_ids: list[str]
    insecure_website_ids: list[str]
    strength_distribution: list[int]


class SSHKeyField(TypedDict, total=False):
    id: str
    label: str
    private_key: str
    public_key: str
    key_type: str  # "ed25519", "rsa", "ecdsa"
    fingerprint: str
    field_type: str  # always "ssh_key"


class Attachment(TypedDict, total=False):
    id: str
    item_id: str
    filename: str
    mime_type: str
    size: int
    created_at: str


class DeviceKeyPair(TypedDict):
    public_key: bytes
    private_key: bytes


class PairingData(TypedDict):
    device_name: str
    device_type: str
    public_key: bytes


class PairingResult(TypedDict):
    public_key: bytes
    private_key: bytes
    qr_data: bytes


class AuthRequest(TypedDict):
    handshake_msg1: bytes
    encrypted_metadata: bytes
    request_type: str


class DecryptedAuthRequest(TypedDict):
    metadata: dict
    handshake_msg2: bytes
    request_type: str


class AuthResponse(TypedDict):
    encrypted_payload: bytes
