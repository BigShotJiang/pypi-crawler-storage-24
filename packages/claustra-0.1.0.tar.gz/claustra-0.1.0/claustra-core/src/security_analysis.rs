use std::collections::HashMap;

use chrono::{DateTime, Duration, Utc};
use serde::{Deserialize, Serialize};

use crate::models::{Category, PasswordItem};
use crate::password_generator::calculate_password_strength;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityReport {
    /// Overall security score 0-100
    pub score: u32,
    /// Score label: "危险", "注意", "一般", "安全"
    pub score_label: String,
    /// Total number of issues
    pub total_issues: u32,
    /// Weak password item IDs
    pub weak_password_ids: Vec<String>,
    /// Reused password item IDs
    pub reused_password_ids: Vec<String>,
    /// Old password item IDs (>180 days since update)
    pub old_password_ids: Vec<String>,
    /// Expiring item IDs (within 30 days)
    pub expiring_ids: Vec<String>,
    /// Login items missing 2FA
    pub missing_2fa_ids: Vec<String>,
    /// Insecure website item IDs (HTTP instead of HTTPS)
    pub insecure_website_ids: Vec<String>,
    /// Password strength distribution: [count_at_score_0, ..., count_at_score_6]
    pub strength_distribution: Vec<u32>,
}

pub fn analyze_security(items: &[PasswordItem]) -> SecurityReport {
    // Filter to active (non-deleted) items
    let active: Vec<&PasswordItem> = items.iter()
        .filter(|i| i.deleted_at.is_none())
        .collect();

    // 1. Weak passwords: strength score <= 2
    let weak_password_ids: Vec<String> = active.iter()
        .filter(|i| !i.password.is_empty())
        .filter(|i| calculate_password_strength(&i.password).score <= 2)
        .map(|i| i.id.clone())
        .collect();

    // 2. Reused passwords: same password used by more than one item
    let mut pw_map: HashMap<&str, Vec<&str>> = HashMap::new();
    for item in &active {
        if !item.password.is_empty() {
            pw_map.entry(&item.password).or_default().push(&item.id);
        }
    }
    let reused_password_ids: Vec<String> = pw_map.iter()
        .filter(|(_, ids)| ids.len() > 1)
        .flat_map(|(_, ids)| ids.iter().map(|id| id.to_string()))
        .collect();

    // 3. Old passwords: updated_at > 180 days ago
    let cutoff_old = Utc::now() - Duration::days(180);
    let old_password_ids: Vec<String> = active.iter()
        .filter(|i| !i.password.is_empty())
        .filter(|i| {
            DateTime::parse_from_rfc3339(&i.updated_at)
                .map(|d| d < cutoff_old)
                .unwrap_or(false)
        })
        .map(|i| i.id.clone())
        .collect();

    // 4. Expiring items: expires_at within 30 days (and non-empty)
    let cutoff_expiry = Utc::now() + Duration::days(30);
    let expiring_ids: Vec<String> = active.iter()
        .filter(|i| {
            if i.expires_at.is_empty() {
                return false;
            }
            DateTime::parse_from_rfc3339(&i.expires_at)
                .map(|d| d <= cutoff_expiry)
                .unwrap_or(false)
        })
        .map(|i| i.id.clone())
        .collect();

    // 5. Missing 2FA: login category items without TOTP
    let missing_2fa_ids: Vec<String> = active.iter()
        .filter(|i| i.category == Category::Logins && i.totp_secret.is_empty())
        .map(|i| i.id.clone())
        .collect();

    // 6. Insecure websites: HTTP (not HTTPS)
    let insecure_website_ids: Vec<String> = active.iter()
        .filter(|i| {
            let w = i.website.to_lowercase();
            !w.is_empty() && w.starts_with("http://")
        })
        .map(|i| i.id.clone())
        .collect();

    // 7. Password strength distribution: scores 0-6
    let mut strength_distribution = vec![0u32; 7];
    for item in &active {
        if !item.password.is_empty() {
            let s = calculate_password_strength(&item.password).score as usize;
            if s < 7 {
                strength_distribution[s] += 1;
            }
        }
    }

    // Overall score calculation (matches Swift SecurityCheckView logic)
    let count = active.len();
    let total_issues = weak_password_ids.len()
        + reused_password_ids.len()
        + old_password_ids.len()
        + expiring_ids.len()
        + missing_2fa_ids.len();

    let score = if count == 0 {
        100u32
    } else {
        let max_penalty = count * 5;
        let penalty = std::cmp::min(total_issues * 20, max_penalty);
        let score_f = 100.0 - (penalty as f64 / max_penalty as f64) * 100.0;
        score_f.max(0.0) as u32
    };

    let score_label = match score {
        80..=u32::MAX => "安全".to_string(),
        60..=79 => "一般".to_string(),
        40..=59 => "注意".to_string(),
        _ => "危险".to_string(),
    };

    SecurityReport {
        score,
        score_label,
        total_issues: total_issues as u32,
        weak_password_ids,
        reused_password_ids,
        old_password_ids,
        expiring_ids,
        missing_2fa_ids,
        insecure_website_ids,
        strength_distribution,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::models::{Category, PasswordItem};

    fn make_item(id: &str, password: &str, category: Category) -> PasswordItem {
        PasswordItem {
            id: id.to_string(),
            password: password.to_string(),
            category,
            ..PasswordItem::default()
        }
    }

    #[test]
    fn test_empty_items_returns_100() {
        let report = analyze_security(&[]);
        assert_eq!(report.score, 100);
        assert_eq!(report.score_label, "安全");
        assert_eq!(report.total_issues, 0);
    }

    #[test]
    fn test_weak_password_detected() {
        let item = make_item("1", "abc", Category::Logins);
        let report = analyze_security(&[item]);
        assert!(report.weak_password_ids.contains(&"1".to_string()));
    }

    #[test]
    fn test_reused_password_detected() {
        let a = make_item("a", "SamePass1!", Category::Logins);
        let b = make_item("b", "SamePass1!", Category::Logins);
        let report = analyze_security(&[a, b]);
        assert!(report.reused_password_ids.contains(&"a".to_string()));
        assert!(report.reused_password_ids.contains(&"b".to_string()));
    }

    #[test]
    fn test_deleted_items_excluded() {
        let mut item = make_item("1", "abc", Category::Logins);
        item.deleted_at = Some("2024-01-01T00:00:00Z".to_string());
        let report = analyze_security(&[item]);
        assert_eq!(report.total_issues, 0);
        assert!(report.weak_password_ids.is_empty());
    }

    #[test]
    fn test_insecure_website_detected() {
        let mut item = make_item("1", "", Category::Logins);
        item.website = "http://example.com".to_string();
        let report = analyze_security(&[item]);
        assert!(report.insecure_website_ids.contains(&"1".to_string()));
    }

    #[test]
    fn test_https_website_not_flagged() {
        let mut item = make_item("1", "", Category::Logins);
        item.website = "https://example.com".to_string();
        let report = analyze_security(&[item]);
        assert!(report.insecure_website_ids.is_empty());
    }
}
