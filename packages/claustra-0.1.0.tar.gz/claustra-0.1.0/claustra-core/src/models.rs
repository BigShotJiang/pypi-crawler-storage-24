use std::fmt;
use std::str::FromStr;

use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Attachment
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Attachment {
    pub id: String,
    pub item_id: String,
    pub filename: String,
    pub mime_type: String,
    pub size: u64,
    pub created_at: String,
}

// ---------------------------------------------------------------------------
// Category
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Category {
    Logins,
    Cards,
    Notes,
    Identities,
    BankAccounts,
    SoftwareLicenses,
    Wifi,
    Passkeys,
}

impl Default for Category {
    fn default() -> Self {
        Category::Logins
    }
}

impl fmt::Display for Category {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Category::Logins => "logins",
            Category::Cards => "cards",
            Category::Notes => "notes",
            Category::Identities => "identities",
            Category::BankAccounts => "bank-accounts",
            Category::SoftwareLicenses => "software-licenses",
            Category::Wifi => "wifi",
            Category::Passkeys => "passkeys",
        };
        write!(f, "{}", s)
    }
}

impl FromStr for Category {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "logins" => Ok(Category::Logins),
            "cards" => Ok(Category::Cards),
            "notes" => Ok(Category::Notes),
            "identities" => Ok(Category::Identities),
            "bank-accounts" => Ok(Category::BankAccounts),
            "software-licenses" => Ok(Category::SoftwareLicenses),
            "wifi" => Ok(Category::Wifi),
            "passkeys" => Ok(Category::Passkeys),
            other => Err(format!("Unknown category: {}", other)),
        }
    }
}

// ---------------------------------------------------------------------------
// CustomField
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CustomField {
    pub id: String,
    pub label: String,
    pub value: String,
    pub field_type: String,
}

// ---------------------------------------------------------------------------
// PasswordHistoryEntry
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PasswordHistoryEntry {
    pub password: String,
    pub changed_at: String,
}

// ---------------------------------------------------------------------------
// SecurityQuestion
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityQuestion {
    pub question: String,
    pub answer: String,
}

// ---------------------------------------------------------------------------
// PasswordItem
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PasswordItem {
    pub id: String,
    pub title: String,
    pub username: String,
    pub password: String,
    pub website: String,
    pub notes: String,
    pub category: Category,
    pub is_favorite: bool,
    pub is_pinned: bool,
    pub icon_emoji: String,
    pub icon_bg_color: String,
    pub tags: Vec<String>,
    pub security_questions: Vec<SecurityQuestion>,
    pub custom_fields: Vec<CustomField>,
    pub password_history: Vec<PasswordHistoryEntry>,
    pub totp_secret: String,
    pub expires_at: String,
    pub created_at: String,
    pub updated_at: String,
    pub folder_id: Option<String>,
    pub deleted_at: Option<String>,
    pub archived_at: Option<String>,
}

impl Default for PasswordItem {
    fn default() -> Self {
        let now = chrono::Utc::now().to_rfc3339();
        Self {
            id: uuid::Uuid::new_v4().to_string(),
            title: String::new(),
            username: String::new(),
            password: String::new(),
            website: String::new(),
            notes: String::new(),
            category: Category::default(),
            is_favorite: false,
            is_pinned: false,
            icon_emoji: "🔑".to_string(),
            icon_bg_color: "#2b7fff".to_string(),
            tags: Vec::new(),
            security_questions: Vec::new(),
            custom_fields: Vec::new(),
            password_history: Vec::new(),
            totp_secret: String::new(),
            expires_at: String::new(),
            created_at: now.clone(),
            updated_at: now,
            folder_id: None,
            deleted_at: None,
            archived_at: None,
        }
    }
}

// ---------------------------------------------------------------------------
// Folder
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Folder {
    pub id: String,
    pub name: String,
    pub icon: String,
}

impl Default for Folder {
    fn default() -> Self {
        Self {
            id: uuid::Uuid::new_v4().to_string(),
            name: String::new(),
            icon: "📁".to_string(),
        }
    }
}

// ---------------------------------------------------------------------------
// SortOption
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SortOption {
    NameAsc,
    NameDesc,
    CreatedNewest,
    CreatedOldest,
    ModifiedNewest,
    ModifiedOldest,
}

// ---------------------------------------------------------------------------
// PasswordGeneratorOptions
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PasswordGeneratorOptions {
    pub length: u32,
    pub uppercase: bool,
    pub lowercase: bool,
    pub numbers: bool,
    pub symbols: bool,
}

impl Default for PasswordGeneratorOptions {
    fn default() -> Self {
        Self {
            length: 16,
            uppercase: true,
            lowercase: true,
            numbers: true,
            symbols: true,
        }
    }
}

// ---------------------------------------------------------------------------
// PasswordStrength
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PasswordStrength {
    pub score: u32,
    pub label: String,
}

// ---------------------------------------------------------------------------
// SidebarCategory
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SidebarCategory {
    All,
    Favorites,
    RecentlyUsed,
    Trash,
    Category(Category),
}

// ---------------------------------------------------------------------------
// FaviconEntry
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FaviconEntry {
    pub domain: String,
    pub data_url: String,
    pub fetched_at: String,
}

// ---------------------------------------------------------------------------
// AppSettings
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppSettings {
    pub auto_lock_timeout: u64,
    pub clipboard_auto_clear: bool,
    pub clipboard_clear_timeout: u64,
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            auto_lock_timeout: 300,
            clipboard_auto_clear: true,
            clipboard_clear_timeout: 30,
        }
    }
}
