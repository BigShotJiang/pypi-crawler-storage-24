use rand::Rng;
use rand::seq::SliceRandom;

use crate::models::{PasswordGeneratorOptions, PasswordStrength};

// ---------------------------------------------------------------------------
// Word list for memorable password generation (~500 common English words,
// 4–8 letters, easy to type and remember)
// ---------------------------------------------------------------------------

const WORD_LIST: &[&str] = &[
    "able", "acid", "aged", "also", "area", "army", "auto", "away", "back", "ball",
    "band", "bank", "base", "bath", "bear", "beat", "been", "bell", "best", "bird",
    "bite", "blue", "boat", "body", "bold", "bolt", "bond", "bone", "book", "boom",
    "boot", "born", "boss", "both", "bulk", "burn", "busy", "cage", "cake", "call",
    "calm", "came", "camp", "card", "care", "cart", "case", "cash", "cast", "cave",
    "cell", "chat", "chef", "chip", "city", "clam", "clan", "clay", "clip", "club",
    "clue", "coal", "coat", "code", "coil", "coin", "cold", "come", "cook", "cool",
    "copy", "core", "corn", "cost", "coup", "crew", "crop", "cube", "curl", "cute",
    "dark", "data", "date", "dawn", "days", "dead", "deal", "dean", "dear", "deck",
    "deed", "deep", "deer", "desk", "diet", "dirt", "dish", "disk", "dock", "dome",
    "door", "dose", "down", "draw", "drew", "drop", "drum", "dual", "duck", "dusk",
    "dust", "duty", "each", "earn", "ease", "edge", "else", "emit", "even", "exam",
    "exit", "face", "fact", "fail", "fair", "fall", "fame", "farm", "fast", "fate",
    "feed", "feel", "feet", "fell", "felt", "file", "fill", "film", "fine", "fire",
    "firm", "fish", "fist", "five", "flag", "flat", "flew", "flip", "flow", "foam",
    "fold", "folk", "fond", "font", "food", "fool", "foot", "ford", "fork", "form",
    "fort", "foul", "four", "free", "from", "fuel", "full", "fund", "fuse", "gain",
    "game", "gate", "gave", "gear", "gene", "gift", "girl", "give", "glad", "glow",
    "glue", "goal", "gold", "golf", "gone", "good", "gown", "grab", "gray", "grew",
    "grid", "grip", "grit", "grow", "gulf", "guru", "gust", "half", "hall", "halt",
    "hand", "hang", "hard", "harm", "hash", "have", "hawk", "head", "heap", "heat",
    "heel", "held", "helm", "help", "herb", "hero", "high", "hill", "hint", "hire",
    "hold", "hole", "home", "hook", "hope", "horn", "host", "huge", "hung", "hunt",
    "hurt", "icon", "idea", "idle", "inch", "into", "iron", "item", "jack", "join",
    "joke", "jump", "just", "keen", "keep", "kick", "kill", "kind", "king", "knee",
    "knew", "knit", "knot", "know", "lack", "laid", "lake", "lamb", "lamp", "land",
    "lane", "last", "late", "lawn", "lead", "leaf", "lean", "leap", "left", "lend",
    "lens", "less", "life", "lift", "like", "lime", "line", "link", "lion", "list",
    "live", "load", "loan", "lock", "loft", "long", "look", "loop", "lord", "lore",
    "lose", "loss", "lost", "loud", "love", "luck", "lung", "lure", "main", "make",
    "mall", "malt", "many", "mark", "mass", "mate", "maze", "meal", "mean", "meat",
    "meet", "melt", "memo", "menu", "mesh", "mild", "milk", "mill", "mind", "mine",
    "mint", "miss", "mode", "mold", "mood", "moon", "more", "most", "move", "much",
    "muse", "must", "nail", "name", "need", "nest", "news", "next", "nice", "nine",
    "node", "none", "noon", "norm", "nose", "note", "null", "oath", "obey", "once",
    "only", "open", "oral", "oval", "oven", "over", "pace", "pack", "page", "paid",
    "pain", "pair", "palm", "park", "part", "pass", "past", "path", "peak", "pear",
    "peel", "peer", "pick", "pier", "pile", "pine", "pipe", "plan", "play", "plea",
    "plot", "plow", "plug", "plum", "plus", "poem", "poet", "poll", "polo", "pond",
    "pool", "poor", "port", "pose", "post", "pour", "pray", "prey", "prop", "pull",
    "pump", "pure", "push", "rail", "rain", "rake", "ramp", "rang", "rank", "rare",
    "rate", "read", "real", "reap", "rear", "reef", "reel", "rely", "rest", "rice",
    "rich", "ride", "ring", "riot", "rise", "risk", "road", "roam", "roar", "rock",
    "rode", "role", "roll", "roof", "room", "rope", "rose", "rule", "rush", "rust",
    "safe", "sage", "sail", "salt", "same", "sand", "save", "scan", "seal", "seam",
    "seed", "seek", "seem", "seen", "self", "sell", "send", "shed", "ship", "shoe",
    "shop", "show", "shut", "side", "sign", "silk", "sill", "sing", "sink", "site",
    "size", "skin", "skip", "slab", "slag", "slim", "slip", "slow", "slug", "snap",
    "snow", "soap", "sock", "soft", "soil", "sold", "sole", "some", "song", "soon",
    "sort", "soul", "soup", "span", "spin", "spot", "star", "stay", "stem", "step",
    "stir", "stop", "such", "suit", "sung", "sunk", "sure", "surf", "swap", "swim",
    "tail", "take", "tale", "tall", "tank", "tape", "task", "team", "tear", "tell",
    "tent", "term", "test", "text", "than", "that", "them", "then", "they", "thin",
    "this", "thus", "tide", "till", "time", "tiny", "tire", "toll", "tone", "took",
    "tool", "torn", "toss", "tour", "town", "tram", "trap", "tree", "trim", "trio",
    "trip", "true", "tuck", "tune", "turn", "twin", "type", "unit", "upon", "used",
    "user", "vary", "vast", "very", "view", "vine", "void", "volt", "vote", "wade",
    "wage", "wake", "walk", "wall", "want", "ward", "warm", "warp", "wary", "wave",
    "weak", "wear", "weed", "week", "well", "went", "were", "west", "what", "when",
    "whom", "wide", "wife", "wild", "will", "wind", "wine", "wing", "wire", "wise",
    "wish", "with", "woke", "wolf", "wood", "word", "wore", "work", "worm", "worn",
    "wrap", "wren", "yard", "year", "yell", "yoga", "your", "zero", "zone", "zoom",
    "about", "above", "abuse", "acute", "admit", "adopt", "adult", "after", "again",
    "agent", "agree", "ahead", "alarm", "album", "alert", "align", "alike", "alive",
    "alley", "allow", "alone", "along", "aloud", "alter", "angel", "angry", "anime",
    "ankle", "annex", "apart", "apple", "apply", "arena", "argue", "arise", "armor",
    "array", "arrow", "asset", "atlas", "attic", "audio", "audit", "avoid", "award",
    "aware", "awful", "badge", "baked", "baker", "basis", "batch", "beach", "began",
    "begin", "being", "bench", "berry", "black", "blade", "blame", "bland", "blank",
    "blast", "blaze", "bleed", "blend", "bless", "blind", "block", "blood", "bloom",
    "blown", "board", "bonus", "boost", "booth", "bound", "brace", "brain", "brand",
    "brave", "bread", "break", "breed", "brick", "brief", "bring", "brisk", "broad",
    "brook", "brown", "brush", "build", "built", "buyer", "cabin", "candy", "carry",
    "catch", "cause", "cease", "chain", "chair", "chaos", "charm", "chase", "cheap",
    "check", "cheek", "cheer", "chess", "chest", "chief", "child", "civil", "claim",
    "clash", "class", "clean", "clear", "clerk", "click", "climb", "cling", "clock",
    "clone", "close", "cloud", "coach", "coast", "color", "comic", "coral", "count",
    "court", "cover", "craft", "crane", "crash", "crazy", "creek", "cross", "crowd",
    "crown", "cruel", "crush", "cycle", "daily", "dance", "daisy", "debut", "delay",
    "delta", "depot", "depth", "derby", "devil", "digit", "diner", "dizzy", "dodge",
    "draft", "drain", "drama", "drank", "dream", "dress", "drift", "drive", "drove",
    "dryer", "eagle", "early", "earth", "eight", "elite", "email", "ember", "empty",
    "enjoy", "enter", "entry", "equal", "error", "essay", "event", "every", "exact",
    "extra", "fable", "faith", "fancy", "fault", "feast", "fence", "fetch", "fever",
    "fewer", "field", "fifth", "fifty", "fight", "final", "first", "fixed", "fjord",
    "flare", "flash", "flask", "fleet", "flesh", "flock", "flood", "floor", "floss",
    "flour", "fluid", "flush", "focus", "force", "forge", "forum", "found", "frame",
    "franc", "frank", "fraud", "fresh", "frost", "fruit", "fully", "gamer", "ghost",
    "giant", "given", "gland", "glass", "gleam", "glide", "globe", "gloss", "goose",
    "grace", "grade", "grain", "grand", "grant", "grape", "grasp", "grass", "grave",
    "great", "green", "greet", "grief", "grind", "groan", "group", "grove", "guard",
    "guide", "guild", "guise", "gusto", "happy", "haste", "haven", "heart", "heavy",
    "hence", "hinge", "honor", "horse", "hotel", "house", "human", "humor", "image",
    "imply", "index", "infer", "inner", "input", "intel", "invent", "issue", "ivory",
    "jewel", "judge", "juice", "juicy", "kayak", "knack", "label", "large", "laser",
    "later", "laugh", "layer", "learn", "lease", "legal", "level", "light", "limit",
    "linen", "liver", "local", "lodge", "logic", "loose", "lotus", "lower", "lucky",
    "lunar", "lunch", "lusty", "macro", "magic", "major", "maker", "manor", "maple",
    "march", "match", "mayor", "media", "mercy", "merit", "metal", "micro", "might",
    "minor", "minus", "mixed", "model", "money", "month", "moral", "mound", "mount",
    "mouse", "mouth", "moved", "movie", "music", "naive", "nerve", "never", "night",
    "ninja", "noble", "noise", "north", "noted", "novel", "nurse", "nymph", "occur",
    "ocean", "offer", "often", "order", "other", "outer", "owner", "oxide", "ozone",
    "paint", "panel", "paper", "party", "pasta", "pause", "peace", "pedal", "penny",
    "perch", "phase", "phone", "photo", "piano", "pilot", "pitch", "pixel", "pizza",
    "place", "plain", "plane", "plant", "plate", "plaza", "plead", "pluck", "point",
    "poise", "polar", "porch", "posed", "pound", "power", "press", "price", "pride",
    "prime", "print", "prior", "prize", "probe", "prone", "proof", "prose", "proud",
    "prove", "proxy", "pulse", "punch", "pupil", "queen", "query", "quest", "queue",
    "quick", "quiet", "quota", "quote", "radar", "radio", "rally", "ranch", "range",
    "rapid", "ratio", "reach", "ready", "realm", "rebel", "refer", "relax", "relay",
    "renew", "repay", "repel", "reply", "rider", "ridge", "risky", "river", "robin",
    "robot", "rocky", "rouge", "rough", "round", "route", "rover", "royal", "rugby",
    "ruler", "rural", "rusty", "sadly", "saint", "salad", "sauce", "savor", "scale",
    "scene", "scope", "score", "scout", "sense", "serve", "setup", "seven", "shade",
    "shake", "shall", "shape", "share", "shark", "sharp", "shave", "shelf", "shell",
    "shift", "shine", "shirt", "shore", "short", "sight", "sigma", "sixth", "sixty",
    "skill", "skull", "slate", "sleep", "slide", "slope", "smart", "smell", "smile",
    "smoke", "snake", "solar", "solid", "solve", "sorry", "south", "space", "spark",
    "speak", "speed", "spend", "spill", "spoke", "spoon", "spray", "squad", "stack",
    "staff", "stage", "stake", "stale", "stall", "stamp", "stand", "start", "state",
    "steam", "steel", "steep", "steer", "sting", "stock", "stone", "stood", "store",
    "storm", "story", "stove", "strap", "straw", "strip", "stuck", "study", "stuff",
    "style", "sugar", "super", "surge", "sword", "table", "taunt", "teach", "teeth",
    "thank", "theme", "there", "thick", "thing", "third", "those", "three", "threw",
    "throw", "thumb", "timer", "tired", "title", "today", "token", "toner", "topic",
    "total", "touch", "tough", "towel", "tower", "trace", "track", "trade", "trail",
    "train", "trait", "tread", "treat", "trend", "trial", "tribe", "trick", "tried",
    "troop", "truck", "truly", "trump", "trunk", "trust", "truth", "tumor", "tutor",
    "tweak", "twice", "twist", "tying", "ultra", "under", "unify", "union", "until",
    "upper", "urban", "usage", "valid", "value", "valve", "video", "vigor", "viral",
    "virus", "visit", "visor", "vista", "vital", "vivid", "vocal", "voice", "vowed",
    "wagon", "water", "weary", "weave", "weigh", "weird", "where", "which", "while",
    "white", "whole", "whose", "wider", "witch", "witty", "woman", "women", "world",
    "worry", "worth", "would", "wound", "wrath", "write", "wrote", "yacht", "yield",
    "young", "youth",
];

const UPPER: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const LOWER: &[u8] = b"abcdefghijklmnopqrstuvwxyz";
const NUMBERS: &[u8] = b"0123456789";
const SYMBOLS: &[u8] = b"!@#$%^&*()_+-=[]{}|;:,.<>?";

/// Generate a random password according to `options`.
///
/// If no character class is enabled the generator falls back to using all four
/// classes so that it never returns an empty or degenerate password.
pub fn generate_password(options: &PasswordGeneratorOptions) -> String {
    let mut rng = rand::thread_rng();

    // Collect enabled character sets.
    let mut charset: Vec<u8> = Vec::new();
    let mut guaranteed: Vec<u8> = Vec::new(); // one char from each required class

    let use_upper = options.uppercase;
    let use_lower = options.lowercase;
    let use_numbers = options.numbers;
    let use_symbols = options.symbols;

    // If nothing is enabled fall back to all classes.
    let (use_upper, use_lower, use_numbers, use_symbols) =
        if !use_upper && !use_lower && !use_numbers && !use_symbols {
            (true, true, true, true)
        } else {
            (use_upper, use_lower, use_numbers, use_symbols)
        };

    if use_upper {
        charset.extend_from_slice(UPPER);
        guaranteed.push(*UPPER.choose(&mut rng).unwrap());
    }
    if use_lower {
        charset.extend_from_slice(LOWER);
        guaranteed.push(*LOWER.choose(&mut rng).unwrap());
    }
    if use_numbers {
        charset.extend_from_slice(NUMBERS);
        guaranteed.push(*NUMBERS.choose(&mut rng).unwrap());
    }
    if use_symbols {
        charset.extend_from_slice(SYMBOLS);
        guaranteed.push(*SYMBOLS.choose(&mut rng).unwrap());
    }

    let length = options.length as usize;

    // Fill the remaining slots with random characters from the full charset.
    let remaining = length.saturating_sub(guaranteed.len());
    let mut password_bytes: Vec<u8> = (0..remaining)
        .map(|_| *charset.choose(&mut rng).unwrap())
        .collect();

    password_bytes.extend_from_slice(&guaranteed);
    password_bytes.shuffle(&mut rng);

    // Safety: all bytes come from ASCII literals.
    String::from_utf8(password_bytes).expect("password bytes are valid ASCII")
}

/// Calculate a strength score for the given password.
///
/// Each criterion grants +1 to the score:
/// 1. length >= 8
/// 2. length >= 12
/// 3. length >= 16
/// 4. contains both uppercase and lowercase letters
/// 5. contains at least one digit
/// 6. contains at least one special character
///
/// Score → label mapping:
/// 0 → "未知", 1 → "弱", 2 → "一般", 3 → "良好", 4 → "强", 5 → "极强"
pub fn calculate_password_strength(password: &str) -> PasswordStrength {
    let len = password.len();

    let mut score: u32 = 0;

    if len >= 8 {
        score += 1;
    }
    if len >= 12 {
        score += 1;
    }
    if len >= 16 {
        score += 1;
    }

    let has_upper = password.chars().any(|c| c.is_uppercase());
    let has_lower = password.chars().any(|c| c.is_lowercase());
    if has_upper && has_lower {
        score += 1;
    }

    if password.chars().any(|c| c.is_ascii_digit()) {
        score += 1;
    }

    if password.chars().any(|c| !c.is_alphanumeric()) {
        score += 1;
    }

    let label = match score {
        0 => "未知",
        1 => "弱",
        2 => "一般",
        3 => "良好",
        4 => "强",
        _ => "极强",
    }
    .to_string();

    PasswordStrength { score, label }
}

/// Generate a numeric-only PIN of the specified length (defaults to 6 if `length` is 0).
pub fn generate_pin(length: u32) -> String {
    let length = if length == 0 { 6 } else { length } as usize;
    let mut rng = rand::thread_rng();
    (0..length)
        .map(|_| rng.gen_range(b'0'..=b'9') as char)
        .collect()
}

/// Generate a memorable passphrase like "correct-horse-battery-staple".
///
/// Words are chosen randomly from the built-in `WORD_LIST`.
/// If `capitalize` is true the first letter of every word is uppercased.
/// `word_count` defaults to 4 if 0 is passed.
pub fn generate_memorable_password(word_count: u32, separator: &str, capitalize: bool) -> String {
    let word_count = if word_count == 0 { 4 } else { word_count } as usize;
    let mut rng = rand::thread_rng();
    let words: Vec<String> = (0..word_count)
        .map(|_| {
            let word = WORD_LIST.choose(&mut rng).copied().unwrap_or("word");
            if capitalize {
                let mut chars = word.chars();
                match chars.next() {
                    None => String::new(),
                    Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
                }
            } else {
                word.to_string()
            }
        })
        .collect();
    words.join(separator)
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn default_opts() -> PasswordGeneratorOptions {
        PasswordGeneratorOptions::default()
    }

    #[test]
    fn test_generated_password_length() {
        let opts = PasswordGeneratorOptions {
            length: 20,
            ..default_opts()
        };
        let pwd = generate_password(&opts);
        assert_eq!(pwd.len(), 20);
    }

    #[test]
    fn test_generated_password_contains_required_classes() {
        let opts = PasswordGeneratorOptions {
            length: 32,
            uppercase: true,
            lowercase: true,
            numbers: true,
            symbols: true,
        };
        let pwd = generate_password(&opts);
        assert!(pwd.chars().any(|c| c.is_uppercase()), "missing uppercase");
        assert!(pwd.chars().any(|c| c.is_lowercase()), "missing lowercase");
        assert!(pwd.chars().any(|c| c.is_ascii_digit()), "missing digit");
        assert!(
            pwd.chars().any(|c| !c.is_alphanumeric()),
            "missing symbol"
        );
    }

    #[test]
    fn test_generated_password_only_uppercase_and_digits() {
        let opts = PasswordGeneratorOptions {
            length: 16,
            uppercase: true,
            lowercase: false,
            numbers: true,
            symbols: false,
        };
        let pwd = generate_password(&opts);
        assert_eq!(pwd.len(), 16);
        for c in pwd.chars() {
            assert!(
                c.is_ascii_uppercase() || c.is_ascii_digit(),
                "unexpected char: {}",
                c
            );
        }
    }

    #[test]
    fn test_fallback_when_all_disabled() {
        let opts = PasswordGeneratorOptions {
            length: 10,
            uppercase: false,
            lowercase: false,
            numbers: false,
            symbols: false,
        };
        let pwd = generate_password(&opts);
        assert_eq!(pwd.len(), 10);
        assert!(!pwd.is_empty());
    }

    #[test]
    fn test_passwords_are_random() {
        let opts = default_opts();
        let p1 = generate_password(&opts);
        let p2 = generate_password(&opts);
        // Statistically extremely unlikely to be equal.
        assert_ne!(p1, p2);
    }

    #[test]
    fn test_strength_weak() {
        let s = calculate_password_strength("abc");
        assert_eq!(s.score, 0);
        assert_eq!(s.label, "未知");
    }

    #[test]
    fn test_strength_short_mixed() {
        // length >= 8 (+1), upper+lower (+1) = 2
        let s = calculate_password_strength("Abcdefgh");
        assert_eq!(s.score, 2);
        assert_eq!(s.label, "一般");
    }

    #[test]
    fn test_strength_strong() {
        // length >= 8(+1), >= 12(+1), >= 16(+1), upper+lower(+1), digit(+1), symbol(+1) = 6 → "极强"
        let s = calculate_password_strength("Abcdefgh1!XyZq@$");
        assert_eq!(s.score, 6);
        assert_eq!(s.label, "极强");
    }

    #[test]
    fn test_strength_no_special() {
        // "Password123" → len 11 → >=8(+1), upper+lower(+1), digit(+1) = 3 → "良好"
        let s = calculate_password_strength("Password123");
        assert_eq!(s.score, 3);
        assert_eq!(s.label, "良好");
    }

    #[test]
    fn test_generate_pin_length() {
        for len in [4u32, 6, 8, 12] {
            let pin = generate_pin(len);
            assert_eq!(pin.len(), len as usize, "pin length mismatch for {len}");
            assert!(pin.chars().all(|c| c.is_ascii_digit()), "non-digit in pin: {pin}");
        }
    }

    #[test]
    fn test_generate_pin_default_length() {
        let pin = generate_pin(0);
        assert_eq!(pin.len(), 6);
    }

    #[test]
    fn test_generate_pin_randomness() {
        let p1 = generate_pin(8);
        let p2 = generate_pin(8);
        // Extremely unlikely to collide for 8-digit PINs (1 in 100 million).
        assert_ne!(p1, p2);
    }

    #[test]
    fn test_generate_memorable_word_count() {
        let pwd = generate_memorable_password(4, "-", false);
        let parts: Vec<&str> = pwd.split('-').collect();
        assert_eq!(parts.len(), 4);
    }

    #[test]
    fn test_generate_memorable_separator() {
        let pwd = generate_memorable_password(3, ".", false);
        assert!(pwd.contains('.'));
        assert_eq!(pwd.split('.').count(), 3);
    }

    #[test]
    fn test_generate_memorable_capitalize() {
        let pwd = generate_memorable_password(4, "-", true);
        for word in pwd.split('-') {
            let first = word.chars().next().unwrap();
            assert!(first.is_uppercase(), "word not capitalized: {word}");
        }
    }

    #[test]
    fn test_generate_memorable_no_capitalize() {
        let pwd = generate_memorable_password(4, "-", false);
        for word in pwd.split('-') {
            let first = word.chars().next().unwrap();
            assert!(first.is_lowercase(), "word should be lowercase: {word}");
        }
    }

    #[test]
    fn test_generate_memorable_default_count() {
        let pwd = generate_memorable_password(0, "-", false);
        assert_eq!(pwd.split('-').count(), 4);
    }

    #[test]
    fn test_word_list_coverage() {
        assert!(WORD_LIST.len() >= 400, "word list too small: {}", WORD_LIST.len());
        for word in WORD_LIST {
            let len = word.len();
            assert!((4..=8).contains(&len), "word out of range: {word}");
        }
    }
}
