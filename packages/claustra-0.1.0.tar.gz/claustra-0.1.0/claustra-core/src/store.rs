use base64::{engine::general_purpose::STANDARD, Engine};
use chrono::Utc;
use serde::{Deserialize, Serialize};

use crate::crypto;
use crate::database::{Database, ItemRowV1};
use crate::error::{Result, ClaustraError};
use crate::import_export;
use crate::models::{
    Attachment, Category, CustomField, FaviconEntry, Folder, PasswordGeneratorOptions,
    PasswordHistoryEntry, PasswordItem, PasswordStrength, SecurityQuestion,
};
use crate::password_generator;
use crate::totp;

// ---------------------------------------------------------------------------
// Sensitive data blob (v1 encryption)
// ---------------------------------------------------------------------------

#[derive(Serialize, Deserialize)]
struct SensitiveData {
    title: String,
    username: String,
    password: String,
    website: String,
    notes: String,
    tags: Vec<String>,
    totp_secret: String,
    security_questions: Vec<SecurityQuestion>,
    custom_fields: Vec<CustomField>,
    password_history: Vec<PasswordHistoryEntry>,
    expires_at: String,
    icon_emoji: String,
    icon_bg_color: String,
}

// ---------------------------------------------------------------------------
// Module-level helpers for v1 item construction
// ---------------------------------------------------------------------------

fn extract_sensitive(item: &PasswordItem) -> SensitiveData {
    SensitiveData {
        title: item.title.clone(),
        username: item.username.clone(),
        password: item.password.clone(),
        website: item.website.clone(),
        notes: item.notes.clone(),
        tags: item.tags.clone(),
        totp_secret: item.totp_secret.clone(),
        security_questions: item.security_questions.clone(),
        custom_fields: item.custom_fields.clone(),
        password_history: item.password_history.clone(),
        expires_at: item.expires_at.clone(),
        icon_emoji: item.icon_emoji.clone(),
        icon_bg_color: item.icon_bg_color.clone(),
    }
}

fn reconstruct_item(row: &ItemRowV1, sensitive: SensitiveData) -> PasswordItem {
    PasswordItem {
        id: row.id.clone(),
        title: sensitive.title,
        username: sensitive.username,
        password: sensitive.password,
        website: sensitive.website,
        notes: sensitive.notes,
        category: row.category.parse().unwrap_or(Category::Logins),
        is_favorite: row.is_favorite,
        is_pinned: row.is_pinned,
        icon_emoji: sensitive.icon_emoji,
        icon_bg_color: sensitive.icon_bg_color,
        tags: sensitive.tags,
        security_questions: sensitive.security_questions,
        custom_fields: sensitive.custom_fields,
        password_history: sensitive.password_history,
        totp_secret: sensitive.totp_secret,
        expires_at: sensitive.expires_at,
        folder_id: row.folder_id.clone(),
        created_at: row.created_at.clone(),
        updated_at: row.updated_at.clone(),
        deleted_at: row.deleted_at.clone(),
        archived_at: row.archived_at.clone(),
    }
}

/// The main password store facade.
///
/// Wraps the database, encryption layer, and all sub-modules behind a single
/// coherent API. All methods that touch password data require the store to be
/// unlocked first.
pub struct PasswordStore {
    db: Database,
    encryption_key: Option<[u8; 32]>,       // v0 key (keep for backward compat)
    master_password_hash: Option<String>,     // v0 hash (keep for backward compat)
    vault_key: Option<[u8; 32]>,             // v1 vault key
}

// ---------------------------------------------------------------------------
// Construction
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Open (or create) a file-backed store at `db_path`.
    pub fn new(db_path: &str) -> Result<Self> {
        Ok(Self {
            db: Database::new(db_path)?,
            encryption_key: None,
            master_password_hash: None,
            vault_key: None,
        })
    }

    /// Create an in-memory store (useful for tests).
    pub fn new_in_memory() -> Result<Self> {
        Ok(Self {
            db: Database::new_in_memory()?,
            encryption_key: None,
            master_password_hash: None,
            vault_key: None,
        })
    }
}

// ---------------------------------------------------------------------------
// Authentication
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Set up the master password for a brand-new store.
    ///
    /// Stores the Argon2 PHC hash in the settings table and derives the
    /// encryption key.
    pub fn setup_master_password(&mut self, password: &str) -> Result<()> {
        let hash = crypto::hash_master_password(password)?;
        self.db.set_setting("master_password_hash", &hash)?;
        self.master_password_hash = Some(hash);

        let key = self.derive_key(password)?;
        self.encryption_key = Some(key);
        Ok(())
    }

    /// Attempt to unlock the store with the given password.
    ///
    /// Returns `true` if the password is correct and the store is now unlocked.
    pub fn unlock(&mut self, password: &str) -> Result<bool> {
        let hash = self
            .db
            .get_setting("master_password_hash")?
            .ok_or(ClaustraError::InvalidMasterPassword)?;

        if !crypto::verify_master_password(password, &hash)? {
            return Ok(false);
        }

        let key = self.derive_key(password)?;
        self.encryption_key = Some(key);
        self.master_password_hash = Some(hash);
        Ok(true)
    }

    /// Clear the encryption key (lock the store).
    pub fn lock(&mut self) {
        self.encryption_key = None;
    }

    /// Returns `true` if the store has been unlocked.
    pub fn is_unlocked(&self) -> bool {
        self.encryption_key.is_some()
    }

    /// Returns `true` if a master password has ever been set.
    pub fn is_setup(&self) -> Result<bool> {
        Ok(self.db.get_setting("master_password_hash")?.is_some())
    }

    /// Derive a 32-byte AES-256 key from the master password.
    ///
    /// We use a fixed application salt so that the same password always
    /// produces the same key (the password hash itself is stored separately
    /// and uses a random salt for verification security).
    fn derive_key(&self, password: &str) -> Result<[u8; 32]> {
        // Fixed application salt — distinct from the Argon2 verification salt.
        const KEY_SALT: &[u8] = b"SwiftPasswordKeyDerivation_v1___"; // 32 bytes
        crypto::derive_encryption_key(password, KEY_SALT)
    }
}

// ---------------------------------------------------------------------------
// Encryption helpers
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Return a reference to the current encryption key, or an error if
    /// the store is locked.
    fn key(&self) -> Result<&[u8; 32]> {
        self.encryption_key
            .as_ref()
            .ok_or(ClaustraError::InvalidMasterPassword)
    }

    /// Clone `item` and encrypt its `password` field.
    fn encrypt_item(&self, item: &PasswordItem) -> Result<PasswordItem> {
        let key = self.key()?;
        let mut encrypted = item.clone();
        if !item.password.is_empty() {
            encrypted.password = crypto::encrypt(&item.password, key)?;
        }
        Ok(encrypted)
    }

    /// Clone `item` and decrypt its `password` field.
    fn decrypt_item(&self, item: &PasswordItem) -> Result<PasswordItem> {
        let key = self.key()?;
        let mut decrypted = item.clone();
        if !item.password.is_empty() {
            decrypted.password = crypto::decrypt(&item.password, key)?;
        }
        Ok(decrypted)
    }
}

// ---------------------------------------------------------------------------
// Items
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Encrypt and persist a new item.
    pub fn create_item(&self, item: &PasswordItem) -> Result<()> {
        let encrypted = self.encrypt_item(item)?;
        self.db.insert_item(&encrypted)
    }

    /// Fetch and decrypt a single item by id.
    pub fn get_item(&self, id: &str) -> Result<PasswordItem> {
        let raw = self.db.get_item(id)?;
        self.decrypt_item(&raw)
    }

    /// Fetch and decrypt all active (non-deleted) items.
    pub fn get_all_items(&self) -> Result<Vec<PasswordItem>> {
        self.db
            .get_active_items()?
            .iter()
            .map(|raw| self.decrypt_item(raw))
            .collect()
    }

    /// Update an existing item.
    ///
    /// If the plaintext password has changed, the old password is appended to
    /// the item's `password_history` before saving.
    pub fn update_item(&self, item: &PasswordItem) -> Result<()> {
        // Fetch the old encrypted version to compare.
        let old_raw = self.db.get_item(&item.id)?;
        let old_decrypted = self.decrypt_item(&old_raw)?;

        let mut updated = item.clone();

        // Track password changes.
        if !old_decrypted.password.is_empty() && old_decrypted.password != item.password {
            updated.password_history.push(PasswordHistoryEntry {
                password: old_decrypted.password,
                changed_at: Utc::now().to_rfc3339(),
            });
        }

        let encrypted = self.encrypt_item(&updated)?;
        self.db.update_item(&encrypted)
    }

    /// Soft-delete an item (moves it to trash).
    pub fn delete_item(&self, id: &str) -> Result<()> {
        self.db.soft_delete_item(id)
    }

    /// Restore a soft-deleted item from trash.
    pub fn restore_item(&self, id: &str) -> Result<()> {
        self.db.restore_item(id)
    }

    /// Permanently delete an item (cannot be undone).
    pub fn permanently_delete_item(&self, id: &str) -> Result<()> {
        self.db.permanently_delete_item(id)
    }

    /// Permanently delete all trashed items. Returns the number deleted.
    pub fn empty_trash(&self) -> Result<u64> {
        self.db.empty_trash()
    }

    /// Fetch and decrypt all trashed items.
    pub fn get_trashed_items(&self) -> Result<Vec<PasswordItem>> {
        self.db
            .get_trashed_items()?
            .iter()
            .map(|raw| self.decrypt_item(raw))
            .collect()
    }

    /// Full-text search across active items.
    pub fn search_items(&self, query: &str) -> Result<Vec<PasswordItem>> {
        self.db
            .search_items(query)?
            .iter()
            .map(|raw| self.decrypt_item(raw))
            .collect()
    }
}

// ---------------------------------------------------------------------------
// Folders
// ---------------------------------------------------------------------------

impl PasswordStore {
    pub fn create_folder(&self, folder: &Folder) -> Result<()> {
        self.db.insert_folder(folder)
    }

    pub fn get_all_folders(&self) -> Result<Vec<Folder>> {
        self.db.get_all_folders()
    }

    pub fn update_folder(&self, folder: &Folder) -> Result<()> {
        self.db.update_folder(folder)
    }

    pub fn delete_folder(&self, id: &str) -> Result<()> {
        self.db.delete_folder(id)
    }
}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Generate a random password according to the provided options.
    pub fn generate_password(&self, options: &PasswordGeneratorOptions) -> String {
        password_generator::generate_password(options)
    }

    /// Calculate the strength of the given password.
    pub fn calculate_strength(&self, password: &str) -> PasswordStrength {
        password_generator::calculate_password_strength(password)
    }

    /// Generate a numeric-only PIN of the specified length.
    pub fn generate_pin(&self, length: u32) -> String {
        password_generator::generate_pin(length)
    }

    /// Generate a memorable passphrase (e.g. "correct-horse-battery-staple").
    pub fn generate_memorable_password(&self, word_count: u32, separator: &str, capitalize: bool) -> String {
        password_generator::generate_memorable_password(word_count, separator, capitalize)
    }

    /// Generate a TOTP code from a base32-encoded secret.
    ///
    /// Returns `(code, remaining_seconds)`.
    pub fn generate_totp(&self, secret: &str) -> Result<(String, u32)> {
        totp::generate_totp(secret)
    }
}

// ---------------------------------------------------------------------------
// Import / Export
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Export all active items as a pretty-printed JSON string.
    pub fn export_json(&self) -> Result<String> {
        let items = self.get_all_items()?;
        import_export::export_json(&items)
    }

    /// Export all active items as a CSV string.
    pub fn export_csv(&self) -> Result<String> {
        let items = self.get_all_items()?;
        import_export::export_csv(&items)
    }

    /// Import items from a JSON string. Returns the number of items imported.
    pub fn import_json(&self, json_str: &str) -> Result<usize> {
        let items = import_export::import_json(json_str)?;
        let count = items.len();
        for item in &items {
            self.create_item(item)?;
        }
        Ok(count)
    }

    /// Import items from a CSV string. Returns the number of items imported.
    pub fn import_csv(&self, csv_str: &str) -> Result<usize> {
        let items = import_export::import_csv(csv_str)?;
        let count = items.len();
        for item in &items {
            self.create_item(item)?;
        }
        Ok(count)
    }

    /// Import items from a 1Password `.1pux` ZIP archive.
    /// Returns the number of items imported.
    pub fn import_1pux(&self, zip_data: &[u8]) -> Result<usize> {
        let items = import_export::import_1pux(zip_data)?;
        let count = items.len();
        for item in &items {
            self.create_item(item)?;
        }
        Ok(count)
    }

    /// Import items from a Bitwarden unencrypted JSON export.
    /// Returns the number of items imported.
    pub fn import_bitwarden(&self, json_str: &str) -> Result<usize> {
        let items = import_export::import_bitwarden_json(json_str)?;
        let count = items.len();
        for item in &items {
            self.create_item(item)?;
        }
        Ok(count)
    }

    /// Import items from a LastPass CSV export.
    /// Returns the number of items imported.
    pub fn import_lastpass(&self, csv_str: &str) -> Result<usize> {
        let items = import_export::import_lastpass_csv(csv_str)?;
        let count = items.len();
        for item in &items {
            self.create_item(item)?;
        }
        Ok(count)
    }

    /// Import items from a KeePass KDBX database (raw bytes).
    /// Returns the number of items imported.
    pub fn import_keepass(&self, data: &[u8], password: &str) -> Result<usize> {
        let items = import_export::import_keepass(data, password)?;
        let count = items.len();
        for item in &items {
            self.create_item(item)?;
        }
        Ok(count)
    }
}

// ---------------------------------------------------------------------------
// Favicon
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Retrieve a cached favicon for the given domain.
    pub fn get_favicon(&self, domain: &str) -> Result<Option<FaviconEntry>> {
        self.db.get_favicon(domain)
    }

    /// Store (or update) a favicon cache entry.
    pub fn cache_favicon(&self, entry: &FaviconEntry) -> Result<()> {
        self.db.upsert_favicon(entry)
    }
}

// ---------------------------------------------------------------------------
// V1 key hierarchy methods
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Set up the v1 master password with the layered key hierarchy.
    ///
    /// Derives master key → auth key + KEK, generates a random vault key,
    /// wraps it with the KEK, then persists auth_key and wrapped_vault_key
    /// in the settings table.
    pub fn setup_master_password_v1(
        &mut self,
        password: &str,
        device_secret: &[u8],
    ) -> Result<()> {
        let master_key = crypto::derive_master_key(password, device_secret)?;
        let auth_key = crypto::derive_auth_key(&master_key)?;
        let kek = crypto::derive_kek(&master_key)?;

        let vault_key_bytes = crypto::generate_random_bytes(32);
        let mut vault_key = [0u8; 32];
        vault_key.copy_from_slice(&vault_key_bytes);

        let wrapped = crypto::wrap_vault_key(&kek, &vault_key)?;

        self.db.set_setting("auth_key", &STANDARD.encode(&auth_key))?;
        self.db
            .set_setting("wrapped_vault_key", &STANDARD.encode(&wrapped))?;
        self.db.set_setting("kdf_algorithm", "argon2id")?;
        self.db.set_setting(
            "kdf_params",
            r#"{"memory":65536,"iterations":3,"parallelism":4}"#,
        )?;

        self.vault_key = Some(vault_key);
        Ok(())
    }

    /// Attempt to unlock the v1 store with the given password and device secret.
    ///
    /// Returns `true` if the password + device_secret combination is correct
    /// and the vault key has been successfully recovered.
    pub fn unlock_v1(&mut self, password: &str, device_secret: &[u8]) -> Result<bool> {
        let stored_auth_b64 = self
            .db
            .get_setting("auth_key")?
            .ok_or(ClaustraError::InvalidMasterPassword)?;
        let stored_auth = STANDARD
            .decode(&stored_auth_b64)
            .map_err(|e| ClaustraError::Encryption(format!("base64 decode auth_key: {}", e)))?;

        let wrapped_b64 = self
            .db
            .get_setting("wrapped_vault_key")?
            .ok_or(ClaustraError::InvalidMasterPassword)?;
        let wrapped_bytes = STANDARD
            .decode(&wrapped_b64)
            .map_err(|e| {
                ClaustraError::Encryption(format!("base64 decode wrapped_vault_key: {}", e))
            })?;

        let master_key = crypto::derive_master_key(password, device_secret)?;

        // Try new auth key first (current derivation with "claustra-v1-auth")
        let derived_auth = crypto::derive_auth_key(&master_key)?;
        if crypto::constant_time_eq(&derived_auth, &stored_auth) {
            let kek = crypto::derive_kek(&master_key)?;
            let unwrapped = crypto::unwrap_vault_key(&kek, &wrapped_bytes)?;
            self.vault_key = Some(unwrapped);
            return Ok(true);
        }

        // Fall back to legacy auth key ("swiftpassword-v1-auth") for migration
        let derived_auth_legacy = crypto::derive_auth_key_legacy(&master_key)?;
        if crypto::constant_time_eq(&derived_auth_legacy, &stored_auth) {
            // Use legacy KEK since the wrapped key was created with the old KEK
            let legacy_kek = crypto::derive_kek_legacy(&master_key)?;
            let vault_key = crypto::unwrap_vault_key(&legacy_kek, &wrapped_bytes)?;

            // Transparent migration: re-derive with new strings and update DB
            let new_auth = crypto::derive_auth_key(&master_key)?;
            let new_kek = crypto::derive_kek(&master_key)?;
            let new_wrapped = crypto::wrap_vault_key(&new_kek, &vault_key)?;
            self.db
                .set_setting("auth_key", &STANDARD.encode(&new_auth))?;
            self.db
                .set_setting("wrapped_vault_key", &STANDARD.encode(&new_wrapped))?;

            self.vault_key = Some(vault_key);
            return Ok(true);
        }

        Ok(false)
    }

    /// Directly unlock with a vault key (e.g. recovered from Keychain for biometric auth).
    pub fn unlock_with_vault_key(&mut self, vault_key: [u8; 32]) {
        self.vault_key = Some(vault_key);
    }

    /// Return a reference to the current vault key so Swift can persist it in Keychain.
    pub fn get_vault_key(&self) -> Option<&[u8; 32]> {
        self.vault_key.as_ref()
    }

    /// Clear the vault key (lock the v1 store).
    pub fn lock_v1(&mut self) {
        self.vault_key = None;
    }

    /// Returns `true` if the v1 store is currently unlocked.
    pub fn is_unlocked_v1(&self) -> bool {
        self.vault_key.is_some()
    }

    /// Returns `true` if the v1 master password has been set up (auth_key and
    /// wrapped_vault_key both exist in the settings table).
    pub fn is_setup_v1(&self) -> Result<bool> {
        let has_auth = self.db.get_setting("auth_key")?.is_some();
        let has_wrapped = self.db.get_setting("wrapped_vault_key")?.is_some();
        Ok(has_auth && has_wrapped)
    }

    /// Change the v1 master password.
    ///
    /// Verifies the old password, unwraps the vault key, re-wraps it with a new
    /// KEK derived from the new password, and updates the DB settings.
    /// The in-memory vault key is preserved unchanged (it's the same vault key).
    pub fn change_password_v1(
        &mut self,
        old_password: &str,
        new_password: &str,
        device_secret: &[u8],
    ) -> Result<()> {
        // Verify old password
        let stored_auth_b64 = self
            .db
            .get_setting("auth_key")?
            .ok_or(ClaustraError::InvalidMasterPassword)?;
        let stored_auth = STANDARD
            .decode(&stored_auth_b64)
            .map_err(|e| ClaustraError::Encryption(format!("base64 decode: {}", e)))?;

        let old_master = crypto::derive_master_key(old_password, device_secret)?;
        let old_auth = crypto::derive_auth_key(&old_master)?;

        // Determine which KEK was used to wrap the vault key (new or legacy)
        let old_kek = if crypto::constant_time_eq(&old_auth, &stored_auth) {
            crypto::derive_kek(&old_master)?
        } else {
            // Try legacy derivation for migration from SwiftPassword
            let old_auth_legacy = crypto::derive_auth_key_legacy(&old_master)?;
            if crypto::constant_time_eq(&old_auth_legacy, &stored_auth) {
                crypto::derive_kek_legacy(&old_master)?
            } else {
                return Err(ClaustraError::InvalidMasterPassword);
            }
        };

        // Recover vault key using the appropriate KEK
        let wrapped_b64 = self
            .db
            .get_setting("wrapped_vault_key")?
            .ok_or(ClaustraError::InvalidMasterPassword)?;
        let wrapped_bytes = STANDARD
            .decode(&wrapped_b64)
            .map_err(|e| ClaustraError::Encryption(format!("base64 decode: {}", e)))?;

        let vault_key = crypto::unwrap_vault_key(&old_kek, &wrapped_bytes)?;

        // Derive new keys
        let new_master = crypto::derive_master_key(new_password, device_secret)?;
        let new_auth = crypto::derive_auth_key(&new_master)?;
        let new_kek = crypto::derive_kek(&new_master)?;

        // Re-wrap the same vault key with the new KEK
        let new_wrapped = crypto::wrap_vault_key(&new_kek, &vault_key)?;

        // Persist
        self.db
            .set_setting("auth_key", &STANDARD.encode(&new_auth))?;
        self.db
            .set_setting("wrapped_vault_key", &STANDARD.encode(&new_wrapped))?;

        // Keep the in-memory vault key unchanged
        Ok(())
    }

    // -----------------------------------------------------------------------
    // V1 vault key helper
    // -----------------------------------------------------------------------

    fn vault_key_ref(&self) -> Result<&[u8; 32]> {
        self.vault_key
            .as_ref()
            .ok_or(ClaustraError::InvalidMasterPassword)
    }
}

// ---------------------------------------------------------------------------
// V1 Item CRUD
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Encrypt and persist a new item using the v1 scheme.
    pub fn create_item_v1(&self, item: &PasswordItem) -> Result<()> {
        let vault_key = self.vault_key_ref()?;
        let sensitive = extract_sensitive(item);
        let json = serde_json::to_string(&sensitive)
            .map_err(|e| ClaustraError::Encryption(format!("serialize: {}", e)))?;
        let encrypted_data = crypto::encrypt_blob(vault_key, &json, &item.id)?;

        let row = ItemRowV1 {
            id: item.id.clone(),
            category: item.category.to_string(),
            is_favorite: item.is_favorite,
            is_pinned: item.is_pinned,
            folder_id: item.folder_id.clone(),
            encrypted_data,
            created_at: item.created_at.clone(),
            updated_at: item.updated_at.clone(),
            deleted_at: item.deleted_at.clone(),
            sync_version: 0,
            archived_at: None,
        };
        self.db.insert_item_v1(&row)
    }

    /// Fetch and decrypt a single v1 item by id.
    pub fn get_item_v1(&self, id: &str) -> Result<PasswordItem> {
        let vault_key = self.vault_key_ref()?;
        let row = self.db.get_item_v1(id)?;
        let json = crypto::decrypt_blob(vault_key, &row.encrypted_data, &row.id)?;
        let sensitive: SensitiveData = serde_json::from_str(&json)
            .map_err(|e| ClaustraError::Encryption(format!("deserialize: {}", e)))?;
        Ok(reconstruct_item(&row, sensitive))
    }

    /// Fetch and decrypt all active v1 items.
    pub fn get_all_items_v1(&self) -> Result<Vec<PasswordItem>> {
        let vault_key = self.vault_key_ref()?;
        self.db
            .get_active_items_v1()?
            .iter()
            .map(|row| {
                let json = crypto::decrypt_blob(vault_key, &row.encrypted_data, &row.id)?;
                let sensitive: SensitiveData = serde_json::from_str(&json)
                    .map_err(|e| ClaustraError::Encryption(format!("deserialize: {}", e)))?;
                Ok(reconstruct_item(row, sensitive))
            })
            .collect()
    }

    /// Update an existing v1 item, tracking password history if the password changed.
    pub fn update_item_v1(&self, item: &PasswordItem) -> Result<()> {
        let vault_key = self.vault_key_ref()?;

        // Fetch old version to check for password change
        let old_row = self.db.get_item_v1(&item.id)?;
        let old_json = crypto::decrypt_blob(vault_key, &old_row.encrypted_data, &old_row.id)?;
        let old_sensitive: SensitiveData = serde_json::from_str(&old_json)
            .map_err(|e| ClaustraError::Encryption(format!("deserialize: {}", e)))?;

        let mut updated = item.clone();

        // Track password changes
        if !old_sensitive.password.is_empty() && old_sensitive.password != item.password {
            updated.password_history.push(PasswordHistoryEntry {
                password: old_sensitive.password,
                changed_at: Utc::now().to_rfc3339(),
            });
        }

        let sensitive = extract_sensitive(&updated);
        let json = serde_json::to_string(&sensitive)
            .map_err(|e| ClaustraError::Encryption(format!("serialize: {}", e)))?;
        let encrypted_data = crypto::encrypt_blob(vault_key, &json, &updated.id)?;

        let row = ItemRowV1 {
            id: updated.id.clone(),
            category: updated.category.to_string(),
            is_favorite: updated.is_favorite,
            is_pinned: updated.is_pinned,
            folder_id: updated.folder_id.clone(),
            encrypted_data,
            created_at: updated.created_at.clone(),
            updated_at: Utc::now().to_rfc3339(),
            deleted_at: updated.deleted_at.clone(),
            sync_version: 0, // sync_version is incremented by the DB layer; this value is ignored
            archived_at: old_row.archived_at.clone(),
        };
        self.db.update_item_v1(&row)
    }

    /// Soft-delete a v1 item (moves it to trash).
    pub fn delete_item_v1(&self, id: &str) -> Result<()> {
        self.db.soft_delete_item_v1(id)
    }

    /// Restore a soft-deleted v1 item from trash.
    pub fn restore_item_v1(&self, id: &str) -> Result<()> {
        self.db.restore_item_v1(id)
    }

    /// Permanently delete a v1 item (cannot be undone).
    pub fn permanently_delete_item_v1(&self, id: &str) -> Result<()> {
        self.db.permanently_delete_item_v1(id)
    }

    /// Permanently delete all trashed v1 items. Returns the number deleted.
    pub fn empty_trash_v1(&self) -> Result<u64> {
        self.db.empty_trash_v1()
    }

    /// Fetch and decrypt all trashed v1 items.
    pub fn get_trashed_items_v1(&self) -> Result<Vec<PasswordItem>> {
        let vault_key = self.vault_key_ref()?;
        self.db
            .get_trashed_items_v1()?
            .iter()
            .map(|row| {
                let json = crypto::decrypt_blob(vault_key, &row.encrypted_data, &row.id)?;
                let sensitive: SensitiveData = serde_json::from_str(&json)
                    .map_err(|e| ClaustraError::Encryption(format!("deserialize: {}", e)))?;
                Ok(reconstruct_item(row, sensitive))
            })
            .collect()
    }

    /// Archive a v1 item (moves it out of the active list without trashing).
    pub fn archive_item_v1(&self, id: &str) -> Result<()> {
        self.db.archive_item_v1(id)
    }

    /// Unarchive a v1 item, returning it to the active list.
    pub fn unarchive_item_v1(&self, id: &str) -> Result<()> {
        self.db.unarchive_item_v1(id)
    }

    /// Fetch and decrypt all archived v1 items.
    pub fn get_archived_items_v1(&self) -> Result<Vec<PasswordItem>> {
        let vault_key = self.vault_key_ref()?;
        self.db
            .get_archived_items_v1()?
            .iter()
            .map(|row| {
                let json = crypto::decrypt_blob(vault_key, &row.encrypted_data, &row.id)?;
                let sensitive: SensitiveData = serde_json::from_str(&json)
                    .map_err(|e| ClaustraError::Encryption(format!("deserialize: {}", e)))?;
                Ok(reconstruct_item(row, sensitive))
            })
            .collect()
    }

    /// Count all active (non-deleted, non-archived) items without decrypting.
    pub fn count_active_items(&self) -> Result<u64> {
        self.db.count_active_items_v1()
    }

    /// Search active v1 items by decrypting all items and filtering in memory.
    ///
    /// Case-insensitive search across title, username, tags, and website.
    pub fn search_items_v1(&self, query: &str) -> Result<Vec<PasswordItem>> {
        let q = query.to_lowercase();
        let all = self.get_all_items_v1()?;
        let results = all
            .into_iter()
            .filter(|item| {
                item.title.to_lowercase().contains(&q)
                    || item.username.to_lowercase().contains(&q)
                    || item.website.to_lowercase().contains(&q)
                    || item.tags.iter().any(|t| t.to_lowercase().contains(&q))
            })
            .collect();
        Ok(results)
    }

    // ---------------------------------------------------------------------------
    // Item sharing (v1)
    // ---------------------------------------------------------------------------

    /// Export a single item as an encrypted sharing blob.
    ///
    /// The item is serialized to JSON then encrypted with a caller-supplied
    /// passphrase using [`crypto::encrypt_for_sharing`].  The vault must be
    /// unlocked because the item data needs to be decrypted first.
    pub fn share_item_v1(&self, item_id: &str, passphrase: &str) -> Result<Vec<u8>> {
        let item = self.get_item_v1(item_id)?;
        let json = serde_json::to_string(&item)
            .map_err(|e| ClaustraError::Serialization(e.into()))?;
        crypto::encrypt_for_sharing(json.as_bytes(), passphrase)
    }

    /// Import a single item from an encrypted sharing blob.
    ///
    /// Decrypts with the given passphrase, deserializes the `PasswordItem`,
    /// assigns a fresh UUID and current timestamps, then creates it in the
    /// store.  Returns the new item ID.
    pub fn import_shared_item_v1(&self, encrypted_data: &[u8], passphrase: &str) -> Result<String> {
        let plaintext = crypto::decrypt_for_sharing(encrypted_data, passphrase)?;
        let json = std::str::from_utf8(&plaintext)
            .map_err(|e| ClaustraError::Encryption(format!("UTF-8 decode: {}", e)))?;
        let mut item: PasswordItem = serde_json::from_str(json)
            .map_err(|e| ClaustraError::Serialization(e.into()))?;

        // Assign a fresh identity so the imported item does not collide with
        // anything already in this vault.
        item.id = uuid::Uuid::new_v4().to_string();
        let now = Utc::now().to_rfc3339();
        item.created_at = now.clone();
        item.updated_at = now;
        item.deleted_at = None;

        let new_id = item.id.clone();
        self.create_item_v1(&item)?;
        Ok(new_id)
    }
}

// ---------------------------------------------------------------------------
// Attachments (v1)
// ---------------------------------------------------------------------------

impl PasswordStore {
    /// Encrypt `data` with the vault key and store it as an attachment on `item_id`.
    ///
    /// Returns the new attachment id.
    pub fn attach_file_v1(
        &self,
        item_id: &str,
        filename: &str,
        mime_type: &str,
        data: &[u8],
    ) -> Result<String> {
        use base64::{engine::general_purpose::STANDARD, Engine};
        let vault_key = self.vault_key_ref()?;
        let attachment_id = uuid::Uuid::new_v4().to_string();
        let created_at = Utc::now().to_rfc3339();

        // Base64-encode the raw bytes so they can be fed into encrypt_blob (which takes &str)
        let b64_data = STANDARD.encode(data);
        let encrypted_data = crypto::encrypt_blob(vault_key, &b64_data, &attachment_id)?;

        self.db.insert_attachment(
            &attachment_id,
            item_id,
            filename,
            mime_type,
            data.len() as u64,
            &encrypted_data,
            &created_at,
        )?;

        Ok(attachment_id)
    }

    /// Retrieve an attachment and decrypt its file data.
    ///
    /// Returns `(metadata, decrypted_bytes)`.
    pub fn get_attachment_v1(&self, attachment_id: &str) -> Result<(Attachment, Vec<u8>)> {
        use base64::{engine::general_purpose::STANDARD, Engine};
        let vault_key = self.vault_key_ref()?;
        let (id, item_id, filename, mime_type, size, encrypted_data, created_at) =
            self.db.get_attachment(attachment_id)?;

        let b64_data = crypto::decrypt_blob(vault_key, &encrypted_data, &id)?;
        let raw_bytes = STANDARD
            .decode(&b64_data)
            .map_err(|e| ClaustraError::Encryption(format!("base64 decode attachment: {}", e)))?;

        let attachment = Attachment {
            id,
            item_id,
            filename,
            mime_type,
            size,
            created_at,
        };

        Ok((attachment, raw_bytes))
    }

    /// Return attachment metadata for all attachments on `item_id`.
    ///
    /// Does not decrypt or return file data.
    pub fn list_attachments_v1(&self, item_id: &str) -> Result<Vec<Attachment>> {
        let rows = self.db.get_attachments_for_item(item_id)?;
        let attachments = rows
            .into_iter()
            .map(|(id, item_id, filename, mime_type, size, created_at)| Attachment {
                id,
                item_id,
                filename,
                mime_type,
                size,
                created_at,
            })
            .collect();
        Ok(attachments)
    }

    /// Delete a single attachment by id.
    pub fn delete_attachment_v1(&self, attachment_id: &str) -> Result<()> {
        self.db.delete_attachment(attachment_id)
    }

    // ---------------------------------------------------------------------------
    // Audit log
    // ---------------------------------------------------------------------------

    /// Log an audit event.
    pub fn log_audit_event(
        &self,
        event_type: &str,
        device_id: Option<&str>,
        device_name: Option<&str>,
        item_id: Option<&str>,
        details: Option<&str>,
    ) -> Result<()> {
        let id = uuid::Uuid::new_v4().to_string();
        let timestamp = Utc::now().to_rfc3339();
        self.db.insert_audit_entry(
            &id,
            event_type,
            device_id,
            device_name,
            item_id,
            details,
            &timestamp,
        )
    }

    /// Get audit log entries with pagination.
    pub fn get_audit_log(
        &self,
        limit: usize,
        offset: usize,
    ) -> Result<Vec<crate::database::AuditEntry>> {
        self.db.get_audit_log(limit, offset)
    }

    /// Get audit log entries for a specific device.
    pub fn get_audit_log_for_device(
        &self,
        device_id: &str,
        limit: usize,
    ) -> Result<Vec<crate::database::AuditEntry>> {
        self.db.get_audit_log_for_device(device_id, limit)
    }

    /// Delete audit log entries older than the given ISO-8601 timestamp.
    /// Returns the number of entries deleted.
    pub fn clear_audit_log_before(&self, before: &str) -> Result<usize> {
        self.db.clear_audit_log_before(before)
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::models::{Category, PasswordGeneratorOptions};

    fn make_item(title: &str, password: &str) -> PasswordItem {
        PasswordItem {
            title: title.to_string(),
            password: password.to_string(),
            username: "user@test.com".to_string(),
            website: "https://example.com".to_string(),
            category: Category::Logins,
            ..Default::default()
        }
    }

    fn unlocked_store() -> PasswordStore {
        let mut store = PasswordStore::new_in_memory().expect("store creation failed");
        store
            .setup_master_password("correct-horse-battery-staple")
            .expect("setup failed");
        store
    }

    // --- Auth ---

    #[test]
    fn test_setup_and_unlock() {
        let mut store = PasswordStore::new_in_memory().unwrap();
        assert!(!store.is_setup().unwrap());

        store.setup_master_password("my-password").unwrap();
        assert!(store.is_setup().unwrap());
        assert!(store.is_unlocked());

        store.lock();
        assert!(!store.is_unlocked());

        let ok = store.unlock("my-password").unwrap();
        assert!(ok);
        assert!(store.is_unlocked());
    }

    #[test]
    fn test_wrong_password_does_not_unlock() {
        let mut store = PasswordStore::new_in_memory().unwrap();
        store.setup_master_password("correct").unwrap();
        store.lock();

        let ok = store.unlock("wrong").unwrap();
        assert!(!ok);
        assert!(!store.is_unlocked());
    }

    // --- Items ---

    #[test]
    fn test_create_and_get_item() {
        let store = unlocked_store();
        let item = make_item("GitHub", "super-secret");
        store.create_item(&item).unwrap();

        let fetched = store.get_item(&item.id).unwrap();
        assert_eq!(fetched.title, "GitHub");
        assert_eq!(fetched.password, "super-secret");
    }

    #[test]
    fn test_password_is_stored_encrypted() {
        let store = unlocked_store();
        let item = make_item("Google", "my-plain-password");
        store.create_item(&item).unwrap();

        // Read raw from the DB (bypassing decrypt)
        let raw = store.db.get_item(&item.id).unwrap();
        assert_ne!(raw.password, "my-plain-password", "password must not be stored in plaintext");
    }

    #[test]
    fn test_get_all_items() {
        let store = unlocked_store();
        store.create_item(&make_item("A", "pA")).unwrap();
        store.create_item(&make_item("B", "pB")).unwrap();

        let items = store.get_all_items().unwrap();
        assert_eq!(items.len(), 2);
        assert!(items.iter().any(|i| i.title == "A" && i.password == "pA"));
        assert!(items.iter().any(|i| i.title == "B" && i.password == "pB"));
    }

    #[test]
    fn test_update_item_tracks_password_history() {
        let store = unlocked_store();
        let item = make_item("Twitter", "old-password");
        store.create_item(&item).unwrap();

        let mut updated = store.get_item(&item.id).unwrap();
        updated.password = "new-password".to_string();
        store.update_item(&updated).unwrap();

        let fetched = store.get_item(&item.id).unwrap();
        assert_eq!(fetched.password, "new-password");
        assert_eq!(fetched.password_history.len(), 1);
        assert_eq!(fetched.password_history[0].password, "old-password");
    }

    #[test]
    fn test_delete_and_restore_item() {
        let store = unlocked_store();
        let item = make_item("Facebook", "pw");
        store.create_item(&item).unwrap();

        store.delete_item(&item.id).unwrap();
        let active = store.get_all_items().unwrap();
        assert!(active.iter().all(|i| i.id != item.id));

        let trashed = store.get_trashed_items().unwrap();
        assert!(trashed.iter().any(|i| i.id == item.id));

        store.restore_item(&item.id).unwrap();
        let active_after = store.get_all_items().unwrap();
        assert!(active_after.iter().any(|i| i.id == item.id));
    }

    #[test]
    fn test_empty_trash() {
        let store = unlocked_store();
        let item = make_item("ToDelete", "pw");
        store.create_item(&item).unwrap();
        store.delete_item(&item.id).unwrap();

        let count = store.empty_trash().unwrap();
        assert_eq!(count, 1);
        assert!(store.get_trashed_items().unwrap().is_empty());
    }

    #[test]
    fn test_search_items() {
        let store = unlocked_store();
        store.create_item(&make_item("GitHub", "gh-pw")).unwrap();
        store.create_item(&make_item("GitLab", "gl-pw")).unwrap();
        store.create_item(&make_item("Google", "g-pw")).unwrap();

        let results = store.search_items("git").unwrap();
        assert_eq!(results.len(), 2);
    }

    // --- Folders ---

    #[test]
    fn test_folder_crud() {
        let store = unlocked_store();
        let folder = Folder {
            id: uuid::Uuid::new_v4().to_string(),
            name: "Work".to_string(),
            icon: "💼".to_string(),
        };
        store.create_folder(&folder).unwrap();

        let folders = store.get_all_folders().unwrap();
        assert_eq!(folders.len(), 1);
        assert_eq!(folders[0].name, "Work");

        let updated = Folder { name: "Work Updated".to_string(), ..folder.clone() };
        store.update_folder(&updated).unwrap();
        let folders = store.get_all_folders().unwrap();
        assert_eq!(folders[0].name, "Work Updated");

        store.delete_folder(&folder.id).unwrap();
        assert!(store.get_all_folders().unwrap().is_empty());
    }

    // --- Utilities ---

    #[test]
    fn test_generate_password() {
        let store = unlocked_store();
        let opts = PasswordGeneratorOptions {
            length: 20,
            ..Default::default()
        };
        let pwd = store.generate_password(&opts);
        assert_eq!(pwd.len(), 20);
    }

    #[test]
    fn test_calculate_strength() {
        let store = unlocked_store();
        let strong = store.calculate_strength("Abcdefgh1!XyZq@$");
        assert!(strong.score >= 4);
        let weak = store.calculate_strength("abc");
        assert!(weak.score < 2);
    }

    #[test]
    fn test_generate_totp() {
        let store = unlocked_store();
        let (code, remaining) = store.generate_totp("JBSWY3DPEHPK3PXP").unwrap();
        assert_eq!(code.len(), 6);
        assert!(remaining > 0 && remaining <= 30);
    }

    // --- Import / Export ---

    #[test]
    fn test_export_and_import_json() {
        let store = unlocked_store();
        store.create_item(&make_item("Site A", "pw-a")).unwrap();
        store.create_item(&make_item("Site B", "pw-b")).unwrap();

        let json = store.export_json().unwrap();
        assert!(json.contains("Site A"));

        let store2 = unlocked_store();
        let count = store2.import_json(&json).unwrap();
        assert_eq!(count, 2);
        let items = store2.get_all_items().unwrap();
        assert_eq!(items.len(), 2);
        assert!(items.iter().any(|i| i.password == "pw-a"));
    }

    #[test]
    fn test_export_and_import_csv() {
        let store = unlocked_store();
        store.create_item(&make_item("CSV Site", "csv-pw")).unwrap();

        let csv = store.export_csv().unwrap();
        let store2 = unlocked_store();
        let count = store2.import_csv(&csv).unwrap();
        assert_eq!(count, 1);
        let items = store2.get_all_items().unwrap();
        assert_eq!(items[0].password, "csv-pw");
    }

    // --- Favicon ---

    #[test]
    fn test_favicon_cache_and_retrieve() {
        let store = unlocked_store();
        let entry = FaviconEntry {
            domain: "github.com".to_string(),
            data_url: "data:image/png;base64,abc".to_string(),
            fetched_at: Utc::now().to_rfc3339(),
        };
        store.cache_favicon(&entry).unwrap();

        let fetched = store.get_favicon("github.com").unwrap();
        assert!(fetched.is_some());
        assert_eq!(fetched.unwrap().data_url, "data:image/png;base64,abc");

        let missing = store.get_favicon("notexist.com").unwrap();
        assert!(missing.is_none());
    }

    // =========================================================================
    // V1 Auth
    // =========================================================================

    fn unlocked_store_v1() -> PasswordStore {
        let mut store = PasswordStore::new_in_memory().expect("store creation failed");
        let device_secret = crypto::generate_random_bytes(32);
        store
            .setup_master_password_v1("correct-horse-battery-staple", &device_secret)
            .expect("setup failed");
        store
    }

    fn unlocked_store_v1_with_secret() -> (PasswordStore, Vec<u8>) {
        let mut store = PasswordStore::new_in_memory().expect("store creation failed");
        let device_secret = crypto::generate_random_bytes(32);
        store
            .setup_master_password_v1("correct-horse-battery-staple", &device_secret)
            .expect("setup failed");
        (store, device_secret)
    }

    #[test]
    fn test_v1_setup_and_unlock() {
        let (mut store, device_secret) = unlocked_store_v1_with_secret();
        assert!(store.is_setup_v1().unwrap());
        assert!(store.is_unlocked_v1());

        store.lock_v1();
        assert!(!store.is_unlocked_v1());

        let ok = store
            .unlock_v1("correct-horse-battery-staple", &device_secret)
            .unwrap();
        assert!(ok);
        assert!(store.is_unlocked_v1());
    }

    #[test]
    fn test_v1_wrong_password() {
        let (mut store, device_secret) = unlocked_store_v1_with_secret();
        store.lock_v1();
        let ok = store.unlock_v1("wrong-password", &device_secret).unwrap();
        assert!(!ok);
        assert!(!store.is_unlocked_v1());
    }

    #[test]
    fn test_v1_wrong_device_secret() {
        let (mut store, _) = unlocked_store_v1_with_secret();
        store.lock_v1();
        let wrong_secret = crypto::generate_random_bytes(32);
        let ok = store
            .unlock_v1("correct-horse-battery-staple", &wrong_secret)
            .unwrap();
        assert!(!ok);
    }

    #[test]
    fn test_v1_biometric_unlock() {
        let (mut store, _) = unlocked_store_v1_with_secret();
        let vault_key = *store.get_vault_key().unwrap();

        store.lock_v1();
        assert!(!store.is_unlocked_v1());

        store.unlock_with_vault_key(vault_key);
        assert!(store.is_unlocked_v1());
    }

    #[test]
    fn test_v1_change_password() {
        let (mut store, device_secret) = unlocked_store_v1_with_secret();

        // Create an item first
        let item = make_item("ChangeTest", "secret-pw");
        store.create_item_v1(&item).unwrap();

        // Change password
        store
            .change_password_v1(
                "correct-horse-battery-staple",
                "new-password-123",
                &device_secret,
            )
            .unwrap();

        // Lock and unlock with new password
        store.lock_v1();
        let ok = store.unlock_v1("new-password-123", &device_secret).unwrap();
        assert!(ok);

        // Old password should fail
        store.lock_v1();
        let ok = store
            .unlock_v1("correct-horse-battery-staple", &device_secret)
            .unwrap();
        assert!(!ok);

        // Data should still be accessible with new password
        store.lock_v1();
        store.unlock_v1("new-password-123", &device_secret).unwrap();
        let fetched = store.get_item_v1(&item.id).unwrap();
        assert_eq!(fetched.password, "secret-pw");
    }

    // =========================================================================
    // V1 Legacy Migration (SwiftPassword → Claustra)
    // =========================================================================

    /// Simulate a database that was set up with the old SwiftPassword HKDF info
    /// strings ("swiftpassword-v1-auth" / "swiftpassword-v1-kek" /
    /// "swiftpassword-vault-key-wrap") and verify that unlock_v1 can still
    /// authenticate, transparently migrates the stored values to the new
    /// strings, and that subsequent unlocks use the new path.
    #[test]
    fn test_v1_legacy_unlock_migrates_to_new_strings() {
        use aes_gcm::aead::{Aead, KeyInit, Payload};
        use aes_gcm::{Aes256Gcm, Nonce};
        use rand::RngCore;

        let password = "legacy-password";
        let device_secret = crypto::generate_random_bytes(32);

        // --- Simulate old SwiftPassword setup ---
        let master_key = crypto::derive_master_key(password, &device_secret).unwrap();
        let legacy_auth = crypto::derive_auth_key_legacy(&master_key).unwrap();
        let legacy_kek = crypto::derive_kek_legacy(&master_key).unwrap();

        // Generate a vault key and wrap it with the legacy KEK + legacy AAD
        let vault_key_bytes = crypto::generate_random_bytes(32);
        let mut vault_key = [0u8; 32];
        vault_key.copy_from_slice(&vault_key_bytes);

        let cipher = Aes256Gcm::new_from_slice(&legacy_kek).unwrap();
        let mut nonce_bytes = [0u8; 12];
        rand::thread_rng().fill_bytes(&mut nonce_bytes);
        let nonce = Nonce::from_slice(&nonce_bytes);
        let legacy_aad = b"swiftpassword-vault-key-wrap";
        let payload = Payload {
            msg: vault_key.as_ref(),
            aad: legacy_aad.as_ref(),
        };
        let ciphertext = cipher.encrypt(nonce, payload).unwrap();
        let mut wrapped = Vec::with_capacity(12 + ciphertext.len());
        wrapped.extend_from_slice(&nonce_bytes);
        wrapped.extend_from_slice(&ciphertext);

        // Store the legacy values directly in a fresh in-memory DB
        let mut store = PasswordStore::new_in_memory().unwrap();
        store
            .db
            .set_setting("auth_key", &STANDARD.encode(&legacy_auth))
            .unwrap();
        store
            .db
            .set_setting("wrapped_vault_key", &STANDARD.encode(&wrapped))
            .unwrap();
        store
            .db
            .set_setting(
                "kdf_params",
                r#"{"memory":65536,"iterations":3,"parallelism":4}"#,
            )
            .unwrap();

        // --- unlock_v1 must succeed via legacy fallback ---
        let ok = store.unlock_v1(password, &device_secret).unwrap();
        assert!(ok, "legacy unlock must succeed");
        assert!(store.is_unlocked_v1());

        // The recovered vault key must match the original
        assert_eq!(store.get_vault_key().unwrap(), &vault_key);

        // --- After migration the DB should now hold NEW-string values ---
        let migrated_auth_b64 = store.db.get_setting("auth_key").unwrap().unwrap();
        let migrated_auth = STANDARD.decode(&migrated_auth_b64).unwrap();
        let expected_new_auth = crypto::derive_auth_key(&master_key).unwrap();
        assert_eq!(
            migrated_auth, expected_new_auth,
            "auth_key must be migrated to new string"
        );

        // --- Subsequent unlock must work via the NEW path (no legacy fallback needed) ---
        store.lock_v1();
        let ok2 = store.unlock_v1(password, &device_secret).unwrap();
        assert!(ok2, "second unlock (new path) must succeed");
        assert_eq!(store.get_vault_key().unwrap(), &vault_key);
    }

    /// Verify that change_password_v1 works when the stored data was created
    /// with legacy SwiftPassword derivation strings.
    #[test]
    fn test_v1_legacy_change_password() {
        use aes_gcm::aead::{Aead, KeyInit, Payload};
        use aes_gcm::{Aes256Gcm, Nonce};
        use rand::RngCore;

        let old_password = "old-legacy-password";
        let new_password = "new-shiny-password";
        let device_secret = crypto::generate_random_bytes(32);

        // --- Simulate old SwiftPassword setup ---
        let master_key = crypto::derive_master_key(old_password, &device_secret).unwrap();
        let legacy_auth = crypto::derive_auth_key_legacy(&master_key).unwrap();
        let legacy_kek = crypto::derive_kek_legacy(&master_key).unwrap();

        let vault_key_bytes = crypto::generate_random_bytes(32);
        let mut vault_key = [0u8; 32];
        vault_key.copy_from_slice(&vault_key_bytes);

        let cipher = Aes256Gcm::new_from_slice(&legacy_kek).unwrap();
        let mut nonce_bytes = [0u8; 12];
        rand::thread_rng().fill_bytes(&mut nonce_bytes);
        let nonce = Nonce::from_slice(&nonce_bytes);
        let payload = Payload {
            msg: vault_key.as_ref(),
            aad: b"swiftpassword-vault-key-wrap" as &[u8],
        };
        let ciphertext = cipher.encrypt(nonce, payload).unwrap();
        let mut wrapped = Vec::with_capacity(12 + ciphertext.len());
        wrapped.extend_from_slice(&nonce_bytes);
        wrapped.extend_from_slice(&ciphertext);

        let mut store = PasswordStore::new_in_memory().unwrap();
        store
            .db
            .set_setting("auth_key", &STANDARD.encode(&legacy_auth))
            .unwrap();
        store
            .db
            .set_setting("wrapped_vault_key", &STANDARD.encode(&wrapped))
            .unwrap();
        store
            .db
            .set_setting(
                "kdf_params",
                r#"{"memory":65536,"iterations":3,"parallelism":4}"#,
            )
            .unwrap();

        // change_password_v1 must succeed despite legacy derivation
        store
            .change_password_v1(old_password, new_password, &device_secret)
            .unwrap();

        // Old password must no longer work
        store.lock_v1();
        let ok_old = store.unlock_v1(old_password, &device_secret).unwrap();
        assert!(!ok_old, "old password must not unlock after change");

        // New password must unlock and preserve the vault key
        let ok_new = store.unlock_v1(new_password, &device_secret).unwrap();
        assert!(ok_new, "new password must unlock after change");
        assert_eq!(store.get_vault_key().unwrap(), &vault_key);
    }

    // =========================================================================
    // V1 Items
    // =========================================================================

    #[test]
    fn test_v1_create_and_get_item() {
        let store = unlocked_store_v1();
        let item = make_item("GitHub", "super-secret");
        store.create_item_v1(&item).unwrap();

        let fetched = store.get_item_v1(&item.id).unwrap();
        assert_eq!(fetched.title, "GitHub");
        assert_eq!(fetched.password, "super-secret");
        assert_eq!(fetched.username, "user@test.com");
        assert_eq!(fetched.website, "https://example.com");
    }

    #[test]
    fn test_v1_all_sensitive_fields_encrypted() {
        let store = unlocked_store_v1();
        let mut item = make_item("TestEncryption", "my-password");
        item.notes = "secret notes".to_string();
        item.totp_secret = "JBSWY3DPEHPK3PXP".to_string();
        store.create_item_v1(&item).unwrap();

        // Read raw from DB — encrypted_data should not contain plaintext
        let raw = store.db.get_item_v1(&item.id).unwrap();
        assert!(!raw.encrypted_data.contains("my-password"));
        assert!(!raw.encrypted_data.contains("secret notes"));
        assert!(!raw.encrypted_data.contains("JBSWY3DPEHPK3PXP"));

        // Decrypted version should have all fields
        let decrypted = store.get_item_v1(&item.id).unwrap();
        assert_eq!(decrypted.password, "my-password");
        assert_eq!(decrypted.notes, "secret notes");
        assert_eq!(decrypted.totp_secret, "JBSWY3DPEHPK3PXP");
    }

    #[test]
    fn test_v1_get_all_items() {
        let store = unlocked_store_v1();
        store.create_item_v1(&make_item("A", "pA")).unwrap();
        store.create_item_v1(&make_item("B", "pB")).unwrap();

        let items = store.get_all_items_v1().unwrap();
        assert_eq!(items.len(), 2);
    }

    #[test]
    fn test_v1_update_tracks_password_history() {
        let store = unlocked_store_v1();
        let item = make_item("Twitter", "old-password");
        store.create_item_v1(&item).unwrap();

        let mut updated = store.get_item_v1(&item.id).unwrap();
        updated.password = "new-password".to_string();
        store.update_item_v1(&updated).unwrap();

        let fetched = store.get_item_v1(&item.id).unwrap();
        assert_eq!(fetched.password, "new-password");
        assert_eq!(fetched.password_history.len(), 1);
        assert_eq!(fetched.password_history[0].password, "old-password");
    }

    #[test]
    fn test_v1_delete_and_restore() {
        let store = unlocked_store_v1();
        let item = make_item("Facebook", "pw");
        store.create_item_v1(&item).unwrap();

        store.delete_item_v1(&item.id).unwrap();
        assert!(store.get_all_items_v1().unwrap().is_empty());

        let trashed = store.get_trashed_items_v1().unwrap();
        assert_eq!(trashed.len(), 1);

        store.restore_item_v1(&item.id).unwrap();
        assert_eq!(store.get_all_items_v1().unwrap().len(), 1);
    }

    #[test]
    fn test_v1_search_items() {
        let store = unlocked_store_v1();
        store.create_item_v1(&make_item("GitHub", "gh-pw")).unwrap();
        store.create_item_v1(&make_item("GitLab", "gl-pw")).unwrap();
        store.create_item_v1(&make_item("Google", "g-pw")).unwrap();

        let results = store.search_items_v1("git").unwrap();
        assert_eq!(results.len(), 2);
    }

    // -----------------------------------------------------------------------
    // Audit log tests
    // -----------------------------------------------------------------------

    #[test]
    fn test_audit_log_via_store() {
        let store = unlocked_store_v1();

        store
            .log_audit_event(
                "device_paired",
                Some("dev-1"),
                Some("Mac Studio"),
                None,
                Some("QR pairing"),
            )
            .unwrap();

        store
            .log_audit_event("vault_unlocked", Some("dev-1"), Some("Mac Studio"), None, None)
            .unwrap();

        let all = store.get_audit_log(10, 0).unwrap();
        assert_eq!(all.len(), 2);

        let for_dev = store.get_audit_log_for_device("dev-1", 10).unwrap();
        assert_eq!(for_dev.len(), 2);

        let for_other = store.get_audit_log_for_device("dev-999", 10).unwrap();
        assert!(for_other.is_empty());
    }

    #[test]
    fn test_audit_log_cleanup_via_store() {
        let store = unlocked_store_v1();

        // Insert old and new entries using the DB directly for controlled timestamps
        store.db.insert_audit_entry("old-1", "vault_unlocked", None, None, None, None, "2025-01-01T00:00:00Z").unwrap();
        store.db.insert_audit_entry("new-1", "vault_locked", None, None, None, None, "2026-06-01T00:00:00Z").unwrap();

        let deleted = store.clear_audit_log_before("2026-01-01T00:00:00Z").unwrap();
        assert_eq!(deleted, 1);

        let remaining = store.get_audit_log(10, 0).unwrap();
        assert_eq!(remaining.len(), 1);
        assert_eq!(remaining[0].id, "new-1");
    }
}
