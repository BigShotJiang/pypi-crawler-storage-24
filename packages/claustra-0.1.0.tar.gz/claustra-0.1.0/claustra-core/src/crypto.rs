use aes_gcm::{
    aead::{Aead, KeyInit},
    Aes256Gcm, Nonce,
};
use argon2::{
    password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2, Params,
};
use hkdf::Hkdf;
use rand::RngCore;
use sha2::Sha256;

use crate::error::{Result, ClaustraError};

// ---------------------------------------------------------------------------
// Master password hashing (PHC format, for storage)
// ---------------------------------------------------------------------------

/// Hash a master password using Argon2id. Returns a PHC-format string suitable
/// for persistent storage.
pub fn hash_master_password(password: &str) -> Result<String> {
    let mut salt_bytes = [0u8; 16];
    rand::thread_rng().fill_bytes(&mut salt_bytes);

    // SaltString requires a base64-url encoded value without padding.
    let salt = SaltString::encode_b64(&salt_bytes)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let argon2 = Argon2::default();
    let hash = argon2
        .hash_password(password.as_bytes(), &salt)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    Ok(hash.to_string())
}

/// Verify a master password against a stored PHC hash.
pub fn verify_master_password(password: &str, hash: &str) -> Result<bool> {
    let parsed =
        PasswordHash::new(hash).map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let argon2 = Argon2::default();
    match argon2.verify_password(password.as_bytes(), &parsed) {
        Ok(()) => Ok(true),
        Err(argon2::password_hash::Error::Password) => Ok(false),
        Err(e) => Err(ClaustraError::Encryption(e.to_string())),
    }
}

// ---------------------------------------------------------------------------
// Key derivation
// ---------------------------------------------------------------------------

/// Derive a 32-byte AES-256 encryption key from the master password and a
/// caller-supplied salt using Argon2id.
pub fn derive_encryption_key(master_password: &str, salt: &[u8]) -> Result<[u8; 32]> {
    let params = Params::new(
        64 * 1024, // m_cost: 64 MiB
        3,         // t_cost: 3 iterations
        1,         // p_cost: 1 thread
        Some(32),  // output length
    )
    .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let argon2 = Argon2::new(argon2::Algorithm::Argon2id, argon2::Version::V0x13, params);

    let mut key = [0u8; 32];
    argon2
        .hash_password_into(master_password.as_bytes(), salt, &mut key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    Ok(key)
}

// ---------------------------------------------------------------------------
// AES-256-GCM encrypt / decrypt
// ---------------------------------------------------------------------------

/// Encrypt `plaintext` with AES-256-GCM using the provided 32-byte key.
///
/// Returns a Base64-encoded string in the format `<nonce_b64>:<ciphertext_b64>`.
/// A fresh 12-byte nonce is generated randomly for every call.
pub fn encrypt(plaintext: &str, key: &[u8; 32]) -> Result<String> {
    use base64::{engine::general_purpose::STANDARD, Engine};

    let cipher = Aes256Gcm::new_from_slice(key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let ciphertext = cipher
        .encrypt(nonce, plaintext.as_bytes())
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let result = format!(
        "{}:{}",
        STANDARD.encode(nonce_bytes),
        STANDARD.encode(ciphertext)
    );
    Ok(result)
}

/// Decrypt a string previously produced by [`encrypt`].
///
/// Expects the format `<nonce_b64>:<ciphertext_b64>`.
pub fn decrypt(encrypted: &str, key: &[u8; 32]) -> Result<String> {
    use base64::{engine::general_purpose::STANDARD, Engine};

    let (nonce_b64, cipher_b64) = encrypted
        .split_once(':')
        .ok_or_else(|| ClaustraError::Encryption("Invalid encrypted format".to_string()))?;

    let nonce_bytes = STANDARD
        .decode(nonce_b64)
        .map_err(|e| ClaustraError::Encryption(format!("Base64 decode nonce: {}", e)))?;

    let ciphertext = STANDARD
        .decode(cipher_b64)
        .map_err(|e| ClaustraError::Encryption(format!("Base64 decode ciphertext: {}", e)))?;

    let cipher = Aes256Gcm::new_from_slice(key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let nonce = Nonce::from_slice(&nonce_bytes);

    let plaintext_bytes = cipher
        .decrypt(nonce, ciphertext.as_ref())
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    String::from_utf8(plaintext_bytes)
        .map_err(|e| ClaustraError::Encryption(format!("UTF-8 decode: {}", e)))
}

// ---------------------------------------------------------------------------
// V1 key hierarchy
// ---------------------------------------------------------------------------

/// Generate `len` cryptographically random bytes.
pub fn generate_random_bytes(len: usize) -> Vec<u8> {
    let mut buf = vec![0u8; len];
    rand::thread_rng().fill_bytes(&mut buf);
    buf
}

/// Derive a 256-bit master key from a master password and a device secret
/// using Argon2id (memory=64 MiB, iterations=3, parallelism=4).
///
/// This is the v1 KDF; the salt is the device_secret bytes.
pub fn derive_master_key(password: &str, device_secret: &[u8]) -> Result<[u8; 32]> {
    let params = Params::new(
        64 * 1024, // m_cost: 64 MiB
        3,         // t_cost: 3 iterations
        4,         // p_cost: 4 threads (v1, differs from derive_encryption_key)
        Some(32),  // output length
    )
    .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let argon2 = Argon2::new(argon2::Algorithm::Argon2id, argon2::Version::V0x13, params);

    let mut key = [0u8; 32];
    argon2
        .hash_password_into(password.as_bytes(), device_secret, &mut key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    Ok(key)
}

/// Derive a 256-bit key from `master_key` using HKDF-SHA256 with the given
/// `info` label. No salt is used (RFC 5869 allows this).
pub fn hkdf_derive_key(master_key: &[u8; 32], info: &str) -> Result<[u8; 32]> {
    let hk = Hkdf::<Sha256>::new(None, master_key);
    let mut okm = [0u8; 32];
    hk.expand(info.as_bytes(), &mut okm)
        .map_err(|_| ClaustraError::Encryption("HKDF expand failed".to_string()))?;
    Ok(okm)
}

/// Derive the auth key (used for vault-unlock verification) from the master key.
pub fn derive_auth_key(master_key: &[u8; 32]) -> Result<[u8; 32]> {
    hkdf_derive_key(master_key, "claustra-v1-auth")
}

/// Derive the Key-Encryption Key (KEK) used to wrap the vault key.
pub fn derive_kek(master_key: &[u8; 32]) -> Result<[u8; 32]> {
    hkdf_derive_key(master_key, "claustra-v1-kek")
}

/// Legacy auth key derivation (for migration from SwiftPassword).
pub fn derive_auth_key_legacy(master_key: &[u8; 32]) -> Result<[u8; 32]> {
    hkdf_derive_key(master_key, "swiftpassword-v1-auth")
}

/// Legacy KEK derivation (for migration from SwiftPassword).
pub fn derive_kek_legacy(master_key: &[u8; 32]) -> Result<[u8; 32]> {
    hkdf_derive_key(master_key, "swiftpassword-v1-kek")
}

/// Wrap a 32-byte vault key with AES-256-GCM using the KEK.
///
/// Returns `nonce(12) || ciphertext || tag(16)` as raw bytes.
pub fn wrap_vault_key(kek: &[u8; 32], vault_key: &[u8; 32]) -> Result<Vec<u8>> {
    use aes_gcm::aead::Payload;

    let cipher = Aes256Gcm::new_from_slice(kek)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let aad = b"claustra-vault-key-wrap";
    let payload = Payload {
        msg: vault_key.as_ref(),
        aad: aad.as_ref(),
    };

    let ciphertext = cipher
        .encrypt(nonce, payload)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut out = Vec::with_capacity(12 + ciphertext.len());
    out.extend_from_slice(&nonce_bytes);
    out.extend_from_slice(&ciphertext);
    Ok(out)
}

/// Unwrap a vault key previously produced by [`wrap_vault_key`].
///
/// Tries the new AAD (`"claustra-vault-key-wrap"`) first; if that fails,
/// retries with the legacy AAD (`"swiftpassword-vault-key-wrap"`) to support
/// migration from existing SwiftPassword data.
///
/// Input format: `nonce(12) || ciphertext || tag(16)`.
pub fn unwrap_vault_key(kek: &[u8; 32], wrapped: &[u8]) -> Result<[u8; 32]> {
    unwrap_vault_key_with_aad(kek, wrapped, b"claustra-vault-key-wrap")
        .or_else(|_| unwrap_vault_key_with_aad(kek, wrapped, b"swiftpassword-vault-key-wrap"))
}

/// Private helper: unwrap a vault key with an explicit AAD byte string.
fn unwrap_vault_key_with_aad(kek: &[u8; 32], wrapped: &[u8], aad: &[u8]) -> Result<[u8; 32]> {
    use aes_gcm::aead::Payload;

    if wrapped.len() < 12 {
        return Err(ClaustraError::Encryption(
            "Wrapped key too short".to_string(),
        ));
    }

    let (nonce_bytes, ciphertext) = wrapped.split_at(12);
    let nonce = Nonce::from_slice(nonce_bytes);

    let cipher = Aes256Gcm::new_from_slice(kek)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let payload = Payload {
        msg: ciphertext,
        aad,
    };

    let plaintext = cipher
        .decrypt(nonce, payload)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    if plaintext.len() != 32 {
        return Err(ClaustraError::Encryption(
            "Unwrapped key has wrong length".to_string(),
        ));
    }

    let mut key = [0u8; 32];
    key.copy_from_slice(&plaintext);
    Ok(key)
}

// ---------------------------------------------------------------------------
// Sync key hierarchy
// ---------------------------------------------------------------------------

/// Derive the Sync Key-Encryption Key (KEK) from a master password and a
/// random sync salt using Argon2id (memory=64 MiB, iterations=3, parallelism=4),
/// then HKDF with label "claustra-v1-sync-kek".
///
/// Unlike `derive_master_key`, the sync salt is already raw bytes (not a `&str`).
pub fn derive_sync_kek(master_password: &str, sync_salt: &[u8]) -> Result<Vec<u8>> {
    let master_key = derive_master_key(master_password, sync_salt)?;
    let sync_kek = hkdf_derive_key(&master_key, "claustra-v1-sync-kek")?;
    Ok(sync_kek.to_vec())
}

/// Wrap a vault key for upload to CloudKit using the sync KEK.
///
/// Uses AES-256-GCM with AAD = `b"claustra-sync-vault-key-wrap"`.
/// Returns `nonce(12) || ciphertext || tag(16)` as raw bytes.
pub fn wrap_vault_key_for_sync(vault_key: &[u8], sync_kek: &[u8]) -> Result<Vec<u8>> {
    use aes_gcm::aead::Payload;

    if sync_kek.len() != 32 {
        return Err(ClaustraError::Encryption(
            "sync_kek must be exactly 32 bytes".to_string(),
        ));
    }

    let cipher = Aes256Gcm::new_from_slice(sync_kek)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let aad = b"claustra-sync-vault-key-wrap";
    let payload = Payload {
        msg: vault_key,
        aad: aad.as_ref(),
    };

    let ciphertext = cipher
        .encrypt(nonce, payload)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut out = Vec::with_capacity(12 + ciphertext.len());
    out.extend_from_slice(&nonce_bytes);
    out.extend_from_slice(&ciphertext);
    Ok(out)
}

/// Unwrap a vault key retrieved from CloudKit using the sync KEK.
///
/// Input format: `nonce(12) || ciphertext || tag(16)`.
/// Returns the raw vault key bytes.
pub fn unwrap_vault_key_from_sync(sync_wrapped_vault_key: &[u8], sync_kek: &[u8]) -> Result<Vec<u8>> {
    use aes_gcm::aead::Payload;

    if sync_kek.len() != 32 {
        return Err(ClaustraError::Encryption(
            "sync_kek must be exactly 32 bytes".to_string(),
        ));
    }

    if sync_wrapped_vault_key.len() < 12 {
        return Err(ClaustraError::Encryption(
            "Wrapped key too short".to_string(),
        ));
    }

    let (nonce_bytes, ciphertext) = sync_wrapped_vault_key.split_at(12);
    let nonce = Nonce::from_slice(nonce_bytes);

    let cipher = Aes256Gcm::new_from_slice(sync_kek)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let aad = b"claustra-sync-vault-key-wrap";
    let payload = Payload {
        msg: ciphertext,
        aad: aad.as_ref(),
    };

    let plaintext = cipher
        .decrypt(nonce, payload)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    Ok(plaintext)
}

/// Generate a random 32-byte sync salt.
pub fn generate_sync_salt() -> Vec<u8> {
    generate_random_bytes(32)
}

/// Encrypt `plaintext` with AES-256-GCM using `vault_key`, binding `item_id`
/// as additional authenticated data.
///
/// Returns Base64( `0x01` || nonce(12) || ciphertext || tag(16) ).
pub fn encrypt_blob(vault_key: &[u8; 32], plaintext: &str, item_id: &str) -> Result<String> {
    use aes_gcm::aead::Payload;
    use base64::{engine::general_purpose::STANDARD, Engine};

    let cipher = Aes256Gcm::new_from_slice(vault_key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let payload = Payload {
        msg: plaintext.as_bytes(),
        aad: item_id.as_bytes(),
    };

    let ciphertext = cipher
        .encrypt(nonce, payload)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut raw = Vec::with_capacity(1 + 12 + ciphertext.len());
    raw.push(0x01u8); // version byte
    raw.extend_from_slice(&nonce_bytes);
    raw.extend_from_slice(&ciphertext);

    Ok(STANDARD.encode(raw))
}

/// Decrypt a blob previously produced by [`encrypt_blob`].
pub fn decrypt_blob(vault_key: &[u8; 32], encrypted: &str, item_id: &str) -> Result<String> {
    use aes_gcm::aead::Payload;
    use base64::{engine::general_purpose::STANDARD, Engine};

    let raw = STANDARD
        .decode(encrypted)
        .map_err(|e| ClaustraError::Encryption(format!("Base64 decode: {}", e)))?;

    if raw.is_empty() || raw[0] != 0x01 {
        return Err(ClaustraError::Encryption(
            "Unsupported blob version".to_string(),
        ));
    }

    if raw.len() < 1 + 12 {
        return Err(ClaustraError::Encryption(
            "Blob too short".to_string(),
        ));
    }

    let nonce = Nonce::from_slice(&raw[1..13]);
    let ciphertext = &raw[13..];

    let cipher = Aes256Gcm::new_from_slice(vault_key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let payload = Payload {
        msg: ciphertext,
        aad: item_id.as_bytes(),
    };

    let plaintext_bytes = cipher
        .decrypt(nonce, payload)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    String::from_utf8(plaintext_bytes)
        .map_err(|e| ClaustraError::Encryption(format!("UTF-8 decode: {}", e)))
}

// ---------------------------------------------------------------------------
// Passphrase-based sharing encryption
// ---------------------------------------------------------------------------

/// Encrypt data with a passphrase for sharing.
///
/// Uses Argon2id (32 MiB, 2 iterations) to derive a key from the passphrase,
/// then encrypts with AES-256-GCM.
///
/// Returns: `salt(16) || nonce(12) || ciphertext || tag(16)`
pub fn encrypt_for_sharing(plaintext: &[u8], passphrase: &str) -> Result<Vec<u8>> {
    let mut salt = [0u8; 16];
    rand::thread_rng().fill_bytes(&mut salt);

    let params = Params::new(
        32 * 1024, // m_cost: 32 MiB (lighter than vault KDF)
        2,         // t_cost: 2 iterations
        1,         // p_cost: 1 thread
        Some(32),  // output length
    )
    .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let argon2 = Argon2::new(argon2::Algorithm::Argon2id, argon2::Version::V0x13, params);
    let mut key = [0u8; 32];
    argon2
        .hash_password_into(passphrase.as_bytes(), &salt, &mut key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let cipher = Aes256Gcm::new_from_slice(&key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let ciphertext = cipher
        .encrypt(nonce, plaintext)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let mut out = Vec::with_capacity(16 + 12 + ciphertext.len());
    out.extend_from_slice(&salt);
    out.extend_from_slice(&nonce_bytes);
    out.extend_from_slice(&ciphertext);
    Ok(out)
}

/// Decrypt data that was encrypted for sharing with [`encrypt_for_sharing`].
///
/// Input format: `salt(16) || nonce(12) || ciphertext || tag(16)`
pub fn decrypt_for_sharing(encrypted: &[u8], passphrase: &str) -> Result<Vec<u8>> {
    if encrypted.len() < 16 + 12 + 16 {
        return Err(ClaustraError::Encryption(
            "Sharing blob too short".to_string(),
        ));
    }

    let salt = &encrypted[..16];
    let nonce_bytes = &encrypted[16..28];
    let ciphertext = &encrypted[28..];

    let params = Params::new(
        32 * 1024, // m_cost: 32 MiB
        2,         // t_cost: 2 iterations
        1,         // p_cost: 1 thread
        Some(32),  // output length
    )
    .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let argon2 = Argon2::new(argon2::Algorithm::Argon2id, argon2::Version::V0x13, params);
    let mut key = [0u8; 32];
    argon2
        .hash_password_into(passphrase.as_bytes(), salt, &mut key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let cipher = Aes256Gcm::new_from_slice(&key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;

    let nonce = Nonce::from_slice(nonce_bytes);
    cipher
        .decrypt(nonce, ciphertext)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))
}

/// Constant-time comparison of two byte slices.
///
/// Returns `true` only when both slices have identical length and contents,
/// without leaking timing information about where a mismatch occurs.
pub fn constant_time_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff = 0u8;
    for (x, y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_encrypt_decrypt_roundtrip() {
        let key = [42u8; 32];
        let plaintext = "Hello, Claustra!";

        let encrypted = encrypt(plaintext, &key).expect("encrypt failed");
        assert!(encrypted.contains(':'), "format should be nonce:ciphertext");

        let decrypted = decrypt(&encrypted, &key).expect("decrypt failed");
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_encrypt_produces_different_ciphertexts() {
        let key = [7u8; 32];
        let plaintext = "same plaintext";

        let e1 = encrypt(plaintext, &key).unwrap();
        let e2 = encrypt(plaintext, &key).unwrap();
        // Different nonces must produce different ciphertexts.
        assert_ne!(e1, e2);
    }

    #[test]
    fn test_decrypt_wrong_key_fails() {
        let key1 = [1u8; 32];
        let key2 = [2u8; 32];
        let encrypted = encrypt("secret", &key1).unwrap();
        assert!(decrypt(&encrypted, &key2).is_err());
    }

    #[test]
    fn test_hash_and_verify_master_password() {
        let password = "my_super_secret_password";
        let hash = hash_master_password(password).expect("hash failed");

        assert!(verify_master_password(password, &hash).unwrap());
        assert!(!verify_master_password("wrong_password", &hash).unwrap());
    }

    #[test]
    fn test_derive_encryption_key_deterministic() {
        let password = "deterministic";
        let salt = b"fixed_salt_1234_"; // 16 bytes

        let key1 = derive_encryption_key(password, salt).unwrap();
        let key2 = derive_encryption_key(password, salt).unwrap();
        assert_eq!(key1, key2);
    }

    #[test]
    fn test_derive_encryption_key_different_salts() {
        let password = "same_password";
        let key1 = derive_encryption_key(password, b"salt_aaaaaaaaaa_").unwrap();
        let key2 = derive_encryption_key(password, b"salt_bbbbbbbbbbb").unwrap();
        assert_ne!(key1, key2);
    }

    // -----------------------------------------------------------------------
    // V1 tests
    // -----------------------------------------------------------------------

    #[test]
    fn test_derive_master_key() {
        let device_secret = [0xABu8; 32];
        let key1 = derive_master_key("password", &device_secret).unwrap();
        let key2 = derive_master_key("password", &device_secret).unwrap();
        assert_eq!(key1, key2); // deterministic

        let key3 = derive_master_key("different", &device_secret).unwrap();
        assert_ne!(key1, key3); // different password → different key
    }

    #[test]
    fn test_hkdf_derive_key() {
        let master = [42u8; 32];
        let auth = hkdf_derive_key(&master, "claustra-v1-auth").unwrap();
        let kek = hkdf_derive_key(&master, "claustra-v1-kek").unwrap();
        assert_ne!(auth, kek); // different info → different keys

        let auth2 = hkdf_derive_key(&master, "claustra-v1-auth").unwrap();
        assert_eq!(auth, auth2); // deterministic
    }

    #[test]
    fn test_wrap_unwrap_vault_key() {
        let kek = [7u8; 32];
        let vault_key = [99u8; 32];
        let wrapped = wrap_vault_key(&kek, &vault_key).unwrap();
        let unwrapped = unwrap_vault_key(&kek, &wrapped).unwrap();
        assert_eq!(vault_key, unwrapped);
    }

    #[test]
    fn test_wrap_vault_key_wrong_kek_fails() {
        let kek1 = [1u8; 32];
        let kek2 = [2u8; 32];
        let vault_key = [99u8; 32];
        let wrapped = wrap_vault_key(&kek1, &vault_key).unwrap();
        assert!(unwrap_vault_key(&kek2, &wrapped).is_err());
    }

    #[test]
    fn test_unwrap_vault_key_new_aad() {
        let kek = [7u8; 32];
        let vault_key = [99u8; 32];
        let wrapped = wrap_vault_key(&kek, &vault_key).unwrap();
        let unwrapped = unwrap_vault_key(&kek, &wrapped).unwrap();
        assert_eq!(vault_key, unwrapped);
    }

    #[test]
    fn test_unwrap_vault_key_legacy_migration() {
        use aes_gcm::aead::Payload;

        let kek = [7u8; 32];
        let vault_key = [99u8; 32];

        // Wrap with legacy AAD (simulating old SwiftPassword data)
        let cipher = Aes256Gcm::new_from_slice(&kek).unwrap();
        let mut nonce_bytes = [0u8; 12];
        rand::thread_rng().fill_bytes(&mut nonce_bytes);
        let nonce = Nonce::from_slice(&nonce_bytes);
        let legacy_aad = b"swiftpassword-vault-key-wrap";
        let payload = Payload {
            msg: vault_key.as_ref(),
            aad: legacy_aad.as_ref(),
        };
        let ciphertext = cipher.encrypt(nonce, payload).unwrap();
        let mut wrapped = Vec::with_capacity(12 + ciphertext.len());
        wrapped.extend_from_slice(&nonce_bytes);
        wrapped.extend_from_slice(&ciphertext);

        // Unwrap with new function — must succeed via legacy fallback
        let unwrapped = unwrap_vault_key(&kek, &wrapped).unwrap();
        assert_eq!(vault_key, unwrapped);
    }

    #[test]
    fn test_encrypt_decrypt_blob() {
        let vault_key = [42u8; 32];
        let item_id = "item-001";
        let plaintext = r#"{"title":"GitHub","password":"secret"}"#;

        let encrypted = encrypt_blob(&vault_key, plaintext, item_id).unwrap();
        let decrypted = decrypt_blob(&vault_key, &encrypted, item_id).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_encrypt_blob_different_nonces() {
        let vault_key = [42u8; 32];
        let e1 = encrypt_blob(&vault_key, "same", "id1").unwrap();
        let e2 = encrypt_blob(&vault_key, "same", "id1").unwrap();
        assert_ne!(e1, e2); // random nonce each time
    }

    #[test]
    fn test_decrypt_blob_wrong_item_id_fails() {
        let vault_key = [42u8; 32];
        let encrypted = encrypt_blob(&vault_key, "data", "item-1").unwrap();
        assert!(decrypt_blob(&vault_key, &encrypted, "item-2").is_err());
    }

    #[test]
    fn test_decrypt_blob_wrong_key_fails() {
        let key1 = [1u8; 32];
        let key2 = [2u8; 32];
        let encrypted = encrypt_blob(&key1, "data", "item-1").unwrap();
        assert!(decrypt_blob(&key2, &encrypted, "item-1").is_err());
    }

    #[test]
    fn test_constant_time_eq() {
        let a = [1, 2, 3, 4];
        let b = [1, 2, 3, 4];
        let c = [1, 2, 3, 5];
        assert!(constant_time_eq(&a, &b));
        assert!(!constant_time_eq(&a, &c));
        assert!(!constant_time_eq(&a, &[1, 2, 3]));
    }

    #[test]
    fn test_full_key_hierarchy() {
        // Simulate the complete setup flow
        let password = "my-master-password";
        let device_secret = generate_random_bytes(32);

        // 1. Derive master key
        let master_key = derive_master_key(password, &device_secret).unwrap();

        // 2. Derive auth key and KEK
        let auth_key = derive_auth_key(&master_key).unwrap();
        let kek = derive_kek(&master_key).unwrap();
        assert_ne!(auth_key, kek);

        // 3. Generate and wrap vault key
        let vault_key_bytes = generate_random_bytes(32);
        let mut vault_key = [0u8; 32];
        vault_key.copy_from_slice(&vault_key_bytes);
        let wrapped = wrap_vault_key(&kek, &vault_key).unwrap();

        // 4. Simulate unlock: re-derive and unwrap
        let master_key2 = derive_master_key(password, &device_secret).unwrap();
        let auth_key2 = derive_auth_key(&master_key2).unwrap();
        assert!(constant_time_eq(&auth_key, &auth_key2));

        let kek2 = derive_kek(&master_key2).unwrap();
        let unwrapped = unwrap_vault_key(&kek2, &wrapped).unwrap();
        assert_eq!(vault_key, unwrapped);

        // 5. Encrypt and decrypt an item
        let plaintext = r#"{"password":"super-secret","notes":"important"}"#;
        let encrypted = encrypt_blob(&vault_key, plaintext, "item-uuid-1").unwrap();
        let decrypted = decrypt_blob(&unwrapped, &encrypted, "item-uuid-1").unwrap();
        assert_eq!(decrypted, plaintext);
    }
}
