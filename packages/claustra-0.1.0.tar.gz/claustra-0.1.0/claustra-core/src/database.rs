use rusqlite::{params, Connection, OptionalExtension};

use crate::error::{Result, ClaustraError};
use crate::models::*;

// 将 rusqlite::Error 包装为 ClaustraError::Database
fn db_err(e: rusqlite::Error) -> ClaustraError {
    ClaustraError::Database(e)
}

pub struct Database {
    conn: Connection,
}

/// Represents an item in the v1 schema where sensitive data is stored as an encrypted blob.
pub struct ItemRowV1 {
    pub id: String,
    pub category: String,
    pub is_favorite: bool,
    pub is_pinned: bool,
    pub folder_id: Option<String>,
    pub encrypted_data: String, // Base64-encoded encrypted blob
    pub created_at: String,
    pub updated_at: String,
    pub deleted_at: Option<String>,
    pub sync_version: i64,
    pub archived_at: Option<String>,
}

impl Database {
    /// 打开文件数据库，并初始化表结构
    pub fn new(path: &str) -> Result<Self> {
        let conn = Connection::open(path)
            .map_err(db_err)?;
        let db = Self { conn };
        db.init_tables()?;
        Ok(db)
    }

    /// 打开内存数据库（测试用）
    pub fn new_in_memory() -> Result<Self> {
        let conn = Connection::open_in_memory()
            .map_err(db_err)?;
        let db = Self { conn };
        db.init_tables()?;
        Ok(db)
    }

    /// 初始化所有表结构，并按需执行迁移
    fn init_tables(&self) -> Result<()> {
        self.init_tables_v1()?;
        let version = self.get_schema_version()?;
        if version < 2 {
            self.migrate_v1_to_v2()?;
        }
        let version = self.get_schema_version()?;
        if version < 3 {
            self.migrate_v2_to_v3()?;
        }
        let version = self.get_schema_version()?;
        if version < 4 {
            self.migrate_v3_to_v4()?;
        }
        let version = self.get_schema_version()?;
        if version < 5 {
            self.migrate_v4_to_v5()?;
        }
        Ok(())
    }

    /// v0 schema: legacy plaintext columns (kept for migration purposes)
    fn init_tables_v0(&self) -> Result<()> {
        self.conn
            .execute_batch(
                "
                CREATE TABLE IF NOT EXISTS items (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL DEFAULT '',
                    username TEXT NOT NULL DEFAULT '',
                    password TEXT NOT NULL DEFAULT '',
                    website TEXT NOT NULL DEFAULT '',
                    notes TEXT NOT NULL DEFAULT '',
                    category TEXT NOT NULL DEFAULT 'logins',
                    is_favorite INTEGER NOT NULL DEFAULT 0,
                    is_pinned INTEGER NOT NULL DEFAULT 0,
                    icon_emoji TEXT NOT NULL DEFAULT '🔑',
                    icon_bg_color TEXT NOT NULL DEFAULT '#2b7fff',
                    tags TEXT NOT NULL DEFAULT '[]',
                    security_questions TEXT NOT NULL DEFAULT '[]',
                    custom_fields TEXT NOT NULL DEFAULT '[]',
                    password_history TEXT NOT NULL DEFAULT '[]',
                    totp_secret TEXT NOT NULL DEFAULT '',
                    expires_at TEXT NOT NULL DEFAULT '',
                    folder_id TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    deleted_at TEXT
                );

                CREATE TABLE IF NOT EXISTS folders (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    icon TEXT NOT NULL DEFAULT '📁'
                );

                CREATE TABLE IF NOT EXISTS favicon_cache (
                    domain TEXT PRIMARY KEY,
                    data_url TEXT NOT NULL,
                    fetched_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                ",
            )
            .map_err(db_err)
    }

    /// v1 schema: sensitive fields stored as a single encrypted blob
    fn init_tables_v1(&self) -> Result<()> {
        self.init_tables_v0()?;
        self.conn
            .execute_batch(
                "
                CREATE TABLE IF NOT EXISTS items_v1 (
                    id TEXT PRIMARY KEY,
                    category TEXT NOT NULL DEFAULT 'logins',
                    is_favorite INTEGER NOT NULL DEFAULT 0,
                    is_pinned INTEGER NOT NULL DEFAULT 0,
                    folder_id TEXT,
                    encrypted_data TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    deleted_at TEXT
                );

                INSERT OR IGNORE INTO settings (key, value) VALUES ('schema_version', '1');
                ",
            )
            .map_err(db_err)
    }

    /// v1 → v2 migration: add sync_version column to items_v1 and create sync_metadata table.
    fn migrate_v1_to_v2(&self) -> Result<()> {
        // ALTER TABLE is idempotent-ish: SQLite errors if column already exists.
        // Use a separate execute so we can ignore the "duplicate column" error.
        let alter_result = self.conn.execute_batch(
            "ALTER TABLE items_v1 ADD COLUMN sync_version INTEGER NOT NULL DEFAULT 0;",
        );
        // Ignore error if column already exists (SQLite error message contains "duplicate column")
        if let Err(ref e) = alter_result {
            let msg = e.to_string();
            if !msg.contains("duplicate column") {
                alter_result.map_err(db_err)?;
            }
        }

        self.conn
            .execute_batch(
                "
                CREATE TABLE IF NOT EXISTS sync_metadata (
                    key   TEXT PRIMARY KEY NOT NULL,
                    value TEXT NOT NULL
                );

                INSERT OR REPLACE INTO settings (key, value) VALUES ('schema_version', '2');
                ",
            )
            .map_err(db_err)?;

        Ok(())
    }

    /// v2 → v3 migration: add archived_at column to items_v1.
    fn migrate_v2_to_v3(&self) -> Result<()> {
        let alter_result = self.conn.execute_batch(
            "ALTER TABLE items_v1 ADD COLUMN archived_at TEXT;",
        );
        if let Err(ref e) = alter_result {
            let msg = e.to_string();
            if !msg.contains("duplicate column") {
                alter_result.map_err(db_err)?;
            }
        }

        self.conn
            .execute_batch(
                "INSERT OR REPLACE INTO settings (key, value) VALUES ('schema_version', '3');",
            )
            .map_err(db_err)?;

        Ok(())
    }

    /// v3 → v4 migration: create the attachments table.
    fn migrate_v3_to_v4(&self) -> Result<()> {
        self.conn
            .execute_batch(
                "
                CREATE TABLE IF NOT EXISTS attachments (
                    id TEXT PRIMARY KEY,
                    item_id TEXT NOT NULL,
                    filename TEXT NOT NULL,
                    mime_type TEXT NOT NULL DEFAULT '',
                    size INTEGER NOT NULL DEFAULT 0,
                    encrypted_data TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (item_id) REFERENCES items_v1(id) ON DELETE CASCADE
                );

                INSERT OR REPLACE INTO settings (key, value) VALUES ('schema_version', '4');
                ",
            )
            .map_err(db_err)?;

        Ok(())
    }

    /// v4 → v5 migration: create the audit_log table.
    fn migrate_v4_to_v5(&self) -> Result<()> {
        self.conn
            .execute_batch(
                "
                CREATE TABLE IF NOT EXISTS audit_log (
                    id TEXT PRIMARY KEY,
                    event_type TEXT NOT NULL,
                    device_id TEXT,
                    device_name TEXT,
                    item_id TEXT,
                    details TEXT,
                    timestamp TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT (datetime('now'))
                );

                CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit_log(timestamp);
                CREATE INDEX IF NOT EXISTS idx_audit_log_event_type ON audit_log(event_type);

                INSERT OR REPLACE INTO settings (key, value) VALUES ('schema_version', '5');
                ",
            )
            .map_err(db_err)?;

        Ok(())
    }

    // -------------------------------------------------------------------------
    // Audit Log
    // -------------------------------------------------------------------------

    /// Insert an audit log entry.
    pub fn insert_audit_entry(
        &self,
        id: &str,
        event_type: &str,
        device_id: Option<&str>,
        device_name: Option<&str>,
        item_id: Option<&str>,
        details: Option<&str>,
        timestamp: &str,
    ) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO audit_log (id, event_type, device_id, device_name, item_id, details, timestamp)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
                params![id, event_type, device_id, device_name, item_id, details, timestamp],
            )
            .map_err(db_err)?;
        Ok(())
    }

    /// Get audit log entries, ordered by timestamp descending, with pagination.
    pub fn get_audit_log(&self, limit: usize, offset: usize) -> Result<Vec<AuditEntry>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT id, event_type, device_id, device_name, item_id, details, timestamp
                 FROM audit_log ORDER BY timestamp DESC LIMIT ?1 OFFSET ?2",
            )
            .map_err(db_err)?;

        let rows = stmt
            .query_map(params![limit as i64, offset as i64], row_to_audit_entry)
            .map_err(db_err)?;

        let mut entries = Vec::new();
        for row in rows {
            entries.push(row.map_err(db_err)?);
        }
        Ok(entries)
    }

    /// Get audit log entries for a specific device.
    pub fn get_audit_log_for_device(
        &self,
        device_id: &str,
        limit: usize,
    ) -> Result<Vec<AuditEntry>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT id, event_type, device_id, device_name, item_id, details, timestamp
                 FROM audit_log WHERE device_id = ?1 ORDER BY timestamp DESC LIMIT ?2",
            )
            .map_err(db_err)?;

        let rows = stmt
            .query_map(params![device_id, limit as i64], row_to_audit_entry)
            .map_err(db_err)?;

        let mut entries = Vec::new();
        for row in rows {
            entries.push(row.map_err(db_err)?);
        }
        Ok(entries)
    }

    /// Delete audit log entries older than the given ISO-8601 timestamp.
    /// Returns the number of rows deleted.
    pub fn clear_audit_log_before(&self, before: &str) -> Result<usize> {
        let count = self
            .conn
            .execute(
                "DELETE FROM audit_log WHERE timestamp < ?1",
                params![before],
            )
            .map_err(db_err)?;
        Ok(count)
    }

    // -------------------------------------------------------------------------
    // Items CRUD
    // -------------------------------------------------------------------------

    /// 插入一条密码条目
    pub fn insert_item(&self, item: &PasswordItem) -> Result<()> {
        let category_str = item.category.to_string();
        let tags_json = serde_json::to_string(&item.tags)
            .unwrap_or_else(|_| "[]".to_string());
        let security_questions_json = serde_json::to_string(&item.security_questions)
            .unwrap_or_else(|_| "[]".to_string());
        let custom_fields_json = serde_json::to_string(&item.custom_fields)
            .unwrap_or_else(|_| "[]".to_string());
        let password_history_json = serde_json::to_string(&item.password_history)
            .unwrap_or_else(|_| "[]".to_string());

        self.conn
            .execute(
                "INSERT INTO items (
                    id, title, username, password, website, notes, category,
                    is_favorite, is_pinned, icon_emoji, icon_bg_color,
                    tags, security_questions, custom_fields, password_history,
                    totp_secret, expires_at, folder_id, created_at, updated_at, deleted_at
                ) VALUES (
                    ?1, ?2, ?3, ?4, ?5, ?6, ?7,
                    ?8, ?9, ?10, ?11,
                    ?12, ?13, ?14, ?15,
                    ?16, ?17, ?18, ?19, ?20, ?21
                )",
                params![
                    item.id,
                    item.title,
                    item.username,
                    item.password,
                    item.website,
                    item.notes,
                    category_str,
                    item.is_favorite as i64,
                    item.is_pinned as i64,
                    item.icon_emoji,
                    item.icon_bg_color,
                    tags_json,
                    security_questions_json,
                    custom_fields_json,
                    password_history_json,
                    item.totp_secret,
                    item.expires_at,
                    item.folder_id,
                    item.created_at,
                    item.updated_at,
                    item.deleted_at,
                ],
            )
            .map_err(db_err)?;
        Ok(())
    }

    /// 通过 id 获取单条密码条目
    pub fn get_item(&self, id: &str) -> Result<PasswordItem> {
        let mut stmt = self
            .conn
            .prepare("SELECT * FROM items WHERE id = ?1")
            .map_err(db_err)?;

        let item = stmt
            .query_row(params![id], row_to_item)
            .optional()
            .map_err(db_err)?
            .ok_or_else(|| ClaustraError::NotFound(id.to_string()))?;

        Ok(item)
    }

    /// 获取所有条目（含已删除）
    pub fn get_all_items(&self) -> Result<Vec<PasswordItem>> {
        let mut stmt = self
            .conn
            .prepare("SELECT * FROM items ORDER BY created_at DESC")
            .map_err(db_err)?;

        let items = stmt
            .query_map([], row_to_item)
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(items)
    }

    /// 更新一条密码条目
    pub fn update_item(&self, item: &PasswordItem) -> Result<()> {
        let category_str = item.category.to_string();
        let tags_json = serde_json::to_string(&item.tags)
            .unwrap_or_else(|_| "[]".to_string());
        let security_questions_json = serde_json::to_string(&item.security_questions)
            .unwrap_or_else(|_| "[]".to_string());
        let custom_fields_json = serde_json::to_string(&item.custom_fields)
            .unwrap_or_else(|_| "[]".to_string());
        let password_history_json = serde_json::to_string(&item.password_history)
            .unwrap_or_else(|_| "[]".to_string());

        let rows = self
            .conn
            .execute(
                "UPDATE items SET
                    title = ?2, username = ?3, password = ?4, website = ?5,
                    notes = ?6, category = ?7, is_favorite = ?8, is_pinned = ?9,
                    icon_emoji = ?10, icon_bg_color = ?11, tags = ?12,
                    security_questions = ?13, custom_fields = ?14,
                    password_history = ?15, totp_secret = ?16, expires_at = ?17,
                    folder_id = ?18, created_at = ?19, updated_at = ?20, deleted_at = ?21
                WHERE id = ?1",
                params![
                    item.id,
                    item.title,
                    item.username,
                    item.password,
                    item.website,
                    item.notes,
                    category_str,
                    item.is_favorite as i64,
                    item.is_pinned as i64,
                    item.icon_emoji,
                    item.icon_bg_color,
                    tags_json,
                    security_questions_json,
                    custom_fields_json,
                    password_history_json,
                    item.totp_secret,
                    item.expires_at,
                    item.folder_id,
                    item.created_at,
                    item.updated_at,
                    item.deleted_at,
                ],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(item.id.clone()));
        }
        Ok(())
    }

    /// 软删除：设置 deleted_at 为当前 UTC 时间
    pub fn soft_delete_item(&self, id: &str) -> Result<()> {
        let now = chrono::Utc::now().to_rfc3339();
        let rows = self
            .conn
            .execute(
                "UPDATE items SET deleted_at = ?2 WHERE id = ?1 AND deleted_at IS NULL",
                params![id, now],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// 恢复软删除的条目：清空 deleted_at
    pub fn restore_item(&self, id: &str) -> Result<()> {
        let rows = self
            .conn
            .execute(
                "UPDATE items SET deleted_at = NULL WHERE id = ?1",
                params![id],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// 永久删除单条条目
    pub fn permanently_delete_item(&self, id: &str) -> Result<()> {
        let rows = self
            .conn
            .execute("DELETE FROM items WHERE id = ?1", params![id])
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// 清空回收站：删除所有 deleted_at 不为空的条目，返回删除数量
    pub fn empty_trash(&self) -> Result<u64> {
        let rows = self
            .conn
            .execute(
                "DELETE FROM items WHERE deleted_at IS NOT NULL",
                [],
            )
            .map_err(db_err)?;
        Ok(rows as u64)
    }

    /// 获取所有活跃条目（deleted_at IS NULL）
    pub fn get_active_items(&self) -> Result<Vec<PasswordItem>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT * FROM items WHERE deleted_at IS NULL ORDER BY updated_at DESC",
            )
            .map_err(db_err)?;

        let items = stmt
            .query_map([], row_to_item)
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(items)
    }

    /// 获取所有回收站条目（deleted_at IS NOT NULL）
    pub fn get_trashed_items(&self) -> Result<Vec<PasswordItem>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT * FROM items WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC",
            )
            .map_err(db_err)?;

        let items = stmt
            .query_map([], row_to_item)
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(items)
    }

    /// 搜索活跃条目：在 title、username、tags 中进行大小写不敏感的模糊匹配
    pub fn search_items(&self, query: &str) -> Result<Vec<PasswordItem>> {
        let pattern = format!("%{}%", query.to_lowercase());
        let mut stmt = self
            .conn
            .prepare(
                "SELECT * FROM items
                WHERE deleted_at IS NULL
                  AND (
                    LOWER(title) LIKE ?1
                    OR LOWER(username) LIKE ?1
                    OR LOWER(tags) LIKE ?1
                  )
                ORDER BY updated_at DESC",
            )
            .map_err(db_err)?;

        let items = stmt
            .query_map(params![pattern], row_to_item)
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(items)
    }

    // -------------------------------------------------------------------------
    // Folders CRUD
    // -------------------------------------------------------------------------

    /// 插入文件夹
    pub fn insert_folder(&self, folder: &Folder) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO folders (id, name, icon) VALUES (?1, ?2, ?3)",
                params![folder.id, folder.name, folder.icon],
            )
            .map_err(db_err)?;
        Ok(())
    }

    /// 获取所有文件夹
    pub fn get_all_folders(&self) -> Result<Vec<Folder>> {
        let mut stmt = self
            .conn
            .prepare("SELECT id, name, icon FROM folders ORDER BY name")
            .map_err(db_err)?;

        let folders = stmt
            .query_map([], |row| {
                Ok(Folder {
                    id: row.get(0)?,
                    name: row.get(1)?,
                    icon: row.get(2)?,
                })
            })
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(folders)
    }

    /// 更新文件夹
    pub fn update_folder(&self, folder: &Folder) -> Result<()> {
        let rows = self
            .conn
            .execute(
                "UPDATE folders SET name = ?2, icon = ?3 WHERE id = ?1",
                params![folder.id, folder.name, folder.icon],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(folder.id.clone()));
        }
        Ok(())
    }

    /// 删除文件夹，同时将该文件夹下的条目的 folder_id 置为 NULL
    pub fn delete_folder(&self, id: &str) -> Result<()> {
        // 解除条目与文件夹的关联
        self.conn
            .execute(
                "UPDATE items SET folder_id = NULL WHERE folder_id = ?1",
                params![id],
            )
            .map_err(db_err)?;

        let rows = self
            .conn
            .execute("DELETE FROM folders WHERE id = ?1", params![id])
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    // -------------------------------------------------------------------------
    // Favicon Cache
    // -------------------------------------------------------------------------

    /// 插入或更新 favicon 缓存
    pub fn upsert_favicon(&self, entry: &FaviconEntry) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO favicon_cache (domain, data_url, fetched_at)
                VALUES (?1, ?2, ?3)
                ON CONFLICT(domain) DO UPDATE SET
                    data_url = excluded.data_url,
                    fetched_at = excluded.fetched_at",
                params![entry.domain, entry.data_url, entry.fetched_at],
            )
            .map_err(db_err)?;
        Ok(())
    }

    /// 获取单个 favicon 缓存
    pub fn get_favicon(&self, domain: &str) -> Result<Option<FaviconEntry>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT domain, data_url, fetched_at FROM favicon_cache WHERE domain = ?1",
            )
            .map_err(db_err)?;

        let entry = stmt
            .query_row(params![domain], |row| {
                Ok(FaviconEntry {
                    domain: row.get(0)?,
                    data_url: row.get(1)?,
                    fetched_at: row.get(2)?,
                })
            })
            .optional()
            .map_err(db_err)?;

        Ok(entry)
    }

    /// 获取所有 favicon 缓存
    pub fn get_all_favicons(&self) -> Result<Vec<FaviconEntry>> {
        let mut stmt = self
            .conn
            .prepare("SELECT domain, data_url, fetched_at FROM favicon_cache")
            .map_err(db_err)?;

        let entries = stmt
            .query_map([], |row| {
                Ok(FaviconEntry {
                    domain: row.get(0)?,
                    data_url: row.get(1)?,
                    fetched_at: row.get(2)?,
                })
            })
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(entries)
    }

    // -------------------------------------------------------------------------
    // Settings
    // -------------------------------------------------------------------------

    /// 设置键值对（upsert）
    pub fn set_setting(&self, key: &str, value: &str) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO settings (key, value) VALUES (?1, ?2)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                params![key, value],
            )
            .map_err(db_err)?;
        Ok(())
    }

    /// 获取设置值（不存在时返回 None）
    pub fn get_setting(&self, key: &str) -> Result<Option<String>> {
        let mut stmt = self
            .conn
            .prepare("SELECT value FROM settings WHERE key = ?1")
            .map_err(db_err)?;

        let value = stmt
            .query_row(params![key], |row| row.get::<_, String>(0))
            .optional()
            .map_err(db_err)?;

        Ok(value)
    }
}

// =============================================================================
// v1 schema methods
// =============================================================================

impl Database {
    /// Insert an item into the items_v1 table. sync_version is always set to 0 on insert.
    pub fn insert_item_v1(&self, item: &ItemRowV1) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO items_v1 (
                    id, category, is_favorite, is_pinned, folder_id,
                    encrypted_data, created_at, updated_at, deleted_at, sync_version, archived_at
                ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, 0, ?10)",
                params![
                    item.id,
                    item.category,
                    item.is_favorite as i64,
                    item.is_pinned as i64,
                    item.folder_id,
                    item.encrypted_data,
                    item.created_at,
                    item.updated_at,
                    item.deleted_at,
                    item.archived_at,
                ],
            )
            .map_err(db_err)?;
        Ok(())
    }

    /// Get a single item from items_v1 by id.
    pub fn get_item_v1(&self, id: &str) -> Result<ItemRowV1> {
        let mut stmt = self
            .conn
            .prepare("SELECT * FROM items_v1 WHERE id = ?1")
            .map_err(db_err)?;

        let item = stmt
            .query_row(params![id], row_to_item_v1)
            .optional()
            .map_err(db_err)?
            .ok_or_else(|| ClaustraError::NotFound(id.to_string()))?;

        Ok(item)
    }

    /// Get all active items (deleted_at IS NULL AND archived_at IS NULL), ordered by updated_at DESC.
    pub fn get_active_items_v1(&self) -> Result<Vec<ItemRowV1>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT * FROM items_v1 WHERE deleted_at IS NULL AND archived_at IS NULL ORDER BY updated_at DESC",
            )
            .map_err(db_err)?;

        let items = stmt
            .query_map([], row_to_item_v1)
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(items)
    }

    /// Get all trashed items (deleted_at IS NOT NULL), ordered by deleted_at DESC.
    pub fn get_trashed_items_v1(&self) -> Result<Vec<ItemRowV1>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT * FROM items_v1 WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC",
            )
            .map_err(db_err)?;

        let items = stmt
            .query_map([], row_to_item_v1)
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(items)
    }

    /// Get all archived items (archived_at IS NOT NULL AND deleted_at IS NULL), ordered by archived_at DESC.
    pub fn get_archived_items_v1(&self) -> Result<Vec<ItemRowV1>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT * FROM items_v1 WHERE archived_at IS NOT NULL AND deleted_at IS NULL ORDER BY archived_at DESC",
            )
            .map_err(db_err)?;

        let items = stmt
            .query_map([], row_to_item_v1)
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(items)
    }

    /// Update an item in items_v1. sync_version is incremented automatically.
    /// Returns NotFound if 0 rows are affected.
    pub fn update_item_v1(&self, item: &ItemRowV1) -> Result<()> {
        let rows = self
            .conn
            .execute(
                "UPDATE items_v1 SET
                    category = ?2, is_favorite = ?3, is_pinned = ?4,
                    folder_id = ?5, encrypted_data = ?6,
                    created_at = ?7, updated_at = ?8, deleted_at = ?9,
                    archived_at = ?10,
                    sync_version = sync_version + 1
                WHERE id = ?1",
                params![
                    item.id,
                    item.category,
                    item.is_favorite as i64,
                    item.is_pinned as i64,
                    item.folder_id,
                    item.encrypted_data,
                    item.created_at,
                    item.updated_at,
                    item.deleted_at,
                    item.archived_at,
                ],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(item.id.clone()));
        }
        Ok(())
    }

    /// Soft-delete an item in items_v1 by setting deleted_at to current UTC time.
    pub fn soft_delete_item_v1(&self, id: &str) -> Result<()> {
        let now = chrono::Utc::now().to_rfc3339();
        let rows = self
            .conn
            .execute(
                "UPDATE items_v1 SET deleted_at = ?2 WHERE id = ?1 AND deleted_at IS NULL",
                params![id, now],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// Restore a soft-deleted item in items_v1 by clearing deleted_at.
    pub fn restore_item_v1(&self, id: &str) -> Result<()> {
        let rows = self
            .conn
            .execute(
                "UPDATE items_v1 SET deleted_at = NULL WHERE id = ?1",
                params![id],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// Archive an item in items_v1 by setting archived_at to current UTC time.
    pub fn archive_item_v1(&self, id: &str) -> Result<()> {
        let now = chrono::Utc::now().to_rfc3339();
        let rows = self
            .conn
            .execute(
                "UPDATE items_v1 SET archived_at = ?2 WHERE id = ?1 AND archived_at IS NULL AND deleted_at IS NULL",
                params![id, now],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// Unarchive an item in items_v1 by clearing archived_at.
    pub fn unarchive_item_v1(&self, id: &str) -> Result<()> {
        let rows = self
            .conn
            .execute(
                "UPDATE items_v1 SET archived_at = NULL WHERE id = ?1",
                params![id],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// Permanently delete a single item from items_v1.
    pub fn permanently_delete_item_v1(&self, id: &str) -> Result<()> {
        let rows = self
            .conn
            .execute("DELETE FROM items_v1 WHERE id = ?1", params![id])
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// Delete all trashed items from items_v1. Returns the number of deleted rows.
    pub fn empty_trash_v1(&self) -> Result<u64> {
        let rows = self
            .conn
            .execute("DELETE FROM items_v1 WHERE deleted_at IS NOT NULL", [])
            .map_err(db_err)?;
        Ok(rows as u64)
    }

    /// Count all active (non-deleted, non-archived) items in items_v1.
    pub fn count_active_items_v1(&self) -> Result<u64> {
        let count: i64 = self
            .conn
            .query_row(
                "SELECT COUNT(*) FROM items_v1 WHERE deleted_at IS NULL AND archived_at IS NULL",
                [],
                |row| row.get(0),
            )
            .map_err(db_err)?;
        Ok(count as u64)
    }

    /// Search active items in items_v1.
    ///
    /// Since most fields are encrypted, SQL-level text search is not possible.
    /// This method returns all active items; the store layer should decrypt and
    /// filter in memory.
    pub fn search_items_v1(&self, _query: &str) -> Result<Vec<ItemRowV1>> {
        self.get_active_items_v1()
    }

    /// Get all items from items_v1, including deleted ones.
    pub fn get_all_items_v1(&self) -> Result<Vec<ItemRowV1>> {
        let mut stmt = self
            .conn
            .prepare("SELECT * FROM items_v1 ORDER BY updated_at DESC")
            .map_err(db_err)?;

        let items = stmt
            .query_map([], row_to_item_v1)
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(items)
    }

    /// Read the schema_version from the settings table.
    /// Returns 0 if the key is not present (legacy schema).
    pub fn get_schema_version(&self) -> Result<u32> {
        let value = self.get_setting("schema_version")?;
        Ok(value
            .and_then(|v| v.parse::<u32>().ok())
            .unwrap_or(0))
    }

    // -------------------------------------------------------------------------
    // Sync Metadata
    // -------------------------------------------------------------------------

    /// Get a sync metadata value by key. Returns None if the key does not exist.
    pub fn get_sync_metadata(&self, key: &str) -> Result<Option<String>> {
        let mut stmt = self
            .conn
            .prepare("SELECT value FROM sync_metadata WHERE key = ?1")
            .map_err(db_err)?;

        let value = stmt
            .query_row(params![key], |row| row.get::<_, String>(0))
            .optional()
            .map_err(db_err)?;

        Ok(value)
    }

    /// Set (upsert) a sync metadata value.
    pub fn set_sync_metadata(&self, key: &str, value: &str) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO sync_metadata (key, value) VALUES (?1, ?2)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                params![key, value],
            )
            .map_err(db_err)?;
        Ok(())
    }

    /// Increment sync_version for a single item in items_v1.
    /// Returns NotFound if no row with the given id exists.
    pub fn increment_sync_version(&self, item_id: &str) -> Result<()> {
        let rows = self
            .conn
            .execute(
                "UPDATE items_v1 SET sync_version = sync_version + 1 WHERE id = ?1",
                params![item_id],
            )
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(item_id.to_string()));
        }
        Ok(())
    }

    // -------------------------------------------------------------------------
    // Attachments CRUD
    // -------------------------------------------------------------------------

    /// Insert an attachment row. `encrypted_data` is a Base64-encoded encrypted blob.
    pub fn insert_attachment(
        &self,
        id: &str,
        item_id: &str,
        filename: &str,
        mime_type: &str,
        size: u64,
        encrypted_data: &str,
        created_at: &str,
    ) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO attachments (id, item_id, filename, mime_type, size, encrypted_data, created_at)
                VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
                params![id, item_id, filename, mime_type, size as i64, encrypted_data, created_at],
            )
            .map_err(db_err)?;
        Ok(())
    }

    /// Get a single attachment row by id. Returns (metadata fields, encrypted_data).
    pub fn get_attachment(
        &self,
        id: &str,
    ) -> Result<(String, String, String, String, u64, String, String)> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT id, item_id, filename, mime_type, size, encrypted_data, created_at
                FROM attachments WHERE id = ?1",
            )
            .map_err(db_err)?;

        let row = stmt
            .query_row(params![id], |row| {
                let size: i64 = row.get(4)?;
                Ok((
                    row.get::<_, String>(0)?,
                    row.get::<_, String>(1)?,
                    row.get::<_, String>(2)?,
                    row.get::<_, String>(3)?,
                    size as u64,
                    row.get::<_, String>(5)?,
                    row.get::<_, String>(6)?,
                ))
            })
            .optional()
            .map_err(db_err)?
            .ok_or_else(|| ClaustraError::NotFound(id.to_string()))?;

        Ok(row)
    }

    /// Get all attachment rows for a given item_id (metadata only, no encrypted_data).
    pub fn get_attachments_for_item(
        &self,
        item_id: &str,
    ) -> Result<Vec<(String, String, String, String, u64, String)>> {
        let mut stmt = self
            .conn
            .prepare(
                "SELECT id, item_id, filename, mime_type, size, created_at
                FROM attachments WHERE item_id = ?1 ORDER BY created_at ASC",
            )
            .map_err(db_err)?;

        let rows = stmt
            .query_map(params![item_id], |row| {
                let size: i64 = row.get(4)?;
                Ok((
                    row.get::<_, String>(0)?,
                    row.get::<_, String>(1)?,
                    row.get::<_, String>(2)?,
                    row.get::<_, String>(3)?,
                    size as u64,
                    row.get::<_, String>(5)?,
                ))
            })
            .map_err(db_err)?
            .filter_map(|r| r.ok())
            .collect();

        Ok(rows)
    }

    /// Delete a single attachment by id. Returns NotFound if no row was deleted.
    pub fn delete_attachment(&self, id: &str) -> Result<()> {
        let rows = self
            .conn
            .execute("DELETE FROM attachments WHERE id = ?1", params![id])
            .map_err(db_err)?;

        if rows == 0 {
            return Err(ClaustraError::NotFound(id.to_string()));
        }
        Ok(())
    }

    /// Delete all attachments for a given item_id.
    pub fn delete_attachments_for_item(&self, item_id: &str) -> Result<()> {
        self.conn
            .execute(
                "DELETE FROM attachments WHERE item_id = ?1",
                params![item_id],
            )
            .map_err(db_err)?;
        Ok(())
    }
}

// -----------------------------------------------------------------------------
// 辅助函数：将数据库行转换为 PasswordItem
// 列顺序与 CREATE TABLE 中的定义一致（SELECT * 时按此顺序）：
//  0: id, 1: title, 2: username, 3: password, 4: website, 5: notes,
//  6: category, 7: is_favorite, 8: is_pinned, 9: icon_emoji, 10: icon_bg_color,
// 11: tags, 12: security_questions, 13: custom_fields, 14: password_history,
// 15: totp_secret, 16: expires_at, 17: folder_id, 18: created_at, 19: updated_at,
// 20: deleted_at
// -----------------------------------------------------------------------------

fn row_to_item(row: &rusqlite::Row) -> rusqlite::Result<PasswordItem> {
    let category_str: String = row.get(6)?;
    let category = category_str
        .parse::<Category>()
        .unwrap_or(Category::Logins);

    let is_favorite: i64 = row.get(7)?;
    let is_pinned: i64 = row.get(8)?;

    let tags_json: String = row.get(11)?;
    let tags: Vec<String> = serde_json::from_str(&tags_json).unwrap_or_default();

    let security_questions_json: String = row.get(12)?;
    let security_questions: Vec<SecurityQuestion> =
        serde_json::from_str(&security_questions_json).unwrap_or_default();

    let custom_fields_json: String = row.get(13)?;
    let custom_fields: Vec<CustomField> =
        serde_json::from_str(&custom_fields_json).unwrap_or_default();

    let password_history_json: String = row.get(14)?;
    let password_history: Vec<PasswordHistoryEntry> =
        serde_json::from_str(&password_history_json).unwrap_or_default();

    Ok(PasswordItem {
        id: row.get(0)?,
        title: row.get(1)?,
        username: row.get(2)?,
        password: row.get(3)?,
        website: row.get(4)?,
        notes: row.get(5)?,
        category,
        is_favorite: is_favorite != 0,
        is_pinned: is_pinned != 0,
        icon_emoji: row.get(9)?,
        icon_bg_color: row.get(10)?,
        tags,
        security_questions,
        custom_fields,
        password_history,
        totp_secret: row.get(15)?,
        expires_at: row.get(16)?,
        folder_id: row.get(17)?,
        created_at: row.get(18)?,
        updated_at: row.get(19)?,
        deleted_at: row.get(20)?,
        archived_at: None,
    })
}

// -----------------------------------------------------------------------------
// Helper: convert a row to ItemRowV1
// Column order matches CREATE TABLE items_v1 definition (used by SELECT *):
//  0: id, 1: category, 2: is_favorite, 3: is_pinned, 4: folder_id,
//  5: encrypted_data, 6: created_at, 7: updated_at, 8: deleted_at,
//  9: sync_version, 10: archived_at
// -----------------------------------------------------------------------------

fn row_to_item_v1(row: &rusqlite::Row) -> rusqlite::Result<ItemRowV1> {
    let is_favorite: i64 = row.get(2)?;
    let is_pinned: i64 = row.get(3)?;
    Ok(ItemRowV1 {
        id: row.get(0)?,
        category: row.get(1)?,
        is_favorite: is_favorite != 0,
        is_pinned: is_pinned != 0,
        folder_id: row.get(4)?,
        encrypted_data: row.get(5)?,
        created_at: row.get(6)?,
        updated_at: row.get(7)?,
        deleted_at: row.get(8)?,
        sync_version: row.get(9).unwrap_or(0),
        archived_at: row.get(10).unwrap_or(None),
    })
}

// -----------------------------------------------------------------------------
// Audit log entry + row mapper
// -----------------------------------------------------------------------------

/// A single audit log entry.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct AuditEntry {
    pub id: String,
    pub event_type: String,
    pub device_id: Option<String>,
    pub device_name: Option<String>,
    pub item_id: Option<String>,
    pub details: Option<String>,
    pub timestamp: String,
}

fn row_to_audit_entry(row: &rusqlite::Row) -> rusqlite::Result<AuditEntry> {
    Ok(AuditEntry {
        id: row.get(0)?,
        event_type: row.get(1)?,
        device_id: row.get(2)?,
        device_name: row.get(3)?,
        item_id: row.get(4)?,
        details: row.get(5)?,
        timestamp: row.get(6)?,
    })
}

/// Device revocation record (local audit trail only; actual CloudKit
/// record deletion is handled on the Swift side).
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct DeviceRevocation {
    pub device_id: String,
    pub revoked_at: String,
    pub reason: String,
}

// -----------------------------------------------------------------------------
// 单元测试
// -----------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// 创建一个用于测试的 PasswordItem
    fn make_item(id: &str, title: &str) -> PasswordItem {
        let now = chrono::Utc::now().to_rfc3339();
        PasswordItem {
            id: id.to_string(),
            title: title.to_string(),
            username: "user@example.com".to_string(),
            password: "secret123".to_string(),
            website: "https://example.com".to_string(),
            notes: "some notes".to_string(),
            category: Category::Logins,
            is_favorite: false,
            is_pinned: false,
            icon_emoji: "\u{1F511}".to_string(),
            icon_bg_color: "#2b7fff".to_string(),
            tags: vec!["work".to_string(), "important".to_string()],
            security_questions: vec![],
            custom_fields: vec![],
            password_history: vec![],
            totp_secret: "".to_string(),
            expires_at: "".to_string(),
            folder_id: None,
            created_at: now.clone(),
            updated_at: now,
            deleted_at: None,
            archived_at: None,
        }
    }

    /// 创建一个用于测试的 Folder
    fn make_folder(id: &str, name: &str) -> Folder {
        Folder {
            id: id.to_string(),
            name: name.to_string(),
            icon: "\u{1F4C1}".to_string(),
        }
    }

    #[test]
    fn test_insert_and_get_item() {
        let db = Database::new_in_memory().unwrap();
        let item = make_item("id-001", "GitHub");
        db.insert_item(&item).unwrap();

        let fetched = db.get_item("id-001").unwrap();
        assert_eq!(fetched.id, "id-001");
        assert_eq!(fetched.title, "GitHub");
        assert_eq!(fetched.username, "user@example.com");
        assert_eq!(fetched.tags, vec!["work", "important"]);
        assert!(!fetched.is_favorite);
    }

    #[test]
    fn test_get_item_not_found() {
        let db = Database::new_in_memory().unwrap();
        let result = db.get_item("nonexistent");
        assert!(result.is_err());
    }

    #[test]
    fn test_update_item() {
        let db = Database::new_in_memory().unwrap();
        let mut item = make_item("id-002", "Gmail");
        db.insert_item(&item).unwrap();

        item.title = "Gmail Updated".to_string();
        item.is_favorite = true;
        db.update_item(&item).unwrap();

        let fetched = db.get_item("id-002").unwrap();
        assert_eq!(fetched.title, "Gmail Updated");
        assert!(fetched.is_favorite);
    }

    #[test]
    fn test_update_nonexistent_item() {
        let db = Database::new_in_memory().unwrap();
        let item = make_item("nonexistent", "Test");
        let result = db.update_item(&item);
        assert!(result.is_err());
    }

    #[test]
    fn test_soft_delete_and_restore() {
        let db = Database::new_in_memory().unwrap();
        let item = make_item("id-003", "Twitter");
        db.insert_item(&item).unwrap();

        // 软删除后条目不出现在活跃列表
        db.soft_delete_item("id-003").unwrap();
        let active = db.get_active_items().unwrap();
        assert!(active.iter().all(|i| i.id != "id-003"));

        // 出现在回收站列表且 deleted_at 已设置
        let trashed = db.get_trashed_items().unwrap();
        assert!(trashed.iter().any(|i| i.id == "id-003"));
        assert!(
            trashed
                .iter()
                .find(|i| i.id == "id-003")
                .unwrap()
                .deleted_at
                .is_some()
        );

        // 恢复后重新出现在活跃列表
        db.restore_item("id-003").unwrap();
        let active_after = db.get_active_items().unwrap();
        assert!(active_after.iter().any(|i| i.id == "id-003"));
        let trashed_after = db.get_trashed_items().unwrap();
        assert!(trashed_after.iter().all(|i| i.id != "id-003"));
    }

    #[test]
    fn test_soft_delete_nonexistent() {
        let db = Database::new_in_memory().unwrap();
        let result = db.soft_delete_item("nonexistent");
        assert!(result.is_err());
    }

    #[test]
    fn test_permanently_delete_item() {
        let db = Database::new_in_memory().unwrap();
        let item = make_item("id-004", "Facebook");
        db.insert_item(&item).unwrap();
        db.soft_delete_item("id-004").unwrap();
        db.permanently_delete_item("id-004").unwrap();

        let result = db.get_item("id-004");
        assert!(result.is_err());
    }

    #[test]
    fn test_empty_trash() {
        let db = Database::new_in_memory().unwrap();
        db.insert_item(&make_item("id-010", "Item A")).unwrap();
        db.insert_item(&make_item("id-011", "Item B")).unwrap();
        db.insert_item(&make_item("id-012", "Item C")).unwrap();

        db.soft_delete_item("id-010").unwrap();
        db.soft_delete_item("id-011").unwrap();

        let deleted_count = db.empty_trash().unwrap();
        assert_eq!(deleted_count, 2);

        // Item C 仍然活跃
        let active = db.get_active_items().unwrap();
        assert_eq!(active.len(), 1);
        assert_eq!(active[0].id, "id-012");

        // 回收站为空
        let trashed = db.get_trashed_items().unwrap();
        assert!(trashed.is_empty());
    }

    #[test]
    fn test_get_all_items_includes_deleted() {
        let db = Database::new_in_memory().unwrap();
        db.insert_item(&make_item("id-020", "Item1")).unwrap();
        db.insert_item(&make_item("id-021", "Item2")).unwrap();
        db.soft_delete_item("id-021").unwrap();

        let all = db.get_all_items().unwrap();
        assert_eq!(all.len(), 2);

        let active = db.get_active_items().unwrap();
        assert_eq!(active.len(), 1);
    }

    #[test]
    fn test_search_items_by_title() {
        let db = Database::new_in_memory().unwrap();
        db.insert_item(&make_item("id-030", "GitHub")).unwrap();
        db.insert_item(&make_item("id-031", "GitLab")).unwrap();
        db.insert_item(&make_item("id-032", "Google")).unwrap();

        let results = db.search_items("git").unwrap();
        assert_eq!(results.len(), 2);
        assert!(results.iter().any(|i| i.title == "GitHub"));
        assert!(results.iter().any(|i| i.title == "GitLab"));
    }

    #[test]
    fn test_search_items_case_insensitive() {
        let db = Database::new_in_memory().unwrap();
        db.insert_item(&make_item("id-033", "Amazon")).unwrap();

        let results = db.search_items("AMAZON").unwrap();
        assert_eq!(results.len(), 1);
    }

    #[test]
    fn test_search_items_by_username() {
        let db = Database::new_in_memory().unwrap();
        let mut item = make_item("id-040", "MyApp");
        item.username = "john.doe@company.com".to_string();
        db.insert_item(&item).unwrap();

        let results = db.search_items("john").unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "id-040");
    }

    #[test]
    fn test_search_items_by_tags() {
        let db = Database::new_in_memory().unwrap();
        let mut item = make_item("id-050", "BankApp");
        item.tags = vec!["finance".to_string(), "bank".to_string()];
        db.insert_item(&item).unwrap();

        let results = db.search_items("finance").unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, "id-050");
    }

    #[test]
    fn test_search_excludes_trashed() {
        let db = Database::new_in_memory().unwrap();
        db.insert_item(&make_item("id-060", "DeletedApp")).unwrap();
        db.soft_delete_item("id-060").unwrap();

        let results = db.search_items("DeletedApp").unwrap();
        assert!(results.is_empty());
    }

    #[test]
    fn test_insert_get_update_folder() {
        let db = Database::new_in_memory().unwrap();
        let folder = make_folder("folder-001", "Work");
        db.insert_folder(&folder).unwrap();

        let folders = db.get_all_folders().unwrap();
        assert_eq!(folders.len(), 1);
        assert_eq!(folders[0].name, "Work");

        let updated = Folder {
            id: "folder-001".to_string(),
            name: "Work Updated".to_string(),
            icon: "\u{1F4BC}".to_string(),
        };
        db.update_folder(&updated).unwrap();

        let folders_after = db.get_all_folders().unwrap();
        assert_eq!(folders_after[0].name, "Work Updated");
    }

    #[test]
    fn test_delete_folder_cascades_to_items() {
        let db = Database::new_in_memory().unwrap();
        let folder = make_folder("folder-002", "Personal");
        db.insert_folder(&folder).unwrap();

        let mut item = make_item("id-070", "PersonalVault");
        item.folder_id = Some("folder-002".to_string());
        db.insert_item(&item).unwrap();

        // 删除文件夹后，条目的 folder_id 应被置为 NULL
        db.delete_folder("folder-002").unwrap();

        let fetched = db.get_item("id-070").unwrap();
        assert!(fetched.folder_id.is_none());

        let folders = db.get_all_folders().unwrap();
        assert!(folders.is_empty());
    }

    #[test]
    fn test_delete_nonexistent_folder() {
        let db = Database::new_in_memory().unwrap();
        let result = db.delete_folder("nonexistent");
        assert!(result.is_err());
    }

    #[test]
    fn test_upsert_and_get_favicon() {
        let db = Database::new_in_memory().unwrap();
        let entry = FaviconEntry {
            domain: "github.com".to_string(),
            data_url: "data:image/png;base64,abc123".to_string(),
            fetched_at: chrono::Utc::now().to_rfc3339(),
        };
        db.upsert_favicon(&entry).unwrap();

        let fetched = db.get_favicon("github.com").unwrap();
        assert!(fetched.is_some());
        let fetched = fetched.unwrap();
        assert_eq!(fetched.domain, "github.com");
        assert_eq!(fetched.data_url, "data:image/png;base64,abc123");
    }

    #[test]
    fn test_upsert_favicon_updates_existing() {
        let db = Database::new_in_memory().unwrap();
        let entry1 = FaviconEntry {
            domain: "example.com".to_string(),
            data_url: "data:image/png;base64,old".to_string(),
            fetched_at: chrono::Utc::now().to_rfc3339(),
        };
        db.upsert_favicon(&entry1).unwrap();

        let entry2 = FaviconEntry {
            domain: "example.com".to_string(),
            data_url: "data:image/png;base64,new".to_string(),
            fetched_at: chrono::Utc::now().to_rfc3339(),
        };
        db.upsert_favicon(&entry2).unwrap();

        let fetched = db.get_favicon("example.com").unwrap().unwrap();
        assert_eq!(fetched.data_url, "data:image/png;base64,new");
    }

    #[test]
    fn test_get_favicon_not_found() {
        let db = Database::new_in_memory().unwrap();
        let result = db.get_favicon("notexist.com").unwrap();
        assert!(result.is_none());
    }

    #[test]
    fn test_get_all_favicons() {
        let db = Database::new_in_memory().unwrap();
        for domain in &["a.com", "b.com", "c.com"] {
            db.upsert_favicon(&FaviconEntry {
                domain: domain.to_string(),
                data_url: "data:image/png;base64,x".to_string(),
                fetched_at: chrono::Utc::now().to_rfc3339(),
            })
            .unwrap();
        }

        let all = db.get_all_favicons().unwrap();
        assert_eq!(all.len(), 3);
    }

    #[test]
    fn test_set_and_get_setting() {
        let db = Database::new_in_memory().unwrap();
        db.set_setting("theme", "dark").unwrap();

        let value = db.get_setting("theme").unwrap();
        assert_eq!(value, Some("dark".to_string()));
    }

    #[test]
    fn test_set_setting_upsert() {
        let db = Database::new_in_memory().unwrap();
        db.set_setting("language", "en").unwrap();
        db.set_setting("language", "zh").unwrap();

        let value = db.get_setting("language").unwrap();
        assert_eq!(value, Some("zh".to_string()));
    }

    #[test]
    fn test_get_setting_not_found() {
        let db = Database::new_in_memory().unwrap();
        let value = db.get_setting("nonexistent_key").unwrap();
        assert!(value.is_none());
    }

    #[test]
    fn test_item_category_persistence() {
        let db = Database::new_in_memory().unwrap();
        let mut item = make_item("id-080", "My Card");
        item.category = Category::Cards;
        db.insert_item(&item).unwrap();

        let fetched = db.get_item("id-080").unwrap();
        assert!(matches!(fetched.category, Category::Cards));
    }

    #[test]
    fn test_item_boolean_fields() {
        let db = Database::new_in_memory().unwrap();
        let mut item = make_item("id-090", "PinnedItem");
        item.is_favorite = true;
        item.is_pinned = true;
        db.insert_item(&item).unwrap();

        let fetched = db.get_item("id-090").unwrap();
        assert!(fetched.is_favorite);
        assert!(fetched.is_pinned);
    }

    #[test]
    fn test_item_json_fields_roundtrip() {
        let db = Database::new_in_memory().unwrap();
        let mut item = make_item("id-100", "SecureVault");
        item.custom_fields = vec![CustomField {
            id: "cf-001".to_string(),
            label: "PIN".to_string(),
            value: "1234".to_string(),
            field_type: "text".to_string(),
        }];
        item.password_history = vec![PasswordHistoryEntry {
            password: "oldpass".to_string(),
            changed_at: chrono::Utc::now().to_rfc3339(),
        }];
        item.security_questions = vec![SecurityQuestion {
            question: "What is your pet's name?".to_string(),
            answer: "Fluffy".to_string(),
        }];
        db.insert_item(&item).unwrap();

        let fetched = db.get_item("id-100").unwrap();
        assert_eq!(fetched.custom_fields.len(), 1);
        assert_eq!(fetched.custom_fields[0].label, "PIN");
        assert_eq!(fetched.password_history.len(), 1);
        assert_eq!(fetched.password_history[0].password, "oldpass");
        assert_eq!(fetched.security_questions.len(), 1);
        assert_eq!(fetched.security_questions[0].answer, "Fluffy");
    }

    #[test]
    fn test_item_with_folder_id() {
        let db = Database::new_in_memory().unwrap();
        let folder = make_folder("f-001", "Vault");
        db.insert_folder(&folder).unwrap();

        let mut item = make_item("id-110", "VaultItem");
        item.folder_id = Some("f-001".to_string());
        db.insert_item(&item).unwrap();

        let fetched = db.get_item("id-110").unwrap();
        assert_eq!(fetched.folder_id, Some("f-001".to_string()));
    }

    // -------------------------------------------------------------------------
    // v1 schema tests
    // -------------------------------------------------------------------------

    #[test]
    fn test_v1_insert_and_get_item() {
        let db = Database::new_in_memory().unwrap();
        let now = chrono::Utc::now().to_rfc3339();
        let item = ItemRowV1 {
            id: "v1-001".to_string(),
            category: "logins".to_string(),
            is_favorite: false,
            is_pinned: false,
            folder_id: None,
            encrypted_data: "base64_encrypted_blob_here".to_string(),
            created_at: now.clone(),
            updated_at: now,
            deleted_at: None,
            sync_version: 0,
            archived_at: None,
        };
        db.insert_item_v1(&item).unwrap();
        let fetched = db.get_item_v1("v1-001").unwrap();
        assert_eq!(fetched.id, "v1-001");
        assert_eq!(fetched.encrypted_data, "base64_encrypted_blob_here");
    }

    #[test]
    fn test_v1_active_and_trashed() {
        let db = Database::new_in_memory().unwrap();
        let now = chrono::Utc::now().to_rfc3339();
        for i in 1..=3 {
            db.insert_item_v1(&ItemRowV1 {
                id: format!("v1-{:03}", i),
                category: "logins".to_string(),
                is_favorite: false,
                is_pinned: false,
                folder_id: None,
                encrypted_data: "data".to_string(),
                created_at: now.clone(),
                updated_at: now.clone(),
                deleted_at: None,
                sync_version: 0,
                archived_at: None,
            })
            .unwrap();
        }
        db.soft_delete_item_v1("v1-001").unwrap();
        assert_eq!(db.get_active_items_v1().unwrap().len(), 2);
        assert_eq!(db.get_trashed_items_v1().unwrap().len(), 1);
    }

    #[test]
    fn test_v1_update_item() {
        let db = Database::new_in_memory().unwrap();
        let now = chrono::Utc::now().to_rfc3339();
        let item = ItemRowV1 {
            id: "v1-upd".to_string(),
            category: "logins".to_string(),
            is_favorite: false,
            is_pinned: false,
            folder_id: None,
            encrypted_data: "original".to_string(),
            created_at: now.clone(),
            updated_at: now,
            deleted_at: None,
            sync_version: 0,
            archived_at: None,
        };
        db.insert_item_v1(&item).unwrap();
        let mut updated = db.get_item_v1("v1-upd").unwrap();
        updated.encrypted_data = "modified".to_string();
        updated.is_favorite = true;
        db.update_item_v1(&updated).unwrap();
        let fetched = db.get_item_v1("v1-upd").unwrap();
        assert_eq!(fetched.encrypted_data, "modified");
        assert!(fetched.is_favorite);
    }

    #[test]
    fn test_schema_version() {
        let db = Database::new_in_memory().unwrap();
        let version = db.get_schema_version().unwrap();
        assert_eq!(version, 5);
    }

    // -------------------------------------------------------------------------
    // Audit log tests
    // -------------------------------------------------------------------------

    #[test]
    fn test_audit_log_insert_and_get() {
        let db = Database::new_in_memory().unwrap();
        let now = chrono::Utc::now().to_rfc3339();

        db.insert_audit_entry(
            "evt-001",
            "device_paired",
            Some("dev-A"),
            Some("iPhone 16"),
            None,
            Some("paired via QR"),
            &now,
        )
        .unwrap();

        let entries = db.get_audit_log(10, 0).unwrap();
        assert_eq!(entries.len(), 1);
        assert_eq!(entries[0].id, "evt-001");
        assert_eq!(entries[0].event_type, "device_paired");
        assert_eq!(entries[0].device_id.as_deref(), Some("dev-A"));
        assert_eq!(entries[0].device_name.as_deref(), Some("iPhone 16"));
        assert!(entries[0].item_id.is_none());
        assert_eq!(entries[0].details.as_deref(), Some("paired via QR"));
    }

    #[test]
    fn test_audit_log_pagination() {
        let db = Database::new_in_memory().unwrap();
        for i in 0..5 {
            let ts = format!("2026-03-20T10:{:02}:00Z", i);
            db.insert_audit_entry(
                &format!("evt-{}", i),
                "vault_unlocked",
                None,
                None,
                None,
                None,
                &ts,
            )
            .unwrap();
        }

        // Get first 2 (by descending timestamp)
        let page1 = db.get_audit_log(2, 0).unwrap();
        assert_eq!(page1.len(), 2);
        assert_eq!(page1[0].id, "evt-4"); // newest first
        assert_eq!(page1[1].id, "evt-3");

        // Get next 2
        let page2 = db.get_audit_log(2, 2).unwrap();
        assert_eq!(page2.len(), 2);
        assert_eq!(page2[0].id, "evt-2");
    }

    #[test]
    fn test_audit_log_for_device() {
        let db = Database::new_in_memory().unwrap();
        let now = chrono::Utc::now().to_rfc3339();

        db.insert_audit_entry("e1", "vault_unlocked", Some("dev-A"), None, None, None, &now)
            .unwrap();
        db.insert_audit_entry("e2", "item_accessed_remotely", Some("dev-B"), None, Some("item-1"), None, &now)
            .unwrap();
        db.insert_audit_entry("e3", "vault_locked", Some("dev-A"), None, None, None, &now)
            .unwrap();

        let entries_a = db.get_audit_log_for_device("dev-A", 10).unwrap();
        assert_eq!(entries_a.len(), 2);

        let entries_b = db.get_audit_log_for_device("dev-B", 10).unwrap();
        assert_eq!(entries_b.len(), 1);
        assert_eq!(entries_b[0].event_type, "item_accessed_remotely");
    }

    #[test]
    fn test_audit_log_clear_before() {
        let db = Database::new_in_memory().unwrap();

        db.insert_audit_entry("e1", "vault_unlocked", None, None, None, None, "2026-01-01T00:00:00Z")
            .unwrap();
        db.insert_audit_entry("e2", "vault_locked", None, None, None, None, "2026-02-01T00:00:00Z")
            .unwrap();
        db.insert_audit_entry("e3", "device_paired", None, None, None, None, "2026-03-01T00:00:00Z")
            .unwrap();

        // Delete entries before Feb 15
        let deleted = db.clear_audit_log_before("2026-02-15T00:00:00Z").unwrap();
        assert_eq!(deleted, 2);

        let remaining = db.get_audit_log(10, 0).unwrap();
        assert_eq!(remaining.len(), 1);
        assert_eq!(remaining[0].id, "e3");
    }

    #[test]
    fn test_audit_log_with_null_fields() {
        let db = Database::new_in_memory().unwrap();
        let now = chrono::Utc::now().to_rfc3339();

        db.insert_audit_entry("e1", "vault_unlocked", None, None, None, None, &now)
            .unwrap();

        let entries = db.get_audit_log(10, 0).unwrap();
        assert_eq!(entries.len(), 1);
        assert!(entries[0].device_id.is_none());
        assert!(entries[0].device_name.is_none());
        assert!(entries[0].item_id.is_none());
        assert!(entries[0].details.is_none());
    }

    #[test]
    fn test_migration_v4_to_v5_idempotent() {
        // Database::new_in_memory already runs all migrations.
        // Calling migrate_v4_to_v5 again should not fail thanks to IF NOT EXISTS.
        let db = Database::new_in_memory().unwrap();
        assert_eq!(db.get_schema_version().unwrap(), 5);
        // Run migration again — should be idempotent
        db.migrate_v4_to_v5().unwrap();
        assert_eq!(db.get_schema_version().unwrap(), 5);
    }
}
