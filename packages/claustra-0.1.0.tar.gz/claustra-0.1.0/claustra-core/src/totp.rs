use hmac::{Hmac, Mac};
use sha1::Sha1;
use std::time::{SystemTime, UNIX_EPOCH};

use crate::error::{Result, ClaustraError};

type HmacSha1 = Hmac<Sha1>;

/// Decode a base32 string (RFC 4648 alphabet) into bytes.
/// Ignores spaces and '=' padding characters.
fn base32_decode(input: &str) -> Option<Vec<u8>> {
    const ALPHABET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    let normalized: String = input
        .chars()
        .filter(|c| *c != ' ' && *c != '=')
        .map(|c| c.to_ascii_uppercase())
        .collect();

    let mut bits: u64 = 0;
    let mut bit_count: u32 = 0;
    let mut output: Vec<u8> = Vec::new();

    for ch in normalized.bytes() {
        let val = ALPHABET.iter().position(|&b| b == ch)? as u64;
        bits = (bits << 5) | val;
        bit_count += 5;
        if bit_count >= 8 {
            bit_count -= 8;
            output.push(((bits >> bit_count) & 0xFF) as u8);
        }
    }

    Some(output)
}

/// Generate a TOTP code using the given base32-encoded secret.
///
/// Returns `(code, remaining_seconds)` where `code` is a zero-padded 6-digit
/// string and `remaining_seconds` is how many seconds until the code changes.
pub fn generate_totp(secret: &str) -> Result<(String, u32)> {
    let key = base32_decode(secret)
        .ok_or_else(|| ClaustraError::InvalidInput("Invalid base32 TOTP secret".into()))?;

    let unix_ts = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| ClaustraError::InvalidInput(e.to_string()))?
        .as_secs();

    let time_step = unix_ts / 30;
    let remaining = 30 - (unix_ts % 30) as u32;

    let time_bytes = time_step.to_be_bytes();

    let mut mac = HmacSha1::new_from_slice(&key)
        .map_err(|e| ClaustraError::Encryption(e.to_string()))?;
    mac.update(&time_bytes);
    let hmac_result = mac.finalize().into_bytes();

    let offset = (hmac_result[19] & 0x0F) as usize;
    let code = (((hmac_result[offset] as u32) & 0x7F) << 24)
        | (((hmac_result[offset + 1] as u32) & 0xFF) << 16)
        | (((hmac_result[offset + 2] as u32) & 0xFF) << 8)
        | ((hmac_result[offset + 3] as u32) & 0xFF);

    let otp = code % 1_000_000;
    Ok((format!("{:06}", otp), remaining))
}

/// Extract the TOTP secret from an `otpauth://` URI.
///
/// Returns `None` if the URI does not contain a `secret` parameter.
pub fn parse_totp_uri(uri: &str) -> Option<String> {
    let lower = uri.to_ascii_lowercase();
    let key = "secret=";
    let start = lower.find(key)? + key.len();
    let rest = &uri[start..];
    let end = rest.find('&').unwrap_or(rest.len());
    let secret = &rest[..end];
    if secret.is_empty() {
        None
    } else {
        Some(secret.to_ascii_uppercase())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// RFC 6238 test vector: secret bytes = "12345678901234567890"
    /// base32: GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ
    /// At time_step = 1, expected OTP = 287082
    #[test]
    fn test_generate_totp_known_vector() {
        let secret_b32 = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ";
        let key = base32_decode(secret_b32).expect("decode failed");
        assert_eq!(key, b"12345678901234567890");

        let time_step: u64 = 1;
        let time_bytes = time_step.to_be_bytes();

        let mut mac = HmacSha1::new_from_slice(&key).unwrap();
        mac.update(&time_bytes);
        let hmac_result = mac.finalize().into_bytes();

        let offset = (hmac_result[19] & 0x0F) as usize;
        let code = (((hmac_result[offset] as u32) & 0x7F) << 24)
            | (((hmac_result[offset + 1] as u32) & 0xFF) << 16)
            | (((hmac_result[offset + 2] as u32) & 0xFF) << 8)
            | ((hmac_result[offset + 3] as u32) & 0xFF);
        let otp = code % 1_000_000;

        assert_eq!(format!("{:06}", otp), "287082");
    }

    #[test]
    fn test_generate_totp_returns_six_digits() {
        let (code, remaining) = generate_totp("JBSWY3DPEHPK3PXP").expect("totp failed");
        assert_eq!(code.len(), 6);
        assert!(code.chars().all(|c| c.is_ascii_digit()));
        assert!(remaining > 0 && remaining <= 30);
    }

    #[test]
    fn test_parse_totp_uri_standard() {
        let uri =
            "otpauth://totp/Example:alice@google.com?secret=JBSWY3DPEHPK3PXP&issuer=Example";
        let secret = parse_totp_uri(uri);
        assert_eq!(secret, Some("JBSWY3DPEHPK3PXP".to_string()));
    }

    #[test]
    fn test_parse_totp_uri_case_insensitive_param() {
        let uri = "otpauth://totp/test?Secret=ABCDE234&issuer=Test";
        let secret = parse_totp_uri(uri);
        assert_eq!(secret, Some("ABCDE234".to_string()));
    }

    #[test]
    fn test_parse_totp_uri_no_secret() {
        let uri = "otpauth://totp/test?issuer=Test";
        assert_eq!(parse_totp_uri(uri), None);
    }

    #[test]
    fn test_base32_decode_ignores_spaces_and_padding() {
        let with_spaces = "JBSW Y3DP";
        let plain = "JBSWY3DP";
        assert_eq!(base32_decode(with_spaces), base32_decode(plain));

        let with_padding = "JBSWY3DP====";
        assert_eq!(base32_decode(with_padding), base32_decode(plain));
    }
}
