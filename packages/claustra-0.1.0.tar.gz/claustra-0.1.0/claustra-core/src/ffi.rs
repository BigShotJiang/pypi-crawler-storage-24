use std::sync::Mutex;
use base64::{engine::general_purpose::STANDARD, Engine};
use crate::crypto;
use crate::error::ClaustraError;
use crate::models::{Folder, PasswordGeneratorOptions, PasswordItem};
use crate::remote_auth::{DeviceKeyPair, DeviceType, NoiseChannel, PairingData};
use crate::store::PasswordStore;

// ---------------------------------------------------------------------------
// FFI error type (UniFFI-compatible)
// ---------------------------------------------------------------------------

#[derive(Debug, thiserror::Error, uniffi::Error)]
pub enum CoreError {
    #[error("Database error: {message}")]
    Database { message: String },
    #[error("Encryption error: {message}")]
    Encryption { message: String },
    #[error("Invalid master password")]
    InvalidMasterPassword,
    #[error("Serialization error: {message}")]
    Serialization { message: String },
    #[error("IO error: {message}")]
    Io { message: String },
    #[error("Invalid input: {message}")]
    InvalidInput { message: String },
    #[error("Not found: {message}")]
    NotFound { message: String },
}

impl From<ClaustraError> for CoreError {
    fn from(e: ClaustraError) -> Self {
        match e {
            ClaustraError::Database(e) => CoreError::Database { message: e.to_string() },
            ClaustraError::Encryption(msg) => CoreError::Encryption { message: msg },
            ClaustraError::InvalidMasterPassword => CoreError::InvalidMasterPassword,
            ClaustraError::Serialization(e) => CoreError::Serialization { message: e.to_string() },
            ClaustraError::Io(e) => CoreError::Io { message: e.to_string() },
            ClaustraError::Csv(e) => CoreError::Serialization { message: e.to_string() },
            ClaustraError::InvalidInput(msg) => CoreError::InvalidInput { message: msg },
            ClaustraError::NotFound(msg) => CoreError::NotFound { message: msg },
        }
    }
}

// ---------------------------------------------------------------------------
// TOTP result (simple UniFFI record)
// ---------------------------------------------------------------------------

#[derive(uniffi::Record)]
pub struct TotpResult {
    pub code: String,
    pub remaining_seconds: u32,
}

#[derive(uniffi::Record)]
pub struct FfiDeviceKeyPair {
    pub public_key: Vec<u8>,
    pub private_key: Vec<u8>,
}

// ---------------------------------------------------------------------------
// Main FFI object
// ---------------------------------------------------------------------------

#[derive(uniffi::Object)]
pub struct ClaustraCore {
    inner: Mutex<PasswordStore>,
}

#[uniffi::export]
impl ClaustraCore {
    /// Open (or create) a file-backed store.
    #[uniffi::constructor]
    pub fn new(db_path: String) -> Result<Self, CoreError> {
        let store = PasswordStore::new(&db_path)?;
        Ok(Self {
            inner: Mutex::new(store),
        })
    }

    // --- V1 Authentication ---

    /// Set up master password with the v1 layered key hierarchy.
    pub fn setup(&self, password: String, device_secret: Vec<u8>) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .setup_master_password_v1(&password, &device_secret)
            .map_err(CoreError::from)
    }

    /// Unlock with master password + device secret.
    /// Returns true if successful.
    pub fn unlock(&self, password: String, device_secret: Vec<u8>) -> Result<bool, CoreError> {
        self.inner
            .lock()
            .unwrap()
            .unlock_v1(&password, &device_secret)
            .map_err(CoreError::from)
    }

    /// Unlock directly with a vault key (for biometric auth).
    pub fn unlock_with_vault_key(&self, vault_key: Vec<u8>) -> Result<(), CoreError> {
        if vault_key.len() != 32 {
            return Err(CoreError::InvalidInput {
                message: "vault_key must be exactly 32 bytes".to_string(),
            });
        }
        let mut key = [0u8; 32];
        key.copy_from_slice(&vault_key);
        self.inner.lock().unwrap().unlock_with_vault_key(key);
        Ok(())
    }

    /// Get the current vault key (for storing in Keychain).
    /// Returns None if the store is locked.
    pub fn get_vault_key(&self) -> Option<Vec<u8>> {
        self.inner
            .lock()
            .unwrap()
            .get_vault_key()
            .map(|k| k.to_vec())
    }

    /// Lock the store, clearing the vault key from memory.
    pub fn lock(&self) {
        self.inner.lock().unwrap().lock_v1();
    }

    /// Check if the store is currently unlocked.
    pub fn is_unlocked(&self) -> bool {
        self.inner.lock().unwrap().is_unlocked_v1()
    }

    /// Check if the master password has been set up.
    pub fn is_setup(&self) -> Result<bool, CoreError> {
        self.inner
            .lock()
            .unwrap()
            .is_setup_v1()
            .map_err(CoreError::from)
    }

    /// Change the master password.
    pub fn change_password(
        &self,
        old_password: String,
        new_password: String,
        device_secret: Vec<u8>,
    ) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .change_password_v1(&old_password, &new_password, &device_secret)
            .map_err(CoreError::from)
    }

    // --- Items (JSON-based) ---

    /// Create a new item. Pass the PasswordItem as a JSON string.
    pub fn create_item(&self, item_json: String) -> Result<(), CoreError> {
        let item: PasswordItem = serde_json::from_str(&item_json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })?;
        self.inner
            .lock()
            .unwrap()
            .create_item_v1(&item)
            .map_err(CoreError::from)
    }

    /// Get a single item by ID. Returns a JSON string.
    pub fn get_item(&self, id: String) -> Result<String, CoreError> {
        let item = self
            .inner
            .lock()
            .unwrap()
            .get_item_v1(&id)
            .map_err(CoreError::from)?;
        serde_json::to_string(&item)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Get all active (non-deleted) items. Returns a JSON array string.
    pub fn get_all_items(&self) -> Result<String, CoreError> {
        let items = self
            .inner
            .lock()
            .unwrap()
            .get_all_items_v1()
            .map_err(CoreError::from)?;
        serde_json::to_string(&items)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Update an existing item. Pass the PasswordItem as a JSON string.
    pub fn update_item(&self, item_json: String) -> Result<(), CoreError> {
        let item: PasswordItem = serde_json::from_str(&item_json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })?;
        self.inner
            .lock()
            .unwrap()
            .update_item_v1(&item)
            .map_err(CoreError::from)
    }

    /// Soft-delete an item (move to trash).
    pub fn delete_item(&self, id: String) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .delete_item_v1(&id)
            .map_err(CoreError::from)
    }

    /// Restore a trashed item.
    pub fn restore_item(&self, id: String) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .restore_item_v1(&id)
            .map_err(CoreError::from)
    }

    /// Permanently delete an item.
    pub fn permanently_delete_item(&self, id: String) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .permanently_delete_item_v1(&id)
            .map_err(CoreError::from)
    }

    /// Empty the trash. Returns the number of items deleted.
    pub fn empty_trash(&self) -> Result<u64, CoreError> {
        self.inner
            .lock()
            .unwrap()
            .empty_trash_v1()
            .map_err(CoreError::from)
    }

    /// Count all active (non-deleted) items. Works even when the vault is locked.
    pub fn get_active_item_count(&self) -> Result<u64, CoreError> {
        self.inner
            .lock()
            .unwrap()
            .count_active_items()
            .map_err(CoreError::from)
    }

    /// Get all trashed items. Returns a JSON array string.
    pub fn get_trashed_items(&self) -> Result<String, CoreError> {
        let items = self
            .inner
            .lock()
            .unwrap()
            .get_trashed_items_v1()
            .map_err(CoreError::from)?;
        serde_json::to_string(&items)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Archive an item (moves it out of the active list without trashing).
    pub fn archive_item(&self, id: String) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .archive_item_v1(&id)
            .map_err(CoreError::from)
    }

    /// Unarchive an item, returning it to the active list.
    pub fn unarchive_item(&self, id: String) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .unarchive_item_v1(&id)
            .map_err(CoreError::from)
    }

    /// Get all archived items. Returns a JSON array string.
    pub fn get_archived_items(&self) -> Result<String, CoreError> {
        let items = self
            .inner
            .lock()
            .unwrap()
            .get_archived_items_v1()
            .map_err(CoreError::from)?;
        serde_json::to_string(&items)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Search items by query. Returns a JSON array string.
    pub fn search_items(&self, query: String) -> Result<String, CoreError> {
        let items = self
            .inner
            .lock()
            .unwrap()
            .search_items_v1(&query)
            .map_err(CoreError::from)?;
        serde_json::to_string(&items)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    // --- Folders (JSON-based) ---

    /// Create a new folder. Pass the Folder as a JSON string.
    pub fn create_folder(&self, folder_json: String) -> Result<(), CoreError> {
        let folder: Folder = serde_json::from_str(&folder_json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })?;
        self.inner
            .lock()
            .unwrap()
            .create_folder(&folder)
            .map_err(CoreError::from)
    }

    /// Get all folders. Returns a JSON array string.
    pub fn get_all_folders(&self) -> Result<String, CoreError> {
        let folders = self
            .inner
            .lock()
            .unwrap()
            .get_all_folders()
            .map_err(CoreError::from)?;
        serde_json::to_string(&folders)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Update a folder. Pass the Folder as a JSON string.
    pub fn update_folder(&self, folder_json: String) -> Result<(), CoreError> {
        let folder: Folder = serde_json::from_str(&folder_json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })?;
        self.inner
            .lock()
            .unwrap()
            .update_folder(&folder)
            .map_err(CoreError::from)
    }

    /// Delete a folder by ID.
    pub fn delete_folder(&self, id: String) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .delete_folder(&id)
            .map_err(CoreError::from)
    }

    // --- Utilities ---

    /// Generate a random password. Pass PasswordGeneratorOptions as JSON.
    /// Returns the generated password string.
    pub fn generate_password(&self, options_json: String) -> Result<String, CoreError> {
        let opts: PasswordGeneratorOptions = serde_json::from_str(&options_json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })?;
        Ok(self.inner.lock().unwrap().generate_password(&opts))
    }

    /// Calculate password strength. Returns JSON with score and label.
    pub fn calculate_strength(&self, password: String) -> Result<String, CoreError> {
        let strength = self.inner.lock().unwrap().calculate_strength(&password);
        serde_json::to_string(&strength)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Generate a numeric-only PIN of the specified length (pass 0 for the default of 6).
    pub fn generate_pin(&self, length: u32) -> String {
        self.inner.lock().unwrap().generate_pin(length)
    }

    /// Generate a memorable passphrase (e.g. "correct-horse-battery-staple").
    ///
    /// `word_count`: number of words (pass 0 for the default of 4).
    /// `separator`: string placed between words (e.g. "-").
    /// `capitalize`: if true, capitalise the first letter of every word.
    pub fn generate_memorable_password(
        &self,
        word_count: u32,
        separator: String,
        capitalize: bool,
    ) -> String {
        self.inner
            .lock()
            .unwrap()
            .generate_memorable_password(word_count, &separator, capitalize)
    }

    /// Generate a TOTP code.
    pub fn generate_totp(&self, secret: String) -> Result<TotpResult, CoreError> {
        let (code, remaining) = self
            .inner
            .lock()
            .unwrap()
            .generate_totp(&secret)
            .map_err(CoreError::from)?;
        Ok(TotpResult {
            code,
            remaining_seconds: remaining,
        })
    }

    // --- Import / Export ---

    /// Export all active items as JSON.
    pub fn export_json(&self) -> Result<String, CoreError> {
        let items = self
            .inner
            .lock()
            .unwrap()
            .get_all_items_v1()
            .map_err(CoreError::from)?;
        serde_json::to_string_pretty(&items)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Export all active items as CSV.
    pub fn export_csv(&self) -> Result<String, CoreError> {
        self.inner
            .lock()
            .unwrap()
            .export_csv()
            .map_err(CoreError::from)
    }

    /// Import items from JSON string. Returns number of items imported.
    pub fn import_json(&self, json_str: String) -> Result<u64, CoreError> {
        let items: Vec<PasswordItem> = serde_json::from_str(&json_str)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })?;
        let count = items.len() as u64;
        let store = self.inner.lock().unwrap();
        for item in &items {
            store.create_item_v1(item).map_err(CoreError::from)?;
        }
        Ok(count)
    }

    /// Import items from CSV string. Returns number of items imported.
    pub fn import_csv(&self, csv_str: String) -> Result<u64, CoreError> {
        let count = self
            .inner
            .lock()
            .unwrap()
            .import_csv(&csv_str)
            .map_err(CoreError::from)?;
        Ok(count as u64)
    }

    /// Import items from a 1Password .1pux archive. Returns number imported.
    pub fn import_1pux(&self, data: Vec<u8>) -> Result<u64, CoreError> {
        let count = self
            .inner
            .lock()
            .unwrap()
            .import_1pux(&data)
            .map_err(CoreError::from)?;
        Ok(count as u64)
    }

    /// Import items from a Bitwarden unencrypted JSON export. Returns number imported.
    pub fn import_bitwarden(&self, json_str: String) -> Result<u64, CoreError> {
        let count = self
            .inner
            .lock()
            .unwrap()
            .import_bitwarden(&json_str)
            .map_err(CoreError::from)?;
        Ok(count as u64)
    }

    /// Import items from a LastPass CSV export. Returns number imported.
    pub fn import_lastpass(&self, csv_str: String) -> Result<u64, CoreError> {
        let count = self
            .inner
            .lock()
            .unwrap()
            .import_lastpass(&csv_str)
            .map_err(CoreError::from)?;
        Ok(count as u64)
    }

    /// Import items from a KeePass KDBX database (raw bytes). Returns number imported.
    pub fn import_keepass(&self, data: Vec<u8>, password: String) -> Result<u64, CoreError> {
        let count = self
            .inner
            .lock()
            .unwrap()
            .import_keepass(&data, &password)
            .map_err(CoreError::from)?;
        Ok(count as u64)
    }

    // --- Crypto utilities (exposed for Swift-side use) ---

    /// Generate cryptographically random bytes.
    pub fn generate_random_bytes(&self, len: u32) -> Vec<u8> {
        crypto::generate_random_bytes(len as usize)
    }

    // --- Sync key hierarchy ---

    /// Derive the Sync KEK from master password and sync salt.
    pub fn derive_sync_kek(&self, master_password: String, sync_salt: Vec<u8>) -> Result<Vec<u8>, CoreError> {
        crypto::derive_sync_kek(&master_password, &sync_salt).map_err(CoreError::from)
    }

    /// Wrap vault key with the sync KEK for upload to CloudKit.
    pub fn wrap_vault_key_for_sync(&self, vault_key: Vec<u8>, sync_kek: Vec<u8>) -> Result<Vec<u8>, CoreError> {
        crypto::wrap_vault_key_for_sync(&vault_key, &sync_kek).map_err(CoreError::from)
    }

    /// Unwrap vault key retrieved from CloudKit using the sync KEK.
    pub fn unwrap_vault_key_from_sync(&self, sync_wrapped_vault_key: Vec<u8>, sync_kek: Vec<u8>) -> Result<Vec<u8>, CoreError> {
        crypto::unwrap_vault_key_from_sync(&sync_wrapped_vault_key, &sync_kek).map_err(CoreError::from)
    }

    /// Generate a random 32-byte sync salt.
    pub fn generate_sync_salt(&self) -> Vec<u8> {
        crypto::generate_sync_salt()
    }

    // --- Item sharing ---

    /// Export a single item as an encrypted sharing blob.
    ///
    /// The vault must be unlocked. Returns the raw encrypted bytes that can be
    /// passed to `import_shared_item` on any device.
    pub fn share_item(&self, id: String, passphrase: String) -> Result<Vec<u8>, CoreError> {
        self.inner
            .lock()
            .unwrap()
            .share_item_v1(&id, &passphrase)
            .map_err(CoreError::from)
    }

    /// Import a single item from an encrypted sharing blob.
    ///
    /// Decrypts `data` with the given passphrase, assigns a new UUID and
    /// timestamps, and creates the item in the store.  Returns the new item ID.
    pub fn import_shared_item(
        &self,
        data: Vec<u8>,
        passphrase: String,
    ) -> Result<String, CoreError> {
        self.inner
            .lock()
            .unwrap()
            .import_shared_item_v1(&data, &passphrase)
            .map_err(CoreError::from)
    }

    // --- Security analysis ---

    /// Run security analysis on all items and return a JSON-encoded SecurityReport.
    pub fn analyze_security(&self) -> Result<String, CoreError> {
        let items = self
            .inner
            .lock()
            .unwrap()
            .get_all_items_v1()
            .map_err(CoreError::from)?;
        let report = crate::security_analysis::analyze_security(&items);
        serde_json::to_string(&report)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    // --- Attachments ---

    /// Encrypt and store a file attachment on the given item.
    /// Returns the new attachment id as a string.
    pub fn attach_file(
        &self,
        item_id: String,
        filename: String,
        mime_type: String,
        data: Vec<u8>,
    ) -> Result<String, CoreError> {
        self.inner
            .lock()
            .unwrap()
            .attach_file_v1(&item_id, &filename, &mime_type, &data)
            .map_err(CoreError::from)
    }

    /// Retrieve an attachment. Returns a JSON string containing attachment metadata
    /// plus a `data` field with the decrypted file content as a Base64 string.
    pub fn get_attachment(&self, attachment_id: String) -> Result<String, CoreError> {
        use base64::{engine::general_purpose::STANDARD, Engine};
        let (meta, bytes) = self
            .inner
            .lock()
            .unwrap()
            .get_attachment_v1(&attachment_id)
            .map_err(CoreError::from)?;

        // Build a combined JSON object: all metadata fields + base64-encoded data
        #[derive(serde::Serialize)]
        struct AttachmentWithData {
            id: String,
            item_id: String,
            filename: String,
            mime_type: String,
            size: u64,
            created_at: String,
            data: String,
        }

        let result = AttachmentWithData {
            id: meta.id,
            item_id: meta.item_id,
            filename: meta.filename,
            mime_type: meta.mime_type,
            size: meta.size,
            created_at: meta.created_at,
            data: STANDARD.encode(&bytes),
        };

        serde_json::to_string(&result)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// List all attachments for a given item. Returns a JSON array of attachment
    /// metadata objects (no file data).
    pub fn list_attachments(&self, item_id: String) -> Result<String, CoreError> {
        let attachments = self
            .inner
            .lock()
            .unwrap()
            .list_attachments_v1(&item_id)
            .map_err(CoreError::from)?;
        serde_json::to_string(&attachments)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Delete a single attachment by id.
    pub fn delete_attachment(&self, attachment_id: String) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .delete_attachment_v1(&attachment_id)
            .map_err(CoreError::from)
    }

    // --- Remote auth (pure crypto, no vault lock needed) ---

    /// Generate a new X25519 keypair for device identity.
    pub fn generate_device_keypair(&self) -> FfiDeviceKeyPair {
        let kp = DeviceKeyPair::generate();
        FfiDeviceKeyPair {
            public_key: kp.public_bytes().to_vec(),
            private_key: kp.secret_bytes().to_vec(),
        }
    }

    /// Encode device info into compact bytes for QR code display.
    /// `device_type`: "ios" | "macos" | "watchos" | "cli" | "browser" | "python"
    pub fn encode_pairing_data(
        &self,
        device_name: String,
        device_type: String,
        public_key: Vec<u8>,
    ) -> Result<Vec<u8>, CoreError> {
        let dt = parse_device_type(&device_type)?;
        let pk = to_key_array(&public_key, "public_key")?;
        let pd = PairingData {
            device_name,
            device_type: dt,
            public_key: pk,
        };
        Ok(pd.to_bytes())
    }

    /// Decode pairing data from QR code bytes.
    /// Returns JSON: `{"device_name": "...", "device_type": "...", "public_key": "<base64>"}`
    pub fn decode_pairing_data(&self, data: Vec<u8>) -> Result<String, CoreError> {
        let pd = PairingData::from_bytes(&data).map_err(CoreError::from)?;
        let json = serde_json::json!({
            "device_name": pd.device_name,
            "device_type": device_type_to_str(pd.device_type),
            "public_key": STANDARD.encode(pd.public_key),
        });
        serde_json::to_string(&json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Create an authorization request (requester / initiator side).
    ///
    /// Produces the Noise KK handshake msg1 and encrypts metadata using a
    /// stateless X25519 ECDH + AES-256-GCM scheme (since the Noise transport
    /// isn't ready until both sides complete the handshake).
    ///
    /// Returns JSON:
    /// ```json
    /// {
    ///   "encrypted_metadata": "<base64>",
    ///   "handshake_msg1": "<base64>"
    /// }
    /// ```
    pub fn create_auth_request(
        &self,
        my_private_key: Vec<u8>,
        peer_public_key: Vec<u8>,
        _request_type: String,
        metadata_json: String,
    ) -> Result<String, CoreError> {
        let my_sk = to_key_array(&my_private_key, "my_private_key")?;
        let peer_pk = to_key_array(&peer_public_key, "peer_public_key")?;

        // Initiator step 1: produce Noise KK msg1
        let (_hs, msg1) =
            NoiseChannel::new_initiator(&my_sk, &peer_pk).map_err(CoreError::from)?;

        // Encrypt metadata with stateless X25519 ECDH + AES-256-GCM
        let shared = compute_x25519_shared_secret(&my_sk, &peer_pk);
        let enc_meta = encrypt_with_shared_secret(&shared, metadata_json.as_bytes())?;

        let json = serde_json::json!({
            "handshake_msg1": STANDARD.encode(&msg1),
            "encrypted_metadata": STANDARD.encode(&enc_meta),
        });
        serde_json::to_string(&json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Decrypt an authorization request (approver / responder side).
    ///
    /// Processes the initiator's handshake_msg1, produces handshake_msg2,
    /// and decrypts the metadata.
    ///
    /// Returns JSON:
    /// ```json
    /// {
    ///   "metadata": "<decrypted metadata JSON>",
    ///   "handshake_msg2": "<base64>"
    /// }
    /// ```
    pub fn decrypt_auth_request(
        &self,
        my_private_key: Vec<u8>,
        peer_public_key: Vec<u8>,
        handshake_msg1: Vec<u8>,
        _handshake_msg2: Vec<u8>,
        encrypted_metadata: Vec<u8>,
    ) -> Result<String, CoreError> {
        let my_sk = to_key_array(&my_private_key, "my_private_key")?;
        let peer_pk = to_key_array(&peer_public_key, "peer_public_key")?;

        // Responder processes msg1, produces msg2
        let (_hs, msg2) =
            NoiseChannel::new_responder(&my_sk, &peer_pk, &handshake_msg1)
                .map_err(CoreError::from)?;

        // Decrypt metadata with stateless X25519 ECDH + AES-256-GCM
        let shared = compute_x25519_shared_secret(&my_sk, &peer_pk);
        let meta_plaintext = decrypt_with_shared_secret(&shared, &encrypted_metadata)?;
        let metadata_str = String::from_utf8(meta_plaintext).map_err(|e| {
            CoreError::InvalidInput {
                message: format!("Invalid UTF-8 metadata: {}", e),
            }
        })?;

        let json = serde_json::json!({
            "metadata": metadata_str,
            "handshake_msg2": STANDARD.encode(&msg2),
        });
        serde_json::to_string(&json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Create an encrypted authorization response (approver / responder side, after Face ID).
    ///
    /// Encrypts the payload using stateless X25519 ECDH + AES-256-GCM.
    ///
    /// Returns JSON: `{"encrypted_payload": "<base64>"}`
    pub fn create_auth_response(
        &self,
        my_private_key: Vec<u8>,
        peer_public_key: Vec<u8>,
        payload_json: String,
    ) -> Result<String, CoreError> {
        let my_sk = to_key_array(&my_private_key, "my_private_key")?;
        let peer_pk = to_key_array(&peer_public_key, "peer_public_key")?;

        let shared = compute_x25519_shared_secret(&my_sk, &peer_pk);
        let encrypted = encrypt_with_shared_secret(&shared, payload_json.as_bytes())?;

        let json = serde_json::json!({
            "encrypted_payload": STANDARD.encode(&encrypted),
        });
        serde_json::to_string(&json)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    // --- Audit log ---

    /// Log an audit event.
    pub fn log_audit_event(
        &self,
        event_type: String,
        device_id: Option<String>,
        device_name: Option<String>,
        item_id: Option<String>,
        details: Option<String>,
    ) -> Result<(), CoreError> {
        self.inner
            .lock()
            .unwrap()
            .log_audit_event(
                &event_type,
                device_id.as_deref(),
                device_name.as_deref(),
                item_id.as_deref(),
                details.as_deref(),
            )
            .map_err(CoreError::from)
    }

    /// Get audit log entries as JSON. Returns a JSON array of AuditEntry objects.
    pub fn get_audit_log(&self, limit: u64, offset: u64) -> Result<String, CoreError> {
        let entries = self
            .inner
            .lock()
            .unwrap()
            .get_audit_log(limit as usize, offset as usize)
            .map_err(CoreError::from)?;
        serde_json::to_string(&entries)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Get audit log entries for a specific device as JSON.
    pub fn get_audit_log_for_device(
        &self,
        device_id: String,
        limit: u64,
    ) -> Result<String, CoreError> {
        let entries = self
            .inner
            .lock()
            .unwrap()
            .get_audit_log_for_device(&device_id, limit as usize)
            .map_err(CoreError::from)?;
        serde_json::to_string(&entries)
            .map_err(|e| CoreError::Serialization { message: e.to_string() })
    }

    /// Delete audit log entries older than the given ISO-8601 timestamp.
    /// Returns the number of entries deleted.
    pub fn clear_audit_log_before(&self, before: String) -> Result<u64, CoreError> {
        let count = self
            .inner
            .lock()
            .unwrap()
            .clear_audit_log_before(&before)
            .map_err(CoreError::from)?;
        Ok(count as u64)
    }

    /// Decrypt an authorization response (requester / initiator side).
    ///
    /// Returns the decrypted payload JSON string.
    pub fn decrypt_auth_response(
        &self,
        my_private_key: Vec<u8>,
        peer_public_key: Vec<u8>,
        encrypted_payload: Vec<u8>,
    ) -> Result<String, CoreError> {
        let my_sk = to_key_array(&my_private_key, "my_private_key")?;
        let peer_pk = to_key_array(&peer_public_key, "peer_public_key")?;

        // DH is commutative: A_secret * B_public == B_secret * A_public
        let shared = compute_x25519_shared_secret(&my_sk, &peer_pk);
        let plaintext = decrypt_with_shared_secret(&shared, &encrypted_payload)?;

        String::from_utf8(plaintext).map_err(|e| CoreError::InvalidInput {
            message: format!("Invalid UTF-8 payload: {}", e),
        })
    }
}

// ---------------------------------------------------------------------------
// Remote auth helpers (private, outside the uniffi::export block)
// ---------------------------------------------------------------------------

fn parse_device_type(s: &str) -> Result<DeviceType, CoreError> {
    match s.to_lowercase().as_str() {
        "ios" => Ok(DeviceType::IOS),
        "macos" => Ok(DeviceType::MacOS),
        "watchos" => Ok(DeviceType::WatchOS),
        "cli" => Ok(DeviceType::CLI),
        "browser" => Ok(DeviceType::Browser),
        "python" => Ok(DeviceType::Python),
        _ => Err(CoreError::InvalidInput {
            message: format!("Unknown device type: {}", s),
        }),
    }
}

fn device_type_to_str(dt: DeviceType) -> &'static str {
    match dt {
        DeviceType::IOS => "ios",
        DeviceType::MacOS => "macos",
        DeviceType::WatchOS => "watchos",
        DeviceType::CLI => "cli",
        DeviceType::Browser => "browser",
        DeviceType::Python => "python",
    }
}

fn to_key_array(bytes: &[u8], name: &str) -> Result<[u8; 32], CoreError> {
    bytes.try_into().map_err(|_| CoreError::InvalidInput {
        message: format!("{} must be exactly 32 bytes, got {}", name, bytes.len()),
    })
}

/// Compute X25519 ECDH shared secret, then derive a 32-byte key via HKDF-SHA256.
fn compute_x25519_shared_secret(my_secret: &[u8; 32], peer_public: &[u8; 32]) -> [u8; 32] {
    use x25519_dalek::{PublicKey, StaticSecret};

    let sk = StaticSecret::from(*my_secret);
    let pk = PublicKey::from(*peer_public);
    let shared = sk.diffie_hellman(&pk);

    // HKDF-SHA256 to derive a proper encryption key
    use hkdf::Hkdf;
    use sha2::Sha256;
    let hk = Hkdf::<Sha256>::new(None, shared.as_bytes());
    let mut okm = [0u8; 32];
    hk.expand(b"claustra-remote-auth-v1", &mut okm)
        .expect("HKDF expand should not fail for 32 bytes");
    okm
}

/// Encrypt plaintext with AES-256-GCM using the given key.
/// Returns nonce (12 bytes) || ciphertext+tag.
fn encrypt_with_shared_secret(key: &[u8; 32], plaintext: &[u8]) -> Result<Vec<u8>, CoreError> {
    use aes_gcm::{aead::Aead, Aes256Gcm, KeyInit, Nonce};
    use rand::RngCore;

    let cipher = Aes256Gcm::new_from_slice(key)
        .map_err(|e| CoreError::Encryption { message: e.to_string() })?;

    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let ciphertext = cipher
        .encrypt(nonce, plaintext)
        .map_err(|e| CoreError::Encryption { message: e.to_string() })?;

    let mut result = Vec::with_capacity(12 + ciphertext.len());
    result.extend_from_slice(&nonce_bytes);
    result.extend_from_slice(&ciphertext);
    Ok(result)
}

/// Decrypt ciphertext produced by `encrypt_with_shared_secret`.
/// Input format: nonce (12 bytes) || ciphertext+tag.
fn decrypt_with_shared_secret(key: &[u8; 32], data: &[u8]) -> Result<Vec<u8>, CoreError> {
    use aes_gcm::{aead::Aead, Aes256Gcm, KeyInit, Nonce};

    if data.len() < 12 {
        return Err(CoreError::Encryption {
            message: "Ciphertext too short (missing nonce)".to_string(),
        });
    }

    let (nonce_bytes, ciphertext) = data.split_at(12);
    let cipher = Aes256Gcm::new_from_slice(key)
        .map_err(|e| CoreError::Encryption { message: e.to_string() })?;
    let nonce = Nonce::from_slice(nonce_bytes);

    cipher
        .decrypt(nonce, ciphertext)
        .map_err(|e| CoreError::Encryption { message: e.to_string() })
}
