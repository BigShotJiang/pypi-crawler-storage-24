use serde::{Deserialize, Serialize};
use snow::{Builder, TransportState};
use x25519_dalek::{PublicKey, StaticSecret};

use crate::error::{ClaustraError, Result};

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const NOISE_PATTERN: &str = "Noise_KK_25519_AESGCM_SHA256";

/// Maximum Noise message size (64 KiB per the spec, minus overhead).
const MAX_MSG_LEN: usize = 65535;

// ---------------------------------------------------------------------------
// Device types & identity
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DeviceType {
    IOS,
    MacOS,
    WatchOS,
    CLI,
    Browser,
    Python,
}

impl DeviceType {
    fn to_byte(self) -> u8 {
        match self {
            DeviceType::IOS => 0,
            DeviceType::MacOS => 1,
            DeviceType::WatchOS => 2,
            DeviceType::CLI => 3,
            DeviceType::Browser => 4,
            DeviceType::Python => 5,
        }
    }

    fn from_byte(b: u8) -> Result<Self> {
        match b {
            0 => Ok(DeviceType::IOS),
            1 => Ok(DeviceType::MacOS),
            2 => Ok(DeviceType::WatchOS),
            3 => Ok(DeviceType::CLI),
            4 => Ok(DeviceType::Browser),
            5 => Ok(DeviceType::Python),
            _ => Err(ClaustraError::InvalidInput(format!(
                "Unknown device type byte: {}",
                b
            ))),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeviceIdentity {
    pub device_id: String,
    pub device_name: String,
    pub device_type: DeviceType,
    pub public_key: [u8; 32],
    pub created_at: String,
    pub last_seen_at: String,
    pub is_trusted: bool,
}

// ---------------------------------------------------------------------------
// Key management
// ---------------------------------------------------------------------------

/// An X25519 keypair for device identity.
pub struct DeviceKeyPair {
    secret: StaticSecret,
    public: PublicKey,
}

impl DeviceKeyPair {
    /// Generate a new random X25519 keypair.
    pub fn generate() -> Self {
        let mut rng = rand::thread_rng();
        let secret = StaticSecret::random_from_rng(&mut rng);
        let public = PublicKey::from(&secret);
        Self { secret, public }
    }

    /// Reconstruct a keypair from a 32-byte secret key.
    pub fn from_secret_bytes(bytes: &[u8; 32]) -> Self {
        let secret = StaticSecret::from(*bytes);
        let public = PublicKey::from(&secret);
        Self { secret, public }
    }

    /// The raw 32-byte secret key (for secure storage).
    pub fn secret_bytes(&self) -> [u8; 32] {
        // StaticSecret does not expose .to_bytes() directly in all versions,
        // but we stored the original bytes. Re-derive via the clone impl.
        self.secret.to_bytes()
    }

    /// The raw 32-byte public key.
    pub fn public_bytes(&self) -> [u8; 32] {
        self.public.to_bytes()
    }
}

// ---------------------------------------------------------------------------
// Noise KK encrypted channel
// ---------------------------------------------------------------------------

/// A bidirectional Noise_KK channel in transport mode.
pub struct NoiseChannel {
    transport: TransportState,
}

/// The two handshake messages produced during a KK handshake.
pub struct HandshakeResult {
    pub channel: NoiseChannel,
    pub msg1: Vec<u8>,
    pub msg2: Vec<u8>,
}

impl NoiseChannel {
    /// Perform a complete KK handshake between initiator and responder,
    /// returning both transport channels.
    ///
    /// In production the two messages would be sent over the network; here
    /// the helper drives both sides locally.
    pub fn establish(
        initiator_secret: &[u8; 32],
        initiator_public: &[u8; 32],
        responder_secret: &[u8; 32],
        responder_public: &[u8; 32],
    ) -> Result<(NoiseChannel, NoiseChannel)> {
        let builder_i = Builder::new(NOISE_PATTERN.parse().map_err(map_snow_err)?)
            .local_private_key(initiator_secret)
            .remote_public_key(responder_public);
        let mut hs_i = builder_i.build_initiator().map_err(map_snow_err)?;

        let builder_r = Builder::new(NOISE_PATTERN.parse().map_err(map_snow_err)?)
            .local_private_key(responder_secret)
            .remote_public_key(initiator_public);
        let mut hs_r = builder_r.build_responder().map_err(map_snow_err)?;

        // -> e, es, ss
        let mut msg1 = vec![0u8; MAX_MSG_LEN];
        let len1 = hs_i.write_message(&[], &mut msg1).map_err(map_snow_err)?;
        msg1.truncate(len1);

        let mut payload1 = vec![0u8; MAX_MSG_LEN];
        hs_r.read_message(&msg1, &mut payload1).map_err(map_snow_err)?;

        // <- e, ee, se
        let mut msg2 = vec![0u8; MAX_MSG_LEN];
        let len2 = hs_r.write_message(&[], &mut msg2).map_err(map_snow_err)?;
        msg2.truncate(len2);

        let mut payload2 = vec![0u8; MAX_MSG_LEN];
        hs_i.read_message(&msg2, &mut payload2).map_err(map_snow_err)?;

        let transport_i = hs_i.into_transport_mode().map_err(map_snow_err)?;
        let transport_r = hs_r.into_transport_mode().map_err(map_snow_err)?;

        Ok((
            NoiseChannel { transport: transport_i },
            NoiseChannel { transport: transport_r },
        ))
    }

    /// Build a one-sided handshake state for the initiator.
    /// Returns the first handshake message.
    pub fn new_initiator(
        local_secret: &[u8; 32],
        remote_public: &[u8; 32],
    ) -> Result<(snow::HandshakeState, Vec<u8>)> {
        let builder = Builder::new(NOISE_PATTERN.parse().map_err(map_snow_err)?)
            .local_private_key(local_secret)
            .remote_public_key(remote_public);
        let mut hs = builder.build_initiator().map_err(map_snow_err)?;

        let mut msg = vec![0u8; MAX_MSG_LEN];
        let len = hs.write_message(&[], &mut msg).map_err(map_snow_err)?;
        msg.truncate(len);

        Ok((hs, msg))
    }

    /// Build a one-sided handshake state for the responder.
    /// Consumes msg1, returns msg2.
    pub fn new_responder(
        local_secret: &[u8; 32],
        remote_public: &[u8; 32],
        msg1: &[u8],
    ) -> Result<(snow::HandshakeState, Vec<u8>)> {
        let builder = Builder::new(NOISE_PATTERN.parse().map_err(map_snow_err)?)
            .local_private_key(local_secret)
            .remote_public_key(remote_public);
        let mut hs = builder.build_responder().map_err(map_snow_err)?;

        let mut payload = vec![0u8; MAX_MSG_LEN];
        hs.read_message(msg1, &mut payload).map_err(map_snow_err)?;

        let mut msg2 = vec![0u8; MAX_MSG_LEN];
        let len = hs.write_message(&[], &mut msg2).map_err(map_snow_err)?;
        msg2.truncate(len);

        Ok((hs, msg2))
    }

    /// Finish the initiator handshake after receiving msg2.
    pub fn finish_initiator(mut hs: snow::HandshakeState, msg2: &[u8]) -> Result<NoiseChannel> {
        let mut payload = vec![0u8; MAX_MSG_LEN];
        hs.read_message(msg2, &mut payload).map_err(map_snow_err)?;
        let transport = hs.into_transport_mode().map_err(map_snow_err)?;
        Ok(NoiseChannel { transport })
    }

    /// Finish the responder handshake (already complete after new_responder).
    pub fn finish_responder(hs: snow::HandshakeState) -> Result<NoiseChannel> {
        let transport = hs.into_transport_mode().map_err(map_snow_err)?;
        Ok(NoiseChannel { transport })
    }

    /// Encrypt a plaintext message.
    pub fn encrypt(&mut self, plaintext: &[u8]) -> Result<Vec<u8>> {
        let mut buf = vec![0u8; plaintext.len() + 16]; // AEAD tag
        let len = self
            .transport
            .write_message(plaintext, &mut buf)
            .map_err(map_snow_err)?;
        buf.truncate(len);
        Ok(buf)
    }

    /// Decrypt a ciphertext message.
    pub fn decrypt(&mut self, ciphertext: &[u8]) -> Result<Vec<u8>> {
        let mut buf = vec![0u8; ciphertext.len()];
        let len = self
            .transport
            .read_message(ciphertext, &mut buf)
            .map_err(map_snow_err)?;
        buf.truncate(len);
        Ok(buf)
    }
}

fn map_snow_err(e: snow::Error) -> ClaustraError {
    ClaustraError::Encryption(format!("Noise protocol error: {}", e))
}

// ---------------------------------------------------------------------------
// Authorization request / response models
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AuthRequestType {
    ReadItem,
    Unlock,
    Export,
    SensitiveOp,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AuthStatus {
    Pending,
    Approved,
    Denied,
    Expired,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuthorizationRequest {
    pub request_id: String,
    pub requester_device_id: String,
    pub target_device_id: Option<String>,
    pub request_type: AuthRequestType,
    pub encrypted_metadata: Vec<u8>,
    pub expires_at: String,
    pub status: AuthStatus,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuthorizationResponse {
    pub response_id: String,
    pub request_id: String,
    pub responder_device_id: String,
    pub encrypted_payload: Vec<u8>,
    pub created_at: String,
}

impl AuthorizationRequest {
    /// Create a new pending authorization request.
    ///
    /// `metadata_plaintext` is encrypted through the provided Noise channel
    /// before being stored.
    pub fn new(
        requester_device_id: &str,
        target_device_id: Option<&str>,
        request_type: AuthRequestType,
        metadata_plaintext: &[u8],
        channel: &mut NoiseChannel,
        ttl_seconds: i64,
    ) -> Result<Self> {
        let now = chrono::Utc::now();
        let expires = now + chrono::Duration::seconds(ttl_seconds);

        let encrypted_metadata = channel.encrypt(metadata_plaintext)?;

        Ok(Self {
            request_id: uuid::Uuid::new_v4().to_string(),
            requester_device_id: requester_device_id.to_string(),
            target_device_id: target_device_id.map(|s| s.to_string()),
            request_type,
            encrypted_metadata,
            expires_at: expires.to_rfc3339(),
            status: AuthStatus::Pending,
            created_at: now.to_rfc3339(),
        })
    }

    /// Decrypt the metadata using the responder's Noise channel.
    pub fn decrypt_metadata(&self, channel: &mut NoiseChannel) -> Result<Vec<u8>> {
        channel.decrypt(&self.encrypted_metadata)
    }
}

impl AuthorizationResponse {
    /// Create an authorization response with an encrypted payload.
    pub fn new(
        request_id: &str,
        responder_device_id: &str,
        payload_plaintext: &[u8],
        channel: &mut NoiseChannel,
    ) -> Result<Self> {
        let encrypted_payload = channel.encrypt(payload_plaintext)?;

        Ok(Self {
            response_id: uuid::Uuid::new_v4().to_string(),
            request_id: request_id.to_string(),
            responder_device_id: responder_device_id.to_string(),
            encrypted_payload,
            created_at: chrono::Utc::now().to_rfc3339(),
        })
    }

    /// Decrypt the payload using the initiator's Noise channel.
    pub fn decrypt_payload(&self, channel: &mut NoiseChannel) -> Result<Vec<u8>> {
        channel.decrypt(&self.encrypted_payload)
    }
}

// ---------------------------------------------------------------------------
// QR pairing data
// ---------------------------------------------------------------------------

/// Compact pairing data for QR code exchange.
///
/// Binary format (compact):
///   - 1 byte:  device_type
///   - 32 bytes: public_key
///   - 1 byte:  device_name length (max 255)
///   - N bytes: device_name (UTF-8)
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PairingData {
    pub device_name: String,
    pub device_type: DeviceType,
    pub public_key: [u8; 32],
}

impl PairingData {
    /// Serialize to a compact binary format suitable for QR encoding.
    pub fn to_bytes(&self) -> Vec<u8> {
        let name_bytes = self.device_name.as_bytes();
        let name_len = name_bytes.len().min(255) as u8;

        let mut buf = Vec::with_capacity(1 + 32 + 1 + name_len as usize);
        buf.push(self.device_type.to_byte());
        buf.extend_from_slice(&self.public_key);
        buf.push(name_len);
        buf.extend_from_slice(&name_bytes[..name_len as usize]);
        buf
    }

    /// Deserialize from the compact binary format.
    pub fn from_bytes(data: &[u8]) -> Result<Self> {
        if data.len() < 1 + 32 + 1 {
            return Err(ClaustraError::InvalidInput(
                "Pairing data too short".to_string(),
            ));
        }

        let device_type = DeviceType::from_byte(data[0])?;

        let mut public_key = [0u8; 32];
        public_key.copy_from_slice(&data[1..33]);

        let name_len = data[33] as usize;
        if data.len() < 34 + name_len {
            return Err(ClaustraError::InvalidInput(
                "Pairing data truncated".to_string(),
            ));
        }

        let device_name = String::from_utf8(data[34..34 + name_len].to_vec())
            .map_err(|e| ClaustraError::InvalidInput(format!("Invalid device name: {}", e)))?;

        Ok(Self {
            device_name,
            device_type,
            public_key,
        })
    }
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_keypair_generation_and_roundtrip() {
        let kp = DeviceKeyPair::generate();
        let secret = kp.secret_bytes();
        let public = kp.public_bytes();

        // Reconstruct from secret bytes
        let kp2 = DeviceKeyPair::from_secret_bytes(&secret);
        assert_eq!(kp2.public_bytes(), public);
        assert_eq!(kp2.secret_bytes(), secret);
    }

    #[test]
    fn test_keypair_different_each_time() {
        let kp1 = DeviceKeyPair::generate();
        let kp2 = DeviceKeyPair::generate();
        assert_ne!(kp1.public_bytes(), kp2.public_bytes());
    }

    #[test]
    fn test_noise_kk_handshake_and_transport() {
        let alice = DeviceKeyPair::generate();
        let bob = DeviceKeyPair::generate();

        let (mut ch_a, mut ch_b) = NoiseChannel::establish(
            &alice.secret_bytes(),
            &alice.public_bytes(),
            &bob.secret_bytes(),
            &bob.public_bytes(),
        )
        .expect("handshake failed");

        // Alice -> Bob
        let plaintext = b"Hello from Alice";
        let ct = ch_a.encrypt(plaintext).unwrap();
        let pt = ch_b.decrypt(&ct).unwrap();
        assert_eq!(pt, plaintext);

        // Bob -> Alice
        let plaintext2 = b"Hello from Bob";
        let ct2 = ch_b.encrypt(plaintext2).unwrap();
        let pt2 = ch_a.decrypt(&ct2).unwrap();
        assert_eq!(pt2, plaintext2);
    }

    #[test]
    fn test_noise_kk_stepwise_handshake() {
        let alice = DeviceKeyPair::generate();
        let bob = DeviceKeyPair::generate();

        // Step 1: Initiator creates msg1
        let (hs_i, msg1) =
            NoiseChannel::new_initiator(&alice.secret_bytes(), &bob.public_bytes()).unwrap();

        // Step 2: Responder processes msg1, creates msg2
        let (hs_r, msg2) =
            NoiseChannel::new_responder(&bob.secret_bytes(), &alice.public_bytes(), &msg1).unwrap();

        // Step 3: Finish both sides
        let mut ch_a = NoiseChannel::finish_initiator(hs_i, &msg2).unwrap();
        let mut ch_b = NoiseChannel::finish_responder(hs_r).unwrap();

        // Verify transport works
        let ct = ch_a.encrypt(b"step-wise works").unwrap();
        let pt = ch_b.decrypt(&ct).unwrap();
        assert_eq!(pt, b"step-wise works");
    }

    #[test]
    fn test_noise_wrong_key_fails() {
        let alice = DeviceKeyPair::generate();
        let bob = DeviceKeyPair::generate();
        let eve = DeviceKeyPair::generate();

        // Alice thinks she's talking to Bob, but Eve tries to respond
        let (_hs_i, msg1) =
            NoiseChannel::new_initiator(&alice.secret_bytes(), &bob.public_bytes()).unwrap();

        // Eve tries to act as responder with her own key but claiming alice's remote
        let result =
            NoiseChannel::new_responder(&eve.secret_bytes(), &alice.public_bytes(), &msg1);
        // KK pattern: responder's static key mismatch causes decryption failure
        assert!(result.is_err());
    }

    #[test]
    fn test_encrypt_decrypt_empty_message() {
        let alice = DeviceKeyPair::generate();
        let bob = DeviceKeyPair::generate();

        let (mut ch_a, mut ch_b) = NoiseChannel::establish(
            &alice.secret_bytes(),
            &alice.public_bytes(),
            &bob.secret_bytes(),
            &bob.public_bytes(),
        )
        .unwrap();

        let ct = ch_a.encrypt(b"").unwrap();
        let pt = ch_b.decrypt(&ct).unwrap();
        assert!(pt.is_empty());
    }

    #[test]
    fn test_encrypt_decrypt_large_message() {
        let alice = DeviceKeyPair::generate();
        let bob = DeviceKeyPair::generate();

        let (mut ch_a, mut ch_b) = NoiseChannel::establish(
            &alice.secret_bytes(),
            &alice.public_bytes(),
            &bob.secret_bytes(),
            &bob.public_bytes(),
        )
        .unwrap();

        let large = vec![0xABu8; 60000];
        let ct = ch_a.encrypt(&large).unwrap();
        let pt = ch_b.decrypt(&ct).unwrap();
        assert_eq!(pt, large);
    }

    #[test]
    fn test_pairing_data_roundtrip() {
        let kp = DeviceKeyPair::generate();
        let pd = PairingData {
            device_name: "iPhone 16 Pro".to_string(),
            device_type: DeviceType::IOS,
            public_key: kp.public_bytes(),
        };

        let bytes = pd.to_bytes();
        let pd2 = PairingData::from_bytes(&bytes).unwrap();
        assert_eq!(pd, pd2);
    }

    #[test]
    fn test_pairing_data_all_device_types() {
        let key = [42u8; 32];
        for dt in [
            DeviceType::IOS,
            DeviceType::MacOS,
            DeviceType::WatchOS,
            DeviceType::CLI,
            DeviceType::Browser,
            DeviceType::Python,
        ] {
            let pd = PairingData {
                device_name: "Test".to_string(),
                device_type: dt,
                public_key: key,
            };
            let bytes = pd.to_bytes();
            let pd2 = PairingData::from_bytes(&bytes).unwrap();
            assert_eq!(pd2.device_type, dt);
        }
    }

    #[test]
    fn test_pairing_data_empty_name() {
        let pd = PairingData {
            device_name: String::new(),
            device_type: DeviceType::CLI,
            public_key: [0u8; 32],
        };
        let bytes = pd.to_bytes();
        let pd2 = PairingData::from_bytes(&bytes).unwrap();
        assert_eq!(pd2.device_name, "");
    }

    #[test]
    fn test_pairing_data_truncated_fails() {
        assert!(PairingData::from_bytes(&[0u8; 10]).is_err());
    }

    #[test]
    fn test_authorization_request_response_flow() {
        let alice = DeviceKeyPair::generate();
        let bob = DeviceKeyPair::generate();

        let (mut ch_a, mut ch_b) = NoiseChannel::establish(
            &alice.secret_bytes(),
            &alice.public_bytes(),
            &bob.secret_bytes(),
            &bob.public_bytes(),
        )
        .unwrap();

        // Alice creates an auth request
        let metadata = b"please unlock item-123";
        let req = AuthorizationRequest::new(
            "alice-device-id",
            Some("bob-device-id"),
            AuthRequestType::ReadItem,
            metadata,
            &mut ch_a,
            300,
        )
        .unwrap();

        assert_eq!(req.status, AuthStatus::Pending);
        assert_eq!(req.request_type, AuthRequestType::ReadItem);

        // Bob decrypts the metadata
        let decrypted_meta = req.decrypt_metadata(&mut ch_b).unwrap();
        assert_eq!(decrypted_meta, metadata);

        // Bob creates a response
        let payload = b"here-is-the-vault-key-material";
        let resp = AuthorizationResponse::new(
            &req.request_id,
            "bob-device-id",
            payload,
            &mut ch_b,
        )
        .unwrap();

        assert_eq!(resp.request_id, req.request_id);

        // Alice decrypts the response
        let decrypted_payload = resp.decrypt_payload(&mut ch_a).unwrap();
        assert_eq!(decrypted_payload, payload);
    }

    #[test]
    fn test_auth_request_broadcast() {
        let alice = DeviceKeyPair::generate();
        let bob = DeviceKeyPair::generate();

        let (mut ch_a, mut ch_b) = NoiseChannel::establish(
            &alice.secret_bytes(),
            &alice.public_bytes(),
            &bob.secret_bytes(),
            &bob.public_bytes(),
        )
        .unwrap();

        let req = AuthorizationRequest::new(
            "alice-device-id",
            None, // broadcast
            AuthRequestType::Unlock,
            b"unlock-request",
            &mut ch_a,
            60,
        )
        .unwrap();

        assert!(req.target_device_id.is_none());
        let meta = req.decrypt_metadata(&mut ch_b).unwrap();
        assert_eq!(meta, b"unlock-request");
    }

    #[test]
    fn test_device_identity_serde_roundtrip() {
        let kp = DeviceKeyPair::generate();
        let identity = DeviceIdentity {
            device_id: uuid::Uuid::new_v4().to_string(),
            device_name: "Mac Studio".to_string(),
            device_type: DeviceType::MacOS,
            public_key: kp.public_bytes(),
            created_at: chrono::Utc::now().to_rfc3339(),
            last_seen_at: chrono::Utc::now().to_rfc3339(),
            is_trusted: true,
        };

        let json = serde_json::to_string(&identity).unwrap();
        let deserialized: DeviceIdentity = serde_json::from_str(&json).unwrap();

        assert_eq!(deserialized.device_id, identity.device_id);
        assert_eq!(deserialized.device_name, identity.device_name);
        assert_eq!(deserialized.device_type, identity.device_type);
        assert_eq!(deserialized.public_key, identity.public_key);
        assert_eq!(deserialized.is_trusted, identity.is_trusted);
    }
}
