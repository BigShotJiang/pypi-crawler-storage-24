use std::io::{Cursor, Read};
use std::str::FromStr;

use chrono::Utc;
use keepass::{Database, DatabaseKey};
use serde_json::Value;
use uuid::Uuid;

use crate::error::{Result, ClaustraError};
use crate::models::{Category, CustomField, PasswordItem};
use crate::totp::parse_totp_uri;

// ---------------------------------------------------------------------------
// Export
// ---------------------------------------------------------------------------

/// Serialize a slice of `PasswordItem`s to pretty-printed JSON.
pub fn export_json(items: &[PasswordItem]) -> Result<String> {
    let json = serde_json::to_string_pretty(items)?;
    Ok(json)
}

/// Serialize a slice of `PasswordItem`s to CSV.
///
/// Columns: title, username, password, website, category, notes, tags
/// Tags are joined with ";".
pub fn export_csv(items: &[PasswordItem]) -> Result<String> {
    let mut wtr = csv::Writer::from_writer(vec![]);
    wtr.write_record(["title", "username", "password", "website", "category", "notes", "tags"])?;
    for item in items {
        wtr.write_record([
            &item.title,
            &item.username,
            &item.password,
            &item.website,
            &item.category.to_string(),
            &item.notes,
            &item.tags.join(";"),
        ])?;
    }
    let data = wtr.into_inner().map_err(|e| ClaustraError::Io(e.into_error()))?;
    String::from_utf8(data).map_err(|e| ClaustraError::InvalidInput(e.to_string()))
}

// ---------------------------------------------------------------------------
// Import – JSON
// ---------------------------------------------------------------------------

/// Parse a JSON array of `PasswordItem`s.
///
/// Missing fields fall back to `PasswordItem::default()`. Each item is
/// guaranteed to have a non-empty `id`, `created_at`, and `updated_at`.
pub fn import_json(json_str: &str) -> Result<Vec<PasswordItem>> {
    let values: Vec<Value> = serde_json::from_str(json_str)?;
    let now = Utc::now().to_rfc3339();

    let items = values
        .into_iter()
        .map(|v| {
            let mut item: PasswordItem = serde_json::from_value(v).unwrap_or_default();
            if item.id.is_empty() {
                item.id = Uuid::new_v4().to_string();
            }
            if item.created_at.is_empty() {
                item.created_at = now.clone();
            }
            if item.updated_at.is_empty() {
                item.updated_at = now.clone();
            }
            item
        })
        .collect();

    Ok(items)
}

// ---------------------------------------------------------------------------
// Import – CSV
// ---------------------------------------------------------------------------

/// Parse CSV text into a `Vec<PasswordItem>`.
///
/// Expected header: `title, username, password, website, category, notes, tags`
/// Tags are split on ";". An unrecognised category defaults to `Logins`.
pub fn import_csv(csv_str: &str) -> Result<Vec<PasswordItem>> {
    let mut rdr = csv::Reader::from_reader(csv_str.as_bytes());
    let now = Utc::now().to_rfc3339();
    let mut items = Vec::new();

    for result in rdr.records() {
        let record = result?;

        let get = |idx: usize| record.get(idx).unwrap_or("").to_string();

        let category = Category::from_str(&get(4)).unwrap_or_default();

        let tags: Vec<String> = {
            let raw = get(6);
            if raw.is_empty() {
                Vec::new()
            } else {
                raw.split(';')
                    .map(|s| s.trim().to_string())
                    .filter(|s| !s.is_empty())
                    .collect()
            }
        };

        let item = PasswordItem {
            id: Uuid::new_v4().to_string(),
            title: get(0),
            username: get(1),
            password: get(2),
            website: get(3),
            category,
            notes: get(5),
            tags,
            created_at: now.clone(),
            updated_at: now.clone(),
            ..Default::default()
        };

        items.push(item);
    }

    Ok(items)
}

// ---------------------------------------------------------------------------
// Import – 1Password .1pux
// ---------------------------------------------------------------------------

fn map_1p_category(uuid: &str) -> Category {
    match uuid {
        "001" => Category::Logins,
        "002" | "003" => Category::Cards,
        "004" => Category::Identities,
        "005" => Category::Logins,
        "006" => Category::Notes,
        "007" | "101" => Category::BankAccounts,
        "100" => Category::SoftwareLicenses,
        "109" => Category::Wifi,
        "112" | "114" => Category::Logins,
        _ => Category::Logins,
    }
}

/// Parse a 1Password `.1pux` export (ZIP containing `export.data`).
///
/// Skips archived items. Each imported item receives a fresh UUID.
pub fn import_1pux(zip_data: &[u8]) -> Result<Vec<PasswordItem>> {
    let cursor = Cursor::new(zip_data);
    let mut archive = zip::ZipArchive::new(cursor)
        .map_err(|e| ClaustraError::InvalidInput(format!("ZIP error: {e}")))?;

    let export_data = {
        let mut file = archive.by_name("export.data").map_err(|_| {
            ClaustraError::InvalidInput("export.data not found in ZIP".into())
        })?;
        let mut buf = String::new();
        file.read_to_string(&mut buf)?;
        buf
    };

    let root: Value = serde_json::from_str(&export_data)?;
    let now = Utc::now().to_rfc3339();
    let mut items: Vec<PasswordItem> = Vec::new();

    let accounts = root
        .get("accounts")
        .and_then(|a| a.as_array())
        .cloned()
        .unwrap_or_default();

    for account in &accounts {
        let vaults = account
            .get("vaults")
            .and_then(|v| v.as_array())
            .cloned()
            .unwrap_or_default();

        for vault in &vaults {
            let vault_items = vault
                .get("items")
                .and_then(|i| i.as_array())
                .cloned()
                .unwrap_or_default();

            for raw_item in &vault_items {
                let state = raw_item
                    .get("state")
                    .and_then(|s| s.as_str())
                    .unwrap_or("");
                if state == "archived" {
                    continue;
                }

                let overview = raw_item.get("overview").cloned().unwrap_or(Value::Null);
                let details = raw_item.get("details").cloned().unwrap_or(Value::Null);

                let title = overview
                    .get("title")
                    .and_then(|t| t.as_str())
                    .unwrap_or("Untitled")
                    .to_string();

                let category_uuid = raw_item
                    .get("categoryUuid")
                    .and_then(|c| c.as_str())
                    .unwrap_or("001");
                let category = map_1p_category(category_uuid);

                let website = overview
                    .get("url")
                    .and_then(|u| u.as_str())
                    .map(|s| s.to_string())
                    .or_else(|| {
                        overview
                            .get("urls")
                            .and_then(|urls| urls.as_array())
                            .and_then(|arr| arr.first())
                            .and_then(|u| u.get("u").and_then(|x| x.as_str()))
                            .map(|s| s.to_string())
                    })
                    .unwrap_or_default();

                let notes = details
                    .get("notesPlain")
                    .and_then(|n| n.as_str())
                    .unwrap_or("")
                    .to_string();

                let mut username = String::new();
                let mut password = String::new();
                let mut totp_secret = String::new();

                if let Some(login_fields) = details.get("loginFields").and_then(|f| f.as_array()) {
                    for field in login_fields {
                        let designation =
                            field.get("designation").and_then(|d| d.as_str()).unwrap_or("");
                        let value = field
                            .get("value")
                            .and_then(|v| v.as_str())
                            .unwrap_or("")
                            .to_string();

                        match designation {
                            "username" if username.is_empty() => username = value,
                            "password" if password.is_empty() => password = value,
                            _ => {}
                        }
                    }
                }

                if password.is_empty() {
                    if let Some(p) = details.get("password").and_then(|p| p.as_str()) {
                        password = p.to_string();
                    }
                }

                // Extract TOTP from section fields
                'outer: for section in details
                    .get("sections")
                    .and_then(|s| s.as_array())
                    .cloned()
                    .unwrap_or_default()
                    .iter()
                {
                    for field in section
                        .get("fields")
                        .and_then(|f| f.as_array())
                        .cloned()
                        .unwrap_or_default()
                        .iter()
                    {
                        let field_id = field.get("id").and_then(|i| i.as_str()).unwrap_or("");
                        let field_type =
                            field.get("type").and_then(|t| t.as_str()).unwrap_or("");
                        let raw_value = field
                            .get("value")
                            .and_then(|v| v.as_str())
                            .unwrap_or("")
                            .to_string();

                        let is_totp = field_id.to_lowercase().contains("totp")
                            || field_type.to_lowercase().contains("totp")
                            || raw_value.starts_with("otpauth://");

                        if is_totp && !raw_value.is_empty() {
                            if raw_value.starts_with("otpauth://") {
                                if let Some(s) = parse_totp_uri(&raw_value) {
                                    totp_secret = s;
                                }
                            } else {
                                totp_secret = raw_value;
                            }
                            break 'outer;
                        }
                    }
                }

                items.push(PasswordItem {
                    id: Uuid::new_v4().to_string(),
                    title,
                    username,
                    password,
                    website,
                    notes,
                    category,
                    totp_secret,
                    created_at: now.clone(),
                    updated_at: now.clone(),
                    ..Default::default()
                });
            }
        }
    }

    Ok(items)
}

// ---------------------------------------------------------------------------
// Import – Bitwarden JSON
// ---------------------------------------------------------------------------

/// Parse a Bitwarden unencrypted JSON export into a `Vec<PasswordItem>`.
///
/// Bitwarden types: 1=Login, 2=SecureNote, 3=Card, 4=Identity.
/// Returns an error if the export is encrypted.
pub fn import_bitwarden_json(json_str: &str) -> Result<Vec<PasswordItem>> {
    let root: Value = serde_json::from_str(json_str)?;

    if root.get("encrypted").and_then(|v| v.as_bool()).unwrap_or(false) {
        return Err(ClaustraError::InvalidInput(
            "Encrypted exports not supported. Please export without encryption.".into(),
        ));
    }

    let items_raw = root
        .get("items")
        .and_then(|v| v.as_array())
        .cloned()
        .unwrap_or_default();

    let now = Utc::now().to_rfc3339();
    let mut items: Vec<PasswordItem> = Vec::new();

    for raw in &items_raw {
        let str_field = |key: &str| -> String {
            raw.get(key).and_then(|v| v.as_str()).unwrap_or("").to_string()
        };

        let item_type = raw.get("type").and_then(|v| v.as_u64()).unwrap_or(1);
        let category = match item_type {
            2 => Category::Notes,
            3 => Category::Cards,
            4 => Category::Identities,
            _ => Category::Logins,
        };

        let title = str_field("name");
        let notes = str_field("notes");
        let is_favorite = raw.get("favorite").and_then(|v| v.as_bool()).unwrap_or(false);

        let login = raw.get("login");
        let username = login
            .and_then(|l| l.get("username"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        let password = login
            .and_then(|l| l.get("password"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        let totp_secret = login
            .and_then(|l| l.get("totp"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        let website = login
            .and_then(|l| l.get("uris"))
            .and_then(|u| u.as_array())
            .and_then(|arr| arr.first())
            .and_then(|u| u.get("uri"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();

        // Map Bitwarden custom fields (type 0=text, 1=hidden → treat both as text/hidden)
        let custom_fields: Vec<CustomField> = raw
            .get("fields")
            .and_then(|f| f.as_array())
            .map(|arr| {
                arr.iter()
                    .map(|f| {
                        let field_type_num = f.get("type").and_then(|t| t.as_u64()).unwrap_or(0);
                        CustomField {
                            id: Uuid::new_v4().to_string(),
                            label: f
                                .get("name")
                                .and_then(|v| v.as_str())
                                .unwrap_or("")
                                .to_string(),
                            value: f
                                .get("value")
                                .and_then(|v| v.as_str())
                                .unwrap_or("")
                                .to_string(),
                            field_type: if field_type_num == 1 {
                                "hidden".to_string()
                            } else {
                                "text".to_string()
                            },
                        }
                    })
                    .collect()
            })
            .unwrap_or_default();

        items.push(PasswordItem {
            id: Uuid::new_v4().to_string(),
            title,
            username,
            password,
            website,
            notes,
            category,
            is_favorite,
            totp_secret,
            custom_fields,
            created_at: now.clone(),
            updated_at: now.clone(),
            ..Default::default()
        });
    }

    Ok(items)
}

// ---------------------------------------------------------------------------
// Import – LastPass CSV
// ---------------------------------------------------------------------------

/// Parse a LastPass CSV export into a `Vec<PasswordItem>`.
///
/// Expected header: `url,username,password,totp,extra,name,grouping,fav`
/// The `grouping` field (backslash-separated) is mapped to tags.
pub fn import_lastpass_csv(csv_str: &str) -> Result<Vec<PasswordItem>> {
    let mut rdr = csv::Reader::from_reader(csv_str.as_bytes());
    let now = Utc::now().to_rfc3339();
    let mut items = Vec::new();

    for result in rdr.records() {
        let record = result?;

        let get = |idx: usize| record.get(idx).unwrap_or("").to_string();

        let website = get(0);
        let username = get(1);
        let password = get(2);
        let totp_secret = get(3);
        let notes = get(4);
        let title = get(5);
        let grouping = get(6);
        let fav_str = get(7);

        let is_favorite = fav_str.trim() == "1";

        let tags: Vec<String> = if grouping.is_empty() {
            Vec::new()
        } else {
            grouping
                .split('\\')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect()
        };

        items.push(PasswordItem {
            id: Uuid::new_v4().to_string(),
            title,
            username,
            password,
            website,
            notes,
            totp_secret,
            is_favorite,
            tags,
            created_at: now.clone(),
            updated_at: now.clone(),
            ..Default::default()
        });
    }

    Ok(items)
}

// ---------------------------------------------------------------------------
// Import – KeePass KDBX
// ---------------------------------------------------------------------------

/// Parse a KeePass KDBX database from raw bytes using the given password.
///
/// Iterates all entries recursively. Each entry's parent group name is
/// added as a tag. Custom fields beyond the standard set are preserved.
pub fn import_keepass(data: &[u8], password: &str) -> Result<Vec<PasswordItem>> {
    let key = DatabaseKey::new().with_password(password);
    let db = Database::open(&mut Cursor::new(data), key)
        .map_err(|e| ClaustraError::InvalidInput(format!("KeePass open error: {e}")))?;

    let now = Utc::now().to_rfc3339();
    let mut items: Vec<PasswordItem> = Vec::new();

    // Standard field names handled explicitly; everything else becomes a custom field.
    const STANDARD_FIELDS: &[&str] = &["Title", "UserName", "Password", "URL", "Notes"];

    // Recursive closure helper via a stack — avoids lifetime complexity of nested fn.
    // Each element is (group_tag, group_ref).
    let mut stack: Vec<(String, &keepass::db::Group)> = vec![("".to_string(), &db.root)];

    while let Some((parent_tag, group)) = stack.pop() {
        // Build this group's tag for child entries.
        let group_tag = if parent_tag.is_empty() {
            group.name.clone()
        } else {
            format!("{}/{}", parent_tag, group.name)
        };

        for entry in &group.entries {
            let title = entry.get_title().unwrap_or("").to_string();
            let username = entry.get_username().unwrap_or("").to_string();
            let password = entry.get_password().unwrap_or("").to_string();
            let website = entry.get("URL").unwrap_or("").to_string();
            let notes = entry.get("Notes").unwrap_or("").to_string();

            // `entry.get(key)` already handles both Unprotected and Protected variants.
            let custom_fields: Vec<CustomField> = entry
                .fields
                .iter()
                .filter(|(k, _)| !STANDARD_FIELDS.contains(&k.as_str()))
                .map(|(k, _)| CustomField {
                    id: Uuid::new_v4().to_string(),
                    label: k.clone(),
                    value: entry.get(k).unwrap_or("").to_string(),
                    field_type: "text".to_string(),
                })
                .collect();

            let tags: Vec<String> = if group_tag.is_empty() {
                Vec::new()
            } else {
                vec![group_tag.clone()]
            };

            items.push(PasswordItem {
                id: Uuid::new_v4().to_string(),
                title,
                username,
                password,
                website,
                notes,
                custom_fields,
                tags,
                created_at: now.clone(),
                updated_at: now.clone(),
                ..Default::default()
            });
        }

        // Push child groups onto the stack for processing.
        for child_group in &group.groups {
            stack.push((group_tag.clone(), child_group));
        }
    }

    Ok(items)
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::models::Category;
    use serde_json::Value;

    fn sample_item() -> PasswordItem {
        PasswordItem {
            id: "test-id-1".to_string(),
            title: "GitHub".to_string(),
            username: "alice".to_string(),
            password: "s3cr3t".to_string(),
            website: "https://github.com".to_string(),
            notes: "my github".to_string(),
            category: Category::Logins,
            tags: vec!["dev".to_string(), "code".to_string()],
            ..Default::default()
        }
    }

    // --- JSON ---

    #[test]
    fn test_export_json_produces_valid_json() {
        let items = vec![sample_item()];
        let json = export_json(&items).expect("export failed");
        let parsed: Vec<Value> = serde_json::from_str(&json).expect("parse failed");
        assert_eq!(parsed.len(), 1);
        assert_eq!(parsed[0]["title"], "GitHub");
    }

    #[test]
    fn test_import_json_round_trip() {
        let items = vec![sample_item()];
        let json = export_json(&items).expect("export failed");
        let imported = import_json(&json).expect("import failed");
        assert_eq!(imported.len(), 1);
        assert_eq!(imported[0].title, "GitHub");
        assert_eq!(imported[0].username, "alice");
        assert_eq!(imported[0].tags, vec!["dev", "code"]);
    }

    #[test]
    fn test_import_json_assigns_id_if_missing() {
        let json = r#"[{"title":"Test"}]"#;
        let imported = import_json(json).expect("import failed");
        assert!(!imported[0].id.is_empty());
    }

    #[test]
    fn test_import_json_assigns_timestamps_if_missing() {
        let json = r#"[{}]"#;
        let imported = import_json(json).expect("import failed");
        assert!(!imported[0].created_at.is_empty());
        assert!(!imported[0].updated_at.is_empty());
    }

    // --- CSV ---

    #[test]
    fn test_export_csv_has_header_and_data() {
        let items = vec![sample_item()];
        let csv = export_csv(&items).expect("export failed");
        let lines: Vec<&str> = csv.lines().collect();
        assert!(lines[0].starts_with("title"));
        assert!(lines[1].contains("GitHub"));
        assert!(lines[1].contains("alice"));
    }

    #[test]
    fn test_import_csv_round_trip() {
        let items = vec![sample_item()];
        let csv = export_csv(&items).expect("export failed");
        let imported = import_csv(&csv).expect("import failed");
        assert_eq!(imported.len(), 1);
        assert_eq!(imported[0].title, "GitHub");
        assert_eq!(imported[0].username, "alice");
        assert_eq!(imported[0].password, "s3cr3t");
        assert_eq!(imported[0].tags, vec!["dev", "code"]);
    }

    #[test]
    fn test_import_csv_invalid_category_defaults_to_logins() {
        let csv =
            "title,username,password,website,category,notes,tags\nTest,u,p,w,unknown,,\n";
        let imported = import_csv(csv).expect("import failed");
        assert_eq!(imported[0].category, Category::Logins);
    }

    #[test]
    fn test_import_csv_valid_category() {
        let csv =
            "title,username,password,website,category,notes,tags\nCard,u,p,w,cards,,\n";
        let imported = import_csv(csv).expect("import failed");
        assert_eq!(imported[0].category, Category::Cards);
    }

    // --- 1pux category mapping ---

    #[test]
    fn test_map_1p_category() {
        assert_eq!(map_1p_category("001"), Category::Logins);
        assert_eq!(map_1p_category("002"), Category::Cards);
        assert_eq!(map_1p_category("006"), Category::Notes);
        assert_eq!(map_1p_category("100"), Category::SoftwareLicenses);
        assert_eq!(map_1p_category("109"), Category::Wifi);
        assert_eq!(map_1p_category("999"), Category::Logins);
    }
}
