# SkillDepot Python SDK

Official Python client for the [SkillDepot](https://skilldepot.dev) marketplace.

## Installation

```bash
pip install skilldepot
```

## Usage

```python
from skilldepot import SkillDepot

# Initialize client
client = SkillDepot(api_key="your_api_key")

# List skills
skills = client.list_skills(category="NLP", limit=5)
for skill in skills.data:
    print(f"{skill.name}: {skill.description}")

# Get skill details with content
skill = client.get_skill("sentiment-analyzer", include_content=True)
print(skill.data.content)

# Run a skill
result = client.run("sentiment-analyzer", {"text": "I love SkillDepot!"})
print(result)
```

## Requirements
- Python 3.9+
- `httpx`
- `pydantic`
