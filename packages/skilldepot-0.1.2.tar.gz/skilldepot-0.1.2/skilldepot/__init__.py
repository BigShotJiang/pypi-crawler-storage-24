"""
SkillDepot — Official Python SDK for the AI Skills Marketplace.

Quick start:
    from skilldepot import SkillDepot

    client = SkillDepot(api_key="sk_live_...")
    skills = client.list_skills(category="NLP")

    for skill in skills.data:
        print(f"{skill.name} — {skill.rating}★")
"""

from .client import SkillDepot, AsyncSkillDepot, SkillDepotError, AuthenticationError, AccessDeniedError, NotFoundError, RateLimitError
from .models import Skill, Profile, Review, Package, APIKey, PricingModel

__version__ = "0.1.0"

__all__ = [
    "SkillDepot",
    "AsyncSkillDepot",
    "SkillDepotError",
    "AuthenticationError",
    "AccessDeniedError",
    "NotFoundError",
    "RateLimitError",
    "Skill",
    "Profile",
    "Review",
    "Package",
    "APIKey",
    "PricingModel",
]
