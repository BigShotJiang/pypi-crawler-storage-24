"""
Tiger MCP Server package
"""
