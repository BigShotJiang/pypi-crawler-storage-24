from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.voice_upload_request import VoiceUploadRequest
from ...models.voice_upload_response import VoiceUploadResponse
from ...types import Response


def _get_kwargs(
    *,
    body: VoiceUploadRequest,
    api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["api-key"] = api_key

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v0/voice/upload",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | VoiceUploadResponse | None:
    if response.status_code == 201:
        response_201 = VoiceUploadResponse.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | VoiceUploadResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: VoiceUploadRequest,
    api_key: str,
) -> Response[HTTPValidationError | VoiceUploadResponse]:
    """Upload Voice File

     Upload a base64-encoded audio file (WAV or MP3).

    Files are stored in their original format. Duration is extracted
    from audio headers.

    Args:
        api_key (str):
        body (VoiceUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VoiceUploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: VoiceUploadRequest,
    api_key: str,
) -> HTTPValidationError | VoiceUploadResponse | None:
    """Upload Voice File

     Upload a base64-encoded audio file (WAV or MP3).

    Files are stored in their original format. Duration is extracted
    from audio headers.

    Args:
        api_key (str):
        body (VoiceUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VoiceUploadResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        api_key=api_key,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: VoiceUploadRequest,
    api_key: str,
) -> Response[HTTPValidationError | VoiceUploadResponse]:
    """Upload Voice File

     Upload a base64-encoded audio file (WAV or MP3).

    Files are stored in their original format. Duration is extracted
    from audio headers.

    Args:
        api_key (str):
        body (VoiceUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VoiceUploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        api_key=api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: VoiceUploadRequest,
    api_key: str,
) -> HTTPValidationError | VoiceUploadResponse | None:
    """Upload Voice File

     Upload a base64-encoded audio file (WAV or MP3).

    Files are stored in their original format. Duration is extracted
    from audio headers.

    Args:
        api_key (str):
        body (VoiceUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VoiceUploadResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            api_key=api_key,
        )
    ).parsed
