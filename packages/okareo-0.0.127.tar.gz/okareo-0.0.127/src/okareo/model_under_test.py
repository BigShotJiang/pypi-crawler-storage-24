import asyncio
import inspect
import json
import logging
import ssl
import threading
import urllib
from abc import abstractmethod
from base64 import b64encode
from datetime import datetime
from typing import Any, Awaitable, Dict, List, Optional, Union
from uuid import UUID, uuid4

import aiohttp
from attrs import define
from attrs import define as _attrs_define
from attrs import field
from nkeys import from_seed  # type: ignore
from tqdm import tqdm  # type: ignore

from okareo.error import MissingApiKeyError, MissingVectorDbError, TestRunError
from okareo_api_client.api.default import (
    add_datapoint_v0_datapoints_post,
    evaluate_v0_evaluate_post,
    get_scenario_set_data_points_v0_scenario_data_points_scenario_id_get,
    get_test_run_v0_test_runs_test_run_id_get,
    internal_custom_model_listener_v0_internal_custom_model_listener_get,
    run_test_v0_test_run_post,
    submit_test_v0_test_run_submit_post,
)
from okareo_api_client.client import Client
from okareo_api_client.errors import UnexpectedStatus
from okareo_api_client.models import (
    DatapointResponse,
    DatapointSchema,
    ModelUnderTestResponse,
    ScenarioDataPoinResponse,
    TestRunItem,
    TestRunType,
)
from okareo_api_client.models.driver_model_response import DriverModelResponse
from okareo_api_client.models.error_response import ErrorResponse
from okareo_api_client.models.evaluation_payload import EvaluationPayload
from okareo_api_client.models.evaluation_payload_metrics_kwargs import (
    EvaluationPayloadMetricsKwargs,
)
from okareo_api_client.models.scenario_set_response import ScenarioSetResponse
from okareo_api_client.models.target_model_response import TargetModelResponse
from okareo_api_client.models.test_run_payload_v2 import TestRunPayloadV2
from okareo_api_client.models.test_run_payload_v2_api_keys_type_0 import (
    TestRunPayloadV2ApiKeysType0,
)
from okareo_api_client.models.test_run_payload_v2_metrics_kwargs import (
    TestRunPayloadV2MetricsKwargs,
)
from okareo_api_client.models.test_run_payload_v2_model_results_type_0 import (
    TestRunPayloadV2ModelResultsType0,
)
from okareo_api_client.models.test_run_payload_v2_simulation_params_type_0 import (
    TestRunPayloadV2SimulationParamsType0,
)
from okareo_api_client.models.voice_driver_model_response import (
    VoiceDriverModelResponse,
)
from okareo_api_client.types import UNSET, Unset

from .async_utils import AsyncProcessorMixin

## BEGIN Monkey Patch for nats to use proxy env vars (via aiohttp)
#  Apply monkey patch at module level to allow aiohttp client session to pull proxy env vars
_original_client_session = aiohttp.ClientSession


# Create a wrapper class that inherits from the original ClientSession
class PatchedClientSession(_original_client_session):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        logging.debug("Applying proxy patch to aiohttp")
        logging.debug("Proxy env vars: %s", urllib.request.getproxies())
        kwargs["trust_env"] = True
        super().__init__(*args, **kwargs)


# Replace the original ClientSession with our patched version
aiohttp.ClientSession = PatchedClientSession  # type: ignore
# We import nats only after patching aiohttp to respect the proxy env vars
import nats  # type: ignore # noqa: E402

## END Monkey Patch for nats to use proxy env vars (via aiohttp)


class BaseModel:
    type: str
    api_key: Optional[str]

    @abstractmethod
    def params(self) -> dict:
        pass

    def get_sensitive_fields(self) -> list[str]:
        return []


class ModelUnderTest(AsyncProcessorMixin):
    """A class for managing a Model Under Test (MUT) in Okareo.
    Returned by [okareo.register_model()](/docs/reference/python-sdk/okareo#register_model)
    """

    def __init__(
        self,
        client: Client,
        api_key: str,
        mut: ModelUnderTestResponse,
        models: Optional[Dict[str, Any]] = None,
    ):
        self.client = client
        self.api_key = api_key

        self.version = mut.version
        self.mut_id = mut.id
        self.project_id = mut.project_id
        self.name = mut.name
        self.tags = mut.tags
        self.models = models
        self.app_link = mut.app_link
        self.model_key: Optional[str] = None
        super().__init__(name="OkareoDatapointsProcessor")

    def get_client(self) -> Client:
        return self.client

    def get_api_key(self) -> str:
        return self.api_key

    def add_data_point(
        self,
        input_obj: Union[dict, str, None] = None,
        result_obj: Union[dict, str, None] = None,
        feedback: Union[float, None] = None,
        context_token: Union[str, None] = None,
        error_message: Union[str, None] = None,
        error_code: Union[str, None] = None,
        input_datetime: Union[str, Unset] = UNSET,
        result_datetime: Union[str, Unset] = UNSET,
        project_id: Union[str, None] = None,
        tags: Union[List[str], None] = None,
        test_run_id: Union[None, str] = None,
        group_id: Union[None, str] = None,
    ) -> Union[DatapointResponse, ErrorResponse]:
        body = {
            "tags": tags or [],
            "input": json.dumps(input_obj, default=str),
            "result": json.dumps(result_obj, default=str),
            "context_token": context_token,
            "feedback": feedback,
            "error_message": error_message,
            "error_code": error_code,
            "input_datetime": (
                datetime.now().isoformat()
                if input_datetime == UNSET and input_obj is not None
                else input_datetime
            ),
            "result_datetime": (
                datetime.now().isoformat()
                if result_datetime == UNSET and result_obj is not None
                else result_datetime
            ),
            "project_id": str(self.project_id),
            "mut_id": str(self.mut_id),
        }
        if test_run_id is not None:
            body["test_run_id"] = test_run_id
        if group_id is not None:
            body["group_id"] = group_id
        response = add_datapoint_v0_datapoints_post.sync(
            client=self.client,
            api_key=self.api_key,
            body=DatapointSchema.from_dict(body),
        )
        if not response:
            print("Empty response from API")
        assert response is not None

        return response

    def add_data_point_async(
        self,
        input_obj: Union[dict, str, None] = None,
        result_obj: Union[dict, str, None] = None,
        feedback: Union[float, None] = None,
        context_token: Union[str, None] = None,
        error_message: Union[str, None] = None,
        error_code: Union[str, None] = None,
        input_datetime: Union[str, Unset] = UNSET,
        result_datetime: Union[str, Unset] = UNSET,
        project_id: Union[str, None] = None,
        tags: Union[List[str], None] = None,
        test_run_id: Union[None, str] = None,
        group_id: Union[None, str] = None,
    ) -> bool:
        body = {
            "tags": tags or [],
            "input": json.dumps(input_obj, default=str),
            "result": json.dumps(result_obj, default=str),
            "context_token": context_token,
            "feedback": feedback,
            "error_message": error_message,
            "error_code": error_code,
            "input_datetime": (
                datetime.now().isoformat()
                if input_datetime == UNSET and input_obj is not None
                else input_datetime
            ),
            "result_datetime": (
                datetime.now().isoformat()
                if result_datetime == UNSET and result_obj is not None
                else result_datetime
            ),
            "project_id": str(self.project_id),
            "mut_id": str(self.mut_id),
        }
        if test_run_id is not None:
            body["test_run_id"] = test_run_id
        if group_id is not None:
            body["group_id"] = group_id

        return self.async_call(
            add_datapoint_v0_datapoints_post.sync, DatapointSchema.from_dict(body)
        )

    def _validate_run_test_params(
        self,
        api_key: Optional[str],
        api_keys: Optional[dict],
        test_run_type: TestRunType,
    ) -> dict:
        assert isinstance(self.models, dict)
        model_names = list(self.models.keys())
        run_api_keys = api_keys if api_keys else {model_names[0]: api_key}

        if (
            "custom" not in model_names  # custom is a model without a key
            and test_run_type
            != TestRunType.MULTI_TURN  # driver can have 2 keys for driver and target
            and len(model_names) != len(run_api_keys)
        ):
            raise MissingApiKeyError("Number of models and API keys does not match")

        if test_run_type == TestRunType.INFORMATION_RETRIEVAL:
            if {"pinecone", "qdrant", "custom"}.isdisjoint(model_names):
                raise MissingVectorDbError("No vector database specified")

        return run_api_keys

    def _has_custom_model(self) -> bool:
        assert isinstance(self.models, dict)
        if any(
            model in self.models.keys()
            for model in [
                "custom_target",
                "custom_target_async",
                "custom",
                "custom_batch",
            ]
        ):
            return True
        return False

    def _has_async_custom_model(self) -> bool:
        assert isinstance(self.models, dict)
        return "custom_target_async" in self.models.keys()

    def _has_custom_batch_model(self) -> bool:
        assert isinstance(self.models, dict)
        return "custom_batch" in list(self.models.keys())

    def _get_scenario_data_points(
        self, scenario_id: Union[str, UUID]
    ) -> List[ScenarioDataPoinResponse]:
        scenario_data_points = (
            get_scenario_set_data_points_v0_scenario_data_points_scenario_id_get.sync(
                client=self.client,
                api_key=self.api_key,
                scenario_id=(
                    UUID(scenario_id) if isinstance(scenario_id, str) else scenario_id
                ),
            )
        )
        scenario_data_points = (
            scenario_data_points if isinstance(scenario_data_points, List) else []
        )
        return scenario_data_points

    def _add_model_invocation_for_scenario(
        self,
        custom_model_return_value: Any,
        model_data: dict,
        scenario_data_point_id: Union[str, UUID],
        test_run_id: Optional[str] = None,
    ) -> None:
        scenario_data_point_id = str(scenario_data_point_id)
        if isinstance(custom_model_return_value, ModelInvocation):
            model_prediction = custom_model_return_value.model_prediction
            model_output_metadata = custom_model_return_value.model_output_metadata
            model_input = custom_model_return_value.model_input
            tool_calls = custom_model_return_value.tool_calls
            error = custom_model_return_value.error
            error_message = error.get("error_message") if error else None
        else:  # assume the preexisting behavior of returning a tuple
            model_prediction, model_output_metadata = custom_model_return_value
            model_input = None
            tool_calls = None
            error = None
            error_message = None

        model_data["model_data"][scenario_data_point_id] = {
            "actual": model_prediction,
            "model_response": model_output_metadata,
            "model_input": model_input,
            "tool_calls": tool_calls,
        }
        if error_message:
            model_data["model_data"][scenario_data_point_id]["error_message"] = {
                "message": error_message
            }
        if test_run_id is not None:
            # add a data point for the invocation
            try:
                # Type checking inputs/predictions.
                # Seems that `add_data_point` interface accepts only str/dict/None,
                # but model_input and model_prediction can also be list.
                assert (
                    isinstance(model_input, str)
                    or isinstance(model_input, dict)
                    or model_input is None
                ), f"Unexpected model_input type: {type(model_input)}"
                assert (
                    isinstance(model_prediction, str)
                    or isinstance(model_prediction, dict)
                    or model_prediction is None
                ), f"Unexpected model_prediction type: {type(model_prediction)}"
                datapoint_response = self.add_data_point(
                    input_obj=model_input,
                    result_obj=model_prediction,
                    project_id=str(self.project_id),
                    test_run_id=test_run_id,
                    error_message=error_message,
                )
                self.validate_response(datapoint_response)
                assert isinstance(datapoint_response, DatapointResponse)
            except Exception as e:
                # Log the error but continue processing other datapoints
                print(
                    f"Failed to add datapoint for scenario_data_point_id {scenario_data_point_id}: {str(e)}. Adding error data point."
                )
                datapoint_response = self.add_data_point(
                    input_obj=model_input,  # type: ignore
                    project_id=str(self.project_id),
                    test_run_id=test_run_id,
                    error_message=str(e),
                )

                self.validate_response(datapoint_response)
                assert isinstance(datapoint_response, DatapointResponse)

    def _get_test_run_payload(
        self,
        scenario_id: Any,
        name: str,
        api_key: Optional[str],
        api_keys: Optional[dict],
        run_api_keys: dict,
        metrics_kwargs: Optional[dict],
        test_run_type: TestRunType,
        calculate_metrics: bool,
        model_data: dict,
        checks: Optional[List[str]],
        simulation_params: Optional[Any],
        driver_id: Optional[str],
        nats_invoke_id: Optional[str],
    ) -> TestRunPayloadV2:
        return TestRunPayloadV2(
            mut_id=self.mut_id,
            api_keys=(
                TestRunPayloadV2ApiKeysType0.from_dict(run_api_keys)
                if api_keys or api_key
                else UNSET
            ),
            scenario_id=scenario_id,
            name=name,
            type_=test_run_type,
            calculate_metrics=calculate_metrics,
            metrics_kwargs=TestRunPayloadV2MetricsKwargs.from_dict(
                metrics_kwargs or {}
            ),
            model_results=(
                TestRunPayloadV2ModelResultsType0.from_dict(model_data)
                if self._has_custom_model()
                else UNSET
            ),
            checks=checks if checks else UNSET,
            simulation_params=(
                TestRunPayloadV2SimulationParamsType0.from_dict(
                    simulation_params.to_dict()
                )
                if simulation_params
                else UNSET
            ),
            driver_id=(
                UUID(driver_id)
                if isinstance(driver_id, str)
                else (driver_id if driver_id else UNSET)
            ),
            nats_invoke_id=nats_invoke_id if nats_invoke_id else UNSET,
        )

    async def connect_nats(self, user_jwt: str, seed: str, local_nats: str) -> Any:
        nc = None
        if local_nats != "":
            nc = await nats.connect(
                # Use the hostname 'nats' which is the service name in docker-compose
                servers=[local_nats],
                connect_timeout=120,
                allow_reconnect=True,
                max_reconnect_attempts=10,
                reconnect_time_wait=10,
            )
        else:
            nkey = from_seed(seed.encode())

            def user_jwt_cb() -> Any:
                return user_jwt.encode()

            def user_sign_cb(nonce: str) -> Any:
                sig = nkey.sign(nonce.encode())
                return b64encode(sig)

            ssl_ctx = ssl.create_default_context()
            ssl_ctx.check_hostname = True
            ssl_ctx.verify_mode = ssl.CERT_REQUIRED
            ngs_url = "wss://connect.ngs.global:443"
            nc = await nats.connect(
                servers=[ngs_url],
                user_jwt_cb=user_jwt_cb,
                signature_cb=user_sign_cb,
                tls=ssl_ctx,
                connect_timeout=30,
                allow_reconnect=True,
                max_reconnect_attempts=5,
                reconnect_time_wait=1,
            )
        return nc

    async def call_custom_invoker_async(
        self,
        args: Any,
        message_history: Optional[list[dict[str, str]]] = None,
        scenario_input: Optional[Union[str, dict, list]] = None,
        session_id: Optional[str] = None,
        call_type: str = "invoke",
    ) -> Any:
        assert isinstance(self.models, dict)
        if not self.model_key:
            self.model_key = next(
                (
                    k
                    for k in [
                        "custom_target",
                        "custom_target_async",
                        "custom",
                        "custom_batch",
                    ]
                    if k in self.models.keys()
                ),
                None,
            )
        assert self.model_key is not None
        if call_type == "invoke":
            messages = message_history if message_history is not None else args
            invoker = self.models[self.model_key]["model_invoker"]
            sig = inspect.signature(invoker)
            num_positional = sum(
                1
                for param in sig.parameters.values()
                if param.kind in (param.POSITIONAL_ONLY, param.POSITIONAL_OR_KEYWORD)
            )
            if num_positional > 1 and scenario_input is not None:
                # new impl; first pos arg is message_history, second is scenario_input
                return await invoker(messages, scenario_input, session_id)
            else:
                # legacy impl; first pos arg is message_history (named args)
                return await invoker(args)
        elif call_type == "start_session":
            if "session_starter" in self.models[self.model_key]:
                message_history if message_history is not None else args
                invoker = self.models[self.model_key]["session_starter"]
                result = await invoker(scenario_input)
                if not isinstance(result, tuple):
                    raise TypeError(
                        "session_starter must return a tuple (session_id, ModelInvocation)"
                    )
                return result
        elif call_type == "end_session":
            if (
                "session_ender" in self.models[self.model_key]
                and session_id is not None
            ):
                return await self.models[self.model_key]["session_ender"](session_id)
        return None

    def call_custom_invoker(
        self,
        args: Any,
        message_history: Optional[list[dict[str, str]]] = None,
        scenario_input: Optional[Union[str, dict, list]] = None,
        session_id: Optional[str] = None,
        call_type: str = "invoke",
    ) -> Any:
        assert isinstance(self.models, dict)
        if self.models.get("custom"):
            return self.models["custom"]["model_invoker"](args)
        elif self.models.get("custom_batch"):
            return self.models["custom_batch"]["model_invoker"](args)
        else:
            if call_type == "invoke":
                messages = message_history if message_history is not None else args
                invoker = self.models["custom_target"]["model_invoker"]
                sig = inspect.signature(invoker)
                num_positional = sum(
                    1
                    for param in sig.parameters.values()
                    if param.kind
                    in (param.POSITIONAL_ONLY, param.POSITIONAL_OR_KEYWORD)
                )
                if num_positional > 1 and scenario_input is not None:
                    # new impl; first pos arg is message_history, second is scenario_input
                    return invoker(messages, scenario_input, session_id)
                else:
                    # legacy impl; first pos arg is message_history (named args)
                    return invoker(args)
            elif call_type == "start_session":
                if "session_starter" in self.models["custom_target"]:
                    message_history if message_history is not None else args
                    invoker = self.models["custom_target"]["session_starter"]
                    result = invoker(scenario_input)
                    if not isinstance(result, tuple):
                        raise TypeError(
                            "session_starter must return a tuple (session_id, ModelInvocation)"
                        )
                    return result
            elif call_type == "end_session":
                if (
                    "session_ender" in self.models["custom_target"]
                    and session_id is not None
                ):
                    return self.models["custom_target"]["session_ender"](session_id)
        return None

    def get_params_from_custom_result(self, result: Any) -> Any:
        if isinstance(result, tuple):
            if len(result) != 2:
                raise TypeError(
                    "start_session must return a tuple (session_id, ModelInvocation)"
                )
            if result[1] is not None and isinstance(result[1], ModelInvocation):
                invocation = result[1].params()
            else:
                invocation = {}
            if result[0] is not None and isinstance(result[0], str):
                # If session_id is provided, add it to the invocation
                invocation["session_id"] = result[0]
            else:
                invocation["session_id"] = None
            return invocation
        if isinstance(result, ModelInvocation):
            result = result.params()
        if (
            isinstance(result, list)
            and len(result) > 0
            and result[0].get("model_invocation")
        ):
            result = [r["model_invocation"].params() for r in result]
        return result

    async def process_single_message(
        self,
        msg: Any,
        nats_connection: Any,
        stop_event: Any,
    ) -> None:
        try:
            data = json.loads(msg.data.decode())
            if data.get("close"):
                await nats_connection.publish(
                    msg.reply, json.dumps({"status": "disconnected"}).encode()
                )
                stop_event.set()
                return
            args = data.get("args", [])
            message_history = data.get("message_history", [])
            scenario_input = data.get("scenario_input", None)
            session_id = data.get("session_id", None)
            call_type = data.get("call_type", "invoke")

            if not self._has_async_custom_model():
                result = self.call_custom_invoker(
                    args, message_history, scenario_input, session_id, call_type
                )
            else:
                result = await self.call_custom_invoker_async(
                    args, message_history, scenario_input, session_id, call_type
                )

            json_encodable_result = self.get_params_from_custom_result(result)
            await nats_connection.publish(
                msg.reply, json.dumps(json_encodable_result).encode()
            )

        except Exception as e:
            error_msg = f"An error occurred in the custom model invocation. {type(e).__name__}: {str(e)}"
            print(error_msg)
            await nats_connection.publish(
                msg.reply, json.dumps({"error": error_msg}).encode()
            )

    async def _internal_run_custom_model_listener(
        self, stop_event: Any, nats_jwt: str, seed: str, local_nats: str, invoke_id: str
    ) -> None:
        nats_connection = await self.connect_nats(nats_jwt, seed, local_nats)
        # Track active tasks for proper cleanup
        active_tasks: set[asyncio.Task] = set()

        try:

            async def message_handler_custom_model(msg: Any) -> None:
                # Create task and track it
                task = asyncio.create_task(
                    self.process_single_message(msg, nats_connection, stop_event)
                )
                active_tasks.add(task)

                # Remove completed tasks from the set to prevent memory leaks
                def task_done_callback(completed_task: asyncio.Task) -> None:
                    active_tasks.discard(completed_task)

                task.add_done_callback(task_done_callback)

            # Create multiple subscribers for better concurrency
            await nats_connection.subscribe(
                f"invoke.{invoke_id}",
                cb=message_handler_custom_model,
            )
            while not stop_event.is_set():
                await asyncio.sleep(0.1)

        except Exception as e:
            print(f"An error occurred in the custom model invocation: {str(e)}")
        finally:
            # Wait for all active tasks to complete before closing
            if active_tasks:
                await asyncio.gather(*active_tasks, return_exceptions=True)
            await nats_connection.close()

    def _internal_run_custom_model_thread(self, coro: Any) -> Any:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def _internal_start_custom_model_thread(
        self, nats_jwt: str, seed: str, local_nats: str, invoke_id: str
    ) -> tuple:
        custom_model_thread_stop_event = threading.Event()
        custom_model_thread = threading.Thread(
            target=self._internal_run_custom_model_thread,
            args=(
                self._internal_run_custom_model_listener(
                    custom_model_thread_stop_event,
                    nats_jwt,
                    seed,
                    local_nats,
                    invoke_id,
                ),
            ),
        )
        return custom_model_thread, custom_model_thread_stop_event

    def _internal_cleanup_custom_model(
        self,
        custom_model_thread_stop_event: threading.Event,
        custom_model_thread: threading.Thread,
    ) -> None:
        if custom_model_thread_stop_event:
            custom_model_thread_stop_event.set()  # Signal the thread to stop

        if custom_model_thread:
            custom_model_thread.join(timeout=5)

    def _run_test_internal(
        self,
        scenario: Union[ScenarioSetResponse, str, UUID],
        name: str,
        api_key: Optional[str] = None,
        api_keys: Optional[dict] = None,
        metrics_kwargs: Optional[dict] = None,
        test_run_type: TestRunType = TestRunType.MULTI_CLASS_CLASSIFICATION,
        calculate_metrics: bool = True,
        checks: Optional[List[str]] = None,
        run_test_method: Any = None,
        simulation_params: Optional[Any] = None,
        driver_id: Optional[str] = None,
    ) -> TestRunItem:
        """Internal method to run a test. This method is used by both run_test and submit_test."""
        self.custom_model_thread: Any = None
        self.custom_model_thread_stop_event: Any = None

        try:
            assert isinstance(self.models, dict)
            _raw_scenario_id = (
                scenario.scenario_id
                if isinstance(scenario, ScenarioSetResponse)
                else scenario
            )
            assert _raw_scenario_id is not None and not isinstance(
                _raw_scenario_id, Unset
            )
            scenario_id: Union[str, UUID] = _raw_scenario_id
            run_api_keys = self._validate_run_test_params(
                api_key, api_keys, test_run_type
            )

            model_data: dict = {"model_data": {}}
            nats_invoke_id = None
            submit_response: Optional[TestRunItem] = None
            if self._has_custom_model() and test_run_type == TestRunType.MULTI_TURN:
                # concat UUID to mut_id to make nats channel unique while maintaining like to mut
                # allows multiple clients with same target to run in parallel
                nats_invoke_id = f"{self.mut_id}_{str(uuid4())}"
                creds = internal_custom_model_listener_v0_internal_custom_model_listener_get.sync(
                    client=self.client,
                    api_key=self.api_key,
                    mut_id=str(self.mut_id),
                    nats_invoke_id=nats_invoke_id,
                )
                assert isinstance(creds, dict)
                nats_jwt = creds["jwt"]
                seed = creds["seed"]
                local_nats = creds["local_nats"]
                (
                    self.custom_model_thread,
                    self.custom_model_thread_stop_event,
                ) = self._internal_start_custom_model_thread(
                    nats_jwt, seed, local_nats, nats_invoke_id
                )
                self.custom_model_thread.start()
            elif self._has_custom_model():
                if run_test_method == submit_test_v0_test_run_submit_post.sync:
                    # call the 'run_test_method' to fetch the test_run_id first
                    submit_response = self._call_run_test_method(
                        run_test_method,
                        scenario_id,
                        name,
                        api_key,
                        api_keys,
                        run_api_keys,
                        metrics_kwargs,
                        test_run_type,
                        calculate_metrics,
                        model_data,
                        checks,
                        simulation_params,
                        driver_id,
                        None,
                    )
                    assert isinstance(submit_response, TestRunItem)
                    test_run_id = submit_response.id
                    # run _custom_exec + _evaluate_internal in a background thread
                    # if/when we make this method fully async, then we should use asyncio.create_task
                    # since this is sync, we use use threading.Thread (which does not require an event loop)
                    thread = threading.Thread(
                        target=self._run_custom_exec_then_evaluate,
                        args=(
                            scenario_id,
                            model_data,
                            test_run_id,
                            name,
                            test_run_type,
                            metrics_kwargs or UNSET,
                            checks or UNSET,
                        ),
                        name=f"submit-testrun-custommodel-{test_run_id}",
                        daemon=False,  # Important: don't use daemon thread to ensure task runs in background
                    )
                    thread.start()
                    # return the submit response immediately, allowing the user to access the test run ID
                    self.validate_response(submit_response)
                    assert isinstance(submit_response, TestRunItem)
                    return submit_response
                else:
                    # run the custom exec synchronously
                    self._custom_exec(scenario_id, model_data, None)

            response: TestRunItem = self._call_run_test_method(
                run_test_method,
                scenario_id,
                name,
                api_key,
                api_keys,
                run_api_keys,
                metrics_kwargs,
                test_run_type,
                calculate_metrics,
                model_data,
                checks,
                simulation_params,
                driver_id,
                nats_invoke_id,
            )

            return response
        except UnexpectedStatus as e:
            print(f"Unexpected status {e=}, {e.content=}")
            raise
        finally:
            self._internal_cleanup_custom_model(
                self.custom_model_thread_stop_event, self.custom_model_thread
            )

    def _call_run_test_method(
        self,
        run_test_method: Any,
        scenario_id: Union[str, UUID],
        name: str,
        api_key: Optional[str],
        api_keys: Optional[dict],
        run_api_keys: dict,
        metrics_kwargs: Optional[dict],
        test_run_type: TestRunType,
        calculate_metrics: bool,
        model_data: dict,
        checks: Optional[List[str]],
        simulation_params: Optional[Any],
        driver_id: Optional[str],
        nats_invoke_id: Optional[str],
    ) -> TestRunItem:
        response: TestRunItem = run_test_method(
            client=self.client,
            api_key=self.api_key,
            body=self._get_test_run_payload(
                scenario_id,
                name,
                api_key,
                api_keys,
                run_api_keys,
                metrics_kwargs,
                test_run_type,
                calculate_metrics,
                model_data,
                checks,
                simulation_params,
                driver_id,
                nats_invoke_id,
            ),
        )
        if isinstance(response, ErrorResponse):
            error_message = f"error: {response}, {response.detail}"
            print(error_message)
            raise TestRunError(str(response.detail))
        if not response:
            print("Empty response from API")
        assert response is not None
        return response

    def _run_custom_exec_then_evaluate(
        self,
        scenario_id: str,
        model_data: dict,
        test_run_id: str,
        name: str,
        test_run_type: TestRunType,
        metrics_kwargs: Union[dict, Unset] = UNSET,
        checks: Union[List[str], Unset] = UNSET,
    ) -> TestRunItem:
        """Run custom exec, then evaluate once complete"""
        self._custom_exec(scenario_id, model_data, test_run_id)
        # pull datapoint IDs from test_run_id
        print(
            f"Submitting evaluation for test_run_id {test_run_id} after custom model invocations."
        )
        response = self._evaluate_internal(
            self.client,
            self.api_key,
            name=name,
            test_run_type=test_run_type,
            scenario_id=scenario_id,
            metrics_kwargs=metrics_kwargs,
            test_run_id=test_run_id,
            checks=checks,
        )
        self.validate_response(response)
        assert isinstance(response, TestRunItem)
        return response

    def _check_multiturn_submit_safe(self, test_run_type: TestRunType) -> bool:
        """Check if the test_run_type is MULTI_TURN and if the model is a CustomMultiturnTarget.
        If so, return False to indicate that submit_test should not be used."""
        if (
            test_run_type == TestRunType.MULTI_TURN
            and self.models is not None
            and isinstance(self.models, dict)
            and "custom_target" in self.models
        ):
            return False
        return True

    def submit_test(
        self,
        scenario: Union[ScenarioSetResponse, str, UUID],
        name: str,
        api_key: Optional[str] = None,
        api_keys: Optional[dict] = None,
        metrics_kwargs: Optional[dict] = None,
        test_run_type: TestRunType = TestRunType.MULTI_CLASS_CLASSIFICATION,
        calculate_metrics: bool = True,
        checks: Optional[List[str]] = None,
        simulation_params: Optional[Any] = None,
        driver_id: Optional[str] = None,
    ) -> TestRunItem:
        """Asynchronous server-based version of test-run execution. For CustomModels, model
        invocations are handled client-side in a background thread then evaluated server-side asynchronously.
        For other models, model invocations and evaluation are both handled server-side asynchronously.

        Arguments:
            scenario (Union[ScenarioSetResponse, str]): The scenario set or identifier to use for the test run.
            name (str): The name to assign to the test run.
            api_key (Optional[str]): Optional API key for authentication.
            api_keys (Optional[dict]): Optional dictionary of API keys for different services.
            metrics_kwargs (Optional[dict]): Optional dictionary of keyword arguments for metrics calculation.
            test_run_type (TestRunType): The type of test run to execute. Defaults to MULTI_CLASS_CLASSIFICATION.
            calculate_metrics (bool): Whether to calculate metrics after the test run. Defaults to True.
            checks (Optional[List[str]]): Optional list of checks to perform during the test run.

        Returns:
            TestRunItem: The resulting test run item for the submitted test run. The `id` field can be used to retrieve the test run.
        """
        endpoint = submit_test_v0_test_run_submit_post.sync
        if not self._check_multiturn_submit_safe(test_run_type):
            print(
                "WARNING: CustomMultiturnTarget models are not supported in submit_test. "
                + "Falling back to run_test instead."
            )
            endpoint = run_test_v0_test_run_post.sync
        return self._run_test_internal(
            scenario,
            name,
            api_key,
            api_keys,
            metrics_kwargs,
            test_run_type,
            calculate_metrics,
            checks,
            endpoint,
            simulation_params,
            driver_id,
        )

    def run_test(
        self,
        scenario: Union[ScenarioSetResponse, str, UUID],
        name: str,
        api_key: Optional[str] = None,
        api_keys: Optional[dict] = None,
        metrics_kwargs: Optional[dict] = None,
        test_run_type: TestRunType = TestRunType.MULTI_CLASS_CLASSIFICATION,
        calculate_metrics: bool = True,
        checks: Optional[List[str]] = None,
        simulation_params: Optional[Any] = None,
        driver_id: Optional[str] = None,
    ) -> TestRunItem:
        """Server-based version of test-run execution. For CustomModels, model
        invocations are handled client-side then evaluated server-side. For other models,
        model invocations and evaluations handled server-side.

        Arguments:
            scenario (Union[ScenarioSetResponse, str]): The scenario set or identifier to use for the test run.
            name (str): The name to assign to the test run.
            api_key (Optional[str]): Optional API key for authentication.
            api_keys (Optional[dict]): Optional dictionary of API keys for different services.
            metrics_kwargs (Optional[dict]): Optional dictionary of keyword arguments for metrics calculation.
            test_run_type (TestRunType): The type of test run to execute. Defaults to MULTI_CLASS_CLASSIFICATION.
            calculate_metrics (bool): Whether to calculate metrics after the test run. Defaults to True.
            checks (Optional[List[str]]): Optional list of checks to perform during the test run.

        Returns:
            TestRunItem: The resulting test run item for the completed test run.
        """
        try:
            return self._run_test_internal(
                scenario,
                name,
                api_key,
                api_keys,
                metrics_kwargs,
                test_run_type,
                calculate_metrics,
                checks,
                run_test_v0_test_run_post.sync,
                simulation_params,
                driver_id,
            )
        except Exception as e:
            raise TestRunError(str(e)) from e

    def get_test_run(self, test_run_id: Union[str, UUID]) -> TestRunItem:
        """Retrieve a test run by its ID.

        Arguments:
            test_run_id (str): The ID of the test run to retrieve.

        Returns:
            TestRunItem: The test run item corresponding to the provided ID.
        """
        try:
            response = get_test_run_v0_test_runs_test_run_id_get.sync(
                client=self.client,
                api_key=self.api_key,
                test_run_id=(
                    UUID(test_run_id) if isinstance(test_run_id, str) else test_run_id
                ),
            )
            self.validate_response(response)
            assert isinstance(response, TestRunItem)

            return response
        except UnexpectedStatus as e:
            print(e.content)
            raise

    @classmethod
    def validate_response(cls, response: Any) -> None:
        if isinstance(response, ErrorResponse):
            error_message = f"error: {response}, {response.detail}"
            print(error_message)
            raise TypeError(error_message)
        if response is None:
            print("Received no response (None) from the API")
            raise ValueError("No response received")

    def _extract_input_from_scenario_data_point(
        self, scenario_data_point: ScenarioDataPoinResponse
    ) -> Any:
        """helper method to handle different scenario data point formats"""
        scenario_input = scenario_data_point.input_
        return scenario_input

    def _custom_exec(
        self, scenario_id: Any, model_data: Any, test_run_id: Optional[str] = None
    ) -> Any:
        assert isinstance(self.models, dict)

        assert scenario_id
        scenario_data_points = self._get_scenario_data_points(scenario_id)
        datapoint_len = len(scenario_data_points)

        if not self._has_custom_batch_model():
            custom_model_invoker = self.models["custom"]["model_invoker"]
            for scenario_data_point in tqdm(
                scenario_data_points, desc="Invoking CustomModel", unit="datapoint"
            ):
                scenario_input = self._extract_input_from_scenario_data_point(
                    scenario_data_point
                )

                try:
                    custom_model_return_value = custom_model_invoker(scenario_input)
                except Exception as e:
                    # Log the error but continue processing other datapoints
                    print(
                        f"An error occurred while invoking the custom model for scenario_data_point ID {scenario_data_point.id}: {str(e)}"
                    )
                    # Create a ModelInvocation with error details
                    custom_model_return_value = ModelInvocation(
                        model_prediction=None,
                        model_input=scenario_input,
                        tool_calls=None,
                        error={"error_message": str(e)},
                    )
                self._add_model_invocation_for_scenario(
                    custom_model_return_value,
                    model_data,
                    scenario_data_point.id,
                    test_run_id,
                )
        else:
            # batch inputs to the custom model
            custom_model_invoker = self.models["custom_batch"]["model_invoker"]
            batch_size = self.models["custom_batch"]["batch_size"]
            for index in tqdm(
                range(0, datapoint_len, batch_size),
                desc="Invoking CustomModel",
                unit="batch",
            ):
                end_index = min(index + batch_size, datapoint_len)
                scenario_data_points_batch = scenario_data_points[index:end_index]
                scenario_inputs = [
                    {
                        "id": str(sdp.id),
                        "input_value": self._extract_input_from_scenario_data_point(
                            sdp
                        ),
                    }
                    for sdp in scenario_data_points_batch
                ]
                custom_model_return_batch = custom_model_invoker(scenario_inputs)

                for return_dict in custom_model_return_batch:
                    self._add_model_invocation_for_scenario(
                        return_dict["model_invocation"],
                        model_data,
                        return_dict["id"],
                        test_run_id,
                    )

    @classmethod
    def _evaluate_internal(
        cls,
        client: Client,
        api_key: str,
        name: str,
        test_run_type: TestRunType,
        scenario_id: Union[Unset, str, UUID] = UNSET,
        datapoint_ids: Union[Unset, list[str], list[UUID]] = UNSET,
        filter_group_id: Union[Unset, str, UUID] = UNSET,
        tags: Union[Unset, list[str]] = UNSET,
        metrics_kwargs: Union[Dict[str, Any], Unset] = UNSET,
        checks: Union[Unset, list[str]] = UNSET,
        test_run_id: Union[Unset, str, UUID] = UNSET,
    ) -> TestRunItem:
        """Run an 'online' evaluation on already uploaded datapoints.
        Also used to handle 'submit_test' for CustomModel (requires a `test_run_id`$).
        """
        _scenario_id: Union[Unset, UUID, None] = (
            UNSET
            if isinstance(scenario_id, Unset)
            else UUID(scenario_id) if isinstance(scenario_id, str) else scenario_id
        )
        _datapoint_ids: Union[Unset, list[UUID], None] = (
            UNSET
            if isinstance(datapoint_ids, Unset)
            else [UUID(d) if isinstance(d, str) else d for d in datapoint_ids]
        )
        _filter_group_id: Union[Unset, UUID, None] = (
            UNSET
            if isinstance(filter_group_id, Unset)
            else (
                UUID(filter_group_id)
                if isinstance(filter_group_id, str)
                else filter_group_id
            )
        )
        _test_run_id: Union[Unset, UUID, None] = (
            UNSET
            if isinstance(test_run_id, Unset)
            else UUID(test_run_id) if isinstance(test_run_id, str) else test_run_id
        )
        payload = EvaluationPayload(
            metrics_kwargs=EvaluationPayloadMetricsKwargs.from_dict(
                metrics_kwargs or {}
            ),
            name=name,
            type_=test_run_type,
            tags=tags,
            checks=checks,
            scenario_id=_scenario_id,
            datapoint_ids=_datapoint_ids,
            filter_group_id=_filter_group_id,
            test_run_id=_test_run_id,
        )

        response = evaluate_v0_evaluate_post.sync(
            client=client,
            body=payload,
            api_key=api_key,
        )
        cls.validate_response(response)
        assert response is not None and not isinstance(response, ErrorResponse)
        return response


@_attrs_define
class ModelInvocation:
    """
    Model invocation response object returned from a CustomModel.invoke method
    or as an element of a list returned from a CustomBatchModel.invoke_batch method.

    Arguments:
        model_prediction: Prediction from the model to be used when running the evaluation,
            e.g. predicted class from classification model or generated text completion from
            a generative model. This would typically be parsed out of the overall model_output_metadata.
        model_input: All the input sent to the model.
        model_output_metadata: Full model response, including any metadata returned with model's output.
        tool_calls: List of tool calls made during the model invocation, if any.
    """

    model_prediction: Union[dict, list, str, None] = None
    model_input: Union[dict, list, str, None] = None
    model_output_metadata: Union[dict, list, str, None] = None
    tool_calls: Optional[List] = None
    error: Optional[dict] = None

    def params(self) -> dict:
        return {
            "actual": self.model_prediction,
            "model_input": self.model_input,
            "model_result": self.model_output_metadata,
            "tool_calls": self.tool_calls,
            "error": self.error,
        }


@define
class OpenAIModel(BaseModel):
    """
    An OpenAI model definition with prompt template and relevant parameters for an Okareo evaluation.

    Arguments:
        model_id: Model ID to request from OpenAI completion.
            For list of available models, see https://platform.openai.com/docs/models
        temperature: Parameter for controlling the randomness of the model's output.
        system_prompt_template: `System` role prompt template to pass to the model. Uses mustache syntax for variable substitution, e.g. `{scenario_input}`.
        user_prompt_template: `User` role prompt template to pass to the model. Uses mustache syntax for variable substitution, e.g. `{scenario_input}`
        dialog_template: Dialog template in OpenAI message format to pass to the model. Uses mustache syntax for variable substitution.
        tools: List of tools to pass to the model.
    """

    type = "openai"
    model_id: str = field(default="gpt-4o-mini")
    temperature: float = field(default=0)
    system_prompt_template: Optional[str] = None
    user_prompt_template: Optional[str] = None
    dialog_template: Optional[str] = None
    tools: Optional[List] = None

    def params(self) -> dict:
        return {
            "model_id": self.model_id,
            "temperature": self.temperature,
            "system_prompt_template": self.system_prompt_template,
            "user_prompt_template": self.user_prompt_template,
            "dialog_template": self.dialog_template,
            "type": self.type,
            "tools": self.tools,
        }


@define
class GenerationModel(BaseModel):
    """An LLM definition with prompt template and relevant parameters for an Okareo evaluation.

    Arguments:
        model_id: Model ID to request for LLM completion.
        temperature: Parameter for controlling the randomness of the model's output.
        system_prompt_template: `System` role prompt template to pass to the model. Uses mustache syntax for variable substitution, e.g. `{scenario_input}`.
        user_prompt_template: `User` role prompt template to pass to the model. Uses mustache syntax for variable substitution, e.g. `{scenario_input}`
        dialog_template: Dialog template in OpenAI message format to pass to the model. Uses mustache syntax for variable substitution.
        tools: List of tools to pass to the model.
    """

    type = "generation"
    model_id: str = field(default="gpt-4o-mini")
    temperature: float = field(default=0)
    system_prompt_template: Optional[str] = None
    user_prompt_template: Optional[str] = None
    dialog_template: Optional[str] = None
    tools: Optional[List] = None

    def params(self) -> dict:
        return {
            "model_id": self.model_id,
            "temperature": self.temperature,
            "system_prompt_template": self.system_prompt_template,
            "user_prompt_template": self.user_prompt_template,
            "dialog_template": self.dialog_template,
            "type": self.type,
            "tools": self.tools,
        }


@_attrs_define
class OpenAIAssistantModel(BaseModel):
    """An OpenAI Assistant definition with prompt template and relevant parameters for an Okareo evaluation.

    Arguments:
        model_id: Assistant ID to request to run a thread against.
        assistant_prompt_template: `System` role prompt template to pass to the model. Uses mustache syntax for variable substitution, e.g. `{scenario_input}`.
        user_prompt_template: `User` role prompt template to pass to the model. Uses mustache syntax for variable substitution, e.g. `{scenario_input}`
        dialog_template: Dialog template in OpenAI message format to pass to the model. Uses mustache syntax for variable substitution.
    """

    type = "openai_assistant"
    model_id: str
    assistant_prompt_template: Optional[str] = None
    user_prompt_template: Optional[str] = None
    dialog_template: Optional[str] = None

    def params(self) -> dict:
        return {
            "model_id": self.model_id,
            "assistant_prompt_template": self.assistant_prompt_template,
            "user_prompt_template": self.user_prompt_template,
            "dialog_template": self.dialog_template,
            "type": self.type,
        }


@_attrs_define
class CohereModel(BaseModel):
    """
    A Cohere model definition with prompt template and relevant parameters for an Okareo evaluation.

    Arguments:
        model_id: Model ID to request for the Cohere completion.
            For a full list of available models, see https://docs.cohere.com/v2/docs/models
        model_type: Type of application for the Cohere model. Currently, we support 'classify' and 'embed'.
        input_type: Input type for the Cohere embedding model.
            For more details, see https://docs.cohere.com/v2/docs/embeddings#the-input_type-parameter
    """

    type = "cohere"
    model_id: str
    model_type: str
    input_type: Optional[str] = None

    def params(self) -> dict:
        return {
            "model_id": self.model_id,
            "model_type": self.model_type,
            "input_type": self.input_type,
        }


@_attrs_define
class PineconeDb(BaseModel):
    """
    A Pinecone vector database configuration for use in an Okareo retrieval evaluation.

    Arguments:
        index_name: The name of the Pinecone index to connect to.
        region: The region where the Pinecone index is hosted.
        project_id: The project identifier associated with the Pinecone index.
        top_k: The number of top results to retrieve for queries. Defaults to 5.
    """

    type = "pinecone"
    index_name: str
    region: str
    project_id: str
    top_k: int = 5

    def params(self) -> dict:
        return {
            "index_name": self.index_name,
            "region": self.region,
            "project_id": self.project_id,
            "top_k": self.top_k,
        }


@_attrs_define
class QdrantDB(BaseModel):
    """
    A Qdrant vector database configuration for use in an Okareo retrieval evaluation.

    Arguments:
        collection_name: The name of the Qdrant collection to connect to.
        url: The URL of the Qdrant instance.
        top_k: The number of top results to retrieve for queries. Defaults to 5.
        sparse: Whether to use sparse vectors for the Qdrant collection. Defaults to False.
    """

    type = "qdrant"
    collection_name: str
    url: str
    top_k: int = 5
    sparse: bool = False

    def params(self) -> dict:
        return {
            "collection_name": self.collection_name,
            "url": self.url,
            "top_k": self.top_k,
            "sparse": self.sparse,
        }


@_attrs_define
class CustomModel(BaseModel):
    """A custom model definition for an Okareo evaluation.
    Requires a valid `invoke` definition that operates on a single input.

    Arguments:
        name: A name for the custom model.
    """

    type = "custom"
    name: str

    @abstractmethod
    def invoke(
        self, input_value: Union[dict, list, str]
    ) -> Union[ModelInvocation, Any]:
        """Method for taking a single scenario input and returning a single model output

        Arguments:
            input_value: Union[dict, list, str] - input to the model.

        Returns:
            Union[ModelInvocation, Any] - model output.
            If the model returns a ModelInvocation, it should contain the model's prediction, input, and metadata.
            If the model returns a tuple, the first element should be the model's prediction and the second element should be the metadata.
        """

    def params(self) -> dict:
        return {
            "name": self.name,
            "type": self.type,
            "model_invoker": self.invoke,
        }


@_attrs_define
class CustomMultiturnTarget(BaseModel):
    """A custom model definition for an Okareo multiturn evaluation.
    Requires a valid `invoke` definition that operates on a single turn of a converstation.
    """

    type = "custom_target"
    name: str

    def start_session(
        self, scenario_input: str | None = None
    ) -> tuple[str | None, ModelInvocation | None]:
        """Method for starting a multiturn conversation with a custom model

        Returns:
            - str | None: session_id - the ID of the session started by the model.
            - ModelInvocation | None: model output - the model's response to the session start, if any.
        """
        return None, None

    def end_session(self, session_id: str) -> None:
        """Method for ending a multiturn conversation with a custom model

        Arguments:
            session_id: str - the ID of the session to end.
        """

    @abstractmethod
    def invoke(
        self,
        messages: List[dict[str, str]],
        scenario_input: Optional[Union[dict, list, str]] = None,
        session_id: Optional[str] = None,
    ) -> Union[ModelInvocation, Any]:
        """Method for continuing a multiturn conversation with a custom model

        Arguments:
            messages: list - list of messages in the conversation
            scenario_input: Optional[dict | list | str] - scenario input for the conversation

        Returns:
            Union[ModelInvocation, Any] - model output.
            If the model returns a ModelInvocation, it should contain the model's prediction, input, and metadata.
            If the model returns a tuple, the first element should be the model's prediction and the second element should be the metadata.
        """

    def params(self) -> dict:
        return {
            "name": self.name,
            "type": self.type,
            "model_invoker": self.invoke,
            "session_starter": self.start_session,
            "session_ender": self.end_session,
        }


@_attrs_define
class CustomMultiturnTargetAsync(BaseModel):
    """A custom model definition for an Okareo multiturn evaluation that uses asynchronous methods.
    Requires a valid `invoke` definition that operates on a single turn of a converstation.
    """

    type = "custom_target_async"
    name: str

    async def start_session(
        self, scenario_input: str | None = None
    ) -> tuple[str | None, ModelInvocation | None]:
        """Method for starting a multiturn conversation with a custom model

        Returns:
            - str | None: session_id - the ID of the session started by the model.
            - ModelInvocation | None: model output - the model's response to the session start, if any.
        """
        return None, None

    async def end_session(self, session_id: str) -> None:
        """Method for ending a multiturn conversation with a custom model

        Arguments:
            session_id: str - the ID of the session to end.
        """

    @abstractmethod
    async def invoke(
        self,
        messages: List[dict[str, str]],
        scenario_input: Optional[Union[dict, list, str]] = None,
        session_id: Optional[str] = None,
    ) -> Awaitable[Union[ModelInvocation, Any]]:
        """Method for continuing a multiturn conversation with a custom model

        Arguments:
            messages: list - list of messages in the conversation
            scenario_input: Optional[dict | list | str] - scenario input for the conversation

        Returns:
            Union[ModelInvocation, Any] - model output.
            If the model returns a ModelInvocation, it should contain the model's prediction, input, and metadata.
            If the model returns a tuple, the first element should be the model's prediction and the second element should be the metadata.
        """

    def params(self) -> dict:
        return {
            "name": self.name,
            "type": self.type,
            "model_invoker": self.invoke,
            "session_starter": self.start_session,
            "session_ender": self.end_session,
        }


class VoiceTarget(BaseModel):
    """
    Base class for realtime voice targets in Okareo multiturn evaluation.

    This target runs server-side during multiturn evaluations and follows the
    same API key pattern as other targets: API keys are passed via the
    `api_keys` parameter in `run_simulation()`.
    """

    type = "voice"
    edge_type: str

    @abstractmethod
    def params(self) -> dict:
        pass

    def get_sensitive_fields(self) -> list[str]:
        return []


@_attrs_define
class OpenAIVoiceTarget(VoiceTarget):
    """
    OpenAI Realtime API voice target for Okareo multiturn evaluation.

    Arguments:
        model: Model ID for OpenAI Realtime. Default: "gpt-realtime".
        instructions: System instructions for the voice agent. Default: "Be brief and helpful."
        output_voice: Voice ID for TTS output. Options: "alloy", "echo", "fable", "onyx", "nova", "shimmer".
    """

    edge_type = "openai"
    model: str = field(default="gpt-realtime")
    instructions: str = field(default="Be brief and helpful.")
    output_voice: str = field(default="alloy")

    def params(self) -> dict:
        return {
            "type": self.type,
            "edge_type": self.edge_type,
            "model": self.model,
            "instructions": self.instructions,
            "output_voice": self.output_voice,
        }


@_attrs_define
class DeepgramVoiceTarget(VoiceTarget):
    """
    Deepgram voice target for Okareo multiturn evaluation.

    Arguments:
        model: Model ID for Deepgram. Default: "aura-2".
        instructions: System instructions for the voice agent. Default: "Be brief and helpful."
        output_voice: Voice ID for TTS output. Example: "aura-2-thalia-en".
    """

    edge_type = "deepgram"
    model: str = field(default="aura-2")
    instructions: str = field(default="Be brief and helpful.")
    output_voice: str = field(default="aura-2-thalia-en")

    def params(self) -> dict:
        return {
            "type": self.type,
            "edge_type": self.edge_type,
            "model": self.model,
            "instructions": self.instructions,
            "output_voice": self.output_voice,
        }


@_attrs_define
class TwilioVoiceTarget(VoiceTarget):
    """
    Twilio voice target for Okareo multiturn evaluation.

    Arguments:
        account_sid: Twilio account SID for authentication.
        auth_token: Twilio authentication token.
        from_phone_number: Phone number to call from (Twilio number).
        to_phone_number: Phone number to call to (destination number).
        max_parallel_requests: Maximum number of parallel requests the target can handle.
    """

    edge_type = "twilio"
    account_sid: str = field(default="")
    auth_token: str = field(default="")
    from_phone_number: Optional[str] = None
    to_phone_number: Optional[str] = None
    max_parallel_requests: Optional[int] = None

    def params(self) -> dict:
        return {
            "type": self.type,
            "edge_type": self.edge_type,
            "account_sid": self.account_sid,
            "auth_token": self.auth_token,
            "from_phone_number": self.from_phone_number,
            "to_phone_number": self.to_phone_number,
            "max_parallel_requests": self.max_parallel_requests,
        }

    def get_sensitive_fields(self) -> list[str]:
        return ["auth_token"] if self.auth_token else []


@define
class StopConfig:
    """
    Configuration for stopping a multiturn conversation based on a specific check.

    Arguments:
        check_name: Name of the check to use for stopping the conversation.
        stop_on: The check condition to stop the conversation.
            Defaults to `True` (i.e., conversation stops when check evaluates to `True`).
    """

    check_name: str
    stop_on: bool = field(default=True)

    def params(self) -> dict:
        return {"check_name": self.check_name, "stop_on": self.stop_on}


class StreamingStopCondition:
    """A condition that terminates the stream when matched.

    Stop conditions use OR semantics — any single match ends the stream.

    Arguments:
        value: The value to match. Supports:
            - ``"true"`` / ``"false"`` (case-insensitive) for JSON booleans
            - ``"*"`` for presence check (any non-None value)
            - Any other string for exact string comparison
        path: Optional ``response.``-prefixed dot-bracket path into each
            parsed JSON chunk. E.g., ``response.is_finished``.
            When omitted, ``value`` is matched as a raw string against the
            SSE ``data:`` payload before JSON parsing (e.g., ``"[DONE]"``).
    """

    def __init__(self, value: str, path: Optional[str] = None) -> None:
        self.value = value
        self.path = path

    def to_dict(self) -> dict:
        d: dict = {"value": self.value}
        if self.path is not None:
            d["path"] = self.path
        return d


class StreamingSelectCondition:
    """A condition that filters which chunks have their content extracted.

    Select conditions use AND semantics — all conditions must match for a
    chunk's content to be extracted.

    Arguments:
        path: Required ``response.``-prefixed dot-bracket path into each
            parsed JSON chunk. E.g., ``response.role``.
        value: The value to match at that path. Same matching rules as
            :class:`StreamingStopCondition`: ``"true"``/``"false"`` for booleans,
            ``"*"`` for presence, anything else for exact string comparison.
    """

    def __init__(self, path: str, value: str) -> None:
        self.path = path
        self.value = value

    def to_dict(self) -> dict:
        return {"path": self.path, "value": self.value}


class StreamingConfig:
    """Configuration for streaming responses from a custom API endpoint.

    When provided on a TurnConfig or SessionConfig, the server will consume the
    endpoint's response as a Server-Sent Events (SSE) or NDJSON stream and
    reassemble the tokens into the final response.

    The text extraction path is specified via ``response_message_path`` on the
    parent TurnConfig/SessionConfig — set it to the chunk shape when streaming
    (e.g., ``response.choices[0].delta.content``).

    Arguments:
        stop: List of :class:`StreamingStopCondition` objects. The stream terminates
            when **any** condition matches (OR semantics). A stop condition
            without a ``path`` matches as a raw string against the SSE
            ``data:`` payload before JSON parsing (e.g., ``[DONE]``).
        select: List of :class:`StreamingSelectCondition` objects. **All** conditions
            must match for a chunk's content to be extracted (AND semantics).
            When omitted or empty, content is extracted from every chunk.
    """

    def __init__(
        self,
        stop: Optional[list] = None,
        select: Optional[list] = None,
    ) -> None:
        self.stop = stop
        self.select = select

    def to_dict(self) -> dict:
        d: dict = {}
        if self.stop:
            d["stop"] = [c.to_dict() for c in self.stop]
        if self.select:
            d["select"] = [c.to_dict() for c in self.select]
        return d


class SessionConfig:
    """Configuration for a custom API endpoint that starts a session.

    Arguments:
        url: URL of the endpoint to start the session.
        method: HTTP method to use for the request. Defaults to `POST`.
        headers: Headers to include in the request. Defaults to an empty JSON object.
        body: Body to include in the request. Defaults to an empty JSON object.
        status_code: Expected HTTP status code of the response.
        response_session_id_path: Path to extract the session ID from the response.
            E.g., `response.id` will use the `id` field of the response JSON object to set the `session_id`.
    """

    def __init__(
        self,
        url: str,
        method: str = "POST",
        headers: Optional[Union[str, dict]] = None,
        body: Union[str, dict] = "{}",
        status_code: Optional[int] = None,
        response_session_id_path: str = "",
        response_message_path: str = "",
        streaming: Optional[StreamingConfig] = None,
    ) -> None:
        self.url = url
        self.method = method
        self.headers = headers or json.dumps({})
        self.body = body
        self.status_code = status_code
        self.response_session_id_path = response_session_id_path
        self.response_message_path = response_message_path
        self.streaming = streaming

    def to_dict(self) -> dict:
        d = {
            "url": self.url,
            "method": self.method,
            "headers": self.headers,
            "body": self.body,
            "status_code": self.status_code,
            "response_session_id_path": self.response_session_id_path,
            "response_message_path": self.response_message_path,
        }
        if self.streaming is not None:
            d["streaming"] = self.streaming.to_dict()
        return d


class TurnConfig:
    """
    Configuration for a custom API endpoint that continues a session/conversation by one turn.

    Arguments:
        url: URL of the endpoint to start the session.
        method: HTTP method to use for the request. Defaults to `POST`.
        headers: Headers to include in the request.
            Supports mustache syntax for variable substitution for `{latest_message}`, `{message_history}`, `{session_id}`.
            Defaults to an empty JSON object.
        body: Body to include in the request.
            Supports mustache syntax for variable substitution for `{latest_message}`, `{message_history}`, `{session_id}`.
            Defaults to an empty JSON object.
        status_code: Expected HTTP status code of the response.
        response_message_path: Path to extract the model's generated message from the response.
            E.g., `response.completion.message.content` will parse out the corresponding field of
            the response JSON object as the model's generated response.
        response_session_id_path: Path to extract the session ID from the response.
            E.g., `response.result.contextId` will use the `contextId` field of the response
            JSON object to set the `session_id` for subsequent turns.
        response_tool_calls_path: Path to extract tool calls from the response.
    """

    def __init__(
        self,
        url: str,
        method: str = "POST",
        headers: Optional[Union[str, dict]] = None,
        body: Union[str, dict] = "{}",
        status_code: Optional[int] = None,
        response_message_path: str = "",
        response_session_id_path: str = "",
        response_tool_calls_path: str = "",
        streaming: Optional[StreamingConfig] = None,
    ) -> None:
        self.url = url
        self.method = method
        self.headers = headers or json.dumps({})
        self.body = body
        self.status_code = status_code
        self.response_message_path = response_message_path
        self.response_session_id_path = response_session_id_path
        self.response_tool_calls_path = (
            response_tool_calls_path  # TODO: populate this once we support on BE
        )
        self.streaming = streaming

    def to_dict(self) -> dict:
        d = {
            "url": self.url,
            "method": self.method,
            "headers": self.headers,
            "body": self.body,
            "status_code": self.status_code,
            "response_message_path": self.response_message_path,
            "response_session_id_path": self.response_session_id_path,
            "response_tool_calls_path": self.response_tool_calls_path,
        }
        if self.streaming is not None:
            d["streaming"] = self.streaming.to_dict()
        return d


class EndSessionConfig:
    """Configuration for a custom API endpoint that ends a session.

    Arguments:
        url: URL of the endpoint to start the session.
        method: HTTP method to use for the request. Defaults to `POST`.
        headers: Headers to include in the request. Defaults to an empty JSON object.
        body: Body to include in the request. Defaults to an empty JSON object.
        status_code: Expected HTTP status code of the response.
        response_session_id_path: Path to extract the session ID from the response.
    """

    def __init__(
        self,
        url: str,
        method: str = "POST",
        headers: Optional[Union[str, dict]] = None,
        body: Union[str, dict] = "{}",
        status_code: Optional[int] = None,
        response_session_id_path: str = "",
    ) -> None:
        self.url = url
        self.method = method
        self.headers = headers or json.dumps({})
        self.body = body
        self.status_code = status_code
        self.response_session_id_path = response_session_id_path

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "method": self.method,
            "headers": self.headers,
            "body": self.body,
            "status_code": self.status_code,
        }


class AuthConfig:
    """Configuration for a custom API endpoint that authenticates a session.

    Arguments:
        url: URL of the endpoint to authenticate.
        method: HTTP method to use for the request. Defaults to `POST`.
        headers: Headers to include in the request. Defaults to an empty JSON object.
        body: Body to include in the request. Defaults to an empty JSON object.
        status_code: Expected HTTP status code of the response.
        response_access_token_path: Path to extract the access token from the response.
    """

    def __init__(
        self,
        url: str,
        method: str = "POST",
        headers: Optional[Union[str, dict]] = None,
        body: Union[str, dict] = "{}",
        status_code: Optional[int] = None,
        response_access_token_path: str = "",
    ) -> None:
        self.url = url
        self.method = method
        self.headers = headers or json.dumps({})
        self.body = body
        self.status_code = status_code
        self.response_access_token_path = response_access_token_path

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "method": self.method,
            "headers": self.headers,
            "body": self.body,
            "status_code": self.status_code,
            "response_access_token_path": self.response_access_token_path,
        }


class CustomEndpointTarget(BaseModel):
    """
    A trio of custom API endpoints for starting a session and continuing a conversation to use in
    Okareo multiturn evaluation.

    Arguments:
        start_session: A valid SessionConfig for starting a session.
        next_turn: A valid TurnConfig for requesting and parsing the next turn of a conversation.
        end_session: A valid EndSessionConfig for ending a session.
        auth: A valid AuthConfig for authenticating a session.
        max_parallel_requests: Maximum number of parallel requests to allow when running the evaluation.
    """

    type = "custom_endpoint"

    def __init__(
        self,
        start_session: Optional[SessionConfig],
        next_turn: TurnConfig,
        end_session: Optional[EndSessionConfig] = None,
        auth: Optional[AuthConfig] = None,
        max_parallel_requests: Optional[int] = None,
    ) -> None:
        self.start_session = start_session
        self.next_turn = next_turn
        self.end_session = end_session
        self.auth = auth
        self.max_parallel_requests = max_parallel_requests

    def params(self) -> dict:
        result = {
            "type": self.type,
            "start_session_params": (
                self.start_session.to_dict() if self.start_session is not None else None
            ),
            "next_message_params": self.next_turn.to_dict(),
            "end_session_params": (
                self.end_session.to_dict() if self.end_session is not None else None
            ),
            "max_parallel_requests": self.max_parallel_requests,
        }
        if self.auth is not None:
            result["auth_params"] = self.auth.to_dict()
        return result


@_attrs_define
class Driver:
    name: str
    prompt_template: str = "{scenario_input}"
    model_id: Optional[str] = None
    temperature: Optional[float] = 0.6
    id: Optional[Union[str, UUID]] = None
    time_created: Optional[str] = datetime.now().isoformat()
    project_id: Optional[Union[str, UUID]] = None
    voice_instructions: Optional[str] = None
    voice_profile: Optional[str] = None
    voice: Optional[str] = None

    def to_dict(self) -> dict:
        d: dict = {
            "name": self.name,
            "temperature": self.temperature,
            "model_id": self.model_id,
            "prompt_template": self.prompt_template,
            "time_created": self.time_created,
            "voice_instructions": self.voice_instructions,
            "voice_profile": self.voice_profile,
            "voice": self.voice,
        }
        if self.id is not None:
            d["id"] = str(self.id)
        return d

    def _get_driver_fields(
        self, response: Union[DriverModelResponse, VoiceDriverModelResponse]
    ) -> None:
        self.id = response.id
        if response.prompt_template:
            self.prompt_template = response.prompt_template
        if response.model_id:
            self.model_id = response.model_id
        if response.temperature:
            self.temperature = response.temperature
        if response.time_created:
            self.time_created = response.time_created
        if response.project_id:
            self.project_id = response.project_id

    def _get_voice_driver_fields(self, response: VoiceDriverModelResponse) -> None:
        if response.voice_instructions:
            self.voice_instructions = response.voice_instructions
        if response.voice:
            self.voice = response.voice

    @classmethod
    def from_response(
        cls, response: Union[DriverModelResponse, VoiceDriverModelResponse]
    ) -> "Driver":
        inst = cls(response.name)
        inst._get_driver_fields(response)
        if isinstance(response, VoiceDriverModelResponse):
            inst._get_voice_driver_fields(response)
        return inst


@_attrs_define
class Target:
    name: str
    target: Union[
        OpenAIModel,
        CustomMultiturnTarget,
        GenerationModel,
        CustomEndpointTarget,
        CustomMultiturnTargetAsync,
        OpenAIVoiceTarget,
        DeepgramVoiceTarget,
        TwilioVoiceTarget,
        dict,
    ]
    id: Optional[str] = None

    def to_dict(self) -> dict:
        target_payload = (
            self.target if isinstance(self.target, dict) else self.target.params()
        )
        out: dict = {"name": self.name, "target": target_payload, "id": self.id}

        # Promote any declared sensitive fields to top-level
        if not isinstance(self.target, dict):
            sensitive = self.target.get_sensitive_fields()
            if sensitive:
                out["sensitive_fields"] = sensitive
        return out

    @classmethod
    def from_response(
        cls,
        response: ModelUnderTestResponse | TargetModelResponse,
        target_data: Optional[dict] = None,
    ) -> "Target":
        target: dict | None = None
        if isinstance(response, ModelUnderTestResponse):
            assert (
                target_data is not None
            ), "Target constructed from ModelUnderTestResponse must have target_data"
            target = target_data
        if isinstance(response, TargetModelResponse):
            target = response.target.to_dict()
        assert target is not None
        inst = cls(response.name, target)
        if response.id:
            inst.id = str(response.id)
        return inst


@_attrs_define
class Simulation:
    stop_check: Union[StopConfig, dict, None] = None
    repeats: Optional[int] = 1
    max_turns: Optional[int] = 5
    first_turn: Optional[str] = "target"
    checks_at_every_turn: Optional[bool] = False
    concurrent_ask_probability: Optional[float] = 0.0
    turn_transition_time: Optional[int] = 1000

    def __attrs_post_init__(self) -> None:
        if isinstance(self.stop_check, dict):
            self.stop_check = StopConfig(**self.stop_check)

    def to_dict(self) -> dict:
        return {
            "repeats": self.repeats,
            "max_turns": self.max_turns,
            "first_turn": self.first_turn,
            "stop_check": (
                self.stop_check.params()
                if isinstance(self.stop_check, StopConfig)
                else self.stop_check
            ),
            "checks_at_every_turn": self.checks_at_every_turn,
            "concurrent_ask_probability": self.concurrent_ask_probability,
            "turn_transition_time": self.turn_transition_time,
        }


@_attrs_define
class MultiTurnDriver(BaseModel):
    """
    A driver model for Okareo multiturn evaluation.

    Arguments:
        target: Target model under test to use in the multiturn evaluation.
        stop_check: A valid StopConfig or a dict that can be converted to StopConfig.
        driver_model_id: Model ID to use for the driver model (e.g., "gpt-4.1").
        driver_temperature: Parameter for controlling the randomness of the driver model's output.
        repeats: Number of times to run a conversation per scenario row. Defaults to 1.
        max_turns: Maximum number of turns to run in a conversation. Defaults to 5.
        first_turn: Name of model (i.e., "target" or "driver") that should initiate each conversation. Defaults to "target".
        driver_prompt_template: Optional system prompt template to pass to the driver model.
            Uses mustache syntax for variable substitution, e.g. `{input}`.
    """

    type = "driver"
    target: Union[
        OpenAIModel,
        CustomMultiturnTarget,
        CustomMultiturnTargetAsync,
        GenerationModel,
        CustomEndpointTarget,
        OpenAIVoiceTarget,
        DeepgramVoiceTarget,
        TwilioVoiceTarget,
    ]
    stop_check: Union[StopConfig, dict, None] = None
    driver_model_id: Optional[str] = None
    driver_temperature: Optional[float] = 0.8
    repeats: Optional[int] = 1
    max_turns: Optional[int] = 5
    first_turn: Optional[str] = "target"
    driver_prompt_template: Optional[str] = None
    checks_at_every_turn: Optional[bool] = False

    def __attrs_post_init__(self) -> None:
        if isinstance(self.stop_check, dict):
            self.stop_check = StopConfig(**self.stop_check)

    def params(self) -> dict:
        target_params = self.target.params()
        deprecated_params = {
            "deprecated_params": {
                "driver_model_id": self.driver_model_id,
                "driver_temperature": self.driver_temperature,
                "driver_prompt_template": self.driver_prompt_template,
                "repeats": self.repeats,
                "max_turns": self.max_turns,
                "first_turn": self.first_turn,
                "stop_check": (
                    self.stop_check.params()
                    if isinstance(self.stop_check, StopConfig)
                    else self.stop_check
                ),
                "checks_at_every_turn": self.checks_at_every_turn,
            }
        }
        # add deprecated params to target
        return {**target_params, **deprecated_params}


@_attrs_define
class CustomBatchModel(BaseModel):
    """A custom batch model definition for an Okareo evaluation.
    Requires a valid `invoke_batch` definition that operates on a single input.
    """

    type = "custom_batch"
    name: str
    batch_size: int = 1

    @abstractmethod
    def invoke_batch(
        self, input_batch: list[dict[str, Union[dict, list, str]]]
    ) -> list[dict[str, Union[ModelInvocation, Any]]]:
        """Method for taking a batch of scenario inputs and returning a corresponding batch of model outputs

        Arguments:
            input_batch: list[dict[str, Union[dict, list, str]]] - batch of inputs to the model. Expects a list of
            dicts of the format `{ 'id': str, 'input_value': Union[dict, list, str] }`.

        Returns:
            List of dicts of format `{ 'id': str, 'model_invocation': Union[ModelInvocation, Any] }`. 'id' must match
            the corresponding input_batch element's 'id'.
        """

    def params(self) -> dict:
        return {
            "name": self.name,
            "type": self.type,
            "batch_size": self.batch_size,
            "model_invoker": self.invoke_batch,
        }
