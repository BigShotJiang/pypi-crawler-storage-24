import os
import uuid
from datetime import datetime
from typing import Optional
from unittest.mock import Mock

import pytest
from okareo_tests.common import API_KEY, OkareoAPIhost, integration, random_string
from pytest_httpx import HTTPXMock

from okareo import ModelUnderTest, Okareo
from okareo.error import TestRunError
from okareo.model_under_test import (
    AuthConfig,
    CohereModel,
    CustomEndpointTarget,
    EndSessionConfig,
    OpenAIModel,
    OpenAIVoiceTarget,
    PineconeDb,
    SessionConfig,
    Target,
    TurnConfig,
    TwilioVoiceTarget,
)
from okareo_api_client.models import SeedData
from okareo_api_client.models.scenario_set_create import ScenarioSetCreate
from okareo_api_client.models.test_run_type import TestRunType

MOCK_UUID = "0156f5d7-4ac4-4568-9d44-24750aa08d1a"
MOCK_UUID_2 = "1256f5d7-4ac4-4568-9d44-24750aa08d1a"

GLOBAL_PROJECT_RESPONSE = [
    {
        "id": MOCK_UUID,
        "name": "Global",
        "onboarding_status": "onboarding_status",
        "tags": [],
        "additional_properties": {},
    }
]


def helper_register_model(httpx_mock: HTTPXMock) -> ModelUnderTest:
    httpx_mock.add_response(
        json=GLOBAL_PROJECT_RESPONSE,
        status_code=201,
    )
    fixture = get_mut_fixture("NotebookModel")
    httpx_mock.add_response(status_code=201, json=fixture)
    okareo = Okareo("api-key", "http://mocked.com")
    return okareo.register_model(name="NotebookModel", tags=["ci-testing"])


def get_mut_fixture(name: Optional[str] = None) -> dict:
    rnd_str = random_string(5)
    return {
        "id": MOCK_UUID,
        "project_id": MOCK_UUID,
        "version": 1,
        "name": name if name else f"CI-Test-Model-{rnd_str}",
        "tags": ["ci-testing"],
        "time_created": "foo",
    }


@integration
def test_register_model(httpx_mock: HTTPXMock, okareo_api: OkareoAPIhost) -> None:
    fixture = get_mut_fixture()
    if okareo_api.is_mock:
        httpx_mock.add_response(
            json=GLOBAL_PROJECT_RESPONSE,
            status_code=201,
        )
        httpx_mock.add_response(status_code=201, json=fixture)

    okareo = Okareo(api_key=API_KEY, base_path=okareo_api.path)
    mut = okareo.register_model(name=fixture["name"], tags=fixture["tags"])
    assert mut.name == fixture["name"]


@integration
def test_add_datapoint_optional_integration(
    httpx_mock: HTTPXMock, okareo_api: OkareoAPIhost
) -> None:
    fixture = get_mut_fixture()
    if okareo_api.is_mock:
        httpx_mock.add_response(
            json=GLOBAL_PROJECT_RESPONSE,
            status_code=201,
        )
        httpx_mock.add_response(status_code=201, json=fixture)

    okareo = Okareo(api_key=API_KEY, base_path=okareo_api.path)
    mut = okareo.register_model(name=fixture["name"], tags=fixture["tags"])
    dp = mut.add_data_point(
        feedback=0,
        context_token="SOME_CONTEXT_TOKEN",
    )
    assert dp


@integration
def test_mut_test_run(httpx_mock: HTTPXMock, okareo_api: OkareoAPIhost) -> None:
    mut_fixture = get_mut_fixture()

    if okareo_api.is_mock:
        httpx_mock.add_response(
            json=GLOBAL_PROJECT_RESPONSE,
            status_code=201,
        )
        httpx_mock.add_response(
            status_code=201,
            json={
                "scenario_id": MOCK_UUID,
                "project_id": MOCK_UUID,
                "time_created": str(datetime.now()),
                "type": "REPHRASE_INVARIANT",
            },
        )
        httpx_mock.add_response(status_code=201, json=mut_fixture)
        httpx_mock.add_response(
            status_code=201,
            json={
                "id": MOCK_UUID_2,
                "name": "CI run test",
                "input": "",
                "result": "",
                "project_id": MOCK_UUID,
                "mut_id": MOCK_UUID,
                "scenario_set_id": MOCK_UUID,
            },
        )

    okareo = Okareo(api_key=API_KEY, base_path=okareo_api.path)

    # generate scenario and return results in one call
    scenario_set_create = ScenarioSetCreate(
        name=f"my test scenario set {random_string(10)}",
        seed_data=[
            SeedData(input_="example question or statement", result="example result")
        ],
    )
    response = okareo.create_scenario_set(scenario_set_create)
    response.scenario_id

    mut = okareo.register_model(
        name=mut_fixture["name"],
        tags=mut_fixture["tags"],
        model=OpenAIModel(
            model_id="gpt-4o-mini",
            temperature=1,
            system_prompt_template="system_prompt_template",
        ),
    )

    # use the scenario id from one of the scenario set notebook examples
    test_run_item = mut.run_test(
        scenario=response, name="CI run test", api_key=os.environ["OPENAI_API_KEY"]
    )
    assert test_run_item.name == "CI run test"


@integration
def test_mut_test_run_with_id(httpx_mock: HTTPXMock, okareo_api: OkareoAPIhost) -> None:
    mut_fixture = get_mut_fixture()

    if okareo_api.is_mock:
        httpx_mock.add_response(
            json=GLOBAL_PROJECT_RESPONSE,
            status_code=201,
        )

        httpx_mock.add_response(
            status_code=201,
            json={
                "scenario_id": MOCK_UUID,
                "project_id": MOCK_UUID,
                "time_created": str(datetime.now()),
                "type": "REPHRASE_INVARIANT",
            },
        )

        httpx_mock.add_response(status_code=201, json=mut_fixture)
        httpx_mock.add_response(
            status_code=201,
            json={
                "id": MOCK_UUID_2,
                "name": "CI run test",
                "input": "",
                "result": "",
                "project_id": MOCK_UUID,
                "mut_id": MOCK_UUID,
                "scenario_set_id": MOCK_UUID,
            },
        )

    okareo = Okareo(api_key=API_KEY, base_path=okareo_api.path)
    # generate scenario and return results in one call
    scenario_set_create = ScenarioSetCreate(
        name=f"my test scenario set {random_string(10)}",
        seed_data=[
            SeedData(input_="example question or statement", result="example result")
        ],
    )
    response = okareo.create_scenario_set(scenario_set_create)

    mut = okareo.register_model(
        name=mut_fixture["name"],
        tags=mut_fixture["tags"],
        model=OpenAIModel(
            model_id="gpt-4o-mini",
            temperature=1,
            system_prompt_template="system_prompt_template",
        ),
    )

    # use the scenario id from one of the scenario set notebook examples
    assert isinstance(response.scenario_id, uuid.UUID)
    test_run_item = mut.run_test(
        scenario=response.scenario_id,
        name="CI run test",
        api_key=os.environ["OPENAI_API_KEY"],
    )
    assert test_run_item.name == "CI run test"


def test_add_datapoint(httpx_mock: HTTPXMock) -> None:
    registered_model = helper_register_model(httpx_mock)
    fixture = {"id": MOCK_UUID, "project_id": MOCK_UUID, "mut_id": MOCK_UUID}

    httpx_mock.add_response(status_code=201, json=fixture)
    dp = registered_model.add_data_point(
        input_obj={"input": "value"},
        result_obj={"result": "value"},
        feedback=0,
        context_token="SOME_CONTEXT_TOKEN",
        input_datetime=str(datetime.now()),
        result_datetime=str(datetime.now()),
        tags=["ci-testing"],
    )
    assert dp


def test_add_datapoint_only_context_and_feedback(httpx_mock: HTTPXMock) -> None:
    registered_model = helper_register_model(httpx_mock)
    fixture = {"id": MOCK_UUID, "project_id": MOCK_UUID, "mut_id": MOCK_UUID}
    httpx_mock.add_response(status_code=201, json=fixture)
    dp = registered_model.add_data_point(
        feedback=0,
        context_token="SOME_CONTEXT_TOKEN",
    )
    assert dp


def test_get_test_run(httpx_mock: HTTPXMock) -> None:
    registered_model = helper_register_model(httpx_mock)

    # Mocking response for the get_test_run_v0_test_runs_test_run_id_get API call
    httpx_mock.add_response(
        status_code=201,
        json={
            "id": MOCK_UUID,
            "project_id": MOCK_UUID,
            "mut_id": MOCK_UUID,
            "scenario_set_id": MOCK_UUID,
        },
    )

    result = registered_model.get_test_run(MOCK_UUID)
    assert result


def test_missing_api_key_test_run_modelv2(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        json=GLOBAL_PROJECT_RESPONSE,
        status_code=201,
    )
    httpx_mock.add_response(status_code=201, json=get_mut_fixture())
    okareo = Okareo("api-key", "http://mocked.com")
    mut = okareo.register_model(
        name="complex model test",
        model=[
            CohereModel(model_id="foo", model_type="embed"),
            PineconeDb(index_name="bar", region="baz", project_id="fooz"),
        ],
    )

    with pytest.raises(TestRunError):
        mut.run_test(
            name="quick test",
            scenario=Mock(),
            calculate_metrics=True,
            test_run_type=TestRunType.INFORMATION_RETRIEVAL,
            api_keys={"cohere": "foo"},
        )


def test_missing_vector_db_key_test_run_modelv2(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        json=GLOBAL_PROJECT_RESPONSE,
        status_code=201,
    )
    httpx_mock.add_response(status_code=201, json=get_mut_fixture())
    okareo = Okareo("api-key", "http://mocked.com")
    mut = okareo.register_model(
        name="complex model test",
        model=[
            CohereModel(model_id="foo", model_type="embed"),
        ],
    )

    with pytest.raises(TestRunError):
        mut.run_test(
            name="quick test",
            scenario=Mock(),
            calculate_metrics=True,
            test_run_type=TestRunType.INFORMATION_RETRIEVAL,
            api_keys={"cohere": "foo"},
        )


def test_target_to_dict_twilio_marks_auth_token_sensitive() -> None:
    tgt = Target(
        name="Voice Sim Target (Twilio)",
        target=TwilioVoiceTarget(
            account_sid="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            auth_token="super-secret",
            from_phone_number="+15105551234",
            to_phone_number="+14155559876",
        ),
    )
    payload = tgt.to_dict()

    # Top-level sensitive_fields should be present and include only "auth_token"
    assert "sensitive_fields" in payload
    assert payload["sensitive_fields"] == ["auth_token"]

    # Sanity: the inner target payload is still Twilio-shaped
    assert payload["target"]["type"] == "voice"
    assert payload["target"]["edge_type"] == "twilio"
    assert payload["target"]["account_sid"] == "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    assert payload["target"]["auth_token"] == "super-secret"


def test_target_to_dict_twilio_omits_sensitive_when_token_missing() -> None:
    tgt = Target(
        name="Voice Sim Target (Twilio)",
        target=TwilioVoiceTarget(
            account_sid="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            auth_token="",  # no token provided
            from_phone_number="+15105551234",
            to_phone_number="+14155559876",
        ),
    )
    payload = tgt.to_dict()

    # No auth_token provided -> do not emit sensitive_fields
    assert "sensitive_fields" not in payload


def test_target_to_dict_other_voice_targets_have_no_sensitive_fields() -> None:
    tgt = Target(
        name="OpenAI Voice",
        target=OpenAIVoiceTarget(model="gpt-realtime"),
    )
    payload = tgt.to_dict()

    # Only Twilio declares sensitive fields, others should not
    assert "sensitive_fields" not in payload
    assert payload["target"]["edge_type"] == "openai"


# ---------------------------------------------------------------------------
# CustomEndpointTarget.params() serialization
# ---------------------------------------------------------------------------
MINIMAL_TURN = TurnConfig(
    url="https://api.example.com/message",
    method="POST",
)


class TestCustomEndpointTargetParams:
    """Verify that CustomEndpointTarget.params() serializes optional fields correctly."""

    def test_omitted_optional_params_serialize_as_none(self) -> None:
        """When start_session and end_session are omitted, params() must emit null (not {})."""
        target = CustomEndpointTarget(None, MINIMAL_TURN)
        result = target.params()
        assert result["start_session_params"] is None
        assert result["end_session_params"] is None
        assert "auth_params" not in result

    def test_explicit_none_optional_params_serialize_as_none(self) -> None:
        target = CustomEndpointTarget(
            start_session=None,
            next_turn=MINIMAL_TURN,
            end_session=None,
            auth=None,
        )
        result = target.params()
        assert result["start_session_params"] is None
        assert result["end_session_params"] is None
        assert "auth_params" not in result

    def test_provided_start_session_serializes_as_dict(self) -> None:
        session = SessionConfig(url="https://api.example.com/start")
        target = CustomEndpointTarget(session, MINIMAL_TURN)
        result = target.params()
        assert isinstance(result["start_session_params"], dict)
        assert result["start_session_params"]["url"] == "https://api.example.com/start"

    def test_provided_end_session_serializes_as_dict(self) -> None:
        end = EndSessionConfig(url="https://api.example.com/end")
        target = CustomEndpointTarget(None, MINIMAL_TURN, end_session=end)
        result = target.params()
        assert isinstance(result["end_session_params"], dict)
        assert result["end_session_params"]["url"] == "https://api.example.com/end"

    def test_provided_auth_serializes_as_dict(self) -> None:
        auth = AuthConfig(url="https://auth.example.com/token")
        target = CustomEndpointTarget(None, MINIMAL_TURN, auth=auth)
        result = target.params()
        assert "auth_params" in result
        assert result["auth_params"]["url"] == "https://auth.example.com/token"

    def test_next_turn_always_serializes_as_dict(self) -> None:
        target = CustomEndpointTarget(None, MINIMAL_TURN)
        result = target.params()
        assert isinstance(result["next_message_params"], dict)
        assert result["next_message_params"]["url"] == "https://api.example.com/message"

    def test_max_parallel_requests_passed_through(self) -> None:
        target = CustomEndpointTarget(None, MINIMAL_TURN, max_parallel_requests=5)
        result = target.params()
        assert result["max_parallel_requests"] == 5

    def test_type_is_custom_endpoint(self) -> None:
        target = CustomEndpointTarget(None, MINIMAL_TURN)
        assert target.params()["type"] == "custom_endpoint"
