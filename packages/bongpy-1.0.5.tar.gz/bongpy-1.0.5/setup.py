from setuptools import setup

# This reads your README.md file
with open("bongpy/README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='bongpy', 
    version='1.0.5',
    description='The Official Benglish Programming Language Engine, developed by Ronit.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Ronit',
    py_modules=['bongpy_engine'],
    entry_points={
        'console_scripts': [
            'bongpy=bongpy_engine:main',
        ],
    },
)