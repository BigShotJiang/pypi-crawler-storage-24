from importlib.metadata import version

from .channel import AsyncChannel as AsyncChannel
from .channel import AsyncWebSocket as AsyncWebSocket
from .client import AsyncWebSocketClient as AsyncWebSocketClient
from .server import YRoom as YRoom
from .server import YRoomFactory as YRoomFactory
from .server import YRooms as YRooms

__version__ = version(__package__)
