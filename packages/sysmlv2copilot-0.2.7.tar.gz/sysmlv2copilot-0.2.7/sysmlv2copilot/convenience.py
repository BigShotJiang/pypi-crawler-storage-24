from __future__ import annotations

from os import PathLike
from typing import Literal, Protocol, overload

from .client import SysMLCopilot
from .input_utils import coerce_input_text
from .types import RepairObject, ResponseObject


class _ReadableText(Protocol):
    name: str

    def read(self) -> str | bytes:
        ...


InputSource = str | bytes | PathLike[str] | _ReadableText


@overload
def generate(
    source: InputSource,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    provider: Literal["openai", "anthropic"] | None = None,
    upstream_model: str | None = None,
    model: str = "refine-sysml-v1",
    max_iters: int = 10,
    max_total_tokens: int = 40_000,
    temperature: float | None = None,
    timeout: float = 120.0,
    return_response: Literal[False] = False,
) -> str:
    ...


@overload
def generate(
    source: InputSource,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    provider: Literal["openai", "anthropic"] | None = None,
    upstream_model: str | None = None,
    model: str = "refine-sysml-v1",
    max_iters: int = 10,
    max_total_tokens: int = 40_000,
    temperature: float | None = None,
    timeout: float = 120.0,
    return_response: Literal[True],
) -> ResponseObject:
    ...


def generate(
    source: InputSource,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    provider: Literal["openai", "anthropic"] | None = None,
    upstream_model: str | None = None,
    model: str = "refine-sysml-v1",
    max_iters: int = 10,
    max_total_tokens: int = 40_000,
    temperature: float | None = None,
    timeout: float = 120.0,
    return_response: bool = False,
) -> str | ResponseObject:
    input_text = coerce_input_text(source)
    with SysMLCopilot(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        response = client.responses.create(
            input=input_text,
            model=model,
            provider=provider,
            upstream_model=upstream_model,
            max_iters=max_iters,
            max_total_tokens=max_total_tokens,
            temperature=temperature,
        )
    if return_response:
        return response
    if response.output_text is None:
        raise RuntimeError(f"Generate request {response.id} returned no output_text.")
    return response.output_text


@overload
def repair(
    source: InputSource,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    provider: Literal["openai", "anthropic"] | None = None,
    upstream_model: str | None = None,
    model: str = "refine-sysml-v1",
    max_iters: int = 10,
    max_total_tokens: int = 40_000,
    temperature: float | None = None,
    timeout: float = 120.0,
    return_response: Literal[False] = False,
) -> str:
    ...


@overload
def repair(
    source: InputSource,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    provider: Literal["openai", "anthropic"] | None = None,
    upstream_model: str | None = None,
    model: str = "refine-sysml-v1",
    max_iters: int = 10,
    max_total_tokens: int = 40_000,
    temperature: float | None = None,
    timeout: float = 120.0,
    return_response: Literal[True],
) -> RepairObject:
    ...


def repair(
    source: InputSource,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    provider: Literal["openai", "anthropic"] | None = None,
    upstream_model: str | None = None,
    model: str = "refine-sysml-v1",
    max_iters: int = 10,
    max_total_tokens: int = 40_000,
    temperature: float | None = None,
    timeout: float = 120.0,
    return_response: bool = False,
) -> str | RepairObject:
    input_text = coerce_input_text(source)
    with SysMLCopilot(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        response = client.repairs.create(
            input=input_text,
            model=model,
            provider=provider,
            upstream_model=upstream_model,
            max_iters=max_iters,
            max_total_tokens=max_total_tokens,
            temperature=temperature,
        )
    if return_response:
        return response
    if response.output_text is None:
        raise RuntimeError(f"Repair request {response.id} returned no output_text.")
    return response.output_text
