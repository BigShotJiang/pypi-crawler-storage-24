from __future__ import annotations

from typing import Any


class SysMLCopilotError(Exception):
    """Base SDK exception."""


class APIConnectionError(SysMLCopilotError):
    """Raised when the API cannot be reached."""


class APIResponseValidationError(SysMLCopilotError):
    """Raised when the API response shape is invalid."""


class APIStatusError(SysMLCopilotError):
    """Raised for non-2xx API responses."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        body: Any | None = None,
        error_type: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body
        self.error_type = error_type


class AuthenticationError(APIStatusError):
    """Raised for 401 responses."""


class RateLimitError(APIStatusError):
    """Raised for 429 responses."""
