from __future__ import annotations

from collections.abc import Mapping
import os
from typing import Any

import httpx
from pydantic import ValidationError

from .exceptions import (
    APIConnectionError,
    APIResponseValidationError,
    APIStatusError,
    AuthenticationError,
    RateLimitError,
)
from .types import (
    HealthResponse,
    RepairCreateParams,
    RepairObject,
    RequestDetail,
    ResponseCreateParams,
    ResponseObject,
)

DEFAULT_BASE_URL = "https://sysml-refinement-api.lemontree-8a5c4550.eastus.azurecontainerapps.io"


def _normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def _resolve_base_url(base_url: str | None, http_client: httpx.Client | None) -> str:
    if base_url:
        return _normalize_base_url(base_url)
    if env_base_url := os.getenv("SYSMLV2COPILOT_BASE_URL"):
        return _normalize_base_url(env_base_url)
    if http_client is not None and str(http_client.base_url):
        return _normalize_base_url(str(http_client.base_url))
    return DEFAULT_BASE_URL


class _BaseResource:
    def __init__(self, client: "SysMLCopilot") -> None:
        self._client = client

    def _request(self, method: str, path: str, *, json_body: Mapping[str, Any] | None = None) -> Any:
        return self._client._request(method, path, json_body=json_body)


class ResponsesResource(_BaseResource):
    def create(
        self,
        *,
        input: str,
        model: str = "refine-sysml-v1",
        provider: str | None = None,
        upstream_model: str | None = None,
        max_iters: int = 10,
        max_total_tokens: int = 40_000,
        temperature: float | None = None,
    ) -> ResponseObject:
        payload = ResponseCreateParams(
            input=input,
            model=model,
            provider=provider,
            upstream_model=upstream_model,
            max_iters=max_iters,
            max_total_tokens=max_total_tokens,
            temperature=temperature,
        )
        data = self._request(
            "POST",
            "/v1/responses",
            json_body=payload.model_dump(exclude_none=True),
        )
        try:
            return ResponseObject.model_validate(data)
        except ValidationError as exc:
            raise APIResponseValidationError(f"Invalid response payload: {exc}") from exc


class RequestsResource(_BaseResource):
    def retrieve(self, request_id: str) -> RequestDetail:
        data = self._request("GET", f"/v1/requests/{request_id}")
        try:
            return RequestDetail.model_validate(data)
        except ValidationError as exc:
            raise APIResponseValidationError(f"Invalid request detail payload: {exc}") from exc


class RepairsResource(_BaseResource):
    def create(
        self,
        *,
        input: str,
        model: str = "refine-sysml-v1",
        provider: str | None = None,
        upstream_model: str | None = None,
        max_iters: int = 10,
        max_total_tokens: int = 40_000,
        temperature: float | None = None,
    ) -> RepairObject:
        payload = RepairCreateParams(
            input=input,
            model=model,
            provider=provider,
            upstream_model=upstream_model,
            max_iters=max_iters,
            max_total_tokens=max_total_tokens,
            temperature=temperature,
        )
        data = self._request(
            "POST",
            "/v1/repairs",
            json_body=payload.model_dump(exclude_none=True),
        )
        try:
            return RepairObject.model_validate(data)
        except ValidationError as exc:
            raise APIResponseValidationError(f"Invalid repair payload: {exc}") from exc


class HealthResource(_BaseResource):
    def check(self) -> HealthResponse:
        data = self._request("GET", "/healthz")
        try:
            return HealthResponse.model_validate(data)
        except ValidationError as exc:
            raise APIResponseValidationError(f"Invalid health payload: {exc}") from exc


class SysMLCopilot:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 120.0,
        http_client: httpx.Client | None = None,
        default_headers: Mapping[str, str] | None = None,
    ) -> None:
        self.base_url = _resolve_base_url(base_url, http_client)
        self._owns_client = http_client is None
        headers = {"Accept": "application/json"}
        if default_headers:
            headers.update(default_headers)
        if api_key is None:
            api_key = os.getenv("SYSMLV2COPILOT_API_KEY")
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        if http_client is None:
            self._client = httpx.Client(
                base_url=self.base_url,
                headers=headers,
                timeout=timeout,
            )
        else:
            http_client.headers.update(headers)
            self._client = http_client
        self.responses = ResponsesResource(self)
        self.repairs = RepairsResource(self)
        self.requests = RequestsResource(self)
        self.health = HealthResource(self)

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "SysMLCopilot":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _request(self, method: str, path: str, *, json_body: Mapping[str, Any] | None = None) -> Any:
        try:
            response = self._client.request(method, path, json=json_body)
        except httpx.HTTPError as exc:
            raise APIConnectionError(f"Request failed: {exc}") from exc
        if response.is_error:
            self._raise_for_status(response)
        try:
            return response.json()
        except ValueError as exc:
            raise APIResponseValidationError(f"Response was not valid JSON: {exc}") from exc

    def _raise_for_status(self, response: httpx.Response) -> None:
        body: Any
        try:
            body = response.json()
        except ValueError:
            body = response.text

        detail = body.get("detail") if isinstance(body, dict) else None
        payload = detail.get("error") if isinstance(detail, dict) else None
        error_type = payload.get("type") if isinstance(payload, dict) else None
        message = payload.get("message") if isinstance(payload, dict) else response.text

        exc_cls: type[APIStatusError]
        if response.status_code == 401:
            exc_cls = AuthenticationError
        elif response.status_code == 429:
            exc_cls = RateLimitError
        else:
            exc_cls = APIStatusError
        raise exc_cls(
            message or f"API request failed with status {response.status_code}",
            status_code=response.status_code,
            body=body,
            error_type=error_type,
        )
