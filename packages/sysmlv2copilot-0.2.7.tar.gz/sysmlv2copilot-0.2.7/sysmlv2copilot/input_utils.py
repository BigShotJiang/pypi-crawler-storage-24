from __future__ import annotations

from html.parser import HTMLParser
from os import PathLike
from pathlib import Path
from typing import Protocol

ALLOWED_INPUT_SUFFIXES = {".txt", ".sysml", ".html", ".htm"}
_BLOCK_HTML_TAGS = {
    "article",
    "aside",
    "blockquote",
    "br",
    "div",
    "footer",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "header",
    "li",
    "main",
    "ol",
    "p",
    "section",
    "table",
    "td",
    "th",
    "tr",
    "ul",
}


class _ReadableText(Protocol):
    name: str

    def read(self) -> str | bytes:
        ...


class _HTMLToTextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._parts: list[str] = []
        self._ignored_depth = 0

    def handle_starttag(self, tag: str, attrs) -> None:  # type: ignore[override]
        normalized = tag.lower()
        if normalized in {"script", "style"}:
            self._ignored_depth += 1
            return
        if self._ignored_depth == 0 and normalized in _BLOCK_HTML_TAGS:
            self._parts.append("\n")

    def handle_endtag(self, tag: str) -> None:  # type: ignore[override]
        normalized = tag.lower()
        if normalized in {"script", "style"} and self._ignored_depth > 0:
            self._ignored_depth -= 1
            return
        if self._ignored_depth == 0 and normalized in _BLOCK_HTML_TAGS:
            self._parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._ignored_depth == 0 and data:
            self._parts.append(data)

    def get_text(self) -> str:
        lines = (" ".join(segment.split()) for segment in "".join(self._parts).splitlines())
        return "\n".join(line for line in lines if line)


def coerce_input_text(source: str | bytes | PathLike[str] | _ReadableText) -> str:
    if isinstance(source, bytes):
        return source.decode("utf-8")
    if isinstance(source, PathLike):
        return _read_input_file(Path(source))
    if hasattr(source, "read"):
        raw_text = source.read()
        if isinstance(raw_text, bytes):
            raw_text = raw_text.decode("utf-8")
        if not isinstance(raw_text, str):
            raise TypeError("Input file objects must return text or UTF-8 bytes from read().")
        suffix = Path(getattr(source, "name", "")).suffix.lower()
        return _convert_html_to_text(raw_text) if suffix in {".html", ".htm"} else raw_text
    if isinstance(source, str):
        maybe_path = Path(source)
        if maybe_path.is_file() and maybe_path.suffix.lower() in ALLOWED_INPUT_SUFFIXES:
            return _read_input_file(maybe_path)
        return source
    raise TypeError(
        "Input must be a string, bytes, pathlib.Path, path string, or readable text file object."
    )


def _read_input_file(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix not in ALLOWED_INPUT_SUFFIXES:
        allowed = ", ".join(sorted(ALLOWED_INPUT_SUFFIXES))
        raise ValueError(f"Unsupported input file type: {suffix or '<none>'}. Use one of: {allowed}.")

    raw_text = path.read_text(encoding="utf-8")
    return _convert_html_to_text(raw_text) if suffix in {".html", ".htm"} else raw_text


def _convert_html_to_text(raw_text: str) -> str:
    parser = _HTMLToTextParser()
    parser.feed(raw_text)
    parser.close()
    return parser.get_text()
