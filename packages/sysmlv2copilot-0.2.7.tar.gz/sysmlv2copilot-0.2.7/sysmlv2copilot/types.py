from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ResponseCreateParams(BaseModel):
    input: str
    model: str = "refine-sysml-v1"
    provider: Literal["openai", "anthropic"] | None = None
    upstream_model: str | None = None
    max_iters: int = Field(default=10, ge=1, le=50)
    max_total_tokens: int = Field(default=40_000, ge=1, le=250_000)
    temperature: float | None = Field(default=None, ge=0, le=2)


class RepairCreateParams(ResponseCreateParams):
    pass


class ErrorPayload(BaseModel):
    type: str
    message: str


class ArtifactReference(BaseModel):
    id: str
    artifact_type: str
    storage_backend: str
    storage_path: str
    content_type: str
    size_bytes: int
    created_at: str


class ResponseMetadata(BaseModel):
    operation: Literal["generate", "repair"] | None = None
    provider: Literal["openai", "anthropic"] | None = None
    upstream_model: str | None = None
    run_id: str | None = None
    diagnostics_summary: str | None = None
    initial_compiler_passed: bool | None = None
    artifact_paths: dict[str, str] = Field(default_factory=dict)
    usage: dict[str, int | None] = Field(default_factory=dict)


class ResponseObject(BaseModel):
    id: str
    object: Literal["response"] = "response"
    status: Literal["completed", "failed"]
    model: str
    output_text: str | None = None
    compiler_passed: bool | None = None
    iterations_completed: int | None = None
    started_at: str
    finished_at: str | None = None
    duration_ms: int | None = None
    request_user_id: str
    request_user_email: str | None = None
    request_user_name: str | None = None
    metadata: ResponseMetadata
    error: ErrorPayload | None = None


class RepairObject(BaseModel):
    id: str
    object: Literal["repair"] = "repair"
    status: Literal["completed", "failed"]
    model: str
    output_text: str | None = None
    compiler_passed: bool | None = None
    iterations_completed: int | None = None
    started_at: str
    finished_at: str | None = None
    duration_ms: int | None = None
    request_user_id: str
    request_user_email: str | None = None
    request_user_name: str | None = None
    metadata: ResponseMetadata
    error: ErrorPayload | None = None


class RequestDetail(BaseModel):
    id: str
    object: Literal["request"] = "request"
    status: str
    model: str
    output_text: str | None = None
    compiler_passed: bool | None = None
    iterations_completed: int | None = None
    started_at: str
    finished_at: str | None = None
    duration_ms: int | None = None
    request_user_id: str
    request_user_email: str | None = None
    request_user_name: str | None = None
    metadata: ResponseMetadata
    error: ErrorPayload | None = None
    artifacts: list[ArtifactReference] = Field(default_factory=list)


class DependencyStatus(BaseModel):
    available: bool
    detail: str | None = None


class HealthResponse(BaseModel):
    status: Literal["ok"] = "ok"
    service: str
    version: str
    dependencies: dict[str, DependencyStatus]
