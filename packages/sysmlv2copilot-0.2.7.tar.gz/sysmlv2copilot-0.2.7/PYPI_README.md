# sysmlv2copilot

`sysmlv2copilot` is the Python SDK and CLI for the SysML Copilot service used by the Visual Design and Engineering Lab at Carnegie Mellon University.

This package is for authorized internal users. Installing it does not by itself grant service access.

## What Users Can Do

- Generate SysML from text requirements
- Repair existing SysML
- Use either Python or the command line

## Install

```bash
python -m pip install sysmlv2copilot
```

## Authentication

Set your API key once:

```bash
export SYSMLV2COPILOT_API_KEY=sysml_live_...
```

Or pass it directly in code:

```python
from sysmlv2copilot import generate, repair

sysml = generate(
    "Design a compact warehouse inspection drone that can hover for 15 minutes.",
    api_key="sysml_live_...",
)

repaired = repair(
    "broken.sysml",
    api_key="sysml_live_...",
)
```

## Python

Generate SysML:

```python
from sysmlv2copilot import generate

sysml = generate("Design a compact warehouse inspection drone that can hover for 15 minutes.")
print(sysml)
```

Repair SysML:

```python
from pathlib import Path

from sysmlv2copilot import repair

repaired = repair(Path("broken.sysml"))
print(repaired)
```

You can pass:
- raw strings
- `Path` objects
- path strings like `"broken.sysml"` or `"requirements.html"`
- open text files

## CLI

Generate SysML from inline text:

```bash
sysmlv2copilot --api-key sysml_live_... \
  generate \
  --input "Design a compact warehouse inspection drone that can hover for 15 minutes."
```

Repair SysML from a file:

```bash
sysmlv2copilot --api-key sysml_live_... \
  repair \
  --input-file ./broken.sysml
```

The CLI accepts `.txt`, `.sysml`, and `.html` files for `--input-file`.
HTML files are converted to plain text before being sent to the API.
