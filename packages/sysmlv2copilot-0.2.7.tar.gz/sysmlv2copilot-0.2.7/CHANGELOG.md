# Changelog

## 0.2.0

- split the public package into a client-only SDK and CLI boundary
- added PyPI-ready metadata, MIT licensing, and release workflow docs
- added a repair workflow across the API, SDK, and CLI
- added packaging, CI, and smoke-test improvements
