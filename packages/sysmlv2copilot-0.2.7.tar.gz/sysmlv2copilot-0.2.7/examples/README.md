# SDK Examples

- `client_sdk_basic.py` shows text-to-SysML generation through the hosted API.
- `repair_basic.py` shows the repair workflow for broken SysML input.
