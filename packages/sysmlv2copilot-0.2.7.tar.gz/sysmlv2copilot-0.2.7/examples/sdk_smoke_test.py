from __future__ import annotations

import os

from sysmlv2copilot import SysMLCopilot


def main() -> int:
    api_key = os.environ["SYSMLV2COPILOT_API_KEY"]
    base_url = os.environ.get("SYSMLV2COPILOT_BASE_URL", "http://127.0.0.1:8000")

    with SysMLCopilot(api_key=api_key, base_url=base_url) as client:
        response = client.responses.create(
            input="Design a compact warehouse inspection drone that can hover for 15 minutes.",
            provider="openai",
        )
        detail = client.requests.retrieve(response.id)
    print(response.id)
    print(detail.metadata.operation)
    print(detail.artifacts[0].storage_path if detail.artifacts else "no-artifacts")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
