from sysmlv2copilot import repair

BROKEN_SYSML = """package Example {
  public import ScalarValues::*;
  requirement def R_Sample { text = "Example" }
}
"""

fixed_sysml = repair(BROKEN_SYSML, api_key="sysml_live_...")
print(fixed_sysml)
