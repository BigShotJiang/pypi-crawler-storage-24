from sysmlv2copilot import generate

sysml = generate(
    "Design a compact warehouse inspection drone that can hover for 15 minutes.",
    api_key="sysml_live_...",
)
print(sysml)
