"""Model providers for different LLM backends."""

from henchman.providers.anthropic import AnthropicProvider, AnthropicProviderConfig
from henchman.providers.base import (
    FinishReason,
    Message,
    ModelProvider,
    StreamChunk,
    ToolCall,
    ToolDeclaration,
)
from henchman.providers.deepseek import DeepSeekProvider
from henchman.providers.ollama import OllamaProvider
from henchman.providers.openai_compat import OpenAICompatibleProvider
from henchman.providers.openrouter import OpenRouterProvider
from henchman.providers.registry import ProviderRegistry, get_default_registry

__all__ = [
    "AnthropicProvider",
    "AnthropicProviderConfig",
    "DeepSeekProvider",
    "FinishReason",
    "Message",
    "ModelProvider",
    "OllamaProvider",
    "OpenAICompatibleProvider",
    "OpenRouterProvider",
    "ProviderRegistry",
    "StreamChunk",
    "ToolCall",
    "ToolDeclaration",
    "get_default_registry",
]
