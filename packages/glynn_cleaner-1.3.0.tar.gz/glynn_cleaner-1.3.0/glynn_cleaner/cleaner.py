"""
Data Cleaning Tool
Author: Glynn Holland

Version:
    The current version is defined in glynn_cleaner.__version__.

Description:
    A command-line CSV cleaning utility supporting simple and audit modes,
    with lenient or strict validation. Generates cleaned output, a machine-
    readable summary CSV, and a human-readable text report.

Features:
    - Email validation (lenient or strict)
    - Date parsing and normalisation
    - Junk row removal
    - Duplicate removal
    - Name capitalisation
    - Dry-run mode (no files written)
    - Summary-only mode
    - Structured progress messages
    - Startup and success banners
"""

import pandas as pd
from datetime import datetime
import re
from glynn_cleaner import __version__

from glynn_cleaner.utils.file_helpers import (
    load_csv,
    save_csv,
    save_summary,
    save_text_report
)

from glynn_cleaner.utils.logger import (
    log_info,
    log_debug,
    log_warning,
    log_error
)

# ------------------------------------------------------------
# NEW EMAIL LOGIC (imports from your helper module)
# ------------------------------------------------------------
from glynn_cleaner.helpers.email_utils import (
    is_valid_email,
    suggest_email_fix
)

# ------------------------------------------------------------
# 24-HOUR BACKGROUND REFRESH LOOP FOR DISPOSABLE DOMAIN LIST
# ------------------------------------------------------------
from glynn_cleaner.helpers.email_disposable_loader import start_background_refresh


def clean_email_simple(email: str) -> str:
    """
    Simple mode email cleaning:
    - Keep valid emails unchanged.
    - Apply safe fixes when available.
    - Blank unfixable invalid emails.
    """
    if not isinstance(email, str):
        return ""

    email = email.strip()

    # Valid → keep
    if is_valid_email(email):
        return email

    # Fixable → fix
    fix = suggest_email_fix(email)
    if fix:
        return fix

    # Invalid + unfixable → blank
    return ""


def clean_email_audit(email: str) -> dict:
    """
    Audit mode email cleaning:
    Returns a dict with:
    - original
    - cleaned
    - valid
    - suggested_fix
    """
    if not isinstance(email, str):
        return {
            "original": email,
            "cleaned": "",
            "valid": False,
            "suggested_fix": ""
        }

    original = email.strip()
    valid = is_valid_email(original)
    suggested = suggest_email_fix(original)

    if valid:
        cleaned = original
    elif suggested:
        cleaned = suggested
    else:
        cleaned = ""

    return {
        "original": original,
        "cleaned": cleaned,
        "valid": valid,
        "suggested_fix": suggested or ""
    }


# ------------------------------------------------------------
# Date parsing helpers (unchanged)
# ------------------------------------------------------------
def parse_date(date_str: str, strict: bool = False):
    if not isinstance(date_str, str) or not date_str.strip():
        return "", date_str, False

    original = date_str.strip()

    normalised = (
        original.replace(".", "-")
                .replace("/", "-")
                .replace(" ", "-")
    )

    if strict and not re.search(r"\b\d{4}\b", normalised):
        return "", original, False

    formats = [
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%m-%d-%Y",
        "%d-%m-%y",
        "%m-%d-%y",
    ]

    for fmt in formats:
        try:
            dt = datetime.strptime(normalised, fmt)

            if strict and "%y" in fmt:
                return "", original, False

            return dt.strftime("%Y-%m-%d"), original, True
        except ValueError:
            continue

    return "", original, False


def format_date_column(df, column="date_of_birth_cleaned", output_format="%Y-%m-%d"):
    if column in df.columns:
        df[column] = df[column].apply(
            lambda x: datetime.strptime(x, "%Y-%m-%d").strftime(output_format)
            if isinstance(x, str) and x.strip()
            else x
        )
    return df


# ------------------------------------------------------------
# Main cleaning function
# ------------------------------------------------------------
def clean_data(input_path: str, output_path: str, mode: str = "simple",
               strictness: str = "lenient", dry_run: bool = False,
               summary_only: bool = False):

    log_info("==============================================")
    log_info("        Glynn Cleaner — Data Cleaning Tool")
    log_info(f"                    Version {__version__}")
    log_info("==============================================")
    log_info(f"Mode: {mode} | Strictness: {strictness}")
    log_info("----------------------------------------------")

    step = 1
    total_steps = 10

    # ------------------------------------------------------------
    # Step 1 — Load CSV
    # ------------------------------------------------------------
    log_info(f"[{step}/{total_steps}] Loading CSV: {input_path}")
    step += 1

    df = load_csv(input_path)
    original_count = len(df)
    log_info(f"Rows loaded: {original_count}")

    # ------------------------------------------------------------
    # Step 2 — Column normalisation
    # ------------------------------------------------------------
    log_info(f"[{step}/{total_steps}] Normalising column names")
    step += 1

    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "_")
    )
    log_debug(f"Normalised columns: {df.columns.tolist()}")

    column_map = {
        "email_address": "email",
        "dob": "date_of_birth",
        "dateofbirth": "date_of_birth",
    }
    df = df.rename(columns={k: v for k, v in column_map.items() if k in df.columns})

    # ------------------------------------------------------------
    # Step 3 — Trim whitespace
    # ------------------------------------------------------------
    log_info(f"[{step}/{total_steps}] Trimming whitespace")
    step += 1

    df = df.map(lambda x: x.strip() if isinstance(x, str) else x)

    # ------------------------------------------------------------
    # Step 4 — Capitalise names
    # ------------------------------------------------------------
    log_info(f"[{step}/{total_steps}] Applying name capitalisation")
    step += 1

    if "name" in df.columns:
        df["name"] = df["name"].str.title()

    # ------------------------------------------------------------
    # Step 5 — Remove junk rows
    # ------------------------------------------------------------
    log_info(f"[{step}/{total_steps}] Removing junk rows")
    step += 1

    def is_junk_row(row):
        vals = row.astype(str).str.strip()
        return all(v == "" or v == "'''" for v in vals)

    df = df.dropna(how="all")
    df = df[~df.apply(is_junk_row, axis=1)]
    removed_junk = original_count - len(df)
    log_info(f"Junk rows removed: {removed_junk}")

    # ------------------------------------------------------------
    # Step 6 — Email validation (NEW LOGIC)
    # ------------------------------------------------------------
    strict_flag = (strictness == "strict")
    log_info(f"[{step}/{total_steps}] Validating emails (strict={strict_flag})")
    step += 1

    if mode == "simple":
        df["email"] = df["email"].apply(clean_email_simple)
        df["email_valid"] = df["email"].apply(lambda e: is_valid_email(e))
        df["email_suggested_fix"] = ""
    else:
        audit_results = df["email"].apply(clean_email_audit)
        df["email_original"] = audit_results.apply(lambda x: x["original"])
        df["email_cleaned"] = audit_results.apply(lambda x: x["cleaned"])
        df["email_valid"] = audit_results.apply(lambda x: x["valid"])
        df["email_suggested_fix"] = audit_results.apply(lambda x: x["suggested_fix"])

    invalid_email_count = (~df["email_valid"]).sum()
    log_info(f"Invalid emails detected: {invalid_email_count}")

    # ------------------------------------------------------------
    # Step 7 — Date parsing
    # ------------------------------------------------------------
    log_info(f"[{step}/{total_steps}] Parsing dates of birth")
    step += 1

    parsed = df["date_of_birth"].apply(lambda d: parse_date(d, strict=strict_flag))
    df["date_of_birth_cleaned"] = parsed.apply(lambda x: x[0])
    df["date_of_birth_raw"] = parsed.apply(lambda x: x[1])
    df["date_of_birth_valid"] = parsed.apply(lambda x: x[2])

    invalid_date_count = (~df["date_of_birth_valid"]).sum()
    log_info(f"Invalid dates detected: {invalid_date_count}")
    df = format_date_column(df)

    # ------------------------------------------------------------
    # Step 8 — Strict mode filtering
    # ------------------------------------------------------------
    removed_invalid_emails = 0
    removed_invalid_dates = 0

    if strict_flag:
        log_info(f"[{step}/{total_steps}] Applying strict filtering rules")
        step += 1

        before = len(df)
        df = df[df["email_valid"]]
        removed_invalid_emails = before - len(df)
        log_info(f"Rows removed due to invalid emails: {removed_invalid_emails}")

        before = len(df)
        df = df[df["date_of_birth_valid"]]
        removed_invalid_dates = before - len(df)
        log_info(f"Rows removed due to invalid dates: {removed_invalid_dates}")
    else:
        log_info(f"[{step}/{total_steps}] Skipping strict filtering (lenient mode)")
        step += 1

    # ------------------------------------------------------------
    # Step 9 — Duplicate removal (improved, case-insensitive)
    # ------------------------------------------------------------
    log_info(f"[{step}/{total_steps}] Removing duplicate rows")
    step += 1

    before = len(df)

    # Normalise key fields BEFORE deduplication
    if "name" in df.columns:
        df["name"] = df["name"].astype(str).str.strip().str.title()

    if "email" in df.columns:
        df["email"] = df["email"].astype(str).str.strip().str.lower()

    if "date_of_birth" in df.columns:
        df["date_of_birth"] = df["date_of_birth"].astype(str).str.strip()

    # Drop duplicates using stable, explicit keys
    dedupe_keys = [col for col in ["name", "email", "date_of_birth"] if col in df.columns]
    df = df.drop_duplicates(subset=dedupe_keys, keep="first")

    removed_dupes = before - len(df)
    log_info(f"Duplicates removed: {removed_dupes}")

    final_count = len(df)

    # ------------------------------------------------------------
    # Final output columns (simple vs audit)
    # ------------------------------------------------------------
    log_info("Preparing final output columns")

    if mode == "simple":
        log_info("Simple mode selected — dropping helper columns")

        # Drop original date column to avoid duplicates
        if "date_of_birth" in df.columns:
            df = df.drop(columns=["date_of_birth"])

        # Keep only cleaned date
        df = df[["name", "email", "date_of_birth_cleaned", "notes"]]
        df = df.rename(columns={"date_of_birth_cleaned": "date_of_birth"})

    else:
        log_info("Audit mode selected — keeping helper columns")

        # Drop original date column to avoid duplicate names
        if "date_of_birth" in df.columns:
            df = df.drop(columns=["date_of_birth"])

        # Rename cleaned date into place
        df = df.rename(columns={"date_of_birth_cleaned": "date_of_birth"})


    # ------------------------------------------------------------
    # Dry-run mode
    # ------------------------------------------------------------
    if dry_run:
        log_warning("Dry-run mode enabled — no output files will be written.")
        log_info("Cleaning process completed (dry-run).")

        log_info("Summary (dry-run):")
        log_info(f"  Rows loaded: {original_count}")
        log_info(f"  Junk rows removed: {removed_junk}")
        log_info(f"  Invalid emails removed: {removed_invalid_emails}")
        log_info(f"  Invalid dates removed: {removed_invalid_dates}")
        log_info(f"  Duplicates removed: {removed_dupes}")
        log_info(f"  Final row count: {final_count}")

        return

    # ------------------------------------------------------------
    # Step 10 — Save cleaned CSV
    # ------------------------------------------------------------
    log_info(f"[{step}/{total_steps}] Saving cleaned CSV")
    step += 1

    if not summary_only:
        save_csv(df, output_path)
    else:
        log_info("Skipping cleaned CSV (summary-only mode).")

    # ------------------------------------------------------------
    # Build summary
    # ------------------------------------------------------------
    summary = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "input_file": input_path,
        "output_file": output_path,
        "mode": mode,
        "strictness": strictness,
        "rows_loaded": original_count,
        "junk_rows_removed": removed_junk,
        "invalid_emails_removed": removed_invalid_emails,
        "invalid_dates_removed": removed_invalid_dates,
        "duplicates_removed": removed_dupes,
        "final_row_count": final_count,
    }

    summary_path = output_path.replace(".csv", "_summary.csv")
    save_summary(summary, summary_path)

    # ------------------------------------------------------------
    # Human-readable report
    # ------------------------------------------------------------
    report_text = f"""
CLEANING REPORT — {summary['timestamp']}
----------------------------------------
Input file: {input_path}
Output file: {output_path}

Mode: {mode}
Strictness: {strictness}

Rows loaded: {original_count}
Junk rows removed: {removed_junk}
Invalid emails removed: {removed_invalid_emails}
Invalid dates removed: {removed_invalid_dates}
Duplicates removed: {removed_dupes}

Final row count: {final_count}
"""
    report_path = output_path.replace(".csv", "_report.txt")
    save_text_report(report_text.strip(), report_path)

    # ------------------------------------------------------------
    # Success banner
    # ------------------------------------------------------------
    log_info("==============================================")
    log_info(f"        Cleaning Completed Successfully (v{__version__})")
    log_info("==============================================")


# ------------------------------------------------------------
# CLI entry point
# ------------------------------------------------------------
def clean_data_cli():
    import argparse
    import logging

    parser = argparse.ArgumentParser(
        description="Clean CSV data with optional audit and strictness modes.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    parser.add_argument("--input", "-i", default="input/sample_dirty_data.csv")
    parser.add_argument("--output", "-o", default="output/cleaned_output.csv")
    parser.add_argument("--mode", "-m", choices=["simple", "audit"], default="simple")
    parser.add_argument("--strictness", "-s", choices=["lenient", "strict"], default="lenient")
    parser.add_argument(
        "--version",
        action="version",
        version=f"Data Cleaning Tool v{__version__}"
    )

    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--summary-only", action="store_true")

    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--quiet", action="store_true")

    args = parser.parse_args()

    logger = logging.getLogger("cleaner_logger")
    if args.verbose:
        logger.setLevel(logging.DEBUG)
    elif args.quiet:
        logger.setLevel(logging.WARNING)
    else:
        logger.setLevel(logging.INFO)

    # ------------------------------------------------------------
    # Start the 24‑hour background refresh loop
    # ------------------------------------------------------------
    start_background_refresh()

    clean_data(
        input_path=args.input,
        output_path=args.output,
        mode=args.mode,
        strictness=args.strictness,
        dry_run=args.dry_run,
        summary_only=args.summary_only
    )


if __name__ == "__main__":
    clean_data_cli()












