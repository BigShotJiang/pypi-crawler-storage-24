from typing import Protocol, Any, Dict, List, Optional


class ConnectorProtocol(Protocol):

    def __init__(self, credentials: Dict[str, Any]) -> None: ...

    def authenticate(self) -> Any: ...

    def get_objects(self) -> List[Dict[str, Any]]: ...

    def get_fields(
        self,
        object_id: str,
        options: Dict[str, Any] = {}
    ) -> List[Dict[str, Any]]: ...

    def get_data(
        self,
        object_id: str,
        field_ids: List[str],
        n_rows: Optional[int] = None,
        filters: Optional[Dict[str, Any]] = None,
        next_page: Optional[Any] = None,
        options: Dict[str, Any] = {}
    ) -> Any: ...

    def load_data(
        self,
        data: List[Dict[str, Any]],
        object_id: str,
        m: Any,
        update_method: str,
        batch_number: int,
        total_batches: int
    ) -> Any: ...

    def close(self) -> None: ...