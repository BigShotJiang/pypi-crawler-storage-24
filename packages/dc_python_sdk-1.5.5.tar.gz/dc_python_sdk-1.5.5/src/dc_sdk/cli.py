import sys

def main():
    if len(sys.argv) < 2:
        print("Usage: dc-sdk [run|http|lambda]")
        sys.exit(1)

    command = sys.argv[1]

    print(f"[DC SDK] Command: {command}")

    if command == "http":
        from dc_sdk.server import start_server
        start_server()

    else:
        print(f"Unknown command: {command}")
        sys.exit(1)