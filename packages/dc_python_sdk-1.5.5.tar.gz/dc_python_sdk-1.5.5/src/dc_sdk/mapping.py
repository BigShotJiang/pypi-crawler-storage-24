from dc_sdk import errors
import logging
from dc_sdk.loader import load_connector

logger = logging.getLogger(__name__)
class Mapping():
    def __init__(self, credentials):
        Connector = load_connector()
        self.connector = Connector(credentials)

    def authenticate(self):
        results = None
        metadata = None
        message = None

        if self.connector.authenticate():
            try:
                metadata = self.connector.get_metadata()
            except errors.NotImplementedError:
                pass
            except:
                logger.exception("Error getting metadata")

            results = {
                'metadata': metadata
            }

            message = "Authenticated successfully"
        else:
            raise errors.AuthenticationError(message="Failed to authenticate")

        return [results, message]

    def connect_get_objects(self):
        results = None
        metadata = None
        objects = None
        message = None

        if self.connector.authenticate():
            objects = self.connector.get_objects()
            try:
                metadata = self.connector.get_metadata()
            except errors.NotImplementedError:
                pass
            except Exception as e:
                print("Error getting metadata")
                print(str(e))

            results = {
                'metadata': metadata,
                'objects': objects,
            }
            message = "Authenticated successfully"
        else:
            # If not authenticated, raise the authentication error.
            raise errors.AuthenticationError(message="Failed to authenticate")

        return [results, message]
        
    def test_connection(self):
        results = None
        message = None

        if self.connector.authenticate():
            message = "Authenticated successfully"
        else:
            # If not authenticated, raise the authentication error.
            raise errors.AuthenticationError(message="Failed to authenticate")

        return [results, message]

    def get_fields(self, object_id, options):
        results = None
        message = None
        if self.connector.authenticate():
            results = self.connector.get_fields(object_id, options=options)
            message = "Retrieved fields"
        else:
            # If not authenticated, raise the authentication error.
            raise errors.AuthenticationError("Failed to authenticate")

        return [results, message]

    def get_five_row_preview(self, object_id, field_ids, options):
        results = None
        message = None

        if self.connector.authenticate():
            results = self.connector.get_data(object_id, field_ids=field_ids, n_rows=5, options=options)
            message = "Retrieved 5 row preview"
        else:
            # If not authenticated, raise the authentication error.
            raise errors.AuthenticationError("Failed to authenticate")

        return [results, message]

    def get_data(self, object_id, field_ids, n_rows, next_page, options):
        results = None
        message = None

        if self.connector.authenticate():
            results = self.connector.get_data(object_id, field_ids=field_ids, n_rows=n_rows, next_page=next_page, options=options)
            message = "Retrieved data"
        else:
            # If not authenticated, raise the authentication error.
            raise errors.AuthenticationError("Failed to authenticate")

        return [results, message]