import os, sys, marshal, lzma, base64, gc, zlib, json

def run_cmd(data, k_enc):
    # Khai báo màu sắc
    G, R, W = "\033[92m", "\033[91m", "\033[0m"
    os.system('cls' if os.name == 'nt' else 'clear')
    
    print(f"{G}╔{'═'*21}╗")
    print(f"║{' '*5}VINH AN 17{' '*6}║")
    print(f"╚{'═'*21}╝{W}")

    try:
        _d = "".join(data.split()).strip()
        _h = __import__('hashlib').sha256(_d.encode('utf-8')).hexdigest().strip()
        
        print(f"{G} Đang khởi tạo hệ thống...{W}")

        _k_b = base64.b85decode(k_enc.strip().encode('ascii'))
        _h_k = __import__('hashlib').sha256(_h.encode('utf-8')).digest()
        
        _m_r = bytearray(b ^ _h_k[i % 32] for i, b in enumerate(_k_b))
        _m_d = json.loads(_m_r.decode('utf-8'))
        _rev = {v: k for k, v in _m_d.items()}
        
        _b85 = ""
        for i in range(0, len(_d), 3):
            _ch = _d[i:i+3]
            if _ch in _rev: _b85 += _rev[_ch]
            else: _b85 += _ch

        _raw = base64.b85decode(_b85.encode('ascii'))
        _dec = lzma.decompress(zlib.decompress(_raw[::-1]))
        
        print(f"{G} Đang chạy... \n{W}")
        
        del data, _d, _k_b, _m_r, _rev, _b85, _raw
        gc.collect()
        
        _run = getattr(__import__('builtins'), 'exec')
        _run(marshal.loads(_dec), globals())

    except Exception as e:
        print(f"\n{R} Dữ liệu không hợp lệ hoặc đã bị thay đổi!{W}")
        sys.exit()