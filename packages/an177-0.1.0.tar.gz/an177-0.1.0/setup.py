from setuptools import setup, find_packages

setup(
    name="an177",
    version="0.1.0",
    author="vinh_an17",
    author_email="your_email@example.com",
    description="A lightweight offline code protection tool",
    long_description="A private tool for Python code obfuscation and protection.",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[], 
)