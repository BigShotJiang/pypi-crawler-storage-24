"""Prompt templates for arh."""
