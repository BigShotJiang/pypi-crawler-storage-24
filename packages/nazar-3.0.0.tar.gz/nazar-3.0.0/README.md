# Nazar

[![Test](https://github.com/user/nazar/actions/workflows/test.yml/badge.svg)](https://github.com/user/nazar/actions/workflows/test.yml)
[![PyPI version](https://badge.fury.io/py/nazar.svg)](https://badge.fury.io/py/nazar)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

Otonom guvenlik & kalite tarayicisi - Projeyi tarar, mimariyi anlar, 158+ test olusturur ve calistirir.

## Ozellikler

- 158+ otomatik test, 22 kategori
- 63 guvenlik testi (OWASP Top 10, 50+ secret pattern, supply chain)
- SCA Scanner (npm audit, pip-audit, govulncheck, typosquatting tespiti)
- Python AST Analyzer (false positive %80 azalma)
- Taint Tracking (SQL injection, XSS, command injection veri akisi)
- YAML Kural Motoru (Semgrep benzeri, kendi kuralinizi yazin)
- App Store & Play Store uyumluluk kontrolleri
- 87 adim adim duzeltme rehberi
- 15+ teknoloji destegi (React Native, Flutter, Django, FastAPI, Go, Rust...)
- Canli TUI + Interaktif shell + HTML rapor
- GitHub Action + PR Comment + SARIF
- VS Code Extension
- Zero-config: nazar yaz, gerisini o halleder

## Kurulum

### pipx ile (tavsiye edilen)

```bash
pipx install nazar
```

### pip ile

```bash
pip install nazar
```

### Kaynaktan (gelistirici)

```bash
git clone https://github.com/user/nazar.git
cd nazar
pip install -e ".[dev]"
```

Kurulumdan sonra terminal'de `nazar` yazmaniz yeterli.

## Kullanim

```bash
# Interaktif arayuz (en kolay yol)
nazar

# Tek komutla tam tarama
nazar auto /proje/yolu

# Mevcut dizini tara
nazar auto .

# Sadece tara (rapor yok)
nazar scan .

# Belirli kategori calistir
nazar run . --category security
nazar run . --category sca
nazar run . --category taint
nazar run . --category ast_analysis
nazar run . --category appstore
nazar run . --category playstore
nazar run . --category yaml_rules

# JSON cikti (CI/CD icin)
nazar --json auto .

# GitHub PR entegrasyonu
nazar auto . --github-pr --sarif nazar.sarif

# Minimal cikti
nazar --quiet auto .

# Yapilandirma dosyasi olustur
nazar init
```

### Interaktif Arayuz

`nazar` yazin, proje yolunu girin. Sonuclari inceleyin:

```
nazar> /Users/kadir/Desktop/MyApp
nazar> /report failed
nazar> /detail 1
nazar> /guide 1
nazar> /export html
nazar> /categories
nazar> /stats
nazar> /clear
nazar> /help
```

## Docker

```bash
docker build -t nazar .
docker run -v $(pwd):/project nazar
```

## Test Kategorileri (22)

| Kategori | Test | Aciklama |
|----------|------|----------|
| Security | 63 | 50+ secret pattern, OWASP Top 10, crypto, CORS, CSRF |
| SCA | 7 | npm/pip/go audit, typosquatting, lisans uyumluluk |
| AST Analysis | 6 | Python AST ile gercek kod analizi |
| Taint Tracking | 5 | SQL injection, XSS, command injection veri akisi |
| App Store | 32 | Privacy manifest, ATT, IAP, Sign in with Apple |
| Play Store | 10 | targetSdk, exported, ProGuard, permissions |
| Code Quality | 16 | Complexity, dead code, smells, debug statements |
| YAML Rules | 3 | Semgrep benzeri ozel kural motoru |
| UI Component | 10 | a11y, touch target, dark mode, loading state |
| UX Text | 8 | Yazim, tutarlilik, i18n, alt text |
| Cross-File | 7 | Dead export, orphan component, circular import |
| API | 4 | Erisilebilirlik, response, performance |
| Git | 4 | gitignore, buyuk dosya, hassas dosya |
| Type Safety | 3 | any usage, ts-ignore, as any |
| Error Handling | 3 | Bos catch, yutulmus hata, async |
| Performance | 3 | Kaynak boyutu, buyuk dosya/gorsel |
| Documentation | 3 | README, CHANGELOG |
| Naming | 3 | Dosya isimleri, tek harfli degisken |
| Dependencies | 3 | Vulnerability, deprecated |
| Accessibility | 2 | testID, label |
| Docker | 2 | Base image, secret |

## Plugin Gelistirme

```python
from nazar.plugins.base import BaseTestPlugin

class MyPlugin(BaseTestPlugin):
    name = "my-plugin"
    version = "1.0.0"
    description = "Custom test rules"

    def get_tests(self, scan_result):
        return [{"name": "My Test", "type": "custom", "priority": "medium"}]

    def run_test(self, test, project_path):
        return True, "Passed"
```

## Cikti Formatlari

```bash
nazar --json              # JSON
nazar auto --report r.html  # HTML (default)
```

Programmatik kullanim:
```python
from nazar.reporters import JSONReporter, JUnitReporter, SARIFReporter, MarkdownReporter
```

## Katki

Katki saglamak icin [CONTRIBUTING.md](CONTRIBUTING.md) dosyasini inceleyin.

## Lisans

MIT
