#!/usr/bin/env python
"""Simulate LLM-user workflow through the MCP server tool layer.

For each observatory:
  1. browse_observatories → find it
  2. load_observatory → get prompt with dataset catalog
  3. Pick a dataset (prefer mag/plasma with good coverage)
  4. browse_parameters → get parameter list
  5. Pick a sensible timeseries parameter (skip flags, status, energy tables)
  6. fetch_data → download 1 hour of data, check output file

Usage:
    python scripts/test_mcp_workflow.py                        # all 65 observatories
    python scripts/test_mcp_workflow.py --observatory ace       # one observatory
    python scripts/test_mcp_workflow.py --workers 6             # parallel workers
    python scripts/test_mcp_workflow.py --report                # print last report
"""

import argparse
import asyncio
import json
import signal
import sys
import tempfile
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import UTC, datetime, timedelta
from pathlib import Path

REPORTS_DIR = Path(__file__).resolve().parent.parent / "reports"

# Units that indicate real timeseries data (not flags, indices, status codes)
_GOOD_UNITS = {"nt", "km/s", "cm^-3", "cm-3", "/cc", "#/cc", "ev", "kev", "mev",
               "degrees", "deg", "re", "au", "v/m", "mv/m", "w/m^2", "npa",
               "km", "counts/s", "counts", "k", "w m^-2", "v", "ma",
               "particles/(cm2 s sr kev)", "1/(cm2 s sr kev)", "ergs/cm2-s"}

# Parameter name patterns that indicate timeseries (fallback when units don't match)
_GOOD_NAME_PATTERNS = {"mag", "field", "vel", "dens", "temp", "flux", "pres",
                       "speed", "flow", "intensity", "power", "energy"}

# Parameter names/patterns to avoid — flags, status, quality, support data
_BAD_PATTERNS = {"flag", "status", "quality", "mode", "range", "gap",
                 "label", "delta", "error", "sigma", "weight",
                 "sector", "channel", "bin", "index"}


# ── MCP tool helpers ─────────────────────────────────────────────────────────

def _call_tool_sync(server, name: str, args: dict) -> str:
    """Call an MCP tool synchronously, return the text result."""
    async def _call():
        result = await server.call_tool(name, args)
        blocks = result[0] if isinstance(result, tuple) else result
        if isinstance(blocks, list) and blocks:
            return blocks[0].text
        return str(blocks)
    return asyncio.run(_call())


# ── Parameter selection (the "LLM brain") ────────────────────────────────────

def pick_dataset(prompt_text: str) -> dict | None:
    """Pick the best dataset from the observatory prompt text.

    Prefers: mag > plasma > particles > anything else.
    Within category, prefers datasets with wider time coverage.
    """
    lines = prompt_text.split("\n")
    datasets = []
    current_section = ""

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("### "):
            current_section = stripped[4:].strip().lower()
        if stripped.startswith("- **") and "**:" in stripped:
            ds_id = stripped.split("**")[1]
            # Extract coverage
            coverage_start = ""
            coverage_stop = ""
            for subsequent in lines[lines.index(line):lines.index(line) + 3]:
                if "Coverage:" in subsequent:
                    parts = subsequent.split("Coverage:")[1].strip()
                    if " to " in parts:
                        coverage_start, coverage_stop = parts.split(" to ", 1)
                        coverage_start = coverage_start.strip()
                        coverage_stop = coverage_stop.strip()
                    break

            # Priority score: mag=4, plasma=3, particles=2, other=1
            section = current_section
            priority = 1
            if any(k in section for k in ("mag", "magnetic")):
                priority = 4
            elif any(k in section for k in ("plasma", "solar wind")):
                priority = 3
            elif any(k in section for k in ("particle", "energetic", "cosmic")):
                priority = 2

            # Coverage duration bonus
            try:
                dt_start = _parse_date(coverage_start)
                dt_stop = _parse_date(coverage_stop)
                years = (dt_stop - dt_start).days / 365.25
                coverage_score = min(years / 10, 1.0)  # cap at 10 years
            except Exception:
                coverage_score = 0

            datasets.append({
                "dataset_id": ds_id,
                "section": section,
                "priority": priority,
                "coverage_score": coverage_score,
                "start_date": coverage_start,
                "stop_date": coverage_stop,
            })

    if not datasets:
        return None

    # Sort by priority desc, then coverage desc
    datasets.sort(key=lambda d: (d["priority"], d["coverage_score"]), reverse=True)
    return datasets[0]


def pick_parameter(params: list[dict]) -> str | None:
    """Pick the best timeseries parameter from a browse_parameters result.

    Strategy:
    1. Prefer parameters with recognized physics units (nT, km/s, etc.)
    2. Among those, prefer names matching known timeseries patterns
    3. Avoid flags, status, quality, support data
    4. Prefer vector fields (size > 1) over scalars
    5. Fall back to first parameter with type=double/float
    """
    if not params:
        return None

    scored = []
    for p in params:
        name = p.get("name", "")
        name_lower = name.lower()
        units = (p.get("units", "") or "").lower().strip()
        ptype = (p.get("type", "") or "").lower()

        # Skip bad patterns
        if any(bad in name_lower for bad in _BAD_PATTERNS):
            continue

        # Skip non-numeric types
        if ptype and ptype not in ("double", "float", "real4", "real8", "int2", "int4", "integer"):
            continue

        score = 0

        # Units match
        if units and any(u in units for u in _GOOD_UNITS):
            score += 10

        # Name match
        if any(pat in name_lower for pat in _GOOD_NAME_PATTERNS):
            score += 5

        # Vector bonus
        size = p.get("size", [])
        if isinstance(size, list) and size and size[0] > 1:
            score += 2

        # Has description (better documented = more likely real data)
        if p.get("description"):
            score += 1

        # Numeric type bonus
        if ptype in ("double", "float", "real8"):
            score += 1

        scored.append((score, name))

    if not scored:
        # Fallback: first double/float parameter
        for p in params:
            ptype = (p.get("type", "") or "").lower()
            if ptype in ("double", "float", "real8", "real4"):
                return p["name"]
        # Last resort: first parameter
        return params[0]["name"]

    scored.sort(key=lambda x: -x[0])
    return scored[0][1]


def _parse_date(s: str) -> datetime:
    s = s.strip()
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(s.rstrip("Z"), fmt.rstrip("Z"))
        except ValueError:
            continue
    return datetime.strptime(s[:10], "%Y-%m-%d")


# ── Per-observatory test ─────────────────────────────────────────────────────

def test_observatory(obs_id: str, obs_name: str) -> dict:
    """Run the full MCP workflow for one observatory."""
    from cdawebmcp.server import create_server

    t0 = time.monotonic()
    steps_completed = []

    try:
        server = create_server()

        # Step 1: load_observatory
        prompt = _call_tool_sync(server, "load_observatory", {"observatory_id": obs_id})
        steps_completed.append("load_observatory")

        if "Dataset Catalog" not in prompt:
            return _result(obs_id, obs_name, "no_catalog",
                           "load_observatory returned no dataset catalog", steps_completed, t0)

        # Step 2: Pick a dataset from the prompt
        ds = pick_dataset(prompt)
        if not ds:
            return _result(obs_id, obs_name, "no_dataset",
                           "Could not pick a dataset from prompt", steps_completed, t0)

        dataset_id = ds["dataset_id"]
        steps_completed.append(f"picked:{dataset_id}")

        # Step 3: browse_parameters
        params_json = _call_tool_sync(server, "browse_parameters",
                                       {"dataset_id": dataset_id})
        params_result = json.loads(params_json)
        steps_completed.append("browse_parameters")

        if params_result.get("status") != "success":
            return _result(obs_id, obs_name, "no_params",
                           f"{dataset_id}: browse_parameters failed: {params_result.get('message', '?')}",
                           steps_completed, t0)

        params = params_result.get("parameters", [])
        if not params:
            return _result(obs_id, obs_name, "no_params",
                           f"{dataset_id}: no parameters returned",
                           steps_completed, t0)

        # Step 4: Pick a parameter
        param_name = pick_parameter(params)
        if not param_name:
            return _result(obs_id, obs_name, "no_params",
                           f"{dataset_id}: could not pick a sensible parameter",
                           steps_completed, t0)
        steps_completed.append(f"picked:{param_name}")

        # Step 5: fetch_data (1 hour, start + 1 day)
        start_str = ds.get("start_date", "")
        if not start_str:
            return _result(obs_id, obs_name, "empty",
                           f"{dataset_id}: no start_date", steps_completed, t0)

        start_dt = _parse_date(start_str) + timedelta(days=1)
        stop_dt = start_dt + timedelta(hours=1)
        start_iso = start_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        stop_iso = stop_dt.strftime("%Y-%m-%dT%H:%M:%SZ")

        with tempfile.TemporaryDirectory(prefix="mcp_test_") as tmpdir:
            fetch_json = _call_tool_sync(server, "fetch_data", {
                "dataset_id": dataset_id,
                "parameters": [param_name],
                "start": start_iso,
                "stop": stop_iso,
                "output_dir": tmpdir,
            })
            fetch_result = json.loads(fetch_json)
            steps_completed.append("fetch_data")

            if fetch_result.get("status") != "success":
                msg = fetch_result.get("message", "")
                if not msg:
                    pm = fetch_result.get("parameters", {})
                    for pid, pinfo in pm.items():
                        if pinfo.get("status") == "error":
                            msg = pinfo.get("message", "unknown")
                            break
                return _result(obs_id, obs_name, _classify_error(msg),
                               f"{dataset_id}/{param_name}: {msg}", steps_completed, t0)

            # Step 6: Verify output file
            file_path = fetch_result.get("file_path", "")
            if not file_path or not Path(file_path).exists():
                return _result(obs_id, obs_name, "no_file",
                               f"Output file not found: {file_path}", steps_completed, t0)

            file_size = Path(file_path).stat().st_size
            total_rows = fetch_result.get("total_rows", 0)
            steps_completed.append(f"verified:{total_rows}rows,{file_size}bytes")

            # Extract stats for detail
            param_info = fetch_result.get("parameters", {}).get(param_name, {})
            stats = param_info.get("stats", {})

            return _result(obs_id, obs_name, "pass",
                           f"{dataset_id}/{param_name}: {total_rows} rows, "
                           f"{file_size} bytes, stats={json.dumps(stats)[:200]}",
                           steps_completed, t0)

    except Exception as e:
        return _result(obs_id, obs_name, _classify_error(str(e)),
                       str(e)[:400], steps_completed, t0)


def _result(obs_id, obs_name, status, detail, steps, t0):
    return {
        "observatory_id": obs_id,
        "observatory_name": obs_name,
        "status": status,
        "detail": detail,
        "steps": steps,
        "elapsed_seconds": round(time.monotonic() - t0, 2),
        "timestamp": datetime.now(UTC).isoformat(),
    }


def _classify_error(msg: str) -> str:
    msg_lower = msg.lower()
    if "length of values" in msg_lower and "does not match" in msg_lower:
        return "epoch_mismatch"
    if "no cdf files" in msg_lower or "no data" in msg_lower:
        return "empty"
    if "timeout" in msg_lower or "timed out" in msg_lower:
        return "timeout"
    if "403" in msg or "forbidden" in msg_lower:
        return "forbidden"
    if "404" in msg or "not found" in msg_lower:
        return "download_error"
    if any(x in msg for x in ("500", "502", "503", "HTTPError")):
        return "server_error"
    if "variable" in msg_lower and "not found" in msg_lower:
        return "parse_error"
    return "other"


# ── Report ───────────────────────────────────────────────────────────────────

def get_latest_report() -> Path | None:
    if not REPORTS_DIR.exists():
        return None
    reports = sorted(REPORTS_DIR.glob("mcp_workflow_*.json"))
    return reports[-1] if reports else None


def save_report(path: Path, results: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(results, f, indent=2)


def print_summary(results: list[dict]) -> None:
    total = len(results)
    if total == 0:
        print("No results.")
        return

    counts = Counter(r["status"] for r in results)
    order = ["pass", "empty", "no_catalog", "no_dataset", "no_params",
             "forbidden", "download_error", "server_error", "parse_error",
             "epoch_mismatch", "timeout", "no_file", "other"]
    print(f"\n{'═' * 60}")
    print(f"  MCP Workflow Test: {total} observatories")
    print(f"{'═' * 60}")
    for status in order:
        c = counts.get(status, 0)
        if c > 0:
            pct = 100 * c / total
            print(f"  {status:20s} {c:3d}  ({pct:5.1f}%)")
    print(f"{'─' * 60}")

    elapsed = [r["elapsed_seconds"] for r in results]
    print(f"  Total elapsed:  {sum(elapsed):.0f}s")
    print(f"  Avg per obs:    {sum(elapsed) / total:.1f}s")
    print()

    # Show failures
    failures = [r for r in results if r["status"] != "pass"]
    if failures:
        print(f"  Failures ({len(failures)}):")
        for f in failures:
            print(f"    {f['observatory_id']:40s} {f['status']:15s} {f['detail'][:70]}")
        print()

    # Show passes with details
    passes = [r for r in results if r["status"] == "pass"]
    if passes:
        print(f"  Passes ({len(passes)}):")
        for p in passes:
            steps = p["steps"]
            dataset = next((s.split(":", 1)[1] for s in steps if s.startswith("picked:") and "/" not in s), "?")
            param = next((s.split(":", 1)[1] for s in steps if s.startswith("picked:") and s != f"picked:{dataset}"), "?")
            print(f"    {p['observatory_id']:40s} {dataset:40s} {param}")
        print()


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="MCP workflow smoke test")
    parser.add_argument("--observatory", help="Test only this observatory")
    parser.add_argument("--workers", type=int, default=6, help="Parallel workers (default 6)")
    parser.add_argument("--report", action="store_true", help="Print summary of latest report")
    args = parser.parse_args()

    if args.report:
        rpt = get_latest_report()
        if not rpt:
            print("No reports found.")
            return
        print(f"Report: {rpt}")
        print_summary(json.load(open(rpt)))
        return

    # Get observatory list
    from cdawebmcp.catalog import browse_observatories
    obs_list = browse_observatories()
    if args.observatory:
        obs_list = [o for o in obs_list if o["id"] == args.observatory]
        if not obs_list:
            print(f"Observatory '{args.observatory}' not found.")
            return

    total = len(obs_list)
    print(f"Testing {total} observatories, {args.workers} workers")
    print()

    ts = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    report_path = REPORTS_DIR / f"mcp_workflow_{ts}.json"

    results = []
    completed = [0]
    interrupted = False

    def signal_handler(sig, frame):
        nonlocal interrupted
        interrupted = True
        print("\nInterrupted — saving report...")

    signal.signal(signal.SIGINT, signal_handler)

    def run_one(obs):
        if interrupted:
            return None
        result = test_observatory(obs["id"], obs["name"])
        completed[0] += 1
        n = completed[0]
        tag = "PASS" if result["status"] == "pass" else result["status"].upper()
        print(f"  [{n:2d}/{total}] {obs['id']:40s} {tag:20s} ({result['elapsed_seconds']:.1f}s)")
        return result

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(run_one, obs): obs for obs in obs_list}
        for future in as_completed(futures):
            if interrupted:
                break
            try:
                r = future.result()
                if r:
                    results.append(r)
            except Exception as e:
                obs = futures[future]
                print(f"  FATAL: {obs['id']}: {e}")

    save_report(report_path, results)
    print_summary(results)
    print(f"Report saved: {report_path}")


if __name__ == "__main__":
    main()
