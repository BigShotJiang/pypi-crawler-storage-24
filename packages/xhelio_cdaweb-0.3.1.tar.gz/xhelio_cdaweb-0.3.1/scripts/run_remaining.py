#!/usr/bin/env python
"""Run test_all_datasets in observatory-sized batches via subprocess.

Each observatory runs in its own subprocess, so memory leaks from
timed-out daemon threads don't accumulate.
"""
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

REPORTS_DIR = Path(__file__).resolve().parent.parent / "reports"


def get_remaining_observatories():
    """Find observatories with untested datasets."""
    # Load current results
    reports = sorted(REPORTS_DIR.glob("fetch_test_*.json"))
    if not reports:
        print("No reports found")
        sys.exit(1)
    report_path = reports[-1]
    with open(report_path) as f:
        results = json.load(f)
    done_ids = {r["dataset_id"] for r in results}

    # Load all datasets
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from test_all_datasets import enumerate_datasets

    datasets = enumerate_datasets()
    remaining = {}
    for d in datasets:
        if d["dataset_id"] not in done_ids:
            obs = d["observatory"]
            remaining.setdefault(obs, []).append(d["dataset_id"])

    return remaining, report_path


def main():
    remaining, report_path = get_remaining_observatories()
    total_remaining = sum(len(ds) for ds in remaining.values())
    print(f"Report: {report_path.name}")
    print(f"Remaining: {total_remaining} datasets across {len(remaining)} observatories")
    print()

    for obs in sorted(remaining):
        count = len(remaining[obs])
        print(f"── {obs} ({count} datasets) ──")
        result = subprocess.run(
            [sys.executable, "scripts/test_all_datasets.py",
             "--resume", "--observatory", obs, "--workers", "3"],
            capture_output=False,
            timeout=count * 90 + 60,  # 90s per dataset + 60s overhead
        )
        if result.returncode != 0:
            print(f"  WARNING: {obs} exited with code {result.returncode}")
        print()

    # Print final summary
    with open(report_path) as f:
        results = json.load(f)
    print(f"\n{'═' * 50}")
    print(f"FINAL: {len(results)} datasets tested")
    counts = Counter(r["status"] for r in results)
    for status, c in counts.most_common():
        pct = 100 * c / len(results)
        print(f"  {status:20s} {c:5d}  ({pct:5.1f}%)")


if __name__ == "__main__":
    main()
