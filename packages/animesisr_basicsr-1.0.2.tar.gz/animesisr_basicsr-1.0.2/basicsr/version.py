# GENERATED VERSION FILE
# TIME: Mon Mar 23 12:48:02 2026
__version__ = '1.0.2'
__gitsha__ = '4b84bf3'
version_info = (1, 0, 2)
