#######################################################################################
# gui.py       Version 1.0     13-Mar-2026
# Taj Ballinger, Trevor Ritchie, Bill Manaris, and Dana Hughes
#######################################################################################
import numpy as np

from CreativePython.GuiHandler import _createHandler

#######################################################################################
# GuiHandler singleton and object ID allocator
#######################################################################################
# gui.py's display rendering, hit testing, and event handling is powered by Qt(PySide6).
# However, Qt's event loop blocks the python intepreter while its running.  Since Qt
# requires its event loop to be in the main thread, we offload it to a child process,
# which is managed by GuiHandler.  As a result, CreativePython's user libraries never
# need to touch Qt.
# 
# NOTE: GuiHandler's components have mirrored versions of CreativePython's visual
# objects to help with converting to Qt.  Future changes to gui's API may require
# updating those mirrored objects as well.

_GUI_HANDLER = None   # lazily created on first Display

def _handler():
   """Returns the GuiHandler singleton, creating it if needed."""
   global _GUI_HANDLER
   if _GUI_HANDLER is None:
      _GUI_HANDLER = _createHandler()
   return _GUI_HANDLER

_OBJECT_ID_COUNTER = 0

def _nextObjectId():
   """
   Returns the next unique object ID.
   GuiHandler uses this ID to decide where to route commands.
   """
   global _OBJECT_ID_COUNTER
   _OBJECT_ID_COUNTER += 1
   return _OBJECT_ID_COUNTER

#######################################################################################
# Virtual Key Constants
#######################################################################################
# Java 8 Virtual Keys -> Qt Virtual Key Codes
VK_A = 65
VK_B = 66
VK_C = 67
VK_D = 68
VK_E = 69
VK_F = 70
VK_G = 71
VK_H = 72
VK_I = 73
VK_J = 74
VK_K = 75
VK_L = 76
VK_M = 77
VK_N = 78
VK_O = 79
VK_P = 80
VK_Q = 81
VK_R = 82
VK_S = 83
VK_T = 84
VK_U = 85
VK_V = 86
VK_W = 87
VK_X = 88
VK_Y = 89
VK_Z = 90

VK_0 = 48
VK_1 = 49
VK_2 = 50
VK_3 = 51
VK_4 = 52
VK_5 = 53
VK_6 = 54
VK_7 = 55
VK_8 = 56
VK_9 = 57

VK_NUMPAD0 = 48
VK_NUMPAD1 = 49
VK_NUMPAD2 = 50
VK_NUMPAD3 = 51
VK_NUMPAD4 = 52
VK_NUMPAD5 = 53
VK_NUMPAD6 = 54
VK_NUMPAD7 = 55
VK_NUMPAD8 = 56
VK_NUMPAD9 = 57

VK_F1            = 16777264
VK_F2            = 16777265
VK_F3            = 16777266
VK_F4            = 16777267
VK_F5            = 16777268
VK_F6            = 16777269
VK_F7            = 16777270
VK_F8            = 16777271
VK_F9            = 16777272
VK_F10           = 16777273
VK_F11           = 16777274
VK_F12           = 16777275

VK_ESCAPE        = 16777216
VK_TAB           = 16777217
VK_CAPS_LOCK     = 16777252
VK_SHIFT         = 16777248
VK_CONTROL       = 16777249
VK_ALT           = 16777251
VK_SPACE         = 32
VK_ENTER         = 16777220
VK_BACK_SPACE    = 16777219
VK_DELETE        = 16777223
VK_HOME          = 16777232
VK_END           = 16777233
VK_PAGE_UP       = 16777238
VK_PAGE_DOWN     = 16777239
VK_UP            = 16777235
VK_DOWN          = 16777237
VK_LEFT          = 16777234
VK_RIGHT         = 16777236
VK_INSERT        = 16777222
VK_PAUSE         = 16777224
VK_PRINTSCREEN   = 16777225
VK_SCROLL_LOCK   = 16777254
VK_NUM_LOCK      = 16777253
VK_SEMICOLON     = 59
VK_EQUALS        = 61
VK_COMMA         = 44
VK_MINUS         = 45
VK_PERIOD        = 46
VK_SLASH         = 47
VK_BACK_SLASH    = 92
VK_OPEN_BRACKET  = 91
VK_CLOSE_BRACKET = 93
VK_QUOTE         = 39
VK_BACK_QUOTE    = 96

# Arc Constants (in degrees)
PI      = 180
HALF_PI = 90
TWO_PI  = 360

# Arc Style Constants
PIE   = 0
OPEN  = 1
CHORD = 2

# Label Alignment Constants
LEFT   = 1
CENTER = 132
RIGHT  = 2

# Widget Orientation Constants
HORIZONTAL = 1
VERTICAL   = 2


#######################################################################################
# Color
#######################################################################################
class Color:
   """
   Color constants and utilities.
   """
   def __init__(self, red=None, green=None, blue=None, alpha=None):
      """
      Creates a new Color object.
      """
      if None in (red, green, blue):
         # at least one necessary color was missing, so bring up color selection.
         red   = red   if red   is not None else 255  # replace None values with 255
         green = green if green is not None else 255
         blue  = blue  if blue  is not None else 255
         
         red, green, blue = Color.select(red, green, blue)  # get a usable color

      # store color values as 0-255 integers
      self.red   = int(red)
      self.green = int(green)
      self.blue  = int(blue)
      self.alpha = int(alpha) if alpha is not None else 255

   def __str__(self):
      return f'Color(red = {self.getRed()}, green = {self.getGreen()}, blue = {self.getBlue()}, alpha = {self.getAlpha()})'

   def __repr__(self):
      return str(self)

   def getRed(self):
      """
      Returns the Color's red value (0-255).
      """
      return self.red

   def setRed(self, red):
      """
      Sets the Color's red value (0-255).
      """
      self.red = red

   def getGreen(self):
      """
      Returns the Color's green value (0-255).
      """
      return self.green

   def setGreen(self, green):
      """
      Sets the Color's green value (0-255).
      """
      self.green = green

   def getBlue(self):
      """
      Returns the Color's blue value (0-255).
      """
      return self.blue

   def setBlue(self, blue):
      """
      Sets the Color's blue value (0-255).
      """
      self.blue = blue

   def getAlpha(self):
      """
      Returns the Color's transparency value (0-255).
      """
      return self.alpha

   def setAlpha(self, alpha):
      """
      Sets the Color's alpha value (0-255).
      """
      self.alpha = alpha

   def getRGB(self):
      """
      Returns the Color's values (0-255) as a list.
      """
      return [self.red, self.green, self.blue]

   def setRGB(self, red, green, blue):
      """
      Sets the Color's values (0-255).
      """
      self.red   = red
      self.green = green
      self.blue  = blue

   def getRGBA(self):
      """
      Returns the Color's values (0-255), including transparency, as a list.
      """
      return [self.red, self.green, self.blue, self.alpha]

   def setRGBA(self, red, green, blue, alpha):
      """
      Sets the Color's values (0-255).
      """
      self.red   = red
      self.green = green
      self.blue  = blue
      self.alpha = alpha

   def getHex(self):
      """
      Returns the Color's values as a hex string (e.g. #FF00FF).
      Includes transparency, if it's meaningful.
      """
      hex = Color.RGBtoHex(self.red, self.green, self.blue)  # base hex string
      if self.alpha != 255:
         hex += f'{self.alpha:02x}'  # add alpha if not fully opaque
      return hex

   def setHex(self, hex):
      """
      Sets the Color's values from a hex string (e.g. '#00FFAA').
      """
      red, green, blue = Color.HextoRGB(hex)
      self.setRGB(red, green, blue)

   def getHSB(self):
      """
      Returns the Color's values as a list of HSB values (e.g. [0.5, 0.3, 1.0]).
      Includes transparency, if it's meaningful.
      """
      hsb = Color.RGBtoHSB(self.red, self.green, self.blue)  # base HSB values
      if self.alpha != 255:
         hsb.append(self.alpha/255)  # add alpha if not fully opaque, converted to 0.0 - 1.0

      return hsb

   def setHSB(self, hue, saturation, brightness):
      """
      Sets the Color's values from HSB values (each 0.0 - 1.0).
      """
      red, green, blue = Color.HSBtoRGB(hue, saturation, brightness)
      self.setRGB(red, green, blue)

   def brighter(self):
      """
      Returns a Color that's 10% brighter than this one.
      """
      return Color(
         min(255, int(self.red * 1.1)),
         min(255, int(self.green * 1.1)),
         min(255, int(self.blue * 1.1)),
         self.alpha
      )

   def darker(self):
      """
      Returns a Color that's 10% darker than this one.
      """
      return Color(
         max(0, int(self.red * 0.9)),
         max(0, int(self.green * 0.9)),
         max(0, int(self.blue * 0.9)),
         self.alpha
      )

   @staticmethod
   def HSBtoRGB(hue, saturation, brightness):
      """
      Converts a HSB-model color (hue, saturation, brightness) to RGB (red, green, blue).
      HSB should be floats from 0.0 - 1.0
      """
      import colorsys
      
      # clamp HSB to 0.0 - 1.0
      hue        = max(0.0, min(1.0, hue))
      saturation = max(0.0, min(1.0, saturation))
      brightness = max(0.0, min(1.0, brightness))
      
      # convert HSB to RGB
      red, green, blue = colorsys.hsv_to_rgb(hue, saturation, brightness)
      
      # convert RGB to 0 - 255
      red   = int(red * 255)
      green = int(green * 255)
      blue  = int(blue * 255)
      
      return [red, green, blue]

   @staticmethod
   def RGBtoHSB(red, green, blue):
      """
      Converts RGB-model color (red, green, blue) to HSB (hue, saturation, brightness)
      red, green, and blue should be integers from 0 - 255.
      """
      import colorsys

      # convert RGB to 0.0 - 1.0
      red   = red / 255
      green = green / 255
      blue  = blue / 255

      # convert RGB to HSV
      hue, saturation, brightness = colorsys.rgb_to_hsv(red, green, blue)

      return [hue, saturation, brightness]

   @staticmethod
   def getHSBColor(hue, saturation, brightness):
      """
      Returns a new Color object from HSB-model values.
      hue, saturation, and brightness should be floats from 0.0 - 1.0.
      """
      red, green, blue = Color.HSBtoRGB(hue, saturation, brightness)
      return Color(red, green, blue)

   @staticmethod
   def HextoRGB(hex):
      """
      Converts a hex color to RGB (red, green, blue).
      hex should be a string like '#00FFAA'.
      """
      hexCode = hex.lstrip('#')
      color   = []

      for i in [0, 2, 4]:
         # convert to base 10 integer
         hexValue = hexCode[i:i+2]
         rgbValue = int(hexValue, 16)
         color.append(rgbValue)

      return color

   @staticmethod
   def RGBtoHex(red, green, blue):
      """
      Converts an RGB color to hex.
      red, green, and blue should be integers from 0 - 255.
      """

      hexCode = "#"

      for color in [red, green, blue]:
         # convert to base 16 string
         hexCode.join(f"{color:02x}")

      return hexCode

   @staticmethod
   def getHexColor(hex):
      """
      Returns a new Color object from a Hex value.
      Hex can be any of these formats:
         #RRGGBB
         #RRGGBBAA
         #RGB
         #RGBA
      """
      red, green, blue = Color.HextoRGB(hex)

      return Color(red, green, blue)

   @staticmethod
   def select(r=255, g=255, b=255):
      """
      Opens a color picker dialog and returns the selected (r, g, b) values.
      If r, g, or b are set, the picker will start with those values.
      Returns color values as a (r, g, b) tuple.
      """
      r, g, b = _handler().sendQuery('colorDialog', None, {'initial': [r, g, b, 255]})
      return r, g, b

   @staticmethod
   def gradient(startColor, endColor, steps):
      """
      Returns a list of Colors creating a "smooth" gradient between 'startColor' and
      'endColor'.  The amount of smoothness is determined by 'steps', which specifies
      how many intermediate colors to create. The result includes 'startColor' but not
      'endColor' to allow for connecting one gradient to another (without duplication
      of colors).
      startColor and endColor can be Color objects or [r,g,b] lists.
      """
      gradientList = []   # holds RGB lists of individual gradient colors

      # extract colors to RGB values
      if isinstance(startColor, Color):
         red1, green1, blue1 = startColor.getRGB()
      elif isinstance(startColor, list):
         red1, green1, blue1 = startColor
      else:
         raise ValueError(f"colorGradient(): startColor should be a Color object or [r,g,b] list (it was a {str(type(startColor))})")

      if isinstance(endColor, Color):
         red2, green2, blue2 = endColor.getRGB()
      elif isinstance(endColor, list):
         red2, green2, blue2 = endColor
      else:
         raise ValueError(f"colorGradient(): endColor should be a Color object or [r,g,b] list (it was a {str(type(endColor))})")

      # find difference between color extremes
      differenceR = red2   - red1     # R component
      differenceG = green2 - green1   # G component
      differenceB = blue2  - blue1    # B component

      # interpolate RGB values between extremes
      for i in range(steps):
         gradientR = red1   + i * differenceR / steps
         gradientG = green1 + i * differenceG / steps
         gradientB = blue1  + i * differenceB / steps

         # ensure color values are integers
         gradientList.append([int(gradientR), int(gradientG), int(gradientB)])
      # now, gradient list contains all the intermediate colors, including color1
      # but not color2

      # if input was Color objects (e.g., Color.RED), return Color objects
      # otherwise, keep as RGB lists (e.g., [255, 0, 0]
      if isinstance(startColor, Color):
         gradientList = [Color(rgb[0], rgb[1], rgb[2]) for rgb in gradientList]

      return gradientList

# alias colorGradient for backwards compatibility
colorGradient = Color.gradient

# Color constants, for convenience
Color.BLACK      = Color(  0,   0,   0)
Color.BLUE       = Color(  0,   0, 255)
Color.CYAN       = Color(  0, 255, 255)
Color.DARK_GRAY  = Color( 44,  44,  44)
Color.GRAY       = Color(128, 128, 128)
Color.GREEN      = Color(  0, 255,   0)
Color.LIGHT_GRAY = Color(211, 211, 211)
Color.MAGENTA    = Color(255,   0, 255)
Color.ORANGE     = Color(255, 165,   0)
Color.PINK       = Color(255, 192, 203)
Color.PURPLE     = Color(128,   0, 128)
Color.RED        = Color(255,   0,   0)
Color.WHITE      = Color(255, 255, 255)
Color.YELLOW     = Color(255, 255,   0)
Color.CLEAR      = Color(  0,   0,   0,   0)


########################################################################################
# Font
########################################################################################
class Font:
   """
   Font descriptor for Label, TextField, and TextArea.
   """
   PLAIN      = (400, False)  # (Weight, Italic)
   BOLD       = (700, False)  # Weight values are from QtGui.QFont.Weight
   ITALIC     = (400, True)
   BOLDITALIC = (700, True)

   def __init__(self, name, style=PLAIN, size=-1):
      """
      Creates a new Font object.
      """
      self._name  = name
      self._style = style
      self._size  = size

   def __str__(self):
      return f'Font(name = "{self.getName()}", style = {self.getStyle()}, size = {self.getSize()}")'

   def __repr__(self):
      return str(self)

   def getName(self):
      """
      Returns the Font's family name as a string.
      """
      return self._name

   def setName(self, name):
      """
      Sets the Font's family name.
      """
      self._name = name

   def getStyle(self):
      """
      Returns the Font's style as a tuple.
      The first value represents the Font's weight.
      The second value represents whether the Font is italicized.
      """
      return self._style

   def setStyle(self, style):
      """
      Sets the Font's style.
      """
      self._style = style

   def getSize(self):
      """
      Returns the Font's point size.
      """
      return self._size

   def setSize(self, size):
      """
      Sets the Font's point size.
      """
      self._size = size


#######################################################################################
# Interactable - items that can trigger events
#######################################################################################
class _Interactable:
   """
   Superclass that provides event/callback support.
   """
   def __init__(self):
      self._objectId = _nextObjectId()
      self._actionList = {}

   def _registerCallback(self, eventType, action):
      """
      Registers a single event callback via IPC to the renderer process.
      """
      self._actionList[eventType] = action
      _handler().registerEvent(self._objectId, eventType, action)

   def onMouseClick(self, action):
      """
      Registers a callback function for mouse clicks events (down, then up).
      The function should accept two parameters, an x and y coordinate.
      """
      self._registerCallback('mouseClick', action)

   def onMouseDown(self, action):
      """
      Registers a callback function for mouse button down events.
      The function should accept two parameters, an x and y coordinate.
      """
      self._registerCallback('mouseDown', action)

   def onMouseUp(self, action):
      """
      Registers a callback function for mouse button up events.
      The function should accept two parameters, an x and y coordinate.
      """
      self._registerCallback('mouseUp', action)

   def onMouseMove(self, action):
      """
      Registers a callback function for mouse move events.
      The function should accept two parameters, an x and y coordinate.
      """
      self._registerCallback('mouseMove', action)

   def onMouseDrag(self, action):
      """
      Registers a callback function for mouse drag events (moving with mouse down).
      The function should accept two parameters, an x and y coordinate.
      """
      self._registerCallback('mouseDrag', action)

   def onMouseEnter(self, action):
      """
      Registers a callback function for mouse enter events (enter the item's space).
      The function should accept two parameters, an x and y coordinate.
      """
      self._registerCallback('mouseEnter', action)

   def onMouseExit(self, action):
      """
      Registers a callback function for mouse exit events (exit the item's space).
      The function should accept two parameters, an x and y coordinate.
      """
      self._registerCallback('mouseExit', action)

   def onKeyType(self, action):
      """
      Registers a callback function for key type events.
      The function should accept one parameter, the typed character.
      """
      self._registerCallback('keyType', action)

   def onKeyDown(self, action):
      """
      Registers a callback function for key down events.
      The function should accept one parameter, the key's code.
      """
      self._registerCallback('keyDown', action)

   def onKeyUp(self, action):
      """
      Registers a callback function for key up events.
      The function should accept one parameter, the key's code.
      """
      self._registerCallback('keyUp', action)

#######################################################################################
class Display(_Interactable):
   """
   Top-level window and drawing canvas.  Use to draw shapes, images, text, and
   controls; handle mouse/keyboard events; and manage on-screen items.
   """

   def __init__(self, title="", width=600, height=400, x=0, y=50, color=Color.WHITE):
      """
      Creates a new display window with given title, size, position, and background color.
      """
      _Interactable.__init__(self)

      # initialize internal properties
      self._itemList         = []     # list of items in this display (front=top)
      self._toolTipText      = None   # tooltip text for this display
      self._showCoordinates  = False  # show mouse coordinates in tooltip?
      self._title            = title
      self._width            = width
      self._height           = height
      self._color            = color.getRGBA()

      # create display in the renderer child process
      _handler().sendCommand('create', self._objectId, {
         'type':   'Display',
         'title':  title,
         'width':  width,
         'height': height,
         'x':      x,
         'y':      y,
         'color':  color.getRGBA(),
      })

   def __str__(self):
      r, g, b, a = self._color
      return f'Display(title = "{self._title}", width = {self._width}, height = {self._height}, color = Color({r}, {g}, {b}, {a}))'

   def show(self):
      """
      Shows the display window.
      """
      _handler().sendCommand('show', self._objectId)

   def hide(self):
      """
      Hides the display window.
      """
      _handler().sendCommand('hide', self._objectId)

   def close(self):
      """
      Closes the display window.
      """
      if 'onClose' in self._actionList:
         action = self._actionList['onClose']
         if callable(action):
            action()

      _handler().sendCommand('close', self._objectId)
      self.removeAll()

   def add(self, item, x=None, y=None):
      """
      Adds an item to the display at its current or specified position.
      Removes the item from other Groups or Displays first.
      """
      self.addOrder(item, 0, x, y)  # use logic from addOrder()

   def addOrder(self, item, order, x=None, y=None):
      """
      Adds an item to the display at the specified order and position.
      Removes the item from other Groups or Displays first.
      """
      if not isinstance(item, _Drawable):
         raise TypeError(f'{type(self).__name__}.addOrder(): item should be a Drawable object (it was {type(item).__name__})')

      if item._parent is not None:
         item._parent.remove(item)
      item._parent = self

      order = max(0, min(len(self._itemList), order))
      self._itemList.insert(order, item)

      # send add command to renderer (mirror handles z-ordering)
      _handler().sendCommand('addOrder', self._objectId, {
         'itemId': item._objectId,
         'order':  order,
         'x':      x,
         'y':      y,
      })

      # set item position locally (so gui.py state stays in sync)
      if x is not None:
         item.setX(x)
      if y is not None:
         item.setY(y)

   def remove(self, item):
      """
      Removes an item from the display.
      """
      if item in self._itemList:
         item._parent = None
         self._itemList.remove(item)
         _handler().sendCommand('remove', self._objectId, {
            'itemId': item._objectId,
         })

   def removeAll(self):
      """
      Removes all items from the display.
      """
      for item in list(self._itemList):
         item._parent = None
      self._itemList.clear()
      _handler().sendCommand('removeAll', self._objectId)

   def move(self, item, x, y):
      """
      Moves an item to the given coordinates.
      """
      if item in self._itemList:  # skip if item not on Display
         item.setPosition(x, y)   # move item

   def getOrder(self, item):
      """
      Returns the drawing order (z-index) for an item on the display.
      """
      order = None

      if item in self._itemList:  # skip if item not on Display
         order = self._itemList.index(item)

      return order

   def setOrder(self, item, order):
      """
      Sets the drawing order (z-index) for an item on the display.
      """
      if item in self._itemList:  # skip if item not on Display
         self.addOrder(item, order)  # remove and re-add item at desired order

   def setToolTipText(self, text=None):
      """
      Sets the display's tooltip text (None clears it).
      """
      self._toolTipText = text
      _handler().sendCommand('setToolTipText', self._objectId, {'text': text})

   def showMouseCoordinates(self):
      """
      Shows a tooltip with live mouse coordinates.
      """
      self._showCoordinates = True
      _handler().sendCommand('showMouseCoordinates', self._objectId)

   def hideMouseCoordinates(self):
      """
      Hides the mouse coordinate tooltip.
      """
      self._showCoordinates = False
      _handler().sendCommand('hideMouseCoordinates', self._objectId)

   def getColor(self):
      """
      Returns the display's background color.
      """
      r, g, b, a = self._color
      return Color(r, g, b, a)

   def setColor(self, color=None):
      """
      Sets the display's background color.
      """
      if color is None:
         r, g, b = Color.select()
         color = Color(r, g, b)

      if isinstance(color, Color):
         r, g, b, a = color.getRGBA()
      else:
         raise TypeError(f'{type(self).__name__}.setColor(): color should be a Color object (it was {type(color).__name__})')

      self._color = [r, g, b, a]
      _handler().sendCommand('setColor', self._objectId, {'color': [r, g, b, a]})

   def getTitle(self):
      """
      Returns the display's window title.
      """
      return self._title

   def setTitle(self, title):
      """
      Sets the display's  window title.
      """
      self._title = title
      _handler().sendCommand('setTitle', self._objectId, {'title': title})

   def getWidth(self):
      """
      Returns the display's canvas width (in pixels).
      """
      width, _ = self.getSize()
      return width

   def setWidth(self, width):
      """
      Sets the display's canvas width (in pixels).
      """
      self.setSize(width, self.getHeight())

   def getHeight(self):
      """
      Returns the display's canvas height (in pixels).
      """
      _, height = self.getSize()
      return height

   def setHeight(self, height):
      """
      Sets the display's canvas height (in pixels).
      """
      self.setSize(self.getWidth(), height)

   def getSize(self):
      """
      Returns the display's canvas dimensions (in pixels).
      """
      return self._width, self._height

   def setSize(self, width, height):
      """
      Sets the display's canvas dimensions (in pixels).
      """
      if (width <= 0) or (height <= 0):
         print(f"{type(self).__name__}.setSize(): width and height should be positive, non-zero integers (they were {width} and {height}).")
      else:
         self._width  = width
         self._height = height
         _handler().sendCommand('setSize', self._objectId, {'width': width, 'height': height})

   def getPosition(self):
      """
      Returns the display's window position on the screen.
      """
      result = _handler().sendQuery('getPosition', self._objectId)
      return result[0], result[1]

   def setPosition(self, x, y):
      """
      Moves the display's window on the screen.
      """
      _handler().sendCommand('setPosition', self._objectId, {'x': int(x), 'y': int(y)})

   def getItems(self):
      """
      Returns a list of items in the display.
      """
      from copy import copy
      return copy(self._itemList)

   def addMenu(self, menu):
      """
      Attaches a top-level menu to the display's menu bar.
      """
      if not isinstance(menu, Menu):
         raise TypeError(f'{type(self).__name__}.addMenu(): menu should be a Menu object (it was {type(menu).__name__})')
      _handler().sendCommand('addMenu', self._objectId, {'menuId': menu._objectId})

   def addPopupMenu(self, menu):
      """
      Attaches a context (right-click) menu to the display.
      """
      if not isinstance(menu, Menu):
         raise TypeError(f'{type(self).__name__}.addPopupMenu(): menu should be a Menu object (it was {type(menu).__name__})')
      _handler().sendCommand('addPopupMenu', self._objectId, {'menuId': menu._objectId})

   def write(self, filename, width=None, height=None):
      """
      Saves the display's currently visible canvas to an image file.
      The file format is determined by the filename extension (e.g. .png, .jpg).
      Optional width and height resize the saved image; omitting one preserves the aspect ratio.
      Prints whether the write succeeded and the resolved file path.
      """
      result = _handler().sendQuery('write', self._objectId, {'filename': filename, 'width': width, 'height': height})
      success, resolvedPath = result[0], result[1]
      if success:
         print(f'{type(self).__name__}.write(): saved to "{resolvedPath}"')
      else:
         print(f'{type(self).__name__}.write(): failed to save "{resolvedPath}"')

   def onClose(self, action):
      """
      Registers a callback function for window close events.
      The function should accept no parameters.
      """
      self._actionList['displayClose'] = action

   # ── Draw Methods ────────────────────────────────────────────────────────────────
   # These methods draw a shape directly to the canvas without returning an object.
   # Since there's no object to manage, these methods are very fast to render, and are
   # ideal for drawing shapes that you don't intend on altering later.

   def clearDrawing(self):
      """
      Clears all shapes painted with draw<X>() methods from the display.
      Does not affect objects added with add().
      """
      _handler().sendCommand('clearDrawing', self._objectId)

   def drawRectangle(self, x1, y1, x2, y2, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Paints a rectangle onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      _handler().sendCommand('draw', self._objectId, {
         'shape':     'rectangle',
         'x':         min(x1, x2),
         'y':         min(y1, y2),
         'width':     abs(x1 - x2),
         'height':    abs(y1 - y2),
         'color':     color.getRGBA(),
         'fill':      bool(fill),
         'thickness': int(thickness),
         'rotation':  rotation,
      })

   def drawOval(self, x1, y1, x2, y2, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Paints an oval onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      _handler().sendCommand('draw', self._objectId, {
         'shape':     'oval',
         'x':         min(x1, x2),
         'y':         min(y1, y2),
         'width':     abs(x1 - x2),
         'height':    abs(y1 - y2),
         'color':     color.getRGBA(),
         'fill':      bool(fill),
         'thickness': int(thickness),
         'rotation':  rotation,
      })

   def drawCircle(self, x, y, radius, color=Color.BLACK, fill=False, thickness=1):
      """
      Paints a circle onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      diameter = radius * 2
      _handler().sendCommand('draw', self._objectId, {
         'shape':     'circle',
         'x':         x - radius,
         'y':         y - radius,
         'width':     diameter,
         'height':    diameter,
         'color':     color.getRGBA(),
         'fill':      bool(fill),
         'thickness': int(thickness),
         'rotation':  0,
      })

   def drawPoint(self, x, y, color=Color.BLACK):
      """
      Paints a point onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      _handler().sendCommand('draw', self._objectId, {
         'shape':     'point',
         'x':         x - 1,
         'y':         y - 1,
         'width':     2,
         'height':    2,
         'color':     color.getRGBA(),
         'fill':      True,
         'thickness': 1,
         'rotation':  0,
      })

   def drawArc(self, x1, y1, x2, y2, startAngle=PI, endAngle=TWO_PI, style=OPEN, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Paints an arc onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      _handler().sendCommand('draw', self._objectId, {
         'shape':      'arc',
         'x':          min(x1, x2),
         'y':          min(y1, y2),
         'width':      abs(x1 - x2),
         'height':     abs(y1 - y2),
         'startAngle': startAngle,
         'endAngle':   endAngle,
         'style':      style,
         'color':      color.getRGBA(),
         'fill':       bool(fill),
         'thickness':  int(thickness),
         'rotation':   rotation,
      })

   def drawArcCircle(self, x, y, radius, startAngle=PI, endAngle=TWO_PI, style=OPEN, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Paints an arc of a circle onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      diameter = radius * 2
      _handler().sendCommand('draw', self._objectId, {
         'shape':      'arc',
         'x':          x - radius,
         'y':          y - radius,
         'width':      diameter,
         'height':     diameter,
         'startAngle': startAngle,
         'endAngle':   endAngle,
         'style':      style,
         'color':      color.getRGBA(),
         'fill':       bool(fill),
         'thickness':  int(thickness),
         'rotation':   rotation,
      })

   def drawPolyline(self, xPoints, yPoints, color=Color.BLACK, thickness=1, rotation=0):
      """
      Paints a polyline onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      _handler().sendCommand('draw', self._objectId, {
         'shape':     'polyline',
         'xPoints':   list(xPoints),
         'yPoints':   list(yPoints),
         'color':     color.getRGBA(),
         'thickness': int(thickness),
         'rotation':  rotation,
      })

   def drawLine(self, x1, y1, x2, y2, color=Color.BLACK, thickness=1, rotation=0):
      """
      Paints a line onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      _handler().sendCommand('draw', self._objectId, {
         'shape':     'line',
         'x1':        x1,
         'y1':        y1,
         'x2':        x2,
         'y2':        y2,
         'color':     color.getRGBA(),
         'thickness': int(thickness),
         'rotation':  rotation,
      })

   def drawPolygon(self, xPoints, yPoints, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Paints a polygon onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      _handler().sendCommand('draw', self._objectId, {
         'shape':     'polygon',
         'xPoints':   list(xPoints),
         'yPoints':   list(yPoints),
         'color':     color.getRGBA(),
         'fill':      bool(fill),
         'thickness': int(thickness),
         'rotation':  rotation,
      })

   def drawIcon(self, filename, x, y, width=None, height=None, rotation=0):
      """
      Paints an image file onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      _handler().sendCommand('draw', self._objectId, {
         'shape':    'icon',
         'filename': filename,
         'x':        x,
         'y':        y,
         'width':    width,
         'height':   height,
         'rotation': rotation,
      })

   def drawLabel(self, text, x, y, color=Color.BLACK, font=None):
      """
      Paints a text label onto the display's draw layer.
      Unlike add(), this is a one-time paint — no object is created or returned.
      The result is permanent until clearDrawing() is called.
      """
      fontData = None
      if isinstance(font, Font):
         fontData = [font.getName(), font.getStyle(), font.getSize()]

      _handler().sendCommand('draw', self._objectId, {
         'shape': 'label',
         'text':  str(text),
         'x':     x,
         'y':     y,
         'color': color.getRGBA(),
         'font':  fontData,
      })


#######################################################################################
# Drawable - items that can be added to a Display
#######################################################################################
class _Drawable(_Interactable):
   """
   Superclass for all items that can be added to a Display.
   Handles geometric attributes, such as position, size, and hit testing.
   """
   def __init__(self):
      """
      Initializes drawable state (position, size, rotation).
      """
      _Interactable.__init__(self)

      self._parent         = None  # Display or Group this item is on/in, if any

      # our rendering engine applies rotation as a secondary transform,
      # after considering object position and size.  Our user-facing methods
      # give post-rotation values, so we cache the pre-rotation values internally.
      self._localCornerX   = 0     # top-left corner, relative to parent
      self._localCornerY   = 0     # ...
      self._width          = 0     # horizontal dimension
      self._height         = 0     # vertical dimension
      self._rotation       = 0     # rotation angle in degrees (CCW, start @ 3 o'clock), always around center
      self._anchorX        = None  # last used global rotation anchor (None = center)
      self._anchorY        = None  # ...
      self._toolTipText    = None  # text to Display on mouse over (None == disabled)

      # renderer visibility toggle
      # only used by Toggle and Push, but doesn't hurt to have as part of Drawable
      self._visible        = True

   # ── Helper Methods ───────────────────────────────────────────────────────────────

   def _getLocalCorner(self):
      """
      Returns the item's pre-rotation top-left corner in local (parent-relative) coordinates.
      """
      return self._localCornerX, self._localCornerY

   def _setLocalCorner(self, localX, localY):
      """
      Sets the item's pre-rotation top-left corner in local (parent-relative) coordinates
      and notifies the renderer with the resulting global position.
      """
      self._localCornerX = localX
      self._localCornerY = localY

      _handler().sendCommand('setPosition', self._objectId, {'x': localX, 'y': localY})
      if isinstance(self._parent, Group):
         self._parent._markDirty()

   def _getGlobalCorner(self):
      """
      Returns the item's pre-rotation top-left corner in global coordinates.
      """
      # if we aren't in a Group, local coordinates are the same as global coordinates
      globalX = self._localCornerX
      globalY = self._localCornerY

      # if we're in a Group, convert local space to global space, relative to our parent
      if isinstance(self._parent, Group):
         parentX, parentY = self._parent._getGlobalCorner()
         globalX = globalX + parentX
         globalY = globalY + parentY

      return globalX, globalY

   def _setGlobalCorner(self, globalX, globalY):
      """
      Set's the item's pre-rotation top-left corner in global coordinates.
      """
      localX = globalX
      localY = globalY

      # if we're in a Group, convert global space to local space, relative to our parent
      if isinstance(self._parent, Group):
         parentX, parentY = self._parent._getGlobalCorner()
         localX = localX - parentX
         localY = localY - parentY

      # delegate to setLocalCorner for updating internal position and renderer
      self._setLocalCorner(localX, localY)

   def _getRotationAnchors(self):
      """
      Returns the last used global rotation anchor as (anchorX, anchorY).
      If no anchor was set (i.e. None), defaults to the item's current global center.
      """
      anchorX = self._anchorX
      anchorY = self._anchorY

      if (anchorX is None) or (anchorY is None):
         globalX, globalY = self._getGlobalCorner()
         centerX = (self._width / 2)
         centerY = (self._height / 2)

         # update anchors with None values
         anchorX = globalX + centerX if anchorX is None else anchorX
         anchorY = globalY + centerY if anchorY is None else anchorY

      return anchorX, anchorY

   def _getBoundingBox(self):
      """
      Returns (x, y, w, h) of the post-rotation bounding box in global coordinates.
      For rotation == 0 this is just the pre-rotation bounding box.
      For non-zero rotation, corners are rotated around the item's center and the
      enclosing axis-aligned rectangle is returned.
      Since _rotation is always stored as rotation-around-center, no anchor look-up
      is needed here.
      """
      # for a non-rotated shape, the bounding box is the same as its internal shape
      x, y   = self._getGlobalCorner()
      width  = self._width
      height = self._height

      if self._rotation != 0:
         # center of the pre-rotation bounding box
         centerX = x + (width / 2)
         centerY = y + (height / 2)

         # rotation trig
         radians = np.radians(self._rotation)
         cos     = np.cos(radians)
         sin     = np.sin(radians)

         # rotate the four corners around the center
         x1 = -(width / 2)
         x2 =  (width / 2)
         y1 = -(height / 2)
         y2 =  (height / 2)
         corners  = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]

         rotatedXs = [centerX + (px * cos) - (py * sin) for px, py in corners]
         rotatedYs = [centerY + (px * sin) + (py * cos) for px, py in corners]

         # get bounding box dimensions
         x      = min(rotatedXs)
         y      = min(rotatedYs)
         width  = max(rotatedXs) - x
         height = max(rotatedYs) - y

      return x, y, width, height

   def _rotatePoints(self, xPoints, yPoints):
      """
      Rotates a list of global-coordinate points around this item's center.
      Returns (xPoints, yPoints) — post-rotation, as lists of ints.
      If rotation == 0, returns the inputs unchanged.
      """
      if self._rotation != 0:
         globalX, globalY = self._getGlobalCorner()
         cx = globalX + self._width  / 2
         cy = globalY + self._height / 2

         radians = np.radians(self._rotation)
         cos     = np.cos(radians)
         sin     = np.sin(radians)

         rotatedXs = []
         rotatedYs = []
         for px, py in zip(xPoints, yPoints):
            dx = px - cx
            dy = py - cy
            rotatedXs.append(int(cx + dx * cos + dy * sin))
            rotatedYs.append(int(cy - dx * sin + dy * cos))
         
         xPoints = rotatedXs
         yPoints = rotatedYs

      return xPoints, yPoints

   # ── Position ───────────────────────────────────────────────────────────────

   def getCenter(self):
      """
      Returns the item's center position.
      """
      globalX, globalY = self._getGlobalCorner()

      centerX = globalX + (self._width / 2)
      centerY = globalY + (self._height / 2)

      return int(centerX), int(centerY)

   def setCenter(self, x, y):
      """
      Sets the item's center position.
      """
      centerX = x
      centerY = y

      # convert center to corner coordinates
      globalX = centerX - (self._width / 2)
      globalY = centerY - (self._height / 2)

      self._setGlobalCorner(globalX, globalY)

   def getPosition(self):
      """
      Returns the item's top-left corner position (in pixels).
      If the item is rotated, this returns the position after rotation.
      """
      boundingX, boundingY, _, _ = self._getBoundingBox()
      return int(boundingX), int(boundingY)

   def setPosition(self, x, y):
      """
      Sets the item's top-left corner position (in pixels).
      """
      boundingX, boundingY, _, _ = self._getBoundingBox()
      globalX, globalY = self._getGlobalCorner()

      # find offset from current bounding box to pre-rotated coordinates
      dx = globalX - boundingX
      dy = globalY - boundingY

      # find desired pre-rotation corner in global coords
      newGlobalX = x + dx
      newGlobalY = y + dy

      self._setGlobalCorner(newGlobalX, newGlobalY)

   def getX(self):
      """
      Returns the item's x coordinate.
      If the item is rotated, this returns the x coordinate after rotation.
      """
      # updates to getPosition() automatically update how this method works
      x, y = self.getPosition()
      return x

   def setX(self, x):
      """
      Sets the item's x coordinate.
      """
      # updates to setPosition() automatically update how this method works
      self.setPosition(x, self.getY())

   def getY(self):
      """
      Returns the item's y coordinate.
      If the item is rotated, this returns the y coordinate after rotation.
      """
      # updates to getPosition() automatically update how this method works
      x, y = self.getPosition()
      return y

   def setY(self, y):
      """
      Sets the item's y coordinate.
      """
      # updates to setPosition() automatically update how this method works
      self.setPosition(self.getX(), y)

   # ── Size ───────────────────────────────────────────────────────────────────

   def getSize(self):
      """
      Returns the item's width and height (in pixels).
      """
      _, _, boundingWidth, boundingHeight = self._getBoundingBox()
      return int(boundingWidth), int(boundingHeight)

   def setSize(self, width, height):
      """
      Sets the item's width and height (in pixels).
      If the item is rotated, this returns the width and height after rotation.
      """
      localWidth  = width  if width  is not None else self._width
      localHeight = height if height is not None else self._height

      # convert post-rotation width and height to pre-rotation dimensions
      if self._rotation != 0:
         pass
         # TODO

      # update internal coordinates
      self._width  = localWidth
      self._height = localHeight

      # update rendering canvas
      _handler().sendCommand('setSize', self._objectId, {'width': localWidth, 'height': localHeight})
      if isinstance(self._parent, Group):
         self._parent._markDirty()

   def getWidth(self):
      """
      Returns the item's width (in pixels).
      If the item is rotated, this returns the width after rotation.
      """
      # updates to getSize() automatically update how this method works
      width, height = self.getSize()
      return width

   def setWidth(self, width):
      """
      Sets the item's width, stretching if needed.
      """
      # updates to setSize() automatically update how this method works
      self.setSize(width, None)

   def getHeight(self):
      """
      Returns the item's height (in pixels).
      If the item is rotated, this returns the height after rotation.
      """
      # updates to getSize() automatically update how this method works
      width, height = self.getSize()
      return height

   def setHeight(self, height):
      """
      Sets the item's height, stretching if needed.
      """
      # updates to setSize() automatically update how this method works
      self.setSize(None, height)

   # ── Rotation ───────────────────────────────────────────────────────────────

   def getRotation(self):
      """
      Returns (rotation, anchorX, anchorY).
      rotation  — current angle in degrees (CCW, starts at 3 o'clock).
      anchorX/Y — the global anchor last passed to setRotation(), or the item's
                  current global center if no anchor was given.
      """
      anchorX, anchorY = self._getRotationAnchors()
      return int(self._rotation), int(anchorX), int(anchorY)

   def setRotation(self, rotation, anchorX=None, anchorY=None):
      """
      Sets the item's rotation (in degrees).  Rotation starts at 3 o'clock,
      increasing counter-clockwise.
      Items rotate around their center by default. If anchorX and anchorY are provided,
      the item rotates around that anchor point instead.
      """
      # store the global anchor for getRotation() (None = center)
      self._anchorX  = anchorX
      self._anchorY  = anchorY

      if (anchorX is not None) or (anchorY is not None):
         # At least one anchor was set, so the item's position will also need to change
         anchorX, anchorY = self._getRotationAnchors()  # replace None with center anchors
         globalX, globalY = self._getGlobalCorner()     # get pre-rotation position
         centerX = globalX + (self._width / 2)
         centerY = globalY + (self._height / 2)

         # rotate center around the anchor to find its new position
         # screen coordinates have y-down, so visual CCW uses the formula:
         #   x' = dx*cos + dy*sin,  y' = -dx*sin + dy*cos
         radians = np.radians(rotation)
         cos     = np.cos(radians)
         sin     = np.sin(radians)

         dx         = centerX - anchorX
         dy         = centerY - anchorY
         newCenterX = anchorX + (dx * cos) + (dy * sin)
         newCenterY = anchorY - (dx * sin) + (dy * cos)

         newGlobalX = newCenterX - (self._width / 2)
         newGlobalY = newCenterY - (self._height / 2)

         # move the shape so its center lands at the rotated position
         self._setGlobalCorner(newGlobalX, newGlobalY)

      # update internal rotation
      self._rotation = rotation

      # update the renderer
      _handler().sendCommand('setRotation', self._objectId, {
         'rotation': rotation
      })

   # ── Hit testing ────────────────────────────────────────────────────────────

   def contains(self, x, y):
      """
      Returns True if the point (x, y) is inside the item.
      """
      result = _handler().sendQuery('contains', self._objectId, {'x': x, 'y': y})
      return result[0]

   def intersects(self, other):
      """
      Returns True if this item intersects the other item.
      """
      result = None

      if not isinstance(other, _Drawable):
         raise TypeError(f'{type(self).__name__}.intersects(): other should be a Drawable object (it was {type(other).__name__})')
      else:
         response = _handler().sendQuery('intersects', self._objectId, {'otherObjectId': other._objectId})
         result = response[0]

      return result

   def encloses(self, other):
      """
      Returns True if this item fully encloses the other item.
      """
      result = None

      if not isinstance(other, _Drawable):
         raise TypeError(f'{type(self).__name__}.encloses(): other should be a Drawable object (it was {type(other).__name__})')
      else:
         response = _handler().sendQuery('encloses', self._objectId, {'otherObjectId': other._objectId})
         result = response[0]

      return result

   # ── Visibility ─────────────────────────────────────────────────────────────

   def _show(self):
      """
      Makes the item visible in the renderer.
      Used by some MusicControls (Push and Toggle).
      """
      self._visible = True
      _handler().sendCommand('show', self._objectId)

   def _hide(self):
      """
      Hides the item in the renderer without removing it.
      Used by some MusicControls (Push and Toggle).
      """
      self._visible = False
      _handler().sendCommand('hide', self._objectId)

   # ── Tooltip ────────────────────────────────────────────────────────────────

   def setToolTipText(self, text=None):
      """
      Sets a tooltip for this item (None clears it).
      """
      self._toolTipText = text
      _handler().sendCommand('setToolTipText', self._objectId, {'text': text})


#######################################################################################
# Graphics - simple geometric shapes, icons, and text labels
#######################################################################################
class _Graphics(_Drawable):
   """
   Superclass for primitive shapes and text on a Display.
   """
   def __init__(self, color=Color.BLACK, fill=False, thickness=1):
      _Drawable.__init__(self)

      self._color     = color.getRGBA()  # color unpacked as rgba values
      self._fill      = bool(fill)       # is this shape filled in?
      self._thickness = int(thickness)   # outline width

   # ── Color ────────────────────────────────────────────────────────────────
   def getColor(self):
      """
      Returns the item's outline and background color.
      """
      r, g, b, a = self._color
      return Color(r, g, b, a)

   def setColor(self, color=None):
      """
      Sets the item's outline and background color.
      If no color is provided, a color selection box will appear.
      """
      if color is None:
         color = Color()

      if isinstance(color, Color):
         r, g, b, a = color.getRGBA()
      else:
         raise TypeError(f'{type(self).__name__}.setColor(): color should be a Color object (it was {type(color).__name__})')

      self._color = [r, g, b, a]
      _handler().sendCommand('setColor', self._objectId, {'color': [r, g, b, a]})

   # ── Fill ────────────────────────────────────────────────────────────────

   def getFilled(self):
      """
      Returns whether the item is filled or not.
      """
      return self._fill

   def setFilled(self, fill):
      """
      Sets whether the item is filled or not.
      """
      self._fill = bool(fill)
      _handler().sendCommand('setFill', self._objectId, {'fill': self._fill})

   # ── Thickness ────────────────────────────────────────────────────────────────

   def getThickness(self):
      """
      Returns the item line width (in pixels).
      """
      return self._thickness

   def setThickness(self, thickness):
      """
      Sets the item's line width.
      """
      self._thickness = int(thickness)
      _handler().sendCommand('setThickness', self._objectId, {'thickness': self._thickness})

#######################################################################################
class Rectangle(_Graphics):
   """
   Drawable rectangle defined by its bounding box.
   """
   def __init__(self, x1, y1, x2, y2, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Creates an rectangle with corners at (x1, y1) to (x2, y2).
      """
      _Graphics.__init__(self, color, fill, thickness)

      self._localCornerX   = min(x1, x2)
      self._localCornerY   = min(y1, y2)
      self._width          = abs(x1 - x2)
      self._height         = abs(y1 - y2)
      self._rotation       = rotation

      _handler().sendCommand('create', self._objectId, {
         'type':      'Rectangle',
         'x':         self._localCornerX,
         'y':         self._localCornerY,
         'width':     self._width,
         'height':    self._height,
         'color':     self._color,
         'fill':      self._fill,
         'thickness': self._thickness,
         'rotation':  self._rotation,
      })

   def __str__(self):
      xPoints, yPoints = self._getEndpoints()
      x1, y1    = xPoints[0], yPoints[0]
      x2, y2    = xPoints[2], yPoints[2]
      rotation  = self.getRotation()
      color     = self.getColor()
      fill      = self.getFilled()
      thickness = self.getThickness()
      return f'Rectangle(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, color = {color}, fill = {fill}, thickness = {thickness}, rotation = {rotation})'

   # ── Coordinates ────────────────────────────────────────────────────────────────

   def _getEndpoints(self):
      """
      Returns (xPoints, yPoints) — the four pre-rotation corners, in global coordinates.
      Corner order: top-left, bottom-left, bottom-right, top-right.
      """
      globalX, globalY = self._getGlobalCorner()
      w = self._width
      h = self._height

      xPoints = [int(globalX), int(globalX),     int(globalX + w), int(globalX + w)]
      yPoints = [int(globalY), int(globalY + h), int(globalY + h), int(globalY)]

      return xPoints, yPoints

   def getEndpoints(self):
      """
      Returns (xPoints, yPoints) — the four corners after rotation, in global coordinates.
      Original corner order: top-left, bottom-left, bottom-right, top-right.
      """
      xPoints, yPoints = self._getEndpoints()
      return self._rotatePoints(xPoints, yPoints)


class Oval(_Graphics):
   """
   Drawable oval defined by its bounding box.
   """
   def __init__(self, x1, y1, x2, y2, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Creates an oval inside the box with corners at (x1, y1) to (x2, y2).
      """
      _Graphics.__init__(self, color, fill, thickness)

      self._localCornerX   = min(x1, x2)
      self._localCornerY   = min(y1, y2)
      self._width          = abs(x1 - x2)
      self._height         = abs(y1 - y2)
      self._rotation       = rotation

      # create oval in the renderer child process
      _handler().sendCommand('create', self._objectId, {
         'type':      'Oval',
         'x':         self._localCornerX,
         'y':         self._localCornerY,
         'width':     self._width,
         'height':    self._height,
         'color':     self._color,
         'fill':      self._fill,
         'thickness': self._thickness,
         'rotation':  self._rotation,
      })

   def __str__(self):
      x1, y1    = self._getGlobalCorner()
      x2        = x1 + self._width
      y2        = y1 + self._height
      rotation  = self.getRotation()
      color     = self.getColor()
      fill      = self.getFilled()
      thickness = self.getThickness()
      return f'Oval(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, color = {color}, fill = {fill}, thickness = {thickness}, rotation = {rotation})'


class Circle(Oval):
   """
   Drawable circle defined by its center and radius.
   """
   def __init__(self, x, y, radius, color=Color.BLACK, fill=False, thickness=1):
      """
      Creates a circle at (x, y) with the given radius.
      """
      x1 = x - radius
      y1 = y - radius
      x2 = x + radius
      y2 = y + radius

      Oval.__init__(self, x1, y1, x2, y2, color, fill, thickness, 0)

   def __str__(self):
      x, y      = self.getCenter()
      radius    = self.getRadius()
      color     = self.getColor()
      fill      = self.getFilled()
      thickness = self.getThickness()

      return f'Circle(x = {x}, y = {y}, radius = {radius}, color = {color}, fill = {fill}, thickness = {thickness})'

   # ── Size ────────────────────────────────────────────────────────────────

   def setSize(self, width, height):
      """
      Sets the item's width and height, stretching if needed.
      If width and height aren't the same, the height is discarded.
      """
      if width != height:
         print(f"{type(self).__name__}.setSize(): The width and height of a {type(self).__name__} should be the same (they were '{width}' and '{height}').  Using the width for now.")
      Oval.setSize(self, width, width)

   def setWidth(self, width):
      """Sets the item's width, stretching if needed."""
      self.setSize(width, width)

   def setHeight(self, height):
      """Sets the item's height, stretching if needed."""
      self.setSize(height, height)

   # ── Radius ────────────────────────────────────────────────────────────────

   def getRadius(self):
      """
      Returns the item's radius (in pixels).
      """
      radius = self.getWidth() / 2
      return int(radius)

   def setRadius(self, radius):
      """
      Sets the item's radius (in pixels).
      """
      diameter = radius * 2
      self.setWidth(diameter)


class Point(Circle):
   """
   Drawable single point defined by its position.
   """
   def __init__(self, x, y, color=Color.BLACK):
      """
      Creates a point at (x, y).
      """
      Circle.__init__(self, x, y, 1, color, True, 1)

   def __str__(self):
      x, y  = self.getCenter()
      color = self.getColor()
      return f'Point(x = {x}, y = {y}, color = {color})'


class Arc(_Graphics):
   """
   Drawable arc of an ellipse defined by its bounding box and angles.
   """
   def __init__(self, x1, y1, x2, y2, startAngle=PI, endAngle=TWO_PI, style=OPEN, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Creates an arc segment inside the box with corners at (x1, y1) to (x2, y2).
      """
      _Graphics.__init__(self, color, fill, thickness)

      self._localCornerX   = min(x1, x2)
      self._localCornerY   = min(y1, y2)
      self._width          = abs(x1 - x2)
      self._height         = abs(y1 - y2)
      self._rotation       = rotation

      self._startAngle     = startAngle
      self._endAngle       = endAngle
      self._style          = style

      _handler().sendCommand('create', self._objectId, {
         'type':       'Arc',
         'x':          self._localCornerX,
         'y':          self._localCornerY,
         'width':      self._width,
         'height':     self._height,
         'startAngle': self._startAngle,
         'endAngle':   self._endAngle,
         'style':      self._style,
         'color':      self._color,
         'fill':       self._fill,
         'thickness':  self._thickness,
         'rotation':   self._rotation,
      })

   def __str__(self):
      x1, y1     = self._getGlobalCorner()
      x2         = x1 + self._width
      y2         = y1 + self._height
      startAngle = self._startAngle
      endAngle   = self._endAngle
      style      = self._style
      rotation   = self.getRotation()
      color      = self.getColor()
      fill       = self.getFilled()
      thickness  = self.getThickness()
      return f'Arc(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, startAngle = {startAngle}, endAngle = {endAngle}, style = {style}, color = {color}, fill = {fill}, thickness = {thickness}, rotation = {rotation})'

   # ── ArcWidth ────────────────────────────────────────────────────────────────

   def _setArcWidth(self, arcWidth):
      """
      Changes the arc's sweep angle in the renderer.
      arcWidth is in gui.py convention (positive degrees, counterclockwise).
      Used by Rotary to adjust the size of the rotary knob.
      """
      _handler().sendCommand('setArcWidth', self._objectId, {'arcWidth': -arcWidth})


class ArcCircle(Arc):
   """
   Drawable arc of a circle defined by its center, radius, and angles.
   """
   def __init__(self, x, y, radius, startAngle=PI, endAngle=TWO_PI, style=OPEN, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Creates an arc segment inside the circle at (x, y) with given radius.
      """
      x1 = x - radius
      y1 = y - radius
      x2 = x + radius
      y2 = y + radius

      Arc.__init__(self, x1, y1, x2, y2, startAngle, endAngle, style, color, fill, thickness, rotation)

   def __str__(self):
      x, y       = self.getCenter()
      radius     = self.getRadius()
      startAngle = self._startAngle
      endAngle   = self._endAngle
      style      = self._style
      rotation   = self.getRotation()
      color      = self.getColor()
      fill       = self.getFilled()
      thickness  = self.getThickness()
      return f'ArcCircle(x = {x}, y = {y}, radius = {radius}, startAngle = {startAngle}, endAngle = {endAngle}, style = {style}, color = {color}, fill = {fill}, thickness = {thickness}, rotation = {rotation})'

   # ── Size ────────────────────────────────────────────────────────────────

   def setSize(self, width, height):
      """
      Sets the item's width and height, stretching if needed.
      """
      if width != height:
         print(f"{type(self).__name__}.setSize(): The width and height of a {type(self).__name__} should be the same (they were '{width}' and '{height}').  Using the width for now.")
      Arc.setSize(self, width, width)

   # ── Radius ────────────────────────────────────────────────────────────────

   def getRadius(self):
      """
      Returns the item's radius (in pixels).
      """
      radius = self.getWidth() / 2
      return int(radius)

   def setRadius(self, radius):
      """
      Sets the item's radius (in pixels).
      """
      diameter = radius * 2
      self.setWidth(diameter)


class Line(_Graphics):
   """
   Drawable line between two endpoints.
   """
   def __init__(self, x1, y1, x2, y2, color=Color.BLACK, thickness=1, rotation=0):
      """
      Creates a line from (x1, y1) to (x2, y2).
      """
      _Graphics.__init__(self, color, False, thickness)

      self._localCornerX   = min(x1, x2)
      self._localCornerY   = min(y1, y2)
      self._width          = abs(x1 - x2)
      self._height         = abs(y1 - y2)
      self._rotation       = rotation

      # store interior endpoints (relative to corner)
      innerX1 = x1 - self._localCornerX
      innerY1 = y1 - self._localCornerY
      innerX2 = x2 - self._localCornerX
      innerY2 = y2 - self._localCornerY

      self._xPoints = [innerX1, innerX2]
      self._yPoints = [innerY1, innerY2]

      # store original size - we use this to rebuild after a shape has been flattened
      self._originalWidth  = self._width
      self._originalHeight = self._height

      _handler().sendCommand('create', self._objectId, {
         'type':      'Line',
         'x':         self._localCornerX,
         'y':         self._localCornerY,
         'width':     self._width,
         'height':    self._height,
         'xPoints':   self._xPoints,
         'yPoints':   self._yPoints,
         'color':     self._color,
         'thickness': self._thickness,
         'rotation':  self._rotation,
      })

   def __str__(self):
      xPoints, yPoints = self._getEndpoints()
      x1, x2    = xPoints
      y1, y2    = yPoints
      rotation  = self.getRotation()
      color     = self.getColor()
      thickness = self.getThickness()
      return f'Line(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, color = {color}, thickness = {thickness}, rotation = {rotation})'

   # ── Coordinates ────────────────────────────────────────────────────────────────

   def _getEndpoints(self):
      """
      Returns ([x1, x2], [y1, y2]) — the two pre-rotation endpoints, in global coordinates.
      """
      scaleX = 0 if (self._originalWidth  == 0) else (self._width  / self._originalWidth)
      scaleY = 0 if (self._originalHeight == 0) else (self._height / self._originalHeight)

      globalX, globalY = self._getGlobalCorner()

      xPoints = [int(globalX + (self._xPoints[i] * scaleX)) for i in range(2)]
      yPoints = [int(globalY + (self._yPoints[i] * scaleY)) for i in range(2)]

      return xPoints, yPoints

   def getEndpoints(self):
      """
      Returns ([x1, x2], [y1, y2]) — the two endpoints after rotation, in global coordinates.
      """
      xPoints, yPoints = self._getEndpoints()
      return self._rotatePoints(xPoints, yPoints)

   # ── Length ────────────────────────────────────────────────────────────────

   def getLength(self):
      """
      Returns the distance between the line's endpoints (in pixels).
      """
      return float(np.sqrt(self._width**2 + self._height**2))

   def setLength(self, length):
      """
      Sets the distance between the line's endpoints (in pixels).
      The line's second endpoint (x2, y2) moves to match.
      """
      xPoints, yPoints = self.getEndpoints()
      x1, x2 = xPoints
      y1, y2 = yPoints

      # find the current length
      dx = x2 - x1
      dy = y2 - y1
      oldLength = np.hypot(dx, dy)

      if oldLength == 0:
         # (x1,y1) == (x2,y2), so extend x horizontally
         newX2 = x1 + length
         newY2 = y1
      else:
         # adjust (x2,y2) based on the new length
         ux = dx / oldLength
         uy = dy / oldLength
         newX2 = x1 + (length * ux)
         newY2 = y1 + (length * uy)

      # update rendered object
      _handler().sendCommand('setLine', self._objectId, {
         'x1': x1, 'y1': y1,
         'x2': newX2, 'y2': newY2
      })

      # recalculate local dimensions
      localX = min(x1, newX2)
      localY = min(y1, newY2)
      width  = abs(x1 - newX2)
      height = abs(y1 - newY2)

      if isinstance(self._parent, Group):
         # if we're in a group, subtract our parent's corner coordinates
         # to convert to local coordinates
         parentX, parentY = self._parent.getPosition()
         localX = localX - parentX
         localY = localY - parentY

      # rebase the line - treat this updated line as though it's new
      self._localCornerX   = localX
      self._localCornerY   = localY
      self._width          = width
      self._height         = height
      self._originalWidth  = width
      self._originalHeight = height
      # store new points as a list of points relative to this shape's position
      # i.e. min(xPoints) == 0 and min(yPoints) == 0
      self._xPoints        = [x1 - self._localCornerX, newX2 - self._localCornerX]
      self._yPoints        = [y1 - self._localCornerY, newY2 - self._localCornerY]


class Polyline(_Graphics):
   """
   Drawable lines between a series of points.
   """
   def __init__(self, xPoints, yPoints, color=Color.BLACK, thickness=1, rotation=0):
      """
      Creates lines between a series of points.
      """
      if len(xPoints) != len(yPoints):
         raise ValueError(f'{type(self).__name__}(): xPoints and yPoints must have the same number of points (they had {len(xPoints)} and {len(yPoints)} points).')

      _Graphics.__init__(self, color, False, thickness)

      self._localCornerX   = min(xPoints)
      self._localCornerY   = min(yPoints)
      self._width          = max(xPoints) - self._localCornerX
      self._height         = max(yPoints) - self._localCornerY
      self._rotation       = rotation

      # store original points as a list of points relative to this shape's position
      # i.e. min(xPoints) == 0 and min(yPoints) == 0
      self._xPoints = [x - self._localCornerX for x in xPoints]
      self._yPoints = [y - self._localCornerY for y in yPoints]

      # store original size - we use this to rebuild after a shape has been flattened
      self._originalWidth  = self._width
      self._originalHeight = self._height

      _handler().sendCommand('create', self._objectId, {
         'type':      'Polyline',
         'x':         self._localCornerX,
         'y':         self._localCornerY,
         'width':     self._width,
         'height':    self._height,
         'xPoints':   self._xPoints,
         'yPoints':   self._yPoints,
         'color':     self._color,
         'thickness': self._thickness,
         'rotation':  self._rotation,
      })

   def __str__(self):
      xPoints, yPoints = self._getEndpoints()
      rotation  = self.getRotation()
      color     = self.getColor()
      thickness = self.getThickness()
      return f'Polyline(xPoints = {xPoints}, yPoints = {yPoints}, color = {color}, thickness = {thickness}, rotation = {rotation})'

   # ── Coordinates ────────────────────────────────────────────────────────────────

   def _getEndpoints(self):
      """
      Returns (xPoints, yPoints) — all pre-rotation points, in global coordinates.
      """
      scaleX = 0 if (self._originalWidth  == 0) else (self._width  / self._originalWidth)
      scaleY = 0 if (self._originalHeight == 0) else (self._height / self._originalHeight)

      globalX, globalY = self._getGlobalCorner()

      xPoints = [int(globalX + (self._xPoints[i] * scaleX)) for i in range(len(self._xPoints))]
      yPoints = [int(globalY + (self._yPoints[i] * scaleY)) for i in range(len(self._yPoints))]

      return xPoints, yPoints

   def getEndpoints(self):
      """
      Returns (xPoints, yPoints) — all points after rotation, in global coordinates.
      """
      xPoints, yPoints = self._getEndpoints()
      return self._rotatePoints(xPoints, yPoints)


class Polygon(_Graphics):
   """
   Drawable shape defined by a series of points.
   """
   def __init__(self, xPoints, yPoints, color=Color.BLACK, fill=False, thickness=1, rotation=0):
      """
      Creates a polygon from a series of points.
      """
      if len(xPoints) != len(yPoints):
         raise ValueError(f'{type(self).__name__}(): xPoints and yPoints must have the same number of points (they had {len(xPoints)} and {len(yPoints)} points).')

      _Graphics.__init__(self, color, fill, thickness)

      self._localCornerX   = min(xPoints)
      self._localCornerY   = min(yPoints)
      self._width          = max(xPoints) - self._localCornerX
      self._height         = max(yPoints) - self._localCornerY
      self._rotation       = rotation

      # store original points as a list of points relative to this shape's position
      # i.e. min(xPoints) == 0 and min(yPoints) == 0
      self._xPoints = [x - self._localCornerX for x in xPoints]
      self._yPoints = [y - self._localCornerY for y in yPoints]

      # store original size - we use this to rebuild after a shape has been flattened
      self._originalWidth  = self._width
      self._originalHeight = self._height

      _handler().sendCommand('create', self._objectId, {
         'type':      'Polygon',
         'x':         self._localCornerX,
         'y':         self._localCornerY,
         'width':     self._width,
         'height':    self._height,
         'xPoints':   self._xPoints,
         'yPoints':   self._yPoints,
         'color':     self._color,
         'fill':      self._fill,
         'thickness': self._thickness,
         'rotation':  self._rotation,
      })

   def __str__(self):
      xPoints, yPoints = self._getEndpoints()
      rotation  = self.getRotation()
      color     = self.getColor()
      fill      = self.getFilled()
      thickness = self.getThickness()
      return f'Polygon(xPoints = {xPoints}, yPoints = {yPoints}, color = {color}, fill = {fill}, thickness = {thickness}, rotation = {rotation})'

   # ── Coordinates ────────────────────────────────────────────────────────────────

   def _getEndpoints(self):
      """
      Returns (xPoints, yPoints) — all pre-rotation points, in global coordinates.
      """
      scaleX = 0 if (self._originalWidth  == 0) else (self._width  / self._originalWidth)
      scaleY = 0 if (self._originalHeight == 0) else (self._height / self._originalHeight)

      globalX, globalY = self._getGlobalCorner()

      xPoints = [int(globalX + (self._xPoints[i] * scaleX)) for i in range(len(self._xPoints))]
      yPoints = [int(globalY + (self._yPoints[i] * scaleY)) for i in range(len(self._yPoints))]

      return xPoints, yPoints

   def getEndpoints(self):
      """
      Returns (xPoints, yPoints) — all points after rotation, in global coordinates.
      """
      xPoints, yPoints = self._getEndpoints()
      return self._rotatePoints(xPoints, yPoints)


class Icon(_Graphics):
   """
   Icons are sprites made from individual pixels.
   """
   def __init__(self, filename, width=None, height=None, rotation=0):
      """
      Creates an icon from a given file, or creates a new, blank icon.
      Supports JPG, JPEG, PNG, GIF, SVG, SVGZ, ICO, BMP, CUR, JFIF, PBM, PGM, PPM, XBM, and XPM formats.
      Read more: https://doc.qt.io/qt-6/qpixmap.html#reading-and-writing-image-files
      """
      _Graphics.__init__(self, Color.CLEAR, False, 0)

      self._filename = filename
      self._rotation = rotation

      # width/height are resolved by the renderer (from the actual pixmap)
      # For now, cache what the user provided; the renderer will resolve None values.
      self._width          = width  if width  is not None else 0
      self._height         = height if height is not None else 0
      self._originalWidth  = self._width
      self._originalHeight = self._height

      _handler().sendCommand('create', self._objectId, {
         'type':     'Icon',
         'filename': filename,
         'width':    width,
         'height':   height,
         'rotation': rotation,
      })

      # query the renderer for the resolved dimensions
      if width is None or height is None:
         result = _handler().sendQuery('getSize', self._objectId)
         self._width          = result[0]
         self._height         = result[1]
         self._originalWidth  = self._width
         self._originalHeight = self._height

   def __str__(self):
      filename      = self._filename
      width, height = self.getSize()
      rotation      = self.getRotation()
      return f'Icon(filename = "{filename}", width = {width}, height = {height}, rotation = {rotation})'

   # ── Write ────────────────────────────────────────────────────────────────

   def write(self, filename, width=None, height=None):
      """
      Saves the icon to an image file.
      The file format is determined by the filename extension (e.g. .png, .jpg).
      Optional width and height resize the saved image; omitting one preserves the aspect ratio.
      Prints whether the write succeeded and the resolved file path.
      """
      result = _handler().sendQuery('write', self._objectId, {'filename': filename, 'width': width, 'height': height})
      success, resolvedPath = result[0], result[1]
      if success:
         print(f'{type(self).__name__}.write(): saved to "{resolvedPath}"')
      else:
         print(f'{type(self).__name__}.write(): failed to save "{resolvedPath}"')

   # ── Crop ────────────────────────────────────────────────────────────────

   def crop(self, x, y, width, height):
      """
      Crop the icon to the specified rectangle, relative to the icon's position.
      """
      self._width  = int(width)
      self._height = int(height)
      _handler().sendCommand('crop', self._objectId, {'x': x, 'y': y, 'width': width, 'height': height})

   # ── Pixel Manipulation ────────────────────────────────────────────────────────────

   def getPixel(self, column, row):
      """
      Returns the [r, g, b] color of a given pixel in the icon.
      """
      result = _handler().sendQuery('getPixel', self._objectId, {'column': column, 'row': row})
      return result

   def setPixel(self, column, row, color):
      """
      Sets the [r, g, b] color of a given pixel in the icon.
      """
      r, g, b = color
      _handler().sendCommand('setPixel', self._objectId, {'column': column, 'row': row, 'color': [r, g, b]})

   def getPixels(self):
      """
      Returns the [r, g, b] color of all pixels in the icon as a 2-dimensional array.
      """
      result = _handler().sendQuery('getPixels', self._objectId)
      return result[0]

   def setPixels(self, pixels):
      """
      Sets the [r, g, b] color of all pixels in the icon from a 2-dimensional array.
      """
      _handler().sendCommand('setPixels', self._objectId, {'pixels': pixels})


class Label(_Graphics):
   """
   Drawable single-line text.
   """
   def __init__(self, text, alignment=LEFT, textColor=Color.BLACK, backgroundColor=Color.CLEAR, font=None):
      """
      Create a new text label.
      """
      _Graphics.__init__(self, textColor, False, 1)

      self._text            = str(text)
      self._backgroundColor = backgroundColor.getRGBA()
      self._alignment       = alignment
      self._font            = None

      # extract Font information
      fontData = None
      if isinstance(font, Font):
         name  = font.getName()
         style = font.getStyle()
         size  = font.getSize()
         self._font = [name, style, size]
         fontData   = [name, style, size]

      _handler().sendCommand('create', self._objectId, {
         'type':            'Label',
         'text':            str(text),
         'alignment':       alignment,
         'textColor':       self._color,
         'backgroundColor': self._backgroundColor,
         'font':            fontData,
         'color':           self._color,
         'rotation':        0,
      })

      # query the renderer for the resolved dimensions (text bounds)
      result = _handler().sendQuery('getSize', self._objectId)
      self._width          = result[0]
      self._height         = result[1]
      self._originalWidth  = self._width
      self._originalHeight = self._height

   def __str__(self):
      text            = self.getText()
      alignment       = self.getAlignment()
      textColor       = self.getTextColor()
      backgroundColor = self.getBackgroundColor()
      font            = self.getFont()
      return f'Label(text = "{text}", alignment = {alignment}, textColor = {textColor}, backgroundColor = {backgroundColor}, font = {font})'

   # ── Text ────────────────────────────────────────────────────────────────

   def getText(self):
      """
      Returns the label's text.
      """
      return self._text

   def setText(self, text):
      """
      Sets the label's text.
      """
      self._text = str(text)
      _handler().sendCommand('setText', self._objectId, {'text': str(text)})

   # ── Color ────────────────────────────────────────────────────────────────

   def getTextColor(self):
      """
      Returns the label's text color.
      """
      return self.getColor()

   def setTextColor(self, color=None):
      """
      Sets the label's text color.
      If no color is provided, a color selection box will appear.
      """
      self.setColor(color)

   def getBackgroundColor(self):
      """
      Returns the label's background color.
      """
      r, g, b, a = self._backgroundColor
      return Color(r, g, b, a)

   def setBackgroundColor(self, color=None):
      """
      Sets the label's background color.
      If no color is provided, a color selection box will appear.
      """
      if color is None:
         color = Color()

      if isinstance(color, Color):
         r, g, b, a = color.getRGBA()
      else:
         raise TypeError(f'{type(self).__name__}.setBackgroundColor(): color should be a Color object (it was {type(color).__name__})')

      self._backgroundColor = [r, g, b, a]
      _handler().sendCommand('setBackgroundColor', self._objectId, {'color': [r, g, b, a]})

   # ── Alignment ────────────────────────────────────────────────────────────────

   def getAlignment(self):
      """
      Returns the label's horizontal alignment.
      """
      return self._alignment

   def setAlignment(self, alignment):
      """
      Sets the label's horizontal alignment.
      """
      self._alignment = alignment
      _handler().sendCommand('setAlignment', self._objectId, {'alignment': alignment})

   # ── Font ────────────────────────────────────────────────────────────────

   def getFont(self):
      """
      Returns the label's font, or None if the font was not set.
      """
      font = None

      if self._font is not None:
         name, style, size = self._font
         font = Font(name, style, size)

      return font

   def setFont(self, font):
      """
      Sets the label's font.
      """
      name  = font.getName()
      style = font.getStyle()
      size  = font.getSize()
      self._font = [name, style, size]
      _handler().sendCommand('setFont', self._objectId, {'font': [name, style, size]})


#######################################################################################
# Group - a collection of Graphics that are manipulated as one object
#######################################################################################
class Group(_Drawable):
   """
   Container that groups multiple drawables to move/scale/order them together.
   """
   def __init__(self, items=[]):
      _Drawable.__init__(self)

      self._itemList = []   # list of child items
      self._dirty    = True # bounding box needs recalculation

      # create a new Group before adding items to it
      _handler().sendCommand('create', self._objectId, {'type': 'Group'})

      for item in reversed(items):  # add each item, back to front
         self.add(item)

   def __str__(self):
      return f'Group(items = {self._itemList})'

   # ── Lazy Update ────────────────────────────────────────────────────────────
   # Since a Group's items can be moved and changed independently of the Group,
   # we lazy update the group's size and position - that is, we don't bother to
   # calculate a Group's dimensions until Group.getPosition() or Group.getSize()
   # are called.

   def _markDirty(self):
      """Marks this group's bounding box as stale, and propagates to any parent Group."""
      self._dirty = True
      if isinstance(self._parent, Group):
         self._parent._markDirty()

   def _calculateSize(self):
      """Recomputes the group's pre-rotation bounding box from its children's AABBs.
      Clears the dirty flag."""
      if not self._dirty:
         return

      if len(self._itemList) == 0:
         self._width  = 0
         self._height = 0
      else:
         # express each child's AABB in group-pre-rotation-relative coords
         groupGX, groupGY = self._getGlobalCorner()

         x1s, y1s, x2s, y2s = [], [], [], []
         for child in self._itemList:
            cx, cy = child.getPosition()   # child rotated bounding box top-left in scene
            cw, ch = child.getSize()       # child rotated bounding box dimensions
            x1s.append(cx - groupGX)
            y1s.append(cy - groupGY)
            x2s.append(cx - groupGX + cw)
            y2s.append(cy - groupGY + ch)

         minX = min(x1s)
         minY = min(y1s)

         # Normalize: the Group's pre-rotation corner should sit at its content AABB top-left.
         # Absorb (minX, minY) into the Group's corner, then rebase children so that the
         # minimum child AABB offset from the group origin is always (0, 0).
         # Children are updated directly to avoid re-triggering dirty.
         if minX != 0 or minY != 0:
            self._localCornerX += minX
            self._localCornerY += minY
            gx, gy = self._getGlobalCorner()
            _handler().sendCommand('setPosition', self._objectId, {'x': gx, 'y': gy})

            for child in self._itemList:
               child._localCornerX -= minX
               child._localCornerY -= minY
               cgx, cgy = child._getGlobalCorner()
               _handler().sendCommand('setPosition', child._objectId, {'x': cgx, 'y': cgy})

            # Group's corner changed — parent Group needs to recalculate its bounding box
            if isinstance(self._parent, Group):
               self._parent._markDirty()

         self._width  = max(x2s) - minX
         self._height = max(y2s) - minY

      self._dirty = False

   # ── Position / Size ─────────────────────────────────────────────────

   def getPosition(self):
      """Returns the group's top-left in global coordinates."""
      self._calculateSize()
      return _Drawable.getPosition(self)

   def getSize(self):
      """Returns the group's dimensions, recalculating from children only if needed."""
      self._calculateSize()
      _, _, w, h = self._getBoundingBox()
      return int(w), int(h)

   def setSize(self, width, height):
      """
      Sets the group's dimensions, stretching children proportionally.
      Each child.setSize() and _setLocalCorner() sends its own IPC commands.
      The group bounding box in Qt derives from children automatically.
      """
      oldWidth, oldHeight = self.getSize()

      ratioX = (width  / oldWidth)  if oldWidth  != 0 else 1
      ratioY = (height / oldHeight) if oldHeight != 0 else 1

      if (ratioX != 1) or (ratioY != 1):  # skip if no significant change
         for child in self._itemList:
            w, h = child.getSize()
            lx, ly = child._getLocalCorner()
            child.setSize(w * ratioX, h * ratioY)
            child._setLocalCorner(lx * ratioX, ly * ratioY)
         self._markDirty()
         if isinstance(self._parent, Group):
            self._parent._markDirty()

   # ── Item Manipulation ───────────────────────────────────────────────────────────────

   def add(self, item):
      """
      Adds an item to the group.
      Removes the item from other Groups or Displays first.
      """
      self.addOrder(item, 0)

   def addOrder(self, item, order=0):
      """
      Adds an item to the group at the specified order.
      Removes the item from other Groups or Displays first.
      """
      if not isinstance(item, _Drawable):  # do some basic type checking
         raise TypeError(f'{type(self).__name__}.addOrder(): item should be a Drawable object (it was {type(item).__name__}).')

      # capture pre-rotation corner before any re-parenting changes the parent chain
      itemPreRotX, itemPreRotY = item._getGlobalCorner()

      if isinstance(item._parent, (Group, Display)):
         item._parent.remove(item)  # remove item from any Group or Display

      # rebase child into group-local coords using pre-rotation corners on both sides,
      # so the item appears in the same scene position after re-parenting
      groupPreRotX, groupPreRotY = self._getGlobalCorner()
      localX = itemPreRotX - groupPreRotX
      localY = itemPreRotY - groupPreRotY

      item._parent = self
      item._setLocalCorner(localX, localY)

      # add item in CreativePython
      order = max(0, min(len(self._itemList), order))  # clamp order to possible indices
      self._itemList.insert(order, item)               # insert to items list
      self._markDirty()

      # send IPC command to add child in renderer
      _handler().sendCommand('addChildOrder', self._objectId, {
         'itemId': item._objectId,
         'order':  order,
      })

   def remove(self, item):
      """
      Removes an item from the group.
      """
      if item in self._itemList:  # skip if item not in Group
         # remove item in CreativePython
         item._parent = None                 # tell item it's not in this Group
         self._itemList.remove(item)         # remove item from items list
         self._markDirty()

         # remove item in renderer
         _handler().sendCommand('removeChild', self._objectId, {
            'itemId': item._objectId,
         })

         # add item to this Group's parent
         if self._parent is not None:
            self._parent.add(item)

   def getOrder(self, item):
      """
      Returns the drawing order (z-index) for an item in the group.
      """
      order = None

      if item in self._itemList:  # skip if item not in Group
         order = self._itemList.index(item)

      return order

   def setOrder(self, item, order):
      """
      Sets the drawing order (z-index) for an item in the group.
      """
      if (item in self._itemList): # skip if item not in Group
         self.addOrder(item, order)  # remove and re-add item at desired order


#######################################################################################
# MusicControl - special Groups with custom callbacks
#######################################################################################
class _MusicControl(Group):
   """
   Superclass for on-screen music controls (sliders, knobs, pads).
   """
   def __init__(self, action=None):
      """
      Initializes music control state (value, callback function, component shapes).
      """
      Group.__init__(self)
      self._value  = None
      self._action = action
      # Since MusicControls are Groups, users can manipulate them by adding and
      # removing items.  As a result, we need a way to identify the MusicControl's
      # original components without referencing their index in itemList.
      # Also, since Groups' true dimensions change with their items, we use these
      # components' dimensions to resolve value changes from events.
      self._foregroundShape = None
      self._backgroundShape = None
      self._outlineShape    = None

   ##### NEW MUSICCONTROL METHODS
   def _defaultAction(self, *args):
      """
      Defines the default behavior of the control.
      Each MusicControl should override this method based on their behavior.
      """
      pass

   def _updateAppearance(self):
      """
      Redraws the control based on its current value.
      Each MusicControl should override this method based on their appearance.
      """
      pass

   def getValue(self):
      """
      Returns the control's current value.
      """
      return int(self._value)

   def setValue(self, newValue):
      """
      Sets the control's current value, and updates its appearance.
      """
      if newValue != self._value:  # only update if value has changed
         self._value = newValue
         self._updateAppearance()
         if (self._action is not None) and callable(self._action):
            self._action(self._value)  # call user function

#######################################################################################
class HFader(_MusicControl):
   """
   Horizontal fader (slider) control.
   """
   def __init__(self, x1, y1, x2, y2, minValue=0, maxValue=999, startValue=None,
                action=None, foregroundColor=Color.RED, backgroundColor=Color.BLACK,
                outlineColor=Color.BLACK, thickness=3, rotation=0):
      """
      Creates a horizontal fader with corners at (x1, y1) to (x2, y2).
      """
      _MusicControl.__init__(self, action)

      # calculate dimensions
      localX = min(x1, x2)
      localY = min(y1, y2)
      width  = abs(x1 - x2)
      height = abs(y1 - y2)

      # initialize internal shapes with (0, 0) position
      self._backgroundShape = Rectangle(
         0, 0, width, height,
         color=backgroundColor,
         fill=True,
         thickness=0,
         rotation=0
      )
      self._foregroundShape = Rectangle(
         0, 0, width, height,
         color=foregroundColor,
         fill=True,
         thickness=0,
         rotation=0
      )
      self._outlineShape = Rectangle(
         0, 0, width, height,
         color=outlineColor,
         fill=False,
         thickness=thickness,
         rotation=0
      )

      self.add(self._backgroundShape)
      self.add(self._foregroundShape)
      self.add(self._outlineShape)

      # set starting attributes
      self.setPosition(localX, localY)
      self.setRotation(rotation)

      if startValue is None:
         startValue = (minValue + maxValue) / 2

      self._minValue = minValue
      self._maxValue = maxValue
      self.setValue(startValue)

      # register default behavior events
      self.onMouseDown(self._defaultAction)
      self.onMouseDrag(self._defaultAction)

   def __str__(self):
      x1, y1          = self._backgroundShape.getPosition()
      width, height   = self._backgroundShape.getSize()
      x2              = x1 + width
      y2              = y1 + height
      foregroundColor = self._foregroundShape.getColor()
      backgroundColor = self._backgroundShape.getColor()
      outlineColor    = self._outlineShape.getColor()
      thickness       = self._outlineShape.getThickness()
      rotation        = self.getRotation()
      return f'HFader(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, minValue = {self._minValue}, maxValue = {self._maxValue}, startValue = {self.getValue()}, action = {self._action}, foreground = {foregroundColor}, background = {backgroundColor}, outline = {outlineColor}, thickness = {thickness}, rotation = {rotation})'

   # OVERRIDDEN METHODS
   def _defaultAction(self, ex, ey):
      """
      Defines the default behavior of the control.
      HFaders update their value based on the horizontal position of the mouse,
      relative to the fader.
      """
      # update fader value based on mouse position on the fader
      fx = self._backgroundShape.getX()  # global fader position
      x  = ex - fx                       # local event position

      valueRatio = x / self._backgroundShape.getWidth()        # (0.0 - 1.0)
      valueRatio = max(0.0, min(1.0, valueRatio))              # clamp ratio
      valueRange = self._maxValue - self._minValue             # possible values
      newValue   = self._minValue + (valueRatio * valueRange)  # scale to range
      self.setValue(newValue)                                  # update value

   def _updateAppearance(self):
      """
      Redraws the control based on its current value.
      """
      valueRatio = (self._value - self._minValue) / (self._maxValue - self._minValue)  # (0.0 - 1.0)
      width, height = self._backgroundShape.getSize()
      x,     y      = self._backgroundShape.getPosition()
      padding       = self._outlineShape.getThickness() / 2

      fWidth  = (width  - (2 * padding))  # find maximum fader bar dimensions
      fHeight = (height - (2 * padding))  # ...
      fx      = x + padding               # ...
      fy      = y + padding               # ...
      fWidth  = fWidth * valueRatio       # scale to value

      self._foregroundShape.setPosition(fx, fy)
      self._foregroundShape.setSize(fWidth, fHeight)

   def setValue(self, newValue):
      """
      Sets the control's current value, and updates its appearance.
      """
      newValue = max(self._minValue, min(self._maxValue, newValue))  # clamp value
      _MusicControl.setValue(self, newValue)  # update value and call user function


class VFader(HFader):
   """
   Vertical fader (slider) control.
   """
   def __init__(self, x1, y1, x2, y2, minValue=0, maxValue=999, startValue=None,
               action=None, foregroundColor=Color.RED, backgroundColor=Color.BLACK,
               outlineColor=Color.BLACK, thickness=3, rotation=0):
      """
      Creates a vertical fader with corners at (x1, y1) to (x2, y2).
      """
      HFader.__init__(self, x1, y1, x2, y2, minValue, maxValue, startValue,
                      action, foregroundColor, backgroundColor,
                      outlineColor, thickness, rotation)

   def __str__(self):
      x1, y1          = self._backgroundShape.getPosition()
      width, height   = self._backgroundShape.getSize()
      x2              = x1 + width
      y2              = y1 + height
      foregroundColor = self._foregroundShape.getColor()
      backgroundColor = self._backgroundShape.getColor()
      outlineColor    = self._outlineShape.getColor()
      thickness       = self._outlineShape.getThickness()
      rotation        = self.getRotation()
      return f'VFader(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, minValue = {self._minValue}, maxValue = {self._maxValue}, startValue = {self.getValue()}, action = {self._action}, foreground = {foregroundColor}, background = {backgroundColor}, outline = {outlineColor}, thickness = {thickness}, rotation = {rotation})'

   # OVERRIDDEN METHODS
   def _defaultAction(self, ex, ey):
      """
      Defines the default behavior of the control.
      VFaders update their value based on the vertical position of the mouse,
      relative to the fader.
      """
      # update fader value based on mouse position on the fader
      fy = self._backgroundShape.getY()  # global fader position
      y  = ey - fy                       # local event position

      valueRatio = 1- (y / self._backgroundShape.getHeight())  # (0.0 - 1.0)
      valueRatio = max(0.0, min(1.0, valueRatio))              # clamp ratio
      valueRange = self._maxValue - self._minValue             # possible values
      newValue   = self._minValue + (valueRatio * valueRange)  # scale to range
      self.setValue(newValue)                                  # update value

   def _updateAppearance(self):
      """
      Redraws the control based on its current value.
      """
      valueRatio = (self._value - self._minValue) / (self._maxValue - self._minValue)  # (0.0 - 1.0)
      width, height = self._backgroundShape.getSize()
      x,     y      = self._backgroundShape.getPosition()
      padding       = self._outlineShape.getThickness() / 2

      fWidth  = (width  - (2 * padding))  # find maximum fader bar dimensions
      fHeight = (height - (2 * padding))  # ...
      fx      = x + padding               # ...
      fy      = y + padding               # ...
      # As the ratio decreases, the fader bar's height decreases,
      # while its y position increases downward, giving the illusion
      # of shrinking.  We do a little algebra to offset y appropriately.
      fy      = fy + (fHeight * (1 - valueRatio))
      fHeight = fHeight * valueRatio

      self._foregroundShape.setPosition(fx, fy)
      self._foregroundShape.setSize(fWidth, fHeight)

   def setValue(self, newValue):
      """
      Sets the control's current value, and updates its appearance.
      """
      newValue = max(self._minValue, min(self._maxValue, newValue))  # clamp value
      _MusicControl.setValue(self, newValue)  # update value and call user function


class Rotary(_MusicControl):
   """
   Rotary knob control.
   """
   def __init__(self, x1, y1, x2, y2, minValue=0, maxValue=999, startValue=None,
               action=None, foregroundColor=Color.RED, backgroundColor=Color.BLACK,
               outlineColor=Color.BLUE, thickness=3, arcWidth=300, rotation=0):
      """
      Creates a rotary knob with corners at (x1, y1) to (x2, y2).
      """
      _MusicControl.__init__(self, action)

      # calculate dimensions
      localX     = min(x1, x2)
      localY     = min(y1, y2)
      width      = abs(x1 - x2)
      height     = abs(y1 - y2)
      startAngle = 90 + arcWidth//2
      endAngle   = startAngle + arcWidth

      # initialize internal shapes
      self._backgroundShape = Arc(
         0, 0, width, height,
         startAngle, endAngle,
         style=PIE,
         color=backgroundColor,
         fill=True,
         thickness=0,
         rotation=0
      )
      self._foregroundShape = Arc(
         0, 0, width, height,
         startAngle, endAngle,
         style=PIE,
         color=foregroundColor,
         fill=True,
         thickness=0,
         rotation=0
      )
      self._outlineShape = Arc(
         0, 0, width, height,
         startAngle, endAngle,
         style=PIE,
         color=outlineColor,
         fill=False,
         thickness=thickness,
         rotation=0
      )

      self.add(self._backgroundShape)
      self.add(self._foregroundShape)
      self.add(self._outlineShape)

      # set starting attributes
      self.setPosition(localX, localY)
      self.setRotation(rotation)

      if startValue is None:
         startValue = (minValue + maxValue) / 2

      self._minValue = minValue
      self._maxValue = maxValue
      self._arcWidth = arcWidth
      self.setValue(startValue)

      # register default behavior events
      self.onMouseDown(self._defaultAction)
      self.onMouseDrag(self._defaultAction)

   def __str__(self):
      x1, y1          = self._backgroundShape.getPosition()
      width, height   = self._backgroundShape.getSize()
      x2              = x1 + width
      y2              = y1 + height
      foregroundColor = self._foregroundShape.getColor()
      backgroundColor = self._backgroundShape.getColor()
      outlineColor    = self._outlineShape.getColor()
      thickness       = self._outlineShape.getThickness()
      rotation        = self.getRotation()
      return f'Rotary(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, minValue = {self._minValue}, maxValue = {self._maxValue}, startValue = {self.getValue()}, action = {self._action}, foreground = {foregroundColor}, background = {backgroundColor}, outline = {outlineColor}, thickness = {thickness}, arcWidth = {self._arcWidth}, rotation = {rotation})'

   # OVERRIDDEN METHODS
   def _defaultAction(self, ex, ey):
      """
      Defines the default behavior of the control.
      Rotaries update their value based on the position of the mouse, in an arc
      around their bottom-center point.
      """
      # update rotary value based on mouse position
      rx, ry = self._backgroundShape.getPosition()  # global rotary position
      x = ex - rx                                   # local event position
      y = ey - ry                                   # ...

      width, height = self._backgroundShape.getSize()
      cx = width / 2                                       # local rotary center
      cy = height / 2                                      # ...
      dx = x - cx                                          # vector to event pos
      dy = cy - y                                          # ...
      mouseAngle = np.degrees(np.arctan2(dy, dx)) % 360    # angle (in degrees)
      startAngle = 90 + self._arcWidth/2                   # rotary start
      eventWidth = (startAngle - mouseAngle) % 360         # from start to mouse

      if 0 <= eventWidth <= self._arcWidth:  # skip if width outside of arc
         valueRatio = eventWidth / self._arcWidth                 # (0.0 - 1.0)
         valueRatio = max(0.0, min(1.0, valueRatio))              # clamp ratio
         valueRange = self._maxValue - self._minValue             # possible values
         newValue   = self._minValue + (valueRatio * valueRange)  # scale to range
         self.setValue(newValue)                                  # set value

   def _updateAppearance(self):
      """
      Redraws the control based on its current value.
      Sends a setArcWidth command to the renderer to rebuild the foreground arc path.
      """
      valueRatio = (self._value - self._minValue) / (self._maxValue - self._minValue)  # 0.0 to 1.0
      arcWidth   = self._arcWidth * valueRatio                                          # scale to value
      self._foregroundShape._setArcWidth(arcWidth)

   def setValue(self, newValue):
      """
      Sets the control's current value, and updates its appearance.
      """
      newValue = max(self._minValue, min(self._maxValue, newValue))  # clamp value
      _MusicControl.setValue(self, newValue)  # update value and call user function


class Push(_MusicControl):
   """
   Push button that resets when released.
   """
   def __init__(self, x1, y1, x2, y2, action=None, foregroundColor=Color.RED, backgroundColor=Color.BLACK, outlineColor=Color.CLEAR, thickness=3, rotation=0):
      """
      Creates a push button with corners at (x1, y1) to (x2, y2).
      """
      _MusicControl.__init__(self, action)

      # calculate dimensions
      localX  = min(x1, x2)
      localY  = min(y1, y2)
      width   = abs(x1 - x2)
      height  = abs(y1 - y2)
      padding = thickness//2 + 1

      # initialize internal shapes
      self._backgroundShape = Rectangle(
         0, 0, width, height,
         color=backgroundColor,
         fill=True,
         thickness=0,
         rotation=0
      )
      self._foregroundShape = Rectangle(
         padding, padding, (width - padding), (height - padding),
         color=foregroundColor,
         fill=True,
         thickness=0,
         rotation=0
      )
      self._outlineShape = Rectangle(
         0, 0, width, height,
         color=outlineColor,
         fill=False,
         thickness=thickness,
         rotation=0
      )

      self.add(self._backgroundShape)
      self.add(self._foregroundShape)
      self.add(self._outlineShape)

      # set starting attributes
      self.setPosition(localX, localY)
      self.setRotation(rotation)
      self.setValue(False)

      # register default behavior events
      self.onMouseDown(self._defaultAction)
      self.onMouseUp(self._secondaryAction)
      self.onMouseExit(self._secondaryAction)

   def __str__(self):
      x1, y1          = self._backgroundShape.getPosition()
      width, height   = self._backgroundShape.getSize()
      x2              = x1 + width
      y2              = y1 + height
      foregroundColor = self._foregroundShape.getColor()
      backgroundColor = self._backgroundShape.getColor()
      outlineColor    = self._outlineShape.getColor()
      thickness       = self._outlineShape.getThickness()
      rotation        = self.getRotation()
      return f'Push(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, action = {self._action}, foreground = {foregroundColor}, background = {backgroundColor}, outline = {outlineColor}, thickness = {thickness}, rotation = {rotation})'

   # OVERRIDDEN METHODS
   def _defaultAction(self, ex, ey):
      """
      Defines the default behavior of the control.
      Pushes value becomes True when the mouse is pressed down while over it,
      and become False when the mouse is released or leaves the Push's area.
      """
      # this event triggers only on mouseDown
      self.setValue(True)

   def _secondaryAction(self, ex, ey):
      """
      Defines the secondary behavior of the control.
      Pushes value becomes True when the mouse is pressed down while over it,
      and become False when the mouse is released or leaves the Push's area.
      """
      # this event triggers on mouseUp or mouseExit
      self.setValue(False)

   def _updateAppearance(self):
      """
      Redraws the control based on its current value.
      """
      if self._value:
         self._foregroundShape._show()
      else:
         self._foregroundShape._hide()


class Toggle(Push):
   """
   Rectangular on/off button.
   """
   def __init__(self, x1, y1, x2, y2, action=None, foregroundColor=Color.RED, backgroundColor=Color.BLACK, outlineColor=Color.CLEAR, thickness=3, rotation=0):
      """
      Creates a toggle button with corners at (x1, y1) to (x2, y2).
      """
      Push.__init__(self, x1, y1, x2, y2, action, foregroundColor, backgroundColor, outlineColor, thickness, rotation)

   def __str__(self):
      x1, y1          = self._backgroundShape.getPosition()
      width, height   = self._backgroundShape.getSize()
      x2              = x1 + width
      y2              = y1 + height
      foregroundColor = self._foregroundShape.getColor()
      backgroundColor = self._backgroundShape.getColor()
      outlineColor    = self._outlineShape.getColor()
      thickness       = self._outlineShape.getThickness()
      rotation        = self.getRotation()
      return f'Toggle(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, action = {self._action}, foreground = {foregroundColor}, background = {backgroundColor}, outline = {outlineColor}, thickness = {thickness}, rotation = {rotation})'

   # OVERRIDDEN METHODS
   def _defaultAction(self, ex, ey):
      """
      Defines the default behavior of the control.
      Toggles flip their value on each mouse press and stay latched until pressed again.
      """
      self.setValue(not self._value)

   def _secondaryAction(self, ex, ey):
      """
      Disables Push's reset-on-release behavior.
      Toggle state is latched, so mouseUp and mouseExit do nothing.
      """
      pass


class XYPad(_MusicControl):
   """
   2-Dimensional control that reports (x, y) values.
   """
   def __init__(self, x1, y1, x2, y2, action=None, foregroundColor=Color.RED, backgroundColor=Color.BLACK, outlineColor=Color.CLEAR, outlineThickness=2, trackerRadius=10, crosshairThickness=None, rotation=0):
      """
      Creates an XYPad with corners at (x1, y1) to (x2, y2).
      """
      _MusicControl.__init__(self, action)

      # calculate dimensions
      localX  = min(x1, x2)
      localY  = min(y1, y2)
      width   = abs(x1 - x2)
      height  = abs(y1 - y2)

      if crosshairThickness is None:
         crosshairThickness = outlineThickness

      # initialize internal shapes
      self._backgroundShape = Rectangle(
         0, 0, width, height,
         color=backgroundColor,
         fill=True,
         thickness=0,
         rotation=0
      )
      self._trackerXLine = Line(
         0, 0, 0, height,  # vertical line
         color=foregroundColor,
         thickness=crosshairThickness,
         rotation=0
      )
      self._trackerYLine = Line(
         0, 0, width, 0,  # horizontal line
         color=foregroundColor,
         thickness=crosshairThickness,
         rotation=0
      )
      self._foregroundShape = Circle(
         width/2, height/2,
         trackerRadius,
         color=foregroundColor,
         fill=False,
         thickness=crosshairThickness
         )
      self._outlineShape = Rectangle(
         0, 0, width, height,
         color=outlineColor,
         fill=False,
         thickness=outlineThickness,
         rotation=0
      )

      self.add(self._backgroundShape)
      self.add(self._trackerXLine)
      self.add(self._trackerYLine)
      self.add(self._foregroundShape)
      self.add(self._outlineShape)

      # set starting attributes
      self.setPosition(localX, localY)
      self.setRotation(rotation)
      self.setValue(width/2, height/2)

      # register default behavior events
      self.onMouseDown(self._defaultAction)
      self.onMouseDrag(self._defaultAction)

   def __str__(self):
      x1, y1             = self._backgroundShape.getPosition()
      width, height      = self._backgroundShape.getSize()
      x2                 = x1 + width
      y2                 = y1 + height
      foregroundColor    = self._foregroundShape.getColor()
      backgroundColor    = self._backgroundShape.getColor()
      outlineColor       = self._outlineShape.getColor()
      outlineThickness   = self._outlineShape.getThickness()
      trackerRadius      = self._foregroundShape.getRadius()
      crosshairThickness = self._foregroundShape.getThickness()
      rotation           = self.getRotation()

      return f'XYPad(x1 = {x1}, y1 = {y1}, x2 = {x2}, y2 = {y2}, action = {self._action}, foreground = {foregroundColor}, background = {backgroundColor}, outline = {outlineColor}, outlineThickness = {outlineThickness}, trackerRadius = {trackerRadius}, crosshairThickness = {crosshairThickness}, rotation = {rotation})'

   # OVERRIDDEN METHODS
   def _defaultAction(self, ex, ey):
      """
      Defines the default behavior of the control.
      XYPads update their value based on the mouse position relative to the pad.
      """
      mx, my = self._backgroundShape.getPosition()  # global XYPad position
      x = ex - mx                                   # local event position
      y = ey - my                                   # ...
      self.setValue(x, y)

   def _updateAppearance(self):
      """
      Redraws the control based on its current value.
      """
      vx, vy = self._value                          # local value position
      mx, my = self._backgroundShape.getPosition()  # global XYPad position
      x = mx + vx                                   # global value position
      y = my + vy                                   # ...

      self._trackerXLine.setX(x)
      self._trackerYLine.setY(y)
      self._foregroundShape.setPosition(x, y)

   def setValue(self, x, y):
      """
      Sets the control's current value, and updates its appearance.
      """
      width, height = self._backgroundShape.getSize()
      x = max(0, min(x, width))            # clamp values
      y = max(0, min(y, height))           # ...
      _MusicControl.setValue(self, [x, y])  # update value and call user function


#######################################################################################
# Control - system-styled interactable objects
#######################################################################################
class _Control(_Drawable):
   """
   Superclass for widgets that sit above the Display.
   Controls are Qt native widgets (QWidgets) that float above the scene,
   unaffected by z-ordering of graphics items.
   Position and size commands are handled by _ControlMirror, which uses
   .move() and .setFixedSize() instead of QGraphicsItem APIs.
   """
   def __init__(self):
      _Drawable.__init__(self)
      _Interactable.__init__(self)

#######################################################################################
class Button(_Control):
   """
   Clickable push button.
   """
   def __init__(self, text="", action=None, color=Color.LIGHT_GRAY):
      """
      Creates an interactive push button with optional text label.
      """
      _Control.__init__(self)

      self._action = action
      self._color  = color.getRGBA()

      _handler().sendCommand('create', self._objectId, {
         'type':  'Button',
         'text':  str(text),
         'color': self._color,
      })

      result       = _handler().sendQuery('getSize', self._objectId)
      self._width  = result[0]
      self._height = result[1]

      if action is not None:
         def _onClicked():
            action()
         _handler().registerEvent(self._objectId, 'clicked', _onClicked)

   def __str__(self):
      return f'Button(text = "{self.getText()}", action = {self._action})'

   def getText(self):
      """
      Returns the button's label text.
      """
      return _handler().sendQuery('getText', self._objectId)[0]

   def setText(self, text):
      """
      Sets the button's label text.  The button resizes to fit the new text.
      """
      _handler().sendCommand('setText', self._objectId, {'text': str(text)})
      result       = _handler().sendQuery('getSize', self._objectId)
      self._width  = result[0]
      self._height = result[1]

   def setColor(self, color):
      """
      Sets the button's background color.
      """
      if not isinstance(color, Color):
         raise TypeError(f'{type(self).__name__}.setColor(): color should be a Color object (it was {type(color).__name__})')
      r, g, b, a  = color.getRGBA()
      self._color  = [r, g, b, a]
      _handler().sendCommand('setColor', self._objectId, {'color': self._color})


class CheckBox(_Control):
   """
   Checkbox with checked/unchecked state.
   """
   def __init__(self, text="", action=None, color=Color.CLEAR):
      """
      Creates an interactive checkbox with optional text label.
      """
      _Control.__init__(self)

      self._action = action
      self._color  = color.getRGBA()

      _handler().sendCommand('create', self._objectId, {
         'type':  'CheckBox',
         'text':  str(text),
         'color': self._color,
      })

      result       = _handler().sendQuery('getSize', self._objectId)
      self._width  = result[0]
      self._height = result[1]

      if action is not None:
         def _onStateChanged(checked):
            action(checked)
         _handler().registerEvent(self._objectId, 'stateChanged', _onStateChanged)

   def __str__(self):
      return f'CheckBox(text = "{self.getText()}", action = {self._action})'

   def getText(self):
      """
      Returns the checkbox's label text.
      """
      return _handler().sendQuery('getText', self._objectId)[0]

   def setText(self, text):
      """
      Sets the checkbox's label text.  The widget resizes to fit the new text.
      """
      _handler().sendCommand('setText', self._objectId, {'text': str(text)})
      result       = _handler().sendQuery('getSize', self._objectId)
      self._width  = result[0]
      self._height = result[1]

   def setColor(self, color):
      """
      Sets the checkbox's background color.
      """
      if not isinstance(color, Color):
         raise TypeError(f'{type(self).__name__}.setColor(): color should be a Color object (it was {type(color).__name__})')
      r, g, b, a  = color.getRGBA()
      self._color  = [r, g, b, a]
      _handler().sendCommand('setColor', self._objectId, {'color': self._color})

   def isChecked(self):
      """
      Returns True if the checkbox is currently checked.
      """
      return _handler().sendQuery('isChecked', self._objectId)[0]

   def check(self):
      """
      Sets the checkbox to checked.
      """
      _handler().sendCommand('check', self._objectId)

   def uncheck(self):
      """
      Sets the checkbox to unchecked.
      """
      _handler().sendCommand('uncheck', self._objectId)


class Slider(_Control):
   """
   Slider control for numeric values.
   """
   def __init__(self, orientation=HORIZONTAL, minValue=0, maxValue=100, startValue=None, action=None):
      """
      Creates an interactive slider.
      """
      _Control.__init__(self)

      if startValue is None:
         startValue = int((minValue + maxValue) / 2)

      self._action    = action
      self._orientation = orientation
      self._minValue    = minValue
      self._maxValue    = maxValue

      _handler().sendCommand('create', self._objectId, {
         'type':        'Slider',
         'orientation': orientation,
         'minValue':    minValue,
         'maxValue':    maxValue,
         'startValue':  startValue,
      })

      result       = _handler().sendQuery('getSize', self._objectId)
      self._width  = result[0]
      self._height = result[1]

      if action is not None:
         def _onValueChanged(value):
            action(value)
         _handler().registerEvent(self._objectId, 'valueChanged', _onValueChanged)

   def __str__(self):
      return f'Slider(orientation = {self._orientation}, minValue = {self._minValue}, maxValue = {self._maxValue}, startValue = {self.getValue()}, action = {self._action})'

   def getValue(self):
      """
      Returns the slider's current value.
      """
      return _handler().sendQuery('getValue', self._objectId)[0]

   def setValue(self, value):
      """
      Sets the slider's current value.
      """
      _handler().sendCommand('setValue', self._objectId, {'value': int(value)})


class DropDownList(_Control):
   """
   Drop-down selection list.
   """
   def __init__(self, items=[], action=None, color=Color.LIGHT_GRAY):
      """
      Creates an interactive drop-down list with given items.
      """
      _Control.__init__(self)

      self._action = action
      self._items    = list(items)
      self._color    = color.getRGBA()

      _handler().sendCommand('create', self._objectId, {
         'type':  'DropDownList',
         'items': self._items,
         'color': self._color,
      })

      result       = _handler().sendQuery('getSize', self._objectId)
      self._width  = result[0]
      self._height = result[1]

      if action is not None:
         def _onActivated(index):
            action(self._items[index])
         _handler().registerEvent(self._objectId, 'activated', _onActivated)

   def __str__(self):
      return f'DropDownList(items = {self._items}, action = {self._action})'

   def setColor(self, color):
      """
      Sets the dropdown's background color.
      """
      if not isinstance(color, Color):
         raise TypeError(f'{type(self).__name__}.setColor(): color should be a Color object (it was {type(color).__name__})')
      r, g, b, a  = color.getRGBA()
      self._color  = [r, g, b, a]
      _handler().sendCommand('setColor', self._objectId, {'color': self._color})


class TextField(_Control):
   """
   Single-line editable text field.
   """
   def __init__(self, text="", columns=8, action=None, color=Color.WHITE, font=None):
      """
      Creates a single-line text field with optional starting text.
      """
      _Control.__init__(self)

      self._action = action
      self._columns  = columns
      self._font     = None
      self._color    = color.getRGBA()

      _handler().sendCommand('create', self._objectId, {
         'type':    'TextField',
         'text':    str(text),
         'columns': columns,
         'color':   self._color,
         'font':    None,
      })

      result       = _handler().sendQuery('getSize', self._objectId)
      self._width  = result[0]
      self._height = result[1]

      if font is not None:
         self.setFont(font)

      if action is not None:
         def _onReturnPressed(text):
            action(text)
         _handler().registerEvent(self._objectId, 'returnPressed', _onReturnPressed)

   def __str__(self):
      return f'TextField(text = "{self.getText()}", columns = {self._columns}, action = {self._action})'

   def getText(self):
      """
      Returns the current text.
      """
      return _handler().sendQuery('getText', self._objectId)[0]

   def setText(self, text):
      """
      Sets the current text.
      """
      _handler().sendCommand('setText', self._objectId, {'text': str(text)})

   def setColor(self, color):
      """
      Sets the text field's background color.
      """
      if not isinstance(color, Color):
         raise TypeError(f'{type(self).__name__}.setColor(): color should be a Color object (it was {type(color).__name__})')
      r, g, b, a  = color.getRGBA()
      self._color  = [r, g, b, a]
      _handler().sendCommand('setColor', self._objectId, {'color': self._color})

   def getFont(self):
      """
      Returns the text field's font, or None if it was not set.
      """
      if self._font is not None:
         name, style, size = self._font
         return Font(name, style, size)
      return None

   def setFont(self, font):
      """
      Sets the text field's font.
      """
      if font is not None:
         name       = font.getName()
         style      = font.getStyle()
         size       = font.getSize()
         self._font = [name, style, size]
         _handler().sendCommand('setFont', self._objectId, {'font': [name, style, size]})


class TextArea(_Control):
   """
   Multi-line editable text field.
   """
   def __init__(self, text="", columns=8, rows=5, color=Color.WHITE, font=None):
      """
      Creates a multi-line text field with optional starting text.
      """
      _Control.__init__(self)

      self._columns = columns
      self._rows    = rows
      self._font    = None
      self._color   = color.getRGBA()

      _handler().sendCommand('create', self._objectId, {
         'type':    'TextArea',
         'text':    str(text),
         'columns': columns,
         'rows':    rows,
         'color':   self._color,
         'font':    None,
      })

      result       = _handler().sendQuery('getSize', self._objectId)
      self._width  = result[0]
      self._height = result[1]

      if font is not None:
         self.setFont(font)

   def __str__(self):
      return f'TextArea(text = "{self.getText()}", columns = {self._columns}, rows = {self._rows})'

   def getText(self):
      """
      Returns the current text.
      """
      return _handler().sendQuery('getText', self._objectId)[0]

   def setText(self, text):
      """
      Sets the current text.
      """
      _handler().sendCommand('setText', self._objectId, {'text': str(text)})

   def setColor(self, color):
      """
      Sets the text area's background color.
      """
      if not isinstance(color, Color):
         raise TypeError(f'{type(self).__name__}.setColor(): color should be a Color object (it was {type(color).__name__})')
      r, g, b, a  = color.getRGBA()
      self._color  = [r, g, b, a]
      _handler().sendCommand('setColor', self._objectId, {'color': self._color})

   def getFont(self):
      """
      Returns the text area's font, or None if it was not set.
      """
      if self._font is not None:
         name, style, size = self._font
         return Font(name, style, size)
      return None

   def setFont(self, font):
      """
      Sets the text area's font.
      """
      if font is not None:
         name       = font.getName()
         style      = font.getStyle()
         size       = font.getSize()
         self._font = [name, style, size]
         _handler().sendCommand('setFont', self._objectId, {'font': [name, style, size]})


class Menu():
   """
   Pop-up or context menu containing selectable actions.
   """

   def __init__(self, title):
      """
      Creates a menu with given title.
      """
      self._objectId = _nextObjectId()
      self._name     = title
      self._actions  = []   # per-item callbacks; index matches itemIndex sent to renderer

      _handler().sendCommand('create', self._objectId, {
         'type':  'Menu',
         'title': str(title),
      })

      def _onItemTriggered(itemIndex):
         if 0 <= itemIndex < len(self._actions):
            action = self._actions[itemIndex]
            if callable(action):
               action()

      _handler().registerEvent(self._objectId, 'itemTriggered', _onItemTriggered)

   def __str__(self):
      return f'Menu(menuName = "{self._name}")'

   def __repr__(self):
      return str(self)

   def addItem(self, item="", action=None):
      """
      Adds a selectable item to the menu with optional callback.
      """
      itemIndex = len(self._actions)
      self._actions.append(action)
      _handler().sendCommand('addItem', self._objectId, {
         'text':      str(item),
         'itemIndex': itemIndex,
      })

   def addItemList(self, itemList=[""], actionList=[]):
      """
      Adds a list of items to the menu with optional corresponding callbacks.
      """
      for i in range(len(itemList)):
         item   = itemList[i]
         action = actionList[i] if i < len(actionList) else None
         self.addItem(item, action)

   def addSeparator(self):
      """
      Adds a separator to the menu.
      """
      _handler().sendCommand('addSeparator', self._objectId)

   def addSubmenu(self, menu):
      """
      Adds a submenu to the menu.
      """
      if not isinstance(menu, Menu):
         raise TypeError(f'{type(self).__name__}.addSubmenu(): menu should be a Menu object (it was {type(menu).__name__})')
      _handler().sendCommand('addSubmenu', self._objectId, {'submenuId': menu._objectId})

   def enable(self):
      """
      Enables menu interaction.
      """
      _handler().sendCommand('enable', self._objectId)

   def disable(self):
      """
      Disables menu interaction.
      """
      _handler().sendCommand('disable', self._objectId)


#######################################################################################
# Animate
#######################################################################################
# Animate is a static class that can register functions to call repeatedly.  
# This is essentially a Timer, but with a different API designed for students.
# This is basic functionality, inspired by MIT Processing's draw() function.  
# Anything more involved can be easily created using a Timer.

class Animate:
   """
   Animate provides methods to animate graphics and other function behavior at a
   global interval/framerate.
   """
   _ENGINE     = None       # animation timer, created the first time add() is called
   _rate       = 60 / 1000  # current framerate (in ms)
   _actionList = []         # list of registered callback functions

   @staticmethod
   def _startEngine():
      """
      Starts the animation engine.
      """
      if Animate._ENGINE is None:
         # create a new engine and start it
         from timer import Timer
         Animate._ENGINE = Timer(Animate._rate, Animate.tick, [], True)
         Animate._ENGINE.start()

   @staticmethod
   def tick():
      """
      Call each registered callback function once.
      """
      for action in Animate._actionList:
         if callable(action):
            action()

   @staticmethod
   def resume():
      """
      Continues the animation.
      """
      if Animate._ENGINE is not None:
         Animate._ENGINE.start()

   @staticmethod
   def pause():
      """
      Temporarily stops the animation.
      """
      if Animate._ENGINE is not None:
         Animate._ENGINE.stop()

   @staticmethod
   def add(action):
      """
      Register a new callback function to animate.
      A function can be registered multiple times, but must be removed
      """
      if callable(action):
         Animate._actionList.append(action)
         Animate._startEngine()   # start lazily on first add, after the fork
      else:
         print(f"Animate.add(): '{action.__name__}()' isn't a callable function.")

   @staticmethod
   def remove(action):
      """
      Deregisters a callback function that's being animated.
      If a function is registered multiple times, this only removes the earliest time it was registered.
      """
      if action in Animate._actionList:
         Animate._actionList.remove(action)

   @staticmethod
   def getRate():
      """
      Returns the current animation rate (in frames per second).
      """
      return int(Animate._rate * 1000)

   @staticmethod
   def setRate(frameRate):
      """
      Sets the current animation rate.
      """
      Animate._rate = (frameRate / 1000)
      
      if Animate._ENGINE is not None:
         # if an animation is started, also update the engine
         Animate._ENGINE.setDelay(Animate._rate)

# aliases for backwards compatibility
def animate(action):
   """
   Adds a function to be called repeatedly by the animation engine.
   """
   Animate.add(action)

def setAnimationRate(frameRate=60):
   """
   Set animation frame rate (frames per second).
   """
   Animate.setRate(frameRate)
   
def getAnimationRate():
   """
   Returns animation frame rate (frames per second).
   """
   return Animate.getRate()

def pauseAnimation():
   """
   Temporarily stops animation.
   """
   Animate.pause()

def resumeAnimation():
   """
   Resumes stopped animation.
   """
   Animate.resume()


#######################################################################################
# Test
#######################################################################################

if __name__ == "__main__":
   pass
