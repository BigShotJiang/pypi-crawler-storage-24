################################################################################
# image.py       Version 1.0     30-Jan-2025
# Taj Ballinger, Trevor Ritchie, and Bill Manaris
#
##############################################################
##################

from gui import Display, Icon

class Image(Display):
   """
   Display window for rendering images.
   """
   def __init__(self, arg1, arg2=None):
      """
      Creates a new image display.
      """
      # JythonMusic's Image class has overloaded constructors,
      # but Python doesn't allow that.  We replicate an overload based on the
      # data types of arg1 and arg2.
      #
      # (str, None) -> a filename for an image to load
      # (str, int)  -> a filename for an image to load, scaled to a width
      # (int, None) -> the width of a square, blank canvas
      # (int, int)  -> the width and height of a blank canvas

      if isinstance(arg1, str):
         # this is a filename
         title = arg1
         self._icon = Icon(arg1, arg2)  # load icon with optional parameter

      else:
         title = "Image"
         self._icon = Icon("", arg1, arg2)  # load blank icon with given dimensions

      width, height = self._icon.getSize()

      Display.__init__(self, title, width, height)
      self.add(self._icon)

   # pixel manipulation wrappers

   def getPixel(self, col, row):
      """
      Returns the [r, g, b] color of a given pixel in the image.
      """
      return self._icon.getPixel(col, row)

   def setPixel(self, col, row, RGBList):
      """
      Sets the [r, g, b] color of a given pixel in the image.
      """
      self._icon.setPixel(col, row, RGBList)

   def getPixels(self):
      """
      Returns the [r, g, b] color of all pixels in the icon as a 2-dimensional array.
      """
      return self._icon.getPixels()

   def setPixels(self, pixels):
      """
      Sets the [r, g, b] color of all pixels in the icon from a 2-dimensional array.
      """
      self._icon.setPixels(pixels)

###### Unit Tests ###################################

if __name__ == "__main__":
   pass