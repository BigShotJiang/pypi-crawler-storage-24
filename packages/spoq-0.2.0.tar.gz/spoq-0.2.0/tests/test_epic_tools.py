"""Unit tests for SPOQ epic management MCP tools."""

import json
from pathlib import Path

import pytest

from spoq_server.epic_tools import (
    spoq_analyze_dag,
    spoq_compute_waves,
    spoq_estimate_effort,
    spoq_generate_execution_plan,
    spoq_get_wave_tasks,
    spoq_parse_epic,
    spoq_validate_epic,
)


# =============================================================================
# spoq_parse_epic
# =============================================================================


class TestParseEpic:
    """Tests for the spoq_parse_epic tool."""

    def test_parse_epic_returns_valid_json(self, fixture_epic_path):
        raw = spoq_parse_epic(str(fixture_epic_path))
        data = json.loads(raw)
        assert "error" not in data

    def test_parse_epic_contains_metadata(self, fixture_epic_path):
        data = json.loads(spoq_parse_epic(str(fixture_epic_path)))
        assert "metadata" in data
        assert "title" in data["metadata"]
        assert data["metadata"]["title"] == "Config Validator Service"

    def test_parse_epic_contains_tasks(self, fixture_epic_path):
        data = json.loads(spoq_parse_epic(str(fixture_epic_path)))
        assert "tasks" in data
        assert len(data["tasks"]) == 4

    def test_parse_epic_contains_stats(self, fixture_epic_path):
        data = json.loads(spoq_parse_epic(str(fixture_epic_path)))
        assert "stats" in data
        stats = data["stats"]
        assert stats["total_tasks"] == 4
        assert stats["valid_tasks"] == 4
        assert stats["pending"] == 4

    def test_parse_epic_strips_source_file(self, fixture_epic_path):
        data = json.loads(spoq_parse_epic(str(fixture_epic_path)))
        for task in data["tasks"]:
            assert "_source_file" not in task

    def test_parse_epic_contains_epic_name(self, fixture_epic_path):
        data = json.loads(spoq_parse_epic(str(fixture_epic_path)))
        assert data["epic_name"] == "test-epic"

    def test_parse_epic_nonexistent_path(self):
        raw = spoq_parse_epic("/nonexistent/path/to/epic")
        data = json.loads(raw)
        assert "error" in data
        assert "not found" in data["error"].lower() or "not a directory" in data["error"].lower()

    def test_parse_epic_relative_path(self, fixture_epic_path):
        """Verify relative paths are resolved against project root."""
        # Use a path that definitely does not exist relative to project root
        raw = spoq_parse_epic("nonexistent/relative/epic")
        data = json.loads(raw)
        assert "error" in data


# =============================================================================
# spoq_validate_epic
# =============================================================================


class TestValidateEpic:
    """Tests for the spoq_validate_epic tool."""

    def test_validate_returns_valid_json(self, fixture_epic_path):
        raw = spoq_validate_epic(str(fixture_epic_path))
        data = json.loads(raw)
        assert "error" not in data

    def test_validate_has_required_keys(self, fixture_epic_path):
        data = json.loads(spoq_validate_epic(str(fixture_epic_path)))
        assert "errors" in data
        assert "warnings" in data
        assert "summary" in data

    def test_validate_summary_structure(self, fixture_epic_path):
        data = json.loads(spoq_validate_epic(str(fixture_epic_path)))
        summary = data["summary"]
        assert "valid" in summary
        assert "total_tasks" in summary
        assert "valid_tasks" in summary
        assert "error_count" in summary
        assert "warning_count" in summary

    def test_validate_fixture_epic_is_valid(self, fixture_epic_path):
        data = json.loads(spoq_validate_epic(str(fixture_epic_path)))
        assert data["summary"]["valid"] is True
        assert data["summary"]["error_count"] == 0

    def test_validate_fixture_no_warnings_above_threshold(self, fixture_epic_path):
        """The fixture epic has 7 success criteria (above the 5 threshold), so no warnings."""
        data = json.loads(spoq_validate_epic(str(fixture_epic_path)))
        # The fixture has 7 checkboxes which is >= 5, so no recommend warning
        recommend_warnings = [
            w for w in data["warnings"] if "recommend" in w.lower()
        ]
        assert len(recommend_warnings) == 0

    def test_validate_strict_mode_with_valid_epic(self, fixture_epic_path):
        """In strict mode, phase warnings become errors but fixture phases are consistent."""
        data_normal = json.loads(spoq_validate_epic(str(fixture_epic_path), strict=False))
        data_strict = json.loads(spoq_validate_epic(str(fixture_epic_path), strict=True))
        # Strict should have at least as many errors as normal mode
        assert data_strict["summary"]["error_count"] >= data_normal["summary"]["error_count"]
        # Phase warnings in normal mode should move to errors in strict mode
        phase_warnings_normal = len([w for w in data_normal["warnings"] if "phase" in w.lower()])
        phase_errors_strict = len([e for e in data_strict["errors"] if "phase" in e.lower()])
        assert phase_errors_strict >= phase_warnings_normal

    def test_validate_nonexistent_path(self):
        raw = spoq_validate_epic("/nonexistent/epic/path")
        data = json.loads(raw)
        assert "error" in data
        assert "not found" in data["error"].lower()

    def test_validate_task_count_matches(self, fixture_epic_path):
        data = json.loads(spoq_validate_epic(str(fixture_epic_path)))
        assert data["summary"]["total_tasks"] == 4
        assert data["summary"]["valid_tasks"] == 4


# =============================================================================
# spoq_compute_waves
# =============================================================================


class TestComputeWaves:
    """Tests for the spoq_compute_waves tool."""

    def test_compute_waves_returns_valid_json(self, fixture_epic_path):
        raw = spoq_compute_waves(str(fixture_epic_path))
        data = json.loads(raw)
        assert "error" not in data

    def test_compute_waves_has_required_keys(self, fixture_epic_path):
        data = json.loads(spoq_compute_waves(str(fixture_epic_path)))
        assert "epic_name" in data
        assert "total_waves" in data
        assert "total_tasks" in data
        assert "waves" in data

    def test_compute_waves_fixture_produces_three_waves(self, fixture_epic_path):
        data = json.loads(spoq_compute_waves(str(fixture_epic_path)))
        assert data["total_waves"] == 3
        assert data["total_tasks"] == 4

    def test_compute_waves_wave_structure(self, fixture_epic_path):
        data = json.loads(spoq_compute_waves(str(fixture_epic_path)))
        for wave in data["waves"]:
            assert "wave" in wave
            assert "task_count" in wave
            assert "tasks" in wave
            for task in wave["tasks"]:
                assert "id" in task
                assert "title" in task
                assert "status" in task
                assert "priority" in task
                assert "dependencies" in task

    def test_compute_waves_wave0_has_two_tasks(self, fixture_epic_path):
        data = json.loads(spoq_compute_waves(str(fixture_epic_path)))
        wave0 = data["waves"][0]
        assert wave0["wave"] == 0
        assert wave0["task_count"] == 2
        task_ids = [t["id"] for t in wave0["tasks"]]
        assert "01-setup" in task_ids
        assert "02-core" in task_ids

    def test_compute_waves_wave1_has_api(self, fixture_epic_path):
        data = json.loads(spoq_compute_waves(str(fixture_epic_path)))
        wave1 = data["waves"][1]
        assert wave1["wave"] == 1
        assert wave1["task_count"] == 1
        assert wave1["tasks"][0]["id"] == "03-api"

    def test_compute_waves_wave2_has_tests(self, fixture_epic_path):
        data = json.loads(spoq_compute_waves(str(fixture_epic_path)))
        wave2 = data["waves"][2]
        assert wave2["wave"] == 2
        assert wave2["task_count"] == 1
        assert wave2["tasks"][0]["id"] == "04-tests"

    def test_compute_waves_with_critical_path(self, fixture_epic_path):
        data = json.loads(
            spoq_compute_waves(str(fixture_epic_path), critical_path=True)
        )
        assert "critical_path" in data
        cp = data["critical_path"]
        assert "tasks" in cp
        assert "duration_hours" in cp
        assert "length" in cp
        assert len(cp["tasks"]) >= 2

    def test_compute_waves_without_critical_path(self, fixture_epic_path):
        data = json.loads(
            spoq_compute_waves(str(fixture_epic_path), critical_path=False)
        )
        assert "critical_path" not in data

    def test_compute_waves_nonexistent_path(self):
        raw = spoq_compute_waves("/nonexistent/epic/path")
        data = json.loads(raw)
        assert "error" in data


# =============================================================================
# spoq_generate_execution_plan
# =============================================================================


class TestGenerateExecutionPlan:
    """Tests for the spoq_generate_execution_plan tool."""

    def test_returns_valid_json(self, fixture_epic_path):
        raw = spoq_generate_execution_plan(str(fixture_epic_path))
        data = json.loads(raw)
        assert "error" not in data

    def test_has_required_keys(self, fixture_epic_path):
        data = json.loads(spoq_generate_execution_plan(str(fixture_epic_path)))
        assert "epic_name" in data
        assert "total_waves" in data
        assert "total_tasks" in data
        assert "actionable_tasks" in data
        assert "waves" in data

    def test_all_pending_tasks_are_actionable(self, fixture_epic_path):
        data = json.loads(spoq_generate_execution_plan(str(fixture_epic_path)))
        # Fixture has all tasks pending, so all should be actionable
        assert data["actionable_tasks"] == data["total_tasks"]

    def test_wave_has_actionable_count(self, fixture_epic_path):
        data = json.loads(spoq_generate_execution_plan(str(fixture_epic_path)))
        wave0 = data["waves"][0]
        assert "actionable_tasks" in wave0
        assert "total_tasks" in wave0
        assert wave0["actionable_tasks"] == wave0["total_tasks"]

    def test_task_has_actionable_flag(self, fixture_epic_path):
        data = json.loads(spoq_generate_execution_plan(str(fixture_epic_path)))
        task = data["waves"][0]["tasks"][0]
        assert "actionable" in task
        assert task["actionable"] is True

    def test_task_includes_files_and_skills(self, fixture_epic_path):
        data = json.loads(spoq_generate_execution_plan(str(fixture_epic_path)))
        task = data["waves"][0]["tasks"][0]
        assert "files_to_touch" in task
        assert "skills_required" in task

    def test_completed_task_not_actionable(self, tmp_epic_copy):
        """After marking a task completed, it should not be actionable."""
        import yaml

        # Mark 01-setup as completed
        task_file = tmp_epic_copy / "tasks" / "01-setup.yml"
        task_data = yaml.safe_load(task_file.read_text())
        task_data["status"] = "completed"
        task_file.write_text(yaml.dump(task_data, default_flow_style=False, sort_keys=False))

        data = json.loads(spoq_generate_execution_plan(str(tmp_epic_copy)))
        # Find the completed task
        for wave in data["waves"]:
            for task in wave["tasks"]:
                if task["id"] == "01-setup":
                    assert task["actionable"] is False
                    break
        # Total actionable should be total - 1
        assert data["actionable_tasks"] == data["total_tasks"] - 1

    def test_includes_critical_path_by_default(self, fixture_epic_path):
        data = json.loads(spoq_generate_execution_plan(str(fixture_epic_path)))
        assert "critical_path" in data
        cp = data["critical_path"]
        assert "tasks" in cp
        assert "duration_hours" in cp
        assert "length" in cp

    def test_critical_path_task_has_wave(self, fixture_epic_path):
        data = json.loads(spoq_generate_execution_plan(str(fixture_epic_path)))
        cp_task = data["critical_path"]["tasks"][0]
        assert "wave" in cp_task
        assert "id" in cp_task
        assert "title" in cp_task

    def test_without_critical_path(self, fixture_epic_path):
        data = json.loads(
            spoq_generate_execution_plan(str(fixture_epic_path), include_critical_path=False)
        )
        assert "critical_path" not in data

    def test_nonexistent_path(self):
        data = json.loads(spoq_generate_execution_plan("/nonexistent/path"))
        assert "error" in data


# =============================================================================
# spoq_get_wave_tasks
# =============================================================================


class TestGetWaveTasks:
    """Tests for the spoq_get_wave_tasks tool."""

    def test_get_wave_0_returns_valid_json(self, fixture_epic_path):
        raw = spoq_get_wave_tasks(str(fixture_epic_path), wave=0)
        data = json.loads(raw)
        assert "error" not in data

    def test_get_wave_0_has_required_keys(self, fixture_epic_path):
        data = json.loads(spoq_get_wave_tasks(str(fixture_epic_path), wave=0))
        assert "wave" in data
        assert "task_count" in data
        assert "tasks" in data

    def test_get_wave_0_task_details(self, fixture_epic_path):
        data = json.loads(spoq_get_wave_tasks(str(fixture_epic_path), wave=0))
        assert data["wave"] == 0
        assert data["task_count"] == 2
        for task in data["tasks"]:
            assert "id" in task
            assert "title" in task
            assert "status" in task
            assert "dependencies" in task
            assert "files_to_touch" in task
            assert "skills_required" in task

    def test_get_wave_1_has_api_task(self, fixture_epic_path):
        data = json.loads(spoq_get_wave_tasks(str(fixture_epic_path), wave=1))
        assert data["task_count"] == 1
        task = data["tasks"][0]
        assert task["id"] == "03-api"
        assert "01-setup" in task["dependencies"]
        assert "02-core" in task["dependencies"]

    def test_get_wave_2_has_test_task(self, fixture_epic_path):
        data = json.loads(spoq_get_wave_tasks(str(fixture_epic_path), wave=2))
        assert data["task_count"] == 1
        assert data["tasks"][0]["id"] == "04-tests"

    def test_get_wave_invalid_number(self, fixture_epic_path):
        raw = spoq_get_wave_tasks(str(fixture_epic_path), wave=99)
        data = json.loads(raw)
        assert "error" in data
        assert "99" in data["error"]
        assert "Available waves" in data["error"]

    def test_get_wave_nonexistent_path(self):
        raw = spoq_get_wave_tasks("/nonexistent/epic/path", wave=0)
        data = json.loads(raw)
        assert "error" in data

    def test_get_wave_skills_and_files(self, fixture_epic_path):
        """Wave 0 tasks should include skills and files_to_touch."""
        data = json.loads(spoq_get_wave_tasks(str(fixture_epic_path), wave=0))
        task_ids = {t["id"]: t for t in data["tasks"]}
        setup = task_ids["01-setup"]
        assert "python" in setup["skills_required"]
        assert "src/config.py" in setup["files_to_touch"]


# =============================================================================
# spoq_analyze_dag
# =============================================================================


class TestAnalyzeDag:
    """Tests for the spoq_analyze_dag tool."""

    def test_analyze_dag_returns_valid_json(self, fixture_epic_path):
        raw = spoq_analyze_dag(str(fixture_epic_path))
        data = json.loads(raw)
        assert "error" not in data

    def test_analyze_dag_has_required_keys(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path)))
        assert "epic_name" in data
        assert "total_tasks" in data
        assert "critical_path" in data
        assert "parallelism" in data
        assert "effort" in data

    def test_analyze_dag_critical_path_structure(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path)))
        cp = data["critical_path"]
        assert "tasks" in cp
        assert "duration_hours" in cp
        assert "task_details" in cp
        assert len(cp["tasks"]) >= 2
        assert cp["duration_hours"] > 0

    def test_analyze_dag_critical_path_details(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path)))
        cp = data["critical_path"]
        for detail in cp["task_details"]:
            assert "id" in detail
            assert "title" in detail
            assert "duration" in detail

    def test_analyze_dag_parallelism_structure(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path)))
        par = data["parallelism"]
        assert "wave_count" in par
        assert "max_parallelism" in par
        assert "wave0_tasks" in par
        assert "wave0_ratio" in par
        assert "waves" in par

    def test_analyze_dag_parallelism_values(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path)))
        par = data["parallelism"]
        assert par["wave_count"] == 3
        assert par["max_parallelism"] == 2
        assert par["wave0_tasks"] == 2
        assert par["wave0_ratio"] == 0.5

    def test_analyze_dag_effort_structure(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path)))
        effort = data["effort"]
        assert "total_hours" in effort
        assert "total_pert_hours" in effort
        assert "critical_path_hours" in effort
        assert "parallel_estimate_hours" in effort
        assert "speedup_factor" in effort
        assert "num_agents" in effort

    def test_analyze_dag_effort_values(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path)))
        effort = data["effort"]
        assert effort["total_hours"] > 0
        assert effort["total_pert_hours"] > 0
        assert effort["speedup_factor"] >= 1.0
        assert effort["num_agents"] == 4

    def test_analyze_dag_custom_agents(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path), agents=2))
        assert data["effort"]["num_agents"] == 2

    def test_analyze_dag_nonexistent_path(self):
        raw = spoq_analyze_dag("/nonexistent/epic/path")
        data = json.loads(raw)
        assert "error" in data

    def test_analyze_dag_total_tasks(self, fixture_epic_path):
        data = json.loads(spoq_analyze_dag(str(fixture_epic_path)))
        assert data["total_tasks"] == 4


# =============================================================================
# spoq_estimate_effort
# =============================================================================


class TestEstimateEffort:
    """Tests for the spoq_estimate_effort tool."""

    def test_estimate_returns_valid_json(self, fixture_epic_path):
        raw = spoq_estimate_effort(str(fixture_epic_path))
        data = json.loads(raw)
        assert "error" not in data

    def test_estimate_has_required_keys(self, fixture_epic_path):
        data = json.loads(spoq_estimate_effort(str(fixture_epic_path)))
        assert "epic_name" in data
        assert "total_tasks" in data
        assert "wave_count" in data
        assert "estimates" in data
        assert "waves" in data

    def test_estimate_summary_structure(self, fixture_epic_path):
        data = json.loads(spoq_estimate_effort(str(fixture_epic_path)))
        estimates = data["estimates"]
        assert "total_pert_hours" in estimates
        assert "sequential_hours" in estimates
        assert "parallel_hours" in estimates
        assert "speedup_factor" in estimates

    def test_estimate_values_are_positive(self, fixture_epic_path):
        data = json.loads(spoq_estimate_effort(str(fixture_epic_path)))
        estimates = data["estimates"]
        assert estimates["total_pert_hours"] > 0
        assert estimates["sequential_hours"] > 0
        assert estimates["parallel_hours"] > 0
        assert estimates["speedup_factor"] >= 1.0

    def test_estimate_parallel_less_than_sequential(self, fixture_epic_path):
        data = json.loads(spoq_estimate_effort(str(fixture_epic_path)))
        estimates = data["estimates"]
        assert estimates["parallel_hours"] <= estimates["sequential_hours"]

    def test_estimate_wave_structure(self, fixture_epic_path):
        data = json.loads(spoq_estimate_effort(str(fixture_epic_path)))
        assert data["wave_count"] == 3
        # Waves are keyed as strings in JSON
        for wave_key in ["0", "1", "2"]:
            assert wave_key in data["waves"]
            wave = data["waves"][wave_key]
            assert "task_count" in wave
            assert "total_pert" in wave
            assert "parallel_duration" in wave
            assert "tasks" in wave

    def test_estimate_wave_task_details(self, fixture_epic_path):
        data = json.loads(spoq_estimate_effort(str(fixture_epic_path)))
        wave0 = data["waves"]["0"]
        assert wave0["task_count"] == 2
        for task in wave0["tasks"]:
            assert "id" in task
            assert "title" in task
            assert "optimistic" in task
            assert "realistic" in task
            assert "pessimistic" in task
            assert "pert" in task
            # PERT should be between optimistic and pessimistic
            assert task["optimistic"] <= task["pert"] <= task["pessimistic"]

    def test_estimate_pert_formula(self, fixture_epic_path):
        """Verify PERT = (O + 4M + P) / 6 for a known task."""
        data = json.loads(spoq_estimate_effort(str(fixture_epic_path)))
        wave0 = data["waves"]["0"]
        # 01-setup: O=30m=0.5h, M=1h, P=2h => PERT = (0.5 + 4*1 + 2) / 6 = 6.5/6 ~ 1.083
        setup_task = next(t for t in wave0["tasks"] if t["id"] == "01-setup")
        expected_pert = (0.5 + 4 * 1.0 + 2.0) / 6
        assert abs(setup_task["pert"] - expected_pert) < 0.01

    def test_estimate_nonexistent_path(self):
        raw = spoq_estimate_effort("/nonexistent/epic/path")
        data = json.loads(raw)
        assert "error" in data

    def test_estimate_total_tasks(self, fixture_epic_path):
        data = json.loads(spoq_estimate_effort(str(fixture_epic_path)))
        assert data["total_tasks"] == 4
        assert data["epic_name"] == "test-epic"
