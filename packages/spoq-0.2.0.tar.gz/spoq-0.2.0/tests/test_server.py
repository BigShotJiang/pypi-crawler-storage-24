"""Unit tests for SPOQ MCP server core."""

import json
import pytest


def test_server_imports():
    """Verify server module imports without error."""
    from spoq_server.server import mcp, project_root
    assert mcp is not None
    assert mcp.name == "spoq"


def test_project_root_exists():
    """Verify project_root() resolves to a directory with .git."""
    from spoq_server.server import project_root
    root = project_root()
    assert root.exists()
    assert (root / ".git").exists()


def test_bundled_utils_importable():
    """Verify bundled epic_utils and map_utils import without error."""
    from spoq_server import epic_utils, map_utils
    assert hasattr(epic_utils, "parse_epic")
    assert hasattr(map_utils, "parse_map_md")


def test_spoq_ping():
    """Verify spoq_ping returns valid JSON with expected keys."""
    from spoq_server.server import spoq_ping
    result = json.loads(spoq_ping())
    assert result["status"] == "ok"
    assert "version" in result
    assert "project_root" in result
    assert "package" in result


def test_version():
    """Verify package version is set."""
    from spoq_server import __version__
    assert __version__ == "0.2.0"
