"""Pytest configuration and shared fixtures for SPOQ MCP server tests."""

import shutil
from pathlib import Path

import pytest


# --- Fixtures -----------------------------------------------------------------

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def fixture_epic_path() -> Path:
    """Return the path to the test-epic fixture directory."""
    path = FIXTURES_DIR / "test-epic"
    assert path.exists(), f"Fixture not found: {path}"
    return path


@pytest.fixture
def tmp_epic_copy(tmp_path: Path, fixture_epic_path: Path) -> Path:
    """
    Copy the test-epic fixture to a temporary directory.

    Use this for tests that mutate task files (e.g., status updates)
    to avoid corrupting shared fixtures.
    """
    dest = tmp_path / "test-epic"
    shutil.copytree(fixture_epic_path, dest)
    return dest


@pytest.fixture
def fixture_map_path() -> Path:
    """Return the path to the test-map fixture directory."""
    path = FIXTURES_DIR / "test-map"
    assert path.exists(), f"Fixture not found: {path}"
    return path


@pytest.fixture
def fixture_map_epics_path() -> Path:
    """Return the path to the test-map-epics fixture directory."""
    path = FIXTURES_DIR / "test-map-epics"
    assert path.exists(), f"Fixture not found: {path}"
    return path


@pytest.fixture
def tmp_map_copy(
    tmp_path: Path, fixture_map_path: Path, fixture_map_epics_path: Path
) -> tuple[Path, Path]:
    """
    Copy both the test-map and test-map-epics fixtures to a temporary directory.

    Returns (map_dest, epics_dest) paths.
    """
    map_dest = tmp_path / "test-map"
    epics_dest = tmp_path / "test-map-epics"
    shutil.copytree(fixture_map_path, map_dest)
    shutil.copytree(fixture_map_epics_path, epics_dest)
    return map_dest, epics_dest
