"""SPOQ project initialization command.

Bootstraps a project directory with SPOQ structure, templates, and
optional MCP configuration. Replaces the shell-based spoq-init.sh
for users who install SPOQ via pip/PyPI.
"""

import json
import shutil
from pathlib import Path


# =============================================================================
# Skill Stubs — minimal SKILL.md files for Claude Code discovery
# =============================================================================

SKILL_STUBS = {
    "epic-planning": {
        "name": "epic-planning",
        "description": "Decompose high-level goals into structured epics with atomic tasks, dependency DAGs, and wave-based phases.",
        "body": "Use `/epic-planning` to start a planning session. Creates epics in `spoq/epics/active/` with EPIC.md and task YAMLs.\n\nFor multi-epic programs, use `/epic-planning --map \"Program name\"` to create a coordinated map.",
    },
    "epic-validation": {
        "name": "epic-validation",
        "description": "Validate EPIC.md files and task sets with 10 planning-focused metrics (0-100).",
        "body": "Use `/epic-validation spoq/epics/active/my-epic` to score an epic against 10 planning quality metrics. Pass threshold: 95 average, 90 minimum per metric.",
    },
    "agent-execution": {
        "name": "agent-execution",
        "description": "Orchestrate parallel sub-agent swarms on epics.",
        "body": "Use `/agent-execution spoq/epics/active/my-epic` to execute tasks with Opus workers dispatched wave-by-wave.",
    },
    "agent-validation": {
        "name": "agent-validation",
        "description": "Validate sub-agent work against task definitions with 10-metric scoring.",
        "body": "Use `/agent-validation` after agent execution to score delivered code. Pass threshold: 95 average, 80 minimum per metric.",
    },
    "team-execution": {
        "name": "team-execution",
        "description": "Orchestrate wave-based agent teams with persona-specialized workers.",
        "body": "Use `/team-execution spoq/epics/active/my-epic` for persona-specialized parallel execution with conflict detection.",
    },
    "task-validation": {
        "name": "task-validation",
        "description": "Validate task YAML definitions before execution with 10 planning metrics.",
        "body": "Use `/task-validation spoq/epics/active/my-epic/tasks/01-task.yml` to validate individual task definitions.",
    },
    "journal-tracker": {
        "name": "journal-tracker",
        "description": "Track AI agent work sessions in journal.md.",
        "body": "Use `/journal-tracker` to log work sessions with timestamps, confidence scores, and detailed summaries.",
    },
    "skill-maker": {
        "name": "skill-maker",
        "description": "Create new Claude Code skills following best practices.",
        "body": "Use `/skill-maker` to scaffold a new skill with SKILL.md and supporting files.",
    },
}


CLAUDE_MD_TEMPLATE = """\
# Project Guidelines

## SPOQ Integration

This project uses [SPOQ](https://spoqpaper.com) for multi-agent AI orchestration.

### Common Commands

```bash
# Plan an epic
/epic-planning "Implement feature X"

# Validate epic quality
/epic-validation @spoq/epics/active/feature-x

# Execute with agent swarm
/agent-execution @spoq/epics/active/feature-x

# Execute with agent teams
/team-execution @spoq/epics/active/feature-x

# Validate delivered code
/agent-validation

# Plan a multi-epic program
/epic-planning --map "Program name"
```

### Validation Thresholds

**Epic Validation (10 Metrics):** >= 95 average, >= 90 per metric
**Agent Validation (10 Metrics):** >= 95 average, >= 80 per metric

### Directory Structure

- `spoq/epics/active/` — Epics in progress
- `spoq/epics/complete/` — Archived completed epics
- `spoq/maps/active/` — Maps (multi-epic programs) in progress
- `spoq/maps/complete/` — Archived completed maps
- `.claude/skills/` — SPOQ skill definitions

### MCP Server

The SPOQ MCP server provides 23 tools for epic, map, and task management.
Configure in `.mcp.json`:

```json
{
  "mcpServers": {
    "spoq": {
      "command": "spoq",
      "args": ["mcp"]
    }
  }
}
```

### Workflow

1. **Plan** — `/epic-planning` decomposes goals into atomic tasks
2. **Validate** — `/epic-validation` scores against 10 quality metrics
3. **Execute** — `/agent-execution` dispatches parallel agent swarms
4. **Verify** — `/agent-validation` scores delivered code

### Git Operations

- Repository maintainer handles all git operations
- SPOQ agents never create commits
"""

JOURNAL_MD_TEMPLATE = """\
# Development Journal

This journal tracks all AI agent work sessions with timestamps, confidence scores, and detailed summaries.

- **Auto-Archiving**: When journal exceeds 1500 lines, archive older entries
- **Format**: YAML frontmatter + Markdown sections
- **Required fields**: agent, start_time, end_time, confidence, session_type, files_modified

---
"""

ROADMAP_MD_TEMPLATE = """\
# SPOQ Roadmap

## Active Epics

| Priority | Epic | Status | Tasks | Est. Hours | Dependencies |
|----------|------|--------|-------|------------|-------------|
| | | | | | |

## Completed Epics

| Epic | Completed | Tasks | Duration |
|------|-----------|-------|----------|
| | | | |
"""


def run_init(
    target: str = ".",
    full: bool = False,
    with_mcp: bool = False,
    upgrade: bool = False,
) -> None:
    """Bootstrap or upgrade SPOQ in the target directory."""
    target_path = Path(target).resolve()

    if not target_path.exists():
        target_path.mkdir(parents=True)
        print(f"Created directory: {target_path}")

    if upgrade:
        _upgrade(target_path)
    else:
        _fresh_init(target_path, full=full)

    if with_mcp:
        _setup_mcp(target_path)

    print(f"\nSPOQ initialized in: {target_path}")
    print("\nNext steps:")
    print("  1. Open the project in Claude Code")
    print("  2. Run /epic-planning to plan your first epic")
    print("  3. Run /epic-validation to verify quality")
    print("  4. Run /agent-execution to dispatch agent swarms")


def _fresh_init(target: Path, full: bool = False) -> None:
    """Create fresh SPOQ project structure."""
    # Directory structure
    dirs = [
        ".claude/skills",
        "spoq/epics/active",
        "spoq/epics/complete",
        "spoq/maps/active",
        "spoq/maps/complete",
    ]
    for d in dirs:
        (target / d).mkdir(parents=True, exist_ok=True)

    # CLAUDE.md
    claude_md = target / "CLAUDE.md"
    if not claude_md.exists():
        claude_md.write_text(CLAUDE_MD_TEMPLATE)
        print("  Created CLAUDE.md")
    else:
        print("  CLAUDE.md already exists (skipped)")

    # journal.md
    journal = target / "journal.md"
    if not journal.exists():
        journal.write_text(JOURNAL_MD_TEMPLATE)
        print("  Created journal.md")

    # ROADMAP.md
    roadmap = target / "spoq" / "ROADMAP.md"
    if not roadmap.exists():
        roadmap.write_text(ROADMAP_MD_TEMPLATE)
        print("  Created spoq/ROADMAP.md")

    # Skill stubs
    _create_skill_stubs(target)

    # Example epic (if --full)
    if full:
        _create_example_epic(target)

    print(f"  Created {len(dirs)} directories")


def _create_skill_stubs(target: Path) -> None:
    """Create minimal skill stub files for Claude Code discovery."""
    skills_dir = target / ".claude" / "skills"
    created = 0

    for skill_name, stub in SKILL_STUBS.items():
        skill_dir = skills_dir / skill_name
        skill_file = skill_dir / "SKILL.md"

        if skill_file.exists():
            continue

        skill_dir.mkdir(parents=True, exist_ok=True)
        content = f"""\
---
name: {stub['name']}
description: {stub['description']}
---

# {stub['name'].replace('-', ' ').title()}

{stub['body']}
"""
        skill_file.write_text(content)
        created += 1

    if created:
        print(f"  Created {created} skill stubs")


def _create_example_epic(target: Path) -> None:
    """Create the example config-validator epic."""
    epic_dir = target / "spoq" / "epics" / "active" / "example-config-validator"
    if epic_dir.exists():
        print("  Example epic already exists (skipped)")
        return

    tasks_dir = epic_dir / "tasks"
    tasks_dir.mkdir(parents=True, exist_ok=True)

    # EPIC.md
    (epic_dir / "EPIC.md").write_text("""\
# Epic: Example Config Validator

## Overview

A minimal example epic demonstrating SPOQ structure. Build a configuration
validator with a parser, API, and test suite across 3 execution waves.

## Architecture

```
Parser -> API -> Tests
```

## Success Criteria

- [ ] Parser handles YAML input
- [ ] API returns structured JSON
- [ ] Tests cover the full pipeline
- [ ] All tasks have three-point estimates
- [ ] Dependency graph is acyclic

## Task Dependencies

```
Wave 0: 01-parser, 02-models (parallel)
Wave 1: 03-api (depends on 01, 02)
Wave 2: 04-tests (depends on 03)
```

## Dispatch Strategy

**Wave 0:** Tasks 01, 02 (parallel foundation)
**Wave 1:** Task 03 (API, depends on Wave 0)
**Wave 2:** Task 04 (tests, depends on Wave 1)

## Estimated Effort

| Wave | Tasks | Duration |
|------|-------|----------|
| 0 | 2 | ~1.5h |
| 1 | 1 | ~2h |
| 2 | 1 | ~1.5h |
| **Total** | **4** | **~5h** |
""")

    # Task YAMLs
    tasks = [
        ("01-parser.yml", "01-parser", "Config Parser", 0, "critical", "[]"),
        ("02-models.yml", "02-models", "Data Models", 0, "high", "[]"),
        ("03-api.yml", "03-api", "REST API", 1, "high", "[01-parser, 02-models]"),
        ("04-tests.yml", "04-tests", "Integration Tests", 2, "medium", "[03-api]"),
    ]

    for filename, tid, title, phase, priority, deps in tasks:
        (tasks_dir / filename).write_text(f"""\
id: {tid}
title: {title}
epic: example-config-validator
status: pending
priority: {priority}
phase: {phase}

estimate:
  optimistic: 30m
  realistic: 1h
  pessimistic: 2h

dependencies: {deps}

skills_required:
  - python

files_to_touch:
  - src/{tid.split('-')[1]}.py

acceptance_criteria:
  - "[ ] Implementation complete"
  - "[ ] Tests pass"

description: |
  ## Objective
  Implement the {title.lower()} component.

  ## Steps
  1. Create the module
  2. Add core logic
  3. Write tests

  ## Verification
  Run pytest to verify.
""")

    print("  Created example epic: example-config-validator (4 tasks)")


def _upgrade(target: Path) -> None:
    """Upgrade an existing SPOQ installation."""
    upgraded = []

    # Ensure directory structure
    for d in ["spoq/epics/active", "spoq/epics/complete",
              "spoq/maps/active", "spoq/maps/complete"]:
        path = target / d
        if not path.exists():
            path.mkdir(parents=True)
            upgraded.append(f"Created {d}/")

    # Migrate legacy structures
    legacy_automation = target / "automation" / "tasks"
    if legacy_automation.exists():
        dest = target / "spoq" / "epics" / "active"
        for item in legacy_automation.iterdir():
            if item.is_dir():
                target_dest = dest / item.name
                if not target_dest.exists():
                    shutil.move(str(item), str(target_dest))
                    upgraded.append(f"Migrated automation/tasks/{item.name} -> spoq/epics/active/")
        print("  Migrated legacy automation/tasks/ structure")

    legacy_factory = target / "factory" / "epics"
    if legacy_factory.exists():
        dest = target / "spoq" / "epics"
        for item in legacy_factory.iterdir():
            if item.is_dir():
                target_dest = dest / "active" / item.name
                if not target_dest.exists():
                    shutil.move(str(item), str(target_dest))
                    upgraded.append(f"Migrated factory/epics/{item.name} -> spoq/epics/active/")
        print("  Migrated legacy factory/ structure")

    # Update skill stubs
    _create_skill_stubs(target)

    # Ensure ROADMAP.md
    roadmap = target / "spoq" / "ROADMAP.md"
    if not roadmap.exists():
        roadmap.write_text(ROADMAP_MD_TEMPLATE)
        upgraded.append("Created spoq/ROADMAP.md")

    if upgraded:
        print(f"  Upgraded {len(upgraded)} items")
    else:
        print("  Already up to date")


def _setup_mcp(target: Path) -> None:
    """Configure .mcp.json for the SPOQ MCP server."""
    mcp_file = target / ".mcp.json"

    mcp_config = {
        "mcpServers": {
            "spoq": {
                "command": "spoq",
                "args": ["mcp"],
            }
        }
    }

    if mcp_file.exists():
        existing = json.loads(mcp_file.read_text())
        servers = existing.get("mcpServers", {})
        if "spoq" not in servers:
            servers["spoq"] = mcp_config["mcpServers"]["spoq"]
            existing["mcpServers"] = servers
            mcp_file.write_text(json.dumps(existing, indent=2) + "\n")
            print("  Added spoq entry to existing .mcp.json")
        else:
            print("  .mcp.json already has spoq entry (skipped)")
    else:
        mcp_file.write_text(json.dumps(mcp_config, indent=2) + "\n")
        print("  Created .mcp.json")
