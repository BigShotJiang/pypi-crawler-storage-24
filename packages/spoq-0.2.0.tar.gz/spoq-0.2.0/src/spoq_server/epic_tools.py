"""Epic management MCP tools for SPOQ."""

import json
from pathlib import Path

from spoq_server.server import mcp, project_root
from spoq_server import epic_utils


def _resolve_epic_path(epic_path: str) -> Path:
    """Resolve epic path relative to project root."""
    p = Path(epic_path)
    if not p.is_absolute():
        p = project_root() / p
    return p


@mcp.tool()
def spoq_parse_epic(epic_path: str) -> str:
    """Parse an epic directory and return its metadata, tasks, and stats as JSON.

    Args:
        epic_path: Path to epic directory (absolute or relative to project root).
                   Example: "spoq/epics/active/spoq-mcp-server"
    """
    try:
        eu = epic_utils
        resolved = _resolve_epic_path(epic_path)
        result = eu.parse_epic(resolved)
        # Remove _source_file from tasks for cleaner output
        for task in result.get("tasks", []):
            task.pop("_source_file", None)
        return json.dumps(result, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def spoq_validate_epic(epic_path: str, strict: bool = False) -> str:
    """Validate an epic's structure, dependencies, and phases.

    Args:
        epic_path: Path to epic directory.
        strict: If true, warnings become errors.

    Returns JSON with errors[], warnings[], and summary.
    """
    try:
        eu = epic_utils
        resolved = _resolve_epic_path(epic_path)

        if not resolved.exists():
            return json.dumps({"error": f"Epic directory not found: {resolved}"})

        errors = []
        warnings = []

        # Validate EPIC.md structure
        md_errors = eu.validate_epic_md_structure(resolved)
        # Treat "recommend" messages as warnings unless strict
        for err in md_errors:
            if "recommend" in err.lower() and not strict:
                warnings.append(err)
            else:
                errors.append(err)

        # Load and validate tasks
        tasks = eu.load_tasks(resolved)
        valid_tasks = [t for t in tasks if "error" not in t]
        error_tasks = [t for t in tasks if "error" in t]

        for t in error_tasks:
            errors.append(t["error"])

        for task in valid_tasks:
            source = Path(task.get("_source_file", "unknown"))
            task_errors = eu.validate_task_yaml_structure(task, source)
            errors.extend(task_errors)

        # Validate dependencies
        errors.extend(eu.validate_dependencies(valid_tasks))

        # Detect cycles
        cycle_errors = eu.detect_cycles(valid_tasks)
        errors.extend(cycle_errors)

        # Validate phases
        phase_errors = eu.validate_phases(valid_tasks)
        if strict:
            errors.extend(phase_errors)
        else:
            warnings.extend(phase_errors)

        summary = {
            "valid": len(errors) == 0,
            "total_tasks": len(tasks),
            "valid_tasks": len(valid_tasks),
            "error_count": len(errors),
            "warning_count": len(warnings),
        }

        return json.dumps({"errors": errors, "warnings": warnings, "summary": summary})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def spoq_compute_waves(epic_path: str, critical_path: bool = False) -> str:
    """Compute execution waves from task dependency graph.

    Args:
        epic_path: Path to epic directory.
        critical_path: Include critical path analysis in output.

    Returns JSON with waves[], each containing task details.
    """
    try:
        eu = epic_utils
        resolved = _resolve_epic_path(epic_path)
        result = eu.parse_epic(resolved)

        if "error" in result:
            return json.dumps(result)

        tasks = result["tasks"]
        if not tasks:
            return json.dumps({"error": "No tasks found in epic"})

        waves_map = eu.compute_waves(tasks)
        wave_groups = eu.group_waves(waves_map)
        task_map = {t["id"]: t for t in tasks}

        waves = []
        for wave_num in sorted(wave_groups.keys()):
            task_ids = wave_groups[wave_num]
            wave_tasks = []
            for tid in sorted(task_ids):
                task = task_map.get(tid, {})
                wave_tasks.append({
                    "id": tid,
                    "title": task.get("title", tid),
                    "status": task.get("status", "pending"),
                    "priority": task.get("priority", "medium"),
                    "dependencies": task.get("dependencies", []),
                })
            waves.append({
                "wave": wave_num,
                "task_count": len(wave_tasks),
                "tasks": wave_tasks,
            })

        output = {
            "epic_name": result.get("epic_name", "unknown"),
            "total_waves": len(waves),
            "total_tasks": len(tasks),
            "waves": waves,
        }

        if critical_path:
            cp_tasks, cp_duration = eu.compute_critical_path(tasks, waves_map)
            output["critical_path"] = {
                "tasks": cp_tasks,
                "duration_hours": cp_duration,
                "length": len(cp_tasks),
            }

        return json.dumps(output, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def spoq_get_wave_tasks(epic_path: str, wave: int) -> str:
    """Get tasks for a specific wave number.

    Args:
        epic_path: Path to epic directory.
        wave: Wave number (0-indexed).

    Returns JSON with the wave's tasks only.
    """
    try:
        eu = epic_utils
        resolved = _resolve_epic_path(epic_path)
        result = eu.parse_epic(resolved)

        if "error" in result:
            return json.dumps(result)

        tasks = result["tasks"]
        waves_map = eu.compute_waves(tasks)
        wave_groups = eu.group_waves(waves_map)

        if wave not in wave_groups:
            available = sorted(wave_groups.keys())
            return json.dumps({
                "error": f"Wave {wave} not found. Available waves: {available}"
            })

        task_map = {t["id"]: t for t in tasks}
        wave_tasks = []
        for tid in sorted(wave_groups[wave]):
            task = task_map.get(tid, {})
            wave_tasks.append({
                "id": tid,
                "title": task.get("title", tid),
                "status": task.get("status", "pending"),
                "dependencies": task.get("dependencies", []),
                "files_to_touch": task.get("files_to_touch", []),
                "skills_required": task.get("skills_required", []),
            })

        return json.dumps({
            "wave": wave,
            "task_count": len(wave_tasks),
            "tasks": wave_tasks,
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def spoq_generate_execution_plan(epic_path: str, include_critical_path: bool = True) -> str:
    """Generate a full execution plan with actionable task filtering.

    Computes waves from the dependency graph and marks each task as actionable
    (pending, in_progress, or rework) or non-actionable (completed, failed, qa).
    Essential for --resume workflows where completed tasks should be skipped.

    Used by both /agent-execution and /team-execution as the primary planning step.

    Args:
        epic_path: Path to epic directory.
        include_critical_path: Include critical path analysis (default True).

    Returns JSON with waves[], actionable counts, and per-task actionable flags.
    """
    try:
        eu = epic_utils
        resolved = _resolve_epic_path(epic_path)
        result = eu.parse_epic(resolved)

        if "error" in result:
            return json.dumps(result)

        tasks = result["tasks"]
        if not tasks:
            return json.dumps({"error": "No tasks found in epic"})

        actionable_statuses = {"pending", "rework", "in_progress"}

        waves_map = eu.compute_waves(tasks)
        wave_groups = eu.group_waves(waves_map)
        task_map = {t["id"]: t for t in tasks}

        waves = []
        total_actionable = 0
        for wave_num in sorted(wave_groups.keys()):
            task_ids = wave_groups[wave_num]
            wave_tasks = []
            wave_actionable = 0
            for tid in sorted(task_ids):
                task = task_map.get(tid, {})
                is_actionable = task.get("status", "pending") in actionable_statuses
                if is_actionable:
                    wave_actionable += 1
                wave_tasks.append({
                    "id": tid,
                    "title": task.get("title", tid),
                    "status": task.get("status", "pending"),
                    "priority": task.get("priority", "medium"),
                    "dependencies": task.get("dependencies", []),
                    "files_to_touch": task.get("files_to_touch", []),
                    "skills_required": task.get("skills_required", []),
                    "actionable": is_actionable,
                })
            total_actionable += wave_actionable
            waves.append({
                "wave": wave_num,
                "total_tasks": len(wave_tasks),
                "actionable_tasks": wave_actionable,
                "tasks": wave_tasks,
            })

        output = {
            "epic_name": result.get("epic_name", "unknown"),
            "total_waves": len(waves),
            "total_tasks": len(tasks),
            "actionable_tasks": total_actionable,
            "waves": waves,
        }

        if include_critical_path:
            cp_tasks, cp_duration = eu.compute_critical_path(tasks, waves_map)
            output["critical_path"] = {
                "tasks": [
                    {
                        "id": tid,
                        "title": task_map.get(tid, {}).get("title", tid),
                        "wave": waves_map.get(tid, -1),
                    }
                    for tid in cp_tasks
                ],
                "duration_hours": cp_duration,
                "length": len(cp_tasks),
            }

        return json.dumps(output, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def spoq_analyze_dag(epic_path: str, agents: int = 4) -> str:
    """Analyze the dependency DAG for critical path and parallelism metrics.

    Args:
        epic_path: Path to epic directory.
        agents: Number of parallel agents for effort estimation.

    Returns JSON with critical_path, parallelism, and effort analysis.
    """
    try:
        eu = epic_utils
        resolved = _resolve_epic_path(epic_path)

        tasks = eu.load_tasks(resolved)
        valid_tasks = [t for t in tasks if "error" not in t]

        if not valid_tasks:
            return json.dumps({"error": "No valid tasks found"})

        waves = eu.compute_waves(valid_tasks)
        wave_groups = eu.group_waves(waves)
        cp_tasks, cp_duration = eu.compute_critical_path(valid_tasks, waves)
        parallelism = eu.compute_parallelism_metrics(valid_tasks, waves)

        task_map = {t["id"]: t for t in valid_tasks}
        total_effort = sum(eu.get_task_duration(t) for t in valid_tasks)
        total_pert = sum(eu.calculate_pert_estimate(t) for t in valid_tasks)
        parallel_estimate = (
            max(cp_duration, total_effort / agents)
            if agents > 0
            else total_effort
        )
        speedup = total_effort / cp_duration if cp_duration > 0 else 1.0

        return json.dumps({
            "epic_name": resolved.name,
            "total_tasks": len(valid_tasks),
            "critical_path": {
                "tasks": cp_tasks,
                "duration_hours": cp_duration,
                "task_details": [
                    {
                        "id": tid,
                        "title": task_map.get(tid, {}).get("title", tid),
                        "duration": eu.get_task_duration(task_map.get(tid, {})),
                    }
                    for tid in cp_tasks
                ],
            },
            "parallelism": {
                "wave_count": parallelism["phase_count"],
                "max_parallelism": parallelism["max_parallelism"],
                "wave0_tasks": parallelism["phase1_tasks"],
                "wave0_ratio": parallelism["phase1_ratio"],
                "waves": {str(k): v for k, v in parallelism["phases"].items()},
            },
            "effort": {
                "total_hours": total_effort,
                "total_pert_hours": total_pert,
                "critical_path_hours": cp_duration,
                "parallel_estimate_hours": parallel_estimate,
                "speedup_factor": speedup,
                "num_agents": agents,
            },
        }, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def spoq_estimate_effort(epic_path: str) -> str:
    """Calculate PERT estimates per wave and total for an epic.

    Args:
        epic_path: Path to epic directory.

    Returns JSON with per-wave and total effort estimates.
    """
    try:
        eu = epic_utils
        resolved = _resolve_epic_path(epic_path)

        tasks = eu.load_tasks(resolved)
        valid_tasks = [t for t in tasks if "error" not in t]

        if not valid_tasks:
            return json.dumps({"error": "No valid tasks found"})

        waves = eu.compute_waves(valid_tasks)
        wave_groups = eu.group_waves(waves)
        task_map = {t["id"]: t for t in valid_tasks}

        wave_estimates = {}
        total_pert = 0

        for wave_num in sorted(wave_groups.keys()):
            task_ids = wave_groups[wave_num]
            tasks_detail = []
            wave_pert = 0

            for tid in task_ids:
                task = task_map.get(tid, {})
                estimate = task.get("estimate", {})
                opt = eu.parse_duration(estimate.get("optimistic", "30m"))
                real = eu.parse_duration(estimate.get("realistic", "1h"))
                pess = eu.parse_duration(estimate.get("pessimistic", "2h"))
                pert = eu.calculate_pert_estimate(task)
                wave_pert += pert

                tasks_detail.append({
                    "id": tid,
                    "title": task.get("title", tid),
                    "optimistic": opt,
                    "realistic": real,
                    "pessimistic": pess,
                    "pert": pert,
                })

            max_pert = (
                max(t["pert"] for t in tasks_detail) if tasks_detail else 0
            )
            wave_estimates[wave_num] = {
                "task_count": len(task_ids),
                "total_pert": wave_pert,
                "parallel_duration": max_pert,
                "tasks": tasks_detail,
            }
            total_pert += wave_pert

        parallel_duration = sum(
            w["parallel_duration"] for w in wave_estimates.values()
        )

        return json.dumps({
            "epic_name": resolved.name,
            "total_tasks": len(valid_tasks),
            "wave_count": len(wave_groups),
            "estimates": {
                "total_pert_hours": total_pert,
                "sequential_hours": total_pert,
                "parallel_hours": parallel_duration,
                "speedup_factor": (
                    total_pert / parallel_duration
                    if parallel_duration > 0
                    else 1
                ),
            },
            "waves": {str(k): v for k, v in wave_estimates.items()},
        }, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
