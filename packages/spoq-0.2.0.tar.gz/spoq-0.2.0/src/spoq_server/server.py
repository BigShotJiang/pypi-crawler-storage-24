"""
SPOQ MCP Server entry point.

Registers all SPOQ tools and runs the FastMCP server via stdio transport.
"""

import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from spoq_server import __version__


def project_root() -> Path:
    """
    Find the project root by walking up from the current file to find .git directory.

    Returns the path to the repository root (where .git lives).
    """
    current = Path(__file__).resolve()
    for parent in current.parents:
        if (parent / ".git").exists():
            return parent
    # Fallback: assume 4 levels up from server.py
    # code/mcp/spoq-server/src/spoq_server/server.py -> project root
    return Path(__file__).resolve().parents[4]


# Create FastMCP server instance
mcp = FastMCP("spoq")


@mcp.tool()
def spoq_ping() -> str:
    """Health check - returns server version and project root path."""
    import json
    return json.dumps({
        "version": __version__,
        "project_root": str(project_root()),
        "package": "spoq",
        "status": "ok"
    })


# Import tool modules to register their tools with the mcp instance
import spoq_server.epic_tools  # noqa: F401
import spoq_server.task_tools  # noqa: F401
import spoq_server.team_tools  # noqa: F401
import spoq_server.util_tools  # noqa: F401
import spoq_server.map_tools  # noqa: F401


def main():
    """Run the SPOQ MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
