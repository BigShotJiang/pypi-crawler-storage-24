"""SPOQ — Specialist Orchestrated Queuing for multi-agent AI development.

Provides:
  - MCP server with 23 tools for epic, map, and task management
  - CLI for project initialization, template generation, and server operation
  - Bundled epic_utils and map_utils for standalone use
"""

__version__ = "0.2.0"
