# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class SaveCredentialRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'ak': 'str',
        'sk': 'str'
    }

    attribute_map = {
        'ak': 'ak',
        'sk': 'sk'
    }

    def __init__(self, ak=None, sk=None):
        r"""SaveCredentialRequestBody

        The model defined in huaweicloud sdk

        :param ak: AK
        :type ak: str
        :param sk: SK
        :type sk: str
        """
        
        

        self._ak = None
        self._sk = None
        self.discriminator = None

        self.ak = ak
        self.sk = sk

    @property
    def ak(self):
        r"""Gets the ak of this SaveCredentialRequestBody.

        AK

        :return: The ak of this SaveCredentialRequestBody.
        :rtype: str
        """
        return self._ak

    @ak.setter
    def ak(self, ak):
        r"""Sets the ak of this SaveCredentialRequestBody.

        AK

        :param ak: The ak of this SaveCredentialRequestBody.
        :type ak: str
        """
        self._ak = ak

    @property
    def sk(self):
        r"""Gets the sk of this SaveCredentialRequestBody.

        SK

        :return: The sk of this SaveCredentialRequestBody.
        :rtype: str
        """
        return self._sk

    @sk.setter
    def sk(self, sk):
        r"""Sets the sk of this SaveCredentialRequestBody.

        SK

        :param sk: The sk of this SaveCredentialRequestBody.
        :type sk: str
        """
        self._sk = sk

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SaveCredentialRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
