# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowFullDeadLockListResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total': 'int',
        'full_deadlock_list': 'list[FullDeadLockListRespFullDeadlockList]'
    }

    attribute_map = {
        'total': 'total',
        'full_deadlock_list': 'full_deadlock_list'
    }

    def __init__(self, total=None, full_deadlock_list=None):
        r"""ShowFullDeadLockListResponse

        The model defined in huaweicloud sdk

        :param total: 死锁数量
        :type total: int
        :param full_deadlock_list: 死锁具体信息
        :type full_deadlock_list: list[:class:`huaweicloudsdkdas.v3.FullDeadLockListRespFullDeadlockList`]
        """
        
        super().__init__()

        self._total = None
        self._full_deadlock_list = None
        self.discriminator = None

        if total is not None:
            self.total = total
        if full_deadlock_list is not None:
            self.full_deadlock_list = full_deadlock_list

    @property
    def total(self):
        r"""Gets the total of this ShowFullDeadLockListResponse.

        死锁数量

        :return: The total of this ShowFullDeadLockListResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ShowFullDeadLockListResponse.

        死锁数量

        :param total: The total of this ShowFullDeadLockListResponse.
        :type total: int
        """
        self._total = total

    @property
    def full_deadlock_list(self):
        r"""Gets the full_deadlock_list of this ShowFullDeadLockListResponse.

        死锁具体信息

        :return: The full_deadlock_list of this ShowFullDeadLockListResponse.
        :rtype: list[:class:`huaweicloudsdkdas.v3.FullDeadLockListRespFullDeadlockList`]
        """
        return self._full_deadlock_list

    @full_deadlock_list.setter
    def full_deadlock_list(self, full_deadlock_list):
        r"""Sets the full_deadlock_list of this ShowFullDeadLockListResponse.

        死锁具体信息

        :param full_deadlock_list: The full_deadlock_list of this ShowFullDeadLockListResponse.
        :type full_deadlock_list: list[:class:`huaweicloudsdkdas.v3.FullDeadLockListRespFullDeadlockList`]
        """
        self._full_deadlock_list = full_deadlock_list

    def to_dict(self):
        import warnings
        warnings.warn("ShowFullDeadLockListResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowFullDeadLockListResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
