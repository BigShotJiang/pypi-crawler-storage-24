# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowHealthReportSettingsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'update_at': 'int',
        'do_ai_anomaly_detection': 'bool'
    }

    attribute_map = {
        'update_at': 'update_at',
        'do_ai_anomaly_detection': 'do_ai_anomaly_detection'
    }

    def __init__(self, update_at=None, do_ai_anomaly_detection=None):
        r"""ShowHealthReportSettingsResponse

        The model defined in huaweicloud sdk

        :param update_at: 更新时间
        :type update_at: int
        :param do_ai_anomaly_detection: 是否进行AI异常检测
        :type do_ai_anomaly_detection: bool
        """
        
        super().__init__()

        self._update_at = None
        self._do_ai_anomaly_detection = None
        self.discriminator = None

        if update_at is not None:
            self.update_at = update_at
        if do_ai_anomaly_detection is not None:
            self.do_ai_anomaly_detection = do_ai_anomaly_detection

    @property
    def update_at(self):
        r"""Gets the update_at of this ShowHealthReportSettingsResponse.

        更新时间

        :return: The update_at of this ShowHealthReportSettingsResponse.
        :rtype: int
        """
        return self._update_at

    @update_at.setter
    def update_at(self, update_at):
        r"""Sets the update_at of this ShowHealthReportSettingsResponse.

        更新时间

        :param update_at: The update_at of this ShowHealthReportSettingsResponse.
        :type update_at: int
        """
        self._update_at = update_at

    @property
    def do_ai_anomaly_detection(self):
        r"""Gets the do_ai_anomaly_detection of this ShowHealthReportSettingsResponse.

        是否进行AI异常检测

        :return: The do_ai_anomaly_detection of this ShowHealthReportSettingsResponse.
        :rtype: bool
        """
        return self._do_ai_anomaly_detection

    @do_ai_anomaly_detection.setter
    def do_ai_anomaly_detection(self, do_ai_anomaly_detection):
        r"""Sets the do_ai_anomaly_detection of this ShowHealthReportSettingsResponse.

        是否进行AI异常检测

        :param do_ai_anomaly_detection: The do_ai_anomaly_detection of this ShowHealthReportSettingsResponse.
        :type do_ai_anomaly_detection: bool
        """
        self._do_ai_anomaly_detection = do_ai_anomaly_detection

    def to_dict(self):
        import warnings
        warnings.warn("ShowHealthReportSettingsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowHealthReportSettingsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
