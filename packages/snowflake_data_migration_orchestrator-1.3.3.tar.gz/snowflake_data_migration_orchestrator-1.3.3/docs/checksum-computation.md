# Checksum Computation

This document describes how partition checksums are computed for each source platform.

See [incremental-sync.md](./incremental-sync.md) for the overall CHECKSUM strategy flow.

## Overview

The checksum computation generates a deterministic string that represents the contents of a partition. If the checksum changes between syncs, the partition data has changed and needs to be re-extracted.

**Key requirements:**
- Deterministic: Same data always produces the same checksum
- Order-independent: Row order doesn't affect the result
- Overflow-safe: Works with tables of any size

## SQL Server

### Algorithm

SQL Server checksums use `HASHBYTES('md5', ...)` with **bucket slicing** to aggregate row hashes without numeric overflow.

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. For each row: HASHBYTES('md5', col1 + '|' + col2 + '|' ...) │
│    → Produces 16-byte (128-bit) binary hash per row             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. Split each 16-byte hash into 4 buckets of 4 bytes each       │
│    [bytes 1-4] [bytes 5-8] [bytes 9-12] [bytes 13-16]          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. SUM each bucket independently across all rows                │
│    SUM(bucket1), SUM(bucket2), SUM(bucket3), SUM(bucket4)      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. Concatenate bucket sums with ':' separator                   │
│    Result: "123456789:987654321:111111111:222222222"            │
└─────────────────────────────────────────────────────────────────┘
```

### Why Bucket Slicing?

Directly summing 128-bit hashes would overflow any SQL numeric type. By splitting into 4-byte chunks:
- Each chunk fits in `BIGINT` (8 bytes)
- SUMs are stored as `NUMERIC(38,0)` (handles ~10^38, safe for billions of rows)
- Final result preserves all hash entropy

### Why SUM Instead of XOR?

XOR-based aggregation (like `CHECKSUM_AGG`) has a flaw: **identical rows cancel out**.

```
XOR: row_hash ⊕ row_hash = 0  →  Duplicate rows become invisible!
SUM: row_hash + row_hash = 2×row_hash  →  Duplicates are counted
```

SUM correctly detects changes even when tables have duplicate rows.

### Generated Query Structure

```sql
SELECT
    CAST(ISNULL(SUM(CAST(CAST(SUBSTRING(hashed_columns, 1, 4) AS BIGINT) AS NUMERIC(38,0))), 0) AS VARCHAR(40)) + ':' +
    CAST(ISNULL(SUM(CAST(CAST(SUBSTRING(hashed_columns, 5, 4) AS BIGINT) AS NUMERIC(38,0))), 0) AS VARCHAR(40)) + ':' +
    CAST(ISNULL(SUM(CAST(CAST(SUBSTRING(hashed_columns, 9, 4) AS BIGINT) AS NUMERIC(38,0))), 0) AS VARCHAR(40)) + ':' +
    CAST(ISNULL(SUM(CAST(CAST(SUBSTRING(hashed_columns, 13, 4) AS BIGINT) AS NUMERIC(38,0))), 0) AS VARCHAR(40))
    AS checksum
FROM (
    SELECT HASHBYTES('md5', <column_expressions>) AS hashed_columns
    FROM [database].[schema].[table]
    WHERE <partition_boundaries>
) t
```

### Column Type Handling

#### Skipped Columns

These types cannot be passed to `HASHBYTES()` and are excluded:

| Type | Reason |
|------|--------|
| `image` | Legacy LOB type, not hashable |
| `ntext` | Legacy LOB type, not hashable |
| `text` | Legacy LOB type, not hashable |

If **all** columns are skipped, the checksum falls back to `COUNT_BIG(*)`.

#### Type Conversions

All other columns are converted to character representation before hashing:

| Data Type | Conversion |
|-----------|------------|
| `int`, `bigint`, `smallint`, `tinyint` | `LTRIM(STR(col, 40, 0))` |
| `decimal`, `numeric`, `money` | `LTRIM(STR(col, precision+2, scale))` |
| `float`, `real` | `CONVERT(nvarchar(50), col, 2)` |
| `datetime`, `datetime2`, `smalldatetime` | `CONVERT(nvarchar(29), col, 121)` |
| `date` | `CONVERT(nvarchar(10), col, 23)` |
| `time` | `CONVERT(nvarchar(16), col, 121)` |
| `datetimeoffset` | `CONVERT(nvarchar(35), col, 127)` |
| `binary`, `varbinary` | `CONVERT(nvarchar(max), col, 2)` |
| `timestamp`/`rowversion` | `CONVERT(nvarchar(max), CAST(col AS varbinary(8)), 2)` |
| `uniqueidentifier` | `CONVERT(nvarchar(36), col)` |
| `xml` | `CAST(CONVERT(XML, col) AS nvarchar(max))` |
| `hierarchyid` | `col.ToString()` |
| `geometry`, `geography` | `col.STAsText()` |
| `bit` | `CAST(col AS nvarchar(1))` |
| `char`, `varchar`, `nchar`, `nvarchar` | `CAST(col AS nvarchar(max))` |

### NULL Handling

Nullable columns are wrapped with `ISNULL()` to ensure consistent hashing:

```sql
ISNULL(column_expression, '-99999999')
```

This ensures NULL values produce a deterministic hash rather than making the entire row hash NULL.

### Version Requirements

- **SQL Server 2005+** required for `HASHBYTES()`
- MD5 algorithm is used (available in all supported versions)

### Limitations

- If concatenated column values exceed **8000 bytes** on SQL Server 2005-2014, `HASHBYTES()` returns NULL
- SQL Server 2016+ supports up to 2GB input

## Redshift

### Algorithm

Redshift checksums use `crc32()` as an intermediate per-column hash, `farmFingerprint64()` as the per-row hash, and `AVG()` for overflow-safe aggregation.

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. For each column: crc32(charamerized_column)                  │
│    → Produces a numeric hash per column per row                 │
│    → Nullable columns: COALESCE(crc32(...), '-99999999')        │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. Concatenate all CRC32 results with ||                        │
│    crc32(col1) || crc32(col2) || ...                            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. farmFingerprint64(concatenation) → BIGINT per row            │
│    Cast to DECIMAL(38,0) for safe aggregation                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. AVG(hashed_columns) across all rows                          │
│    Result: "1234567890123456789"                                │
└─────────────────────────────────────────────────────────────────┘
```

### Why CRC32 Intermediate Hashing?

Each column is hashed individually with `crc32()` before concatenation. This reduces every column value to a fixed-size numeric, preventing the concatenated string from exceeding Redshift's `VARCHAR(65535)` limit on wide tables with large data values.

### Why AVG Instead of SUM?

`farmFingerprint64()` returns a `BIGINT` (8 bytes, signed). In Redshift, `SUM(BIGINT)` returns `BIGINT`, which can overflow with as few as two rows at extreme values. `AVG` is inherently bounded by the input range and is overflow-safe regardless of table size.

**Future improvement**: consider switching to SUM with bucket slicing (splitting the 8-byte BIGINT into 2x4-byte buckets summed as `DECIMAL(38,0)`), which would mirror the SQL Server pattern and provide finer-grained change detection while remaining overflow-safe.

### Generated Query Structure

```sql
SELECT
    CAST(COALESCE(AVG(hashed_columns), 0) AS VARCHAR(40)) AS checksum
FROM (
    SELECT CAST(farmFingerprint64(
        crc32(col1_expr) || crc32(col2_expr) || ...
    ) AS DECIMAL(38,0)) AS hashed_columns
    FROM "database"."schema"."table"
    WHERE <partition_boundaries>
) t
```

### Column Type Handling

No Redshift types are skipped. All columns are charamerized (converted to VARCHAR) before being passed to `crc32()`. If the column list is empty, the checksum falls back to `COUNT(*)`.

#### Type Conversions

| Data Type | Conversion |
|-----------|------------|
| `super` | `JSON_SERIALIZE(col)` |
| `boolean`, `bool` | `CASE col WHEN true THEN 'TRUE' WHEN false THEN 'FALSE' ELSE NULL END` |
| `varbyte`, `varbinary`, `binary varying` | `RIGHT(CAST(col AS VARCHAR), -2)` (strips `0x` prefix) |
| `timetz`, `time with time zone` | `CAST(col AS VARCHAR)` |
| `char`, `varchar`, `text`, `character varying`, etc. | Used as-is (no conversion) |
| All other types (numeric, date, timestamp, etc.) | `CAST(col AS VARCHAR)` |

### NULL Handling

Nullable columns are wrapped with `COALESCE()` after the `crc32()` call:

```sql
COALESCE(crc32(column_expression), '-99999999')
```

If a column is NULL, `crc32(NULL)` returns NULL, which is then replaced with the deterministic token `'-99999999'` to ensure consistent hashing.

## Other Platforms

*Additional platforms will be documented as they are implemented.*
