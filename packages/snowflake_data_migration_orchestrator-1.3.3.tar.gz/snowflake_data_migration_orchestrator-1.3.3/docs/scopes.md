# Scopes (for Tasks)

## Summary
Each task in the task queue has a "scope", which describes (through a meta-language) what is the purpose of the task and what resources/objects does it apply to.

## Specific Scopes
- Table[\<table-name\>]::Preprocessing
    - Indicates that the task is related to preprocessing a specific table (obtaining metadata and preparing partitions).
    - Example: `Table[MY_DB.MY_SCHEMA.MY_TABLE]::Preprocessing`
- Table[\<table-name\>]::Partition[\<partition-id\>]::Extraction
    - Indicates that the task is related to the extraction of data from the source system, for a specific partition of a specific table.
    - Example: `Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[2]::Extraction`
- Table[\<table-name\>]::Partition[\<partition-id\>]::Loading
    - Indicates that the task is related to the loading of data into the target system, for a specific partition of a specific table.
    - Example: `Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[2]::Loading`

More scopes can be added in the future.

## What makes up a scope?
A scope is composed of different fragments with a hierarchical ordering. For example, the scope `Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[2]::Loading` has three fragments:
- `Table[MY_DB.MY_SCHEMA.MY_TABLE]`: This part refers to the fact that the task has the purpose of migrating the data for a specific table, with name `MY_DB.MY_SCHEMA.MY_TABLE`.
- `Partition[2]`: This part is more specific, it indicates that the task is related to a specific partition belonging to the table that was identified in the previous fragment.
- `Loading`: This part is even more specific, indicating that the task is related to loading the partition that was identified in the previous fragment.

These fragments must be deterministically created, with normalization of the "dynamic" parts of the scope, such as the fully qualified names of the tables (using the source name) and the partition ids.

## What is the purpose?
By providing hierarchical scopes, it is easier and more performant to execute queries that rely on prefixes on the SCOPE column (assuming there is an index on said column). For example, it is possible to find all tasks related to a specific partition of a specific table by using a `LIKE` expression similar to `LIKE 'Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[4]::%`. It can be similarly done for all tasks related to a specific table.

# TODO: Indexes for the SCOPE column (prefix)
