# Task Model

## Overview

The Data Migration system uses a task-based architecture where the **Data Migration Orchestrator** produces tasks that are executed by different **executors**. Tasks are stored in a shared queue (Snowflake tables) and consumed by the appropriate executor based on their type.

## Executors

There are three types of executors that can process tasks:

| Executor | Description |
|----------|-------------|
| `orchestrator` | Handles coordination, processing, and decision-making tasks (e.g., partition strategy, checksum validation) |
| `data-exchange-agent` | Executes tasks that interact with source systems (e.g., data extraction, checksum collection) |
| `warehouse` | Runs Snowflake queries directly (e.g., COPY INTO, table creation) |

## Task Structure

Each task contains:

| Field | Description |
|-------|-------------|
| `id` | Unique identifier (assigned when queued) |
| `workflow_id` | The workflow this task belongs to |
| `executor_type` | Which executor should process this task |
| `task_name` | Human-readable name |
| `payload` | Task-specific data (varies by task kind) |
| `status` | Current state in the lifecycle |
| `priority` | Execution priority (lower = higher priority) |
| `scope` | Hierarchical description of task purpose (see [scopes.md](scopes.md)) |
| `successor_task_id` | Task to unblock upon completion |
| `is_blocked` | Whether task is waiting on predecessors |

## Task Lifecycle

```
PENDING → EXECUTING → COMPLETED
                   ↘ FAILED
                   ↘ ABANDONED

BLOCKED → (unblocked when predecessor completes) → PENDING
```

**Status definitions:**
- `pending` – Ready to be picked up by an executor
- `blocked` – Waiting for predecessor task(s) to complete
- `executing` – Currently being processed by an executor
- `completed` – Successfully finished
- `failed` – Execution failed
- `abandoned` – Lease expired without completion

## Task Payload Kinds

### Orchestrator Tasks
| Kind | Purpose |
|------|---------|
| `determine_partition_strategy` | Analyze table metadata to decide partitioning approach |
| `create_partition_tasks` | Generate extraction tasks for each partition |
| `process_staged_data` | Process data after staging to prepare for loading |
| `complete_partition_migration` | Update partition metadata after successful COPY INTO |
| `validate_checksums` | Validate data integrity via checksums |
| `detect_changed_partitions` | Identify partitions that need re-extraction |

### Data Exchange Agent Tasks
| Kind | Purpose |
|------|---------|
| `data_movement` | Extract data from source and upload to target location |
| `get_source_checksums` | Collect checksums from source system |
| `measure_partition_source` | Generate validation measures from source |

### Warehouse Tasks
| Kind | Purpose |
|------|---------|
| `snowflake_query` | Execute arbitrary Snowflake SQL |
| `copy_into` | Load staged data into target table |
| `fetch_target_metadata` | Retrieve metadata about target table |
| `create_target_table` | Create destination table in Snowflake |
| `get_target_checksums` | Collect checksums from target |

## Task Flow Example

A typical table migration creates tasks in this pattern:

```
[determine_partition_strategy] (orchestrator)
            ↓
[create_partition_tasks] (orchestrator)
            ↓
    ┌───────┴───────┐
    ↓               ↓
[data_movement]  [data_movement]   (data-exchange-agent, parallel)
    ↓               ↓
[process_staged_data] [process_staged_data]   (orchestrator, parallel)
    ↓               ↓
[copy_into]      [copy_into]       (warehouse, parallel)
    ↓               ↓
[complete_partition_migration] ...  (orchestrator)
```

## Priority System

Tasks use numeric priorities where **lower values = higher priority**:

| Priority | Use Case |
|----------|----------|
| 1 | Fan-out tasks (partition strategy, task creation) |
| 2-3 | Extraction tasks (spread across range to balance load) |
| 2 | COPY INTO and loading tasks |
| 3 | Default priority |

## Communication Protocol

1. **Orchestrator** pushes tasks to the shared queue in Snowflake
2. **Data Exchange Agent** polls via stored procedure (`PULL_TASKS`)
3. Upon completion, executors call `COMPLETE_TASK` or `FAIL_TASK`
4. **Orchestrator** monitors task status and unblocks successor tasks
5. **Warehouse** tasks are monitored via Snowflake query history
