# Schema Migrations Guide

## Overview

The Data Migration Orchestrator uses a schema migration system to manage database schema changes in a version-controlled, predictable manner. This document explains how the system works and provides step-by-step instructions for adding new migrations.

## Table of Contents

- [Important Notes](#important-notes)
- [How Schema Migrations Work](#how-schema-migrations-work)
- [Migration Lifecycle](#migration-lifecycle)
- [Adding a New Migration](#adding-a-new-migration)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)

---

## Important Notes
1. DO NOT just change the SQL scripts if you want those changes to be considered for your migration.
2. When adding a new migration, make sure it can be executed in sequence after the previous migrations.
3. Consider that previous migrations might have been executed with different code.
4. Schema migrations are immutable. We are OK making changes to schema migrations until the first version is released (since us devs can simply remove the entire schema and execute the migrations from zero).

## How Schema Migrations Work

### Core Concepts

1. **Migrations are Python Classes**: Each migration is a Python class that inherits from `BaseMigration` and implements an `apply()` method.

2. **Explicit Registration**: Migrations must be explicitly registered in the `REGISTERED_MIGRATIONS` list in `schema_manager.py` - there is no automatic discovery.

3. **Version Tracking**: A `SCHEMA_MIGRATION` table in Snowflake tracks which migrations have been applied, when they were applied, and how long they took.

4. **Automatic Execution**: Migrations run automatically when the application starts (in `main.py`).

5. **Sequential Application**: Pending migrations are applied in order by version number.

### Architecture

```
schema/
├── __init__.py
├── schema_manager.py              # Main manager + REGISTERED_MIGRATIONS list
├── run_schema_migrations.py       # Helper function called from main.py
└── migrations/
    ├── __init__.py
    ├── base_migration.py          # Abstract base class
    ├── migration_0001_initial.py  # Initial schema setup
    └── migration_XXXX_*.py        # Future migrations
```

### Key Components

#### SchemaManager (`schema_manager.py`)

The main class that orchestrates migrations:

- **`migrate()`**: Main entry point - applies all pending migrations
- **`get_pending_migrations()`**: Returns list of migrations that haven't been applied yet
- **`REGISTERED_MIGRATIONS`**: List where all migrations must be registered

#### BaseMigration (`base_migration.py`)

Abstract base class that all migrations must inherit from:

```python
class BaseMigration(ABC):
    @property
    @abstractmethod
    def version(self) -> int:
        """Unique version number (must be positive integer)."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description of what this migration does."""
        pass
    
    @abstractmethod
    def apply(self, connection: SnowflakeConnection) -> None:
        """Execute the migration."""
        pass
```

#### SCHEMA_MIGRATION Table

Tracks migration history in Snowflake:

```sql
CREATE TABLE SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION (
    VERSION INTEGER PRIMARY KEY,
    DESCRIPTION TEXT NOT NULL,
    APPLIED_AT TIMESTAMP_NTZ NOT NULL DEFAULT SYSDATE(),
    EXECUTION_TIME_MS INTEGER NOT NULL,
    SUCCESS BOOLEAN NOT NULL DEFAULT TRUE
);
```

---

## Migration Lifecycle

### When Migrations Run

Migrations run automatically when the application starts via the `run_schema_migrations()` function in `main.py`:

```python
async def main():
    connection_config = get_connection_config()
    
    # Migrations run here, before anything else
    run_schema_migrations(connection_config)
    
    # Then application starts...
```

### Execution Flow

```
1. Application starts
   ↓
2. run_schema_migrations() called
   ↓
3. SchemaManager checks if SCHEMA_MIGRATION table exists
   ↓
4a. If NO -> Fresh database, all migrations are pending
4b. If YES -> Query table for applied versions
   ↓
5. Get pending migrations (registered but not applied)
   ↓
6. Sort pending migrations by version number
   ↓
7. For each pending migration:
   - Log start
   - Execute migration.apply(connection)
   - Record result in SCHEMA_MIGRATION table
   - Log completion with execution time
   ↓
8. Application continues startup
```

### What Happens on First Run

On a completely fresh database:

1. SCHEMA_MIGRATION table doesn't exist
2. System identifies all registered migrations as pending
3. Migration 0001 (Initial) executes:
   - Creates database and schema
   - Creates all tables, sequences, stages
   - Creates all stored procedures
   - **Creates SCHEMA_MIGRATION table** (last step)
4. Migration 0001 is recorded in SCHEMA_MIGRATION
5. Future runs will see version 1 is applied

### What Happens on Subsequent Runs

On a database that already has migrations:

1. SCHEMA_MIGRATION table exists
2. System queries for applied versions
3. Compares applied vs registered migrations
4. Only new migrations (higher version numbers) are applied
5. Each new migration is recorded after successful execution

---

## Adding a New Migration

Follow these steps to add a new schema migration:

### Step 1: Determine Version Number

Choose the next sequential version number. Check `REGISTERED_MIGRATIONS` in `schema_manager.py` to see what's already used.

```python
# If REGISTERED_MIGRATIONS has [Migration0001Initial], 
# your new migration should be version 2
```

### Step 2: Create Migration File

Create a new file in `src/data_migration_orchestrator/schema/migrations/`:

**File naming convention**: `migration_XXXX_description.py`

Example: `migration_0002_add_indexes.py`

```python
"""Add indexes to improve query performance."""

import snowflake.connector

from data_migration_orchestrator.schema.migrations.base_migration import BaseMigration


class Migration0002AddIndexes(BaseMigration):
    """Add indexes to TASK_QUEUE table."""

    @property
    def version(self) -> int:
        """Return version 2."""
        return 2

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Add indexes to TASK_QUEUE table for better query performance"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Apply the migration.

        Args:
            connection: Active Snowflake connection

        Raises:
            Exception: If migration fails

        """
        cursor = connection.cursor()
        try:
            # Execute your schema changes
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_task_queue_status 
                ON SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE(STATUS)
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_task_queue_executor 
                ON SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE(EXECUTOR_TYPE)
            """)
            
        finally:
            cursor.close()
```

### Step 3: Register the Migration

Add your migration to `REGISTERED_MIGRATIONS` in `schema_manager.py`:

```python
# In schema_manager.py
from data_migration_orchestrator.schema.migrations import Migration0001Initial
from data_migration_orchestrator.schema.migrations.migration_0002_add_indexes import (
    Migration0002AddIndexes,
)

# Explicit registration of all migrations
REGISTERED_MIGRATIONS: list[type[BaseMigration]] = [
    Migration0001Initial,
    Migration0002AddIndexes,  # <-- Add your new migration here
]
```

**Important**: Migrations in this list should be in version order, though the system will sort them automatically.

### Step 4: Update migrations/__init__.py (Optional)

For convenience, export your migration from `migrations/__init__.py`:

```python
# In migrations/__init__.py
from data_migration_orchestrator.schema.migrations.base_migration import BaseMigration
from data_migration_orchestrator.schema.migrations.migration_0001_initial import (
    Migration0001Initial,
)
from data_migration_orchestrator.schema.migrations.migration_0002_add_indexes import (
    Migration0002AddIndexes,
)

__all__ = ["BaseMigration", "Migration0001Initial", "Migration0002AddIndexes"]
```

### Step 5: Test the Migration

#### Local Testing

1. **On a test database**, run the application:
   ```bash
   python -m data_migration_orchestrator.main
   ```

2. The migration will run automatically and you should see:
   ```
   [SchemaManager] Starting migration process...
   [SchemaManager] Found 1 pending migration(s):
     - Version 2: Add indexes to TASK_QUEUE table for better query performance
   [SchemaManager] Applying migration 2: Add indexes to TASK_QUEUE table...
   [SchemaManager] Migration 2 completed in 1234ms
   [SchemaManager] Successfully applied 1 migration(s)
   ```

3. **Verify the migration was recorded**:
   ```sql
   SELECT VERSION, DESCRIPTION, APPLIED_AT, EXECUTION_TIME_MS, SUCCESS
   FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
   ORDER BY VERSION;
   ```

4. **Verify your schema changes**:
   ```sql
   -- For indexes
   SHOW INDEXES IN TABLE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE;
   
   -- For tables
   SHOW TABLES IN SCHEMA SNOWCONVERT_AI.DATA_MIGRATION;
   
   -- For procedures
   SHOW PROCEDURES IN SCHEMA SNOWCONVERT_AI.DATA_MIGRATION;
   ```

#### Test Idempotency

Run the application again. The migration should NOT run a second time:

```
[SchemaManager] Starting migration process...
[SchemaManager] Found 2 applied migration(s): [1, 2]
[SchemaManager] No pending migrations found. Schema is up to date.
```

---

## Migration Types and Examples

### Simple SQL Statement

For straightforward schema changes:

```python
def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
    cursor = connection.cursor()
    try:
        cursor.execute("""
            ALTER TABLE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
            ADD COLUMN NEW_FIELD TEXT NULL
        """)
    finally:
        cursor.close()
```

### Multiple SQL Statements

Execute multiple statements in sequence:

```python
def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
    cursor = connection.cursor()
    try:
        # Create new table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS SNOWCONVERT_AI.DATA_MIGRATION.AUDIT_LOG (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                EVENT_TYPE TEXT NOT NULL,
                EVENT_DATA VARIANT,
                CREATED_AT TIMESTAMP_NTZ DEFAULT SYSDATE()
            )
        """)
        
        # Create index
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_log_event_type
            ON SNOWCONVERT_AI.DATA_MIGRATION.AUDIT_LOG(EVENT_TYPE)
        """)
    finally:
        cursor.close()
```

### Executing SQL Files

If you have complex SQL in separate files:

```python
import os
from pathlib import Path

def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
    # Get path to SQL file
    migrations_dir = Path(__file__).parent
    sql_file = migrations_dir / "scripts" / "migration_0002.sql"
    
    # Read and execute
    with open(sql_file, 'r') as f:
        sql = f.read()
    
    cursor = connection.cursor()
    try:
        cursor.execute(sql)
    finally:
        cursor.close()
```

### Data Migrations

For migrations that modify data:

```python
def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
    cursor = connection.cursor()
    try:
        # Update existing data
        cursor.execute("""
            UPDATE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
            SET PRIORITY = 1
            WHERE PRIORITY IS NULL
        """)
        
        # Make column NOT NULL after backfilling
        cursor.execute("""
            ALTER TABLE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
            ALTER COLUMN PRIORITY SET NOT NULL
        """)
    finally:
        cursor.close()
```

---

## Best Practices

### DO ✅

1. **Use Sequential Version Numbers**
   - Version 1, 2, 3, 4... (no gaps)
   - Makes it easy to track order

2. **Write Descriptive Names and Descriptions**
   ```python
   # Good
   class Migration0003AddTaskPriorityIndex(BaseMigration):
       @property
       def description(self) -> str:
           return "Add index on TASK_QUEUE.PRIORITY for faster task retrieval"
   
   # Bad
   class Migration0003(BaseMigration):
       @property
       def description(self) -> str:
           return "Add index"
   ```

3. **Use Idempotent Operations**
   - Use `CREATE TABLE IF NOT EXISTS`
   - Use `CREATE INDEX IF NOT EXISTS`
   - Use `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` (Snowflake)
   - This makes migrations safer to re-run if needed

4. **Test on a Copy of Production Data**
   - Clone production database for testing
   - Verify migration works with real data volumes

5. **Keep Migrations Focused**
   - One migration = one logical change
   - Don't mix unrelated changes

6. **Handle Errors Gracefully**
   - Use try/finally to close cursors
   - Let exceptions propagate (SchemaManager will record failures)

7. **Document Complex Migrations**
   - Add comments explaining WHY
   - Include references to tickets/issues

### DON'T ❌

1. **Don't Modify Applied Migrations**
   - Once a migration is applied, never change its `apply()` method
   - The SCHEMA_MIGRATION table tracks by version number
   - Create a new migration instead

2. **Don't Skip Version Numbers**
   - Don't go 1, 2, 5, 7
   - Keep them sequential

3. **Don't Use the Same Version Number Twice**
   - Each migration must have a unique version
   - Check REGISTERED_MIGRATIONS before adding

4. **Don't Forget to Register**
   - Adding the file isn't enough
   - Must add to REGISTERED_MIGRATIONS

5. **Don't Assume Order of Execution**
   - Within a migration, statements execute sequentially
   - But don't rely on execution order between migrations
   - Each migration should be independent

6. **Don't Make Assumptions About Schema State**
   - Your migration might run after others you haven't seen
   - Use IF EXISTS / IF NOT EXISTS checks
   - Verify assumptions in your code

---

## Troubleshooting

### Migration Failed During Execution

**Symptom**: Migration throws an exception

**What Happens**:
- Migration is recorded in SCHEMA_MIGRATION with `SUCCESS = FALSE`
- Application startup fails
- Error is logged

**How to Fix**:
1. Check the logs for the specific error
2. Fix the issue in your migration code
3. Delete the failed migration record:
   ```sql
   DELETE FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
   WHERE VERSION = <failed_version> AND SUCCESS = FALSE;
   ```
4. Restart the application

### Migration Already Applied But Need to Re-run

**Scenario**: Migration was recorded as successful but didn't actually complete

**How to Fix**:
1. Manually undo the changes (if any were made)
2. Delete the migration record:
   ```sql
   DELETE FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
   WHERE VERSION = <version_to_rerun>;
   ```
3. Restart the application

### Wrong Version Number Used

**Symptom**: Created migration with version 5 but version 3 doesn't exist

**How to Fix**:
1. Rename the migration class and change the version number
2. Update the import in `schema_manager.py`
3. Update the registration in REGISTERED_MIGRATIONS

### Forgot to Register Migration

**Symptom**: Created migration file but it never runs

**Check**: Is your migration in `REGISTERED_MIGRATIONS`?

```python
# schema_manager.py
REGISTERED_MIGRATIONS: list[type[BaseMigration]] = [
    Migration0001Initial,
    # Is your migration here? ←
]
```

### Need to See Migration History

Query the SCHEMA_MIGRATION table:

```sql
-- All migrations
SELECT VERSION, DESCRIPTION, APPLIED_AT, EXECUTION_TIME_MS, SUCCESS
FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
ORDER BY VERSION;

-- Failed migrations only
SELECT VERSION, DESCRIPTION, APPLIED_AT
FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
WHERE SUCCESS = FALSE;

-- Recently applied
SELECT VERSION, DESCRIPTION, APPLIED_AT, EXECUTION_TIME_MS
FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
ORDER BY APPLIED_AT DESC
LIMIT 10;
```

### Migration Takes Too Long

**If a migration is slow**:

1. Check `EXECUTION_TIME_MS` in SCHEMA_MIGRATION table
2. Consider breaking it into smaller migrations
3. For data migrations on large tables:
   - Use batch processing
   - Add progress logging
   - Consider doing it in stages across multiple migrations

---

## Complete Example: Adding a New Column

Let's walk through a complete example of adding a new column to the TASK_QUEUE table.

### Step 1: Create Migration File

`src/data_migration_orchestrator/schema/migrations/migration_0002_add_task_category.py`:

```python
"""Add CATEGORY column to TASK_QUEUE table."""

import snowflake.connector

from data_migration_orchestrator.schema.migrations.base_migration import BaseMigration


class Migration0002AddTaskCategory(BaseMigration):
    """Add optional CATEGORY column to categorize tasks."""

    @property
    def version(self) -> int:
        """Return version 2."""
        return 2

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Add CATEGORY column to TASK_QUEUE table"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Apply the migration.

        Adds a nullable CATEGORY column to allow task categorization.

        Args:
            connection: Active Snowflake connection

        Raises:
            Exception: If migration fails

        """
        cursor = connection.cursor()
        try:
            # Add the column (nullable for backwards compatibility)
            cursor.execute("""
                ALTER TABLE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
                ADD COLUMN IF NOT EXISTS CATEGORY TEXT NULL
            """)
            
        finally:
            cursor.close()
```

### Step 2: Register in schema_manager.py

```python
from data_migration_orchestrator.schema.migrations import Migration0001Initial
from data_migration_orchestrator.schema.migrations.migration_0002_add_task_category import (
    Migration0002AddTaskCategory,
)

REGISTERED_MIGRATIONS: list[type[BaseMigration]] = [
    Migration0001Initial,
    Migration0002AddTaskCategory,
]
```

### Step 3: Test

```bash
python -m data_migration_orchestrator.main
```

Expected output:
```
[SchemaManager] Starting migration process...
[SchemaManager] Found 1 pending migration(s):
  - Version 2: Add CATEGORY column to TASK_QUEUE table
[SchemaManager] Applying migration 2: Add CATEGORY column to TASK_QUEUE table
[SchemaManager] Migration 2 completed in 245ms
[SchemaManager] Successfully applied 1 migration(s)
```

### Step 4: Verify

```sql
-- Check the column was added
DESC TABLE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE;

-- Check migration was recorded
SELECT * FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
WHERE VERSION = 2;
```

---

## Summary

- **Migrations are Python classes** that inherit from `BaseMigration`
- **Explicitly register** migrations in `REGISTERED_MIGRATIONS`
- **Migrations run automatically** on application startup
- **Track migration history** in SCHEMA_MIGRATION table
- **Keep migrations focused** and idempotent
- **Never modify** applied migrations - create new ones instead
- **Test thoroughly** before deploying to production

For questions or issues with migrations, consult the design document at `SCHEMA_MANAGER_DESIGN.md` or review existing migrations in the `schema/migrations/` directory.
