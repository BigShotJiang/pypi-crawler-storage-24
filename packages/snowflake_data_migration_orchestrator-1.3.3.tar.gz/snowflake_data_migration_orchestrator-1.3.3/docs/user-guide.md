# User Guide

Data Migration Orchestrator migrates tables from source databases (SQL Server, Redshift, etc.) to Snowflake.

## Creating a Workflow

To create a workflow, write a JSON configuration file and run:

```bash
hatch run create-workflow <config-file> [--connection-name <name>] [--name <workflow-name>] [--source-platform <platform>]
```

This validates the configuration against the schema described below and inserts a row into the `WORKFLOW` table. If `--connection-name` is omitted, the default Snowflake connection from environment variables is used.

## Workflow Configuration

A workflow configuration defines which tables to migrate and how. It consists of:
- `tables` (required): Array of table-specific configurations
- `defaultTableConfiguration` (optional): Shared settings inherited by all tables
- `affinity` (optional): Affinity group string; ensures only orchestrator and agent instances with the same affinity process this workflow

### Table Configuration Properties

| Property | Required | Description |
|----------|----------|-------------|
| `source` | Yes | Source table identifier (`databaseName`, `schemaName`, `tableName`) |
| `target` | Yes | Target table identifier (`databaseName`, `schemaName`, `tableName`) |
| `columnNamesToPartitionBy` | Yes | Columns used to partition data during extraction |
| `extraction` | No | Extraction strategy settings (see below) |
| `columnTypeMappings` | No | Type conversions: `[{sourceType, targetType}]` |
| `columnNameMappings` | No | Column renames: `[{sourceName, targetName}]` |
| `primaryKeyColumns` | No | Primary key columns (required for `trackModifications`) |
| `synchronization` | No | Incremental sync settings (see below) |
| `whereClauseCriteria` | No | Filter rows (e.g., `"is_deleted = 0"`) |

### Extraction Strategy

The `extraction` property configures how data is extracted from the source database.

| Field | Required | Description |
|-------|----------|-------------|
| `strategy` | Yes | `"regular"` (default) or `"unload"` |
| `externalStage` | UNLOAD only | Snowflake external stage for UNLOAD strategy |

**Regular (Default)**
```json
"extraction": {
  "strategy": "regular"
}
```

**UNLOAD (Redshift only)**
```json
"extraction": {
  "strategy": "unload",
  "externalStage": "MY_DB.MY_SCHEMA.S3_EXTERNAL_STAGE"
}
```

### Synchronization Strategies

Choose a strategy based on your data change patterns and performance requirements.

#### None (Default)

Full extraction of all partition data on every run. No synchronization metadata is stored.

```json
"synchronization": {
  "strategy": "none"
}
```

**Use when:** Data is small, changes are unpredictable, or you need guaranteed consistency.

#### Checksum

Computes a hash of all column values for each partition. On subsequent runs, compares the new checksum with the stored one:
- **Unchanged:** Partition is skipped
- **Changed:** Entire partition is cleared and re-extracted

```json
"synchronization": {
  "strategy": "checksum"
}
```

**Use when:** You need to detect any change in a partition but don't have a reliable watermark column. Good for dimension tables or lookup tables that change infrequently.

**Trade-offs:** Must compute checksum on source for every partition on every run (even if unchanged). Entire partition is re-synced if even one row changes.

#### Watermark

Tracks a monotonic column (timestamp, auto-increment ID, version number) to sync only rows where the watermark value is greater than the maximum observed in the previous sync.

```json
"synchronization": {
  "strategy": "watermark",
  "watermarkColumn": "UPDATED_AT"
}
```

**Use when:** Your table has a reliable monotonic column that increases on insert/update. Ideal for fact tables, event logs, or any append-heavy table.

**Limitation:** Watermark cannot track deletions. If rows are deleted from the source, they will remain in the target. Consider using soft deletes (`is_deleted` flag) with `whereClauseCriteria` to filter them out.

**Options:**

| Field | Required | Description |
|-------|----------|-------------|
| `watermarkColumn` | Yes | Column name to track (must be monotonically increasing) |
| `trackModifications` | No | If `true`, deduplicates modified rows using primary key (requires `primaryKeyColumns`) |

**With modification tracking:**

When `trackModifications: true`, the system handles rows that are updated (not just inserted). It uses the primary key to identify and deduplicate rows that appear in multiple syncs.

```json
"synchronization": {
  "strategy": "watermark",
  "watermarkColumn": "UPDATED_AT",
  "trackModifications": true
},
"primaryKeyColumns": ["order_id"]
```

> **Requirement:** `trackModifications: true` requires `primaryKeyColumns` to be specified.

#### Change Tracking (Future)

Uses a change tracking table to identify specific changed rows via JOIN. Not yet implemented.

## Default Table Configuration

Use `defaultTableConfiguration` to avoid repetition. Table-specific values override defaults.

**Merging rules:**
- **Nested objects** (`source`, `target`, `synchronization`, `extraction`): Deep merge (fields within are merged)
- **Collections** (`columnTypeMappings`, `columnNameMappings`, etc.): Table value replaces default entirely
- **Scalars** (`whereClauseCriteria`): Table value overrides default

## Examples

### Basic Migration

```json
{
  "affinity": "my-team",
  "tables": [
    {
      "source": {
        "databaseName": "SourceDB",
        "schemaName": "dbo",
        "tableName": "customers"
      },
      "target": {
        "databaseName": "TargetDB",
        "schemaName": "public",
        "tableName": "customers"
      },
      "columnNamesToPartitionBy": ["customer_id"]
    }
  ]
}
```

### Using Defaults

```json
{
  "defaultTableConfiguration": {
    "source": {
      "databaseName": "SourceDB",
      "schemaName": "dbo"
    },
    "target": {
      "databaseName": "TargetDB",
      "schemaName": "migrated"
    },
    "extraction": {
      "strategy": "unload",
      "externalStage": "MY_DB.MY_SCHEMA.S3_STAGE"
    }
  },
  "tables": [
    {
      "source": { "tableName": "customers" },
      "target": { "tableName": "customers" },
      "columnNamesToPartitionBy": ["customer_id"]
    },
    {
      "source": { "tableName": "orders" },
      "target": { "tableName": "orders" },
      "columnNamesToPartitionBy": ["order_id"],
      "columnTypeMappings": [
        { "sourceType": "MONEY", "targetType": "DECIMAL(19,4)" }
      ]
    }
  ]
}
```

### Incremental Sync with Watermark

```json
{
  "defaultTableConfiguration": {
    "source": { "databaseName": "SRC", "schemaName": "dbo" },
    "target": { "databaseName": "TGT", "schemaName": "public" },
    "synchronization": {
      "strategy": "watermark",
      "watermarkColumn": "updated_at"
    }
  },
  "tables": [
    {
      "source": { "tableName": "orders" },
      "target": { "tableName": "orders" },
      "columnNamesToPartitionBy": ["order_id"],
      "primaryKeyColumns": ["order_id"],
      "synchronization": {
        "trackModifications": true
      }
    }
  ]
}
```

In this example, the `orders` table inherits `strategy: watermark` and `watermarkColumn: updated_at` from defaults, and adds `trackModifications: true` via deep merge.
