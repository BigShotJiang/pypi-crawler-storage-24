# CONTRIBUTING

## Code Organization
Data Migration Orchestrator is organized in these main modules:
- `utils`: Utils that can be imported from anywhere.
- `cloud_core`: Core for Cloud operations, which includes definitions for Workflows and Tasks.
- `data_migration_core`: Core for Data Migration, which includes platform-agnostic logic.
- `data_migration_cloud`: Workflows Initializers, Task, and Task Handlers for Data Migration Workflows.  
- `cloud_orchestrator`: The Orchestrator itself, which consumes the other modules to support the execution of Workflows of any kind.

These modules follow a layered architecture with strict import rules. An arrow from module A to module B means that A can import from B. Colors represent the architecture layers:
- 🔵 **Blue**: Orchestration layer (`cloud_orchestrator`)
- 🟢 **Green**: Migration logic layer (`data_migration_cloud`)
- 🟠 **Orange**: Core components layer (`cloud_core`, `data_migration_core`)
- 🟣 **Purple**: Foundation layer (`utils`)

![Module Dependencies](docs/diagrams/module-dependencies.png)

## Type Errors, Lint Errors, Import Errors & Tests
We try to keep a high bar for code quality in this project. This includes having a linter and type-safe code. These commands can help you navigate the codebase and check that your work is fulfilling those expectations:
- Check (and fix) linter errors: `ruff check --fix`
- Check that you're not violating the rules of the dependencies between the main modules described in [Code Organization](#code-organization): `./scripts/validate_imports.py`
- Check type safety: `hatch run types:check-ty`
- Run all tests: `hatch run test:unit`

## Keeping Documentation up to Date
When adding/modifying features, we should be careful with updating the corresponding documentation (including this file, the README.md and the files in the `docs` directory). This is particularly relevant for the `user-guide.md`.
There are also Cursor rules that we should keep synchronized with the docs (including this doc).

## Development Patterns
### Task Model
In the **Data Migration Orchestrator** we distribute work by converting workflows into sequences of many tasks:
- Distributing the work in tasks help us achieve fault-tolerance, distribute the workload across several workers, and have "resumability".
- These tasks can have successors/predecessors and be executed by different components of the architecture.
- We strive for tasks to be idempotent, retryable, and moderately "quick" to execute. This might not always be achievable.
- No specific executor is assigned to a task, although a specific executor type will be assigned depending on the kind of the task.
- Each task has a payload that depends on the kind of the task. There are no guarantees on the time at which a task will be executed. Because of that, we can't assume that a sucessor task will be executed immediately after its predecessor (hours/days could have passed since).

When adding features to the Orchestrator, consider this task model. For more information, you can visit the `task-model.md` document.

### Creating/Queuing Tasks
Create tasks using the `TaskBuilder` class and then queue them using the `TaskQueue`. When creating sequences of dependent tasks, you can use the `push_task_chain` method of the `TaskQueue`.

### Manipulating Stage Paths
We constantly are putting data/metadata into files in different paths of stages and then reading that data/metadata (or copying it into tables). For example, the default internal stage is `SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS` and we normally upload metadata/data of the tables we're moving.

We try to avoid passing stage paths through task payloads. Instead, we try to have a standardize pattern for stage paths. For example, if you want to access the path at which the schema information for a table was uploaded, then it might look something like this: `<stage-id>/workflows/<workflow-id>/table/<table-metadata-id>/schema/`.

### Scopes
Scopes are described in detail in the `scopes.md` doc. Those are useful for understanding what is the purpose of each task and to what "domain" it applies.

When creating scopes, we should use the `ScopeBuilder`. There are other helper functions that can be used when creating scopes (specially if the scope is very commonly created).

### Changing Configuration
When changing configuration models (by adding or modifying properties or configuration sections) or configuration behavior, we should update the corresponding documentation (the `user-guide.md` and also the examples of configuration).

### Schema Migrations
When changing the schema (tables in the `SNOWCONVERT_AI.DATA_MIGRATION` schema, for example), we should do it through schema migrations. Check the `schema-migrations.md` doc for more information about this topic.

## Anti-patterns
1. We want to avoid having duplicated dataclasses (or dataclasses that are almost equivalent) without a good reason.
2. We do not want to rely too much on magic strings. In cases where we are dealing with categories/kinds, we should prefer to create a `StrEnum`.
3. We want to avoid "carrying" too much information across tasks, particularly if you are sending a piece of information that is not meant for a task, but rather for a future task that might be created by the immediate task you are creating. We should strive to read configuration values from the TABLE_METADATA configuration column, for example. This also applies to the PARTITION_METADATA synchronization data, for example.
4. We want to avoid using `Any` if possible. In general, we try to keep the code as type-safe as possible.
5. We want to avoid complex types without a meaningful name. For example, types like `dict[str, dict[str, str]]` might be complex to understand when reading the code. A type alias or a dedicated class can help here.
6. Let's not make non-deterministic tests, or unit tests that can take a lot of time. Running all tests should be matter of less than 10 seconds.

## How to add a new platform?
### Basic Integration
TODO

### Optimizations
TODO
