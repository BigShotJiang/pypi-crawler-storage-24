#!/usr/bin/env python3
"""
Validate import rules for the data_migration_orchestrator package.

Import Rules:
- cloud_core can only import modules from cloud_core or utils (or third party)
- data_migration_core can only import modules from data_migration_core or utils (or third party)
- data_migration_cloud can import modules from data_migration_core, cloud_core, data_migration_cloud, or utils
- cloud_orchestrator can import modules from cloud_core, data_migration_core, data_migration_cloud, cloud_orchestrator, or utils
- utils can only import from utils (or third party)
- All files in src/data_migration_orchestrator must be in one of the above modules (except main.py)

Usage: python validate_imports.py [--verbose]
"""

import ast
import sys

from pathlib import Path
from typing import NamedTuple


# Colors for terminal output
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
NC = "\033[0m"  # No Color

# Package name
PACKAGE_NAME = "data_migration_orchestrator"

# Internal modules (the ones we care about for import rules)
INTERNAL_MODULES = {
    "cloud_core",
    "data_migration_core",
    "data_migration_cloud",
    "cloud_orchestrator",
    "utils",
}

# Files in the package root that are allowed (not required to be in a module)
ALLOWED_ROOT_FILES = {"main.py", "__init__.py", "__about__.py"}

# Import rules: module -> set of allowed internal modules it can import from
IMPORT_RULES: dict[str, set[str]] = {
    "cloud_core": {"cloud_core", "utils"},
    "data_migration_core": {"data_migration_core", "utils"},
    "data_migration_cloud": {
        "data_migration_core",
        "cloud_core",
        "data_migration_cloud",
        "utils",
    },
    "cloud_orchestrator": {
        "cloud_core",
        "data_migration_core",
        "data_migration_cloud",
        "cloud_orchestrator",
        "utils",
    },
    "utils": {"utils"},
}


class ImportViolation(NamedTuple):
    """Represents a violation of the import rules."""

    file_path: Path
    line_number: int
    import_statement: str
    source_module: str
    imported_module: str
    reason: str


class OrphanFile(NamedTuple):
    """Represents a file that is not in any controlled module."""

    file_path: Path
    reason: str


def get_module_from_path(file_path: Path, src_dir: Path) -> str | None:
    """Determine which internal module a file belongs to based on its path."""
    try:
        relative = file_path.relative_to(src_dir / PACKAGE_NAME)
        parts = relative.parts
        if parts and parts[0] in INTERNAL_MODULES:
            return parts[0]
    except ValueError:
        pass
    return None


def extract_imported_internal_module(import_name: str) -> str | None:
    """
    Extract the internal module name from an import statement.

    Examples:
        'data_migration_orchestrator.cloud_core.tasks' -> 'cloud_core'
        'data_migration_orchestrator.data_migration_core' -> 'data_migration_core'
        'cloud_core.tasks' -> 'cloud_core'  (relative imports within package)
        'pandas' -> None (third party)

    """
    parts = import_name.split(".")

    # Handle absolute imports: from data_migration_orchestrator.X import ...
    if parts[0] == PACKAGE_NAME and len(parts) > 1:
        if parts[1] in INTERNAL_MODULES:
            return parts[1]

    # Handle relative-style imports that start with internal module
    if parts[0] in INTERNAL_MODULES:
        return parts[0]

    return None


def get_imports_from_file(file_path: Path) -> list[tuple[int, str, str]]:
    """
    Parse a Python file and extract all import statements.

    Returns a list of (line_number, import_statement, module_name) tuples.
    """
    imports = []

    try:
        with open(file_path, encoding="utf-8") as f:
            source = f.read()
    except (OSError, UnicodeDecodeError) as e:
        print(f"{YELLOW}Warning: Could not read {file_path}: {e}{NC}")
        return imports

    try:
        tree = ast.parse(source, filename=str(file_path))
    except SyntaxError as e:
        print(f"{YELLOW}Warning: Syntax error in {file_path}: {e}{NC}")
        return imports

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                import_stmt = f"import {alias.name}"
                imports.append((node.lineno, import_stmt, alias.name))

        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""

            # Handle relative imports
            if node.level > 0:
                # This is a relative import within the same module, skip detailed resolution
                # Just check if it's importing from the package
                if module:
                    full_module = module
                else:
                    # from . import X or from .. import X
                    continue  # Skip pure relative imports without module
            else:
                full_module = module

            names = ", ".join(alias.name for alias in node.names)
            import_stmt = f"from {full_module} import {names}"
            imports.append((node.lineno, import_stmt, full_module))

    return imports


def validate_file(file_path: Path, src_dir: Path) -> list[ImportViolation]:
    """Validate all imports in a single file against the import rules."""
    violations = []

    source_module = get_module_from_path(file_path, src_dir)
    if source_module is None:
        # File is not in one of the controlled modules
        return violations

    allowed_modules = IMPORT_RULES.get(source_module, set())

    for line_number, import_stmt, module_name in get_imports_from_file(file_path):
        imported_internal = extract_imported_internal_module(module_name)

        if imported_internal is not None and imported_internal not in allowed_modules:
            violations.append(
                ImportViolation(
                    file_path=file_path,
                    line_number=line_number,
                    import_statement=import_stmt,
                    source_module=source_module,
                    imported_module=imported_internal,
                    reason=f"'{source_module}' cannot import from '{imported_internal}' (allowed: {allowed_modules})",
                )
            )

    return violations


def find_python_files(directory: Path) -> list[Path]:
    """Recursively find all Python files in a directory."""
    return list(directory.rglob("*.py"))


def find_orphan_files(package_dir: Path) -> list[OrphanFile]:
    """Find Python files that are not in any controlled module."""
    orphans = []

    for file_path in package_dir.rglob("*.py"):
        relative = file_path.relative_to(package_dir)
        parts = relative.parts

        # Check if file is in the package root
        if len(parts) == 1:
            # It's a root file - check if it's allowed
            if parts[0] not in ALLOWED_ROOT_FILES:
                orphans.append(
                    OrphanFile(
                        file_path=file_path,
                        reason=f"File not in any module (allowed root files: {ALLOWED_ROOT_FILES})",
                    )
                )
        else:
            # It's in a subdirectory - check if it's in a controlled module
            if parts[0] not in INTERNAL_MODULES:
                orphans.append(
                    OrphanFile(
                        file_path=file_path,
                        reason=f"File not in any controlled module (must be in one of: {INTERNAL_MODULES})",
                    )
                )

    return orphans


def main() -> int:
    """Validate imports from the data-migration-orchestrator package."""
    verbose = "--verbose" in sys.argv or "-v" in sys.argv

    # Determine paths
    script_dir = Path(__file__).parent
    orchestrator_dir = script_dir.parent
    src_dir = orchestrator_dir / "src"
    package_dir = src_dir / PACKAGE_NAME

    if not package_dir.exists():
        print(f"{RED}Error: Package directory not found: {package_dir}{NC}")
        return 1

    print(f"{GREEN}{'=' * 50}{NC}")
    print(f"{GREEN}Validating Import Rules{NC}")
    print(f"{GREEN}{'=' * 50}{NC}")
    print()
    print(f"{YELLOW}Import Rules:{NC}")
    for module, allowed in IMPORT_RULES.items():
        print(f"  • {module} can import from: {allowed}")
    print(f"  • All files must be in one of: {INTERNAL_MODULES}")
    print(f"  • Allowed root files: {ALLOWED_ROOT_FILES}")
    print()

    # Check for orphan files first
    orphan_files = find_orphan_files(package_dir)

    if verbose and orphan_files:
        print(f"{YELLOW}Orphan files found:{NC}")
        for orphan in orphan_files:
            relative_path = orphan.file_path.relative_to(package_dir)
            print(f"  {RED}✗{NC} {relative_path}")

    # Collect all Python files from the controlled modules
    all_violations: list[ImportViolation] = []
    files_checked = 0

    for module_name in INTERNAL_MODULES:
        module_dir = package_dir / module_name
        if not module_dir.exists():
            print(f"{YELLOW}Warning: Module directory not found: {module_dir}{NC}")
            continue

        python_files = find_python_files(module_dir)

        if verbose:
            print(f"{YELLOW}Checking {module_name}/: {len(python_files)} files{NC}")

        for file_path in python_files:
            files_checked += 1
            violations = validate_file(file_path, src_dir)
            all_violations.extend(violations)

            if verbose and violations:
                for v in violations:
                    relative_path = file_path.relative_to(package_dir)
                    print(f"  {RED}✗{NC} {relative_path}:{v.line_number}")

    print(f"\n{YELLOW}Summary:{NC}")
    print(f"  Files checked: {files_checked}")
    print(f"  Import violations found: {len(all_violations)}")
    print(f"  Orphan files found: {len(orphan_files)}")

    has_errors = bool(all_violations or orphan_files)

    if orphan_files:
        print(f"\n{RED}{'=' * 50}{NC}")
        print(f"{RED}Orphan Files Detected{NC}")
        print(f"{RED}{'=' * 50}{NC}\n")

        for orphan in orphan_files:
            relative_path = orphan.file_path.relative_to(package_dir)
            print(f"  {RED}✗{NC} {relative_path}")
            print(f"      {RED}{orphan.reason}{NC}")
        print()

    if all_violations:
        print(f"\n{RED}{'=' * 50}{NC}")
        print(f"{RED}Import Violations Detected{NC}")
        print(f"{RED}{'=' * 50}{NC}\n")

        # Group violations by source module
        by_module: dict[str, list[ImportViolation]] = {}
        for v in all_violations:
            by_module.setdefault(v.source_module, []).append(v)

        for module, violations in sorted(by_module.items()):
            print(f"{YELLOW}In {module}/:{NC}")
            for v in violations:
                relative_path = v.file_path.relative_to(package_dir)
                print(f"  {RED}✗{NC} {relative_path}:{v.line_number}")
                print(f"      {v.import_statement}")
                print(f"      {RED}{v.reason}{NC}")
            print()

    if has_errors:
        total_errors = len(all_violations) + len(orphan_files)
        print(f"{RED}Validation FAILED: {total_errors} error(s) found{NC}")
        return 1
    else:
        print(f"\n{GREEN}{'=' * 50}{NC}")
        print(f"{GREEN}✓ All validations passed!{NC}")
        print(f"{GREEN}{'=' * 50}{NC}")
        return 0


if __name__ == "__main__":
    sys.exit(main())
