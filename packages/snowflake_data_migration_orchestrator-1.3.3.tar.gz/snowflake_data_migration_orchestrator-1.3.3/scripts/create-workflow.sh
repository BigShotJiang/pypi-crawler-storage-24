#!/bin/bash

# Usage: ./create-workflow.sh <SNOWFLAKE_CONNECTION_NAME> <JSON_FILE_PATH> <AFFINITY>

set -e

if [ $# -ne 3 ]; then
    echo "Usage: $0 <SNOWFLAKE_CONNECTION_NAME> <JSON_FILE_PATH> <AFFINITY>"
    echo "  SNOWFLAKE_CONNECTION_NAME: Name of the Snowflake connection to use"
    echo "  JSON_FILE_PATH: Path to the JSON configuration file"
    echo "  AFFINITY: Affinity value for the workflow"
    exit 1
fi

SNOWFLAKE_CONNECTION_NAME="$1"
JSON_FILE_PATH="$2"
AFFINITY="$3"

# Validate JSON file exists
if [ ! -f "$JSON_FILE_PATH" ]; then
    echo "Error: JSON file not found: $JSON_FILE_PATH"
    exit 1
fi

# Read JSON content and escape single quotes (replace ' with '')
JSON_CONTENT=$(cat "$JSON_FILE_PATH" | sed "s/'/''/g")

# Build and execute the SQL statement
SQL_STATEMENT="INSERT INTO SNOWCONVERT_AI.DATA_MIGRATION.WORKFLOW(
    NAME,
    WORKFLOW_TYPE,
    SOURCE_PLATFORM,
    TARGET_CLOUD_TYPE,
    TARGET_CLOUD_STAGE_NAME,
    TARGET_CLOUD_URL,
    SCHEMA_VERSION,
    INITIATOR_ID,
    CONFIGURATION,
    AFFINITY
)
SELECT
    'MY_WORKFLOW',
    'data-migration',
    'sqlserver',
    'snowflake:stage',
    '@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS',
    '',
    '1.0',
    '',
    PARSE_JSON('${JSON_CONTENT}'),
    '${AFFINITY}'
;"

snow sql --connection "$SNOWFLAKE_CONNECTION_NAME" --query "$SQL_STATEMENT"
