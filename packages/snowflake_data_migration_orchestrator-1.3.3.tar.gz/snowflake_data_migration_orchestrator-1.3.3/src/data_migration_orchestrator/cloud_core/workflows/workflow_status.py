from enum import StrEnum


class WorkflowStatus(StrEnum):
    """
    Enum representing possible workflow statuses.

    Used to track the state of workflows throughout their lifecycle.
    """

    PENDING = "pending"
    RUNNING = "running"
    FINISHED = "finished"
