import dataclasses
import json
import threading

from collections.abc import Callable
from json import dumps as serialize_to_json
from typing import Any, ClassVar, Generic, Protocol, TypeVar

from snowflake.connector import DictCursor, SnowflakeConnection
from snowflake.connector import Error as SnowflakeError
from snowflake.connector.constants import QueryStatus

import data_migration_orchestrator.cloud_core.workflows.workflow_columns as workflow_columns

from data_migration_orchestrator.cloud_core.constants.priorities import DEFAULT_PRIORITY
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.stored_procedure_calls import (
    COMPLETE_TASK_CALL_TEMPLATE,
    FAIL_TASK_CALL_TEMPLATE,
    HAS_WORKFLOW_STARTED_CALL_TEMPLATE,
    PULL_TASKS_CALL_TEMPLATE,
    PUSH_TASK_CALL_TEMPLATE,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_core.workflows.stored_procedures_calls import (
    COMPLETE_WORKFLOWS_CALL_TEMPLATE,
    GET_PENDING_WORKFLOWS_CALL_TEMPLATE,
)
from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.queues.table_task_queue")


class DataclassProtocol(Protocol):
    """Protocol for dataclass instances (required for dataclasses.asdict)."""

    __dataclass_fields__: ClassVar[dict[str, Any]]


TPayload = TypeVar("TPayload", bound=DataclassProtocol)


class TableTaskQueue(BaseTaskQueue[TPayload], Generic[TPayload]):
    """Concrete implementation of a task queue that works with a Snowflake table under the hood."""

    max_tasks_to_pull: int = 1000

    def __init__(
        self,
        connection: SnowflakeConnection,
        payload_mapper: Callable[[str, dict], TPayload],
        affinity: str | None = None,
    ) -> None:
        """
        Initialize the TableTaskQueue with a Snowflake connection.

        Args:
            connection: The Snowflake database connection to use for task operations.
            payload_mapper: A callable to map payload data to the appropriate type.
            affinity: The affinity group for this task queue. Will determine which workflows and tasks are picked up.

        """
        super().__init__(payload_mapper)
        self.affinity = affinity
        self.workflow_affinity_by_id: dict[int, str] = dict()
        self._pending_warehouse_tasks: dict[int, str] = {}
        self._warehouse_tasks_loaded: bool = False
        self._lock = threading.RLock()
        self._thread_local = threading.local()
        self._thread_local.connection = connection

    @property
    def connection(self) -> SnowflakeConnection:
        """Return the Snowflake connection for the current thread."""
        return self._thread_local.connection

    def register_thread_connection(self, connection: SnowflakeConnection) -> None:
        """Register a per-thread Snowflake connection for the calling thread."""
        self._thread_local.connection = connection

    async def _execute_statement(self, statement: str) -> None:
        with self.connection.cursor() as cursor:
            cursor.execute(statement)

    async def _push_task_internal(
        self,
        workflow_id: int,
        executor_type: ExecutorType,
        task_name: str,
        payload: TPayload,
        scope: str,
        priority: float = DEFAULT_PRIORITY,
        successor_task_id: int | None = None,
        is_blocked: bool = False,
    ) -> int | None:
        """
        Push a task into the task queue.

        Args:
            workflow_id: The ID of the workflow to which the task belongs.
            executor_type: The type of executor that should process the task.
            task_name: The name of the task.
            payload: The payload containing task data and metadata.
            scope: The hierarchical scope describing the task's purpose (e.g., 'Table[DB.SCHEMA.TABLE]::Preprocessing').
            priority: The priority of the task (default is 3).
            successor_task_id: The ID of the successor task, if any.
            is_blocked: Whether the task is initially blocked (default is False).

        Returns:
            The ID of the newly created task, or None if creation failed.

        """
        cursor = self.connection.cursor()
        payload_json_string = serialize_to_json(
            dataclasses.asdict(payload), default=str
        )
        affinity = await self.get_workflow_affinity(workflow_id)
        cursor.execute(
            PUSH_TASK_CALL_TEMPLATE,
            (
                workflow_id,
                executor_type.value,
                task_name,
                priority,
                successor_task_id,
                is_blocked,
                affinity,
                scope,
                payload_json_string,
            ),
        )
        row = cursor.fetchone()
        task_id: int | None = row[0] if row else None

        if (
            task_id is not None
            and executor_type == ExecutorType.WAREHOUSE
            and isinstance(payload, SnowflakeQueryTaskPayload)
            and payload.query_id
        ):
            with self._lock:
                self._pending_warehouse_tasks[task_id] = payload.query_id

        return task_id

    async def check_tasks(
        self, workflow_id: int, task_ids: list[int]
    ) -> list[Task[TPayload]]:
        """Check tasks."""
        cursor = self.connection.cursor()
        # TODO(SNOW-2687870): Do not use interpolation for writing array of ints in SQL code
        cursor.execute(
            "CALL SNOWCONVERT_AI.DATA_MIGRATION.CHECK_TASKS(%s, ARRAY_CONSTRUCT(%s)::ARRAY(INT))",
            (workflow_id, task_ids),
        )
        rows = cursor.fetchall()
        return [self._map_task(row, workflow_id) for row in rows]

    async def unblock_tasks(self):
        """Unblocks tasks for which all predecessor tasks have been completed."""
        await self._execute_statement(
            "CALL SNOWCONVERT_AI.DATA_MIGRATION.UNBLOCK_TASKS()"
        )

    async def expire_leases(self):
        """Expire leases for tasks that have exceeded their lease duration."""
        await self._execute_statement(
            "CALL SNOWCONVERT_AI.DATA_MIGRATION.EXPIRE_LEASES()"
        )

    async def refresh_warehouse_tasks(self):
        """
        Check tasks associated with queries running in a warehouse and mark them as complete.

        Uses the Snowflake Python connector's get_query_status() to check each
        pending warehouse task by query_id directly, instead of relying on
        QUERY_HISTORY_BY_WAREHOUSE() which can miss queries due to retention
        limits or timing issues.
        """
        with self._lock:
            if not self._warehouse_tasks_loaded:
                self._pending_warehouse_tasks = dict(
                    await self._fetch_pending_warehouse_tasks()
                )
                self._warehouse_tasks_loaded = True

            if not self._pending_warehouse_tasks:
                return

            logger.info(
                f"Checking status for {len(self._pending_warehouse_tasks)} pending warehouse task(s)"
            )
            completed_task_ids: list[int] = []
            for task_id, query_id in list(self._pending_warehouse_tasks.items()):
                try:
                    status = self.connection.get_query_status_throw_if_error(query_id)
                except SnowflakeError as e:
                    error_message = str(e)
                    logger.warning(
                        f"Warehouse task {task_id} query failed: {error_message}"
                    )
                    await self._fail_warehouse_task(task_id, error_message)
                    completed_task_ids.append(task_id)
                    continue
                except Exception as e:
                    logger.warning(
                        f"Could not check status for warehouse task {task_id} "
                        f"(query_id={query_id}), will retry next cycle: {e}"
                    )
                    continue

                logger.info(
                    f"Warehouse task {task_id} (query_id={query_id}): status={status.name}"
                )

                if self.connection.is_still_running(status):
                    continue

                if status == QueryStatus.SUCCESS:
                    logger.info(f"Completing warehouse task {task_id}")
                    try:
                        await self._complete_warehouse_task(task_id)
                    except Exception as e:
                        logger.warning(
                            f"Could not mark warehouse task {task_id} as completed, "
                            f"will retry next cycle: {e}"
                        )
                        continue
                else:
                    logger.warning(
                        f"Warehouse task {task_id} query has unexpected terminal "
                        f"status: {status.name}, will retry next cycle"
                    )
                    continue
                completed_task_ids.append(task_id)

            for task_id in completed_task_ids:
                self._pending_warehouse_tasks.pop(task_id, None)

    async def _fetch_pending_warehouse_tasks(self) -> list[tuple[int, str]]:
        """Fetch all pending warehouse tasks and their associated query IDs from the database."""
        with self.connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT ID, PAYLOAD:query_id::TEXT AS QUERY_ID
                FROM SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
                WHERE EXECUTOR_TYPE = %s
                    AND STATUS = %s
                    AND PAYLOAD:query_id IS NOT NULL
                """,
                (ExecutorType.WAREHOUSE.value, TaskStatus.PENDING.value),
            )
            rows = cursor.fetchall()
            return [(int(row[0]), str(row[1])) for row in rows]

    async def _complete_warehouse_task(self, task_id: int) -> None:
        """
        Mark a warehouse task as completed.

        Warehouse tasks are never leased to a consumer, so we update
        the status directly instead of going through COMPLETE_TASK
        (which requires LEASED_TO to match).
        """
        with self.connection.cursor() as cursor:
            cursor.execute(
                """
                UPDATE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
                SET STATUS = %s,
                    END_TIME = SYSDATE()
                WHERE ID = %s
                    AND EXECUTOR_TYPE = %s
                    AND STATUS = %s
                """,
                (
                    TaskStatus.COMPLETED.value,
                    task_id,
                    ExecutorType.WAREHOUSE.value,
                    TaskStatus.PENDING.value,
                ),
            )

    async def _fail_warehouse_task(self, task_id: int, error_message: str) -> None:
        """
        Mark a warehouse task as failed.

        Warehouse tasks are never leased to a consumer, so we update
        the status directly instead of going through FAIL_TASK
        (which requires LEASED_TO to match).
        """
        with self.connection.cursor() as cursor:
            cursor.execute(
                """
                UPDATE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
                SET STATUS = %s,
                    LAST_ERROR_MESSAGE = %s,
                    END_TIME = SYSDATE()
                WHERE ID = %s
                    AND EXECUTOR_TYPE = %s
                    AND STATUS = %s
                """,
                (
                    TaskStatus.FAILED.value,
                    error_message,
                    task_id,
                    ExecutorType.WAREHOUSE.value,
                    TaskStatus.PENDING.value,
                ),
            )

    async def get_tasks(self) -> list[Task]:
        """
        Get tasks for a workflow.

        Returns:
            The list of tasks for the workflow.

        """
        cursor = self.connection.cursor(DictCursor)
        cursor.execute(
            PULL_TASKS_CALL_TEMPLATE,
            (
                ExecutorType.ORCHESTRATOR.value,
                ExecutorType.ORCHESTRATOR.value,
                self.affinity,
                self.max_tasks_to_pull,
            ),
        )
        rows = cursor.fetchall()

        tasks = [
            self._map_task_by_column_name(
                row,
                executor_type=ExecutorType.ORCHESTRATOR,
                status=TaskStatus.EXECUTING,
            )
            for row in rows
        ]
        filtered_tasks = [task for task in tasks if task is not None]
        if len(filtered_tasks) != len(tasks):
            logger.warning(f"{len(tasks) - len(filtered_tasks)} task(s) failed to map")
        return filtered_tasks

    async def has_workflow_started(self, workflow_id: int) -> bool:
        """
        Check if the workflow has started.

        This checks if the workflow has any tasks in the task queue.
        """
        cursor = self.connection.cursor()
        cursor.execute(HAS_WORKFLOW_STARTED_CALL_TEMPLATE, (workflow_id,))
        row = cursor.fetchone()
        has_workflow_started: bool = row[0] if row else False
        return has_workflow_started

    async def complete_task(self, consumer_type: ExecutorType, task_id: int) -> bool:
        """
        Complete a task.

        Args:
            consumer_type: The type of consumer that completed the task.
            task_id: The ID of the task to complete.

        Returns:
            True if the task was successfully completed, False otherwise.

        """
        with self.connection.cursor() as cursor:
            cursor.execute(COMPLETE_TASK_CALL_TEMPLATE, (consumer_type.value, task_id))
            row = cursor.fetchone()
            return row[0] if row else False

    async def fail_task(
        self, consumer_id: str, task_id: int, error_message: str
    ) -> bool:
        """
        Mark a task as failed.

        Args:
            consumer_id: The ID of the consumer that failed the task.
            task_id: The ID of the task to mark as failed.
            error_message: The error message describing the failure.

        Returns:
            True if the task was marked as failed successfully, False otherwise.

        """
        with self.connection.cursor() as cursor:
            cursor.execute(
                FAIL_TASK_CALL_TEMPLATE, (task_id, consumer_id, error_message)
            )
            row = cursor.fetchone()
            return row[0] if row else False

    async def get_pending_workflows(self) -> list[Workflow]:
        """
        Get pending workflows to be started.

        Returns:
            The list of pending workflows to be started.

        """
        with self.connection.cursor(DictCursor) as cursor:
            cursor.execute(GET_PENDING_WORKFLOWS_CALL_TEMPLATE, (self.affinity,))
            rows = cursor.fetchall()
            return [self._map_row_to_workflow(row) for row in rows]

    async def complete_workflows(self):
        """Complete executing workflows for which all tasks are in terminal state."""
        await self._execute_statement(COMPLETE_WORKFLOWS_CALL_TEMPLATE)

    def _map_row_to_workflow(self, row: dict) -> Workflow:
        return Workflow(
            id=row[workflow_columns.ID],
            name=row[workflow_columns.NAME],
            source_platform=SourceType.from_string(
                row[workflow_columns.SOURCE_PLATFORM]
            ),
            target_cloud_type=row[workflow_columns.TARGET_CLOUD_TYPE],
            target_cloud_stage_name=row[workflow_columns.TARGET_CLOUD_STAGE_NAME],
            target_cloud_url=row.get(workflow_columns.TARGET_CLOUD_URL),
            schema_version=row.get(workflow_columns.SCHEMA_VERSION, ""),
            workflow_type=row[workflow_columns.WORKFLOW_TYPE],
            initiator_id=row.get(workflow_columns.INITIATOR_ID, ""),
            status=WorkflowStatus.RUNNING,
            configuration=json.loads(row[workflow_columns.CONFIGURATION]),
            creation_time=row.get(workflow_columns.CREATION_TIME),
            end_time=row.get(workflow_columns.END_TIME),
            affinity=row.get(workflow_columns.AFFINITY),
        )

    async def get_workflow_affinity(self, workflow_id: int) -> str | None:
        """
        Get the affinity group for a workflow.

        Args:
            workflow_id: The ID of the workflow.

        Returns:
            The affinity group for the workflow, or None if not found.

        """
        with self._lock:
            if workflow_id in self.workflow_affinity_by_id:
                return self.workflow_affinity_by_id[workflow_id]

        with self.connection.cursor(DictCursor) as cursor:
            cursor.execute(
                """
                    SELECT AFFINITY
                    FROM SNOWCONVERT_AI.DATA_MIGRATION.WORKFLOW
                    WHERE ID = %s
                """,
                (workflow_id,),
            )
            row = cursor.fetchone()
            if row is None:
                logger.warning(
                    f"Workflow with ID {workflow_id} not found (when looking for affinity)."
                )
                return None

            affinity: str | None = row.get(workflow_columns.AFFINITY)
            if affinity is not None:
                with self._lock:
                    self.workflow_affinity_by_id[workflow_id] = affinity
            return affinity
