# WAREHOUSE PAYLOADS
from dataclasses import dataclass
from typing import Literal


SNOWFLAKE_QUERY_TASK_PAYLOAD_KIND = "snowflake_query"


@dataclass
class SnowflakeQueryTaskPayload:
    """
    Payload for a Snowflake query task.

    This task is responsible for executing a query in Snowflake.
    This task is not completed by the WAREHOUSE, it has to be monitored by the ORCHESTRATOR and
    manually marked as completed by checking query history.
    """

    query: str
    """
    The query that is executed in Snowflake.
    """

    query_id: str | None = None
    """
    The ID of the query that is executed in Snowflake, or NULL if not yet assigned.
    This query can be used to read the query history and understand the status of the query
    (and subsequently, the status of this task).
    """

    kind: Literal["snowflake_query"] = SNOWFLAKE_QUERY_TASK_PAYLOAD_KIND
