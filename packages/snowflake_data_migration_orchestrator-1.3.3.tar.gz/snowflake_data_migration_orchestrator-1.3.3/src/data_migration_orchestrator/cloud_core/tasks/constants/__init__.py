"""Constants related to Cloud Tasks."""
