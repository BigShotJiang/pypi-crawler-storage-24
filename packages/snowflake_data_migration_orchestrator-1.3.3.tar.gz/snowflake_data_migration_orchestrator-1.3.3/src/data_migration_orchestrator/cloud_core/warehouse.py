from typing import Any

from snowflake.connector import SnowflakeConnection

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder


class Warehouse:
    """Represents a Snowflake warehouse and exposes operations associated with it."""

    def __init__(
        self,
        conn: SnowflakeConnection,
        task_queue: BaseTaskQueue[SnowflakeQueryTaskPayload],
    ):
        """
        Initialize the representation of a Snowflake Warehouse.

        Args:
            conn: The Snowflake database connection.
            task_queue: The task queue for managing tasks.

        """
        self.conn = conn
        self.task_queue = task_queue

    async def execute_snowflake_query_and_push_task(
        self,
        workflow_id: int,
        query: str,
        *args: Any,
        task_name: str,
        scope: str,
        priority: float,
        successor_task_id: int | None = None,
    ) -> int:
        """
        Execute a Snowflake query and push a task to the queue.

        Args:
            workflow_id: The workflow ID.
            query: The SQL query to execute.
            *args: Query parameters.
            task_name: The name of the task.
            scope: The hierarchical scope for this task (e.g., 'Table[DB.SCHEMA.TABLE]::Partition[0]::Loading')
            priority: The priority of the task.
            successor_task_id: Optional ID of the successor task.

        Returns:
            The task ID.

        """
        query_id = await self.execute_async_query(query, list(args))
        payload = SnowflakeQueryTaskPayload(query=query, query_id=query_id)
        task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=task_name,
                executor_type=ExecutorType.WAREHOUSE,
                payload=payload,
                scope=scope,
            )
            .with_successor(successor_task_id)
            .with_priority(priority)
            .build()
        )

        return await self.task_queue.push_task(task)

    async def execute_async_query(self, query: str, args: list[Any]) -> str:
        """
        Execute a query asynchronously in Snowflake and return the query ID.

        Args:
            query: The SQL query to execute.
            args: Query parameters.

        Returns:
            The query ID from Snowflake.

        Raises:
            Exception: If the query execution fails or query ID is not returned.

        """
        if query == "":
            # TODO(SNOW-2860272): Currently we are not handling empty queries.
            return ""
        query_data = self.conn.cursor().execute_async(query, args if args else None)
        query_id: str | None = query_data.get("queryId")
        if query_id is None:
            raise Exception("Failed to execute query in Snowflake")
        return query_id

    async def execute_sync_query(self, query: str) -> list[dict[str, Any]]:
        """
        Execute a query synchronously and return results.

        Args:
            query: The SQL query to execute.

        Returns:
            List of dictionaries representing query results.

        Raises:
            Exception: If the query execution fails.

        """
        cursor = self.conn.cursor()
        try:
            cursor.execute(query)
            rows = cursor.fetchall()
            columns = (
                [desc[0] for desc in cursor.description] if cursor.description else []
            )
            return [dict(zip(columns, row, strict=True)) for row in rows]
        except Exception as e:
            raise Exception(
                f"Failed to execute query. Query: {query}. Error: {e}"
            ) from e
        finally:
            cursor.close()
