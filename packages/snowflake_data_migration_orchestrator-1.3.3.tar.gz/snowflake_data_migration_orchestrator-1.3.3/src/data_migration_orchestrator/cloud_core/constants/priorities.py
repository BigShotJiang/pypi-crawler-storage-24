"""
Priority that should be assigned to tasks that will result in multiple fan-out tasks.

These tasks are critical for orchestrating parallel workloads, and thus should be given higher priority
to ensure timely execution.
"""

PRIORITY_FOR_FAN_OUT_TASKS = 1

"""
Default priority for tasks that do not have a specific priority requirement.
"""
DEFAULT_PRIORITY = 3
