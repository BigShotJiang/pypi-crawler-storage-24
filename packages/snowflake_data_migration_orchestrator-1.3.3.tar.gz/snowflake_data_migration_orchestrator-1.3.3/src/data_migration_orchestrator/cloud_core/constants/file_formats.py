# Snowflake file format for reading staged Parquet files
# TODO(SNOW-2860273): Ensure privileges over this file format
PARQUET_FILE_FORMAT = "SNOWCONVERT_AI.DATA_MIGRATION.PARQUET_FILE_FORMAT"

# Snowflake file format for reading staged CSV files
CSV_FILE_FORMAT = "SNOWCONVERT_AI.DATA_MIGRATION.CSV_FILE_FORMAT"
