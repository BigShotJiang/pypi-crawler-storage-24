"""UnsupportedPayloadKindError exception."""


class QueueingError(Exception):
    """Exception raised when a task could not be correctly queued into the task queue."""

    def __init__(
        self,
        task_name: str,
        internal_exception: Exception | None = None,
    ):
        """
        Initialize the exception.

        Args:
            task_name: The name of the task that failed to be queued
            internal_exception: Optional internal exception that caused this error

        """
        self.task_name = task_name
        self.internal_exception = internal_exception

        message = f"Failed to queue task '{task_name}'"
        if self.internal_exception:
            message += f". Internal exception: {self.internal_exception}"

        super().__init__(message)
