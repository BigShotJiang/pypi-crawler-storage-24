"""
Connection Manager for Snowflake.

Handles both local development and SPCS (Snowflake Container Services) environments.
"""

import os

from typing import Any

import snowflake.connector

from data_migration_orchestrator.__about__ import __version__
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from shared.telemetry import detect_runtime_environment, initialize_telemetry


logger = get_logger("connection_manager")


def is_spcs_environment() -> bool:
    """
    Detect if running in SPCS environment.

    It does so by checking for SNOWFLAKE_HOST
    which is automatically injected by SPCS.
    """
    return "SNOWFLAKE_HOST" in os.environ and "OMIT_SPCS_CREDENTIALS" not in os.environ


def get_connection_config() -> dict[str, Any]:
    """
    Build connection configuration based on the environment.

    Returns:
        Connection configuration dict for local or SPCS environment

    """
    if is_spcs_environment():
        return _get_spcs_config()
    else:
        return _get_local_config()


def _get_local_config() -> dict[str, Any]:
    """
    Get connection configuration for local development.

    Requires explicit credentials via environment variables.
    """
    logger.info("Detected LOCAL environment - using explicit credentials")

    connection_name = os.environ.get("SNOWFLAKE_CONNECTION_NAME")
    if connection_name:
        logger.info(f"Using connection_name: {connection_name}")
        return {"connection_name": connection_name}

    config = {}

    required_fields = ["SNOWFLAKE_ACCOUNT", "SNOWFLAKE_USER", "SNOWFLAKE_PASSWORD"]
    for field in required_fields:
        value = os.environ.get(field)
        if not value:
            raise ValueError(f"Missing required environment variable: {field}")
        config[field.lower().replace("snowflake_", "")] = value

    optional_fields = [
        "SNOWFLAKE_WAREHOUSE",
        "SNOWFLAKE_DATABASE",
        "SNOWFLAKE_SCHEMA",
        "SNOWFLAKE_ROLE",
    ]
    for field in optional_fields:
        value = os.environ.get(field)
        if value:
            config[field.lower().replace("snowflake_", "")] = value

    logger.info(
        f"Local connection config: account={config.get('account')}, user={config.get('user')}, "
        f"warehouse={config.get('warehouse')}, database={config.get('database')}"
    )

    return config


def _get_login_token() -> (
    str
):  # TODO(SNOW-2860280): We need to read this again if the token expires, to refresh the connection
    with open("/snowflake/session/token") as f:
        return f.read()


def _get_spcs_config() -> dict[str, Any]:
    """
    Get connection configuration for SPCS environment.

    Uses auto-injected environment variables from Snowflake.
    """
    logger.info("Detected SPCS environment - using auto-injected credentials")

    token_value: str = _get_login_token()
    config = {
        "account": os.environ.get("SNOWFLAKE_ACCOUNT"),
        "host": os.environ.get("SNOWFLAKE_HOST"),
        "port": int(os.environ.get("SNOWFLAKE_PORT", "443")),
        "authenticator": "oauth",
        "token": token_value,
        "protocol": os.environ.get("SNOWFLAKE_PROTOCOL", "https"),
    }

    if os.environ.get("SNOWFLAKE_DATABASE"):
        config["database"] = os.environ["SNOWFLAKE_DATABASE"]
    if os.environ.get("SNOWFLAKE_SCHEMA"):
        config["schema"] = os.environ["SNOWFLAKE_SCHEMA"]

    snowflake_warehouse = os.environ.get("SNOWFLAKE_WAREHOUSE")
    if snowflake_warehouse is not None and snowflake_warehouse != "":
        config["warehouse"] = snowflake_warehouse
    if os.environ.get("SNOWFLAKE_ROLE"):
        config["role"] = os.environ["SNOWFLAKE_ROLE"]

    logger.info(
        f"SPCS connection config: account={config.get('account')}, host={config.get('host')}, "
        f"role = {config.get('role')}, warehouse={config.get('warehouse')}, database={config.get('database')}, "
        f"token length={len(token_value)}, protocol={config.get('protocol')}, port={config.get('port')}"
    )
    return config


def create_connection() -> snowflake.connector.SnowflakeConnection:
    """
    Create and return a Snowflake connection based on the environment.

    Returns:
        An active Snowflake connection with telemetry initialized.

    """
    config = get_connection_config()
    logger.info("Creating Snowflake connection...")
    connection = snowflake.connector.connect(**config)
    logger.info("Snowflake connection created.")

    # Initialize telemetry automatically
    try:
        env = os.getenv("ENVIRONMENT", "prod")
        runtime = detect_runtime_environment()
        initialize_telemetry(
            conn=connection,
            app_name="data_migration_orchestrator",
            app_version=__version__,
            env=env,
            runtime=runtime,
        )
        logger.info(f"Telemetry initialized (env={env}, runtime={runtime.value})")
    except Exception as e:
        # Don't fail connection creation if telemetry fails
        logger.debug(f"Telemetry initialization skipped: {e}")

    return connection
