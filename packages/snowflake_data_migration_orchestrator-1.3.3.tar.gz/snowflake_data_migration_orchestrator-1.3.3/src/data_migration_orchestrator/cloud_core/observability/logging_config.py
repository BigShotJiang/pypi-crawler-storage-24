"""
Logging configuration for the data migration orchestrator.

This module provides a centralized logging configuration that supports:
- Logging to stdout
- Logging to a file
- Logging to both stdout and file (default)
"""

import logging

from enum import Enum
from pathlib import Path


class LogDestination(Enum):
    """Enum for log destination options."""

    STDOUT = "stdout"
    FILE = "file"
    BOTH = "both"


# Default log file path
DEFAULT_LOG_DIR = Path("logs")
DEFAULT_LOG_FILE = DEFAULT_LOG_DIR / "cloud_orchestrator.log"


# Application logger name
APP_LOGGER_NAME = "cloud_orchestrator"


def setup_logging(
    destination: LogDestination = LogDestination.BOTH,
    log_file_path: Path | None = None,
    log_level: int = logging.INFO,
    log_format: str | None = None,
) -> logging.Logger:
    """
    Set up logging configuration for the application.

    Args:
        destination: Where to send logs (stdout, file, or both)
        log_file_path: Path to the log file. If None, uses DEFAULT_LOG_FILE
        log_level: Logging level (e.g., logging.INFO, logging.DEBUG)
        log_format: Custom log format string. If None, uses default format

    Returns:
        Configured logger instance

    """
    # Use default log format if not provided
    if log_format is None:
        log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # Get the root logger for our application
    # logging.getLogger() returns the same instance for a given name
    logger = logging.getLogger(APP_LOGGER_NAME)
    logger.setLevel(log_level)

    # Remove any existing handlers to avoid duplicates
    logger.handlers.clear()

    # Create formatter
    formatter = logging.Formatter(log_format)

    # Add handlers based on destination
    if destination in (LogDestination.STDOUT, LogDestination.BOTH):
        console_handler = logging.StreamHandler()
        console_handler.setLevel(log_level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    if destination in (LogDestination.FILE, LogDestination.BOTH):
        # Use default log file if not specified
        file_path = log_file_path if log_file_path else DEFAULT_LOG_FILE

        # Create log directory if it doesn't exist
        file_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(file_path, mode="a")
        file_handler.setLevel(log_level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    # Prevent propagation to avoid duplicate logs
    logger.propagate = False

    return logger


def get_logger(name: str | None = None) -> logging.Logger:
    """
    Get a logger instance.

    This function leverages Python's logging module's built-in logger registry,
    which maintains singleton instances of loggers by name. No global variables needed!

    Args:
        name: Optional name for a sub-logger. If provided, returns a child logger
              of the main application logger (e.g., "data_migration_orchestrator.name").
              If None, returns the root application logger.

    Returns:
        Logger instance. If logging hasn't been configured yet via setup_logging(),
        the logger will use default Python logging behavior.

    """
    if name:
        # Return a child logger with the specified name
        # Python's getLogger automatically creates hierarchical relationships
        return logging.getLogger(f"{APP_LOGGER_NAME}.{name}")

    # Return the root application logger
    # Python's logging module maintains the same instance for a given name
    return logging.getLogger(APP_LOGGER_NAME)


def parse_log_destination(destination_str: str) -> LogDestination:
    """
    Parse a string into a LogDestination enum.

    Args:
        destination_str: String representation of log destination
                        (e.g., "stdout", "file", "both")

    Returns:
        LogDestination enum value

    Raises:
        ValueError: If the destination string is not valid

    """
    try:
        return LogDestination(destination_str.lower())
    except ValueError as err:
        valid_options = ", ".join([d.value for d in LogDestination])
        raise ValueError(
            f"Invalid log destination: {destination_str}. "
            f"Valid options are: {valid_options}"
        ) from err


def get_log_level_from_string(level_str: str) -> int:
    """
    Convert a string log level to a logging constant.

    Args:
        level_str: String representation of log level
                  (e.g., "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")

    Returns:
        Logging level constant

    Raises:
        ValueError: If the level string is not valid

    """
    level_str = level_str.upper()
    level_map = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }

    if level_str not in level_map:
        valid_options = ", ".join(level_map.keys())
        raise ValueError(
            f"Invalid log level: {level_str}. Valid options are: {valid_options}"
        )

    return level_map[level_str]


def shutdown_logging():
    """
    Shut down logging and close all handlers.

    This should be called when the application is shutting down to ensure
    all log messages are flushed and resources are released.
    """
    logging.shutdown()
