"""Datetime utility functions for formatting and validation."""

import re

from datetime import datetime


# Regex pattern to detect datetime strings in common formats
# Matches: YYYY-MM-DD HH:MM:SS, YYYY-MM-DDTHH:MM:SS, with optional fractional seconds
# and optional timezone offset
DATETIME_PATTERN = re.compile(
    r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[+-]\d{2}:\d{2})?$"
)

# Pattern to detect timezone offset at end of string (e.g., +00:00, -05:30)
TIMEZONE_OFFSET_PATTERN = re.compile(r"[+-]\d{2}:\d{2}$")

# Pattern to truncate fractional seconds to 3 digits (milliseconds)
# Matches: .NNNNNN (any number of digits after decimal, captures first 3)
FRACTIONAL_SECONDS_PATTERN = re.compile(r"\.(\d{3})\d*")


def is_datetime_string(value: str) -> bool:
    """
    Check if a string looks like a datetime value.

    Matches common datetime formats:
    - YYYY-MM-DD HH:MM:SS
    - YYYY-MM-DDTHH:MM:SS
    - With optional fractional seconds (.NNNNNN)
    - With optional timezone offset (+HH:MM or -HH:MM)

    Args:
        value: The string to check

    Returns:
        True if the string matches a datetime pattern, False otherwise

    """
    return bool(DATETIME_PATTERN.match(value))


def format_datetime_for_sqlserver(dt: datetime) -> str:
    """
    Format a Python datetime object for SQL Server.

    Uses CONVERT with style 126 (ISO8601) for maximum compatibility
    with DateTime, DateTime2, and DateTimeOffset types.

    Args:
        dt: The datetime object to format

    Returns:
        SQL Server CONVERT expression string

    """
    # TODO(SNOW-3102599): Replace code that is specific to SqlServer with more general code
    if dt.tzinfo is not None:
        # DateTimeOffset: include timezone
        iso_str = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]  # Trim to milliseconds
        offset = dt.strftime("%z")
        # Format offset as +HH:MM or -HH:MM
        if offset:
            formatted_offset = f"{offset[:3]}:{offset[3:]}"
            iso_str = f"{iso_str}{formatted_offset}"
        return f"CONVERT(datetimeoffset, '{iso_str}', 127)"
    else:
        # DateTime/DateTime2: no timezone
        iso_str = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]  # Trim to milliseconds
        return f"CONVERT(datetime2, '{iso_str}', 126)"


def format_datetime_string_for_sqlserver(value: str) -> str:
    """
    Format a datetime string for SQL Server.

    Converts common datetime string formats to SQL Server compatible format
    using CONVERT function.

    Args:
        value: The datetime string to format

    Returns:
        SQL Server CONVERT expression string

    """
    # TODO(SNOW-3102599): Replace code that is specific to SqlServer with more general code
    # Check for timezone offset (DateTimeOffset)
    has_timezone = bool(TIMEZONE_OFFSET_PATTERN.search(value))

    # Normalize the datetime string:
    # - Replace space separator with 'T' for ISO format
    # - Truncate microseconds to milliseconds (6 digits -> 3 digits)
    normalized = value.replace(" ", "T")

    # Truncate fractional seconds to 3 digits (milliseconds) for SQL Server compatibility
    normalized = FRACTIONAL_SECONDS_PATTERN.sub(r".\1", normalized)

    if has_timezone:
        return f"CONVERT(datetimeoffset, '{normalized}', 127)"
    else:
        return f"CONVERT(datetime2, '{normalized}', 126)"

    # TODO(SNOW-3102599): Review if we want to move this to query builder (for example)
