"""SQL utility functions for query construction and value sanitization."""

import re


# Pattern for valid SQL Server identifiers (no quoting needed):
# - Starts with a letter or underscore
# - Followed by letters, digits, or underscores
SQLSERVER_VALID_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

# Pattern for valid Snowflake identifiers (no quoting needed):
# - Starts with a letter or underscore
# - Followed by letters, digits, underscores, or $
# Note: Snowflake also requires uppercase for unquoted identifiers (checked separately)
SNOWFLAKE_VALID_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_$]*$")


def escape_sql_string(value: str) -> str:
    """
    Escape a string value for safe use in SQL queries.

    This function escapes single quotes by doubling them, which is the standard
    SQL escape mechanism for string literals.

    Args:
        value: The string value to escape

    Returns:
        The escaped string (without surrounding quotes)

    """
    return value.replace("'", "''")


def quote_string_literal(value: str, unicode_prefix: bool = False) -> str:
    """
    Quote a string value for use in SQL queries.

    This function wraps a string value in single quotes for use as a SQL string literal.
    It also escapes internal single quotes by doubling them.

    Args:
        value: The string value to quote
        unicode_prefix: If True, prefix with N for SQL Server Unicode literals (N'...')

    Returns:
        The quoted string literal

    """
    escaped_value = escape_sql_string(value)
    prefix = "N" if unicode_prefix else ""
    return f"{prefix}'{escaped_value}'"


def is_already_quoted_sqlserver(identifier: str) -> bool:
    """
    Check if an identifier is already quoted for SQL Server.

    SQL Server accepts both bracket notation [name] and double quotes "name".

    Args:
        identifier: The identifier to check

    Returns:
        True if the identifier is already quoted, False otherwise

    """
    return (identifier.startswith("[") and identifier.endswith("]")) or (
        identifier.startswith('"') and identifier.endswith('"')
    )


def is_already_quoted_snowflake(identifier: str) -> bool:
    """
    Check if an identifier is already quoted with double quotes.

    Args:
        identifier: The identifier to check

    Returns:
        True if the identifier is already double-quoted, False otherwise

    """
    return identifier.startswith('"') and identifier.endswith('"')


def needs_quoting_sqlserver(identifier: str) -> bool:
    """
    Check if a SQL Server identifier needs to be quoted.

    An identifier needs quoting if it doesn't match the valid identifier pattern
    (letter/underscore followed by letters/digits/underscores).

    Note: Reserved words are not automatically quoted - users should quote them
    in their configuration if needed.

    Args:
        identifier: The identifier to check

    Returns:
        True if the identifier should be quoted, False otherwise

    """
    if not identifier:
        return True

    if is_already_quoted_sqlserver(identifier):
        return False

    return not SQLSERVER_VALID_IDENTIFIER_PATTERN.match(identifier)


def needs_quoting_snowflake(identifier: str) -> bool:
    """
    Check if a Snowflake identifier needs to be quoted.

    In Snowflake, unquoted identifiers are case-insensitive and stored as uppercase.
    This function only checks if the identifier matches the valid pattern (starts with
    letter/underscore, contains only letters/digits/underscores/$).

    Note: Snowflake converts unquoted identifiers to uppercase automatically, so
    'mytable' and 'MYTABLE' are equivalent when unquoted. If user needs case-sensitive
    identifiers, should quote them explicitly in their configuration.

    Args:
        identifier: The identifier to check

    Returns:
        True if the identifier should be quoted, False otherwise

    """
    if not identifier:
        return True

    if is_already_quoted_snowflake(identifier):
        return False

    return not SNOWFLAKE_VALID_IDENTIFIER_PATTERN.match(identifier)


def quote_identifier_sqlserver(identifier: str, force_quote: bool = True) -> str:
    """
    Quote an identifier for SQL Server using double quotes.

    SQL Server supports both [brackets] and "double quotes" for quoting identifiers.
    Using double quotes for consistency with other databases (Snowflake, PostgreSQL).
    Internal " characters are escaped by doubling them: "" .

    Args:
        identifier: The identifier to quote (database, schema, table, or column name)
        force_quote: If True, always quote. If False, only quote if necessary.

    Returns:
        The quoted identifier in "double quote" notation

    """
    if not identifier:
        return '""'

    if is_already_quoted_sqlserver(identifier):
        return identifier

    if not force_quote and not needs_quoting_sqlserver(identifier):
        return identifier

    escaped = identifier.replace('"', '""')
    return f'"{escaped}"'


def quote_identifier_snowflake(identifier: str, force_quote: bool = True) -> str:
    """
    Quote an identifier for Snowflake using double quotes.

    Snowflake uses "double quotes" to quote identifiers. Internal " characters
    are escaped by doubling them: "" .

    Args:
        identifier: The identifier to quote (database, schema, table, or column name)
        force_quote: If True, always quote. If False, only quote if necessary.

    Returns:
        The quoted identifier in "double quote" notation

    """
    if not identifier:
        return '""'

    if is_already_quoted_snowflake(identifier):
        return identifier

    if not force_quote and not needs_quoting_snowflake(identifier):
        return identifier

    escaped = identifier.replace('"', '""')
    return f'"{escaped}"'


def quote_identifier(
    identifier: str,
    dialect: str = "sqlserver",
    force_quote: bool = True,
) -> str:
    """
    Quote an identifier (table, column, database name) for use in SQL queries.

    Both SQL Server and Snowflake use "double quotes" for identifier quoting.
    SQL Server also accepts [brackets], but we use double quotes for consistency.

    Args:
        identifier: The identifier to quote
        dialect: The SQL dialect ("sqlserver", "snowflake")
        force_quote: If True, always quote. If False, only quote if necessary.

    Returns:
        The quoted identifier in "double quote" notation

    """
    if dialect == "sqlserver":
        return quote_identifier_sqlserver(identifier, force_quote)
    elif dialect == "snowflake":
        return quote_identifier_snowflake(identifier, force_quote)
    else:
        return quote_identifier_sqlserver(identifier, force_quote)


def unquote_identifier_sqlserver(identifier: str) -> str:
    """
    Remove SQL Server quoting from an identifier.

    Handles both bracket notation [name] and double quote notation "name".

    Args:
        identifier: The potentially quoted identifier

    Returns:
        The identifier without quoting

    """
    is_bracket_quoted = identifier.startswith("[") and identifier.endswith("]")
    is_double_quote_quoted = identifier.startswith('"') and identifier.endswith('"')

    if is_bracket_quoted:
        return identifier[1:-1].replace("]]", "]")
    if is_double_quote_quoted:
        return identifier[1:-1].replace('""', '"')
    return identifier


def unquote_identifier_snowflake(identifier: str) -> str:
    """
    Remove Snowflake double-quote quoting from an identifier.

    Args:
        identifier: The potentially quoted identifier

    Returns:
        The identifier without double-quote quoting

    """
    if is_already_quoted_snowflake(identifier):
        return identifier[1:-1].replace('""', '"')
    return identifier


def unquote_identifier(identifier: str, dialect: str = "sqlserver") -> str:
    """
    Remove quoting from an identifier based on dialect.

    Args:
        identifier: The potentially quoted identifier
        dialect: The SQL dialect

    Returns:
        The identifier without quoting

    """
    if dialect == "sqlserver":
        return unquote_identifier_sqlserver(identifier)
    elif dialect == "snowflake":
        return unquote_identifier_snowflake(identifier)
    # TODO(SNOW-3102599): Add Redshift branch
    return identifier


# TODO(SNOW-3102599): Decide if we want to move this to query builder
