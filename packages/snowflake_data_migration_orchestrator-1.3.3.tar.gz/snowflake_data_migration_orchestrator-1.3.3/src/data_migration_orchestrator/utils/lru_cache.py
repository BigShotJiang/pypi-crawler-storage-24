"""
Generic LRU cache with TTL support.

This module provides a reusable LRU (Least Recently Used) cache implementation
with configurable capacity and time-to-live (TTL) for entries.
"""

import time

from collections import OrderedDict
from dataclasses import dataclass
from typing import Generic, TypeVar, cast


K = TypeVar("K")
V = TypeVar("V")


@dataclass
class _CacheEntry(Generic[V]):
    """Cache entry with value and timestamp for TTL tracking."""

    value: V
    timestamp: float


class LRUCache(Generic[K, V]):
    """
    LRU cache with TTL support.

    A generic cache that evicts least recently used entries when capacity
    is reached and expires entries after a configurable TTL.

    Type Parameters:
        K: The type of cache keys
        V: The type of cached values

    """

    # Default value to distinguish "not in cache" from "cached None"
    NOT_FOUND = object()

    def __init__(self, max_size: int = 200, ttl_seconds: float = 3600.0):
        """
        Initialize the LRU cache.

        Args:
            max_size: Maximum number of entries in the cache. When exceeded,
                the least recently used entries are evicted.
            ttl_seconds: Time-to-live in seconds for cache entries. Entries
                older than this are considered expired and removed on access.

        """
        self._cache: OrderedDict[K, _CacheEntry[V]] = OrderedDict()
        self._max_size = max_size
        self._ttl_seconds = ttl_seconds

    def get(self, key: K) -> V | None:
        """
        Get a value from the cache.

        Args:
            key: The cache key to look up

        Returns:
            The cached value, or None if not found or expired.
            Note: If you need to distinguish between "not in cache" and
            "cached as None", use get_with_sentinel() instead.

        """
        result = self.get_with_sentinel(key)
        if result is self.NOT_FOUND:
            return None
        return cast(V, result)

    def get_with_sentinel(self, key: K) -> V | object:
        """
        Get a value from the cache, distinguishing cache miss from cached None.

        Args:
            key: The cache key to look up

        Returns:
            The cached value (which may be None), or LRUCache.NOT_FOUND
            if the key is not in the cache or has expired.

        """
        if key not in self._cache:
            return self.NOT_FOUND

        entry = self._cache[key]
        current_time = time.monotonic()

        # Check TTL
        if current_time - entry.timestamp > self._ttl_seconds:
            # Entry expired, remove it
            del self._cache[key]
            return self.NOT_FOUND

        self._cache.move_to_end(key)
        return entry.value

    def set(self, key: K, value: V) -> None:
        """
        Store a value in the cache.

        If the key already exists, it is updated and moved to the end (most recent).
        If the cache is at capacity, the least recently used entry is evicted.

        Args:
            key: The cache key
            value: The value to cache (can be None)

        """
        # If key exists, remove to update timestamp
        if key in self._cache:
            del self._cache[key]

        # Remove oldest entries if at capacity
        while len(self._cache) >= self._max_size:
            self._cache.popitem(last=False)

        self._cache[key] = _CacheEntry(
            value=value,
            timestamp=time.monotonic(),
        )

    def invalidate(self, key: K) -> bool:
        """
        Remove a specific key from the cache.

        Args:
            key: The cache key to remove

        Returns:
            True if the key was in the cache and removed, False otherwise

        """
        if key in self._cache:
            del self._cache[key]
            return True
        return False

    def clear(self) -> None:
        """Remove all entries from the cache."""
        self._cache.clear()

    def __len__(self) -> int:
        """Return the number of entries in the cache (including potentially expired ones)."""
        return len(self._cache)

    def __contains__(self, key: K) -> bool:
        """Check if a key is in the cache (does not check TTL or update LRU order)."""
        return key in self._cache
