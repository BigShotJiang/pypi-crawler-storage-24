"""Utilities for building table references."""

import re

from dataclasses import dataclass

from data_migration_orchestrator.utils.sql_utils import (
    is_already_quoted_sqlserver,
    needs_quoting_sqlserver,
    quote_identifier_sqlserver,
)
from shared.enums.source_type import SourceType


@dataclass
class TableNameParts:
    """
    Parsed components of a qualified table name.

    Attributes:
        database: Database/catalog name (None if not specified), unquoted
        schema: Schema name (None if not specified), unquoted
        table: Table name (always present), unquoted

    """

    database: str | None
    schema: str | None
    table: str


def parse_table_name(
    table_name: str, source_type: str = SourceType.SQLSERVER
) -> TableNameParts:
    """
    Parse a qualified table name into its components.

    Handles simple dot-separated names and quoted identifiers:
    - Bracket notation: [schema].[table]
    - Double-quote notation: "schema"."table"

    Args:
        table_name: Qualified table name (e.g., 'schema.table', '[schema].[table]',
            or '"schema"."table"')
        source_type: Source database type (default: "sqlserver")

    Returns:
        TableNameParts with database, schema, and table components

    """
    if not table_name or not table_name.strip():
        raise ValueError("table_name cannot be empty")

    table_name = table_name.strip()

    # Handle quoted identifiers (brackets or double quotes)
    has_brackets = "[" in table_name
    has_double_quotes = '"' in table_name

    if source_type == SourceType.SQLSERVER and (has_brackets or has_double_quotes):
        # Pattern matches [bracketed], "double-quoted", or unquoted identifiers
        bracketed_pattern = r"\[([^\]]*(?:\]\][^\]]*)*)\]"  # Handles escaped ]]
        quoted_pattern = r'"([^"]*(?:""[^"]*)*)"'  # Handles escaped ""
        unquoted_pattern = r'([^.\[\]"]+)'
        pattern = f"({bracketed_pattern})|({quoted_pattern})|({unquoted_pattern})"

        parts = []
        for match in re.finditer(pattern, table_name):
            full_match = match.group(0)
            if full_match.startswith("["):
                inner = full_match[1:-1].replace("]]", "]")
                parts.append(inner)
            elif full_match.startswith('"'):
                inner = full_match[1:-1].replace('""', '"')
                parts.append(inner)
            else:
                parts.append(full_match)
    else:
        parts = table_name.split(".")

    parts = [p.strip() for p in parts if p.strip()]

    if not parts:
        raise ValueError(f"Invalid table name: {table_name}")

    if len(parts) == 1:
        return TableNameParts(database=None, schema=None, table=parts[0])
    elif len(parts) == 2:
        return TableNameParts(database=None, schema=parts[0], table=parts[1])
    else:
        return TableNameParts(database=parts[-3], schema=parts[-2], table=parts[-1])


def _normalize_identifier_for_source(
    identifier: str, source_type: SourceType | None
) -> str:
    """
    Normalize an identifier appropriately for the source type.

    For SQL Server, unquoted identifiers are case-insensitive and
    stored in uppercase by default. Quoted identifiers preserve case.

    Args:
        identifier: The identifier to normalize
        source_type: The source database type

    Returns:
        The appropriately normalized identifier

    """
    if source_type == SourceType.SQLSERVER:
        possibly_quoted_identifier = _quote_identifier_for_source(
            identifier, source_type
        )
        if is_already_quoted_sqlserver(possibly_quoted_identifier):
            # Preserve case for identifiers that require quoting
            return possibly_quoted_identifier
        else:
            # Unquoted identifiers are case-insensitive, normalize to uppercase
            return possibly_quoted_identifier.upper()

    # TODO(SNOW-3102599): Move to query builder?
    return identifier


def _quote_identifier_for_source(
    identifier: str,
    source_type: str,
    force_quote: bool = False,
) -> str:
    """
    Quote an identifier appropriately for the source type.

    Args:
        identifier: The identifier to quote
        source_type: The source database type
        force_quote: If True, always quote regardless of whether it's needed

    Returns:
        The appropriately quoted identifier

    """
    if source_type == SourceType.SQLSERVER:
        should_quote = (
            force_quote
            or needs_quoting_sqlserver(identifier)
            or is_already_quoted_sqlserver(identifier)
        )
        if should_quote:
            return quote_identifier_sqlserver(identifier, force_quote=True)
        return identifier
    return identifier


def build_table_ref(
    database: str, schema: str, table_name: str, source_type: SourceType | None
) -> str:
    """
    Build fully qualified table reference with proper quoting.

    Uses "double quote" notation when quoting is needed:
    - Special characters (spaces, dots, etc.)
    - Reserved words
    - Identifiers starting with digits

    Simple identifiers like 'dbo' or 'MyTable' are not quoted since
    SQL Server is case-insensitive by default for unquoted identifiers.

    Args:
        database: Database name
        schema: Schema name
        table_name: Table name
        source_type: Source database type (used for quoting rules)

    Returns:
        Fully qualified table reference string with proper quoting

    """
    # Quote identifiers only when needed (special chars, reserved words, etc.)
    db_fragment = (
        _normalize_identifier_for_source(database, source_type) + "."
        if database
        else ""
    )
    schema_fragment = (
        _normalize_identifier_for_source(schema, source_type) + "." if schema else ""
    )
    table_fragment = _normalize_identifier_for_source(table_name, source_type)
    return f"{db_fragment}{schema_fragment}{table_fragment}"


def build_table_ref_from_parts(
    parts: TableNameParts,
    source_type: str = SourceType.SQLSERVER,
    force_quote: bool = False,
) -> str:
    """
    Build fully qualified table reference from parsed parts.

    Args:
        parts: Parsed table name parts
        source_type: Source database type (default: "sqlserver")
        force_quote: If True, always quote all identifiers

    Returns:
        Fully qualified table reference string with proper quoting

    """
    # Validate source type
    SourceType.from_string(source_type)

    components = []

    if parts.database:
        quoted_db = _quote_identifier_for_source(
            parts.database, source_type, force_quote=force_quote
        )
        components.append(quoted_db)

    if parts.schema:
        quoted_schema = _quote_identifier_for_source(
            parts.schema, source_type, force_quote=force_quote
        )
        components.append(quoted_schema)

    quoted_table = _quote_identifier_for_source(
        parts.table, source_type, force_quote=force_quote
    )
    components.append(quoted_table)

    return ".".join(components)


def quote_column_name(column_name: str, source_type: str = SourceType.SQLSERVER) -> str:
    """
    Quote a column name appropriately for the source type.

    Only quotes the column name if it needs quoting (special characters,
    reserved words, etc.). Simple column names like 'id' are not quoted.

    Args:
        column_name: The column name to quote
        source_type: The source database type (default: "sqlserver")

    Returns:
        The column name, quoted only if necessary

    """
    return _quote_identifier_for_source(column_name, source_type)
