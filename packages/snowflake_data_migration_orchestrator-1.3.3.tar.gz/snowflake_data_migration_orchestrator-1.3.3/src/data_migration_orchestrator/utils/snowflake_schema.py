"""
Snowflake database and schema provisioning utilities.

Provides helpers that check for existence before creating, so callers don't
need CREATE privileges when the objects already exist.
"""

import logging

from collections.abc import Awaitable, Callable
from typing import Any


logger = logging.getLogger(__name__)


async def ensure_database_and_schema(
    execute_query: Callable[[str], Awaitable[list[Any]]],
    database_name: str,
    schema_name: str,
) -> None:
    """
    Ensure a Snowflake database and schema exist, creating them if needed.

    Uses SHOW commands to check existence first, avoiding CREATE IF NOT EXISTS
    which requires CREATE privileges even when the object already exists.

    Args:
        execute_query: Async callable that executes a SQL query and returns
            a list of results (empty list when no rows match).
        database_name: Name of the database to ensure exists.
        schema_name: Name of the schema to ensure exists.

    """
    db_rows = await execute_query(f"SHOW DATABASES LIKE '{database_name}'")
    if not db_rows:
        logger.info("Database %s does not exist, creating...", database_name)
        await execute_query(f"CREATE DATABASE {database_name}")
    else:
        logger.info("Database %s already exists, skipping creation", database_name)

    schema_rows = await execute_query(
        f"SHOW SCHEMAS LIKE '{schema_name}' IN DATABASE {database_name}"
    )
    if not schema_rows:
        logger.info("Schema %s does not exist, creating...", schema_name)
        await execute_query(f"CREATE SCHEMA {database_name}.{schema_name}")
    else:
        logger.info("Schema %s already exists, skipping creation", schema_name)


def ensure_database_and_schema_sync(
    execute_and_fetch: Callable[[str], Any],
    database_name: str,
    schema_name: str,
) -> None:
    """
     Ensure a Snowflake database and schema exist, creating them if needed (synchronous).

    Args:
        execute_and_fetch: Callable that executes a SQL query and returns the
            first row (or a falsy value when no rows match).
        database_name: Name of the database to ensure exists.
        schema_name: Name of the schema to ensure exists.

    """
    db_result = execute_and_fetch(f"SHOW DATABASES LIKE '{database_name}'")
    if not db_result:
        logger.info("Database %s does not exist, creating...", database_name)
        execute_and_fetch(f"CREATE DATABASE {database_name}")
    else:
        logger.info("Database %s already exists, skipping creation", database_name)

    schema_result = execute_and_fetch(
        f"SHOW SCHEMAS LIKE '{schema_name}' IN DATABASE {database_name}"
    )
    if not schema_result:
        logger.info("Schema %s does not exist, creating...", schema_name)
        execute_and_fetch(f"CREATE SCHEMA {database_name}.{schema_name}")
    else:
        logger.info("Schema %s already exists, skipping creation", schema_name)
