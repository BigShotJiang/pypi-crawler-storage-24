"""Base migration class for schema migrations."""

from abc import ABC, abstractmethod

import snowflake.connector


class BaseMigration(ABC):
    """
    Abstract base class for schema migrations.

    All schema migrations must inherit from this class and implement the required methods.
    """

    @property
    @abstractmethod
    def version(self) -> int:
        """
        Return the migration version number.

        Returns:
            int: Unique version number for this migration (must be positive integer)

        """
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """
        Return a description of this migration.

        Returns:
            str: Human-readable description of what this migration does

        """
        pass

    @abstractmethod
    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Apply this migration.

        Args:
            connection: Active Snowflake connection to execute migration against

        Raises:
            Exception: If migration fails for any reason

        """
        pass

    def rollback(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Rollback this migration (optional, not implemented in initial version).

        Args:
            connection: Active Snowflake connection to execute rollback against

        Raises:
            NotImplementedError: Rollback is not yet supported

        """
        raise NotImplementedError("Rollback is not yet supported")

    def __repr__(self) -> str:
        """Return string representation of migration."""
        return f"{self.__class__.__name__}(version={self.version}, description='{self.description}')"
