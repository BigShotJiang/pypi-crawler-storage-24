"""Initial schema migration for Data Migration Orchestrator."""

import os

from pathlib import Path
from typing import Any

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.utils.snowflake_schema import (
    ensure_database_and_schema_sync,
)


logger = get_logger("schema.migrations.migration_0001")


class Migration0001Initial(BaseMigration):
    """
    Initial migration that sets up the complete database schema.

    This migration executes all SQL scripts in the assets directory in the correct
    dependency order to bootstrap a fresh database.
    """

    @property
    def version(self) -> int:
        """Return version 1 for initial migration."""
        return 1

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "Initial schema setup - creates database, tables, sequences, and procedures"
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Apply the initial migration by executing all SQL scripts in order.

        Args:
            connection: Active Snowflake connection

        Raises:
            Exception: If any SQL script fails to execute

        """
        # Get the path to the assets directory
        assets_dir = self._get_assets_directory()

        # Define the execution order of SQL scripts
        script_paths = [
            # 1. Core tables and sequences
            "scripts/task-queue/task_id_sequence.sql",
            "scripts/task-queue/task_queue.sql",
            "scripts/task-queue/task_results.sql",
            "scripts/workflows/workflow.sql",
            "scripts/file-formats/csv_file_format.sql",
            "scripts/file-formats/parquet_file_format.sql",
            # 2. Table metadata tables and sequences
            "scripts/table-metadata/table_metadata_id_sequence.sql",
            "scripts/table-metadata/partition_metadata_id_sequence.sql",
            "scripts/table-metadata/table_metadata.sql",
            "scripts/table-metadata/partition_metadata.sql",
            # 3. Task queue procedures (alphabetical order)
            "scripts/task-queue/procedures/check_tasks.sql",
            "scripts/task-queue/procedures/complete_task.sql",
            "scripts/task-queue/procedures/copy_parquet_into_table.sql",
            "scripts/task-queue/procedures/create_table.sql",
            "scripts/task-queue/procedures/expire_leases.sql",
            "scripts/task-queue/procedures/fail_task.sql",
            "scripts/task-queue/procedures/has_workflow_started.sql",
            "scripts/task-queue/procedures/pull_tasks.sql",
            "scripts/task-queue/procedures/push_task_variant.sql",
            "scripts/task-queue/procedures/push_task_text.sql",
            "scripts/task-queue/procedures/refresh_leases.sql",
            "scripts/task-queue/procedures/unblock_tasks.sql",
            # 4. Table metadata procedures & views
            "scripts/table-metadata/procedures/insert_table_metadata.sql",
            "scripts/table-metadata/procedures/insert_partition_metadata.sql",
            "scripts/table-metadata/procedures/get_table_configuration.sql",
            "scripts/table-metadata/procedures/find_existing_table_metadata.sql",
            "scripts/table-metadata/procedures/copy_table_metadata.sql",
            "scripts/table-metadata/procedures/copy_partition_metadata.sql",
            "scripts/table-metadata/procedures/get_partition_metadata.sql",
            "scripts/table-metadata/views/table_progress.sql",
            "scripts/table-metadata/views/data_migration_error.sql",
            "scripts/table-metadata/views/table_progress_with_example_error.sql",
            # 5. Workflow procedures
            "scripts/workflows/procedures/get_pending_workflows.sql",
            "scripts/workflows/procedures/complete_workflows.sql",
            # 6. Schema migration tracking table (created last)
            "scripts/task-queue/schema_migration_table.sql",
        ]

        with connection.cursor() as cursor:
            self._ensure_database_and_schema(cursor)

            for script_path in script_paths:
                full_path = os.path.join(assets_dir, script_path)
                logger.info(f"Executing: {script_path}")
                self._execute_sql_file(cursor, full_path)
                logger.info(f"Completed: {script_path}")

            logger.info("Successfully applied initial migration")

    def _ensure_database_and_schema(
        self, cursor: snowflake.connector.cursor.SnowflakeCursor
    ) -> None:
        """
        Ensure the SNOWCONVERT_AI database and DATA_MIGRATION schema exist.

        Uses SHOW commands to check existence first, avoiding CREATE IF NOT EXISTS
        which requires CREATE privileges even when the object already exists.

        Args:
            cursor: Snowflake cursor to execute SQL with

        """

        def _execute_and_fetch(sql: str) -> Any:
            cursor.execute(sql)
            return cursor.fetchone()

        ensure_database_and_schema_sync(
            _execute_and_fetch, "SNOWCONVERT_AI", "DATA_MIGRATION"
        )

    def _get_assets_directory(self) -> str:
        """
        Get the absolute path to the assets directory.

        Returns:
            str: Absolute path to assets directory

        """
        # Get the directory containing this migration file
        migrations_dir = Path(__file__).parent

        # Navigate up to the package root, then to assets
        # migrations/ -> schema/ -> cloud_orchestrator/ -> data_migration_orchestrator/ -> assets/
        package_root = migrations_dir.parent.parent.parent
        assets_dir = package_root / "assets"

        if not assets_dir.exists():
            raise FileNotFoundError(f"Assets directory not found: {assets_dir}")

        return str(assets_dir)

    def _execute_sql_file(
        self, cursor: snowflake.connector.cursor.SnowflakeCursor, file_path: str
    ) -> None:
        """
        Execute a SQL file.

        Args:
            cursor: Snowflake cursor to execute SQL with
            file_path: Path to the SQL file

        Raises:
            FileNotFoundError: If SQL file doesn't exist
            Exception: If SQL execution fails

        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"SQL file not found: {file_path}")

        with open(file_path, encoding="utf-8") as f:
            sql = f.read().strip()

        if not sql:
            raise ValueError(f"SQL file is empty: {file_path}")

        try:
            cursor.execute(sql)
        except Exception as e:
            raise Exception(f"Failed to execute {file_path}: {str(e)}") from e
