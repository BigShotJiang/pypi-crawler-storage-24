"""Schema Manager for managing database migrations."""

import time

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0001_initial import (
    Migration0001Initial,
)


logger = get_logger("schema_manager")


# Explicit registration of all migrations
REGISTERED_MIGRATIONS: list[type[BaseMigration]] = [
    Migration0001Initial,
    # Future migrations added here
]


class SchemaManager:
    """
    Manages schema migrations for the Data Migration Orchestrator.

    The Schema Manager is responsible for:
    - Tracking which migrations have been applied
    - Discovering pending migrations
    - Applying migrations in the correct order
    - Recording migration results

    Usage:
        manager = SchemaManager(connection)
        manager.migrate()  # Apply all pending migrations
    """

    def __init__(self, connection: snowflake.connector.SnowflakeConnection):
        """
        Initialize the Schema Manager.

        Args:
            connection: Active Snowflake connection for executing migrations

        """
        self.connection = connection

    def migrate(self) -> None:
        """
        Apply all pending migrations.

        This is the main entry point for running migrations. It:
        1. Checks which migrations have been applied
        2. Determines which migrations are pending
        3. Applies pending migrations in order
        4. Records results in the SCHEMA_MIGRATION table

        Raises:
            Exception: If any migration fails

        """
        logger.info("Starting migration process...")

        pending_migrations = self.get_pending_migrations()

        if not pending_migrations:
            logger.info("No pending migrations found. Schema is up to date.")
            return

        logger.info(f"Found {len(pending_migrations)} pending migration(s):")
        for migration in pending_migrations:
            logger.info(f"  - Version {migration.version}: {migration.description}")

        for migration in pending_migrations:
            self._apply_migration(migration)

        logger.info(f"Successfully applied {len(pending_migrations)} migration(s)")

    def get_pending_migrations(self) -> list[BaseMigration]:
        """
        Get migrations that need to be applied.

        Returns:
            list[BaseMigration]: List of pending migrations sorted by version

        """
        # Check if schema migration table exists
        table_exists = self._ensure_schema_migration_table_exists()

        if not table_exists:
            # Fresh database - all registered migrations are pending
            logger.info(
                "SCHEMA_MIGRATION table does not exist. This is a fresh database."
            )
            available_migrations = self._get_available_migrations()
            return sorted(available_migrations, key=lambda m: m.version)

        # Get applied migration versions
        applied_versions = self._get_applied_migrations()
        logger.info(
            f"Found {len(applied_versions)} applied migration(s): {sorted(applied_versions)}"
        )

        # Get available migrations
        available_migrations = self._get_available_migrations()

        # Filter to pending migrations
        pending = [
            migration
            for migration in available_migrations
            if migration.version not in applied_versions
        ]

        return sorted(pending, key=lambda m: m.version)

    def _ensure_schema_migration_table_exists(self) -> bool:
        """
        Check if the SCHEMA_MIGRATION table exists.

        Returns:
            bool: True if table exists, False otherwise

        """
        cursor = self.connection.cursor()
        try:
            # Try to query the table
            cursor.execute(
                """
                SELECT COUNT(*)
                FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
                LIMIT 1
            """
            )
            cursor.fetchone()
            return True
        except snowflake.connector.errors.ProgrammingError as e:
            # Table doesn't exist
            error_msg = str(e).lower()
            if "does not exist" in error_msg or "invalid" in error_msg:
                return False
            # Some other error - re-raise
            raise
        finally:
            cursor.close()

    def _get_applied_migrations(self) -> set[int]:
        """
        Get set of applied migration versions.

        Returns:
            set[int]: Set of version numbers that have been successfully applied

        """
        cursor = self.connection.cursor()
        try:
            cursor.execute(
                """
                SELECT VERSION
                FROM SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
                WHERE SUCCESS = TRUE
                ORDER BY VERSION
            """
            )
            results = cursor.fetchall()
            return {row[0] for row in results}
        finally:
            cursor.close()

    def _get_available_migrations(self) -> list[BaseMigration]:
        """
        Get all registered migrations.

        Returns:
            list[BaseMigration]: List of instantiated migration objects

        """
        return [migration_class() for migration_class in REGISTERED_MIGRATIONS]

    def _apply_migration(self, migration: BaseMigration) -> None:
        """
        Apply a single migration and record the result.

        Args:
            migration: Migration to apply

        Raises:
            Exception: If migration fails

        """
        logger.info(f"Applying migration {migration.version}: {migration.description}")

        start_time = time.time()
        success = False
        error_message: str | None = None

        try:
            # Apply the migration
            migration.apply(self.connection)
            self.connection.commit()  # Commit in case auto-commit is not enabled
            success = True
            execution_time_ms = int((time.time() - start_time) * 1000)

            logger.info(
                f"Migration {migration.version} completed in {execution_time_ms}ms"
            )

        except Exception as e:
            execution_time_ms = int((time.time() - start_time) * 1000)
            error_message = str(e)
            logger.error(
                f"Migration {migration.version} failed after {execution_time_ms}ms: {error_message}",
                exc_info=True,
            )
            raise

        finally:
            # Record the migration attempt
            self._record_migration(
                migration.version,
                migration.description,
                execution_time_ms,
                success,
            )

    def _record_migration(
        self, version: int, description: str, execution_time_ms: int, success: bool
    ) -> None:
        """
        Record a migration in the SCHEMA_MIGRATION table.

        Args:
            version: Migration version number
            description: Migration description
            execution_time_ms: Execution time in milliseconds
            success: Whether the migration succeeded

        """
        cursor = self.connection.cursor()
        try:
            cursor.execute(
                """
                INSERT INTO SNOWCONVERT_AI.DATA_MIGRATION.SCHEMA_MIGRATION
                    (VERSION, DESCRIPTION, EXECUTION_TIME_MS, SUCCESS)
                VALUES (%s, %s, %s, %s)
            """,
                (version, description, execution_time_ms, success),
            )
        except Exception as e:
            logger.warning(f"Could not record migration {version}: {str(e)}")
            raise e
        finally:
            cursor.close()
