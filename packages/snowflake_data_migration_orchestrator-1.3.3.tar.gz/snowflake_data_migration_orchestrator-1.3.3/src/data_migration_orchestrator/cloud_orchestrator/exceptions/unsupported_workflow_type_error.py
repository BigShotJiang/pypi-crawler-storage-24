from data_migration_orchestrator.cloud_orchestrator.workflows.workflow_type import (
    WorkflowType,
)


class UnsupportedWorkflowTypeError(Exception):
    """Raised when a workflow type is not supported by any initializer."""

    def __init__(
        self, workflow_type: WorkflowType, supported_types: list[WorkflowType]
    ):
        """
        Initialize the unsupported workflow type error.

        Args:
            workflow_type: The workflow type that is not supported
            supported_types: The list of supported workflow types

        """
        self.workflow_type = workflow_type
        self.supported_types = supported_types
        super().__init__(
            f"Unsupported workflow type: '{workflow_type}'. "
            f"Supported types: {', '.join([wf_type.value for wf_type in supported_types])}"
        )
