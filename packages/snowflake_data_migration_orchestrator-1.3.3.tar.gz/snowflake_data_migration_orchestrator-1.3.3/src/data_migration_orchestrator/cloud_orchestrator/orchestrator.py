import asyncio
import queue
import threading

from asyncio import sleep

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_orchestrator.worker_context import (
    WorkerContext,
    WorkerContextFactory,
)
from data_migration_orchestrator.cloud_orchestrator.workflows.workflow_initializer_factory import (
    WorkflowInitializerFactory,
)
from data_migration_orchestrator.cloud_orchestrator.workflows.workflow_type import (
    WorkflowType,
)
from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationParser,
)
from data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer import (
    DataMigrationWorkflowInitializer,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    TaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from shared.telemetry import (
    FEATURE_ORCHESTRATION,
    TARGET_SNOWFLAKE,
    UNKNOWN_PLATFORM,
    UNKNOWN_SOURCE,
    MigrationTracker,
    categorize_exception,
    log_telemetry_event,
    sanitize_error_message,
)


logger = get_logger("orchestrator")


class Orchestrator:
    """
    Orchestrates the execution of data migration workflows.

    The Orchestrator manages task creation, scheduling, and execution for data migration
    workflows, coordinating between different executor types.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue[TaskPayload],
        warehouse_proxy: Warehouse,
        worker_context_factory: WorkerContextFactory,
        workflow_cycle_interval_seconds: int = 10,
        configuration_parser: ConfigurationParser | None = None,
        max_task_workers: int = 8,
    ):
        """
        Initialize the Orchestrator.

        Args:
            task_queue: The task queue implementation for managing tasks (used by the main thread).
            warehouse_proxy: The warehouse proxy for executing warehouse operations (used by the main thread).
            worker_context_factory: Factory that creates per-thread resources (connection, task queue, warehouse, handler factory).
            workflow_cycle_interval_seconds: The interval in seconds between workflow cycles.
            configuration_parser: Parser for table configurations. If None, a default one is created.
            max_task_workers: Number of persistent worker threads for task execution.

        """
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy
        self.is_running = False
        self.workflow_cycle_interval_seconds = workflow_cycle_interval_seconds
        self.configuration_parser = configuration_parser or ConfigurationParser()
        self.initializer_factory = self._create_workflow_initializer_factory()

        self._worker_context_factory = worker_context_factory
        self._max_task_workers = max_task_workers
        self._work_queue: queue.Queue[Task | None] = queue.Queue()
        self._workers: list[threading.Thread] = []

    async def start(self) -> None:
        """
        Start the Orchestrator.

        Spawns persistent worker threads, then enters the main loop which runs
        until the is_running flag is set to False.
        """
        self.is_running = True
        self._start_workers()
        while self.is_running:
            try:
                await self.execute_workflow_cycle()
            except Exception as e:
                logger.error(f"Error in orchestrator cycle: {e}", exc_info=True)

            await sleep(self.workflow_cycle_interval_seconds)

    async def execute_workflow_cycle(self) -> None:
        """
        Execute a single cycle of the workflow.

        This method performs book-keeping, handles pending workflows, and enqueues
        any unblocked tasks for the worker threads to process. It returns immediately
        after enqueueing -- task execution happens asynchronously in worker threads.
        """
        await self._do_book_keeping_for_tasks()
        await self._handle_workflows()
        unblocked_tasks: list[Task] = await self._check_unblocked_tasks()
        if unblocked_tasks:
            self._enqueue_tasks(unblocked_tasks)

    async def _handle_workflows(self):
        """Handle the workflows."""
        logger.info("Handling workflows")
        pending_workflows = await self.task_queue.get_pending_workflows()
        logger.info("Found %d pending workflows", len(pending_workflows))

        for workflow in pending_workflows:
            logger.info("Creating tasks for workflow %s", workflow.id)

            # Track workflow start
            log_telemetry_event(
                action="workflow_start",
                status="success",
                task_id=str(workflow.id),
                source_type=(
                    workflow.source_platform
                    if hasattr(workflow, "source_platform")
                    else UNKNOWN_PLATFORM
                ),
                feature=FEATURE_ORCHESTRATION,
            )

            try:
                workflow_type: WorkflowType = WorkflowType.from_string(
                    workflow.workflow_type
                )
                logger.info(
                    "Creating tasks for workflow %s of type %s",
                    workflow.id,
                    workflow_type,
                )
                initializer = self.initializer_factory.get_initializer(workflow_type)
                await initializer.create_initial_tasks(workflow)
                logger.info("Successfully created tasks for workflow %s", workflow.id)

                # Track workflow tasks created successfully
                log_telemetry_event(
                    action="workflow_tasks_created",
                    status="success",
                    task_id=str(workflow.id),
                    source_type=(
                        workflow.source_platform
                        if hasattr(workflow, "source_platform")
                        else UNKNOWN_PLATFORM
                    ),
                    feature=FEATURE_ORCHESTRATION,
                )
            except Exception as e:
                logger.error(
                    "Failed to create tasks for workflow %s: %s",
                    workflow.id,
                    e,
                    exc_info=True,
                )

                # Track workflow failure
                log_telemetry_event(
                    action="workflow_tasks_creation_failed",
                    status="error",
                    task_id=str(workflow.id),
                    failure_type=categorize_exception(e),
                    error_msg=sanitize_error_message(str(e)),
                    source_type=(
                        workflow.source_platform
                        if hasattr(workflow, "source_platform")
                        else UNKNOWN_PLATFORM
                    ),
                    feature=FEATURE_ORCHESTRATION,
                )
                continue

        logger.info("Completing workflows...")
        await self.task_queue.complete_workflows()
        logger.info("Completed workflows")

    async def _do_book_keeping_for_tasks(self):
        """
        Do book-keeping for the tasks.

        1. Expire leases for tasks that have exceeded their lease duration.
        2. Complete tasks that are associated with queries running in a warehouse.
        3. Unblock tasks for which all predecessor tasks have been completed.
        """
        try:
            logger.info("Expiring leases...")
            await self.task_queue.expire_leases()

            logger.info("Refreshing warehouse tasks...")
            await self.task_queue.refresh_warehouse_tasks()

            logger.info("Unblocking tasks...")
            await self.task_queue.unblock_tasks()

        except Exception as e:
            logger.error(f"Error during task book-keeping: {e}", exc_info=True)

    async def _check_unblocked_tasks(self) -> list[Task]:
        """
        Check which tasks have been unblocked since the last execution.

        This queries all tasks in the workflow that are in PENDING state and have
        executor=ORCHESTRATOR, which are the unblocked tasks.
        """
        return await self.task_queue.get_tasks()

    def _enqueue_tasks(self, tasks: list[Task]) -> None:
        """Place unblocked tasks onto the shared work queue for worker threads."""
        for task in tasks:
            self._work_queue.put(task)
        logger.info("Enqueued %d task(s) for worker threads", len(tasks))

    # ------------------------------------------------------------------
    # Worker thread methods (run outside the async event loop)
    # ------------------------------------------------------------------

    def _task_worker(self) -> None:
        """
        Execute worker loop in a dedicated thread.

        Creates its own Snowflake connection and dependent resources on startup,
        then blocks on the shared work queue waiting for tasks to process.
        Exits when it receives a ``None`` sentinel value.
        """
        context: WorkerContext = self._worker_context_factory()
        self.task_queue.register_thread_connection(context.connection)
        try:
            while True:
                task = self._work_queue.get()
                if task is None:
                    self._work_queue.task_done()
                    break
                try:
                    asyncio.run(self._execute_task_with_context(task, context))
                except Exception as e:
                    logger.error(f"Worker error on task {task.id}: {e}", exc_info=True)
                finally:
                    self._work_queue.task_done()
        finally:
            try:
                context.connection.close()
            except Exception:
                logger.warning("Failed to close worker connection", exc_info=True)

    async def _execute_task_with_context(self, task: Task, ctx: WorkerContext) -> None:
        """Execute a single task using the worker's own resources."""
        try:
            payload_kind = task.payload.kind

            if payload_kind in (
                TaskPayloadKind.DATA_MOVEMENT,
                TaskPayloadKind.SNOWFLAKE_QUERY,
            ):
                raise Exception(
                    f"{payload_kind} tasks should not be handled by the Orchestrator"
                )

            with MigrationTracker(
                task_id=str(task.id),
                source_type=(
                    task.payload.source_type
                    if hasattr(task.payload, "source_type")
                    else UNKNOWN_SOURCE
                ),
                target_type=TARGET_SNOWFLAKE,
                feature=FEATURE_ORCHESTRATION,
            ) as tracker:
                logger.info(f"Handling task {task.id}: {task.task_name}")
                handler = ctx.handler_factory.get_handler(payload_kind)
                await handler.handle(task)
                logger.info(f"Completed task {task.id}")
                tracker.set_metrics(0, 0)
        except Exception as e:
            error_message = self._build_detailed_error_message(e)
            logger.error(
                f"ERROR handling task {task.id}: {error_message}",
                exc_info=True,
            )
            if task.id is not None:
                await ctx.task_queue.fail_task(
                    ExecutorType.ORCHESTRATOR.value, task.id, error_message
                )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _start_workers(self) -> None:
        """Spawn persistent worker threads for task execution."""
        for i in range(self._max_task_workers):
            thread = threading.Thread(
                target=self._task_worker,
                name=f"orchestrator-worker-{i}",
                daemon=True,
            )
            thread.start()
            self._workers.append(thread)

    def stop(self) -> None:
        """Signal all worker threads to shut down and wait for them to finish."""
        self.is_running = False
        for _ in self._workers:
            self._work_queue.put(None)
        for worker in self._workers:
            worker.join(timeout=30)

    def _build_detailed_error_message(self, exception: Exception) -> str:
        """
        Build a detailed error message including exception type and message.

        Args:
            exception: The exception to extract details from

        Returns:
            A formatted error message with complete exception details

        """
        exception_type = type(exception).__name__
        exception_message = str(exception)
        return f"{exception_type}: {exception_message}"

    def _create_workflow_initializer_factory(self) -> WorkflowInitializerFactory:
        """
        Create a workflow initializer factory.

        Returns:
            A workflow initializer factory

        """
        factory = WorkflowInitializerFactory()
        factory.register_initializer(
            WorkflowType.DATA_MIGRATION,
            DataMigrationWorkflowInitializer(
                task_queue=self.task_queue,
                warehouse_proxy=self.warehouse_proxy,
                configuration_parser=self.configuration_parser,
            ),
        )
        return factory
