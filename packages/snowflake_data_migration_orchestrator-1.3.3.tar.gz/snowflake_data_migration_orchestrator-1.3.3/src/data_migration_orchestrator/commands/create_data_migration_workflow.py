"""
Command to create a Data Migration Workflow.

Reads a JSON configuration file, validates it using the same schema
the workflow initializer uses, and inserts a row into the WORKFLOW table.
"""

import argparse
import json
import sys

from pathlib import Path

import snowflake.connector

from data_migration_orchestrator.cloud_core.connection_manager import (
    get_connection_config,
)
from data_migration_orchestrator.commands import CREATE_DATA_MIGRATION_WORKFLOW
from data_migration_orchestrator.data_migration_cloud.config.workflow_configuration_schema import (
    validate_workflow_configuration,
)
from data_migration_orchestrator.utils.sql_utils import escape_sql_string


def register_subparser(subparsers: argparse._SubParsersAction) -> None:
    """Register the ``create-data-migration-workflow`` subcommand."""
    create_parser = subparsers.add_parser(
        CREATE_DATA_MIGRATION_WORKFLOW,
        help="Validate a workflow config and insert it into the WORKFLOW table",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m data_migration_orchestrator.main create-data-migration-workflow config.json
  python -m data_migration_orchestrator.main create-data-migration-workflow config.json --connection-name my_conn
  python -m data_migration_orchestrator.main create-data-migration-workflow config.json --name my_workflow --source-platform redshift
        """,
    )
    create_parser.set_defaults(func=create_data_migration_workflow)

    create_parser.add_argument(
        "config_file",
        type=Path,
        help="Path to the JSON workflow configuration file",
    )
    create_parser.add_argument(
        "--connection-name",
        type=str,
        default=None,
        help="Snowflake connection name (uses default from env vars if omitted)",
    )
    create_parser.add_argument(
        "--name",
        type=str,
        default="MY_WORKFLOW",
        help="Workflow name (default: MY_WORKFLOW)",
    )
    create_parser.add_argument(
        "--source-platform",
        type=str,
        default="sqlserver",
        help="Source platform (default: sqlserver)",
    )


_TARGET_CLOUD_TYPE = "snowflake:stage"
_TARGET_CLOUD_STAGE_NAME = "@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS"
_SCHEMA_VERSION = "1.0"

_INSERT_WORKFLOW_SQL = """\
INSERT INTO SNOWCONVERT_AI.DATA_MIGRATION.WORKFLOW(
    NAME,
    WORKFLOW_TYPE,
    SOURCE_PLATFORM,
    TARGET_CLOUD_TYPE,
    TARGET_CLOUD_STAGE_NAME,
    TARGET_CLOUD_URL,
    SCHEMA_VERSION,
    INITIATOR_ID,
    CONFIGURATION,
    AFFINITY
)
SELECT
    '{name}',
    'data-migration',
    '{source_platform}',
    '{target_cloud_type}',
    '{target_cloud_stage_name}',
    '',
    '{schema_version}',
    '',
    PARSE_JSON('{configuration}'),
    {affinity}
"""


def _read_config_file(config_file: Path) -> dict:
    """Read and parse a JSON configuration file."""
    if not config_file.is_file():
        print(f"Error: configuration file not found: {config_file}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(config_file) as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        print(f"Error: invalid JSON in {config_file}: {e}", file=sys.stderr)
        sys.exit(1)


def _connect(connection_name: str | None) -> snowflake.connector.SnowflakeConnection:
    """
    Create a Snowflake connection.

    When *connection_name* is given it is used directly.  Otherwise the
    standard environment-variable-based configuration is used.
    """
    if connection_name is not None:
        print(f"Using Snowflake connection: {connection_name}")
        return snowflake.connector.connect(connection_name=connection_name)

    config = get_connection_config()
    display_name = config.get("connection_name") or config.get("account", "default")
    print(f"Using Snowflake connection: {display_name}")
    return snowflake.connector.connect(**config)


def _build_insert_sql(
    *,
    name: str,
    source_platform: str,
    configuration_json: str,
    affinity: str | None,
) -> str:
    return _INSERT_WORKFLOW_SQL.format(
        name=escape_sql_string(name),
        source_platform=escape_sql_string(source_platform),
        target_cloud_type=_TARGET_CLOUD_TYPE,
        target_cloud_stage_name=_TARGET_CLOUD_STAGE_NAME,
        schema_version=_SCHEMA_VERSION,
        configuration=escape_sql_string(configuration_json),
        affinity=f"'{escape_sql_string(affinity)}'" if affinity else "NULL",
    )


def create_data_migration_workflow(args: argparse.Namespace) -> None:
    """Entry point invoked by the CLI subcommand."""
    config = _read_config_file(args.config_file)

    validated = validate_workflow_configuration(config)
    print("Workflow configuration is valid.")

    affinity = validated.affinity
    configuration_json = json.dumps(config)

    sql = _build_insert_sql(
        name=args.name,
        source_platform=args.source_platform,
        configuration_json=configuration_json,
        affinity=affinity,
    )

    connection = _connect(args.connection_name)
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(sql)
            print("Workflow created successfully.")
        finally:
            cursor.close()
    finally:
        connection.close()
