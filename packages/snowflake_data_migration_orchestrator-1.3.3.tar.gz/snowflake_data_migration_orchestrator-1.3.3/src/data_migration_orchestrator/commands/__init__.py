"""CLI commands for the data migration orchestrator."""

START = "start"
CREATE_DATA_MIGRATION_WORKFLOW = "create-data-migration-workflow"
