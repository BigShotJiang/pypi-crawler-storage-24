"""
UNLOAD Strategy Infrastructure Setup.

This script contains example code for setting up a external stage pointin to an S3 bucket, which is required for the UNLOAD strategy.
This code can be used in the future as reference to implement a command that does this automatically given the appropriate configuration.
The UNLOAD strategy requires:
1. An S3 bucket where Redshift can write data
2. An IAM role that Redshift can assume to write to S3
3. A Snowflake Storage Integration for S3 access
"""

# =============================================================================
# Example SQL: Snowflake Storage Integration Setup
# =============================================================================

STORAGE_INTEGRATION_SQL = """
-- Create a storage integration for S3 access
-- This requires ACCOUNTADMIN privileges

CREATE OR REPLACE STORAGE INTEGRATION {integration_name}
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = 'S3'
  STORAGE_AWS_ROLE_ARN = '{snowflake_iam_role_arn}'
  ENABLED = TRUE
  STORAGE_ALLOWED_LOCATIONS = ('s3://{s3_bucket}/');

-- After creation, describe to get the AWS IAM user and external ID
-- These are needed to configure the trust policy on the IAM role
DESC STORAGE INTEGRATION {integration_name};

-- The output includes:
-- STORAGE_AWS_IAM_USER_ARN: The Snowflake IAM user ARN to trust
-- STORAGE_AWS_EXTERNAL_ID: The external ID for the trust policy
"""

# =============================================================================
# Example SQL: Snowflake External Stage Setup
# =============================================================================

EXTERNAL_STAGE_SQL = """
-- Create an external stage pointing to the S3 bucket
-- This stage is what the orchestrator uses to read UNLOAD output

CREATE OR REPLACE STAGE {database}.{schema}.{stage_name}
  URL = 's3://{s3_bucket}/'
  STORAGE_INTEGRATION = {integration_name}
  FILE_FORMAT = (TYPE = PARQUET);

-- Verify the stage
LIST @{database}.{schema}.{stage_name};
"""

# =============================================================================
# Example: AWS IAM Role Trust Policy for Snowflake
# =============================================================================

SNOWFLAKE_TRUST_POLICY = """
{{
  "Version": "2012-10-17",
  "Statement": [
    {{
      "Effect": "Allow",
      "Principal": {{
        "AWS": "{snowflake_iam_user_arn}"
      }},
      "Action": "sts:AssumeRole",
      "Condition": {{
        "StringEquals": {{
          "sts:ExternalId": "{snowflake_external_id}"
        }}
      }}
    }}
  ]
}}
"""

# =============================================================================
# Example: AWS IAM Role Trust Policy for Redshift UNLOAD
# =============================================================================

REDSHIFT_TRUST_POLICY = """
{{
  "Version": "2012-10-17",
  "Statement": [
    {{
      "Effect": "Allow",
      "Principal": {{
        "Service": "redshift.amazonaws.com"
      }},
      "Action": "sts:AssumeRole"
    }}
  ]
}}
"""

# =============================================================================
# Example: AWS IAM Policy for S3 Access
# =============================================================================

S3_ACCESS_POLICY = """
{{
  "Version": "2012-10-17",
  "Statement": [
    {{
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:GetObjectVersion",
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:ListBucket",
        "s3:GetBucketLocation"
      ],
      "Resource": [
        "arn:aws:s3:::{s3_bucket}",
        "arn:aws:s3:::{s3_bucket}/*"
      ]
    }}
  ]
}}
"""


def build_unload_query_reference(
    select_query: str,
    s3_path: str,
    iam_role: str,
    file_format: str = "parquet",
    max_file_size_mb: int = 256,
) -> str:
    """
    Build a Redshift UNLOAD query.

    This is currently done in task_chain_creator.py but should be moved to the DEA.
    The DEA should have the s3_path base, iam_role, file_format, max_file_size_mb
    in its configuration, and only receive the select_query and relative path from
    the orchestrator.

    Args:
        select_query: The SELECT query to unload
        s3_path: Full S3 path for output (e.g., s3://bucket/prefix/workflow/table/partition/)
        iam_role: IAM role ARN for Redshift to assume
        file_format: Output format (parquet or csv)
        max_file_size_mb: Maximum file size in MB

    Returns:
        The complete UNLOAD SQL statement

    """
    # This is from redshift/query_builder.py
    format_options = ""
    if file_format.lower() == "parquet":
        format_options = "FORMAT AS PARQUET"
    else:
        format_options = "FORMAT AS CSV DELIMITER ',' ADDQUOTES HEADER"

    return f"""UNLOAD ('{select_query.replace("'", "''")}')
TO '{s3_path}'
IAM_ROLE '{iam_role}'
{format_options}
ALLOWOVERWRITE
PARALLEL ON
MAXFILESIZE {max_file_size_mb} MB"""


def build_s3_path_for_partition(
    s3_bucket: str,
    s3_prefix: str,
    workflow_id: int,
    table_metadata_id: int,
    partition_index: int,
) -> str:
    """
    Build the S3 path for a partition's data.

    This path structure must match what the orchestrator expects when
    computing the Snowflake external stage path.

    Path structure: s3://{bucket}/{prefix}/{workflow_id}/{table_id}/partition_{N}/

    Args:
        s3_bucket: S3 bucket (e.g., "migrations-unload-bucket/e2e-test")
        s3_prefix: Path prefix within bucket (e.g., "data-migration")
        workflow_id: The workflow ID
        table_metadata_id: The table metadata ID
        partition_index: The partition index

    Returns:
        Full S3 path for the partition

    """
    s3_bucket = s3_bucket.rstrip("/")
    s3_prefix = s3_prefix.strip("/")

    path_parts = [s3_bucket]
    if s3_prefix:
        path_parts.append(s3_prefix)
    path_parts.extend(
        [
            str(workflow_id),
            str(table_metadata_id),
            f"partition_{partition_index}",
        ]
    )

    return f"s3://{'/'.join(path_parts)}/"
