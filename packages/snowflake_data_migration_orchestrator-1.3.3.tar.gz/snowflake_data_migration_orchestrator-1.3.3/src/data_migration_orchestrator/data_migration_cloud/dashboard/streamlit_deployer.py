"""
Streamlit Dashboard Deployer.

Handles automatic deployment of the Streamlit dashboard to Snowflake
when the orchestrator starts.
"""

import os

from pathlib import Path

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.snowflake_account import QUALIFIED_SCHEMA


logger = get_logger("streamlit_deployer")

# Configuration - can be overridden via environment variables
STREAMLIT_APP_NAME = os.environ.get("STREAMLIT_APP_NAME", "DATA_MIGRATION_DASHBOARD")
STREAMLIT_STAGE_NAME = os.environ.get(
    "STREAMLIT_STAGE_NAME", "STREAMLIT_DASHBOARD_STAGE"
)
QUALIFIED_STREAMLIT_STAGE_NAME = f"{QUALIFIED_SCHEMA}.{STREAMLIT_STAGE_NAME}"
QUALIFIED_STREAMLIT_APP_NAME = f"{QUALIFIED_SCHEMA}.{STREAMLIT_APP_NAME}"


def deploy_streamlit_if_needed(
    connection: snowflake.connector.SnowflakeConnection,
) -> None:
    """
    Deploy the Streamlit dashboard if it doesn't already exist.

    This function is idempotent - it checks if the Streamlit app exists
    before attempting to create it.

    Args:
        connection: Active Snowflake connection

    """
    logger.info("Checking if Streamlit dashboard deployment is needed...")

    if _streamlit_exists(connection):
        logger.info(
            f"Streamlit app '{STREAMLIT_APP_NAME}' already exists, skipping deployment"
        )
        return

    logger.info(f"Streamlit app '{STREAMLIT_APP_NAME}' not found, deploying...")

    try:
        _create_stage_if_needed(connection)
        _upload_app_file(connection)
        _create_streamlit_app(connection)
        logger.info(f"Streamlit app '{STREAMLIT_APP_NAME}' deployed successfully")
    except Exception as e:
        logger.error(f"Failed to deploy Streamlit app: {e}")
        raise


def _streamlit_exists(connection: snowflake.connector.SnowflakeConnection) -> bool:
    """Check if the Streamlit app already exists."""
    cursor = connection.cursor()
    try:
        # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
        # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
        cursor.execute(
            f"SHOW STREAMLITS LIKE '{STREAMLIT_APP_NAME}' IN SCHEMA {QUALIFIED_SCHEMA}"
        )
        results = cursor.fetchall()
        return len(results) > 0
    except Exception as e:
        logger.warning(f"Error checking for existing Streamlit app: {e}")
        return False
    finally:
        cursor.close()


def _create_stage_if_needed(
    connection: snowflake.connector.SnowflakeConnection,
) -> None:
    """Create the stage for Streamlit app files if it doesn't exist."""
    cursor = connection.cursor()
    try:
        # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
        # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
        cursor.execute(f"CREATE STAGE IF NOT EXISTS {QUALIFIED_STREAMLIT_STAGE_NAME}")
        logger.info(f"Stage '{STREAMLIT_STAGE_NAME}' ready")
    finally:
        cursor.close()


def _upload_app_file(connection: snowflake.connector.SnowflakeConnection) -> None:
    """Upload the Streamlit app.py file to the stage."""
    # Get the path to the app.py file in this package
    app_file_path = Path(__file__).parent / "app.py"

    if not app_file_path.exists():
        raise FileNotFoundError(f"Streamlit app file not found: {app_file_path}")

    cursor = connection.cursor()
    try:
        # Upload the file to the stage
        # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
        # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
        cursor.execute(
            f"PUT 'file://{app_file_path.as_posix()}' @{QUALIFIED_STREAMLIT_STAGE_NAME} AUTO_COMPRESS=FALSE OVERWRITE=TRUE"
        )
        logger.info(f"Uploaded app.py to stage '{STREAMLIT_STAGE_NAME}'")
    finally:
        cursor.close()


def _create_streamlit_app(connection: snowflake.connector.SnowflakeConnection) -> None:
    """Create the Streamlit app in Snowflake."""
    cursor = connection.cursor()
    try:
        # Get current warehouse for the Streamlit app
        cursor.execute("SELECT CURRENT_WAREHOUSE()")
        result = cursor.fetchone()
        if not result or not result[0]:
            raise RuntimeError(
                "No active warehouse found. Please ensure a warehouse is set "
                "on the Snowflake connection."
            )
        warehouse = result[0]

        create_sql = f"""
        CREATE STREAMLIT IF NOT EXISTS {QUALIFIED_STREAMLIT_APP_NAME}
        ROOT_LOCATION = '@{QUALIFIED_STREAMLIT_STAGE_NAME}'
        MAIN_FILE = 'app.py'
        QUERY_WAREHOUSE = {warehouse}
        """

        # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
        # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
        cursor.execute(create_sql)
        logger.info(f"Created Streamlit app '{STREAMLIT_APP_NAME}'")
    finally:
        cursor.close()
