"""Dashboard module for Streamlit deployment."""

from data_migration_orchestrator.data_migration_cloud.dashboard.streamlit_deployer import (
    deploy_streamlit_if_needed,
)


__all__ = ["deploy_streamlit_if_needed"]
