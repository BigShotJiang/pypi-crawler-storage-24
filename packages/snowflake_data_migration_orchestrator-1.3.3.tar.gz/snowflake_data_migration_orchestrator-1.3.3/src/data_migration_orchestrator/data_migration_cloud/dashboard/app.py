"""
Data Migration Dashboard.

Monitor the progress of cloud data migration workflows.
Designed for Streamlit in Snowflake (SiS).
"""

import pandas as pd
import streamlit as st

from snowflake.snowpark.context import get_active_session


st.set_page_config(
    page_title="Data Migration Dashboard",
    page_icon="🔄",
    layout="wide",
)

# Get active Snowflake session (SiS provides this automatically)
session = get_active_session()


def run_query(sql: str) -> pd.DataFrame:
    """Execute a query and return results as a pandas DataFrame."""
    return session.sql(sql).to_pandas()


@st.cache_data(ttl=60)
def get_workflows():
    """Fetch list of available workflows."""
    try:
        df = run_query(
            """
            SELECT DISTINCT WORKFLOW_ID
            FROM SNOWCONVERT_AI.DATA_MIGRATION.TABLE_PROGRESS
            ORDER BY WORKFLOW_ID DESC
        """
        )
        return df["WORKFLOW_ID"].tolist() if len(df) > 0 else []
    except Exception:
        return []


@st.cache_data(ttl=30)
def get_overview_metrics(workflow_id: int | None = None):
    """Fetch high-level migration metrics, optionally filtered by workflow."""
    try:
        where_clause = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        df = run_query(
            f"""
            SELECT
                COUNT(DISTINCT WORKFLOW_ID) as total_workflows,
                COUNT(DISTINCT TABLE_ID) as total_tables,
                COALESCE(SUM(TOTAL_PARTITIONS), 0) as total_partitions,
                COALESCE(SUM(LOADED_PARTITIONS), 0) as loaded_partitions,
                COALESCE(SUM(FAILED_PARTITIONS), 0) as failed_partitions,
                COALESCE(SUM(PARTITIONS_IN_EXTRACTION_PHASE), 0) as extracting,
                COALESCE(SUM(PARTITIONS_IN_LOADING_PHASE), 0) as loading
            FROM SNOWCONVERT_AI.DATA_MIGRATION.TABLE_PROGRESS
            {where_clause}
        """
        )
        return df.iloc[0] if len(df) > 0 else None
    except Exception:
        return None


@st.cache_data(ttl=30)
def get_workflow_summary():
    """Fetch summary statistics per workflow."""
    try:
        return run_query(
            """
            SELECT
                WORKFLOW_ID,
                COUNT(DISTINCT TABLE_ID) as TABLES,
                COALESCE(SUM(TOTAL_PARTITIONS), 0) as TOTAL_PARTITIONS,
                COALESCE(SUM(LOADED_PARTITIONS), 0) as LOADED,
                COALESCE(SUM(FAILED_PARTITIONS), 0) as FAILED,
                COALESCE(SUM(PARTITIONS_IN_EXTRACTION_PHASE), 0)
                + COALESCE(SUM(PARTITIONS_IN_LOADING_PHASE), 0) as IN_PROGRESS,
                CASE
                    WHEN COALESCE(SUM(TOTAL_PARTITIONS), 0) > 0
                    THEN ROUND(COALESCE(SUM(LOADED_PARTITIONS), 0) * 100.0 / SUM(TOTAL_PARTITIONS), 1)
                    ELSE 0
                END as PROGRESS_PCT
            FROM SNOWCONVERT_AI.DATA_MIGRATION.TABLE_PROGRESS
            GROUP BY WORKFLOW_ID
            ORDER BY WORKFLOW_ID DESC
        """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_table_progress(workflow_id: int = None):
    """Fetch table-level progress data, optionally filtered by workflow."""
    try:
        where_clause = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                TABLE_ID,
                TABLE_NAME,
                HAS_BEEN_PREPROCESSED,
                COALESCE(TOTAL_PARTITIONS, 0) as TOTAL_PARTITIONS,
                COALESCE(PARTITIONS_IN_EXTRACTION_PHASE, 0) as PARTITIONS_IN_EXTRACTION_PHASE,
                COALESCE(PARTITIONS_IN_LOADING_PHASE, 0) as PARTITIONS_IN_LOADING_PHASE,
                COALESCE(LOADED_PARTITIONS, 0) as LOADED_PARTITIONS,
                COALESCE(FAILED_PARTITIONS, 0) as FAILED_PARTITIONS,
                EXAMPLE_ERROR_MESSAGE
            FROM SNOWCONVERT_AI.DATA_MIGRATION.TABLE_PROGRESS_WITH_EXAMPLE_ERROR
            {where_clause}
            ORDER BY
                CASE WHEN COALESCE(FAILED_PARTITIONS, 0) > 0 THEN 0 ELSE 1 END,
                TABLE_NAME
        """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_error_logs(workflow_id: int | None = None, table_name: str | None = None):
    """Fetch error logs, optionally filtered by workflow and/or table."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"WORKFLOW_ID = {workflow_id}")
        if table_name and table_name != "All tables":
            safe_table_name = table_name.replace("'", "''")
            conditions.append(f"TABLE_NAME = '{safe_table_name}'")

        where_clause = "WHERE " + " AND ".join(conditions) if conditions else ""

        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                TABLE_NAME,
                PARTITION_NUMBER,
                COALESCE(PARTITION_ROWS, 0) as PARTITION_ROWS,
                TASK_NAME,
                TASK_START_TIME,
                TASK_END_TIME,
                LAST_ERROR_MESSAGE
            FROM SNOWCONVERT_AI.DATA_MIGRATION.DATA_MIGRATION_ERROR
            {where_clause}
            ORDER BY TASK_START_TIME DESC
        """
        )
    except Exception:
        return pd.DataFrame()


# Title
st.title("🔄 Data migration dashboard")

# Sidebar with workflow filter and refresh
with st.sidebar:
    st.header("🔍 Filters")

    if st.button("🔄 Refresh data"):
        st.cache_data.clear()
        st.experimental_rerun()

    st.caption("Data refreshes every 30 seconds")

    # Workflow filter
    workflows = get_workflows()
    workflow_options = ["All workflows"] + [str(w) for w in workflows if w is not None]

    selected_workflow_str = st.selectbox(
        "Workflow",
        options=workflow_options,
        index=0,
        help="Filter dashboard by a specific workflow",
        disabled=len(workflows) == 0,
    )

    selected_workflow = (
        None if selected_workflow_str == "All workflows" else int(selected_workflow_str)
    )

    if len(workflows) == 0:
        st.warning("No workflows found in the database.")

# Main content tabs
tab_overview, tab_workflows, tab_tables, tab_errors = st.tabs(
    [
        "📊 Overview",
        "🔀 Workflows",
        "📋 Table progress",
        "⚠️ Error logs",
    ]
)

# Overview Dashboard Tab
with tab_overview:
    metrics = get_overview_metrics(selected_workflow)

    if metrics is not None:
        total_workflows = int(metrics["TOTAL_WORKFLOWS"] or 0)
        total_tables = int(metrics["TOTAL_TABLES"] or 0)
        total_partitions = int(metrics["TOTAL_PARTITIONS"] or 0)
        loaded = int(metrics["LOADED_PARTITIONS"] or 0)
        failed = int(metrics["FAILED_PARTITIONS"] or 0)
        extracting = int(metrics["EXTRACTING"] or 0)
        loading = int(metrics["LOADING"] or 0)

        progress_pct = (loaded / total_partitions * 100) if total_partitions > 0 else 0
        in_progress = extracting + loading

        # Show which workflow is selected
        if selected_workflow:
            st.info(
                f"Showing data for **Workflow {selected_workflow}**",
            )

        # KPI Row
        cols = st.columns(6 if not selected_workflow else 5)
        col_idx = 0
        if not selected_workflow:
            with cols[col_idx]:
                st.metric("Workflows", f"{total_workflows:,}")
            col_idx += 1
        with cols[col_idx]:
            st.metric("Tables", f"{total_tables:,}")
        with cols[col_idx + 1]:
            st.metric("Total partitions", f"{total_partitions:,}")
        with cols[col_idx + 2]:
            st.metric(
                "Loaded",
                f"{loaded:,}",
                delta=f"{progress_pct:.1f}% complete",
            )
        with cols[col_idx + 3]:
            st.metric(
                "In progress",
                f"{in_progress:,}",
                delta=f"{extracting:,} extracting, {loading:,} loading",
                delta_color="off",
            )
        with cols[col_idx + 4]:
            st.metric(
                "Failed",
                f"{failed:,}",
                delta="needs attention" if failed > 0 else None,
                delta_color="inverse",
            )

        # Progress visualization
        col1, col2 = st.columns(2)

        with col1:
            with st.container():
                st.subheader("Overall progress")
                if total_partitions > 0:
                    st.progress(loaded / total_partitions)
                    st.caption(f"{loaded:,} of {total_partitions:,} partitions loaded")
                else:
                    st.info("No partitions found")

        with col2:
            with st.container():
                st.subheader("Partition status breakdown")
                status_data = pd.DataFrame(
                    {
                        "Status": ["Loaded", "Extracting", "Loading", "Failed"],
                        "Count": [loaded, extracting, loading, failed],
                    }
                )
                status_data = status_data[status_data["Count"] > 0]
                if len(status_data) > 0:
                    st.bar_chart(status_data.set_index("Status"))
                else:
                    st.info("No partition data available")
    else:
        st.warning(
            "No migration data available. Ensure the migration workflow is running."
        )

# Workflows Tab
with tab_workflows:
    st.subheader("Workflow summary")

    workflow_df = get_workflow_summary()

    if len(workflow_df) > 0:
        # Workflow KPIs
        total_wf = len(workflow_df)
        completed_wf = len(workflow_df[workflow_df["PROGRESS_PCT"] == 100])
        failed_wf = len(workflow_df[workflow_df["FAILED"] > 0])

        cols = st.columns(4)
        with cols[0]:
            st.metric("Total workflows", total_wf)
        with cols[1]:
            st.metric("Completed", completed_wf)
        with cols[2]:
            st.metric(
                "With errors",
                failed_wf,
                delta="needs attention" if failed_wf > 0 else None,
                delta_color="inverse",
            )
        with cols[3]:
            st.metric("In progress", total_wf - completed_wf)

        # Workflow table with progress bars
        st.dataframe(
            workflow_df,
            use_container_width=True,
        )

        # Workflow comparison chart
        with st.container():
            st.subheader("Workflow progress comparison")
            if len(workflow_df) > 0:
                chart_df = workflow_df[
                    ["WORKFLOW_ID", "LOADED", "FAILED", "IN_PROGRESS"]
                ].copy()
                chart_df["WORKFLOW_ID"] = chart_df["WORKFLOW_ID"].astype(str)
                chart_df = chart_df.set_index("WORKFLOW_ID")
                st.bar_chart(chart_df)
            else:
                st.info("No workflow data to display.")
    else:
        st.info("No workflow data available.")

# Table Progress Tab
with tab_tables:
    if selected_workflow:
        st.info(
            f"Showing tables for **Workflow {selected_workflow}**",
        )

    table_df = get_table_progress(selected_workflow)

    if len(table_df) > 0:
        # Summary stats
        tables_with_errors = len(table_df[table_df["FAILED_PARTITIONS"] > 0])
        tables_complete = len(
            table_df[
                (table_df["LOADED_PARTITIONS"] == table_df["TOTAL_PARTITIONS"])
                & (table_df["TOTAL_PARTITIONS"] > 0)
            ]
        )

        cols = st.columns(3)
        with cols[0]:
            st.metric("Tables with errors", tables_with_errors)
        with cols[1]:
            st.metric("Tables complete", tables_complete)
        with cols[2]:
            st.metric(
                "Tables in progress",
                len(table_df) - tables_complete - tables_with_errors,
            )

        # Search filter
        search = st.text_input(
            "Search tables",
            placeholder="Filter by table name...",
            label_visibility="collapsed",
        )

        filtered_df = table_df
        if search:
            filtered_df = table_df[
                table_df["TABLE_NAME"].str.contains(search, case=False, na=False)
            ]

        # Add computed columns for display
        if len(filtered_df) > 0:
            display_df = filtered_df.copy()
            display_df["PROGRESS"] = display_df.apply(
                lambda r: (
                    (r["LOADED_PARTITIONS"] / r["TOTAL_PARTITIONS"] * 100)
                    if r["TOTAL_PARTITIONS"] > 0
                    else 0
                ),
                axis=1,
            )
            display_df["STATUS"] = display_df.apply(
                lambda r: (
                    "Failed"
                    if r["FAILED_PARTITIONS"] > 0
                    else (
                        "Complete"
                        if r["LOADED_PARTITIONS"] == r["TOTAL_PARTITIONS"]
                        and r["TOTAL_PARTITIONS"] > 0
                        else "In progress"
                    )
                ),
                axis=1,
            )
        else:
            display_df = pd.DataFrame()

        # Display dataframe with progress bars
        if len(display_df) > 0:
            st.dataframe(
                display_df,
                use_container_width=True,
            )
        else:
            st.info("No tables match the current filter.")
    else:
        st.info("No table progress data available.")

# Error Logs Tab
with tab_errors:
    if selected_workflow:
        st.info(
            f"Showing errors for **Workflow {selected_workflow}**",
        )

    # Get unique table names for filter (respecting workflow filter)
    table_df = get_table_progress(selected_workflow)
    table_names = ["All tables"]
    if len(table_df) > 0 and "TABLE_NAME" in table_df.columns:
        unique_tables = table_df["TABLE_NAME"].dropna().unique().tolist()
        if unique_tables:
            table_names = table_names + sorted(unique_tables)

    # Table filter
    selected_table = st.selectbox(
        "Filter by table", options=table_names, label_visibility="collapsed"
    )

    error_df = get_error_logs(selected_workflow, selected_table)

    if len(error_df) > 0:
        st.caption(f"Showing {len(error_df):,} error records")

        st.dataframe(
            error_df,
            use_container_width=True,
        )

        # Error message detail expander
        if st.checkbox("Show full error details"):
            for _idx, row in error_df.iterrows():
                with st.expander(
                    f"{row['TABLE_NAME']} - Partition {row['PARTITION_NUMBER']}"
                ):
                    st.code(row["LAST_ERROR_MESSAGE"], language=None)
    else:
        st.success("No errors found. All partitions are processing successfully.")
