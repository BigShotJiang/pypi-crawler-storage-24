from dataclasses import dataclass, field
from typing import Any

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.constants.priorities import (
    PRIORITY_FOR_COPY_INTO_TASKS,
    compute_priority_for_extraction_task,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    DEFAULT_INTERNAL_STAGE,
)
from data_migration_orchestrator.data_migration_cloud.exceptions.unsupported_extraction_strategy_error import (
    UnsupportedExtractionStrategyError,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.scope import (
    build_partition_extraction_scope,
    build_partition_loading_scope,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundary,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    ChecksumSyncData,
    SyncData,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    ClearPartitionDataPayload,
    DataMovementTaskPayload,
    ProcessChecksumResultPayload,
    ProcessStagedDataTaskPayload,
    TargetType,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    relative_path_for_partition_data,
    stage_path_for_partition_data,
)


@dataclass
class PartitionInput:
    """Unified input for creating partition extraction chains."""

    partition_index: int
    partition_metadata_id: int
    partition_boundary: PartitionBoundary
    sync_data: SyncData | None


@dataclass(frozen=True)
class TaskChainContext:
    """Context for building task chains for a given table based on the provided context."""

    workflow_id: int
    """
    The ID of the workflow
    """

    table_metadata_id: int
    """
    The ID of the table metadata
    """

    table_config: TableConfiguration
    """
    The configuration of the table
    """

    source_schema: list[dict[str, str]]
    """
    The schema of the source table
    """

    suggested_batch_size: int | None
    """
    The suggested batch size for the table
    """

    strategy_config: dict[str, Any] = field(default_factory=dict)
    """
    Strategy-specific configuration fetched from the WORKFLOW table via
    WorkflowConfigService (e.g., {"s3_bucket": ..., "iam_role_arn": ...}
    for the UNLOAD strategy).
    """

    external_stage_location: str | None = None
    """
    External stage location for strategies that write directly to S3 (e.g., UNLOAD).
    When set, this is the Snowflake external stage path that maps to the S3 bucket.
    Example: @MY_DB.MY_SCHEMA.S3_STAGE/
    """

    def get_strategy_config_value(self, key: str, default: Any = None) -> Any:
        """
        Get a value from strategy-specific configuration.

        Args:
            key: Configuration key
            default: Default value if key not found

        Returns:
            Configuration value or default

        """
        if self.strategy_config is None:
            return default
        return self.strategy_config.get(key, default)


class TaskChainCreator:
    """Service responsible for building task chains for a given table based on the provided context."""

    def __init__(
        self,
        platform: BasePlatform,
        task_queue: BaseTaskQueue,
        task_chain_context: TaskChainContext,
    ):
        """
        Initialize the TaskChainCreator.

        Args:
            platform: The platform to use for the task chains
            task_queue: The task queue to use for the task chains
            task_chain_context: The context for the task chains

        """
        self.platform = platform
        self.task_queue = task_queue
        self.task_chain_context = task_chain_context

    async def build_task_chains_for_extraction_and_load(
        self,
        partition_inputs: list[PartitionInput],
    ) -> list[int]:
        """Build a task chain for extracting data and loading it into the target system."""
        task_ids: list[int] = []

        # Create task chain for each partition
        for partition_input in partition_inputs:
            new_task_ids = await self.build_task_chain_for_extraction_and_load(
                partition_input
            )
            task_ids.extend(new_task_ids)

        return task_ids

    async def build_task_chain_for_extraction_and_load(
        self,
        partition_input: PartitionInput,
        process_checksum_result_payload: ProcessChecksumResultPayload | None = None,
    ) -> list[int]:
        """
        Build a task chain for extracting data and loading it into the target system.

        Args:
            partition_input: The input for the partition
            process_checksum_result_payload: The payload for the process checksum result
                (optional, only must be passed if using CHECKSUM sync strategy)

        Returns:
            The list of task IDs

        """
        task_chain: list[Task] = []

        task_chain.append(self._build_data_extraction_task(partition_input))

        if (
            self._requires_clearing_partition(partition_input.sync_data)
            and process_checksum_result_payload is not None
        ):
            task_chain.append(
                self._build_clear_partition_task(process_checksum_result_payload)
            )

        task_chain.append(
            self._build_data_loading_task(
                partition_input.partition_metadata_id,
                partition_input.partition_index,
            )
        )

        return await self.task_queue.push_task_chain(task_chain)

    def _build_data_extraction_task(self, partition_input: PartitionInput) -> Task:
        partition_index = partition_input.partition_index
        table_config: TableConfiguration = self.task_chain_context.table_config
        data_movement_payload = self._build_data_extraction_payload(partition_input)

        # Build task with scope
        scope = build_partition_extraction_scope(
            table_config.source, partition_index, self.platform.name
        )
        return (
            TaskBuilder(
                workflow_id=self.task_chain_context.workflow_id,
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                task_name=f"Extract partition #{partition_index} of {table_config.source.fully_qualified_friendly_name}",
                payload=data_movement_payload,
                scope=scope,
            )
            .with_priority(compute_priority_for_extraction_task(partition_index))
            .build()
        )

    def _build_data_extraction_payload(
        self, partition_input: PartitionInput
    ) -> DataMovementTaskPayload:
        """
        Build data extraction task payload for any extraction strategy.

        Supports both regular extraction (via Snowflake internal stage) and
        UNLOAD extraction (via S3 for Redshift).

        Args:
            partition_input: The partition input containing boundary and metadata

        Returns:
            DataMovementTaskPayload configured for the extraction strategy

        Raises:
            UnsupportedExtractionStrategyError: If UNLOAD is requested but platform
                doesn't support it (only Redshift supports UNLOAD)

        """
        table_config: TableConfiguration = self.task_chain_context.table_config
        is_unload = table_config.extraction_strategy == ExtractionStrategy.UNLOAD

        # UNLOAD strategy is not supported for all platforms
        if is_unload and not self.platform.supports_strategy(ExtractionStrategy.UNLOAD):
            raise UnsupportedExtractionStrategyError(
                extraction_strategy_name="UNLOAD",
                platform_name=str(self.platform.name),
            )

        # Build type-aware SELECT query for this partition
        select_query = self.platform.query_builder.build_extraction_query(
            table_name=table_config.source,
            source_schema=self.task_chain_context.source_schema,
            partition_condition=partition_input.partition_boundary.where_clause,
            sync_data=partition_input.sync_data,
            where_clause_criteria=table_config.where_clause_criteria,
        )

        # Build platform-specific USE database command
        use_database_command = self.platform.query_builder.build_use_database_command(
            table_config.source.database_name
        )

        # Target type and path differ by extraction strategy
        if is_unload:
            target_type = TargetType.S3_UNLOAD
            # UNLOAD: relative path only - Extraction Agent prepends its configured S3 bucket
            target_id = relative_path_for_partition_data(
                self.task_chain_context.workflow_id,
                self.task_chain_context.table_metadata_id,
                partition_input.partition_index,
            )
            # UNLOAD doesn't need batch sizing - Redshift handles it internally
            suggested_batch_size = None
        else:
            target_type = TargetType.SNOWFLAKE_STAGE
            target_id = stage_path_for_partition_data(
                DEFAULT_INTERNAL_STAGE,
                self.task_chain_context.workflow_id,
                self.task_chain_context.table_metadata_id,
                partition_input.partition_index,
            )
            suggested_batch_size = self.task_chain_context.suggested_batch_size

        return DataMovementTaskPayload(
            database=table_config.source.database_name,
            schema=table_config.source.schema_name,
            source_type=self.platform.name,
            # TODO(SNOW-3113561): Check if this source_id is actually useful (why is it only the schema?)
            source_id=f"{table_config.source.database_name}.{table_config.source.schema_name}",
            target_type=target_type,
            target_id=target_id,
            statement_location_id=select_query,
            suggested_batch_size=suggested_batch_size,
            is_bulk_operation=True,
            use_database_command=use_database_command,
        )

    def _build_data_loading_task(
        self, partition_metadata_id: int, partition_index: int
    ) -> Task:
        target_table: str = (
            self.task_chain_context.table_config.target.get_fully_qualified_normalized_name(
                source_type=None
            )
        )

        process_payload = ProcessStagedDataTaskPayload(
            table_metadata_id=self.task_chain_context.table_metadata_id,
            partition_metadata_id=partition_metadata_id,
            partition_index=partition_index,
            target_table=target_table,
        )

        source_table_id: TableIdentifier = self.task_chain_context.table_config.source

        # Build task with scope
        scope = build_partition_loading_scope(
            source_table_id, partition_index, self.platform.name
        )
        return (
            TaskBuilder(
                workflow_id=self.task_chain_context.workflow_id,
                executor_type=ExecutorType.ORCHESTRATOR,
                task_name=f"Load partition #{partition_index} of {source_table_id.fully_qualified_friendly_name}",
                payload=process_payload,
                scope=scope,
            )
            .with_priority(PRIORITY_FOR_COPY_INTO_TASKS)
            .build()
        )

    def _build_clear_partition_task(
        self, process_checksum_result_payload: ProcessChecksumResultPayload
    ) -> Task:
        partition_index = process_checksum_result_payload.partition_number
        source_table_id: TableIdentifier = self.task_chain_context.table_config.source
        scope = build_partition_loading_scope(
            source_table_id, partition_index, self.platform.name
        )
        payload = ClearPartitionDataPayload(
            target_table=process_checksum_result_payload.target_table,
            partition_column=process_checksum_result_payload.partition_column,
            min_value=process_checksum_result_payload.min_value,
            max_value=process_checksum_result_payload.max_value,
            partition_metadata_id=process_checksum_result_payload.partition_metadata_id,
        )
        return (
            TaskBuilder(
                workflow_id=self.task_chain_context.workflow_id,
                executor_type=ExecutorType.ORCHESTRATOR,
                task_name=f"Clear partition #{partition_index} before loading",
                payload=payload,
                scope=scope,
            )
            .with_priority(PRIORITY_FOR_COPY_INTO_TASKS)
            .build()
        )

    def _requires_clearing_partition(
        self, synchronization_data: SyncData | None
    ) -> bool:
        if not isinstance(synchronization_data, ChecksumSyncData):
            return False  # Currently, clearing partitions is only required for CHECKSUM sync strategy
        is_first_synchronization = synchronization_data.candidate_checksum is None
        return not is_first_synchronization
