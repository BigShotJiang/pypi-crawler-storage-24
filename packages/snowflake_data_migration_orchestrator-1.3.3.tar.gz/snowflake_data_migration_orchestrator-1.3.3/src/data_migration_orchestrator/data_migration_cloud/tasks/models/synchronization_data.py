"""
Synchronization data types for incremental sync.

This module defines the data structures for storing synchronization metadata
in PARTITION_METADATA.SYNCHRONIZATION_DATA (VARIANT column).

Uses a tagged union pattern where the 'strategy' field determines the type.
"""

import json

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.constants.metadata import (
    SYNC_DATA_CANDIDATE_CHECKSUM,
    SYNC_DATA_CANDIDATE_MAX_WATERMARK_VALUE,
    SYNC_DATA_CHECKSUM,
    SYNC_DATA_MAX_WATERMARK_VALUE,
    SYNC_DATA_STRATEGY,
    SYNC_DATA_WATERMARK_COLUMN,
)


# Type alias for watermark values (supports various temporal and numeric types)
WatermarkValue = str | int | float | datetime | None


@dataclass
class BaseSyncData(ABC):
    """
    Base class for synchronization data.

    All sync data types must have a strategy field that identifies the type.
    """

    strategy: SyncStrategy

    @abstractmethod
    def to_json(self) -> str:
        """Serialize to JSON string for storage in VARIANT column."""
        pass


@dataclass
class WatermarkSyncData(BaseSyncData):
    """
    Synchronization data for WATERMARK strategy.

    Stores the watermark column name and the maximum observed value
    from the last successful sync.

    The candidate_max_watermark_value is set during extraction (before COPY INTO)
    and promoted to max_watermark_value only after successful completion.

    Watermark values can be strings, numbers, or datetime objects.
    Datetime objects are serialized to ISO format strings for JSON storage.
    """

    watermark_column: str
    max_watermark_value: WatermarkValue = None
    candidate_max_watermark_value: WatermarkValue = None

    def __post_init__(self):
        """Post-init hook to set the strategy."""
        self.strategy = SyncStrategy.WATERMARK

    @staticmethod
    def _serialize_watermark_value(value: WatermarkValue) -> Any:
        """
        Serialize a watermark value for JSON storage.

        Converts datetime objects to ISO format strings.
        Other types are returned as-is.
        """
        if isinstance(value, datetime):
            return value.isoformat()
        return value

    def to_json(self) -> str:
        """Serialize to JSON string for storage in VARIANT column."""
        data = {
            SYNC_DATA_STRATEGY: self.strategy.value,
            SYNC_DATA_WATERMARK_COLUMN: self.watermark_column,
            SYNC_DATA_MAX_WATERMARK_VALUE: self._serialize_watermark_value(
                self.max_watermark_value
            ),
        }
        # Only include candidate if it has a value
        if self.candidate_max_watermark_value is not None:
            data[SYNC_DATA_CANDIDATE_MAX_WATERMARK_VALUE] = (
                self._serialize_watermark_value(self.candidate_max_watermark_value)
            )
        return json.dumps(data)


@dataclass
class ChecksumSyncData(BaseSyncData):
    """
    Synchronization data for CHECKSUM strategy.

    Stores the checksum (hash of all column values) for a partition.

    The candidate_checksum is computed during the COMPARE_CHECKSUM phase and
    promoted to checksum only after successful COPY INTO completion.
    """

    checksum: str | None = None
    candidate_checksum: str | None = None

    def __post_init__(self):
        """Post-init hook to set the strategy."""
        self.strategy = SyncStrategy.CHECKSUM

    def to_json(self) -> str:
        """Serialize to JSON string for storage in VARIANT column."""
        data = {
            SYNC_DATA_STRATEGY: self.strategy.value,
        }
        # Only include checksum if it has a value
        if self.checksum is not None:
            data[SYNC_DATA_CHECKSUM] = self.checksum
        # Only include candidate if it has a value
        if self.candidate_checksum is not None:
            data[SYNC_DATA_CANDIDATE_CHECKSUM] = self.candidate_checksum
        return json.dumps(data)


@dataclass
class ChangeTrackingSyncData(BaseSyncData):
    """
    Synchronization data for CHANGE_TRACKING strategy.

    Stores change tracking version or similar metadata.
    """

    # TODO(SNOW-3067427): Add change tracking specific fields

    def __post_init__(self):
        """Post-init hook to set the strategy."""
        self.strategy = SyncStrategy.CHANGE_TRACKING

    def to_json(self) -> str:
        """Serialize to JSON string for storage in VARIANT column."""
        return json.dumps({SYNC_DATA_STRATEGY: self.strategy.value})


# Union type for all sync data variants
SyncData = WatermarkSyncData | ChecksumSyncData | ChangeTrackingSyncData


def parse_sync_data(data: dict | str | None) -> SyncData | None:
    """
    Parse synchronization data from JSON or dict.

    Deserializes the SYNCHRONIZATION_DATA VARIANT column into the
    appropriate typed dataclass based on the strategy field.

    Args:
        data: Raw data from database (dict, JSON string, or None)

    Returns:
        Typed SyncData object, or None if data is None/empty

    Raises:
        ValueError: If strategy is unknown or data is malformed

    """
    if data is None:
        return None

    if isinstance(data, str):
        data = json.loads(data)

    if not data:
        return None

    strategy_str = data.get(SYNC_DATA_STRATEGY)
    if not strategy_str:
        return None

    strategy = SyncStrategy.from_string(strategy_str)

    if strategy == SyncStrategy.WATERMARK:
        return WatermarkSyncData(
            strategy=strategy,
            watermark_column=data.get(SYNC_DATA_WATERMARK_COLUMN, ""),
            max_watermark_value=data.get(SYNC_DATA_MAX_WATERMARK_VALUE),
            candidate_max_watermark_value=data.get(
                SYNC_DATA_CANDIDATE_MAX_WATERMARK_VALUE
            ),
        )
    elif strategy == SyncStrategy.CHECKSUM:
        return ChecksumSyncData(
            strategy=strategy,
            checksum=data.get(SYNC_DATA_CHECKSUM),
            candidate_checksum=data.get(SYNC_DATA_CANDIDATE_CHECKSUM),
        )
    elif strategy == SyncStrategy.CHANGE_TRACKING:
        return ChangeTrackingSyncData(strategy=strategy)
    else:
        raise ValueError(f"Unknown sync strategy: {strategy_str}")
