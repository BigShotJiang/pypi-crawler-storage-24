"""
Task Payload Kind enumeration.

This module defines all possible task types in the migration workflow.
"""

from enum import StrEnum

from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SNOWFLAKE_QUERY_TASK_PAYLOAD_KIND,
)


class TaskPayloadKind(StrEnum):
    """
    Enum representing all possible task types in the migration workflow.

    Tasks are categorized by their executor type:
    - ORCHESTRATOR: Coordination, processing, and decision-making tasks
    - DATA_EXCHANGE_AGENT: Tasks that interact with source systems
    - WAREHOUSE: Tasks that execute Snowflake queries
    """

    # ==================== ORCHESTRATOR TASKS ====================
    # Partition Strategy
    DETERMINE_PARTITION_STRATEGY = "determine_partition_strategy"
    CREATE_PARTITION_TASKS = "create_partition_tasks"

    # Checksum Validation
    VALIDATE_CHECKSUMS = "validate_checksums"
    DETECT_CHANGED_PARTITIONS = "detect_changed_partitions"

    # Data Movement
    PROCESS_STAGED_DATA = "process_staged_data"
    UNLOAD_PARTITION_FROM_STAGE = "unload_partition_from_stage"
    COMPLETE_PARTITION_MIGRATION = "complete_partition_migration"

    # Checksum Incremental Sync
    COMPARE_PARTITION_CHECKSUM = "compare_partition_checksum"
    PROCESS_CHECKSUM_RESULT = "process_checksum_result"
    CLEAR_PARTITION_DATA = "clear_partition_data"

    # Watermark Incremental Sync
    DEDUPLICATE_PARTITION_DATA = "deduplicate_partition_data"

    # Partition Measures Validation
    GENERATE_VALIDATION_MEASURES = "generate_validation_measures"
    COMPARE_MEASURES = "compare_measures"

    # ==================== DATA EXCHANGE AGENT TASKS ====================
    # Checksum Collection
    GET_SOURCE_CHECKSUMS = "get_source_checksums"

    # Data Extraction (covers both metadata and data extraction)
    DATA_MOVEMENT = "data_movement"

    # Validation Measures
    MEASURE_PARTITION_SOURCE = "measure_partition_source"

    # ==================== WAREHOUSE TASKS ====================
    # Table Setup
    FETCH_TARGET_METADATA = "fetch_target_metadata"
    CREATE_TARGET_TABLE = "create_target_table"
    CREATE_STREAM = "create_stream"

    # Target Checksums
    GET_TARGET_CHECKSUMS = "get_target_checksums"

    # Data Loading
    COPY_INTO = "copy_into"
    SNOWFLAKE_QUERY = SNOWFLAKE_QUERY_TASK_PAYLOAD_KIND

    # Validation & Cleanup
    MEASURE_PARTITION_TARGET = "measure_partition_target"
    VALIDATE_AND_CLEANUP = "validate_and_cleanup"
