"""
Process checksum result handler.

This handler processes the staged checksum result from the DataMovementTask and:
1. Reads the computed checksum from the staged location
2. Compares with the stored checksum
3. If unchanged: marks partition as complete
4. If changed (or first-time): stores candidate checksum and creates extraction chain
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    DEFAULT_INTERNAL_STAGE,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.services.batch_size_calculator import (
    calculate_suggested_batch_size_from_bytes,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundaryGenerator,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.synchronization_config_service import (
    SynchronizationConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_config_service import (
    WorkflowConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.partition_migration_status import (
    PartitionMigrationStatus,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    ChecksumSyncData,
    SyncData,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    ProcessChecksumResultPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_chain_creator import (
    PartitionInput,
    TaskChainContext,
    TaskChainCreator,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    read_schema_from_stage,
    stage_path_for_checksum,
    stage_path_for_schema,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.process_checksum_result")


class ProcessChecksumResultHandler(BaseTaskHandler):
    """
    Handler for processing checksum results and deciding next steps.

    This handler:
    1. Reads the computed checksum from the staged location
    2. Compares with the stored checksum (if any)
    3. If unchanged (and stored checksum exists): marks partition as complete
    4. If changed (or first-time): stores candidate_checksum and creates
       CLEAR -> EXTRACT -> LOAD chain
    """

    def __init__(self, task_queue: BaseTaskQueue, warehouse: Warehouse):
        """Initialize handler with task queue and warehouse proxy."""
        super().__init__(
            TaskPayloadKind.PROCESS_CHECKSUM_RESULT,
            task_queue,
            warehouse,
        )
        self.boundary_generator = PartitionBoundaryGenerator()
        self.table_config_service = TableConfigurationService(warehouse)
        self.sync_config_service = SynchronizationConfigService(warehouse)
        self.workflow_config_service = WorkflowConfigService(warehouse)

    async def handle(self, task: Task) -> None:
        """
        Handle a process checksum result task.

        Reads the staged checksum, compares with stored, and decides
        whether to create extraction chain or mark partition complete.

        Args:
            task: The task containing ProcessChecksumResultPayload

        """
        if not isinstance(task.payload, ProcessChecksumResultPayload):
            raise ValueError(
                f"Expected ProcessChecksumResultPayload, got {type(task.payload)}"
            )

        if self.warehouse_proxy is None:
            raise ValueError(
                "warehouse_proxy is required for ProcessChecksumResultHandler"
            )

        payload = task.payload
        logger.info(
            f"ProcessChecksumResultHandler: partition {payload.partition_number} "
            f"for table {payload.database}.{payload.schema}.{payload.table_name}"
        )

        # Checksum data is always stored on internal stage (regardless of extraction strategy)
        checksum_staged_location = stage_path_for_checksum(
            DEFAULT_INTERNAL_STAGE,
            task.workflow_id,
            payload.table_metadata_id,
            payload.partition_number,
        )

        # Read the computed checksum from staged location
        current_checksum = await self._read_staged_checksum(checksum_staged_location)
        logger.info(
            f"Read checksum for partition {payload.partition_number}: {current_checksum}"
        )

        # Compare with stored checksum
        if (
            payload.stored_checksum is not None
            and current_checksum == payload.stored_checksum
        ):
            # Checksum unchanged - mark partition as complete
            logger.info(
                f"Partition {payload.partition_number} checksum unchanged, "
                f"marking as complete"
            )
            await self._mark_partition_complete(payload.partition_metadata_id)
        else:
            # Checksum changed or first-time sync - create extraction chain
            if payload.stored_checksum is None:
                logger.info(
                    f"Partition {payload.partition_number} first-time sync, "
                    f"creating extraction chain"
                )
            else:
                logger.info(
                    f"Partition {payload.partition_number} checksum changed "
                    f"({payload.stored_checksum} -> {current_checksum}), "
                    f"creating extraction chain"
                )

            # Store candidate checksum before extraction
            await self._store_candidate_checksum(
                payload.partition_metadata_id, current_checksum
            )

            # Create extraction chain: EXTRACT -> CLEAR -> LOAD
            await self._create_extraction_chain(
                workflow_id=task.workflow_id,
                payload=payload,
            )

        # Complete this task
        if task.id is None:
            raise ValueError("Task ID is required")

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    async def _read_staged_checksum(self, staged_location: str) -> str:
        """
        Read the checksum value from the staged location.

        The checksum query should have produced a single row with a 'checksum' column.

        Args:
            staged_location: Stage location where checksum result was written

        Returns:
            The checksum string

        Raises:
            ValueError: If checksum could not be read

        """
        # Query the staged file to get the checksum value
        # The data-exchange-agent writes results as Parquet or CSV
        query = f"""
            SELECT $1:checksum::VARCHAR AS checksum
            FROM {staged_location}
            (FILE_FORMAT => 'SNOWCONVERT_AI.DATA_MIGRATION.PARQUET_FILE_FORMAT',
            PATTERN => '.*[.]parquet')
            LIMIT 1
        """

        try:
            result = await self.warehouse_proxy.execute_sync_query(query)
            if not result:
                # Try CSV format
                query_csv = f"""
                    SELECT $1 AS checksum
                    FROM {staged_location}
                    (FILE_FORMAT => 'SNOWCONVERT_AI.DATA_MIGRATION.DM_CSV_FORMAT',
                    PATTERN => '.*[.]csv.*')
                    LIMIT 1
                """
                result = await self.warehouse_proxy.execute_sync_query(query_csv)

            if not result:
                raise ValueError(f"No checksum result found at {staged_location}")

            checksum = result[0].get("CHECKSUM") or result[0].get("checksum")
            if checksum is None:
                raise ValueError(
                    f"Checksum column not found in result at {staged_location}"
                )

            return str(checksum)

        except Exception as e:
            logger.error(f"Failed to read checksum from {staged_location}: {e}")
            raise ValueError(
                f"Failed to read checksum from {staged_location}: {e}"
            ) from e

    async def _mark_partition_complete(self, partition_metadata_id: int) -> None:
        """
        Mark partition as complete without extraction.

        Args:
            partition_metadata_id: ID of the partition metadata record

        """
        query = f"""
            UPDATE SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA
            SET
                MIGRATION_STATUS = 'COMPLETED',
                MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP(),
                SYNC_TIMESTAMP = CURRENT_TIMESTAMP()
            WHERE ID = {partition_metadata_id}
        """
        await self.warehouse_proxy.execute_sync_query(query)
        logger.info(
            f"Marked partition {partition_metadata_id} as COMPLETED (unchanged)"
        )

    async def _store_candidate_checksum(
        self, partition_metadata_id: int, checksum: str
    ) -> None:
        """
        Store candidate checksum in SYNCHRONIZATION_DATA.

        Args:
            partition_metadata_id: ID of the partition metadata record
            checksum: The computed checksum value

        """
        # Build sync data JSON with strategy and candidate checksum
        sync_data_json = ChecksumSyncData(
            SyncStrategy.CHECKSUM, candidate_checksum=checksum
        ).to_json()

        query = f"""
            UPDATE SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA
            SET
                SYNCHRONIZATION_DATA = PARSE_JSON('{sync_data_json}'),
                MIGRATION_STATUS = '{PartitionMigrationStatus.EXTRACTING}',
                MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP()
            WHERE ID = {partition_metadata_id}
        """
        await self.warehouse_proxy.execute_sync_query(query)
        logger.info(
            f"Stored candidate checksum for partition {partition_metadata_id}: {checksum}"
        )

    async def _create_extraction_chain(
        self,
        workflow_id: int,
        payload: ProcessChecksumResultPayload,
    ) -> None:
        source_type = SourceType.from_string(payload.source_type)
        platform = PlatformRegistry.create_by_name_or_alias(payload.source_type)
        table_config = (
            await self.table_config_service.fetch_required_table_configuration(
                payload.table_metadata_id
            )
        )

        # Fetch strategy config for TaskChainContext
        strategy_config = await self.workflow_config_service.fetch_strategy_config(
            workflow_id, table_config.extraction_strategy.value
        )

        # Read source schema for extraction query
        # Schema is always stored on internal stage (PUT only works with internal stages)
        schema_location = stage_path_for_schema(
            DEFAULT_INTERNAL_STAGE, workflow_id, payload.table_metadata_id
        )
        source_schema = await read_schema_from_stage(
            self.warehouse_proxy, schema_location
        )

        # Read sync data if available
        sync_data: SyncData | None = (
            await self.sync_config_service.fetch_partition_sync_data(
                payload.table_metadata_id, payload.partition_number
            )
        )

        # Prepare for creation of task chain
        task_chain_context = TaskChainContext(
            workflow_id=workflow_id,
            table_metadata_id=payload.table_metadata_id,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=self._calculate_batch_size(payload.avg_row_size_bytes),
            strategy_config=strategy_config or {},
        )
        task_chain_creator = TaskChainCreator(
            platform, self.task_queue, task_chain_context
        )
        partition_boundary = self.boundary_generator.generate_single_boundary(
            partition_column=payload.partition_column,
            partition_id=payload.partition_number,
            min_value=payload.min_value,
            max_value=payload.max_value,
            source_type=source_type,
        )
        partition_input = PartitionInput(
            partition_metadata_id=payload.partition_metadata_id,
            partition_index=payload.partition_number,
            partition_boundary=partition_boundary,
            sync_data=sync_data,
        )

        # Create task chain
        await task_chain_creator.build_task_chain_for_extraction_and_load(
            partition_input, process_checksum_result_payload=payload
        )

    def _calculate_batch_size(self, avg_row_size_bytes: float | None) -> int | None:
        """Calculate suggested batch size from average row size."""
        if avg_row_size_bytes is None:
            return None

        return calculate_suggested_batch_size_from_bytes(avg_row_size_bytes)
