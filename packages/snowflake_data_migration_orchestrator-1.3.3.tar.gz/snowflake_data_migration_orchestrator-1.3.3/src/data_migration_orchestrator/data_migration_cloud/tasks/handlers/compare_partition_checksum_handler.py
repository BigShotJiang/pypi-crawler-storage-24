"""
Compare partition checksum handler.

This handler initiates the CHECKSUM incremental sync strategy by:
1. Building a platform-specific checksum query
2. Creating a DataMovementTask to execute the query on the source
3. Creating a ProcessChecksumResultTask to compare and decide next steps

The actual checksum comparison happens in ProcessChecksumResultHandler
after the DataMovementTask stages the checksum result.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.constants.priorities import (
    compute_priority_for_extraction_task,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    DEFAULT_INTERNAL_STAGE,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.scope import ScopeBuilder
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    ComparePartitionChecksumPayload,
    DataMovementTaskPayload,
    ProcessChecksumResultPayload,
    TargetType,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    read_schema_from_stage,
    stage_path_for_checksum,
    stage_path_for_schema,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.compare_partition_checksum")


class ComparePartitionChecksumHandler(BaseTaskHandler):
    """
    Handler for initiating partition checksum comparison.

    This handler:
    1. Builds a platform-specific checksum query
    2. Creates a DataMovementTask to execute the query via data-exchange-agent
    3. Creates a ProcessChecksumResultTask (blocked) to process the result

    The DataMovementTask will stage the checksum result, and upon completion,
    ProcessChecksumResultTask will read it, compare with stored checksum,
    and decide whether to create the extraction chain.
    """

    def __init__(self, task_queue: BaseTaskQueue, warehouse_proxy: Warehouse):
        """Initialize handler with task queue and warehouse proxy."""
        super().__init__(
            TaskPayloadKind.COMPARE_PARTITION_CHECKSUM,
            task_queue,
            warehouse_proxy,
        )

    async def handle(self, task: Task) -> None:
        """
        Handle a compare partition checksum task.

        Creates a DataMovementTask to compute the checksum on the source,
        with a ProcessChecksumResultTask as successor to process the result.

        Args:
            task: The task containing ComparePartitionChecksumPayload

        """
        if not isinstance(task.payload, ComparePartitionChecksumPayload):
            raise ValueError(
                f"Expected ComparePartitionChecksumPayload, got {type(task.payload)}"
            )

        payload = task.payload
        logger.info(
            f"ComparePartitionChecksumHandler: partition {payload.partition_number} "
            f"for table {payload.database}.{payload.schema}.{payload.table_name}"
        )

        source_table_id = TableIdentifier(
            database_name=payload.database,
            schema_name=payload.schema,
            table_name=payload.table_name,
        )

        # Read column metadata from stage (already extracted during metadata phase)
        schema_location = stage_path_for_schema(
            DEFAULT_INTERNAL_STAGE, task.workflow_id, payload.table_metadata_id
        )
        schema_rows = await read_schema_from_stage(
            self.warehouse_proxy, schema_location
        )
        columns = self._convert_schema_to_column_info(schema_rows)
        logger.info(
            f"Read {len(columns)} columns from schema stage for checksum computation"
        )

        # Resolve platform once and reuse for checksum query + USE command
        platform = PlatformRegistry.create_by_name_or_alias(payload.source_type)

        # Build checksum query using platform-specific query builder
        partition_info = PartitionInfo(
            database=payload.database,
            schema=payload.schema,
            table_name=payload.table_name,
            partition_column=payload.partition_column,
            min_value=payload.min_value,
            max_value=payload.max_value,
            partition_number=payload.partition_number,
        )

        checksum_query = platform.query_builder.build_checksum_query(
            partition_info=partition_info,
            source_table_id=source_table_id,
            columns=columns,
        )
        logger.info(
            f"Built checksum query for partition {payload.partition_number}: {checksum_query}"
        )

        # Compute checksum stage location deterministically
        # Checksum results are always stored on internal stage (regardless of extraction strategy)
        checksum_stage_location = stage_path_for_checksum(
            DEFAULT_INTERNAL_STAGE,
            task.workflow_id,
            payload.table_metadata_id,
            payload.partition_number,
        )

        # Build scope for checksum tasks
        source_type = SourceType.from_string(payload.source_type)
        checksum_scope = (
            ScopeBuilder.for_table(source_table_id, source_type)
            .partition(payload.partition_number)
            .extraction()
        )

        # Build USE database command for source
        use_database_command = platform.query_builder.build_use_database_command(
            payload.database
        )

        # Create ProcessChecksumResultTask (blocked until DataMovementTask completes)
        process_checksum_result_payload = ProcessChecksumResultPayload(
            partition_metadata_id=payload.partition_metadata_id,
            table_metadata_id=payload.table_metadata_id,
            partition_number=payload.partition_number,
            partition_column=payload.partition_column,
            min_value=payload.min_value,
            max_value=payload.max_value,
            stored_checksum=payload.stored_checksum,
            database=payload.database,
            schema=payload.schema,
            table_name=payload.table_name,
            source_type=payload.source_type,
            target_table=payload.target_table,
            avg_row_size_bytes=payload.avg_row_size_bytes,
        )
        process_result_task = (
            TaskBuilder(
                workflow_id=task.workflow_id,
                executor_type=ExecutorType.ORCHESTRATOR,
                task_name=f"Process checksum result partition {payload.partition_number}: {payload.table_name}",
                scope=checksum_scope,
                payload=process_checksum_result_payload,
            )
            .with_priority(
                compute_priority_for_extraction_task(payload.partition_number)
            )
            .blocked()
            .build()
        )
        process_result_task_id = await self.task_queue.push_task(process_result_task)

        # Create DataMovementTask to execute checksum query on source
        checksum_query_task = (
            TaskBuilder(
                workflow_id=task.workflow_id,
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                task_name=f"Compute checksum partition {payload.partition_number}: {payload.table_name}",
                payload=DataMovementTaskPayload(
                    database=payload.database,
                    schema=payload.schema,
                    source_type=payload.source_type,
                    source_id=f"{payload.database}.{payload.schema}",
                    target_type=TargetType.SNOWFLAKE_STAGE,
                    target_id=checksum_stage_location,
                    statement_location_type="in-payload",
                    statement_location_id=checksum_query,
                    suggested_batch_size=None,  # Checksum is a single row result
                    is_bulk_operation=False,  # Not a bulk operation
                    use_database_command=use_database_command,
                ),
                scope=checksum_scope,
            )
            .with_priority(
                compute_priority_for_extraction_task(payload.partition_number)
            )
            .with_successor(process_result_task_id)
            .build()
        )
        checksum_query_task_id = await self.task_queue.push_task(checksum_query_task)

        logger.info(
            f"Created checksum chain for partition {payload.partition_number}: "
            f"checksum_query_task={checksum_query_task_id} -> "
            f"process_result_task={process_result_task_id}"
        )

        # Complete this task
        if task.id is None:
            raise ValueError("Task ID is required")

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    def _convert_schema_to_column_info(
        self, schema_rows: list[dict]
    ) -> list[ColumnInfo]:
        """
        Convert schema rows from stage to ColumnInfo objects.

        Args:
            schema_rows: List of dicts from read_schema_from_stage with keys:
                column_name, data_type, max_length, precision, scale,
                is_nullable, ordinal_position

        Returns:
            List of ColumnInfo objects sorted by ordinal_position

        """
        columns = []
        for row in schema_rows:
            # is_nullable can be 'YES', 'NO', 'True', 'False', etc.
            is_nullable_raw = row.get("is_nullable", "YES")
            is_nullable = str(is_nullable_raw).upper() in ("YES", "TRUE", "1", "Y")

            columns.append(
                ColumnInfo(
                    column_name=row["column_name"],
                    data_type=row["data_type"],
                    is_nullable=is_nullable,
                    numeric_precision=row.get("precision"),
                    numeric_scale=row.get("scale"),
                )
            )
        return columns
