"""
Service for fetching and managing synchronization configuration.

This module provides utilities to fetch synchronization configuration
from TABLE_METADATA table and PARTITION_METADATA table for incremental sync operations.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    SynchronizationConfig,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    SyncData,
    parse_sync_data,
)


logger = get_logger("tasks.handlers.synchronization_config_service")


class SynchronizationConfigService:
    """
    Service for fetching synchronization configuration from TABLE_METADATA.

    This service retrieves sync config stored during workflow initialization
    and provides it to handlers for incremental sync operations.

    Note: This service delegates to TableConfigurationService for fetching
    the synchronization config from the TABLE_CONFIGURATION column.
    """

    def __init__(self, warehouse_proxy: Warehouse):
        """
        Initialize the synchronization config service.

        Args:
            warehouse_proxy: Proxy for executing warehouse queries

        """
        self.warehouse_proxy = warehouse_proxy
        self._table_config_service = TableConfigurationService(warehouse_proxy)

    async def fetch_synchronization_config(
        self, table_metadata_id: int | None
    ) -> SynchronizationConfig:
        """
        Fetch synchronization config from TABLE_METADATA table with caching.

        Args:
            table_metadata_id: ID of the table metadata record

        Returns:
            SynchronizationConfig object (returns default config if not found)

        """
        if table_metadata_id is None:
            return SynchronizationConfig()

        # Delegate to TableConfigurationService (which handles caching)
        table_config = await self._table_config_service.fetch_table_configuration(
            table_metadata_id
        )

        if table_config is not None:
            logger.debug(
                f"Fetched sync config for table_metadata_id={table_metadata_id}: "
                f"strategy={table_config.synchronization.strategy.value}"
            )
            return table_config.synchronization

        return SynchronizationConfig()

    async def fetch_partition_sync_data(
        self,
        table_metadata_id: int,
        partition_number: int,
    ) -> SyncData | None:
        """
        Fetch SYNCHRONIZATION_DATA for a specific partition with caching.

        Queries the PARTITION_METADATA table to get the sync data for a partition
        identified by its table_metadata_id and partition_number.

        Args:
            table_metadata_id: ID of the table metadata record
            partition_number: The partition number (0 for full table extraction)

        Returns:
            Parsed SyncData object, or None if partition doesn't exist or has no sync data

        """
        try:
            query = f"""
                SELECT SYNCHRONIZATION_DATA
                FROM SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA
                WHERE TABLE_ID = {table_metadata_id}
                  AND PARTITION_NUMBER = {partition_number}
            """
            result = await self.warehouse_proxy.execute_sync_query(query)

            if not result:
                logger.debug(
                    f"No partition found for table_metadata_id={table_metadata_id}, "
                    f"partition_number={partition_number}"
                )
                return None

            sync_data_raw = result[0].get("SYNCHRONIZATION_DATA") or result[0].get(
                "synchronization_data"
            )
            if sync_data_raw is None:
                logger.debug(
                    f"Partition {partition_number} for table {table_metadata_id} "
                    f"has no sync data"
                )
                return None

            sync_data = parse_sync_data(sync_data_raw)

            logger.debug(
                f"Fetched sync data for partition {partition_number} of "
                f"table {table_metadata_id}: strategy={sync_data.strategy.value if sync_data else None}"
            )
            return sync_data

        except Exception as e:
            logger.error(
                f"Failed to fetch partition sync data for table_metadata_id={table_metadata_id}, "
                f"partition_number={partition_number}: {e}"
            )
            return None


# TODO(SNOW-3067445): Clean this class a bit and generalize this pattern.
