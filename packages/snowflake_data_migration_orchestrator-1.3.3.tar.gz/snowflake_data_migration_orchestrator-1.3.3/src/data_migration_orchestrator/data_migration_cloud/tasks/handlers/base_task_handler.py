"""
Base task handler class.

This module defines the abstract base class for all task handlers in the orchestrator.
"""

from abc import ABC, abstractmethod

from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)


class BaseTaskHandler(ABC):
    """
    Abstract base class for all task handlers.

    Each task handler implements the logic for processing a specific task type.
    Task handlers follow the Template Method pattern, where the base class defines
    the overall flow and subclasses implement specific behavior.

    Attributes:
        task_type: The type of task this handler processes
        task_queue: The task queue for managing task lifecycle
        warehouse_proxy: Optional warehouse proxy for executing warehouse operations

    """

    def __init__(
        self,
        task_type: TaskPayloadKind,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ):
        """
        Initialize the task handler.

        Args:
            task_type: The type of task this handler processes
            task_queue: The task queue implementation for managing tasks
            warehouse_proxy: Optional warehouse proxy for executing warehouse operations

        """
        self.task_type = task_type
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    @abstractmethod
    async def handle(self, task: Task) -> None:
        """
        Handle the task execution.

        This is the main entry point for task processing. Subclasses must implement
        this method to define the specific logic for their task type.

        The handle method should:
        1. Extract necessary data from the task payload
        2. Perform the required operations
        3. Generate any follow-up tasks if needed
        4. Update task status appropriately

        Args:
            task: The task to be processed

        Raises:
            Exception: If task processing fails. Subclasses should raise
                      appropriate exceptions for error handling.

        """
        ...
