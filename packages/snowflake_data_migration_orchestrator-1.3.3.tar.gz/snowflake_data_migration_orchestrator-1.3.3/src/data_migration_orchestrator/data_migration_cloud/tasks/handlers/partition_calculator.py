"""Partition calculation for determining optimal partitioning strategy."""

from dataclasses import dataclass


@dataclass
class PartitionConfig:
    """Partition configuration thresholds."""

    # TODO: these  values should be configurable
    max_single_partition_size_mb: int = 10 * 1024  # 10 GB threshold
    target_partition_size_mb: int = 10 * 512  # 5 GB target per partition
    target_fill_percentage: float = 0.9  # Safety margin
    min_partitions: int = 2
    max_partitions: int = 100


@dataclass
class PartitionDecision:
    """Partition analysis result."""

    should_partition: bool
    num_partitions: int
    rows_per_partition: int
    reasoning: str
    partition_column: str | None = None


class PartitionCalculator:
    """
    Calculates partitioning strategy based on table size.

    Binary decision based on max_single_partition_size_mb:
    - Small (≤ threshold): No partitioning
    - Large (> threshold): Partition using percentiles
    """

    def __init__(self, config: PartitionConfig | None = None):
        """Initialize calculator with optional custom config."""
        self.config = config or PartitionConfig()

    def calculate_partition_strategy(
        self, row_count: int, data_size_mb: float
    ) -> PartitionDecision:
        """Decide: partition or not? If yes, how many partitions?."""
        if row_count == 0:
            return PartitionDecision(
                should_partition=False,
                num_partitions=1,
                rows_per_partition=0,
                reasoning="Empty table - single extraction",
            )

        # Check for small table threshold
        if data_size_mb <= self.config.max_single_partition_size_mb:
            return PartitionDecision(
                should_partition=False,
                num_partitions=1,
                rows_per_partition=row_count,
                reasoning=f"{data_size_mb:.2f} MB ({row_count:,} rows) - single extraction",
            )

        # Large table - calculate partitions
        num_partitions = self._calculate_num_partitions(row_count, data_size_mb)
        rows_per_partition = row_count // num_partitions

        return PartitionDecision(
            should_partition=True,
            num_partitions=num_partitions,
            rows_per_partition=rows_per_partition,
            reasoning=(
                f"{data_size_mb:.2f} MB ({row_count:,} rows) - "
                f"{num_partitions} partitions (~{rows_per_partition:,} rows each)"
            ),
        )

    def _calculate_num_partitions(self, row_count: int, data_size_mb: float) -> int:
        """Calculate number of partitions needed."""
        avg_row_size_mb = data_size_mb / row_count if row_count > 0 else 0
        target_size = (
            self.config.target_partition_size_mb * self.config.target_fill_percentage
        )

        if avg_row_size_mb > 0:
            rows_per_partition = int(target_size / avg_row_size_mb)
            num_partitions = (row_count + rows_per_partition - 1) // rows_per_partition
        else:
            num_partitions = self.config.min_partitions

        # Apply bounds
        return max(
            self.config.min_partitions, min(num_partitions, self.config.max_partitions)
        )
