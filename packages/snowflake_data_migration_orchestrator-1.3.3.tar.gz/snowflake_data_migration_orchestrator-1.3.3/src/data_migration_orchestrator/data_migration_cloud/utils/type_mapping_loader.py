"""Loader for type mapping configurations with support for custom overrides."""

from __future__ import annotations

import logging

from dataclasses import dataclass
from pathlib import Path

import yaml

from data_migration_orchestrator.cloud_core.constants.file_formats import (
    CSV_FILE_FORMAT,
    PARQUET_FILE_FORMAT,
)
from data_migration_orchestrator.data_migration_core.type_mappings.default_mappings import (
    get_available_source_types as get_default_source_types,
)
from data_migration_orchestrator.data_migration_core.type_mappings.default_mappings import (
    get_default_mappings,
)
from data_migration_orchestrator.data_migration_core.type_mappings.models import (
    SourceTypeInfo,
    TypeMapping,
    TypeMappingCategory,
)
from shared.enums.file_type import FileType
from shared.enums.source_type import SourceType


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TypeTransformation:
    """Defines how to transform one type to another in SQL."""

    from_type: str
    to_type: str
    transformation: str


# Types that always require explicit cast in COPY INTO, even when source and target types match.
ALWAYS_CAST_TYPES = {"BINARY", "VARBINARY"}

# Spatial types need TO_GEOGRAPHY/TO_GEOMETRY($1:"col"::VARCHAR) in COPY INTO.
# A direct ::GEOGRAPHY cast or bare column reference both fail on Parquet VARIANT values.
_SPATIAL_COPY_INTO_CONSTRUCTORS: dict[str, str] = {
    "GEOGRAPHY": "TO_GEOGRAPHY",
    "GEOMETRY": "TO_GEOMETRY",
}


# Source types that store boolean-like data as integers (0/1) and require TO_BOOLEAN
# These types need special handling because even if Parquet reports BOOLEAN,
# the actual data might be stored as integers from the source database.
SOURCE_TYPES_REQUIRING_TO_BOOLEAN = {"BIT"}

# Snowflake text/character target types that need BCP empty-string handling in
# CSV COPY INTO.  BCP represents empty strings as a single null-byte character
# (0x00) because empty strings signify NULL in SQL Server.  We convert that
# sentinel back to '' with IFF($N = CHR(0), '', $N).
CSV_TEXT_TYPES = {"VARCHAR", "STRING", "TEXT", "CHAR"}

# Source types that represent datetime values.
# When Snowflake's USE_LOGICAL_TYPE is disabled, PyArrow INT64 timestamps are read as NUMBER
# instead of TIMESTAMP_NTZ. These source types help identify columns that need epoch-microsecond
# conversion when the Parquet schema reports NUMBER for what should be a timestamp.
SOURCE_DATETIME_TYPES = {"DATETIME", "DATETIME2", "SMALLDATETIME", "DATETIMEOFFSET"}

# Snowflake timestamp type family
SNOWFLAKE_TIMESTAMP_TYPES = {"TIMESTAMP_NTZ", "TIMESTAMP_TZ", "TIMESTAMP_LTZ"}


def _normalize_base_type(type_str: str) -> str:
    """
    Extract the base type name, removing any parameter annotations.

    Snowflake's INFER_SCHEMA returns types with parameters (e.g., "NUMBER(19,0)",
    "TIMESTAMP_NTZ(6)"). This function strips those so they can be matched against
    the transformation lookup table.

    Args:
        type_str: A type string, possibly with parameters

    Returns:
        The base type name without parameters

    Examples:
        >>> _normalize_base_type("NUMBER(19,0)")
        'NUMBER'
        >>> _normalize_base_type("TIMESTAMP_NTZ(6)")
        'TIMESTAMP_NTZ'
        >>> _normalize_base_type("VARCHAR")
        'VARCHAR'

    """
    paren_idx = type_str.find("(")
    if paren_idx != -1:
        return type_str[:paren_idx].strip()
    return type_str


class TypeTransformationEngine:
    """Handles type transformation logic for COPY INTO operations."""

    TRANSFORMATIONS: dict[tuple[str, str], str] = {
        ("BOOLEAN", "VARCHAR"): "CASE WHEN {col}::BOOLEAN THEN 'true' ELSE 'false' END",
        ("NUMBER", "VARCHAR"): "TO_VARCHAR({col})",
        (
            "NUMBER",
            "BOOLEAN",
        ): "TO_BOOLEAN({col}::NUMBER)",  # Cast variant to NUMBER first
        ("FLOAT", "VARCHAR"): "TO_VARCHAR({col})",
        ("DATE", "VARCHAR"): "TO_VARCHAR({col}, 'YYYY-MM-DD')",
        ("TIMESTAMP_NTZ", "VARCHAR"): "TO_VARCHAR({col}, 'YYYY-MM-DD HH24:MI:SS')",
        (
            "TIMESTAMP_TZ",
            "VARCHAR",
        ): "TO_VARCHAR({col}, 'YYYY-MM-DD HH24:MI:SS TZH:TZM')",
        ("TIMESTAMP_LTZ", "VARCHAR"): "TO_VARCHAR({col}, 'YYYY-MM-DD HH24:MI:SS')",
        ("TIME", "VARCHAR"): "TO_VARCHAR({col}, 'HH24:MI:SS')",
        ("BINARY", "VARCHAR"): "TO_VARCHAR({col}, 'hex')",
        ("VARBINARY", "VARCHAR"): "TO_VARCHAR({col}, 'hex')",
    }

    def get_transformation(
        self,
        from_type: str,
        to_type: str,
        column_name: str,
        source_type: str | None = None,
    ) -> str:
        """
        Get SQL transformation expression for type conversion (Parquet format).

        Uses named column access syntax ($1:"column_name") for Parquet files.

        Args:
            from_type: Source/intermediate type (e.g., "BOOLEAN" from Parquet).
                      May include parameters from INFER_SCHEMA (e.g., "NUMBER(19,0)").
            to_type: Target type (e.g., "VARCHAR(152)" from mapping or actual schema).
                    May include parameters that will be preserved in SQL casts.
            column_name: Column name to transform
            source_type: Optional original source database type (e.g., "BIT" from SQL Server)
                        Used to apply special transformations for types that store
                        boolean-like data as integers.

        Returns:
            SQL expression with transformation, or just column reference if no transform needed

        """
        # Normalize types: strip parameters (e.g., "NUMBER(19,0)" → "NUMBER",
        # "TIMESTAMP_NTZ(6)" → "TIMESTAMP_NTZ") so lookups match correctly.
        from_type_normalized = _normalize_base_type(from_type.upper())
        to_type_normalized = _normalize_base_type(to_type.upper())
        # Preserve full type with parameters for SQL casts (e.g., "CHAR(25)")
        to_type_cast = to_type.upper()
        source_type_normalized = source_type.upper() if source_type else None

        # Check source-type-aware special cases first
        special_case = self._try_source_type_transformation(
            from_type_normalized,
            to_type_normalized,
            column_name,
            source_type_normalized,
            to_type_cast,
        )
        if special_case is not None:
            return special_case

        if from_type_normalized == to_type_normalized:
            if to_type_normalized in ALWAYS_CAST_TYPES:
                return f'$1:"{column_name}"::{to_type_cast}'
            # Cast when the target type has explicit parameters (e.g., CHAR(25),
            # VARCHAR(152), NUMBER(10,2)) to preserve the intended precision/length.
            if to_type_cast != to_type_normalized:
                return f'$1:"{column_name}"::{to_type_cast}'
            return f'$1:"{column_name}"'

        spatial_fn = _SPATIAL_COPY_INTO_CONSTRUCTORS.get(to_type_normalized)
        if spatial_fn is not None:
            return f'{spatial_fn}($1:"{column_name}"::VARCHAR)'

        key = (from_type_normalized, to_type_normalized)
        if key in self.TRANSFORMATIONS:
            template = self.TRANSFORMATIONS[key]
            return template.format(col=f'$1:"{column_name}"') + f"::{to_type_cast}"

        return f'$1:"{column_name}"::{to_type_cast}'

    def _try_source_type_transformation(
        self,
        from_type: str,
        to_type: str,
        column_name: str,
        source_type: str | None,
        to_type_cast: str | None = None,
    ) -> str | None:
        """
        Check source-type-aware special cases that override normal transformation logic.

        Some conversions depend on the original source database type, not just the
        Parquet/file type and target Snowflake type. This method centralizes those
        checks so the main get_transformation method stays focused on general logic.

        Args:
            from_type: Normalized file/intermediate type (e.g., "NUMBER", "BOOLEAN")
            to_type: Normalized target Snowflake type
            column_name: Column name for building the SQL expression
            source_type: Normalized original source database type, or None
            to_type_cast: Full target type with parameters for SQL casts (e.g., "BOOLEAN").
                         Falls back to to_type if not provided.

        Returns:
            SQL expression if a special case matches, None otherwise

        """
        cast_type = to_type_cast or to_type

        result = self._try_boolean_from_integer(
            to_type, column_name, source_type, cast_type
        )
        if result is not None:
            return result

        result = self._try_epoch_timestamp(
            from_type, to_type, column_name, source_type, cast_type
        )
        if result is not None:
            return result

        return None

    def _try_boolean_from_integer(
        self,
        to_type: str,
        column_name: str,
        source_type: str | None,
        to_type_cast: str,
    ) -> str | None:
        """
        Handle source types that store booleans as integers (e.g., SQL Server BIT).

        We must first cast the VARIANT to NUMBER before TO_BOOLEAN, otherwise
        Snowflake throws "Failed to cast variant value 1 to BOOLEAN".

        Args:
            to_type: Normalized target Snowflake type
            column_name: Column name for building the SQL expression
            source_type: Normalized original source database type, or None
            to_type_cast: Full target type with parameters for the final cast

        Returns:
            SQL expression if this special case matches, None otherwise

        """
        if source_type in SOURCE_TYPES_REQUIRING_TO_BOOLEAN and to_type == "BOOLEAN":
            return f'TO_BOOLEAN($1:"{column_name}"::NUMBER)::{to_type_cast}'
        return None

    def _try_epoch_timestamp(
        self,
        from_type: str,
        to_type: str,
        column_name: str,
        source_type: str | None,
        to_type_cast: str,
    ) -> str | None:
        """
        Handle Parquet timestamps read as NUMBER (epoch microseconds).

        When Snowflake's USE_LOGICAL_TYPE is disabled, PyArrow INT64 timestamps
        (epoch microseconds) appear as NUMBER in INFER_SCHEMA. A plain ::TIMESTAMP_NTZ
        cast would interpret microseconds as seconds, producing dates millions of years
        in the future. We use TO_TIMESTAMP_* with scale 6 (microseconds) instead.

        Args:
            from_type: Normalized file/intermediate type
            to_type: Normalized target Snowflake type
            column_name: Column name for building the SQL expression
            source_type: Normalized original source database type, or None
            to_type_cast: Full target type with parameters for the final cast

        Returns:
            SQL expression if this special case matches, None otherwise

        """
        if (
            from_type == "NUMBER"
            and to_type in SNOWFLAKE_TIMESTAMP_TYPES
            and source_type in SOURCE_DATETIME_TYPES
        ):
            to_func = f"TO_{to_type}"
            return f'{to_func}($1:"{column_name}"::NUMBER, 6)::{to_type_cast}'
        return None

    def get_csv_transformation(
        self,
        to_type: str,
        column_position: int,
        source_type: str | None = None,
    ) -> str:
        """
        Get SQL transformation expression for CSV type conversion.

        Uses positional column access syntax ($N) for CSV files.

        Args:
            to_type: Target Snowflake type (e.g., "VARCHAR", "NUMBER")
            column_position: 1-based column position in CSV file
            source_type: Optional original source database type (e.g., "BIT" from SQL Server)
                        Used to apply special transformations for types that store
                        boolean-like data as integers.

        Returns:
            SQL expression with transformation for CSV column

        """
        to_type_full = to_type.upper()
        to_type_base = _normalize_base_type(to_type_full)
        source_type_normalized = source_type.upper() if source_type else None
        col_ref = f"${column_position}"

        # Handle BIT -> BOOLEAN conversion for CSV
        if (
            source_type_normalized in SOURCE_TYPES_REQUIRING_TO_BOOLEAN
            and to_type_base == "BOOLEAN"
        ):
            return f"TO_BOOLEAN({col_ref}::NUMBER)::{to_type_full}"

        # BCP exports empty strings as a single null-byte (0x00) because empty
        # strings represent NULL in SQL Server.  Convert that sentinel back to ''.
        if to_type_base in CSV_TEXT_TYPES:
            return f"IFF({col_ref} = CHR(0), '', {col_ref})::{to_type_full}"

        # For CSV, we always cast to the target type since CSV data is text
        return f"{col_ref}::{to_type_full}"


# Automatic category detection based on Snowflake type
SNOWFLAKE_TYPE_TO_CATEGORY = {
    "NUMBER": TypeMappingCategory.NUMERIC,
    "FLOAT": TypeMappingCategory.FLOAT,
    "BOOLEAN": TypeMappingCategory.LOGICAL,
    "VARCHAR": TypeMappingCategory.CHARACTER,
    "STRING": TypeMappingCategory.CHARACTER,
    "TEXT": TypeMappingCategory.CHARACTER,
    "CHAR": TypeMappingCategory.CHARACTER,
    "DATE": TypeMappingCategory.DATE,
    "TIME": TypeMappingCategory.TIME,
    "TIMESTAMP_NTZ": TypeMappingCategory.TIMESTAMP,
    "TIMESTAMP_TZ": TypeMappingCategory.TIMESTAMP,
    "TIMESTAMP_LTZ": TypeMappingCategory.TIMESTAMP,
    "DATETIME": TypeMappingCategory.DATETIME,
    "BINARY": TypeMappingCategory.BINARY,
    "VARBINARY": TypeMappingCategory.BINARY,
    "VARIANT": TypeMappingCategory.VARIANT,
    "OBJECT": TypeMappingCategory.VARIANT,
    "ARRAY": TypeMappingCategory.VARIANT,
    "GEOGRAPHY": TypeMappingCategory.GEOGRAPHY,
    "GEOMETRY": TypeMappingCategory.GEOGRAPHY,
}

# LOB types detection based on source type name patterns
LOB_TYPE_PATTERNS = ["TEXT", "NTEXT", "IMAGE", "CLOB", "BLOB", "LONG"]


class TypeMappingLoader:
    """
    Loads and manages type mappings with support for custom overrides.

    This class handles loading type mappings from hardcoded defaults
    and supports custom override files (YAML, JSON, or other formats in the future)
    for user-defined mappings.

    Default mappings are hardcoded in Python for performance and are based on
    the snowflake-data-validation project. Users can override any mapping or
    add new ones using custom configuration files.

    Supported custom file formats:
    1. Simple format: SOURCE_TYPE: SNOWFLAKE_TYPE
    2. Detailed format: SOURCE_TYPE: {snowflake_type, category, is_lob, notes}

    Attributes:
        source_type: The source database type (e.g., "sqlserver")
        custom_mappings_file: Optional path to custom mappings file
        _source_info: Cached SourceTypeInfo object with loaded mappings

    """

    def __init__(
        self,
        source_type: str | SourceType,
        custom_mappings_file: str | Path | None = None,
        *,
        _preloaded_mappings: dict[str, TypeMapping] | None = None,
    ):
        """
        Initialize the type mapping loader.

        Args:
            source_type: The source database type (e.g., "sqlserver", "postgresql")
            custom_mappings_file: Optional path to a custom mappings file that will
                                 override default mappings. Can be absolute or relative path.
                                 Supports YAML format currently. Future: JSON support.
            _preloaded_mappings: Internal parameter for creating loaders with pre-loaded
                                mappings (used by with_table_overrides). Do not use directly.

        Raises:
            ValueError: If the source type is not supported (no default mappings found)

        """
        if isinstance(source_type, SourceType):
            self.source_type = source_type.value
        else:
            self.source_type = source_type.lower()

        self.custom_mappings_file = (
            Path(custom_mappings_file) if custom_mappings_file else None
        )
        self._source_info: SourceTypeInfo | None = None

        if _preloaded_mappings is not None:
            self._source_info = SourceTypeInfo(
                source_system=self.source_type,
                mappings=_preloaded_mappings,
            )
        else:
            self._load_mappings()

    def _load_mappings(self) -> None:
        """
        Load type mappings from hardcoded defaults and custom overrides.

        Loads hardcoded default mappings first, then applies custom overrides if provided.
        Custom mappings will override default mappings for matching source types.

        """
        # Load hardcoded default mappings
        default_mappings_dict = get_default_mappings(self.source_type)

        if default_mappings_dict is None:
            raise ValueError(
                f"No default type mappings found for source type '{self.source_type}'. "
                f"Available types: {', '.join(get_default_source_types())}"
            )

        # Convert simple dict to TypeMapping objects
        mappings = self._convert_simple_mappings(default_mappings_dict)

        logger.info(
            f"Loaded {len(mappings)} hardcoded default type mappings for '{self.source_type}'"
        )

        # Apply custom overrides if provided
        if self.custom_mappings_file:
            if not self.custom_mappings_file.exists():
                logger.warning(
                    f"Custom mappings file not found: {self.custom_mappings_file}, using defaults only"
                )
            else:
                try:
                    custom_mappings = self._load_mappings_from_file(
                        self.custom_mappings_file
                    )
                    # Override default mappings with custom ones
                    mappings.update(custom_mappings)
                    overridden_count = len(custom_mappings)
                    logger.info(
                        f"Applied {overridden_count} custom type mapping overrides "
                        f"from {self.custom_mappings_file.name}"
                    )
                except Exception as e:
                    logger.error(
                        f"Failed to load custom mappings: {e}, using defaults only"
                    )

        self._source_info = SourceTypeInfo(
            source_system=self.source_type,
            mappings=mappings,
        )

        logger.info(
            f"Successfully loaded {len(mappings)} total type mappings for '{self.source_type}'"
        )

    def _convert_simple_mappings(
        self, simple_mappings: dict[str, str]
    ) -> dict[str, TypeMapping]:
        """
        Convert simple string mappings to TypeMapping objects.

        Args:
            simple_mappings: Dictionary of SOURCE_TYPE: SNOWFLAKE_TYPE

        Returns:
            Dictionary of SOURCE_TYPE to TypeMapping objects

        """
        mappings: dict[str, TypeMapping] = {}

        for source_type, snowflake_type in simple_mappings.items():
            category = self._detect_category(snowflake_type)
            is_lob = self._detect_lob_type(source_type)

            type_mapping = TypeMapping(
                source_type=source_type,
                snowflake_type=snowflake_type,
                category=category,
                is_lob=is_lob,
                notes=None,
            )

            mappings[source_type.upper()] = type_mapping

        return mappings

    def _load_mappings_from_file(self, file_path: Path) -> dict[str, TypeMapping]:
        """
        Load type mappings from a specific YAML file.

        Supports two formats:
        1. Simple format: SOURCE_TYPE: SNOWFLAKE_TYPE
           - Category is auto-detected from Snowflake type
           - LOB detection based on source type name patterns

        2. Detailed format: SOURCE_TYPE: {snowflake_type, category, is_lob, notes}
           - Explicit control over all fields
           - Category can be omitted for auto-detection

        Args:
            file_path: Path to the YAML file

        Returns:
            Dictionary of source types (uppercase) to TypeMapping objects

        """
        try:
            with open(file_path, encoding="utf-8") as f:
                yaml_data = yaml.safe_load(f)

            if not yaml_data:
                logger.warning(f"Mapping file is empty: {file_path}")
                return {}

            mappings: dict[str, TypeMapping] = {}

            for source_type, mapping_data in yaml_data.items():
                # Skip comments and empty entries
                if source_type.startswith("#") or mapping_data is None:
                    continue

                # Handle simple format: SOURCE_TYPE: SNOWFLAKE_TYPE
                if isinstance(mapping_data, str):
                    snowflake_type = mapping_data
                    category = self._detect_category(snowflake_type)
                    is_lob = self._detect_lob_type(source_type)
                    notes = None

                # Handle detailed format with dict
                elif isinstance(mapping_data, dict):
                    snowflake_type = mapping_data.get("snowflake_type")
                    if not snowflake_type:
                        logger.warning(
                            f"Skipping '{source_type}' in {file_path.name}: missing snowflake_type"
                        )
                        continue

                    # Category can be explicit or auto-detected
                    category_str = mapping_data.get("category")
                    if category_str:
                        try:
                            category = TypeMappingCategory(category_str)
                        except ValueError:
                            logger.warning(
                                f"Invalid category '{category_str}' for '{source_type}' in {file_path.name}, "
                                f"auto-detecting"
                            )
                            category = self._detect_category(snowflake_type)
                    else:
                        category = self._detect_category(snowflake_type)

                    # LOB flag can be explicit or auto-detected
                    is_lob = mapping_data.get(
                        "is_lob", self._detect_lob_type(source_type)
                    )
                    notes = mapping_data.get("notes")

                else:
                    logger.warning(
                        f"Skipping '{source_type}' in {file_path.name}: invalid format {type(mapping_data)}"
                    )
                    continue

                # Create TypeMapping object
                type_mapping = TypeMapping(
                    source_type=source_type,
                    snowflake_type=snowflake_type,
                    category=category,
                    is_lob=is_lob,
                    notes=notes,
                )

                mappings[source_type.upper()] = type_mapping

            return mappings

        except yaml.YAMLError as e:
            raise ValueError(
                f"Failed to parse YAML mapping file: {file_path}\n{str(e)}"
            ) from e
        except Exception as e:
            raise ValueError(
                f"Failed to load type mappings from: {file_path}\n{str(e)}"
            ) from e

    def _detect_category(self, snowflake_type: str) -> TypeMappingCategory:
        """
        Auto-detect category from Snowflake type.

        Args:
            snowflake_type: The Snowflake data type

        Returns:
            Detected TypeMappingCategory, defaults to OTHER if unknown

        """
        snowflake_type_upper = snowflake_type.upper()

        # Direct lookup
        if snowflake_type_upper in SNOWFLAKE_TYPE_TO_CATEGORY:
            return SNOWFLAKE_TYPE_TO_CATEGORY[snowflake_type_upper]

        # Pattern matching for parameterized types (e.g., VARCHAR(100))
        for type_prefix, category in SNOWFLAKE_TYPE_TO_CATEGORY.items():
            if snowflake_type_upper.startswith(type_prefix):
                return category

        logger.debug(f"Unknown Snowflake type '{snowflake_type}', defaulting to OTHER")
        return TypeMappingCategory.OTHER

    def _detect_lob_type(self, source_type: str) -> bool:
        """
        Auto-detect if a source type is a LOB (Large Object) type.

        LOB types typically require special handling during migration.

        Args:
            source_type: The source database type name

        Returns:
            True if detected as LOB type, False otherwise

        """
        source_type_upper = source_type.upper()
        return any(pattern in source_type_upper for pattern in LOB_TYPE_PATTERNS)

    def get_mapping(self, source_type: str) -> TypeMapping | None:
        """
        Get the complete type mapping for a source type.

        Args:
            source_type: The source database type name (case-insensitive)

        Returns:
            TypeMapping object if found, None otherwise


        """
        if not self._source_info:
            return None
        return self._source_info.get_mapping(source_type)

    def get_snowflake_type(self, source_type: str) -> str | None:
        """
        Get the Snowflake type for a source type.

        Args:
            source_type: The source database type name (case-insensitive)

        Returns:
            Snowflake type name if mapping found, None otherwise


        """
        if not self._source_info:
            return None
        return self._source_info.get_snowflake_type(source_type)

    def get_all_mappings(self) -> dict[str, TypeMapping]:
        """
        Get all type mappings as a dictionary.

        Returns:
            Dictionary mapping source types to TypeMapping objects


        """
        if not self._source_info:
            return {}
        return self._source_info.mappings.copy()

    def list_all_source_types(self) -> list[str]:
        """
        Get a sorted list of all supported source types.

        Returns:
            Sorted list of source type names

        """
        if not self._source_info:
            return []
        return self._source_info.list_all_source_types()

    def list_by_category(self, category: TypeMappingCategory) -> list[TypeMapping]:
        """
        Get all type mappings in a specific category.

        Args:
            category: The category to filter by

        Returns:
            List of TypeMapping objects in the specified category

        """
        if not self._source_info:
            return []
        return self._source_info.list_by_category(category)

    def is_lob_type(self, source_type: str) -> bool:
        """
        Check if a source type is a Large Object (LOB) type.

        Args:
            source_type: The source database type name (case-insensitive)

        Returns:
            True if the type is a LOB type, False otherwise

        """
        mapping = self.get_mapping(source_type)
        return mapping.is_lob if mapping else False

    def get_category(self, source_type: str) -> TypeMappingCategory | None:
        """
        Get the category for a source type.

        Args:
            source_type: The source database type name (case-insensitive)

        Returns:
            TypeMappingCategory if found, None otherwise

        """
        mapping = self.get_mapping(source_type)
        return mapping.category if mapping else None

    @staticmethod
    def get_available_source_types() -> list[str]:
        """
        Get a list of all available source types with default mappings.

        Returns:
            List of source type names that have hardcoded default mappings

        """
        return get_default_source_types()

    def with_table_overrides(
        self,
        overrides: dict[str, str] | None,
    ) -> TypeMappingLoader:
        """
        Create a new loader with table-specific type mapping overrides applied.

        This method returns a new TypeMappingLoader instance that has all the
        current mappings plus the provided overrides. The overrides take
        precedence over existing mappings.

        Args:
            overrides: Dict mapping source types to target types
                      (e.g., {"MONEY": "DECIMAL(19,4)", "BIT": "BOOLEAN"}),
                      or None/empty dict (returns self unchanged).

        Returns:
            A new TypeMappingLoader with overrides applied, or self if no overrides

        """
        if not overrides:
            return self

        new_mappings = self.get_all_mappings()

        # Apply overrides
        for source_type, target_type in overrides.items():
            # Normalize to uppercase
            source_type_upper = source_type.upper()
            target_type_upper = target_type.upper()

            # Create new TypeMapping for the override
            category = self._detect_category(target_type_upper)
            is_lob = self._detect_lob_type(source_type_upper)

            new_mappings[source_type_upper] = TypeMapping(
                source_type=source_type_upper,
                snowflake_type=target_type_upper,
                category=category,
                is_lob=is_lob,
                notes="Table-level override",
            )

            logger.debug(
                f"Applied table-level type override: {source_type_upper} -> {target_type_upper}"
            )

        logger.info(f"Created loader with {len(overrides)} table-level type overrides")

        # Create new loader with the combined mappings
        return TypeMappingLoader(
            source_type=self.source_type,
            _preloaded_mappings=new_mappings,
        )

    def _resolve_target_type(
        self,
        column_name: str,
        source_type: str,
        target_types: dict[str, str] | None,
    ) -> str | None:
        """
        Resolve the target type for a column, preferring actual schema types.

        The existing target table is the source of truth. When ``target_types``
        is provided (e.g., from the existing table schema), its type takes
        precedence -- even if it disagrees with the generic source-to-Snowflake
        mapping.  This handles cases where the DDL was created externally
        (e.g., by SnowConvert) with types that differ from our default mappings.

        Falls back to the generic mapped type from ``get_snowflake_type`` only
        when no ``target_types`` entry exists for the column.

        Args:
            column_name: Column name (will be uppercased for lookup)
            source_type: Source database type (used for generic mapping fallback)
            target_types: Optional dict mapping column names (uppercase) to full
                target types from the actual table schema

        Returns:
            Full target type string, or None if no mapping found

        """
        if target_types:
            actual_type = target_types.get(column_name.upper())
            if actual_type:
                return actual_type
        return self.get_snowflake_type(source_type)

    def generate_copy_into_column_list(
        self,
        columns: list[tuple[str, str]],
        parquet_schema: dict[str, str] | None = None,
        format_name: str | None = None,
        target_types: dict[str, str] | None = None,
    ) -> str:
        """
        Generate COPY INTO column list with type transformations.

        Args:
            columns: List of (column_name, source_type) tuples from source database
            parquet_schema: Optional dict mapping column names to Parquet types
            format_name: Optional file format name
            target_types: Optional dict mapping column names (uppercase) to their full
                target types from the actual table schema (e.g., {"N_NAME": "CHAR(25)"}).
                When provided, these override the generic mapped types for casts.

        Returns:
            Formatted column list for COPY INTO statement

        """
        transformation_engine = TypeTransformationEngine()
        column_expressions = []

        for column_name, source_type in columns:
            mapped_type = self.get_snowflake_type(source_type)
            target_type = self._resolve_target_type(
                column_name, source_type, target_types
            )

            if not target_type:
                column_expressions.append(f"${column_name}")
                logger.warning(
                    f"No mapping found for '{source_type}', "
                    f"column '{column_name}' will not be cast"
                )
                continue

            if parquet_schema:
                parquet_type = parquet_schema.get(
                    column_name.upper(), mapped_type or target_type
                )
            else:
                parquet_type = mapped_type or target_type

            transformation = transformation_engine.get_transformation(
                from_type=parquet_type,
                to_type=target_type,
                column_name=column_name,
                source_type=source_type,
            )

            if transformation != f"${column_name}":
                column_expressions.append(f"{transformation} AS {column_name}")
            else:
                column_expressions.append(f"${column_name}")

        return ",\n    ".join(column_expressions)

    def generate_copy_into_statement(
        self,
        target_table: str,
        columns: list[tuple[str, str]],
        stage_location: str,
        file_schema: dict[str, str] | None = None,
        column_name_mappings: dict[str, str] | None = None,
        file_type: FileType = FileType.PARQUET,
        target_types: dict[str, str] | None = None,
    ) -> str:
        """
        Generate a COPY INTO statement for the specified file type.

        Args:
            target_table: The target Snowflake table name
            columns: List of (column_name, source_type) tuples from source database
            stage_location: Stage location (e.g., @my_stage/path/)
            file_schema: Optional dict mapping column names to their types in the file
            column_name_mappings: Optional dict mapping source column names to target
                column names (e.g., {"id": "old_id"})
            file_type: File type (FileType.PARQUET or FileType.CSV)
            target_types: Optional dict mapping column names (uppercase) to their full
                target types from the actual table schema (e.g., {"N_NAME": "CHAR(25)"}).
                When provided, these override the generic mapped types for casts.

        Returns:
            COPY INTO SQL statement

        """
        transformation_engine = TypeTransformationEngine()

        if file_type == FileType.CSV:
            select_clause = self._generate_csv_select(
                columns=columns,
                stage_location=stage_location,
                column_name_mappings=column_name_mappings,
                transformation_engine=transformation_engine,
                target_types=target_types,
            )
        else:
            select_clause = self._generate_parquet_select(
                columns=columns,
                stage_location=stage_location,
                file_schema=file_schema,
                column_name_mappings=column_name_mappings,
                transformation_engine=transformation_engine,
                target_types=target_types,
            )

        return f"""COPY INTO {target_table}
FROM (
{select_clause}
)"""

    def _generate_parquet_select(
        self,
        columns: list[tuple[str, str]],
        stage_location: str,
        file_schema: dict[str, str] | None,
        column_name_mappings: dict[str, str] | None,
        transformation_engine: TypeTransformationEngine,
        target_types: dict[str, str] | None = None,
    ) -> str:
        """
        Generate SELECT statement for Parquet files.

        Args:
            columns: List of (column_name, source_type) tuples
            stage_location: Stage location path
            file_schema: Optional dict mapping column names to their Parquet types
            column_name_mappings: Optional column name mappings
            transformation_engine: TypeTransformationEngine instance
            target_types: Optional dict mapping column names (uppercase) to their full
                target types from the actual table schema

        Returns:
            SELECT statement string for Parquet files

        """
        column_expressions = []

        for column_name, source_type in columns:
            mapped_type = self.get_snowflake_type(source_type)
            target_type = self._resolve_target_type(
                column_name, source_type, target_types
            )

            # Determine target column name
            target_column_name = column_name
            if column_name_mappings:
                target_column_name = column_name_mappings.get(column_name, column_name)

            if not target_type:
                column_expressions.append(
                    f'$1:"{column_name}" AS "{target_column_name}"'
                )
                logger.warning(
                    f"No mapping found for '{source_type}', "
                    f"column '{column_name}' will not be cast"
                )
                continue

            if file_schema:
                file_column_type = file_schema.get(
                    column_name.upper(), mapped_type or target_type
                )
            else:
                file_column_type = mapped_type or target_type

            transformation = transformation_engine.get_transformation(
                from_type=file_column_type,
                to_type=target_type,
                column_name=column_name,
                source_type=source_type,
            )

            column_expressions.append(f'{transformation} AS "{target_column_name}"')

        select_list = ",\n        ".join(column_expressions)

        return f"""    SELECT
        {select_list}
    FROM {stage_location}
    (FILE_FORMAT => '{PARQUET_FILE_FORMAT}',
        PATTERN => '.*[.]parquet')"""

    def _generate_csv_select(
        self,
        columns: list[tuple[str, str]],
        stage_location: str,
        column_name_mappings: dict[str, str] | None,
        transformation_engine: TypeTransformationEngine,
        target_types: dict[str, str] | None = None,
    ) -> str:
        """
        Generate SELECT statement for CSV files.

        Args:
            columns: List of (column_name, source_type) tuples
            stage_location: Stage location path
            column_name_mappings: Optional column name mappings
            transformation_engine: TypeTransformationEngine instance
            target_types: Optional dict mapping column names (uppercase) to their full
                target types from the actual table schema

        Returns:
            SELECT statement string for CSV files

        """
        column_expressions = []

        for position, (column_name, source_type) in enumerate(columns, start=1):
            target_type = self._resolve_target_type(
                column_name, source_type, target_types
            )

            # Determine target column name
            target_column_name = column_name
            if column_name_mappings:
                target_column_name = column_name_mappings.get(column_name, column_name)

            if not target_type:
                # No mapping found, use direct positional reference as VARCHAR
                column_expressions.append(f'${position} AS "{target_column_name}"')
                logger.warning(
                    f"No mapping found for '{source_type}', "
                    f"column '{column_name}' will not be cast (CSV)"
                )
                continue

            transformation = transformation_engine.get_csv_transformation(
                to_type=target_type,
                column_position=position,
                source_type=source_type,
            )

            column_expressions.append(f'{transformation} AS "{target_column_name}"')

        select_list = ",\n        ".join(column_expressions)

        return f"""    SELECT
        {select_list}
    FROM {stage_location}
    (FILE_FORMAT => '{CSV_FILE_FORMAT}',
        PATTERN => '.*[.]csv([.]gz)?')"""
