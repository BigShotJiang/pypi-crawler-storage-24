"""
Scope utilities for building hierarchical task scopes.

This module provides a builder pattern for constructing task scopes that describe
what resources/objects a task applies to. Scopes follow a hierarchical format like:
    Table[DB.SCHEMA.TABLE]::Preprocessing
    Table[DB.SCHEMA.TABLE]::Partition[2]::Extraction
    Table[DB.SCHEMA.TABLE]::Partition[2]::Loading
"""

from __future__ import annotations

from enum import StrEnum

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from shared.enums.source_type import SourceType


class ScopeOperation(StrEnum):
    """Operations that can be performed on a scope."""

    PREPROCESSING = "Preprocessing"
    EXTRACTION = "Extraction"
    LOADING = "Loading"


class ScopeBuilder:
    """
    Builder for constructing hierarchical task scopes.

    Usage:
        # Table-level preprocessing scope
        scope = ScopeBuilder.for_table("DB.SCHEMA.TABLE").preprocessing()
        # Returns: "Table[DB.SCHEMA.TABLE]::Preprocessing"

        # Partition-level extraction scope
        scope = ScopeBuilder.for_table("DB.SCHEMA.TABLE").partition(2).extraction()
        # Returns: "Table[DB.SCHEMA.TABLE]::Partition[2]::Extraction"

        # Partition-level loading scope
        scope = ScopeBuilder.for_table("DB.SCHEMA.TABLE").partition(2).loading()
        # Returns: "Table[DB.SCHEMA.TABLE]::Partition[2]::Loading"
    """

    FRAGMENT_SEPARATOR = "::"

    def __init__(self) -> None:
        """Initialize an empty scope builder."""
        self._fragments: list[str] = []

    @classmethod
    def for_table(
        cls, table_name: TableIdentifier, source_type: SourceType
    ) -> ScopeBuilder:
        """
        Create a scope builder for a specific table.

        Args:
            table_name: The fully qualified table name (e.g., 'DB.SCHEMA.TABLE'). Must be normalized.
            source_type: The source type of the table.

        Returns:
            A ScopeBuilder instance with the table fragment set.

        """
        builder = cls()
        fully_qualfied_normalized_table_name = (
            table_name.get_fully_qualified_normalized_name(source_type)
        )
        builder._fragments.append(f"Table[{fully_qualfied_normalized_table_name}]")
        return builder

    def partition(self, partition_id: int) -> ScopeBuilder:
        """
        Add a partition fragment to the scope.

        Args:
            partition_id: The partition identifier.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If partition_id is negative.

        """
        if partition_id < 0:
            raise ValueError(f"Partition ID must be non-negative, got {partition_id}")
        self._fragments.append(f"Partition[{partition_id}]")
        return self

    def preprocessing(self) -> str:
        """
        Build a preprocessing scope.

        Returns:
            The complete scope string ending with ::Preprocessing.

        """
        return self._build_with_operation(ScopeOperation.PREPROCESSING)

    def extraction(self) -> str:
        """
        Build an extraction scope.

        Returns:
            The complete scope string ending with ::Extraction.

        """
        return self._build_with_operation(ScopeOperation.EXTRACTION)

    def loading(self) -> str:
        """
        Build a loading scope.

        Returns:
            The complete scope string ending with ::Loading.

        """
        return self._build_with_operation(ScopeOperation.LOADING)

    def _build_with_operation(self, operation: ScopeOperation) -> str:
        """
        Build the scope string with the given operation.

        Args:
            operation: The operation to append.

        Returns:
            The complete scope string.

        Raises:
            ValueError: If no fragments have been added to the builder.

        """
        if not self._fragments:
            raise ValueError(
                "Cannot build scope without any fragments. Use for_table() first."
            )
        fragments = self._fragments + [operation.value]
        return self.FRAGMENT_SEPARATOR.join(fragments)

    def build(self) -> str:
        """
        Build the current scope string without an operation suffix.

        This is useful for building partial scopes for LIKE queries.

        Returns:
            The scope string with current fragments.

        Raises:
            ValueError: If no fragments have been added to the builder.

        """
        if not self._fragments:
            raise ValueError(
                "Cannot build scope without any fragments. Use for_table() first."
            )
        return self.FRAGMENT_SEPARATOR.join(self._fragments)


def build_table_preprocessing_scope(
    table_name: TableIdentifier, source_type: SourceType
) -> str:
    """
    Build a table-level preprocessing scope.

    Convenience function for the common case of creating a preprocessing scope.

    Args:
        table_name: The fully qualified table name.
        source_type: The source type of the table.

    Returns:
        A preprocessing scope string like "Table[DB.SCHEMA.TABLE]::Preprocessing".

    """
    return ScopeBuilder.for_table(table_name, source_type).preprocessing()


def build_partition_extraction_scope(
    table_name: TableIdentifier, partition_id: int, source_type: SourceType
) -> str:
    """
    Build a partition-level extraction scope.

    Args:
        table_name: The fully qualified table name.
        partition_id: The partition identifier.
        source_type: The source type of the table.

    Returns:
        An extraction scope string like "Table[DB.SCHEMA.TABLE]::Partition[2]::Extraction".

    """
    return (
        ScopeBuilder.for_table(table_name, source_type)
        .partition(partition_id)
        .extraction()
    )


def build_partition_loading_scope(
    table_name: TableIdentifier, partition_id: int, source_type: SourceType
) -> str:
    """
    Build a partition-level loading scope.

    Args:
        table_name: The fully qualified table name.
        partition_id: The partition identifier.
        source_type: The source type of the table.

    Returns:
        A loading scope string like "Table[DB.SCHEMA.TABLE]::Partition[2]::Loading".

    """
    return (
        ScopeBuilder.for_table(table_name, source_type)
        .partition(partition_id)
        .loading()
    )
