"""
Data migration workflow initializer.

This module implements the workflow initializer for data migration workflows.
It creates the initial set of tasks for migrating tables from a source database
to Snowflake.
"""

import json

from data_migration_orchestrator.cloud_core.constants.priorities import (
    PRIORITY_FOR_FAN_OUT_TASKS,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_core.workflows.base_workflow_initializer import (
    BaseWorkflowInitializer,
)
from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.data_migration_cloud.config import (
    configuration_properties_keys,
)
from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
    ConfigurationParser,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableConfiguration,
)
from data_migration_orchestrator.data_migration_cloud.config.workflow_configuration_schema import (
    validate_workflow_configuration,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    DEFAULT_INTERNAL_STAGE,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.scope import ScopeBuilder
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_reuse_service import (
    PartitionReuseService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CreatePartitionTasksPayload,
    DataMovementTaskPayload,
    DeterminePartitionStrategyTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    stage_path_for_metadata,
    stage_path_for_schema,
)
from data_migration_orchestrator.data_migration_core.queries.table_metadata import (
    build_metadata_query,
    build_schema_query,
)
from data_migration_orchestrator.utils.sql_utils import escape_sql_string
from shared.enums.source_type import SourceType


logger = get_logger("data_migration_workflow_initializer")


class DataMigrationWorkflowInitializer(BaseWorkflowInitializer):
    """
    Workflow initializer for data migration workflows.

    This initializer creates the initial set of tasks for migrating tables
    from a source database to Snowflake. For each table in the workflow
    configuration, it creates:
    1. Metadata extraction task
    2. Schema extraction task
    3. Partition strategy determination task (blocked until 1 and 2 complete)

    The partition strategy task then dynamically creates extraction and
    loading tasks based on the table size and partitioning strategy.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
        configuration_parser: ConfigurationParser | None = None,
    ):
        """
        Initialize the data migration workflow initializer.

        Args:
            task_queue: Task queue for pushing tasks
            warehouse_proxy: Proxy for executing warehouse operations
            configuration_parser: Parser for table configurations. If None, a default one is created.

        """
        super().__init__()
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy
        self.configuration_parser = configuration_parser or ConfigurationParser()
        self.partition_reuse_service = PartitionReuseService(warehouse_proxy)

    async def create_initial_tasks(self, workflow: Workflow) -> None:
        """
        Create the initial tasks for a data migration workflow.

        This method processes a workflow and creates the necessary tasks for each table
        in the workflow configuration. It iterates through all tables defined in the
        workflow's configuration and delegates task creation to _create_tasks_for_table.

        Args:
            workflow: The workflow object containing configuration and metadata for
                     task creation, including tables to migrate, source platform,
                     target cloud type, and target cloud stage name.

        Raises:
            ConfigurationError: If the workflow configuration is missing or invalid

        """
        validate_workflow_configuration(workflow.configuration)

        configuration = workflow.configuration
        assert (
            configuration is not None
        )  # guaranteed by validate_workflow_configuration

        raw_tables_config = configuration.get(configuration_properties_keys.TABLES, [])

        # Extract default table configuration (optional)
        default_table_config = configuration.get(
            configuration_properties_keys.DEFAULT_TABLE_CONFIGURATION
        )

        # Parse all table configurations using the ConfigurationParser
        # Each table config is merged with defaults before validation
        try:
            table_configurations = self.configuration_parser.parse_tables(
                raw_tables_config,
                default_config=default_table_config,
            )
        except ConfigurationError as e:
            logger.error(f"Invalid table configuration in workflow {workflow.id}: {e}")
            raise

        for table_config in table_configurations:
            await self._create_tasks_for_table(
                workflow_id=int(workflow.id),
                table_config=table_config,
                source_platform=workflow.source_platform,
                target_cloud_type=workflow.target_cloud_type,
            )

    async def _create_tasks_for_table(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        source_platform: SourceType,
        target_cloud_type: str,
    ):
        """
        Create the task chain for table migration with metadata-driven partitioning.

        For incremental sync, if the table was previously migrated, we reuse the existing
        partition definitions (copying TABLE_METADATA and PARTITION_METADATA rows) and skip
        the boundary analysis phase. The SYNCHRONIZATION_DATA is preserved for incremental sync.

        Task Flow (first migration):
        1. Metadata Extraction (DATA_MOVEMENT) - Extracts table metadata (runs immediately)
        2. Schema Extraction (DATA_MOVEMENT) - Extracts table schema (runs in parallel with metadata)
        3. Partition Strategy (DETERMINE_PARTITION_STRATEGY) - Waits for BOTH metadata and schema, then:
           - Analyzes metadata to determine partitioning strategy
           - Creates extraction + load tasks based on table size
           - Small tables: Creates single EXTRACT -> LOAD chain
           - Large tables: Creates ANALYZE -> PROCESS_RESULTS -> N × [EXTRACT -> LOAD] chains
        4. Load tasks (PROCESS_STAGED_DATA) - Use the schema for type mappings during COPY INTO

        Task Flow (incremental sync with existing partitions):
        1. Schema Extraction (DATA_MOVEMENT) - Extracts table schema (still needed for type mappings)
        2. Create Extraction Tasks (CREATE_PARTITION_TASKS_FROM_EXISTING) - Uses existing partitions
           - Skips metadata extraction and boundary analysis
           - Reuses partition definitions from previous workflow
           - Preserves SYNCHRONIZATION_DATA for incremental filtering

        Args:
            workflow_id: The ID of the workflow.
            table_config: Parsed TableConfiguration object with source, target, and mappings
            source_platform: The source platform type (e.g., 'sqlserver')
            target_cloud_type: The target cloud type (e.g., 'snowflake:stage')

        """
        # Extract table information from typed configuration
        fully_qualified_source_table_name = (
            table_config.source.get_fully_qualified_normalized_name(source_platform)
        )
        logger.info(f"Creating tasks for {fully_qualified_source_table_name}.")

        # Check for existing table metadata from previous workflows (incremental sync)
        existing_table_metadata_id: int | None = (
            await self.partition_reuse_service.find_existing_table_metadata(
                fully_qualified_source_table_name
            )
        )

        if existing_table_metadata_id:
            # Incremental sync: copy existing metadata and partitions
            await self._create_tasks_with_existing_partitions(
                workflow_id=workflow_id,
                table_config=table_config,
                source_platform=source_platform,
                target_cloud_type=target_cloud_type,
                existing_table_metadata_id=existing_table_metadata_id,
            )
        else:
            # First migration: full preprocessing flow
            await self._create_tasks_with_new_partitions(
                workflow_id=workflow_id,
                table_config=table_config,
                source_platform=source_platform,
                target_cloud_type=target_cloud_type,
            )

    async def _create_tasks_with_existing_partitions(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        source_platform: SourceType,
        target_cloud_type: str,
        existing_table_metadata_id: int,
    ):
        """
        Create tasks using existing partition definitions (incremental sync).

        Copies TABLE_METADATA and PARTITION_METADATA from a previous workflow,
        preserving SYNCHRONIZATION_DATA for incremental filtering.

        Args:
            workflow_id: The ID of the workflow
            table_config: Parsed TableConfiguration object
            source_platform: The source platform type
            target_cloud_type: The target cloud type
            existing_table_metadata_id: ID of existing TABLE_METADATA to copy from

        """
        fully_qualified_source_table_name = (
            table_config.source.get_fully_qualified_normalized_name(source_platform)
        )

        logger.info(
            f"Reusing existing partitions from table_metadata_id={existing_table_metadata_id} "
            f"for {fully_qualified_source_table_name} (incremental sync)"
        )

        # Serialize the current workflow's table configuration so it is stored
        # on the new TABLE_METADATA row instead of reusing the old config.
        table_config_dict = self._serialize_table_configuration(table_config)
        table_config_json = escape_sql_string(json.dumps(table_config_dict))
        table_config_param = f"PARSE_JSON('{table_config_json}')"

        # Copy table metadata (with current config) and all partitions (including SYNCHRONIZATION_DATA)
        copied = await self.partition_reuse_service.copy_table_and_partitions(
            source_table_metadata_id=existing_table_metadata_id,
            new_workflow_id=workflow_id,
            table_configuration_sql=table_config_param,
        )

        if not copied:
            logger.warning(
                f"Failed to copy existing partitions for {fully_qualified_source_table_name}, "
                f"falling back to full preprocessing"
            )
            await self._create_tasks_with_new_partitions(
                workflow_id=workflow_id,
                table_config=table_config,
                source_platform=source_platform,
                target_cloud_type=target_cloud_type,
            )
            return

        logger.info(
            f"Copied {copied.partitions_copied} partition(s) with SYNCHRONIZATION_DATA "
            f"for {fully_qualified_source_table_name}"
        )

        # Get partition column and target info
        partition_column = self._get_partition_column(table_config)
        fully_qualified_target_table_name = (
            table_config.target.get_fully_qualified_normalized_name(source_platform)
        )

        source_database_name = table_config.source.database_name
        source_schema_name = table_config.source.schema_name
        source_table_name = table_config.source.table_name

        if source_database_name is None or source_schema_name is None:
            raise ConfigurationError(
                f"Source database and schema names must be provided for {fully_qualified_source_table_name}"
            )

        # Get appropriate platform
        platform = PlatformRegistry.create_by_name_or_alias(source_platform)

        # Build preprocessing scope for this table
        preprocessing_scope = ScopeBuilder.for_table(
            table_config.source, platform.name
        ).preprocessing()

        # Build platform-specific USE database command
        use_database_command = platform.query_builder.build_use_database_command(
            source_database_name
        )

        # Create CREATE_PARTITION_TASKS task (not blocked - partitions already exist)
        # This task will read existing partitions and create extraction tasks

        # Get existing partitions to determine num_partitions
        existing_partitions = (
            await self.partition_reuse_service.get_existing_partitions(
                copied.new_table_metadata_id
            )
        )

        # Compute schema location deterministically for extraction task target
        # Schema is always stored on internal stage (PUT only works with internal stages)
        schema_location = stage_path_for_schema(
            DEFAULT_INTERNAL_STAGE, workflow_id, copied.new_table_metadata_id
        )

        # Paths are computed deterministically by the handler from workflow_id and table_metadata_id
        create_tasks_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                executor_type=ExecutorType.ORCHESTRATOR,
                task_name=f"Create extraction tasks (reusing partitions): {fully_qualified_source_table_name}",
                scope=preprocessing_scope,
                payload=CreatePartitionTasksPayload(
                    database=source_database_name,
                    schema=source_schema_name,
                    table_name=source_table_name,
                    source_type=source_platform,
                    num_partitions=len(existing_partitions),
                    target_table=fully_qualified_target_table_name,
                    partition_column=partition_column,
                    table_metadata_id=copied.new_table_metadata_id,
                ),
            )
            .with_priority(PRIORITY_FOR_FAN_OUT_TASKS)
            .blocked()
            .build()
        )
        create_tasks_task_id = await self.task_queue.push_task(create_tasks_task)

        schema_query = build_schema_query(
            source_platform, fully_qualified_source_table_name
        )
        schema_extract_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                task_name=f"Extract schema: {fully_qualified_source_table_name}",
                scope=preprocessing_scope,
                payload=DataMovementTaskPayload(
                    database=source_database_name,
                    schema=source_schema_name,
                    source_type=source_platform,
                    source_id="*",
                    target_type=target_cloud_type,
                    target_id=schema_location,
                    statement_location_id=schema_query,
                    use_database_command=use_database_command,
                ),
            )
            .with_successor(create_tasks_task_id)
            .build()
        )
        schema_extract_task_id = await self.task_queue.push_task(schema_extract_task)

        if schema_extract_task_id is None:
            raise Exception(
                f"Failed to queue schema extraction task for {fully_qualified_source_table_name}"
            )
        logger.info(
            f"Created incremental sync tasks for {fully_qualified_source_table_name}: "
            f"schema extraction -> create partition tasks (reusing {copied.partitions_copied} partitions)"
        )

    async def _create_tasks_with_new_partitions(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        source_platform: SourceType,
        target_cloud_type: str,
    ):
        """
        Create tasks with full preprocessing (first migration).

        This is the original flow for tables that haven't been migrated before.

        Args:
            workflow_id: The ID of the workflow
            table_config: Parsed TableConfiguration object
            source_platform: The source platform type
            target_cloud_type: The target cloud type

        """
        fully_qualified_source_table_name = (
            table_config.source.get_fully_qualified_normalized_name(source_platform)
        )
        fully_qualified_target_table_name = (
            table_config.target.get_fully_qualified_normalized_name(source_platform)
        )

        source_database_name = table_config.source.database_name
        source_schema_name = table_config.source.schema_name
        source_table_name = table_config.source.table_name

        if source_database_name is None or source_schema_name is None:
            raise ConfigurationError(
                f"Source database and schema names must be provided for {fully_qualified_source_table_name}"
            )

        # Get partition column (currently only single column supported)
        partition_column = self._get_partition_column(table_config)

        # Insert table metadata record and get the ID FIRST
        # so we can compute deterministic paths
        table_metadata_id = await self._insert_table_metadata(
            workflow_id,
            fully_qualified_source_table_name,
            table_config,
        )

        if table_metadata_id is None:
            raise Exception(
                f"Failed to insert table metadata for {fully_qualified_source_table_name}"
            )

        # Compute stage locations deterministically from identifiers
        # Metadata and schema are always stored on internal stage (PUT only works with internal stages)
        metadata_location = stage_path_for_metadata(
            DEFAULT_INTERNAL_STAGE, workflow_id, table_metadata_id
        )
        schema_location = stage_path_for_schema(
            DEFAULT_INTERNAL_STAGE, workflow_id, table_metadata_id
        )

        # Build preprocessing scope for this table
        preprocessing_scope = ScopeBuilder.for_table(
            table_config.source, source_platform
        ).preprocessing()

        # Step 1: Create DETERMINE_PARTITION_STRATEGY task
        # (blocked, will be unblocked when BOTH metadata and schema extraction complete)
        partition_strategy_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Determine partition strategy: {fully_qualified_source_table_name}",
                executor_type=ExecutorType.ORCHESTRATOR,
                scope=preprocessing_scope,
                payload=DeterminePartitionStrategyTaskPayload(
                    database=source_database_name,
                    schema=source_schema_name,
                    table_name=source_table_name,
                    source_type=source_platform,
                    target_table=fully_qualified_target_table_name,
                    partition_column=partition_column,
                    table_metadata_id=table_metadata_id,
                ),
            )
            .blocked()
            .build()
        )
        partition_strategy_task_id = await self.task_queue.push_task(
            partition_strategy_task
        )
        if partition_strategy_task_id is None:
            raise Exception(
                f"Failed to queue partition strategy task for {fully_qualified_source_table_name}"
            )

        # Build platform-specific USE database command
        platform = PlatformRegistry.create_by_name_or_alias(source_platform)
        use_database_command = platform.query_builder.build_use_database_command(
            source_database_name
        )

        # Step 2: Create metadata extraction task
        metadata_query = build_metadata_query(
            source_platform, fully_qualified_source_table_name
        )
        metadata_extract_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Extract metadata: {fully_qualified_source_table_name}",
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                scope=preprocessing_scope,
                payload=DataMovementTaskPayload(
                    database=source_database_name,
                    schema=source_schema_name,
                    source_type=source_platform,
                    source_id="*",
                    target_type=target_cloud_type,
                    target_id=metadata_location,
                    statement_location_id=metadata_query,
                    use_database_command=use_database_command,
                ),
            )
            .with_successor(partition_strategy_task_id)
            .build()
        )
        await self.task_queue.push_task(metadata_extract_task)

        # Step 3: Create schema extraction task
        schema_query = build_schema_query(
            source_platform, fully_qualified_source_table_name
        )
        schema_extract_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Extract schema: {fully_qualified_source_table_name}",
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                scope=preprocessing_scope,
                payload=DataMovementTaskPayload(
                    database=source_database_name,
                    schema=source_schema_name,
                    source_type=source_platform,
                    source_id="*",
                    target_type=target_cloud_type,
                    target_id=schema_location,
                    statement_location_id=schema_query,
                    use_database_command=use_database_command,
                ),
            )
            .with_successor(partition_strategy_task_id)
            .build()
        )
        await self.task_queue.push_task(schema_extract_task)

    def _get_partition_column(self, table_config: TableConfiguration) -> str:
        """
        Get the partition column from table configuration.

        Currently only supports a single partition column. The ConfigurationParser
        already validates that partition_columns is not empty.

        Args:
            table_config: The parsed TableConfiguration object

        Returns:
            The partition column name

        Raises:
            ValueError: If multiple partition columns are specified

        """
        partition_columns = table_config.partition_columns
        table_name = table_config.source.fully_qualified_friendly_name

        if len(partition_columns) > 1:
            raise ValueError(
                f"Multiple partition columns specified for {table_name}: "
                f"{partition_columns}. Only one partition column is currently supported."
            )

        partition_column = partition_columns[0]
        logger.info(f"Using partition column '{partition_column}' for {table_name}")
        return partition_column

    async def _insert_table_metadata(
        self,
        workflow_id: int,
        source_identifier: str,
        table_config: TableConfiguration,
    ) -> int | None:
        """
        Insert a table metadata record and return its ID.

        Args:
            workflow_id: The workflow ID
            source_identifier: Fully qualified source table name (must be normalized)
            table_config: The full table configuration to store

        Returns:
            The ID of the inserted table metadata record, or None if insertion failed

        """
        try:
            # Escape single quotes in the source identifier
            escaped_identifier = escape_sql_string(source_identifier)

            # Serialize full TableConfiguration as JSON for TABLE_CONFIGURATION column
            table_config_dict = self._serialize_table_configuration(table_config)
            table_config_json = escape_sql_string(json.dumps(table_config_dict))
            table_config_param = f"PARSE_JSON('{table_config_json}')"

            query = (
                f"CALL SNOWCONVERT_AI.DATA_MIGRATION.INSERT_TABLE_METADATA("
                f"{workflow_id}, '{escaped_identifier}', {table_config_param})"
            )
            result = await self.warehouse_proxy.execute_sync_query(query)
            if (
                result and len(result) > 0
            ):  # TODO: Get scalar value instead of list of rows
                # The stored procedure returns the new ID as the first (and only) column
                first_row = result[0]
                table_metadata_id = next(iter(first_row.values()), None)
                logger.info(
                    f"Inserted table metadata for {source_identifier} with ID {table_metadata_id}"
                )
                return table_metadata_id
            return None
        except Exception as e:
            logger.error(
                f"Failed to insert table metadata for {source_identifier}: {e}"
            )
            return None

    def _serialize_table_configuration(self, table_config: TableConfiguration) -> dict:
        """
        Serialize a TableConfiguration to a dictionary for JSON storage.

        Args:
            table_config: The table configuration to serialize

        Returns:
            Dictionary representation suitable for JSON serialization

        """
        return {
            configuration_properties_keys.SOURCE: {
                configuration_properties_keys.DATABASE_NAME: table_config.source.database_name,
                configuration_properties_keys.SCHEMA_NAME: table_config.source.schema_name,
                configuration_properties_keys.TABLE_NAME: table_config.source.table_name,
            },
            configuration_properties_keys.TARGET: {
                configuration_properties_keys.DATABASE_NAME: table_config.target.database_name,
                configuration_properties_keys.SCHEMA_NAME: table_config.target.schema_name,
                configuration_properties_keys.TABLE_NAME: table_config.target.table_name,
            },
            configuration_properties_keys.COLUMN_NAMES_TO_PARTITION_BY: table_config.partition_columns,
            configuration_properties_keys.COLUMN_TYPE_MAPPINGS: table_config.column_type_mappings,
            configuration_properties_keys.COLUMN_NAME_MAPPINGS: table_config.column_name_mappings,
            configuration_properties_keys.PRIMARY_KEY_COLUMNS: table_config.primary_key_columns,
            configuration_properties_keys.SYNCHRONIZATION: {
                configuration_properties_keys.STRATEGY: table_config.synchronization.strategy.value,
                configuration_properties_keys.WATERMARK_COLUMN: table_config.synchronization.watermark_column,
                configuration_properties_keys.TRACK_MODIFICATIONS: table_config.synchronization.track_modifications,
            },
            configuration_properties_keys.EXTRACTION: {
                configuration_properties_keys.STRATEGY: table_config.extraction.strategy.value,
                configuration_properties_keys.EXTERNAL_STAGE: table_config.extraction.external_stage,
            },
            configuration_properties_keys.WHERE_CLAUSE_CRITERIA: table_config.where_clause_criteria,
        }
