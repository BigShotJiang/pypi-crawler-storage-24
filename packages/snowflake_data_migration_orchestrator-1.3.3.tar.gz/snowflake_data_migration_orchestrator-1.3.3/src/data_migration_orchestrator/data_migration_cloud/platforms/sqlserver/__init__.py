"""
SQL Server platform implementation.

This package provides SQL Server-specific components for data migration:
    SqlServerPlatform: Platform definition and configuration
    SqlServerQueryBuilder: SQL Server dialect query generation
    SQLSERVER_TO_SNOWFLAKE_TYPE_MAPPINGS: Type conversion mappings
"""

from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.platform import (
    SqlServerPlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.query_builder import (
    SqlServerQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.type_mappings import (
    SQLSERVER_TO_SNOWFLAKE_TYPE_MAPPINGS,
)


__all__ = [
    "SqlServerPlatform",
    "SqlServerQueryBuilder",
    "SQLSERVER_TO_SNOWFLAKE_TYPE_MAPPINGS",
]
