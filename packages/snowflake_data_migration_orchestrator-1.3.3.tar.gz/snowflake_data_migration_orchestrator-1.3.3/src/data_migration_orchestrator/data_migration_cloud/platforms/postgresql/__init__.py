"""
PostgreSQL platform implementation.

This package provides PostgreSQL-specific components for data migration:
    PostgresqlPlatform: Platform definition and configuration
    PostgresqlQueryBuilder: PostgreSQL dialect query generation
    POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS: Type conversion mappings
"""

from data_migration_orchestrator.data_migration_cloud.platforms.postgresql.platform import (
    PostgresqlPlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.postgresql.query_builder import (
    PostgresqlQueryBuilder,
)
from data_migration_orchestrator.data_migration_core.type_mappings.postgresql_default_mappings import (
    POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS,
)


__all__ = [
    "PostgresqlPlatform",
    "PostgresqlQueryBuilder",
    "POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS",
]
