"""Redshift platform implementation package."""
