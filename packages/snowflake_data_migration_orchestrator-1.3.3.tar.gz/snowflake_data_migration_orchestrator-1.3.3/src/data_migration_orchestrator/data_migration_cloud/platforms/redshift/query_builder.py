"""
Redshift-specific SQL query builder.

This module provides the RedshiftQueryBuilder class that generates
SQL queries using Amazon Redshift syntax for metadata extraction,
schema queries, partition calculations, and UNLOAD operations.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.redshift.checksum import (
    build_redshift_checksum_query,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from data_migration_orchestrator.data_migration_core.queries.table_metadata import (
    COLUMN_NAME,
    DATA_TYPE,
)
from data_migration_orchestrator.utils.datetime_utils import is_datetime_string
from shared.enums.source_type import SourceType


# Server-side conversions for Redshift types that need special handling.
_REDSHIFT_EXTRACTION_CONVERSIONS: dict[str, str] = {}

# Tables with at least this many rows use sampling for boundary analysis
SAMPLING_THRESHOLD_ROWS = 100_000_000
# Target number of sampled rows for boundary analysis
SAMPLING_TARGET_ROWS = 20_000_000


class RedshiftQueryBuilder(BaseQueryBuilder):
    """
    Query builder for Amazon Redshift SQL syntax.

    Generates SQL queries compatible with Redshift, including support
    for the UNLOAD command to export data to S3.
    """

    @property
    def platform_name(self) -> SourceType:
        """Return the platform name."""
        return SourceType.REDSHIFT

    @property
    def identifier_quote_char(self) -> tuple[str, str]:
        """Return double quotes for Redshift identifier quoting."""
        return ('"', '"')

    @property
    def string_literal_prefix(self) -> str:
        """Return empty string - Redshift has no special prefix."""
        return ""

    def quote_identifier(self, identifier: str) -> str:
        """
        Quote an identifier using double quotes.

        Args:
            identifier: Identifier to quote

        Returns:
            Quoted identifier

        """
        open_q, close_q = self.identifier_quote_char
        # Escape any existing quotes by doubling them
        escaped = identifier.replace('"', '""')
        return f"{open_q}{escaped}{close_q}"

    def build_metadata_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table metadata from Redshift.

        Uses SVV_TABLE_INFO system view to get row count and size.

        Args:
            table_name: Fully qualified table name (database.schema.table)

        Returns:
            SQL query string

        """
        # TODO(3048007): Normalize schema_name/table_name?
        # svv_table_info.size is already in 1 MB blocks, no conversion needed
        return f"""
SELECT
    tbl_rows AS row_count,
    ROUND(size::FLOAT, 2) AS data_size_mb
FROM SVV_TABLE_INFO
WHERE "schema" = '{table_name.schema_name}'
  AND "table" = '{table_name.table_name}'
""".strip()

    def build_schema_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table schema from Redshift.

        Uses information_schema.columns to get column definitions.

        Args:
            table_name: Fully qualified table name (database.schema.table)

        Returns:
            SQL query string

        """
        return f"""
SELECT
    column_name,
    data_type,
    character_maximum_length,
    numeric_precision,
    numeric_scale,
    is_nullable,
    column_default,
    ordinal_position
FROM information_schema.columns
WHERE table_schema = '{table_name.schema_name}'
  AND table_name = '{table_name.table_name}'
ORDER BY ordinal_position
""".strip()

    def build_partition_boundary_query(
        self,
        table_name: TableIdentifier,
        column: str,
        num_partitions: int,
        row_count: int | None = None,
    ) -> str:
        """
        Generate SQL query to calculate partition boundaries.

        For large tables (>= SAMPLING_THRESHOLD_ROWS), uses a random sample
        of ~SAMPLING_TARGET_ROWS rows to avoid a full table scan + sort.
        For smaller tables or when row_count is unknown, falls back to the
        standard full-table NTILE query.

        Args:
            table_name: Object representing fully qualified table name
            column: Column name to partition on
            num_partitions: Number of partitions to create
            row_count: Optional total row count from metadata

        Returns:
            SQL query string that returns partition boundary values

        """
        if row_count is not None and row_count >= SAMPLING_THRESHOLD_ROWS:
            return self._build_sampled_boundary_query(
                table_name, column, num_partitions, row_count
            )

        return super().build_partition_boundary_query(
            table_name, column, num_partitions, row_count
        )

    def _build_sampled_boundary_query(
        self,
        table_name: TableIdentifier,
        column: str,
        num_partitions: int,
        row_count: int,
    ) -> str:
        """Build a boundary query that samples ~SAMPLING_TARGET_ROWS rows."""
        fqn = table_name.get_fully_qualified_normalized_name(
            source_type=self.platform_name
        )
        quoted_column = self.quote_identifier(column)
        sample_rate = min(SAMPLING_TARGET_ROWS / row_count, 1.0)

        return f"""
WITH sampled AS (
    SELECT {quoted_column}
    FROM {fqn}
    WHERE RANDOM() < {sample_rate:.10f}
),
partitioned AS (
    SELECT
        {quoted_column},
        NTILE({num_partitions}) OVER (ORDER BY {quoted_column}) AS partition_id
    FROM sampled
)
SELECT
    partition_id,
    MIN({quoted_column}) AS min_value_in_partition,
    MAX({quoted_column}) AS max_value_in_partition,
    COUNT(*) AS n_rows
FROM partitioned
GROUP BY partition_id
ORDER BY partition_id
""".strip()

    def build_unload_query(
        self,
        select_query: str,
        s3_path: str,
        iam_role: str,
        file_format: str = "parquet",
        include_header: bool = False,
        parallel: bool = True,
        max_file_size_mb: int | None = None,
    ) -> str:
        """
        Generate a Redshift UNLOAD command.

        Args:
            select_query: SELECT statement to export
            s3_path: S3 destination path (must end with /)
            iam_role: IAM role ARN for S3 access
            file_format: Output format ('parquet' or 'csv')
            include_header: Include column headers (CSV only)
            parallel: Enable parallel unload
            max_file_size_mb: Maximum file size in MB

        Returns:
            UNLOAD SQL command

        """
        options = []

        # File format
        if file_format.lower() == "parquet":
            options.append("FORMAT AS PARQUET")
        elif file_format.lower() == "csv":
            options.append("FORMAT AS CSV")
            if include_header:
                options.append("HEADER")

        # Parallel option
        if not parallel:
            options.append("PARALLEL OFF")

        # Max file size
        if max_file_size_mb is not None:
            # Redshift expects size in bytes or MB suffix
            options.append(f"MAXFILESIZE {max_file_size_mb} MB")

        # Always add ALLOWOVERWRITE for idempotency
        options.append("ALLOWOVERWRITE")

        options_str = "\n    ".join(options)

        return f"""
UNLOAD ('{select_query.replace("'", "''")}')
TO '{s3_path}'
IAM_ROLE '{iam_role}'
    {options_str}
""".strip()

    def build_select_query(
        self,
        table_name: TableIdentifier,
        column_types: list[dict[str, str]],
        where_clause: str | None = None,
    ) -> str:
        """Build a type-aware SELECT with server-side conversions where needed."""
        fqn = table_name.get_fully_qualified_normalized_name(self.platform_name)
        # Build column expressions with conversions where needed
        col_expressions: list[str] = []
        for col in column_types:
            col_name = col[COLUMN_NAME]
            data_type = col.get(DATA_TYPE, "").lower()
            quoted_col = self.quote_identifier(col_name)

            conversion_template = _REDSHIFT_EXTRACTION_CONVERSIONS.get(data_type)
            if conversion_template:
                expr = conversion_template.format(col=quoted_col)
                col_expressions.append(f"{expr} AS {quoted_col}")
            else:
                col_expressions.append(quoted_col)

        col_str = ", ".join(col_expressions)
        query = f"SELECT {col_str} FROM {fqn}"

        if where_clause:
            query += f" WHERE {where_clause}"

        return query

    def format_sql_value(self, value: Any) -> str:
        """
        Format a value for Redshift WHERE clauses.

        Uses simple quoted ISO strings for datetime values, which Redshift
        can parse implicitly without explicit type conversion functions.

        Args:
            value: The value to format

        Returns:
            A Redshift-compatible string representation of the value

        """
        if value is None:
            return "NULL"

        if isinstance(value, (int | float)):
            return str(value)

        # Handle Python datetime objects - use ISO format string
        if isinstance(value, datetime):
            # Redshift accepts ISO format strings directly
            iso_str = value.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            return self.quote_string_literal(iso_str)

        if isinstance(value, str):
            # Remove surrounding double quotes if present (from Snowflake VARIANT)
            trimmed = value
            if value.startswith('"') and value.endswith('"'):
                trimmed = value[1:-1]

            # Datetime strings work as-is in Redshift (implicit conversion)
            # Just normalize the format
            if is_datetime_string(trimmed):
                # Normalize: replace 'T' with space for Redshift compatibility
                normalized = trimmed.replace("T", " ")
                return self.quote_string_literal(normalized)

            # Regular string
            return self.quote_string_literal(trimmed)

        # Fallback: convert to string and quote
        return self.quote_string_literal(str(value))

    def build_checksum_query(
        self,
        partition_info: PartitionInfo,
        source_table_id: TableIdentifier,
        columns: list[ColumnInfo],
    ) -> str:
        """
        Build Redshift checksum query.

        Delegates to :func:`~...platforms.redshift.checksum.build_redshift_checksum_query`.

        """
        where_clause = self.build_partition_condition(
            partition_info.partition_column,
            partition_info.min_value,
            partition_info.max_value,
        )
        return build_redshift_checksum_query(
            partition_info=partition_info,
            source_table_id=source_table_id,
            columns=columns,
            quote_identifier_fn=self.quote_identifier,
            where_clause=where_clause,
        )
