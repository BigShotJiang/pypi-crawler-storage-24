"""
Platform registry for managing source database platform implementations.

This module provides the PlatformRegistry class for registering and retrieving
platform implementations. It extends BaseRegistry with platform-specific
functionality like alias resolution.
"""

from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.utils.base_registry import BaseRegistry


class PlatformRegistry(BaseRegistry[BasePlatform]):
    """
    Registry for source database platform implementations.

    This registry manages platform implementations and provides:
    - Platform registration and retrieval
    - Alias support (e.g., "mssql" -> "sqlserver")
    - Platform listing and discovery

    Example:
        >>> from data_migration_orchestrator.platforms.sqlserver import SqlServerPlatform
        >>> PlatformRegistry.register("sqlserver", SqlServerPlatform)
        >>> PlatformRegistry.register_alias("mssql", "sqlserver")
        >>> platform = PlatformRegistry.create("mssql")  # Returns SqlServerPlatform instance

    """

    _registry_type_name: str = "platform"
    _aliases: dict[str, str] = {}

    def __init_subclass__(cls, **kwargs):
        """Initialize subclass with its own registry and aliases."""
        super().__init_subclass__(**kwargs)
        cls._aliases = {}

    @classmethod
    def register_alias(cls, alias: str, canonical_name: str) -> None:
        """
        Register an alias for a platform.

        Args:
            alias: The alias name (e.g., "mssql")
            canonical_name: The canonical platform name (e.g., "sqlserver")

        """
        cls._aliases[alias] = canonical_name

    @classmethod
    def resolve_alias(cls, name: str) -> str:
        """
        Resolve a platform name or alias to the canonical name.

        Args:
            name: Platform name or alias

        Returns:
            Canonical platform name

        """
        return cls._aliases.get(name, name)

    @classmethod
    def get_by_name_or_alias(cls, name: str) -> type[BasePlatform]:
        """
        Get a platform class by name or alias.

        Args:
            name: Platform name or alias

        Returns:
            The registered platform class

        Raises:
            KeyError: If the platform is not registered

        """
        canonical_name = cls.resolve_alias(name)
        return cls.get(canonical_name)

    @classmethod
    def create_by_name_or_alias(cls, name: str, **kwargs) -> BasePlatform:
        """
        Create a platform instance by name or alias.

        Args:
            name: Platform name or alias
            **kwargs: Arguments to pass to the platform constructor

        Returns:
            Platform instance

        """
        canonical_name = cls.resolve_alias(name)
        return cls.create(canonical_name, **kwargs)

    @classmethod
    def list_platforms(cls) -> list[str]:
        """
        List all registered platform names.

        Returns:
            List of canonical platform names

        """
        return cls.list_types()

    @classmethod
    def list_aliases(cls) -> dict[str, str]:
        """
        List all registered aliases.

        Returns:
            Dictionary mapping aliases to canonical names

        """
        return dict(cls._aliases)

    @classmethod
    def get_all_names(cls) -> list[str]:
        """
        Get all platform names including aliases.

        Returns:
            List of all platform names and aliases

        """
        return list(set(cls.list_types()) | set(cls._aliases.keys()))
