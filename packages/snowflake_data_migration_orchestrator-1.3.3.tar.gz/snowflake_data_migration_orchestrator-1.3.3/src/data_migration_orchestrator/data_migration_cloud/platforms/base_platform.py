"""
Base platform abstract class for source database platforms.

This module defines the abstract base class that all source database platforms
must implement. Each platform provides query generation, type mappings, and
supported extraction strategies.
"""

from abc import ABC, abstractmethod
from functools import cached_property

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from shared.enums.source_type import SourceType


class BasePlatform(ABC):
    """
    Abstract base class for source database platforms.

    Each platform implementation provides:
    - Platform identification (name, display name, aliases)
    - Supported extraction strategies
    - Query builder for platform-specific SQL
    - Type mappings from source types to Snowflake types

    Example:
        >>> class SqlServerPlatform(BasePlatform):
        ...     @property
        ...     def name(self) -> str:
        ...         return "sqlserver"
        ...     # ... implement other abstract properties/methods

    """

    @property
    @abstractmethod
    def name(self) -> SourceType:
        """
        Platform identifier used in configuration.

        Returns:
            Lowercase identifier (e.g., "sqlserver", "redshift", "postgresql")

        """
        ...

    @property
    @abstractmethod
    def display_name(self) -> str:
        """
        Human-readable platform name.

        Returns:
            Display name (e.g., "SQL Server", "Amazon Redshift")

        """
        ...

    @property
    @abstractmethod
    def aliases(self) -> list[str]:
        """
        Alternative names for this platform.

        Returns:
            List of aliases (e.g., ["mssql", "sql-server"] for SQL Server)

        """
        ...

    @property
    @abstractmethod
    def default_strategy(self) -> ExtractionStrategy:
        """
        Default extraction strategy for this platform.

        Returns:
            Strategy name (e.g., "jdbc", "unload")

        """
        ...

    @property
    @abstractmethod
    def supported_strategies(self) -> list[ExtractionStrategy]:
        """
        List of extraction strategies this platform supports.

        Returns:
            List of strategy names (e.g., ["odbc", "unload"])

        """
        ...

    @cached_property
    @abstractmethod
    def query_builder(self) -> BaseQueryBuilder:
        """
        Query builder for generating platform-specific SQL.

        Returns:
            QueryBuilder instance for this platform

        """
        ...

    @property
    @abstractmethod
    def type_mappings(self) -> dict[str, str]:
        """
        Type mappings from source types to Snowflake types.

        Returns:
            Dictionary mapping source type names to Snowflake type names
            (e.g., {"BIGINT": "NUMBER", "VARCHAR": "VARCHAR"})

        """
        ...

    def supports_strategy(self, strategy_name: ExtractionStrategy) -> bool:
        """
        Check if this platform supports the given extraction strategy.

        Args:
            strategy_name: Name of the strategy to check

        Returns:
            True if the strategy is supported, False otherwise

        """
        return strategy_name in self.supported_strategies

    def get_type_mapping(self, source_type: SourceType) -> str | None:
        """
        Get the Snowflake type for a source type.

        Args:
            source_type: Source database type name

        Returns:
            Snowflake type name, or None if no mapping exists

        """
        return self.type_mappings.get(source_type.upper())

    def get_metadata_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table metadata (row count, size).

        Args:
            table_name: Fully qualified table name

        Returns:
            SQL query string

        """
        return self.query_builder.build_metadata_query(table_name)

    def get_schema_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table schema (column definitions).

        Args:
            table_name: Fully qualified table name

        Returns:
            SQL query string

        """
        return self.query_builder.build_schema_query(table_name)

    def get_partition_boundary_query(
        self, table_name: TableIdentifier, column: str, num_partitions: int
    ) -> str:
        """
        Generate SQL query to calculate partition boundaries.

        Args:
            table_name: Fully qualified table name
            column: Column to partition on
            num_partitions: Number of partitions

        Returns:
            SQL query string

        """
        return self.query_builder.build_partition_boundary_query(
            table_name, column, num_partitions
        )
