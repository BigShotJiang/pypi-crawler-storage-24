"""
The base priority for extraction tasks.

An "offset" can be added to this priority so that the priority of
extracting a partition falls in the range [2, 3[ depending on the partition number.
This prevents agents from swarming to extract partitions from the same table at the same time, instead opting for
extracting the lowermost non-extracted partition of each pending table.
"""

BASE_PRIORITY_FOR_EXTRACTION_TASKS = 2

"""
Priority for tasks that handle COPY INTO operations from staged data to target tables, or that
are related to this part of the data migration.
"""
PRIORITY_FOR_COPY_INTO_TASKS = 2


def compute_priority_for_extraction_task(partition_id: int) -> float:
    """Compute priority for extraction task based on partition ID."""
    priority_offset = (partition_id % 100) * 0.01
    return BASE_PRIORITY_FOR_EXTRACTION_TASKS + priority_offset
