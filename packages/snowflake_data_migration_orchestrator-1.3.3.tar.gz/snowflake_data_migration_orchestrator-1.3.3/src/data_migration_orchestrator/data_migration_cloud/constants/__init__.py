"""Constants for Data Migration Cloud."""
