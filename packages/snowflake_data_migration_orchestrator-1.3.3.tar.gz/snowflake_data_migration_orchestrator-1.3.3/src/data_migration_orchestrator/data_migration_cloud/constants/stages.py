"""Constants for Snowflake stage identifiers used in data migration."""

# The default internal stage used for storing task results, metadata, and intermediate data.
# This stage is always available and used when no external stage is configured.
DEFAULT_INTERNAL_STAGE = "@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS"
