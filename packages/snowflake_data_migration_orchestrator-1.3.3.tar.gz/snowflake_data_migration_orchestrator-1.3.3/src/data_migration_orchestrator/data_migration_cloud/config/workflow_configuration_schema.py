"""
Pydantic schema models for structural validation of workflow configurations.

These models validate the raw JSON configuration dict (types, required fields,
unknown keys) before the ConfigurationParser performs semantic validation
and transformation into domain objects.

The standalone ``validate_workflow_configuration`` function is the public entry
point. It can be called from the workflow initializer, a REST API endpoint, a
CLI pre-check, or any other execution path that needs to validate a workflow
configuration.
"""

from pydantic import BaseModel, ConfigDict, Field, field_validator

from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
)


class TableEndpointSchema(BaseModel):
    """Schema for a source or target table endpoint."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    database_name: str | None = Field(default=None, alias="databaseName")
    schema_name: str | None = Field(default=None, alias="schemaName")
    table_name: str | None = Field(default=None, alias="tableName")


class ColumnTypeMappingSchema(BaseModel):
    """Schema for a single column type mapping entry."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    source_type: str = Field(alias="sourceType")
    target_type: str = Field(alias="targetType")


class ColumnNameMappingSchema(BaseModel):
    """Schema for a single column name mapping entry."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    source_name: str = Field(alias="sourceName")
    target_name: str = Field(alias="targetName")


class SynchronizationSchema(BaseModel):
    """Schema for the synchronization configuration block."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    strategy: str | None = None
    watermark_column: str | None = Field(default=None, alias="watermarkColumn")
    track_modifications: bool | None = Field(default=None, alias="trackModifications")


class ExtractionSchema(BaseModel):
    """Schema for the extraction strategy configuration block."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    strategy: str | None = None
    external_stage: str | None = Field(default=None, alias="externalStage")


class TableConfigurationSchema(BaseModel):
    """Schema for a single table configuration entry."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    source: TableEndpointSchema | None = None
    target: TableEndpointSchema | None = None
    column_names_to_partition_by: list[str] | None = Field(
        default=None, alias="columnNamesToPartitionBy"
    )
    column_type_mappings: list[ColumnTypeMappingSchema] | None = Field(
        default=None, alias="columnTypeMappings"
    )
    column_name_mappings: list[ColumnNameMappingSchema] | None = Field(
        default=None, alias="columnNameMappings"
    )
    primary_key_columns: list[str] | None = Field(
        default=None, alias="primaryKeyColumns"
    )
    synchronization: SynchronizationSchema | None = None
    extraction: ExtractionSchema | None = None
    where_clause_criteria: str | None = Field(default=None, alias="whereClauseCriteria")


class WorkflowConfigurationSchema(BaseModel):
    """
    Top-level schema for a Data Migration Workflow configuration.

    Validates structural correctness of the raw JSON configuration dict.
    Semantic validation (e.g. watermark requires watermarkColumn) is handled
    separately by ConfigurationParser.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    tables: list[TableConfigurationSchema]
    default_table_configuration: TableConfigurationSchema | None = Field(
        default=None, alias="defaultTableConfiguration"
    )
    affinity: str | None = None

    @field_validator("tables")
    @classmethod
    def tables_must_not_be_empty(
        cls,
        v: list[TableConfigurationSchema],
    ) -> list[TableConfigurationSchema]:
        """Ensure the tables list contains at least one entry."""
        if len(v) == 0:
            raise ValueError("'tables' must contain at least one table configuration")
        return v


def validate_workflow_configuration(
    configuration: dict | None,
) -> WorkflowConfigurationSchema:
    """
    Validate a raw workflow configuration dict.

    This is the public entry point for configuration validation. It can be
    called from any execution path (workflow initializer, API, CLI, etc.)
    independently.

    Args:
        configuration: The raw configuration dict from the workflow, or None.

    Returns:
        The validated WorkflowConfigurationSchema model.

    Raises:
        ConfigurationError: If the configuration is None or structurally invalid.

    """
    if configuration is None:
        raise ConfigurationError("Workflow configuration must not be None")

    try:
        return WorkflowConfigurationSchema.model_validate(configuration)
    except Exception as e:
        raise ConfigurationError(f"Invalid workflow configuration: {e}") from e
