"""Data models for table configuration in workflow definitions."""

from dataclasses import dataclass, field

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    DEFAULT_EXTRACTION_STRATEGY,
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    DEFAULT_SYNCHRONIZATION_STRATEGY,
    SyncStrategy,
)
from data_migration_orchestrator.utils.table_utils import build_table_ref
from shared.enums.source_type import SourceType


@dataclass(frozen=True)
class ExtractionConfig:
    """
    Configuration for extraction strategy of a table.

    Uses a tagged union pattern where the 'strategy' field determines which
    additional fields are relevant.

    Attributes:
        strategy: The extraction strategy to use (REGULAR, UNLOAD)
            Defaults to REGULAR.
        external_stage: External stage path for UNLOAD strategy.
            Required when strategy is UNLOAD.

    """

    strategy: ExtractionStrategy = DEFAULT_EXTRACTION_STRATEGY

    # Fields for UNLOAD strategy
    external_stage: str | None = None


@dataclass(frozen=True)
class SynchronizationConfig:
    """
    Configuration for incremental synchronization of a table.

    Attributes:
        strategy: The synchronization strategy to use (NONE, CHECKSUM, WATERMARK, etc.)
            Defaults to NONE (no incremental sync, always full partition extraction).
        watermark_column: Column name to use for watermark-based sync (required for WATERMARK strategy)
        track_modifications: Whether to track and deduplicate modified rows (WATERMARK strategy only).
            When True, requires primary_key_columns to be set on the table configuration.

    """

    strategy: SyncStrategy = DEFAULT_SYNCHRONIZATION_STRATEGY

    # Fields for CHECKSUM strategy
    # N/A

    # Fields for WATERMARK strategy
    watermark_column: str | None = None
    track_modifications: bool = False

    # Fields for CHANGE_TRACKING strategy
    # TODO(SNOW-3067427)


@dataclass(frozen=True)
class TableIdentifier:
    """
    Represents a source or target table endpoint.

    Attributes:
        database_name: The database/catalog name
        schema_name: The schema name
        table_name: The table name

    """

    database_name: str
    schema_name: str
    table_name: str

    @property
    def fully_qualified_friendly_name(self) -> str:
        """
        Get the fully qualified table name (database.schema.table).

        Returns unquoted names joined with dots. For quoted names suitable
        for SQL queries, use get_quoted_reference() instead.
        """
        db_fragment = self.database_name + "." if self.database_name else ""
        schema_fragment = self.schema_name + "." if self.schema_name else ""
        return f"{db_fragment}{schema_fragment}{self.table_name}"

    def get_fully_qualified_normalized_name(
        self, source_type: SourceType | None
    ) -> (
        str
    ):  # TODO(SNOW-3102599): Maybe move this to query builder? This is platform-dependent
        """
        Get the fully qualified table name with proper quoting for SQL queries.

        For SQL Server, this uses [bracket] notation to handle special characters,
        reserved words, and case-sensitive names.

        Args:
            source_type: The database type ("sqlserver", "snowflake", etc.)

        Returns:
            Fully qualified table reference with proper quoting

        """
        return build_table_ref(
            database=self.database_name,
            schema=self.schema_name,
            table_name=self.table_name,
            source_type=source_type,
        )


@dataclass(frozen=True)
class TableConfiguration:
    """
    Parsed and validated table configuration from workflow definition.

    This model represents a single table migration configuration with all
    its properties strongly typed. It is constructed by ConfigurationParser
    from raw dictionary configurations.

    Attributes:
        source: The source table endpoint
        target: The target table endpoint
        partition_columns: List of column names to partition by during extraction
        column_type_mappings: Optional dict mapping source types to target types
            (e.g., {"MONEY": "DECIMAL(19,4)", "BIT": "BOOLEAN"})
        column_name_mappings: Optional dict mapping source column names to target column names
            (e.g., {"id": "old_id", "name": "full_name"})
        primary_key_columns: List of column names that form the primary key of the table.
            Used for deduplication in watermark-based incremental sync with track_modifications.
        synchronization: Configuration for incremental synchronization
        extraction: Configuration for extraction strategy (tagged union pattern).
            Contains the strategy type and strategy-specific settings.

    """

    source: TableIdentifier
    target: TableIdentifier
    partition_columns: list[str] = field(default_factory=list)
    column_type_mappings: dict[str, str] = field(default_factory=dict)
    column_name_mappings: dict[str, str] = field(default_factory=dict)
    primary_key_columns: list[str] = field(default_factory=list)
    synchronization: SynchronizationConfig = field(
        default_factory=SynchronizationConfig
    )
    extraction: ExtractionConfig = field(default_factory=ExtractionConfig)

    where_clause_criteria: str | None = None

    # Backwards compatibility property
    @property
    def extraction_strategy(self) -> ExtractionStrategy:
        """Get the extraction strategy (for backwards compatibility)."""
        return self.extraction.strategy

    def get_source_fully_qualified_name(self, source_type: SourceType) -> str:
        """Get the fully qualified source table name."""
        return self.source.get_fully_qualified_normalized_name(source_type)

    def get_target_fully_qualified_name(self, source_type: SourceType) -> str:
        """Get the fully qualified target table name."""
        return self.target.get_fully_qualified_normalized_name(source_type)
