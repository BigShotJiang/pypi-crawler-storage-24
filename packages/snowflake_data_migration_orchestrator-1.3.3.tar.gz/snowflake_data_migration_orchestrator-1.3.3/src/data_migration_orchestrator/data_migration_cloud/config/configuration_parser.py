"""
Parser for workflow table configurations.

This module provides the ConfigurationParser class for parsing and validating
raw table configuration dictionaries into strongly-typed TableConfiguration objects.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config import (
    configuration_properties_keys,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    ExtractionConfig,
    SynchronizationConfig,
    TableConfiguration,
    TableIdentifier,
)


logger = get_logger("utils.configuration_parser")


class ConfigurationError(Exception):
    """Raised when table configuration is invalid."""

    pass


class ConfigurationParser:
    """
    Parses and validates workflow table configurations.

    This class handles the conversion of raw dictionary configurations
    (as received from workflow definitions) into strongly-typed
    TableConfiguration objects with proper validation.

    """

    # Fields that should be deep-merged (nested objects)
    _DEEP_MERGE_FIELDS = frozenset(
        {
            configuration_properties_keys.SOURCE,
            configuration_properties_keys.TARGET,
            configuration_properties_keys.SYNCHRONIZATION,
            configuration_properties_keys.EXTRACTION,
        }
    )

    # Fields that should be shallow-replaced (collections/lists)
    _SHALLOW_REPLACE_FIELDS = frozenset(
        {
            configuration_properties_keys.COLUMN_TYPE_MAPPINGS,
            configuration_properties_keys.COLUMN_NAME_MAPPINGS,
            configuration_properties_keys.COLUMN_NAMES_TO_PARTITION_BY,
            configuration_properties_keys.PRIMARY_KEY_COLUMNS,
        }
    )

    def _deep_merge_dicts(self, default: dict, override: dict) -> dict:
        """
        Deep merge two dictionaries. Override values take precedence.

        For nested dictionaries, the merge is recursive. For other types,
        the override value completely replaces the default.

        Args:
            default: The default dictionary to merge into
            override: The dictionary with override values

        Returns:
            A new dictionary with merged values

        """
        result = dict(default)
        for key, override_value in override.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(override_value, dict)
            ):
                # Recursively merge nested dicts
                result[key] = self._deep_merge_dicts(result[key], override_value)
            else:
                # Override value takes precedence
                result[key] = override_value
        return result

    def _merge_table_configs(self, default: dict, table: dict) -> dict:
        """
        Merge a table configuration with defaults using appropriate strategy per field.

        Merging rules:
        - Nested objects (source, target, synchronization): Deep merge
        - Collection fields (columnTypeMappings, etc.): Shallow replace (table replaces default)
        - Scalar fields: Table value overrides default

        Args:
            default: The default table configuration dictionary
            table: The table-specific configuration dictionary

        Returns:
            A new dictionary with merged configuration

        """
        result = dict(default)

        for key, table_value in table.items():
            if key in self._DEEP_MERGE_FIELDS:
                # Deep merge for nested objects
                default_value = result.get(key, {})
                if isinstance(default_value, dict) and isinstance(table_value, dict):
                    result[key] = self._deep_merge_dicts(default_value, table_value)
                else:
                    result[key] = table_value
            elif key in self._SHALLOW_REPLACE_FIELDS:
                # Shallow replace for collections - table value completely replaces default
                result[key] = table_value
            else:
                # Scalar fields - table value overrides default
                result[key] = table_value

        return result

    def parse_table_configuration(self, raw_config: dict) -> TableConfiguration:
        """
        Parse a raw table configuration dictionary into a TableConfiguration.

        Args:
            raw_config: Raw dictionary from workflow configuration containing
                       'source', 'target', and optional 'columnNamesToPartitionBy'
                       and 'columnTypeMappings' fields.

        Returns:
            A validated TableConfiguration object.

        Raises:
            ConfigurationError: If required fields are missing or invalid.

        """
        # Parse source endpoint
        source_dict = raw_config.get(configuration_properties_keys.SOURCE)
        if not source_dict:
            raise ConfigurationError(
                "Missing required field 'source' in table configuration"
            )
        source = self._parse_table_endpoint(source_dict, "source")

        # Parse target endpoint
        target_dict = raw_config.get(configuration_properties_keys.TARGET)
        if not target_dict:
            raise ConfigurationError(
                "Missing required field 'target' in table configuration"
            )
        target = self._parse_table_endpoint(target_dict, "target")

        # Parse partition columns
        partition_columns = self._parse_partition_columns(
            raw_config, source.fully_qualified_friendly_name
        )

        # Parse column type mappings (optional)
        column_type_mappings = self._parse_column_type_mappings(raw_config)

        # Parse column name mappings (optional)
        column_name_mappings = self._parse_column_name_mappings(raw_config)

        # Parse primary key columns (optional, table-level metadata)
        primary_key_columns = self._parse_primary_key_columns(raw_config)

        # Parse synchronization configuration (optional)
        synchronization = self._parse_synchronization_config(
            raw_config, source.fully_qualified_friendly_name, primary_key_columns
        )

        # Parse extraction configuration (optional)
        extraction = self._parse_extraction_config(
            raw_config, source.fully_qualified_friendly_name
        )

        # Parse where clause criteria (optional)
        where_clause_criteria = self._parse_where_clause_criteria(raw_config)

        return TableConfiguration(
            source=source,
            target=target,
            partition_columns=partition_columns,
            column_type_mappings=column_type_mappings,
            column_name_mappings=column_name_mappings,
            primary_key_columns=primary_key_columns,
            synchronization=synchronization,
            extraction=extraction,
            where_clause_criteria=where_clause_criteria,
        )

    def parse_tables(
        self,
        tables_config: list[dict],
        default_config: dict | None = None,
    ) -> list[TableConfiguration]:
        """
        Parse all table configurations from a workflow.

        If a default_config is provided, each table configuration is merged with
        the defaults before parsing. This allows tables to have partial configurations
        that inherit from a common template.

        Merging rules:
        - Nested objects (source, target, synchronization): Deep merge
        - Collection fields (columnTypeMappings, etc.): Table value replaces default
        - Scalar fields: Table value overrides default

        Args:
            tables_config: List of raw table configuration dictionaries.
            default_config: Optional default configuration to merge with each table.

        Returns:
            List of validated TableConfiguration objects.

        Raises:
            ConfigurationError: If any table configuration is invalid after merging.

        """
        configurations = []
        for i, raw_config in enumerate(tables_config):
            try:
                # Merge with defaults if provided
                if default_config:
                    merged_config = self._merge_table_configs(
                        default_config, raw_config
                    )
                else:
                    merged_config = raw_config

                config = self.parse_table_configuration(merged_config)
                configurations.append(config)
            except ConfigurationError as e:
                raise ConfigurationError(
                    f"Invalid configuration for table at index {i}: {e}"
                ) from e
        return configurations

    def _parse_table_endpoint(self, endpoint_dict: dict, name: str) -> TableIdentifier:
        """
        Parse a table endpoint (source or target) from configuration.

        Args:
            endpoint_dict: Dictionary containing tableName, schemaName, databaseName
            name: Name of the endpoint for error messages ('source' or 'target')

        Returns:
            TableIdentifier object.

        Raises:
            ConfigurationError: If required fields are missing.

        """
        missing_fields: list[str] = []

        def get_required(key: str, field_name: str) -> str:
            value = endpoint_dict.get(key)
            if not value:
                missing_fields.append(field_name)
                return ""
            return value

        database_name = get_required(
            configuration_properties_keys.DATABASE_NAME, "databaseName"
        )
        schema_name = get_required(
            configuration_properties_keys.SCHEMA_NAME, "schemaName"
        )
        table_name = get_required(configuration_properties_keys.TABLE_NAME, "tableName")

        if missing_fields:
            raise ConfigurationError(
                f"Missing required field(s) in {name}: {', '.join(missing_fields)}"
            )

        return TableIdentifier(
            database_name=database_name,
            schema_name=schema_name,
            table_name=table_name,
        )

    def _parse_partition_columns(self, raw_config: dict, table_name: str) -> list[str]:
        """
        Parse partition columns from configuration.

        Args:
            raw_config: Raw table configuration dictionary
            table_name: Table name for error messages

        Returns:
            List of partition column names.

        Raises:
            ConfigurationError: If partition columns are not specified.

        """
        column_names = raw_config.get(
            configuration_properties_keys.COLUMN_NAMES_TO_PARTITION_BY, []
        )

        if not column_names:
            raise ConfigurationError(
                f"No partition column specified for {table_name}. "
                f"Please add 'columnNamesToPartitionBy' to the table configuration."
            )

        return list(column_names)

    def _parse_column_type_mappings(self, raw_config: dict) -> dict[str, str]:
        """
        Parse column type mappings from configuration.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            Dict mapping source types to target types (empty if not specified).

        """
        mappings_list = raw_config.get(
            configuration_properties_keys.COLUMN_TYPE_MAPPINGS, []
        )

        if not mappings_list:
            return {}

        column_type_mappings: dict[str, str] = {}
        for i, mapping_dict in enumerate(mappings_list):
            source_type = mapping_dict.get(configuration_properties_keys.SOURCE_TYPE)
            target_type = mapping_dict.get(configuration_properties_keys.TARGET_TYPE)

            if not source_type or not target_type:
                logger.warning(
                    f"Skipping invalid column type mapping at index {i}: "
                    f"missing sourceType or targetType"
                )
                continue

            # Normalize to uppercase
            column_type_mappings[source_type.upper()] = target_type.upper()

        if column_type_mappings:
            logger.info(
                f"Parsed {len(column_type_mappings)} custom column type mapping(s)"
            )

        return column_type_mappings

    def _parse_column_name_mappings(self, raw_config: dict) -> dict[str, str]:
        """
        Parse column name mappings from configuration.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            Dict mapping source column names to target column names (empty if not specified).

        """
        mappings_list = raw_config.get(
            configuration_properties_keys.COLUMN_NAME_MAPPINGS, []
        )

        if not mappings_list:
            return {}

        column_name_mappings: dict[str, str] = {}
        for i, mapping_dict in enumerate(mappings_list):
            source_name = mapping_dict.get(configuration_properties_keys.SOURCE_NAME)
            target_name = mapping_dict.get(configuration_properties_keys.TARGET_NAME)

            if not source_name or not target_name:
                logger.warning(
                    f"Skipping invalid column name mapping at index {i}: "
                    f"missing sourceName or targetName"
                )
                continue

            column_name_mappings[source_name] = target_name

        if column_name_mappings:
            logger.info(
                f"Parsed {len(column_name_mappings)} custom column name mapping(s)"
            )

        return column_name_mappings

    def _parse_where_clause_criteria(self, raw_config: dict) -> str | None:
        """
        Parse optional whereClauseCriteria from configuration.

        Strips a leading ``WHERE`` keyword (case-insensitive) if present,
        trims whitespace, and ignores non-string values.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            Cleaned WHERE condition string, or None if not specified / empty.

        """
        criteria = raw_config.get(configuration_properties_keys.WHERE_CLAUSE_CRITERIA)

        if not criteria:
            return None

        if not isinstance(criteria, str):
            logger.warning(
                f"Ignoring non-string whereClauseCriteria value: "
                f"{type(criteria).__name__}"
            )
            return None

        cleaned = criteria.strip()
        if not cleaned:
            return None

        upper = cleaned.upper()
        if upper.startswith("WHERE "):
            cleaned = cleaned[6:].strip()
        elif upper == "WHERE":
            cleaned = ""

        if not cleaned:
            return None

        logger.info(f"Parsed whereClauseCriteria: {cleaned}")
        return cleaned

    def _parse_primary_key_columns(self, raw_config: dict) -> list[str]:
        """
        Parse primary key columns from configuration.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            List of primary key column names (empty if not specified).

        """
        pk_columns = raw_config.get(
            configuration_properties_keys.PRIMARY_KEY_COLUMNS, []
        )

        if pk_columns:
            logger.info(f"Parsed {len(pk_columns)} primary key column(s)")

        return list(pk_columns)

    def _parse_synchronization_config(
        self, raw_config: dict, table_name: str, primary_key_columns: list[str]
    ) -> SynchronizationConfig:
        """
        Parse synchronization configuration from table configuration.

        Args:
            raw_config: Raw table configuration dictionary
            table_name: Table name for error messages
            primary_key_columns: List of primary key columns from table configuration

        Returns:
            SynchronizationConfig object (uses defaults if not specified).

        Raises:
            ConfigurationError: If watermark strategy is specified without watermarkColumn,
                or if trackModifications is enabled without primaryKeyColumns.

        """
        sync_dict = raw_config.get(configuration_properties_keys.SYNCHRONIZATION)

        if not sync_dict:
            # Return default configuration
            return SynchronizationConfig()

        # Parse strategy
        strategy_str = sync_dict.get(configuration_properties_keys.STRATEGY)
        if strategy_str:
            try:
                strategy = SyncStrategy.from_string(strategy_str)
            except NotImplementedError as e:
                raise ConfigurationError(
                    f"Invalid synchronization strategy for {table_name}: {e}"
                ) from e
        else:
            # Use default strategy if not specified
            strategy = SynchronizationConfig().strategy

        # Parse watermark column (required for WATERMARK strategy)
        watermark_column = sync_dict.get(configuration_properties_keys.WATERMARK_COLUMN)

        if strategy == SyncStrategy.WATERMARK and not watermark_column:
            raise ConfigurationError(
                f"Synchronization strategy 'watermark' requires 'watermarkColumn' "
                f"to be specified for table {table_name}"
            )

        # Parse track_modifications (optional, defaults to False)
        track_modifications = sync_dict.get(
            configuration_properties_keys.TRACK_MODIFICATIONS, False
        )

        # Validate: trackModifications requires primaryKeyColumns for WATERMARK strategy
        if (
            strategy == SyncStrategy.WATERMARK
            and track_modifications
            and not primary_key_columns
        ):
            raise ConfigurationError(
                f"Synchronization with 'trackModifications' enabled requires "
                f"'primaryKeyColumns' to be specified for table {table_name}"
            )

        logger.info(
            f"Parsed synchronization config for {table_name}: "
            f"strategy={strategy.value}, watermark_column={watermark_column}, "
            f"track_modifications={track_modifications}"
        )

        return SynchronizationConfig(
            strategy=strategy,
            watermark_column=watermark_column,
            track_modifications=track_modifications,
        )

    def _parse_extraction_config(
        self, raw_config: dict, table_name: str
    ) -> ExtractionConfig:
        """
        Parse extraction configuration from table configuration.

        Uses a tagged union pattern where the 'strategy' field determines the type
        and which additional fields are relevant.

        Args:
            raw_config: Raw table configuration dictionary
            table_name: Table name for error messages

        Returns:
            ExtractionConfig object (uses defaults if not specified).

        Raises:
            ConfigurationError: If UNLOAD strategy is specified without externalStage.

        """
        extraction_dict = raw_config.get(configuration_properties_keys.EXTRACTION)

        if not extraction_dict:
            return ExtractionConfig()

        # Parse strategy type
        strategy_str = extraction_dict.get(configuration_properties_keys.STRATEGY)
        if strategy_str:
            try:
                strategy = ExtractionStrategy.from_string(strategy_str)
            except ValueError as e:
                raise ConfigurationError(
                    f"Invalid extraction strategy for {table_name}: {e}"
                ) from e
        else:
            strategy = ExtractionConfig().strategy

        # Parse external_stage (required for UNLOAD strategy)
        external_stage = extraction_dict.get(
            configuration_properties_keys.EXTERNAL_STAGE
        )

        if strategy == ExtractionStrategy.UNLOAD and not external_stage:
            raise ConfigurationError(
                f"Extraction strategy 'unload' requires 'externalStage' "
                f"to be specified for table {table_name}"
            )

        logger.info(
            f"Parsed extraction config for {table_name}: "
            f"strategy={strategy.value}, external_stage={external_stage}"
        )

        return ExtractionConfig(
            strategy=strategy,
            external_stage=external_stage,
        )
