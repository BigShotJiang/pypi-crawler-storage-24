"""
SQL queries for extracting table metadata from source databases.

This module provides SQL query templates for extracting table metadata such as
row counts and data sizes from various source database types.

TODO: Rename this file to source_schema_queries.py to align with target_schema_queries.py
"""

# Source type constants


from data_migration_orchestrator.utils.sql_utils import quote_string_literal
from data_migration_orchestrator.utils.table_utils import parse_table_name


SOURCE_TYPE_SQLSERVER = "sqlserver"
SOURCE_TYPE_POSTGRESQL = "postgresql"
SOURCE_TYPE_REDSHIFT = "redshift"
SOURCE_TYPE_ORACLE = "oracle"
SOURCE_TYPE_MYSQL = "mysql"

# Source type aliases
SOURCE_TYPE_ALIASES = {
    "sqlserver": SOURCE_TYPE_SQLSERVER,
    "mssql": SOURCE_TYPE_SQLSERVER,
    "sql-server": SOURCE_TYPE_SQLSERVER,
    "postgresql": SOURCE_TYPE_POSTGRESQL,
    "postgres": SOURCE_TYPE_POSTGRESQL,
    "redshift": SOURCE_TYPE_REDSHIFT,
    "aws-redshift": SOURCE_TYPE_REDSHIFT,
    "amazon-redshift": SOURCE_TYPE_REDSHIFT,
    "oracle": SOURCE_TYPE_ORACLE,
    "mysql": SOURCE_TYPE_MYSQL,
}

# SQL Server constants
SQLSERVER_PAGE_SIZE_KB = 8
KB_TO_MB = 1024.0
DECIMAL_PLACES = 2
NUMERIC_PRECISION = 36
NUMERIC_SCALE = 2

# SQL Server index constants
# Index IDs 0 (heap) and 1 (clustered) contain actual data pages
# Index IDs 2+ are non-clustered indexes (index pages only)
MAX_DATA_INDEX_ID = 2
ZERO_PAGES = 0

# SQL Server system table flag
# is_ms_shipped = 0 means user table (not a system table)
USER_TABLE_FLAG = 0

# Table name parsing constants
SINGLE_PART_NAME_LENGTH = 1  # table_name
TWO_PART_NAME_LENGTH = 2  # schema.table_name
SCHEMA_PART_INDEX = -2  # Second to last part in multi-part name
TABLE_PART_INDEX = -1  # Last part in multi-part name

# Column names for metadata query results
COLUMN_ROW_COUNTS = "row_counts"
COLUMN_DATA_MB = "data_mb"

# Column names for schema query results
COLUMN_NAME = "column_name"
DATA_TYPE = "data_type"
MAX_LENGTH = "max_length"
NUMERIC_PRECISION_COL = "precision"
NUMERIC_SCALE_COL = "scale"
IS_NULLABLE_COL = "is_nullable"
ORDINAL_POSITION_COL = "ordinal_position"

# SQL Server query template for extracting table metadata
# TODO SNOW-2869618: We need a query generator for the all dialects and to have a way to sanitize the query
SQLSERVER_TABLE_METADATA_QUERY = f"""
SELECT
    SUM(partitions.rows) AS {COLUMN_ROW_COUNTS},
    CAST(ROUND(((SUM(CASE WHEN indexes.index_id < {MAX_DATA_INDEX_ID} THEN alloc_units.used_pages ELSE {ZERO_PAGES} END)
        * {SQLSERVER_PAGE_SIZE_KB}) / {KB_TO_MB}), {DECIMAL_PLACES})
        AS NUMERIC({NUMERIC_PRECISION}, {NUMERIC_SCALE})) AS {COLUMN_DATA_MB}
FROM
    sys.tables tables
INNER JOIN
    sys.schemas schemas ON tables.schema_id = schemas.schema_id
INNER JOIN
    sys.indexes indexes ON tables.OBJECT_ID = indexes.object_id
INNER JOIN
    sys.partitions partitions ON indexes.object_id = partitions.OBJECT_ID AND indexes.index_id = partitions.index_id
INNER JOIN
    sys.allocation_units alloc_units ON partitions.partition_id = alloc_units.container_id
WHERE
    {{where_clause}}
    AND tables.is_ms_shipped = {USER_TABLE_FLAG}
""".strip()

SQLSERVER_TABLE_SCHEMA_QUERY = f"""
SELECT
    COLUMN_NAME as {COLUMN_NAME},
    DATA_TYPE as {DATA_TYPE},
    CHARACTER_MAXIMUM_LENGTH as {MAX_LENGTH},
    NUMERIC_PRECISION as {NUMERIC_PRECISION_COL},
    NUMERIC_SCALE as {NUMERIC_SCALE_COL},
    IS_NULLABLE as {IS_NULLABLE_COL},
    ORDINAL_POSITION as {ORDINAL_POSITION_COL}
FROM
    INFORMATION_SCHEMA.COLUMNS
WHERE
    {{where_clause}}
ORDER BY
    ORDINAL_POSITION
""".strip()

# Redshift query templates for extracting table metadata
# Redshift is based on PostgreSQL, so we use pg_* system tables
# Note: svv_table_info.size is already in 1 MB blocks, no conversion needed
REDSHIFT_TABLE_METADATA_QUERY = f"""
SELECT
    SUM(rows) AS {COLUMN_ROW_COUNTS},
    CAST(ROUND(SUM(size_mb), {DECIMAL_PLACES}) AS NUMERIC({NUMERIC_PRECISION}, {NUMERIC_SCALE})) AS {COLUMN_DATA_MB}
FROM (
    SELECT
        tbl.rows,
        (tbl.size)::float AS size_mb
    FROM (
        SELECT
            "schema" AS schemaname,
            "table" AS tablename,
            table_id,
            size,
            COALESCE(tbl_rows, 0) AS rows
        FROM svv_table_info
    ) tbl
    WHERE
        {{where_clause}}
) subquery
""".strip()

REDSHIFT_TABLE_SCHEMA_QUERY = f"""
SELECT
    column_name as {COLUMN_NAME},
    data_type as {DATA_TYPE},
    character_maximum_length as {MAX_LENGTH},
    numeric_precision as {NUMERIC_PRECISION_COL},
    numeric_scale as {NUMERIC_SCALE_COL},
    is_nullable as {IS_NULLABLE_COL},
    ordinal_position as {ORDINAL_POSITION_COL}
FROM
    information_schema.columns
WHERE
    {{where_clause}}
ORDER BY
    ordinal_position
""".strip()

# PostgreSQL constants
DEFAULT_POSTGRESQL_SCHEMA = "public"

POSTGRESQL_TABLE_SCHEMA_QUERY = f"""
SELECT
    column_name as {COLUMN_NAME},
    data_type as {DATA_TYPE},
    character_maximum_length as {MAX_LENGTH},
    numeric_precision as {NUMERIC_PRECISION_COL},
    numeric_scale as {NUMERIC_SCALE_COL},
    is_nullable as {IS_NULLABLE_COL},
    ordinal_position as {ORDINAL_POSITION_COL}
FROM
    information_schema.columns
WHERE
    {{where_clause}}
ORDER BY
    ordinal_position
""".strip()


def build_sqlserver_metadata_query(table_name: str) -> str:
    """
    Build a SQL Server query to extract table metadata.

    Args:
        table_name: The name of the table to extract metadata from.

    Returns:
        SQL query string with the table name inserted

    Raises:
        ValueError: If table_name is empty or None

    """
    if not table_name:
        raise ValueError("table_name is required and cannot be empty")

    parts = parse_table_name(table_name, source_type="sqlserver")

    if parts.schema is not None:
        schema_quoted = quote_string_literal(parts.schema, unicode_prefix=True)
        table_quoted = quote_string_literal(parts.table, unicode_prefix=True)
        where_clause = (
            f"schemas.name = {schema_quoted} AND tables.name = {table_quoted}"
        )
    else:
        table_quoted = quote_string_literal(parts.table, unicode_prefix=True)
        where_clause = f"tables.name = {table_quoted}"

    return SQLSERVER_TABLE_METADATA_QUERY.format(
        where_clause=where_clause
    )  # TODO SNOW-2869618: We need a query generator for the all dialects and to have a way to sanitize the query


def build_sqlserver_schema_query(table_name: str) -> str:
    """
    Build a SQL Server query to extract table schema (column definitions).

    Args:
        table_name: The name of the table to extract schema from.

    Returns:
        SQL query string with the table name inserted

    Raises:
        ValueError: If table_name is empty or None

    """
    if not table_name:
        raise ValueError("table_name is required and cannot be empty")

    parts = parse_table_name(table_name, source_type="sqlserver")

    where_conditions = []

    if parts.database is not None:
        database_quoted = quote_string_literal(parts.database, unicode_prefix=True)
        where_conditions.append(f"TABLE_CATALOG = {database_quoted}")

    if parts.schema is not None:
        schema_quoted = quote_string_literal(parts.schema, unicode_prefix=True)
        where_conditions.append(f"TABLE_SCHEMA = {schema_quoted}")

    table_quoted = quote_string_literal(parts.table, unicode_prefix=True)
    where_conditions.append(f"TABLE_NAME = {table_quoted}")

    where_clause = " AND ".join(where_conditions)

    return SQLSERVER_TABLE_SCHEMA_QUERY.format(where_clause=where_clause)


def build_redshift_metadata_query(table_name: str) -> str:
    """
    Build a Redshift query to extract table metadata.

    Args:
        table_name: The name of the table to extract metadata from.

    Returns:
        SQL query string with the table name inserted

    Raises:
        ValueError: If table_name is empty or None

    """
    if not table_name:
        raise ValueError("table_name is required and cannot be empty")

    parts = parse_table_name(table_name, source_type="redshift")

    if parts.schema is not None:
        schema_quoted = quote_string_literal(parts.schema)
        table_quoted = quote_string_literal(parts.table)
        where_clause = f"schemaname = {schema_quoted} AND tablename = {table_quoted}"
    else:
        table_quoted = quote_string_literal(parts.table)
        where_clause = f"tablename = {table_quoted}"

    return REDSHIFT_TABLE_METADATA_QUERY.format(where_clause=where_clause)


def build_redshift_schema_query(table_name: str) -> str:
    """
    Build a Redshift query to extract table schema (column definitions).

    Args:
        table_name: The name of the table to extract schema from.

    Returns:
        SQL query string with the table name inserted

    Raises:
        ValueError: If table_name is empty or None

    """
    if not table_name:
        raise ValueError("table_name is required and cannot be empty")

    parts = parse_table_name(table_name, source_type="redshift")

    where_conditions = []

    if parts.database is not None:
        database_quoted = quote_string_literal(parts.database)
        where_conditions.append(f"table_catalog = {database_quoted}")

    if parts.schema is not None:
        schema_quoted = quote_string_literal(parts.schema)
        where_conditions.append(f"table_schema = {schema_quoted}")

    table_quoted = quote_string_literal(parts.table)
    where_conditions.append(f"table_name = {table_quoted}")

    where_clause = " AND ".join(where_conditions)

    return REDSHIFT_TABLE_SCHEMA_QUERY.format(where_clause=where_clause)


def build_postgresql_metadata_query(table_name: str) -> str:
    """
    Build a PostgreSQL query to extract table metadata.

    Uses COUNT(*) for exact row counts and pg_total_relation_size for data size.
    This avoids relying on pg_class.reltuples which returns -1 for tables that
    have never been analyzed (ANALYZE not yet run).

    Args:
        table_name: The name of the table to extract metadata from.

    Returns:
        SQL query string with the table name inserted

    Raises:
        ValueError: If table_name is empty or None

    """
    if not table_name:
        raise ValueError("table_name is required and cannot be empty")

    parts = parse_table_name(table_name, source_type="postgresql")

    schema = parts.schema if parts.schema is not None else DEFAULT_POSTGRESQL_SCHEMA
    table_ref = f"{schema}.{parts.table}"
    table_ref_quoted = quote_string_literal(table_ref)

    return (
        f"SELECT\n"
        f"    COUNT(*) AS {COLUMN_ROW_COUNTS},\n"
        f"    CAST(ROUND((pg_total_relation_size({table_ref_quoted}::regclass)::numeric\n"
        f"        / ({KB_TO_MB} * {KB_TO_MB})), {DECIMAL_PLACES})\n"
        f"        AS NUMERIC({NUMERIC_PRECISION}, {NUMERIC_SCALE})) AS {COLUMN_DATA_MB}\n"
        f"FROM {schema}.{parts.table}"
    )


def build_postgresql_schema_query(table_name: str) -> str:
    """
    Build a PostgreSQL query to extract table schema (column definitions).

    Args:
        table_name: The name of the table to extract schema from.

    Returns:
        SQL query string with the table name inserted

    Raises:
        ValueError: If table_name is empty or None

    """
    if not table_name:
        raise ValueError("table_name is required and cannot be empty")

    parts = parse_table_name(table_name, source_type="postgresql")

    where_conditions = []

    if parts.database is not None:
        database_quoted = quote_string_literal(parts.database)
        where_conditions.append(f"table_catalog = {database_quoted}")

    schema = parts.schema if parts.schema is not None else DEFAULT_POSTGRESQL_SCHEMA
    schema_quoted = quote_string_literal(schema)
    where_conditions.append(f"table_schema = {schema_quoted}")

    table_quoted = quote_string_literal(parts.table)
    where_conditions.append(f"table_name = {table_quoted}")

    where_clause = " AND ".join(where_conditions)

    return POSTGRESQL_TABLE_SCHEMA_QUERY.format(where_clause=where_clause)


def build_metadata_query(source_type: str, table_name: str) -> str:
    """
    Build a metadata extraction query for the specified source type.

    Args:
        source_type: The type of source database (e.g., 'sqlserver', 'redshift', 'postgresql', 'mssql')
        table_name: The name of the table to extract metadata from

    Returns:
        SQL query string appropriate for the source type

    Raises:
        ValueError: If source_type is not supported or table_name is empty
        NotImplementedError: If the source type is recognized but not yet implemented

    """
    if not table_name:
        raise ValueError("table_name is required and cannot be empty")

    if not source_type:
        raise ValueError("source_type is required and cannot be empty")

    resolved_type = SOURCE_TYPE_ALIASES.get(source_type.lower())
    if resolved_type is None:
        raise ValueError(
            f"Unsupported source type. "
            f"Supported types: {', '.join(sorted(set(SOURCE_TYPE_ALIASES.keys())))}"
        )

    if resolved_type == SOURCE_TYPE_SQLSERVER:
        return build_sqlserver_metadata_query(table_name)
    elif resolved_type == SOURCE_TYPE_REDSHIFT:
        return build_redshift_metadata_query(table_name)
    elif resolved_type == SOURCE_TYPE_POSTGRESQL:
        return build_postgresql_metadata_query(table_name)

    raise NotImplementedError(
        f"Metadata extraction for {resolved_type} is not yet implemented"
    )


def build_schema_query(source_type: str, table_name: str) -> str:
    """
    Build a schema extraction query for the specified source type.

    Args:
        source_type: The type of source database (e.g., 'sqlserver', 'redshift', 'postgresql', 'mssql')
        table_name: The name of the table to extract schema from

    Returns:
        SQL query string appropriate for the source type

    Raises:
        ValueError: If source_type is not supported or table_name is empty
        NotImplementedError: If the source type is recognized but not yet implemented

    """
    if not table_name:
        raise ValueError("table_name is required and cannot be empty")

    if not source_type:
        raise ValueError("source_type is required and cannot be empty")

    resolved_type = SOURCE_TYPE_ALIASES.get(source_type.lower())
    if resolved_type is None:
        raise ValueError(
            f"Unsupported source type. "
            f"Supported types: {', '.join(sorted(set(SOURCE_TYPE_ALIASES.keys())))}"
        )

    if resolved_type == SOURCE_TYPE_SQLSERVER:
        return build_sqlserver_schema_query(table_name)
    elif resolved_type == SOURCE_TYPE_REDSHIFT:
        return build_redshift_schema_query(table_name)
    elif resolved_type == SOURCE_TYPE_POSTGRESQL:
        return build_postgresql_schema_query(table_name)

    raise NotImplementedError(
        f"Schema extraction for {resolved_type} is not yet implemented"
    )
