"""Query generation modules for data migration orchestrator."""

from data_migration_orchestrator.data_migration_core.queries.table_metadata import (
    SQLSERVER_TABLE_METADATA_QUERY,
    build_metadata_query,
    build_sqlserver_metadata_query,
)


__all__ = [
    "SQLSERVER_TABLE_METADATA_QUERY",
    "build_metadata_query",
    "build_sqlserver_metadata_query",
]
