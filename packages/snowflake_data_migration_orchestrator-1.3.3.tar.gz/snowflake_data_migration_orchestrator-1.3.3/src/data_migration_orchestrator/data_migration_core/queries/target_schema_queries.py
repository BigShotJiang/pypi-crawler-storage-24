"""
SQL queries for extracting schema information from target databases.

This module provides SQL query builders for querying target database schema
such as table existence and column definitions. Currently supports Snowflake.

TODO: A query generator should be in place so we can generate the queries for the all dialects.
"""

# Target type constants


from data_migration_orchestrator.utils.sql_utils import quote_string_literal


TARGET_TYPE_SNOWFLAKE = "snowflake"

# Target type aliases
TARGET_TYPE_ALIASES = {
    "snowflake": TARGET_TYPE_SNOWFLAKE,
    "sf": TARGET_TYPE_SNOWFLAKE,
}


def build_snowflake_table_exists_query(
    database_name: str, schema_name: str, table_name: str
) -> str:
    """
    Build a Snowflake query to check if a table exists.

    Args:
        database_name: The database name
        schema_name: The schema name
        table_name: The table name

    Returns:
        SQL query string to check table existence

    Note:
        Uses UPPER() for comparisons because Snowflake stores unquoted identifiers
        in uppercase in INFORMATION_SCHEMA, and string comparisons are case-sensitive.

    """
    return f"""
        SELECT COUNT(*) as TABLE_EXISTS
        FROM {database_name}.INFORMATION_SCHEMA.TABLES
        WHERE TABLE_CATALOG = UPPER({quote_string_literal(database_name)})
          AND TABLE_SCHEMA = UPPER({quote_string_literal(schema_name)})
          AND TABLE_NAME = UPPER({quote_string_literal(table_name)})
    """


def build_snowflake_table_schema_query(
    database_name: str, schema_name: str, table_name: str
) -> str:
    """
    Build a Snowflake query to get table column definitions.

    Args:
        database_name: The database name
        schema_name: The schema name
        table_name: The table name

    Returns:
        SQL query string to retrieve column schema

    Note:
        Uses UPPER() for comparisons because Snowflake stores unquoted identifiers
        in uppercase in INFORMATION_SCHEMA, and string comparisons are case-sensitive.

    """
    return f"""
        SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
               NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE, ORDINAL_POSITION
        FROM {database_name}.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_CATALOG = UPPER({quote_string_literal(database_name)})
          AND TABLE_SCHEMA = UPPER({quote_string_literal(schema_name)})
          AND TABLE_NAME = UPPER({quote_string_literal(table_name)})
        ORDER BY ORDINAL_POSITION
    """


def build_table_exists_query(
    target_type: str, database_name: str, schema_name: str, table_name: str
) -> str:
    """
    Build a table existence query for the specified target type.

    Args:
        target_type: The target database type (e.g., 'snowflake')
        database_name: The database name
        schema_name: The schema name
        table_name: The table name

    Returns:
        SQL query string appropriate for the target type

    Raises:
        ValueError: If target_type is not supported
        NotImplementedError: If target type is recognized but not yet implemented

    """
    resolved_type = TARGET_TYPE_ALIASES.get(target_type.lower())
    if resolved_type is None:
        raise ValueError(
            f"Unsupported target type '{target_type}'. "
            f"Supported types: {', '.join(sorted(TARGET_TYPE_ALIASES.keys()))}"
        )

    if resolved_type == TARGET_TYPE_SNOWFLAKE:
        return build_snowflake_table_exists_query(
            database_name, schema_name, table_name
        )

    raise NotImplementedError(
        f"Table existence query for {resolved_type} is not yet implemented"
    )


def build_table_schema_query(
    target_type: str, database_name: str, schema_name: str, table_name: str
) -> str:
    """
    Build a table schema query for the specified target type.

    Args:
        target_type: The target database type (e.g., 'snowflake')
        database_name: The database name
        schema_name: The schema name
        table_name: The table name

    Returns:
        SQL query string appropriate for the target type

    Raises:
        ValueError: If target_type is not supported
        NotImplementedError: If target type is recognized but not yet implemented

    """
    resolved_type = TARGET_TYPE_ALIASES.get(target_type.lower())
    if resolved_type is None:
        raise ValueError(
            f"Unsupported target type '{target_type}'. "
            f"Supported types: {', '.join(sorted(TARGET_TYPE_ALIASES.keys()))}"
        )

    if resolved_type == TARGET_TYPE_SNOWFLAKE:
        return build_snowflake_table_schema_query(
            database_name, schema_name, table_name
        )

    raise NotImplementedError(
        f"Table schema query for {resolved_type} is not yet implemented"
    )
