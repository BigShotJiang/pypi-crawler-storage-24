"""
Central registry for default type mappings from all source databases.

This module imports dialect-specific mappings and provides a unified interface.
Each source database has its own file (e.g., sqlserver_default_mappings.py).

Organization:
- sqlserver_default_mappings.py - SQL Server mappings
- platforms/redshift/type_mappings.py - Redshift mappings
- postgresql_default_mappings.py - PostgreSQL mappings
- oracle_default_mappings.py - Oracle mappings (future)
- mysql_default_mappings.py - MySQL mappings (future)
"""

# Default mappings registry
# Imports from dialect-specific modules
# Using SourceType enum values as keys ensures consistency
from data_migration_orchestrator.data_migration_core.type_mappings.postgresql_default_mappings import (
    POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS,
)
from data_migration_orchestrator.data_migration_core.type_mappings.redshift_default_mappings import (
    REDSHIFT_TO_SNOWFLAKE_TYPE_MAPPINGS,
)
from data_migration_orchestrator.data_migration_core.type_mappings.sqlserver_default_mappings import (
    SQLSERVER_TO_SNOWFLAKE_TYPES,
)
from shared.enums.source_type import SourceType


DEFAULT_TYPE_MAPPINGS: dict[str, dict[str, str]] = {
    SourceType.SQLSERVER: SQLSERVER_TO_SNOWFLAKE_TYPES,
    SourceType.REDSHIFT: REDSHIFT_TO_SNOWFLAKE_TYPE_MAPPINGS,
    SourceType.POSTGRESQL: POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS,
    # Future: Import from other dialect modules
    # SourceType.ORACLE: ORACLE_TO_SNOWFLAKE_TYPES,
    # SourceType.MYSQL: MYSQL_TO_SNOWFLAKE_TYPES,
}


def get_default_mappings(source_type: str) -> dict[str, str] | None:
    """
    Get default type mappings for a source database type.

    Args:
        source_type: The source database type (e.g., SourceType.SQLSERVER or "sqlserver")

    Returns:
        Dictionary of source types to Snowflake types, or None if not found

    """
    return DEFAULT_TYPE_MAPPINGS.get(source_type.lower())


def get_available_source_types() -> list[str]:
    """
    Get list of source database types with default mappings.

    Returns:
        List of source type names

    """
    return sorted(DEFAULT_TYPE_MAPPINGS.keys())
