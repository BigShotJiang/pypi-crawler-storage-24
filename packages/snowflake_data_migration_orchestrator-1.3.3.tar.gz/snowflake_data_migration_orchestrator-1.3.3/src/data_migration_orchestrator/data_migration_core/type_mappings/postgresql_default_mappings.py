"""
PostgreSQL to Snowflake data type mappings.

This module provides a comprehensive mapping from PostgreSQL data types
to their equivalent Snowflake data types.

Reference:
- PostgreSQL data types: https://www.postgresql.org/docs/current/datatype.html
- Snowflake data types: https://docs.snowflake.com/en/sql-reference/intro-summary-data-types
"""

# Comprehensive mapping of PostgreSQL types to Snowflake types
# Keys are lowercase for case-insensitive lookup
POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS: dict[str, str] = {
    # Integer types
    "smallint": "NUMBER(5,0)",
    "int2": "NUMBER(5,0)",
    "integer": "NUMBER(10,0)",
    "int": "NUMBER(10,0)",
    "int4": "NUMBER(10,0)",
    "bigint": "NUMBER(19,0)",
    "int8": "NUMBER(19,0)",
    "smallserial": "NUMBER(5,0)",
    "serial": "NUMBER(10,0)",
    "bigserial": "NUMBER(19,0)",
    # Decimal/Numeric types (precision preserved in actual migration)
    "decimal": "NUMBER(20,10)",
    "numeric": "NUMBER(20,10)",
    # Floating point types
    "real": "FLOAT",
    "float4": "FLOAT",
    "double precision": "FLOAT",
    "float8": "FLOAT",
    "float": "FLOAT",
    # Monetary type
    "money": "VARCHAR",
    # Character types
    "char": "VARCHAR",
    "character": "VARCHAR",
    "bpchar": "VARCHAR",
    "varchar": "VARCHAR",
    "character varying": "VARCHAR",
    "text": "VARCHAR",
    "name": "VARCHAR",
    # Boolean type
    "boolean": "BOOLEAN",
    "bool": "BOOLEAN",
    # Date/Time types
    "date": "DATE",
    "timestamp": "TIMESTAMP_NTZ",
    "timestamp without time zone": "TIMESTAMP_NTZ",
    "timestamptz": "TIMESTAMP_TZ",
    "timestamp with time zone": "TIMESTAMP_TZ",
    "time": "TIME",
    "time without time zone": "TIME",
    "timetz": "TIME",
    "time with time zone": "TIME",
    "interval": "VARCHAR",
    # Binary types
    "bytea": "BINARY",
    # Network address types
    "cidr": "VARCHAR",
    "inet": "VARCHAR",
    "macaddr": "VARCHAR",
    "macaddr8": "VARCHAR",
    # Bit string types
    "bit": "VARCHAR",
    "bit varying": "VARCHAR",
    "varbit": "VARCHAR",
    # UUID type
    "uuid": "VARCHAR(36)",
    # JSON types
    "json": "VARIANT",
    "jsonb": "VARIANT",
    # XML type
    "xml": "VARIANT",
    # Array types (generic fallback)
    "array": "VARIANT",
    # Range types
    "int4range": "VARCHAR",
    "int8range": "VARCHAR",
    "numrange": "VARCHAR",
    "tsrange": "VARCHAR",
    "tstzrange": "VARCHAR",
    "daterange": "VARCHAR",
    # Geometric types
    "point": "VARCHAR",
    "line": "VARCHAR",
    "lseg": "VARCHAR",
    "box": "VARCHAR",
    "path": "VARCHAR",
    "polygon": "VARCHAR",
    "circle": "VARCHAR",
    # Full text search types
    "tsvector": "VARCHAR",
    "tsquery": "VARCHAR",
    # OID type (internal)
    "oid": "NUMBER(10,0)",
    # Enumerated types (generic fallback)
    "enum": "VARCHAR",
    # Domain types (generic fallback)
    "domain": "VARCHAR",
}


def get_snowflake_type(
    postgresql_type: str,
    precision: int | None = None,
    scale: int | None = None,
    length: int | None = None,
) -> str:
    """
    Get the Snowflake equivalent type for a PostgreSQL type.

    This function provides more precise mapping when precision/scale/length
    are known from the source schema.

    Args:
        postgresql_type: PostgreSQL data type name
        precision: Numeric precision (for DECIMAL/NUMERIC)
        scale: Numeric scale (for DECIMAL/NUMERIC)
        length: Character length (for CHAR/VARCHAR)

    Returns:
        Snowflake data type string

    """
    normalized = postgresql_type.lower().strip()

    # Handle parameterized types
    if normalized in ("decimal", "numeric") and precision is not None:
        actual_scale = scale if scale is not None else 0
        return f"NUMBER({precision},{actual_scale})"

    if normalized in ("char", "character", "bpchar") and length is not None:
        return f"CHAR({length})"

    if normalized in ("varchar", "character varying") and length is not None:
        return f"VARCHAR({length})"

    if normalized == "bytea" and length is not None:
        return f"BINARY({length})"

    if normalized in ("bit", "bit varying", "varbit") and length is not None:
        return f"VARCHAR({length})"

    # Fall back to default mapping
    return POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS.get(normalized, "VARCHAR")
