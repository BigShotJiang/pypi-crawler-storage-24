"""
Default SQL Server to Snowflake type mappings.

These mappings are based on the snowflake-data-validation project:
snowflake-data-validation/sqlserver/extractor/templates/sqlserver_to_snowflake_datatypes_mapping_template.yaml

These are hardcoded for performance and will be the default fallback.
Users can override these with custom mapping files.
"""

# SQL Server to Snowflake type mappings
SQLSERVER_TO_SNOWFLAKE_TYPES = {
    # Numeric Types
    "BIGINT": "NUMBER",
    "INT": "NUMBER",
    "SMALLINT": "NUMBER",
    "TINYINT": "NUMBER",
    "DECIMAL": "NUMBER(20, 10)",
    "NUMERIC": "NUMBER(20, 10)",
    "MONEY": "NUMBER(20, 10)",
    "SMALLMONEY": "NUMBER(10, 5)",
    # Floating Point Types
    "FLOAT": "FLOAT",
    "REAL": "FLOAT",
    # Logical Types
    "BIT": "BOOLEAN",
    # Character Types
    "CHAR": "VARCHAR",
    "TEXT": "VARCHAR",
    "VARCHAR": "VARCHAR",
    # National Character Types (Unicode)
    "NCHAR": "VARCHAR",
    "NTEXT": "VARCHAR",
    "NVARCHAR": "VARCHAR",
    # Date and Time Types
    "DATE": "DATE",
    "TIME": "TIME",
    "DATETIME": "TIMESTAMP_NTZ",
    "DATETIME2": "TIMESTAMP_NTZ",
    "SMALLDATETIME": "TIMESTAMP_NTZ",
    "DATETIMEOFFSET": "TIMESTAMP_TZ",
    # Binary Types
    "BINARY": "BINARY",
    "VARBINARY": "BINARY",
    "IMAGE": "BINARY",
    "TIMESTAMP": "BINARY",  # SQL Server TIMESTAMP is a row version, not datetime
    # Special Types
    "UNIQUEIDENTIFIER": "VARCHAR",
    "XML": "VARIANT",
    "SQL_VARIANT": "VARIANT",
    "GEOGRAPHY": "GEOGRAPHY",
    "GEOMETRY": "GEOMETRY",
    "HIERARCHYID": "VARCHAR",
    "SYSNAME": "VARCHAR",
    # SQL Server 2025+ Types
    "JSON": "VARIANT",
    "VECTOR": "VARCHAR",  # ODBC exposes as varchar(max) JSON array
}
