-- Get all partition metadata for a table
-- Returns partition info needed for creating extraction tasks
CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.GET_PARTITION_METADATA(
    p_table_metadata_id INT
)
RETURNS TABLE (
    ID INT,
    PARTITION_NUMBER INT,
    MIN_VALUE VARIANT,
    MAX_VALUE VARIANT,
    N_ROWS BIGINT,
    SYNCHRONIZATION_DATA VARIANT,
    SYNC_TIMESTAMP TIMESTAMP_NTZ
)
LANGUAGE SQL
AS
$$
DECLARE
    res RESULTSET;
BEGIN
    res := (
        SELECT
            ID,
            PARTITION_NUMBER,
            MIN_VALUE,
            MAX_VALUE,
            N_ROWS,
            SYNCHRONIZATION_DATA,
            SYNC_TIMESTAMP
        FROM SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA
        WHERE TABLE_ID = :p_table_metadata_id
        ORDER BY PARTITION_NUMBER
    );
    RETURN TABLE(res);
END;
$$;
