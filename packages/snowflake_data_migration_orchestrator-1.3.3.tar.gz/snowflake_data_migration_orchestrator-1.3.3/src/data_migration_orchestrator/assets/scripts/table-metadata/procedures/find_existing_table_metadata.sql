-- Find existing TABLE_METADATA for a source table from any previous workflow
-- Returns the most recent preprocessed table metadata ID, or NULL if none found
CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.FIND_EXISTING_TABLE_METADATA(
    p_source_identifier TEXT
)
RETURNS INT
LANGUAGE SQL
AS
$$
DECLARE
    result INT;
BEGIN
    SELECT ID INTO :result
    FROM SNOWCONVERT_AI.DATA_MIGRATION.TABLE_METADATA
    WHERE SOURCE_IDENTIFIER = :p_source_identifier
      AND HAS_BEEN_PREPROCESSED = TRUE
    ORDER BY UPDATED_AT DESC
    LIMIT 1;
    RETURN result;
END;
$$;
