-- Copy all PARTITION_METADATA rows from source table to new table
-- Copies partition boundaries and SYNCHRONIZATION_DATA (critical for incremental sync)
-- Returns the number of partitions copied
CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.COPY_PARTITION_METADATA(
    p_source_table_metadata_id INT,
    p_new_table_metadata_id INT
)
RETURNS INT
LANGUAGE SQL
AS
$$
DECLARE
    partitions_copied INT;
BEGIN
    INSERT INTO SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA (
        ID,
        TABLE_ID,
        PARTITION_NUMBER,
        MIN_VALUE,
        MAX_VALUE,
        N_ROWS,
        MIGRATION_STATUS,
        SYNCHRONIZATION_DATA,
        SYNC_TIMESTAMP
    )
    SELECT
        SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA_ID_SEQ.NEXTVAL,
        :p_new_table_metadata_id,
        PARTITION_NUMBER,
        MIN_VALUE,
        MAX_VALUE,
        N_ROWS,
        'PENDING',  -- Reset status for the new workflow
        SYNCHRONIZATION_DATA,  -- Copy sync data (critical!)
        SYNC_TIMESTAMP  -- Copy last sync timestamp
    FROM SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA
    WHERE TABLE_ID = :p_source_table_metadata_id
    ORDER BY PARTITION_NUMBER;

    partitions_copied := SQLROWCOUNT;

    RETURN partitions_copied;
END;
$$;
