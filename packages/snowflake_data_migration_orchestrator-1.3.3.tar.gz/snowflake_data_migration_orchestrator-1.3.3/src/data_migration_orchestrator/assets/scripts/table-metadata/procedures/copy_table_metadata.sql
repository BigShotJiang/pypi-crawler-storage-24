-- Copy TABLE_METADATA from an existing record to a new workflow
-- Uses the provided table configuration from the current workflow
-- Returns the new table metadata ID
CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.COPY_TABLE_METADATA(
    p_source_table_metadata_id INT,
    p_new_workflow_id INT,
    p_table_configuration VARIANT
)
RETURNS INT
LANGUAGE SQL
AS
$$
DECLARE
    new_id INT;
BEGIN
    new_id := (SELECT SNOWCONVERT_AI.DATA_MIGRATION.TABLE_METADATA_ID_SEQ.NEXTVAL);

    INSERT INTO SNOWCONVERT_AI.DATA_MIGRATION.TABLE_METADATA (
        ID,
        WORKFLOW_ID,
        SOURCE_IDENTIFIER,
        TABLE_CONFIGURATION,
        HAS_BEEN_PREPROCESSED
    )
    SELECT
        :new_id,
        :p_new_workflow_id,
        SOURCE_IDENTIFIER,
        :p_table_configuration,
        TRUE  -- Already preprocessed since we're copying from a preprocessed source
    FROM SNOWCONVERT_AI.DATA_MIGRATION.TABLE_METADATA
    WHERE ID = :p_source_table_metadata_id;

    RETURN new_id;
END;
$$;
