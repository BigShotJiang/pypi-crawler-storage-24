CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.COMPLETE_WORKFLOWS()
RETURNS BOOLEAN
LANGUAGE SQL
AS
$$
DECLARE
    workflows_completed BOOLEAN DEFAULT FALSE;
    current_time TIMESTAMP_NTZ;
BEGIN
    -- Capture timestamp once for consistent use
    current_time := SYSDATE();

    -- Mark workflows as finished if all tasks are in terminal state
    UPDATE WORKFLOW
    SET
        STATUS = 'finished',
        END_TIME = :current_time
    WHERE STATUS = 'running'
        AND NOT EXISTS (
            SELECT 1
            FROM TASK_QUEUE
            WHERE TASK_QUEUE.WORKFLOW_ID = WORKFLOW.ID
            AND TASK_QUEUE.STATUS NOT IN ('failed', 'completed')
        );

    workflows_completed := SQLROWCOUNT > 0;

    -- Mark incomplete partitions as FAILED for any workflow that just finished
    UPDATE PARTITION_METADATA pm
    SET
        MIGRATION_STATUS = 'FAILED',
        MIGRATION_STATUS_TIMESTAMP = :current_time
    FROM TABLE_METADATA tm
    INNER JOIN WORKFLOW w ON tm.WORKFLOW_ID = w.ID
    WHERE pm.TABLE_ID = tm.ID
        AND w.STATUS = 'finished'
        AND w.END_TIME = :current_time  -- Just completed in this call
        AND pm.MIGRATION_STATUS != 'COMPLETED';

    RETURN workflows_completed;
END;
$$;
