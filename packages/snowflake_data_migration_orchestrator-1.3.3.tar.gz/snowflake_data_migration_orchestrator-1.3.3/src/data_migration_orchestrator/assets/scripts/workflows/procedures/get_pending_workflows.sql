CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.GET_PENDING_WORKFLOWS(AFFINITY TEXT)
RETURNS TABLE (
    ID INT,
    NAME TEXT,
    SOURCE_PLATFORM TEXT,
    TARGET_CLOUD_TYPE TEXT,
    TARGET_CLOUD_STAGE_NAME TEXT,
    TARGET_CLOUD_URL TEXT,
    SCHEMA_VERSION TEXT,
    WORKFLOW_TYPE TEXT,
    INITIATOR_ID TEXT,
    STATUS TEXT,
    CONFIGURATION VARIANT,
    CREATION_TIME TIMESTAMP,
    END_TIME TIMESTAMP,
    AFFINITY TEXT
)
LANGUAGE SQL
AS
$$
DECLARE
    assignment_id TEXT;
BEGIN
    -- Generate "unique" assignment_id
    SELECT 'assigning-' || DATE_PART(epoch_millisecond, SYSDATE()) || '-' || RANDOM()
    INTO :assignment_id;

    -- Mark workflows as "assigning" (a unique suffix is appended so that these specific workflows can be referenced later in the transaction)
    UPDATE SNOWCONVERT_AI.DATA_MIGRATION.WORKFLOW
    SET STATUS = :assignment_id
    WHERE STATUS ILIKE 'pending';

    -- Fetch the workflows that were marked
    LET result_set RESULTSET := (
        SELECT
            ID,
            NAME,
            SOURCE_PLATFORM,
            TARGET_CLOUD_TYPE,
            TARGET_CLOUD_STAGE_NAME,
            TARGET_CLOUD_URL,
            SCHEMA_VERSION,
            WORKFLOW_TYPE,
            INITIATOR_ID,
            STATUS,
            CONFIGURATION,
            CREATION_TIME,
            END_TIME,
            AFFINITY
        FROM SNOWCONVERT_AI.DATA_MIGRATION.WORKFLOW
        WHERE STATUS = :assignment_id AND (AFFINITY = :AFFINITY OR AFFINITY IS NULL OR :AFFINITY IS NULL)
    );

    -- Update the workflows to running status
    UPDATE SNOWCONVERT_AI.DATA_MIGRATION.WORKFLOW
    SET STATUS = 'running'
    WHERE STATUS = :assignment_id;

    RETURN TABLE(result_set);
END;
$$;
