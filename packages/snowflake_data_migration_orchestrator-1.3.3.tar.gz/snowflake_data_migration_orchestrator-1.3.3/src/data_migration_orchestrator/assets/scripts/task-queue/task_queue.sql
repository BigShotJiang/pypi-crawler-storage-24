CREATE OR REPLACE HYBRID TABLE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE(
    -- General Data
    ID INTEGER NOT NULL PRIMARY KEY, -- The ID that uniquely identifies this task.
    WORKFLOW_ID INTEGER NOT NULL, -- The ID that refers to the Job/Workflow ID that produced this task.
    NAME TEXT NOT NULL, -- An internal name that has no meaning for consumers/producers but can be used when logging. For example ('Table Metadata Extraction for Table MY_DB.MY_SCHEMA.MY_TABLE').
    EXECUTOR_TYPE TEXT NOT NULL, -- The component that should execute this task. Can be 'data-exchange-agent'/'warehouse'/'orchestrator'.
    STATUS TEXT NOT NULL DEFAULT 'pending', -- The status of the task. Can be 'pending'/'executing'/'failed'/'abandoned'/'completed'/'blocked'.
    PRIORITY FLOAT NOT NULL DEFAULT 2, -- The priority of the task, ranging from 0 to 3 (0 being the most urgent and 3 being the least urgent). It is a float to allow for fractional priorities, in the case of related tasks that have a suggested order to tackle them in.
    PAYLOAD VARIANT NOT NULL, -- The payload that contains all the information needed to execute the task. There are several kinds of payloads, but each payload has a "kind" field that indicates its type.
    SUCCESSOR_TASK_ID INT NULL DEFAULT NULL, -- The ID for the task that is waiting for the successor task, if any.
    LAST_ERROR_MESSAGE TEXT NULL, -- The last error message that was received, if any.
    AFFINITY TEXT NULL DEFAULT NULL, -- The affinity group that this task belongs to, if any.

    -- Metadata
    CREATION_TIME TIMESTAMP_NTZ NOT NULL DEFAULT SYSDATE(), -- The UTC time at which the task was created.
    START_TIME TIMESTAMP_NTZ NULL DEFAULT NULL, -- The UTC time at which the task started execution. Can be NULL while the task has not started execution.
    END_TIME TIMESTAMP_NTZ NULL DEFAULT NULL, -- The UTC time at which the task was completed (or definitely marked as failed). Can be NULL while the task has still not been completed.
    SCOPE TEXT NOT NULL, -- The scope of the task, which indicates what is the purpose of this task. Examples: "Table[MY_DB.MY_SCHEMA.MY_TABLE]::Preprocessing" or "Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[4]::Loading".

    -- Leasing
    LEASED_TO TEXT NULL DEFAULT NULL, -- The ID for the consumer that has taken a lease on this task. Can be NULL if no one has leased the task.
    LEASING_TIME TIMESTAMP_NTZ NULL DEFAULT NULL, -- The UTC time at which the task was leased. Can be NULL if no one has leased the task.
    LEASE_DURATION INTEGER NULL DEFAULT 5, -- The number of minutes for which a lease on this task is valid. Can be NULL if no one has leased the task.

    -- Retries
    AUTO_RETRY BOOLEAN NOT NULL DEFAULT TRUE, -- Indicates that the task can be automatically retried without risk.
    MAX_RETRIES INTEGER NOT NULL DEFAULT 3, -- Indicates the amount of times a task will be automatically retried after it is put into the FAILED state.
    MAX_RETRIES_IF_ABANDONED INTEGER NULL, -- Indicates the amount of times a task will be automatically retried after it is put into the ABANDONED state. Can be NULL if there is no max amount for this case. By default it is NULL.
    FAILURES INTEGER NOT NULL DEFAULT 0, -- Indicates the amount of times this task has been put into the FAILED state.
    ABANDONMENTS INTEGER NOT NULL DEFAULT 0, -- Indicates the amount of times this task has been put into the ABANDONED state.

    -- Caching
    STALE_TIME INTEGER NULL DEFAULT NULL -- The amount of time in minutes after which a completed task is considered stale and its results cannot be reliably used anymore. Can be NULL if there is no staleness for this task. By default it is NULL.
);
