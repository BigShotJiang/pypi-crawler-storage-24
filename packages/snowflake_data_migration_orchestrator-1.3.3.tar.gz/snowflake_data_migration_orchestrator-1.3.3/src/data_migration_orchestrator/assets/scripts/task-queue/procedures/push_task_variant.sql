CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.PUSH_TASK(
    workflow_id INT,
    executor_type TEXT,
    task_name TEXT,
    priority FLOAT,
    successor_task_id INT,
    is_blocked BOOLEAN,
    affinity TEXT,
    scope TEXT,
    payload VARIANT)
RETURNS INTEGER
LANGUAGE SQL
AS
$$
BEGIN
    LET task_id INTEGER;

    SELECT SNOWCONVERT_AI.DATA_MIGRATION.TASK_ID_SEQUENCE.NEXTVAL INTO :task_id;

    INSERT INTO SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE(
        ID,
        WORKFLOW_ID,
        NAME,
        EXECUTOR_TYPE,
        PRIORITY,
        AFFINITY,
        SCOPE,
        PAYLOAD,
        SUCCESSOR_TASK_ID,
        STATUS
    )
    SELECT
        :task_id,
        :workflow_id,
        :task_name,
        :executor_type,
        :priority,
        :affinity,
        :scope,
        :payload,
        :successor_task_id,
        CASE WHEN :is_blocked THEN 'blocked' ELSE 'pending' END
    ;

    RETURN task_id;
END;
$$
;
