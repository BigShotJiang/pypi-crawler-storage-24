CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.CREATE_TABLE(
    DATABASE_NAME VARCHAR,
    SCHEMA_NAME VARCHAR,
    TABLE_NAME VARCHAR,
    LOCATION VARCHAR,
    FILE_FORMAT VARCHAR,
    STAGE_FULL_NAME VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    FULL_TABLE_NAME VARCHAR;
    CREATE_DATABASE_SQL VARCHAR;
    CREATE_SCHEMA_SQL VARCHAR;
    CREATE_TABLE_SQL VARCHAR;
    FIRST_PARQUET_FILE VARCHAR;
    LIST_STAGE_SQL VARCHAR;
BEGIN
    -- Check if database exists, if not create it
    CREATE_DATABASE_SQL := 'CREATE DATABASE IF NOT EXISTS ' || DATABASE_NAME;
    EXECUTE IMMEDIATE CREATE_DATABASE_SQL;

    -- Check if schema exists, if not create it
    CREATE_SCHEMA_SQL := 'CREATE SCHEMA IF NOT EXISTS ' || DATABASE_NAME || '.' || SCHEMA_NAME;
    EXECUTE IMMEDIATE CREATE_SCHEMA_SQL;

    -- Build full table name
    FULL_TABLE_NAME := DATABASE_NAME || '.' || SCHEMA_NAME || '.' || TABLE_NAME;

    -- 1. Construct the dynamic SELECT statement, embedding the LOCATION variable's value
    LIST_STAGE_SQL := '
        SELECT METADATA$FILENAME
        FROM ' || LOCATION || '
        WHERE METADATA$FILENAME LIKE ''%.parquet''
        LIMIT 1';

    -- 2. Execute the dynamic SELECT statement into a temporary result set.
    EXECUTE IMMEDIATE LIST_STAGE_SQL;

    -- 3. Capture the result from the last executed query (the dynamic SELECT)
    SELECT "METADATA$FILENAME" INTO FIRST_PARQUET_FILE
    FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

    -- Check if a file was found before proceeding
    IF (FIRST_PARQUET_FILE IS NULL) THEN
        RETURN 'Error: No .parquet files found in stage ' || LOCATION;
    END IF;

    -- Create table using template from inferred schema (only if it doesn't exist)
    -- The internal quotes for LOCATION and FILE_FORMAT are correctly doubled up ('''...)
    CREATE_TABLE_SQL :=
        'CREATE TABLE IF NOT EXISTS ' || FULL_TABLE_NAME || ' ' ||
        'USING TEMPLATE ( ' ||
        '    SELECT ARRAY_AGG(OBJECT_CONSTRUCT(*)) ' ||
        '    FROM TABLE( ' ||
        '        INFER_SCHEMA( ' ||
        '            LOCATION => ''' || STAGE_FULL_NAME || FIRST_PARQUET_FILE || ''', ' ||
        '            FILE_FORMAT => ''' || FILE_FORMAT || ''' ' ||
        '        ) ' ||
        '    ) ' ||
        ')';

    EXECUTE IMMEDIATE CREATE_TABLE_SQL;

    RETURN 'Table ' || FULL_TABLE_NAME || ' created or already exists';
END;
$$;
