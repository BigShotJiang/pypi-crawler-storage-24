CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.EXPIRE_LEASES()
RETURNS BOOLEAN
LANGUAGE SQL
AS
$$
DECLARE
    rows_updated INT;
BEGIN
    UPDATE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
    SET
        ABANDONMENTS = ABANDONMENTS + 1,
        STATUS =
            CASE
                WHEN ABANDONMENTS < MAX_RETRIES_IF_ABANDONED OR MAX_RETRIES_IF_ABANDONED IS NULL THEN 'pending'
                ELSE 'failed'
            END,
        LAST_ERROR_MESSAGE = 'Lease expired (consumer "' || LEASED_TO || '" did not refresh the lease appropriately).',
        LEASED_TO = NULL,
        START_TIME = NULL,
        LEASING_TIME = NULL
    WHERE LEASED_TO IS NOT NULL
        AND SYSDATE() > TIMESTAMPADD(MINUTE, LEASE_DURATION, LEASING_TIME)
        AND STATUS NOT IN ('completed', 'failed');

    rows_updated := SQLROWCOUNT;

    RETURN rows_updated > 0;
END;
$$
;
