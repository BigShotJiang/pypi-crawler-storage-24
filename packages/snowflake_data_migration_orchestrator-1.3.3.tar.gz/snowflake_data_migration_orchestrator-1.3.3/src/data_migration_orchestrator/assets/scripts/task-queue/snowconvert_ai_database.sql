-- NOTE: This script is not executed by the migration. Database creation is
-- handled in migration_0001_initial.py which checks existence first to avoid
-- requiring CREATE DATABASE privileges when the database already exists.
CREATE DATABASE IF NOT EXISTS SNOWCONVERT_AI;
