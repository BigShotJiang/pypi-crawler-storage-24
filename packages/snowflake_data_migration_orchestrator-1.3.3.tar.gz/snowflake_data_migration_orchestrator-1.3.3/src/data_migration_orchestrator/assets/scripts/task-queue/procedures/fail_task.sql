CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.FAIL_TASK(
    task_id INTEGER,
    consumer_id TEXT,
    error_message TEXT)
RETURNS BOOLEAN
LANGUAGE SQL
AS
$$
DECLARE
    rows_updated INT;
BEGIN
    UPDATE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
    SET
        FAILURES = FAILURES + 1,
        STATUS =
            CASE
                WHEN FAILURES < MAX_RETRIES THEN 'pending'
                ELSE 'failed'
            END,
        LAST_ERROR_MESSAGE = :error_message,
        LEASED_TO = NULL,
        END_TIME =
            CASE
                WHEN FAILURES < MAX_RETRIES THEN NULL
                ELSE SYSDATE() -- Mark end time only if task is definitely marked as failed
            END,
        LEASING_TIME = NULL
    WHERE ID = :task_id AND LEASED_TO = :consumer_id;

    rows_updated := SQLROWCOUNT;

    RETURN rows_updated > 0;
END;
$$
;
