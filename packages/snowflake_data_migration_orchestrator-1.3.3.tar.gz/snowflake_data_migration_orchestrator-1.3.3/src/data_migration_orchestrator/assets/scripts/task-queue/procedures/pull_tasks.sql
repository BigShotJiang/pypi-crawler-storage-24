CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.PULL_TASKS(
    consumer_id TEXT,
    executor_type TEXT,
    affinity TEXT,
    capacity INT)
RETURNS TABLE(ID INT, WORKFLOW_ID INT, NAME TEXT, PRIORITY FLOAT, PAYLOAD VARIANT, SCOPE TEXT)
LANGUAGE SQL
AS
$$
DECLARE
    results RESULTSET;
    lock_qid TEXT;
BEGIN
    BEGIN TRANSACTION;

    -- Lock up to :capacity pending tasks for this executor/affinity.
    -- WAIT 5 avoids immediate failure when another consumer holds a lock;
    -- it retries for up to 5 seconds before raising an error.
    SELECT ID
    FROM SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
    WHERE STATUS = 'pending'
        AND EXECUTOR_TYPE = :executor_type
        AND (AFFINITY = :affinity OR AFFINITY IS NULL OR :affinity IS NULL)
        AND LEASED_TO IS NULL
    ORDER BY PRIORITY ASC, ID ASC
    LIMIT :capacity
    FOR UPDATE WAIT 5;

    lock_qid := LAST_QUERY_ID();

    UPDATE SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
    SET
        LEASED_TO = :consumer_id,
        START_TIME = SYSDATE(),
        LEASING_TIME = SYSDATE(),
        STATUS = 'executing'
    WHERE ID IN (SELECT ID FROM TABLE(RESULT_SCAN(:lock_qid)));

    results := (
        SELECT ID, WORKFLOW_ID, NAME, PRIORITY, PAYLOAD, SCOPE
        FROM SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE
        WHERE ID IN (SELECT ID FROM TABLE(RESULT_SCAN(:lock_qid)))
    );

    COMMIT;

    RETURN TABLE(results);
END;
$$
;
-- TODO: Make sure this is caught as a warning (not error) when the WAIT expires.
