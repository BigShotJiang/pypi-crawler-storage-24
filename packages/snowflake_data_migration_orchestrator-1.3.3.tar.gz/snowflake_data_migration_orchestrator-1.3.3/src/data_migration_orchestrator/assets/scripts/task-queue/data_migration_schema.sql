-- NOTE: This script is not executed by the migration. Schema creation is
-- handled in migration_0001_initial.py which checks existence first to avoid
-- requiring CREATE SCHEMA privileges when the schema already exists.
CREATE SCHEMA IF NOT EXISTS SNOWCONVERT_AI.DATA_MIGRATION;
