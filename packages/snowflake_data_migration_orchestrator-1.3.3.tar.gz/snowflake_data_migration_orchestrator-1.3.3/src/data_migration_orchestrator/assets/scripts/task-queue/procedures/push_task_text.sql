CREATE OR REPLACE PROCEDURE SNOWCONVERT_AI.DATA_MIGRATION.PUSH_TASK(
    workflow_id INT,
    executor_type TEXT,
    task_name TEXT,
    priority FLOAT,
    successor_task_id INT,
    is_blocked BOOLEAN,
    affinity TEXT,
    scope TEXT,
    payload TEXT)
RETURNS INTEGER
LANGUAGE SQL
AS
$$
DECLARE
    call_result TEXT;
BEGIN
    LET variant_payload VARIANT := PARSE_JSON(payload);

    CALL SNOWCONVERT_AI.DATA_MIGRATION.PUSH_TASK(
        :workflow_id,
        :executor_type,
        :task_name,
        :priority,
        :successor_task_id,
        :is_blocked,
        :affinity,
        :scope,
        :variant_payload
    ) INTO :call_result;

    RETURN call_result;
END;
$$
;
