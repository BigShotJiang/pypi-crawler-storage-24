CREATE SEQUENCE IF NOT EXISTS SNOWCONVERT_AI.DATA_MIGRATION.TASK_ID_SEQUENCE START = 1 INCREMENT = 1;
-- This does not guarantee the values to be in order. If we wanted that, we can use ORDER parameter.
