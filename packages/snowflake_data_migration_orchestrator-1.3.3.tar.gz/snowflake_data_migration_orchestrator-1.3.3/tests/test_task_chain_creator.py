"""
Tests for TaskChainCreator.

This module tests the TaskChainCreator class, particularly the UNLOAD
extraction strategy support.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    ExtractionConfig,
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.exceptions.unsupported_extraction_strategy_error import (
    UnsupportedExtractionStrategyError,
)
from data_migration_orchestrator.data_migration_cloud.platforms.redshift.query_builder import (
    RedshiftQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundary,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    TargetType,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_chain_creator import (
    PartitionInput,
    TaskChainContext,
    TaskChainCreator,
)


class TestTaskChainCreatorUnloadStrategy:
    """Tests for UNLOAD extraction strategy in TaskChainCreator."""

    @pytest.fixture
    def source_table(self):
        """Create a sample source table identifier."""
        return TableIdentifier(
            database_name="test_db",
            schema_name="test_schema",
            table_name="test_table",
        )

    @pytest.fixture
    def target_table(self):
        """Create a sample target table identifier."""
        return TableIdentifier(
            database_name="SNOWFLAKE_DB",
            schema_name="PUBLIC",
            table_name="TEST_TABLE",
        )

    @pytest.fixture
    def source_schema(self):
        """Create a sample source schema."""
        return [
            {"column_name": "id", "data_type": "INTEGER"},
            {"column_name": "name", "data_type": "VARCHAR"},
            {"column_name": "created_at", "data_type": "TIMESTAMP"},
        ]

    @pytest.fixture
    def partition_input(self):
        """Create a sample partition input."""
        return PartitionInput(
            partition_index=1,
            partition_metadata_id=100,
            partition_boundary=PartitionBoundary(
                partition_index=1,
                where_clause="id >= 1 AND id < 1000",
                min_value=1,
                max_value=999,
                row_count=999,
            ),
            sync_data=None,
        )

    @pytest.fixture
    def mock_redshift_platform(self):
        """Create a mock Redshift platform with RedshiftQueryBuilder."""
        platform = MagicMock()
        platform.name = "redshift"

        # Use actual RedshiftQueryBuilder for realistic query generation
        query_builder = RedshiftQueryBuilder()
        platform.query_builder = query_builder

        return platform

    @pytest.fixture
    def mock_non_redshift_platform(self):
        """Create a mock non-Redshift platform (e.g., SQL Server)."""
        platform = MagicMock()
        platform.name = "sqlserver"

        # Mock query builder that is NOT a RedshiftQueryBuilder
        query_builder = MagicMock()
        query_builder.build_use_database_command = MagicMock(return_value=None)
        platform.query_builder = query_builder

        # Non-Redshift platforms don't support UNLOAD strategy
        platform.supports_strategy = MagicMock(return_value=False)

        return platform

    @pytest.fixture
    def mock_task_queue(self):
        """Create a mock task queue."""
        task_queue = MagicMock()
        task_queue.push_task_chain = AsyncMock(return_value=[1, 2])
        return task_queue

    def test_build_unload_extraction_payload_with_redshift(
        self,
        source_table,
        target_table,
        source_schema,
        partition_input,
        mock_redshift_platform,
        mock_task_queue,
    ):
        """Test that UNLOAD extraction task is correctly built for Redshift platform."""
        table_config = TableConfiguration(
            source=source_table,
            target=target_table,
            extraction=ExtractionConfig(
                strategy=ExtractionStrategy.UNLOAD,
                external_stage="@MY_DB.MY_SCHEMA.S3_STAGE",
            ),
        )

        context = TaskChainContext(
            workflow_id=42,
            table_metadata_id=123,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=None,
            strategy_config={
                "s3_bucket": "test-bucket",
                "iam_role_arn": "arn:aws:iam::123456789012:role/test",
            },
        )

        creator = TaskChainCreator(
            platform=mock_redshift_platform,
            task_queue=mock_task_queue,
            task_chain_context=context,
        )

        # Call the internal method directly for focused testing
        payload = creator._build_data_extraction_payload(partition_input)

        # Verify the payload is configured for S3 UNLOAD
        assert payload.target_type == TargetType.S3_UNLOAD
        assert payload.source_type == "redshift"
        assert payload.database == "test_db"
        assert payload.schema == "test_schema"
        assert payload.is_bulk_operation is True

        # Verify target_id is a relative path (DEA prepends S3 bucket)
        assert (
            "task_results/workflows/42/tables/123/data/partition_1/"
            in payload.target_id
        )
        assert not payload.target_id.startswith("@")  # Should not have stage prefix
        assert not payload.target_id.startswith("s3://")  # Should not have S3 prefix

        # Verify statement_location_id contains the SELECT query
        assert "SELECT" in payload.statement_location_id
        assert (
            "test_schema" in payload.statement_location_id
            or "test_table" in payload.statement_location_id
        )

    def test_build_unload_extraction_raises_for_non_redshift_platform(
        self,
        source_table,
        target_table,
        source_schema,
        partition_input,
        mock_non_redshift_platform,
        mock_task_queue,
    ):
        """Test that UNLOAD strategy raises error for non-Redshift platforms."""
        table_config = TableConfiguration(
            source=source_table,
            target=target_table,
            extraction=ExtractionConfig(
                strategy=ExtractionStrategy.UNLOAD,
                external_stage="@MY_DB.MY_SCHEMA.S3_STAGE",
            ),
        )

        context = TaskChainContext(
            workflow_id=42,
            table_metadata_id=123,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=None,
        )

        creator = TaskChainCreator(
            platform=mock_non_redshift_platform,
            task_queue=mock_task_queue,
            task_chain_context=context,
        )

        # Verify that attempting UNLOAD with non-Redshift platform raises error
        with pytest.raises(UnsupportedExtractionStrategyError) as exc_info:
            creator._build_data_extraction_payload(partition_input)

        assert exc_info.value.extraction_strategy_name == "UNLOAD"
        assert exc_info.value.platform_name == "sqlserver"
        assert "UNLOAD" in str(exc_info.value)
        assert "sqlserver" in str(exc_info.value)
