"""Tests for SQL utility functions."""

from data_migration_orchestrator.utils.sql_utils import (
    is_already_quoted_snowflake,
    is_already_quoted_sqlserver,
    needs_quoting_snowflake,
    needs_quoting_sqlserver,
    quote_identifier,
    quote_identifier_snowflake,
    quote_identifier_sqlserver,
    quote_string_literal,
    unquote_identifier,
    unquote_identifier_snowflake,
    unquote_identifier_sqlserver,
)


class TestQuoteStringLiteral:
    """Tests for quote_string_literal function."""

    def test_quote_simple_string(self):
        """Test quoting a simple string value."""
        result = quote_string_literal("my_value")
        assert result == "'my_value'"

    def test_quote_path_string(self):
        """Test quoting a path string."""
        result = quote_string_literal("@stage/path/to/file.parquet")
        assert result == "'@stage/path/to/file.parquet'"

    def test_quote_with_spaces(self):
        """Test quoting a string with spaces."""
        result = quote_string_literal("Order Details")
        assert result == "'Order Details'"

    def test_quote_empty_string(self):
        """Test quoting an empty string."""
        result = quote_string_literal("")
        assert result == "''"

    def test_quote_with_unicode_prefix(self):
        """Test quoting with SQL Server Unicode prefix."""
        result = quote_string_literal("my_value", unicode_prefix=True)
        assert result == "N'my_value'"

    def test_quote_with_unicode_prefix_false(self):
        """Test quoting with unicode_prefix explicitly False."""
        result = quote_string_literal("my_value", unicode_prefix=False)
        assert result == "'my_value'"

    def test_quote_special_characters(self):
        """Test quoting string with special characters."""
        result = quote_string_literal("value-with_special$chars")
        assert result == "'value-with_special$chars'"

    def test_quote_with_single_quote(self):
        """Test that strings with single quotes are properly escaped."""
        result = quote_string_literal("O'Brien")
        assert result == "'O''Brien'"  # Single quotes are escaped by doubling

    def test_quote_multiple_single_quotes(self):
        """Test that multiple single quotes are properly escaped."""
        result = quote_string_literal("It's O'Brien's")
        assert result == "'It''s O''Brien''s'"


class TestIsAlreadyQuoted:
    """Tests for is_already_quoted functions."""

    def test_is_already_quoted_sqlserver_with_brackets(self):
        """Test that bracketed identifiers are detected as quoted."""
        assert is_already_quoted_sqlserver("[MyTable]") is True
        assert is_already_quoted_sqlserver("[Order Details]") is True
        assert is_already_quoted_sqlserver("[my.schema]") is True

    def test_is_already_quoted_sqlserver_without_brackets(self):
        """Test that non-bracketed identifiers are not detected as quoted."""
        assert is_already_quoted_sqlserver("MyTable") is False
        assert is_already_quoted_sqlserver("dbo") is False
        assert is_already_quoted_sqlserver("") is False

    def test_is_already_quoted_sqlserver_partial_brackets(self):
        """Test partial brackets are not considered quoted."""
        assert is_already_quoted_sqlserver("[MyTable") is False
        assert is_already_quoted_sqlserver("MyTable]") is False

    def test_is_already_quoted_snowflake_with_quotes(self):
        """Test that double-quoted identifiers are detected as quoted."""
        assert is_already_quoted_snowflake('"MyTable"') is True
        assert is_already_quoted_snowflake('"Order Details"') is True

    def test_is_already_quoted_snowflake_without_quotes(self):
        """Test that non-quoted identifiers are not detected as quoted."""
        assert is_already_quoted_snowflake("MyTable") is False
        assert is_already_quoted_snowflake("PUBLIC") is False


class TestNeedsQuoting:
    """Tests for needs_quoting functions."""

    def test_needs_quoting_sqlserver_simple_identifier(self):
        """Test that simple identifiers don't need quoting."""
        assert needs_quoting_sqlserver("mytable") is False
        assert needs_quoting_sqlserver("MyTable") is False
        assert needs_quoting_sqlserver("my_table_123") is False

    def test_needs_quoting_sqlserver_with_spaces(self):
        """Test that identifiers with spaces need quoting."""
        assert needs_quoting_sqlserver("Order Details") is True
        assert needs_quoting_sqlserver("My Table") is True

    def test_needs_quoting_sqlserver_with_special_chars(self):
        """Test that identifiers with special characters need quoting."""
        assert needs_quoting_sqlserver("my.table") is True
        assert needs_quoting_sqlserver("table-name") is True
        assert needs_quoting_sqlserver("table$name") is True

    def test_needs_quoting_sqlserver_starts_with_digit(self):
        """Test that identifiers starting with digits need quoting."""
        assert needs_quoting_sqlserver("123table") is True
        assert needs_quoting_sqlserver("1_column") is True

    def test_needs_quoting_sqlserver_reserved_words_not_auto_quoted(self):
        """
        Test that reserved words are NOT automatically quoted.

        Users should quote reserved words themselves in their configuration.
        """
        # Reserved words that are valid identifiers don't need quoting
        assert needs_quoting_sqlserver("SELECT") is False
        assert needs_quoting_sqlserver("select") is False
        assert needs_quoting_sqlserver("TABLE") is False
        assert needs_quoting_sqlserver("ORDER") is False

    def test_needs_quoting_sqlserver_already_quoted(self):
        """Test that already quoted identifiers don't need quoting."""
        assert needs_quoting_sqlserver("[MyTable]") is False
        assert needs_quoting_sqlserver("[Order Details]") is False

    def test_needs_quoting_snowflake_valid_identifiers(self):
        """
        Test that valid identifiers don't need quoting in Snowflake.

        Snowflake is case-insensitive for unquoted identifiers (converts to uppercase),
        so lowercase identifiers work without quoting.
        """
        assert needs_quoting_snowflake("mytable") is False
        assert needs_quoting_snowflake("MyTable") is False
        assert needs_quoting_snowflake("MYTABLE") is False
        assert needs_quoting_snowflake("MY_TABLE_123") is False
        assert needs_quoting_snowflake("_private") is False
        assert needs_quoting_snowflake("table$name") is False  # $ is valid in Snowflake

    def test_needs_quoting_snowflake_invalid_identifiers(self):
        """Test that invalid identifiers need quoting in Snowflake."""
        assert needs_quoting_snowflake("Order Details") is True  # space
        assert needs_quoting_snowflake("my.table") is True  # dot
        assert needs_quoting_snowflake("123table") is True  # starts with digit
        assert needs_quoting_snowflake("table-name") is True  # hyphen


class TestQuoteIdentifierSqlserver:
    """Tests for quote_identifier_sqlserver function."""

    def test_quote_simple_identifier(self):
        """Test quoting a simple identifier."""
        result = quote_identifier_sqlserver("my_table")
        assert result == '"my_table"'

    def test_quote_identifier_with_spaces(self):
        """Test quoting an identifier with spaces."""
        result = quote_identifier_sqlserver("Order Details")
        assert result == '"Order Details"'

    def test_quote_identifier_with_special_chars(self):
        """Test quoting an identifier with special characters."""
        result = quote_identifier_sqlserver("my.table")
        assert result == '"my.table"'

    def test_quote_empty_identifier(self):
        """Test quoting an empty identifier."""
        result = quote_identifier_sqlserver("")
        assert result == '""'

    def test_quote_identifier_with_double_quote(self):
        """Test quoting an identifier that contains a double quote."""
        result = quote_identifier_sqlserver('Table"1')
        assert result == '"Table""1"'

    def test_quote_identifier_already_quoted_brackets(self):
        """Test that bracket-quoted identifiers are returned as-is."""
        result = quote_identifier_sqlserver("[MyTable]")
        assert result == "[MyTable]"

    def test_quote_identifier_already_quoted_double_quotes(self):
        """Test that double-quote identifiers are returned as-is."""
        result = quote_identifier_sqlserver('"MyTable"')
        assert result == '"MyTable"'

    def test_quote_identifier_case_sensitive(self):
        """Test that case-sensitive identifiers are properly quoted."""
        result = quote_identifier_sqlserver("CaseSensitiveTable")
        assert result == '"CaseSensitiveTable"'

    def test_quote_identifier_no_force_simple(self):
        """Test that simple identifiers aren't quoted when force_quote=False."""
        result = quote_identifier_sqlserver("mytable", force_quote=False)
        assert result == "mytable"

    def test_quote_identifier_no_force_needs_quoting(self):
        """Test that identifiers that need quoting are still quoted when force_quote=False."""
        result = quote_identifier_sqlserver("Order Details", force_quote=False)
        assert result == '"Order Details"'


class TestQuoteIdentifierSnowflake:
    """Tests for quote_identifier_snowflake function."""

    def test_quote_simple_identifier(self):
        """Test quoting a simple identifier."""
        result = quote_identifier_snowflake("MyTable")
        assert result == '"MyTable"'

    def test_quote_identifier_with_spaces(self):
        """Test quoting an identifier with spaces."""
        result = quote_identifier_snowflake("Order Details")
        assert result == '"Order Details"'

    def test_quote_identifier_with_double_quote(self):
        """Test quoting an identifier that contains a double quote."""
        result = quote_identifier_snowflake('My"Table')
        assert result == '"My""Table"'

    def test_quote_identifier_no_force_valid(self):
        """
        Test that valid identifiers aren't quoted when force_quote=False.

        Snowflake is case-insensitive for unquoted identifiers, so both
        lowercase and uppercase valid identifiers don't need quoting.
        """
        assert quote_identifier_snowflake("MYTABLE", force_quote=False) == "MYTABLE"
        assert quote_identifier_snowflake("mytable", force_quote=False) == "mytable"
        assert quote_identifier_snowflake("MyTable", force_quote=False) == "MyTable"

    def test_quote_identifier_no_force_invalid(self):
        """Test that invalid identifiers are quoted when force_quote=False."""
        result = quote_identifier_snowflake("Order Details", force_quote=False)
        assert result == '"Order Details"'


class TestQuoteIdentifier:
    """Tests for quote_identifier function with dialect parameter."""

    def test_quote_identifier_sqlserver_dialect(self):
        """Test quoting with SQL Server dialect uses double quotes."""
        result = quote_identifier("MyTable", dialect="sqlserver")
        assert result == '"MyTable"'

    def test_quote_identifier_snowflake_dialect(self):
        """Test quoting with Snowflake dialect."""
        result = quote_identifier("MyTable", dialect="snowflake")
        assert result == '"MyTable"'

    def test_quote_identifier_unknown_dialect_defaults_to_sqlserver(self):
        """Test that unknown dialects default to SQL Server style (double quotes)."""
        result = quote_identifier("MyTable", dialect="unknown")  # type: ignore
        assert result == '"MyTable"'


class TestUnquoteIdentifier:
    """Tests for unquote_identifier functions."""

    def test_unquote_sqlserver_bracketed(self):
        """Test unquoting SQL Server bracketed identifiers."""
        result = unquote_identifier_sqlserver("[MyTable]")
        assert result == "MyTable"

    def test_unquote_sqlserver_escaped_brackets(self):
        """Test unquoting SQL Server identifiers with escaped brackets."""
        result = unquote_identifier_sqlserver("[Table[1]]]")
        assert result == "Table[1]"

    def test_unquote_sqlserver_not_quoted(self):
        """Test that unquoted identifiers are returned as-is."""
        result = unquote_identifier_sqlserver("MyTable")
        assert result == "MyTable"

    def test_unquote_sqlserver_double_quoted(self):
        """Test unquoting SQL Server double-quoted identifiers."""
        result = unquote_identifier_sqlserver('"MyTable"')
        assert result == "MyTable"

    def test_unquote_sqlserver_double_quoted_escaped(self):
        """Test unquoting SQL Server identifiers with escaped double quotes."""
        result = unquote_identifier_sqlserver('"My""Table"')
        assert result == 'My"Table'

    def test_unquote_snowflake_quoted(self):
        """Test unquoting Snowflake double-quoted identifiers."""
        result = unquote_identifier_snowflake('"MyTable"')
        assert result == "MyTable"

    def test_unquote_snowflake_escaped_quotes(self):
        """Test unquoting Snowflake identifiers with escaped quotes."""
        result = unquote_identifier_snowflake('"My""Table"')
        assert result == 'My"Table'

    def test_unquote_snowflake_not_quoted(self):
        """Test that unquoted identifiers are returned as-is."""
        result = unquote_identifier_snowflake("MYTABLE")
        assert result == "MYTABLE"

    def test_unquote_identifier_by_dialect(self):
        """Test unquote_identifier with dialect parameter."""
        assert unquote_identifier("[MyTable]", "sqlserver") == "MyTable"
        assert unquote_identifier('"MyTable"', "snowflake") == "MyTable"
