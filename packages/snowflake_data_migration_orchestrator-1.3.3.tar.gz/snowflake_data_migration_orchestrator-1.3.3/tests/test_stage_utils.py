"""Tests for stage utility functions."""

from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    stage_path_for_boundaries,
    stage_path_for_checksum,
    stage_path_for_metadata,
    stage_path_for_partition_data,
    stage_path_for_schema,
)


class TestDeterministicStagePaths:
    """Tests for deterministic path computation functions."""

    def test_stage_path_for_partition_data_full_table(self):
        """Test computing data path for full table (partition 0)."""
        result = stage_path_for_partition_data(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
            partition_index=0,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/data/full_table/"

    def test_stage_path_for_partition_data_partition_5(self):
        """Test computing data path for partition 5."""
        result = stage_path_for_partition_data(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
            partition_index=5,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/data/partition_5/"

    def test_stage_path_for_partition_data_fully_qualified_stage(self):
        """Test with fully qualified Snowflake stage name."""
        result = stage_path_for_partition_data(
            stage_id="@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS",
            workflow_id=123,
            table_metadata_id=456,
            partition_index=3,
        )
        assert result == (
            "@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS/"
            "task_results/workflows/123/tables/456/data/partition_3/"
        )

    def test_stage_path_for_schema(self):
        """Test computing schema path."""
        result = stage_path_for_schema(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/schema/"

    def test_stage_path_for_metadata(self):
        """Test computing metadata path."""
        result = stage_path_for_metadata(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/metadata/"

    def test_stage_path_for_boundaries(self):
        """Test computing boundaries path."""
        result = stage_path_for_boundaries(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/boundaries/"

    def test_stage_path_for_checksum(self):
        """Test computing checksum path."""
        result = stage_path_for_checksum(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
            partition_index=7,
        )
        assert (
            result == "@STAGE/task_results/workflows/1/tables/42/checksum/partition_7/"
        )

    def test_all_paths_share_common_base(self):
        """Test that all path functions share the same base structure."""
        stage_id = "@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS"
        workflow_id = 99
        table_metadata_id = 101

        expected_base = (
            "@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS/"
            "task_results/workflows/99/tables/101"
        )

        data_path = stage_path_for_partition_data(
            stage_id, workflow_id, table_metadata_id, partition_index=0
        )
        schema_path = stage_path_for_schema(stage_id, workflow_id, table_metadata_id)
        metadata_path = stage_path_for_metadata(
            stage_id, workflow_id, table_metadata_id
        )
        boundaries_path = stage_path_for_boundaries(
            stage_id, workflow_id, table_metadata_id
        )
        checksum_path = stage_path_for_checksum(
            stage_id, workflow_id, table_metadata_id, partition_index=0
        )

        assert data_path.startswith(expected_base)
        assert schema_path.startswith(expected_base)
        assert metadata_path.startswith(expected_base)
        assert boundaries_path.startswith(expected_base)
        assert checksum_path.startswith(expected_base)

    def test_different_table_ids_produce_different_paths(self):
        """Test that different table_metadata_ids produce different paths."""
        path1 = stage_path_for_schema("@STAGE", 1, table_metadata_id=1)
        path2 = stage_path_for_schema("@STAGE", 1, table_metadata_id=2)
        assert path1 != path2

    def test_different_workflow_ids_produce_different_paths(self):
        """Test that different workflow_ids produce different paths."""
        path1 = stage_path_for_schema("@STAGE", workflow_id=1, table_metadata_id=1)
        path2 = stage_path_for_schema("@STAGE", workflow_id=2, table_metadata_id=1)
        assert path1 != path2
