"""Tests for datetime utility functions."""

from datetime import datetime, timedelta, timezone, UTC

from data_migration_orchestrator.utils.datetime_utils import (
    DATETIME_PATTERN,
    is_datetime_string,
    format_datetime_for_sqlserver,
    format_datetime_string_for_sqlserver,
)


class TestDatetimePattern:
    """Tests for DATETIME_PATTERN and is_datetime_string."""

    def test_matches_datetime_with_space_separator(self):
        """Test pattern matches datetime with space separator."""
        assert DATETIME_PATTERN.match("2023-07-01 01:01:52")
        assert is_datetime_string("2023-07-01 01:01:52")

    def test_matches_datetime_with_t_separator(self):
        """Test pattern matches datetime with T separator."""
        assert DATETIME_PATTERN.match("2023-07-01T01:01:52")
        assert is_datetime_string("2023-07-01T01:01:52")

    def test_matches_datetime_with_milliseconds(self):
        """Test pattern matches datetime with fractional seconds."""
        assert DATETIME_PATTERN.match("2023-07-01 01:01:52.197")
        assert DATETIME_PATTERN.match("2023-07-01T01:01:52.197")
        assert is_datetime_string("2023-07-01 01:01:52.197")

    def test_matches_datetime_with_microseconds(self):
        """Test pattern matches datetime with 6-digit fractional seconds."""
        assert DATETIME_PATTERN.match("2023-07-01 01:01:52.197000")
        assert DATETIME_PATTERN.match("2023-07-01T01:01:52.197000")
        assert is_datetime_string("2023-07-01T01:01:52.197000")

    def test_matches_datetime_with_timezone_offset(self):
        """Test pattern matches datetime with timezone offset."""
        assert DATETIME_PATTERN.match("2023-07-01T01:01:52+00:00")
        assert DATETIME_PATTERN.match("2023-07-01T01:01:52-05:00")
        assert DATETIME_PATTERN.match("2023-07-01T01:01:52.197+05:30")
        assert is_datetime_string("2023-07-01T01:01:52+00:00")

    def test_does_not_match_date_only(self):
        """Test pattern does not match date without time."""
        assert not DATETIME_PATTERN.match("2023-07-01")
        assert not is_datetime_string("2023-07-01")

    def test_does_not_match_time_only(self):
        """Test pattern does not match time without date."""
        assert not DATETIME_PATTERN.match("01:01:52")
        assert not is_datetime_string("01:01:52")

    def test_does_not_match_invalid_format(self):
        """Test pattern does not match invalid formats."""
        assert not DATETIME_PATTERN.match("07-01-2023 01:01:52")  # Wrong date format
        assert not DATETIME_PATTERN.match("2023/07/01 01:01:52")  # Wrong separator
        assert not is_datetime_string("07-01-2023 01:01:52")
        assert not is_datetime_string("2023/07/01 01:01:52")


class TestFormatDatetimeForSqlserver:
    """Tests for format_datetime_for_sqlserver with Python datetime objects."""

    def test_format_datetime_without_timezone(self):
        """Test formatting a datetime without timezone."""
        dt = datetime(2023, 7, 1, 1, 1, 52, 197000)
        result = format_datetime_for_sqlserver(dt)

        assert result == "CONVERT(datetime2, '2023-07-01T01:01:52.197', 126)"

    def test_format_datetime_with_timezone(self):
        """Test formatting a datetime with timezone."""
        tz = timezone(timedelta(hours=5, minutes=30))
        dt = datetime(2023, 7, 1, 1, 1, 52, 197000, tzinfo=tz)
        result = format_datetime_for_sqlserver(dt)

        assert "CONVERT(datetimeoffset," in result
        assert "2023-07-01T01:01:52.197" in result
        assert "+05:30" in result
        assert "127)" in result

    def test_format_datetime_utc(self):
        """Test formatting a datetime with UTC timezone."""
        dt = datetime(2023, 7, 1, 1, 1, 52, 197000, tzinfo=UTC)
        result = format_datetime_for_sqlserver(dt)

        assert "CONVERT(datetimeoffset," in result
        assert "+00:00" in result
        assert "127)" in result

    def test_format_datetime_negative_timezone(self):
        """Test formatting a datetime with negative timezone offset."""
        tz = timezone(timedelta(hours=-5))
        dt = datetime(2023, 7, 1, 1, 1, 52, 197000, tzinfo=tz)
        result = format_datetime_for_sqlserver(dt)

        assert "CONVERT(datetimeoffset," in result
        assert "-05:00" in result

    def test_format_datetime_trims_to_milliseconds(self):
        """Test that microseconds are trimmed to milliseconds."""
        dt = datetime(2023, 7, 1, 1, 1, 52, 197456)  # 197456 microseconds
        result = format_datetime_for_sqlserver(dt)

        # Should trim to 197 (milliseconds), not include full 197456
        assert ".197'" in result
        assert ".197456" not in result


class TestFormatDatetimeStringForSqlserver:
    """Tests for format_datetime_string_for_sqlserver."""

    def test_format_datetime_string_without_timezone(self):
        """Test formatting a datetime string without timezone."""
        result = format_datetime_string_for_sqlserver("2023-07-01 01:01:52.197000")

        assert result == "CONVERT(datetime2, '2023-07-01T01:01:52.197', 126)"

    def test_format_datetime_string_with_t_separator(self):
        """Test formatting a datetime string that already has T separator."""
        result = format_datetime_string_for_sqlserver("2023-07-01T01:01:52.197000")

        assert "CONVERT(datetime2," in result
        assert "2023-07-01T01:01:52.197" in result

    def test_format_datetime_string_with_timezone(self):
        """Test formatting a datetime string with timezone offset."""
        result = format_datetime_string_for_sqlserver(
            "2023-07-01T01:01:52.197000+05:30"
        )

        assert result == "CONVERT(datetimeoffset, '2023-07-01T01:01:52.197+05:30', 127)"

    def test_format_datetime_string_with_negative_timezone(self):
        """Test formatting a datetime string with negative timezone offset."""
        result = format_datetime_string_for_sqlserver("2023-07-01T01:01:52.197-05:00")

        assert "CONVERT(datetimeoffset," in result
        assert "-05:00" in result
        assert "127)" in result

    def test_format_datetime_string_truncates_microseconds(self):
        """Test that microseconds are truncated to milliseconds."""
        result = format_datetime_string_for_sqlserver("2023-07-01 01:01:52.197456")

        # Should only have 3 fractional digits, not 6
        assert ".197456" not in result
        assert ".197" in result

    def test_format_datetime_string_without_fractional_seconds(self):
        """Test formatting a datetime string without fractional seconds."""
        result = format_datetime_string_for_sqlserver("2023-07-01T01:01:52")

        assert result == "CONVERT(datetime2, '2023-07-01T01:01:52', 126)"

    def test_format_datetime_string_normalizes_space_to_t(self):
        """Test that space separator is normalized to T."""
        result = format_datetime_string_for_sqlserver("2023-07-01 01:01:52")

        assert "2023-07-01T01:01:52" in result
        assert " " not in result.split("'")[1]  # No space in the datetime part
