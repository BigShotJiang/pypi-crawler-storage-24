"""Tests for table utility functions."""

import pytest

from data_migration_orchestrator.utils.table_utils import (
    TableNameParts,
    build_table_ref,
    build_table_ref_from_parts,
    parse_table_name,
    quote_column_name,
)


class TestParseTableName:
    """Tests for parse_table_name function."""

    def test_parse_single_part_table_name(self):
        """Test parsing a simple table name without schema or database."""
        result = parse_table_name("my_table")
        assert result.database is None
        assert result.schema is None
        assert result.table == "my_table"

    def test_parse_two_part_table_name(self):
        """Test parsing schema.table format."""
        result = parse_table_name("dbo.my_table")
        assert result.database is None
        assert result.schema == "dbo"
        assert result.table == "my_table"

    def test_parse_three_part_table_name(self):
        """Test parsing database.schema.table format."""
        result = parse_table_name("mydb.dbo.my_table")
        assert result.database == "mydb"
        assert result.schema == "dbo"
        assert result.table == "my_table"

    def test_parse_sqlserver_bracketed_identifiers(self):
        """Test parsing SQL Server bracketed identifiers."""
        result = parse_table_name(
            "[my.db].[my.schema].[my.table]", source_type="sqlserver"
        )
        assert result.database == "my.db"
        assert result.schema == "my.schema"
        assert result.table == "my.table"

    def test_parse_sqlserver_mixed_bracketed_identifiers(self):
        """Test parsing SQL Server with some bracketed and some not."""
        result = parse_table_name("mydb.[my.schema].mytable", source_type="sqlserver")
        assert result.database == "mydb"
        assert result.schema == "my.schema"
        assert result.table == "mytable"

    def test_parse_sqlserver_bracket_in_schema(self):
        """Test parsing SQL Server with brackets only in schema."""
        result = parse_table_name("dbo.[Order Details]", source_type="sqlserver")
        assert result.database is None
        assert result.schema == "dbo"
        assert result.table == "Order Details"

    def test_parse_sqlserver_double_quoted_identifiers(self):
        """Test parsing SQL Server with double-quoted identifiers."""
        result = parse_table_name(
            '"mydb"."my.schema"."mytable"', source_type="sqlserver"
        )
        assert result.database == "mydb"
        assert result.schema == "my.schema"
        assert result.table == "mytable"

    def test_parse_sqlserver_mixed_double_quoted_identifiers(self):
        """Test parsing SQL Server with some double-quoted and some not."""
        result = parse_table_name('mydb."my.schema".mytable', source_type="sqlserver")
        assert result.database == "mydb"
        assert result.schema == "my.schema"
        assert result.table == "mytable"

    def test_parse_sqlserver_double_quoted_with_escaped_quotes(self):
        """Test parsing SQL Server with escaped double quotes inside."""
        result = parse_table_name('"My""Table"', source_type="sqlserver")
        assert result.database is None
        assert result.schema is None
        assert result.table == 'My"Table'

    def test_parse_snowflake_three_part_name(self):
        """Test parsing Snowflake 3-part table name."""
        result = parse_table_name("MYDB.PUBLIC.CUSTOMERS", source_type="snowflake")
        assert result.database == "MYDB"
        assert result.schema == "PUBLIC"
        assert result.table == "CUSTOMERS"

    def test_parse_four_part_name_takes_last_three(self):
        """Test that 4+ part names use the last 3 parts (server.database.schema.table)."""
        result = parse_table_name("server.database.schema.table")
        assert result.database == "database"
        assert result.schema == "schema"
        assert result.table == "table"

    def test_parse_empty_table_name_raises_error(self):
        """Test that empty table name raises ValueError."""
        with pytest.raises(ValueError, match="table_name cannot be empty"):
            parse_table_name("")

    def test_parse_none_table_name_raises_error(self):
        """Test that None table name raises ValueError."""
        with pytest.raises(ValueError, match="table_name cannot be empty"):
            parse_table_name(None)  # type: ignore

    def test_parse_whitespace_only_table_name_raises_error(self):
        """Test that whitespace-only table name raises ValueError."""
        with pytest.raises(ValueError, match="table_name cannot be empty"):
            parse_table_name("   ")

    def test_parse_table_name_with_special_characters(self):
        """Test parsing table name with special characters."""
        result = parse_table_name("schema.Table-With_Special$Chars")
        assert result.schema == "schema"
        assert result.table == "Table-With_Special$Chars"

    def test_parse_table_name_strips_whitespace(self):
        """Test that whitespace is stripped from table name and parts."""
        result = parse_table_name("  mydb . myschema . mytable  ")
        assert result.database == "mydb"
        assert result.schema == "myschema"
        assert result.table == "mytable"

    def test_parse_sqlserver_with_database_schema_table(self):
        """Test SQL Server with fully qualified 3-part name."""
        result = parse_table_name(
            "AdventureWorks.Sales.Customer", source_type="sqlserver"
        )
        assert result.database == "AdventureWorks"
        assert result.schema == "Sales"
        assert result.table == "Customer"

    def test_parse_sqlserver_escaped_brackets(self):
        """Test parsing SQL Server with escaped brackets (]] inside brackets)."""
        result = parse_table_name("[Table[1]]]", source_type="sqlserver")
        assert result.table == "Table[1]"

    def test_parse_sqlserver_reserved_word(self):
        """Test parsing SQL Server with reserved word as identifier."""
        result = parse_table_name("dbo.Order", source_type="sqlserver")
        assert result.schema == "dbo"
        assert result.table == "Order"


class TestTableNameParts:
    """Tests for TableNameParts dataclass."""

    def test_table_name_parts_initialization(self):
        """Test creating TableNameParts."""
        parts = TableNameParts(database="db", schema="schema", table="table")
        assert parts.database == "db"
        assert parts.schema == "schema"
        assert parts.table == "table"

    def test_table_name_parts_with_none_values(self):
        """Test creating TableNameParts with None values."""
        parts = TableNameParts(database=None, schema=None, table="table")
        assert parts.database is None
        assert parts.schema is None
        assert parts.table == "table"


class TestBuildTableRef:
    """Tests for build_table_ref function."""

    def test_build_table_ref_simple_identifiers(self):
        """Test that simple identifiers are NOT quoted but uppercased for SQL Server."""
        ref = build_table_ref("mydb", "myschema", "mytable", source_type="sqlserver")
        # SQL Server unquoted identifiers are normalized to uppercase
        assert ref == "MYDB.MYSCHEMA.MYTABLE"

    def test_build_table_ref_without_schema(self):
        """Test building table reference without schema."""
        ref = build_table_ref("mydb", "", "mytable", source_type="sqlserver")
        # SQL Server unquoted identifiers are normalized to uppercase
        assert ref == "MYDB.MYTABLE"

    def test_build_table_ref_with_special_chars(self):
        """Test that only identifiers with special characters are quoted."""
        ref = build_table_ref("mydb", "dbo", "Order Details", source_type="sqlserver")
        # Only "Order Details" has a space, so only it gets quoted (preserving case)
        # Other identifiers are uppercased
        assert ref == 'MYDB.DBO."Order Details"'

    def test_build_table_ref_with_dots_in_name(self):
        """Test that identifiers with dots are quoted."""
        ref = build_table_ref("my.db", "my.schema", "my.table", source_type="sqlserver")
        assert ref == '"my.db"."my.schema"."my.table"'

    def test_build_table_ref_reserved_word_not_auto_quoted(self):
        """
        Test that reserved words are NOT automatically quoted.

        Users should quote reserved words themselves if needed.
        """
        ref = build_table_ref("mydb", "dbo", "Order", source_type="sqlserver")
        # "Order" is a valid identifier pattern, so it's not auto-quoted, just uppercased
        assert ref == "MYDB.DBO.ORDER"

    def test_build_table_ref_mixed_quoting(self):
        """Test mixed case where some identifiers need quoting."""
        ref = build_table_ref(
            "AdventureWorks", "Sales", "Order Details", source_type="sqlserver"
        )
        # Only "Order Details" needs quoting (has space, preserving case)
        # Other identifiers are uppercased
        assert ref == 'ADVENTUREWORKS.SALES."Order Details"'

    def test_build_table_ref_starts_with_digit(self):
        """Test that identifiers starting with digits are quoted."""
        ref = build_table_ref("mydb", "dbo", "123Table", source_type="sqlserver")
        # "123Table" needs quoting (starts with digit), other identifiers are uppercased
        assert ref == 'MYDB.DBO."123Table"'


class TestBuildTableRefFromParts:
    """Tests for build_table_ref_from_parts function."""

    def test_build_from_parts_special_chars(self):
        """Test building from parts where identifiers have special chars."""
        parts = TableNameParts(
            database="my.db",
            schema="my.schema",
            table="my.table",
        )
        # Special chars are automatically detected and quoted
        ref = build_table_ref_from_parts(parts, source_type="sqlserver")
        assert ref == '"my.db"."my.schema"."my.table"'

    def test_build_from_parts_mixed_quoting(self):
        """Test building from parts with mixed quoting needs."""
        parts = TableNameParts(
            database="mydb",
            schema="dbo",
            table="Order Details",
        )
        ref = build_table_ref_from_parts(parts, source_type="sqlserver")
        # Only the table part needs quoting (has spaces)
        assert ref == 'mydb.dbo."Order Details"'

    def test_build_from_parts_no_database(self):
        """Test building from parts without database."""
        parts = TableNameParts(
            database=None,
            schema="dbo",
            table="mytable",
        )
        ref = build_table_ref_from_parts(parts, source_type="sqlserver")
        assert ref == "dbo.mytable"

    def test_build_from_parts_only_table(self):
        """Test building from parts with only table name."""
        parts = TableNameParts(
            database=None,
            schema=None,
            table="mytable",
        )
        ref = build_table_ref_from_parts(parts, source_type="sqlserver")
        assert ref == "mytable"

    def test_build_from_parts_force_quote(self):
        """Test building from parts with force_quote."""
        parts = TableNameParts(
            database="mydb",
            schema="dbo",
            table="mytable",
        )
        ref = build_table_ref_from_parts(
            parts, source_type="sqlserver", force_quote=True
        )
        assert ref == '"mydb"."dbo"."mytable"'


class TestQuoteColumnName:
    """Tests for quote_column_name function."""

    def test_simple_column_not_quoted(self):
        """Test that simple column names are NOT quoted."""
        result = quote_column_name("id", source_type="sqlserver")
        assert result == "id"

    def test_quote_column_with_spaces(self):
        """Test that column names with spaces ARE quoted."""
        result = quote_column_name("Order Date", source_type="sqlserver")
        assert result == '"Order Date"'

    def test_simple_mixed_case_not_quoted(self):
        """Test that mixed case simple names are NOT quoted (SQL Server is case-insensitive)."""
        result = quote_column_name("CustomerID", source_type="sqlserver")
        assert result == "CustomerID"

    def test_quote_column_reserved_word_not_auto_quoted(self):
        """
        Test that reserved word column names are NOT automatically quoted.

        Users should quote reserved words themselves if needed.
        """
        result = quote_column_name("order", source_type="sqlserver")
        assert result == "order"

    def test_quote_column_with_special_chars(self):
        """Test that column names with special chars ARE quoted."""
        result = quote_column_name("my-column", source_type="sqlserver")
        assert result == '"my-column"'
