"""Tests for platform implementations."""
