"""Tests for the Redshift platform implementation."""
