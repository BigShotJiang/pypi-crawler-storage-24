"""
Unit tests for RedshiftPlatform.

Tests cover platform properties, strategy support, type mappings,
and query builder integration.
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.platforms.redshift.platform import (
    RedshiftPlatform,
)


class TestRedshiftPlatform:
    """Test suite for RedshiftPlatform."""

    @pytest.fixture
    def platform(self) -> RedshiftPlatform:
        """Create a RedshiftPlatform instance for testing."""
        return RedshiftPlatform()

    def test_name(self, platform: RedshiftPlatform):
        """Test that platform name is 'redshift'."""
        assert platform.name == "redshift"

    def test_display_name(self, platform: RedshiftPlatform):
        """Test that display name is properly formatted."""
        assert platform.display_name == "Amazon Redshift"

    def test_aliases(self, platform: RedshiftPlatform):
        """Test that common aliases are defined."""
        aliases = platform.aliases
        assert "aws-redshift" in aliases
        assert "amazon-redshift" in aliases

    def test_default_strategy(self, platform: RedshiftPlatform):
        """Test that default extraction strategy is REGULAR."""
        assert platform.default_strategy == ExtractionStrategy.REGULAR

    def test_supported_strategies(self, platform: RedshiftPlatform):
        """Test that supported strategies include both UNLOAD and REGULAR."""
        strategies = platform.supported_strategies
        assert ExtractionStrategy.UNLOAD in strategies
        assert ExtractionStrategy.REGULAR in strategies

    def test_supports_unload_strategy(self, platform: RedshiftPlatform):
        """Test that UNLOAD strategy is supported."""
        assert platform.supports_strategy(ExtractionStrategy.UNLOAD) is True

    def test_supports_regular_strategy(self, platform: RedshiftPlatform):
        """Test that REGULAR strategy is supported."""
        assert platform.supports_strategy(ExtractionStrategy.REGULAR) is True

    def test_does_not_support_unknown_strategy(self, platform: RedshiftPlatform):
        """Test that unknown strategies are not supported."""
        assert platform.supports_strategy("unknown") is False

    def test_query_builder_type(self, platform: RedshiftPlatform):
        """Test that query builder is the correct type."""
        from data_migration_orchestrator.data_migration_cloud.platforms.redshift.query_builder import (
            RedshiftQueryBuilder,
        )

        assert isinstance(platform.query_builder, RedshiftQueryBuilder)

    def test_query_builder_cached(self, platform: RedshiftPlatform):
        """Test that query builder instance is cached."""
        qb1 = platform.query_builder
        qb2 = platform.query_builder
        assert qb1 is qb2


class TestRedshiftTypeMappings:
    """Test suite for Redshift to Snowflake type mappings."""

    @pytest.fixture
    def platform(self) -> RedshiftPlatform:
        """Create a RedshiftPlatform instance for testing."""
        return RedshiftPlatform()

    def test_type_mappings_not_empty(self, platform: RedshiftPlatform):
        """Test that type mappings dictionary is populated."""
        assert len(platform.type_mappings) > 0

    # Integer types
    def test_smallint_mapping(self, platform: RedshiftPlatform):
        """Test SMALLINT maps to Snowflake NUMBER."""
        assert platform.get_type_mapping("smallint") == "NUMBER(5,0)"

    def test_integer_mapping(self, platform: RedshiftPlatform):
        """Test INTEGER maps to Snowflake NUMBER."""
        assert platform.get_type_mapping("integer") == "NUMBER(10,0)"
        assert platform.get_type_mapping("int") == "NUMBER(10,0)"
        assert platform.get_type_mapping("int4") == "NUMBER(10,0)"

    def test_bigint_mapping(self, platform: RedshiftPlatform):
        """Test BIGINT maps to Snowflake NUMBER."""
        assert platform.get_type_mapping("bigint") == "NUMBER(19,0)"
        assert platform.get_type_mapping("int8") == "NUMBER(19,0)"

    # Decimal/Numeric types
    def test_decimal_mapping(self, platform: RedshiftPlatform):
        """Test DECIMAL maps to Snowflake NUMBER."""
        mapping = platform.get_type_mapping("decimal")
        assert mapping is not None
        assert "NUMBER" in mapping.upper()

    def test_numeric_mapping(self, platform: RedshiftPlatform):
        """Test NUMERIC maps to Snowflake NUMBER."""
        mapping = platform.get_type_mapping("numeric")
        assert mapping is not None
        assert "NUMBER" in mapping.upper()

    # Floating point types
    def test_real_mapping(self, platform: RedshiftPlatform):
        """Test REAL maps to Snowflake FLOAT."""
        assert platform.get_type_mapping("real") == "FLOAT"
        assert platform.get_type_mapping("float4") == "FLOAT"

    def test_double_precision_mapping(self, platform: RedshiftPlatform):
        """Test DOUBLE PRECISION maps to Snowflake FLOAT."""
        assert platform.get_type_mapping("double precision") == "FLOAT"
        assert platform.get_type_mapping("float8") == "FLOAT"
        assert platform.get_type_mapping("float") == "FLOAT"

    # String types
    def test_char_mapping(self, platform: RedshiftPlatform):
        """Test CHAR maps to Snowflake CHAR."""
        mapping = platform.get_type_mapping("char")
        assert mapping is not None
        assert "CHAR" in mapping.upper() or "VARCHAR" in mapping.upper()

    def test_varchar_mapping(self, platform: RedshiftPlatform):
        """Test VARCHAR maps to Snowflake VARCHAR."""
        mapping = platform.get_type_mapping("varchar")
        assert mapping is not None
        assert "VARCHAR" in mapping.upper()

    def test_text_mapping(self, platform: RedshiftPlatform):
        """Test TEXT maps to Snowflake VARCHAR."""
        mapping = platform.get_type_mapping("text")
        assert mapping is not None
        # TEXT typically maps to VARCHAR with max length
        assert "VARCHAR" in mapping.upper()

    def test_bpchar_mapping(self, platform: RedshiftPlatform):
        """Test BPCHAR (blank-padded char) maps correctly."""
        mapping = platform.get_type_mapping("bpchar")
        assert mapping is not None

    # Date/Time types
    def test_date_mapping(self, platform: RedshiftPlatform):
        """Test DATE maps to Snowflake DATE."""
        assert platform.get_type_mapping("date") == "DATE"

    def test_timestamp_mapping(self, platform: RedshiftPlatform):
        """Test TIMESTAMP maps to Snowflake TIMESTAMP_NTZ."""
        mapping = platform.get_type_mapping("timestamp")
        assert mapping is not None
        assert "TIMESTAMP" in mapping.upper()

    def test_timestamptz_mapping(self, platform: RedshiftPlatform):
        """Test TIMESTAMPTZ maps to Snowflake TIMESTAMP_TZ."""
        mapping = platform.get_type_mapping("timestamptz")
        assert mapping is not None
        assert "TIMESTAMP" in mapping.upper()
        assert "TZ" in mapping.upper()

    def test_time_mapping(self, platform: RedshiftPlatform):
        """Test TIME maps to Snowflake TIME."""
        assert platform.get_type_mapping("time") == "TIME"

    def test_timetz_mapping(self, platform: RedshiftPlatform):
        """Test TIMETZ maps correctly."""
        mapping = platform.get_type_mapping("timetz")
        assert mapping is not None
        assert "TIME" in mapping.upper()

    # Boolean type
    def test_boolean_mapping(self, platform: RedshiftPlatform):
        """Test BOOLEAN maps to Snowflake BOOLEAN."""
        assert platform.get_type_mapping("boolean") == "BOOLEAN"
        assert platform.get_type_mapping("bool") == "BOOLEAN"

    # Binary types
    def test_varbyte_mapping(self, platform: RedshiftPlatform):
        """Test VARBYTE maps to Snowflake BINARY."""
        mapping = platform.get_type_mapping("varbyte")
        assert mapping is not None
        assert "BINARY" in mapping.upper()

    # Special types
    def test_super_mapping(self, platform: RedshiftPlatform):
        """Test SUPER (semi-structured) maps to Snowflake VARIANT."""
        assert platform.get_type_mapping("super") == "VARIANT"

    def test_geometry_mapping(self, platform: RedshiftPlatform):
        """Test GEOMETRY maps to Snowflake GEOGRAPHY or GEOMETRY."""
        mapping = platform.get_type_mapping("geometry")
        assert mapping is not None
        assert "GEO" in mapping.upper()

    def test_geography_mapping(self, platform: RedshiftPlatform):
        """Test GEOGRAPHY maps to Snowflake GEOGRAPHY."""
        mapping = platform.get_type_mapping("geography")
        assert mapping is not None
        assert "GEOGRAPHY" in mapping.upper()

    # Unknown type handling
    def test_unknown_type_returns_none(self, platform: RedshiftPlatform):
        """Test that unknown types return None."""
        assert platform.get_type_mapping("unknown_type_xyz") is None

    def test_case_insensitive_lookup(self, platform: RedshiftPlatform):
        """Test that type lookups are case-insensitive."""
        assert platform.get_type_mapping("VARCHAR") == platform.get_type_mapping(
            "varchar"
        )
        assert platform.get_type_mapping("Integer") == platform.get_type_mapping(
            "integer"
        )
        assert platform.get_type_mapping("BOOLEAN") == platform.get_type_mapping(
            "boolean"
        )
