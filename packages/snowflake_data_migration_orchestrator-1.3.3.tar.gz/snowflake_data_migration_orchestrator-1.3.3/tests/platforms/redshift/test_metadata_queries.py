"""
Unit tests for Redshift metadata query support.

Tests verify that:
1. Redshift is recognized as a valid source type
2. Metadata queries can be built for Redshift tables
3. Schema queries can be built for Redshift tables
4. Query structures are correct
5. Error handling works properly
"""

import pytest

from data_migration_orchestrator.data_migration_core.queries.table_metadata import (
    SOURCE_TYPE_ALIASES,
    build_metadata_query,
    build_schema_query,
)


class TestRedshiftSourceTypeRecognition:
    """Tests for Redshift source type recognition."""

    def test_redshift_in_aliases(self):
        """Test that 'redshift' is recognized as a valid source type."""
        assert "redshift" in SOURCE_TYPE_ALIASES

    def test_aws_redshift_in_aliases(self):
        """Test that 'aws-redshift' is recognized as a valid source type."""
        assert "aws-redshift" in SOURCE_TYPE_ALIASES

    def test_amazon_redshift_in_aliases(self):
        """Test that 'amazon-redshift' is recognized as a valid source type."""
        assert "amazon-redshift" in SOURCE_TYPE_ALIASES

    def test_all_redshift_aliases_resolve_correctly(self):
        """Test that all Redshift aliases resolve to the same base type."""
        redshift_aliases = ["redshift", "aws-redshift", "amazon-redshift"]
        resolved_types = {SOURCE_TYPE_ALIASES[alias] for alias in redshift_aliases}
        # All aliases should resolve to the same type
        assert len(resolved_types) == 1


class TestRedshiftMetadataQuery:
    """Tests for building Redshift metadata queries."""

    def test_build_metadata_query_simple_table(self):
        """Test building metadata query for a simple table name."""
        query = build_metadata_query("redshift", "customer")
        assert query is not None
        assert isinstance(query, str)
        assert len(query) > 0

    def test_build_metadata_query_with_schema(self):
        """Test building metadata query for table with schema."""
        query = build_metadata_query("redshift", "ecommerce_raw.customer")
        assert query is not None
        assert "ecommerce_raw" in query
        assert "customer" in query

    def test_metadata_query_uses_svv_table_info(self):
        """Test that metadata query uses SVV_TABLE_INFO view."""
        query = build_metadata_query("redshift", "public.users")
        assert "svv_table_info" in query.lower()

    def test_metadata_query_includes_row_count(self):
        """Test that metadata query includes row count."""
        query = build_metadata_query("redshift", "public.orders")
        # Check for row count column (tbl_rows or similar)
        assert "row" in query.lower()

    def test_metadata_query_includes_data_size(self):
        """Test that metadata query includes data size metrics."""
        query = build_metadata_query("redshift", "public.products")
        # Check for data size metrics
        assert "mb" in query.lower() or "size" in query.lower()

    def test_metadata_query_does_not_divide_size_by_1024(self):
        """
        Test that svv_table_info.size (already in MB) is not divided by 1024.

        svv_table_info.size reports size in 1 MB blocks, so dividing by 1024
        would incorrectly convert to GB while labeling it as MB. This caused
        large tables (e.g. 774 GB) to be misclassified as small (<1 GB) and
        skip partitioning entirely.
        """
        query = build_metadata_query("redshift", "public.lineitem")
        assert "/ 1024" not in query
        assert "/1024" not in query

    @pytest.mark.parametrize(
        "source_type,table_name",
        [
            ("redshift", "customer"),
            ("redshift", "ecommerce_raw.customer"),
            ("aws-redshift", "schema.table"),
            ("amazon-redshift", "public.orders"),
        ],
    )
    def test_metadata_query_for_various_aliases(
        self, source_type: str, table_name: str
    ):
        """Test metadata query generation for different Redshift aliases."""
        query = build_metadata_query(source_type, table_name)
        assert query is not None
        assert "svv_table_info" in query.lower()


class TestRedshiftSchemaQuery:
    """Tests for building Redshift schema queries."""

    def test_build_schema_query_simple_table(self):
        """Test building schema query for a simple table name."""
        query = build_schema_query("redshift", "customer")
        assert query is not None
        assert isinstance(query, str)
        assert len(query) > 0

    def test_build_schema_query_with_schema(self):
        """Test building schema query for table with schema."""
        query = build_schema_query("redshift", "ecommerce_raw.customer")
        assert query is not None
        assert "ecommerce_raw" in query
        assert "customer" in query

    def test_schema_query_uses_information_schema(self):
        """Test that schema query uses information_schema."""
        query = build_schema_query("redshift", "public.users")
        assert "information_schema" in query.lower()

    def test_schema_query_selects_column_info(self):
        """Test that schema query selects column information."""
        query = build_schema_query("redshift", "public.orders")
        # Should select column name and type information
        assert "column" in query.lower()

    def test_schema_query_filters_by_table(self):
        """Test that schema query filters by table name."""
        query = build_schema_query("redshift", "public.products")
        assert "products" in query

    @pytest.mark.parametrize(
        "source_type,table_name",
        [
            ("redshift", "customer"),
            ("redshift", "ecommerce_raw.customer"),
            ("aws-redshift", "schema.table"),
            ("amazon-redshift", "public.orders"),
        ],
    )
    def test_schema_query_for_various_aliases(self, source_type: str, table_name: str):
        """Test schema query generation for different Redshift aliases."""
        query = build_schema_query(source_type, table_name)
        assert query is not None
        assert "information_schema" in query.lower()


class TestRedshiftQueryStructure:
    """Tests for Redshift query structure and content."""

    def test_metadata_query_structure(self):
        """Test that metadata query has correct structure."""
        query = build_metadata_query("redshift", "public.customer")

        # Should use SVV_TABLE_INFO
        assert "svv_table_info" in query.lower()

        # Should be a valid SQL query (basic check)
        assert "SELECT" in query.upper() or "select" in query.lower()

    def test_schema_query_structure(self):
        """Test that schema query has correct structure."""
        query = build_schema_query("redshift", "public.customer")

        # Should use information_schema
        assert "information_schema" in query.lower()

        # Should be a valid SQL query (basic check)
        assert "SELECT" in query.upper() or "select" in query.lower()

        # Should have column information
        assert "column" in query.lower()

    def test_queries_are_non_empty(self):
        """Test that generated queries are not empty."""
        metadata_query = build_metadata_query("redshift", "test_table")
        schema_query = build_schema_query("redshift", "test_table")

        assert len(metadata_query) > 50  # Should be substantial query
        assert len(schema_query) > 50  # Should be substantial query


class TestRedshiftQueryErrorHandling:
    """Tests for error handling in query generation."""

    def test_unsupported_source_type_raises_error(self):
        """Test that unsupported source type raises ValueError."""
        with pytest.raises(ValueError, match="Unsupported source type"):
            build_metadata_query("unsupported-db", "table")

    def test_empty_table_name_raises_error(self):
        """Test that empty table name raises ValueError."""
        with pytest.raises(ValueError, match="table_name"):
            build_metadata_query("redshift", "")

    def test_none_table_name_raises_error(self):
        """Test that None table name raises ValueError."""
        with pytest.raises((ValueError, TypeError)):
            build_metadata_query("redshift", None)

    def test_schema_query_unsupported_source_raises_error(self):
        """Test that schema query with unsupported source raises ValueError."""
        with pytest.raises(ValueError, match="Unsupported source type"):
            build_schema_query("unsupported-db", "table")

    def test_schema_query_empty_table_raises_error(self):
        """Test that schema query with empty table name raises ValueError."""
        with pytest.raises(ValueError, match="table_name"):
            build_schema_query("redshift", "")


class TestRedshiftQueryIntegration:
    """Integration tests for Redshift query generation."""

    def test_complete_workflow_metadata_query(self):
        """Test complete workflow of generating a metadata query."""
        # Generate query for a realistic table
        table_name = "ecommerce_prod.customer_orders"
        query = build_metadata_query("redshift", table_name)

        # Verify query structure
        assert "svv_table_info" in query.lower()
        assert "ecommerce_prod" in query
        assert "customer_orders" in query

        # Should be executable SQL (basic validation)
        assert (
            query.strip().upper().startswith("SELECT")
            or "svv_table_info" in query.lower()
        )

    def test_complete_workflow_schema_query(self):
        """Test complete workflow of generating a schema query."""
        # Generate query for a realistic table
        table_name = "ecommerce_prod.customer_orders"
        query = build_schema_query("redshift", table_name)

        # Verify query structure
        assert "information_schema" in query.lower()
        assert "ecommerce_prod" in query
        assert "customer_orders" in query

        # Should be executable SQL (basic validation)
        assert (
            query.strip().upper().startswith("SELECT")
            or "information_schema" in query.lower()
        )

    def test_queries_differ_by_purpose(self):
        """Test that metadata and schema queries are different."""
        table_name = "public.test_table"
        metadata_query = build_metadata_query("redshift", table_name)
        schema_query = build_schema_query("redshift", table_name)

        # Queries should be different
        assert metadata_query != schema_query

        # Metadata query uses SVV_TABLE_INFO
        assert "svv_table_info" in metadata_query.lower()

        # Schema query uses information_schema
        assert "information_schema" in schema_query.lower()


class TestRedshiftTableNameParsing:
    """Tests for table name parsing in Redshift queries."""

    def test_simple_table_name(self):
        """Test query generation with simple table name."""
        query = build_metadata_query("redshift", "customers")
        assert "customers" in query

    def test_schema_qualified_table_name(self):
        """Test query generation with schema.table format."""
        query = build_metadata_query("redshift", "public.customers")
        assert "public" in query
        assert "customers" in query

    def test_fully_qualified_table_name(self):
        """Test query generation with database.schema.table format."""
        query = build_metadata_query("redshift", "mydb.public.customers")
        # Should handle fully qualified names
        assert "customers" in query

    def test_table_name_with_underscore(self):
        """Test query generation with underscore in table name."""
        query = build_schema_query("redshift", "customer_orders")
        assert "customer_orders" in query

    def test_table_name_with_numbers(self):
        """Test query generation with numbers in table name."""
        query = build_schema_query("redshift", "orders_2024")
        assert "orders_2024" in query
