"""
Unit tests for PostgreSQL metadata query support.

Tests verify that:
1. PostgreSQL is recognized as a valid source type
2. Metadata queries can be built for PostgreSQL tables
3. Schema queries can be built for PostgreSQL tables
4. Query structures are correct (pg_class for metadata, information_schema for schema)
5. Default schema defaults to 'public' when not specified
6. Error handling works properly
"""

import pytest

from data_migration_orchestrator.data_migration_core.queries.table_metadata import (
    SOURCE_TYPE_ALIASES,
    build_metadata_query,
    build_postgresql_metadata_query,
    build_postgresql_schema_query,
    build_schema_query,
)


class TestPostgresqlSourceTypeRecognition:
    """Tests for PostgreSQL source type recognition."""

    def test_postgresql_in_aliases(self):
        assert "postgresql" in SOURCE_TYPE_ALIASES

    def test_postgres_in_aliases(self):
        assert "postgres" in SOURCE_TYPE_ALIASES

    def test_all_postgresql_aliases_resolve_correctly(self):
        postgresql_aliases = ["postgresql", "postgres"]
        resolved_types = {SOURCE_TYPE_ALIASES[alias] for alias in postgresql_aliases}
        assert len(resolved_types) == 1


class TestPostgresqlMetadataQuery:
    """Tests for building PostgreSQL metadata queries."""

    def test_build_metadata_query_simple_table(self):
        query = build_metadata_query("postgresql", "customers")
        assert query is not None
        assert isinstance(query, str)
        assert len(query) > 0

    def test_build_metadata_query_with_schema(self):
        query = build_metadata_query("postgresql", "public.customers")
        assert "public" in query
        assert "customers" in query

    def test_metadata_query_uses_count(self):
        query = build_metadata_query("postgresql", "public.users")
        assert "COUNT(*)" in query

    def test_metadata_query_includes_row_count(self):
        query = build_metadata_query("postgresql", "public.orders")
        assert "COUNT(*)" in query
        assert "row_counts" in query

    def test_metadata_query_includes_data_size(self):
        query = build_metadata_query("postgresql", "public.products")
        assert "pg_total_relation_size" in query
        assert "data_mb" in query

    def test_metadata_query_queries_actual_table(self):
        query = build_metadata_query("postgresql", "sales.orders")
        assert "FROM sales.orders" in query

    def test_metadata_query_defaults_to_public_schema(self):
        query = build_postgresql_metadata_query("customers")
        assert "FROM public.customers" in query

    @pytest.mark.parametrize(
        "source_type,table_name",
        [
            ("postgresql", "customers"),
            ("postgresql", "sales.orders"),
            ("postgres", "public.users"),
            ("postgres", "analytics.events"),
        ],
    )
    def test_metadata_query_for_various_aliases(
        self, source_type: str, table_name: str
    ):
        query = build_metadata_query(source_type, table_name)
        assert query is not None
        assert "COUNT(*)" in query


class TestPostgresqlSchemaQuery:
    """Tests for building PostgreSQL schema queries."""

    def test_build_schema_query_simple_table(self):
        query = build_schema_query("postgresql", "customers")
        assert query is not None
        assert isinstance(query, str)
        assert len(query) > 0

    def test_build_schema_query_with_schema(self):
        query = build_schema_query("postgresql", "sales.orders")
        assert "sales" in query
        assert "orders" in query

    def test_schema_query_uses_information_schema(self):
        query = build_schema_query("postgresql", "public.users")
        assert "information_schema" in query.lower()

    def test_schema_query_selects_column_info(self):
        query = build_schema_query("postgresql", "public.orders")
        assert "column_name" in query
        assert "data_type" in query
        assert "ordinal_position" in query

    def test_schema_query_filters_by_table(self):
        query = build_schema_query("postgresql", "public.products")
        assert "products" in query

    def test_schema_query_defaults_to_public_schema(self):
        query = build_postgresql_schema_query("customers")
        assert "'public'" in query
        assert "'customers'" in query

    def test_schema_query_with_database(self):
        query = build_postgresql_schema_query("sampledb.public.customers")
        assert "'sampledb'" in query
        assert "table_catalog" in query
        assert "'public'" in query
        assert "'customers'" in query

    @pytest.mark.parametrize(
        "source_type,table_name",
        [
            ("postgresql", "customers"),
            ("postgresql", "sales.orders"),
            ("postgres", "public.users"),
            ("postgres", "analytics.events"),
        ],
    )
    def test_schema_query_for_various_aliases(self, source_type: str, table_name: str):
        query = build_schema_query(source_type, table_name)
        assert query is not None
        assert "information_schema" in query.lower()


class TestPostgresqlQueryStructure:
    """Tests for PostgreSQL query structure and content."""

    def test_metadata_query_structure(self):
        query = build_metadata_query("postgresql", "public.customers")
        assert "COUNT(*)" in query
        assert "pg_total_relation_size" in query
        assert query.strip().upper().startswith("SELECT")

    def test_schema_query_structure(self):
        query = build_schema_query("postgresql", "public.customers")
        assert "information_schema" in query.lower()
        assert query.strip().upper().startswith("SELECT")
        assert "column" in query.lower()

    def test_queries_are_non_empty(self):
        metadata_query = build_metadata_query("postgresql", "test_table")
        schema_query = build_schema_query("postgresql", "test_table")
        assert len(metadata_query) > 50
        assert len(schema_query) > 50


class TestPostgresqlQueryErrorHandling:
    """Tests for error handling in query generation."""

    def test_empty_table_name_metadata_raises_error(self):
        with pytest.raises(ValueError, match="table_name"):
            build_metadata_query("postgresql", "")

    def test_empty_table_name_schema_raises_error(self):
        with pytest.raises(ValueError, match="table_name"):
            build_schema_query("postgresql", "")

    def test_none_table_name_metadata_raises_error(self):
        with pytest.raises((ValueError, TypeError)):
            build_metadata_query("postgresql", None)

    def test_none_table_name_schema_raises_error(self):
        with pytest.raises((ValueError, TypeError)):
            build_schema_query("postgresql", None)

    def test_direct_builder_empty_table_raises_error(self):
        with pytest.raises(ValueError, match="table_name"):
            build_postgresql_metadata_query("")

    def test_direct_schema_builder_empty_table_raises_error(self):
        with pytest.raises(ValueError, match="table_name"):
            build_postgresql_schema_query("")


class TestPostgresqlQueryIntegration:
    """Integration tests for PostgreSQL query generation."""

    def test_complete_workflow_metadata_query(self):
        table_name = "inventory.product_catalog"
        query = build_metadata_query("postgresql", table_name)

        assert "COUNT(*)" in query
        assert "FROM inventory.product_catalog" in query
        assert query.strip().upper().startswith("SELECT")

    def test_complete_workflow_schema_query(self):
        table_name = "inventory.product_catalog"
        query = build_schema_query("postgresql", table_name)

        assert "information_schema" in query.lower()
        assert "inventory" in query
        assert "product_catalog" in query
        assert query.strip().upper().startswith("SELECT")

    def test_queries_differ_by_purpose(self):
        table_name = "public.test_table"
        metadata_query = build_metadata_query("postgresql", table_name)
        schema_query = build_schema_query("postgresql", table_name)

        assert metadata_query != schema_query
        assert "COUNT(*)" in metadata_query
        assert "information_schema" in schema_query.lower()


class TestPostgresqlTableNameParsing:
    """Tests for table name parsing in PostgreSQL queries."""

    def test_simple_table_name(self):
        query = build_metadata_query("postgresql", "customers")
        assert "customers" in query

    def test_schema_qualified_table_name(self):
        query = build_metadata_query("postgresql", "public.customers")
        assert "public" in query
        assert "customers" in query

    def test_fully_qualified_table_name(self):
        query = build_metadata_query("postgresql", "sampledb.public.customers")
        assert "customers" in query
        assert "public" in query

    def test_table_name_with_underscore(self):
        query = build_schema_query("postgresql", "customer_orders")
        assert "customer_orders" in query

    def test_table_name_with_numbers(self):
        query = build_schema_query("postgresql", "orders_2024")
        assert "orders_2024" in query

    def test_simple_name_defaults_to_public(self):
        query = build_postgresql_metadata_query("customers")
        assert "FROM public.customers" in query

    def test_explicit_schema_used(self):
        query = build_postgresql_metadata_query("sales.orders")
        assert "FROM sales.orders" in query
