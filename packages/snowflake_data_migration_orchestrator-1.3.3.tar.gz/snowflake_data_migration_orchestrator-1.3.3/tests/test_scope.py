"""Tests for scope utilities."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.scope import (
    ScopeBuilder,
    build_partition_extraction_scope,
    build_partition_loading_scope,
    build_table_preprocessing_scope,
)
from shared.enums.source_type import SourceType


class TestScopeBuilderForTable:
    """Tests for ScopeBuilder.for_table() factory method."""

    def test_for_table_creates_builder(self):
        """Test that for_table returns a ScopeBuilder instance."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        builder = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
        assert isinstance(builder, ScopeBuilder)


class TestScopeBuilderPartition:
    """Tests for ScopeBuilder.partition() method."""

    def test_partition_adds_fragment(self):
        """Test that partition adds a Partition fragment."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(0)
            .extraction()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[0]::Extraction"

    def test_partition_with_positive_id(self):
        """Test partition with various positive IDs."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(5)
            .extraction()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[5]::Extraction"

    def test_partition_returns_self_for_chaining(self):
        """Test that partition returns self for method chaining."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        builder = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
        result = builder.partition(1)
        assert result is builder

    def test_partition_negative_id_raises_error(self):
        """Test that negative partition IDs raise ValueError."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        with pytest.raises(ValueError) as excinfo:
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).partition(-1)
        assert "non-negative" in str(excinfo.value)
        assert "-1" in str(excinfo.value)


class TestScopeBuilderPreprocessing:
    """Tests for ScopeBuilder.preprocessing() method."""

    def test_preprocessing_table_scope(self):
        """Test building a table-level preprocessing scope."""
        table_id = TableIdentifier(
            database_name="MY_DB", schema_name="MY_SCHEMA", table_name="MY_TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).preprocessing()
        assert scope == "Table[MY_DB.MY_SCHEMA.MY_TABLE]::Preprocessing"

    def test_preprocessing_returns_string(self):
        """Test that preprocessing returns a string."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).preprocessing()
        assert isinstance(scope, str)


class TestScopeBuilderExtraction:
    """Tests for ScopeBuilder.extraction() method."""

    def test_extraction_table_scope(self):
        """Test building a table-level extraction scope."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).extraction()
        assert scope == "Table[DB.SCHEMA.TABLE]::Extraction"

    def test_extraction_partition_scope(self):
        """Test building a partition-level extraction scope."""
        table_id = TableIdentifier(
            database_name="MY_DB", schema_name="MY_SCHEMA", table_name="MY_TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(2)
            .extraction()
        )
        assert scope == "Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[2]::Extraction"

    def test_extraction_returns_string(self):
        """Test that extraction returns a string."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(0)
            .extraction()
        )
        assert isinstance(scope, str)


class TestScopeBuilderLoading:
    """Tests for ScopeBuilder.loading() method."""

    def test_loading_table_scope(self):
        """Test building a table-level loading scope."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).loading()
        assert scope == "Table[DB.SCHEMA.TABLE]::Loading"

    def test_loading_partition_scope(self):
        """Test building a partition-level loading scope."""
        table_id = TableIdentifier(
            database_name="MY_DB", schema_name="MY_SCHEMA", table_name="MY_TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(2)
            .loading()
        )
        assert scope == "Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[2]::Loading"

    def test_loading_returns_string(self):
        """Test that loading returns a string."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(0)
            .loading()
        )
        assert isinstance(scope, str)


class TestScopeBuilderBuild:
    """Tests for ScopeBuilder.build() method."""

    def test_build_table_only(self):
        """Test building a partial scope with just the table."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).build()
        assert scope == "Table[DB.SCHEMA.TABLE]"

    def test_build_table_with_partition(self):
        """Test building a partial scope with table and partition."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).partition(3).build()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[3]"

    def test_build_useful_for_like_queries(self):
        """Test that build creates scopes useful for LIKE patterns."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        partial = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).build()
        # This partial scope could be used in a LIKE query to find all tasks for a table
        assert partial.startswith("Table[")
        assert "::" not in partial or partial.count("::") == 0


class TestScopeBuilderErrors:
    """Tests for ScopeBuilder error conditions."""

    def test_preprocessing_without_table_raises_error(self):
        """Test that calling preprocessing without for_table raises ValueError."""
        builder = ScopeBuilder()
        with pytest.raises(ValueError) as excinfo:
            builder.preprocessing()
        assert "for_table()" in str(excinfo.value)

    def test_extraction_without_table_raises_error(self):
        """Test that calling extraction without for_table raises ValueError."""
        builder = ScopeBuilder()
        with pytest.raises(ValueError) as excinfo:
            builder.extraction()
        assert "for_table()" in str(excinfo.value)

    def test_loading_without_table_raises_error(self):
        """Test that calling loading without for_table raises ValueError."""
        builder = ScopeBuilder()
        with pytest.raises(ValueError) as excinfo:
            builder.loading()
        assert "for_table()" in str(excinfo.value)

    def test_build_without_table_raises_error(self):
        """Test that calling build without for_table raises ValueError."""
        builder = ScopeBuilder()
        with pytest.raises(ValueError) as excinfo:
            builder.build()
        assert "for_table()" in str(excinfo.value)


class TestScopeBuilderFragmentSeparator:
    """Tests for ScopeBuilder fragment separator."""

    def test_fragment_separator_constant(self):
        """Test that FRAGMENT_SEPARATOR is correct."""
        assert ScopeBuilder.FRAGMENT_SEPARATOR == "::"

    def test_fragments_joined_with_separator(self):
        """Test that fragments are joined with the correct separator."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(1)
            .extraction()
        )
        assert scope.count("::") == 2
        parts = scope.split("::")
        assert parts[0] == "Table[DB.SCHEMA.TABLE]"
        assert parts[1] == "Partition[1]"
        assert parts[2] == "Extraction"


class TestBuildTableScope:
    """Tests for build_table_scope convenience function."""

    def test_build_table_scope_basic(self):
        """Test basic table scope creation."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_table_preprocessing_scope(table_id, SourceType.SQLSERVER)
        assert scope == "Table[DB.SCHEMA.TABLE]::Preprocessing"

    def test_build_table_scope_preserves_case(self):
        """Test that table scope preserves original case for identifiers that need quoting."""
        # Note: SQL Server identifiers are normalized to uppercase unless they require quoting
        table_id = TableIdentifier(
            database_name="db", schema_name="schema", table_name="table"
        )
        scope = build_table_preprocessing_scope(table_id, SourceType.SQLSERVER)
        # Unquoted identifiers are case-insensitive and normalized to uppercase
        assert scope == "Table[DB.SCHEMA.TABLE]::Preprocessing"

    def test_build_table_scope_matches_builder(self):
        """Test that convenience function matches builder output."""
        table_id = TableIdentifier(
            database_name="MY", schema_name="SCHEMA", table_name="TABLE"
        )
        convenience = build_table_preprocessing_scope(table_id, SourceType.SQLSERVER)
        builder = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).preprocessing()
        assert convenience == builder


class TestBuildPartitionExtractionScope:
    """Tests for build_partition_extraction_scope convenience function."""

    def test_build_partition_extraction_scope_basic(self):
        """Test basic partition extraction scope creation."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_partition_extraction_scope(table_id, 2, SourceType.SQLSERVER)
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[2]::Extraction"

    def test_build_partition_extraction_scope_zero_partition(self):
        """Test partition extraction scope with partition 0."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_partition_extraction_scope(table_id, 0, SourceType.SQLSERVER)
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[0]::Extraction"

    def test_build_partition_extraction_scope_preserves_case(self):
        """Test that table name case behavior follows SQL Server rules."""
        # Unquoted identifiers are case-insensitive and normalized to uppercase
        table_id = TableIdentifier(
            database_name="my", schema_name="schema", table_name="table"
        )
        scope = build_partition_extraction_scope(table_id, 5, SourceType.SQLSERVER)
        assert scope == "Table[MY.SCHEMA.TABLE]::Partition[5]::Extraction"

    def test_build_partition_extraction_scope_matches_builder(self):
        """Test that convenience function matches builder output."""
        table_id = TableIdentifier(
            database_name="MY", schema_name="SCHEMA", table_name="TABLE"
        )
        partition_id = 7
        convenience = build_partition_extraction_scope(
            table_id, partition_id, SourceType.SQLSERVER
        )
        builder = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(partition_id)
            .extraction()
        )
        assert convenience == builder

    def test_build_partition_extraction_scope_negative_id_raises_error(self):
        """Test that negative partition IDs raise ValueError."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        with pytest.raises(ValueError):
            build_partition_extraction_scope(table_id, -1, SourceType.SQLSERVER)


class TestBuildPartitionLoadingScope:
    """Tests for build_partition_loading_scope convenience function."""

    def test_build_partition_loading_scope_basic(self):
        """Test basic partition loading scope creation."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_partition_loading_scope(table_id, 2, SourceType.SQLSERVER)
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[2]::Loading"

    def test_build_partition_loading_scope_zero_partition(self):
        """Test partition loading scope with partition 0."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_partition_loading_scope(table_id, 0, SourceType.SQLSERVER)
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[0]::Loading"

    def test_build_partition_loading_scope_preserves_case(self):
        """Test that table name case behavior follows SQL Server rules."""
        # Unquoted identifiers are case-insensitive and normalized to uppercase
        table_id = TableIdentifier(
            database_name="my", schema_name="schema", table_name="table"
        )
        scope = build_partition_loading_scope(table_id, 5, SourceType.SQLSERVER)
        assert scope == "Table[MY.SCHEMA.TABLE]::Partition[5]::Loading"

    def test_build_partition_loading_scope_matches_builder(self):
        """Test that convenience function matches builder output."""
        table_id = TableIdentifier(
            database_name="MY", schema_name="SCHEMA", table_name="TABLE"
        )
        partition_id = 7
        convenience = build_partition_loading_scope(
            table_id, partition_id, SourceType.SQLSERVER
        )
        builder = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(partition_id)
            .loading()
        )
        assert convenience == builder

    def test_build_partition_loading_scope_negative_id_raises_error(self):
        """Test that negative partition IDs raise ValueError."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        with pytest.raises(ValueError):
            build_partition_loading_scope(table_id, -1, SourceType.SQLSERVER)


class TestScopeBuilderDocExamples:
    """Tests that verify the examples from the docstrings work correctly."""

    def test_table_preprocessing_example(self):
        """Test the table preprocessing example from the docstring."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).preprocessing()
        assert scope == "Table[DB.SCHEMA.TABLE]::Preprocessing"

    def test_partition_extraction_example(self):
        """Test the partition extraction example from the docstring."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(2)
            .extraction()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[2]::Extraction"

    def test_partition_loading_example(self):
        """Test the partition loading example from the docstring."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(2)
            .loading()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[2]::Loading"


class TestScopeBuilderRealWorldScenarios:
    """Tests for real-world usage scenarios."""

    def test_fully_qualified_table_names(self):
        """Test with fully qualified table names including special characters."""
        table_id = TableIdentifier(
            database_name="SNOWCONVERT_AI",
            schema_name="DATA_MIGRATION",
            table_name="TASK_QUEUE",
        )
        scope = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).preprocessing()
        assert scope == "Table[SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE]::Preprocessing"

    def test_multiple_partitions_have_unique_scopes(self):
        """Test that different partitions generate unique scopes."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scopes = [
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(i)
            .extraction()
            for i in range(5)
        ]
        assert len(scopes) == len(set(scopes))  # All unique

    def test_extraction_and_loading_for_same_partition_differ(self):
        """Test that extraction and loading scopes for the same partition differ."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        extraction = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(1)
            .extraction()
        )
        loading = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(1)
            .loading()
        )
        assert extraction != loading
        assert "Extraction" in extraction
        assert "Loading" in loading

    def test_scope_can_be_used_for_prefix_matching(self):
        """Test that partial scopes can be used for prefix matching."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        table_prefix = ScopeBuilder.for_table(table_id, SourceType.SQLSERVER).build()
        partition_scope = (
            ScopeBuilder.for_table(table_id, SourceType.SQLSERVER)
            .partition(1)
            .extraction()
        )
        assert partition_scope.startswith(table_prefix)
