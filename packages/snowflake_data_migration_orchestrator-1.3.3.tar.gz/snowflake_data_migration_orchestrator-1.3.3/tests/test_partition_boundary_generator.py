"""Tests for partition boundary generator."""

from datetime import datetime

import pytest

# Import platforms to ensure registration happens
import data_migration_orchestrator.data_migration_cloud.platforms  # noqa: F401

from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundaryGenerator,
)


class TestFormatValue:
    """Tests for _format_value method."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()
        # Initialize query builder with sqlserver (to test _format_value directly)
        self.generator.generate_single_boundary(
            partition_column="test_col",
            partition_id=0,
            min_value=0,
            max_value=1,
            source_type="sqlserver",
        )

    # Non-datetime types

    def test_format_integer(self):
        """Test formatting an integer value."""
        result = self.generator._format_value(100)
        assert result == "100"

    def test_format_float(self):
        """Test formatting a float value."""
        result = self.generator._format_value(123.456)
        assert result == "123.456"

    def test_format_string(self):
        """Test formatting a regular string value."""
        result = self.generator._format_value("hello")
        # SQL Server uses N prefix for Unicode strings
        assert result == "N'hello'"

    def test_format_string_with_quotes(self):
        """Test formatting a string containing single quotes."""
        result = self.generator._format_value("it's a test")
        assert result == "N'it''s a test'"

    def test_format_none(self):
        """Test formatting a None value."""
        result = self.generator._format_value(None)
        assert result == "NULL"

    # Datetime integration (detailed datetime tests are in test_datetime_utils.py)

    def test_format_datetime_string_delegates_to_utils(self):
        """Test that datetime strings are formatted using datetime utils."""
        result = self.generator._format_value("2023-07-01 01:01:52.197000")
        assert "CONVERT(datetime2," in result

    def test_format_python_datetime_delegates_to_utils(self):
        """Test that Python datetime objects are formatted using datetime utils."""
        dt = datetime(2023, 7, 1, 1, 1, 52, 197000)
        result = self.generator._format_value(dt)
        assert "CONVERT(datetime2," in result


class TestGenerateBoundariesWithDatetime:
    """Tests for generate_boundaries with datetime partition columns."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()

    def test_generate_boundaries_with_datetime_values(self):
        """Test generating boundaries with datetime boundary values."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": "2023-01-01 00:00:00.000000",
                "max_value_in_partition": "2023-06-30 23:59:59.999000",
                "n_rows": 1000,
            },
            {
                "partition_id": 2,
                "min_value_in_partition": "2023-07-01 00:00:00.000000",
                "max_value_in_partition": "2023-12-31 23:59:59.999000",
                "n_rows": 1000,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_column="LogTimestampUTC",
            boundary_values=boundary_values,
            num_partitions=2,
            source_type="sqlserver",
        )

        # 2 interior + 2 edge = 4
        assert len(partitions) == 4

        # Interior partitions are at indices 1 and 2
        first_where = partitions[1].where_clause
        assert "LogTimestampUTC >=" in first_where
        assert "CONVERT(datetime2," in first_where
        assert "2023-01-01T00:00:00.000" in first_where
        assert "LogTimestampUTC <" in first_where
        assert "2023-07-01T00:00:00.000" in first_where

        last_where = partitions[2].where_clause
        assert "LogTimestampUTC >=" in last_where
        assert "LogTimestampUTC <=" in last_where
        assert "2023-12-31T23:59:59.999" in last_where

    def test_generate_boundaries_with_datetimeoffset_values(self):
        """Test generating boundaries with DateTimeOffset boundary values."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": "2023-01-01T00:00:00.000+00:00",
                "max_value_in_partition": "2023-06-30T23:59:59.999+00:00",
                "n_rows": 1000,
            },
            {
                "partition_id": 2,
                "min_value_in_partition": "2023-07-01T00:00:00.000+00:00",
                "max_value_in_partition": "2023-12-31T23:59:59.999+00:00",
                "n_rows": 1000,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_column="EventTimestamp",
            boundary_values=boundary_values,
            num_partitions=2,
            source_type="sqlserver",
        )

        # 2 interior + 2 edge = 4
        assert len(partitions) == 4

        # Interior partition at index 1
        first_interior_where = partitions[1].where_clause
        assert "CONVERT(datetimeoffset," in first_interior_where
        assert "+00:00" in first_interior_where


class TestWhereClauseGeneration:
    """Tests for WHERE clause generation."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()

    def test_where_clause_uses_convert_for_datetime(self):
        """Test that WHERE clauses use CONVERT for datetime columns."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": "2023-07-01 01:01:52.197000",
                "max_value_in_partition": "2023-12-30 13:01:05.767000",
                "n_rows": 5000,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_column="LogTimestampUTC",
            boundary_values=boundary_values,
            num_partitions=1,
            source_type="sqlserver",
        )

        # 1 interior + 2 edge = 3; interior partition is at index 1
        assert len(partitions) == 3
        where_clause = partitions[1].where_clause

        assert "CONVERT(datetime2," in where_clause
        assert "'2023-07-01T01:01:52.197'" in where_clause
        assert "'2023-12-30T13:01:05.767'" in where_clause
        assert ", 126)" in where_clause


class TestEdgePartitions:
    """Tests for edge partition generation in generate_boundaries."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()

    def test_edge_partitions_are_created(self):
        """generate_boundaries returns N+2 partitions with lower and upper edges."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": 1,
                "max_value_in_partition": 500,
                "n_rows": 500,
            },
            {
                "partition_id": 2,
                "min_value_in_partition": 501,
                "max_value_in_partition": 1000,
                "n_rows": 500,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_column="id",
            boundary_values=boundary_values,
            num_partitions=2,
            source_type="redshift",
        )

        assert len(partitions) == 4

        lower = partitions[0]
        upper = partitions[3]

        assert lower.partition_index == 0
        assert lower.min_value is None
        assert lower.max_value == 1
        assert lower.row_count == 0

        assert upper.partition_index == 3
        assert upper.min_value == 1000
        assert upper.max_value is None
        assert upper.row_count == 0

    def test_lower_edge_uses_exclusive_less_than(self):
        """Lower edge partition uses '<' (exclusive upper bound)."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": 10,
                "max_value_in_partition": 20,
                "n_rows": 100,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_column="val",
            boundary_values=boundary_values,
            num_partitions=1,
            source_type="redshift",
        )

        lower = partitions[0]
        assert '"val" < 10' in lower.where_clause
        assert ">=" not in lower.where_clause

    def test_upper_edge_uses_exclusive_greater_than(self):
        """Upper edge partition uses '>' (exclusive lower bound)."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": 10,
                "max_value_in_partition": 20,
                "n_rows": 100,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_column="val",
            boundary_values=boundary_values,
            num_partitions=1,
            source_type="redshift",
        )

        upper = partitions[2]
        assert '"val" > 20' in upper.where_clause
        assert "<=" not in upper.where_clause

    def test_interior_partitions_unchanged(self):
        """Interior partitions retain the existing >= / < / <= logic."""
        boundary_values = [
            {
                "partition_id": 1,
                "min_value_in_partition": 1,
                "max_value_in_partition": 500,
                "n_rows": 500,
            },
            {
                "partition_id": 2,
                "min_value_in_partition": 501,
                "max_value_in_partition": 1000,
                "n_rows": 500,
            },
        ]

        partitions = self.generator.generate_boundaries(
            partition_column="id",
            boundary_values=boundary_values,
            num_partitions=2,
            source_type="redshift",
        )

        first_interior = partitions[1]
        assert ">= 1" in first_interior.where_clause
        assert "< 501" in first_interior.where_clause

        last_interior = partitions[2]
        assert ">= 501" in last_interior.where_clause
        assert "<= 1000" in last_interior.where_clause


class TestGenerateSingleBoundaryEdge:
    """Tests for generate_single_boundary with NULL bounds (edge partitions)."""

    def setup_method(self):
        """Set up test instance."""
        self.generator = PartitionBoundaryGenerator()

    def test_single_boundary_full_table(self):
        """Both None -> empty WHERE clause (full table)."""
        boundary = self.generator.generate_single_boundary(
            partition_column="id",
            partition_id=0,
            min_value=None,
            max_value=None,
            source_type="redshift",
        )

        assert boundary.where_clause == ""

    def test_single_boundary_only_max(self):
        """Only max (lower edge) -> exclusive: col < max."""
        boundary = self.generator.generate_single_boundary(
            partition_column="id",
            partition_id=0,
            min_value=None,
            max_value=100,
            source_type="redshift",
        )

        assert '"id" < 100' in boundary.where_clause

    def test_single_boundary_only_min(self):
        """Only min (upper edge) -> exclusive: col > min."""
        boundary = self.generator.generate_single_boundary(
            partition_column="id",
            partition_id=99,
            min_value=1000,
            max_value=None,
            source_type="redshift",
        )

        assert '"id" > 1000' in boundary.where_clause

    def test_single_boundary_both_bounds(self):
        """Both bounds -> inclusive: col >= min AND col <= max."""
        boundary = self.generator.generate_single_boundary(
            partition_column="id",
            partition_id=1,
            min_value=10,
            max_value=50,
            source_type="redshift",
        )

        assert '"id" >= 10' in boundary.where_clause
        assert '"id" <= 50' in boundary.where_clause


class TestBuildPartitionCondition:
    """Tests for BaseQueryBuilder.build_partition_condition through platform instances."""

    @pytest.fixture()
    def redshift_qb(self):
        platform = PlatformRegistry.create_by_name_or_alias("redshift")
        return platform.query_builder

    @pytest.fixture()
    def sqlserver_qb(self):
        platform = PlatformRegistry.create_by_name_or_alias("sqlserver")
        return platform.query_builder

    def test_both_bounds_inclusive(self, redshift_qb):
        result = redshift_qb.build_partition_condition("col", 1, 100)
        assert result == '"col" >= 1 AND "col" <= 100'

    def test_only_min_exclusive(self, redshift_qb):
        result = redshift_qb.build_partition_condition("col", 1000, None)
        assert result == '"col" > 1000'

    def test_only_max_exclusive(self, redshift_qb):
        result = redshift_qb.build_partition_condition("col", None, 500)
        assert result == '"col" < 500'

    def test_no_bounds(self, redshift_qb):
        result = redshift_qb.build_partition_condition("col", None, None)
        assert result == "1=1"

    def test_sqlserver_quoting(self, sqlserver_qb):
        result = sqlserver_qb.build_partition_condition("my col", 10, 20)
        assert "[my col] >= 10" in result
        assert "[my col] <= 20" in result

    def test_sqlserver_datetime_formatting(self, sqlserver_qb):
        result = sqlserver_qb.build_partition_condition(
            "ts", "2023-01-01 00:00:00.000000", None
        )
        assert "CONVERT(datetime2," in result
        assert ">" in result
        assert ">=" not in result
