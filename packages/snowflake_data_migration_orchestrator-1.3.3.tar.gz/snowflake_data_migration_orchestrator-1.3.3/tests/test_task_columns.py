import unittest

from data_migration_orchestrator.cloud_core.tasks.constants.task_columns import (
    ID,
    PAYLOAD,
    STATUS,
)


class TestTaskColumns(unittest.TestCase):
    """
    Test suite for task column name constants.

    This test class validates that the task column constants are defined
    correctly and consistently.
    """

    def test_id_column_constant(self):
        """Test that ID constant has the correct value."""
        self.assertEqual(ID, "ID")

    def test_status_column_constant(self):
        """Test that STATUS constant has the correct value."""
        self.assertEqual(STATUS, "STATUS")

    def test_payload_column_constant(self):
        """Test that PAYLOAD constant has the correct value."""
        self.assertEqual(PAYLOAD, "PAYLOAD")

    def test_all_constants_are_strings(self):
        """Test that all column constants are strings."""
        self.assertIsInstance(ID, str)
        self.assertIsInstance(STATUS, str)
        self.assertIsInstance(PAYLOAD, str)

    def test_constants_are_uppercase(self):
        """Test that all column constants are uppercase."""
        self.assertEqual(ID, ID.upper())
        self.assertEqual(STATUS, STATUS.upper())
        self.assertEqual(PAYLOAD, PAYLOAD.upper())

    def test_constants_are_unique(self):
        """Test that all column constants have unique values."""
        constants = [ID, STATUS, PAYLOAD]
        self.assertEqual(len(constants), len(set(constants)))


if __name__ == "__main__":
    unittest.main()
