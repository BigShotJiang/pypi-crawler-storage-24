"""
Tests for WorkflowProgressService.

This module tests the partition metadata insertion and table preprocessing
methods for workflow progress tracking.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_progress_service import (
    WorkflowProgressService,
)


class TestFormatAsVariant(unittest.TestCase):
    """Test cases for _format_as_variant helper method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_warehouse_proxy = MagicMock()
        self.progress_service = WorkflowProgressService(
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    def test_format_none_returns_null(self):
        """Test that None is formatted as NULL."""
        result = self.progress_service._format_as_variant(None)
        self.assertEqual(result, "NULL")

    def test_format_boolean_true(self):
        """Test that True is formatted as TRUE::VARIANT."""
        result = self.progress_service._format_as_variant(True)
        self.assertEqual(result, "TRUE::VARIANT")

    def test_format_boolean_false(self):
        """Test that False is formatted as FALSE::VARIANT."""
        result = self.progress_service._format_as_variant(False)
        self.assertEqual(result, "FALSE::VARIANT")

    def test_format_integer(self):
        """Test that integers are formatted with ::VARIANT cast."""
        result = self.progress_service._format_as_variant(42)
        self.assertEqual(result, "42::VARIANT")

    def test_format_negative_integer(self):
        """Test that negative integers are formatted correctly."""
        result = self.progress_service._format_as_variant(-100)
        self.assertEqual(result, "-100::VARIANT")

    def test_format_float(self):
        """Test that floats are formatted with ::VARIANT cast."""
        result = self.progress_service._format_as_variant(3.14)
        self.assertEqual(result, "3.14::VARIANT")

    def test_format_negative_float(self):
        """Test that negative floats are formatted correctly."""
        result = self.progress_service._format_as_variant(-99.99)
        self.assertEqual(result, "-99.99::VARIANT")

    def test_format_numeric_string_integer(self):
        """Test that numeric strings are formatted as numbers."""
        result = self.progress_service._format_as_variant("123")
        self.assertEqual(result, "123::VARIANT")

    def test_format_numeric_string_float(self):
        """Test that float strings are formatted as numbers."""
        result = self.progress_service._format_as_variant("45.67")
        self.assertEqual(result, "45.67::VARIANT")

    def test_format_string_quoted(self):
        """Test that regular strings are quoted and cast to VARIANT."""
        result = self.progress_service._format_as_variant("hello")
        self.assertEqual(result, "'hello'::VARIANT")

    def test_format_string_with_single_quotes_escaped(self):
        """Test that single quotes in strings are escaped."""
        result = self.progress_service._format_as_variant("it's a test")
        self.assertEqual(result, "'it''s a test'::VARIANT")

    def test_format_string_with_multiple_quotes(self):
        """Test that multiple quotes are all escaped."""
        result = self.progress_service._format_as_variant("don't say 'hello'")
        self.assertEqual(result, "'don''t say ''hello'''::VARIANT")

    def test_format_zero(self):
        """Test that zero is formatted correctly."""
        result = self.progress_service._format_as_variant(0)
        self.assertEqual(result, "0::VARIANT")

    def test_format_large_integer(self):
        """Test that large integers are formatted correctly."""
        result = self.progress_service._format_as_variant(9999999999999)
        self.assertEqual(result, "9999999999999::VARIANT")


class TestInsertPartitionMetadata(unittest.IsolatedAsyncioTestCase):
    """Test cases for insert_partition_metadata method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            return_value=[{"INSERT_PARTITION_METADATA": 42}]
        )

        self.progress_service = WorkflowProgressService(
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    async def test_insert_partition_metadata_success(self):
        """Test successful partition metadata insertion."""
        result = await self.progress_service.insert_partition_metadata(
            table_metadata_id=100,
            partition_number=1,
            min_value=1,
            max_value=1000,
            rows=None,
        )

        self.assertEqual(result, 42)
        self.mock_warehouse_proxy.execute_sync_query.assert_called_once()

    async def test_insert_partition_metadata_query_format(self):
        """Test that the INSERT query is formatted correctly."""
        await self.progress_service.insert_partition_metadata(
            table_metadata_id=55,
            partition_number=2,
            min_value=100,
            max_value=200,
            rows=1500,
        )

        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]

        self.assertIn(
            "CALL SNOWCONVERT_AI.DATA_MIGRATION.INSERT_PARTITION_METADATA", query
        )
        self.assertIn("55", query)  # table_metadata_id
        self.assertIn("2", query)  # partition_number
        self.assertIn("100::VARIANT", query)  # min_value
        self.assertIn("200::VARIANT", query)  # max_value
        self.assertIn("1500", query)  # rows

    async def test_insert_partition_metadata_with_null_rows(self):
        """Test insert with NULL rows."""
        await self.progress_service.insert_partition_metadata(
            table_metadata_id=10,
            partition_number=3,
            min_value=0,
            max_value=100,
            rows=None,
        )

        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]
        self.assertIn("NULL)", query)  # rows is NULL

    async def test_insert_partition_metadata_with_null_values(self):
        """Test insert with NULL min/max values (full table partition)."""
        await self.progress_service.insert_partition_metadata(
            table_metadata_id=20,
            partition_number=1,
            min_value=None,
            max_value=None,
            rows=50000,
        )

        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]
        self.assertIn("NULL, NULL", query)  # Both min and max are NULL

    async def test_insert_partition_metadata_returns_none_when_table_id_is_none(self):
        """Test that None is returned when table_metadata_id is None."""
        result = await self.progress_service.insert_partition_metadata(
            table_metadata_id=None,
            partition_number=1,
            min_value=1,
            max_value=100,
            rows=None,
        )

        self.assertIsNone(result)
        self.mock_warehouse_proxy.execute_sync_query.assert_not_called()

    async def test_insert_partition_metadata_returns_none_when_no_warehouse_proxy(self):
        """Test that None is returned when warehouse_proxy is None."""
        progress_service = WorkflowProgressService(
            warehouse_proxy=None,
        )

        result = await progress_service.insert_partition_metadata(
            table_metadata_id=100,
            partition_number=1,
            min_value=1,
            max_value=100,
            rows=None,
        )

        self.assertIsNone(result)

    async def test_insert_partition_metadata_handles_query_error(self):
        """Test that errors are caught and None is returned."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=Exception("Database error")
        )

        result = await self.progress_service.insert_partition_metadata(
            table_metadata_id=100,
            partition_number=1,
            min_value=1,
            max_value=100,
            rows=None,
        )

        self.assertIsNone(result)

    async def test_insert_partition_metadata_with_string_boundaries(self):
        """Test insert with string boundary values."""
        await self.progress_service.insert_partition_metadata(
            table_metadata_id=30,
            partition_number=5,
            min_value="AAA",
            max_value="ZZZ",
            rows=1000,
        )

        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]
        self.assertIn("'AAA'::VARIANT", query)
        self.assertIn("'ZZZ'::VARIANT", query)


class TestUpdateTablePreprocessed(unittest.IsolatedAsyncioTestCase):
    """Test cases for update_table_preprocessed method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.progress_service = WorkflowProgressService(
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    async def test_update_table_preprocessed_success(self):
        """Test successful table metadata update."""
        await self.progress_service.update_table_preprocessed(table_metadata_id=100)

        self.mock_warehouse_proxy.execute_sync_query.assert_called_once()

    async def test_update_table_preprocessed_query_format(self):
        """Test that the UPDATE query is formatted correctly."""
        await self.progress_service.update_table_preprocessed(table_metadata_id=42)

        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]

        self.assertIn("UPDATE SNOWCONVERT_AI.DATA_MIGRATION.TABLE_METADATA", query)
        self.assertIn("HAS_BEEN_PREPROCESSED = TRUE", query)
        self.assertIn("UPDATED_AT = CURRENT_TIMESTAMP()", query)
        self.assertIn("WHERE ID = 42", query)

    async def test_update_table_preprocessed_skips_when_id_is_none(self):
        """Test that update is skipped when table_metadata_id is None."""
        await self.progress_service.update_table_preprocessed(table_metadata_id=None)

        self.mock_warehouse_proxy.execute_sync_query.assert_not_called()

    async def test_update_table_preprocessed_skips_when_no_warehouse_proxy(self):
        """Test that update is skipped when warehouse_proxy is None."""
        progress_service = WorkflowProgressService(
            warehouse_proxy=None,
        )

        await progress_service.update_table_preprocessed(table_metadata_id=100)
        # No assertion needed - should not raise

    async def test_update_table_preprocessed_handles_error_gracefully(self):
        """Test that errors are handled gracefully (logged but not raised)."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=Exception("Database error")
        )

        # Should not raise
        await self.progress_service.update_table_preprocessed(table_metadata_id=100)

    async def test_update_table_preprocessed_with_different_ids(self):
        """Test update with various table metadata IDs."""
        for table_id in [1, 100, 999999]:
            self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])
            await self.progress_service.update_table_preprocessed(
                table_metadata_id=table_id
            )

            call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
            query = call_args[0][0]
            self.assertIn(f"WHERE ID = {table_id}", query)


if __name__ == "__main__":
    unittest.main()
