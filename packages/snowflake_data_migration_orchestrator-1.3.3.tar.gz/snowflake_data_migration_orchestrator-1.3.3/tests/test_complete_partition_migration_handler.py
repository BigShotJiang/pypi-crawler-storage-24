"""
Tests for CompletePartitionMigrationHandler.

This module tests the handler for completing partition migration after COPY INTO.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.data_migration_cloud.tasks.handlers.complete_partition_migration_handler import (
    CompletePartitionMigrationHandler,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CompletePartitionMigrationTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus


class TestCompletePartitionMigrationHandler(unittest.IsolatedAsyncioTestCase):
    """Test cases for CompletePartitionMigrationHandler."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = CompletePartitionMigrationHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    def test_handler_initialization(self):
        """Test handler initializes with correct task type."""
        self.assertEqual(
            self.handler.task_type, TaskPayloadKind.COMPLETE_PARTITION_MIGRATION
        )

    def test_handler_stores_dependencies(self):
        """Test handler stores task_queue and warehouse_proxy."""
        self.assertEqual(self.handler.task_queue, self.mock_task_queue)
        self.assertEqual(self.handler.warehouse_proxy, self.mock_warehouse_proxy)

    async def test_handle_updates_partition_status_to_completed(self):
        """Test handle() updates partition metadata status to COMPLETED."""
        payload = CompletePartitionMigrationTaskPayload(partition_metadata_id=123)
        task = Task(
            id=1,
            workflow_id=100,
            task_name="Complete partition migration: users",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.USERS]::Partition[123]::Completing",
        )

        await self.handler.handle(task)

        # Verify UPDATE query was executed
        self.mock_warehouse_proxy.execute_sync_query.assert_called_once()
        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]

        self.assertIn("UPDATE SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA", query)
        self.assertIn("MIGRATION_STATUS = 'COMPLETED'", query)
        self.assertIn("WHERE ID = 123", query)

    async def test_handle_completes_task(self):
        """Test handle() marks the task as complete."""
        payload = CompletePartitionMigrationTaskPayload(partition_metadata_id=456)
        task = Task(
            id=42,
            workflow_id=100,
            task_name="Complete partition migration: orders",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.ORDERS]::Partition[456]::Completing",
        )

        await self.handler.handle(task)

        # Verify task was completed
        self.mock_task_queue.complete_task.assert_called_once_with(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=42,
        )

    async def test_handle_raises_error_when_warehouse_proxy_is_none(self):
        """Test handle() raises ValueError when warehouse_proxy is None."""
        handler = CompletePartitionMigrationHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=None,
        )

        payload = CompletePartitionMigrationTaskPayload(partition_metadata_id=789)
        task = Task(
            id=1,
            workflow_id=100,
            task_name="Test task",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[789]::Completing",
        )

        with self.assertRaises(ValueError) as context:
            await handler.handle(task)

        self.assertIn("warehouse_proxy is required", str(context.exception))

    async def test_handle_propagates_query_error(self):
        """Test handle() propagates errors from query execution."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=Exception("Database connection error")
        )

        payload = CompletePartitionMigrationTaskPayload(partition_metadata_id=999)
        task = Task(
            id=1,
            workflow_id=100,
            task_name="Test task",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[999]::Completing",
        )

        with self.assertRaises(Exception) as context:
            await self.handler.handle(task)

        self.assertIn("Database connection error", str(context.exception))

    async def test_handle_with_different_partition_ids(self):
        """Test handle() works with different partition metadata IDs."""
        partition_ids = [1, 100, 999999]

        for partition_id in partition_ids:
            # Reset mock
            self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])
            self.mock_task_queue.complete_task = AsyncMock(return_value=True)

            payload = CompletePartitionMigrationTaskPayload(
                partition_metadata_id=partition_id
            )
            task = Task(
                id=1,
                workflow_id=100,
                task_name=f"Complete partition: {partition_id}",
                executor_type=ExecutorType.ORCHESTRATOR,
                status=TaskStatus.EXECUTING,
                priority=1.0,
                payload=payload,
                scope=f"Table[DB.SCHEMA.TABLE]::Partition[{partition_id}]::Completing",
            )

            await self.handler.handle(task)

            call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
            query = call_args[0][0]
            self.assertIn(f"WHERE ID = {partition_id}", query)

    async def test_handle_query_includes_timestamp_update(self):
        """Test handle() UPDATE query includes timestamp update."""
        payload = CompletePartitionMigrationTaskPayload(partition_metadata_id=123)
        task = Task(
            id=1,
            workflow_id=100,
            task_name="Test task",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[123]::Completing",
        )

        await self.handler.handle(task)

        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]
        self.assertIn("MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP()", query)


if __name__ == "__main__":
    unittest.main()
