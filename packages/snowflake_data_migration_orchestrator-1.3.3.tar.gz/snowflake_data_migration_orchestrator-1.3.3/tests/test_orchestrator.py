import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.cloud_orchestrator.orchestrator import Orchestrator
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DataMovementTaskPayload,
    ProcessStagedDataTaskPayload,
    TargetType,
)
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus


class TestOrchestrator(unittest.IsolatedAsyncioTestCase):
    """
    Test suite for the Orchestrator class.

    This test class validates the Orchestrator functionality,
    particularly the _get_unblocked_tasks method and its
    interaction with the task queue.
    """

    def setUp(self):
        """Set up test fixtures before each test method."""
        self.workflow_id = "test-workflow-123"
        self.mock_task_queue = MagicMock()
        self.mock_warehouse_proxy = MagicMock()
        self.orchestrator = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
            worker_context_factory=MagicMock(),
        )

    async def test_get_unblocked_tasks_empty_queue(self):
        """Test _get_unblocked_tasks when no tasks are available."""
        # Mock task_queue.get_tasks to return empty list
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])

        # Call _get_unblocked_tasks
        tasks = await self.orchestrator._check_unblocked_tasks()

        # Assertions
        self.assertEqual(tasks, [])
        self.mock_task_queue.get_tasks.assert_awaited_once()

    async def test_get_unblocked_tasks_single_task(self):
        """Test _get_unblocked_tasks when one task is available."""
        # Create a mock task
        payload = DataMovementTaskPayload(
            source_type="sql-server",
            source_id="test_db",
            target_type="snowflake:table",
            target_id="MY_DB.MY_SCHEMA.MY_TABLE",
            statement_location_id="SELECT * FROM test_table",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        task = Task(
            id=1,
            workflow_id=self.workflow_id,
            task_name="Test Task",
            executor_type="orchestrator",
            status=TaskStatus.PENDING,
            payload=payload,
            scope="Table[MY_DB.MY_SCHEMA.MY_TABLE]::Extraction",
        )

        # Mock task_queue.get_tasks to return one task
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[task])

        # Call _get_unblocked_tasks
        tasks = await self.orchestrator._check_unblocked_tasks()

        # Assertions
        self.assertEqual(len(tasks), 1)
        self.assertEqual(tasks[0], task)
        self.assertEqual(tasks[0].id, 1)
        self.assertEqual(tasks[0].status, TaskStatus.PENDING)
        self.mock_task_queue.get_tasks.assert_awaited_once()

    async def test_get_unblocked_tasks_multiple_tasks(self):
        """Test _get_unblocked_tasks when multiple tasks are available."""
        # Create multiple mock tasks
        payload1 = DataMovementTaskPayload(
            source_type="teradata",
            source_id="teradata_db",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="MY_DB.MY_SCHEMA.MY_STAGE/file1.parquet",
            statement_location_id="SELECT * FROM table1",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        payload2 = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=200,
            partition_index=0,
            target_table="MY_DB.MY_SCHEMA.TARGET_TABLE",
        )

        payload3 = DataMovementTaskPayload(
            source_type="redshift",
            source_id="redshift_db",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="MY_DB.MY_SCHEMA.ANOTHER_TABLE",
            statement_location_id="MY_DB.MY_SCHEMA.MY_STAGE/query.sql",
            database="MY_DB",
            schema="MY_SCHEMA",
            statement_location_type="snowflake:stage",
        )

        tasks = [
            Task(
                id=10,
                workflow_id=self.workflow_id,
                task_name="Task 1",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload1,
                scope="Table[MY_DB.MY_SCHEMA.TABLE1]::Extraction",
            ),
            Task(
                id=20,
                workflow_id=self.workflow_id,
                task_name="Task 2",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload2,
                scope="Table[MY_DB.MY_SCHEMA.TARGET_TABLE]::Loading",
            ),
            Task(
                id=30,
                workflow_id=self.workflow_id,
                task_name="Task 3",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload3,
                scope="Table[MY_DB.MY_SCHEMA.ANOTHER_TABLE]::Extraction",
            ),
        ]

        # Mock task_queue.get_tasks to return multiple tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=tasks)

        # Call _get_unblocked_tasks
        result = await self.orchestrator._check_unblocked_tasks()

        # Assertions
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0].id, 10)
        self.assertEqual(result[1].id, 20)
        self.assertEqual(result[2].id, 30)
        self.mock_task_queue.get_tasks.assert_awaited_once()

    async def test_get_unblocked_tasks_passes_workflow_id(self):
        """Test that _get_unblocked_tasks calls get_tasks correctly."""
        # Mock task_queue.get_tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])

        # Call _get_unblocked_tasks
        await self.orchestrator._check_unblocked_tasks()

        # Verify that get_tasks was called
        self.mock_task_queue.get_tasks.assert_awaited_once()

    async def test_get_unblocked_tasks_with_different_workflow_ids(self):
        """Test _get_unblocked_tasks can be called multiple times."""
        # Reset mock
        self.mock_task_queue.reset_mock()
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])

        # Call _get_unblocked_tasks multiple times
        for _ in range(3):
            await self.orchestrator._check_unblocked_tasks()

        # Verify get_tasks was called multiple times
        self.assertEqual(self.mock_task_queue.get_tasks.await_count, 3)

    async def test_get_unblocked_tasks_returns_list(self):
        """Test that _get_unblocked_tasks always returns a list."""
        # Test with empty result
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])
        result = await self.orchestrator._check_unblocked_tasks()
        self.assertIsInstance(result, list)

        # Test with tasks
        task = Task(
            id=1,
            workflow_id=self.workflow_id,
            task_name="Test Task",
            executor_type="orchestrator",
            status=TaskStatus.PENDING,
            payload=DataMovementTaskPayload(
                source_type="mysql",
                source_id="db",
                target_type="snowflake:table",
                target_id="TABLE",
                statement_location_id="SELECT 1",
                database="MY_DB",
                schema="MY_SCHEMA",
            ),
            scope="Table[MY_DB.MY_SCHEMA.TABLE]::Extraction",
        )
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[task])
        result = await self.orchestrator._check_unblocked_tasks()
        self.assertIsInstance(result, list)

    async def test_get_unblocked_tasks_preserves_task_order(self):
        """Test that _get_unblocked_tasks preserves the order of tasks."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=50,
            partition_metadata_id=100,
            partition_index=0,
            target_table="target",
        )

        # Create tasks with specific order
        task_ids = [100, 50, 75, 25, 200]
        tasks = [
            Task(
                id=task_id,
                workflow_id=self.workflow_id,
                task_name=f"Task {task_id}",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload,
                scope=f"Table[target]::Partition[{task_id}]::Loading",
            )
            for task_id in task_ids
        ]

        # Mock task_queue.get_tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=tasks)

        # Call _get_unblocked_tasks
        result = await self.orchestrator._check_unblocked_tasks()

        # Verify order is preserved
        result_ids = [task.id for task in result]
        self.assertEqual(result_ids, task_ids)

    async def test_get_unblocked_tasks_handles_exceptions(self):
        """Test that _get_unblocked_tasks propagates exceptions from task_queue."""
        # Mock task_queue.get_tasks to raise an exception
        self.mock_task_queue.get_tasks = AsyncMock(
            side_effect=Exception("Database connection error")
        )

        # Verify exception is propagated
        with self.assertRaises(Exception) as context:
            await self.orchestrator._check_unblocked_tasks()

        self.assertIn("Database connection error", str(context.exception))

    async def test_get_unblocked_tasks_does_not_modify_tasks(self):
        """Test that _get_unblocked_tasks returns tasks without modification."""
        # Create a task with specific attributes
        original_payload = DataMovementTaskPayload(
            source_type="oracle",
            source_id="oracle_db",
            target_type="snowflake:table",
            target_id="MY_DB.MY_SCHEMA.MY_TABLE",
            statement_location_id="SELECT * FROM employees",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        original_task = Task(
            id=42,
            workflow_id=self.workflow_id,
            task_name="Original Task",
            executor_type="orchestrator",
            status=TaskStatus.PENDING,
            payload=original_payload,
            successor_task_id=100,
            scope="Table[MY_DB.MY_SCHEMA.MY_TABLE]::Extraction",
        )

        # Mock task_queue.get_tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[original_task])

        # Call _get_unblocked_tasks
        result = await self.orchestrator._check_unblocked_tasks()

        # Verify task is returned unchanged
        returned_task = result[0]
        self.assertEqual(returned_task.id, original_task.id)
        self.assertEqual(returned_task.status, original_task.status)
        self.assertEqual(returned_task.payload, original_payload)
        self.assertEqual(
            returned_task.successor_task_id, original_task.successor_task_id
        )

    async def test_get_unblocked_tasks_is_async(self):
        """Test that _get_unblocked_tasks is an async method."""
        import inspect

        self.assertTrue(
            inspect.iscoroutinefunction(self.orchestrator._check_unblocked_tasks)
        )

    async def test_get_unblocked_tasks_awaits_task_queue(self):
        """Test that _get_unblocked_tasks properly awaits the task_queue call."""
        # Create a mock that tracks if it was awaited
        mock_coro = AsyncMock(return_value=[])
        self.mock_task_queue.get_tasks = mock_coro

        # Call _get_unblocked_tasks
        await self.orchestrator._check_unblocked_tasks()

        # Verify the async method was awaited
        mock_coro.assert_awaited_once()

    async def test_get_unblocked_tasks_with_mixed_task_types(self):
        """Test _get_unblocked_tasks with different task payload types."""
        # Create tasks with different payload types
        data_movement_payload = DataMovementTaskPayload(
            source_type="postgresql",
            source_id="postgres_db",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="STAGE/file.parquet",
            statement_location_id="SELECT * FROM users",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        process_staged_payload = ProcessStagedDataTaskPayload(
            table_metadata_id=75,
            partition_metadata_id=150,
            partition_index=1,
            target_table="TARGET_TABLE",
        )

        tasks = [
            Task(
                id=1,
                workflow_id=self.workflow_id,
                task_name="Data Movement Task",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=data_movement_payload,
                scope="Table[MY_DB.MY_SCHEMA.USERS]::Extraction",
            ),
            Task(
                id=2,
                workflow_id=self.workflow_id,
                task_name="Process Staged Task",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=process_staged_payload,
                scope="Table[TARGET_TABLE]::Loading",
            ),
        ]

        # Mock task_queue.get_tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=tasks)

        # Call _get_unblocked_tasks
        result = await self.orchestrator._check_unblocked_tasks()

        # Verify both tasks are returned with correct types
        self.assertEqual(len(result), 2)
        self.assertIsInstance(result[0].payload, DataMovementTaskPayload)
        self.assertIsInstance(result[1].payload, ProcessStagedDataTaskPayload)


if __name__ == "__main__":
    unittest.main()
