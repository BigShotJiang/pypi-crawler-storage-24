"""Tests for PartitionStrategyHandler behavioral changes."""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_strategy_handler import (
    PartitionStrategyHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DeterminePartitionStrategyTaskPayload,
)

MODULE = "data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_strategy_handler"


def _make_handler() -> tuple[PartitionStrategyHandler, MagicMock, MagicMock]:
    mock_queue = MagicMock()
    mock_queue.push_task = AsyncMock(return_value=1)
    mock_queue.push_task_chain = AsyncMock(return_value=[1, 2])
    mock_queue.complete_task = AsyncMock()

    mock_warehouse = MagicMock()
    mock_warehouse.execute_sync_query = AsyncMock(return_value=[])

    handler = PartitionStrategyHandler(
        task_queue=mock_queue,
        warehouse_proxy=mock_warehouse,
    )
    return handler, mock_queue, mock_warehouse


def _make_task(payload: DeterminePartitionStrategyTaskPayload) -> Task:
    return Task(
        id=42,
        workflow_id=1,
        executor_type=ExecutorType.ORCHESTRATOR,
        task_name="test",
        payload=payload,
        scope="Table[db.public.big_table]::Preprocessing",
    )


def _make_payload(**overrides) -> DeterminePartitionStrategyTaskPayload:
    defaults = dict(
        database="db",
        schema="public",
        table_name="big_table",
        source_type="redshift",
        target_table="db.public.big_table",
        partition_column="id",
        table_metadata_id=100,
    )
    defaults.update(overrides)
    return DeterminePartitionStrategyTaskPayload(**defaults)


def _stub_table_config(sync_strategy=SyncStrategy.NONE):
    cfg = MagicMock()
    cfg.extraction_strategy = ExtractionStrategy.REGULAR
    cfg.synchronization.strategy = sync_strategy
    return cfg


class TestSchemaReadDeferred(unittest.IsolatedAsyncioTestCase):
    """Verify that read_schema_from_stage is only called on the single-partition path."""

    @patch(f"{MODULE}.read_metadata_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.read_schema_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.TableConfigurationService")
    @patch(f"{MODULE}.WorkflowConfigService")
    @patch(f"{MODULE}.SynchronizationConfigService")
    @patch(f"{MODULE}.WorkflowProgressService")
    async def test_schema_not_read_when_partitioned(
        self,
        _mock_progress,
        _mock_sync_config,
        _mock_workflow_config,
        mock_table_config,
        mock_read_schema,
        mock_read_metadata,
    ):
        mock_read_metadata.return_value = {
            "row_count": 500_000_000,
            "data_size_mb": 50_000,
        }

        mock_table_config.return_value.fetch_required_table_configuration = AsyncMock(
            return_value=_stub_table_config()
        )
        _mock_workflow_config.return_value.fetch_strategy_config = AsyncMock(
            return_value=None
        )

        handler, mock_queue, _ = _make_handler()
        task = _make_task(_make_payload())

        await handler.handle(task)

        mock_read_schema.assert_not_called()

    @patch(f"{MODULE}.TaskChainCreator")
    @patch(f"{MODULE}.read_metadata_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.read_schema_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.TableConfigurationService")
    @patch(f"{MODULE}.WorkflowConfigService")
    @patch(f"{MODULE}.SynchronizationConfigService")
    @patch(f"{MODULE}.WorkflowProgressService")
    async def test_schema_read_when_single_partition(
        self,
        mock_progress,
        mock_sync_config,
        mock_workflow_config,
        mock_table_config,
        mock_read_schema,
        mock_read_metadata,
        mock_chain_creator,
    ):
        mock_read_metadata.return_value = {"row_count": 100, "data_size_mb": 0.01}
        mock_read_schema.return_value = [{"column": "id", "type": "INT"}]

        mock_table_config.return_value.fetch_required_table_configuration = AsyncMock(
            return_value=_stub_table_config()
        )
        mock_workflow_config.return_value.fetch_strategy_config = AsyncMock(
            return_value=None
        )
        mock_progress.return_value.insert_partition_metadata = AsyncMock(return_value=1)
        mock_progress.return_value.update_table_preprocessed = AsyncMock()
        mock_sync_config.return_value.fetch_partition_sync_data = AsyncMock(
            return_value=None
        )

        creator_instance = MagicMock()
        creator_instance.build_task_chain_for_extraction_and_load = AsyncMock(
            return_value=[1, 2]
        )
        mock_chain_creator.return_value = creator_instance

        handler, _, _ = _make_handler()
        task = _make_task(_make_payload())

        await handler.handle(task)

        mock_read_schema.assert_called_once()


class TestRowCountPassedToQueryBuilder(unittest.IsolatedAsyncioTestCase):
    """Verify that row_count is forwarded when building the boundary query."""

    @patch(f"{MODULE}.read_metadata_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.read_schema_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.TableConfigurationService")
    @patch(f"{MODULE}.WorkflowConfigService")
    @patch(f"{MODULE}.SynchronizationConfigService")
    @patch(f"{MODULE}.WorkflowProgressService")
    @patch(f"{MODULE}.PlatformRegistry")
    async def test_row_count_forwarded_to_boundary_query(
        self,
        mock_registry,
        _mock_progress,
        _mock_sync_config,
        _mock_workflow_config,
        mock_table_config,
        _mock_read_schema,
        mock_read_metadata,
    ):
        row_count = 500_000_000
        mock_read_metadata.return_value = {
            "row_count": row_count,
            "data_size_mb": 50_000,
        }

        mock_table_config.return_value.fetch_required_table_configuration = AsyncMock(
            return_value=_stub_table_config()
        )
        _mock_workflow_config.return_value.fetch_strategy_config = AsyncMock(
            return_value=None
        )

        mock_builder = MagicMock()
        mock_builder.build_partition_boundary_query.return_value = "SELECT 1"
        mock_builder.build_use_database_command.return_value = None
        mock_platform = MagicMock()
        mock_platform.query_builder = mock_builder
        mock_platform.name = "redshift"
        mock_registry.create_by_name_or_alias.return_value = mock_platform

        handler, _, _ = _make_handler()
        task = _make_task(_make_payload())

        await handler.handle(task)

        mock_builder.build_partition_boundary_query.assert_called_once()
        _, kwargs = mock_builder.build_partition_boundary_query.call_args
        self.assertEqual(kwargs.get("row_count"), row_count)


class TestCreateTasksTaskIsBlocked(unittest.IsolatedAsyncioTestCase):
    """Verify that the CREATE_PARTITION_TASKS task is pushed in blocked state."""

    @patch(f"{MODULE}.read_metadata_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.read_schema_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.TableConfigurationService")
    @patch(f"{MODULE}.WorkflowConfigService")
    @patch(f"{MODULE}.SynchronizationConfigService")
    @patch(f"{MODULE}.WorkflowProgressService")
    @patch(f"{MODULE}.PlatformRegistry")
    async def test_create_tasks_pushed_as_blocked(
        self,
        mock_registry,
        _mock_progress,
        _mock_sync_config,
        _mock_workflow_config,
        mock_table_config,
        _mock_read_schema,
        mock_read_metadata,
    ):
        mock_read_metadata.return_value = {
            "row_count": 500_000_000,
            "data_size_mb": 50_000,
        }

        mock_table_config.return_value.fetch_required_table_configuration = AsyncMock(
            return_value=_stub_table_config()
        )
        _mock_workflow_config.return_value.fetch_strategy_config = AsyncMock(
            return_value=None
        )

        mock_builder = MagicMock()
        mock_builder.build_partition_boundary_query.return_value = "SELECT 1"
        mock_builder.build_use_database_command.return_value = None
        mock_platform = MagicMock()
        mock_platform.query_builder = mock_builder
        mock_platform.name = "redshift"
        mock_registry.create_by_name_or_alias.return_value = mock_platform

        handler, mock_queue, _ = _make_handler()
        task = _make_task(_make_payload())

        await handler.handle(task)

        first_push = mock_queue.push_task.call_args_list[0]
        pushed_task = first_push[0][0]
        self.assertTrue(pushed_task.is_blocked)


if __name__ == "__main__":
    unittest.main()
