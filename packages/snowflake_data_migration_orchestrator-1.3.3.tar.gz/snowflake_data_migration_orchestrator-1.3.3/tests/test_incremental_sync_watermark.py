"""
Tests for incremental sync with WATERMARK strategy.

Tests the watermark-based synchronization data models, serialization,
and query building for incremental data migration.
"""

import json
from datetime import datetime

# Import platforms to ensure registration
import data_migration_orchestrator.data_migration_cloud.platforms  # noqa: F401

from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms import PlatformRegistry
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    WatermarkSyncData,
    parse_sync_data,
)


class TestWatermarkSyncData:
    """Tests for WatermarkSyncData serialization and deserialization."""

    def test_to_json_without_candidate(self):
        """Test serialization without candidate value."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value="2026-01-15 10:30:00.000",
        )

        result = json.loads(sync_data.to_json())

        assert result["strategy"] == "watermark"
        assert result["watermark_column"] == "updated_at"
        assert result["max_watermark_value"] == "2026-01-15 10:30:00.000"
        assert "candidate_max_watermark_value" not in result

    def test_to_json_with_candidate(self):
        """Test serialization includes candidate when present."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value="2026-01-15 10:30:00.000",
            candidate_max_watermark_value="2026-01-16 14:00:00.000",
        )

        result = json.loads(sync_data.to_json())

        assert result["max_watermark_value"] == "2026-01-15 10:30:00.000"
        assert result["candidate_max_watermark_value"] == "2026-01-16 14:00:00.000"

    def test_to_json_with_datetime_object(self):
        """Test that datetime objects are serialized to ISO format."""
        dt = datetime(2026, 2, 12, 14, 42, 28, 997000)
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="timestamp",
            max_watermark_value=dt,
        )

        result = json.loads(sync_data.to_json())

        assert result["max_watermark_value"] == "2026-02-12T14:42:28.997000"

    def test_to_json_with_numeric_watermark(self):
        """Test serialization with numeric watermark value."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="id",
            max_watermark_value=12345,
        )

        result = json.loads(sync_data.to_json())

        assert result["max_watermark_value"] == 12345


class TestParseSyncData:
    """Tests for parse_sync_data function."""

    def test_parse_watermark_from_dict(self):
        """Test parsing watermark sync data from dict."""
        data = {
            "strategy": "watermark",
            "watermark_column": "updated_at",
            "max_watermark_value": "2026-01-15 10:30:00.000",
        }

        result = parse_sync_data(data)

        assert isinstance(result, WatermarkSyncData)
        assert result.strategy == SyncStrategy.WATERMARK
        assert result.watermark_column == "updated_at"
        assert result.max_watermark_value == "2026-01-15 10:30:00.000"

    def test_parse_watermark_from_json_string(self):
        """Test parsing watermark sync data from JSON string."""
        json_str = '{"strategy": "watermark", "watermark_column": "id", "max_watermark_value": 100}'

        result = parse_sync_data(json_str)

        assert isinstance(result, WatermarkSyncData)
        assert result.watermark_column == "id"
        assert result.max_watermark_value == 100

    def test_parse_watermark_with_candidate(self):
        """Test parsing includes candidate_max_watermark_value."""
        data = {
            "strategy": "watermark",
            "watermark_column": "updated_at",
            "max_watermark_value": "2026-01-15",
            "candidate_max_watermark_value": "2026-01-16",
        }

        result = parse_sync_data(data)

        assert result.max_watermark_value == "2026-01-15"
        assert result.candidate_max_watermark_value == "2026-01-16"

    def test_parse_none_returns_none(self):
        """Test that None input returns None."""
        assert parse_sync_data(None) is None

    def test_parse_empty_dict_returns_none(self):
        """Test that empty dict returns None."""
        assert parse_sync_data({}) is None


class TestBuildWhereClauseWithWatermark:
    """Tests for build_where_clause with watermark sync data."""

    def setup_method(self):
        """Set up query builders for testing."""
        self.sqlserver_builder = PlatformRegistry.create_by_name_or_alias(
            "sqlserver"
        ).query_builder
        self.redshift_builder = PlatformRegistry.create_by_name_or_alias(
            "redshift"
        ).query_builder

    def test_watermark_only(self):
        """Test WHERE clause with only watermark condition."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value="2026-01-15 10:30:00.000",
        )

        result = self.sqlserver_builder.build_where_clause(sync_data=sync_data)

        assert "[updated_at] >" in result
        assert "CONVERT(datetime2," in result

    def test_partition_and_watermark_combined(self):
        """Test WHERE clause combining partition boundary and watermark."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="modified_ts",
            max_watermark_value="2026-01-01",
        )
        partition_condition = "id >= 1 AND id < 1000"

        result = self.sqlserver_builder.build_where_clause(
            partition_condition=partition_condition,
            sync_data=sync_data,
        )

        assert "id >= 1 AND id < 1000" in result
        assert "[modified_ts] >" in result
        assert " AND " in result

    def test_no_watermark_value_no_condition(self):
        """Test that None watermark value doesn't add condition."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value=None,
        )

        result = self.sqlserver_builder.build_where_clause(sync_data=sync_data)

        assert result is None

    def test_numeric_watermark(self):
        """Test WHERE clause with numeric watermark."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="version",
            max_watermark_value=42,
        )

        result = self.redshift_builder.build_where_clause(sync_data=sync_data)

        assert '"version" > 42' in result


class TestBuildExtractionQueryWithWatermark:
    """Tests for full extraction query with watermark sync data."""

    def setup_method(self):
        """Set up query builder and schema for testing."""
        self.builder = PlatformRegistry.create_by_name_or_alias(
            "sqlserver"
        ).query_builder
        self.source_schema = [
            {"column_name": "id", "data_type": "int"},
            {"column_name": "name", "data_type": "varchar"},
            {"column_name": "updated_at", "data_type": "datetime2"},
        ]

    def test_extraction_query_with_watermark(self):
        """Test full extraction query includes watermark filter."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value="2026-02-01 00:00:00.000",
        )
        table_id = TableIdentifier(
            database_name="db", schema_name="schema", table_name="table"
        )

        query = self.builder.build_extraction_query(
            table_name=table_id,
            source_schema=self.source_schema,
            sync_data=sync_data,
        )

        assert "SELECT" in query
        assert "FROM" in query
        # SQL Server identifiers are normalized to uppercase
        assert "DB.SCHEMA.TABLE" in query
        assert "WHERE" in query
        assert "[updated_at] >" in query

    def test_extraction_query_with_partition_and_watermark(self):
        """Test extraction query with both partition and watermark."""
        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value="2026-01-01",
        )
        table_id = TableIdentifier(
            database_name="db", schema_name="schema", table_name="table"
        )

        query = self.builder.build_extraction_query(
            table_name=table_id,
            source_schema=self.source_schema,
            partition_condition="id >= 100 AND id < 200",
            sync_data=sync_data,
        )

        assert "id >= 100 AND id < 200" in query
        assert "[updated_at] >" in query

    def test_extraction_query_without_sync_data(self):
        """Test extraction query without sync data has no WHERE."""
        table_id = TableIdentifier(
            database_name="db", schema_name="schema", table_name="table"
        )

        query = self.builder.build_extraction_query(
            table_name=table_id,
            source_schema=self.source_schema,
        )

        assert "SELECT" in query
        assert "WHERE" not in query
