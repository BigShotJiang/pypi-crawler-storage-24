"""Unit tests for workflow configuration schema validation."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
)
from data_migration_orchestrator.data_migration_cloud.config.workflow_configuration_schema import (
    WorkflowConfigurationSchema,
    validate_workflow_configuration,
)


def _minimal_table_config() -> dict:
    return {
        "source": {
            "databaseName": "source_db",
            "schemaName": "dbo",
            "tableName": "customers",
        },
        "target": {
            "databaseName": "target_db",
            "schemaName": "public",
            "tableName": "customers",
        },
        "columnNamesToPartitionBy": ["id"],
    }


class TestValidateWorkflowConfiguration:
    """Tests for the standalone validate_workflow_configuration function."""

    def test_valid_minimal_configuration(self):
        config = {"tables": [_minimal_table_config()]}

        result = validate_workflow_configuration(config)

        assert isinstance(result, WorkflowConfigurationSchema)
        assert len(result.tables) == 1

    def test_valid_with_affinity(self):
        config = {
            "tables": [_minimal_table_config()],
            "affinity": "blue",
        }

        result = validate_workflow_configuration(config)

        assert result.affinity == "blue"

    def test_valid_without_affinity(self):
        config = {"tables": [_minimal_table_config()]}

        result = validate_workflow_configuration(config)

        assert result.affinity is None

    def test_valid_multiple_tables(self):
        table1 = _minimal_table_config()
        table2 = _minimal_table_config()
        table2["source"]["tableName"] = "orders"
        config = {"tables": [table1, table2]}

        result = validate_workflow_configuration(config)

        assert len(result.tables) == 2

    def test_valid_with_default_table_configuration(self):
        config = {
            "defaultTableConfiguration": {
                "source": {"databaseName": "shared_db", "schemaName": "dbo"},
                "target": {"databaseName": "target_db", "schemaName": "public"},
            },
            "tables": [
                {
                    "source": {"tableName": "customers"},
                    "target": {"tableName": "customers"},
                    "columnNamesToPartitionBy": ["id"],
                },
            ],
        }

        result = validate_workflow_configuration(config)

        assert result.default_table_configuration is not None
        assert result.default_table_configuration.source is not None
        assert result.default_table_configuration.source.database_name == "shared_db"

    def test_valid_full_configuration(self):
        config = {
            "defaultTableConfiguration": {
                "extraction": {"strategy": "unload", "externalStage": "@MY_STAGE"},
            },
            "tables": [
                {
                    "source": {
                        "databaseName": "src",
                        "schemaName": "dbo",
                        "tableName": "orders",
                    },
                    "target": {
                        "databaseName": "tgt",
                        "schemaName": "public",
                        "tableName": "orders",
                    },
                    "columnNamesToPartitionBy": ["order_id"],
                    "columnTypeMappings": [
                        {"sourceType": "MONEY", "targetType": "DECIMAL(19,4)"},
                    ],
                    "columnNameMappings": [
                        {"sourceName": "id", "targetName": "old_id"},
                    ],
                    "primaryKeyColumns": ["order_id"],
                    "synchronization": {
                        "strategy": "watermark",
                        "watermarkColumn": "updated_at",
                        "trackModifications": True,
                    },
                    "extraction": {"strategy": "regular"},
                    "whereClauseCriteria": "is_deleted = 0",
                },
            ],
        }

        result = validate_workflow_configuration(config)

        table = result.tables[0]
        assert table.synchronization is not None
        assert table.synchronization.strategy == "watermark"
        assert table.where_clause_criteria == "is_deleted = 0"

    def test_returns_validated_model(self):
        config = {"tables": [_minimal_table_config()]}

        result = validate_workflow_configuration(config)

        assert isinstance(result, WorkflowConfigurationSchema)
        assert result.tables[0].source is not None
        assert result.tables[0].source.table_name == "customers"


class TestValidateWorkflowConfigurationErrors:
    """Tests for invalid configurations that should raise ConfigurationError."""

    def test_none_configuration_raises_error(self):
        with pytest.raises(ConfigurationError, match="must not be None"):
            validate_workflow_configuration(None)

    def test_missing_tables_key_raises_error(self):
        with pytest.raises(ConfigurationError, match="tables"):
            validate_workflow_configuration({})

    def test_empty_tables_list_raises_error(self):
        with pytest.raises(ConfigurationError, match="at least one"):
            validate_workflow_configuration({"tables": []})

    def test_tables_wrong_type_string_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": "not_a_list"})

    def test_tables_wrong_type_int_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": 42})

    def test_default_table_configuration_wrong_type_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration(
                {
                    "tables": [_minimal_table_config()],
                    "defaultTableConfiguration": "not_a_dict",
                }
            )

    def test_unknown_top_level_key_raises_error(self):
        with pytest.raises(ConfigurationError, match="extra_field"):
            validate_workflow_configuration(
                {
                    "tables": [_minimal_table_config()],
                    "extra_field": "should_fail",
                }
            )

    def test_unknown_key_in_table_raises_error(self):
        table = _minimal_table_config()
        table["unknownProperty"] = "bad"

        with pytest.raises(ConfigurationError, match="unknownProperty"):
            validate_workflow_configuration({"tables": [table]})

    def test_unknown_key_in_source_raises_error(self):
        table = _minimal_table_config()
        table["source"]["extraField"] = "bad"

        with pytest.raises(ConfigurationError, match="extraField"):
            validate_workflow_configuration({"tables": [table]})

    def test_unknown_key_in_synchronization_raises_error(self):
        table = _minimal_table_config()
        table["synchronization"] = {"strategy": "none", "badKey": True}

        with pytest.raises(ConfigurationError, match="badKey"):
            validate_workflow_configuration({"tables": [table]})

    def test_unknown_key_in_extraction_raises_error(self):
        table = _minimal_table_config()
        table["extraction"] = {"strategy": "regular", "badKey": "x"}

        with pytest.raises(ConfigurationError, match="badKey"):
            validate_workflow_configuration({"tables": [table]})

    def test_partition_columns_wrong_type_string_raises_error(self):
        table = _minimal_table_config()
        table["columnNamesToPartitionBy"] = "not_a_list"

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_partition_columns_wrong_element_type_raises_error(self):
        table = _minimal_table_config()
        table["columnNamesToPartitionBy"] = [123]

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_column_type_mappings_wrong_type_raises_error(self):
        table = _minimal_table_config()
        table["columnTypeMappings"] = "not_a_list"

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_column_type_mapping_missing_field_raises_error(self):
        table = _minimal_table_config()
        table["columnTypeMappings"] = [{"sourceType": "BIT"}]

        with pytest.raises(ConfigurationError, match="targetType"):
            validate_workflow_configuration({"tables": [table]})

    def test_column_name_mapping_missing_field_raises_error(self):
        table = _minimal_table_config()
        table["columnNameMappings"] = [{"sourceName": "id"}]

        with pytest.raises(ConfigurationError, match="targetName"):
            validate_workflow_configuration({"tables": [table]})

    def test_primary_key_columns_wrong_type_raises_error(self):
        table = _minimal_table_config()
        table["primaryKeyColumns"] = "not_a_list"

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_where_clause_criteria_wrong_type_raises_error(self):
        table = _minimal_table_config()
        table["whereClauseCriteria"] = 42

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_track_modifications_wrong_type_raises_error(self):
        table = _minimal_table_config()
        table["synchronization"] = {
            "strategy": "watermark",
            "trackModifications": "not_a_bool",
        }

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_table_entry_is_list_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [["not", "a", "dict"]]})

    def test_table_entry_is_string_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": ["not_a_dict"]})


class TestWorkflowConfigurationSchemaDirectly:
    """Tests for the Pydantic model directly (not through the wrapper function)."""

    def test_model_validate_valid(self):
        config = {"tables": [_minimal_table_config()]}
        model = WorkflowConfigurationSchema.model_validate(config)
        assert len(model.tables) == 1

    def test_model_rejects_extra_fields(self):
        config = {
            "tables": [_minimal_table_config()],
            "extraField": "value",
        }
        with pytest.raises(ValueError, match="extraField"):
            WorkflowConfigurationSchema.model_validate(config)


# TODO: Use constants for the keys (also in other tests)
