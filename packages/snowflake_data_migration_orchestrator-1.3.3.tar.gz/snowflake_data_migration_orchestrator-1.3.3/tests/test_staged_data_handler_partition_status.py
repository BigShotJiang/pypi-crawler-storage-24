"""
Tests for StagedDataHandler partition status methods.

This module tests the partition metadata status update methods
in the StagedDataHandler, specifically the _update_partition_status method
and the creation of CompletePartitionMigrationTask as successor.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from shared.enums.file_type import FileType
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler import (
    StagedDataHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.partition_migration_status import (
    PartitionMigrationStatus,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CompletePartitionMigrationTaskPayload,
    ProcessStagedDataTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus


class TestStagedDataHandlerPartitionStatus(unittest.TestCase):
    """Test cases for StagedDataHandler partition status methods."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=1)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    def test_handler_initialization(self):
        """Test handler initializes with correct task type."""
        self.assertEqual(self.handler.task_type, TaskPayloadKind.PROCESS_STAGED_DATA)


class TestUpdatePartitionStatus(unittest.IsolatedAsyncioTestCase):
    """Test cases for _update_partition_status method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    async def test_update_partition_status_to_loading(self):
        """Test updating partition status to LOADING."""
        await self.handler._update_partition_status(
            partition_metadata_id=123,
            status=PartitionMigrationStatus.LOADING,
        )

        self.mock_warehouse_proxy.execute_sync_query.assert_called_once()
        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]

        self.assertIn("UPDATE SNOWCONVERT_AI.DATA_MIGRATION.PARTITION_METADATA", query)
        self.assertIn("MIGRATION_STATUS = 'LOADING'", query)
        self.assertIn("WHERE ID = 123", query)

    async def test_update_partition_status_includes_timestamp(self):
        """Test that status update includes timestamp update."""
        await self.handler._update_partition_status(
            partition_metadata_id=456,
            status=PartitionMigrationStatus.COMPLETED,
        )

        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]

        self.assertIn("MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP()", query)

    async def test_update_partition_status_with_valid_id(self):
        """Test that update is executed when partition_metadata_id is valid."""
        await self.handler._update_partition_status(
            partition_metadata_id=100,
            status=PartitionMigrationStatus.LOADING,
        )

        self.mock_warehouse_proxy.execute_sync_query.assert_called_once()

    async def test_update_partition_status_skips_when_warehouse_proxy_is_none(self):
        """Test that update is skipped when warehouse_proxy is None."""
        handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=None,
        )

        await handler._update_partition_status(
            partition_metadata_id=100,
            status=PartitionMigrationStatus.LOADING,
        )
        # Should not raise

    async def test_update_partition_status_handles_error_gracefully(self):
        """Test that errors are handled gracefully (logged but not raised)."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=Exception("Database error")
        )

        # Should not raise - errors are logged but not propagated
        await self.handler._update_partition_status(
            partition_metadata_id=100,
            status=PartitionMigrationStatus.LOADING,
        )

    async def test_update_partition_status_with_different_statuses(self):
        """Test update with different status values."""
        statuses = [
            PartitionMigrationStatus.EXTRACTING,
            PartitionMigrationStatus.LOADING,
            PartitionMigrationStatus.COMPLETED,
            PartitionMigrationStatus.FAILED,
        ]

        for status in statuses:
            self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])
            await self.handler._update_partition_status(
                partition_metadata_id=100,
                status=status,
            )

            call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
            query = call_args[0][0]
            self.assertIn(f"MIGRATION_STATUS = '{status}'", query)

    async def test_update_partition_status_with_different_ids(self):
        """Test update with various partition metadata IDs."""
        for partition_id in [1, 100, 999999]:
            self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])
            await self.handler._update_partition_status(
                partition_metadata_id=partition_id,
                status=PartitionMigrationStatus.LOADING,
            )

            call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
            query = call_args[0][0]
            self.assertIn(f"WHERE ID = {partition_id}", query)


class TestStagedDataHandlerCreatesSuccessorTask(unittest.IsolatedAsyncioTestCase):
    """Test cases for StagedDataHandler creating CompletePartitionMigrationTask."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=999)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            return_value=[
                {"COLUMN_NAME": "ID", "TYPE": "INTEGER"},
                {"COLUMN_NAME": "NAME", "TYPE": "VARCHAR"},
            ]
        )
        self.mock_warehouse_proxy.execute_snowflake_query_and_push_task = AsyncMock(
            return_value=None
        )

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.resolve_stage_for_strategy"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.read_schema_from_stage"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.SchemaValidator"
    )
    async def test_creates_successor_task_when_partition_metadata_id_present(
        self, mock_schema_validator, mock_read_schema, mock_resolve_stage
    ):
        """Test that CompletePartitionMigrationTask is created when partition_metadata_id is set."""
        # Setup mocks for table config and workflow config services
        mock_table_config = MagicMock()
        mock_table_config.extraction_strategy = MagicMock()
        mock_table_config.extraction_strategy.value = "regular"
        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=mock_table_config)
        )
        self.handler.workflow_config_service.fetch_strategy_config = AsyncMock(
            return_value={}
        )

        # Mock stage resolution
        mock_stage_resolution = MagicMock()
        mock_stage_resolution.is_external = False
        mock_stage_resolution.stage_id = "@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS"
        mock_resolve_stage.return_value = mock_stage_resolution

        # Setup mocks
        mock_read_schema.return_value = [
            {"COLUMN_NAME": "ID", "DATA_TYPE": "int"},
            {"COLUMN_NAME": "NAME", "DATA_TYPE": "varchar"},
        ]

        mock_validator_instance = MagicMock()
        mock_validator_instance.validate_schema = AsyncMock(
            return_value=MagicMock(
                table_exists=True,
                has_drift=False,
                drifts=[],
            )
        )
        mock_validator_instance.get_columns_for_copy_into = MagicMock(
            return_value=[("ID", "NUMBER"), ("NAME", "VARCHAR")]
        )
        mock_schema_validator.return_value = mock_validator_instance

        # Mock file type detection and schema inference
        self.handler._detect_stage_file_type = AsyncMock(return_value=FileType.PARQUET)
        self.handler._infer_file_schema = AsyncMock(
            return_value={"ID": "NUMBER", "NAME": "TEXT"}
        )

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=123,
            partition_index=1,
            target_table="DB.SCHEMA.TABLE",
        )

        task = Task(
            id=1,
            workflow_id=100,
            task_name="Process staged data",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[1]::Loading",
        )

        await self.handler.handle(task)

        # Verify push_task was called for the successor task
        # The implementation passes a Task object as a positional argument
        push_task_calls = [
            call
            for call in self.mock_task_queue.push_task.call_args_list
            if call.args
            and hasattr(call.args[0], "payload")
            and isinstance(call.args[0].payload, CompletePartitionMigrationTaskPayload)
        ]

        self.assertEqual(len(push_task_calls), 1)
        successor_task = push_task_calls[0].args[0]
        self.assertEqual(successor_task.payload.partition_metadata_id, 123)

    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.resolve_stage_for_strategy"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.read_schema_from_stage"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.SchemaValidator"
    )
    async def test_no_successor_task_when_partition_metadata_id_is_none(
        self, mock_schema_validator, mock_read_schema, mock_resolve_stage
    ):
        """Test that no successor task is created when partition_metadata_id is None."""
        # Setup mocks for table config and workflow config services
        mock_table_config = MagicMock()
        mock_table_config.extraction_strategy = MagicMock()
        mock_table_config.extraction_strategy.value = "regular"
        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=mock_table_config)
        )
        self.handler.workflow_config_service.fetch_strategy_config = AsyncMock(
            return_value={}
        )

        # Mock stage resolution
        mock_stage_resolution = MagicMock()
        mock_stage_resolution.is_external = False
        mock_stage_resolution.stage_id = "@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS"
        mock_resolve_stage.return_value = mock_stage_resolution

        # Setup mocks
        mock_read_schema.return_value = [
            {"COLUMN_NAME": "ID", "DATA_TYPE": "int"},
        ]

        mock_validator_instance = MagicMock()
        mock_validator_instance.validate_schema = AsyncMock(
            return_value=MagicMock(
                table_exists=True,
                has_drift=False,
                drifts=[],
            )
        )
        mock_validator_instance.get_columns_for_copy_into = MagicMock(
            return_value=[("ID", "NUMBER")]
        )
        mock_schema_validator.return_value = mock_validator_instance

        # Mock file type detection and schema inference
        self.handler._detect_stage_file_type = AsyncMock(return_value=FileType.PARQUET)
        self.handler._infer_file_schema = AsyncMock(return_value={"ID": "NUMBER"})

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=0,
            partition_index=0,
            target_table="DB.SCHEMA.TABLE",
        )

        task = Task(
            id=1,
            workflow_id=100,
            task_name="Process staged data",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[0]::Loading",
        )

        await self.handler.handle(task)

        # Verify CompletePartitionMigrationTaskPayload was still pushed
        # (partition_metadata_id is now always required, so successor task is always created)
        push_task_calls = [
            call
            for call in self.mock_task_queue.push_task.call_args_list
            if call.args
            and hasattr(call.args[0], "payload")
            and isinstance(call.args[0].payload, CompletePartitionMigrationTaskPayload)
        ]

        # With the new API, partition_metadata_id is always required,
        # so a successor task is always created
        self.assertEqual(len(push_task_calls), 1)


class TestEmptyExtractionHandling(unittest.IsolatedAsyncioTestCase):
    """Test that StagedDataHandler handles empty extractions (0 rows) gracefully."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=999)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.resolve_stage_for_strategy"
    )
    async def test_empty_extraction_marks_partition_completed(self, mock_resolve_stage):
        """When no staged files are found, partition should be marked COMPLETED."""
        mock_table_config = MagicMock()
        mock_table_config.extraction_strategy = MagicMock()
        mock_table_config.extraction_strategy.value = "regular"
        mock_table_config.extraction = MagicMock()
        mock_table_config.extraction.external_stage = None
        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=mock_table_config)
        )
        self.handler.workflow_config_service.fetch_strategy_config = AsyncMock(
            return_value={}
        )
        self.handler.workflow_config_service.fetch_workflow_external_stage = AsyncMock(
            return_value=None
        )

        mock_stage_resolution = MagicMock()
        mock_stage_resolution.is_external = False
        mock_stage_resolution.stage_id = "@SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS"
        mock_resolve_stage.return_value = mock_stage_resolution

        # Simulate _detect_stage_file_type raising ValueError (no files found)
        self.handler._detect_stage_file_type = AsyncMock(
            side_effect=ValueError("No files found at @stage/path/")
        )

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=42,
            partition_index=0,
            target_table="DB.SCHEMA.TABLE",
        )

        task = Task(
            id=1,
            workflow_id=100,
            task_name="Process staged data",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[0]::Loading",
        )

        await self.handler.handle(task)

        # Partition status should be updated to COMPLETED
        status_update_calls = [
            call
            for call in self.mock_warehouse_proxy.execute_sync_query.call_args_list
            if "MIGRATION_STATUS = 'COMPLETED'" in str(call)
            and "WHERE ID = 42" in str(call)
        ]
        self.assertEqual(len(status_update_calls), 1)

        # Task should be completed
        self.mock_task_queue.complete_task.assert_called_once_with(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=1,
        )

        # No COPY INTO or successor tasks should be created
        self.mock_task_queue.push_task.assert_not_called()
        self.mock_warehouse_proxy.execute_snowflake_query_and_push_task = AsyncMock()
        self.mock_warehouse_proxy.execute_snowflake_query_and_push_task.assert_not_called()


class TestProcessStagedDataTaskPayloadPartitionMetadataId(unittest.TestCase):
    """Test cases for ProcessStagedDataTaskPayload with partition_metadata_id."""

    def test_payload_with_partition_metadata_id(self):
        """Test creating payload with partition_metadata_id."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=42,
            partition_index=1,
            target_table="DB.SCHEMA.TABLE",
        )

        self.assertEqual(payload.partition_metadata_id, 42)
        self.assertEqual(payload.kind, TaskPayloadKind.PROCESS_STAGED_DATA)

    def test_payload_with_all_fields(self):
        """Test creating payload with all fields."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=789,
            partition_index=5,
            target_table="DB.SCHEMA.TABLE",
        )

        self.assertEqual(payload.table_metadata_id, 100)
        self.assertEqual(payload.partition_metadata_id, 789)
        self.assertEqual(payload.partition_index, 5)
        self.assertEqual(payload.target_table, "DB.SCHEMA.TABLE")
        self.assertEqual(payload.kind, TaskPayloadKind.PROCESS_STAGED_DATA)


if __name__ == "__main__":
    unittest.main()
