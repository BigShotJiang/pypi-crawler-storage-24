import json
import unittest

from data_migration_orchestrator.cloud_core.tasks.constants.task_columns import (
    ID,
    NAME,
    PAYLOAD,
    PRIORITY,
    SCOPE,
    STATUS,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DataMovementTaskPayload,
    ProcessStagedDataTaskPayload,
    TargetType,
)
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)


def mock_payload_mapper(kind: str, payload_dict: dict):
    """Mock payload mapper for testing."""
    from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
        TaskPayloadKind,
    )

    if kind == TaskPayloadKind.DATA_MOVEMENT:
        return DataMovementTaskPayload(
            **{k: v for k, v in payload_dict.items() if k != "kind"}
        )
    elif kind == TaskPayloadKind.PROCESS_STAGED_DATA:
        return ProcessStagedDataTaskPayload(
            **{k: v for k, v in payload_dict.items() if k != "kind"}
        )
    return payload_dict


class ConcreteTaskQueue(BaseTaskQueue):
    """Concrete implementation of BaseTaskQueue for testing purposes."""

    def __init__(self, payload_mapper=None):
        super().__init__(payload_mapper or mock_payload_mapper)

    async def _push_task_internal(
        self,
        workflow_id: str,
        executor_type: ExecutorType,
        task_name: str,
        payload: object,
        priority: int = 3,
        successor_task_id: int | None = None,
        is_blocked: bool = False,
    ) -> int | None:
        """Push a task."""
        pass

    async def check_tasks(self, workflow_id: str, task_ids: list[int]) -> list[Task]:
        """Check tasks."""
        pass

    async def complete_task(self, consumer_type: ExecutorType, task_id: int) -> bool:
        """Complete a task."""
        pass

    async def unblock_tasks(self):
        """Unblock tasks."""
        pass

    async def expire_leases(self):
        """Expire leases."""
        pass

    async def refresh_warehouse_tasks(self):
        """Refresh warehouse tasks."""
        pass

    async def get_tasks(self) -> list[Task]:
        """Get tasks."""
        pass

    async def has_workflow_started(self, workflow_id: str) -> bool:
        """Check if a workflow has started."""
        pass

    async def get_pending_workflows(self):
        """Get pending workflows."""
        pass

    async def complete_workflows(self):
        """Complete a workflow."""
        pass

    async def fail_task(
        self, consumer_id: str, task_id: int, error_message: str
    ) -> bool:
        """Fail a task."""
        pass


class TestBaseTaskQueue(unittest.TestCase):
    """
    Test suite for the BaseTaskQueue class.

    This test class validates the helper methods in the BaseTaskQueue
    abstract base class.
    """

    def setUp(self):
        """Set up test fixtures before each test method."""
        self.task_queue = ConcreteTaskQueue()

    def test_map_task_with_tuple(self):
        """Test _map_task method with tuple input (positional access)."""
        # Create a mock payload
        payload = DataMovementTaskPayload(
            source_type="sql-server",
            source_id="test_db",
            target_type="snowflake:table",
            target_id="MY_DB.MY_SCHEMA.MY_TABLE",
            statement_location_id="SELECT * FROM table",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        # Create a tuple row (id, name, executor_type, status, priority, payload, scope)
        row = (123, "Test Task", "orchestrator", "pending", 3, payload, "test_scope")
        workflow_id = "test_workflow"

        # Map the task
        task = self.task_queue._map_task(row, workflow_id)

        # Assertions
        self.assertIsInstance(task, Task)
        self.assertEqual(task.id, 123)
        self.assertEqual(task.workflow_id, workflow_id)
        self.assertEqual(task.task_name, "Test Task")
        self.assertEqual(task.executor_type, ExecutorType.ORCHESTRATOR)
        self.assertEqual(task.status, TaskStatus.PENDING)
        self.assertEqual(task.priority, 3)
        self.assertEqual(task.payload, payload)
        self.assertEqual(task.scope, "test_scope")

    def test_map_task_with_different_status(self):
        """Test _map_task method with different task statuses."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=200,
            partition_index=1,
            target_table="MY_DB.MY_SCHEMA.MY_TABLE",
        )

        statuses = [
            ("pending", TaskStatus.PENDING),
            ("executing", TaskStatus.EXECUTING),
            ("completed", TaskStatus.COMPLETED),
            ("failed", TaskStatus.FAILED),
            ("abandoned", TaskStatus.ABANDONED),
            ("blocked", TaskStatus.BLOCKED),
        ]

        workflow_id = 42
        for status_str, expected_status in statuses:
            row = (
                456,
                "Test Task",
                "orchestrator",
                status_str,
                2,
                payload,
                "test_scope",
            )
            task = self.task_queue._map_task(row, workflow_id)

            self.assertEqual(task.status, expected_status)
            self.assertEqual(task.id, 456)

    def test_map_task_by_column_name_with_dict(self):
        """Test _map_task_by_column_name method with dictionary input."""
        workflow_id = 1
        payload = DataMovementTaskPayload(
            source_type="teradata",
            source_id="teradata_db",
            target_type=TargetType.S3_UNLOAD.value,
            target_id="MY_DB.MY_SCHEMA.MY_STAGE/file.parquet",
            database="MY_DB",
            schema="MY_SCHEMA",
            statement_location_type="snowflake:stage",
            statement_location_id="MY_DB.MY_SCHEMA.MY_STAGE/query.sql",
        )

        # Create a dictionary row with column names
        row = {
            ID: 789,
            NAME: "Test Task",
            PRIORITY: 3,
            STATUS: "executing",
            PAYLOAD: json.dumps(payload.__dict__),
            "WORKFLOW_ID": workflow_id,
            SCOPE: "test_scope",
        }

        # Map the task
        task = self.task_queue._map_task_by_column_name(
            row, executor_type=ExecutorType.ORCHESTRATOR
        )

        # Assertions
        self.assertIsNotNone(task)
        self.assertIsInstance(task, Task)
        self.assertEqual(task.id, 789)
        self.assertEqual(task.status, TaskStatus.EXECUTING)
        self.assertEqual(task.payload.source_type, payload.source_type)

    def test_map_task_by_column_name_with_different_payloads(self):
        """Test _map_task_by_column_name with different payload types."""
        workflow_id = 1
        payloads = [
            DataMovementTaskPayload(
                source_type="redshift",
                source_id="redshift_db",
                target_type="snowflake:table",
                target_id="MY_DB.MY_SCHEMA.MY_TABLE",
                statement_location_id="SELECT 1",
                database="MY_DB",
                schema="MY_SCHEMA",
            ),
            ProcessStagedDataTaskPayload(
                table_metadata_id=50,
                partition_metadata_id=100,
                partition_index=0,
                target_table="TARGET_TABLE",
            ),
        ]

        for idx, payload in enumerate(payloads):
            row = {
                ID: idx + 1,
                NAME: f"Task {idx + 1}",
                PRIORITY: 3,
                STATUS: "completed",
                PAYLOAD: json.dumps(payload.__dict__),
                "WORKFLOW_ID": workflow_id,
                SCOPE: "test_scope",
            }

            task = self.task_queue._map_task_by_column_name(
                row, executor_type=ExecutorType.ORCHESTRATOR
            )

            self.assertIsNotNone(task)
            self.assertEqual(task.id, idx + 1)
            self.assertEqual(task.status, TaskStatus.COMPLETED)
            self.assertEqual(task.payload.kind, payload.kind)

    def test_map_task_by_column_name_preserves_task_structure(self):
        """Test that _map_task_by_column_name creates proper Task objects."""
        workflow_id = 1
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=75,
            partition_metadata_id=150,
            partition_index=2,
            target_table="test_target",
        )

        row = {
            ID: 999,
            NAME: "Test Task",
            PRIORITY: 3,
            STATUS: "failed",
            PAYLOAD: json.dumps(payload.__dict__),
            "WORKFLOW_ID": workflow_id,
            SCOPE: "test_scope",
        }

        task = self.task_queue._map_task_by_column_name(
            row, executor_type=ExecutorType.ORCHESTRATOR
        )

        # Verify task structure
        self.assertIsNotNone(task)
        self.assertTrue(hasattr(task, "id"))
        self.assertTrue(hasattr(task, "status"))
        self.assertTrue(hasattr(task, "payload"))
        self.assertTrue(hasattr(task, "successor_task_id"))
        self.assertTrue(hasattr(task, "scope"))

        # Verify default values
        self.assertIsNone(task.successor_task_id)
        self.assertEqual(task.scope, "test_scope")

    def test_map_task_consistency(self):
        """Test that both mapping methods produce equivalent results."""
        payload = DataMovementTaskPayload(
            source_type="mysql",
            source_id="mysql_db",
            target_type="snowflake:table",
            target_id="TARGET",
            statement_location_id="SELECT * FROM users",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        task_id = 555
        task_name = "Test Comparison Task"
        executor_type = "orchestrator"
        status_str = "pending"
        priority = 2
        workflow_id = 1

        # Map using tuple method
        tuple_row = (
            task_id,
            task_name,
            executor_type,
            status_str,
            priority,
            payload,
            "test_scope",
        )
        task_from_tuple = self.task_queue._map_task(tuple_row, workflow_id)

        # Map using dictionary method
        dict_row = {
            ID: task_id,
            NAME: task_name,
            PRIORITY: priority,
            STATUS: status_str,
            PAYLOAD: json.dumps(payload.__dict__),
            "WORKFLOW_ID": workflow_id,
            SCOPE: "test_scope",
        }
        task_from_dict = self.task_queue._map_task_by_column_name(
            dict_row, ExecutorType.ORCHESTRATOR
        )

        # Both should produce equivalent tasks
        self.assertEqual(task_from_tuple.id, task_from_dict.id)
        self.assertEqual(task_from_tuple.workflow_id, workflow_id)
        self.assertEqual(task_from_dict.workflow_id, workflow_id)
        self.assertEqual(task_from_tuple.task_name, task_from_dict.task_name)
        self.assertEqual(task_from_tuple.executor_type, task_from_dict.executor_type)
        self.assertEqual(task_from_tuple.status, task_from_dict.status)
        self.assertEqual(task_from_tuple.priority, task_from_dict.priority)
        self.assertEqual(task_from_tuple.scope, task_from_dict.scope)


if __name__ == "__main__":
    unittest.main()
