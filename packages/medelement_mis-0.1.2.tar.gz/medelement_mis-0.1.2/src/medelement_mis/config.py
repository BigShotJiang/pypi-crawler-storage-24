"""Configuration for Medelement MIS SDK."""

from enum import StrEnum

from pydantic_settings import BaseSettings, SettingsConfigDict

# Constants
BASE_URL = "https://api3.medelement.com"
DEFAULT_TIMEOUT = 10.0
DEFAULT_RETRIES = 3
DEFAULT_RETRY_BACKOFF = 0.5


class Environment(StrEnum):
    """API environment."""

    SANDBOX = "sandbox"
    PRODUCTION = "production"


class MedelementConfig(BaseSettings):
    """Configuration loaded from environment variables.

    Environment variables (prefix: MEDELEMENT_):
        - MEDELEMENT_ENVIRONMENT: "sandbox" or "production" (default: production)
        - MEDELEMENT_BASE_URL: API base URL (default: https://api3.medelement.com)
        - MEDELEMENT_USER_ID: User ID for Basic auth (required)
        - MEDELEMENT_PASSWORD: Password for Basic auth (required)
        - MEDELEMENT_INTEGRATOR_KEY: X-Integrator-Key header value (required)
        - MEDELEMENT_TIMEOUT: Request timeout in seconds (default: 10.0)
        - MEDELEMENT_RETRIES: Retry attempts for retryable requests (default: 3)
        - MEDELEMENT_RETRY_BACKOFF: Base backoff in seconds between retries (default: 0.5)

    Usage:
        config = MedelementConfig()  # loads from env
        client = MedelementClient(config=config)
    """

    model_config = SettingsConfigDict(
        env_prefix="MEDELEMENT_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    environment: Environment = Environment.PRODUCTION
    base_url: str = BASE_URL
    user_id: str
    password: str
    integrator_key: str
    timeout: float = DEFAULT_TIMEOUT
    retries: int = DEFAULT_RETRIES
    retry_backoff: float = DEFAULT_RETRY_BACKOFF
