"""Public interface for the Medelement MIS SDK."""

from importlib.metadata import PackageNotFoundError, version

from .catalogs import CONCESSIONS, SOCIAL_STATUSES
from .client import MedelementClient
from .config import BASE_URL, DEFAULT_TIMEOUT, Environment, MedelementConfig
from .exceptions import APIError, AuthenticationError, MedelementError, NotFoundError, ValidationError
from .models import (
    ActiveStatus,
    ColorCode,
    Gender,
    NomenclatureType,
)

try:
    __version__ = version("medelement-mis")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "__version__",
    "MedelementClient",
    "MedelementConfig",
    "Environment",
    "BASE_URL",
    "DEFAULT_TIMEOUT",
    "MedelementError",
    "AuthenticationError",
    "ValidationError",
    "APIError",
    "NotFoundError",
    "Gender",
    "ColorCode",
    "ActiveStatus",
    "NomenclatureType",
    "SOCIAL_STATUSES",
    "CONCESSIONS",
]
