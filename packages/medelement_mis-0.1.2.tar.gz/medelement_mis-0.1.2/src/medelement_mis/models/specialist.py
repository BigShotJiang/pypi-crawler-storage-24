"""Specialist models for Medelement MIS API."""

from typing import Optional

from pydantic import Field, RootModel

from .base import MedelementBaseModel


class Cabinet(MedelementBaseModel):
    """Cabinet/room information for a specialist.

    Cabinets represent physical locations where specialists work.
    """

    company_cabinet_code: int = Field(..., alias="companyCabinetCode")
    cabinet_name: str = Field(..., alias="cabinetName")
    cabinet_type: int = Field(..., alias="cabinetType")
    cabinet_number: Optional[str] = Field(None, alias="cabinetNumber")


class Specialist(MedelementBaseModel):
    """Specialist/doctor information.

    GET https://api3.medelement.com/v1/timetable/get_specialists
    """

    specialist_code: int = Field(..., alias="specialistCode")
    is_schedule_published: int = Field(
        ..., alias="isSchedulePublished", description="0=No, 1=Yes"
    )
    user_name: str = Field(..., alias="userName")
    reception_time: int = Field(
        ..., alias="receptionTime", description="Standard reception duration in minutes"
    )
    cabinets: list[Cabinet] = Field(default_factory=list)

    @property
    def has_published_schedule(self) -> bool:
        """Check if specialist has a published schedule."""
        return self.is_schedule_published == 1


class SpecialistsDict(RootModel[dict[str, Specialist]]):
    """Dictionary of specialists keyed by specialist code string.

    API returns: {"652154781487571870": {specialist_data}, ...}
    """

    def __iter__(self):
        return iter(self.root)

    def __getitem__(self, key: str) -> Specialist:
        return self.root[key]

    def __len__(self) -> int:
        return len(self.root)

    def values(self):
        return self.root.values()

    def keys(self):
        return self.root.keys()

    def items(self):
        return self.root.items()
