"""Pydantic models for Medelement MIS API."""

# Base models and enums
from .base import (
    ActiveStatus,
    ColorCode,
    Gender,
    MedelementBaseModel,
    NomenclatureType,
    PhoneArray,
    RemovedStatus,
    validate_date_format,
    validate_datetime_format,
)

# Nomenclature models
from .nomenclature import (
    GetNomenclaturesRequest,
    GetNomenclaturesResponse,
    Nomenclature,
)

# Patient models
from .patient import (
    CreatePatientRequest,
    CreatePatientResponse,
    PatientDetail,
    SearchPatientItem,
    SearchPatientRequest,
    SearchPatientResponse,
    UpdatePatientRequest,
    UpdatePatientResponse,
)

# Reception models
from .reception import (
    CreateReceptionRequest,
    CreateReceptionResponse,
    DeleteReceptionRequest,
    GetReceptionsRequest,
    GetReceptionsResponse,
    ReceptionDetail,
    ReceptionListItem,
    RescheduleReceptionRequest,
    SearchReceptionItem,
    SearchReceptionPDItem,
    SearchReceptionPDRequest,
    SearchReceptionPDResponse,
    SearchReceptionRequest,
    SearchReceptionResponse,
)

# Specialist models
from .specialist import (
    Cabinet,
    Specialist,
    SpecialistsDict,
)

# Timetable models
from .timetable import (
    ClinicWorkingHours,
    DaySchedule,
    GetTimetableRequest,
    SpecialistSchedule,
    SpecialistWorkingHours,
    TimeOff,
    TimetableResponse,
    TimetableSlot,
)

__all__ = [
    # Base
    "MedelementBaseModel",
    "Gender",
    "ColorCode",
    "ActiveStatus",
    "RemovedStatus",
    "NomenclatureType",
    "PhoneArray",
    "validate_date_format",
    "validate_datetime_format",
    # Patient
    "CreatePatientRequest",
    "CreatePatientResponse",
    "PatientDetail",
    "SearchPatientRequest",
    "SearchPatientItem",
    "SearchPatientResponse",
    "UpdatePatientRequest",
    "UpdatePatientResponse",
    # Specialist
    "Cabinet",
    "Specialist",
    "SpecialistsDict",
    # Reception
    "CreateReceptionRequest",
    "CreateReceptionResponse",
    "ReceptionDetail",
    "ReceptionListItem",
    "GetReceptionsRequest",
    "GetReceptionsResponse",
    "DeleteReceptionRequest",
    "RescheduleReceptionRequest",
    "SearchReceptionRequest",
    "SearchReceptionItem",
    "SearchReceptionResponse",
    "SearchReceptionPDRequest",
    "SearchReceptionPDItem",
    "SearchReceptionPDResponse",
    # Timetable
    "GetTimetableRequest",
    "TimetableSlot",
    "ClinicWorkingHours",
    "TimeOff",
    "SpecialistWorkingHours",
    "SpecialistSchedule",
    "DaySchedule",
    "TimetableResponse",
    # Nomenclature
    "GetNomenclaturesRequest",
    "Nomenclature",
    "GetNomenclaturesResponse",
]
