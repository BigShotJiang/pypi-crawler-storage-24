"""API resources for Medelement MIS."""

from .nomenclatures import NomenclaturesAPI
from .patients import PatientsAPI
from .receptions import ReceptionsAPI
from .specialists import SpecialistsAPI
from .timetable import TimetableAPI

__all__ = [
    "NomenclaturesAPI",
    "PatientsAPI",
    "ReceptionsAPI",
    "SpecialistsAPI",
    "TimetableAPI",
]
