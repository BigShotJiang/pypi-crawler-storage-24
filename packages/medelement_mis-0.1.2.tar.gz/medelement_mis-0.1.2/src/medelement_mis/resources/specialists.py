"""Specialists API resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from medelement_mis.models import SpecialistsDict

if TYPE_CHECKING:
    from medelement_mis.client import MedelementClient


class SpecialistsAPI:
    """API resource for specialist operations."""

    def __init__(self, client: MedelementClient) -> None:
        self._client = client

    def list(self) -> SpecialistsDict:
        """Get list of all specialists.

        GET /v1/timetable/get_specialists

        Returns:
            SpecialistsDict containing specialists keyed by specialist code
        """
        response = self._client._request("GET", "/v1/timetable/get_specialists")
        self._client._raise_for_status(response)

        return SpecialistsDict.model_validate(response.json())
