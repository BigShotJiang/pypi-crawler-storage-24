"""Timetable API resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from medelement_mis.models import GetReceptionsRequest, GetReceptionsResponse, TimetableResponse

if TYPE_CHECKING:
    from medelement_mis.client import MedelementClient


class TimetableAPI:
    """API resource for timetable/schedule operations."""

    def __init__(self, client: MedelementClient) -> None:
        self._client = client

    def get_timetable(
        self,
        dates: list[str],
        specialist_code: int,
    ) -> TimetableResponse:
        """Get specialist timetable for specified dates.

        GET /v1/timetable/get_timetable

        Args:
            dates: Array of dates in dd.mm.yyyy format
            specialist_code: Specialist code

        Returns:
            TimetableResponse containing schedule for each requested date
        """
        params: dict = {
            "date[]": dates,
            "specialistCode": specialist_code,
        }

        response = self._client._request("GET", "/v1/timetable/get_timetable", params=params)
        self._client._raise_for_status(response)

        return TimetableResponse.model_validate(response.json())

    def get_specialist_receptions(
        self,
        *,
        specialist_code: int,
        begin_datetime: str,
        end_datetime: str,
        company_cabinet_code: int | None = None,
        skip: int | None = None,
    ) -> GetReceptionsResponse:
        """Get specialist's receptions for a given period.

        POST /v1/timetable/get_receptions_short
        Returns up to 1000 records per request.

        Args:
            specialist_code: Specialist code (required)
            begin_datetime: Period start datetime (required)
            end_datetime: Period end datetime (required)
            company_cabinet_code: Filter by cabinet
            skip: Pagination offset

        Returns:
            GetReceptionsResponse with list of receptions
        """
        request = GetReceptionsRequest(
            specialistCode=specialist_code,
            beginDatetime=begin_datetime,
            endDatetime=end_datetime,
            companyCabinetCode=company_cabinet_code,
            skip=skip,
        )

        response = self._client._request(
            "POST",
            "/v1/timetable/get_receptions_short",
            json=request.model_dump(by_alias=True, exclude_none=True),
        )
        self._client._raise_for_status(response)

        return GetReceptionsResponse.model_validate(response.json())
