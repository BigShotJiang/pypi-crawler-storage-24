"""Reference catalogs documented by Medelement API docs."""

from types import MappingProxyType

# Documented in docs/api/social_status.md
SOCIAL_STATUSES = MappingProxyType(
    {
        1: "Employee",
        2: "Worker",
        3: "Agricultural worker",
        4: "Pensioner",
        5: "Student",
        6: "Housewife",
        7: "Self-employed",
        8: "Clergy",
        9: "Unemployed",
        10: "Other",
        11: "Company employee",
        12: "Family member",
    }
)

# Documented in docs/api/concessions.md
CONCESSIONS = MappingProxyType(
    {
        1: "Not specified",
        2: "WWII participant",
        3: "Internationalist warrior",
        4: "Disabled since childhood",
        5: "Disabled due to illness",
        6: "Radiation exposed person",
        7: "Equivalent to WWII participant",
        8: "Conscript",
        9: "Labor disability",
        10: "Relocated person",
        11: "Equivalent to WWII participant (family of fallen service members)",
        12: "Equivalent to WWII participant (rehabilitated victims of political repression)",
        13: "Semipalatinsk radiation exposed",
        14: "Chernobyl radiation exposed",
        15: "No category",
        99: "Other",
    }
)

__all__ = [
    "SOCIAL_STATUSES",
    "CONCESSIONS",
]
