"""Browse the clinic service catalogue (nomenclatures)."""

from medelement_mis.client import MedelementClient
from medelement_mis.config import MedelementConfig

config = MedelementConfig(
    user_id="d4eaa832f927e761627b31dc965d7702",
    password="608b982d8518f",
    integrator_key="bp_mUkTd",
    base_url="https://api3.medelement.com",
)

client = MedelementClient(config=config)

# List all nomenclatures (first page)
services = client.nomenclatures.list()
print(f"Services (first page): {len(services)}")
for svc in services:
    print(f"  [{svc.nomenclature_code}] {svc.nomenclature_name}")

# Filter by category
by_category = client.nomenclatures.list(category_code=162289911723442467)
print(f"\nCategory 162289911723442467 services: {len(by_category)}")

# Search by keyword
found = client.nomenclatures.list(q="анализ")
print(f"\nSearch 'анализ': {len(found)} results")
for svc in found:
    print(f"  [{svc.nomenclature_code}] {svc.nomenclature_name}")

# Paginate
page2 = client.nomenclatures.list(skip=100)
print(f"\nPage 2 (skip=100): {len(page2)} services")
