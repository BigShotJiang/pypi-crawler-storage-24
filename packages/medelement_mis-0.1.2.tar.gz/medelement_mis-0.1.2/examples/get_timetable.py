"""Fetch specialist timetable and scheduled receptions."""

from medelement_mis.client import MedelementClient
from medelement_mis.config import MedelementConfig

config = MedelementConfig()
client = MedelementClient(config=config)

SPECIALIST_CODE = 456
CABINET_CODE = 789

# Get working schedule for a specialist over several days
schedule = client.timetable.get_timetable(
    dates=["15.06.2025", "16.06.2025", "17.06.2025"],
    specialist_code=SPECIALIST_CODE,
)
print(f"Schedule for specialist {SPECIALIST_CODE}:")
for date, day in schedule.root.items():
    print(f"  {date}: {day}")

# Get all booked receptions for the specialist in a cabinet
receptions = client.timetable.get_specialist_receptions(
    specialist_code=SPECIALIST_CODE,
    begin_datetime="15.06.2025 00:00",
    end_datetime="15.06.2025 23:59",
    company_cabinet_code=CABINET_CODE,
)
print(f"\nBooked slots on 15.06.2025: {len(receptions.receptions)}")
for r in receptions.receptions:
    print(f"  [{r.reception_code}] patient={r.patient_code}  {r.starttime} — {r.endtime}  active={r.active}")
