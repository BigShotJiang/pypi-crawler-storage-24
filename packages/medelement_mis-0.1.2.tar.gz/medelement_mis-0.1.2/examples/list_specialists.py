"""List all specialists and their cabinets."""

from medelement_mis.client import MedelementClient
from medelement_mis.config import MedelementConfig

config = MedelementConfig()
client = MedelementClient(config=config)

specialists = client.specialists.list()

print(f"Total specialists: {len(specialists)}")
for code, specialist in specialists.items():
    cabinets = ", ".join(str(c.company_cabinet_code) for c in specialist.cabinets)
    print(f"  [{code}] {specialist.user_name}  cabinets=[{cabinets}]")
