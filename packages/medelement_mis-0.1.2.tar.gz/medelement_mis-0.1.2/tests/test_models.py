import pytest

from medelement_mis.models import GetReceptionsRequest, SearchPatientRequest


def test_search_patient_request_validates_date_format():
    with pytest.raises(ValueError, match="dd.mm.yyyy"):
        SearchPatientRequest(lastname="Ivanov", birthday="2025-01-01")


def test_get_receptions_request_serializes_with_api_aliases():
    request = GetReceptionsRequest(
        specialistCode=123,
        beginDatetime="01.01.2025 09:00",
        endDatetime="01.01.2025 10:00",
        companyCabinetCode=456,
        skip=10,
    )

    assert request.model_dump(by_alias=True, exclude_none=True) == {
        "specialistCode": 123,
        "beginDatetime": "01.01.2025 09:00",
        "endDatetime": "01.01.2025 10:00",
        "companyCabinetCode": 456,
        "skip": 10,
    }
