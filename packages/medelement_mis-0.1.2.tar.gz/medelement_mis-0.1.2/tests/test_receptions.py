from medelement_mis.models import (
    GetReceptionsResponse,
    SearchReceptionPDResponse,
    SearchReceptionResponse,
)


def test_reception_responses_accept_wrapped_payloads():
    payload = {
        "receptions": [
            {
                "RECEPTION_CODE": 1,
                "PATIENT_CODE": 2,
                "STARTTIME": "2018-08-22 09:43:11",
                "ENDTIME": "2018-08-22 09:43:11",
                "ACTIVE": 1,
                "REMOVED": 0,
            }
        ]
    }

    assert len(GetReceptionsResponse.model_validate(payload).receptions) == 1
    assert len(SearchReceptionResponse.model_validate(payload).receptions) == 1


def test_reception_responses_accept_direct_list_payloads():
    payload = [
        {
            "RECEPTION_CODE": 1,
            "PATIENT_CODE": 2,
            "STARTTIME": "2018-08-22 09:43:11",
            "ENDTIME": "2018-08-22 09:43:11",
            "ACTIVE": 1,
            "REMOVED": 0,
            "SPECIALIST_CODE": 3,
            "SPECIALIST_FULLNAME": "Ivan Ivanov",
            "CABINET_TYPE_NAME": "Therapist",
            "DEPARTMENT_CODE": 4,
        }
    ]

    assert len(GetReceptionsResponse.model_validate(payload).receptions) == 1
    assert len(SearchReceptionResponse.model_validate(payload).receptions) == 1
    assert len(SearchReceptionPDResponse.model_validate(payload).receptions) == 1
