import medelement_mis as mm
from collections.abc import Mapping
from medelement_mis.client import MedelementClient


def test_top_level_public_exports():
    assert mm.MedelementClient is MedelementClient
    assert isinstance(mm.SOCIAL_STATUSES, Mapping)
    assert isinstance(mm.CONCESSIONS, Mapping)
    assert 11 in mm.SOCIAL_STATUSES
    assert 15 in mm.CONCESSIONS


def test_all_documented_methods_exist():
    client = MedelementClient(
        base_url="https://api3.medelement.com",
        user_id="user",
        password="pass",
        integrator_key="key",
    )

    assert hasattr(client.patients, "create")
    assert hasattr(client.patients, "update")
    assert hasattr(client.patients, "get")
    assert hasattr(client.patients, "search")

    assert hasattr(client.receptions, "create")
    assert hasattr(client.receptions, "search")
    assert hasattr(client.receptions, "search_pd")
    assert hasattr(client.receptions, "remove")
    assert hasattr(client.receptions, "get")
    assert hasattr(client.receptions, "reschedule")

    assert hasattr(client.specialists, "list")
    assert hasattr(client.timetable, "get_timetable")
    assert hasattr(client.timetable, "get_specialist_receptions")
    assert hasattr(client.nomenclatures, "list")
