# Поиск приема

**POST**: `https://api3.medelement.com/v2/doctor/reception/search`

## Параметры:

| Название         | Тип     | Описание                            |
| ---------------- | ------- | ----------------------------------- |
| patient_code     | Bigint  | Код пациента                        |
| begin_datetime\* | String  | Дата начала приема                  |
| end_datetime\*   | String  | Дата окончания приема               |
| active           | Integer | Статус приема (0-закрыт, 1- открыт) |
| removed          | Integer | Прием удален                        |
| paid             | Integer | Прием оплачен                       |
| skip             | Integer | Пропустить строк                    |
| only_ambulator   | Integer | Получить только амбулаторные приемы |

\* Обязательные параметры

## Ответ:

HTTP/1.1 200 OK

```json
{
    "receptions": [
        {
            "RECEPTION_CODE": 548262341534909391,
            "PATIENT_CODE": 112946961558007465,
            "STARTTIME": "2018-08-22 09:43:11",
            "ENDTIME": "2018-08-22 09:43:11",
            "ACTIVE": 1,
            "REMOVED": 0,
            "PAID": null,
            "RECCOUNT": 1
        }
    ]
}
```
