# Поиск приема

**POST**: `https://api3.medelement.com/v3/doctor/reception/search_pd`

## Параметры:

| Название       | Тип     | Описание                                        |
| -------------- | ------- | ----------------------------------------------- |
| patient_code   | Bigint  | Код пациента                                    |
| begin_datetime | String  | Дата начала приема от (dd.mm.yyyy → 12.02.2021) |
| end_datetime   | String  | Дата начала приема до (dd.mm.yyyy → 12.02.2021) |
| active         | Integer | Статус приема (0-закрыт, 1- открыт)             |
| removed        | Integer | Прием удален                                    |
| paid           | Integer | Прием оплачен                                   |
| skip           | Integer | Пропустить строк                                |

## Ответ:

HTTP/1.1 200 OK

```json
{
    "receptions": [
        {
            "RECEPTION_CODE": "116756051548649887",
            "PATIENT_CODE": "112946961558007465",
            "STARTTIME": "2019-01-27 22:31:27",
            "ENDTIME": "2019-01-27 22:31:27",
            "ACTIVE": 0,
            "REMOVED": 0,
            "PAID": null,
            "RECCOUNT": 1473,
            "NOTIFY": null,
            "SPECIALIST_CODE": 652154781487571870,
            "SPECIALIST_FULLNAME": "Иванов Иван Иванович",
            "CABINET_TYPE_NAME": "Терапевт",
            "DEPARTMENT_CODE": 325913071604646080
        }
    ]
}
```
