# Поиск пациента

**GET**: `https://api3.medelement.com/doctor/v2/patients`

Для запроса требуется минимум 1 параметр с данными пациента. В ответе всегда будет не более 100 записей с возможностью смещения через skip.

## Параметры:

| Название            | Тип      | Описание                            |
| ------------------- | -------- | ----------------------------------- |
| patient_code        | Bigint[] | Уникальные коды пациентов           |
| email               | String[] | Список адресов электронной почты    |
| iin                 | String   | Список ИИН-ов                       |
| name                | String   | Имя                                 |
| lastname            | String   | Фамилия                             |
| middlename          | String   | Отчество                            |
| gender              | Integer  | Пол (1 - женский, 2 - мужской)      |
| birthday            | String   | Дата рождения (дд.мм.гггг)          |
| patient_phone_2[0]  | Integer  | Код страны (7 или 998)              |
| patient_phone_2[1]  | Integer  | Код города (777)                    |
| patient_phone_2[2]  | Integer  | Номер (1231212)                     |
| skip                | Integer  | Какое количество записей пропустить |
| patient_status_code | Bigint   | Статус пациента                     |

## Ответ:

HTTP/1.1 200 OK

```json
[
  {
    "profile_code": "123456789321654",
    "parent_code": "123456789321654",
    "name": "John"
    "lastname": "Golt",
    "middlename": "Senior",
    "fullname": "Golt John Senior",
    "birthday": "01.01.1971",
    "gender": 2,
    "iin": "710101123456",
    "ambulatory_count": "123456789321654",
    "created_date": "2017-10-31 09:42:12",
    "removed": 0,
    "removed_date": null,
    "removed_reason": null,
    "description": "Some text",
    "status_code": "Some text",
    "percentage_discount": 0,
    "patient_passport": null,
    "patient_phone_1": null,
    "patient_phone_2": null,
    "patient_phone_3": null,
    "patient_phone_4": null,
    "phones_str": null,
    "patient_address": null,
    "patient_email": "hello@example.com",
    "patient_card_number": null
  }
]
```
