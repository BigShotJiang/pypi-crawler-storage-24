# Номенклатура услуг компании

**GET**: `https://api3.medelement.com/v1/doctor/nomenclatures`

## Параметры:

| Название      | Тип     | Описание                      |
| ------------- | ------- | ----------------------------- |
| category_code | Bigint  | Идентификатор категории       |
| skip          | Integer | Пропустить записей (смещение) |
| q             | Bigint  | Строка поиска                 |

## Ответ:

HTTP/1.1 200 OK

```json
[
  {
    "NOMENCLATURE_CODE": "30791821435136102",
    "NOMENCLATURE_NAME": "Gardnerella vaginalis Ig M",
    "NOMENCLATURE_TYPE_CODE": 5,
    "IS_GROUP": 0,
    "RECCOUNT": 18,
    "PARENT_CODE": 745269181414848239,
    "PARENT_NAME": "Лаборатория",
    "NESTING_LEVEL": 2,
    "PRICE": 1500,
    "UNIT_NAME": "исследование"
  },
  {...}
]
```

## Описание полей ответа:

| Название               | Тип     | Описание                        |
| ---------------------- | ------- | ------------------------------- |
| NOMENCLATURE_CODE      | Bigint  | Уникальный идентификатор услуги |
| NOMENCLATURE_NAME      | String  | Название услуги                 |
| NOMENCLATURE_TYPE_CODE | Integer | Тип номенклатуры                |
| IS_GROUP               | Integer | Маркер категории                |
| RECCOUNT               | Integer | Общее количество услуг          |
| PARENT_CODE            | Integer | Уникальный код категории        |
| PARENT_NAME            | String  | Название категории              |
| NESTING_LEVEL          | Integer | Уровень вложенности в дереве    |
| PRICE                  | Double  | Стоимость услуги                |
| UNIT_NAME              | String  | Название единицы измерения      |
