# Создание пациента

**POST**: `https://api3.medelement.com/doctor/v1/patient`

## Параметры:

| Название           | Тип    | Описание                                                                |
| ------------------ | ------ | ----------------------------------------------------------------------- |
| company_code       | BigInt | Уникальный код клиники (учитывается, если есть глобальный доступ к API) |
| name\*             | String | Имя                                                                     |
| lastname\*         | String | Фамилия                                                                 |
| middlename         | String | Отчество                                                                |
| patient_email      | String | Электронная почта                                                       |
| birthday           | String | Дата рождения (дд.мм.гггг)                                              |
| gender             | Number | Пол (1 - женский; 2 - мужской)                                          |
| patient_phone_2[0] | String | Код страны                                                              |
| patient_phone_2[1] | String | Код города                                                              |
| patient_phone_2[2] | String | Номер                                                                   |
| iin                | String | ИИН                                                                     |
| source_code        | Bigint | Источник информации о клинике                                           |

\* обязательный параметр

## Ответ:

HTTP/1.1 201 OK

```json
{
    "profile_code": "123456789321654",
    "name": "John",
    "lastname": "Golt",
    "middlename": "Senior",
    "patient_email": "hello@example.com",
    "birthday": "01.01.1971",
    "gender": 2,
    "patient_phone_2": "+7-X-777-X-1231212",
    "iin": "",
    "source_code": 1
}
```

## Описание полей ответа:

| Название           | Тип    | Описание                       |
| ------------------ | ------ | ------------------------------ |
| profile_code       | Bigint | Уникальный код пациента        |
| name               | String | Имя                            |
| lastname           | String | Фамилия                        |
| middlename         | String | Отчество                       |
| patient_email      | String | Электронная почта              |
| birthday           | String | Дата рождения                  |
| gender             | Number | Пол (1 - женский; 2 - мужской) |
| patient_phone_2[0] | String | Код страны                     |
| patient_phone_2[1] | String | Код города                     |
| patient_phone_2[2] | String | Номер                          |
| iin                | String | ИИН                            |
| source_code        | Number | Источника информации о клинике |
