# Данные пациента

**GET**: `https://api3.medelement.com/doctor/v1/patient/:patient_code`

## Параметры:

| Название     | Тип    | Описание               |
| ------------ | ------ | ---------------------- |
| patient_code | Bigint | Идентификатор пациента |

## Ответ:

HTTP/1.1 200 OK

```json
{
    "PROFILE_CODE": "724674951660749664",
    "NAME": "Test",
    "LASTNAME": "Test",
    "MIDDLENAME": "Test",
    "BIRTHDAY": "12.12.1987",
    "GENDER": 1,
    "IIN": "840111300111",
    "REMOVED": 0,
    "PATIENT_CARD_NUMBER": null,
    "PERCENTAGE_DISCOUNT": 0,
    "PATIENT_PASSPORT": null,
    "PATIENT_PHONE_1": null,
    "PATIENT_PHONE_2": null,
    "PATIENT_PHONE_3": null,
    "PATIENT_PHONE_4": null,
    "PATIENT_ADDRESS": null,
    "PATIENT_EMAIL": "test@gmail.com",
    "DEATH_DATE": null,
    "REGION": null,
    "LIVING": null,
    "LIVING_CODE": null,
    "LIVING_TYPE": null,
    "ORGANIZATION": null,
    "DEPARTMENT": null,
    "SPECIALTY": null,
    "BAD_TYPE": null,
    "SOURCE_CODE": 0,
    "NATIONALITY": null,
    "MARITAL_STATUS": null,
    "SOCIAL_STATUS": null,
    "BENEFIT": null,
    "CHANGES_IN_MARITAL_STATUS": null,
    "CONTRACT": null,
    "BLOOD_GROUP": null,
    "RH_FACTOR": null,
    "RW": null,
    "HIV": null,
    "ADDITIONAL_CONTACT_INFO": null,
    "PATIENT_AMBULATORY_COUNT": "724674951660749664",
    "PATIENT_STATUS_CODE": null,
    "DOCTOR_CODE": null,
    "EDUCATION": null,
    "ORALMAN": 0,
    "SOCDISGROUP": 0,
    "WH_NOTIFICATION": null,
    "MSNGR_LANGUAGE": null,
    "PROFILE_LASTNAME": "Test",
    "PROFILE_NAME": "Test",
    "PROFILE_MIDDLENAME": "Test",
    "FULLNAME": "Test Test Test",
    "PATIENT_PHONE_1_STR": "",
    "PATIENT_PHONE_2_STR": "",
    "PATIENT_PHONE_3_STR": "",
    "PATIENT_PHONE_4_STR": "",
    "PHONES_STR": "",
    "STATUS_NAME": "",
    "BLOOD_GROUP_STR": "",
    "RH_FACTOR_STR": "",
    "FULL_ADDRESS": "",
    "is_woman": true,
    "GENDER_NAME": "Женский",
    "DOCTOR_NAME": "",
    "DOCTOR_FULLNAME": "",
    "ATTACHMENT_ORGANIZATION_NAME": ""
}
```
