# Получить приём

**GET**: `https://api3.medelement.com/v1/doctor/reception/:reception_code`

## Параметры:

| Название       | Тип    | Описание             |
| -------------- | ------ | -------------------- |
| reception_code | Bigint | Идентификатор приёма |

## Ответ:

HTTP/1.1 200 OK

```json
{
    "RECEPTION_CODE": "899043231643030805",
    "PROFILE_CODE": "200226541636371294",
    "STARTTIME": "27.01.2022 09:30",
    "ENDTIME": "27.01.2022 09:45",
    "ACTIVE": 1,
    "REMOVED": 0,
    "COMPANY_CODE": "772444821619761147"
}
```

## Описание полей ответа:

| Название       | Тип    | Описание                  |
| -------------- | ------ | ------------------------- |
| RECEPTION_CODE | Bigint | Идентификатор приёма      |
| PROFILE_CODE   | Bigint | Идентификатор пациента    |
| STARTTIME      | String | Начало приёма             |
| ENDTIME        | String | Завершение приёма         |
| ACTIVE         | Number | Если 0, то приём закрыт   |
| REMOVED        | Number | Удалён приём или нет      |
| COMPANY_CODE   | Bigint | Идентификатор организации |
