# Приемы специалиста

**POST**: `https://api3.medelement.com/v1/timetable/get_receptions_short`

Возвращает список приемов специалиста в кабинете за указанный период по 1000 записей в запросе

## Параметры:

| Название           | Тип     | Описание              |
| ------------------ | ------- | --------------------- |
| companyCabinetCode | Bigint  | Код кабинета          |
| specialistCode\*   | Bigint  | Код специалиста       |
| beginDatetime\*    | String  | Дата начала приема    |
| endDatetime\*      | String  | Дата окончания приема |
| skip               | Integer | Пропустить строк      |

\* Обязательные параметры

## Ответ:

HTTP/1.1 200 OK

```json
{
    "receptions": [
        {
            "RECEPTION_CODE": 548262341534909391,
            "PATIENT_CODE": 112946961558007465,
            "STARTTIME": "2018-08-22 09:43:11",
            "ENDTIME": "2018-08-22 09:43:11",
            "ACTIVE": 1,
            "REMOVED": 0,
            "PAID": null,
            "RECCOUNT": 1
        }
    ]
}
```
