# Список специалистов

**GET**: `https://api3.medelement.com/v1/timetable/get_specialists`

## Ответ:

HTTP/1.1 200 OK
{
"652154781487571870": {
"specialistCode": 652154781487571870,
"isSchedulePublished": 1,
"userName": "Иванов Иван",
"receptionTime": 90,
"cabinets": [
{
"companyCabinetCode": "221413041487572153",
"cabinetName": "Регистратура",
"cabinetType": 13301397711791,
"cabinetNumber": ""
},
{
"companyCabinetCode": "708803341488189364",
"cabinetName": "Терапевт( кб. №200 )",
"cabinetType": 63961403254475,
"cabinetNumber": "200"
},
]
}
}

## Описание полей ответа:

| Название            | Тип              | Описание                           |
| ------------------- | ---------------- | ---------------------------------- |
| specialistCode      | Bigint           | Код специалиста                    |
| isSchedulePublished | Boolean          | Статус опубликования графика работ |
| userName            | String           | Имя специалиста                    |
| receptionTime       | Integer          | Продолжительность приема           |
| cabinets            | Array of Objects | Кабинеты специалиста               |

### Объект кабинет:

| Название           | Тип    | Описание          |
| ------------------ | ------ | ----------------- |
| companyCabinetCode | Bigint | Код кабинета      |
| cabinetName        | String | Название кабинета |
| cabinetType        | Bigint | Тип кабинета      |
| cabinetNumber      | String | Номер кабинета    |
