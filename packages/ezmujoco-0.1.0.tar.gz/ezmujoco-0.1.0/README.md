# ezmujoco

`ezmujoco` is a lightweight utility library for building and manipulating MuJoCo scenes in Python.
It provides small, practical abstractions around `Scene`, `World`, and `Robot` so you can compose objects from XML, manage robot models, and work with poses, mocap bodies, cameras, and simple simulation workflows with less boilerplate.

## Development

```bash
uv sync --dev
uv run pytest -q
```
