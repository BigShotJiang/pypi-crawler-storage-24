from pathlib import Path
from yourdfpy import URDF as URDFInfo
from yourdfpy import filename_handler_magic
from functools import partial
import mujoco
import numpy as np
from ezpose import SE3, SO3


def get_urdf(urdf_path) -> URDFInfo:
    urdf_path = Path(urdf_path)
    urdf = URDFInfo.load(
        urdf_path,
        filename_handler=partial(filename_handler_magic, dir=urdf_path.parent),
    )
    return urdf





def attach_z_rx_ry_joint_in_handspec(
    hand_spec,
    # kp_trans=2000, kv_trans=200, kp_rot=1000, kv_rot=100
):
    hand_root_body = hand_spec.worldbody.bodies[0]

    # hand_root_body.add_joint(
    #     name="base_joint_z",
    #     type=mujoco.mjtJoint.mjJNT_SLIDE,  # 슬라이더 타입
    #     axis=[0.0, 0.0, 1.0],  # X축 방향으로 이동
    #     pos=[0.0, 0.0, 0.0],  # joint 기준점
    #     range=[-0.5, 0.5],  # 이동 범위 [m]
    #     damping=100.0,  # 감쇠 계수 (optional)
    #     stiffness=0,
    #     armature=0.2,
    # )
    # hand_spec.add_actuator(
    #     name="base_joint_z",
    #     target="base_joint_z",
    #     trntype=mujoco.mjtTrn.mjTRN_JOINT,  # joint 직접 제어
    #     gaintype=mujoco.mjtGain.mjGAIN_AFFINE,
    #     gainprm=[kp_trans, kv_trans] + [0.0] * 8,  # kp=100, kv=10
    #     biastype=mujoco.mjtBias.mjBIAS_AFFINE,
    #     biasprm=[0.0, -kp_trans] + [0.0] * 8,  # -kp*q
    #     ctrllimited=True,
    #     ctrlrange=[-0.5, 0.5],
    # )
    # hand_root_body.add_joint(
    #     name="base_joint_rx",
    #     type=mujoco.mjtJoint.mjJNT_HINGE,  # 슬라이더 타입
    #     axis=[1.0, 0.0, 0.0],  # X축 방향으로 이동
    #     pos=[0.0, 0.0, 0.0],  # joint 기준점
    #     range=[-np.pi / 2, np.pi / 2],  # 이동 범위 [m]
    #     damping=10.0,  # 감쇠 계수 (optional)
    #     stiffness=0,
    #     armature=0.02,
    # )
    # hand_spec.add_actuator(
    #     name="base_joint_rx",
    #     target="base_joint_rx",
    #     trntype=mujoco.mjtTrn.mjTRN_JOINT,  # joint 직접 제어
    #     gaintype=mujoco.mjtGain.mjGAIN_AFFINE,
    #     gainprm=[kp_rot, kv_rot] + [0.0] * 8,  # kp=100, kv=10
    #     biastype=mujoco.mjtBias.mjBIAS_AFFINE,
    #     biasprm=[0.0, -kp_rot] + [0.0] * 8,  # -kp*q
    #     ctrllimited=True,
    #     ctrlrange=[-np.pi / 2, np.pi / 2],
    # )
    # hand_root_body.add_joint(
    #     name="base_joint_ry",
    #     type=mujoco.mjtJoint.mjJNT_HINGE,  # 슬라이더 타입
    #     axis=[0.0, 1.0, 0.0],  # X축 방향으로 이동
    #     pos=[0.0, 0.0, 0.0],  # joint 기준점
    #     range=[-np.pi / 2, np.pi / 2],  # 이동 범위 [m]
    #     damping=10.0,  # 감쇠 계수 (optional)
    #     stiffness=0,
    #     armature=0.02,
    # )
    # hand_spec.add_actuator(
    #     name="base_joint_ry",
    #     target="base_joint_ry",
    #     trntype=mujoco.mjtTrn.mjTRN_JOINT,  # joint 직접 제어
    #     gaintype=mujoco.mjtGain.mjGAIN_AFFINE,
    #     gainprm=[kp_rot, kv_rot] + [0.0] * 8,  # kp=100, kv=10
    #     biastype=mujoco.mjtBias.mjBIAS_AFFINE,
    #     biasprm=[0.0, -kp_rot] + [0.0] * 8,  # -kp*q
    #     ctrllimited=True,
    #     ctrlrange=[-np.pi / 2, np.pi / 2],
    # )
    return hand_spec
