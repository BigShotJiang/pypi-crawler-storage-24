from __future__ import annotations

from dataclasses import dataclass

import mujoco
import numpy as np
from ezpose import SE3, SO3

from .world import World


# ARENA_GROUND_XML = """
#     <mujoco>
#     <size memory="32M"/>
#     <visual>
#         <headlight diffuse="0.6 0.6 0.6" ambient="0.3 0.3 0.3" specular="0 0 0"/>
#         <rgba haze="0.15 0.25 0.35 1"/>
#         <global azimuth="120" elevation="-20"/>
#     </visual>

#     <asset>
#         <texture type="skybox" builtin="gradient" rgb1="0.3 0.5 0.7" rgb2="0 0 0" width="512" height="3072"/>
#         <texture type="2d" name="groundplane" builtin="checker" mark="edge" rgb1="0.2 0.3 0.4" rgb2="0.1 0.2 0.3" markrgb="0.8 0.8 0.8" width="300" height="300"/>
#         <material name="groundplane" texture="groundplane" texuniform="true" texrepeat="5 5" reflectance="0.2"/>
#     </asset>

#     <worldbody>
#         <light pos="0 0 1.5" dir="0 0 -1" directional="true"/>
#         <geom name="floor" size="5 5 0.01" type="plane" material="groundplane"/>
#     </worldbody>
#     </mujoco>
# """

ARENA_GROUND_XML = """
    <mujoco>
    <size memory="32M"/>

    <asset>
        <texture type="skybox" builtin="gradient" rgb1=".4 .6 .8" rgb2="0 0 0" width="256" height="256"/>
        <material name="white_mat" rgba="0.99 0.99 0.99 1" specular="0" emission="0.05"/>
        <material name="mat_pastel" specular="0" shininess="0"/>
    </asset>
    <visual>
        <quality offsamples="0"/>
        <headlight diffuse="0.4 0.4 0.4" ambient="0.35 0.35 0.35" specular="0 0 0"/>
        <rgba haze="0.15 0.25 0.35 1"/>
        <global azimuth="110" elevation="-15" offwidth="1280" offheight="720"/>
    </visual>

    <worldbody>
        <light castshadow="true" pos="0 0 4" dir="0 0 -1" attenuation="1 0 0" diffuse="0.3 0.3 0.3" specular="0 0 0"/>
        
        <geom name="floor" type="plane" size="10 10 0.1" material="white_mat"/>
        
        <body name="cam-cam_body" mocap="true">
            <camera name="cam1" mode="fixed" pos="0 0 0" quat="1 0 0 0"/>
        </body>
    </worldbody>
    </mujoco>
"""

ARENA_EMPTY_XML = """
    <mujoco>
    <size memory="32M"/>

    <asset>
        <texture type="skybox" builtin="gradient" rgb1=".4 .6 .8" rgb2="0 0 0" width="256" height="256"/>
        <material name="white_mat" rgba="0.99 0.99 0.99 1" specular="0" emission="0.05"/>
        <material name="mat_pastel" specular="0" shininess="0"/>
    </asset>
    <visual>
        <quality offsamples="0"/>
        <headlight diffuse="0.4 0.4 0.4" ambient="0.35 0.35 0.35" specular="0 0 0"/>
        <rgba haze="0.15 0.25 0.35 1"/>
        <global azimuth="110" elevation="-15" offwidth="1280" offheight="720"/>
    </visual>

    <worldbody>
        <light castshadow="true" pos="0 0 4" dir="0 0 -1" attenuation="1 0 0" diffuse="0.3 0.3 0.3" specular="0 0 0"/>

        <body name="cam-cam_body" mocap="true">
            <camera name="cam1" mode="fixed" pos="0 0 0" quat="1 0 0 0"/>
        </body>
    </worldbody>
    </mujoco>
"""

@dataclass
class SpecInfo:
    name: str
    spec: mujoco.MjSpec
    pose: SE3
    mocap: bool = False
    visualize_mocap: bool = False

def apply_offset(spec, pose:SE3):
    for i, geom in enumerate(spec.geoms):
        spec.geoms[i].pos = pose.trans
        spec.geoms[i].quat = pose.rot.as_wxyz()
    return spec

class Scene:
    def __init__(self, world_spec: mujoco.MjSpec):
        world_info = SpecInfo("world", world_spec, SE3())
        self.spec_infos: dict[str, SpecInfo] = {"world": world_info}
        self.compiled_model = None
        self.compiled_data = None

        # default contact configuration
        self.lateral_friction = 0.7
        self.torsional_friction = 0.01
        self.rolling_friction = 0.01
        self.noslip_iterations = 0

    @property
    def root_spec(self):
        return self.spec_infos["world"].spec.copy()

    @classmethod
    def _create_from_xml_string(cls, xml_string: str) -> 'Scene':
        spec = mujoco.MjSpec.from_string(xml_string)
        spec.modelname = "world"
        return cls(spec)
    
    @classmethod
    def from_ground(cls) -> 'Scene':
        return cls._create_from_xml_string(ARENA_GROUND_XML)

    @classmethod
    def from_mj_ground(cls) -> 'Scene':
        return cls._create_from_xml_string(ARENA_GROUND_XML)
    
    @classmethod
    def from_empty(cls) -> 'Scene':
        return cls._create_from_xml_string(ARENA_EMPTY_XML)
    
    @classmethod
    def from_xml(cls, xml, add_free_joint=False) -> Scene:
        spec = mujoco.MjSpec.from_file(xml)
        if add_free_joint:
            spec.worldbody.bodies[0].add_freejoint()
        spec.modelname = "world"
        return cls(spec)
    
    def add_box(
        self,
        name: str,
        size: tuple[float, float, float],
        pos: tuple[float, float, float]=(0, 0, 0),
        rgba: tuple[float, float, float, float]=(1., 1., 1., 1.),
        material: str=None,
        **info_kwargs
    ):
        box_spec = mujoco.MjSpec()
        box_spec.worldbody.add_geom(
            type=mujoco.mjtGeom.mjGEOM_BOX,
            name=name,
            size=size,
            pos=pos,
            material=material,
        )
        self.add_spec_info(name, box_spec, **info_kwargs)
        
        
    def add_spec_info(
        self,
        name: str,
        spec: mujoco.MjSpec = None,
        xml: str = None,
        pose: SE3 = None,        # extrinsic
        pose_offset: SE3 = None, # intrinsic
        free_joint=False,
        scale:float=1.0,
        gravcomp:float=None,
        mocap=False,
        visualize_mocap=False,
    ):
        assert spec is not None or xml is not None
        assert not mocap or free_joint, "mocap requires a free joint"

        if xml is not None:
            spec = mujoco.MjSpec.from_file(xml)
        
        if isinstance(gravcomp, float):
            for body in spec.bodies:
                body.gravcomp = gravcomp

        if free_joint:
            spec.worldbody.bodies[0].add_freejoint()

        if scale != 1.0:
            for mesh in spec.meshes:
                mesh.scale *= scale

        if pose_offset is not None:
            spec = apply_offset(spec, pose_offset)
            # for i, geom in enumerate(spec.geoms):
            #     local_pose = SE3(SO3.from_xyzw(geom.quat), geom.pos)
            #     new_local_pose = pose_offset @ local_pose
            #     spec.geoms[i].pos = new_local_pose.trans
            #     spec.geoms[i].quat = new_local_pose.rot.as_wxyz()

        self.spec_infos[name] = SpecInfo(name, spec, pose, mocap, visualize_mocap)
        return self
    
    def build_spec(
        self,
        include: list[str] = None, 
    ):
        if include is None:
            include = list(self.spec_infos.keys() - {"world"}) # include all

        composed_spec = self.spec_infos["world"].spec.copy()
        
        for name in include:
            if name not in self.spec_infos:
                print(f"Warning: Object '{name}' not found in scene factory.")
                continue
            spec_info_to_add = self.spec_infos[name]
            self._attach(composed_spec, spec_info_to_add)

        # This is a hack to disable degree selection bug. (radian specified in xml is ignored)
        composed_spec.compiler.degree = False
        return composed_spec
        
    def build(
        self, 
        include_only: list[str] = None, 
        export_xml_path: str = None
    ) -> 'World':
        composed_spec = self.build_spec(include_only)
        self.set_default_stable_contact_config(
            composed_spec,
            lateral_friction=self.lateral_friction,
            torsional_friction=self.torsional_friction,
            rolling_friction=self.rolling_friction,
            noslip_iterations=self.noslip_iterations,
        )

        model = composed_spec.compile()
        data = mujoco.MjData(model)
        mujoco.mj_forward(model, data)

        if export_xml_path is not None:
            with open(export_xml_path, "w") as f:
                f.write(composed_spec.to_xml())
        return World(model, data)
    
    def compile_world(self, spec:mujoco.MjSpec):
        model = spec.compile()
        data = mujoco.MjData(model)
        mujoco.mj_forward(model, data)
        return World(model, data)

    @staticmethod
    def _attach(base_spec: mujoco.MjSpec, new_info: SpecInfo):
        # this uses site
        pose = new_info.pose if new_info.pose is not None else SE3()
        site = base_spec.worldbody.add_site(
            name=f"{new_info.name}-attach",
            pos=pose.trans,
            quat=pose.rot.as_wxyz(),
        )
        site.size = [0.0001, 0, 0]

        if new_info.mocap:
            mocap_body_name = f"{new_info.name}-mocap"
            root_body = new_info.spec.bodies[1]
            base_link_name = f"{new_info.name}-{root_body.name}"
            root_pos = np.array(root_body.pos, dtype=float)
            root_quat = np.array(root_body.quat, dtype=float)
            root_pose = SE3(trans=root_pos, rot=SO3.from_wxyz(root_quat))
            mocap_pose = pose @ root_pose
            mocap_body = base_spec.worldbody.add_body(
                name=mocap_body_name, mocap=True
            )
            mocap_body.pos = mocap_pose.trans
            mocap_body.quat = mocap_pose.rot.as_wxyz()
            if new_info.visualize_mocap:
                # attach_coord_frame_to_body(base_body)
                attach_coord_frame_to_body(mocap_body)
            base_spec.add_equality(
                type=mujoco.mjtEq.mjEQ_WELD,
                name1=mocap_body_name,
                name2=base_link_name,
                objtype=mujoco.mjtObj.mjOBJ_BODY,
                solimp=[0.9, 0.95, 0.001, 0.5, 2],
                data=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            )
        base_spec.attach(
            new_info.spec.copy(), 
            site=site, 
            prefix=f"{new_info.name}-"
        )
        return base_spec

    @staticmethod
    def _detach(base_spec: mujoco.MjSpec, info: SpecInfo):
        # detach body. In most cases you don't need this
        pattern = f"{info.name}-"
        body_names = [f.name for f in base_spec.bodies]
        for body_name in body_names:
            if pattern in body_name:
                base_spec.delete(base_spec.body(body_name))

        frame_names = [f.name for f in base_spec.frames]
        for frame_name in frame_names:
            if pattern in frame_name:
                base_spec.frame(frame_name).delete()

        site_names = [f.name for f in base_spec.sites]
        for site_name in site_names:
            if pattern in site_name:
                base_spec.delete(base_spec.site(site_name))

    def set_default_stable_contact_config(
        self, 
        spec: mujoco.MjSpec,
        lateral_friction: float=None,
        torsional_friction: float=None,
        rolling_friction: float=None,
        noslip_iterations: int =None
    ):
        if lateral_friction is None:
            lateral_friction = self.lateral_friction
        if torsional_friction is None:
            torsional_friction = self.torsional_friction
        if rolling_friction is None:
            rolling_friction = self.rolling_friction
        if noslip_iterations is None:
            noslip_iterations = self.noslip_iterations
        spec.option.noslip_iterations = noslip_iterations
        spec.option.integrator = mujoco.mjtIntegrator.mjINT_IMPLICITFAST
        spec.option.cone = mujoco.mjtCone.mjCONE_ELLIPTIC
        spec.option.impratio = 2 #2  impratio 증가 (Friction Priority)
        for geom in spec.geoms:
            geom.friction[:] = [lateral_friction, torsional_friction, rolling_friction]
            # 0.5 -> 0.95: 접촉 깊이가 얕을 때도(살짝 닿아도) 강한 힘(Stiffness)을 발휘하게 함.
            #geom.solimp[:3] = [0.5, 0.9, 0.0001]
            # geom.solimp[:3] = [0.95, 0.99, 0.001]
            geom.solimp[:3] = [0.9, 0.95, 0.001]
            geom.solref[:2] = [0.005, 1]
            geom.condim = 4
        return spec

    def combine_spec_infos(self, include=[]):
        world_spec = self.spec.copy()
        if include == "all":
            include = [k for k in self.spec_infos.keys() if k != "world"]
        
        for name in include:
            spec_info2 = self.spec_infos[name]
            world_spec = Scene.attach(
                world_spec, spec_info2, pose=spec_info2.pose
            )
        return world_spec


def attach_coord_frame_to_body(
    body, rel_pose: SE3 = SE3(), length=0.05, width=0.005
):
    origin = body.add_site()
    origin.name = f"{body.name}-origin"
    origin.type = mujoco.mjtGeom.mjGEOM_SPHERE
    origin.pos = rel_pose.trans
    origin.quat = rel_pose.rot.as_wxyz()
    origin.size = [width, 0, 0]
    origin.rgba = [0.3, 0.3, 0.3, 1.0]

    axes = np.eye(3)
    axes_rots = [[0, 1, 0], [-1, 0, 0], [0, 0, 0]]
    for i in range(3):
        axis = body.add_site()
        axis.type = mujoco.mjtGeom.mjGEOM_CYLINDER
        axis_pos = np.array(axes[i]) * length
        axis.pos = rel_pose.rot.apply(axis_pos) + rel_pose.trans
        axis.size = [width, length, 0]
        axis.rgba = [*axes[i], 1.0]
        axis.name = f"{origin.name}-axis{i}"
        rotvec = np.array(axes_rots[i]) * np.pi / 2
        rot = rel_pose.rot @ SO3.from_rotvec(rotvec)
        axis.quat = rot.as_wxyz()
