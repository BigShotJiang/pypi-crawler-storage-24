from collections.abc import Iterable
from typing import Optional

import mujoco
import numpy as np
from ezpose import SE3
from lxml import etree as ET

from .world import Body, World


class Robot:
    def __init__(
        self,
        robot_name,
        world: World,
        body_names: list[str],
        joint_names: list[str],
        actuator_names: list[str],
        mimic_joint_targets: dict[str, str],
    ):
        self.world = world
        self.model = world.model
        self.data = world.data
        self.name = robot_name
        #assert set(joint_names) == set(actuator_names)

        self.bodies: list[Body] = []
        for lname in body_names:
            bname = f"{robot_name}-{lname}"
            if bname in world.bodies:
                self.bodies.append(world.get_body(bname))

        self.joint_names = joint_names
        self.joints = {
            jname: self.model.joint(f"{robot_name}-{jname}")
            for jname in joint_names
        }
        #self.joints_by_idx = list(self.joints.values())
        self.actuator_models = {
            aname: self.model.actuator(f"{robot_name}-{aname}")
            for aname in actuator_names
        }
        self.actuator_data = {
            aname: self.data.actuator(f"{robot_name}-{aname}")
            for aname in actuator_names
        }
        self.aname_joint_map = {
            aname:self.model.joint(actuator.trnid[0])
            for aname, actuator in self.actuator_models.items()
        }
        self.jname_actuator_data_map = {
            joint.name.split("-", 1)[1]:self.actuator_data[aname]
            for aname, joint in self.aname_joint_map.items()
        }
        
        self.mimic_joint_targets = mimic_joint_targets
        self.movable_joint_names = [
            jname
            for jname in self.joint_names
            if jname not in self.mimic_joint_targets
        ]
        self.mocap_body = None
        if f"{robot_name}-mocap" in list(self.world.bodies.keys()):
            self.mocap_body = self.model.body(f"{robot_name}-mocap")

    @classmethod
    def parse_from_urdf(cls, robot_name, world: World, urdf_path: str):
        # TODO: implement
        pass
    
    @classmethod
    def parse_from_xml(
        cls, 
        robot_name, 
        world: World, 
        xml_path: str,
        joint_order: Optional[list[str]] = None,
        joint_order_map: Optional[dict[str, str]] = None,
    ):
        """the joints and the actuators are ordered by the appearance in the xml file"""
        def parse_by_tag(root: ET._Element, tag: str, parent_tag=None):
            if parent_tag is not None:
                path = f".//{parent_tag}/{tag}"
            else:
                path = f".//{tag}"
            attrs = root.xpath(path)
            return attrs

        tree = ET.parse(xml_path)
        root = tree.getroot()

        bodies = parse_by_tag(root, "body")  # body names
        joints = parse_by_tag(root, "joint", "body")  # body names
        actuators = parse_by_tag(root, "position", "actuator")
        mimic_joints = parse_by_tag(root, "joint", "equality")

        body_names = [b.attrib["name"] for b in bodies]
        joint_names = [
            j.attrib["name"]
            for j in joints
            if j.attrib.get("type", "hinge") not in ["fixed"]
        ]
        actuator_names = [a.attrib["name"] for a in actuators]
        mimic_joint_targets = {
            m.attrib["joint2"]: m.attrib["joint1"] for m in mimic_joints
        }
        robot = cls(
            robot_name=robot_name,
            world=world,
            body_names=body_names,
            joint_names=joint_names,
            actuator_names=actuator_names,
            mimic_joint_targets=mimic_joint_targets,
        )
        robot.apply_joint_order_map(joint_order, joint_order_map)
        return robot

    def apply_joint_order_map(
        self,
        joint_order: Optional[list[str]] = None,
        joint_order_map: Optional[dict[str, str]] = None,
    ):
        if joint_order is None or joint_order_map is None:
            return

        mapped_order = []
        for name in joint_order:
            if name not in joint_order_map:
                raise ValueError(
                    f"joint_order_map missing key '{name}' for robot '{self.name}'"
                )
            mapped_order.append(joint_order_map[name])

        movable_set = set(self.movable_joint_names)
        mapped_set = set(mapped_order)
        if mapped_set != movable_set:
            raise ValueError(
                "joint_order_map mismatch for robot "
                f"'{self.name}': mapped={sorted(mapped_set)}, "
                f"movable={sorted(movable_set)}"
            )
        if len(mapped_order) != len(movable_set):
            raise ValueError(
                f"joint_order_map has duplicate mapped joints for robot '{self.name}'"
            )

        # Reorder movable joints for q-vector interpretation.
        self.movable_joint_names = mapped_order

        # Keep non-movable joints after movable ones.
        non_movable = [j for j in self.joint_names if j not in movable_set]
        self.joint_names = mapped_order + non_movable
        self.joints = {
            jname: self.model.joint(f"{self.name}-{jname}")
            for jname in self.joint_names
        }

    # @classmethod
    # def parse_from_xml(cls, robot_name, world: World, xml_path: str):
    #     def parse_by_tag(root: ET._Element, tag: str, parent_tag=None):
    #         if parent_tag is not None:
    #             path = f".//{parent_tag}/{tag}"
    #         else:
    #             path = f".//{tag}"
    #         attrs = root.xpath(path)
    #         return attrs

    #     tree = ET.parse(xml_path)
    #     root = tree.getroot()

    #     bodies = parse_by_tag(root, "body")  # body names
    #     joints = parse_by_tag(root, "joint", "body")  # body names
    #     actuators = parse_by_tag(root, "position", "actuator")
    #     mimic_joints = parse_by_tag(root, "joint", "equality")

    #     body_names = [b.attrib["name"] for b in bodies]
    #     joint_names = [
    #         j.attrib["name"]
    #         for j in joints
    #         if j.attrib.get("type", "hinge") not in ["fixed"]
    #     ]
    #     actuator_names = [a.attrib["name"] for a in actuators]
    #     mimic_joint_targets = {
    #         m.attrib["joint2"]: m.attrib["joint1"] for m in mimic_joints
    #     }
    #     return cls(
    #         robot_name=robot_name,
    #         world=world,
    #         body_names=body_names,
    #         joint_names=joint_names,
    #         actuator_names=actuator_names,
    #         mimic_joint_targets=mimic_joint_targets,
    #     )

    @property
    def dof(self):
        return len(self.actuator_models)

    @property
    def mass(self):
        masses = [self.model.body_mass[b.uid] for b in self.bodies]
        return sum(masses)

    @property
    def body_names(self):
        return [b.body_name for b in self.bodies]

    def get_joint_angles(self, only_movable=True):
        if only_movable:
            joint_names = self.movable_joint_names
        else:
            joint_names = self.joint_names
        qpos_adr = np.array(
            [self.joints[jname].qposadr[0] for jname in joint_names], dtype=int
        )
        return self.data.qpos[qpos_adr]

    def span(self, q, return_dict=False):
        if not isinstance(q, Iterable):
            q = [q]
        q_dict = {name: 0.0 for name in self.joint_names}
        for theta, jname in zip(q, self.movable_joint_names):
            q_dict[jname] = theta
        for jname, target_jname in self.mimic_joint_targets.items():
            q_dict[jname] = q_dict[target_jname]
        if return_dict:
            return q_dict
        return np.array(list(q_dict.values()))

    def set_joint_angles(self, q, span_mimic=True):
        if len(q) != len(self.movable_joint_names):
            raise ValueError(
                f"q length mismatch for '{self.name}': "
                f"got {len(q)}, expected {len(self.movable_joint_names)}"
            )
        if span_mimic:
            q_span = self.span(q)
        qpos_adr = np.array(
            [j.qposadr[0] for j in self.joints.values()], dtype=int
        )
        dof_adr = np.array(
            [j.dofadr[0] for j in self.joints.values()], dtype=int
        )
        self.data.qpos[qpos_adr] = q_span
        self.data.qvel[dof_adr] = 0.0
        self.data.qacc[dof_adr] = 0.0
        self.set_pos_ctrl_target(q)  # already spanned
        #mujoco.mj_forward(self.model, self.data)
        self.world.step(render=True, forward_only=True)

    def set_pos_ctrl_target(self, q, span_mimic=True):
        if span_mimic:
            q_dict = self.span(q, return_dict=True)
        for jname, theta in q_dict.items():
            if jname not in self.jname_actuator_data_map:
                continue
            self.jname_actuator_data_map[jname].ctrl = theta

    def get_base_pose(self):
        return self.bodies[0].get_pose()

    def set_base_pose(self, pose):
        self.bodies[0].set_pose(pose)
        if self.mocap_body is not None:
            self.ctrl_base_pose(pose)

    def ctrl_base_pose(self, pose: SE3):
        assert self.mocap_body is not None
        mocap_idx = self.model.body_mocapid[self.mocap_body.id]
        self.data.mocap_pos[mocap_idx] = pose.trans
        self.data.mocap_quat[mocap_idx] = pose.rot.as_wxyz()

    def set_ghost(self, value: bool):
        for body in self.bodies:
            body.set_ghost(value)

    def is_in_collision(
        self,
        body2: Body = None,
        exclude_list: list[Body] = None,
        threshold=0.0,
        ignore_self_col=True
    ):
        """
        Checks if the robot is in collision with other objects in the world.
        """
        exclude_list = exclude_list or []
        contact_pairs = self.world.get_contact_pairs()

        # Determine which bodies to check for collisions against.
        # If body2 is specified, only check against it. Otherwise, check all robot bodies.
        relevant_bodies = {body2.body_name} if body2 else set(self.body_names)

        for rbody_name in relevant_bodies:
            if rbody_name not in contact_pairs:
                continue

            for other_body, dist in contact_pairs[rbody_name]:
                # 1. Check the distance threshold.
                if dist >= threshold:
                    continue

                # # 2. If body2 is specified, only consider collisions with that body.
                if body2 and other_body.body_name not in self.body_names:
                    continue

                # 3. Check if the other body is in the exclude list.
                if other_body in exclude_list:
                    continue

                # 4. Ignore self-collisions if the flag is set.
                if ignore_self_col and self.name in rbody_name and other_body.tag == self.name:
                    continue

                # If none of the above conditions are met, a collision is detected.
                return True

        return False

    # def is_in_collision(
    #     self, 
    #     body2: Body = None, 
    #     exclude_list: list[Body] = [], 
    #     threshold=0.0,
    #     ignore_self_col = True
    # ):
    #     def check_pairs(pairs):
    #         for rbody_name in self.body_names:
    #             if rbody_name not in pairs:
    #                 continue

    #             for body, dist in pairs[rbody_name]:
    #                 if body2 is not None and body2 != body:  # check body2
    #                     continue
    #                 elif body in exclude_list:
    #                     continue
    #                 elif dist < threshold:
    #                     return True
    #         return False

    #     pairs = self.world.get_contact_pairs()
    #     if body2 is not None:
    #         if body2.body_name not in pairs:
    #             return False
    #     else:
    #         col_rbody_names = set(pairs.keys()) & set(self.body_names)
    #         if len(col_rbody_names) == 0:
    #             return False

    #         if ignore_self_col:
    #             remove_col_list = []
    #             for name in col_rbody_names:    
    #                 for i, (col_body, dist) in enumerate(pairs[name]):
    #                     if ignore_self_col and col_body.tag == self.name:
    #                         remove_col_list.append((name, i))
                
    #             remove_col_list = sorted(
    #                 remove_col_list, key=lambda item: item[1], reverse=True)
    #             for name, i in remove_col_list:
    #                 pairs[name].pop(i)
    #     return check_pairs(pairs)

    
