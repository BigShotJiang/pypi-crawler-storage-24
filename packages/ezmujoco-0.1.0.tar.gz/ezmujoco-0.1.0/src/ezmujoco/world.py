from __future__ import annotations

import time
from contextlib import contextmanager
from collections import defaultdict

import mujoco
import mujoco.viewer
import numpy as np
from ezpose import SE3, SO3
import imageio

class VideoMaker:
    def __init__(self, cam: Camera, cam_pose: SE3, fps=30, acc=1):
        self.cam = cam
        self.cam_pose = cam_pose
        self.frames = []
        self.running = False
        self.fps = fps
        self.acc = acc
        self._frame_acc_time = 0.
    
    def is_frame_ready(self, dt):
        self._frame_acc_time += dt
        is_frame_ready = self._frame_acc_time >= 1.0 / self.fps
        if is_frame_ready:
            self._frame_acc_time = 0.
        return is_frame_ready

    def start_recording(self):
        self.running = True
        self.frames = []
    
    def stop_recording(self):
        self.running = False
    
    def add_frame(self):
        rgb = self.cam.render_rgb(self.cam_pose)
        self.frames.append(rgb)
    
    def save_video(self, path):
        frames = np.stack(self.frames)
        imageio.mimsave(str(path), frames, fps=self.fps*self.acc)
        
    
    def flush(self):
        self.frames.clear()


class World:
    def __init__(self, model, data):
        self.model = model
        self.data = data
        self.viewer = None
        
        self.realtime = False
        self.realtime_factor = 1.0
        self.step_start = time.time()

        self.bodies: dict[str, Body] = {}
        self.uid_map: dict[int, Body] = {}
        for i in range(model.nbody):
            body_name = model.body(i).name
            body = Body(body_name, self)
            self.bodies[body_name] = body
            self.uid_map[body.uid] = body
        self._contact_cache = None
        self.debug_id = 0

        self.timestep = 0
        self.video_maker = None

    def get_video_maker(self, cam_pose:SE3, width=640, height=480, fps=30, acc=1):
        cam = self.get_camera(width, height)
        self.video_maker = VideoMaker(cam, cam_pose, fps=fps, acc=acc)
        return self.video_maker

    def get_camera(self, width=640, height=480)->Camera:
        return Camera(self, width, height)

    def set_viewer(self, contact=False):
        self.viewer = mujoco.viewer.launch_passive(self.model, self.data)
        if contact:
            self.viewer.opt.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT] = 1
            self.viewer.opt.flags[mujoco.mjtVisFlag.mjVIS_CONTACTFORCE] = 1

    @contextmanager
    def visualized(self, gui=True, contact=True):
        if self.viewer is None and gui:
            self.set_viewer(contact=contact)
        yield self
        if self.viewer is not None:
            self.viewer.close()
        self.viewer = None

    @property
    def dt(self):
        return self.model.opt.timestep

    def step(self, render=True, forward_only=False):
        self._contact_cache = None

        if forward_only:
            mujoco.mj_forward(self.model, self.data)
        else:
            mujoco.mj_step(self.model, self.data)
            self.timestep += 1

        if render:
            self.render()
            if (
                self.video_maker is not None 
                and self.video_maker.running 
                and not forward_only
                and self.video_maker.is_frame_ready(self.dt)
            ):
                self.video_maker.add_frame()

        if self.realtime:
            step_time = time.time() - self.step_start
            is_step_too_fast = self.dt > step_time
            if is_step_too_fast:
                wait_time = (self.dt - step_time) * self.realtime_factor
                time.sleep(wait_time)
        self.step_start = time.time()

    def render(self):
        if self.viewer is not None:
            self.viewer.sync()

    def spin(self):
        while self.viewer.is_running():
            self.step()

    def get_body(self, bname):
        return self.bodies[bname]

    def find_body(self, pattern):
        for bname in self.bodies.keys():
            if pattern in bname:
                return self.bodies[bname]
        return None

    def get_contact_pairs(self) -> dict[str, list[tuple[Body, float]]]:
        if self._contact_cache is not None:
            return self._contact_cache
        
        pairs = defaultdict(list)

        for i in range(self.data.ncon):
            contact = self.data.contact[i]
            body1_uid = self.model.geom_bodyid[contact.geom1]
            body2_uid = self.model.geom_bodyid[contact.geom2]

            cbody1 = self.uid_map[body1_uid]
            cbody2 = self.uid_map[body2_uid]
            pairs[cbody1.body_name].append((cbody2, contact.dist))
            pairs[cbody2.body_name].append((cbody1, contact.dist))
        
        self._contact_cache = pairs
        return pairs

    def is_in_collision(
        self, body1: Body, body2: Body = None, threshold: float = 0.0
    ):
        all_contacts = self.get_contact_pairs()
        if body1.body_name not in all_contacts:
            return False

        contact_list = all_contacts[body1.body_name]
        if body2 is None:
            return any(dist < threshold for _, dist in contact_list)
        else:    
            return any(
                other_body == body2 and dist < threshold
                for other_body, dist in contact_list
            )

    def set_gravity(self, gravity_vec=[0, 0, -9.81]):
        assert len(gravity_vec) == 3
        self.model.opt.gravity = gravity_vec

    def wait_to_stabilize(
        self,
        timeout: float = 5.0,
        tol: float = 0.2,
        hold_time: float = 0.5,
    ):
        max_steps = int(timeout / self.dt)
        hold_steps = int(hold_time / self.dt)
        consecutive = 0

        for step in range(max_steps):
            self.step()

            linvels = np.linalg.norm(self.data.cvel[:, :3], axis=-1)
            max_vel = float(linvels.max())

            if max_vel < tol:
                consecutive += 1
                if consecutive >= hold_steps:
                    return
            else:
                consecutive = 0

    def draw_bounding_box(self, center=(0, 0, 0), extent=(0.5, 0.5, 0.5)):
        if self.viewer is None:
            return
        half_extents = np.array(extent) / 2
        mujoco.mjv_initGeom(
            self.viewer.user_scn.geoms[self.debug_id],
            type=mujoco.mjtGeom.mjGEOM_LINEBOX,
            size=half_extents,
            pos=np.array(center),
            mat=np.eye(3).flatten(),
            rgba=np.array([255, 0, 0, 255]),
        )
        self.viewer.user_scn.ngeom = self.debug_id + 1
        self.debug_id += 1
        self.render()


class Body:
    def __init__(self, body_name, world: World):
        self.body_name = body_name
        if body_name == "world":
            self.tag = "world"
            self.name = "world"
        else:
            self.tag, self.name = body_name.split("-", 1)
        self.world = world
        self.model = world.model
        self.data = world.data
        self._body = self.world.model.body(body_name)
        self.uid = self._body.id
        geomadr = self._body.geomadr[0]
        geomnum = self._body.geomnum[0]
        self.geomids = [i for i in range(geomadr, geomadr + geomnum)]

    def set_color(self, rgba=None, material=None):
        if rgba is None:
            rgb = np.random.uniform(0, 1, 3) / 2 + 0.5
            rgba = [*rgb, 1]
        for geomid in self.geomids:
            self.model.geom_rgba[geomid] = rgba
        
        if material is not None:
            mat_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_MATERIAL, material)
            if mat_id == -1:
                print(f"material {material} not found")
            for geomid in self.geomids:
                self.model.geom_matid[geomid] = mat_id
    
    def apply_external_force(self, force=np.zeros(3), torque=np.zeros(3)):
        assert len(force) == 3
        assert len(torque) == 3
        ft = np.concatenate([force, torque])
        self.data.xfrc_applied[self.uid] = ft

    def set_ghost(self, value:bool, color=None):
        if value:
            # disappearing
            for geomid in self.geomids:
                self.model.geom_conaffinity[geomid] = 0
                self.model.geom_contype[geomid] = 0
                self.model.geom_rgba[geomid] = [0,0,0,0]
            self.model.body_gravcomp[self.uid] = 1.
            self.world.step(forward_only=True)
        else:
            # appearing
            for geomid in self.geomids:
                self.model.geom_conaffinity[geomid] = 1
                self.model.geom_contype[geomid] = 1
                if color == "random":
                    rgb = np.random.uniform(0, 1, 3)
                elif color is None:
                    rgb = (0.5, 0.5, 0.5)
                self.model.geom_rgba[geomid] = [*rgb, 1]
                
            self.model.body_gravcomp[self.uid] = 0.
            self.world.step(forward_only=True)

    def __eq__(self, other_body: Body):
        if not isinstance(other_body, Body):
            return NotImplemented
        return self.uid == other_body.uid

    def __repr__(self):
        return f"Body(name={self.body_name}, uid={self.uid})"

    @property
    def first_joint(self):
        if self.model.body(self.uid).jntnum == 0:
            return None
        first_joint_id = self.model.body(self.uid).jntadr[0]
        return self.model.joint(first_joint_id)

    @property
    def is_free_body(self):
        if self.first_joint is None:
            return False
        return (self.first_joint.type == mujoco.mjtJoint.mjJNT_FREE)[0]

    def set_mass(self, mass):
        scale = mass / self.model.body_mass[self.uid]
        self.model.body_mass[self.uid] *= scale
        self.model.body_inertia[self.uid] *= scale

    def get_mass(self):
        return self.model.body_mass[self.uid]

    def get_pose(self):
        pos = self.world.data.xpos[self.uid].copy()
        quat = self.world.data.xquat[self.uid].copy()
        return SE3(trans=pos, rot=SO3.from_wxyz(quat))

    def get_velocity(self):
        vel = self.world.data.cvel[self.uid].copy()
        return vel[:3], vel[3:]

    def set_pose(self, pose: SE3):
        assert self.is_free_body
        first_joint_id = self.model.body(self.uid).jntadr[0]
        idx = self.model.jnt_qposadr[first_joint_id]
        self.data.qpos[idx : idx + 3] = pose.trans
        self.data.qpos[idx + 3 : idx + 7] = pose.rot.as_wxyz()
        idx = self.first_joint.dofadr[0]
        self.data.qvel[idx : idx + 6] = 0.0
        self.data.qacc[idx : idx + 6] = 0.0
        
        self.world.step(render=True, forward_only=True) # clear contact cache

    def is_in_collision(self, body2=None):
        return self.world.is_in_collision(self, body2)

    def is_collision_at(self, pose: SE3):
        old_pose = self.get_pose()
        self.set_pose(pose)
        is_col = self.is_in_collision()
        self.set_pose(old_pose)
        return is_col

class MocappedBody(Body):
    def __init__(self, body_name, world: World):
        super().__init__(body_name=body_name, world=world)
        self.mocap_body = self.model.body(f"{self.tag}-mocap")
        
    def set_pose(self, pose):
        super().set_pose(pose)
        self.ctrl_pose(pose)

    def ctrl_pose(self, pose: SE3):
        mocap_idx = self.model.body_mocapid[self.mocap_body.id]
        self.data.mocap_pos[mocap_idx] = pose.trans
        self.data.mocap_quat[mocap_idx] = pose.rot.as_wxyz()

class Camera:
    def __init__(self, world: World, width=640, height=480):
        self.world = world
        self.renderer = None
        self._cam = mujoco.MjvCamera()
        self._cam.fixedcamid = self.world.model.camera('cam1').id
        # self._cam.type = mujoco.mjtCamera.mjCAMERA_FREE
        # self._cam.fixedcamid = -1
        self.width = int(width)
        self.height = int(height)
        self._render_width = int(width)
        self._render_height = int(height)
        self.dmax = 2.0
        self.dmin = 0.1
        self._fovy_override: float | None = None
        self._target_cx: float = (self.width - 1) / 2.0
        self._target_cy: float = (self.height - 1) / 2.0
        self._crop_x0 = 0
        self._crop_y0 = 0
        self._render_margin = 20
        self._reinit_renderer(self._render_width, self._render_height)
    
    def close(self):
        if hasattr(self, "renderer") and self.renderer is not None:
            self.renderer.close()

    def __del__(self):
        self.close()

    def _reinit_renderer(self, width: int, height: int):
        if self.renderer is not None:
            self.renderer.close()
        self._render_width = int(width)
        self._render_height = int(height)
        self.renderer = mujoco.Renderer(
            self.world.model,
            height=self._render_height,
            width=self._render_width,
        )

    def _camera_id(self) -> int:
        return self.world.model.camera('cam1').id

    def _get_active_fovy_deg(self) -> float:
        if self._fovy_override is not None:
            return float(self._fovy_override)
        return float(self.world.model.cam_fovy[self._camera_id()])

    def _get_effective_intrinsic_dict(self):
        fovy_deg = self._get_active_fovy_deg()
        fovy = np.radians(fovy_deg)
        fy = self.height / (2 * np.tan(fovy / 2))
        fx = fy
        render_cx = (self._render_width - 1) / 2.0
        render_cy = (self._render_height - 1) / 2.0
        cx = render_cx - self._crop_x0
        cy = render_cy - self._crop_y0
        return {
            "fx": float(fx),
            "fy": float(fy),
            "cx": float(cx),
            "cy": float(cy),
            "width": int(self.width),
            "height": int(self.height),
            "fovy": float(fovy_deg),
        }

    def _crop_render(self, image: np.ndarray) -> np.ndarray:
        y0 = int(self._crop_y0)
        x0 = int(self._crop_x0)
        y1 = y0 + int(self.height)
        x1 = x0 + int(self.width)
        if image.ndim == 2:
            return image[y0:y1, x0:x1]
        return image[y0:y1, x0:x1, ...]
    
    def _set_cam_pose(self, cam_pose: SE3):
        # rotmat = cam_pose.rot.as_matrix()
        # zaxis = rotmat[:, -1]
        # xy_dist = np.linalg.norm(zaxis[:2])
        # elevation = np.degrees(np.arctan2(zaxis[2], xy_dist))
        # azimuth = np.degrees(np.arctan2(zaxis[1], zaxis[0]))

        # self._cam.lookat[:] = cam_pose.trans + zaxis
        # self._cam.distance = 1.0
        # self._cam.azimuth = azimuth
        # self._cam.elevation = elevation
        
        # Convention unification:
        # - External API cam_pose is treated as OpenCV-style camera pose.
        # - Internal MuJoCo camera body pose uses a fixed conversion only here.
        #   (so callers do not need extra Rz(pi) patches outside Camera)
        cam_pose = (
            cam_pose
            @ SE3(rot=SO3.from_euler("Z", -np.pi))
            @ SE3(rot=SO3.from_euler("xyz", [np.pi, 0, np.pi]))
        )
        pos = cam_pose.trans
        quat = cam_pose.rot.as_wxyz() 
        camera_body_id = self.world.model.body('cam-cam_body').mocapid[0]
        self.world.data.mocap_pos[camera_body_id] = pos
        self.world.data.mocap_quat[camera_body_id] = quat
        mujoco.mj_forward(self.world.model, self.world.data)
        # 4. Tell the renderer to use this specific camera
        # self._cam.fixedcamid = self.world.model.camera('cam1').id
        # self._cam.type = mujoco.mjtCamera.mjCAMERA_FIXED

    def render_depth(self, cam_pose: SE3):
        self._set_cam_pose(cam_pose)
        self.renderer.enable_depth_rendering()
        self.renderer.update_scene(self.world.data, "cam1")
        depth = self.renderer.render()
        depth = self._crop_render(depth).astype(np.float32)
        return depth

    def render_rgb(self, cam_pose: SE3):
        self._set_cam_pose(cam_pose)
        self.renderer.disable_depth_rendering()
        self.renderer.disable_segmentation_rendering()
        self.renderer.update_scene(self.world.data, "cam1")
        rgb = self.renderer.render()
        return self._crop_render(rgb)
    
    def render_segmentation(self, cam_pose: SE3):
        self._set_cam_pose(cam_pose)
        # TBD
        self.renderer.enable_segmentation_rendering()
        self.renderer.update_scene(self.world.data, "cam1")
        seg = self.renderer.render()
        return self._crop_render(seg)

    def set_intrinsic(
        self,
        fovy: float,
        cx_pixel: float | None = None,
        cy_pixel: float | None = None,
        width: int | None = None,
        height: int | None = None,
    ):
        # Runtime MuJoCo camera calibration does not provide a reliable programmable
        # off-center principal-point path in this codebase. We therefore control
        # effective intrinsics as:
        # - fx/fy via fovy
        # - cx/cy via overscan rendering + pixel crop
        # get_intrinsic() returns the effective post-crop intrinsics, not the
        # internal oversized render buffer parameters.
        if width is not None:
            self.width = int(width)
        if height is not None:
            self.height = int(height)

        self._fovy_override = float(fovy)
        center_x = (self.width - 1.0) / 2.0
        center_y = (self.height - 1.0) / 2.0
        self._target_cx = float(center_x if cx_pixel is None else cx_pixel)
        self._target_cy = float(center_y if cy_pixel is None else cy_pixel)

        margin = int(self._render_margin)
        render_width = int(self.width + 2 * margin)
        render_height = int(self.height + 2 * margin)
        if render_width != self._render_width or render_height != self._render_height:
            self._reinit_renderer(render_width, render_height)

        render_center_x = (self._render_width - 1.0) / 2.0
        render_center_y = (self._render_height - 1.0) / 2.0
        dx = self._target_cx - center_x
        dy = self._target_cy - center_y
        self._crop_x0 = int(np.rint(render_center_x - self._target_cx))
        self._crop_y0 = int(np.rint(render_center_y - self._target_cy))
        self._crop_x0 = int(np.clip(self._crop_x0, 0, self._render_width - self.width))
        self._crop_y0 = int(np.clip(self._crop_y0, 0, self._render_height - self.height))

        # Adjust internal camera fovy so the cropped output has the requested effective fovy.
        fovy_rad = np.radians(self._fovy_override)
        internal_fovy = 2.0 * np.arctan(
            (self._render_height / self.height) * np.tan(fovy_rad / 2.0)
        )
        self.world.model.cam_fovy[self._camera_id()] = np.degrees(internal_fovy)
        mujoco.mj_forward(self.world.model, self.world.data)

    def get_intrinsic(self, return_type: str = "matrix"):
        intr = self._get_effective_intrinsic_dict()
        fx = intr["fx"]
        fy = intr["fy"]
        cx = intr["cx"]
        cy = intr["cy"]
        K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]], dtype=float)
        if return_type == "matrix":
            return K
        if return_type == "dict":
            intr["K"] = K
            return intr
        raise ValueError("return_type must be one of {'matrix', 'dict'}")

    def get_intrinsic_matrix(self):
        return self.get_intrinsic(return_type="matrix")

    def depth_to_points(
        self, depth, cam_pose: SE3, eps=0.01, near=0.1, far=2.0
    ):
        height, width = depth.shape
        K = self.get_intrinsic(return_type="matrix")
        X, Y = np.meshgrid(np.arange(width), np.arange(height), indexing="xy")
        pixels = np.stack([X, Y]).reshape(2, -1)
        pixels_homo_coord = np.vstack([pixels, np.ones(pixels.shape[1])])
        P_inv = np.linalg.inv(K)
        obj_pixels_norm = (P_inv @ pixels_homo_coord).T
        points_cam = np.einsum("ij,i->ij", obj_pixels_norm, depth.flatten())
        is_valid = (near + eps <= depth) & (depth <= far - eps)
        points_cam = points_cam[is_valid.flatten()]
        return cam_pose.apply(points_cam)
