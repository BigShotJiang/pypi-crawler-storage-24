# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.6] - 2026-03-21

### Test
- Update tests/test_dashboard_new.py

### Other
- Update frontend/dashboard.html
- Update frontend/proxym-dashboard.jsx

## [0.1.5] - 2026-03-21

### Docs
- Update README.md
- Update docs/README.md

### Test
- Update tests/test_dashboard_gui.py
- Update tests/test_dashboard_integration.py
- Update tests/test_dashboard_live.py
- Update tests/test_dashboard_new.py
- Update tests/test_dashboard_performance.py

### Other
- Update dashboard.html
- Update proxym-dashboard.jsx

## [0.1.4] - 2026-03-21

### Docs
- Update README.md

### Test
- Update tests/conftest.py
- Update tests/test_accounts.py
- Update tests/test_analyzer.py
- Update tests/test_dashboard.py
- Update tests/test_delta_buffer.py
- Update tests/test_e2e.py
- Update tests/test_router.py

## [0.1.3] - 2026-03-21

### Docs
- Update CHANGELOG.md
- Update README.md

### Other
- Update Dockerfile.jetson
- Update docker-compose.prod.yml
- Update proxym-dashboard.jsx
- Update quadlet/ollama.container
- Update quadlet/proxym.container
- Update quadlet/proxym.network
- Update quadlet/redis.container
- Update scripts/jetson-entrypoint.sh
- Update scripts/setup.sh
- Update src/proxym/dashboard/panel.jsx
- ... and 1 more files

## [0.1.2] - 2026-03-21

## [0.1.1] - 2026-03-21

### Docs
- Update README.md

### Test
- Update tests/conftest.py
- Update tests/test_accounts.py
- Update tests/test_analyzer.py
- Update tests/test_dashboard.py
- Update tests/test_delta_buffer.py
- Update tests/test_e2e.py
- Update tests/test_router.py

### Other
- Update .env.example
- Update .gitignore
- Update Dockerfile.jetson
- Update proxym-dashboard.jsx
- Update docker-compose.prod.yml
- Update project.sh
- Update quadlet/proxym.container
- Update quadlet/proxym.network
- Update quadlet/ollama.container
- Update quadlet/redis.container
- ... and 4 more files

