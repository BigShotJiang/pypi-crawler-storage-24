"""Tests for sandbox module."""

import asyncio
import tempfile
from pathlib import Path

import pytest

from mini_box_agent.sandbox import ExecuteCodeTool
from mini_box_agent.sandbox.kernel_manager import KernelManager, DANGEROUS_PATTERNS


class TestKernelManager:
    """Tests for KernelManager."""

    @pytest.fixture
    def connection_info(self):
        """Create connection info for testing."""
        return {
            "url": "http://localhost:9999",
            "token": "test-token",
            "base_url": "http://localhost:9999?token=test-token",
        }

    def test_dangerous_patterns_defined(self):
        """Test that dangerous patterns are defined."""
        assert len(DANGEROUS_PATTERNS) > 0
        for pattern, message in DANGEROUS_PATTERNS:
            assert isinstance(pattern, str)
            assert isinstance(message, str)

    def test_dangerous_patterns_block_os_import(self, connection_info):
        """Test that os import is detected."""
        km = KernelManager(connection_info)
        result = km.check_dangerous_code("import os")
        assert result is not None
        assert "os" in result.lower()

    def test_dangerous_patterns_block_subprocess(self, connection_info):
        """Test that subprocess is detected."""
        km = KernelManager(connection_info)
        result = km.check_dangerous_code("import subprocess")
        assert result is not None

    def test_dangerous_patterns_block_eval(self, connection_info):
        """Test that eval is detected."""
        km = KernelManager(connection_info)
        result = km.check_dangerous_code("eval('1+1')")
        assert result is not None

    def test_dangerous_patterns_block_exec(self, connection_info):
        """Test that exec is detected."""
        km = KernelManager(connection_info)
        result = km.check_dangerous_code("exec('print(1)')")
        assert result is not None

    def test_dangerous_patterns_allow_safe_code(self, connection_info):
        """Test that safe code passes."""
        km = KernelManager(connection_info)
        safe_codes = [
            "print('hello')",
            "x = 10",
            "import pandas as pd",
            "df = pd.DataFrame({'a': [1, 2, 3]})",
        ]
        for code in safe_codes:
            result = km.check_dangerous_code(code)
            assert result is None, f"Safe code {code} was incorrectly blocked"


class TestExecuteCodeTool:
    """Tests for ExecuteCodeTool."""

    @pytest.fixture
    def sandbox_dir(self):
        """Create temporary sandbox directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    @pytest.fixture
    def tool(self, sandbox_dir):
        """Create ExecuteCodeTool instance."""
        return ExecuteCodeTool(str(sandbox_dir))

    @pytest.mark.asyncio
    async def test_simple_execute(self, tool):
        """Test simple print statement."""
        result = await tool.execute("print('hello world')")
        assert result.success
        assert "hello world" in result.content

    @pytest.mark.asyncio
    async def test_math_operations(self, tool):
        """Test math operations."""
        result = await tool.execute("x = 2 + 2; print(x)")
        assert result.success
        assert "4" in result.content

    @pytest.mark.asyncio
    async def test_variable_persistence(self, tool):
        """Test that variables persist within session."""
        await tool.execute("x = 42")
        result = await tool.execute("print(x)")
        assert result.success
        assert "42" in result.content

    @pytest.mark.asyncio
    async def test_pandas_import(self, tool):
        """Test pandas import and usage."""
        result = await tool.execute(
            "import pandas as pd; df = pd.DataFrame({'a': [1, 2, 3]}); print(len(df))"
        )
        assert result.success
        assert "3" in result.content

    @pytest.mark.asyncio
    async def test_matplotlib_import(self, tool):
        """Test matplotlib import."""
        result = await tool.execute(
            "import matplotlib.pyplot as plt; plt.plot([1, 2], [3, 4])"
        )
        assert result.success

    @pytest.mark.asyncio
    async def test_error_handling(self, tool):
        """Test error handling."""
        result = await tool.execute("raise ValueError('test error')")
        assert not result.success
        assert "ValueError" in result.content or "Error" in result.content

    @pytest.mark.asyncio
    async def test_security_block_os(self, tool):
        """Test that os import is blocked."""
        result = await tool.execute("import os")
        assert not result.success
        assert "Security" in result.content

    @pytest.mark.asyncio
    async def test_security_block_subprocess(self, tool):
        """Test that subprocess is blocked."""
        result = await tool.execute("import subprocess")
        assert not result.success
        assert "Security" in result.content

    @pytest.mark.asyncio
    async def test_security_block_eval(self, tool):
        """Test that eval is blocked."""
        result = await tool.execute("eval('1+1')")
        assert not result.success
        assert "Security" in result.content

    @pytest.mark.asyncio
    async def test_security_block_exec(self, tool):
        """Test that exec is blocked."""
        result = await tool.execute("exec('print(1)')")
        assert not result.success
        assert "Security" in result.content

    @pytest.mark.asyncio
    async def test_security_block_absolute_path(self, tool):
        """Test that absolute path open is blocked."""
        result = await tool.execute("open('/etc/passwd')")
        assert not result.success
        assert "Security" in result.content

    @pytest.mark.asyncio
    async def test_interrupt(self, tool):
        """Test interrupt functionality."""
        # Start a long-running operation
        task = asyncio.create_task(tool.execute("import time; time.sleep(10)"))
        await asyncio.sleep(0.5)  # Let it start
        result = await tool.interrupt()
        assert result.success
        assert "Interrupt" in result.content
        task.cancel()

    @pytest.mark.asyncio
    async def test_reset(self, tool):
        """Test reset functionality."""
        await tool.execute("x = 100")
        await tool.reset()
        # After reset, x should not exist
        result = await tool.execute("print(x)")
        # Should fail because x is not defined after reset
        assert not result.success or "NameError" in result.content

    @pytest.mark.asyncio
    async def test_cleanup(self, tool):
        """Test cleanup functionality."""
        await tool.execute("x = 1")
        await tool.cleanup()
        assert tool._initialized is False

    @pytest.mark.asyncio
    async def test_multiple_execute_in_session(self, tool):
        """Test multiple execute calls in same session."""
        results = []
        results.append(await tool.execute("x = 10"))
        results.append(await tool.execute("y = 20"))
        results.append(await tool.execute("print(x + y)"))

        assert all(r.success for r in results)
        assert "30" in results[-1].content

    @pytest.mark.asyncio
    async def test_no_output(self, tool):
        """Test code with no output."""
        result = await tool.execute("x = 5  # just assignment")
        assert result.success
        assert "(no output)" in result.content

    @pytest.mark.asyncio
    async def test_stderr_captured(self, tool):
        """Test that stderr is captured."""
        result = await tool.execute("import sys; sys.stderr.write('error message\\n')")
        assert not result.success or "[stderr]" in result.content

    @pytest.mark.asyncio
    async def test_path_sanitization(self, tool):
        """Test that sandbox paths are sanitized."""
        # sandbox:/file.csv should be converted to relative path
        result = await tool.execute(
            "sandbox_data = 'sandbox:/data.csv'; print(sandbox_data)"
        )
        assert result.success
        assert "sandbox:/" not in result.content or "data.csv" in result.content


class TestMultiSandbox:
    """Tests for multi-sandbox session management."""

    @pytest.fixture
    def multi_tool(self):
        """Create MultiSandboxTool instance."""
        import tempfile
        from pathlib import Path
        from mini_box_agent.sandbox import MultiSandboxTool

        with tempfile.TemporaryDirectory() as tmpdir:
            yield MultiSandboxTool(str(Path(tmpdir)))

    @pytest.mark.asyncio
    async def test_create_session(self, multi_tool):
        """Test creating a sandbox session."""
        result = await multi_tool.execute(action="create")
        assert result.success
        assert "Created sandbox session:" in result.content

    @pytest.mark.asyncio
    async def test_create_multiple_sessions(self, multi_tool):
        """Test creating multiple sessions."""
        r1 = await multi_tool.execute(action="create")
        r2 = await multi_tool.execute(action="create")
        assert r1.success and r2.success

        list_result = await multi_tool.execute(action="list")
        assert "2" in list_result.content or "," in list_result.content

        await multi_tool.execute(action="close_all")

    @pytest.mark.asyncio
    async def test_isolation_between_sessions(self, multi_tool):
        """Test that sessions are isolated."""
        # Create two sessions
        r1 = await multi_tool.execute(action="create")
        r2 = await multi_tool.execute(action="create")

        # Extract session IDs
        import re

        session_id_1 = re.search(r": (\w+)", r1.content).group(1)
        session_id_2 = re.search(r": (\w+)", r2.content).group(1)

        # Execute in session 1
        await multi_tool.execute(
            action="execute", session_id=session_id_1, code="x = 100"
        )

        # Execute in session 2
        await multi_tool.execute(
            action="execute", session_id=session_id_2, code="y = 200"
        )

        # Check isolation: session 1 should have x, session 2 should have y
        r1_check = await multi_tool.execute(
            action="execute", session_id=session_id_1, code="print(x)"
        )
        r2_check = await multi_tool.execute(
            action="execute", session_id=session_id_2, code="print(y)"
        )

        assert "100" in r1_check.content
        assert "200" in r2_check.content

        # Session 1 should NOT have y
        r1_no_y = await multi_tool.execute(
            action="execute", session_id=session_id_1, code="print(y)"
        )
        assert not r1_no_y.success

        await multi_tool.execute(action="close_all")

    @pytest.mark.asyncio
    async def test_list_sessions(self, multi_tool):
        """Test listing sessions."""
        await multi_tool.execute(action="create")
        await multi_tool.execute(action="create")

        result = await multi_tool.execute(action="list")
        assert result.success
        assert "Active sessions:" in result.content

        await multi_tool.execute(action="close_all")

    @pytest.mark.asyncio
    async def test_close_session(self, multi_tool):
        """Test closing a specific session."""
        r = await multi_tool.execute(action="create")
        import re

        session_id = re.search(r": (\w+)", r.content).group(1)

        close_result = await multi_tool.execute(action="close", session_id=session_id)
        assert close_result.success
        assert "Closed sandbox session" in close_result.content

    @pytest.mark.asyncio
    async def test_close_all(self, multi_tool):
        """Test closing all sessions."""
        await multi_tool.execute(action="create")
        await multi_tool.execute(action="create")

        result = await multi_tool.execute(action="close_all")
        assert result.success
        assert "Closed all sandbox sessions" in result.content

        list_result = await multi_tool.execute(action="list")
        assert "none" in list_result.content


class TestSandboxCSVAnalysis:
    """Integration tests for CSV analysis workflow."""

    @pytest.fixture
    def csv_tool(self):
        """Create ExecuteCodeTool for CSV analysis."""
        import tempfile
        from pathlib import Path

        tool = ExecuteCodeTool(str(Path(tempfile.mkdtemp())))
        yield tool

    @pytest.mark.asyncio
    async def test_csv_data_analysis(self, csv_tool):
        """Test full CSV analysis workflow."""
        # Create and analyze CSV in single execution
        result = await csv_tool.execute("""
import pandas as pd
from io import StringIO
csv_data = '''name,age,city,salary
Alice,30,NYC,75000
Bob,25,LA,60000
Charlie,35,NYC,90000
Diana,28,SF,80000
Eve,32,NYC,85000
'''
df = pd.read_csv(StringIO(csv_data))
print(f"Rows: {len(df)}")
print(f"Average salary: {df['salary'].mean()}")
print(f"Highest salary: {df['salary'].max()}")
""")
        assert result.success
        assert "Rows: 5" in result.content
        assert "Average salary: 78000" in result.content
        assert "Highest salary: 90000" in result.content

    @pytest.mark.asyncio
    async def test_csv_visualization(self, csv_tool):
        """Test creating a visualization from CSV data."""
        result = await csv_tool.execute("""
import pandas as pd
import matplotlib.pyplot as plt
from io import StringIO
csv_data = '''month,sales
Jan,100
Feb,150
Mar,200
Apr,180
May,220
'''
df = pd.read_csv(StringIO(csv_data))
plt.figure()
plt.bar(df['month'], df['sales'])
plt.title('Monthly Sales')
plt.savefig('sales_chart.png')
plt.close()
print("Chart saved successfully")
""")
        assert result.success
        assert "Chart saved successfully" in result.content

    @pytest.mark.asyncio
    async def test_dataframe_operations(self, csv_tool):
        """Test dataframe operations persist in session."""
        # Create dataframe
        r1 = await csv_tool.execute("""
import pandas as pd
global df
df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
print(f"Created df with {len(df)} rows")
""")
        assert r1.success

        # Use it in next call
        r2 = await csv_tool.execute("""
print(f"Sum of column 'b': {df['b'].sum()}")
print(f"Mean of column 'a': {df['a'].mean()}")
""")
        assert r2.success
        assert "Sum of column 'b': 15" in r2.content
        assert "Mean of column 'a': 2" in r2.content

    @pytest.mark.asyncio
    async def test_multi_sandbox_parallel_csv_analysis(self):
        """Test parallel CSV analysis using multi-sandbox."""
        import re
        from mini_box_agent.sandbox import MultiSandboxTool
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as tmpdir:
            multi_tool = MultiSandboxTool(tmpdir)

            # Create sessions
            r1 = await multi_tool.execute(action="create")
            r2 = await multi_tool.execute(action="create")

            session_id_1 = re.search(r": (\w+)", r1.content).group(1)
            session_id_2 = re.search(r": (\w+)", r2.content).group(1)

            # Execute in each session
            r1_result = await multi_tool.execute(
                action="execute",
                session_id=session_id_1,
                code="import pandas as pd; df = pd.DataFrame({'x': [1,2,3]}); print(f'Session 1: {len(df)} rows')",
            )
            r2_result = await multi_tool.execute(
                action="execute",
                session_id=session_id_2,
                code="import pandas as pd; df = pd.DataFrame({'y': [4,5,6]}); print(f'Session 2: {len(df)} rows')",
            )

            assert r1_result.success
            assert "Session 1: 3 rows" in r1_result.content
            assert r2_result.success
            assert "Session 2: 3 rows" in r2_result.content

            await multi_tool.execute(action="close_all")
