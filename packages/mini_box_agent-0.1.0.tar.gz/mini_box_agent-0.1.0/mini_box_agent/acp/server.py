"""ACP server entry point."""

from mini_box_agent.acp import main

if __name__ == "__main__":
    main()
