"""Sandbox environment management."""

import subprocess
import sys
from pathlib import Path


def get_sandbox_venv_path() -> Path:
    """Get the path to the sandbox virtual environment."""
    return Path.home() / ".mini-box-agent" / "venv"


def ensure_sandbox_venv() -> Path:
    """Ensure the sandbox venv exists with required packages."""
    venv_path = get_sandbox_venv_path()

    if venv_path.exists():
        python_path = venv_path / "bin" / "python"
        if python_path.exists():
            return venv_path

    print(f"Creating isolated Python environment at {venv_path}...")
    venv_path.parent.mkdir(parents=True, exist_ok=True)

    if venv_path.exists():
        subprocess.run(
            [
                str(venv_path / "bin" / "python"),
                "-m",
                "venv",
                "--clear",
                str(venv_path),
            ],
            check=True,
        )
    else:
        subprocess.run([sys.executable, "-m", "venv", str(venv_path)], check=True)

    pip_path = venv_path / "bin" / "pip"
    subprocess.run(
        [str(pip_path), "install", "--upgrade", "pip"],
        check=True,
        capture_output=True,
    )
    subprocess.run(
        [
            str(pip_path),
            "install",
            "jupyter",
            "jupyter_client",
            "pandas",
            "numpy",
            "matplotlib",
            "scipy",
        ],
        check=True,
    )
    print(f"Isolated environment ready at {venv_path}")
    return venv_path


def get_sandbox_python() -> str:
    """Get the Python executable path for the sandbox venv."""
    venv_path = ensure_sandbox_venv()
    python_path = venv_path / "bin" / "python"
    if not python_path.exists():
        raise RuntimeError(f"Python not found at {python_path}")
    return str(python_path)


def get_sandbox_jupyter() -> str:
    """Get the jupyter executable path for the sandbox venv."""
    venv_path = ensure_sandbox_venv()
    jupyter_path = venv_path / "bin" / "jupyter"
    if not jupyter_path.exists():
        raise RuntimeError(f"Jupyter not found at {jupyter_path}")
    return str(jupyter_path)


def install_to_sandbox(package_name: str) -> bool:
    """Install a package to the sandbox venv. Returns True if successful."""
    venv_path = get_sandbox_venv_path()
    pip_path = venv_path / "bin" / "pip"

    if not pip_path.exists():
        return False

    try:
        result = subprocess.run(
            [str(pip_path), "install", package_name],
            capture_output=True,
            text=True,
            timeout=120,
        )
        return result.returncode == 0
    except Exception:
        return False
