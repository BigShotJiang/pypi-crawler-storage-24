"""
Mini Box Agent - Interactive Runtime Example

Usage:
    mini-box [--workspace DIR] [--task TASK]

Examples:
    mini-box                              # Use current directory as workspace (interactive mode)
    mini-box --workspace /path/to/dir     # Use specific workspace directory (interactive mode)
    mini-box --task "create a file"       # Execute a task non-interactively
"""

import argparse
import asyncio
import platform
import subprocess
import sys
import threading
import uuid
from datetime import datetime
from getpass import getpass
from pathlib import Path
from typing import List

from prompt_toolkit import PromptSession
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.history import FileHistory
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.styles import Style

from mini_box_agent import LLMClient
from mini_box_agent.agent import Agent
from mini_box_agent.config import Config
from mini_box_agent.schema import LLMProvider
from mini_box_agent.tools.base import Tool
from mini_box_agent.tools.bash_tool import BashKillTool, BashOutputTool, BashTool
from mini_box_agent.tools.file_tools import EditTool, ReadTool, WriteTool
from mini_box_agent.tools.mcp_loader import (
    cleanup_mcp_connections,
    load_mcp_tools_async,
    set_mcp_timeout_config,
)
from mini_box_agent.tools.note_tool import SessionNoteTool
from mini_box_agent.tools.skill_tool import create_skill_tools
from mini_box_agent.sandbox import ExecuteCodeTool, MultiSandboxTool, SandboxFileTool
from mini_box_agent.utils import calculate_display_width


# ANSI color codes
class Colors:
    """Terminal color definitions"""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

    # Foreground colors
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bright colors
    BRIGHT_BLACK = "\033[90m"
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"

    # Background colors
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"


def get_log_directory() -> Path:
    """Get the log directory path."""
    return Path.home() / ".mini-box-agent" / "log"


def show_log_directory(open_file_manager: bool = True) -> None:
    """Show log directory contents and optionally open file manager.

    Args:
        open_file_manager: Whether to open the system file manager
    """
    log_dir = get_log_directory()

    print(f"\n{Colors.BRIGHT_CYAN}📁 Log Directory: {log_dir}{Colors.RESET}")

    if not log_dir.exists() or not log_dir.is_dir():
        print(f"{Colors.RED}Log directory does not exist: {log_dir}{Colors.RESET}\n")
        return

    log_files = list(log_dir.glob("*.log"))

    if not log_files:
        print(f"{Colors.YELLOW}No log files found in directory.{Colors.RESET}\n")
        return

    # Sort by modification time (newest first)
    log_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)

    print(f"{Colors.DIM}{'─' * 60}{Colors.RESET}")
    print(
        f"{Colors.BOLD}{Colors.BRIGHT_YELLOW}Available Log Files (newest first):{Colors.RESET}"
    )

    for i, log_file in enumerate(log_files[:10], 1):
        mtime = datetime.fromtimestamp(log_file.stat().st_mtime)
        size = log_file.stat().st_size
        size_str = f"{size:,}" if size < 1024 else f"{size / 1024:.1f}K"
        print(
            f"  {Colors.GREEN}{i:2d}.{Colors.RESET} {Colors.BRIGHT_WHITE}{log_file.name}{Colors.RESET}"
        )
        print(
            f"      {Colors.DIM}Modified: {mtime.strftime('%Y-%m-%d %H:%M:%S')}, Size: {size_str}{Colors.RESET}"
        )

    if len(log_files) > 10:
        print(f"  {Colors.DIM}... and {len(log_files) - 10} more files{Colors.RESET}")

    print(f"{Colors.DIM}{'─' * 60}{Colors.RESET}")

    # Open file manager
    if open_file_manager:
        _open_directory_in_file_manager(log_dir)

    print()


def _open_directory_in_file_manager(directory: Path) -> None:
    """Open directory in system file manager (cross-platform)."""
    system = platform.system()

    try:
        if system == "Darwin":
            subprocess.run(["open", str(directory)], check=False)
        elif system == "Windows":
            subprocess.run(["explorer", str(directory)], check=False)
        elif system == "Linux":
            subprocess.run(["xdg-open", str(directory)], check=False)
    except FileNotFoundError:
        print(
            f"{Colors.YELLOW}Could not open file manager. Please navigate manually.{Colors.RESET}"
        )
    except Exception as e:
        print(f"{Colors.YELLOW}Error opening file manager: {e}{Colors.RESET}")


def read_log_file(filename: str) -> None:
    """Read and display a specific log file.

    Args:
        filename: The log filename to read
    """
    log_dir = get_log_directory()
    log_file = log_dir / filename

    if not log_file.exists() or not log_file.is_file():
        print(f"\n{Colors.RED}❌ Log file not found: {log_file}{Colors.RESET}\n")
        return

    print(f"\n{Colors.BRIGHT_CYAN}📄 Reading: {log_file}{Colors.RESET}")
    print(f"{Colors.DIM}{'─' * 80}{Colors.RESET}")

    try:
        with open(log_file, "r", encoding="utf-8") as f:
            content = f.read()
        print(content)
        print(f"{Colors.DIM}{'─' * 80}{Colors.RESET}")
        print(f"\n{Colors.GREEN}✅ End of file{Colors.RESET}\n")
    except Exception as e:
        print(f"\n{Colors.RED}❌ Error reading file: {e}{Colors.RESET}\n")


def print_banner():
    """Print welcome banner with proper alignment"""
    BOX_WIDTH = 58
    banner_text = (
        f"{Colors.BOLD}🤖 Mini Agent - Multi-turn Interactive Session{Colors.RESET}"
    )
    banner_width = calculate_display_width(banner_text)

    # Center the text with proper padding
    total_padding = BOX_WIDTH - banner_width
    left_padding = total_padding // 2
    right_padding = total_padding - left_padding

    print()
    print(f"{Colors.BOLD}{Colors.BRIGHT_CYAN}╔{'═' * BOX_WIDTH}╗{Colors.RESET}")
    print(
        f"{Colors.BOLD}{Colors.BRIGHT_CYAN}║{Colors.RESET}{' ' * left_padding}{banner_text}{' ' * right_padding}{Colors.BOLD}{Colors.BRIGHT_CYAN}║{Colors.RESET}"
    )
    print(f"{Colors.BOLD}{Colors.BRIGHT_CYAN}╚{'═' * BOX_WIDTH}╝{Colors.RESET}")
    print()


def print_help():
    """Print help information"""
    help_text = f"""
{Colors.BOLD}{Colors.BRIGHT_YELLOW}Available Commands:{Colors.RESET}
  {Colors.BRIGHT_GREEN}/help{Colors.RESET}      - Show this help message
  {Colors.BRIGHT_GREEN}/clear{Colors.RESET}     - Clear session history and reset sandbox
  {Colors.BRIGHT_GREEN}/history{Colors.RESET}   - Show current session message count
  {Colors.BRIGHT_GREEN}/stats{Colors.RESET}     - Show session statistics
  {Colors.BRIGHT_GREEN}/log{Colors.RESET}       - Show log directory and recent files
  {Colors.BRIGHT_GREEN}/log <file>{Colors.RESET} - Read a specific log file
  {Colors.BRIGHT_GREEN}/exit{Colors.RESET}      - Exit program (also: exit, quit, q)

{Colors.BOLD}{Colors.BRIGHT_YELLOW}Keyboard Shortcuts:{Colors.RESET}
  {Colors.BRIGHT_CYAN}Esc{Colors.RESET}        - Cancel current agent execution
  {Colors.BRIGHT_CYAN}Ctrl+C{Colors.RESET}     - Exit program
  {Colors.BRIGHT_CYAN}Ctrl+U{Colors.RESET}     - Clear current input line
  {Colors.BRIGHT_CYAN}Ctrl+L{Colors.RESET}     - Clear screen
  {Colors.BRIGHT_CYAN}Ctrl+J{Colors.RESET}     - Insert newline (also Ctrl+Enter)
  {Colors.BRIGHT_CYAN}Tab{Colors.RESET}        - Auto-complete commands
  {Colors.BRIGHT_CYAN}↑/↓{Colors.RESET}        - Browse command history
  {Colors.BRIGHT_CYAN}→{Colors.RESET}          - Accept auto-suggestion

{Colors.BOLD}{Colors.BRIGHT_YELLOW}Usage:{Colors.RESET}
  - Enter your task directly, Agent will help you complete it
  - Agent remembers all conversation content in this session
  - Use {Colors.BRIGHT_GREEN}/clear{Colors.RESET} to start a new session
  - Press {Colors.BRIGHT_CYAN}Enter{Colors.RESET} to submit your message
  - Use {Colors.BRIGHT_CYAN}Ctrl+J{Colors.RESET} to insert line breaks within your message
"""
    print(help_text)


def print_session_info(agent: Agent, workspace_dir: Path, model: str):
    """Print session information with proper alignment"""
    BOX_WIDTH = 58

    def print_info_line(text: str):
        """Print a single info line with proper padding"""
        # Account for leading space
        text_width = calculate_display_width(text)
        padding = max(0, BOX_WIDTH - 1 - text_width)
        print(
            f"{Colors.DIM}│{Colors.RESET} {text}{' ' * padding}{Colors.DIM}│{Colors.RESET}"
        )

    # Top border
    print(f"{Colors.DIM}┌{'─' * BOX_WIDTH}┐{Colors.RESET}")

    # Header (centered)
    header_text = f"{Colors.BRIGHT_CYAN}Session Info{Colors.RESET}"
    header_width = calculate_display_width(header_text)
    header_padding_total = BOX_WIDTH - 1 - header_width  # -1 for leading space
    header_padding_left = header_padding_total // 2
    header_padding_right = header_padding_total - header_padding_left
    print(
        f"{Colors.DIM}│{Colors.RESET} {' ' * header_padding_left}{header_text}{' ' * header_padding_right}{Colors.DIM}│{Colors.RESET}"
    )

    # Divider
    print(f"{Colors.DIM}├{'─' * BOX_WIDTH}┤{Colors.RESET}")

    # Info lines
    print_info_line(f"Model: {model}")
    print_info_line(f"Workspace: {workspace_dir}")
    print_info_line(f"Message History: {len(agent.messages)} messages")
    print_info_line(f"Available Tools: {len(agent.tools)} tools")

    # Bottom border
    print(f"{Colors.DIM}└{'─' * BOX_WIDTH}┘{Colors.RESET}")
    print()
    print(
        f"{Colors.DIM}Type {Colors.BRIGHT_GREEN}/help{Colors.DIM} for help, {Colors.BRIGHT_GREEN}/exit{Colors.DIM} to quit{Colors.RESET}"
    )
    print()


def print_stats(agent: Agent, session_start: datetime):
    """Print session statistics"""
    duration = datetime.now() - session_start
    hours, remainder = divmod(int(duration.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)

    # Count different types of messages
    user_msgs = sum(1 for m in agent.messages if m.role == "user")
    assistant_msgs = sum(1 for m in agent.messages if m.role == "assistant")
    tool_msgs = sum(1 for m in agent.messages if m.role == "tool")

    print(f"\n{Colors.BOLD}{Colors.BRIGHT_CYAN}Session Statistics:{Colors.RESET}")
    print(f"{Colors.DIM}{'─' * 40}{Colors.RESET}")
    print(f"  Session Duration: {hours:02d}:{minutes:02d}:{seconds:02d}")
    print(f"  Total Messages: {len(agent.messages)}")
    print(f"    - User Messages: {Colors.BRIGHT_GREEN}{user_msgs}{Colors.RESET}")
    print(
        f"    - Assistant Replies: {Colors.BRIGHT_BLUE}{assistant_msgs}{Colors.RESET}"
    )
    print(f"    - Tool Calls: {Colors.BRIGHT_YELLOW}{tool_msgs}{Colors.RESET}")
    print(f"  Available Tools: {len(agent.tools)}")
    if agent.api_total_tokens > 0:
        print(
            f"  API Tokens Used: {Colors.BRIGHT_MAGENTA}{agent.api_total_tokens:,}{Colors.RESET}"
        )
    print(f"{Colors.DIM}{'─' * 40}{Colors.RESET}\n")


def parse_args() -> argparse.Namespace:
    """Parse command line arguments

    Returns:
        Parsed arguments
    """
    parser = argparse.ArgumentParser(
        description="Mini Agent - AI assistant with file tools and MCP support",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  mini-box                              # Use current directory as workspace
  mini-box --workspace /path/to/dir     # Use specific workspace directory
  mini-box log                          # Show log directory and recent files
  mini-box log agent_run_xxx.log        # Read a specific log file
        """,
    )
    parser.add_argument(
        "--workspace",
        "-w",
        type=str,
        default=None,
        help="Workspace directory (default: current directory)",
    )
    parser.add_argument(
        "--task",
        "-t",
        type=str,
        default=None,
        help="Execute a task non-interactively and exit",
    )
    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version="mini-agent 0.1.0",
    )
    parser.add_argument(
        "--sandbox",
        "-s",
        action="store_true",
        default=True,
        help="Enable Jupyter sandbox for Python code execution (default: enabled)",
    )
    parser.add_argument(
        "--no-sandbox",
        dest="sandbox",
        action="store_false",
        help="Disable Jupyter sandbox for Python code execution",
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Validate existing API key configuration and exit",
    )

    # Subcommands
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # log subcommand
    log_parser = subparsers.add_parser(
        "log", help="Show log directory or read log files"
    )
    log_parser.add_argument(
        "filename",
        nargs="?",
        default=None,
        help="Log filename to read (optional, shows directory if omitted)",
    )

    return parser.parse_args()


async def initialize_base_tools(config: Config):
    """Initialize base tools (independent of workspace)

    These tools are loaded from package configuration and don't depend on workspace.
    Note: File tools are now workspace-dependent and initialized in add_workspace_tools()

    Args:
        config: Configuration object

    Returns:
        Tuple of (list of tools, skill loader if skills enabled)
    """

    tools = []
    skill_loader = None

    # 1. Bash auxiliary tools (output monitoring and kill)
    # Note: BashTool itself is created in add_workspace_tools() with workspace_dir as cwd
    if config.tools.enable_bash:
        bash_output_tool = BashOutputTool()
        tools.append(bash_output_tool)
        print(f"{Colors.GREEN}✅ Loaded Bash Output tool{Colors.RESET}")

        bash_kill_tool = BashKillTool()
        tools.append(bash_kill_tool)
        print(f"{Colors.GREEN}✅ Loaded Bash Kill tool{Colors.RESET}")

    # 3. Claude Skills (loaded from package directory)
    if config.tools.enable_skills:
        print(f"{Colors.BRIGHT_CYAN}Loading Claude Skills...{Colors.RESET}")
        try:
            # Resolve skills directory with priority search
            # Expand ~ to user home directory for portability
            skills_path = Path(config.tools.skills_dir).expanduser()
            if skills_path.is_absolute():
                skills_dir = str(skills_path)
            else:
                # Search in priority order:
                # 1. Current directory (dev mode: ./skills or ./mini_agent/skills)
                # 2. Package directory (installed: site-packages/mini_agent/skills)
                search_paths = [
                    skills_path,  # ./skills for backward compatibility
                    Path("mini_agent") / skills_path,  # ./mini_agent/skills
                    Config.get_package_dir()
                    / skills_path,  # site-packages/mini_agent/skills
                ]

                # Find first existing path
                skills_dir = str(skills_path)  # default
                for path in search_paths:
                    if path.exists():
                        skills_dir = str(path.resolve())
                        break

            skill_tools, skill_loader = create_skill_tools(skills_dir)
            if skill_tools:
                tools.extend(skill_tools)
                print(f"{Colors.GREEN}✅ Loaded Skill tool (get_skill){Colors.RESET}")
            else:
                print(f"{Colors.YELLOW}⚠️  No available Skills found{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.YELLOW}⚠️  Failed to load Skills: {e}{Colors.RESET}")

    # 4. MCP tools (loaded with priority search)
    if config.tools.enable_mcp:
        print(f"{Colors.BRIGHT_CYAN}Loading MCP tools...{Colors.RESET}")
        try:
            # Apply MCP timeout configuration from config.yaml
            mcp_config = config.tools.mcp
            set_mcp_timeout_config(
                connect_timeout=mcp_config.connect_timeout,
                execute_timeout=mcp_config.execute_timeout,
                sse_read_timeout=mcp_config.sse_read_timeout,
            )
            print(
                f"{Colors.DIM}  MCP timeouts: connect={mcp_config.connect_timeout}s, "
                f"execute={mcp_config.execute_timeout}s, sse_read={mcp_config.sse_read_timeout}s{Colors.RESET}"
            )

            # Use priority search for mcp.json
            mcp_config_path = Config.find_config_file(config.tools.mcp_config_path)
            if mcp_config_path:
                mcp_tools = await load_mcp_tools_async(str(mcp_config_path))
                if mcp_tools:
                    tools.extend(mcp_tools)
                    print(
                        f"{Colors.GREEN}✅ Loaded {len(mcp_tools)} MCP tools (from: {mcp_config_path}){Colors.RESET}"
                    )
                else:
                    print(
                        f"{Colors.YELLOW}⚠️  No available MCP tools found{Colors.RESET}"
                    )
            else:
                print(
                    f"{Colors.YELLOW}⚠️  MCP config file not found: {config.tools.mcp_config_path}{Colors.RESET}"
                )
        except Exception as e:
            print(f"{Colors.YELLOW}⚠️  Failed to load MCP tools: {e}{Colors.RESET}")

    print()  # Empty line separator
    return tools, skill_loader


def add_workspace_tools(
    tools: List[Tool],
    config: Config,
    workspace_dir: Path,
    sandbox_dir: Path | None = None,
    enable_sandbox: bool = True,
):
    """Add workspace-dependent tools

    These tools need to know the workspace directory.

    Args:
        tools: Existing tools list to add to
        config: Configuration object
        workspace_dir: Workspace directory path
        sandbox_dir: Directory for Jupyter sandbox (if sandbox enabled)
        enable_sandbox: Whether to enable sandbox tools
    """
    # Ensure workspace directory exists
    workspace_dir.mkdir(parents=True, exist_ok=True)

    # Bash tool - needs workspace as cwd for command execution
    if config.tools.enable_bash:
        bash_tool = BashTool(workspace_dir=str(workspace_dir))
        tools.append(bash_tool)
        print(f"{Colors.GREEN}✅ Loaded Bash tool (cwd: {workspace_dir}){Colors.RESET}")

    # File tools - need workspace to resolve relative paths
    if config.tools.enable_file_tools:
        tools.extend(
            [
                ReadTool(workspace_dir=str(workspace_dir)),
                WriteTool(workspace_dir=str(workspace_dir)),
                EditTool(workspace_dir=str(workspace_dir)),
            ]
        )
        print(
            f"{Colors.GREEN}✅ Loaded file operation tools (workspace: {workspace_dir}){Colors.RESET}"
        )

    # Session note tool - needs workspace to store memory file
    if config.tools.enable_note:
        tools.append(
            SessionNoteTool(memory_file=str(workspace_dir / ".agent_memory.json"))
        )
        print(f"{Colors.GREEN}✅ Loaded session note tool{Colors.RESET}")

    # Sandbox tools - Jupyter-based Python code execution
    if enable_sandbox and sandbox_dir:
        execute_code_tool = ExecuteCodeTool(str(sandbox_dir))
        tools.append(execute_code_tool)
        print(
            f"{Colors.GREEN}✅ Loaded execute_code tool (sandbox: {sandbox_dir}){Colors.RESET}"
        )

        # Multi-sandbox for parallel analysis
        multi_sandbox_tool = MultiSandboxTool(str(sandbox_dir))
        tools.append(multi_sandbox_tool)
        print(
            f"{Colors.GREEN}✅ Loaded multi_sandbox tool (parallel sessions){Colors.RESET}"
        )


async def _quiet_cleanup(execute_code_tool=None):
    """Clean up MCP connections and sandbox, suppressing noisy asyncgen teardown tracebacks."""
    loop = asyncio.get_event_loop()
    loop.set_exception_handler(lambda _loop, _ctx: None)
    try:
        await cleanup_mcp_connections()
    except Exception:
        pass
    if execute_code_tool:
        try:
            await execute_code_tool.cleanup()
        except Exception:
            pass


async def validate_api_key(
    api_key: str, provider: str, api_base: str, model: str
) -> tuple[bool, str]:
    """Validate API key by making a test call."""
    from mini_box_agent.schema import LLMProvider, Message
    from mini_box_agent.llm import LLMClient
    from mini_box_agent.retry import RetryConfig

    try:
        retry_config = RetryConfig(enabled=False)
        client = LLMClient(
            api_key=api_key,
            provider=LLMProvider.ANTHROPIC
            if provider == "anthropic"
            else LLMProvider.OPENAI,
            api_base=api_base,
            model=model,
            retry_config=retry_config,
        )
        await client.generate([Message(role="user", content="hi")])
        return True, "Validation successful"
    except Exception as e:
        return False, str(e)


async def setup_config_interactive() -> Config | None:
    """Interactive configuration setup when no config is found."""
    import yaml

    user_config_dir = Path.home() / ".mini-box-agent" / "config"
    user_config_file = user_config_dir / "config.yaml"
    example_config = Config.get_package_dir() / "config" / "config-example.yaml"

    print(f"{Colors.YELLOW}📋 No configuration file found{Colors.RESET}")
    print()
    print(f"{Colors.BRIGHT_CYAN}🚀 Mini-Box Setup:{Colors.RESET}")
    print(f"  I'll create config at {user_config_dir}")
    print()

    print(f"{Colors.BRIGHT_CYAN}1. Select Provider:{Colors.RESET}")
    print(f"  {Colors.GREEN}1){Colors.RESET} Anthropic")
    print(f"  {Colors.GREEN}2){Colors.RESET} OpenAI")
    print()

    choice = (
        input(f"{Colors.BRIGHT_GREEN}Enter choice (1/2) [1]: {Colors.RESET}").strip()
        or "1"
    )

    if choice == "2":
        provider = "openai"
        api_base = input(
            f"{Colors.BRIGHT_GREEN}2. Enter API Base URL [https://api.openai.com/v1]: {Colors.RESET}"
        ).strip()
        if not api_base:
            api_base = "https://api.openai.com/v1"
        print(f"  Using OpenAI provider with {api_base}")
        print()
        print(f"{Colors.BRIGHT_CYAN}3. Select Model:{Colors.RESET}")
        print(f"  {Colors.GREEN}1){Colors.RESET} gpt-4o (default)")
        print(f"  {Colors.GREEN}2){Colors.RESET} gpt-4-turbo")
        print(f"  {Colors.GREEN}3){Colors.RESET} gpt-3.5-turbo")
        print(f"  {Colors.GREEN}4){Colors.RESET} custom")
        model_choice = (
            input(
                f"{Colors.BRIGHT_GREEN}Enter choice (1-4) [1]: {Colors.RESET}"
            ).strip()
            or "1"
        )
        if model_choice == "2":
            model = "gpt-4-turbo"
        elif model_choice == "3":
            model = "gpt-3.5-turbo"
        elif model_choice == "4":
            model = input(
                f"{Colors.BRIGHT_GREEN}Enter model name: {Colors.RESET}"
            ).strip()
            if not model:
                model = "gpt-4o"
        else:
            model = "gpt-4o"
    else:
        provider = "anthropic"
        api_base = input(
            f"{Colors.BRIGHT_GREEN}2. Enter API Base URL [https://api.anthropic.com]: {Colors.RESET}"
        ).strip()
        if not api_base:
            api_base = "https://api.anthropic.com"
        print(f"  Using Anthropic provider with {api_base}")
        print()
        print(f"{Colors.BRIGHT_CYAN}3. Select Model:{Colors.RESET}")
        print(f"  {Colors.GREEN}1){Colors.RESET} claude-3-5-sonnet (default)")
        print(f"  {Colors.GREEN}2){Colors.RESET} claude-3-opus")
        print(f"  {Colors.GREEN}3){Colors.RESET} claude-3-haiku")
        print(f"  {Colors.GREEN}4){Colors.RESET} custom")
        model_choice = (
            input(
                f"{Colors.BRIGHT_GREEN}Enter choice (1-4) [1]: {Colors.RESET}"
            ).strip()
            or "1"
        )
        if model_choice == "2":
            model = "claude-3-opus"
        elif model_choice == "3":
            model = "claude-3-haiku"
        elif model_choice == "4":
            model = input(
                f"{Colors.BRIGHT_GREEN}Enter model name: {Colors.RESET}"
            ).strip()
            if not model:
                model = "claude-3-5-sonnet"
        else:
            model = "claude-3-5-sonnet"
    print()
    print(f"  Using model: {model}")
    print()

    api_key = getpass(
        f"{Colors.BRIGHT_GREEN}4. Enter your API Key: {Colors.RESET}"
    ).strip()

    if not api_key:
        print(f"{Colors.RED}❌ API Key is required{Colors.RESET}")
        return None

    print()
    print(f"{Colors.BRIGHT_CYAN}5. Validating API Key...{Colors.RESET}")

    valid, msg = await validate_api_key(api_key, provider, api_base, model)

    if not valid:
        print(f"{Colors.RED}❌ Validation failed: {msg}{Colors.RESET}")
        return None

    print(f"{Colors.GREEN}✅ {msg}{Colors.RESET}")
    print()

    user_config_dir.mkdir(parents=True, exist_ok=True)

    with open(example_config, encoding="utf-8") as f:
        config_data = yaml.safe_load(f)

    config_data["api_key"] = api_key
    config_data["provider"] = provider
    config_data["api_base"] = api_base
    config_data["model"] = model

    with open(user_config_file, "w", encoding="utf-8") as f:
        yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)

    print(f"{Colors.GREEN}✅ Configuration saved to {user_config_file}{Colors.RESET}")
    print()

    return Config.from_yaml(user_config_file)


async def run_agent(workspace_dir: Path, task: str = None, sandbox: bool = True):
    """Run Agent in interactive or non-interactive mode.

    Args:
        workspace_dir: Workspace directory path
        task: If provided, execute this task and exit (non-interactive mode)
    """
    session_start = datetime.now()

    # 1. Load configuration
    config_path = Config.find_config_file("config.yaml")

    config = None
    if not config_path:
        config = await setup_config_interactive()
        if config is None:
            return
        config_path = Config.find_config_file("config.yaml")
    else:
        try:
            config = Config.from_yaml(config_path)
        except ValueError as e:
            print(f"{Colors.RED}❌ Error: {e}{Colors.RESET}")
            print(
                f"{Colors.YELLOW}Please check the configuration file format{Colors.RESET}"
            )
            return
        except Exception as e:
            print(
                f"{Colors.RED}❌ Error: Failed to load configuration file: {e}{Colors.RESET}"
            )
            return

    if not config.llm.api_key or config.llm.api_key == "YOUR_API_KEY_HERE":
        print(f"{Colors.RED}❌ API Key not configured{Colors.RESET}")
        config = await setup_config_interactive()
        if config is None:
            return
        config_path = Config.find_config_file("config.yaml")
    else:
        print(f"{Colors.CYAN}🔑 Validating API Key...{Colors.RESET}")
        valid, msg = await validate_api_key(
            config.llm.api_key,
            config.llm.provider,
            config.llm.api_base,
            config.llm.model,
        )
        if not valid:
            print(f"{Colors.YELLOW}⚠️  API Key validation failed: {msg}{Colors.RESET}")
            print(f"{Colors.YELLOW}Please re-enter your configuration{Colors.RESET}")
            config = await setup_config_interactive()
            if config is None:
                return
            config_path = Config.find_config_file("config.yaml")
        else:
            print(f"{Colors.GREEN}✅ API Key valid{Colors.RESET}")
            print()

    # 2. Initialize LLM client
    from mini_box_agent.retry import RetryConfig as RetryConfigBase

    # Convert configuration format
    retry_config = RetryConfigBase(
        enabled=config.llm.retry.enabled,
        max_retries=config.llm.retry.max_retries,
        initial_delay=config.llm.retry.initial_delay,
        max_delay=config.llm.retry.max_delay,
        exponential_base=config.llm.retry.exponential_base,
        retryable_exceptions=(Exception,),
    )

    # Create retry callback function to display retry information in terminal
    def on_retry(exception: Exception, attempt: int):
        """Retry callback function to display retry information"""
        print(
            f"\n{Colors.BRIGHT_YELLOW}⚠️  LLM call failed (attempt {attempt}): {str(exception)}{Colors.RESET}"
        )
        next_delay = retry_config.calculate_delay(attempt - 1)
        print(
            f"{Colors.DIM}   Retrying in {next_delay:.1f}s (attempt {attempt + 1})...{Colors.RESET}"
        )

    # Convert provider string to LLMProvider enum
    provider = (
        LLMProvider.ANTHROPIC
        if config.llm.provider.lower() == "anthropic"
        else LLMProvider.OPENAI
    )

    llm_client = LLMClient(
        api_key=config.llm.api_key,
        provider=provider,
        api_base=config.llm.api_base,
        model=config.llm.model,
        retry_config=retry_config if config.llm.retry.enabled else None,
    )

    # Set retry callback
    if config.llm.retry.enabled:
        llm_client.retry_callback = on_retry
        print(
            f"{Colors.GREEN}✅ LLM retry mechanism enabled (max {config.llm.retry.max_retries} retries){Colors.RESET}"
        )

    # 3. Initialize base tools (independent of workspace)
    tools, skill_loader = await initialize_base_tools(config)

    # 4. Setup sandbox directory if enabled
    sandbox_dir = None
    execute_code_tool = None
    if sandbox:
        sandbox_dir = Path.home() / ".mini-box-agent" / "sandbox" / str(uuid.uuid4())
        sandbox_dir.mkdir(parents=True, exist_ok=True)

        # Check for previous session artifacts
        if sandbox_dir.exists() and any(sandbox_dir.iterdir()):
            print(
                f"{Colors.YELLOW}⚠️  Previous sandbox session detected. Variables from last session are lost.{Colors.RESET}"
            )

        print(f"{Colors.BRIGHT_CYAN}🔒 Sandbox enabled: {sandbox_dir}{Colors.RESET}")

    # 5. Add workspace-dependent tools
    add_workspace_tools(tools, config, workspace_dir, sandbox_dir, sandbox)

    # Track execute_code_tool and multi_sandbox_tool for cleanup if sandbox was enabled
    execute_code_tool = None
    multi_sandbox_tool = None
    if sandbox:
        execute_code_tool = next(
            (t for t in tools if isinstance(t, ExecuteCodeTool)), None
        )
        multi_sandbox_tool = next(
            (t for t in tools if isinstance(t, MultiSandboxTool)), None
        )

    # 5. Load System Prompt (with priority search)
    system_prompt_path = Config.find_config_file(config.agent.system_prompt_path)
    if system_prompt_path and system_prompt_path.exists():
        system_prompt = system_prompt_path.read_text(encoding="utf-8")
        print(
            f"{Colors.GREEN}✅ Loaded system prompt (from: {system_prompt_path}){Colors.RESET}"
        )
    else:
        system_prompt = "You are Mini-Agent, an intelligent assistant powered by MiniMax M2.5 that can help users complete various tasks."
        print(f"{Colors.YELLOW}⚠️  System prompt not found, using default{Colors.RESET}")

    # 6. Inject Skills Metadata into System Prompt (Progressive Disclosure - Level 1)
    if skill_loader:
        skills_metadata = skill_loader.get_skills_metadata_prompt()
        if skills_metadata:
            # Replace placeholder with actual metadata
            system_prompt = system_prompt.replace("{SKILLS_METADATA}", skills_metadata)
            print(
                f"{Colors.GREEN}✅ Injected {len(skill_loader.loaded_skills)} skills metadata into system prompt{Colors.RESET}"
            )
        else:
            # Remove placeholder if no skills
            system_prompt = system_prompt.replace("{SKILLS_METADATA}", "")
    else:
        # Remove placeholder if skills not enabled
        system_prompt = system_prompt.replace("{SKILLS_METADATA}", "")

    # Append sandbox warning if enabled
    if sandbox:
        sandbox_warning = (
            "\n\n[Sandbox Limitation] "
            "When using execute_code tool: Python variables only persist within the same CLI session. "
            "If kernel restarts or you start a new session, re-initialize all variables. "
            "The /clear command resets both conversation history and kernel state."
        )
        system_prompt += sandbox_warning

    # 7. Create Agent
    agent = Agent(
        llm_client=llm_client,
        system_prompt=system_prompt,
        tools=tools,
        max_steps=config.agent.max_steps,
        workspace_dir=str(workspace_dir),
    )

    # 8. Display welcome information
    if not task:
        print_banner()
        print_session_info(agent, workspace_dir, config.llm.model)

    # 8.5 Non-interactive mode: execute task and exit
    if task:
        print(
            f"\n{Colors.BRIGHT_BLUE}Agent{Colors.RESET} {Colors.DIM}›{Colors.RESET} {Colors.DIM}Executing task...{Colors.RESET}\n"
        )
        agent.add_user_message(task)
        try:
            await agent.run()
        except Exception as e:
            print(f"\n{Colors.RED}❌ Error: {e}{Colors.RESET}")
        finally:
            print_stats(agent, session_start)

        # Cleanup MCP connections and sandbox
        await _quiet_cleanup(execute_code_tool)
        return

    # 9. Setup prompt_toolkit session
    # Command completer
    command_completer = WordCompleter(
        ["/help", "/clear", "/history", "/stats", "/log", "/exit", "/quit", "/q"],
        ignore_case=True,
        sentence=True,
    )

    # Custom style for prompt
    prompt_style = Style.from_dict(
        {
            "prompt": "#00ff00 bold",  # Green and bold
            "separator": "#666666",  # Gray
        }
    )

    # Custom key bindings
    kb = KeyBindings()

    @kb.add("c-u")  # Ctrl+U: Clear current line
    def _(event):
        """Clear the current input line"""
        event.current_buffer.reset()

    @kb.add("c-l")  # Ctrl+L: Clear screen (optional bonus)
    def _(event):
        """Clear the screen"""
        event.app.renderer.clear()

    @kb.add("c-j")  # Ctrl+J (对应 Ctrl+Enter)
    def _(event):
        """Insert a newline"""
        event.current_buffer.insert_text("\n")

    # Create prompt session with history and auto-suggest
    # Use FileHistory for persistent history across sessions (stored in user's home directory)
    history_file = Path.home() / ".mini-box-agent" / ".history"
    history_file.parent.mkdir(parents=True, exist_ok=True)
    session = PromptSession(
        history=FileHistory(str(history_file)),
        auto_suggest=AutoSuggestFromHistory(),
        completer=command_completer,
        style=prompt_style,
        key_bindings=kb,
    )

    # 10. Interactive loop
    while True:
        try:
            # Get user input using prompt_toolkit
            user_input = await session.prompt_async(
                [
                    ("class:prompt", "You"),
                    ("", " › "),
                ],
                multiline=False,
                enable_history_search=True,
            )
            user_input = user_input.strip()

            if not user_input:
                continue

            # Handle commands
            if user_input.startswith("/"):
                command = user_input.lower()

                if command in ["/exit", "/quit", "/q"]:
                    print(
                        f"\n{Colors.BRIGHT_YELLOW}👋 Goodbye! Thanks for using Mini Agent{Colors.RESET}\n"
                    )
                    print_stats(agent, session_start)
                    break

                elif command == "/help":
                    print_help()
                    continue

                elif command == "/clear":
                    # Clear message history but keep system prompt
                    old_count = len(agent.messages)
                    agent.messages = [agent.messages[0]]  # Keep only system message
                    # Also reset sandbox to maintain consistency
                    if execute_code_tool:
                        await execute_code_tool.reset()
                        print(
                            f"{Colors.GREEN}✅ Cleared {old_count - 1} messages and reset sandbox{Colors.RESET}\n"
                        )
                    else:
                        print(
                            f"{Colors.GREEN}✅ Cleared {old_count - 1} messages, starting new session{Colors.RESET}\n"
                        )
                    continue

                elif command == "/history":
                    print(
                        f"\n{Colors.BRIGHT_CYAN}Current session message count: {len(agent.messages)}{Colors.RESET}\n"
                    )
                    continue

                elif command == "/stats":
                    print_stats(agent, session_start)
                    continue

                elif command == "/log" or command.startswith("/log "):
                    # Parse /log command
                    parts = user_input.split(maxsplit=1)
                    if len(parts) == 1:
                        # /log - show log directory
                        show_log_directory(open_file_manager=True)
                    else:
                        # /log <filename> - read specific log file
                        filename = parts[1].strip("\"'")
                        read_log_file(filename)
                    continue

                elif command == "/sandbox" or command.startswith("/sandbox "):
                    # Parse /sandbox command
                    if not multi_sandbox_tool:
                        print(f"{Colors.RED}❌ Sandbox not enabled{Colors.RESET}")
                        continue

                    parts = user_input.split(maxsplit=1)
                    if len(parts) == 1:
                        # /sandbox - show status
                        sessions = await multi_sandbox_tool.manager.list_sessions()
                        print(f"{Colors.BRIGHT_CYAN}Sandbox Sessions:{Colors.RESET}")
                        if sessions:
                            for sid in sessions:
                                print(f"  - {sid}")
                        else:
                            print("  No active sessions")
                        print(f"\nSandbox directory: {multi_sandbox_tool.base_dir}")
                    else:
                        # /sandbox <action> [args]
                        sub_parts = parts[1].split(maxsplit=2)
                        action = sub_parts[0]

                        if action == "create":
                            result = await multi_sandbox_tool.execute(action="create")
                            print(f"{Colors.GREEN}✅ {result.content}{Colors.RESET}")
                        elif action == "list":
                            result = await multi_sandbox_tool.execute(action="list")
                            print(f"{Colors.CYAN}{result.content}{Colors.RESET}")
                        elif action == "close":
                            if len(sub_parts) < 2:
                                print(
                                    f"{Colors.YELLOW}Usage: /sandbox close <session_id>{Colors.RESET}"
                                )
                            else:
                                session_id = sub_parts[1]
                                result = await multi_sandbox_tool.execute(
                                    action="close", session_id=session_id
                                )
                                print(
                                    f"{Colors.GREEN}✅ {result.content}{Colors.RESET}"
                                )
                        elif action == "close_all":
                            result = await multi_sandbox_tool.execute(
                                action="close_all"
                            )
                            print(f"{Colors.GREEN}✅ {result.content}{Colors.RESET}")
                        else:
                            print(
                                f"{Colors.RED}❌ Unknown action: {action}{Colors.RESET}"
                            )
                            print(
                                f"  Actions: create, list, close <session_id>, close_all{Colors.RESET}"
                            )
                    continue

                else:
                    print(f"{Colors.RED}❌ Unknown command: {user_input}{Colors.RESET}")
                    print(
                        f"{Colors.DIM}Type /help to see available commands{Colors.RESET}\n"
                    )
                    continue

            # Normal conversation - exit check
            if user_input.lower() in ["exit", "quit", "q"]:
                print(
                    f"\n{Colors.BRIGHT_YELLOW}👋 Goodbye! Thanks for using Mini Agent{Colors.RESET}\n"
                )
                print_stats(agent, session_start)
                break

            # Run Agent with Esc cancellation support
            print(
                f"\n{Colors.BRIGHT_BLUE}Agent{Colors.RESET} {Colors.DIM}›{Colors.RESET} {Colors.DIM}Thinking... (Esc to cancel){Colors.RESET}\n"
            )
            agent.add_user_message(user_input)

            # Create cancellation event
            cancel_event = asyncio.Event()
            agent.cancel_event = cancel_event

            # Esc key listener thread
            esc_listener_stop = threading.Event()
            esc_cancelled = [False]  # Mutable container for thread access

            def esc_key_listener():
                """Listen for Esc key in a separate thread."""
                if platform.system() == "Windows":
                    try:
                        import msvcrt

                        while not esc_listener_stop.is_set():
                            if msvcrt.kbhit():
                                char = msvcrt.getch()
                                if char == b"\x1b":  # Esc
                                    print(
                                        f"\n{Colors.BRIGHT_YELLOW}⏹️  Esc pressed, cancelling...{Colors.RESET}"
                                    )
                                    esc_cancelled[0] = True
                                    cancel_event.set()
                                    break
                            esc_listener_stop.wait(0.05)
                    except Exception:
                        pass
                    return

                # Unix/macOS
                try:
                    import select
                    import termios
                    import tty

                    fd = sys.stdin.fileno()
                    old_settings = termios.tcgetattr(fd)

                    try:
                        tty.setcbreak(fd)
                        while not esc_listener_stop.is_set():
                            rlist, _, _ = select.select([sys.stdin], [], [], 0.05)
                            if rlist:
                                char = sys.stdin.read(1)
                                if char == "\x1b":  # Esc
                                    print(
                                        f"\n{Colors.BRIGHT_YELLOW}⏹️  Esc pressed, cancelling...{Colors.RESET}"
                                    )
                                    esc_cancelled[0] = True
                                    cancel_event.set()
                                    break
                    finally:
                        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                except Exception:
                    pass

            # Start Esc listener thread
            esc_thread = threading.Thread(target=esc_key_listener, daemon=True)
            esc_thread.start()

            # Run agent with periodic cancellation check
            try:
                agent_task = asyncio.create_task(agent.run())

                # Poll for cancellation while agent runs
                while not agent_task.done():
                    if esc_cancelled[0]:
                        cancel_event.set()
                    await asyncio.sleep(0.1)

                # Get result
                _ = agent_task.result()

            except asyncio.CancelledError:
                print(
                    f"\n{Colors.BRIGHT_YELLOW}⚠️  Agent execution cancelled{Colors.RESET}"
                )
            finally:
                agent.cancel_event = None
                esc_listener_stop.set()
                esc_thread.join(timeout=0.2)

            # Visual separation
            print(f"\n{Colors.DIM}{'─' * 60}{Colors.RESET}\n")

        except KeyboardInterrupt:
            print(
                f"\n\n{Colors.BRIGHT_YELLOW}👋 Interrupt signal detected, exiting...{Colors.RESET}\n"
            )
            print_stats(agent, session_start)
            break

        except Exception as e:
            print(f"\n{Colors.RED}❌ Error: {e}{Colors.RESET}")
            print(f"{Colors.DIM}{'─' * 60}{Colors.RESET}\n")

    # 11. Cleanup MCP connections and sandbox
    await _quiet_cleanup(execute_code_tool)


def main():
    """Main entry point for CLI"""
    # Parse command line arguments
    args = parse_args()

    # Handle log subcommand
    if args.command == "log":
        if args.filename:
            read_log_file(args.filename)
        else:
            show_log_directory(open_file_manager=True)
        return

    # Handle --validate flag
    if args.validate:
        config_path = Config.find_config_file("config.yaml")
        if not config_path:
            print(f"{Colors.RED}❌ No configuration file found{Colors.RESET}")
            return

        try:
            config = Config.from_yaml(config_path)
        except Exception as e:
            print(f"{Colors.RED}❌ Failed to load config: {e}{Colors.RESET}")
            return

        print(f"{Colors.CYAN}🔑 Validating API Key...{Colors.RESET}")
        valid, msg = asyncio.run(
            validate_api_key(
                config.llm.api_key,
                config.llm.provider,
                config.llm.api_base,
                config.llm.model,
            )
        )

        if valid:
            print(f"{Colors.GREEN}✅ {msg}{Colors.RESET}")
        else:
            print(f"{Colors.RED}❌ Validation failed: {msg}{Colors.RESET}")
        return

    # Determine workspace directory
    # Expand ~ to user home directory for portability
    if args.workspace:
        workspace_dir = Path(args.workspace).expanduser().absolute()
    else:
        # Use current working directory
        workspace_dir = Path.cwd()

    # Ensure workspace directory exists
    workspace_dir.mkdir(parents=True, exist_ok=True)

    # Run the agent (config always loaded from package directory)
    asyncio.run(run_agent(workspace_dir, task=args.task, sandbox=args.sandbox))


if __name__ == "__main__":
    main()
