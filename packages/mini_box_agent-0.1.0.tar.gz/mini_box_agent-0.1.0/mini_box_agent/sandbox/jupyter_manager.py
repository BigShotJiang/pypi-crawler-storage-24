"""Jupyter server lifecycle management."""

import asyncio
import logging
import re
import shutil
from pathlib import Path
from typing import Optional, Union

logger = logging.getLogger(__name__)


class JupyterManager:
    """Manages the jupyter_server process lifecycle."""

    def __init__(
        self, sandbox_dir: Union[str, Path], python_path: Optional[str] = None
    ):
        self.sandbox_dir = (
            Path(sandbox_dir) if isinstance(sandbox_dir, str) else sandbox_dir
        )
        self.python_path = python_path
        self.port: Optional[int] = None
        self.token: Optional[str] = None
        self.base_url: Optional[str] = None
        self.process: Optional[asyncio.subprocess.Process] = None
        self._started = False

    @property
    def is_started(self) -> bool:
        return self._started and self.process is not None

    async def start(self) -> str:
        """Start jupyter_server and return the base URL with token."""
        if self._started:
            return self.base_url  # type: ignore

        if self.python_path:
            python_exe = Path(self.python_path)
            jupyter_path = str(python_exe.parent / "jupyter")
        else:
            import sys

            venv_bin = Path(sys.executable).parent
            jupyter_path = str(venv_bin / "jupyter")

        if not Path(jupyter_path).exists():
            raise RuntimeError(
                "jupyter command not found. Install with: pip install jupyter"
            )

        cmd = [
            jupyter_path,
            "server",
            "--ServerApp.disable_check_xsrf=True",
            "--ServerApp.allow_origin=*",
            "--no-browser",
            "--ServerApp.root_dir=" + str(self.sandbox_dir),
        ]

        logger.info(f"Starting jupyter_server in {self.sandbox_dir}")

        self.sandbox_dir.mkdir(parents=True, exist_ok=True)

        self.process = await asyncio.create_subprocess_exec(
            *cmd,
            stderr=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
        )

        stderr_lines = []
        all_output = []

        while True:
            line = await self.process.stderr.readline()
            if not line:
                break
            decoded = line.decode("utf-8", errors="replace")
            stderr_lines.append(decoded)
            all_output.append(decoded)
            logger.debug(f"jupyter stderr: {decoded.strip()}")

            url_match = re.search(r"(http://[^\s]+)", decoded)
            if url_match:
                url = url_match.group(1)
                port_match = re.search(r":(\d+)", url)
                token_match = re.search(r"token=([a-zA-Z0-9_-]+)", url)
                if port_match and not self.port:
                    self.port = int(port_match.group(1))
                if token_match and not self.token:
                    self.token = token_match.group(1)

            if self.port and self.token:
                break

        if not self.port or not self.token:
            stderr_text = "".join(stderr_lines[-20:])
            logger.error(f"Jupyter stderr: {stderr_text}")

        if not self.port or not self.token:
            stderr_text = "".join(stderr_lines[-20:])
            logger.error(f"Jupyter stderr: {stderr_text}")
            raise RuntimeError(
                f"Failed to extract port/token from jupyter_server. "
                f"port={self.port}, token={self.token}"
            )

        self.base_url = f"http://localhost:{self.port}?token={self.token}"
        self._started = True
        logger.info(f"Jupyter server started at {self.base_url}")
        return self.base_url

    async def stop(self):
        """Stop the jupyter_server process."""
        if self.process:
            logger.info("Stopping jupyter_server")
            self.process.terminate()
            try:
                await asyncio.wait_for(self.process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                logger.warning("Jupyter server did not stop gracefully, killing")
                self.process.kill()
                await self.process.wait()
            self.process = None
            self._started = False
            logger.info("Jupyter server stopped")

    def get_connection_info(self) -> dict:
        """Get connection info for kernel manager."""
        if not self.is_started:
            raise RuntimeError("Jupyter server not started")
        return {
            "url": f"http://localhost:{self.port}",
            "token": self.token,
            "base_url": self.base_url,
        }
