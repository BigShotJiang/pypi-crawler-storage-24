"""Sandbox manager for multiple independent sessions."""

import asyncio
import uuid
from pathlib import Path
from typing import Optional

from mini_box_agent.sandbox.jupyter_manager import JupyterManager
from mini_box_agent.sandbox.kernel_manager import KernelManager


class SandboxSession:
    """A single sandbox session with its own kernel and directory."""

    def __init__(
        self, session_id: str, base_dir: Path, python_path: Optional[str] = None
    ):
        self.session_id = session_id
        self.base_dir = base_dir / session_id
        self.python_path = python_path
        self.jupyter_manager = JupyterManager(
            str(self.base_dir), python_path=python_path
        )
        self.kernel_manager: Optional[KernelManager] = None
        self._initialized = False

    async def initialize(self, timeout: int = 300, memory_limit_mb: int = 512):
        """Initialize the sandbox session."""
        await self.jupyter_manager.start()
        conn_info = self.jupyter_manager.get_connection_info()
        self.kernel_manager = KernelManager(
            connection_info=conn_info,
            timeout=timeout,
            memory_limit_mb=memory_limit_mb,
            python_path=self.python_path,
        )
        await self.kernel_manager.start_kernel()
        self._initialized = True

        # Pre-warm kernel with common imports and settings
        warmup_code = (
            "import pandas as pd\n"
            "import numpy as np\n"
            "import matplotlib.pyplot as plt\n"
            "plt.rcParams['figure.figsize'] = (10, 6)\n"
            "plt.rcParams['font.size'] = 12\n"
            "_ = np.random.default_rng()\n"
        )
        try:
            await self.kernel_manager.execute_code(warmup_code)
        except Exception:
            pass  # Warmup failure is non-fatal

    async def execute(self, code: str) -> dict:
        """Execute code in this sandbox session."""
        if not self._initialized:
            await self.initialize()
        return await self.kernel_manager.execute_code(code)

    async def cleanup(self):
        """Clean up this sandbox session."""
        if self.kernel_manager:
            await self.kernel_manager.close()
        await self.jupyter_manager.stop()
        self._initialized = False


class SandboxManager:
    """Manages multiple independent sandbox sessions."""

    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = (
            Path(base_dir) if base_dir else Path.home() / ".mini-box-agent" / "sandbox"
        )
        self.sessions: dict[str, SandboxSession] = {}
        self._lock = asyncio.Lock()
        self._python_path: Optional[str] = None

    def _get_python_path(self) -> Optional[str]:
        """Get the sandbox Python path, creating venv if needed."""
        if self._python_path:
            return self._python_path
        try:
            from mini_box_agent.utils.sandbox_venv import get_sandbox_python

            self._python_path = get_sandbox_python()
            return self._python_path
        except Exception:
            return None

    async def create_session(self, session_id: Optional[str] = None) -> str:
        """Create a new sandbox session and return its ID."""
        if session_id is None:
            session_id = str(uuid.uuid4())[:8]

        python_path = self._get_python_path()

        async with self._lock:
            if session_id in self.sessions:
                raise ValueError(f"Session {session_id} already exists")

            session = SandboxSession(session_id, self.base_dir, python_path=python_path)
            await session.initialize()
            self.sessions[session_id] = session

        return session_id

    async def get_session(self, session_id: str) -> Optional[SandboxSession]:
        """Get a sandbox session by ID."""
        return self.sessions.get(session_id)

    async def execute_in_session(self, session_id: str, code: str) -> dict:
        """Execute code in a specific session."""
        session = self.sessions.get(session_id)
        if not session:
            raise ValueError(f"Session {session_id} not found")
        return await session.execute(code)

    async def close_session(self, session_id: str):
        """Close and remove a specific session."""
        async with self._lock:
            session = self.sessions.pop(session_id, None)
            if session:
                await session.cleanup()

    async def close_all(self):
        """Close all sandbox sessions."""
        async with self._lock:
            for session in self.sessions.values():
                await session.cleanup()
            self.sessions.clear()

    async def list_sessions(self) -> list[str]:
        """List all active session IDs."""
        return list(self.sessions.keys())
