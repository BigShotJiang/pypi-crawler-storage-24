"""Jupyter sandbox code execution tools."""

import base64
import re
from typing import Any

from mini_box_agent.tools.base import Tool, ToolResult
from mini_box_agent.sandbox.jupyter_manager import JupyterManager
from mini_box_agent.sandbox.kernel_manager import KernelManager, DANGEROUS_PATTERNS


class ExecuteCodeTool(Tool):
    """Executes Python code in a Jupyter sandbox environment."""

    def __init__(
        self, sandbox_dir: str, timeout: int = 300, memory_limit_mb: int = 512
    ):
        self.sandbox_dir = sandbox_dir
        self.timeout = timeout
        self.memory_limit_mb = memory_limit_mb
        self.jupyter_manager = JupyterManager(sandbox_dir)
        self.kernel_manager: KernelManager | None = None
        self._initialized = False
        self._kernel_restarted = False

    @property
    def name(self) -> str:
        return "execute_code"

    @property
    def description(self) -> str:
        return (
            "Executes Python code in a Jupyter sandbox with pandas, numpy, matplotlib, seaborn, and scipy. "
            "The sandbox directory is isolated from the host system. "
            "Kernel state persists across multiple execute_code calls within the same session, "
            "but if the kernel restarts (e.g., due to crash), all Python variables are lost and must be re-initialized. "
            "Probing principle: read 5 rows first before full operations to understand data structure. "
            "Security: dangerous commands (os, subprocess, eval, exec, sys.exit) are blocked. "
            "Timeout: code execution is limited to 300 seconds per call. "
            "Returns: stdout, stderr, images (base64 encoded), and error info if any."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Python code to execute in the sandbox. "
                    "Use print() to output results as the kernel does not auto-display. "
                    "If kernel was restarted, re-initialize all variables. "
                    "Dangerous commands (os, subprocess, eval, exec) are blocked.",
                },
                "purpose": {
                    "type": "string",
                    "description": "What you intend to do with the output (e.g., 'understand data structure', 'visualize results').",
                },
            },
            "required": ["code"],
        }

    async def _ensure_initialized(self):
        if not self._initialized:
            await self.jupyter_manager.start()
            conn_info = self.jupyter_manager.get_connection_info()
            self.kernel_manager = KernelManager(
                connection_info=conn_info,
                timeout=self.timeout,
                memory_limit_mb=self.memory_limit_mb,
            )
            await self.kernel_manager.start_kernel()
            self._initialized = True
            self._kernel_restarted = False

            # Pre-warm kernel with common imports and settings
            warmup_code = (
                "import pandas as pd\n"
                "import numpy as np\n"
                "import matplotlib.pyplot as plt\n"
                "plt.rcParams['figure.figsize'] = (10, 6)\n"
                "plt.rcParams['font.size'] = 12\n"
                "_ = np.random.default_rng()\n"
            )
            try:
                await self.kernel_manager.execute_code(warmup_code)
            except Exception:
                pass  # Warmup failure is non-fatal

    def _sanitize_path(self, code: str) -> str:
        sandbox_pattern = r"sandbox:/([^/\s]+)"
        code = re.sub(sandbox_pattern, r"\1", code)
        return code

    def _check_security(self, code: str) -> ToolResult | None:
        """Check for dangerous code patterns."""
        for pattern, message in DANGEROUS_PATTERNS:
            if re.search(pattern, code):
                return ToolResult(
                    success=False,
                    content=f"[Security Error] {message}",
                    error=f"blocked_pattern: {pattern}",
                )
        return None

    async def execute(self, code: str, purpose: str = "") -> ToolResult:
        """Execute Python code in the sandbox."""
        try:
            await self._ensure_initialized()

            if self._kernel_restarted:
                self._kernel_restarted = False
                return ToolResult(
                    success=False,
                    content="[Kernel Restarted] The Python kernel was restarted and all previous variables are lost. Please re-initialize your variables and re-run your analysis code.",
                    error="kernel_restarted",
                )

            code = self._sanitize_path(code)

            security_check = self._check_security(code)
            if security_check:
                return security_check

            try:
                result = await self.kernel_manager.execute_code(code)
            except Exception as e:
                error_msg = str(e)
                if any(
                    keyword in error_msg.lower()
                    for keyword in ["kernel", "zmq", "channel", "connection"]
                ):
                    self._kernel_restarted = True
                    await self.kernel_manager.close()
                    await self.kernel_manager.start_kernel()
                    return ToolResult(
                        success=False,
                        content=f"[Kernel Restarted] The Python kernel crashed and was restarted. "
                        f"All previous variables are lost. Please re-initialize your variables. "
                        f"Original error: {error_msg}",
                        error="kernel_restarted",
                    )
                raise

            if result.get("timed_out"):
                return ToolResult(
                    success=False,
                    content=f"[Timeout Error] Code execution timed out after {self.timeout} seconds. "
                    f"The code took too long to execute. "
                    f"Original error: {result['error']['evalue'] if result.get('error') else 'timeout'}",
                    error="timeout",
                )

            if result.get("memory_exceeded"):
                return ToolResult(
                    success=False,
                    content=f"[Memory Error] Memory limit ({self.memory_limit_mb}MB) exceeded. "
                    f"Try processing data in smaller chunks or using more efficient algorithms. "
                    f"Original error: {result['error']['evalue'] if result.get('error') else 'memory exceeded'}",
                    error="memory_exceeded",
                )

            if result["error"]:
                return ToolResult(
                    success=False,
                    content=f"Error: {result['error']['ename']}: {result['error']['evalue']}\n"
                    f"Traceback:\n{result['error']['traceback']}",
                    error=result["error"]["traceback"],
                )

            output_parts = []
            if result["stdout"]:
                output_parts.append(result["stdout"])
            if result["stderr"]:
                output_parts.append(f"[stderr]: {result['stderr']}")
            if result["data"]:
                output_parts.append(result["data"])
            if result["images"]:
                for img_data in result["images"]:
                    output_parts.append(
                        f"[image: base64 encoded, {len(img_data)} bytes]"
                    )
                    base64.b64decode(img_data)

            if not output_parts:
                return ToolResult(success=True, content="(no output)")

            return ToolResult(success=True, content="\n".join(output_parts))

        except Exception as e:
            return ToolResult(
                success=False, content=f"Execution failed: {str(e)}", error=str(e)
            )

    async def reset(self):
        """Reset the sandbox: close old kernel and start a fresh one."""
        if self.kernel_manager:
            await self.kernel_manager.close()
        if self.jupyter_manager:
            await self.jupyter_manager.stop()
        self._initialized = False
        self._kernel_restarted = False
        await self._ensure_initialized()

    async def interrupt(self) -> ToolResult:
        """Interrupt currently running code."""
        if self.kernel_manager:
            await self.kernel_manager.interrupt()
        return ToolResult(success=True, content="Interrupt signal sent to kernel")

    async def cleanup(self):
        """Clean up resources."""
        if self.kernel_manager:
            await self.kernel_manager.close()
            self.kernel_manager = None
        if self.jupyter_manager:
            await self.jupyter_manager.stop()
        self._initialized = False


class SandboxFileTool(Tool):
    """Tool for reading/writing files within the sandbox directory."""

    def __init__(self, sandbox_dir: str):
        self.sandbox_dir = sandbox_dir

    @property
    def name(self) -> str:
        return "sandbox_file"

    @property
    def description(self) -> str:
        return (
            f"Read or write files in the sandbox directory ({self.sandbox_dir}). "
            "Use this to persist data between code executions or save outputs."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["read", "write"],
                    "description": "Whether to read or write a file",
                },
                "path": {
                    "type": "string",
                    "description": "Relative path within the sandbox",
                },
                "content": {
                    "type": "string",
                    "description": "File content to write (required for write action)",
                },
            },
            "required": ["action", "path"],
        }

    async def execute(self, action: str, path: str, content: str = "") -> ToolResult:
        """Read or write a file in the sandbox."""
        import os

        full_path = os.path.join(self.sandbox_dir, path)

        if os.path.commonpath([full_path, self.sandbox_dir]) != self.sandbox_dir:
            return ToolResult(
                success=False, content="Path outside sandbox is not allowed"
            )

        try:
            if action == "read":
                with open(full_path, "r") as f:
                    data = f.read()
                return ToolResult(success=True, content=data)

            elif action == "write":
                with open(full_path, "w") as f:
                    f.write(content)
                return ToolResult(
                    success=True, content=f"Written {len(content)} bytes to {path}"
                )

            return ToolResult(success=False, content=f"Unknown action: {action}")

        except Exception as e:
            return ToolResult(
                success=False, content=f"File operation failed: {str(e)}", error=str(e)
            )


class MultiSandboxTool(Tool):
    """Tool for managing multiple independent sandbox sessions."""

    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        from mini_box_agent.sandbox.sandbox_manager import SandboxManager

        self.manager = SandboxManager(base_dir)
        self._sessions: dict[str, str] = {}

    @property
    def name(self) -> str:
        return "multi_sandbox"

    @property
    def description(self) -> str:
        return (
            "Manage multiple independent Python sandbox sessions for parallel analysis. "
            "Each session has its own kernel and variable state, isolated from others. "
            "Use this to analyze multiple files or run parallel analyses without interference. "
            "Actions: "
            "  - create: Create a new session, returns session_id. "
            "  - execute: Run code in a specific session (requires session_id). "
            "  - list: List all active sessions. "
            "  - close: Close and remove a session. "
            "  - close_all: Close all sessions."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "execute", "list", "close", "close_all"],
                    "description": "Action to perform",
                },
                "session_id": {
                    "type": "string",
                    "description": "Session ID (required for execute and close actions)",
                },
                "code": {
                    "type": "string",
                    "description": "Python code to execute (required for execute action)",
                },
            },
            "required": ["action"],
        }

    async def execute(
        self, action: str, session_id: str = "", code: str = ""
    ) -> ToolResult:
        """Execute a multi-sandbox action."""
        try:
            if action == "create":
                new_session_id = await self.manager.create_session()
                self._sessions[new_session_id] = new_session_id
                return ToolResult(
                    success=True,
                    content=f"Created sandbox session: {new_session_id}",
                )

            elif action == "execute":
                if not session_id:
                    return ToolResult(
                        success=False,
                        content="session_id is required for execute action",
                    )
                if not code:
                    return ToolResult(
                        success=False, content="code is required for execute action"
                    )
                result = await self.manager.execute_in_session(session_id, code)
                if result["error"]:
                    return ToolResult(
                        success=False,
                        content=f"Error: {result['error']['ename']}: {result['error']['evalue']}",
                        error=result["error"]["traceback"],
                    )
                output = result.get("stdout", "") or result.get("data", "")
                return ToolResult(success=True, content=output)

            elif action == "list":
                sessions = await self.manager.list_sessions()
                return ToolResult(
                    success=True,
                    content=f"Active sessions: {', '.join(sessions) if sessions else 'none'}",
                )

            elif action == "close":
                if not session_id:
                    return ToolResult(
                        success=False, content="session_id is required for close action"
                    )
                await self.manager.close_session(session_id)
                self._sessions.pop(session_id, None)
                return ToolResult(
                    success=True, content=f"Closed sandbox session: {session_id}"
                )

            elif action == "close_all":
                await self.manager.close_all()
                self._sessions.clear()
                return ToolResult(success=True, content="Closed all sandbox sessions")

            return ToolResult(success=False, content=f"Unknown action: {action}")

        except Exception as e:
            return ToolResult(
                success=False,
                content=f"Multi-sandbox operation failed: {str(e)}",
                error=str(e),
            )
