"""Kernel management for Jupyter sandbox using jupyter_client."""

import asyncio
import logging
import re
import threading
from typing import Any, Optional

from jupyter_client import AsyncKernelManager

logger = logging.getLogger(__name__)

DANGEROUS_PATTERNS = [
    (r"import\s+os", "import os is not allowed in sandbox"),
    (r"from\s+os\s+import", "from os import is not allowed in sandbox"),
    (r"import\s+subprocess", "import subprocess is not allowed in sandbox"),
    (r"subprocess\.", "subprocess calls are not allowed in sandbox"),
    (r"os\.system", "os.system is not allowed in sandbox"),
    (r"os\.popen", "os.popen is not allowed in sandbox"),
    (r"eval\s*\(", "eval() is not allowed in sandbox"),
    (r"exec\s*\(", "exec() is not allowed in sandbox"),
    (r"__import__", "__import__ is not allowed in sandbox"),
    (r"import\s+sys", "import sys is not allowed in sandbox"),
    (r"sys\.exit", "sys.exit is not allowed in sandbox"),
    (r"open\s*\(\s*['\"]\/", "absolute path open is not allowed"),
    (r"open\s*\(\s*['\"]..", "parent directory access is not allowed"),
    (r"with\s+open\s*\([^)]*\/", "absolute path file access is not allowed"),
]


class KernelManager:
    """Manages Jupyter kernels for code execution using jupyter_client."""

    def __init__(
        self,
        connection_info: dict,
        timeout: int = 60,
        memory_limit_mb: int = 512,
        python_path: Optional[str] = None,
    ):
        self.connection_info = connection_info
        self.timeout = timeout
        self.memory_limit_mb = memory_limit_mb
        self.python_path = python_path
        self.kernel_id: Optional[str] = None
        self._kernel_client = None
        self._km: Optional[AsyncKernelManager] = None
        self._execution_lock = asyncio.Lock()
        self._interrupted = False

    def check_dangerous_code(self, code: str) -> Optional[str]:
        """Check for dangerous patterns in code. Returns error message if dangerous."""
        for pattern, message in DANGEROUS_PATTERNS:
            if re.search(pattern, code):
                return f"[Security] {message}"
        return None

    async def start_kernel(self) -> str:
        """Start a new kernel and return its ID."""
        if self.python_path:
            self._km = AsyncKernelManager(
                kernel_name="python3", executable=self.python_path
            )
        else:
            self._km = AsyncKernelManager(kernel_name="python3")
        await self._km.start_kernel()

        self.kernel_id = self._km.kernel_id
        logger.info(f"Started kernel: {self.kernel_id}")

        self._kernel_client = self._km.blocking_client()
        self._kernel_client.start_channels()
        self._kernel_client.wait_for_ready(timeout=30)

        return self.kernel_id

    def _extract_package_from_error(self, error: dict) -> Optional[str]:
        """Extract package name from ImportError traceback."""
        if error.get("ename") != "ModuleNotFoundError":
            return None

        traceback = error.get("traceback", "")
        evalue = error.get("evalue", "")

        combined = traceback + "\n" + evalue

        import re

        patterns = [
            r"No module named ['\"]([^'\"]+)['\"]",
            r"ModuleNotFoundError: No module named ['\"]([^'\"]+)['\"]",
        ]

        for pattern in patterns:
            match = re.search(pattern, combined)
            if match:
                module_name = match.group(1)
                return module_name.split(".")[0]

        return None

    def _should_auto_install(self, code: str, package_name: str) -> bool:
        """Check if package is used in the code and should be auto-installed."""
        code_lower = code.lower()
        return (
            package_name.lower() in code_lower or f"import {package_name}" in code_lower
        )

    async def _auto_install_and_retry(self, code: str) -> dict[str, Any]:
        """Auto-install missing packages and retry execution."""
        if not self.python_path:
            return None

        from mini_box_agent.utils.sandbox_venv import install_to_sandbox

        venv_path = Path(self.python_path).parent.parent
        pip_path = venv_path / "bin" / "pip"

        if not pip_path.exists():
            return None

        package_match = re.search(r"(?:import|from)\s+([a-zA-Z_][a-zA-Z0-9_]*)", code)
        if not package_match:
            return None

        package_name = package_match.group(1)

        print(f"Installing {package_name} to sandbox environment...")
        success = install_to_sandbox(package_name)

        if success:
            print(f"{package_name} installed, retrying...")
            return await self.execute_code(code)

        return None

    async def execute_code(self, code: str) -> dict[str, Any]:
        """Execute Python code in the kernel with timeout and interrupt support."""
        if not self._kernel_client:
            await self.start_kernel()

        # Check for dangerous code
        danger_check = self.check_dangerous_code(code)
        if danger_check:
            return {
                "stdout": "",
                "stderr": "",
                "images": [],
                "error": {
                    "ename": "SecurityError",
                    "evalue": danger_check,
                    "traceback": "",
                },
                "data": None,
                "timed_out": False,
                "memory_exceeded": False,
            }

        result = {
            "stdout": "",
            "stderr": "",
            "images": [],
            "error": None,
            "data": None,
            "timed_out": False,
            "memory_exceeded": False,
        }

        self._interrupted = False

        def do_execute():
            msg_id = self._kernel_client.execute(code)
            shell_done = False
            execution_time = 0

            while not shell_done and not self._interrupted:
                try:
                    msg = self._kernel_client.get_shell_msg(timeout=1)
                    execution_time += 1

                    if execution_time > self.timeout:
                        self._interrupted = True
                        result["timed_out"] = True
                        result["error"] = {
                            "ename": "TimeoutError",
                            "evalue": f"Execution timed out after {self.timeout} seconds",
                            "traceback": "Code took too long to execute. Consider using smaller data or optimizing your code.",
                        }
                        try:
                            self._kernel_client._session.send(
                                self._kernel_client.kernel_manager.transport,
                                "interrupt_request",
                            )
                        except Exception:
                            pass
                        shell_done = True
                        break

                    if msg["parent_header"].get("msg_id") == msg_id:
                        msg_type = msg["msg_type"]
                        content = msg["content"]

                        if msg_type == "execute_result":
                            if "data" in content:
                                data = content["data"]
                                if "text/plain" in data:
                                    result["data"] = data["text/plain"]
                                if "image/png" in data:
                                    result["images"].append(data["image/png"])
                                if "image/svg+xml" in data:
                                    result["images"].append(data["image/svg+xml"])

                        elif msg_type == "error":
                            result["error"] = {
                                "ename": content.get("ename", ""),
                                "evalue": content.get("evalue", ""),
                                "traceback": "\n".join(content.get("traceback", [])),
                            }

                        elif msg_type == "execute_reply":
                            shell_done = True
                            if content.get("status") == "error":
                                result["error"] = {
                                    "ename": content.get("ename", ""),
                                    "evalue": content.get("evalue", ""),
                                    "traceback": "\n".join(
                                        content.get("traceback", [])
                                    ),
                                }
                except Exception as e:
                    if "Timeout" not in str(e) and "timed out" not in str(e).lower():
                        logger.warning(f"Error getting shell message: {e}")
                    shell_done = True

            while not self._interrupted:
                try:
                    msg = self._kernel_client.get_iopub_msg(timeout=1)
                    if msg.get("parent_header", {}).get("msg_id") != msg_id:
                        continue
                    msg_type = msg["msg_type"]
                    content = msg["content"]

                    if msg_type == "stream":
                        text = content.get("text", "")
                        if content.get("name") == "stdout":
                            result["stdout"] += text
                        elif content.get("name") == "stderr":
                            result["stderr"] += text
                            if "MemoryError" in text or "Killed" in text:
                                result["memory_exceeded"] = True
                                result["error"] = {
                                    "ename": "MemoryError",
                                    "evalue": f"Memory limit ({self.memory_limit_mb}MB) exceeded",
                                    "traceback": "The code used too much memory. Try processing data in smaller chunks.",
                                }

                    elif msg_type in ("execute_result", "display_data"):
                        if "data" in content:
                            data = content["data"]
                            if "text/plain" in data:
                                result["data"] = data["text/plain"]
                            if "image/png" in data:
                                result["images"].append(data["image/png"])
                            if "image/svg+xml" in data:
                                result["images"].append(data["image/svg+xml"])

                    elif msg_type == "error":
                        err_text = "\n".join(content.get("traceback", []))
                        if "MemoryError" in err_text or "Killed" in err_text:
                            result["memory_exceeded"] = True
                        result["error"] = {
                            "ename": content.get("ename", ""),
                            "evalue": content.get("evalue", ""),
                            "traceback": err_text,
                        }
                except Exception:
                    break

        async with self._execution_lock:
            await asyncio.get_event_loop().run_in_executor(None, do_execute)

        if result["error"]:
            package_name = self._extract_package_from_error(result["error"])
            if package_name and self._should_auto_install(code, package_name):
                retry_result = await self._auto_install_and_retry(code)
                if retry_result:
                    return retry_result

        return result

    async def interrupt(self):
        """Interrupt the currently running code."""
        self._interrupted = True
        if self._km:
            try:
                await self._km.interrupt_kernel()
                logger.info("Interrupted kernel")
            except Exception as e:
                logger.warning(f"Failed to interrupt kernel: {e}")

    async def close(self):
        """Close the kernel and client."""
        if self._km:
            try:
                await self._km.shutdown_kernel()
                logger.info(f"Closed kernel: {self.kernel_id}")
            except Exception as e:
                logger.warning(f"Failed to close kernel: {e}")
        self._kernel_client = None
        self._km = None

    def is_alive(self) -> bool:
        """Check if kernel is alive."""
        if not self._kernel_client or not self._km:
            return False
        try:
            self._kernel_client.get_shell_msg(timeout=1)
            return True
        except Exception:
            return False

    async def restart_if_needed(self) -> bool:
        """Restart kernel if it's not alive. Returns True if restarted."""
        if not self.is_alive():
            logger.warning("Kernel is not alive, restarting...")
            await self.close()
            await self.start_kernel()
            return True
        return False
