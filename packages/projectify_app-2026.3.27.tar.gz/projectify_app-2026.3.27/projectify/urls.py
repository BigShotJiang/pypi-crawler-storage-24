# SPDX-License-Identifier: AGPL-3.0-or-later
#
# SPDX-FileCopyrightText: 2021-2025 JWP Consulting GK
"""
Projectify URL Configuration.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/

Several URL patterns are hidden behind a feature flag.

This module also re-exports 403, 404, and 500 exception handlers
"""

from collections.abc import Sequence
from typing import Union

from django.contrib import admin
from django.contrib.sitemaps.views import sitemap
from django.urls import URLPattern, URLResolver, include, path
from django.views.generic import TemplateView

from allauth.urls import build_provider_urlpatterns

from projectify.blog.sitemap import BlogSitemap
from projectify.help.sitemap import HelpSitemap
from projectify.lib.views import permanent_redirect
from projectify.storefront.sitemap import StorefrontSitemap

from .lib.settings import get_settings
from .views import (
    colored_icon,
    handler403,
    handler404,
    handler500,
    health_check,
    manifest_view,
)

settings = get_settings()

sitemaps = {
    "storefront": StorefrontSitemap,
    "help": HelpSitemap,
    "blog": BlogSitemap,
}

thirdparty_logins = build_provider_urlpatterns()

# allauth
# can't add this to projectify.user.urls because it can't be namespaced
# with users:. allauth expects the url names to be non-prefixed
allauth_urls = (
    path("user/auth/", include(thirdparty_logins)),
    path("user/auth/", include("allauth.socialaccount.urls")),
    path(
        "user/auth/login/",
        permanent_redirect("users:log-in"),
        name="account_login",
    ),
)


urlpatterns: Sequence[Union[URLResolver, URLPattern]] = (
    # TODO may I use projectify.admin.admin.urls here?
    path("admin/", admin.site.urls),
    path("healthz", health_check, name="health-check"),
    path("corporate/", include("projectify.corporate.urls")),
    path(
        "icons/<str:icon>/<str:color>.svg", colored_icon, name="colored-icon"
    ),
    # New Django frontend urls
    path("dashboard/", include("projectify.workspace.urls")),
    path("user/", include("projectify.user.urls")),
    *allauth_urls,
    # storefront, help, etc.
    path("", include("projectify.storefront.urls")),
    path("", include("projectify.help.urls")),
    path("onboarding/", include("projectify.onboarding.urls")),
    # blog
    path("blog/", include("projectify.blog.urls")),
    # other
    path("manifest.json", manifest_view, name="manifest"),
    path(
        "robots.txt",
        TemplateView.as_view(
            template_name="robots.txt", content_type="text/plain; charset=UTF8"
        ),
    ),
    path(
        "humans.txt",
        TemplateView.as_view(
            template_name="humans.txt", content_type="text/plain; charset=UTF8"
        ),
    ),
    path(
        ".well-known/security.txt",
        TemplateView.as_view(
            template_name="well-known-security.txt",
            content_type="text/plain; charset=UTF8",
        ),
    ),
    path(
        "sitemap.xml",
        sitemap,
        {"sitemaps": sitemaps},
        name="django.contrib.sitemaps.views.sitemap",
    ),
)

if settings.PREMAIL_PREVIEW:
    urlpatterns = (
        *urlpatterns,
        path("premail/", include("projectify.premail.urls")),
    )

if settings.SERVE_MEDIA:
    from django.conf.urls.static import static

    urlpatterns = (
        *urlpatterns,
        *static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT),
    )

if settings.DEBUG_TOOLBAR:
    urlpatterns = (
        *urlpatterns,
        path("__debug__/", include("debug_toolbar.urls")),
    )

if settings.BROWSER_RELOAD:
    urlpatterns = (
        *urlpatterns,
        path("__reload__/", include("django_browser_reload.urls")),
    )

if settings.DEBUG_ERROR_PAGES:
    urlpatterns = (
        *urlpatterns,
        path("403.html", handler403),
        path("404.html", handler404),
        path("500.html", handler500),
    )

if settings.DEBUG_AUTH:
    urlpatterns = [
        *urlpatterns,
        path("test/", include("projectify.user.testing_urls")),
    ]

if settings.DEBUG:
    from .views import csp_report

    urlpatterns = [
        *urlpatterns,
        path("csp-report/", csp_report, name="csp-report"),
    ]


__all__ = ("handler404", "handler500", "handler403")
