# SPDX-License-Identifier: AGPL-3.0-or-later
#
# SPDX-FileCopyrightText: 2024-2026 JWP Consulting GK
"""Shared template tags for Projectify."""

import logging
from typing import Any, Literal, Optional, Union

from django import template
from django.contrib.staticfiles import finders
from django.templatetags import static
from django.urls import NoReverseMatch, reverse
from django.utils.html import format_html
from django.utils.safestring import SafeText, mark_safe
from django.utils.translation import gettext_lazy as _

from projectify.lib.utils import static_image_get_with_dimensions
from projectify.user.models import User
from projectify.workspace.models import TeamMember

logger = logging.getLogger(__name__)

register = template.Library()


@register.filter
def percent(value: Optional[float]) -> Optional[str]:
    """Format value as percentage."""
    if value is None:
        return None
    return _("{percentage} %").format(percentage=round(value * 100))


@register.simple_tag
def anchor(
    href: str,
    label: str,
    aria_label: Optional[str] = None,
    title: Optional[str] = None,
    external: bool = False,
    *args: Any,
    **kwargs: Any,
) -> SafeText:
    """
    Render a fully styled HTML anchor.

    Expects label to be translated.

    Set external=True when you want the link to open
    """
    extra: Union[SafeText, str]
    a_extra: Union[SafeText, str]
    if href == "":
        raise ValueError("Empty href supplied")
    try:
        url = reverse(href, args=args, kwargs=kwargs)
    except NoReverseMatch:
        url = href
    # TODO, if we have a reverse match, we don't have external URLs
    # We could switch all callers of the anchor function to use the route name
    # and implicitly switch on external for all other URLs. After all, if it's
    # an internal resource, we'd have a named route for that resource.
    if external:
        a_extra = mark_safe(' target="_blank"')
        extra = format_html(
            '<img class="inline-block w-4 h-4" src="{src}" alt="{text}">',
            src=reverse(
                "colored-icon",
                kwargs={"icon": "external_links", "color": "primary"},
            ),
            text=_("(Opens in new tab)"),
        )
    else:
        a_extra = ""
        extra = ""
    return format_html(
        '<a href="{url}"{aria_label}{title} class="text-primary underline hover:text-primary-hover active:text-primary-pressed text-base"{a_extra}>{label}{extra}</a>',
        aria_label=format_html(' aria-label="{label}"', label=aria_label)
        if aria_label is not None
        else "",
        title=format_html(' title="{title}"', title=title)
        if title is not None
        else "",
        a_extra=a_extra,
        url=url,
        label=label,
        extra=extra,
    )


@register.simple_tag
def circle_button(
    label: str,
    icon_style: str,
    name: str,
    value: Optional[str] = None,
    disabled: bool = False,
) -> SafeText:
    """Render a circular button."""
    return format_html(
        '<button name="{name}"{value}{disabled} type="submit" hx-swap="outerHTML" '
        'aria-label="{label}"'
        ' class="size-8 p-1.5 rounded-full border border-transparent hover:bg-secondary-hover active:bg-disabled-background disabled:bg-transparent disabled:opacity-20">{icon}</button>',
        name=name,
        disabled=" disabled" if disabled else "",
        value=format_html(' value="{}"', value) if value else "",
        icon=icon(icon_style),
        label=label,
    )


@register.simple_tag
def circle_anchor(
    label: str,
    icon_style: str,
    # TODO rename to path, since we don't accept full URLs anymore
    href: str,
    fragment: Optional[str] = None,
    title: Optional[str] = None,
    size: Literal[None, 4, 6] = None,
    *args: Any,
    **kwargs: Any,
) -> SafeText:
    """Render a circular anchor link."""
    if not href:
        raise ValueError("Empty href supplied")
    url = reverse(href, args=args, kwargs=kwargs)
    return format_html(
        '<a href="{url}" aria-label="{label}"{title} class="inline-block shrink-0 size-8 p-1.5 rounded-full border border-transparent hover:bg-secondary-hover active:bg-disabled-background">{icon}</a>',
        url=f"{url}#{fragment}" if fragment else url,
        label=label,
        title=format_html(' title="{title}"', title=title)
        if title is not None
        else "",
        icon=icon(icon_style, size=size),
    )


@register.simple_tag
def action_button(
    text: str,
    icon: Optional[str] = None,
    style: Literal["secondary", "destructive"] = "secondary",
    value: Optional[str] = None,
    name: Optional[str] = None,
    grow: bool = True,
    disabled: bool = False,
    justify_left: bool = False,
) -> SafeText:
    """Render a styled action button with icon."""
    # Source: frontend/src/lib/funabashi/buttons/Button.svelte
    color_classes = {
        "secondary": "text-secondary-content hover:bg-secondary-hover hover:text-secondary-content-hover active:bg-secondary-pressed active:text-secondary-content-hover",
        "destructive": "text-destructive hover:bg-destructive-secondary-hover hover:text-destructive-hover active:bg-destructive-secondary-pressed active:text-destructive-pressed",
    }

    return format_html(
        '<button type="submit" '
        'class="{width_class} {color_classes}{disabled_class} flex min-w-0 flex-row {justify} gap-2 rounded-lg px-4 py-2 font-bold"'
        "{disabled_attr}{value}{name}>"
        "{icon}"
        '<span class="truncate">{text}</span>'
        "</button>",
        width_class="w-full" if grow else "",
        color_classes=color_classes[style],
        disabled_class=" opacity-20" if disabled else "",
        disabled_attr=" disabled" if disabled else "",
        justify="justify-left" if justify_left else "justify-center",
        # TODO
        # icon=icon(icon, style, 6) if icon else "",
        icon=format_html(
            '<img class="w-6 h-6 shrink-0" src="{src}" aria-hidden="true">',
            src=reverse(
                "colored-icon",
                kwargs={
                    "icon": icon,
                    "color": "destructive"
                    if style == "destructive"
                    else "primary",
                },
            ),
        )
        if icon
        else "",
        text=text,
        value=format_html(' value="{value}"', value=value) if value else "",
        name=format_html(' name="{name}"', name=name) if name else "",
    )


@register.simple_tag
def go_to_action(
    # TODO rename to path, since we don't accept full URLs anymore
    href: str,
    label: str,
    title: Optional[str] = None,
    icon_style: Optional[str] = None,
    style: Literal["primary", "secondary", "destructive"] = "secondary",
    justify_left: bool = False,
    *args: Any,
    **kwargs: Any,
) -> SafeText:
    """
    Render a primary action button link.

    Used for main actions like "Edit", "Create", etc.
    """
    if href == "":
        raise ValueError("Empty href supplied")
    url = reverse(href, args=args, kwargs=kwargs)

    # Define color classes for different styles
    color_classes = {
        "primary": "bg-primary text-primary-content hover:bg-primary-hover active:bg-primary-pressed",
        "secondary": "text-secondary-content hover:bg-secondary-hover hover:text-secondary-content-hover active:bg-secondary-pressed active:text-secondary-content-hover",
        "destructive": "text-destructive hover:bg-destructive-secondary-hover hover:text-destructive-hover active:bg-destructive-secondary-pressed active:text-destructive-pressed",
    }

    justify_class = "justify-start" if justify_left else "justify-center"

    return format_html(
        '<a href="{url}"{title} class="{color_classes} text-base flex min-w-max flex-row {justify_class} gap-2 rounded-lg px-4 py-2 font-bold">{icon}<span class="truncate">{label}</span></a>',
        url=url,
        title=format_html(' title="{title}"', title=title)
        if title is not None
        else "",
        color_classes=color_classes[style],
        justify_class=justify_class,
        icon=icon(icon_style, style, 6) if icon_style else "",
        label=label,
    )


@register.simple_tag
def icon(
    icon: str,
    color: Optional[Literal["primary", "secondary", "destructive"]] = None,
    size: Literal[None, 4, 6] = None,
) -> SafeText:
    """Return a rendered heroicon SVG file with optional color."""
    static_path = f"heroicons/{icon}.svg"
    if not finders.find(static_path):
        logger.error("Missing icon '%s'", icon)
        return format_html("<div>MISSING ICON {}</div>", icon)

    if color:
        src = reverse("colored-icon", kwargs={"icon": icon, "color": color})
    else:
        src = static.static(static_path)
    try:
        size_class = (
            format_html(" class={}", {4: "size-4", 6: "size-6"}[size])
            if size
            else ""
        )
    except KeyError:
        logger.error(f"Missing size class for size {size}")
        size_class = ""
    return format_html(
        '<img src="{src}" aria-hidden="true"{size_class}>',
        src=src,
        icon=icon,
        size_class=size_class,
    )


@register.simple_tag
def user_avatar(
    team_member_or_user: Union[None, TeamMember, User],
) -> SafeText:
    """
    Render a user avatar image.

    Takes a user or team member object as parameter.
    """
    match team_member_or_user:
        case TeamMember(user=user) | (User() as user) if user.profile_picture:
            return format_html(
                '<div class="shrink-0 flex flex-row h-6 w-6 items-center rounded-full border border-primary"><img src="{src}" alt="{alt}" height="24" width="24" class="h-full w-full overflow-x-auto rounded-full object-cover object-center"></div>',
                src=user.profile_picture.url,
                alt=_("Team member {} avatar").format(str(user)),
            )
        case TeamMember(user=user) as team_member:
            avatar_url = reverse(
                "dashboard:avatar-marble", args=[team_member.uuid]
            )
            return format_html(
                '<div class="shrink-0 flex flex-row h-6 w-6 items-center rounded-full border border-primary"><img src="{src}?size=24" alt="{alt}" height="24" width="24" class="h-full w-full overflow-x-auto rounded-full object-cover object-center"></div>',
                src=avatar_url,
                alt=_("Team member {} avatar").format(str(user)),
            )
        case _:
            # TODO use one of our named colors instead of bg-base-200
            return mark_safe(
                '<div class="shrink-0 flex flex-row h-6 w-6 items-center rounded-full border border-primary bg-base-200"></div>'
            )


@register.simple_tag
def picture(
    src: str,
    alt: str,
    klass: Optional[str] = None,
    fetchpriority: Literal[None, "low", "high"] = None,
) -> SafeText:
    """
    Render a picture tag with an image from static files.

    Requires alt text for accessibility.
    Optionally accepts CSS classes.
    Automatically detects image dimensions using PIL.
    """
    match static_image_get_with_dimensions(src):
        case None:
            logger.warning("Could not get dimensions for file '%s'", src)
            return format_html("IMG_NOT_FOUND")
        case url, width, height:
            pass

    dimensions = format_html(' width="{}" height="{}"', width, height)

    return format_html(
        '<picture><img src="{url}" alt="{alt}"{dimensions}{klass}{fetchpriority}></picture>',
        url=url,
        alt=alt,
        dimensions=dimensions,
        klass=format_html(' class="{}"', klass) if klass else "",
        fetchpriority=format_html(' fetchpriority="{}"', fetchpriority)
        if fetchpriority
        else "",
    )
