# SPDX-License-Identifier: AGPL-3.0-or-later
#
# SPDX-FileCopyrightText: 2022-2024 JWP Consulting GK
"""Projectify middlewares."""

from typing import Callable, Optional

from django.http import HttpRequest, HttpResponse

GetResponse = Callable[[HttpRequest], HttpResponse]


def reverse_proxy(get_response: GetResponse) -> GetResponse:
    """
    Enhance request headers with X-Forwarded-For, if found, for rate limiting.

    It ain't great, and we don't rely on it alone for rate limiting.

    https://devcenter.heroku.com/articles/http-routing#heroku-headers
    Accessed 2024-04-05
    > The X-Forwarded-For, X-Forwarded-By, X-Forwarded-Proto, and X-Forwarded-Host headers are not trusted for security reasons, because it is not possible to know the order in which already existing fields were added (as per Forwarded HTTP Extension).
    > X-Forwarded-For: the originating IP address of the client connecting to the Heroku router

    https://django-ratelimit.readthedocs.io/en/stable/security.html#client-ip-address
    Accessed 2024-04-05
    > Mishandling client IP data creates an IP spoofing vector that allows attackers to circumvent IP ratelimiting entirely

    https://stackoverflow.com/questions/18264304/get-clients-real-ip-address-on-heroku/18517550#18517550
    Accessed 2024-04-05
    > From Jacob, Heroku's Director of Security at the time:
    >> The router doesn't overwrite X-Forwarded-For, but it does guarantee that the real origin will always be the last item in the list.
    > This means that, if you access a Heroku app in the normal way, you will just see your IP address in the X-Forwarded-For header [...]
    > Obviously, this is all we need, so there's a clear and secure solution for getting the client's IP address on Heroku [...]

    https://stackoverflow.com/questions/18264304/get-clients-real-ip-address-on-heroku/37061471#37061471
    Accessed 2024-04-05
    > From a practical standpoint, this IP will likely be reliable most of the time (because most people won't be bothering to spoof their IP). Unfortunately, it's impossible to prevent this sort of spoofing and by the time a request gets to the Heroku router, it's impossible for us to tell if IPs in an X-Forwarded-For chain have been tampered with or not.
    """

    def process_request(request: HttpRequest) -> HttpResponse:
        forwarded_for: Optional[str] = request.headers.get("X-Forwarded-For")
        if forwarded_for is not None:
            ips = [ip.strip() for ip in forwarded_for.split(",")]
            if len(ips) == 0:
                raise ValueError(
                    "X-Forwarded-For was specified, but no list of "
                    f"IPs was given: {forwarded_for}"
                )
            request.META["REMOTE_ADDR"] = ips[0]
        return get_response(request)

    return process_request
