# SPDX-License-Identifier: AGPL-3.0-or-later
#
# SPDX-FileCopyrightText: 2022-2024 JWP Consulting GK
"""User app user model views."""

from django import forms
from django.contrib.auth.decorators import login_required
from django.contrib.auth.password_validation import (
    password_validators_help_texts,
)
from django.forms import ValidationError
from django.http import HttpRequest, HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
from django.views.decorators.http import require_http_methods

from django_ratelimit.core import UNSAFE
from django_ratelimit.decorators import ratelimit

from projectify.lib.forms import populate_form_with_drf_errors
from projectify.lib.types import AuthenticatedHttpRequest
from projectify.lib.views import platform_view
from projectify.user.models import User
from projectify.user.services.internal import Token
from projectify.user.services.user import (
    user_change_password,
    user_confirm_email_address_update,
    user_request_email_address_update,
    user_set_password,
    user_update,
)

# Django views


class UserProfileForm(forms.ModelForm):
    """Form for user profile update."""

    class Meta:
        """Form meta."""

        model = User
        fields = ("profile_picture", "preferred_name")
        labels = {"profile_picture": _("Profile picture")}
        widgets = {
            # https://docs.djangoproject.com/en/5.2/ref/forms/widgets/#clearablefileinput
            "profile_picture": forms.ClearableFileInput(
                attrs={
                    "initial_text": _("Your current profile picture"),
                    "clear_checkbox_label": _("Remove profile picture"),
                    "cleared": _("You haven't uploaded a profile picture"),
                }
            ),
            "preferred_name": forms.TextInput(
                attrs={"placeholder": _("Enter your preferred name")}
            ),
        }


@require_http_methods(["GET", "POST"])
@login_required
def user_profile(request: HttpRequest) -> HttpResponse:
    """Show user profile."""
    user = request.user
    assert isinstance(user, User)
    if request.method == "POST":
        form = UserProfileForm(
            data=request.POST, instance=user, files=request.FILES
        )
        if form.is_valid():
            user_update(
                who=user,
                user=user,
                preferred_name=form.cleaned_data["preferred_name"],
                profile_picture=form.cleaned_data["profile_picture"],
            )
            return redirect(reverse("users:profile"))
        raise ValueError()
    else:
        form = UserProfileForm(instance=user)
    context = {
        "user": user,
        "form": form,
    }
    return render(request, "user/user_profile.html", context=context)


@require_http_methods(["GET", "POST"])
@platform_view
def password_set(request: AuthenticatedHttpRequest) -> HttpResponse:
    """Set password for user who doesn't have one."""
    user = request.user

    if user.has_usable_password():
        # TODO show flash that the user already has a password
        return redirect("users:change-password")

    context: dict[str, object] = {
        "validators": password_validators_help_texts()
    }
    template = "user/password_set.html"
    match request.method:
        case "GET":
            form = PasswordSetForm()
            context = {**context, "form": form}
            return render(request, "user/password_set.html", context=context)
        case _:  # POST
            form = PasswordSetForm(request.POST)
            context = {**context, "form": form}
            if not form.is_valid():
                status = 400
            else:
                data = form.cleaned_data
                try:
                    user_set_password(
                        user=user,
                        new_password=data["new_password"],
                        new_password_confirm=data["new_password_confirm"],
                        request=request,
                    )
                except ValidationError as error:
                    populate_form_with_drf_errors(form, error)
                    status = 400
                else:
                    return redirect("users:profile")
    return render(request, template, context=context, status=status)


class PasswordChangeForm(forms.Form):
    """Form for changing passwords."""

    current_password = forms.CharField(
        label=_("Current password"),
        widget=forms.PasswordInput(
            attrs={"placeholder": _("Enter your password")}
        ),
    )
    new_password = forms.CharField(
        label=_("New password"),
        widget=forms.PasswordInput(
            attrs={"placeholder": _("Enter the new password")}
        ),
    )
    new_password_confirm = forms.CharField(
        label=_("Confirm password"),
        widget=forms.PasswordInput(
            attrs={"placeholder": _("Confirm the new password")}
        ),
    )


@require_http_methods(["GET", "POST"])
@platform_view
@ratelimit(key="user", rate="5/h", method=UNSAFE)
def password_change(request: AuthenticatedHttpRequest) -> HttpResponse:
    """Change user password."""
    user = request.user

    context: dict[str, object] = {
        "validators": password_validators_help_texts()
    }
    template = "user/password_change.html"
    match request.method:
        case "GET":
            form = PasswordChangeForm()
            context = {**context, "form": form}
            status = 200
        case _:  # POST
            form = PasswordChangeForm(request.POST)
            context = {**context, "form": form}
            if not form.is_valid():
                status = 400
            else:
                data = form.cleaned_data
                try:
                    user_change_password(
                        user=user,
                        current_password=data["current_password"],
                        new_password=data["new_password"],
                        new_password_confirm=data["new_password_confirm"],
                        request=request,
                    )
                except ValidationError as error:
                    populate_form_with_drf_errors(form, error)
                    status = 400
                else:
                    return redirect("users:profile")
    return render(request, template, context=context, status=status)


class PasswordSetForm(forms.Form):
    """Form for setting passwords for users without passwords."""

    new_password = forms.CharField(
        label=_("New password"),
        widget=forms.PasswordInput(
            attrs={"placeholder": _("Enter the new password")}
        ),
    )
    new_password_confirm = forms.CharField(
        label=_("Confirm password"),
        widget=forms.PasswordInput(
            attrs={"placeholder": _("Confirm the new password")}
        ),
    )


class EmailAddressUpdateForm(forms.Form):
    """Form for updating email address."""

    new_email = forms.EmailField(
        label=_("New email"),
        widget=forms.EmailInput(
            attrs={"placeholder": _("Enter your new email address")}
        ),
    )
    password = forms.CharField(
        label=_("Current password"),
        widget=forms.PasswordInput(
            attrs={"placeholder": _("Enter your current password")}
        ),
    )


@require_http_methods(["GET", "POST"])
@platform_view
@ratelimit(key="user", rate="5/h", method=UNSAFE)
def email_address_update(request: AuthenticatedHttpRequest) -> HttpResponse:
    """Start email address update process for user."""
    user = request.user
    assert isinstance(user, User)

    if request.method == "GET":
        form = EmailAddressUpdateForm()
        context = {"form": form}
        return render(
            request, "user/email_address_update.html", context=context
        )

    form = EmailAddressUpdateForm(request.POST)

    if not form.is_valid():
        context = {"form": form}
        return render(
            request,
            "user/email_address_update.html",
            context=context,
            status=400,
        )

    data = form.cleaned_data
    try:
        user_request_email_address_update(
            user=user,
            password=data["password"],
            new_email=data["new_email"],
        )
    except ValidationError as error:
        populate_form_with_drf_errors(form, error)
        context = {"form": form}
        return render(
            request,
            "user/email_address_update.html",
            context=context,
            status=400,
        )
    return redirect("users:requested-email-address-update")


@login_required
def email_address_update_confirm(
    request: AuthenticatedHttpRequest, token: str
) -> HttpResponse:
    """Confirm the user's new email address by checking the token."""
    user = request.user
    try:
        user_confirm_email_address_update(
            user=user,
            confirmation_token=Token(token),
        )
    except ValidationError as error:
        context = {"error": str(error)}
        return render(
            request,
            "user/email_address_update_confirm.html",
            context=context,
            status=400,
        )
    else:
        return redirect("users:confirmed-email-address-update")


@login_required
def email_address_update_requested(
    request: AuthenticatedHttpRequest,
) -> HttpResponse:
    """Show confirmation that email address update was requested."""
    return render(request, "user/email_address_update_requested.html")


@login_required
def email_address_update_confirmed(
    request: AuthenticatedHttpRequest,
) -> HttpResponse:
    """Show confirmation that email address update was confirmed."""
    return render(request, "user/email_address_update_confirmed.html")
