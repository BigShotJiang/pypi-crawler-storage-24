"""PosAng subpackage."""
