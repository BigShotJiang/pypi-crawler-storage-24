"""Beam stability info subpackage."""
