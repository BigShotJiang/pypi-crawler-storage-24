"""DiagSys subpackage."""
