"""PSDiag subpackage."""
