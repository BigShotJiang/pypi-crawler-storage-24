"""OpticsCorr subpackage."""
