from egogym.embodiments.grippers.floating_gripper import FloatingGripper

class RUMGripper(FloatingGripper):
    def __init__(self, control_steps=200, grasping_steps=2000, action_space="delta", np_random=None):
        super().__init__(control_steps, grasping_steps, action_space, np_random=np_random)
        self.name = "rum"