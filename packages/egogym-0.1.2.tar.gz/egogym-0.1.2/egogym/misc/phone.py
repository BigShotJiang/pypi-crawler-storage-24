import numpy as np
from scipy.spatial.transform import Rotation as R
import teledex

class PhoneController:

    def __init__(self, scale=2.0):
        self.scale = scale
        self.session = teledex.Session()
        self.phone_init, self.eef_init = None, None
        self.transform = np.eye(4)
        self.transform[:3, :3] = R.from_euler("xyz", [-90, 90, 0], degrees=True).as_matrix()

    def start(self):
        self.session.start()
        while self.session.get_latest_data()["position"] is None: pass

    def calibrate(self, eef_pose: np.ndarray):
        self.eef_init = eef_pose.copy()
        data = self.session.get_latest_data()
        self.phone_init = np.eye(4)
        self.phone_init[:3, 3], self.phone_init[:3, :3] = data["position"], data["rotation"]

    def get_action(self) -> np.ndarray:
        data = self.session.get_latest_data()
        phone_pose = np.eye(4)
        phone_pose[:3, 3], phone_pose[:3, :3] = data["position"], data["rotation"]
        rel = self.transform @ np.linalg.inv(self.phone_init) @ phone_pose @ np.linalg.inv(self.transform)
        rel[:3, 3] *= self.scale
        return np.append((self.eef_init @ rel).flatten(), data["toggle"])

    @property
    def button(self) -> bool:
        return self.session.get_latest_data()["button"]

    def stop(self):
        self.session.stop()