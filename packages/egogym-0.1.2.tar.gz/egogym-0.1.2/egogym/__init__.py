import gymnasium as gym
from .tasks.pick import PickTask
from .tasks.open import OpenTask
from .tasks.close import CloseTask

gym.register(id="Egogym-Pick-v0", entry_point=PickTask)
gym.register(id="Egogym-Open-v0", entry_point=OpenTask)
gym.register(id="Egogym-Close-v0", entry_point=CloseTask)