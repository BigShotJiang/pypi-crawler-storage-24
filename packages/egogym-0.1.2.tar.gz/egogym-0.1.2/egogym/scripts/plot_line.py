import os
import numpy as np
import pandas as pd
import altair as alt
from scipy.stats import beta

alt.renderers.enable("colab")

BASE_DIR = "logs"
REWARD_THRESHOLD = 0.03
SHOW_LABELS = 1  # Set to True to show percentage labels above points

MODELS = {
    "RUMs2 + Gemini-ER": "rum/gemini",
    "π-0.5": "pi0",
    "RUMs2 + Oracle": "rum/oracle",
    "RUMv2 + Molmo": "rum/molmo",
    "RUMv2 + Moondream": "rum/moondream",
}

NUM_OBJECTS = [1, 2, 3, 4, 5]


def compute_success_from_csv(csv_path):
    df = pd.read_csv(csv_path, sep="\t")
    successes = (df["max_reward"] > REWARD_THRESHOLD).sum()
    total = len(df)
    return successes, total


def plot_bayesian_success_by_objects():
    rows = []

    for model_name, model_folder in MODELS.items():
        for n_obj in NUM_OBJECTS:
            possible_folders = [
                f"{n_obj}_objects",
                f"{n_obj}_object",
                f"{n_obj}-objects",
                f"{n_obj}-object",
            ]

            csv_path = None
            for folder in possible_folders:
                # First try direct path
                candidate = os.path.join(
                    BASE_DIR, model_folder, folder, "log.csv"
                )
                if os.path.exists(candidate):
                    csv_path = candidate
                    break
                
                # Try nested evaluation folder structure
                folder_path = os.path.join(BASE_DIR, model_folder, folder)
                if os.path.exists(folder_path) and os.path.isdir(folder_path):
                    for subdir in os.listdir(folder_path):
                        subdir_path = os.path.join(folder_path, subdir)
                        if os.path.isdir(subdir_path):
                            candidate = os.path.join(subdir_path, "log.csv")
                            if os.path.exists(candidate):
                                csv_path = candidate
                                break
                    if csv_path:
                        break

            if csv_path is None:
                print(f"Missing data: {model_name}, {n_obj} objects")
                continue

            s, t = compute_success_from_csv(csv_path)

            # Beta posterior
            a, b = 1 + s, 1 + (t - s)
            mean = a / (a + b)
            lo = beta.ppf(0.025, a, b)
            hi = beta.ppf(0.975, a, b)

            print(f"{model_name} | {n_obj} objects: {s}/{t} = {mean:.2%}")

            rows.append({
                "model": model_name,
                "num_objects": n_obj,
                "num_distractors": n_obj - 1,
                "mean": mean,
                "lo": lo,
                "hi": hi,
                "err": hi - mean,
            })

    df = pd.DataFrame(rows)
    
    # Calculate average success rate per model and sort by descending order
    model_means = df.groupby("model")["mean"].mean().sort_values(ascending=False)
    sorted_models = model_means.index.tolist()
    
    # Create color mapping maintaining original colors
    color_map = {
        "RUMs2 + Gemini-ER": "#6095e1",
        "π-0.5": "#E0BE16",
        "RUMs2 + Oracle": "#A918C0",
        "RUMv2 + Molmo": "#F0529c",
        "RUMv2 + Moondream": "#000000",
        "RUMs2 + 4o": "#FF6B35"
    }
    
    # Ensure all sorted models have colors
    sorted_colors = []
    for model in sorted_models:
        sorted_colors.append(color_map[model])

    print(f"Sorted models: {sorted_models}")
    print(f"Sorted colors: {sorted_colors}")

    base = alt.Chart(df).encode(
        x=alt.X(
            "num_distractors:O",
            title="Number of Distractor Objects",
            axis=alt.Axis(labelFontSize=16, titleFontSize=16, labelAngle=0, titlePadding=15)
        ),
        color=alt.Color(
            "model:N",
            scale=alt.Scale(
                domain=sorted_models,
                range=sorted_colors
            ),
            legend=alt.Legend(
                title="Model",
                titleFontSize=15,
                labelFontSize=13,
                symbolSize=200,
                orient="none",
                direction="vertical",
                fillColor="#F5F5F5",
                strokeColor="gray",
                padding=10,
                cornerRadius=5,
                legendX=575,
                legendY=-85
            )
        )
    )

    lines = base.mark_line(
        strokeWidth=3,
        point=alt.OverlayMarkDef(size=100)
    ).encode(
        y=alt.Y(
            "mean:Q",
            title="Success Rate (%)",
            scale=alt.Scale(domain=[0.0, 1.0]),
            axis=alt.Axis(
                format=".0%",
                tickCount=6,
                labelFontSize=16,
                titleFontSize=16,
                titlePadding=14,
                grid=True,
                gridOpacity=0.9,
                gridWidth=0.5
            )
        )
    )

    error_bars = base.mark_errorbar(
        ticks=True,
        size=18,
        color="black"
    ).encode(
        y="mean:Q",
        yError="err:Q"
    )


    labels = alt.Chart(df).mark_text(
        dy=-8,
        fontSize=14,
        color="black"
    ).encode(
        x=alt.X("num_distractors:O"),
        y="hi:Q",
        text=alt.Text("mean:Q", format=".0%")
    )

    # Combine layers based on SHOW_LABELS setting
    if SHOW_LABELS:
        chart = lines + error_bars + labels
    else:
        chart = lines + error_bars

    return (
        chart
        .properties(
            width=720,
            height=420,
            title={
                "text": "EgoGym Pick Success Rate vs Number of Distractors",
                "anchor": "start"
            },
            padding={"left": 60, "right": 20, "top": 45, "bottom": 40}
        )
        .configure_view(stroke=None)
        .configure_title(
            fontSize=18,
            fontWeight="bold",
            offset=-30,
            dx=60
        )
    )


chart = plot_bayesian_success_by_objects()
chart.save("success_by_objects.png", scale_factor=2)