
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import beta, pearsonr, gaussian_kde
from matplotlib.patches import Polygon

BASE_DIR = "logs/5_objects"
REWARD_THRESHOLD = 0.03
PARTIAL_LIFT_THRESHOLD = 0.01

CHECKPOINT_REAL_SR = {
    "checkpoint_10": 24.0,
    "checkpoint_50": 38.8,
    "checkpoint_64": 67.5,
    "checkpoint_80": 83.2,
}

REAL_SAMPLES = 250
SIM_SAMPLES_PER_CHECKPOINT = None

USE_CSV_FILES = True


def compute_success_from_csv(csv_path):
    if not os.path.exists(csv_path):
        return None, None
    df = pd.read_csv(csv_path, sep="\t")
    successes = (df["max_reward"] > REWARD_THRESHOLD).sum()
    total = len(df)
    return successes, total


def compute_failure_modes_from_csv(csv_path):
    if not os.path.exists(csv_path):
        return None, None
    df = pd.read_csv(csv_path, sep="\t")
    total_episodes = len(df)
    def get_failure_mode(row):
        if row["max_reward"] > REWARD_THRESHOLD:
            return None
        bodies_contacted = str(row.get("grasped_bodies", ""))
        object_name = str(row.get("object_name", ""))
        grasping_object = row.get("grasping_object", False)
        is_grasping = row.get("is_grasping", False)
        has_target_contact = object_name in bodies_contacted
        has_gripper_contact = "left" in bodies_contacted or "right" in bodies_contacted
        has_any_object_contact = "object" in bodies_contacted
        has_wrong_object_contact = has_any_object_contact and not has_target_contact
        if grasping_object:
            if row["max_reward"] >= PARTIAL_LIFT_THRESHOLD:
                return "did not lift enough"
            return "object fell/slipped"
        if has_target_contact:
            return "object fell/slipped"
        if has_wrong_object_contact and (is_grasping or has_gripper_contact):
            return "picked wrong object"
        if has_gripper_contact or is_grasping:
            return "Empty Grasp"
        return "did not grasp"
    df["failure_mode"] = df.apply(get_failure_mode, axis=1)
    failure_modes = {
        "Did not lift enough": 0,
        "Object touched but not grasped": 0,
        "Picked wrong object": 0,
        "Empty Grasp": 0,
        "Did not grasp": 0,
    }
    failure_condition = df["max_reward"] <= REWARD_THRESHOLD
    for _, row in df[failure_condition].iterrows():
        mode = row["failure_mode"]
        if mode == "did not lift enough":
            failure_modes["Did not lift enough"] += 1
        elif mode == "object fell/slipped":
            failure_modes["Object touched but not grasped"] += 1
        elif mode == "picked wrong object":
            failure_modes["Picked wrong object"] += 1
        elif mode == "Empty Grasp":
            failure_modes["Empty Grasp"] += 1
        elif mode == "did not grasp":
            failure_modes["Did not grasp"] += 1
    total_failures = sum(failure_modes.values())
    return failure_modes, total_failures, total_episodes


def plot_bayesian_correlation():
    stats = {}
    checkpoint_order = ["checkpoint_10", "checkpoint_50", "checkpoint_64", "checkpoint_80"]
    for checkpoint in checkpoint_order:
        if checkpoint not in CHECKPOINT_REAL_SR:
            print(f"Warning: {checkpoint} not in CHECKPOINT_REAL_SR")
            continue
        csv_path = os.path.join(BASE_DIR, checkpoint, "log.csv")
        success, total = compute_success_from_csv(csv_path)
        if success is None:
            print(f"Warning: Could not find CSV data for {checkpoint}")
            continue
        real_sr = CHECKPOINT_REAL_SR[checkpoint]
        a_sim = 1 + success
        b_sim = 1 + (total - success)
        sim_mean = 100 * a_sim / (a_sim + b_sim)
        real_successes = int(real_sr / 100 * REAL_SAMPLES)
        a_real = 1 + real_successes
        b_real = 1 + (REAL_SAMPLES - real_successes)
        real_mean = 100 * a_real / (a_real + b_real)
        print(f"{checkpoint}: sim={success}/{total} ({sim_mean:.1f}%), real={real_sr:.1f}% ({real_successes}/{REAL_SAMPLES})")
        stats[checkpoint] = {
            "sim_mean": sim_mean,
            "sim_alpha": a_sim,
            "sim_beta": b_sim,
            "real_mean": real_mean,
            "real_alpha": a_real,
            "real_beta": b_real,
        }
    if not stats:
        print("No data found!")
        return
    checkpoint_names = list(stats.keys())
    sim_rates = np.array([stats[c]["sim_mean"] for c in checkpoint_names])
    real_rates = np.array([stats[c]["real_mean"] for c in checkpoint_names])
    fig, ax = plt.subplots(figsize=(10, 8))
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    r, p_value = pearsonr(sim_rates, real_rates)
    z = np.polyfit(sim_rates, real_rates, 1)
    p = np.poly1d(z)
    xs = np.linspace(sim_rates.min() - 5, sim_rates.max() + 5, 200)
    ax.plot(xs, p(xs), "--", color="black", lw=1.5, alpha=0.5, zorder=1)
    violin_width = 2.5
    for i, checkpoint in enumerate(checkpoint_names):
        sim_lo = beta.ppf(0.025, stats[checkpoint]["sim_alpha"], stats[checkpoint]["sim_beta"]) * 100
        sim_hi = beta.ppf(0.975, stats[checkpoint]["sim_alpha"], stats[checkpoint]["sim_beta"]) * 100
        y = beta.rvs(stats[checkpoint]["real_alpha"], stats[checkpoint]["real_beta"], size=10000) * 100
        kde = gaussian_kde(y)
        yg = np.linspace(y.min(), y.max(), 200)
        d = kde(yg)
        d = d / d.max() * violin_width
        xc = sim_rates[i]
        yc = real_rates[i]
        vx = np.concatenate([xc - d, [xc], xc + d[::-1]])
        vy = np.concatenate([yg, [yg[-1]], yg[::-1]])
        fc, ec = "#A894DB", "#8B4789"
        ax.add_patch(Polygon(list(zip(vx, vy)), facecolor=fc, edgecolor=ec, alpha=0.6, lw=1.1, zorder=3))
        ax.plot([xc - 1.0, xc + 1.0], [yc] * 2, color="black", lw=1.2, zorder=4)
        ax.errorbar(xc, yc, xerr=[[xc - sim_lo], [sim_hi - xc]], fmt='none', ecolor='black', elinewidth=1.5, capsize=4, capthick=1.5, zorder=4)
        label = "Checkpoints" if i == 0 else None
        ax.plot(xc, yc, "D", color=fc, markeredgecolor=ec, ms=7, zorder=5, label=label)
    sim_los = [beta.ppf(0.025, stats[c]["sim_alpha"], stats[c]["sim_beta"]) * 100 for c in checkpoint_names]
    sim_his = [beta.ppf(0.975, stats[c]["sim_alpha"], stats[c]["sim_beta"]) * 100 for c in checkpoint_names]
    real_los = [beta.ppf(0.025, stats[c]["real_alpha"], stats[c]["real_beta"]) * 100 for c in checkpoint_names]
    real_his = [beta.ppf(0.975, stats[c]["real_alpha"], stats[c]["real_beta"]) * 100 for c in checkpoint_names]
    n_samples = 1000
    r_samples = []
    for _ in range(n_samples):
        sim_sample = [beta.rvs(stats[c]["sim_alpha"], stats[c]["sim_beta"]) * 100 for c in checkpoint_names]
        real_sample = [beta.rvs(stats[c]["real_alpha"], stats[c]["real_beta"]) * 100 for c in checkpoint_names]
        r_sample, _ = pearsonr(sim_sample, real_sample)
        r_samples.append(r_sample)
    r_samples = np.array(r_samples)
    r_lo = np.percentile(r_samples, 2.5)
    r_hi = np.percentile(r_samples, 97.5)
    x_min = min(sim_los) - 5
    x_max = max(sim_his) + 5
    y_min = min(real_los) - 5
    y_max = max(real_his) + 5
    ax.set_xlabel("EgoGym Performance (%)", fontsize=18)
    ax.set_ylabel("Real Performance (%)", fontsize=18)
    ax.set_title("Checkpoint Correlation", fontsize=18, pad=20)
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    ax.grid(True, alpha=0.3, linewidth=0.5)
    ax.tick_params(axis='both', labelsize=16)
    ax.text(0.95, 0.05, f'r = {r:.3f} [{r_lo:.3f}, {r_hi:.3f}]', transform=ax.transAxes, fontsize=16, verticalalignment='bottom', horizontalalignment='right', bbox=dict(boxstyle='round', facecolor='white', alpha=0.8, edgecolor='gray'))
    ax.legend(loc="upper left", frameon=False, fontsize=12)
    plt.tight_layout()
    plt.savefig("checkpoint_correlation.png", dpi=300, bbox_inches="tight")
    print(f"\nCorrelation: r = {r:.3f}, p = {p_value:.4f}")
    print("\nPlot saved to: checkpoint_correlation.png")
    plt.show()


def plot_failure_modes_by_checkpoint(checkpoint_order):
    failure_data = {}
    failure_totals = {}
    episode_totals = {}
    for checkpoint in checkpoint_order:
        csv_path = os.path.join(BASE_DIR, checkpoint, "log.csv")
        failure_modes, total_failures, total_episodes = compute_failure_modes_from_csv(csv_path)
        if failure_modes is None:
            print(f"Warning: Could not find CSV data for {checkpoint}")
            continue
        failure_data[checkpoint] = failure_modes
        failure_totals[checkpoint] = total_failures
        episode_totals[checkpoint] = total_episodes
    if not failure_data:
        print("No failure mode data found!")
        return
    checkpoint_names = list(failure_data.keys())
    x = np.arange(len(checkpoint_names))
    bottom = np.zeros(len(checkpoint_names))
    mode_order = [
        "Did not lift enough",
        "Object touched but not grasped",
        "Picked wrong object",
        "Empty Grasp",
        "Did not grasp",
    ]
    colors = {
        "Did not lift enough": "#5E81AC",
        "Object touched but not grasped": "#A3BE8C",
        "Picked wrong object": "#D08770",
        "Empty Grasp": "#EBCB8B",
        "Did not grasp": "#BF616A",
    }
    fig, ax = plt.subplots(figsize=(10, 6))
    fig.patch.set_facecolor("white")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    total_by_mode = {mode: 0 for mode in mode_order}
    for checkpoint in checkpoint_names:
        for mode in mode_order:
            total_by_mode[mode] += failure_data[checkpoint].get(mode, 0)
    for mode in mode_order:
        if total_by_mode.get(mode, 0) == 0:
            continue
        values = []
        for checkpoint in checkpoint_names:
            total = episode_totals.get(checkpoint, 0) or 1
            count = failure_data[checkpoint].get(mode, 0)
            values.append(count / total * 100)
        ax.bar(
            x,
            values,
            bottom=bottom,
            label=mode,
            color=colors.get(mode, "#999999"),
            edgecolor="black",
            linewidth=0.8,
            width=0.6,
        )
        bottom += np.array(values)
    checkpoint_labels = []
    for checkpoint in checkpoint_names:
        if checkpoint == "checkpoint_10":
            checkpoint_labels.append("RUM-EC1")
        elif checkpoint == "checkpoint_50":
            checkpoint_labels.append("RUM-EC2")
        elif checkpoint == "checkpoint_64":
            checkpoint_labels.append("RUM-EC3")
        elif checkpoint == "checkpoint_80":
            checkpoint_labels.append("RUM")
        else:
            checkpoint_labels.append(checkpoint)
    ax.set_xticks(x)
    ax.set_xticklabels(checkpoint_labels, fontsize=12)
    ax.set_ylabel("Share of Episodes (%)", fontsize=14)
    ax.set_title("Failure Modes by Checkpoint", fontsize=17, pad=18, loc="left")
    ax.set_ylim(0, 100)
    ax.grid(axis="y", alpha=0.2, linewidth=0.6)
    ax.tick_params(axis="y", labelsize=12)
    ax.legend(frameon=False, fontsize=11, title="Failure Mode", title_fontsize=12)
    plt.tight_layout()
    plt.savefig("failure_modes_by_checkpoint.png", dpi=300, bbox_inches="tight")
    print("\nPlot saved to: failure_modes_by_checkpoint.png")
    plt.show()


if __name__ == "__main__":
    plot_bayesian_correlation()
    plot_failure_modes_by_checkpoint([
        "checkpoint_10", "checkpoint_50", "checkpoint_64", "checkpoint_80"
    ])
