import numpy as np
import gymnasium as gym
import egogym

seed = 42
max_steps = 3
robot = "droid"
env = gym.make("Egogym-Pick-v0", seed=seed, action_space="delta", robot=robot, render_mode="human")

action = np.zeros(17)
if robot == "rum":
    action[:16] = np.eye(4).reshape(16)

while True:
    obs, _ = env.reset()

    for _ in range(max_steps):
        obs, reward, terminated, truncated, info = env.step(action)
        env.render()
        if reward > 0.05:
            break
