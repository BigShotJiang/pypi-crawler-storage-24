from baselines.rum.models.bet.vqvae.vector_quantize_pytorch import VectorQuantize
from baselines.rum.models.bet.vqvae.residual_vq import ResidualVQ
from baselines.rum.models.bet.vqvae.vqvae import VqVae
