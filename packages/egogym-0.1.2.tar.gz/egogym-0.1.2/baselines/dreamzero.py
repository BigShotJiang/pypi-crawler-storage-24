import numpy as np
import time
import uuid
import logging
from typing import Dict, Tuple

import websockets.sync.client
from openpi_client import msgpack_numpy

from egogym.policies.base_policy import BasePolicy
from egogym.utils import resize_with_pad

PING_INTERVAL_SECS = 60
PING_TIMEOUT_SECS = 600


class DreamZeroWebsocketClient:
    """Websocket client that adds endpoint field for DreamZero server."""

    def __init__(self, host: str = "0.0.0.0", port: int = 8000) -> None:
        self._uri = f"ws://{host}:{port}"
        self._packer = msgpack_numpy.Packer()
        self._ws, self._server_metadata = self._wait_for_server()

    def _wait_for_server(self) -> Tuple[websockets.sync.client.ClientConnection, Dict]:
        logging.info(f"Waiting for server at {self._uri}...")
        try:
            conn = websockets.sync.client.connect(
                self._uri,
                compression=None,
                max_size=None,
                ping_interval=PING_INTERVAL_SECS,
                ping_timeout=PING_TIMEOUT_SECS,
            )
            metadata = msgpack_numpy.unpackb(conn.recv())
            return conn, metadata
        except:
            logging.info("Connection to server with ws:// failed. Trying wss:// ...")

        self._uri = "wss://" + self._uri.split("//")[1]
        conn = websockets.sync.client.connect(
            self._uri,
            compression=None,
            max_size=None,
            ping_interval=PING_INTERVAL_SECS,
            ping_timeout=PING_TIMEOUT_SECS,
        )
        metadata = msgpack_numpy.unpackb(conn.recv())
        return conn, metadata

    def infer(self, obs: Dict) -> Dict:
        obs["endpoint"] = "infer"
        data = self._packer.pack(obs)
        self._ws.send(data)
        response = self._ws.recv()
        if isinstance(response, str):
            raise RuntimeError(f"Error in inference server:\n{response}")
        return msgpack_numpy.unpackb(response)

    def reset(self, reset_info: Dict = None) -> None:
        if reset_info is None:
            reset_info = {}
        reset_info["endpoint"] = "reset"
        data = self._packer.pack(reset_info)
        self._ws.send(data)
        response = self._ws.recv()
        return response

class DreamZeroPolicy(BasePolicy):
    
    def __init__(self, config=None, **kwargs):
        super().__init__()
        if config is None:
            config = get_config()
        
        for key, value in kwargs.items():
            config[key] = value
            
        self.config = config
        self.name = "dreamzero"
        self.host = self.config["host"]
        self.port = self.config["port"]
        self.grasping_style = self.config["grasping_style"]
        self.buffer_length = self.config["buffer_length"]
        self.batch_size = 0

        max_retries = 5
        for attempt in range(max_retries):
            try:
                self.model = DreamZeroWebsocketClient(
                    host=self.host,
                    port=self.port,
                )
                print(f"Connected to DreamZero model at {self.host}:{self.port}")
                break
            except Exception as e:
                if attempt < max_retries - 1:
                    print(f"Connection attempt {attempt + 1} failed: {e}. Retrying...")
                    time.sleep(1)
                else:
                    print(f"Failed to connect to remote model after {max_retries} attempts")
                    raise
                
    def get_action(self, obs):

        if self.batch_size == 0:
            if obs["rgb_exo"].ndim == 3:
                self.batch_size = 1
            else:
                self.batch_size = obs["rgb_exo"].shape[0]
            self.action_buffer = [None] * self.batch_size
            self.current_buffer_index = [0] * self.batch_size
            self.session_ids = [str(uuid.uuid4()) for _ in range(self.batch_size)]

        if self.batch_size == 1:
            obs = {key: np.expand_dims(value, axis=0) if isinstance(value, np.ndarray) else [value] for key, value in obs.items()}

        
        actions = []
        for i in range(self.batch_size):

            if self.action_buffer[i] is None or self.current_buffer_index[i] >= self.buffer_length:
                model_input = {
                    "observation/exterior_image_0_left": resize_with_pad(obs["rgb_exo"][i], 180, 320),
                    "observation/exterior_image_1_left": resize_with_pad(obs["rgb_exo"][i], 180, 320),
                    "observation/wrist_image_left": resize_with_pad(obs["rgb_ego"][i], 180, 320),
                    "observation/joint_position": np.array(obs["joint_positions"][i][:7], dtype=np.float64).reshape(7,),
                    "observation/cartesian_position": np.zeros((6,), dtype=np.float64),
                    "observation/gripper_position": np.array(obs["grasp"][i], dtype=np.float64).reshape(1,),
                    "prompt": f'pick up the {obs["object_name"][i]} and place it on a plate.',
                    "session_id": self.session_ids[i],
                }
                result = self.model.infer(model_input)
                self.action_buffer[i] = result["actions"]
                self.current_buffer_index[i] = 0    

            current_action = self.action_buffer[i][self.current_buffer_index[i]]
            self.current_buffer_index[i] += 1

            gripper_pos = np.array([np.clip(current_action[7], 0.0, 1.0)])

            if self.grasping_style == "binary":
                gripper_pos = np.array([1.0]) if gripper_pos >= self.config["gripper_threshold"] else np.array([0.0])
            elif self.grasping_style == "semi_binary":
                gripper_pos = gripper_pos if gripper_pos <= self.config["gripper_threshold"] else np.array([1.0])
            elif not self.grasping_style == "continuous":
                raise ValueError(f"Invalid grasping style: {self.grasping_style}")
                
                
            arm_output = current_action[:7].reshape(7)
            actions.append(np.concatenate([arm_output, gripper_pos], axis=0).reshape(1, -1))

        return np.array(actions).reshape(self.batch_size, 8)
    
    def reset(self, indicies=None):
        if indicies is not None:
            for i in indicies:
                self.action_buffer[i] = None
                self.current_buffer_index[i] = 0
                self.session_ids[i] = str(uuid.uuid4())
        else:
            self.batch_size = 0
            self.action_buffer = None
            self.current_buffer_index = None
            self.session_ids = None


def get_config():
    config = {
        "host": "localhost",
        "port": 6000,
        "gripper_threshold": 0.5,
        "grasping_style": "binary",
        "buffer_length": 24,
    }
    return config
