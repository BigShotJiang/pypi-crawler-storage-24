# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from darabonba.model import DaraModel

class UpdateCustomAgentRequest(DaraModel):
    def __init__(
        self,
        custom_agent_id: str = None,
        enable_tools: bool = None,
        name: str = None,
        skill_ids: List[str] = None,
        system_prompt: str = None,
        tools: List[str] = None,
    ):
        # The operation that you want to perform. Set the value to **UpdateCustomAgent**.
        # 
        # This parameter is required.
        self.custom_agent_id = custom_agent_id
        # The system prompts.
        self.enable_tools = enable_tools
        # The ID of the agent.
        self.name = name
        self.skill_ids = skill_ids
        # The name of the agent.
        self.system_prompt = system_prompt
        # Specifies whether to enable tools.
        self.tools = tools

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.custom_agent_id is not None:
            result['CustomAgentId'] = self.custom_agent_id

        if self.enable_tools is not None:
            result['EnableTools'] = self.enable_tools

        if self.name is not None:
            result['Name'] = self.name

        if self.skill_ids is not None:
            result['SkillIds'] = self.skill_ids

        if self.system_prompt is not None:
            result['SystemPrompt'] = self.system_prompt

        if self.tools is not None:
            result['Tools'] = self.tools

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CustomAgentId') is not None:
            self.custom_agent_id = m.get('CustomAgentId')

        if m.get('EnableTools') is not None:
            self.enable_tools = m.get('EnableTools')

        if m.get('Name') is not None:
            self.name = m.get('Name')

        if m.get('SkillIds') is not None:
            self.skill_ids = m.get('SkillIds')

        if m.get('SystemPrompt') is not None:
            self.system_prompt = m.get('SystemPrompt')

        if m.get('Tools') is not None:
            self.tools = m.get('Tools')

        return self

