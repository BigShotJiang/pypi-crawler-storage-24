# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict, Any, List

from darabonba.model import DaraModel

class CreateSkillRequest(DaraModel):
    def __init__(
        self,
        content: Dict[str, Any] = None,
        dbtypes: List[str] = None,
        description: str = None,
        name: str = None,
    ):
        # The content of the skill.
        self.content = content
        # The list of database engines.
        # 
        # This parameter is required.
        self.dbtypes = dbtypes
        # The description of the skill. It can be up to 1000 characters in length.
        # 
        # This parameter is required.
        self.description = description
        # The name of the skill, which can contain only lowercase letters, numbers, and hyphens.
        # 
        # This parameter is required.
        self.name = name

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.content is not None:
            result['Content'] = self.content

        if self.dbtypes is not None:
            result['Dbtypes'] = self.dbtypes

        if self.description is not None:
            result['Description'] = self.description

        if self.name is not None:
            result['Name'] = self.name

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Content') is not None:
            self.content = m.get('Content')

        if m.get('Dbtypes') is not None:
            self.dbtypes = m.get('Dbtypes')

        if m.get('Description') is not None:
            self.description = m.get('Description')

        if m.get('Name') is not None:
            self.name = m.get('Name')

        return self

