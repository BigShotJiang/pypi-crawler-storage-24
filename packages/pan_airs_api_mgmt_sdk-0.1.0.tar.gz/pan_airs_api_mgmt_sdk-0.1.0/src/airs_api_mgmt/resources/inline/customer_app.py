# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

from __future__ import annotations

from typing import Optional

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.config.constants import MAX_EMAIL_LENGTH
from airs_api_mgmt.sdk.inline import ApiException
from airs_api_mgmt.sdk.inline.api import CustomerAppApi
from airs_api_mgmt.sdk.models import CustomerAppObject, PaginatedCustomerAppObject
from airs_api_mgmt.resources.inline.base_client import BaseClient
from airs_api_mgmt.exceptions import (
    MgmtSdkAPIError,
    MgmtSdkServerError,
    MgmtSdkClientError,
    MgmtSdkBaseError,
    PayloadConfigurationError,
)
from airs_api_mgmt.utils import get_logger


class CustomerApp(BaseClient):
    """Customer App management class for handling customer application operations.

    This class provides methods to manage customer applications including retrieval,
    deletion, and update operations.
    """

    def __init__(self, config: ClientConfig):
        """Initialize CustomerApp with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        super().__init__(config)
        self.logger = get_logger(__name__)
        self._api = CustomerAppApi(self.api_client)

    def delete_customer_app(self, app_name: str, updated_by: str) -> str:
        """Delete a customer application by its name.

        Args:
            app_name: The name of the customer application to delete.
            updated_by: Identifier of the user performing the deletion.

        Returns:
            str: Response confirming the deletion operation.

        Raises:
            MgmtSdkClientError: If customer app deletion fails due to client error (4xx)
            MgmtSdkServerError: If customer app deletion fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not app_name:
            raise PayloadConfigurationError("app_name is required and cannot be empty")
        if not updated_by or len(updated_by.strip()) == 0:
            raise PayloadConfigurationError(
                "updated_by is required and cannot be empty"
            )
        elif len(updated_by.strip()) > MAX_EMAIL_LENGTH:
            raise PayloadConfigurationError(
                f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
            )

        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.delete_customer_app.__name__} app_name={app_name}"
            )
            response = self._api.delete_customer_app(
                app_name=app_name.strip(), updated_by=updated_by.strip()
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to delete customer app: {e}"
            self.logger.error(
                f"event={self.delete_customer_app.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while deleting customer app: {e}"
            self.logger.error(
                f"event={self.delete_customer_app.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    def update_customer_app(
        self,
        customer_app_id: str,
        app_name: str,
        cloud_provider: str,
        environment: str,
        auth_code: str,
        dp_name: Optional[str] = None,
        model_name: Optional[str] = None,
        status: Optional[str] = None,
        updated_by: Optional[str] = None,
        ai_agent_framework: Optional[str] = None,
    ) -> CustomerAppObject:
        """Update a customer application with new settings.

        Args:
            customer_app_id: The unique identifier of the customer application to update.
            app_name: The name of the customer application to update.
            cloud_provider: Cloud Provider Name for the customer app.
            environment: Environment for the customer app.
            model_name: AI Model Name for the customer app. Optional.
            status: Customer app status (completed or pending). Optional.
            updated_by: Identifier of the user performing the update. Optional.
            ai_agent_framework: Framework associated for AI Agent. Optional.

        Returns:
            CustomerAppObject: The updated customer application object.

        Raises:
            MgmtSdkClientError: If customer app update fails due to client error (4xx)
            MgmtSdkServerError: If customer app update fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not customer_app_id or len(customer_app_id.strip()) == 0:
            raise PayloadConfigurationError(
                "customer_app_id is required and cannot be empty"
            )
        if not app_name:
            raise PayloadConfigurationError("app_name is required and cannot be empty")
        if not cloud_provider:
            raise PayloadConfigurationError(
                "cloud_provider is required and cannot be empty"
            )
        if not environment:
            raise PayloadConfigurationError(
                "environment is required and cannot be empty"
            )
        if not auth_code:
            raise PayloadConfigurationError("auth_code is required and cannot be empty")

        self.refresh_token_if_expired()

        # Build customer app object
        app_data = {
            "app_name": app_name.strip(),
            "cloud_provider": cloud_provider.strip(),
            "environment": environment.strip(),
            "customer_app_id": customer_app_id.strip(),
            "auth_code": auth_code.strip(),
        }
        if model_name is not None:
            app_data["model_name"] = model_name.strip()
        if status is not None:
            app_data["status"] = status.strip()
        if updated_by is not None:
            if len(updated_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            app_data["updated_by"] = updated_by.strip()
        if ai_agent_framework is not None:
            app_data["ai_agent_framework"] = ai_agent_framework.strip()
        if dp_name is not None:
            app_data["dp_name"] = dp_name.strip()

        customer_app_object = CustomerAppObject(**app_data)
        try:
            self.logger.info(
                f"event={self.update_customer_app.__name__} app_name={app_name}"
            )
            response = self._api.update_customer_app_by_id(
                customer_app_id=customer_app_id.strip(),
                customer_app_object=customer_app_object,
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to update customer app: {e}"
            self.logger.error(
                f"event={self.update_customer_app.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while updating customer app: {e}"
            self.logger.error(
                f"event={self.update_customer_app.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    def get_all_customer_apps(
        self, offset: int = 0, limit: int = 100
    ) -> PaginatedCustomerAppObject:
        """Retrieve all customer applications for a TSG ID with pagination support.

        Args:
            offset: The starting position for pagination (number of records to skip).
                Defaults to 0.
            limit: The maximum number of customer apps to retrieve in a single request.
                Defaults to 100.

        Returns:
            PaginatedCustomerAppObject: A paginated collection of customer app objects
                with pagination metadata.

        Raises:
            MgmtSdkClientError: If customer apps retrieval fails due to client error (4xx)
            MgmtSdkServerError: If customer apps retrieval fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        if offset < 0 or limit < 0:
            raise PayloadConfigurationError("offset and/or limit not specified")
        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.get_all_customer_apps.__name__} offset={offset} limit={limit}"
            )
            response = self._api.get_all_customer_apps_for_tsg_id(
                offset=offset, limit=limit
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to retrieve customer apps: {e}"
            self.logger.error(
                f"event={self.get_all_customer_apps.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while retrieving customer apps: {e}"
            self.logger.error(
                f"event={self.get_all_customer_apps.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)
