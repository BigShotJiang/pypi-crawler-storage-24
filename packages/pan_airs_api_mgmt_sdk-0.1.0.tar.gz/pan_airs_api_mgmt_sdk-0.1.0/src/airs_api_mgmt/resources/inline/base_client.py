# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

from __future__ import annotations

from urllib3 import poolmanager
from urllib3.util import Retry

from airs_api_mgmt.config import ClientConfig, TokenManager
from airs_api_mgmt.config.constants import (
    USER_AGENT,
    HTTP_FORCE_RETRY_STATUS_CODES,
    HEADER_AUTH_TOKEN,
    BEARER,
)

from airs_api_mgmt.sdk.inline.api_client import ApiClient

from airs_api_mgmt.utils import get_logger

log = get_logger(__name__)


class BaseClient:
    def __init__(self, config: ClientConfig):
        """Initialize BaseClient with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        self.config = config

        # Initialize token manager for OAuth2 token operations
        self._token_manager = TokenManager(config)

        self._api_client = self.create_api_client()

    @property
    def api_client(self):
        return self._api_client

    def create_api_client(self):
        api_client = ApiClient()
        api_client.user_agent = USER_AGENT

        api_client.rest_client.pool_manager = poolmanager.PoolManager(
            retries=Retry(
                total=self.config.num_retries,
                status_forcelist=HTTP_FORCE_RETRY_STATUS_CODES,
                backoff_factor=1,  # Wait 1s, 2s, 4s, 8s... between retries
            ),
        )

        if self.config.base_url is not None:
            api_client.configuration.host = self.config.base_url

        # Fetch new token using TokenManager
        access_token = self._token_manager.get_access_token()

        # Set token in API client configuration
        api_client.set_default_header(HEADER_AUTH_TOKEN, BEARER + access_token)

        log.info(
            f"event={self.create_api_client.__name__} action=new_api_client_created"
        )
        return api_client

    def refresh_token_if_expired(self):
        """Refresh the access token and update the API client headers.

        This method retrieves a fresh access token and updates the Authorization
        header in the API client. It should be called before making API requests
        to ensure the token is valid.
        """
        access_token = self._token_manager.get_access_token()
        self.api_client.set_default_header(HEADER_AUTH_TOKEN, BEARER + access_token)

    def close(self):
        """Close the HTTP connection pool.

        This method should be called when the client is no longer needed to clean up resources.
        """
        if self._api_client is not None and hasattr(self._api_client, "rest_client"):
            if hasattr(self._api_client.rest_client, "pool_manager"):
                self._api_client.rest_client.pool_manager.clear()
                log.debug("Closed HTTP connection pool")
