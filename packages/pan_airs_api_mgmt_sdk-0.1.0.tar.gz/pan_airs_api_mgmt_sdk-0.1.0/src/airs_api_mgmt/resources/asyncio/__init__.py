# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

"""
Asyncio resource classes for AI Security Management API.

This module provides asyncio resource classes for different API endpoint groups,
following an async/await pattern.
"""

from airs_api_mgmt.resources.asyncio.api_keys import ApiKeyAsync
from airs_api_mgmt.resources.asyncio.ai_sec_profiles import AISecProfileAsync
from airs_api_mgmt.resources.asyncio.custom_topic import CustomTopicAsync
from airs_api_mgmt.resources.asyncio.customer_app import CustomerAppAsync
from airs_api_mgmt.resources.asyncio.deployment_profiles import DeploymentProfilesAsync
from airs_api_mgmt.resources.asyncio.dlp_profiles import DLPProfilesAsync
from airs_api_mgmt.resources.asyncio.oauth import OauthAsync

__all__ = [
    "ApiKeyAsync",
    "AISecProfileAsync",
    "CustomTopicAsync",
    "CustomerAppAsync",
    "DeploymentProfilesAsync",
    "DLPProfilesAsync",
    "OauthAsync",
]
