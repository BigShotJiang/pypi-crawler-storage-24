# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

from __future__ import annotations

import aiohttp_retry

from airs_api_mgmt.config import ClientConfig, TokenManager
from airs_api_mgmt.config.constants import (
    USER_AGENT,
    HTTP_FORCE_RETRY_STATUS_CODES,
    HEADER_AUTH_TOKEN,
    BEARER,
    MAX_CONNECTION_POOL_SIZE,
)

from airs_api_mgmt.sdk.asyncio.api_client import ApiClient

from airs_api_mgmt.utils import get_logger

log = get_logger(__name__)


class BaseClient:
    def __init__(self, config: ClientConfig):
        """Initialize BaseClient with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        self.config = config

        # Initialize token manager for OAuth2 token operations
        self._token_manager = TokenManager(config)

        self._api_client = self.create_api_client()

    @property
    def api_client(self):
        """Get the API client instance.

        Note: For asyncio, the client must be initialized by calling
        ensure_initialized() before use.
        """
        return self._api_client

    def create_api_client(self):
        """Create and configure the API client (internal use)."""
        api_client = ApiClient()
        api_client.user_agent = USER_AGENT

        api_client.configuration.connection_pool_maxsize = MAX_CONNECTION_POOL_SIZE
        api_client.rest_client.retry_client = aiohttp_retry.RetryClient(
            client_session=api_client.rest_client.pool_manager,
            retry_options=aiohttp_retry.ExponentialRetry(
                attempts=self.config.num_retries,
                statuses=set(HTTP_FORCE_RETRY_STATUS_CODES),
            ),
        )

        if self.config.base_url is not None:
            api_client.configuration.host = self.config.base_url

        # Fetch new token using TokenManager (sync call, which is fine)
        access_token = self._token_manager.get_access_token()

        # Set token in API client configuration
        api_client.set_default_header(HEADER_AUTH_TOKEN, BEARER + access_token)

        log.info("event=_create_api_client action=new_api_client_created")

        return api_client

    def refresh_token_if_expired(self):
        """Refresh the access token and update the API client headers.

        This method retrieves a fresh access token and updates the Authorization
        header in the API client. It should be called before making API requests
        to ensure the token is valid.

        Note: Token acquisition uses synchronous HTTP calls, which is acceptable
        as token requests are infrequent and typically fast.
        """
        # Ensure client is initialized

        access_token = self._token_manager.get_access_token()
        self.api_client.set_default_header(HEADER_AUTH_TOKEN, BEARER + access_token)

    async def close(self):
        """Close the aiohttp sessions and token manager.

        This should be called when the client is no longer needed to clean up resources.
        """
        # Close API client
        if self._api_client is not None:
            await self._api_client.close()
