# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

from __future__ import annotations

from datetime import datetime
from typing import Optional

from airs_api_mgmt.config import ClientConfig
from airs_api_mgmt.config.constants import MAX_EMAIL_LENGTH
from airs_api_mgmt.sdk.asyncio import ApiException
from airs_api_mgmt.sdk.asyncio.api import CustomTopicApi
from airs_api_mgmt.sdk.models import CustomTopicObject, PaginatedCustomTopicObject
from airs_api_mgmt.resources.asyncio.base_client import BaseClient
from airs_api_mgmt.exceptions import (
    MgmtSdkAPIError,
    MgmtSdkServerError,
    MgmtSdkClientError,
    MgmtSdkBaseError,
    PayloadConfigurationError,
)
from airs_api_mgmt.utils import get_logger


class CustomTopicAsync(BaseClient):
    """Custom Topic management class for handling custom topic operations.

    This class provides methods to manage custom topics including retrieval,
    deletion, modification, and update operations.
    """

    def __init__(self, config: ClientConfig):
        """Initialize CustomTopic with a ClientConfig instance.

        Args:
            config: ClientConfig instance with authentication credentials
        """
        super().__init__(config)
        self.logger = get_logger(__name__)
        self._api = CustomTopicApi(self.api_client)

    async def create_new_custom_topic(
        self,
        topic_name: str,
        description: str,
        examples: list[str],
        revision: int,
        topic_id: Optional[str] = None,
        active: Optional[bool] = None,
        created_by: Optional[str] = None,
        updated_by: Optional[str] = None,
        last_modified_ts: Optional[datetime] = None,
        created_ts: Optional[datetime] = None,
    ) -> CustomTopicObject:
        """Create a new custom topic with the specified details.

        Args:
            topic_name: Name of the custom topic.
            description: Detailed explanation or purpose of the custom topic.
            examples: List of example usages or scenarios for the custom topic.
            revision: Revision number of the custom topic.
            topic_id: Unique identifier for the custom topic. Optional.
            active: Whether the custom topic is currently active or disabled. Optional.
            created_by: Email address of the user who created the custom topic. Optional.
            updated_by: Email address of the user creating the custom topic. Optional.
            last_modified_ts: Timestamp of when the custom topic was last modified. Optional.
            created_ts: Timestamp of when the custom topic was created. Optional.

        Returns:
            CustomTopicObject: The newly created custom topic object.

        Raises:
            MgmtSdkClientError: If custom topic creation fails due to client error (4xx)
            MgmtSdkServerError: If custom topic creation fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not topic_name:
            raise PayloadConfigurationError(
                "topic_name is required and cannot be empty"
            )
        if not description:
            raise PayloadConfigurationError(
                "description is required and cannot be empty"
            )
        if not examples:
            raise PayloadConfigurationError("examples is required and cannot be empty")
        if revision is None:
            raise PayloadConfigurationError("revision is required and cannot be None")

        self.refresh_token_if_expired()

        # Build custom topic object
        topic_data = {
            "topic_name": topic_name.strip(),
            "description": description.strip(),
            "examples": examples,
            "revision": revision,
        }
        if topic_id is not None:
            topic_data["topic_id"] = topic_id.strip()
        if active is not None:
            topic_data["active"] = active
        if created_by is not None:
            if len(created_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"created_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            topic_data["created_by"] = created_by.strip()
        if updated_by is not None:
            if len(updated_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            topic_data["updated_by"] = updated_by.strip()
        if last_modified_ts is not None:
            topic_data["last_modified_ts"] = last_modified_ts
        if created_ts is not None:
            topic_data["created_ts"] = created_ts

        custom_topic_object = CustomTopicObject(**topic_data)
        try:
            self.logger.info(
                f"event={self.create_new_custom_topic.__name__} topic_name={topic_name}"
            )
            response = await self._api.create_new_custom_topic(
                custom_topic_object=custom_topic_object
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to create custom topic: {e}"
            self.logger.error(
                f"event={self.create_new_custom_topic.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while creating custom topic: {e}"
            self.logger.error(
                f"event={self.create_new_custom_topic.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    async def delete_custom_topic(self, topic_id: str) -> str:
        """Delete a custom topic by its ID.

        Args:
            topic_id: The unique identifier of the custom topic to delete.

        Returns:
            str: Response confirming the deletion operation.

        Raises:
            MgmtSdkClientError: If custom topic deletion fails due to client error (4xx)
            MgmtSdkServerError: If custom topic deletion fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not topic_id or len(topic_id.strip()) == 0:
            raise PayloadConfigurationError("topic_id is required and cannot be empty")

        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.delete_custom_topic.__name__} topic_id={topic_id}"
            )
            response = await self._api.delete_custom_topic(topic_id=topic_id.strip())
            return response
        except ApiException as e:
            error_msg = f"Failed to delete custom topic: {e}"
            self.logger.error(
                f"event={self.delete_custom_topic.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while deleting custom topic: {e}"
            self.logger.error(
                f"event={self.delete_custom_topic.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    async def force_delete_custom_topic(self, topic_id: str, updated_by: str) -> str:
        """Force delete a custom topic by its ID.

        Args:
            topic_id: The unique identifier of the custom topic to force delete.
            updated_by: Identifier of the user performing the deletion.

        Returns:
            str: Response confirming the force deletion operation.

        Raises:
            MgmtSdkClientError: If custom topic force deletion fails due to client error (4xx)
            MgmtSdkServerError: If custom topic force deletion fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not topic_id or len(topic_id.strip()) == 0:
            raise PayloadConfigurationError("topic_id is required and cannot be empty")
        if not updated_by or len(updated_by.strip()) == 0:
            raise PayloadConfigurationError(
                "updated_by is required and cannot be empty"
            )
        elif len(updated_by.strip()) > MAX_EMAIL_LENGTH:
            raise PayloadConfigurationError(
                f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
            )

        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.force_delete_custom_topic.__name__} topic_id={topic_id}"
            )
            response = await self._api.force_delete_custom_topic(
                topic_id=topic_id.strip(), updated_by=updated_by.strip()
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to force delete custom topic: {e}"
            self.logger.error(
                f"event={self.force_delete_custom_topic.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while force deleting custom topic: {e}"
            self.logger.error(
                f"event={self.force_delete_custom_topic.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    async def modify_custom_topic_details(
        self,
        topic_id: str,
        topic_name: str,
        description: str,
        examples: list[str],
        revision: int,
        active: Optional[bool] = None,
        created_by: Optional[str] = None,
        updated_by: Optional[str] = None,
        last_modified_ts: Optional[datetime] = None,
        created_ts: Optional[datetime] = None,
    ) -> CustomTopicObject:
        """Modify a custom topic with updated details.

        Args:
            topic_id: The unique identifier of the custom topic to modify.
            topic_name: Name of the custom topic.
            description: Detailed explanation or purpose of the custom topic.
            examples: List of example usages or scenarios for the custom topic.
            revision: Revision number of the custom topic.
            active: Whether the custom topic is currently active or disabled. Optional.
            created_by: Email address of the user who created the custom topic. Optional.
            updated_by: Email address of the user modifying the custom topic. Optional.
            last_modified_ts: Timestamp of when the custom topic was last modified. Optional.
            created_ts: Timestamp of when the custom topic was created. Optional.

        Returns:
            CustomTopicObject: The modified custom topic object.

        Raises:
            MgmtSdkClientError: If custom topic modification fails due to client error (4xx)
            MgmtSdkServerError: If custom topic modification fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        # Validate mandatory arguments
        if not topic_id:
            raise PayloadConfigurationError("topic_id is required and cannot be empty")
        if not topic_name:
            raise PayloadConfigurationError(
                "topic_name is required and cannot be empty"
            )
        if not description:
            raise PayloadConfigurationError(
                "description is required and cannot be empty"
            )
        if not examples:
            raise PayloadConfigurationError("examples is required and cannot be empty")
        if revision is None:
            raise PayloadConfigurationError("revision is required and cannot be None")

        self.refresh_token_if_expired()

        # Build custom topic object
        topic_data = {
            "topic_name": topic_name.strip(),
            "description": description.strip(),
            "examples": examples,
            "revision": revision,
        }
        if active is not None:
            topic_data["active"] = active
        if created_by is not None:
            if len(created_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"created_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            topic_data["created_by"] = created_by.strip()
        if updated_by is not None:
            if len(updated_by.strip()) > MAX_EMAIL_LENGTH:
                raise PayloadConfigurationError(
                    f"updated_by cannot exceed {MAX_EMAIL_LENGTH} characters"
                )
            topic_data["updated_by"] = updated_by.strip()
        if last_modified_ts is not None:
            topic_data["last_modified_ts"] = last_modified_ts
        if created_ts is not None:
            topic_data["created_ts"] = created_ts

        custom_topic_object = CustomTopicObject(**topic_data)
        try:
            self.logger.info(
                f"event={self.modify_custom_topic_details.__name__} topic_id={topic_id}"
            )
            response = await self._api.update_topic_by_topic_id(
                topic_id=topic_id.strip(), custom_topic_object=custom_topic_object
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to modify custom topic: {e}"
            self.logger.error(
                f"event={self.modify_custom_topic_details.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while modifying custom topic: {e}"
            self.logger.error(
                f"event={self.modify_custom_topic_details.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)

    async def get_all_custom_topics(
        self, offset: int = 0, limit: int = 100
    ) -> PaginatedCustomTopicObject:
        """Retrieve all custom topics for a TSG ID with pagination support.

        Args:
            offset: The starting position for pagination (number of records to skip).
                Defaults to 0.
            limit: The maximum number of custom topics to retrieve in a single request.
                Defaults to 100.

        Returns:
            PaginatedCustomTopicObject: A paginated collection of custom topic objects
                with pagination metadata.

        Raises:
            MgmtSdkClientError: If custom topics retrieval fails due to client error (4xx)
            MgmtSdkServerError: If custom topics retrieval fails due to server error (5xx)
            MgmtSdkBaseError: If an unexpected error occurs
        """
        self.refresh_token_if_expired()
        try:
            self.logger.info(
                f"event={self.get_all_custom_topics.__name__} offset={offset} limit={limit}"
            )
            response = await self._api.get_all_custom_topics_for_tsg_id(
                offset=offset, limit=limit
            )
            return response
        except ApiException as e:
            error_msg = f"Failed to retrieve custom topics: {e}"
            self.logger.error(
                f"event={self.get_all_custom_topics.__name__} error={error_msg}"
            )

            status = getattr(e, "status", None)
            reason = getattr(e, "reason", None)
            body = getattr(e, "body", None)

            if status and 400 <= status < 500:
                raise MgmtSdkClientError(
                    reason or error_msg, status_code=status, response_body=body
                )
            elif status and status >= 500:
                raise MgmtSdkServerError(
                    reason or error_msg, status_code=status, response_body=body
                )
            else:
                raise MgmtSdkAPIError(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error while retrieving custom topics: {e}"
            self.logger.error(
                f"event={self.get_all_custom_topics.__name__} error={error_msg}"
            )
            raise MgmtSdkBaseError(error_msg)
