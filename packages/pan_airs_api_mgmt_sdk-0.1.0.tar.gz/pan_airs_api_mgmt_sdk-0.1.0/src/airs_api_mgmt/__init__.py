# Copyright (c) 2025, Palo Alto Networks
#
# Licensed under the Polyform Internal Use License 1.0.0 (the "License");
# you may not use this file except in compliance with the License.
#
# You may obtain a copy of the License at:
#
# https://polyformproject.org/licenses/internal-use/1.0.0
# (or)
# https://github.com/polyformproject/polyform-licenses/blob/76a278c4/PolyForm-Internal-Use-1.0.0.md
#
# As far as the law allows, the software comes as is, without any warranty
# or condition, and the licensor will not be liable to you for any damages
# arising out of these terms or the use or nature of the software, under
# any kind of legal claim.

"""
Palo Alto Networks Prisma AIRS API Management SDK

Provides both synchronous and asynchronous SDKs for the AIRS API.
"""

from airs_api_mgmt._version import __version__

# Shared models - available to all users
from .sdk import models


# High-level clients (if available)
try:
    from airs_api_mgmt.mgmt_client import MgmtClient
except ImportError:
    MgmtClient = None

try:
    from airs_api_mgmt.mgmt_client_async import MgmtClientAsync
except ImportError:
    MgmtClientAsync = None

# Exceptions
from airs_api_mgmt.exceptions import (
    MgmtSdkBaseError,
    MgmtSdkAPIError,
    MgmtSdkClientError,
    MgmtSdkServerError,
    MgmtSdkConfigurationError,
)

# For advanced users who want low-level SDK access
from . import sdk

__all__ = [
    "__version__",
    "models",
    "MgmtClient",
    "MgmtClientAsync",
    "MgmtSdkBaseError",
    "MgmtSdkAPIError",
    "MgmtSdkClientError",
    "MgmtSdkServerError",
    "MgmtSdkConfigurationError",
    "sdk",
]
