"""debugger.help VPS Agent — Deep system monitoring."""
__version__ = "4.0.0"
