"""Chat history storage and management (stored in ~/.cellsistant/history/*.json)."""

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List

import tornado.web
from jupyter_server.base.handlers import APIHandler


HISTORY_DIR = Path.home() / ".cellsistant" / "history"

MAX_CHATS = 100
MAX_CHAT_SIZE = 5 * 1024 * 1024


def ensure_history_dir():
    """Create history directory if it doesn't exist."""
    HISTORY_DIR.mkdir(parents=True, exist_ok=True)


def generate_chat_id() -> str:
    """Generate unique chat ID."""
    return f"{int(datetime.now(timezone.utc).timestamp())}_{uuid.uuid4().hex[:8]}"


def extract_title(messages: List[Dict]) -> str:
    """Extract title from first user message."""
    for msg in messages:
        if msg.get("role") == "user" and msg.get("content"):
            content = msg["content"]
            first_line = content.split("\n")[0].strip()
            if len(first_line) > 80:
                return first_line[:77] + "..."
            return first_line
    return "Untitled chat"


class HistoryListHandler(APIHandler):
    """GET /ai-agent/history — list of chats."""

    def check_xsrf_cookie(self):
        """Disable XSRF check for API requests."""
        pass

    @tornado.web.authenticated
    async def get(self):
        try:
            ensure_history_dir()

            chats = []
            for file_path in sorted(HISTORY_DIR.glob("*.json"), reverse=True):
                try:
                    with open(file_path, encoding="utf-8") as f:
                        data = json.load(f)

                    chats.append(
                        {
                            "id": file_path.stem,
                            "title": data.get("title", "Untitled"),
                            "created_at": data.get("created_at", ""),
                            "updated_at": data.get("updated_at", ""),
                            "message_count": len(data.get("messages", [])),
                        }
                    )
                except (OSError, json.JSONDecodeError):
                    continue

            # Limit count
            chats = chats[:MAX_CHATS]

            self.finish({"chats": chats})

        except Exception as e:
            self.set_status(500)
            self.finish({"error": str(e)})


class HistorySaveHandler(APIHandler):
    """POST /ai-agent/history/save — save chat."""

    def check_xsrf_cookie(self):
        """Disable XSRF check for API requests."""
        pass

    @tornado.web.authenticated
    async def post(self):
        try:
            data = self.get_json_body()
            messages = data.get("messages", [])
            chat_id = data.get("id")  # If passed, update existing
            title = data.get("title")

            if not messages:
                self.set_status(400)
                self.finish({"error": "Messages array is required"})
                return

            ensure_history_dir()

            now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

            if chat_id:
                # Update existing
                file_path = HISTORY_DIR / f"{chat_id}.json"
                if file_path.exists():
                    with open(file_path, encoding="utf-8") as f:
                        existing = json.load(f)
                    created_at = existing.get("created_at", now)
                else:
                    created_at = now
            else:
                # New chat
                chat_id = generate_chat_id()
                created_at = now

            if not title:
                title = extract_title(messages)

            chat_data = {
                "id": chat_id,
                "title": title,
                "created_at": created_at,
                "updated_at": now,
                "messages": messages,
            }

            # Check size
            serialized = json.dumps(chat_data, ensure_ascii=False)
            if len(serialized) > MAX_CHAT_SIZE:
                self.set_status(413)
                self.finish(
                    {
                        "error": f"Chat too large: {len(serialized)} bytes (max {MAX_CHAT_SIZE})"
                    }
                )
                return

            file_path = HISTORY_DIR / f"{chat_id}.json"
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(serialized)

            # Delete old chats if limit exceeded
            cleanup_old_chats()

            self.finish({"id": chat_id, "title": title, "message": "Chat saved"})

        except Exception as e:
            self.set_status(500)
            self.finish({"error": str(e)})


class HistoryItemHandler(APIHandler):
    """Universal handler for /ai-agent/history/{id}."""

    def check_xsrf_cookie(self):
        """Disable XSRF check for API requests."""
        pass

    @tornado.web.authenticated
    async def get(self, chat_id: str):
        """Load chat."""
        try:
            ensure_history_dir()

            file_path = HISTORY_DIR / f"{chat_id}.json"
            if not file_path.exists():
                self.set_status(404)
                self.finish({"error": f"Chat not found: {chat_id}"})
                return

            with open(file_path, encoding="utf-8") as f:
                data = json.load(f)

            self.finish(data)

        except Exception as e:
            self.set_status(500)
            self.finish({"error": str(e)})

    @tornado.web.authenticated
    async def delete(self, chat_id: str):
        """Delete chat."""
        try:
            ensure_history_dir()

            file_path = HISTORY_DIR / f"{chat_id}.json"
            if file_path.exists():
                file_path.unlink()
                self.finish({"message": f"Chat {chat_id} deleted"})
            else:
                self.set_status(404)
                self.finish({"error": f"Chat not found: {chat_id}"})

        except Exception as e:
            self.set_status(500)
            self.finish({"error": str(e)})


class HistoryExportHandler(APIHandler):
    """GET /ai-agent/history/{id}/export — export chat to Markdown."""

    def check_xsrf_cookie(self):
        """Disable XSRF check for API requests."""
        pass

    @tornado.web.authenticated
    async def get(self, chat_id: str):
        try:
            ensure_history_dir()

            file_path = HISTORY_DIR / f"{chat_id}.json"
            if not file_path.exists():
                self.set_status(404)
                self.finish({"error": f"Chat not found: {chat_id}"})
                return

            with open(file_path, encoding="utf-8") as f:
                data = json.load(f)

            # Build Markdown
            md_lines = [
                f"# {data.get('title', 'Untitled Chat')}",
                "",
                f"**Created:** {data.get('created_at', 'Unknown')}",
                f"**Updated:** {data.get('updated_at', 'Unknown')}",
                "",
                "---",
                "",
            ]

            for msg in data.get("messages", []):
                role = msg.get("role", "unknown")
                content = msg.get("content", "")

                if role == "user":
                    md_lines.append("## 👤 User")
                elif role == "assistant":
                    md_lines.append("## 🤖 Assistant")
                elif role == "tool":
                    md_lines.append("## 🔧 Tool")
                else:
                    md_lines.append(f"## {role.capitalize()}")

                md_lines.append("")
                if content:
                    md_lines.append(content)
                md_lines.append("")
                md_lines.append("---")
                md_lines.append("")

            markdown_content = "\n".join(md_lines)

            # Return as text
            self.set_header("Content-Type", "text/markdown; charset=utf-8")

            # Filename like chat-{id}.md
            filename = f"chat-{chat_id}.md"

            self.set_header("Content-Disposition", f"attachment; filename={filename}")
            self.finish(markdown_content)

        except Exception as e:
            self.set_status(500)
            self.finish({"error": str(e)})


def cleanup_old_chats():
    """Delete oldest chats if limit exceeded."""
    files = sorted(HISTORY_DIR.glob("*.json"))
    while len(files) > MAX_CHATS:
        oldest = files.pop(0)
        oldest.unlink()
