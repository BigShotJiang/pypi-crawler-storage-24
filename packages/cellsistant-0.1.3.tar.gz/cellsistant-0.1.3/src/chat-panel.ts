import { MainAreaWidget } from '@jupyterlab/apputils';
import { Widget } from '@lumino/widgets';
import { streamFromLLM, ILLMMessage } from './api';
import { toolRegistry } from './tool-registry';
import { PermissionManager } from './permission-manager';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { IThemeManager } from '@jupyterlab/apputils';
import {
  INotebookTracker,
  NotebookPanel,
  NotebookActions
} from '@jupyterlab/notebook';
import hljs from 'highlight.js';
import { estimateMessagesTokens, formatTokenCount } from './token-counter';
import {
  listChats,
  saveChat,
  loadChat,
  deleteChat,
  exportChat,
  exportChatAsJson
} from './history-api';
import { ContextCollector } from './context-collector';
import { VariableInspector } from './variable-inspector';
import { renderSettingsPanelContent } from './settings-dialog';
import { getSettings } from './settings-api';
import {
  codeIcon,
  historyIcon,
  settingsIcon,
  redoIcon,
  addAboveIcon,
  addBelowIcon,
  copyIcon
} from '@jupyterlab/ui-components';

/** Context configuration */
interface IContextConfig {
  includeCellOutline: boolean;
  includeVariables: boolean;
  maxCellsInOutline: number;
  maxVariables: number;
  smartMode: boolean;
}

const DEFAULT_CONTEXT_CONFIG: IContextConfig = {
  includeCellOutline: true,
  includeVariables: true,
  maxCellsInOutline: 20,
  maxVariables: 30,
  smartMode: true
};

/** Process inline markdown in table cells */
function parseInlineMarkdown(text: string): string {
  let result = text;
  result = result.replace(/`(.+?)`/g, '<code class="inline-code">$1</code>');
  result = result.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  result = result.replace(/__(.+?)__/g, '<strong>$1</strong>');
  result = result.replace(/\*(.+?)\*/g, '<em>$1</em>');
  result = result.replace(/_(.+?)_/g, '<em>$1</em>');
  result = result.replace(/~~(.+?)~~/g, '<del>$1</del>');
  result = result.replace(
    /\[(.+?)\]\((.+?)\)/g,
    '<a href="$2" target="_blank">$1</a>'
  );
  return result;
}

/** Simple markdown-to-HTML parser */
function parseMarkdown(text: string): string {
  let html = text;

  html = html
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Preserve tables during formatting
  const tables: string[] = [];
  html = html.replace(
    /^\|(.+)\|\n\|[-:| ]+\|\n((?:\|.*\|\n?)+)/gm,
    (_match, headerRow, bodyRows) => {
      const headers = headerRow
        .split('|')
        .filter((h: string) => h.trim())
        .map((h: string) => `<th>${parseInlineMarkdown(h.trim())}</th>`)
        .join('');
      const rows = bodyRows
        .trim()
        .split('\n')
        .map((row: string) => {
          const cells = row
            .split('|')
            .filter((c: string) => c.trim())
            .map((c: string) => `<td>${parseInlineMarkdown(c.trim())}</td>`)
            .join('');
          return `<tr>${cells}</tr>`;
        })
        .join('');
      tables.push(
        `<table><thead><tr>${headers}</tr></thead><tbody>${rows}</tbody></table>`
      );
      return `<!--TABLE${tables.length - 1}-->`;
    }
  );

  // Preserve code blocks with syntax highlighting
  const codeBlocks: string[] = [];
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_match, lang, code) => {
    const idx = codeBlocks.length;
    const langClass = lang ? `language-${lang}` : '';
    const highlighted = hljs.highlightAuto(code).value;
    codeBlocks.push(
      `<pre class="code-block"><code class="${langClass}">${highlighted}</code></pre>`
    );
    return `<!--CODEBLOCK${idx}-->`;
  });

  // Inline code after blocks to avoid capturing ```
  html = html.replace(/`(.+?)`/g, '<code class="inline-code">$1</code>');

  // Bold text
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');

  // Italic text
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
  html = html.replace(/_(.+?)_/g, '<em>$1</em>');

  // Strikethrough
  html = html.replace(/~~(.+?)~~/g, '<del>$1</del>');

  // Links
  html = html.replace(
    /\[(.+?)\]\((.+?)\)/g,
    '<a href="$2" target="_blank">$1</a>'
  );

  // Bullet lists
  html = html.replace(/^[-*]\s+(.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

  // Numbered lists
  html = html.replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>');

  // Headers
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

  // Line breaks
  html = html.replace(/\n/g, '<br>');

  // Restore tables
  tables.forEach((table, i) => {
    html = html.replace(`<!--TABLE${i}-->`, table);
  });

  // Restore code blocks with action buttons
  codeBlocks.forEach((block, i) => {
    const buttons = `<div class="code-block-buttons">
      <button class="code-btn copy-btn" data-code="${i}" title="Copy">
        <span class="copy-icon"></span>
      </button>
      <button class="code-btn add-above-btn" data-code="${i}" title="Add to cell above">
        <span class="add-above-icon"></span>
      </button>
      <button class="code-btn add-below-btn" data-code="${i}" title="Add to cell below">
        <span class="add-below-icon"></span>
      </button>
    </div>`;
    html = html.replace(
      `<!--CODEBLOCK${i}-->`,
      `<div class="code-block-wrapper">${block}${buttons}</div>`
    );
  });

  return html;
}

/** Chat panel with agent loop */
export class ChatPanel extends MainAreaWidget {
  private messagesArea!: HTMLElement;
  private inputField!: HTMLTextAreaElement;
  private sendButton!: HTMLButtonElement;
  private stopButton!: HTMLButtonElement;
  private isLoading = false;
  private abortController: AbortController | null = null;
  private themeManager: IThemeManager;
  private notebookTracker: INotebookTracker;
  private lastUserMessage: string | null = null;

  private conversationHistory: ILLMMessage[] = [];
  private tokenCounter!: HTMLElement;
  private autoExecuteTools: boolean = true;
  private askMode: boolean = false;

  // Chat history
  private currentChatId: string | null = null;
  private historyPanel!: HTMLElement;
  private settingsPanel!: HTMLElement;
  private isHistoryLoading: boolean = false;

  // Auto context
  private contextCollector: ContextCollector;
  private variableInspector: VariableInspector;
  private contextConfig = DEFAULT_CONTEXT_CONFIG;
  private lastContextNotebook: string | null = null;
  private lastContextTimestamp: number = 0;

  // Settings
  private maxAgentIterations: number = 15;

  constructor(
    app: JupyterFrontEnd,
    themeManager: IThemeManager,
    notebookTracker: INotebookTracker
  ) {
    super({ content: new Widget({ node: document.createElement('div') }) });

    this.themeManager = themeManager;
    this.notebookTracker = notebookTracker;
    this.id = 'jupyterlab-ai-agent-panel';
    this.title.closable = true;
    this.title.icon = codeIcon;

    // Initialize context collectors
    this.contextCollector = new ContextCollector(app, notebookTracker);
    this.variableInspector = new VariableInspector(notebookTracker);

    // Build UI structure
    this.createUI();

    // Listen for theme changes
    this.syncTheme();
    this.themeManager.themeChanged.connect(this.onThemeChanged, this);

    // Load settings on init
    this.loadSettingsFromServer();
  }

  private createUI(): void {
    const container = this.content.node;
    container.className = 'ai-agent-container';
    container.style.position = 'relative';

    // Header with mode checkbox and panel buttons
    const header = document.createElement('div');
    header.className = 'ai-agent-header';

    const headerTop = document.createElement('div');
    headerTop.className = 'ai-agent-header-top';

    // Title
    const titleEl = document.createElement('h2');
    titleEl.textContent = 'Cellsistant';
    titleEl.style.margin = '0';
    titleEl.style.flex = '1';

    // History button
    const historyBtn = document.createElement('button');
    historyBtn.className = 'jp-Button ai-agent-history-btn';
    historyBtn.appendChild(historyIcon.element());
    historyBtn.title = 'Chat History';
    historyBtn.addEventListener('click', () => this.toggleHistoryPanel());

    // Settings button
    const settingsBtn = document.createElement('button');
    settingsBtn.className = 'jp-Button ai-agent-settings-btn';
    settingsBtn.appendChild(settingsIcon.element());
    settingsBtn.title = 'AI Agent Settings';
    settingsBtn.addEventListener('click', () => this.toggleSettingsPanel());

    headerTop.appendChild(titleEl);
    headerTop.appendChild(historyBtn);
    headerTop.appendChild(settingsBtn);

    header.appendChild(headerTop);
    container.appendChild(header);

    // History panel
    this.historyPanel = document.createElement('div');
    this.historyPanel.className = 'ai-agent-settings-panel ai-agent-hidden';
    container.appendChild(this.historyPanel);

    // Settings panel
    this.settingsPanel = document.createElement('div');
    this.settingsPanel.className = 'ai-agent-settings-panel ai-agent-hidden';
    container.appendChild(this.settingsPanel);

    // Messages area
    this.messagesArea = document.createElement('div');
    this.messagesArea.className = 'ai-agent-messages';
    container.appendChild(this.messagesArea);

    // Input area
    const inputContainer = document.createElement('div');
    inputContainer.className = 'ai-agent-input-container';

    this.inputField = document.createElement('textarea');
    this.inputField.className = 'ai-agent-input';
    this.inputField.placeholder =
      'Type a message... (Enter to send, Shift+Enter for new line)';
    this.inputField.rows = 3;

    this.sendButton = document.createElement('button');
    this.sendButton.className = 'jp-Button ai-agent-send-button';
    this.sendButton.textContent = 'Send';
    this.sendButton.title = 'Send';

    // Stop button (hidden initially)
    this.stopButton = document.createElement('button');
    this.stopButton.className =
      'jp-Button ai-agent-stop-button ai-agent-hidden';
    this.stopButton.textContent = 'Stop';
    this.stopButton.title = 'Stop';
    this.stopButton.addEventListener('click', () => this.handleStop());

    inputContainer.appendChild(this.inputField);
    inputContainer.appendChild(this.sendButton);
    inputContainer.appendChild(this.stopButton);
    container.appendChild(inputContainer);

    // Status bar with Ask mode checkbox and token counter
    const statusBar = document.createElement('div');
    statusBar.className = 'ai-agent-status-bar';

    // Ask mode checkbox
    const askModeContainer = document.createElement('label');
    askModeContainer.className = 'ai-agent-ask-mode';
    askModeContainer.title = 'Ask mode: read-only, no code execution';

    const askModeCheckbox = document.createElement('input');
    askModeCheckbox.type = 'checkbox';
    askModeCheckbox.className = 'ai-agent-ask-mode-checkbox';

    // Load saved state from localStorage
    const savedAskMode = localStorage.getItem('ai-agent-ask-mode');
    if (savedAskMode === 'true') {
      askModeCheckbox.checked = true;
      this.askMode = true;
    }

    askModeCheckbox.addEventListener('change', () => {
      this.askMode = askModeCheckbox.checked;
      localStorage.setItem(
        'ai-agent-ask-mode',
        String(askModeCheckbox.checked)
      );
    });

    const askModeLabel = document.createElement('span');
    askModeLabel.textContent = 'Ask';

    askModeContainer.appendChild(askModeCheckbox);
    askModeContainer.appendChild(askModeLabel);

    this.tokenCounter = document.createElement('span');
    this.tokenCounter.className = 'ai-agent-token-counter';
    this.tokenCounter.textContent = '';

    statusBar.appendChild(askModeContainer);
    statusBar.appendChild(this.tokenCounter);
    container.appendChild(statusBar);

    // Event handlers
    this.sendButton.addEventListener('click', () => this.handleUserMessage());
    this.inputField.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.handleUserMessage();
      }
      // Escape to cancel
      if (e.key === 'Escape' && this.isLoading) {
        e.preventDefault();
        this.handleStop();
      }
    });

    // Also catch Escape at container level
    container.addEventListener('keydown', e => {
      if (e.key === 'Escape' && this.isLoading) {
        e.preventDefault();
        this.handleStop();
      }
    });

    // Welcome message
    this.addBubble(
      'assistant',
      'Hello! I am AI Agent. I can write and execute code in your notebook. Try: "Write a fibonacci function and execute it"'
    );
  }

  // ─────────────────────────────────────────────
  // UI helpers
  // ─────────────────────────────────────────────

  /** Scroll chat to bottom */
  private scrollToBottom(): void {
    this.messagesArea.scrollTop = this.messagesArea.scrollHeight;
  }

  /** Add message bubble to chat */
  private addBubble(role: 'user' | 'assistant', text: string): void {
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-agent-message ${role}`;

    const roleLabel = document.createElement('span');
    roleLabel.className = 'ai-agent-message-role';
    roleLabel.textContent = role === 'user' ? 'You:' : 'AI:';

    const textDiv = document.createElement('div');
    textDiv.className = 'ai-agent-message-text';
    textDiv.innerHTML = parseMarkdown(text);

    messageDiv.appendChild(roleLabel);
    messageDiv.appendChild(textDiv);
    this.messagesArea.appendChild(messageDiv);
    this.scrollToBottom();

    this.addCodeBlockButtons(textDiv, text);
  }

  /** Add action buttons to code blocks */
  private addCodeBlockButtons(
    textDiv: HTMLElement,
    originalText: string
  ): void {
    const wrappers = textDiv.querySelectorAll('.code-block-wrapper');
    wrappers.forEach(wrapper => {
      const btnContainer = wrapper.querySelector('.code-block-buttons');
      if (!btnContainer) {
        return;
      }

      const copyBtn = btnContainer.querySelector('.copy-icon');
      const addAboveBtn = btnContainer.querySelector('.add-above-icon');
      const addBelowBtn = btnContainer.querySelector('.add-below-icon');

      if (copyBtn) {
        copyIcon.element({
          container: copyBtn as HTMLElement,
          width: '14px',
          height: '14px'
        });
      }
      if (addAboveBtn) {
        addAboveIcon.element({
          container: addAboveBtn as HTMLElement,
          width: '14px',
          height: '14px'
        });
      }
      if (addBelowBtn) {
        addBelowIcon.element({
          container: addBelowBtn as HTMLElement,
          width: '14px',
          height: '14px'
        });
      }

      const buttons = btnContainer.querySelectorAll('.code-btn');
      buttons.forEach(btn => {
        btn.addEventListener('click', () => {
          const codeBlock = (wrapper as HTMLElement).querySelector('code');
          const code = codeBlock?.textContent || '';
          const btnType = (btn as HTMLElement).classList.contains('copy-btn')
            ? 'copy'
            : (btn as HTMLElement).classList.contains('add-above-btn')
              ? 'above'
              : 'below';
          this.handleCodeBlockAction(code, btnType);
        });
      });
    });
  }

  /** Handle code block button actions */
  private handleCodeBlockAction(code: string, action: string): void {
    const trimmedCode = code.trim();
    if (action === 'copy') {
      navigator.clipboard.writeText(trimmedCode);
      this.showNotification('Code copied!', 'success');
    } else {
      this.addCodeToNotebook(trimmedCode, action === 'above');
    }
  }

  /** Insert code into notebook cell */
  private async addCodeToNotebook(
    code: string,
    addAbove: boolean
  ): Promise<void> {
    const notebook = this.notebookTracker.currentWidget as NotebookPanel | null;

    if (!notebook) {
      this.showNotification('No notebook open', 'error');
      return;
    }

    const notebookContent = notebook.content as any;
    const activeIndex = notebookContent.activeCellIndex;

    try {
      if (addAbove) {
        notebookContent.activeCellIndex = activeIndex;
        NotebookActions.insertBelow(notebookContent);
        await new Promise(resolve => setTimeout(resolve, 50));

        const newCell = notebookContent.model?.cells?.get(activeIndex);
        if (newCell) {
          const cellAny = newCell as any;
          if (cellAny.sharedModel) {
            cellAny.sharedModel.setSource(code);
          } else if (cellAny.value) {
            cellAny.value.text = code;
          }
        }
      } else {
        NotebookActions.insertBelow(notebookContent);
        await new Promise(resolve => setTimeout(resolve, 50));

        const newIndex = activeIndex + 1;
        const newCell = notebookContent.model?.cells?.get(newIndex);
        if (newCell) {
          const cellAny = newCell as any;
          if (cellAny.sharedModel) {
            cellAny.sharedModel.setSource(code);
          } else if (cellAny.value) {
            cellAny.value.text = code;
          }
        }
      }

      this.showNotification(
        `Code added to new cell ${addAbove ? 'above' : 'below'}`,
        'success'
      );
    } catch (error) {
      console.error('Error adding code:', error);
      this.showNotification('Failed to add code', 'error');
    }
  }

  /** Add error message with retry button */
  private addErrorBubbleWithRetry(errorText: string): void {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'ai-agent-message assistant ai-agent-error-message';

    const roleLabel = document.createElement('span');
    roleLabel.className = 'ai-agent-message-role';
    roleLabel.textContent = 'AI:';

    const textDiv = document.createElement('div');
    textDiv.className = 'ai-agent-message-text';
    textDiv.innerHTML = parseMarkdown(errorText);

    const retryButton = document.createElement('button');
    retryButton.className = 'jp-Button ai-agent-retry-button';
    const retryIcon = redoIcon.element();
    retryIcon.style.width = '14px';
    retryIcon.style.height = '14px';
    retryButton.appendChild(retryIcon);
    retryButton.appendChild(document.createTextNode(' Retry'));
    retryButton.title = 'Retry last request';

    messageDiv.appendChild(roleLabel);
    messageDiv.appendChild(textDiv);
    messageDiv.appendChild(retryButton);
    this.messagesArea.appendChild(messageDiv);
    this.scrollToBottom();

    // Retry button handler
    retryButton.addEventListener('click', () => {
      messageDiv.remove();
      this.handleUserMessage(true);
    });
  }

  /** Add tool call message bubble */
  private addToolBubble(
    name: string,
    args: Record<string, unknown>,
    status: string
  ): HTMLElement {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'ai-agent-tool-call';

    const statusIcon =
      {
        pending: '&#9203;',
        completed: '&#10004;',
        error: '&#10060;'
      }[status] || '&#9203;';

    // Collapsible header
    const headerDiv = document.createElement('div');
    headerDiv.className = 'ai-agent-tool-call-header';
    headerDiv.innerHTML = `
      <span class="tool-collapse-icon">▼</span>
      <span class="tool-status">${statusIcon}</span>
      <strong>${name}</strong>
    `;

    // Collapsible body
    const bodyDiv = document.createElement('div');
    bodyDiv.className = 'ai-agent-tool-call-body';

    const argsDiv = document.createElement('div');
    argsDiv.className = 'ai-agent-tool-call-args';
    argsDiv.textContent = this.formatArgs(name, args);

    bodyDiv.appendChild(argsDiv);
    messageDiv.appendChild(headerDiv);
    messageDiv.appendChild(bodyDiv);

    // Toggle collapse on header click
    headerDiv.addEventListener('click', () => {
      const isCollapsed = messageDiv.classList.toggle('collapsed');
      const icon = headerDiv.querySelector(
        '.tool-collapse-icon'
      ) as HTMLElement;
      if (icon) {
        icon.textContent = isCollapsed ? '▶' : '▼';
      }
    });

    // Store data for auto-suggestions
    (messageDiv as any)._toolName = name;
    (messageDiv as any)._toolArgs = args;

    this.messagesArea.appendChild(messageDiv);
    this.scrollToBottom();

    return messageDiv;
  }

  /** Format tool arguments for display */
  private formatArgs(toolName: string, args: Record<string, unknown>): string {
    switch (toolName) {
      case 'create_cell':
        return `Create ${args.cell_type} cell:\n${((args.source as string) || '').substring(0, 200)}${((args.source as string) || '').length > 200 ? '...' : ''}`;
      case 'execute_cell':
        return `Execute cell [${args.index}]`;
      case 'get_cell_output':
        return `Get cell output [${args.index}]`;
      case 'update_cell':
        return `Update cell [${args.index}]`;
      case 'delete_cell':
        return `Delete cell [${args.index}]`;
      case 'get_notebook_content':
        return 'Read notebook content';
      case 'get_cell_content':
        return `Read cell [${args.index}]`;
      case 'find_in_notebook':
        return `Search in notebook: "${args.query}"${args.regex ? ' (regex)' : ''}${args.case_sensitive ? ' (case-sensitive)' : ''}`;
      case 'replace_in_cell':
        return `Replace in cell [${args.index}]: "${args.search}" -> "${args.replace}"${args.replace_all ? ' (all)' : ' (first)'}`;
      case 'read_file':
        return `Read file: ${args.path}${args.max_lines ? ` (first ${args.max_lines} lines)` : ''}`;
      case 'write_file':
        return `Write file: ${args.path} (${((args.content as string) || '').length} chars)`;
      case 'list_directory':
        return `List files: ${args.path || '.'}`;
      case 'create_notebook':
        return `Create notebook: ${args.path || ''}${args.name}`;
      case 'delete_file':
        return `Delete: ${args.path}`;
      case 'rename_file':
        return `Rename: ${args.old_path} -> ${args.new_path}`;
      case 'run_shell':
        return `Run command: ${args.command}`;
      case 'install_package':
        return `Install package: ${args.package_name} (${args.manager || 'pip'})${args.extra_args ? ` ${args.extra_args}` : ''}`;
      case 'list_packages':
        return `List packages${args.filter ? `: filter "${args.filter}"` : ''}`;
      case 'remember':
        return `Remember [${args.category || 'general'}]: ${args.key} = "${((args.value as string) || '').substring(0, 100)}"`;

      case 'analyze_image':
        return `Analyze image in cell [${args.cell_index}]${args.context ? `: "${args.context}"` : ''}`;
      default:
        return JSON.stringify(args, null, 2);
    }
  }

  /** Update tool bubble status (supports images) */
  private updateToolBubble(
    el: HTMLElement,
    status: 'completed' | 'error',
    result: string
  ): void {
    const icon = status === 'completed' ? '✅' : '❌';
    const statusEl = el.querySelector('.tool-status');
    if (statusEl) {
      statusEl.textContent = icon;
    }

    const bodyDiv = el.querySelector(
      '.ai-agent-tool-call-body'
    ) as HTMLElement | null;
    if (!bodyDiv) {
      return;
    }

    const resultDiv = document.createElement('div');
    resultDiv.className = `ai-agent-tool-call-result ${status}`;

    // Check for images in result
    try {
      const parsed = JSON.parse(result);
      if (parsed.outputs && Array.isArray(parsed.outputs)) {
        // Render each output
        for (const output of parsed.outputs) {
          if (output.type === 'image' && output.base64) {
            const img = document.createElement('img');
            img.className = 'ai-agent-output-image';
            img.src = `data:${output.mime_type || 'image/png'};base64,${output.base64}`;
            img.alt = output.alt_text || 'Cell output';
            img.style.maxWidth = '100%';
            img.style.maxHeight = '400px';
            img.style.borderRadius = '4px';
            img.style.marginTop = '8px';
            resultDiv.appendChild(img);
          } else if (output.content) {
            const textNode = document.createElement('pre');
            textNode.className = 'ai-agent-output-text';
            textNode.textContent =
              typeof output.content === 'string'
                ? output.content
                : JSON.stringify(output.content, null, 2);
            resultDiv.appendChild(textNode);
          }
        }
      } else {
        // Plain text result
        resultDiv.textContent = result;
      }
    } catch {
      // Not JSON - show as plain text
      resultDiv.textContent = result;
    }

    // Truncate long results
    if (result.length > 500) {
      resultDiv.textContent = result.substring(0, 500) + '...';

      const showMore = document.createElement('button');
      showMore.className = 'ai-agent-show-more';
      showMore.textContent = 'Show full result';
      showMore.addEventListener('click', () => {
        resultDiv.textContent = result;
        showMore.remove();
      });

      bodyDiv.appendChild(resultDiv);
      bodyDiv.appendChild(showMore);
    } else {
      bodyDiv.appendChild(resultDiv);
    }

    // Auto-suggest image analysis
    const toolName = (el as any)._toolName;
    const toolArgs = (el as any)._toolArgs;
    if (toolName === 'get_cell_output' && status === 'completed') {
      try {
        const parsed = JSON.parse(result);
        if (
          parsed.has_images ||
          (parsed.outputs &&
            parsed.outputs.some((o: any) => o.type === 'image'))
        ) {
          this.addImageAnalysisSuggestion(
            bodyDiv,
            toolArgs?.index as number | undefined
          );
        }
      } catch {
        // Ignore parse errors
      }
    }

    // Auto-collapse on success
    if (status === 'completed') {
      el.classList.add('collapsed');
      const collapseIcon = el.querySelector(
        '.tool-collapse-icon'
      ) as HTMLElement;
      if (collapseIcon) {
        collapseIcon.textContent = '▶';
      }
    }

    this.scrollToBottom();
  }

  /** Add image analysis suggestion */
  private async addImageAnalysisSuggestion(
    container: HTMLElement,
    cellIndex?: number
  ): Promise<void> {
    try {
      const settings = await getSettings();
      if (settings.image_analysis?.auto_suggest === false) {
        return;
      }
    } catch {
      // Show button if settings fail to load
    }

    const suggestionDiv = document.createElement('div');
    suggestionDiv.className = 'ai-agent-image-suggestion';
    suggestionDiv.innerHTML = `
      <span class="ai-agent-suggestion-text">Image detected in output</span>
      <button class="ai-agent-suggestion-btn">Analyze with AI</button>
    `;

    const btn = suggestionDiv.querySelector(
      '.ai-agent-suggestion-btn'
    ) as HTMLButtonElement;
    btn.addEventListener('click', async () => {
      const cellIdx = cellIndex || 1;
      const text = `Analyze the image in cell ${cellIdx}`;

      this.addBubble('user', text);
      this.setLoading(true);

      this.abortController = new AbortController();

      this.conversationHistory.push({
        role: 'user',
        content: text
      });

      this.updateTokenCounter();
      this.lastUserMessage = text;

      try {
        await this.agentLoop();
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        if (msg !== 'Request cancelled' && !msg.includes('abort')) {
          this.addBubble('assistant', `Error: ${msg}`);
        }
      } finally {
        this.setLoading(false);
      }

      suggestionDiv.remove();
    });

    container.appendChild(suggestionDiv);
  }

  /** Add thinking indicator */
  private addThinkingIndicator(): HTMLElement {
    const div = document.createElement('div');
    div.className = 'ai-agent-thinking';
    div.innerHTML = '<em>Agent is thinking...</em>';
    this.messagesArea.appendChild(div);
    this.scrollToBottom();
    return div;
  }

  // ═══════════════════════════════════════════════════════
  // File autocompletion (@mention)
  // ═══════════════════════════════════════════════════════

  /** Set loading state */
  private setLoading(loading: boolean): void {
    this.isLoading = loading;
    this.sendButton.disabled = loading;
    this.inputField.disabled = loading;

    // Toggle button visibility
    if (loading) {
      this.sendButton.classList.add('ai-agent-hidden');
      this.stopButton.classList.remove('ai-agent-hidden');
    } else {
      this.sendButton.classList.remove('ai-agent-hidden');
      this.stopButton.classList.add('ai-agent-hidden');
    }
  }

  /** Handle stop button click */
  private handleStop(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
    this.addBubble('assistant', 'Request cancelled by user.');
    this.setLoading(false);
  }

  /** Update token counter display */
  private updateTokenCounter(): void {
    const tokens = estimateMessagesTokens(this.conversationHistory);
    this.tokenCounter.textContent = `~${formatTokenCount(tokens)} tokens`;
    this.tokenCounter.title = `Approximately ${tokens} tokens in context`;
  }

  // ─────────────────────────────────────────────
  // Auto context
  // ─────────────────────────────────────────────

  /** Decide whether to refresh context */
  private shouldRefreshContext(): boolean {
    if (!this.contextConfig.smartMode) {
      return true;
    }

    const ctx = this.contextCollector.collect();
    const currentNotebook = ctx.notebookPath;
    const now = Date.now();

    // Refresh if:
    // 1. Notebook changed
    if (currentNotebook !== this.lastContextNotebook) {
      this.lastContextNotebook = currentNotebook;
      this.lastContextTimestamp = now;
      return true;
    }

    // 2. More than 30 seconds passed
    if (now - this.lastContextTimestamp > 30000) {
      this.lastContextTimestamp = now;
      return true;
    }

    // 3. First request in session
    if (this.conversationHistory.length <= 1) {
      return true;
    }

    return false;
  }

  /** Build dynamic context message */
  private async buildContextMessage(): Promise<string> {
    const parts: string[] = [];

    // 1. Environment context (always included)
    parts.push(
      this.contextCollector.formatAsSystemMessage(
        this.contextConfig.includeCellOutline
      )
    );

    // 2. Variables (if enabled)
    if (this.contextConfig.includeVariables) {
      try {
        const varsInfo = await this.variableInspector.formatForPrompt();
        parts.push('');
        parts.push(varsInfo);
      } catch {
        // Skip if variables unavailable
      }
    }

    return parts.join('\n');
  }

  /** Prepare messages for LLM (includes context and truncation) */
  private async prepareMessages(): Promise<ILLMMessage[]> {
    const messages = [...this.conversationHistory];

    // 1. Add auto context
    if (this.shouldRefreshContext()) {
      const contextText = await this.buildContextMessage();

      const contextMessage: ILLMMessage = {
        role: 'user',
        content: `[SYSTEM CONTEXT]\n${contextText}`
      };

      // Insert before last user message
      let insertIndex = messages.length;
      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].role === 'user') {
          insertIndex = i;
          break;
        }
      }

      messages.splice(insertIndex, 0, contextMessage);
    }

    // 2. Update token counter
    this.updateTokenCounter();

    return messages;
  }

  // ─────────────────────────────────────────────
  // Confirmation (when auto-mode is off)
  // ─────────────────────────────────────────────

  /** Request tool execution confirmation */
  private async confirmTool(
    name: string,
    args: Record<string, unknown>
  ): Promise<boolean> {
    const tool = toolRegistry.get(name);
    if (!tool) {
      return false;
    }

    // Check via PermissionManager
    const needsConfirm = toolRegistry.permissions.requiresConfirmation(
      tool,
      this.autoExecuteTools
    );

    if (!needsConfirm) {
      return true;
    }

    // Show confirmation dialog
    const confirmClass = PermissionManager.getConfirmationClass(
      tool.safetyLevel
    );

    return new Promise(resolve => {
      const confirmDiv = document.createElement('div');
      confirmDiv.className = `ai-agent-tool-confirm ${confirmClass}`;
      confirmDiv.innerHTML = `
        <div class="ai-agent-tool-confirm-text">
          Execute <strong>${name}</strong>?
        </div>
        <div class="ai-agent-tool-confirm-details">
          ${this.formatToolArgs(name, args)}
        </div>
        <div class="ai-agent-tool-confirm-buttons">
          <button class="jp-mod-accept">Yes</button>
          <button class="jp-mod-reject">No</button>
        </div>
      `;

      this.messagesArea.appendChild(confirmDiv);
      this.scrollToBottom();

      const acceptBtn = confirmDiv.querySelector(
        '.jp-mod-accept'
      ) as HTMLButtonElement;
      const rejectBtn = confirmDiv.querySelector(
        '.jp-mod-reject'
      ) as HTMLButtonElement;

      const cleanup = () => {
        confirmDiv.remove();
      };

      acceptBtn.onclick = () => {
        cleanup();
        resolve(true);
      };

      rejectBtn.onclick = () => {
        cleanup();
        resolve(false);
      };
    });
  }

  /** Format tool args for display */
  private formatToolArgs(name: string, args: Record<string, unknown>): string {
    const entries = Object.entries(args);
    if (entries.length === 0) {
      return '';
    }

    const argsHtml = entries
      .map(([key, value]) => {
        const str = typeof value === 'string' ? value : JSON.stringify(value);
        const truncated =
          str.length > 100 ? str.substring(0, 100) + '...' : str;
        return `<div><strong>${key}:</strong> ${this.escapeHtml(truncated)}</div>`;
      })
      .join('');

    return `<div class="ai-agent-tool-args">${argsHtml}</div>`;
  }

  /** Escape HTML special characters */
  private escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // ─────────────────────────────────────────────
  // Main agent loop
  // ─────────────────────────────────────────────

  /** Handle user message */
  private async handleUserMessage(
    retryLastMessage: boolean = false
  ): Promise<void> {
    // Use last message for retry, otherwise read from input
    let text: string;
    if (retryLastMessage && this.lastUserMessage) {
      text = this.lastUserMessage;
    } else {
      text = this.inputField.value.trim();
      if (!text || this.isLoading) {
        return;
      }
      this.inputField.value = '';
      this.lastUserMessage = text;
    }

    this.addBubble('user', text);
    this.setLoading(true);

    // Create AbortController for this request
    this.abortController = new AbortController();

    this.conversationHistory.push({
      role: 'user',
      content: text
    });

    // Update token counter
    this.updateTokenCounter();

    try {
      await this.agentLoop();
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);

      if (msg === 'Request cancelled' || msg.includes('abort')) {
        // Cancelled - don't show as error
      } else {
        this.addErrorBubbleWithRetry(`Error: ${msg}`);
      }
    } finally {
      this.abortController = null;
      this.setLoading(false);
    }
  }

  /**
   * Agent loop:
   * 1. Send history to LLM (streaming)
   * 2. If tool_calls: execute, add results, goto 1
   * 3. If text: display, done
   */
  private async agentLoop(): Promise<void> {
    for (let iteration = 0; iteration < this.maxAgentIterations; iteration++) {
      const needMore = await this.agentStep();
      if (!needMore) {
        return;
      }
    }
    this.addBubble('assistant', 'Agent iteration limit reached.');
  }

  /** Single agent step with streaming (returns: true=continue, false=done) */
  private async agentStep(): Promise<boolean> {
    const thinkingEl = this.addThinkingIndicator();

    // Создаём пустой bubble для ответа ассистента
    let assistantBubble: HTMLElement | null = null;
    let assistantTextEl: HTMLElement | null = null;
    let accumulatedText = '';

    // Prepare messages with context
    const messages = await this.prepareMessages();

    // Get image_analysis settings
    const settings = await getSettings();
    const imageAnalysisEnabled = settings.image_analysis?.enabled ?? true;

    return new Promise<boolean>((resolve, reject) => {
      streamFromLLM(
        messages,
        {
          onToken: (token: string) => {
            // Remove thinking indicator on first token
            if (thinkingEl.parentNode) {
              thinkingEl.remove();
            }

            // Create bubble on first token
            if (!assistantBubble) {
              assistantBubble = document.createElement('div');
              assistantBubble.className = 'ai-agent-message assistant';

              const roleLabel = document.createElement('span');
              roleLabel.className = 'ai-agent-message-role';
              roleLabel.textContent = 'AI:';

              assistantTextEl = document.createElement('div');
              assistantTextEl.className = 'ai-agent-message-text';
              assistantTextEl.innerHTML = '';

              assistantBubble.appendChild(roleLabel);
              assistantBubble.appendChild(assistantTextEl);
              this.messagesArea.appendChild(assistantBubble);
            }

            // Append token
            if (assistantTextEl) {
              accumulatedText += token;
              assistantTextEl.innerHTML = parseMarkdown(accumulatedText);
            }
            this.scrollToBottom();
          },

          onToolCalls: _toolCalls => {
            // Tool calls handled in onDone
          },

          onDone: async fullMessage => {
            thinkingEl.remove();

            // No tool_calls - final response
            if (
              !fullMessage.tool_calls ||
              fullMessage.tool_calls.length === 0
            ) {
              this.conversationHistory.push({
                role: 'assistant',
                content: fullMessage.content || ''
              });

              // Initialize code block buttons
              if (assistantTextEl) {
                this.addCodeBlockButtons(assistantTextEl, accumulatedText);
              }

              // Update token counter
              this.updateTokenCounter();

              resolve(false);
              return;
            }

            // Has tool_calls - add to history and execute
            this.conversationHistory.push({
              role: 'assistant',
              content: fullMessage.content || null,
              tool_calls: fullMessage.tool_calls
            } as ILLMMessage);

            // Update token counter
            this.updateTokenCounter();

            // Execute each tool
            for (const toolCall of fullMessage.tool_calls) {
              const funcName = toolCall.function.name;
              let funcArgs: Record<string, unknown> = {};

              try {
                funcArgs = JSON.parse(toolCall.function.arguments);
              } catch {
                funcArgs = {};
              }

              // Show in UI
              const toolBubble = this.addToolBubble(
                funcName,
                funcArgs,
                'pending'
              );

              // Request confirmation (if auto-mode is off)
              const confirmed = await this.confirmTool(funcName, funcArgs);

              if (!confirmed) {
                // User cancelled
                this.updateToolBubble(toolBubble, 'error', 'Cancelled by user');
                this.conversationHistory.push({
                  role: 'tool',
                  tool_call_id: toolCall.id,
                  content: JSON.stringify({
                    success: false,
                    error: 'Cancelled by user'
                  })
                });
                // Update token counter
                this.updateTokenCounter();
                continue;
              }

              // Execute tool
              try {
                const result = await toolRegistry.execute(funcName, funcArgs);

                if (result.success) {
                  this.updateToolBubble(
                    toolBubble,
                    'completed',
                    JSON.stringify(result.result, null, 2)
                  );
                } else {
                  this.updateToolBubble(
                    toolBubble,
                    'error',
                    result.error || 'Unknown error'
                  );
                }

                // Invalidate variable cache after execute_cell
                if (funcName === 'execute_cell') {
                  this.variableInspector.invalidateCache();
                }

                // Add result to history for next LLM iteration
                this.conversationHistory.push({
                  role: 'tool',
                  tool_call_id: toolCall.id,
                  content: JSON.stringify(result)
                });

                // Обновляем счётчик токенов
                this.updateTokenCounter();
              } catch (error) {
                const errMsg =
                  error instanceof Error ? error.message : String(error);
                this.updateToolBubble(toolBubble, 'error', errMsg);
                this.conversationHistory.push({
                  role: 'tool',
                  tool_call_id: toolCall.id,
                  content: JSON.stringify({ success: false, error: errMsg })
                });

                // Update token counter
                this.updateTokenCounter();
              }
            }

            resolve(true); // need next iteration
          },

          onError: error => {
            thinkingEl.remove();
            reject(new Error(error));
          }
        },
        this.abortController?.signal,
        this.askMode,
        imageAnalysisEnabled
      );
    });
  }

  /** Sync theme with JupyterLab */
  private syncTheme(): void {
    // CSS variables from JupyterLab apply automatically
  }

  /** Handle theme change */
  private onThemeChanged(): void {
    this.syncTheme();
  }

  // ─────────────────────────────────────────────
  // Chat history management
  // ─────────────────────────────────────────────

  /** Toggle history panel */
  private async toggleHistoryPanel(): Promise<void> {
    const isVisible = !this.historyPanel.classList.contains('ai-agent-hidden');

    // Hide all panels
    this.historyPanel.classList.add('ai-agent-hidden');
    this.settingsPanel.classList.add('ai-agent-hidden');

    if (isVisible) {
      // Was hidden - restore chat
      this.messagesArea.classList.remove('ai-agent-hidden');
      this.inputField.disabled = false;
      this.sendButton.disabled = false;
      return;
    }

    // Show history
    this.messagesArea.classList.add('ai-agent-hidden');
    this.inputField.disabled = true;
    this.sendButton.disabled = true;
    this.historyPanel.classList.remove('ai-agent-hidden');

    await this.renderHistoryPanel();
  }

  /** Render saved chats list */
  private async renderHistoryPanel(): Promise<void> {
    if (this.isHistoryLoading) {
      return;
    }

    this.isHistoryLoading = true;
    this.historyPanel.innerHTML =
      '<div class="ai-agent-history-loading">Loading...</div>';

    try {
      const chats = await listChats();

      const header = document.createElement('div');
      header.className = 'ai-agent-settings-header';
      header.innerHTML = `
        <h3>Chat History</h3>
        <button class="ai-agent-settings-close" title="Close">⨯</button>
      `;
      header
        .querySelector('.ai-agent-settings-close')
        ?.addEventListener('click', () => {
          this.toggleHistoryPanel();
        });

      const actions = document.createElement('div');
      actions.className = 'ai-agent-history-actions';

      const newChatBtn = document.createElement('button');
      newChatBtn.className = 'ai-agent-history-action-btn';
      newChatBtn.innerHTML = 'New Chat';
      newChatBtn.addEventListener('click', () => this.startNewChat());

      const saveBtn = document.createElement('button');
      saveBtn.className = 'ai-agent-history-action-btn';
      saveBtn.innerHTML = 'Save';
      saveBtn.addEventListener('click', () => this.saveCurrentChat());

      const exportMdBtn = document.createElement('button');
      exportMdBtn.className = 'ai-agent-history-action-btn';
      exportMdBtn.innerHTML = 'Export MD';
      exportMdBtn.addEventListener('click', async () => {
        if (this.currentChatId) {
          try {
            await exportChat(this.currentChatId);
          } catch (error) {
            const errorMsg =
              error instanceof Error ? error.message : String(error);
            this.showNotification(`Export error: ${errorMsg}`, 'error');
          }
        } else {
          this.showNotification('Please save the chat first', 'error');
        }
      });

      const exportJsonBtn = document.createElement('button');
      exportJsonBtn.className = 'ai-agent-history-action-btn';
      exportJsonBtn.innerHTML = 'Export JSON';
      exportJsonBtn.addEventListener('click', () => {
        exportChatAsJson(
          this.conversationHistory,
          this.currentChatId || undefined
        );
      });

      actions.appendChild(newChatBtn);
      actions.appendChild(saveBtn);
      actions.appendChild(exportMdBtn);
      actions.appendChild(exportJsonBtn);

      const list = document.createElement('div');
      list.className = 'ai-agent-history-list';

      if (chats.length === 0) {
        list.innerHTML =
          '<div class="ai-agent-history-empty">No saved chats</div>';
      } else {
        for (const chat of chats) {
          const item = document.createElement('div');
          item.className = 'ai-agent-history-item';
          if (chat.id === this.currentChatId) {
            item.classList.add('active');
          }

          const date = new Date(chat.updated_at).toLocaleDateString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
          });

          item.innerHTML = `
            <div class="ai-agent-history-item-main">
              <span class="ai-agent-history-item-title">${this.escapeHtml(chat.title)}</span>
              <span class="ai-agent-history-item-date">${date}</span>
            </div>
            <div class="ai-agent-history-item-actions">
              <button class="ai-agent-history-item-btn" title="Load">Open</button>
              <button class="ai-agent-history-item-btn ai-agent-history-delete" title="Delete">Delete</button>
            </div>
          `;

          // Load
          item
            .querySelector(
              '.ai-agent-history-item-btn:not(.ai-agent-history-delete)'
            )
            ?.addEventListener('click', () => this.loadChatById(chat.id));

          // Delete
          item
            .querySelector('.ai-agent-history-delete')
            ?.addEventListener('click', async e => {
              e.stopPropagation();
              if (confirm(`Delete chat "${chat.title}"?`)) {
                await this.deleteChatById(chat.id);
                await this.renderHistoryPanel();
              }
            });

          list.appendChild(item);
        }
      }

      this.historyPanel.innerHTML = '';
      this.historyPanel.appendChild(header);
      this.historyPanel.appendChild(actions);
      this.historyPanel.appendChild(list);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.historyPanel.innerHTML = `<div class="ai-agent-history-error">Error: ${this.escapeHtml(errorMsg)}</div>`;
    } finally {
      this.isHistoryLoading = false;
    }
  }

  /** Start new chat */
  private startNewChat(): void {
    if (this.conversationHistory.length > 0) {
      if (!confirm('Start new chat? Current chat will be cleared.')) {
        return;
      }
    }

    this.currentChatId = null;
    this.conversationHistory = [];
    this.messagesArea.innerHTML = '';
    this.updateTokenCounter();

    this.addBubble(
      'assistant',
      'Hello! I am AI Agent. I can write and execute code in your notebook. Try: "Write a fibonacci function and execute it"'
    );
    this.toggleHistoryPanel();
  }

  /** Save current chat */
  private async saveCurrentChat(): Promise<void> {
    if (this.conversationHistory.length === 0) {
      this.showNotification('Chat is empty', 'error');
      return;
    }

    try {
      const result = await saveChat(
        this.conversationHistory,
        this.currentChatId || undefined
      );
      this.currentChatId = result.id;
      this.showNotification(`Chat saved: "${result.title}"`, 'success');
      this.toggleHistoryPanel();
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.showNotification(`Save error: ${errorMsg}`, 'error');
    }
  }

  /** Load chat by ID */
  private async loadChatById(chatId: string): Promise<void> {
    if (this.conversationHistory.length > 0) {
      if (!confirm('Load chat? Current chat will be replaced.')) {
        return;
      }
    }

    try {
      const chatData = await loadChat(chatId);
      this.currentChatId = chatData.id;
      this.conversationHistory = chatData.messages;

      // Display messages
      this.messagesArea.innerHTML = '';
      for (const msg of chatData.messages) {
        if (msg.role === 'user' && msg.content) {
          this.addBubble('user', msg.content);
        } else if (msg.role === 'assistant' && msg.content) {
          this.addBubble('assistant', msg.content);
        } else if (msg.role === 'tool') {
          // Tool messages are in history, not displayed
        }
      }

      this.updateTokenCounter();
      this.showNotification(`Chat "${chatData.title}" loaded`, 'success');
      this.toggleHistoryPanel();
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.showNotification(`Load error: ${errorMsg}`, 'error');
    }
  }

  /** Delete chat by ID */
  private async deleteChatById(chatId: string): Promise<void> {
    try {
      await deleteChat(chatId);
      if (chatId === this.currentChatId) {
        this.currentChatId = null;
      }
      this.showNotification('Chat deleted', 'success');
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.showNotification(`Delete error: ${errorMsg}`, 'error');
    }
  }

  /** Show notification */
  private showNotification(
    message: string,
    type: 'success' | 'error' | 'info'
  ): void {
    const notification = document.createElement('div');
    notification.className = `ai-agent-notification ai-agent-notification-${type}`;
    notification.textContent = message;

    const container = this.content.node;
    container.appendChild(notification);

    setTimeout(() => {
      notification.classList.add('ai-agent-notification-hide');
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  /** Toggle settings panel */
  private async toggleSettingsPanel(): Promise<void> {
    const isVisible = !this.settingsPanel.classList.contains('ai-agent-hidden');

    // Hide all panels
    this.historyPanel.classList.add('ai-agent-hidden');
    this.settingsPanel.classList.add('ai-agent-hidden');

    if (isVisible) {
      // Was hidden - restore chat
      this.messagesArea.classList.remove('ai-agent-hidden');
      this.inputField.disabled = false;
      this.sendButton.disabled = false;
      return;
    }

    // Show settings
    this.messagesArea.classList.add('ai-agent-hidden');
    this.inputField.disabled = true;
    this.sendButton.disabled = true;
    this.settingsPanel.classList.remove('ai-agent-hidden');

    await this.renderSettingsPanel();
  }

  /** Load settings from server and apply */
  private async loadSettingsFromServer(): Promise<void> {
    try {
      const settings = await getSettings();

      // Apply settings
      this.maxAgentIterations = settings.max_agent_iterations;
      this.autoExecuteTools = settings.auto_execute_tools;

      // Save context settings
      this.contextConfig = {
        includeCellOutline: settings.include_cell_outline,
        includeVariables: settings.include_variables,
        maxCellsInOutline: 20,
        maxVariables: 30,
        smartMode: true
      };

      // Update permission manager for tool categories
      if (settings.enabled_tool_categories) {
        for (const [category, enabled] of Object.entries(
          settings.enabled_tool_categories
        )) {
          if (enabled) {
            toolRegistry.enableCategory(category);
          } else {
            toolRegistry.disableCategory(category);
          }
        }
      }
    } catch (e) {
      console.error('Failed to load settings:', e);
    }
  }

  /** Render settings panel */
  private async renderSettingsPanel(): Promise<void> {
    await renderSettingsPanelContent(
      this.settingsPanel,
      // onClose - just close panel
      () => {
        this.toggleSettingsPanel();
      },
      // onSettingsChanged - save and close
      () => {
        this.loadSettingsFromServer();
        this.showNotification('Settings saved', 'success');
        this.toggleSettingsPanel();
      }
    );
  }
}
