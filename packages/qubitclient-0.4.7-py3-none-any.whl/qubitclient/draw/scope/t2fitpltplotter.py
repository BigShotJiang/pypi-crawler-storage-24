from ..pltplotter import QuantumDataPltPlotter
import numpy as np


class T2FitDataPltPlotter(QuantumDataPltPlotter):
    def __init__(self):
        super().__init__("t2fit")

    def plot_result_npy(self, **kwargs):
        result = kwargs.get('result')
        dict_param = kwargs.get('dict_param')

        data = dict_param.item() if isinstance(dict_param, np.ndarray) else dict_param
        image_dict = data.get("image", {})
        qubit_names = list(image_dict.keys())

        n_qubits = len(qubit_names)
        fig, axes, rows, cols = self.create_subplots(n_qubits)
        axs = axes.flatten()

        params_list   = result.get("params_list",   [])
        r2_list       = result.get("r2_list",       [])
        fit_data_list = result.get("fit_data_list", [])

        for q_idx, q_name in enumerate(qubit_names):
            ax = axs[q_idx]
            item = image_dict.get(q_name)

            if not isinstance(item, (list, tuple)) or len(item) < 2:
                ax.axis('off')
                continue

            x_raw = np.asarray(item[0])
            y_raw = np.asarray(item[1])

            # 原始数据 - 散点
            scatter = self.add_scatter(
                ax,
                x_raw,
                y_raw,
                label="Data",           # 每个子图都给 label
                marker_index=1,         # 'o'
                color_index=6,          # 橙色
                alpha=0.7
            )

            # 拟合曲线
            if q_idx < len(fit_data_list) and fit_data_list[q_idx] is not None:
                fit_y = np.asarray(fit_data_list[q_idx])

                # 若长度不匹配则重新生成 x
                if len(fit_y) != len(x_raw):
                    x_plot = np.linspace(x_raw.min(), x_raw.max(), len(fit_y))
                else:
                    x_plot = x_raw

                self.add_line(
                    ax,
                    x_plot,
                    fit_y,
                    label="Fit",            # 每个子图都给 label
                    color_index=0,          # 蓝色
                    line_style_index=0
                )

            # 图例：每个子图都尝试添加
            handles, labels = ax.get_legend_handles_labels()
            if handles:  
                self.add_legend(
                    ax=ax,
                    handles=handles,
                    labels=labels,
                )

            # 参数文本
            if q_idx < len(params_list) and params_list[q_idx]:
                A, B, T1, T2, w, phi = params_list[q_idx]
                r2 = r2_list[q_idx] if q_idx < len(r2_list) else 0.0

                text_str = (
                    f"A   = {A:.3f}\n"
                    f"B   = {B:.3f}\n"
                    f"T₁  = {T1:.1f} µs\n"
                    f"T₂  = {T2:.1f} µs\n"
                    f"ω   = {w/1e6:.2f} MHz\n"
                    f"φ   = {phi:.3f}\n"
                    f"R²  = {r2:.3f}"
                )

                self.add_annotation(
                    ax,
                    text_str,
                    xy=(0, 1),
                    annotation_textcoords="axes fraction",
                    annotation_xytext=(0, 1),   
                    color_index=0,
                    showarrow=False,
                    ha='left',
                    va='top'
                )

            # 坐标轴标题
            self.configure_axis(
                ax,
                title=q_name,
                xlabel="Time",
                ylabel="Amp"
            )

        fig.tight_layout()
        return fig