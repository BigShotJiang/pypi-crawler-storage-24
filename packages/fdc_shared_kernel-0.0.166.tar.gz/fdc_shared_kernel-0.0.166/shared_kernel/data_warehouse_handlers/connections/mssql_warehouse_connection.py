import time
import threading

from contextlib import contextmanager
from typing import Dict
from urllib.parse import quote

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import InterfaceError, OperationalError, ProgrammingError

from shared_kernel.dataclasses.warehouse_configs import MSSQLConfig
from shared_kernel.exceptions.http_exceptions import BadRequest
from shared_kernel.interfaces.warehouse_connection import DataWarehouseConnection
from shared_kernel.constants.constants import get_constant
from shared_kernel.data_warehouse_handlers.utils import extract_sql_server_error_message
from shared_kernel.logger import Logger
from shared_kernel.config import Config

config = Config()
logger = Logger(config.get("APP_NAME"))


class MSSQLWarehouseConnection(DataWarehouseConnection):

    _engines: Dict[str, Engine] = {}
    _lock = threading.Lock()

    def __init__(
        self,
        source_config: MSSQLConfig,
        set_default_schema: bool = True,
    ):
        if source_config is None:
            raise ValueError("Missing required parameter: source_config (MSSQLConfig)")

        self._mssql_config = source_config
        self.org_schema = source_config.schema if source_config.schema else None
        self.set_default_schema = set_default_schema

        pagination = getattr(source_config, "pagination", None) or {}
        self.page = pagination.get("page") if isinstance(pagination, dict) else None
        self.limit = pagination.get("limit") if isinstance(pagination, dict) else None
        self.search = pagination.get("search") if isinstance(pagination, dict) else None

    def _engine_key(self, cfg: MSSQLConfig) -> str:
        return f"{cfg.host}|{cfg.port}|{cfg.database}|{cfg.username}"

    def _get_engine(self) -> Engine:
        cfg = self._mssql_config
        key = self._engine_key(cfg)

        if key not in self._engines:
            with self.__class__._lock: # thread-safe
                if key not in self._engines: # recheck
                    password = quote(cfg.password)
                    connection_string = get_constant("mssql", "CONNECTION_STRING").format(
                        cfg.username, password, cfg.host, int(cfg.port), cfg.database
                    )

                    self._engines[key] = create_engine(
                        connection_string,
                        pool_size=10,
                        max_overflow=5,
                        pool_timeout=30,
                        pool_recycle=1800,
                        pool_pre_ping=True,
                    )
                    logger.info(
                        f"Created new MSSQL engine for {cfg.host}:{cfg.port}/{cfg.database}"
                    )

        return self._engines[key]

    @contextmanager
    def get_connection(self, retries: int = 3, delay: int = 5):
        """Context manager for database connections with retry mechanism"""
        engine = self._get_engine()
        last_exception = None

        for attempt in range(retries):
            conn = None
            try:
                conn = engine.connect()
                yield conn
                return

            except (OperationalError, InterfaceError, ProgrammingError) as e:
                last_exception = e
                if conn is not None:
                    conn.close()
                    conn = None

                error_message = extract_sql_server_error_message(str(e))
                logger.warning(
                    f"MSSQL connection failed (attempt {attempt + 1}/{retries}): {error_message}"
                )

                if attempt < retries - 1:
                    time.sleep(delay)
                    delay += 5
                    continue

                break

            finally:
                if conn is not None:
                    conn.close()

        raise BadRequest(
            f"Failed to connect to MSSQL after {retries} attempts"
        ) from last_exception

    def close_connection(self):
        """Dispose all pooled engines managed by this class."""
        for engine in self._engines.values():
            engine.dispose()
        self._engines.clear()
        logger.info("All MSSQL engine pools disposed.")

    def is_valid_connection(self) -> bool:
        """Pool health is managed by pool_pre_ping; no manual check needed."""
        return True

    def test_connection(self) -> bool:
        """Verify the connection is reachable. Raises on failure."""
        try:
            with self.get_connection() as conn:
                conn.execute(text("SELECT 1"))
            return True
        except OperationalError as e:
            if "authentication failed" in str(e).lower():
                raise ValueError("Invalid username or password")
            raise ConnectionError(f"Database error: {str(e)}")
        except InterfaceError:
            raise ConnectionError("Cannot connect to database server")
