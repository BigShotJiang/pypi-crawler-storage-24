"""Click wrappers: tests + diagnose groups — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import diagnostics as diag_cli
from proxym.cli._groups._shared import make_args as _make_args


# ── Tests group ──────────────────────────────────────────────

@click.group(name="tests")
def tests():
    """Run system diagnostics."""
    pass


@tests.command(name="status")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def tests_status(ctx: click.Context, fmt: str):
    """Run all diagnostic tests."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_tests_status(args)


@tests.command(name="vscode")
@click.pass_context
def tests_vscode(ctx: click.Context):
    """Test VS Code Web connectivity."""
    args = _make_args(ctx)
    diag_cli.cmd_test_vscode(args)


@tests.command(name="proxy")
@click.pass_context
def tests_proxy(ctx: click.Context):
    """Test LLM proxy connectivity."""
    args = _make_args(ctx)
    diag_cli.cmd_test_proxy(args)


@tests.command(name="providers")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def tests_providers(ctx: click.Context, fmt: str):
    """Check configured LLM providers."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_test_providers(args)


@tests.command(name="extensions")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def tests_extensions(ctx: click.Context, fmt: str):
    """Check installed VS Code extensions."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_test_extensions(args)


@tests.command(name="agent-setup")
@click.pass_context
def tests_agent_setup(ctx: click.Context):
    """Comprehensive agent readiness check."""
    args = _make_args(ctx)
    diag_cli.cmd_test_agent_setup(args)


@tests.command(name="agent")
@click.pass_context
def tests_agent(ctx: click.Context):
    """Test agent with a simple completion."""
    args = _make_args(ctx)
    diag_cli.cmd_test_agent(args)


# ── Diagnose alias group ─────────────────────────────────────

@click.group(name="diagnose")
def diagnose():
    """Run diagnostics to verify system health (alias for 'tests')."""
    pass


@diagnose.command(name="all")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def diagnose_all(ctx: click.Context, fmt: str):
    """Run all diagnostic tests."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_tests_status(args)


@diagnose.command(name="proxy")
@click.pass_context
def diagnose_proxy(ctx: click.Context):
    """Test proxy connectivity."""
    args = _make_args(ctx)
    diag_cli.cmd_test_proxy(args)


@diagnose.command(name="vscode")
@click.pass_context
def diagnose_vscode(ctx: click.Context):
    """Test VS Code Web status."""
    args = _make_args(ctx)
    diag_cli.cmd_test_vscode(args)


@diagnose.command(name="providers")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def diagnose_providers(ctx: click.Context, fmt: str):
    """Test provider configuration."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_test_providers(args)


@diagnose.command(name="agent")
@click.pass_context
def diagnose_agent(ctx: click.Context):
    """Test agent setup + completion."""
    args = _make_args(ctx)
    diag_cli.cmd_test_agent(args)


@diagnose.command(name="test")
@click.argument("test_name")
@click.pass_context
def diagnose_one(ctx: click.Context, test_name: str):
    """Run a specific test (vscode|proxy|roo|extensions|providers|copilot|agent-setup|agent)."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get(f"/tests/{test_name}", timeout=30)
    print_json(r.json())
