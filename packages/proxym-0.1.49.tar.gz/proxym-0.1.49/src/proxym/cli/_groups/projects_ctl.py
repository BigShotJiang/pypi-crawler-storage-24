"""Click wrappers: project group — manage projects from CLI."""
from __future__ import annotations

import click

from proxym.cli._groups._shared import make_args as _make_args


# ── Project group ─────────────────────────────────────────────

@click.group(name="project")
def project():
    """Manage projects (local, git, SSH, FTP)."""
    pass


@project.command(name="list")
@click.option("--type", "source_type", default=None, help="Filter by source type (local, git, ssh, ftp)")
@click.option("--status", default=None, help="Filter by status (active, archived, error)")
@click.pass_context
def project_list(ctx: click.Context, source_type, status):
    """List registered projects."""
    from proxym.cli._client import make_client, print_json, print_table
    args = _make_args(ctx)
    params = {}
    if source_type:
        params["source_type"] = source_type
    if status:
        params["status"] = status

    with make_client(args.proxy, args.key) as c:
        r = c.get("/dashboard/projects", params=params)
        data = r.json()

    projects = data if isinstance(data, list) else data.get("projects", [])
    if getattr(args, "format", "table") == "yaml":
        print_json(data)
        return

    print(f"\n  Projects ({len(projects)})\n")
    if not projects:
        print("  No projects found.\n")
        return

    print_table(
        projects,
        ["name", "source_type", "stack", "has_git", "default_tool", "ticket_count"],
        [20, 8, 25, 6, 14, 8],
    )
    print()


@project.command(name="add")
@click.argument("path_or_url")
@click.option("--git", is_flag=True, help="Treat argument as git URL")
@click.option("--ssh", is_flag=True, help="Treat argument as SSH (user@host:/path)")
@click.option("--name", default=None, help="Project name (auto-detected if not given)")
@click.option("--tool", default=None, help="Default tool (aider, claude-code, roo-code, ...)")
@click.pass_context
def project_add(ctx: click.Context, path_or_url, git, ssh, name, tool):
    """Add a project. Accepts local path, --git URL, or --ssh user@host:/path."""
    from proxym.cli._client import make_client
    args = _make_args(ctx)
    payload = {}
    if name:
        payload["name"] = name
    if tool:
        payload["default_tool"] = tool

    if git:
        payload["git_url"] = path_or_url
    elif ssh:
        # Parse user@host:/path
        if "@" in path_or_url and ":" in path_or_url:
            user_host, path = path_or_url.split(":", 1)
            user, host = user_host.split("@", 1)
            payload["ssh_host"] = host
            payload["ssh_path"] = path
            payload["ssh_user"] = user
        else:
            click.echo(f"  Invalid SSH format: {path_or_url} (expected user@host:/path)")
            return
    else:
        payload["path"] = path_or_url

    with make_client(args.proxy, args.key) as c:
        r = c.post("/dashboard/projects", json=payload)
        r.raise_for_status()
        data = r.json()

    stack = ", ".join(data.get("stack", []))
    click.echo(f"  \u2705 Added: {data['name']} ({data['source_type']}){' [' + stack + ']' if stack else ''}")


@project.command(name="scan")
@click.argument("directory", default="~/github")
@click.pass_context
def project_scan(ctx: click.Context, directory):
    """Scan a directory for projects and register them."""
    from proxym.cli._client import make_client
    args = _make_args(ctx)

    with make_client(args.proxy, args.key) as c:
        r = c.post("/dashboard/projects/scan", json={"directory": directory})
        r.raise_for_status()
        data = r.json()

    click.echo(f"  Scanned: {data['scanned']}")
    click.echo(f"  Added: {data['added']} project(s)")
    for p in data.get("projects", []):
        stack = ", ".join(p.get("stack", []))
        click.echo(f"    + {p['name']}{' [' + stack + ']' if stack else ''}")


@project.command(name="show")
@click.argument("project_id")
@click.pass_context
def project_show(ctx: click.Context, project_id):
    """Show project details."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)

    with make_client(args.proxy, args.key) as c:
        r = c.get(f"/dashboard/projects/{project_id}")
        if r.status_code == 404:
            click.echo(f"  Project {project_id} not found.")
            return
        data = r.json()

    click.echo(f"\n  {data['id']}  {data['name']}")
    click.echo(f"  Type: {data['source_type']}  Status: {data['status']}")
    click.echo(f"  Path: {data['source_path']}")
    if data.get("local_path") and data["local_path"] != data["source_path"]:
        click.echo(f"  Local: {data['local_path']}")
    if data.get("stack"):
        click.echo(f"  Stack: {', '.join(data['stack'])}")
    if data.get("frameworks"):
        click.echo(f"  Frameworks: {', '.join(data['frameworks'])}")
    if data.get("default_tool"):
        click.echo(f"  Tool: {data['default_tool']}")
    click.echo(f"  Git: {'yes' if data.get('has_git') else 'no'}")
    click.echo(f"  Tickets: {data.get('ticket_count', 0)}")
    print()


@project.command(name="remove")
@click.argument("project_id")
@click.pass_context
def project_remove(ctx: click.Context, project_id):
    """Remove a project from the registry."""
    from proxym.cli._client import make_client
    args = _make_args(ctx)

    with make_client(args.proxy, args.key) as c:
        r = c.delete(f"/dashboard/projects/{project_id}")
        if r.status_code == 404:
            click.echo(f"  Project {project_id} not found.")
            return

    click.echo(f"  \u2705 Removed {project_id}")


@project.command(name="task")
@click.argument("project_name")
@click.argument("task_text")
@click.option("-t", "--tool", default=None, help="Tool to assign (aider, claude-code, ...)")
@click.option("--priority", default="medium", help="Priority: critical, high, medium, low")
@click.option("--type", "ticket_type", default="task", help="Type: task, bug, feature, refactor, test, docs")
@click.pass_context
def project_task(ctx: click.Context, project_name, task_text, tool, priority, ticket_type):
    """Create a ticket for a project (shortcut for 'ticket add --project')."""
    from proxym.cli._client import make_client
    args = _make_args(ctx)

    # Resolve project by name or id
    with make_client(args.proxy, args.key) as c:
        r = c.get("/dashboard/projects")
        projects = r.json() if isinstance(r.json(), list) else r.json().get("projects", [])
        project_id = None
        for p in projects:
            if p["name"] == project_name or p["id"] == project_name:
                project_id = p["id"]
                break

        if not project_id:
            click.echo(f"  Project '{project_name}' not found.")
            return

        payload = {
            "task": task_text,
            "project_id": project_id,
            "priority": priority,
            "type": ticket_type,
        }
        if tool:
            payload["tool"] = tool

        r = c.post("/dashboard/tickets", json=payload)
        r.raise_for_status()
        t = r.json()

    click.echo(f"  \u2705 {t['id']} {t.get('title', t.get('task', '')[:50])}")
