"""Click wrappers: context group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import context as context_cli
from proxym.cli._groups._shared import make_args as _make_args


@click.group(name="context")
def context():
    """Manage context, sessions, and MCP servers."""
    pass


@context.command(name="delta")
@click.option("--project-id", default="", help="Project ID")
@click.option("--diff-text", default="", help="Diff text")
@click.option("--file", "file", default=None, help="Read diff from file")
@click.option("--version", type=int, default=None, help="Delta version")
@click.option("--token-estimate", type=int, default=None, help="Estimated tokens")
@click.pass_context
def context_delta(ctx: click.Context, project_id, diff_text, file, version, token_estimate):
    """Push a context delta to the proxy."""
    args = _make_args(ctx, project_id=project_id, diff_text=diff_text,
                     file=file, version=version, token_estimate=token_estimate)
    context_cli.cmd_context_delta(args)


@context.command(name="detect")
@click.option("--message", default=None, help="User message to detect context from")
@click.option("--system-prompt", default=None, help="System prompt")
@click.option("--paths", default=None, help="Comma-separated file paths")
@click.pass_context
def context_detect(ctx: click.Context, message, system_prompt, paths):
    """Detect project context from messages or paths."""
    args = _make_args(ctx, message=message, system_prompt=system_prompt, paths=paths)
    context_cli.cmd_context_detect(args)


@context.command(name="stats")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def context_stats(ctx: click.Context, fmt: str):
    """Show context store statistics."""
    args = _make_args(ctx, format=fmt)
    context_cli.cmd_context_stats(args)


@context.command(name="sessions")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def context_sessions(ctx: click.Context, fmt: str):
    """List active agent sessions."""
    args = _make_args(ctx, format=fmt)
    context_cli.cmd_sessions_list(args)


@context.command(name="mcp")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def context_mcp(ctx: click.Context, fmt: str):
    """List registered MCP servers."""
    args = _make_args(ctx, format=fmt)
    context_cli.cmd_mcp_servers(args)
