"""Shared helpers for CLI command groups."""
from __future__ import annotations

import click


def make_args(ctx: click.Context, **kwargs):
    """Convert Click context to SimpleNamespace for legacy CLI handlers."""
    from proxym.ctl import _make_args as _ma
    return _ma(ctx, **kwargs)
