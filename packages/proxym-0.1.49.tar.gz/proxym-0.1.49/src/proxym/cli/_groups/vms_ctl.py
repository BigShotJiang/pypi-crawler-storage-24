"""Click wrappers: vm group — split from ctl.py."""
from __future__ import annotations

import click

from proxym.cli import vms as vms_cli
from proxym.cli._groups._shared import make_args as _make_args


@click.group(name="vm")
def vm():
    """Manage VMs."""
    pass


@vm.command(name="list")
@click.pass_context
def vm_list(ctx: click.Context):
    """List VMs."""
    args = _make_args(ctx)
    vms_cli.cmd_vm_list(args)


@vm.command(name="create")
@click.option("--name", default="", help="VM name")
@click.option("--tool", default="", help="Tool name")
@click.option("--account", default="", help="Account ID")
@click.option("--mount", default="", help="Mount path")
@click.option("--project", default="", help="Project path")
@click.option("--cpus", type=int, default=4, help="CPU count")
@click.option("--memory", type=int, default=6144, help="Memory in MB")
@click.option("--image", default="ubuntu-24.04", help="OS image")
@click.pass_context
def vm_create(ctx: click.Context, name: str, tool: str, account: str,
              mount: str, project: str, cpus: int, memory: int, image: str):
    """Create VM."""
    args = _make_args(ctx, name=name, tool=tool, account=account, mount=mount,
                     project=project, cpus=cpus, memory=memory, image=image)
    vms_cli.cmd_vm_create(args)


@vm.command(name="start")
@click.argument("vm_id")
@click.pass_context
def vm_start(ctx: click.Context, vm_id: str):
    """Start a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="start")
    vms_cli.cmd_vm_action(args)


@vm.command(name="stop")
@click.argument("vm_id")
@click.option("--force", is_flag=True, help="Force stop")
@click.pass_context
def vm_stop(ctx: click.Context, vm_id: str, force: bool):
    """Stop a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="stop", force=force)
    vms_cli.cmd_vm_action(args)


@vm.command(name="pause")
@click.argument("vm_id")
@click.pass_context
def vm_pause(ctx: click.Context, vm_id: str):
    """Pause a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="pause")
    vms_cli.cmd_vm_action(args)


@vm.command(name="resume")
@click.argument("vm_id")
@click.pass_context
def vm_resume(ctx: click.Context, vm_id: str):
    """Resume a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="resume")
    vms_cli.cmd_vm_action(args)


@vm.command(name="snapshot")
@click.argument("vm_id")
@click.option("--name", default=None, help="Snapshot name")
@click.pass_context
def vm_snapshot(ctx: click.Context, vm_id: str, name: str | None):
    """Snapshot a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="snapshot", name=name)
    vms_cli.cmd_vm_action(args)


@vm.command(name="switch")
@click.argument("vm_id")
@click.option("--project", required=True, help="Project path")
@click.pass_context
def vm_switch(ctx: click.Context, vm_id: str, project: str):
    """Switch project in VM."""
    args = _make_args(ctx, vm_id=vm_id, project=project)
    vms_cli.cmd_vm_switch(args)


@vm.command(name="open")
@click.argument("vm_id")
@click.pass_context
def vm_open(ctx: click.Context, vm_id: str):
    """Open SPICE viewer."""
    args = _make_args(ctx, vm_id=vm_id)
    vms_cli.cmd_vm_open(args)


@vm.command(name="ssh")
@click.argument("vm_id")
@click.option("--user", default="dev", help="SSH user")
@click.pass_context
def vm_ssh(ctx: click.Context, vm_id: str, user: str):
    """SSH into VM."""
    args = _make_args(ctx, vm_id=vm_id, user=user)
    vms_cli.cmd_vm_ssh(args)


@vm.command(name="logs")
@click.argument("vm_id")
@click.pass_context
def vm_logs(ctx: click.Context, vm_id: str):
    """Show VM logs."""
    args = _make_args(ctx, vm_id=vm_id)
    vms_cli.cmd_vm_logs(args)


@vm.command(name="delete")
@click.argument("vm_id")
@click.pass_context
def vm_delete(ctx: click.Context, vm_id: str):
    """Delete a VM."""
    args = _make_args(ctx, vm_id=vm_id)
    vms_cli.cmd_vm_delete(args)


@vm.command(name="bulk-delete")
@click.option("--vm-ids", required=True, help="Comma-separated VM IDs to delete")
@click.pass_context
def vm_bulk_delete(ctx: click.Context, vm_ids: str):
    """Delete multiple VMs."""
    args = _make_args(ctx, vm_ids=vm_ids)
    vms_cli.cmd_vm_bulk_delete(args)


@vm.command(name="console")
@click.argument("vm_id")
@click.pass_context
def vm_console(ctx: click.Context, vm_id: str):
    """Open web console for a VM (prints noVNC URL)."""
    args = _make_args(ctx, vm_id=vm_id)
    vms_cli.cmd_vm_console(args)
