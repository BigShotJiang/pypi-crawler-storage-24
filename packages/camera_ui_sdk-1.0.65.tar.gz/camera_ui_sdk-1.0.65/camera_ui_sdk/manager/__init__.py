from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal, NotRequired, Protocol, TypedDict, runtime_checkable

if TYPE_CHECKING:
    from ..camera import CameraDevice
    from ..observable import Observable
    from ..plugin import BasePlugin


ConnectionStatus = Literal["idle", "connecting", "connected", "error"]
"""Connection status for discovered cameras."""


class CoreManagerEvent(TypedDict):
    """Core manager event payload."""

    type: str
    """Event type identifier."""

    data: Any
    """Event-specific data."""


class SignedRequest(TypedDict):
    """HMAC-signed request data returned by the server."""

    serverId: str
    """Server ID."""

    token: str
    """Server authentication token."""

    timestamp: str
    """Unix timestamp string."""

    signature: str
    """HMAC-SHA256 signature."""

    body: str
    """Complete request body with server_id injected."""


@runtime_checkable
class CoreManager(Protocol):
    """
    Core manager interface for system operations.

    Provides access to system-level functionality like FFmpeg path,
    server addresses, and inter-plugin communication.

    Accessed via `api.coreManager` in plugins.

    Example:
        ```python
        # Get FFmpeg path for spawning processes
        ffmpeg_path = await api.coreManager.getFFmpegPath()

        # Get server addresses for stream URLs
        addresses = await api.coreManager.getServerAddresses()
        ```
    """

    async def connectToPlugin(self, pluginName: str) -> BasePlugin | None:
        """
        Connect to another plugin by name.

        Args:
            pluginName: Name of the plugin to connect to

        Returns:
            Plugin instance or None if not found. Cast to specific interface as needed.
        """
        ...

    async def getFFmpegPath(self) -> str:
        """
        Get the FFmpeg executable path.

        Returns:
            Path to FFmpeg binary
        """
        ...

    async def getServerAddresses(self) -> list[str]:
        """
        Get server addresses (IP addresses the server is listening on).

        Returns:
            List of server addresses
        """
        ...

    async def signRequest(self, method: str, path: str, body: str) -> SignedRequest | None:
        """
        Ask the server to HMAC-sign a request.
        Returns None if no cloud account is configured.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: Request path
            body: Request body JSON string

        Returns:
            Signed request data or None
        """
        ...

    @property
    def onEvent(self) -> Observable[CoreManagerEvent]:
        """
        Observable for core manager events (e.g. cloud account changes).

        Example:
            ```python
            api.coreManager.onEvent.subscribe(lambda e: print(e["type"], e["data"]))
            ```
        """
        ...


@runtime_checkable
class DeviceManager(Protocol):
    """
    Device manager interface for camera operations.
    Provides methods to get cameras and push discovered cameras.

    Accessed via `api.deviceManager` in plugins.

    Example:
        ```python
        # Get a camera by ID or name
        camera = await api.deviceManager.getCamera("Front Door")

        # Push discovered cameras (for cloud-based discovery)
        discovered = await fetch_cameras_from_cloud()
        await api.deviceManager.pushDiscoveredCameras(discovered)
        ```
    """

    async def pushDiscoveredCameras(self, cameras: list[DiscoveredCamera]) -> None:
        """
        Push discovered cameras to the backend.
        Use this when cameras are discovered asynchronously (e.g., after cloud login).
        Cameras will be immediately visible in the UI for adoption.

        Args:
            cameras: List of discovered cameras to push
        """
        ...

    async def getCamera(self, cameraIdOrName: str) -> CameraDevice | None:
        """
        Get a camera by ID or name.

        Args:
            cameraIdOrName: Camera ID or name

        Returns:
            Camera device or None if not found
        """
        ...


class DiscoveredCamera(TypedDict):
    """
    Discovered camera from a discovery provider.

    Represents a camera found during network scanning that can be
    connected to and added to the system.
    """

    id: str
    """Unique identifier for this discovered camera."""

    name: str
    """Display name of the camera."""

    manufacturer: NotRequired[str]
    """Camera manufacturer (optional)."""

    model: NotRequired[str]
    """Camera model (optional)."""


class DiscoveredCameraWithState(DiscoveredCamera):
    """
    Discovered camera with connection state.

    Extended version of DiscoveredCamera that includes connection
    status information for UI display.
    """

    provider: str
    """Provider plugin name."""

    connectionStatus: ConnectionStatus
    """Current connection status."""

    errorMessage: NotRequired[str]
    """Error message if connection failed."""


class CreateDownloadOptions(TypedDict):
    """Options for creating a download."""

    filePath: str
    """Absolute path to the file on disk."""

    filename: NotRequired[str]
    """Filename for Content-Disposition header."""

    mimeType: NotRequired[str]
    """MIME type for Content-Type header."""

    ttlMs: NotRequired[int]
    """Time-to-live in milliseconds."""

    deleteFileAfterDownload: NotRequired[bool]
    """Whether to delete the file after download."""


class DownloadToken(TypedDict):
    """Token returned after registering a download."""

    token: str
    """Unique download token."""

    url: str
    """URL path for downloading."""

    expiresAt: int
    """Unix timestamp (ms) when the token expires."""


@runtime_checkable
class DownloadManager(Protocol):
    """
    Download manager interface for token-based file downloads.

    Allows plugins to register files for HTTP download via a token URL.

    Accessed via `api.downloadManager` in plugins.
    """

    async def createDownload(self, options: CreateDownloadOptions) -> DownloadToken:
        """
        Register a file for download and get a token-based URL.

        Args:
            options: Download options

        Returns:
            Token, URL, and expiry information
        """
        ...

    async def deleteDownload(self, token: str) -> None:
        """
        Remove a download token and optionally delete the file.

        Args:
            token: The download token to remove
        """
        ...


__all__ = [
    # Status type
    "ConnectionStatus",
    # Manager interfaces
    "CoreManager",
    "CoreManagerEvent",
    "DeviceManager",
    "DownloadManager",
    # Signed request
    "SignedRequest",
    # Download types
    "CreateDownloadOptions",
    "DownloadToken",
    # Discovery types
    "DiscoveredCamera",
    "DiscoveredCameraWithState",
]
