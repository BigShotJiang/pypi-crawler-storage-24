from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType
from .motion import Detection, VideoFrameData
from .spec import ModelSpec


class LicensePlateProperty(str, Enum):
    """Properties for license plate sensors."""

    Detected = "detected"
    Detections = "detections"


class LicensePlateDetection(Detection):
    """A license plate detection result, extending Detection with OCR fields."""

    attribute: Literal["license_plate"]  # type: ignore[misc]
    plateText: str


class LicensePlateSensorProperties(TypedDict):
    detected: bool
    detections: list[LicensePlateDetection]


class LicensePlatePropertyChangeData(TypedDict):
    """Emitted on LicensePlateSensorLike.onPropertyChanged."""

    property: str  # LicensePlateProperty value
    value: bool | list[LicensePlateDetection]


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class LicensePlateSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for a license plate sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.LicensePlate

    @overload
    def getPropertyValue(self, property: Literal[LicensePlateProperty.Detected]) -> bool | None: ...
    @overload
    def getPropertyValue(
        self, property: Literal[LicensePlateProperty.Detections]
    ) -> list[LicensePlateDetection] | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[LicensePlatePropertyChangeData]: ...


class LicensePlateSensor(Sensor[LicensePlateSensorProperties, TStorage, str], Generic[TStorage]):
    """License plate sensor that reports detected plates with OCR text."""

    _requires_frames = False

    def __init__(self, name: str = "License Plate Sensor") -> None:
        super().__init__(name)
        self.props.detected = False
        self.props.detections = []

    @property
    def type(self) -> SensorType:
        return SensorType.LicensePlate

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return self.props.detected  # type: ignore[no-any-return]

    @detected.setter
    def detected(self, value: bool) -> None:
        self.props.detected = value

    @property
    def detections(self) -> list[LicensePlateDetection]:
        return self.props.detections  # type: ignore[no-any-return]

    @detections.setter
    def detections(self, value: list[LicensePlateDetection]) -> None:
        self.props.detections = value


class LicensePlateResult(TypedDict):
    """Return type for LicensePlateDetectorSensor.detectLicensePlates()."""

    detected: bool
    detections: list[LicensePlateDetection]


class LicensePlateDetectorSensor(LicensePlateSensor[TStorage], Generic[TStorage]):
    """License plate detector that receives video frames. Implement detectLicensePlates()."""

    _requires_frames = True

    @property
    @abstractmethod
    def modelSpec(self) -> ModelSpec:
        """Declares expected input dimensions and output labels. The backend scales frames to match."""
        ...

    @abstractmethod
    async def detectLicensePlates(
        self, frame: VideoFrameData, vehicleRegions: list[Detection] | None = None
    ) -> LicensePlateResult:
        """Analyze a video frame for license plates. Called by the backend at the configured interval."""
        ...
