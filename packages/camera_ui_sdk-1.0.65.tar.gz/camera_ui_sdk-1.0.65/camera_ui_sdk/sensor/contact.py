from __future__ import annotations

from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType


class ContactProperty(str, Enum):
    """Properties for contact sensors."""

    Detected = "detected"


class ContactSensorProperties(TypedDict):
    detected: bool


class ContactPropertyChangeData(TypedDict):
    """Emitted on ContactSensorLike.onPropertyChanged."""

    property: str  # ContactProperty value
    value: bool


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class ContactSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for a contact sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.Contact

    @overload
    def getPropertyValue(self, property: Literal[ContactProperty.Detected]) -> bool | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[ContactPropertyChangeData]: ...


class ContactSensor(Sensor[ContactSensorProperties, TStorage, str], Generic[TStorage]):
    """Contact sensor for door/window open-close state."""

    _requires_frames = False

    def __init__(self, name: str = "Contact Sensor") -> None:
        super().__init__(name)
        self.props.detected = False

    @property
    def type(self) -> SensorType:
        return SensorType.Contact

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return self.props.detected  # type: ignore[no-any-return]

    @detected.setter
    def detected(self, value: bool) -> None:
        self.props.detected = value
