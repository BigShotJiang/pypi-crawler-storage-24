"""
Local provider for offline testing and development.

This provider doesn't call any external API and simply echoes user messages.
"""

from __future__ import annotations

from typing import Any, AsyncIterable, Iterable, List, Union

from ..types import Message, Role, ToolCall
from ..usage import UsageStats
from .base import Provider


class LocalProvider(Provider):
    """
    Local fallback provider.

    This does not call a model. It echoes the latest user content and is useful
    for offline/manual testing or as a safe default.
    """

    name = "local"
    supports_streaming = True
    supports_async = False  # LocalProvider is sync-only

    def complete(
        self,
        *,
        model: str,
        system_prompt: str,
        messages: List[Message],
        tools: List[Any] | None = None,  # Type Any to avoid circular import dynamically
        temperature: float = 0.0,
        max_tokens: int = 1000,
        timeout: float | None = None,
    ) -> tuple[Message, UsageStats]:
        last_user = next((m for m in reversed(messages) if m.role == Role.USER), None)
        user_text = last_user.content if last_user else ""
        response_text = f"[local provider: {model}] {user_text or 'No user message provided.'}"

        # Create dummy usage stats
        usage_stats = UsageStats(
            prompt_tokens=0,
            completion_tokens=0,
            total_tokens=0,
            cost_usd=0.0,
            model=model,
            provider="local",
        )
        response_msg = Message(role=Role.ASSISTANT, content=response_text)
        return response_msg, usage_stats

    def stream(
        self,
        *,
        model: str,
        system_prompt: str,
        messages: List[Message],
        tools: List[Any] | None = None,
        temperature: float = 0.0,
        max_tokens: int = 1000,
        timeout: float | None = None,
    ) -> Iterable[str]:
        response_msg, _ = self.complete(
            model=model,
            system_prompt=system_prompt,
            messages=messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=timeout,
        )
        text = response_msg.content
        for token in text.split():
            yield token + " "

    # Async methods not supported for LocalProvider
    async def acomplete(
        self,
        *,
        model: str,
        system_prompt: str,
        messages: List[Message],
        tools: List[Any] | None = None,
        temperature: float = 0.0,
        max_tokens: int = 1000,
        timeout: float | None = None,
    ) -> tuple[Message, UsageStats]:
        raise NotImplementedError("LocalProvider does not support async operations")

    async def astream(
        self,
        *,
        model: str,
        system_prompt: str,
        messages: List[Message],
        tools: List[Any] | None = None,
        temperature: float = 0.0,
        max_tokens: int = 1000,
        timeout: float | None = None,
    ) -> AsyncIterable[Union[str, ToolCall]]:
        raise NotImplementedError("LocalProvider does not support async operations")
        yield ""  # pragma: no cover  # makes this an async generator for mypy


__all__ = ["LocalProvider"]
