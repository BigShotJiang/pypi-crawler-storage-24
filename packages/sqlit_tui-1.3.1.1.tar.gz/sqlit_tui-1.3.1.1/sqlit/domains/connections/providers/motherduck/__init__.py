"""MotherDuck provider package."""
