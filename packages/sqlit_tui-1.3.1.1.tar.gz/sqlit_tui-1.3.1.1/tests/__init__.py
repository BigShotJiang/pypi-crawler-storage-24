"""Integration tests for sqlit."""
