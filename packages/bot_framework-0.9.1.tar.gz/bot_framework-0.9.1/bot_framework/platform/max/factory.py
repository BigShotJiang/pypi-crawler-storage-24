from __future__ import annotations

from bot_framework.core.protocols.i_message_core_base import IMessageCoreBase
from bot_framework.domain.flow_management.protocols.i_flow_message_storage import (
    IFlowMessageStorage,
)
from bot_framework.domain.role_management.repos import RoleRepo, UserRepo
from bot_framework.domain.role_management.services import EnsureUserExists
from bot_framework.platform.max.max_dialogs import MaxDialogs
from bot_framework.platform.max.middleware import MaxEnsureUserMiddleware
from bot_framework.platform.max.services.max_message_core import MaxMessageCore


class MaxPlatformFactory:
    def create_core(
        self,
        bot_token: str,
        database_url: str,
        flow_message_storage: IFlowMessageStorage,
    ) -> MaxMessageCore:
        ensure_user_exists = EnsureUserExists(
            user_repo=UserRepo(database_url=database_url),
            role_repo=RoleRepo(database_url=database_url),
        )
        ensure_user_middleware = MaxEnsureUserMiddleware(
            ensure_user_exists=ensure_user_exists,
        )
        return MaxDialogs(
            token=bot_token,
            database_url=database_url,
            flow_message_storage=flow_message_storage,
            ensure_user_middleware=ensure_user_middleware,
        ).core

    def run(self, core: IMessageCoreBase) -> None:
        if not isinstance(core, MaxMessageCore):
            msg = "MaxPlatformFactory.run() requires MaxMessageCore"
            raise TypeError(msg)
        core.run()

    @property
    def supports_support_chat(self) -> bool:
        return False
