from __future__ import annotations

from bot_framework.core.protocols.i_message_core_base import IMessageCoreBase
from bot_framework.domain.flow_management.protocols.i_flow_message_storage import (
    IFlowMessageStorage,
)
from bot_framework.platform.telegram.services.telegram_message_core import (
    TelegramMessageCore,
)


class TelegramPlatformFactory:
    def __init__(self, use_class_middlewares: bool = True) -> None:
        self._use_class_middlewares = use_class_middlewares

    def create_core(
        self,
        bot_token: str,
        database_url: str,
        flow_message_storage: IFlowMessageStorage,
    ) -> TelegramMessageCore:
        return TelegramMessageCore(
            bot_token=bot_token,
            database_url=database_url,
            flow_message_storage=flow_message_storage,
            use_class_middlewares=self._use_class_middlewares,
        )

    def run(self, core: IMessageCoreBase) -> None:
        if not isinstance(core, TelegramMessageCore):
            msg = "TelegramPlatformFactory.run() requires TelegramMessageCore"
            raise TypeError(msg)
        core.polling_bot.infinity_polling()

    @property
    def supports_support_chat(self) -> bool:
        return True
