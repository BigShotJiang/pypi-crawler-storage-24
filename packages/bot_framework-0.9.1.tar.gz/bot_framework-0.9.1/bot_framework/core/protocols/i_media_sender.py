from collections.abc import Sequence
from typing import IO, Protocol


class IMediaSender(Protocol):
    """Отправка медиа-контента: фото, медиагруппы."""

    def send_media_group_urls(
        self,
        chat_id: int,
        urls: Sequence[str],
        caption: str | None = None,
    ) -> None:
        """Отправить группу фотографий по URL (до 10 штук).

        Args:
            chat_id: ID чата получателя.
            urls: Список публичных URL фотографий.
            caption: Подпись к первому фото (HTML).
        """
        ...

    def send_media_group_files(
        self,
        chat_id: int,
        files: Sequence[IO[bytes]],
        caption: str | None = None,
    ) -> None:
        """Отправить группу фотографий как файлы (до 10 штук).

        Args:
            chat_id: ID чата получателя.
            files: Список файловых объектов с фотографиями.
            caption: Подпись к первому фото (HTML).
        """
        ...
