from bot_framework.app.protocols.i_platform_factory import IPlatformFactory

__all__ = ["IPlatformFactory"]
