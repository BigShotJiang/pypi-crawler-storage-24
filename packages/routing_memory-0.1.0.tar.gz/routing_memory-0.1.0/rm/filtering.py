"""Score-based token filtering (τ threshold)."""

from typing import List
from .retrieval import RetrievalResult


def filter_by_score(results: List[RetrievalResult], tau: float = 0.5) -> List[RetrievalResult]:
    """Filter retrieval results below score threshold τ."""
    return [r for r in results if r.score >= tau]


def filter_top_n(results: List[RetrievalResult], n: int = 3) -> List[RetrievalResult]:
    """Keep only top-n results by score."""
    sorted_results = sorted(results, key=lambda r: r.score, reverse=True)
    return sorted_results[:n]
