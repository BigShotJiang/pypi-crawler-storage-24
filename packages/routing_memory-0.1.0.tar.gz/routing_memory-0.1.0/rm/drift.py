"""Drift Monitor — Detects distribution shift via quantization error tracking.

Monitors rolling qerr and margin to detect when incoming queries diverge
from the codebook's trained distribution. When drift is detected:
- Triggers aggressive codebook adaptation (splits/updates)
- Logs alarm for observability
"""

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, List, Optional

logger = logging.getLogger("rm.drift")


@dataclass
class DriftAlarm:
    """Record of a drift event."""
    timestamp: float
    ratio: float        # qerr_recent / qerr_baseline
    episode: int
    message: str


class DriftMonitor:
    """Tracks rolling quantization error to detect distribution drift.

    Alarm triggers when recent qerr exceeds baseline by a configurable factor.
    """

    WINDOW_SIZE = 20          # rolling window for recent stats
    BASELINE_WINDOW = 50      # initial baseline window
    ALARM_RATIO = 1.3         # qerr ratio threshold for alarm
    COOLDOWN_QUERIES = 30     # min queries between alarms

    def __init__(self):
        self._qerr_history: Deque[float] = deque(maxlen=2000)
        self._margin_history: Deque[float] = deque(maxlen=2000)
        self._baseline_qerr: Optional[float] = None
        self._baseline_margin: Optional[float] = None
        self._episode = 0
        self._last_alarm_episode = -self.COOLDOWN_QUERIES
        self._alarms: List[DriftAlarm] = []
        self._in_drift = False

    @property
    def episode_count(self) -> int:
        return self._episode

    @property
    def in_drift(self) -> bool:
        return self._in_drift

    @property
    def alarms(self) -> List[DriftAlarm]:
        return list(self._alarms)

    @property
    def baseline_qerr(self) -> Optional[float]:
        return self._baseline_qerr

    @property
    def recent_qerr(self) -> float:
        if len(self._qerr_history) < 5:
            return 0.0
        recent = list(self._qerr_history)[-self.WINDOW_SIZE:]
        return sum(recent) / len(recent)

    @property
    def drift_ratio(self) -> float:
        if self._baseline_qerr is None or self._baseline_qerr < 1e-10:
            return 0.0
        return self.recent_qerr / self._baseline_qerr

    def record(self, qerr: float, margin: float = 0.0) -> Optional[DriftAlarm]:
        """Record a query's quantization error and margin.

        Returns DriftAlarm if alarm was triggered, None otherwise.
        """
        self._episode += 1
        self._qerr_history.append(qerr)
        self._margin_history.append(margin)

        # Establish baseline from first N queries
        if self._baseline_qerr is None and len(self._qerr_history) >= self.BASELINE_WINDOW:
            baseline_data = list(self._qerr_history)[:self.BASELINE_WINDOW]
            self._baseline_qerr = sum(baseline_data) / len(baseline_data)
            baseline_margins = list(self._margin_history)[:self.BASELINE_WINDOW]
            self._baseline_margin = sum(baseline_margins) / len(baseline_margins)
            return None

        # Check for drift
        return self._check_alarm()

    def _check_alarm(self) -> Optional[DriftAlarm]:
        """Check if current qerr indicates drift."""
        if self._baseline_qerr is None:
            return None
        if len(self._qerr_history) < self.WINDOW_SIZE:
            return None

        ratio = self.drift_ratio

        if ratio >= self.ALARM_RATIO:
            if not self._in_drift:
                self._in_drift = True
            # Rate-limit alarms
            if self._episode - self._last_alarm_episode >= self.COOLDOWN_QUERIES:
                alarm = DriftAlarm(
                    timestamp=time.time(),
                    ratio=ratio,
                    episode=self._episode,
                    message=f"DRIFT_ALARM: qerr {ratio:.1f}x baseline at episode {self._episode}",
                )
                self._alarms.append(alarm)
                self._last_alarm_episode = self._episode
                logger.warning(f"[rm] {alarm.message}")
                return alarm
        else:
            if self._in_drift:
                self._in_drift = False
                logger.info(f"[rm] Drift recovered at episode {self._episode}, "
                            f"ratio={ratio:.2f}")

        return None

    def reset_baseline(self) -> None:
        """Reset baseline using recent data (after adaptation)."""
        if len(self._qerr_history) >= self.WINDOW_SIZE:
            recent = list(self._qerr_history)[-self.WINDOW_SIZE:]
            self._baseline_qerr = sum(recent) / len(recent)
            self._in_drift = False
            logger.info(f"[rm] Baseline reset: new baseline_qerr={self._baseline_qerr:.4f}")

    def get_stats(self) -> dict:
        return {
            "episode": self._episode,
            "baseline_qerr": self._baseline_qerr,
            "recent_qerr": self.recent_qerr,
            "drift_ratio": self.drift_ratio,
            "in_drift": self._in_drift,
            "alarm_count": len(self._alarms),
        }
