"""Abstract embedding backend interface."""

from abc import ABC, abstractmethod
from typing import List
import numpy as np


class EmbeddingBackend(ABC):
    """Abstract base for embedding providers."""

    @property
    @abstractmethod
    def dim(self) -> int:
        """Embedding dimensionality."""

    @abstractmethod
    def encode(self, text: str) -> np.ndarray:
        """Encode a single text to a normalized vector."""

    @abstractmethod
    def encode_batch(self, texts: List[str]) -> np.ndarray:
        """Encode a batch of texts. Returns (N, dim) matrix."""
