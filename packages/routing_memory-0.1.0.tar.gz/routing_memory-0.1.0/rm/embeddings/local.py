"""Local sentence-transformers embedding backend."""

from typing import Dict, List
import numpy as np

from .base import EmbeddingBackend

_model_instance = None


def _get_model(model_name: str):
    """Lazy singleton for SentenceTransformer model."""
    global _model_instance
    if _model_instance is None:
        from sentence_transformers import SentenceTransformer
        _model_instance = SentenceTransformer(model_name)
    return _model_instance


class LocalEmbeddings(EmbeddingBackend):
    """sentence-transformers wrapper with caching. Default: all-MiniLM-L6-v2 (d=384)."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        self.model_name = model_name
        self._cache: Dict[str, np.ndarray] = {}
        self._dim: int = 384  # MiniLM default

    @property
    def dim(self) -> int:
        return self._dim

    def encode(self, text: str) -> np.ndarray:
        if text in self._cache:
            return self._cache[text]
        model = _get_model(self.model_name)
        vec = model.encode(text, normalize_embeddings=True)
        vec = np.asarray(vec, dtype=np.float32)
        self._dim = vec.shape[0]
        self._cache[text] = vec
        return vec

    def encode_batch(self, texts: List[str]) -> np.ndarray:
        # Check cache for all
        uncached = [(i, t) for i, t in enumerate(texts) if t not in self._cache]

        if uncached:
            model = _get_model(self.model_name)
            uncached_texts = [t for _, t in uncached]
            vecs = model.encode(uncached_texts, normalize_embeddings=True, batch_size=64)
            vecs = np.asarray(vecs, dtype=np.float32)
            self._dim = vecs.shape[1]
            for (_, text), vec in zip(uncached, vecs):
                self._cache[text] = vec

        result = np.array([self._cache[t] for t in texts], dtype=np.float32)
        return result
