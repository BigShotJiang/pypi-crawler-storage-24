"""Routing Memory — Lightweight long-term memory via vector-quantized routing."""

from .memory import RoutingMemory
from .codebook import Codebook, CentroidBucket
from .retrieval import L1Retriever, L1Result, RetrievalResult
from .filtering import filter_by_score, filter_top_n
from .drift import DriftMonitor, DriftAlarm
from .embeddings import LocalEmbeddings, EmbeddingBackend
from .storage import RMSQLiteBackend, RMStorageBackend

__all__ = [
    "RoutingMemory",
    "Codebook",
    "CentroidBucket",
    "L1Retriever",
    "L1Result",
    "RetrievalResult",
    "filter_by_score",
    "filter_top_n",
    "DriftMonitor",
    "DriftAlarm",
    "LocalEmbeddings",
    "EmbeddingBackend",
    "RMSQLiteBackend",
    "RMStorageBackend",
]

__version__ = "0.1.0"
