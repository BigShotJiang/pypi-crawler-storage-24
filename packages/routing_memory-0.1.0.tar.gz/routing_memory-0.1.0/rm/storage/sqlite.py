"""SQLite storage backend for Routing Memory."""

import json
import sqlite3
import numpy as np
from typing import Dict, List, Optional

from .base import RMStorageBackend


class RMSQLiteBackend(RMStorageBackend):
    """Default storage: single SQLite file, zero external dependencies."""

    def __init__(self, db_path: str = "rm_memory.db"):
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        self._connect()
        self.init_schema()

    def _connect(self) -> None:
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._connect()
        return self._conn

    def init_schema(self) -> None:
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS rm_items (
                id TEXT PRIMARY KEY,
                text TEXT NOT NULL,
                embedding BLOB NOT NULL,
                metadata TEXT DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS rm_codebook (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                centroids BLOB NOT NULL,
                assignments TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        self.conn.commit()

    # --- Items ---

    def insert_item(self, item_id: str, text: str, embedding: np.ndarray,
                    metadata: Optional[Dict] = None) -> None:
        emb_blob = embedding.astype(np.float32).tobytes()
        meta_json = json.dumps(metadata or {})
        self.conn.execute(
            "INSERT OR REPLACE INTO rm_items (id, text, embedding, metadata) VALUES (?, ?, ?, ?)",
            (item_id, text, emb_blob, meta_json)
        )
        self.conn.commit()

    def get_item(self, item_id: str) -> Optional[Dict]:
        row = self.conn.execute("SELECT * FROM rm_items WHERE id = ?", (item_id,)).fetchone()
        if row is None:
            return None
        return self._row_to_item(row)

    def get_all_items(self) -> List[Dict]:
        rows = self.conn.execute("SELECT * FROM rm_items ORDER BY created_at").fetchall()
        return [self._row_to_item(r) for r in rows]

    def get_all_embeddings(self) -> tuple:
        rows = self.conn.execute("SELECT id, embedding FROM rm_items").fetchall()
        if not rows:
            return [], np.empty((0, 0))
        ids = [r["id"] for r in rows]
        embs = np.array([np.frombuffer(r["embedding"], dtype=np.float32) for r in rows])
        return ids, embs

    def item_count(self) -> int:
        row = self.conn.execute("SELECT COUNT(*) as cnt FROM rm_items").fetchone()
        return row["cnt"]

    def delete_item(self, item_id: str) -> None:
        self.conn.execute("DELETE FROM rm_items WHERE id = ?", (item_id,))
        self.conn.commit()

    def _row_to_item(self, row) -> Dict:
        return {
            "id": row["id"],
            "text": row["text"],
            "embedding": np.frombuffer(row["embedding"], dtype=np.float32),
            "metadata": json.loads(row["metadata"]),
            "created_at": row["created_at"],
        }

    # --- Codebook ---

    def save_codebook(self, centroids: np.ndarray, assignments: Dict) -> None:
        blob = centroids.astype(np.float32).tobytes()
        assign_json = json.dumps({str(k): v for k, v in assignments.items()})
        self.conn.execute(
            """INSERT OR REPLACE INTO rm_codebook (id, centroids, assignments, updated_at)
               VALUES (1, ?, ?, CURRENT_TIMESTAMP)""",
            (blob, assign_json)
        )
        self.conn.commit()

    def load_codebook(self) -> Optional[tuple]:
        row = self.conn.execute("SELECT * FROM rm_codebook WHERE id = 1").fetchone()
        if row is None:
            return None
        centroids = np.frombuffer(row["centroids"], dtype=np.float32)
        assignments = json.loads(row["assignments"])
        assignments = {int(k): v for k, v in assignments.items()}
        return centroids, assignments

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
