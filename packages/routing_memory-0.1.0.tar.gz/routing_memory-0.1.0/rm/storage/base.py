"""Abstract storage backend interface for Routing Memory."""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional
import numpy as np


class RMStorageBackend(ABC):
    """Abstract base for RM storage backends."""

    @abstractmethod
    def init_schema(self) -> None:
        """Create tables if they don't exist."""

    @abstractmethod
    def insert_item(self, item_id: str, text: str, embedding: np.ndarray,
                    metadata: Optional[Dict] = None) -> None:
        ...

    @abstractmethod
    def get_item(self, item_id: str) -> Optional[Dict]:
        ...

    @abstractmethod
    def get_all_items(self) -> List[Dict]:
        ...

    @abstractmethod
    def get_all_embeddings(self) -> tuple:
        """Return (ids, embeddings_matrix) for all items."""

    @abstractmethod
    def item_count(self) -> int:
        ...

    @abstractmethod
    def delete_item(self, item_id: str) -> None:
        ...

    @abstractmethod
    def save_codebook(self, centroids: np.ndarray, assignments: Dict) -> None:
        ...

    @abstractmethod
    def load_codebook(self) -> Optional[tuple]:
        """Return (centroids, assignments) or None."""
