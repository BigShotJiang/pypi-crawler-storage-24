"""RoutingMemory — Lightweight long-term memory via vector-quantized routing.

Usage:
    from rm import RoutingMemory

    memory = RoutingMemory()
    memory.add("User prefers dark mode")
    results = memory.search("what does user prefer?", top_k=5)
"""

import uuid
import numpy as np
from typing import Dict, List, Optional

from .codebook import Codebook, CentroidBucket
from .retrieval import L1Retriever, L1Result, RetrievalResult
from .filtering import filter_by_score, filter_top_n
from .drift import DriftMonitor, DriftAlarm
from .embeddings.local import LocalEmbeddings
from .embeddings.base import EmbeddingBackend
from .storage.sqlite import RMSQLiteBackend
from .storage.base import RMStorageBackend


class RoutingMemory:
    """Standalone Routing Memory: VQ codebook retrieval with score filtering and drift detection.

    Zero-config: just instantiate and use.

    Args:
        db_path: SQLite database path. None for in-memory only (no persistence).
        embedding_model: Sentence-transformer model name.
        n_probes: Number of centroids to probe per query.
        score_threshold: Minimum score for retrieval results.
        dim: Embedding dimensionality (auto-detected if using LocalEmbeddings).
        seed: Random seed for reproducibility.
        storage: Custom storage backend. If None, uses SQLite.
        embedder: Custom embedding backend. If None, uses LocalEmbeddings.
    """

    def __init__(
        self,
        db_path: Optional[str] = "rm_memory.db",
        embedding_model: str = "all-MiniLM-L6-v2",
        n_probes: int = 3,
        score_threshold: float = 0.3,
        dim: int = 384,
        seed: int = 42,
        storage: Optional[RMStorageBackend] = None,
        embedder: Optional[EmbeddingBackend] = None,
    ):
        # Storage
        if storage is not None:
            self._storage = storage
        elif db_path is not None:
            self._storage = RMSQLiteBackend(db_path)
        else:
            self._storage = None

        # Embeddings
        if embedder is not None:
            self._embedder = embedder
        else:
            self._embedder = LocalEmbeddings(embedding_model)

        # Core components
        self._codebook = Codebook(dim=self._embedder.dim, seed=seed)
        self._retriever = L1Retriever(
            self._codebook,
            n_probes=n_probes,
            score_threshold=score_threshold,
        )
        self._drift = DriftMonitor()
        self._query_count = 0

        # Load existing data from storage
        self._load_from_storage()

    def _load_from_storage(self) -> None:
        """Restore codebook + items from persisted data."""
        if self._storage is None:
            return
        items = self._storage.get_all_items()
        if items:
            ids = [item["id"] for item in items]
            embeddings = np.array([item["embedding"] for item in items], dtype=np.float32)
            self._codebook.fit(embeddings, ids)
            for item in items:
                self._retriever.register_item(
                    item["id"], item["text"], item["embedding"], item.get("metadata", {})
                )

    # ─── Public API ──────────────────────────────────────────────────────────

    def add(self, text: str, item_id: Optional[str] = None,
            metadata: Optional[Dict] = None) -> str:
        """Store a memory item.

        Args:
            text: The text content to store.
            item_id: Optional custom ID. Auto-generated if None.
            metadata: Optional metadata dict.

        Returns:
            The item ID.
        """
        item_id = item_id or str(uuid.uuid4())[:12]
        meta = metadata or {}
        embedding = self._embedder.encode(text)

        # Persist
        if self._storage is not None:
            self._storage.insert_item(item_id, text, embedding, meta)

        # Index
        self._codebook.add(item_id, embedding)
        self._retriever.register_item(item_id, text, embedding, meta)

        return item_id

    def search(self, query: str, top_k: int = 5,
               threshold: Optional[float] = None) -> List[Dict]:
        """Search memory by semantic similarity.

        Args:
            query: Natural language query.
            top_k: Maximum results to return.
            threshold: Optional score threshold (overrides constructor default).

        Returns:
            List of dicts with keys: text, score, centroid_id, item_id, metadata.
        """
        if not self._codebook.fitted:
            return []

        emb = self._embedder.encode(query)
        l1_result = self._retriever.query(emb)

        # Drift monitoring + EMA update
        self._query_count += 1
        cid, qerr = self._codebook.encode(emb)
        margin = self._codebook.margin(emb)
        self._drift.record(qerr, margin)
        self._codebook.ema_update(cid, emb)

        if self._query_count % self._codebook.UPDATE_INTERVAL == 0:
            self._codebook.run_adaptation()

        results = l1_result.results[:top_k]

        # Apply threshold filtering
        if threshold is not None:
            results = filter_by_score(results, tau=threshold)

        return [
            {
                "text": r.text,
                "score": r.score,
                "centroid_id": r.centroid_id,
                "item_id": r.item_id,
            }
            for r in results
        ]

    def search_with_signals(self, query: str, top_k: int = 5,
                            threshold: Optional[float] = None) -> Dict:
        """Search with full routing signals exposed (for gate integration).

        Returns:
            Dict with keys: results, confidence, margin, qerr, centroid_id, probed_centroids.
        """
        if not self._codebook.fitted:
            return {
                "results": [],
                "confidence": 0.0,
                "margin": 0.0,
                "qerr": 1.0,
                "centroid_id": -1,
                "probed_centroids": [],
            }

        emb = self._embedder.encode(query)
        l1_result = self._retriever.query(emb)

        # Drift monitoring + EMA update
        self._query_count += 1
        cid, qerr = self._codebook.encode(emb)
        margin_val = self._codebook.margin(emb)
        self._drift.record(qerr, margin_val)
        self._codebook.ema_update(cid, emb)

        if self._query_count % self._codebook.UPDATE_INTERVAL == 0:
            self._codebook.run_adaptation()

        results = l1_result.results[:top_k]
        if threshold is not None:
            results = filter_by_score(results, tau=threshold)

        probed = self._codebook.top_centroids(emb, self._retriever.n_probes)

        return {
            "results": [
                {
                    "text": r.text,
                    "score": r.score,
                    "centroid_id": r.centroid_id,
                    "item_id": r.item_id,
                }
                for r in results
            ],
            "confidence": l1_result.confidence,
            "margin": l1_result.margin,
            "qerr": qerr,
            "centroid_id": cid,
            "probed_centroids": probed,
        }

    def stats(self) -> Dict:
        """Get memory statistics."""
        item_count = 0
        if self._storage is not None:
            item_count = self._storage.item_count()
        else:
            # Count from codebook buckets
            for bucket in self._codebook.buckets.values():
                item_count += len(bucket.item_ids)

        k = self._codebook.K
        compression = f"{k * self._codebook.dim * 4}B routing vs {item_count * self._codebook.dim * 4}B dense" if item_count > 0 else "N/A"

        return {
            "item_count": item_count,
            "K": k,
            "codebook_fitted": self._codebook.fitted,
            "compression_ratio": f"{max(1, item_count * 2 // max(k, 1))}x" if k > 0 else "N/A",
            "drift": self._drift.get_stats(),
        }

    def codebook_info(self) -> Dict:
        """Get codebook details."""
        if not self._codebook.fitted:
            return {"K": 0, "d": self._codebook.dim, "gini": 0.0, "dead_codes": 0}

        # Compute Gini coefficient of bucket sizes
        sizes = []
        dead = 0
        for cid in range(self._codebook.K):
            bucket = self._codebook.buckets.get(cid)
            if bucket:
                sizes.append(len(bucket.item_ids))
                if len(bucket.item_ids) == 0:
                    dead += 1
            else:
                sizes.append(0)
                dead += 1

        gini = 0.0
        if sizes and sum(sizes) > 0:
            sizes_arr = np.array(sizes, dtype=float)
            n = len(sizes_arr)
            if n > 0:
                sorted_sizes = np.sort(sizes_arr)
                index = np.arange(1, n + 1)
                gini = float((2 * np.sum(index * sorted_sizes) - (n + 1) * np.sum(sorted_sizes)) / (n * np.sum(sorted_sizes)))

        return {
            "K": self._codebook.K,
            "d": self._codebook.dim,
            "gini": round(gini, 3),
            "dead_codes": dead,
        }

    # ─── Consolidation Hooks (for HGA integration) ───────────────────────────

    def get_bucket_stats(self, centroid_id: int) -> Dict:
        """For consolidation: bucket size, variance."""
        bucket = self._codebook.get_bucket_items(centroid_id)
        return {
            "centroid_id": centroid_id,
            "size": len(bucket.item_ids),
            "variance": self._codebook.bucket_variance(centroid_id),
            "access_count": bucket.access_count,
        }

    def force_split(self, centroid_id: int) -> bool:
        """For AQSRL reshaping: split overloaded bucket."""
        return self._codebook.maybe_split(centroid_id)

    def get_codebook(self) -> Codebook:
        """Direct access to the codebook (for co-occurrence mining, etc.)."""
        return self._codebook

    def get_retriever(self) -> L1Retriever:
        """Direct access to the retriever."""
        return self._retriever

    def get_drift_monitor(self) -> DriftMonitor:
        """Direct access to drift monitor."""
        return self._drift

    # ─── L1Result access (for HGA gate) ──────────────────────────────────────

    def query_l1(self, query_embedding: np.ndarray) -> L1Result:
        """Low-level: run L1 retrieval on a pre-computed embedding.

        For HGA gate integration where embedding is already computed.
        """
        if not self._codebook.fitted:
            return L1Result(results=[], confidence=0.0, margin=0.0, top_centroid=-1)
        return self._retriever.query(query_embedding)

    def encode_and_query(self, query: str, top_k: int = 5) -> L1Result:
        """Encode query text and run L1 retrieval. Returns raw L1Result."""
        if not self._codebook.fitted:
            return L1Result(results=[], confidence=0.0, margin=0.0, top_centroid=-1)
        emb = self._embedder.encode(query)
        result = self._retriever.query(emb)
        result.results = result.results[:top_k]
        return result

    # ─── Persistence ─────────────────────────────────────────────────────────

    def save(self) -> None:
        """Persist codebook state to storage."""
        if self._storage is None or not self._codebook.fitted:
            return
        centroids, assignments = self._codebook.get_state()
        if centroids is not None:
            self._storage.save_codebook(centroids, assignments)

    def close(self) -> None:
        """Close storage connection."""
        if self._storage is not None and hasattr(self._storage, 'close'):
            self._storage.close()

    # ─── Embedding access ────────────────────────────────────────────────────

    @property
    def embedder(self) -> EmbeddingBackend:
        """Access the embedding backend."""
        return self._embedder

    @property
    def codebook(self) -> Codebook:
        """Access the codebook."""
        return self._codebook

    @property
    def drift_monitor(self) -> DriftMonitor:
        """Access the drift monitor."""
        return self._drift
