"""Multi-probe retrieval with dot-product reranking."""

import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional

from .codebook import Codebook


@dataclass
class RetrievalResult:
    """Single retrieval result."""
    item_id: str
    text: str
    score: float
    centroid_id: int


@dataclass
class L1Result:
    """L1 retrieval output with routing signals."""
    results: List[RetrievalResult]
    confidence: float
    margin: float
    top_centroid: int


class L1Retriever:
    """Multi-probe retrieval over VQ codebook with dot-product reranking."""

    def __init__(self, codebook: Codebook, n_probes: int = 3, top_k: int = 5,
                 score_threshold: float = 0.3):
        self.codebook = codebook
        self.n_probes = n_probes
        self.top_k = top_k
        self.score_threshold = score_threshold
        self._item_store: Dict[str, Dict] = {}  # id -> {text, embedding, ...}

    def register_item(self, item_id: str, text: str, embedding: np.ndarray,
                      metadata: Optional[Dict] = None) -> None:
        """Register an item for retrieval."""
        self._item_store[item_id] = {
            "text": text,
            "embedding": embedding,
            "metadata": metadata or {},
        }

    def query(self, query_embedding: np.ndarray) -> L1Result:
        """Multi-probe retrieval: search top-n centroids, rerank by dot product."""
        if not self.codebook.fitted:
            return L1Result(results=[], confidence=0.0, margin=0.0, top_centroid=-1)

        conf = self.codebook.conf(query_embedding)
        margin = self.codebook.margin(query_embedding)
        top_centroids = self.codebook.top_centroids(query_embedding, self.n_probes)

        if not top_centroids:
            return L1Result(results=[], confidence=conf, margin=margin, top_centroid=-1)

        # Collect candidates from top centroids
        candidates = []
        for cid in top_centroids:
            bucket = self.codebook.get_bucket_items(cid)
            for item_id, emb in zip(bucket.item_ids, bucket.embeddings):
                if item_id in self._item_store:
                    score = float(query_embedding @ emb)
                    candidates.append((item_id, score, cid))

        # Sort by score, take top_k
        candidates.sort(key=lambda x: x[1], reverse=True)
        candidates = candidates[:self.top_k]

        # Filter by score threshold
        results = []
        for item_id, score, cid in candidates:
            if score >= self.score_threshold:
                item = self._item_store[item_id]
                results.append(RetrievalResult(
                    item_id=item_id,
                    text=item["text"],
                    score=score,
                    centroid_id=cid,
                ))

        return L1Result(
            results=results,
            confidence=conf,
            margin=margin,
            top_centroid=top_centroids[0] if top_centroids else -1,
        )
