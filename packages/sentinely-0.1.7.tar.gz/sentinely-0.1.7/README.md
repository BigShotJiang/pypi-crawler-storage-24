# sentinely

Runtime guardrails for AI agents. Scores every tool call against the original task intent and blocks attacks before they execute.

## Install

```bash
pip install sentinely
```

## Quickstart

```python
from sentinel import protect

protected = protect(agent, task="summarize the Q3 report", policy="strict")
result = await protected.invoke("summarize the Q3 report")
```

That's it. Every tool call the agent makes is now scored against the original task. Dangerous actions are blocked. Suspicious actions are flagged. Everything is logged.

## What it protects against

- **Prompt injection** — detects instructions embedded in external content (files, emails, API responses) that try to hijack the agent's behavior.
- **Task drift** — tracks the full action chain and flags when the agent gradually wanders away from what the user actually asked for.
- **Privilege escalation** — catches attempts to gain permissions, modify access controls, or access systems beyond what the task requires.
- **Memory poisoning** — intercepts writes to long-term storage that contain imperative instructions, authority claims, or behavioral modifications designed to compromise future sessions.

## Configuration

| Option                  | Default    | Description                                                                                                                |
| ----------------------- | ---------- | -------------------------------------------------------------------------------------------------------------------------- |
| `policy`                | `"strict"` | `"strict"` blocks at threshold. `"permissive"` raises block threshold to 90. `"monitor"` logs everything but never blocks. |
| `allow_threshold`       | `50`       | Risk scores below this are auto-allowed.                                                                                   |
| `flag_threshold`        | `80`       | Risk scores at or above this are hard-blocked. Between allow and flag thresholds: allowed but flagged.                     |
| `block_on_unknown`      | `True`     | If Sentinely's behavioral analysis engine fails or returns low confidence, flag the action.                                |
| `max_consecutive_flags` | `3`        | Auto-block after this many consecutive flagged actions in a session.                                                       |

## Environment variables

| Variable              | Required | Default                     | Description                                                                   |
| --------------------- | -------- | --------------------------- | ----------------------------------------------------------------------------- |
| `SENTINELY_API_KEY`   | No       | —                           | API key for the Sentinely event API. Events are buffered locally if not set.  |
| `SENTINELY_API_URL`   | No       | `https://sentinely.ai/api` | Sentinely API base URL.                                                       |
| `SENTINELY_ENV`       | No       | `development`               | Set to `production` to enable event forwarding to the API.                    |

## Docs

[https://sentinely.ai/docs](https://sentinely.ai/docs)
