"""Packaged defaults (e.g. bundled YAML) for pip installs."""
