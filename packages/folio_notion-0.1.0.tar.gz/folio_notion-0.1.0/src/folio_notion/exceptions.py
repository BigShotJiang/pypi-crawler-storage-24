"""Pipeline errors with step context for clearer failures."""


class PipelineStepError(RuntimeError):
    """Raised when a named pipeline step fails."""

    def __init__(self, step: str, message: str):
        self.step = step
        super().__init__(f"[{step}] {message}")
