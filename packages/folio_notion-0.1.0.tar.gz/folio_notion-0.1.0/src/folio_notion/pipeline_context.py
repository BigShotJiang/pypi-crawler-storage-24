"""Mutable state passed through pipeline steps."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class PipelineContext:
    project_root: Path
    config: dict[str, Any] = field(default_factory=dict)
    pdf_paths: list[Path] = field(default_factory=list)
    cli_pdf_paths: list[Path] = field(default_factory=list)
    notebooklm_storage: Path | None = None
    notion_token: str = ""
    notion_parent_id: str = ""
    synthesis_prompt: str = ""
    run_title: str = ""
    notebooklm_notebook_id: str | None = None
    synthesis_text: str | None = None
    export_file: Path | None = None
    notion_page_url: str | None = None
    # Run modes (CLI / env)
    dry_run: bool = False
    skip_notion: bool = False
    # NotebookLM tuning (from config)
    notebooklm_source_upload_timeout_sec: float = 600.0
    notebooklm_post_upload_wait_sec: float = 0.0
    notebooklm_chat_retries: int = 2
    notebooklm_chat_retry_delay_sec: float = 3.0
    notion_api_max_retries: int = 3
