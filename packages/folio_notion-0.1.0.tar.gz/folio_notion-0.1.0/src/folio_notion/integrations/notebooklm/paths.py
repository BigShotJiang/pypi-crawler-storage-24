"""Paths for NotebookLM auth files (Folio-customized; optional NOTEBOOKLM_HOME compat)."""

from __future__ import annotations

import os
from pathlib import Path


def get_notebooklm_home(create: bool = False) -> Path:
    """
    Base directory for NotebookLM browser profile + storage state.

    Precedence:
    - ``NOTEBOOKLM_HOME`` or ``FOLIO_NOTEBOOKLM_HOME``
    - default: ``~/.folio-notion/notebooklm``
    """
    key = os.environ.get("NOTEBOOKLM_HOME") or os.environ.get("FOLIO_NOTEBOOKLM_HOME")
    if key:
        p = Path(key).expanduser().resolve()
    else:
        p = (Path.home() / ".folio-notion" / "notebooklm").resolve()

    if create:
        p.mkdir(parents=True, exist_ok=True)
        try:
            p.chmod(0o700)
        except NotImplementedError:
            pass

    return p


def get_storage_path() -> Path:
    """``storage_state.json`` for Playwright ``context.storage_state``."""
    override = os.environ.get("FOLIO_NOTEBOOKLM_STORAGE")
    if override:
        return Path(override).expanduser().resolve()
    return get_notebooklm_home() / "storage_state.json"


def get_browser_profile_dir() -> Path:
    """Persistent Chromium user data dir for ``launch_persistent_context``."""
    return get_notebooklm_home() / "browser_profile"
