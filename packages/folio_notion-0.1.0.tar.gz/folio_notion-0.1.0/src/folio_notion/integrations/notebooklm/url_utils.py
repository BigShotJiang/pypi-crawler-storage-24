"""Detect Google account redirects (from notebooklm-py patterns)."""

from __future__ import annotations

import re
from urllib.parse import urlparse


def is_google_auth_redirect(url: str) -> bool:
    try:
        hostname = (urlparse(url).hostname or "").lower()
        return hostname == "accounts.google.com" or hostname.endswith(".accounts.google.com")
    except (AttributeError, TypeError, ValueError):
        return False


def contains_google_auth_redirect(text: str) -> bool:
    url_pattern = r'https?://[^\s"\'<>]+'
    urls = re.findall(url_pattern, text)
    return any(is_google_auth_redirect(url) for url in urls)
