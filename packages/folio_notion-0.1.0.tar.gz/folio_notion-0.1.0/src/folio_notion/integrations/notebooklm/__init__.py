"""NotebookLM: Playwright login bridge + httpx-ready auth (Folio)."""

from folio_notion.integrations.notebooklm.auth import AuthTokens, load_auth_from_storage
from folio_notion.integrations.notebooklm.paths import (
    get_browser_profile_dir,
    get_notebooklm_home,
    get_storage_path,
)

__all__ = [
    "AuthTokens",
    "get_browser_profile_dir",
    "get_notebooklm_home",
    "get_storage_path",
    "interactive_login",
    "load_auth_from_storage",
]


def interactive_login(*args, **kwargs):
    """Lazy import so core deps work without the optional Playwright extra."""
    from folio_notion.integrations.notebooklm.session import interactive_login as _run

    return _run(*args, **kwargs)
