"""Adapters: NotebookLM, Notion API, filesystem — no pipeline sequencing here."""
