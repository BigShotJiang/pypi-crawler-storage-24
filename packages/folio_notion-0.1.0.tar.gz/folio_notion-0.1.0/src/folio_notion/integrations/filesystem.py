"""Path helpers: inbox PDFs, export dir, atomic writes."""


def placeholder() -> None:
    """Remove when real helpers exist."""
    return None
