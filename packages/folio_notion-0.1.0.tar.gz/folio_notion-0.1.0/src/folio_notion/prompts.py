"""TTY prompts with sane line editing (arrow keys); falls back if prompt_toolkit missing."""

from __future__ import annotations

import getpass


def prompt_line(message: str) -> str:
    try:
        from prompt_toolkit import prompt as pt_prompt

        return pt_prompt(message, history=None).strip()
    except ImportError:
        try:
            import readline  # noqa: F401
        except ImportError:
            pass
        return input(message).strip()


def prompt_secret(message: str) -> str:
    try:
        from prompt_toolkit import prompt as pt_prompt

        return pt_prompt(message, is_password=True, history=None).strip()
    except ImportError:
        return getpass.getpass(message).strip()
