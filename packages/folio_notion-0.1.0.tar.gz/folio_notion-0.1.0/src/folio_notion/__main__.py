"""Allow: python -m folio_notion"""

from folio_notion.cli import main

if __name__ == "__main__":
    main()
