"""Central logging setup for CLI and pipeline."""

from __future__ import annotations

import logging
import os


def setup_logging() -> None:
    level_name = (os.environ.get("FOLIO_LOG_LEVEL") or "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)
    logging.basicConfig(
        level=level,
        format="%(levelname)s [%(name)s] %(message)s",
    )
