"""Reserved: chat prompt runs inside the NotebookLM step."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from folio_notion.pipeline_context import PipelineContext


def run(ctx: PipelineContext) -> None:
    return
