"""Pipeline stages — one module per row in the orchestrator table."""
