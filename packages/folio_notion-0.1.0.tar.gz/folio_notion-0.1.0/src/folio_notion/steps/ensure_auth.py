"""Verify Notion token and NotebookLM storage exist."""

from __future__ import annotations

from typing import TYPE_CHECKING

from folio_notion.integrations.notion_api import verify_integration_token

if TYPE_CHECKING:
    from folio_notion.pipeline_context import PipelineContext


def run(ctx: PipelineContext) -> None:
    if not ctx.skip_notion:
        if not ctx.notion_token:
            raise RuntimeError("NOTION_TOKEN missing. Run: fn connect notion")
        verify_integration_token(ctx.notion_token)

        if not ctx.notion_parent_id:
            raise RuntimeError(
                "Notion parent_page_id missing. Set in config or NOTION_PARENT_PAGE_ID."
            )

    st = ctx.notebooklm_storage
    if not st or not st.is_file():
        raise RuntimeError(
            "NotebookLM session missing. Run: fn connect notebooklm"
        )
