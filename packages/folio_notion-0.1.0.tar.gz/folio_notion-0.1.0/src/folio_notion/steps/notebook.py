"""NotebookLM: create/open notebook, upload PDFs, run synthesis chat (notebooklm-py)."""

from __future__ import annotations

import asyncio
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from folio_notion.pipeline_context import PipelineContext


def run(ctx: PipelineContext) -> None:
    from folio_notion.notebooklm_pipeline import run_notebooklm

    if sys.platform == "win32":
        policy = asyncio.WindowsSelectorEventLoopPolicy()
        asyncio.set_event_loop_policy(policy)
    try:
        asyncio.run(run_notebooklm(ctx))
    except RuntimeError as e:
        if "asyncio.run() cannot be called" in str(e):
            raise RuntimeError(
                "NotebookLM step cannot nest asyncio.run(); run `fn run` from a normal shell."
            ) from e
        raise
