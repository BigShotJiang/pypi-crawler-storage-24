"""Orchestrator: configure → ingest → NotebookLM → capture → disk + Notion."""

__version__ = "0.1.0"
