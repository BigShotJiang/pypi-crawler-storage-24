"""NotebookLM auth cookie extraction."""

from folio_notion.integrations.notebooklm.auth import extract_cookies_from_storage


def test_extract_prefers_google_com_sid():
    storage = {
        "cookies": [
            {"name": "SID", "value": "regional", "domain": ".google.com.sg"},
            {"name": "SID", "value": "base", "domain": ".google.com"},
            {"name": "HSID", "value": "x", "domain": ".google.com"},
        ]
    }
    cookies = extract_cookies_from_storage(storage)
    assert cookies["SID"] == "base"


def test_extract_requires_sid():
    storage = {"cookies": [{"name": "OTHER", "value": "z", "domain": ".google.com"}]}
    try:
        extract_cookies_from_storage(storage)
    except ValueError as e:
        assert "SID" in str(e)
    else:
        raise AssertionError("expected ValueError")
