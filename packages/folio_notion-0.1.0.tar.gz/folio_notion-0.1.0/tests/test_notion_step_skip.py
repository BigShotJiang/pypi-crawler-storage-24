"""Notion publish step respects skip_notion (no API, no synthesis required)."""

from __future__ import annotations

from pathlib import Path

from folio_notion.pipeline_context import PipelineContext
from folio_notion.steps.notion import run as notion_run


def test_notion_step_noop_when_skip_notion() -> None:
    ctx = PipelineContext(project_root=Path(__file__).resolve().parents[1])
    ctx.skip_notion = True
    ctx.synthesis_text = None
    notion_run(ctx)
