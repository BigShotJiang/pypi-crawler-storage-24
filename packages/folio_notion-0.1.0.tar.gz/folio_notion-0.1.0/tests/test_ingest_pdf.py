"""PDF discovery: inbox + extra paths + directories."""

from __future__ import annotations

from pathlib import Path

from folio_notion.steps.ingest_pdf import collect_pdf_paths


def test_collect_merges_inbox_and_files(tmp_path: Path) -> None:
    inbox = tmp_path / "inbox"
    inbox.mkdir()
    (inbox / "a.pdf").write_bytes(b"%PDF-1.4")
    extra = tmp_path / "extra.pdf"
    extra.write_bytes(b"%PDF-1.4")

    got = collect_pdf_paths(inbox, [extra])
    assert len(got) == 2
    assert {p.name for p in got} == {"a.pdf", "extra.pdf"}


def test_collect_dir_globs_pdfs(tmp_path: Path) -> None:
    inbox = tmp_path / "inbox"
    inbox.mkdir()
    folder = tmp_path / "docs"
    folder.mkdir()
    (folder / "x.pdf").write_bytes(b"%PDF-1.4")
    (folder / "y.PDF").write_bytes(b"%PDF-1.4")

    got = collect_pdf_paths(inbox, [folder])
    assert {p.name for p in got} == {"x.pdf", "y.PDF"}


def test_collect_dedupes(tmp_path: Path) -> None:
    inbox = tmp_path / "inbox"
    inbox.mkdir()
    f = inbox / "same.pdf"
    f.write_bytes(b"%PDF-1.4")
    got = collect_pdf_paths(inbox, [f])
    assert len(got) == 1
