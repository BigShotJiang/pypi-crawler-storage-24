"""verify_parent_location tries GET /pages then GET /databases when needed."""

from __future__ import annotations

from unittest.mock import patch

from folio_notion.integrations import notion_api


def test_verify_parent_location_database_fallback():
    err = notion_api.NotionAPIError(
        "Provided ID … is a database, not a page.",
        status=400,
    )

    def fake_notion_request(method: str, path: str, token: str, *, body=None):
        assert token == "t"
        if path.startswith("/pages/"):
            raise err
        if path.startswith("/databases/"):
            return {"title": [{"plain_text": "DB Title"}]}
        raise AssertionError(path)

    with patch.object(notion_api, "notion_request", side_effect=fake_notion_request):
        kind, obj = notion_api.verify_parent_location(
            "t",
            "c2bb0c1105d3836cb22f01ffcaa706e0",
        )

    assert kind == "database"
    assert obj["title"][0]["plain_text"] == "DB Title"
