"""NotebookLM / Notion retry settings from YAML reach PipelineContext."""

from __future__ import annotations

from pathlib import Path

from folio_notion.pipeline_context import PipelineContext
from folio_notion.steps.configure import run as configure_run


def test_configure_applies_api_and_notebooklm_tuning(monkeypatch, tmp_path: Path) -> None:
    repo_root = Path(__file__).resolve().parents[1]
    cfg = tmp_path / "folio.yaml"
    cfg.write_text(
        """
notion:
  api_max_retries: 7
notebooklm:
  source_upload_timeout_sec: 99
  post_upload_wait_sec: 1.25
  chat_retries: 5
  chat_retry_delay_sec: 2.5
""",
        encoding="utf-8",
    )
    monkeypatch.setenv("FOLIO_CONFIG", str(cfg))

    ctx = PipelineContext(project_root=repo_root)
    configure_run(ctx)

    assert ctx.notion_api_max_retries == 7
    assert ctx.notebooklm_source_upload_timeout_sec == 99.0
    assert ctx.notebooklm_post_upload_wait_sec == 1.25
    assert ctx.notebooklm_chat_retries == 5
    assert ctx.notebooklm_chat_retry_delay_sec == 2.5
