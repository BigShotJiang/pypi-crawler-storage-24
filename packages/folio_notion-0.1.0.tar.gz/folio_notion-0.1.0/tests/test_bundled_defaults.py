"""Packaged defaults stay aligned with repo template and load without config/."""

from __future__ import annotations

from importlib import resources
from pathlib import Path

from folio_notion.config_load import _bundled_defaults_text, load_config


def test_bundled_file_matches_repo_config_template() -> None:
    repo = Path(__file__).resolve().parents[1]
    root_yaml = (repo / "config" / "defaults.example.yaml").read_text(encoding="utf-8")
    ref = resources.files("folio_notion").joinpath("data/defaults.example.yaml")
    assert ref.read_text(encoding="utf-8") == root_yaml


def test_load_config_uses_bundle_when_no_repo_defaults(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("FOLIO_CONFIG", raising=False)
    cfg = load_config(tmp_path)
    assert "input_dir" in cfg
    assert "prompts" in cfg
    assert _bundled_defaults_text() is not None
