def test_import_package():
    import folio_notion

    assert folio_notion.__version__
