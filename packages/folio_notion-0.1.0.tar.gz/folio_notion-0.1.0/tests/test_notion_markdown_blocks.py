"""Markdown → Notion block payloads (structure only, no API)."""

from __future__ import annotations

from folio_notion.integrations.notion_api import (
    _parse_inline_rich_text,
    body_markdown_to_notion_blocks,
)


def test_inline_bold_and_code() -> None:
    segs = _parse_inline_rich_text("Hello **world** and `code`")
    assert any(s.get("annotations", {}).get("bold") for s in segs)
    assert any(s.get("annotations", {}).get("code") for s in segs)


def test_heading_list_paragraph() -> None:
    md = """### **Overview**

Intro **bold** here.

* **One:** a
* **Two:** b
"""
    blocks = body_markdown_to_notion_blocks(md)
    assert blocks[0]["type"] == "heading_3"
    assert blocks[1]["type"] == "paragraph"
    assert blocks[2]["type"] == "bulleted_list_item"
    assert blocks[3]["type"] == "bulleted_list_item"


def test_numbered_quote_divider() -> None:
    md = """1. First

> Quote line

---
"""
    blocks = body_markdown_to_notion_blocks(md)
    assert blocks[0]["type"] == "numbered_list_item"
    assert blocks[1]["type"] == "quote"
    assert blocks[2]["type"] == "divider"
