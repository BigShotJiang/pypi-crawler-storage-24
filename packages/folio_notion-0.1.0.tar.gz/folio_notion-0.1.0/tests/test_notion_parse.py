"""Tests for Notion page id parsing from pasted URLs."""

from folio_notion.integrations.notion_api import parse_page_id_from_user_input


def test_parse_full_notion_url_with_query():
    url = (
        "https://www.notion.so/c2bb0c1105d3836cb22f01ffcaa706e0"
        "?v=7e4b0c1105d382b8923b8895c5ad1ee8&source=copy_link"
    )
    assert parse_page_id_from_user_input(url) == "c2bb0c11-05d3-836c-b22f-01ffcaa706e0"


def test_parse_dashed_uuid():
    assert (
        parse_page_id_from_user_input("c2bb0c11-05d3-836c-b22f-01ffcaa706e0")
        == "c2bb0c11-05d3-836c-b22f-01ffcaa706e0"
    )


def test_parse_raw_32_hex():
    assert (
        parse_page_id_from_user_input("c2bb0c1105d3836cb22f01ffcaa706e0")
        == "c2bb0c11-05d3-836c-b22f-01ffcaa706e0"
    )
