# Copyright 2026 Aqarios GmbH
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from luna_model._lm import PyChangeSensePass
from luna_model.model.model import Sense
from luna_model.transformation.transform import ConcreteTransformationPass


class ChangeSensePass(ConcreteTransformationPass):
    """Change the optimization sense between minimization and maximization.

    Converts the optimization sense by negating the objective function.

    Parameters
    ----------
    sense : Sense
        The target sense to convert the optimization sense to.


    Examples
    --------
    >>> from luna_model import Model, Vtype, Sense
    >>> from luna_model.transformation import PassManager
    >>> from luna_model.transformation.passes import ChangeSensePass
    >>> model = Model(sense=Sense.MAX)
    >>> x = model.add_variable("x", vtype=Vtype.BINARY)
    >>> y = model.add_variable("y", vtype=Vtype.BINARY)
    >>> model.objective = x * y + x - 2 * y
    >>> pm = PassManager([ChangeSensePass(Sense.MIN)])
    >>> ir = pm.run(model)
    >>> min_model = ir.model
    """

    def __init__(self, sense: Sense) -> None:
        super().__init__(base=PyChangeSensePass(sense._val))

    @property
    def sense(self) -> Sense:
        """Get the target optimization sense."""
        return Sense._from_pysense(self._csp.sense)
