# tibet-ci-audit

**TIBET CI/CD Audit — lightweight validators for pipelines, AI, and B2B.**

This is an alias for [`tibet-ci`](https://pypi.org/project/tibet-ci/). Install either one — they're the same thing.

```bash
pip install tibet-ci-audit
# or
pip install tibet-ci
```

## Quick Start

```bash
# One-liner for CI/CD (exit 0=pass, 1=fail)
tibet-ci-audit audit-line .

# Full project validation (<1ms, no pipeline run)
tibet-ci-audit validate .

# Demo all validators
tibet-ci-audit validate-demo
```

## Python API

```python
from tibet_ci_audit import QuickValidator, AIValidator, B2BValidator

# Project validation
v = QuickValidator()
result = v.validate_project(".")
print(result.badge)  # VALID / WARNING / INVALID

# AI pipeline validation (EU AI Act compliance)
ai = AIValidator()
result = ai.validate_ai_pipeline(steps)

# B2B transaction validation
b2b = B2BValidator()
result = b2b.validate_transaction(tx)
```

## License

MIT — Humotica AI Lab 2025-2026
