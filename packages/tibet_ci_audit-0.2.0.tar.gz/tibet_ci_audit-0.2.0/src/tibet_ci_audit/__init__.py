"""
tibet-ci-audit — Alias for tibet-ci with focus on validation & audit.

This package re-exports everything from tibet-ci.
Install either one — they're the same thing.

    pip install tibet-ci-audit
    # or
    pip install tibet-ci

Usage::

    from tibet_ci_audit import QuickValidator, AIValidator, B2BValidator

    v = QuickValidator()
    result = v.validate_project(".")
    print(result.badge)  # VALID / WARNING / INVALID
"""

from tibet_ci import (
    PipelineRunner,
    PipelineResult,
    StageResult,
    CIProvenance,
    CIToken,
    ProjectInfo,
    detect_project,
    QuickValidator,
    AIValidator,
    B2BValidator,
    ValidationResult,
)

__version__ = "0.2.0"

__all__ = [
    "PipelineRunner",
    "PipelineResult",
    "StageResult",
    "CIProvenance",
    "CIToken",
    "ProjectInfo",
    "detect_project",
    "QuickValidator",
    "AIValidator",
    "B2BValidator",
    "ValidationResult",
]
