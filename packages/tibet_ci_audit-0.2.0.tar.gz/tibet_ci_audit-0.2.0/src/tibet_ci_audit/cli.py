"""tibet-ci-audit CLI — delegates to tibet-ci."""

from tibet_ci.cli import main

if __name__ == "__main__":
    main()
