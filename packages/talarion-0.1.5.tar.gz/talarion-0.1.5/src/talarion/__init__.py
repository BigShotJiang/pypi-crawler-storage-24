"""Talarion SDK -- Python client for the Talarion prediction market API."""

from talarion.client import TalarionClient
from talarion.exceptions import (
    AuthenticationError,
    ConflictError,
    NotFoundError,
    QuoteProcessingError,
    ServerError,
    TalarionError,
    ValidationError,
)
from talarion.models import (
    CancelResult,
    Instrument,
    OperationResult,
    OperationSequence,
    Quote,
    RelayResult,
    SafeOperation,
    Settlement,
    SubmitResult,
    Trade,
    UserPnl,
)

__all__ = [
    # Client
    "TalarionClient",
    # Models
    "CancelResult",
    "Instrument",
    "OperationResult",
    "OperationSequence",
    "Quote",
    "RelayResult",
    "SafeOperation",
    "Settlement",
    "SubmitResult",
    "Trade",
    "UserPnl",
    # Exceptions
    "AuthenticationError",
    "ConflictError",
    "NotFoundError",
    "QuoteProcessingError",
    "ServerError",
    "TalarionError",
    "ValidationError",
]

from importlib.metadata import version as _v

__version__ = _v("talarion")
