"""Internal constants: minimal Escrow ABI for EOA transaction building."""

from __future__ import annotations

DEFAULT_BASE_URL = "https://api.talarion.tech"

ZERO_ADDRESS = "0x" + "00" * 20

MAX_UINT256 = 2**256 - 1

ESCROW_ADDRESS = "0x49B26609F59697E249092bD39846C0EC6FE2985F"

POLYGON_USDC_ADDRESS = "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"

# Minimal ERC-20 ABI (approve only)
ERC20_APPROVE_ABI: list[dict] = [
    {
        "type": "function",
        "name": "approve",
        "inputs": [
            {"name": "spender", "type": "address", "internalType": "address"},
            {"name": "amount", "type": "uint256", "internalType": "uint256"},
        ],
        "outputs": [{"name": "", "type": "bool", "internalType": "bool"}],
        "stateMutability": "nonpayable",
    },
]

# Minimal Escrow ABI — only the functions needed for EOA interaction
ESCROW_ABI: list[dict] = [
    {
        "type": "function",
        "name": "createTrade",
        "inputs": [
            {
                "name": "args",
                "type": "tuple",
                "internalType": "struct Escrow.TradeCreationArgs",
                "components": [
                    {"name": "instrumentId", "type": "bytes32", "internalType": "bytes32"},
                    {"name": "size", "type": "uint256", "internalType": "uint256"},
                    {"name": "price", "type": "uint256", "internalType": "uint256"},
                    {"name": "buyer", "type": "address", "internalType": "address"},
                    {"name": "seller", "type": "address", "internalType": "address"},
                    {"name": "salt", "type": "bytes32", "internalType": "bytes32"},
                ],
            },
            {"name": "funder", "type": "address", "internalType": "address"},
        ],
        "outputs": [],
        "stateMutability": "nonpayable",
    },
    {
        "type": "function",
        "name": "cancelPendingTrade",
        "inputs": [
            {"name": "tradeId", "type": "bytes32", "internalType": "bytes32"},
            {"name": "funder", "type": "address", "internalType": "address"},
        ],
        "outputs": [],
        "stateMutability": "nonpayable",
    },
]
