## Financial Plots
