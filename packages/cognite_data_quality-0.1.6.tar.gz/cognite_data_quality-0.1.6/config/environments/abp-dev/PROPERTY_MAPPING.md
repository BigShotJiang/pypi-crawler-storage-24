# Property Mapping: NORSOK Standards to CDF Data Model

**Environment:** abp-dev
**Date:** 2026-02-17
**Purpose:** Map NORSOK Z-DP-002 standard terminology to CDF data model property names

---

## Tag / Equipment Properties

### NORSOK Z-DP-002 Section 6: TAG CODING

| NORSOK Standard Term | Data Model Property | Data Type | SHACL Path | Validated In | Notes |
|---------------------|-------------------|-----------|------------|--------------|-------|
| **Tag Code / Equipment ID** | `dm:name` | xsd:string | `dm:name` | tag_shacl_rules.ttl | Format: `NN-AA-NNNN` (System-FunctionType-Sequence) |
| **Equipment Description** | `dm:description` | xsd:string | `dm:description` | tag_shacl_rules.ttl | Human-readable description |
| **System (NN)** | `dm:system` | xsd:string | `dm:system` | tag_shacl_rules.ttl | 2-digit code (01-99) |
| **Function and Type Code (AA)** | `dm:functionCode` | xsd:string | `dm:functionCode` | tag_shacl_rules.ttl | Codes from Annex B.1 (PA, PB, KA, DE, etc.) |
| **Function Code Description** | `dm:functionCodeDesc` | xsd:string | `dm:functionCodeDesc` | tag_shacl_rules.ttl | Human-readable function description |
| **Sequence Number (NNNN)** | _(Extracted from name)_ | - | - | - | Part of tag name, not separate property |
| **Parallel Item (A)** | _(Extracted from name)_ | - | - | - | Optional suffix in tag name |
| **Discipline Code** | `dm:tagDiscipline` | xsd:string | `dm:tagDiscipline` | tag_shacl_rules.ttl | From Annex C (Mechanical, Electrical, etc.) |
| **Installation Date** | `dm:dateInstalled` | xsd:string | `dm:dateInstalled` | tag_shacl_rules.ttl | Currently string, can be empty |
| **ISO 14224 Equipment Class** | `dm:ISOEquipmentClass` | Relation | `dm:ISOEquipmentClass` | tag_shacl_rules.ttl | Reference to EquipmentClass instance |
| **ISO 14224 Equipment Type** | `dm:ISOEquipmentType` | Relation | `dm:ISOEquipmentType` | tag_shacl_rules.ttl | Reference to EquipmentType instance |

### Equipment-Specific Properties

| NORSOK Standard Term | Data Model Property | Data Type | Entity Type | Notes |
|---------------------|-------------------|-----------|-------------|-------|
| **Pump Design Capacity** | `dm:designCapacity` | xsd:float | Pump | Not yet validated (property TBC) |
| **Pump Type** | `dm:pumpType` | xsd:string | Pump | Not yet in model (future enhancement) |
| **Motor Rated Voltage** | `dm:ratedVoltage` | xsd:float | ElectricMotor | Not yet validated (property TBC) |
| **Compressor Type** | `dm:compressorType` | xsd:string | Compressor | Not yet in model (future enhancement) |
| **Heat Exchanger Design Capacity** | `dm:designCapacity` | xsd:float | HeatExchanger | Validated with sh:Warning |
| **Heat Exchanger Design Pressure** | `dm:designPressureMax` | xsd:float | HeatExchanger | Validated with sh:Warning |

---

## Document Properties

### NORSOK Z-DP-002 Section 5: DOCUMENT CODING

| NORSOK Standard Term | Data Model Property | Data Type | SHACL Path | Validated In | Notes |
|---------------------|-------------------|-----------|------------|--------------|-------|
| **Document Identification Code** | `dm:name` | xsd:string | `dm:name` | document_shacl_rules.ttl | Format: `ZZZZ-ZZZZZ-A-NNNN` |
| **Project/Facility Code (ZZZZ)** | _(Extracted from name)_ | - | - | - | First part of document ID (1-4 chars) |
| **Originator Code (ZZZZZ)** | _(Extracted from name)_ | - | - | - | Second part of document ID (1-5 chars) |
| **Discipline Code (A)** | `dm:discipline` | xsd:string | `dm:discipline` | document_shacl_rules.ttl | Single letter from Annex C |
| **Sequential Number (NNNN)** | _(Extracted from name)_ | - | - | - | Fourth part of document ID (4 digits) |
| **Document Type Code** | `dm:documentType` | xsd:string | `dm:documentType` | document_shacl_rules.ttl | 2-letter code from Annex D (AA, CA, XB, etc.) |
| **Title** | `dm:description` | xsd:string | `dm:description` | document_shacl_rules.ttl | Max 80 characters per NORSOK |
| **Source ID** | `dm:sourceId` | xsd:string | `dm:sourceId` | document_shacl_rules.ttl | Identifier from source system |
| **System** | `dm:system` | xsd:string | `dm:system` | _(Not yet validated)_ | 2-digit code, mandatory per NORSOK 5.3 |
| **Subsystem** | `dm:subsystem` | xsd:string | `dm:subsystem` | _(Not yet validated)_ | Subsystem code, mandatory per NORSOK 5.3 |
| **Area** | `dm:area` | xsd:string | `dm:area` | _(Not yet validated)_ | Area code from Annex E, mandatory per NORSOK 5.3 |
| **Responsible Party Code** | `dm:responsibleParty` | xsd:string | `dm:responsibleParty` | _(Not yet validated)_ | Organization responsible (informative attribute) |
| **Revision Code** | `dm:revisionCode` | xsd:string | `dm:revisionCode` | _(Not yet validated)_ | Sequential number NN (starts at 01, informative) |

---

## ISO 14224 Taxonomy Properties

### Equipment Classification

| ISO 14224 Term | Data Model Property | Data Type | SHACL Path | Validated In | Notes |
|----------------|-------------------|-----------|------------|--------------|-------|
| **Equipment Class Code** | `dm:code` | xsd:string | `dm:code` | equipmentclass_shacl_rules.ttl | 2-letter code from Table A.4 (PU, CO, EM, etc.) |
| **Equipment Class Name** | `dm:name` | xsd:string | `dm:name` | equipmentclass_shacl_rules.ttl | Human-readable name (e.g., "Pumps") |
| **Equipment Class Standard** | `dm:standard` | xsd:string | `dm:standard` | equipmentclass_shacl_rules.ttl | Should be "ISO14224" or variant |
| **Equipment Class Description** | `dm:description` | xsd:string | `dm:description` | equipmentclass_shacl_rules.ttl | Optional description (sh:Warning) |

### Equipment Type

| ISO 14224 Term | Data Model Property | Data Type | SHACL Path | Validated In | Notes |
|----------------|-------------------|-----------|------------|--------------|-------|
| **Equipment Type Code** | `dm:code` | xsd:string | `dm:code` | equipmenttype_shacl_rules.ttl | 2-letter code from Tables A.7-A.15 (CE, RE, SC, etc.) |
| **Equipment Type Name** | `dm:name` | xsd:string | `dm:name` | equipmenttype_shacl_rules.ttl | Human-readable name (e.g., "Centrifugal") |
| **Equipment Type Standard** | `dm:standard` | xsd:string | `dm:standard` | equipmenttype_shacl_rules.ttl | Should be "ISO14224" or variant |
| **Equipment Class Reference** | `dm:equipmentClass` | Relation | `dm:equipmentClass` | equipmenttype_shacl_rules.ttl | Reference to EquipmentClass instance |
| **Standard Reference** | `dm:standardReference` | xsd:string | `dm:standardReference` | equipmenttype_shacl_rules.ttl | Reference to standard document (optional) |

---

## Validation Rule Mapping

### Tag Name Format Validation

**NORSOK Format:** `NN-AA-NNNN` (System-FunctionType-Sequence)
**Data Model Property:** `dm:name`
**SHACL Pattern:** `^[0-9]{2}-[A-Z0-9]{1,10}-[0-9]{4}$`
**Example Values:**
- Valid: `11-PA-9102` (System 11, Centrifugal Pump, Sequence 9102)
- Valid: `27-KA-0035` (System 27, Centrifugal Compressor, Sequence 0035)
- Invalid: `1-PA-102` (System must be 2 digits)
- Invalid: `11-PA-102` (Sequence must be 4 digits)

### Document Name Format Validation

**NORSOK Format:** `ZZZZ-ZZZZZ-A-NNNN` (Project-Originator-Discipline-Sequence)
**Data Model Property:** `dm:name`
**SHACL Pattern:** `^[A-Z0-9]{1,4}-[A-Z0-9]{1,5}-[A-Z]-[0-9]{4}$`
**Example Values:**
- Valid: `S5-10696-P-0001` (Saga Petroleum, Aker Engineering, Process, doc #1)
- Valid: `C010-KE-I-0001` (Phillips, Kværner, Instrumentation, doc #1)
- Invalid: `S5-10696-Process-0001` (Discipline must be 1 letter)
- Invalid: `S5-10696-P-1` (Sequence must be 4 digits)

---

## Discipline Code Mapping

### NORSOK Annex C: Single-Letter to Full Name

Both Tags and Documents use discipline codes from NORSOK Annex C:

| Single Letter (in code) | Full Name (in data model) | SHACL Value | Used In |
|------------------------|---------------------------|-------------|---------|
| **A** | Administration | `"Administration"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |
| **C** | Civil/Architectural | `"Civil"` or `"Architectural"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |
| **E** | Electrical | `"Electrical"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |
| **H** | HVAC | `"HVAC"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |
| **I** | Instrumentation/Metering | `"Instrumentation"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |
| **L** | Piping/Layout | `"Piping"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |
| **P** | Process | `"Process"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |
| **R** | Mechanical (Rotating) | `"Mechanical"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |
| **T** | Telecommunication | `"Telecommunication"` | Tag `dm:tagDiscipline`, Document `dm:discipline` |

**Note:** The data model uses full names, not single letters. The single letters appear only in identification codes (tag names, document names).

---

## Function Code Mapping Examples

### NORSOK Annex B.1: Equipment Function Codes

| NORSOK Code | Full Description | SHACL Value | Data Model Property | Equipment Type |
|-------------|------------------|-------------|-------------------|----------------|
| **PA** | Centrifugal Pumps | `"PA"` | `dm:functionCode` | Pump |
| **PB** | Reciprocating Pumps | `"PB"` | `dm:functionCode` | Pump |
| **KA** | Centrifugal Compressors | `"KA"` | `dm:functionCode` | Compressor |
| **KB** | Reciprocating Compressors | `"KB"` | `dm:functionCode` | Compressor |
| **DE** | Electrical Motors | `"DE"` | `dm:functionCode` | ElectricMotor |
| **HA** | Shell and Tube Heat Exchangers | `"HA"` | `dm:functionCode` | HeatExchanger |
| **HB** | Plate Heat Exchangers | `"HB"` | `dm:functionCode` | HeatExchanger |

The data model stores these as 2-letter codes (not expanded descriptions).

---

## Document Type Code Mapping Examples

### NORSOK Annex D: Document Type Codes

| NORSOK Code | Full Description | SHACL Value | Data Model Property | Category |
|-------------|------------------|-------------|-------------------|----------|
| **XB** | Pipe and instrument diagram (P&ID) | `"XB"` | `dm:documentType` | Drawing |
| **XN** | Isometric drawings | `"XN"` | `dm:documentType` | Drawing |
| **DS** | Data sheets | `"DS"` | `dm:documentType` | Data |
| **MA** | Equipment user manual | `"MA"` | `dm:documentType` | Manual |
| **PA** | Purchase orders | `"PA"` | `dm:documentType` | Procurement |
| **RA** | Reports | `"RA"` | `dm:documentType` | Report |

The data model stores these as 2-letter codes (not expanded descriptions).

---

## Cross-Reference Validation

### Tag → EquipmentClass and EquipmentType

**NORSOK/ISO 14224 Requirement:** Tags must reference valid equipment classification

| Tag Property | References | Validation Rule | SHACL Constraint |
|--------------|-----------|----------------|------------------|
| `dm:ISOEquipmentClass` | → EquipmentClass instance | Must exist and be valid | `sh:node eq_class:EquipmentClassShape` + `sh:minCount 1` |
| `dm:ISOEquipmentType` | → EquipmentType instance | Must exist and be valid | `sh:node eq_type:EquipmentTypeShape` + `sh:minCount 1` |
| _Consistency_ | Both references | EquipmentType.equipmentClass must match Tag.ISOEquipmentClass | SPARQL constraint in ISO-003 |

**Example:**
```
Tag "11-PA-9102"
├── dm:ISOEquipmentClass → EquipmentClass{code: "PU", name: "Pumps"}
└── dm:ISOEquipmentType → EquipmentType{code: "CE", name: "Centrifugal", equipmentClass: → same "PU" instance}
```

### EquipmentType → EquipmentClass

**ISO 14224 Requirement:** Equipment types must belong to a valid equipment class

| EquipmentType Property | References | Validation Rule |
|----------------------|-----------|----------------|
| `dm:equipmentClass` | → EquipmentClass instance | Must exist and be valid |
| `dm:standard` | String value | Should match EquipmentClass.standard |

---

## Property Existence in Data Model

### Currently Implemented and Validated

✅ **Tag/Equipment:**
- `dm:name` - Tag identification code
- `dm:description` - Tag description
- `dm:system` - System code (2 digits)
- `dm:functionCode` - Equipment function code
- `dm:functionCodeDesc` - Function code description
- `dm:tagDiscipline` - Discipline code
- `dm:dateInstalled` - Installation date
- `dm:ISOEquipmentClass` - Reference to EquipmentClass
- `dm:ISOEquipmentType` - Reference to EquipmentType

✅ **Document:**
- `dm:name` - Document identification code
- `dm:description` - Document title
- `dm:sourceId` - Source system identifier
- `dm:documentType` - Document type code (from Annex D)
- `dm:discipline` - Document discipline code

✅ **EquipmentClass:**
- `dm:code` - Equipment class code
- `dm:name` - Equipment class name
- `dm:standard` - Standard identifier
- `dm:description` - Description (optional)

✅ **EquipmentType:**
- `dm:code` - Equipment type code
- `dm:name` - Equipment type name
- `dm:standard` - Standard identifier
- `dm:equipmentClass` - Reference to EquipmentClass
- `dm:standardReference` - Standard document reference (optional)

### Not Yet in Data Model (Future Enhancement)

❌ **Tag/Equipment (future):**
- `dm:subsystem` - Subsystem code
- `dm:area` - Area code
- `dm:facility` - Facility code
- `dm:plantCode` - Plant identification
- `dm:installationCode` - Installation code
- `dm:pumpType` - Pump type classification
- `dm:compressorType` - Compressor type classification
- `dm:manufacturerName` - Equipment manufacturer
- `dm:serialNumber` - Equipment serial number

❌ **Document (future):**
- `dm:system` - System code (mandatory per NORSOK 5.3)
- `dm:subsystem` - Subsystem code (mandatory per NORSOK 5.3)
- `dm:area` - Area code (mandatory per NORSOK 5.3)
- `dm:responsibleParty` - Responsible organization
- `dm:revisionCode` - Revision number

---

## Summary: Property Usage by Entity

### Tag (Base Interface)
- **Identification:** `dm:name` (tag code format)
- **Classification:** `dm:functionCode`, `dm:tagDiscipline`, `dm:system`
- **Description:** `dm:description`, `dm:functionCodeDesc`
- **ISO 14224:** `dm:ISOEquipmentClass`, `dm:ISOEquipmentType`
- **Operational:** `dm:dateInstalled`

### Equipment Types (Pump, Compressor, ElectricMotor, HeatExchanger)
- **Inherit all Tag properties**
- **Additional discipline constraints** via SPARQL (must match equipment type)

### Document
- **Identification:** `dm:name` (document code format)
- **Classification:** `dm:documentType`, `dm:discipline`
- **Description:** `dm:description` (title, max 80 chars)
- **Source:** `dm:sourceId`

### EquipmentClass
- **Identification:** `dm:code`, `dm:name`
- **Standard:** `dm:standard`
- **Description:** `dm:description` (optional)

### EquipmentType
- **Identification:** `dm:code`, `dm:name`
- **Standard:** `dm:standard`, `dm:standardReference` (optional)
- **Classification:** `dm:equipmentClass` (reference)

---

**Last Updated:** 2026-02-17
**Data Model Version:** sp_yggdrasil-twin-commissioning-types v6
**NORSOK Standard:** Z-DP-002 Rev.3 October 1996
**ISO Standard:** 14224:2016
