

### Fixed

- `FunctionSchedule.get_input_data()` used instead of non-existent `.data` attribute in orchestrator monitor mode cleanup, which caused monitor mode to silently fail when checking whether to delete a stale schedule after orchestration completes
- `passedValidation=True` when there are no Violation-severity failures (only Warning/Info)
- Bumps `cognite-data-quality` to `==0.1.6` in function requirements