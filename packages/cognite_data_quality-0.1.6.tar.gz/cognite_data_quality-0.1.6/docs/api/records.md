# Records

::: cognite_data_quality._records
