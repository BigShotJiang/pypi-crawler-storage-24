# invoke

::: cognite_data_quality.invoke
