# Config

::: cognite_data_quality._config
