# Runner

::: cognite_data_quality.runner
