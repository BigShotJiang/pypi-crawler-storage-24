# Installation

## Local / Notebook / Script (Python 3.10+)

From PyPI:

```bash
pip install cognite-data-quality
```

In a notebook:

```python
%pip install cognite-data-quality
```

After install, **restart the kernel or interpreter** so imports pick up the package. SHACL validation code is inlined in the package — no external dependencies required.

## Local wheel (recommended for testing)

When you need to test unreleased or local changes:

```bash
cd data-quality-validation
uv build
pip install dist/cognite_data_quality-0.0.0-py3-none-any.whl
```

Then restart the kernel. The version in the wheel name may differ; use the file that `uv build` produces.

## Editable install (active development)

To iterate on the package without rebuilding a wheel:

```bash
pip install -e ./data-quality-validation
```

Code changes are picked up on next import; you may still need to restart the kernel after editing.

## Embedded function code

Function handler code is **embedded in the package**. There is no separate `function/` directory or `function_source_root` parameter. When you deploy with `deploy_validation_infrastructure()`, the function zip is built from `cognite_data_quality._function_code` automatically. You do not need to clone or copy handler code elsewhere.

To confirm embedded files are present:

```python
from cognite_data_quality.deploy import _get_embedded_function_files

embedded = _get_embedded_function_files()
print(f"Embedded function files: {len(embedded)}")
```

## Cognite Function (deployed in CDF)

When the validation runs inside a Cognite Function, dependencies are declared in the function’s `requirements.txt` (folder deploy) or via `[requirements]` tags in the handler (function_handle deploy). The deployment process that uses `deploy_validation_infrastructure()` builds the function bundle from the package and includes the correct dependencies.

If you deploy a custom function that uses this package, list it in requirements:

```text
cognite-data-quality
```

See [Deploy](usage/deploy.md) for full deployment examples and [Runtime options](usage/runtime_options.md) for usage contexts.
