from __future__ import annotations

from pathlib import Path

from cognite_data_quality.deploy import extract_target_views_from_shacl


def test_extract_target_views_from_shacl_sailboat() -> None:
    """Extract target views from sailboat SHACL rules."""
    path = Path(__file__).parent.parent / "config/environments/cog-sail/shacl_rules/sailboat_data_quality_rules.ttl"
    if not path.exists():
        return
    views = extract_target_views_from_shacl(path)
    assert "SmallBoat" in views
    assert "LargeBoat" in views
    assert "NMEATimeSeries" in views
    assert "PGN" in views
    assert "NavigationAid" in views


def test_extract_target_views_from_shacl_missing_file() -> None:
    """Missing file returns empty set."""
    views = extract_target_views_from_shacl("/nonexistent/path.ttl")
    assert views == set()
