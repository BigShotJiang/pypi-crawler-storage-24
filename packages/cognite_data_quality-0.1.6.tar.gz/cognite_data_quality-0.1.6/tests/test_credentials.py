from __future__ import annotations

from pathlib import Path

import pytest
from cognite_data_quality._credentials import load_cognite_client_from_toml


def test_load_cognite_client_from_toml(tmp_path: Path) -> None:
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        '[cognite]\nproject = "proj"\ntenant_id = "tenant"\ncdf_cluster = "api"\nclient_id = "id"\nclient_secret = "secret"\nlogin_flow = "client_credentials"',  # noqa: E501
        encoding="utf-8",
    )

    client = load_cognite_client_from_toml(toml_file)
    assert client.config.project == "proj"


def test_load_cognite_client_missing_file(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        load_cognite_client_from_toml(tmp_path / "missing.toml")


def test_load_cognite_client_missing_section(tmp_path: Path) -> None:
    toml_file = tmp_path / "config.toml"
    toml_file.write_text('project = "proj"', encoding="utf-8")
    with pytest.raises(KeyError):
        load_cognite_client_from_toml(toml_file)
