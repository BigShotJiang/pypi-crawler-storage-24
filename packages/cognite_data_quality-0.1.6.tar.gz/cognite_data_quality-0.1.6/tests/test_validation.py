from __future__ import annotations

from typing import Any

from cognite_data_quality._config import DataModelConfig
from cognite_data_quality._records import RecordsConfig
from cognite_data_quality._validation import validate_instances


class _FakeNode:
    space = "sp"
    external_id = "inst1"

    def dump(self) -> dict[str, Any]:
        return {"space": self.space, "externalId": self.external_id, "properties": {}}


class _FakeInstancesList(list):
    def __init__(self) -> None:
        super().__init__([_FakeNode()])


class _FakeInstancesAPI:
    def list(self, **kwargs: Any) -> _FakeInstancesList:
        return _FakeInstancesList()


class _FakeDataModeling:
    instances = _FakeInstancesAPI()


class _FakeClient:
    data_modeling = _FakeDataModeling()


class _FakeValidateInstances:
    def with_shacl(self, **_kwargs: Any) -> Any:
        class Result:
            conforms = True
            report_graph = ""
            report_text = "ok"
            instance_count = 1

        return Result()


class _FakeNeatSession:
    def __init__(self, _client: object, verbose: bool = False) -> None:
        self.validate_instances = _FakeValidateInstances()


def test_validate_instances_builds_records(monkeypatch) -> None:
    monkeypatch.setattr("cognite_data_quality._validation.NeatSession", _FakeNeatSession)

    result = validate_instances(
        client=_FakeClient(),
        shacl_rules="@prefix sh: <http://www.w3.org/ns/shacl#> .",
        datamodel=DataModelConfig(space="sp", external_id="Model", version="v1"),
        instance_space="sp",
        records_config=RecordsConfig(rule_set_id="Set", rule_set_version="1.0"),
    )

    assert result.conforms is True
    assert result.instance_count == 1
