"""
CDF SPARQL Functions for SHACL Validation.

This package provides custom SPARQL functions that can be used in SHACL
validation rules to access CDF data and perform data quality analysis.

Two namespaces are supported:
- cdf_sdk: Functions wrapping the Cognite Python SDK (datapoints, aggregates, etc.)
- cdf_indsl: Functions wrapping INDSL data quality algorithms (optional)
"""

from ._helpers import (
    DataFetchConfig,
    create_datapoints_fetcher,
    get_fetch_config,
    get_new_cursor,
    get_timeseries_datapoints,
    literal_to_python,
    parse_instance_id_from_uri,
    safe_sparql_wrapper,
    set_fetch_config,
    verify_timeseries_exists,
)
from ._indsl_wrappers import (
    create_indsl_wrappers,
    get_indsl_import_error,
    is_indsl_available,
)
from ._registry import (
    CDF_INDSL_NS,
    CDF_SDK_NS,
    get_registered_functions,
    register_cdf_sparql_functions,
    unregister_cdf_sparql_functions,
)
from ._sdk_wrappers import create_sdk_wrappers

__all__ = [
    "CDF_INDSL_NS",
    "CDF_SDK_NS",
    "DataFetchConfig",
    "create_datapoints_fetcher",
    "create_indsl_wrappers",
    "create_sdk_wrappers",
    "get_fetch_config",
    "get_indsl_import_error",
    "get_new_cursor",
    "get_registered_functions",
    "get_timeseries_datapoints",
    "is_indsl_available",
    "literal_to_python",
    "parse_instance_id_from_uri",
    "register_cdf_sparql_functions",
    "safe_sparql_wrapper",
    "set_fetch_config",
    "unregister_cdf_sparql_functions",
    "verify_timeseries_exists",
]
