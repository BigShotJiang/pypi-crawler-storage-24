from abc import abstractmethod
from collections.abc import Iterable

from cognite_data_quality._neat._shared import Triple


class BaseExtractor:
    @abstractmethod
    def extract(self) -> Iterable[Triple]:
        raise NotImplementedError()
