from cognite.client import CogniteClient

from ._client import NeatClient
from ._constants import get_raw_namespace
from ._validate_instances import ValidateInstancesAPI


class NeatSession:
    def __init__(self, client: CogniteClient, verbose: bool = True) -> None:
        neat_client = NeatClient(client)
        self.validate_instances = ValidateInstancesAPI(neat_client)


__all__ = [
    "NeatSession",
    "get_raw_namespace",
]
