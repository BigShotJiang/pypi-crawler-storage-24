"""
SHACL utilities for loading rules and running validation.
"""


def load_shacl_from_file(client, external_id: str) -> str:
    """
    Load SHACL rules from a CDF File by external ID.

    Args:
        client: Cognite client instance
        external_id: External ID of the file containing SHACL rules

    Returns:
        SHACL rules as a string
    """
    file_bytes = client.files.download_bytes(external_id=external_id)
    return file_bytes.decode("utf-8")
