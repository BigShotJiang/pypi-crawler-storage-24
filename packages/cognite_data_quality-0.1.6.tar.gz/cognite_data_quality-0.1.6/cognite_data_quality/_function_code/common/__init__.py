"""Common utilities shared across validation handlers."""
