import batou.component
import batou_ext.nix
from batou.lib.file import File
from risclog.batou import resource_filename


@batou_ext.nix.rebuild
class DisableNSCD(batou.component.Component):
    """Disable NSCD to fix DNS resolution problems."""

    def configure(self):
        self += File(
            '/etc/local/nixos/disablenscd.nix',
            source=resource_filename(
                'risclog.batou', 'resources/disablenscd.nix'
            ),
        )
