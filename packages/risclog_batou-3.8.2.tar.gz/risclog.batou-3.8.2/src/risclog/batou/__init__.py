"""Top-level package for risclog.batou."""

from importlib.resources import files


def resource_filename(package, resource_path):
    """Get the filename of a package resource.

    Args:
        package: Package name (e.g., 'risclog.batou')
        resource_path: Path to resource relative to package
                       (e.g., 'resources/file.txt')

    Returns:
        Path to the resource file as a string
    """
    parts = resource_path.split('/')
    resource = files(package)
    for part in parts:
        resource = resource / part
    return str(resource)
