import os
import logging
from mysql.connector.pooling import MySQLConnectionPool
import mysql.connector

logger = logging.getLogger(__name__)

_pool = None

def get_pool():
    global _pool
    if _pool is None:
        
        host = os.getenv("RCM_DB_HOST")
        user = os.getenv("RCM_DB_USER")
        password = os.getenv("RCM_DB_PASSWORD")
        database = os.getenv("RCM_DB_NAME")
        
        if not all([host, user, database]):
            logger.error("Missing critical database environment variables. Required: RCM_DB_HOST, RCM_DB_USER, RCM_DB_NAME")
            
        try:
            _pool = MySQLConnectionPool(
                pool_name="rcm_pool",
                pool_size=5,
                host=host,
                user=user,
                password=password,
                database=database,
            )
            logger.info("MySQL Connection Pool initialized successfully.")
        except mysql.connector.Error as err:
            logger.critical(f"Failed to initialize database pool: {err}", exc_info=True)
            raise
            
    return _pool

def get_connection():
    try:
        return get_pool().get_connection()
    except mysql.connector.Error as err:
        logger.error(f"Failed to acquire connection from pool: {err}", exc_info=True)
        raise