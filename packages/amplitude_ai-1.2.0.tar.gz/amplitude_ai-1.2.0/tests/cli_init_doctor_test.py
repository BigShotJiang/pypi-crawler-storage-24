from __future__ import annotations

from pathlib import Path

import pytest

from amplitude_ai.cli.doctor import run_doctor


def test_run_doctor_reports_missing_api_key(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("AMPLITUDE_AI_API_KEY", raising=False)
    result = run_doctor(tmp_path)
    assert result["ok"] is False
    assert any(check["name"] == "env.AMPLITUDE_AI_API_KEY" for check in result["checks"])
    assert any(
        check["name"] == "mock_event_delivery" and check["ok"] is True
        for check in result["checks"]
    )
    assert any(
        check["name"] == "mock_flush_path" and check["ok"] is True
        for check in result["checks"]
    )


def test_run_doctor_can_skip_mock_check(tmp_path: Path) -> None:
    result = run_doctor(tmp_path, include_mock_check=False)
    assert not any(check["name"] == "mock_event_delivery" for check in result["checks"])
    assert not any(check["name"] == "mock_flush_path" for check in result["checks"])
