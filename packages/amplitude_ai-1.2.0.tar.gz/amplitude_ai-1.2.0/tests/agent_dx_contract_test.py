from __future__ import annotations

from pathlib import Path
import subprocess
import sys

from amplitude_ai.mcp.contract import GENERATED_FILES, MCP_PROMPTS, MCP_RESOURCES, MCP_TOOLS

PACKAGE_ROOT = Path(__file__).resolve().parent.parent

CANONICAL_PROVIDERS = ["OpenAI", "Anthropic", "Gemini", "AzureOpenAI", "Bedrock", "Mistral"]

MUST_DOCUMENT_APIS = [
    "AmplitudeAI",
    "patch",
    "unpatch",
    "wrap",
    "tool",
    "observe",
    "MockAmplitudeAI",
    *CANONICAL_PROVIDERS,
]


def test_mcp_contract_names_are_stable() -> None:
    assert MCP_TOOLS == {
        "get_event_schema": "get_event_schema",
        "get_integration_pattern": "get_integration_pattern",
        "validate_setup": "validate_setup",
        "suggest_instrumentation": "suggest_instrumentation",
        "validate_file": "validate_file",
        "search_docs": "search_docs",
        "scan_project": "scan_project",
        "generate_verify_test": "generate_verify_test",
        "instrument_file": "instrument_file",
    }
    assert MCP_PROMPTS["instrument_app"] == "instrument_app"
    assert MCP_RESOURCES["event_schema"] == "amplitude-ai://event-schema"
    assert MCP_RESOURCES["integration_patterns"] == "amplitude-ai://integration-patterns"
    assert GENERATED_FILES["agents"] == "AGENTS.md"
    assert GENERATED_FILES["llms"] == "llms.txt"
    assert GENERATED_FILES["llms_full"] == "llms-full.txt"
    assert GENERATED_FILES["mcp_schema"] == "mcp.schema.json"


def test_readme_mentions_all_canonical_providers() -> None:
    readme = (PACKAGE_ROOT / "README.md").read_text(encoding="utf-8")
    readme_lower = readme.lower()
    missing = [p for p in CANONICAL_PROVIDERS if p.lower() not in readme_lower]
    assert missing == [], f"README.md missing providers: {missing}"


def test_llms_full_mentions_all_canonical_providers() -> None:
    llms_full = (PACKAGE_ROOT / "llms-full.txt").read_text(encoding="utf-8")
    llms_lower = llms_full.lower()
    missing = [p for p in CANONICAL_PROVIDERS if p.lower() not in llms_lower]
    assert missing == [], f"llms-full.txt missing providers: {missing}"


def test_llms_full_mentions_key_public_api_exports() -> None:
    llms_full = (PACKAGE_ROOT / "llms-full.txt").read_text(encoding="utf-8")
    missing = [api for api in MUST_DOCUMENT_APIS if api not in llms_full]
    assert missing == [], f"llms-full.txt missing API docs for: {missing}"


def test_generated_docs_check_passes() -> None:
    package_root = Path(__file__).resolve().parent.parent
    script_path = package_root / "scripts" / "generate_agent_docs.py"
    result = subprocess.run(
        [sys.executable, str(script_path), "--check"],
        cwd=str(package_root),
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr


def test_generated_mcp_schema_is_in_sync() -> None:
    package_root = Path(__file__).resolve().parent.parent
    schema_path = package_root / GENERATED_FILES["mcp_schema"]
    assert schema_path.exists()
    schema = schema_path.read_text(encoding="utf-8")
    assert '"prompt": "instrument_app"' in schema
    assert '"get_event_schema"' in schema
    assert '"get_integration_pattern"' in schema
    assert '"validate_setup"' in schema
    assert '"suggest_instrumentation"' in schema
    assert '"validate_file"' in schema
    assert '"search_docs"' in schema
