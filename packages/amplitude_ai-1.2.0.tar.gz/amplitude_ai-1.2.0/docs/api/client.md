# AmplitudeAI Client

The main entry point for the Amplitude AI SDK.

::: amplitude_ai.client.AmplitudeAI
options:
members: - **init** - amplitude - config - track_user_message - track_ai_message - track_tool_call - track_embedding - track_span - track_session_end - track_session_enrichment - score - flush - shutdown
