# Configuration

SDK configuration classes that control privacy tiers, PII redaction, and event callbacks.

## AIConfig

::: amplitude_ai.config.AIConfig

## ContentMode

::: amplitude_ai.config.ContentMode
