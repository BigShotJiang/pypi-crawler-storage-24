<!-- GENERATED FILE: do not edit manually -->
# AGENTS.md

Package: `amplitude-ai` v1.2.0

## Install
- `pip install amplitude-ai`
- Optional MCP support: `pip install 'amplitude-ai[mcp]'`

## Decision Tree
- Need zero-code coverage: use `patch()`.
- Already have provider client objects: use `wrap()`.
- Need session lineage and agent hierarchy: use `ai.agent(...).session(...)`.
- Multiple agents collaborating: use `session.run_as(child_agent)` for automatic identity propagation.
- Need explicit tool telemetry: use `@tool`.
- Need guided agent integration: use MCP prompt `instrument_app`.

## Canonical Patterns
- zero-code patching
- wrap-openai
- bound-agent-session
- multi-agent-run-as
- tool-decorator
- fastapi-middleware

## MCP Surface
- Tools: `get_event_schema`, `get_integration_pattern`, `validate_setup`, `suggest_instrumentation`, `validate_file`, `search_docs`, `scan_project`, `generate_verify_test`, `instrument_file`
- Resources: `amplitude-ai://event-schema`, `amplitude-ai://integration-patterns`, `amplitude-ai://instrument-guide`
- Prompt: `instrument_app`

## Gotchas
- Keep `AMPLITUDE_AI_API_KEY` set in runtime env.
- Use `MockAmplitudeAI` for deterministic tests.
- Use `unpatch()` in tests to prevent cross-test leakage.

## Testing
- `uv run pytest langley/amplitude_ai/tests`
- `uv run python scripts/generate_agent_docs.py --check`

## CLI
- `amplitude-ai-mcp` — start the MCP server for AI coding agents
- `amplitude-ai-doctor`

## Examples
- `examples/zero_code_example.py`
- `examples/wrap_openai_example.py`
- `examples/multi_agent_example.py`
- `examples/framework_integration_example.py`
- `examples/real_openai_example.py` (requires OPENAI_API_KEY)

## Extended Reference
- `llms-full.txt` — Full API signatures and canonical patterns for LLM agents

## Instrumentation Guide
- `amplitude-ai.md` — self-contained 4-phase instrumentation guide for any AI coding agent

## Event Schema (names)
- `[Agent] AI Response`
- `[Agent] Embedding`
- `[Agent] Score`
- `[Agent] Session End`
- `[Agent] Session Enrichment`
- `[Agent] Session Evaluation`
- `[Agent] Span`
- `[Agent] Tool Call`
- `[Agent] Topic Classification`
- `[Agent] User Message`
