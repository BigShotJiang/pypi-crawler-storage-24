"""
Real Anthropic integration example.
Requires ANTHROPIC_API_KEY and AMPLITUDE_AI_API_KEY environment variables.

Run: ANTHROPIC_API_KEY=sk-ant-... AMPLITUDE_AI_API_KEY=... python examples/real_anthropic_example.py
"""
from __future__ import annotations

import os


def run_real_anthropic_example() -> None:
    api_key = os.environ.get("AMPLITUDE_AI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key or not anthropic_key:
        print("Skipping: AMPLITUDE_AI_API_KEY and ANTHROPIC_API_KEY required.")
        return

    from amplitude import Amplitude
    from amplitude_ai import AmplitudeAI, Anthropic

    amplitude = Amplitude(api_key)
    ai = AmplitudeAI(amplitude=amplitude)
    client = Anthropic(amplitude=ai, api_key=anthropic_key)

    agent = ai.agent("real-anthropic-agent", user_id="demo-user")
    with agent.session() as session:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=100,
            messages=[{"role": "user", "content": "What is Amplitude analytics in one sentence?"}],
            amplitude_user_id="demo-user",
            amplitude_session_id=session.session_id,
        )
        text = response.content[0].text if response.content else ""
        print(f"Response: {text}")

    ai.flush()
    print("Events flushed successfully.")


if __name__ == "__main__":
    run_real_anthropic_example()
