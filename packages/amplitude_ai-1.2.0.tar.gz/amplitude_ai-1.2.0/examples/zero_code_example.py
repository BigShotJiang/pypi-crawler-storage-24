from __future__ import annotations

from amplitude_ai.testing import MockAmplitudeAI


def run_zero_code_example() -> MockAmplitudeAI:
    mock = MockAmplitudeAI()
    mock.track_user_message(
        user_id="user-zero-code",
        content="What changed in retention this week?",
        session_id="session-zero-code",
    )
    mock.track_ai_message(
        user_id="user-zero-code",
        content="Retention improved by 2.3% week-over-week.",
        session_id="session-zero-code",
        model="gpt-4o-mini",
        provider="openai",
        latency_ms=220,
    )
    return mock
