"""
Real OpenAI integration example.
Requires OPENAI_API_KEY and AMPLITUDE_AI_API_KEY environment variables.

Run: OPENAI_API_KEY=sk-... AMPLITUDE_AI_API_KEY=... python examples/real_openai_example.py
"""
from __future__ import annotations

import os


def run_real_openai_example() -> None:
    api_key = os.environ.get("AMPLITUDE_AI_API_KEY")
    openai_key = os.environ.get("OPENAI_API_KEY")
    if not api_key or not openai_key:
        print("Skipping: AMPLITUDE_AI_API_KEY and OPENAI_API_KEY required.")
        return

    from amplitude import Amplitude
    from amplitude_ai import AmplitudeAI, OpenAI

    amplitude = Amplitude(api_key)
    ai = AmplitudeAI(amplitude=amplitude)
    client = OpenAI(amplitude=ai, api_key=openai_key)

    agent = ai.agent("real-example-agent", user_id="demo-user")
    with agent.session() as session:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "What is Amplitude analytics in one sentence?"}],
            max_tokens=100,
            amplitude_user_id="demo-user",
            amplitude_session_id=session.session_id,
        )
        print(f"Response: {response.choices[0].message.content}")

    ai.flush()
    print("Events flushed successfully.")


if __name__ == "__main__":
    run_real_openai_example()
