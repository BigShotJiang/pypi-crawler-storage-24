"""Integrations for Amplitude AI SDK."""

from typing import Any


# LangChain integration
def _import_langchain() -> tuple[Any, Any]:
    try:
        from .langchain import AmplitudeCallbackHandler as _ACH
        from .langchain import create_amplitude_callback as _cac

        return _ACH, _cac
    except ImportError:
        return None, None


AmplitudeCallbackHandler: Any
create_amplitude_callback: Any
AmplitudeCallbackHandler, create_amplitude_callback = _import_langchain()


# OpenTelemetry integration
def _import_otel() -> tuple[Any, Any, Any]:
    try:
        from .opentelemetry import AmplitudeSpanExporter as _ASE
        from .opentelemetry import AmplitudeAgentExporter as _AAE
        from .opentelemetry import AmplitudeGenAIExporter as _AGAE

        return _ASE, _AAE, _AGAE
    except ImportError:
        return None, None, None


AmplitudeSpanExporter: Any
AmplitudeAgentExporter: Any
AmplitudeGenAIExporter: Any
AmplitudeSpanExporter, AmplitudeAgentExporter, AmplitudeGenAIExporter = _import_otel()


# LlamaIndex integration
def _import_llamaindex() -> tuple[Any, Any]:
    try:
        from .llamaindex import AmplitudeLlamaIndexHandler as _ALIH
        from .llamaindex import create_amplitude_llamaindex_handler as _calih

        return _ALIH, _calih
    except ImportError:
        return None, None


AmplitudeLlamaIndexHandler: Any
create_amplitude_llamaindex_handler: Any
AmplitudeLlamaIndexHandler, create_amplitude_llamaindex_handler = _import_llamaindex()


# OpenAI Agents SDK integration
def _import_openai_agents() -> Any:
    try:
        from .openai_agents import AmplitudeTracingProcessor as _ATP

        return _ATP
    except ImportError:
        return None


AmplitudeTracingProcessor: Any
AmplitudeTracingProcessor = _import_openai_agents()


# Anthropic tool_use loop integration
def _import_anthropic_tools() -> Any:
    try:
        from .anthropic_tools import AmplitudeToolLoop as _ATL

        return _ATL
    except ImportError:
        return None


AmplitudeToolLoop: Any
AmplitudeToolLoop = _import_anthropic_tools()


# CrewAI integration
def _import_crewai() -> Any:
    try:
        from .crewai import AmplitudeCrewAIHooks as _ACH

        return _ACH
    except ImportError:
        return None


AmplitudeCrewAIHooks: Any
AmplitudeCrewAIHooks = _import_crewai()


__all__ = [
    "AmplitudeAgentExporter",
    "AmplitudeCallbackHandler",
    "AmplitudeCrewAIHooks",
    "AmplitudeGenAIExporter",
    "AmplitudeLlamaIndexHandler",
    "AmplitudeSpanExporter",
    "AmplitudeToolLoop",
    "AmplitudeTracingProcessor",
    "create_amplitude_callback",
    "create_amplitude_llamaindex_handler",
]
