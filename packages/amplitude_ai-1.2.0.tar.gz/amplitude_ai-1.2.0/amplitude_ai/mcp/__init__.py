from amplitude_ai.mcp.contract import (
    GENERATED_FILES,
    MCP_PROMPTS,
    MCP_RESOURCES,
    MCP_SERVER_NAME,
    MCP_TOOLS,
)

__all__ = [
    "MCP_SERVER_NAME",
    "MCP_TOOLS",
    "MCP_RESOURCES",
    "MCP_PROMPTS",
    "GENERATED_FILES",
]
