from __future__ import annotations

MCP_SERVER_NAME = "amplitude-ai-mcp"

MCP_TOOLS = {
    "get_event_schema": "get_event_schema",
    "get_integration_pattern": "get_integration_pattern",
    "validate_setup": "validate_setup",
    "suggest_instrumentation": "suggest_instrumentation",
    "validate_file": "validate_file",
    "search_docs": "search_docs",
    "scan_project": "scan_project",
    "generate_verify_test": "generate_verify_test",
    "instrument_file": "instrument_file",
}

MCP_RESOURCES = {
    "event_schema": "amplitude-ai://event-schema",
    "integration_patterns": "amplitude-ai://integration-patterns",
    "instrument_guide": "amplitude-ai://instrument-guide",
}

MCP_PROMPTS = {
    "instrument_app": "instrument_app",
}

GENERATED_FILES = {
    "agents": "AGENTS.md",
    "llms": "llms.txt",
    "llms_full": "llms-full.txt",
    "mcp_schema": "mcp.schema.json",
}
