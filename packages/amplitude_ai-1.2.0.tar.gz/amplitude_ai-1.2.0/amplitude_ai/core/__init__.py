"""Core functionality for Amplitude AI SDK."""

from .decorators import ToolCallTracker, tool
from .enrichments import RubricScore, SessionEnrichments, TopicClassification
from .privacy import PrivacyConfig
from .tracking import (
    track_ai_message,
    track_conversation,
    track_embedding,
    track_score,
    track_session_end,
    track_session_enrichment,
    track_span,
    track_tool_call,
    track_user_message,
)

__all__ = [
    "PrivacyConfig",
    "RubricScore",
    "SessionEnrichments",
    "ToolCallTracker",
    "TopicClassification",
    "tool",
    "track_ai_message",
    "track_conversation",
    "track_embedding",
    "track_score",
    "track_session_end",
    "track_session_enrichment",
    "track_span",
    "track_tool_call",
    "track_user_message",
]
