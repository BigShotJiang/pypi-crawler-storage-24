"""
Configuration for the Amplitude AI SDK.

Provides AIConfig (top-level SDK configuration) and ContentMode (privacy tier enum).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from amplitude import BaseEvent

    from .core.privacy import PrivacyConfig


class ContentMode(str, Enum):
    """Privacy tier controlling what content is sent to Amplitude.

    - ``full``: Raw text + metrics. Server enrichment runs automatically.
    - ``metadata_only``: Metrics only (no content). No server enrichment.
    - ``customer_enriched``: Customer-provided classifications + metrics.
      No raw content sent; customer provides their own topic/rubric labels.
    """

    FULL = "full"
    METADATA_ONLY = "metadata_only"
    CUSTOMER_ENRICHED = "customer_enriched"


@dataclass
class AIConfig:
    """Top-level configuration for :class:`AmplitudeAI`.

    Parameters
    ----------
    content_mode:
        Privacy tier controlling what content is sent.  Default ``"full"``
        for maximum analytics value; customers opt-in to stricter tiers.
    redact_pii:
        When *True* and ``content_mode`` is ``"full"``, PII patterns
        (emails, phone numbers, credit cards, SSNs) are scrubbed from
        content before sending.  Default is *False* to maximize analytics
        value in the public SDK (changed from the legacy ``PrivacyConfig``
        default of *True*).  Customers opt-in to PII redaction explicitly.
    custom_redaction_patterns:
        Additional regex patterns to redact from content when
        ``redact_pii`` is *True*.
    on_event_callback:
        Optional callback invoked for every event sent or failed.
        Signature: ``(event: BaseEvent, status_code: int, message: str | None) -> None``.
        Hooks into ``amplitude.configuration.callback``.
    debug:
        When *True*, print colored event summaries to stderr for every
        tracked event.  Events are still sent to Amplitude unless
        ``dry_run`` is also *True*.
    dry_run:
        When *True*, print events but never send them to Amplitude.
        Works in CI without a real API key.  Combine with ``debug=True``
        for colored verbose output; without ``debug`` a compact JSON
        summary is printed instead.
    validate:
        When *True*, raise :class:`~amplitude_ai.exceptions.ValidationError`
        on bad inputs (empty ``user_id``, negative ``latency_ms``, etc.).
        Default is *False* (production mode -- silently log and continue).
        Combine with ``dry_run=True`` for strictest CI checking.
    propagate_context:
        When *True*, provider wrappers inject session/agent context as HTTP
        headers (``traceparent``, ``x-amplitude-session-id``, etc.) on
        outgoing LLM calls.  Downstream services running the SDK can pick
        up this context, linking sessions into a single distributed trace.
        Default is *False* — safe for single-service deployments.  Enable
        for multi-service LLM architectures.
    """

    content_mode: ContentMode = ContentMode.FULL
    redact_pii: bool = False
    custom_redaction_patterns: list[str] = field(default_factory=list)
    on_event_callback: Callable[[Any, int, str | None], None] | None = None
    debug: bool = False
    dry_run: bool = False
    validate: bool = False
    propagate_context: bool = False

    def to_privacy_config(self) -> "PrivacyConfig":
        """Bridge to the existing :class:`PrivacyConfig` used by tracking functions.

        Maps the ``content_mode`` enum to the boolean ``privacy_mode`` flag
        that ``core.privacy`` currently understands, plus forwards the PII
        settings.  This lets us adopt the new enum in the public API while
        keeping the internal tracking code unchanged for now.
        """
        from .core.privacy import PrivacyConfig

        # Any non-"full" mode sets privacy_mode=True so that PrivacyConfig
        # strips content.  The tracking functions inspect ``content_mode``
        # directly for the specific behavior per tier.
        privacy_mode = self.content_mode in (
            ContentMode.METADATA_ONLY,
            ContentMode.CUSTOMER_ENRICHED,
        )

        return PrivacyConfig(
            privacy_mode=privacy_mode,
            redact_pii=self.redact_pii,
            custom_redaction_patterns=self.custom_redaction_patterns,
            content_mode=self.content_mode,
            validate=self.validate,
            debug=self.debug,
        )
