try:
    import networkx as _networkx
except ImportError:
    raise ImportError("Networkx is not installed. Please install networkx to use this feature: altbacken[networkx].")


def __getattr__(name):
    return getattr(_networkx, name)