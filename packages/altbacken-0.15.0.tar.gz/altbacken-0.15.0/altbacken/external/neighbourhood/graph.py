from collections.abc import Mapping, Sequence, Callable, Iterable
from enum import Enum
from functools import partial
from itertools import product
from typing import Protocol, runtime_checkable
from random import choice as builtin_choice, shuffle as builtin_shuffle
from warnings import warn
from toolz import take

from altbacken.core.annealing import RandomChoice, RandomShuffle, RandomNumberGenerator
from altbacken.core.random import WeightedPicker
from altbacken.core.state import AnnealingState
from altbacken.core.types import PrimitiveType
from altbacken.internal.neighbourhood.adaptive import Epsilon, ConstantEpsilon
from altbacken.optional.networkx import Graph


class _Modification(Enum):
    ADD_NODE = 0
    ADD_EDGE = 1
    REMOVE_NODE = 2
    REMOVE_EDGE = 3


@runtime_checkable
class GraphModification(Protocol):
    def __call__(self, graph: Graph, *, choice: RandomChoice = builtin_choice) -> bool:
        """

        Args:
            graph:

        Returns:

        """


class AddNode:
    def __call__(self, graph: Graph, *, choice: RandomChoice = builtin_choice) -> bool:
        graph.add_node(max(graph.nodes, default=0)+1)
        return True

class RemoveNode:
    def __init__(self, only_isolated: bool = True):
        self._only_isolated = only_isolated

    def __call__(self, graph: Graph, *, choice: RandomChoice = builtin_choice) -> bool:
        candidates: list[int] = self._get_candidates(graph)
        if candidates:
            graph.remove_node(choice(candidates))
            return True
        else:
            return False

    def _get_candidates(self, graph: Graph) -> list[int]:
        if self._only_isolated:
            return [n for n in graph.nodes if graph.degree(n) == 0]
        else:
            return list(graph.nodes)

class AddEdge:
    def __init__(self, attributes: Mapping[str, PrimitiveType] | None = None):
        self._attributes: dict[str, PrimitiveType] = dict(attributes) if attributes else {}

    def __call__(self, graph: Graph, *, choice: RandomChoice = builtin_choice) -> bool:
        missing_edges = [
            (v, w)
            for v,w in product(graph.nodes, graph.nodes)
            if v != w and not graph.has_edge(v, w)
        ]
        if not missing_edges:
            return False
        else:
            graph.add_edge(*choice(missing_edges), **self._attributes)
            return True

class RemoveEdge:
    def __call__(self, graph: Graph, *, choice: RandomChoice = builtin_choice) -> bool:
        if bool(graph.edges):
            graph.remove_edge(*choice(list(graph.edges)))
            return True
        else:
            return False


_DEFAULT_MODIFICATIONS: dict[GraphModification, int] = {
    AddNode(): 2,
    AddEdge(): 2,
    RemoveNode(): 1,
    RemoveEdge(): 1
}

class GraphNeighbourhood:
    def __init__(
            self,
            epsilon: int | Epsilon[Graph, int] = 1,
            modifications: Mapping[GraphModification, int] | None = None,
            *,
            choice: RandomChoice = builtin_choice,
            shuffle: RandomShuffle = builtin_shuffle
    ):

        self._epsilon: Epsilon[Graph, int] = ConstantEpsilon(epsilon) if isinstance(epsilon, (int, float)) else epsilon # type: ignore
        self._choice: RandomChoice = choice
        self._shuffle: RandomShuffle = shuffle
        self._modifications: Mapping[GraphModification, int] = dict(modifications) if modifications else _DEFAULT_MODIFICATIONS
        self._picker: WeightedPicker[GraphModification] = WeightedPicker(shuffle)

    def __call__(self, state: AnnealingState[Graph]) -> Graph:
        graph: Graph = state.current_solution.copy()
        for _ in range(self._epsilon(state)):
            for modification in self._pick_modifications():
                if modification(graph, choice=self._choice):
                    break
        return graph

    def _pick_modifications(self) -> Sequence[GraphModification]:
        return self._picker.pick(self._modifications)


class ColorAdjustment[Node, Color](Protocol):
    def __call__(
            self,
            graph: Graph,
            attribute: str = "color",
            *,
            choice: RandomChoice = builtin_choice
    ) -> dict[Node, Color]:
        """

        Args:
            graph:

        Returns:

        """


class ReassignNode[Node, Color]:
    def __init__(
            self,
            random_color: Callable[[], Color]
    ):
        self._random_color: Callable[[], Color] = random_color

    def __call__(
        self, graph: Graph,
        attribute: str = "color",
        *,
        choice: RandomChoice = builtin_choice
    ) -> dict[Node, Color]:
        node: Node = choice(list(graph.nodes))
        new_color: Color = self._random_color()
        return {node: new_color} if graph.nodes[node][attribute] != new_color else {}

def _pick_two_differently_colored_nodes[Node](
        graph: Graph,
        attribute: str,
        choice: RandomChoice,
) -> tuple[Node, Node] | None:
    candidates: list[Node] = list(graph.nodes)
    if len(candidates) < 2:
        return None
    left: Node = choice(candidates)
    candidates.remove(left)
    right: Node = choice(candidates)
    if graph.nodes[left][attribute] != graph.nodes[right][attribute]:
        return left, right
    return None


class SwapColors[Node, Color]:
    def __call__(
            self,
            graph: Graph,
            attribute: str = "color",
            *,
            choice: RandomChoice = builtin_choice
    ) -> dict[Node, Color]:
        pair: tuple[Node, Node] | None = _pick_two_differently_colored_nodes(graph, attribute, choice)
        if pair is None:
            return {}
        left, right = pair
        return {left: graph.nodes[right][attribute], right: graph.nodes[left][attribute]}


class CopyColor[Node, Color]:
    def __call__(
            self,
            graph: Graph,
            attribute: str = "color",
            *,
            choice: RandomChoice = builtin_choice
    ) -> dict[Node, Color]:
        pair: tuple[Node, Node] | None = _pick_two_differently_colored_nodes(graph, attribute, choice)
        if pair is None:
            return {}
        left, right = pair
        return {left: graph.nodes[right][attribute]}

class PermuteColors[Node, Color]:
    def __init__(self, set_size: int = 3, shuffle: RandomShuffle = builtin_shuffle):
        self._set_size: int = set_size
        self._shuffle: RandomShuffle = shuffle

    def __call__(
            self,
            graph: Graph,
            attribute: str = "color",
            *,
            choice: RandomChoice = builtin_choice
    ) -> dict[Node, Color]:
        if len(graph.nodes) < self._set_size:
            return {}
        candidates: list[Node] = list(graph.nodes)
        self._shuffle(candidates)
        permutation_set: list[Node] = list(take(self._set_size, candidates))
        permutation_values: list[Color] = [graph.nodes[node][attribute] for node in permutation_set]
        permuted_values: list[Color] = permutation_values.copy()
        self._shuffle(permuted_values)
        if permuted_values != permutation_values:
            return dict(zip(permutation_set, permuted_values))
        else:
            return {}


def color_adjustments_for_limited_colors[Node, Color](
    colors: Iterable[Color],
    permutation_size: int = 3,
    choice: RandomChoice = builtin_choice,
    shuffle: RandomShuffle = builtin_shuffle,
) -> dict[ColorAdjustment[Node, Color], int]:
    possible_colors: list[Color] = list(colors)
    return {
        ReassignNode(partial(choice, possible_colors)): 1,
        SwapColors(): 1,
        CopyColor(): 1,
        PermuteColors(permutation_size, shuffle): 1
    }


class GraphColoringNeighbourhood[Node, Color]:
    def __init__(
            self,
            adjustments: Mapping[ColorAdjustment[Node, Color], int],
            epsilon: int | Epsilon[Graph, int] = 1,
            color_attribute: str = "color",
            *,
            choice: RandomChoice = builtin_choice,
            shuffle: RandomShuffle = builtin_shuffle
    ):
        if not adjustments:
            raise ValueError("At least one color adjustment must be provided")
        self._epsilon: Epsilon[Graph, int] = ConstantEpsilon(epsilon) if isinstance(epsilon, (int, float)) else epsilon # type: ignore
        self._color_attribute: str = color_attribute
        self._choice: RandomChoice = choice
        self._shuffle: RandomShuffle = shuffle
        self._picker: WeightedPicker[ColorAdjustment[Node, Color]] = WeightedPicker(shuffle)
        self._adjustments: dict[ColorAdjustment[Node, Color], int] = dict(adjustments)


    def __call__(self, state: AnnealingState[Graph]) -> Graph:
        graph: Graph = state.current_solution.copy()
        for _ in range(self._epsilon(state)):
            changed: bool = False
            for modification in self._picker.pick(self._adjustments):
                if recoloring := modification(graph, choice=self._choice):
                    self._apply_recoloring(graph, recoloring)
                    changed = True
                    break
            if not changed:
                warn(RuntimeWarning("No color adjustment applied to graph"))
        return graph

    def _apply_recoloring(self, graph: Graph, recoloring: dict[Node, Color]) -> None:
        for node, color in recoloring.items():
            graph.nodes[node][self._color_attribute] = color
