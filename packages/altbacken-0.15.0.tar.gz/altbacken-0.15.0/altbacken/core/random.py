from collections.abc import Mapping, Sequence, Callable
from itertools import repeat
from random import shuffle as builtin_shuffle, choices as builtin_choices

from altbacken.core.annealing import RandomShuffle


class WeightedPicker[T]:
    """
    Utility class for creating a weighted picker.

    The class is designed to provide a mechanism to generate a sequence of items based on
    their respective weights. It uses a shuffling function to randomize the order of the items
    after replicating each item according to its weight. By default, the standard Python
    shuffle method is used, but a custom shuffle implementation can also be provided.

    Attributes:
        shuffle (RandomShuffle): Function used to shuffle the modified list of items.
    """
    def __init__(
            self,
            shuffle: RandomShuffle = builtin_shuffle
    ):
        self._shuffle: RandomShuffle = shuffle

    def pick(self, weighted_options: Mapping[T, int]) -> Sequence[T]:
        candidates: list[T] = [
            copy
            for modification, weight in weighted_options.items()
            for copy in repeat(modification, weight)
        ]
        self._shuffle(candidates)
        result: list[T] = []
        seen: list[T] = []
        for item in candidates:
            if item not in seen:
                result.append(item)
                seen.append(item)
        return result