from typing import ClassVar

class Frame:
    width: int
    height: int
    format: str
    data: bytes
    timestamp_ns: int | None

class Codec:
    H264: ClassVar[Codec]
    H265: ClassVar[Codec]
    AV1: ClassVar[Codec]

    def __eq__(self, other: object) -> bool: ...
    def __int__(self) -> int: ...

class ImageFormat:
    Jpeg: ClassVar[ImageFormat]
    Png: ClassVar[ImageFormat]

    def __eq__(self, other: object) -> bool: ...
    def __int__(self) -> int: ...

class FlipMode:
    Horizontal: ClassVar[FlipMode]
    Vertical: ClassVar[FlipMode]
    Rotate90: ClassVar[FlipMode]
    Rotate180: ClassVar[FlipMode]
    Rotate270: ClassVar[FlipMode]

    def __eq__(self, other: object) -> bool: ...
    def __int__(self) -> int: ...

class Crop:
    top: int
    bottom: int
    left: int
    right: int
    def __init__(self, top: int = 0, bottom: int = 0, left: int = 0, right: int = 0) -> None: ...

class ReconnectOptions:
    retry_delay_s: float
    max_retries: int | None
    disconnect_grace_s: float
    def __init__(
        self,
        retry_delay_s: float = 2.0,
        max_retries: int | None = None,
        disconnect_grace_s: float = 2.0,
    ) -> None: ...

class StreamOptions:
    codec: Codec
    bitrate: int
    resolution: str | None
    overlay: bool
    fps: int | None
    keyframe_interval: int
    flip: FlipMode | None
    crop: Crop | None
    reconnect: ReconnectOptions | None
    transcode: bool
    congestion_control: bool
    def __init__(
        self,
        codec: Codec | None = None,
        bitrate: int = 4000,
        resolution: str | None = None,
        overlay: bool = False,
        fps: int | None = None,
        keyframe_interval: int = 30,
        flip: FlipMode | None = None,
        crop: Crop | None = None,
        reconnect: ReconnectOptions | None = None,
        transcode: bool = False,
        congestion_control: bool = True,
    ) -> None: ...

class Src:
    @staticmethod
    def test() -> Src: ...
    @staticmethod
    def camera(device_index: int = 0, resolution: str | None = None) -> Src: ...
    @staticmethod
    def rtsp(url: str) -> Src: ...
    @staticmethod
    def udp_rtp(port: int) -> Src: ...
    @staticmethod
    def udp_mpegts(port: int) -> Src: ...
    @staticmethod
    def file(location: str, start_ns: int | None = None) -> Src: ...
    @staticmethod
    def images(path: str, fps: int, start_ns: int | None = None) -> Src: ...
    @staticmethod
    def app(width: int, height: int, format: str = "RGB", auto_timestamp: bool = True) -> Src: ...
    @staticmethod
    def app_encoded(codec: Codec | None = None) -> Src: ...
    @staticmethod
    def app_image(format: ImageFormat) -> Src: ...
    @staticmethod
    def custom(description: str) -> Src: ...

class Sink:
    @staticmethod
    def whip(
        endpoint: str,
        token: str | None = None,
        stun_server: str | None = None,
    ) -> Sink: ...
    @staticmethod
    def udp_rtp(host: str, port: int) -> Sink: ...
    @staticmethod
    def udp_mpegts(host: str, port: int) -> Sink: ...
    @staticmethod
    def file(location: str) -> Sink: ...
    @staticmethod
    def fake() -> Sink: ...
    @staticmethod
    def display() -> Sink: ...
    @staticmethod
    def app(format: str = "RGB") -> Sink: ...

class Stream:
    def __init__(self, src: Src, sink: Sink, options: StreamOptions | None = None) -> None: ...
    def open(self) -> None: ...
    def run(self, seconds: float | None = None) -> None: ...
    def close(self) -> None: ...
    def restart(self) -> None: ...
    def __enter__(self) -> Stream: ...
    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> bool: ...
    def send_frame(self, data: bytes, timestamp_ns: int | None = None) -> bool: ...
    def send_encoded(self, data: bytes, timestamp_ns: int | None = None) -> bool: ...
    def recv_frame(self, timeout_ms: int | None = None) -> Frame | None: ...
