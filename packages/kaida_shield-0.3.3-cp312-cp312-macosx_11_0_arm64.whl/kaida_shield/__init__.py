"""Kaida Shield"""

__version__ = "0.3.3"

# ── Public API ────────────────────────────────────────────────────────────────

from .shield import Shield, ShieldConfig, ShieldMode

from .policy_engine import (
    Policy,
    PolicyEvaluator,
    PolicyLoader,
    PolicyTemplates,
    Verdict,
    MonitoringMode,
    SupervisedDecision,
)

from .quarantine import QuarantineManager

from .pre_scanner import (
    InputScanner,
    ScanResult,
    ThreatLevel,
)

from .anomaly_detector import AnomalyDetector, AnomalyAlert, AnomalyConfig

# Convenience alias
PolicyEngine = PolicyEvaluator

__all__ = [
    "Shield",
    "ShieldConfig",
    "ShieldMode",
    "Policy",
    "PolicyEvaluator",
    "PolicyEngine",
    "PolicyLoader",
    "PolicyTemplates",
    "Verdict",
    "MonitoringMode",
    "SupervisedDecision",
    "QuarantineManager",
    "InputScanner",
    "ScanResult",
    "ThreatLevel",
    "AnomalyDetector",
    "AnomalyAlert",
    "AnomalyConfig",
]
