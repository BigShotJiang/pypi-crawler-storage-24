"""Custom exceptions for the SignalNet SDK."""

from __future__ import annotations


class SignalNetError(Exception):
    """Base exception for all SignalNet SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, response_body: dict | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class AuthenticationError(SignalNetError):
    """Raised when the API key is invalid or missing (401/403)."""


class NotFoundError(SignalNetError):
    """Raised when the requested resource is not found (404)."""


class ValidationError(SignalNetError):
    """Raised when the request payload is invalid (400/422)."""


class RateLimitError(SignalNetError):
    """Raised when the API rate limit is exceeded (429)."""


class ServerError(SignalNetError):
    """Raised when the server returns a 5xx error."""
