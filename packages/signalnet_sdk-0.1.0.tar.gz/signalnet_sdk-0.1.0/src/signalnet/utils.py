"""Utility helpers for the SignalNet SDK."""

from __future__ import annotations

import io
import os
import shutil
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd

_DEFAULT_CACHE_DIR = os.path.join(os.path.expanduser("~"), ".signalnet", "data")


def csv_bytes_to_dataframe(data: bytes) -> "pd.DataFrame":
    """Parse CSV bytes into a pandas DataFrame.

    Args:
        data: Raw CSV bytes from the API response.

    Returns:
        A pandas DataFrame with the parsed CSV data.
    """
    import pandas as pd

    return pd.read_csv(io.BytesIO(data))


def _human_size(nbytes: int) -> str:
    """Format byte count as a human-readable string (KB / MB / GB)."""
    if nbytes < 1024:
        return f"{nbytes} B"
    for unit in ("KB", "MB", "GB"):
        nbytes /= 1024  # type: ignore[assignment]
        if nbytes < 1024 or unit == "GB":
            return f"{nbytes:.1f} {unit}"
    return f"{nbytes:.1f} GB"  # pragma: no cover


def _log(msg: str) -> None:
    """Print a prefixed log message to stderr."""
    print(f"[SignalNet] {msg}", file=sys.stderr, flush=True)


class DataCache:
    """Local parquet cache for SignalNet data downloads.

    Args:
        cache_dir: Root cache directory. Defaults to ``~/.signalnet/data``
            or the ``SIGNALNET_CACHE_DIR`` environment variable.
    """

    def __init__(self, cache_dir: str | None = None) -> None:
        self.cache_dir = Path(
            cache_dir
            or os.environ.get("SIGNALNET_CACHE_DIR")
            or _DEFAULT_CACHE_DIR
        )

    # ── paths ────────────────────────────────────────────────────────

    def _round_features_path(self, round_id: int) -> Path:
        return self.cache_dir / "rounds" / str(round_id) / "features.parquet"

    def _training_path(self, data_type: str) -> Path:
        return self.cache_dir / "training" / f"{data_type}.parquet"

    # ── read / write ─────────────────────────────────────────────────

    def read_round_features(self, round_id: int) -> "pd.DataFrame | None":
        """Read cached round features. Returns None on miss."""
        import pandas as pd

        path = self._round_features_path(round_id)
        if path.exists():
            df = pd.read_parquet(path)
            _log(f"Using cached features for round {round_id} ({_human_size(path.stat().st_size)})")
            return df
        return None

    def write_round_features(self, round_id: int, df: "pd.DataFrame", csv_size: int) -> None:
        """Write round features to parquet cache."""
        path = self._round_features_path(round_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(path, index=False)
        pq_size = path.stat().st_size
        _log(f"Downloading features for round {round_id}... done ({_human_size(csv_size)} → {_human_size(pq_size)} parquet)")

    def read_training(self, data_type: str) -> "pd.DataFrame | None":
        """Read cached training data. Returns None on miss."""
        import pandas as pd

        path = self._training_path(data_type)
        if path.exists():
            df = pd.read_parquet(path)
            _log(f"Using cached training {data_type} ({_human_size(path.stat().st_size)})")
            return df
        return None

    def write_training(self, data_type: str, df: "pd.DataFrame", csv_size: int) -> None:
        """Write training data to parquet cache."""
        path = self._training_path(data_type)
        path.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(path, index=False)
        pq_size = path.stat().st_size
        _log(f"Downloading training {data_type}... done ({_human_size(csv_size)} → {_human_size(pq_size)} parquet)")

    # ── management ───────────────────────────────────────────────────

    def clear(self) -> int:
        """Delete all cached data. Returns bytes freed."""
        freed = self._dir_size(self.cache_dir)
        if self.cache_dir.exists():
            shutil.rmtree(self.cache_dir)
        return freed

    def info(self) -> dict:
        """Return cache statistics.

        Returns:
            Dict with ``cache_dir``, ``total_size``, ``total_size_human``,
            ``round_features`` (list of round IDs), and
            ``training_files`` (list of data types).
        """
        rounds_dir = self.cache_dir / "rounds"
        training_dir = self.cache_dir / "training"

        round_ids: list[int] = []
        if rounds_dir.exists():
            for d in sorted(rounds_dir.iterdir()):
                if d.is_dir() and (d / "features.parquet").exists():
                    try:
                        round_ids.append(int(d.name))
                    except ValueError:
                        pass

        training_files: list[str] = []
        if training_dir.exists():
            for f in sorted(training_dir.iterdir()):
                if f.suffix == ".parquet":
                    training_files.append(f.stem)

        total = self._dir_size(self.cache_dir)

        return {
            "cache_dir": str(self.cache_dir),
            "total_size": total,
            "total_size_human": _human_size(total),
            "round_features": round_ids,
            "training_files": training_files,
        }

    @staticmethod
    def _dir_size(path: Path) -> int:
        if not path.exists():
            return 0
        return sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
