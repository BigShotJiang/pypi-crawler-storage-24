"""Tests for the SignalNet SDK client."""

from __future__ import annotations

import json
import os
import tempfile
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from signalnet import SignalNet, SignalNetError, __version__
from signalnet.exceptions import AuthenticationError, NotFoundError, ValidationError
from signalnet.models import Round, Tournament, User


# ── Fixtures ─────────────────────────────────────────────────────────────


@pytest.fixture
def tmp_cache(tmp_path):
    """Provide a temporary cache directory."""
    return str(tmp_path / "cache")


@pytest.fixture
def client(tmp_cache) -> SignalNet:
    return SignalNet(api_key="sn_test_key", base_url="http://localhost:4000/api", cache_dir=tmp_cache)


def _mock_response(
    status_code: int = 200,
    json_data: dict | list | None = None,
    content: bytes = b"",
) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = 200 <= status_code < 300
    resp.json.return_value = json_data
    resp.content = content or (json.dumps(json_data).encode() if json_data else b"")
    resp.text = json.dumps(json_data) if json_data else content.decode("utf-8", errors="replace")
    return resp


# ── Version ──────────────────────────────────────────────────────────────


def test_version() -> None:
    assert __version__ == "0.1.0"


# ── Constructor ──────────────────────────────────────────────────────────


def test_default_base_url(tmp_cache) -> None:
    sn = SignalNet(api_key="k", cache_dir=tmp_cache)
    assert sn.base_url == "http://localhost:4000/api"


def test_env_base_url(monkeypatch: pytest.MonkeyPatch, tmp_cache) -> None:
    monkeypatch.setenv("SIGNALNET_API_URL", "https://custom.api")
    sn = SignalNet(api_key="k", cache_dir=tmp_cache)
    assert sn.base_url == "https://custom.api"


def test_env_api_key(monkeypatch: pytest.MonkeyPatch, tmp_cache) -> None:
    monkeypatch.setenv("SIGNALNET_API_KEY", "sn_env")
    sn = SignalNet(cache_dir=tmp_cache)
    assert sn.api_key == "sn_env"


# ── Rounds ───────────────────────────────────────────────────────────────


@patch("signalnet.client.requests.Session.get")
def test_get_current_round(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(json_data={"round": {"id": 42, "status": "active"}})
    r = client.get_current_round()
    assert isinstance(r, Round)
    assert r.id == 42
    assert r.status == "active"


@patch("signalnet.client.requests.Session.get")
def test_get_rounds(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        json_data={"rounds": [{"id": 1}, {"id": 2}], "total": 2}
    )
    rounds = client.get_rounds(limit=10, status="active")
    assert len(rounds) == 2
    assert rounds[0].id == 1


@patch("signalnet.client.requests.Session.get")
def test_get_round(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(json_data={"round": {"id": 5}})
    r = client.get_round(5)
    assert r.id == 5


@patch("signalnet.client.requests.Session.get")
def test_get_round_results(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        json_data={"results": [{"user_id": 1, "rank": 1, "score": 0.95}]}
    )
    results = client.get_round_results(1)
    assert len(results) == 1
    assert results[0].rank == 1


# ── Tournaments ──────────────────────────────────────────────────────────


@patch("signalnet.client.requests.Session.get")
def test_get_tournaments(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        json_data={"tournaments": [{"id": 1, "slug": "genesis", "name": "Genesis"}]}
    )
    tournaments = client.get_tournaments()
    assert len(tournaments) == 1
    assert isinstance(tournaments[0], Tournament)


@patch("signalnet.client.requests.Session.get")
def test_get_tournament_by_slug(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        json_data={"tournaments": [{"id": 1, "slug": "genesis", "name": "Genesis"}]}
    )
    t = client.get_tournament("genesis")
    assert t.slug == "genesis"


@patch("signalnet.client.requests.Session.get")
def test_get_tournament_not_found(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        json_data={"tournaments": []}
    )
    with pytest.raises(NotFoundError):
        client.get_tournament("nonexistent")


# ── Data Downloads ───────────────────────────────────────────────────────


@patch("signalnet.client.requests.Session.get")
def test_download_features(mock_get: MagicMock, client: SignalNet) -> None:
    csv = b"stock_id,feat1,feat2\nstock_0,0.1,0.2\nstock_1,0.3,0.4\n"
    mock_get.return_value = _mock_response(content=csv)
    df = client.download_features(round_id=1)
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 2
    assert "stock_id" in df.columns


@patch("signalnet.client.requests.Session.get")
def test_download_training_data(mock_get: MagicMock, client: SignalNet) -> None:
    csv = b"stock_id,target\nstock_0,1.0\n"
    mock_get.return_value = _mock_response(content=csv)
    df = client.download_training_data("targets")
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 1


def test_download_training_data_invalid_type(client: SignalNet) -> None:
    with pytest.raises(ValueError, match="data_type must be"):
        client.download_training_data("invalid")


# ── Cache Behavior ───────────────────────────────────────────────────────


@patch("signalnet.client.requests.Session.get")
def test_download_features_caches_as_parquet(mock_get: MagicMock, client: SignalNet) -> None:
    csv = b"stock_id,feat1\nstock_0,0.1\nstock_1,0.2\n"
    mock_get.return_value = _mock_response(content=csv)

    # First call downloads
    df1 = client.download_features(round_id=7)
    assert mock_get.call_count == 1
    assert len(df1) == 2

    # Second call uses cache (no extra HTTP call)
    df2 = client.download_features(round_id=7)
    assert mock_get.call_count == 1  # still 1
    assert df2.equals(df1)


@patch("signalnet.client.requests.Session.get")
def test_download_features_force_bypasses_cache(mock_get: MagicMock, client: SignalNet) -> None:
    csv = b"stock_id,feat1\nstock_0,0.5\n"
    mock_get.return_value = _mock_response(content=csv)

    client.download_features(round_id=3)
    assert mock_get.call_count == 1

    # force=True re-downloads
    client.download_features(round_id=3, force=True)
    assert mock_get.call_count == 2


@patch("signalnet.client.requests.Session.get")
def test_download_training_data_caches(mock_get: MagicMock, client: SignalNet) -> None:
    csv = b"stock_id,target\nstock_0,1.0\n"
    mock_get.return_value = _mock_response(content=csv)

    client.download_training_data("features")
    client.download_training_data("features")
    assert mock_get.call_count == 1

    client.download_training_data("features", force=True)
    assert mock_get.call_count == 2


@patch("signalnet.client.requests.Session.get")
def test_cache_info(mock_get: MagicMock, client: SignalNet) -> None:
    # Empty cache
    info = client.cache_info()
    assert info["total_size"] == 0
    assert info["round_features"] == []
    assert info["training_files"] == []

    # Cache something
    csv = b"stock_id,feat1\nstock_0,0.1\n"
    mock_get.return_value = _mock_response(content=csv)
    client.download_features(round_id=5)

    info = client.cache_info()
    assert info["total_size"] > 0
    assert 5 in info["round_features"]


@patch("signalnet.client.requests.Session.get")
def test_clear_cache(mock_get: MagicMock, client: SignalNet) -> None:
    csv = b"stock_id,feat1\nstock_0,0.1\n"
    mock_get.return_value = _mock_response(content=csv)
    client.download_features(round_id=1)

    assert client.cache_info()["total_size"] > 0
    client.clear_cache()
    assert client.cache_info()["total_size"] == 0


# ── Submissions ──────────────────────────────────────────────────────────


@patch("signalnet.client.requests.Session.post")
def test_submit(mock_post: MagicMock, client: SignalNet) -> None:
    mock_post.return_value = _mock_response(
        json_data={"id": 99, "round_id": 1, "status": "accepted", "stake_amount": 500}
    )
    df = pd.DataFrame({"stock_id": ["s0", "s1"], "signal": [0.7, 0.3]})
    result = client.submit(round_id=1, predictions=df, stake=500)
    assert result.id == 99
    assert result.status == "accepted"

    call_kwargs = mock_post.call_args
    payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
    assert payload["round_id"] == 1
    assert payload["stake_amount"] == 500
    assert len(payload["predictions"]) == 2


def test_submit_missing_columns(client: SignalNet) -> None:
    df = pd.DataFrame({"stock_id": ["s0"], "price": [100]})
    with pytest.raises(ValueError, match="missing columns"):
        client.submit(round_id=1, predictions=df)


# ── User ─────────────────────────────────────────────────────────────────


@patch("signalnet.client.requests.Session.get")
def test_get_me(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        json_data={"id": 1, "username": "quant_master", "email": "q@m.com"}
    )
    user = client.get_me()
    assert isinstance(user, User)
    assert user.username == "quant_master"


@patch("signalnet.client.requests.Session.get")
def test_get_my_scores(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        json_data={"scores": [{"round_id": 1, "score": 0.88}]}
    )
    scores = client.get_my_scores()
    assert len(scores) == 1
    assert scores[0].score == 0.88


# ── Error Handling ───────────────────────────────────────────────────────


@patch("signalnet.client.requests.Session.get")
def test_auth_error(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        status_code=401, json_data={"error": "Invalid API key"}
    )
    with pytest.raises(AuthenticationError):
        client.get_me()


@patch("signalnet.client.requests.Session.get")
def test_not_found_error(mock_get: MagicMock, client: SignalNet) -> None:
    mock_get.return_value = _mock_response(
        status_code=404, json_data={"error": "Round not found"}
    )
    with pytest.raises(NotFoundError):
        client.get_round(999)


@patch("signalnet.client.requests.Session.post")
def test_validation_error(mock_post: MagicMock, client: SignalNet) -> None:
    mock_post.return_value = _mock_response(
        status_code=422, json_data={"error": "Invalid predictions format"}
    )
    df = pd.DataFrame({"stock_id": ["s0"], "signal": [0.5]})
    with pytest.raises(ValidationError):
        client.submit(round_id=1, predictions=df)
