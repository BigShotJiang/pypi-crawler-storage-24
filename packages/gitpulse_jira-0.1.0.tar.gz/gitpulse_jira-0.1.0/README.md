# GitPulse

Automatically post daily Jira progress updates from your git commits — no manual standup notes needed.

GitPulse scans your local git repos, groups commits by Jira ticket key, uses Gemini AI to write a concise progress summary, and posts it as a Jira comment. It runs on a schedule via macOS LaunchAgent so it just happens in the background.

---

## How it works

1. Scans configured repos for commits in the last 24 hours authored by you
2. Groups commits by Jira ticket key (e.g. `PROJ-123`) found in branch names or commit messages
3. Sends commits to Gemini to generate a professional progress summary
4. Posts the summary as a comment on the corresponding Jira ticket
5. Sends a macOS notification with the run result

---

## Requirements

- macOS (uses LaunchAgent for scheduling and native notifications)
- Python 3.11+
- A Jira account with API token access
- A Google Gemini API key (free tier works — get one at [aistudio.google.com](https://aistudio.google.com/app/apikey))

---

## Installation

```bash
pip install gitpulse
```

Or install from source:

```bash
git clone https://github.com/ashishBhatnagar-16/git-pulse.git
cd git-pulse
pip install -e .
```

---

## Setup

Run the interactive setup wizard once:

```bash
gitpulse setup
```

It will walk you through:
- Jira URL, email, and API token (credentials are validated live)
- Gemini API key (validated live)
- Your git author email
- Local repo paths to scan
- Jira project keys to watch (e.g. `PROJ`, `BACKEND`)
- Daily run time (24hr format, default `18:00`)
- macOS notification preferences

Config is saved to `~/.gitpulse/config.yaml`. A LaunchAgent is installed automatically to run on your chosen schedule.

---

## Commands

| Command | Description |
|---|---|
| `gitpulse run` | Scan repos and post updates now |
| `gitpulse setup` | Run the setup wizard |
| `gitpulse status` | Show LaunchAgent status and recent logs |
| `gitpulse config` | Display current config (secrets masked) |
| `gitpulse config --set KEY=VALUE` | Update a config value |
| `gitpulse schedule HH:MM` | Change the daily run time |
| `gitpulse logs` | Show recent log entries |
| `gitpulse logs -n 50` | Show last 50 log entries |
| `gitpulse uninstall` | Remove all GitPulse data and the LaunchAgent |

### Examples

```bash
# Run manually right now
gitpulse run

# Change schedule to 5pm
gitpulse schedule 17:00

# Update a single config value
gitpulse config --set git.lookback_hours=48

# Check what's going on
gitpulse status
```

---

## Configuration reference

Config lives at `~/.gitpulse/config.yaml`. Key fields:

```yaml
jira:
  url: https://your-org.atlassian.net
  email: you@example.com
  token: <your-api-token>

gemini:
  api_key: <your-gemini-key>
  model: gemini-2.5-flash-lite

git:
  author_email: you@example.com
  lookback_hours: 24        # how far back to scan commits

repos:
  - path: ~/code/my-project
  - path: ~/code/another-repo

project_keys:
  - PROJ
  - BACKEND

schedule:
  time: "18:00"

notificationsConfig:
  macos: true
  on_success: true
  on_failure: true

logging:
  path: ~/.gitpulse/run.log
  level: INFO
  retain_days: 30
```

---

## Jira ticket detection

GitPulse looks for ticket keys matching your configured `project_keys` in:
- The current branch name (e.g. `feature/PROJ-123-add-login`)
- Commit messages (e.g. `PROJ-123: fix null pointer`)

Commits are grouped per ticket, so if you worked across multiple tickets in a day, each gets its own comment.

---

## Logs

Logs are written to `~/.gitpulse/run.log` in JSON format and rotated automatically after `retain_days` (default 30).

```bash
gitpulse logs          # last 20 entries
gitpulse logs -n 100   # last 100 entries
```

---

## License

MIT
