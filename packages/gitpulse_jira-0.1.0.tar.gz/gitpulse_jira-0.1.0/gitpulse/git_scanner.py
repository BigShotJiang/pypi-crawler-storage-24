import re
from datetime import datetime, timedelta, timezone
from typing import Dict, List
import git
from pathlib import Path
from gitpulse.config_schema import RepoConfig
from gitpulse.models import Commit

class GitScanner:

    def scan_repos(
        self,
        repos: List[RepoConfig],
        author_email: str,
        lookback_hours: int,
        project_keys: List[str]
    ) -> Dict[str, List[Commit]] :
        """
        Given a list of repositories, this function will scan each repository   
        for commits made by the specified author in the last lookback_hours
        grouped by project_key
        """

        since = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
        grouped: Dict(str, List[Commit]) = {}
        
        for repo_config in repos:
            commits = self._scan_single_repo(
                repo_path=repo_config.path,
                author_email=author_email,
                since=since,
                project_keys=project_keys
            )

            for commit in commits:
                ticket_key = self._extract_ticket_key(commit.message, project_keys)
                if ticket_key:
                    if ticket_key not in grouped:
                        grouped[ticket_key] = []
                    grouped[ticket_key].append(commit)

        return grouped

                
    def _extract_ticket_key(
        self,
        message: str,
        project_keys: List[str]
    ) -> str | None:
        """
        Extracts ticket key from commit message.
        e.g. "SHOP-42 | fixed cart bug" → "SHOP-42"
        Returns None if no valid ticket key found.
        """
        # Support formats:
        # SH-42 message
        # SH-42 | message
        # SH-42: message
        # feat(SH-42): message
        # feat(SH-42) message
        keys_pattern = "|".join(project_keys)
        pattern = rf"(?:^\w+\(({keys_pattern})-(\d+)\)|^({keys_pattern})-(\d+))[\s|:]?"
        match = re.match(pattern, message.strip())
        if match:
            # conventional commit: group 1+2, plain: group 3+4
            prefix = match.group(1) or match.group(3)
            number = match.group(2) or match.group(4)
            return f"{prefix}-{number}"
        return None
        
    def _scan_single_repo(
        self,
        repo_path,
        author_email: str,
        since: datetime,
        project_keys: List[str]
    )->List[Commit]:
        """
        Opens one repo and returns matching commits
        from that repo. Returns empty list if anything goes wrong
        """
        try:
            path = Path(repo_path).expanduser()
            repo = git.Repo(path)

            # resolve GitHub web URL from origin remote
            try:
                remote_url = repo.remotes.origin.url
                # convert SSH → HTTPS: git@github.com:org/repo.git → https://github.com/org/repo
                if remote_url.startswith("git@"):
                    remote_url = remote_url.replace(":", "/").replace("git@", "https://")
                repo_web_url = remote_url.rstrip(".git")
            except Exception:
                repo_web_url = None

            # collect all SHAs reachable from remote tracking branches
            remote_shas = set()
            for remote in repo.remotes:
                for ref in remote.refs:
                    try:
                        for rc in repo.iter_commits(ref):
                            remote_shas.add(rc.hexsha)
                    except Exception:
                        pass

            commits = []
            seen_shas = set()

            for c in repo.iter_commits(all=True):
                # convert commit timestamp to utc datetime
                commit_time = datetime.fromtimestamp(
                    c.committed_date, tz=timezone.utc
                )

                #stop walking if commit is older tahn our loookback window
                if commit_time < since:
                    break

                #skip if not by the same developer
                if c.author.email.lower() != author_email.lower():
                    continue

                #skip if no matching ticket key in the message
                ticket_key = self._extract_ticket_key(c.message, project_keys)
                if not ticket_key:
                    continue

                # skip duplicate commits (same sha on multiple branches)
                if c.hexsha in seen_shas:
                    continue
                seen_shas.add(c.hexsha)

                #get list of files changed in this commit
                changed_files = list(c.stats.files.keys())

                commits.append(
                    Commit(
                        sha=c.hexsha[:7],
                        full_sha=c.hexsha,
                        message=c.message.strip(),
                        author_email=c.author.email,
                        timestamp=commit_time,
                        repo_path=str(path),
                        repo_url=repo_web_url,
                        is_pushed=c.hexsha in remote_shas
                    )
                )

            return commits
        
        except Exception as e:
            print(f"Error scanning {repo_path}: {e}")
            return []



