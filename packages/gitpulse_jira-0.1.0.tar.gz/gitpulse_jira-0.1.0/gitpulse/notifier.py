from dataclasses import dataclass
from typing import List

@dataclass
class RunSummary:
    total_cards: int
    successful: List[str]
    failed: List[str]

class Notifier:
    def __init__(self, enabled: bool = True):
        self.enabled = enabled

    def notify_success(self, summary: RunSummary) -> None:
        """All cards updated successfully."""
        if not self.enabled:
            return

        card_list = ", ".join(summary.successful)
        self._send(
            title="GitPulse",
            message=f"Updated {len(summary.successful)} cards: {card_list}"
        )

    def notify_partial(self, summary: RunSummary) -> None:
        """Some cards succeeded, some failed."""
        if not self.enabled:
            return

        self._send(
            title="GitPulse — Partial Update",
            message=(
                f"{len(summary.successful)} updated, "
                f"{len(summary.failed)} failed: "
                f"{', '.join(summary.failed)}"
            )
        )

    def notify_no_updates(self) -> None:
        """No commits found today."""
        if not self.enabled:
            return

        self._send(
            title="GitPulse",
            message="No commits found today. Nothing posted to Jira."
        )

    def notify_failure(self, error: str) -> None:
        """Complete run failure — something crashed."""
        if not self.enabled:
            return

        self._send(
            title="GitPulse — Run Failed",
            message=f"GitPulse could not complete: {error}"
        )

    def _send(self, title: str, message: str) -> None:
        """
        Sends the actual macOS notification.
        Uses pyobjc if available, falls back to terminal bell if not.
        """
        try:
            from Foundation import NSUserNotification, NSUserNotificationCenter

            notification = NSUserNotification.alloc().init()
            notification.setTitle_(title)
            notification.setInformativeText_(message)

            center = NSUserNotificationCenter.defaultUserNotificationCenter()
            center.deliverNotification_(notification)

        except ImportError:
            # pyobjc not available — just print to terminal as fallback
            print(f"\n🔔 {title}: {message}")

        except Exception:
            # notification failed silently — never crash the run
            print(f"\n{title}: {message}")
