import os
import yaml
from pathlib import Path
from gitpulse.config_schema import GitPulseConfig

CONFIG_PATH = Path.home() / ".gitpulse" / "config.yaml"

class ConfigManager:
    def __init__(self, path:Path= CONFIG_PATH):
        self.path = path

    # ------------------- LOAD -------------------- #

    def load(self) -> GitPulseConfig:
        if not self.path.exists():
            raise FileNotFoundError(
                f"Config file not found at {self.path}. "
                f"Run 'gitpulse setup' to create it."
            )
        with open(self.path, "r") as f:
            raw = yaml.safe_load(f)
            return GitPulseConfig(**raw)

    #--------------------SAVE----------------------#

    def save(self, config: GitPulseConfig) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "w") as f:
            yaml.dump(config.model_dump(), f, default_flow_style = False)
        os.chmod(self.path, 0o600)        # lock file: owner read/write only    


    #----------------------- GET / SET Individual values----------------------

    def get_value(self, key: str) -> any :
        config = self.load();
        data = config.model_dump()
        return self._get_nested(data, key.split("."))

    def set_value(self, key: str, value: str) -> None:
        config = self.load()
        data = config.model_dump()
        self._set_nested(data, key.split("."), value)
        self.save(GitPulseConfig(**data))
    
    # ── MASK SECRETS ────────────────────────────────────────────────────────

    def mask_secrets(self, config: GitPulseConfig) -> dict:
        data = config.model_dump()
        secret_keys = ["token", "api_key"] 
        return self._mask_recursive(data, secret_keys)

    def _get_nested(self, data: dict, keys: list):
        for key in keys:
            if not isinstance(data, dict) or key not in data:
                raise KeyError(f"Config key not found: {'.'.join(keys)}")
            data = data[key]
        return data

    def _set_nested(self, data: dict, keys: list, value) -> None:
        for key in keys[:-1]:             # walk to the second-to-last key
            if key not in data:
                raise KeyError(f"Config key not found: {'.'.join(keys)}")
            data = data[key]
        if keys[-1] not in data:
            raise KeyError(f"Config key not found: {'.'.join(keys)}")
        data[keys[-1]] = value            # set the final key

    def _mask_recursive(self, data: dict, secret_keys: set) -> dict:
        result = {}
        for k, v in data.items():
            if k in secret_keys:
                result[k] = "****"        # hide secret values
            elif isinstance(v, dict):
                result[k] = self._mask_recursive(v, secret_keys)  # go deeper
            else:
                result[k] = v
        return result 