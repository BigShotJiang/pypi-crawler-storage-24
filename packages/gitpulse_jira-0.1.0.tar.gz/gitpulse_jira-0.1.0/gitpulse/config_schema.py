from pydantic import BaseModel, field_validator
from typing import List
import re


class JiraConfig(BaseModel):
    url: str
    email: str
    token: str


class GeminiConfig(BaseModel):
    api_key: str
    model: str = 'gemini-2.5-flash-lite'


class GitConfig(BaseModel):
    author_email: str
    lookback_hours: int = 24


class RepoConfig(BaseModel):
    path: str


class ScheduleConfig(BaseModel):
    time: str = '18:00'

    @field_validator("time")
    @classmethod
    def must_be_valid_time(cls, v):
        if not re.match(r'^([01]?[0-9]|2[0-3]):[0-5][0-9]$', v):
            raise ValueError('Time must be in HH:mm format')
        hour, minute = v.split(":")
        if not (0 <= int(hour) <= 23 and 0 <= int(minute) <= 59):
            raise ValueError('Invalid hour or minute value')
        return v


class NotificationsConfig(BaseModel):
    macos: bool = True
    on_success: bool = True
    on_failure: bool = True


class LoggingConfig(BaseModel):
    path: str = "~/.gitpulse/run.log"
    level: str = "INFO"
    retain_days: int = 30


class GitPulseConfig(BaseModel):
    jira: JiraConfig
    gemini: GeminiConfig
    git: GitConfig
    repos: List[RepoConfig]
    project_keys: List[str]
    schedule: ScheduleConfig = ScheduleConfig()
    logging: LoggingConfig = LoggingConfig()
    notificationsConfig: NotificationsConfig = NotificationsConfig()
