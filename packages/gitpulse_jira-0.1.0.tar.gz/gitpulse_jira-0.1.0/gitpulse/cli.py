import click
from rich.console import Console
from rich.table import Table
from rich import box
from datetime import datetime, timezone
from gitpulse.config_manager import ConfigManager
from gitpulse.launch_agent import LaunchAgentManager

console = Console()

@click.group()
def main():
    """GitPulse — Automated Jira progress updater from git commits."""
    pass

# ------------ COMMAND: RUN -------------
@main.command()
def run():
    """Scan repos and post daily updates to JIRA"""
    
    from gitpulse.config_manager import ConfigManager
    from gitpulse.git_scanner import GitScanner
    from gitpulse.summarizer import GeminiSummarizer
    from gitpulse.jira_poster import JiraPoster
    from gitpulse.notifier import Notifier, RunSummary
    from gitpulse.logger import Logger
    from gitpulse.models import PostStatus

    try:
        config = ConfigManager().load()
    except FileNotFoundError as e:
        console.print(f"[red]Config not found.[/red] Run 'gitpulse setup' first.")
        raise SystemExit(1)

    # Setup logger and register secrets
    logger = Logger(
        log_path=config.logging.path,
        level=config.logging.level
    )
    logger.register_secret(config.jira.token)
    logger.register_secret(config.gemini.api_key)

    # Purge old logs
    logger.purge_old_logs(retain_days=config.logging.retain_days)

    # Notifier set up
    notifier = Notifier(enabled=config.notificationsConfig.macos)

    logger.info("GitPulse run started")
    console.print("\n[bold]GitPulse[/bold] — scanning repos...\n")

    try:
        # Step 1: Scan all the repos
        scanner = GitScanner()
        grouped_commits = scanner.scan_repos(
            repos=config.repos,
            author_email=config.git.author_email,
            lookback_hours=config.git.lookback_hours,
            project_keys=config.project_keys
        )

        if not grouped_commits:
            console.print("[yellow]No commits found in specified time range.[/yellow]")
            notifier.notify_no_updates()
            return
        
        console.print(f"Found commits for [bold]{len(grouped_commits)}[/bold] cards: "
            f"{', '.join(grouped_commits.keys())}\n")


        # Step 2: Summarize commits + Post each cards
        summarizer = GeminiSummarizer(
            api_key=config.gemini.api_key,
            model=config.gemini.model,
            logger=logger
        )

        poster = JiraPoster(
            url=config.jira.url,
            email=config.jira.email,
            token=config.jira.token,
            logger=logger
        )

        results = []

        for ticket_key, commits in grouped_commits.items():
            console.print(f"  Processing [bold]{ticket_key}[/bold] "
                          f"({len(commits)} commits)...")
            
            # Generate summary
            summary = summarizer.summarize(ticket_key, commits)

            # Post to JIRA
            result = poster.post(ticket_key, summary, commits)

            results.append(result)
            
            if result.status == PostStatus.CREATED:
                console.print(f"  [green]Posted to {ticket_key}[/green]")
                logger.info(f"Posted to {ticket_key}")
            else:
                console.print(f"  [red]Failed: {ticket_key} — {result.error}[/red]")
                logger.error(f"Failed to post to {ticket_key}: {result.error}")
        
        # Step 3: Print summary table
        _print_results_table(results)


        # Step 4: Notify
        successful = [r.ticket_key for r in results if r.status == PostStatus.CREATED]
        failed     = [r.ticket_key for r in results if r.status == PostStatus.FAILED]

        run_summary = RunSummary(
            total_cards=len(results),
            successful=successful,
            failed=failed
        )

        if failed and successful:
            notifier.notify_partial(run_summary)
        elif failed:
            notifier.notify_failure(f"{len(failed)} cards failed")
        else:
            notifier.notify_success(run_summary)

        logger.info(
            f"Run complete — {len(successful)} posted, {len(failed)} failed"
        )


    except Exception as e:
        logger.error(f"Unexpected error in run: {str(e)}")
        console.print(f"\n[red]Unexpected error:[/red] {e}")
        notifier.notify_failure(str(e))
        raise SystemExit(1)

#--------------COMMAND: SETUP ------------
@main.command()
def setup():
    """Interactive first time configuration wizard"""
    from gitpulse.setup_wizard import SetupWizard
    SetupWizard().run()

#--------------Command: STATUS ------------
@main.command()
def status():
    """Show gitpulse status and last run info"""
    from gitpulse.logger import Logger

    # launchd status
    agent_status = LaunchAgentManager().status()
    console.print("\n[bold]GitPulse Status[/bold]\n")

    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    table.add_column(style="dim", width=20)
    table.add_column()

    table.add_row(
        "LaunchAgent",
        "[green]Installed[/green]" if agent_status.installed else "[red]Not installed[/red]"
    )
    table.add_row(
        "Schedule",
        agent_status.schedule_time or "—"
    )
    table.add_row(
        "Running",
        "[green]Yes[/green]" if agent_status.running else "No"
    )
    table.add_row(
        "Plist path",
        agent_status.plist_path
    )

    console.print(table)

    try:
        config = ConfigManager().load()
        from gitpulse.logger import Logger
        logger = Logger(log_path=config.logging.path)
        recent = logger.tail(5)
        if recent:
            console.print("\n[bold]Recent log entries[/bold]\n")
            for entry in recent:
                level_color = {
                    "INFO": "blue",
                    "WARNING": "yellow",
                    "ERROR": "red"
                }.get(entry.get("level", "INFO"), "blue")

                console.print(
                    f"  [{level_color}]{entry.get('level')}[/{level_color}]  "
                    f"{entry.get('time', '')}  "
                    f"{entry.get('msg', '')}"
                )
    except FileNotFoundError:
        console.print("\n[dim]No config found — run 'gitpulse setup' first.[/dim]")

    console.print()

# ── COMMAND: config ───────────────────────────────────────────────────────────

@main.command("config")
@click.option("--set", "set_value", metavar="KEY=VALUE",
              help="Set a config value e.g. --set schedule.time=17:00")
def config_cmd(set_value):
    """Display or update config values."""

    manager = ConfigManager()

    try:
        config = manager.load()
    except FileNotFoundError:
        console.print("[red]No config found.[/red] Run 'gitpulse setup' first.")
        raise SystemExit(1)

    if set_value:
        # --set schedule.time=17:00
        if "=" not in set_value:
            console.print("[red]Invalid format.[/red] Use KEY=VALUE e.g. schedule.time=17:00")
            raise SystemExit(1)

        key, value = set_value.split("=", 1)
        try:
            manager.set_value(key, value)
            console.print(f"[green]Updated:[/green] {key} = {value}")
        except KeyError as e:
            console.print(f"[red]Invalid config key:[/red] {e}")
            raise SystemExit(1)
    else:
        # display masked config
        masked = manager.mask_secrets(config)
        console.print("\n[bold]GitPulse Config[/bold]")
        console.print(f"  [dim]Location: {manager.path}[/dim]\n")
        _print_config_dict(masked)
        console.print()

# ── COMMAND: logs ─────────────────────────────────────────────────────────────

@main.command()
@click.option("--lines", "-n", default=20, help="Number of lines to show")
def logs(lines):
    """Show recent log entries."""
    from gitpulse.config_manager import ConfigManager
    from gitpulse.logger import Logger

    try:
        config = ConfigManager().load()
    except FileNotFoundError:
        console.print("[red]No config found.[/red] Run 'gitpulse setup' first.")
        raise SystemExit(1)

    logger = Logger(log_path=config.logging.path)
    entries = logger.tail(lines)

    if not entries:
        console.print("[dim]No log entries found.[/dim]")
        return

    console.print(f"\n[bold]Last {len(entries)} log entries[/bold]\n")

    for entry in entries:
        level = entry.get("level", "INFO")
        color = {"INFO": "blue", "WARNING": "yellow", "ERROR": "red"}.get(level, "blue")
        console.print(
            f"  [{color}]{level:<8}[/{color}]  "
            f"[dim]{entry.get('time', '')}[/dim]  "
            f"{entry.get('msg', '')}"
        )

    console.print()

# ── COMMAND: schedule ─────────────────────────────────────────────────────────

@main.command()
@click.argument("time")
def schedule(time):
    """Update the daily run time. e.g. gitpulse schedule 17:00"""

    manager = ConfigManager()

    try:
        manager.set_value("schedule.time", time)
    except (FileNotFoundError, KeyError) as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    LaunchAgentManager().update_schedule(time)
    console.print(f"[green]Schedule updated to {time}[/green]")

# ── COMMAND: uninstall ────────────────────────────────────────────────────────

@main.command()
def uninstall():
    """Remove GitPulse completely — config, logs, and LaunchAgent."""
    from pathlib import Path
    import shutil

    confirmed = click.confirm(
        "This will remove all GitPulse data. Are you sure?",
        default=False
    )
    if not confirmed:
        console.print("Uninstall cancelled.")
        return

    # unload and remove launchd agent
    LaunchAgentManager().uninstall()

    # remove ~/.gitpulse/ directory
    gitpulse_dir = Path.home() / ".gitpulse"
    if gitpulse_dir.exists():
        shutil.rmtree(gitpulse_dir)
        console.print("[green]Removed ~/.gitpulse/[/green]")

    console.print("[green]GitPulse uninstalled successfully.[/green]")

# ── HELPERS ───────────────────────────────────────────────────────────────────

def _print_results_table(results) -> None:
    """Prints a summary table of all post results."""
    from gitpulse.models import PostStatus

    table = Table(
        title="Run Results",
        box=box.SIMPLE,
        show_header=True,
        header_style="bold"
    )
    table.add_column("Ticket", style="bold", width=12)
    table.add_column("Status", width=10)
    table.add_column("Details")

    for r in results:
        if r.status == PostStatus.CREATED:
            table.add_row(r.ticket_key, "[green]Posted[/green]", "")
        else:
            table.add_row(r.ticket_key, "[red]Failed[/red]", r.error or "")

    console.print()
    console.print(table)


def _print_config_dict(data: dict, indent: int = 0) -> None:
    """Recursively prints config dict with indentation."""
    for key, value in data.items():
        if isinstance(value, dict):
            console.print(f"{'  ' * indent}  [bold]{key}:[/bold]")
            _print_config_dict(value, indent + 1)
        elif isinstance(value, list):
            console.print(f"{'  ' * indent}  [bold]{key}:[/bold]")
            for item in value:
                if isinstance(item, dict):
                    _print_config_dict(item, indent + 1)
                else:
                    console.print(f"{'  ' * (indent+1)}  - {item}")
        else:
            console.print(f"{'  ' * indent}  [dim]{key}:[/dim] {value}")