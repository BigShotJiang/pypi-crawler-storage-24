from google import genai
from abc import ABC, abstractmethod
from typing import List
from gitpulse.models import Commit
from gitpulse.logger import Logger


class SummarizerBase(ABC):

    @abstractmethod
    def summarize(self, ticket_key: str, commits: List[Commit]) -> str:
        """Takes a ticket key and its commits and returns a plain english summary."""
        pass

    def _fallback_summary(self, commits: List[Commit]) -> str:
        """Used when AI is unavailable — returns a plain bullet list of commit messages."""
        lines = ["Automated progress update (AI unavailable):\n"]
        for c in commits:
            lines.append(f"  - {c.sha} | {c.message}")
        return "\n".join(lines)

    def _build_prompt(self, ticket_key: str, commits: List[Commit]) -> str:
        """Builds the prompt sent to Gemini."""
        commit_details = [
            f"- [{c.sha}] {c.message} (repo: {c.repo_path}, time: {c.timestamp})"
            for c in commits
        ]
        commits_text = "\n".join(commit_details)

        return f"""You are a helpful assistant that writes daily Jira progress updates for software developers.

Given the following git commits for ticket {ticket_key}, write a concise professional progress update suitable for a Jira comment.

Focus on:
- What was actually done (not just the commit messages verbatim)
- Any patterns across commits (e.g. testing, fixing, implementing)
- Keep it factual and professional

Commits:
{commits_text}

Write only the summary and bullet points to make it understandable, no intro or closing remarks."""


class GeminiSummarizer(SummarizerBase):
    def __init__(self, api_key: str, model: str, logger: Logger):
        self.model_name = model
        self.logger = logger
        self.logger.register_secret(api_key)
        self.client = genai.Client(api_key=api_key)

    def summarize(self, ticket_key: str, commits: List[Commit]) -> str:
        """Sends commits to Gemini and returns a plain-English summary.
        Falls back to plain text if anything goes wrong."""
        if not commits:
            return ""

        prompt = self._build_prompt(ticket_key=ticket_key, commits=commits)

        try:
            self.logger.info(f"Requesting summary for {ticket_key} ({len(commits)} commits)")
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt
            )
            summary = response.text.strip()
            self.logger.info(f"Summary generated for {ticket_key}")
            return summary
        except Exception as e:
            self.logger.warning(f"Gemini API failed for {ticket_key}: {e}. Using fallback.")
            return self._fallback_summary(commits)
