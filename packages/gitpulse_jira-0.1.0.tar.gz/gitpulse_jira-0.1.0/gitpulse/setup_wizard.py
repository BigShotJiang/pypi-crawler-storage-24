import os
import click
import httpx
from pathlib import Path
from gitpulse.config_schema import (
    GitPulseConfig, JiraConfig, GeminiConfig,
    GitConfig, RepoConfig, ScheduleConfig,
    NotificationsConfig, LoggingConfig
)
from gitpulse.config_manager import ConfigManager
from gitpulse.launch_agent import LaunchAgentManager

class SetupWizard:
    def __init__(self, config_manager: ConfigManager = None, launch_agent: LaunchAgentManager = None):
        self.config_manager = config_manager or ConfigManager()
        self.launch_agent = launch_agent or LaunchAgentManager()
    
    def run(self) -> None:
        click.echo("\n")
        click.echo("=" * 50)
        click.echo("  Welcome to GitPulse!")
        click.echo("  Let's get you configured.")
        click.echo("=" * 50)
        click.echo("\n")

        # Check if config already exists
        if self.config_manager.path.exists():
            overwrite = click.confirm("A config already exists. Do you want to over write it?", default=False)
            if not overwrite:
                click.echo("Setup cancelled")
                return

        config = self._prompt_all()
        self.config_manager.save(config)
        self.launch_agent.install(config.schedule.time)
        click.echo("\n  GitPulse is set up and scheduled. Run 'gitpulse status' to verify.\n")

    def _prompt_all(self) -> GitPulseConfig:
        # JIRA
        click.echo("\n  Jira Configuration")
        click.echo("  " + "-" * 30)
        jira_url = click.prompt("  Jira URL",
            default="https://andinolabs.atlassian.net")
        jira_email = click.prompt("  Jira email")
        jira_token = click.prompt("  Jira API token", hide_input=True)

        # validate jira credentials
        click.echo("  Validating Jira credentials...")
        while not self._validate_jira(jira_url, jira_email, jira_token):
            click.echo("  Invalid Jira credentials. Please try again.")
            jira_email = click.prompt("  Jira email")
            jira_token = click.prompt("  Jira API token", hide_input=True)
        click.echo("  Jira credentials valid!")

        # ── Gemini ────────────────────────────────────────────────────────
        click.echo("\n  Gemini Configuration")
        click.echo("  " + "-" * 30)
        click.echo("  Get your free API key at: aistudio.google.com/app/apikey")

        gemini_key = click.prompt("  Gemini API key", hide_input=True)
        gemini_model = "gemini-2.5-flash-lite"

        # validate gemini key
        click.echo("  Validating Gemini API key...")
        while not self._validate_gemini(gemini_key, gemini_model):
            click.echo("  Invalid Gemini API key. Please try again.")
            gemini_key = click.prompt("  Gemini API key", hide_input=True)
        click.echo("  Gemini API key valid!")

        # ── Git ───────────────────────────────────────────────────────────
        click.echo("\n  Git Configuration")
        click.echo("  " + "-" * 30)

        author_email = click.prompt(
            "  Your git author email",
            default=jira_email
        )

        # ── Repos ─────────────────────────────────────────────────────────
        click.echo("\n  Repositories")
        click.echo("  " + "-" * 30)
        click.echo("  Enter each repo path one by one.")
        click.echo("  Press Enter with no input when done.\n")

        repos = []
        while True:
            path = click.prompt(
                "  Repo path",
                default="",
                show_default=False
            )
            if not path:
                if not repos:
                    click.echo("  Please add at least one repo.")
                    continue
                break

            expanded = Path(path).expanduser()
            if not expanded.exists():
                click.echo(f"  Path does not exist: {path}. Try again.")
                continue
            if not (expanded / ".git").exists():
                click.echo(f"  Not a git repo: {path}. Try again.")
                continue

            repos.append(RepoConfig(path=path))
            click.echo(f"  Added: {path}")

        # ── Project keys ──────────────────────────────────────────────────
        click.echo("\n  Jira Project Keys")
        click.echo("  " + "-" * 30)

        keys_input = click.prompt(
            "  Project keys (comma separated)",
            default="PROJ"
        )
        project_keys = [k.strip().upper() for k in keys_input.split(",")]

        # ── Schedule ──────────────────────────────────────────────────────
        click.echo("\n  Schedule")
        click.echo("  " + "-" * 30)

        schedule_time = click.prompt(
            "  Daily run time (24hr format)",
            default="18:00"
        )

        # ── Notifications ─────────────────────────────────────────────────
        notifications_enabled = click.confirm(
            "\n  Enable macOS notifications?",
            default=True
        )

        return GitPulseConfig(
            jira=JiraConfig(
                url=jira_url,
                email=jira_email,
                token=jira_token
            ),
            gemini=GeminiConfig(
                api_key=gemini_key,
                model=gemini_model
            ),
            git=GitConfig(
                author_email=author_email
            ),
            repos=repos,
            project_keys=project_keys,
            schedule=ScheduleConfig(time=schedule_time),
            notificationsConfig=NotificationsConfig(
                macos=notifications_enabled,
                on_success=notifications_enabled,
                on_failure=notifications_enabled
            ),
            logging=LoggingConfig()
        )

    def _validate_jira(
        self,
        url: str,
        email: str,
        token: str
    ) -> bool:
        """
        Makes a real test call to Jira API to verify credentials.
        GET /rest/api/3/myself — returns the current user if valid.
        """
        try:
            with httpx.Client() as client:
                response = client.get(
                    f"{url.rstrip('/')}/rest/api/3/myself",
                    auth=httpx.BasicAuth(email, token),
                    timeout=10.0
                )
            return response.status_code == 200
        except Exception:
            return False

    def _validate_gemini(self, api_key: str, model: str) -> bool:
        """Makes a minimal test call to Gemini API to verify the key."""
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            response = client.models.generate_content(model=model, contents="Say OK")
            return bool(response.text)
        except Exception as e:
            err = str(e)
            if "429" in err or "RESOURCE_EXHAUSTED" in err:
                click.echo("  Quota limit reached, but your API key is valid.")
                return True
            if "401" in err or "403" in err or "API_KEY_INVALID" in err:
                click.echo(f"  Gemini error: {e}")
                return False
            click.echo(f"  Gemini error: {e}")
            return False

        