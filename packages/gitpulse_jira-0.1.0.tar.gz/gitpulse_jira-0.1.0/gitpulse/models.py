from dataclasses import dataclass
from datetime import datetime
from enum import Enum

@dataclass
class Commit:
    sha: str
    full_sha: str
    message: str
    author_email: str
    timestamp: datetime
    repo_path: str
    repo_url: str | None = None
    is_pushed: bool = False

class PostStatus(Enum):
    CREATED = 'created'
    UPDATED = 'updated'
    FAILED = 'failed'

@dataclass
class PostResult:
    ticket_key: str
    status: PostStatus
    error: str | None

