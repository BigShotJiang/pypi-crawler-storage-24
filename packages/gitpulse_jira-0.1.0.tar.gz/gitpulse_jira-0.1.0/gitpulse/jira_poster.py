import httpx
from datetime import datetime, timezone
from typing import List
from gitpulse.models import Commit, PostResult, PostStatus
from gitpulse.logger import Logger

class JiraPoster:
    def __init__(
        self,
        url:str,
        email: str,
        token: str,
        logger: Logger
    ):
        self.base_url = url.rstrip("/")
        self.email = email
        self.token = token
        self.logger = logger

        self.logger.register_secret(token)
        self.auth = httpx.BasicAuth(email, token)
    
    def post(
        self,
        ticket_key: str,
        summary: str,
        commits: List[Commit]
    ) -> PostResult:
            """
            Posts a comment on the Jira ticket.
            Always creates a new comment.
            Returns a PostResult indicating success or failure.
            """
            try:
                self._post_comment(ticket_key, summary, commits)
                self.logger.info(f"Posted comment on {ticket_key}")
                return PostResult(ticket_key, status=PostStatus.CREATED, error=None)
            
            except JiraAuthError as e:
                self.logger.error(f"Auth failed for {ticket_key}: {e}")
                return PostResult(
                    ticket_key,
                    status=PostStatus.FAILED,
                    error=str(e)
                )
            
            except Exception as e:
                self.logger.error(f"Failed to post to {ticket_key}: {e}")
                return PostResult(
                    ticket_key,
                    status=PostStatus.FAILED,
                    error=str(e)
                )

    
    def _build_comment(
        self,
        ticket_key: str,
        summary: str,
        commits: List[Commit]
    ) -> str:
        """
        Builds the comment body text.
        """
        # collect unique repos across all commits
        repos = list(set(c.repo_path for c in commits))

        # collect unique files across all commits
        # (we don't have files on Commit model yet — using repo names for now)

        # time span — first to last commit
        timestamps = sorted(c.timestamp for c in commits)
        first = timestamps[0].strftime("%H:%M")
        last  = timestamps[-1].strftime("%H:%M")

        # build commit list
        commit_lines = "\n".join(
            f"  {c.sha} | {c.message}" for c in commits
        )

        # build repo list
        repo_names = ", ".join(
            r.split("/")[-1] for r in repos   # just the folder name, not full path
        )

        now = datetime.now(timezone.utc).strftime("%d %b %Y %H:%M UTC")

        return f"""GitPulse Daily Update — {ticket_key}

            Summary:
            {summary}

            Commits ({len(commits)}):
            {commit_lines}

            Repositories: {repo_names}
            Active: {first} – {last}

            Posted automatically by GitPulse on {now}
            Any issues - Feel free to reach out to ashishbhatnagar@andinolabs.com
            """
    
    def _handle_response(self, ticket_key: str, response: httpx.Response) -> None:
        """
        Checks the HTTP response and raises appropriate errors.
        """
        if response.status_code == 201:
            return                 # 201 Created — all good

        if response.status_code in (401, 403):
            raise JiraAuthError(
                f"Authentication failed for {ticket_key}. "
                f"Check your Jira email and API token."
            )

        if response.status_code == 404:
            raise Exception(
                f"Ticket {ticket_key} not found. "
                f"Check the ticket key and Jira URL."
            )

        # any other error
        raise Exception(
            f"Jira API returned {response.status_code} for {ticket_key}"
        )
    
    def _post_comment(self, ticket_key: str, summary: str, commits: List[Commit]) -> None:

        url = f"{self.base_url}/rest/api/3/issue/{ticket_key}/comment"

        payload = {
            "body": self._build_adf(ticket_key, summary, commits)
        }

        with httpx.Client() as client:
            self.logger.debug(f"Posting comment to Jira: {url}")
            response = client.post(
                url,
                json=payload,
                auth=self.auth,
                timeout= 15.0
            )
            self.logger.debug(f"Jira API response: {response.status_code}")
            self._handle_response(ticket_key, response)
    
    def _build_adf(self, ticket_key: str, summary: str, commits: list) -> dict:
        """
        Builds a rich Atlassian Document Format body.
        Heading → summary bullets → commit code lines → metadata.
        """

        # ── heading ───────────────────────────────────────────────────────────
        heading = {
            "type": "heading",
            "attrs": {"level": 3},
            "content": [{"type": "text", "text": f"GitPulse Daily Update — {ticket_key}"}]
        }

        # ── summary section label ─────────────────────────────────────────────
        summary_label = {
            "type": "paragraph",
            "content": [{"type": "text", "text": "Summary", "marks": [{"type": "strong"}]}]
        }

        # ── summary as bullet list ─────────────────────────────────────────────
        # split summary into lines and make each a bullet
        summary_lines = [line.strip() for line in summary.split("\n") if line.strip()]
        bullet_items = [
            {
                "type": "listItem",
                "content": [{
                    "type": "paragraph",
                    "content": [{"type": "text", "text": line.lstrip("*-• ").strip()}]
                }]
            }
            for line in summary_lines
        ]

        summary_list = {
            "type": "bulletList",
            "content": bullet_items
        }

        # ── commits section label ──────────────────────────────────────────────
        commits_label = {
            "type": "paragraph",
            "content": [{
                "type": "text",
                "text": f"Commits ({len(commits)})",
                "marks": [{"type": "strong"}]
            }]
        }

        # ── each commit as a code block line ──────────────────────────────────
        commit_nodes = []
        for c in commits:
            sha_marks = [{"type": "code"}]
            if c.repo_url and c.is_pushed:
                sha_marks.append({
                    "type": "link",
                    "attrs": {"href": f"{c.repo_url}/commit/{c.full_sha}"}
                })
            commit_nodes.append({
                "type": "paragraph",
                "content": [
                    {
                        "type": "text",
                        "text": c.sha,
                        "marks": sha_marks
                    },
                    {
                        "type": "text",
                        "text": f"  |  {c.message.strip()}"
                    }
                ]
            })

        # ── metadata line ──────────────────────────────────────────────────────
        repos = list(set(c.repo_path.split("/")[-1] for c in commits))
        timestamps = sorted(c.timestamp for c in commits)
        first = timestamps[0].strftime("%H:%M")
        last  = timestamps[-1].strftime("%H:%M")
        now   = __import__('datetime').datetime.now(
            __import__('datetime').timezone.utc
        ).strftime("%d %b %Y %H:%M UTC")

        meta = {
            "type": "paragraph",
            "content": [
                {"type": "text", "text": f"Repositories: {', '.join(repos)}  |  Active: {first} – {last}",
                "marks": [{"type": "em"}]}
            ]
        }

        footer = {
            "type": "paragraph",
            "content": [
                {"type": "text", "text": f"Posted automatically by GitPulse · {now}  |  Any issues - Feel free to reach out to {self.email}",
                "marks": [{"type": "em"}]}
            ]
        }

        return {
            "type": "doc",
            "version": 1,
            "content": [
                heading,
                summary_label,
                summary_list,
                commits_label,
                *commit_nodes,
                meta,
                footer
            ]
        }

class JiraAuthError(Exception):
    """Raised when Jira returns 401 or 403."""
    pass