import subprocess
import plistlib
from dataclasses import dataclass
from pathlib import Path

PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / "com.gitpulse.agent.plist"
LABEL = "com.gitpulse.agent"

@dataclass
class LaunchAgentStatus:
    installed: bool
    running: bool
    schedule_time: str | None
    plist_path: str


class LaunchAgentManager:
    def __init__(self, plist_path: Path=PLIST_PATH):
        self.plist_path = plist_path

    def install(self, schedule_time: str) -> None:
        """
        Writes the plist file and loads it into launchd.
        schedule_time is in HH:MM format e.g. "18:00"
        """
        hour, minute = self._parse_time(schedule_time)
        self._write_plist(hour, minute)
        self._launchctl("load", str(self.plist_path))
        print(f"GitPulse scheduled daily at {schedule_time}")

    def uninstall(self) -> None:
        """
        Unloads from launchd and deletes the plist file.
        """
        if self.plist_path.exists():
            self._launchctl("unload", str(self.plist_path))
            self.plist_path.unlink()       # delete the file
            print("GitPulse LaunchAgent removed.")
        else:
            print("No LaunchAgent found — nothing to uninstall.")

    def update_schedule(self, schedule_time: str) -> None:
        """
        Changes the daily run time.
        Unloads, rewrites plist with new time, reloads.
        """
        hour, minute = self._parse_time(schedule_time)

        if self.plist_path.exists():
            self._launchctl("unload", str(self.plist_path))

        self._write_plist(hour, minute)
        self._launchctl("load", str(self.plist_path))
        print(f"Schedule updated to {schedule_time}")

    def status(self) -> LaunchAgentStatus:
        """
        Returns the current status of the LaunchAgent.
        """
        if not self.plist_path.exists():
            return LaunchAgentStatus(
                installed=False,
                running=False,
                schedule_time=None,
                plist_path=str(self.plist_path)
            )

        # read the plist to get the scheduled time
        schedule_time = self._read_schedule_from_plist()

        # check if launchd currently has it loaded
        running = self._is_loaded()

        return LaunchAgentStatus(
            installed=True,
            running=running,
            schedule_time=schedule_time,
            plist_path=str(self.plist_path)
        )

    def _write_plist(self, hour: int, minute: int) -> None:
        """
        Writes the launchd plist XML file.
        """
        import sys

        # find the full path to the gitpulse command
        gitpulse_bin = Path(sys.executable).parent / "gitpulse"

        plist_data = {
            "Label": LABEL,
            "ProgramArguments": [
                str(gitpulse_bin),
                "run"
            ],
            "StartCalendarInterval": {
                "Hour": hour,
                "Minute": minute
            },
            "StandardOutPath": str(
                Path.home() / ".gitpulse" / "launchd.out.log"
            ),
            "StandardErrorPath": str(
                Path.home() / ".gitpulse" / "launchd.err.log"
            ),
            "RunAtLoad": False          # don't run immediately on load
        }

        # create LaunchAgents directory if it doesn't exist
        self.plist_path.parent.mkdir(parents=True, exist_ok=True)

        # write plist using Python's built-in plistlib
        with open(self.plist_path, "wb") as f:
            plistlib.dump(plist_data, f)

        print(f"Plist written to {self.plist_path}")

    def _launchctl(self, *args) -> subprocess.CompletedProcess:
        """
        Runs a launchctl command.
        e.g. _launchctl("load", "/path/to/plist")
        """
        result = subprocess.run(
            ["launchctl", *args],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            raise RuntimeError(
                f"launchctl {' '.join(args)} failed: {result.stderr}"
            )

        return result

    def _parse_time(self, schedule_time: str) -> tuple[int, int]:
        """
        Parses "18:00" into (18, 0).
        """
        parts = schedule_time.split(":")
        if len(parts) != 2:
            raise ValueError(f"Invalid time format: {schedule_time}. Use HH:MM.")
        return int(parts[0]), int(parts[1])

    def _read_schedule_from_plist(self) -> str | None:
        """
        Reads the scheduled time back from the plist file.
        Returns "18:00" style string or None.
        """
        try:
            with open(self.plist_path, "rb") as f:
                data = plistlib.load(f)
            interval = data.get("StartCalendarInterval", {})
            hour = interval.get("Hour", 0)
            minute = interval.get("Minute", 0)
            return f"{hour:02d}:{minute:02d}"
        except Exception:
            return None

    def _is_loaded(self) -> bool:
        """
        Checks if the LaunchAgent is currently loaded in launchd.
        """
        try:
            result = subprocess.run(
                ["launchctl", "list", LABEL],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False
