import json
from collections import deque
from datetime import datetime, timezone
from pathlib import Path

class Logger:
    def __init__(self, log_path = "~/.gitpulse/run.log", level: str = "INFO"):
        self.log_path = Path(log_path).expanduser()
        self.level = level
        self._secrets: set = set()

    # ------------------ Secret Management -----------------
    def register_secret(self, secret: str) -> None:
        """
        Register a value that should never appear in logs.
        Call this once for each API token / password during startup.
        """
        if secret:
            self._secrets.add(secret)

    def _redact(self, message: str) -> str:
        """Remove all registered secrets from a message."""
        for secret in self._secrets:
            message = message.replace(secret, "***")
        return message
    
    # -------------------- LOGGING METHODS ----------------

    def info(self, message: str) -> None:
        self._write("INFO", message)

    def warning(self, message: str) -> None:
        self._write("WARNING", message)

    def error(self, message: str) -> None:
        self._write("ERROR", message)

    def debug(self, message: str) -> None:
        self._write("DEBUG", message)

     # ── READ LOGS ───────────────────────────────────────────────────────────

    def tail(self, n: int = 50) -> list:
        """
        Returns the last n lines from the log file as a list of dicts.
        Like the Unix tail command.
        """
        if not self.log_path.exists():
            return []

        with open(self.log_path, "r") as f:
            last_n = deque(f, maxlen=n)   # only keeps last n lines in memory

        result = []
        for line in last_n:
            try:
                result.append(json.loads(line))   # each line is a JSON object
            except json.JSONDecodeError:
                continue                           # skip malformed lines
        return result

    def purge_old_logs(self, retain_days: int = 30) -> None:
        """
        Deletes log entries older than retain_days.
        Rewrites the log file keeping only recent entries.
        """
        if not self.log_path.exists():
            return

        cutoff = datetime.now(timezone.utc).timestamp() - (retain_days * 86400)
        kept = []

        with open(self.log_path, "r") as f:
            for line in f:
                try:
                    entry = json.loads(line)
                    # keep if timestamp is recent enough
                    if entry.get("ts", 0) >= cutoff:
                        kept.append(line)
                except json.JSONDecodeError:
                    continue

        with open(self.log_path, "w") as f:
            f.writelines(kept)

    def _write(self, level: str, message: str) -> None:
        """
        Redacts the message then writes a JSON line to the log file.
        """
        safe_message = self._redact(message)

        entry = {
            "ts": datetime.now(timezone.utc).timestamp(),   # unix timestamp
            "time": datetime.now(timezone.utc).isoformat(), # human readable
            "level": level,
            "msg": safe_message
        }

        # create log directory if it doesn't exist
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

        with open(self.log_path, "a") as f:   # "a" = append, never overwrite
            f.write(json.dumps(entry) + "\n") # one JSON object per line