"""Job tools: create_job, get_job_status, get_job_messages, wait_for_job."""

from __future__ import annotations

import asyncio
import json
import time
from typing import Annotated, Optional

from mcp import types
from mcp.server.fastmcp import Context
from mcp.types import ToolAnnotations
from pydantic import Field

from hyperplexity_mcp.client import APIError, get_client
from hyperplexity_mcp.guidance import build_guidance


def register(server):

    @server.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=True))
    def create_job(
        session_id: Annotated[str, Field(description="Session ID from upload_file or confirm_upload identifying the upload session.")],
        upload_id: Annotated[Optional[str], Field(description="Upload ID from upload_file (optional if session already holds the upload).")] = None,
        config_id: Annotated[Optional[str], Field(description="ID of a known prior configuration to reuse directly.")] = None,
        config: Annotated[Optional[dict], Field(description="Validation configuration dict to apply directly.")] = None,
        s3_key: Annotated[Optional[str], Field(description="S3 key of the uploaded file.")] = None,
        notify_method: Annotated[Optional[str], Field(description='Notification method: "poll" (default) or "webhook".')] = None,
        webhook_url: Annotated[Optional[str], Field(description="Webhook URL to notify when the job completes (requires notify_method=webhook).")] = None,
    ) -> list[types.TextContent]:
        """Create a validation job.

        Always runs as a 3-row preview first — approve_validation is required
        before full processing begins.

        Provide one of:
          - config_id  — reuse a known config (fastest)
          - config     — supply a config dict directly
          - (neither)  — session must already hold a config from upload_interview

        upload_id comes from the upload_file response.
        notify_method: "poll" (default) or "webhook".
        """
        client = get_client()
        payload: dict = {"session_id": session_id, "preview_rows": 3}
        if upload_id:
            payload["upload_id"] = upload_id
        if config_id:
            payload["config_id"] = config_id
        if config is not None:
            payload["config"] = config
        if s3_key:
            payload["s3_key"] = s3_key
        if notify_method:
            payload["notify_method"] = notify_method
        if webhook_url:
            payload["webhook_url"] = webhook_url

        try:
            data = client.post("/jobs", json=payload)
        except APIError as exc:
            if "missing_config" in str(exc):
                result = {
                    "error": "missing_config",
                    "message": str(exc),
                    "session_id": session_id,
                    "_guidance": {
                        "summary": (
                            "No validation config found for this session. "
                            "This happens in two cases: "
                            "(1) Upload-interview session: config generation is still in progress — "
                            "the backend is building the validation config from the interview. "
                            "Do NOT retry create_job. "
                            "(2) Table-maker session: the table is still being built and the "
                            "preview is not yet auto-queued. "
                            "In both cases, call wait_for_job(session_id) — it detects the "
                            "intermediate phase, waits for config generation or table-making to "
                            "finish, and tracks the preview phase automatically until "
                            "preview_complete."
                        ),
                        "next_steps": [
                            {
                                "tool": "wait_for_job",
                                "params": {"job_id": session_id},
                                "note": (
                                    "Preferred: handles the config-gen → preview and "
                                    "table-maker → preview phase boundaries automatically. "
                                    "Blocks until preview_complete."
                                ),
                            }
                        ],
                    },
                }
                return [types.TextContent(type="text", text=json.dumps(result, indent=2))]
            raise

        data["_guidance"] = build_guidance("create_job", data)
        return [types.TextContent(type="text", text=json.dumps(data, indent=2))]

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True, openWorldHint=False))
    def get_job_status(job_id: Annotated[str, Field(description="Session ID / job ID returned by upload_file, confirm_upload, or start_table_maker.")]) -> list[types.TextContent]:
        """One-shot job status check. Prefer wait_for_job for tracking long-running jobs.

        Use this for quick status inspections or as a fallback when wait_for_job
        is not appropriate. For polling loops, wait_for_job is more efficient —
        it holds the connection, emits live MCP progress notifications, and handles
        the multi-phase pipeline (table-maker → preview) automatically.

        Key statuses:
          queued / processing  → call wait_for_job instead of re-polling manually
          preview_complete     → approve_validation (or refine_config)
          completed            → get_results
          failed               → check error field
        """
        client = get_client()
        data = client.get(f"/jobs/{job_id}")
        data["_guidance"] = build_guidance("get_job_status", data)
        return [types.TextContent(type="text", text=json.dumps(data, indent=2))]

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True, openWorldHint=False))
    def get_job_messages(
        job_id: Annotated[str, Field(description="Session ID / job ID to fetch progress messages for.")],
        since_seq: Annotated[Optional[int], Field(description="Return only messages with sequence number greater than this value.")] = None,
    ) -> list[types.TextContent]:
        """Fetch live progress messages for a running job.

        Pass since_seq from the last message to receive only new messages.
        """
        client = get_client()
        params = {}
        if since_seq is not None:
            params["since_seq"] = since_seq
        data = client.get(f"/jobs/{job_id}/messages", params=params or None)
        data["job_id"] = job_id  # ensure job_id present for guidance
        data["_guidance"] = build_guidance("get_job_messages", data)
        return [types.TextContent(type="text", text=json.dumps(data, indent=2))]

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True, openWorldHint=True))
    async def wait_for_job(
        job_id: Annotated[str, Field(description="Session ID returned by upload_file, confirm_upload, or start_table_maker.")],
        ctx: Context,
        timeout_seconds: Annotated[int, Field(description="Maximum wall-clock seconds to wait before returning last known state (default 900).")] = 900,
        poll_interval: Annotated[int, Field(description="Seconds between status poll cycles (default 10).")] = 10,
        warmup_seconds: Annotated[int, Field(description="Seconds of synthetic sqrt-curve progress during silent setup phases (default 0; use 300 for instructions= mode).")] = 0,
    ) -> list[types.TextContent]:
        """Wait for a job to reach a terminal state, emitting live MCP progress notifications.

        Preferred over manually looping get_job_status. The MCP host shows a live
        progress indicator while this tool holds the connection — no extra token cost.

        Architecture
        ────────────
        Every poll cycle does two things in sequence:
          1. Fetch /messages → extract native progress %, emit MCP notification
          2. Fetch /status   → act on phase transitions or terminal states

        This separation means messages drive the visual indicator (they are more
        real-time) while status is the authoritative source for workflow transitions.
        Neither endpoint is used as a shortcut to skip the other; both are polled
        every cycle so transient failures in one don't cause false terminations.

        Progress is always monotonically non-decreasing.  Within a phase,
        msg_progress can oscillate (e.g. QC triggers new row-discovery rounds in
        the table-maker), but the emitted value is clamped to last_emitted.
        Across phases a geometric slice scheme is used so the bar never goes
        backward regardless of how many phases occur.

        Progress geometry (lazy split)
        ──────────────────────────────
        Starts with the full 0–99 range so single-phase jobs (e.g. full
        validation after approve_validation) map their native 0–100% directly
        across the whole bar.  On each intermediate phase transition, 80% of
        the current range is "spent" on the completed phase and the remaining
        20% is handed to the next phase — keeping progress monotonic for any
        number of QC re-discovery rounds or pipeline stages.
        True terminal always emits exactly 100.

        Terminal states: preview_complete, failed, completed-without-intermediate-step.
        Intermediate:    completed + current_step in (Config Generation, Table Making,
                         Claim Extraction, …) — tool advances phase and keeps polling.

        Returns the same payload shape as get_job_status so downstream tools
        (approve_validation, get_results, etc.) apply directly.

        job_id: the session_id value returned by upload_file / confirm_upload /
          start_table_maker. "job_id" and "session_id" are the same string — every
          workflow uses session_id as its job identifier throughout the pipeline.
        timeout_seconds: max wall time before returning last known state (default 900).
          Upload-interview + config-gen phases and large table previews can take up
          to 15 minutes — set timeout_seconds=900 or higher for long-running jobs.
        poll_interval:   seconds between poll cycles (default 10)
        warmup_seconds:  when > 0, applies synthetic sqrt-curve progress from 0→70%
          over this many seconds during the pre-message phase (before the first
          progress message or intermediate step arrives). Use this when the pipeline
          has a silent setup phase (e.g. instructions= mode where the backend runs
          an internal AI interview + config generation before preview messages begin).
          The warmup is automatically disabled once the first intermediate step
          completes (phase-split takes over). For instructions= mode, pass 300.
        """
        client = get_client()
        # ── Helpers: phase and terminal classification ────────────────────────

        # Step names (lowercased) embedded in current_step that mark an
        # intermediate completed state (generator phase done, next pipeline
        # stage not yet started).  Lowercase comparison avoids mismatches like
        # "Config Generation" vs "Configuration generation completed…" (Issue #1).
        _INTERMEDIATE_STEPS = (
            "config generation",
            "configuration generation",
            "table making",
            "table maker",
            "claim extraction",
        )

        # Track the last current_step that triggered a phase split so that a
        # stuck status endpoint returning the same stale response doesn't keep
        # re-splitting the progress range on every poll cycle.
        _last_intermediate_step: list = [None]

        def _is_intermediate_complete(d: dict) -> bool:
            if d.get("status") != "completed":
                return False
            step = (d.get("current_step") or d.get("step") or "").lower()
            return any(s in step for s in _INTERMEDIATE_STEPS)

        def _is_true_terminal(d: dict) -> bool:
            status = d.get("status", "")
            if status in ("preview_complete", "failed"):
                return True
            if status == "completed" and not _is_intermediate_complete(d):
                return True
            return False

        # ── Helpers: progress geometry ────────────────────────────────────────
        #
        # Lazy-split approach: start with the full 0–99 range so that
        # single-phase jobs (e.g. full validation after approve_validation)
        # map their native 0–100% progress directly across the whole bar.
        # Only when an intermediate phase transition is detected do we
        # "spend" 80% of the current range on the completed phase and hand
        # the remaining 20% to the next phase.  This ensures:
        #   • Validation (always the last phase) always uses the full range.
        #   • Multi-phase compound jobs (table-maker → preview) still produce
        #     monotonically non-decreasing progress.
        #   • Unbounded QC re-discovery rounds within a phase are handled by
        #     last_emitted clamping rather than pre-allocated geometry.

        # Mutable range for the current phase; updated on intermediate transitions.
        # These are captured by the `if _is_intermediate_complete` block below.
        _pf: list = [0.0]   # phase_floor (use list so inner references stay valid)
        _pc: list = [99.0]  # phase_ceiling

        def _scale_to_range(phase_pct: float) -> float:
            """Map a within-phase 0–100 value into [phase_floor, phase_ceiling]."""
            clamped = min(max(phase_pct, 0.0), 99.0)
            return _pf[0] + (clamped / 100.0) * (_pc[0] - _pf[0])

        # ── Helpers: async I/O ────────────────────────────────────────────────

        last_seq: Optional[int] = None
        _cursor_primed: bool = False  # True after the first fetch has advanced last_seq

        def _extract_progress(messages: list) -> Optional[float]:
            """Return the latest progress % from message payloads, or None.

            Uses an explicit key-in check so that progress=0 (a valid value at
            the start of a new sub-task) is never silently dropped by an or-chain.
            """
            for msg in reversed(messages):
                payload = msg.get("message_data") or msg.get("data") or {}
                if isinstance(payload, dict):
                    for key in ("progress", "percent", "progress_percent", "value"):
                        if key in payload:
                            return float(payload[key])
            return None

        async def _fetch_messages() -> list:
            """Fetch messages since last_seq.

            The first call (last_seq=None) advances the cursor to the current
            tail of the log without returning those messages for progress use.
            This prevents stale messages from a previous phase (e.g. a preview
            completion at 100%) from poisoning last_emitted at the start of a
            new wait_for_job invocation (e.g. full validation after approval).
            """
            nonlocal last_seq, _cursor_primed
            # Use a lambda so asyncio.to_thread passes params unambiguously.
            params = {"since_seq": last_seq} if last_seq is not None else None
            resp = await asyncio.to_thread(
                lambda: client.get(f"/jobs/{job_id}/messages", params)
            )
            messages = resp.get("messages") or []
            new_seq = resp.get("last_seq")
            if new_seq is None and messages:
                new_seq = messages[-1].get("_seq") or messages[-1].get("seq")
            if new_seq is not None:
                last_seq = new_seq
            if not _cursor_primed:
                # Cursor is now at the current tail; discard this batch so old
                # phase messages don't influence last_emitted.
                _cursor_primed = True
                return []
            return messages

        async def _fetch_status() -> dict:
            return await asyncio.to_thread(client.get, f"/jobs/{job_id}")

        async def _report(progress: float) -> None:
            try:
                await ctx.report_progress(progress, 100.0)
            except Exception:
                pass

        # ── Main loop state ───────────────────────────────────────────────────

        deadline = time.monotonic() + timeout_seconds
        _warmup_start: float = time.monotonic()
        msg_progress: float = 2.0  # latest within-phase progress % from messages
        last_emitted: float = 0.0  # monotonic floor — never report below this
        data: dict = {}

        while True:
            # ── 1. Poll messages → update within-phase progress ───────────────
            try:
                messages = await _fetch_messages()
                if messages:
                    extracted = _extract_progress(messages)
                    if extracted is not None:
                        msg_progress = extracted
            except Exception:
                pass  # transient message-endpoint failure; keep going

            # ── 2. Emit monotonically non-decreasing progress notification ────
            # Within a phase, msg_progress can dip (e.g. QC restarts row
            # discovery in the table-maker).  last_emitted ensures the bar never
            # visually regresses.
            #
            # Synthetic warmup: when warmup_seconds > 0 and no intermediate
            # phase has completed yet (_pf[0] still at 0), advance msg_progress
            # along a sqrt curve toward 70% over warmup_seconds.  This covers
            # silent setup phases (internal AI interview + config generation)
            # where no progress messages arrive for several minutes.  Once the
            # first intermediate step completes and the phase-split kicks in
            # (_pf[0] > 0), warmup is disabled and real message tracking takes over.
            if warmup_seconds > 0 and _pf[0] < 1.0:
                elapsed_w = time.monotonic() - _warmup_start
                warmup_pct = min(70.0, (elapsed_w / warmup_seconds) ** 0.5 * 70.0)
                if warmup_pct > msg_progress:
                    msg_progress = warmup_pct

            candidate = _scale_to_range(max(msg_progress, 2.0))
            emit_pct = max(candidate, last_emitted)
            last_emitted = emit_pct
            await _report(emit_pct)

            # ── 3. Poll status → authoritative source for transitions ─────────
            # Status is polled every cycle (not only when messages look done) so
            # a network hiccup on the message endpoint never causes a missed
            # terminal state, and a transient 100% message value never causes a
            # false completion.
            #
            # Architecture note: during full validation the interface Lambda is
            # not active — the validation Lambda runs async and writes status and
            # messages directly to DynamoDB.  The REST API reads DynamoDB, so
            # polling works correctly regardless of which Lambda is live.
            try:
                data = await _fetch_status()

                if _is_intermediate_complete(data):
                    # Generator phase done (e.g. table-maker finished, preview
                    # about to start).  Apply a lazy split: "spend" 80% of the
                    # current range on the completed phase and give the remainder
                    # to the next phase.  This keeps progress monotonic while
                    # ensuring the final phase (validation) always uses whatever
                    # range is left — usually the full 0–99 if this is the only
                    # transition seen.
                    #
                    # Only apply the phase split if this is a NEW intermediate
                    # step — if the status endpoint is stuck returning the same
                    # stale "completed / Config Generation" response on every
                    # poll, skip the split to prevent the range from converging
                    # toward 99% without the job actually advancing (Issue #2).
                    #
                    # Do NOT reset last_seq — keep consuming new messages from
                    # where we are; resetting would replay stale messages and
                    # re-trigger this block.
                    current_step_key = (data.get("current_step") or "").lower()
                    if current_step_key != _last_intermediate_step[0]:
                        _last_intermediate_step[0] = current_step_key
                        spend = _pf[0] + (_pc[0] - _pf[0]) * 0.8   # 80% of range used
                        new_floor = max(spend, last_emitted + 0.5)   # never regress
                        new_floor = min(new_floor, _pc[0] - 1.0)     # always leave room
                        _pf[0] = new_floor
                        # _pc[0] stays at 99 — the next phase inherits the rest
                        msg_progress = 2.0

                elif _is_true_terminal(data):
                    await _report(100.0)
                    data["_guidance"] = build_guidance("get_job_status", data)
                    return [types.TextContent(type="text", text=json.dumps(data, indent=2))]

            except Exception:
                pass  # transient status-endpoint failure; keep polling

            # ── 4. Timeout guard ──────────────────────────────────────────────
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                if not data:
                    data = {"job_id": job_id, "status": "unknown"}
                data["_guidance"] = build_guidance("get_job_status", data)
                data["_wait_timeout"] = (
                    f"wait_for_job timed out after {timeout_seconds}s. "
                    "The job is still running — this is normal for complex research requests. "
                    "Call wait_for_job again to continue tracking (it will resume from where "
                    "it left off). For table-maker jobs, slow runs can take 25–35 minutes total."
                )
                return [types.TextContent(type="text", text=json.dumps(data, indent=2))]

            await asyncio.sleep(min(float(poll_interval), remaining))
