import http.server
import socketserver
import urllib.parse
import os
import zipfile
import tempfile
import shutil
import json
import socket
import sys

# Port range
PORT_START = 7701
PORT_END = 7799

# Get the directory of this script to find viewer.html
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
VIEWER_HTML_PATH = os.path.join(PACKAGE_DIR, 'viewer.html')

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        
        # API: Download
        if parsed_path.path == '/api/download':
            query = urllib.parse.parse_qs(parsed_path.query)
            dir_name = query.get('dir', [''])[0]
            dir_name = os.path.normpath(urllib.parse.unquote(dir_name)).lstrip('/')
            
            if not dir_name or dir_name == '.' or dir_name == '':
                target_dir = '.'
                download_name = 'root_directory.zip'
            else:
                target_dir = urllib.parse.unquote(dir_name)
                download_name = f"{os.path.basename(target_dir.rstrip('/'))}.zip"

            if not os.path.exists(target_dir) or not os.path.isdir(target_dir):
                self.send_error(404, "Directory not found")
                return

            fd, temp_path = tempfile.mkstemp(suffix='.zip')
            os.close(fd)
            
            try:
                with zipfile.ZipFile(temp_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                    for root, dirs, files in os.walk(target_dir):
                        dirs[:] = [d for d in dirs if not d.startswith('.')]
                        for file in files:
                            if file.startswith('.'): continue
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, '.' if target_dir == '.' else target_dir)
                            zf.write(file_path, arcname)
                
                file_size = os.path.getsize(temp_path)
                self.send_response(200)
                self.send_header('Content-Type', 'application/zip')
                self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
                self.send_header('Content-Length', str(file_size))
                self.end_headers()
                
                with open(temp_path, 'rb') as f:
                    shutil.copyfileobj(f, self.wfile)
            except BrokenPipeError:
                pass
            finally:
                if os.path.exists(temp_path):
                    os.remove(temp_path)

        # API: Download Single File
        elif parsed_path.path == '/api/download_single':
            query = urllib.parse.parse_qs(parsed_path.query)
            file_path = query.get('path', [''])[0]
            target_file = urllib.parse.unquote(file_path).lstrip('/')

            if not os.path.exists(target_file) or not os.path.isfile(target_file):
                self.send_error(404, "File not found")
                return

            try:
                file_size = os.path.getsize(target_file)
                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition', f'attachment; filename="{os.path.basename(target_file)}"')
                self.send_header('Content-Length', str(file_size))
                self.end_headers()
                
                with open(target_file, 'rb') as f:
                    shutil.copyfileobj(f, self.wfile)
            except BrokenPipeError:
                pass
            except Exception as e:
                self.send_error(500, str(e))

        # API: List
        elif parsed_path.path == '/api/list':
            query = urllib.parse.parse_qs(parsed_path.query)
            path = query.get('path', [''])[0]
            unquoted_path = urllib.parse.unquote(path)
            
            if unquoted_path == '~' or unquoted_path.startswith('~/'):
                target_dir = os.path.expanduser(unquoted_path)
            elif os.path.isabs(unquoted_path):
                target_dir = unquoted_path
            else:
                safe_path = os.path.normpath(unquoted_path).lstrip('/')
                target_dir = '.' if (safe_path == '.' or safe_path == '') else safe_path

            if not os.path.exists(target_dir) or not os.path.isdir(target_dir):
                self.send_error(404, "Directory not found")
                return

            try:
                items = []
                for entry in os.scandir(target_dir):
                    if entry.name.startswith('.'): continue
                    stats = entry.stat()
                    items.append({
                        'name': entry.name,
                        'is_dir': entry.is_dir(),
                        'size': stats.st_size if entry.is_file() else 0,
                        'mtime': stats.st_mtime,
                        'ext': os.path.splitext(entry.name)[1].lower() if entry.is_file() else ''
                    })
                items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
                response_data = json.dumps(items).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(response_data)))
                self.end_headers()
                self.wfile.write(response_data)
            except Exception as e:
                self.send_error(500, str(e))

        # Default Serving
        else:
            if parsed_path.path == '/' or parsed_path.path == '/viewer.html':
                # Serve viewer.html from the package directory
                try:
                    with open(VIEWER_HTML_PATH, 'rb') as f:
                        content = f.read()
                        self.send_response(200)
                        self.send_header('Content-Type', 'text/html')
                        self.send_header('Content-Length', str(len(content)))
                        self.end_headers()
                        self.wfile.write(content)
                        return
                except Exception as e:
                    self.send_error(404, f"viewer.html not found: {e}")
                    return
            
            # Fall back to standard file serving from CWD
            try:
                super().do_GET()
            except BrokenPipeError:
                pass

def main():
    socketserver.TCPServer.allow_reuse_address = True
    
    server = None
    applied_port = None
    
    for port in range(PORT_START, PORT_END + 1):
        try:
            server = socketserver.TCPServer(("", port), CustomHandler)
            applied_port = port
            break
        except socket.error:
            continue
            
    if not server:
        print(f"Error: All ports in range {PORT_START}-{PORT_END} are occupied.")
        sys.exit(1)
        
    with server:
        print(f"GalleryView Explorer started at http://localhost:{applied_port}")
        print(f"Serving files from: {os.getcwd()}")
        print("To stop, press Ctrl+C")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        print("\nServer stopped.")

if __name__ == "__main__":
    main()
