# Universal Gallery Explorer

A premium, high-speed gallery for images, videos, audio, and code that you can run from any directory.

Created by **Muhammad Ahmed**
GitHub: [muhammad-ahmed-ghani](https://github.com/muhammad-ahmed-ghani)

## Installation

### Local Development
To install the package locally from source:

```bash
cd galleryview_pkg
pip install -e .
```
*Note: Using `-e` (editable) is recommended during development.*

### From PyPI (Once uploaded)
```bash
pip install galleryview-explorer
```

## Usage

Run the following command in any directory containing images:

```bash
galleryview
```

The server will automatically find an available port in the range 7701-7799.

## How to upload to PyPI

Follow these exact steps to share your package with the world:

### 1. Create a PyPI Account
If you haven't already, create an account on [PyPI (pypi.org)](https://pypi.org/account/register/).

### 2. Generate an API Token
- Go to [Account Settings](https://pypi.org/manage/account/) on PyPI.
- Scroll down to "API tokens" and click "Add API token".
- Give it a name (e.g., "galleryview-token") and set the scope to "Entire account".
- **Copy the token immediately** (it starts with `pypi-`). You will need it later.

### 3. Install Build and Upload Tools
```bash
pip install build twine
```

### 4. Build the Package
Run this from the `/home/ubuntu/ahmed/galleryview_pkg` directory:
```bash
python3 -m build
```
This will create a `dist/` directory containing:
- `galleryview_explorer-0.2.0-py3-none-any.whl` (Built Distribution)
- `galleryview_explorer-0.2.0.tar.gz` (Source Archive)

### 5. Upload to PyPI
Run the following command:
```bash
python3 -m twine upload dist/*
```
- **Username**: Use `__token__`
- **Password**: Paste your API token (including the `pypi-` prefix)

### 6. Verify
Once uploaded, anyone can install it using:
`pip install galleryview-explorer`
