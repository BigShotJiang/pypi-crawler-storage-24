"""
Utilities Module

提供辅助函数和工具类。
"""

import json
import re
from typing import Any, Dict, List, Optional, Union


def validate_pipeline(pipeline: List[Dict[str, Any]]) -> tuple:
    """
    验证聚合管道格式。
    
    Args:
        pipeline: MongoDB 聚合管道
        
    Returns:
        (is_valid, errors) 元组
        
    示例:
        >>> pipeline = [{ "$match": { "status": "active" } }]
        >>> is_valid, errors = validate_pipeline(pipeline)
        >>> print(is_valid)  # True
    """
    errors = []
    
    if not isinstance(pipeline, list):
        return False, ["Pipeline must be a list"]
    
    if not pipeline:
        return True, []  # 空管道是有效的
    
    valid_stages = {
        '$match', '$project', '$group', '$sort', '$limit', '$skip',
        '$lookup', '$unwind', '$facet', '$bucket', '$bucketAuto',
        '$collStats', '$count', '$currentOp', '$graphLookup',
        '$indexStats', '$listLocalSessions', '$listSessions',
        '$out', '$redact', '$replaceRoot', '$sample'
    }
    
    for index, stage in enumerate(pipeline):
        # 检查阶段类型
        if not isinstance(stage, dict):
            errors.append(f"Stage {index}: Expected dict, got {type(stage).__name__}")
            continue
        
        # 检查阶段数量
        if len(stage) == 0:
            errors.append(f"Stage {index}: Empty stage")
            continue
        
        if len(stage) > 1:
            errors.append(f"Stage {index}: Multiple stage operators in one stage")
            continue
        
        # 获取阶段名称
        stage_name = list(stage.keys())[0]
        
        # 检查阶段名称格式
        if not stage_name.startswith('$'):
            errors.append(f"Stage {index}: Stage name must start with '$', got '{stage_name}'")
            continue
        
        # 检查阶段是否受支持（可选）
        if stage_name not in valid_stages:
            errors.append(f"Stage {index}: Unknown stage '{stage_name}'")
    
    return len(errors) == 0, errors


def format_sql(sql: str, uppercase_keywords: bool = True) -> str:
    """
    格式化 SQL 语句。
    
    Args:
        sql: SQL 语句
        uppercase_keywords: 是否将关键字转换为大写
        
    Returns:
        格式化后的 SQL
        
    示例:
        >>> sql = 'select * from users where id = 1'
        >>> print(format_sql(sql))
        SELECT 
            *
        FROM users 
        WHERE 1=1
         AND id = 1
    """
    # 关键字列表
    keywords = [
        'select', 'from', 'where', 'group by', 'having', 'order by',
        'limit', 'offset', 'join', 'left join', 'right join', 'inner join',
        'cross join', 'on', 'and', 'or', 'not', 'null', 'is', 'as',
        'with', 'union', 'all', 'distinct', 'case', 'when', 'then', 'else', 'end',
        'insert', 'update', 'delete', 'create', 'drop', 'alter', 'table',
        'index', 'view', 'trigger', 'values', 'set', 'into'
    ]
    
    formatted = sql
    
    # 转换关键字为大写
    if uppercase_keywords:
        for keyword in keywords:
            # 使用正则表达式匹配完整单词
            pattern = r'\b' + re.escape(keyword) + r'\b'
            formatted = re.sub(pattern, keyword.upper(), formatted, flags=re.IGNORECASE)
    
    # 添加适当的换行和缩进
    formatted = _add_line_breaks(formatted)
    
    return formatted


def _add_line_breaks(sql: str) -> str:
    """
    为 SQL 添加适当的换行和缩进。
    
    Args:
        sql: SQL 语句
        
    Returns:
        格式化后的 SQL
    """
    # 在主要关键字前添加换行
    keywords_with_newline = [
        'SELECT', 'FROM', 'WHERE', 'GROUP BY', 'HAVING', 'ORDER BY',
        'LIMIT', 'OFFSET', 'UNION', 'INTERSECT', 'EXCEPT'
    ]
    
    result = sql
    
    for keyword in keywords_with_newline:
        pattern = r'\s+' + re.escape(keyword) + r'\s+'
        replacement = f'\n{keyword} '
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
    
    # 处理 JOIN
    join_pattern = r'\s+(LEFT|RIGHT|INNER|OUTER|CROSS|FULL)\s+JOIN\s+'
    result = re.sub(join_pattern, r'\n\1 JOIN ', result, flags=re.IGNORECASE)
    
    # 处理 ON
    result = re.sub(r'\s+ON\s+', '\n  ON ', result, flags=re.IGNORECASE)
    
    # 处理 AND/OR（在 WHERE 子句中）
    result = re.sub(r'\s+AND\s+', '\n  AND ', result, flags=re.IGNORECASE)
    result = re.sub(r'\s+OR\s+', '\n  OR ', result, flags=re.IGNORECASE)
    
    # 处理 SELECT 子句中的逗号（每个列占一行）
    # 只在SELECT部分应用此格式化
    lines = result.split('\n')
    formatted_lines = []
    in_select = False
    for line in lines:
        if 'SELECT' in line.upper():
            in_select = True
            formatted_lines.append(line)
        elif 'FROM' in line.upper():
            in_select = False
            formatted_lines.append(line)
        elif in_select and ',' in line:
            # 将逗号分隔的列拆分成多行
            parts = line.split(',')
            for i, part in enumerate(parts):
                if i == 0:
                    formatted_lines.append(part.strip())
                else:
                    formatted_lines.append('    ' + part.strip())
        else:
            formatted_lines.append(line)
    
    result = '\n'.join(formatted_lines)
    
    return result.strip()


def escape_sql_string(value: str, dialect: str = 'sqlite') -> str:
    """
    转义 SQL 字符串值。
    
    Args:
        value: 字符串值
        dialect: SQL 方言
        
    Returns:
        转义后的字符串
    """
    if dialect in ('sqlite', 'postgresql', 'mysql'):
        return value.replace("'", "''")
    
    return value


def quote_identifier(identifier: str, dialect: str = 'sqlite') -> str:
    """
    引用 SQL 标识符。
    
    Args:
        identifier: 标识符（表名、列名等）
        dialect: SQL 方言
        
    Returns:
        引用的标识符
    """
    # 处理带点的标识符（如 table.column）
    if '.' in identifier:
        parts = identifier.split('.')
        return '.'.join(quote_identifier(part, dialect) for part in parts)
    
    # 根据请求，不添加任何引号
    return identifier


def parse_mongo_query(query: Dict[str, Any]) -> Dict[str, Any]:
    """
    解析 MongoDB 查询文档。
    
    Args:
        query: MongoDB 查询文档
        
    Returns:
        解析后的查询信息
    """
    result = {
        'fields': [],
        'operators': [],
        'conditions': []
    }
    
    for key, value in query.items():
        if key.startswith('$'):
            # 顶级操作符
            result['operators'].append({
                'operator': key,
                'value': value
            })
        else:
            # 字段条件
            result['fields'].append(key)
            
            if isinstance(value, dict):
                # 操作符条件
                for op, op_value in value.items():
                    result['conditions'].append({
                        'field': key,
                        'operator': op,
                        'value': op_value
                    })
            else:
                # 相等条件
                result['conditions'].append({
                    'field': key,
                    'operator': '$eq',
                    'value': value
                })
    
    return result


def convert_value_to_sql(value: Any, dialect: str = 'sqlite') -> str:
    """
    将 Python 值转换为 SQL 字面量。
    
    Args:
        value: Python 值
        dialect: SQL 方言
        
    Returns:
        SQL 字面量字符串
    """
    if value is None:
        return 'NULL'
    elif isinstance(value, bool):
        return 'TRUE' if value else 'FALSE'
    elif isinstance(value, (int, float)):
        return str(value)
    elif isinstance(value, str):
        escaped = escape_sql_string(value, dialect)
        return f"'{escaped}'"
    elif isinstance(value, list):
        items = [convert_value_to_sql(item, dialect) for item in value]
        return f"({', '.join(items)})"
    elif isinstance(value, dict):
        json_str = json.dumps(value)
        escaped = escape_sql_string(json_str, dialect)
        return f"'{escaped}'"
    else:
        return f"'{str(value)}'"


def is_comparison_operator(operator: str) -> bool:
    """
    检查是否是比较操作符。
    
    Args:
        operator: 操作符名称
        
    Returns:
        是否是比较操作符
    """
    comparison_ops = {'$eq', '$ne', '$gt', '$gte', '$lt', '$lte', '$in', '$nin'}
    return operator in comparison_ops


def is_logical_operator(operator: str) -> bool:
    """
    检查是否是逻辑操作符。
    
    Args:
        operator: 操作符名称
        
    Returns:
        是否是逻辑操作符
    """
    logical_ops = {'$and', '$or', '$nor', '$not'}
    return operator in logical_ops


def is_aggregation_operator(operator: str) -> bool:
    """
    检查是否是聚合操作符。
    
    Args:
        operator: 操作符名称
        
    Returns:
        是否是聚合操作符
    """
    agg_ops = {'$sum', '$avg', '$min', '$max', '$count', '$first', '$last', '$push', '$addToSet'}
    return operator in agg_ops


def merge_conditions(conditions: List[str], operator: str = 'AND') -> str:
    """
    合并多个条件。
    
    Args:
        conditions: 条件列表
        operator: 连接操作符（AND 或 OR）
        
    Returns:
        合并后的条件
        
    示例:
        >>> conditions = ['a = 1', 'b = 2']
        >>> print(merge_conditions(conditions))
        (a = 1) AND (b = 2)
    """
    if not conditions:
        return ''
    
    if len(conditions) == 1:
        return conditions[0]
    
    # 为每个条件添加括号
    wrapped = [f"({cond})" for cond in conditions]
    
    return f' {operator} '.join(wrapped)


class SQLBuilder:
    """
    SQL 查询构建器。
    
    提供流畅的接口来构建 SQL 查询。
    
    示例:
        >>> builder = SQLBuilder()
        >>> sql = (builder
        ...     .select('name', 'age')
        ...     .from_table('users')
        ...     .where(status = active)
        ...     .order_by('age', 'DESC')
        ...     .limit(10)
        ...     .build())
        >>> print(sql)
        SELECT 
            name,
            age
        FROM users AS t
        WHERE 1=1
            AND status = 'active'
        ORDER BY age DESC
        LIMIT 10
    """
    
    def __init__(self, dialect: str = 'sqlite'):
        """
        初始化 SQL 构建器。
        
        Args:
            dialect: SQL 方言
        """
        self.dialect = dialect
        self.parts = {
            'select': [],
            'from': '',
            'joins': [],
            'where': [],
            'group_by': [],
            'having': [],
            'order_by': [],
            'limit': None,
            'offset': None,
        }
    
    def select(self, *columns: str) -> 'SQLBuilder':
        """添加 SELECT 列。"""
        self.parts['select'].extend(columns)
        return self
    
    def select_distinct(self, *columns: str) -> 'SQLBuilder':
        """添加 DISTINCT SELECT 列。"""
        self.parts['select'].extend(columns)
        self.parts['distinct'] = True
        return self
    
    def from_table(self, table: str, alias: Optional[str] = None) -> 'SQLBuilder':
        """设置 FROM 表。"""
        self.parts['from'] = f'{table}' + (f' AS {alias}' if alias else '')
        return self
    
    def join(self, table: str, condition: str, alias: Optional[str] = None, join_type: str = 'INNER') -> 'SQLBuilder':
        """添加 JOIN。"""
        join_sql = f'{join_type} JOIN {table}'
        if alias:
            join_sql += f' AS {alias}'
        join_sql += f' ON {condition}'
        self.parts['joins'].append(join_sql)
        return self
    
    def left_join(self, table: str, condition: str, alias: Optional[str] = None) -> 'SQLBuilder':
        """添加 LEFT JOIN。"""
        return self.join(table, condition, alias, 'LEFT')
    
    def where(self, condition: str) -> 'SQLBuilder':
        """添加 WHERE 条件。"""
        self.parts['where'].append(condition)
        return self
    
    def group_by(self, *columns: str) -> 'SQLBuilder':
        """添加 GROUP BY 列。"""
        self.parts['group_by'].extend(columns)
        return self
    
    def having(self, condition: str) -> 'SQLBuilder':
        """添加 HAVING 条件。"""
        self.parts['having'].append(condition)
        return self
    
    def order_by(self, column: str, direction: str = 'ASC') -> 'SQLBuilder':
        """添加 ORDER BY 列。"""
        self.parts['order_by'].append(f'{column} {direction}')
        return self
    
    def limit(self, n: int) -> 'SQLBuilder':
        """设置 LIMIT。"""
        self.parts['limit'] = n
        return self
    
    def offset(self, n: int) -> 'SQLBuilder':
        """设置 OFFSET。"""
        self.parts['offset'] = n
        return self
    
    def build(self) -> str:
        """构建 SQL 查询。"""
        parts = []
        
        # SELECT
        select_clause = 'SELECT'
        if self.parts.get('distinct'):
            select_clause += ' DISTINCT'
        
        if self.parts['select']:
            # 格式化SELECT子句，每列占一行
            if len(self.parts['select']) == 1:
                select_clause += ' ' + self.parts['select'][0]
            else:
                select_clause += '\n    ' + ',\n    '.join(self.parts['select'])
        else:
            select_clause += ' *'
        parts.append(select_clause)
        
        # FROM
        if self.parts['from']:
            parts.append(f'FROM {self.parts["from"]}')
        
        # JOINs
        if self.parts['joins']:
            parts.extend(self.parts['joins'])
        
        # WHERE
        if self.parts['where']:
            # 统一添加 1=1 作为第一个条件
            where_conditions = ['1=1'] + self.parts['where']
            if len(where_conditions) == 1:
                parts.append('WHERE ' + where_conditions[0])
            else:
                # 多个WHERE条件，每个条件占一行，用\n分割
                where_clause = 'WHERE ' + where_conditions[0]
                for condition in where_conditions[1:]:
                    where_clause += '\n    AND ' + condition
                parts.append(where_clause)
        
        # GROUP BY
        if self.parts['group_by']:
            parts.append('GROUP BY ' + ', '.join(self.parts['group_by']))
        
        # HAVING
        if self.parts['having']:
            parts.append('HAVING ' + ' AND '.join(self.parts['having']))
        
        # ORDER BY
        if self.parts['order_by']:
            parts.append('ORDER BY ' + ', '.join(self.parts['order_by']))
        
        # LIMIT
        if self.parts['limit'] is not None:
            parts.append(f'LIMIT {self.parts["limit"]}')
        
        # OFFSET
        if self.parts['offset'] is not None:
            parts.append(f'OFFSET {self.parts["offset"]}')
        
        return '\n'.join(parts)
