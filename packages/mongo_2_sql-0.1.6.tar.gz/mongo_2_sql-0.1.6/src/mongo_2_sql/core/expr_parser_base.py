"""
Base Expression Parser Module

提供所有stage表达式的通用解析功能。
各stage的expr模块可以继承这个基类来减少代码重复。
"""

from typing import Any, Dict, List, Optional, Set

from ..core.expr_base import (
    BaseExpression,
    BinaryOperation,
    FieldReference,
    FunctionCall,
    LiteralValue,
)
from .stage_base import RenderContext


class BaseExpressionParser:
    """
    基础表达式解析器。
    
    提供所有stage表达式解析的通用功能：
    - 通用操作符集合
    - 字段引用解析
    - 值转换
    - 基础操作符处理
    """

    # ==================== 通用操作符集合 ====================
    
    # 比较操作符 - 所有stage都可能使用
    COMPARISON_OPERATORS: Set[str] = {
        '$eq', '$ne', '$gt', '$gte', '$lt', '$lte', '$in', '$nin'
    }
    
    # 逻辑操作符
    LOGICAL_OPERATORS: Set[str] = {
        '$and', '$or', '$nor', '$not'
    }
    
    # 算术操作符
    ARITHMETIC_OPERATORS: Set[str] = {
        '$add', '$subtract', '$multiply', '$divide', '$mod'
    }
    
    # 字符串操作符
    STRING_OPERATORS: Set[str] = {
        '$concat', '$substr', '$toLower', '$toUpper', '$trim'
    }
    
    # 日期操作符
    DATE_OPERATORS: Set[str] = {
        '$year', '$month', '$dayOfMonth', '$hour', '$minute', '$second', '$dateToString'
    }
    
    # 条件操作符
    CONDITIONAL_OPERATORS: Set[str] = {
        '$cond', '$ifNull', '$switch'
    }
    
    # 数组操作符
    ARRAY_OPERATORS: Set[str] = {
        '$size', '$slice', '$arrayElemAt'
    }
    
    # 累加器操作符（主要用于group）
    ACCUMULATORS: Set[str] = {
        '$sum', '$avg', '$min', '$max', '$count',
        '$first', '$last', '$push', '$addToSet',
        '$stdDevPop', '$stdDevSamp'
    }
    
    # 字面量操作符
    LITERAL_OPERATOR: str = '$literal'

    # ==================== 通用方法 ====================

    @classmethod
    def _value_to_sql(cls, value: Any) -> str:
        """
        将值转换为SQL字面量。
        
        Args:
            value: 值
            
        Returns:
            SQL表示
        """
        if value is None:
            return 'NULL'
        elif isinstance(value, bool):
            return 'TRUE' if value else 'FALSE'
        elif isinstance(value, (int, float)):
            return str(value)
        elif isinstance(value, str):
            # 转义单引号
            escaped = value.replace("'", "''")
            return f"'{escaped}'"
        elif isinstance(value, dict):
            # 字典作为JSON对象
            import json
            json_str = json.dumps(value)
            return f"'{json_str}'"
        elif isinstance(value, list):
            # 列表作为JSON数组
            import json
            json_str = json.dumps(value)
            return f"'{json_str}'"
        else:
            return str(value)

    @classmethod
    def _is_operator(cls, expr: str) -> bool:
        """
        检查表达式是否是操作符。
        
        Args:
            expr: 表达式字符串
            
        Returns:
            是否是操作符
        """
        # 检查是否是已知的操作符
        all_operators = (
            cls.COMPARISON_OPERATORS |
            cls.LOGICAL_OPERATORS |
            cls.ARITHMETIC_OPERATORS |
            cls.STRING_OPERATORS |
            cls.CONDITIONAL_OPERATORS |
            cls.ARRAY_OPERATORS |
            cls.ACCUMULATORS
        )
        
        if expr in all_operators:
            return True
        
        # 检查是否以$开头（可能是自定义操作符）
        return expr.startswith('$')

    @classmethod
    def _parse_field_reference(
        cls, 
        field: str, 
        context: RenderContext,
        is_post_aggregation: bool = False
    ) -> str:
        """
        解析字段引用。
        
        Args:
            field: 字段名
            context: 渲染上下文
            is_post_aggregation: 是否在聚合后
            
        Returns:
            SQL字段表达式
        """
        if field.startswith('$'):
            field = field[1:]
        
        # 移除引号
        field = field.strip('"')
        
        if is_post_aggregation:
            # 聚合后直接使用字段名
            return field
        else:
            # 添加表前缀
            table_alias = context.from_alias or 't'
            return f'{table_alias}.{field}'

    @classmethod
    def _parse_comparison_operator(
        cls, 
        operator: str, 
        value: Any, 
        context: RenderContext
    ) -> Optional[str]:
        """
        解析比较操作符。
        
        Args:
            operator: 操作符
            value: 比较值
            context: 渲染上下文
            
        Returns:
            SQL比较表达式
        """
        op_map = {
            '$eq': '=',
            '$ne': '!=',
            '$gt': '>',
            '$gte': '>=',
            '$lt': '<',
            '$lte': '<=',
        }
        
        sql_op = op_map.get(operator)
        if sql_op is None:
            return None
        
        right_operand = cls._value_to_sql(value)
        
        # 解析左操作数（通常是字段）
        left_expr = None
        if isinstance(value, dict):
            # 如果value是字典，可能包含字段引用
            for key in value.keys():
                if key.startswith('$') and not key.startswith('$'):
                    # 这种情况比较少见
                    pass
        
        return f"({left_expr} {sql_op} {right_operand})" if left_expr else f"({sql_op} {right_operand})"

    @classmethod
    def _parse_arithmetic_operator(
        cls, 
        operator: str, 
        value: Any, 
        context: RenderContext
    ) -> Optional[str]:
        """
        解析算术操作符。
        
        Args:
            operator: 操作符
            value: 操作数
            context: 渲染上下文
            
        Returns:
            SQL算术表达式
        """
        op_map = {
            '$add': '+',
            '$subtract': '-',
            '$multiply': '*',
            '$divide': '/',
            '$mod': '%',
        }
        
        sql_op = op_map.get(operator)
        if sql_op is None:
            return None
        
        if not isinstance(value, list) or len(value) < 2:
            return None
        
        operands = []
        for item in value:
            if isinstance(item, str) and item.startswith('$'):
                operands.append(cls._parse_field_reference(item, context))
            else:
                operands.append(cls._value_to_sql(item))
        
        return f"({' ' + sql_op + ' '.join(operands)})"

    @classmethod
    def _parse_logical_operator(
        cls, 
        operator: str, 
        value: Any, 
        context: RenderContext
    ) -> Optional[str]:
        """
        解析逻辑操作符。
        
        Args:
            operator: 操作符
            value: 逻辑值
            context: 渲染上下文
            
        Returns:
            SQL逻辑表达式
        """
        if operator == '$and':
            if not isinstance(value, list):
                return None
            parts = []
            for item in value:
                # 递归解析每个条件
                part = cls._parse_condition_item(item, context)
                if part:
                    parts.append(part)
            return '(' + ' AND '.join(parts) + ')' if parts else None
        
        elif operator == '$or':
            if not isinstance(value, list):
                return None
            parts = []
            for item in value:
                part = cls._parse_condition_item(item, context)
                if part:
                    parts.append(part)
            return '(' + ' OR '.join(parts) + ')' if parts else None
        
        elif operator == '$not':
            # 处理 $not 操作符
            if isinstance(value, dict):
                for op, val in value.items():
                    parsed = cls._parse_condition_item({op: val}, context)
                    if parsed:
                        return f'(NOT {parsed})'
        
        return None

    @classmethod
    def _parse_condition_item(cls, condition: Any, context: RenderContext) -> Optional[str]:
        """
        解析条件项。
        
        Args:
            condition: 条件
            context: 渲染上下文
            
        Returns:
            SQL条件表达式
        """
        if isinstance(condition, dict):
            for key, value in condition.items():
                if key in cls.COMPARISON_OPERATORS:
                    # 比较操作符
                    if isinstance(value, dict):
                        # 字段比较：{"$field": value}
                        for field, val in value.items():
                            if field.startswith('$'):
                                field_expr = cls._parse_field_reference(field, context)
                                return f"({field_expr} {cls._get_sql_op(key)} {cls._value_to_sql(val)})"
                    else:
                        # 简单比较
                        return cls._value_to_sql(value)
                elif key in cls.LOGICAL_OPERATORS:
                    return cls._parse_logical_operator(key, value, context)
        
        return None

    @classmethod
    def _get_sql_op(cls, mongo_op: str) -> str:
        """
        获取SQL操作符。
        
        Args:
            mongo_op: MongoDB操作符
            
        Returns:
            SQL操作符
        """
        op_map = {
            '$eq': '=',
            '$ne': '!=',
            '$gt': '>',
            '$gte': '>=',
            '$lt': '<',
            '$lte': '<=',
        }
        return op_map.get(mongo_op, '=')
