"""
Expression Registry Module

表达式类型注册表，用于动态解析和创建表达式对象。
"""

from typing import Any, Dict, List, Optional, Type, Union

from .expr_base import (
    BaseExpression,
    BinaryOperation,
    FieldReference,
    FunctionCall,
    LiteralValue,
)


class ExpressionRegistry:
    """
    表达式注册表。
    
    管理表达式类型的注册和解析，提供统一的表达式创建接口。
    """
    
    # 操作符优先级
    OPERATOR_PRECEDENCE = {
        '$or': 1,
        '$and': 2,
        '$eq': 3,
        '$ne': 3,
        '$gt': 3,
        '$gte': 3,
        '$lt': 3,
        '$lte': 3,
        '$in': 3,
        '$nin': 3,
        '$regex': 3,
        '$not': 4,
    }
    
    # 聚合函数列表
    AGGREGATION_FUNCTIONS = {
        '$sum', '$avg', '$min', '$max', '$count', 
        '$first', '$last', '$push', '$addToSet'
    }
    
    # 字符串函数列表
    STRING_FUNCTIONS = {
        '$concat', '$substr', '$toLower', '$toUpper', '$trim'
    }
    
    # 条件函数列表
    CONDITIONAL_FUNCTIONS = {
        '$cond', '$ifNull', '$switch'
    }
    
    @classmethod
    def parse_expression(cls, expr: Any, alias: Optional[str] = None) -> BaseExpression:
        """
        解析表达式并创建对应的表达式对象。
        
        Args:
            expr: MongoDB 表达式（可以是字典、列表、字符串等）
            alias: 表达式别名
            
        Returns:
            对应的表达式对象
        """
        if expr is None:
            return LiteralValue(None)
        
        # 处理字段引用（以 $ 开头但不是操作符）
        if isinstance(expr, str) and expr.startswith('$') and not cls._is_operator(expr):
            return FieldReference(expr, alias)
        
        # 处理字面值
        if isinstance(expr, (str, int, float, bool)):
            return LiteralValue(expr)
        
        # 处理列表
        if isinstance(expr, list):
            return LiteralValue(expr)
        
        # 处理字典（操作符表达式）
        if isinstance(expr, dict):
            return cls._parse_dict_expression(expr, alias)
        
        # 默认处理
        return LiteralValue(expr)
    
    @classmethod
    def _parse_dict_expression(cls, expr: Dict[str, Any], alias: Optional[str] = None) -> BaseExpression:
        """
        解析字典类型的表达式。
        
        Args:
            expr: 表达式字典
            alias: 表达式别名
            
        Returns:
            表达式对象
        """
        if not expr:
            return LiteralValue({})
        
        # 获取操作符
        operators = list(expr.keys())
        
        if not operators:
            return LiteralValue({})
        
        # 处理单个操作符
        if len(operators) == 1:
            op = operators[0]
            value = expr[op]
            return cls._parse_operator(op, value, alias)
        
        # 处理多个操作符（通常是隐式 AND）
        # 创建 AND 连接的多个条件
        conditions = []
        for op, value in expr.items():
            conditions.append(cls._parse_operator(op, value))
        
        # 用 AND 连接所有条件
        result = conditions[0]
        for condition in conditions[1:]:
            result = BinaryOperation('$and', result, condition)
        
        return result
    
    @classmethod
    def _parse_operator(cls, op: str, value: Any, alias: Optional[str] = None) -> BaseExpression:
        """
        解析单个操作符。
        
        Args:
            op: 操作符名称
            value: 操作符值
            alias: 表达式别名
            
        Returns:
            表达式对象
        """
        # 逻辑操作符
        if op in ('$and', '$or'):
            if not isinstance(value, list):
                raise ValueError(f"{op} requires an array of expressions")
            
            if len(value) == 0:
                return LiteralValue(True if op == '$and' else False)
            
            # 解析所有子表达式
            expressions = [cls.parse_expression(item) for item in value]
            
            # 用操作符连接所有表达式
            result = expressions[0]
            for expr in expressions[1:]:
                result = BinaryOperation(op, result, expr)
            
            return result
        
        # 比较操作符
        if op in ('$eq', '$ne', '$gt', '$gte', '$lt', '$lte', '$in', '$nin', '$regex'):
            # 这些操作符通常在字段上下文中使用
            # 例如: { age: { $gt: 18 } }
            # 这里我们假设 value 是操作数
            return cls._create_comparison(op, value)
        
        # 非操作符
        if op == '$not':
            inner_expr = cls.parse_expression(value)
            # 在 SQL 中，NOT 通常用前缀表示
            # 这里我们返回一个特殊的表示
            return cls._create_not_expression(inner_expr)
        
        # 聚合函数
        if cls._is_aggregation_function(op):
            args = cls._parse_function_arguments(value)
            return FunctionCall(op, args)
        
        # 字符串函数
        if cls._is_string_function(op):
            args = cls._parse_function_arguments(value)
            return FunctionCall(op, args)
        
        # 条件函数
        if cls._is_conditional_function(op):
            args = cls._parse_function_arguments(value)
            return FunctionCall(op, args)
        
        # 字段引用（如 { $field: <value> } 这种形式）
        if op.startswith('$') and not cls._is_operator(op):
            # 这可能是字段赋值，如 { $field: <expression> }
            # 在 project 阶段常见
            return cls._create_field_assignment(op, value, alias)
        
        # 其他情况，将整个字典作为字面值
        return LiteralValue({op: value})
    
    @classmethod
    def _create_comparison(cls, op: str, value: Any) -> BaseExpression:
        """
        创建比较表达式。
        
        注意：这里的 value 应该是完整的比较对象。
        例如：{ $gt: 18 } 中的 18
        
        Args:
            op: 比较操作符
            value: 比较值
            
        Returns:
            表达式对象
        """
        # 这里返回一个占位表达式
        # 实际使用时，应该在字段上下文中解析
        return LiteralValue({op: value})
    
    @classmethod
    def _create_not_expression(cls, inner_expr: BaseExpression) -> BaseExpression:
        """
        创建 NOT 表达式。
        
        Args:
            inner_expr: 内部表达式
            
        Returns:
            NOT 表达式
        """
        # 对于二元操作，我们可以转换操作符
        if isinstance(inner_expr, BinaryOperation):
            inverted_op = cls._invert_operator(inner_expr.operator)
            if inverted_op:
                return BinaryOperation(
                    inverted_op,
                    inner_expr.left,
                    inner_expr.right
                )
        
        # 对于其他情况，返回一个特殊的表示
        # 在 SQL 中，我们会生成 NOT (expression)
        return LiteralValue({'$not': inner_expr})
    
    @classmethod
    def _invert_operator(cls, op: str) -> Optional[str]:
        """
        获取操作符的否定形式。
        
        Args:
            op: 原操作符
            
        Returns:
            否定操作符，如果不存在则返回 None
        """
        inversions = {
            '$eq': '$ne',
            '$ne': '$eq',
            '$gt': '$lte',
            '$gte': '$lt',
            '$lt': '$gte',
            '$lte': '$gt',
            '$in': '$nin',
            '$nin': '$in',
        }
        return inversions.get(op)
    
    @classmethod
    def _parse_function_arguments(cls, value: Any) -> List[BaseExpression]:
        """
        解析函数参数。
        
        Args:
            value: 参数值（可以是单个值或列表）
            
        Returns:
            参数表达式列表
        """
        if isinstance(value, list):
            return [cls.parse_expression(item) for item in value]
        else:
            return [cls.parse_expression(value)]
    
    @classmethod
    def _create_field_assignment(cls, field: str, value: Any, alias: Optional[str] = None) -> BaseExpression:
        """
        创建字段赋值表达式。
        
        Args:
            field: 字段名（可能以 $ 开头）
            value: 字段值
            alias: 别名
            
        Returns:
            表达式对象
        """
        # 解析值表达式
        value_expr = cls.parse_expression(value)
        
        # 如果值是简单的字段引用，直接返回
        if isinstance(value_expr, FieldReference):
            if alias:
                return FieldReference(value_expr.field_path, alias)
            return value_expr
        
        # 对于复杂表达式，我们需要保留字段信息
        # 这里我们返回一个带有别名的表达式
        if alias:
            # 创建一个包装表达式
            return cls._create_aliased_expression(value_expr, alias)
        
        return value_expr
    
    @classmethod
    def _create_aliased_expression(cls, expr: BaseExpression, alias: str) -> BaseExpression:
        """
        创建带别名的表达式。
        
        Args:
            expr: 原表达式
            alias: 别名
            
        Returns:
            带别名的表达式
        """
        # 对于字段引用，直接设置别名
        if isinstance(expr, FieldReference):
            return FieldReference(expr.field_path, alias)
        
        # 对于其他表达式，我们创建一个特殊的包装
        # 在实际 SQL 生成时，我们会添加 AS 子句
        return LiteralValue({'$expr': expr, '$alias': alias})
    
    @classmethod
    def _is_operator(cls, name: str) -> bool:
        """
        检查名称是否是操作符。
        
        Args:
            name: 要检查的名称
            
        Returns:
            是否是操作符
        """
        operators = {
            '$eq', '$ne', '$gt', '$gte', '$lt', '$lte',
            '$in', '$nin', '$regex', '$exists', '$type',
            '$and', '$or', '$not', '$nor',
            '$sum', '$avg', '$min', '$max', '$count',
            '$first', '$last', '$push', '$addToSet',
            '$concat', '$substr', '$toLower', '$toUpper',
            '$cond', '$ifNull', '$switch',
        }
        return name in operators
    
    @classmethod
    def _is_aggregation_function(cls, name: str) -> bool:
        """
        检查名称是否是聚合函数。
        
        Args:
            name: 要检查的名称
            
        Returns:
            是否是聚合函数
        """
        return name in cls.AGGREGATION_FUNCTIONS
    
    @classmethod
    def _is_string_function(cls, name: str) -> bool:
        """
        检查名称是否是字符串函数。
        
        Args:
            name: 要检查的名称
            
        Returns:
            是否是字符串函数
        """
        return name in cls.STRING_FUNCTIONS
    
    @classmethod
    def _is_conditional_function(cls, name: str) -> bool:
        """
        检查名称是否是条件函数。
        
        Args:
            name: 要检查的名称
            
        Returns:
            是否是条件函数
        """
        return name in cls.CONDITIONAL_FUNCTIONS
    
    @classmethod
    def parse_field_condition(cls, field: str, condition: Dict[str, Any]) -> BinaryOperation:
        """
        解析字段条件。
        
        例如: { age: { $gt: 18 } } -> age > 18
        
        Args:
            field: 字段名
            condition: 条件字典
            
        Returns:
            二元操作表达式
        """
        field_ref = FieldReference(field)
        
        # 处理简单值（隐式 $eq）
        if not isinstance(condition, dict):
            value_expr = cls.parse_expression(condition)
            return BinaryOperation('$eq', field_ref, value_expr)
        
        # 处理操作符条件
        if len(condition) == 1:
            op = list(condition.keys())[0]
            value = condition[op]
            
            if op in ('$eq', '$ne', '$gt', '$gte', '$lt', '$lte', '$in', '$nin', '$regex'):
                value_expr = cls.parse_expression(value)
                return BinaryOperation(op, field_ref, value_expr)
            
            if op == '$exists':
                # $exists: true -> IS NOT NULL
                # $exists: false -> IS NULL
                if value:
                    return BinaryOperation('$ne', field_ref, LiteralValue(None))
                else:
                    return BinaryOperation('$eq', field_ref, LiteralValue(None))
        
        # 多个条件（隐式 AND）
        conditions = []
        for op, value in condition.items():
            if op in ('$eq', '$ne', '$gt', '$gte', '$lt', '$lte', '$in', '$nin', '$regex'):
                value_expr = cls.parse_expression(value)
                conditions.append(BinaryOperation(op, field_ref, value_expr))
        
        if conditions:
            result = conditions[0]
            for cond in conditions[1:]:
                result = BinaryOperation('$and', result, cond)
            return result
        
        # 默认返回相等比较
        value_expr = cls.parse_expression(condition)
        return BinaryOperation('$eq', field_ref, value_expr)
