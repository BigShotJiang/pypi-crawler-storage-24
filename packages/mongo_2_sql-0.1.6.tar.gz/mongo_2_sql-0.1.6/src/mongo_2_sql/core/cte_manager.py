"""
CTE Manager Module

统一管理 CTE（Common Table Expressions）的创建和使用。
"""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass

@dataclass
class CTEInfo:
    """CTE 信息"""
    name: str
    sql: str
    dependencies: List[str]  # 依赖的其他 CTE 名称

class CTEManager:
    """CTE 管理器"""
    
    def __init__(self):
        self.ctes: List[CTEInfo] = []
        self.cte_counter: int = 0
    
    def generate_name(self) -> str:
        """生成唯一的 CTE 名称"""
        self.cte_counter += 1
        return f"cte_{self.cte_counter}"
    
    def add_cte(self, sql: str, dependencies: List[str] = None) -> str:
        """
        添加一个新的 CTE
        
        Args:
            sql: CTE 的 SQL 内容
            dependencies: 依赖的其他 CTE 名称列表
            
        Returns:
            新创建的 CTE 名称
        """
        cte_name = self.generate_name()
        cte_info = CTEInfo(
            name=cte_name,
            sql=sql,
            dependencies=dependencies or []
        )
        self.ctes.append(cte_info)
        return cte_name
    
    def get_all_ctes(self) -> List[CTEInfo]:
        """获取所有 CTE 信息"""
        return self.ctes.copy()
    
    def clear(self):
        """清空所有 CTE"""
        self.ctes.clear()
        self.cte_counter = 0
    
    def build_with_clause(self) -> str:
        """
        构建完整的 WITH 子句
        
        Returns:
            完整的 WITH 子句 SQL
        """
        if not self.ctes:
            return ""
        
        cte_parts = []
        for cte in self.ctes:
            cte_parts.append(f"{cte.name} AS (\n{cte.sql}\n)")
        
        return "WITH\n" + ",\n".join(cte_parts)