"""
Pipeline Runtime Module

管道运行时执行器，负责按顺序执行各个聚合阶段。
"""

from typing import Any, Dict, List, Optional

from .stage_base import RenderContext
from .stage_loader import StageLoader


class PipelineRuntime:
    """
    管道运行时。
    
    负责按顺序执行 MongoDB 聚合管道的各个阶段，
    并将结果转换为 SQL 查询。
    """
    
    def __init__(self, collection_name: str, stage_loader: Optional[StageLoader] = None):
        """
        初始化管道运行时。
        
        Args:
            collection_name: MongoDB 集合名称（对应 SQL 表名）
            stage_loader: 阶段加载器实例
        """
        self.collection_name = collection_name
        self.stage_loader = stage_loader or StageLoader()
        self.context = RenderContext(
            collection_name=collection_name,
            from_table=collection_name,
            from_alias='t'
        )
        self.errors: List[str] = []
        self.warnings: List[str] = []
    
    def execute(self, pipeline: List[Dict[str, Any]]) -> RenderContext:
        """
        执行聚合管道。
        
        Args:
            pipeline: MongoDB 聚合管道
            
        Returns:
            渲染上下文，包含生成的 SQL 信息
        """
        self.errors = []
        self.warnings = []
        
        # 加载所有阶段处理器
        self.stage_loader.load_all_stages()
        
        # 按顺序处理每个阶段
        for index, stage in enumerate(pipeline):
            if not isinstance(stage, dict):
                self.errors.append(f"Stage {index}: Expected dict, got {type(stage).__name__}")
                continue
            
            # 获取阶段名称和值
            stage_names = list(stage.keys())
            
            if len(stage_names) != 1:
                self.errors.append(f"Stage {index}: Expected exactly one stage operator, got {len(stage_names)}")
                continue
            
            stage_name = stage_names[0]
            stage_value = stage[stage_name]
            
            # 获取阶段处理器
            processor = self.stage_loader.get_processor(stage_name)
            
            if processor is None:
                if self.stage_loader.is_stage_supported(stage_name):
                    self.warnings.append(f"Stage {index}: Processor for '{stage_name}' not loaded yet, skipping")
                else:
                    self.warnings.append(f"Stage {index}: Stage '{stage_name}' is not supported, skipping")
                continue
            
            # 验证阶段值
            try:
                if not processor.validate(stage_value):
                    self.errors.append(f"Stage {index}: Invalid value for '{stage_name}'")
                    continue
            except Exception as e:
                self.errors.append(f"Stage {index}: Validation error for '{stage_name}': {e}")
                continue
            
            # 处理阶段
            try:
                processor.process(stage_value, self.context)
            except Exception as e:
                self.errors.append(f"Stage {index}: Error processing '{stage_name}': {e}")
                import traceback
                traceback.print_exc()
        
        return self.context
    
    def get_sql(self) -> str:
        """
        获取生成的 SQL 查询。
        
        Returns:
            SQL 查询字符串
        """
        return self.context.to_sql()
    
    def has_errors(self) -> bool:
        """
        检查是否有错误。
        
        Returns:
            是否有错误
        """
        return len(self.errors) > 0
    
    def has_warnings(self) -> bool:
        """
        检查是否有警告。
        
        Returns:
            是否有警告
        """
        return len(self.warnings) > 0
    
    def get_errors(self) -> List[str]:
        """
        获取错误列表。
        
        Returns:
            错误信息列表
        """
        return self.errors.copy()
    
    def get_warnings(self) -> List[str]:
        """
        获取警告列表。
        
        Returns:
            警告信息列表
        """
        return self.warnings.copy()
    
    def get_context(self) -> RenderContext:
        """
        获取渲染上下文。
        
        Returns:
            渲染上下文
        """
        return self.context
