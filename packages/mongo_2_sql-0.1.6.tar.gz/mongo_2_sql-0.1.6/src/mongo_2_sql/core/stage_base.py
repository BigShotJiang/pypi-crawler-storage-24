"""
Stage Base Module

定义阶段处理器的抽象基类。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from .cte_manager import CTEManager


@dataclass
class RenderContext:
    """
    SQL 渲染上下文。
    
    存储查询构建过程中的各种状态，包括 CTE、SELECT、FROM、
    WHERE、GROUP BY、HAVING、ORDER BY、LIMIT 等子句。
    """
    
    # 表信息
    collection_name: str = ""
    table_alias: str = "t"
    
    # CTE 管理器
    cte_manager: CTEManager = field(default_factory=CTEManager)
    
    # CTE (Common Table Expressions) - 保持向后兼容
    ctes: List[Dict[str, Any]] = field(default_factory=list)
    cte_counter: int = 0
    
    # SELECT 子句
    select_columns: List[str] = field(default_factory=list)
    select_distinct: bool = False
    
    # FROM 子句
    from_table: str = ""
    from_alias: str = ""
    joins: List[Dict[str, Any]] = field(default_factory=list)
    
    # WHERE 子句
    where_conditions: List[str] = field(default_factory=list)
    
    # GROUP BY 子句
    group_by_columns: List[str] = field(default_factory=list)
    
    # HAVING 子句
    having_conditions: List[str] = field(default_factory=list)
    
    # ORDER BY 子句
    order_by_columns: List[Tuple[str, str]] = field(default_factory=list)  # (column, direction)
    
    # LIMIT 子句
    limit_value: Optional[int] = None
    offset_value: Optional[int] = None
    
    # 展开信息（用于 unwind）
    unwind_info: List[Dict[str, Any]] = field(default_factory=list)
    
    # 聚合标志
    has_aggregation: bool = False
    
    def generate_cte_name(self) -> str:
        """
        生成唯一的 CTE 名称。
        
        Returns:
            CTE 名称
        """
        return self.cte_manager.generate_name()
    
    def add_cte(self, name: str, sql: str) -> None:
        """
        添加 CTE。
        
        Args:
            name: CTE 名称
            sql: CTE 的 SQL 查询
        """
        self.ctes.append({'name': name, 'sql': sql})
    
    def add_select_column(self, column: str, alias: Optional[str] = None) -> None:
        """
        添加 SELECT 列。
        
        Args:
            column: 列表达式
            alias: 列别名
        """
        if alias:
            self.select_columns.append(f"{column} AS {alias}")
        else:
            self.select_columns.append(column)
    
    def add_join(self, join_type: str, table: str, alias: str, condition: str) -> None:
        """
        添加 JOIN 子句。
        
        Args:
            join_type: JOIN 类型（LEFT, INNER, etc.）
            table: 表名
            alias: 表别名
            condition: JOIN 条件
        """
        self.joins.append({
            'type': join_type,
            'table': table,
            'alias': alias,
            'condition': condition
        })
    
    def add_where_condition(self, condition: str) -> None:
        """
        添加 WHERE 条件。
        
        Args:
            condition: 条件表达式
        """
        self.where_conditions.append(condition)
    
    def add_group_by_column(self, column: str) -> None:
        """
        添加 GROUP BY 列。
        
        Args:
            column: 列名
        """
        if column not in self.group_by_columns:
            self.group_by_columns.append(column)
    
    def add_having_condition(self, condition: str) -> None:
        """
        添加 HAVING 条件。
        
        Args:
            condition: 条件表达式
        """
        self.having_conditions.append(condition)
    
    def add_order_by_column(self, column: str, direction: str = 'ASC') -> None:
        """
        添加 ORDER BY 列。
        
        Args:
            column: 列名
            direction: 排序方向（ASC 或 DESC）
        """
        direction = direction.upper()
        if direction not in ('ASC', 'DESC'):
            direction = 'ASC'
        self.order_by_columns.append((column, direction))
    
    def set_limit(self, limit: int) -> None:
        """
        设置 LIMIT 值。
        
        Args:
            limit: 限制数量
        """
        self.limit_value = limit
    
    def set_offset(self, offset: int) -> None:
        """
        设置 OFFSET 值。
        
        Args:
            offset: 偏移量
        """
        self.offset_value = offset
    
    def quote_identifier(self, identifier: str) -> str:
        """
        引用标识符。
        
        Args:
            identifier: 标识符
            
        Returns:
            引用的标识符
        """
        # 处理带表前缀的标识符
        if '.' in identifier:
            parts = identifier.split('.')
            return '.'.join(f'{part}' for part in parts)
        return f'{identifier}'
    
    def to_sql(self) -> str:
        """
        将上下文转换为完整的 SQL 查询。
        
        Returns:
            SQL 查询字符串
        """
        parts = []
        
        # CTE - 使用新的 CTE 管理器
        with_clause = self.cte_manager.build_with_clause()
        if with_clause:
            parts.append(with_clause)
        
        # SELECT
        select_clause = "SELECT"
        if self.select_distinct:
            select_clause += " DISTINCT"
        
        if self.select_columns:
            select_clause += f"\n {',\n    '.join(dict.fromkeys(self.select_columns))}"
        else:
            select_clause += " *"
        parts.append(select_clause)
        
        # FROM
        if self.from_table:
            from_clause = f'FROM {self.from_table}'
            if self.from_alias:
                from_clause += f' AS {self.from_alias}'
            parts.append(from_clause)
        
        # JOINs
        for join in self.joins:
            join_clause = f"{join['type']} JOIN {join['table']}"
            if join['alias']:
                join_clause += f' AS {join["alias"]}'
            join_clause += f" ON {join['condition']}"
            parts.append(join_clause)
        
        # WHERE
        if self.where_conditions:
            # 统一添加 1=1 作为第一个条件
            all_conditions = ["1=1\n"] + self.where_conditions
            where_clause = "WHERE " + " AND ".join(dict.fromkeys(all_conditions))
            parts.append(where_clause)
        
        # GROUP BY
        if self.group_by_columns:
            group_clause = f"GROUP BY {', \n'.join(dict.fromkeys(self.group_by_columns))}"
            parts.append(group_clause)
        
        # HAVING
        if self.having_conditions:
            having_clause = "HAVING " + " AND \n".join(dict.fromkeys(self.having_conditions))
            parts.append(having_clause)
        
        # ORDER BY
        if self.order_by_columns:
            order_parts = [f'{col} {dir}' for col, dir in self.order_by_columns]
            order_clause = f"ORDER BY {', \n'.join(dict.fromkeys(order_parts))}"
            parts.append(order_clause)
        
        # LIMIT
        if self.limit_value is not None:
            parts.append(f"LIMIT {self.limit_value}")
        
        # OFFSET
        if self.offset_value is not None:
            parts.append(f"OFFSET {self.offset_value}")
        
        return "\n".join(dict.fromkeys(parts))


class StageProcessor(ABC):
    """
    阶段处理器的抽象基类。
    
    所有 MongoDB 聚合阶段处理器都应继承此类。
    """
    
    def __init__(self, stage_name: str):
        """
        初始化阶段处理器。
        
        Args:
            stage_name: 阶段名称（如 '$match', '$project' 等）
        """
        self.stage_name = stage_name
    
    @abstractmethod
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理聚合阶段。
        
        Args:
            stage_value: 阶段的值
            context: 渲染上下文
        """
        pass
    
    @abstractmethod
    def validate(self, stage_value: Any) -> bool:
        """
        验证阶段值是否有效。
        
        Args:
            stage_value: 阶段的值
            
        Returns:
            是否有效
        """
        pass
    
    def get_stage_name(self) -> str:
        """
        获取阶段名称。
        
        Returns:
            阶段名称
        """
        return self.stage_name
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(stage='{self.stage_name}')"
