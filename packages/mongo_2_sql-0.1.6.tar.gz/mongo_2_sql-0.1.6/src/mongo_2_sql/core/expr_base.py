"""
Expression Base Module

定义表达式系统的基类，用于表示 MongoDB 查询表达式。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union
from enum import Enum, auto


class ExpressionType(Enum):
    """表达式类型枚举。"""
    FIELD_REFERENCE = auto()
    LITERAL_VALUE = auto()
    BINARY_OPERATION = auto()
    UNARY_OPERATION = auto()
    FUNCTION_CALL = auto()
    CONDITIONAL = auto()
    ARRAY_EXPRESSION = auto()
    DOCUMENT_EXPRESSION = auto()


class BaseExpression(ABC):
    """
    表达式的抽象基类。
    
    所有 MongoDB 表达式都应继承此类。
    """
    
    def __init__(self, expr_type: ExpressionType):
        """
        初始化表达式。
        
        Args:
            expr_type: 表达式类型
        """
        self.expr_type = expr_type
    
    @abstractmethod
    def to_sql(self, context: Optional[Dict[str, Any]] = None) -> str:
        """
        将表达式转换为 SQL 字符串。
        
        Args:
            context: 转换上下文
            
        Returns:
            SQL 字符串表示
        """
        pass
    
    @abstractmethod
    def evaluate(self, document: Dict[str, Any]) -> Any:
        """
        在文档上下文中评估表达式。
        
        Args:
            document: 文档数据
            
        Returns:
            表达式评估结果
        """
        pass
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(type={self.expr_type.name})"


class FieldReference(BaseExpression):
    """
    字段引用表达式。
    
    表示对文档中某个字段的引用，如 "$field" 或 "$nested.field"。
    """
    
    def __init__(self, field_path: str, alias: Optional[str] = None):
        """
        初始化字段引用。
        
        Args:
            field_path: 字段路径，如 "name" 或 "address.city"
            alias: 字段别名
        """
        super().__init__(ExpressionType.FIELD_REFERENCE)
        # 移除开头的 $ 符号
        self.field_path = field_path.lstrip('$')
        self.alias = alias
    
    def to_sql(self, context: Optional[Dict[str, Any]] = None) -> str:
        """
        将字段引用转换为 SQL 标识符。
        
        Args:
            context: 转换上下文
            
        Returns:
            SQL 标识符
        """
        # 处理嵌套字段路径
        parts = self.field_path.split('.')
        
        # 检查是否有表别名
        table_alias = context.get('table_alias') if context else None
        
        if table_alias:
            parts.insert(0, table_alias)
        
        # 引用每个部分
        quoted_parts = [f'{part}' for part in parts]
        sql = '.'.join(dict.fromkeys(quoted_parts))
        
        # 添加别名
        if self.alias:
            sql += f' AS {self.alias}'
        
        return sql
    
    def evaluate(self, document: Dict[str, Any]) -> Any:
        """
        从文档中获取字段值。
        
        Args:
            document: 文档数据
            
        Returns:
            字段值
        """
        parts = self.field_path.split('.')
        value = document
        
        for part in parts:
            if isinstance(value, dict) and part in value:
                value = value[part]
            else:
                return None
        
        return value
    
    def __repr__(self) -> str:
        return f"FieldReference(path='{self.field_path}')"


class LiteralValue(BaseExpression):
    """
    字面值表达式。
    
    表示常量值，如字符串、数字、布尔值、null 等。
    """
    
    def __init__(self, value: Any):
        """
        初始化字面值。
        
        Args:
            value: 常量值
        """
        super().__init__(ExpressionType.LITERAL_VALUE)
        self.value = value
    
    def to_sql(self, context: Optional[Dict[str, Any]] = None) -> str:
        """
        将字面值转换为 SQL 表示。
        
        Args:
            context: 转换上下文
            
        Returns:
            SQL 字面量字符串
        """
        if self.value is None:
            return 'NULL'
        elif isinstance(self.value, bool):
            return 'TRUE' if self.value else 'FALSE'
        elif isinstance(self.value, (int, float)):
            return str(self.value)
        elif isinstance(self.value, str):
            # 转义单引号
            escaped = self.value.replace("'", "''")
            return f"'{escaped}'"
        elif isinstance(self.value, list):
            # 数组字面量
            items = [LiteralValue(item).to_sql(context) for item in self.value]
            return f"({', '.join(dict.fromkeys(items))})"
        elif isinstance(self.value, dict):
            # 对象字面量（在 SQL 中通常表示为 JSON）
            import json
            json_str = json.dumps(self.value)
            escaped = json_str.replace("'", "''")
            return f"'{escaped}'"
        else:
            return f"'{str(self.value)}'"
    
    def evaluate(self, document: Dict[str, Any]) -> Any:
        """
        返回字面值本身。
        
        Args:
            document: 文档数据（不使用）
            
        Returns:
            字面值
        """
        return self.value
    
    def __repr__(self) -> str:
        return f"LiteralValue(value={repr(self.value)})"


class BinaryOperation(BaseExpression):
    """
    二元操作表达式。
    
    表示二元运算符，如 $eq, $gt, $lt, $and, $or 等。
    """
    
    # MongoDB 操作符到 SQL 操作符的映射
    OPERATOR_MAP = {
        '$eq': '=',
        '$ne': '!=',
        '$gt': '>',
        '$gte': '>=',
        '$lt': '<',
        '$lte': '<=',
        '$and': 'AND',
        '$or': 'OR',
        '$in': 'IN',
        '$nin': 'NOT IN',
        '$regex': 'LIKE',
    }
    
    def __init__(self, operator: str, left: BaseExpression, right: BaseExpression):
        """
        初始化二元操作。
        
        Args:
            operator: MongoDB 操作符
            left: 左操作数
            right: 右操作数
        """
        super().__init__(ExpressionType.BINARY_OPERATION)
        self.operator = operator
        self.left = left
        self.right = right
    
    def to_sql(self, context: Optional[Dict[str, Any]] = None) -> str:
        """
        将二元操作转换为 SQL 表达式。
        
        Args:
            context: 转换上下文
            
        Returns:
            SQL 表达式字符串
        """
        sql_operator = self.OPERATOR_MAP.get(self.operator, self.operator)
        
        left_sql = self.left.to_sql(context)
        right_sql = self.right.to_sql(context)
        
        # 特殊处理某些操作符
        if self.operator == '$regex':
            # MongoDB 正则表达式需要转换为 SQL LIKE 模式
            return self._convert_regex_to_like(left_sql, right_sql)
        
        return f"({left_sql} {sql_operator} {right_sql})"
    
    def _convert_regex_to_like(self, left_sql: str, right_sql: str) -> str:
        """
        将 MongoDB 正则表达式转换为 SQL LIKE 模式。
        
        Args:
            left_sql: 左操作数的 SQL
            right_sql: 右操作数的 SQL（正则表达式）
            
        Returns:
            SQL LIKE 表达式
        """
        # 简单的正则到 LIKE 转换
        # 移除正则表达式的引号
        pattern = right_sql.strip("'")
        
        # 转换 MongoDB 正则语法到 SQL LIKE 语法
        # ^ 开头 -> 不需要前缀 %
        # $ 结尾 -> 不需要后缀 %
        # .* -> %
        # . -> _
        
        has_start_anchor = pattern.startswith('^')
        has_end_anchor = pattern.endswith('$')
        
        if has_start_anchor:
            pattern = pattern[1:]
        if has_end_anchor:
            pattern = pattern[:-1]
        
        pattern = pattern.replace('.*', '%')
        pattern = pattern.replace('.?', '_')
        pattern = pattern.replace('.', '_')
        
        # 添加 % 通配符
        if not has_start_anchor:
            pattern = '%' + pattern
        if not has_end_anchor:
            pattern = pattern + '%'
        
        return f"({left_sql} LIKE '{pattern}')"
    
    def evaluate(self, document: Dict[str, Any]) -> Any:
        """
        评估二元操作。
        
        Args:
            document: 文档数据
            
        Returns:
            评估结果
        """
        left_val = self.left.evaluate(document)
        right_val = self.right.evaluate(document)
        
        # 根据操作符执行相应操作
        if self.operator == '$eq':
            return left_val == right_val
        elif self.operator == '$ne':
            return left_val != right_val
        elif self.operator == '$gt':
            return left_val is not None and right_val is not None and left_val > right_val
        elif self.operator == '$gte':
            return left_val is not None and right_val is not None and left_val >= right_val
        elif self.operator == '$lt':
            return left_val is not None and right_val is not None and left_val < right_val
        elif self.operator == '$lte':
            return left_val is not None and right_val is not None and left_val <= right_val
        elif self.operator == '$in':
            return left_val in right_val if isinstance(right_val, (list, tuple)) else False
        elif self.operator == '$nin':
            return left_val not in right_val if isinstance(right_val, (list, tuple)) else True
        elif self.operator == '$and':
            return bool(left_val) and bool(right_val)
        elif self.operator == '$or':
            return bool(left_val) or bool(right_val)
        else:
            raise ValueError(f"Unknown operator: {self.operator}")
    
    def __repr__(self) -> str:
        return f"BinaryOperation(op='{self.operator}', left={self.left}, right={self.right})"


class FunctionCall(BaseExpression):
    """
    函数调用表达式。
    
    表示 MongoDB 聚合函数调用，如 $sum, $avg, $min, $max 等。
    """
    
    # MongoDB 聚合函数到 SQL 函数的映射
    FUNCTION_MAP = {
        '$sum': 'SUM',
        '$avg': 'AVG',
        '$min': 'MIN',
        '$max': 'MAX',
        '$count': 'COUNT',
        '$first': 'FIRST_VALUE',
        '$last': 'LAST_VALUE',
        '$push': 'JSON_GROUP_ARRAY',
        '$addToSet': 'JSON_GROUP_ARRAY',
        '$concat': 'CONCAT',
        '$substr': 'SUBSTR',
        '$toLower': 'LOWER',
        '$toUpper': 'UPPER',
        '$dateToString': 'STRFTIME',
        '$ifNull': 'COALESCE',
        '$cond': 'CASE',
    }
    
    def __init__(self, function_name: str, arguments: List[BaseExpression]):
        """
        初始化函数调用。
        
        Args:
            function_name: 函数名称
            arguments: 参数列表
        """
        super().__init__(ExpressionType.FUNCTION_CALL)
        self.function_name = function_name
        self.arguments = arguments
    
    def to_sql(self, context: Optional[Dict[str, Any]] = None) -> str:
        """
        将函数调用转换为 SQL 函数调用。
        
        Args:
            context: 转换上下文
            
        Returns:
            SQL 函数调用字符串
        """
        sql_function = self.FUNCTION_MAP.get(self.function_name, self.function_name.lstrip('$'))
        
        # 特殊处理某些函数
        if self.function_name == '$cond':
            return self._convert_cond_to_sql(context)
        
        args_sql = [arg.to_sql(context) for arg in self.arguments]
        
        if self.function_name in ['$push', '$addToSet']:
            # DISTINCT 用于 $addToSet
            distinct = 'DISTINCT ' if self.function_name == '$addToSet' else ''
            return f"{sql_function}({distinct}{', '.join(dict.fromkeys(args_sql))})"
        
        return f"{sql_function}({', '.join(dict.fromkeys(args_sql))})"
    
    def _convert_cond_to_sql(self, context: Optional[Dict[str, Any]]) -> str:
        """
        将 $cond 表达式转换为 SQL CASE 表达式。
        
        Args:
            context: 转换上下文
            
        Returns:
            SQL CASE 表达式
        """
        if len(self.arguments) == 3:
            # $cond: { if: <boolean-expression>, then: <true-expression>, else: <false-expression> }
            condition = self.arguments[0]
            then_expr = self.arguments[1]
            else_expr = self.arguments[2]
            
            condition_sql = condition.to_sql(context)
            then_sql = then_expr.to_sql(context)
            else_sql = else_expr.to_sql(context)
            
            return f"CASE WHEN {condition_sql} THEN {then_sql} ELSE {else_sql} END"
        elif len(self.arguments) == 1 and isinstance(self.arguments[0], LiteralValue):
            # $cond: [ <if>, <then>, <else> ] 格式
            arr = self.arguments[0].value
            if isinstance(arr, list) and len(arr) == 3:
                from .expr_registry import ExpressionRegistry
                condition = ExpressionRegistry.parse_expression(arr[0])
                then_expr = ExpressionRegistry.parse_expression(arr[1])
                else_expr = ExpressionRegistry.parse_expression(arr[2])
                
                condition_sql = condition.to_sql(context)
                then_sql = then_expr.to_sql(context)
                else_sql = else_expr.to_sql(context)
                
                return f"CASE WHEN {condition_sql} THEN {then_sql} ELSE {else_sql} END"
        
        raise ValueError("Invalid $cond expression format")
    
    def evaluate(self, document: Dict[str, Any]) -> Any:
        """
        评估函数调用。
        
        Args:
            document: 文档数据
            
        Returns:
            函数调用结果
        """
        args = [arg.evaluate(document) for arg in self.arguments]
        
        # 简单的函数实现（实际应在聚合上下文中使用）
        if self.function_name == '$sum':
            return sum(args) if args else 0
        elif self.function_name == '$avg':
            return sum(args) / len(args) if args else 0
        elif self.function_name == '$min':
            return min(args) if args else None
        elif self.function_name == '$max':
            return max(args) if args else None
        elif self.function_name == '$count':
            return len(args)
        elif self.function_name == '$concat':
            return ''.join(str(arg) for arg in args)
        elif self.function_name == '$ifNull':
            return args[0] if args[0] is not None else (args[1] if len(args) > 1 else None)
        else:
            raise ValueError(f"Function evaluation not implemented: {self.function_name}")
    
    def __repr__(self) -> str:
        return f"FunctionCall(func='{self.function_name}', args={self.arguments})"
