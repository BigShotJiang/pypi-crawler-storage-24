"""
Stage Loader Module

动态加载阶段处理器。
"""

import importlib
import os
from typing import Dict, Optional, Type

from .stage_base import StageProcessor


class StageLoader:
    """
    阶段加载器。
    
    负责动态发现和加载所有可用的阶段处理器。
    """
    
    # 内置阶段处理器映射
    BUILTIN_STAGES = {
        '$match': 'stages.match.stage.MatchStage',
        '$project': 'stages.project.stage.ProjectStage',
        '$group': 'stages.group.stage.GroupStage',
        '$sort': 'stages.sort.stage.SortStage',
        '$limit': 'stages.limit.stage.LimitStage',
        '$lookup': 'stages.lookup.stage.LookupStage',
        '$unwind': 'stages.unwind.stage.UnwindStage',
        '$skip': 'stages.limit.stage.SkipStage',
        '$addFields': 'stages.add_fields.stage.AddFieldsStage',
    }
    
    def __init__(self, stages_package: str = 'mongo_2_sql.stages'):
        """
        初始化阶段加载器。
        
        Args:
            stages_package: 阶段处理器所在的包路径
        """
        self.stages_package = stages_package
        self._processors: Dict[str, StageProcessor] = {}
        self._processor_classes: Dict[str, Type[StageProcessor]] = {}
    
    def load_all_stages(self) -> Dict[str, StageProcessor]:
        """
        加载所有可用的阶段处理器。
        
        Returns:
            阶段名称到处理器实例的映射
        """
        if self._processors:
            return self._processors
        
        for stage_name, class_path in self.BUILTIN_STAGES.items():
            try:
                processor = self._load_processor_class(class_path)
                if processor:
                    self._processors[stage_name] = processor()
                    self._processor_classes[stage_name] = class_path
            except Exception as e:
                # 记录错误但继续加载其他阶段
                print(f"Warning: Failed to load stage {stage_name}: {e}")
        
        return self._processors
    
    def get_processor(self, stage_name: str) -> Optional[StageProcessor]:
        """
        获取指定阶段的处理器。
        
        Args:
            stage_name: 阶段名称（如 '$match'）
            
        Returns:
            阶段处理器实例，如果不存在则返回 None
        """
        # 如果已加载，直接返回
        if stage_name in self._processors:
            return self._processors[stage_name]
        
        # 尝试加载
        if stage_name in self.BUILTIN_STAGES:
            class_path = self.BUILTIN_STAGES[stage_name]
            try:
                processor = self._load_processor_class(class_path)
                if processor:
                    self._processors[stage_name] = processor()
                    return self._processors[stage_name]
            except Exception as e:
                print(f"Error loading stage {stage_name}: {e}")
        
        return None
    
    def register_processor(self, stage_name: str, processor_class: Type[StageProcessor]) -> None:
        """
        注册自定义阶段处理器。
        
        Args:
            stage_name: 阶段名称
            processor_class: 处理器类
        """
        self._processor_classes[stage_name] = processor_class
        self._processors[stage_name] = processor_class()
    
    def _load_processor_class(self, class_path: str) -> Optional[Type[StageProcessor]]:
        """
        加载处理器类。
        
        Args:
            class_path: 类的完整路径（如 'stages.match.stage.MatchStage'）
            
        Returns:
            处理器类，如果加载失败则返回 None
        """
        try:
            # 尝试相对导入
            module_name, class_name = class_path.rsplit('.', 1)
            
            # 构建完整的模块路径
            if module_name.startswith('stages.'):
                full_module_name = f"mongo_2_sql.{module_name}"
            else:
                full_module_name = module_name
            
            # 导入模块
            module = importlib.import_module(full_module_name)
            
            # 获取类
            processor_class = getattr(module, class_name)
            
            # 验证是否是 StageProcessor 的子类
            if issubclass(processor_class, StageProcessor):
                return processor_class
            else:
                raise TypeError(f"{class_name} is not a subclass of StageProcessor")
                
        except ImportError as e:
            # 尝试备用导入方式
            try:
                # 直接使用 stages 包路径
                module_name, class_name = class_path.rsplit('.', 1)
                module = importlib.import_module(module_name)
                processor_class = getattr(module, class_name)
                
                if issubclass(processor_class, StageProcessor):
                    return processor_class
            except Exception:
                pass
            
            raise ImportError(f"Failed to import {class_path}: {e}")
        
        return None
    
    def list_available_stages(self) -> list:
        """
        列出所有可用的阶段。
        
        Returns:
            可用阶段名称列表
        """
        return list(self.BUILTIN_STAGES.keys())
    
    def is_stage_supported(self, stage_name: str) -> bool:
        """
        检查阶段是否受支持。
        
        Args:
            stage_name: 阶段名称
            
        Returns:
            是否受支持
        """
        return stage_name in self.BUILTIN_STAGES
