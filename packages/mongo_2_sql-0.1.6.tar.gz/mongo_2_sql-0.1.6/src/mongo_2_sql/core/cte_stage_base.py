"""
CTE-enabled Stage Processor Base Module

为需要使用 CTE 的阶段处理器提供统一的基础类。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from ..core.stage_base import RenderContext, StageProcessor


class CTEStageProcessor(StageProcessor, ABC):
    """
    CTE 阶段处理器基类。
    
    为 $addFields、$project、$group 等需要创建中间表的阶段提供统一的 CTE 处理逻辑。
    """
    
    def __init__(self, stage_name: str):
        """
        初始化 CTE 阶段处理器。
        
        Args:
            stage_name: 阶段名称
        """
        super().__init__(stage_name)
    
    def process_with_cte(self, stage_value: Any, context: RenderContext, 
                        build_cte_sql_func) -> None:
        """
        使用 CTE 方式处理阶段。
        
        Args:
            stage_value: 阶段值
            context: 渲染上下文
            build_cte_sql_func: 构建 CTE SQL 的函数
        """
        # 保存当前上下文状态
        original_from_table = context.from_table
        original_from_alias = context.from_alias
        
        # 构建 CTE SQL
        cte_sql = build_cte_sql_func(stage_value, context, original_from_table, original_from_alias)
        
        # 添加 CTE
        cte_name = context.cte_manager.add_cte(cte_sql)
        
        # 更新上下文以使用新的 CTE 作为源表
        context.from_table = cte_name
        context.from_alias = 't'  # 重置别名
        
        # 清空原有条件，因为它们已经在 CTE 中处理了
        self._clear_context_state(context)
        
        # 设置新的 SELECT 列
        context.select_columns.clear()
        context.add_select_column("*")
    
    def _clear_context_state(self, context: RenderContext) -> None:
        """
        清空上下文状态。
        
        Args:
            context: 渲染上下文
        """
        context.where_conditions.clear()
        context.group_by_columns.clear()
        context.having_conditions.clear()
        context.has_aggregation = False
    
    @abstractmethod
    def should_use_cte(self, stage_value: Any, context: RenderContext) -> bool:
        """
        判断是否应该使用 CTE 来处理此阶段。
        
        Args:
            stage_value: 阶段值
            context: 渲染上下文
            
        Returns:
            是否使用 CTE
        """
        pass
    
    @abstractmethod
    def build_cte_sql(self, stage_value: Any, context: RenderContext, 
                     original_from_table: str, original_from_alias: str) -> str:
        """
        构建 CTE 的 SQL 内容。
        
        Args:
            stage_value: 阶段值
            context: 渲染上下文
            original_from_table: 原始表名
            original_from_alias: 原始表别名
            
        Returns:
            CTE SQL 内容
        """
        pass