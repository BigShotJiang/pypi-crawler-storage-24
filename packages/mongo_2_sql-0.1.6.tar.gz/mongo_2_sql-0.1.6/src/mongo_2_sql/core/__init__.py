"""
Mongo to SQL - Core Module

提供 MongoDB 聚合管道到 SQL 转换的核心基础设施。
"""

from .ast_base import ASTNode
from .expr_base import BaseExpression, FieldReference, LiteralValue
from .expr_registry import ExpressionRegistry
from .stage_base import StageProcessor
from .stage_loader import StageLoader
from .pipeline_runtime import PipelineRuntime

__all__ = [
    'ASTNode',
    'BaseExpression',
    'FieldReference',
    'LiteralValue',
    'ExpressionRegistry',
    'StageProcessor',
    'StageLoader',
    'PipelineRuntime',
]
