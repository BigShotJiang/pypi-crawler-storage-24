"""
Expression Resolver Module

统一的表达式解析器，负责集中处理所有stage中的表达式解析逻辑。
这样可以避免stage之间的内部耦合。
"""

from typing import Any, Optional

from ..stages.project.expr import ProjectExpressionParser


class ExpressionResolver:
    """
    表达式解析器。
    
    统一管理所有stage中的表达式解析，提供一个集中的入口点。
    这样可以避免stage之间相互import，保持模块独立性。
    """
    
    def __init__(self):
        """初始化表达式解析器"""
        # 延迟导入，避免循环依赖
        self._project_parser = None
        self._group_parser = None
    
    @property
    def project_parser(self):
        """获取Project表达式解析器（延迟加载）"""
        if self._project_parser is None:
            self._project_parser = ProjectExpressionParser
        return self._project_parser
    
    def parse_expression_value(
        self, 
        operator: str, 
        value: Any, 
        context: Any
    ) -> Optional[str]:
        """
        解析表达式值。
        
        这是统一的入口点，所有stage都可以通过这个方法来解析表达式。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 表达式字符串
        """
        # 使用ProjectExpressionParser来解析表达式值
        return self.project_parser._parse_expression_value(operator, value, context)
    
    def parse_field_reference(
        self, 
        field_ref: str, 
        context: Any,
        is_post_aggregation: bool = False
    ) -> str:
        """
        解析字段引用。
        
        Args:
            field_ref: 字段引用（如 "$field_name"）
            context: 渲染上下文
            is_post_aggregation: 是否在聚合后
            
        Returns:
            SQL 字段表达式
        """
        if not field_ref.startswith('$'):
            return field_ref
            
        field_name = field_ref[1:]
        
        if is_post_aggregation:
            # 聚合后直接使用字段名
            return field_name
        else:
            # 正常情况添加表前缀
            table_alias = context.from_alias or 't'
            return f'{table_alias}.{field_name}'


# 全局单例
_expression_resolver: ExpressionResolver = None


def get_expression_resolver() -> ExpressionResolver:
    """
    获取全局表达式解析器实例。
    
    Returns:
        ExpressionResolver实例
    """
    global _expression_resolver
    if _expression_resolver is None:
        _expression_resolver = ExpressionResolver()
    return _expression_resolver
