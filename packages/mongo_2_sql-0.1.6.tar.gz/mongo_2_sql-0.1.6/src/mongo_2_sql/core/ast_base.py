"""
AST Base Module

定义抽象语法树（AST）的基础节点类。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class ASTNode(ABC):
    """
    抽象语法树节点的基类。
    
    所有 AST 节点都应继承此类，实现必要的抽象方法。
    """
    
    def __init__(self, node_type: str, **kwargs):
        """
        初始化 AST 节点。
        
        Args:
            node_type: 节点类型标识
            **kwargs: 额外的节点属性
        """
        self.node_type = node_type
        self.properties = kwargs
        self.children: list = []
        self.parent: Optional['ASTNode'] = None
    
    def add_child(self, child: 'ASTNode') -> None:
        """
        添加子节点。
        
        Args:
            child: 要添加的子节点
        """
        child.parent = self
        self.children.append(child)
    
    def remove_child(self, child: 'ASTNode') -> None:
        """
        移除子节点。
        
        Args:
            child: 要移除的子节点
        """
        if child in self.children:
            child.parent = None
            self.children.remove(child)
    
    @abstractmethod
    def accept(self, visitor: 'ASTVisitor') -> Any:
        """
        接受访问者。
        
        Args:
            visitor: AST 访问者
            
        Returns:
            访问结果
        """
        pass
    
    def to_dict(self) -> Dict[str, Any]:
        """
        将节点转换为字典表示。
        
        Returns:
            节点的字典表示
        """
        return {
            'node_type': self.node_type,
            'properties': self.properties,
            'children': [child.to_dict() for child in self.children]
        }
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(type={self.node_type})"


class ASTVisitor(ABC):
    """
    AST 访问者基类。
    
    实现访问者模式，用于遍历和操作 AST。
    """
    
    def visit(self, node: ASTNode) -> Any:
        """
        访问节点。
        
        Args:
            node: 要访问的 AST 节点
            
        Returns:
            访问结果
        """
        method_name = f'visit_{node.node_type}'
        visitor = getattr(self, method_name, self.visit_default)
        return visitor(node)
    
    def visit_default(self, node: ASTNode) -> Any:
        """
        默认访问方法。
        
        Args:
            node: 要访问的 AST 节点
            
        Returns:
            默认访问结果
        """
        results = []
        for child in node.children:
            results.append(self.visit(child))
        return results
