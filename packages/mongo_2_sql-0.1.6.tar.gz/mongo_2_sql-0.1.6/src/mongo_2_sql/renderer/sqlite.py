"""
SQLite Renderer Module

SQLite SQL 渲染器，生成 SQLite 兼容的 SQL 查询。
"""

from typing import Any, Dict, List, Optional
import sqlparse

from ..core.stage_base import RenderContext


class SQLiteRenderer:
    """
    SQLite SQL 渲染器。
    
    将渲染上下文转换为 SQLite 兼容的 SQL 查询。
    
    注意：当前项目中 RenderContext 已经包含了 SQL 生成逻辑，
    这个类提供额外的 SQLite 特定优化和格式化。
    """
    
    def __init__(self):
        """初始化 SQLite 渲染器。"""
        self.dialect = 'sqlite'
    
    def render(self, context: RenderContext) -> str:
        """
        渲染 SQL 查询。
        
        Args:
            context: 渲染上下文
            
        Returns:
            SQLite SQL 查询字符串
        """
        # 使用上下文的 to_sql 方法生成基本 SQL
        sql = context.to_sql()
        
        # 应用 SQLite 特定的优化
        sql = self._optimize_for_sqlite(sql, context)

        # 应用格式化
        sql = self.format_sql(sql)
        
        return sql
    
    def _optimize_for_sqlite(self, sql: str, context: RenderContext) -> str:
        """
        应用 SQLite 特定的优化。
        
        Args:
            sql: 原始 SQL
            context: 渲染上下文
            
        Returns:
            优化后的 SQL
        """
        # SQLite 特定的优化可以在这里添加
        # 例如：
        # - 处理 JSON 函数
        # - 优化数组展开
        # - 处理特定的数据类型
        
        return sql

    def format_sql(self, sql: str) -> str:
        """
        格式化 SQL 查询。
        
        Args:
            sql: SQL 查询字符串
            
        Returns:
            格式化后的 SQL
        """
        # 预处理：按换行符分割，去除首尾空白行，并合并每一行内的空白
        lines = [line.strip() for line in sql.split('\n')]
        # 过滤掉空行
        lines = [line for line in lines if line]
        
        formatted_lines = []
        indent_level = 0
        in_with_clause = False
        in_cte_definition = False # 是否正在定义一个CTE (在 AS ( 之后)
        # 存储CTE名称，用于判断何时退出CTE定义
        cte_names_stack = []

        # 定义需要增加缩进的行首关键字
        # 这些关键字后面通常跟着一个子查询块
        indent_increase_keywords = {
            'AS ('
        }
        # 定义需要减少缩进的行首关键字
        # 这些关键字标志着一个块的结束
        indent_decrease_keywords = {
            ')',
            ') AS'
        }
        # 定义需要减少缩进但自身保持当前缩进的关键字
        # 例如 FROM, WHERE, ORDER BY 等，它们属于上一级块
        indent_decrease_inline_keywords = {
            'FROM', 'JOIN', 'INNER JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'FULL JOIN', 
            'WHERE', 'GROUP BY', 'HAVING', 'ORDER BY', 'LIMIT', 'OFFSET'
        }
        # 定义需要增加缩进的行尾关键字
        # 例如 'AS ('，表示一个CTE或子查询的开始
        indent_increase_on_end = {'AS ('}
        # 定义需要减少缩进的行尾关键字
        # 例如 ')' 或 ') AS'，表示一个CTE或子查询的结束
        indent_decrease_on_end = {')', ') AS'}

        for line in lines:
            original_line = line
            upper_line = line.upper().strip()

            # --- 状态更新逻辑 ---
            # 检查是否进入CTE定义 (AS ( 开始)
            if upper_line.startswith('AS ('):
                in_cte_definition = True
                cte_names_stack.append("current_cte_placeholder") # 实际应用中可能需要解析CTE名称
                indent_level += 1
            # 检查是否退出CTE定义 (匹配 ) 或 ) AS)
            elif in_cte_definition and (upper_line == ')' or upper_line.endswith(') AS')):
                if cte_names_stack:
                    cte_names_stack.pop()
                if not cte_names_stack: # 如果栈为空，说明退出了所有CTE定义
                    in_cte_definition = False
                if indent_level > 0:
                    indent_level -= 1
            # 检查是否进入 WITH 子句
            if upper_line.startswith('WITH'):
                in_with_clause = True
            # 检查是否退出 WITH 子句 (当遇到不在CTE定义中的顶级关键字时)
            elif in_with_clause and not in_cte_definition and any(kw in indent_decrease_inline_keywords for kw in upper_line.split()):
                in_with_clause = False


            # --- 缩进调整逻辑 ---
            current_indent_level = indent_level

            # 1. 检查行首是否是需要减少缩进并内联的关键字
            if any(upper_line.startswith(keyword) for keyword in indent_decrease_inline_keywords):
                if current_indent_level > 0:
                    current_indent_level -= 1
                # 不增加 indent_level，因为这些关键字属于上一级块

            # 2. 检查行首是否是需要增加缩进的关键字
            elif any(upper_line.startswith(keyword) for keyword in indent_increase_keywords):
                current_indent_level += 1

            # 3. 检查行尾是否是需要增加缩进的关键字
            if any(upper_line.endswith(keyword) for keyword in indent_increase_on_end):
                # 对于 'AS (', 我们已经在状态更新中增加了 indent_level
                pass # 状态更新已处理

            # 4. 检查行尾是否是需要减少缩进的关键字
            if any(upper_line.endswith(keyword) for keyword in indent_decrease_on_end):
                # 对于 ')' 或 ') AS', 我们已经在状态更新中减少了 indent_level
                pass # 状态更新已处理


            # --- 格式化输出 ---
            indented_line = '    ' * current_indent_level + line
            formatted_lines.append(indented_line)

            # --- 状态更新后处理 ---
            # 检查行尾是否是逗号且在WITH中，这可能意味着下一个CTE定义
            # 这种情况通常紧跟下一个CTE名称，我们不在此处增加缩进，而是等待 'AS (' 的出现
            # if line.endswith(',') and in_with_clause and not in_cte_definition:
            #     # This logic is implicitly handled by waiting for 'AS ('
            #     pass

        return '\n'.join(formatted_lines)
    
    def quote_identifier(self, identifier: str) -> str:
        """
        引用标识符。
        
        Args:
            identifier: 标识符
            
        Returns:
            引用的标识符
        """
        # SQLite 使用双引号引用标识符
        # 根据请求，不添加任何引号
        return identifier
    
    def escape_string(self, value: str) -> str:
        """
        转义字符串值。
        
        Args:
            value: 字符串值
            
        Returns:
            转义后的字符串
        """
        return value.replace("'", "''")
    
    def supports_feature(self, feature: str) -> bool:
        """
        检查 SQLite 是否支持特定功能。
        
        Args:
            feature: 功能名称
            
        Returns:
            是否支持
        """
        supported_features = {
            'cte': True,
            'window_functions': True,  # SQLite 3.25+
            'json': True,
            'arrays': True,  # 通过 JSON
            'full_text_search': True,  # FTS3/FTS4/FTS5
            'recursive_cte': True,
            'upsert': True,  # SQLite 3.24+
        }
        
        return supported_features.get(feature, False)

    def format_sql(self, sql: str) -> str:
        """
        格式化 SQL 查询。
        
        Args:
            sql: SQL 查询字符串
            
        Returns:
            格式化后的 SQL
        """
        return sqlparse.format(sql, reindent=True, keyword_case='upper')
