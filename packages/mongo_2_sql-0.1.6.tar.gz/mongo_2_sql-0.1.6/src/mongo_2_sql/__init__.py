"""
Mongo to SQL

将 MongoDB 聚合管道转换为 SQL 查询的工具。

Usage:
    >>> from mongo_2_sql import convert_mongo_pipeline_to_sql
    >>> 
    >>> pipeline = [
    ...     { "$match": { "status": "active" } },
    ...     { "$group": { "_id": "$category", "count": { "$sum": 1 } } }
    ... ]
    >>> 
    >>> sql, metadata = convert_mongo_pipeline_to_sql(pipeline, "products")
    >>> print(sql)

Features:
    - 支持多种 MongoDB 聚合阶段：$match, $project, $group, $sort, $limit, $lookup, $unwind
    - 支持复杂的查询表达式和聚合函数
    - 可扩展的架构，易于添加新的阶段处理器
    - 支持多种 SQL 方言

Author: Mongo to SQL Team
Version: 0.1.0
"""

__version__ = '0.1.0'
__author__ = 'Mongo to SQL Team'

from .converter import (
    convert_mongo_pipeline_to_sql,
    MongoToSQLConverter,
    mongo_match_to_sql,
    mongo_project_to_sql,
    mongo_group_to_sql,
)
from .core.pipeline_runtime import PipelineRuntime
from .core.stage_base import RenderContext
from .core.stage_loader import StageLoader

__all__ = [
    # 主要转换函数
    'convert_mongo_pipeline_to_sql',
    'MongoToSQLConverter',
    
    # 便捷函数
    'mongo_match_to_sql',
    'mongo_project_to_sql',
    'mongo_group_to_sql',
    
    # 核心类
    'PipelineRuntime',
    'RenderContext',
    'StageLoader',
    
    # 元信息
    '__version__',
    '__author__',
]
