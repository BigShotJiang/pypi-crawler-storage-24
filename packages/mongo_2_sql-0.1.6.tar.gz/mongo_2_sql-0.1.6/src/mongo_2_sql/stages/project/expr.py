"""
Project Expression Parser Module

解析 MongoDB $project 阶段的投影表达式。
"""

from typing import Any, Dict, List, Optional

from ...core.expr_parser_base import BaseExpressionParser
from ...core.expr_base import (
    BaseExpression,
    BinaryOperation,
    FieldReference,
    FunctionCall,
    LiteralValue,
)
from ...core.expr_registry import ExpressionRegistry
from ...core.stage_base import RenderContext


class ProjectExpressionParser(BaseExpressionParser):
    """
    Project 表达式解析器。
    
    将 MongoDB 投影表达式解析为 SQL SELECT 列。
    """
    
    @classmethod
    def parse(cls, projection: Dict[str, Any], context: RenderContext, is_post_aggregation: bool = False) -> List[str]:
        """
        解析投影表达式并生成 SQL SELECT 列。
        
        Args:
            projection: MongoDB 投影表达式
            context: 渲染上下文
            is_post_aggregation: 是否在聚合之后进行投影
            
        Returns:
            SQL SELECT 列列表
        """
        columns = []
        
        # 检查是否是包含/排除模式
        inclusion_mode = cls._determine_inclusion_mode(projection)
        
        for field, value in projection.items():
            if field == '_id':
                # _id 字段特殊处理
                if value == 0 or value is False:
                    continue  # 排除 _id
                elif value == 1 or value is True:
                    if is_post_aggregation:
                        # 在聚合后，_id 是分组字段，应该引用分组键
                        if context.group_by_columns:
                            # 使用第一个分组字段作为 _id
                            group_field = context.group_by_columns[0]
                            # 移除表前缀获取纯字段名
                            if '.' in group_field:
                                pure_field = group_field.split('.')[-1]
                            else:
                                pure_field = group_field
                            columns.append(cls._create_column(pure_field, None, context, is_post_aggregation))
                        else:
                            # 如果没有分组字段，使用字面量
                            columns.append(cls._create_column('_id', None, context, is_post_aggregation))
                    else:
                        # 聚合前，_id 是普通字段
                        columns.append(cls._create_column('_id', None, context, is_post_aggregation))
                continue
            
            if inclusion_mode:
                # 包含模式：value = 1 表示包含字段
                if value == 1 or value is True:
                    column = cls._create_column(field, None, context, is_post_aggregation)
                    columns.append(column)
                elif isinstance(value, dict):
                    # 表达式投影
                    column = cls._parse_expression_projection(field, value, context, is_post_aggregation)
                    if column:
                        columns.append(column)
                elif isinstance(value, str) and value.startswith('$'):
                    # 字段重命名：{"new_name": "$old_name"}
                    column = cls._parse_field_rename(field, value, context, is_post_aggregation)
                    if column:
                        columns.append(column)
                else:
                    # 字面量值（用于 $addFields）：{"field": "literal_value"}
                    column = cls._parse_literal_value(field, value, context, is_post_aggregation)
                    if column:
                        columns.append(column)
            else:
                # 排除模式：value = 0 表示排除字段
                # 表达式投影在两种模式下都应该工作
                if value == 0 or value is False:
                    continue
                elif isinstance(value, dict):
                    # 表达式投影在排除模式下也应该处理
                    column = cls._parse_expression_projection(field, value, context, is_post_aggregation)
                    if column:
                        columns.append(column)
                elif isinstance(value, str) and value.startswith('$'):
                    # 字段重命名：{"new_name": "$old_name"}
                    column = cls._parse_field_rename(field, value, context, is_post_aggregation)
                    if column:
                        columns.append(column)
                else:
                    # 字面量值（用于 $addFields）：{"field": "literal_value"}
                    column = cls._parse_literal_value(field, value, context, is_post_aggregation)
                    if column:
                        columns.append(column)
        
        return columns
    
    @classmethod
    def _determine_inclusion_mode(cls, projection: Dict[str, Any]) -> bool:
        """
        确定投影模式是包含还是排除。
        
        Args:
            projection: 投影字典
            
        Returns:
            True 表示包含模式，False 表示排除模式
        """
        # 如果有任何字段值为 1 或 True（除了 _id），则是包含模式
        for field, value in projection.items():
            if field != '_id' and (value == 1 or value is True):
                return True
        
        # 如果所有字段都是 0 或 False，则是排除模式
        # 在排除模式下，我们需要选择所有字段
        return False
    
    @classmethod
    def _create_column(cls, field: str, alias: Optional[str], context: RenderContext, is_post_aggregation: bool = False) -> str:
        """
        创建 SELECT 列。
        
        Args:
            field: 字段名
            alias: 别名
            context: 渲染上下文
            is_post_aggregation: 是否在聚合之后进行投影
            
        Returns:
            SQL 列表达式
        """
        table_alias = context.from_alias or 't'
        
        # 处理字段路径
        if field.startswith('"'):
            # 已经是引用的字段
            quoted_field = field
        else:
            if is_post_aggregation:
                # 在聚合后，直接使用字段名（不加表前缀）
                # 因为这些是聚合结果字段
                quoted_field = field
            else:
                # 正常情况，添加表前缀
                parts = field.split('.')
                parts.insert(0, table_alias)
                quoted_field = '.'.join(f'{part}' for part in parts)
        
        if alias:
            return f"{quoted_field} AS {alias}"
        
        # 如果没有别名，使用字段的最后一部分
        field_parts = field.strip('"').split('.')
        return f"{quoted_field} AS {field_parts[-1]}"
    
    @classmethod
    def _parse_expression_projection(cls, alias: str, expr: Dict[str, Any], context: RenderContext, is_post_aggregation: bool = False) -> Optional[str]:
        """
        解析表达式投影。
        
        Args:
            alias: 输出字段别名
            expr: 表达式字典
            context: 渲染上下文
            is_post_aggregation: 是否在聚合之后进行投影
            
        Returns:
            SQL 列表达式，或 None
        """
        if not expr:
            return None
        
        # 获取操作符
        operators = list(expr.keys())
        if len(operators) != 1:
            return None
        
        op = operators[0]
        value = expr[op]
        
        # 解析表达式
        sql_expr = cls._parse_expression_value(op, value, context)
        
        if sql_expr:
            return f"{sql_expr} AS {alias}"
        
        return None
    
    @classmethod
    def _parse_field_rename(cls, alias: str, field_ref: str, context: RenderContext, is_post_aggregation: bool = False) -> Optional[str]:
        """
        解析字段重命名投影。
        
        Args:
            alias: 新字段名
            field_ref: 字段引用（如 "$old_name"）
            context: 渲染上下文
            is_post_aggregation: 是否在聚合之后进行投影
            
        Returns:
            SQL 列表达式，或 None
        """
        if not field_ref.startswith('$'):
            return None
            
        # 提取字段名
        field_name = field_ref[1:]  # 移除开头的 $
        
        # 在聚合后，直接使用字段名（不加表前缀）
        if is_post_aggregation:
            return f"{field_name} AS {alias}"
        else:
            # 正常情况，添加表前缀
            table_alias = context.from_alias or 't'
            return f"{table_alias}.{field_name} AS {alias}"
    
    @classmethod
    def _parse_literal_value(cls, alias: str, value: Any, context: RenderContext, is_post_aggregation: bool = False) -> Optional[str]:
        """
        解析字面量值投影（主要用于 $addFields）。
        
        Args:
            alias: 输出字段别名
            value: 字面量值
            context: 渲染上下文
            is_post_aggregation: 是否在聚合之后进行投影
            
        Returns:
            SQL 列表达式，或 None
        """
        if value is None:
            sql_literal = 'NULL'
        elif isinstance(value, bool):
            sql_literal = 'TRUE' if value else 'FALSE'
        elif isinstance(value, (int, float)):
            sql_literal = str(value)
        elif isinstance(value, str):
            escaped = value.replace("'", "''")
            sql_literal = f"'{escaped}'"
        elif isinstance(value, list):
            import json
            # 将数组转换为 JSON 字符串
            json_str = json.dumps(value)
            escaped = json_str.replace("'", "''")
            sql_literal = f"'{escaped}'"
        elif isinstance(value, dict):
            import json
            # 将字典转换为 JSON 字符串
            json_str = json.dumps(value)
            escaped = json_str.replace("'", "''")
            sql_literal = f"'{escaped}'"
        else:
            sql_literal = f"'{str(value)}'"
        
        return f"{sql_literal} AS {alias}"
    
    @classmethod
    def _parse_expression_value(cls, operator: str, value: Any, context: RenderContext) -> Optional[str]:
        """
        解析表达式值。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 表达式，或 None
        """
        # 字段引用
        if operator == '$' or (isinstance(value, str) and value.startswith('$') and '.' not in value):
            # 简单字段引用
            field = value if isinstance(value, str) else operator
            if field.startswith('$'):
                field = field[1:]
            
            # 检查是否在聚合后进行投影
            if context.has_aggregation and len(context.group_by_columns) > 0:
                # 在聚合后，直接使用字段名（不加表前缀）
                # 因为这些是聚合结果字段
                return field
            else:
                # 正常情况，添加表前缀
                table_alias = context.from_alias or 't'
                return f'{table_alias}.{field}'
        
        # 字面量
        if operator == '$literal':
            return cls._value_to_sql(value)
        
        # 算术操作符
        if operator in cls.ARITHMETIC_OPERATORS:
            return cls._parse_arithmetic_operator(operator, value, context)
        
        # 字符串操作符
        if operator in cls.STRING_OPERATORS:
            return cls._parse_string_operator(operator, value, context)
        
        # 日期操作符
        if operator in cls.DATE_OPERATORS:
            return cls._parse_date_operator(operator, value, context)
        
        # 条件操作符
        if operator in cls.CONDITIONAL_OPERATORS:
            return cls._parse_conditional_operator(operator, value, context)
        
        # 比较操作符
        if operator in cls.COMPARISON_OPERATORS:
            return cls._parse_comparison_operator(operator, value, context)
        
        # 数组操作符
        if operator in cls.ARRAY_OPERATORS:
            return cls._parse_array_operator(operator, value, context)
        
        # 聚合函数（在 project 阶段）
        if operator in ExpressionRegistry.AGGREGATION_FUNCTIONS:
            return cls._parse_aggregation_function(operator, value, context)
        
        return None
    
    @classmethod
    def _parse_arithmetic_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析算术操作符。
        
        Args:
            operator: 操作符
            value: 操作数值（数组）
            context: 渲染上下文
            
        Returns:
            SQL 算术表达式
        """
        op_map = {
            '$add': '+',
            '$subtract': '-',
            '$multiply': '*',
            '$divide': '/',
            '$mod': '%',
        }
        
        sql_op = op_map.get(operator, '+')
        
        if not isinstance(value, list):
            raise ValueError(f"{operator} requires an array of operands")
        
        # 解析每个操作数
        operands = []
        for item in value:
            if isinstance(item, str) and item.startswith('$'):
                # 字段引用
                field = item[1:]
                table_alias = context.from_alias or 't'
                operands.append(f'{table_alias}.{field}')
            else:
                # 字面值
                operands.append(cls._value_to_sql(item))
        
        if len(operands) == 1:
            return operands[0]
        
        # 用操作符连接所有操作数
        return f"({f' {sql_op} '.join(operands)})"
    
    @classmethod
    def _parse_string_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析字符串操作符。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 字符串表达式
        """
        if operator == '$concat':
            if not isinstance(value, list):
                raise ValueError("$concat requires an array of strings")
            
            parts = []
            for item in value:
                if isinstance(item, str) and item.startswith('$'):
                    field = item[1:]
                    table_alias = context.from_alias or 't'
                    parts.append(f'{table_alias}.{field}')
                else:
                    parts.append(cls._value_to_sql(item))
            
            return f"CONCAT({', '.join(parts)})"
        
        if operator == '$toLower':
            expr = cls._parse_operand(value, context)
            return f"LOWER({expr})"
        
        if operator == '$toUpper':
            expr = cls._parse_operand(value, context)
            return f"UPPER({expr})"
        
        if operator == '$substr':
            if not isinstance(value, list) or len(value) < 2:
                raise ValueError("$substr requires [string, start, length]")
            
            str_expr = cls._parse_operand(value[0], context)
            start = cls._parse_operand(value[1], context)
            length = cls._parse_operand(value[2], context) if len(value) > 2 else 'LENGTH(' + str_expr + ')'
            
            return f"SUBSTR({str_expr}, {start}, {length})"
        
        return ""
    
    @classmethod
    def _parse_date_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析日期操作符。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 日期表达式
        """
        if operator == '$dateToString':
            if isinstance(value, dict):
                date = value.get('date', '')
                format_str = value.get('format', '%Y-%m-%d')
                
                date_expr = cls._parse_operand(date, context)
                # SQLite 使用 STRFTIME
                return f"STRFTIME('{format_str}', {date_expr})"
        
        # 其他日期操作符
        date_part_map = {
            '$year': '%Y',
            '$month': '%m',
            '$dayOfMonth': '%d',
            '$hour': '%H',
            '$minute': '%M',
            '$second': '%S',
        }
        
        if operator in date_part_map:
            expr = cls._parse_operand(value, context)
            format_str = date_part_map[operator]
            return f"CAST(STRFTIME('{format_str}', {expr}) AS INTEGER)"
        
        return ""
    
    @classmethod
    def _parse_conditional_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析条件操作符。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 条件表达式
        """
        if operator == '$cond':
            if isinstance(value, dict):
                # { if: <boolean>, then: <true>, else: <false> }
                if_expr = cls._parse_operand(value.get('if'), context)
                then_expr = cls._parse_operand(value.get('then'), context)
                else_expr = cls._parse_operand(value.get('else'), context)
                
                return f"CASE WHEN {if_expr} THEN {then_expr} ELSE {else_expr} END"
            
            elif isinstance(value, list) and len(value) == 3:
                # [ <if>, <then>, <else> ]
                if_expr = cls._parse_operand(value[0], context)
                then_expr = cls._parse_operand(value[1], context)
                else_expr = cls._parse_operand(value[2], context)
                
                return f"CASE WHEN {if_expr} THEN {then_expr} ELSE {else_expr} END"
        
        if operator == '$ifNull':
            if isinstance(value, list) and len(value) >= 1:
                expr = cls._parse_operand(value[0], context)
                replacement = cls._parse_operand(value[1], context) if len(value) > 1 else 'NULL'
                
                return f"COALESCE({expr}, {replacement})"
        
        return ""
    
    @classmethod
    def _parse_comparison_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析比较操作符。
        
        Args:
            operator: 操作符
            value: 操作数值（数组：[左操作数, 右操作数]）
            context: 渲染上下文
            
        Returns:
            SQL 比较表达式
        """
        if not isinstance(value, list) or len(value) != 2:
            raise ValueError(f"{operator} requires an array with exactly 2 operands")
        
        left_operand = cls._parse_operand(value[0], context)
        right_operand = cls._parse_operand(value[1], context)
        
        op_map = {
            '$eq': '=',
            '$ne': '!=',
            '$gt': '>',
            '$gte': '>=',
            '$lt': '<',
            '$lte': '<=',
        }
        
        sql_op = op_map.get(operator, '=')
        return f"({left_operand} {sql_op} {right_operand})"
    
    @classmethod
    def _parse_array_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析数组操作符。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 数组表达式
        """
        if operator == '$size':
            expr = cls._parse_operand(value, context)
            return f"JSON_ARRAY_LENGTH({expr})"
        
        if operator == '$arrayElemAt':
            if isinstance(value, list) and len(value) == 2:
                array_expr = cls._parse_operand(value[0], context)
                index_expr = cls._parse_operand(value[1], context)
                # SQLite JSON 数组索引从 0 开始
                return f"JSON_EXTRACT({array_expr}, '$[' || {index_expr} || ']')"
        
        return ""
    
    @classmethod
    def _parse_aggregation_function(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析聚合函数。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 聚合函数表达式
        """
        func_map = {
            '$sum': 'SUM',
            '$avg': 'AVG',
            '$min': 'MIN',
            '$max': 'MAX',
            '$count': 'COUNT',
        }
        
        func_name = func_map.get(operator, operator.lstrip('$').upper())
        
        if value == 1 or value is True:
            # COUNT(*)
            return f"{func_name}(*)"
        
        expr = cls._parse_operand(value, context)
        return f"{func_name}({expr})"
    
    @classmethod
    def _parse_operand(cls, value: Any, context: RenderContext) -> str:
        """
        解析操作数。
        
        Args:
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 表达式
        """
        if value is None:
            return 'NULL'
        
        if isinstance(value, str):
            if value.startswith('$'):
                # 字段引用
                field = value[1:]
                table_alias = context.from_alias or 't'
                return f'{table_alias}.{field}'
            return cls._value_to_sql(value)
        
        if isinstance(value, (int, float, bool)):
            return cls._value_to_sql(value)
        
        if isinstance(value, dict):
            # 嵌套表达式
            operators = list(value.keys())
            if len(operators) == 1:
                return cls._parse_expression_value(operators[0], value[operators[0]], context) or ''
        
        return cls._value_to_sql(value)
    



