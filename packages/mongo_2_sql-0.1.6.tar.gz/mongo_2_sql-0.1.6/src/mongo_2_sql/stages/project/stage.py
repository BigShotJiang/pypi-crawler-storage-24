"""
Project Stage Processor Module

处理 MongoDB $project 阶段，对应 SQL 的 SELECT 子句。
"""

from typing import Any, Dict

from ...core.cte_stage_base import CTEStageProcessor
from ...core.stage_base import RenderContext
from .expr import ProjectExpressionParser


class ProjectStage(CTEStageProcessor):
    """
    Project 阶段处理器。
    
    将 MongoDB $project 阶段转换为 SQL SELECT 子句。
    
    示例:
        MongoDB: { $project: { name: 1, age: 1 } }
        SQL: SELECT t.name, t.age
        
        MongoDB: { $project: { fullName: { $concat: ["$firstName", " ", "$lastName"] } } }
        SQL: SELECT CONCAT(t.firstName, ' ', t.lastName) AS fullName
    """
    
    def __init__(self):
        """初始化 Project 阶段处理器。"""
        super().__init__('$project')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $project 阶段。
        
        Args:
            stage_value: 投影规范字典
            context: 渲染上下文
        """
        if not isinstance(stage_value, dict):
            raise ValueError("$project stage value must be a document")
        
        # 检查是否在聚合后进行投影
        is_post_aggregation = context.has_aggregation and len(context.group_by_columns) > 0

        self.process_with_cte(stage_value, context, self.build_cte_sql)

    def should_use_cte(self, stage_value: Any, context: RenderContext) -> bool:
        """
        判断是否应该使用 CTE 来处理此 $project 阶段。
        
        Args:
            stage_value: 阶段值
            context: 渲染上下文
            
        Returns:
            是否使用 CTE
        """
        if not isinstance(stage_value, dict):
            return False
        return self._should_use_cte(stage_value, context)
    
    def _should_use_cte(self, stage_value: Dict[str, Any], context: RenderContext) -> bool:
        """
        判断是否应该使用 CTE 来处理此 $project 阶段。
        
        Args:
            stage_value: 投影规范字典
            context: 渲染上下文
            
        Returns:
            是否使用 CTE
        """
        # 如果有复杂的表达式投影，使用 CTE
        for value in stage_value.values():
            if isinstance(value, dict) and len(value) > 0:
                # 包含表达式的投影
                return True
        
        # 如果在聚合后进行投影，使用 CTE
        if context.has_aggregation and context.group_by_columns:
            return True
            
        # 如果来自 CTE（即前面有其他阶段创建了中间表），也使用 CTE
        if context.from_table and context.from_table.startswith('cte_'):
            return True
            
        return False
    
    def build_cte_sql(self, stage_value: Any, context: RenderContext,
                     original_from_table: str, original_from_alias: str) -> str:
        """
        构建 $project CTE 的 SQL 内容。
        
        Args:
            stage_value: 投影规范字典
            context: 渲染上下文
            original_from_table: 原始表名
            original_from_alias: 原始表别名
            
        Returns:
            CTE SQL 内容
        """
        # 检查是否在聚合后进行投影
        is_post_aggregation = context.has_aggregation and len(context.group_by_columns) > 0
        
        # 解析投影表达式
        columns = ProjectExpressionParser.parse(stage_value, context, is_post_aggregation)
        
        # 构建 CTE 的 SELECT 子句
        cte_select = "SELECT " + ", ".join(columns)
        cte_from = f"FROM {original_from_table}"
        if original_from_alias:
            cte_from += f" AS {original_from_alias}"
        
        cte_sql = f"{cte_select}\n{cte_from}"
        
        # 添加 WHERE 条件（如果有）
        if context.where_conditions:
            where_clause = "WHERE\n" + " AND ".join(["1=1\n"] + context.where_conditions)
            cte_sql += f"\n{where_clause}"
        
        # 如果有 GROUP BY，也添加进去
        if context.group_by_columns:
            group_clause = "GROUP BY\n" + ", ".join(context.group_by_columns)
            cte_sql += f"\n{group_clause}"
        
        return cte_sql
    

    
    def _process_traditional(self, stage_value: Dict[str, Any], context: RenderContext, is_post_aggregation: bool) -> None:
        """
        传统方式处理 $project 阶段。
        
        Args:
            stage_value: 投影规范字典
            context: 渲染上下文
            is_post_aggregation: 是否在聚合之后
        """
        # 解析投影表达式
        columns = ProjectExpressionParser.parse(stage_value, context, is_post_aggregation)
        
        # 检查是否需要替换 SELECT 列
        # 如果已有列且包含聚合函数，则这是一个后续的 $project 阶段
        should_replace = False
        if context.select_columns:
            # 检查现有列中是否包含聚合函数
            for col in context.select_columns:
                if any(agg_func in col.upper() for agg_func in ['SUM(', 'COUNT(', 'AVG(', 'MIN(', 'MAX(']):
                    should_replace = True
                    break
        
        if should_replace:
            # 替换 SELECT 列，只保留当前投影的列
            context.select_columns = columns
        else:
            # 添加到 SELECT 列
            for column in columns:
                context.add_select_column(column)
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $project 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if not isinstance(stage_value, dict):
            return False
        
        # 空字典是有效的（但会投影空结果）
        if not stage_value:
            return True
        
        # 检查键是否有效
        for key, value in stage_value.items():
            if not isinstance(key, str):
                return False
            
            # 值可以是：
            # - 1 / 0（包含/排除）
            # - true / false
            # - 表达式对象
            # - 字段引用字符串
            if isinstance(value, (int, bool)):
                continue
            elif isinstance(value, str):
                continue
            elif isinstance(value, dict):
                continue
            else:
                return False
        
        return True
