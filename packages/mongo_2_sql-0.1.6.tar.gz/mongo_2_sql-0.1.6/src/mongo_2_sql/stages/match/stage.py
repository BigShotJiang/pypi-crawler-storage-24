"""
Match Stage Processor Module

处理 MongoDB $match 阶段，对应 SQL 的 WHERE 子句。
"""

from typing import Any, Dict

from ...core.stage_base import RenderContext, StageProcessor
from .expr import MatchExpressionParser


class MatchStage(StageProcessor):
    """
    Match 阶段处理器。
    
    将 MongoDB $match 阶段转换为 SQL WHERE 子句。
    
    示例:
        MongoDB: { $match: { status: "active", age: { $gte: 18 } } }
        SQL: WHERE "t"."status" = 'active' AND "t"."age" >= 18
    """
    
    def __init__(self):
        """初始化 Match 阶段处理器。"""
        super().__init__('$match')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $match 阶段。
        
        Args:
            stage_value: 匹配条件字典
            context: 渲染上下文
        """
        if not isinstance(stage_value, dict):
            raise ValueError("$match stage value must be a document")
        
        # 解析匹配表达式
        condition = MatchExpressionParser.parse(stage_value, context)
        
        if condition:
            context.add_where_condition(condition)
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $match 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if not isinstance(stage_value, dict):
            return False
        
        # 空字典是有效的（匹配所有文档）
        if not stage_value:
            return True
        
        # 检查键是否有效
        for key in stage_value.keys():
            if not isinstance(key, str):
                return False
        
        return True
