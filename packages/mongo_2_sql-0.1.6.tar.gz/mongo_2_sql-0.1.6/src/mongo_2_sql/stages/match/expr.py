"""
Match Expression Parser Module

解析 MongoDB $match 阶段的查询表达式。
"""

from typing import Any, Dict, List, Optional, Union

from ...core.expr_parser_base import BaseExpressionParser
from ...core.expr_base import (
    BaseExpression,
    BinaryOperation,
    FieldReference,
    FunctionCall,
    LiteralValue,
)
from ...core.expr_registry import ExpressionRegistry
from ...core.stage_base import RenderContext


class MatchExpressionParser(BaseExpressionParser):
    """
    Match 表达式解析器。
    
    将 MongoDB 查询表达式解析为 SQL WHERE 子句。
    """
    
    # 逻辑操作符
    LOGICAL_OPERATORS = {'$and', '$or', '$nor', '$not'}
    
    # 元素操作符
    ELEMENT_OPERATORS = {'$exists', '$type'}
    
    # 评估操作符
    EVALUATION_OPERATORS = {'$regex', '$text', '$where', '$expr'}
    
    # 数组操作符
    ARRAY_OPERATORS = {'$all', '$elemMatch', '$size'}
    
    # 比较操作符
    COMPARISON_OPERATORS = {'$eq', '$ne', '$gt', '$gte', '$lt', '$lte', '$in', '$nin'}
    
    @classmethod
    def parse(cls, query: Dict[str, Any], context: RenderContext) -> str:
        """
        解析查询表达式并生成 SQL WHERE 子句。
        
        Args:
            query: MongoDB 查询表达式
            context: 渲染上下文
            
        Returns:
            SQL WHERE 子句字符串
        """
        if not query:
            return ""
        
        condition = cls._parse_query(query, context)
        return condition
    
    @classmethod
    def _parse_query(cls, query: Dict[str, Any], context: RenderContext) -> str:
        """
        解析查询字典。
        
        Args:
            query: 查询字典
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        conditions = []
        
        for key, value in query.items():
            if key.startswith('$'):
                # 顶级逻辑操作符
                condition = cls._parse_logical_operator(key, value, context)
                if condition:
                    conditions.append(condition)
            else:
                # 字段条件
                condition = cls._parse_field_condition(key, value, context)
                if condition:
                    conditions.append(condition)
        
        if not conditions:
            return ""
        
        if len(conditions) == 1:
            return conditions[0]
        
        # 多个条件组，每个条件组用换行分隔
        return cls._format_conditions_with_newlines(conditions)
    
    @classmethod
    def _parse_logical_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析逻辑操作符。
        
        Args:
            operator: 操作符名称（如 '$and', '$or'）
            value: 操作符值
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        if operator == '$and':
            if not isinstance(value, list):
                raise ValueError("$and requires an array")
            conditions = [cls._parse_query(item, context) for item in value]
            conditions = [c for c in conditions if c]
            if not conditions:
                return ""
            return f"({' AND '.join(dict.fromkeys(conditions))})"
        
        elif operator == '$or':
            if not isinstance(value, list):
                raise ValueError("$or requires an array")
            conditions = [cls._parse_query(item, context) for item in value]
            conditions = [c for c in conditions if c]
            if not conditions:
                return ""
            return f"({' OR '.join(dict.fromkeys(conditions))})"
        
        elif operator == '$nor':
            if not isinstance(value, list):
                raise ValueError("$nor requires an array")
            conditions = [cls._parse_query(item, context) for item in value]
            conditions = [c for c in conditions if c]
            if not conditions:
                return ""
            return f"(NOT ({' OR '.join(dict.fromkeys(conditions))}))\n"
        
        elif operator == '$not':
            condition = cls._parse_query(value, context) if isinstance(value, dict) else cls._parse_value_condition(value, context)
            if not condition:
                return ""
            return f"(NOT {condition})"
        
        return ""
    
    @classmethod
    def _parse_field_condition(cls, field: str, value: Any, context: RenderContext) -> str:
        """
        解析字段条件。
        
        Args:
            field: 字段名
            value: 字段值或条件
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        # 引用字段名
        quoted_field = cls._quote_field(field, context)
        
        # 如果值是字典，可能包含操作符
        if isinstance(value, dict):
            return cls._parse_operator_condition(quoted_field, value, context)
        
        # 简单相等比较
        sql_value = cls._value_to_sql(value)
        return f"({quoted_field} = {sql_value})"
    
    @classmethod
    def _parse_operator_condition(cls, field: str, operators: Dict[str, Any], context: RenderContext) -> str:
        """
        解析操作符条件。
        
        Args:
            field: 已引用的字段名
            operators: 操作符字典
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        conditions = []
        
        for op, value in operators.items():
            condition = cls._parse_single_operator(field, op, value, context)
            if condition:
                conditions.append(condition)
        
        if not conditions:
            return ""
        
        if len(conditions) == 1:
            return conditions[0]
        
        return f"({' AND '.join(dict.fromkeys(conditions))})"
    
    @classmethod
    def _parse_single_operator(cls, field: str, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析单个操作符。
        
        Args:
            field: 已引用的字段名
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        # 比较操作符
        if operator in cls.COMPARISON_OPERATORS:
            return cls._parse_comparison_operator(field, operator, value, context)
        
        # 元素操作符
        if operator in cls.ELEMENT_OPERATORS:
            return cls._parse_element_operator(field, operator, value, context)
        
        # 数组操作符
        if operator in cls.ARRAY_OPERATORS:
            return cls._parse_array_operator(field, operator, value, context)
        
        # 评估操作符
        if operator in cls.EVALUATION_OPERATORS:
            return cls._parse_evaluation_operator(field, operator, value, context)
        
        # 逻辑操作符（在字段上下文中）
        if operator in cls.LOGICAL_OPERATORS:
            return cls._parse_logical_operator(operator, value, context)
        
        return ""
    
    @classmethod
    def _parse_comparison_operator(cls, field: str, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析比较操作符。
        
        Args:
            field: 已引用的字段名
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        sql_value = cls._value_to_sql(value)
        
        op_map = {
            '$eq': '=',
            '$ne': '!=',
            '$gt': '>',
            '$gte': '>=',
            '$lt': '<',
            '$lte': '<=',
        }
        
        if operator in op_map:
            return f"({field} {op_map[operator]} {sql_value})"
        
        if operator == '$in':
            if not isinstance(value, list):
                raise ValueError("$in requires an array")
            values_sql = ', '.join(dict.fromkeys(cls._value_to_sql(v) for v in value))
            return f"({field} IN ({values_sql}))"
        
        if operator == '$nin':
            if not isinstance(value, list):
                raise ValueError("$nin requires an array")
            values_sql = ', '.join(dict.fromkeys(cls._value_to_sql(v) for v in value))
            return f"({field} NOT IN ({values_sql}))"
        
        return ""
    
    @classmethod
    def _parse_element_operator(cls, field: str, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析元素操作符。
        
        Args:
            field: 已引用的字段名
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        if operator == '$exists':
            if value:
                return f"({field} IS NOT NULL)"
            else:
                return f"({field} IS NULL)"
        
        if operator == '$type':
            # $type 检查字段类型
            # 在 SQL 中可以使用 TYPEOF 函数（SQLite）或其他方式
            # 这里简化处理
            return f"(TYPEOF({field}) = '{value}')"
        
        return ""
    
    @classmethod
    def _parse_array_operator(cls, field: str, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析数组操作符。
        
        Args:
            field: 已引用的字段名
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        if operator == '$size':
            # 数组大小比较
            # 在 SQLite 中可以使用 JSON_ARRAY_LENGTH
            return f"(JSON_ARRAY_LENGTH({field}) = {value})"
        
        if operator == '$all':
            # 包含所有元素
            # 这需要多个条件，简化处理
            if isinstance(value, list):
                conditions = []
                for item in value:
                    sql_item = cls._value_to_sql(item)
                    conditions.append(f"({field} LIKE '%' || {sql_item} || '%')")
                return f"({' AND '.join(conditions)})"
        
        return ""
    
    @classmethod
    def _parse_evaluation_operator(cls, field: str, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析评估操作符。
        
        Args:
            field: 已引用的字段名
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        if operator == '$regex':
            return cls._parse_regex_operator(field, value, context)
        
        if operator == '$text':
            # 全文搜索
            # 在 SQLite 中可以使用 FTS
            if isinstance(value, dict):
                search = value.get('$search', '')
                return f"({field} LIKE '%{search}%')"
        
        return ""
    
    @classmethod
    def _parse_regex_operator(cls, field: str, value: Any, context: RenderContext) -> str:
        """
        解析正则表达式操作符。
        
        Args:
            field: 已引用的字段名
            value: 正则表达式
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        if isinstance(value, dict):
            # 包含选项的正则
            pattern = value.get('$regex', '')
            options = value.get('$options', '')
        else:
            pattern = value
            options = ''
        
        # 转换为 LIKE 模式
        like_pattern = cls._regex_to_like(pattern)
        
        # 处理选项
        case_sensitive = 'i' not in options
        
        if case_sensitive:
            return f"({field} LIKE '{like_pattern}')"
        else:
            # SQLite 默认是大小写不敏感的，但可以使用 COLLATE NOCASE
            return f"(LOWER({field}) LIKE LOWER('{like_pattern}'))"
    
    @classmethod
    def _regex_to_like(cls, pattern: str) -> str:
        """
        将正则表达式转换为 SQL LIKE 模式。
        
        Args:
            pattern: 正则表达式
            
        Returns:
            LIKE 模式
        """
        # 处理锚点
        has_start = pattern.startswith('^')
        has_end = pattern.endswith('$')
        
        if has_start:
            pattern = pattern[1:]
        if has_end:
            pattern = pattern[:-1]
        
        # 转换通配符
        pattern = pattern.replace('.*', '%')
        pattern = pattern.replace('.?', '_')
        pattern = pattern.replace('.', '_')
        pattern = pattern.replace('.*', '%')
        
        # 转义 LIKE 特殊字符
        pattern = pattern.replace('%', '\\%')
        pattern = pattern.replace('_', '\\_')
        
        # 恢复通配符
        pattern = pattern.replace('%', '%')
        pattern = pattern.replace('_', '_')
        
        # 添加通配符
        if not has_start:
            pattern = '%' + pattern
        if not has_end:
            pattern = pattern + '%'
        
        return pattern
    
    @classmethod
    def _parse_value_condition(cls, value: Any, context: RenderContext) -> str:
        """
        解析值条件（用于 $not 等）。
        
        Args:
            value: 值
            context: 渲染上下文
            
        Returns:
            SQL 条件字符串
        """
        sql_value = cls._value_to_sql(value)
        return sql_value
    
    @classmethod
    def _quote_field(cls, field: str, context: RenderContext) -> str:
        """
        引用字段名。
        
        Args:
            field: 字段名
            context: 渲染上下文
            
        Returns:
            引用的字段名
        """
        # 处理嵌套字段路径
        parts = field.split('.')
        
        # 添加表别名
        table_alias = context.from_alias or 't'
        parts.insert(0, table_alias)
        
        return '.'.join(f'{part}' for part in parts)
    
    @classmethod
    def _format_conditions_with_newlines(cls, conditions: List[str]) -> str:
        """
        用换行符格式化条件组。
        
        Args:
            conditions: 条件列表
            
        Returns:
            格式化后的条件字符串
        """
        if not conditions:
            return ""
        
        if len(conditions) == 1:
            return conditions[0]
        
        # 将多个条件用换行符连接
        return "\n AND ".join(dict.fromkeys(conditions))
