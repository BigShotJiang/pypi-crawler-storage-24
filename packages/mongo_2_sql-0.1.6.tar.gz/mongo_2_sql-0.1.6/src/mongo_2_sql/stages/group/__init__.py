"""
Group Stage Module

处理 MongoDB $group 阶段，对应 SQL 的 GROUP BY 子句。
"""

from .stage import GroupStage
from .expr import GroupExpressionParser

__all__ = ['GroupStage', 'GroupExpressionParser']
