"""
Group Stage Processor Module

处理 MongoDB $group 阶段，对应 SQL 的 GROUP BY 子句。
"""

from typing import Any, Dict

from ...core.cte_stage_base import CTEStageProcessor
from ...core.stage_base import RenderContext
from .expr import GroupExpressionParser


class GroupStage(CTEStageProcessor):
    """
    Group 阶段处理器。
    
    将 MongoDB $group 阶段转换为 SQL GROUP BY 子句和聚合函数。
    
    示例:
        MongoDB: { $group: { _id: "$category", total: { $sum: "$amount" } } }
        SQL: SELECT t.category AS _id, SUM(t.amount) AS total GROUP BY t.category
        
        MongoDB: { $group: { _id: null, count: { $sum: 1 }, avg: { $avg: "$score" } } }
        SQL: SELECT COUNT(*) AS count, AVG(t.score) AS avg
    """
    
    def __init__(self):
        """初始化 Group 阶段处理器。"""
        super().__init__('$group')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $group 阶段。
        
        Args:
            stage_value: 分组规范字典
            context: 渲染上下文
        """
        if not isinstance(stage_value, dict):
            raise ValueError("$group stage value must be a document")
        
        # 使用 CTE 方式处理 $group 阶段
        self.process_with_cte(stage_value, context, self.build_cte_sql)
    
    def should_use_cte(self, stage_value: Any, context: RenderContext) -> bool:
        """
        判断是否应该使用 CTE 来处理此 $group 阶段。
        
        Args:
            stage_value: 阶段值
            context: 渲染上下文
            
        Returns:
            是否使用 CTE
        """
        # Group 阶段总是使用 CTE，因为它涉及聚合操作
        return True
    
    def build_cte_sql(self, stage_value: Any, context: RenderContext,
                     original_from_table: str, original_from_alias: str) -> str:
        """
        构建 $group CTE 的 SQL 内容。
        
        Args:
            stage_value: 分组规范字典
            context: 渲染上下文
            original_from_table: 原始表名
            original_from_alias: 原始表别名
            
        Returns:
            CTE SQL 内容
        """
        # 设置聚合标志
        context.has_aggregation = True
        
        # 解析分组表达式
        group_by_columns, select_columns, having_conditions = GroupExpressionParser.parse(
            stage_value, context
        )
        
        # 构建 CTE 的 SELECT 子句
        cte_select = "SELECT " + ", ".join(select_columns)
        cte_from = f"FROM {original_from_table}"
        if original_from_alias:
            cte_from += f" AS {original_from_alias}"
        
        cte_sql = f"{cte_select}\n{cte_from}"
        
        # 添加 WHERE 条件（如果有）
        if context.where_conditions:
            where_clause = "WHERE " + " AND ".join(["1=1\n"] + context.where_conditions)
            cte_sql += f"\n\t{where_clause}"
        
        # 添加 GROUP BY 子句
        if group_by_columns:
            group_clause = "GROUP BY\n\t" + ", ".join(group_by_columns)
            cte_sql += f"\n\t{group_clause}"
        
        # 添加 HAVING 条件（如果有）
        if having_conditions:
            having_clause = "HAVING\n\t" + " AND ".join(having_conditions)
            cte_sql += f"\n\t{having_clause}"
        
        return cte_sql
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $group 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if not isinstance(stage_value, dict):
            return False
        
        # _id 字段是必需的
        if '_id' not in stage_value:
            return False
        
        # 验证累加器字段
        for field, value in stage_value.items():
            if field == '_id':
                continue
            
            # 值必须是累加器表达式
            if not isinstance(value, dict):
                # 可以是字面值
                continue
            
            # 检查是否是有效的累加器
            operators = list(value.keys())
            if len(operators) != 1:
                return False
            
            op = operators[0]
            if not op.startswith('$'):
                return False
        
        return True