"""
Group Expression Parser Module

解析 MongoDB $group 阶段的聚合表达式。
"""

from typing import Any, Dict, List, Optional, Tuple

from ...core.expr_parser_base import BaseExpressionParser
from ...core.expr_registry import ExpressionRegistry
from ...core.stage_base import RenderContext


class GroupExpressionParser(BaseExpressionParser):
    """
    Group 表达式解析器。
    
    将 MongoDB $group 表达式解析为 SQL GROUP BY 和聚合函数。
    """
    
    @classmethod
    def parse(cls, group_spec: Dict[str, Any], context: RenderContext) -> Tuple[List[str], List[str], List[str]]:
        """
        解析 $group 规范。
        
        Args:
            group_spec: $group 规范字典
            context: 渲染上下文
            
        Returns:
            (group_by_columns, select_columns, having_conditions) 元组
        """
        group_by_columns = []
        select_columns = []
        having_conditions = []
        
        # 处理 _id 字段（分组键）
        id_value = group_spec.get('_id')
        
        if id_value is None:
            # 全局分组
            pass
        elif isinstance(id_value, str):
            if id_value.startswith('$'):
                # 单个字段分组
                field = id_value[1:]
                table_alias = context.from_alias or 't'
                group_col = f'{table_alias}.{field}'
                group_by_columns.append(group_col)
                select_columns.append(f'{group_col} AS _id')
            else:
                # 常量分组
                select_columns.append(f"'{id_value}' AS _id")
        elif isinstance(id_value, dict):
            # 复合分组键
            group_cols, select_cols = cls._parse_group_key(id_value, context)
            group_by_columns.extend(group_cols)
            select_columns.extend(select_cols)
        
        # 处理累加器字段
        for field, expr in group_spec.items():
            if field == '_id':
                continue
            
            if isinstance(expr, dict):
                acc_expr = cls._parse_accumulator(field, expr, context)
                if acc_expr:
                    select_columns.append(acc_expr)
            else:
                # 简单值
                sql_value = cls._value_to_sql(expr)
                select_columns.append(f"{sql_value} AS {field}")
        
        return group_by_columns, select_columns, having_conditions
    
    @classmethod
    def _parse_group_key(cls, key_spec: Dict[str, Any], context: RenderContext) -> Tuple[List[str], List[str]]:
        """
        解析复合分组键。
        
        Args:
            key_spec: 分组键规范
            context: 渲染上下文
            
        Returns:
            (group_by_columns, select_columns) 元组
        """
        group_by_columns = []
        select_columns = []
        
        for key_name, key_value in key_spec.items():
            if isinstance(key_value, str) and key_value.startswith('$'):
                field = key_value[1:]
                table_alias = context.from_alias or 't'
                group_col = f'{table_alias}.{field}'
                group_by_columns.append(group_col)
                select_columns.append(f'{group_col} AS {key_name}')
            else:
                # 表达式分组键
                expr_sql = cls._parse_expression(key_value, context)
                if expr_sql:
                    group_by_columns.append(expr_sql)
                    select_columns.append(f'{expr_sql} AS {key_name}')
        
        return group_by_columns, select_columns
    
    @classmethod
    def _parse_accumulator(cls, output_field: str, expr: Dict[str, Any], context: RenderContext) -> Optional[str]:
        """
        解析累加器表达式。
        
        Args:
            output_field: 输出字段名
            expr: 累加器表达式字典
            context: 渲染上下文
            
        Returns:
            SQL 聚合表达式，或 None
        """
        if not expr:
            return None
        
        # 获取累加器操作符
        operators = list(expr.keys())
        if len(operators) != 1:
            return None
        
        op = operators[0]
        value = expr[op]
        
        if op not in cls.ACCUMULATORS:
            return None
        
        # 映射到 SQL 函数
        func_map = {
            '$sum': 'SUM',
            '$avg': 'AVG',
            '$min': 'MIN',
            '$max': 'MAX',
            '$count': 'COUNT',
            '$first': 'FIRST_VALUE',
            '$last': 'LAST_VALUE',
            '$push': 'JSON_GROUP_ARRAY',
            '$addToSet': 'JSON_GROUP_ARRAY',
            '$stdDevPop': 'STDDEV_POP',
            '$stdDevSamp': 'STDDEV_SAMP',
        }
        
        func_name = func_map.get(op, op.lstrip('$').upper())
        
        # 解析参数
        if value == 1 and op == '$sum':
            # SUM(1) = COUNT(*)
            return f"COUNT(*) AS {output_field}"
        
        if value == 1 and op == '$count':
            return f"COUNT(*) AS {output_field}"
        
        if isinstance(value, str) and value.startswith('$'):
            # 字段引用
            field = value[1:]
            table_alias = context.from_alias or 't'
            
            if op in ('$push', '$addToSet'):
                # JSON 数组聚合
                distinct = 'DISTINCT ' if op == '$addToSet' else ''
                return f"JSON_GROUP_ARRAY({distinct}{table_alias}.{field}) AS {output_field}"
            
            return f"{func_name}({table_alias}.{field}) AS {output_field}"
        
        # 表达式参数
        expr_sql = cls._parse_expression(value, context)
        if expr_sql:
            if op in ('$push', '$addToSet'):
                distinct = 'DISTINCT ' if op == '$addToSet' else ''
                return f"JSON_GROUP_ARRAY({distinct}{expr_sql}) AS {output_field}"
            
            return f"{func_name}({expr_sql}) AS {output_field}"
        
        # 字面值
        sql_value = cls._value_to_sql(value)
        return f"{func_name}({sql_value}) AS {output_field}"
    
    @classmethod
    def _parse_expression(cls, value: Any, context: RenderContext) -> Optional[str]:
        """
        解析表达式。
        
        Args:
            value: 表达式值
            context: 渲染上下文
            
        Returns:
            SQL 表达式，或 None
        """
        if value is None:
            return None
        
        if isinstance(value, str):
            if value.startswith('$'):
                field = value[1:]
                table_alias = context.from_alias or 't'
                return f'{table_alias}.{field}'
            return cls._value_to_sql(value)
        
        if isinstance(value, (int, float, bool)):
            return cls._value_to_sql(value)
        
        if isinstance(value, dict):
            # 嵌套表达式 - 使用统一的ExpressionResolver
            from ...core.expression_resolver import get_expression_resolver
            resolver = get_expression_resolver()
            operators = list(value.keys())
            if len(operators) == 1:
                return resolver.parse_expression_value(
                    operators[0], value[operators[0]], context
                )
        
        return cls._value_to_sql(value)
    

