"""
Unwind Stage Processor Module

处理 MongoDB $unwind 阶段，用于展开数组字段。
"""

from typing import Any, Dict

from ...core.stage_base import RenderContext, StageProcessor


class UnwindStage(StageProcessor):
    """
    Unwind 阶段处理器。
    
    将 MongoDB $unwind 阶段转换为 SQL 的 JSON 数组展开。
    
    示例:
        MongoDB: { $unwind: "$tags" }
        SQL: 使用 JSON_EACH 或递归 CTE 展开数组
        
        MongoDB: { $unwind: { path: "$tags", includeArrayIndex: "idx", preserveNullAndEmptyArrays: true } }
        SQL: 更复杂的展开逻辑
    """
    
    def __init__(self):
        """初始化 Unwind 阶段处理器。"""
        super().__init__('$unwind')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $unwind 阶段。
        
        Args:
            stage_value: Unwind 规范（字符串或对象）
            context: 渲染上下文
        """
        path, include_index, preserve_null = self._parse_unwind_spec(stage_value)
        
        # 提取字段名
        if path.startswith('$'):
            field_name = path[1:]
        else:
            field_name = path
        
        table_alias = context.from_alias or 't'
        
        # 记录 unwind 信息
        unwind_info = {
            'field': field_name,
            'path': path,
            'include_index': include_index,
            'preserve_null': preserve_null,
            'table_alias': table_alias,
        }
        
        context.unwind_info.append(unwind_info)
        
        # 构建展开逻辑
        # 在 SQLite 中，我们可以使用 JSON_EACH 表值函数
        # 或者使用递归 CTE
        
        # 简化处理：使用 CROSS JOIN JSON_EACH
        json_each_table = f"json_each_{field_name}"
        
        # 构建 JSON_EACH 表达式
        json_field = f'{table_alias}.{field_name}'
        
        # 添加 JOIN 来展开数组
        # 这里我们使用 LATERAL JOIN 或 CROSS JOIN
        join_condition = f"1=1"  # JSON_EACH 会自动展开
        
        # 添加特殊的 "JSON_EACH" JOIN
        context.add_join(
            'CROSS JOIN',
            f'JSON_EACH({json_field})',
            json_each_table,
            join_condition
        )
        
        # 如果有索引字段，添加选择
        if include_index:
            context.add_select_column(f'{json_each_table}.key AS {include_index}')
        
        # 添加展开后的值选择
        context.add_select_column(f'{json_each_table}.value AS {field_name}')
    
    def _parse_unwind_spec(self, stage_value: Any) -> tuple:
        """
        解析 unwind 规范。
        
        Args:
            stage_value: Unwind 规范
            
        Returns:
            (path, include_index, preserve_null) 元组
        """
        if isinstance(stage_value, str):
            # 简单字符串格式
            return stage_value, None, False
        
        if isinstance(stage_value, dict):
            # 对象格式
            path = stage_value.get('path', '')
            include_index = stage_value.get('includeArrayIndex')
            preserve_null = stage_value.get('preserveNullAndEmptyArrays', False)
            return path, include_index, preserve_null
        
        raise ValueError("$unwind stage value must be a string or document")
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $unwind 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if isinstance(stage_value, str):
            # 简单字符串格式
            return stage_value.startswith('$')
        
        if isinstance(stage_value, dict):
            # 对象格式
            if 'path' not in stage_value:
                return False
            
            path = stage_value.get('path')
            if not isinstance(path, str) or not path.startswith('$'):
                return False
            
            # 验证可选字段
            if 'includeArrayIndex' in stage_value:
                if not isinstance(stage_value['includeArrayIndex'], str):
                    return False
            
            if 'preserveNullAndEmptyArrays' in stage_value:
                if not isinstance(stage_value['preserveNullAndEmptyArrays'], bool):
                    return False
            
            return True
        
        return False
