"""
Add Fields Stage Module

处理 MongoDB $addFields 阶段，用于添加新字段到文档中。
"""

from .stage import AddFieldsStage

__all__ = ['AddFieldsStage']