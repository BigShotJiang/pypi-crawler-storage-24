"""
Add Fields Stage Processor Module

处理 MongoDB $addFields 阶段，对应 SQL 的计算字段。
"""

from typing import Any, Dict

from ...core.cte_stage_base import CTEStageProcessor
from ...core.stage_base import RenderContext


class AddFieldsStage(CTEStageProcessor):
    """
    Add Fields 阶段处理器。
    
    将 MongoDB $addFields 阶段转换为 SQL 的计算字段，并使用 CTE 创建中间表。
    
    示例:
        MongoDB: { $addFields: { total: { $add: ["$price", "$tax"] } } }
        SQL: WITH cte_1 AS (
                 SELECT *, (price + tax) AS total FROM products AS t
             )
             SELECT * FROM cte_1
             
        MongoDB: { $addFields: { fullName: { $concat: ["$firstName", " ", "$lastName"] } } }
        SQL: WITH cte_1 AS (
                 SELECT *, CONCAT(firstName, ' ', lastName) AS fullName FROM products AS t
             )
             SELECT * FROM cte_1
    """
    
    def __init__(self):
        """初始化 Add Fields 阶段处理器。"""
        super().__init__('$addFields')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $addFields 阶段。
        
        Args:
            stage_value: 添加字段规范字典
            context: 渲染上下文
        """
        if not isinstance(stage_value, dict):
            raise ValueError("$addFields stage value must be a document")
        
        # 总是使用 CTE 方式处理 $addFields
        self.process_with_cte(stage_value, context, self.build_cte_sql)
    
    def should_use_cte(self, stage_value: Any, context: RenderContext) -> bool:
        """
        判断是否应该使用 CTE 来处理此 $addFields 阶段。
        
        Args:
            stage_value: 阶段值
            context: 渲染上下文
            
        Returns:
            是否使用 CTE
        """
        # $addFields 总是需要使用 CTE，因为它会添加新字段
        return True
    
    def build_cte_sql(self, stage_value: Dict[str, Any], context: RenderContext,
                     original_from_table: str, original_from_alias: str) -> str:
        """
        构建 $addFields CTE 的 SQL 内容。
        
        Args:
            stage_value: 添加字段规范字典
            context: 渲染上下文
            original_from_table: 原始表名
            original_from_alias: 原始表别名
            
        Returns:
            CTE SQL 内容
        """
        from ...stages.add_fields.expr import AddFieldsExpressionParser
        
        # 解析添加的字段表达式
        columns = AddFieldsExpressionParser.parse(stage_value, context)
        
        # 构建 CTE 的 SELECT 子句
        select_parts = []
        
        # 添加所有现有字段（使用 *）
        select_parts.append("*")
        
        # 添加新计算的字段
        for column in columns:
            select_parts.append(column)
        
        # 构建 CTE SQL
        cte_select = "SELECT " + ", ".join(select_parts)
        cte_from = f"FROM {original_from_table}"
        if original_from_alias:
            cte_from += f" AS {original_from_alias}"
        
        cte_sql = f"{cte_select}\n{cte_from}"
        
        # 添加 WHERE 条件（如果有）
        if context.where_conditions:
            where_clause = "WHERE " + " AND ".join(["1=1\n"] + context.where_conditions)
            cte_sql += f"\n{where_clause}"
        
        return cte_sql
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $addFields 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if not isinstance(stage_value, dict):
            return False
        
        # 空字典是无效的（必须至少添加一个字段）
        if not stage_value:
            return False
        
        # 检查键是否有效
        for key, value in stage_value.items():
            if not isinstance(key, str):
                return False
            
            # 值可以是表达式或字面值
            if isinstance(value, (int, float, bool, str, list, dict)):
                continue
            else:
                return False
        
        return True