"""
Add Fields Expression Parser Module

解析 MongoDB $addFields 阶段的表达式。
"""

from typing import Any, Dict, List, Optional

from ...core.expr_parser_base import BaseExpressionParser
from ...core.expr_base import (
    BaseExpression,
    BinaryOperation,
    FieldReference,
    FunctionCall,
    LiteralValue,
)
from ...core.expr_registry import ExpressionRegistry
from ...core.stage_base import RenderContext


class AddFieldsExpressionParser(BaseExpressionParser):
    """
    Add Fields 表达式解析器。
    
    将 MongoDB $addFields 表达式解析为 SQL 计算字段。
    专门用于处理 $addFields 阶段，不使用 $project 的包含/排除逻辑。
    """
    
    @classmethod
    def parse(cls, add_fields_spec: Dict[str, Any], context: RenderContext) -> List[str]:
        """
        解析 $addFields 规范并生成 SQL SELECT 列。
        
        Args:
            add_fields_spec: MongoDB $addFields 规范
            context: 渲染上下文
            
        Returns:
            SQL SELECT 列列表
        """
        columns = []
        
        for field_name, field_value in add_fields_spec.items():
            if isinstance(field_value, dict):
                # 表达式：{"field": {"$add": ["$price", "$tax"]}}
                column = cls._parse_expression_projection(field_name, field_value, context)
                if column:
                    columns.append(column)
            elif isinstance(field_value, str) and field_value.startswith('$'):
                # 字段引用：{"new_field": "$old_field"}
                column = cls._parse_field_rename(field_name, field_value, context)
                if column:
                    columns.append(column)
            else:
                # 字面量值：{"field": 1} 或 {"field": "value"}
                column = cls._parse_literal_value(field_name, field_value, context)
                if column:
                    columns.append(column)
        
        return columns
    
    @classmethod
    def _parse_expression_projection(cls, alias: str, expr: Dict[str, Any], context: RenderContext) -> Optional[str]:
        """
        解析表达式投影。
        
        Args:
            alias: 输出字段别名
            expr: 表达式字典
            context: 渲染上下文
            
        Returns:
            SQL 列表达式，或 None
        """
        if not expr:
            return None
        
        # 获取操作符
        operators = list(expr.keys())
        if len(operators) != 1:
            return None
        
        op = operators[0]
        value = expr[op]
        
        # 解析表达式
        sql_expr = cls._parse_expression_value(op, value, context)
        
        if sql_expr:
            return f"{sql_expr} AS {alias}"
        
        return None
    
    @classmethod
    def _parse_field_rename(cls, alias: str, field_ref: str, context: RenderContext) -> Optional[str]:
        """
        解析字段重命名投影。
        
        Args:
            alias: 新字段名
            field_ref: 字段引用（如 "$old_name"）
            context: 渲染上下文
            
        Returns:
            SQL 列表达式，或 None
        """
        if not field_ref.startswith('$'):
            return None
            
        # 提取字段名
        field_name = field_ref[1:]  # 移除开头的 $
        
        # 添加表前缀
        table_alias = context.from_alias or 't'
        return f"{table_alias}.{field_name} AS {alias}"
    
    @classmethod
    def _parse_literal_value(cls, alias: str, value: Any, context: RenderContext) -> Optional[str]:
        """
        解析字面量值投影。
        
        Args:
            alias: 输出字段别名
            value: 字面量值
            context: 渲染上下文
            
        Returns:
            SQL 列表达式，或 None
        """
        sql_literal = cls._value_to_sql(value)
        return f"{sql_literal} AS {alias}"

    @classmethod
    def _parse_expression_value(cls, operator: str, value: Any, context: RenderContext) -> Optional[str]:
        """
        解析表达式值。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 表达式，或 None
        """
        # 字面量
        if operator == '$literal':
            return cls._value_to_sql(value)
        
        # 算术操作符 - 使用专门的处理逻辑
        if operator in cls.ARITHMETIC_OPERATORS:
            return cls._parse_arithmetic_operator(operator, value, context)
        
        # 字符串操作符
        if operator in cls.STRING_OPERATORS:
            return cls._parse_string_operator(operator, value, context)
        
        # 日期操作符
        if operator in cls.DATE_OPERATORS:
            return cls._parse_date_operator(operator, value, context)
        
        # 条件操作符
        if operator in cls.CONDITIONAL_OPERATORS:
            return cls._parse_conditional_operator(operator, value, context)
        
        # 比较操作符 - 使用专门的处理逻辑  
        if operator in cls.COMPARISON_OPERATORS:
            return cls._parse_comparison_operator(operator, value, context)
        
        # 数组操作符
        if operator in cls.ARRAY_OPERATORS:
            return cls._parse_array_operator(operator, value, context)
        
        return None
    
    @classmethod
    def _parse_arithmetic_operator(cls, operator: str, value: Any, context: RenderContext) -> Optional[str]:
        """解析算术操作符，返回布尔表达式"""
        op_map = {
            '$add': '+',
            '$subtract': '-',
            '$multiply': '*',
            '$divide': '/',
            '$mod': '%',
        }
        
        sql_op = op_map.get(operator)
        if sql_op is None:
            return None
        
        if not isinstance(value, list) or len(value) < 2:
            return None
        
        operands = []
        for item in value:
            if isinstance(item, str) and item.startswith('$'):
                field = item[1:]
                table_alias = context.from_alias or 't'
                operands.append(f'{table_alias}.{field}')
            else:
                operands.append(cls._value_to_sql(item))
        
        return f"({f' {sql_op} '.join(operands)})"
        
    @classmethod
    def _parse_string_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析字符串操作符。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 字符串表达式
        """
        if operator == '$concat':
            if not isinstance(value, list):
                raise ValueError("$concat requires an array of strings")
            
            parts = []
            for item in value:
                if isinstance(item, str) and item.startswith('$'):
                    field = item[1:]
                    table_alias = context.from_alias or 't'
                    parts.append(f'{table_alias}.{field}')
                else:
                    parts.append(cls._value_to_sql(item))
            
            return f"CONCAT({', '.join(parts)})"
        
        if operator == '$toLower':
            expr = cls._parse_operand(value, context)
            return f"LOWER({expr})"
        
        if operator == '$toUpper':
            expr = cls._parse_operand(value, context)
            return f"UPPER({expr})"
        
        if operator == '$substr':
            if not isinstance(value, list) or len(value) < 2:
                raise ValueError("$substr requires [string, start, length]")
            
            str_expr = cls._parse_operand(value[0], context)
            start = cls._parse_operand(value[1], context)
            length = cls._parse_operand(value[2], context) if len(value) > 2 else 'LENGTH(' + str_expr + ')'
            
            return f"SUBSTR({str_expr}, {start}, {length})"
        
        return ""
    
    @classmethod
    def _parse_date_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析日期操作符。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 日期表达式
        """
        if operator == '$dateToString':
            if isinstance(value, dict):
                date = value.get('date', '')
                format_str = value.get('format', '%Y-%m-%d')
                
                date_expr = cls._parse_operand(date, context)
                # SQLite 使用 STRFTIME
                return f"STRFTIME('{format_str}', {date_expr})"
        
        # 其他日期操作符
        date_part_map = {
            '$year': '%Y',
            '$month': '%m',
            '$dayOfMonth': '%d',
            '$hour': '%H',
            '$minute': '%M',
            '$second': '%S',
        }
        
        if operator in date_part_map:
            expr = cls._parse_operand(value, context)
            format_str = date_part_map[operator]
            return f"CAST(STRFTIME('{format_str}', {expr}) AS INTEGER)"
        
        return ""
    
    @classmethod
    def _parse_conditional_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析条件操作符。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 条件表达式
        """
        if operator == '$cond':
            if isinstance(value, dict):
                # { if: <boolean>, then: <true>, else: <false> }
                if_expr = cls._parse_operand(value.get('if'), context)
                then_expr = cls._parse_operand(value.get('then'), context)
                else_expr = cls._parse_operand(value.get('else'), context)
                
                return f"CASE WHEN {if_expr} THEN {then_expr} ELSE {else_expr} END"
            
            elif isinstance(value, list) and len(value) == 3:
                # [ <if>, <then>, <else> ]
                if_expr = cls._parse_operand(value[0], context)
                then_expr = cls._parse_operand(value[1], context)
                else_expr = cls._parse_operand(value[2], context)
                
                return f"CASE WHEN {if_expr} THEN {then_expr} ELSE {else_expr} END"
        
        if operator == '$ifNull':
            if isinstance(value, list) and len(value) >= 1:
                expr = cls._parse_operand(value[0], context)
                replacement = cls._parse_operand(value[1], context) if len(value) > 1 else 'NULL'
                
                return f"COALESCE({expr}, {replacement})"
        
        return ""
    
    @classmethod 
    def _parse_comparison_operator(cls, operator: str, value: Any, context: RenderContext) -> Optional[str]:
        """解析比较操作符，返回布尔表达式"""
        if not isinstance(value, list) or len(value) != 2:
            return None
            
        op_map = {
            '$eq': '=',
            '$ne': '!=',
            '$gt': '>',
            '$gte': '>=',
            '$lt': '<',
            '$lte': '<=',
        }
        
        sql_op = op_map.get(operator)
        if sql_op is None:
            return None
        
        def parse_operand(operand):
            if isinstance(operand, str) and operand.startswith('$'):
                field = operand[1:]
                table_alias = context.from_alias or 't'
                return f'{table_alias}.{field}'
            else:
                return cls._value_to_sql(operand)
        
        left = parse_operand(value[0])
        right = parse_operand(value[1])
        
        return f"({left} {sql_op} {right})"
    
    @classmethod
    def _parse_array_operator(cls, operator: str, value: Any, context: RenderContext) -> str:
        """
        解析数组操作符。
        
        Args:
            operator: 操作符
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 数组表达式
        """
        if operator == '$size':
            expr = cls._parse_operand(value, context)
            return f"JSON_ARRAY_LENGTH({expr})"
        
        if operator == '$arrayElemAt':
            if isinstance(value, list) and len(value) == 2:
                array_expr = cls._parse_operand(value[0], context)
                index_expr = cls._parse_operand(value[1], context)
                # SQLite JSON 数组索引从 0 开始
                return f"JSON_EXTRACT({array_expr}, '$[' || {index_expr} || ']')"
        
        return ""

    @classmethod
    def _parse_operand(cls, value: Any, context: RenderContext) -> str:
        """
        解析操作数。
        
        Args:
            value: 操作数值
            context: 渲染上下文
            
        Returns:
            SQL 表达式
        """
        if value is None:
            return 'NULL'
        
        if isinstance(value, str):
            if value.startswith('$'):
                # 字段引用
                field = value[1:]
                table_alias = context.from_alias or 't'
                return f'{table_alias}.{field}'
            return cls._value_to_sql(value)
        
        if isinstance(value, (int, float, bool)):
            return cls._value_to_sql(value)
        
        if isinstance(value, dict):
            # 嵌套表达式
            operators = list(value.keys())
            if len(operators) == 1:
                return cls._parse_expression_value(operators[0], value[operators[0]], context) or ''
        
        return cls._value_to_sql(value)
