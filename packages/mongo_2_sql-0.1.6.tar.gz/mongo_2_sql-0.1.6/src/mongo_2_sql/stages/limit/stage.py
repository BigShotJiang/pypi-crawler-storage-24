"""
Limit Stage Processor Module

处理 MongoDB $limit 和 $skip 阶段，对应 SQL 的 LIMIT 和 OFFSET 子句。
"""

from typing import Any

from ...core.stage_base import RenderContext, StageProcessor


class LimitStage(StageProcessor):
    """
    Limit 阶段处理器。
    
    将 MongoDB $limit 阶段转换为 SQL LIMIT 子句。
    
    示例:
        MongoDB: { $limit: 10 }
        SQL: LIMIT 10
    """
    
    def __init__(self):
        """初始化 Limit 阶段处理器。"""
        super().__init__('$limit')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $limit 阶段。
        
        Args:
            stage_value: 限制数量
            context: 渲染上下文
        """
        if not isinstance(stage_value, (int, float)):
            raise ValueError("$limit stage value must be a number")
        
        limit = int(stage_value)
        
        if limit < 0:
            raise ValueError("$limit value must be non-negative")
        
        context.set_limit(limit)
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $limit 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if not isinstance(stage_value, (int, float)):
            return False
        
        return int(stage_value) >= 0


class SkipStage(StageProcessor):
    """
    Skip 阶段处理器。
    
    将 MongoDB $skip 阶段转换为 SQL OFFSET 子句。
    
    示例:
        MongoDB: { $skip: 20 }
        SQL: OFFSET 20
    """
    
    def __init__(self):
        """初始化 Skip 阶段处理器。"""
        super().__init__('$skip')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $skip 阶段。
        
        Args:
            stage_value: 跳过数量
            context: 渲染上下文
        """
        if not isinstance(stage_value, (int, float)):
            raise ValueError("$skip stage value must be a number")
        
        skip = int(stage_value)
        
        if skip < 0:
            raise ValueError("$skip value must be non-negative")
        
        context.set_offset(skip)
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $skip 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if not isinstance(stage_value, (int, float)):
            return False
        
        return int(stage_value) >= 0
