"""
Limit Stage Module

处理 MongoDB $limit 和 $skip 阶段，对应 SQL 的 LIMIT 和 OFFSET 子句。
"""

from .stage import LimitStage, SkipStage

__all__ = ['LimitStage', 'SkipStage']
