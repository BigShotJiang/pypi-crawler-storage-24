"""
Sort Stage Processor Module

处理 MongoDB $sort 阶段，对应 SQL 的 ORDER BY 子句。
"""

from typing import Any, Dict

from ...core.stage_base import RenderContext, StageProcessor


class SortStage(StageProcessor):
    """
    Sort 阶段处理器。
    
    将 MongoDB $sort 阶段转换为 SQL ORDER BY 子句。
    
    示例:
        MongoDB: { $sort: { age: -1, name: 1 } }
        SQL: ORDER BY t.age" DESC, t.name ASC
        
        MongoDB: { $sort: { createdAt: { $meta: "textScore" } } }
        SQL: ORDER BY t.createdAt DESC  (简化处理)
    """
    
    def __init__(self):
        """初始化 Sort 阶段处理器。"""
        super().__init__('$sort')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $sort 阶段。
        
        Args:
            stage_value: 排序规范字典
            context: 渲染上下文
        """
        if not isinstance(stage_value, dict):
            raise ValueError("$sort stage value must be a document")
        
        table_alias = context.from_alias or 't'
        
        for field, sort_spec in stage_value.items():
            direction = self._parse_sort_direction(sort_spec)
            
            # 引用字段名
            quoted_field = f'{table_alias}.{field}'
            
            # 添加到 ORDER BY
            context.add_order_by_column(quoted_field, direction)
    
    def _parse_sort_direction(self, sort_spec: Any) -> str:
        """
        解析排序方向。
        
        Args:
            sort_spec: 排序规范（可以是数字、布尔值或对象）
            
        Returns:
            排序方向字符串（'ASC' 或 'DESC'）
        """
        if isinstance(sort_spec, (int, float)):
            # 1 表示升序，-1 表示降序
            return 'ASC' if sort_spec >= 0 else 'DESC'
        
        if isinstance(sort_spec, bool):
            return 'ASC' if sort_spec else 'DESC'
        
        if isinstance(sort_spec, dict):
            # 处理 $meta 等特殊排序
            if '$meta' in sort_spec:
                # 元数据排序，默认降序
                return 'DESC'
        
        # 默认升序
        return 'ASC'
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $sort 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if not isinstance(stage_value, dict):
            return False
        
        if not stage_value:
            return False
        
        # 验证每个排序字段
        for field, sort_spec in stage_value.items():
            if not isinstance(field, str):
                return False
            
            # 排序规范可以是：
            # - 1 / -1（升序/降序）
            # - true / false
            # - { $meta: "textScore" }
            if isinstance(sort_spec, (int, float, bool)):
                continue
            elif isinstance(sort_spec, dict):
                if '$meta' in sort_spec:
                    continue
                return False
            else:
                return False
        
        return True
