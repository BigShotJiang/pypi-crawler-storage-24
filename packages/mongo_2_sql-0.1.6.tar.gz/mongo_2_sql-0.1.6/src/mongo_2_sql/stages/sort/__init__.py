"""
Sort Stage Module

处理 MongoDB $sort 阶段，对应 SQL 的 ORDER BY 子句。
"""

from .stage import SortStage

__all__ = ['SortStage']
