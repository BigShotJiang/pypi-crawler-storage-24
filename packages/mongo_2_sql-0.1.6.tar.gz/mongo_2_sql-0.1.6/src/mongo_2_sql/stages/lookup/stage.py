"""
Lookup Stage Processor Module

处理 MongoDB $lookup 阶段，对应 SQL 的 JOIN 操作。
"""

from typing import Any, Dict, List

from ...core.stage_base import RenderContext, StageProcessor


class LookupStage(StageProcessor):
    """
    Lookup 阶段处理器。
    
    将 MongoDB $lookup 阶段转换为 SQL JOIN 子句。
    
    示例:
        MongoDB: { 
            $lookup: { 
                from: "orders", 
                localField: "_id", 
                foreignField: "customerId", 
                as: "orders" 
            } 
        }
        SQL: LEFT JOIN orders AS orders ON t._id = orders.customerId
        
        MongoDB: {
            $lookup: {
                from: "comments",
                let: { post_id: "$_id" },
                pipeline: [
                    { $match: { $expr: { $eq: ["$postId", "$$post_id"] } } }
                ],
                as: "comments"
            }
        }
        SQL: 使用子查询或 CTE 实现
    """
    
    def __init__(self):
        """初始化 Lookup 阶段处理器。"""
        super().__init__('$lookup')
    
    def process(self, stage_value: Any, context: RenderContext) -> None:
        """
        处理 $lookup 阶段。
        
        Args:
            stage_value: Lookup 规范字典
            context: 渲染上下文
        """
        if not isinstance(stage_value, dict):
            raise ValueError("$lookup stage value must be a document")
        
        # 检查是否是管道式 $lookup
        if 'pipeline' in stage_value:
            self._process_pipeline_lookup(stage_value, context)
        else:
            self._process_simple_lookup(stage_value, context)
    
    def _process_simple_lookup(self, lookup_spec: Dict[str, Any], context: RenderContext) -> None:
        """
        处理简单的等值连接 $lookup。
        
        Args:
            lookup_spec: Lookup 规范
            context: 渲染上下文
        """
        from_table = lookup_spec.get('from')
        local_field = lookup_spec.get('localField')
        foreign_field = lookup_spec.get('foreignField')
        as_field = lookup_spec.get('as')
        
        if not from_table:
            raise ValueError("$lookup requires 'from' field")
        if not local_field:
            raise ValueError("$lookup requires 'localField' field")
        if not foreign_field:
            raise ValueError("$lookup requires 'foreignField' field")
        if not as_field:
            raise ValueError("$lookup requires 'as' field")
        
        # 生成 JOIN 别名
        join_alias = as_field
        
        # 构建 JOIN 条件
        table_alias = context.from_alias or 't'
        join_condition = f'{table_alias}.{local_field} = {join_alias}.{foreign_field}'
        
        # 添加 LEFT JOIN
        context.add_join('LEFT', from_table, join_alias, join_condition)
    
    def _process_pipeline_lookup(self, lookup_spec: Dict[str, Any], context: RenderContext) -> None:
        """
        处理管道式 $lookup（使用子查询）。
        
        Args:
            lookup_spec: Lookup 规范
            context: 渲染上下文
        """
        from_table = lookup_spec.get('from')
        let_vars = lookup_spec.get('let', {})
        pipeline = lookup_spec.get('pipeline', [])
        as_field = lookup_spec.get('as')
        
        if not from_table:
            raise ValueError("$lookup requires 'from' field")
        if not as_field:
            raise ValueError("$lookup requires 'as' field")
        
        # 生成 CTE 名称
        cte_name = context.generate_cte_name()
        
        # 构建子查询
        from ...core.pipeline_runtime import PipelineRuntime
        
        # 创建子查询运行时
        sub_runtime = PipelineRuntime(from_table)
        
        # 如果有 let 变量，需要处理它们
        if let_vars:
            # 将 let 变量添加到子查询上下文中
            for var_name, var_expr in let_vars.items():
                # 这里简化处理，实际应该解析表达式
                pass
        
        # 执行管道
        sub_context = sub_runtime.execute(pipeline)
        
        # 获取子查询 SQL
        sub_sql = sub_context.to_sql()
        
        # 添加 CTE
        context.add_cte(cte_name, sub_sql)
        
        # 添加 JOIN
        table_alias = context.from_alias or 't'
        join_alias = as_field
        
        # 构建 JOIN 条件（简化处理，实际应该基于 let 变量）
        # 这里假设有一个共同的连接字段
        join_condition = f'1=1\n'  # 简化处理
        
        context.add_join('LEFT', cte_name, join_alias, join_condition)
    
    def validate(self, stage_value: Any) -> bool:
        """
        验证 $lookup 阶段值。
        
        Args:
            stage_value: 阶段值
            
        Returns:
            是否有效
        """
        if not isinstance(stage_value, dict):
            return False
        
        # 检查必需字段
        if 'from' not in stage_value:
            return False
        if 'as' not in stage_value:
            return False
        
        # 检查是简单 lookup 还是管道 lookup
        has_pipeline = 'pipeline' in stage_value
        
        if has_pipeline:
            # 管道式 lookup 需要 let（可选）
            if 'let' in stage_value and not isinstance(stage_value['let'], dict):
                return False
            if not isinstance(stage_value['pipeline'], list):
                return False
        else:
            # 简单 lookup 需要 localField 和 foreignField
            if 'localField' not in stage_value:
                return False
            if 'foreignField' not in stage_value:
                return False
        
        return True
