"""
Converter Module

MongoDB 聚合管道到 SQL 查询的主要转换入口。
"""

from typing import Any, Dict, List, Optional, Tuple

from .core.pipeline_runtime import PipelineRuntime
from .core.stage_base import RenderContext
from .core.stage_loader import StageLoader
from .renderer.sqlite import SQLiteRenderer


def convert_mongo_pipeline_to_sql(
    pipeline: List[Dict[str, Any]],
    collection_name: str,
    dialect: str = 'sqlite',
    validate: bool = True
) -> Tuple[str, Dict[str, Any]]:
    """
    将 MongoDB 聚合管道转换为 SQL 查询。
    
    Args:
        pipeline: MongoDB 聚合管道（阶段列表）
        collection_name: MongoDB 集合名称（对应 SQL 表名）
        dialect: SQL 方言（默认 'sqlite'）
        validate: 是否验证管道格式
        
    Returns:
        (sql_query, metadata) 元组
        
    Raises:
        ValueError: 如果管道格式无效
        RuntimeError: 如果转换过程中发生错误
        
    示例:
        >>> pipeline = [
        ...     { "$match": { "status": "active" } },
        ...     { "$group": { "_id": "$category", "count": { "$sum": 1 } } },
        ...     { "$sort": { "count": -1 } },
        ...     { "$limit": 10 }
        ... ]
        >>> sql, metadata = convert_mongo_pipeline_to_sql(pipeline, "products")
        >>> print(sql)
        SELECT 
            t.category AS _id, 
            COUNT(*) AS count
        FROM products AS t
        WHERE 1=1
         AND (t.status = 'active')
        GROUP BY t.category
        ORDER BY count DESC
        LIMIT 10
    """
    # 验证管道
    if validate:
        _validate_pipeline(pipeline)
    
    # 创建管道运行时
    runtime = PipelineRuntime(collection_name)
    
    # 执行管道
    context = runtime.execute(pipeline)
    
    # 检查错误
    if runtime.has_errors():
        errors = runtime.get_errors()
        raise RuntimeError(f"Pipeline conversion failed: {'; '.join(errors)}")
    
    # 生成 SQL
    if dialect == 'sqlite':
        renderer = SQLiteRenderer()
        sql = renderer.render(context)
    else:
        # 默认使用上下文的 to_sql 方法
        sql = context.to_sql()
    
    # 构建元数据
    metadata = {
        'dialect': dialect,
        'collection': collection_name,
        'stages_processed': len(pipeline),
        'has_aggregation': context.has_aggregation,
        'warnings': runtime.get_warnings(),
        'select_columns': context.select_columns,
        'where_conditions': context.where_conditions,
        'group_by_columns': context.group_by_columns,
        'order_by_columns': context.order_by_columns,
        'limit': context.limit_value,
        'offset': context.offset_value,
    }
    
    return sql, metadata


def _validate_pipeline(pipeline: List[Dict[str, Any]]) -> None:
    """
    验证聚合管道格式。
    
    Args:
        pipeline: 聚合管道
        
    Raises:
        ValueError: 如果管道格式无效
    """
    if not isinstance(pipeline, list):
        raise ValueError("Pipeline must be a list")
    
    for index, stage in enumerate(pipeline):
        if not isinstance(stage, dict):
            raise ValueError(f"Stage {index}: Expected dict, got {type(stage).__name__}")
        
        if len(stage) != 1:
            raise ValueError(f"Stage {index}: Expected exactly one stage operator, got {len(stage)}")
        
        stage_name = list(stage.keys())[0]
        
        if not stage_name.startswith('$'):
            raise ValueError(f"Stage {index}: Stage name must start with '$', got '{stage_name}'")


class MongoToSQLConverter:
    """
    MongoDB 到 SQL 转换器类。
    
    提供面向对象的转换接口，支持更多配置选项。
    """
    
    def __init__(
        self,
        dialect: str = 'sqlite',
        stage_loader: Optional[StageLoader] = None
    ):
        """
        初始化转换器。
        
        Args:
            dialect: SQL 方言
            stage_loader: 自定义阶段加载器
        """
        self.dialect = dialect
        self.stage_loader = stage_loader or StageLoader()
        self.renderer = SQLiteRenderer() if dialect == 'sqlite' else None
    
    def convert(
        self,
        pipeline: List[Dict[str, Any]],
        collection_name: str,
        validate: bool = True
    ) -> Tuple[str, Dict[str, Any]]:
        """
        转换聚合管道为 SQL。
        
        Args:
            pipeline: MongoDB 聚合管道
            collection_name: 集合名称
            validate: 是否验证管道
            
        Returns:
            (sql_query, metadata) 元组
        """
        return convert_mongo_pipeline_to_sql(
            pipeline=pipeline,
            collection_name=collection_name,
            dialect=self.dialect,
            validate=validate
        )
    
    def convert_single_stage(
        self,
        stage: Dict[str, Any],
        collection_name: str
    ) -> str:
        """
        转换单个阶段为 SQL 片段。
        
        Args:
            stage: MongoDB 阶段
            collection_name: 集合名称
            
        Returns:
            SQL 片段
        """
        runtime = PipelineRuntime(collection_name, self.stage_loader)
        context = runtime.execute([stage])
        
        if self.renderer:
            return self.renderer.render(context)
        
        return context.to_sql()
    
    def get_supported_stages(self) -> List[str]:
        """
        获取支持的阶段列表。
        
        Returns:
            支持的阶段名称列表
        """
        return self.stage_loader.list_available_stages()
    
    def is_stage_supported(self, stage_name: str) -> bool:
        """
        检查阶段是否受支持。
        
        Args:
            stage_name: 阶段名称
            
        Returns:
            是否受支持
        """
        return self.stage_loader.is_stage_supported(stage_name)


# 便捷函数

def mongo_match_to_sql(match_spec: Dict[str, Any], table_name: str = 't') -> str:
    """
    将 MongoDB $match 规范转换为 SQL WHERE 子句。
    
    Args:
        match_spec: $match 规范
        table_name: 表别名
        
    Returns:
        SQL WHERE 子句（不包含 WHERE 关键字）
    """
    from ..stages.match.expr import MatchExpressionParser
    from ...core.stage_base import RenderContext
    
    context = RenderContext(from_alias=table_name)
    condition = MatchExpressionParser.parse(match_spec, context)
    
    return condition


def mongo_project_to_sql(project_spec: Dict[str, Any], table_name: str = 't') -> List[str]:
    """
    将 MongoDB $project 规范转换为 SQL SELECT 列。
    
    Args:
        project_spec: $project 规范
        table_name: 表别名
        
    Returns:
        SQL SELECT 列列表
    """
    from ..stages.project.expr import ProjectExpressionParser
    from ...core.stage_base import RenderContext
    
    context = RenderContext(from_alias=table_name)
    columns = ProjectExpressionParser.parse(project_spec, context)
    
    return columns


def mongo_group_to_sql(
    group_spec: Dict[str, Any],
    table_name: str = 't'
) -> Tuple[List[str], List[str]]:
    """
    将 MongoDB $group 规范转换为 SQL GROUP BY 和 SELECT。
    
    Args:
        group_spec: $group 规范
        table_name: 表别名
        
    Returns:
        (group_by_columns, select_columns) 元组
    """
    from ..stages.group.expr import GroupExpressionParser
    from ...core.stage_base import RenderContext
    
    context = RenderContext(from_alias=table_name)
    group_by, select, _ = GroupExpressionParser.parse(group_spec, context)
    
    return group_by, select
