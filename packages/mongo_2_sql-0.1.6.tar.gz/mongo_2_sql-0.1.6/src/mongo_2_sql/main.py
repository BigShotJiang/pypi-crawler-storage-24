#!/usr/bin/env python3
"""
Mongo to SQL - Command Line Interface

命令行工具，用于将 MongoDB 聚合管道转换为 SQL 查询。
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

# 添加父目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from .converter import convert_mongo_pipeline_to_sql, MongoToSQLConverter


def parse_arguments() -> argparse.Namespace:
    """
    解析命令行参数。
    
    Returns:
        解析后的参数
    """
    parser = argparse.ArgumentParser(
        description='Convert MongoDB aggregation pipeline to SQL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  # Convert from file
  python -m mongo_2_sql.main -f pipeline.json -c users

  # Convert from stdin
  echo '[{"$match": {"status": "active"}}]' | python -m mongo_2_sql.main -c users

  # Convert with specific dialect
  python -m mongo_2_sql.main -f pipeline.json -c users -d sqlite

  # List supported stages
  python -m mongo_2_sql.main --list-stages
        '''
    )
    
    parser.add_argument(
        '-f', '--file',
        type=str,
        help='Path to JSON file containing the aggregation pipeline'
    )
    
    parser.add_argument(
        '-c', '--collection',
        type=str,
        help='MongoDB collection name (SQL table name)'
    )
    
    parser.add_argument(
        '-d', '--dialect',
        type=str,
        default='sqlite',
        choices=['sqlite', 'postgresql', 'mysql'],
        help='SQL dialect (default: sqlite)'
    )
    
    parser.add_argument(
        '-p', '--pipeline',
        type=str,
        help='Pipeline as JSON string'
    )
    
    parser.add_argument(
        '--no-validate',
        action='store_true',
        help='Skip pipeline validation'
    )
    
    parser.add_argument(
        '--metadata',
        action='store_true',
        help='Output metadata along with SQL'
    )
    
    parser.add_argument(
        '--list-stages',
        action='store_true',
        help='List all supported aggregation stages'
    )
    
    parser.add_argument(
        '--format',
        action='store_true',
        help='Format the output SQL'
    )
    
    parser.add_argument(
        '-o', '--output',
        type=str,
        help='Output file path (default: stdout)'
    )
    
    return parser.parse_args()


def load_pipeline(args: argparse.Namespace) -> List[Dict[str, Any]]:
    """
    加载聚合管道。
    
    Args:
        args: 命令行参数
        
    Returns:
        聚合管道
        
    Raises:
        ValueError: 如果无法加载管道
    """
    # 从文件加载
    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                content = f.read()
                return json.loads(content)
        except FileNotFoundError:
            raise ValueError(f"File not found: {args.file}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in file: {e}")
    
    # 从命令行参数加载
    if args.pipeline:
        try:
            return json.loads(args.pipeline)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in pipeline argument: {e}")
    
    # 从标准输入加载
    if not sys.stdin.isatty():
        try:
            content = sys.stdin.read()
            if content.strip():
                return json.loads(content)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON from stdin: {e}")
    
    raise ValueError("No pipeline provided. Use -f, -p, or pipe from stdin.")


def format_sql(sql: str) -> str:
    """
    格式化 SQL 查询。
    
    Args:
        sql: SQL 查询字符串
        
    Returns:
        格式化后的 SQL
    """
    # 简单的格式化
    lines = sql.split('\n')
    formatted_lines = []
    
    for line in lines:
        stripped = line.strip()
        if stripped:
            formatted_lines.append(stripped)
    
    return '\n'.join(formatted_lines)


def print_result(
    sql: str,
    metadata: Dict[str, Any],
    args: argparse.Namespace
) -> None:
    """
    打印转换结果。
    
    Args:
        sql: SQL 查询
        metadata: 元数据
        args: 命令行参数
    """
    output_lines = []
    
    # SQL 查询
    if args.format:
        sql = format_sql(sql)
    
    output_lines.append(sql)
    
    # 元数据
    if args.metadata:
        output_lines.append('')
        output_lines.append('-- Metadata:')
        output_lines.append(f'-- Dialect: {metadata["dialect"]}')
        output_lines.append(f'-- Collection: {metadata["collection"]}')
        output_lines.append(f'-- Stages processed: {metadata["stages_processed"]}')
        output_lines.append(f'-- Has aggregation: {metadata["has_aggregation"]}')
        
        if metadata.get('warnings'):
            output_lines.append('-- Warnings:')
            for warning in metadata['warnings']:
                output_lines.append(f'--   - {warning}')
    
    output = '\n'.join(output_lines)
    
    # 输出到文件或标准输出
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"Output written to: {args.output}")
    else:
        print(output)


def list_supported_stages() -> None:
    """
    列出所有支持的阶段。
    """
    converter = MongoToSQLConverter()
    stages = converter.get_supported_stages()
    
    print("Supported MongoDB Aggregation Stages:")
    print()
    
    stage_descriptions = {
        '$match': 'Filter documents (WHERE clause)',
        '$project': 'Reshape documents (SELECT clause)',
        '$group': 'Group documents (GROUP BY clause)',
        '$sort': 'Sort documents (ORDER BY clause)',
        '$limit': 'Limit results (LIMIT clause)',
        '$skip': 'Skip results (OFFSET clause)',
        '$lookup': 'Join with other collection (JOIN clause)',
        '$unwind': 'Deconstruct arrays (UNNEST)',
    }
    
    for stage in sorted(stages):
        desc = stage_descriptions.get(stage, '')
        print(f"  {stage:<15} {desc}")


def main() -> int:
    """
    主入口函数。
    
    Returns:
        退出码
    """
    args = parse_arguments()
    
    # 列出支持的阶段
    if args.list_stages:
        list_supported_stages()
        return 0
    
    # 检查必需参数
    if not args.collection:
        print("Error: Collection name is required (-c COLLECTION)", file=sys.stderr)
        return 1
    
    try:
        # 加载管道
        pipeline = load_pipeline(args)
        print(pipeline)
        # 转换
        sql, metadata = convert_mongo_pipeline_to_sql(
            pipeline=pipeline,
            collection_name=args.collection,
            dialect=args.dialect,
            validate=not args.no_validate
        )
        
        # 输出结果
        print_result(sql, metadata, args)
        
        return 0
        
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except RuntimeError as e:
        print(f"Conversion Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Unexpected Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
