import re
from typing import List, Dict, Any, Set

class MongoPipelineToDuckDBWithCTE:
    SQL_KEYWORDS = {
        "SELECT", "FROM", "WHERE", "GROUP", "ORDER", "LIMIT", "OFFSET", "AS", "AND", "OR",
        "NOT", "NULL", "TRUE", "FALSE", "COUNT", "SUM", "AVG", "MIN", "MAX", "CASE", "WHEN",
        "THEN", "ELSE", "END", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER", "ON", "BY"
    }

    def __init__(self, collection_name: str):
        self.collection = collection_name
        self.errors = []

    def _escape_string(self, s: str) -> str:
        return s.replace("'", "''")

    def _literal(self, val) -> str:
        if isinstance(val, str):
            return f"'{self._escape_string(val)}'"
        elif isinstance(val, bool):
            return str(val).upper()
        elif val is None:
            return "NULL"
        else:
            return str(val)

    def _field_ref(self, field: str) -> str:
        """仅移除 $ 前缀"""
        if isinstance(field, str) and field.startswith("$"):
            return field[1:]
        return str(field)

    def _quote_identifier(self, name: str) -> str:
        if not name:
            return '""'
        # 检查是否为合法标识符且非关键字
        if re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", name) and name.upper() not in self.SQL_KEYWORDS:
            return name
        return f'"{name}"'

    def _resolve_field(self, field_ref: str, available_fields: Set[str]) -> str:
        if not isinstance(field_ref, str) or not field_ref.startswith("$"):
            return str(field_ref)
        path = field_ref[1:]
        if path.startswith("_id.") and len(path) > 4:
            subfield = path[4:]
            virtual_col = f"_id_{subfield}"
            if virtual_col in available_fields:
                return virtual_col
            if subfield in available_fields:
                return subfield
            return subfield  # fallback
        if available_fields == {"*"}:
            return path
        if path in available_fields:
            return path
        self.errors.append(f"Field '{field_ref}' not found. Available: {sorted(available_fields)}")
        return "'<MISSING>'"

    def _parse_match_condition(self, field: str, condition) -> str:
        if not isinstance(condition, dict):
            return f"{self._field_ref(field)} = {self._literal(condition)}"
        parts = []
        for op, val in condition.items():
            ref = self._field_ref(field)
            if op == "$eq":
                parts.append(f"{ref} = {self._literal(val)}")
            elif op == "$ne":
                parts.append(f"{ref} != {self._literal(val)}")
            elif op == "$gt":
                parts.append(f"{ref} > {self._literal(val)}")
            elif op == "$gte":
                parts.append(f"{ref} >= {self._literal(val)}")
            elif op == "$lt":
                parts.append(f"{ref} < {self._literal(val)}")
            elif op == "$lte":
                parts.append(f"{ref} <= {self._literal(val)}")
            elif op == "$in":
                vals = ", ".join([self._literal(v) for v in val])
                parts.append(f"{ref} IN ({vals})")
            elif op == "$nin":
                vals = ", ".join([self._literal(v) for v in val])
                parts.append(f"{ref} NOT IN ({vals})")
            else:
                self.errors.append(f"Unsupported match operator: {op}")
                parts.append("TRUE")
        return " AND ".join(parts) if len(parts) > 1 else parts[0]

    def _convert_expression_in_select(self, expr, available_fields: Set[str]) -> str:
        if isinstance(expr, dict):
            for op, args in expr.items():
                if op == "$cond":
                    if isinstance(args, list):
                        cond, then_e, else_e = args
                    else:
                        cond, then_e, else_e = args["if"], args["then"], args["else"]
                    cond_sql = self._convert_expression_in_select(cond, available_fields)
                    then_sql = self._convert_expression_in_select(then_e, available_fields)
                    else_sql = self._convert_expression_in_select(else_e, available_fields)
                    return f"(CASE WHEN {cond_sql} THEN {then_sql} ELSE {else_sql} END)"

                # ===== 新增：支持比较操作符 =====
                elif op == "$eq":
                    left = self._convert_expression_in_select(args[0], available_fields)
                    right = self._convert_expression_in_select(args[1], available_fields)
                    return f"({left} = {right})"
                elif op == "$ne":
                    left = self._convert_expression_in_select(args[0], available_fields)
                    right = self._convert_expression_in_select(args[1], available_fields)
                    return f"({left} != {right})"
                elif op == "$gt":
                    left = self._convert_expression_in_select(args[0], available_fields)
                    right = self._convert_expression_in_select(args[1], available_fields)
                    return f"({left} > {right})"
                elif op == "$gte":
                    left = self._convert_expression_in_select(args[0], available_fields)
                    right = self._convert_expression_in_select(args[1], available_fields)
                    return f"({left} >= {right})"
                elif op == "$lt":
                    left = self._convert_expression_in_select(args[0], available_fields)
                    right = self._convert_expression_in_select(args[1], available_fields)
                    return f"({left} < {right})"
                elif op == "$lte":
                    left = self._convert_expression_in_select(args[0], available_fields)
                    right = self._convert_expression_in_select(args[1], available_fields)
                    return f"({left} <= {right})"

                # ===== 其他操作符（可选）=====
                elif op == "$concat":
                    parts = [self._convert_expression_in_select(p, available_fields) for p in args]
                    return " || ".join(parts)
                elif op == "$toString":
                    inner = self._convert_expression_in_select(args, available_fields)
                    return f"CAST({inner} AS VARCHAR)"
                elif op == "$add":
                    left = self._convert_expression_in_select(args[0], available_fields)
                    right = self._convert_expression_in_select(args[1], available_fields)
                    return f"({left} + {right})"
                elif op.startswith("$"):
                    self.errors.append(f"Unsupported expression operator: {op}")
                    return "'<UNSUPPORTED>'"
        if isinstance(expr, str) and expr.startswith("$"):
            return self._resolve_field(expr, available_fields)
        return self._literal(expr)

    def convert(self, pipeline: List[Dict[str, Any]]) -> str:
        self.errors = []
        ctes = []
        current_table = self.collection
        current_fields = {"*"}  # 初始 schema 未知

        # 累积非物化操作
        where_clauses = []
        order_by = []
        limit_val = None
        offset_val = 0
        joins = []
        unnest_list = []

        for stage in pipeline:
            if not stage:
                continue
            stage_type = next(iter(stage))
            value = stage[stage_type]

            # 非物化阶段：累积
            if stage_type == "$match":
                for field, cond in value.items():
                    where_clauses.append(self._parse_match_condition(field, cond))
                continue
            elif stage_type == "$sort":
                for field, direction in value.items():
                    dir_str = "DESC" if direction == -1 else "ASC"
                    resolved = self._resolve_field(field, current_fields)
                    order_by.append(f"{resolved} {dir_str}")
                continue
            elif stage_type == "$limit":
                limit_val = value
                continue
            elif stage_type == "$skip":
                offset_val = value
                continue
            elif stage_type == "$unwind":
                field = value if isinstance(value, str) else value["path"]
                alias = (value.get("as", field.lstrip("$").split(".")[-1])
                         if isinstance(value, dict) else field.lstrip("$").split(".")[-1])
                unnest_list.append((self._field_ref(field), alias))
                continue
            elif stage_type == "$lookup":
                join_def = value
                from_col = join_def["from"]
                local_f = join_def["localField"].lstrip("$")
                foreign_f = join_def["foreignField"].lstrip("$")
                as_alias = join_def["as"]
                joins.append((from_col, local_f, foreign_f, as_alias))
                continue

            # ===== 物化阶段：生成 CTE =====
            from_clause = current_table
            if current_table == self.collection:
                from_clause = f"{self.collection} AS t0"
                current_alias = "t0"
            else:
                current_alias = current_table

            # 构建 FROM（含 UNNEST）
            base_from = from_clause
            for field, alias in unnest_list:
                base_from += f", UNNEST({field}) AS {alias}"

            # 构建 JOINs
            join_sqls = []
            for (tbl, local_f, foreign_f, as_a) in joins:
                join_sqls.append(f"LEFT JOIN {tbl} AS {as_a} ON {current_alias}.{local_f} = {as_a}.{foreign_f}")

            # 构建 WHERE
            where_sql = ""
            if where_clauses:
                where_sql = "WHERE " + " AND ".join(f"({wc})" for wc in where_clauses)

            # 构建 SELECT 和 GROUP BY
            select_items = []
            group_keys = []
            new_fields = set()

            if stage_type == "$group":
                for alias, expr in value.items():
                    if alias == "_id":
                        if expr is None:
                            continue
                        elif isinstance(expr, str):
                            resolved_col = self._resolve_field(expr, current_fields)  # ← 关键！
                            safe_alias = self._quote_identifier("_id")
                            select_items.append(f"{resolved_col} AS {safe_alias}")
                            group_keys.append(resolved_col)  # ← 用解析后的列名
                            new_fields.add("_id")
                        elif isinstance(expr, dict):
                            for output_key, field_expr in expr.items():
                                resolved_col = self._resolve_field(field_expr, current_fields)
                                virtual_name = f"_id_{output_key}"
                                safe_alias = self._quote_identifier(virtual_name)
                                select_items.append(f"{resolved_col} AS {safe_alias}")
                                group_keys.append(resolved_col)
                                new_fields.add(virtual_name)
                        else:
                            lit = self._literal(expr)
                            safe_alias = self._quote_identifier("_id")
                            select_items.append(f"{lit} AS {safe_alias}")
                            new_fields.add("_id")
                    else:
                        if isinstance(expr, dict) and len(expr) == 1:
                            op = next(iter(expr))
                            arg = expr[op]
                            if op == "$sum":
                                if arg == 1:
                                    agg_expr = "COUNT(*)"
                                else:
                                    resolved = self._resolve_field(arg, current_fields)
                                    agg_expr = f"SUM({resolved})"
                            elif op == "$avg":
                                resolved = self._resolve_field(arg, current_fields)
                                agg_expr = f"AVG({resolved})"
                            elif op == "$min":
                                resolved = self._resolve_field(arg, current_fields)
                                agg_expr = f"MIN({resolved})"
                            elif op == "$max":
                                resolved = self._resolve_field(arg, current_fields)
                                agg_expr = f"MAX({resolved})"
                            else:
                                agg_expr = "'<UNSUPPORTED>'"
                            safe_alias = self._quote_identifier(alias)
                            select_items.append(f"{agg_expr} AS {safe_alias}")
                            new_fields.add(alias)
                        else:
                            lit = self._literal(expr)
                            safe_alias = self._quote_identifier(alias)
                            select_items.append(f"{lit} AS {safe_alias}")
                            new_fields.add(alias)

                group_sql = "GROUP BY " + ", ".join(group_keys) if group_keys else ""

            elif stage_type in ("$project", "$addFields"):
                # 收集已有字段（用于 $addFields）
                existing_fields = set()
                if stage_type == "$addFields" and current_fields != {"*"}:
                    existing_fields = current_fields.copy()

                for alias, expr in value.items():
                    if alias == "_id" and expr in (0, False):
                        continue
                    safe_alias = self._quote_identifier(alias)
                    if expr in (1, True):
                        resolved = self._resolve_field(f"${alias}", current_fields)
                        select_items.append(f"{resolved} AS {safe_alias}")
                    elif isinstance(expr, (dict, list)) or (isinstance(expr, str) and expr.startswith("$")):
                        sql_expr = self._convert_expression_in_select(expr, current_fields)
                        select_items.append(f"{sql_expr} AS {safe_alias}")
                    else:
                        lit = self._literal(expr)
                        select_items.append(f"{lit} AS {safe_alias}")
                    new_fields.add(alias)

                if stage_type == "$addFields":
                    for f in existing_fields:
                        if f not in value:
                            resolved = self._resolve_field(f"${f}", current_fields)
                            select_items.insert(0, resolved)  # prepend

                group_sql = ""

            else:
                self.errors.append(f"Unsupported stage: {stage_type}")
                select_items = ["*"]
                group_sql = ""
                new_fields = {"*"}

            # 构建 CTE SQL
            select_clause = ", ".join(select_items)
            cte_sql = f"SELECT {select_clause}\nFROM {base_from}"
            if join_sqls:
                cte_sql += "\n" + "\n".join(join_sqls)
            if where_sql:
                cte_sql += "\n" + where_sql
            if group_sql:
                cte_sql += "\n" + group_sql

            # 创建新 CTE
            cte_name = f"cte_{len(ctes) + 1}"
            ctes.append((cte_name, cte_sql))
            current_table = cte_name
            current_fields = new_fields

            # 重置累积状态
            where_clauses = []
            order_by = []
            joins = []
            unnest_list = []

        # ===== 构建最终查询 =====
        final_parts = []

        # CTE 部分
        if ctes:
            cte_clauses = []
            for name, sql in ctes:
                clean_sql = "\n".join(line.rstrip() for line in sql.strip().splitlines())
                cte_clauses.append(f"{name} AS (\n{clean_sql}\n)")
            final_parts.append("WITH " + ",\n".join(cte_clauses))

        # 主查询
        main_query = f"SELECT *\nFROM {current_table}"
        if where_clauses:
            main_query += "\nWHERE " + " AND ".join(f"({wc})" for wc in where_clauses)
        if order_by:
            main_query += "\nORDER BY " + ", ".join(order_by)
        if limit_val is not None:
            main_query += f"\nLIMIT {limit_val}"
            if offset_val > 0:
                main_query += f" OFFSET {offset_val}"

        final_parts.append(main_query)
        final_sql = "\n".join(final_parts)

        if self.errors:
            print("⚠️ 转换警告:")
            for err in self.errors:
                print(f"  - {err}")

        return final_sql

if __name__ == "__main__":
    my_pipeline = [
        { "$match": { "status": "active", "age": { "$gte": 18 } } },
        { 
            "$addFields": { 
                "name": 1,
                "category": 1,      # ← 保留
                "ID": 1,            # ← 保留
                "amount": 1,        # ← 保留
                "statusLabel": {
                    "$cond": {
                        "if": { "$eq": ["$status", "active"] },
                        "then": "Active",
                        "else": "Inactive"
                    }
                }
            } 
        },
        { 
            "$group": { 
                "_id": {
                    "category": "$category",
                    "ID": "$ID",
                },
                "totalAmount": { "$sum": "$amount" },
                "count": { "$sum": 1 }
            } 
        },
        { 
            "$group": { 
                "_id": "$_id.category",
                "totalAmount": { "$sum": "$totalAmount" },
                "count": { "$sum": 1 }
            } 
        },
        { "$sort": { "totalAmount": -1 } },
        { "$limit": 5 }
    ]

    sql = MongoPipelineToDuckDBWithCTE("my_collection").convert(my_pipeline)
    print(sql)