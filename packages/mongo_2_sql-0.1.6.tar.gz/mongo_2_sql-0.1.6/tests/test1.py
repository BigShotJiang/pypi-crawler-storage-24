import sys
from pathlib import Path

# 1. 添加项目根目录
project_root = Path(r"D:\projects\mongo-2-sql\mongo-2-sql\src")
sys.path.insert(0, str(project_root))


from mongo_2_sql import convert_mongo_pipeline_to_sql

def print_separator(title):
    """打印分隔符"""
    print("=" * 60)
    print(f" {title} ")
    print("=" * 60)

def test_complex_pipeline():
    """复杂管道示例"""
    print_separator("复杂管道示例")
    
    pipeline = [
        { "$match": { "status": "active", "age": { "$gte": 18 } } },
        { 
            "$addFields": { 
                "name": 1,
                "category": 1,      # ← 保留
                "ID": 1,            # ← 保留
                "amount": 1,        # ← 保留
                "statusLabel": {
                    "$cond": {
                        "if": { "$eq": ["$status", "active"] },
                        "then": "Active",
                        "else": "Inactive"
                    }
                }
            } 
        },
        { 
            "$group": { 
                "_id": {
                    "category": "$category",
                    "ID": "$ID",
                },
                "totalAmount": { "$sum": "$amount" },
                "count": { "$sum": 1 }
            } 
        },
        { 
            "$group": { 
                "_id": "$_id.category",
                "totalAmount": { "$sum": "$totalAmount" },
                "count": { "$sum": 1 }
            } 
        },
        { "$sort": { "totalAmount": -1 } },
        { "$limit": 5 }
    ]
    sql, metadata = convert_mongo_pipeline_to_sql(pipeline, "transactions")
    print("\nMongoDB Pipeline:")
    for i, stage in enumerate(pipeline):
        print(f"  Stage {i+1}: {stage}")
    print("\n生成的 SQL:")
    print(sql)
    print()
    
    # 打印元数据信息
    print("元数据信息:")
    for key, value in metadata.items():
        print(f"  {key}: {value}")
    print()


if __name__ == '__main__':
    test_complex_pipeline()
