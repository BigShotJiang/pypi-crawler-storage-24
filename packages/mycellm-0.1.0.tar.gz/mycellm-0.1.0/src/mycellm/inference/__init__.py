"""Inference backend abstraction."""
