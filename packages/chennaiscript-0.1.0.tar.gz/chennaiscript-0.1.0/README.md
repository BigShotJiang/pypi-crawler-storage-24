# ChennaiScript 😄

A fun domain-specific programming language inspired by Chennai English slang.

## Features
- Custom syntax (sollu, va vechu, enna na)
- Lexer + Parser + Interpreter
- CLI execution

## Example
