from email.mime import text
from platform import node


def interpret(ast):
    memory = {}
    functions = {}

    def exec_block(block):
        i = 0
        while i < len(block):
            node = block[i]

            if node[0] == "PRINT":
                val = node[1]
                print(memory.get(val, val))
            
            elif node[0] == "PRINT_STR":
                text = node[1]

                 # 🔥 variable replacement (magic)
                for var in memory:
                    text = text.replace(var, str(memory[var]))

                print(text)

            elif node[0] == "ASSIGN":
                _, var, val = node
                memory[var] = int(val)

            elif node[0] == "INPUT":
                var = node[1]
                memory[var] = input(f"dei {var} kudu: ")

            elif node[0] == "IF":
                _, left, op, right, if_block = node

                left_val = int(memory.get(left, left))
                right_val = int(right)

                cond = False
                if op == ">":
                    cond = left_val > right_val
                elif op == "<":
                    cond = left_val < right_val
                elif op == "==":
                    cond = left_val == right_val

                if cond:
                    exec_block(if_block)
                else:
                    # check next node if ELSE
                    if i+1 < len(block) and block[i+1][0] == "ELSE":
                        exec_block(block[i+1][1])
                        i += 1

            elif node[0] == "LOOP":
                _, count, loop_block = node
                for _ in range(int(count)):
                    exec_block(loop_block)

            elif node[0] == "FUNCTION":
                _, name, func_block = node
                functions[name] = func_block

            elif node[0] == "CALL":
                name = node[1]
                if name in functions:
                    exec_block(functions[name])
                else:
                    print(f"❌ dei function {name} illa da")

            i += 1

    exec_block(ast)