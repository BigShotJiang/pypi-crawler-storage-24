from chennaiscript.tokens import *

def tokenize(code):
    tokens = []
    lines = code.split("\n")

    for line in lines:
        line = line.strip()

        # 🔥 Skip comments
        if line.startswith("#") or line == "":
            continue

        words = line.split()

        i = 0
        while i < len(words):
            word = words[i]

            if word == "sollu":
                tokens.append(Token(PRINT, "sollu"))

                # 🔥 capture full sentence after sollu
                remaining = " ".join(words[i+1:])
                if remaining:
                    tokens.append(Token(STRING, remaining))
                else:
                    tokens.append(Token(STRING, ""))

                break  # move to next line

            elif word == "va":
                tokens.append(Token(ASSIGN, word))

            elif word == "enna":
                tokens.append(Token(IF, word))

            elif word == "illa":
                tokens.append(Token(ELSE, word))

            elif word == "repeat":
                tokens.append(Token(LOOP, word))

            elif word == "function":
                tokens.append(Token("FUNCTION", word))

            elif word == "mudichu":
                tokens.append(Token("END", word))

            elif word == "kelu":
                tokens.append(Token(INPUT, word))

            elif word.isdigit():
                tokens.append(Token(NUMBER, int(word)))

            elif word in [">", "<", "=="]:
                tokens.append(Token(OP, word))

            else:
                tokens.append(Token(VAR, word))

            i += 1

        tokens.append(Token("NEWLINE", "\n"))

    return tokens