class Token:
    def __init__(self, type_, value):
        self.type = type_
        self.value = value

    def __repr__(self):
        return f"{self.type}:{self.value}"


PRINT = "PRINT"
VAR = "VAR"
NUMBER = "NUMBER"
ASSIGN = "ASSIGN"
IF = "IF"
ELSE = "ELSE"
LOOP = "LOOP"
INPUT = "INPUT"
STRING = "STRING"
OP = "OP"