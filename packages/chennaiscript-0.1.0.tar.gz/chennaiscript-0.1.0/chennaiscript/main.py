import sys
from chennaiscript.lexer import tokenize
from chennaiscript.parser import parse
from chennaiscript.interpreter import interpret

def run():
    if len(sys.argv) < 2:
        print("Usage: chennaiscript <file.chen>")
        return

    filename = sys.argv[1]

    with open(filename, "r", encoding="utf-8") as f:
        code = f.read()

    tokens = tokenize(code)
    ast = parse(tokens)
    interpret(ast)