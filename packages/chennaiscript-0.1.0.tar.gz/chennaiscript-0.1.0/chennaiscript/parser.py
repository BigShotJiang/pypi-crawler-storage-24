def parse(tokens):
    ast = []
    i = 0

    def parse_block():
        nonlocal i
        block = []

        while i < len(tokens) and tokens[i].type != "END":
            node = parse_statement()
            if node:
                block.append(node)

        i += 1  # skip END
        return block

    def parse_statement():
        nonlocal i
        token = tokens[i]

        # PRINT
        if token.type == "PRINT":
            val = tokens[i+1]
            i += 2
            return ("PRINT_STR", val.value)

        # ASSIGN
        elif token.type == "VAR" and tokens[i+1].type == "ASSIGN":
            var = token.value
            val = tokens[i+2].value
            i += 3
            return ("ASSIGN", var, val)

        # INPUT
        elif token.type == "INPUT":
            var = tokens[i+1].value
            i += 2
            return ("INPUT", var)

        # IF
        elif token.type == "IF":
            left = tokens[i+1].value
            op = tokens[i+2].value
            right = tokens[i+3].value
            i += 4
            block = parse_block()
            return ("IF", left, op, right, block)

        # ELSE
        elif token.type == "ELSE":
            i += 1
            block = parse_block()
            return ("ELSE", block)

        # LOOP
        elif token.type == "LOOP":
            count = tokens[i+1].value
            i += 2
            block = parse_block()
            return ("LOOP", count, block)

        # FUNCTION DEF
        elif token.type == "FUNCTION":
            name = tokens[i+1].value
            i += 2
            block = parse_block()
            return ("FUNCTION", name, block)

        # FUNCTION CALL
        elif token.type == "VAR":
            name = token.value
            i += 1
            return ("CALL", name)

        else:
            i += 1
            return None

    while i < len(tokens):
        stmt = parse_statement()
        if stmt:
            ast.append(stmt)

    return ast