"""High-level tunnel management for exposing local APIs.

This module provides a clean abstraction for setting up tunnels to expose
local containers to the internet for use with Synth optimization jobs.

Primary backends:

- **SynthTunnel** (default): Relay-based HTTPS tunnel via Synth's servers.
  No ``cloudflared`` binary needed. Supports 128 concurrent in-flight
  requests with dynamic memory-based budgeting. Uses ``worker_token``
  for job authentication.

- **NgrokManaged**: Synth-managed ngrok-compatible endpoint flow.
  Requires a Synth-provisioned URL and disallows free/personal ngrok URLs.

Example — SynthTunnel (recommended):

    from synth_ai.core.tunnels import TunneledContainer

    tunnel = await TunneledContainer.create(local_port=8001, api_key="sk_live_...")
    print(tunnel.url)            # https://dev.st.usesynth.ai/s/rt_...
    print(tunnel.worker_token)   # pass this to your job config
    tunnel.close()

Example — managed ngrok-compatible endpoint:

    from synth_ai.core.tunnels import TunneledContainer, TunnelBackend

    tunnel = await TunneledContainer.create(
        local_port=8001,
        backend=TunnelBackend.NgrokManaged,
        managed_ngrok_url="https://example-tunnel.usesynth.ai",
    )
    print(tunnel.url)  # https://example-tunnel.usesynth.ai
    tunnel.close()

Using with optimization jobs::

    # SynthTunnel
    job = PromptLearningJob.from_dict(config,
        container_url=tunnel.url,
        container_worker_token=tunnel.worker_token,
    )

    # Managed ngrok-compatible
    job = PromptLearningJob.from_dict(config,
        container_url=tunnel.url,
        container_api_key=env_api_key,
    )

See Also:
    - `synth_ai.core.tunnels`: Module-level docs with comparison table
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import warnings
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from synth_ai.core.utils.urls import (
    is_cloudflare_tunnel_url,
    is_free_ngrok_url,
    is_synth_managed_ngrok_url,
)
from synth_ai.core.tunnels.errors import TunnelErrorCode, TunnelProviderError

logger = logging.getLogger(__name__)


def _resolve_synth_tunnel_requested_ttl_seconds(
    explicit_ttl_seconds: int | None,
) -> int:
    import os

    min_ttl = 60
    max_ttl = 24 * 60 * 60
    default_ttl = 3600

    value = explicit_ttl_seconds
    if value is None:
        raw = (os.environ.get("SYNTH_TUNNEL_REQUESTED_TTL_SECONDS") or "").strip()
        if raw:
            try:
                value = int(raw)
            except Exception:
                logger.warning(
                    "[TUNNELED_API] Invalid SYNTH_TUNNEL_REQUESTED_TTL_SECONDS=%r; using %ss",
                    raw,
                    default_ttl,
                )
                value = None

    ttl = default_ttl if value is None else int(value)
    if ttl < min_ttl:
        logger.warning(
            "[TUNNELED_API] Requested SynthTunnel TTL %ss below minimum; clamping to %ss",
            ttl,
            min_ttl,
        )
        return min_ttl
    if ttl > max_ttl:
        logger.warning(
            "[TUNNELED_API] Requested SynthTunnel TTL %ss above maximum; clamping to %ss",
            ttl,
            max_ttl,
        )
        return max_ttl
    return ttl


class TunnelBackend(str, Enum):
    """Supported tunnel backends for exposing local APIs.

    **SynthTunnel vs managed ngrok-compatible:**

    Use **SynthTunnel** (default) for optimization jobs (GEPA, MiPRO).
    It requires no external binary, supports 128 concurrent in-flight
    requests with dynamic memory budgeting, and authenticates via
    ``worker_token``.

    Use **NgrokManaged** when Synth infra provisions and owns the tunnel URL.
    Free/personal ngrok URLs are explicitly rejected.

    Attributes:
        SynthTunnel: Relay-based HTTPS tunnel (default, recommended).
            - No ``cloudflared`` binary required
            - Up to 128 concurrent in-flight requests (dynamic cap)
            - Authenticate jobs with ``worker_token``
            - URLs: ``https://st.usesynth.ai/s/rt_...``

        NgrokManaged: Synth-managed ngrok-compatible endpoint.
            - Requires Synth-owned/provisioned URL allow-listed by `SYNTH_MANAGED_TUNNEL_HOSTS`
            - Free ngrok hostnames are rejected
            - Authenticate jobs with ``container_api_key``

        Cloudflare* backends: Deprecated and disabled.

        Localhost: No tunnel, use ``http://localhost:{port}`` directly.
    """

    SynthTunnel = "synthtunnel"
    NgrokManaged = "ngrok_managed"
    CloudflareManagedLease = "cloudflare_managed_lease"
    CloudflareManagedTunnel = "cloudflare_managed"
    CloudflareQuickTunnel = "cloudflare_quick"
    Localhost = "localhost"


class TunnelProvider(str, Enum):
    """Provider-level tunnel selector used by canonical helpers."""

    SynthTunnel = "SynthTunnel"
    Ngrok = "Ngrok"
    Localhost = "Localhost"


_DEPRECATED_CLOUDFLARE_BACKENDS = {
    TunnelBackend.CloudflareManagedLease,
    TunnelBackend.CloudflareManagedTunnel,
    TunnelBackend.CloudflareQuickTunnel,
}


def _raise_cloudflare_disabled(backend: TunnelBackend) -> None:
    warnings.warn(
        f"{backend.value} is deprecated and disabled. Use TunnelBackend.SynthTunnel or TunnelBackend.NgrokManaged.",
        DeprecationWarning,
        stacklevel=3,
    )
    raise RuntimeError(
        f"Tunnel backend '{backend.value}' is disabled. Cloudflare is deprecated; use SynthTunnel or NgrokManaged."
    )


def _resolve_managed_ngrok_url(explicit_url: str | None) -> str:
    candidate = (explicit_url or os.environ.get("SYNTH_MANAGED_NGROK_URL") or "").strip()
    if not candidate:
        raise ValueError(
            "NgrokManaged requires managed_ngrok_url or SYNTH_MANAGED_NGROK_URL to be set."
        )
    if is_cloudflare_tunnel_url(candidate):
        raise ValueError("Cloudflare URLs are forbidden. Use a Synth-managed ngrok-compatible URL.")
    if is_free_ngrok_url(candidate):
        raise ValueError("Free ngrok URLs are forbidden. Use a Synth-managed ngrok-compatible URL.")
    if not is_synth_managed_ngrok_url(candidate):
        raise ValueError(
            "ngrok URL is not recognized as Synth-managed. Add host allowlist in SYNTH_MANAGED_TUNNEL_HOSTS."
        )
    return candidate.rstrip("/")


def _resolve_backend_from_provider(
    backend: TunnelBackend,
    provider: TunnelProvider | str | None,
) -> TunnelBackend:
    if provider is None:
        return backend
    if isinstance(provider, TunnelProvider):
        provider_value = provider.value
    else:
        provider_value = str(provider).strip()
    normalized = provider_value.lower()
    if normalized in {"synthtunnel", "synth_tunnel", "synth"}:
        return TunnelBackend.SynthTunnel
    if normalized in {"ngrok", "ngrokmanaged", "ngrok_managed"}:
        return TunnelBackend.NgrokManaged
    if normalized in {"localhost", "local"}:
        return TunnelBackend.Localhost
    raise ValueError("provider must be one of 'SynthTunnel', 'Ngrok', or 'Localhost'")


@dataclass
class TunneledContainer:
    """A managed tunnel exposing a local API to the internet.

    This class provides a clean interface for:
    1. Provisioning a tunnel (SynthTunnel or NgrokManaged)
    2. Starting the SynthTunnel agent when needed
    3. Verifying DNS resolution and connectivity
    4. Tracking lifecycle for cleanup

    Use `TunneledContainer.create()` with a `TunnelBackend` to provision a tunnel.

    Attributes:
        url: Public HTTPS URL for the tunnel (e.g., "https://st.usesynth.ai/s/rt_...")
        hostname: Hostname without protocol (e.g., "task-1234-5678.usesynth.ai")
        local_port: Local port being tunneled
        backend: The tunnel backend used
        process: Reserved process handle (legacy/non-canonical paths)
        worker_token: SynthTunnel worker token (if using SynthTunnel)

    Example:
        >>> from synth_ai.core.tunnels import TunneledContainer
        >>> tunnel = await TunneledContainer.create(
        ...     local_port=8001,
        ...     api_key="sk_live_...",
        ... )
        >>> print(tunnel.url)
        https://mt-xxxx.usesynth.ai/s/abc123
        >>> tunnel.close()
    """

    url: str
    hostname: str
    local_port: int
    backend: TunnelBackend
    process: Optional[Any] = None
    tunnel_token: Optional[str] = field(default=None, repr=False)
    worker_token: Optional[str] = field(default=None, repr=False)
    _raw: dict[str, Any] = field(default_factory=dict, repr=False)
    # New lease-based fields
    _lease_id: Optional[str] = field(default=None, repr=False)
    _manager: Any = field(default=None, repr=False)  # Reserved for future use
    _handle: Any = field(default=None, repr=False)  # Rust handle for lease-based tunnels
    _synth_session: Any = field(default=None, repr=False)

    @classmethod
    async def create(
        cls,
        local_port: int,
        backend: TunnelBackend = TunnelBackend.SynthTunnel,
        *,
        provider: TunnelProvider | str | None = None,
        api_key: Optional[str] = None,
        env_api_key: Optional[str] = None,
        backend_url: Optional[str] = None,
        verify_dns: bool = True,
        progress: bool = False,
        reason: str | None = None,
        requested_ttl_seconds: int | None = None,
        managed_ngrok_url: str | None = None,
    ) -> TunneledContainer:
        """Create a tunnel to expose a local API.

        This is the main entry point for creating tunnels. It handles:
        1. Requesting a tunnel (Synth relay lease) or validating managed ngrok URL
        2. Starting the SynthTunnel agent for relay leases
        3. Waiting for DNS propagation
        4. Verifying HTTP connectivity
        5. Registering for automatic cleanup

        Args:
            local_port: Local port to tunnel (e.g., 8001)
            backend: Tunnel backend to use. Defaults to SynthTunnel.
                - SynthTunnel: Relay-based HTTPS tunnel (recommended)
                - NgrokManaged: Synth-managed ngrok-compatible endpoint
            api_key: Synth API key for authentication (required for managed tunnels).
                If not provided, will be read from SYNTH_API_KEY environment variable.
            env_api_key: API key for the local container (for health checks).
                Defaults to ENVIRONMENT_API_KEY env var.
            backend_url: Optional backend URL (defaults to production, managed only)
            verify_dns: Whether to verify DNS resolution after creating tunnel.
                Set to False if you're sure DNS will work (e.g., reusing subdomain).
            progress: If True, print status updates during setup
            requested_ttl_seconds: Optional SynthTunnel lease TTL in seconds.
                If not set, reads `SYNTH_TUNNEL_REQUESTED_TTL_SECONDS` env var,
                then falls back to 3600.
            managed_ngrok_url: Synth-managed ngrok-compatible URL. If unset, read from
                `SYNTH_MANAGED_NGROK_URL`.

        Returns:
            TunneledContainer instance with .url, .hostname, .close(), etc.

        Raises:
            ValueError: If api_key is missing for managed tunnels
            RuntimeError: If tunnel creation or verification fails
        """
        # Auto-detect API key from environment if not provided
        if api_key is None:
            api_key = os.environ.get("SYNTH_API_KEY")

        from synth_ai.sdk.container.auth import ensure_container_auth

        resolved_backend = _resolve_backend_from_provider(backend, provider)
        if (
            provider is not None
            and backend != TunnelBackend.SynthTunnel
            and resolved_backend != backend
        ):
            provider_name = provider.value if isinstance(provider, TunnelProvider) else str(provider)
            raise TunnelProviderError(
                "provider conflicts with backend",
                code=TunnelErrorCode.PROVIDER_INVALID,
                provider=provider_name,
                hint="Pass either provider or backend, or make them agree.",
            )
        backend = resolved_backend

        if backend == TunnelBackend.Localhost:
            url = f"http://localhost:{local_port}"
            return cls(
                url=url,
                hostname="localhost",
                local_port=local_port,
                backend=backend,
                process=None,
                tunnel_token=None,
                _raw={},
            )

        if backend in _DEPRECATED_CLOUDFLARE_BACKENDS:
            _raise_cloudflare_disabled(backend)

        if backend == TunnelBackend.NgrokManaged:
            url = _resolve_managed_ngrok_url(managed_ngrok_url)
            return cls(
                url=url,
                hostname=url.split("://", 1)[-1].split("/", 1)[0],
                local_port=local_port,
                backend=backend,
                process=None,
                tunnel_token=None,
                worker_token=None,
                _raw={},
            )

        if backend == TunnelBackend.SynthTunnel:
            if not api_key:
                raise ValueError("api_key is required for SynthTunnel")
            env_api_key = (env_api_key or "").strip() or None
            if env_api_key is None:
                env_api_key = (
                    (os.environ.get("ENVIRONMENT_API_KEY") or "").strip()
                    or (os.environ.get("DEV_ENVIRONMENT_API_KEY") or "").strip()
                    or None
                )
            if env_api_key is None:
                # SynthTunnel agent forwards container auth headers to the local app.
                # Ensure a stable local key exists even when the caller did not
                # preconfigure ENVIRONMENT_API_KEY.
                env_api_key = ensure_container_auth(upload=False)
            env_api_key = (env_api_key or "").strip() or None
            if env_api_key is None:
                raise RuntimeError(
                    "SynthTunnel requires ENVIRONMENT_API_KEY for local container auth, "
                    "but no key could be resolved."
                )

            async def _wait_for_agent_online(
                public_url: str,
                worker_token: str,
                *,
                timeout_sec: float = 10.0,
                request_timeout_sec: float = 2.0,
                poll_interval_sec: float = 0.25,
            ) -> None:
                """Wait until the relay can reach the local container.

                The Rust WS agent may take a moment to connect. If we submit jobs
                before it is online, the backend will fail with AGENT_OFFLINE.
                """
                import time

                import httpx

                health_url = f"{public_url.rstrip('/')}/health"
                headers = {"Authorization": f"Bearer {worker_token}"}
                deadline = time.time() + timeout_sec
                last_err: Exception | None = None

                # Reuse one client while polling to reduce startup overhead.
                async with httpx.AsyncClient(timeout=request_timeout_sec) as http_client:
                    while time.time() < deadline:
                        try:
                            resp = await http_client.get(health_url, headers=headers)
                            if resp.status_code == 200:
                                return
                            # Surfacing non-200 responses is critical for debugging local
                            # auth mismatches (e.g., container expects ENVIRONMENT_API_KEY).
                            last_err = RuntimeError(
                                f"Health check returned HTTP {resp.status_code}"
                            )
                        except Exception as exc:
                            last_err = exc
                        await asyncio.sleep(poll_interval_sec)

                if last_err:
                    raise RuntimeError(
                        f"SynthTunnel agent did not come online for {health_url}: {last_err!r}"
                    )
                raise RuntimeError(f"SynthTunnel agent did not come online for {health_url}")

            def _read_env_int(name: str, default: int, minimum: int = 1) -> int:
                raw = (os.environ.get(name) or "").strip()
                if not raw:
                    return default
                try:
                    return max(minimum, int(raw))
                except Exception:
                    logger.warning(
                        "[SynthTunnel] Invalid %s=%r; using default %s",
                        name,
                        raw,
                        default,
                    )
                    return default

            def _read_env_float(name: str, default: float, minimum: float = 0.0) -> float:
                raw = (os.environ.get(name) or "").strip()
                if not raw:
                    return default
                try:
                    return max(minimum, float(raw))
                except Exception:
                    logger.warning(
                        "[SynthTunnel] Invalid %s=%r; using default %s",
                        name,
                        raw,
                        default,
                    )
                    return default

            # Step 1: Create lease via Python (simple HTTP POST, works fine)
            from .synth_tunnel import (
                SynthTunnelClient,
                _collect_container_keys,
                get_client_instance_id,
                hostname_from_url,
            )

            client = SynthTunnelClient(api_key, backend_url=backend_url)
            lease_ttl_seconds = _resolve_synth_tunnel_requested_ttl_seconds(requested_ttl_seconds)
            max_attempts = _read_env_int("SYNTH_TUNNEL_CREATE_MAX_ATTEMPTS", default=3)
            base_online_timeout_sec = _read_env_float(
                "SYNTH_TUNNEL_AGENT_ONLINE_TIMEOUT_SEC", default=20.0, minimum=1.0
            )
            online_timeout_backoff_multiplier = _read_env_float(
                "SYNTH_TUNNEL_AGENT_ONLINE_TIMEOUT_BACKOFF_MULTIPLIER",
                default=2.0,
                minimum=1.0,
            )
            online_request_timeout_sec = _read_env_float(
                "SYNTH_TUNNEL_AGENT_ONLINE_REQUEST_TIMEOUT_SEC", default=2.0, minimum=0.2
            )
            online_poll_interval_sec = _read_env_float(
                "SYNTH_TUNNEL_AGENT_ONLINE_POLL_INTERVAL_SEC", default=0.25, minimum=0.05
            )
            max_online_timeout_sec = _read_env_float(
                "SYNTH_TUNNEL_AGENT_ONLINE_TIMEOUT_MAX_SEC", default=120.0, minimum=1.0
            )
            retry_backoff_initial_sec = _read_env_float(
                "SYNTH_TUNNEL_CREATE_RETRY_INITIAL_BACKOFF_SEC", default=1.0, minimum=0.0
            )
            retry_backoff_max_sec = _read_env_float(
                "SYNTH_TUNNEL_CREATE_RETRY_MAX_BACKOFF_SEC", default=8.0, minimum=0.0
            )

            # Step 2: Start Rust WS agent (runs in its own tokio runtime)
            import synth_ai_py

            container_keys = _collect_container_keys(env_api_key)
            for attempt in range(1, max_attempts + 1):
                lease = None
                agent = None
                timeout_for_attempt = min(
                    max_online_timeout_sec,
                    base_online_timeout_sec * (online_timeout_backoff_multiplier ** (attempt - 1)),
                )
                try:
                    lease = await client.create_lease(
                        client_instance_id=get_client_instance_id(),
                        local_host="127.0.0.1",
                        local_port=local_port,
                        requested_ttl_seconds=lease_ttl_seconds,
                    )
                    max_inflight = int(lease.limits.get("max_inflight", 128))
                    agent = await asyncio.to_thread(
                        synth_ai_py.synth_tunnel_start,
                        lease.agent_url,
                        lease.agent_token,
                        lease.lease_id,
                        "127.0.0.1",
                        local_port,
                        lease.public_url,
                        lease.worker_token,
                        container_keys,
                        max_inflight,
                    )

                    # Ensure the agent is actually online before returning.
                    await _wait_for_agent_online(
                        lease.public_url,
                        lease.worker_token,
                        timeout_sec=timeout_for_attempt,
                        request_timeout_sec=online_request_timeout_sec,
                        poll_interval_sec=online_poll_interval_sec,
                    )

                    url = lease.public_url
                    return cls(
                        url=url,
                        hostname=hostname_from_url(url),
                        local_port=local_port,
                        backend=backend,
                        process=None,
                        tunnel_token=None,
                        worker_token=lease.worker_token,
                        _raw={
                            "lease_id": lease.lease_id,
                            "route_token": lease.route_token,
                            "agent_url": lease.agent_url,
                        },
                        _lease_id=lease.lease_id,
                        _manager=None,
                        _handle=None,
                        _synth_session={"agent": agent, "client": client, "lease": lease},
                    )
                except Exception as exc:
                    if agent is not None:
                        with contextlib.suppress(Exception):
                            agent.stop()
                    if lease is not None:
                        with contextlib.suppress(Exception):
                            await client.close_lease(lease.lease_id)
                    if attempt >= max_attempts:
                        raise RuntimeError(
                            f"SynthTunnel create failed after {max_attempts} attempts: {exc!r}"
                        ) from exc

                    retry_sleep = min(
                        retry_backoff_max_sec,
                        retry_backoff_initial_sec * (2 ** (attempt - 1)),
                    )
                    logger.warning(
                        "[SynthTunnel] Bring-up attempt %s/%s failed (timeout=%.1fs): %r. Retrying in %.1fs",
                        attempt,
                        max_attempts,
                        timeout_for_attempt,
                        exc,
                        retry_sleep,
                    )
                    if retry_sleep > 0:
                        await asyncio.sleep(retry_sleep)

        # Resolve env_api_key from environment if not provided
        if env_api_key is None:
            env_api_key = ensure_container_auth(
                backend_base=backend_url,
                synth_api_key=api_key,
            )

        return await cls._create_via_rust(
            local_port=local_port,
            backend=backend,
            api_key=api_key,
            env_api_key=env_api_key,
            backend_url=backend_url,
            verify_dns=verify_dns,
            progress=progress,
        )

    @classmethod
    async def _create_via_rust(
        cls,
        local_port: int,
        backend: TunnelBackend,
        api_key: Optional[str],
        env_api_key: Optional[str],
        backend_url: Optional[str],
        verify_dns: bool,
        progress: bool,
    ) -> TunneledContainer:
        """Internal: Create a tunnel using Rust core."""
        import synth_ai_py

        backend_map = {}
        backend_key = backend_map.get(backend)
        if backend_key is None:
            raise ValueError(f"Unsupported tunnel backend: {backend}")

        handle = await asyncio.to_thread(
            synth_ai_py.tunnel_open,
            backend_key,
            local_port,
            api_key,
            backend_url,
            env_api_key,
            False,
            verify_dns,
            progress,
        )

        return cls(
            url=handle.url,
            hostname=handle.hostname,
            local_port=local_port,
            backend=backend,
            process=None,
            tunnel_token=None,
            _raw={
                "lease_id": getattr(handle, "lease_id", None),
                "process_id": getattr(handle, "process_id", None),
            },
            _lease_id=getattr(handle, "lease_id", None),
            _manager=None,
            _handle=handle,
        )

    async def close_async(self) -> None:
        """Close the tunnel and await all async cleanup work."""
        logger.info("[TUNNELED_API] close_async() called")
        if self.backend == TunnelBackend.SynthTunnel and self._synth_session:
            session = self._synth_session
            try:
                # Rust-only tunnel runtime: dict session payload is required.
                if not isinstance(session, dict):
                    raise RuntimeError(
                        "Invalid SynthTunnel session type; expected Rust session dict."
                    )
                agent = session.get("agent")
                if agent is not None:
                    agent.stop()
                client = session.get("client")
                lease = session.get("lease")
                if client is not None and lease is not None:
                    await client.close_lease(lease.lease_id)
            except Exception as e:
                logger.warning("[TUNNELED_API] SynthTunnel close failed: %s", e)
            self._synth_session = None
            self._lease_id = None
            self.worker_token = None
            return

        if self._handle:
            try:
                self._handle.close()
            except Exception as e:
                logger.warning("[TUNNELED_API] Close failed: %s", e)
            self._handle = None
            self._lease_id = None
            return

        if self.process:
            try:
                import synth_ai_py

                synth_ai_py.stop_tunnel(self.process)
            except Exception:
                with contextlib.suppress(Exception):
                    self.process.terminate()
            self.process = None
            return

        logger.debug("[TUNNELED_API] close_async() - nothing to close")

    def close(self) -> None:
        """Close the tunnel and terminate any associated tunnel runtime.

        This is called automatically when the process exits (via atexit),
        but you can call it explicitly for earlier cleanup.
        """
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(self.close_async())
            return
        raise RuntimeError("close() cannot be called from an async context; await close_async().")

    def __enter__(self) -> TunneledContainer:
        """Context manager entry (for sync use after async creation)."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit - closes tunnel."""
        self.close()

    @classmethod
    async def create_for_app(
        cls,
        app: Any,
        local_port: int | None = None,
        backend: TunnelBackend = TunnelBackend.SynthTunnel,
        *,
        provider: TunnelProvider | str | None = None,
        api_key: Optional[str] = None,
        backend_url: Optional[str] = None,
        verify_dns: bool = True,
        progress: bool = False,
        requested_ttl_seconds: int | None = None,
        managed_ngrok_url: str | None = None,
    ) -> TunneledContainer:
        """Create a tunnel for a FastAPI/ASGI app, handling server startup automatically.

        This is a convenience method that:
        1. Finds an available port (or uses the provided one)
        2. Kills any process using that port
        3. Starts the app server in the background
        4. Waits for health check
        5. Creates and returns the tunnel

        Args:
            app: FastAPI or ASGI application to tunnel
            local_port: Port to use (defaults to finding an available port starting from 8001)
            backend: Tunnel backend to use (defaults to SynthTunnel)
            api_key: Synth API key (defaults to SYNTH_API_KEY env var)
            backend_url: Backend URL (defaults to production)
            verify_dns: Whether to verify DNS resolution
            progress: If True, print status updates
            requested_ttl_seconds: Optional SynthTunnel lease TTL in seconds.
            managed_ngrok_url: Synth-managed ngrok-compatible URL for NgrokManaged backend.

        Returns:
            TunneledContainer instance with .url, .hostname, .close(), etc.

        Example:
            >>> from fastapi import FastAPI
            >>> app = FastAPI()
            >>> tunnel = await TunneledContainer.create_for_app(app)
            >>> print(f"App exposed at: {tunnel.url}")
        """
        import os

        from synth_ai.sdk.container._impl.server import run_server_background

        from .rust import find_available_port, kill_port, wait_for_health_check

        if api_key is None:
            api_key = os.environ.get("SYNTH_API_KEY") or None

        # Find or use port
        if local_port is None:
            local_port = find_available_port(8001)
            if progress:
                print(f"Auto-selected port: {local_port}")
        else:
            # Kill any process using the port
            kill_port(local_port)

        # Start the server
        if progress:
            print(f"Starting server on port {local_port}...")
        run_server_background(app, local_port)

        # Wait for health check
        if progress:
            print("Waiting for server health check...")
        await wait_for_health_check("localhost", local_port, timeout=30.0)

        # Create tunnel
        return await cls.create(
            local_port=local_port,
            backend=backend,
            provider=provider,
            api_key=api_key,
            backend_url=backend_url,
            verify_dns=verify_dns,
            progress=progress,
            requested_ttl_seconds=requested_ttl_seconds,
            managed_ngrok_url=managed_ngrok_url,
        )


__all__ = ["TunneledContainer", "TunnelBackend", "TunnelProvider"]
