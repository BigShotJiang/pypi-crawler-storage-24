from __future__ import annotations

from typing import Any


def validate_container_url(url: str, *, name: str = "CONTAINER_BASE_URL") -> None:
    from synth_ai.sdk.container._impl.validators import validate_container_url as _vt

    try:
        _vt(url)
    except ValueError as exc:
        raise ValueError(f"{name}: {exc}") from exc


def validate_trainer_cfg_rl(trainer: dict[str, Any]) -> None:
    bs = int(trainer.get("batch_size", 1))
    gs = int(trainer.get("group_size", 2))
    if bs < 1:
        raise ValueError("trainer.batch_size must be >= 1")
    if gs < 2:
        raise ValueError("trainer.group_size must be >= 2")


def validate_training_jsonl(path: str, *, sample_lines: int = 50) -> None:
    """Validate training JSONL file.

    Note: Full SFT validation has been moved to the research repo.
    This is a basic JSON structure check only.
    """
    import json
    from pathlib import Path

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(str(p))

    max_samples = max(1, sample_lines)
    non_empty_lines = 0

    with p.open("r", encoding="utf-8") as fh:
        for lineno, raw_line in enumerate(fh, start=1):
            stripped = raw_line.strip()
            if not stripped:
                continue
            non_empty_lines += 1
            if non_empty_lines > max_samples:
                break
            try:
                data = json.loads(stripped)
                if not isinstance(data, dict):
                    raise ValueError(f"line {lineno}: expected JSON object")
                if "messages" not in data:
                    raise ValueError(f"line {lineno}: missing 'messages' field")
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid json on line {lineno}: {exc}") from exc

    if non_empty_lines == 0:
        raise ValueError("empty JSONL")
