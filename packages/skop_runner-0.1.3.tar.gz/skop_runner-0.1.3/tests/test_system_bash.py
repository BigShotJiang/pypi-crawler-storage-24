"""Tests for system.bash RPC handler."""

import asyncio
import os
import tempfile
import pytest
from pathlib import Path

from skop_runner.message_handler import MessageHandler, MAX_CONCURRENT_BASH
from skop_runner.file_manager import FileManager
from skop_runner.mock_backend import MockKernelBackend


@pytest.fixture
def tmp_project(tmp_path):
    """Create a temp project directory."""
    return tmp_path


@pytest.fixture
def handler(tmp_project):
    """Create a MessageHandler with mock backend and temp project root."""
    backend = MockKernelBackend()
    fm = FileManager()
    fm.set_root(str(tmp_project))
    h = MessageHandler(kernel_backend=backend, file_manager=fm)
    return h


async def bash_request(handler, command, timeout=None):
    """Helper to send a system.bash JSON-RPC request."""
    params = {"command": command}
    if timeout is not None:
        params["timeout"] = timeout
    msg = {"jsonrpc": "2.0", "id": "test-1", "method": "system.bash", "params": params}
    return await handler.handle_message(msg)


@pytest.mark.asyncio
async def test_basic_echo(handler):
    """Basic command: echo hello → stdout='hello\\n', exit_code=0."""
    resp = await bash_request(handler, "echo hello")
    assert "result" in resp
    result = resp["result"]
    assert result["stdout"].strip() == "hello"
    assert result["exit_code"] == 0
    assert result["truncated"] is False


@pytest.mark.asyncio
async def test_failing_command(handler):
    """Failing command: exit 1 → exit_code=1."""
    resp = await bash_request(handler, "exit 1")
    result = resp["result"]
    assert result["exit_code"] == 1


@pytest.mark.asyncio
async def test_stderr_output(handler):
    """Stderr output: echo err >&2 → stderr contains 'err'."""
    resp = await bash_request(handler, "echo err >&2")
    result = resp["result"]
    assert "err" in result["stderr"]


@pytest.mark.asyncio
async def test_timeout(handler):
    """Timeout: sleep 999 with timeout=1 → exit_code=-1."""
    resp = await bash_request(handler, "sleep 999", timeout=1)
    result = resp["result"]
    assert result["exit_code"] == -1
    assert "timed out" in result["stderr"]


@pytest.mark.asyncio
async def test_no_project_root():
    """No project root set → ValueError."""
    backend = MockKernelBackend()
    fm = FileManager()
    # Don't set root
    h = MessageHandler(kernel_backend=backend, file_manager=fm)
    resp = await bash_request(h, "echo hello")
    assert "error" in resp
    assert "project root" in resp["error"]["message"].lower()


@pytest.mark.asyncio
async def test_concurrency_limit(handler):
    """Exceeding MAX_CONCURRENT_BASH raises RuntimeError."""
    # Fill up the bash slots
    handler._active_bash_count = MAX_CONCURRENT_BASH

    resp = await bash_request(handler, "echo hello")
    assert "error" in resp
    assert "concurrent" in resp["error"]["message"].lower()

    # Reset
    handler._active_bash_count = 0


@pytest.mark.asyncio
async def test_invalid_command_empty(handler):
    """Empty command string → ValueError."""
    resp = await bash_request(handler, "")
    assert "error" in resp
    assert "non-empty" in resp["error"]["message"].lower()


@pytest.mark.asyncio
async def test_invalid_command_whitespace(handler):
    """Whitespace-only command → ValueError."""
    resp = await bash_request(handler, "   ")
    assert "error" in resp
    assert "non-empty" in resp["error"]["message"].lower()


@pytest.mark.asyncio
async def test_clean_environment(handler):
    """Environment is clean: env output should not contain ANTHROPIC_API_KEY."""
    # Set a fake secret in the current process env
    os.environ["ANTHROPIC_API_KEY"] = "sk-test-secret-key"
    try:
        resp = await bash_request(handler, "env")
        result = resp["result"]
        assert "ANTHROPIC_API_KEY" not in result["stdout"]
        assert "sk-test-secret-key" not in result["stdout"]
    finally:
        del os.environ["ANTHROPIC_API_KEY"]


@pytest.mark.asyncio
async def test_cwd_is_project_root(handler, tmp_project):
    """Commands run with cwd set to project root."""
    resp = await bash_request(handler, "pwd")
    result = resp["result"]
    # Resolve symlinks (macOS /tmp → /private/tmp)
    assert result["stdout"].strip() == str(tmp_project.resolve())


@pytest.mark.asyncio
async def test_bash_count_decrements_on_success(handler):
    """Active bash count returns to 0 after successful command."""
    assert handler._active_bash_count == 0
    await bash_request(handler, "echo hello")
    assert handler._active_bash_count == 0


@pytest.mark.asyncio
async def test_bash_count_decrements_on_timeout(handler):
    """Active bash count returns to 0 after timeout."""
    assert handler._active_bash_count == 0
    await bash_request(handler, "sleep 999", timeout=1)
    assert handler._active_bash_count == 0
