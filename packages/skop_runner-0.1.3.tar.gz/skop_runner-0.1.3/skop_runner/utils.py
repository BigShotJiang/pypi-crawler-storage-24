import logging
from rich.logging import RichHandler


def setup_logger(level: str = "INFO"):
    """Set up rich logging."""
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(rich_tracebacks=True)],
    )

    return logging.getLogger("skop-runner")
