"""Skill scanner package."""
