"""Static rules analyzers."""
