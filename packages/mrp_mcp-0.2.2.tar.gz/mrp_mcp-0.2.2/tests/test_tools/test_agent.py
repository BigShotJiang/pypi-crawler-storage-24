from __future__ import annotations

import pytest

from mcp.server.fastmcp import FastMCP

from mrp_mcp.tools.agent import register


@pytest.fixture
def mcp_server(mock_agent, state):
    mcp = FastMCP("test")
    register(mcp, mock_agent, state)
    return mcp


@pytest.mark.asyncio
async def test_whoami(mcp_server, mock_agent):
    result = await mcp_server.call_tool("mrp_whoami", {})
    text = result[0][0].text

    mock_agent.client.get_agent.assert_called_once_with(mock_agent.public_key)
    assert "Identity" in text
    assert "Test Agent" in text
    assert "text:chat" in text
    assert "active" in text


@pytest.mark.asyncio
async def test_update_profile_name(mcp_server, mock_agent):
    result = await mcp_server.call_tool(
        "mrp_update_profile", {"name": "New Name"}
    )
    text = result[0][0].text

    mock_agent.client.update_agent.assert_called_once()
    call_kwargs = mock_agent.client.update_agent.call_args
    assert call_kwargs.kwargs["display_name"] == "New Name"
    assert "Profile updated" in text


@pytest.mark.asyncio
async def test_update_profile_capabilities(mcp_server, mock_agent):
    result = await mcp_server.call_tool(
        "mrp_update_profile", {"capabilities": "text:chat,code:review"}
    )
    text = result[0][0].text

    call_kwargs = mock_agent.client.update_agent.call_args
    assert call_kwargs.kwargs["capabilities"] == ["text:chat", "code:review"]
    assert "Profile updated" in text


@pytest.mark.asyncio
async def test_update_profile_metadata(mcp_server, mock_agent):
    result = await mcp_server.call_tool(
        "mrp_update_profile", {"metadata": {"version": "2.0"}}
    )
    text = result[0][0].text

    call_kwargs = mock_agent.client.update_agent.call_args
    assert call_kwargs.kwargs["metadata"] == {"version": "2.0"}
    assert "Profile updated" in text


@pytest.mark.asyncio
async def test_register_webhook(mcp_server, mock_agent):
    result = await mcp_server.call_tool(
        "mrp_register_webhook",
        {"url": "https://example.com/webhook", "secret": "s3cret"},
    )
    text = result[0][0].text

    mock_agent.client._request.assert_called_once()
    assert "Webhook registered" in text
    assert "https://example.com/webhook" in text
