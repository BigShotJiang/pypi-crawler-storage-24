"""Push a Harbor job directory to trajectories.sh."""

import os
import tarfile
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import httpx
from rich.console import Console
from rich.progress import (
    Progress,
    BarColumn,
    TextColumn,
    TimeElapsedColumn,
    MofNCompleteColumn,
    DownloadColumn,
    SpinnerColumn,
)

from trajectories.config import get_api_key, get_api_url

console = Console()

SKIP_PATTERNS = {"__pycache__", ".DS_Store", ".git"}
MAX_FILE_SIZE = 50 * 1024 * 1024
ARCHIVE_THRESHOLD = 50


def collect_files(job_dir: Path) -> list[tuple[Path, str]]:
    """Collect all files in the job directory with relative paths."""
    files = []
    for root, dirs, filenames in os.walk(job_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_PATTERNS]
        for name in filenames:
            if name in SKIP_PATTERNS:
                continue
            abs_path = Path(root) / name
            rel_path = abs_path.relative_to(job_dir)
            if abs_path.stat().st_size > MAX_FILE_SIZE:
                continue
            files.append((abs_path, str(rel_path)))
    return files


def push_job(
    job_dir: Path,
    slug: str | None = None,
    name: str | None = None,
    visibility: str = "private",
    api_url: str | None = None,
    api_key: str | None = None,
    concurrency: int = 12,
):
    """Push a Harbor job directory to trajectories.sh."""
    api_url = api_url or get_api_url()
    api_key = api_key or get_api_key()

    if not api_key:
        console.print("[red]No API key configured. Run: trajectories login[/red]")
        raise SystemExit(1)

    if not job_dir.exists() or not job_dir.is_dir():
        console.print(f"[red]Directory not found: {job_dir}[/red]")
        raise SystemExit(1)

    if not slug:
        slug = job_dir.name

    if not name:
        name = slug

    headers = {"Authorization": f"Bearer {api_key}"}
    client = httpx.Client(base_url=api_url, headers=headers, timeout=300.0)

    console.print(f"[bold]Pushing[/bold] {job_dir} → [cyan]{slug}[/cyan]")

    files = collect_files(job_dir)
    total_size = sum(f.stat().st_size for f, _ in files)
    console.print(f"  {len(files)} files, {total_size / 1024 / 1024:.1f} MB")

    resp = client.post("/api/cli/push/init", json={
        "slug": slug,
        "name": name,
        "visibility": visibility,
    })
    if resp.status_code != 200:
        console.print(f"[red]Init failed: {resp.text}[/red]")
        raise SystemExit(1)

    init_data = resp.json()
    job_id = init_data["job_id"]
    console.print(f"  Job ID: [dim]{job_id}[/dim]")

    if len(files) >= ARCHIVE_THRESHOLD:
        _push_archive(client, job_id, job_dir, files, total_size)
    else:
        _push_files(client, job_id, files, total_size, concurrency)

    console.print("  Finalizing...")
    resp = client.post(f"/api/cli/push/{job_id}/finalize")
    if resp.status_code != 200:
        console.print(f"[red]Finalize failed: {resp.text}[/red]")
        raise SystemExit(1)

    result = resp.json()
    console.print()
    console.print(f"[green bold]✓ Pushed successfully![/green bold]")
    console.print(f"  Trials: {result['n_trials']}")
    if result.get("mean_reward") is not None:
        console.print(f"  Pass rate: {result['mean_reward'] * 100:.0f}%")
    console.print(f"  Viewer: {api_url}{result['viewer_url']}")


CHUNK_SIZE_MB = 80


def _push_archive(client: httpx.Client, job_id: str, job_dir: Path, files: list, total_size: int):
    """Compress and upload as tar.gz archive(s), chunking if needed."""
    with tempfile.TemporaryDirectory() as tmpdir:
        archive_path = os.path.join(tmpdir, "upload.tar.gz")

        console.print(f"  Compressing {len(files)} files...")
        with tarfile.open(archive_path, "w:gz") as tar:
            for abs_path, rel_path in files:
                tar.add(str(abs_path), arcname=rel_path)

        archive_size = os.path.getsize(archive_path)
        ratio = (1 - archive_size / total_size) * 100 if total_size > 0 else 0
        console.print(f"  Archive: {archive_size / 1024 / 1024:.1f} MB ({ratio:.0f}% compressed)")

        chunk_limit = CHUNK_SIZE_MB * 1024 * 1024

        if archive_size <= chunk_limit:
            _upload_single_archive(client, job_id, archive_path, archive_size)
        else:
            _upload_chunked(client, job_id, files, tmpdir, chunk_limit)


def _upload_single_archive(client: httpx.Client, job_id: str, archive_path: str, archive_size: int):
    """Upload a single archive that fits within the size limit."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Uploading archive"),
        BarColumn(bar_width=30),
        DownloadColumn(),
        TextColumn("·"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("upload", total=archive_size)
        with open(archive_path, "rb") as f:
            resp = client.post(
                f"/api/cli/push/{job_id}/archive",
                files={"file": ("upload.tar.gz", f, "application/gzip")},
                timeout=600.0,
            )
            progress.update(task, completed=archive_size)

    if resp.status_code != 200:
        console.print(f"[red]Archive upload failed: {resp.text}[/red]")
        raise SystemExit(1)

    result = resp.json()
    if result.get("errors", 0) > 0:
        console.print(f"  [yellow]Stored: {result['uploaded']}, Errors: {result['errors']}[/yellow]")
    else:
        console.print(f"  [green]All {result['uploaded']} files stored[/green]")


def _upload_chunked(client: httpx.Client, job_id: str, files: list, tmpdir: str, chunk_limit: int):
    """Split files into multiple archives that each fit within the size limit."""
    chunks: list[list] = [[]]
    current_size = 0

    for abs_path, rel_path in files:
        fsize = abs_path.stat().st_size
        if current_size + fsize > chunk_limit * 3 and chunks[-1]:
            chunks.append([])
            current_size = 0
        chunks[-1].append((abs_path, rel_path))
        current_size += fsize

    total_uploaded = 0
    total_errors = 0

    for i, chunk_files in enumerate(chunks):
        chunk_path = os.path.join(tmpdir, f"chunk-{i}.tar.gz")

        console.print(f"  Compressing chunk {i + 1}/{len(chunks)} ({len(chunk_files)} files)...")
        with tarfile.open(chunk_path, "w:gz") as tar:
            for abs_path, rel_path in chunk_files:
                tar.add(str(abs_path), arcname=rel_path)

        chunk_size = os.path.getsize(chunk_path)
        console.print(f"  Chunk {i + 1}: {chunk_size / 1024 / 1024:.1f} MB")

        with Progress(
            SpinnerColumn(),
            TextColumn(f"[bold blue]Uploading chunk {i + 1}/{len(chunks)}"),
            BarColumn(bar_width=30),
            DownloadColumn(),
            TextColumn("·"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("upload", total=chunk_size)
            with open(chunk_path, "rb") as f:
                resp = client.post(
                    f"/api/cli/push/{job_id}/archive",
                    files={"file": (f"chunk-{i}.tar.gz", f, "application/gzip")},
                    timeout=600.0,
                )
                progress.update(task, completed=chunk_size)

        if resp.status_code != 200:
            console.print(f"[red]Chunk {i + 1} upload failed: {resp.text}[/red]")
            raise SystemExit(1)

        result = resp.json()
        total_uploaded += result.get("uploaded", 0)
        total_errors += result.get("errors", 0)

        os.unlink(chunk_path)

    if total_errors > 0:
        console.print(f"  [yellow]Stored: {total_uploaded}, Errors: {total_errors}[/yellow]")
    else:
        console.print(f"  [green]All {total_uploaded} files stored across {len(chunks)} chunks[/green]")


def _push_files(client: httpx.Client, job_id: str, files: list, total_size: int, concurrency: int):
    """Upload files individually (used for small jobs)."""
    uploaded = 0
    errors = 0

    def upload_one(abs_path: Path, rel_path: str) -> int:
        file_size = abs_path.stat().st_size
        for attempt in range(3):
            try:
                with open(abs_path, "rb") as f:
                    upload_resp = client.post(
                        f"/api/cli/push/{job_id}/file",
                        files={"file": (rel_path, f, "application/octet-stream")},
                        data={"path": rel_path},
                    )
                if upload_resp.status_code == 200:
                    return file_size
            except Exception:
                pass
            if attempt < 2:
                time.sleep(1.0 * (attempt + 1))
        return -1

    with Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=30),
        MofNCompleteColumn(),
        TextColumn("·"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Uploading", total=len(files))

        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            futures = {executor.submit(upload_one, ap, rp): (ap, rp) for ap, rp in files}
            for future in as_completed(futures):
                _, rel_path = futures[future]
                result = future.result()
                if result >= 0:
                    uploaded += 1
                    progress.console.print(f"  [green]✓[/green] [dim]{rel_path}[/dim]")
                else:
                    errors += 1
                    progress.console.print(f"  [red]✗[/red] [dim]{rel_path}[/dim]")
                progress.advance(task)

    if errors > 0:
        console.print(f"  [yellow]Uploaded: {uploaded}, Errors: {errors}[/yellow]")
    else:
        console.print(f"  [green]All {uploaded} files uploaded[/green]")
