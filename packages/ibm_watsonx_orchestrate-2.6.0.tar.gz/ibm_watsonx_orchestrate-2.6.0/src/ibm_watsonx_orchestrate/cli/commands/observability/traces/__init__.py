"""Traces CLI commands."""
