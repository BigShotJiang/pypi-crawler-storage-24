import os
from importlib.metadata import version

__version__ = version("rembus")

from .core import RbURL  # noqa: F401
from .component import anonym, component, connect
from .settings import (  # noqa: F401
    nowbucket,
    rembus_dir,
    DEFAULT_BROKER,
    TENANTS_FILE,
)
from .protocol import (  # noqa: F401
    RembusError,
    CBOR,
    JSON,
    LastReceived,
    Now,
    QOS0,
    QOS1,
    QOS2,
    SIG_ECDSA,
    SIG_RSA,
)
from .router import add_plugin
from .sync import node, register
from .keyspace import KeySpaceRouter
from .db import dbconnect

if os.environ.get("REMBUS_KEEP_PROXY", "0") == "0":
    os.environ.pop("http_proxy", None)
    os.environ.pop("HTTP_PROXY", None)
    os.environ.pop("https_proxy", None)
    os.environ.pop("HTTPS_PROXY", None)

__all__ = [
    "add_plugin",
    "anonym",
    "nowbucket",
    "connect",
    "dbconnect",
    "component",
    "node",
    "register",
    "rembus_dir",
    "KeySpaceRouter",
    "RbURL",
]
