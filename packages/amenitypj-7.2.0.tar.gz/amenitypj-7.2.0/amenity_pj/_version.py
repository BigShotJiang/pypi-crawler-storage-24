"""
Provides amenity_pj version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update amenity_pj` to change this file.

from incremental import Version

__version__ = Version("amenity_pj", 7, 2, 0)
__all__ = ["__version__"]
