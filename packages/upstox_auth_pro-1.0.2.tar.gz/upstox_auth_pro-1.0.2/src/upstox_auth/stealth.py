"""
Stealth utilities for Playwright to bypass bot detection.
"""

# Realistic User Agent for Chromium on Windows
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
)

# Arguments to disable automation flags and improve resilience
STEALTH_ARGS = [
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--disable-dev-shm-usage",
    "--disable-gpu",
    "--disable-blink-features=AutomationControlled",
    "--no-first-run",
    "--disable-default-apps",
    "--disable-extensions",
    "--mute-audio",
    "--no-zygote",
]

# JavaScript to inject at page initialization to mask webdriver
INIT_SCRIPT = """
Object.defineProperty(navigator, 'webdriver', {
    get: () => undefined
});

// Mock plugins and languages to look more like a real browser
Object.defineProperty(navigator, 'plugins', {
    get: () => [1, 2, 3, 4, 5]
});

Object.defineProperty(navigator, 'languages', {
    get: () => ['en-US', 'en']
});
"""


def get_stealth_config():
    """Returns a dictionary containing common stealth settings."""
    return {
        "user_agent": DEFAULT_USER_AGENT,
        "args": STEALTH_ARGS,
        "init_script": INIT_SCRIPT,
    }
