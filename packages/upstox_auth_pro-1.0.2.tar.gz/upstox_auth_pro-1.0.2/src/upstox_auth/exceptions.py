class UpstoxAuthError(Exception):
    """Base exception for upstox-auth-pro"""

    pass


class LoginTimeoutError(UpstoxAuthError):
    """Raised when the login automation times out"""

    pass


class InvalidCredentialsError(UpstoxAuthError):
    """Raised when provided credentials (PIN, TOTP) are rejected"""

    pass


class StorageError(UpstoxAuthError):
    """Raised when there is an issue reading or writing tokens"""

    pass
