"""
MCP Server - Espone i tool interni di Robot come server MCP.

Permette a client MCP esterni (altre app, Claude Desktop, ecc.)
di scoprire e chiamare i tool di Robot via protocollo MCP su HTTP.

I tool sono registrati dinamicamente da ToolManager._list.
Il client MCP passa l'app_id come parametro per caricare la configurazione
reale dalla CMS (secrets, vector_db, api_settings, ecc.).

Autenticazione via Bearer token standard MCP:
  Authorization: Bearer <token>
"""
import json
import logging
import inspect
import secrets as secrets_module
from mcp.server.fastmcp import FastMCP

from ws_bom_robot_app.config import config
from ws_bom_robot_app.llm.tools.tool_manager import ToolManager
from ws_bom_robot_app.llm.providers.llm_manager import LlmManager, LlmConfig, LlmInterface
from ws_bom_robot_app.llm.models.api import LlmAppTool

logger = logging.getLogger(__name__)

# Tool che non devono essere esposti via MCP
_SKIP_TOOLS = {"proxy_app_chat", "proxy_app_tool", "mcp_tool"}

# Stato globale
_mcp_instance = None
_app_cache: dict = {}  # app_id -> (CmsApp, LlmInterface)


# ---------------------------------------------------------------------------
# Autenticazione Bearer Token
# ---------------------------------------------------------------------------

def _parse_auth_tokens() -> dict[str, str]:
    """
    Parsa i token di autenticazione dal config.
    Formato: "token1:client1,token2:client2"
    Ritorna {token: client_name}.
    """
    tokens = {}
    raw = config.mcp_auth_tokens.strip()
    if not raw:
        return tokens
    for entry in raw.split(","):
        entry = entry.strip()
        if ":" in entry:
            token, client = entry.split(":", 1)
            tokens[token.strip()] = client.strip()
    return tokens


class BearerTokenMiddleware:
    """
    ASGI middleware che valida il Bearer token nell'header Authorization.
    Standard MCP: il client invia "Authorization: Bearer <token>".

    Il middleware lascia passare le richieste OPTIONS (preflight CORS)
    senza autenticazione, poiché il browser non invia token nei preflight.
    """

    def __init__(self, app):
        self.app = app
        self._valid_tokens = _parse_auth_tokens()

    async def __call__(self, scope, receive, send):
        if scope["type"] in ("http", "websocket"):

            if not self._valid_tokens:
                # Nessun token configurato = auth disabilitata
                await self.app(scope, receive, send)
                return

            # Lascia passare OPTIONS (preflight CORS) senza auth
            method = scope.get("method", "")
            if method == "OPTIONS":
                await self.app(scope, receive, send)
                return

            # Estrai l'header Authorization
            headers = dict(scope.get("headers", []))
            auth_header = headers.get(b"authorization", b"").decode()

            if not auth_header.lower().startswith("bearer "):
                await self._send_error(send, 401, "Missing or invalid Authorization header")
                return

            token = auth_header[7:]  # Rimuovi "Bearer "

            if not any(secrets_module.compare_digest(token, valid) for valid in self._valid_tokens):
                await self._send_error(send, 401, "Invalid Bearer token")
                return

        await self.app(scope, receive, send)

    @staticmethod
    async def _send_error(send, status_code: int, message: str):
        body = json.dumps({"error": message}).encode()
        await send({
            "type": "http.response.start",
            "status": status_code,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode()),
                (b"www-authenticate", b'Bearer error="invalid_token"'),
            ],
        })
        await send({
            "type": "http.response.body",
            "body": body,
        })


# ---------------------------------------------------------------------------
# App CMS
# ---------------------------------------------------------------------------

async def _get_app(app_id: str):
    """Carica e inizializza un'app CMS, con cache in memoria."""
    if app_id in _app_cache:
        return _app_cache[app_id]

    try:
        from ws_bom_robot_app.llm.utils.cms import get_app_by_id

        app = await get_app_by_id(app_id)
        if not app:
            logger.error(f"[MCP Server] App '{app_id}' not found in CMS")
            return None, None

        await app.rq.initialize()
        llm = app.rq.get_llm()

        _app_cache[app_id] = (app, llm)
        logger.info(f"[MCP Server] Loaded app '{app.name}' ({app_id})")
        return app, llm

    except Exception as e:
        logger.error(f"[MCP Server] Failed to load app '{app_id}': {e}")
        return None, None


def _get_default_llm() -> LlmInterface:
    """Crea un LlmInterface di default usando OPENAI_API_KEY."""
    return LlmManager._list["openai"](LlmConfig(
        api_key=config.OPENAI_API_KEY,
        model="gpt-4o",
        temperature=0,
    ))


def _get_default_app_tool(tool_name: str) -> LlmAppTool:
    """Crea un LlmAppTool minimale (fallback senza app CMS)."""
    return LlmAppTool(
        name=tool_name,
        type="function",
        function_id=tool_name,
        function_name=tool_name,
        function_description=f"MCP tool: {tool_name}",
        data_source="knowledgebase",
        secrets=[],
    )


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

def create_mcp_server() -> FastMCP:
    """
    Crea e configura il server MCP registrando dinamicamente
    i tool da ToolManager._list.
    """
    mcp = FastMCP(
        name="Robot MCP Server",
        instructions="Robot AI Platform - Tool server MCP. Pass 'app_id' to use a specific CMS app configuration.",
        json_response=True,
        streamable_http_path="/",
    )

    registered = 0
    for tool_name, tool_config in ToolManager._list.items():
        if tool_name in _SKIP_TOOLS:
            continue
        _register_mcp_tool(mcp, tool_name, tool_config)
        registered += 1

    logger.info(f"[MCP Server] Registered {registered} tools")
    return mcp


def _register_mcp_tool(mcp: FastMCP, tool_name: str, tool_config) -> None:
    """Registra un singolo tool MCP che delega a ToolManager."""
    method = tool_config.function
    doc = method.__doc__ or f"Execute {tool_name}"
    model = tool_config.model
    model_fields = model.model_fields if model and hasattr(model, 'model_fields') else {}

    if not model_fields:
        def _make_noop(tn):
            @mcp.tool(name=tn, description=doc.strip())
            async def _handler(app_id: str = "") -> str:
                return await _invoke_tool(tn, app_id=app_id)
            return _handler
        _make_noop(tool_name)
    else:
        _create_dynamic_handler(mcp, tool_name, doc.strip(), model_fields)


def _create_dynamic_handler(mcp: FastMCP, tool_name: str, description: str, model_fields: dict) -> None:
    """
    Crea e registra un handler MCP con app_id + i parametri del modello Pydantic.
    Usa factory functions per catturare tool_name nella closure.
    """
    field_names = list(model_fields.keys())

    if set(field_names) == {"query", "language"}:
        def _make(tn):
            @mcp.tool(name=tn, description=description)
            async def _handler(query: str, language: str = "it", app_id: str = "") -> str:
                return await _invoke_tool(tn, app_id=app_id, query=query, language=language)
        _make(tool_name)

    elif field_names == ["query"]:
        def _make(tn):
            @mcp.tool(name=tn, description=description)
            async def _handler(query: str, app_id: str = "") -> str:
                return await _invoke_tool(tn, app_id=app_id, query=query)
        _make(tool_name)

    elif field_names == ["input"]:
        def _make(tn):
            @mcp.tool(name=tn, description=description)
            async def _handler(input: str, app_id: str = "") -> str:
                return await _invoke_tool(tn, app_id=app_id, input=input)
        _make(tool_name)

    elif set(field_names) == {"email_subject", "body", "to_email"}:
        def _make(tn):
            @mcp.tool(name=tn, description=description)
            async def _handler(email_subject: str, body: str, to_email: str, app_id: str = "") -> str:
                return await _invoke_tool(tn, app_id=app_id, email_subject=email_subject, body=body, to_email=to_email)
        _make(tool_name)

    elif field_names == ["parameters"]:
        def _make(tn):
            @mcp.tool(name=tn, description=description)
            async def _handler(parameters: str = "{}", app_id: str = "") -> str:
                return await _invoke_tool(tn, app_id=app_id, parameters=parameters)
        _make(tool_name)

    else:
        def _make(tn):
            @mcp.tool(name=tn, description=description)
            async def _handler(kwargs_json: str = "{}", app_id: str = "") -> str:
                try:
                    kwargs = json.loads(kwargs_json)
                except json.JSONDecodeError:
                    return f"Error: invalid JSON input for {tn}"
                return await _invoke_tool(tn, app_id=app_id, **kwargs)
        _make(tool_name)


async def _invoke_tool(tool_name: str, app_id: str = "", **kwargs) -> str:
    """
    Invoca un tool di ToolManager.
    Se app_id è fornito, carica la configurazione dall'app CMS.
    """
    try:
        llm = None
        app_tool = None

        if app_id:
            app, app_llm = await _get_app(app_id)
            if app and app_llm:
                app_tool = next(
                    (t for t in app.rq.app_tools
                     if t.is_active and t.function_name == tool_name),
                    None
                )
                if app_tool:
                    llm = app_llm
                    logger.debug(f"[MCP Tool] Using app '{app.name}' config for '{tool_name}'")
                else:
                    logger.warning(f"[MCP Tool] Tool '{tool_name}' not found in app '{app.name}', using default")

        if not llm or not app_tool:
            llm = _get_default_llm()
            app_tool = _get_default_app_tool(tool_name)

        manager = ToolManager(llm=llm, app_tool=app_tool, callbacks=[], queue=None)
        coroutine = manager.get_coroutine()

        # Filtra kwargs per i parametri accettati dal metodo
        sig = inspect.signature(coroutine)
        valid_params = set(sig.parameters.keys()) - {"self"}
        filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_params}

        result = await coroutine(**filtered_kwargs)

        if result is None:
            return "No result"
        elif isinstance(result, (dict, list)):
            return json.dumps(result, ensure_ascii=False, default=str)
        else:
            return str(result)

    except Exception as e:
        logger.error(f"[MCP Tool] Error executing '{tool_name}': {e}")
        return f"Error executing {tool_name}: {str(e)}"


# ---------------------------------------------------------------------------
# Mount
# ---------------------------------------------------------------------------

def mount_mcp_server(app) -> None:
    """
    Monta il server MCP sull'app FastAPI con autenticazione Bearer token.
    """
    global _mcp_instance

    if not config.mcp_server_enabled:
        logger.info("[MCP Server] Disabled (set MCP_SERVER_ENABLED=true to enable)")
        return

    try:
        import contextlib
        from starlette.routing import Mount

        _mcp_instance = create_mcp_server()

        original_lifespan = app.router.lifespan_context

        @contextlib.asynccontextmanager
        async def combined_lifespan(app_instance):
            async with _mcp_instance.session_manager.run():
                if original_lifespan:
                    async with original_lifespan(app_instance) as state:
                        yield state
                else:
                    yield

        app.router.lifespan_context = combined_lifespan

        mcp_app = _mcp_instance.streamable_http_app()

        if config.mcp_auth_tokens:
            mcp_app = BearerTokenMiddleware(mcp_app)
            logger.info("[MCP Server] Bearer token authentication enabled")
        else:
            logger.warning("[MCP Server] No auth tokens configured - server is OPEN")

        app.router.routes.append(
            Mount("/mcp", app=mcp_app)
        )

        logger.info("[MCP Server] Mounted at /mcp")
    except Exception as e:
        logger.error(f"[MCP Server] Failed to mount: {e}")
        import traceback
        traceback.print_exc()
