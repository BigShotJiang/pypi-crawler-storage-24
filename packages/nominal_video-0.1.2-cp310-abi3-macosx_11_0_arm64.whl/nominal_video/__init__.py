import os
import sys

if sys.platform == "win32":
    # Python 3.8+ no longer searches PATH for extension DLLs.
    # Add the GStreamer bin directory explicitly so nominal_video.pyd can load.
    _gst_root = os.environ.get("GSTREAMER_1_0_ROOT_MSVC_X86_64", "")
    if _gst_root:
        _gst_bin = os.path.join(_gst_root.rstrip("\\"), "bin")
        if os.path.isdir(_gst_bin):
            os.add_dll_directory(_gst_bin)

from .nominal_video import *
