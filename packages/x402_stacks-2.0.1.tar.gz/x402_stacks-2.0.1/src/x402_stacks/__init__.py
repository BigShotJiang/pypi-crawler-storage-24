"""x402-stacks — Python SDK for x402 payment protocol on Stacks blockchain.

Default exports are V2 (Coinbase-compatible). V1 (legacy) exports use _v1 suffix.
"""

# ── V2 (Coinbase compatible, default) ────────────────────────────────

# Types V2
from .types_v2 import (
    STACKS_NETWORKS,
    X402_HEADERS,
    X402_ERROR_CODES,
    ResourceInfo,
    PaymentRequirementsV2,
    PaymentRequiredV2,
    StacksPayloadV2,
    PaymentPayloadV2,
    VerifyResponseV2,
    SettlementResponseV2,
    FacilitatorVerifyRequestV2,
    FacilitatorSettleRequestV2,
    SupportedKind,
    SupportedResponse,
)

# Verifier V2
from .verifier_v2 import (
    X402PaymentVerifier,
    VerifyOptions,
    SettleOptions,
    create_verifier,
)

# Interceptor V2 core
from .http.interceptor_v2 import (
    private_key_to_account,
    decode_payment_response,
    decode_payment_required,
    encode_payment_payload,
    sign_payment_v2,
    select_payment_option,
    get_payment_response_from_headers,
)

# ── V1 (Legacy, _v1 suffix) ─────────────────────────────────────────

# Types V1
from .types import (
    NetworkType,
    TokenType,
    TokenContract,
    PaymentStatus,
    X402PaymentRequired,
    PaymentDetails,
    PaymentResult,
    SignedPaymentResult,
    VerifiedPayment,
    VerificationOptions,
    X402MiddlewareConfig,
    StacksTransaction,
    X402ClientConfig,
    FacilitatorVerifyRequest,
    FacilitatorVerifyResponse,
    FacilitatorSettleRequest,
    FacilitatorSettleResponse,
    StacksAccount,
    PaymentResponse,
)

# Client V1
from .client import X402PaymentClient

# Verifier V1
from .verifier import X402PaymentVerifierV1, SettleOptionsV1

# Interceptor V1 core
from .http.interceptor import (
    private_key_to_account_v1,
    decode_x_payment_response,
    encode_x_payment_response,
    sign_payment_for_request,
    is_valid_payment_request,
)

# ── Utilities (shared) ──────────────────────────────────────────────

from .utils import (
    # Currency conversion
    micro_stx_to_stx,
    stx_to_micro_stx,
    sats_to_btc,
    btc_to_sats,
    usdcx_to_micro_usdcx,
    micro_usdcx_to_usdcx,
    # Address
    is_valid_stacks_address,
    get_address_network,
    truncate_address,
    # Network
    get_api_endpoint,
    get_explorer_url,
    get_network_instance,
    # Token
    get_default_sbtc_contract,
    get_default_usdcx_contract,
    get_token_symbol,
    get_token_decimals,
    get_token_smallest_unit,
    # Payment
    format_payment_amount,
    parse_payment_memo,
    create_payment_memo,
    estimate_fee,
    # Timing
    is_payment_request_expired,
    create_expiration_timestamp,
    wait_with_backoff,
    retry_with_backoff,
    # CAIP-2
    network_to_caip2,
    network_from_caip2,
    is_valid_stacks_caip2,
    asset_to_v2,
    asset_from_v2,
    # Keys
    generate_keypair,
)

# ── Transaction builders (re-exported) ──────────────────────────────

from .stacks_tx import (
    build_stx_transfer,
    build_contract_call,
    private_key_to_address,
    private_key_to_public_key,
)

__version__ = "2.0.1"

__all__ = [
    # V2 types
    "STACKS_NETWORKS",
    "X402_HEADERS",
    "X402_ERROR_CODES",
    "ResourceInfo",
    "PaymentRequirementsV2",
    "PaymentRequiredV2",
    "StacksPayloadV2",
    "PaymentPayloadV2",
    "VerifyResponseV2",
    "SettlementResponseV2",
    "FacilitatorVerifyRequestV2",
    "FacilitatorSettleRequestV2",
    "SupportedKind",
    "SupportedResponse",
    # V2 verifier
    "X402PaymentVerifier",
    "VerifyOptions",
    "SettleOptions",
    "create_verifier",
    # V2 interceptor
    "private_key_to_account",
    "decode_payment_response",
    "decode_payment_required",
    "encode_payment_payload",
    "sign_payment_v2",
    "select_payment_option",
    "get_payment_response_from_headers",
    # V1 types
    "NetworkType",
    "TokenType",
    "TokenContract",
    "PaymentStatus",
    "X402PaymentRequired",
    "PaymentDetails",
    "PaymentResult",
    "SignedPaymentResult",
    "VerifiedPayment",
    "VerificationOptions",
    "X402MiddlewareConfig",
    "StacksTransaction",
    "X402ClientConfig",
    "FacilitatorVerifyRequest",
    "FacilitatorVerifyResponse",
    "FacilitatorSettleRequest",
    "FacilitatorSettleResponse",
    "StacksAccount",
    "PaymentResponse",
    # V1 client
    "X402PaymentClient",
    # V1 verifier
    "X402PaymentVerifierV1",
    "SettleOptionsV1",
    # V1 interceptor
    "private_key_to_account_v1",
    "decode_x_payment_response",
    "encode_x_payment_response",
    "sign_payment_for_request",
    "is_valid_payment_request",
    # Utilities
    "micro_stx_to_stx",
    "stx_to_micro_stx",
    "sats_to_btc",
    "btc_to_sats",
    "usdcx_to_micro_usdcx",
    "micro_usdcx_to_usdcx",
    "is_valid_stacks_address",
    "get_address_network",
    "truncate_address",
    "get_api_endpoint",
    "get_explorer_url",
    "get_network_instance",
    "get_default_sbtc_contract",
    "get_default_usdcx_contract",
    "get_token_symbol",
    "get_token_decimals",
    "get_token_smallest_unit",
    "format_payment_amount",
    "parse_payment_memo",
    "create_payment_memo",
    "estimate_fee",
    "is_payment_request_expired",
    "create_expiration_timestamp",
    "wait_with_backoff",
    "retry_with_backoff",
    "network_to_caip2",
    "network_from_caip2",
    "is_valid_stacks_caip2",
    "asset_to_v2",
    "asset_from_v2",
    "generate_keypair",
    # Transaction builders
    "build_stx_transfer",
    "build_contract_call",
    "private_key_to_address",
    "private_key_to_public_key",
    # Version
    "__version__",
]
