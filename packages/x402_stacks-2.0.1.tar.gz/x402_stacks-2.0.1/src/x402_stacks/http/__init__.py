"""HTTP client interceptors and server middleware for x402-stacks."""
