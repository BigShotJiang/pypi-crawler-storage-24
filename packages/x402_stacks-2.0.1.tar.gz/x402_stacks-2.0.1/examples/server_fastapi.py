"""FastAPI server example with x402 payment middleware."""

from fastapi import FastAPI, Request
from x402_stacks.http.middleware_fastapi import (
    PaymentMiddleware,
    PaymentMiddlewareConfig,
    get_payment,
)

app = FastAPI(title="x402 Payment API")

config = PaymentMiddlewareConfig(
    network="testnet",
    amount="1000000",  # 1 STX
    pay_to="ST1PQHQKV0RJXZFY1DGX8MNSNYVE3VGZJSRTPGZGM",
    description="Premium weather data",
    facilitator_url="https://facilitator.stacksx402.com",
)

app.add_middleware(PaymentMiddleware, config=config)


@app.get("/weather")
async def weather(request: Request):
    payment = get_payment(request)
    return {
        "temperature": 72,
        "conditions": "sunny",
        "payment": payment.model_dump(by_alias=True) if payment else None,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
