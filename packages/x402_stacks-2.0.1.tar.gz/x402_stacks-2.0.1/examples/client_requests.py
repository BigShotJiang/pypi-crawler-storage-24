"""requests client example with automatic x402 payment handling."""

from x402_stacks.http.interceptor_v2 import private_key_to_account
from x402_stacks.http.client_requests import create_payment_session

PRIVATE_KEY = "edf9aee84d9b7abc145504dde6726c64f369d37ee34ced614f76c2dcb7004497"


def main():
    account = private_key_to_account(PRIVATE_KEY, "testnet")
    print(f"Account: {account.address}")

    session = create_payment_session(account)
    response = session.get("http://localhost:8000/weather")
    print(f"Status: {response.status_code}")
    print(f"Data: {response.json()}")


if __name__ == "__main__":
    main()
