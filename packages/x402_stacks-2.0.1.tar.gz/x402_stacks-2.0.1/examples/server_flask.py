"""Flask server example with x402 payment middleware."""

from flask import Flask, jsonify
from x402_stacks.http.middleware_flask import (
    PaymentMiddlewareConfig,
    payment_middleware,
    get_payment,
)

app = Flask(__name__)

config = PaymentMiddlewareConfig(
    network="testnet",
    amount="1000000",  # 1 STX
    pay_to="ST1PQHQKV0RJXZFY1DGX8MNSNYVE3VGZJSRTPGZGM",
    description="Premium weather data",
    facilitator_url="https://facilitator.stacksx402.com",
)

app.before_request(payment_middleware(config))


@app.route("/weather")
def weather():
    payment = get_payment()
    return jsonify({
        "temperature": 72,
        "conditions": "sunny",
        "payment": payment.model_dump(by_alias=True) if payment else None,
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
