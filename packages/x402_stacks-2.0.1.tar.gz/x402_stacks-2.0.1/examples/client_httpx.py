"""httpx client example with automatic x402 payment handling."""

import asyncio
from x402_stacks.http.interceptor_v2 import private_key_to_account
from x402_stacks.http.client_httpx import create_payment_client, create_payment_client_sync

PRIVATE_KEY = "edf9aee84d9b7abc145504dde6726c64f369d37ee34ced614f76c2dcb7004497"


async def main_async():
    """Async httpx client example."""
    account = private_key_to_account(PRIVATE_KEY, "testnet")
    print(f"Account: {account.address}")

    async with create_payment_client(account, timeout=60) as client:
        response = await client.get("http://localhost:8000/weather")
        print(f"Status: {response.status_code}")
        print(f"Data: {response.json()}")


def main_sync():
    """Sync httpx client example."""
    account = private_key_to_account(PRIVATE_KEY, "testnet")
    print(f"Account: {account.address}")

    with create_payment_client_sync(account, timeout=60) as client:
        response = client.get("http://localhost:8000/weather")
        print(f"Status: {response.status_code}")
        print(f"Data: {response.json()}")


if __name__ == "__main__":
    main_sync()
