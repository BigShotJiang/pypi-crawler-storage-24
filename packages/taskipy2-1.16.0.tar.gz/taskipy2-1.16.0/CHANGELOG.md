# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.16.0] - 2026-03-19

### Changed

- Python's standard library `tomllib` is now used on Python 3.11+ and `tomli` is
  only installed on < Python 3.11.

### Removed

- `<7` version constraint for `psutil`.

## [1.15.1] - 2026-03-19

### Fixed

- Resolve inadvertent version constraint changes for `mslex` and `colorama`. The
  new version constraint for `colorama` (v0.4.6) was not compatible with all the
  python version we are trying to support (python 3.6).

## [1.15.0] - 2026-03-19

### Changed

- Forked from [taskipy](https://github.com/taskipy/taskipy) as `taskipy2`
