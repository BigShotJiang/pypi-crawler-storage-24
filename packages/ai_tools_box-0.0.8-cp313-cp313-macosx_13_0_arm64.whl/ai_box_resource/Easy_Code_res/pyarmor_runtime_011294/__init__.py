# Pyarmor 9.2.3 (pro), 011294, 2026-01-20T07:16:15.146286
from .pyarmor_runtime import __pyarmor__
