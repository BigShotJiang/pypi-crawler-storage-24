"""
DatagenKit - A local Image Dataset Generator
using smart augmentations and MobileNetV2 filtering.
"""

from datagenkit.pipeline import run_datagen_pipeline

__version__ = "0.1.0"
__all__ = ["run_datagen_pipeline"]
