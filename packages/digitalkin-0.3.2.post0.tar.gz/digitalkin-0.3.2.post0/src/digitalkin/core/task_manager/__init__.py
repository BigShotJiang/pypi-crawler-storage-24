"""Base task manager logic."""
