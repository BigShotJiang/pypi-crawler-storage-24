"""
inkbox/vault/exceptions.py

Re-exports from the canonical ``inkbox.exceptions`` module for
backward compatibility.
"""

from inkbox.exceptions import InkboxAPIError, InkboxError, InkboxVaultKeyError

__all__ = ["InkboxError", "InkboxAPIError", "InkboxVaultKeyError"]
