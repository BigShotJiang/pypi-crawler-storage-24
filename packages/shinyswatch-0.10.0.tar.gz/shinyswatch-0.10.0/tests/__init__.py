"""Unit tests for shinyswatch"""
