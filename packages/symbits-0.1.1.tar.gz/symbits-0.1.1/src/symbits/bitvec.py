"""Symbolic bitvector with three-valued logic (0, 1, unknown)."""

import re


class B:
    """A symbolic bitvector where each bit is known-0, known-1, or unknown.

    Internal representation:
        _ones:  bitmask of bits known to be 1
        _zeros: bitmask of bits known to be 0
        _width: bit width of the value

    Invariant: _ones & _zeros == 0 (no bit can be both 0 and 1).
    A bit where neither is set is unknown.
    """

    __slots__ = ('_ones', '_zeros', '_width')

    def __init__(self, value=0, width=None):
        if isinstance(value, B):
            self._ones = value._ones
            self._zeros = value._zeros
            self._width = value._width
            if width is not None and width != value._width:
                # Re-interpret at new width via zext or truncate
                if width > value._width:
                    result = value.zext(width)
                else:
                    result = value.truncate(width)
                self._ones = result._ones
                self._zeros = result._zeros
                self._width = result._width
            return

        if isinstance(value, str):
            self._parse_string(value, width)
            return

        if isinstance(value, int):
            if value < 0:
                raise ValueError(
                    "Negative integers are ambiguous without a sign convention. "
                    "Use a binary string with explicit bit pattern instead."
                )
            if width is None:
                width = 32
            if width <= 0:
                raise ValueError(f"Width must be positive, got {width}")
            mask = (1 << width) - 1
            if value > mask:
                raise ValueError(
                    f"Value {value:#x} does not fit in {width} bits "
                    f"(max {mask:#x})"
                )
            self._ones = value & mask
            self._zeros = (~value) & mask
            self._width = width
            return

        raise TypeError(
            f"Cannot construct B from {type(value).__name__}. "
            f"Use an int, binary string, or hex string."
        )

    def _parse_string(self, s, width):
        """Parse a binary or hex string into ones/zeros/width."""
        s_stripped = s.replace(' ', '')

        # Hex string
        if s_stripped.startswith('0x') or s_stripped.startswith('0X'):
            self._parse_hex(s_stripped[2:], width)
            return

        # Check if it looks like hex (contains a-f/A-F digits and no 'x'/'?' except as unknown markers)
        # Binary strings only contain 0, 1, x, X, ?
        # If it has hex digits (2-9, a-f) beyond 0/1 and x/?, treat contextually
        is_binary = all(c in '01xX?' for c in s_stripped)

        if is_binary and len(s_stripped) > 0:
            self._parse_binary(s_stripped, width)
            return

        # Try as hex without prefix
        if all(c in '0123456789abcdefABCDEFxX?' for c in s_stripped) and len(s_stripped) > 0:
            self._parse_hex(s_stripped, width)
            return

        raise ValueError(
            f"Cannot parse '{s}' as a bitvector. Use binary (e.g., '0000xxxx') "
            f"or hex (e.g., '0xFFXX00') format."
        )

    def _parse_binary(self, s, width):
        """Parse a binary string like '0000xxxx' or '1xxx0011'."""
        bit_width = len(s)
        if width is None:
            width = bit_width
        elif width < bit_width:
            raise ValueError(
                f"Binary string '{s}' has {bit_width} bits but width={width} "
                f"is too small"
            )

        ones = 0
        zeros = 0
        for ch in s:
            ones <<= 1
            zeros <<= 1
            if ch == '1':
                ones |= 1
            elif ch == '0':
                zeros |= 1
            elif ch in ('x', 'X', '?'):
                pass  # unknown — neither set
            else:
                raise ValueError(f"Invalid character '{ch}' in binary string")

        # If width > bit_width, upper bits are known-zero
        if width > bit_width:
            upper_mask = ((1 << width) - 1) ^ ((1 << bit_width) - 1)
            zeros |= upper_mask

        mask = (1 << width) - 1
        self._ones = ones & mask
        self._zeros = zeros & mask
        self._width = width

    def _parse_hex(self, s, width):
        """Parse a hex string like 'FFXX00' or 'FF??00'."""
        nibble_count = len(s)
        if width is None:
            width = nibble_count * 4
        elif width < nibble_count * 4:
            raise ValueError(
                f"Hex string '{s}' implies {nibble_count * 4} bits but "
                f"width={width} is too small"
            )

        ones = 0
        zeros = 0
        for ch in s:
            ones <<= 4
            zeros <<= 4
            if ch in ('x', 'X', '?'):
                pass  # all 4 bits unknown
            else:
                val = int(ch, 16)
                ones |= val
                zeros |= (~val) & 0xF

        # If width > nibble_count * 4, upper bits are known-zero
        bit_width = nibble_count * 4
        if width > bit_width:
            upper_mask = ((1 << width) - 1) ^ ((1 << bit_width) - 1)
            zeros |= upper_mask

        mask = (1 << width) - 1
        self._ones = ones & mask
        self._zeros = zeros & mask
        self._width = width

    @classmethod
    def _from_raw(cls, ones, zeros, width):
        """Internal constructor with invariant enforcement.

        Checks the invariant BEFORE masking so bugs in operation logic
        are caught rather than silently masked.
        """
        if ones & zeros != 0:
            raise RuntimeError(
                f"Invariant violation: ones & zeros != 0. "
                f"ones={ones:#x}, zeros={zeros:#x}, overlap={ones & zeros:#x}"
            )
        mask = (1 << width) - 1
        obj = object.__new__(cls)
        obj._ones = ones & mask
        obj._zeros = zeros & mask
        obj._width = width
        return obj

    @classmethod
    def unknown(cls, width=32):
        """Create a value where all bits are unknown."""
        if width <= 0:
            raise ValueError(f"Width must be positive, got {width}")
        return cls._from_raw(0, 0, width)

    # --- Properties ---

    @property
    def width(self):
        """Bit width of this value."""
        return self._width

    @property
    def ones(self):
        """Bitmask of bits known to be 1."""
        return self._ones

    @property
    def zeros(self):
        """Bitmask of bits known to be 0."""
        return self._zeros

    @property
    def _mask(self):
        """Bitmask for this width (all bits set)."""
        return (1 << self._width) - 1

    @property
    def _unknown(self):
        """Bitmask of unknown bits."""
        return self._mask & ~(self._ones | self._zeros)

    # --- Display ---

    def __repr__(self):
        hex_str = self.hex()
        bin_str = self._bin_grouped()
        known = self.known_bits()
        return f"{hex_str}  ({bin_str})  [{known}/{self._width} known]"

    def __str__(self):
        return self.__repr__()

    def bin(self):
        """Return binary string with 'x' for unknowns, no prefix or grouping."""
        chars = []
        for i in range(self._width - 1, -1, -1):
            if self._ones & (1 << i):
                chars.append('1')
            elif self._zeros & (1 << i):
                chars.append('0')
            else:
                chars.append('x')
        return ''.join(chars)

    def hex(self):
        """Return hex string with X for unknown nibbles, ? for mixed."""
        # Pad width to multiple of 4 for display
        nibbles = (self._width + 3) // 4
        chars = []
        for i in range(nibbles - 1, -1, -1):
            shift = i * 4
            nibble_ones = (self._ones >> shift) & 0xF
            nibble_zeros = (self._zeros >> shift) & 0xF
            nibble_unknown = (~(nibble_ones | nibble_zeros)) & 0xF

            if nibble_unknown == 0xF:
                chars.append('X')
            elif nibble_unknown == 0:
                chars.append(f'{nibble_ones:x}')
            else:
                chars.append('?')

        return '0x' + ''.join(chars)

    def _bin_grouped(self):
        """Return binary string grouped in nibbles with spaces."""
        raw = self.bin()
        # Pad to multiple of 4
        pad_len = (4 - len(raw) % 4) % 4
        raw = '0' * pad_len + raw
        groups = [raw[i:i+4] for i in range(0, len(raw), 4)]
        return ' '.join(groups)

    # --- Coercion helpers ---

    def _coerce_binary(self, other):
        """Normalize operands for a binary operation.

        Returns (a, b) where both are B instances with the same width.
        The narrower operand is zero-extended.
        """
        if isinstance(other, int):
            if other < 0:
                raise ValueError("Negative integers are ambiguous in symbolic context")
            other = B(other, width=self._width)

        if not isinstance(other, B):
            return NotImplemented

        a, b = self, other
        if a._width != b._width:
            target = max(a._width, b._width)
            if a._width < target:
                a = a.zext(target)
            if b._width < target:
                b = b.zext(target)
        return a, b

    # --- Bitwise operations ---

    def __and__(self, other):
        result = self._coerce_binary(other)
        if result is NotImplemented:
            return NotImplemented
        a, b = result
        # AND truth table:
        # result._ones = a._ones & b._ones (both must be known-1)
        # result._zeros = a._zeros | b._zeros (either known-0 forces 0)
        return B._from_raw(
            ones=a._ones & b._ones,
            zeros=a._zeros | b._zeros,
            width=a._width,
        )

    def __rand__(self, other):
        if isinstance(other, int):
            return B(other, width=self._width) & self
        return NotImplemented

    def __or__(self, other):
        result = self._coerce_binary(other)
        if result is NotImplemented:
            return NotImplemented
        a, b = result
        # OR truth table:
        # result._ones = a._ones | b._ones (either known-1 forces 1)
        # result._zeros = a._zeros & b._zeros (both must be known-0)
        return B._from_raw(
            ones=a._ones | b._ones,
            zeros=a._zeros & b._zeros,
            width=a._width,
        )

    def __ror__(self, other):
        if isinstance(other, int):
            return B(other, width=self._width) | self
        return NotImplemented

    def __xor__(self, other):
        result = self._coerce_binary(other)
        if result is NotImplemented:
            return NotImplemented
        a, b = result
        # XOR truth table:
        # result._ones: bits where exactly one is known-1 and the other known-0
        # result._zeros: bits where both known-same (both 1 or both 0)
        # Any unknown input -> unknown output
        return B._from_raw(
            ones=(a._ones & b._zeros) | (a._zeros & b._ones),
            zeros=(a._ones & b._ones) | (a._zeros & b._zeros),
            width=a._width,
        )

    def __rxor__(self, other):
        if isinstance(other, int):
            return B(other, width=self._width) ^ self
        return NotImplemented

    def __invert__(self):
        # NOT: swap ones and zeros, unknowns stay unknown
        return B._from_raw(
            ones=self._zeros,
            zeros=self._ones,
            width=self._width,
        )

    # --- Shifts ---

    def __lshift__(self, n):
        if isinstance(n, B):
            raise TypeError(
                "Cannot shift by symbolic amount — shift count must be a "
                "concrete integer"
            )
        if not isinstance(n, int):
            return NotImplemented
        if n < 0:
            raise ValueError(f"Shift amount must be non-negative, got {n}")
        if n >= self._width:
            # All bits shifted out — result is all known-zero
            return B(0, width=self._width)
        mask = self._mask
        return B._from_raw(
            ones=(self._ones << n) & mask,
            zeros=((self._zeros << n) | ((1 << n) - 1)) & mask,
            width=self._width,
        )

    def __rshift__(self, n):
        """Logical right shift — top bits become known-0."""
        if isinstance(n, B):
            raise TypeError(
                "Cannot shift by symbolic amount — shift count must be a "
                "concrete integer"
            )
        if not isinstance(n, int):
            return NotImplemented
        if n < 0:
            raise ValueError(f"Shift amount must be non-negative, got {n}")
        if n >= self._width:
            return B(0, width=self._width)
        # Top n bits become known-zero
        top_mask = (((1 << n) - 1) << (self._width - n))
        return B._from_raw(
            ones=self._ones >> n,
            zeros=(self._zeros >> n) | top_mask,
            width=self._width,
        )

    def ashr(self, n):
        """Arithmetic right shift — sign bit fills from top."""
        if isinstance(n, B):
            raise TypeError(
                "Cannot shift by symbolic amount — shift count must be a "
                "concrete integer"
            )
        if not isinstance(n, int):
            raise TypeError(f"Shift amount must be an integer, got {type(n).__name__}")
        if n < 0:
            raise ValueError(f"Shift amount must be non-negative, got {n}")
        if n >= self._width:
            # All bits become copies of sign bit
            sign_one = bool(self._ones & (1 << (self._width - 1)))
            sign_zero = bool(self._zeros & (1 << (self._width - 1)))
            if sign_one:
                return B._from_raw(ones=self._mask, zeros=0, width=self._width)
            elif sign_zero:
                return B(0, width=self._width)
            else:
                return B.unknown(self._width)

        # Shift data bits
        ones = self._ones >> n
        zeros = self._zeros >> n

        # Fill top n bits based on sign bit state
        top_mask = (((1 << n) - 1) << (self._width - n))
        sign_one = bool(self._ones & (1 << (self._width - 1)))
        sign_zero = bool(self._zeros & (1 << (self._width - 1)))

        if sign_one:
            ones |= top_mask
        elif sign_zero:
            zeros |= top_mask
        # else: sign unknown, top bits stay unknown (neither ones nor zeros set)

        return B._from_raw(ones=ones, zeros=zeros, width=self._width)

    # --- Width manipulation ---

    def zext(self, new_width):
        """Zero-extend to new_width. Upper bits become known-0."""
        if new_width < self._width:
            raise ValueError(
                f"Cannot zero-extend from {self._width} to {new_width} bits — "
                f"use truncate() to narrow"
            )
        if new_width == self._width:
            return B._from_raw(self._ones, self._zeros, self._width)
        upper_mask = ((1 << new_width) - 1) ^ ((1 << self._width) - 1)
        return B._from_raw(
            ones=self._ones,
            zeros=self._zeros | upper_mask,
            width=new_width,
        )

    def sext(self, new_width):
        """Sign-extend to new_width. Upper bits copy the sign bit."""
        if new_width < self._width:
            raise ValueError(
                f"Cannot sign-extend from {self._width} to {new_width} bits — "
                f"use truncate() to narrow"
            )
        if new_width == self._width:
            return B._from_raw(self._ones, self._zeros, self._width)

        sign_one = bool(self._ones & (1 << (self._width - 1)))
        sign_zero = bool(self._zeros & (1 << (self._width - 1)))
        upper_mask = ((1 << new_width) - 1) ^ ((1 << self._width) - 1)

        ones = self._ones
        zeros = self._zeros
        if sign_one:
            ones |= upper_mask
        elif sign_zero:
            zeros |= upper_mask
        # else: sign unknown, upper bits stay unknown

        return B._from_raw(ones=ones, zeros=zeros, width=new_width)

    def truncate(self, new_width):
        """Truncate to new_width, keeping only the low bits."""
        if new_width > self._width:
            raise ValueError(
                f"Cannot truncate from {self._width} to {new_width} bits — "
                f"use zext() or sext() to widen"
            )
        if new_width <= 0:
            raise ValueError(f"Width must be positive, got {new_width}")
        mask = (1 << new_width) - 1
        return B._from_raw(
            ones=self._ones & mask,
            zeros=self._zeros & mask,
            width=new_width,
        )

    # --- Bit extraction and inspection ---

    def bit(self, n):
        """Return '0', '1', or 'x' for bit n (0-indexed from LSB)."""
        if n < 0:
            raise ValueError(f"Bit index must be non-negative, got {n}")
        if n >= self._width:
            return '0'  # Out of range bits are implicitly 0
        if self._ones & (1 << n):
            return '1'
        if self._zeros & (1 << n):
            return '0'
        return 'x'

    def bits(self, hi, lo):
        """Extract bits hi:lo (inclusive) as a new B value."""
        if hi < lo:
            raise ValueError(f"hi ({hi}) must be >= lo ({lo})")
        if lo < 0:
            raise ValueError(f"Bit indices must be non-negative")
        new_width = hi - lo + 1
        ones = (self._ones >> lo) & ((1 << new_width) - 1)
        zeros = (self._zeros >> lo) & ((1 << new_width) - 1)
        return B._from_raw(ones=ones, zeros=zeros, width=new_width)

    def __getitem__(self, key):
        """Slice syntax: a[7:0] extracts bits 7 down to 0 (MSB:LSB convention)."""
        if isinstance(key, int):
            # Single bit extraction — return a B of width 1
            return self.bits(key, key)
        if isinstance(key, slice):
            hi = key.start
            lo = key.stop
            if key.step is not None:
                raise ValueError("Step not supported in bit slice")
            if hi is None:
                hi = self._width - 1
            if lo is None:
                lo = 0
            return self.bits(hi, lo)
        raise TypeError(f"Invalid index type: {type(key).__name__}")

    def known_bits(self):
        """Count of bits that are known (either 0 or 1)."""
        return _popcount(self._ones | self._zeros)

    def unknown_bits(self):
        """Count of bits that are unknown."""
        return self._width - self.known_bits()

    def is_fully_known(self):
        """True if all bits are known."""
        return (self._ones | self._zeros) == self._mask

    def is_fully_unknown(self):
        """True if no bits are known."""
        return (self._ones | self._zeros) == 0

    def as_int(self):
        """Return the integer value if fully known, raise if any unknowns."""
        if not self.is_fully_known():
            raise ValueError(
                f"Cannot convert to int: {self.unknown_bits()} bits are unknown. "
                f"Value: {self}"
            )
        return self._ones

    def could_equal(self, val):
        """True if the known bits are compatible with val."""
        if isinstance(val, B):
            if not val.is_fully_known():
                raise ValueError("could_equal argument must be a concrete value")
            val = val._ones
        if not isinstance(val, int):
            raise TypeError(f"could_equal expects an int, got {type(val).__name__}")
        val = val & self._mask
        # Check: all known-1 bits must be 1 in val
        if (val & self._ones) != self._ones:
            return False
        # Check: all known-0 bits must be 0 in val
        if (val & self._zeros) != 0:
            return False
        return True

    def known_ones_mask(self):
        """Bitmask of bits known to be 1."""
        return self._ones

    def known_zeros_mask(self):
        """Bitmask of bits known to be 0."""
        return self._zeros

    def unknown_mask(self):
        """Bitmask of unknown bits."""
        return self._unknown

    # --- Concatenation ---

    def concat(self, *others):
        """Concatenate bitvectors: self is high bits, args are lower bits in order.

        Can also be called as a classmethod: B.concat(hi, lo)
        """
        if not others:
            # Called as B.concat(hi, lo, ...) — self is the class
            raise TypeError("concat requires at least two values")

        parts = [self] + list(others)
        # Build from low to high
        result_ones = 0
        result_zeros = 0
        total_width = 0
        for part in reversed(parts):
            if isinstance(part, int):
                part = B(part)
            if not isinstance(part, B):
                raise TypeError(f"concat expects B values, got {type(part).__name__}")
            result_ones |= part._ones << total_width
            result_zeros |= part._zeros << total_width
            total_width += part._width

        return B._from_raw(result_ones, result_zeros, total_width)

    # --- Comparison ---

    def __eq__(self, other):
        """Structural equality: same width, same known bits, same unknowns."""
        if isinstance(other, int):
            other = B(other, width=self._width)
        if not isinstance(other, B):
            return NotImplemented
        if self._width != other._width:
            return False
        return self._ones == other._ones and self._zeros == other._zeros

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return NotImplemented
        return not result

    def __hash__(self):
        return hash((self._ones, self._zeros, self._width))

    def __bool__(self):
        raise TypeError(
            "Symbolic bitvectors cannot be used as booleans. "
            "A symbolic value may represent multiple concrete values, "
            "so truth/falsity is not well-defined. "
            "Use .is_fully_known(), .could_equal(), or .as_int() instead."
        )

    def is_refinement_of(self, other):
        """True if self knows everything other knows, plus possibly more.

        self is a refinement of other if:
        - Every bit that other knows as 1, self also knows as 1
        - Every bit that other knows as 0, self also knows as 0
        - self may know additional bits that other doesn't
        """
        if isinstance(other, int):
            other = B(other, width=self._width)
        if not isinstance(other, B):
            raise TypeError(f"Expected B, got {type(other).__name__}")
        if self._width != other._width:
            raise ValueError(
                f"Width mismatch: {self._width} vs {other._width}"
            )
        # All of other's known-1 bits must be known-1 in self
        if (other._ones & self._ones) != other._ones:
            return False
        # All of other's known-0 bits must be known-0 in self
        if (other._zeros & self._zeros) != other._zeros:
            return False
        return True


def _popcount(n):
    """Count the number of set bits in a non-negative integer."""
    count = 0
    while n:
        count += 1
        n &= n - 1
    return count


def B8(value=0):
    """Create an 8-bit symbolic bitvector."""
    return B(value, width=8)


def B16(value=0):
    """Create a 16-bit symbolic bitvector."""
    return B(value, width=16)


def B32(value=0):
    """Create a 32-bit symbolic bitvector."""
    return B(value, width=32)


def B64(value=0):
    """Create a 64-bit symbolic bitvector."""
    return B(value, width=64)
