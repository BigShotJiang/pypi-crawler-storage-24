"""Tests for edge cases, algebraic laws, and special behaviors."""

import pytest
from symbits import B, B8, B16, B32
from conftest import random_symbolic


class TestWidth1:
    def test_construct(self):
        b = B(1, width=1)
        assert b.width == 1
        assert b.as_int() == 1

    def test_zero(self):
        b = B(0, width=1)
        assert b.as_int() == 0

    def test_unknown(self):
        b = B.unknown(1)
        assert b.is_fully_unknown()

    def test_and(self):
        a = B(1, width=1)
        b = B(1, width=1)
        r = a & b
        assert r.as_int() == 1

    def test_or(self):
        a = B(0, width=1)
        b = B(1, width=1)
        r = a | b
        assert r.as_int() == 1

    def test_not(self):
        a = B(1, width=1)
        r = ~a
        assert r.as_int() == 0


class TestLargeWidth:
    def test_128bit(self):
        b = B(0, width=128)
        assert b.width == 128
        assert b.is_fully_known()

    def test_256bit(self):
        b = B.unknown(256)
        assert b.width == 256
        assert b.is_fully_unknown()

    def test_128bit_ops(self):
        a = B(0xFF, width=128)
        b = B(0xFF00, width=128)
        r = a | b
        assert r.as_int() == 0xFFFF


class TestInvariant:
    def test_invariant_after_and(self):
        a = B8("1100xxxx")
        b = B8("1010xx00")
        r = a & b
        assert r._ones & r._zeros == 0

    def test_invariant_after_or(self):
        a = B8("1100xxxx")
        b = B8("1010xx00")
        r = a | b
        assert r._ones & r._zeros == 0

    def test_invariant_after_xor(self):
        a = B8("1100xxxx")
        b = B8("1010xx00")
        r = a ^ b
        assert r._ones & r._zeros == 0

    def test_invariant_after_not(self):
        a = B8("1100xxxx")
        r = ~a
        assert r._ones & r._zeros == 0

    def test_invariant_after_shift(self):
        a = B8("1100xxxx")
        r = a << 3
        assert r._ones & r._zeros == 0
        r = a >> 3
        assert r._ones & r._zeros == 0

    def test_invariant_random(self):
        import random
        rng = random.Random(42)
        for _ in range(1000):
            a = random_symbolic(8, rng)
            b = random_symbolic(8, rng)
            for r in [a & b, a | b, a ^ b, ~a, a << 3, a >> 3]:
                assert r._ones & r._zeros == 0


class TestChainedOps:
    def test_chain(self):
        a = B8("11001100")
        b = B8("10101010")
        c = B8("11110000")
        d = B8("00001111")
        r = (a & b) | (c ^ d)
        assert r.is_fully_known()
        expected = (0xCC & 0xAA) | (0xF0 ^ 0x0F)
        assert r.as_int() == expected

    def test_chain_with_unknowns(self):
        a = B8("1100xxxx")
        b = B8("1010xx00")
        c = B8("xxxx1111")
        r = (a & b) | c
        assert r._ones & r._zeros == 0


class TestIdempotence:
    def test_and_idempotent(self):
        a = B8("1100xxxx")
        assert (a & a) == a

    def test_or_idempotent(self):
        a = B8("1100xxxx")
        assert (a | a) == a


class TestIdentityAndAnnihilator:
    def test_and_zero(self):
        a = B8("1100xxxx")
        assert (a & B8(0)) == B8(0)

    def test_or_allones(self):
        a = B8("1100xxxx")
        assert (a | B8(0xFF)) == B8(0xFF)

    def test_xor_zero_identity(self):
        a = B8("1100xxxx")
        assert (a ^ B8(0)) == a


class TestXorSelf:
    def test_xor_self_known(self):
        a = B8(0xAB)
        r = a ^ a
        assert r == B8(0)

    def test_xor_self_unknown(self):
        a = B8("1100xxxx")
        r = a ^ a
        # Known bits cancel to 0, unknown stays unknown
        for i in range(4, 8):
            assert r.bit(i) == '0'
        for i in range(4):
            assert r.bit(i) == 'x'


class TestDeMorgans:
    def test_demorgan_and(self):
        """~(a & b) == ~a | ~b"""
        a = B8("1100xxxx")
        b = B8("1010xx00")
        assert ~(a & b) == (~a | ~b)

    def test_demorgan_or(self):
        """~(a | b) == ~a & ~b"""
        a = B8("1100xxxx")
        b = B8("1010xx00")
        assert ~(a | b) == (~a & ~b)

    def test_demorgan_random(self):
        import random
        rng = random.Random(99)
        for _ in range(100):
            a = random_symbolic(8, rng)
            b = random_symbolic(8, rng)
            assert ~(a & b) == (~a | ~b)
            assert ~(a | b) == (~a & ~b)


class TestHash:
    def test_equal_values_same_hash(self):
        a = B8(0xAB)
        b = B8(0xAB)
        assert hash(a) == hash(b)

    def test_different_values_different_hash(self):
        a = B8(0xAB)
        b = B8(0xCD)
        assert hash(a) != hash(b)

    def test_usable_in_set(self):
        s = {B8(0xAB), B8(0xAB), B8(0xCD)}
        assert len(s) == 2

    def test_usable_as_dict_key(self):
        d = {B8(0xAB): "hello"}
        assert d[B8(0xAB)] == "hello"


class TestBoolRaises:
    def test_bool_raises(self):
        with pytest.raises(TypeError, match="Symbolic"):
            bool(B8(0xFF))

    def test_if_raises(self):
        with pytest.raises(TypeError, match="Symbolic"):
            if B8(0xFF):
                pass


class TestEquality:
    def test_eq_same(self):
        assert B8(0xAB) == B8(0xAB)

    def test_eq_different(self):
        assert not (B8(0xAB) == B8(0xCD))

    def test_ne(self):
        assert B8(0xAB) != B8(0xCD)

    def test_eq_with_int(self):
        assert B8(42) == 42

    def test_eq_unknown_not_equal_to_int(self):
        assert not (B8("xxxx0000") == 0)

    def test_eq_different_width(self):
        assert not (B8(0xFF) == B16(0xFF))

    def test_eq_structural(self):
        a = B8("1100xxxx")
        b = B8("1100xxxx")
        assert a == b


class TestRefinement:
    def test_self_is_refinement(self):
        a = B8("1100xxxx")
        assert a.is_refinement_of(a)

    def test_more_known_is_refinement(self):
        a = B8("11000000")  # fully known
        b = B8("1100xxxx")  # partially known
        assert a.is_refinement_of(b)

    def test_less_known_is_not_refinement(self):
        a = B8("1100xxxx")
        b = B8("11000000")
        assert not a.is_refinement_of(b)

    def test_conflicting_is_not_refinement(self):
        a = B8("11000000")
        b = B8("0000xxxx")
        assert not a.is_refinement_of(b)

    def test_unknown_refines_unknown(self):
        a = B.unknown(8)
        b = B.unknown(8)
        assert a.is_refinement_of(b)

    def test_width_mismatch_raises(self):
        with pytest.raises(ValueError, match="Width"):
            B8(0xFF).is_refinement_of(B16(0xFF))
