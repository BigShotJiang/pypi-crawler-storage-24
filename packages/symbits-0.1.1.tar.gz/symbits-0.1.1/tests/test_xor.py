"""Tests for XOR operation."""

import random
import pytest
from symbits import B, B8
from conftest import random_symbolic, concrete_values_for


class TestXorTruthTable:
    def test_0_xor_0(self):
        r = B8(0) ^ B8(0)
        assert r == B8(0)

    def test_0_xor_1(self):
        r = B8("00000000") ^ B8("11111111")
        assert r == B8(0xFF)

    def test_0_xor_x(self):
        r = B8("00000000") ^ B8("xxxxxxxx")
        assert r.is_fully_unknown()

    def test_1_xor_0(self):
        r = B8("11111111") ^ B8("00000000")
        assert r == B8(0xFF)

    def test_1_xor_1(self):
        r = B8(0xFF) ^ B8(0xFF)
        assert r == B8(0)

    def test_1_xor_x(self):
        r = B8("11111111") ^ B8("xxxxxxxx")
        assert r.is_fully_unknown()

    def test_x_xor_0(self):
        r = B8("xxxxxxxx") ^ B8("00000000")
        assert r.is_fully_unknown()

    def test_x_xor_1(self):
        r = B8("xxxxxxxx") ^ B8("11111111")
        assert r.is_fully_unknown()

    def test_x_xor_x(self):
        r = B8("xxxxxxxx") ^ B8("xxxxxxxx")
        assert r.is_fully_unknown()


class TestXorProperties:
    def test_commutativity(self):
        a = B8("1100xxxx")
        b = B8("1010xx00")
        assert (a ^ b) == (b ^ a)

    def test_identity(self):
        a = B8("1100xxxx")
        r = a ^ B8(0)
        assert r == a

    def test_self_xor_known(self):
        """XOR with self: known bits become 0."""
        a = B8(0xAB)
        r = a ^ a
        assert r == B8(0)

    def test_self_xor_unknown(self):
        """XOR with self: unknown bits stay unknown (conservative)."""
        a = B8("1100xxxx")
        r = a ^ a
        # Known bits (1100 in upper nibble) XOR themselves = 0000
        # Unknown bits (xxxx in lower nibble) XOR themselves = xxxx (conservative)
        assert r.bit(7) == '0'
        assert r.bit(6) == '0'
        assert r.bit(5) == '0'
        assert r.bit(4) == '0'
        assert r.bit(3) == 'x'
        assert r.bit(2) == 'x'
        assert r.bit(1) == 'x'
        assert r.bit(0) == 'x'

    def test_reverse_operator(self):
        a = B8("11001100")
        r = 0xFF ^ a
        assert r == B8(0xFF ^ 0xCC)

    def test_known_xor_known(self):
        a = B8(0xAB)
        b = B8(0xCD)
        r = a ^ b
        assert r == B8(0xAB ^ 0xCD)


class TestXorFuzz:
    def test_concrete_fuzz(self):
        rng = random.Random(42)
        for _ in range(1000):
            a = rng.randint(0, 0xFF)
            b = rng.randint(0, 0xFF)
            result = B8(a) ^ B8(b)
            assert result.could_equal(a ^ b)
            assert result.as_int() == (a ^ b)

    def test_symbolic_fuzz(self):
        rng = random.Random(789)
        for _ in range(100):
            sa = random_symbolic(8, rng)
            sb = random_symbolic(8, rng)
            result = sa ^ sb
            for va in concrete_values_for(sa, 16):
                for vb in concrete_values_for(sb, 16):
                    assert result.could_equal(va ^ vb)
