"""Tests for bit extraction and inspection methods."""

import pytest
from symbits import B, B8, B32


class TestBit:
    def test_known_one(self):
        assert B8(0x01).bit(0) == '1'

    def test_known_zero(self):
        assert B8(0x01).bit(1) == '0'

    def test_unknown(self):
        assert B8("xxxxxxxx").bit(3) == 'x'

    def test_out_of_range(self):
        assert B8(0xFF).bit(8) == '0'
        assert B8(0xFF).bit(100) == '0'

    def test_negative_raises(self):
        with pytest.raises(ValueError, match="non-negative"):
            B8(0xFF).bit(-1)


class TestBits:
    def test_extract_nibble(self):
        a = B8(0xAB)  # 10101011
        r = a.bits(7, 4)
        assert r.width == 4
        assert r.as_int() == 0xA

    def test_extract_low_nibble(self):
        a = B8(0xAB)
        r = a.bits(3, 0)
        assert r.width == 4
        assert r.as_int() == 0xB

    def test_extract_single_bit(self):
        a = B8(0x80)
        r = a.bits(7, 7)
        assert r.width == 1
        assert r.as_int() == 1

    def test_extract_preserves_unknowns(self):
        a = B8("1100xxxx")
        r = a.bits(3, 0)
        assert r.width == 4
        assert r.is_fully_unknown()

    def test_hi_lt_lo_raises(self):
        with pytest.raises(ValueError, match=">="):
            B8(0xFF).bits(2, 5)

    def test_negative_raises(self):
        with pytest.raises(ValueError, match="non-negative"):
            B8(0xFF).bits(3, -1)


class TestSlice:
    def test_slice_7_0(self):
        a = B8(0xAB)
        r = a[7:0]
        assert r.width == 8
        assert r.as_int() == 0xAB

    def test_slice_3_0(self):
        a = B8(0xAB)
        r = a[3:0]
        assert r.width == 4
        assert r.as_int() == 0xB

    def test_slice_7_4(self):
        a = B8(0xAB)
        r = a[7:4]
        assert r.width == 4
        assert r.as_int() == 0xA

    def test_single_bit_index(self):
        a = B8(0x80)
        r = a[7]
        assert r.width == 1
        assert r.as_int() == 1

    def test_step_raises(self):
        with pytest.raises(ValueError, match="Step"):
            B8(0xFF)[7:0:2]

    def test_slice_stop_zero(self):
        """Critical: slice.stop=0 is falsy, must use 'is None' check."""
        a = B8(0xAB)
        r = a[7:0]
        assert r.width == 8

    def test_open_start(self):
        a = B8(0xAB)
        r = a[:0]
        assert r.width == 8
        assert r.as_int() == 0xAB

    def test_open_stop(self):
        a = B8(0xAB)
        r = a[7:]
        assert r.width == 8
        assert r.as_int() == 0xAB


class TestKnownBits:
    def test_fully_known(self):
        assert B8(0xFF).known_bits() == 8

    def test_fully_unknown(self):
        assert B.unknown(8).known_bits() == 0

    def test_partial(self):
        assert B8("1100xxxx").known_bits() == 4

    def test_unknown_bits(self):
        assert B8("1100xxxx").unknown_bits() == 4

    def test_is_fully_known(self):
        assert B8(0xFF).is_fully_known()
        assert not B8("1100xxxx").is_fully_known()

    def test_is_fully_unknown(self):
        assert B.unknown(8).is_fully_unknown()
        assert not B8("1100xxxx").is_fully_unknown()


class TestAsInt:
    def test_known(self):
        assert B8(0xAB).as_int() == 0xAB

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="unknown"):
            B8("1100xxxx").as_int()

    def test_zero(self):
        assert B8(0).as_int() == 0


class TestCouldEqual:
    def test_compatible(self):
        a = B8("1100xxxx")
        assert a.could_equal(0xC0)  # 11000000
        assert a.could_equal(0xCF)  # 11001111

    def test_incompatible(self):
        a = B8("1100xxxx")
        assert not a.could_equal(0x00)  # upper bits wrong
        assert not a.could_equal(0xFF)  # bit 5 wrong

    def test_fully_known(self):
        a = B8(0xAB)
        assert a.could_equal(0xAB)
        assert not a.could_equal(0xAC)

    def test_fully_unknown(self):
        a = B.unknown(8)
        for v in range(256):
            assert a.could_equal(v)

    def test_with_b_value(self):
        a = B8("1100xxxx")
        assert a.could_equal(B8(0xC5))

    def test_masks_to_width(self):
        a = B8(0xFF)
        assert a.could_equal(0x1FF)  # upper bits masked off


class TestMaskAccessors:
    def test_known_ones_mask(self):
        a = B8("1100xxxx")
        assert a.known_ones_mask() == 0xC0

    def test_known_zeros_mask(self):
        a = B8("1100xxxx")
        assert a.known_zeros_mask() == 0x30

    def test_unknown_mask(self):
        a = B8("1100xxxx")
        assert a.unknown_mask() == 0x0F
