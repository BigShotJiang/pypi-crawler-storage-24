"""Tests for mixed-width operations, sext, zext, truncate."""

import pytest
from symbits import B, B8, B16, B32, B64


class TestWidthPromotion:
    def test_b32_and_b64(self):
        a = B32(0xFF)
        b = B64(0xFF)
        r = a & b
        assert r.width == 64

    def test_b8_and_b32(self):
        a = B8(0xFF)
        b = B32(0xFF)
        r = a & b
        assert r.width == 32
        assert r == B32(0xFF)

    def test_b8_or_b32(self):
        a = B8(0xFF)
        b = B32(0)
        r = a | b
        assert r.width == 32
        assert r == B32(0xFF)

    def test_b8_xor_b16(self):
        a = B8(0xAA)
        b = B16(0x00FF)
        r = a ^ b
        assert r.width == 16
        assert r == B16(0xAA ^ 0x00FF)

    def test_narrow_zero_extended(self):
        """Narrower operand is zero-extended: upper bits are known-0."""
        a = B8("xxxxxxxx")
        b = B32(0xFFFFFFFF)
        r = a & b
        assert r.width == 32
        # Upper 24 bits should be known-0 (from zero-extending a)
        for i in range(8, 32):
            assert r.bit(i) == '0'
        # Lower 8 bits should be unknown (x & 1 = x)
        for i in range(8):
            assert r.bit(i) == 'x'

    def test_mixed_preserves_unknowns(self):
        a = B8("xxxx0000")
        b = B16("00000000xxxxxxxx")
        r = a | b
        assert r.width == 16


class TestZext:
    def test_zext_8_to_32(self):
        a = B8(0xFF)
        r = a.zext(32)
        assert r.width == 32
        assert r._ones == 0xFF
        # Upper bits known-zero
        for i in range(8, 32):
            assert r.bit(i) == '0'

    def test_zext_same_width(self):
        a = B8(0xFF)
        r = a.zext(8)
        assert r == a

    def test_zext_narrow_raises(self):
        with pytest.raises(ValueError, match="truncate"):
            B32(0xFF).zext(8)

    def test_zext_preserves_unknowns(self):
        a = B8("xxxx0000")
        r = a.zext(16)
        assert r.width == 16
        for i in range(4):
            assert r.bit(i) == '0'
        for i in range(4, 8):
            assert r.bit(i) == 'x'
        for i in range(8, 16):
            assert r.bit(i) == '0'


class TestSext:
    def test_sext_sign_one(self):
        a = B8("10000000")
        r = a.sext(32)
        assert r.width == 32
        # Upper bits filled with 1
        for i in range(8, 32):
            assert r.bit(i) == '1'
        assert r.bit(7) == '1'
        for i in range(7):
            assert r.bit(i) == '0'

    def test_sext_sign_zero(self):
        a = B8("01111111")
        r = a.sext(32)
        assert r.width == 32
        for i in range(8, 32):
            assert r.bit(i) == '0'

    def test_sext_sign_unknown(self):
        a = B8("x0000000")
        r = a.sext(32)
        assert r.width == 32
        # Sign bit unknown, so upper bits unknown
        for i in range(8, 32):
            assert r.bit(i) == 'x'

    def test_sext_same_width(self):
        a = B8(0xFF)
        r = a.sext(8)
        assert r == a

    def test_sext_narrow_raises(self):
        with pytest.raises(ValueError, match="truncate"):
            B32(0xFF).sext(8)

    def test_sext_mixed(self):
        a = B8("1xxx0011")
        r = a.sext(16)
        assert r.width == 16
        # Sign bit is 1, upper 8 bits filled with 1
        for i in range(8, 16):
            assert r.bit(i) == '1'


class TestTruncate:
    def test_truncate_32_to_8(self):
        a = B32(0xDEADBEEF)
        r = a.truncate(8)
        assert r.width == 8
        assert r.as_int() == 0xEF

    def test_truncate_preserves_low_bits(self):
        a = B32("xxxx0000xxxx000011110000xxxx1111")
        r = a.truncate(8)
        assert r.width == 8

    def test_truncate_wider_raises(self):
        with pytest.raises(ValueError, match="widen"):
            B8(0xFF).truncate(16)

    def test_truncate_zero_width_raises(self):
        with pytest.raises(ValueError, match="positive"):
            B8(0xFF).truncate(0)

    def test_truncate_same_width(self):
        a = B8(0xFF)
        r = a.truncate(8)
        # Same width → no change
        assert r.width == 8
        assert r._ones == a._ones


class TestMixedWidthOperations:
    def test_chain_mixed(self):
        a = B8(0xFF)
        b = B16(0x00FF)
        c = B32(0x0000FFFF)
        r = (a & b) | c
        assert r.width == 32
