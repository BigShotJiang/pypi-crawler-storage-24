"""Tests for AND operation."""

import random
import pytest
from symbits import B, B8
from conftest import random_symbolic, concrete_values_for


class TestAndTruthTable:
    """Verify every row of the AND truth table."""

    def test_0_and_0(self):
        a = B8("00000000")
        b = B8("00000000")
        r = a & b
        assert r.bit(0) == '0'

    def test_0_and_1(self):
        a = B("00000000")
        b = B("11111111")
        r = a & b
        assert r == B(0, width=8)

    def test_0_and_x(self):
        a = B8("00000000")
        b = B8("xxxxxxxx")
        r = a & b
        # 0 AND anything = 0
        assert r == B8(0)

    def test_1_and_0(self):
        a = B8("11111111")
        b = B8("00000000")
        r = a & b
        assert r == B8(0)

    def test_1_and_1(self):
        a = B8("11111111")
        b = B8("11111111")
        r = a & b
        assert r == B8(0xFF)

    def test_1_and_x(self):
        a = B8("11111111")
        b = B8("xxxxxxxx")
        r = a & b
        assert r.is_fully_unknown()

    def test_x_and_0(self):
        a = B8("xxxxxxxx")
        b = B8("00000000")
        r = a & b
        assert r == B8(0)

    def test_x_and_1(self):
        a = B8("xxxxxxxx")
        b = B8("11111111")
        r = a & b
        assert r.is_fully_unknown()

    def test_x_and_x(self):
        a = B8("xxxxxxxx")
        b = B8("xxxxxxxx")
        r = a & b
        assert r.is_fully_unknown()


class TestAndProperties:
    def test_commutativity(self):
        a = B8("1100xxxx")
        b = B8("1010xx00")
        assert a & b == b & a

    def test_identity(self):
        a = B8("1100xxxx")
        r = a & B8(0xFF)
        assert r == a

    def test_annihilator(self):
        a = B8("1100xxxx")
        r = a & B8(0)
        assert r == B8(0)

    def test_idempotent(self):
        a = B8("1100xxxx")
        assert (a & a) == a

    def test_reverse_operator(self):
        a = B8("1100xxxx")
        r = 0xFF & a
        assert r == a

    def test_reverse_operator_zero(self):
        a = B8("1100xxxx")
        r = 0x00 & a
        assert r == B8(0)

    def test_known_and_known(self):
        a = B8(0xAB)
        b = B8(0xCD)
        r = a & b
        assert r == B8(0xAB & 0xCD)

    def test_partial_unknowns(self):
        a = B8("11xx0000")
        b = B8("1x1x0000")
        r = a & b
        # bit7: 1&1=1, bit6: 1&x=x, bit5: x&1=x, bit4: x&x=x
        assert r.bit(7) == '1'
        assert r.bit(6) == 'x'
        assert r.bit(5) == 'x'
        assert r.bit(4) == 'x'
        assert r.bit(3) == '0'
        assert r.bit(0) == '0'


class TestAndFuzz:
    def test_concrete_fuzz(self):
        """For 1000 random concrete pairs, verify B(a) & B(b) could_equal(a & b)."""
        rng = random.Random(42)
        for _ in range(1000):
            a = rng.randint(0, 0xFF)
            b = rng.randint(0, 0xFF)
            result = B8(a) & B8(b)
            assert result.could_equal(a & b)
            assert result.as_int() == (a & b)

    def test_symbolic_fuzz(self):
        """Generate random symbolic values, verify concrete results are compatible."""
        rng = random.Random(123)
        for _ in range(100):
            sa = random_symbolic(8, rng)
            sb = random_symbolic(8, rng)
            result = sa & sb
            for va in concrete_values_for(sa, 16):
                for vb in concrete_values_for(sb, 16):
                    assert result.could_equal(va & vb), (
                        f"{sa} & {sb} = {result}, but doesn't match "
                        f"{va:#x} & {vb:#x} = {va & vb:#x}"
                    )
