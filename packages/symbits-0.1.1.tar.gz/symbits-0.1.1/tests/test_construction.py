"""Tests for B construction from various input formats."""

import pytest
from symbits import B, B8, B16, B32, B64


class TestIntegerConstruction:
    def test_zero(self):
        b = B(0)
        assert b.width == 32
        assert b._ones == 0
        assert b._zeros == 0xFFFFFFFF

    def test_positive(self):
        b = B(0x42)
        assert b._ones == 0x42
        assert b._zeros == ~0x42 & 0xFFFFFFFF

    def test_max_32bit(self):
        b = B(0xFFFFFFFF)
        assert b._ones == 0xFFFFFFFF
        assert b._zeros == 0

    def test_explicit_width(self):
        b = B(0x42, width=64)
        assert b.width == 64
        assert b._ones == 0x42
        mask64 = (1 << 64) - 1
        assert b._zeros == ~0x42 & mask64

    def test_width_8(self):
        b = B(0xFF, width=8)
        assert b.width == 8
        assert b._ones == 0xFF
        assert b._zeros == 0

    def test_negative_raises(self):
        with pytest.raises(ValueError, match="Negative"):
            B(-1)

    def test_overflow_raises(self):
        with pytest.raises(ValueError, match="does not fit"):
            B(0x100, width=8)

    def test_zero_width_raises(self):
        with pytest.raises(ValueError, match="positive"):
            B(0, width=0)

    def test_negative_width_raises(self):
        with pytest.raises(ValueError, match="positive"):
            B(0, width=-1)


class TestBinaryStringConstruction:
    def test_all_zeros(self):
        b = B("00000000")
        assert b.width == 8
        assert b._ones == 0
        assert b._zeros == 0xFF

    def test_all_ones(self):
        b = B("11111111")
        assert b.width == 8
        assert b._ones == 0xFF
        assert b._zeros == 0

    def test_all_unknown(self):
        b = B("xxxxxxxx")
        assert b.width == 8
        assert b._ones == 0
        assert b._zeros == 0

    def test_mixed(self):
        b = B("0000xxxx")
        assert b.width == 8
        assert b._ones == 0
        assert b._zeros == 0xF0  # upper nibble known-zero

    def test_with_spaces(self):
        b = B("0000 xxxx")
        assert b.width == 8
        assert b._ones == 0
        assert b._zeros == 0xF0

    def test_question_marks(self):
        b = B("0000????")
        assert b.width == 8
        assert b._ones == 0
        assert b._zeros == 0xF0

    def test_capital_x(self):
        b = B("0000XXXX")
        assert b.width == 8
        assert b._ones == 0
        assert b._zeros == 0xF0

    def test_shorter_than_width(self):
        b = B("1010", width=8)
        assert b.width == 8
        assert b._ones == 0x0A  # 1010 = 10
        # Upper 4 bits should be known-zero
        assert b._zeros & 0xF0 == 0xF0

    def test_explicit_width_too_small_raises(self):
        with pytest.raises(ValueError, match="too small"):
            B("00001111", width=4)

    def test_complex_pattern(self):
        b = B("1xxx0011")
        assert b.width == 8
        assert b.bit(0) == '1'
        assert b.bit(1) == '1'
        assert b.bit(2) == '0'
        assert b.bit(3) == '0'
        assert b.bit(4) == 'x'
        assert b.bit(5) == 'x'
        assert b.bit(6) == 'x'
        assert b.bit(7) == '1'

    def test_16bit_with_spaces(self):
        b = B("1xxx xxxx xxxx xxxx")
        assert b.width == 16
        assert b.bit(15) == '1'
        for i in range(15):
            assert b.bit(i) == 'x'


class TestHexStringConstruction:
    def test_known_hex(self):
        b = B("0xFF")
        assert b.width == 8
        assert b._ones == 0xFF
        assert b._zeros == 0

    def test_hex_with_unknowns(self):
        b = B("0xFFXX00")
        assert b.width == 24
        # FF = upper byte known
        assert b._ones & 0xFF0000 == 0xFF0000
        # XX = middle byte unknown
        assert b._ones & 0x00FF00 == 0
        assert b._zeros & 0x00FF00 == 0
        # 00 = lower byte known-zero
        assert b._zeros & 0x0000FF == 0xFF

    def test_hex_with_question_marks(self):
        b = B("0xFF??00")
        assert b.width == 24
        assert b._ones & 0xFF0000 == 0xFF0000
        assert b._ones & 0x00FF00 == 0
        assert b._zeros & 0x00FF00 == 0

    def test_hex_without_prefix(self):
        b = B("FF")
        assert b.width == 8
        assert b._ones == 0xFF

    def test_hex_explicit_width(self):
        b = B("0xFF", width=32)
        assert b.width == 32
        assert b._ones == 0xFF
        # Upper 24 bits should be known-zero
        assert b._zeros & 0xFFFFFF00 == 0xFFFFFF00

    def test_hex_width_too_small_raises(self):
        with pytest.raises(ValueError, match="too small"):
            B("0xFFFF", width=8)


class TestConvenienceConstructors:
    def test_b8(self):
        b = B8(0x42)
        assert b.width == 8

    def test_b16(self):
        b = B16(0x42)
        assert b.width == 16

    def test_b32(self):
        b = B32(0x42)
        assert b.width == 32

    def test_b64(self):
        b = B64(0x42)
        assert b.width == 64

    def test_b8_string(self):
        b = B8("0000xxxx")
        assert b.width == 8

    def test_b16_overflow_raises(self):
        with pytest.raises(ValueError):
            B16(0x10000)

    def test_b8_default(self):
        b = B8()
        assert b.width == 8
        assert b._ones == 0


class TestUnknown:
    def test_unknown_32(self):
        b = B.unknown(32)
        assert b.width == 32
        assert b._ones == 0
        assert b._zeros == 0
        assert b.is_fully_unknown()

    def test_unknown_64(self):
        b = B.unknown(64)
        assert b.width == 64
        assert b.is_fully_unknown()

    def test_unknown_8(self):
        b = B.unknown(8)
        assert b.width == 8
        assert b.is_fully_unknown()

    def test_unknown_zero_width_raises(self):
        with pytest.raises(ValueError, match="positive"):
            B.unknown(0)


class TestInvalidInputs:
    def test_bad_type(self):
        with pytest.raises(TypeError, match="Cannot construct"):
            B([1, 2, 3])

    def test_bad_type_float(self):
        with pytest.raises(TypeError, match="Cannot construct"):
            B(3.14)

    def test_empty_string(self):
        with pytest.raises(ValueError):
            B("")

    def test_bad_binary_char(self):
        with pytest.raises(ValueError):
            B("0000ghij")  # g-j are not valid hex or binary


class TestCopyConstruction:
    def test_copy_b(self):
        a = B("0000xxxx")
        b = B(a)
        assert b == a
        assert b is not a

    def test_copy_with_new_width(self):
        a = B8(0xFF)
        b = B(a, width=16)
        assert b.width == 16
        assert b._ones == 0xFF
