"""Tests for OR operation."""

import random
import pytest
from symbits import B, B8
from conftest import random_symbolic, concrete_values_for


class TestOrTruthTable:
    def test_0_or_0(self):
        r = B8(0) | B8(0)
        assert r == B8(0)

    def test_0_or_1(self):
        r = B8("00000000") | B8("11111111")
        assert r == B8(0xFF)

    def test_0_or_x(self):
        r = B8("00000000") | B8("xxxxxxxx")
        assert r.is_fully_unknown()

    def test_1_or_0(self):
        r = B8("11111111") | B8("00000000")
        assert r == B8(0xFF)

    def test_1_or_1(self):
        r = B8(0xFF) | B8(0xFF)
        assert r == B8(0xFF)

    def test_1_or_x(self):
        r = B8("11111111") | B8("xxxxxxxx")
        # 1 OR anything = 1
        assert r == B8(0xFF)

    def test_x_or_0(self):
        r = B8("xxxxxxxx") | B8("00000000")
        assert r.is_fully_unknown()

    def test_x_or_1(self):
        r = B8("xxxxxxxx") | B8("11111111")
        assert r == B8(0xFF)

    def test_x_or_x(self):
        r = B8("xxxxxxxx") | B8("xxxxxxxx")
        assert r.is_fully_unknown()


class TestOrProperties:
    def test_commutativity(self):
        a = B8("1100xxxx")
        b = B8("1010xx00")
        assert (a | b) == (b | a)

    def test_identity(self):
        a = B8("1100xxxx")
        r = a | B8(0)
        assert r == a

    def test_annihilator(self):
        a = B8("1100xxxx")
        r = a | B8(0xFF)
        assert r == B8(0xFF)

    def test_idempotent(self):
        a = B8("1100xxxx")
        assert (a | a) == a

    def test_reverse_operator(self):
        a = B8("1100xxxx")
        r = 0x00 | a
        assert r == a

    def test_reverse_operator_allones(self):
        a = B8("1100xxxx")
        r = 0xFF | a
        assert r == B8(0xFF)

    def test_known_or_known(self):
        a = B8(0xAB)
        b = B8(0xCD)
        r = a | b
        assert r == B8(0xAB | 0xCD)

    def test_partial_unknowns(self):
        a = B8("11xx0000")
        b = B8("1x1x0000")
        r = a | b
        assert r.bit(7) == '1'  # 1|1 = 1
        assert r.bit(6) == '1'  # 1|x = 1 (known-1 OR anything = 1)
        assert r.bit(5) == '1'  # x|1 = 1
        assert r.bit(4) == 'x'  # x|x = x
        assert r.bit(3) == '0'


class TestOrFuzz:
    def test_concrete_fuzz(self):
        rng = random.Random(42)
        for _ in range(1000):
            a = rng.randint(0, 0xFF)
            b = rng.randint(0, 0xFF)
            result = B8(a) | B8(b)
            assert result.could_equal(a | b)
            assert result.as_int() == (a | b)

    def test_symbolic_fuzz(self):
        rng = random.Random(456)
        for _ in range(100):
            sa = random_symbolic(8, rng)
            sb = random_symbolic(8, rng)
            result = sa | sb
            for va in concrete_values_for(sa, 16):
                for vb in concrete_values_for(sb, 16):
                    assert result.could_equal(va | vb)
