"""Tests for NOT (bitwise invert) operation."""

import pytest
from symbits import B, B8


class TestNotBasic:
    def test_not_all_ones(self):
        r = ~B8(0xFF)
        assert r == B8(0)

    def test_not_all_zeros(self):
        r = ~B8(0)
        assert r == B8(0xFF)

    def test_not_pattern(self):
        r = ~B8(0xAA)
        assert r == B8(0x55)

    def test_not_agrees_with_python(self):
        for val in range(256):
            r = ~B8(val)
            assert r.as_int() == (~val & 0xFF)


class TestNotUnknowns:
    def test_not_all_unknown(self):
        r = ~B.unknown(8)
        assert r.is_fully_unknown()

    def test_not_mixed(self):
        a = B8("1100xxxx")
        r = ~a
        assert r.bit(7) == '0'
        assert r.bit(6) == '0'
        assert r.bit(5) == '1'
        assert r.bit(4) == '1'
        assert r.bit(3) == 'x'
        assert r.bit(2) == 'x'
        assert r.bit(1) == 'x'
        assert r.bit(0) == 'x'


class TestNotIdentity:
    def test_double_not(self):
        a = B8("1100xxxx")
        assert ~~a == a

    def test_double_not_known(self):
        a = B8(0xAB)
        assert ~~a == a

    def test_double_not_unknown(self):
        a = B.unknown(8)
        assert ~~a == a

    def test_double_not_32bit(self):
        a = B("0xFFXX0000")
        assert ~~a == a
