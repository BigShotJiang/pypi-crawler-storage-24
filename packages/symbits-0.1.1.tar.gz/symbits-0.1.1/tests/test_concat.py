"""Tests for concatenation operations."""

import pytest
from symbits import B, B8, B16, B32, B64


class TestConcatStatic:
    def test_two_known(self):
        hi = B32(0x0000FFFF)
        lo = B32(0xFFFF0000)
        r = B.concat(hi, lo)
        assert r.width == 64
        assert r.as_int() == 0x0000FFFFFFFF0000

    def test_two_known_simple(self):
        hi = B8(0xFF)
        lo = B8(0x00)
        r = B.concat(hi, lo)
        assert r.width == 16
        assert r.as_int() == 0xFF00

    def test_three_parts(self):
        a = B8(0xAA)
        b = B8(0xBB)
        c = B8(0xCC)
        r = B.concat(a, b, c)
        assert r.width == 24
        assert r.as_int() == 0xAABBCC


class TestConcatInstance:
    def test_instance_method(self):
        hi = B8(0xFF)
        lo = B8(0x00)
        r = hi.concat(lo)
        assert r.width == 16
        assert r.as_int() == 0xFF00

    def test_matches_static(self):
        hi = B8(0xAA)
        lo = B8(0xBB)
        assert hi.concat(lo) == B.concat(hi, lo)


class TestConcatWithUnknowns:
    def test_known_hi_unknown_lo(self):
        hi = B32(0x0000FFFF)
        lo = B32("0xXXXX0000")
        r = hi.concat(lo)
        assert r.width == 64
        # Upper 32: fully known
        for i in range(32, 64):
            assert r.bit(i) in ('0', '1')
        # Lower 32: XXXX=bits 31:16 unknown, 0000=bits 15:0 known-zero
        for i in range(16, 32):
            assert r.bit(i) == 'x'

    def test_unknown_hi_known_lo(self):
        hi = B8("xxxxxxxx")
        lo = B8(0xFF)
        r = hi.concat(lo)
        assert r.width == 16
        for i in range(8):
            assert r.bit(i) == '1'
        for i in range(8, 16):
            assert r.bit(i) == 'x'


class TestConcatWidths:
    def test_result_width(self):
        a = B8(0)
        b = B16(0)
        r = a.concat(b)
        assert r.width == 24

    def test_mixed_widths(self):
        a = B8(0xFF)
        b = B32(0)
        r = a.concat(b)
        assert r.width == 40
        assert r.bit(39) == '1'  # high bit of 'a'
        assert r.bit(32) == '1'
        assert r.bit(31) == '0'  # high bit of 'b'

    def test_single_bit_concat(self):
        a = B("1", width=1)
        b = B("0", width=1)
        r = a.concat(b)
        assert r.width == 2
        assert r.as_int() == 0b10


class TestConcatBitPositions:
    def test_first_arg_is_high(self):
        hi = B8(0xAB)
        lo = B8(0xCD)
        r = hi.concat(lo)
        assert r[15:8].as_int() == 0xAB
        assert r[7:0].as_int() == 0xCD
