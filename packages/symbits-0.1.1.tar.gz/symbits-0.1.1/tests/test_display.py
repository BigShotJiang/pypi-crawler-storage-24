"""Tests for repr, str, bin(), hex() display methods."""

import pytest
from symbits import B, B8, B16, B32, B64


class TestRepr:
    def test_known_value(self):
        r = repr(B(0xFF, width=8))
        assert '0xff' in r.lower()
        assert '1111 1111' in r
        assert '8/8 known' in r

    def test_partially_known(self):
        r = repr(B("0000xxxx"))
        assert '4/8 known' in r

    def test_all_unknown(self):
        r = repr(B.unknown(8))
        assert '0/8 known' in r

    def test_32bit_repr(self):
        r = repr(B(0x000000FF))
        assert '32/32 known' in r

    def test_str_same_as_repr(self):
        b = B(0x42)
        assert str(b) == repr(b)


class TestHexDisplay:
    def test_known_hex(self):
        assert B(0xFF, width=8).hex() == '0xff'

    def test_all_unknown_nibble(self):
        h = B("0xFFXX00").hex()
        # Middle byte unknown
        assert 'X' in h

    def test_mixed_nibble(self):
        b = B("0000xx00")
        h = b.hex()
        # Upper nibble: 0000 = '0', lower nibble: xx00 = mixed = '?'
        assert '?' in h

    def test_zero(self):
        assert B(0, width=8).hex() == '0x00'

    def test_64bit(self):
        h = B(0, width=64).hex()
        assert h == '0x0000000000000000'

    def test_known_digit(self):
        assert B(0xAB, width=8).hex() == '0xab'


class TestBinDisplay:
    def test_known_value(self):
        assert B(0xFF, width=8).bin() == '11111111'

    def test_with_unknowns(self):
        assert B("0000xxxx").bin() == '0000xxxx'

    def test_all_unknown(self):
        assert B.unknown(8).bin() == 'xxxxxxxx'

    def test_all_zero(self):
        assert B(0, width=8).bin() == '00000000'

    def test_16bit(self):
        s = B(0xFF00, width=16).bin()
        assert s == '1111111100000000'
        assert len(s) == 16


class TestBinGrouped:
    def test_8bit_grouped(self):
        b = B(0xFF, width=8)
        grouped = b._bin_grouped()
        assert grouped == '1111 1111'

    def test_nibble_boundaries(self):
        b = B("0000xxxx")
        grouped = b._bin_grouped()
        assert grouped == '0000 xxxx'


class TestDisplayReadability:
    def test_64bit_display(self):
        b = B64(0xDEADBEEF)
        r = repr(b)
        # Should be readable
        assert '64/64 known' in r
        assert '0x' in r
