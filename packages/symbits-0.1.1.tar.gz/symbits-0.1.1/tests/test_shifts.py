"""Tests for shift operations (lshift, rshift, ashr)."""

import random
import pytest
from symbits import B, B8, B16, B32


class TestLeftShift:
    def test_shift_by_zero(self):
        a = B8("1100xxxx")
        assert (a << 0) == a

    def test_shift_by_one(self):
        a = B8(0x01)
        r = a << 1
        assert r == B8(0x02)

    def test_bottom_bits_known_zero(self):
        a = B8("xxxxxxxx")
        r = a << 3
        assert r.bit(0) == '0'
        assert r.bit(1) == '0'
        assert r.bit(2) == '0'
        assert r.bit(3) == 'x'

    def test_top_bits_lost(self):
        a = B8(0xFF)
        r = a << 4
        assert r == B8(0xF0)

    def test_shift_by_width(self):
        a = B8("1100xxxx")
        r = a << 8
        assert r == B8(0)

    def test_shift_beyond_width(self):
        a = B8("1100xxxx")
        r = a << 100
        assert r == B8(0)

    def test_concrete_fuzz(self):
        rng = random.Random(42)
        for _ in range(1000):
            val = rng.randint(0, 0xFF)
            n = rng.randint(0, 7)
            result = B8(val) << n
            assert result.could_equal((val << n) & 0xFF)


class TestLogicalRightShift:
    def test_shift_by_zero(self):
        a = B8("1100xxxx")
        assert (a >> 0) == a

    def test_shift_by_one(self):
        a = B8(0x80)
        r = a >> 1
        assert r == B8(0x40)

    def test_top_bits_known_zero(self):
        a = B8("xxxxxxxx")
        r = a >> 3
        assert r.bit(7) == '0'
        assert r.bit(6) == '0'
        assert r.bit(5) == '0'
        assert r.bit(4) == 'x'

    def test_shift_by_width(self):
        a = B8("1100xxxx")
        r = a >> 8
        assert r == B8(0)

    def test_shift_beyond_width(self):
        a = B8("1100xxxx")
        r = a >> 100
        assert r == B8(0)

    def test_concrete_fuzz(self):
        rng = random.Random(42)
        for _ in range(1000):
            val = rng.randint(0, 0xFF)
            n = rng.randint(0, 7)
            result = B8(val) >> n
            assert result.could_equal(val >> n)


class TestArithmeticRightShift:
    def test_sign_bit_one(self):
        a = B8(0x80)  # 10000000
        r = a.ashr(4)
        # Top 4 bits fill with 1 (sign bit)
        assert r == B8(0xF8)  # 11111000

    def test_sign_bit_zero(self):
        a = B8(0x40)  # 01000000
        r = a.ashr(4)
        assert r == B8(0x04)  # 00000100

    def test_sign_bit_unknown(self):
        a = B8("xxxxxxxx")
        r = a.ashr(4)
        # Top 4 bits unknown (sign is unknown)
        assert r.bit(7) == 'x'
        assert r.bit(6) == 'x'
        assert r.bit(5) == 'x'
        assert r.bit(4) == 'x'

    def test_shift_by_zero(self):
        a = B8("1100xxxx")
        assert a.ashr(0) == a

    def test_shift_by_width(self):
        a = B8(0x80)
        r = a.ashr(8)
        assert r == B8(0xFF)  # All 1s from sign bit

    def test_shift_by_width_zero_sign(self):
        a = B8(0x7F)
        r = a.ashr(8)
        assert r == B8(0)

    def test_shift_by_width_unknown_sign(self):
        a = B8("xxxxxxxx")
        r = a.ashr(8)
        assert r.is_fully_unknown()

    def test_known_sign_one_fills(self):
        a = B8("10000000")
        r = a.ashr(3)
        assert r.bit(7) == '1'
        assert r.bit(6) == '1'
        assert r.bit(5) == '1'
        assert r.bit(4) == '1'
        assert r.bit(3) == '0'

    def test_partial_unknown(self):
        a = B8("1xxx0000")
        r = a.ashr(2)
        # Sign bit is '1', so top 2 filled with 1
        assert r.bit(7) == '1'
        assert r.bit(6) == '1'


class TestShiftErrors:
    def test_negative_shift(self):
        with pytest.raises(ValueError, match="non-negative"):
            B8(0xFF) << -1

    def test_negative_rshift(self):
        with pytest.raises(ValueError, match="non-negative"):
            B8(0xFF) >> -1

    def test_negative_ashr(self):
        with pytest.raises(ValueError, match="non-negative"):
            B8(0xFF).ashr(-1)

    def test_symbolic_shift_lshift(self):
        with pytest.raises(TypeError, match="symbolic"):
            B8(0xFF) << B8(1)

    def test_symbolic_shift_rshift(self):
        with pytest.raises(TypeError, match="symbolic"):
            B8(0xFF) >> B8(1)

    def test_symbolic_shift_ashr(self):
        with pytest.raises(TypeError, match="symbolic"):
            B8(0xFF).ashr(B8(1))
