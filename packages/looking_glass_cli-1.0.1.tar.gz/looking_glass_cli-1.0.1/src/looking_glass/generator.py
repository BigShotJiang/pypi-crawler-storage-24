"""OpenAI Image Edit API integration for Looking Glass."""

from __future__ import annotations

import base64
import time
from pathlib import Path

from openai import OpenAI, RateLimitError

from looking_glass import config

MAX_RETRIES = 5
INITIAL_BACKOFF = 2.0

PROMPT_TEMPLATE = (
    "Change the outfit of the person in this photo. "
    "Keep their face, body, pose, and background exactly the same. "
    "Only change their clothing and accessories to match this description:\n\n"
    "{description}"
)


def get_client() -> OpenAI:
    """Create an OpenAI client from the configured API key."""
    api_key = config.get_api_key()
    if not api_key:
        raise RuntimeError(
            "OpenAI API key not configured. Run: glass config set api_key <your-key>"
        )
    return OpenAI(api_key=api_key)


def build_prompt(outfit_description: str) -> str:
    """Build the image edit prompt from an outfit description."""
    return PROMPT_TEMPLATE.format(description=outfit_description)


def generate_outfit_image(
    photo_path: Path,
    outfit_name: str,
    outfit_description: str,
    output_dir: Path,
    *,
    client: OpenAI | None = None,
) -> Path:
    """Generate an image with a new outfit using OpenAI's Image Edit API.

    Retries automatically on rate-limit errors with exponential backoff.

    Returns the path to the saved output image.
    """
    if client is None:
        client = get_client()

    prompt = build_prompt(outfit_description)
    photo_name = photo_path.stem

    result = _call_with_retry(client, photo_path, prompt)

    image_data = base64.b64decode(result.data[0].b64_json)

    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{photo_name}_{outfit_name}.png"
    output_path.write_bytes(image_data)

    return output_path


def _call_with_retry(client: OpenAI, photo_path: Path, prompt: str):
    """Call the images.edit API with exponential backoff on rate-limit errors."""
    backoff = INITIAL_BACKOFF

    for attempt in range(MAX_RETRIES):
        try:
            return client.images.edit(
                model="gpt-image-1.5",
                image=photo_path,
                prompt=prompt,
                input_fidelity="high",
                quality="high",
                size="auto",
                extra_body={"moderation": "low"},
            )
        except RateLimitError:
            if attempt == MAX_RETRIES - 1:
                raise
            time.sleep(backoff)
            backoff *= 2
