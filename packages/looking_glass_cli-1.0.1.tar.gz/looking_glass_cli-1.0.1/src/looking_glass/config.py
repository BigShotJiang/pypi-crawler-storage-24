"""Configuration management for Looking Glass.

Reads and writes ~/.looking-glass/config.toml.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

import tomli_w

APP_DIR = Path.home() / ".looking-glass"
PHOTOS_DIR = APP_DIR / "photos"
OUTFITS_DIR = APP_DIR / "outfits"
CONFIG_FILE = APP_DIR / "config.toml"


def ensure_dirs() -> None:
    """Create the app directories if they don't exist."""
    for d in (APP_DIR, PHOTOS_DIR, OUTFITS_DIR):
        d.mkdir(parents=True, exist_ok=True)
    APP_DIR.chmod(0o700)


def _read_config() -> dict:
    ensure_dirs()
    if CONFIG_FILE.exists():
        return tomllib.loads(CONFIG_FILE.read_text())
    return {}


def _write_config(data: dict) -> None:
    ensure_dirs()
    CONFIG_FILE.write_bytes(tomli_w.dumps(data).encode())
    CONFIG_FILE.chmod(0o600)


def get(key: str, default=None):
    """Get a config value by key (dot-notation not supported)."""
    return _read_config().get(key, default)


def set_value(key: str, value: str) -> None:
    """Set a config value."""
    data = _read_config()
    data[key] = value
    _write_config(data)


def get_all() -> dict:
    """Return the full config dict."""
    return _read_config()


def get_api_key() -> str | None:
    """Return the OpenAI API key, if configured."""
    return get("api_key")


def get_max_workers() -> int:
    """Return the max parallel workers for image generation (default 4)."""
    value = get("max_workers")
    if value is None:
        return 4
    return int(value)
