"""Interactive selection UI for Looking Glass."""

from __future__ import annotations

import questionary
from rich.console import Console
from rich.table import Table

from looking_glass import storage

console = Console()


def select_photo() -> dict | None:
    """Prompt the user to select a photo. Returns the photo dict or None."""
    photos = storage.list_photos()
    if not photos:
        console.print("[yellow]No photos found.[/] Add one with: [bold]glass photo <file>[/]")
        return None

    choices = [
        questionary.Choice(title=p["name"], value=p) for p in photos
    ]

    return questionary.select(
        "Select a photo:",
        choices=choices,
        use_shortcuts=False,
        use_indicator=True,
    ).ask()


def select_outfits() -> list[dict]:
    """Prompt the user to select one or more outfits. Returns list of outfit dicts."""
    outfits = storage.list_outfits()
    if not outfits:
        console.print(
            "[yellow]No outfits found.[/] Add one with: [bold]glass outfit <file>[/]"
        )
        return []

    choices = [
        questionary.Choice(title=o["name"], value=o)
        for o in outfits
    ]

    selected = questionary.checkbox(
        "Select outfits (space to toggle, enter to confirm):",
        choices=choices,
    ).ask()

    return selected or []


def show_photos_table() -> None:
    """Display a table of all stored photos."""
    photos = storage.list_photos()
    if not photos:
        console.print("[yellow]No photos stored yet.[/]")
        return

    table = Table(title="Photos")
    table.add_column("Name", style="cyan")
    table.add_column("Path", style="dim")
    for p in photos:
        table.add_row(p["name"], str(p["path"]))
    console.print(table)


def show_outfits_table() -> None:
    """Display a table of all stored outfits."""
    outfits = storage.list_outfits()
    if not outfits:
        console.print("[yellow]No outfits stored yet.[/]")
        return

    table = Table(title="Outfits")
    table.add_column("Name", style="cyan")
    for o in outfits:
        table.add_row(o["name"])
    console.print(table)
