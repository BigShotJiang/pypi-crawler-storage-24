# Looking Glass

Use your photos to design and try on outfits — powered by OpenAI's image editing API.

## Installation

```bash
uv tool install .
```

Or run directly from the repo:

```bash
uv run glass --help
```

## Quick Start

```bash
# 1. Set your OpenAI API key
glass config set api_key sk-your-key-here

# 2. Add a photo of yourself
glass photo add ~/selfie.jpg --name me

# 3. Add outfit descriptions (plain text files)
echo "Elegant navy suit, white dress shirt, silk tie" > formal.txt
glass outfit add formal.txt

echo "Hawaiian shirt, cargo shorts, flip-flops" > beach.txt
glass outfit add beach.txt --name beach-vibes

# 4. Run interactive mode — pick a photo, pick outfits, generate!
glass
```

## Commands

| Command | Description |
|---|---|
| `glass` | Interactive mode — select a photo and outfits, then generate images |
| `glass photo add <file> [--name NAME]` | Add a photo |
| `glass photo list` | List stored photos |
| `glass photo remove <name>` | Remove a photo |
| `glass outfit add <file> [--name NAME]` | Add an outfit description |
| `glass outfit create --name NAME` | Create an outfit description in your default editor |
| `glass outfit list` | List stored outfits |
| `glass outfit remove <name>` | Remove an outfit |
| `glass config set <key> <value>` | Set a config value |
| `glass config show` | Show current config |

### Options

- `--output, -o PATH` — Directory for generated images (default: current directory)
- `--version` — Show version

### Configuration

| Key | Description | Default |
|---|---|---|
| `api_key` | OpenAI API key | — |
| `max_workers` | Max parallel image generations | `4` |

Set values with `glass config set <key> <value>`.

## How It Works

1. Photos and outfit files are stored in `~/.looking-glass/`
2. Outfits are plain `.txt` files — the filename is the name, the content is the description
3. In interactive mode, select a photo and one or more outfits
4. For each outfit, the app sends your photo + a prompt to OpenAI's Image Edit API (gpt-image-1)
5. Generated images are saved as `{photo}_{outfit}.png`
