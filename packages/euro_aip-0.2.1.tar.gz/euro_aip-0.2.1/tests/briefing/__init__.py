"""Tests for briefing module."""
