# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class StreamCountData:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'value': 'int',
        'time': 'str'
    }

    attribute_map = {
        'value': 'value',
        'time': 'time'
    }

    def __init__(self, value=None, time=None):
        r"""StreamCountData

        The model defined in huaweicloud sdk

        :param value: 采样时间点的推流路数。
        :type value: int
        :param time: 采样时间。日期格式按照ISO8601表示法，并使用UTC时间。 格式为：YYYY-MM-DDThh:mm:ssZ。
        :type time: str
        """
        
        

        self._value = None
        self._time = None
        self.discriminator = None

        if value is not None:
            self.value = value
        if time is not None:
            self.time = time

    @property
    def value(self):
        r"""Gets the value of this StreamCountData.

        采样时间点的推流路数。

        :return: The value of this StreamCountData.
        :rtype: int
        """
        return self._value

    @value.setter
    def value(self, value):
        r"""Sets the value of this StreamCountData.

        采样时间点的推流路数。

        :param value: The value of this StreamCountData.
        :type value: int
        """
        self._value = value

    @property
    def time(self):
        r"""Gets the time of this StreamCountData.

        采样时间。日期格式按照ISO8601表示法，并使用UTC时间。 格式为：YYYY-MM-DDThh:mm:ssZ。

        :return: The time of this StreamCountData.
        :rtype: str
        """
        return self._time

    @time.setter
    def time(self, time):
        r"""Sets the time of this StreamCountData.

        采样时间。日期格式按照ISO8601表示法，并使用UTC时间。 格式为：YYYY-MM-DDThh:mm:ssZ。

        :param time: The time of this StreamCountData.
        :type time: str
        """
        self._time = time

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, StreamCountData):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
