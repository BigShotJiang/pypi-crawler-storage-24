"""Dailybot CLI entry point."""

import click

from typing import Optional

from dailybot_cli import __version__
from dailybot_cli.commands.agent import agent
from dailybot_cli.commands.auth import login, logout
from dailybot_cli.commands.config import config
from dailybot_cli.commands.interactive import run_interactive
from dailybot_cli.commands.status import status
from dailybot_cli.commands.update import update
from dailybot_cli.config import set_api_url_override


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="dailybot")
@click.option("--api-url", default=None, envvar="DAILYBOT_API_URL", help="Override the API base URL (e.g. staging).")
@click.pass_context
def cli(ctx: click.Context, api_url: Optional[str]) -> None:
    """Dailybot CLI - The command-line bridge between humans and agents.

    \b
    Quick start:
      dailybot login               # Authenticate with email OTP
      dailybot status              # View pending check-ins
      dailybot update "message"    # Submit a free-text update
      dailybot update --done "X" --doing "Y" --blocked "None"

    \b
    Agent mode (API key or login session):
      Progress updates, health reporting, and messaging.
      dailybot config key=<API_KEY>   # Store API key
      dailybot agent update "Deployed v2.1" --name "My Agent"
      dailybot agent --help

    Run without arguments for interactive mode.
    """
    if api_url:
        set_api_url_override(api_url)
    if ctx.invoked_subcommand is None:
        run_interactive()


cli.add_command(login)
cli.add_command(logout)
cli.add_command(update)
cli.add_command(status)
cli.add_command(agent)
cli.add_command(config)


if __name__ == "__main__":
    cli()
