"""Wavelength calibration module."""
