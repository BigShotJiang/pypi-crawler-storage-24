"""Flat-field correction module."""
