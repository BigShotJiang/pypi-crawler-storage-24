
{
    "version": "2026.3.21",
    "target": "default",
    "variant": "cpu"
}
