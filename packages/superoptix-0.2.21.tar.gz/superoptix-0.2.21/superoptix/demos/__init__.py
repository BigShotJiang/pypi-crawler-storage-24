"""Packaged demos for SuperOptiX."""
