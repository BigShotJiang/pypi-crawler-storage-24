# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Self-hosted service provisioning and management."""

from familiar.services.compose import generate_compose, write_compose_file
from familiar.services.manager import ServiceManager, get_service_manager
from familiar.services.specs import SERVICE_SPECS, ServiceSpec, ServiceType

__all__ = [
    "SERVICE_SPECS",
    "ServiceManager",
    "ServiceSpec",
    "ServiceType",
    "generate_compose",
    "get_service_manager",
    "write_compose_file",
]
