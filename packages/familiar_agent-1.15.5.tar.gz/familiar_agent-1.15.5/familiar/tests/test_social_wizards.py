# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Tests for Mastodon and Bluesky connect wizards."""

import os
from unittest import mock

from familiar.channels.connect_wizard._helpers import (
    SERVICE_BUTTON_LABELS,
    SERVICE_DISPLAY,
    SERVICE_DOCS,
    TAB_CATEGORIES,
    TAB_ORDER,
)


class TestSocialWizardRegistration:
    """Tests that social wizards are properly registered."""

    def test_social_tab_in_tab_order(self):
        assert "social" in TAB_ORDER

    def test_social_tab_has_services(self):
        assert "social" in TAB_CATEGORIES
        services = TAB_CATEGORIES["social"]["services"]
        assert "mastodon" in services
        assert "bluesky" in services

    def test_mastodon_in_service_display(self):
        assert "mastodon" in SERVICE_DISPLAY
        assert "Mastodon" in SERVICE_DISPLAY["mastodon"]

    def test_bluesky_in_service_display(self):
        assert "bluesky" in SERVICE_DISPLAY
        assert "Bluesky" in SERVICE_DISPLAY["bluesky"]

    def test_mastodon_in_button_labels(self):
        assert "mastodon" in SERVICE_BUTTON_LABELS

    def test_bluesky_in_button_labels(self):
        assert "bluesky" in SERVICE_BUTTON_LABELS

    def test_mastodon_in_service_docs(self):
        assert "mastodon" in SERVICE_DOCS

    def test_bluesky_in_service_docs(self):
        assert "bluesky" in SERVICE_DOCS


class TestSocialWizardHandlers:
    """Tests for wizard handler registration."""

    def test_mastodon_handler_registered(self):
        from familiar.channels.connect_wizard._core import _WIZARD_HANDLERS

        assert "mastodon" in _WIZARD_HANDLERS

    def test_bluesky_handler_registered(self):
        from familiar.channels.connect_wizard._core import _WIZARD_HANDLERS

        assert "bluesky" in _WIZARD_HANDLERS

    def test_mastodon_handler_callable(self):
        from familiar.channels.connect_wizard._core import _WIZARD_HANDLERS

        assert callable(_WIZARD_HANDLERS["mastodon"])

    def test_bluesky_handler_callable(self):
        from familiar.channels.connect_wizard._core import _WIZARD_HANDLERS

        assert callable(_WIZARD_HANDLERS["bluesky"])


class TestMastodonWizardConfig:
    """Tests for Mastodon wizard configuration detection."""

    def test_mastodon_configured(self):
        from familiar.skills.mastodon.skill import _configured

        with mock.patch.dict(os.environ, {
            "MASTODON_INSTANCE_URL": "https://mastodon.social",
            "MASTODON_ACCESS_TOKEN": "test-token",
        }):
            assert _configured() is True

    def test_mastodon_not_configured(self):
        from familiar.skills.mastodon.skill import _configured

        with mock.patch.dict(os.environ, {}, clear=True):
            assert _configured() is False


class TestBlueskyWizardConfig:
    """Tests for Bluesky wizard configuration detection."""

    def test_bluesky_configured(self):
        from familiar.skills.bluesky.skill import _configured

        with mock.patch.dict(os.environ, {
            "BLUESKY_HANDLE": "test.bsky.social",
            "BLUESKY_APP_PASSWORD": "xxxx-xxxx",
        }):
            assert _configured() is True

    def test_bluesky_not_configured(self):
        from familiar.skills.bluesky.skill import _configured

        with mock.patch.dict(os.environ, {}, clear=True):
            assert _configured() is False
