# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Tests for Mastodon and Bluesky channel adapters."""

from unittest import mock

from familiar.channels.auth import ChannelType
from familiar.channels.formatting import FormatMode

# =============================================================================
# Mastodon Channel tests
# =============================================================================


class TestMastodonChannel:
    """Tests for MastodonChannel adapter."""

    def test_format_mode_is_plain(self):
        from familiar.channels.mastodon import MastodonChannel

        assert MastodonChannel.format_mode == FormatMode.PLAIN

    def test_supports_buttons_false(self):
        from familiar.channels.mastodon import MastodonChannel

        assert MastodonChannel.supports_buttons is False

    def test_supports_message_deletion_false(self):
        from familiar.channels.mastodon import MastodonChannel

        assert MastodonChannel.supports_message_deletion is False

    def test_init_defaults(self):
        from familiar.channels.mastodon import MastodonChannel

        agent = mock.MagicMock()
        with mock.patch.dict("os.environ", {}, clear=False):
            ch = MastodonChannel(agent)
            assert ch.agent is agent
            assert ch._running is False
            assert ch._client is None
            assert ch.respond_to_dms is True
            assert ch.respond_to_mentions is True

    def test_init_with_params(self):
        from familiar.channels.mastodon import MastodonChannel

        agent = mock.MagicMock()
        ch = MastodonChannel(
            agent,
            instance_url="https://mastodon.example.org",
            access_token="test-token",
            owner_handle="@admin@example.org",
            allowed_users=["user1", "user2"],
        )
        assert ch.instance_url == "https://mastodon.example.org"
        assert ch.access_token == "test-token"
        assert ch.owner_handle == "@admin@example.org"
        assert "user1" in ch.allowed_users

    def test_channel_type_exists(self):
        assert hasattr(ChannelType, "MASTODON")
        assert ChannelType.MASTODON.value == "mastodon"

    def test_stop_sets_running_false(self):
        from familiar.channels.mastodon import MastodonChannel

        agent = mock.MagicMock()
        ch = MastodonChannel(agent)
        ch._running = True
        ch.stop()
        assert ch._running is False


# =============================================================================
# Bluesky Channel tests
# =============================================================================


class TestBlueskyChannel:
    """Tests for BlueskyChannel adapter."""

    def test_format_mode_is_plain(self):
        from familiar.channels.bluesky import BlueskyChannel

        assert BlueskyChannel.format_mode == FormatMode.PLAIN

    def test_supports_buttons_false(self):
        from familiar.channels.bluesky import BlueskyChannel

        assert BlueskyChannel.supports_buttons is False

    def test_supports_message_deletion_false(self):
        from familiar.channels.bluesky import BlueskyChannel

        assert BlueskyChannel.supports_message_deletion is False

    def test_init_defaults(self):
        from familiar.channels.bluesky import BlueskyChannel

        agent = mock.MagicMock()
        with mock.patch.dict("os.environ", {}, clear=False):
            ch = BlueskyChannel(agent)
            assert ch.agent is agent
            assert ch._running is False
            assert ch._client is None
            assert ch._poll_interval == 15

    def test_init_with_params(self):
        from familiar.channels.bluesky import BlueskyChannel

        agent = mock.MagicMock()
        ch = BlueskyChannel(
            agent,
            handle="test.bsky.social",
            app_password="xxxx-xxxx",
            pds_url="https://pds.example.org",
            owner_handle="owner.bsky.social",
            allowed_users=["friend.bsky.social"],
        )
        assert ch.handle == "test.bsky.social"
        assert ch.app_password == "xxxx-xxxx"
        assert ch.pds_url == "https://pds.example.org"
        assert ch.owner_handle == "owner.bsky.social"
        assert "friend.bsky.social" in ch.allowed_users

    def test_channel_type_exists(self):
        assert hasattr(ChannelType, "BLUESKY")
        assert ChannelType.BLUESKY.value == "bluesky"

    def test_stop_sets_running_false(self):
        from familiar.channels.bluesky import BlueskyChannel

        agent = mock.MagicMock()
        ch = BlueskyChannel(agent)
        ch._running = True
        ch.stop()
        assert ch._running is False
