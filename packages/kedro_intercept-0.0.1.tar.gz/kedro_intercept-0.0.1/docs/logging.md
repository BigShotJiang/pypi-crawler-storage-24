# Logging

Kedro's default logging only covers the `kedro` namespace. Output from `kedro_intercept` is silently dropped unless you enable it explicitly.

Add a `conf/logging.yml` to your project (Kedro picks this up automatically):

```yaml
version: 1

disable_existing_loggers: False

handlers:
  rich:
    class: kedro.logging.RichHandler
    rich_tracebacks: True

loggers:
  kedro:
    level: INFO
  kedro_intercept:
    level: INFO

root:
  handlers: [rich]
```

Without this, the hook will be listed in `kedro info` but produce no log output during `kedro run`. This is a consequence of how Kedro scopes its default logging, not a bug.

!!! note
    If you already have a `conf/logging.yml`, just add `kedro_intercept: {level: INFO}` under the `loggers` key.
