# API Reference

## Registry

::: kedro_intercept.InterceptorRegistry

## Functions

::: kedro_intercept.intercept_node

::: kedro_intercept.intercept
