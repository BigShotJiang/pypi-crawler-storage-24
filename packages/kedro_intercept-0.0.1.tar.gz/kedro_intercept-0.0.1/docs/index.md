# kedro-intercept

A Kedro hook for attaching interceptors to pipeline lifecycle phases. Unlike writing a hook class, interceptors are declared in the pipeline definition — scoped to the node or dataset they belong to.

## Installation

```bash
pip install kedro-intercept
```

The hook is auto-discovered via Kedro's entry point mechanism. No `settings.py` changes needed.

## Usage

Call `intercept_node` next to the node it applies to:

```python
from kedro_intercept import intercept_node

my_node = node(func=train, inputs="raw", outputs="model", name="train_model")

intercept_node(
    my_node,
    before_node_run=log_start,
    after_dataset_saved={"model": validate_model},
)
```

For global phases, `node` can be omitted:

```python
intercept_node(before_pipeline_run=setup, after_pipeline_run=teardown)
```

Or use `intercept` directly by phase name:

```python
from kedro_intercept import intercept

intercept("before_pipeline_run", setup)
intercept("before_node_run", log_start, name="train_model")
intercept("after_dataset_saved", validate_model, name="model")
```

## Parameter matching

Interceptors only need to declare the parameters they use. Everything else is dropped:

```python
def log_start(node, run_id):
    print(f"{node.name} started — run {run_id}")
```

Available parameters depend on the phase. See the [Kedro hooks documentation](https://docs.kedro.org/en/stable/hooks/introduction.html) for the full signatures.

## Phases

### Global

| Phase | When |
|---|---|
| `after_context_created` | After `KedroContext` is created |
| `after_catalog_created` | After the data catalog is created |
| `before_pipeline_run` | Before the pipeline starts |
| `after_pipeline_run` | After the pipeline finishes |
| `on_pipeline_error` | If the pipeline raises |

### Node-level

| Phase | When |
|---|---|
| `before_node_run` | Before the node runs |
| `after_node_run` | After the node runs |
| `on_node_error` | If the node raises |

### Dataset-level

| Phase | When |
|---|---|
| `before_dataset_loaded` | Before a dataset is loaded |
| `after_dataset_loaded` | After a dataset is loaded |
| `before_dataset_saved` | Before a dataset is saved |
| `after_dataset_saved` | After a dataset is saved |

Dataset phases accept a single callable (applied to all inputs/outputs), a list, or a dict keyed by dataset name:

```python
intercept_node(
    my_node,
    after_dataset_saved={"predictions": validate, "metrics": log_metrics},
)
```

## Assert variants

Every phase has an `assert_` variant that re-raises on failure instead of logging a warning:

```python
intercept_node(
    my_node,
    assert_after_dataset_saved={"predictions": check_no_nulls},
)
```
