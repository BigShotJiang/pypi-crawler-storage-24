from __future__ import annotations

import logging
from collections.abc import Callable, Iterable, Iterator, Mapping
from typing import TYPE_CHECKING, Any, TypeAlias, cast

from kedro.pipeline.node import Node

if TYPE_CHECKING:
    from ._registry import InterceptorRegistry

logger = logging.getLogger(__name__)

Hook: TypeAlias = Callable[..., Any]


def _iter_datasets(
    outputs: str | list[str] | dict[str, str] | None,
) -> Iterator[str]:
    if outputs is None:
        return iter(())
    if isinstance(outputs, str):
        return iter((outputs,))
    if isinstance(outputs, list):
        return iter(outputs)
    return iter(outputs.values())


def _normalise_hooks(hooks: Hook | Iterable[Hook]) -> list[Hook]:
    if callable(hooks):
        return [hooks]
    try:
        items = list(cast(Iterable[Hook], hooks))
    except TypeError as e:
        raise TypeError(
            f"Expected a callable or an iterable of callables, "
            f"got {type(hooks).__name__}"
        ) from e
    not_callables = [x for x in items if not callable(x)]
    if not_callables:
        raise TypeError(f"All items must be callables, got: {not_callables!r}")
    return list(items)


def _as_per_element(
    names: Iterable[str],
    hooks: Hook | Iterable[Hook] | dict[str, Hook | Iterable[Hook]],
) -> list[tuple[str, Hook]]:
    names = tuple(names)

    if callable(hooks) or (
        isinstance(hooks, Iterable) and not isinstance(hooks, Mapping)
    ):
        fns = _normalise_hooks(hooks)
        return [(name, fn) for name in names for fn in fns]

    if not isinstance(hooks, Mapping):
        raise TypeError(
            f"Expected a callable, iterable of callables, or mapping, "
            f"got {type(hooks).__name__}"
        )

    hooks_map = cast(dict[str, Hook | Iterable[Hook]], hooks)
    unknown = set(hooks_map.keys()) - set(names)
    if unknown:
        logger.warning(
            "intercept_node: ignoring unknown output names: %s", sorted(unknown)
        )

    pairs: list[tuple[str, Hook]] = []
    for name in names:
        if name in hooks_map:
            pairs.extend((name, fn) for fn in _normalise_hooks(hooks_map[name]))
    return pairs


def intercept_node(
    node: Node | None = None,
    *,
    registry: InterceptorRegistry,
    after_context_created: Hook | Iterable[Hook] | None = None,
    after_catalog_created: Hook | Iterable[Hook] | None = None,
    before_pipeline_run: Hook | Iterable[Hook] | None = None,
    after_pipeline_run: Hook | Iterable[Hook] | None = None,
    on_pipeline_error: Hook | Iterable[Hook] | None = None,
    assert_after_context_created: Hook | Iterable[Hook] | None = None,
    assert_after_catalog_created: Hook | Iterable[Hook] | None = None,
    assert_before_pipeline_run: Hook | Iterable[Hook] | None = None,
    assert_after_pipeline_run: Hook | Iterable[Hook] | None = None,
    assert_on_pipeline_error: Hook | Iterable[Hook] | None = None,
    before_node_run: Hook | Iterable[Hook] | None = None,
    after_node_run: Hook | Iterable[Hook] | None = None,
    on_node_error: Hook | Iterable[Hook] | None = None,
    assert_before_node_run: Hook | Iterable[Hook] | None = None,
    assert_after_node_run: Hook | Iterable[Hook] | None = None,
    assert_on_node_error: Hook | Iterable[Hook] | None = None,
    before_dataset_loaded: Hook
    | Iterable[Hook]
    | dict[str, Hook | Iterable[Hook]]
    | None = None,
    after_dataset_loaded: Hook
    | Iterable[Hook]
    | dict[str, Hook | Iterable[Hook]]
    | None = None,
    before_dataset_saved: Hook
    | Iterable[Hook]
    | dict[str, Hook | Iterable[Hook]]
    | None = None,
    after_dataset_saved: Hook
    | Iterable[Hook]
    | dict[str, Hook | Iterable[Hook]]
    | None = None,
    assert_before_dataset_loaded: Hook
    | Iterable[Hook]
    | dict[str, Hook | Iterable[Hook]]
    | None = None,
    assert_after_dataset_loaded: Hook
    | Iterable[Hook]
    | dict[str, Hook | Iterable[Hook]]
    | None = None,
    assert_before_dataset_saved: Hook
    | Iterable[Hook]
    | dict[str, Hook | Iterable[Hook]]
    | None = None,
    assert_after_dataset_saved: Hook
    | Iterable[Hook]
    | dict[str, Hook | Iterable[Hook]]
    | None = None,
) -> Node | None:
    """Register callables for Kedro lifecycle phases on a given node.

    Each argument accepts a single callable, an iterable of callables, or
    (for dataset phases) a mapping of ``{dataset_name: callable_or_list}``.

    Prefix any phase with ``assert_`` to make failures raise instead of log.

    Parameters
    ----------
    node : Node, optional
        The Kedro ``Node`` whose name / inputs / outputs are used for node-
        and dataset-level phases. Pass ``None`` for global-only registrations.
    registry : InterceptorRegistry
        The registry to register into. When called via the public
        ``intercept_node`` wrapper this is the package-level singleton.

    Returns
    -------
    Node or None
        The same ``node`` that was passed in. Registration is a side-effect.

    Examples
    --------
    Global interceptors (run once per pipeline):

    ```python
    from kedro_intercept import intercept_node

    intercept_node(
        node,
        before_pipeline_run=my_setup_fn,
        after_pipeline_run=[my_teardown_fn, my_report_fn],
    )
    ```

    Node interceptors:

    ```python
    intercept_node(node, before_node_run=my_pre_fn, after_node_run=my_post_fn)
    ```

    Dataset interceptors — apply to all outputs, or only named ones:

    ```python
    intercept_node(
        node,
        after_dataset_saved={
            "predictions": validate_predictions,
            "metrics": [log_metrics, upload_metrics],
        },
    )
    ```
    """

    def _reg_global(phase: str, hooks: Hook | Iterable[Hook] | None) -> None:
        if hooks is None:
            return
        for fn in _normalise_hooks(hooks):
            registry.intercept(phase, fn)

    def _reg_node(phase: str, hooks: Hook | Iterable[Hook] | None) -> None:
        if hooks is None or node is None:
            return
        for fn in _normalise_hooks(hooks):
            registry.intercept(phase, fn, name=node.name)

    def _reg_ds_input(
        phase: str,
        hooks: Hook | Iterable[Hook] | dict[str, Hook | Iterable[Hook]] | None,
    ) -> None:
        if hooks is None:
            return
        input_names = tuple(_iter_datasets(getattr(node, "inputs", None)))
        for ds, fn in _as_per_element(input_names, hooks):
            registry.intercept(phase, fn, name=ds)

    def _reg_ds_output(
        phase: str,
        hooks: Hook | Iterable[Hook] | dict[str, Hook | Iterable[Hook]] | None,
    ) -> None:
        if hooks is None:
            return
        if node is None:
            logger.warning(
                "intercept_node: no node passed, cannot register dataset output hooks"
            )
            return
        output_names = tuple(_iter_datasets(getattr(node, "outputs", None)))
        for ds, fn in _as_per_element(output_names, hooks):
            registry.intercept(phase, fn, name=ds)

    # Global phases
    _reg_global("after_context_created", after_context_created)
    _reg_global("assert_after_context_created", assert_after_context_created)
    _reg_global("after_catalog_created", after_catalog_created)
    _reg_global("assert_after_catalog_created", assert_after_catalog_created)
    _reg_global("before_pipeline_run", before_pipeline_run)
    _reg_global("assert_before_pipeline_run", assert_before_pipeline_run)
    _reg_global("after_pipeline_run", after_pipeline_run)
    _reg_global("assert_after_pipeline_run", assert_after_pipeline_run)
    _reg_global("on_pipeline_error", on_pipeline_error)
    _reg_global("assert_on_pipeline_error", assert_on_pipeline_error)

    # Node phases
    _reg_node("before_node_run", before_node_run)
    _reg_node("assert_before_node_run", assert_before_node_run)
    _reg_node("after_node_run", after_node_run)
    _reg_node("assert_after_node_run", assert_after_node_run)
    _reg_node("on_node_error", on_node_error)
    _reg_node("assert_on_node_error", assert_on_node_error)

    # Dataset phases
    _reg_ds_input("before_dataset_loaded", before_dataset_loaded)
    _reg_ds_input("assert_before_dataset_loaded", assert_before_dataset_loaded)
    _reg_ds_input("after_dataset_loaded", after_dataset_loaded)
    _reg_ds_input("assert_after_dataset_loaded", assert_after_dataset_loaded)
    _reg_ds_output("before_dataset_saved", before_dataset_saved)
    _reg_ds_output("assert_before_dataset_saved", assert_before_dataset_saved)
    _reg_ds_output("after_dataset_saved", after_dataset_saved)
    _reg_ds_output("assert_after_dataset_saved", assert_after_dataset_saved)

    return node
