# Copyright (c) Simon Niederberger.
# Distributed under the terms of the MIT License.

from ._api import intercept_node as _intercept_node
from ._registry import InterceptorRegistry

try:
    from ._version import __version__
except ImportError:
    __version__ = "unknown"

interceptor_registry = InterceptorRegistry()
intercept = interceptor_registry.intercept


def intercept_node(node=None, **kwargs):
    """Register callables for Kedro lifecycle phases.

    Thin wrapper around ``_api.intercept_node`` that binds the package-level
    ``interceptor_registry`` singleton as the default registry.

    See ``intercept_node`` in ``_api`` for full parameter docs.
    """
    return _intercept_node(node, registry=interceptor_registry, **kwargs)


__all__ = [
    "InterceptorRegistry",
    "__version__",
    "intercept",
    "intercept_node",
    "interceptor_registry",
]
