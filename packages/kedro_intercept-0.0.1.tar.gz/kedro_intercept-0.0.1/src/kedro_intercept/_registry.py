from __future__ import annotations

import functools
import inspect
import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, TypeAlias

from kedro.framework.hooks import hook_impl

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from kedro.framework.context import KedroContext
    from kedro.io import CatalogProtocol
    from kedro.pipeline import Pipeline
    from kedro.pipeline.node import Node

Hook: TypeAlias = Callable[..., Any]
_NamedRegistry: TypeAlias = dict[str, dict[str, list[Hook]]]
_GlobalRegistry: TypeAlias = dict[str, list[Hook]]


def _callable_name(func: Hook) -> str:
    if isinstance(func, functools.partial):
        return getattr(func.func, "__name__", "<partial>")
    return getattr(func, "__name__", "<callable>")


_NAMED_PHASES = frozenset(
    {
        "before_dataset_loaded",
        "after_dataset_loaded",
        "before_node_run",
        "after_node_run",
        "before_dataset_saved",
        "after_dataset_saved",
        "on_node_error",
        "assert_before_dataset_loaded",
        "assert_after_dataset_loaded",
        "assert_before_node_run",
        "assert_after_node_run",
        "assert_before_dataset_saved",
        "assert_after_dataset_saved",
        "assert_on_node_error",
    }
)

_GLOBAL_PHASES = frozenset(
    {
        "after_context_created",
        "after_catalog_created",
        "before_pipeline_run",
        "after_pipeline_run",
        "on_pipeline_error",
        "assert_after_context_created",
        "assert_after_catalog_created",
        "assert_before_pipeline_run",
        "assert_after_pipeline_run",
        "assert_on_pipeline_error",
    }
)


class InterceptorRegistry:
    """Central registry and dispatcher for Kedro pipeline lifecycle hooks.

    Holds callables keyed by phase (and optionally by node or dataset name),
    and invokes them when Kedro triggers the corresponding hook method.

    The package-level ``interceptor_registry`` singleton is auto-discovered by
    Kedro via the ``kedro.hooks`` entry point — no ``settings.py`` changes
    required.

    Use ``intercept_node`` to attach interceptors at node-definition time, or
    call ``intercept`` directly for fine-grained control.
    """

    def __init__(self) -> None:
        self.catalog: CatalogProtocol | None = None
        self._registry: _NamedRegistry = {phase: {} for phase in _NAMED_PHASES}
        self._global_registry: _GlobalRegistry = {phase: [] for phase in _GLOBAL_PHASES}

    def intercept(
        self,
        phase: str,
        func: Hook,
        name: str | None = None,
    ) -> None:
        """Register a single callable for a lifecycle phase.

        Parameters are matched by name against what Kedro passes for that
        phase, so a registered function only needs to declare the arguments it
        actually uses — extras are silently dropped.

        Prefix any phase name with ``assert_`` to make the hook re-raise on
        failure rather than logging a warning.

        Parameters
        ----------
        phase : str
            Lifecycle phase to register for.

            Global phases (``name`` must be omitted):
            ``after_context_created``, ``after_catalog_created``,
            ``before_pipeline_run``, ``after_pipeline_run``,
            ``on_pipeline_error``

            Named phases (``name`` = node or dataset name):
            ``before_node_run``, ``after_node_run``, ``on_node_error``,
            ``before_dataset_loaded``, ``after_dataset_loaded``,
            ``before_dataset_saved``, ``after_dataset_saved``

        func : callable
            The callable to invoke when the phase fires.
        name : str, optional
            Node or dataset name for named phases. Must be ``None`` for
            global phases.

        Raises
        ------
        TypeError
            If ``func`` is not callable.
        ValueError
            If ``phase`` is unknown, ``name`` is provided for a global phase,
            or ``name`` is missing for a named phase.
        """
        if not callable(func):
            raise TypeError("func must be callable")

        if phase in self._global_registry:
            if name is not None:
                raise ValueError(
                    f"Global phases do not take a name. "
                    f"Got name={name!r} for phase {phase!r}."
                )
            logger.info(
                "Registering '%s' in global phase '%s'", _callable_name(func), phase
            )
            self._global_registry[phase].append(func)

        elif phase in self._registry:
            if not isinstance(name, str) or not name:
                raise ValueError(
                    f"name must be a non-empty str for named phase {phase!r}."
                )
            logger.info(
                "Registering '%s' on '%s' in phase '%s'",
                _callable_name(func),
                name,
                phase,
            )
            self._registry[phase].setdefault(name, []).append(func)

        else:
            raise ValueError(
                f"Unknown phase: {phase!r}. "
                f"Valid phases: {sorted(_GLOBAL_PHASES | _NAMED_PHASES)}"
            )

    @hook_impl
    def after_context_created(self, context: KedroContext) -> None:
        self._invoke("after_context_created", context=context)

    @hook_impl
    def after_catalog_created(
        self,
        catalog: CatalogProtocol,
        conf_catalog: dict[str, Any],
        conf_creds: dict[str, Any],
        parameters: dict[str, Any],
        save_version: str,
        load_versions: dict[str, str],
    ) -> None:
        self.catalog = catalog
        self._invoke(
            "after_catalog_created",
            catalog=catalog,
            conf_catalog=conf_catalog,
            conf_creds=conf_creds,
            parameters=parameters,
            save_version=save_version,
            load_versions=load_versions,
        )

    @hook_impl
    def before_pipeline_run(
        self,
        run_params: dict[str, Any],
        pipeline: Pipeline,
        catalog: CatalogProtocol,
    ) -> None:
        self._invoke(
            "before_pipeline_run",
            run_params=run_params,
            pipeline=pipeline,
            catalog=catalog,
        )

    @hook_impl
    def after_pipeline_run(
        self,
        run_params: dict[str, Any],
        run_result: dict[str, Any],
        pipeline: Pipeline,
        catalog: CatalogProtocol,
    ) -> None:
        self._invoke(
            "after_pipeline_run",
            run_params=run_params,
            run_result=run_result,
            pipeline=pipeline,
            catalog=catalog,
        )

    @hook_impl
    def on_pipeline_error(
        self,
        error: Exception,
        run_params: dict[str, Any],
        pipeline: Pipeline,
        catalog: CatalogProtocol,
    ) -> None:
        self._invoke(
            "on_pipeline_error",
            error=error,
            run_params=run_params,
            pipeline=pipeline,
            catalog=catalog,
        )

    @hook_impl
    def before_dataset_loaded(self, dataset_name: str, node: Node) -> None:
        self._invoke(
            "before_dataset_loaded",
            name=dataset_name,
            catalog=self.catalog,
            dataset_name=dataset_name,
            node=node,
        )

    @hook_impl
    def after_dataset_loaded(self, dataset_name: str, data: Any, node: Node) -> None:
        self._invoke(
            "after_dataset_loaded",
            name=dataset_name,
            catalog=self.catalog,
            dataset_name=dataset_name,
            data=data,
            node=node,
        )

    @hook_impl
    def before_dataset_saved(self, dataset_name: str, data: Any, node: Node) -> None:
        self._invoke(
            "before_dataset_saved",
            name=dataset_name,
            catalog=self.catalog,
            dataset_name=dataset_name,
            data=data,
            node=node,
        )

    @hook_impl
    def after_dataset_saved(self, dataset_name: str, data: Any, node: Node) -> None:
        self._invoke(
            "after_dataset_saved",
            name=dataset_name,
            catalog=self.catalog,
            dataset_name=dataset_name,
            data=data,
            node=node,
        )

    @hook_impl
    def before_node_run(
        self,
        node: Node,
        catalog: CatalogProtocol,
        inputs: dict[str, Any],
        is_async: bool,
        run_id: str,
    ) -> dict[str, Any] | None:
        self._invoke(
            "before_node_run",
            name=node.name,
            node=node,
            catalog=catalog,
            inputs=inputs,
            is_async=is_async,
            run_id=run_id,
        )

    @hook_impl
    def after_node_run(
        self,
        node: Node,
        catalog: CatalogProtocol,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        is_async: bool,
        run_id: str,
    ) -> None:
        self._invoke(
            "after_node_run",
            name=node.name,
            node=node,
            catalog=catalog,
            inputs=inputs,
            outputs=outputs,
            is_async=is_async,
            run_id=run_id,
        )

    @hook_impl
    def on_node_error(
        self,
        error: Exception,
        node: Node,
        catalog: CatalogProtocol,
        inputs: dict[str, Any],
        is_async: bool,
        run_id: str,
    ) -> None:
        self._invoke(
            "on_node_error",
            name=node.name,
            error=error,
            node=node,
            catalog=catalog,
            inputs=inputs,
            is_async=is_async,
            run_id=run_id,
        )

    def _invoke(self, phase: str, name: str | None = None, **kwargs: Any) -> None:
        if phase in self._global_registry:
            funcs = self._global_registry[phase]
            assert_funcs = self._global_registry.get(f"assert_{phase}", [])
        elif phase in self._registry:
            funcs = self._registry[phase].get(name or "", [])
            assert_funcs = self._registry.get(f"assert_{phase}", {}).get(name or "", [])
        else:
            raise ValueError(f"Unknown phase: {phase!r}")

        for func in funcs:
            self._run_func(func, phase=phase, name=name, break_on_error=False, **kwargs)
        for func in assert_funcs:
            self._run_func(func, phase=phase, name=name, break_on_error=True, **kwargs)

    def _run_func(
        self,
        func: Hook,
        phase: str,
        name: str | None = None,
        break_on_error: bool = False,
        **hook_kwargs: Any,
    ) -> None:
        func_name = _callable_name(func)
        label = f"'{func_name}' on '{name}'" if name else f"'{func_name}'"

        try:
            param_names = self._get_param_names(func)
            kwargs = {k: v for k, v in hook_kwargs.items() if k in param_names}
            func(**kwargs)
        except Exception as exc:
            msg = f"Hook {label} in phase '{phase}' failed: {exc}"
            if break_on_error:
                logger.exception(msg)
                raise
            logger.warning(msg, exc_info=True)

    @staticmethod
    def _get_param_names(func: Hook) -> frozenset[str]:
        sig = inspect.signature(func)
        return frozenset(sig.parameters)
