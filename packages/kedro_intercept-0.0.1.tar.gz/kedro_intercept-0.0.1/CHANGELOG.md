# Changelog

## 0.1.0 (2026-03-20)

Initial release.

### Features

- `InterceptorRegistry` Kedro hook, auto-discovered via the `kedro.hooks` entry point
- `intercept_node` — attach interceptors to lifecycle phases in the pipeline definition, scoped by node name or dataset name
- `intercept` — low-level registration by phase name
- Global, node-level, and dataset-level phases
- `assert_` variants that re-raise on failure instead of logging a warning
- Parameter matching by name — interceptors only declare the parameters they use
