import kedro_intercept


def test_import():
    assert kedro_intercept.__version__ != "unknown"
