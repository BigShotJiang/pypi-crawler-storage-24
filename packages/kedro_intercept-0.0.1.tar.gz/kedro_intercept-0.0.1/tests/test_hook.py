from __future__ import annotations

from unittest.mock import MagicMock

import pytest

import kedro_intercept
from kedro_intercept import InterceptorRegistry, intercept_node

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_node(name: str = "my_node", inputs=None, outputs=None) -> MagicMock:
    node = MagicMock()
    node.name = name
    node.inputs = inputs or []
    node.outputs = outputs or []
    return node


@pytest.fixture
def registry() -> InterceptorRegistry:
    """Fresh isolated registry for each test."""
    return InterceptorRegistry()


# ---------------------------------------------------------------------------
# intercept()
# ---------------------------------------------------------------------------


def test_register_global_phase(registry):
    fn = MagicMock()
    registry.intercept("before_pipeline_run", fn)
    assert fn in registry._global_registry["before_pipeline_run"]


def test_register_named_phase(registry):
    fn = MagicMock()
    registry.intercept("before_node_run", fn, name="my_node")
    assert fn in registry._registry["before_node_run"]["my_node"]


def test_register_global_phase_rejects_name(registry):
    with pytest.raises(ValueError, match="do not take a name"):
        registry.intercept("before_pipeline_run", MagicMock(), name="oops")


def test_register_named_phase_requires_name(registry):
    with pytest.raises(ValueError, match="non-empty str"):
        registry.intercept("before_node_run", MagicMock())


def test_register_unknown_phase_raises(registry):
    with pytest.raises(ValueError, match="Unknown phase"):
        registry.intercept("not_a_phase", MagicMock())


def test_register_non_callable_raises(registry):
    with pytest.raises(TypeError):
        registry.intercept("before_pipeline_run", "not_a_function")  # type: ignore[arg-type]


def test_two_registries_are_isolated():
    fn = MagicMock()
    r1, r2 = InterceptorRegistry(), InterceptorRegistry()
    r1.intercept("before_pipeline_run", fn)
    assert fn in r1._global_registry["before_pipeline_run"]
    assert fn not in r2._global_registry["before_pipeline_run"]


# ---------------------------------------------------------------------------
# intercept_node()
# ---------------------------------------------------------------------------


def test_intercept_node_global_phase(registry):
    fn = MagicMock()
    intercept_node(_make_node(), before_pipeline_run=fn)
    # uses the package singleton; verify via the registry fixture indirectly
    # by calling _intercept_node directly with our registry
    from kedro_intercept._api import intercept_node as _intercept_node

    node = _make_node()
    _intercept_node(node, registry=registry, before_pipeline_run=fn)
    assert fn in registry._global_registry["before_pipeline_run"]


def test_intercept_node_node_phase(registry):
    from kedro_intercept._api import intercept_node as _intercept_node

    fn = MagicMock()
    node = _make_node("train_model")
    _intercept_node(node, registry=registry, before_node_run=fn)
    assert fn in registry._registry["before_node_run"]["train_model"]


def test_intercept_node_dataset_output_phase(registry):
    from kedro_intercept._api import intercept_node as _intercept_node

    fn = MagicMock()
    node = _make_node(outputs=["predictions"])
    _intercept_node(node, registry=registry, after_dataset_saved=fn)
    assert fn in registry._registry["after_dataset_saved"]["predictions"]


def test_intercept_node_dataset_input_phase(registry):
    from kedro_intercept._api import intercept_node as _intercept_node

    fn = MagicMock()
    node = _make_node(inputs=["raw_data"])
    _intercept_node(node, registry=registry, after_dataset_loaded=fn)
    assert fn in registry._registry["after_dataset_loaded"]["raw_data"]


def test_intercept_node_dataset_dict_applies_only_to_named(registry):
    from kedro_intercept._api import intercept_node as _intercept_node

    fn1, fn2 = MagicMock(), MagicMock()
    node = _make_node(outputs=["out1", "out2"])
    _intercept_node(
        node, registry=registry, after_dataset_saved={"out1": fn1, "out2": fn2}
    )
    assert fn1 in registry._registry["after_dataset_saved"]["out1"]
    assert fn2 in registry._registry["after_dataset_saved"]["out2"]


def test_intercept_node_returns_node(registry):
    from kedro_intercept._api import intercept_node as _intercept_node

    node = _make_node()
    result = _intercept_node(node, registry=registry, before_pipeline_run=MagicMock())
    assert result is node


def test_intercept_node_multiple_callables_via_list(registry):
    from kedro_intercept._api import intercept_node as _intercept_node

    fn1, fn2 = MagicMock(), MagicMock()
    _intercept_node(_make_node(), registry=registry, before_pipeline_run=[fn1, fn2])
    assert fn1 in registry._global_registry["before_pipeline_run"]
    assert fn2 in registry._global_registry["before_pipeline_run"]


# ---------------------------------------------------------------------------
# InterceptorRegistry dispatch
# ---------------------------------------------------------------------------


def test_dispatch_before_pipeline_run(registry):
    fn = MagicMock()
    registry.intercept("before_pipeline_run", fn)
    registry.before_pipeline_run(
        run_params={}, pipeline=MagicMock(), catalog=MagicMock()
    )
    fn.assert_called_once()


def test_dispatch_before_node_run(registry):
    fn = MagicMock()
    registry.intercept("before_node_run", fn, name="my_node")
    registry.before_node_run(
        node=_make_node("my_node"),
        catalog=MagicMock(),
        inputs={},
        is_async=False,
        run_id="x",
    )
    fn.assert_called_once()


def test_dispatch_skips_other_nodes(registry):
    fn = MagicMock()
    registry.intercept("before_node_run", fn, name="other_node")
    registry.before_node_run(
        node=_make_node("my_node"),
        catalog=MagicMock(),
        inputs={},
        is_async=False,
        run_id="x",
    )
    fn.assert_not_called()


def test_hook_receives_only_declared_params(registry):
    """Functions only receive the kwargs they declare."""
    received = {}

    def fn(node):
        received["node"] = node

    node = _make_node("my_node")
    registry.intercept("before_node_run", fn, name="my_node")
    registry.before_node_run(
        node=node, catalog=MagicMock(), inputs={}, is_async=False, run_id="x"
    )
    assert received["node"] is node


def test_non_assert_hook_does_not_raise_on_error(registry):
    registry.intercept(
        "before_pipeline_run", MagicMock(side_effect=RuntimeError("boom"))
    )
    registry.before_pipeline_run(
        run_params={}, pipeline=MagicMock(), catalog=MagicMock()
    )


def test_assert_hook_raises_on_error(registry):
    registry.intercept(
        "assert_before_pipeline_run", MagicMock(side_effect=RuntimeError("boom"))
    )
    with pytest.raises(RuntimeError, match="boom"):
        registry.before_pipeline_run(
            run_params={}, pipeline=MagicMock(), catalog=MagicMock()
        )


def test_catalog_initialized_to_none():
    r = InterceptorRegistry()
    assert r.catalog is None


# ---------------------------------------------------------------------------
# Smoke
# ---------------------------------------------------------------------------


def test_version():
    assert kedro_intercept.__version__ != "unknown"
