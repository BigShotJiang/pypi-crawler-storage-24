<div align="center">
  <img src="frontend/public/logo.svg" alt="NVCurve Logo" width="128" />
  <h1>NVCurve</h1>
  <p><strong>A native Linux NVIDIA GPU V/F Curve Editor & Overclocking Tool</strong></p>
</div>

---

NVCurve is a Linux-native GPU overclocking tool, providing MSI Afterburner-like per-point voltage-frequency curve control for NVIDIA GPUs. It uses undocumented NvAPI functions via `libnvidia-api.so` for exact hardware-level tuning.

It features both a robust Python CLI and a modern React web interface for interactive curve editing, profile management, and live hardware monitoring.

> [!WARNING]
> **This tool is experimental.** It has only been verified on an **RTX 5090** with driver **580.126.18**. Compatibility with other GPUs and driver versions is unknown. The underlying NvAPI functions are undocumented and unsupported by NVIDIA — they can change or disappear between driver releases.
>
> Read operations are generally safe. Write operations alter GPU frequency offsets at a hardware level. **Follow the first-time setup steps below before applying any changes**, and proceed with caution.
>
> **Disable other overclocking tools** (LACT, GreenWithEnvy, any NVML-based utilities) before using NVCurve. They write to the same clock boost table and will silently overwrite each other's changes.

## Features

- **Per-Point Curve Editing**: Independently adjust the frequency offset for any point on the GPU's voltage-frequency curve.
- **Modern Web UI**: Interactive visual curve editor, point table, and real-time monitoring dashboard.
- **Live Monitoring**: Tracks GPU voltage, clock speed, temperature, and power draw using both NvAPI and NVML.
- **Profile Management**: Save and load clock settings.
- **CLI Support**: Full terminal interface for scripting and headless use.

## Prerequisites

- **OS**: Linux
- **GPU**: NVIDIA GPU (Tested on RTX 5090 Blackwell architecture)
- **Python**: 3.12+
- **Privileges**: NVCurve requires `root` access for hardware interactions. The CLI will automatically prompt for elevated privileges via `sudo` when needed.

## Installation

```bash
uv tool install nvcurve
```

*For frontend development, use `pnpm install` and `pnpm run dev` in the `frontend/` directory.*

## Getting started

### Step 1 — Verify hardware compatibility (CLI)

Before touching anything, use the CLI to confirm NvAPI is working correctly on your GPU and driver. **Do not skip this if you are on an untested configuration.**

Check that all required NvAPI functions resolve:

```bash
nvcurve read --diag
```

All entries under `=== Function probe ===` should show `resolved`. If any critical functions show `NOT FOUND`, write operations will not work and the tool is not supported on your system.

Read your current curve to establish a baseline:

```bash
nvcurve read
```

Run a single-point write-and-verify cycle with a small, safe offset to confirm the write path works end-to-end:

```bash
nvcurve verify --point 80 --delta 15
```

This writes `+15 MHz` to point 80, reads it back, and reports whether the driver accepted the change — including whether any other points were unexpectedly modified. If this passes cleanly, writes are working correctly on your system.

Restore the baseline afterwards:

```bash
nvcurve snapshot restore
```

Only continue once `verify` reports success.

### Step 2 — Launch the web UI

Once you've confirmed compatibility, the web UI is the primary interface for curve editing, live monitoring, and profile management. Run with no arguments to start the server and open it in your browser:

```bash
nvcurve
```

To run the server in the background:

```bash
nvcurve serve start --detach
nvcurve serve status
nvcurve serve stop
```

Then navigate to `http://localhost:8042`.

## CLI reference

The CLI is useful for scripting, headless systems, or quick one-off operations. All write commands support `--dry-run` to preview changes without applying them.

### Reading

```bash
nvcurve read                   # Condensed V/F curve
nvcurve read --full            # All 128 points
nvcurve read --json            # JSON output
```

### Writing

> [!NOTE]
> If you use LACT, GreenWithEnvy, or similar tools, disable them first — they share the same clock boost table and changes will overwrite each other.

```bash
# Use --dry-run to preview things first
nvcurve write --global --delta 50 --dry-run
nvcurve write --point 80 --delta 100 --dry-run

# Apply
nvcurve write --global --delta 50
nvcurve write --point 80 --delta 100
nvcurve write --range 70-90 --delta 75
nvcurve write --reset          # Reset all offsets to 0
```

Snapshots are saved automatically before each write. Manual snapshot management:

```bash
nvcurve snapshot save
nvcurve snapshot list
nvcurve snapshot restore
```

### Profiles

```bash
nvcurve profile save --name balanced
nvcurve profile apply --name balanced
nvcurve profile list
```

### Diagnostics

```bash
nvcurve read --diag            # Probe all NvAPI functions
nvcurve inspect --point 80     # Raw buffer fields for a point
nvcurve inspect --range 78-82
```

## Architecture

NVCurve is split into two primary components:
1. **Python API Backend (`nvcurve/`)**: Interfaces directly with `libnvidia-api.so` (via ctypes) and `libnvidia-ml.so` to read/write hardware states. It exposes these mechanisms via a FastAPI REST+WebSocket server to provide privilege isolation.
2. **React Frontend (`frontend/`)**: A rich interactive GUI running in the browser, communicating with the root backend remotely.

## Disclaimer

This software is experimental and provided as-is. The NvAPI functions it uses are undocumented, unsupported by NVIDIA, and may change or break without notice between driver versions. It has only been verified on a single GPU (RTX 5090) and driver version (580.126.18) — behaviour on other hardware is unknown. Write operations alter GPU state at a hardware level. The authors accept no responsibility for hardware damage, system instability, or data loss resulting from the use of this software.
