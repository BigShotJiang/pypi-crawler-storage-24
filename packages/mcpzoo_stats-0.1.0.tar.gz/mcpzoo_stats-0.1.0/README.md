# mcpzoo-stats

> 统计计算 — 计算一组数字的平均值中位数标准差等

## Installation

```bash
uvx mcpzoo-stats
```

## uvx JSON

```json
{
  "mcpServers": {
    "stats": {
      "args": ["mcpzoo-stats"],
      "command": "uvx"
    }
  }
}
```
