import statistics
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("stats")

@mcp.tool()
def calc_stats(numbers: str, separator: str = ",") -> str:
    """计算一组数字的平均值、中位数、标准差等。"""
    try:
        nums = [float(x.strip()) for x in numbers.split(separator) if x.strip()]
        if not nums:
            return "没有提取到有效数字"
    except ValueError as e:
        return f"数字解析失败: {e}"
        
    count = len(nums)
    mean = sum(nums) / count
    total = sum(nums)
    
    res = [
        f"数量: {count}",
        f"总和: {total}",
        f"平均值(Mean): {mean}",
        f"中位数(Median): {statistics.median(nums)}",
        f"最小值: {min(nums)}",
        f"最大值: {max(nums)}"
    ]
    
    if count > 1:
        res.append(f"方差(Variance): {statistics.variance(nums)}")
        res.append(f"标准差(StdDev): {statistics.stdev(nums)}")
        
    try:
        res.append(f"众数(Mode): {statistics.mode(nums)}")
    except statistics.StatisticsError:
        pass # 无唯一众数
        
    return "\n".join(res)

def main():
    mcp.run()

if __name__ == "__main__":
    main()
