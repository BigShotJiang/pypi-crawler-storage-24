# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowPrivateModuleVersionMetadataRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'client_request_id': 'str',
        'module_name': 'str',
        'module_id': 'str',
        'module_version': 'str'
    }

    attribute_map = {
        'client_request_id': 'Client-Request-Id',
        'module_name': 'module_name',
        'module_id': 'module_id',
        'module_version': 'module_version'
    }

    def __init__(self, client_request_id=None, module_name=None, module_id=None, module_version=None):
        r"""ShowPrivateModuleVersionMetadataRequest

        The model defined in huaweicloud sdk

        :param client_request_id: 用户指定的，对于此请求的唯一Id，用于定位某个请求，推荐使用UUID
        :type client_request_id: str
        :param module_name: 私有模块（private-module）的名字。此名字在domain_id+region下应唯一，可以使用中文、大小写英文、数字、下划线、中划线。首字符需为中文或者英文，区分大小写。
        :type module_name: str
        :param module_id: 私有模块（private-module）的唯一Id。  此Id由资源编排服务在生成模块的时候生成，为UUID。  由于私有模块名称仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的私有模块，删除，再重新创建一个同名私有模块。  对于团队并行开发，用户可能希望确保，当前我操作的私有模块就是我认为的那个，而不是其他队友删除后创建的同名私有模块。因此，使用Id就可以做到强匹配。  资源编排服务保证每次创建的私有模块所对应的Id都不相同，更新不会影响Id。如果给予的module_id和当前模块的Id不一致，则返回400
        :type module_id: str
        :param module_version: 模块的版本号。版本号遵循语义化版本号（Semantic Version），为用户自定义
        :type module_version: str
        """
        
        

        self._client_request_id = None
        self._module_name = None
        self._module_id = None
        self._module_version = None
        self.discriminator = None

        self.client_request_id = client_request_id
        self.module_name = module_name
        if module_id is not None:
            self.module_id = module_id
        self.module_version = module_version

    @property
    def client_request_id(self):
        r"""Gets the client_request_id of this ShowPrivateModuleVersionMetadataRequest.

        用户指定的，对于此请求的唯一Id，用于定位某个请求，推荐使用UUID

        :return: The client_request_id of this ShowPrivateModuleVersionMetadataRequest.
        :rtype: str
        """
        return self._client_request_id

    @client_request_id.setter
    def client_request_id(self, client_request_id):
        r"""Sets the client_request_id of this ShowPrivateModuleVersionMetadataRequest.

        用户指定的，对于此请求的唯一Id，用于定位某个请求，推荐使用UUID

        :param client_request_id: The client_request_id of this ShowPrivateModuleVersionMetadataRequest.
        :type client_request_id: str
        """
        self._client_request_id = client_request_id

    @property
    def module_name(self):
        r"""Gets the module_name of this ShowPrivateModuleVersionMetadataRequest.

        私有模块（private-module）的名字。此名字在domain_id+region下应唯一，可以使用中文、大小写英文、数字、下划线、中划线。首字符需为中文或者英文，区分大小写。

        :return: The module_name of this ShowPrivateModuleVersionMetadataRequest.
        :rtype: str
        """
        return self._module_name

    @module_name.setter
    def module_name(self, module_name):
        r"""Sets the module_name of this ShowPrivateModuleVersionMetadataRequest.

        私有模块（private-module）的名字。此名字在domain_id+region下应唯一，可以使用中文、大小写英文、数字、下划线、中划线。首字符需为中文或者英文，区分大小写。

        :param module_name: The module_name of this ShowPrivateModuleVersionMetadataRequest.
        :type module_name: str
        """
        self._module_name = module_name

    @property
    def module_id(self):
        r"""Gets the module_id of this ShowPrivateModuleVersionMetadataRequest.

        私有模块（private-module）的唯一Id。  此Id由资源编排服务在生成模块的时候生成，为UUID。  由于私有模块名称仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的私有模块，删除，再重新创建一个同名私有模块。  对于团队并行开发，用户可能希望确保，当前我操作的私有模块就是我认为的那个，而不是其他队友删除后创建的同名私有模块。因此，使用Id就可以做到强匹配。  资源编排服务保证每次创建的私有模块所对应的Id都不相同，更新不会影响Id。如果给予的module_id和当前模块的Id不一致，则返回400

        :return: The module_id of this ShowPrivateModuleVersionMetadataRequest.
        :rtype: str
        """
        return self._module_id

    @module_id.setter
    def module_id(self, module_id):
        r"""Sets the module_id of this ShowPrivateModuleVersionMetadataRequest.

        私有模块（private-module）的唯一Id。  此Id由资源编排服务在生成模块的时候生成，为UUID。  由于私有模块名称仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的私有模块，删除，再重新创建一个同名私有模块。  对于团队并行开发，用户可能希望确保，当前我操作的私有模块就是我认为的那个，而不是其他队友删除后创建的同名私有模块。因此，使用Id就可以做到强匹配。  资源编排服务保证每次创建的私有模块所对应的Id都不相同，更新不会影响Id。如果给予的module_id和当前模块的Id不一致，则返回400

        :param module_id: The module_id of this ShowPrivateModuleVersionMetadataRequest.
        :type module_id: str
        """
        self._module_id = module_id

    @property
    def module_version(self):
        r"""Gets the module_version of this ShowPrivateModuleVersionMetadataRequest.

        模块的版本号。版本号遵循语义化版本号（Semantic Version），为用户自定义

        :return: The module_version of this ShowPrivateModuleVersionMetadataRequest.
        :rtype: str
        """
        return self._module_version

    @module_version.setter
    def module_version(self, module_version):
        r"""Sets the module_version of this ShowPrivateModuleVersionMetadataRequest.

        模块的版本号。版本号遵循语义化版本号（Semantic Version），为用户自定义

        :param module_version: The module_version of this ShowPrivateModuleVersionMetadataRequest.
        :type module_version: str
        """
        self._module_version = module_version

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowPrivateModuleVersionMetadataRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
