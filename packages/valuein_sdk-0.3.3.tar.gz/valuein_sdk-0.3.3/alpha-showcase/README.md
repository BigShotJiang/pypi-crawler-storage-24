# SEC Alpha Showcase: Institutional Grade Financial Data

Welcome to the SEC Alpha Showcase. This repository provides executable engineering scripts and analytical modules demonstrating how to extract alpha from our high-fidelity, dual-exported SEC data feed.

Our pipeline parses, standardizes, and delivers point-in-time SEC filings (10-K, 10-Q, 8-K, 20-F and their amendments) mapped to the S&P 500 (Sample Dataset) and the broader US equity market (Production) since 1990. Delivered via ZSTD-compressed Parquet files hosted on Cloudflare R2, our architecture enables lightning-fast, zero-copy analytics using highly efficient columnar engines like DuckDB.

---

## 🏛️ The Architecture: Zero-Copy Cloud Data Lake

Institutional data engineering is traditionally plagued by massive ETL pipelines, redundant storage costs, and stale database syncs. We bypassed this entirely by separating storage from compute.

Our delivery mechanism allows your quantitative and fundamental teams to query over **105 million standardized financial facts in milliseconds, directly over the network, with zero local storage required.**

* **The Storage (Cloudflare R2):** Data is exported daily into heavily compressed, columnar Parquet files via a Blue/Green deployment model. A dynamic `manifest.json` ensures you are always querying the latest immutable snapshot with zero downtime.
* **The Compute (DuckDB + PyArrow):** Using the `httpfs` extension, DuckDB executes queries directly against our R2 bucket. Because Parquet is columnar, DuckDB only downloads the specific bytes required for your query—not the whole file.
* **The Result:** You can run complex cross-sectional backtests across the entire US equity market directly from a Jupyter Notebook on your laptop, without downloading a single megabyte to your local hard drive.

---

## 🏗️ Repository Structure

This showcase is divided into four domains tailored to specific institutional workflows:

### 1. 🛡️ Quality Assurance & Proofs (`/quality_proof`)
Quants require pristine data. These scripts execute directly against our dataset to prove the absence of systemic data errors.
* **`01_survivorship_bias_proof.py`**: Proves the dataset retains complete financial histories for defunct, bankrupt, and acquired companies (historical S&P 500 constituents).
* **`02_point_in_time_proof.py`**: Proves strict Point-In-Time (PIT) architecture by calculating the exact "Reporting Lag" between a fiscal `period_end` and the public `filing_date` to guarantee no look-ahead bias.

### 2. 📊 Quantitative Research (`/quantitative_analysis`)
For Systematic Quants running cross-sectional backtests and signal generation.
* **`01_piotroski_f_score_backtest.py`**: Calculates the 9-point Piotroski F-Score utilizing window functions across the entire universe simultaneously to identify value stocks with improving financial health.
* **`02_post_earnings_announcement_drift.py`**: Evaluates Post-Earnings Announcement Drift (PEAD) by joining point-in-time SEC EPS data with trailing market pricing.

### 3. 💼 Fundamental Analysis (`/fundamental_analysis`)
For discretionary Equity Analysts focusing on deep company teardowns.
* **`01_sp500_value_screener.py`**: A cross-sectional screener joining facts and SEC taxonomy maps to identify high Free Cash Flow yield and conservative leverage.
* **`02_dcf_and_roic_teardown.py`**: Reconstructs a historical Return on Invested Capital (ROIC) trendline for a single ticker to quantitatively assess economic moats.

### 4. 🛠️ Data Engineering (`/engineering`)
For Data Engineers integrating our feed into local data lakes or cloud warehouses.
* **`r2_inspector.py`**: Query the live Cloudflare R2 bucket directly over the network using DuckDB.
* **`bulk_sync_to_local.py`**: A pure-Python Boto3 script to safely and incrementally mirror the latest daily release to your local storage.

---

### 3. Running the Showcases

The showcases in this repository are provided as interactive Python scripts formatted with # %% markers (Scientific Mode).

* Using PyCharm / VS Code: Open any .py file in the notebooks/ directories. Your IDE will recognize the # %% markers and allow you to run the file cell-by-cell interactively.

* Using Jupyter: If you prefer standard .ipynb files, you can easily convert the provided scripts using jupytext:

```bash
pip install jupytext
jupytext --to notebook engineering/notebooks/quickstart.py
```

## Data Schema Overview

The dataset is fully normalized for institutional quantitative research. It separates the legal entity from the tradeable security, tracks filing metadata, and provides a strictly Point-in-Time (PiT) fact table for fundamental metrics.


### 1. `entity` (The Legal Structure)
Tracks the corporate metadata for the issuing company.
* **Primary Key:** `cik` (Central Index Key)

| Column | Type | Description |
| :--- | :--- | :--- |
| `cik` | String | The 10-digit SEC identifier. |
| `name` / `lei` / `ein` | String | Corporate name and legal identifiers. |
| `industry` / `sector` / `sic_code` | String | Standardized industry classifications. |
| `fiscal_year_end` | String | The month and day the fiscal year ends. |
| `status` | String | Active or inactive status of the entity. |

### 2. `security` (The Tradeable Instrument)
Maps point-in-time ticker symbols and identifiers to the legal entity. This handles ticker changes and delistings gracefully.
* **Primary Key:** `id`
* **Foreign Key:** `entity_id` -> `entity.cik`

| Column | Type | Description |
| :--- | :--- | :--- |
| `symbol` / `exchange` | String | The trading ticker and listed exchange. |
| `figi` / `composite_figi` | String | Financial Instrument Global Identifiers. |
| `valid_from` / `valid_to` | Date | The exact date range this symbol was active. |
| `is_active` | Boolean | Auto-generated flag for currently active tickers. |

### 3. `filing` (Submission Metadata)
Contains the metadata for the actual document submitted to the SEC.
* **Primary Key:** `accession_id`
* **Foreign Key:** `entity_id` -> `entity.cik`

| Column | Type | Description |
| :--- | :--- | :--- |
| `accession_id` | String | The unique SEC filing identifier. |
| `form_type` | String | The document type (e.g., `10-K`, `10-Q`, `8-K`). |
| `filing_date` / `report_date` | Date | When it was filed vs. the period it covers. |
| `accepted_at` | Timestamp | The exact time the SEC accepted the filing. |

### 4. `fact` (Fundamental Data Points)
The core time-series table containing all extracted accounting metrics. Partitioned by `period_end` for high-performance querying.

| Column | Type | Description |
| :--- | :--- | :--- |
| `concept` | String | The raw XBRL tag from the filing. |
| `standard_concept` | String | The mapped, normalized accounting concept. |
| `numeric_value` / `value` | Float / String | The extracted value (numeric or text). |
| `unit` | String | The unit of measurement (e.g., `USD`, `shares`). |
| `period_start` / `period_end` | Date | The exact accounting period the metric covers. |
| `frame` | String | Standardized SEC frame (e.g., `CY2023Q1`). |
| `knowledge_at` | Timestamp | **CRITICAL:** The exact microsecond the data became public. Use this to prevent look-ahead bias. |

### 5. Reference Tables
Helper tables designed to map raw SEC XBRL tags to standardized institutional metrics and track index components.

* **`index_membership`**: Tracks which securities belonged to which indices (e.g., S&P 500) at specific point-in-time dates (`start_date` / `end_date`).
* **`concept_mapping`**: Maps messy, raw `xbrl_tag` variations into a single `standard_concept`.
* **`taxonomy_guide`**: A data dictionary defining every `standard_concept`, including its `balance_type` (debit/credit) and human-readable definitions.

---

## Advanced: The Point-in-Time Join

To build a robust quantitative backtest, you must join the fundamental metrics with the historically accurate ticker symbol active at the exact time of the filing.

Because companies change tickers (e.g., Facebook changing from FB to META), joining purely on today's ticker introduces look-ahead bias. Our `security` table tracks the exact `valid_from` and `valid_to` dates for every ticker.

Below is an example using DuckDB to extract a clean, Point-in-Time time-series of Net Income for a specific company, ensuring we capture the exact ticker symbol the market was trading on the day the filing dropped.


```python
import duckdb

# Assuming your R2 credentials and latest_path are already configured in DuckDB...

pit_query = f"""
    SELECT 
        s.symbol AS historical_ticker,
        f.standard_concept,
        f.numeric_value AS value,
        f.unit,
        f.period_end,
        fil.form_type,
        f.knowledge_at AS market_aware_timestamp
    FROM read_parquet('r2://{BUCKET}/{latest_path}fact/*.parquet') f
    
    -- 1. Join Document Metadata
    JOIN read_parquet('r2://{BUCKET}/{latest_path}filing/*.parquet') fil 
      ON f.accession_id = fil.accession_id
      
    -- 2. Join Historical Security Data
    JOIN read_parquet('r2://{BUCKET}/{latest_path}security/*.parquet') s 
      ON f.entity_id = s.entity_id
      
    WHERE f.standard_concept = 'NetIncomeLoss'
      AND f.frame LIKE 'CY%' -- Annual data only
      
      -- 3. The Point-in-Time Ticker Constraint
      -- This ensures we only map the ticker that was active at the exact moment the filing became public.
      AND f.knowledge_at >= s.valid_from 
      AND (s.valid_to IS NULL OR f.knowledge_at <= s.valid_to)
      
      -- Filter for a specific company using its permanent CIK
      AND f.entity_id = '0000320193' 
      
    ORDER BY f.knowledge_at DESC
    LIMIT 5;
"""

df_historical = con.execute(pit_query).df()
print(df_historical)
