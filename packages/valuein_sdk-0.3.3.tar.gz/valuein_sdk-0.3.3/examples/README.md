# Valuein US Core Fundamentals — Examples

> **Start here →** `getting_started.py` → `notebooks/quickstart.ipynb` → pick your topic below.

---

## Python Scripts

| File | Description | Tables loaded | Difficulty |
|------|-------------|---------------|------------|
| [`getting_started.py`](getting_started.py) | First script to run. Auth check, row counts, AAPL lookup. | `entity`, `security` | Beginner |
| [`usage.py`](usage.py) | Reference walkthrough of every SDK method. | `entity`, `security`, `filing`, `taxonomy_guide`, `fact` | Beginner |
| [`01_entity_screening.py`](01_entity_screening.py) | Screen the universe by sector, SIC code, and status. | `entity`, `security` | Intermediate |
| [`02_financial_analysis.py`](02_financial_analysis.py) | Revenue trends, balance sheet, margins, concept normalisation. | `entity`, `security`, `filing`, `fact`, `concept_mapping` | Intermediate |
| [`03_pit_backtest.py`](03_pit_backtest.py) | Point-in-Time demo. PIT-correct vs look-ahead-biased queries. | `security`, `filing`, `fact` | Advanced |
| [`04_survivorship_bias.py`](04_survivorship_bias.py) | Bankrupt and delisted company data. Why omitting them is dangerous. | `entity`, `security`, `filing`, `fact` | Advanced |

---

## Jupyter Notebooks

| Notebook | Description | Open in Colab |
|----------|-------------|---------------|
| [`notebooks/quickstart.ipynb`](notebooks/quickstart.ipynb) | Notebook version of `getting_started.py`. Step-by-step with markdown. | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/valuein/quants/blob/main/examples/notebooks/quickstart.ipynb) |
| [`notebooks/fundamental_analysis.ipynb`](notebooks/fundamental_analysis.ipynb) | Mag 7 revenue trend, income statement, concept_mapping, $10B screen. | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/valuein/quants/blob/main/examples/notebooks/fundamental_analysis.ipynb) |
| [`notebooks/pit_backtest.ipynb`](notebooks/pit_backtest.ipynb) | Flagship PIT notebook. Restatements, correct vs incorrect query patterns. | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/valuein/quants/blob/main/examples/notebooks/pit_backtest.ipynb) |
| [`notebooks/survivorship_bias.ipynb`](notebooks/survivorship_bias.ipynb) | Dead company data. Scale, notable bankruptcies, sector failure rates. | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/valuein/quants/blob/main/examples/notebooks/survivorship_bias.ipynb) |

---

## Prerequisites

```bash
pip install valuein-sdk
export VALUEIN_API_KEY="your_token_here"
```

Get a token at [valuein.biz](https://valuein.biz).

---

## Key concepts

**`tables=` parameter** — always pass only the tables you need. Loading the full `fact` table takes longer; load it only when you need financials.

**PIT rule** — always filter by `filing_date <= trade_date`, never by `report_date`. See `03_pit_backtest.py` and `notebooks/pit_backtest.ipynb`.

**`standard_concept`** — one canonical name for each financial metric, across all 10,000+ companies. Powered by the `concept_mapping` table.
