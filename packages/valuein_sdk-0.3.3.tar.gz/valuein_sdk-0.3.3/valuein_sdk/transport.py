# Copyright 2026 Valuein Data Engineering
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""HTTP transport layer for the Valuein SDK.

Wraps httpx with:
- Bearer token auth on every request
- 30s connect / 120s read timeouts
- Retry with exponential backoff + jitter (3 attempts) on transient errors
- Gateway HTTP status codes mapped to the custom exception hierarchy
"""

from __future__ import annotations

import logging
import random
import time

import httpx

from .exceptions import (
    ValueinAPIError,
    ValueinAuthError,
    ValueinNotFoundError,
    ValueinPlanError,
    ValueinRateLimitError,
)

logger = logging.getLogger("valuein_sdk")

_CONNECT_TIMEOUT = 30.0  # seconds
_READ_TIMEOUT = 120.0  # seconds — large Parquet files need headroom
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0  # seconds; actual delay = base * 2^attempt + jitter

# Status codes that are safe to retry (transient server/network errors)
_RETRYABLE_STATUS = {429, 502, 503, 504}


def _backoff(attempt: int) -> float:
    """Return exponential backoff delay with jitter for a given attempt (0-indexed)."""
    return _RETRY_BASE_DELAY * (2**attempt) + random.uniform(0.0, 0.5)


def _raise_for_status(response: httpx.Response) -> None:
    """Map gateway HTTP status codes to Valuein exceptions.

    Args:
        response: The httpx Response object to inspect.

    Raises:
        ValueinAuthError: On HTTP 401 or 403 for auth issues.
        ValueinPlanError: On HTTP 403 for plan-gating.
        ValueinNotFoundError: On HTTP 404.
        ValueinRateLimitError: On HTTP 429, includes retry_after if header present.
        ValueinAPIError: On any other non-2xx status.
    """
    code = response.status_code

    if code == 401:
        raise ValueinAuthError("Invalid API key. Check your token at valuein.biz/portal.")
    if code == 402:
        raise ValueinAuthError("Account suspended — payment required. Visit valuein.biz/portal.")
    if code == 403:
        body = response.text.lower()
        if "plan" in body or "upgrade" in body or "full" in body:
            raise ValueinPlanError(
                "This resource requires a Full Dataset plan. Upgrade at valuein.biz/pricing."
            )
        raise ValueinAuthError("API token has been revoked. Resubscribe at valuein.biz/pricing.")
    if code == 400:
        try:
            url_str = str(response.url)
        except Exception:
            url_str = "unknown"
        raise ValueinNotFoundError(f"Unknown table name: {url_str}")
    if code == 404:
        try:
            url_str = str(response.url)
        except Exception:
            url_str = "unknown"
        raise ValueinNotFoundError(f"Resource not found: {url_str}")
    if code == 429:
        retry_after_raw = response.headers.get("Retry-After")
        retry_after = (
            int(retry_after_raw) if retry_after_raw and retry_after_raw.isdigit() else None
        )
        msg = "Rate limited by the Valuein gateway."
        if retry_after:
            msg += f" Retry after {retry_after}s."
        raise ValueinRateLimitError(msg, retry_after=retry_after)

    if code >= 500:
        raise ValueinAPIError(
            f"Gateway server error (HTTP {code}). Try again shortly.",
            status_code=code,
        )

    if not (200 <= code < 300):
        raise ValueinAPIError(
            f"Unexpected HTTP {code} from gateway.",
            status_code=code,
        )


class Transport:
    """Authenticated HTTP client for the Valuein gateway.

    Args:
        api_key: Valuein Bearer token.
        gateway_url: Base URL of the gateway, without trailing slash.

    Example:
        >>> t = Transport(api_key="tok_...", gateway_url="https://data.valuein.biz")
        >>> data = t.get("/v1/manifest")
    """

    def __init__(self, api_key: str, gateway_url: str) -> None:
        self._api_key = api_key
        self._gateway_url = gateway_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._gateway_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=httpx.Timeout(
                connect=_CONNECT_TIMEOUT, read=_READ_TIMEOUT, write=30.0, pool=30.0
            ),
        )

    # ------------------------------------------------------------------

    def get(self, path: str, stream: bool = False) -> httpx.Response:
        """Perform an authenticated GET request with retry on transient errors.

        Args:
            path: URL path relative to the gateway base URL (e.g. '/v1/manifest').
            stream: If True, return the response without reading the body
                (caller is responsible for closing).

        Returns:
            An httpx.Response with a 2xx status code.

        Raises:
            ValueinAuthError: Token invalid/revoked/account suspended.
            ValueinPlanError: Resource requires higher-tier plan.
            ValueinNotFoundError: Resource does not exist.
            ValueinRateLimitError: Too many requests.
            ValueinAPIError: Any other non-2xx or unexpected error.
            ConnectionError: Could not reach the gateway.
        """
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES):
            try:
                if stream:
                    response = self._client.send(
                        self._client.build_request("GET", path),
                        stream=True,
                    )
                else:
                    response = self._client.get(path)

                # Raise immediately on non-retryable errors
                if response.status_code not in _RETRYABLE_STATUS:
                    _raise_for_status(response)
                    return response

                # Retryable status — raise on final attempt, else back off
                _raise_for_status(response)  # will raise ValueinRateLimitError / ValueinAPIError

            except (ValueinAuthError, ValueinPlanError, ValueinNotFoundError):
                # Never retry auth/plan/404 errors
                raise
            except ValueinRateLimitError as exc:
                last_exc = exc
                delay = exc.retry_after or _backoff(attempt)
                logger.warning(
                    "Rate limited; retrying in %.1fs (attempt %d/%d)",
                    delay,
                    attempt + 1,
                    _MAX_RETRIES,
                )
                time.sleep(delay)
            except ValueinAPIError as exc:
                last_exc = exc
                delay = _backoff(attempt)
                logger.warning(
                    "Transient gateway error; retrying in %.1fs (attempt %d/%d)",
                    delay,
                    attempt + 1,
                    _MAX_RETRIES,
                )
                time.sleep(delay)
            except httpx.ConnectError as exc:
                raise ConnectionError(
                    f"Could not reach the Valuein gateway at {self._gateway_url}. "
                    "Check your internet connection."
                ) from exc
            except httpx.TimeoutException as exc:
                last_exc = exc
                delay = _backoff(attempt)
                logger.warning(
                    "Request timed out; retrying in %.1fs (attempt %d/%d)",
                    delay,
                    attempt + 1,
                    _MAX_RETRIES,
                )
                time.sleep(delay)

        raise ValueinAPIError(
            f"Request failed after {_MAX_RETRIES} attempts: {last_exc}"
        ) from last_exc

    def close(self) -> None:
        """Close the underlying httpx client."""
        self._client.close()

    def __enter__(self) -> Transport:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
