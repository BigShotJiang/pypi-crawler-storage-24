# Copyright 2026 Valuein Data Engineering
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Custom exception hierarchy for the Valuein SDK."""

from __future__ import annotations


class ValueinError(Exception):
    """Base class for all Valuein SDK errors."""


class ValueinAuthError(ValueinError):
    """Raised when the API token is invalid, expired, or revoked.

    HTTP 401 or 403 from the gateway.

    Example:
        >>> raise ValueinAuthError("Invalid API key. Check your token at valuein.biz/portal.")
    """


class ValueinPlanError(ValueinError):
    """Raised when the requested resource requires a higher-tier plan.

    HTTP 403 on a full-dataset endpoint with an sp500 token.

    Example:
        >>> raise ValueinPlanError("Table 'fact' requires a Full Dataset plan.")
    """


class ValueinNotFoundError(ValueinError):
    """Raised when a requested resource does not exist (HTTP 404).

    Example:
        >>> raise ValueinNotFoundError("Table 'unknown' not found.")
    """


class ValueinRateLimitError(ValueinError):
    """Raised when the gateway returns HTTP 429 (Too Many Requests).

    Attributes:
        retry_after: Seconds to wait before retrying, if provided by the server.

    Example:
        >>> raise ValueinRateLimitError("Rate limited. Retry after 30s.", retry_after=30)
    """

    def __init__(self, message: str, retry_after: int | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class ValueinAPIError(ValueinError):
    """Raised for unexpected server-side errors (HTTP 5xx or unhandled status codes).

    Attributes:
        status_code: The HTTP status code returned by the gateway, if available.

    Example:
        >>> raise ValueinAPIError("Gateway error: 502 Bad Gateway", status_code=502)
    """

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
