# Copyright 2026 Valuein Data Engineering
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Valuein SDK — Python client for US Core Fundamentals data.

The client authenticates against the Valuein edge gateway, discovers the
user's plan and current data snapshot, then downloads Parquet tables into
an in-process DuckDB instance for zero-latency SQL analytics.

Users never interact with storage directly.  The gateway resolves the
correct bucket, snapshot folder, and Parquet path from the token alone.
"""

from __future__ import annotations

import contextlib
import importlib.resources as pkg_resources
import io
import logging
import os
import time
import warnings
from typing import Any

import duckdb
import pandas as pd
import pyarrow.parquet as pq
from dotenv import load_dotenv

from .exceptions import (
    ValueinAuthError,
    ValueinPlanError,
)
from .transport import Transport

_logger = logging.getLogger("valuein_sdk")

_DEFAULT_GATEWAY = "https://data.valuein.biz"

# The 7 tables the edge-gateway exposes.  Used as fallback only when
# the manifest does not include a "tables" key.
_KNOWN_TABLES = frozenset(
    [
        "entity",
        "security",
        "filing",
        "fact",
        "taxonomy_guide",
        "index_membership",
    ]
)


class ValueinClient:
    """Client for the Valuein Financial Data API.

    Connects to the Valuein edge gateway, authenticates with a Bearer
    token, and loads Parquet tables into DuckDB for SQL querying.

    The gateway determines which data you can access based on your token's
    plan — you never need to specify a bucket, snapshot, or file path.

    Args:
        api_key: Valuein API token.  Falls back to the ``VALUEIN_API_KEY``
            environment variable or a ``.env`` file in the working directory.
        gateway_url: Override the gateway URL (development only).
        tables: Restrict which tables are loaded at init.  Pass a subset
            like ``["entity", "security"]`` for faster startup.  ``None``
            loads every table the manifest advertises.  An empty list
            (``[]``) skips all table loading — useful for health checks.

    Raises:
        ValueError: If no API key is provided or discoverable.
        ConnectionError: If the gateway is unreachable or no tables load.
        ValueinAuthError: If the token is invalid, expired, or revoked.

    Example::

        from valuein_sdk import ValueinClient

        client = ValueinClient()
        print(client)
        # ValueinClient(plan='full', status='active', snapshot='snapshot_20260310', tables=7)

        df = client.query("SELECT count(*) AS n FROM entity")
    """

    # ── Construction ──────────────────────────────────────────────────────

    def __init__(
        self,
        api_key: str | None = None,
        gateway_url: str | None = None,
        tables: list[str] | None = None,
    ) -> None:
        load_dotenv()

        self.api_key: str = api_key or os.getenv("VALUEIN_API_KEY", "")
        if not self.api_key:
            raise ValueError(
                "Missing API key.  Pass it directly:\n"
                "    client = ValueinClient('your_token')\n"
                "or set VALUEIN_API_KEY in your environment / .env file.\n"
                "Register at https://valuein.biz to obtain a token."
            )

        self.gateway_url: str = (
            gateway_url or os.getenv("VALUEIN_GATEWAY_URL") or _DEFAULT_GATEWAY
        ).rstrip("/")

        self._transport = Transport(
            api_key=self.api_key,
            gateway_url=self.gateway_url,
        )

        # ── Discover plan & snapshot ──────────────────────────────────────
        self._me_data: dict[str, Any] = self._fetch_me()
        self._plan: str = self._me_data.get("plan", "sp500")
        self._manifest_data: dict[str, Any] = self._fetch_manifest()

        # ── Resolve table list ────────────────────────────────────────────
        manifest_tables = list(self._manifest_data.get("tables", {}))
        available = manifest_tables if manifest_tables else sorted(_KNOWN_TABLES)

        if tables is not None:
            unknown = set(tables) - set(available)
            if unknown:
                raise ValueError(
                    f"Unknown table(s): {', '.join(sorted(unknown))}. "
                    f"Available: {', '.join(available)}"
                )
            self._tables: list[str] = list(tables)
        else:
            self._tables = available

        # ── DuckDB ────────────────────────────────────────────────────────
        self.con: duckdb.DuckDBPyConnection = duckdb.connect()
        self.query_cache: dict[str, str] = {}

        if self._tables:
            self._load_tables()

        self._build_query_map()

    # ── Gateway calls (private) ───────────────────────────────────────────

    def _fetch_me(self) -> dict[str, Any]:
        """``GET /v1/me`` — token identity and plan."""
        response = self._transport.get("/v1/me")
        return response.json()

    def _fetch_manifest(self) -> dict[str, Any]:
        """``GET /v1/manifest`` — current snapshot and table inventory."""
        response = self._transport.get("/v1/manifest")
        return response.json()

    # ── Table loading ─────────────────────────────────────────────────────

    def _table_endpoint(self, table: str) -> str:
        """Return the gateway path for *table* under the current plan.

        The edge gateway resolves the physical R2 bucket and snapshot
        folder — the SDK only needs to know the plan prefix.
        """
        prefix = "full" if self._plan == "full" else "sp500"
        return f"/v1/{prefix}/{table}"

    def _load_tables(self) -> None:
        """Download Parquet tables and register them in DuckDB.

        Each table is fetched through the authenticated transport layer
        and registered as a named DuckDB table backed by a PyArrow buffer.

        The gateway returns ``503`` when a snapshot upload is in progress;
        the transport layer retries with exponential backoff automatically.

        Raises:
            ConnectionError: If zero tables could be loaded.
        """
        loaded: list[str] = []
        failed: list[str] = []
        t0 = time.monotonic()

        for table in self._tables:
            endpoint = self._table_endpoint(table)
            try:
                response = self._transport.get(endpoint)
                arrow_tbl = pq.read_table(io.BytesIO(response.content))
                self.con.register(table, arrow_tbl)
                loaded.append(table)
                _logger.debug(
                    "Loaded %s (%s rows, %.1f MB)",
                    table,
                    f"{len(arrow_tbl):,}",
                    len(response.content) / 1_048_576,
                )
            except ValueinPlanError:
                _logger.warning("Table '%s' requires a higher plan — skipped", table)
                failed.append(table)
            except Exception as exc:
                warnings.warn(
                    f"Could not load table '{table}': {exc}",
                    stacklevel=2,
                )
                failed.append(table)

        elapsed = time.monotonic() - t0
        _logger.info(
            "Loaded %d/%d tables in %.1fs (plan=%s)",
            len(loaded),
            len(self._tables),
            elapsed,
            self._plan,
        )

        if not loaded:
            raise ConnectionError(
                "No tables could be loaded. Verify your token, plan, and "
                "network connectivity.  Run with tables=[] to skip loading "
                "and diagnose with client.me()."
            )

        # Update internal list to reflect what actually loaded.
        self._tables = loaded

    def _build_query_map(self) -> None:
        """Index bundled SQL templates from ``valuein_sdk/queries/``."""
        self.query_cache = {}
        try:
            queries_root = str(pkg_resources.files("valuein_sdk").joinpath("queries"))
            for dirpath, _, filenames in os.walk(queries_root):
                for fname in filenames:
                    if fname.endswith(".sql"):
                        key = fname.removesuffix(".sql")
                        self.query_cache[key] = os.path.join(dirpath, fname)
        except Exception as exc:
            warnings.warn(f"Could not index SQL templates: {exc}", stacklevel=2)

    # ── Public API ────────────────────────────────────────────────────────

    def me(self) -> dict[str, Any]:
        """Token identity — plan, status, email, and creation date.

        Returns:
            Dict with keys ``plan``, ``status``, ``email``, ``createdAt``.

        Example::

            >>> client.me()
            {'plan': 'full', 'status': 'active', 'email': 'quant@fund.com', ...}
        """
        return dict(self._me_data)

    def manifest(self) -> dict[str, Any]:
        """Current data snapshot metadata (fresh call to the gateway).

        Returns:
            Dict with keys ``snapshot``, ``last_updated``, ``tables``.

        Example::

            >>> client.manifest()
            {'snapshot': 'snapshot_20260310', 'tables': {'entity': '...', ...}}
        """
        return self._fetch_manifest()

    def health(self) -> dict[str, Any]:
        """Gateway liveness probe (no authentication required).

        Returns:
            Dict with key ``ok`` (bool) and ``worker`` identifier.

        Example::

            >>> client.health()
            {'ok': True, 'worker': 'edge-gateway', 'env': 'production'}
        """
        response = self._transport.get("/health")
        return response.json()

    def get(self, table: str) -> pd.DataFrame:
        """Download a full table as a pandas DataFrame (fresh from gateway).

        This bypasses the local DuckDB cache and fetches directly from the
        gateway.  Useful when you need a guaranteed-fresh copy.

        Args:
            table: Table name (e.g. ``"entity"``, ``"fact"``).

        Returns:
            pandas DataFrame with the complete table.

        Raises:
            ValueError: If *table* is not recognised.
            ValueinPlanError: If your plan cannot access this table.

        Example::

            >>> df = client.get("entity")
            >>> df.shape
            (19113, 15)
        """
        all_known = sorted(set(list(self._manifest_data.get("tables", {}))) | _KNOWN_TABLES)
        if table not in all_known:
            raise ValueError(f"Unknown table '{table}'. Available: {', '.join(all_known)}")

        endpoint = self._table_endpoint(table)
        try:
            response = self._transport.get(endpoint)
        except (ValueinAuthError, ValueinPlanError):
            raise
        except Exception as exc:
            raise ConnectionError(f"Failed to download '{table}': {exc}") from exc

        return pq.read_table(io.BytesIO(response.content)).to_pandas()

    def query(self, sql: str) -> pd.DataFrame:
        """Execute SQL against loaded tables using DuckDB.

        All tables loaded at init are available by name.  DuckDB's
        columnar engine applies predicate pushdown and projection
        pruning automatically.

        Args:
            sql: Any valid DuckDB SQL statement.

        Returns:
            pandas DataFrame with query results.

        Example::

            >>> client.query(\"\"\"
            ...     SELECT s.symbol, e.name, e.sector
            ...     FROM security s
            ...     JOIN entity e ON s.entity_id = e.cik
            ...     WHERE s.is_active = TRUE
            ...     LIMIT 10
            ... \"\"\")
        """
        return self.con.execute(sql).df()

    def run_template(self, name: str, **kwargs: object) -> pd.DataFrame:
        """Execute a bundled SQL template by name.

        Templates are ``.sql`` files in ``valuein_sdk/queries/`` using
        Python ``str.format()`` placeholders.  List arguments are
        expanded into quoted ``IN``-list literals automatically.

        Args:
            name: Template name (filename without ``.sql``).
            **kwargs: Template parameters.

        Returns:
            pandas DataFrame with query results.

        Raises:
            FileNotFoundError: If the template does not exist.

        Example::

            >>> client.run_template(
            ...     "01_fundamentals_by_ticker",
            ...     ticker="NVDA",
            ...     form_types=["10-K"],
            ...     metrics=["Revenues"],
            ...     start_date="2020-01-01",
            ...     end_date="2026-01-01",
            ... )
        """
        path = self.query_cache.get(name)
        if not path:
            available = sorted(self.query_cache) or ["(none)"]
            raise FileNotFoundError(
                f"Template '{name}' not found. Available: {', '.join(available)}"
            )

        with open(path) as fh:
            sql = fh.read()

        fmt: dict[str, object] = {}
        for key, val in kwargs.items():
            if isinstance(val, (list, tuple)):
                fmt[key] = ", ".join(f"'{v}'" for v in val)
            else:
                fmt[key] = val

        return self.con.execute(sql.format(**fmt)).df()

    def tables(self) -> list[str]:
        """List of tables currently loaded in DuckDB.

        Returns:
            Sorted list of table name strings.

        Example::

            >>> client.tables()
            ['concept_mapping', 'entity', 'fact', 'filing', ...]
        """
        return sorted(self._tables)

    # ── Dunder ────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"ValueinClient("
            f"plan={self._plan!r}, "
            f"status={self._me_data.get('status', 'unknown')!r}, "
            f"snapshot={self._manifest_data.get('snapshot', 'unknown')!r}, "
            f"tables={len(self._tables)})"
        )

    def __del__(self) -> None:
        """Close the DuckDB connection on garbage collection."""
        with contextlib.suppress(Exception):
            self.con.close()
