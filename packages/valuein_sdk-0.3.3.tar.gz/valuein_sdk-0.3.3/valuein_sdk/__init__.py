from importlib.metadata import PackageNotFoundError, version

from .client import ValueinClient
from .exceptions import (
    ValueinAPIError,
    ValueinAuthError,
    ValueinError,
    ValueinNotFoundError,
    ValueinPlanError,
    ValueinRateLimitError,
)

try:
    __version__ = version("valuein_sdk")
except PackageNotFoundError:
    # Package is not installed (e.g., during local development)
    __version__ = "0.0.0-dev"


__all__ = [
    "ValueinClient",
    "__version__",
    "ValueinError",
    "ValueinAuthError",
    "ValueinPlanError",
    "ValueinNotFoundError",
    "ValueinRateLimitError",
    "ValueinAPIError",
]
