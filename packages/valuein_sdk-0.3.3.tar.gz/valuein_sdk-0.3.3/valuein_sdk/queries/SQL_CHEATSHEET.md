# 📖 Valuein SEC SQL Join Cheat Sheet

This guide provides the 5 most common "join patterns" for navigating the Valuein SEC Data Warehouse. Use these snippets to build your own custom quants models.

## 1.The "Golden Join" (Ticker to Fact)

Goal: The standard entry point. Map a familiar ticker symbol (e.g., NVDA) to its actual financial data points.
SQL

```sql
SELECT
s.symbol,
f.report_date,
fa.standard_concept,
fa.numeric_value,
fa.unit
FROM security s
JOIN filing f ON s.entity_id = f.entity_id
JOIN fact fa  ON f.accession_id = fa.accession_id
WHERE s.symbol = 'NVDA'
AND s.is_active = TRUE
AND f.form_type = '10-K';
```

## 2. The Human-Readable Label Join

Goal: XBRL tags like NetCashProvidedByUsedInOperatingActivities are hard to read. Use this join to pull in human names and definitions.
SQL

```sql
SELECT
fa.standard_concept,
tg.human_name,
tg.definition,
fa.numeric_value
FROM fact fa
JOIN taxonomy_guide tg ON fa.standard_concept = tg.standard_concept
WHERE fa.accession_id = '0001047469-24-000012'; -- Example Accession ID
```

## 3. The Index Filter Join

Goal: Run a screen across a specific universe, such as the S&P 500 or Nasdaq 100.
SQL

```sql
SELECT
s.symbol,
e.name,
e.sector,
im.index_name
FROM security s
JOIN entity e            ON s.entity_id = e.cik
JOIN index_membership im ON s.id = im.security_id
WHERE im.index_name = 'S&P 500'
AND im.end_date IS NULL; -- Ensures current membership
```

## 4. The Amendment & Restatement Auditor

Goal: Financial data is often revised. Use this to track how values changed between the original filing and subsequent amendments.
SQL

```sql
SELECT
f.report_date,
f.is_amendment,
f.amendment_no,
fa.standard_concept,
fa.numeric_value
FROM filing f
JOIN fact fa ON f.accession_id = fa.accession_id
WHERE f.entity_id = '0001067983' -- Berkshire Hathaway CIK
AND f.form_type = '10-K'
ORDER BY f.report_date DESC, f.amendment_no ASC;
```

## 5. Multi-Factor Business Profile Join

Goal: Combine financial metrics (Revenue) with firmographics (CEO, Industry, State of Incorporation) for deep-dive analysis.
SQL

```sql
SELECT
e.name,
e.sector,
e.ceo,
e.state_of_incorporation,
fa.numeric_value AS revenue
FROM entity e
JOIN filing f ON e.cik = f.entity_id
JOIN fact fa  ON f.accession_id = fa.accession_id
WHERE fa.standard_concept = 'Revenues'
AND f.report_date = '2025-12-31'
AND e.sector = 'Technology';
```

Pro-Tip:

The is_active Flag: Always include WHERE s.is_active = TRUE when joining the security table. This ensures you are mapping data to the current ticker symbol and exchange, avoiding duplicates from historical ticker changes.
