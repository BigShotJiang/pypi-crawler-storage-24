-- Extracts variables for the 9-point accounting quality score (Piotroski F-Score).

WITH target_filings AS (
    SELECT
        f.accession_id,
        f.report_date
    FROM filing f
    JOIN security s ON f.entity_id = s.entity_id
    WHERE s.symbol = '{ticker}'
      AND s.is_active = TRUE
      AND f.form_type = '10-K'
      AND f.filing_date BETWEEN '{start_date}' AND '{end_date}'
)
SELECT
    tf.report_date,
    fa.standard_concept,
    fa.numeric_value
FROM target_filings tf
JOIN fact fa
  ON tf.accession_id = fa.accession_id
WHERE fa.standard_concept IN (
    'NetIncomeLoss',
    'NetCashProvidedByUsedInOperatingActivities',
    'Assets',
    'LongTermDebt',
    'CurrentAssets',
    'CurrentLiabilities',
    'SharesOutstanding',
    'GrossProfit'
)
ORDER BY tf.report_date DESC;
