-- Screens for companies delaying their reports (a strong short signal).

SELECT
    s.symbol AS ticker,
    f.form_type,
    f.report_date,
    f.filing_date,
    date_diff('day', f.report_date, f.filing_date) AS reporting_delay_days
FROM filing f
JOIN security s ON f.entity_id = s.entity_id
WHERE s.is_active = TRUE
  AND f.form_type IN ('10-K', '10-Q')
  AND f.filing_date BETWEEN '{start_date}' AND '{end_date}'
ORDER BY reporting_delay_days DESC
LIMIT 50;
