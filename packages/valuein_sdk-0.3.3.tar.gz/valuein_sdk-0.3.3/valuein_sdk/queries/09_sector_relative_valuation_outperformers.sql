-- Ranks companies against their specific entity.sector average to find undervalued peers.

WITH sector_averages AS (
    SELECT
        e.sector,
        AVG(f.numeric_value) AS avg_sector_revenue
    FROM entity e
    JOIN fact f ON e.cik = f.entity_id
    WHERE f.standard_concept = 'Revenues' AND f.frame = '{frame}'
    GROUP BY e.sector
)
SELECT
    e.name,
    e.sector,
    f.numeric_value AS company_revenue,
    sa.avg_sector_revenue,
    (f.numeric_value / sa.avg_sector_revenue) AS sector_relative_multiple
FROM entity e
JOIN fact f ON e.cik = f.entity_id
JOIN sector_averages sa ON e.sector = sa.sector
WHERE f.standard_concept = 'Revenues' AND f.frame = '{frame}'
ORDER BY sector_relative_multiple DESC;
