-- Utilizes Window functions to calculate exact Year-Over-Year growth entirely in SQL.

WITH target_filings AS (
    SELECT
        f.accession_id,
        f.report_date
    FROM filing f
    JOIN security s ON f.entity_id = s.entity_id
    WHERE s.symbol = '{ticker}'
      AND s.is_active = TRUE
      AND f.form_type = '10-K'
      AND f.filing_date BETWEEN '{start_date}' AND '{end_date}'
),
raw_facts AS (
    SELECT
        tf.report_date,
        fa.numeric_value AS revenue
    FROM target_filings tf
    JOIN fact fa ON tf.accession_id = fa.accession_id
    WHERE fa.standard_concept = 'Revenues'
)
SELECT
    report_date,
    revenue,
    LAG(revenue) OVER (ORDER BY report_date) as prev_year_revenue,
    (revenue - LAG(revenue) OVER (ORDER BY report_date)) / NULLIF(LAG(revenue) OVER (ORDER BY report_date), 0) AS yoy_growth
FROM raw_facts
ORDER BY report_date DESC;
