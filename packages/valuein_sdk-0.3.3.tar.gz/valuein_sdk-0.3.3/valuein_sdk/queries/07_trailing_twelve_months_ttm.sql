-- Rolls up 10-Q quarterly flow metrics into a continuous TTM view.

WITH target_filings AS (
    SELECT
        f.accession_id,
        f.report_date
    FROM filing f
    JOIN security s ON f.entity_id = s.entity_id
    WHERE s.symbol = '{ticker}'
      AND s.is_active = TRUE
      AND f.form_type = '10-Q'
      AND f.filing_date BETWEEN '{start_date}' AND '{end_date}'
),
quarterly_facts AS (
    SELECT
        tf.report_date,
        fa.standard_concept,
        fa.numeric_value
    FROM target_filings tf
    JOIN fact fa ON tf.accession_id = fa.accession_id
    WHERE fa.standard_concept IN ({metrics})
)
SELECT
    report_date,
    standard_concept,
    numeric_value AS quarterly_value,
    SUM(numeric_value) OVER (
        PARTITION BY standard_concept
        ORDER BY report_date
        ROWS BETWEEN 3 PRECEDING AND CURRENT ROW
    ) AS ttm_value
FROM quarterly_facts
ORDER BY standard_concept, report_date DESC;
