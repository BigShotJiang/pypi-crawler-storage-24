-- Filters entities based on the Market Identification Code (MIC) to isolate domestic vs. foreign-listed ADRs.

SELECT
    s.symbol,
    s.exchange,
    s.mic,
    f.numeric_value,
    f.unit
FROM security s
JOIN fact f ON s.entity_id = f.entity_id
WHERE s.mic = '{mic_code}' -- e.g., 'XNYS' for NYSE
  AND f.standard_concept = 'NetIncomeLoss'
  AND f.frame = '{frame}' -- e.g., 'CY2023Q4'
ORDER BY f.numeric_value DESC;
