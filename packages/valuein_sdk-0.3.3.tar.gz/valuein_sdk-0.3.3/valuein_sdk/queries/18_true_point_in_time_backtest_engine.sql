-- The ultimate quant query. Filters data strictly by knowledge_at to simulate what
-- a trading algorithm would have known on a random Tuesday in 2018.

SELECT
    s.symbol,
    f.standard_concept,
    f.numeric_value,
    f.knowledge_at
FROM fact f
JOIN security s ON f.entity_id = s.entity_id
WHERE s.is_active = TRUE
  AND f.knowledge_at <= '{simulation_timestamp}' -- e.g., '2018-06-15 09:30:00'
  AND f.standard_concept IN ({metrics})
ORDER BY f.knowledge_at DESC;
