-- Reconstructs the total revenue or earnings for a specific index (like the S&P 500) for macro analysis.

SELECT
    idx.index_name,
    f.period_end,
    SUM(f.numeric_value) AS total_index_revenue
FROM index_membership idx
JOIN security s ON idx.security_id = s.id
JOIN fact f ON s.entity_id = f.entity_id
WHERE idx.index_name = '{index_name}'
  AND f.standard_concept = 'Revenues'
  AND f.frame = '{frame}'
  AND (idx.end_date IS NULL OR idx.end_date >= f.period_end)
GROUP BY idx.index_name, f.period_end
ORDER BY f.period_end DESC;
