-- Resolves multi-share class anomalies and maps standard fundamentals directly to
-- Bloomberg FIGI codes for seamless trade execution.

SELECT
    s.figi,
    s.symbol,
    e.name,
    f.standard_concept,
    f.numeric_value,
    f.period_end
FROM security s
JOIN entity e ON s.entity_id = e.cik
JOIN fact f ON e.cik = f.entity_id
WHERE s.is_active = TRUE
  AND s.security_type = 'Common Stock'
  AND f.standard_concept IN ({metrics})
  AND f.knowledge_at <= '{backtest_date}'
ORDER BY s.figi, f.period_end DESC;
