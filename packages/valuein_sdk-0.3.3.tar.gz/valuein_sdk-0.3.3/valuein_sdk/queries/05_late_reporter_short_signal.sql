-- A classic short-selling signal. Calculates the delay between the end of the quarter and the actual filing date.

SELECT
    e.cik,
    s.symbol,
    filing.form_type,
    filing.report_date,
    filing.filing_date,
    (filing.filing_date - filing.report_date) AS reporting_delay_days
FROM filing
JOIN entity e ON filing.entity_id = e.cik
JOIN security s ON e.cik = s.entity_id
WHERE filing.form_type IN ('10-K', '10-Q')
  AND filing.filing_date BETWEEN '{start_date}' AND '{end_date}'
  AND s.is_active = TRUE
ORDER BY reporting_delay_days DESC
LIMIT 100;
