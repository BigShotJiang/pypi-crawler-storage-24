#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jieming Ye
# Created on: Feb 2024
# Last Modified: Feb 2024
#=================================================================
# Copyright (c) 2024 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Pre-requisite: 
SimulationName.oof: default oslo output file after successfully run a simulation.
xxxxx.xlsx: excel spreadsheet with proper user settings.
SimulationName.lst.txt: required for option 4
Used Input:
simname: to locate the result file or file rename
time_start: to define the analysis start time
time_end: to define the analysis end time
option_select: to define the option selected in subfunction
text_input: to locate the excel file name
other input for oslo_extraction.py only.
Expected Output:
Updated excel spreadsheet with analysis result.
Description:
This script defines the process of doing average load assessment.
First, it reads the excel file and save the user input in a data frame called start_df. Then it find the related .d4 files and read information one by one and saved in a data frame list called d4dataframe. The calculation result is saved in a similar format data frame list called sumdataframe. It then doing some analysis and save the final result in an updated data frame. Final step is to save all information in the excel in a proper format. The whole process is easy to follow via reading the code.
The key manual updating part is get_result_range() function which depends on the desired output format in excel, followed by table_formatting() function where some reading needs manual input. The other process should be auto adjustable as long as the excel input format is followed.

"""
#=================================================================
# VERSION CONTROL
# V1.0 (Jieming Ye) - Initial Version
# V1.1 (Jieming Ye) - Logic change for average calculation and counter for negative values
# V2.0 (Jieming Ye) - Upgrade using xlsxwriter
#=================================================================
# Set Information Variable
# N/A
#=================================================================

import pandas as pd
import numpy as np
from xlsxwriter.utility import xl_range
from openpyxl import load_workbook

# import vision_oslo
from vision_oslo_extension import oslo_extraction
from vision_oslo_extension.shared_contents import SharedMethods
from vision_oslo_extension.shared_excel_helper import excel_to_rowcol,excel_to_table_list,pddataframe_to_excel_with_format


def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):
    
    print("")
    print("Supply Point Preliminary BEMU Support Assessment - - - > ")
    print("")
    
    simname = simname
    # Specify Excel file name
    excel_file = text_input + ".xlsx"
    excel_result = f"{excel_file.rsplit('.', 1)[0]}_result.xlsx"

    #option = "1" # Full Auto
    #option = "2" # Update Spreadsheet only

    option = option_select # 1:Fully Restart, require oof, and list

    time_increment = 5
    start = 10

    space  = 5
    
    if option == "1":
        if not SharedMethods.check_oofresult_file(simname):
            return False

    if not SharedMethods.can_write_file(excel_result):
        SharedMethods.print_message(f"ERROR: Result file {excel_result} is currently in use. Please close or delete it before running the process.","31")
        return False

    # read data from start tab
    result = start_reading_process(
        simname, time_start, time_end, text_input, low_v, high_v, time_step,excel_file,option
    )
    if result == False:
        return False
    else:
        supply_list, start_df,start_page = result

    # number of dataframes to create
    total = len(supply_list)

    # check if want to go throught the feeder check process
    if option == "1":

        if not one_stop_AC_extraction(simname, time_start, time_end,supply_list):
            return False

        if option == "4":
            return True
        
    if option == "2":
        print("Checking essential d4 files files...")
        for supply in supply_list:
            filename = simname + "_" + supply + ".osop.d4"
            if not SharedMethods.check_existing_file(filename):
                SharedMethods.print_message(f"ERROR: d4 file {supply} do not exist. Select option 1 to proceed.","31")
                return False
    
    # check if the d4 file is empty or not
    for feeder in supply_list:
        filename = simname + "_" + feeder +".osop.d4"
        if not SharedMethods.validate_extracted_result(filename,force_data = True):
            SharedMethods.print_message(f"ERROR: Empty d4 file from {feeder} is not allowed in the function. Check your settings.")
            return False
        
    # process d4 file
    d4dataframe = feeder_reading_process(simname, supply_list,time_increment)

    data_write_save(simname,excel_result,start,total,space,start_df,d4dataframe,supply_list,time_increment,start_page)

    return True

# extraction
def one_stop_AC_extraction(simname, time_start, time_end,supply_list):

    # User defined time windows extraction
    time_start = SharedMethods.time_input_process(time_start,1)
    time_end = SharedMethods.time_input_process(time_end,1)

    if time_start == False or time_end == False:
        return False

    # process 1: feeder step output
    print("Extrating feeder step output from Start Tab ... ")

    # processing the list
    for items in supply_list:
        #print(items)
        oslo_extraction.feeder_step_one(simname,items,time_start,time_end)

    # process 2: minmax value extraction
    print("Extrating min-max output...")
    
    # define the default osop command
        
    opcname = simname + ".opc"

    with open(opcname,"w") as fopc:
        fopc.writelines("MINMAX VALUES REQUIRED\n")

    if not SharedMethods.osop_running(simname):
        return False

    return True

# write data to excel
def data_write_save(simname, excel_result,start,total,space,start_df,d4dataframe,supply_list,time_increment,start_page):
    # write data to excel
    data_row = start + 15

    with pd.ExcelWriter(excel_result, engine='xlsxwriter') as writer:
        workbook = writer.book
        header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1,'text_wrap': True})
        table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
        print("Generate Setting Page...")
        setting_summary(writer,start_df,start_page,start)
        print("Writing individual feeder...")
        for index, dflist in enumerate(d4dataframe):
            print(f"Saving {supply_list[index]}...")
            # emty columns
            new_columns = ['New_C_1', 'New_C_2', 'New_C_3', 'Excel_Time', 'Inst Current Headroom (A)', \
                           'Instat Max Train', 'New_C_4', 'MISL Headroom (MVA)', 'MISL Current (A)', \
                            'Charging Headroom (A)', 'Charging per OLE (A)', '30 min Average (A)', \
                                '30 min Current Headroom for charing (A)', '30 min Equvilent Power (MVA)', \
                                    '30 min Max Train', 'Max Train']
            
            new_df = pd.DataFrame(np.nan, index=dflist.index, columns=new_columns)
            # Concatenate the new columns to the original DataFrame
            dflist = pd.concat([dflist, new_df], axis=1)
            worksheet = workbook.add_worksheet(supply_list[index])
            pddataframe_to_excel_with_format(worksheet,data_row,0,dflist,header_format,table_format)

        for index, supply in enumerate(supply_list):
            print(f"Assessment for {supply}...")
            row = start_df.loc[start_df['OSLO ID'] == supply]
            apply_default_value(writer,supply,row)
            apply_excel_formula(writer,supply,len(d4dataframe[index]),data_row+2,time_increment)
            t_start = d4dataframe[index]["Time"].iloc[0]
            t_end = d4dataframe[index]["Time"].iloc[-1]
            train_plot(writer,supply,t_start,t_end,row,len(d4dataframe[index]),data_row+1)

        print("Saving Data...")

    return

# new result page writer (format and writing in one go)
def setting_summary(writer: pd.ExcelWriter,start_df,start_page,start):
    print('Copy the Setting Information...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Setting")
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1,'text_wrap': True})
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    grey_fill = workbook.add_format({"bg_color": "#888888"})
    # copy header info
    #===================INFO TABLE==========================================
    irow = 1
    icol = 0
    for row, line in enumerate(start_page['InfoTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data)
    
    #==================Main Setting=========================================
    irow = start
    icol = 0
    # header info
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # data
    for row, line in enumerate(start_page['SettingTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)

    worksheet.autofit()
    
    return

# adding default value to each sheet from start setup
def apply_default_value(writer: pd.ExcelWriter,supply,row):
    workbook = writer.book
    percentage_format = workbook.add_format({'num_format': '0.0%'})

    sheet = writer.sheets[supply]
    sheet.write("B2", "Source Impedance")
    sheet.write("B3", "Expected Usage")
    sheet.write("B4", "MISL (MVA)")
    sheet.write("B5", "MISL Limit (MVA)")
    sheet.write("B6", "IF O/C (A)")
    sheet.write("B7", "IF O/C Limit(A)")
    sheet.write("B8", "OLE Section")
    sheet.write("B9", "BEMU Limit (A)")
    sheet.write("B10", "BEMU Limit (MW)")
    sheet.write("B11", "OLE Rating (A)")

    sheet.write_formula("C2", "=SQRT(D2^2+E2^2)")
    sheet.write("D2", row["Source Resistance (Ω)"].iloc[0])
    sheet.write("E2", row["Source Reactance (Ω)"].iloc[0])

    sheet.write("C3", row["Expected Site Usage (%)"].iloc[0],percentage_format)
    sheet.write("C4", row["MISL (MVA)"].iloc[0])
    sheet.write_formula("C5", "=C4*C3")
    sheet.write("C6", row["Incoming Feeder Overcurrent (A)"].iloc[0])
    sheet.write_formula("C7", "=C6*C3")
    sheet.write("C8", row["OLE Paralleled Section"].iloc[0])
    sheet.write("C9", row["Instant Charging Limit (A)"].iloc[0])
    sheet.write("C10", row["Continouse Charging Limit (MW)"].iloc[0])
    sheet.write("C11", row["OLE Continous Rating (A)"].iloc[0])

    sheet.write("A17", "NOTE: Calculation from Column W should is trackable from the formula")
    sheet.write("A18", "NOTE: You can adjust the settings above to manipulate the plot")
    sheet.write("A19", "Support for Column 'AC' Charging Headroom calculation as follows:")
    sheet.write("A20", "Considering the source energy consumption --> VI + I^2 R = MISL --> RI^2+VI-MISL = 0")
    sheet.write("A21", "I could be sorted using standard 2nd order equation solution")
    sheet.write("A22", "I = [-V + sqrt(V^2 - 4 R MISL)] / 2 R")

    return

# adding formula to BEMU assessment (adjusting require testing)
def apply_excel_formula(writer: pd.ExcelWriter,supply,total,start,time_increment):
    workbook = writer.book
    worksheet = writer.sheets[supply]
    # hh:mm:ss format
    time_fmt = workbook.add_format({'num_format': 'hh:mm:ss'})

    # time conversion
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1, 22, f'=TIME(LEFT(C{index},2),MID(C{index},4,2),RIGHT(C{index},2))', time_fmt)
        index += 1

    # instant current headroom
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1, 23, f'=$C$7-H{index}')
        index += 1

    # instant max train
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1, 24, f'=ROUNDDOWN(X{index}/$C$9,0)')
        index += 1

    # MISL headroom
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1, 26, f'=$C$5-P{index}')
        index += 1

    # MISL headroom
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1, 27, f'=AA{index}*1000/F{index}')
        index += 1

    # charging headroom
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1,28,f'=(-F{index}+SQRT(F{index}^2+4*$C$2*$C$5))/(2*$C$2)*1000')
        index += 1

    # charging per OLE
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1, 29, f'=AC{index}/$C$8')
        index += 1

    # 30 min average current
    index = start
    target_index = int(start + (1800 / time_increment) - 1)
    for r in range(start, start + total):
        if index <= target_index:
            temp = start
        else:
            temp = int(index - (1800 / time_increment) + 1)
        worksheet.write_formula(r-1,30,f'=AVERAGE(AD{temp}:AD{index})')
        index += 1

    # 30 min charging
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1,31,f'=IF(AE{index}>$C$11,$C$11*$C$8,AC{index})')
        index += 1

    # 30 min charging
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1,32,f'=AF{index}*F{index}/1000')
        index += 1

    # 30 min max train
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1,33,f'=ROUNDDOWN(AG{index}/$C$10,0)')
        index += 1

    # final max train
    index = start
    for r in range(start, start + total):
        worksheet.write_formula(r-1,34,f'=MAX(MIN(AH{index},Y{index}),0)')
        index += 1
    
    worksheet.set_column('A:AI', 11) # default
    worksheet.set_column('B:B', 15) # supply point name

    return

# plot the 30min average power:
def train_plot(writer: pd.ExcelWriter,supply,t_start,t_end,row,total,start):
    workbook = writer.book
    worksheet = writer.sheets[supply]
    name = row["Supply Point Name"].iloc[0]

    time = t_start.split(":")
    ts = (float(time[0])+float(time[1])/60+float(time[1])/3600)/24

    time = t_end.split(":")
    te = (float(time[0])+float(time[1])/60+float(time[1])/3600)/24

    xlim = 0
    ylim = 1
    
    # find nearest 10 min timeline.
    for i in range(0,144):
        if i*1/144 > ts:
            xlim = (i-1)*1/144
            for j in range(i,144):
                if j*1/144 >= te:
                    ylim = j*1/144
                    break
            break
    
    tspace = (ylim-xlim)/8

    # Create scatter chart
    chart = workbook.add_chart({'type': 'scatter', 'subtype': 'straight'})
    chart.set_size({'width': 15*64, 'height': 20*20})
    chart.set_title({'name': f"Max Number of BEMU Chargable within {name}"})
    chart.set_legend({'none': True})

    # Add data series
    chart.add_series({
        'name': 'Result',
        'categories': [worksheet.name, start, 22, start+total-1, 22],
        'values':     [worksheet.name, start, 34, start+total-1, 34],
        'line':   {'width': 1.5},
    })
    
    chart.set_y_axis({
        'name':"No. of Trains",
        'min': 0,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })
    chart.set_x_axis({
        'name': "Time (hh:mm:ss)",
        'min': xlim,
        'max': ylim,
        'major_unit': tspace,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })
    
    # Insert chart
    worksheet.insert_chart("J2", chart)

    # Create scatter chart
    chart = workbook.add_chart({'type': 'scatter', 'subtype': 'straight'})
    chart.set_size({'width': 15*64, 'height': 20*20})
    chart.set_title({'name': f"Max Number of BEMU Chargable for {name} (Continous Loading Only)"})
    chart.set_legend({'none': True})

    # Add data series
    chart.add_series({
        'name': 'Result',
        'categories': [worksheet.name, start, 22, start+total-1, 22],
        'values':     [worksheet.name, start, 33, start+total-1, 33],
        'line':   {'width': 1.5},
    })
    
    chart.set_y_axis({
        'name':"No. of Trains",
        'min': 0,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })
    chart.set_x_axis({
        'name': "Time (hh:mm:ss)",
        'min': xlim,
        'max': ylim,
        'major_unit': tspace,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })
    
    # Insert chart
    worksheet.insert_chart("Y2", chart)


    return

# read the start tab and collect informaiton
def start_reading_process(simname, time_start, time_end, text_input, low_v, high_v, time_step, excel_file,option):
    
    # File check
    print("Check Excel and Deleting Existing Contents ...")
    try:
        wb = load_workbook(excel_file)
        if 'Start' not in wb.sheetnames:
            SharedMethods.print_message("ERROR: 'Start' sheet not found. Ensure the correct excel file selected.","31")
            return False

        # Process Start sheet first
        result = start_page_processing(
            wb['Start'], simname, time_start, time_end,text_input, low_v, high_v, time_step, option
        )

        if result is False:
            return False

        supply_list,start_page = result

        # Now remove other sheets
        for sheet_name in wb.sheetnames:
            if sheet_name != 'Start':
                wb.remove(wb[sheet_name])

        # Save changes
        wb.save(excel_file)

    except Exception as e:
        SharedMethods.print_message(f"(Close the Excel file and Start Again) Error: {e}","31")
        return False
        
    # read start up information 
    columns = ["Supply Point Name","OSLO ID","Source Resistance (Ω)","Source Reactance (Ω)","OLE Paralleled Section","Fault Level (MVA)", \
               "Incoming Feeder Overcurrent (A)","MISL (MVA)","Instant Charging Limit (A)","Continouse Charging Limit (MW)","Expected Site Usage (%)", \
                "OLE Continous Rating (A)"]
    start_df = pd.DataFrame(start_page['SettingTable'],columns=columns)

    # check duplication in OSLO id
    if not SharedMethods.find_duplicates(supply_list): return False
    
    return supply_list, start_df, start_page

# start page processing
def start_page_processing(sheet, simname, time_start, time_end, text_input, low_v, high_v, time_step,option):
    '''
    processing start page in three steps
    1. Blindly reading all tables from start page
    2. processing and validation
    3. return required data format for post processing
    
    :param sheet: Description
    '''
    #------ read header information table
    print("Reading Configuration Setting ...")
    info_start_row,info_start_col = excel_to_rowcol('A2')
    _,info_end_col = excel_to_rowcol('B2')
    setting_start_row,setting_start_col = excel_to_rowcol('A11')
    _,setting_end_col = excel_to_rowcol('L11')

    info_table = excel_to_table_list(sheet,info_start_row,info_start_col,info_end_col,info_start_row,info_start_col,1)
    setting_table = excel_to_table_list(sheet,setting_start_row,setting_start_col,setting_end_col,setting_start_row,setting_start_col+1,1)

    if setting_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at B11.","31")
        return False

    # prepare the return
    supply_list = [item[1] for item in setting_table]
    start_page = {
        "InfoTable": info_table,
        "SettingTable": setting_table,
    }

    return supply_list,start_page

# read individual d4 file
def feeder_reading_process(simname, supply_list,time_increment):
    
    # create dataframe
    d4dataframe = []

    for feeder in supply_list:
        print(f"Processing {feeder} ...")
        filename = simname + "_" + feeder +".osop.d4"
        delimiter = '\\s+'
        columns = ["SupplyID","Type","Time","P_inst","Q_inst","Voltage","V_angle","Current","I_angle"]
        
        dtype_mapping = {"Time": str,}

        df = pd.read_csv(filename, delimiter=delimiter, names = columns, skiprows = 11,dtype = dtype_mapping)  # You might need to adjust the delimiter based on your file
        #df["Time"] = pd.to_datetime(df["Time"],format='%H:%M:%S')
        # Extracting parts from the string and formatting the 'Time' column
        df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")

        # data frame process
        df = d4_file_process(df,time_increment)

        d4dataframe.append(df)

    return d4dataframe

# doing invididual d4 file process and calculatoin
def d4_file_process(df, time_increment):

    df['S_inst'] = np.sqrt(df['P_inst']**2 + df['Q_inst']**2)

    # window_sizes = {'1min': 60, '2min': 120, '10min': 600, '20min': 1200, '30min': 1800}
    window_sizes = {'20min': 1200, '30min': 1800}

    for time_interval, window_size in window_sizes.items():
        df[f'P_{time_interval}'] = df['P_inst'].rolling(window=int(window_size / time_increment)).mean()
        df[f'Q_{time_interval}'] = df['Q_inst'].rolling(window=int(window_size / time_increment)).mean()
        df[f'S_{time_interval}'] = np.sqrt(df[f'P_{time_interval}']**2 + df[f'Q_{time_interval}']**2)

    df['I_Inst'] = df['Current'] # Current Duplicate

    # for time_interval in [5, 10, 15, 20, 25, 30, 35, 40, 60, 120, 600, 1200, 1800]:
    for time_interval in [1200, 1800]:
        column_name = f'I_{time_interval}s_RMS'
        df[column_name] = calculate_rolling_rms(df, 'Current', time_interval, time_increment)

    # df['P_CosPhi'] = df['P_inst'] / df['S_inst']
    
    # for time_interval in ['inst', '1min', '2min', '10min', '20min', '30min']:
    #     df[f'PF_{time_interval}'] = df[f'P_{time_interval}'] / df[f'S_{time_interval}']

    return df

# calculate rms
def calculate_rolling_rms(data, column, window_size, time_increment):
    return data[column].rolling(window=int(window_size / time_increment)).apply(lambda x: np.sqrt(np.mean(x**2)), raw=True)

if __name__ == "__main__":
    # Add your debugging code here
    simname = "test_model_1"  # Provide a simulation name or adjust as needed
    main_option = "1"  # Adjust as needed
    time_start = "0070000"  # Adjust as needed
    time_end = "0080000"  # Adjust as needed
    option_select = "2"  # Adjust as needed
    text_input = "AC_06_BEMU1"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = None  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)

