#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jieming Ye
# Created on: Feb 2024
# Last Modified: Feb 2024
#=================================================================
# Copyright (c) 2024 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Pre-requisite: 
SimulationName.oof: default oslo output file after successfully run a simulation.
xxxxx.xlsx: excel spreadsheet with proper user settings.
Used Input:
simname: to locate the result file or file rename
time_start: to define the analysis start time
time_end: to define the analysis end time
option_select: to define the option selected in subfunction
text_input: to locate the excel file name
other input for oslo_extraction.py only.
Expected Output:
Updated excel spreadsheet with analysis result.
Description:
This script defines the process of doing incoming feeder protection assessment.
First, it reads the excel file and save the user input in a data frame called start_df. Then it find the related .d4 files and read information one by one and saved in a data frame list called d4dataframe. The calculation result is saved in a similar format data frame list called sumdataframe. It then doing some analysis and save the final result in an updated data frame. Final step is to save all information in the excel in a proper format. The whole process is easy to follow via reading the code.
The key manual updating part is get_result_range() function which depends on the desired output format in excel, followed by table_formatting() function where some reading needs manual input. The curve_plot() function is also need manual change if some new plots is desired in the future. The other process should be auto adjustable as long as the excel input format is followed.

"""
#=================================================================
# VERSION CONTROL
# V1.0 (Jieming Ye) - Initial Version
# V2.0 (Jieming Ye) - Use xlsxwriter as main output
#=================================================================
# Set Information Variable
# N/A
#=================================================================

import pandas as pd
import numpy as np
from xlsxwriter.utility import xl_range
from datetime import datetime
from openpyxl import load_workbook

# import vision_oslo
from vision_oslo_extension import oslo_extraction
from vision_oslo_extension.shared_contents import SharedMethods
from vision_oslo_extension.shared_excel_helper import excel_to_rowcol,excel_to_table_list,pddataframe_to_excel_with_format


def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):

    print("")
    print("Incoming Feeder Protection Assessment --->")
    print("")
    
    simname = simname
    excel_file = text_input + ".xlsx"
    excel_result = f"{excel_file.rsplit('.', 1)[0]}_result.xlsx"

    if not SharedMethods.check_existing_file(excel_file):
        return False
    
    #option = "1" # Fully Restart, require oof,
    #option = "2" # Process only

    option = option_select # 1:Fully Restart, require oof, and list

    time_increment = 5
    start = 10

    space  = 5

    if option not in ["0","1","2"]:
        SharedMethods.print_message("ERROR: Error in protection_if.py. Please contact Support.","31")
        return False
    
    if option == "0":
        SharedMethods.print_message("ERROR: Please select an option to proceed.","31")
        return False

    if not SharedMethods.can_write_file(excel_result):
        SharedMethods.print_message(f"ERROR: Result file {excel_result} is currently in use. Please close or delete it before running the process.","31")
        return False

    result = start_reading_process(simname,excel_file)
    if result == False:
        return False
    else:
        feeder_list, type_list, p_type, p_setting, start_df, start_page = result

    # number of dataframes to create
    total = len(feeder_list)

    # check if want to go throught the feeder check process
    if option == "1":
        if not SharedMethods.check_oofresult_file(simname):
            return False
        if not one_stop_protection_extraction(simname, time_start, time_end, feeder_list, type_list):
            return False
        
    if option == "2":
        print("Checking essential d4 files and mxn files...")
        for feeder in feeder_list:
            filename = simname + "_" + feeder + ".osop.d4"
            if not SharedMethods.check_existing_file(filename):
                SharedMethods.print_message(f"ERROR: d4 file {feeder} do not exist. Select option 1 to proceed.","31")
                return False

    # process d4 file
    i_r_df,d4dataframe,sumdataframe = feeder_reading_process(simname,feeder_list,type_list,time_increment)
    
    # process assessment threshold table
    limit_r_df = protection_limit(simname, feeder_list,p_type,p_setting,time_increment)

    data_write_save(simname, excel_result,start,total,space,start_df,i_r_df,limit_r_df, \
                    d4dataframe,sumdataframe,feeder_list,type_list,time_increment,start_page)

    return True


def one_stop_protection_extraction(simname, time_start, time_end, feeder_list, type_list):

    # User defined time windows extraction
    time_start = SharedMethods.time_input_process(time_start,1)
    time_end = SharedMethods.time_input_process(time_end,1)

    if time_start == False or time_end == False:
        return False

    # process 1: feeder step output
    print("Extrating step output from Start Tab ... ")

    # processing the list
    for index, items in enumerate(feeder_list):
        #print(items)
        if type_list[index] == "SP":
            if not oslo_extraction.feeder_step_one(simname,items,time_start,time_end):
                SharedMethods.print_message(f"WARNING: Error for {items} will be ignored and process continued...","33")
        elif type_list[index] == "TR":
            if not oslo_extraction.tranx_step_one(simname,items,time_start,time_end):
                SharedMethods.print_message(f"WARNING: Error for {items} will be ignored and process continued...","33")
        else:
            SharedMethods.print_message(f"WARNING: {type_list[index]} is not a recongized type for {items}. Feeder applies by default.","33")
            if not oslo_extraction.feeder_step_one(simname,items,time_start,time_end):
                SharedMethods.print_message(f"WARNING: Error for {items} will be ignored and process continued...","33")
    
    return True

# write data to excel
def data_write_save(simname, excel_result:str,start,total,space,start_df,i_r_df,limit_r_df, \
                    d4dataframe,sumdataframe,feeder_list,type_list,time_increment,start_page):
    
    # write data to excel
    for i in range(1,51):
        excel_dashboard = f"0_{simname}_result_IF_protection_{i}.xlsx"
        # if file does not exist
        if not SharedMethods.check_existing_file(excel_dashboard,printing = False):
            break
    else:
        SharedMethods.print_message("WARNING: Dashboard exporting fail. More than 50 dashboard exists already.","33")

    with pd.ExcelWriter(excel_dashboard, engine='xlsxwriter') as writer:
        print(f"Generating result dashboard {excel_dashboard}...")
        result_summary(writer,simname,start_df,limit_r_df,i_r_df,start_page,start,space)
    
    with pd.ExcelWriter(excel_result, engine='xlsxwriter') as writer:
        # get currrent workbook to do process
        workbook = writer.book
        print("Generate Setting Page...")
        setting_summary(writer,start_df,start_page,start)
        print("Generate Result Page...")
        result_summary(writer,simname,start_df,limit_r_df,i_r_df,start_page,start,space)
        print("Generate Plot Page...")
        curve_plot(writer,sumdataframe,limit_r_df,feeder_list,time_increment)
        
        # Write each DataFrame to a different sheet in the Excel file
        print("Writing individual incoming feeder...")
        for index, dflist in enumerate(d4dataframe):
            print(f"Saving {feeder_list[index]}...")
            if type_list[index] == 'TR':
                dflist.insert(dflist.columns.get_loc('2nd_I_angle') + 1, 'New_C_1', np.nan)
                sumdataframe[index].insert(sumdataframe[index].columns.get_loc('2nd_I_angle')+1,'New_C_1', np.nan)
            
            else:
                dflist.insert(dflist.columns.get_loc('I_angle') + 1, 'New_C_1', np.nan)
                dflist.insert(dflist.columns.get_loc('New_C_1') + 1, 'New_C_2', np.nan)
                dflist.insert(dflist.columns.get_loc('New_C_2') + 1, 'New_C_3', np.nan)
                dflist.insert(dflist.columns.get_loc('New_C_3') + 1, 'New_C_4', np.nan)
                sumdataframe[index].insert(sumdataframe[index].columns.get_loc('I_angle')+1,'New_C_1', np.nan)
                sumdataframe[index].insert(sumdataframe[index].columns.get_loc('New_C_1')+1,'New_C_2', np.nan)
                sumdataframe[index].insert(sumdataframe[index].columns.get_loc('New_C_2')+1,'New_C_3', np.nan)
                sumdataframe[index].insert(sumdataframe[index].columns.get_loc('New_C_3')+1,'New_C_4', np.nan)

            sumdataframe[index].to_excel(writer, sheet_name=feeder_list[index], index=False, startrow = 0)

            dflist.to_excel(writer, sheet_name=feeder_list[index], index=False, startrow = sumdataframe[index].shape[0]+2)
        
        print("Saving Data...")

    return

# new result page writer (format and writing in one go)
def setting_summary(writer: pd.ExcelWriter,start_df,start_page,start):
    print('Copy the Setting Information...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Setting")
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    grey_fill = workbook.add_format({"bg_color": "#888888"})
    # copy header info
    #===================INFO TABLE==========================================
    irow = 1
    icol = 0
    for row, line in enumerate(start_page['InfoTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data)
    
    #==================Main Setting=========================================
    irow = start
    icol = 0
    # header info
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # data
    for row, line in enumerate(start_page['SettingTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)

    worksheet.autofit()
    
    return

# new result page writer (format and writing in one go)
def result_summary(writer: pd.ExcelWriter,simname,start_df,limit_r_df,i_r_df,start_page,start,space):
    print('Preparing the Final Result...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Result")
    # define formatting
    # Header: bold, center, grey background, all borders
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})

    # Subheader: italic, size 10, grey background, all borders
    subheader_format = workbook.add_format({'italic': True,'font_size': 10,'align': 'center','valign': 'vcenter','bg_color': '#EDEDED','border': 1, 'text_wrap': True})

    # Setting info: center aligned
    setting_info_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '00.00','border': 1})

    # Percentage format: 0.00%
    percentage_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00%','border': 1})

    # Write Basic Information
    project_name = start_page['InfoTable'][0][1]
    feeding_desp = start_page['InfoTable'][1][1]
    modeller = start_page['InfoTable'][2][1]
    date = start_page['InfoTable'][3][1]
    
    worksheet.write('B2', "Project Name:")
    worksheet.write('C2', project_name)
    worksheet.write('B3', "Simulation Name:")
    worksheet.write('C3', simname)
    worksheet.write('B4', "Feeding Arrangement:")
    worksheet.write('C4', feeding_desp)
    worksheet.write('B5', "Result Created by:")
    worksheet.write('C5', modeller)
    worksheet.write('B6', "Result Created at:")
    worksheet.write('C6', datetime.now().strftime("%d-%m-%Y %H:%M"))

    worksheet.write('H4', "Protection Type:")
    worksheet.write('H5', "DT")
    worksheet.write('H6', "IDMT")

    worksheet.write('K4', "Threshold Calculation:")
    worksheet.write('K5', "Pickup Current --> i.e. Trip Current")
    worksheet.write('K6', "(((0.14*[time_multiplier]/[time_window])+1)^(1/0.02))*[pickup_current]")

    # actual data writing started
    row1, cols1 = start_df.shape
    row2, cols2 = limit_r_df.shape

    #==================== FIRST TABLE=============================================================
    irow = start
    icol = 1
    # write first table
    worksheet.merge_range(irow-1,icol,irow-1,icol+cols1-1,"Site Information Summary",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,start_df,subheader_format,setting_info_format)
    # write 2nd table
    icol = icol + cols1
    i_critera = f"H{irow+2}"
    worksheet.merge_range(irow-1,icol,irow-1,icol+cols2-1,"Trip Current Threshold (A)",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,limit_r_df,subheader_format,number_format)
    
    #==================== 2ND TABLE=============================================================
    irow = irow + row1 + space
    icol = 1
    # write first table
    worksheet.merge_range(irow-1,icol,irow-1,icol+cols1-1,"Site Information Summary",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,start_df,subheader_format,setting_info_format)
    # write 2nd table
    icol = icol + cols1
    # getting the range
    i_range = xl_range(irow+1,icol,irow+row1,icol+13)
    worksheet.merge_range(irow-1,icol,irow-1,icol+13,"Maximum Incoming Feeder RMS Current (A)",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,i_r_df,subheader_format,number_format)

    # conditional formatting
    red_bkg = workbook.add_format({"bg_color": "#FF0000"})
    yellow_bkg = workbook.add_format({"bg_color": "#FFFF00"})
    green_bkg = workbook.add_format({"bg_color": "#00FF00"})
    
    worksheet.conditional_format(i_range,{'type': 'cell','criteria':'<', 'value': f'={i_critera}-300','format': green_bkg}) 
    worksheet.conditional_format(i_range,{'type': 'cell','criteria':'>=', 'value': f'={i_critera}','format': red_bkg})
    worksheet.conditional_format(i_range,{'type': 'cell','criteria':'between', 'minimum': f'={i_critera}-300','maximum': f'={i_critera}','format': yellow_bkg})

    # set column width
    worksheet.set_column('B:U', 10) # default
    worksheet.set_column('B:B', 25) # supply point name
    
    return

# plot the IDMT Protection Curve
def curve_plot(writer:pd.ExcelWriter,sumdataframe,limit_r_df,feeder_list,time_increment):
    # clean up date frame
    limit_r_df = limit_r_df.where(pd.notna(limit_r_df), None)
    # limit as list
    workbook = writer.book
    worksheet = workbook.add_worksheet("Plot")

    row = 0 # row 1 0-based
    start = 1 # column B 0-based
    p_row = 1 # row 1 1-based
    time = [time_increment, 5, 10, 15, 20, 25, 30, 35, 40, 60, 120, 600, 1200, 1800]

    worksheet.write(row,start, "Time")

    for index, t in enumerate(time):
        worksheet.write(row,start+index+1,t)

    for index, feeder in enumerate(feeder_list):
        row = row + 1
        worksheet.write(row,start,feeder)
        row = row + 1
        worksheet.write(row,start,"Limit")
        limit = limit_r_df.iloc[index].tolist()
        for index1,lmt in enumerate(limit):
            worksheet.write(row,start+index1+1,lmt)

        row = row + 1
        worksheet.write(row,start,"Result")
        df = sumdataframe[index]
        start_index = df.columns.get_loc('I_Inst')
        result = df.iloc[0, start_index:].tolist()
        for index1, re in enumerate(result):
            worksheet.write(row,start+index1+1,re)

    # Prepare the plot
    row = 0  # xlsxwriter uses 0-based indexing
    x_row = row

    # X values (Time Window)
    # start is assumed to be 0-based column index
    xvalues = [worksheet.name, x_row, start + 1, x_row, start + 14]

    for index, feeder in enumerate(feeder_list):
        row += 3
        # Create scatter chart with smooth lines and markers
        chart = writer.book.add_chart({'type': 'scatter', 'subtype': 'smooth_with_markers'})
        chart.set_size({'width': 15*64, 'height': 20*20})
        chart.set_title({'name': f'Incoming Feeder Protection Curve for {feeder}'})
        chart.set_x_axis({'name': 'Time Window (s)','min': 0,'max': 120,'major_gridlines': {'visible': True}})
        chart.set_y_axis({'name': 'Maximum RMS Current (A)','major_gridlines': {'visible': True}})
        # chart.set_size({'width': 900, 'height': 400})

        # --- Maximum RMS Current Series ---
        chart.add_series({
            'name': 'Maximum RMS Current',
            'categories': xvalues,
            'values': [worksheet.name, row, start+1, row, start + 14],
            'marker': {'type': 'circle','size': 5},
            'smooth': True,
        })

        # --- Protection Curve Series ---
        chart.add_series({
            'name': 'Protection Curve',
            'categories': xvalues,
            'values': [worksheet.name, row - 1, start+1, row - 1, start + 14],
            'marker': {'type': 'circle','size': 5},
            'smooth': True,
        })

        chart.set_legend({'position': 'top'})

        # Insert chart into worksheet
        worksheet.insert_chart(f'R{p_row}', chart)
        p_row += 20

    return

# read the start tab and collect informaiton
def start_reading_process(simname, excel_file):
    # File check
    print("Check Excel and Deleting Existing Contents ...")

    try:
        wb = load_workbook(excel_file)

        if 'Start' not in wb.sheetnames:
            SharedMethods.print_message("ERROR: 'Start' sheet not found. Ensure the correct excel file selected.","31")
            return False

        # Process Start sheet first
        result = start_page_processing(wb['Start'], simname)

        if result is False: return False

        feeder_list, type_list, p_type, p_setting, start_page = result

        # Now remove other sheets
        for sheet_name in wb.sheetnames:
            if sheet_name != 'Start':
                wb.remove(wb[sheet_name])

        # Save changes
        wb.save(excel_file)

    except Exception as e:
        SharedMethods.print_message(f"ERROR: (Close the Excel file and Start Again) Error: {e}","31")
        return False
        
    # read start up information 
    columns = ["Incoming Feeder","OSLO ID","OSLO Type","Protection Type","Pickup Current (A)","Time Multiplier (s)"]
    start_df = pd.DataFrame(start_page['SettingTable'],columns=columns)

    # check duplication in OSLO id
    if not SharedMethods.find_duplicates(feeder_list): return False
    
    return feeder_list, type_list, p_type, p_setting, start_df, start_page

# start page processing
def start_page_processing(sheet, simname):
    '''
    processing start page in three steps
    1. Blindly reading all tables from start page
    2. processing and validation
    3. return required data format for post processing
    
    :param sheet: Description
    '''
    #------ read header information table
    print("Reading Configuration Setting ...")
    info_start_row,info_start_col = excel_to_rowcol('A2')
    _,info_end_col = excel_to_rowcol('B2')
    setting_start_row,setting_start_col = excel_to_rowcol('A11')
    _,setting_end_col = excel_to_rowcol('F11')

    info_table = excel_to_table_list(sheet,info_start_row,info_start_col,info_end_col,info_start_row,info_start_col,1)
    setting_table = excel_to_table_list(sheet,setting_start_row,setting_start_col,setting_end_col,setting_start_row,setting_start_col+1,1)

    feeder_list = []
    type_list = []
    p_type = []
    p_setting = []

    if setting_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at B11.","31")
        return False
    else:
        for row in setting_table:
            feeder_list.append(row[1])
            type_list.append(row[2])
            p_type.append(row[3])
            if row[3] == "DT":
                p_setting.append(row[4])
            else:
                p_setting.append([row[4],row[5]])
            
    start_page = {
        "InfoTable": info_table,
        "SettingTable": setting_table,
    }

    return feeder_list, type_list, p_type, p_setting, start_page

# create table 1 and table 2
def current_result(supply_list):
    columns = ['Instantanous','05 seconds','10 seconds','15 seconds', '20 seconds', '25 seconds','30 seconds','35 seconds','40 seconds', \
               '60 seconds', '120 seconds', '10 min','20 min','30 min']
    rows = []

    for feeder in supply_list:
        rows.append(feeder)
    df = pd.DataFrame(index=rows,columns=columns)

    return df

#create protection limit dataframe
def protection_limit(simname, feeder_list,p_type,p_setting,time_increment):
    limit_r_df = current_result(feeder_list) # create limit dataframe

    columns = limit_r_df.columns # get columns

    time_interval = [time_increment, 5, 10, 15, 20, 25, 30, 35, 40, 60, 120, 600, 1200, 1800]

    for index, item in enumerate(feeder_list):
        if p_type[index] == "DT":
            result = float(p_setting[index])
            for column in columns: # exclude the first column
                limit_r_df.at[item,column] = result
        
        if p_type[index] == "IDMT":
            pickup = float(p_setting[index][0])
            tm = float(p_setting[index][1])

            for index1, column in enumerate(columns):
                time = time_interval[index1]

                result = (((0.14 * tm / time) + 1) ** (1 / 0.02)) * pickup # IDMT threshold Calculation formula based on standard inverse curve

                limit_r_df.at[item,column] = result

    return limit_r_df

# read individual d4 file
def feeder_reading_process(simname, feeder_list,type_list,time_increment):

    i_r_df = current_result(feeder_list)

    # create dataframe
    d4dataframe = []
    sumdataframe = []

    for index, feeder in enumerate(feeder_list):
        print(f"Processing {feeder} ...")
        filename = simname + "_" + feeder +".osop.d4"
        if type_list [index] == "TR":
            delimiter = '\\s+'
            columns = ["TransID","Type","TR_Type","Time","P_inst","Q_inst","Voltage","V_angle","1st_Current","1st_I_angle","2nd_Current","2nd_I_angle"]
            dtype_mapping = {"Time": str,}
            df = pd.read_csv(filename, delimiter=delimiter, names = columns, skiprows = 11,dtype = dtype_mapping) 
            # Extracting parts from the string and formatting the 'Time' column
            df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")
            # data frame process
            df = d4_file_tr_process(df,time_increment)
            df_sum = d4_find_max(df,f_type = 2)

            i_r_df = current_update(i_r_df, df_sum, feeder,f_type = 2)
        
        #elif type_list[index] == "SP":
        else:
            delimiter = '\\s+'
            columns = ["FeederID","Type","Time","P_inst","Q_inst","Voltage","V_angle","Current","I_angle"]
            dtype_mapping = {"Time": str,}
            df = pd.read_csv(filename, delimiter=delimiter, names = columns, skiprows = 11,dtype = dtype_mapping) 
            # Extracting parts from the string and formatting the 'Time' column
            df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")
            # data frame process
            df = d4_file_sp_process(df,time_increment)
            # calculate sum value
            df_sum = d4_find_max(df,f_type = 1)
            #update summary result
            i_r_df = current_update(i_r_df, df_sum,feeder,f_type = 1)

        
        # calculate sum value
        sumdataframe.append(df_sum)
        d4dataframe.append(df)
        
    return i_r_df, d4dataframe, sumdataframe

# doing invididual d4 file process and calculatoin for supply points
def d4_file_sp_process(df, time_increment):

    df['I_Inst'] = df['Current'] # Current Duplicate

    for time_interval in [5, 10, 15, 20, 25, 30, 35, 40, 60, 120, 600, 1200, 1800]:
        column_name = f'I_{time_interval}s_RMS'
        df[column_name] = calculate_rolling_rms(df, 'Current', time_interval, time_increment)

    return df

# doing invididual d4 file process and calculatoin for transformer
def d4_file_tr_process(df, time_increment):

    df['I_Inst'] = df['2nd_Current'] # Current Duplicate

    for time_interval in [5, 10, 15, 20, 25, 30, 35, 40, 60, 120, 600, 1200, 1800]:
        column_name = f'I_{time_interval}s_RMS'
        df[column_name] = calculate_rolling_rms(df, '2nd_Current', time_interval, time_increment)

    return df

# calculate rms
def calculate_rolling_rms(data, column, window_size, time_increment):
    return data[column].rolling(window=int(window_size / time_increment)).apply(lambda x: np.sqrt(np.mean(x**2)), raw=True)

# find maximum value and time of each d4 file
def d4_find_max(df,f_type):
    # # Insert two empty rows above the first row
    # df = pd.concat([pd.DataFrame(index=range(2)), df], ignore_index=True)
    sum_df = pd.DataFrame(columns=df.columns,index=range(4))
    sum_df.iloc[0, 0] = "Maximum Value"
    sum_df.iloc[1, 0] = "Maximum Value at Time"
    sum_df.iloc[2, 0] = "Minimum Value"
    sum_df.iloc[3, 0] = "Minimum Value at Time"

    if f_type == 1:
        start = 9
    
    if f_type == 2:
        start = 12

    if df.empty:
        sum_df.iloc[0, 1] = "DATA FOR THIS FEEDER IS NOT AVAILABLE"

    else:
        for column in df.columns[start:]:
            if df[column].dtype in [int, float]:
                max_value = df[column].max()
                time_of_max = df.loc[df[column].idxmax(), 'Time']
                sum_df.at[0, column] = max_value
                sum_df.at[1, column] = time_of_max
                min_value = df[column].min()
                time_of_min = df.loc[df[column].idxmin(), 'Time']
                sum_df.at[2, column] = min_value
                sum_df.at[3, column] = time_of_min

    return sum_df

# update current based on output of d4 process
def current_update(target,df_sum,feeder,f_type):
    if f_type == 1:
        index = 9
    if f_type == 2:
        index = 12
    #index = 25 # from 25th column
    for column in target.columns:
        target.at[feeder,column] = df_sum.iloc[0,index]
        index = index + 1
    return target

if __name__ == "__main__":
    # Add your debugging code here
    simname = "test_model_1"  # Provide a simulation name or adjust as needed
    main_option = "1"  # Adjust as needed
    time_start = "0070000"  # Adjust as needed
    time_end = "0080000"  # Adjust as needed
    option_select = "2"  # Adjust as needed
    text_input = "AC_03_Protection"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = None  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)

