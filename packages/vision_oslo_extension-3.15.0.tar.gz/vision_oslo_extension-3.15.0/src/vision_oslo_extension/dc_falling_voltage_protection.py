#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jacky Lai
# Created on: Jun 2024
# Last Modified: July 2024
#=================================================================
# Copyright (c) 2024 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Pre-requisite: 
SimulationName.oof: default oslo output file after successfully run a simulation.
FVP input.xlsx
Used Input:
simname: to locate the result file or file rename
time_start: to define the analysis start time
time_end: to define the analysis end time
option_select: to define the option selected in subfunction
text_input: to locate the excel file name
other input for oslo_extraction.py only.
Expected Output:
Various .csv file containing individual detailed output or summary output.
Description:
This script defines the process of DC data calculation for falling voltage protection.

In branch_data_process(), it generates the list file first and read list file line by line, saving the result is a data frame during the reading process. It then doing individual calculation and output the result to several .csv files. The process is relative easy to follow via reading the code.

"""
#=================================================================
# VERSION CONTROL
# V0.1 (Jacky Lai) - Test Version
# V1.0 (Jieming Ye) - Refactor logic and using xlsxwriter
#=================================================================
# Set Information Variable
# N/A
#=================================================================

import math
import pandas as pd

from xlsxwriter.utility import xl_range
from datetime import datetime
from openpyxl import load_workbook

from vision_oslo_extension import oslo_extraction
from vision_oslo_extension.shared_contents import SharedMethods
from vision_oslo_extension.shared_excel_helper import excel_to_rowcol,excel_to_table_list,excel_to_table_list_col,pddataframe_to_excel_with_format

def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):
    
    print("")
    print("DC Falling Voltage Protection Assessment - - - > ")
    print("")
    
    simname = simname

    option = option_select

    start = 12 # result start from row 12
    time_increment = 5

    # Option:
    # 1: DC FVP protection assessment
    # 2: 
    #check option for TCB or ETE is selected
    if option not in ["0","1","2","3","4"]:
        SharedMethods.print_message("ERROR: Error in DC FVP processing . Please contact Support...","31")
        return False

    if option == "0":
        SharedMethods.print_message("ERROR: Please select an option to proceed.","31")
        return False

    # Specify Excel file name
    excel_file = text_input + ".xlsx"
    excel_result = f"{excel_file.rsplit('.', 1)[0]}_result.xlsx"
    output_plots = f"{excel_file.rsplit('.', 1)[0]}_step_outputs_plots.xlsx"

    if not SharedMethods.check_existing_file(excel_file):
        return False

    if not SharedMethods.can_write_file(excel_result):
        SharedMethods.print_message(f"ERROR: Result file {excel_result} is currently in use. Please close or delete it before running the process.","31")
        return False
    
    if option == "2" or option =="4":
        if not SharedMethods.can_write_file(output_plots):
            SharedMethods.print_message(f"ERROR: Result file {output_plots} is currently in use. Please close or delete it before running the process.","31")
            return False

    try:
        #read excel and get branch list
        result = start_reading_process(simname,excel_file,option)
        if result == False:
            return False
        else:
            start_df,oslo_total,rating_data,rolling_stock_df,start_page= result

        #create data frame for processing branches, FVP coefficients will be added to this dataframe
        branch_process_df = start_df

        # read branch names from excel and create branch list for OSOP extraction
        branch_list_1 = read_all_branches(start_df)

        # create branch list 1 new in different format
        branch_list_1new = check_branch_list(branch_list_1)
        if branch_list_1new == False:
            return False

        # branch_list_1: branch format in XXXX/X format
        # branch_list_1new: branch format in XXXX-X format this is because many application does not allow / charaters in naming

        #create df for results
        results_df = start_df
        
        #check oof file of simname exist
        if option == "1" or option =="2":              
            if not SharedMethods.check_oofresult_file(simname):
                return False

        # check all specified FVP ratings are within FVP list

        # Create a set of valid (FVP Type, FVP setting (kA)) combinations from rating_data
        valid_combinations = set(zip(rating_data['FVP Type'], rating_data['FVP setting (kA)']))
        branch_process_df_t = branch_process_df

        # Check if each (FVP Type, FVP setting (kA)) in branch_process_df is in the valid_combinations set
        branch_process_df_t['is_valid'] = branch_process_df_t.apply(lambda row: (row['FVP Type'], row['FVP setting (kA)']) in valid_combinations, axis=1)

        # If there are any invalid combinations, raise an error
        if not branch_process_df_t['is_valid'].all():
            invalid_rows = branch_process_df_t[~branch_process_df_t['is_valid']]
            SharedMethods.print_message(f"Invalid FVP Type or FVP setting (kA) compination found in the following rows:\n{invalid_rows}","31")
            return False
        #if no errors continue with extraction

        # extract the branches
        #extract all branch step output using OSOP for branches in branch list  
        #only extract branches if in option 1 or 2
        if option == "1" or option =="2":
            for branch_id in branch_list_1:
                if not oslo_extraction.branch_step(simname, time_start, time_end, "1", branch_id):
                    return False

        #read branch step voltage and current into data_frame from d4.osop
        branchstep_d4_df = branch_reading_process(simname,branch_list_1new)

        #merge ratings data coefficient to branch_process_df_r which is the dataframe for processing branch results
        print("merging FVP ratings to each branch")
        branch_process_df_r = pd.merge(branch_process_df,rating_data, on=[ 'FVP Type','FVP setting (kA)'],how='left')

        #change branch format for comparison in next step
        branch_process_df_r['OSLO']=branch_list_1new

        #for each branch step see if the voltage at the recorded current is below the FVP curves
        # 0 is pass, 1 is below the -% rating curve, 2 is below the 0% nominal rating curve, 3 is below the +% rating curve
        branchstep_r = branch_FVP_rating(branchstep_d4_df,branch_process_df_r)

        #count number of 0 1 2 3 in branchstep_r
        results_df['OSLO']=branch_list_1new
        results_df = Branch_FVP_sum(results_df,branchstep_r)

        #create substation summary for each substation
        sub_sum_df = Summary_by_substation(results_df)

        # creating final result dataframe for output
        excel_b_results_df, excel_s_results_df = create_summary_dataframe(results_df,sub_sum_df)

        #export results summary to excel
        if not SEF_ratings_excel(simname,excel_result,start,excel_b_results_df, excel_s_results_df,rolling_stock_df,start_page):
            return False

        #the following are only requried for detailed step results and graphs run only with option 2 or 4
        if option == "2" or option =="4":

            #create a dictionary for each substation row in the above for a list of Nodes
            #dict_substation_stock added, same format as a dictionary of list of rolling stocks
            dict_substation, dict_substation_name, dict_substation_stock = substations_node_list(sub_sum_df,results_df)
            
            #dict_substation_stock = substations_stock(dict_substation_name,results_df)

            #create a dictionary for each substation that contains each Nodes step resutls
            dict_sub_step = substations_step_list(branchstep_r,dict_substation)

            #run the main loop for extracting step resutls to step_excel and plot graphs
            #graph plotting loop within this loop
            if not FVP_step_excel(simname,output_plots,excel_s_results_df,sub_sum_df,dict_sub_step,dict_substation_name,
                                  rating_data,dict_substation_stock,rolling_stock_df,start_page,start):
                return False
    
    except KeyError as e:
        SharedMethods.print_message(f"ERROR: Unexpected error occured: {e}. Possibly due to incompleted data.","31")
        return False
    
    except Exception as e:
        SharedMethods.print_message(f"ERROR: Unexpected error occured: {e}","31")
        return False

    return True 
        
def create_summary_dataframe(results_df,sub_sum_df):
    columns1 = ['Substation Name', 'OSLO', 'TCB Type', 'FVP Type','FVP setting (kA)','Total Data Point','Total No. Exceed rating lower trip limit', 'Total No. Exceed rating nominal trip limit', 'Total No. Exceed rating upper trip limit']
    columns2 = ['Substation Name', 'TCB Type', 'FVP Type','FVP setting (kA)', 'Number of Nodes', 'Total Data Point' ,'Total No. Exceed rating lower trip limit', 'Total No. Exceed rating nominal trip limit', 'Total No. Exceed rating upper trip limit']
    #write to results sheet
    excel_b_results_df = pd.DataFrame(columns=columns1)
    #write to results summary sheet
    excel_s_results_df = pd.DataFrame(columns=columns2)

    excel_b_results_df = pd.DataFrame(results_df, columns=columns1)
    excel_s_results_df = pd.DataFrame(sub_sum_df, columns=columns2)
    
    # Calculate the percentage columns
    excel_b_results_df['% Exceed lower trip limit'] = excel_b_results_df['Total No. Exceed rating lower trip limit'] / excel_b_results_df['Total Data Point']
    excel_b_results_df['% Exceed nominal trip limit'] = excel_b_results_df['Total No. Exceed rating nominal trip limit'] / excel_b_results_df['Total Data Point']
    excel_b_results_df['% Exceed upper trip limit'] = excel_b_results_df['Total No. Exceed rating upper trip limit'] / excel_b_results_df['Total Data Point']

    excel_s_results_df['% Exceed lower trip limit'] = excel_s_results_df['Total No. Exceed rating lower trip limit'] / excel_s_results_df['Total Data Point']
    excel_s_results_df['% Exceed nominal trip limit'] = excel_s_results_df['Total No. Exceed rating nominal trip limit'] / excel_s_results_df['Total Data Point']
    excel_s_results_df['% Exceed upper trip limit'] = excel_s_results_df['Total No. Exceed rating upper trip limit'] / excel_s_results_df['Total Data Point']

    return excel_b_results_df, excel_s_results_df

# read the start tab and collect informaiton
def start_reading_process(simname, excel_file,option):
    
    # File check
    print("Check Excel and Deleting Existing Contents ...")
    try:
        wb = load_workbook(excel_file)
        if 'Start' not in wb.sheetnames:
            SharedMethods.print_message("ERROR: 'Start' sheet not found. Ensure the correct excel file selected.","31")
            return False

        # Process Start sheet first
        result = start_page_processing(wb['Start'], simname, option)

        if result is False:
            return False

        oslo_list,oslo_total,rolling_stock_df,start_page = result

        # Now remove other sheets
        for sheet_name in wb.sheetnames:
            if sheet_name != 'Start':
                wb.remove(wb[sheet_name])
        # Save changes
        wb.save(excel_file)
        
    except Exception as e:
        SharedMethods.print_message(f"ERROR: (Close the Excel file and Start Again) Error: {e}","31")
        return False
    
    # read start up information 
    columns = ['Substation Name', 'OSLO', 'TCB Type', 'FVP Type','FVP setting (kA)','Rolling Stock Types']
    start_df = pd.DataFrame(start_page['SettingTable'],columns=columns)
    start_df['FVP setting (kA)'] = start_df['FVP setting (kA)'].astype(float)

    columns = ['FVP Type','FVP setting (kA)', '-% A', '-% B','-% C','-% D', '0% A', '0% B','0% C','0% D', '+% A', '+% B','+% C','+% D']
    rating_data = pd.DataFrame(start_page['AddiTable'],columns=columns)
    
    # check duplication in OSLO id
    if not SharedMethods.find_duplicates(oslo_list): return False

    
    return start_df,oslo_total,rating_data,rolling_stock_df,start_page

# start page processing
def start_page_processing(sheet, simname, option):
    '''
    processing start page in three steps
    1. Blindly reading all tables from start page
    2. processing and validation
    3. return required data format for post processing
    
    :param sheet: Description
    '''
    #------ read header information table

    print("Reading Configuration Setting ...")
    info_start_row,info_start_col = excel_to_rowcol('A2')
    _,info_end_col = excel_to_rowcol('B2')
    setting_start_row,setting_start_col = excel_to_rowcol('A12')
    _,setting_end_col = excel_to_rowcol('F12')
    addi_start_row,addi_start_col = excel_to_rowcol('H12')
    _,addi_end_col = excel_to_rowcol('U12')

    info_table = excel_to_table_list(sheet,info_start_row,info_start_col,info_end_col,info_start_row,info_start_col,1)
    setting_table = excel_to_table_list(sheet,setting_start_row,setting_start_col,setting_end_col,setting_start_row,setting_start_col+1,1)
    addi_table = excel_to_table_list(sheet,addi_start_row,addi_start_col,addi_end_col,addi_start_row,addi_start_col,1)

    addi_start_row1,addi_start_col1 = excel_to_rowcol('W12')
    addi_end_row1,_ = excel_to_rowcol('W22')

    if setting_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at B12.","31")
        return False
    
    if addi_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at H12.","31")
        return False
    
    if option == "2" or option =="4":
        addi_table1 = excel_to_table_list_col(sheet,addi_start_col1,addi_start_row1,addi_end_row1,addi_start_row1-2,addi_start_col1,2)
        if addi_table1 == []:
            SharedMethods.print_message("ERROR: Wrong data format. No information at W12.","31")
            return False
        addi_end_col1 = addi_start_col1 + len(addi_table1[0])
        # get the rolling stock list
        rolling_stock_list = []
        for i in range(addi_start_col1,addi_end_col1+1):
            if (i-addi_start_col1) % 2 != 0:
                rolling_stock_list.append(sheet.cell(row=addi_start_row1-2, column=i).value)
        rolling_stock_df = check_rolling_stock(addi_table1,rolling_stock_list)
    else:
        rolling_stock_df = None

    # prepare the return
    oslo_list = [item[1] for item in setting_table]
    oslo_total = len(oslo_list)
    start_page = {
        "InfoTable": info_table,
        "SettingTable": setting_table,
        "AddiTable": addi_table,
        "AddiTable1": addi_table1
    }

    return oslo_list,oslo_total,rolling_stock_df,start_page

#read Rolling Stock maximum current curves list
def check_rolling_stock(data_table,rolling_stock_list):
    rolling_stock_df = {}
    columns = ['Voltage','Current']
    for index, train in enumerate(rolling_stock_list):
        data = []
        for line in data_table:
            data.append([line[2*index],line[2*index+1]])
        stock_df = pd.DataFrame(data, columns=columns)
        rolling_stock_df[train] = stock_df
    
    return rolling_stock_df
    
#read all branch list and create a list for extracting branch step outputs
def read_all_branches(start_df):

    columns = ['Substation Name', 'OSLO', 'TCB Type', 'FVP Type','FVP setting (kA)']

    bl_1 = pd.DataFrame(columns=columns)
    # copy branch list from start_df to bl_1
    bl_1 = start_df['OSLO'].tolist()
        
    #for each item in bl_1 check if it end with /E or /S add the opposite node if it not already exist in bl_1
    #not used for FVP
 
    return bl_1

# create branch list 1 in different format
# check branch list
def check_branch_list(branch_list):
    newlst = []
    for branch_id in branch_list:
            if len(branch_id) <= 6:
                if branch_id[-2:-1] =="/":
                    branch = branch_id[:len(branch_id)-2].ljust(4)+branch_id[-2:]
                    branch = branch[:4]+"-"+ branch[-1:]
                    newlst.append(branch)
                else:
                    SharedMethods.print_message(f"ERROR: Branch OSLO ID {branch_id} does not contains proper symbol. Check Input","31")
                    return False
            else:
                SharedMethods.print_message(f"ERROR: Branch OSLO ID {branch_id} is NOT in correct format. Check Input'.format(branch_id)","31")       
                return False

    return newlst

# read individual d4 file
def branch_reading_process(simname,branch_list):

    total = len(branch_list)

    # create dataframe
    branchstep_d4_df = {}

    for index, branch in enumerate(branch_list):
        print(f"Processing {branch} ...")
        filename = simname + "_" + branch +".osop.d4"
        delimiter = '\\s+'
        columns = ["BranchID","Type","Time","P_inst","Q_inst","Voltage","V_angle","Current","I_angle"]
        dtype_mapping = {"Time": str,}
        df = pd.read_csv(filename, delimiter=delimiter, names = columns, skiprows = 11,dtype = dtype_mapping) 
        # Extracting parts from the string and formatting the 'Time' column
        df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")
        # data frame process
        # save the data
        
        branchstep_d4_df[branch] = df

    return branchstep_d4_df
    #this is the dataframe containing step outputs for each branch

#compare the ratings in each step result of each branch
def branch_FVP_rating(branchstep_d4_df,branch_process_df_r):
    #add a column of current in kA for later calculations
    for key, df in branchstep_d4_df.items():
        df["Current kA"] = df["Current"]/1000
        df["Voltage V"] = df["Voltage"]*1000       

    for key, df in branchstep_d4_df.items():

        print(f"Comparing step values to FVP curve in branch {key} ...")

        #find the row of this branch in the input branch list and get the FVP coefficients
        if key in branch_process_df_r['OSLO'].values:

            #matches the OSLO name from each key in branchstep_d4_df.items to the branch process dataframe
            matching_row = branch_process_df_r.loc[branch_process_df_r['OSLO'] == key]

            #if a match is found for that OSLO name, extract the Falling Voltage Protection coefficients from the branch_process_df_r row
            if not matching_row.empty:
                # Access values directly from the matching row
                #'-% A', '-% B','-% C','-% D', '0% A', '0% B','0% C','0% D', '+% A', '+% B','+% C','+% D'
                M_A = matching_row['-% A'].values[0]
                M_B = matching_row['-% B'].values[0]
                M_C = matching_row['-% C'].values[0]
                M_D = matching_row['-% D'].values[0]

                N_A = matching_row['0% A'].values[0]
                N_B = matching_row['0% B'].values[0]
                N_C = matching_row['0% C'].values[0]
                N_D = matching_row['0% D'].values[0]

                P_A = matching_row['+% A'].values[0]
                P_B = matching_row['+% B'].values[0]
                P_C = matching_row['+% C'].values[0]
                P_D = matching_row['+% D'].values[0]

                #these variables are the coefficients for calculating the FVP curve
                #M is minus, N for Nominal and P for plus
            
            else:
                #return error if cannot get coefficients
                SharedMethods.print_message(f"ERROR: Could not match branch names when comparing ratings in step results, could not get FVP coefficients","31")
       
        else:
                SharedMethods.print_message(f"ERROR: Could not match branch names when comparing ratings in step results","31")
        #df["Current kA"] = df["Current"]/1000  

        #create list to contain the test results
        FVP_test_results =[]

        #for each row (step values) in branch step data frame, after doing the FVP test add the results in 0, 1 , 2 ,3 number to a new key of "FVP_test" in the branchstep_d4_df
        for index, row in df.iterrows():
            FVP_test_result = FVP_test(row["Current kA"], row["Voltage V"], M_A, M_B, M_C, M_D, N_A, N_B, N_C, N_D, P_A, P_B, P_C, P_D)
            FVP_test_results.append(FVP_test_result)

        df["FVP_test"] = FVP_test_results

    return branchstep_d4_df
    #return branchstep_d4_df with the "FVP_test" added

#used for comparing the voltage against FVP curves
def FVP_test(Current, Voltage, M_A, M_B, M_C, M_D, N_A, N_B, N_C, N_D, P_A, P_B, P_C, P_D):
    if Voltage < Current**3 * P_A + Current**2 * P_B + Current*P_C +P_D:
        return 3
    elif Voltage < Current**3 * N_A + Current**2 * N_B + Current*N_C +N_D:
        return 2
    elif Voltage < Current** 3 * M_A + Current** 2 * M_B + Current*M_C +M_D:
        return 1
    else:
        return 0       

#used for counting FVP test results in each branch 
def Branch_FVP_sum(results_df,branchstep_r):

    print("Counting FVP exceedances for each branch")

    for index, row in results_df.iterrows():
        B_name = row['OSLO']

        branch_steps = branchstep_r[B_name]
        num_data = len(branch_steps)

        T_1 = branch_steps["FVP_test"].value_counts().get(1,0)
        T_2 = branch_steps["FVP_test"].value_counts().get(2,0)
        T_3 = branch_steps["FVP_test"].value_counts().get(3,0)


        results_df.at[index, 'Total Data Point'] = num_data
        results_df.at[index, 'Total No. Exceed rating lower trip limit'] = T_1 + T_2 + T_3
        results_df.at[index, 'Total No. Exceed rating nominal trip limit'] = T_2 + T_3
        results_df.at[index, 'Total No. Exceed rating upper trip limit'] = T_3

    return results_df

#create substation summary for each substation
#assume as same substation if substation name, TCB type, FVP type and FVP setting match
def Summary_by_substation(results_df):

    print("Creating Substation Summary for each substation")

    # Group by the required columns and sum the remaining columns
    sub_sum_df = results_df.groupby(["Substation Name", 'TCB Type', "FVP Type", "FVP setting (kA)"]).sum(numeric_only=True).reset_index()

    # Add a column with the count of rows in each group
    sub_sum_df['Number of Nodes'] = results_df.groupby(["Substation Name", 'TCB Type', "FVP Type", "FVP setting (kA)"]).size().values

    return sub_sum_df

#create a dictionary for each substation row defined as the above for a list of Nodes and list of rolling stock that lies within that substation
def substations_node_list(sub_sum_df,results_df):
    key_columns = ["Substation Name", "FVP Type", "FVP setting (kA)"]
    key_columns2 = ["Substation Name", 'TCB Type', "FVP Type", "FVP setting (kA)"]
    dict_substation = {}

    dict_substation_name = {}

    # add substation stock extractions
    dict_substation_stock = {}
    rolling_stock_list = []
    
    for index, row in sub_sum_df.iterrows():
        #Join the values of the selected columns to form a key
        key = '_'.join(str(row[col]) for col in key_columns) # Using string to create a composite key

        sub_name = row[key_columns2].to_frame().T

        OSLO_nodes = [] #create empty list of nodes
        rolling_stock_list = [] #create empty list of rolling stock

        for index2, row2 in results_df.iterrows():
            if row["Substation Name"] == row2["Substation Name"] and row["FVP Type"] == row2["FVP Type"]and row["FVP setting (kA)"] == row2["FVP setting (kA)"]:
                OSLO_nodes.append(row2['OSLO'])

                rolling_stock_types = row2['Rolling Stock Types']

                #check if there is valid entry, only add trains to rolling_stock_list_a if entry exist. 
                if isinstance(rolling_stock_types, str):                    
                    if len(rolling_stock_types)>3:
                        #check if the divider is within the entry 
                        if ", " in rolling_stock_types:
                            rolling_stock_list_a = rolling_stock_types.split(", ")
                        else:
                            rolling_stock_list_a = [rolling_stock_types]
                    else:
                        rolling_stock_list_a = []
                else:
                    rolling_stock_list_a = []

                #append rolling stock if not already in the list for this substation
                for rs in rolling_stock_list_a:
                    if rs not in rolling_stock_list:
                        rolling_stock_list.append(rs)


        #key (substation name) gives all OSLO nodes in the substation
        dict_substation[key] = OSLO_nodes
        #key (substation name) gives all settings in the substation
        dict_substation_name[key] = sub_name
        #key (substation name) gives all rolling stock in this substation
        dict_substation_stock[key] = rolling_stock_list

    return dict_substation, dict_substation_name, dict_substation_stock

#create a dictionary for each substation, based on the branch nodes in the dictionary in the previous part
#create a dictionary to contain the step results of all branches in each substations
def substations_step_list(branchstep_r,dict_substation):

    #dictionary containing all step results in each substation    
    dict_sub_step = {}

    for key, value in dict_substation.items():

        temp_df = pd.DataFrame()

        for oslo in value:

            if oslo in branchstep_r:
                temp_df = pd.concat([temp_df, branchstep_r[oslo]], ignore_index=True)

        # Assign the concatenated DataFrame to the dictionary
        dict_sub_step[key] = temp_df
    
    return dict_sub_step

#export results summary to excel
def SEF_ratings_excel(simname,excel_result,start,excel_b_results_df, excel_s_results_df,rolling_stock_df,start_page):
    # write data to excel
    with pd.ExcelWriter(excel_result, engine='xlsxwriter') as writer:
        workbook = writer.book
        print("Generate Setting Page...")
        setting_summary(writer,start_page,start,rolling_stock_df)
        print("Generate Result excel Page...")
        result_summary_1(writer,simname,excel_b_results_df,start_page,start)
        result_summary_2(writer,simname,excel_s_results_df,start_page,start)

    return True

# new result page writer (format and writing in one go)
def setting_summary(writer: pd.ExcelWriter,start_page,start,rolling_stock_df):
    print('Copy the Setting Information...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Setting")
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1,'text_wrap': True})
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00','border': 1})
    grey_fill = workbook.add_format({'bold': True,"bg_color": "#888888"})
    # copy header info
    #===================INFO TABLE==========================================
    irow = 1
    icol = 0
    for row, line in enumerate(start_page['InfoTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data)
    
    #==================Main Setting=========================================
    irow = start
    icol = 0
    # header info
    header = ['Substation Name', 'OSLO', 'TCB Type', 'FVP Type','FVP setting (kA)','Rolling Stock Types']
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(header):
        worksheet.write(irow-2, icol + col, None, grey_fill)
    # data
    for row, line in enumerate(start_page['SettingTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)

    #==================Additional Table=========================================
    irow = start
    icol = 7
    # header info
    header = ['FVP Type','FVP setting (kA)', '-% A', '-% B','-% C','-% D', '0% A', '0% B','0% C','0% D', '+% A', '+% B','+% C','+% D']
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, col_name, header_format)
    worksheet.write(irow-2, icol+1,"Avalaible Falling Voltage Protection Types and settings based on 3rd order polynomial equation", grey_fill)
    worksheet.write(irow-2, icol+10,"Ax^3+Bx^2+Cx+D", grey_fill)

    for row, line in enumerate(start_page['AddiTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,number_format)

    #==================Additional Table=========================================
    if start_page['AddiTable1'] is not None:
        irow = start
        icol = 22
        worksheet.write(irow-3, icol, 'Rolling Stock', header_format)
        for train, df in rolling_stock_df.items():
            worksheet.write(irow-2, icol, '', header_format)
            worksheet.write(irow-2, icol+1, train, header_format)
            worksheet.write(irow-1, icol, 'Voltage (V)', header_format)
            worksheet.write(irow-1, icol+1, 'Current (kA)', header_format)
            # Write DataFrame values one by one
            for row_num in range(len(df)):
                for col_num in range(len(df.columns)):
                    value = df.iloc[row_num, col_num]
                    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                        worksheet.write(irow + row_num, icol + col_num, None,table_format)
                    else:
                        worksheet.write(irow + row_num, icol + col_num, value,table_format)
            icol = icol + 2
    
    worksheet.set_column('A:F', 18) # default
    worksheet.set_column('H:AZ', 10) # 
    
    return

# new result page writer (format and writing in one go)
def result_summary_1(writer: pd.ExcelWriter,simname,excel_b_results_df,start_page,start):
    print('Preparing the Branches Result...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Results in branches")
    # define formatting
    # Header: bold, center, grey background, all borders
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1, 'text_wrap': True})

    # Subheader: italic, size 10, grey background, all borders
    subheader_format = workbook.add_format({'italic': True,'font_size': 10,'align': 'center','valign': 'vcenter','bg_color': '#EDEDED','border': 1, 'text_wrap': True})

    # Setting info: center aligned
    setting_info_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    integer_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0','border': 1})

    # Percentage format: 0.00%
    percentage_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00%','border': 1})

    # Write Basic Information
    project_name = start_page['InfoTable'][0][1]
    feeding_desp = start_page['InfoTable'][1][1]
    modeller = start_page['InfoTable'][2][1]
    date = start_page['InfoTable'][3][1]
    
    worksheet.write('B2', "Project Name:")
    worksheet.write('C2', project_name)
    worksheet.write('B3', "Simulation Name:")
    worksheet.write('C3', simname)
    worksheet.write('B4', "Feeding Arrangement:")
    worksheet.write('C4', feeding_desp)
    worksheet.write('B5', "Result Created by:")
    worksheet.write('C5', modeller)
    worksheet.write('B6', "Result Created at:")
    worksheet.write('C6', datetime.now().strftime("%d-%m-%Y %H:%M"))

    # actual data writing started
    row1, cols1 = excel_b_results_df.shape

    #==================== FIRST TABLE=============================================================
    irow = start-2
    icol = 1
    # write first table
    for c_idx, col_name in enumerate(excel_b_results_df.columns):
        worksheet.write(irow, icol + c_idx, col_name, header_format)

    for r_idx, row in enumerate(excel_b_results_df.values):
        for c_idx, value in enumerate(row):
            if c_idx in [0,1,2,3]: # table
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, setting_info_format)
            elif c_idx == 4: # settings
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, number_format)
            elif c_idx in [9,10,11]: # % exceedance
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, percentage_format)
            else:
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, integer_format)

    # getting the range
    r_range = xl_range(irow+1,icol+1,irow+row1,icol+1)
    low_1 = xl_range(irow+1,icol+6,irow+row1,icol+6)
    low_2 = xl_range(irow+1,icol+7,irow+row1,icol+7)
    low_3 = xl_range(irow+1,icol+8,irow+row1,icol+8)

    # conditional formatting
    red_bkg = workbook.add_format({"bg_color": "#FF0000"})
    amber_bkg = workbook.add_format({"bg_color": "#FFBF00"})
    yellow_bkg = workbook.add_format({"bg_color": "#FFFF00"})
    green_bkg = workbook.add_format({"bg_color": "#00FF00"})
    
    worksheet.conditional_format(r_range,{'type': 'formula','criteria': f'={low_3}>0','format': red_bkg})
    worksheet.conditional_format(r_range,{'type': 'formula','criteria': f'={low_2}>0','format': amber_bkg}) 
    worksheet.conditional_format(r_range,{'type': 'formula','criteria': f'={low_1}>0','format': yellow_bkg}) 
    worksheet.conditional_format(r_range,{'type': 'formula','criteria': f'={low_1}=0','format': green_bkg}) 

    # set column width
    worksheet.set_column('B:M', 15) # default
    worksheet.set_column('B:B', 25) # supply point name
    worksheet.set_column('D:D', 20) # feeder station name
    
    return

# new result page writer (format and writing in one go)
def result_summary_2(writer: pd.ExcelWriter,simname,excel_b_results_df,start_page,start):
    print('Preparing the Substations Result...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Summary results each substation")
    # define formatting
    # Header: bold, center, grey background, all borders
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1, 'text_wrap': True})

    # Subheader: italic, size 10, grey background, all borders
    subheader_format = workbook.add_format({'italic': True,'font_size': 10,'align': 'center','valign': 'vcenter','bg_color': '#EDEDED','border': 1, 'text_wrap': True})

    # Setting info: center aligned
    setting_info_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    integer_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0','border': 1})

    # Percentage format: 0.00%
    percentage_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00%','border': 1})

    # Write Basic Information
    project_name = start_page['InfoTable'][0][1]
    feeding_desp = start_page['InfoTable'][1][1]
    modeller = start_page['InfoTable'][2][1]
    date = start_page['InfoTable'][3][1]
    
    worksheet.write('B2', "Project Name:")
    worksheet.write('C2', project_name)
    worksheet.write('B3', "Simulation Name:")
    worksheet.write('C3', simname)
    worksheet.write('B4', "Feeding Arrangement:")
    worksheet.write('C4', feeding_desp)
    worksheet.write('B5', "Result Created by:")
    worksheet.write('C5', modeller)
    worksheet.write('B6', "Result Created at:")
    worksheet.write('C6', datetime.now().strftime("%d-%m-%Y %H:%M"))

    # actual data writing started
    row1, cols1 = excel_b_results_df.shape

    #==================== FIRST TABLE=============================================================
    irow = start-2
    icol = 1
    # write first table
    for c_idx, col_name in enumerate(excel_b_results_df.columns):
        worksheet.write(irow, icol + c_idx, col_name, header_format)

    for r_idx, row in enumerate(excel_b_results_df.values):
        for c_idx, value in enumerate(row):
            if c_idx in [0,1,2]: # table
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, setting_info_format)
            elif c_idx == 3: # settings
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, number_format)
            elif c_idx in [9,10,11]: # % exceedance
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, percentage_format)
            else:
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, integer_format)

    # getting the range
    r_range = xl_range(irow+1,icol,irow+row1,icol)
    low_1 = xl_range(irow+1,icol+6,irow+row1,icol+6)
    low_2 = xl_range(irow+1,icol+7,irow+row1,icol+7)
    low_3 = xl_range(irow+1,icol+8,irow+row1,icol+8)


    # conditional formatting
    red_bkg = workbook.add_format({"bg_color": "#FF0000"})
    amber_bkg = workbook.add_format({"bg_color": "#FFBF00"})
    yellow_bkg = workbook.add_format({"bg_color": "#FFFF00"})
    green_bkg = workbook.add_format({"bg_color": "#00FF00"})
    
    worksheet.conditional_format(r_range,{'type': 'formula','criteria': f'={low_3}>0','format': red_bkg})
    worksheet.conditional_format(r_range,{'type': 'formula','criteria': f'={low_2}>0','format': amber_bkg}) 
    worksheet.conditional_format(r_range,{'type': 'formula','criteria': f'={low_1}>0','format': yellow_bkg}) 
    worksheet.conditional_format(r_range,{'type': 'formula','criteria': f'={low_1}=0','format': green_bkg}) 

    # set column width
    worksheet.set_column('B:M', 15) # default
    worksheet.set_column('B:B', 25) # supply point name
    worksheet.set_column('E:E', 20) # feeder station name
    
    return

#export step results to excel
def FVP_step_excel(simname,output_plots,excel_s_results_df,sub_sum_df,dict_sub_step,dict_substation_name,rating_data,dict_substation_stock,rolling_stock_df,start_page,start):

    with pd.ExcelWriter(output_plots, engine='xlsxwriter') as writer:
        workbook = writer.book
        print("Generate Result excel Page...")
        result_summary_2(writer,simname,excel_s_results_df,start_page,start)

        # prepare the data frame
        writer_individual_substation(writer,simname,dict_sub_step,dict_substation_name,dict_substation_stock,rolling_stock_df,rating_data,start_page,start)

        # plotting the graph
        fvp_plot(writer,dict_sub_step,dict_substation_stock,dict_substation_name,start)

        print("Saving Data...")

    return True

def writer_individual_substation(writer: pd.ExcelWriter,simname, dict_sub_step,dict_substation_name,dict_substation_stock,rolling_stock_df,rating_data,start_page,start):
    workbook = writer.book
    # define formatting
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1, 'text_wrap': True})
    setting_info_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.0000','border': 1})
    data_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.0','border': 1})
    integer_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0','border': 1})

    dict_substation_rating_data = {}
    r_start = start - 2
    icol = 1

    # Write Basic Information
    project_name = start_page['InfoTable'][0][1]
    feeding_desp = start_page['InfoTable'][1][1]
    modeller = start_page['InfoTable'][2][1]
    date = start_page['InfoTable'][3][1]
    
    #for each substation dataframes exist in the dictionary of dict_sub_step
    for key, branch_step in dict_sub_step.items():
        print(f"Adding A sheet for substation {key} ...")

        #make sure the sheet_name is never longer than 30 characters
        if len(key) <31:
            sheet_name_variable = key
        else:
            sheet_name_variable = key[-30:]

        worksheet = worksheet = workbook.add_worksheet(sheet_name_variable)
        #write the branch step dataframe to excel with sheet name the same name as the key
        pddataframe_to_excel_with_format(worksheet,r_start,icol,branch_step,header_format,setting_info_format)
        # ===============================
        # Write titles in worksheet
        # ===============================
        worksheet.write('B2', "Project Name:")
        worksheet.write('C2', project_name)
        worksheet.write('B3', "Simulation Name:")
        worksheet.write('C3', simname)
        worksheet.write('B4', "Feeding Arrangement:")
        worksheet.write('C4', feeding_desp)
        worksheet.write('B5', "Result Created by:")
        worksheet.write('C5', modeller)
        worksheet.write('B6', "Result Created at:")
        worksheet.write('C6', datetime.now().strftime("%d-%m-%Y %H:%M"))
        # ===============================
        # Substation Information
        # ===============================
        worksheet.write('B7', "Substation Name:")
        worksheet.write('C7', dict_substation_name[key]['Substation Name'].iloc[0])
        worksheet.write('B8', "TCB Type:")
        worksheet.write('C8', dict_substation_name[key]['TCB Type'].iloc[0])
        worksheet.write('B9', "FVP Type:")
        worksheet.write('C9', dict_substation_name[key]['FVP Type'].iloc[0])
        worksheet.write('B10', "FVP setting (kA):")
        worksheet.write('C10', dict_substation_name[key]['FVP setting (kA)'].iloc[0])
        # ===============================
        # Merge rating data
        # ===============================
        dict_substation_rating_data[key] = pd.merge(dict_substation_name[key],rating_data,on=['FVP Type', 'FVP setting (kA)'],how='left')
        # ===============================
        # FVP Coefficients Section
        # ===============================
        worksheet.write('E6', "FVP coefficients")
        worksheet.write('F6', "for plotting curves")

        worksheet.write('E7', "FVP Type:",header_format)
        worksheet.write('F7', "FVP Setting (kA):",header_format)
        worksheet.write('G7', "-% A (^3)",header_format)
        worksheet.write('H7', "-% B (^2)",header_format)
        worksheet.write('I7', "-% C (^1)",header_format)
        worksheet.write('J7', "-% D",header_format)
        worksheet.write('K7', "100% A (^3)",header_format)
        worksheet.write('L7', "100% B (^2)",header_format)
        worksheet.write('M7', "100% C (^1)",header_format)
        worksheet.write('N7', "100% D",header_format)
        worksheet.write('O7', "+% A (^3)",header_format)
        worksheet.write('P7', "+% B (^2)",header_format)
        worksheet.write('Q7', "+% C (^1)",header_format)
        worksheet.write('R7', "+% D",header_format)
        # ===============================
        # Write Data Row
        # ===============================
        rating_row = dict_substation_rating_data[key].loc[0]
        # -% curve
        a1 = rating_row['-% A'] # Coefficient for x^3
        b1 = rating_row['-% B'] # Coefficient for x^2
        c1 = rating_row['-% C'] # Coefficient for x
        d1 = rating_row['-% D'] # Constant term
        # 0% curve
        a2 = rating_row['0% A'] # Coefficient for x^3
        b2 = rating_row['0% B'] # Coefficient for x^2
        c2 = rating_row['0% C'] # Coefficient for x
        d2 = rating_row['0% D'] # Constant term
        # +% curve
        a3 = rating_row['+% A'] # Coefficient for x^3
        b3 = rating_row['+% B'] # Coefficient for x^2
        c3 = rating_row['+% C'] # Coefficient for x
        d3 = rating_row['+% D'] # Constant term
 
        worksheet.write('E8', dict_substation_rating_data[key].loc[0, 'FVP Type'],number_format)
        worksheet.write('F8', dict_substation_rating_data[key].loc[0, 'FVP setting (kA)'],number_format)
        worksheet.write('G8', a1, number_format)
        worksheet.write('H8', b1, number_format)
        worksheet.write('I8', c1, number_format)
        worksheet.write('J8', d1, number_format)

        worksheet.write('K8', a2, number_format)
        worksheet.write('L8', b2, number_format)
        worksheet.write('M8', c2, number_format)
        worksheet.write('N8', d2, number_format)

        worksheet.write('O8', a3, number_format)
        worksheet.write('P8', b3, number_format)
        worksheet.write('Q8', c3, number_format)
        worksheet.write('R8', d3, number_format)

        FVP_type = dict_substation_name[key]['FVP Type'].iloc[0]

        plus_minus = "\u00B1"  # ± symbol
        if FVP_type == "HSL" :
            tol = plus_minus + "10%"
        else:
            tol = plus_minus + "15%" 
        worksheet.write('G6', tol,header_format)

        worksheet.write('O11', 'Current (kA)',header_format)
        worksheet.write('P11', '-% Voltage (V) lower trip limit',header_format)
        worksheet.write('Q11', '100% Voltage (V) nominal trip limit',header_format)
        worksheet.write('R11', '+% Voltage (V) upper trip limit',header_format)

        # Current (kA) values in 0.5 increment from 0 to 10
        values = [i * 0.5 for i in range(21)]
        # Write the values in column O from O12 onwards
        for idx, value in enumerate(values, start=12):
            worksheet.write(f'O{idx}',value,data_format)

        # For -% lower trip limit Calculate the polynomial values and write them in column P from P12 onwards
        for idx, value in enumerate(values, start=12):
            x = value
            poly_value = a1 * x**3 + b1 * x**2 + c1 * x + d1
            worksheet.write(f'P{idx}',poly_value,data_format)

        # For 100% Voltage (V) nominal trip limit Calculate the polynomial values and write them in column Q from P12 onwards
        for idx, value in enumerate(values, start=12):
            x = value
            poly_value = a2 * x**3 + b2 * x**2 + c2 * x + d2
            worksheet.write(f'Q{idx}',poly_value,data_format)

        # For +% Voltage (V) upper trip limit Calculate the polynomial values and write them in column R from P12 onwards
        for idx, value in enumerate(values, start=12):
            x = value
            poly_value = a3 * x**3 + b3 * x**2 + c3 * x + d3
            worksheet.write(f'R{idx}',poly_value,data_format)

        rs_row = 34
        worksheet.write(f'O{rs_row}','All Rolling Stocks Used',header_format)
        row=rs_row+1
        column = 13
        
        # find number of rolling stock 
        rs_list= dict_substation_stock[key]

        # for each rolling stock in rs_list
        #check for all avalaible rolling stock details in rolling stock data frame

        print(f"Adding rolling stock information for substaion {key} ...")

        for key2, rs_details in rolling_stock_df.items():
            #if this key is in hte rs list then add it to the sheet
            if key2 in rs_list:
                worksheet.write(rs_row,column+1,key2,header_format)
                pddataframe_to_excel_with_format(worksheet,row,column+1,rs_details,header_format,data_format)
                column = column+2

        # set column width
        worksheet.set_column('B:R', 12) # default
        worksheet.set_column('B:B', 25) # 

    return

#plot the graphs in all sheets created in FVP_step_excel()
def fvp_plot(writer:pd.ExcelWriter, dict_sub_step,dict_substation_stock,dict_substation_name,start):
    # Current (kA) values in 0.5 increment from 0 to 10
    workbook = writer.book
    values = [i * 0.5 for i in range(21)]

    for key, branch_step in dict_sub_step.items():
        
        print(f"Adding scatter plot for substaion {key} ...")
        #make sure the sheet_name is never longer than 30 characters
        if len(key) <31:
            sheet_name_variable = key
        else:
            sheet_name_variable = key[-30:]

        #copy ratings values in spreadsheet for plotting
        worksheet = writer.sheets[sheet_name_variable]

        #information for chart new title format
        Sub_name = dict_substation_name[key]['Substation Name'].iloc[0]
        TCB_type = dict_substation_name[key]['TCB Type'].iloc[0]
        FVP_type = dict_substation_name[key]['FVP Type'].iloc[0]
        FVP_setting = dict_substation_name[key]['FVP setting (kA)'].iloc[0]

        plus_minus = "\u00B1"  # ± symbol
        if FVP_type == "HSL" :
            tol = plus_minus + "10%"
        else:
            tol = plus_minus + "15%" 

        # Create scatter chart
        chart = workbook.add_chart({'type': 'scatter', "subtype": "straight"})

        chart.set_size({'width': 15*64, 'height': 26*20})

        chart.set_title({'name': f'FVP Plot, {Sub_name} ({FVP_type} {FVP_setting}kA, {tol})'})
        chart.set_legend({'position': 'bottom'})

        # Define data for the scatter plot (from branch_step)
        current_col = 10 # K 0-based index
        voltage_col = 11 # L 0-based index
        row = start - 1
        chart.add_series({
            'name': 'Voltage vs Current',
            'categories': [worksheet.name, row, current_col, row + len(branch_step) - 1, current_col],
            'values':     [worksheet.name, row, voltage_col, row + len(branch_step) - 1, voltage_col],
            'line':   {'none': True},
            'marker': {'type': 'circle','size': 2},
        })

        # Define -% lower trip limit data for the curve (columns O and P)
        col1 = 14 # O current kA 
        col2 = 15 # P voltage lower limit
        col3 = 16 # Q normal limit
        col4 = 17 # R voltage upper limit
        # build customised labels
        custom_labels = []
        for i in range(21):
            if i == 12:
                custom_labels.append({'value': 'lower trip limit'})
            else:
                custom_labels.append({'delete': True})
        chart.add_series({
            'name': 'lower trip limit',
            'categories': [worksheet.name, row, col1, row + 20, col1],
            'values':     [worksheet.name, row, col2, row + 20, col2],
            'smooth':     True,
            'line':   {'width':1.5, 'color': "#FF0000", 'dash_type': 'square_dot'},
            'data_labels': {'value': True,'custom': custom_labels, 'position': 'right','border': {'color': 'red','width': 1.2},'fill': {'color': 'white'},},
        })

        # Define normal trip limit data for the curve (columns O and Q)
        custom_labels = []
        for i in range(21):
            if i == 13:
                custom_labels.append({'value': 'normal trip limit'})
            else:
                custom_labels.append({'delete': True})
        chart.add_series({
            'name': 'normal trip limit',
            'categories': [worksheet.name, row, col1, row + 20, col1],
            'values':     [worksheet.name, row, col3, row + 20, col3],
            'smooth':     True,
            'line':   {'width':1.5, 'color': "#000000",},
            'data_labels': {'value': True,'custom': custom_labels,'position': 'right','border': {'color': 'black','width': 1.2},'fill': {'color': 'white'},},
        })

        # Define -% lower trip limit data for the curve (columns O and P)
        custom_labels = []
        for i in range(21):
            if i == 13:
                custom_labels.append({'value': 'upper trip limit'})
            else:
                custom_labels.append({'delete': True})
        chart.add_series({
            'name': 'upper trip limit',
            'categories': [worksheet.name, row, col1, row + 20, col1],
            'values':     [worksheet.name, row, col4, row + 20, col4],
            'smooth':     True,
            'line':   {'width':1.5, 'color': "#FF0000", 'dash_type': 'square_dot'},
            'data_labels': {'value': True,'custom': custom_labels,'position': 'right','border': {'color': 'red','width': 1.2},'fill': {'color': 'white'},},
        })

        #add the rolling stocks to scatter graph
        # Define a list of custom colors (avoiding blue, black, and red)
        custom_colors = [
            "#00FF00",  # Green
            "#FFA500",  # Orange
            "#800080",  # Purple
            "#FFFF00",  # Yellow
            "#00CED1",  # DarkTurquoise
            "#FF69B4",  # HotPink
            "#8B4513",  # SaddleBrown
            "#4B0082",  # Indigo
            "#A52A2A",  # Brown
            "#7FFF00",  # Chartreuse
        ]

        # find number of rolling stock 
        rs_list= dict_substation_stock[key]
        row = start + 20 + 4
        column = 14
        for index, rs in enumerate(rs_list):
            line_color = custom_colors[index % len(custom_colors)]
            custom_labels = []
            for i in range(11):
                if i == 7:
                    custom_labels.append({'value': rs})
                else:
                    custom_labels.append({'delete': True})
            chart.add_series({
                'name': rs,
                'categories': [worksheet.name, row, column+1, row + 10, column+1],
                'values':     [worksheet.name, row, column, row + 10, column],
                'line':   {'width':1.5, 'color': line_color,},
                'data_labels': {'value': True,'custom': custom_labels,'position': 'right','border': {'color': line_color,'width': 1.2},'fill': {'color': 'white'},},
            })
            column = column+2

        chart.set_y_axis({
            'name':"Voltage (V)",
            'min': 300,
            'max': 900,
            'major_unit': 100,
            'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
        })
        chart.set_x_axis({
            'name': "Current (kA)",
            'min': 0,
            'max': 8,
            'major_unit': 1,
            'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
        })

        # Insert chart
        worksheet.insert_chart('T3', chart)
    return True

#============================================================================
# Check if the script is run as the main module
if __name__ == "__main__":
    # Add your debugging code here
    simname = "DC001"  # Provide a simulation name or adjust as needed
    main_option = "13"  # Adjust as needed
    time_start = "0010000"  # Adjust as needed
    time_end = "0013000"  # Adjust as needed
    option_select = "4"  # Adjust as needed
    text_input = "DC001_FVP"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = 5  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)