#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jieming Ye
# Created on: April 2025
# Last Modified: April 2025
#=================================================================
# Copyright (c) 2025 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Pre-requisite: 
SimulationName.battery.txt: default oslo output file after successfully run a simulation from version RN29 with battery train running.
xxxxx.xlsx: excel spreadsheet with proper user settings.
Used Input:
simname: to locate the result file or file rename
time_start: to define the analysis start time
time_end: to define the analysis end time
option_select: to define the option selected in subfunction
text_input: to locate the excel file name
other input for oslo_extraction.py only.
Expected Output:
Updated excel spreadsheet with analysis result.
Description:
TBC
"""
#=================================================================
# VERSION CONTROL
# V1.0 (Jieming Ye) - Initial Version
# V2.0 (Jieming Ye) - Refactor using xlsxwriter instead of openpyxl
#=================================================================
# Set Information Variable
# N/A
#=================================================================

import pandas as pd
import numpy as np
from xlsxwriter.utility import xl_range
from datetime import datetime
from openpyxl import load_workbook

# import vision_oslo
from vision_oslo_extension.shared_contents import SharedMethods
from vision_oslo_extension.shared_excel_helper import excel_to_rowcol, excel_to_table_list, pddataframe_to_excel_with_format


def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):
    
    print("")
    print("New Battery Train Assessment From VISION RN29- - - > ")
    print("")

    simname = simname
    excel_file = text_input + ".xlsx"
    result_file = simname + ".battery.txt"
    result_file_2 = simname + ".traction.txt"
    excel_result = f"{excel_file.rsplit('.', 1)[0]}_result.xlsx"

    option = option_select # 1:Fully Restart, require oof, and list

    time_increment = 5
    start = 10
    space  = 5

    if not SharedMethods.check_existing_file(result_file):
        SharedMethods.print_message(f"ERROR: Ensure you rerun the simulation with 'Run Battery Train' option selected !","31")
        return False
    
    if not SharedMethods.check_existing_file(result_file_2):
        SharedMethods.print_message(f"ERROR: Ensure you rerun the simulation with 'Run Battery Train' option selected !","31")
        return False
    
    if not SharedMethods.check_existing_file(excel_file):
        return False

    # read data from start tab
    if not SharedMethods.can_write_file(excel_result):
        SharedMethods.print_message(f"ERROR: Result file {excel_result} is currently in use. Please close or delete it before running the process.","31")
        return False
    
    result = start_reading_process(
        simname, time_start, time_end, text_input, low_v, high_v, time_step,excel_file,option
    )
    if result == False:
        return False
    else:
        plot_type,marker_route_list, marker_location_list, marker_distance_list, start_df, start_page = result

    # process .battery.txt file
    result = train_reading_process(simname,time_increment,start_df,result_file)
    if result == False:
        return False
    else:
        result_data, batterydataframe = result

    # process .traction.txt file
    tractiondataframe = train_reading_process_traction(simname,time_increment,start_df,result_file_2)

    # append traction data to battery for bettery analysis
    result_data, ds1dataframe = additional_data_process(result_data,time_increment,batterydataframe,tractiondataframe)

    # update result
    result_df = result_table_prepare(start_df, result_data)

    # update the excel
    data_write_save(simname,excel_result,start,space,start_df,result_df,ds1dataframe,plot_type,marker_route_list, marker_location_list, marker_distance_list,start_page)

    return True


# write data to excel
def data_write_save(simname,excel_result,start,space,start_df,result_df,ds1dataframe,plot_type,marker_route_list, marker_location_list, marker_distance_list,start_page):
    # write data to excel
    with pd.ExcelWriter(excel_result, engine='xlsxwriter') as writer:
        # get currrent workbook to do process
        workbook = writer.book
        print("Generate Setting Page...")
        setting_summary(writer,start_df,start_page,plot_type,start)
        print("Generate Result Page...")
        result_summary(writer,simname,start_df,result_df,start_page,start,space)

        # Write each DataFrame to a different sheet in the Excel file
        print("Writing individual Trains...")
        train_list = start_df['Train ID'].tolist()
        for index, train in enumerate(train_list):
            
            print(f"Saving {train}...")
            dflist = ds1dataframe[index]
            # emty columns
            dflist.insert(dflist.columns.get_loc('Control Mode No.')+1,'New_C_1', np.nan)
            dflist.insert(dflist.columns.get_loc('Track Energy (kWh)')+1,'New_C_2', np.nan)
            dflist.insert(dflist.columns.get_loc('New_C_2')+1,'Excel_Time', np.nan)
            dflist.insert(dflist.columns.get_loc('Excel_Time')+1,'Excel_SoC', np.nan)

            dflist.to_excel(writer, sheet_name=f'{index+1}_Train_{train}', index=False, startrow = 2)

        start_row = 4 # (1-index based)
        print("Add Information Supporting Plotting....")
        addtional_info(writer,train_list,ds1dataframe,result_df,start_row)

        # prepare for additional marker
        datapoint_row,datapoint_location =  put_dummy_marker(train_list,ds1dataframe,result_df,start_row,marker_route_list, marker_location_list, marker_distance_list)

        # jounery plotting
        jounery_plot(writer,train_list,ds1dataframe,result_df,start_row,datapoint_row,datapoint_location,plot_type)

        print("Saving Data...")

    return

# new result page writer (format and writing in one go)
def setting_summary(writer: pd.ExcelWriter,start_df,start_page,plot_type,start):
    print('Copy the Setting Information...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Setting")
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    grey_fill = workbook.add_format({"bg_color": "#888888"})
    highlight_fill = workbook.add_format({'align': 'center','valign': 'vcenter','bg_color': "#FFFF00",'border': 1})
    # copy header info
    #===================INFO TABLE==========================================
    irow = 1
    icol = 0
    for row, line in enumerate(start_page['InfoTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data)
    
    #==================Main Setting=========================================
    irow = start
    icol = 0
    # header info
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # data
    for row, line in enumerate(start_page['SettingTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)

    #==================Supply Point=========================================
    irow = start
    icol = 9
    # header info
    header = ['Jounery Profile','Distance Gone (m)','Location Name']
    for col, col_name in enumerate(header):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # additional text
    worksheet.write(irow-3, icol,"Additional Location Marker", header_format)
    worksheet.write(irow-4, icol,"Plot Settings", header_format)
    if plot_type == 2:
        worksheet.write(irow-4, icol+1,"Mode Split", highlight_fill)
    else:
        worksheet.write(irow-4, icol+1,"Continous", highlight_fill)
    
    # addtional table
    for row, line in enumerate(start_page['AddiTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)
    
    worksheet.autofit()
    
    return

def result_summary(writer: pd.ExcelWriter,simname,start_df,result_df,start_page,start,space):
    print('Preparing the Final Result...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Result")
    # define formatting
    # Header: bold, center, grey background, all borders
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})

    # Subheader: italic, size 10, grey background, all borders
    subheader_format = workbook.add_format({'italic': True,'font_size': 10,'align': 'center','valign': 'vcenter','bg_color': '#EDEDED','border': 1, 'text_wrap': True})

    # Setting info: center aligned
    setting_info_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '00.00','border': 1})

    # Integer number format: 00
    integer_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0','border': 1})

    # Percentage format: 0.00%
    percentage_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00%','border': 1})

    # Write Basic Information
    project_name = start_page['InfoTable'][0][1]
    feeding_desp = start_page['InfoTable'][1][1]
    modeller = start_page['InfoTable'][2][1]
    date = start_page['InfoTable'][3][1]
    
    worksheet.write('B2', "Project Name:")
    worksheet.write('C2', project_name)
    worksheet.write('B3', "Simulation Name:")
    worksheet.write('C3', simname)
    worksheet.write('B4', "Feeding Arrangement:")
    worksheet.write('C4', feeding_desp)
    worksheet.write('B5', "Result Created by:")
    worksheet.write('C5', modeller)
    worksheet.write('B6', "Result Created at:")
    worksheet.write('C6', datetime.now().strftime("%d-%m-%Y %H:%M"))

    # actual data writing started
    row1, cols1 = start_df.shape
    row2, cols2 = result_df.shape

    #==================== FIRST TABLE=============================================================
    irow = start
    icol = 1

    # getting the range
    h1_range = xl_range(irow-1,icol,irow-1,icol+4)
    h2_range = xl_range(irow-1,icol+5,irow-1,icol+9)
    h3_range = xl_range(irow-1,icol+10,irow-1,icol+15)
    h4_range = xl_range(irow-1,icol+16,irow-1,icol+20)
    energy_range = xl_range(irow+1,icol+15,irow+row2,icol+15)
    soc_range1 = xl_range(irow+1,icol+16,irow+row2,icol+17)
    soc_range2 = xl_range(irow+1,icol+19,irow+row2,icol+20)
    low_critera = f"$F{irow+2}"
    high_critera = f"$E{irow+2}"
    # write first table
    worksheet.merge_range(h1_range,"Train Jounery Settings",header_format)
    worksheet.merge_range(h2_range,"Total Time Spent on Each Mode (s)",header_format)
    worksheet.merge_range(h3_range,"Train Battery Unit Energy Result",header_format)
    worksheet.merge_range(h4_range,"Train Battery Unit SoC Result",header_format)

    for c_idx, col_name in enumerate(result_df.columns):
        worksheet.write(irow, icol + c_idx, col_name, subheader_format)

    for r_idx, row in enumerate(result_df.values):
        for c_idx, value in enumerate(row):
            if c_idx in [0,1]: # settings
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, setting_info_format)
            elif c_idx in [2,10,11,12,13,14,15]: # Energy
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, number_format)
            elif c_idx in [5,6,7,8,9]: # time seconds
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, integer_format)
            else: # SoC percentage
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, percentage_format)

    # conditional formatting
    red_bkg = workbook.add_format({"bg_color": "#FF0000"})
    yellow_bkg = workbook.add_format({"bg_color": "#FFFF00"})
    green_bkg = workbook.add_format({"bg_color": "#00FF00"})
    
    worksheet.conditional_format(energy_range,{'type': 'cell','criteria':'>', 'value': 0,'format': red_bkg})
    
    worksheet.conditional_format(soc_range1,{'type': 'cell','criteria':'=', 'value': 0,'format': red_bkg})
    worksheet.conditional_format(soc_range1,{'type': 'cell','criteria':'<', 'value': f'={low_critera}','format': yellow_bkg})
    worksheet.conditional_format(soc_range1,{'type': 'cell','criteria':'>', 'value': f'={high_critera}','format': yellow_bkg})
    worksheet.conditional_format(soc_range1,{'type': 'cell','criteria':'between', 'minimum': f'={low_critera}','maximum': f'={high_critera}','format': green_bkg})

    worksheet.conditional_format(soc_range2,{'type': 'cell','criteria':'=', 'value': 0,'format': red_bkg})
    worksheet.conditional_format(soc_range2,{'type': 'cell','criteria':'<', 'value': f'={low_critera}','format': yellow_bkg})
    worksheet.conditional_format(soc_range2,{'type': 'cell','criteria':'>', 'value': f'={high_critera}','format': yellow_bkg})
    worksheet.conditional_format(soc_range2,{'type': 'cell','criteria':'between', 'minimum': f'={low_critera}','maximum': f'={high_critera}','format': green_bkg})

    # set column width
    worksheet.set_column('B:V', 13) # default
    worksheet.set_column('B:B', 25) # supply point name
    worksheet.set_column('D:D', 15) # feeder station name
    
    return

def put_dummy_marker(train_list,ds1dataframe,result_df,start_row,marker_route_list, marker_location_list, marker_distance_list):
    
    print("Analysing Additional Marker...")
    # this will return a final list as data point that could be shown as a new series and added to to the plot
    datapoint_row = []
    datapoint_location = []
    for index, train in enumerate(train_list):
        datapoint_row.append([])
        datapoint_location.append([])

        route_name = result_df.loc[index, 'Train Journey'] # get the route name
        train_df = ds1dataframe[index] # get the data frame

        for index2, marker_route in enumerate(marker_route_list):
            if marker_route == route_name:

                for index3,item in enumerate(marker_distance_list[index2]):
                    # find dataframe index with closest distance
                    closest_index = (train_df['Distance Gone (m)'] - item).abs().idxmin()
                    relative_index = train_df.index.get_loc(closest_index)
                    datapoint_row[index].append(int(start_row+relative_index))
                    datapoint_location[index].append(marker_location_list[index2][index3])
            
    return datapoint_row,datapoint_location

def addtional_info(writer: pd.ExcelWriter,train_list,ds1dataframe,result_df,start_row):
    # Create time format
    workbook = writer.book
    time_format = workbook.add_format({'num_format': 'hh:mm:ss'})
    soc_format = workbook.add_format({'num_format': '0.00%'})
       
    for index, train in enumerate(train_list):

        dflist = ds1dataframe[index]

        worksheet = writer.sheets[f'{index+1}_Train_{train}']
        
        col_time_excel = 24   # Y column (0-based index)
        soc_excel = 25        # Z column (0-based index)

        for i in range(len(dflist)):
            r = start_row + i - 1
            row = r + 1
            formula = f'=TIME(MID(B{row},4,2),MID(B{row},7,2),RIGHT(B{row},2))'
            worksheet.write_formula(r, col_time_excel, formula, time_format)
        
        for i in range(len(dflist)):
            r = start_row + i - 1
            row = r + 1
            formula = f'=P{row}/100'
            worksheet.write_formula(r, soc_excel, formula, soc_format)

    return

def jounery_plot(writer: pd.ExcelWriter,train_list,ds1dataframe,result_df,start_row,datapoint_row,datapoint_location,plot_type):
    print("Plotting Jounery Profile...")

    # plot no 1 = SoC vs xxx
    # plot no 2 = Energy vs xxxx

    workbook  = writer.book
    # Excel is 0-based in XlsxWriter
    data_row = start_row - 1  
    # column numbers converted to 0-based
    c1 = 24  # Time (25-1)
    c2 = 5   # Distance (6-1)
    c3 = 14  # Energy (15-1)
    c4 = 25  # SoC (26-1)

    for plot_no in range(1, 3):

        if plot_no == 1:
            cp1_start, cp1_end = c1, c4
            cp2_start, cp2_end = c2, c4
            cp1_loc, cp2_loc = "B2", "B25"
            title_suffix = " Battery SoC Profile"
            y_title = "State of Charge SoC (%)"
            y_max = 1
            y_unit = 0.1
        else:
            cp1_start, cp1_end = c1, c3
            cp2_start, cp2_end = c2, c3
            cp1_loc, cp2_loc = "T2", "T25"
            title_suffix = " Battery Energy Level Profile"
            y_title = "Battery Energy Level (kWh)"
            y_max = None
            y_unit = None

        for idx, train in enumerate(train_list):

            worksheet = writer.sheets[f'{idx+1}_Train_{train}']

            train_df = ds1dataframe[idx]
            total_rows, row_list, mode_changes = train_plot_prepare(train_df)

            route_name = result_df.loc[idx, 'Train Journey']
            sheet_name = f'{idx+1}_Train_{train}'

            # ==========================================================
            # Determine the time scale (limitation, Day 1 has to be covered)
            # ==========================================================

            xlimmin = 1
            xlimmax = 0
            t_start = ds1dataframe[idx]['Time(D/HH:MM:SS)'].iloc[0]
            t_start = t_start.split(":")
            ts = (float(t_start[0][-2:])+float(t_start[1])/60+float(t_start[1])/3600)/24
            t_end = ds1dataframe[idx]['Time(D/HH:MM:SS)'].iloc[-1]
            t_end = t_end.split(":")
            te = (float(t_end[0][-2:])+float(t_end[1])/60+float(t_end[1])/3600)/24

            if ts < xlimmin: xlimmin = ts
            if te > xlimmax: xlimmax = te
                    
            # find nearest 10 min timeline.
            for i in range(0,144):
                if i*1/144 > xlimmin:
                    xlimmin = (i-1)*1/144
                    for j in range(i,144):
                        if j*1/144 >= xlimmax:
                            xlimmax = j*1/144
                            break
                    break
            
            tspace = (xlimmax-xlimmin)/8

            # ==========================================================
            # TIME vs SOC / ENERGY
            # ==========================================================

            chart = workbook.add_chart({'type': 'scatter','subtype': 'smooth'})

            chart.set_size({'width': 17*64, 'height': 20*20})
            chart.set_title({'name': route_name + title_suffix})
            chart.set_legend({'position': 'bottom'})

            if plot_type == 2:
                for i, mode in enumerate(mode_changes):
                    if i == len(mode_changes) - 1:
                        r1 = data_row + row_list[i]
                        r2 = data_row + total_rows - 1
                    else:
                        r1 = data_row + row_list[i]
                        r2 = data_row + row_list[i+1] - 1

                    chart.add_series({
                        'name': mode,
                        'categories': [sheet_name, r1, cp1_start, r2, cp1_start],
                        'values':     [sheet_name, r1, cp1_end,   r2, cp1_end],
                    })
            else:
                chart.add_series({
                    'name': route_name,
                    'categories': [sheet_name, data_row, cp1_start, data_row + total_rows - 1, cp1_start],
                    'values':     [sheet_name, data_row, cp1_end, data_row + total_rows - 1, cp1_end],
                })

            # Addtitional data label marker as data point series
            if datapoint_row[idx] != []:
                for index, location in enumerate(datapoint_location[idx]):
                    # Convert Excel row number to 0-based row index
                    r = datapoint_row[idx][index] - 1

                    chart.add_series({
                        'name': location,
                        'categories': [sheet_name, r, cp1_start, r, cp1_start],
                        'values':     [sheet_name, r, cp1_end,   r, cp1_end],
                        'line':   {'none': True},
                        'marker': {'type': 'circle','size': 5,'border': {'color': 'black'},'fill':{'color': 'black'}},
                        'data_labels': {'series_name': True,'position':'above'},
                    })
            
            chart.set_y_axis({
                'name': y_title,
                'min': 0,
                'max': y_max,
                'major_unit': y_unit,
                'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
            })
            chart.set_x_axis({
                'name': 'Time (hh:mm:ss)',
                'min': xlimmin,
                'max': xlimmax,
                'major_unit': tspace,
                'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
            })

            worksheet.insert_chart(cp1_loc, chart)

            # ==========================================================
            # DISTANCE vs SOC / ENERGY
            # ==========================================================

            chart2 = workbook.add_chart({'type': 'scatter','subtype': 'smooth'})
            
            chart2.set_size({'width': 17*64, 'height': 20*20})
            chart2.set_title({'name': route_name + title_suffix})
            chart2.set_legend({'position': 'bottom'})

            if plot_type == 2:
                for i, mode in enumerate(mode_changes):

                    if i == len(mode_changes) - 1: # Last line
                        r1 = data_row + row_list[i]
                        r2 = data_row + total_rows - 1
                    else:
                        r1 = data_row + row_list[i]
                        r2 = data_row + row_list[i+1] - 1

                    chart2.add_series({
                        'name': mode,
                        'categories': [sheet_name, r1, cp2_start, r2, cp2_start],
                        'values':     [sheet_name, r1, cp2_end,   r2, cp2_end],
                    })
            else:
                chart2.add_series({
                    'name': route_name,
                    'categories': [sheet_name, data_row, cp2_start, data_row + total_rows - 1, cp2_start],
                    'values':     [sheet_name, data_row, cp2_end, data_row + total_rows - 1, cp2_end],
                })

            # Addtitional data label marker as data point series
            if datapoint_row[idx] != []:
                for index, location in enumerate(datapoint_location[idx]):
                    # Convert Excel row number to 0-based row index
                    r = datapoint_row[idx][index] - 1

                    chart2.add_series({
                        'name': location,
                        'categories': [sheet_name, r, cp2_start, r, cp2_start],
                        'values':     [sheet_name, r, cp2_end,   r, cp2_end],
                        'line':   {'none': True},
                        'marker': {'type': 'circle','size': 5,'border': {'color': 'black'},'fill':{'color': 'black'}},
                        'data_labels': {'series_name': True,'position':'above'},
                    })

            chart2.set_y_axis({
                'name': y_title,
                'min': 0,
                'max': y_max,
                'major_unit': y_unit,
                'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
            })
            chart2.set_x_axis({
                'name': 'Distance Gone (meter)',
                'min': 0,
                'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
            })

            worksheet.insert_chart(cp2_loc, chart2)

    return

# find row number based on dataframe
def train_plot_prepare(train_df):
    # get the total rows

    total_rows = train_df.shape[0]

    mode_changes = []
    row_list = []
    previous_mode = None

    # check row number for each mode change
    # interate each row, when never there is a change in 'Operation Mode No.', record the row number
    # start a new count, and record the Operation Mode No.
    for i, current_mode in enumerate(train_df['Operation Mode No.']):
        if current_mode != previous_mode:
            match current_mode:
                case 0:
                    mode_changes.append("Battery Suspended")
                case 1:
                    mode_changes.append("On-Wire Charging")
                case 2:
                    mode_changes.append("On-Wire Discharging")
                case 3:
                    mode_changes.append("Off-Wire Charging")
                case 4:
                    mode_changes.append("Off-Wire Discharging")
            row_list.append(i)
            previous_mode = current_mode

    return total_rows,row_list,mode_changes

# read the start tab and collect informaiton
def start_reading_process(simname, time_start, time_end, text_input, low_v, high_v, time_step, excel_file, option):
    
    # File check
    print("Check Excel and Deleting Existing Contents ...")

    try:
        wb = load_workbook(excel_file)
        if 'Start' not in wb.sheetnames:
            SharedMethods.print_message("ERROR: 'Start' sheet not found. Ensure the correct excel file selected.","31")
            return False
        
        # Process Start sheet first
        result = start_page_processing(
            wb['Start'], simname, time_start, time_end,text_input, low_v, high_v, time_step, option
        )

        if result is False:
            return False
        
        plot_type,marker_route_list, marker_location_list, marker_distance_list, start_page = result

        # Delete all sheets except 'Start'
        for sheet_name in wb.sheetnames:
            if sheet_name != 'Start':
                wb.remove(wb[sheet_name])

        # Save changes
        wb.save(excel_file)

    except Exception as e:
        SharedMethods.print_message(f"(Close the Excel file and Start Again) ERROR: {e}","31")
        return False
        
    # read start up information 
    columns = ["Train Journey","Train ID","Modelled Battery Size (kWh)","High SoC Warning (%)", \
               "Low SoC Warning (%)","Optional Battery Size (kWh)","Optional Battery SoC (%)"]
    start_df = pd.DataFrame(start_page['SettingTable'],columns=columns)
    
    return plot_type, marker_route_list, marker_location_list, marker_distance_list, start_df, start_page

def start_page_processing(sheet, simname, time_start, time_end,text_input, low_v, high_v, time_step, option):

    #------ read header information table
    print("Reading Configuration Setting ...")
    info_start_row,info_start_col = excel_to_rowcol('A2')
    _,info_end_col = excel_to_rowcol('B2')
    setting_start_row,setting_start_col = excel_to_rowcol('A11')
    _,setting_end_col = excel_to_rowcol('G11')
    addi_start_row,addi_start_col = excel_to_rowcol('J11')
    _,addi_end_col = excel_to_rowcol('L11')

    info_table = excel_to_table_list(sheet,info_start_row,info_start_col,info_end_col,info_start_row,info_start_col,1)
    setting_table = excel_to_table_list(sheet,setting_start_row,setting_start_col,setting_end_col,setting_start_row,setting_start_col+1,1)
    addi_table = excel_to_table_list(sheet,addi_start_row,addi_start_col,addi_end_col,addi_start_row,addi_start_col+1,2)

    table_list = setting_table
    if table_list == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at B11.","31")
        return False
    if addi_table == []:
        print(f"INFO: No additional marker defined as no information in 'K11'.")
    else:    
        marker_route_list, marker_location_list, marker_distance_list = check_location_list(addi_table)

    # doing some table validation          
    for line in table_list:
        route = line[0]
        if route not in marker_route_list:
            print(f"INFO: Route '{route}' does not have additional marker information for plotting.")
        train = line[1]
        if not str(train).isdigit():  # This works for positive integers represented as strings
            SharedMethods.print_message(f"ERROR: Train ID '{train}' is not a valid number. Please check your input.","31")
            return False

    # read the plotting settings (K7)
    if sheet.cell(row=7, column=11).value == 'Mode Split':
        plot_type = 2
    elif sheet.cell(row=7, column=11).value == 'Continues':
        plot_type = 1
    else:
        SharedMethods.print_message(f"WARNING: Plotting type (Mode Split/Continues) not defined at K7. Default to 'Continues'.","33")
        plot_type = 1

    start_page = {
        "InfoTable": info_table,
        "SettingTable": setting_table,
        "AddiTable": addi_table
    }

    return plot_type,marker_route_list, marker_location_list, marker_distance_list, start_page

# check location list on start page
def check_location_list(datatable):
    print("Reading Addtional Location Marker ...")
    # create location list
    marker_route_list = [] # format[route1, route2,...]
    marker_location_list = [] # format[[marker1, marker2 ...],[...],...]
    marker_distance_list = [] # format[[distance1, distance2 ...],[...],...]

    for plot_line in datatable:
        jounery = plot_line[0]
        if jounery is not None:
            if jounery not in marker_location_list:
                marker_route_list.append(jounery)
                marker_location_list.append([])
                marker_distance_list.append([])
            else:
                SharedMethods.print_message(f"WARNING: Duplicate route '{jounery}' detected. 2nd one will be ignored.","33")

    for index, jounery in enumerate(marker_route_list):
        record = False
        for plot_line in datatable:
            distance = plot_line[1]
            location = plot_line[2]
            if jounery == plot_line[0]:
                record = True
            if distance is None and record is True:
                record = False
                break

            if record:
                marker_distance_list[index].append(distance)
                marker_location_list[index].append(location)

    return marker_route_list, marker_location_list, marker_distance_list

# read battery file summary
def train_reading_process(simname,time_increment,start_df,result_file):
    print("Analysing Train Information...")

    # read the result file using comma spaced
    columns = ["TimeStep(S)","Time(D/HH:MM:SS)","Train ID","Rolling Stock No.","Battery Unit No.","Distance Gone (m)","Branch","Branch Position", \
                "Voltage Re (V)", "Voltage Im (V)", "Current Re (A)", "Current Im (A)", "Active Power (kW)", "Reactive Power (kVAR)", \
                "Battery Energy Level (kWh)", "Battery SoC Level (%)", "Operation Mode No.","Control Mode No."]

    df = pd.read_csv(result_file, delimiter=',', names = columns, skiprows = 8)  # You might need to adjust the delimiter based on your file

    # Extracting parts from the string and formatting the 'Time' column
    # df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")

    train_list = start_df['Train ID'].tolist()
    # create dataframe
    ds1dataframe = []
    result_data = []
    for train in train_list:
        # Filter the DataFrame for the current Train ID
        train_df = df[df['Train ID'] == train].copy()

        if train_df.empty:
            SharedMethods.print_message(f"ERROR: Train {train} does NOT exist in the simulation result. Check your settings...","31")
            return False

        # Get start and end values
        start_energy = train_df['Battery Energy Level (kWh)'].iloc[0]
        end_energy = train_df['Battery Energy Level (kWh)'].iloc[-1]
        change_energy = end_energy - start_energy
        start_SoC = train_df['Battery SoC Level (%)'].iloc[0]
        end_SoC = train_df['Battery SoC Level (%)'].iloc[-1]
        change_SoC = end_SoC - start_SoC

        # Get max and min values
        max_energy = train_df['Battery Energy Level (kWh)'].max()
        min_energy = train_df['Battery Energy Level (kWh)'].min()
        max_SoC = train_df['Battery SoC Level (%)'].max()
        min_SoC = train_df['Battery SoC Level (%)'].min()

        # Count time spent in each operation mode
        mode_counts = train_df['Operation Mode No.'].value_counts()

        mode0_time = mode_counts.get(0, 0) * time_increment
        mode1_time = mode_counts.get(1, 0) * time_increment
        mode2_time = mode_counts.get(2, 0) * time_increment
        mode3_time = mode_counts.get(3, 0) * time_increment
        mode4_time = mode_counts.get(4, 0) * time_increment

        result_data.append([mode0_time,mode1_time,mode2_time,mode3_time,mode4_time,start_energy,end_energy,change_energy, \
                            max_energy,min_energy,start_SoC,end_SoC,change_SoC,max_SoC,min_SoC])
        ds1dataframe.append(train_df)
    
    return result_data, ds1dataframe

# read traction file summary
def train_reading_process_traction(simname,time_increment,start_df,result_file):
    # read the result file using comma spaced
    columns = ["TimeStep(S)","Time(D/HH:MM:SS)","Train ID","Rolling Stock No.","Battery Unit No.","Distance Gone (m)","Branch","Branch Position", \
                "Voltage Re (V)", "Voltage Im (V)", "Current Re (A)", "Current Im (A)", "Active Power (kW)", "Reactive Power (kVAR)", \
                "Reserve", "Operation Mode No.","Control Mode No."]

    df = pd.read_csv(result_file, delimiter=',', names = columns, skiprows = 8)  # You might need to adjust the delimiter based on your file

    # Extracting parts from the string and formatting the 'Time' column
    # df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")

    train_list = start_df['Train ID'].tolist()
    # create dataframe
    ds1dataframe = []

    for train in train_list:
        # Filter the DataFrame for the current Train ID
        train_df = df[df['Train ID'] == train].copy()
        ds1dataframe.append(train_df)
    
    return ds1dataframe

# append addtional data from traction file to battery data list
def additional_data_process(result_data,time_increment,ds1dataframe,ds2dataframe):
    for index, train_df in enumerate(ds1dataframe):
        train_df["Track P (kW)"] = ds2dataframe[index]["Active Power (kW)"]
        train_df["Track Q (kVAR)"] = ds2dataframe[index]["Reactive Power (kVAR)"]
        train_df["Track S (kVA)"] = np.sqrt(train_df["Track P (kW)"]**2 +train_df["Track Q (kVAR)"]**2)
        train_df["Track Energy (kWh)"] = train_df["Track P (kW)"] * time_increment / 3600

        # adding column track energy when Operation Mode No. is zero and track P is postive.
        # Define mask for the condition
        mask = (train_df["Operation Mode No."] == 0) & (train_df["Battery SoC Level (%)"] == 0) # battery turned off but still require traction
        additional_energy = train_df.loc[mask,"Track Energy (kWh)"].sum()

        # insert the data to proper place
        result_row = result_data[index]
        result_data[index] = result_row[:-5] + [additional_energy] + result_row[-5:] # put it five column before

    return result_data,ds1dataframe

# ceate table 1 frame / power
def result_table_prepare(start_df, result_data):    

    columns = start_df.columns.tolist()
    columns = columns + ['Battery Idle','On-Wire Charging','On-wire Discharging','Off-wire Charging', \
                         'Off-wire Discharging', 'Start Energy (kWh)', 'End Energy (kWh)','Jounery Energy (kWh)', \
                            'Max Energy (kWh)','Min Energy (kWh)','Extra Required (kWh)', 'Start SoC (%)', 'End SoC (%)', \
                                'Jounery SoC (%)','Max SoC (%)','Min SoC (%)']
    
    # Build a list of combined rows
    result_rows = []

    for index, row in start_df.iterrows():
        result_row = result_data[index]
        # last 5 columns is SoC, convernt to percentage value
        result_row[-5:] = [x / 100 for x in result_row[-5:]]
        # Convert the row to a list, then add corresponding result_data
        combined_row = row.tolist() + result_row
        result_rows.append(combined_row)

    # Create the final DataFrame
    result_df = pd.DataFrame(data=result_rows, columns=columns)

    # drop two optional columns 'Optional Battery Size (kWh)","Optional Battery SoC (%)"
    result_df = result_df.drop(columns=["Optional Battery Size (kWh)", "Optional Battery SoC (%)"])
    
    return result_df

if __name__ == "__main__":
    # Add your debugging code here
    simname = "test_model_6"  # Provide a simulation name or adjust as needed
    main_option = "1"  # Adjust as needed
    time_start = "0070000"  # Adjust as needed
    time_end = "0080000"  # Adjust as needed
    option_select = "5"  # Adjust as needed
    text_input = "AC_07_BEMU3"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = None  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)

