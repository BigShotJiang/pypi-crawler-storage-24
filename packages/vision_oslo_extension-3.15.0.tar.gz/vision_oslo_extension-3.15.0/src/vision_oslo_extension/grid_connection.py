#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jieming Ye
# Created on: Feb 2024
# Last Modified: Feb 2024
#=================================================================
# Copyright (c) 2024 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Pre-requisite: 
SimulationName.oof: default oslo output file after successfully run a simulation.
xxxxx.xlsx: excel spreadsheet with proper user settings.
Used Input:
simname: to locate the result file or file rename
time_start: to define the analysis start time
time_end: to define the analysis end time
option_select: to define the option selected in subfunction
text_input: to locate the excel file name
other input for oslo_extraction.py only.
Expected Output:
Updated excel spreadsheet with analysis result.
Description:
This script defines the process of doing new grid compliance assessment.
First, it reads the excel file and save the user input in a data frame called start_df. Then it reads the related .d4 file and saved in a data frame list called d4dataframe. This is for future proof as only one .df file is needed for this assessment. The calculation is then carried out. It then doing some analysis and save the final result in an updated data frame. Final step is to save all information in the excel in a proper format. The whole process is easy to follow via reading the code.
The calculation to be checked is saved in d4_file_sp_process() function. Some formulas are hard coded in this function, i,e, RVC calculation, memory time calculation.
The key manual updating part is get_result_range() function which depends on the desired output format in excel, followed by table_formatting() function where some reading needs manual input. The curve_plot() function is also need manual change if some new plots is desired in the future. The other process should be auto adjustable as long as the excel input format is followed.

"""
#=================================================================
# VERSION CONTROL
# V1.0 (Jieming Ye) - Initial Version
# V2.0 (Jieming Ye) - Using xlsx writer as output
#=================================================================
# Set Information Variable
# N/A
#=================================================================

# vision_oslo_extension/excel_processing.py
import pandas as pd
import numpy as np
from xlsxwriter.utility import xl_range
from datetime import datetime
from openpyxl import load_workbook

# import vision_oslo
from vision_oslo_extension import oslo_extraction
from vision_oslo_extension.shared_contents import SharedMethods
from vision_oslo_extension.shared_excel_helper import excel_to_rowcol,excel_to_table_list,pddataframe_to_excel_with_format


def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):

    print("")
    print("New Grid Connection Assessment: ------>")
    print("")
    
    simname = simname
    # Specify Excel file name
    excel_file = text_input + ".xlsx"
    excel_result = f"{excel_file.rsplit('.', 1)[0]}_result.xlsx"

    if not SharedMethods.check_existing_file(excel_file):
        return False
    
    #option = "1" # Fully Restart, require oof,
    #option = "2" # Process only

    option = option_select # 1:Fully Restart, require oof, and list

    start = 10
    plot_start  = 10 # for feeder table, start from row 10
    total = 15

    if option not in ["0","1","2"]:
        SharedMethods.print_message("ERROR: Error in grid_connection.py. Please contact Support.","31")
        return False
    
    if option == "0":
        SharedMethods.print_message("ERROR: Please select an option to proceed.","31")
        return False

    if not SharedMethods.can_write_file(excel_result):
        SharedMethods.print_message(f"ERROR: Result file {excel_result} is currently in use. Please close or delete it before running the process.","31")
        return False
    
    # read data from start tab
    result = start_reading_process(simname,excel_file)
    if result == False: return False
    setting_df,start_page = result

    # get the feeder ID, ratio, time, etc, important info.    
    sec_v = setting_df.at[0,'Settings']  # modelled v
    time_increment = setting_df.at[1,'Settings'] # time increament

    feeder = str(setting_df.at[2,'Settings'])

    pri_v = setting_df.at[4,'Settings']  # grid voltage level
    ratio = pri_v / sec_v  # ratio between actual and modelled

    max_op_range = setting_df.at[5,'Settings']  # grid voltage max level
    min_op_range = setting_df.at[6,'Settings']  # grid voltage max level
    fault = setting_df.at[7,'Settings']  # grid voltage max level

    load_1_min = setting_df.at[9,'Settings']  # load from BA
    load_10_min = setting_df.at[10,'Settings']
    load_30_min = setting_df.at[11,'Settings']

    event_f = setting_df.at[13,'Settings']  # Assumed RVC current
    event_if = setting_df.at[14,'Settings']
    event_vif = setting_df.at[15,'Settings']

    # check input sensible or not:
    result = check_input_info(sec_v,time_increment,feeder,pri_v,max_op_range,min_op_range,fault)
    if result == False:
        return False
    
    # calculate and create result data table, calculate the criteria
    result_df = criteria_calculate(pri_v,max_op_range,min_op_range,load_1_min,load_10_min,load_30_min,time_increment)

    # check if want to go throught the feeder check process
    if option == "1":
        if not SharedMethods.check_oofresult_file(simname):
            return False
        # extract the feeder
        oslo_extraction.feeder_step(simname, time_start, time_end, "1", feeder)
        
    if option == "2":
        print("Checking essential d4 files...")
        filename = simname + "_" + feeder + ".osop.d4"
        if not SharedMethods.check_existing_file(filename):
            SharedMethods.print_message(f"ERROR: d4 file {feeder} do not exist. Select option 1 or check Supply Point ID to proceed.","31")
            return False
    
    # process d4 file
    feeder_list = [feeder]
    d4_df, d4_sum, result_df = feeder_reading_process(simname,feeder_list,pri_v,ratio,time_increment,result_df)
    
    # Update the result table for RVC
    result_df = result_rvc_update(simname, result_df,pri_v, fault, event_f,event_if,event_vif)

    # save the data
    data_write_save(simname, excel_result,start,plot_start,d4_df,d4_sum,result_df,feeder,start_page)

    return True

# write data to excel
def data_write_save(simname, excel_result,start,plot_start,d4_df,d4_sum,result_df,feeder,start_page):
    # write data to excel
    with pd.ExcelWriter(excel_result, engine='xlsxwriter') as writer:
        # get currrent workbook to do process
        workbook = writer.book
        print("Generate Setting Page...")
        setting_summary(writer,start_page,start)
        print("Generate Result Page...")
        result_summary(writer,simname,result_df,start_page,start)

        # print("Generate Plot Page...")
        print(f"Saving {feeder}...")

        # Add an empty row with NaN values
        d4_sum.loc[len(d4_sum)] = np.nan

        # write calculation instruction
        info_row = {'S_inst':'Refer Appendix E in 157897-NRD-REP-EDS-000003 and 000004, MML Braybrooke Assessment',
                    'SVC':'Step Voltage Change In Percentage',
                    'worst_case_d':'d = (step voltage change/nominal voltage)*(1+10%)',
                    'tn_step': 'tn = 18.4*(100*d*F)^3 with F=1',
                    't_memory': 't = rolling 10 min sum of tn_step'}
        d4_sum.loc[len(d4_sum)] = info_row

        # save information to spreadsheet
        d4_df.insert(d4_df.columns.get_loc('I_angle') + 1, 'New_C_1', np.nan)
        d4_sum.insert(d4_sum.columns.get_loc('I_angle') + 1, 'New_C_1', np.nan)

        d4_df.insert(d4_df.columns.get_loc('New_C_1') + 1, 'T_F_Plot', np.nan)
        d4_sum.insert(d4_sum.columns.get_loc('New_C_1') + 1, 'T_F_Plot', np.nan)

        d4_df.insert(d4_df.columns.get_loc('S_30min') + 1, 'New_C_2', np.nan)
        d4_sum.insert(d4_sum.columns.get_loc('S_30min') + 1, 'New_C_2', np.nan)

        d4_df.insert(d4_df.columns.get_loc('abs_SVC') + 1, 'New_C_3', np.nan)
        d4_sum.insert(d4_sum.columns.get_loc('abs_SVC') + 1, 'New_C_3', np.nan)

        d4_sum.to_excel(writer, sheet_name=feeder, index=False, startrow = 0)

        d4_df.to_excel(writer, sheet_name=feeder, index=False, startrow = d4_sum.shape[0]+2)

        # do the plot
        curve_plot(writer,feeder,result_df,plot_start,d4_df)

        print("Saving Excel File...")

    return

# new result page writer (format and writing in one go)
def setting_summary(writer: pd.ExcelWriter,start_page,start):
    print('Copy the Setting Information...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Setting")
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})
    comment_info_format = workbook.add_format({'align': 'left','valign': 'vcenter','border': 1})
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    grey_fill = workbook.add_format({"bg_color": "#888888"})
    highlight_fill = workbook.add_format({'align': 'center','valign': 'vcenter','bg_color': "#FFFF00",'border': 1})
    # copy header info
    #===================INFO TABLE==========================================
    irow = 1
    icol = 0
    for row, line in enumerate(start_page['InfoTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row, icol+col, data)
    
    #==================Main Setting=========================================
    irow = start+1
    icol = 0
    # header info
    header = ['Items','Description','Settings','Note']
    for col, col_name in enumerate(header):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # data
    for row, line in enumerate(start_page['SettingTable']):
        for col, data in enumerate(line):
            if col == 1:
                worksheet.write(irow+row,icol+col,data,comment_info_format)
            else:
                worksheet.write(irow+row,icol+col,data,table_format)

    #==================Additional Info=========================================
    irow = start+1
    icol = 6
    # header info
    header = ['Items','Criteria']
    for col, col_name in enumerate(header):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # addtional table
    for row, line in enumerate(start_page['AddiTable']):
        for col, data in enumerate(line):
            if col == 0:
                worksheet.write(irow+row, icol+col, data, comment_info_format)
            else:
                if hasattr(data, 'text'):  # detect ArrayFormula due to openpy reading
                    worksheet.write_formula(irow+row, icol+col, data.text, highlight_fill)
                else:
                    worksheet.write(irow+row, icol+col, data, highlight_fill)
    
    worksheet.autofit()
    
    return

def result_summary(writer: pd.ExcelWriter,simname,result_df,start_page,start):
    print('Preparing the Final Result...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Result")
    # define formatting
    # Header: bold, center, grey background, all borders
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1,'text_wrap': True})

    # Subheader: italic, size 10, grey background, all borders
    subheader_format = workbook.add_format({'italic': True,'font_size': 10,'align': 'center','valign': 'vcenter','bg_color': '#EDEDED','border': 1, 'text_wrap': True})

    # Setting info: center aligned
    setting_info_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1,'text_wrap': True})

    # Setting info: center aligned
    green_fill = workbook.add_format({'align': 'center','valign': 'vcenter','bg_color': '#00FF00','border': 1})

    # Setting info: center aligned
    red_fill = workbook.add_format({'align': 'center','valign': 'vcenter','bg_color': '#FF0000','border': 1})

    # comment info: left aligned
    comment_info_format = workbook.add_format({'align': 'left','valign': 'vcenter','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '00.00','border': 1})

    # Integer number format: 00
    integer_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0','border': 1})

    # Percentage format: 0.00%
    percentage_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00%','border': 1})

    # Write Basic Information
    project_name = start_page['InfoTable'][0][1]
    feeding_desp = start_page['InfoTable'][1][1]
    modeller = start_page['InfoTable'][2][1]
    date = start_page['InfoTable'][3][1]
    
    worksheet.write('B2', "Project Name:")
    worksheet.write('C2', project_name)
    worksheet.write('B3', "Simulation Name:")
    worksheet.write('C3', simname)
    worksheet.write('B4', "Feeding Arrangement:")
    worksheet.write('C4', feeding_desp)
    worksheet.write('B5', "Result Created by:")
    worksheet.write('C5', modeller)
    worksheet.write('B6', "Result Created at:")
    worksheet.write('C6', datetime.now().strftime("%d-%m-%Y %H:%M"))
    
    worksheet.write('H4', "Note:")
    worksheet.write('H5', "Detailed calculation principle --> Refer to Braybrooke Flicker & Reactive Power Assessment Report ")
    worksheet.write('H6', "Doc Ref: 157897-NRD-REP-EDS-000003 & 000004")

    # actual data writing started
    row1, cols1 = result_df.shape
    #==================== FIRST TABLE=============================================================
    irow = start
    icol = 1

    # getting the range
    r_range1 = xl_range(irow+2,icol+3,irow+2,icol+3)
    r_range2 = xl_range(irow+1,icol+3,irow+row1-1,icol+3)
    criteria1 = f"$D{irow+3}" # D13
    criteria2 = f"$D{irow+2}" # D12

    for c_idx, col_name in enumerate(result_df.columns):
        worksheet.write(irow, icol + c_idx, col_name, header_format)

    for r_idx, row in enumerate(result_df.values):
        for c_idx, value in enumerate(row):
            if c_idx == 0: # left aligned
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, comment_info_format)
            elif c_idx in [2,3] and r_idx in [0,1,2,3,4,5,6,7,16]: # number
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, number_format)
            elif c_idx == 2 and r_idx == 17: # text
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, setting_info_format)
            elif c_idx == 3 and r_idx == 17: # special case
                if result_df.iloc[16,3] < result_df.iloc[16,2] or result_df.iloc[15,3] < result_df.iloc[15,2]:
                    worksheet.write(irow + 1 + r_idx, icol + c_idx, "PASS", green_fill)
                else:
                    worksheet.write(irow + 1 + r_idx, icol + c_idx, "TO BE CONFIRMED", red_fill)
            elif c_idx in [2,3]: # percentage
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, percentage_format)
            else: # index = 1
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, setting_info_format)

    # conditional formatting
    red_bkg = workbook.add_format({"bg_color": "#FF0000"})
    yellow_bkg = workbook.add_format({"bg_color": "#FFFF00"})
    green_bkg = workbook.add_format({"bg_color": "#00FF00"})
    
    worksheet.conditional_format(r_range1,{'type': 'cell','criteria':'<=', 'value': f'={criteria1}','format': red_bkg})
    worksheet.conditional_format(r_range1,{'type': 'cell','criteria':'between', 'minimum': f'={criteria1}','maximum': f'={criteria1}*1.05','format': yellow_bkg})
    worksheet.conditional_format(r_range1,{'type': 'cell','criteria':'>', 'value': f'={criteria1}*1.05','format': green_bkg})

    worksheet.conditional_format(r_range2,{'type': 'cell','criteria':'>=', 'value': f'={criteria2}','format': red_bkg})
    worksheet.conditional_format(r_range2,{'type': 'cell','criteria':'between', 'minimum': f'={criteria2}*0.9','maximum': f'={criteria2}','format': yellow_bkg})
    worksheet.conditional_format(r_range2,{'type': 'cell','criteria':'<', 'value': f'={criteria2}*0.9','format': green_bkg})

    # set column width
    worksheet.set_column('B:E', 15) # default
    worksheet.set_column('B:B', 50) # assessment item
    
    return

# plot some essential graphs
def curve_plot(writer: pd.ExcelWriter,feeder,result_df,plot_start,d4_df):

    print("Plotting Graphs in Result... ")
    workbook = writer.book
    # Create time format
    time_format = workbook.add_format({'num_format': 'hh:mm:ss'})
    total = len(d4_df)
    #====================== Individual Feeder Time Column =============================#
    feeder_sheet = writer.sheets[feeder]
    row = plot_start    # data writting row 1-based index
    col_time_excel = 10  # column K 0-based index

    #index = plot_start
    for i in range(total):
            r = row + i
            formula = f'=TIME(LEFT(C{r},2),MID(C{r},4,2),RIGHT(C{r},2))'
            feeder_sheet.write_formula(r-1, col_time_excel, formula, time_format)

    time_start = d4_df.iloc[0,2]
    time_end = d4_df.iloc[-1,2]
    v_max = result_df.iloc[0,2]
    v_min = result_df.iloc[1,2]

    time = time_start
    time = time.split(":")
    ts = (float(time[0])+float(time[1])/60+float(time[1])/3600)/24

    time = time_end
    time = time.split(":")
    te = (float(time[0])+float(time[1])/60+float(time[1])/3600)/24

    xmin = 0
    xmax = 1
    
    # find nearest 10 min timeline.
    for i in range(0,144):
        if i*1/144 > ts:
            xmin = (i-1)*1/144
            for j in range(i,144):
                if j*1/144 >= te:
                    xmax = j*1/144
                    break
            break
    
    tspace = (xmax-xmin)/6

    #=========================Result Page Processing==================================
    # start plot
    worksheet = writer.sheets['Result']
    # start row for data (convert to zero-based index)
    start = plot_start - 1          # openpyxl is 1-based, xlsxwriter is 0-based
    index = 10                      # row 11 in Excel -> index 10 in xlsxwriter

    ##############################################################################
    # Plot 1 - Voltage
    ##############################################################################
    # Create a scatter chart with smooth lines and markers
    chart = workbook.add_chart({'type': 'scatter','subtype': 'smooth'})

    # Set chart title and axis labels
    chart.set_title({'name': 'Point of Common Coupling - Voltage Profile'})
    chart.set_y_axis({'name': 'Voltage (kV)','major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}})
    chart.set_size({'width': 15*64, 'height': 19*20})
    chart.set_legend({'position': 'top'})

    # Column indexes (convert from 1-based to 0-based)
    x_col = 10   # col K
    y_col = 22   # col W

    # Add series
    chart.add_series({
        'name':       'PCC Voltage',
        'categories': [feeder, start, x_col, start + total - 1, x_col],
        'values':     [feeder, start, y_col, start + total - 1, y_col],
    })

    chart.set_x_axis({
        'name': 'Time (hh:mm:ss)',
        'min': xmin,
        'max': xmax,
        'major_unit': tspace,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })

    # Insert chart into worksheet (adjust position as needed)
    worksheet.insert_chart(index, 7, chart)

    # to be discussed if plotting threshold is nneded in the future as it will make voltage profile very hard to see
    
    # rows = [['Time','Threshold'],[time_start, v_max],[time_end, v_max],[time_start, v_min],[time_end, v_min]]
    # for row_index, row_data in enumerate(rows, start=1):
    #     for col_index, value in enumerate(row_data, start=32):  # Column AF is the 32nd column
    #         wb[feeder].cell(row=row_index, column=col_index, value=value)
    
    # xvalues = Reference(wb[feeder], min_col=32, min_row=2, max_row=3)
    # yvalues = Reference(wb[feeder], min_col=33, min_row=2, max_row=3)
    # series = Series(yvalues,xvalues,title_from_data=False,title = 'Maximum Voltage')
    # chart.series.append(series)

    # xvalues = Reference(wb[feeder], min_col=32, min_row=4, max_row=5)
    # yvalues = Reference(wb[feeder], min_col=33, min_row=4, max_row=5)
    # series = Series(yvalues,xvalues,title_from_data=False,title = 'Minimum Voltage')
    # chart.series.append(series)
    index = index + 20

    ##############################################################################
    # Plot 2 - SVC
    ##############################################################################
    # Create a scatter chart with smooth lines and markers
    chart = workbook.add_chart({'type': 'scatter','subtype': 'smooth'})

    # Set chart title and axis labels
    chart.set_title({'name': 'Point of Common Coupling - Step Voltage Change in Percentage'})
    chart.set_y_axis({'name': 'Percentage %','major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}})
    chart.set_size({'width': 15*64, 'height': 19*20})
    chart.set_legend({'position': 'top'})

    # Column indexes (convert from 1-based to 0-based)
    x_col = 10   # col K
    y_col = 23   # col X

    # Add series
    chart.add_series({
        'name':       'SVC',
        'categories': [feeder, start, x_col, start + total - 1, x_col],
        'values':     [feeder, start, y_col, start + total - 1, y_col],
    })

    chart.set_x_axis({
        'name': 'Time (hh:mm:ss)',
        'min': xmin,
        'max': xmax,
        'major_unit': tspace,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })

    # Insert chart into worksheet (adjust position as needed)
    worksheet.insert_chart(index, 7, chart)
    index = index + 20

    ##############################################################################
    # Plot 3 - Memory Time
    ##############################################################################
    # Create a scatter chart with smooth lines and markers
    chart = workbook.add_chart({'type': 'scatter','subtype': 'smooth'})

    # Set chart title and axis labels
    chart.set_title({'name': 'Flicker Severity Stage 2 Assessment - Memory Time Technique'})
    chart.set_y_axis({'name': 'Second (s)','major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}})
    chart.set_size({'width': 15*64, 'height': 19*20})
    chart.set_legend({'position': 'top'})

    # Column indexes (convert from 1-based to 0-based)
    x_col = 10   # col K
    y_col = 27   
    chart.add_series({
        'name':       'tn: memory time for each step',
        'categories': [feeder, start, x_col, start + total - 1, x_col],
        'values':     [feeder, start, y_col, start + total - 1, y_col],
    })
    y_col = 28
    chart.add_series({
        'name':       't: memory time for 10 min sum',
        'categories': [feeder, start, x_col, start + total - 1, x_col],
        'values':     [feeder, start, y_col, start + total - 1, y_col],
    })

    chart.set_x_axis({
        'name': 'Time (hh:mm:ss)',
        'min': xmin,
        'max': xmax,
        'major_unit': tspace,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })

    # Insert chart into worksheet (adjust position as needed)
    worksheet.insert_chart(index, 7, chart)
    index = index + 20

    ##############################################################################
    # Plot 4 - 30 min
    ##############################################################################
    # Create a scatter chart with smooth lines and markers
    chart = workbook.add_chart({'type': 'scatter','subtype': 'smooth'})

    # Set chart title and axis labels
    chart.set_title({'name': '30 min Average Reactive Power'})
    chart.set_y_axis({'name': 'Reactive Power (MVAr)','major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}})
    chart.set_size({'width': 15*64, 'height': 19*20})
    chart.set_legend({'position': 'top'})

    # Column indexes (convert from 1-based to 0-based)
    x_col = 10   # col K
    y_col = 19   
    chart.add_series({
        'name':       '30-min Average Reactive Power',
        'categories': [feeder, start, x_col, start + total - 1, x_col],
        'values':     [feeder, start, y_col, start + total - 1, y_col],
    })
    chart.set_x_axis({
        'name': 'Time (hh:mm:ss)',
        'min': xmin,
        'max': xmax,
        'major_unit': tspace,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })

    # Insert chart into worksheet (adjust position as needed)
    worksheet.insert_chart(index, 7, chart)
    index = index + 20

    ##############################################################################
    # Plot 5 - 30 min
    ##############################################################################
    # Create a scatter chart with smooth lines and markers
    chart = workbook.add_chart({'type': 'scatter','subtype': 'smooth'})

    # Set chart title and axis labels
    chart.set_title({'name': '30 min Average Apparent Power'})
    chart.set_y_axis({'name': 'Power (MVA)','major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}})
    chart.set_size({'width': 15*64, 'height': 19*20})
    chart.set_legend({'position': 'top'})

    # Column indexes (convert from 1-based to 0-based)
    x_col = 10   # col K
    y_col = 20   
    chart.add_series({
        'name':       '30-min Average Power',
        'categories': [feeder, start, x_col, start + total - 1, x_col],
        'values':     [feeder, start, y_col, start + total - 1, y_col],
    })
    chart.set_x_axis({
        'name': 'Time (hh:mm:ss)',
        'min': xmin,
        'max': xmax,
        'major_unit': tspace,
        'major_gridlines': {'visible': True,'line': {'color': "#C3C3C3", 'dash_type': 'dash'}}
    })

    # Insert chart into worksheet (adjust position as needed)
    worksheet.insert_chart(index, 7, chart)
    index = index + 20

    return

# read the start tab and collect informaiton
def start_reading_process(simname, excel_file):
    
    # File check
    print("Check Excel and Deleting Existing Contents ...")

    try:
        wb = load_workbook(excel_file)

        if 'Start' not in wb.sheetnames:
            SharedMethods.print_message("ERROR: 'Start' sheet not found. Ensure the correct excel file selected.","31")
            return False
        
        result = start_page_processing(wb['Start'], simname)

        if result is False: return False
        start_page = result
        
        # Now remove other sheets
        for sheet_name in wb.sheetnames:
            if sheet_name != 'Start':
                wb.remove(wb[sheet_name])
        
        # Save changes
        wb.save(excel_file)

    except Exception as e:
        SharedMethods.print_message(f"ERROR: (Close the Excel file and Start Again) Error: {e}","31")
        return False

    print("Reading Setting Tables...")
    columns = ['Items','Description','Settings','Note']
    setting_df = pd.DataFrame(start_page['SettingTable'],columns=columns)
    
    return setting_df, start_page

# start page processing
def start_page_processing(sheet, simname):
    '''
    processing start page in three steps
    1. Blindly reading all tables from start page
    2. processing and validation
    3. return required data format for post processing
    
    :param sheet: Description
    '''
    #------ read header information table
    print("Reading Configuration Setting ...")

    if sheet.cell(row=11, column=1).value != 'Items':
        SharedMethods.print_message("ERROR: Wrong setting format. Please use the latest template.","31")
        return False


    info_start_row,info_start_col = excel_to_rowcol('A2')
    _,info_end_col = excel_to_rowcol('B2')
    setting_start_row,setting_start_col = excel_to_rowcol('A12')
    _,setting_end_col = excel_to_rowcol('D12')
    addi_start_row,addi_start_col = excel_to_rowcol('G12')
    _,addi_end_col = excel_to_rowcol('H12')

    info_table = excel_to_table_list(sheet,info_start_row,info_start_col,info_end_col,info_start_row,info_start_col,1)
    setting_table = excel_to_table_list(sheet,setting_start_row,setting_start_col,setting_end_col,setting_start_row,setting_start_col+1,2)
    addi_table = excel_to_table_list(sheet,addi_start_row,addi_start_col,addi_end_col,addi_start_row,addi_start_col,1)

    if setting_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at B12.","31")
        return False
    else:
        if setting_table[0][0] == '':
            SharedMethods.print_message("ERROR: Data Reading Failed. Check your settings in Excel.","31")
            return False

            
    start_page = {
        "InfoTable": info_table,
        "SettingTable": setting_table,
        "AddiTable": addi_table
    }

    return start_page

# create criteria table and ready for result
def criteria_calculate(pri_v,max_op_range,min_op_range,load_1_min,load_10_min,load_30_min,time_increment):
    # find the NPS value
    if pri_v < 150:
        a = 0.02 # 1 min NPS
        b = '-' # 10 min NPS
        c = 0.01 # 30 min NPS
    else:
        a = '-'
        b = 0.015
        c = 0.01

    columns = ['Assessment Item','Unit','Assessment Criteria','Simulation Result']

    # Example data to populate the DataFrame
    data = [
        ['PCC Maximum Voltage', 'kV', pri_v + pri_v*max_op_range, np.nan],
        ['PCC Minimum Voltage', 'kV', pri_v + pri_v*min_op_range, np.nan],
        ['PCC 1-min Maximum Apparent Load', 'MVA', np.nan, np.nan],
        ['PCC 10-min Maximum Apparent Load', 'MVA', np.nan, np.nan],
        ['PCC 30-min Maximum Apparent Load', 'MVA', np.nan, np.nan],
        ['PCC 1-min Maximum Reactive Load', 'MVAr', np.nan, np.nan],
        ['PCC 10-min Maximum Reactive Load', 'MVAr', np.nan, np.nan],
        ['PCC 30-min Maximum Reactive Load', 'MVAr', np.nan, np.nan],
        ['PCC 1-min Negative Phase Sequence (NPS)', '%', a, np.nan],
        ['PCC 10-min Negative Phase Sequence (NPS)', '%', b, np.nan],
        ['PCC 30-min Negative Phase Sequence (NPS)', '%', c, np.nan],
        ['PCC Step Voltage Change (SVC)', '%', 0.03, np.nan],
        ['PCC Rapid Voltage Change (RVC) - Frequent Event', '%', 0.06, np.nan],
        ['PCC Rapid Voltage Change (RVC) - Infrequent Event', '%', 0.1, np.nan],
        ['PCC Rapid Voltage Change (RVC) - Very Infrequent Event', '%', 0.12, np.nan],
        ['Flicker Severity - Short Term - RVC with Pst <= 0.5', '%', np.nan, np.nan],
        ['Flicker Severity - Short Term - Memory Time Technique', 's', 600, np.nan],
        ['Flicker Severity - Long Term - Plt', 'N/A', 'Pass if Stage 2 Pst pass', np.nan],
        # Add more rows as needed
    ]

    # Create the DataFrame from the data
    df = pd.DataFrame(data, columns=columns)

    # if load_1_min is a number than assign the value to 1min load 
    coff = 0.48/np.sqrt(1+0.48*0.48)
    if isinstance(load_1_min, (int, float)) and not np.isnan(load_1_min):
        df.at[2, 'Assessment Criteria'] = load_1_min
        df.at[5, 'Assessment Criteria'] = load_1_min*coff
    else:
        df.at[2, 'Assessment Criteria'] = '-'
        df.at[5, 'Assessment Criteria'] = '-'
        
    if isinstance(load_10_min, (int, float)) and not np.isnan(load_10_min):
        df.at[3, 'Assessment Criteria'] = load_10_min
        df.at[6, 'Assessment Criteria'] = load_10_min*coff
    else:
        df.at[3, 'Assessment Criteria'] = '-'
        df.at[6, 'Assessment Criteria'] = '-'
        
    if isinstance(load_30_min, (int, float)) and not np.isnan(load_30_min):
        df.at[4, 'Assessment Criteria'] = load_30_min
        df.at[7, 'Assessment Criteria'] = load_30_min*coff
    else:
        df.at[4, 'Assessment Criteria'] = '-'
        df.at[7, 'Assessment Criteria'] = '-'
        
    # assign the Flicker criteria stage 2
    # based on 1 ,2,3,4,5 sec
    criteria_values = [0.004, 0.0045, 0.005, 0.0055, 0.006]
    df.at[15, 'Assessment Criteria'] = criteria_values[time_increment - 1]
    
    return df

#create protection limit dataframe
def result_rvc_update(simname, result_df, pri_v, fault, event_f,event_if,event_vif):

    vo_impedance = 2* (pri_v*pri_v) / fault  #vision oslo equivalent source impedance
    nominal_v = 25  # inrush current at 25 kV (nominla voltage setting)

    temp = result_df.at[2, 'Simulation Result'] / fault # 1 min NPS = 1 min Power / falue
    result_df.at[8, 'Simulation Result'] = temp

    temp = result_df.at[3, 'Simulation Result'] / fault # 10 min NPS = 10 min Power / falue
    result_df.at[9, 'Simulation Result'] = temp

    temp = result_df.at[4, 'Simulation Result'] / fault # 30 min NPS = 30 min Power / falue
    result_df.at[10, 'Simulation Result'] = temp

    if isinstance(event_f, (int, float)) and not np.isnan(event_f):
        temp = (event_f * nominal_v / pri_v) * vo_impedance / pri_v /1000 # current at primary * impedance / primary nominal voltag
        result_df.at[12, 'Simulation Result'] = temp
    else:
        result_df.at[12, 'Simulation Result'] = '-'

    if isinstance(event_if, (int, float)) and not np.isnan(event_if):
        temp = (event_if * nominal_v / pri_v) * vo_impedance / pri_v /1000 # current at primary * impedance / primary nominal voltag
        result_df.at[13, 'Simulation Result'] = temp
    else:
        result_df.at[13, 'Simulation Result'] = '-'

    if isinstance(event_vif, (int, float)) and not np.isnan(event_vif):
        temp = (event_vif * nominal_v / pri_v) * vo_impedance / pri_v /1000 # current at primary * impedance / primary nominal voltag
        result_df.at[14, 'Simulation Result'] = temp
    else:
        result_df.at[14, 'Simulation Result'] = '-'

    return result_df

# read individual d4 file
def feeder_reading_process(simname,feeder_list,pri_v,ratio,time_increment,result_df):

    # create dataframe
    d4dataframe = []
    #sumdataframe = []

    for index, feeder in enumerate(feeder_list):
        print(f"Processing {feeder} ...")
        filename = simname + "_" + feeder +".osop.d4"
        delimiter = '\\s+'
        columns = ["FeederID","Type","Time","P_inst","Q_inst","Voltage","V_angle","Current","I_angle"]
        dtype_mapping = {"Time": str,}
        df = pd.read_csv(filename, delimiter=delimiter, names = columns, skiprows = 11,dtype = dtype_mapping) 
        # Extracting parts from the string and formatting the 'Time' column
        df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")
        # data frame process
        df = d4_file_sp_process(df,pri_v, ratio,time_increment)
        # calculate sum value
        df_sum = d4_find_max(df)
        #update summary result
        result_df = result_update(result_df, df_sum)

    return df, df_sum, result_df

# doing invididual d4 file process and calculatoin for supply points
def d4_file_sp_process(df, pri_v, ratio, time_increment):

    # calculate Power 
    df['S_inst'] = np.sqrt(df['P_inst']**2 + df['Q_inst']**2)

    window_sizes = {'1min': 60, '10min': 600, '30min': 1800}

    for time_interval, window_size in window_sizes.items():
        df[f'P_{time_interval}'] = df['P_inst'].rolling(window=int(window_size / time_increment)).mean()
        df[f'Q_{time_interval}'] = df['Q_inst'].rolling(window=int(window_size / time_increment)).mean()
        df[f'S_{time_interval}'] = np.sqrt(df[f'P_{time_interval}']**2 + df[f'Q_{time_interval}']**2)

    df['SP_Voltage'] = df['Voltage']*ratio  # actually supply point voltage
    df['SVC'] = df['SP_Voltage'].pct_change()  # default method to calculate percentage difference
    #df['SVC'] = df['SVC'].map('{:.2f}%'.format) # change the data shown in percentage format note this will hcange the data type to str

    df['abs_SVC'] = np.abs(df['SVC']) # calculate the absolute value of SVC
    #df['abs_SVC'] = df['abs_SVC'].map('{:.2f}%'.format) # change the data shown in percentage format

    df['worst_case_d'] = np.abs(df['SP_Voltage'].diff())/pri_v*1.1  # calcuate the worst case d for memory time relative votlage change
    df['tn_step'] = (df['worst_case_d']*100)**3 * 18.4  # calculate tn = 18.4 * (100*d*F)^3, with F=1 for step voltage change.
    
    df['t_memory'] = df['tn_step'].rolling(window=int(600 / time_increment)).sum() # rolling 10 min sum as required

    return df

# find maximum value and time of each d4 file
def d4_find_max(df):
    # # Insert two empty rows above the first row
    # df = pd.concat([pd.DataFrame(index=range(2)), df], ignore_index=True)
    sum_df = pd.DataFrame(columns=df.columns,index=range(4))
    sum_df.iloc[0, 0] = "Maximum Value"
    sum_df.iloc[1, 0] = "Maximum Value at Time"
    sum_df.iloc[2, 0] = "Minimum Value"
    sum_df.iloc[3, 0] = "Minimum Value at Time"

    start = 9

    if df.empty:
        sum_df.iloc[0, 1] = "DATA FOR THIS FEEDER IS NOT AVAILABLE"

    else:
        for column in df.columns[start:]:
            if df[column].dtype in [int, float]:
                max_value = df[column].max()
                time_of_max = df.loc[df[column].idxmax(), 'Time']
                sum_df.at[0, column] = max_value
                sum_df.at[1, column] = time_of_max
                min_value = df[column].min()
                time_of_min = df.loc[df[column].idxmin(), 'Time']
                sum_df.at[2, column] = min_value
                sum_df.at[3, column] = time_of_min

    return sum_df

# update result table based on output of d4 process
def result_update(target,df_sum):

#     Assessment Item  Unit       Assessment Criteria  Simulation Result
# 0                                 PCC Maximum Voltage    kV                     420.0                NaN
# 1                                 PCC Minimum Voltage    kV                     360.0                NaN
# 2                     PCC 1-min Maximum Apparent Load   MVA                       100                NaN
# 3                    PCC 10-min Maximum Apparent Load   MVA                         -                NaN
# 4                    PCC 30-min Maximum Apparent Load   MVA                        40                NaN
# 5                     PCC 1-min Maximum Reactive Load  MVAr                 43.273107                NaN
# 6                    PCC 10-min Maximum Reactive Load  MVAr                         -                NaN
# 7                    PCC 30-min Maximum Reactive Load  MVAr                 17.309243                NaN

# 8                     PCC 1-min NPS                       %                 43.273107                NaN
# 9                    PCC 10-min NPS                       %                         -                NaN
# 10                   PCC 30-min NPS                       %                 17.309243                NaN

# 11                      PCC Step Voltage Change (SVC)     %                      0.03                NaN
# 12    PCC Rapid Voltage Change (RVC) - Frequent Event     %                      0.06                NaN
# 13  PCC Rapid Voltage Change (RVC) - Infrequent Event     %                       0.1                NaN
# 14  PCC Rapid Voltage Change (RVC) - Very Infreque...     %                      0.12                NaN
# 15  Flicker Severity - Short Term - RVC with Pst <...     %                     0.006                NaN
# 16  Flicker Severity - Short Term - Memory Time Te...     s                       600                NaN
# 17                 Flicker Severity - Long Term - Plt   N/A  Pass if Stage 2 Pst pass                NaN
    
    target.loc[0,'Simulation Result'] = df_sum.at[0,'SP_Voltage']
    target.loc[1,'Simulation Result'] = df_sum.at[2,'SP_Voltage']

    target.loc[2,'Simulation Result'] = df_sum.at[0,'S_1min']
    target.loc[3,'Simulation Result'] = df_sum.at[0,'S_10min']
    target.loc[4,'Simulation Result'] = df_sum.at[0,'S_30min']
    target.loc[5,'Simulation Result'] = df_sum.at[0,'Q_1min']
    target.loc[6,'Simulation Result'] = df_sum.at[0,'Q_10min']
    target.loc[7,'Simulation Result'] = df_sum.at[0,'Q_30min']

    target.loc[11,'Simulation Result'] = df_sum.at[0,'abs_SVC'] # SVC
    target.loc[15,'Simulation Result'] = df_sum.at[0,'abs_SVC'] # Flicker Short Term stage 2
    target.loc[16,'Simulation Result'] = df_sum.at[0,'t_memory'] # Flicker memory time
    
    return target

# check input information:
def check_input_info(sec_v,time_increment,feeder,pri_v,max_op_range,min_op_range,fault):

    # check if time increament is sensible or not
    if 0 <= time_increment <= 5:
        print(f"Simulation Time Increment was Set to {time_increment} second.")
    else:
        SharedMethods.print_message("ERROR: Please set simulation time increment between 1-5 and restart the process....","31")
        return False
    
    if isinstance(sec_v, str) or np.isnan(sec_v):
        SharedMethods.print_message("ERROR: Please check input in Modelled Supply Voltage. Value Required...","31")
        return False
    else:
        if sec_v < 10 or sec_v > 450:
            SharedMethods.print_message("WARNING: Norminal Voltage in kV. Abnormal norminal votage detected.","33")
    
    if isinstance(pri_v, str) or np.isnan(pri_v):
        SharedMethods.print_message("ERROR: Please check input in Nominal Supply Voltage. Value Required...","31")
        return False
    else:
        if pri_v < 10 or pri_v > 450:
            SharedMethods.print_message("WARNING: Norminal Voltage in kV. Abnormal norminal votage detected.","33")
    
    if isinstance(max_op_range, str) or np.isnan(max_op_range):
        SharedMethods.print_message("ERROR: Check Maximum Operating Range. Value Required...","31")
        return False
    
    if isinstance(min_op_range, str) or np.isnan(min_op_range):
        SharedMethods.print_message("ERROR: Check Minimum Operating Range. Value Required...","31")
        return False
    
    if isinstance(fault, str) or np.isnan(fault) or fault == 0:
        SharedMethods.print_message("ERROR: Please check input in Fault Level. Value Required...","31")
        return False
    
    if len(feeder) > 4:
        SharedMethods.print_message("ERROR: Feeder ID larger than 4 digit. Extraction is not possible...","31")
        return False

    return True

if __name__ == "__main__":
    # Add your debugging code here
    simname = "test_model_1"  # Provide a simulation name or adjust as needed
    main_option = "1"  # Adjust as needed
    time_start = "0070000"  # Adjust as needed
    time_end = "0080000"  # Adjust as needed
    option_select = "2"  # Adjust as needed
    text_input = "AC_05_Grid"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = "1"  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)

