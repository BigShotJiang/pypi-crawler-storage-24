#=================================================================
# Created by: Jieming Ye
# Created on: Feb 2026
# Last Modified: Feb 2026
#=================================================================
# Copyright (c) 2026 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Commonly used excel function helper

"""
#=================================================================
# VERSION CONTROL
# V1.0 (Jieming Ye) - Initial Version
#=================================================================
# Set Information Variable
# N/A
#=================================================================

# from openpyxl import Workbook
# from copy import copy
# import xlsxwriter
from openpyxl.worksheet.worksheet import Worksheet
import re
import pandas as pd
import math

# def export_excel_sheet_from_wb(wb: Workbook, sheet_name: str, output_file: str):
#     '''
#     Docstring for export_excel_sheet_from_wb

#     :param wb: The source workbook object
#     :param sheet_name: The name of the sheet to export
#     :param output_file: The path to save the exported file
#     '''
#     src_ws = wb[sheet_name]

#     dst_wb = Workbook()
#     dst_ws = dst_wb.active
#     dst_ws.title = sheet_name

#     # Copy cells + styles
#     for row in src_ws.iter_rows():
#         for cell in row:
#             new_cell = dst_ws[cell.coordinate]
#             new_cell.value = cell.value

#             if cell.has_style:
#                 new_cell.font = copy(cell.font)
#                 new_cell.border = copy(cell.border)
#                 new_cell.fill = copy(cell.fill)
#                 new_cell.number_format = cell.number_format
#                 new_cell.protection = copy(cell.protection)
#                 new_cell.alignment = copy(cell.alignment)

#     # Column widths
#     for col, dim in src_ws.column_dimensions.items():
#         dst_ws.column_dimensions[col].width = dim.width

#     # Row heights
#     for row, dim in src_ws.row_dimensions.items():
#         dst_ws.row_dimensions[row].height = dim.height

#     # Merged cells
#     for merged in src_ws.merged_cells.ranges:
#         dst_ws.merge_cells(str(merged))

#     # Freeze panes
#     dst_ws.freeze_panes = src_ws.freeze_panes

#     # Tables
#     for table in src_ws.tables.values():
#         dst_ws.add_table(copy(table))

#     # Conditional formatting
#     dst_ws.conditional_formatting = src_ws.conditional_formatting

#     dst_wb.save(output_file)

#     return

def excel_to_rowcol(cell_ref: str):
    """
    Convert Excel cell reference (e.g., 'A1', 'BC23') 
    to (row, column) tuple as used in openpyxl (1-based indexing).
    VALID TO OPENPYXL ONLY!!!
    """
    match = re.fullmatch(r"([A-Za-z]+)(\d+)", cell_ref.strip())
    if not match:
        raise ValueError(f"Invalid Excel cell reference: {cell_ref}")

    col_letters, row_str = match.groups()
    row = int(row_str)

    # Convert column letters to number
    col = 0
    for char in col_letters.upper():
        col = col * 26 + (ord(char) - ord('A') + 1)

    return row, col

def excel_to_table_list(ws: Worksheet,row_start:int=0,col_start:int=0,col_end:int=0,row_search:int=0,col_search:int=0,row_gap:int=0):
    """
    Read data from an Excel sheet using openpyxl and return it as a nested list.

    The function determines the table boundaries starting from a given cell:

    - Top boundary: row_start
    - Left boundary: col_start
    - Bottom boundary: Starting from row_search_cell, moves downward until
      consecutive empty rows exceed row_gap
    - Right boundary: Starting from col_search, moves right until
      consecutive empty columns exceed col_gap

    Blank rows/columns inside the allowed gap are preserved as None.
    """
    table_list = []
    row_end = 0
    # -------------------------
    # Find bottom boundary
    # -------------------------
    if ws.cell(row=row_search, column=col_search).value is not None:
        index = row_search
        while True:
            index += 1
            stop = True
            for i in range(0,row_gap):
                if ws.cell(row=index+i, column=col_search).value is not None:
                    stop = False
            if stop:
                row_end = index-1
                break
    # -------------------------
    # Extract table data
    # -------------------------
    for r in range(row_start, row_end + 1):
        row_data = [
            ws.cell(row=r, column=c).value
            for c in range(col_start, col_end + 1)
        ]
        table_list.append(row_data)

    return table_list

def excel_to_table_list_col(ws: Worksheet,col_start:int=0,row_start:int=0,row_end:int=0,row_search:int=0,col_search:int=0,row_gap:int=0):
    """
    Read data from an Excel sheet using openpyxl and return it as a nested list.
    See logic in excel_to_table_list_row

    This function search to right instead of search to bottom

    Blank rows/columns inside the allowed gap are preserved as None.
    """
    table_list = []
    col_end = 0
    # -------------------------
    # Find right boundary
    # -------------------------
    if ws.cell(row=row_search, column=col_search).value is not None:
        index = col_search
        while True:
            index += 1
            stop = True
            for i in range(0,row_gap):
                if ws.cell(row=row_search, column=index+i).value is not None:
                    stop = False
            if stop:
                col_end = index-1
                break
    # -------------------------
    # Extract table data
    # -------------------------
    for r in range(row_start, row_end + 1):
        row_data = [
            ws.cell(row=r, column=c).value
            for c in range(col_start, col_end + 1)
        ]
        table_list.append(row_data)

    return table_list

def pddataframe_to_excel_with_format(worksheet, start_row:int,start_column:int,dataframe: pd.DataFrame,header_format,data_format):
    '''
    THIS IS VALID FOR XLSXWRITER ONLY
    
    :param worksheet: Description
    :param start_row: Description
    :type start_row: int
    :param start_column: Description
    :type start_column: int
    :param dataframe: Description
    :type dataframe: pd.DataFrame
    '''
    for c_idx, col_name in enumerate(dataframe.columns):
        worksheet.write(start_row, start_column + c_idx, col_name, header_format)
    for r_idx, row in enumerate(dataframe.values):
        for c_idx, value in enumerate(row):
            if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                worksheet.write(start_row + 1 + r_idx, start_column + c_idx, None, data_format)
            else:
                worksheet.write(start_row + 1 + r_idx, start_column + c_idx, value, data_format)
    
    return
