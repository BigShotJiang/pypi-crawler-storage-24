#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jieming Ye
# Created on: Feb 2024
# Last Modified: Feb 2024
#=================================================================
# Copyright (c) 2024 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Pre-requisite: 
SimulationName.oof: default oslo output file after successfully run a simulation.
xxxxx.xlsx: excel spreadsheet with proper user settings.
Used Input:
simname: to locate the result file or file rename
time_start: to define the analysis start time
time_end: to define the analysis end time
option_select: to define the option selected in subfunction
text_input: to locate the excel file name
other input for oslo_extraction.py only.
Expected Output:
Updated excel spreadsheet with analysis result.
Description:
This script defines the process of doing OLE rating assessment.
First, it reads the excel file and save the user input in a data frame called start_df. Then it calculated the rating_df as a comparison data frame. Then it processing related  .d4 files and read information one by one and saved in a data frame list called d4dataframe. The calculation result is saved in a similar format data frame list called sumdataframe. It then doing some analysis and save the final result in an updated data frame. Final step is to save all information in the excel in a proper format. The whole process is easy to follow via reading the code.
If additional time window to be assessed in the future, several places needs to updated, specially column definition in each sub functions.
The key manual updating part is get_result_range() function which depends on the desired output format in excel, followed by table_formatting() function where some reading needs manual input. The other process should be auto adjustable as long as the excel input format is followed.

"""
#=================================================================
# VERSION CONTROL
# V1.0 (Jieming Ye) - Initial Version
# V1.1 (Jieming Ye) - Including pre-checking of OLE type
# V2.0 (Jieming Ye) - Use xlsxwriter as main output
#=================================================================
# Set Information Variable
# N/A
#=================================================================
# vision_oslo_extension/excel_processing.py
import pandas as pd
import numpy as np
from xlsxwriter.utility import xl_range
from datetime import datetime
from openpyxl import load_workbook

# import vision_oslo
from vision_oslo_extension import oslo_extraction
from vision_oslo_extension.shared_contents import SharedMethods
from vision_oslo_extension.shared_excel_helper import excel_to_rowcol,excel_to_table_list,pddataframe_to_excel_with_format


def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):

    print("")
    print("OLE Thermal Rating Assessment ----->")
    print("")
    
    simname = simname
    # Specify Excel file name
    excel_file = text_input + ".xlsx"
    excel_result = f"{excel_file.rsplit('.', 1)[0]}_result.xlsx"

    if not SharedMethods.check_existing_file(excel_file):
        return False
    
    #option = "1" # Fully Restart, require oof,
    #option = "2" # Process only

    option = option_select # 1:Fully Restart, require oof, and list

    start = 10 # result start from row 10
    space = 5
    time_increment = 5

    if option not in ["0","1","2"]:
        SharedMethods.print_message("ERROR: Error in ole_processing.py. Please contact Support...","31")
        return False
    
    if option == "0":
        SharedMethods.print_message("ERROR: Please select an option to proceed.","31")
        return False

    if not SharedMethods.can_write_file(excel_result):
        SharedMethods.print_message(f"ERROR: Result file {excel_result} is currently in use. Please close or delete it before running the process.","31")
        return False
    
    # read data from start tab
    result = start_reading_process(simname,excel_file)
    if result == False:
        return False
    else:
        start_df,rating_df,ole_list,start_page = result

    # get essential info
    branch_list = start_df['OSLO ID'].tolist()
    
    # check duplication in OSLO id
    if not SharedMethods.find_duplicates(branch_list): return False

    type_list = start_df['OLE Type'].tolist()
    # check branch_list
    branch_list_new = check_branch_list(branch_list)
    if branch_list_new == False:
        return False        
    # branch_list: branch format in XXXX/X format
    # branch_list_new: branch format in XXXX-X format this is because many application does not allow / charaters in naming

    # check type information
    ole_flag = False
    for index, ole in enumerate(type_list):
        if ole not in ole_list:
            SharedMethods.print_message(f"ERROR: OLE {start_df.loc[index,'OSLO ID']} Type '{ole}' not defined in the list. Check Input Data.","31")
            ole_flag = True
    if ole_flag: return False        

    # check if want to go throught the feeder check process
    if option == "1":
        if not SharedMethods.check_oofresult_file(simname):
            return False
        # extract the feeder
        for branch_id in branch_list:
            if not oslo_extraction.branch_step(simname, time_start, time_end, "1", branch_id):
                return False
        
    if option == "2":
        print("Checking essential d4 files...")
        for branch in branch_list_new:
            filename = simname + "_" + branch + ".osop.d4"
            if not SharedMethods.check_existing_file(filename):
                SharedMethods.print_message(f"ERROR: d4 file {branch} do not exist. Select option 1 or check OSLO ID to proceed.","31")
                return False
    try:
        # process d4 file
        d4dataframe, sumdataframe, result_df = branch_reading_process(simname,branch_list_new,time_increment)

        # Update the result table for Rating
        result_df = result_rating_update(simname,result_df,start_df,rating_df)

        # save the data
        data_write_save(simname,excel_result,start,space,d4dataframe,sumdataframe,start_df,result_df,branch_list_new,start_page)
    
    except KeyError as e:
        SharedMethods.print_message(f"ERROR: Unexpected error occured: {e}. Possibly due to incompleted data.","31")
        return False
    
    except Exception as e:
        SharedMethods.print_message(f"ERROR: Unexpected error occured: {e}","31")
        return False

    return True


# write data to excel
def data_write_save(simname,excel_result:str,start,space,d4dataframe,sumdataframe,start_df,result_df,branch_list_new,start_page):

    # write data to excel
    for i in range(1,51):
        excel_dashboard = f"0_{simname}_result_OLE_loading_{i}.xlsx"
        # if file does not exist
        if not SharedMethods.check_existing_file(excel_dashboard,printing = False):
            break
    else:
        SharedMethods.print_message("WARNING: Dashboard exporting fail. More than 50 dashboard exists already.","33")

    with pd.ExcelWriter(excel_dashboard, engine='xlsxwriter') as writer:
        print(f"Generating result dashboard {excel_dashboard}...")
        result_summary(writer,simname,start_df,result_df,start_page,start,space)
    
    with pd.ExcelWriter(excel_result, engine='xlsxwriter') as writer:
        # get currrent workbook to do process
        workbook = writer.book
        print("Generate Setting Page...")
        setting_summary(writer,start_df,start_page,start)
        print("Generate Result Page...")
        result_summary(writer,simname,start_df,result_df,start_page,start,space)
        # saving individual feeder
        for index, dflist in enumerate(d4dataframe):

            print(f"Saving {branch_list_new[index]}...")
            # emty columns
            dflist.insert(dflist.columns.get_loc('I_angle')+1,'New_C_1', np.nan)

            sumdataframe[index].insert(sumdataframe[index].columns.get_loc('I_angle')+1,'New_C_1', np.nan)

            sumdataframe[index].to_excel(writer, sheet_name=branch_list_new[index], index=False, startrow = 0)

            dflist.to_excel(writer, sheet_name=branch_list_new[index], index=False, startrow = sumdataframe[index].shape[0]+2)
        
        print("Saving Excel File...")

    return

# new result page writer (format and writing in one go)
def setting_summary(writer: pd.ExcelWriter,start_df,start_page,start):
    print('Copy the Setting Information...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Setting")
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    grey_fill = workbook.add_format({"bg_color": "#888888"})
    highlight_fill = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1,"bg_color": "#FFFF00"})
    # copy header info
    #===================INFO TABLE==========================================
    irow = 1
    icol = 0
    for row, line in enumerate(start_page['InfoTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data)
    
    #==================Main Setting=========================================
    irow = start+1
    icol = 0
    # header info
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # data
    for row, line in enumerate(start_page['SettingTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)

    #==================Additional TABLE=========================================
    irow = start+1
    icol = 6
    # header info
    header = ['OLE Type','Cont.Rating (A)','20min (A)','10min (A)','5min (A)','Note','Enviroment','Source']
    for col, col_name in enumerate(header):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # data
    for row, line in enumerate(start_page['AddiTable']):
        for col, data in enumerate(line):
            if col in [1,2,3,4]:
                worksheet.write(irow+row,icol+col,data,highlight_fill)
            else:
                worksheet.write(irow+row,icol+col,data,table_format)
                
    worksheet.autofit()
    
    return

# new result page writer (format and writing in one go)
def result_summary(writer: pd.ExcelWriter,simname,start_df,result_df,start_page,start,space):
    print('Preparing the Final Result...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Result")
    # define formatting
    # Header: bold, center, grey background, all borders
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})

    # Subheader: italic, size 10, grey background, all borders
    subheader_format = workbook.add_format({'italic': True,'font_size': 10,'align': 'center','valign': 'vcenter','bg_color': '#EDEDED','border': 1, 'text_wrap': True})

    # Setting info: center aligned
    setting_info_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '00.00','border': 1})

    # Percentage format: 0.00%
    percentage_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00%','border': 1})

    # Time format: 00:00:00
    time_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': 'hh:mm:ss','border': 1})

    # Write Basic Information
    project_name = start_page['InfoTable'][0][1]
    feeding_desp = start_page['InfoTable'][1][1]
    modeller = start_page['InfoTable'][2][1]
    date = start_page['InfoTable'][3][1]
    
    worksheet.write('B2', "Project Name:")
    worksheet.write('C2', project_name)
    worksheet.write('B3', "Simulation Name:")
    worksheet.write('C3', simname)
    worksheet.write('B4', "Feeding Arrangement:")
    worksheet.write('C4', feeding_desp)
    worksheet.write('B5', "Result Created by:")
    worksheet.write('C5', modeller)
    worksheet.write('B6', "Result Created at:")
    worksheet.write('C6', datetime.now().strftime("%d-%m-%Y %H:%M"))

    # actual data writing started
    row1, cols1 = start_df.shape
    row2, cols2 = result_df.shape

    #==================== FIRST TABLE=============================================================
    irow = start
    icol = 1
    # write first table
    worksheet.merge_range(irow-1,icol,irow-1,icol+cols1-1,"Contact System Information",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,start_df,subheader_format,setting_info_format)
    # write 2nd table
    icol = icol + cols1
    h1_range = xl_range(irow-1,icol,irow-1,icol+3)
    h2_range = xl_range(irow-1,icol+4,irow-1,icol+11)

    critera1 = f"$F{irow+2}"
    critera2 = f"$G{irow+2}"
    critera3 = f"$H{irow+2}"
    critera4 = f"$I{irow+2}"

    i_range1 = xl_range(irow+1,icol+4,irow+row1,icol+4)
    i_range2 = xl_range(irow+1,icol+6,irow+row1,icol+6)
    i_range3 = xl_range(irow+1,icol+8,irow+row1,icol+8)
    i_range4 = xl_range(irow+1,icol+10,irow+row1,icol+10)

    worksheet.merge_range(h1_range,"Equipment Rating (A)",header_format)
    worksheet.merge_range(h2_range,"Simulation Result: Maximum RMS Current (A)",header_format)

    subheader = ['Cont.','20min','10min','5min','30min','Time at','20min','Time at','10min','Time at','5min','Time at']
    for c_idx, col_name in enumerate(subheader):
        worksheet.write(irow, icol + c_idx, col_name, subheader_format)
    for r_idx, row in enumerate(result_df.values):
        for c_idx, value in enumerate(row):
            if c_idx in [5,7,9,11]: # time info
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, time_format)
            else:
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, number_format)
    

    # conditional formatting
    red_bkg = workbook.add_format({"bg_color": "#FF0000"})
    yellow_bkg = workbook.add_format({"bg_color": "#FFFF00"})
    green_bkg = workbook.add_format({"bg_color": "#00FF00"})
    
    worksheet.conditional_format(i_range1,{'type': 'cell','criteria':'<', 'value': f'={critera1}*0.9','format': green_bkg}) 
    worksheet.conditional_format(i_range1,{'type': 'cell','criteria':'>=', 'value': f'={critera1}','format': red_bkg})
    worksheet.conditional_format(i_range1,{'type': 'cell','criteria':'between', 'minimum': f'={critera1}*0.9','maximum': f'={critera1}','format': yellow_bkg})

    worksheet.conditional_format(i_range2,{'type': 'cell','criteria':'<', 'value': f'={critera2}*0.9','format': green_bkg}) 
    worksheet.conditional_format(i_range2,{'type': 'cell','criteria':'>=', 'value': f'={critera2}','format': red_bkg})
    worksheet.conditional_format(i_range2,{'type': 'cell','criteria':'between', 'minimum': f'={critera2}*0.9','maximum': f'={critera2}','format': yellow_bkg})

    worksheet.conditional_format(i_range3,{'type': 'cell','criteria':'<', 'value': f'={critera3}*0.9','format': green_bkg}) 
    worksheet.conditional_format(i_range3,{'type': 'cell','criteria':'>=', 'value': f'={critera3}','format': red_bkg})
    worksheet.conditional_format(i_range3,{'type': 'cell','criteria':'between', 'minimum': f'={critera3}*0.9','maximum': f'={critera3}','format': yellow_bkg})

    worksheet.conditional_format(i_range4,{'type': 'cell','criteria':'<', 'value': f'={critera4}*0.9','format': green_bkg}) 
    worksheet.conditional_format(i_range4,{'type': 'cell','criteria':'>=', 'value': f'={critera4}','format': red_bkg})
    worksheet.conditional_format(i_range4,{'type': 'cell','criteria':'between', 'minimum': f'={critera4}*0.9','maximum': f'={critera4}','format': yellow_bkg})

    # set column width
    worksheet.set_column('B:Q', 10) # default
    worksheet.set_column('B:B', 25) # Location
    worksheet.set_column('C:C', 45) # OLE Section
    worksheet.set_column('E:E', 15) # OLE Section
    
    return

# check branch list
def check_branch_list(branch_list):
    newlst = []
    for branch_id in branch_list:
            if len(branch_id) <= 6:
                if branch_id[-2:-1] =="/":
                    branch = branch_id[:len(branch_id)-2].ljust(4)+branch_id[-2:]
                    branch = branch[:4]+"-"+ branch[-1:]
                    newlst.append(branch)
                else:
                    SharedMethods.print_message(f"ERROR: Branch OSLO ID {branch_id} does not contains proper symbol. Check Input","31")
                    return False
            else:
                SharedMethods.print_message(f"ERROR: Branch OSLO ID {branch_id} is NOT in correct format. Check Input'.format(branch_id)","31")       
                return False

    return newlst

# read the start tab and collect informaiton
def start_reading_process(simname, excel_file):
    
    # File check
    print("Check Excel and Deleting Existing Contents ...")

    try:
        wb = load_workbook(excel_file)

        if 'Start' not in wb.sheetnames:
            SharedMethods.print_message("ERROR: 'Start' sheet not found. Ensure the correct excel file selected.","31")
            return False

        # Process Start sheet first
        result = start_page_processing(wb['Start'], simname)

        if result is False: return False

        setting_table,ole_list,rating_data,start_page = result

        # Now remove other sheets
        for sheet_name in wb.sheetnames:
            if sheet_name != 'Start':
                wb.remove(wb[sheet_name])

        # Save changes
        wb.save(excel_file)

    except Exception as e:
        SharedMethods.print_message(f"ERROR: (Close the Excel file and Start Again) Error: {e}","31")
        return False

    # creat dataframe
    columns = ['Location','OLE Section','OSLO ID','OLE Type']
    start_df = pd.DataFrame(start_page['SettingTable'],columns=columns)
    rating_df = pd.DataFrame(rating_data, index = ole_list)
    
    return start_df,rating_df,ole_list,start_page

# start page processing
def start_page_processing(sheet, simname):
    '''
    processing start page in three steps
    1. Blindly reading all tables from start page
    2. processing and validation
    3. return required data format for post processing
    
    :param sheet: Description
    '''
    #------ read header information table
    print("Reading Configuration Setting ...")
    info_start_row,info_start_col = excel_to_rowcol('A2')
    _,info_end_col = excel_to_rowcol('B2')
    setting_start_row,setting_start_col = excel_to_rowcol('A12')
    _,setting_end_col = excel_to_rowcol('D12')
    addi_start_row,addi_start_col = excel_to_rowcol('G12')
    _,addi_end_col = excel_to_rowcol('N12')

    info_table = excel_to_table_list(sheet,info_start_row,info_start_col,info_end_col,info_start_row,info_start_col,1)
    setting_table = excel_to_table_list(sheet,setting_start_row,setting_start_col,setting_end_col,setting_start_row,setting_start_col+2,1)
    addi_table = excel_to_table_list(sheet,addi_start_row,addi_start_col,addi_end_col,addi_start_row,addi_start_col,1)

    if setting_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at C12.","31")
        return False
    if addi_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at G12","31")
        return False
    
    ole_list,rating_data = check_rating_list(addi_table)
            
    start_page = {
        "InfoTable": info_table,
        "SettingTable": setting_table,
        "AddiTable": addi_table
    }

    return setting_table,ole_list,rating_data,start_page

# check rating data
def check_rating_list(rating_table):
    print("Analysising Ratings Info ...")
    # create ole list and rating data
    ole_list = []
    cont_list = []
    r_20min = []
    r_10min = []
    r_5min = []

    for row in rating_table:
        ole_list.append(row[0])

        data = row[1]
        if isinstance(data,(int,float)):
            cont_list.append(data)
        else:
            cont_list.append('-')
        
        data = row[2]
        if isinstance(data,(int,float)):
            r_20min.append(data)
        else:
            r_20min.append('-')

        data = row[3]
        if isinstance(data,(int,float)):
            r_10min.append(data)
        else:
            r_10min.append('-')
        
        data = row[4]
        if isinstance(data,(int,float)):
            r_5min.append(data)
        else:
            r_5min.append('-')

    rating_data = {'Cont.':cont_list,'20min': r_20min,'10min': r_10min,'5min': r_5min}

    return ole_list,rating_data

#update the result with rating information
def result_rating_update(simname,result_df,start_df,rating_df):

    type_list = start_df['OLE Type'].tolist()

    for index, ole_type in enumerate(type_list):
        result_df.loc[index,'Cont.'] = rating_df.loc[ole_type,'Cont.']
        result_df.loc[index,'20min'] = rating_df.loc[ole_type,'20min']
        result_df.loc[index,'10min'] = rating_df.loc[ole_type,'10min']
        result_df.loc[index,'5min'] = rating_df.loc[ole_type,'5min']

    return result_df

# read individual d4 file
def branch_reading_process(simname,branch_list,time_increment):

    total = len(branch_list)

    # create dataframe
    d4dataframe = []
    sumdataframe = []

    # creat result dataframe
    columns = ['Cont.','20min','10min','5min','r_30min','r_max_t1','r_20min','r_max_t2','r_10min','r_max_t3','r_5min','r_max_t4']
    result_df = pd.DataFrame(columns = columns, index=range(total))

    for index, branch in enumerate(branch_list):
        print(f"Processing {branch} ...")
        filename = simname + "_" + branch +".osop.d4"
        delimiter = '\\s+'
        columns = ["BranchID","Type","Time","P_inst","Q_inst","Voltage","V_angle","Current","I_angle"]
        dtype_mapping = {"Time": str,}
        df = pd.read_csv(filename, delimiter=delimiter, names = columns, skiprows = 11,dtype = dtype_mapping) 
        # Extracting parts from the string and formatting the 'Time' column
        df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")
        # data frame process
        df = d4_file_br_process(df,time_increment)
        # calculate sum value
        df_sum = d4_find_max(df)
        #update summary result
        result_df = result_update(result_df, df_sum, index)

        # save the data
        sumdataframe.append(df_sum)
        d4dataframe.append(df)

    return d4dataframe, sumdataframe, result_df

# doing invididual d4 file process and calculatoin for branch step output
def d4_file_br_process(df, time_increment):

    window_sizes = {'30min': 1800,'20min': 1200, '10min': 600, '5min': 300}

    for time_interval, window_size in window_sizes.items():
        df[f'I_{time_interval}'] = calculate_rolling_rms(df, 'Current', window_size, time_increment)

    return df

# calculate rms
def calculate_rolling_rms(data, column, window_size, time_increment):
    return data[column].rolling(window=int(window_size / time_increment)).apply(lambda x: np.sqrt(np.mean(x**2)), raw=True)

# find maximum value and time of each d4 file
def d4_find_max(df):
    # # Insert two empty rows above the first row
    # df = pd.concat([pd.DataFrame(index=range(2)), df], ignore_index=True)
    sum_df = pd.DataFrame(columns=df.columns,index=range(4))
    sum_df.iloc[0, 0] = "Maximum Value"
    sum_df.iloc[1, 0] = "Maximum Value at Time"
    sum_df.iloc[2, 0] = "Minimum Value"
    sum_df.iloc[3, 0] = "Minimum Value at Time"

    start = 9

    if df.empty:
        sum_df.iloc[0, 1] = "DATA FOR THIS FEEDER IS NOT AVAILABLE"

    else:
        for column in df.columns[start:]:
            if df[column].dtype in [int, float]:
                max_value = df[column].max()
                time_of_max = df.loc[df[column].idxmax(), 'Time']
                sum_df.at[0, column] = max_value
                sum_df.at[1, column] = time_of_max
                min_value = df[column].min()
                time_of_min = df.loc[df[column].idxmin(), 'Time']
                sum_df.at[2, column] = min_value
                sum_df.at[3, column] = time_of_min

    return sum_df

# update result table based on output of d4 process
def result_update(target,df_sum,index):
    
    target.loc[index,'r_30min'] = df_sum.at[0,'I_30min']
    target.loc[index,'r_max_t1'] = df_sum.at[1,'I_30min']

    target.loc[index,'r_20min'] = df_sum.at[0,'I_20min']
    target.loc[index,'r_max_t2'] = df_sum.at[1,'I_20min']

    target.loc[index,'r_10min'] = df_sum.at[0,'I_10min']
    target.loc[index,'r_max_t3'] = df_sum.at[1,'I_10min']

    target.loc[index,'r_5min'] = df_sum.at[0,'I_5min']
    target.loc[index,'r_max_t4'] = df_sum.at[1,'I_5min']
    
    return target

if __name__ == "__main__":
    # Add your debugging code here
    simname = "test_model_1"  # Provide a simulation name or adjust as needed
    main_option = "1"  # Adjust as needed
    time_start = "0070000"  # Adjust as needed
    time_end = "0080000"  # Adjust as needed
    option_select = "2"  # Adjust as needed
    text_input = "AC_02_OLE"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = "5"  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)

