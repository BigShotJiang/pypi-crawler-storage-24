#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jacky Lai
# Created on: Oct 2025
# Last Modified: Oct 2025
#=================================================================
# Copyright (c) 2025 [Jacky Lai]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================

"""
Pre-requisite: 
xxxxx.xlsx: summary spreadsheet with user configuration settings
Result saved in a proper folder structure
train_list.csv for each simulation already extracted within each folder
Used Input:
simname: to locate the result file or file rename
option_select: to define the option selected in subfunction
text_input: to locate the excel file name
Expected Output:
Updated excel spreadsheet with low voltage analysis result.
Description:
This script summarised the low voltage results using the train_list.csv various simulation to one place.
It will highlight the low voltage events based on the user defined thresholds.
It will generate the following sheets:
- Filtered Branch Results
- Filtered Train Results
- Branch Results
- Train Results
The script reads the configuration from the "Start" sheet of the provided Excel file, 
processes the train_list.csv files from specified simulation folders, 
and outputs the results back into the same Excel file with appropriate formatting."""

#=================================================================
# VERSION CONTROL
# V0.1 (Jacky Lai) - Draft Version
# V1.0 (Jieming Ye) - Update following review
# V2.0 (Jieming Ye) - Update using the xlsxwriter to output
#=================================================================
# Set Information Variable
# N/A
#=================================================================

import pandas as pd
import os

from datetime import datetime, time

from openpyxl import load_workbook
from xlsxwriter.utility import xl_range,xl_col_to_name

# import vision_oslo
from vision_oslo_extension.shared_contents import SharedMethods
from vision_oslo_extension.shared_excel_helper import excel_to_rowcol,excel_to_table_list,pddataframe_to_excel_with_format

def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):

    print("")
    print("Low Voltage Summary for AC or DC - - - > ")
    print("")
    
    # Specify Excel file name
    excel_file = text_input + ".xlsx"
    excel_result = f"{excel_file.rsplit('.', 1)[0]}_result.xlsx"

    if not SharedMethods.check_existing_file(excel_file):
        return False
    
    # Option:
    # 1: Low Voltage Assessment

    if not SharedMethods.can_write_file(excel_result):
        SharedMethods.print_message(f"ERROR: Result file {excel_result} is currently in use. Please close or delete it before running the process.","31")
        return False
    
    # Read the start tab in the excel and collect information
    result = start_reading_process(excel_file)
    if not result:
        return False
    sims_df, filters, limits, start_page = result

    try:
        # Validate inputs
        if sims_df is None or limits is None:
            SharedMethods.print_message("ERROR: Missing simulations or limits from the 'Start' sheet.", "31")
            return False

        # check essential files
        if not check_essential_files(sims_df):
            return False

        # read all train_list.csv for each simulation
        sim_data = load_simulation_data(sims_df, filters)
        if not sim_data:
            SharedMethods.print_message("ERROR: No simulation data loaded. Ensure train_list.csv files exist and filters are correct.", "31")
            return False

        # get unique sorted branches and trains
        sorted_branches, sorted_trains = get_unique_sorted_lists(sim_data)
        if len(sorted_branches) == 0 or len(sorted_trains) == 0:
            SharedMethods.print_message("WARNING: No branches or trains found after loading data. Results may be empty.", "33")

    except ValueError as ve:
        SharedMethods.print_message(f"ERROR: Input validation failed - {ve}", "31")
        return False
    except Exception as e:
        SharedMethods.print_message(f"ERROR: Unexpected error during pre-processing: {e}", "31")
        return False
    
    
    sim_data_v = assess_voltage(sim_data, limits)

    time_interval = 5  # Assuming each record represents a 5-second interval
    
    # generate train results
    train_results_df = generate_train_results(sim_data_v, sorted_trains,time_interval)

    # generate branch results
    branch_results_df = generate_branch_results(sim_data_v, sorted_branches)

    # Filter train results
    filtered_train_results_df = filter_results_by_amber_threshold(train_results_df, limits['amber'])

    # Filter branch results
    filtered_branch_results_df = filter_results_by_amber_threshold(branch_results_df, limits['amber'])

    # Export results to Excel
    export_results_to_excel(excel_result, train_results_df, branch_results_df, filtered_train_results_df, filtered_branch_results_df, sims_df, limits,start_page)

    return True

# read the start tab and collect informaiton
def start_reading_process(excel_file):

    try:
        wb = load_workbook(excel_file)
        if 'Start' not in wb.sheetnames:
            SharedMethods.print_message("ERROR: 'Start' sheet not found. Ensure the correct excel file selected.","31")
            return False

        # Process Start sheet first
        result = start_page_processing(wb['Start'])

        if result is False:
            return False

        sims_df, filters, limits, start_page = result

        # Now remove other sheets
        for sheet_name in wb.sheetnames:
            if sheet_name != 'Start':
                wb.remove(wb[sheet_name])

        # Save changes
        wb.save(excel_file)

    except Exception as e:
        SharedMethods.print_message(f"(Close the Excel file and Start Again) Error: {e}","31")
        return False
    
    print(f"Simulations found ({len(sims_df)} rows):")
    print(str(sims_df))
    print("Filters:")
    print(str(filters))
    print("Limits:")
    print(str(limits))

    # Return for further processing
    return sims_df, filters, limits, start_page

# Read the Inputs sheet using fixed cell positions
def start_page_processing(sheet):
    #------ read header information table
    print("Reading Configuration Setting ...")
    info_start_row,info_start_col = excel_to_rowcol('A2')
    _,info_end_col = excel_to_rowcol('B2')
    setting_start_row,setting_start_col = excel_to_rowcol('A12')
    _,setting_end_col = excel_to_rowcol('F12')
    addi_start_row,addi_start_col = excel_to_rowcol('H12')
    _,addi_end_col = excel_to_rowcol('K12')

    brn_start_row,brn_start_col = excel_to_rowcol('D12')

    info_table = excel_to_table_list(sheet,info_start_row,info_start_col,info_end_col,info_start_row,info_start_col,1)
    setting_table = excel_to_table_list(sheet,setting_start_row,setting_start_col,setting_end_col,setting_start_row,setting_start_col,1)
    addi_table = excel_to_table_list(sheet,addi_start_row,addi_start_col,addi_end_col,addi_start_row,addi_start_col+1,1)

    branch_table = excel_to_table_list(sheet,brn_start_row,brn_start_col,brn_start_col,brn_start_row,brn_start_col,1)

    if setting_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at A12.","31")
        return False
    
    if addi_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at I12.","31")
        return False
    
    # simulation data
    sims_df = pd.DataFrame(addi_table)
    # New dataframe take only 3rd and 2nd column with new column name SimName and Folder
    sims_df = sims_df.iloc[:, [2, 1]]  # Select columns 2 and 3 (0-based indexing)
    sims_df.columns = ['SimName', 'Folder']  # Rename columns

    # converted nested branch_table list to a simple list of branches
    branches = [item[0] for item in branch_table]
    # analysis time
    if len(setting_table) > 1:
        SharedMethods.print_message("WARNING: Multiple rows found in settings table. Only the first row will be used.","33")
    else:
        start = setting_table[0][4]
        end = setting_table[0][5]
        # validate time
        if start is not None or end is not None:
            if not is_valid_time_string(start):
                SharedMethods.print_message(f"ERROR: Invalid Start Time (hh:mm:ss): '{start}'. Check Input...","31")
                return False
            if not is_valid_time_string(end):
                SharedMethods.print_message(f"ERROR: Invalid End Time (hh:mm:ss): '{end}'. Check Input...","31")
                return False

        amber = setting_table[0][1]
        red = setting_table[0][0]
        time_threshold_s = setting_table[0][2]
        # validate limits
        if amber is None or red is None or time_threshold_s is None:
            SharedMethods.print_message("ERROR: AmberLimit, RedLimit, and TimeThresholdSeconds are compulsory setting input.","31")
            return False

        try:
            amber = float(amber)
            red = float(red)
            time_threshold_s = float(time_threshold_s)
        except ValueError:
            SharedMethods.print_message("ERROR: AmberLimit, RedLimit, and TimeThresholdSeconds must be numeric.","31")
            return False
    
    filters = {"branches": branches, "start": start, "end": end}

    limits = {"amber": amber, "red": red, "time_threshold_s": time_threshold_s}
    
    start_page = {
        "InfoTable": info_table,
        "SettingTable": setting_table,
        "AddiTable": addi_table,
        "BranchTable": branch_table
    }

    return sims_df, filters, limits, start_page

# checking essential files existence
def check_essential_files(sims_df):
    # check essential files
    print('Checking essential files...')
    for _, row in sims_df.iterrows():
        folder = row['Folder']
        sim = row['SimName']
        if pd.isna(folder) or pd.isna(sim):
            SharedMethods.print_message("WARNING: Scenario List Information Not Complete. Please check.","33")
        else:
            # Adjust the require checking files below
            file_to_check = "train_list.csv"
            if not SharedMethods.folder_file_check(folder, file_to_check, True):
                SharedMethods.print_message("ERROR: Check info above. Adjust Setting or Do extraction first","31")
                return False
        
    return True

# load all train_list.csv for each simulation
def load_simulation_data(sims_df, filters):
    sim_data = {}
    for _, row in sims_df.iterrows():
        sim_name = row['SimName']
        folder = row['Folder']
        csv_path = os.path.join(folder, "train_list.csv")
        print(f"Loaded train_list.csv for {sim_name}")
        
        # Read only the columns of interest
        df = pd.read_csv(csv_path, usecols=[0, 2, 5, 12], 
                            names=['Train', 'Time', 'Voltage', 'Branch'], header=0)
        
        # Remove data points with zero voltage (neutral section)
        df = df[df['Voltage'] != 0]

        # Ensure Time is string
        df['Time'] = df['Time'].astype(str)

        # Convert h.mm.ss / hh.mm.ss  →  HH:MM:SS
        df['Time'] = (
            df['Time']
            .str.strip()
            .str.split('.', expand=True)
            .apply(lambda x: f"{int(x[0]):02d}:{int(x[1]):02d}:{int(x[2]):02d}", axis=1)
        )
        # convert to datatime format for date time
        df['Time'] = pd.to_datetime(df['Time'], format="%H:%M:%S",errors='coerce').dt.time
        
        # Apply filters if provided
        mask = pd.Series(True, index=df.index)

        # Branch filter (only if provided)
        if filters.get('branches'):
            mask &= df['Branch'].isin(filters['branches'])

        # Time filter (only if both provided)
        start = filters.get('start')
        end = filters.get('end')

        if start is not None and end is not None:
            mask &= (df['Time'] >= start) & (df['Time'] <= end)

        filtered_df = df.loc[mask]
        sim_data[sim_name] = filtered_df

    return sim_data
    
def get_unique_sorted_lists(sim_data):
    """
    Get unique and sorted lists of branches and trains from all simulation data frames.

    Args:
        sim_data (dict): Dictionary with simulation names as keys and data frames as values.

    Returns:
        tuple: Sorted list of unique branches, sorted list of unique trains.
    """
    all_branches = set()
    all_trains = set()

    for sim_name, df in sim_data.items():
        all_branches.update(df['Branch'].unique())
        all_trains.update(df['Train'].unique())

    # Convert sets to sorted lists
    sorted_branches = sorted(all_branches)
    sorted_trains = sorted(all_trains)

    return sorted_branches, sorted_trains

def assess_voltage(sim_data, limits):
    """
    Add a column to each data frame in sim_data to assess voltage levels.

    Args:
        sim_data (dict): Dictionary with simulation names as keys and data frames as values.
        limits (dict): Dictionary containing 'amber' and 'red' voltage thresholds.

    Returns:
        dict: Updated sim_data with an additional 'Assessment' column in each data frame.
    """
    print("Voltage Assessment In Progress...")
    amber_threshold = limits['amber']
    red_threshold = limits['red']

    for sim_name, df in sim_data.items():
        # Add a new column 'Assessment' based on voltage thresholds
        df['Assessment'] = df['Voltage'].apply(
            lambda v: 2 if v < red_threshold else (1 if v < amber_threshold else 0)
        )

        # SharedMethods.print_message(f"Voltage assessment added for {sim_name}", "32")

    return sim_data

def generate_train_results(sim_data, sorted_trains, time_interval):
    """
    Generate a results data frame for each train across all simulations.

    Args:
        sim_data (dict): Dictionary with simulation names as keys and data frames as values.
        sorted_trains (list): Sorted list of unique trains.

    Returns:
        pd.DataFrame: Results data frame with train statistics across simulations.
    """
    results = []

    for train in sorted_trains:
        train_row = {"Train": train}
        for sim_name, df in sim_data.items():
            # Filter data for the current train
            train_data = df[df['Train'] == train]

            if not train_data.empty:
                # Calculate statistics
                min_voltage = train_data['Voltage'].min()
                min_voltage_time = train_data.loc[train_data['Voltage'].idxmin(), 'Time']
                time_under_amber = len(train_data[train_data['Assessment'].isin([1, 2])]) * time_interval  # can be adjusted based on value set in main loop
                #amber_events = len(train_data[train_data['Assessment'] == 1])
                #red_events = len(train_data[train_data['Assessment'] == 2])

                # Update the row for this simulation
                train_row[f"{sim_name}_MinV"] = min_voltage
                train_row[f"{sim_name}_MinV_Time"] = min_voltage_time
                train_row[f"{sim_name}_TimeUnderAmber"] = time_under_amber
                #train_row[f"{sim_name}_AmberEvents"] = amber_events
                #train_row[f"{sim_name}_RedEvents"] = red_events
            else:
                # If no data for this train in the simulation, fill with NaN or default values
                train_row[f"{sim_name}_MinV"] = None
                train_row[f"{sim_name}_MinV_Time"] = None
                train_row[f"{sim_name}_TimeUnderAmber"] = 0
                #train_row[f"{sim_name}_AmberEvents"] = 0
                #train_row[f"{sim_name}_RedEvents"] = 0

        # Append the row to the results
        results.append(train_row)

    # Convert results to a DataFrame
    results_df = pd.DataFrame(results)

    return results_df

def generate_branch_results(sim_data, sorted_branches):
    """
    Generate a results data frame for each branch across all simulations.

    Args:
        sim_data (dict): Dictionary with simulation names as keys and data frames as values.
        sorted_branches (list): Sorted list of unique branches.

    Returns:
        pd.DataFrame: Results data frame with branch statistics across simulations.
    """
    results = []

    for branch in sorted_branches:
        branch_row = {"Branch": branch}
        for sim_name, df in sim_data.items():
            # Filter data for the current branch
            branch_data = df[df['Branch'] == branch]

            if not branch_data.empty:
                # Calculate statistics
                min_voltage = branch_data['Voltage'].min()
                min_voltage_train = branch_data.loc[branch_data['Voltage'].idxmin(), 'Train']
                min_voltage_time = branch_data.loc[branch_data['Voltage'].idxmin(), 'Time']
                
                # Update the row for this simulation
                branch_row[f"{sim_name}_MinV"] = min_voltage
                branch_row[f"{sim_name}_MinV_Train"] = min_voltage_train
                branch_row[f"{sim_name}_MinV_Time"] = min_voltage_time
            else:
                # If no data for this branch in the simulation, fill with NaN or default values
                branch_row[f"{sim_name}_MinV"] = None
                branch_row[f"{sim_name}_MinV_Train"] = None
                branch_row[f"{sim_name}_MinV_Time"] = None

        # Append the row to the results
        results.append(branch_row)

    # Convert results to a DataFrame
    results_df = pd.DataFrame(results)

    return results_df

def filter_results_by_amber_threshold(results_df, amber_threshold):
    """
    Filter the results data frame to include only rows where the minimum voltage is below the amber threshold.

    Args:
        results_df (pd.DataFrame): The results data frame (train or branch).
        amber_threshold (float): The amber voltage threshold.

    Returns:
        pd.DataFrame: Filtered results data frame.
    """
    # Identify columns that represent minimum voltage for simulations
    min_v_columns = [col for col in results_df.columns if col.endswith("_MinV")]

    # Filter rows where any of the MinV columns have a value below the amber threshold
    filtered_df = results_df[
        results_df[min_v_columns].apply(lambda row: any(row < amber_threshold), axis=1)
    ]

    return filtered_df

def export_results_to_excel(excel_result, train_results_df, branch_results_df, filtered_train_results_df, filtered_branch_results_df, sims_df, limits, start_page):
    """
    Export results data frames to the input Excel file with specified layout and formatting.

    Args:
        excel_file (str): Path to the Excel file.
        train_results_df (pd.DataFrame): Train results data frame.
        branch_results_df (pd.DataFrame): Branch results data frame.
        filtered_train_results_df (pd.DataFrame): Filtered train results data frame.
        filtered_branch_results_df (pd.DataFrame): Filtered branch results data frame.
        time_limit (float): Time limit for coloring TimeUnderAmber cells.
    """

    # write data to excel
    with pd.ExcelWriter(excel_result, engine='xlsxwriter') as writer:
        print("Writing to Excel...")
        simulations = sims_df["SimName"].tolist()
        sheets = ["Branch Results (Highlighted)","Train Results (Highlighted)","Branch Results (All Lists)","Train Results (All Lists)"]

        print("Generate Setting Page...")
        setting_summary(writer,start_page)

        # writing to each sheet
        # 1 Branch Sheet, 2 Train Sheet
        format_result_sheet(writer,sheets[0],filtered_branch_results_df,simulations,limits,1)
        format_result_sheet(writer,sheets[1],filtered_train_results_df,simulations,limits,2)
        format_result_sheet(writer,sheets[2],branch_results_df,simulations,limits,1)
        format_result_sheet(writer,sheets[3],train_results_df,simulations,limits,2)
        
        print("Saving Excel File...")

# new result page writer (format and writing in one go)
def setting_summary(writer: pd.ExcelWriter,start_page):
    print('Copy the Setting Information...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Setting")
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1, 'text_wrap': True})
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    grey_fill = workbook.add_format({"bg_color": "#888888"})
    # copy header info
    #===================INFO TABLE==========================================
    irow = 1
    icol = 0
    for row, line in enumerate(start_page['InfoTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data)
    
    #==================Main Setting=========================================
    irow = 11
    icol = 0
    # header info
    worksheet.merge_range(irow-2,icol,irow-2,icol+2,"Limits",header_format)
    worksheet.merge_range(irow-2,icol+3,irow-2,icol+5,"Filters",header_format)
    # grey seperate line
    header = ['Low Voltage Failure Limit - Red (V)','Low Voltage Warning Limit - Amber (V)','Low Voltage Time Limit (s)','Branches','Start Time (hh:mm:ss)','End Time (hh:mm:ss)']
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, col_name, header_format)
    # data
    for row, line in enumerate(start_page['SettingTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)

    for row, line in enumerate(start_page['BranchTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)

    #==================Supply Point=========================================
    irow = 11
    icol = 7
    # header info
    header = ['Outage Number','Simulation Sub-Folder','Simulation Name','Notes']
    worksheet.write(irow-2, icol, "Outage List", header_format)
    # grey seperate line
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, col_name, header_format)
    
    for row, line in enumerate(start_page['AddiTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)
    
    worksheet.set_column('A:C', 20) # default
    worksheet.set_column('D:F', 10) # supply point name
    worksheet.set_column('H:K', 15) # feeder station name
    
    return

def format_result_sheet(writer: pd.ExcelWriter,sheet_name,dataframe,simulation_names,limits,sheet_type):
    """
    Docstring for format_result_sheet
    
    :param ws: Current worksheet
    :param simulation_names: Description
    :param limits: Description
    :param sheet_type: 1: Branch, 2: Train
    :param header_row: Description
    :param start_data_row: Description
    """
    workbook = writer.book
    worksheet = workbook.add_worksheet(sheet_name)
    # define formatting
    # Header: bold, center, grey background, all borders
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})
    # Subheader: italic, size 10, grey background, all borders
    subheader_format = workbook.add_format({'italic': True,'font_size': 10,'align': 'center','valign': 'vcenter','bg_color': '#EDEDED','border': 1, 'text_wrap': True})
    # Setting info: center aligned
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    # Data number format: 00 integer
    integer_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '00','border': 1})
    # time format: hh:mm:ss
    time_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': 'hh:mm:ss','border': 1})

    if sheet_type == 1:
        header = ['Mimimum Voltage (V)','Train VO ID','At Time (hh:mm:ss)']
        time_col = 0 # reverse order for branch sheet, time column is the last column in train sheet but is the 3rd column in branch sheet
    else:
        header = ["Mimimum Voltage (V)","At Time (hh:mm:ss)",f"Duration < {limits['amber']}V (S)"]
        time_col = 1

    # actual data writing started
    row1, cols1 = dataframe.shape

    #==================== FIRST TABLE=============================================================
    irow = 2
    icol = 0
    format_column_id = []
    format_column_name = []
    dwell_column_name = []

    for simname in simulation_names:
        worksheet.merge_range(irow-2,icol+1,irow-2,icol+3,simname,header_format)
        for c_idx, col_name in enumerate(header):
            worksheet.write(irow-1, icol + 1 + c_idx, col_name, subheader_format)
        # prepare the conditional formatting columns
        format_column_id.append(icol+1)
        format_column_name.append(xl_col_to_name(icol+1))
        if sheet_type == 2:
            dwell_column_name.append(xl_col_to_name(icol+3))
        icol = icol + 3

    
    icol = 0
    worksheet.write(irow-1, icol, "Branch", subheader_format)
    for r_idx, row in enumerate(dataframe.values):
        for c_idx, value in enumerate(row):
            if (c_idx+2) % 3 == 0: # votlage column
                worksheet.write(irow + r_idx, icol + c_idx, value, integer_format)
            elif (c_idx+time_col) % 3 == 0: # time column
                worksheet.write(irow + r_idx, icol + c_idx, value, time_format)
            else:
                worksheet.write(irow + r_idx, icol + c_idx, value, table_format)

    # conditional formatting
    red_bkg = workbook.add_format({"bg_color": "#FF0000"})
    yellow_bkg = workbook.add_format({"bg_color": "#FFFF00"})
    amber_bkg = workbook.add_format({"bg_color": "#FFDD00"})
    green_bkg = workbook.add_format({"bg_color": "#00FF00"})

    # add conditional formatting
    if sheet_type == 1:
        for col in format_column_id:
            v_range = xl_range(irow,col,irow+row1-1,col)
            worksheet.conditional_format(v_range,{'type': 'cell','criteria':'<', 'value': limits['red'],'format': red_bkg}) 
            worksheet.conditional_format(v_range,{'type': 'cell','criteria':'<', 'value': limits['amber'],'format': amber_bkg})
    else:
        for index, col in enumerate(format_column_id):
            v_range = xl_range(irow,col,irow+row1-1,col)
            worksheet.conditional_format(v_range,{'type': 'cell','criteria':'<', 'value': limits['red'],'format': red_bkg}) 
            worksheet.conditional_format(v_range,{'type': 'formula','criteria':f"=AND({format_column_name[index]}{irow}<{limits['amber']},{dwell_column_name[index]}{irow}>{limits['time_threshold_s']})",'format': red_bkg}) 
            worksheet.conditional_format(v_range,{'type': 'cell','criteria':'<', 'value': limits['amber'],'format': amber_bkg})
    
    worksheet.set_column(icol,icol+cols1, 12) # default

def is_valid_time_string(val):
    """
    Validate string in HH:MM:SS format.
    And also a valid time.
    """
    if val is None or pd.isna(val):
        return False

    # Already a time object
    if isinstance(val, time):
        return True

    # datetime or pandas Timestamp
    if isinstance(val, (datetime, pd.Timestamp)):
        return True

    # String case
    if isinstance(val, str):
        try:
            datetime.strptime(val.strip(), "%H:%M:%S")
            return True
        except ValueError:
            return False

    return False


if __name__ == "__main__":
    # Add your debugging code here
    simname = "DC000"  # Provide a simulation name or adjust as needed
    main_option = "10"  # Adjust as needed
    time_start = "0070000"  # Adjust as needed
    time_end = "0080000"  # Adjust as needed
    option_select = "1"  # Adjust as needed
    text_input = "Low_V_Summary_template"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = "1"  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)