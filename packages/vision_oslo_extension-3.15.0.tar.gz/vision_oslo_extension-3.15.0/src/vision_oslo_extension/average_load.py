#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jieming Ye
# Created on: Feb 2024
# Last Modified: Feb 2024
#=================================================================
# Copyright (c) 2024 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Pre-requisite: 
SimulationName.oof: default oslo output file after successfully run a simulation.
xxxxx.xlsx: excel spreadsheet with proper user settings.
SimulationName.lst.txt: required for option 4
Used Input:
simname: to locate the result file or file rename
time_start: to define the analysis start time
time_end: to define the analysis end time
option_select: to define the option selected in subfunction
text_input: to locate the excel file name
other input for oslo_extraction.py only.
Expected Output:
Updated excel spreadsheet with analysis result.
Description:
This script defines the process of doing average load assessment.
First, it reads the excel file and save the user input in a data frame called start_df. Then it find the related .d4 files and read information one by one and saved in a data frame list called d4dataframe. The calculation result is saved in a similar format data frame list called sumdataframe. It then doing some analysis and save the final result in an updated data frame. Final step is to save all information in the excel in a proper format. The whole process is easy to follow via reading the code.
The key manual updating part is get_result_range() function which depends on the desired output format in excel, followed by table_formatting() function where some reading needs manual input. The other process should be auto adjustable as long as the excel input format is followed.

"""
#=================================================================
# VERSION CONTROL
# V1.0 (Jieming Ye) - Initial Version
# V2.0 (Jieming Ye) - Using xlsxwriter for Excel Output instead of openpyxl
#=================================================================
# Set Information Variable
# N/A
#=================================================================

import pandas as pd
import numpy as np
from xlsxwriter.utility import xl_range
from datetime import datetime
from openpyxl import load_workbook

# import vision_oslo
from vision_oslo_extension import oslo_extraction
from vision_oslo_extension import model_check
from vision_oslo_extension.shared_contents import SharedMethods
from vision_oslo_extension.shared_excel_helper import excel_to_rowcol,excel_to_table_list,pddataframe_to_excel_with_format


def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):
    
    print("")
    print("Average Power Assessment - - - > ")
    print("")
    
    simname = simname
    # Specify Excel file name
    excel_file = text_input + ".xlsx"
    excel_result = f"{excel_file.rsplit('.', 1)[0]}_result.xlsx"

    if not SharedMethods.check_existing_file(excel_file):
        return False
    
    # node_list = [['SPF1','TSC1','TSC2'],['SPF2','TSC3','TSC4']]
    # node_list = [['SPF1','TSC1','TSC2'],['SPF2','TSC3','TSC4'],['SPF2','TSC3','TSC4'],['SPF2','TSC3','TSC4'],['SPF2','TSC3','TSC4'],['SPF2','TSC3','TSC4']]
    #option = "1" # Fully Restart, require oof, and list
    #option = "2" # auto, oof only, self configuration file
    #option = "3" # manual, exisiting d4 and mxn, self configuration
    #option = "4" # manual, create d4 and mxn only.

    option = option_select # 1:Fully Restart, require oof, and list

    time_increment = 5
    start = 10

    space  = 5

    if option not in ["0","1","2","3","4"]:
        SharedMethods.print_message("ERROR: Error in average_load.py. Please contact Support.","31")
        return False
    
    if option == "0":
        SharedMethods.print_message("ERROR: Please select an option to proceed.","31")
        return False
    
    if option == "1":
        lstfilename = simname + '.lst.txt'
        if not SharedMethods.check_existing_file(lstfilename):
            return False
    
    if option in ["1","2","4"]:
        if not SharedMethods.check_oofresult_file(simname):
            return False

    if not SharedMethods.can_write_file(excel_result):
        SharedMethods.print_message(f"ERROR: Result file {excel_result} is currently in use. Please close or delete it before running the process.","31")
        return False

    # read data from start tab
    result = start_reading_process(
        simname, time_start, time_end, text_input, low_v, high_v, time_step,excel_file,option
    )
    if result == False:
        return False
    else:
        supply_list, node_list, start_df, start_page = result

    # number of dataframes to create
    total = len(supply_list)

    # check if want to go throught the feeder check process
    if option in ["1","2","4"]:

        if not one_stop_AC_extraction(simname, time_start, time_end,supply_list):
            return False

        if option == "4":
            return True
        
    if option == "3":
        print("Checking essential d4 files and mxn files...")
        for supply in supply_list:
            filename = simname + "_" + supply + ".osop.d4"
            if not SharedMethods.check_existing_file(filename):
                SharedMethods.print_message(f"ERROR: d4 file {supply} do not exist. Select option 2 to proceed.","31")
                return False
        filename = simname + ".osop.mxn"
        if not SharedMethods.check_existing_file(filename):
            SharedMethods.print_message(f"ERROR: File {filename} do not exist. Select option 2 to proceed.","31")
            return False
    
    try:
        # read min max value
        mxndataframe = mxn_file_reading(simname)

        # process d4 file
        p_r_df,i_r_df,d4dataframe,sumdataframe = feeder_reading_process(simname, supply_list,time_increment)
        
        # update NPS
        p_r_df = nps_update(p_r_df, start_df, supply_list)

        # update min max value voltage
        p_r_df = minmax_update(simname,p_r_df,supply_list,mxndataframe,node_list)

        # process information to get the summary (substation real time sum)
        start_sum_df,s_r_df, fsdataframe,fssum, feeder_dict = summary_info_power(supply_list,start_df,d4dataframe)


        # get feeder station list
        feeder_station = list(feeder_dict.keys())
        fsnumber = len(feeder_station)

        # update NPS
        s_r_df = nps_update(s_r_df, start_sum_df, feeder_station)

        # items_total = start_df.shape[0]
        # print(str(items_total))

        data_write_save(simname ,excel_result, start,total,space,fsnumber,start_df, start_sum_df,p_r_df,i_r_df,s_r_df, \
                        mxndataframe,d4dataframe,fsdataframe,sumdataframe,fssum, \
                            supply_list,node_list,feeder_station,feeder_dict,start_page)
    
    except KeyError as e:
        SharedMethods.print_message(f"ERROR: Unexpected error occured: {e}. Possibly due to incompleted data.","31")
        return False
    
    except Exception as e:
        SharedMethods.print_message(f"ERROR: Unexpected error occured: {e}","31")
        return False

    return True

# extraction
def one_stop_AC_extraction(simname, time_start, time_end,supply_list):

    # User defined time windows extraction
    time_start = SharedMethods.time_input_process(time_start,1)
    time_end = SharedMethods.time_input_process(time_end,1)

    if time_start == False or time_end == False:
        return False

    # process 1: feeder step output
    print("Extrating feeder step output from Start Tab ... ")

    # processing the list
    for items in supply_list:
        #print(items)
        if not oslo_extraction.feeder_step_one(simname,items,time_start,time_end):
            SharedMethods.print_message(f"WARNING: Error for {items} will be ignored and process continued...","33")

    # process 2: minmax value extraction
    print("Extrating min-max output...")
    
    # define the default osop command
        
    opcname = simname + ".opc"

    with open(opcname,"w") as fopc:
        fopc.writelines("MINMAX VALUES REQUIRED\n")

    if not SharedMethods.osop_running(simname):
        return False

    return True

# write data to excel
def data_write_save(simname,excel_result:str,start,total,space,fsnumber,start_df,start_sum_df,p_r_df,i_r_df,s_r_df, \
                    mxndataframe,d4dataframe,fsdataframe,sumdataframe,fssum, \
                        supply_list,node_list,feeder_station,feeder_dict,start_page):

    # write data to excel
    for i in range(1,51):
        excel_dashboard = f"0_{simname}_result_supply_points_loading_{i}.xlsx"
        # if file does not exist
        if not SharedMethods.check_existing_file(excel_dashboard,printing = False):
            break
    else:
        SharedMethods.print_message("WARNING: Dashboard exporting fail. More than 50 dashboard exists already.","33")

    with pd.ExcelWriter(excel_dashboard, engine='xlsxwriter') as writer:
        print(f"Generating result dashboard {excel_dashboard}...")
        result_summary(writer,simname,start_df,p_r_df,i_r_df,start_sum_df,s_r_df,start_page,start,space)

    with pd.ExcelWriter(excel_result, engine='xlsxwriter') as writer:
        # get currrent workbook to do process
        workbook = writer.book
        print("Generate Setting Page...")
        setting_summary(writer,start_df,mxndataframe,start_page,start)
        print("Generate Result Page...")
        result_summary(writer,simname,start_df,p_r_df,i_r_df,start_sum_df,s_r_df,start_page,start,space)

        print("Writing min max summary...")
        mxndataframe.to_excel(writer, sheet_name='Data', index=False, startrow = len(feeder_dict)+2+len(supply_list)+2+2)

        # Write each DataFrame to a different sheet in the Excel file
        print("Writing individual feeder...")
        for index, dflist in enumerate(d4dataframe):
            print(f"Saving {supply_list[index]}...")
            # emty columns
            dflist.insert(dflist.columns.get_loc('I_angle')+1,'New_C_1', np.nan)
            dflist.insert(dflist.columns.get_loc('S_30min')+1,'New_C_2', np.nan)
            dflist.insert(dflist.columns.get_loc('I_1800s_RMS')+1,'New_C_3', np.nan)
            dflist.insert(dflist.columns.get_loc('PF_30min')+1,'Excel_Time', np.nan)

            sumdataframe[index].insert(sumdataframe[index].columns.get_loc('I_angle')+1,'New_C_1', np.nan)
            sumdataframe[index].insert(sumdataframe[index].columns.get_loc('S_30min')+1,'New_C_2', np.nan)
            sumdataframe[index].insert(sumdataframe[index].columns.get_loc('I_1800s_RMS')+1,'New_C_3', np.nan)

            sumdataframe[index].to_excel(writer, sheet_name=supply_list[index], index=False, startrow = 0)

            dflist.to_excel(writer, sheet_name=supply_list[index], index=False, startrow = sumdataframe[index].shape[0]+2)

            sheet = writer.sheets[supply_list[index]]
            power_plot(workbook,sheet,dflist,row = sumdataframe[index].shape[0]+2+2,option=1)

        print("Writing feeder station...")
        for index, dflist in enumerate(fsdataframe):
            fssum[index].to_excel(writer, sheet_name=feeder_station[index], index=False, startrow = 0)

            dflist.insert(dflist.columns.get_loc('30minS')+1,'Excel_Time', np.nan)

            dflist.to_excel(writer, sheet_name=feeder_station[index], index=False, startrow = fssum[index].shape[0]+2)
            
            sheet = writer.sheets[feeder_station[index]]
            power_plot(workbook,sheet,dflist,row = fssum[index].shape[0]+2+2,option=2)
        
        # update Data tab
        sheet = writer.sheets['Data']
        data_tab_update(sheet,feeder_dict,supply_list,node_list)

        print("Saving Data...")

    return

# new result page writer (format and writing in one go)
def setting_summary(writer: pd.ExcelWriter,start_df,mxndataframe,start_page,start):
    print('Copy the Setting Information...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Setting")
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})
    table_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})
    grey_fill = workbook.add_format({"bg_color": "#888888"})
    # copy header info
    #===================INFO TABLE==========================================
    irow = 1
    icol = 0
    for row, line in enumerate(start_page['InfoTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data)
    
    #==================Main Setting=========================================
    irow = start
    icol = 0
    # header info
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(start_df.columns):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # data
    for row, line in enumerate(start_page['SettingTable']):
        for col, data in enumerate(line):
            worksheet.write(irow+row,icol+col,data,table_format)

    #==================Supply Point=========================================
    irow = start
    icol = 13
    # header info
    header = ['Supply Point','Site Name','Node ID','Min Voltage']
    for col, col_name in enumerate(header):
        worksheet.write(irow-2, icol + col, col_name, header_format)
    # grey seperate line
    for col, col_name in enumerate(header):
        worksheet.write(irow-1, icol + col, None, grey_fill)
    # additional text
    worksheet.write(irow-3, icol+1,"Individual Feeding Sections", header_format)
    
    # addtional table
    for row, line in enumerate(start_page['AddiTable']):
        for col, data in enumerate(line):
            if col == 3: # minimum voltage needs to be updated accordingly
                node = line[2]
                if node is not None:
                    # Filter mxndataframe for the current feeder and node    
                    node_data = mxndataframe[(mxndataframe['Node'] == node)]
                    if not node_data.empty:
                        # get the minimum voltage
                        value = node_data['Minimum Voltage (kV)'].iloc[0]
                        worksheet.write(irow+row,icol+col,value,table_format)
                    else:
                        SharedMethods.print_message(f"WARNING: No data found for node {node}","33")
            else:
                worksheet.write(irow+row,icol+col,data,table_format)
    
    worksheet.autofit()
    
    return

# new result page writer (format and writing in one go)
def result_summary(writer: pd.ExcelWriter,simname,start_df,p_r_df,i_r_df,start_sum_df,s_r_df,start_page,start,space):
    print('Preparing the Final Result...')
    workbook = writer.book
    worksheet = workbook.add_worksheet("Result")
    # define formatting
    # Header: bold, center, grey background, all borders
    header_format = workbook.add_format({'bold': True,'align': 'center','valign': 'vcenter','bg_color': '#D9D9D9','border': 1})

    # Subheader: italic, size 10, grey background, all borders
    subheader_format = workbook.add_format({'italic': True,'font_size': 10,'align': 'center','valign': 'vcenter','bg_color': '#EDEDED','border': 1, 'text_wrap': True})

    # Setting info: center aligned
    setting_info_format = workbook.add_format({'align': 'center','valign': 'vcenter','border': 1})

    # Data number format: 00.00 (always two digits before decimal, two after)
    number_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '00.00','border': 1})

    # Percentage format: 0.00%
    percentage_format = workbook.add_format({'align': 'center','valign': 'vcenter','num_format': '0.00%','border': 1})

    # Write Basic Information
    project_name = start_page['InfoTable'][0][1]
    feeding_desp = start_page['InfoTable'][1][1]
    modeller = start_page['InfoTable'][2][1]
    date = start_page['InfoTable'][3][1]
    
    worksheet.write('B2', "Project Name:")
    worksheet.write('C2', project_name)
    worksheet.write('B3', "Simulation Name:")
    worksheet.write('C3', simname)
    worksheet.write('B4', "Feeding Arrangement:")
    worksheet.write('C4', feeding_desp)
    worksheet.write('B5', "Result Created by:")
    worksheet.write('C5', modeller)
    worksheet.write('B6', "Result Created at:")
    worksheet.write('C6', datetime.now().strftime("%d-%m-%Y %H:%M"))

    # actual data writing started
    row1, cols1 = start_df.shape
    row2, cols2 = start_sum_df.shape

    #==================== FIRST TABLE=============================================================
    irow = start
    icol = 1
    # write first table
    worksheet.merge_range(irow-1,icol,irow-1,icol+cols1-1,"Site Information Summary",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,start_df,subheader_format,setting_info_format)
    # write 2nd table
    icol = icol + cols1
    # getting the range
    h1_range = xl_range(irow-1,icol,irow-1,icol+5)
    h2_range = xl_range(irow-1,icol+6,irow-1,icol+8)
    h3_range = xl_range(irow-1,icol+9,irow-1,icol+10)
    p_range1 = xl_range(irow+1,icol+5,irow+row1,icol+5)
    nps_range1_1min = xl_range(irow+1,icol+6,irow+row1,icol+6)
    nps_range1_10min = xl_range(irow+1,icol+7,irow+row1,icol+7)
    nps_range1_30min = xl_range(irow+1,icol+8,irow+row1,icol+8)
    v_range_min = xl_range(irow+1,icol+9,irow+row1,icol+9)
    v_range_max = xl_range(irow+1,icol+10,irow+row1,icol+10)
    p_critera1 = f"$J{irow+2}"

    worksheet.merge_range(h1_range,"Maximum Average Apparent Power (MVA)",header_format)
    worksheet.merge_range(h2_range,"Peak NPS (%)",header_format)
    worksheet.merge_range(h3_range,"Voltage (kV)",header_format)

    for c_idx, col_name in enumerate(p_r_df.columns):
        worksheet.write(irow, icol + c_idx, col_name, subheader_format)

    for r_idx, row in enumerate(p_r_df.values):
        for c_idx, value in enumerate(row):
            if c_idx in [6,7,8]: # NPS percentage table
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, percentage_format)
            else:
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, number_format)
    
    #==================== 2ND TABLE=============================================================
    irow = irow + row1 + space
    icol = 1
    # write first table
    worksheet.merge_range(irow-1,icol,irow-1,icol+cols1-1,"Site Information Summary",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,start_df,subheader_format,setting_info_format)
    # write 2nd table
    icol = icol + cols1
    worksheet.merge_range(irow-1,icol,irow-1,icol+13,"Maximum Incoming Feeder RMS Current (A)",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,i_r_df,subheader_format,number_format)
    
    #==================== 3ND TABLE=============================================================
    irow = irow + row1 + space
    icol = 1
    worksheet.merge_range(irow-1,icol,irow-1,icol+cols2-1,"Site Information Summary",header_format)
    pddataframe_to_excel_with_format(worksheet,irow,icol,start_sum_df,subheader_format,setting_info_format)
    # write 2nd table
    icol = icol + cols2
    # getting the range
    h1_range = xl_range(irow-1,icol,irow-1,icol+5)
    h2_range = xl_range(irow-1,icol+6,irow-1,icol+8)
    # h3_range = xl_range(irow-1,icol+9,irow-1,icol+10)
    p_range2 = xl_range(irow+1,icol+5,irow+row2,icol+5)
    nps_range2_1min = xl_range(irow+1,icol+6,irow+row2,icol+6)
    nps_range2_10min = xl_range(irow+1,icol+7,irow+row2,icol+7)
    nps_range2_30min = xl_range(irow+1,icol+8,irow+row2,icol+8)
    # v_range = xl_range(irow+1,icol+9,irow+row1,icol+10)
    p_critera2 = f"$J{irow+2}"

    worksheet.merge_range(h1_range,"Maximum Average Apparent Power (MVA)",header_format)
    worksheet.merge_range(h2_range,"Peak NPS (%)",header_format)
    # worksheet.merge_range(h3_range,"Voltage (kV)",header_format)

    for c_idx, col_name in enumerate(s_r_df.columns):
        worksheet.write(irow, icol + c_idx, col_name, subheader_format)

    for r_idx, row in enumerate(s_r_df.values):
        for c_idx, value in enumerate(row):
            if c_idx in [6,7,8]: # NPS percentage table
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, percentage_format)
            else:
                worksheet.write(irow + 1 + r_idx, icol + c_idx, value, number_format)

    # conditional formatting
    red_bkg = workbook.add_format({"bg_color": "#FF0000"})
    yellow_bkg = workbook.add_format({"bg_color": "#FFFF00"})
    green_bkg = workbook.add_format({"bg_color": "#00FF00"})
    
    worksheet.conditional_format(p_range1,{'type': 'cell','criteria':'<', 'value': f'={p_critera1}*0.9','format': green_bkg}) 
    worksheet.conditional_format(p_range1,{'type': 'cell','criteria':'>=', 'value': f'={p_critera1}','format': red_bkg})
    worksheet.conditional_format(p_range1,{'type': 'cell','criteria':'between', 'minimum': f'={p_critera1}*0.9','maximum': f'={p_critera1}','format': yellow_bkg})
    
    worksheet.conditional_format(p_range2,{'type': 'cell','criteria':'<', 'value': f'={p_critera2}*0.9','format': green_bkg}) 
    worksheet.conditional_format(p_range2,{'type': 'cell','criteria':'>=', 'value': f'={p_critera2}','format': red_bkg})
    worksheet.conditional_format(p_range2,{'type': 'cell','criteria':'between', 'minimum': f'={p_critera2}*0.9','maximum': f'={p_critera2}','format': yellow_bkg})
    
    worksheet.conditional_format(nps_range1_1min,{'type': 'cell','criteria':'<', 'value': 0.018,'format': green_bkg}) 
    worksheet.conditional_format(nps_range1_1min,{'type': 'cell','criteria':'>=', 'value': 0.02,'format': red_bkg})
    worksheet.conditional_format(nps_range1_1min,{'type': 'cell','criteria':'between', 'minimum': 0.018,'maximum': 0.02,'format': yellow_bkg})

    worksheet.conditional_format(nps_range2_1min,{'type': 'cell','criteria':'<', 'value': 0.018,'format': green_bkg}) 
    worksheet.conditional_format(nps_range2_1min,{'type': 'cell','criteria':'>=', 'value': 0.02,'format': red_bkg})
    worksheet.conditional_format(nps_range2_1min,{'type': 'cell','criteria':'between', 'minimum': 0.018,'maximum': 0.02,'format': yellow_bkg})

    worksheet.conditional_format(nps_range1_10min,{'type': 'cell','criteria':'<', 'value': 0.0135,'format': green_bkg}) 
    worksheet.conditional_format(nps_range1_10min,{'type': 'cell','criteria':'>=', 'value': 0.015,'format': red_bkg})
    worksheet.conditional_format(nps_range1_10min,{'type': 'cell','criteria':'between', 'minimum': 0.0135,'maximum': 0.015,'format': yellow_bkg})

    worksheet.conditional_format(nps_range2_10min,{'type': 'cell','criteria':'<', 'value': 0.018,'format': green_bkg}) 
    worksheet.conditional_format(nps_range2_10min,{'type': 'cell','criteria':'>=', 'value': 0.02,'format': red_bkg})
    worksheet.conditional_format(nps_range2_10min,{'type': 'cell','criteria':'between', 'minimum': 0.0135,'maximum': 0.015,'format': yellow_bkg})

    worksheet.conditional_format(nps_range1_30min,{'type': 'cell','criteria':'<', 'value': 0.009,'format': green_bkg}) 
    worksheet.conditional_format(nps_range1_30min,{'type': 'cell','criteria':'>=', 'value': 0.01,'format': red_bkg})
    worksheet.conditional_format(nps_range1_30min,{'type': 'cell','criteria':'between', 'minimum': 0.009,'maximum': 0.01,'format': yellow_bkg})

    worksheet.conditional_format(nps_range2_30min,{'type': 'cell','criteria':'<', 'value': 0.009,'format': green_bkg}) 
    worksheet.conditional_format(nps_range2_30min,{'type': 'cell','criteria':'>=', 'value': 0.01,'format': red_bkg})
    worksheet.conditional_format(nps_range2_30min,{'type': 'cell','criteria':'between', 'minimum': 0.009,'maximum': 0.01,'format': yellow_bkg})

    worksheet.conditional_format(v_range_min,{'type': 'cell','criteria':'<', 'value': 19,'format': green_bkg}) 
    worksheet.conditional_format(v_range_min,{'type': 'cell','criteria':'>=', 'value': 22.5,'format': red_bkg})
    worksheet.conditional_format(v_range_min,{'type': 'cell','criteria':'between', 'minimum': 19,'maximum': 22.5,'format': yellow_bkg})

    worksheet.conditional_format(v_range_max,{'type': 'cell','criteria':'<', 'value': 27.5,'format': green_bkg}) 
    worksheet.conditional_format(v_range_max,{'type': 'cell','criteria':'>=', 'value': 27.5,'format': red_bkg})

    # set column width
    worksheet.set_column('B:Z', 11) # default
    worksheet.set_column('B:B', 25) # supply point name
    worksheet.set_column('H:H', 25) # feeder station name
    
    return

# plot the 30min average power:
def power_plot(workbook, worksheet, dflist, row, option):
    
    # Create time format
    time_format = workbook.add_format({'num_format': 'hh:mm:ss'})

    if option == 1:  # single supply points
        index = 8
        col_time_excel = 49   # AX column (0-based index)
        x_col = 49            # Time column for chart
        y_col = 25            # 26th column (0-based)

        for i in range(len(dflist)):
            r = row + i
            formula = f'=TIME(LEFT(C{index},2),MID(C{index},4,2),RIGHT(C{index},2))'
            worksheet.write_formula(r, col_time_excel, formula, time_format)
            index += 1

        chart_position = 'J8'

    elif option == 2:  # feeder station tab
        index = 8
        col_time_excel = 19   # T column (0-based index)
        x_col = 19
        y_col = 18            # 19th column (0-based)

        for i in range(len(dflist)):
            r = row + i
            formula = f'=TIME(LEFT(A{index},2),MID(A{index},4,2),RIGHT(A{index},2))'
            worksheet.write_formula(r, col_time_excel, formula, time_format)
            index += 1

        chart_position = 'T8'

    # Create scatter chart
    chart = workbook.add_chart({'type': 'scatter', 'subtype': 'smooth'})

    chart.set_size({'width': 15*64, 'height': 20*20})

    chart.set_title({'name': '30-min Average Apparent Power'})
    chart.set_x_axis({'name': 'Time (hh:mm:ss)','major_gridlines': {'visible': True}})

    chart.set_y_axis({'name': 'Average Power (MVA)','major_gridlines': {'visible': True}})
    chart.set_legend({'position': 'top'})

    # Add data series
    chart.add_series({
        'name': '30min Average',
        'categories': [worksheet.name, row, x_col, row + len(dflist) - 1, x_col],
        'values':     [worksheet.name, row, y_col, row + len(dflist) - 1, y_col],
    })

    # Insert chart
    worksheet.insert_chart(chart_position, chart)

    return

# read the start tab and collect informaiton
def start_reading_process(simname, time_start, time_end, text_input, low_v, high_v, time_step, excel_file,option):

    # File check
    print("Check Excel and Deleting Existing Contents ...")

    try:
        wb = load_workbook(excel_file)
        if 'Start' not in wb.sheetnames:
            SharedMethods.print_message("ERROR: 'Start' sheet not found. Ensure the correct excel file selected.","31")
            return False

        # Process Start sheet first
        result = start_page_processing(
            wb['Start'], simname, time_start, time_end,text_input, low_v, high_v, time_step, option
        )

        if result is False:
            return False

        supply_list, node_list, name_list, start_page = result

        # Now remove other sheets
        for sheet_name in wb.sheetnames:
            if sheet_name != 'Start':
                wb.remove(wb[sheet_name])

        # Save changes
        wb.save(excel_file)

    except Exception as e:
        SharedMethods.print_message(f"(Close the Excel file and Start Again) Error: {e}","31")
        return False
        
    # read start up information 
    columns = ["Supply Point Name","OSLO ID","Incoming Voltage (kV)","Incoming Feeder","Capacity (MVA)","Fault Level (MVA)","Feeder Station Name","Cable Rating (MVA)","FSC (MVA)","Supply Type","Supply Voltage (kV)"]
    start_df = pd.DataFrame(start_page['SettingTable'],columns=columns)
    
    # check duplication in OSLO id
    if not SharedMethods.find_duplicates(supply_list): return False

    return supply_list, node_list, start_df, start_page

# start page processing
def start_page_processing(sheet, simname, time_start, time_end, text_input, low_v, high_v, time_step,option):
    '''
    processing start page in three steps
    1. Blindly reading all tables from start page
    2. processing and validation
    3. return required data format for post processing
    
    :param sheet: Description
    '''
    #------ read header information table
    print("Reading Configuration Setting ...")
    info_start_row,info_start_col = excel_to_rowcol('A2')
    _,info_end_col = excel_to_rowcol('B2')
    setting_start_row,setting_start_col = excel_to_rowcol('A11')
    _,setting_end_col = excel_to_rowcol('K11')
    addi_start_row,addi_start_col = excel_to_rowcol('N11')
    _,addi_end_col = excel_to_rowcol('Q11')

    info_table = excel_to_table_list(sheet,info_start_row,info_start_col,info_end_col,info_start_row,info_start_col,1)
    setting_table = excel_to_table_list(sheet,setting_start_row,setting_start_col,setting_end_col,setting_start_row,setting_start_col+1,1)
    addi_table = excel_to_table_list(sheet,addi_start_row,addi_start_col,addi_end_col,addi_start_row,addi_start_col+2,2)

    if setting_table == []:
        SharedMethods.print_message("ERROR: Wrong data format. No information at B11.","31")
        return False
    else:
        if option != "1":
            # get supply point name list
            name_list = [item[0] for item in setting_table]
            if addi_table == []:
                SharedMethods.print_message("ERROR: Wrong data format. No information at P11","31")
                return False
            else:
                node_list = check_node_list(name_list,addi_table)
            if node_list == False:
                return False
        else:
            filename = simname + ".lst.txt"
            node_check = model_check.main_menu(simname, filename, "2", \
                                time_start, time_end, "sp", text_input, low_v, high_v, time_step)
            # Extract elements from the third element to the end for each inner list

            for line in setting_table:
                supply = line[1] # get the supply point oslo id
                for lst in node_check:
                    if lst[1] == supply:
                        nodeline = lst[2:]
                        break                                    
                    else:
                        nodeline = []
                try:
                    node_list.append(nodeline)
                    if nodeline[1] == 'NOT CONNECTED':
                        SharedMethods.print_message(f"ERROR: {nodeline[0]} is not connected to any nodes. Double check or choose option 3 to Proceed.","31")
                        return False

                except Exception as e:
                    SharedMethods.print_message(f"ERROR: {e}. [Potential reason is OSLO mode is not enabled when running the simulation. Double check...]","31")
                    SharedMethods.print_message(f"ERROR: Exception happens at processing {supply}. Ensure the Supply Point OSLO ID is correct...","31")
                    return False

    # prepare the return
    supply_list = [item[1] for item in setting_table]
    start_page = {
        "InfoTable": info_table,
        "SettingTable": setting_table,
        "AddiTable": addi_table
    }


    return supply_list,node_list,name_list,start_page

# check node list
def check_node_list(name_list,table_data):
    # validate the supply point name's existance
    for node_line in table_data:
        feeder = node_line[0]
        if feeder is not None:
            if feeder not in name_list:
                SharedMethods.print_message(f"Warning: Supply Point '{feeder}' cannot be found in the table. Check Name in Column N.","33")
    
    # create container for node_list
    node_list = []
    for supply in name_list:
        node_list.append([])

    # get node list
    for index, supply in enumerate(name_list):
        record = False
        for node_line in table_data:
            feeder = node_line[0]
            node = node_line[2]
            if feeder == supply:
                record = True
            if node is None and record is True:
                record = False
                break

            if record:
                node_list[index].append(node)
    
    # validate the node list
    for index, supply in enumerate(name_list):
        if node_list[index] == []:
            SharedMethods.print_message(f"ERROR: Feeder {supply} has no voltage node associdated. Check the input before proceed.","31")
            return False
    
    # succesful return
    return node_list

# update data tab with connection information
def data_tab_update(sheet,feeder_dict,supply_list,node_list):
    print("Writing Connection Info...")
    row = 0
    col = 0

    # Writing feeder station info
    sheet.write(row, col, 'Feeder Station')
    sheet.write(row, col + 1, 'Linked Supply Points')

    for key, lst in feeder_dict.items():
        row = row + 1
        sheet.write(row, col, key)
        for index, supply in enumerate(lst):
            sheet.write(row, col + index + 1, supply)
    
    # for station, supply in
    row = row + 2

    row = row + 1
    sheet.write(row, col, 'Supply Points')
    sheet.write(row, col + 1, 'Linked Nodes')

    for index, supply in enumerate(supply_list):
        row = row + 1
        sheet.write(row, col, supply)
        
        for index1, node in enumerate(node_list[index]):
            sheet.write(row, col + index1 + 1, node)

    return

# ceate table 1 frame / power
def power_result(supply_list):
    columns = ['Instantanous','01 Minute','02 Minutes','10 Minutes', '20 Minutes', '30 Minutes']
    rows = []

    for feeder in supply_list:
        rows.append(feeder)
    df = pd.DataFrame(index=rows,columns=columns)

    return df

# create table 2 frame/ current
def current_result(supply_list):
    columns = ['Instantanous','05 seconds','10 seconds','15 seconds', '20 seconds', '25 seconds','30 seconds','35 seconds','40 seconds', \
               '60 seconds', '120 seconds', '10 min','20 min','30 min']
    rows = []

    for feeder in supply_list:
        rows.append(feeder)
    df = pd.DataFrame(index=rows,columns=columns)

    return df

# update power based on output of d4 process
def power_update(target,df_sum,feeder):
    index = 9
    for column in target.columns:
        target.at[feeder,column] = df_sum.iloc[0,index]
        index = index + 3
    return target

# update current based on output of d4 process
def current_update(target,df_sum,feeder):
    index = 25
    for column in target.columns:
        target.at[feeder,column] = df_sum.iloc[0,index]
        index = index + 1
    return target

# update power data frame inlcude the NPS summary value
def nps_update(target,start_df,supply_list):

    print("Calculating NPS....")
    #columns = ['Instantanous','01 Minute','02 Minutes','10 Minutes', '20 Minutes', '30 Minutes']
    columns = ['01 Minute','10 Minutes','30 Minutes']
    rows = []

    for feeder in supply_list:
        rows.append(feeder)
    nps_df = pd.DataFrame(index=rows,columns=columns)

    for index, feeder in enumerate(supply_list):
        # Check if '01 Minute' value is numeric
        if pd.notna(pd.to_numeric(target.loc[feeder, '01 Minute'], errors='coerce')):
            nps_df.loc[feeder, '01 Minute'] = target.loc[feeder, '01 Minute'] / start_df.iloc[index, 5]
        if pd.notna(pd.to_numeric(target.loc[feeder, '10 Minutes'], errors='coerce')):
            nps_df.loc[feeder, '10 Minutes'] = target.loc[feeder, '10 Minutes'] / start_df.iloc[index, 5]
        if pd.notna(pd.to_numeric(target.loc[feeder, '30 Minutes'], errors='coerce')):
            nps_df.loc[feeder, '30 Minutes'] = target.loc[feeder, '30 Minutes'] / start_df.iloc[index, 5]
    
    combined_df = pd.concat([target, nps_df], axis=1)

    return combined_df

# update min max value
def minmax_update(simname,target,supply_list,mxndataframe,node_list):

    print("Caculating Minimum Maximum Value...")
    # Create a DataFrame to store the results
    
    columns=['Feeder', "Node", "Minimum", "Time at Min", "Maximum", "Time at Max"]
    rows = []
    for feeder in supply_list:
        rows.append(feeder)

    result_df = pd.DataFrame(index=rows,columns=columns)

    # Find minimum voltage for each node
    for index, feeder in enumerate(supply_list):
        columns=["Node","Minimum", "Time at Min", "Maximum", "Time at Max"]
        rows = []
        for node in node_list[index]:
            rows.append(node)

        temp_df = pd.DataFrame(index=rows,columns=columns)

        for node in node_list[index]:

            # Filter mxndataframe for the current feeder and node
            node_data = mxndataframe[(mxndataframe['Node'] == node)].reset_index(drop=True)
            
            if not node_data.empty:
                # Find the row with the minimum voltage
                temp_df.at[node,'Node'] = node_data['Node'][0]
                temp_df.at[node,'Minimum'] = node_data['Minimum Voltage (kV)'][0]
                temp_df.at[node,'Time at Min'] = node_data['Time at Min'][0]
                temp_df.at[node,'Maximum'] = node_data['Maximum Voltage (kV)'][0]
                temp_df.at[node,'Time at Max'] = node_data['Time at Max'][0]
        
        # update the main dataframe
        temp_df = temp_df.reset_index(drop=True)
        min_index = temp_df['Minimum'].idxmin()       
        result_df.at[feeder,'Feeder'] = feeder
        result_df.at[feeder,'Node'] = temp_df.at[min_index,'Node']
        result_df.at[feeder,'Minimum'] = temp_df.at[min_index,'Minimum']
        result_df.at[feeder,'Time at Min'] = temp_df.at[min_index,'Time at Min']
        result_df.at[feeder,'Maximum'] = temp_df.at[min_index,'Maximum']
        result_df.at[feeder,'Time at Max'] = temp_df.at[min_index,'Time at Max']

    # Selecting the relevant columns from result_df
    selected_columns = result_df[['Minimum', 'Maximum']]

    # Concatenate the selected columns to the 'target' DataFrame
    combined_df = pd.concat([target, selected_columns], axis = 1)

    return combined_df

# read individual d4 file
def feeder_reading_process(simname, supply_list,time_increment):

    # supply_list = ["SUP1","SUP2"]
    p_r_df = power_result(supply_list)
    i_r_df = current_result(supply_list)
    
    # create dataframe
    d4dataframe = []
    sumdataframe = []

    for feeder in supply_list:
        print(f"Processing {feeder} ...")
        filename = simname + "_" + feeder +".osop.d4"
        delimiter = '\\s+'
        columns = ["SupplyID","Type","Time","P_inst","Q_inst","Voltage","V_angle","Current","I_angle"]
        
        dtype_mapping = {"Time": str,}

        df = pd.read_csv(filename, delimiter=delimiter, names = columns, skiprows = 11,dtype = dtype_mapping)  # You might need to adjust the delimiter based on your file
        #df["Time"] = pd.to_datetime(df["Time"],format='%H:%M:%S')
        # Extracting parts from the string and formatting the 'Time' column
        df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")

        # data frame process
        df = d4_file_process(df,time_increment)
        # calculate sum value
        df_sum = d4_find_max(df)

        #update summary result
        p_r_df = power_update(p_r_df, df_sum, feeder)
        i_r_df = current_update(i_r_df, df_sum,feeder)

        # # Calculate rolling RMS
        # df['Rolling_RMS'] = df['Current'].rolling(window=12*time_increment).apply(lambda x: np.sqrt(np.mean(x**2)), raw=True)
        # calculate sum value
        sumdataframe.append(df_sum)
        d4dataframe.append(df)
    
    # power_data_sum = power_detail(d4dataframe,supply_list)
    # current_data_sum = current_detail(d4dataframe,supply_list)

    # columns = ['P-inst','P-1min','P-2min','P-2min','P-2min','P-2min','P-2min','P-2min','P-2min','P-2min']
    # rows = []
    return p_r_df, i_r_df, d4dataframe, sumdataframe

# doing invididual d4 file process and calculatoin
def d4_file_process(df, time_increment):

    df['S_inst'] = np.sqrt(df['P_inst']**2 + df['Q_inst']**2)

    window_sizes = {'1min': 60, '2min': 120, '10min': 600, '20min': 1200, '30min': 1800}

    for time_interval, window_size in window_sizes.items():
        df[f'P_{time_interval}'] = df['P_inst'].rolling(window=int(window_size / time_increment)).mean()
        df[f'Q_{time_interval}'] = df['Q_inst'].rolling(window=int(window_size / time_increment)).mean()
        df[f'S_{time_interval}'] = np.sqrt(df[f'P_{time_interval}']**2 + df[f'Q_{time_interval}']**2)

    df['I_Inst'] = df['Current'] # Current Duplicate

    for time_interval in [5, 10, 15, 20, 25, 30, 35, 40, 60, 120, 600, 1200, 1800]:
        column_name = f'I_{time_interval}s_RMS'
        df[column_name] = calculate_rolling_rms(df, 'Current', time_interval, time_increment)

    df['P_CosPhi'] = df['P_inst'] / df['S_inst']
    
    for time_interval in ['inst', '1min', '2min', '10min', '20min', '30min']:
        df[f'PF_{time_interval}'] = df[f'P_{time_interval}'] / df[f'S_{time_interval}']

    return df

# calculate rms
def calculate_rolling_rms(data, column, window_size, time_increment):
    return data[column].rolling(window=int(window_size / time_increment)).apply(lambda x: np.sqrt(np.mean(x**2)), raw=True)

# find maximum value and time of each d4 file
def d4_find_max(df):
    # # Insert two empty rows above the first row
    # df = pd.concat([pd.DataFrame(index=range(2)), df], ignore_index=True)
    sum_df = pd.DataFrame(columns=df.columns,index=range(4))
    sum_df.iloc[0, 0] = "Maximum Value (absolute for PF)"
    sum_df.iloc[1, 0] = "Maximum Value at Time"
    sum_df.iloc[2, 0] = "Minimum Value (absolute for PF)"
    sum_df.iloc[3, 0] = "Minimum Value at Time"


    if df.empty:
        sum_df.iloc[0, 1] = "DATA FOR THIS FEEDER IS NOT AVAILABLE"

    else:
        for column in df.columns[9:25]:
            if df[column].dtype in [int, float]:
                max_value = df[column].max()
                time_of_max = df.loc[df[column].idxmax(), 'Time']
                sum_df.at[0, column] = max_value
                sum_df.at[1, column] = time_of_max
                min_value = df[column].min()
                time_of_min = df.loc[df[column].idxmin(), 'Time']
                sum_df.at[2, column] = min_value
                sum_df.at[3, column] = time_of_min
        
        for column in df.columns[25:]:
            if df[column].dtype in [int, float]:
                # Check if the column has any non-NA values
                if df[column].dropna().empty:
                    time_of_max = None  # or handle this case as needed
                else:
                    max_value = abs(df[column]).max()
                    time_of_max = df.loc[abs(df[column]).idxmax(), 'Time']
                    sum_df.at[0, column] = max_value
                    sum_df.at[1, column] = time_of_max
                    min_value = abs(df[column]).min()
                    time_of_min = df.loc[abs(df[column]).idxmin(), 'Time']
                    sum_df.at[2, column] = min_value
                    sum_df.at[3, column] = time_of_min

    return sum_df

# read the mxn file and find the node voltage
def mxn_file_reading(simname):
    # Create an empty DataFrame with the specified columns
    columns = ["Node", "Minimum Voltage (kV)", "Time at Min", "Maximum Voltage (kV)", "Time at Max"]
    mxndataframe = pd.DataFrame(columns=columns)

    print(f"Processing {simname} ...")
    filename = simname + ".osop.mxn"
    

    # Specify column widths based on your file format
    colspecs = [(0, 16), (16, 38), (38, 58), (58, 73), (73, 120)]

    start_marker = "NODE VOLTAGES"
    end_marker = "MAXIMUM FEEDER"

    # Use pd.read_fwf to read the fixed-width file
    mxndataframe = pd.read_fwf(filename, colspecs=colspecs, header=None, names=columns, skiprows=2)

    # Identify the start and end indices of the relevant block
    start_index = mxndataframe.index[mxndataframe['Node'] == start_marker].tolist()[0] + 5 #(do not include NODE + ========line)
    end_index = mxndataframe.index[mxndataframe['Node'] == end_marker].tolist()[0]

    # Extract the relevant block
    mxndataframe = mxndataframe.iloc[start_index:end_index].reset_index(drop=True)

    # Strip leading and trailing spaces from all values
    mxndataframe = mxndataframe.map(lambda x: x.strip() if isinstance(x, str) else x)

    # Convert the time columns to the desired format
    time_columns = ["Time at Min", "Time at Max"]
    mxndataframe[time_columns] = mxndataframe[time_columns].map(convert_time_format)

    # Convert "Minimum Voltage (kV)" and "Maximum Voltage (kV)" to numeric
    numeric_columns = ["Minimum Voltage (kV)", "Maximum Voltage (kV)"]
    mxndataframe[numeric_columns] = mxndataframe[numeric_columns].apply(pd.to_numeric, errors='coerce')

    # Drop rows where all values are NaN or empty
    mxndataframe = mxndataframe.dropna(how='all')

    # flag = False

    # with open(filename) as fp:
    #     for line in fp:

    #         if line[:20].strip() == "NODE":
    #             flag = True
    #             continue
    #         if line[:9].strip() == "MAXIMUM":
    #             flag = False
    #             break

    #         if flag == True:
    #             if line[:20].strip() == "":
    #                 continue
    #             else:
    #                 node = line[:20].strip()
    #                 minvalue = line[21:37].strip()
    #                 tmin = line[38:55].strip()
    #                 maxvalue = line[56:71].strip()
    #                 tmax = line[72:90].strip()

    #                 data = [node,minvalue,tmin,maxvalue,tmax]

    #                 row_data = dict(zip(columns, data))
    #                 mxndataframe = mxndataframe.append(row_data, ignore_index=True)


            # Assuming the data in each line is separated by some delimiter (e.g., comma or tab)
            # data = line.strip().split('\t')  # Adjust the delimiter as needed

                    # Assuming the data has the same format as the columns
            #if len(data) == len(columns):
                        

    #df = pd.read_csv(filename, delimiter=delimiter, names = columns, skiprows = 11,dtype = dtype_mapping)  # You might need to adjust the delimiter based on your file
    #df["Time"] = pd.to_datetime(df["Time"],format='%H:%M:%S')
    # Extracting parts from the string and formatting the 'Time' column
    #df['Time'] = df['Time'].apply(lambda x: f"{int(x[1:3]):02d}:{int(x[3:5]):02d}:{int(x[5:]):02d}")
    
    return mxndataframe

# covert mxn time format to proper time format (ignore DAY)
def convert_time_format(time_str):

    if ':' not in time_str:
        return time_str  # Return the original string if ':' is not present

    # Split the time string into components
    days, time = time_str.split(':')
    
    # Split the time component into hours, minutes, and seconds
    hours, minutes, seconds = map(int, time.split('.'))

    # Convert to the desired format
    converted_time = f'{hours:02d}:{minutes:02d}:{seconds:02d}'

    return converted_time

# Table 3 creationsupply_list
def summary_info_power(supply_list,start_df,d4dataframe):
    print("Creating summary table for feeder station...")

    # Create a new DataFrame called start_sum_df with the same columns as start_df
    start_sum_df = pd.DataFrame(columns=start_df.columns)

    # Keep track of seen feeder stations
    feeder_dict = {}

    # Check feeder in supply_list one by one
    for feeder in supply_list:
        # Filter the start_df column 'OSLO feeder name' matching the feeder
        feeder_data = start_df[start_df['OSLO ID'] == feeder]

        # Check if 'Feeder Station' name in start_df has never appeared before
        feeder_station_name = feeder_data['Feeder Station Name'].iloc[0]
        if feeder_station_name not in feeder_dict:
            # If the feeder station is not in the dictionary, add it with the OSLO ID as a list
            feeder_dict[feeder_station_name] = [feeder]
            # If start_sum_df is empty, assign the columns from feeder_data
            if start_sum_df.empty:
                start_sum_df = feeder_data.copy()
            else:
                # Add the entire row information to start_sum_df
                start_sum_df = pd.concat([start_sum_df, feeder_data])
        else:
            # If the feeder station is already in the dictionary, append the OSLO ID to its list
            feeder_dict[feeder_station_name].append(feeder)
            # Update the set of seen feeder stations
            # seen_feeder_stations.add(feeder_data['Feeder Station Name'].iloc[0])
    
    # create summary result
    columns = ['Instantanous','01 Minute','02 Minutes','10 Minutes', '20 Minutes', '30 Minutes']
    row = list(feeder_dict.keys())
    # create summary result data frame
    s_r_df = pd.DataFrame(index = row, columns=columns)

    s_r_df,fsdataframe,fssum = feeder_station_sum(feeder_dict,d4dataframe,supply_list,s_r_df)

    return start_sum_df,s_r_df,fsdataframe,fssum,feeder_dict

# individual feeder staiton summary process
def feeder_station_sum(feeder_dict, d4dataframe, supply_list,s_r_df):
    fsdataframe = []
    fssum = []

    for station, oslo_list in feeder_dict.items():
        # define data frame for summary
        columns = ['Time', 'instP', 'instQ', 'instS', '1minP', '1minQ', '1minS', '2minP', '2minQ', '2minS',
                   '10minP', '10minQ', '10minS', '20minP', '20minQ', '20minS', '30minP', '30minQ', '30minS']
        df = pd.DataFrame(columns=columns)

        df['Time'] = d4dataframe[0]['Time']

        for time_interval in ['inst', '1min', '2min', '10min', '20min', '30min']:
            tempP_sum = sum(d4dataframe[supply_list.index(feeder)]['P_' + time_interval] for feeder in oslo_list)
            tempQ_sum = sum(d4dataframe[supply_list.index(feeder)]['Q_' + time_interval] for feeder in oslo_list)
            tempS_sum = np.sqrt(tempP_sum**2 + tempQ_sum**2)

            df.loc[:, f'{time_interval}P'] = tempP_sum
            df.loc[:, f'{time_interval}Q'] = tempQ_sum
            df.loc[:, f'{time_interval}S'] = tempS_sum

        # calculate sum value
        df_sum = fs_find_max(df)
        
        # update result
        index = 3
        for column in s_r_df.columns:
            s_r_df.at[station,column] = df_sum.iloc[0,index]
            index = index + 3

        fsdataframe.append(df)
        fssum.append(df_sum)

    return s_r_df,fsdataframe,fssum

# find maximum value and time of each feeder station
def fs_find_max(df):
    # # Insert two empty rows above the first row
    # df = pd.concat([pd.DataFrame(index=range(2)), df], ignore_index=True)
    sum_df = pd.DataFrame(columns=df.columns,index=range(4))
    sum_df.iloc[0, 0] = "Maximum Value (absolute for PF)"
    sum_df.iloc[1, 0] = "Maximum Value at Time"
    sum_df.iloc[2, 0] = "Minimum Value (absolute for PF)"
    sum_df.iloc[3, 0] = "Minimum Value at Time"

    for column in df.columns[1:]:
        df[column] = pd.to_numeric(df[column], errors='coerce') # convert the column to number
        if np.issubdtype(df[column].dtype, np.number):
            # Check if the entire column is NaN
            if df[column].isna().all():
                sum_df.at[0, column] = "N/A"
            else:
                max_value = df[column].max()
                time_of_max = df.loc[df[column].idxmax(), 'Time']
                sum_df.at[0, column] = max_value
                sum_df.at[1, column] = time_of_max
                min_value = df[column].min()
                time_of_min = df.loc[df[column].idxmin(), 'Time']
                sum_df.at[2, column] = min_value
                sum_df.at[3, column] = time_of_min

    # for column in df.columns[25:]:
    #     if df[column].dtype in [int, float]:
    #         max_value = abs(df[column]).max()
    #         time_of_max = df.loc[abs(df[column]).idxmax(), 'Time']
    #         sum_df.at[0, column] = max_value
    #         sum_df.at[1, column] = time_of_max
    #         min_value = abs(df[column]).min()
    #         time_of_min = df.loc[abs(df[column]).idxmin(), 'Time']
    #         sum_df.at[2, column] = min_value
    #         sum_df.at[3, column] = time_of_min
    return sum_df

if __name__ == "__main__":
    # Add your debugging code here
    simname = "test_model_1"  # Provide a simulation name or adjust as needed
    main_option = "1"  # Adjust as needed
    time_start = "0070000"  # Adjust as needed
    time_end = "0080000"  # Adjust as needed
    option_select = "3"  # Adjust as needed
    text_input = "AC_01_Power"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = None  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)

