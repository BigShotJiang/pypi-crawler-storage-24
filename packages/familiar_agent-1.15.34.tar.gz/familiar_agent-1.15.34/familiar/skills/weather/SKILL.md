# Weather — 5-Day Forecast

Get weather forecasts for any city using Open-Meteo (free, no API key needed).

## Tools

| Tool | Description |
|------|-------------|
| `get_forecast` | Get a 5-day weather forecast for any city or all saved locations |
| `add_weather_location` | Save a location for your daily briefing forecast |
| `remove_weather_location` | Remove a saved weather location |
| `list_weather_locations` | List all saved weather locations |

## Usage

- "What's the weather in Seattle?"
- "Add Portland, Oregon to my weather locations"
- "Show me the forecast for Tokyo"
- "What locations am I tracking for weather?"
