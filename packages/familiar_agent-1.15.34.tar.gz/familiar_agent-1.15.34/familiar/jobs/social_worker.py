# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Social Worker job class — case management, advocacy, resource navigation."""

from . import JobClass, register_job_class

SOCIAL_WORKER = JobClass(
    key="social_worker",
    name="Social Worker",
    icon="fa-clipboard",
    description="Case management, advocacy, and resource navigation",
    prompt_fragment="""You are operating in Social Worker mode. Your focus areas:
- **Active listening**: Validate feelings before problem-solving. Use reflective statements.
- **Resource navigation**: Help find community resources, benefits, housing, food banks, support groups.
- **Case tracking**: Use notes and memory to track ongoing situations, follow up on previous concerns.
- **Crisis awareness**: Recognize distress signals. Offer grounding techniques. Suggest crisis hotlines when appropriate (988 Suicide & Crisis Lifeline, SAMHSA 1-800-662-4357).
- **Strengths-based**: Focus on what the person CAN do, not deficits. Empower self-advocacy.
- **Boundaries**: You are an AI assistant, not a licensed professional. Be clear about this when appropriate.
- **Warm handoffs**: When referring to services, explain what to expect, help prepare questions.
- **Follow-up**: Proactively ask about previous concerns in future conversations.
- **Case notes**: Document interactions carefully. Track status changes and outcomes.
- **Safety planning**: When risk is identified, help create concrete safety plans with resources.""",
    skill_weights={
        "web_search": 0.8,
        "remember": 0.9,
        "recall": 0.9,
        "query_chairman": 0.7,
        "search_knowledge": 0.7,
        "write_note": 0.9,
        "search_notes": 0.8,
        "send_email": 0.6,
        "calendar_create": 0.7,
        "calendar_list": 0.6,
        "contact_add": 0.7,
        "contact_search": 0.7,
        "web_read": 0.7,
    },
    species_flavor={
        "fox": "Your fox's warmth becomes gentle advocacy — quick to find resources, always checking in.",
        "owl": "Your owl's wisdom becomes careful case assessment — thorough, evidence-based guidance.",
        "cat": "Your cat's independence becomes empowerment coaching — teaching self-advocacy skills.",
        "dragon": (
            "Your dragon's protectiveness becomes fierce advocacy — standing up for those in need."
        ),
        "wolf": (
            "Your wolf's loyalty becomes steadfast support — always following up, never forgetting."
        ),
        "frog": (
            "Your frog's adaptability becomes creative problem-solving"
            " — finding unconventional resources."
        ),
    },
    recommended_connects=[
        "email",
        "calendar",
        "joplin",
        "todoist",
        "healthcare",
        "kobo",
        "open_referral",
    ],
    proactive_focus=[
        "check-in on ongoing concerns",
        "follow up on referrals",
        "remind about appointments",
        "review active cases for overdue follow-ups",
    ],
    workspace={
        "label": "Case Management",
        "icon": "fa-clipboard",
        "description": (
            "Your case management hub — track cases, resources, notes, and crisis interventions."
        ),
        "overview": {
            "cards": [
                {
                    "key": "server_setup_cta",
                    "type": "cta",
                    "icon": "fa-clipboard",
                    "color": "#60a5fa",
                    "label": "Case Management Server",
                    "message": (
                        "Set up your own secure server — Joplin for case notes,"
                        " Nextcloud for file sharing with clients, and GoToSocial"
                        " for community outreach. Your data stays on your machine."
                    ),
                    "button_label": "Set Up My Server",
                    "button_action": "full_server_setup",
                    "source": "server",
                    "show_when": "needs_setup",
                    "service_keys": ["joplin", "nextcloud", "gotosocial"],
                },
                {
                    "key": "casework_services",
                    "type": "service_status",
                    "icon": "fa-clipboard",
                    "color": "#60a5fa",
                    "label": "Case Management Services",
                    "source": "server",
                    "service_keys": [
                        "joplin",
                        "nextcloud",
                        "gotosocial",
                    ],
                },
                {
                    "key": "active_cases",
                    "label": "Active Cases",
                    "icon": "fa-folder-open",
                    "color": "#60a5fa",
                    "source": "cases",
                    "metric": "cases.active_count",
                    "format": "number",
                },
                {
                    "key": "intake_cases",
                    "label": "In Intake",
                    "icon": "fa-inbox",
                    "color": "#fbbf24",
                    "source": "cases",
                    "metric": "cases.intake_count",
                    "format": "number",
                },
                {
                    "key": "follow_up_needed",
                    "label": "Need Follow-Up",
                    "icon": "fa-phone-flip",
                    "color": "#f87171",
                    "source": "cases",
                    "metric": "cases.followup_count",
                    "format": "number",
                },
                {
                    "key": "crisis_this_week",
                    "label": "Crisis This Week",
                    "icon": "fa-triangle-exclamation",
                    "color": "#ef4444",
                    "source": "cases",
                    "metric": "crisis_week_count",
                    "format": "number",
                },
                {
                    "key": "total_resources",
                    "label": "Resources",
                    "icon": "fa-map-location-dot",
                    "color": "#4ade80",
                    "source": "cases",
                    "metric": "resources.count",
                    "format": "number",
                },
                {
                    "key": "total_notes",
                    "label": "Case Notes",
                    "icon": "fa-file-lines",
                    "color": "#c084fc",
                    "source": "cases",
                    "metric": "notes.count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "cases",
                "label": "Cases",
                "icon": "fa-folder-open",
                "type": "pipeline",
                "source": "cases",
                "source_key": "cases",
                "empty_message": "No cases yet. Tell me about a new client and I'll set up their case file!",
                "service_key": "joplin",
                "stages": ["intake", "assessment", "active", "follow_up", "closed"],
                "stage_field": "status",
                "card_title_field": "name",
                "card_subtitle_field": "category",
                "card_badge_field": "priority",
                "card_badge_format": "text",
            },
            {
                "key": "resources",
                "label": "Resources",
                "icon": "fa-map-location-dot",
                "type": "table",
                "source": "cases",
                "source_key": "resources",
                "empty_message": "No resources cataloged yet. Tell me about shelters, food banks, or services in your area and I'll build your directory!",
                "service_key": "nextcloud",
                "columns": [
                    {"key": "name", "label": "Resource", "type": "text", "sortable": True},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {"key": "phone", "label": "Phone", "type": "text", "sortable": False},
                    {"key": "address", "label": "Address", "type": "text", "sortable": False},
                    {"key": "notes", "label": "Notes", "type": "text", "sortable": False},
                ],
                "default_sort": "category",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "refer",
                        "label": "Refer",
                        "icon": "fa-share",
                        "mode": "agent",
                        "prompt_template": (
                            "Help me prepare a referral to {name}."
                            " What should the client expect when they contact them?"
                        ),
                    },
                ],
            },
            {
                "key": "case_notes",
                "label": "Notes",
                "icon": "fa-file-lines",
                "type": "table",
                "source": "cases",
                "source_key": "notes",
                "empty_message": "No case notes yet. Notes you write during sessions will appear here automatically!",
                "service_key": "joplin",
                "columns": [
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                    {"key": "case_name", "label": "Case", "type": "text", "sortable": True},
                    {"key": "category", "label": "Type", "type": "badge", "sortable": True},
                    {"key": "content", "label": "Note", "type": "text", "sortable": False},
                ],
                "default_sort": "date",
                "default_sort_dir": "desc",
                "row_actions": [],
            },
            {
                "key": "crisis_log",
                "label": "Crisis Log",
                "icon": "fa-triangle-exclamation",
                "type": "table",
                "source": "cases",
                "source_key": "crisis_log",
                "empty_message": "No crisis events logged. If a crisis occurs, I'll help you document it properly here.",
                "columns": [
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                    {"key": "case_name", "label": "Case", "type": "text", "sortable": True},
                    {"key": "severity", "label": "Severity", "type": "badge", "sortable": True},
                    {"key": "summary", "label": "Summary", "type": "text", "sortable": False},
                    {"key": "outcome", "label": "Outcome", "type": "text", "sortable": False},
                ],
                "default_sort": "date",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "follow_up",
                        "label": "Follow Up",
                        "icon": "fa-phone",
                        "mode": "agent",
                        "prompt_template": (
                            "I need to follow up on the crisis event for {case_name}"
                            " on {date}. Summary: {summary}. Help me plan my follow-up."
                        ),
                    },
                ],
            },
        ],
        "quick_actions": [
            {
                "key": "new_case",
                "label": "New Case",
                "icon": "fa-folder-plus",
                "mode": "agent",
                "prompt": "I need to open a new case. Help me capture the intake information.",
            },
            {
                "key": "find_resources",
                "label": "Find Resources",
                "icon": "fa-magnifying-glass-location",
                "mode": "agent",
                "prompt": (
                    "Help me find community resources. What type of resource"
                    " is needed? (housing, food, mental health, employment, etc.)"
                ),
            },
            {
                "key": "case_note",
                "label": "Case Note",
                "icon": "fa-pen-to-square",
                "mode": "agent",
                "prompt": "I need to add a case note. Which case is this for?",
            },
            {
                "key": "crisis_hotlines",
                "label": "Crisis Hotlines",
                "icon": "fa-phone-volume",
                "mode": "agent",
                "prompt": (
                    "List the key crisis hotlines and resources:\n"
                    "- 988 Suicide & Crisis Lifeline\n"
                    "- SAMHSA Helpline: 1-800-662-4357\n"
                    "- Crisis Text Line: Text HOME to 741741\n"
                    "- National Domestic Violence Hotline: 1-800-799-7233\n"
                    "- Childhelp National Child Abuse Hotline: 1-800-422-4453\n\n"
                    "Is there a specific situation I can help with?"
                ),
            },
            {
                "key": "check_follow_ups",
                "label": "Check Follow-Ups",
                "icon": "fa-clipboard-check",
                "mode": "agent",
                "prompt": (
                    "Review my active cases and tell me which ones"
                    " are overdue for a follow-up or check-in."
                ),
            },
            {
                "key": "safety_plan",
                "label": "Safety Plan",
                "icon": "fa-shield-heart",
                "mode": "agent",
                "prompt": (
                    "Help me create a safety plan. Guide me through"
                    " the standard safety planning steps."
                ),
            },
        ],
    },
)

register_job_class(SOCIAL_WORKER)
