# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Business Buddy job class — productivity, scheduling, professional comms."""

from . import JobClass, register_job_class

BUSINESS_BUDDY = JobClass(
    key="business_buddy",
    name="Business Buddy",
    icon="fa-briefcase",
    description="Productivity, scheduling, and professional communication",
    prompt_fragment="""You are operating in Business Buddy mode. Your focus areas:
- **Professional tone**: Default to clear, concise business communication.
- **Calendar mastery**: Proactively manage scheduling conflicts, prep for meetings.
- **Email drafting**: Help compose professional emails with appropriate tone.
- **Task management**: Track action items, deadlines, deliverables.
- **Meeting prep**: Summarize relevant context before appointments.
- **Time awareness**: Respect business hours and deadlines.""",
    skill_weights={
        "calendar_create": 0.9,
        "calendar_list": 0.8,
        "send_email": 0.8,
        "draft_email": 0.8,
        "search_emails": 0.7,
        "write_note": 0.7,
        "search_notes": 0.6,
        "web_search": 0.5,
        "remember": 0.6,
        "recall": 0.6,
        "query_chairman": 0.7,
    },
    species_flavor={
        "fox": "Your fox brings energetic professionalism — quick replies, smart scheduling.",
        "owl": "Your owl brings methodical planning — nothing falls through the cracks.",
        "cat": "Your cat brings elegant efficiency — minimal effort, maximum impact.",
        "dragon": "Your dragon brings commanding presence — decisive communication.",
        "wolf": "Your wolf brings team coordination — keeping everyone aligned.",
        "frog": "Your frog brings flexibility — adapting plans when priorities shift.",
    },
    recommended_connects=["email", "calendar", "todoist", "hubspot", "stripe", "quickbooks", "clockify", "mailerlite"],
    proactive_focus=["upcoming meetings", "pending deadlines", "unanswered emails"],
    workspace={
        "label": "Command Center",
        "icon": "fa-gauge-high",
        "description": "Your daily command center — schedule, tasks, and communications.",
        "overview": {
            "cards": [
                {
                    "key": "server_setup_cta",
                    "type": "cta",
                    "icon": "fa-gauge-high",
                    "color": "#60a5fa",
                    "label": "Business Server",
                    "message": (
                        "Set up your own business server — Gitea for code and"
                        " documents, Nextcloud for file sharing, Joplin for notes,"
                        " and GoToSocial for your business presence."
                        " One click, all private."
                    ),
                    "button_label": "Set Up Business Server",
                    "button_action": "full_server_setup",
                    "source": "server",
                    "show_when": "needs_setup",
                    "service_keys": ["gitea", "nextcloud", "joplin", "gotosocial"],
                },
                {
                    "key": "business_services",
                    "type": "service_status",
                    "icon": "fa-gauge-high",
                    "color": "#60a5fa",
                    "label": "Business Services",
                    "source": "server",
                    "service_keys": [
                        "gitea",
                        "nextcloud",
                        "joplin",
                        "gotosocial",
                    ],
                },
                {
                    "key": "today_events",
                    "label": "Today's Events",
                    "icon": "fa-calendar-day",
                    "color": "#60a5fa",
                    "source": "calendar",
                    "metric": "today_count",
                    "format": "number",
                },
                {
                    "key": "open_tasks",
                    "label": "Open Tasks",
                    "icon": "fa-list-check",
                    "color": "#4ade80",
                    "source": "tasks",
                    "metric": "pending_count",
                    "format": "number",
                },
                {
                    "key": "overdue",
                    "label": "Overdue",
                    "icon": "fa-triangle-exclamation",
                    "color": "#f87171",
                    "source": "tasks",
                    "metric": "overdue_count",
                    "format": "number",
                },
                {
                    "key": "unread_emails",
                    "label": "Unread Emails",
                    "icon": "fa-envelope",
                    "color": "#fbbf24",
                    "source": "email",
                    "metric": "unread_count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "today",
                "label": "Today",
                "icon": "fa-calendar-day",
                "type": "table",
                "source": "calendar",
                "source_key": "events",
                "empty_message": "No events today. Enjoy the free time!",
                "columns": [
                    {"key": "time", "label": "Time", "type": "text", "sortable": True},
                    {"key": "summary", "label": "Event", "type": "text", "sortable": True},
                    {"key": "location", "label": "Location", "type": "text", "sortable": False},
                    {
                        "key": "attendee_count",
                        "label": "Attendees",
                        "type": "number",
                        "sortable": True,
                    },
                ],
                "default_sort": "time",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "running_late",
                        "label": "Running Late",
                        "icon": "fa-clock",
                        "mode": "agent",
                        "prompt_template": "I'm running late to {summary}."
                        " Draft a quick message to let attendees know.",
                    },
                ],
            },
            {
                "key": "tasks",
                "label": "Tasks",
                "icon": "fa-list-check",
                "type": "table",
                "source": "tasks",
                "source_key": "tasks",
                "empty_message": "All clear — no open tasks!",
                "columns": [
                    {"key": "title", "label": "Title", "type": "text", "sortable": True},
                    {"key": "priority", "label": "Priority", "type": "badge", "sortable": True},
                    {"key": "due", "label": "Due", "type": "date", "sortable": True},
                    {"key": "category", "label": "Category", "type": "text", "sortable": True},
                ],
                "default_sort": "due",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "complete",
                        "label": "Complete",
                        "icon": "fa-check",
                        "mode": "tool",
                        "tool": "complete_task",
                    },
                ],
            },
            {
                "key": "email_summary",
                "label": "Email",
                "icon": "fa-envelope",
                "type": "summary",
                "source": "email",
                "stats": [
                    {
                        "key": "urgent",
                        "label": "Urgent",
                        "icon": "fa-fire",
                        "color": "#f87171",
                        "metric": "urgent_count",
                        "format": "number",
                    },
                    {
                        "key": "needs_action",
                        "label": "Need Action",
                        "icon": "fa-reply",
                        "color": "#fbbf24",
                        "metric": "action_count",
                        "format": "number",
                    },
                    {
                        "key": "fyi",
                        "label": "FYI",
                        "icon": "fa-info-circle",
                        "color": "#60a5fa",
                        "metric": "fyi_count",
                        "format": "number",
                    },
                    {
                        "key": "total_unread",
                        "label": "Total Unread",
                        "icon": "fa-inbox",
                        "color": "#c084fc",
                        "metric": "unread_count",
                        "format": "number",
                    },
                ],
            },
        ],
        "quick_actions": [
            {
                "key": "morning_briefing",
                "label": "Morning Briefing",
                "icon": "fa-sun",
                "mode": "agent",
                "prompt": "Give me my morning briefing — what's on the calendar today,"
                " top tasks, and any urgent emails.",
            },
            {
                "key": "sort_inbox",
                "label": "Sort Inbox",
                "icon": "fa-inbox",
                "mode": "agent",
                "prompt": "Triage my inbox — categorize recent emails by urgency.",
            },
            {
                "key": "check_deadlines",
                "label": "Check Deadlines",
                "icon": "fa-clock",
                "mode": "agent",
                "prompt": "What deadlines are coming up this week?",
            },
            {
                "key": "add_task",
                "label": "Add Task",
                "icon": "fa-plus",
                "mode": "agent",
                "prompt": "I need to add a new task.",
            },
        ],
    },
)

register_job_class(BUSINESS_BUDDY)
