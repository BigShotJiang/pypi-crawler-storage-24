# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Nonprofit Director job class — donor CRM, grants, bookkeeping, board reporting."""

from . import JobClass, register_job_class

NONPROFIT_DIRECTOR = JobClass(
    key="nonprofit_director",
    name="Nonprofit Director",
    icon="fa-building-columns",
    description="Donor management, grant tracking, bookkeeping, and board reporting",
    prompt_fragment="""You are operating in Nonprofit Director mode. Your focus areas:
- **Donor relations**: Track donations, generate thank-you letters, manage donor history.
- **Grant management**: Track grant pipeline from prospect through completion.
- **Financial oversight**: Monitor income, expenses, and fund balances. Prepare 990 data.
- **Board reporting**: Generate board packets with financial summaries and program updates.
- **Compliance**: Track deadlines for filings, grant reports, and donor acknowledgments.
- **Stewardship**: Flag donors needing follow-up, track engagement touchpoints.""",
    skill_weights={
        "donor_add": 0.9,
        "donor_details": 0.9,
        "donor_search": 0.8,
        "log_donation": 0.9,
        "grant_add": 0.8,
        "grant_update": 0.8,
        "grant_list": 0.7,
        "bookkeeping_add": 0.8,
        "bookkeeping_summary": 0.8,
        "board_packet": 0.9,
        "export_990": 0.7,
        "write_note": 0.7,
        "search_notes": 0.6,
        "send_email": 0.7,
        "draft_email": 0.7,
        "calendar_create": 0.6,
        "remember": 0.6,
        "recall": 0.6,
        "query_chairman": 0.7,
    },
    species_flavor={
        "fox": "Your fox brings charm to donor relations — warm thank-yous, quick follow-ups.",
        "owl": "Your owl brings meticulous oversight — every grant deadline tracked, every dollar accounted.",
        "cat": "Your cat brings quiet competence — elegant board packets, efficient operations.",
        "dragon": "Your dragon brings commanding stewardship — bold fundraising, decisive budgeting.",
        "wolf": "Your wolf brings loyal partnership — building lasting donor relationships.",
        "frog": "Your frog brings creative fundraising — finding grants others miss.",
    },
    recommended_connects=[
        "email",
        "calendar",
        "todoist",
        "hubspot",
        "stripe",
        "mailerlite",
        "civicrm",
        "globalgiving",
    ],
    proactive_focus=[
        "donors needing thank-you letters",
        "upcoming grant deadlines",
        "monthly financial reconciliation",
        "board meeting preparation",
    ],
    workspace={
        "label": "Nonprofit HQ",
        "icon": "fa-building-columns",
        "description": (
            "Your nonprofit command center. Track donors, manage grants,"
            " keep your books, and prepare for board meetings — all in one place."
            " Just tell me what you need in the chat below."
        ),
        "overview": {
            "cards": [
                {
                    "key": "server_setup_cta",
                    "type": "cta",
                    "icon": "fa-building-columns",
                    "color": "#60a5fa",
                    "label": "Nonprofit Server",
                    "message": (
                        "Set up your nonprofit's own private server —"
                        " Joplin for board minutes and notes, Nextcloud"
                        " for sharing files with your board and team."
                        " Everything stays on your machine, fully private."
                    ),
                    "button_label": "Set Up Nonprofit Server",
                    "button_action": "full_server_setup",
                    "source": "server",
                    "show_when": "needs_setup",
                    "service_keys": ["joplin", "nextcloud"],
                },
                {
                    "key": "nonprofit_services",
                    "type": "service_status",
                    "icon": "fa-building-columns",
                    "color": "#60a5fa",
                    "label": "Nonprofit Services",
                    "source": "server",
                    "service_keys": [
                        "joplin",
                        "nextcloud",
                    ],
                },
                {
                    "key": "total_donors",
                    "label": "Total Donors",
                    "icon": "fa-users",
                    "color": "#4ade80",
                    "source": "nonprofit",
                    "metric": "donors.count",
                    "format": "number",
                },
                {
                    "key": "ytd_raised",
                    "label": "YTD Raised",
                    "icon": "fa-dollar-sign",
                    "color": "#fbbf24",
                    "source": "bookkeeping",
                    "metric": "ytd_income",
                    "format": "currency",
                },
                {
                    "key": "active_grants",
                    "label": "Active Grants",
                    "icon": "fa-file-contract",
                    "color": "#60a5fa",
                    "source": "nonprofit",
                    "metric": "grants.active_count",
                    "format": "number",
                },
                {
                    "key": "needs_thanks",
                    "label": "Need Thank You",
                    "icon": "fa-envelope-open-text",
                    "color": "#f87171",
                    "source": "nonprofit",
                    "metric": "donors.needs_thanks_count",
                    "format": "number",
                },
                {
                    "key": "open_tasks",
                    "label": "Open Tasks",
                    "icon": "fa-list-check",
                    "color": "#c084fc",
                    "source": "tasks",
                    "metric": "pending_count",
                    "format": "number",
                },
                {
                    "key": "upcoming_deadlines",
                    "label": "Upcoming Deadlines",
                    "icon": "fa-clock",
                    "color": "#fb923c",
                    "source": "nonprofit",
                    "metric": "grants.deadline_count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "donors",
                "label": "Donors",
                "icon": "fa-users",
                "type": "table",
                "source": "nonprofit",
                "source_key": "donors",
                "empty_message": (
                    "No donors yet. To get started, just tell me something like"
                    " \"Jane Smith donated $100 today\" and I'll create her"
                    " donor record automatically!"
                ),
                "columns": [
                    {"key": "name", "label": "Name", "type": "text", "sortable": True},
                    {"key": "email", "label": "Email", "type": "text", "sortable": True},
                    {
                        "key": "total_given",
                        "label": "Total Given",
                        "type": "currency",
                        "sortable": True,
                    },
                    {
                        "key": "last_gift",
                        "label": "Last Gift",
                        "type": "date",
                        "sortable": True,
                    },
                    {
                        "key": "interactions_count",
                        "label": "Interactions",
                        "type": "number",
                        "sortable": True,
                    },
                ],
                "default_sort": "total_given",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "details",
                        "label": "Details",
                        "icon": "fa-eye",
                        "mode": "tool",
                        "tool": "donor_details",
                    },
                    {
                        "key": "thank",
                        "label": "Thank",
                        "icon": "fa-envelope",
                        "mode": "agent",
                        "prompt_template": "Draft a thank-you email to {name} at {email}"
                        " for their generous support.",
                    },
                ],
            },
            {
                "key": "grants",
                "label": "Grant Pipeline",
                "icon": "fa-file-contract",
                "type": "pipeline",
                "source": "nonprofit",
                "source_key": "grants",
                "empty_message": (
                    "No grants tracked yet. Tell me about a grant you're"
                    " pursuing — the funder name, amount, and deadline —"
                    " and I'll track it through your pipeline from prospect"
                    " to completion."
                ),
                "stages": ["prospect", "applied", "awarded", "declined", "completed"],
                "stage_field": "status",
                "card_title_field": "name",
                "card_subtitle_field": "funder",
                "card_badge_field": "amount",
                "card_badge_format": "currency",
            },
            {
                "key": "financials",
                "label": "Financials",
                "icon": "fa-chart-pie",
                "type": "summary",
                "source": "bookkeeping",
                "stats": [
                    {
                        "key": "ytd_income",
                        "label": "YTD Income",
                        "icon": "fa-arrow-up",
                        "color": "#4ade80",
                        "metric": "ytd_income",
                        "format": "currency",
                    },
                    {
                        "key": "ytd_expense",
                        "label": "YTD Expenses",
                        "icon": "fa-arrow-down",
                        "color": "#f87171",
                        "metric": "ytd_expense",
                        "format": "currency",
                    },
                    {
                        "key": "ytd_net",
                        "label": "Net Position",
                        "icon": "fa-scale-balanced",
                        "color": "#60a5fa",
                        "metric": "ytd_net",
                        "format": "currency",
                    },
                    {
                        "key": "donor_revenue",
                        "label": "Donor Revenue",
                        "icon": "fa-hand-holding-heart",
                        "color": "#fbbf24",
                        "metric": "donor_revenue",
                        "format": "currency",
                    },
                    {
                        "key": "grant_revenue",
                        "label": "Grant Revenue",
                        "icon": "fa-file-invoice-dollar",
                        "color": "#c084fc",
                        "metric": "grant_revenue",
                        "format": "currency",
                    },
                    {
                        "key": "transaction_count",
                        "label": "Transactions",
                        "icon": "fa-receipt",
                        "color": "#fb923c",
                        "metric": "transaction_count",
                        "format": "number",
                    },
                ],
            },
            {
                "key": "notes",
                "label": "Notes",
                "icon": "fa-sticky-note",
                "type": "table",
                "source": "nonprofit",
                "source_key": "notes",
                "empty_message": (
                    "No notes yet. Try saying \"take a note\" in chat —"
                    " board meeting minutes, planning notes, and memos"
                    " will all be organized here."
                ),
                "service_key": "joplin",
                "columns": [
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {"key": "content", "label": "Content", "type": "text", "sortable": False},
                ],
                "default_sort": "date",
                "default_sort_dir": "desc",
                "row_actions": [],
            },
        ],
        "quick_actions": [
            {
                "key": "log_donation",
                "label": "Log Donation",
                "icon": "fa-hand-holding-dollar",
                "mode": "agent",
                "prompt": (
                    "I received a donation and need to log it."
                    " Ask me for the donor's name, amount, date,"
                    " and whether it's restricted or unrestricted."
                ),
            },
            {
                "key": "thank_you",
                "label": "Thank You Letters",
                "icon": "fa-envelope-open-text",
                "mode": "agent",
                "prompt": (
                    "Which donors need thank-you letters?"
                    " Show me anyone who gave recently but hasn't"
                    " been thanked yet, and help me draft the letters."
                ),
            },
            {
                "key": "add_grant",
                "label": "Track Grant",
                "icon": "fa-file-contract",
                "mode": "agent",
                "prompt": (
                    "I found a grant opportunity I want to track."
                    " Ask me for the funder, grant name, amount,"
                    " deadline, and any requirements."
                ),
            },
            {
                "key": "board_packet",
                "label": "Board Packet",
                "icon": "fa-file-export",
                "mode": "agent",
                "prompt": (
                    "I need to prepare a board packet."
                    " Generate a summary with financials,"
                    " recent donations, grant status updates,"
                    " and any items needing board approval."
                ),
            },
            {
                "key": "grant_deadlines",
                "label": "Upcoming Deadlines",
                "icon": "fa-calendar-check",
                "mode": "agent",
                "prompt": (
                    "What deadlines are coming up?"
                    " Show me grant deadlines, report due dates,"
                    " and donor acknowledgment timelines."
                ),
            },
            {
                "key": "quick_note",
                "label": "Quick Note",
                "icon": "fa-pen",
                "mode": "agent",
                "prompt": (
                    "I want to jot down a quick note."
                    " It could be from a meeting, a phone call,"
                    " or just something I need to remember."
                ),
            },
            {
                "key": "export_990",
                "label": "990 Data Export",
                "icon": "fa-file-invoice",
                "mode": "agent",
                "prompt": (
                    "I need to prepare data for my 990 filing."
                    " Pull together income, expenses, donor counts,"
                    " and program spending for the fiscal year."
                ),
            },
        ],
    },
)

register_job_class(NONPROFIT_DIRECTOR)
