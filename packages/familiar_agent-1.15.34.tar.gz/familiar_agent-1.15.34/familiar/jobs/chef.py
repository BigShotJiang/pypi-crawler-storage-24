# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Chef job class — recipe management, menu creation, cost tracking, kitchen operations."""

from . import JobClass, register_job_class

CHEF = JobClass(
    key="chef",
    name="Chef",
    icon="fa-utensils",
    description="Recipe management, menu creation, cost tracking, and kitchen operations",
    prompt_fragment="""You are operating in Chef mode — a professional kitchen management assistant. Your focus areas:
- **Recipe management**: Maintain a detailed recipe database with ingredients, quantities, methods, plating notes, and cost-per-serving breakdowns. Scale recipes up/down precisely.
- **Menu creation**: Design menus (dinner, lunch, tasting, seasonal, catering) with course flow, dietary considerations, and cost analysis. Track menu item profitability.
- **Cost tracking**: Monitor food cost percentages, plate costs, waste, and margins. Flag items running over target cost. Track invoices against budget.
- **Vendor management**: Maintain supplier contacts, order history, pricing, lead times. Compare vendor pricing. Track delivery schedules.
- **Scheduling & payroll**: Manage staff shifts, labor cost tracking, overtime alerts. Help with weekly schedule planning around covers and events.
- **Inventory**: Track ingredient stock levels, par levels, shelf life. Flag items approaching expiry or below reorder point.
- **Mise en place**: Help with prep lists, production schedules, and station assignments for service.
- **Compliance**: Track food safety logs, temperature records, health inspection prep, allergen documentation.""",
    skill_weights={
        "bookkeeping_add": 0.9,
        "bookkeeping_summary": 0.9,
        "write_note": 0.8,
        "search_notes": 0.8,
        "calendar_create": 0.8,
        "calendar_list": 0.7,
        "send_email": 0.7,
        "draft_email": 0.7,
        "contact_add": 0.7,
        "contact_search": 0.7,
        "web_search": 0.6,
        "web_read": 0.6,
        "remember": 0.8,
        "recall": 0.8,
        "query_chairman": 0.7,
    },
    species_flavor={
        "fox": (
            "Your fox brings flair to the kitchen — sniffing out the best suppliers,"
            " charming front-of-house, and improvising when the walk-in surprises you."
        ),
        "owl": (
            "Your owl brings precision to every plate — exact measurements,"
            " meticulous costing, and food safety protocols followed to the letter."
        ),
        "cat": (
            "Your cat brings effortless elegance — refined plating, curated menus,"
            " and an instinct for what will sell."
        ),
        "dragon": (
            "Your dragon brings heat and intensity — commanding the pass,"
            " driving service, and keeping costs in line with fire."
        ),
        "wolf": (
            "Your wolf brings team loyalty — building a tight brigade,"
            " covering stations, and never leaving a ticket behind."
        ),
        "frog": (
            "Your frog brings creative leaps — unexpected flavor pairings,"
            " seasonal pivots, and the joy of experimentation."
        ),
    },
    recommended_connects=["email", "calendar", "spoonacular", "mealie", "square"],
    proactive_focus=[
        "check inventory against upcoming menu needs",
        "review food cost percentages weekly",
        "remind about vendor order deadlines",
        "flag upcoming staff schedule gaps",
        "prep list for tomorrow's service",
    ],
    workspace={
        "label": "Kitchen HQ",
        "icon": "fa-utensils",
        "description": (
            "Your kitchen command center — recipes, menus, costs, vendors, and scheduling."
        ),
        "overview": {
            "cards": [
                {
                    "key": "server_setup_cta",
                    "type": "cta",
                    "icon": "fa-utensils",
                    "color": "#4ade80",
                    "label": "Kitchen Server",
                    "message": (
                        "Set up your kitchen's own server — Mealie for recipe"
                        " management, Joplin for notes, and more."
                        " One click, no tech skills needed."
                    ),
                    "button_label": "Set Up Kitchen Server",
                    "button_action": "full_server_setup",
                    "source": "server",
                    "show_when": "needs_setup",
                    "service_keys": ["mealie", "joplin"],
                },
                {
                    "key": "kitchen_services",
                    "type": "service_status",
                    "icon": "fa-utensils",
                    "color": "#4ade80",
                    "label": "Kitchen Services",
                    "source": "server",
                    "service_keys": [
                        "mealie",
                        "joplin",
                    ],
                },
                {
                    "key": "total_recipes",
                    "label": "Recipes",
                    "icon": "fa-book-open",
                    "color": "#4ade80",
                    "source": "kitchen",
                    "metric": "recipes.count",
                    "format": "number",
                },
                {
                    "key": "active_menus",
                    "label": "Active Menus",
                    "icon": "fa-scroll",
                    "color": "#fbbf24",
                    "source": "kitchen",
                    "metric": "menus.active_count",
                    "format": "number",
                },
                {
                    "key": "food_cost_pct",
                    "label": "Food Cost %",
                    "icon": "fa-percent",
                    "color": "#f87171",
                    "source": "kitchen",
                    "metric": "food_cost_pct",
                    "format": "percent",
                },
                {
                    "key": "vendor_count",
                    "label": "Vendors",
                    "icon": "fa-truck",
                    "color": "#60a5fa",
                    "source": "kitchen",
                    "metric": "vendors.count",
                    "format": "number",
                },
                {
                    "key": "staff_count",
                    "label": "Staff",
                    "icon": "fa-people-group",
                    "color": "#c084fc",
                    "source": "kitchen",
                    "metric": "staff.count",
                    "format": "number",
                },
                {
                    "key": "low_stock",
                    "label": "Low Stock",
                    "icon": "fa-triangle-exclamation",
                    "color": "#fb923c",
                    "source": "kitchen",
                    "metric": "inventory.low_stock_count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "recipes",
                "label": "Recipes",
                "icon": "fa-book-open",
                "type": "table",
                "source": "kitchen",
                "source_key": "recipes",
                "empty_message": "No recipes yet. Open Mealie to add your first recipe, or just tell me one and I'll save it for you!",
                "service_key": "mealie",
                "columns": [
                    {"key": "name", "label": "Recipe", "type": "text", "sortable": True},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {
                        "key": "servings",
                        "label": "Servings",
                        "type": "number",
                        "sortable": True,
                    },
                    {
                        "key": "cost_per_serving",
                        "label": "Cost/Serving",
                        "type": "currency",
                        "sortable": True,
                    },
                    {"key": "prep_time", "label": "Prep", "type": "text", "sortable": True},
                    {
                        "key": "last_updated",
                        "label": "Updated",
                        "type": "date",
                        "sortable": True,
                    },
                ],
                "default_sort": "name",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "view",
                        "label": "View",
                        "icon": "fa-eye",
                        "mode": "agent",
                        "prompt_template": (
                            "Show me the full recipe for {name} —"
                            " ingredients, method, plating, and cost breakdown."
                        ),
                    },
                    {
                        "key": "scale",
                        "label": "Scale",
                        "icon": "fa-up-right-and-down-left-from-center",
                        "mode": "agent",
                        "prompt_template": (
                            "Scale the recipe for {name}"
                            " (currently {servings} servings). How many servings do I need?"
                        ),
                    },
                ],
            },
            {
                "key": "menus",
                "label": "Menus",
                "icon": "fa-scroll",
                "type": "table",
                "source": "kitchen",
                "source_key": "menus",
                "empty_message": "No menus yet. Tell me what kind of menu you need and I'll help you design it!",
                "service_key": "mealie",
                "columns": [
                    {"key": "name", "label": "Menu", "type": "text", "sortable": True},
                    {"key": "type", "label": "Type", "type": "badge", "sortable": True},
                    {
                        "key": "item_count",
                        "label": "Items",
                        "type": "number",
                        "sortable": True,
                    },
                    {
                        "key": "avg_plate_cost",
                        "label": "Avg Plate Cost",
                        "type": "currency",
                        "sortable": True,
                    },
                    {"key": "status", "label": "Status", "type": "badge", "sortable": True},
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                ],
                "default_sort": "date",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "cost_analysis",
                        "label": "Costs",
                        "icon": "fa-calculator",
                        "mode": "agent",
                        "prompt_template": (
                            "Give me a full cost analysis for the {name} menu"
                            " — food cost per item, total cost, and margin."
                        ),
                    },
                    {
                        "key": "prep_list",
                        "label": "Prep List",
                        "icon": "fa-list-check",
                        "mode": "agent",
                        "prompt_template": (
                            "Generate a prep list for the {name} menu"
                            " — everything that needs to be prepped before service."
                        ),
                    },
                ],
            },
            {
                "key": "vendors",
                "label": "Vendors",
                "icon": "fa-truck",
                "type": "table",
                "source": "kitchen",
                "source_key": "vendors",
                "empty_message": "No vendors yet. Tell me about your suppliers and I'll start tracking them here!",
                "columns": [
                    {"key": "name", "label": "Vendor", "type": "text", "sortable": True},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {"key": "contact", "label": "Contact", "type": "text", "sortable": False},
                    {"key": "phone", "label": "Phone", "type": "text", "sortable": False},
                    {"key": "order_day", "label": "Order Day", "type": "text", "sortable": True},
                    {"key": "notes", "label": "Notes", "type": "text", "sortable": False},
                ],
                "default_sort": "category",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "order",
                        "label": "Order",
                        "icon": "fa-cart-shopping",
                        "mode": "agent",
                        "prompt_template": (
                            "I need to place an order with {name}."
                            " Help me draft the order based on current inventory levels."
                        ),
                    },
                ],
            },
            {
                "key": "inventory",
                "label": "Inventory",
                "icon": "fa-boxes-stacked",
                "type": "table",
                "source": "kitchen",
                "source_key": "inventory",
                "empty_message": "No inventory tracked yet. Tell me what you have in stock and I'll start tracking it!",
                "columns": [
                    {"key": "item", "label": "Item", "type": "text", "sortable": True},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {
                        "key": "quantity",
                        "label": "Qty",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "unit", "label": "Unit", "type": "text", "sortable": False},
                    {
                        "key": "par_level",
                        "label": "Par Level",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "supplier", "label": "Supplier", "type": "text", "sortable": True},
                ],
                "default_sort": "category",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "reorder",
                        "label": "Reorder",
                        "icon": "fa-rotate",
                        "mode": "agent",
                        "prompt_template": (
                            "I need to reorder {item} from {supplier}."
                            " Current qty: {quantity} {unit}, par level: {par_level}."
                        ),
                    },
                ],
            },
            {
                "key": "schedule",
                "label": "Schedule",
                "icon": "fa-calendar-days",
                "type": "table",
                "source": "kitchen",
                "source_key": "schedule",
                "empty_message": "No shifts scheduled yet. Tell me your team and I'll help build the weekly schedule!",
                "columns": [
                    {"key": "staff_name", "label": "Name", "type": "text", "sortable": True},
                    {"key": "role", "label": "Role", "type": "badge", "sortable": True},
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                    {"key": "shift", "label": "Shift", "type": "text", "sortable": True},
                    {"key": "hours", "label": "Hours", "type": "number", "sortable": True},
                ],
                "default_sort": "date",
                "default_sort_dir": "asc",
                "row_actions": [],
            },
            {
                "key": "costs",
                "label": "Cost Tracker",
                "icon": "fa-chart-pie",
                "type": "summary",
                "source": "kitchen",
                "stats": [
                    {
                        "key": "food_cost_pct",
                        "label": "Food Cost %",
                        "icon": "fa-percent",
                        "color": "#f87171",
                        "metric": "food_cost_pct",
                        "format": "percent",
                    },
                    {
                        "key": "labor_cost_pct",
                        "label": "Labor Cost %",
                        "icon": "fa-people-group",
                        "color": "#fb923c",
                        "metric": "labor_cost_pct",
                        "format": "percent",
                    },
                    {
                        "key": "total_revenue",
                        "label": "Revenue (MTD)",
                        "icon": "fa-dollar-sign",
                        "color": "#4ade80",
                        "metric": "revenue_mtd",
                        "format": "currency",
                    },
                    {
                        "key": "total_food_cost",
                        "label": "Food Cost (MTD)",
                        "icon": "fa-carrot",
                        "color": "#fbbf24",
                        "metric": "food_cost_mtd",
                        "format": "currency",
                    },
                    {
                        "key": "total_labor_cost",
                        "label": "Labor Cost (MTD)",
                        "icon": "fa-clock",
                        "color": "#c084fc",
                        "metric": "labor_cost_mtd",
                        "format": "currency",
                    },
                    {
                        "key": "avg_plate_cost",
                        "label": "Avg Plate Cost",
                        "icon": "fa-plate-wheat",
                        "color": "#60a5fa",
                        "metric": "avg_plate_cost",
                        "format": "currency",
                    },
                ],
            },
        ],
        "quick_actions": [
            {
                "key": "add_recipe",
                "label": "Add Recipe",
                "icon": "fa-book-medical",
                "mode": "agent",
                "prompt": (
                    "I want to add a new recipe. Help me capture"
                    " the name, category, ingredients with quantities,"
                    " method, plating notes, and cost per serving."
                ),
            },
            {
                "key": "create_menu",
                "label": "Create Menu",
                "icon": "fa-scroll",
                "mode": "agent",
                "prompt": (
                    "I want to create a new menu. What type?"
                    " (dinner, lunch, tasting, seasonal, catering)"
                    " I'll help with course flow and cost analysis."
                ),
            },
            {
                "key": "log_cost",
                "label": "Log Cost",
                "icon": "fa-receipt",
                "mode": "agent",
                "prompt": "I need to log a food or labor cost entry.",
            },
            {
                "key": "add_vendor",
                "label": "Add Vendor",
                "icon": "fa-truck",
                "mode": "agent",
                "prompt": (
                    "I want to add a new vendor/supplier."
                    " Help me capture their name, category, contact info,"
                    " order days, and delivery schedule."
                ),
            },
            {
                "key": "prep_list",
                "label": "Prep List",
                "icon": "fa-list-check",
                "mode": "agent",
                "prompt": (
                    "Generate a prep list for today's service"
                    " based on the active menu and expected covers."
                ),
            },
            {
                "key": "weekly_costs",
                "label": "Weekly Report",
                "icon": "fa-chart-line",
                "mode": "agent",
                "prompt": (
                    "Give me a weekly cost report — food cost %,"
                    " labor cost %, revenue, and any items running"
                    " over target cost."
                ),
            },
        ],
    },
)

register_job_class(CHEF)
