"""Configuration loading and validation for SOAP pipeline."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_CONFIG_DIR = Path(__file__).parent


def _load_toml(path: Path) -> dict:
    with open(path, "rb") as f:
        return tomllib.load(f)


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base*, returning a new dict."""
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


@dataclass
class SOAPConfig:
    """Holds all pipeline configuration."""

    # Extraction
    extraction_threshold: float = 1.5
    extraction_min_area: int = 5

    # Aperture
    aperture_mode: str = "fwhm_scaled"
    aperture_scale: float = 2.5
    aperture_fixed_radius: float = 5.0
    aperture_min_radius: float = 3.0
    aperture_max_radius: float = 20.0
    aperture_step: float = 0.5
    aperture_radii: list[float] = field(
        default_factory=lambda: [2.0, 3.0, 5.0, 7.0, 10.0]
    )
    aperture_keep_all: bool = False

    # Calibration
    calibration_sigma_clip: float = 3.0
    calibration_max_iter: int = 5
    calibration_match_radius_arcsec: float = 3.0
    calibration_default_cat_error: float = 0.03
    calibration_merge_tolerance_arcsec: float = 2.0
    calibration_convert_vega_to_ab: bool = False

    # Forced photometry
    forced_photometry_enabled: bool = False
    forced_photometry_snr_threshold: float = 3.0
    forced_photometry_aperture_radius: float = 5.0

    # Limiting magnitude
    limiting_mag_method: str = "analytic"
    limiting_mag_robust_n_samples: int = 2000
    limiting_mag_robust_mask_dilate_pixels: int = 3
    limiting_mag_robust_edge_buffer_pixels: int = 25
    limiting_mag_robust_sigma_estimator: str = "mad"
    limiting_mag_robust_max_draws_multiplier: int = 20
    limiting_mag_robust_random_seed: int | None = None

    # Astrometry
    astrometry_enabled: bool = False
    astrometry_solver: str = "auto"
    astrometry_fallback_enabled: bool = True

    # Local solver
    astrometry_local_binary_path: str = "solve-field"
    astrometry_local_timeout: int = 300
    astrometry_local_scale_low: float | None = None
    astrometry_local_scale_high: float | None = None
    astrometry_local_depth: int | list[int] | None = None
    astrometry_local_downsample: int | None = None
    astrometry_local_extra_args: list[str] = field(default_factory=list)

    # API solver
    astrometry_api_key: str | None = None
    astrometry_api_timeout: int = 500

    # Debugging & Intermediate Products
    debug_mode: bool = False
    debug_dir: str = "soap_debug"
    save_intermediates: bool = False
    intermediates_dir: str = "soap_intermediates"

    # Logging
    log_level: str = "WARNING"

    # Raw TOML data for filters/catalogs
    filters: dict = field(default_factory=dict)
    catalogs: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> SOAPConfig:
        """Create a SOAPConfig from a flat or nested dictionary."""
        cfg = cls()

        ext = d.get("extraction", {})
        cfg.extraction_threshold = ext.get("threshold", cfg.extraction_threshold)
        cfg.extraction_min_area = ext.get("min_area", cfg.extraction_min_area)

        ap = d.get("aperture", {})
        cfg.aperture_mode = ap.get("mode", cfg.aperture_mode)
        cfg.aperture_scale = ap.get("scale", cfg.aperture_scale)
        cfg.aperture_fixed_radius = ap.get("fixed_radius", cfg.aperture_fixed_radius)
        cfg.aperture_min_radius = ap.get("min_radius", cfg.aperture_min_radius)
        cfg.aperture_max_radius = ap.get("max_radius", cfg.aperture_max_radius)
        cfg.aperture_step = ap.get("step", cfg.aperture_step)
        cfg.aperture_radii = ap.get("radii", cfg.aperture_radii)
        cfg.aperture_keep_all = ap.get("keep_all", cfg.aperture_keep_all)

        cal = d.get("calibration", {})
        cfg.calibration_sigma_clip = cal.get("sigma_clip", cfg.calibration_sigma_clip)
        cfg.calibration_max_iter = cal.get("max_iter", cfg.calibration_max_iter)
        cfg.calibration_match_radius_arcsec = cal.get(
            "match_radius_arcsec", cfg.calibration_match_radius_arcsec
        )
        cfg.calibration_default_cat_error = cal.get(
            "default_cat_error", cfg.calibration_default_cat_error
        )
        cfg.calibration_merge_tolerance_arcsec = cal.get(
            "merge_tolerance_arcsec", cfg.calibration_merge_tolerance_arcsec
        )
        cfg.calibration_convert_vega_to_ab = cal.get(
            "convert_vega_to_ab", cfg.calibration_convert_vega_to_ab
        )

        fp = d.get("forced_photometry", {})
        cfg.forced_photometry_enabled = fp.get("enabled", cfg.forced_photometry_enabled)
        cfg.forced_photometry_snr_threshold = fp.get(
            "snr_threshold", cfg.forced_photometry_snr_threshold
        )
        cfg.forced_photometry_aperture_radius = fp.get(
            "aperture_radius", cfg.forced_photometry_aperture_radius
        )

        lm = d.get("limiting_mag", {})
        cfg.limiting_mag_method = lm.get("method", cfg.limiting_mag_method)
        lm_robust = lm.get("robust", {})
        cfg.limiting_mag_robust_n_samples = lm_robust.get(
            "n_samples", cfg.limiting_mag_robust_n_samples
        )
        cfg.limiting_mag_robust_mask_dilate_pixels = lm_robust.get(
            "mask_dilate_pixels", cfg.limiting_mag_robust_mask_dilate_pixels
        )
        cfg.limiting_mag_robust_edge_buffer_pixels = lm_robust.get(
            "edge_buffer_pixels", cfg.limiting_mag_robust_edge_buffer_pixels
        )
        cfg.limiting_mag_robust_sigma_estimator = lm_robust.get(
            "sigma_estimator", cfg.limiting_mag_robust_sigma_estimator
        )
        cfg.limiting_mag_robust_max_draws_multiplier = lm_robust.get(
            "max_draws_multiplier", cfg.limiting_mag_robust_max_draws_multiplier
        )
        seed = lm_robust.get("random_seed", cfg.limiting_mag_robust_random_seed)
        cfg.limiting_mag_robust_random_seed = (
            int(seed) if seed is not None and int(seed) > 0 else None
        )

        ast = d.get("astrometry", {})
        cfg.astrometry_enabled = ast.get("enabled", cfg.astrometry_enabled)
        cfg.astrometry_solver = ast.get("solver", cfg.astrometry_solver)
        cfg.astrometry_fallback_enabled = ast.get(
            "fallback_enabled", cfg.astrometry_fallback_enabled
        )

        # Local solver config
        ast_local = ast.get("local", {})
        cfg.astrometry_local_binary_path = ast_local.get(
            "binary_path", cfg.astrometry_local_binary_path
        )
        cfg.astrometry_local_timeout = ast_local.get(
            "timeout", cfg.astrometry_local_timeout
        )
        cfg.astrometry_local_scale_low = ast_local.get(
            "scale_low", cfg.astrometry_local_scale_low
        )
        cfg.astrometry_local_scale_high = ast_local.get(
            "scale_high", cfg.astrometry_local_scale_high
        )
        cfg.astrometry_local_depth = ast_local.get("depth", cfg.astrometry_local_depth)
        cfg.astrometry_local_downsample = ast_local.get(
            "downsample", cfg.astrometry_local_downsample
        )
        cfg.astrometry_local_extra_args = ast_local.get(
            "extra_args", cfg.astrometry_local_extra_args
        )

        # API solver config
        ast_api = ast.get("api", {})
        cfg.astrometry_api_key = ast_api.get("api_key", cfg.astrometry_api_key)
        cfg.astrometry_api_timeout = ast_api.get("timeout", cfg.astrometry_api_timeout)

        dbg = d.get("debug", {})
        cfg.debug_mode = dbg.get("enabled", cfg.debug_mode)
        cfg.debug_dir = dbg.get("debug_dir", cfg.debug_dir)
        cfg.save_intermediates = dbg.get("save_intermediates", cfg.save_intermediates)
        cfg.intermediates_dir = dbg.get("intermediates_dir", cfg.intermediates_dir)

        log = d.get("logging", {})
        cfg.log_level = log.get("level", cfg.log_level)

        cfg.filters = d.get("filters", cfg.filters)
        cfg.catalogs = d.get("catalogs", cfg.catalogs)

        return cfg


def load_config(
    user_config_path: str | Path | None = None, overrides: dict[str, Any] | None = None
) -> SOAPConfig:
    """Load default config, merge with user config and overrides.

    Parameters
    ----------
    user_config_path : path, optional
        Path to a user TOML file that overrides defaults.
    overrides : dict, optional
        Additional overrides applied last.

    Returns
    -------
    SOAPConfig
    """
    defaults = _load_toml(_CONFIG_DIR / "defaults.toml")
    filters = _load_toml(_CONFIG_DIR / "filters.toml")
    catalogs = _load_toml(_CONFIG_DIR / "catalogs.toml")

    merged = defaults.copy()
    merged["filters"] = filters
    merged["catalogs"] = catalogs

    if user_config_path is not None:
        user = _load_toml(Path(user_config_path))
        merged = _deep_merge(merged, user)

    if overrides is not None:
        merged = _deep_merge(merged, overrides)

    return SOAPConfig.from_dict(merged)
