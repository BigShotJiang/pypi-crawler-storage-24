"""kulu-audio-eval: Voice Agent Audio Evaluation Library.

Evaluates 2-speaker conversation audio (agent + user) and returns structured
quality metrics: cutout detection, response latency, and failure inference.

Usage::

    from kulu_audio_eval import evaluate

    result = evaluate(
        audio_path="recording.oga",
        elevenlabs_api_key="elabs_xxx",
        gemini_api_key="AIza...",  # optional
    )
    print(result["latency_report"]["mean_ms"])
    print(result["cutout_report"]["total_count"])
"""

from __future__ import annotations

import os
from typing import Any


def evaluate(
    audio_path: str,
    elevenlabs_api_key: str,
    gemini_api_key: str | None = None,
    output_dir: str | None = None,
    dump: bool = False,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run the full evaluation pipeline and return structured results.

    Args:
        audio_path: Path to the audio file (.oga, .wav, .mp3, .m4a, .flac).
        elevenlabs_api_key: ElevenLabs API key for STT and diarization.
        gemini_api_key: Gemini API key for failure inference and translation.
            Optional; those pipeline stages are skipped when absent.
        output_dir: Directory for output files (CSVs, PNGs, cache).
            Only used when dump=True. Defaults to ``out/<audio-stem>``.
        dump: When True, write CSVs/PNGs/cache to output_dir.
            Defaults to False (pure in-memory, no files created).
        **kwargs: Additional config overrides, e.g.
            ``CUTOUT_THRESHOLD_MS=500``, ``TRANSLATION_TARGET_LANGUAGE="fr"``.

    Returns:
        Dict with keys:

        - ``cutout_report`` (dict): ``total_count``, ``total_duration_ms``, ``cutouts`` list.
        - ``latency_report`` (dict): latency statistics + ``per_turn`` list.
        - ``failure_report`` (dict): ``count``, ``failures`` list.
        - ``output_dir`` (str): where files were written (only present when dump=True).
    """
    os.environ.setdefault("MPLBACKEND", "Agg")
    overrides: dict[str, Any] = {
        "ELEVENLABS_API_KEY": elevenlabs_api_key,
        "GEMINI_API_KEY": gemini_api_key,
        **kwargs,
    }
    from kulu_audio_eval.core.pipeline import run

    return run(audio_path, output_dir=output_dir, config_overrides=overrides, dump=dump)


__all__ = ["evaluate"]
