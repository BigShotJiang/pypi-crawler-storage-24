"""
Main Evaluation Pipeline

Stages (1–11, no gaps):
    1) load_audio: Load the audio file.
    2) run_elevenlabs_pipeline + merge + assign_turns: Transcribe, diarize, merge segments, assign turn numbers.
    3) export_chunk + export_chunk_audio_csv: Per-turn stereo WAV and chunk CSV (mix + agent/user amplitudes).
    4) detect_cutouts: Detect agent audio cutouts (e.g., mid-speech dropouts).
    5) infer_failed_responses (optional): Label failures via Gemini.
    6) run_latency_metrics: User→agent response latency per turn + summary stats.
    7) translate_segments (optional): Translate segment text via Gemini.
    8) write_transcript_csv: transcript.csv and agent_transcript.csv.
    9) write_speaker_timeline_csv: latency_plot.csv.
    10) plot_speaker_timeline_with_flags: latency_plot.png.
    11) write_evaluation_summary_csv: evaluation_summary.csv.

Main outputs:
    - evaluation_summary.csv
    - agent_transcript.csv
    - latency_plot.png
    - (+ cached API results)

Concurrency (within a single run() call, one audio file):
    - Sequential: stages 1–4, 6, 8–11 (load, STT, export, cutouts, latency, CSV/plot writes).
    - Parallel (non-blocking batch work): stage 5 (failure inference) and stage 7 (translation)
      run their Gemini batch requests in parallel via ThreadPoolExecutor; the rest of the
      pipeline is blocking/sequential per file.
    - Multiple audio files: use the CLI without a single AUDIO argument; the CLI runs
      multiple files in parallel (see evaluate -j/--max-workers in cli.py).
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import MutableMapping
from pathlib import Path
from typing import Any

from kulu_audio_eval.config import load_config
from kulu_audio_eval.utils.pipeline_utils import (
    DEFAULT_OUTPUT_DIR,
    _format_duration,
    _format_pipeline_duration,
    _stage,
)
from kulu_audio_eval.utils.audio import (
    load_audio,
    load_audio_stereo,
    export_chunk,
    export_chunk_audio_csv,
)
from kulu_audio_eval.utils.csv_writer import (
    write_evaluation_summary_csv,
    write_transcript_csv,
    write_speaker_timeline_csv,
)
from kulu_audio_eval.utils.table_log import print_table
from kulu_audio_eval.utils.visualization import (
    plot_speaker_timeline_with_flags,
)
from kulu_audio_eval.services.two_cluster import (
    _assign_turns,
    _merge_consecutive_same_speaker,
)
from kulu_audio_eval.services.anomaly_detection import detect_cutouts
from kulu_audio_eval.services.gemini_failed_response import (
    apply_failures_to_segments,
    infer_failed_responses,
)
from kulu_audio_eval.services.latency_metrics import run_latency_metrics

log = logging.getLogger(__name__)


def _load_json(path: Path) -> Any:
    """Load JSON from path. Raises OSError or json.JSONDecodeError on failure."""
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _save_json(path: Path, data: Any) -> None:
    """Write JSON to path; ensure parent dir exists. Uses ensure_ascii=False."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)


class _PipelineLogAdapter(logging.LoggerAdapter):
    """Prefix log messages with [audio_name] when running in batch (e.g. ./manage evaluate)."""

    def process(self, msg: str, kwargs: MutableMapping[str, Any]) -> tuple[str, Any]:
        extra = self.extra or {}
        prefix = extra.get("prefix")
        if prefix:
            return (f"[{prefix}] {msg}", kwargs)
        return (msg, kwargs)


def _merge_and_assign_turns(
    segments: list[dict],
    min_chunk_duration_s: float,
    duration_s: float,
    logger: logging.Logger | logging.LoggerAdapter = log,
) -> list[dict]:
    """Merge consecutive same-speaker segments and assign turn numbers."""
    logger.info(_stage(2, "Merging segments (min_chunk=%.1fs)…") % min_chunk_duration_s)
    merged = _merge_consecutive_same_speaker(
        segments, min_chunk_duration_s, audio_duration_s=duration_s
    )
    _assign_turns(merged)
    logger.debug("Merged segments: %s", len(merged))
    return merged


def _setup(
    audio_path: str,
    output_dir: str | None,
    log_prefix: str | None,
    config_overrides: dict[str, Any] | None = None,
    dump: bool = True,
) -> dict[str, Any]:
    """Resolve paths, load config, create output dirs and logger. Return pipeline context."""
    import tempfile

    cfg = load_config(overrides=config_overrides)
    audio_path_obj = Path(audio_path)
    raw_min_chunk = cfg.get("TURN_MIN_CHUNK_DURATION_S", 3.0)
    min_chunk_duration_s = float(raw_min_chunk if raw_min_chunk is not None else 3.0)
    logger = (
        _PipelineLogAdapter(log, {"prefix": log_prefix})
        if log_prefix is not None
        else log
    )

    if dump:
        default_output_dir = str(Path(DEFAULT_OUTPUT_DIR) / audio_path_obj.stem)
        out_dir = output_dir if output_dir is not None else default_output_dir
        out = Path(out_dir)
        audio_chunks_dir = out / "audio_chunks"
        audio_data_dir = out / "audio_data"
        if audio_chunks_dir.exists():
            for old_chunk in audio_chunks_dir.glob("chunk_*.wav"):
                old_chunk.unlink()
        if audio_data_dir.exists():
            for old_csv in audio_data_dir.glob("chunk_*.csv"):
                old_csv.unlink()
        audio_chunks_dir.mkdir(parents=True, exist_ok=True)
        audio_data_dir.mkdir(parents=True, exist_ok=True)
        cache_dir = out / "cache"
    else:
        tmp_dir = Path(tempfile.mkdtemp(prefix="kulu_audio_eval_"))
        out = tmp_dir
        audio_chunks_dir = tmp_dir / "audio_chunks"
        audio_data_dir = tmp_dir / "audio_data"
        cache_dir = tmp_dir / "cache"

    logger.info("Config")
    print_table(
        [
            ("input", str(audio_path_obj)),
            ("output", str(out) if dump else "(in-memory)"),
            ("method", "elevenlabs"),
            ("num_speakers", str(cfg.get("DIARIZER_NUM_SPEAKERS", 2))),
            ("min_chunk_duration_s", str(min_chunk_duration_s)),
        ],
        left_header="Config",
        right_header="Value",
    )
    return {
        "cfg": cfg,
        "out": out,
        "cache_dir": cache_dir,
        "audio_path_obj": audio_path_obj,
        "audio_chunks_dir": audio_chunks_dir,
        "audio_data_dir": audio_data_dir,
        "min_chunk_duration_s": min_chunk_duration_s,
        "logger": logger,
        "pipeline_start": time.perf_counter(),
        "dump": dump,
    }


def _stage_1_load_audio(ctx: dict[str, Any]) -> None:
    audio_info = load_audio(str(ctx["audio_path_obj"]))
    ctx["audio_data"] = audio_info["audio"]
    ctx["sample_rate"] = audio_info["sample_rate"]
    ctx["duration_s"] = audio_info["duration"]
    # Load stereo for chunk export (ch0=agent, ch1=user); processing uses mono above
    stereo_info = load_audio_stereo(str(ctx["audio_path_obj"]))
    ctx["audio_stereo"] = stereo_info["audio"]
    logger = ctx["logger"]
    logger.info(
        _stage(1, "Audio: %s (%s, %s Hz)")
        % (
            ctx["audio_path_obj"].name,
            _format_duration(ctx["duration_s"]),
            ctx["sample_rate"],
        ),
    )


def _stage_2_stt(ctx: dict[str, Any]) -> None:
    from kulu_audio_eval.services.elevenlabs_adapter import run_elevenlabs_pipeline

    logger = ctx["logger"]
    cfg = ctx["cfg"]
    if not cfg.get("ELEVENLABS_API_KEY"):
        logger.warning("ELEVENLABS_API_KEY not set. Set it in .env for the pipeline.")
    elevenlabs_config = {
        "ELEVENLABS_API_KEY": cfg.get("ELEVENLABS_API_KEY"),
        "elevenlabs_api_key": cfg.get("ELEVENLABS_API_KEY"),
    }
    cache_path = ctx["cache_dir"] / (ctx["audio_path_obj"].name + ".json")
    ctx["stt_json_path"] = cache_path
    try:
        segments = run_elevenlabs_pipeline(
            str(ctx["audio_path_obj"]),
            elevenlabs_config,
            cache_path=str(cache_path),
        )
    except ImportError as e:
        raise RuntimeError("ElevenLabs adapter could not be imported. %s" % e) from e
    logger.info(_stage(2, "Running ElevenLabs Speech-to-Text (transcribe, diarize)…"))
    logger.debug("ElevenLabs raw segments: %s", len(segments))
    ctx["raw_segments"] = list(
        segments
    )  # snapshot before merge (used for barge-in detection)
    ctx["segments"] = _merge_and_assign_turns(
        segments,
        ctx["min_chunk_duration_s"],
        ctx["duration_s"],
        logger=logger,
    )


def _stage_3_export_chunks(ctx: dict[str, Any]) -> None:
    if not ctx["dump"]:
        return
    segments = ctx["segments"]
    audio_data = ctx["audio_data"]
    audio_stereo = ctx["audio_stereo"]
    sample_rate = ctx["sample_rate"]
    audio_chunks_dir = ctx["audio_chunks_dir"]
    audio_data_dir = ctx["audio_data_dir"]
    min_chunk_duration_s = ctx["min_chunk_duration_s"]
    logger = ctx["logger"]
    audio_duration_s = len(audio_data) / sample_rate
    for i, seg in enumerate(segments, start=1):
        chunk_filename = f"chunk_{i:03d}.wav"
        chunk_path = audio_chunks_dir / chunk_filename
        # For user segments, extend the exported chunk to the next segment's start
        # so the latency gap (silence after user speech) is visible in the waveform
        # rather than appearing as a skipped timestamp in the timeline.
        if seg.get("speaker") == "user" and i < len(segments):
            next_seg = segments[i]  # i is 1-based, so segments[i] is the next element
            chunk_end = min(next_seg["start"], audio_duration_s)
        else:
            chunk_end = seg["end"]
        # Export stereo (ch0=agent, ch1=user) so the web UI can show both channels
        export_chunk(
            audio_stereo, sample_rate, seg["start"], chunk_end, str(chunk_path)
        )
        csv_filename = f"chunk_{i:03d}.csv"
        csv_path = audio_data_dir / csv_filename
        export_chunk_audio_csv(
            audio_stereo, sample_rate, seg["start"], chunk_end, str(csv_path)
        )
        seg["audio_chunk"] = f"audio_chunks/{chunk_filename}"
        seg["segment_id"] = i
    for seg in segments:
        dur = seg["end"] - seg["start"]
        if dur < min_chunk_duration_s:
            logger.warning(
                "Chunk segment_id=%s shorter than min_chunk_duration_s (%.1fs): "
                "duration=%.2fs (boundary segment)",
                seg["segment_id"],
                min_chunk_duration_s,
                dur,
            )
    logger.info(
        _stage(3, "Exported %s chunks to %s") % (len(segments), audio_chunks_dir)
    )


def _stage_4_cutouts(ctx: dict[str, Any]) -> None:
    logger = ctx["logger"]
    logger.info(_stage(4, "Detecting anomalies (cutouts)…"))
    # Use agent channel (ch0) for energy analysis so barge-in gaps are visible.
    # Mono averages ch0+ch1: user speech during a barge-in raises the mono RMS above
    # the silence threshold, masking the agent's silence. ch0 is silent during those gaps.
    audio_stereo = ctx.get("audio_stereo")
    audio_for_cutouts = (
        audio_stereo[:, 0]
        if audio_stereo is not None and audio_stereo.ndim == 2
        else ctx["audio_data"]
    )
    all_cutouts = detect_cutouts(
        audio_for_cutouts,
        ctx["sample_rate"],
        ctx["segments"],
        dict(ctx["cfg"]),
        words_json_path=ctx.get("stt_json_path"),
    )
    ctx["all_cutouts"] = all_cutouts
    logger.info(_stage(4, "Found %s cutouts") % len(all_cutouts))

    # Detect barge-in cutouts: short user segments absorbed into agent segments by two_cluster
    # are invisible to mono energy analysis (user speech masks agent silence). Tag them explicitly.
    barge_in_count = 0
    for seg in ctx["segments"]:
        if seg.get("speaker") != "agent":
            continue
        seg_start, seg_end = seg["start"], seg["end"]
        for raw in ctx.get("raw_segments", []):
            if raw.get("speaker") == "agent":
                continue
            if raw["start"] >= seg_start and raw["end"] <= seg_end:
                barge_in = {
                    "type": "cutout_barge_in",
                    "start_ms": round(raw["start"] * 1000, 1),
                    "end_ms": round(raw["end"] * 1000, 1),
                }
                seg.setdefault("cutouts", []).append(barge_in)
                seg.setdefault("y_pred_cutouts", []).append(barge_in)
                barge_in_count += 1
    if barge_in_count:
        logger.info(
            _stage(4, "Tagged %s barge-in interval(s) as cutout_barge_in")
            % barge_in_count
        )


def _stage_5_failure_inference(ctx: dict[str, Any]) -> None:
    cfg = ctx["cfg"]
    logger = ctx["logger"]
    segments = ctx["segments"]
    all_failures: list[dict] = []
    ctx["all_failures"] = all_failures
    if not cfg.get("GEMINI_API_KEY"):
        return
    use_failure_cache = bool(cfg.get("FAILURE_INFERENCE_USE_CACHE", True)) and ctx["dump"]
    failure_cache_path = ctx["cache_dir"] / "failure_inference.json"
    used_failure_cache = False
    if use_failure_cache and failure_cache_path.is_file():
        try:
            cached_failures = _load_json(failure_cache_path)
            if isinstance(cached_failures, list):
                apply_failures_to_segments(segments, cached_failures)
                all_failures.extend(cached_failures)
                logger.info(
                    _stage(5, "Using cached failure inference (%s)"),
                    failure_cache_path.name,
                )
                used_failure_cache = True
        except (OSError, json.JSONDecodeError) as e:
            logger.warning(
                "Failure inference cache read failed (%s), re-running: %s",
                failure_cache_path,
                e,
            )
    if not used_failure_cache:
        logger.info(_stage(5, "Inferring failed responses via Gemini…"))
        gemini_failures = infer_failed_responses(segments, dict(cfg))
        all_failures.extend(gemini_failures)
        logger.info(
            _stage(5, "Gemini found %s failed responses") % len(gemini_failures),
        )
        if use_failure_cache:
            try:
                _save_json(failure_cache_path, gemini_failures)
                logger.debug("Cached failure inference to %s", failure_cache_path)
            except OSError as e:
                logger.warning("Failure inference cache write failed: %s", e)


def _stage_6_latency(ctx: dict[str, Any]) -> None:
    logger = ctx["logger"]
    logger.info(_stage(6, "Computing latency metrics…"))
    out_path = str(ctx["out"]) if ctx["dump"] else None
    turn_latencies, latency_stats = run_latency_metrics(
        ctx["segments"], out_path
    )
    ctx["turn_latencies"] = turn_latencies
    ctx["latency_stats"] = latency_stats
    if latency_stats:
        logger.info(
            _stage(6, "%s turns: mean=%dms, median=%dms, p95=%dms")
            % (
                len(turn_latencies),
                int(latency_stats["mean_ms"]),
                int(latency_stats["median_ms"]),
                int(latency_stats["percentile_95_ms"]),
            ),
        )
    else:
        logger.info(_stage(6, "No latency data (no complete user→agent turns)"))


def _stage_7_translation(ctx: dict[str, Any]) -> None:
    from kulu_audio_eval.services.translation_gemini import translate_segments

    cfg = ctx["cfg"]
    logger = ctx["logger"]
    segments = ctx["segments"]
    _target_raw = cfg.get("TRANSLATION_TARGET_LANGUAGE")
    translation_target_language = (
        str(_target_raw).strip() if _target_raw is not None else "en"
    )
    if not translation_target_language:
        return
    use_translation_cache = bool(cfg.get("TRANSLATION_USE_CACHE", True)) and ctx["dump"]
    cache_basename = "translation_gemini_{}.json".format(
        translation_target_language.replace("/", "-").replace(" ", "_"),
    )
    translation_cache_path = ctx["cache_dir"] / cache_basename
    used_translation_cache = False
    if use_translation_cache and translation_cache_path.is_file():
        try:
            cached_text_eng = _load_json(translation_cache_path)
            if isinstance(cached_text_eng, list) and len(cached_text_eng) == len(
                segments
            ):
                for i, seg in enumerate(segments):
                    seg["text_eng"] = (
                        cached_text_eng[i] if i < len(cached_text_eng) else ""
                    )
                logger.info(
                    _stage(7, "Using cached translation (%s)"),
                    translation_cache_path.name,
                )
                used_translation_cache = True
        except (OSError, json.JSONDecodeError) as e:
            logger.warning(
                "Translation cache read failed (%s), re-translating: %s",
                translation_cache_path,
                e,
            )
    if not used_translation_cache:
        logger.info(
            _stage(7, "Translating to %s (Gemini)…"),
            translation_target_language,
        )
        translation_config = {
            "GEMINI_API_KEY": cfg.get("GEMINI_API_KEY"),
            "TRANSLATION_TARGET_LANGUAGE": translation_target_language,
            "TRANSLATION_MAX_WORKERS": cfg.get("TRANSLATION_MAX_WORKERS", 4),
        }
        translate_segments(segments, translation_config)
        if use_translation_cache:
            text_eng_list = [seg.get("text_eng", "") for seg in segments]
            try:
                _save_json(translation_cache_path, text_eng_list)
                logger.debug("Cached translation to %s", translation_cache_path)
            except OSError as e:
                logger.warning("Translation cache write failed: %s", e)
        logger.debug(
            "Translation complete (text_eng set on %s segments)",
            len(segments),
        )


def _stage_8_transcript_csv(ctx: dict[str, Any]) -> None:
    segments = ctx["segments"]
    logger = ctx["logger"]
    agent_segments = [
        s for s in segments if (s.get("speaker") or "").lower() == "agent"
    ]
    turn_user_end_speech: dict[int, float] = {}
    for s in segments:
        if (s.get("speaker") or "").lower() != "user":
            continue
        t = s.get("turn")
        if t is None:
            continue
        end_s = s.get("end_speech_s")
        if end_s is not None:
            if t not in turn_user_end_speech or end_s > turn_user_end_speech[t]:
                turn_user_end_speech[t] = end_s
    for s in agent_segments:
        prev_turn = (s.get("turn") or 0) - 1
        s["user_previous_end_speech_s"] = (
            turn_user_end_speech.get(prev_turn) if prev_turn >= 1 else None
        )

    # Compute barge-in and total E2E latency on each agent segment now that
    # user_previous_end_speech_s is set.  Stored on the segment so csv_writer
    # and _build_result can read them without re-computing.
    for s in agent_segments:
        pred_cutouts: list[dict] = s.get("y_pred_cutouts") or s.get("cutouts") or []
        gap = s.get("e2e_turn_gap_latency_ms")
        gap_int: int | None = gap if isinstance(gap, int) else None
        after_cutout_ms: int | None = None
        if pred_cutouts:
            try:
                after_cutout_ms = int(round(max(float(c.get("end_ms", 0)) for c in pred_cutouts)))
            except (TypeError, ValueError):
                pass
        user_prev_s = s.get("user_previous_end_speech_s")
        barge_in_int: int | None = None
        if gap_int is None and pred_cutouts and after_cutout_ms is not None and user_prev_s is not None:
            raw = after_cutout_ms - int(float(user_prev_s) * 1000)
            barge_in_int = raw if raw >= 0 else None
        s["e2e_barge_in_latency_ms"] = barge_in_int if barge_in_int is not None else ""
        total = (gap_int or 0) + (barge_in_int or 0)
        s["total_e2e_latency_ms"] = total if total > 0 else ""

    # Enrich turn_latencies with total_e2e_latency_ms so _build_result per_turn is complete
    turn_total: dict[int, int] = {
        s["turn"]: s["total_e2e_latency_ms"]
        for s in agent_segments
        if s.get("turn") is not None and isinstance(s.get("total_e2e_latency_ms"), int)
    }
    for tl in ctx.get("turn_latencies", []):
        tn = tl.get("turn_number")
        tl["total_e2e_latency_ms"] = turn_total.get(tn)

    if not ctx["dump"]:
        return

    out = ctx["out"]
    csv_path = out / "transcript.csv"
    write_transcript_csv(segments, str(csv_path))
    logger.info(_stage(8, "%s (%s segments)") % (csv_path.name, len(segments)))
    agent_transcript_path = out / "agent_transcript.csv"
    write_transcript_csv(
        agent_segments,
        str(agent_transcript_path),
        include_text_columns=False,
        use_display_headers=True,
        omit_columns=[
            "audio_chunk",
            "segment_id",
            "end_ms",
            "y_pred_speaker",
            "y_pred_cutout",
        ],
    )
    logger.info(
        _stage(8, "%s (%s segments)")
        % (agent_transcript_path.name, len(agent_segments)),
    )


def _stage_9_latency_plot_csv(ctx: dict[str, Any]) -> None:
    if not ctx["dump"]:
        return
    logger = ctx["logger"]
    out = ctx["out"]
    latency_plot_csv_path = out / "latency_plot.csv"
    write_speaker_timeline_csv(
        ctx["segments"], str(latency_plot_csv_path), ctx["turn_latencies"]
    )
    logger.info(_stage(9, "%s") % (latency_plot_csv_path.name,))


def _stage_10_plot(ctx: dict[str, Any]) -> None:
    if not ctx["dump"]:
        return
    logger = ctx["logger"]
    out = ctx["out"]
    latency_plot_path = out / "latency_plot.png"
    plot_speaker_timeline_with_flags(
        ctx["segments"],
        ctx["turn_latencies"],
        str(latency_plot_path),
        audio_duration_s=ctx["duration_s"],
        audio_data=ctx["audio_data"],
        sample_rate=ctx["sample_rate"],
    )
    logger.info(_stage(10, "%s") % latency_plot_path.name)


def _stage_11_evaluation_summary(ctx: dict[str, Any]) -> None:
    logger = ctx["logger"]
    pipeline_duration_s = time.perf_counter() - ctx["pipeline_start"]
    if ctx["dump"]:
        write_evaluation_summary_csv(
            str(ctx["out"]),
            ctx["segments"],
            ctx["all_failures"],
            ctx["turn_latencies"],
            ctx["latency_stats"],
        )
        logger.info(_stage(11, "evaluation_summary.csv"))
    logger.info(
        "Completed in %s. %s segments",
        _format_pipeline_duration(pipeline_duration_s),
        len(ctx["segments"]),
    )


def _build_result(ctx: dict[str, Any]) -> dict[str, Any]:
    """Assemble structured evaluation result from pipeline context."""
    all_cutouts: list[dict[str, Any]] = ctx.get("all_cutouts", [])
    total_duration_ms = sum(
        float(c.get("end_ms", 0)) - float(c.get("start_ms", 0))
        for c in all_cutouts
    )
    latency_stats: dict[str, Any] = ctx.get("latency_stats") or {}
    result: dict[str, Any] = {
        "cutout_report": {
            "total_count": len(all_cutouts),
            "total_duration_ms": total_duration_ms,
            "cutouts": all_cutouts,
        },
        "latency_report": {
            **latency_stats,
            "per_turn": [
                {
                    "turn_number": t["turn_number"],
                    "user_start_ms": int(round(t["user_start"] * 1000)) if t.get("user_start") is not None else None,
                    "user_end_ms": int(round(t["user_end"] * 1000)) if t.get("user_end") is not None else None,
                    "agent_start_ms": int(round(t["agent_start"] * 1000)) if t.get("agent_start") is not None else None,
                    "agent_end_ms": int(round(t["agent_end"] * 1000)) if t.get("agent_end") is not None else None,
                    "latency_ms": t.get("total_e2e_latency_ms"),
                }
                for t in ctx.get("turn_latencies", [])
            ],
        },
        "failure_report": {
            "count": len(ctx.get("all_failures", [])),
            "failures": ctx.get("all_failures", []),
        },
    }
    if ctx["dump"]:
        result["output_dir"] = str(ctx["out"])
    return result


def run(
    audio_path: str,
    output_dir: str | None = None,
    log_prefix: str | None = None,
    config_overrides: dict[str, Any] | None = None,
    dump: bool = True,
) -> dict[str, Any]:
    """Run full pipeline: load audio, STT, merge/assign, export, detect, latency, write.

    Interruptible at any stage: Ctrl+C propagates to the CLI (see cli.py).

    Args:
        audio_path: Path to input audio file.
        output_dir: Directory for outputs. Defaults to out/<stem>. Ignored when dump=False.
        log_prefix: When set (e.g. audio filename), prefix all log lines with [log_prefix]
                    so batch runs (./manage evaluate) show which audio each line refers to.
        config_overrides: Optional config overrides (e.g. API keys) merged over defaults and .env.
        dump: When True (CLI default), write CSVs/PNGs/cache to output_dir.
              When False (library default), skip all file I/O and return dict only.

    Returns:
        Dict with cutout_report, latency_report, failure_report.
        When dump=True, also includes output_dir.
    """
    ctx = _setup(audio_path, output_dir, log_prefix, config_overrides=config_overrides, dump=dump)
    _stage_1_load_audio(ctx)
    _stage_2_stt(ctx)
    _stage_3_export_chunks(ctx)
    _stage_4_cutouts(ctx)
    _stage_5_failure_inference(ctx)
    _stage_6_latency(ctx)
    _stage_7_translation(ctx)
    _stage_8_transcript_csv(ctx)
    _stage_9_latency_plot_csv(ctx)
    _stage_10_plot(ctx)
    _stage_11_evaluation_summary(ctx)
    return _build_result(ctx)
