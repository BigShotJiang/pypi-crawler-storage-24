"""Translation to target language (default English) via Gemini.

Uses the same Gemini API and batch defaults as failed-response inference.
Translates segment text in batches and sets text_eng on each segment.
Requires GEMINI_API_KEY.
"""

from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

from google import genai
from google.genai import types

from kulu_audio_eval.utils.gemini_config import (
    GEMINI_BATCH_SIZE,
    GEMINI_MAX_WORKERS,
    GEMINI_MODEL,
    create_gemini_client,
)

log = logging.getLogger(__name__)


def _translate_batch(
    client: genai.Client,
    texts: list[str],
    target_language: str,
) -> list[str]:
    """Call Gemini to translate a batch of texts to target_language.

    Returns a list of translated strings in the same order. Empty input
    returns empty string for that position.
    """
    if not texts:
        return []
    target_desc = "English" if target_language.lower() in ("en", "english") else target_language

    prompt = f"""Translate each of the following lines to {target_desc}. Preserve the same order.
Return ONLY a JSON array of strings, one string per line. For empty or whitespace-only lines, return "" for that element.
Do not add any other text, explanation, or markdown.

Lines:
"""
    for i, t in enumerate(texts):
        prompt += f"{i + 1}. {t}\n"

    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=8192,
            ),
        )
    except Exception:
        log.exception("Gemini translation batch failed")
        return [""] * len(texts)

    raw = (response.text or "").strip()
    # Strip markdown code fence if present
    if raw.startswith("```"):
        lines = raw.split("\n")
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        raw = "\n".join(lines)
    try:
        result = json.loads(raw)
    except (json.JSONDecodeError, TypeError, ValueError):
        log.warning("Gemini translation returned invalid JSON: %s", raw[:200])
        return [""] * len(texts)
    if not isinstance(result, list):
        return [""] * len(texts)
    # Pad or trim to match input length
    out: list[str] = []
    for i in range(len(texts)):
        if i < len(result) and isinstance(result[i], str):
            out.append(result[i].strip())
        else:
            out.append("")
    return out


def translate_segments(
    segments: list[dict],
    config: dict,
) -> None:
    """Translate segment text to target language using Gemini; set text_eng in place.

    Args:
        segments: List of segment dicts with "text". Mutated: each gets "text_eng".
        config: Must contain GEMINI_API_KEY; optional TRANSLATION_TARGET_LANGUAGE
                (default "en"), TRANSLATION_MAX_WORKERS (default from shared config).
    """
    client = create_gemini_client(config)
    if client is None:
        log.warning("GEMINI_API_KEY not set, skipping translation")
        for seg in segments:
            seg["text_eng"] = seg.get("text", "") or ""
        return

    target_language = (config.get("TRANSLATION_TARGET_LANGUAGE") or "en").strip() or "en"
    max_workers = min(
        config.get("TRANSLATION_MAX_WORKERS", GEMINI_MAX_WORKERS),
        max(1, (len(segments) + GEMINI_BATCH_SIZE - 1) // GEMINI_BATCH_SIZE),
    )

    # Build batches: list of (start_index, list of text); batch size from shared config
    batches: list[tuple[int, list[str]]] = []
    for start in range(0, len(segments), GEMINI_BATCH_SIZE):
        batch_texts = [
            (seg.get("text") or "").strip()
            for seg in segments[start : start + GEMINI_BATCH_SIZE]
        ]
        batches.append((start, batch_texts))

    if not batches:
        return

    log.info(
        "Translating %d segments in %d batch(es) to %s",
        len(segments),
        len(batches),
        target_language,
    )

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_translate_batch, client, texts, target_language): (start, texts)
            for start, texts in batches
        }
        for future in as_completed(futures):
            start, _ = futures[future]
            try:
                translated = future.result()
                for k, text_eng in enumerate(translated):
                    if start + k < len(segments):
                        segments[start + k]["text_eng"] = text_eng
            except Exception:
                log.exception(
                    "Translation batch failed for segments %s-%s",
                    start,
                    start + GEMINI_BATCH_SIZE,
                )
                for k in range(GEMINI_BATCH_SIZE):
                    if start + k < len(segments):
                        segments[start + k]["text_eng"] = (
                            segments[start + k].get("text", "") or ""
                        )

    # Ensure any segment without text_eng (e.g. no batch) has a value
    for seg in segments:
        if "text_eng" not in seg:
            seg["text_eng"] = seg.get("text", "") or ""
