# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Standalone priority-chain resolution.

Provides a variadic resolve_value() function that returns the first
non-None value from a sequence of candidates, falling back to a default.
"""

from typing import overload


@overload
def resolve_value[T](*values: T | None, default: T) -> T: ...


@overload
def resolve_value[T](*values: T | None, default: T | None = None) -> T | None: ...


def resolve_value[T](*values: T | None, default: T | None = None) -> T | None:
    """Return the first non-None value, or default.

    Args:
        *values: Candidate values in priority order (highest first).
        default: Final fallback if all candidates are None.

    Returns:
        The first non-None candidate, or default.

    Examples:
        >>> resolve_value("direct", "env", default="fallback")
        'direct'
        >>> resolve_value(None, "env", default="fallback")
        'env'
        >>> resolve_value(None, None, default="fallback")
        'fallback'
    """
    for v in values:
        if v is not None:
            return v
    return default


__all__ = ["resolve_value"]
