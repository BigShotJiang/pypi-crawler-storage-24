# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Type-safe environment variable decoding and configuration resolution."""

from importlib.metadata import version

__version__ = version("vcti-config")

# Concept 1: Priority resolution
# Concept 2: Env decoding (read + convert str -> T)
from .decode import (
    FALSE_VALUES,
    TRUE_VALUES,
    decode_bool,
    decode_float,
    decode_int,
    decode_json,
    decode_path,
    decode_str,
    make_bool_decoder,
    read_env,
)

# Errors (cross-cutting)
from .errors import (
    ConfigError,
    ConfigErrors,
    DecodeError,
    MissingFieldError,
    ValidationError,
)
from .field import MISSING, Field
from .resolve import resolve_value

# Concept 3: Declarative application config (composes 1 + 2)
from .schema import ConfigSchema

__all__ = [
    "__version__",
    "resolve_value",
    "read_env",
    "decode_bool",
    "decode_int",
    "decode_float",
    "decode_str",
    "decode_path",
    "decode_json",
    "make_bool_decoder",
    "TRUE_VALUES",
    "FALSE_VALUES",
    "MISSING",
    "Field",
    "ConfigSchema",
    "ConfigError",
    "ConfigErrors",
    "DecodeError",
    "MissingFieldError",
    "ValidationError",
]
