"""Credential and authentication models."""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class Credentials(BaseModel):
    """Stored SDK credentials.

    Authentication is fingerprint-based: the cert fingerprint is sent as
    `Authorization: Bearer {fingerprint}` on every request. The server looks
    up the credential record by fingerprint and validates its status/expiry.

    Certificate renewal (POST /api/v1/certs/renew) issues a new cert and
    updates api_key to the new fingerprint. No separate refresh token exists.
    """
    api_key: str              # cert fingerprint — used as Bearer token on every request
    api_key_expires_at: datetime  # real cert expiry (7-day cert, renewed at 70% TTL)
    mtls_cert: str            # PEM-encoded certificate (also persisted to cert.pem)
    mtls_private_key: str     # PEM-encoded private key (never leaves SDK host)
    mtls_expires_at: datetime # same as api_key_expires_at — the actual cert expiry
    instance_id: str
    client_id: str
    issued_at: datetime


class BootstrapToken(BaseModel):
    """One-time bootstrap token from dashboard."""
    token: str
    instance_id: str
    expires_at: datetime


class AuthContext(BaseModel):
    """Immutable auth context for requests."""
    client_id: str
    instance_id: str
    api_key: str
    correlation_id: Optional[str] = None
