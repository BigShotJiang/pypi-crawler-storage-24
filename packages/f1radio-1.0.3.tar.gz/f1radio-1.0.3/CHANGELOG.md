# Changelog

All notable changes to this project will be documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-03-21

### Improved

- README: added zsh quoting note for extras install
- README: added context enrichment table
- README: clearer install instructions and requirements
- Added Python 3.14 classifier

## [1.0.0] - 2026-03-21

### Added

- `f1radio.load()` — load any session with fuzzy race matching
- Context enrichment: position, gaps, tyres, lap times, events, overtakes, pit stops
- Smart caching with 30-day auto-cleanup
- Rate-limited API client with circuit breaker and ETag support
- Clip filtering by driver, time window, and lap number
- JSON and CSV export
- Audio playback via optional `[playback]` extra
- CLI: `download`, `info`, `cache list`, `cache clear`
- Request stats via `f1radio.stats`
