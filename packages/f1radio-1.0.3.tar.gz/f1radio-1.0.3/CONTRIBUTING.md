# Contributing

Thanks for your interest in contributing to f1radio.

## Getting Started

```bash
git clone https://github.com/4f4d/f1radio.git
cd f1radio
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest
```

## Guidelines

- Keep API calls minimal — cache everything you can
- Rate limiting must never be weakened
- New features behind optional extras where possible
- Tests for any new functionality

## Reporting Issues

Use [GitHub Issues](https://github.com/4f4d/f1radio/issues). Include:
- Python version
- f1radio version (`f1radio.__version__`)
- What you expected vs what happened

## License

By contributing, you agree that your contributions will be licensed under Apache 2.0.
