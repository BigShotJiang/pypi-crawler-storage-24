# Copyright 2026 4f4d
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Custom exceptions for f1radio."""


class F1RadioError(Exception):
    """Base exception for all f1radio errors."""

    pass


class SessionNotFoundError(F1RadioError):
    """Raised when no matching session is found in the OpenF1 API."""

    def __init__(self, year: int, race: str, session_type: str):
        self.year = year
        self.race = race
        self.session_type = session_type
        super().__init__(
            f"No session found for {year} {race} ({session_type}). "
            f"Check the year (2023+), race name, and session type (R/Q/FP1/FP2/FP3/S/SQ)."
        )


class APIError(F1RadioError):
    """Raised when the OpenF1 API returns an unexpected error."""

    def __init__(self, status_code: int, message: str = ""):
        self.status_code = status_code
        msg = f"OpenF1 API error (HTTP {status_code})"
        if message:
            msg += f": {message}"
        super().__init__(msg)


class CacheError(F1RadioError):
    """Raised when cache read/write operations fail."""

    pass


class PlaybackError(F1RadioError):
    """Raised when audio playback fails or dependency is missing."""

    def __init__(self, message: str = ""):
        if not message:
            message = (
                "Audio playback requires the 'playback' extra. "
                "Install it with: pip install f1radio[playback]"
            )
        super().__init__(message)
