# Copyright 2026 4f4d
# Licensed under the Apache License, Version 2.0

"""Tests for f1radio.models."""

import pytest

from f1radio.models import Clip, ClipContext, ClipList, Session


class TestClipContext:
    def test_default(self):
        ctx = ClipContext()
        assert ctx.position is None
        assert ctx.compound is None
        assert ctx.events == []
        assert ctx.overtakes == []

    def test_to_dict(self):
        ctx = ClipContext(position=1, compound="MEDIUM", tyre_age=12)
        d = ctx.to_dict()
        assert d["position"] == 1
        assert d["compound"] == "MEDIUM"
        assert d["tyre_age"] == 12

    def test_repr(self):
        ctx = ClipContext(position=2, compound="HARD", tyre_age=5)
        r = repr(ctx)
        assert "P2" in r
        assert "HARD" in r


class TestClip:
    def test_to_dict(self):
        clip = Clip(
            driver="VER", driver_number=1, driver_name="Max Verstappen",
            team="Red Bull Racing", time="00:32:15", date="2023-09-03T13:32:15+00:00",
            lap=14, recording_url="https://example.com/ver.mp3", local_path="/tmp/ver.mp3",
            context=ClipContext(position=1, compound="MEDIUM"),
        )
        d = clip.to_dict()
        assert d["driver"] == "VER"
        assert d["context_position"] == 1
        assert d["context_compound"] == "MEDIUM"

    def test_repr(self):
        clip = Clip(
            driver="HAM", driver_number=44, driver_name="Lewis Hamilton",
            team="Mercedes", time="00:45:30", date="2023-09-03T13:45:30+00:00",
            lap=15, recording_url="https://example.com/ham.mp3", local_path="/tmp/ham.mp3",
            context=ClipContext(position=3, compound="SOFT", tyre_age=15),
        )
        r = repr(clip)
        assert "HAM" in r
        assert "00:45:30" in r


class TestClipList:
    def test_filter_by_driver_code(self, sample_session):
        result = sample_session.clips.filter(driver="VER")
        assert len(result) == 2
        assert all(c.driver == "VER" for c in result)

    def test_filter_by_driver_number(self, sample_session):
        result = sample_session.clips.filter(driver=44)
        assert len(result) == 1
        assert result[0].driver == "HAM"

    def test_filter_by_time_range(self, sample_session):
        result = sample_session.clips.filter(after="00:30:00", before="00:50:00")
        assert len(result) == 2

    def test_filter_by_lap(self, sample_session):
        result = sample_session.clips.filter(lap=14)
        assert len(result) == 1
        assert result[0].driver == "VER"

    def test_filter_chaining(self, sample_session):
        result = sample_session.clips.filter(driver="VER").filter(after="01:00:00")
        assert len(result) == 1
        assert result[0].lap == 25

    def test_filter_returns_cliplist(self, sample_session):
        result = sample_session.clips.filter(driver="VER")
        assert isinstance(result, ClipList)

    def test_repr(self, sample_session):
        assert "3 clips" in repr(sample_session.clips)


class TestSession:
    def test_drivers(self, sample_session):
        assert "VER" in sample_session.drivers
        assert "HAM" in sample_session.drivers

    def test_driver_counts(self, sample_session):
        counts = sample_session.driver_counts
        assert counts["VER"] == 2
        assert counts["HAM"] == 1

    def test_time_range(self, sample_session):
        tr = sample_session.time_range
        assert tr[0] == "00:32:15"
        assert tr[1] == "01:10:00"

    def test_len(self, sample_session):
        assert len(sample_session) == 3

    def test_repr(self, sample_session):
        r = repr(sample_session)
        assert "Italian Grand Prix" in r
        assert "3 clips" in r
