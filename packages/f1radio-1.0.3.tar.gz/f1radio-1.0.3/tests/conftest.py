# Copyright 2026 4f4d
# Licensed under the Apache License, Version 2.0

"""Shared fixtures and mock data for f1radio tests."""

from __future__ import annotations

import pytest
from datetime import datetime, timezone


# ── Mock API Responses ───────────────────────────────────────────────────

MOCK_MEETINGS = [
    {
        "meeting_key": 1219,
        "meeting_name": "Italian Grand Prix",
        "meeting_official_name": "FORMULA 1 PIRELLI GRAN PREMIO D'ITALIA 2023",
        "country_name": "Italy",
        "circuit_short_name": "Monza",
        "year": 2023,
    },
    {
        "meeting_key": 1220,
        "meeting_name": "Singapore Grand Prix",
        "meeting_official_name": "FORMULA 1 SINGAPORE AIRLINES SINGAPORE GRAND PRIX 2023",
        "country_name": "Singapore",
        "circuit_short_name": "Marina Bay",
        "year": 2023,
    },
]

MOCK_SESSIONS = [
    {
        "session_key": 9158,
        "meeting_key": 1219,
        "session_name": "Race",
        "session_type": "Race",
        "date_start": "2023-09-03T13:00:00+00:00",
        "date_end": "2023-09-03T15:00:00+00:00",
        "year": 2023,
    },
]

MOCK_DRIVERS = [
    {
        "driver_number": 1,
        "name_acronym": "VER",
        "full_name": "Max Verstappen",
        "team_name": "Red Bull Racing",
        "session_key": 9158,
    },
    {
        "driver_number": 44,
        "name_acronym": "HAM",
        "full_name": "Lewis Hamilton",
        "team_name": "Mercedes",
        "session_key": 9158,
    },
    {
        "driver_number": 4,
        "name_acronym": "NOR",
        "full_name": "Lando Norris",
        "team_name": "McLaren",
        "session_key": 9158,
    },
]

MOCK_RADIO = [
    {
        "meeting_key": 1219,
        "session_key": 9158,
        "driver_number": 1,
        "date": "2023-09-03T13:32:15.000000+00:00",
        "recording_url": "https://livetiming.formula1.com/static/2023/test/VER01.mp3",
    },
    {
        "meeting_key": 1219,
        "session_key": 9158,
        "driver_number": 44,
        "date": "2023-09-03T13:45:30.000000+00:00",
        "recording_url": "https://livetiming.formula1.com/static/2023/test/HAM01.mp3",
    },
    {
        "meeting_key": 1219,
        "session_key": 9158,
        "driver_number": 1,
        "date": "2023-09-03T14:10:00.000000+00:00",
        "recording_url": "https://livetiming.formula1.com/static/2023/test/VER02.mp3",
    },
]

MOCK_POSITION = [
    {"driver_number": 1, "position": 1, "date": "2023-09-03T13:32:10.000000+00:00"},
    {"driver_number": 44, "position": 3, "date": "2023-09-03T13:32:10.000000+00:00"},
    {"driver_number": 1, "position": 2, "date": "2023-09-03T14:09:55.000000+00:00"},
    {"driver_number": 44, "position": 2, "date": "2023-09-03T13:45:25.000000+00:00"},
]

MOCK_INTERVALS = [
    {
        "driver_number": 1,
        "gap_to_leader": 0,
        "interval": 0,
        "date": "2023-09-03T13:32:12.000000+00:00",
    },
    {
        "driver_number": 44,
        "gap_to_leader": 5.432,
        "interval": 1.234,
        "date": "2023-09-03T13:45:28.000000+00:00",
    },
]

MOCK_STINTS = [
    {
        "driver_number": 1,
        "stint_number": 1,
        "compound": "MEDIUM",
        "lap_start": 1,
        "lap_end": 20,
        "tyre_age_at_n_laps": 0,
    },
    {
        "driver_number": 1,
        "stint_number": 2,
        "compound": "HARD",
        "lap_start": 21,
        "lap_end": None,
        "tyre_age_at_n_laps": 0,
    },
    {
        "driver_number": 44,
        "stint_number": 1,
        "compound": "SOFT",
        "lap_start": 1,
        "lap_end": 15,
        "tyre_age_at_n_laps": 0,
    },
]

MOCK_LAPS = [
    {
        "driver_number": 1,
        "lap_number": 14,
        "lap_duration": 92.456,
        "date": "2023-09-03T13:32:00.000000+00:00",
    },
    {
        "driver_number": 44,
        "lap_number": 15,
        "lap_duration": 91.234,
        "date": "2023-09-03T13:45:00.000000+00:00",
    },
    {
        "driver_number": 1,
        "lap_number": 25,
        "lap_duration": 93.100,
        "date": "2023-09-03T14:09:30.000000+00:00",
    },
]

MOCK_RACE_CONTROL = [
    {
        "category": "Flag",
        "flag": "YELLOW",
        "message": "YELLOW FLAG IN SECTOR 2",
        "scope": "Sector",
        "sector": 2,
        "date": "2023-09-03T13:32:12.000000+00:00",
    },
    {
        "category": "SafetyCar",
        "flag": "SAFETY CAR",
        "message": "SAFETY CAR DEPLOYED",
        "scope": "Track",
        "sector": None,
        "date": "2023-09-03T14:00:00.000000+00:00",
    },
]

MOCK_OVERTAKES = [
    {
        "overtaking_driver_number": 1,
        "overtaken_driver_number": 4,
        "position": 2,
        "date": "2023-09-03T13:32:18.000000+00:00",
    },
]

MOCK_PIT = [
    {
        "driver_number": 44,
        "pit_duration": 23.5,
        "lap_number": 15,
        "date": "2023-09-03T13:45:35.000000+00:00",
    },
]


# ── Fixtures ─────────────────────────────────────────────────────────────

@pytest.fixture
def mock_drivers():
    return MOCK_DRIVERS


@pytest.fixture
def mock_radio():
    return MOCK_RADIO


@pytest.fixture
def mock_context():
    return {
        "drivers": MOCK_DRIVERS,
        "position": MOCK_POSITION,
        "intervals": MOCK_INTERVALS,
        "stints": MOCK_STINTS,
        "laps": MOCK_LAPS,
        "race_control": MOCK_RACE_CONTROL,
        "overtakes": MOCK_OVERTAKES,
        "pit": MOCK_PIT,
    }


@pytest.fixture
def sample_session():
    """Build a sample Session for testing."""
    from f1radio.models import Session, Clip, ClipList, ClipContext

    clips = ClipList([
        Clip(
            driver="VER", driver_number=1, driver_name="Max Verstappen",
            team="Red Bull Racing", time="00:32:15", date="2023-09-03T13:32:15+00:00",
            lap=14, recording_url="https://example.com/ver1.mp3", local_path="/tmp/ver1.mp3",
            context=ClipContext(position=1, compound="MEDIUM", tyre_age=14, gap_to_leader="Leader"),
        ),
        Clip(
            driver="HAM", driver_number=44, driver_name="Lewis Hamilton",
            team="Mercedes", time="00:45:30", date="2023-09-03T13:45:30+00:00",
            lap=15, recording_url="https://example.com/ham1.mp3", local_path="/tmp/ham1.mp3",
            context=ClipContext(position=3, compound="SOFT", tyre_age=15, gap_to_leader="+5.432s"),
        ),
        Clip(
            driver="VER", driver_number=1, driver_name="Max Verstappen",
            team="Red Bull Racing", time="01:10:00", date="2023-09-03T14:10:00+00:00",
            lap=25, recording_url="https://example.com/ver2.mp3", local_path="/tmp/ver2.mp3",
            context=ClipContext(position=2, compound="HARD", tyre_age=5, gap_to_leader="+1.234s"),
        ),
    ])

    return Session(
        year=2023,
        race="Italian Grand Prix",
        session_type="Race",
        session_key=9158,
        meeting_key=1219,
        clips=clips,
    )
