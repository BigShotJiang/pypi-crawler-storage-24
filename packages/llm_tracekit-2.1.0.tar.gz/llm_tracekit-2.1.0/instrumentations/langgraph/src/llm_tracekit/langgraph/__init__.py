# Copyright Coralogix Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""LangGraph OpenTelemetry instrumentation entrypoint."""

from llm_tracekit.langgraph.instrumentor import (
    LangGraphInstrumentor as LangGraphInstrumentor,
)

from llm_tracekit.core import (
    enable_capture_content as enable_capture_content,
    setup_export_to_coralogix as setup_export_to_coralogix,
    OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT as OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT,
)
