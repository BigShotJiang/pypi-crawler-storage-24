"""Channels API module."""

from __future__ import annotations

from typing import Any


class ChannelsAPI:
    """Sync channels API."""

    def __init__(self, client: Any):
        self._client = client

    def get_info(self, channel_id: str) -> dict[str, Any]:
        """
        Get information about a YouTube channel.

        Args:
            channel_id: YouTube channel ID (UC...) or handle (@...)

        Returns:
            Dict with channel metadata.
        """
        return self._client._request("GET", f"/v1/channels/{channel_id}")

    def get_videos(
        self,
        channel_id: str,
        limit: int = 20,
        offset: int = 0,
        include_shorts: bool = True,
    ) -> dict[str, Any]:
        """
        Get videos from a YouTube channel.

        Args:
            channel_id: YouTube channel ID
            limit: Maximum number of videos (1-50, default: 20)
            offset: Number of videos to skip for pagination
            include_shorts: Whether to include YouTube Shorts

        Returns:
            Dict with videos list, total_count, and has_more.
        """
        params = _build_videos_params(limit, offset, include_shorts)
        return self._client._request("GET", f"/v1/channels/{channel_id}/videos", params=params)

    def get_all_videos(
        self,
        channel_id: str,
        include_shorts: bool = True,
        max_videos: int = 500,
    ) -> list[dict[str, Any]]:
        """
        Get all videos from a channel with automatic pagination.

        Args:
            channel_id: YouTube channel ID
            include_shorts: Whether to include YouTube Shorts
            max_videos: Maximum total videos to fetch (default: 500)

        Returns:
            List of video dicts.
        """
        all_videos: list[dict[str, Any]] = []
        offset = 0
        limit = 50

        while len(all_videos) < max_videos:
            result = self.get_videos(
                channel_id,
                limit=min(limit, max_videos - len(all_videos)),
                offset=offset,
                include_shorts=include_shorts,
            )
            videos = result.get("videos", [])
            all_videos.extend(videos)
            if not result.get("has_more") or not videos:
                break
            offset += len(videos)

        return all_videos


class AsyncChannelsAPI:
    """Async channels API."""

    def __init__(self, client: Any):
        self._client = client

    async def get_info(self, channel_id: str) -> dict[str, Any]:
        """Get information about a YouTube channel."""
        return await self._client._request("GET", f"/v1/channels/{channel_id}")

    async def get_videos(
        self,
        channel_id: str,
        limit: int = 20,
        offset: int = 0,
        include_shorts: bool = True,
    ) -> dict[str, Any]:
        """Get videos from a YouTube channel."""
        params = _build_videos_params(limit, offset, include_shorts)
        return await self._client._request(
            "GET", f"/v1/channels/{channel_id}/videos", params=params
        )

    async def get_all_videos(
        self,
        channel_id: str,
        include_shorts: bool = True,
        max_videos: int = 500,
    ) -> list[dict[str, Any]]:
        """Get all videos from a channel with automatic pagination."""
        all_videos: list[dict[str, Any]] = []
        offset = 0
        limit = 50

        while len(all_videos) < max_videos:
            result = await self.get_videos(
                channel_id,
                limit=min(limit, max_videos - len(all_videos)),
                offset=offset,
                include_shorts=include_shorts,
            )
            videos = result.get("videos", [])
            all_videos.extend(videos)
            if not result.get("has_more") or not videos:
                break
            offset += len(videos)

        return all_videos


def _build_videos_params(
    limit: int, offset: int, include_shorts: bool
) -> dict[str, Any] | None:
    params: dict[str, Any] = {}
    if limit != 20:
        params["limit"] = limit
    if offset > 0:
        params["offset"] = offset
    if not include_shorts:
        params["include_shorts"] = "false"
    return params or None
