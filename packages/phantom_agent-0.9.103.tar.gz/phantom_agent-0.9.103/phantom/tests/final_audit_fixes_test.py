"""Verification tests for final audit systemic bugs.

Run with: python -m pytest phantom/tests/final_audit_fixes_test.py -v
"""
import os
import sys
from pathlib import Path

import pytest

PHANTOM_SRC = Path(__file__).parent.parent


class TestBaseAgentTimeout:
    """Test max_iterations timeout properly fails task."""

    def test_max_iterations_sets_failure(self):
        from phantom.agents.state import AgentState
        
        state = AgentState(
            agent_id="test",
            agent_name="Test",
            task="Test",
            max_iterations=1,
            parent_id=None
        )
        state.increment_iteration() # now 1/1, has_reached_max_iterations() is True
        
        # Manually invoke the logic block inside agent_loop
        assert state.should_stop() is True
        assert state.completed is False
        
        # Simulate the logic we added
        if state.should_stop():
            if not state.completed and state.has_reached_max_iterations():
                state.set_completed({"success": False, "error": "Max iterations reached"})
        
        assert state.completed is True
        assert state.final_result.get("success") is False
        assert "Max iterations" in state.final_result.get("error")


class TestDedupeCredentials:
    """Test cross-provider dedupe credentials routing logic."""

    def test_dedupe_model_uses_dedupe_api_key(self):
        import ast
        import inspect
        from phantom.llm import dedupe
        
        src = inspect.getsource(dedupe.check_duplicate) if hasattr(dedupe, "check_duplicate") else ""
        if not src:
            with open(dedupe.__file__, "r") as f:
                src = f.read()
                
        assert "phantom_dedupe_api_key" in src, "Dedupe logic must check for distinct API keys for cross-provider configs"
        assert "phantom_dedupe_api_base" in src, "Dedupe logic must check for distinct API bases for cross-provider configs"


class TestDockerFirewall:
    """Test Docker Firewall rules."""
    
    def test_docker_firewall_no_broad_networks(self):
        from phantom.runtime.docker_runtime import DockerRuntime
        import inspect
        src = inspect.getsource(DockerRuntime._configure_scope_firewall)
        assert "172.0.0.0/8" not in src, "Broad Docker bridge 172.0.0.0/8 should not be allowed"
        assert "10.0.0.0/8" not in src, "Broad Docker bridge 10.0.0.0/8 should not be allowed"
        assert "container.attrs.get('NetworkSettings', {})" in src or "container.attrs.get(\"NetworkSettings\", {})" in src, "Must fetch specific gateway from container attributes"


class TestPythonSandbox:
    """Test thread DoS and AST bypass in python tool."""

    def test_ast_sandbox_bypass_blocked(self, monkeypatch):
        import os
        monkeypatch.setattr(os, "chdir", lambda path: None)
        from phantom.tools.python.python_instance import PythonInstance
        instance = PythonInstance(session_id="test_ast")
        
        payloads = [
            '__builtins__["__import__"]("os")',
            'getattr(__builtins__["__import__"]("os"), "system")("id")',
            'setattr(object, "x", 1)',
        ]
        
        for p in payloads:
            err = instance._validate_code_safety(p)
            assert err is not None, f"Payload should be blocked: {p}"

    def test_thread_leak_dos_fixed(self, monkeypatch):
        import os
        monkeypatch.setattr(os, "chdir", lambda path: None)
        from phantom.tools.python.python_instance import PythonInstance
        instance = PythonInstance(session_id="test_dos")
        
        # This infinite loop would previously hang the lock forever
        infinite_loop_code = "while True: pass"
        res1 = instance.execute_code(infinite_loop_code, timeout=1)
        
        assert "timed out" in res1["stderr"].lower() or "timeout" in res1["stderr"].lower()
        
        # If lock is leaked, this second execution will hang indefinitely.
        # It should complete instantly because the lock was released by Thread Exit via ctypes.
        res2 = instance.execute_code("print('survived')", timeout=2)
        assert "timed out" not in res2.get("stderr", "").lower(), "Global _STDOUT_REDIRECT_LOCK was leaked causing subsequent executions to hang!"

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
