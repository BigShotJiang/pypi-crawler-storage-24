"""C1: Hypothesis ledger tool — gives the LLM direct control over hypothesis tracking.

Wires the HypothesisLedger (which was previously dead code — built but never exposed
as a tool) to a `manage_hypothesis` tool the agent can call to track what it has tested,
record results, and avoid redundant payloads.
"""

from typing import Any

from phantom.tools.registry import register_tool


# Module-level ledger reference, set by BaseAgent during initialization.
_ledger = None


def set_ledger(ledger: Any) -> None:
    """Called by BaseAgent to inject the hypothesis ledger instance."""
    global _ledger
    _ledger = ledger


@register_tool(sandbox_execution=False)
def manage_hypothesis(
    action: str,
    surface: str = "",
    vuln_class: str = "",
    hypothesis_id: str = "",
    payload: str = "",
    outcome: str = "",
    evidence: str = "",
) -> dict[str, Any]:
    """Track testing hypotheses to avoid redundant work.

    Actions:
        add       — Register a new hypothesis (requires: surface, vuln_class)
        payload   — Record a payload attempt (requires: hypothesis_id, payload)
        result    — Record test outcome (requires: hypothesis_id, outcome, evidence)
        status    — Show current ledger summary (no args needed)

    Args:
        action:        One of: add, payload, result, status
        surface:       Attack surface identifier (e.g. "/api/login POST username")
        vuln_class:    Vulnerability class (e.g. "SQL_INJECTION", "XSS", "IDOR")
        hypothesis_id: ID returned from 'add' action
        payload:       Payload string that was tested
        outcome:       Test result: "confirmed", "rejected", "inconclusive"
        evidence:      Supporting evidence for the outcome

    Returns:
        dict with 'success' and relevant data fields.
    """
    try:
        if not action or not action.strip():
            return {"success": False, "message": "action is required (add/payload/result/status)"}

        action = action.strip().lower()

        if _ledger is None:
            # Graceful degradation: ledger not wired yet, act as no-op
            return {
                "success": True,
                "message": "Hypothesis noted (ledger not yet initialized).",
                "action": action,
            }

        if action == "add":
            if not surface or not vuln_class:
                return {"success": False, "message": "surface and vuln_class are required for 'add'"}
            hyp_id = _ledger.add(surface.strip(), vuln_class.strip())
            return {
                "success": True,
                "hypothesis_id": hyp_id,
                "message": f"Hypothesis registered: {vuln_class} on {surface}",
            }

        elif action == "payload":
            if not hypothesis_id or not payload:
                return {"success": False, "message": "hypothesis_id and payload are required for 'payload'"}
            _ledger.record_payload(hypothesis_id.strip(), payload.strip())
            return {
                "success": True,
                "hypothesis_id": hypothesis_id.strip(),
                "message": f"Payload recorded for hypothesis {hypothesis_id}",
            }

        elif action == "result":
            if not hypothesis_id or not outcome:
                return {"success": False, "message": "hypothesis_id and outcome are required for 'result'"}
            _ledger.record_result(
                hypothesis_id.strip(),
                outcome.strip(),
                evidence.strip() if evidence else "",
            )
            return {
                "success": True,
                "hypothesis_id": hypothesis_id.strip(),
                "outcome": outcome.strip(),
                "message": f"Result '{outcome}' recorded for hypothesis {hypothesis_id}",
            }

        elif action == "status":
            summary = _ledger.to_prompt_summary(top_n=20)
            return {
                "success": True,
                "summary": summary or "No hypotheses recorded yet.",
                "total_hypotheses": len(getattr(_ledger, "_hypotheses", {})),
            }

        else:
            return {
                "success": False,
                "message": f"Unknown action '{action}'. Use: add, payload, result, status",
            }

    except (ValueError, TypeError, KeyError, AttributeError) as e:
        return {"success": False, "message": f"Hypothesis operation failed: {e!s}"}
