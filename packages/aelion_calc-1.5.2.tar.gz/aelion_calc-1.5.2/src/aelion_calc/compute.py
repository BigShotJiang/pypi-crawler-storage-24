import numpy as np

# Try to import PyOpenCL, but don't crash if the user hasn't installed it yet
try:
    import pyopencl as cl
    HAS_GPU = True
except ImportError:
    HAS_GPU = False

class GPUCompute:
    """
    Hardware-agnostic GPU computing engine.
    Detects the best available device and compiles raw C for it.
    """
    def __init__(self):
        self.available = HAS_GPU
        if not self.available:
            return
            
        # 1. Detect Hardware (Find a GPU if possible)
        platforms = cl.get_platforms()
        device = platforms[0].get_devices()[0] # Fallback to first device
        
        for p in platforms:
            for d in p.get_devices():
                if cl.device_type.to_string(d.type) == 'GPU':
                    device = d
                    break
                    
        print(f"Hardware Acceleration Target: {device.name}")
                    
        self.ctx = cl.Context([device])
        self.queue = cl.CommandQueue(self.ctx)
        
        # 2. The Raw C-Kernel (Runs on the GPU threads)
        kernel_code = """
        __kernel void matmul(
            const int M, const int N, const int K,
            __global const float* A,
            __global const float* B,
            __global float* C) 
        {
            // The GPU spawns thousands of threads, each grabs its own row/col
            int row = get_global_id(0);
            int col = get_global_id(1);
            
            // Prevent calculating outside matrix boundaries
            if (row < M && col < N) {
                float sum = 0.0f;
                for (int k = 0; k < K; ++k) {
                    sum += A[row * K + k] * B[k * N + col];
                }
                C[row * N + col] = sum;
            }
        }
        """
        # Compile the C code for the specific hardware
        self.prg = cl.Program(self.ctx, kernel_code).build()
        
        # THE FIX: Cache the kernel object so it is only retrieved once
        self.matmul_kernel = cl.Kernel(self.prg, "matmul")

    def dot(self, A_np, B_np):
        if not self.available:
            raise RuntimeError("PyOpenCL is not installed.")
            
        # GPU math is fastest using 32-bit floats
        A_np = A_np.astype(np.float32)
        B_np = B_np.astype(np.float32)
        
        M, K = A_np.shape
        K2, N = B_np.shape
        C_np = np.empty((M, N), dtype=np.float32)
        
        # 3. Move RAM to GPU VRAM
        mf = cl.mem_flags
        A_g = cl.Buffer(self.ctx, mf.READ_ONLY | mf.COPY_HOST_PTR, hostbuf=A_np)
        B_g = cl.Buffer(self.ctx, mf.READ_ONLY | mf.COPY_HOST_PTR, hostbuf=B_np)
        C_g = cl.Buffer(self.ctx, mf.WRITE_ONLY, C_np.nbytes)
        
        # 4. Execute the C-Kernel (Grid size is M x N)
        self.matmul_kernel(self.queue, (M, N), None, 
                           np.int32(M), np.int32(N), np.int32(K), 
                           A_g, B_g, C_g)
                        
        # 5. Move VRAM back to RAM
        cl.enqueue_copy(self.queue, C_np, C_g)
        return C_np

# Create a global instance so it only compiles the C-code once
gpu_engine = GPUCompute()