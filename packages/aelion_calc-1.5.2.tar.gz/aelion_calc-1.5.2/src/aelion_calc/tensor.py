import numpy as np
from .compute import gpu_engine
from .fast_tensor import cpu_matmul

class Tensor:
    """
    Enterprise Tensor Engine.
    Wraps C++ / GPU memory blocks to perform Matrix Calculus for Autograd.
    Eliminates the 10GB Python object memory bottleneck.
    """
    def __init__(self, data, _children=(), _op='', requires_grad=True):
        # Force 32-bit floats for maximum GPU compatibility and memory savings
        self.data = np.array(data, dtype=np.float32)
        self.grad = np.zeros_like(self.data)
        self._backward = lambda: None
        self._prev = set(_children)
        self._op = _op
        self.requires_grad = requires_grad
        self.shape = self.data.shape

    def __repr__(self):
        return f"Tensor(shape={self.shape}, op={self._op})"

    # ==========================================
    # 1. CORE MATH OPERATIONS
    # ==========================================
    
    def __add__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data + other.data, (self, other), '+')

        def _backward():
            # Handle broadcasting (if we added a bias vector to a matrix)
            if self.requires_grad:
                self.grad += unbroadcast(out.grad, self.shape)
            if other.requires_grad:
                other.grad += unbroadcast(out.grad, other.shape)
        out._backward = _backward
        return out

    def __mul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data * other.data, (self, other), '*')

        def _backward():
            if self.requires_grad:
                self.grad += unbroadcast(other.data * out.grad, self.shape)
            if other.requires_grad:
                other.grad += unbroadcast(self.data * out.grad, other.shape)
        out._backward = _backward
        return out

    def __pow__(self, other):
        assert isinstance(other, (int, float)), "only supporting int/float powers"
        out = Tensor(self.data ** other, (self,), f'**{other}')

        def _backward():
            if self.requires_grad:
                self.grad += (other * self.data**(other-1)) * out.grad
        out._backward = _backward
        return out

    # ==========================================
    # 2. HARDWARE-ACCELERATED MATRIX MULTIPLICATION
    # ==========================================

    def dot(self, other):
        """
        The heavy lifter. Connects directly to Intel Iris GPU or Multi-Core CPU.
        """
        other = other if isinstance(other, Tensor) else Tensor(other)
        
        # 1. Hardware Routing
        if len(self.shape) == 2 and len(other.shape) == 2:
            if gpu_engine.available:
                out_data = gpu_engine.dot(self.data, other.data)
            else:
                out_data = cpu_matmul(self.data, other.data)
        else:
            # Fallback for higher dimensions (e.g. Batched Matmul)
            out_data = np.matmul(self.data, other.data)

        out = Tensor(out_data, (self, other), 'dot')

        # 2. Matrix Calculus Backpropagation
        def _backward():
            if self.requires_grad:
                # dL/dA = dL/dC @ B.T
                grad_self = np.matmul(out.grad, other.data.swapaxes(-1, -2))
                self.grad += unbroadcast(grad_self, self.shape)
            if other.requires_grad:
                # dL/dB = A.T @ dL/dC
                grad_other = np.matmul(self.data.swapaxes(-1, -2), out.grad)
                other.grad += unbroadcast(grad_other, other.shape)
        out._backward = _backward
        return out

    # ==========================================
    # 3. LLM SPECIFIC OPERATIONS
    # ==========================================

    def exp(self):
        out = Tensor(np.exp(self.data), (self,), 'exp')
        def _backward():
            if self.requires_grad:
                self.grad += out.data * out.grad
        out._backward = _backward
        return out

    def sum(self, axis=None, keepdims=False):
        out = Tensor(np.sum(self.data, axis=axis, keepdims=keepdims), (self,), 'sum')
        def _backward():
            if self.requires_grad:
                # Gradient of sum distributes evenly
                self.grad += np.ones_like(self.data) * out.grad
        out._backward = _backward
        return out

    def max(self, axis=None, keepdims=False):
        out = Tensor(np.max(self.data, axis=axis, keepdims=keepdims), (self,), 'max')
        def _backward():
            if self.requires_grad:
                # Gradient only flows to the maximum values
                mask = (self.data == out.data)
                self.grad += mask * out.grad
        out._backward = _backward
        return out

    def transpose(self):
        out = Tensor(self.data.T, (self,), 'transpose')
        def _backward():
            if self.requires_grad:
                self.grad += out.grad.T
        out._backward = _backward
        return out
    def log(self):
        # Adding a tiny epsilon (1e-8) prevents log(0) crashes
        out = Tensor(np.log(self.data + 1e-8), (self,), 'log')
        def _backward():
            if self.requires_grad:
                self.grad += (1.0 / (self.data + 1e-8)) * out.grad
        out._backward = _backward
        return out

    def tanh(self):
        t = np.tanh(self.data)
        out = Tensor(t, (self,), 'tanh')
        def _backward():
            if self.requires_grad:
                self.grad += (1.0 - t**2) * out.grad
        out._backward = _backward
        return out

    # ==========================================
    # 4. THE AUTOGRAD ENGINE
    # ==========================================

    def backward(self):
        """Topological sort for Matrix Backpropagation."""
        topo = []
        visited = set()
        def build_topo(v):
            if v not in visited:
                visited.add(v)
                for child in v._prev:
                    build_topo(child)
                topo.append(v)
        build_topo(self)

        # Go one variable at a time and apply the chain rule
        self.grad = np.ones_like(self.data)
        for v in reversed(topo):
            v._backward()

    # Python Magic Methods for ease of use
    def __neg__(self): return self * -1
    def __sub__(self, other): return self + (-other)
    def __radd__(self, other): return self + other
    def __rmul__(self, other): return self * other
    def __truediv__(self, other): return self * (other**-1)


# --- Helper Function for Matrix Calculus ---
def unbroadcast(grad, target_shape):
    """
    When adding a vector to a matrix (like biases), NumPy 'broadcasts' the vector.
    During backprop, we have to sum those gradients back down to the original vector shape.
    """
    if grad.shape == target_shape:
        return grad
    
    # Sum out the added dimensions
    ndims_added = len(grad.shape) - len(target_shape)
    for _ in range(ndims_added):
        grad = grad.sum(axis=0)
        
    # Sum across dimensions that were stretched from 1
    for i, dim in enumerate(target_shape):
        if dim == 1:
            grad = grad.sum(axis=i, keepdims=True)
            
    return grad