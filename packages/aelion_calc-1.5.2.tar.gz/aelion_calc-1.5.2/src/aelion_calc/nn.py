import math
import random
from .aly import Value  # Importing your core autograd engine

# ==========================================
# 1. THE BASE CLASS (The PyTorch Secret)
# ==========================================

class Module:
    """
    The Master Class. Every neural network layer inherits from this.
    It automatically searches for 'Value' objects and registers them as parameters.
    """
    def __init__(self):
        self.training = True

    def parameters(self):
        params = []
        def _scan(obj):
            if isinstance(obj, Value):
                params.append(obj)
            elif isinstance(obj, Module):
                params.extend(obj.parameters())
            elif isinstance(obj, list):
                for item in obj: _scan(item)
            elif isinstance(obj, tuple):
                for item in obj: _scan(item)
        
        for k, v in self.__dict__.items():
            _scan(v)
        return params

    def zero_grad(self):
        for p in self.parameters():
            p.grad = 0.0

    def train(self, mode=True):
        """Switches behavior for layers like Dropout and BatchNorm."""
        self.training = mode
        for k, v in self.__dict__.items():
            if isinstance(v, Module): v.train(mode)
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, Module): item.train(mode)

    def eval(self):
        self.train(False)

# ==========================================
# 2. ADVANCED ACTIVATIONS
# ==========================================

class ReLU(Module):
    def __call__(self, x):
        return [xi.relu() for xi in x] if isinstance(x, list) else x.relu()

class LeakyReLU(Module):
    """Allows a small gradient when inactive to prevent 'dead neurons'."""
    def __init__(self, negative_slope=0.01):
        super().__init__()
        self.slope = negative_slope

    def __call__(self, x):
        def _lrelu(val):
            return val if val.data > 0 else val * self.slope
        return [_lrelu(xi) for xi in x] if isinstance(x, list) else _lrelu(x)

class GELU(Module):
    """
    The Gaussian Error Linear Unit. 
    This is the exact activation function used inside ChatGPT and Llama 3!
    """
    def __call__(self, x):
        def _gelu(val):
            # Formula: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
            inner = (val + (val**3) * 0.044715) * math.sqrt(2.0 / math.pi)
            return val * 0.5 * (inner.tanh() + 1.0)
        return [_gelu(xi) for xi in x] if isinstance(x, list) else _gelu(x)

class Tanh(Module):
    def __call__(self, x):
        return [xi.tanh() for xi in x] if isinstance(x, list) else x.tanh()

# ==========================================
# 3. LINEAR LAYERS (Dense)
# ==========================================

class Linear(Module):
    """
    Replaces the old 'Neuron/Layer' setup with a high-performance Dense layer.
    Uses Kaiming/He Initialization for deep network stability.
    """
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        
        # Kaiming Initialization (prevents vanishing gradients in deep nets)
        bound = math.sqrt(2.0 / in_features)
        
        self.weight = [[Value(random.uniform(-bound, bound)) for _ in range(in_features)] 
                       for _ in range(out_features)]
        
        self.bias = [Value(0.0) for _ in range(out_features)] if bias else None

    def __call__(self, x):
        out = []
        for i in range(self.out_features):
            act = sum((w * xi for w, xi in zip(self.weight[i], x)), Value(0.0))
            if self.bias:
                act += self.bias[i]
            out.append(act)
        return out

# ==========================================
# 4. NORMALIZATION & REGULARIZATION
# ==========================================

class LayerNorm(Module):
    def __init__(self, dim, eps=1e-5):
        super().__init__()
        self.eps = eps
        self.gamma = [Value(1.0) for _ in range(dim)]
        self.beta = [Value(0.0) for _ in range(dim)]

    def __call__(self, x):
        mean = sum(x) / len(x)
        var = sum((xi - mean)**2 for xi in x) / len(x)
        std_inv = 1.0 / math.sqrt(var.data + self.eps)
        
        out = []
        for i, xi in enumerate(x):
            x_norm = (xi - mean) * std_inv
            out.append(self.gamma[i] * x_norm + self.beta[i])
        return out

class Dropout(Module):
    def __init__(self, p=0.5):
        super().__init__()
        self.p = p

    def __call__(self, x):
        if not self.training: return x
        
        out = []
        scale = 1.0 / (1.0 - self.p)
        for xi in x:
            if random.random() < self.p:
                out.append(Value(0.0))
            else:
                out.append(xi * scale)
        return out
class BatchNorm1d(Module):
    """
    Enterprise standard for CNNs and Deep MLPs.
    Normalizes data across the batch, accelerating training by 10x.
    Tracks running statistics for production inference.
    """
    def __init__(self, num_features, eps=1e-5, momentum=0.1):
        super().__init__()
        self.eps = eps
        self.momentum = momentum
        self.gamma = [Value(1.0) for _ in range(num_features)]
        self.beta = [Value(0.0) for _ in range(num_features)]
        
        # Running stats don't get gradients; they just track history
        self.running_mean = [0.0] * num_features
        self.running_var = [1.0] * num_features

    def __call__(self, x_batch):
        # x_batch is a list of lists: [Batch_Size, Features]
        if not self.training:
            # During eval/production, use the frozen running stats
            out_batch = []
            for x in x_batch:
                row = []
                for i, xi in enumerate(x):
                    norm = (xi - self.running_mean[i]) / math.sqrt(self.running_var[i] + self.eps)
                    row.append(self.gamma[i] * norm + self.beta[i])
                out_batch.append(row)
            return out_batch

        # During training: calculate batch statistics
        batch_size = len(x_batch)
        num_feats = len(x_batch[0])
        
        batch_mean = [sum(x[i] for x in x_batch) / batch_size for i in range(num_feats)]
        batch_var = [sum((x[i] - batch_mean[i])**2 for x in x_batch) / batch_size for i in range(num_feats)]
        
        # Update running stats (momentum)
        for i in range(num_feats):
            # Using .data to extract raw float for tracking
            b_m = batch_mean[i].data if isinstance(batch_mean[i], Value) else batch_mean[i]
            b_v = batch_var[i].data if isinstance(batch_var[i], Value) else batch_var[i]
            self.running_mean[i] = (1 - self.momentum) * self.running_mean[i] + self.momentum * b_m
            self.running_var[i] = (1 - self.momentum) * self.running_var[i] + self.momentum * b_v

        # Normalize and Scale
        out_batch = []
        for x in x_batch:
            row = []
            for i, xi in enumerate(x):
                norm = (xi - batch_mean[i]) * (1.0 / math.sqrt(batch_var[i].data + self.eps))
                row.append(self.gamma[i] * norm + self.beta[i])
            out_batch.append(row)
            
        return out_batch
# ==========================================
# 5. RECURRENT LAYERS (Time & Sequence)
# ==========================================

class RNNCell(Module):
    """Basic Recurrent Memory Cell for Time-Series forecasting."""
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
        self.i2h = Linear(input_size, hidden_size)
        self.h2h = Linear(hidden_size, hidden_size)

    def __call__(self, x, hidden):
        # New Hidden = Tanh( W_ix * X + W_hh * H )
        combined = [i + h for i, h in zip(self.i2h(x), self.h2h(hidden))]
        return [c.tanh() for c in combined]

class LSTMCell(Module):
    """
    Advanced Memory Cell with Forget/Input/Output gates.
    Prevents the vanishing gradient problem in long sentences.
    """
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
        # LSTMs concatenate input and hidden state and push through 4 gates
        self.fc = Linear(input_size + hidden_size, 4 * hidden_size)

    def _sigmoid(self, x):
        # Custom sigmoid for Value objects
        def _sig(val):
            return Value(1.0) / (Value(1.0) + (-val).exp())
        return [_sig(xi) for xi in x]

    def __call__(self, x, hidden, cell_state):
        concat = x + hidden
        gates = self.fc(concat)
        
        # Split the 4 * hidden_size output into the 4 distinct gates
        h_sz = self.hidden_size
        i_gate = self._sigmoid(gates[0:h_sz])             # Input
        f_gate = self._sigmoid(gates[h_sz:2*h_sz])        # Forget
        o_gate = self._sigmoid(gates[2*h_sz:3*h_sz])      # Output
        g_gate = [g.tanh() for g in gates[3*h_sz:4*h_sz]] # Cell Candidate

        # Next Cell State = (Forget * Old Cell) + (Input * Candidate)
        next_c = [(f * c) + (i * g) for f, c, i, g in zip(f_gate, cell_state, i_gate, g_gate)]
        
        # Next Hidden State = Output * Tanh(Next Cell State)
        next_h = [o * c.tanh() for o, c in zip(o_gate, next_c)]
        
        return next_h, next_c

# ==========================================
# 6. COMPUTER VISION
# ==========================================
# (Your advanced Conv2D, MaxPool2D, and FlattenLayer from previous iterations go here)
# Just ensure they inherit from Module: class Conv2D(Module): ...

# ==========================================
# 7. CONTAINERS
# ==========================================

class Sequential(Module):
    def __init__(self, *layers):
        super().__init__()
        self.layers = list(layers)

    def __call__(self, x):
        for layer in self.layers:
            x = layer(x) if not hasattr(layer, 'forward') else layer.forward(x)
        return x

# ==========================================
# 8. ADVANCED OPTIMIZERS
# ==========================================

class SGD:
    def __init__(self, parameters, lr=0.01, momentum=0.0):
        self.params = parameters
        self.lr = lr
        self.momentum = momentum
        self.velocities = [0.0] * len(parameters)

    def step(self):
        for i, p in enumerate(self.params):
            if p.grad == 0: continue
            self.velocities[i] = self.momentum * self.velocities[i] + p.grad
            p.data -= self.lr * self.velocities[i]

    def zero_grad(self):
        for p in self.params: p.grad = 0.0

class AdamW:
    """
    Adam with Decoupled Weight Decay.
    The absolute gold standard for training LLMs and Transformers.
    """
    def __init__(self, parameters, lr=0.001, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.01):
        self.params = parameters
        self.lr = lr
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.t = 0
        self.m = [0.0] * len(parameters)
        self.v = [0.0] * len(parameters)

    def step(self):
        self.t += 1
        for i, p in enumerate(self.params):
            if p.grad == 0: continue 
            
            # Apply decoupled weight decay (AdamW magic)
            p.data -= self.lr * self.weight_decay * p.data
            
            grad = p.grad
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (grad ** 2)
            
            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            v_hat = self.v[i] / (1 - self.beta2 ** self.t)
            
            p.data -= self.lr * m_hat / (math.sqrt(v_hat) + self.eps)

    def zero_grad(self):
        for p in self.params: p.grad = 0.0

# ==========================================
# 9. LOSS FUNCTIONS
# ==========================================

class BCELoss(Module):
    """Binary Cross Entropy for binary classification."""
    def __call__(self, y_pred, y_true):
        # Uses math tricks to avoid log(0) errors
        loss = Value(0.0)
        for pred, true in zip(y_pred, y_true):
            p = max(min(pred.data, 1 - 1e-7), 1e-7) # Clip
            t = Value(true)
            loss += -(t * Value(math.log(p)) + (Value(1.0) - t) * Value(math.log(1.0 - p)))
        return loss / len(y_pred)
class Softmax(Module):
    """Converts raw network outputs into clean probabilities summing to 1.0."""
    def __call__(self, x):
        # Prevent math explosion by subtracting max value (numerical stability trick)
        max_val = max(xi.data for xi in x)
        e_x = [(xi - max_val).exp() for xi in x]
        sum_e_x = sum(e_x)
        return [ex / sum_e_x for ex in e_x]

class CrossEntropyLoss(Module):
    """
    The Enterprise standard for Multi-Class Classification and LLMs.
    Takes raw logits and the correct target index, calculates loss.
    """
    def __call__(self, logits, target_idx):
        # Numerically stable Log-Sum-Exp
        max_val = max(x.data for x in logits)
        
        # log(sum(exp(x - max)))
        sum_exp = sum((x - max_val).exp() for x in logits)
        log_sum_exp = Value(max_val) + sum_exp.log()
        
        # Loss = -logit[target] + log(sum(exp(logits)))
        loss = -logits[target_idx] + log_sum_exp
        return loss

class MSELoss(Module):
    """Mean Squared Error for Regression Tasks."""
    def __call__(self, y_pred, y_true):
        loss = sum((p - t)**2 for p, t in zip(y_pred, y_true))
        return loss / len(y_pred)
# ==========================================
# 10. LEARNING RATE SCHEDULERS
# ==========================================

class CosineAnnealingLR:
    """
    Decays the learning rate following a cosine curve.
    Used by OpenAI and Meta to stabilize LLM training.
    """
    def __init__(self, optimizer, T_max, eta_min=0.0):
        self.optimizer = optimizer
        self.T_max = T_max
        self.eta_min = eta_min
        self.base_lr = optimizer.lr
        self.current_step = 0

    def step(self):
        self.current_step += 1
        # Prevent division by zero if step exceeds T_max
        if self.current_step > self.T_max: return
        
        # Calculate new learning rate using Cosine formula
        decay_ratio = self.current_step / self.T_max
        coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))
        new_lr = self.eta_min + (self.base_lr - self.eta_min) * coeff
        
        # Inject the new learning rate into the optimizer
        self.optimizer.lr = new_lr