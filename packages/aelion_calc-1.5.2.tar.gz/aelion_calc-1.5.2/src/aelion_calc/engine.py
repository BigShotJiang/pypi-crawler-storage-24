import csv
import os
import json
import time
import numpy as np
import multiprocessing as mp

from .llm import GPT, BPETokenizer
from .nn_tensor import AdamW
from .compute import gpu_engine

# ==========================================
# WINDOWS MULTIPROCESSING WORKERS
# ==========================================
global_tokenizer = None

def _init_worker(vocab, merges, special_tokens, vocab_size):
    global global_tokenizer
    global_tokenizer = BPETokenizer(vocab_size=vocab_size)
    global_tokenizer.vocab = vocab
    global_tokenizer.merges = merges
    global_tokenizer.special_tokens = special_tokens

def _process_row(row):
    """Universal Row Processor."""
    # 1. Check for Chat Format (User/Assistant)
    if 'user' in row and 'assistant' in row:
        user_msg = row.get('user', '').strip()
        ai_msg = row.get('assistant', '').strip()
        if not user_msg or not ai_msg: return np.array([], dtype=np.uint16)
        formatted_text = (
            f"<|system|>You are a helpful AI.<|user|>{user_msg}\n"
            f"<|assistant|>{ai_msg}<|endoftext|>\n"
        )
    # 2. Check for Article/Text Format
    elif 'text' in row or 'body' in row or 'content' in row:
        text = row.get('text', row.get('body', row.get('content', ''))).strip()
        if not text: return np.array([], dtype=np.uint16)
        meta = ""
        if 'title' in row: meta += f"Title: {row['title']}. "
        if 'author' in row: meta += f"Author: {row['author']}. "
        
        if meta:
            formatted_text = f"<|system|>{meta.strip()}\n<|user|>Write the article.\n<|assistant|>{text}<|endoftext|>\n"
        else:
            formatted_text = f"{text}<|endoftext|>\n"
    # 3. Fallback: Treat as raw text line
    else:
        text = " ".join(str(v) for v in row.values()).strip()
        if not text: return np.array([], dtype=np.uint16)
        formatted_text = f"{text}<|endoftext|>\n"

    token_ids = global_tokenizer.encode(formatted_text)
    return np.array(token_ids, dtype=np.uint16)

def _get_data_iterator(file_path):
    """Helper to read CSV, JSON, JSONL, or TXT generically."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.csv':
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader: yield row
    elif ext == '.json':
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                for row in data: yield row
            elif isinstance(data, dict): yield data 
    elif ext == '.jsonl':
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip(): yield json.loads(line)
    elif ext == '.txt':
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip(): yield {'text': line.strip()}
    else:
        raise ValueError(f"Unsupported file format: {ext}")

# ==========================================
# 1. THE ENTERPRISE TRAINER
# ==========================================
class AelionTrainer:
    @staticmethod
    def prepare_data(data_path, bin_path, vocab_size=3000, fast_limit=1000):
        print("\n[Aelion Pipeline] Step 1: Data Preparation")
        
        # 1. SETUP VOCAB PATH
        tokenizer_path = bin_path.replace(".bin", "_vocab.json")
        try: csv.field_size_limit(10000000)
        except: pass
        
        print(f" -> Auto-detecting format for: {data_path}")
        print(" -> Training master vocabulary...")
        
        tokenizer = BPETokenizer(vocab_size=vocab_size)
        sample_text = ""
        iterator = _get_data_iterator(data_path)
        for i, row in enumerate(iterator):
            if i >= fast_limit: break
            row_text = " ".join(str(v) for v in row.values())
            sample_text += row_text + "\n"
            
        tokenizer.fit(sample_text)

        # 2. SAVE TOKENIZER (CRITICAL FIX FOR GIBBERISH)
        print(f" -> Saving synchronized vocabulary to {tokenizer_path}...")
        safe_vocab = {k: (v.decode('latin-1') if isinstance(v, bytes) else v) for k, v in tokenizer.vocab.items()}
        vocab_bundle = {
            "vocab": safe_vocab,
            "merges": {str(k): v for k, v in tokenizer.merges.items()}
        }
        with open(tokenizer_path, 'w') as f:
            json.dump(vocab_bundle, f)
        
        # 3. ENCODE DATA
        cores = mp.cpu_count()
        print(f" -> Igniting {cores} CPU Cores to shard data to {bin_path}...")

        def row_generator(): return _get_data_iterator(data_path)

        processed = 0
        with open(bin_path, 'wb') as bin_out:
            with mp.Pool(processes=cores, 
                         initializer=_init_worker, 
                         initargs=(tokenizer.vocab, tokenizer.merges, tokenizer.special_tokens, vocab_size)) as pool:
                
                for np_tokens in pool.imap(_process_row, row_generator(), chunksize=100):
                    if np_tokens.size > 0:
                        bin_out.write(np_tokens.tobytes())
                    processed += 1
                    if processed % 1000 == 0:
                        print(f"    ...Processed {processed} rows")
                        
        print("✅ Data Pipeline Complete.\n")
        return tokenizer

    @staticmethod
    def train(bin_path, export_path, data_path='chat_data.csv', vocab_size=3000, block_size=128, embed_dim=128, layers=4, target_steps=1000, batch_size=8):
        print(f"\n[Aelion Pipeline] Step 2: GPU Training ({gpu_engine.ctx.devices[0].name if gpu_engine.available else 'CPU'})")
        
        if not os.path.exists(bin_path):
            raise FileNotFoundError(f"Binary file {bin_path} not found. Run prepare_data first.")

        # 1. LOAD THE MATCHING TOKENIZER
        tokenizer_path = bin_path.replace(".bin", "_vocab.json")
        print(f" -> Loading synchronized vocabulary from {tokenizer_path}...")
        
        tokenizer = BPETokenizer(vocab_size=vocab_size)
        if os.path.exists(tokenizer_path):
            with open(tokenizer_path, 'r') as f:
                bundle = json.load(f)
            # Reconstruct Tokenizer
            tokenizer.vocab = {int(k): (v.encode('latin-1') if isinstance(v, str) else v) for k, v in bundle['vocab'].items()}
            tokenizer.merges = {eval(k): v for k, v in bundle['merges'].items()}
        else:
            print(" [!] CRITICAL WARNING: Vocab file missing! Model might speak gibberish.")
            # Fallback (Old way)
            sample_text = ""
            iterator = _get_data_iterator(data_path)
            for i, row in enumerate(iterator):
                if i >= 100: break 
                sample_text += " ".join(str(v) for v in row.values()) + "\n"
            tokenizer.fit(sample_text)
            
        mapped_data = np.memmap(bin_path, dtype=np.uint16, mode='r')
        model = GPT(vocab_size=vocab_size, block_size=block_size, n_embd=embed_dim, n_layer=layers)
        optimizer = AdamW(model.parameters(), lr=3e-4, weight_decay=0.01)
        
        # 2. AUTO-RESUME LOGIC
        checkpoint_file = export_path.replace(".aelion", "_checkpoint.json")
        start_step = 0
        
        if os.path.exists(checkpoint_file):
            print(f" -> [Auto-Resume] Found existing checkpoint: {checkpoint_file}")
            try:
                with open(checkpoint_file, 'r') as f:
                    ckpt = json.load(f)
                start_step = ckpt.get("step", 0) + 1
                for i, p in enumerate(model.parameters()):
                    if f"p{i}" in ckpt["weights"]:
                        p.data = np.array(ckpt["weights"][f"p{i}"], dtype=np.float32)
                print(f" -> Neural network reactivated. Resuming from Step {start_step}...")
            except (json.JSONDecodeError, ValueError):
                print(f" [!] WARNING: Checkpoint corrupted. Starting training from scratch.")
                start_step = 0
        else:
            print(" -> Booting fresh neural network...")

        def get_batch(bs=8):
            ix = np.random.randint(0, len(mapped_data) - block_size - 1, bs)
            x = [mapped_data[i : i+block_size].astype(np.int32) for i in ix]
            y = [mapped_data[i+1 : i+block_size+1].astype(np.int32) for i in ix]
            return x, y
        
        # --- ATOMIC SAVE FUNCTION ---
        def save_checkpoint(step):
            temp_file = checkpoint_file + ".tmp"
            ckpt_data = {
                "step": step,
                "weights": {f"p{i}": p.data.tolist() for i, p in enumerate(model.parameters())}
            }
            try:
                with open(temp_file, 'w') as f: json.dump(ckpt_data, f)
                if os.path.exists(checkpoint_file): os.remove(checkpoint_file)
                os.rename(temp_file, checkpoint_file)
            except Exception as e:
                print(f" [!] Warning: Failed to save checkpoint: {e}")

        print(f" -> Training Target: {target_steps} steps | Batch Size: {batch_size}")
        try:
            for step in range(start_step, target_steps):
                t0 = time.time()
                xb, yb = get_batch(batch_size)
                optimizer.zero_grad()
                total_loss = 0.0
                
                for i in range(batch_size):
                    logits, loss = model(xb[i], targets=yb[i])
                    total_loss += float(loss.data)
                    loss.backward()
                    
                for p in model.parameters():
                    p.grad = np.clip(p.grad, -1.0, 1.0)
                optimizer.step()
                
                # OPTIMIZATION: Save less frequently (Every 500 steps)
                if step % 500 == 0 and step > 0:
                    save_checkpoint(step)
                    print(f"    [Save] Checkpoint secured at step {step}")

                dt = (time.time() - t0) * 1000
                if step % 50 == 0:
                    print(f"    Step {step:04d} | Loss: {(total_loss/batch_size):.4f} | {dt:.1f}ms")
                    
        except KeyboardInterrupt:
            print(f"\n⚠️ Training paused by user at step {step}.")
            save_checkpoint(step)
            print(f" -> Checkpoint saved securely to {checkpoint_file}.")
            return

        # 4. FINAL EXPORT
        print("\n[Aelion Pipeline] Step 3: Exporting Unified Model...")
        safe_vocab = {k: (v.decode('latin-1') if isinstance(v, bytes) else v) for k, v in tokenizer.vocab.items()}
        bundle = {
            "metadata": {
                "vocab_size": vocab_size, "block_size": block_size,
                "n_embd": embed_dim, "n_layer": layers
            },
            "tokenizer": {
                "vocab": safe_vocab,
                "merges": {str(k): v for k, v in tokenizer.merges.items()}
            },
            "weights": {f"p{i}": p.data.tolist() for i, p in enumerate(model.parameters())}
        }
        with open(export_path, 'w') as f:
            json.dump(bundle, f)
        if os.path.exists(checkpoint_file): os.remove(checkpoint_file)
        print(f"✅ Master Model perfectly sealed in: {export_path}\n")

# ==========================================
# 2. THE CHAT INTERFACE
# ==========================================
class Aelion:
    def __init__(self, model_path):
        print(f"[Aelion] Waking neural network from {model_path}...")
        with open(model_path, 'r') as f:
            bundle = json.load(f)
            
        m = bundle['metadata']
        self.tokenizer = BPETokenizer(vocab_size=m['vocab_size'])
        
        self.tokenizer.vocab = {int(k): (v.encode('latin-1') if isinstance(v, str) else v) for k, v in bundle['tokenizer']['vocab'].items()}
        self.tokenizer.merges = {eval(k): v for k, v in bundle['tokenizer']['merges'].items()}
        
        self.model = GPT(vocab_size=m['vocab_size'], block_size=m['block_size'],
                         n_embd=m['n_embd'], n_layer=m['n_layer'])
        
        for i, p in enumerate(self.model.parameters()):
            p.data = np.array(bundle['weights'][f"p{i}"], dtype=np.float32)
        print("[Aelion] Online.\n")

    def chat(self, prompt, max_tokens=150, temperature=0.75, top_k=40, repetition_penalty=1.2):
        return self.model.chat_generate(
            prompt=prompt, 
            tokenizer=self.tokenizer, 
            max_new_tokens=max_tokens, 
            temperature=temperature,
            top_k=top_k,
            repetition_penalty=repetition_penalty
        )