import math
import numpy as np
from .tensor import Tensor

# ==========================================
# 1. THE BASE CLASS
# ==========================================
class Module:
    def __init__(self):
        self.training = True

    def parameters(self):
        params = []
        def _scan(obj):
            # Now searches for Tensors instead of Values
            if isinstance(obj, Tensor):
                params.append(obj)
            elif isinstance(obj, Module):
                params.extend(obj.parameters())
            elif isinstance(obj, list):
                for item in obj: _scan(item)
            elif isinstance(obj, tuple):
                for item in obj: _scan(item)
        
        for k, v in self.__dict__.items():
            _scan(v)
        return params

    def zero_grad(self):
        for p in self.parameters():
            p.grad = np.zeros_like(p.data)

    def train(self, mode=True):
        self.training = mode
        for k, v in self.__dict__.items():
            if isinstance(v, Module): v.train(mode)
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, Module): item.train(mode)
    def eval(self):
        self.train(False)

# ==========================================
# 2. LINEAR LAYER (The Memory Saver)
# ==========================================
class Linear(Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        
        # Kaiming Initialization for deep networks
        bound = math.sqrt(2.0 / in_features)
        
        # This single Tensor replaces thousands of individual Python objects
        self.weight = Tensor(np.random.uniform(-bound, bound, (in_features, out_features)))
        self.bias = Tensor(np.zeros((out_features,))) if bias else None

    def __call__(self, x):
        # Hardware-accelerated Matrix Multiplication
        out = x.dot(self.weight)
        return out + self.bias if self.bias else out

# ==========================================
# 3. ADVANCED ACTIVATIONS
# ==========================================
class GELU(Module):
    def __call__(self, x):
        # 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
        inner = (x + (x**3) * 0.044715) * math.sqrt(2.0 / math.pi)
        return x * 0.5 * (inner.tanh() + 1.0)

class Dropout(Module):
    def __init__(self, p=0.5):
        super().__init__()
        self.p = p

    def __call__(self, x):
        if not self.training: return x
        # Vectorized binomial mask
        mask = np.random.binomial(1, 1 - self.p, size=x.shape) / (1 - self.p)
        return x * Tensor(mask)

# ==========================================
# 4. NORMALIZATION & CONTAINERS
# ==========================================
class LayerNorm(Module):
    def __init__(self, dim, eps=1e-5):
        super().__init__()
        self.eps = eps
        self.gamma = Tensor(np.ones((dim,)))
        self.beta = Tensor(np.zeros((dim,)))

    def __call__(self, x):
        # Vectorized mean and variance across the last dimension
        mean = x.sum(axis=-1, keepdims=True) * (1.0 / x.shape[-1])
        var = ((x - mean)**2).sum(axis=-1, keepdims=True) * (1.0 / x.shape[-1])
        
        x_norm = (x - mean) * Tensor(1.0 / np.sqrt(var.data + self.eps))
        return x_norm * self.gamma + self.beta

class Sequential(Module):
    def __init__(self, *layers):
        super().__init__()
        self.layers = list(layers)

    def __call__(self, x):
        for layer in self.layers:
            x = layer(x) if not hasattr(layer, 'forward') else layer.forward(x)
        return x

# ==========================================
# 5. LOSS FUNCTION & OPTIMIZER
# ==========================================
class CrossEntropyLoss(Module):
    def __call__(self, logits, target_idx):
        max_val = logits.max()
        
        # log(sum(exp(x - max)))
        sum_exp = (logits - max_val).exp().sum()
        log_sum_exp = max_val + sum_exp.log()
        
        # Extract the target logit using a one-hot mask
        target_mask = np.zeros_like(logits.data)
        target_mask[target_idx] = 1.0
        target_logit = (logits * Tensor(target_mask)).sum()
        
        return -target_logit + log_sum_exp

class AdamW:
    """
    Adam with Decoupled Weight Decay.
    Upgraded to handle NumPy array states instead of scalars.
    """
    def __init__(self, parameters, lr=0.001, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.01):
        self.params = parameters
        self.lr = lr
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.t = 0
        self.m = [np.zeros_like(p.data) for p in parameters]
        self.v = [np.zeros_like(p.data) for p in parameters]

    def step(self):
        self.t += 1
        for i, p in enumerate(self.params):
            if not p.requires_grad: continue 
            
            # Apply decoupled weight decay directly to the data
            p.data -= self.lr * self.weight_decay * p.data
            
            grad = p.grad
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (grad ** 2)
            
            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            v_hat = self.v[i] / (1 - self.beta2 ** self.t)
            
            p.data -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)

    def zero_grad(self):
        for p in self.params: 
            p.grad = np.zeros_like(p.data)