import math
import random
import json
import numpy as np
from collections import Counter

# We now import exclusively from the Enterprise Tensor Stack
from .tensor import Tensor
from .nn_tensor import Module, Linear, LayerNorm, Dropout, GELU, CrossEntropyLoss, Sequential

# ==========================================
# 1. THE WORD ENGINE (BPETokenizer)
# ==========================================

class BPETokenizer(Module):
    """
    Learns words instead of characters. 
    Includes Chat boundaries: <|user|>, <|assistant|>, <|system|>.
    """
    def __init__(self, vocab_size=5000):
        super().__init__()
        self.vocab_size = vocab_size
        self.merges = {}
        self.vocab = {i: bytes([i]) for i in range(256)}
        
        self.special_tokens = {
            "<|endoftext|>": 256, "<|user|>": 257, 
            "<|assistant|>": 258, "<|system|>": 259
        }
        for token, idx in self.special_tokens.items():
            self.vocab[idx] = token.encode("utf-8")
        self.next_idx = 260

    def fit(self, text):
        ids = list(text.encode("utf-8"))
        num_merges = self.vocab_size - self.next_idx
        for i in range(num_merges):
            stats = Counter(zip(ids, ids[1:]))
            if not stats: break
            best_pair = max(stats, key=stats.get)
            idx = self.next_idx + i
            self.merges[best_pair] = idx
            self.vocab[idx] = self.vocab[best_pair[0]] + self.vocab[best_pair[1]]
            
            new_ids = []; skip = False
            for j in range(len(ids)):
                if skip: skip = False; continue
                if j < len(ids)-1 and (ids[j], ids[j+1]) == best_pair:
                    new_ids.append(idx); skip = True
                else: new_ids.append(ids[j])
            ids = new_ids

    def encode(self, text):
        tokens = list(text.encode("utf-8"))
        while len(tokens) >= 2:
            stats = Counter(zip(tokens, tokens[1:]))
            pair = min(stats.keys(), key=lambda p: self.merges.get(p, float('inf')))
            if pair not in self.merges: break
            idx = self.merges[pair]
            new_tokens = []; skip = False
            for i in range(len(tokens)):
                if skip: skip = False; continue
                if i < len(tokens)-1 and (tokens[i], tokens[i+1]) == pair:
                    new_tokens.append(idx); skip = True
                else: new_tokens.append(tokens[i])
            tokens = new_tokens
        return tokens

    def decode(self, ids):
        return b"".join(self.vocab.get(i, b"") for i in ids).decode("utf-8", errors="replace")

# ==========================================
# 2. EMBEDDINGS (Now using Tensors)
# ==========================================

class Embedding(Module):
    """Converts token integers into dense Tensor matrices."""
    def __init__(self, num_embeddings, embedding_dim):
        super().__init__()
        # 1 Tensor replaces thousands of Python objects
        self.weight = Tensor(np.random.uniform(-0.1, 0.1, (num_embeddings, embedding_dim)))

    def __call__(self, indices):
        # Ultra-fast NumPy array indexing
        return Tensor(self.weight.data[indices])

# ==========================================
# 3. CAUSAL SELF-ATTENTION (Pure Matrix Math)
# ==========================================

class CausalSelfAttention(Module):
    """
    The Brain of the LLM.
    Uses continuous Tensor blocks. Offloads math to GPU natively.
    """
    def __init__(self, n_embd, dropout=0.1):
        super().__init__()
        self.n_embd = n_embd
        
        self.q_proj = Linear(n_embd, n_embd)
        self.k_proj = Linear(n_embd, n_embd)
        self.v_proj = Linear(n_embd, n_embd)
        self.c_proj = Linear(n_embd, n_embd)
        self.resid_drop = Dropout(dropout)

    def __call__(self, x):
        T = x.shape[0]
        
        # 1. Project Q, K, V
        q = self.q_proj(x)
        k = self.k_proj(x)
        v = self.v_proj(x)
        
        # 2. GPU Accelerated Dot Product: (Q @ K.T) / sqrt(d)
        scores = q.dot(k.transpose()) * (self.n_embd ** -0.5)
        
        # 3. Apply Causal Mask (Hide the future)
        mask = np.triu(np.ones((T, T)), k=1) * -1e9
        scores = scores + Tensor(mask)
        
        # 4. Softmax (Numerically stable)
        max_scores = scores.max(axis=-1, keepdims=True)
        exps = (scores - max_scores).exp()
        # Sum exps and extract data to invert for division
        sum_exps = exps.sum(axis=-1, keepdims=True)
        probs = exps * Tensor(1.0 / (sum_exps.data + 1e-8))
        
        # 5. Weighted values
        out = probs.dot(v)
        return self.resid_drop(self.c_proj(out))

# ==========================================
# 4. THE TRANSFORMER BLOCK
# ==========================================

class TransformerBlock(Module):
    """Now purely Tensor-based. Notice the absence of for-loops."""
    def __init__(self, n_embd, dropout=0.1):
        super().__init__()
        self.ln1 = LayerNorm(n_embd)
        self.attn = CausalSelfAttention(n_embd, dropout)
        self.ln2 = LayerNorm(n_embd)
        self.mlp = Sequential(Linear(n_embd, 4*n_embd), GELU(), Linear(4*n_embd, n_embd), Dropout(dropout))

    def __call__(self, x):
        # Residual Connections: x = x + F(x)
        x = x + self.attn(self.ln1(x))
        x = x + self.mlp(self.ln2(x))
        return x

# ==========================================
# 5. THE COMPLETE TENSOR GPT MODEL
# ==========================================

class GPT(Module):
    def __init__(self, vocab_size, block_size, n_embd=64, n_layer=2, dropout=0.1):
        super().__init__()
        self.block_size = block_size
        
        self.token_embedding = Embedding(vocab_size, n_embd)
        self.position_embedding = Embedding(block_size, n_embd)
        self.drop = Dropout(dropout)
        
        self.blocks = Sequential(*[TransformerBlock(n_embd, dropout) for _ in range(n_layer)])
        
        self.ln_f = LayerNorm(n_embd)
        self.lm_head = Linear(n_embd, vocab_size, bias=False)

    def __call__(self, idx, targets=None):
        T = len(idx)
        
        # 1. Embeddings
        tok_emb = self.token_embedding(idx) 
        pos_emb = self.position_embedding(list(range(T))) 
        
        # 2. Forward Pass (100% Tensor math)
        x = self.drop(tok_emb + pos_emb)
        x = self.blocks(x)
        x = self.ln_f(x)
        logits = self.lm_head(x)
        
        # 3. Loss Calculation
        loss = None
        if targets is not None:
            # We calculate loss only on the last token to save memory
            last_logit = Tensor(logits.data[-1])
            loss = CrossEntropyLoss()(last_logit, targets[-1])
            
        return logits, loss

    def chat_generate(self, prompt, tokenizer, max_new_tokens=150, temperature=0.75, top_k=40, repetition_penalty=1.2):
        """
        Enterprise Chat Generator.
        Features: Temperature Scaling, Top-K Gating, and Repetition Penalty.
        """
        self.eval()
        formatted_prompt = f"<|system|>You are a helpful AI.<|user|>{prompt}<|assistant|>"
        idx = tokenizer.encode(formatted_prompt)
        
        for _ in range(max_new_tokens):
            # Crop to context window
            idx_cond = idx[-self.block_size:]
            logits, _ = self.__call__(idx_cond)
            
            # Extract raw NumPy arrays for blazing fast generation
            last_logits = logits.data[-1] 
            
            # --- THE ACCURACY UPGRADE: REPETITION PENALTY ---
            # Slash the probability of words we've already used
            if repetition_penalty != 1.0:
                for token_id in set(idx):
                    if last_logits[token_id] < 0:
                        last_logits[token_id] *= repetition_penalty
                    else:
                        last_logits[token_id] /= repetition_penalty

            # Apply Temperature
            scaled_logits = last_logits / temperature
            
            # --- THE ACCURACY UPGRADE: TOP-K SAMPLING ---
            if top_k is not None:
                # Find the value of the Kth highest probability
                kth_val = np.sort(scaled_logits)[-top_k]
                # Any token with a lower probability gets permanently zeroed out
                scaled_logits[scaled_logits < kth_val] = -float('Inf')
            
            # NumPy Softmax (Mathematically stable)
            max_val = np.max(scaled_logits)
            e_x = np.exp(scaled_logits - max_val)
            probs = e_x / np.sum(e_x)
            
            # Sample next token based on probability distribution
            next_token = np.random.choice(len(probs), p=probs)
            idx.append(next_token)
            
            # Stop if the AI decides the sentence is over
            if next_token == 256: # <|endoftext|>
                break
                
        self.train()
        reply_ids = idx[len(tokenizer.encode(formatted_prompt)):]
        return tokenizer.decode(reply_ids)