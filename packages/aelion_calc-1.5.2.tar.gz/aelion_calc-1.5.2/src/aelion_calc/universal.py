import os
import time
import json
import numpy as np
from .nn_tensor import AdamW
from .compute import gpu_engine

class UniversalTrainer:
    """
    The General-Purpose Training Engine.
    Unlike 'AelionTrainer' (which is text-only), this trainer accepts ANY model and ANY data.
    """
    def __init__(self, model, optimizer=None):
        self.model = model
        self.optimizer = optimizer if optimizer else AdamW(model.parameters(), lr=3e-4)
        
    def train(self, data_loader, epochs=1, save_path="model.aelion"):
        print(f"\n[Universal Trainer] Linked to {gpu_engine.ctx.devices[0].name if gpu_engine.available else 'CPU'}")
        print(f" -> Model Parameters: {sum(p.size for p in self.model.parameters()):,}")
        
        step = 0
        for epoch in range(epochs):
            print(f" -> Starting Epoch {epoch+1}/{epochs}...")
            
            # The data_loader yields (inputs, targets)
            # It doesn't care if 'inputs' are text tokens or image pixels!
            for batch_idx, (x, y) in enumerate(data_loader):
                t0 = time.time()
                
                # 1. Zero Gradients
                self.optimizer.zero_grad()
                
                # 2. Forward Pass
                logits, loss = self.model(x, targets=y)
                
                # 3. Backward Pass
                loss.backward()
                
                # 4. Optimizer Step
                self.optimizer.step()
                
                step += 1
                dt = (time.time() - t0) * 1000
                
                if step % 10 == 0:
                     print(f"    Step {step:04d} | Loss: {float(loss.data):.4f} | {dt:.1f}ms")

        # Universal Export (Saves strictly weights, no hardcoded tokenizer vocab)
        print(f"\n[Universal Trainer] Saving generic model to {save_path}...")
        bundle = {
            "type": "universal",
            "weights": {f"p{i}": p.data.tolist() for i, p in enumerate(self.model.parameters())}
        }
        with open(save_path, 'w') as f:
            json.dump(bundle, f)
        print("✅ Training Complete.")