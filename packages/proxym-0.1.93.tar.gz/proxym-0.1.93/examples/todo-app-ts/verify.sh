#!/usr/bin/env bash
set +e  # Intentional: we track pass/fail ourselves via $PASS/$FAIL counters;
#        errexit would abort on first non-zero which breaks our test harness.
###############################################################################
# verify.sh — Standalone verification for the todo-app-ts project
#
# This script checks whether the generated TypeScript TODO app is correct.
# It can run independently of proxym — it only inspects the project on disk.
#
# Usage:
#   bash examples/todo-app-ts/verify.sh                        # default path
#   bash examples/todo-app-ts/verify.sh ~/projects/todo-app-ts # custom path
#   bash examples/todo-app-ts/verify.sh --with-proxym          # also check proxym
#
# Exit codes:
#   0 — all checks passed
#   1 — some checks failed (see output)
###############################################################################
set -uo pipefail

PROJECT_DIR="${1:-$HOME/projects/todo-app-ts}"
WITH_PROXYM=false
PROXYM_URL="${PROXYM_URL:-http://localhost:4000}"

# Parse flags mixed with positional
for arg in "$@"; do
  case "$arg" in
    --with-proxym) WITH_PROXYM=true ;;
    --proxy=*)     PROXYM_URL="${arg#--proxy=}" ;;
    --help|-h)
      sed -n '2,/^###/p' "$0" | head -n -1 | sed 's/^# \?//'
      exit 0
      ;;
    *)
      if [[ -d "$arg" ]]; then
        PROJECT_DIR="$arg"
      fi
      ;;
  esac
done

# ── Colors ───────────────────────────────────────────────────────────────────

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; DIM='\033[2m'; RESET='\033[0m'

PASS=0; FAIL=0; WARN=0; SKIP=0

_hdr()  { echo -e "\n${BOLD}${CYAN}─── $1 ───${RESET}"; }
_ok()   { PASS=$((PASS+1)); echo -e "  ${GREEN}✓${RESET} $1"; }
_fail() { FAIL=$((FAIL+1)); echo -e "  ${RED}✗${RESET} $1"; }
_warn() { WARN=$((WARN+1)); echo -e "  ${YELLOW}⚠${RESET} $1"; }
_skip() { SKIP=$((SKIP+1)); echo -e "  ${DIM}⊘ $1 (skipped)${RESET}"; }
_info() { echo -e "  ${DIM}$1${RESET}"; }

# ── Helper: check file exists and is non-empty ──────────────────────────────

_check_file() {
  local path="$1" label="${2:-$1}"
  local full="${PROJECT_DIR}/${path}"
  if [[ -f "$full" ]]; then
    local size
    size=$(wc -c < "$full" 2>/dev/null || echo 0)
    if (( size > 80 )); then
      _ok "${label} (${size} bytes)"
    else
      _warn "${label} exists but looks like a stub (${size} bytes)"
    fi
  else
    _fail "${label} — file missing"
  fi
  return 0
}

# ── Helper: check file contains a pattern ────────────────────────────────────

_check_contains() {
  local path="$1" pattern="$2" label="$3"
  local full="${PROJECT_DIR}/${path}"
  if [[ -f "$full" ]] && grep -qE "$pattern" "$full" >/dev/null 2>&1; then
    _ok "$label"
  else
    _fail "$label"
  fi
  return 0
}

# ── Helper: check file does NOT contain the stub marker ──────────────────────

_check_not_stub() {
  local path="$1" label="${2:-$1}"
  local full="${PROJECT_DIR}/${path}"
  if [[ ! -f "$full" ]]; then
    _fail "${label} — file missing"
    return 0
  fi
  if grep -q "TODO: Implement" "$full" >/dev/null 2>&1; then
    _warn "${label} — still contains TODO stub markers"
  else
    _ok "${label} — implemented (no stub markers)"
  fi
  return 0
}

###############################################################################
# SECTION 1: Project structure
###############################################################################

_verify_structure() {
  _hdr "1. Project Structure"

  if [[ ! -d "$PROJECT_DIR" ]]; then
    _fail "Project directory does not exist: ${PROJECT_DIR}"
    echo ""
    echo "  Create it by running:"
    echo "    bash examples/todo-app-ts/run.sh --project-dir ${PROJECT_DIR}"
    echo ""
    return 0
  fi
  _ok "Project directory exists: ${PROJECT_DIR}"

  # Required files
  _check_file "package.json"        "package.json"
  _check_file "tsconfig.json"       "tsconfig.json"
  _check_file "vitest.config.ts"    "vitest.config.ts"
  _check_file "README.md"           "README.md"
  _check_file "spec.md"             "spec.md"

  # Source files
  _check_file "src/types.ts"        "src/types.ts"
  _check_file "src/store.ts"        "src/store.ts"
  _check_file "src/format.ts"       "src/format.ts"
  _check_file "src/commands.ts"     "src/commands.ts"
  _check_file "src/index.ts"        "src/index.ts"

  # Test files
  _check_file "tests/store.test.ts"    "tests/store.test.ts"
  _check_file "tests/commands.test.ts" "tests/commands.test.ts"

  # Proxym metadata
  if [[ -d "${PROJECT_DIR}/.proxym" ]]; then
    _ok ".proxym/ metadata directory"
    _check_file ".proxym/metadata.json"      ".proxym/metadata.json"
    _check_file ".proxym/tickets.manifest"   ".proxym/tickets.manifest"
  else
    _warn ".proxym/ directory missing — was this created by run.sh?"
  fi

  # Git
  if [[ -d "${PROJECT_DIR}/.git" ]]; then
    _ok "Git repository initialized"
    local commit_count
    commit_count=$(cd "${PROJECT_DIR}" && git rev-list --count HEAD 2>/dev/null || echo 0)
    _info "  Commits: ${commit_count}"
  else
    _warn "No git repository"
  fi
}

###############################################################################
# SECTION 2: Source code quality
###############################################################################

_verify_source_code() {
  _hdr "2. Source Code Quality"

  # Check types.ts has the interface
  _check_contains "src/types.ts" "interface Todo" "types.ts defines Todo interface"
  _check_contains "src/types.ts" "Priority" "types.ts defines Priority type"

  # Check implementation files are not stubs
  _check_not_stub "src/store.ts"    "store.ts implementation"
  _check_not_stub "src/format.ts"   "format.ts implementation"
  _check_not_stub "src/commands.ts" "commands.ts implementation"
  _check_not_stub "src/index.ts"    "index.ts implementation"

  # Check store.ts has key methods
  _check_contains "src/store.ts" "class TodoStore|function.*(create|add)" \
    "store.ts has TodoStore class or create function"
  _check_contains "src/store.ts" "(getAll|list|findAll|todos)" \
    "store.ts has a list/getAll method"
  _check_contains "src/store.ts" "(delete|remove)" \
    "store.ts has a delete/remove method"

  # Check commands.ts imports store
  _check_contains "src/commands.ts" "import.*store|require.*store" \
    "commands.ts imports store"

  # Check index.ts uses commander
  _check_contains "src/index.ts" "commander|Command" \
    "index.ts uses Commander.js"
  _check_contains "src/index.ts" "add|list" \
    "index.ts registers CLI commands"

  # Check tests are not stubs
  _check_not_stub "tests/store.test.ts"    "store.test.ts tests"
  _check_not_stub "tests/commands.test.ts" "commands.test.ts tests"

  # Check tests have actual test cases
  _check_contains "tests/store.test.ts" "it\(|test\(" \
    "store.test.ts has test cases (it/test blocks)"
}

###############################################################################
# SECTION 3: package.json validation
###############################################################################

_verify_package_json() {
  _hdr "3. Package Configuration"

  if [[ ! -f "${PROJECT_DIR}/package.json" ]]; then
    _fail "package.json missing"
    return 0
  fi

  # Check scripts
  local has_build has_test has_typecheck
  # Use python3 with safe path handling (pass path as argument, not inline)
  has_build=$(python3 -c "
import json, sys
path = sys.argv[1]
try:
    with open(path) as f:
        d = json.load(f)
    print('yes' if 'build' in d.get('scripts', {}) else 'no')
except Exception:
    print('no')
" "${PROJECT_DIR}/package.json" 2>/dev/null || echo "no")

  has_test=$(python3 -c "
import json, sys
path = sys.argv[1]
try:
    with open(path) as f:
        d = json.load(f)
    print('yes' if 'test' in d.get('scripts', {}) else 'no')
except Exception:
    print('no')
" "${PROJECT_DIR}/package.json" 2>/dev/null || echo "no")

  has_typecheck=$(python3 -c "
import json, sys
path = sys.argv[1]
try:
    with open(path) as f:
        d = json.load(f)
    print('yes' if 'typecheck' in d.get('scripts', {}) else 'no')
except Exception:
    print('no')
" "${PROJECT_DIR}/package.json" 2>/dev/null || echo "no")

  if [[ "$has_build" == "yes" ]]; then _ok "script: build"; else _fail "missing script: build"; fi
  if [[ "$has_test" == "yes" ]]; then _ok "script: test"; else _fail "missing script: test"; fi
  if [[ "$has_typecheck" == "yes" ]]; then _ok "script: typecheck"; else _warn "missing script: typecheck"; fi

  # Check dependencies
  _check_contains "package.json" "commander"   "dependency: commander"
  _check_contains "package.json" "typescript"  "devDependency: typescript"
  _check_contains "package.json" "vitest"      "devDependency: vitest"
}

###############################################################################
# SECTION 4: npm install
###############################################################################

_verify_npm_install() {
  _hdr "4. Dependencies (npm install)"

  if ! command -v npm &>/dev/null; then
    _skip "npm not installed"
    return 0
  fi

  if [[ -d "${PROJECT_DIR}/node_modules" ]]; then
    _ok "node_modules/ already present"
  else
    _info "Running npm install..."
    local output
    if output=$(cd "${PROJECT_DIR}" && timeout 120 npm install --no-fund --no-audit 2>&1); then
      _ok "npm install succeeded"
    else
      _fail "npm install failed"
      echo "$output" | tail -10 | sed 's/^/    /'
    fi
  fi

  # Verify key packages
  for pkg in commander typescript vitest; do
    if [[ -d "${PROJECT_DIR}/node_modules/${pkg}" ]]; then
      _ok "installed: ${pkg}"
    else
      _fail "missing: ${pkg}"
    fi
  done
}

###############################################################################
# SECTION 5: TypeScript compilation
###############################################################################

_verify_typecheck() {
  _hdr "5. TypeScript Compilation"

  if ! command -v npx &>/dev/null; then
    _skip "npx not available"
    return 0
  fi

  if [[ ! -d "${PROJECT_DIR}/node_modules" ]]; then
    _skip "node_modules not installed (run npm install first)"
    return 0
  fi

  _info "Running tsc --noEmit..."
  local output
  if output=$(cd "${PROJECT_DIR}" && timeout 60 npx tsc --noEmit 2>&1); then
    _ok "TypeScript: zero errors"
  else
    local error_count
    error_count=$(echo "$output" | grep -c "error TS" || echo "?")
    _fail "TypeScript: ${error_count} error(s)"
    echo "$output" | grep "error TS" | head -10 | sed 's/^/    /'
  fi
}

###############################################################################
# SECTION 6: Build
###############################################################################

_verify_build() {
  _hdr "6. Build (tsc)"

  if ! command -v npx &>/dev/null; then
    _skip "npx not available"
    return 0
  fi

  if [[ ! -d "${PROJECT_DIR}/node_modules" ]]; then
    _skip "node_modules not installed"
    return 0
  fi

  _info "Running npm run build..."
  local output
  if output=$(cd "${PROJECT_DIR}" && timeout 60 npm run build 2>&1); then
    _ok "Build succeeded"
  else
    _fail "Build failed"
    echo "$output" | tail -10 | sed 's/^/    /'
  fi

  # Check output
  if [[ -f "${PROJECT_DIR}/dist/index.js" ]]; then
    _ok "dist/index.js produced"
    local dist_size
    dist_size=$(du -sh "${PROJECT_DIR}/dist/" 2>/dev/null | cut -f1)
    _info "dist/ size: ${dist_size}"
  else
    _fail "dist/index.js not found after build"
  fi
}

###############################################################################
# SECTION 7: Tests
###############################################################################

_verify_tests() {
  _hdr "7. Tests (vitest)"

  if ! command -v npx &>/dev/null; then
    _skip "npx not available"
    return 0
  fi

  if [[ ! -d "${PROJECT_DIR}/node_modules" ]]; then
    _skip "node_modules not installed"
    return 0
  fi

  _info "Running npm test..."
  local output exit_code=0
  output=$(cd "${PROJECT_DIR}" && timeout 60 npm test 2>&1) || exit_code=$?

  if [[ $exit_code -eq 0 ]]; then
    _ok "All tests passed"
    # Extract summary line
    echo "$output" | grep -E "(Tests|✓|✗|passed|failed|PASS|FAIL)" | head -5 | sed 's/^/    /'
  else
    _fail "Tests failed (exit code ${exit_code})"
    echo "$output" | tail -20 | sed 's/^/    /'
  fi

  # Count test cases
  local test_count
  test_count=$(echo "$output" | grep -cE "(✓|✗|PASS|FAIL|passed)" || echo "?")
  _info "Detected ~${test_count} test result lines"
}

###############################################################################
# SECTION 8: Functional smoke test
###############################################################################

# ── Smoke test helpers (split from monolithic _verify_smoke_test) ──────────

_smoke_extract_task_id() {
  # Extract first task ID from TODO_FILE (handles both array and object formats)
  if [[ -f "${TODO_FILE}" ]]; then
    python3 -c "
import json, sys
with open(sys.argv[1]) as f:
    data = json.load(f)
todos = data if isinstance(data, list) else data.get('todos', [])
if todos:
    print(todos[0].get('id', ''))
" "${TODO_FILE}" 2>/dev/null || echo ""
  fi
}

_smoke_test_add() {
  local cli="$1"
  _info "Testing 'add' command..."
  local add_out add_exit=0
  add_out=$(timeout 10 $cli add "Buy groceries" --priority high 2>&1) || add_exit=$?
  if [[ $add_exit -eq 0 ]]; then
    _ok "add: exit code 0"
  else
    _fail "add: exit code ${add_exit}"
    _info "Output: ${add_out}"
  fi

  # Add more items for subsequent tests
  timeout 10 $cli add "Write documentation" --priority medium 2>&1 >/dev/null || true
  timeout 10 $cli add "Fix bug in parser" --priority low 2>&1 >/dev/null || true
}

_smoke_test_list() {
  local cli="$1"
  _info "Testing 'list' command..."
  local list_out list_exit=0
  list_out=$(timeout 10 $cli list 2>&1) || list_exit=$?
  if [[ $list_exit -eq 0 ]]; then
    _ok "list: exit code 0"
    if echo "$list_out" | grep -qi "groceries"; then
      _ok "list: shows 'Buy groceries'"
    else
      _warn "list: output doesn't contain expected task"
      _info "Output: ${list_out}"
    fi
  else
    _fail "list: exit code ${list_exit}"
    _info "Output: ${list_out}"
  fi

  # Test: list --filter and --priority options
  _info "Testing 'list --filter pending'..."
  local filter_out filter_exit=0
  filter_out=$(timeout 10 $cli list --filter pending 2>&1) || filter_exit=$?
  if [[ $filter_exit -eq 0 ]]; then
    _ok "list --filter pending: exit code 0"
  else
    _warn "list --filter pending: exit code ${filter_exit}"
  fi

  _info "Testing 'list --priority high'..."
  local prio_out prio_exit=0
  prio_out=$(timeout 10 $cli list --priority high 2>&1) || prio_exit=$?
  if [[ $prio_exit -eq 0 ]]; then
    _ok "list --priority high: exit code 0"
  else
    _warn "list --priority high: exit code ${prio_exit}"
  fi
}

_smoke_test_stats() {
  local cli="$1"
  _info "Testing 'stats' command..."
  local stats_out stats_exit=0
  stats_out=$(timeout 10 $cli stats 2>&1) || stats_exit=$?
  if [[ $stats_exit -eq 0 ]]; then
    _ok "stats: exit code 0"
  else
    _warn "stats: exit code ${stats_exit}"
  fi
}

_smoke_test_done() {
  local cli="$1" task_id="$2"
  _info "Testing 'done' command..."
  if [[ -n "$task_id" ]]; then
    local done_out done_exit=0
    done_out=$(timeout 10 $cli done "$task_id" 2>&1) || done_exit=$?
    if [[ $done_exit -eq 0 ]]; then
      _ok "done: exit code 0 (marked ${task_id:0:8}...)"
    else
      _warn "done: exit code ${done_exit}"
    fi
  else
    _warn "done: could not extract task ID from storage"
  fi
}

_smoke_test_undone() {
  local cli="$1" task_id="$2"
  _info "Testing 'undone' command..."
  if [[ -n "$task_id" ]]; then
    local undone_out undone_exit=0
    undone_out=$(timeout 10 $cli undone "$task_id" 2>&1) || undone_exit=$?
    if [[ $undone_exit -eq 0 ]]; then
      _ok "undone: exit code 0 (unmarked ${task_id:0:8}...)"
    else
      _warn "undone: exit code ${undone_exit}"
    fi
  else
    _skip "undone: no task ID available"
  fi
}

_smoke_test_edit() {
  local cli="$1" task_id="$2"
  _info "Testing 'edit' command..."
  if [[ -n "$task_id" ]]; then
    local edit_out edit_exit=0
    edit_out=$(timeout 10 $cli edit "$task_id" --title "Updated groceries" 2>&1) || edit_exit=$?
    if [[ $edit_exit -eq 0 ]]; then
      _ok "edit: exit code 0"
    else
      _warn "edit: exit code ${edit_exit}"
    fi
  else
    _skip "edit: no task ID available"
  fi
}

_smoke_test_remove() {
  local cli="$1" task_id="$2"
  _info "Testing 'remove' command..."
  if [[ -n "$task_id" ]]; then
    local rm_out rm_exit=0
    rm_out=$(timeout 10 $cli remove "$task_id" 2>&1) || rm_exit=$?
    if [[ $rm_exit -eq 0 ]]; then
      _ok "remove: exit code 0"
    else
      _warn "remove: exit code ${rm_exit}"
    fi
  else
    _skip "remove: no task ID available"
  fi
}

_smoke_test_clear() {
  local cli="$1"
  _info "Testing 'clear --yes' command..."
  # First mark a task done so clear has something to remove
  local tid
  tid=$(_smoke_extract_task_id)
  if [[ -n "$tid" ]]; then
    timeout 10 $cli done "$tid" 2>&1 >/dev/null || true
  fi
  local clear_out clear_exit=0
  clear_out=$(timeout 10 $cli clear --yes 2>&1) || clear_exit=$?
  if [[ $clear_exit -eq 0 ]]; then
    _ok "clear --yes: exit code 0"
  else
    _warn "clear --yes: exit code ${clear_exit}"
  fi
}

_smoke_test_error_handling() {
  local cli="$1"
  _info "Testing error handling..."
  local err_out err_exit=0
  err_out=$(timeout 10 $cli show "nonexistent-id-00000000" 2>&1) || err_exit=$?
  if [[ $err_exit -ne 0 ]]; then
    _ok "show non-existent: correctly returns non-zero exit (${err_exit})"
  else
    _warn "show non-existent: returned exit 0 (expected non-zero)"
  fi
}

_smoke_test_shebang() {
  _info "Testing shebang in dist/index.js..."
  if head -1 "${PROJECT_DIR}/dist/index.js" | grep -q '#!/usr/bin/env node'; then
    _ok "dist/index.js has shebang (#!/usr/bin/env node)"
  else
    _warn "dist/index.js missing shebang (#!/usr/bin/env node)"
  fi
}

_verify_smoke_test() {
  _hdr "8. Functional Smoke Test"

  if [[ ! -f "${PROJECT_DIR}/dist/index.js" ]]; then
    _skip "dist/index.js not found — build first"
    return 0
  fi

  # Check shebang first (doesn't need runtime)
  _smoke_test_shebang

  # Use a temp directory for todo storage so we don't pollute the user's home
  local tmp_store
  tmp_store=$(mktemp -d)
  export TODO_FILE="${tmp_store}/todos.json"
  trap "rm -rf '${tmp_store}'" EXIT

  local cli="node ${PROJECT_DIR}/dist/index.js"

  _smoke_test_add "$cli"
  _smoke_test_list "$cli"
  _smoke_test_stats "$cli"

  # Extract task ID for mutation tests
  local task_id
  task_id=$(_smoke_extract_task_id)

  _smoke_test_done "$cli" "$task_id"
  _smoke_test_undone "$cli" "$task_id"
  _smoke_test_edit "$cli" "$task_id"
  _smoke_test_clear "$cli"
  _smoke_test_remove "$cli" "$task_id"
  _smoke_test_error_handling "$cli"

  # Cleanup
  unset TODO_FILE
}

###############################################################################
# SECTION 9: Proxym integration (optional)
###############################################################################

_verify_proxym() {
  _hdr "9. Proxym Integration"

  if ! $WITH_PROXYM; then
    _skip "Proxym checks disabled (use --with-proxym to enable)"
    return 0
  fi

  # Check server
  if ! timeout 5 curl -sf "${PROXYM_URL}/health" >/dev/null 2>&1; then
    _fail "Proxym server not reachable at ${PROXYM_URL}"
    return 0
  fi
  _ok "Proxym server reachable"

  CLI="proxym --proxy ${PROXYM_URL}"

  # Check project exists
  local proj_output
  proj_output=$(timeout 10 $CLI projects 2>&1) || true
  if echo "$proj_output" | grep -q "todo-app-ts"; then
    _ok "Project 'todo-app-ts' registered in proxym"
  else
    _warn "Project 'todo-app-ts' not found in proxym registry"
  fi

  # Check tickets
  local ticket_output
  ticket_output=$(timeout 10 $CLI ticket list 2>&1) || true
  local ticket_count
  ticket_count=$(echo "$ticket_output" | grep -c "TKT-" || echo 0)
  _ok "Tickets in proxym: ${ticket_count}"

  # Check for human tickets
  local human_tickets
  human_tickets=$(echo "$ticket_output" | grep -c "human" || echo 0)
  if [[ "$human_tickets" -gt 0 ]]; then
    _warn "Human intervention tickets: ${human_tickets}"
    echo "$ticket_output" | grep "human" | head -5 | sed 's/^/    /'
  else
    _ok "No human intervention tickets (everything auto-completed)"
  fi

  # Check job queue
  local queue_output
  queue_output=$(timeout 10 $CLI tools queue 2>&1) || true
  echo "$queue_output" | head -3 | sed 's/^/    /'

  # Check metadata matches
  if [[ -f "${PROJECT_DIR}/.proxym/metadata.json" ]]; then
    local stored_project_id
    # Use python3 with safe path handling (pass path as argument, not inline)
    stored_project_id=$(python3 -c "
import json, sys
path = sys.argv[1]
try:
    with open(path) as f:
        print(json.load(f).get('project_id', ''))
except Exception:
    print('')
" "${PROJECT_DIR}/.proxym/metadata.json" 2>/dev/null || echo "")
    if [[ -n "$stored_project_id" ]]; then
      _ok "Metadata project_id: ${stored_project_id}"
    else
      _warn "Could not read project_id from metadata.json"
    fi
  fi
}

###############################################################################
# Summary
###############################################################################

_print_summary() {
  echo ""
  echo -e "${BOLD}════════════════════════════════════════════════════════════${RESET}"
  echo -e "${BOLD}  Verification Summary${RESET}"
  echo -e "${BOLD}════════════════════════════════════════════════════════════${RESET}"
  echo -e "  Project: ${PROJECT_DIR}"
  echo ""
  echo -e "  ${GREEN}✓ Passed:${RESET}  ${PASS}"
  echo -e "  ${RED}✗ Failed:${RESET}  ${FAIL}"
  echo -e "  ${YELLOW}⚠ Warns:${RESET}   ${WARN}"
  echo -e "  ${DIM}⊘ Skipped:${RESET} ${SKIP}"
  echo ""

  local total=$((PASS + FAIL))
  if [[ $total -gt 0 ]]; then
    local pct=$(( PASS * 100 / total ))
    echo -e "  Score: ${BOLD}${pct}%${RESET} (${PASS}/${total})"
  fi

  if [[ $FAIL -eq 0 ]]; then
    echo -e "  ${GREEN}${BOLD}All checks passed! ✨${RESET}"
  elif [[ $FAIL -le 3 ]]; then
    echo -e "  ${YELLOW}${BOLD}Mostly working — a few issues to fix.${RESET}"
  else
    echo -e "  ${RED}${BOLD}Multiple failures — AI generation may need another pass.${RESET}"
    echo ""
    echo -e "  ${DIM}Tips:${RESET}"
    echo -e "    1. Check human tickets: proxym ticket list --status todo"
    echo -e "    2. Re-dispatch failed tickets: proxym tools dispatch --ticket TKT-XXX --tool aider"
    echo -e "    3. Fix manually and mark done: proxym ticket update TKT-XXX --status done"
  fi

  echo -e "${BOLD}════════════════════════════════════════════════════════════${RESET}"
  echo ""
}

###############################################################################
# Main
###############################################################################

main() {
  echo -e "${BOLD}${CYAN}"
  echo "  ┌─────────────────────────────────────────────┐"
  echo "  │  todo-app-ts · Verification Suite            │"
  echo "  └─────────────────────────────────────────────┘"
  echo -e "${RESET}"
  echo -e "  ${DIM}Project: ${PROJECT_DIR}${RESET}"
  echo -e "  ${DIM}Date:    $(date)${RESET}"

  _verify_structure
  _verify_source_code
  _verify_package_json
  _verify_npm_install
  _verify_typecheck
  _verify_build
  _verify_tests
  _verify_smoke_test
  _verify_proxym
  _print_summary

  [[ $FAIL -eq 0 ]] && exit 0 || exit 1
}

main
