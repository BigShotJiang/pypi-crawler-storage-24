"""Aider CLI adapter.

Aider connects to LLMs via the LiteLLM proxy using the OpenAI-compatible API.
Environment variables OPENAI_API_BASE and OPENAI_API_KEY are injected
automatically so aider routes all requests through the proxy.
"""
from __future__ import annotations

from proxym.tools.adapters._base import BaseAdapter


class AiderAdapter(BaseAdapter):
    """Adapter for aider CLI."""

    # env vars that aider recognises for OpenAI-compatible endpoints
    ENV_KEYS = {
        "OPENAI_API_KEY",
        "OPENAI_API_BASE",
        "AIDER_OPENAI_API_BASE",
        "AIDER_MODEL",
    }

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        args = ["aider", "--yes-always", "--no-auto-commits",
                "--no-show-model-warnings", "--edit-format", "diff"]
        if mode == "architect":
            args.append("--architect")
        if model:
            args.extend(["--model", model])
        if files:
            for f in files:
                args.append(f)
        args.extend(["--message", prompt])
        return args
