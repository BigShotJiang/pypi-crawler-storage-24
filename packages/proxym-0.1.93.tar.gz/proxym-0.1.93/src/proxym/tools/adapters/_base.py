"""BaseAdapter ABC — shared interface for all tool adapters.

All CLI tools connect to LLMs through the LiteLLM proxy. The base adapter
injects ``OPENAI_API_BASE``, ``OPENAI_API_KEY``, ``ANTHROPIC_BASE_URL``, and
``ANTHROPIC_API_KEY`` into the subprocess environment so every tool routes
requests through the proxy automatically.
"""
from __future__ import annotations

import asyncio
import os
import shutil
from abc import ABC, abstractmethod

import structlog

from proxym.tools import ToolDefinition
from proxym.tools.adapters._result import ToolResult

logger = structlog.get_logger()


def _resolve_model_for_tool(model: str, tool_name: str) -> str:
    """Resolve proxy model aliases (smart, balanced, …) to concrete litellm model names.

    Returns the resolved model string suitable for the tool CLI ``--model`` flag.
    For tools connecting through the LiteLLM proxy the returned name uses the
    ``openai/<model>`` prefix so litellm routes correctly.
    """
    try:
        from proxym.config import get_settings
        settings = get_settings()
        resolved = settings.resolve_model_alias(model)
        if resolved != model:
            # Alias was resolved — prefix with openai/ for proxy routing
            return f"openai/{resolved}"
    except Exception:
        pass

    # Common unresolvable aliases → sensible defaults
    _ALIAS_DEFAULTS = {
        "smart": "openai/claude-sonnet",
        "balanced": "openai/claude-sonnet",
        "cheap": "openai/claude-haiku",
        "premium": "openai/claude-opus",
    }
    if model in _ALIAS_DEFAULTS:
        return _ALIAS_DEFAULTS[model]

    return model


def _build_proxy_env() -> dict[str, str]:
    """Build subprocess environment with LiteLLM proxy connection vars.

    Reads the proxy URL and API key from proxym settings and injects them
    as environment variables that CLI tools recognise.
    """
    env = dict(os.environ)
    try:
        from proxym.config import get_settings
        settings = get_settings()
        proxy_url = f"http://localhost:{settings.port}"
        api_key = settings.master_key or os.environ.get("PROXYM_API_KEY", "sk-proxym-master")

        # OpenAI-compatible (aider, goose, codex, open-interpreter, plandex, llm-cli)
        env.setdefault("OPENAI_API_KEY", api_key)
        env["OPENAI_API_BASE"] = f"{proxy_url}/v1"
        env["OPENAI_BASE_URL"] = f"{proxy_url}/v1"

        # Aider-specific
        env["AIDER_OPENAI_API_BASE"] = f"{proxy_url}/v1"

        # Anthropic (claude-code)
        env.setdefault("ANTHROPIC_API_KEY", api_key)
        env["ANTHROPIC_BASE_URL"] = proxy_url
    except Exception:
        pass
    return env


class BaseAdapter(ABC):
    """Base class for tool adapters."""

    def __init__(self, tool: ToolDefinition) -> None:
        self.tool = tool

    @abstractmethod
    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        """Build CLI argument list."""
        ...

    async def run(
        self,
        prompt: str,
        project_dir: str,
        ticket_id: str = "",
        mode: str = "",
        model: str = "",
        files: list[str] | None = None,
        timeout: float = 300,
    ) -> ToolResult:
        """Launch the tool and wait for completion.

        If the tool binary is not found, delegates to LLM fallback
        for real execution via the proxy API.
        """
        import time
        from proxym.tools.adapters._llm_fallback import _llm_fallback_execute

        binary = shutil.which(self.tool.binary) if self.tool.binary else None
        if not binary:
            logger.info("adapter_llm_fallback", tool=self.tool.name,
                        binary=self.tool.binary, reason="binary not found")
            return await _llm_fallback_execute(
                self.tool.name, prompt, ticket_id, project_dir, mode, model, timeout,
            )

        # Resolve model aliases before passing to CLI
        resolved_model = _resolve_model_for_tool(model, self.tool.name) if model else model
        args = self.build_args(prompt, project_dir, mode, resolved_model, files)

        # Inject LiteLLM proxy env vars into subprocess
        env = _build_proxy_env()

        logger.info("tool_adapter_run", tool=self.tool.name, args=args[:5],
                     cwd=project_dir, model=resolved_model)
        t0 = time.monotonic()
        try:
            proc = await asyncio.create_subprocess_exec(
                *args,
                cwd=project_dir,
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_b, stderr_b = await asyncio.wait_for(
                proc.communicate(), timeout=timeout,
            )
            duration = time.monotonic() - t0
            result = ToolResult(
                tool=self.tool.name,
                ticket_id=ticket_id,
                exit_code=proc.returncode or 0,
                stdout=stdout_b.decode(errors="replace"),
                stderr=stderr_b.decode(errors="replace"),
                duration_s=duration,
                execution_metadata={
                    "adapter": self.tool.name, "binary": binary,
                    "args": args[:5], "model": resolved_model,
                },
            )
            logger.info("tool_adapter_done", tool=self.tool.name,
                        exit_code=result.exit_code, duration=f"{duration:.1f}s")
            return result
        except asyncio.TimeoutError:
            duration = time.monotonic() - t0
            return ToolResult(
                tool=self.tool.name, ticket_id=ticket_id,
                exit_code=-1, stderr=f"Timeout after {timeout}s",
                duration_s=duration,
            )
        except FileNotFoundError:
            duration = time.monotonic() - t0
            logger.info("adapter_binary_vanished", tool=self.tool.name)
            return await _llm_fallback_execute(
                self.tool.name, prompt, ticket_id, project_dir, mode, model, timeout,
            )
        except Exception as exc:
            duration = time.monotonic() - t0
            return ToolResult(
                tool=self.tool.name, ticket_id=ticket_id,
                exit_code=-1, stderr=str(exc), duration_s=duration,
            )
