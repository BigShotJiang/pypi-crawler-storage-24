"""Castor: A secure microkernel for LLM Agents.

This is a placeholder release. The full package is coming soon.
See https://github.com/substratum-labs/castor for source code.
"""

__version__ = "0.0.1"
