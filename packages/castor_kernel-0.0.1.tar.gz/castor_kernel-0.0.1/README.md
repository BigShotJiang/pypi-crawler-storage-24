# castor-kernel

**A secure microkernel for LLM Agents.**

This is a placeholder release to reserve the package name. The full release is coming soon.

See the [GitHub repository](https://github.com/substratum-labs/castor) for source code and documentation.
