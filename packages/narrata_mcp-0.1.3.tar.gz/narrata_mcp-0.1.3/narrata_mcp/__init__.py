"""narrata MCP server package."""
