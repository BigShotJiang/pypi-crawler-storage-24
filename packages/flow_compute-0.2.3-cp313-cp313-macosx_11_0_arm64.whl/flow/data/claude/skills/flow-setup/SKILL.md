---
name: flow-setup
description: Set up flow-compute from scratch. Installs the package, configures API credentials, validates connectivity, and runs a test job.
disable-model-invocation: true
allowed-tools: Bash(flow *), Bash(pip *), Bash(uv *)
---

# Set Up Flow

Get a user from zero to running GPU workloads.

## Step 1: Check installation

```bash
flow --version 2>/dev/null
```

If not installed:
```bash
pip install flow-compute
```

## Step 2: Run setup wizard

```bash
flow setup
```

This configures:
- API key (from https://console.mithril.ai)
- Default project
- Default region

## Step 3: Validate connectivity

```bash
flow health
```

This checks:
- API connectivity
- Authentication
- SSH key configuration
- State sync

If health checks fail, help the user fix each issue.

## Step 4: Verify GPU access

```bash
flow availability --json 2>/dev/null || flow availability
```

Show what GPUs are available and current pricing.

## Step 5: Optional test run

Ask the user if they want to run a quick GPU test:

```bash
flow submit "nvidia-smi && python -c 'import torch; print(f\"CUDA: {torch.cuda.is_available()}, GPU: {torch.cuda.get_device_name(0)}\")'" -i a100 -n gpu-test --terminate-on-exit
```

Then:
```bash
flow logs gpu-test -f
```
