---
name: flow-run
description: Submit GPU workloads to the Mithril compute platform. Checks live pricing and availability, helps pick the right GPU, and generates submission code.
disable-model-invocation: true
argument-hint: "[script or description]"
allowed-tools: Bash(flow *), Read, Grep, Glob
---

# Submit a GPU Workload

Help the user run something on GPUs. Inject live market data, pick the right GPU, generate and execute the submission.

## Step 1: Understand what the user wants to run

Parse `$ARGUMENTS` to determine:
- Script path or command to run
- GPU requirements (type, count, memory)
- Any special needs (multi-node, volumes, image, ports)

If unclear, ask the user what they want to run.

## Step 2: Check live pricing and availability

Inject current market data so you can recommend the best option:

```bash
flow pricing --json 2>/dev/null
flow availability --json 2>/dev/null
```

Present the user with 2-3 options (cheapest, fastest, best value) with pricing.

## Step 3: Generate submission

Based on the user's needs, generate EITHER:

**SDK approach** (if they're writing Python):
```python
import flow

@flow.run(gpu="H100", gpu_count=8)
def main():
    # their code here
    pass
```

**CLI approach** (if they have a script to run):
```bash
flow submit train.py -i 8xh100 -n my-training-job
```

**Quick grab** (if they want interactive access):
```bash
flow grab 8 h100 --hours 4
```

## Step 4: Execute (with user confirmation)

After the user approves, run the command. Then show:
- Task ID and name
- How to check status: `flow status <task>`
- How to stream logs: `flow logs <task> -f`
- How to SSH in: `flow ssh <task>`

## Instance type guidance

Help users translate natural language to instance types:
- "I need 4 A100s" → `4xa100` or `a100-80gb.sxm.4x`
- "One H100" → `h100` or `1xh100`
- "Cheapest GPU with 80GB" → check pricing, likely A100
- "Fastest option for LLM training" → `8xh100` (8x H100 SXM)

GPU tiers (fastest to most economical): B200 > H100 SXM > H100 PCIe > A100 SXM > A100 PCIe > L40S
