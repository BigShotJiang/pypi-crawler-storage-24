---
name: flow-dashboard
description: Show live GPU task status, costs, and logs. Checks running jobs and offers to tail logs, SSH in, or cancel tasks.
disable-model-invocation: true
allowed-tools: Bash(flow *)
---

# GPU Task Dashboard

Show the user what's happening with their GPU workloads using live data.

## Step 1: Fetch current state

```bash
flow status --json 2>/dev/null || flow status
```

## Step 2: Present a summary

Show a clean table of active tasks:
- Task name and ID
- Status (PENDING / PROVISIONING / RUNNING / etc.)
- GPU type and count
- Runtime duration
- Cost so far (cost_per_hour x runtime)
- Region

Highlight any tasks that are FAILED, PREEMPTING, or stuck in PENDING.

## Step 3: Offer actions

Based on what's running, suggest:
- **For RUNNING tasks**: "Want to see logs? SSH in? Cancel?"
- **For FAILED tasks**: "Want to check the logs to see what went wrong?"
- **For PENDING tasks**: "This has been pending for X minutes. Want to check availability or adjust pricing?"
- **For completed tasks**: "Want to download results or check final logs?"

## Step 4: Execute requested action

If the user wants logs:
```bash
flow logs <task-id> --tail 50
```

If they want to SSH:
```bash
flow ssh <task-id>
```

If they want to cancel:
```bash
flow cancel <task-id> --yes
```

If they want cost summary:
```bash
flow status --json | # parse total costs across all tasks
```
