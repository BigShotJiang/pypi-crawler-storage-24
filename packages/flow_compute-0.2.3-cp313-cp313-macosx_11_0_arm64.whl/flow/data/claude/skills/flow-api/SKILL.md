---
name: flow-api
description: Flow GPU compute SDK and CLI reference. Auto-loads when code uses `import flow`, `flow.run()`, `FlowApp`, or the `flow` CLI. Covers task submission, instance types, volumes, SSH, health monitoring, and the decorator API for the Mithril compute platform.
user-invocable: false
---

# Flow SDK and CLI Reference

Flow (`pip install flow-compute`) is a CLI and Python SDK for running GPU workloads on the Mithril compute platform.

## SDK Entry Points

### 1. One-liner submission
```python
import flow
task = flow.run("python train.py", instance_type="a100")
task = flow.run("python train.py", gpu="H100", gpu_count=8)
```

### 2. Client with full control
```python
from flow import Flow, TaskConfig
with Flow() as f:
    task = f.submit(command="python train.py", gpu="H100")
    tasks = f.list_tasks(status="running")
    logs = f.logs(task.task_id, follow=True)
    f.cancel(task.task_id)
```

Sub-clients: `f.tasks`, `f.volumes`, `f.reservations`, `f.ssh`, `f.identity`, `f.instances`, `f.dev`.

### 3. Decorator API (recommended for Python)
```python
app = flow.FlowApp()

@app.function(gpu="H100", gpu_count=8, image="pytorch/pytorch:2.2.2-cuda12.1-cudnn8-runtime")
def train(lr: float = 0.001) -> dict:
    # runs on remote GPU
    return {"loss": 0.01}

result = train.remote(lr=0.001)    # sync remote call, returns result
task = train.spawn(lr=0.001)       # async, returns Task handle
results = list(train.map([0.1, 0.01, 0.001]))  # parallel fan-out
```

### 4. Class-based remote execution
```python
@app.cls(gpu="A100")
class Predictor:
    @flow.enter()
    def setup(self):
        self.model = load_model()

    @flow.method()
    def predict(self, text: str) -> dict:
        return self.model(text)
```

### 5. Image builder (fluent API)
```python
image = (flow.Image.debian_slim("3.11")
    .pip_install("torch", "transformers")
    .apt_install("git")
    .run_commands("echo hello")
    .env({"CUDA_VISIBLE_DEVICES": "0,1"}))
```

### 6. Zero-import invocation
```python
result = flow.invoke("train.py", "train_model", args=[0.001], gpu="H100")
```

## TaskConfig Fields

Key fields for `TaskConfig` or `flow.run()` kwargs:

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `command` | `str` | required | Command to execute |
| `instance_type` | `str \| list[str]` | None | GPU spec: `"a100"`, `"8xh100"`, `"h100-80gb.sxm.8x"` |
| `gpu` | `str` | None | Shorthand: `"H100"`, `"A100"` |
| `gpu_count` | `int` | None | Number of GPUs |
| `image` | `str \| Image` | PyTorch default | Container image |
| `name` | `str` | `"flow-task"` | Task name |
| `env` | `dict[str,str]` | `{}` | Environment variables |
| `volumes` | `list[VolumeSpec]` | `[]` | Volume mounts |
| `num_instances` | `int` | `1` | Nodes for distributed (1-100) |
| `max_price_per_hour` | `float` | None | Max hourly price USD |
| `max_run_time_hours` | `float` | None | Max runtime (0-168h) |
| `priority` | `"low"\|"med"\|"high"` | `"med"` | Scheduling priority |
| `region` | `str` | None | Target region |
| `allocation_mode` | `"spot"\|"reserved"\|"auto"` | `"spot"` | Allocation strategy |
| `upload_code` | `bool` | `True` | Sync local code |
| `ports` | `list[int]` | `[]` | Ports to expose (>=1024) |
| `terminate_on_exit` | `bool` | `False` | Cancel on container exit |
| `schedule` | `Cron\|Period` | None | Scheduled runs |
| `constraints` | `Constraints` | None | Cluster selection constraints |
| `secrets` | `list[Secret]` | None | Secrets to inject |

## Instance Type Naming

Multiple formats accepted:
- Short: `a100`, `h100`, `l40s`
- With count: `8xh100`, `4xa100`
- Canonical: `h100-80gb.sxm.8x`, `a100-80gb.pcie.4x`
- GPU types: H100, A100, L40S, B200

## CLI Commands (35 total)

### Submission and Lifecycle
```bash
flow submit train.py -i h100 --gpu-count 8 -n my-job    # Submit task
flow submit config.yaml                                    # Submit from YAML
flow status                                                # List all tasks
flow status <task> --json                                  # Task details
flow logs <task> -f                                        # Stream logs
flow cancel <task>                                         # Cancel task
```

### Interactive GPU Access
```bash
flow grab 8 h100 --hours 4          # Quick GPU grab (sleep infinity + SSH)
flow release <task>                  # Release grabbed resources
flow ssh <task>                      # SSH into instance
flow ssh <task> -- nvidia-smi        # Run remote command
flow ssh <task> --node 2             # SSH to specific node
flow dev                             # Persistent dev VM
flow dev --gpu H100 --sync .         # Dev VM with code sync
```

### Remote Operations
```bash
flow upload-code <task>              # Sync code to running task
flow jupyter <task>                  # Start Jupyter with SSH tunnel
flow colab up h100 --hours 4         # Launch Colab-ready instance
flow ports open <task> --port 8080   # Open port on instance
flow mount <volume> <task>           # Attach volume to task
```

### Infrastructure
```bash
flow volume create --size 100 --name data       # Create volume
flow volume list                                 # List volumes
flow ssh-key list                                # List SSH keys
flow ssh-key sync                                # Sync keys to platform
flow k8s list                                    # List K8s clusters
flow reserve create h100 --hours 24              # Create reservation
flow instance list                               # List instances (alias)
```

### Market and Monitoring
```bash
flow pricing --gpu h100              # GPU pricing
flow availability --gpu h100         # GPU availability by region
flow health                          # System health check
flow health <task>                   # GPU health for task
flow health dashboard <task>         # Grafana dashboard via SSH
flow ask "cheapest 8 H100s"          # AI-powered resource search
```

### Model Serving
```bash
flow serve meta-llama/Llama-3-8B --gpu h100 --num-gpus 4  # Serve with vLLM
flow deploy app.py                                          # Deploy serverless
```

### Setup
```bash
flow setup                           # Configure credentials
flow init                            # Generate task config YAML
flow tutorial                        # Guided onboarding
flow update                          # Update flow-compute
```

## Task Object

`Task` returned by `flow.run()`, `f.submit()`, `fn.spawn()`:
- `task.task_id`, `task.name`, `task.status` (TaskStatus enum)
- `task.logs()`, `task.log_stream()`, `task.wait()`, `task.cancel()`
- `task.shell("nvidia-smi")`, `task.result()` (for decorator API)
- `task.is_running`, `task.is_terminal`, `task.has_ssh_access`
- `task.cost_per_hour`, `task.total_cost`, `task.region`
- `task.ssh_host`, `task.ssh_port`, `task.public_ip`

TaskStatus values: PENDING, PROVISIONING, RUNNING, PAUSED, PREEMPTING, COMPLETED, FAILED, CANCELLED.

## Volume API

```python
vol = f.create_volume(size_gb=100, name="data", interface="block")
f.mount_volume(vol.volume_id, task.task_id, mount_point="/data")
f.delete_volume(vol.volume_id)
```

## Scheduling

```python
@app.function(gpu="A100", schedule=flow.Cron("0 9 * * 1-5"))
def daily_train(): ...

@app.function(gpu="A100", schedule=flow.Period(hours=6))
def periodic_eval(): ...
```

## Secrets

```python
hf = flow.Secret.from_name("huggingface-token", env_var="HF_TOKEN")
wb = flow.Secret.from_env("WANDB_API_KEY")

@app.function(gpu="H100", secrets=[hf, wb])
def train(): ...
```

## Multi-Node Distributed Training

```python
task = flow.run(
    "torchrun --nproc_per_node=8 train.py",
    instance_type="8xh100",
    num_instances=4,   # 4 nodes x 8 GPUs = 32 GPUs
)
# Auto-set: FLOW_NODE_RANK, FLOW_NUM_NODES, FLOW_MAIN_IP
```

## Serverless / Web Endpoints

```python
@app.function(gpu="A100", min_containers=1, max_containers=10)
@flow.web_endpoint(method="POST")
@flow.concurrent(max_inputs=8)
async def predict(text: str) -> dict:
    return model(text)

# Deploy: flow deploy app.py
```

## Errors

All inherit from `FlowError`. Key types: `AuthenticationError`, `ResourceNotFoundError`, `TaskNotFoundError`, `ValidationError`, `ResourceNotAvailableError`, `QuotaExceededError`, `InsufficientBidPriceError`, `SSHNotReadyError`, `FlowTimeoutError`.

## Configuration

```bash
~/.flow/config.yaml          # Config file
MITHRIL_API_KEY=...           # API key env var
FLOW_PROVIDER=mithril         # Provider selection
flow setup                    # Interactive setup
```

## Installation

```bash
pip install flow-compute                # Core
pip install flow-compute[skypilot]      # Multi-cloud via SkyPilot
pip install flow-compute[serverless]    # Temporal serverless
pip install flow-compute[jupyter]       # Jupyter support
```
