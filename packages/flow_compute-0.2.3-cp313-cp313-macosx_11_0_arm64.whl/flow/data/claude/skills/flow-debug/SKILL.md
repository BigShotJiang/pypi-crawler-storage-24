---
name: flow-debug
description: Diagnose failed or stuck GPU tasks. Checks status, reads logs, runs health checks, and identifies common failure causes.
disable-model-invocation: true
argument-hint: "[task-id or task-name]"
allowed-tools: Bash(flow *)
---

# Debug a GPU Task

Diagnose why a task failed, is stuck, or is behaving unexpectedly.

## Step 1: Identify the task

If `$ARGUMENTS` is provided, use it as the task identifier. Otherwise:
```bash
flow status --json 2>/dev/null || flow status
```
Ask the user which task to investigate.

## Step 2: Get task details

```bash
flow status <task-id> --json 2>/dev/null || flow status <task-id>
```

Check: status, how long it's been in current state, instance type, region, error messages.

## Step 3: Read logs

```bash
flow logs <task-id> --tail 200
```

If container logs are empty, check startup/setup logs:
```bash
flow logs <task-id> --source startup --tail 100
flow logs <task-id> --source setup --tail 100
```

## Step 4: Diagnose common issues

### Task stuck in PENDING
- **Bid too low**: Check `flow pricing --gpu <type>` and compare with task's max_price
- **No availability**: Check `flow availability --gpu <type> --region <region>`
- **Quota exceeded**: Contact support or try a different GPU type
- **Recommendation**: Increase max_price, try a different region, or use a different GPU

### Task FAILED immediately
- **Image pull failure**: Check if the Docker image exists and is accessible
- **Command not found**: Check the command path and working directory
- **OOM on startup**: Model too large for GPU memory, need more/bigger GPUs
- **Permission denied**: Check SSH keys, API key validity

### Task FAILED during execution
- **CUDA OOM**: Reduce batch size, enable gradient accumulation, use more GPUs
- **NCCL timeout**: Multi-node networking issue, check interconnect
- **Python error**: Read the traceback in logs

### Task PREEMPTED
- **Spot preemption**: Normal for spot instances. Set up checkpointing:
  ```python
  @flow.run(gpu="H100", volumes=["checkpoints:/checkpoints"])
  def train():
      # Save checkpoints to /checkpoints periodically
      # They persist across preemptions via the volume
  ```

## Step 5: GPU health (if task is running)

```bash
flow health <task-id> 2>/dev/null
```

Check for GPU hardware issues: temperature, memory errors, driver problems.

## Step 6: Suggest fix

Based on diagnosis, provide a specific actionable fix. If the task needs to be resubmitted with different parameters, generate the corrected command.
