# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Flow is a CLI and SDK for submitting GPU workloads to the Mithril compute platform. It provides infrastructure mode (`flow instance create`) for direct GPU provisioning and research mode (`flow submit`, `flow dev`) for batch job submission.

## Common Commands

```bash
# Install dependencies
uv sync --dev

# Run all tests
uv run pytest

# Run specific test file
uv run pytest tests/unit/path/to/test_file.py -v

# Run tests matching pattern
uv run pytest -k "test_pattern" -v

# Run by marker (unit, integration, e2e, slow)
uv run pytest -m "unit"
uv run pytest -m "not slow"

# Lint and format
uv run ruff check --fix
uv run ruff format

# Check import boundaries
PYTHONPATH=src uv run lint-imports --config ./.importlinter

# Run CI gates (import contracts + cold import time)
make gates

```

## Architecture

Flow follows hexagonal architecture with strict import boundaries enforced by import-linter.

### Layer Dependency Rules

```
domain       ← pure business logic, no outward dependencies
protocols    ← interfaces/ports, depends only on domain
errors       ← error types
application  ← orchestration, depends on domain/protocols/errors
adapters     ← external integrations, depends inward only
cli          ← command-line interface, thin layer over sdk/application
sdk          ← public Python API
```

Key constraints:
- `flow.domain` cannot import from any other flow module
- `flow.adapters` cannot import `flow.cli` or `flow.sdk`
- `flow.cli` and `flow.sdk` cannot directly import `flow.adapters`
- Providers (`mithril`, `local`, `mock`) cannot import each other

### Package Structure

```
src/flow/
├── adapters/           # External integrations
│   ├── providers/      # Compute providers (mithril, local, mock)
│   │   └── builtin/mithril/  # Mithril-specific: API client, bidding, SSH, instances
│   ├── transport/      # SSH stack, file transfer
│   ├── http/           # HTTP client adapters
│   └── integrations/   # Health checks, Jupyter, metrics
├── application/        # Service orchestration, config management
├── cli/                # Click commands and UI components
│   ├── commands/       # CLI command implementations
│   └── ui/             # Rich terminal UI, formatters, presentation
├── core/               # Framework-agnostic core services
├── domain/             # Business logic, models, pricing
├── protocols/          # Abstract interfaces (ports)
├── sdk/                # Public Python API (flow.run, decorators)
└── plugins/            # Frontend adapters (YAML, SLURM)
```

### Provider Entry Points

Providers are registered via `pyproject.toml` entry points:
- `flow.providers`: `mithril`, `local`, `mock`
- `flow.frontends`: `yaml`, `slurm`

## Code Style

- Python 3.10+, strict mypy, 4-space indentation, ≤100 char lines
- `snake_case` for functions/modules, `CapWords` for classes, `UPPER_SNAKE` for constants
- Ruff for linting (E, W, F, I, N, UP, B, C4, SIM, BLE, TRY, C90, TID, RUF)
- Absolute imports enforced (no relative imports)
- Google-style docstrings
- K8s API client is hand-written in `k8s_api.py` under the mithril provider

## Test Organization

```
tests/
├── unit/          # Fast isolated tests
├── integration/   # Tests requiring mocked services
├── e2e/           # End-to-end with real infrastructure
├── cli/           # CLI-specific tests
├── fast/          # Quick sanity checks
└── slow/          # Long-running tests
```

Test markers: `@pytest.mark.unit`, `@pytest.mark.integration`, `@pytest.mark.e2e`, `@pytest.mark.slow`

## Key Domain Concepts

- **Bid**: A spot market request for GPU capacity with price constraints
- **Instance**: A provisioned GPU VM (can be multi-node)
- **Task**: A submitted workload with command, environment, mounts
- **Volume**: Persistent storage that can be attached to instances
- **Provider**: Backend compute source (Mithril is primary)

## Typing and Error Handling

**Fail closed, not silent.** Emit actionable errors and halt rather than cascading `if x is not None` fallbacks.

- Replace `Any` and gratuitous `Optional` with concrete types
- Honor existing type annotations—if a dependency is typed as required, assume the system supplies it; don't add defensive `None` checks unless the signature changes
- Aim for mypy `--strict` compatibility
- No catch-all exception handlers without explicit justification

**Before adding safeguards:**
- Read surrounding modules and recent review history
- Confirm referenced symbols/constants still exist; delete stale comments
- Keep diffs tidy: new helpers ship end-to-end or stay out entirely

## Design Principles

**10x not 10%.** Ship simple solutions for 90% of users while enabling power users. Avoid UX overcomplication.

**One obvious way.** Design APIs with explicit behavior, predictable types, and streaming-first ergonomics. No magic `__getattr__` tricks or surprise mutations.

**SOLID and DRY, but resist YAGNI.** Guard against leaky abstractions and scope creep. Solve the 80/20 case comprehensively; edit surgically.

**Clean up after yourself.** Conclude each task by simplifying touched code. Remove backward-compatibility shims promptly after migrations.

**Early returns over nesting.** Flatten logic with guard clauses. Extract complex conditionals into well-named boolean functions.

**Composition over inheritance.** Build behavior by combining simple pieces. Keep dependencies unidirectional.

**Comments explain "why", not "what".** If "what" needs explanation, refactor for clarity. Tests double as executable documentation.

## Git Workflow

### Commit Discipline

**Keep commits atomic and focused.** Each commit should do exactly one thing—a single logical change that can be reviewed, reverted, or cherry-picked independently.

- One commit per concern: don't mix refactoring with feature work, or formatting with logic changes
- If a commit message needs "and" to describe it, split it into multiple commits
- Commit messages should be imperative and specific: "Add wait_seconds parameter to resolve()" not "updates"
- Keep diffs minimal: avoid drive-by cleanups in unrelated code

### Graphite Stacks

Use Graphite (`gt`) for stacked PRs. Each stack should represent a logical progression of changes.

```bash
# Create a new branch in the stack
gt create -m "feat: add instance ordering to SSH resolver"

# Make changes, then amend or create next commit
gt modify  # amend current branch
gt create -m "feat: add wait_seconds polling logic"  # new branch in stack

# Submit stack for review
gt submit

# After review, land the stack
gt merge
```

**Stack organization:**
- Bottom of stack = foundational changes (types, interfaces)
- Middle = core implementation
- Top = integration, tests, cleanup

**Before submitting:** Run `uv run ruff check && uv run pytest` to ensure each commit in the stack passes CI independently.

**Important:** NEVER include Claude Code attribution, "Generated by Claude" messages, Co-Authored-By lines referencing Claude/AI, or any AI assistance mentions in commit messages, PR descriptions, or code comments. All contributions must appear as human-authored.
