"""Install Claude Code skills for flow-compute.

Copies bundled skill definitions and project guidance (CLAUDE.md) into the
current project directory so that Claude Code can use them.

Usage:
    flow claude          # Install skills + CLAUDE.md into current directory
    flow claude --list   # Show bundled skills without installing
"""

from __future__ import annotations

import shutil
from pathlib import Path

import click
from rich.console import Console

from flow.cli.commands.base import BaseCommand, console
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.theme_manager import theme_manager


def get_bundled_dir() -> Path:
    """Return the path to bundled Claude data shipped with the package."""
    from flow.data.claude import get_data_dir

    return get_data_dir()


def install_skills(target_dir: Path, bundled_dir: Path) -> list[str]:
    """Copy bundled skills into the target .claude/skills/ directory.

    Returns list of installed skill names.
    """
    skills_src = bundled_dir / "skills"
    skills_dst = target_dir / ".claude" / "skills"
    installed = []

    if not skills_src.exists():
        return installed

    for skill_dir in sorted(skills_src.iterdir()):
        if not skill_dir.is_dir():
            continue
        skill_file = skill_dir / "SKILL.md"
        if not skill_file.exists():
            continue

        dst_dir = skills_dst / skill_dir.name
        dst_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(skill_file, dst_dir / "SKILL.md")
        installed.append(skill_dir.name)

    return installed


def install_claude_md(target_dir: Path, bundled_dir: Path) -> str:
    """Copy bundled CLAUDE.md into the target directory.

    Returns:
        "created" if installed fresh, "unchanged" if already up to date,
        "backed_up" if existing was backed up and overwritten,
        "missing" if bundled source not found.
    """
    src = bundled_dir / "CLAUDE.md"
    if not src.exists():
        return "missing"

    dst = target_dir / "CLAUDE.md"
    if dst.exists():
        if dst.read_text() == src.read_text():
            return "unchanged"
        backup = target_dir / "CLAUDE.md.bak"
        shutil.copy2(dst, backup)
        shutil.copy2(src, dst)
        return "backed_up"

    shutil.copy2(src, dst)
    return "created"


def install_claude_assets(target_dir: Path, out: Console | None = None) -> None:
    """Install skills and CLAUDE.md, printing results to console.

    Shared entry point used by both `flow claude` and `flow setup --claude-code`.
    """
    out = out or console
    bundled_dir = get_bundled_dir()
    success_color = theme_manager.get_color("success")
    muted = theme_manager.get_color("muted")

    installed = install_skills(target_dir, bundled_dir)
    md_status = install_claude_md(target_dir, bundled_dir)

    if installed:
        out.print(
            f"\n[{success_color}]✓[/{success_color}] Installed {len(installed)} skills "
            f"into {target_dir / '.claude' / 'skills'}"
        )
        for name in installed:
            out.print(f"  [{muted}]{name}[/{muted}]")
    else:
        out.print("[warning]No skills found to install[/warning]")

    if md_status == "backed_up":
        out.print(
            f"[{success_color}]✓[/{success_color}] CLAUDE.md updated (previous version saved to CLAUDE.md.bak)"
        )
    elif md_status in ("created", "unchanged"):
        out.print(f"[{success_color}]✓[/{success_color}] CLAUDE.md installed")

    if installed or md_status != "missing":
        out.print(f"\n[{muted}]Skills are available as /skill-name in Claude Code[/{muted}]")


class ClaudeCommand(BaseCommand):
    """Install Claude Code skills for flow-compute."""

    @property
    def name(self) -> str:
        return "claude"

    @property
    def help(self) -> str:
        return "Install Claude Code skills and project guidance"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option(
            "--list", "list_only", is_flag=True, help="List bundled skills without installing"
        )
        @click.option(
            "--dir",
            "target",
            type=click.Path(exists=True, file_okay=False),
            default=".",
            help="Target project directory (default: current directory)",
        )
        @cli_error_guard(self)
        def claude(list_only: bool, target: str):
            """Install Claude Code skills and CLAUDE.md into your project.

            \b
            Examples:
                flow claude              # Install into current directory
                flow claude --list       # Show available skills
                flow claude --dir /path  # Install into specific directory
            """
            if list_only:
                bundled_dir = get_bundled_dir()
                muted = theme_manager.get_color("muted")
                skills_dir = bundled_dir / "skills"
                if not skills_dir.exists():
                    console.print("[warning]No bundled skills found[/warning]")
                    return

                console.print("\n[bold]Bundled Claude Code skills[/bold]\n")
                for skill_dir in sorted(skills_dir.iterdir()):
                    if not skill_dir.is_dir():
                        continue
                    skill_file = skill_dir / "SKILL.md"
                    if not skill_file.exists():
                        continue

                    # Parse description from YAML front matter
                    content = skill_file.read_text()
                    name = skill_dir.name
                    desc = ""
                    if content.startswith("---"):
                        end = content.find("---", 3)
                        front_matter = content[3:end] if end > 3 else content[3:]
                        for line in front_matter.split("\n"):
                            if line.startswith("description:"):
                                desc = line.split(":", 1)[1].strip()
                                break

                    console.print(f"  [accent]{name:<16}[/accent] [{muted}]{desc}[/{muted}]")

                console.print(f"\n[{muted}]Install with: flow claude[/{muted}]")
                return

            install_claude_assets(Path(target).resolve(), console)

        return claude


command = ClaudeCommand()
