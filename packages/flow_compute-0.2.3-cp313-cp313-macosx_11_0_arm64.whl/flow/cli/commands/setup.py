"""Setup command for Flow SDK configuration.

Supports both interactive wizard and direct configuration via flags.

Examples:
    Interactive setup:
        $ flow setup

    Direct configuration:
        $ flow setup --provider mithril --api-key fkey_xxx --project myproject

    Dry run to preview:
        $ flow setup --provider mithril --dry-run
"""

import logging
import os
import shutil
from pathlib import Path

import click
import yaml
from rich.markup import escape

from flow.cli.commands.base import BaseCommand
from flow.cli.utils.config_validator import ConfigValidator
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.lazy_imports import import_attr as _import_attr
from flow.cli.utils.theme_manager import theme_manager
from flow.core.cloud_detection import detect_all_clouds
from flow.core.setup_adapters import FieldType
from flow.sdk.helpers.masking import mask_api_key, mask_config_for_display
from flow.sdk.setup import get_adapter as _get_adapter
from flow.sdk.setup import list_providers as _list_providers
from flow.sdk.setup import register_providers as _register_providers

logger = logging.getLogger(__name__)

console = theme_manager.create_console()


def _load_existing_api_key() -> str | None:
    """Load existing API key from config if available."""
    ConfigLoader = _import_attr("flow.application.config.loader", "ConfigLoader", default=None)
    if ConfigLoader:
        loader = ConfigLoader()
        sources = loader.load_all_sources()
        existing_api_key = sources.api_key
        if existing_api_key and not existing_api_key.startswith("YOUR_"):
            return existing_api_key
    return None


def run_setup_wizard(provider: str | None = None, environment: str = "production") -> bool:
    """Run the setup wizard for the resolved provider.

    Args:
        provider: Provider name to use
        environment: Environment to configure (production or staging)
    """
    GenericSetupWizard = _import_attr("flow.core.setup_wizard", "GenericSetupWizard", default=None)

    _register_providers()

    resolved_provider = provider

    # Validate explicitly provided provider
    if resolved_provider:
        adapter = _get_adapter(resolved_provider)
        if not adapter:
            available_providers = _list_providers()
            if not available_providers:
                raise RuntimeError("Unexpected error: no providers available.")
            console.print(
                f"[error]Error:[/error] Unknown or unavailable provider: "
                f"{escape(str(resolved_provider))}"
            )
            console.print(f"\n[dim]Available providers:[/dim] {', '.join(available_providers)}")
            return False

    if not resolved_provider:
        try:
            ConfigLoader = _import_attr(
                "flow.application.config.loader", "ConfigLoader", default=None
            )
            loader = ConfigLoader() if ConfigLoader else None
            current = loader.load_all_sources()
            resolved_provider = current.provider or None
        except Exception:  # noqa: BLE001
            resolved_provider = None

    # If resolved provider is 'mock' but demo adapter is disabled, treat as unresolved
    if (resolved_provider or "").strip().lower() == "mock":
        demo_enabled = str(os.environ.get("FLOW_ENABLE_DEMO_ADAPTER", "")).strip().lower() in {
            "1",
            "true",
            "yes",
            "on",
        }
        if not demo_enabled:
            resolved_provider = None

    if not resolved_provider:
        # Present backend choice: Mithril vs Public Cloud
        from flow.core.setup_wizard.menu_selector import interactive_menu_select

        backend_options = [
            ("mithril", "Mithril (recommended)", "Managed multi-cloud GPU platform"),
            (
                "cloud",
                "Your cloud account (AWS, GCP, Azure)",
                "Use your own cloud credentials directly",
            ),
        ]
        backend = interactive_menu_select(
            backend_options,
            title="Select your compute backend",
            default_index=0,
            breadcrumbs=["Flow Setup"],
        )

        if backend == "cloud":
            return run_cloud_setup()

        if backend is None:
            return False

        resolved_provider = "mithril"

    # Set environment variables before creating the adapter
    original_api_url = os.environ.get("MITHRIL_API_URL")
    original_config_path = os.environ.get("FLOW_CONFIG_PATH")

    try:
        from flow.adapters.providers.builtin.mithril.core.constants import (
            MITHRIL_API_PRODUCTION_URL,
            MITHRIL_API_STAGING_URL,
        )

        if environment == "staging":
            os.environ["MITHRIL_API_URL"] = MITHRIL_API_STAGING_URL
            os.environ["FLOW_CONFIG_PATH"] = str(Path.home() / ".flow" / "config-staging.yaml")
        else:
            os.environ["MITHRIL_API_URL"] = MITHRIL_API_PRODUCTION_URL
            os.environ["FLOW_CONFIG_PATH"] = str(Path.home() / ".flow" / "config.yaml")

        adapter = _get_adapter(resolved_provider or "")

        if not adapter:
            console.print(f"[error]Error: Provider not available: {resolved_provider}[/error]")
            try:
                providers = _list_providers()
                if providers:
                    alt = providers[0]
                    alt_adapter = _get_adapter(alt)
                    if alt_adapter:
                        console.print(f"[warning]Hint:[/warning] Falling back to provider '{alt}'.")
                        adapter = alt_adapter
                    else:
                        return False
                else:
                    return False
            except Exception:  # noqa: BLE001
                return False

        if GenericSetupWizard is None:
            console.print("[error]Setup wizard is unavailable in this environment[/error]")
            return False

        wizard = GenericSetupWizard(console, adapter)
        success = wizard.run()

        if success:
            from flow.application.config.config import _set_current_environment

            _set_current_environment(environment)

        return success
    except KeyboardInterrupt:
        console.print("\n\n[warning]Setup cancelled[/warning]")
        return False
    except Exception as e:
        console.print(f"\n\n[error]Setup error:[/error] {escape(str(e))}")
        logger.exception("Setup wizard error")
        return False
    finally:
        if original_api_url is not None:
            os.environ["MITHRIL_API_URL"] = original_api_url
        else:
            os.environ.pop("MITHRIL_API_URL", None)

        if original_config_path is not None:
            os.environ["FLOW_CONFIG_PATH"] = original_config_path
        else:
            os.environ.pop("FLOW_CONFIG_PATH", None)


def run_cloud_setup() -> bool:
    """Run cloud backend setup: detect credentials, select clouds, write config.

    Returns:
        True if configuration was saved successfully, False otherwise.
    """
    from rich.prompt import Confirm

    from flow.application.config.writer import ConfigWriter
    from flow.cli.ui.components.models import SelectionItem
    from flow.cli.ui.components.selector_api import Selector
    from flow.sdk.models import ValidationResult

    success_color = theme_manager.get_color("success")
    error_color = "red"

    # Detect cloud credentials
    console.print("\n  Checking cloud credentials...\n")
    statuses = detect_all_clouds()

    # Display status table
    for status in statuses:
        if status.is_configured:
            indicator = f"[{success_color}]ok[/{success_color}]"
        else:
            indicator = f"[{error_color}]x[/{error_color}]"
        console.print(f"    {indicator}  {status.name:<8} {status.credential_source}")

    # Show setup instructions for unconfigured clouds
    unconfigured = [s for s in statuses if not s.is_configured]
    if unconfigured:
        console.print("")
        for status in unconfigured:
            console.print(f"  To set up {status.name}:")
            for i, (label, command) in enumerate(status.setup_instructions, 1):
                console.print(f"    {i}. {label}")
                console.print(f"       {command}")

    # Check if any clouds are configured
    configured = [s for s in statuses if s.is_configured]
    if not configured:
        console.print(
            "\n  No cloud credentials detected. Set up at least one cloud, "
            "then re-run: [accent]flow setup[/accent]\n"
        )
        return False

    console.print("")

    # Multi-select from configured clouds
    items = [
        SelectionItem(
            value=s.key,
            id=s.key,
            title=s.name,
            subtitle=s.credential_source,
            status="",
        )
        for s in configured
    ]

    selected_clouds = Selector.select_many(
        items=items,
        title="Which clouds do you want to enable?",
        console=console,
    )

    if not selected_clouds:
        console.print("\n  [warning]No clouds selected. Setup cancelled.[/warning]")
        return False

    # Spot instance preference
    use_spot = Confirm.ask(
        "\n  Use spot instances by default? (cheaper, can be interrupted)",
        default=True,
        console=console,
    )

    # Build and write config
    config = {
        "provider": "skypilot",
        "skypilot": {
            "clouds": sorted(selected_clouds),
            "defaults": {
                "use_spot": use_spot,
            },
        },
    }

    writer = ConfigWriter()
    writer.write(config, ValidationResult(is_valid=True))

    # Show completion summary
    cloud_names = [s.name for s in statuses if s.key in selected_clouds]
    console.print(
        f"\n  [{success_color}]Configuration saved to ~/.flow/config.yaml[/{success_color}]"
    )
    console.print(f"  Enabled clouds: {', '.join(cloud_names)}")

    console.print("\n  Next steps:")
    console.print("    Submit a job:   [accent]flow submit -i 1xa100 -- nvidia-smi[/accent]")
    console.print("    Check pricing:  [accent]flow pricing --gpu h100[/accent]")
    console.print("")

    _offer_claude_code_integration()

    return True


def _offer_claude_code_integration() -> None:
    """Offer to install Claude Code skills after setup.

    Checks if Claude Code CLI is available and prompts the user to install
    skills and CLAUDE.md into the current project.
    Skips silently in non-interactive contexts (CI, piped output).
    """
    import sys

    if not sys.stdout.isatty():
        return

    if not shutil.which("claude"):
        return

    # Check if skills are already installed in the current directory
    skills_dir = Path.cwd() / ".claude" / "skills"
    if skills_dir.exists() and any(skills_dir.iterdir()):
        return

    from rich.prompt import Confirm

    muted = theme_manager.get_color("muted")

    console.print("\n  [bold]Claude Code Integration[/bold]")
    console.print(f"  [{muted}]Flow includes GPU workflow skills for Claude Code:[/{muted}]")
    console.print(f"    [{muted}]/flow-run, /flow-debug, /flow-dashboard, /flow-setup[/{muted}]")

    install = Confirm.ask(
        "\n  Install Claude Code skills into this project?",
        default=True,
        console=console,
    )

    if not install:
        console.print(f"  [{muted}]Skip. Install later with: flow claude[/{muted}]")
        return

    try:
        from flow.cli.commands.claude import install_claude_assets

        install_claude_assets(Path.cwd(), console)
    except Exception as e:  # noqa: BLE001
        logger.debug("Could not install Claude skills: %s", e)
        console.print(f"  [warning]Could not install skills: {e}[/warning]")
        console.print(f"  [{muted}]Install manually with: flow claude[/{muted}]")


class SetupCommand(BaseCommand):
    """Setup command implementation."""

    def __init__(self):
        super().__init__()
        self.validator = ConfigValidator()

    @property
    def name(self) -> str:
        return "setup"

    @property
    def help(self) -> str:
        return "Configure credentials and provider settings"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option("--provider", envvar="FLOW_PROVIDER", help="Provider to use")
        @click.option(
            "--environment",
            type=click.Choice(["production", "staging"]),
            default="production",
            help="Environment to configure (production or staging)",
            hidden=True,
        )
        @click.option("--api-key", help="API key for authentication")
        @click.option("--project", help="Project name")
        @click.option("--api-url", help="API endpoint URL")
        @click.option("--dry-run", is_flag=True, help="Show configuration without saving")
        @click.option(
            "--output",
            type=click.Path(dir_okay=False),
            help="Write dry-run YAML to file (with --dry-run)",
        )
        @click.option("--verbose", "-v", is_flag=True, help="Show detailed setup information")
        @click.option("--reset", is_flag=True, help="Reset configuration to start fresh")
        @click.option("--show", is_flag=True, help="Print current resolved configuration and exit")
        @click.option("--yes", is_flag=True, help="Non-interactive; answer yes to prompts (CI)")
        @click.option(
            "--claude-code",
            is_flag=True,
            help="Install the Flow plugin for Claude Code (skips provider setup)",
        )
        @cli_error_guard(self)
        def setup(
            provider: str | None,
            environment: str,
            api_key: str | None,
            project: str | None,
            api_url: str | None,
            dry_run: bool,
            output: str | None,
            verbose: bool,
            reset: bool,
            show: bool,
            yes: bool,
            claude_code: bool,
        ):
            """Configure Flow.

            \b
            Examples:
                flow setup                              # Interactive setup wizard
                flow setup --dry-run                   # Preview configuration
                flow setup --show                      # Show current configuration
                flow setup --provider mithril --api-key xxx  # Direct setup
                flow setup --claude-code               # Install Claude Code plugin

            Use 'flow setup --verbose' for detailed configuration options.
            """
            if claude_code:
                from flow.cli.commands.claude import install_claude_assets

                install_claude_assets(Path.cwd(), console)
                return

            if verbose and not any([provider, api_key, project, api_url, dry_run]):
                self._print_verbose_help()
                return

            if show:
                self._show_config()
                return

            self._run_setup(
                provider,
                environment,
                api_key,
                project,
                api_url,
                dry_run,
                verbose,
                reset,
                output_path=output,
                assume_yes=yes,
            )

        return setup

    def _show_config(self):
        """Print current resolved configuration and exit."""
        try:
            import importlib

            ConfigManager = importlib.import_module("flow.application.config.manager").ConfigManager
            manager = ConfigManager()
            sources = manager.load_sources()
            from flow.application.config.config import _get_current_environment

            show_dict = {
                "environment": _get_current_environment(),
                "provider": sources.provider,
                "api_key": mask_api_key(sources.api_key),
                "mithril": sources.get_mithril_config(),
            }
            console.print(yaml.safe_dump(show_dict, default_flow_style=False))
        except Exception as e:  # noqa: BLE001
            console.print(f"[error]Error loading configuration:[/error] {escape(str(e))}")
            raise click.exceptions.Exit(1)

    def _print_verbose_help(self) -> None:
        """Print detailed, read-only help for `flow setup --verbose`."""
        from rich.panel import Panel as _Panel

        from flow.cli.utils.icons import flow_icon as _flow_icon

        bullet = "[muted]•[/muted]"
        border = theme_manager.get_color("table.border")

        console.print("")
        console.print(
            _Panel(
                f"[bold]{_flow_icon()} Flow — Detailed Guide[/bold]\n"
                "[muted]Setup configures your environment; it never provisions resources.[/muted]",
                border_style=border,
                expand=False,
            )
        )

        sections = [
            (
                "What This Configures",
                [
                    "Provider (backend)",
                    "API key (verified)",
                    "Default project",
                    "Default SSH key behavior",
                ],
            ),
            (
                "Where It's Saved",
                [
                    "[repr.path]~/.flow/config.yaml[/repr.path]  [muted]— user config[/muted]",
                    "[repr.path]./.flow/config.yaml[/repr.path]  [muted]— project override[/muted]",
                    "[repr.path]~/.flow/env.sh[/repr.path]  [muted]— optional env script (source it)[/muted]",
                ],
            ),
            (
                "SSH Keys",
                [
                    "Recommended: Generate on Mithril",
                    "Saves private key under [repr.path]~/.flow/keys/[/repr.path] with secure permissions",
                    "Private keys are never uploaded (only public keys are uploaded when needed)",
                    "Existing local keys: [repr.path]~/.ssh/[/repr.path] (id_ed25519, id_rsa, id_ecdsa)",
                ],
            ),
            (
                "Configuration & Environment",
                [
                    "Precedence: Environment > Config files > Interactive init",
                    "MITHRIL_API_KEY",
                    "MITHRIL_PROJECT",
                    "MITHRIL_SSH_KEYS  [muted]— comma-separated IDs or paths[/muted]",
                    "MITHRIL_SSH_KEY   [muted]— absolute private key path[/muted]",
                ],
            ),
            (
                "Useful Commands",
                [
                    "List known keys: [accent]flow ssh-key list[/accent]",
                    "Upload a local key: [accent]flow ssh-key upload ~/.ssh/id_ed25519.pub[/accent]",
                    "Inspect a key:      [accent]flow ssh-key info <sshkey_id>[/accent]",
                    "Health check:       [accent]flow health[/accent]",
                ],
            ),
        ]

        for title, items in sections:
            console.print("")
            body = "\n".join(f"  {bullet} {item}" for item in items)
            console.print(
                _Panel(
                    body,
                    title=f"[accent][bold]{title}[/bold][/accent]",
                    border_style=border,
                    expand=False,
                )
            )

        console.print("")
        self.show_next_actions(
            [
                "flow health",
                "flow example gpu-test    # GPU check starter",
                "flow status",
            ]
        )

    def _run_setup(
        self,
        provider: str | None,
        environment: str,
        api_key: str | None,
        project: str | None,
        api_url: str | None,
        dry_run: bool,
        verbose: bool = False,
        reset: bool = False,
        output_path: str | None = None,
        assume_yes: bool = False,
    ):
        """Execute setup command."""
        if reset:
            if self._reset_configuration(assume_yes=assume_yes):
                success_color = theme_manager.get_color("success")
                console.print(
                    f"[{success_color}]✓[/{success_color}] Configuration reset successfully"
                )
                if not (provider or api_key or project or api_url):
                    if assume_yes:
                        return
                    console.print("\nStarting fresh setup...\n")
            else:
                return

        explicit_non_interactive = bool(api_key or project or api_url or dry_run)

        if explicit_non_interactive:
            success = self._configure_with_options(
                provider, environment, api_key, project, api_url, dry_run, output_path
            )
        else:
            if assume_yes:
                console.print(
                    "[error]Error:[/error] --yes requires non-interactive options. "
                    "Provide --provider and related flags."
                )
                raise click.exceptions.Exit(1)
            success = run_setup_wizard(provider, environment)
            if success:
                self.show_next_actions(
                    [
                        "Run the GPU check starter: [accent]flow example gpu-test[/accent]",
                        "Create an instance: [accent]flow instance create -i b200 -N 8[/accent]",
                        "Monitor instances: [accent]flow instance list[/accent]",
                        "Generate a config: [accent]flow init -o task.yaml[/accent]",
                    ],
                    max_items=4,
                )

        if success:
            _offer_claude_code_integration()

        if not success:
            raise click.exceptions.Exit(1)

    def _configure_with_options(
        self,
        provider: str | None,
        environment: str,
        api_key: str | None,
        project: str | None,
        api_url: str | None,
        dry_run: bool,
        output_path: str | None,
    ) -> bool:
        """Configure using command-line options."""
        from flow.adapters.providers.builtin.mithril.core.constants import (
            MITHRIL_API_PRODUCTION_URL,
            MITHRIL_API_STAGING_URL,
        )

        _register_providers()

        if not provider:
            adapters = _list_providers() or ["mithril"]
            if len(adapters) == 1:
                provider = adapters[0]
            elif "mithril" in adapters:
                provider = "mithril"
            else:
                console.print(
                    "[error]Error:[/error] Provider must be specified with "
                    "--provider in non-interactive mode"
                )
                return False

        adapter = _get_adapter(provider)
        if not adapter:
            console.print(
                f"[error]Error:[/error] Unknown or unavailable provider: {escape(str(provider))}"
            )
            return False

        # Check required fields early in non-interactive mode
        if not dry_run:
            fields = adapter.get_configuration_fields()
            required_fields = [
                f.name for f in fields if f.required and f.field_type != FieldType.LINK
            ]
            provided_fields = {"provider"}
            if api_key:
                provided_fields.add("api_key")
            if project:
                provided_fields.add("project")
            if api_url:
                provided_fields.add("api_url")

            missing = [name for name in required_fields if name not in provided_fields]
            if missing:
                console.print(
                    f"[error]Missing required fields for non-interactive setup:[/error] "
                    f"{', '.join(missing)}"
                )
                console.print(
                    "\n[dim]Hint:[/dim] Provide all required fields or run "
                    "[accent]flow setup[/accent] interactively"
                )
                return False

        config: dict = {"provider": provider}

        # Validate all fields first
        if not dry_run:
            validation_context: dict[str, str] = {}

            if api_key:
                vr = adapter.validate_field("api_key", api_key)
                if not vr.is_valid:
                    console.print(f"[error]Invalid API key:[/error] {escape(str(vr.message))}")
                    return False
                validation_context["api_key"] = api_key

            if project:
                if not validation_context.get("api_key"):
                    existing_api_key = _load_existing_api_key()
                    if existing_api_key:
                        vr = adapter.validate_field("api_key", existing_api_key)
                        if not vr.is_valid:
                            console.print(
                                f"[error]Existing API key is invalid:[/error] "
                                f"{escape(str(vr.message))}"
                            )
                            return False
                        validation_context["api_key"] = existing_api_key

                if not validation_context.get("api_key"):
                    console.print(
                        "[error]Cannot validate project:[/error] API key is required. "
                        "Provide --api-key or run 'flow setup' to configure first."
                    )
                    return False

                vr = adapter.validate_field("project", project, validation_context)
                if not vr.is_valid:
                    console.print(f"[error]Invalid project:[/error] {escape(str(vr.message))}")
                    return False

            # Show success messages
            success_color = theme_manager.get_color("success")
            if api_key:
                console.print(
                    f"[{success_color}]✓[/{success_color}] API key validated: "
                    f"{mask_api_key(api_key)}"
                )
            if project:
                console.print(f"[{success_color}]✓[/{success_color}] Project: {project}")

            if provider == "mithril" and api_key:
                console.print(
                    "\n[dim]Note:[/dim] Running tasks provisions real infrastructure "
                    "and may incur costs."
                )

        # Build final config
        if api_key:
            config["api_key"] = api_key
        if project:
            config["project"] = project

        if api_url:
            config["api_url"] = api_url
        elif environment == "staging":
            config["api_url"] = MITHRIL_API_STAGING_URL
        else:
            config["api_url"] = MITHRIL_API_PRODUCTION_URL

        # Set environment-specific config path temporarily for saving
        original_config_path = os.environ.get("FLOW_CONFIG_PATH")
        try:
            if environment == "staging":
                os.environ["FLOW_CONFIG_PATH"] = str(Path.home() / ".flow" / "config-staging.yaml")
            else:
                os.environ["FLOW_CONFIG_PATH"] = str(Path.home() / ".flow" / "config.yaml")

            if dry_run:
                console.print("\n[bold]Configuration (dry run)[/bold]")
                console.print("─" * 50)
                display_config = mask_config_for_display(config, adapter.get_configuration_fields())
                console.print(yaml.safe_dump(display_config, default_flow_style=False))
                if output_path:
                    try:
                        with open(output_path, "w") as f:
                            yaml.safe_dump(display_config, f, default_flow_style=False)
                        success_color = theme_manager.get_color("success")
                        console.print(
                            f"\n[{success_color}]✓[/{success_color}] "
                            f"Wrote masked preview to {output_path}"
                        )
                    except Exception as e:  # noqa: BLE001
                        console.print(f"[error]Error writing output file:[/error] {escape(str(e))}")
                        return False
                return True

            saved = adapter.save_configuration(config)
            if not saved:
                console.print("[error]Failed to save configuration[/error]")
                return False

            from flow.application.config.config import _set_current_environment

            _set_current_environment(environment)

            success_color = theme_manager.get_color("success")
            config_file = "config-staging.yaml" if environment == "staging" else "config.yaml"
            console.print(
                f"\n[{success_color}]✓[/{success_color}] Configuration saved to "
                f"~/.flow/{config_file}"
            )
            if environment == "staging":
                console.print(f"[{success_color}]✓[/{success_color}] Environment set to staging")
            self.show_next_actions(
                [
                    "Test your setup: [accent]flow health[/accent]",
                    "Run GPU test: [accent]flow example gpu-test[/accent]",
                    "View examples: [accent]flow example[/accent]",
                    "Submit your first task: [accent]flow submit <config.yaml>[/accent]",
                ]
            )
            return True
        finally:
            if original_config_path is not None:
                os.environ["FLOW_CONFIG_PATH"] = original_config_path
            else:
                os.environ.pop("FLOW_CONFIG_PATH", None)

    def _reset_configuration(self, *, assume_yes: bool = False) -> bool:
        """Reset Flow configuration to initial state."""
        from rich.prompt import Confirm

        flow_dir = Path.home() / ".flow"
        files_to_clear = []

        if flow_dir.exists():
            for config_name in ("config.yaml", "config-staging.yaml"):
                config_file = flow_dir / config_name
                if config_file.exists():
                    files_to_clear.append(config_file)
            for cred_file in flow_dir.glob("credentials.*"):
                files_to_clear.append(cred_file)

        if not files_to_clear:
            console.print("[warning]No configuration files found to reset[/warning]")
            return True

        console.print("\n[bold]The following files will be removed:[/bold]")
        for file in files_to_clear:
            console.print(f"  • {file}")

        console.print("")
        confirm = assume_yes or Confirm.ask(
            "[warning]Are you sure you want to reset configuration?[/warning]"
        )

        if not confirm:
            console.print("[dim]Reset cancelled[/dim]")
            return False

        for file in files_to_clear:
            try:
                file.unlink()
            except Exception as e:  # noqa: BLE001
                console.print(f"[error]Error deleting {file}: {escape(str(e))}[/error]")
                return False

        return True


# Export command instance
command = SetupCommand()
