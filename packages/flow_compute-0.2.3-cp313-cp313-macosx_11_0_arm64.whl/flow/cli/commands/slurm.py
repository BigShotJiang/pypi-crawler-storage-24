"""Slurm subcommands for reservations.

Implements `flow slurm` to submit, list, cancel jobs, and print SSH info for
Slurm-enabled reservations via slurmrestd. Docstrings follow Google style.
"""

from __future__ import annotations

import json
import os
import tempfile
from typing import Any

import click

import flow.sdk.factory as sdk_factory
from flow.cli.commands.base import BaseCommand, console
from flow.cli.commands.input_types import EnvItem
from flow.cli.commands.utils import env_items_to_dict
from flow.cli.utils.error_handling import cli_error_guard

_DEFAULT_SLURMRESTD_API_VERSION = "v0.0.41"


def _slurmrestd_request(
    slurm: dict[str, Any],
    method: str,
    path: str,
    *,
    insecure: bool,
    ca_cert: str | None,
    api_version: str | None,
    json_body: dict[str, Any] | None = None,
    params: dict[str, Any] | None = None,
) -> Any | None:
    """Send a request to slurmrestd, handling TLS and errors.

    Args:
        slurm: Slurm metadata from reservation (must contain restd_url).
        method: HTTP method (GET, POST, DELETE).
        path: URL path (e.g., "/slurm/{version}/job/submit").
        insecure: Disable TLS verification.
        ca_cert: Path to CA certificate PEM file.
        api_version: slurmrestd API version override.
        json_body: Optional JSON request body.
        params: Optional query parameters.

    Returns:
        Response data from slurmrestd.

    Raises:
        click.ClickException: On TLS, connection, timeout, or other errors.
    """
    from flow.sdk.http import HttpClient as _Http

    restd_url = slurm.get("restd_url", "")
    ca_pem = slurm.get("ca_pem")

    # Resolve TLS verification: --insecure > --ca-cert > env > metadata > True
    ca_cert = ca_cert or os.getenv("FLOW_SLURM_CA_CERT")
    insecure = insecure or (os.getenv("FLOW_SLURM_INSECURE", "").strip() in {"1", "true", "yes"})
    api_version = api_version or os.getenv(
        "FLOW_SLURM_API_VERSION", _DEFAULT_SLURMRESTD_API_VERSION
    )

    verify_param: object = True
    caf_path: str | None = None
    try:
        if insecure:
            verify_param = False
        elif ca_cert:
            verify_param = ca_cert
        elif ca_pem:
            with tempfile.NamedTemporaryFile("w", delete=False) as caf:
                caf.write(ca_pem)
                caf.flush()
                caf_path = caf.name
                verify_param = caf_path

        http = _Http(base_url=restd_url.rstrip("/"), verify=verify_param)
        full_path = path.format(api_version=api_version)
        kwargs: dict[str, Any] = {"timeout_seconds": 30}
        if json_body is not None:
            kwargs["json"] = json_body
        if params is not None:
            kwargs["params"] = params
        return http.request(method, full_path, **kwargs)
    except Exception as e:
        msg = str(e)
        if "SSL" in msg or "certificate" in msg or "tls" in msg.lower():
            raise click.ClickException(
                f"TLS verification failed contacting slurmrestd at {restd_url}. "
                f"Hint: pass --ca-cert <pem> or --insecure. Error: {e}"
            ) from e
        if "connect" in msg.lower() or "connection" in msg.lower():
            raise click.ClickException(
                f"Failed to connect to slurmrestd at {restd_url}. "
                f"Ensure the reservation is active and Slurm is provisioned. Error: {e}"
            ) from e
        if "timeout" in msg.lower():
            raise click.ClickException(
                f"Timeout contacting slurmrestd at {restd_url}. "
                f"Try again or check network. Error: {e}"
            ) from e
        raise click.ClickException(f"slurmrestd error: {msg}") from e
    finally:
        if caf_path:
            try:
                os.unlink(caf_path)
            except Exception:  # noqa: BLE001
                pass


class SlurmCommand(BaseCommand):
    """Interact with Slurm clusters attached to reservations."""

    @property
    def name(self) -> str:
        return "slurm"

    @property
    def help(self) -> str:
        return "Interact with Slurm on reservations (submit/status/cancel/ssh)"

    def get_command(self) -> click.Command:
        @click.group(name=self.name, help=self.help)
        @cli_error_guard(self)
        def grp() -> None:
            pass

        def _get_slurm_meta(reservation_id: str) -> dict[str, Any]:
            flow = sdk_factory.create_client(auto_init=True)
            res = flow.get_reservation(reservation_id)
            meta = getattr(res, "provider_metadata", {}) or {}
            slurm = meta.get("slurm") or {}
            if not slurm:
                self.handle_error(
                    "Reservation is not Slurm-enabled. Recreate with --with-slurm or contact support."
                )
                raise click.Abort()
            return slurm

        def _require_restd_url(slurm: dict[str, Any]) -> str:
            restd_url = slurm.get("restd_url")
            if not restd_url:
                self.handle_error("Slurm REST endpoint is not available for this reservation")
                raise click.Abort()
            return restd_url

        @grp.command(name="submit", help="Submit a SLURM script to a reservation's Slurm cluster")
        @click.argument("reservation_id")
        @click.argument("script_path")
        @click.option(
            "--env",
            "env_items",
            type=EnvItem(),
            multiple=True,
            help="Env variables KEY=VALUE (repeatable)",
        )
        @click.option("--account", default=None)
        @click.option("--partition", default=None)
        @click.option("--array", default=None)
        @click.option("--name", default=None)
        @click.option(
            "--insecure",
            is_flag=True,
            default=False,
            help="Do not verify TLS certificate for slurmrestd (or set FLOW_SLURM_INSECURE=1)",
        )
        @click.option(
            "--ca-cert",
            type=click.Path(exists=True, dir_okay=False, readable=True, path_type=str),
            default=None,
            help="Path to CA certificate PEM for slurmrestd (or set FLOW_SLURM_CA_CERT)",
        )
        @click.option(
            "--api-version",
            type=str,
            default=None,
            help="slurmrestd API version (e.g., v0.0.41); overrides FLOW_SLURM_API_VERSION",
        )
        def submit_cmd(
            reservation_id: str,
            script_path: str,
            env_items: tuple[tuple[str, str], ...],
            account: str | None,
            partition: str | None,
            array: str | None,
            name: str | None,
            insecure: bool,
            ca_cert: str | None,
            api_version: str | None,
        ) -> None:
            try:
                slurm = _get_slurm_meta(reservation_id)
            except click.Abort:
                return
            _require_restd_url(slurm)

            try:
                with open(script_path, encoding="utf-8") as f:
                    content = f.read()
            except Exception as e:  # noqa: BLE001
                self.handle_error(e)
                return

            env_dict: dict[str, Any] = env_items_to_dict(env_items)
            payload: dict[str, Any] = {
                "script": content,
                "environment": env_dict,
            }
            if account:
                payload["account"] = account
            if partition:
                payload["partition"] = partition
            if array:
                payload["array"] = array
            if name:
                payload["name"] = name

            try:
                data = _slurmrestd_request(
                    slurm,
                    "POST",
                    "/slurm/{api_version}/job/submit",
                    insecure=insecure,
                    ca_cert=ca_cert,
                    api_version=api_version,
                    json_body=payload,
                )
            except click.ClickException as e:
                self.handle_error(e.format_message())
                return
            console.print(json.dumps(data))

        @grp.command(name="status", help="List jobs for a Slurm-enabled reservation")
        @click.argument("reservation_id")
        @click.option("--user", default=None)
        @click.option("--state", default=None)
        @click.option(
            "--insecure",
            is_flag=True,
            default=False,
            help="Do not verify TLS certificate for slurmrestd (or set FLOW_SLURM_INSECURE=1)",
        )
        @click.option(
            "--ca-cert",
            type=click.Path(exists=True, dir_okay=False, readable=True, path_type=str),
            default=None,
            help="Path to CA certificate PEM for slurmrestd (or set FLOW_SLURM_CA_CERT)",
        )
        @click.option(
            "--api-version",
            type=str,
            default=None,
            help="slurmrestd API version (e.g., v0.0.41); overrides FLOW_SLURM_API_VERSION",
        )
        def status_cmd(
            reservation_id: str,
            user: str | None,
            state: str | None,
            insecure: bool,
            ca_cert: str | None,
            api_version: str | None,
        ) -> None:
            try:
                slurm = _get_slurm_meta(reservation_id)
            except click.Abort:
                return
            _require_restd_url(slurm)

            params: dict[str, Any] = {}
            if user:
                params["user_name"] = user
            if state:
                params["job_state"] = state

            try:
                data = _slurmrestd_request(
                    slurm,
                    "GET",
                    "/slurm/{api_version}/jobs",
                    insecure=insecure,
                    ca_cert=ca_cert,
                    api_version=api_version,
                    params=params,
                )
            except click.ClickException as e:
                self.handle_error(e.format_message())
                return
            console.print(json.dumps(data))

        @grp.command(name="cancel", help="Cancel a Slurm job")
        @click.argument("reservation_id")
        @click.argument("job_id")
        @click.option(
            "--insecure",
            is_flag=True,
            default=False,
            help="Do not verify TLS certificate for slurmrestd (or set FLOW_SLURM_INSECURE=1)",
        )
        @click.option(
            "--ca-cert",
            type=click.Path(exists=True, dir_okay=False, readable=True, path_type=str),
            default=None,
            help="Path to CA certificate PEM for slurmrestd (or set FLOW_SLURM_CA_CERT)",
        )
        @click.option(
            "--api-version",
            type=str,
            default=None,
            help="slurmrestd API version (e.g., v0.0.41); overrides FLOW_SLURM_API_VERSION",
        )
        def cancel_cmd(
            reservation_id: str,
            job_id: str,
            insecure: bool,
            ca_cert: str | None,
            api_version: str | None,
        ) -> None:
            try:
                slurm = _get_slurm_meta(reservation_id)
            except click.Abort:
                return
            _require_restd_url(slurm)

            try:
                _slurmrestd_request(
                    slurm,
                    "DELETE",
                    f"/slurm/{{api_version}}/job/{job_id}",
                    insecure=insecure,
                    ca_cert=ca_cert,
                    api_version=api_version,
                )
            except click.ClickException as e:
                self.handle_error(e.format_message())
                return
            console.print(f"Cancelled job {job_id}")

        @grp.command(name="ssh", help="Print an SSH command to the reservation's login node")
        @click.argument("reservation_id")
        def ssh_cmd(reservation_id: str) -> None:
            try:
                slurm = _get_slurm_meta(reservation_id)
            except click.Abort:
                return
            host = slurm.get("login_host")
            if not host:
                self.handle_error("No login_host available on this reservation")
                return
            console.print(f"ssh {host}")

        return grp


command = SlurmCommand()
