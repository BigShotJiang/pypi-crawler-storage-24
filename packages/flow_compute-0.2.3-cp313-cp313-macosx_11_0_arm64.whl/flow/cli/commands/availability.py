"""GPU availability command.

Shows current GPU availability across regions, grouped by GPU type and region.
Designed for quick capacity checks: "what's available right now?"
"""

import json
from typing import Any

import click

from flow.cli.commands.base import BaseCommand, console
from flow.cli.ui.presentation.table_styles import create_flow_table, wrap_table_in_panel
from flow.cli.utils.error_handling import cli_error_guard, render_auth_required_message
from flow.cli.utils.theme_manager import theme_manager
from flow.domain.parsers.instance_parser import extract_gpu_info
from flow.errors import AuthenticationError


class AvailabilityCommand(BaseCommand):
    """Show current GPU availability across regions."""

    @property
    def name(self) -> str:
        return "availability"

    @property
    def help(self) -> str:
        return "Show current GPU availability across regions"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option("--gpu", help="Filter by GPU type (e.g., b200, h100)")
        @click.option("--region", help="Filter by region (e.g., us-central5-a)")
        @click.option("--json", "as_json", is_flag=True, help="Output as JSON")
        @cli_error_guard(self)
        def availability(
            gpu: str | None = None,
            region: str | None = None,
            as_json: bool = False,
        ):
            self._execute(gpu=gpu, region=region, as_json=as_json)

        return availability

    def _execute(
        self,
        *,
        gpu: str | None,
        region: str | None,
        as_json: bool,
    ) -> None:
        # Fetch instances via SDK
        import flow.sdk.factory as sdk_factory

        try:
            client = sdk_factory.create_client(auto_init=True)
        except AuthenticationError:
            render_auth_required_message(console, output_json=as_json)
            return

        req: dict[str, Any] = {}
        if region:
            req["region"] = region
        instances = client.find_instances(req, limit=100)

        if not instances:
            if as_json:
                click.echo(json.dumps({"availability": []}, indent=2))
            else:
                console.print("[dim]No instances found.[/dim]")
            return

        # Build raw rows from SDK response
        raw_rows: list[dict[str, Any]] = []
        for inst in instances:
            gpu_type = (inst.gpu_type or "") or extract_gpu_info(inst.instance_type)[0]
            raw_rows.append(
                {
                    "region": inst.region,
                    "gpu_type": gpu_type,
                    "gpu_count": inst.gpu_count,
                    "price_per_hour": inst.price_per_hour,
                    "instance_type": inst.instance_type,
                    "available_quantity": inst.available_quantity,
                }
            )

        # Apply GPU filter
        gpu_filter = (gpu or "").lower().strip()
        if gpu_filter:
            raw_rows = [r for r in raw_rows if (r.get("gpu_type") or "").lower() == gpu_filter]

        if not raw_rows:
            if as_json:
                click.echo(json.dumps({"availability": []}, indent=2))
            else:
                console.print("[dim]No matching instances found.[/dim]")
            return

        # JSON output: return raw listings
        if as_json:
            click.echo(json.dumps({"availability": raw_rows}, indent=2))
            return

        # Aggregate by (gpu_type, region).
        # available_quantity is instance count; multiply by gpu_count for chip count.
        # Sizes within the same (gpu_type, region) share the same physical GPU pool,
        # so we take the max (not sum) of chip counts across sizes.
        groups: dict[tuple[str, str], dict[str, Any]] = {}
        for r in raw_rows:
            key = (r.get("gpu_type", ""), r.get("region", ""))
            if key not in groups:
                groups[key] = {
                    "sizes": set(),
                    "total_gpus": 0,
                    "min_price_per_gpu": float("inf"),
                }
            g = groups[key]
            gc = r.get("gpu_count")
            if isinstance(gc, int) and gc > 0:
                g["sizes"].add(gc)
            avail = r.get("available_quantity") or 0
            gpu_count = r.get("gpu_count") or 1
            available_gpus = avail * gpu_count
            g["total_gpus"] = max(g["total_gpus"], available_gpus)
            # API price is per-instance; normalize to per-GPU for consistent display.
            price = r.get("price_per_hour")
            if isinstance(price, int | float) and price > 0:
                price_per_gpu = price / gpu_count
                g["min_price_per_gpu"] = min(g["min_price_per_gpu"], price_per_gpu)

        # Sort: by gpu_type, then by min price per GPU within gpu_type
        sorted_keys = sorted(
            groups.keys(),
            key=lambda k: (k[0], groups[k]["min_price_per_gpu"]),
        )

        # Render table
        try:
            accent = theme_manager.get_color("accent")
            console.print(f"\n[bold {accent}]Availability[/bold {accent}]")
        except Exception:  # noqa: BLE001
            pass

        table = create_flow_table(title=None, show_borders=True, padding=1, expand=False)
        table.add_column("GPU", style=theme_manager.get_color("accent"), no_wrap=True)
        table.add_column("Region", no_wrap=True)
        table.add_column("GPU Configs", no_wrap=True)
        table.add_column("Price/GPU", justify="right", no_wrap=True)
        table.add_column("Available", justify="right")

        for gpu_type, rgn in sorted_keys:
            g = groups[(gpu_type, rgn)]
            sizes = sorted(g["sizes"])
            sizes_str = ", ".join(f"{s}x" for s in sizes) if sizes else "-"
            price = g["min_price_per_gpu"]
            price_str = f"${price:.2f}/hr" if price < float("inf") else "-"
            avail_str = str(g["total_gpus"])
            table.add_row(gpu_type, rgn, sizes_str, price_str, avail_str)

        title_parts = ["GPU Availability"]
        if gpu_filter:
            title_parts.append(gpu_filter.upper())
        if region:
            title_parts.append(region)
        wrap_table_in_panel(table, " - ".join(title_parts), console)


command = AvailabilityCommand()
