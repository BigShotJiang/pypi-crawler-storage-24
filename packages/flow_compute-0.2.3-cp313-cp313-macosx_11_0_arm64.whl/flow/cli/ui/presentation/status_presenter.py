"""Status presenter (core default UI).

Coordinates fetching, formatting, table rendering, header summary, tip bar,
and index cache saving for the default status UI.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path

try:
    from rich.console import Console
except Exception:  # pragma: no cover  # noqa: BLE001

    class Console:  # type: ignore
        pass


import flow.sdk.factory as sdk_factory
from flow.cli.constants import DEFAULT_STATUS_LIMIT
from flow.cli.ui.presentation.next_steps import (
    build_status_recommendations,
    render_next_steps_panel,
)
from flow.cli.ui.presentation.nomenclature import get_entity_labels
from flow.cli.ui.presentation.status_table_renderer import StatusTableRenderer
from flow.cli.ui.runtime.owner_resolver import Me, OwnerResolver
from flow.cli.utils.icons import prefix_with_flow_icon
from flow.cli.utils.task_fetcher import TaskFetcher
from flow.cli.utils.task_index_cache import TaskIndexCache
from flow.cli.utils.theme_manager import theme_manager
from flow.sdk.client import Flow
from flow.sdk.models import Task

logger = logging.getLogger(__name__)


@dataclass
class StatusDisplayOptions:
    show_all: bool = False
    limit: int = DEFAULT_STATUS_LIMIT
    group_by_origin: bool = True
    # When set, indicates the list is filtered by a specific status (e.g., "completed")
    status_filter: str | None = None


class StatusPresenter:
    def __init__(self, console: Console | None = None, flow_client: Flow | None = None) -> None:
        self.console = console or theme_manager.create_console()
        # Prefer factory to construct the client in CLI layer; kept patchable
        self.flow = flow_client or sdk_factory.create_client(auto_init=True)
        self.fetcher = TaskFetcher(self.flow)
        self.table = StatusTableRenderer(self.console)
        self.owner_resolver = OwnerResolver(self.flow)

    def _dbg(self, msg: str) -> None:
        if os.environ.get("FLOW_STATUS_DEBUG"):
            logger.info(msg)

    def present(
        self,
        options: StatusDisplayOptions,
        tasks: list[Task] | None = None,
        *,
        me: Me | None = None,
        owner_map: dict[str, str] | None = None,
        fast: bool = False,
    ) -> None:
        self._dbg(
            f"present: show_all={options.show_all} status={options.status_filter} limit={options.limit}"
        )

        tasks = tasks if tasks is not None else self._fetch_tasks(options)
        if not tasks:
            try:
                self.console.print(f"[dim]No {get_entity_labels().empty_plural} found[/dim]")
            except Exception:  # noqa: BLE001
                self.console.print("[dim]No tasks found[/dim]")
            return

        # Use provided identity context when available to avoid extra network calls
        me = me if me is not None else self.owner_resolver.get_me()
        owner_map = owner_map if owner_map is not None else self.owner_resolver.get_teammates_map()

        tasks_for_display, showing_active_only = self._apply_filters(tasks, options)
        if not fast:
            self._enrich_tasks(tasks_for_display)
        self._print_summary_line(tasks_for_display)
        displayed_tasks = self._render_tables(tasks_for_display, options, me, owner_map, fast)
        self._print_context_note(displayed_tasks, options, showing_active_only)

        if not displayed_tasks:
            return

        self._save_index_cache(displayed_tasks)
        self._render_hints(displayed_tasks, options)

    # -- Fetch --

    def _fetch_tasks(self, options: StatusDisplayOptions) -> list[Task]:
        """Fetch tasks via the centralized TaskFetcher.

        Delegates to fetch_for_display which queries all active statuses
        (RUNNING, PENDING, PROVISIONING, PREEMPTING) plus recently-failed
        tasks (last 2h), with appropriate fallbacks.
        """
        tasks = self.fetcher.fetch_for_display(
            show_all=options.show_all,
            status_filter=options.status_filter,
            limit=options.limit,
        )
        self._dbg(f"fetch: count={len(tasks) if tasks else 0}")
        return tasks or []

    # -- Filter --

    def _apply_filters(
        self, tasks: list[Task], options: StatusDisplayOptions
    ) -> tuple[list[Task], bool]:
        """Apply time-window, active-only, and status filters.

        Returns (filtered_tasks, showing_active_only).
        """
        from flow.sdk.models import TaskStatus as _TS

        result = list(tasks)
        showing_active_only = False

        # 24h time-window filter (skip when show_all or status_filter)
        if not options.show_all and not options.status_filter:
            try:
                from flow.cli.utils.task_filter import TaskFilter as _TF

                result = _TF.filter_by_time_window(result, hours=24, include_active=True)
            except Exception:  # noqa: BLE001
                result = list(tasks)

            # Prune to active + recently-failed if any active tasks exist.
            # Excludes cancelled/completed from the default view while
            # preserving provisioning, preempting, and recent failures.
            _active = set(_TS.active_statuses())
            _default_view = _active | {_TS.FAILED}
            has_active = any(getattr(t, "status", None) in _active for t in result)
            if has_active:
                result = [t for t in result if getattr(t, "status", None) in _default_view]
                showing_active_only = True
            elif result:
                noun = get_entity_labels().empty_plural
                self.console.print(
                    f"[dim]No active {noun} — showing recent (last 24h). Use --all for full history.[/dim]\n"
                )

        # Client-side status filter (covers provider gaps like 'preempting')
        if options.status_filter:
            try:
                from flow.cli.utils.task_filter import TaskFilter as _TF

                if options.status_filter in ("open", "starting"):
                    from flow.cli.ui.formatters.shared_task import TaskFormatter

                    result = [
                        t
                        for t in result
                        if TaskFormatter.get_display_status(t) == options.status_filter
                    ]
                else:
                    result = _TF.filter_by_status(result, _TS(options.status_filter))
            except (ValueError, KeyError):
                pass

        return result, showing_active_only

    # -- Enrich --

    def _enrich_tasks(self, tasks: list[Task]) -> None:
        """Best-effort SSH probing and ground-truth refresh for starting tasks."""
        self._probe_ssh_readiness(tasks)
        self._refresh_starting_tasks(tasks)

    def _probe_ssh_readiness(self, tasks: list[Task]) -> None:
        """Annotate RUNNING tasks with SSH readiness hints (opt-in via env)."""
        enable_val = (os.environ.get("FLOW_STATUS_SSH_PROBE") or "").strip().lower()
        if enable_val not in {"1", "true", "yes", "on"}:
            return

        try:
            from flow.core.ssh import is_endpoint_responsive, is_ssh_ready
            from flow.sdk.models import TaskStatus as _TS

            probed = 0
            for t in tasks:
                if probed >= 12:
                    break
                if getattr(t, "status", None) != _TS.RUNNING:
                    continue
                host = getattr(t, "ssh_host", None)
                if not host:
                    continue
                port = int(getattr(t, "ssh_port", 22) or 22)
                meta = getattr(t, "provider_metadata", {}) or {}
                if "ssh_ready_hint" in meta:
                    continue

                ok: bool | None = None
                try:
                    key_path = self.flow.get_task_ssh_connection_info(getattr(t, "task_id", ""))
                    if isinstance(key_path, Path):
                        ok = is_ssh_ready(
                            user=getattr(t, "ssh_user", "ubuntu"),
                            host=str(host),
                            port=port,
                            key_path=Path(key_path),
                        )
                except Exception:  # noqa: BLE001
                    ok = None
                if ok is None:
                    ok = is_endpoint_responsive(str(host), port)
                try:
                    meta["ssh_ready_hint"] = bool(ok)
                    t.provider_metadata = meta
                except Exception:  # noqa: BLE001
                    pass
                probed += 1
        except Exception:  # noqa: BLE001
            pass

    def _refresh_starting_tasks(self, tasks: list[Task]) -> None:
        """Refresh a few RUNNING tasks without ssh_host (starting state)."""
        try:
            from flow.cli.ui.presentation.task_formatter import TaskFormatter as _TF
            from flow.sdk.models import TaskStatus as _TS

            refresh_indices: list[int] = []
            for idx, t in enumerate(tasks):
                if len(refresh_indices) >= 3:
                    break
                if (
                    getattr(t, "status", None) == _TS.RUNNING
                    and not getattr(t, "ssh_host", None)
                    and str(_TF.get_display_status(t)).lower() == "starting"
                ):
                    refresh_indices.append(idx)

            for idx in refresh_indices:
                try:
                    tid = getattr(tasks[idx], "task_id", None) or getattr(tasks[idx], "id", None)
                    if tid:
                        updated = self.flow.get_task(str(tid))
                        if updated:
                            tasks[idx] = updated
                except Exception:  # noqa: BLE001
                    continue
        except Exception:  # noqa: BLE001
            pass

    # -- Summary --

    def _print_summary_line(self, tasks: list[Task]) -> None:
        """Print a compact status count line above the table."""
        try:
            from flow.cli.ui.presentation.task_formatter import TaskFormatter as _TF

            # Count all display statuses, not just a hardcoded subset
            counts: dict[str, int] = {}
            for t in tasks:
                try:
                    s = _TF.get_display_status(t)
                except Exception:  # noqa: BLE001
                    s = getattr(getattr(t, "status", None), "value", str(getattr(t, "status", "")))
                key = str(s).lower()
                counts[key] = counts.get(key, 0) + 1

            # Display order: most actionable first
            display_order = [
                "running",
                "starting",
                "provisioning",
                "pending",
                "preempting",
                "failed",
                "paused",
            ]
            parts: list[str] = []
            for status in display_order:
                if counts.get(status):
                    parts.append(f"{counts[status]} {status}")

            if parts:
                self.console.print("[dim]" + " · ".join(parts) + "[/dim]\n")
        except Exception:  # noqa: BLE001
            pass

    # -- Render --

    def _render_tables(
        self,
        tasks: list[Task],
        options: StatusDisplayOptions,
        me: Me | None,
        owner_map: dict[str, str] | None,
        fast: bool,
    ) -> list[Task]:
        """Render task tables (grouped or flat). Returns the displayed task list."""
        if options.group_by_origin:
            return self._render_grouped(tasks, options, me, owner_map)
        return self._render_flat(tasks, options, me, owner_map, fast)

    def _render_grouped(
        self,
        tasks: list[Task],
        options: StatusDisplayOptions,
        me: Me | None,
        owner_map: dict[str, str] | None,
    ) -> list[Task]:
        """Render tasks grouped by origin (Flow vs External)."""
        flow_tasks: list[Task] = []
        other_tasks: list[Task] = []
        for t in tasks:
            meta = getattr(t, "provider_metadata", {}) or {}
            origin = str(meta.get("origin", "")).lower()
            if origin in ("flow-cli", "flow-compute"):
                flow_tasks.append(t)
            else:
                other_tasks.append(t)

        displayed: list[Task] = []

        # Compute unified GPU column width across groups for visual alignment
        forced_gpu_width = self._compute_gpu_width(flow_tasks + other_tasks)

        if flow_tasks:
            title_flow = prefix_with_flow_icon("Flow")
            panel = self.table.render(
                flow_tasks,
                me=me,
                owner_map=owner_map,
                title=title_flow,
                wide=False,
                start_index=1,
                return_renderable=True,
                forced_gpu_width=forced_gpu_width,
            )
            self.console.print(panel)
            displayed.extend(flow_tasks)

        if other_tasks:
            if flow_tasks:
                self.console.print("")
            panel = self.table.render(
                other_tasks,
                me=me,
                owner_map=owner_map,
                title="External · outside Flow",
                wide=False,
                start_index=(len(flow_tasks) + 1),
                return_renderable=True,
                forced_gpu_width=forced_gpu_width,
            )
            self.console.print(panel)
            displayed.extend(other_tasks)

        if not displayed:
            self.console.print(f"[dim]No {get_entity_labels().empty_plural} found[/dim]")

        # Show group legend when both groups are present
        if flow_tasks and other_tasks:
            legend = "External (launched outside Flow, e.g., provider console)"
            try:
                prov = getattr(getattr(self.flow, "config", None), "provider", None) or ""
                if not prov:
                    prov = (os.environ.get("FLOW_PROVIDER") or "").lower()
                if prov.lower() == "mithril":
                    legend = "External (launched outside Flow, e.g., Mithril Console)"
            except Exception:  # noqa: BLE001
                pass
            self.console.print(f"\n[dim]Groups: Flow (CLI/SDK) · {legend}[/dim]")

        return displayed

    def _render_flat(
        self,
        tasks: list[Task],
        options: StatusDisplayOptions,
        me: Me | None,
        owner_map: dict[str, str] | None,
        fast: bool,
    ) -> list[Task]:
        """Render tasks as a single flat table."""
        noun_plural = get_entity_labels().title_plural
        if not options.show_all:
            title = f"{noun_plural} (showing up to {options.limit}, last 24 hours)"
        else:
            title = f"{noun_plural} (showing up to {options.limit})"
        title = prefix_with_flow_icon(title)

        panel = self.table.render(
            tasks,
            me=me,
            owner_map=owner_map,
            title=title,
            wide=False,
            start_index=1,
            return_renderable=True,
            avoid_network_owner_lookups=fast,
        )
        self.console.print(panel)
        return list(tasks)

    def _compute_gpu_width(self, tasks: list[Task]) -> int | None:
        """Compute a unified GPU column width from actual task data."""
        try:
            from flow.cli.ui.presentation.gpu_formatter import GPUFormatter as _GF

            desired = 0
            for t in tasks:
                ni = getattr(t, "num_instances", 1)
                try:
                    ni = max(1, int(ni))
                except (TypeError, ValueError):
                    ni = 1
                s = _GF.format_ultra_compact(getattr(t, "instance_type", "") or "", ni)
                desired = max(desired, len(s))
            return desired if desired > 0 else None
        except Exception:  # noqa: BLE001
            return None

    # -- Context note --

    def _print_context_note(
        self,
        displayed_tasks: list[Task],
        options: StatusDisplayOptions,
        showing_active_only: bool,
    ) -> None:
        """Print post-table context about what's being shown."""
        if displayed_tasks and not options.show_all and not options.status_filter:
            noun = get_entity_labels().empty_plural
            if showing_active_only:
                self.console.print(
                    f"\n[muted]Showing active {noun} only. Use --all to see all {noun}.[/muted]"
                )
            else:
                self.console.print(
                    f"\n[muted]Showing recent {noun} from the last 24 hours. Use --all to see all {noun}.[/muted]"
                )
        elif options.status_filter:
            self.console.print(f"[dim]Filtered by status: {options.status_filter}[/dim]")

    # -- Hints --

    def _render_hints(self, displayed_tasks: list[Task], options: StatusDisplayOptions) -> None:
        """Render a concise footer with context-aware recommendations."""
        count = min(len(displayed_tasks), options.limit)
        if count >= 3:
            multi_example = "1-3"
        elif count == 2:
            multi_example = "1-2"
        else:
            multi_example = "1"

        recommendations = build_status_recommendations(
            displayed_tasks,
            max_count=3,
            index_example_single="1",
            index_example_multi=multi_example,
        )

        # Only show recommendations if there are any; skip generic index hints
        if recommendations:
            render_next_steps_panel(self.console, recommendations, max_items=3)

    # -- Cache --

    def _save_index_cache(self, displayed_tasks: list[Task]) -> None:
        """Save task indices for shortcut resolution."""
        try:
            cache = TaskIndexCache()
            cache.save_indices(displayed_tasks)
        except Exception as e:  # noqa: BLE001
            logger.warning("Failed to save task indices: %s", e)
            try:
                TaskIndexCache().clear()
            except Exception:  # noqa: BLE001
                pass
