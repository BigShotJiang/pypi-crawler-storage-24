"""Status table renderer (core).

Unified task table for the Flow CLI with compact columns.
"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from flow.cli.ui.presentation.gpu_formatter import GPUFormatter
from flow.cli.ui.presentation.terminal_adapter import TerminalAdapter
from flow.cli.ui.presentation.time_formatter import TimeFormatter
from flow.cli.ui.runtime.owner_resolver import Me, OwnerResolver
from flow.cli.utils.theme_manager import theme_manager
from flow.sdk.models import Task


class StatusTableRenderer:
    """Render tasks per the compact Status Table Spec.

    Columns (core, fixed positions):
      Index | Status | Task | GPU | Owner | Age

    Wide mode appends right-side columns only.
    """

    def __init__(self, console: Console | None = None) -> None:
        self.console = console or theme_manager.create_console()
        self.time_fmt = TimeFormatter()
        self.gpu_fmt = GPUFormatter()
        self.term = TerminalAdapter()
        # Centralized column config (DRY) — single source of truth for widths/alignments
        self._col_cfg = {
            "#": {"justify": "right", "width": 3, "min_width": 3, "no_wrap": True},
            "Status": {
                "justify": "center",
                "width": 12,  # slightly wider so long states like "completed" fit
                "min_width": 11,
                "no_wrap": True,
                "overflow": "crop",
            },
            "Task": {
                "justify": "left",
                "min_width": 16,
                "max_width": 40,
                "no_wrap": True,
                "overflow": "ellipsis",
            },
            "GPU": {
                "justify": "center",
                "width": 12,
                "min_width": 10,
                "no_wrap": True,
                "overflow": "crop",
            },
            "Owner": {
                "justify": "center",
                "min_width": 8,
                "max_width": 12,
                "no_wrap": True,
                "overflow": "ellipsis",
            },
            # Ensure Age always has room for compact formats like "8m", "11h", "2d"
            # Use width 4 to avoid header cropping edge-cases under tight padding
            "Age": {"justify": "right", "width": 4, "min_width": 3, "no_wrap": True},
        }
        # Cache for quick access
        self._gpu_col_width = self._col_cfg["GPU"].get("width", 12)

    def render(
        self,
        tasks: list[Task],
        *,
        me: Me | None = None,
        owner_map: dict[str, str] | None = None,
        title: str | None = None,
        wide: bool = False,
        start_index: int = 1,
        return_renderable: bool = False,
        forced_gpu_width: int | None = None,
        # Avoid slow provider calls during owner resolution in tight loops
        avoid_network_owner_lookups: bool = False,
    ):
        if not tasks:
            try:
                from flow.cli.ui.presentation.nomenclature import get_entity_labels as _labels

                msg = f"No {_labels().empty_plural} found"
            except Exception:  # noqa: BLE001
                msg = "No tasks found"
            return (
                Panel(msg, border_style=theme_manager.get_color("muted"))
                if return_renderable
                else self.console.print(f"[dim]{msg}[/dim]")
            )

        # Dynamically right-size the GPU column to avoid hanging/cropping.
        # Compute the ideal width from actual content, then clamp to a sane cap
        # to keep the table compact. This is surgical and only affects the GPU column.
        gpu_width = int(self._col_cfg.get("GPU", {}).get("width", 12))
        try:
            if forced_gpu_width is None:
                desired = 0
                for t in tasks:
                    # Coerce num_instances safely
                    ni = getattr(t, "num_instances", 1)
                    try:
                        ni = max(1, int(ni))
                    except Exception:  # noqa: BLE001
                        ni = 1
                    # Get unconstrained (full) compact string to measure
                    s = GPUFormatter.format_ultra_compact(getattr(t, "instance_type", "") or "", ni)
                    desired = max(desired, len(s))
            else:
                desired = int(forced_gpu_width)
            # Respect column min width; cap to keep layout tidy
            gpu_min = int(self._col_cfg.get("GPU", {}).get("min_width", 10))
            gpu_cap = 18  # fits values like "32×H100·80G" comfortably
            gpu_width = max(gpu_min, min(desired, gpu_cap))
        except Exception:  # noqa: BLE001
            pass
        # Update effective width used by width-aware formatter downstream
        self._gpu_col_width = gpu_width

        # Allow table to expand to available width to avoid cramped columns
        table = Table(
            box=None,
            show_header=True,
            header_style=theme_manager.get_color("table.header"),
            border_style=theme_manager.get_color("table.border"),
            padding=(0, 1),
            expand=True,  # Allow table to use available width to avoid header cropping
        )

        # Compute-mode aware header naming (centralized nomenclature)
        from flow.cli.ui.presentation.nomenclature import get_entity_labels as _labels

        task_header = _labels().header

        # Core columns from centralized config
        for name in ["#", "Status", task_header, "GPU", "Owner", "Age"]:
            # Use "Task" column config even if we re-label header in compute mode
            cfg_key = "Task" if name == task_header else name
            cfg = self._col_cfg[cfg_key]
            # Column-specific, restrained styling
            if name == "#":
                style = theme_manager.get_color("muted")
            elif name == task_header:
                style = theme_manager.get_color("task.name")
            elif name == "GPU":
                style = theme_manager.get_color("accent")
            elif name == "Owner":
                style = theme_manager.get_color("muted")
            elif name == "Age":
                style = theme_manager.get_color("task.time")
            else:
                style = None

            table.add_column(
                name,
                justify=cfg.get("justify", "left"),
                width=(gpu_width if name == "GPU" else cfg.get("width")),
                min_width=cfg.get("min_width"),
                max_width=cfg.get("max_width"),
                no_wrap=cfg.get("no_wrap", False),
                overflow=cfg.get("overflow"),
                style=style,
            )

        # Wide-only appended columns
        if wide:
            table.add_column("IP", justify="left", width=15, no_wrap=True)
            table.add_column("Class", justify="left", width=6, no_wrap=True)
            table.add_column("Created", justify="right", width=10, no_wrap=True)
            # Use shorter, unambiguous headers and slightly larger widths to avoid header cropping
            table.add_column("StartIn", justify="right", width=9, no_wrap=True)
            table.add_column("Window", justify="right", width=8, no_wrap=True)

        for idx, task in enumerate(tasks, start=start_index):
            status_display = self._format_status(task)
            # Coerce possible Mock attributes to safe strings
            try:
                name_val = getattr(task, "name", None)
                if name_val is None:
                    name_val = getattr(task, "task_id", "unnamed")
                task_name = str(name_val)
            except Exception:  # noqa: BLE001
                task_name = "unnamed"
            gpu = self._format_gpu(task)
            owner = self._format_owner(task, me, owner_map)
            age = self.time_fmt.format_ultra_compact_age(task.created_at)

            row = [str(idx), status_display, task_name, gpu, owner, age]

            if wide:
                start_in, window = self._format_reservation_columns(task)
                row.extend(
                    [
                        task.ssh_host or "-",
                        self._format_class(task),
                        self.time_fmt.format_ultra_compact_age(task.created_at),
                        start_in,
                        window,
                    ]
                )

            table.add_row(*row)

        if title:
            from rich.markup import escape

            try:
                safe_title = escape(str(title))
            except Exception:  # noqa: BLE001
                safe_title = "Tasks"
            title_text = Text(safe_title, style=f"bold {theme_manager.get_color('accent')}")
            panel = Panel(
                table,
                title=title_text,
                title_align="left",
                border_style=theme_manager.get_color("table.border"),
                padding=(1, 2),
                expand=False,
            )
            return panel if return_renderable else self.console.print(panel)
        return table if return_renderable else self.console.print(table)

    # --- Cell formatters ---

    def _format_status(self, task: Task) -> str:
        from flow.cli.ui.presentation.task_formatter import TaskFormatter

        # Width-aware hybrid: show word when it fits, otherwise compact symbol-only
        # Use configured column width when available
        try:
            STATUS_COL_WIDTH = int(self._col_cfg.get("Status", {}).get("width", 10))
        except Exception:  # noqa: BLE001
            STATUS_COL_WIDTH = 10
        layout = self.term.get_responsive_layout()

        display_status = TaskFormatter.get_display_status(task)

        plain_length = 2 + len(display_status)  # symbol + space + word
        compact = layout.get("use_compact_status", False) or plain_length > STATUS_COL_WIDTH
        base = (
            TaskFormatter.format_compact_status(display_status)
            if compact
            else TaskFormatter.format_status_with_color(display_status)
        )

        # Append a tiny reserved badge when space allows
        try:
            meta = getattr(task, "provider_metadata", {}) or {}
            res = meta.get("reservation")
            if res and not compact and (plain_length + 3) <= STATUS_COL_WIDTH:
                # Only annotate when not extremely tight
                # Use subtle dim 'R' badge to indicate reserved capacity
                return f"{base} [dim]R[/dim]"
        except Exception:  # noqa: BLE001
            pass
        return base

    def _format_task_name(self, task: Task) -> str:
        # Let the table column control width and overflow; avoid pre-truncation
        return task.name or "unnamed"

    def _format_owner(
        self, task: Task, me: Me | None, owner_map: dict[str, str] | None = None
    ) -> str:
        """Format owner column using centralized OwnerResolver."""
        created_by = getattr(task, "created_by", None)
        if not created_by:
            return "-"
        label = OwnerResolver.format_owner(created_by, me, owner_map)
        return label or "-"

    def _format_gpu(self, task: Task) -> str:
        # Be resilient to Mock objects: coerce num_instances to int>0
        num = getattr(task, "num_instances", 1)
        try:
            num = int(num)
            if num <= 0:
                num = 1
        except Exception:  # noqa: BLE001
            num = 1
        # Use the configured GPU column width to drive width-aware formatting
        return self.gpu_fmt.format_ultra_compact_width_aware(
            task.instance_type, num, self._gpu_col_width
        )

    def _format_class(self, task: Task) -> str:
        it = (task.instance_type or "").lower()
        try:
            provider_meta = getattr(task, "provider_metadata", {}) or {}
        except Exception:  # noqa: BLE001
            provider_meta = {}
        if "sxm" in it:
            return "SXM"
        socket = str(provider_meta.get("socket", "")).lower()
        if "pcie" in it or "pcie" in socket:
            return "PCIe"
        return "-"

    def _format_reservation_columns(self, task: Task) -> tuple[str, str]:
        """Return (Start In, Window) for wide mode when task has reservation metadata."""
        try:
            from datetime import datetime, timezone

            meta = getattr(task, "provider_metadata", {}) or {}
            res = meta.get("reservation")
            if not res:
                return "-", "-"
            st = res.get("start_time") or res.get("start_time_utc")
            et = res.get("end_time") or res.get("end_time_utc")
            start_in = "-"
            if st:
                try:
                    s = str(st).replace("Z", "+00:00")
                    dt = datetime.fromisoformat(s)
                    delta_min = max(0, int((dt - datetime.now(timezone.utc)).total_seconds() // 60))
                    start_in = f"{delta_min}m" if delta_min < 120 else f"{delta_min // 60}h"
                except Exception:  # noqa: BLE001
                    pass
            window = "-"
            if st and et:
                try:
                    s1 = str(st).replace("Z", "+00:00")
                    s2 = str(et).replace("Z", "+00:00")
                    dt1 = datetime.fromisoformat(s1)
                    dt2 = datetime.fromisoformat(s2)
                    hours = round((dt2 - dt1).total_seconds() / 3600)
                    window = f"{hours}h"
                except Exception:  # noqa: BLE001
                    pass
            return start_in, window
        except Exception:  # noqa: BLE001
            return "-", "-"
