"""Helpers for building and rendering context-aware "Next steps" panels.

This module centralizes construction and presentation of follow-up
recommendations across CLI commands to ensure a consistent UX.

Design goals:
- Opinionated, minimal, context-aware suggestions
- One rendering style (panel) with muted border
- No command-specific knowledge beyond simple task state heuristics
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import TYPE_CHECKING

from rich.console import Console

if TYPE_CHECKING:
    from flow.sdk.models import Task


def _get_labels():
    """Late-bind nomenclature labels to defer import until actual use."""
    from flow.cli.ui.presentation.nomenclature import get_entity_labels

    return get_entity_labels()


def _get_command_prefix() -> str:
    """Return the command prefix for next-step hints."""
    return "flow"


def _get_create_command() -> str:
    """Return the create/submit command verb for next-step hints."""
    return "submit"


def _get_list_command() -> str:
    """Return the list/status command verb for next-step hints."""
    return "status"


def build_empty_state_next_steps(has_history: bool) -> list[str]:
    """Recommendations when there are no active tasks.

    Args:
        has_history: True if any tasks exist historically (even if not recent)

    Returns:
        A short, ordered list of next steps to present to the user.
    """

    steps: list[str] = []

    # Always offer the fastest path to success
    labels = _get_labels()
    noun = labels.empty_plural[:-1] if labels.empty_plural.endswith("s") else labels.empty_plural
    cmd_prefix = _get_command_prefix()
    create_cmd = _get_create_command()
    # Create a <noun> (quick)
    steps.append(
        f"[accent][bold]{cmd_prefix}[/bold][/accent] {create_cmd} -- 'nvidia-smi' [muted]— Create {labels.article} {noun} (quick)[/muted]"
    )
    steps.append(
        "[accent][bold]flow[/bold][/accent] template -o task.yaml [muted]— Generate YAML template[/muted]"
    )

    # If they already have history, nudge discovery; otherwise nudge examples
    if has_history:
        list_cmd = _get_list_command()
        steps.append(
            f"[accent][bold]flow[/bold][/accent] {list_cmd} 1 [muted]— View {labels.empty_plural[:-1] if labels.empty_plural.endswith('s') else labels.empty_plural} details (by index)[/muted]"
        )
        noun_name = f"{labels.singular}-name"
        steps.append(
            f"[accent][bold]flow[/bold][/accent] {list_cmd} [task.name]<{noun_name}>[/task.name] [muted]— View {labels.empty_plural[:-1] if labels.empty_plural.endswith('s') else labels.empty_plural} details (by name)[/muted]"
        )
    else:
        steps.append("[accent][bold]flow[/bold][/accent] example [muted]— Explore starters[/muted]")

    return steps


def build_generic_recommendations(*, index_help: str, active_tasks: int) -> list[str]:
    """Generic recommendations to append beneath listings.

    Args:
        index_help: A human-friendly index range (e.g., "1" or "1-5")
        active_tasks: Number of active (running/pending) tasks displayed

    Returns:
        A list of recommendations suitable for a compact "Next steps" panel.
    """

    recs: list[str] = []
    # Drill-down affordance – useful in every state
    labels = _get_labels()
    noun = labels.empty_plural[:-1] if labels.empty_plural.endswith("s") else labels.empty_plural
    list_cmd = _get_list_command()
    recs.append(
        f"[accent][bold]flow[/bold][/accent] {list_cmd} {index_help} [muted]— View {noun} details (by index)[/muted]"
    )
    noun_name = f"{labels.singular}-name"
    recs.append(
        f"[accent][bold]flow[/bold][/accent] {list_cmd} [task.name]<{noun_name}>[/task.name] [muted]— View {labels.empty_plural[:-1] if labels.empty_plural.endswith('s') else labels.empty_plural} details (by name)[/muted]"
    )

    # If nothing is running, offer a one-liner to create work
    if active_tasks == 0:
        cmd_prefix = _get_command_prefix()
        create_cmd = _get_create_command()
        recs.insert(
            0,
            f"[accent][bold]{cmd_prefix}[/bold][/accent] {create_cmd} -- 'nvidia-smi' [muted]— Create {labels.article} {noun} (quick)[/muted]",
        )

    return recs


def _is_flow_origin(task: Task) -> bool:
    """Return True if a task is from Flow CLI origin."""
    meta = task.provider_metadata or {}
    return meta.get("origin") == "flow-cli"


def _status_value(task: Task) -> str:
    """Return task status value as string, handling enum types."""
    status = task.status
    return status.value if hasattr(status, "value") else str(status)


def _display_status(task: Task) -> str:
    """Return the display status for a task, differentiating 'starting' from 'pending'."""
    from flow.cli.ui.formatters.shared_task import TaskFormatter

    return str(TaskFormatter.get_display_status(task)).lower()


_STALE_THRESHOLD_DAYS = 30


def _find_stale_tasks(
    task_list: list[Task],
) -> list[tuple[int, Task]]:
    """Return (1-based display index, task) pairs for Flow-origin tasks older than the stale threshold.

    External tasks (launched outside Flow) are excluded because `flow stop`
    cannot manage them.
    """
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    stale: list[tuple[int, Task]] = []
    for idx, t in enumerate(task_list, start=1):
        if not _is_flow_origin(t):
            continue
        created = getattr(t, "created_at", None)
        if created is None:
            continue
        # Ensure timezone-aware comparison
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        age_days = (now - created).days
        if age_days >= _STALE_THRESHOLD_DAYS:
            stale.append((idx, t))
    return stale


def build_status_recommendations(
    tasks: Iterable[Task],
    *,
    max_count: int,
    index_example_single: str,
    index_example_multi: str,
) -> list[str]:
    """Build context-aware recommendations for the status view.

    Recommendations are prioritized by what matters most right now:
    1. Stale task cleanup (tasks running 30+ days)
    2. Pending/starting task readiness
    3. SSH and log access for running tasks
    4. Getting-started paths when idle

    Args:
        tasks: Tasks displayed to the user (already ordered as shown).
        max_count: Maximum number of recommendations to return.
        index_example_single: Index shortcut example for a single selection (e.g., "1").
        index_example_multi: Index shortcut example for multi/range (e.g., "1-3" or "1-3,5").

    Returns:
        A list of concise recommendation strings (top-N by priority).
    """
    task_list = list(tasks)

    has_running = any(_display_status(t) == "running" for t in task_list)
    has_pending = any(_display_status(t) in ("pending", "starting", "open") for t in task_list)
    has_active = has_running or has_pending
    has_flow_running = any(_is_flow_origin(t) and _status_value(t) == "running" for t in task_list)

    labels = _get_labels()
    noun_lower = labels.singular
    list_cmd = _get_list_command()

    recs: list[str] = []

    # --- Priority 1: Stale task cleanup ---
    stale = _find_stale_tasks(task_list)
    if stale:
        if len(stale) == 1:
            idx, t = stale[0]
            age_days = _task_age_days(t)
            recs.append(
                f"[accent][bold]flow[/bold][/accent] stop {idx} [muted]— {t.name} has been running {age_days}d[/muted]"
            )
        else:
            indices = ",".join(str(idx) for idx, _ in stale)
            recs.append(
                f"[accent][bold]flow[/bold][/accent] stop {indices} [muted]— {len(stale)} {labels.empty_plural} running 30+ days[/muted]"
            )

    # --- Priority 2: Pending/starting readiness ---
    if has_pending:
        recs.append(
            f"[accent][bold]flow[/bold][/accent] {list_cmd} {index_example_single} [muted]— View {noun_lower} details (readiness)[/muted]"
        )
        recs.append(
            f"[accent][bold]flow[/bold][/accent] logs {index_example_single} -f [muted]— Follow startup logs[/muted]"
        )

    # --- Priority 3: SSH and log access ---
    if has_flow_running:
        recs.append(
            f"[accent][bold]flow[/bold][/accent] ssh {index_example_single} [muted]— SSH into {noun_lower}[/muted]"
        )
        recs.append(
            f"[accent][bold]flow[/bold][/accent] logs {index_example_single} [muted]— View logs[/muted]"
        )

    # --- Priority 4: Getting-started paths when idle ---
    if not has_active:
        recs.append(
            "[accent][bold]flow[/bold][/accent] dev [muted]— Start development environment[/muted]"
        )
        recs.append("[accent][bold]flow[/bold][/accent] example [muted]— Explore starters[/muted]")

    return recs[: max(0, int(max_count))]


def _task_age_days(task: Task) -> int:
    """Return the age of a task in days."""
    from datetime import datetime, timezone

    created = getattr(task, "created_at", None)
    if created is None:
        return 0
    if created.tzinfo is None:
        created = created.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - created).days


def render_next_steps_panel(
    console: Console,
    recommendations: Iterable[str],
    *,
    title: str = "Next Steps",
    max_items: int = 3,
) -> None:
    """Render a compact, borderless list of recommendations.

    Args:
        console: Rich console to render into.
        recommendations: Lines to display.
        title: Section label (plain text; styling handled internally).
    """
    # Enforce a concise set of top actions
    recs = [str(r).strip() for r in recommendations if str(r).strip()]
    if max_items and max_items > 0:
        recs = recs[:max_items]
    if not recs:
        return

    console.print()
    lines = [f"  {r}" for r in recs]
    console.print("\n".join(lines))
    console.print()
