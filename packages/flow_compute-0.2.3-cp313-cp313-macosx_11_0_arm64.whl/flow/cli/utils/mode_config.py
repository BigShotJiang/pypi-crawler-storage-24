from dataclasses import dataclass, field
from enum import Enum
from typing import Final


class Mode(Enum):
    """Retained for backward compatibility. The CLI no longer switches modes."""

    INFRA = "infra"
    RESEARCH = "research"


@dataclass(frozen=True)
class ModeConfig:
    """Configuration for CLI command grouping."""

    name: str
    display_name: str
    description: str
    groups: dict[str, list[str]]  # Group name -> command names
    core_commands: set[str] = field(default_factory=set)  # Commands shown by default


# Unified command layout -- all commands visible to all users.
_UNIFIED_CONFIG: Final[ModeConfig] = ModeConfig(
    name="default",
    display_name="Flow",
    description="GPU Cloud Platform",
    groups={
        "Getting started": ["setup"],
        "Compute": ["instance", "grab", "dev", "serve", "reserve"],
        "Jobs": ["submit", "status", "logs", "cancel", "ssh"],
        "Resources": ["volume", "ssh-key", "k8s"],
        "Tools": ["pricing", "availability", "ask", "jupyter", "colab", "ports", "deploy"],
    },
    core_commands={
        "setup",
        "instance",
        "grab",
        "dev",
        "serve",
        "submit",
        "status",
        "logs",
        "cancel",
        "ssh",
        "volume",
        "ssh-key",
        "pricing",
        "availability",
    },
)

# Both modes now resolve to the same unified config.
MODE_CONFIGS: Final[dict[Mode, ModeConfig]] = {
    Mode.INFRA: _UNIFIED_CONFIG,
    Mode.RESEARCH: _UNIFIED_CONFIG,
}


def get_mode_config(mode: Mode) -> ModeConfig:
    return _UNIFIED_CONFIG


def get_current_mode() -> Mode:
    """Return the default mode. Mode switching has been removed."""
    return Mode.INFRA


def set_mode(mode: Mode) -> None:
    """No-op. Mode switching has been removed."""
    pass


def get_other_mode() -> Mode:
    """No-op. Returns INFRA for backward compatibility."""
    return Mode.INFRA
