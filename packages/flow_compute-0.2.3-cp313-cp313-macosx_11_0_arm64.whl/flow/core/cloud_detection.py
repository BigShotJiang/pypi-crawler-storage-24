"""Cloud credential detection for multi-cloud setup.

Detects configured cloud credentials (AWS, GCP, Azure) by checking
environment variables and well-known credential file locations. Uses only
stdlib to satisfy the core_is_framework_agnostic import contract.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class CloudStatus:
    """Detection result for a single cloud provider.

    Attributes:
        name: Human-readable cloud name ("AWS", "GCP", "Azure").
        key: Machine key used in config files ("aws", "gcp", "azure").
        is_configured: Whether valid credentials were detected.
        credential_source: Description of where credentials were found,
            or "Not configured" if absent.
        setup_instructions: Ordered steps to configure this cloud.
            Each tuple is (step_description, command_or_url).
    """

    name: str
    key: str
    is_configured: bool
    credential_source: str
    setup_instructions: list[tuple[str, str]] = field(default_factory=list)


def _detect_aws() -> CloudStatus:
    """Detect AWS credentials from env vars or credential files."""
    # Check environment variables (explicit credentials)
    if os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_SECRET_ACCESS_KEY"):
        return CloudStatus(
            name="AWS",
            key="aws",
            is_configured=True,
            credential_source="AWS_ACCESS_KEY_ID environment variable",
        )

    # Check credential files
    aws_dir = Path.home() / ".aws"
    credentials_file = aws_dir / "credentials"
    config_file = aws_dir / "config"

    if credentials_file.exists():
        return CloudStatus(
            name="AWS",
            key="aws",
            is_configured=True,
            credential_source="~/.aws/credentials",
        )

    # SSO config is also valid
    if config_file.exists():
        return CloudStatus(
            name="AWS",
            key="aws",
            is_configured=True,
            credential_source="~/.aws/config (SSO)",
        )

    return CloudStatus(
        name="AWS",
        key="aws",
        is_configured=False,
        credential_source="Not configured",
        setup_instructions=[
            (
                "Install the AWS CLI",
                "https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html",
            ),
            ("Configure credentials", "aws configure"),
        ],
    )


def _detect_gcp() -> CloudStatus:
    """Detect GCP credentials from env vars or application default credentials."""
    # Check GOOGLE_APPLICATION_CREDENTIALS env var
    gac_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if gac_path and Path(gac_path).exists():
        return CloudStatus(
            name="GCP",
            key="gcp",
            is_configured=True,
            credential_source=f"GOOGLE_APPLICATION_CREDENTIALS ({gac_path})",
        )

    # Check application default credentials
    adc_path = Path.home() / ".config" / "gcloud" / "application_default_credentials.json"
    if adc_path.exists():
        return CloudStatus(
            name="GCP",
            key="gcp",
            is_configured=True,
            credential_source="~/.config/gcloud/application_default_credentials.json",
        )

    return CloudStatus(
        name="GCP",
        key="gcp",
        is_configured=False,
        credential_source="Not configured",
        setup_instructions=[
            ("Install the Google Cloud SDK", "https://cloud.google.com/sdk/docs/install"),
            ("Authenticate", "gcloud auth login"),
            ("Set application default credentials", "gcloud auth application-default login"),
        ],
    )


def _detect_azure() -> CloudStatus:
    """Detect Azure credentials from env vars or CLI profile."""
    # Check environment variables (service principal auth)
    if os.environ.get("AZURE_CLIENT_ID") and os.environ.get("AZURE_TENANT_ID"):
        return CloudStatus(
            name="Azure",
            key="azure",
            is_configured=True,
            credential_source="AZURE_CLIENT_ID environment variable",
        )

    # Check Azure CLI profile
    azure_profile = Path.home() / ".azure" / "azureProfile.json"
    if azure_profile.exists():
        return CloudStatus(
            name="Azure",
            key="azure",
            is_configured=True,
            credential_source="~/.azure/azureProfile.json",
        )

    return CloudStatus(
        name="Azure",
        key="azure",
        is_configured=False,
        credential_source="Not configured",
        setup_instructions=[
            (
                "Install the Azure CLI",
                "https://learn.microsoft.com/en-us/cli/azure/install-azure-cli",
            ),
            ("Sign in", "az login"),
        ],
    )


def detect_all_clouds() -> list[CloudStatus]:
    """Detect credentials for all supported cloud providers.

    Returns:
        List of CloudStatus objects for AWS, GCP, and Azure (in that order).
    """
    return [_detect_aws(), _detect_gcp(), _detect_azure()]
