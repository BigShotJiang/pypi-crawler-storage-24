from __future__ import annotations

import torch


def reshape_and_cache_flash_torch(
    *,
    key: torch.Tensor,
    value: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    slot_mapping: torch.Tensor,
    kv_cache_dtype: str,
    k_scale: torch.Tensor,
    v_scale: torch.Tensor,
) -> None:
    # Keep this path graph-friendly: avoid value-dependent masking ops so decode
    # graph capture/replay remains stable on non-SM90 devices.
    slots = slot_mapping
    if (
        slots.device != key.device
        or slots.dtype != torch.int64
        or not slots.is_contiguous()
    ):
        slots = slots.to(device=key.device, dtype=torch.int64).contiguous()
    slots = slots.view(-1)
    if slots.numel() == 0:
        return
    if slots.numel() != int(key.shape[0]) or slots.numel() != int(value.shape[0]):
        raise ValueError("slot_mapping and key/value token dimensions must match")
    block_size = int(key_cache.shape[1])
    k_sel = key
    v_sel = value

    if block_size == 1:
        blocks = slots
        key_cache_bs1 = key_cache.select(1, 0)
        value_cache_bs1 = value_cache.select(1, 0)
        if kv_cache_dtype in ("fp8", "fp8_e4m3"):
            k_scale_t = (
                torch.as_tensor(k_scale, device=key.device, dtype=torch.float32)
                .reshape(1, 1, 1)
            )
            v_scale_t = (
                torch.as_tensor(v_scale, device=key.device, dtype=torch.float32)
                .reshape(1, 1, 1)
            )

            key_cache_fp8 = key_cache.view(torch.float8_e4m3fn).select(1, 0)
            value_cache_fp8 = value_cache.view(torch.float8_e4m3fn).select(1, 0)
            key_cache_fp8.index_copy_(
                0,
                blocks,
                (k_sel.to(torch.float32) / k_scale_t).to(torch.float8_e4m3fn),
            )
            value_cache_fp8.index_copy_(
                0,
                blocks,
                (v_sel.to(torch.float32) / v_scale_t).to(torch.float8_e4m3fn),
            )
            return

        if kv_cache_dtype != "auto":
            raise ValueError(f"Unsupported kv_cache_dtype: {kv_cache_dtype}")
        index = blocks.view(-1, 1, 1).expand(
            -1, key_cache_bs1.shape[1], key_cache_bs1.shape[2]
        )
        key_cache_bs1.scatter_(0, index, k_sel.to(dtype=key_cache_bs1.dtype))
        value_cache_bs1.scatter_(0, index, v_sel.to(dtype=value_cache_bs1.dtype))
        return

    blocks = torch.floor_divide(slots, block_size)
    offsets = slots - (blocks * block_size)

    if kv_cache_dtype in ("fp8", "fp8_e4m3"):
        k_scale_t = (
            torch.as_tensor(k_scale, device=key.device, dtype=torch.float32).reshape(
                1, 1, 1
            )
        )
        v_scale_t = (
            torch.as_tensor(v_scale, device=key.device, dtype=torch.float32).reshape(
                1, 1, 1
            )
        )

        key_cache_fp8 = key_cache.view(torch.float8_e4m3fn)
        value_cache_fp8 = value_cache.view(torch.float8_e4m3fn)
        key_cache_fp8[blocks, offsets, :, :] = (k_sel.to(torch.float32) / k_scale_t).to(
            torch.float8_e4m3fn
        )
        value_cache_fp8[blocks, offsets, :, :] = (
            v_sel.to(torch.float32) / v_scale_t
        ).to(torch.float8_e4m3fn)
        return

    if kv_cache_dtype != "auto":
        raise ValueError(f"Unsupported kv_cache_dtype: {kv_cache_dtype}")

    key_cache[blocks, offsets, :, :] = k_sel.to(dtype=key_cache.dtype)
    value_cache[blocks, offsets, :, :] = v_sel.to(dtype=value_cache.dtype)


__all__ = ["reshape_and_cache_flash_torch"]
