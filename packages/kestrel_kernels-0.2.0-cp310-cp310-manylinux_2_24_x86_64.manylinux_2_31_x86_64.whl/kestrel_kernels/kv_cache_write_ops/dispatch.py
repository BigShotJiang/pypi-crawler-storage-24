"""Dispatch wrapper for KV-cache write with architecture-aware torch fallback."""

from __future__ import annotations

import torch

from kestrel_kernels.fallback import should_use_cuda_impl
from kestrel_kernels.kv_cache_write import (
    reshape_and_cache_flash as reshape_and_cache_flash_cuda,
)
from kestrel_kernels.kv_cache_write_ops.fallback import reshape_and_cache_flash_torch

_SUPPORTED_SMS = {80, 86, 87, 89, 90}


def reshape_and_cache_flash(
    key: torch.Tensor,
    value: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    slot_mapping: torch.Tensor,
    kv_cache_dtype: str,
    k_scale: torch.Tensor,
    v_scale: torch.Tensor,
) -> None:
    if key.device.type != "cuda" or value.device.type != "cuda":
        raise ValueError("reshape_and_cache_flash expects CUDA key/value tensors")
    if key_cache.device.type != "cuda" or value_cache.device.type != "cuda":
        raise ValueError("reshape_and_cache_flash expects CUDA cache tensors")

    if should_use_cuda_impl(
        device=key.device,
        kernel_key="kv_cache_write",
        op_name="reshape_and_cache_flash",
        supported_sms=_SUPPORTED_SMS,
    ):
        reshape_and_cache_flash_cuda(
            key,
            value,
            key_cache,
            value_cache,
            slot_mapping,
            kv_cache_dtype,
            k_scale,
            v_scale,
        )
        return

    reshape_and_cache_flash_torch(
        key=key,
        value=value,
        key_cache=key_cache,
        value_cache=value_cache,
        slot_mapping=slot_mapping,
        kv_cache_dtype=kv_cache_dtype,
        k_scale=k_scale,
        v_scale=v_scale,
    )


__all__ = ["reshape_and_cache_flash"]
