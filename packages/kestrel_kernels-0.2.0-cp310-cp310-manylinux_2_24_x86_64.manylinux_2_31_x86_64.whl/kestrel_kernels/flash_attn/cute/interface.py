"""Thin flash-attention dispatcher.

This module keeps the non-SM90 fallback path lightweight and only imports
CuTe/SM90 implementation details on demand.
"""

from __future__ import annotations

import math
from functools import lru_cache
from importlib import import_module
from typing import TYPE_CHECKING, Callable, Optional, Tuple

import torch

from kestrel_kernels.arch import get_cuda_compute_capability
from kestrel_kernels.flash_attn.cute.fallback import flash_attn_fwd_torch_fallback

if TYPE_CHECKING:
    from kestrel_kernels.flash_attn.cute.block_sparsity import BlockSparseTensorsTorch


@lru_cache(maxsize=1)
def _load_sm90_interface():
    """Load SM90 CuTe implementation lazily and patch entrypoint dispatch."""
    module = import_module("kestrel_kernels.flash_attn.cute.interface_sm90")

    if not hasattr(module, "_flash_attn_fwd_sm90"):
        module._flash_attn_fwd_sm90 = module._flash_attn_fwd
        module._flash_attn_fwd = _flash_attn_fwd
        _flash_attn_fwd.compile_cache = module._flash_attn_fwd_sm90.compile_cache

    return module


@lru_cache(maxsize=1)
def _load_sm8x_interface():
    """Load SM8x prefill implementation lazily."""
    return import_module("kestrel_kernels.flash_attn.cute.interface_sm8x")


def maybe_contiguous(x):
    return x.contiguous() if x is not None and x.stride(-1) != 1 else x


def _validate_tensor(t, name, expected_shape, expected_dtype, expected_device):
    assert t.shape == expected_shape, f"{name} shape {t.shape} != expected {expected_shape}"
    assert t.dtype == expected_dtype, f"{name} dtype {t.dtype} != expected {expected_dtype}"
    assert t.device == expected_device, f"{name} device {t.device} != expected {expected_device}"
    assert t.is_cuda, f"{name} must be on CUDA"


def _flash_attn_fwd(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    softcap: Optional[float] = None,
    window_size_left: Optional[int] = None,
    window_size_right: Optional[int] = None,
    learnable_sink: Optional[torch.Tensor] = None,
    m_block_size: int = 128,
    n_block_size: int = 128,
    num_threads: int = 384,
    num_splits: int = 1,
    pack_gqa: Optional[bool] = None,
    compute_capability: Optional[tuple[int, int]] = None,
    score_mod: Optional[Callable] = None,
    mask_mod: Optional[Callable] = None,
    block_sparse_tensors: Optional["BlockSparseTensorsTorch"] = None,
    return_lse: bool = False,
    out: Optional[torch.Tensor] = None,
    lse: Optional[torch.Tensor] = None,
    aux_tensors: Optional[list[torch.Tensor]] = None,
    paged_kv_non_tma: Optional[bool] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    if compute_capability is None:
        cc_major, cc_minor = get_cuda_compute_capability()
    else:
        cc_major, cc_minor = int(compute_capability[0]), int(compute_capability[1])

    if cc_major == 8:
        sm8x = _load_sm8x_interface()
        out, lse = sm8x._flash_attn_fwd_sm8x(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            softcap=softcap,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            learnable_sink=learnable_sink,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            compute_capability=(cc_major, cc_minor),
            score_mod=score_mod,
            mask_mod=mask_mod,
            block_sparse_tensors=block_sparse_tensors,
            return_lse=return_lse,
            out=out,
            lse=lse,
            aux_tensors=aux_tensors,
            paged_kv_non_tma=paged_kv_non_tma,
            k_scale=k_scale,
            v_scale=v_scale,
        )
        impl = getattr(sm8x._flash_attn_fwd_sm8x, "_debug_last_impl", None)
        if impl is not None:
            _flash_attn_fwd._debug_last_impl = impl
        return out, lse

    if cc_major >= 9:
        sm90 = _load_sm90_interface()
        return sm90._flash_attn_fwd_sm90(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            softcap=softcap,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            learnable_sink=learnable_sink,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            compute_capability=(cc_major, cc_minor),
            score_mod=score_mod,
            mask_mod=mask_mod,
            block_sparse_tensors=block_sparse_tensors,
            return_lse=return_lse,
            out=out,
            lse=lse,
            aux_tensors=aux_tensors,
            paged_kv_non_tma=paged_kv_non_tma,
            k_scale=k_scale,
            v_scale=v_scale,
        )

    q, k, v = [maybe_contiguous(t) for t in (q, k, v)]
    if isinstance(k_scale, torch.Tensor):
        raise TypeError("k_scale must be a float, not a tensor (tensor.item() causes GPU sync)")
    if isinstance(v_scale, torch.Tensor):
        raise TypeError("v_scale must be a float, not a tensor (tensor.item() causes GPU sync)")
    k_scale_val = 1.0 if k_scale is None else float(k_scale)
    v_scale_val = 1.0 if v_scale is None else float(v_scale)

    num_head, head_dim = q.shape[-2:]
    if cu_seqlens_q is None:
        batch_size, seqlen_q = q.shape[:2]
        total_q = batch_size * seqlen_q
    else:
        batch_size = cu_seqlens_q.shape[0] - 1
        seqlen_q = None
        total_q = q.shape[0]

    if page_table is not None:
        assert cu_seqlens_k is None, "page_table is not supported with cu_seqlens_k"
        assert page_table.dtype == torch.int32, "page_table must be int32"
        assert page_table.stride(-1) == 1, "page_table must be contiguous in the last dimension"
        max_num_pages_per_seq = page_table.shape[1]
        assert page_table.shape == (batch_size, max_num_pages_per_seq)
        num_pages, page_size = k.shape[:2]
        seqlen_k = num_pages * page_size
    else:
        num_pages, page_size = None, None
        seqlen_k = k.shape[-3]

    num_head_kv = k.shape[-2]
    head_dim_v = v.shape[-1]
    if cu_seqlens_k is None:
        if page_table is None:
            assert k.shape == (batch_size, seqlen_k, num_head_kv, head_dim)
            assert v.shape == (batch_size, seqlen_k, num_head_kv, head_dim_v)
        else:
            assert k.shape == (num_pages, page_size, num_head_kv, head_dim)
            assert v.shape == (num_pages, page_size, num_head_kv, head_dim_v)
    else:
        assert k.shape == (seqlen_k, num_head_kv, head_dim)
        assert v.shape == (seqlen_k, num_head_kv, head_dim_v)
        assert cu_seqlens_k.shape == (batch_size + 1,), (
            "cu_seqlens_k must have shape (batch_size + 1,)"
        )

    if cu_seqlens_q is not None:
        assert cu_seqlens_q.shape == (batch_size + 1,), (
            "cu_seqlens_q must have shape (batch_size + 1,)"
        )
    assert seqused_q is None or seqused_q.shape == (batch_size,), (
        "seqused_q must have shape (batch_size,)"
    )
    assert seqused_k is None or seqused_k.shape == (batch_size,), (
        "seqused_k must have shape (batch_size,)"
    )
    assert q.dtype in [torch.float16, torch.bfloat16], "q must be float16 or bfloat16"

    kv_is_fp8 = (k.dtype == torch.float8_e4m3fn) or (v.dtype == torch.float8_e4m3fn)
    if kv_is_fp8:
        if k.dtype != torch.float8_e4m3fn or v.dtype != torch.float8_e4m3fn:
            raise ValueError(
                f"FP8 KV cache requires k and v both be float8_e4m3fn (got k={k.dtype}, v={v.dtype})"
            )
        if k_scale is None or v_scale is None:
            raise ValueError("FP8 KV cache requires k_scale and v_scale")
        if k_scale_val <= 0.0 or v_scale_val <= 0.0:
            raise ValueError("k_scale and v_scale must be positive for FP8 KV cache")
    else:
        assert q.dtype == k.dtype == v.dtype, "inputs must have the same dtype"

    for t in [cu_seqlens_q, cu_seqlens_k, seqused_q, seqused_k]:
        if t is not None:
            assert t.dtype == torch.int32, (
                "cu_seqlens_q, cu_seqlens_k, seqused_q, seqused_k must be int32"
            )
            assert t.stride(0) == 1, (
                "cu_seqlens_q, cu_seqlens_k, seqused_q, seqused_k must be contiguous"
            )

    if learnable_sink is not None:
        assert learnable_sink.shape == (num_head,)
        assert learnable_sink.dtype == torch.bfloat16, "learnable_sink must be bfloat16"

    assert all(
        t is None or t.is_cuda
        for t in (
            q,
            k,
            v,
            cu_seqlens_q,
            cu_seqlens_k,
            seqused_q,
            seqused_k,
            page_table,
            learnable_sink,
        )
    ), "inputs must be on CUDA device"
    assert num_head % num_head_kv == 0, "num_head must be divisible by num_head_kv"
    assert head_dim <= 256, "head_dim must be less than or equal to 256"

    alignment = 16 // q.element_size()
    assert head_dim % alignment == 0, f"head_dim must be divisible by {alignment}"
    assert head_dim_v % alignment == 0, f"head_dim_v must be divisible by {alignment}"

    if softmax_scale is None:
        softmax_scale = 1.0 / math.sqrt(head_dim)
    if softcap == 0.0:
        softcap = None

    qhead_per_kvhead = num_head // num_head_kv
    if pack_gqa is None:
        pack_gqa = qhead_per_kvhead > 1

    out_torch_dtype = q.dtype
    device = q.device
    q_batch_seqlen_shape = (batch_size, seqlen_q) if cu_seqlens_q is None else (total_q,)
    lse_shape = (batch_size, num_head, seqlen_q) if cu_seqlens_q is None else (num_head, total_q)
    requires_grad = q.requires_grad or k.requires_grad or v.requires_grad

    if out is None:
        out = torch.empty(
            *q_batch_seqlen_shape, num_head, head_dim_v, dtype=out_torch_dtype, device=device
        )
    else:
        _validate_tensor(out, "out", (*q_batch_seqlen_shape, num_head, head_dim_v), out_torch_dtype, device)

    if lse is None:
        lse = (
            torch.empty(lse_shape, dtype=torch.float32, device=device)
            if requires_grad or return_lse
            else None
        )
    elif lse is not None:
        _validate_tensor(lse, "lse", lse_shape, torch.float32, device)

    if window_size_left is not None and window_size_left < 0:
        window_size_left = None
    if window_size_right is not None and window_size_right < 0:
        window_size_right = None

    if mask_mod is None:
        if causal:
            window_size_right = 0
        if window_size_left is not None or window_size_right is not None:
            if window_size_left is None and window_size_right == 0:
                causal = True
                window_size_right = None
            else:
                causal = False
    else:
        causal = False

    _flash_attn_fwd._debug_last_impl = "torch_sdpa_fallback"
    return flash_attn_fwd_torch_fallback(
        q=q,
        k=k,
        v=v,
        cu_seqlens_q=cu_seqlens_q,
        cu_seqlens_k=cu_seqlens_k,
        seqused_q=seqused_q,
        seqused_k=seqused_k,
        page_table=page_table,
        softmax_scale=softmax_scale,
        causal=causal,
        window_size_left=window_size_left,
        window_size_right=window_size_right,
        score_mod=score_mod,
        mask_mod=mask_mod,
        block_sparse_tensors=block_sparse_tensors,
        aux_tensors=aux_tensors,
        learnable_sink=learnable_sink,
        out=out,
        lse=lse,
        k_scale=k_scale_val,
        v_scale=v_scale_val,
    )


_flash_attn_fwd.compile_cache = {}


def flash_attn_func(*args, **kwargs):
    return _load_sm90_interface().flash_attn_func(*args, **kwargs)


def flash_attn_varlen_func(*args, **kwargs):
    return _load_sm90_interface().flash_attn_varlen_func(*args, **kwargs)


def flash_attn_combine(*args, **kwargs):
    return _load_sm90_interface().flash_attn_combine(*args, **kwargs)


def __getattr__(name: str):
    if name in globals():
        return globals()[name]
    if name.startswith("__") and name.endswith("__"):
        raise AttributeError(name)
    return getattr(_load_sm90_interface(), name)


def __dir__():
    return sorted(set(globals().keys()) | set(dir(_load_sm90_interface())))


__all__ = [
    "_flash_attn_fwd",
    "flash_attn_func",
    "flash_attn_varlen_func",
    "flash_attn_combine",
]
