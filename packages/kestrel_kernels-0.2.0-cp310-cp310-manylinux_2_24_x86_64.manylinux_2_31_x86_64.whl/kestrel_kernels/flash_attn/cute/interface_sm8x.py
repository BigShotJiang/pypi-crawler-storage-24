"""SM8x flash-attn dispatch.

This module adds a custom prefill path for SM80/SM86/SM87 using FlashAttentionForwardSm80.
Decode fastpath (SM80/SM86/SM87/SM89) and all unsupported feature combinations continue to use
the existing interface_sm90 dispatcher.
"""

from __future__ import annotations

import math
import warnings
from functools import lru_cache
from importlib import import_module
from typing import Callable, Optional, Tuple

import cuda.bindings.driver as cuda
import cutlass
import cutlass.cute as cute
import torch
import tvm_ffi
from cutlass.cute.runtime import from_dlpack

from kestrel_kernels.arch import get_cuda_compute_capability
from kestrel_kernels.flash_attn.cute import utils
from kestrel_kernels.flash_attn.cute.mask_definitions import cute_prefix_lm_mask_730
from kestrel_kernels.precompile import get_cuda_arch, load_precompiled_module

_SM8X_PREFILL_SUPPORTED_SMS = {80, 86, 87}
_SM8X_PREFILL_SUPPORTED_HEAD_DIMS = {64, 72, 128}
_PREFIX_LM_730_HASH = getattr(cute_prefix_lm_mask_730, "__cute_hash__", None)

_KERNEL_CLASSES: dict[str, object] = {}


@lru_cache(maxsize=1)
def _load_sm90_interface():
    return import_module("kestrel_kernels.flash_attn.cute.interface_sm90")


def _get_kernel_class(name: str):
    cached = _KERNEL_CLASSES.get(name)
    if cached is not None:
        return cached
    try:
        if name == "FlashAttentionForwardSm80":
            from kestrel_kernels.flash_attn.cute.flash_fwd import FlashAttentionForwardSm80

            _KERNEL_CLASSES[name] = FlashAttentionForwardSm80
            return FlashAttentionForwardSm80
    except ImportError as exc:
        raise RuntimeError(
            f"JIT compilation requires source install. Kernel template '{name}' is not available."
        ) from exc
    raise ValueError(f"Unknown kernel class: {name}")


def _is_prefix_lm_730_hash(mask_mod_hash: int | bool) -> bool:
    return bool(mask_mod_hash and mask_mod_hash == _PREFIX_LM_730_HASH)


def _to_cute_tensor(
    t: torch.Tensor,
    *,
    assumed_align: int = 16,
    leading_dim: int = -1,
    fully_dynamic: bool = False,
):
    tensor = from_dlpack(t.detach(), assumed_align=assumed_align, enable_tvm_ffi=True)
    if fully_dynamic:
        return tensor.mark_layout_dynamic()
    if leading_dim == -1:
        leading_dim = t.ndim - 1
    return tensor.mark_layout_dynamic(leading_dim=leading_dim)


_TORCH2CUTE_DTYPE = {
    torch.float16: cutlass.Float16,
    torch.bfloat16: cutlass.BFloat16,
}
_CUTE_DTYPE_TO_NAME = {
    cutlass.BFloat16: "bf16",
    cutlass.Float16: "f16",
}


def _try_load_precompiled_sm80_forward(
    *,
    dtype: cutlass.Numeric,
    head_dim: int,
    causal: bool,
    mask_mod_hash: int | bool,
    m_block_size: int,
    n_block_size: int,
    num_threads: int,
) -> Optional[Callable]:
    if m_block_size != 128 or n_block_size != 128 or num_threads != 128:
        return None
    if head_dim not in _SM8X_PREFILL_SUPPORTED_HEAD_DIMS:
        return None
    dtype_name = _CUTE_DTYPE_TO_NAME.get(dtype)
    if dtype_name is None:
        return None

    mask_str = ""
    if mask_mod_hash:
        if _is_prefix_lm_730_hash(mask_mod_hash):
            mask_str = "_prefix_lm_730"
        else:
            return None

    causal_str = "_causal" if causal else ""
    arch = get_cuda_arch()
    filename = f"flash_attn_forward_sm80_{dtype_name}_hd{head_dim}{causal_str}{mask_str}_{arch}.so"
    mod = load_precompiled_module(filename)
    if mod is None:
        return None

    fn_name = filename.replace(".so", "")
    kernel_fn = getattr(mod, fn_name, None)
    if kernel_fn is None:
        return None

    # Precompiled TVM FFI kernels do not take stream as an explicit argument.
    def precompiled_wrapper(
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        out: torch.Tensor,
        lse: Optional[torch.Tensor],
        stream: cuda.CUstream,
        softmax_scale: float,
    ) -> None:
        del stream
        with tvm_ffi.use_torch_stream():
            kernel_fn(
                q,
                k,
                v,
                out,
                lse,
                softmax_scale,
                None,  # window_size_left
                None,  # window_size_right
                None,  # learnable_sink
                None,  # aux_tensors
            )

    return precompiled_wrapper


def _compile_sm80_forward_kernel(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    lse: Optional[torch.Tensor],
    dtype: cutlass.Numeric,
    head_dim: int,
    causal: bool,
    mask_mod: Optional[Callable],
    softmax_scale: float,
    m_block_size: int,
    n_block_size: int,
    num_threads: int,
    device_sm: int,
) -> Callable:
    FlashAttentionForwardSm80 = _get_kernel_class("FlashAttentionForwardSm80")
    fa_fwd = FlashAttentionForwardSm80(
        dtype=dtype,
        head_dim=head_dim,
        head_dim_v=head_dim,
        qhead_per_kvhead=1,
        is_causal=causal,
        is_local=False,
        pack_gqa=False,
        tile_m=m_block_size,
        tile_n=n_block_size,
        num_stages=1,
        num_threads=num_threads,
        Q_in_regs=False,
        score_mod=None,
        mask_mod=mask_mod,
        has_aux_tensors=False,
    )
    fa_fwd.arch = device_sm
    current_stream = cuda.CUstream(torch.cuda.current_stream().cuda_stream)
    q_tensor, k_tensor, v_tensor, o_tensor = [
        _to_cute_tensor(t) for t in (q, k, v, out)
    ]
    lse_tensor = _to_cute_tensor(lse, assumed_align=4) if lse is not None else None
    return cute.compile(
        fa_fwd,
        q_tensor,
        k_tensor,
        v_tensor,
        o_tensor,
        lse_tensor,
        current_stream,
        cutlass.Float32(softmax_scale),
        options="--enable-tvm-ffi",
    )


def _run_sm80_forward_kernel(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    lse: Optional[torch.Tensor],
    softmax_scale: float,
    dtype: cutlass.Numeric,
    head_dim: int,
    causal: bool,
    mask_mod: Optional[Callable],
    mask_mod_hash: int | bool,
    m_block_size: int,
    n_block_size: int,
    num_threads: int,
    device_sm: int,
    compile_cache: dict[tuple[object, ...], Callable],
) -> None:
    compile_key = (
        dtype,
        head_dim,
        causal,
        mask_mod_hash,
        m_block_size,
        n_block_size,
        num_threads,
        device_sm,
    )
    kernel = compile_cache.get(compile_key)
    if kernel is None:
        kernel = _try_load_precompiled_sm80_forward(
            dtype=dtype,
            head_dim=head_dim,
            causal=causal,
            mask_mod_hash=mask_mod_hash,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
        )
    if kernel is None:
        warnings.warn(
            f"Flash Attention SM8x prefill kernel not precompiled (hd={head_dim}, "
            f"causal={causal}, mask={'yes' if mask_mod is not None else 'no'}). JIT compiling...",
            stacklevel=3,
        )
        kernel = _compile_sm80_forward_kernel(
            q=q,
            k=k,
            v=v,
            out=out,
            lse=lse,
            dtype=dtype,
            head_dim=head_dim,
            causal=causal,
            mask_mod=mask_mod,
            softmax_scale=softmax_scale,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            device_sm=device_sm,
        )
    compile_cache[compile_key] = kernel
    current_stream = cuda.CUstream(torch.cuda.current_stream().cuda_stream)
    kernel(q, k, v, out, lse, current_stream, softmax_scale)


def _to_sm80_prefill_kv_dtype(
    *,
    k: torch.Tensor,
    v: torch.Tensor,
    target_dtype: torch.dtype,
    k_scale: float,
    v_scale: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    if k.dtype == torch.float8_e4m3fn:
        k = k.to(dtype=target_dtype)
        if k_scale != 1.0:
            k = k * k_scale
    elif k.dtype != target_dtype:
        k = k.to(dtype=target_dtype)

    if v.dtype == torch.float8_e4m3fn:
        v = v.to(dtype=target_dtype)
        if v_scale != 1.0:
            v = v * v_scale
    elif v.dtype != target_dtype:
        v = v.to(dtype=target_dtype)

    return k, v


def _index_select_first_dim(t: torch.Tensor, idx: torch.Tensor) -> torch.Tensor:
    # Torch 2.4 on Jetson lacks float8 index_select CUDA kernels.
    if t.dtype == torch.float8_e4m3fn:
        return t.view(torch.uint8).index_select(0, idx).view(torch.float8_e4m3fn)
    return t.index_select(0, idx)


def _run_sm8x_prefill(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    lse: Optional[torch.Tensor],
    seqused_q: Optional[torch.Tensor],
    seqused_k: Optional[torch.Tensor],
    page_table: Optional[torch.Tensor],
    softmax_scale: float,
    causal: bool,
    mask_mod: Optional[Callable],
    mask_mod_hash: int | bool,
    k_scale: float,
    v_scale: float,
    m_block_size: int,
    n_block_size: int,
    num_threads: int,
    device_sm: int,
    compile_cache: dict[tuple[object, ...], Callable],
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    if q.ndim != 4:
        raise ValueError("SM8x prefill path expects q with shape [batch, seqlen_q, heads, head_dim]")
    batch_size, q_len, num_heads, head_dim = q.shape
    num_heads_kv = int(k.shape[-2])
    if num_heads_kv != num_heads:
        raise NotImplementedError("SM8x prefill path currently supports MHA only (num_heads == num_heads_kv)")
    if head_dim not in _SM8X_PREFILL_SUPPORTED_HEAD_DIMS:
        raise NotImplementedError(
            f"SM8x prefill supports head_dim in {_SM8X_PREFILL_SUPPORTED_HEAD_DIMS}; got {head_dim}"
        )
    if q.dtype not in _TORCH2CUTE_DTYPE:
        raise NotImplementedError("SM8x prefill supports q dtype fp16/bf16 only")

    dtype = _TORCH2CUTE_DTYPE[q.dtype]
    if seqused_q is not None:
        if seqused_q.ndim != 1 or seqused_q.shape[0] != batch_size:
            raise ValueError("seqused_q must be shape [batch] for SM8x prefill")
        if bool((seqused_q < 0).any()) or bool((seqused_q > q_len).any()):
            raise ValueError("seqused_q entries must be in [0, seqlen_q]")

    if page_table is not None:
        if page_table.ndim != 2 or page_table.shape[0] != batch_size:
            raise ValueError("page_table must have shape [batch, max_pages_per_seq] for SM8x prefill")
        if page_table.dtype != torch.int32:
            raise ValueError("page_table must be int32")
        if seqused_k is not None:
            if seqused_k.ndim != 1 or seqused_k.shape[0] != batch_size:
                raise ValueError("seqused_k must have shape [batch]")
    else:
        if k.ndim != 4 or v.ndim != 4:
            raise ValueError("dense SM8x prefill expects k/v shape [batch, seqlen_k, heads_kv, head_dim]")
        if k.shape[0] != batch_size or v.shape[0] != batch_size:
            raise ValueError("dense SM8x prefill expects k/v batch dimension to match q")
        if seqused_k is not None:
            if seqused_k.ndim != 1 or seqused_k.shape[0] != batch_size:
                raise ValueError("seqused_k must have shape [batch]")
            max_kv = int(k.shape[1])
            if bool((seqused_k < 0).any()) or bool((seqused_k > max_kv).any()):
                raise ValueError("seqused_k entries must be in [0, seqlen_k]")

    # Fast batched path for dense fixed-length prefill.
    if page_table is None and seqused_q is None and seqused_k is None:
        k_use, v_use = _to_sm80_prefill_kv_dtype(
            k=k,
            v=v,
            target_dtype=q.dtype,
            k_scale=k_scale,
            v_scale=v_scale,
        )
        _run_sm80_forward_kernel(
            q=q,
            k=k_use,
            v=v_use,
            out=out,
            lse=lse,
            softmax_scale=softmax_scale,
            dtype=dtype,
            head_dim=head_dim,
            causal=causal,
            mask_mod=mask_mod,
            mask_mod_hash=mask_mod_hash,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            device_sm=device_sm,
            compile_cache=compile_cache,
        )
        return out, lse

    out.zero_()
    if lse is not None:
        lse.zero_()

    if page_table is not None:
        total_pages = int(k.shape[0])
        page_size = int(k.shape[1])
        page_table_long = page_table.to(dtype=torch.long)
    else:
        total_pages = 0
        page_size = 0
        page_table_long = None

    for row in range(batch_size):
        q_len_row = int(seqused_q[row].item()) if seqused_q is not None else int(q_len)
        if q_len_row <= 0:
            continue

        q_row = q[row : row + 1, :q_len_row].contiguous()

        if page_table is None:
            kv_len_row = int(seqused_k[row].item()) if seqused_k is not None else int(k.shape[1])
            if kv_len_row <= 0:
                continue
            k_row = k[row : row + 1, :kv_len_row].contiguous()
            v_row = v[row : row + 1, :kv_len_row].contiguous()
        else:
            page_row = page_table_long[row]
            valid_pages = (page_row >= 0) & (page_row < total_pages)
            available_pages = int(valid_pages.sum().item())
            if available_pages <= 0:
                continue
            available_kv_len = available_pages * page_size
            if seqused_k is not None:
                kv_len_row = min(int(seqused_k[row].item()), available_kv_len)
            else:
                kv_len_row = available_kv_len
            if kv_len_row <= 0:
                continue
            pages_needed = min((kv_len_row + page_size - 1) // page_size, available_pages)
            page_ids = page_row[valid_pages][:pages_needed]
            k_pages = _index_select_first_dim(k, page_ids)
            v_pages = _index_select_first_dim(v, page_ids)
            k_row = k_pages.reshape(pages_needed * page_size, num_heads_kv, head_dim)[:kv_len_row]
            v_row = v_pages.reshape(pages_needed * page_size, num_heads_kv, head_dim)[:kv_len_row]
            k_row = k_row.unsqueeze(0).contiguous()
            v_row = v_row.unsqueeze(0).contiguous()

        k_row, v_row = _to_sm80_prefill_kv_dtype(
            k=k_row,
            v=v_row,
            target_dtype=q.dtype,
            k_scale=k_scale,
            v_scale=v_scale,
        )
        out_row = out[row : row + 1, :q_len_row]
        lse_row = lse[row : row + 1, :, :q_len_row] if lse is not None else None
        _run_sm80_forward_kernel(
            q=q_row,
            k=k_row,
            v=v_row,
            out=out_row,
            lse=lse_row,
            softmax_scale=softmax_scale,
            dtype=dtype,
            head_dim=head_dim,
            causal=causal,
            mask_mod=mask_mod,
            mask_mod_hash=mask_mod_hash,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            device_sm=device_sm,
            compile_cache=compile_cache,
        )

    return out, lse


def _delegate_to_sm90(**kwargs) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    sm90 = _load_sm90_interface()
    sm90_impl = getattr(sm90, "_flash_attn_fwd_sm90", sm90._flash_attn_fwd)
    out, lse = sm90_impl(**kwargs)
    _flash_attn_fwd_sm8x._debug_last_impl = getattr(
        sm90_impl,
        "_debug_last_impl",
        getattr(sm90._flash_attn_fwd, "_debug_last_impl", "torch_sdpa_fallback"),
    )
    return out, lse


def _flash_attn_fwd_sm8x(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    softcap: Optional[float] = None,
    window_size_left: Optional[int] = None,
    window_size_right: Optional[int] = None,
    learnable_sink: Optional[torch.Tensor] = None,
    m_block_size: int = 128,
    n_block_size: int = 128,
    num_threads: int = 384,
    num_splits: int = 1,
    pack_gqa: Optional[bool] = None,
    compute_capability: Optional[tuple[int, int]] = None,
    score_mod: Optional[Callable] = None,
    mask_mod: Optional[Callable] = None,
    block_sparse_tensors: Optional[object] = None,
    return_lse: bool = False,
    out: Optional[torch.Tensor] = None,
    lse: Optional[torch.Tensor] = None,
    aux_tensors: Optional[list[torch.Tensor]] = None,
    paged_kv_non_tma: Optional[bool] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    if compute_capability is None:
        cc_major, cc_minor = get_cuda_compute_capability()
    else:
        cc_major, cc_minor = int(compute_capability[0]), int(compute_capability[1])
    device_sm = int(cc_major) * 10 + int(cc_minor)

    if cc_major != 8:
        return _delegate_to_sm90(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            softcap=softcap,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            learnable_sink=learnable_sink,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            compute_capability=(cc_major, cc_minor),
            score_mod=score_mod,
            mask_mod=mask_mod,
            block_sparse_tensors=block_sparse_tensors,
            return_lse=return_lse,
            out=out,
            lse=lse,
            aux_tensors=aux_tensors,
            paged_kv_non_tma=paged_kv_non_tma,
            k_scale=k_scale,
            v_scale=v_scale,
        )

    if q.ndim < 2:
        return _delegate_to_sm90(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            softcap=softcap,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            learnable_sink=learnable_sink,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            compute_capability=(cc_major, cc_minor),
            score_mod=score_mod,
            mask_mod=mask_mod,
            block_sparse_tensors=block_sparse_tensors,
            return_lse=return_lse,
            out=out,
            lse=lse,
            aux_tensors=aux_tensors,
            paged_kv_non_tma=paged_kv_non_tma,
            k_scale=k_scale,
            v_scale=v_scale,
        )

    q = q.contiguous() if q.stride(-1) != 1 else q
    k = k.contiguous() if k.stride(-1) != 1 else k
    v = v.contiguous() if v.stride(-1) != 1 else v

    if q.ndim != 4 or k.ndim != 4 or v.ndim != 4:
        return _delegate_to_sm90(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            softcap=softcap,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            learnable_sink=learnable_sink,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            compute_capability=(cc_major, cc_minor),
            score_mod=score_mod,
            mask_mod=mask_mod,
            block_sparse_tensors=block_sparse_tensors,
            return_lse=return_lse,
            out=out,
            lse=lse,
            aux_tensors=aux_tensors,
            paged_kv_non_tma=paged_kv_non_tma,
            k_scale=k_scale,
            v_scale=v_scale,
        )

    batch_size, q_len, num_q_heads, _ = q.shape
    head_dim_v = int(v.shape[-1])
    expected_out_shape = (batch_size, q_len, num_q_heads, head_dim_v)
    if out is None:
        out = torch.empty(expected_out_shape, dtype=q.dtype, device=q.device)
    elif out.shape != expected_out_shape or out.dtype != q.dtype or out.device != q.device:
        raise ValueError(
            f"out must have shape={expected_out_shape}, dtype={q.dtype}, device={q.device} "
            f"(got shape={tuple(out.shape)}, dtype={out.dtype}, device={out.device})"
        )

    expected_lse_shape = (batch_size, num_q_heads, q_len)
    if lse is None:
        if return_lse:
            lse = torch.empty(expected_lse_shape, dtype=torch.float32, device=q.device)
    elif (
        lse.shape != expected_lse_shape
        or lse.dtype != torch.float32
        or lse.device != q.device
    ):
        raise ValueError(
            f"lse must have shape={expected_lse_shape}, dtype=float32, device={q.device} "
            f"(got shape={tuple(lse.shape)}, dtype={lse.dtype}, device={lse.device})"
        )

    # Keep existing decode fastpath behavior (SM80/SM86/SM87/SM89) in interface_sm90.
    page_size = int(k.shape[1]) if (page_table is not None and k.ndim >= 2) else None
    seqlen_q = int(q.shape[1]) if q.ndim >= 2 else 0
    use_sm_decode_fastpath = (
        device_sm in (80, 86, 87, 89)
        and page_table is not None
        and page_size == 1
        and cu_seqlens_q is None
        and cu_seqlens_k is None
        and seqused_q is None
        and seqused_k is not None
        and seqlen_q == 1
        and q.ndim == 4
        and k.ndim == 4
        and v.ndim == 4
        and int(v.shape[-1]) == int(q.shape[-1])
        and score_mod is None
        and mask_mod is None
        and block_sparse_tensors is None
        and aux_tensors is None
        and learnable_sink is None
        and num_splits == 1
        and int(q.shape[-1]) in (64, 128)
    )
    if use_sm_decode_fastpath:
        return _delegate_to_sm90(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            softcap=softcap,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            learnable_sink=learnable_sink,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            compute_capability=(cc_major, cc_minor),
            score_mod=score_mod,
            mask_mod=mask_mod,
            block_sparse_tensors=block_sparse_tensors,
            return_lse=return_lse,
            out=out,
            lse=lse,
            aux_tensors=aux_tensors,
            paged_kv_non_tma=paged_kv_non_tma,
            k_scale=k_scale,
            v_scale=v_scale,
        )

    mask_mod_hash = utils.hash_callable(mask_mod) if mask_mod is not None else False
    supports_sm8x_prefill = (
        device_sm in _SM8X_PREFILL_SUPPORTED_SMS
        and q.ndim == 4
        and (k.ndim == 4 and v.ndim == 4)
        and cu_seqlens_q is None
        and cu_seqlens_k is None
        and score_mod is None
        and softcap is None
        and block_sparse_tensors is None
        and aux_tensors is None
        and learnable_sink is None
        and num_splits == 1
        and (window_size_left is None or window_size_left < 0)
        and (window_size_right is None or window_size_right < 0)
        and (mask_mod is None or _is_prefix_lm_730_hash(mask_mod_hash))
    )
    if not supports_sm8x_prefill:
        return _delegate_to_sm90(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            softcap=softcap,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            learnable_sink=learnable_sink,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            compute_capability=(cc_major, cc_minor),
            score_mod=score_mod,
            mask_mod=mask_mod,
            block_sparse_tensors=block_sparse_tensors,
            return_lse=return_lse,
            out=out,
            lse=lse,
            aux_tensors=aux_tensors,
            paged_kv_non_tma=paged_kv_non_tma,
            k_scale=k_scale,
            v_scale=v_scale,
        )

    if softmax_scale is None:
        softmax_scale = 1.0 / math.sqrt(int(q.shape[-1]))

    # SM80 kernel default geometry.
    sm80_m_block = 128
    sm80_n_block = 128
    sm80_num_threads = 128
    try:
        result = _run_sm8x_prefill(
            q=q,
            k=k,
            v=v,
            out=out,
            lse=lse,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=float(softmax_scale),
            causal=causal,
            mask_mod=mask_mod,
            mask_mod_hash=mask_mod_hash,
            k_scale=1.0 if k_scale is None else float(k_scale),
            v_scale=1.0 if v_scale is None else float(v_scale),
            m_block_size=sm80_m_block,
            n_block_size=sm80_n_block,
            num_threads=sm80_num_threads,
            device_sm=device_sm,
            compile_cache=_flash_attn_fwd_sm8x.compile_cache,
        )
    except (NotImplementedError, RuntimeError, ValueError):
        return _delegate_to_sm90(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            softcap=softcap,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            learnable_sink=learnable_sink,
            m_block_size=m_block_size,
            n_block_size=n_block_size,
            num_threads=num_threads,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            compute_capability=(cc_major, cc_minor),
            score_mod=score_mod,
            mask_mod=mask_mod,
            block_sparse_tensors=block_sparse_tensors,
            return_lse=return_lse,
            out=out,
            lse=lse,
            aux_tensors=aux_tensors,
            paged_kv_non_tma=paged_kv_non_tma,
            k_scale=k_scale,
            v_scale=v_scale,
        )

    if device_sm == 87:
        _flash_attn_fwd_sm8x._debug_last_impl = "sm87_prefill"
    elif device_sm == 86:
        _flash_attn_fwd_sm8x._debug_last_impl = "sm86_prefill"
    else:
        _flash_attn_fwd_sm8x._debug_last_impl = "sm80_prefill"
    return result


_flash_attn_fwd_sm8x.compile_cache = {}
