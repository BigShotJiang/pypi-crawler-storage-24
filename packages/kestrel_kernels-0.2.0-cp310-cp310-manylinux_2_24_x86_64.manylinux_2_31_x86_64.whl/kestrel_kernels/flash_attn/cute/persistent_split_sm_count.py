"""SM90 persistent split-fused device mapping.

Maps normalized CUDA device-name keys to the SM count used by the
persistent split-fused decode kernel tuning.
"""

from __future__ import annotations

from kestrel_kernels.arch import normalize_gpu_name_key


# Keep this explicit and conservative. Add entries only when validated.
SM90_PERSISTENT_SPLIT_SM_COUNT_BY_DEVICE_KEY: dict[str, int] = {
    "nvidia_h100_80gb_hbm3": 132,
}


def get_sm90_persistent_split_sm_count_for_gpu_key(gpu_key: str | None) -> int | None:
    """Return SM count for a normalized GPU key, or None if unsupported."""
    if not gpu_key:
        return None
    key = normalize_gpu_name_key(gpu_key)
    return SM90_PERSISTENT_SPLIT_SM_COUNT_BY_DEVICE_KEY.get(key)


def get_known_sm90_persistent_split_sm_counts() -> tuple[int, ...]:
    """Return sorted unique SM counts from the known device mapping."""
    return tuple(sorted(set(SM90_PERSISTENT_SPLIT_SM_COUNT_BY_DEVICE_KEY.values())))


__all__ = [
    "SM90_PERSISTENT_SPLIT_SM_COUNT_BY_DEVICE_KEY",
    "get_known_sm90_persistent_split_sm_counts",
    "get_sm90_persistent_split_sm_count_for_gpu_key",
]
