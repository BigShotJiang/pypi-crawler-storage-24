"""Torch SDPA fallback for flash attention on non-SM90 devices."""

from __future__ import annotations

import math
from functools import lru_cache
from typing import Callable, Optional, Tuple

import torch
import torch.nn.functional as F

from kestrel_kernels.fallback import warn_fallback_once
from kestrel_kernels.flash_attn.cute.mask_definitions import cute_prefix_lm_mask_730


_PREFIX_LM_730_HASH = getattr(cute_prefix_lm_mask_730, "__cute_hash__", None)


def _is_prefix_lm_730(mask_mod: Optional[Callable]) -> bool:
    if mask_mod is None:
        return False
    if mask_mod is cute_prefix_lm_mask_730:
        return True
    mask_hash = getattr(mask_mod, "__cute_hash__", None)
    return mask_hash is not None and mask_hash == _PREFIX_LM_730_HASH


def _prepare_kv_for_sdpa(
    *,
    k: torch.Tensor,
    v: torch.Tensor,
    target_dtype: torch.dtype,
    k_scale: float,
    v_scale: float,
) -> tuple[torch.Tensor, torch.Tensor, float, float]:
    q_scale = 1.0
    out_scale = 1.0

    if k.dtype == torch.float8_e4m3fn:
        k = k.to(target_dtype)
        q_scale = float(k_scale)
    elif k.dtype != target_dtype:
        k = k.to(target_dtype)

    if v.dtype == torch.float8_e4m3fn:
        v = v.to(target_dtype)
        out_scale = float(v_scale)
    elif v.dtype != target_dtype:
        v = v.to(target_dtype)

    return k, v, q_scale, out_scale


def _index_select_first_dim(t: torch.Tensor, idx: torch.Tensor) -> torch.Tensor:
    # Torch 2.4 on Jetson lacks float8 index_select CUDA kernels.
    if t.dtype == torch.float8_e4m3fn:
        return t.view(torch.uint8).index_select(0, idx).view(torch.float8_e4m3fn)
    return t.index_select(0, idx)


def _build_additive_attn_mask(
    *,
    q_len: int,
    kv_len: int,
    causal: bool,
    prefix_lm_730: bool,
    device: torch.device,
) -> Optional[torch.Tensor]:
    if not causal and not prefix_lm_730:
        return None
    if q_len == 1:
        # For the decode-style single-query case, q_abs_idx = kv_len - 1, so causal
        # (and prefix_lm_730 OR causal) admits all keys; no explicit mask is needed.
        return None

    kv_idx = torch.arange(kv_len, device=device, dtype=torch.int64)
    q_abs_idx = torch.arange(q_len, device=device, dtype=torch.int64) + max(kv_len - q_len, 0)

    causal_allowed = kv_idx.unsqueeze(0) <= q_abs_idx.unsqueeze(1)
    allowed = causal_allowed
    if prefix_lm_730:
        both_prefix = (q_abs_idx.unsqueeze(1) < 730) & (kv_idx.unsqueeze(0) < 730)
        allowed = both_prefix | causal_allowed

    attn_mask = torch.zeros((q_len, kv_len), dtype=torch.float32, device=device)
    attn_mask.masked_fill_(~allowed, float("-inf"))
    return attn_mask


def _sdpa(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    attn_mask: Optional[torch.Tensor],
    softmax_scale: Optional[float],
) -> torch.Tensor:
    if attn_mask is not None and attn_mask.dtype != q.dtype:
        attn_mask = attn_mask.to(q.dtype)
    kwargs = {
        "attn_mask": attn_mask,
        "dropout_p": 0.0,
        "is_causal": False,
    }
    if softmax_scale is None:
        return F.scaled_dot_product_attention(q, k, v, **kwargs)
    try:
        return F.scaled_dot_product_attention(q, k, v, scale=float(softmax_scale), **kwargs)
    except TypeError:
        default_scale = 1.0 / math.sqrt(q.shape[-1])
        q_scaled = q if math.isclose(float(softmax_scale), default_scale) else q * (float(softmax_scale) / default_scale)
        return F.scaled_dot_product_attention(q_scaled, k, v, **kwargs)


def _attention_forward(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    q_len: int,
    kv_len: int,
    causal: bool,
    prefix_lm_730: bool,
    softmax_scale: Optional[float],
) -> torch.Tensor:
    attn_mask = _build_additive_attn_mask(
        q_len=q_len,
        kv_len=kv_len,
        causal=causal,
        prefix_lm_730=prefix_lm_730,
        device=q.device,
    )
    return (
        _sdpa(
            q=q,
            k=k,
            v=v,
            attn_mask=attn_mask,
            softmax_scale=softmax_scale,
        )
    )


@lru_cache(maxsize=1)
def _get_flex_attention_symbols():
    try:
        from torch.nn.attention.flex_attention import BlockMask
        from torch.nn.attention.flex_attention import flex_attention
    except Exception as exc:
        raise RuntimeError(
            "paged decode flex fallback requires torch.nn.attention.flex_attention "
            "in the active torch build"
        ) from exc
    return BlockMask, flex_attention


@lru_cache(maxsize=1)
def _get_graph_safe_flex_attention():
    _, flex_attention = _get_flex_attention_symbols()
    try:
        return torch.compile(flex_attention, fullgraph=True)  # type: ignore[arg-type]
    except Exception as exc:
        raise RuntimeError(
            "paged decode flex fallback requires torch.compile(flex_attention, fullgraph=True)"
        ) from exc


def _build_paged_decode_block_mask(
    *,
    page_table: torch.Tensor,
    seqused_k: Optional[torch.Tensor],
    total_pages: int,
    block_size: int,
) -> object:
    BlockMask, _ = _get_flex_attention_symbols()
    if page_table.ndim != 2:
        raise ValueError("paged decode expects page_table with shape [batch, max_pages_per_seq]")
    if page_table.dtype != torch.int32:
        raise ValueError("paged decode expects page_table dtype int32")

    if block_size <= 0:
        raise ValueError("block_size must be positive")

    batch_size, max_pages_per_seq = page_table.shape
    valid_pages = (page_table >= 0) & (page_table < total_pages)
    if seqused_k is not None:
        if seqused_k.ndim != 1 or seqused_k.shape[0] != batch_size:
            raise ValueError("seqused_k must be shape [batch] for paged decode")
        seqused_i32 = seqused_k.to(dtype=torch.int32)
        logical_idx = torch.arange(max_pages_per_seq, device=page_table.device, dtype=torch.int32)
        token_valid = valid_pages & (logical_idx.unsqueeze(0) < seqused_i32.unsqueeze(1))
    else:
        token_valid = valid_pages

    physical_idx = torch.where(token_valid, page_table, torch.zeros_like(page_table))

    # Build physical->logical lookup used to filter inactive tokens within selected blocks.
    logical_idx = torch.arange(max_pages_per_seq, device=page_table.device, dtype=torch.int32)
    logical_idx = logical_idx.unsqueeze(0).expand(batch_size, -1)
    src_logical = torch.where(token_valid, logical_idx, torch.full_like(logical_idx, -1))
    physical_to_logical = torch.full(
        (batch_size, total_pages),
        -1,
        dtype=torch.int32,
        device=page_table.device,
    )
    physical_to_logical.scatter_reduce_(
        1,
        physical_idx,
        src_logical,
        reduce="amax",
        include_self=True,
    )

    block_count = (total_pages + block_size - 1) // block_size
    physical_block_ids = torch.div(physical_idx, block_size, rounding_mode="floor")
    block_present = torch.zeros(
        (batch_size, block_count),
        dtype=torch.int32,
        device=page_table.device,
    )
    block_present.scatter_reduce_(
        1,
        physical_block_ids,
        token_valid.to(torch.int32),
        reduce="amax",
        include_self=True,
    )

    all_blocks = torch.arange(block_count, device=page_table.device, dtype=torch.int32)
    all_blocks = all_blocks.view(1, block_count).expand(batch_size, -1)
    sort_keys = torch.where(block_present > 0, all_blocks, all_blocks + block_count)
    packed_blocks = torch.sort(sort_keys, dim=1).values
    packed_blocks = torch.where(
        packed_blocks < block_count, packed_blocks, torch.zeros_like(packed_blocks)
    )
    kv_num_blocks = block_present.sum(dim=1, dtype=torch.int32).view(batch_size, 1, 1).contiguous()
    kv_indices = packed_blocks.view(batch_size, 1, 1, block_count).contiguous()

    def decode_mask_mod(
        b: torch.Tensor,
        _h: torch.Tensor,
        _q_idx: torch.Tensor,
        kv_idx: torch.Tensor,
    ) -> torch.Tensor:
        return physical_to_logical[b, kv_idx] >= 0

    seq_lengths = (1, total_pages)
    return BlockMask.from_kv_blocks(
        kv_num_blocks=kv_num_blocks,
        kv_indices=kv_indices,
        BLOCK_SIZE=block_size,
        seq_lengths=seq_lengths,
        mask_mod=decode_mask_mod,
    )


def _paged_decode_flex_attention(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    page_table: torch.Tensor,
    seqused_k: Optional[torch.Tensor],
    softmax_scale: Optional[float],
) -> torch.Tensor:
    graph_safe_flex = _get_graph_safe_flex_attention()
    if k.shape[1] != 1 or v.shape[1] != 1:
        raise NotImplementedError("paged decode flex fallback currently requires page_size == 1")

    total_pages = int(k.shape[0])
    block_size = 128
    k_phys = k[:, 0, :, :].permute(1, 0, 2).unsqueeze(0)
    v_phys = v[:, 0, :, :].permute(1, 0, 2).unsqueeze(0)
    k_phys = k_phys.expand(q.shape[0], -1, -1, -1)
    v_phys = v_phys.expand(q.shape[0], -1, -1, -1)

    block_mask = _build_paged_decode_block_mask(
        page_table=page_table,
        seqused_k=seqused_k,
        total_pages=total_pages,
        block_size=block_size,
    )
    return graph_safe_flex(
        q,
        k_phys,
        v_phys,
        block_mask=block_mask,
        scale=softmax_scale,
    )


def flash_attn_fwd_torch_fallback(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    seqused_q: Optional[torch.Tensor],
    seqused_k: Optional[torch.Tensor],
    page_table: Optional[torch.Tensor],
    softmax_scale: Optional[float],
    causal: bool,
    window_size_left: Optional[int],
    window_size_right: Optional[int],
    score_mod: Optional[Callable],
    mask_mod: Optional[Callable],
    block_sparse_tensors: Optional[object],
    aux_tensors: Optional[list[torch.Tensor]],
    learnable_sink: Optional[torch.Tensor],
    out: torch.Tensor,
    lse: Optional[torch.Tensor],
    k_scale: float,
    v_scale: float,
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    if q.device.type != "cuda":
        raise RuntimeError("flash_attn SDPA fallback expects CUDA tensors")

    if score_mod is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support score_mod")
    if block_sparse_tensors is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support block sparsity")
    if aux_tensors is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support aux_tensors")
    if learnable_sink is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support learnable_sink")
    if lse is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support lse outputs")
    if window_size_left is not None or window_size_right is not None:
        raise NotImplementedError("flash_attn SDPA fallback does not support sliding-window attention")

    prefix_lm_730 = _is_prefix_lm_730(mask_mod)
    if mask_mod is not None and not prefix_lm_730:
        raise NotImplementedError("flash_attn SDPA fallback only supports cute_prefix_lm_mask_730")

    major, minor = torch.cuda.get_device_capability(q.device)
    variant = "paged" if page_table is not None else "dense"
    mask_kind = "prefix_lm_730" if prefix_lm_730 else ("causal" if causal else "none")
    warn_fallback_once(
        f"flash_attn_fwd_torch_attention_{variant}_{mask_kind}",
        "kestrel-kernels: falling back to torch attention for flash_attn_fwd "
        f"(arch=sm{major}{minor}, variant={variant}, mask={mask_kind}).",
    )

    if cu_seqlens_q is not None or cu_seqlens_k is not None:
        raise NotImplementedError(
            "kestrel-kernels fallback only supports fixed-length dense or paged attention paths used by Kestrel"
        )

    if q.dim() != 4:
        raise ValueError("fixed-length mode expects q with shape [batch, seqlen_q, heads, head_dim]")

    batch_size, q_len, num_q_heads, _head_dim = q.shape
    if seqused_q is not None:
        if seqused_q.ndim != 1 or seqused_q.shape[0] != batch_size:
            raise ValueError("seqused_q must be shape [batch] in fallback")
        q_lens = seqused_q.to(dtype=torch.int64)
        if bool((q_lens < 0).any()) or bool((q_lens > q_len).any()):
            raise ValueError("seqused_q entries must be in [0, q_len]")
    else:
        q_lens = None
    out_result = out

    if page_table is None:
        if k.dim() != 4 or v.dim() != 4:
            raise ValueError("dense mode expects k/v with shape [batch, seqlen_k, heads_kv, head_dim]")
        kv_len = int(k.shape[1])

        k_sdpa, v_sdpa, q_scale, out_scale = _prepare_kv_for_sdpa(
            k=k,
            v=v,
            target_dtype=q.dtype,
            k_scale=k_scale,
            v_scale=v_scale,
        )
        k_sdpa = k_sdpa.permute(0, 2, 1, 3)
        v_sdpa = v_sdpa.permute(0, 2, 1, 3)
        if q_lens is None:
            q_sdpa = q.permute(0, 2, 1, 3)
            q_sdpa_scaled = q_sdpa if q_scale == 1.0 else q_sdpa.mul(q_scale)

            out_sdpa = _attention_forward(
                q=q_sdpa_scaled,
                k=k_sdpa,
                v=v_sdpa,
                q_len=q_len,
                kv_len=kv_len,
                causal=causal,
                prefix_lm_730=prefix_lm_730,
                softmax_scale=softmax_scale,
            )
            if out_scale != 1.0:
                out_sdpa = out_sdpa.mul(out_scale)
            out_result.copy_(out_sdpa.permute(0, 2, 1, 3))
        else:
            out_result.zero_()
            q_sdpa_all = q.permute(0, 2, 1, 3)
            for b in range(batch_size):
                q_len_b = int(q_lens[b].item())
                if q_len_b <= 0:
                    continue
                q_b = q_sdpa_all[b : b + 1, :, :q_len_b, :]
                q_b_scaled = q_b if q_scale == 1.0 else q_b.mul(q_scale)
                out_b = _attention_forward(
                    q=q_b_scaled,
                    k=k_sdpa[b : b + 1],
                    v=v_sdpa[b : b + 1],
                    q_len=q_len_b,
                    kv_len=kv_len,
                    causal=causal,
                    prefix_lm_730=prefix_lm_730,
                    softmax_scale=softmax_scale,
                )
                if out_scale != 1.0:
                    out_b = out_b.mul(out_scale)
                out_result[b : b + 1, :q_len_b].copy_(out_b.permute(0, 2, 1, 3))
    else:
        if k.dim() != 4 or v.dim() != 4:
            raise ValueError("paged mode expects k/v with shape [num_pages, page_size, heads_kv, head_dim]")
        page_size = int(k.shape[1])
        num_kv_heads = int(k.shape[2])
        head_dim = int(k.shape[3])
        total_pages = int(k.shape[0])

        # Prefill path: compact each request to its active KV length before attention.
        # This is not used during decode graph capture (q_len == 1 there), so it can
        # use request-local lengths without violating graph-capture constraints.
        if q_len > 1 or q_lens is not None:
            if q_lens is not None:
                out_result.zero_()
            page_ids_raw = page_table.to(dtype=torch.long)

            for b in range(batch_size):
                q_len_b = int(q_lens[b].item()) if q_lens is not None else q_len
                if q_len_b <= 0:
                    continue
                q_b = q[b : b + 1, :q_len_b].permute(0, 2, 1, 3)
                page_row = page_ids_raw[b]
                valid_pages = (page_row >= 0) & (page_row < total_pages)
                available_pages = int(valid_pages.sum().item())
                available_kv_len = available_pages * page_size
                if available_kv_len <= 0:
                    out_result[b : b + 1].zero_()
                    continue

                if seqused_k is not None:
                    kv_len = int(min(int(seqused_k[b].item()), available_kv_len))
                else:
                    kv_len = available_kv_len

                if kv_len <= 0:
                    out_result[b : b + 1].zero_()
                    continue

                pages_needed = min((kv_len + page_size - 1) // page_size, available_pages)
                page_ids = page_row[valid_pages][:pages_needed]

                k_pages = _index_select_first_dim(k, page_ids)
                v_pages = _index_select_first_dim(v, page_ids)
                k_seq = k_pages.reshape(pages_needed * page_size, num_kv_heads, head_dim)[:kv_len]
                v_seq = v_pages.reshape(pages_needed * page_size, num_kv_heads, head_dim)[:kv_len]

                k_seq, v_seq, q_scale, out_scale = _prepare_kv_for_sdpa(
                    k=k_seq,
                    v=v_seq,
                    target_dtype=q.dtype,
                    k_scale=k_scale,
                    v_scale=v_scale,
                )
                k_b = k_seq.permute(1, 0, 2).unsqueeze(0)
                v_b = v_seq.permute(1, 0, 2).unsqueeze(0)
                q_b_scaled = q_b if q_scale == 1.0 else q_b.mul(q_scale)

                out_b = _attention_forward(
                    q=q_b_scaled,
                    k=k_b,
                    v=v_b,
                    q_len=q_len_b,
                    kv_len=kv_len,
                    causal=causal,
                    prefix_lm_730=prefix_lm_730,
                    softmax_scale=softmax_scale,
                )
                if out_scale != 1.0:
                    out_b = out_b.mul(out_scale)
                out_result[b : b + 1, :q_len_b].copy_(out_b.permute(0, 2, 1, 3))

            return out, None

        # Decode path: use flex_attention with paged block mask to avoid
        # materializing dense gathered KV tensors.
        q_sdpa_all = q.permute(0, 2, 1, 3)
        k_seq, v_seq, q_scale, out_scale = _prepare_kv_for_sdpa(
            k=k,
            v=v,
            target_dtype=q.dtype,
            k_scale=k_scale,
            v_scale=v_scale,
        )
        q_sdpa_scaled = q_sdpa_all if q_scale == 1.0 else q_sdpa_all.mul(q_scale)
        out_sdpa = _paged_decode_flex_attention(
            q=q_sdpa_scaled,
            k=k_seq,
            v=v_seq,
            page_table=page_table,
            seqused_k=seqused_k,
            softmax_scale=softmax_scale,
        )

        if out_scale != 1.0:
            out_sdpa = out_sdpa.mul(out_scale)
        out_result.copy_(out_sdpa.permute(0, 2, 1, 3))

    return out, None
