"""Torch fallback for GELU residual kernel."""

from __future__ import annotations

import torch
import torch.nn.functional as F


def gelu_residual_torch_into(*, out: torch.Tensor, inp: torch.Tensor) -> None:
    hidden = int(out.shape[-1])
    x = inp[..., :hidden]
    y = inp[..., hidden:]
    out.copy_(F.gelu(x, approximate="none") * (y + 1))


__all__ = ["gelu_residual_torch_into"]
