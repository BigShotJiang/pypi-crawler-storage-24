"""Stable runtime API surface for Kestrel kernels.

This module provides a single place for kernel entrypoints used by Kestrel.
Callers should depend on this API rather than deep internal module paths.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Callable

import torch


_PREFIX_LM_730_HASH = (
    "kestrel_kernels.flash_attn.cute.mask_definitions.cute_prefix_lm_mask_730"
)


@dataclass(frozen=True)
class AttentionRuntime:
    flash_attn_fwd: Callable[..., Any]
    prefix_lm_mask_730: Callable[..., Any]


@dataclass(frozen=True)
class MoeRuntime:
    fp8_quant_cute: Callable[..., Any]
    gelu_residual_cute: Callable[..., Any]
    moe_sum: Callable[..., Any]
    has_cute_moe_config: Callable[..., Any]
    get_cute_moe_block_m: Callable[..., Any]
    get_cute_moe_config: Callable[..., Any]
    invoke_cute_moe_down: Callable[..., Any]
    invoke_cute_moe_down_fp8: Callable[..., Any]
    invoke_cute_moe_up: Callable[..., Any]
    invoke_cute_moe_up_fp8: Callable[..., Any]
    moe_align_block_size: Callable[..., Any]
    moe_lora_align_block_size: Callable[..., Any]
    dtype_to_triton: Callable[..., Any]
    invoke_fused_moe_kernel_triton: Callable[..., Any]
    invoke_fused_moe_kernel_triton_fp8: Callable[..., Any]


@dataclass(frozen=True)
class CacheRuntime:
    reshape_and_cache_flash: Callable[..., Any]


@dataclass(frozen=True)
class RotaryRuntime:
    rotary_embedding: Callable[..., Any]


@dataclass(frozen=True)
class TauRuntime:
    tau_tail_apply_into: Callable[..., Any]


@dataclass(frozen=True)
class VisionRuntime:
    fused_linear_bias_residual_into: Callable[..., Any]


@dataclass(frozen=True)
class DenseRuntime:
    fused_mlp_gelu_bias_residual_cuda: Callable[..., Any]
    layernorm_bias_cuda: Callable[..., Any]
    layernorm_bias_reload_cuda: Callable[..., Any]


@dataclass(frozen=True)
class SamplingRuntime:
    top_p_sampling_from_probs: Callable[..., Any]


class KernelRuntime:
    """Unified kernel runtime view used by Kestrel."""

    @property
    def attention(self) -> AttentionRuntime:
        from kestrel_kernels.flash_attn.cute.interface import _flash_attn_fwd
        from kestrel_kernels.flash_attn.cute.mask_definitions import (
            cute_prefix_lm_mask_730,
        )

        # Keep compile-key hashing stable without leaking this detail to callers.
        cute_prefix_lm_mask_730.__cute_hash__ = _PREFIX_LM_730_HASH

        return AttentionRuntime(
            flash_attn_fwd=_flash_attn_fwd,
            prefix_lm_mask_730=cute_prefix_lm_mask_730,
        )

    @property
    def moe(self) -> MoeRuntime:
        from kestrel_kernels.cute_moe import (
            has_cute_moe_config,
            get_cute_moe_block_m,
            get_cute_moe_config,
            invoke_cute_moe_down,
            invoke_cute_moe_down_fp8,
            invoke_cute_moe_up,
            invoke_cute_moe_up_fp8,
        )
        from kestrel_kernels.fp8_quant_cute import fp8_quant_cute
        from kestrel_kernels.gelu_residual import gelu_residual_cute
        from kestrel_kernels.moe_align import (
            moe_align_block_size,
            moe_lora_align_block_size,
        )
        from kestrel_kernels.moe_sum_ops import moe_sum
        from kestrel_kernels.moe_triton import (
            dtype_to_triton,
            invoke_fused_moe_kernel,
            invoke_fused_moe_kernel_fp8_w8a8,
        )

        return MoeRuntime(
            fp8_quant_cute=fp8_quant_cute,
            gelu_residual_cute=gelu_residual_cute,
            moe_sum=moe_sum,
            has_cute_moe_config=has_cute_moe_config,
            get_cute_moe_block_m=get_cute_moe_block_m,
            get_cute_moe_config=get_cute_moe_config,
            invoke_cute_moe_down=invoke_cute_moe_down,
            invoke_cute_moe_down_fp8=invoke_cute_moe_down_fp8,
            invoke_cute_moe_up=invoke_cute_moe_up,
            invoke_cute_moe_up_fp8=invoke_cute_moe_up_fp8,
            moe_align_block_size=moe_align_block_size,
            moe_lora_align_block_size=moe_lora_align_block_size,
            dtype_to_triton=dtype_to_triton,
            invoke_fused_moe_kernel_triton=invoke_fused_moe_kernel,
            invoke_fused_moe_kernel_triton_fp8=invoke_fused_moe_kernel_fp8_w8a8,
        )

    @property
    def cache(self) -> CacheRuntime:
        from kestrel_kernels.kv_cache_write_ops import reshape_and_cache_flash

        return CacheRuntime(reshape_and_cache_flash=reshape_and_cache_flash)

    @property
    def rotary(self) -> RotaryRuntime:
        from kestrel_kernels.rotary_embedding_ops import rotary_embedding

        return RotaryRuntime(rotary_embedding=rotary_embedding)

    @property
    def tau(self) -> TauRuntime:
        from kestrel_kernels.tau_tail_ops import tau_tail_apply_into

        return TauRuntime(tau_tail_apply_into=tau_tail_apply_into)

    @property
    def vision(self) -> VisionRuntime:
        from kestrel_kernels.fused_linear_residual_ops import (
            fused_linear_bias_residual_into,
        )

        return VisionRuntime(
            fused_linear_bias_residual_into=fused_linear_bias_residual_into
        )

    @property
    def dense(self) -> DenseRuntime:
        from kestrel_kernels.fused_mlp import fused_mlp_gelu_bias_residual_cuda
        from kestrel_kernels.layernorm_cuda import (
            layernorm_bias_cuda,
            layernorm_bias_reload_cuda,
        )

        return DenseRuntime(
            fused_mlp_gelu_bias_residual_cuda=fused_mlp_gelu_bias_residual_cuda,
            layernorm_bias_cuda=layernorm_bias_cuda,
            layernorm_bias_reload_cuda=layernorm_bias_reload_cuda,
        )

    @property
    def sampling(self) -> SamplingRuntime:
        from kestrel_kernels.sampling import top_p_sampling_from_probs

        return SamplingRuntime(top_p_sampling_from_probs=top_p_sampling_from_probs)

    @property
    def compute_capability(self) -> tuple[int, int]:
        if not torch.cuda.is_available():
            return (0, 0)
        return torch.cuda.get_device_capability()

    @property
    def is_sm90(self) -> bool:
        major, _minor = self.compute_capability
        return major == 9


@lru_cache(maxsize=1)
def get_runtime() -> KernelRuntime:
    return KernelRuntime()


__all__ = [
    "AttentionRuntime",
    "CacheRuntime",
    "DenseRuntime",
    "KernelRuntime",
    "MoeRuntime",
    "RotaryRuntime",
    "SamplingRuntime",
    "TauRuntime",
    "VisionRuntime",
    "get_runtime",
]
