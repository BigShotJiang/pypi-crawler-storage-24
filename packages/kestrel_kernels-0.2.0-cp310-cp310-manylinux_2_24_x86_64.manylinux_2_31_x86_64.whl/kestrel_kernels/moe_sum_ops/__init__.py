"""MoE sum dispatch API."""

from kestrel_kernels.moe_sum_ops.dispatch import moe_sum

__all__ = ["moe_sum"]
