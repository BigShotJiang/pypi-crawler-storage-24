"""MoE sum wrapper with architecture-aware torch fallback."""

from __future__ import annotations

import torch

from kestrel_kernels.fallback import should_use_cuda_impl
from kestrel_kernels.moe_sum import moe_sum as moe_sum_cuda
from kestrel_kernels.moe_sum_ops.fallback import moe_sum_torch

_SUPPORTED_SMS = {80, 86, 89, 90}


def moe_sum(inp: torch.Tensor, out: torch.Tensor) -> None:
    """Reduce per-expert outputs into final token outputs.

    Expected shapes:
      - ``inp``: [num_tokens, top_k, hidden]
      - ``out``: [num_tokens, hidden]
    """
    if inp.device.type != "cuda" or out.device.type != "cuda":
        raise ValueError("moe_sum expects CUDA tensors")
    if inp.ndim != 3 or out.ndim != 2:
        raise ValueError(
            "moe_sum expects inp=[num_tokens, top_k, hidden], out=[num_tokens, hidden]"
        )
    if inp.shape[0] != out.shape[0] or inp.shape[2] != out.shape[1]:
        raise ValueError("moe_sum input/output shapes are incompatible")
    if out.dtype != inp.dtype:
        raise ValueError("moe_sum output dtype must match input dtype")

    if should_use_cuda_impl(
        device=inp.device,
        kernel_key="moe_sum_non_supported_arch",
        op_name="moe_sum",
        supported_sms=_SUPPORTED_SMS,
    ):
        moe_sum_cuda(inp, out)
        return

    moe_sum_torch(inp, out)


__all__ = ["moe_sum"]
