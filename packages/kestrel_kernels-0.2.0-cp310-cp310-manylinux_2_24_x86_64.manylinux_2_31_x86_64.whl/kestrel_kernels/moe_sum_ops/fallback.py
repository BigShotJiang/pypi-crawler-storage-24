from __future__ import annotations

import torch


def moe_sum_torch(inp: torch.Tensor, out: torch.Tensor) -> None:
    out.copy_(inp.sum(dim=1))


__all__ = ["moe_sum_torch"]
