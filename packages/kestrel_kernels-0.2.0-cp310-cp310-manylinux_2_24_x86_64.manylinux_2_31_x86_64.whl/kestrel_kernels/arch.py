"""CUDA architecture parsing helpers shared by runtime and precompile scripts."""

from __future__ import annotations

import os
import re
from functools import lru_cache


_GPU_KEY_RE = re.compile(r"[^a-z0-9]+")


def parse_torch_arch_list_entry(value: str) -> str | None:
    """Parse a single TORCH_CUDA_ARCH_LIST entry into canonical `smXY` form.

    Examples:
      - "9.0" -> "sm90"
      - "9.0a" -> "sm90"
      - "sm90a" -> "sm90"
      - "90a" -> "sm90"
      - "compute_90" -> "sm90"
    """
    arch = value.strip().lower()
    if not arch:
        return None

    if arch.startswith("compute_"):
        arch = arch[len("compute_") :]
    if arch.startswith("sm_"):
        arch = arch[len("sm_") :]
    elif arch.startswith("sm"):
        arch = arch[len("sm") :]

    if "." in arch:
        major, minor = arch.split(".", 1)
        minor_digits = "".join(ch for ch in minor if ch.isdigit())
        if major.isdigit() and minor_digits:
            return f"sm{major}{minor_digits}"
        return None

    digits = "".join(ch for ch in arch if ch.isdigit())
    if digits:
        return f"sm{digits}"
    return None


def sm_arch_number(arch: str) -> int:
    """Return numeric SM value for an architecture string (e.g., 'sm89' -> 89)."""
    parsed = parse_torch_arch_list_entry(arch)
    if parsed is None:
        return 0
    digits = "".join(ch for ch in parsed[2:] if ch.isdigit())
    return int(digits) if digits else 0


def sm_arch_at_least(arch: str, min_sm: int) -> bool:
    """Check whether `arch` is at least a target SM number (e.g., 90 for SM90)."""
    return sm_arch_number(arch) >= int(min_sm)


def normalize_gpu_name_key(name: str) -> str:
    """Normalize a CUDA device name into a stable lowercase config key."""
    normalized = _GPU_KEY_RE.sub("_", name.strip().lower()).strip("_")
    return normalized or "unknown_gpu"


@lru_cache(maxsize=None)
def _get_cuda_device_name_cached(index: int) -> str:
    import torch

    return str(torch.cuda.get_device_name(index))


@lru_cache(maxsize=None)
def _get_cuda_compute_capability_cached(index: int) -> tuple[int, int]:
    import torch

    major, minor = torch.cuda.get_device_capability(index)
    return int(major), int(minor)


def get_cuda_device_name(device_index: int | None = None) -> str:
    """Get CUDA device name for the current (or provided) CUDA device index."""
    import torch

    index = torch.cuda.current_device() if device_index is None else int(device_index)
    return _get_cuda_device_name_cached(index)


def get_cuda_compute_capability(device_index: int | None = None) -> tuple[int, int]:
    """Get CUDA compute capability `(major, minor)` for current/provided device."""
    import torch

    index = torch.cuda.current_device() if device_index is None else int(device_index)
    return _get_cuda_compute_capability_cached(index)


def get_cuda_sm(device_index: int | None = None) -> int:
    """Get CUDA SM value (e.g. 89, 90, 100) for current/provided device."""
    major, minor = get_cuda_compute_capability(device_index)
    return major * 10 + minor


def get_cuda_device_name_key(device_index: int | None = None) -> str:
    """Get normalized config key for CUDA device name."""
    return normalize_gpu_name_key(get_cuda_device_name(device_index))


def resolve_cuda_device_name_key(
    *,
    device_index: int | None = None,
    env_var: str = "KESTREL_CUTE_MOE_CONFIG_GPU",
) -> str:
    """Resolve GPU config key from env override, else current CUDA device name."""
    override = os.environ.get(env_var, "").strip()
    if override:
        return normalize_gpu_name_key(override)
    return get_cuda_device_name_key(device_index)


__all__ = [
    "get_cuda_compute_capability",
    "get_cuda_device_name",
    "get_cuda_device_name_key",
    "get_cuda_sm",
    "normalize_gpu_name_key",
    "parse_torch_arch_list_entry",
    "resolve_cuda_device_name_key",
    "sm_arch_number",
    "sm_arch_at_least",
]
