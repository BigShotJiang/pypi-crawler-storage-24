"""Dispatch wrapper for rotary embedding with architecture-aware torch fallback."""

from __future__ import annotations

import torch

from kestrel_kernels.fallback import should_use_cuda_impl
from kestrel_kernels.rotary_embedding import rotary_embedding as rotary_embedding_cuda
from kestrel_kernels.rotary_embedding_ops.fallback import rotary_embedding_torch

_SUPPORTED_SMS = {80, 86, 87, 89, 90}


def rotary_embedding(
    positions: torch.Tensor,
    query: torch.Tensor,
    key: torch.Tensor,
    head_size: int,
    cos_sin_cache: torch.Tensor,
) -> None:
    if query.device.type != "cuda" or key.device.type != "cuda":
        raise ValueError("rotary_embedding expects CUDA query/key tensors")
    if positions.device.type != "cuda" or cos_sin_cache.device.type != "cuda":
        raise ValueError("rotary_embedding expects CUDA positions/cos_sin_cache tensors")

    if should_use_cuda_impl(
        device=query.device,
        kernel_key="rotary_embedding",
        op_name="rotary_embedding",
        supported_sms=_SUPPORTED_SMS,
    ):
        rotary_embedding_cuda(positions, query, key, head_size, cos_sin_cache)
        return

    rotary_embedding_torch(
        positions=positions,
        query=query,
        key=key,
        head_size=head_size,
        cos_sin_cache=cos_sin_cache,
    )


__all__ = ["rotary_embedding"]
