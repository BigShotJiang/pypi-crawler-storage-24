"""Shared helpers for kernel fallbacks."""

from __future__ import annotations

from functools import lru_cache
import threading
from typing import Any, Callable, Iterable, TypeVar
import warnings

import torch

from kestrel_kernels.arch import get_cuda_compute_capability


_FALLBACK_WARNED: set[str] = set()
_FALLBACK_WARN_LOCK = threading.Lock()
_T = TypeVar("_T")


def warn_fallback_once(kernel_key: str, message: str) -> None:
    with _FALLBACK_WARN_LOCK:
        if kernel_key in _FALLBACK_WARNED:
            return
        _FALLBACK_WARNED.add(kernel_key)
    warnings.warn(message, RuntimeWarning, stacklevel=2)


@lru_cache(maxsize=None)
def device_arch(device_index: int) -> tuple[int, int]:
    return get_cuda_compute_capability(device_index)


def device_capability(device: torch.device) -> tuple[int, int]:
    """Return (major, minor) capability for a CUDA device, else (0, 0)."""
    if device.type != "cuda":
        return (0, 0)
    index = int(torch.cuda.current_device() if device.index is None else device.index)
    return device_arch(index)


def warn_and_run_fallback(
    *,
    kernel_key: str,
    message: str,
    fallback: Callable[..., _T],
    args: tuple[Any, ...] = (),
    kwargs: dict[str, Any] | None = None,
) -> _T:
    warn_fallback_once(kernel_key, message)
    if kwargs is None:
        kwargs = {}
    return fallback(*args, **kwargs)


def should_use_cuda_impl(
    *,
    device: torch.device,
    kernel_key: str,
    op_name: str,
    supported_sms: Iterable[int],
) -> bool:
    """Return True when CUDA impl is supported on `device`, else warn once and return False."""
    major, minor = device_capability(device)
    sm = major * 10 + minor
    allowed = sorted({int(v) for v in supported_sms})
    if sm in allowed:
        return True
    warn_fallback_once(
        kernel_key,
        "kestrel-kernels: falling back to PyTorch for "
        f"{op_name} (arch=sm{major}{minor}, supported_sms={allowed}).",
    )
    return False
