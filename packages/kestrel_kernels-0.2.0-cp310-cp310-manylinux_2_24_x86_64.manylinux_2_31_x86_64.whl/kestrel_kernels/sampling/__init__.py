"""Top-p sampling kernel APIs."""

from kestrel_kernels.sampling.dispatch import top_p_sampling_from_probs

__all__ = ["top_p_sampling_from_probs"]
