"""Top-p sampling dispatch."""

from __future__ import annotations

import torch

from kestrel_kernels.fallback import warn_and_run_fallback, warn_fallback_once
from kestrel_kernels.precompile import get_cuda_arch, load_precompiled_function
from kestrel_kernels.sampling.fallback import top_p_sampling_torch


_KERNEL_KEY = "top_p_sampling_cute"
_PRECOMPILED_KEY_PREFIX = "top_p_sampling_rejection_precompiled"
_MAX_REJECTION_ROUNDS = 16
_SUPPORTED_VOCAB_SIZES = {1024, 51200}

# CuTe execution is enabled by default on CUDA. Unsupported shapes/devices and
# runtime issues fall back to the PyTorch implementation.
_ENABLE_CUTE_EXECUTION = True


# Precompiled kernel registry
_precompiled_cache: dict[str, object | None] = {}

# We probe for precompiled artifacts once per process.
_probe_done: set[tuple[str, int]] = set()


def _load_precompiled_kernel(vocab_size: int) -> object | None:
    """Load the precompiled CuTe top-p kernel if present."""
    cache_key = f"{_PRECOMPILED_KEY_PREFIX}_v{vocab_size}"
    if cache_key in _precompiled_cache:
        return _precompiled_cache[cache_key]

    arch = get_cuda_arch()
    filename = f"top_p_sampling_rejection_v{vocab_size}_{arch}.so"
    function_name = f"top_p_sampling_rejection_v{vocab_size}_{arch}"
    kernel_fn = load_precompiled_function(filename, function_name)
    _precompiled_cache[cache_key] = kernel_fn
    return kernel_fn


def _probe_once(device: torch.device, vocab_size: int) -> None:
    """Probe whether the precompiled kernel exists for this arch."""
    if vocab_size not in _SUPPORTED_VOCAB_SIZES:
        return

    probe_key = (device.type, int(vocab_size))
    if probe_key in _probe_done:
        return
    _probe_done.add(probe_key)

    if device.type != "cuda":
        return

    if _load_precompiled_kernel(vocab_size) is None:
        warn_fallback_once(
            f"{_PRECOMPILED_KEY_PREFIX}_v{vocab_size}",
            "kestrel-kernels: top-p sampling CuTe artifact was not found for "
            f"arch={get_cuda_arch()}, vocab={vocab_size}; using PyTorch fallback.",
        )


def _run_cute_kernel(
    *,
    probs: torch.Tensor,
    top_p: torch.Tensor,
    generator: torch.Generator | None,
) -> torch.Tensor:
    vocab_size = int(probs.shape[1])
    if vocab_size not in _SUPPORTED_VOCAB_SIZES:
        raise RuntimeError(
            f"no precompiled top-p CuTe kernel for vocab={vocab_size}; "
            f"supported={sorted(_SUPPORTED_VOCAB_SIZES)}"
        )

    kernel_fn = _load_precompiled_kernel(vocab_size)
    if kernel_fn is None:
        raise RuntimeError(
            "precompiled top-p CuTe kernel artifact is unavailable "
            f"for vocab={vocab_size}, arch={get_cuda_arch()}"
        )

    probs_f = probs.to(dtype=torch.float32).contiguous()
    top_p_f = torch.clamp(
        top_p.to(device=probs.device, dtype=torch.float32),
        min=1e-6,
        max=1.0,
    ).contiguous()
    rows = int(probs_f.shape[0])
    uniforms = torch.rand(
        (rows, _MAX_REJECTION_ROUNDS),
        device=probs.device,
        dtype=torch.float32,
        generator=generator,
    )
    sampled = torch.empty((rows,), device=probs.device, dtype=torch.long)
    kernel_fn(sampled, probs_f, top_p_f, uniforms)
    return sampled


def top_p_sampling_from_probs(
    probs: torch.Tensor,
    top_p: torch.Tensor,
    *,
    generator: torch.Generator | None = None,
) -> torch.Tensor:
    """Sample token IDs from probabilities and per-row top-p thresholds.

    Args:
        probs: Probability tensor with shape [batch, vocab].
        top_p: Top-p thresholds with shape [batch].
        generator: Optional random generator.
    """
    if probs.ndim != 2:
        raise ValueError(f"probs must be 2D [batch, vocab], got shape {tuple(probs.shape)}")
    if probs.shape[0] == 0:
        return probs.new_empty((0,), dtype=torch.long)
    if probs.dtype not in (torch.float16, torch.bfloat16, torch.float32):
        raise ValueError(f"unsupported probs dtype {probs.dtype}; expected fp16/bf16/fp32")
    if top_p.ndim == 2 and top_p.shape[1] == 1:
        top_p = top_p.view(-1)
    if top_p.ndim != 1:
        raise ValueError(f"top_p must be 1D [batch], got shape {tuple(top_p.shape)}")
    if top_p.shape[0] != probs.shape[0]:
        raise ValueError(
            f"top_p batch dimension ({top_p.shape[0]}) must match probs ({probs.shape[0]})"
        )

    _probe_once(probs.device, int(probs.shape[1]))

    if (
        _ENABLE_CUTE_EXECUTION
        and probs.device.type == "cuda"
        and int(probs.shape[1]) in _SUPPORTED_VOCAB_SIZES
    ):
        try:
            return _run_cute_kernel(probs=probs, top_p=top_p, generator=generator)
        except Exception as e:
            warn_fallback_once(
                f"{_KERNEL_KEY}_runtime_error",
                "kestrel-kernels: CuTe top-p kernel failed at runtime; "
                f"falling back to PyTorch. error={type(e).__name__}: {e}",
            )

    return warn_and_run_fallback(
        kernel_key=_KERNEL_KEY,
        message="kestrel-kernels: using PyTorch fallback for top_p_sampling_from_probs.",
        fallback=top_p_sampling_torch,
        kwargs={
            "probs": probs,
            "top_p": top_p,
            "generator": generator,
        },
    )


__all__ = ["top_p_sampling_from_probs"]
