from inline_snapshot import snapshot

from mirascope.llm import (
    AssistantMessage,
    Text,
    UserMessage,
)

test_snapshot = snapshot(
    {
        "response": (
            {
                "provider_id": "openai",
                "model_id": "openai/gpt-5:completions",
                "provider_model_name": "gpt-5:completions",
                "params": {
                    "temperature": 0.7,
                    "max_tokens": 500,
                    "top_p": 0.3,
                    "top_k": 50,
                    "seed": 42,
                    "stop_sequences": ["4242"],
                    "thinking": {
                        "level": "none",
                        "encode_thoughts_as_text": False,
                        "include_thoughts": False,
                    },
                },
                "finish_reason": None,
                "usage": {
                    "input_tokens": 15,
                    "output_tokens": 75,
                    "cache_read_tokens": 0,
                    "cache_write_tokens": 0,
                    "reasoning_tokens": 64,
                    "provider_tool_usage": None,
                    "raw": "CompletionUsage(completion_tokens=75, prompt_tokens=15, total_tokens=90, completion_tokens_details=CompletionTokensDetails(accepted_prediction_tokens=0, audio_tokens=0, reasoning_tokens=64, rejected_prediction_tokens=0), prompt_tokens_details=PromptTokensDetails(audio_tokens=0, cached_tokens=0))",
                    "total_tokens": 90,
                },
                "messages": [
                    UserMessage(content=[Text(text="What is 4200 + 42?")]),
                    AssistantMessage(
                        content=[Text(text="4242")],
                        provider_id="openai",
                        model_id="openai/gpt-5:completions",
                        provider_model_name="gpt-5:completions",
                        raw_message={
                            "content": "4242",
                            "role": "assistant",
                            "annotations": [],
                        },
                    ),
                ],
                "format": None,
                "tools": [],
            },
        ),
        "logs": [
            "Skipping unsupported parameter: top_k=50 (provider: openai)",
            "Skipping unsupported parameter: temperature=0.7 (provider: openai)",
            "Skipping unsupported parameter: top_p=0.3 (provider: openai)",
            "Skipping unsupported parameter: stop_sequences=['4242'] (provider: openai)",
        ],
    }
)
