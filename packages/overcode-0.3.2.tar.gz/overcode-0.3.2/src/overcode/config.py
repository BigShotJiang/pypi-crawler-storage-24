"""
Configuration loading for overcode.

Config file location: ~/.overcode/config.yaml

Example config:
    default_standing_instructions: "Approve file read/write permission requests"
    tmux_session: "agents"
"""

import socket
from pathlib import Path
from typing import List, Optional
import yaml


CONFIG_PATH = Path.home() / ".overcode" / "config.yaml"


def save_config(config: dict) -> None:
    """Save configuration dict to ~/.overcode/config.yaml."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(yaml.dump(config, default_flow_style=False, sort_keys=False))


def load_config() -> dict:
    """Load configuration from ~/.overcode/config.yaml.

    Returns empty dict if file doesn't exist or is invalid.
    """
    if not CONFIG_PATH.exists():
        return {}

    try:
        with open(CONFIG_PATH) as f:
            config = yaml.safe_load(f)
            return config if isinstance(config, dict) else {}
    except (yaml.YAMLError, IOError):
        return {}


def _get_config_value(key_path: str, default=None):
    """Load config and traverse a dot-separated key path.

    Example: _get_config_value("web.api_key") loads config["web"]["api_key"].
    Returns default if any key is missing or intermediate value isn't a dict.
    """
    config = load_config()
    keys = key_path.split(".")
    value = config
    for key in keys:
        if not isinstance(value, dict):
            return default
        value = value.get(key)
        if value is None:
            return default
    return value


def get_default_standing_instructions() -> str:
    """Get default standing instructions from config.

    Returns empty string if not configured.
    """
    return _get_config_value("default_standing_instructions", "")


def get_relay_config() -> Optional[dict]:
    """Get relay configuration for pushing state to cloud.

    Returns None if relay is not configured or disabled.

    Config format in ~/.overcode/config.yaml:
        relay:
          enabled: true
          url: https://your-worker.workers.dev/update
          api_key: your-secret-key
          interval: 30  # seconds between pushes (optional, default 30)
    """
    if not _get_config_value("relay.enabled", False):
        return None

    url = _get_config_value("relay.url")
    api_key = _get_config_value("relay.api_key")

    if not url or not api_key:
        return None

    return {
        "url": url,
        "api_key": api_key,
        "interval": _get_config_value("relay.interval", 30),
    }


def get_summarizer_config() -> dict:
    """Get summarizer configuration for AI summaries.

    Config file takes precedence, environment variables are fallback.

    Config format in ~/.overcode/config.yaml:
        summarizer:
          api_url: https://api.openai.com/v1/chat/completions
          model: gpt-4o-mini
          api_key_var: OPENAI_API_KEY  # env var name containing the key

    Environment variable fallbacks:
        OVERCODE_SUMMARIZER_API_URL
        OVERCODE_SUMMARIZER_MODEL
        OVERCODE_SUMMARIZER_API_KEY_VAR

    Returns:
        Dict with api_url, model, and api_key (resolved from env var)
    """
    import os

    # Defaults
    default_api_url = "https://api.openai.com/v1/chat/completions"
    default_model = "gpt-4o-mini"
    default_api_key_var = "OPENAI_API_KEY"

    # Config file takes precedence, env vars are fallback
    api_url = _get_config_value("summarizer.api_url") or os.environ.get("OVERCODE_SUMMARIZER_API_URL") or default_api_url
    model = _get_config_value("summarizer.model") or os.environ.get("OVERCODE_SUMMARIZER_MODEL") or default_model
    api_key_var = _get_config_value("summarizer.api_key_var") or os.environ.get("OVERCODE_SUMMARIZER_API_KEY_VAR") or default_api_key_var

    # Resolve the actual API key from the configured env var
    api_key = os.environ.get(api_key_var)

    return {
        "api_url": api_url,
        "model": model,
        "api_key": api_key,
        "api_key_var": api_key_var,
    }


def get_timeline_config() -> dict:
    """Get timeline display configuration.

    Config format in ~/.overcode/config.yaml:
        timeline:
          hours: 3.0  # How many hours of history to show

    Returns:
        Dict with timeline settings (hours)
    """
    return {
        "hours": _get_config_value("timeline.hours", 3.0),
    }


def get_web_time_presets() -> list:
    """Get time presets for the web analytics dashboard.

    Returns list of preset dictionaries with name, start, end times.
    Falls back to defaults if not configured.

    Config format in ~/.overcode/config.yaml:
        web:
          time_presets:
            - name: "Morning"
              start: "09:00"
              end: "12:00"
            - name: "Full Day"
              start: "09:00"
              end: "17:00"
            - name: "Night Owl"
              start: "22:00"
              end: "02:00"
    """
    presets = _get_config_value("web.time_presets")

    if presets and isinstance(presets, list):
        # Validate and normalize presets
        valid_presets = []
        for p in presets:
            if isinstance(p, dict) and "name" in p:
                valid_presets.append({
                    "name": p.get("name", ""),
                    "start": p.get("start"),
                    "end": p.get("end"),
                })
        if valid_presets:
            # Always add "All Time" at the end
            if not any(p["name"] == "All Time" for p in valid_presets):
                valid_presets.append({"name": "All Time", "start": None, "end": None})
            return valid_presets

    # Default presets
    return [
        {"name": "Morning", "start": "09:00", "end": "12:00"},
        {"name": "Afternoon", "start": "13:00", "end": "17:00"},
        {"name": "Full Day", "start": "09:00", "end": "17:00"},
        {"name": "Evening", "start": "18:00", "end": "22:00"},
        {"name": "All Time", "start": None, "end": None},
    ]


def get_time_context_config() -> dict:
    """Get time context configuration for the time-context hook.

    Config format in ~/.overcode/config.yaml:
        time_context:
          office_start: 9
          office_end: 17
          heartbeat_interval_minutes: 15  # omit to disable

    Returns:
        Dict with office_start (int), office_end (int),
        heartbeat_interval_minutes (Optional[int])
    """
    return {
        "office_start": _get_config_value("time_context.office_start", 9),
        "office_end": _get_config_value("time_context.office_end", 17),
        "heartbeat_interval_minutes": _get_config_value("time_context.heartbeat_interval_minutes"),
    }


def get_hostname() -> str:
    """Get configured hostname or system hostname.

    Config format in ~/.overcode/config.yaml:
        hostname: "mac-studio"

    Returns:
        Configured hostname or socket.gethostname()
    """
    return _get_config_value("hostname") or socket.gethostname()


def get_web_port() -> int:
    """Get configured web server port.

    Config format in ~/.overcode/config.yaml:
        web:
          port: 8081

    Returns:
        Configured port or 8080 (default)
    """
    return int(_get_config_value("web.port", 8080))


def get_web_host() -> str:
    """Get configured web server bind host.

    Config format in ~/.overcode/config.yaml:
        web:
          host: "0.0.0.0"

    Returns:
        Configured host or "127.0.0.1" (default)
    """
    return _get_config_value("web.host", "127.0.0.1")


def get_web_api_key() -> Optional[str]:
    """Get API key for web server authentication.

    Required when binding to non-localhost addresses.

    Config format in ~/.overcode/config.yaml:
        web:
          api_key: "some-shared-secret"

    Returns:
        API key string or None if not configured
    """
    return _get_config_value("web.api_key") or None


def get_web_allow_control() -> bool:
    """Check if remote control is enabled for the web server.

    When False (default), all POST/PUT/DELETE endpoints return 403.

    Config format in ~/.overcode/config.yaml:
        web:
          allow_control: true

    Returns:
        True if remote control is enabled, False otherwise
    """
    return bool(_get_config_value("web.allow_control", False))


def get_tmux_toggle_key() -> str | None:
    """Get configured tmux pane toggle key.

    Config format in ~/.overcode/config.yaml:
        tmux:
          toggle_key: "Tab"  # or "C-]", "BTab", etc.

    Returns:
        Configured key name or None if not set.
    """
    return _get_config_value("tmux.toggle_key")


def set_tmux_toggle_key(key: str) -> None:
    """Save the tmux pane toggle key to config.

    Args:
        key: tmux key name (e.g. "Tab", "C-]").
    """
    config = load_config()
    tmux_section = config.get("tmux", {})
    if not isinstance(tmux_section, dict):
        tmux_section = {}
    tmux_section["toggle_key"] = key
    config["tmux"] = tmux_section
    save_config(config)


def get_new_agent_defaults() -> dict:
    """Get new-agent default settings from config.

    Config format in ~/.overcode/config.yaml:
        new_agent_defaults:
          bypass_permissions: false
          agent_teams: false

    Returns:
        Dict with bypass_permissions (bool) and agent_teams (bool).
    """
    defaults = _get_config_value("new_agent_defaults", {})
    return {
        "bypass_permissions": bool(defaults.get("bypass_permissions", False)),
        "agent_teams": bool(defaults.get("agent_teams", False)),
    }


def save_new_agent_defaults(defaults: dict) -> None:
    """Save new-agent default settings to config.

    Args:
        defaults: Dict with bypass_permissions and agent_teams booleans.
    """
    config = load_config()
    config["new_agent_defaults"] = defaults
    save_config(config)


def get_jobs_retention_hours() -> float:
    """Get job retention period in hours.

    Config format in ~/.overcode/config.yaml:
        jobs:
          retention_hours: 24

    Returns:
        Retention hours (default 24)
    """
    return float(_get_config_value("jobs.retention_hours", 24))


def get_sisters_config() -> List[dict]:
    """Get sister instance configuration for cross-machine monitoring.

    Config format in ~/.overcode/config.yaml:
        sisters:
          - name: "macbook-pro"
            url: "http://localhost:15337"
          - name: "desktop"
            url: "http://localhost:25337"
            api_key: "secret"

    Returns:
        List of dicts with name, url, and optional api_key. Empty list if unconfigured.
    """
    sisters = _get_config_value("sisters", [])
    if not isinstance(sisters, list):
        return []

    result = []
    for s in sisters:
        if not isinstance(s, dict):
            continue
        name = s.get("name")
        url = s.get("url")
        if not name or not url:
            continue
        entry = {"name": name, "url": url.rstrip("/")}
        api_key = s.get("api_key")
        if api_key:
            entry["api_key"] = api_key
        result.append(entry)

    return result


def get_sister_by_name(name: str) -> Optional[dict]:
    """Look up a sister config by name.

    Returns:
        Sister config dict (name, url, optional api_key) or None if not found.
    """
    for sister in get_sisters_config():
        if sister["name"] == name:
            return sister
    return None
