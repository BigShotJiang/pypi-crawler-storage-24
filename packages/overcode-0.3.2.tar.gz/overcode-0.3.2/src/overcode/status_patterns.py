"""
Centralized status detection patterns.

This module contains all the pattern lists used by StatusDetector to identify
Claude's current state. Centralizing these makes them:
- Easier to maintain and extend
- Testable in isolation
- Potentially configurable via config file in the future

Each pattern set includes documentation about when it's used and what it matches.
"""

import re
from dataclasses import dataclass, field
from typing import List, Optional

# Regex to match ANSI escape sequences (colors, cursor movement, etc.)
ANSI_ESCAPE_PATTERN = re.compile(r'\x1b\[[0-9;]*[a-zA-Z]')

# Shell prompt patterns — shared between PollingStatusDetector and HookStatusDetector
# These detect when Claude Code has exited and the user is back at a shell prompt.
SHELL_PROMPT_PATTERNS = [
    re.compile(r'\w+@\w+.*[%$]\s*$'),       # user@hostname ... $ or %
    re.compile(r'\[.*\][%$#]\s*$'),          # [prompt]$ or [prompt]%
    re.compile(r'^[~\/].*[%$]\s*$'),         # /path/to/dir $ or ~/dir %
]


def is_shell_prompt(line: str, patterns=None) -> bool:
    """Check if a line matches a shell prompt pattern.

    Args:
        line: Line to check (should be stripped of whitespace)
        patterns: Optional list of compiled regex patterns (defaults to SHELL_PROMPT_PATTERNS)

    Returns:
        True if the line looks like a shell prompt
    """
    for pattern in (patterns or SHELL_PROMPT_PATTERNS):
        if pattern.search(line):
            return True
    return False


def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences from text.

    This is needed because tmux capture_pane with escape_sequences=True
    preserves color codes, but pattern matching needs plain text.

    Args:
        text: Text potentially containing ANSI escape sequences

    Returns:
        Text with all ANSI escape sequences removed
    """
    return ANSI_ESCAPE_PATTERN.sub('', text)


@dataclass
class StatusPatterns:
    """All patterns used for status detection.

    Patterns are case-insensitive unless noted otherwise.
    """

    # Permission/confirmation prompts - HIGHEST priority
    # These indicate Claude needs user approval before proceeding.
    # Matched against the last few lines of output (lowercased).
    permission_patterns: List[str] = field(default_factory=lambda: [
        "enter to confirm",
        "esc to reject",
        # Note: removed "approve" - too broad, matches "auto-approve" in status bar
        # Note: removed "permission" - too broad, matches "bypass permissions" in status bar
        "allow this",
        # Claude Code v2 permission dialog format
        "do you want to proceed",
        "❯ 1. yes",  # Menu selector on first option
        "tell claude what to do differently",  # Option 3 text
    ])

    # Active work indicators - checked when content hasn't changed
    # These indicate Claude is busy even if the prompt appears visible.
    # Matched against the last few lines of output (lowercased).
    active_indicators: List[str] = field(default_factory=lambda: [
        "web search",
        "searching",
        "fetching",
        "esc to interrupt",  # Shows active operation in progress
        "thinking",
        "✽",  # Spinner character
        # Fun thinking indicators from Claude Code
        "razzmatazzing",
        "fiddle-faddling",
        "pondering",
        "cogitating",
        # Note: removed "tokens" - too broad, matches normal text
        # The spinner ✽ and "esc to interrupt" are sufficient
    ])

    # Tool execution indicators - CASE SENSITIVE
    # These indicate Claude is executing a tool.
    # Matched directly against lines (case-sensitive).
    execution_indicators: List[str] = field(default_factory=lambda: [
        "Reading",
        "Writing",
        "Editing",
        "Running",
        "Executing",
        "Searching",
        "Analyzing",
        "Processing",
        "Installing",
        "Building",
        "Compiling",
        "Testing",
        "Deploying",
    ])

    # Waiting patterns - indicate Claude is waiting for user decision
    # Matched against the last few lines of output (lowercased).
    waiting_patterns: List[str] = field(default_factory=lambda: [
        "paused",
        "do you want",
        "proceed",
        "continue",
        "yes/no",
        "[y/n]",
        "press any key",
    ])

    # Prompt characters - indicate empty prompt waiting for user input
    # These are exact matches for line content.
    prompt_chars: List[str] = field(default_factory=lambda: [
        ">",
        "›",
        "❯",  # Claude Code's prompt character (U+276F)
    ])

    # Line prefixes to clean/remove for display
    # These are stripped from the beginning of lines.
    line_prefixes: List[str] = field(default_factory=lambda: [
        "› ",
        "> ",
        "❯ ",  # Claude Code's prompt character (U+276F)
        "- ",
        "• ",
    ])

    # Status bar prefixes to filter out
    # Lines starting with these are UI chrome, not Claude output.
    status_bar_prefixes: List[str] = field(default_factory=lambda: [
        "⏵⏵",  # Status bar indicator (e.g., "⏵⏵ bypass permissions on")
        "⏸",   # Plan mode status bar (e.g., "⏸ plan mode on (shift+tab to cycle)")
    ])

    # Command menu pattern - regex pattern for slash command menu lines
    # These appear when user types a slash command and Claude shows autocomplete
    # Format: "  /command-name     Description text"
    command_menu_pattern: str = r"^\s*/[\w-]+\s{2,}\S"

    # Spawn failure patterns - when the claude command fails to start
    # These indicate the command was not found or failed to execute
    # Checked against pane content to detect failed spawns
    spawn_failure_patterns: List[str] = field(default_factory=lambda: [
        "command not found",
        "not found:",  # zsh style: "zsh: command not found: claude"
        "no such file or directory",
        "permission denied",
        "cannot execute",
        "is not recognized",  # Windows-style (for future compatibility)
    ])

    # Approval waiting patterns (#22)
    # These indicate Claude is waiting for user approval of a plan or decision
    approval_patterns: List[str] = field(default_factory=lambda: [
        "waiting for.*approval",
        "plan mode",
        "approve.*plan",
        "select.*option",
        "choose.*[1-4]",
        "review the plan",
        "approve this plan",
        "plan requires approval",
    ])

    # Daemon Claude: active work indicators
    # Used by the supervisor daemon to check if daemon claude is still working.
    # These are checked against raw pane content (case-sensitive).
    daemon_active_indicators: List[str] = field(default_factory=lambda: [
        '· ',
        'Running…',
        '(esc to interrupt',
        '✽',
    ])

    # Daemon Claude: tool activity indicators
    # Used by the supervisor daemon to check if daemon claude has started working.
    # These are checked against raw pane content (case-sensitive).
    daemon_tool_indicators: List[str] = field(default_factory=lambda: [
        '⏺',
        'Read(',
        'Write(',
        'Edit(',
        'Bash(',
        'Grep(',
        'Glob(',
    ])

    # Error patterns (#216)
    # These match the SPECIFIC formats Claude Code uses to display errors.
    # Previous broad patterns ("timeout", "429", etc.) caused false positives
    # when Claude's response text discussed errors (#216).
    #
    # Real Claude Code errors have distinct structural formats:
    # - Retryable: "⎿ API Error (...) · Retrying in N seconds… (attempt X/10)"
    # - Final:     "⎿ API Error: <message>"
    # - Network:   "⎿ TypeError (fetch failed)"
    # - Network:   "⎿ Unable to connect to API (ECONNRESET)"
    # - Rate limit: "You've hit your limit · resets <time>"
    # - Auth:      "Invalid API key · Please run /login"
    # - Auth:      "Missing API key · Run /login"
    #
    # These are matched per-line against the last 3 content lines (not joined).
    error_patterns: List[str] = field(default_factory=lambda: [
        r"⎿\s*API Error",            # All API errors (retryable + final)
        r"⎿\s*TypeError",            # Network fetch failures
        r"⎿\s*Unable to connect",    # ECONNRESET and similar
        r"⎿\s*Error:.*compaction",   # Compaction errors
        r"You've hit your limit",     # Rate limit banner
        r"Invalid API key",           # Auth error
        r"Missing API key",           # Auth error
        r"Retrying in.*seconds.*attempt",  # Retry indicator (any format)
    ])


# Default patterns instance
DEFAULT_PATTERNS = StatusPatterns()


def get_patterns() -> StatusPatterns:
    """Get the status detection patterns.

    Returns the default patterns. In the future, this could be
    extended to load from a config file.

    Returns:
        StatusPatterns instance with all pattern lists
    """
    return DEFAULT_PATTERNS


def matches_any(text: str, patterns: List[str], case_sensitive: bool = False) -> bool:
    """Check if text matches any of the patterns.

    Args:
        text: Text to search in
        patterns: List of patterns to match
        case_sensitive: Whether matching is case-sensitive

    Returns:
        True if any pattern is found in text
    """
    if not case_sensitive:
        text = text.lower()
        return any(p.lower() in text for p in patterns)
    return any(p in text for p in patterns)


def find_matching_line(
    lines: List[str],
    patterns: List[str],
    case_sensitive: bool = False,
    reverse: bool = True
) -> str | None:
    """Find the first line that matches any pattern.

    Args:
        lines: Lines to search
        patterns: Patterns to match
        case_sensitive: Whether matching is case-sensitive
        reverse: Search from end to beginning

    Returns:
        The matching line, or None if no match
    """
    search_lines = reversed(lines) if reverse else lines
    for line in search_lines:
        if matches_any(line, patterns, case_sensitive):
            return line
    return None


def line_starts_with_any(
    lines: List[str],
    patterns: List[str],
    case_sensitive: bool = False,
    reverse: bool = True
) -> str | None:
    """Find the first line that starts with any pattern in a tool-execution context.

    Like find_matching_line but designed to reduce false positives from
    mid-sentence occurrences (#359). A line matches if:
    - It has a ⏺ prefix followed by a pattern (definite tool output), OR
    - It starts with a pattern AND the next word looks like a tool name
      (contains parens, quotes, or is a known tool like Bash/Read/etc.)

    This avoids matching prose like "Running the tests revealed..." while
    still matching "Running Bash('ls')" or "⏺ Reading config.json...".

    Args:
        lines: Lines to search
        patterns: Patterns to match
        case_sensitive: Whether matching is case-sensitive
        reverse: Search from end to beginning

    Returns:
        The matching line, or None if no match
    """
    # Prefixes that indicate definite Claude Code tool output
    _tool_prefixes = ("⏺ ", "⏺  ")

    search_lines = reversed(lines) if reverse else lines
    for line in search_lines:
        stripped = line.strip()

        # Path 1: ⏺ prefix = definite tool output — just check pattern starts
        has_tool_prefix = False
        check_str = stripped
        for prefix in _tool_prefixes:
            if stripped.startswith(prefix):
                check_str = stripped[len(prefix):]
                has_tool_prefix = True
                break

        if not case_sensitive:
            starts = any(check_str.lower().startswith(p.lower()) for p in patterns)
        else:
            starts = any(check_str.startswith(p) for p in patterns)

        if not starts:
            continue

        if has_tool_prefix:
            return line

        # Path 2: No ⏺ prefix — require the line looks like tool execution.
        # Real tool lines look like: "Running Bash(...)" or "Reading file.py..."
        # Prose looks like: "Running the tests revealed..."
        # Heuristic: after the verb, check for tool-like tokens (parens, quotes,
        # file extensions, or known tool names).
        if _looks_like_tool_execution(check_str):
            return line

    return None


# Pattern for lines that look like actual tool execution rather than prose.
# Matches: Verb followed by a tool name with parens, a quoted string, or a file path.
_TOOL_EXECUTION_RE = re.compile(
    r'^\w+\s+'           # The verb + space
    r'(?:'
    r'\w+\('             # ToolName( — e.g., Bash(, Read(
    r'|"'                # Quoted argument
    r"|'"                # Single-quoted argument
    r'|\S+\.\w{1,10}'   # File path with extension — e.g., config.json
    r'|\S+/'             # Path with slash — e.g., src/foo
    r')'
)


def _looks_like_tool_execution(line: str) -> bool:
    """Check if a line looks like tool execution rather than prose."""
    return bool(_TOOL_EXECUTION_RE.match(line))


def is_prompt_line(line: str, patterns: StatusPatterns = None) -> bool:
    """Check if a line is an empty prompt waiting for input.

    Args:
        line: Line to check
        patterns: StatusPatterns to use (defaults to DEFAULT_PATTERNS)

    Returns:
        True if line is an empty prompt
    """
    patterns = patterns or DEFAULT_PATTERNS
    stripped = line.strip()
    return stripped in patterns.prompt_chars


def is_status_bar_line(line: str, patterns: StatusPatterns = None) -> bool:
    """Check if a line is status bar UI chrome.

    Args:
        line: Line to check
        patterns: StatusPatterns to use (defaults to DEFAULT_PATTERNS)

    Returns:
        True if line is status bar chrome
    """
    patterns = patterns or DEFAULT_PATTERNS
    stripped = line.strip()
    return any(stripped.startswith(prefix) for prefix in patterns.status_bar_prefixes)


_COMMAND_MENU_RE = re.compile(r"^\s*/[\w-]+\s{2,}\S")


def is_command_menu_line(line: str, patterns: StatusPatterns = None) -> bool:
    """Check if a line is part of a slash command menu.

    Claude Code shows a menu of commands when user types a slash.
    Format: "  /command-name     Description text"

    Args:
        line: Line to check
        patterns: StatusPatterns to use (defaults to DEFAULT_PATTERNS)

    Returns:
        True if line is a command menu entry
    """
    patterns = patterns or DEFAULT_PATTERNS
    # Use pre-compiled regex for the default pattern, fall back to re.match for custom
    if patterns.command_menu_pattern == DEFAULT_PATTERNS.command_menu_pattern:
        return bool(_COMMAND_MENU_RE.match(line))
    return bool(re.match(patterns.command_menu_pattern, line))


def count_command_menu_lines(lines: List[str], patterns: StatusPatterns = None) -> int:
    """Count how many lines in the list are command menu lines.

    Args:
        lines: Lines to check
        patterns: StatusPatterns to use (defaults to DEFAULT_PATTERNS)

    Returns:
        Number of lines matching the command menu pattern
    """
    patterns = patterns or DEFAULT_PATTERNS
    return sum(1 for line in lines if is_command_menu_line(line, patterns))


def _find_status_bar_line(content: str, patterns: StatusPatterns = None, *, clean_content: str = None) -> str | None:
    """Find and return the LAST status bar line from pane content.

    Uses the last match because old status bar lines can persist in scrollback.
    The current/active status bar is always at the bottom of the pane.

    Args:
        content: Raw pane content (can include ANSI codes)
        patterns: StatusPatterns to use (defaults to DEFAULT_PATTERNS)
        clean_content: Pre-stripped content (avoids redundant strip_ansi calls)

    Returns:
        The ANSI-stripped, whitespace-stripped status bar line, or None if not found
    """
    patterns = patterns or DEFAULT_PATTERNS

    # Use pre-stripped content if available, otherwise strip per-line
    # Search from bottom up — old status bar lines persist in scrollback,
    # but the current one is always at the bottom of the pane.
    text = clean_content if clean_content is not None else content
    for line in reversed(text.split('\n')):
        stripped = line.strip() if clean_content is not None else strip_ansi(line).strip()
        if any(stripped.startswith(prefix) for prefix in patterns.status_bar_prefixes):
            return stripped

    return None


def extract_background_bash_count(content: str, patterns: StatusPatterns = None, *, clean_content: str = None) -> int:
    """Extract the number of background bash tasks from pane content.

    Claude Code shows background task counts in the status bar:
    - "2 bashes" when there are 2+ background tasks
    - "command... (running)" when there is 1 background task
    - Nothing when there are 0 background tasks

    Args:
        content: Raw pane content (can include ANSI codes)
        patterns: StatusPatterns to use (defaults to DEFAULT_PATTERNS)
        clean_content: Pre-stripped content (avoids redundant strip_ansi calls)

    Returns:
        Number of active background bash tasks (0 if none detected)
    """
    stripped = _find_status_bar_line(content, patterns, clean_content=clean_content)
    if stripped is None:
        return 0

    # Pattern 1: "N bashes" for 2+ background tasks
    match = re.search(r'(\d+)\s+bashes', stripped)
    if match:
        return int(match.group(1))

    # Pattern 2: "(running)" without "bashes" = 1 background task
    # This appears when a single command is running in background
    if '(running)' in stripped and 'bashes' not in stripped:
        return 1

    return 0


def extract_live_subagent_count(content: str, patterns: StatusPatterns = None, *, clean_content: str = None) -> int:
    """Extract the number of currently running subagents from pane content.

    Claude Code shows live subagent counts in the status bar:
    - "N local agents" when there are N subagents running
    - Nothing when there are 0 subagents

    Args:
        content: Raw pane content (can include ANSI codes)
        patterns: StatusPatterns to use (defaults to DEFAULT_PATTERNS)
        clean_content: Pre-stripped content (avoids redundant strip_ansi calls)

    Returns:
        Number of active subagents (0 if none detected)
    """
    stripped = _find_status_bar_line(content, patterns, clean_content=clean_content)
    if stripped is None:
        return 0

    # Pattern: "N local agents" for running subagents
    match = re.search(r'(\d+)\s+local\s+agents?', stripped)
    if match:
        return int(match.group(1))

    return 0


def strip_ansi_clean(line: str) -> str:
    """Strip ANSI codes and whitespace from a line.

    This is the minimal line-cleaning operation used throughout the codebase.
    For display-ready cleaning (prefix removal, truncation), use clean_line().

    Args:
        line: Line potentially containing ANSI escape sequences

    Returns:
        Line with ANSI codes and surrounding whitespace removed
    """
    return strip_ansi(line).strip()


def clean_line(line: str, patterns: StatusPatterns = None, max_length: int = 80) -> str:
    """Clean a line for display.

    Strips ANSI codes, removes prefixes, strips whitespace, and truncates.

    Args:
        line: Line to clean (may contain ANSI codes)
        patterns: StatusPatterns to use (defaults to DEFAULT_PATTERNS)
        max_length: Maximum length before truncation

    Returns:
        Cleaned line
    """
    patterns = patterns or DEFAULT_PATTERNS
    cleaned = strip_ansi_clean(line)

    # Remove common prefixes
    for prefix in patterns.line_prefixes:
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):]
            break  # Only remove one prefix

    # Truncate if too long
    if len(cleaned) > max_length:
        cleaned = cleaned[:max_length - 3] + "..."

    return cleaned


# Regex for detecting sleep commands in pane content (#289)
_SLEEP_PATTERN = re.compile(r'\bsleep\s+\d+', re.IGNORECASE)
# Matches enriched activity like "Sleeping 1.0m", "Sleeping 45s", "Sleeping 2.5h"
_FORMATTED_SLEEP_PATTERN = re.compile(
    r'\bsleeping\s+(\d+(?:\.\d+)?)(s|m|h|d)\b', re.IGNORECASE
)
# Matches raw commands like "sleep 300", "sleep 60 && echo done"
# Negative lookahead prevents matching "1" from "1.0m"
_RAW_SLEEP_PATTERN = re.compile(r'\bsleep\s+(\d+)(?![.\d])', re.IGNORECASE)


def extract_sleep_duration(text: str) -> int | None:
    """Extract sleep duration in seconds from a command or activity string.

    Handles both raw commands and enriched activity strings:
        extract_sleep_duration("sleep 30") → 30
        extract_sleep_duration("sleep 900 && echo check") → 900
        extract_sleep_duration('Bash("sleep 60")') → 60
        extract_sleep_duration("Sleeping 60s") → 60
        extract_sleep_duration("Sleeping 1.0m") → 60
        extract_sleep_duration("Sleeping 2.5h") → 9000
        extract_sleep_duration("Reading config.json") → None
    """
    # Try formatted activity string first (e.g., "Sleeping 1.0m")
    m = _FORMATTED_SLEEP_PATTERN.search(text)
    if m:
        value = float(m.group(1))
        unit = m.group(2).lower()
        multiplier = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400}
        return int(value * multiplier[unit])

    # Fall back to raw command (e.g., "sleep 300")
    m = _RAW_SLEEP_PATTERN.search(text)
    return int(m.group(1)) if m else None


def extract_pr_number(content: str, *, clean_content: str = None) -> int | None:
    """Extract the most recent PR number from pane content.

    Scans for GitHub PR URLs (github.com/.../pull/123) which appear when
    Claude Code creates or interacts with a PR via `gh pr create`, etc.

    Returns the last (most recent) PR number found, since pane content scrolls.

    Args:
        content: Raw pane content (may include ANSI codes)
        clean_content: Pre-stripped content (avoids redundant strip_ansi calls)

    Returns:
        PR number as int, or None if no PR reference found
    """
    cleaned = clean_content if clean_content is not None else strip_ansi(content)
    # GitHub PR URLs: https://github.com/owner/repo/pull/123
    matches = re.findall(r'github\.com/[^/]+/[^/]+/pull/(\d+)', cleaned)
    if matches:
        return int(matches[-1])
    return None


def is_sleep_command(text: str) -> bool:
    """Check if text contains a bash sleep command.

    Matches patterns like: sleep 30, sleep 300, sleep 5m, Bash("sleep 60"), etc.

    Args:
        text: Line of pane content to check

    Returns:
        True if the text contains a sleep command
    """
    return bool(_SLEEP_PATTERN.search(text))


@dataclass
class PaneExtraction:
    """All display-relevant values extracted from pane content.

    This is the return type of extract_from_pane(). Keeping extractions in a
    pure dataclass prevents accidental mutation of session objects (Pattern B
    anti-pattern) and forces new extractions to follow the widget-var pattern.
    """
    background_bash_count: int = 0
    live_subagent_count: int = 0
    pr_number: Optional[int] = None


def extract_from_pane(content: str) -> PaneExtraction:
    """Pure function: extract all display-relevant data from pane content.

    Returns a PaneExtraction dataclass. Results should be stored as widget
    instance variables, never written to session objects.

    Strips ANSI once and passes the clean version to all sub-extractors,
    avoiding redundant regex strip operations.

    Args:
        content: Raw pane content (may include ANSI codes)

    Returns:
        PaneExtraction with all extracted values
    """
    clean = strip_ansi(content)
    return PaneExtraction(
        background_bash_count=extract_background_bash_count(content, clean_content=clean),
        live_subagent_count=extract_live_subagent_count(content, clean_content=clean),
        pr_number=extract_pr_number(content, clean_content=clean),
    )
