"""
Textual TUI for Overcode monitor.

TODO: Split this file into smaller modules for maintainability:
- tui_core.py: Main App class and core lifecycle
- tui_panels.py: Panel widgets (StatusPanel, AgentPanel, etc.)
- tui_commands.py: Command handlers and actions
- tui_keybindings.py: Key bindings and input handling
"""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import List, Optional
import sys
import time

from textual.app import App, ComposeResult
from textual.containers import ScrollableContainer
from textual.widgets import Header, Static, Input, TextArea
from textual.widget import MountError
from textual.reactive import reactive
from textual.css.query import NoMatches
from textual import events, work

from . import __version__
from .session_manager import SessionManager, Session
from .job_manager import Job, JobManager
from .job_launcher import JobLauncher
from .launcher import ClaudeLauncher
from .status_detector_factory import StatusDetectorDispatcher
from .status_constants import DEFAULT_CAPTURE_LINES, STATUS_CAPTURE_LINES, STATUS_RUNNING, STATUS_RUNNING_HEARTBEAT, STATUS_TERMINATED, STATUS_WAITING_HEARTBEAT, STATUS_WAITING_OVERSIGHT, STATUS_WAITING_USER, is_green_status
from .history_reader import get_session_stats, ClaudeSessionStats, HistoryFile, synthesize_remote_stats
from .settings import signal_activity, write_tui_heartbeat, get_event_loop_timing_path, get_status_changes_path, TUIPreferences  # Activity signaling to daemon
from .monitor_daemon_state import get_monitor_daemon_state
from .monitor_daemon import (
    is_monitor_daemon_running,
)
from .pid_utils import is_daemon_lock_held, spawn_daemon
from .summarizer_component import (
    SummarizerComponent,
    SummarizerConfig,
    AgentSummary,
)
from .sister_poller import SisterPoller
from .usage_monitor import UsageMonitor
from .implementations import RealTmux
from .tmux_utils import get_pane_base_index
from .tui_helpers import (
    format_duration,
    get_git_diff_stats,
)
from .tui_logic import (
    sort_sessions,
    filter_visible_sessions,
    compute_child_counts,
    compute_tree_metadata,
    compute_stall_state,
    should_send_stall_notification,
    compute_active_session_names,
    compute_session_widget_diff,
    detect_display_changes,
)
from .tui_widgets import (
    FullscreenPreview,
    HelpOverlay,
    PreviewPane,
    DaemonPanel,
    DaemonStatusBar,
    StatusTimeline,
    SessionSummary,
    JobSummary,
    CommandBar,
    SummaryConfigModal,
    NewAgentDefaultsModal,
    AgentSelectModal,
    SisterSelectionModal,
    InstructionHistoryModal,
)
from .tui_actions import (
    NavigationActionsMixin,
    ViewActionsMixin,
    DaemonActionsMixin,
    SessionActionsMixin,
    InputActionsMixin,
)


class SupervisorTUI(
    NavigationActionsMixin,
    ViewActionsMixin,
    DaemonActionsMixin,
    SessionActionsMixin,
    InputActionsMixin,
    App,
):
    """Overcode Supervisor TUI"""

    # Disable any size restrictions
    AUTO_FOCUS = None

    # Load CSS from external file
    CSS_PATH = "tui.tcss"


    BINDINGS = [
        ("q", "quit", "Quit"),
        ("h", "toggle_help", "Help"),
        ("question_mark", "toggle_help", "Help"),
        ("d", "toggle_daemon", "Daemon panel"),
        ("t", "toggle_timeline", "Toggle timeline"),
        ("s", "cycle_summary", "Summary detail"),
        ("c", "sync_to_main_and_clear", "Sync main+clear"),
        # Navigation between agents
        ("j", "focus_next_session", "Next"),
        ("k", "focus_previous_session", "Prev"),
        ("down", "focus_next_session", "Next"),
        ("up", "focus_previous_session", "Prev"),
        # Preview pane toggle
        ("m", "toggle_preview", "Preview"),
        # Fullscreen preview (expand preview pane)
        ("f", "expand_preview", "Fullscreen"),
        # Command bar (send instructions to agents)
        ("i", "focus_command_bar", "Send"),
        ("colon", "focus_command_bar", "Send"),
        ("o", "focus_standing_orders", "Standing orders"),
        # Daemon controls (simple keys that work everywhere)
        ("left_square_bracket", "supervisor_start", "Start supervisor"),
        ("right_square_bracket", "supervisor_stop", "Stop supervisor"),
        ("backslash", "monitor_restart", "Restart monitor"),
        ("a", "focus_human_annotation", "Annotation"),
        ("A", "toggle_summarizer", "AI summarizer"),
        # Resize focused agent's tmux window to match pane size
        ("r", "resize_focused_window", "Resize pane"),
        # Agent management
        ("x", "kill_focused", "Kill/Clean up"),
        ("R", "restart_focused", "Restart agent"),
        ("n", "new_agent", "New agent"),
        # Send Enter to focused agent (for approvals)
        ("enter", "send_enter_to_focused", "Send Enter"),
        # Send Escape to focused agent (for interrupting)
        ("escape", "send_escape_to_focused", "Send Escape"),
        # Send number keys 1-5 to focused agent (for numbered prompts)
        ("1", "send_1_to_focused", "Send 1"),
        ("2", "send_2_to_focused", "Send 2"),
        ("3", "send_3_to_focused", "Send 3"),
        ("4", "send_4_to_focused", "Send 4"),
        ("5", "send_5_to_focused", "Send 5"),
        # Copy mode - disable mouse capture for native terminal selection
        ("y", "toggle_copy_mode", "Copy mode"),
        # Heartbeat pause/resume toggle (#265) - promoted to lowercase
        ("p", "toggle_heartbeat_pause", "Pause heartbeat"),
        # Web server toggle
        ("w", "toggle_web_server", "Web dashboard"),
        # Sleep mode toggle - mark agent as paused (excluded from stats)
        ("z", "toggle_sleep", "Sleep mode"),
        # Show terminated/killed sessions (ghost mode)
        ("g", "toggle_show_terminated", "Show killed"),
        # Jump to sessions needing attention (bell/red)
        ("b", "jump_to_attention", "Jump attention"),
        # Hide sleeping agents from display
        ("Z", "toggle_hide_asleep", "Hide sleeping"),
        # Show/hide done child agents (#244)
        ("D", "toggle_show_done", "Show done"),
        # Collapse/expand children in tree view (#244)
        ("X", "toggle_collapse_children", "Collapse children"),
        # Sort mode cycle (#61)
        ("S", "cycle_sort_mode", "Sort mode"),
        # Edit agent value (#61)
        ("V", "edit_agent_value", "Edit value"),
        # Cost budget (#173)
        ("B", "edit_cost_budget", "Cost budget"),
        # Cycle summary content mode (#74)
        ("l", "cycle_summary_content", "Summary content"),
        # Split resize (compact/tmux mode only)
        ("equals_sign", "split_shrink", "Split shrink"),
        ("minus", "split_grow", "Split grow"),
        # Tmux sync - sync navigation to external tmux pane (demoted to shift)
        ("P", "toggle_tmux_sync", "Pane sync"),
        # Baseline time adjustment for mean spin calculation
        ("comma", "baseline_back", "Baseline -15m"),
        ("full_stop", "baseline_forward", "Baseline +15m"),
        ("0", "baseline_reset", "Reset baseline"),
        # Timeline scope cycle (#191)
        ("less_than_sign", "cycle_timeline_hours", "Timeline scope"),
        # Monochrome mode for terminals with ANSI issues (#138)
        ("M", "toggle_monochrome", "Monochrome"),
        # Emoji-free mode for terminals without emoji fonts (#315)
        ("E", "toggle_emoji_free", "Emoji-free"),
        # Cycle between token count, dollar cost, and joules display
        ("dollar_sign", "toggle_cost_display", "Cycle $/⚡"),
        # Transport/handover - prepare all sessions for handoff (double-press)
        ("T", "transport_all", "Handover all"),
        # Heartbeat configuration (#171)
        ("H", "configure_heartbeat", "Heartbeat config"),
        # Fork agent - create child with source's conversation context (#347)
        ("F", "fork_focused", "Fork agent"),
        # Time context toggle - per-agent time awareness hook (moved from F)
        ("ctrl+t", "toggle_time_context", "Time context"),
        # Hook-based status detection toggle (#5)
        ("K", "toggle_hook_detection", "Hook detection"),
        # Column configuration modal (#178)
        ("C", "open_column_config", "Columns"),
        # Column headers toggle
        ("L", "toggle_column_headers", "Column headers"),
        # Remote agent launch on sister (#310)
        ("N", "new_remote_agent", "Remote agent"),
        # New agent defaults modal
        ("G", "open_new_agent_defaults", "Agent defaults"),
        # Sister selection modal (#323)
        ("U", "open_sister_selection", "Sisters"),
        # Instruction history modal (#376)
        ("I", "open_instruction_history", "Instruction history"),
        # Jobs mode toggle
        ("J", "toggle_tui_mode", "Jobs"),
    ]

    # Timeline scope presets in hours (#191)
    TIMELINE_PRESETS = [1, 3, 6, 12, 24]
    # Summary detail levels: low (minimal), med (timing), high (all metrics), full (everything)
    SUMMARY_LEVELS = ["low", "med", "high", "full"]
    # Sort modes (#61)
    SORT_MODES = ["alphabetical", "by_status", "by_value", "by_tree"]
    # Summary content modes: what to show in the summary line (#74)
    SUMMARY_CONTENT_MODES = ["ai_short", "ai_long", "orders", "annotation", "heartbeat"]

    sessions: reactive[List[Session]] = reactive(list)
    focused_session_index: reactive[int] = reactive(0, always_update=True)
    preview_visible: reactive[bool] = reactive(False)  # preview pane visibility
    tmux_sync: reactive[bool] = reactive(False)  # sync navigation to external tmux pane
    show_terminated: reactive[bool] = reactive(False)  # show killed sessions in timeline
    hide_asleep: reactive[bool] = reactive(False)  # hide sleeping agents from display
    show_done: reactive[bool] = reactive(False)  # show "done" child agents (#244)
    summary_content_mode: reactive[str] = reactive("ai_short")  # what to show in summary (#74)
    baseline_minutes: reactive[int] = reactive(0)  # 0=now, 15/30/.../180 = minutes back for mean spin
    monochrome: reactive[bool] = reactive(False)  # B&W mode for terminals with ANSI issues (#138)
    emoji_free: reactive[bool] = reactive(False)  # ASCII fallbacks for emoji (#315)
    show_cost: reactive[str] = reactive("tokens")  # "tokens", "cost", "joules" — cycle with $
    tui_mode: reactive[str] = reactive("agents")  # "agents" | "jobs"
    focused_job_index: reactive[int] = reactive(0, always_update=True)
    jobs: reactive[List[Job]] = reactive(list)

    def __init__(self, tmux_session: str = "agents", diagnostics: bool = False, initial_jobs_mode: bool = False):
        super().__init__()
        self.tmux_session = tmux_session
        self.diagnostics = diagnostics  # Disable all auto-refresh timers
        self._initial_jobs_mode = initial_jobs_mode  # Start in jobs view
        self.compact = False  # Compact mode: no preview (set by overcode tmux)
        self._sister_zoom_active = False  # True when zoomed for a remote/sister agent view
        self.session_manager = SessionManager()
        self.launcher = ClaudeLauncher(tmux_session)
        self.detector = StatusDetectorDispatcher(tmux_session)
        # Track collapsed parents in tree view (#244)
        self.collapsed_parents: set[str] = set()
        # Max repo/branch/name widths for alignment in full detail mode
        self.max_repo_width: int = 10
        self.max_branch_width: int = 10
        self.max_name_width: int = 10
        self.all_names_match_repos: bool = False
        self.column_widths: list = []  # Per-cell column widths for alignment

        # Load persisted TUI preferences
        self._prefs = TUIPreferences.load(tmux_session)

        # Current summary detail level index (cycles through SUMMARY_LEVELS)
        # Initialize from saved preferences
        try:
            self.summary_level_index = self.SUMMARY_LEVELS.index(self._prefs.summary_detail)
        except ValueError:
            self.summary_level_index = 0  # Default to "low"

        # Suppress focus watcher during command bar interaction etc.
        self._suppress_focus_watcher = False
        # Track previous status of each session for detecting transitions to stalled state
        self._previous_statuses: dict[str, str] = {}
        # Track when each session first stalled (monotonic time) for deferred notifications
        self._stall_start_times: dict[str, float] = {}
        # Sessions we've already sent a macOS notification for (current stall)
        self._notified_stalls: set[str] = set()
        # Debounce: when each session last entered green (working) state
        self._non_stall_since: dict[str, float] = {}
        # Timers for auto-dismissing bell when the stalled agent is already focused
        self._bell_dismiss_timers: dict[str, object] = {}
        # Session cache to avoid disk I/O on every status update (250ms interval)
        self._sessions_cache: dict[str, Session] = {}
        self._sessions_cache_time: float = 0
        self._sessions_cache_ttl: float = 1.0  # 1 second TTL
        # Flags to prevent overlapping async updates (fast and slow paths are independent)
        self._status_update_in_progress = False
        self._stats_update_in_progress = False
        # Track whether sessions have been loaded at least once (for startup sequencing)
        self._initial_sessions_loaded = False
        # Track attention jump state (for 'b' key cycling)
        self._attention_jump_index = 0
        self._attention_jump_list: list = []  # Cached list of sessions needing attention
        # Instruction history for reinject modal (#376)
        self._instruction_history: list = []
        # Pending double-press confirmations: action_key -> (session_name | None, timestamp)
        self._pending_confirmations: dict[str, tuple[str | None, float]] = {}
        # Tmux interface for sync operations
        self._tmux = RealTmux()
        # Optional: target a linked session for sync (set by `overcode split`)
        self.tmux_sync_target: str | None = None
        # Initialize tmux_sync from preferences
        self.tmux_sync = self._prefs.tmux_sync
        # Initialize show_terminated from preferences
        self.show_terminated = self._prefs.show_terminated
        # Initialize hide_asleep from preferences
        self.hide_asleep = self._prefs.hide_asleep
        # Initialize show_done from preferences (#244)
        self.show_done = self._prefs.show_done
        # Initialize summary_content_mode from preferences (#98)
        self.summary_content_mode = self._prefs.summary_content_mode
        # Initialize baseline_minutes from preferences (for mean spin calculation)
        self.baseline_minutes = self._prefs.baseline_minutes
        # Initialize monochrome from preferences (#138)
        self.monochrome = self._prefs.monochrome
        # Initialize emoji_free from preferences (#315)
        self.emoji_free = self._prefs.emoji_free
        # Initialize show_cost from preferences
        self.show_cost = self._prefs.show_cost
        # macOS notification integration (#235)
        from .notifier import MacNotifier
        self._notifier = MacNotifier(mode=self._prefs.notifications)
        # Cache of terminated sessions (killed during this TUI session)
        self._terminated_sessions: dict[str, Session] = {}

        # Usage monitor (Claude Code subscription limits)
        self._usage_monitor = UsageMonitor()

        # AI Summarizer - owned by TUI, not daemon (zero cost when TUI closed)
        self._summarizer = SummarizerComponent(
            tmux_session=tmux_session,
            config=SummarizerConfig(enabled=False),  # Disabled by default
        )
        self._summaries: dict[str, AgentSummary] = {}

        # Jobs mode — tracked bash jobs in a separate tmux session
        self._job_manager = JobManager()
        self._job_launcher = JobLauncher(job_manager=self._job_manager)

        # Sister integration (#245) - remote agent monitoring + control
        self._sister_poller = SisterPoller()
        self.has_sisters: bool = self._sister_poller.has_sisters
        self.local_hostname: str = self._sister_poller.local_hostname
        self._remote_sessions: List[Session] = []
        from .sister_controller import SisterController
        self._sister_controller = SisterController()

        # Pre-load session list synchronously so first render has data immediately
        try:
            self._preloaded_sessions: list | None = self.launcher.list_sessions()
        except Exception:
            self._preloaded_sessions = None

        # Event loop heartbeat probe — measures event loop responsiveness
        self._heartbeat_last: float = 0.0  # monotonic timestamp of last tick
        self._heartbeat_log: list = []  # buffered (iso_timestamp, delta_ms, event) tuples
        self._heartbeat_csv_path = get_event_loop_timing_path(tmux_session)

        # Status change diagnostic log — tracks every per-agent status transition
        self._status_change_log: list = []
        self._status_change_csv_path = get_status_changes_path(tmux_session)

    def _terminal_active_banner_text(self) -> str:
        """Build the TERMINAL ACTIVE banner with the configured toggle key."""
        from .config import get_tmux_toggle_key
        from .cli.split import TOGGLE_KEY_CHOICES, DEFAULT_TOGGLE_KEY
        key = get_tmux_toggle_key() or DEFAULT_TOGGLE_KEY
        label = next((l for l, k in TOGGLE_KEY_CHOICES if k == key), key)
        return f"  ↓ TERMINAL ACTIVE — {label} to return ↓  "

    def compose(self) -> ComposeResult:
        """Create child widgets"""
        yield Header(show_clock=True)
        yield DaemonStatusBar(tmux_session=self.tmux_session, session_manager=self.session_manager, id="daemon-status")
        yield StatusTimeline([], tmux_session=self.tmux_session, id="timeline")
        yield DaemonPanel(tmux_session=self.tmux_session, id="daemon-panel")
        yield Static("", id="column-headers")
        yield ScrollableContainer(id="sessions-container")
        yield ScrollableContainer(id="jobs-container")
        yield PreviewPane(id="preview-pane")
        yield Static(self._terminal_active_banner_text(), id="terminal-active-banner")
        yield CommandBar(id="command-bar")
        # Modal for column configuration (positioned programmatically)
        yield SummaryConfigModal(id="summary-config-modal", classes="modal")
        # Modal for new-agent defaults
        yield NewAgentDefaultsModal(id="new-agent-defaults-modal", classes="modal")
        # Modal for agent selection during new agent creation
        yield AgentSelectModal(id="agent-select-modal", classes="modal")
        # Modal for sister instance visibility (#323)
        yield SisterSelectionModal(id="sister-selection-modal", classes="modal")
        # Modal for instruction history (#376)
        yield InstructionHistoryModal(id="instruction-history-modal", classes="modal")
        yield FullscreenPreview(id="fullscreen-preview")
        yield HelpOverlay(id="help-overlay")
        yield Static(
            self._build_footer_text(),
            id="help-text"
        )

    @staticmethod
    def _get_dev_version_suffix() -> str:
        """Get git short hash if running from an editable install, else empty."""
        try:
            from pathlib import Path
            import subprocess
            # Check if this file is inside a git repo (editable install)
            pkg_dir = Path(__file__).resolve().parent
            result = subprocess.run(
                ["git", "describe", "--always", "--dirty"],
                capture_output=True, text=True, cwd=pkg_dir, timeout=2,
            )
            if result.returncode == 0:
                return f" ({result.stdout.strip()})"
        except Exception:
            pass
        return ""

    def on_mount(self) -> None:
        """Called when app starts"""
        self.title = f"Overcode v{__version__}{self._get_dev_version_suffix()}"
        self._update_subtitle()
        self._update_capture_lines()

        # Auto-start Monitor Daemon if not running
        self._ensure_monitor_daemon()

        # Disable command bar inputs to prevent auto-focus capture
        try:
            cmd_bar = self.query_one("#command-bar", CommandBar)
            cmd_bar.query_one("#cmd-input", Input).disabled = True
            cmd_bar.query_one("#cmd-textarea", TextArea).disabled = True
            # Clear any focus from the command bar
            self.set_focus(None)
        except NoMatches:
            pass

        # Apply persisted preferences
        try:
            timeline = self.query_one("#timeline", StatusTimeline)
            timeline.display = self._prefs.timeline_visible
            timeline.timeline_hours = self._prefs.timeline_hours
        except NoMatches:
            pass

        try:
            daemon_panel = self.query_one("#daemon-panel", DaemonPanel)
            daemon_panel.display = self._prefs.daemon_panel_visible
        except NoMatches:
            pass

        # Apply show_cost preference to daemon status bar
        try:
            status_bar = self.query_one("#daemon-status", DaemonStatusBar)
            status_bar.show_cost = self._prefs.show_cost
        except NoMatches:
            pass

        # Apply monochrome preference to preview pane (#138)
        try:
            preview = self.query_one("#preview-pane", PreviewPane)
            preview.monochrome = self._prefs.monochrome
        except NoMatches:
            pass

        # Hide column headers widget initially (shown via L key)
        try:
            header_widget = self.query_one("#column-headers", Static)
            header_widget.display = self._prefs.show_column_headers
        except NoMatches:
            pass

        # Update footer with current detail level
        self._update_footer()

        # Set preview visibility from preferences
        # In compact mode (tmux split), preview is off (sister zoom enables it)
        if not self.compact:
            self.preview_visible = self._prefs.preview_visible

        # Apply pre-loaded sessions synchronously so widgets exist immediately
        if self._preloaded_sessions is not None:
            self._apply_sessions(self._preloaded_sessions)
            self._preloaded_sessions = None
        else:
            self.refresh_sessions()
        self.update_daemon_status()
        self.update_timeline()
        # Kick off status fetch immediately (widgets already exist from pre-load)
        self.update_all_statuses()

        # Event loop heartbeat probe — always on (negligible overhead)
        self._heartbeat_last = time.monotonic()
        self.set_interval(0.1, self._record_heartbeat)
        self.set_timer(4.5, lambda: self.set_interval(5, self._flush_heartbeat))
        if self._prefs.status_change_logging:
            self.set_timer(5.0, lambda: self.set_interval(5, self._flush_status_changes))

        if self.diagnostics:
            # DIAGNOSTICS MODE: No auto-refresh timers
            self._update_subtitle()  # Will include [DIAGNOSTICS]
            self.notify(
                "DIAGNOSTICS MODE: All auto-refresh disabled. Press 'r' to manually refresh.",
                severity="warning",
                timeout=10
            )
        else:
            # Normal mode: Set up all timers
            # Refresh session list every 10 seconds
            self.set_interval(10, self.refresh_sessions)
            # Fast status updates every 250ms (detect_status + capture_pane only)
            self.set_interval(0.25, self.update_focused_status)
            # Slow stats updates every 5s (claude stats + git diff — heavy file I/O)
            # Stagger the three 5s timers so background work doesn't burst all at once
            self.set_interval(5, self._update_stats_async)
            self.set_timer(1.7, lambda: self.set_interval(1, self.update_daemon_status))
            # Update timeline every 30 seconds
            self.set_interval(30, self.update_timeline)
            # Update AI summaries every 5 seconds (only runs if enabled)
            self.set_timer(3.3, lambda: self.set_interval(5, self._update_summaries_async))
            # Poll sister instances every 10 seconds (only runs if configured)
            if self.has_sisters:
                self.set_interval(10, self._poll_sisters)
                self._poll_sisters()  # Initial fetch
                # Fast poll for the focused remote agent (1.5s)
                self.set_interval(1.5, self._poll_focused_sister)
            # Refresh jobs list every 5 seconds
            self.set_interval(5, self._refresh_jobs)
            # Refresh focused job pane content every second
            self.set_interval(1, self._poll_focused_job_pane)

        # Apply initial jobs mode if requested (e.g. --jobs flag)
        if self._initial_jobs_mode:
            self.tui_mode = "jobs"

    def update_daemon_status(self) -> None:
        """Update daemon status bar (kicks off background worker)"""
        self._fetch_daemon_status_async()

    @work(thread=True, exclusive=True, group="daemon_status")
    def _fetch_daemon_status_async(self) -> None:
        """Fetch daemon status off the main thread, then apply to UI."""
        try:
            daemon_bar = self.query_one("#daemon-status", DaemonStatusBar)
        except NoMatches:
            return

        # All I/O happens here in the worker thread
        self._usage_monitor.fetch()  # Internally throttled to 90s
        monitor_state = get_monitor_daemon_state(self.tmux_session)
        from .settings import get_monitor_daemon_pid_path
        daemon_lock_held = is_daemon_lock_held(get_monitor_daemon_pid_path(self.tmux_session))

        # Gather data that DaemonStatusBar.update_status() would fetch
        asleep_ids = set()
        if daemon_bar._session_manager:
            asleep_ids = {
                s.id for s in daemon_bar._session_manager.list_sessions()
                if s.is_asleep and s.tmux_session == self.tmux_session
            }

        # Pre-compute active session names for spin rate calculation
        active_session_names = compute_active_session_names(
            monitor_state.sessions if monitor_state and monitor_state.sessions else [],
            asleep_ids,
        )

        # Fetch all volatile I/O state for the status bar (PID checks, CSV reads, etc.)
        baseline_minutes = getattr(self, 'baseline_minutes', 0)
        daemon_bar.monitor_state = monitor_state
        daemon_bar._asleep_session_ids = asleep_ids
        # Sister states for footer display (#245)
        if self.has_sisters:
            daemon_bar._sister_states = self._sister_poller.get_sister_states()
        daemon_bar.fetch_volatile_state(
            baseline_minutes=baseline_minutes,
            active_session_names=active_session_names,
        )

        # Apply results on main thread
        self.call_from_thread(
            self._apply_daemon_status, daemon_bar, monitor_state, daemon_lock_held, asleep_ids
        )

    def _apply_daemon_status(
        self,
        daemon_bar: "DaemonStatusBar",
        monitor_state,
        daemon_lock_held: bool,
        asleep_ids: set,
    ) -> None:
        """Apply daemon status results on main thread (no I/O)."""
        self._mark_event("apply_daemon_start")
        daemon_bar.monitor_state = monitor_state
        daemon_bar._asleep_session_ids = asleep_ids
        daemon_bar._usage_snapshot = self._usage_monitor.snapshot
        daemon_bar.refresh()
        self._mark_event("apply_daemon_end")

    def update_timeline(self) -> None:
        """Update the status timeline widget (kicks off background worker)"""
        self._fetch_timeline_async()

    @work(thread=True, exclusive=True, group="timeline")
    def _fetch_timeline_async(self) -> None:
        """Read timeline CSV data off the main thread, then apply to UI."""
        try:
            timeline = self.query_one("#timeline", StatusTimeline)
        except NoMatches:
            return

        # Snapshot sessions + filter state for the worker (avoid race with main thread)
        sessions = filter_visible_sessions(
            active_sessions=list(self.sessions),
            terminated_sessions=list(self._terminated_sessions.values()),
            hide_asleep=self.hide_asleep,
            show_terminated=self.show_terminated,
            show_done=self.show_done,
            collapsed_parents=self.collapsed_parents if self._prefs.sort_mode == "by_tree" else None,
        )

        # Heavy CSV I/O happens here in the worker thread
        presence_history, agent_histories = timeline.fetch_history_data(sessions)

        # Merge remote timeline data from sisters (#296)
        if self._sister_poller.has_sisters:
            remote_histories = self._sister_poller.poll_all_timelines(
                timeline.timeline_hours
            )
            agent_histories.update(remote_histories)

        # Apply on main thread
        self.call_from_thread(
            timeline.apply_history_data, sessions, presence_history, agent_histories
        )

    def _save_prefs(self) -> None:
        """Save current TUI preferences to disk."""
        self._prefs.save(self.tmux_session)

    def on_app_blur(self) -> None:
        """Terminal lost focus — show banner, remove header highlight."""
        if self.compact:
            try:
                self.query_one("#terminal-active-banner").add_class("visible")
            except NoMatches:
                pass
            try:
                self.query_one("Header").remove_class("monitor-active")
            except NoMatches:
                pass

    def on_app_focus(self) -> None:
        """Terminal gained focus — hide banner, highlight header."""
        if self.compact:
            try:
                self.query_one("#terminal-active-banner").remove_class("visible")
            except NoMatches:
                pass
            try:
                self.query_one("Header").add_class("monitor-active")
            except NoMatches:
                pass

    def on_resize(self) -> None:
        """Handle terminal resize events"""
        self._update_capture_lines()
        self.refresh()
        self.update_session_widgets()

    def _update_capture_lines(self) -> None:
        """Scale capture buffer to at least 2x terminal height."""
        height = self.size.height if self.size.height > 0 else 40
        self.detector.capture_lines = max(DEFAULT_CAPTURE_LINES, 2 * height)

    def refresh_sessions(self) -> None:
        """Refresh session list (kicks off background worker).

        Uses launcher.list_sessions() to detect terminated sessions
        (tmux windows that no longer exist, e.g., after machine reboot).
        """
        self._fetch_sessions_async()

    @work(thread=True, exclusive=True, group="refresh_sessions")
    def _fetch_sessions_async(self) -> None:
        """Read session list off the main thread, then apply to UI."""
        sessions = self.launcher.list_sessions()
        self.call_from_thread(self._apply_sessions, sessions)

    def _apply_sessions(self, sessions: list) -> None:
        """Apply refreshed session list on main thread (no I/O)."""
        # Detect new sessions for timeline refresh (#244)
        old_names = {s.name for s in self.sessions}

        self._invalidate_sessions_cache()
        # Merge local + remote sessions (#245), filtering disabled sisters (#323)
        self.sessions = sessions + self._visible_remote_sessions()
        # Resolve cross-machine parent relationships (#245)
        self._resolve_remote_parents()
        # Apply sorting (#61)
        self._sort_sessions()
        # update_session_widgets handles focus preservation internally
        # Guard against race where background worker delivers sessions before
        # the ScrollableContainer is fully mounted (#286).
        try:
            self.update_session_widgets(force_refresh=False)
        except MountError:
            return

        # Trigger timeline refresh when new sessions appear (child agents) (#244)
        new_names = {s.name for s in sessions}
        if new_names - old_names:
            self.update_timeline()

        # On first load, select the first agent and kick off async updates.
        if not self._initial_sessions_loaded:
            self._initial_sessions_loaded = True
            self.update_timeline()
            self.update_daemon_status()
            # Select first agent immediately (no timer delay)
            self._select_first_agent()
            # Kick off immediate status fetch for first agent so preview pane
            # populates right away instead of staying blank until 250ms timer (#245)
            self.update_all_statuses()

    def _recalc_column_widths(self, sessions) -> bool:
        """Recalculate max name/repo/branch widths and name-match flag.

        Returns True if any width or flag actually changed.
        """
        old = (self.max_name_width, self.max_repo_width, self.max_branch_width, self.all_names_match_repos)
        sessions = list(sessions)
        if sessions:
            self.max_name_width = max(
                (len(s.name) for s in sessions), default=8
            )
            self.max_repo_width = max(
                (len(s.repo_name or "n/a") for s in sessions), default=5
            )
            self.max_branch_width = max(
                (len(s.branch or "n/a") for s in sessions), default=5
            )
            self.all_names_match_repos = all(
                s.name == s.repo_name for s in sessions if s.repo_name
            )
        else:
            self.max_name_width = 10
            self.max_repo_width = 10
            self.max_branch_width = 10
            self.all_names_match_repos = False
        return old != (self.max_name_width, self.max_repo_width, self.max_branch_width, self.all_names_match_repos)

    def _recompute_cell_column_widths(self) -> None:
        """Recompute per-cell column widths across all visible widgets.

        Collects render_summary_cells() output from every SessionSummary
        widget, then computes max visual width per column position. Stored
        as self.column_widths for use by widget render() via pad_and_join_cells().

        This ensures all widgets align perfectly regardless of content width.
        Same compute_column_widths() function is used by CLI's align_summary_rows(),
        so testing `overcode list` validates the TUI alignment code.
        """
        from .summary_columns import render_summary_cells, compute_column_widths
        widgets = list(self.query(SessionSummary))
        if not widgets:
            self.column_widths = []
            return
        all_cells = []
        for w in widgets:
            ctx = w._build_column_context()
            cells = render_summary_cells(ctx, column_filter=w.column_visible)
            all_cells.append(cells)
        self.column_widths = compute_column_widths(all_cells)
        # Update column headers if visible
        self._update_column_headers()

    def _resolve_remote_parents(self) -> None:
        """Resolve parent_session_id for remote children whose parents are local or on other sisters.

        After merging local + remote sessions, remote children may have parent_name set
        but parent_session_id unset (because the parent wasn't available when the sister
        was polled). This function fixes cross-machine parent relationships by matching
        parent_name to session names in the combined list.

        Fixes flipping behavior where remote children appeared/disappeared from their
        parent's subtree (#245).
        """
        # Build name -> session mapping for fast lookup
        name_to_session = {s.name: s for s in self.sessions}

        for session in self.sessions:
            # Skip if already has parent_session_id set
            if session.parent_session_id:
                continue
            # Only process remote sessions that don't have a parent yet
            if not getattr(session, 'is_remote', False):
                continue

            # Extract parent_name from remote_daemon_state (contains parent_name from the sister)
            parent_name = None
            remote_daemon = getattr(session, 'remote_daemon_state', None)
            if remote_daemon and isinstance(remote_daemon, dict):
                parent_name = remote_daemon.get('parent_name')

            # Try to resolve parent by name in the merged session list
            if parent_name and parent_name in name_to_session:
                parent_session = name_to_session[parent_name]
                session.parent_session_id = parent_session.id

    def _sort_sessions(self) -> None:
        """Sort sessions based on current sort mode (#61)."""
        self.sessions = sort_sessions(self.sessions, self._prefs.sort_mode)

    def _get_cached_sessions(self) -> dict[str, Session]:
        """Get sessions with caching to reduce disk I/O.

        Returns cached session data if TTL hasn't expired, otherwise
        reloads from disk and updates the cache.
        """
        import time
        now = time.time()
        if now - self._sessions_cache_time > self._sessions_cache_ttl:
            # Cache expired, reload from disk
            self._sessions_cache = {s.id: s for s in self.session_manager.list_sessions()}
            self._sessions_cache_time = now
        return self._sessions_cache

    def _invalidate_sessions_cache(self) -> None:
        """Invalidate the sessions cache to force reload on next access."""
        self._sessions_cache_time = 0

    def _get_focused_widget(self) -> "SessionSummary | None":
        """Get the selected session widget using focused_session_index.

        Uses the app's own selection state rather than Textual's self.focused,
        which can diverge during DOM reordering or when non-session widgets
        (e.g. command bar) have focus.

        Self-healing: if the index is out of bounds but widgets exist, clamp it
        so that an agent is always focused when agents are present.
        """
        widgets = self._get_widgets_in_session_order()
        if not widgets:
            return None
        if not (0 <= self.focused_session_index < len(widgets)):
            self.focused_session_index = max(0, min(self.focused_session_index, len(widgets) - 1))
        return widgets[self.focused_session_index]

    def _any_modal_visible(self) -> bool:
        """Check if any modal dialog is currently visible.

        Queries for widgets with both 'modal' and 'visible' CSS classes.
        New modals automatically get focus protection and key blocking
        by adding classes="modal" in compose().
        """
        return bool(self.query(".modal.visible"))

    def _any_dialog_visible(self) -> bool:
        """Check if any dialog (modal or help overlay) is visible."""
        if self._any_modal_visible():
            return True
        try:
            from .tui_widgets import HelpOverlay
            help_overlay = self.query_one("#help-overlay", HelpOverlay)
            if help_overlay.has_class("visible"):
                return True
        except Exception:
            pass
        return False

    def _tui_pane_target(self) -> str:
        """Return tmux target for the TUI (top) pane, respecting pane-base-index."""
        base = get_pane_base_index()
        return f"overcode:overcode-tmux.{base}"

    def _bottom_pane_target(self) -> str:
        """Return tmux target for the bottom (terminal) pane, respecting pane-base-index."""
        base = get_pane_base_index()
        return f"overcode:overcode-tmux.{base + 1}"

    def _dialog_will_open(self) -> None:
        """Zoom the tmux monitor pane when a dialog opens (compact mode only).

        Uses tmux's pane zoom to temporarily hide the bottom (terminal)
        pane, giving the TUI the full window for rendering dialogs.
        """
        if not self.compact:
            return
        import subprocess
        target = self._tui_pane_target()
        # Don't zoom if already zoomed
        info = subprocess.run(
            ["tmux", "display-message", "-t", target, "-p", "#{window_zoomed_flag}"],
            capture_output=True, text=True,
        )
        if info.returncode == 0 and info.stdout.strip() == "1":
            return
        subprocess.run(
            ["tmux", "resize-pane", "-t", target, "-Z"],
            capture_output=True,
        )

    def _dialog_did_close(self) -> None:
        """Unzoom the tmux monitor pane when all dialogs are closed (compact mode only)."""
        if not self.compact:
            return
        # Don't unzoom if another dialog is still visible
        if self._any_dialog_visible():
            return
        # Don't unzoom if sister view or jobs view is holding the zoom open
        if self._sister_zoom_active:
            return
        if self.tui_mode == "jobs":
            return
        import subprocess
        target = self._tui_pane_target()
        info = subprocess.run(
            ["tmux", "display-message", "-t", target, "-p", "#{window_zoomed_flag}"],
            capture_output=True, text=True,
        )
        if info.returncode == 0 and info.stdout.strip() == "1":
            subprocess.run(
                ["tmux", "resize-pane", "-t", target, "-Z"],
                capture_output=True,
            )

    def _enter_sister_view(self) -> None:
        """Zoom TUI pane and show preview for viewing a sister agent.

        Called automatically when navigating to a remote agent in compact
        (tmux split) mode. The preview pane shows the sister's polled
        pane_content. The bottom terminal pane is hidden via tmux zoom.
        """
        if self._sister_zoom_active:
            return
        self._sister_zoom_active = True
        # Zoom the TUI pane (same as dialog zoom)
        self._dialog_will_open()
        # Show preview pane for sister content
        self.preview_visible = True

    def _exit_sister_view(self) -> None:
        """Restore normal compact layout when navigating back to a local agent.

        Reverses _enter_sister_view(): hides preview pane and
        unzooms the TUI pane to reveal the bottom terminal pane.
        """
        if not self._sister_zoom_active:
            return
        self._sister_zoom_active = False
        # Hide preview pane (compact mode default)
        self.preview_visible = False
        # Unzoom — but only if no dialog is holding the zoom open
        if not self._any_dialog_visible():
            import subprocess
            target = self._tui_pane_target()
            info = subprocess.run(
                ["tmux", "display-message", "-t", target, "-p", "#{window_zoomed_flag}"],
                capture_output=True, text=True,
            )
            if info.returncode == 0 and info.stdout.strip() == "1":
                subprocess.run(
                    ["tmux", "resize-pane", "-t", target, "-Z"],
                    capture_output=True,
                )

    def _should_recover_focus(self) -> bool:
        """Check if focus recovery should run.

        Returns False when an overlay is visible (fullscreen preview, help,
        any modal), the command bar is open, or focus is already on a
        session/input widget.
        """
        # Don't steal focus from overlays
        try:
            fs = self.query_one("#fullscreen-preview")
            if fs.has_class("visible"):
                return False
        except NoMatches:
            pass
        try:
            ho = self.query_one("#help-overlay")
            if ho.has_class("visible"):
                return False
        except NoMatches:
            pass
        if self._any_modal_visible():
            return False
        # Don't steal focus from command bar during instruction input (#321)
        try:
            cmd_bar = self.query_one("#command-bar")
            if cmd_bar.has_class("visible"):
                return False
        except NoMatches:
            pass
        # Only recover if focus is not on a session or input widget
        if self.focused is None:
            return True
        if isinstance(self.focused, SessionSummary):
            return False
        if isinstance(self.focused, (Input, TextArea)):
            return False
        return True

    def watch_focused_session_index(self, new_index: int) -> None:
        """Auto-focus the widget at the new index, update preview, and sync tmux."""
        if self._suppress_focus_watcher:
            return
        if self._any_modal_visible():
            return
        widget = self._get_focused_widget()
        if widget is None:
            # No widgets — exit sister zoom if active (e.g. all sisters removed)
            if self._sister_zoom_active:
                self._exit_sister_view()
            return
        if self._prefs.status_change_logging:
            self._log_status_change(
                widget.session.name, widget.detected_status, widget.detected_status,
                source="focus_switch", focused=True,
            )
        widget.focus()
        if self.preview_visible:
            self._update_preview()
        self._sync_tmux_window(widget)
        # Auto-fix window size mismatch when switching between sessions
        # (happens when terminal is resized while window is not active)
        self._fix_window_size_if_needed(widget)

    def update_focused_status(self) -> None:
        """Update all session statuses every 250ms.

        All data fetching (tmux capture_pane, claude stats, git diff) happens
        in a background thread with ThreadPoolExecutor parallelism, so updating
        all widgets is no more expensive than updating one.
        """
        # Skip if an update is already in progress
        if self._status_update_in_progress:
            return

        widgets = list(self.query(SessionSummary))
        if not widgets:
            return

        self._status_update_in_progress = True
        self._fetch_statuses_async(widgets)

    def update_all_statuses(self) -> None:
        """Trigger full async refresh of all session widgets.

        Kicks off both the fast path (detect_status) and slow path (stats/git).
        Primarily used for manual refresh ('r' key) and initial load.
        """
        # Fast path
        if not self._status_update_in_progress:
            widgets = list(self.query(SessionSummary))
            if widgets:
                self._status_update_in_progress = True
                self._fetch_statuses_async(widgets)
        # Slow path
        self._update_stats_async()

    @work(thread=True, exclusive=True, group="fast_status")
    def _fetch_statuses_async(self, widgets: list) -> None:
        """Fast path: fetch detect_status (capture_pane) only, every 250ms.

        This is the critical path for responsive preview pane updates.
        Heavy operations (claude stats, git diff) run on a separate 5s timer.
        """
        try:
            # Load fresh session data (this does file I/O but we're in a thread)
            fresh_sessions = {s.id: s for s in self.session_manager.list_sessions()}

            # Build list of sessions to check (use fresh data if available)
            sessions_to_check = []
            for widget in widgets:
                session = fresh_sessions.get(widget.session.id, widget.session)
                sessions_to_check.append((widget.session.id, session))

            # Fetch only detect_status (capture_pane) in parallel — no heavy I/O
            # Non-focused agents use reduced capture lines (STATUS_CAPTURE_LINES)
            # since their pane content is only needed for status detection, not preview.
            focused_w = self._get_focused_widget()
            focused_session_id = focused_w.session.id if focused_w else None

            def fetch_status(session):
                try:
                    if session.is_remote:
                        return (session.stats.current_state or "running", session.stats.current_task, session.pane_content or "")
                    if session.status == "terminated":
                        # Re-check to detect revival (window is uncontested)
                        return self.detector.detect_status(session)
                    if session.status == "done":
                        # Still capture pane content so preview shows output
                        content = self.detector.get_pane_content(session.tmux_window) or ""
                        return ("done", "Completed", content)
                    # Focused agent: full capture for preview pane display
                    # Non-focused: reduced capture for status detection only
                    capture = 0 if session.id == focused_session_id else STATUS_CAPTURE_LINES
                    return self.detector.detect_status(session, num_lines=capture)
                except Exception:
                    return (STATUS_WAITING_USER, "Error", "")

            sessions = [s for _, s in sessions_to_check]
            with ThreadPoolExecutor(max_workers=min(8, len(sessions))) as executor:
                results = list(executor.map(fetch_status, sessions))

            # Package results with session IDs
            status_results = {}
            raw_statuses = {}
            _diag = self._prefs.status_change_logging
            for (session_id, _), status_result in zip(sessions_to_check, results):
                status_results[session_id] = status_result
                if _diag:
                    raw_statuses[session_id] = status_result[0]

            # Enrich non-focused agents with daemon state (#291)
            # The focused agent keeps its detect_status result for preview pane
            # responsiveness. Non-focused agents use daemon's current_status
            # directly when available and fresh (< 5s old), which includes
            # heartbeat, oversight, and other enrichments already applied by
            # the daemon.
            # IMPORTANT: reuse focused_session_id from capture phase (line 850)
            # to avoid a race where focus changes between capture and enrichment,
            # causing an agent to be captured with reduced lines but treated as
            # focused (no daemon override) for enrichment.
            focused_id = focused_session_id
            status_sources = {sid: "detect" for sid in status_results} if _diag else {}
            daemon_state = get_monitor_daemon_state(self.tmux_session)
            if daemon_state and daemon_state.sessions and not daemon_state.is_stale(buffer_seconds=5.0):
                daemon_by_id = {s.session_id: s for s in daemon_state.sessions}
                for session_id in list(status_results):
                    if session_id == focused_id:
                        # Focused agent: still enrich with heartbeat/oversight
                        # from daemon (detect_status can't see these)
                        ds = daemon_by_id.get(session_id)
                        if ds:
                            status, activity, content = status_results[session_id]
                            if ds.running_from_heartbeat and status == STATUS_RUNNING:
                                status = STATUS_RUNNING_HEARTBEAT
                                status_sources[session_id] = "detect+heartbeat"
                            elif ds.waiting_for_heartbeat and status not in (STATUS_RUNNING, STATUS_RUNNING_HEARTBEAT):
                                status = STATUS_WAITING_HEARTBEAT
                                status_sources[session_id] = "detect+wait_hb"
                            elif ds.current_status == STATUS_WAITING_OVERSIGHT:
                                status = STATUS_WAITING_OVERSIGHT
                                activity = "Waiting for oversight report"
                                status_sources[session_id] = "detect+oversight"
                            status_results[session_id] = (status, activity, content)
                    else:
                        # Non-focused: use daemon's status directly
                        ds = daemon_by_id.get(session_id)
                        if ds:
                            _, _, content = status_results[session_id]
                            status_results[session_id] = (ds.current_status, ds.current_activity, content)
                            status_sources[session_id] = "daemon"

            # Extract subtree costs from daemon state (local agents)
            subtree_costs = {}
            if daemon_state and daemon_state.sessions and not daemon_state.is_stale(buffer_seconds=5.0):
                for ds in daemon_state.sessions:
                    if ds.subtree_cost_usd > 0:
                        subtree_costs[ds.session_id] = ds.subtree_cost_usd
            # Also extract from remote sessions via forwarded daemon_state
            for s in self._remote_sessions:
                rds = getattr(s, 'remote_daemon_state', None)
                if rds and rds.get('subtree_cost_usd', 0) > 0:
                    subtree_costs[s.id] = rds['subtree_cost_usd']

            # Use local summaries from TUI's summarizer (not daemon state)
            ai_summaries = {}
            for session_id, summary in self._summaries.items():
                ai_summaries[session_id] = (
                    summary.text or "",
                    summary.context or "",
                )

            # Build diagnostics (only when status_change_logging is on)
            diag_kwargs = {}
            if _diag:
                polling = getattr(self.detector, 'polling', self.detector)
                diag_kwargs = dict(
                    _diag_raw=raw_statuses, _diag_sources=status_sources,
                    _diag_focused_id=focused_id,
                    _diag_content_changed=dict(getattr(polling, '_content_changed', {})),
                    _diag_phases=dict(getattr(polling, '_last_detect_phase', {})),
                )

            # Update UI on main thread
            self.call_from_thread(
                self._apply_status_results, status_results, fresh_sessions,
                ai_summaries, subtree_costs, **diag_kwargs,
            )
        finally:
            self._status_update_in_progress = False

    @work(thread=True, exclusive=True, group="slow_stats")
    def _update_stats_async(self) -> None:
        """Slow path: fetch claude stats + git diff every 5s.

        These involve heavy file I/O (parsing JSONL session files, running
        git diff subprocess) and don't need 250ms updates. Runs independently
        from the fast status path so it never blocks preview pane updates.

        Uses a shared HistoryFile so history.jsonl is parsed at most once
        per cycle, regardless of how many sessions are checked.
        """
        if self._stats_update_in_progress:
            return
        self._stats_update_in_progress = True
        try:
            widgets = list(self.query(SessionSummary))
            if not widgets:
                return

            fresh_sessions = {s.id: s for s in self.session_manager.list_sessions()}

            sessions_to_check = []
            for widget in widgets:
                session = fresh_sessions.get(widget.session.id, widget.session)
                sessions_to_check.append((widget.session.id, session))

            # Single HistoryFile shared across all sessions — parse once, reuse N times
            history_file = HistoryFile()

            def fetch_stats(session):
                try:
                    if session.is_remote:
                        return (synthesize_remote_stats(session), session.remote_git_diff)
                    claude_stats = get_session_stats(session, history_file=history_file)
                    git_diff = None
                    if session.start_directory:
                        git_diff = get_git_diff_stats(session.start_directory)
                    return (claude_stats, git_diff)
                except Exception:
                    return (None, None)

            sessions = [s for _, s in sessions_to_check]
            with ThreadPoolExecutor(max_workers=min(8, len(sessions))) as executor:
                results = list(executor.map(fetch_stats, sessions))

            stats_results = {}
            git_diff_results = {}
            for (session_id, _), (claude_stats, git_diff) in zip(sessions_to_check, results):
                stats_results[session_id] = claude_stats
                git_diff_results[session_id] = git_diff

            self.call_from_thread(self._apply_stats_results, stats_results, git_diff_results)
        finally:
            self._stats_update_in_progress = False

    # ── Sister integration (#245) ──────────────────────────────────────

    def _poll_sisters(self) -> None:
        """Kick off sister polling in background thread."""
        self._poll_sisters_async()

    @work(thread=True, exclusive=True, group="sister_poll")
    def _poll_sisters_async(self) -> None:
        """Fetch remote sessions from all sisters."""
        remote = self._sister_poller.poll_all()
        self.call_from_thread(self._apply_remote_sessions, remote)

    def _visible_remote_sessions(self) -> List[Session]:
        """Return remote sessions excluding disabled sisters (#323)."""
        disabled = self._prefs.disabled_sisters
        if not disabled:
            return list(self._remote_sessions)
        disabled_urls = {
            s.url for s in self._sister_poller.get_sister_states()
            if s.name in disabled
        }
        return [s for s in self._remote_sessions if s.source_url not in disabled_urls]

    def _apply_remote_sessions(self, remote_sessions: List[Session]) -> None:
        """Store remote sessions and rebuild widget list."""
        self._mark_event("apply_sisters_start")
        had_remote = len(self._remote_sessions) > 0
        self._remote_sessions = remote_sessions
        self.refresh_sessions()
        # On first remote arrival, kick off timeline update so remote
        # agent timelines appear immediately instead of waiting for the
        # 30s timeline cycle (#296).
        if not had_remote and remote_sessions:
            self.update_timeline()
        self._mark_event("apply_sisters_end")

    def _poll_focused_sister(self) -> None:
        """Fast-poll the focused remote agent (1.5s) for responsive preview."""
        focused = self._get_focused_widget()
        if focused is None or not focused.session.is_remote:
            return
        session = focused.session
        if not session.source_url or not session.name:
            return
        self._poll_focused_sister_async(
            session.source_url, session.source_api_key, session.name, session.id
        )

    @work(thread=True, exclusive=True, group="focused_sister_poll")
    def _poll_focused_sister_async(
        self, source_url: str, source_api_key: str, agent_name: str, session_id: str
    ) -> None:
        """Fetch single remote agent status in background thread."""
        updated = self._sister_poller.poll_single_agent(source_url, source_api_key, agent_name)
        if updated is not None:
            self.call_from_thread(self._apply_focused_sister, updated, session_id)

    def _apply_focused_sister(self, updated_session: "Session", session_id: str) -> None:
        """Apply fast-polled remote session data to the matching widget."""
        # Update the session in _remote_sessions so the fast path picks it up
        for i, rs in enumerate(self._remote_sessions):
            if rs.id == session_id:
                self._remote_sessions[i] = updated_session
                break

        # Update the widget directly for immediate feedback
        for widget in self.query(SessionSummary):
            if widget.session.id == session_id:
                widget.session = updated_session
                # Sync pr_number from session (propagates both detection and clearing)
                widget.pr_number = updated_session.pr_number
                widget.refresh()
                break

        # Refresh preview pane if in list_preview mode
        if self.preview_visible:
            self._update_preview()

    def _optimistic_update_remote(self, session_id: str, **fields) -> None:
        """Optimistically update a remote session's local copy for instant UI feedback.

        After a successful remote API call, update the in-memory session and
        widget immediately instead of waiting for the next polling cycle (#305).
        """
        from dataclasses import replace
        for i, rs in enumerate(self._remote_sessions):
            if rs.id == session_id:
                self._remote_sessions[i] = replace(rs, **fields)
                break
        for widget in self.query(SessionSummary):
            if widget.session.id == session_id:
                widget.session = replace(widget.session, **fields)
                widget.refresh()
                break
        if self.preview_visible:
            self._update_preview()

    # ── End sister integration ────────────────────────────────────────

    def _apply_status_results(self, status_results: dict, fresh_sessions: dict,
                              ai_summaries: dict = None, subtree_costs: dict = None,
                              _diag_raw: dict = None, _diag_sources: dict = None,
                              _diag_focused_id: str = None, _diag_content_changed: dict = None,
                              _diag_phases: dict = None) -> None:
        """Apply fast-path status results to widgets (runs on main thread)."""
        self._mark_event("apply_status_start")
        prefs_changed = False
        ai_summaries = ai_summaries or {}
        subtree_costs = subtree_costs or {}
        any_has_subtree_cost = bool(subtree_costs)

        widgets = list(self.query(SessionSummary))

        for widget in widgets:
            session_id = widget.session.id

            # Update widget's session with fresh data
            if session_id in fresh_sessions:
                new_sess = fresh_sessions[session_id]
                widget.session = new_sess
                # Sync pr_number from session (propagates both detection and clearing)
                widget.pr_number = new_sess.pr_number

            # Update AI summaries (if available)
            if session_id in ai_summaries:
                widget.ai_summary_short, widget.ai_summary_context = ai_summaries[session_id]
            elif widget.session.is_remote:
                # Use remote summarizer output carried on the session
                widget.ai_summary_short = widget.session.remote_activity_summary
                widget.ai_summary_context = widget.session.remote_activity_summary_context

            # Propagate subtree cost from daemon state
            widget.subtree_cost_usd = subtree_costs.get(session_id, 0.0)
            widget.any_has_subtree_cost = any_has_subtree_cost

            # Apply status if we have results for this widget
            if session_id in status_results:
                status, activity, content = status_results[session_id]

                prev_status = self._previous_statuses.get(session_id)
                stall = compute_stall_state(
                    status, prev_status, session_id,
                    self._prefs.visited_stalled_agents,
                    widget.session.is_asleep,
                )

                # Track when session transitions TO green (working) state
                prev_was_green = prev_status is not None and is_green_status(prev_status)
                if stall.should_clear_tracking and not prev_was_green:
                    self._non_stall_since[session_id] = time.monotonic()

                # Debounced stall detection: prevents notification re-triggering
                # from brief green flickers and daemon enrichment changes
                if stall.is_new_stall:
                    non_stall_start = self._non_stall_since.pop(session_id, None)
                    active_duration = (time.monotonic() - non_stall_start) if non_stall_start else float('inf')

                    if active_duration >= 60 or prev_status is None:
                        # Sustained work or first observation → genuine new stall
                        self._prefs.visited_stalled_agents.discard(session_id)
                        prefs_changed = True
                        self._stall_start_times[session_id] = time.monotonic()
                        self._notified_stalls.discard(session_id)
                    else:
                        # Brief green flicker → restore stall timer if needed, keep _notified_stalls
                        if session_id not in self._stall_start_times:
                            self._stall_start_times[session_id] = time.monotonic()

                if stall.should_clear_tracking:
                    self._stall_start_times.pop(session_id, None)
                elif status == STATUS_WAITING_USER:
                    self._non_stall_since.pop(session_id, None)

                self._previous_statuses[session_id] = status
                widget.is_unvisited_stalled = stall.is_unvisited_stalled

                # Queue macOS notification with deferred delivery (#235)
                now_mono = time.monotonic()
                stall_age = now_mono - self._stall_start_times[session_id] if session_id in self._stall_start_times else 0
                try:
                    uptime = (datetime.now() - datetime.fromisoformat(widget.session.start_time)).total_seconds()
                except (ValueError, TypeError):
                    uptime = 0
                if should_send_stall_notification(
                    status,
                    is_notified=session_id in self._notified_stalls,
                    is_asleep=widget.session.is_asleep,
                    has_stall_start=session_id in self._stall_start_times,
                    stall_age_seconds=stall_age,
                    uptime_seconds=uptime,
                ):
                    task = widget.session.stats.current_task if widget.session.stats else None
                    self._notifier.queue(widget.session.name, task)
                    self._notified_stalls.add(session_id)

                # Auto-dismiss bell after 5s if this agent is already being viewed
                if stall.is_unvisited_stalled and self.preview_visible:
                    focused = self._get_focused_widget()
                    if focused is not None and focused.session.id == session_id:
                        self._schedule_bell_dismiss(session_id)
                elif not stall.is_unvisited_stalled and session_id in self._bell_dismiss_timers:
                    # Bell cleared by other means — cancel pending timer
                    self._bell_dismiss_timers.pop(session_id, None)

                # Diagnostic: log every color-changing status transition
                if self._prefs.status_change_logging:
                    old_status = widget.detected_status
                    if _diag_raw is not None and old_status != status:
                        raw = _diag_raw.get(session_id, "?")
                        source = (_diag_sources or {}).get(session_id, "?")
                        phase = (_diag_phases or {}).get(session_id, "?")
                        is_focused = session_id == _diag_focused_id
                        cc = (_diag_content_changed or {}).get(session_id, False)
                        self._log_status_change(
                            widget.session.name, old_status, status,
                            source=f"{source}(raw={raw}|{phase})", focused=is_focused,
                            content_changed=cc,
                        )

                # Pass None for claude_stats/git_diff — those come from the slow path
                widget.apply_status_no_refresh(status, activity, content, None, None)

        # Recompute column widths before refreshing widgets for alignment
        self._recompute_cell_column_widths()
        for widget in widgets:
            widget.refresh()

        if prefs_changed:
            self._save_prefs()

        # Update preview pane on the fast path (250ms) for responsive updates
        if self.preview_visible:
            self._update_preview()

        # Proactive focus recovery: if focus was lost or landed on a non-interactive
        # widget (e.g. mouse click on preview pane when switching windows), restore
        # it within 250ms so the selection highlight never disappears.
        if self._should_recover_focus():
            widget = self._get_focused_widget()
            if widget is not None:
                widget.focus()
        # Flush coalesced macOS notifications (#235)
        self._notifier.flush()
        self._mark_event("apply_status_end")

    def _apply_stats_results(self, stats_results: dict, git_diff_results: dict) -> None:
        """Apply slow-path stats results to widgets (runs on main thread)."""
        self._mark_event("apply_stats_start")
        changed_widgets = []
        for widget in self.query(SessionSummary):
            session_id = widget.session.id
            claude_stats = stats_results.get(session_id)
            git_diff = git_diff_results.get(session_id)
            if claude_stats is not None:
                widget.claude_stats = claude_stats
                widget.file_subagent_count = claude_stats.live_subagent_count
            if git_diff is not None:
                widget.git_diff_stats = git_diff
            if claude_stats is not None or git_diff is not None:
                changed_widgets.append(widget)
        if changed_widgets:
            self._recompute_cell_column_widths()
            for widget in changed_widgets:
                widget.refresh()
        self._mark_event("apply_stats_end")

    @work(thread=True, exclusive=True, name="summarizer")
    def _update_summaries_async(self) -> None:
        """Background thread for AI summarization.

        Only runs if summarizer is enabled. Updates are applied to widgets
        via call_from_thread.
        """
        if not self._summarizer.enabled:
            return

        # Get fresh session list (filtered to this tmux session)
        all_sessions = self.session_manager.list_sessions()
        sessions = [s for s in all_sessions if s.tmux_session == self.tmux_session]
        if not sessions:
            return

        # Update summaries (this makes API calls)
        summaries = self._summarizer.update(sessions)

        # Apply to widgets on main thread
        self.call_from_thread(self._apply_summaries, summaries)

    def _apply_summaries(self, summaries: dict) -> None:
        """Apply AI summaries to session widgets (runs on main thread)."""
        self._mark_event("apply_summaries_start")
        self._summaries = summaries
        is_enabled = self._summarizer.config.enabled

        for widget in self.query(SessionSummary):
            widget.summarizer_enabled = is_enabled
            session_id = widget.session.id
            if session_id in summaries:
                summary = summaries[session_id]
                widget.ai_summary_short = summary.text or ""
                widget.ai_summary_context = summary.context or ""
            widget.refresh()
        self._mark_event("apply_summaries_end")

    def update_session_widgets(self, force_refresh: bool = True, preserve_focus: bool = True) -> None:
        """Update the session display incrementally.

        Only adds/removes widgets when sessions change, rather than
        destroying and recreating all widgets (which causes UI stutter).

        Args:
            force_refresh: If False, only refresh widgets whose session data
                actually changed. Set to True when column widths changed or
                on structural changes that require all widgets to repaint.
            preserve_focus: If True, capture the currently focused session
                before DOM mutations and restore focused_session_index after.
                Focus is only restored to a SessionSummary if one had Textual
                focus before the update (never steals from command bar).
        """
        # Capture focus state before DOM mutations
        if preserve_focus:
            _focused_widget = self._get_focused_widget()
            _focused_session_id = _focused_widget.session.id if _focused_widget else None
            _focus_was_on_session = isinstance(self.focused, SessionSummary)
        else:
            _focused_session_id = None
            _focus_was_on_session = False

        container = self.query_one("#sessions-container", ScrollableContainer)

        # Check if any session has a cost budget / oversight timeout / PR
        any_has_budget, any_has_oversight_timeout, any_has_pr = detect_display_changes(
            self.sessions, False, False
        )

        # Read subtree costs from daemon state (local agents)
        subtree_costs = {}
        daemon_state = get_monitor_daemon_state(self.tmux_session)
        if daemon_state and daemon_state.sessions and not daemon_state.is_stale(buffer_seconds=5.0):
            for ds in daemon_state.sessions:
                if ds.subtree_cost_usd > 0:
                    subtree_costs[ds.session_id] = ds.subtree_cost_usd
        # Also extract from remote sessions via forwarded daemon_state
        for s in self._remote_sessions:
            rds = getattr(s, 'remote_daemon_state', None)
            if rds and rds.get('subtree_cost_usd', 0) > 0:
                subtree_costs[s.id] = rds['subtree_cost_usd']
        any_has_subtree_cost = bool(subtree_costs)
        # Also check widget pr_number vars (sticky — survive session replacement)
        if not any_has_pr:
            any_has_pr = any(
                getattr(w, 'pr_number', None) is not None
                for w in self.query(SessionSummary)
            )

        # Check if any agent has a model set
        any_has_model = any(s.model for s in self.sessions if s.model)

        # Check if any agent is busy_sleeping (#289)
        any_is_sleeping = any(
            getattr(w, 'detected_status', '') == "busy_sleeping"
            for w in self.query(SessionSummary)
        )

        # Build the list of sessions to display using extracted logic
        display_sessions = filter_visible_sessions(
            active_sessions=self.sessions,
            terminated_sessions=list(self._terminated_sessions.values()),
            hide_asleep=self.hide_asleep,
            show_terminated=self.show_terminated,
            show_done=self.show_done,
            collapsed_parents=self.collapsed_parents if self._prefs.sort_mode == "by_tree" else None,
        )

        # Column widths computed from exactly what will be rendered
        if self._recalc_column_widths(display_sessions):
            force_refresh = True

        # Get existing widgets and their session IDs
        existing_widgets = {w.session.id: w for w in self.query(SessionSummary)}
        existing_session_ids = set(existing_widgets.keys())

        # Check if we have an empty message widget that needs removal
        # (Static widgets that aren't SessionSummary)
        has_empty_message = any(
            isinstance(w, Static) and not isinstance(w, SessionSummary)
            for w in container.children
        )

        # Compute which widgets to add/remove
        sessions_added, sessions_removed = compute_session_widget_diff(
            existing_session_ids, [s.id for s in display_sessions]
        )

        if not sessions_added and not sessions_removed and not has_empty_message:
            # No structural changes needed - just update session data in existing widgets
            session_map = {s.id: s for s in display_sessions}
            for widget in existing_widgets.values():
                if widget.session.id in session_map:
                    new_session = session_map[widget.session.id]
                    old_budget = widget.any_has_budget
                    old_sleeping = widget.any_is_sleeping
                    # Check if anything display-relevant actually changed
                    changed = (
                        force_refresh
                        or widget.session != new_session
                        or old_budget != any_has_budget
                        or old_sleeping != any_is_sleeping
                    )
                    widget.session = new_session
                    # Sync display modes
                    widget.emoji_free = self.emoji_free
                    # Sync pr_number from session (propagates both detection and clearing)
                    widget.pr_number = new_session.pr_number
                    widget.any_has_budget = any_has_budget
                    widget.any_has_oversight_timeout = any_has_oversight_timeout
                    widget.any_is_sleeping = any_is_sleeping
                    widget.any_has_pr = any_has_pr
                    widget.any_has_model = any_has_model
                    widget.oversight_deadline = getattr(new_session, 'oversight_deadline', None)
                    widget.subtree_cost_usd = subtree_costs.get(widget.session.id, 0.0)
                    widget.any_has_subtree_cost = any_has_subtree_cost
                    # Update terminated visual state
                    if widget.session.status == "terminated":
                        widget.add_class("terminated")
                    else:
                        widget.remove_class("terminated")
                    # Only refresh if data actually changed (#218 alignment still
                    # handled via force_refresh=True when widths change)
                    if changed:
                        widget.refresh()
            # Recompute cell column widths for alignment after data update
            self._recompute_cell_column_widths()
            # Still reorder widgets to handle sort mode changes
            self._reorder_session_widgets(container)
            self._restore_focus_in_update(_focused_session_id, _focus_was_on_session)
            return

        # Remove widgets for deleted sessions
        for session_id in sessions_removed:
            widget = existing_widgets[session_id]
            widget.remove()

        # Clear empty message if we now have sessions
        if has_empty_message and display_sessions:
            container.remove_children()

        # Handle empty state
        if not display_sessions:
            if not has_empty_message:
                container.remove_children()
                container.mount(Static(
                    "\n  No active sessions.\n\n  Launch a session with:\n  overcode launch --name my-agent code\n",
                    classes="dim"
                ))
            return

        # Add widgets for new sessions
        for session in display_sessions:
            if session.id in sessions_added:
                widget = SessionSummary(session, self.detector)
                # Apply current summary detail level
                widget.summary_detail = self.SUMMARY_LEVELS[self.summary_level_index]
                # Apply current summary content mode (#140)
                widget.summary_content_mode = self.summary_content_mode
                # Apply display modes
                widget.emoji_free = self.emoji_free
                widget.show_cost = self.show_cost
                widget.any_has_budget = any_has_budget
                widget.any_has_oversight_timeout = any_has_oversight_timeout
                widget.any_is_sleeping = any_is_sleeping
                widget.any_has_pr = any_has_pr
                widget.any_has_model = any_has_model
                widget.oversight_deadline = getattr(session, 'oversight_deadline', None)
                widget.subtree_cost_usd = subtree_costs.get(session.id, 0.0)
                widget.any_has_subtree_cost = any_has_subtree_cost
                # Apply per-level column overrides
                current_level = self.SUMMARY_LEVELS[self.summary_level_index]
                widget.column_overrides = self._prefs.column_config.get(current_level, {})
                # Apply compact-mode class for prominent focus styling
                if self.compact:
                    widget.add_class("compact-mode")
                # Mark terminated sessions with visual styling and status
                if session.status == "terminated":
                    widget.add_class("terminated")
                    widget.detected_status = "terminated"
                    widget.current_activity = "(tmux window no longer exists)"
                # Set summarizer enabled state
                widget.summarizer_enabled = self._summarizer.config.enabled
                # Apply existing summary if available
                if session.id in self._summaries:
                    summary = self._summaries[session.id]
                    widget.ai_summary_short = summary.text or ""
                    widget.ai_summary_context = summary.context or ""
                container.mount(widget)
                # NOTE: Don't call update_status() here - it does blocking tmux calls
                # The 250ms interval (update_all_statuses) will update status shortly

        # Reorder widgets to match display_sessions order
        # This must run after any structural changes AND after sort mode changes
        self._reorder_session_widgets(container)
        # Recompute cell column widths for alignment after structural changes
        self._recompute_cell_column_widths()
        self._restore_focus_in_update(_focused_session_id, _focus_was_on_session)

    def _restore_focus_in_update(self, focused_session_id: str | None, focus_was_on_session: bool) -> None:
        """Restore focused_session_index after update_session_widgets DOM mutations.

        If the previously focused session still exists, move the index to its
        new position. If it was removed/filtered, clamp the index.
        Only fires the watcher (which calls .focus()) when a SessionSummary
        had Textual focus before the update — never steals from command bar.
        """
        if not focused_session_id:
            return
        widgets = self._get_widgets_in_session_order()
        if not widgets:
            return
        # Suppress watcher if focus wasn't on a session (e.g. command bar open)
        if not focus_was_on_session:
            self._suppress_focus_watcher = True
        try:
            for i, widget in enumerate(widgets):
                if widget.session.id == focused_session_id:
                    self.focused_session_index = i
                    return
            # Focused session was removed/filtered — clamp index
            self.focused_session_index = min(self.focused_session_index, len(widgets) - 1)
        finally:
            self._suppress_focus_watcher = False

    def on_session_summary_stalled_agent_visited(self, message: SessionSummary.StalledAgentVisited) -> None:
        """Handle when user visits a stalled agent - mark as visited"""
        session_id = message.session_id
        self._prefs.visited_stalled_agents.add(session_id)
        self._save_prefs()
        # Cancel any pending auto-dismiss timer
        self._bell_dismiss_timers.pop(session_id, None)

        # Update the widget's state
        for widget in self.query(SessionSummary):
            if widget.session.id == session_id:
                widget.is_unvisited_stalled = False
                widget.refresh()
                break

    def _schedule_bell_dismiss(self, session_id: str) -> None:
        """Auto-dismiss bell after 5s if the agent is already being viewed."""
        # Cancel any existing timer for this session
        self._bell_dismiss_timers.pop(session_id, None)

        def _dismiss() -> None:
            self._bell_dismiss_timers.pop(session_id, None)
            # Only dismiss if still focused on this agent
            focused = self._get_focused_widget()
            if focused is None or focused.session.id != session_id:
                return
            # Mark as visited
            self._prefs.visited_stalled_agents.add(session_id)
            self._save_prefs()
            for widget in self.query(SessionSummary):
                if widget.session.id == session_id:
                    widget.is_unvisited_stalled = False
                    widget.refresh()
                    break

        self._bell_dismiss_timers[session_id] = self.set_timer(5.0, _dismiss)

    def on_session_summary_session_selected(self, message: SessionSummary.SessionSelected) -> None:
        """Handle session selection - update .selected class to preserve highlight when unfocused"""
        session_id = message.session_id
        for widget in self.query(SessionSummary):
            if widget.session.id == session_id:
                widget.add_class("selected")
            else:
                widget.remove_class("selected")

    def _get_widgets_in_session_order(self) -> List[SessionSummary]:
        """Get session widgets sorted to match self.sessions order.

        query() returns widgets in DOM/mount order, but we want navigation
        to follow self.sessions order for consistency with display.
        """
        widgets = list(self.query(SessionSummary))
        if not widgets:
            return []
        # Build session_id -> order mapping from self.sessions
        session_order = {s.id: i for i, s in enumerate(self.sessions)}
        # Sort widgets by their session's position in self.sessions
        widgets.sort(key=lambda w: session_order.get(w.session.id, 999))
        return widgets

    def _reorder_session_widgets(self, container: ScrollableContainer) -> None:
        """Reorder session widgets in container to match session display order.

        When new widgets are mounted, they're appended at the end.
        This method reorders them to match the display order (active + terminated).
        """
        widgets = {w.session.id: w for w in self.query(SessionSummary)}
        if not widgets:
            return

        # Build display sessions list (active + terminated if enabled)
        display_sessions = list(self.sessions)
        if self.show_terminated:
            active_ids = {s.id for s in self.sessions}
            for session in self._terminated_sessions.values():
                if session.id not in active_ids:
                    display_sessions.append(session)

        # Get desired order from display_sessions
        ordered_widgets = []
        for session in display_sessions:
            if session.id in widgets:
                ordered_widgets.append(widgets[session.id])

        # Skip DOM moves if order already matches — avoids unnecessary relayout
        # which cause Textual repaint glitches every 10s
        current_order = [
            w for w in container.children if isinstance(w, SessionSummary)
        ]
        if current_order != ordered_widgets:
            # Reorder by moving each widget to the correct position.
            # Save focused widget so we can restore if move_child() drops focus.
            had_focus = self.focused
            for i, widget in enumerate(ordered_widgets):
                if i == 0:
                    container.move_child(widget, before=0)
                else:
                    container.move_child(widget, after=ordered_widgets[i - 1])
            # Restore focus if move_child() caused it to be lost
            if had_focus is not None and self.focused is None:
                had_focus.focus()

        # Update tree prefix and child count for hierarchy display (#244)
        # Always runs (not gated by reorder) so prefixes are set on first mount.
        # In tree mode: full metadata (prefix, depth, child_count) via compute_tree_metadata
        # Otherwise: lightweight child_count only via compute_child_counts
        is_tree_mode = self._prefs.sort_mode == "by_tree"
        if is_tree_mode:
            tree_meta = compute_tree_metadata(self.sessions)
            for widget in ordered_widgets:
                meta = tree_meta.get(widget.session.id)
                widget.child_count = meta.child_count if meta else 0
                widget.children_collapsed = widget.session.id in self.collapsed_parents
                widget.tree_prefix = meta.prefix if meta else ""
                widget.tree_depth = meta.depth if meta else 0
        else:
            child_counts = compute_child_counts(self.sessions)
            for widget in ordered_widgets:
                widget.child_count = child_counts.get(widget.session.id, 0)
                widget.children_collapsed = widget.session.id in self.collapsed_parents
                widget.tree_prefix = ""
                widget.tree_depth = 0

    def _sync_tmux_window(self, widget: Optional["SessionSummary"] = None) -> None:
        """Sync external tmux pane to show the focused session's window.

        When tmux_sync_target is set (e.g. by `overcode split`), syncs to
        that linked session. Otherwise syncs to the agents session directly.

        In compact mode, selecting a remote/sister agent auto-zooms the TUI
        pane and shows the preview pane with the sister's content. Selecting
        a local agent restores the normal split layout.

        Args:
            widget: The session widget to sync to. If None, uses self.focused.
        """
        if not self.tmux_sync:
            return

        try:
            target = widget if widget is not None else self.focused
            if isinstance(target, SessionSummary):
                session = target.session

                # Sister zoom: auto-enter/exit sister view in compact mode
                if self.compact and session.is_remote and not self._sister_zoom_active:
                    self._enter_sister_view()
                elif self.compact and not session.is_remote and self._sister_zoom_active:
                    self._exit_sister_view()

                window_index = session.tmux_window
                # For remote agents without a tmux window, try to sync to parent's window
                if (not window_index or window_index == "") and session.is_remote and session.parent_session_id:
                    parent = self.session_manager.get_session(session.parent_session_id)
                    if parent:
                        window_index = parent.tmux_window

                if window_index is not None and window_index != "":
                    sync_session = self.tmux_sync_target or self.tmux_session
                    self._tmux.select_window(sync_session, window_index)
        except Exception:
            pass  # Silent fail - don't disrupt navigation

    def _fix_window_size_if_needed(self, widget: "SessionSummary") -> None:
        """Auto-fix tmux window size mismatch when switching sessions.

        When terminal is resized while a session is not active, only the active
        window gets resized. When switching to that session, its window might be
        the wrong size. This method detects the mismatch and sends a tmux command
        to resize it to match the current terminal dimensions.

        The fix is silent and non-blocking — if it fails, navigation continues.
        """
        if not self.tmux_sync or not self.size or self.size.height <= 0:
            return

        try:
            session = widget.session
            window_index = session.tmux_window
            if not window_index or window_index == "":
                return

            sync_session = self.tmux_sync_target or self.tmux_session
            # Get current terminal size from the active window
            # and apply it to the target window
            current_height = self.size.height
            current_width = self.size.width

            # Get the target window's current size by querying tmux
            # If sizes don't match, resize the target window
            self._tmux.resize_window(sync_session, window_index, current_width, current_height)
        except Exception:
            pass  # Silent fail - size mismatch isn't critical

    # =========================================================================
    # Jobs Mode
    # =========================================================================

    def action_toggle_tui_mode(self) -> None:
        """Toggle between agents and jobs view."""
        self.tui_mode = "jobs" if self.tui_mode == "agents" else "agents"

    def watch_show_terminated(self, show_terminated: bool) -> None:
        """Immediately refresh jobs when ghost toggle changes."""
        if self.is_running and self.tui_mode == "jobs":
            self._refresh_jobs()

    def watch_tui_mode(self, mode: str) -> None:
        """React to tui_mode changes — swap visible containers."""
        if not self.is_running:
            return
        try:
            sessions_container = self.query_one("#sessions-container", ScrollableContainer)
            jobs_container = self.query_one("#jobs-container", ScrollableContainer)
            if mode == "jobs":
                sessions_container.display = False
                jobs_container.add_class("visible")
                jobs_container.display = True
                self._refresh_jobs()
                # In compact mode, zoom TUI and show preview (same as sister view)
                if self.compact:
                    self._dialog_will_open()
                    self.preview_visible = True
                # Focus first job widget if available
                job_widgets = list(self.query(JobSummary))
                if job_widgets:
                    self.focused_job_index = 0
                    job_widgets[0].focus()
            else:
                jobs_container.remove_class("visible")
                jobs_container.display = False
                sessions_container.display = True
                # In compact mode, hide preview and unzoom (same as exiting sister view)
                if self.compact:
                    self.preview_visible = False
                    self._dialog_did_close()
                # Refocus agents
                widget = self._get_focused_widget()
                if widget:
                    widget.focus()
        except NoMatches:
            pass
        self._update_subtitle()
        self._update_footer()
        self._update_column_headers()

    def watch_focused_job_index(self, new_index: int) -> None:
        """Focus the job widget at the new index and update preview."""
        if self.tui_mode != "jobs":
            return
        job_widgets = self._get_job_widgets()
        if not job_widgets:
            return
        if not (0 <= new_index < len(job_widgets)):
            new_index = max(0, min(new_index, len(job_widgets) - 1))
            self.focused_job_index = new_index
            return
        widget = job_widgets[new_index]
        widget.focus()
        # Remove .selected from all, add to focused
        for w in job_widgets:
            w.remove_class("selected")
        widget.add_class("selected")
        # Update preview pane
        if self.preview_visible:
            try:
                preview = self.query_one("#preview-pane", PreviewPane)
                preview.update_from_job_widget(widget)
            except NoMatches:
                pass

    def _get_job_widgets(self) -> List[JobSummary]:
        """Get job widgets in order."""
        return list(self.query(JobSummary))

    @work(thread=True, exclusive=True, group="refresh_jobs")
    def _refresh_jobs(self) -> None:
        """Refresh jobs list from state file."""
        try:
            show_completed = self.show_terminated  # Reuse the ghost toggle
            jobs = self._job_launcher.list_jobs(include_completed=show_completed)
            self.call_from_thread(self._apply_jobs, jobs)
        except Exception:
            pass

    def _apply_jobs(self, jobs: List[Job]) -> None:
        """Apply refreshed job list to TUI (main thread)."""
        self.jobs = jobs
        try:
            container = self.query_one("#jobs-container", ScrollableContainer)
        except NoMatches:
            return

        # Compute dynamic name column width (min 12, max 30)
        name_width = max((len(j.name) for j in jobs), default=12)
        name_width = max(12, min(name_width, 30))

        existing = {w.job.id: w for w in self.query(JobSummary)}
        current_ids = {j.id for j in jobs}

        # Remove widgets for deleted jobs
        for job_id, widget in existing.items():
            if job_id not in current_ids:
                widget.remove()

        # Update existing or mount new
        for job in jobs:
            if job.id in existing:
                w = existing[job.id]
                w.name_width = name_width
                w.refresh_job(job)
            else:
                widget = JobSummary(job)
                widget.monochrome = self.monochrome
                widget.emoji_free = self.emoji_free
                widget.name_width = name_width
                container.mount(widget)

        # Capture pane content for focused job
        if self.tui_mode == "jobs":
            self._update_focused_job_pane_content()

    def _update_focused_job_pane_content(self) -> None:
        """Capture tmux pane content for the focused job widget."""
        job_widgets = self._get_job_widgets()
        if not job_widgets:
            return
        idx = self.focused_job_index
        if not (0 <= idx < len(job_widgets)):
            return
        widget = job_widgets[idx]
        job = widget.job
        if job.status == "running" and job.tmux_window:
            try:
                tmux = self._job_launcher.tmux
                pane = tmux._get_pane(job.tmux_window)
                if pane:
                    lines = pane.capture_pane()
                    widget.pane_content = lines if lines else []
            except Exception:
                pass

    def _poll_focused_job_pane(self) -> None:
        """Poll focused job's tmux pane content (1s interval)."""
        if self.tui_mode != "jobs":
            return
        self._update_focused_job_pane_content()
        # Update preview pane
        job_widgets = self._get_job_widgets()
        idx = self.focused_job_index
        if job_widgets and 0 <= idx < len(job_widgets):
            widget = job_widgets[idx]
            if self.preview_visible:
                try:
                    preview = self.query_one("#preview-pane", PreviewPane)
                    preview.update_from_job_widget(widget)
                except NoMatches:
                    pass

    def _action_kill_focused_job(self) -> None:
        """Kill the focused job."""
        job_widgets = self._get_job_widgets()
        if not job_widgets:
            return
        idx = self.focused_job_index
        if not (0 <= idx < len(job_widgets)):
            return
        job = job_widgets[idx].job
        if job.status != "running":
            self.notify(f"Job '{job.name}' is not running", severity="warning")
            return
        if self._job_launcher.kill_job(job.name):
            self.notify(f"Killed job '{job.name}'")
            self._refresh_jobs()
        else:
            self.notify(f"Failed to kill job '{job.name}'", severity="error")

    def _action_clear_completed_jobs(self) -> None:
        """Clear all completed/failed/killed jobs."""
        self._job_manager.clear_completed()
        self.notify("Cleared completed jobs")
        self._refresh_jobs()

    def _action_send_enter_to_focused_job(self) -> None:
        """Send Enter to the focused job's tmux window."""
        job_widgets = self._get_job_widgets()
        if not job_widgets:
            return
        idx = self.focused_job_index
        if not (0 <= idx < len(job_widgets)):
            return
        job = job_widgets[idx].job
        if job.status == "running" and job.tmux_window:
            self._job_launcher.tmux.send_keys(job.tmux_window, "", enter=True)

    def watch_preview_visible(self, preview_visible: bool) -> None:
        """React to preview pane visibility changes."""
        if not self.is_running:
            return  # App not composed yet — nothing to update
        self._update_subtitle()

        try:
            preview = self.query_one("#preview-pane", PreviewPane)
            sessions_container = self.query_one("#sessions-container", ScrollableContainer)
            jobs_container = self.query_one("#jobs-container", ScrollableContainer)
            if preview_visible:
                sessions_container.add_class("list-mode")
                jobs_container.add_class("list-mode")
                preview.add_class("visible")
                self._update_preview()
            else:
                sessions_container.remove_class("list-mode")
                jobs_container.remove_class("list-mode")
                preview.remove_class("visible")
        except NoMatches:
            pass

    def _update_subtitle(self) -> None:
        """Update the header subtitle to show session info."""
        mode_label = "Preview" if self.preview_visible else "List"
        sync_label = " [Sync]" if self.tmux_sync else ""
        session_label = "jobs" if self.tui_mode == "jobs" else self.tmux_session
        if self.diagnostics:
            self.sub_title = f"{session_label} [{mode_label}]{sync_label} [DIAGNOSTICS]"
        else:
            self.sub_title = f"{session_label} [{mode_label}]{sync_label}"

    def _build_footer_text(self) -> str:
        """Build the footer help text string with current detail level."""
        if self.tui_mode == "jobs":
            return "J:Agents | h:Help | q:Quit | j/k:Nav | x:Kill | c:Clear done | enter:Send | g:Show done"
        level = self.SUMMARY_LEVELS[self.summary_level_index] if hasattr(self, 'summary_level_index') else "low"
        return f"s:{level} | h:Help | q:Quit | j/k:Nav | i:Send | n:New | x:Kill | m:Preview | p:Pause | d:Daemon | t:Timeline | g:Killed | J:Jobs"

    def _update_footer(self) -> None:
        """Update the footer help-text with current detail level."""
        try:
            help_text = self.query_one("#help-text", Static)
            help_text.update(self._build_footer_text())
        except NoMatches:
            pass

    def _update_column_headers(self) -> None:
        """Update the column headers widget based on current state."""
        try:
            header_widget = self.query_one("#column-headers", Static)
            if not self._prefs.show_column_headers:
                header_widget.display = False
                return
            header_widget.display = True

            if self.tui_mode == "jobs":
                from rich.text import Text
                # Compute name width from current jobs (same logic as _apply_jobs)
                nw = max((len(j.name) for j in self.jobs), default=12)
                nw = max(12, min(nw, 30))
                header = Text()
                header.append("  ", style="")
                header.append(f"{'Name':<{nw}} ", style="bold dim")
                header.append(f"{'Agent':<16} ", style="bold dim")
                header.append(f"{'Command':<80} ", style="bold dim")
                header.append(f"{'Started':>16} ", style="bold dim")
                header.append(f"{'Time':>6} ", style="bold dim")
                header.append("  ", style="")
                header.append("Status", style="bold dim")
                header_widget.update(header)
                return

            from .summary_columns import render_header_cells, resolve_column_visible
            level = self.SUMMARY_LEVELS[self.summary_level_index]
            overrides = self._prefs.column_config.get(level, {})

            def col_filter(col):
                return resolve_column_visible(col, level, overrides)

            header_line = render_header_cells(
                column_filter=col_filter,
                column_widths=self.column_widths,
            )
            header_widget.update(header_line)
        except NoMatches:
            pass

    def _select_first_agent(self) -> None:
        """Select the first agent so something is highlighted from the start."""
        try:
            widgets = list(self.query(SessionSummary))
            if widgets:
                self.focused_session_index = 0  # Watcher handles focus + preview + tmux sync
        except NoMatches:
            pass

    def _update_preview(self) -> None:
        """Update preview pane with the selected session's content.

        Uses focused_session_index (the app's own selection state) rather
        than self.focused (Textual's internal focus) because DOM reordering
        in _reorder_session_widgets() and async focus changes can cause
        self.focused to diverge from the visually highlighted row.
        """
        # Don't overwrite job preview with agent content
        if self.tui_mode == "jobs":
            return
        try:
            preview = self.query_one("#preview-pane", PreviewPane)
            widgets = self._get_widgets_in_session_order()
            if 0 <= self.focused_session_index < len(widgets):
                preview.update_from_widget(widgets[self.focused_session_index])
        except NoMatches:
            pass

    def _find_any_session_by_name(self, name: str):
        """Find a session by name, including remote sessions.

        Deprecated: prefer _find_any_session_by_id() for unambiguous routing.
        """
        # Check local sessions first
        session = self.session_manager.get_session_by_name(name)
        if session:
            return session
        # Check remote sessions in self.sessions
        for s in self.sessions:
            if s.name == name and getattr(s, 'is_remote', False):
                return s
        return None

    def _find_any_session_by_id(self, session_id: str):
        """Find a session by ID, including remote sessions."""
        if not session_id:
            return None
        session = self.session_manager.get_session(session_id)
        if session:
            return session
        for s in self.sessions:
            if s.id == session_id:
                return s
        return None

    def _resolve_command_bar_session(self, session_id: str, session_name: str):
        """Resolve session from command bar message, preferring ID over name."""
        if session_id:
            return self._find_any_session_by_id(session_id)
        return self._find_any_session_by_name(session_name)

    def on_command_bar_send_requested(self, message: CommandBar.SendRequested) -> None:
        """Handle send request from command bar."""
        session = self._resolve_command_bar_session(message.session_id, message.session_name)

        # Remote agent — dispatch through sister controller
        if session and getattr(session, 'is_remote', False):
            if self._guard_remote(session):
                return
            result = self._sister_controller.send_instruction(
                session.source_url, session.source_api_key,
                session.name, text=message.text,
            )
            if result.ok:
                self._record_instruction(message.text, message.session_name)
                self.notify(f"Sent to remote agent {message.session_name}")
            else:
                self.notify(f"Remote error: {result.error}", severity="error")
            return

        # Local agent — auto-wake sleeping agent if needed (#168)
        if session and session.is_asleep:
            self.session_manager.update_session(session.id, is_asleep=False)
            # Update widget display immediately
            for widget in self.query(SessionSummary):
                if widget.session.id == session.id:
                    widget.session.is_asleep = False
                    if widget.detected_status == "asleep":
                        widget.detected_status = "running"
                    widget.refresh()
                    break
            self.notify(f"Woke agent '{message.session_name}' to send command", severity="information")

        launcher = ClaudeLauncher(
            tmux_session=self.tmux_session,
            session_manager=self.session_manager
        )
        success = launcher.send_to_session_by_id(session.id, message.text) if session else False
        if success:
            self._record_instruction(message.text, message.session_name)
            self._invalidate_sessions_cache()  # Refresh to show updated stats
            self.notify(f"Sent to {message.session_name}")
        else:
            self.notify(f"Failed to send to {message.session_name}", severity="error")

    def on_command_bar_standing_order_requested(self, message: CommandBar.StandingOrderRequested) -> None:
        """Handle standing order request from command bar."""
        session = self._resolve_command_bar_session(message.session_id, message.session_name)
        if not session:
            self.notify(f"Session '{message.session_name}' not found", severity="error")
            return

        if getattr(session, 'is_remote', False):
            if self._guard_remote(session):
                return
            if message.text:
                result = self._sister_controller.set_standing_orders(
                    session.source_url, session.source_api_key,
                    session.name, text=message.text,
                )
            else:
                result = self._sister_controller.clear_standing_orders(
                    session.source_url, session.source_api_key, session.name,
                )
            if result.ok:
                action = "set" if message.text else "cleared"
                self.notify(f"Standing order {action} for remote {message.session_name}")
                self._optimistic_update_remote(session.id, standing_instructions=message.text)
            else:
                self.notify(f"Remote error: {result.error}", severity="error")
            return

        self.session_manager.set_standing_instructions(session.id, message.text)
        if message.text:
            self.notify(f"Standing order set for {message.session_name}")
        else:
            self.notify(f"Standing order cleared for {message.session_name}")
        self.refresh_sessions()

    def on_command_bar_value_updated(self, message: CommandBar.ValueUpdated) -> None:
        """Handle agent value update from command bar (#61)."""
        session = self._resolve_command_bar_session(message.session_id, message.session_name)
        if not session:
            self.notify(f"Session '{message.session_name}' not found", severity="error")
            return

        if getattr(session, 'is_remote', False):
            if self._guard_remote(session):
                return
            result = self._sister_controller.set_value(
                session.source_url, session.source_api_key,
                session.name, value=message.value,
            )
            if result.ok:
                self.notify(f"Value set to {message.value} for remote {message.session_name}")
                self._optimistic_update_remote(session.id, agent_value=message.value)
            else:
                self.notify(f"Remote error: {result.error}", severity="error")
            return

        self.session_manager.set_agent_value(session.id, message.value)
        self.notify(f"Value set to {message.value} for {message.session_name}")
        self.refresh_sessions()

    def on_command_bar_budget_updated(self, message: CommandBar.BudgetUpdated) -> None:
        """Handle cost budget update from command bar (#173)."""
        session = self._resolve_command_bar_session(message.session_id, message.session_name)
        if not session:
            self.notify(f"Session '{message.session_name}' not found", severity="error")
            return

        if getattr(session, 'is_remote', False):
            if self._guard_remote(session):
                return
            result = self._sister_controller.set_budget(
                session.source_url, session.source_api_key,
                session.name, usd=message.budget_usd,
            )
            if result.ok:
                if message.budget_usd > 0:
                    self.notify(f"Budget set to ${message.budget_usd:.2f} for remote {message.session_name}")
                else:
                    self.notify(f"Budget cleared for remote {message.session_name}")
                self._optimistic_update_remote(session.id, cost_budget_usd=message.budget_usd)
            else:
                self.notify(f"Remote error: {result.error}", severity="error")
            return

        self.session_manager.set_cost_budget(session.id, message.budget_usd)
        if message.budget_usd > 0:
            self.notify(f"Budget set to ${message.budget_usd:.2f} for {message.session_name}")
        else:
            self.notify(f"Budget cleared for {message.session_name}")
        self.refresh_sessions()

    def on_command_bar_annotation_updated(self, message: CommandBar.AnnotationUpdated) -> None:
        """Handle human annotation update from command bar (#74)."""
        session = self._resolve_command_bar_session(message.session_id, message.session_name)
        if not session:
            self.notify(f"Session '{message.session_name}' not found", severity="error")
            return

        if getattr(session, 'is_remote', False):
            if self._guard_remote(session):
                return
            result = self._sister_controller.set_annotation(
                session.source_url, session.source_api_key,
                session.name, text=message.annotation,
            )
            if result.ok:
                action = "set" if message.annotation else "cleared"
                self.notify(f"Annotation {action} for remote {message.session_name}")
                self._optimistic_update_remote(session.id, human_annotation=message.annotation)
            else:
                self.notify(f"Remote error: {result.error}", severity="error")
            return

        self.session_manager.set_human_annotation(session.id, message.annotation)
        if message.annotation:
            self.notify(f"Annotation set for {message.session_name}")
        else:
            self.notify(f"Annotation cleared for {message.session_name}")
        self.refresh_sessions()

    def on_command_bar_heartbeat_updated(self, message: CommandBar.HeartbeatUpdated) -> None:
        """Handle heartbeat configuration update from command bar (#171)."""
        session = self._resolve_command_bar_session(message.session_id, message.session_name)
        if not session:
            self.notify(f"Session not found: {message.session_name}", severity="error")
            return

        if getattr(session, 'is_remote', False):
            if self._guard_remote(session):
                return
            result = self._sister_controller.configure_heartbeat(
                session.source_url, session.source_api_key,
                session.name,
                enabled=message.enabled,
                frequency=str(message.frequency),
                instruction=message.instruction,
            )
            if result.ok:
                if message.enabled:
                    freq_str = format_duration(message.frequency)
                    self.notify(f"Heartbeat enabled: every {freq_str} (remote)", severity="information")
                else:
                    self.notify("Heartbeat disabled (remote)", severity="information")
                self._optimistic_update_remote(
                    session.id,
                    heartbeat_enabled=message.enabled,
                    heartbeat_frequency_seconds=message.frequency,
                    heartbeat_instruction=message.instruction,
                )
            else:
                self.notify(f"Remote error: {result.error}", severity="error")
            return

        self.session_manager.update_session(
            session.id,
            heartbeat_enabled=message.enabled,
            heartbeat_frequency_seconds=message.frequency,
            heartbeat_instruction=message.instruction,
        )

        # Wake daemon so status updates immediately (#212)
        signal_activity(self.tmux_session)

        if message.enabled:
            freq_str = format_duration(message.frequency)
            self.notify(f"Heartbeat enabled: every {freq_str}", severity="information")
        else:
            self.notify("Heartbeat disabled", severity="information")

        # Refresh session list to show updated heartbeat config
        self.refresh_sessions()

    def on_command_bar_clear_requested(self, message: CommandBar.ClearRequested) -> None:
        """Handle clear request - hide and unfocus command bar."""
        try:
            # Disable and hide the command bar
            cmd_bar = self.query_one("#command-bar", CommandBar)
            target_session_id = cmd_bar.target_session_id  # Remember before disabling
            target_session_name = cmd_bar.target_session  # Fallback for name match
            cmd_bar.query_one("#cmd-input", Input).disabled = True
            cmd_bar.query_one("#cmd-textarea", TextArea).disabled = True
            cmd_bar.remove_class("visible")

            # Focus the targeted session (not first session) to keep preview on it
            if self.sessions:
                widgets = self._get_widgets_in_session_order()
                if widgets:
                    # Find widget matching target session by ID, fall back to name
                    target_widget = None
                    for i, w in enumerate(widgets):
                        if target_session_id and w.session.id == target_session_id:
                            target_widget = w
                            self.focused_session_index = i
                            break
                        elif not target_session_id and w.session.name == target_session_name:
                            target_widget = w
                            self.focused_session_index = i
                            break
                    if target_widget:
                        target_widget.focus()
                    else:
                        self.focused_session_index = min(self.focused_session_index, len(widgets) - 1)
                        widgets[self.focused_session_index].focus()
                    if self.preview_visible:
                        self._update_preview()
        except NoMatches:
            pass

    def on_command_bar_new_agent_requested(self, message: CommandBar.NewAgentRequested) -> None:
        """Handle new agent creation request."""
        agent_name = message.agent_name
        directory = message.directory
        bypass_permissions = message.bypass_permissions

        # Validate name (no spaces, reasonable length)
        if not agent_name or len(agent_name) > 50:
            self.notify("Invalid agent name", severity="error")
            return

        if ' ' in agent_name:
            self.notify("Agent name cannot contain spaces", severity="error")
            return

        # Create new agent using launcher
        launcher = ClaudeLauncher(
            tmux_session=self.tmux_session,
            session_manager=self.session_manager
        )

        try:
            launcher.launch(
                name=agent_name,
                start_directory=directory,
                dangerously_skip_permissions=bypass_permissions,
                agent_teams=message.agent_teams,
                claude_agent=message.claude_agent,
            )
            dir_info = f" in {directory}" if directory else ""
            perm_info = " (bypass mode)" if bypass_permissions else ""
            agent_info = f" (agent: {message.claude_agent})" if message.claude_agent else ""
            self.notify(f"Created agent: {agent_name}{dir_info}{perm_info}{agent_info}", severity="information")
            # Refresh to show new agent
            self.refresh_sessions()
        except Exception as e:
            self.notify(f"Failed to create agent: {e}", severity="error")

    def on_command_bar_fork_requested(self, message: CommandBar.ForkRequested) -> None:
        """Handle fork agent request (#347)."""
        source_session = message.source_session
        fork_name = message.fork_name

        # Validate name
        if not fork_name or len(fork_name) > 50:
            self.notify("Invalid fork name", severity="error")
            return
        if ' ' in fork_name:
            self.notify("Fork name cannot contain spaces", severity="error")
            return

        # Remote agents: fork via sister controller (#368)
        if getattr(source_session, 'is_remote', False):
            try:
                result = self._sister_controller.fork_agent(
                    source_session.source_url,
                    source_session.source_api_key,
                    source_session.name,
                    fork_name,
                )
                if result.ok:
                    self.notify(f"Forked remote '{source_session.name}' → '{fork_name}'", severity="information")
                    self.refresh_sessions()
                else:
                    self.notify(f"Remote fork failed: {result.error}", severity="error")
            except Exception as e:
                self.notify(f"Failed to fork remote agent: {e}", severity="error")
            return

        launcher = ClaudeLauncher(
            tmux_session=self.tmux_session,
            session_manager=self.session_manager
        )

        try:
            result = launcher.launch_fork(
                name=fork_name,
                source_session=source_session,
            )
            if result:
                self.notify(f"Forked '{source_session.name}' → '{fork_name}'", severity="information")
                self.refresh_sessions()
            else:
                self.notify(f"Failed to fork '{source_session.name}'", severity="error")
        except Exception as e:
            self.notify(f"Failed to fork: {e}", severity="error")

    def on_command_bar_new_remote_agent_requested(self, message: CommandBar.NewRemoteAgentRequested) -> None:
        """Handle remote agent launch request (#310)."""
        sister_name = message.sister_name
        agent_name = message.agent_name
        directory = message.directory
        permissions = message.permissions

        from .config import get_sister_by_name
        sister_config = get_sister_by_name(sister_name)
        if not sister_config:
            self.notify(f"Sister '{sister_name}' not found", severity="error")
            return

        # Check sister is reachable before launching
        for state in self._sister_poller.get_sister_states():
            if state.name == sister_name and not state.reachable:
                self.notify(f"Sister '{sister_name}' is unreachable", severity="warning")
                return

        try:
            result = self._sister_controller.launch_agent(
                sister_url=sister_config["url"],
                api_key=sister_config.get("api_key", ""),
                directory=directory or ".",
                name=agent_name,
                permissions=permissions,
            )
        except Exception as e:
            self.notify(f"Remote launch failed: {e}", severity="error")
            return

        if result.ok:
            self.notify(f"Remote agent '{agent_name}' launched on {sister_name}", severity="information")
        else:
            self.notify(f"Remote launch failed: {result.error}", severity="error")

    def _ensure_monitor_daemon(self) -> None:
        """Start the Monitor Daemon if not running.

        Called automatically on TUI mount to ensure continuous monitoring.
        The Monitor Daemon handles status tracking, time accumulation,
        stats sync, and user presence detection.
        """
        # Check lock file first (authoritative: daemon holds flock for its lifetime)
        from .settings import get_monitor_daemon_pid_path
        if is_daemon_lock_held(get_monitor_daemon_pid_path(self.tmux_session)):
            return  # Already running

        # Fallback: PID file check (covers startup window before lock is acquired)
        if is_monitor_daemon_running(self.tmux_session):
            return

        pid = spawn_daemon([
            sys.executable, "-m", "overcode.monitor_daemon",
            "--session", self.tmux_session,
        ])
        if pid:
            self.notify("Monitor Daemon started", severity="information")
        else:
            self.notify("Failed to start Monitor Daemon", severity="warning")

    def _execute_kill(self, focused: "SessionSummary", session_name: str, session_id: str) -> None:
        """Execute the actual kill operation after confirmation."""
        # Save a copy of the session for showing when show_terminated is True
        session_copy = focused.session
        # Mark it as terminated for display purposes
        from dataclasses import replace
        terminated_session = replace(session_copy, status="terminated")

        # Use launcher to kill the session
        launcher = ClaudeLauncher(
            tmux_session=self.tmux_session,
            session_manager=self.session_manager
        )

        if launcher.kill_session(session_name):
            self.notify(f"Killed agent: {session_name}", severity="information")

            # Store in terminated sessions cache for ghost mode
            self._terminated_sessions[session_id] = terminated_session

            # Remove from self.sessions so j/k ordering stays consistent
            self.sessions = [s for s in self.sessions if s.id != session_id]

            # Remove the widget (will be re-added if show_terminated is True)
            focused.remove()
            # Update session cache
            if session_id in self._sessions_cache:
                del self._sessions_cache[session_id]
            # If showing terminated sessions, refresh to add it back
            if self.show_terminated:
                self.update_session_widgets()

            # Focus next available agent (uses session order for j/k consistency)
            widgets = self._get_widgets_in_session_order()
            if widgets:
                self.focused_session_index = min(self.focused_session_index, len(widgets) - 1)
                # Watcher handles .focus(), preview update, and tmux sync
        else:
            self.notify(f"Failed to kill agent: {session_name}", severity="error")

    def _execute_cleanup(self, focused: "SessionSummary", session_name: str, session_id: str) -> None:
        """Clean up a terminated/done agent: archive and remove from display."""
        self.session_manager.delete_session(session_id)

        self.notify(f"Cleaned up agent: {session_name}", severity="information")

        # Remove from self.sessions so j/k ordering stays consistent
        self.sessions = [s for s in self.sessions if s.id != session_id]

        # Remove from caches
        if session_id in self._terminated_sessions:
            del self._terminated_sessions[session_id]
        if session_id in self._sessions_cache:
            del self._sessions_cache[session_id]
        # Remove the widget
        focused.remove()

        # Focus next available agent (uses session order for j/k consistency)
        widgets = self._get_widgets_in_session_order()
        if widgets:
            self.focused_session_index = min(self.focused_session_index, len(widgets) - 1)
            # Watcher handles .focus(), preview update, and tmux sync

    def _execute_restart(self, focused: "SessionSummary") -> None:
        """Execute the actual restart operation after confirmation (#133).

        Sends Ctrl-C to kill the current Claude process, then restarts it
        with the same configuration (directory, permissions).
        If the tmux window is gone (terminated agent), delegates to _execute_revive.
        """
        import os
        from .tmux_manager import TmuxManager
        session = focused.session
        session_name = session.name
        tmux = TmuxManager(self.tmux_session)

        # If the tmux window is gone, revive instead of restart
        if not tmux.window_exists(session.tmux_window):
            self._execute_revive(focused, tmux)
            return

        # Build the claude command based on permissiveness mode
        claude_command = os.environ.get("CLAUDE_COMMAND", "claude")
        cmd_parts = [claude_command]

        if session.permissiveness_mode == "bypass":
            cmd_parts.append("--dangerously-skip-permissions")
        elif session.permissiveness_mode == "permissive":
            cmd_parts.extend(["--permission-mode", "dontAsk"])

        cmd_str = " ".join(cmd_parts)

        # Send Ctrl-C to kill the current process
        if not tmux.send_keys(session.tmux_window, "C-c", enter=False):
            self.notify(f"Failed to send Ctrl-C to '{session_name}'", severity="error")
            return

        # Brief delay to allow process to terminate
        import time
        time.sleep(0.5)

        # Send the claude command to restart
        if tmux.send_keys(session.tmux_window, cmd_str, enter=True):
            self.notify(f"Restarted agent: {session_name}", severity="information")
            # Reset session stats for fresh start
            self.session_manager.update_stats(
                session.id,
                current_task="Restarting..."
            )
            # Clear the claude session IDs since this is a new claude instance
            self.session_manager.update_session(session.id, claude_session_ids=[])
        else:
            self.notify(f"Failed to restart agent: {session_name}", severity="error")

    def _execute_revive(self, focused: "SessionSummary", tmux: "TmuxManager") -> None:
        """Revive a terminated agent by creating a new tmux window and resuming.

        If the agent has an active_claude_session_id, resumes that session.
        Otherwise starts a fresh claude instance.
        """
        import os
        import uuid as _uuid
        session = focused.session
        session_name = session.name

        # Generate new window name with unique suffix
        new_session_id = str(_uuid.uuid4())
        window_label = f"{session_name}-{new_session_id[:4]}"

        # Create new tmux window
        window_name = tmux.create_window(window_label, session.start_directory)
        if window_name is None:
            self.notify(f"Failed to create tmux window for '{session_name}'", severity="error")
            return

        # Build the claude command
        claude_command = os.environ.get("CLAUDE_COMMAND", "claude")
        if session.active_claude_session_id:
            # Resume existing session — `claude --resume` (no `code` subcommand)
            if claude_command == "claude":
                cmd_parts = ["claude", "--resume", session.active_claude_session_id]
            else:
                cmd_parts = [claude_command, "--resume", session.active_claude_session_id]
        else:
            # Fresh start
            cmd_parts = [claude_command]

        # Permission flags
        if session.permissiveness_mode == "bypass":
            cmd_parts.append("--dangerously-skip-permissions")
        elif session.permissiveness_mode == "permissive":
            cmd_parts.extend(["--permission-mode", "dontAsk"])

        # Agent persona
        if session.claude_agent:
            cmd_parts.extend(["--agent", session.claude_agent])

        # Environment prefix
        env_prefix = f"OVERCODE_SESSION_NAME={session_name} OVERCODE_SESSION_ID={session.id} OVERCODE_TMUX_SESSION={self.tmux_session}"

        # Parent env vars
        if session.parent_session_id:
            parent = self.session_manager.get_session(session.parent_session_id)
            if parent:
                env_prefix += f" OVERCODE_PARENT_SESSION_ID={parent.id} OVERCODE_PARENT_NAME={parent.name}"

        # Agent teams
        if session.agent_teams:
            env_prefix += " CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1"

        cmd_str = f"{env_prefix} {' '.join(cmd_parts)}"

        # Send command to new window
        if not tmux.send_keys(window_name, cmd_str, enter=True):
            tmux.kill_window(window_name)
            self.notify(f"Failed to revive agent: {session_name}", severity="error")
            return

        # Update session state
        self.session_manager.update_session(
            session.id,
            tmux_window=window_name,
            status="running",
        )
        self.session_manager.update_stats(
            session.id,
            current_task="Reviving..."
        )

        # Remove from terminated cache
        if session.id in self._terminated_sessions:
            del self._terminated_sessions[session.id]

        resume_info = " (resuming session)" if session.active_claude_session_id else ""
        self.notify(f"Revived agent: {session_name}{resume_info}", severity="information")
        self.refresh_sessions()

    def action_open_column_config(self) -> None:
        """Open the column configuration modal (#178).

        Edits the currently active detail level. Full shows all columns
        and cannot be configured.
        """
        current_level = self.SUMMARY_LEVELS[self.summary_level_index]
        if current_level == "full":
            self.notify("Full shows all columns", severity="information")
            return
        try:
            modal = self.query_one("#summary-config-modal", SummaryConfigModal)
            overrides = self._prefs.column_config.get(current_level, {})
            self._dialog_will_open()
            modal.show(current_level, overrides, self)
        except NoMatches:
            pass

    def on_summary_config_modal_config_changed(self, message: SummaryConfigModal.ConfigChanged) -> None:
        """Handle column configuration changes from modal (#178)."""
        level = message.level
        if message.overrides:
            self._prefs.column_config[level] = message.overrides
        elif level in self._prefs.column_config:
            # Empty overrides after reset — remove the key
            del self._prefs.column_config[level]
        self._save_prefs()

        # Push updated overrides to all widgets
        current_level = self.SUMMARY_LEVELS[self.summary_level_index]
        new_overrides = self._prefs.column_config.get(current_level, {})
        for widget in self.query(SessionSummary):
            widget.column_overrides = new_overrides
            widget.refresh()
        self._recompute_cell_column_widths()

        self.notify(f"Column config saved for {level}", severity="information")
        self._dialog_did_close()

    def on_summary_config_modal_cancelled(self, message: SummaryConfigModal.Cancelled) -> None:
        """Handle modal cancellation (#178)."""
        # Restore original overrides
        current_level = self.SUMMARY_LEVELS[self.summary_level_index]
        original_overrides = self._prefs.column_config.get(current_level, {})
        for widget in self.query(SessionSummary):
            widget.column_overrides = original_overrides
            widget.refresh()
        self._recompute_cell_column_widths()
        self._dialog_did_close()

    def action_open_new_agent_defaults(self) -> None:
        """Open the new-agent defaults modal."""
        from .config import get_new_agent_defaults
        try:
            modal = self.query_one("#new-agent-defaults-modal", NewAgentDefaultsModal)
            self._dialog_will_open()
            modal.show(get_new_agent_defaults(), self)
        except NoMatches:
            pass

    def on_new_agent_defaults_modal_defaults_changed(self, message: NewAgentDefaultsModal.DefaultsChanged) -> None:
        """Handle new-agent defaults applied from modal."""
        from .config import save_new_agent_defaults
        save_new_agent_defaults(message.defaults)
        self.notify("Defaults saved", severity="information")
        self._dialog_did_close()

    def on_new_agent_defaults_modal_cancelled(self, message: NewAgentDefaultsModal.Cancelled) -> None:
        """Handle new-agent defaults modal cancellation."""
        self._dialog_did_close()

    def on_agent_select_modal_agent_selected(self, message: AgentSelectModal.AgentSelected) -> None:
        """Handle agent selection from modal."""
        self._dialog_did_close()
        try:
            cmd_bar = self.query_one("#command-bar", CommandBar)
            cmd_bar.new_agent_claude_agent = message.agent_name
            cmd_bar._transition_to_name_step()
            cmd_bar.focus_input()
        except NoMatches:
            pass

    def on_agent_select_modal_agent_select_skipped(self, message: AgentSelectModal.AgentSelectSkipped) -> None:
        """Handle agent selection skipped (q/Esc)."""
        self._dialog_did_close()
        try:
            cmd_bar = self.query_one("#command-bar", CommandBar)
            cmd_bar.new_agent_claude_agent = None
            cmd_bar._transition_to_name_step()
            cmd_bar.focus_input()
        except NoMatches:
            pass

    def action_open_sister_selection(self) -> None:
        """Open the sister selection modal (#323)."""
        sisters = [
            {"name": s.name, "url": s.url}
            for s in self._sister_poller.get_sister_states()
        ]
        if not sisters:
            self.notify("No sisters configured", severity="warning")
            return
        try:
            modal = self.query_one("#sister-selection-modal", SisterSelectionModal)
            self._dialog_will_open()
            modal.show(sisters, self._prefs.disabled_sisters, self)
        except NoMatches:
            pass

    def on_sister_selection_modal_selection_changed(self, message: SisterSelectionModal.SelectionChanged) -> None:
        """Handle sister visibility changes from modal (#323)."""
        self._prefs.disabled_sisters = message.disabled_sisters
        self._save_prefs()
        # Re-filter remote sessions and rebuild widget list
        self.refresh_sessions()
        count = len(message.disabled_sisters)
        if count:
            self.notify(f"{count} sister(s) hidden", severity="information")
        else:
            self.notify("All sisters visible", severity="information")
        self._dialog_did_close()

    def on_sister_selection_modal_cancelled(self, message: SisterSelectionModal.Cancelled) -> None:
        """Handle sister selection modal cancellation (#323)."""
        self._dialog_did_close()

    # -- Instruction history (#376) ------------------------------------------

    def _record_instruction(self, text: str, agent_name: str) -> None:
        """Record an instruction in the history ring buffer."""
        from .tui_widgets.instruction_history_modal import HistoryEntry, MAX_HISTORY

        self._instruction_history.insert(0, HistoryEntry(text=text, agent_name=agent_name))
        self._instruction_history = self._instruction_history[:MAX_HISTORY]

    def action_open_instruction_history(self) -> None:
        """Open the instruction history modal (#376)."""
        if not self._instruction_history:
            self.notify("No instructions sent yet — send one with 'i' first", severity="warning")
            return
        modal = self.query_one("#instruction-history-modal", InstructionHistoryModal)
        self._dialog_will_open()
        modal.show(self._instruction_history, self)

    def on_instruction_history_modal_reinject_requested(
        self, message: InstructionHistoryModal.ReinjectRequested
    ) -> None:
        """Handle reinject request from instruction history modal (#376)."""
        focused = self.focused
        if not isinstance(focused, SessionSummary):
            # No agent focused — pre-fill the command bar so user can pick a target
            self.action_focus_command_bar()
            try:
                command_bar = self.query_one("#command-bar", CommandBar)
                input_widget = command_bar.query_one("#cmd-input")
                input_widget.value = message.text
            except NoMatches:
                pass
            self._dialog_did_close()
            return

        session = focused.session
        if getattr(session, 'is_remote', False):
            if self._guard_remote(session):
                self._dialog_did_close()
                return
            result = self._sister_controller.send_instruction(
                session.source_url, session.source_api_key,
                session.name, text=message.text,
            )
            if result.ok:
                self._record_instruction(message.text, session.name)
                self.notify(f"Reinjected to remote agent {session.name}")
            else:
                self.notify(f"Remote error: {result.error}", severity="error")
            self._dialog_did_close()
            return

        launcher = ClaudeLauncher(
            tmux_session=self.tmux_session,
            session_manager=self.session_manager
        )
        if launcher.send_to_session_by_id(session.id, message.text):
            self._record_instruction(message.text, session.name)
            self._invalidate_sessions_cache()
            self.notify(f"Reinjected to {session.name}")
        else:
            self.notify(f"Failed to send to {session.name}", severity="error")
        self._dialog_did_close()

    def on_instruction_history_modal_cancelled(
        self, message: InstructionHistoryModal.Cancelled
    ) -> None:
        """Handle instruction history modal dismissal (#376)."""
        self._dialog_did_close()

    # Throttle TUI heartbeat writes to once per 5 seconds
    _last_heartbeat_write: float = 0.0

    def on_key(self, event: events.Key) -> None:
        """Signal activity to daemon on any keypress."""
        signal_activity(self.tmux_session)

        # Write TUI heartbeat (throttled to every 5s)
        now = time.monotonic()
        if now - self._last_heartbeat_write >= 5.0:
            self._last_heartbeat_write = now
            write_tui_heartbeat(self.tmux_session)

        # Auto-recover if focus was lost or landed on a non-interactive widget
        # (e.g., clicking the terminal window focuses the preview pane)
        if self._should_recover_focus():
            widget = self._get_focused_widget()
            if widget is not None:
                widget.focus()

        # Handle Escape to close fullscreen preview
        try:
            from .tui_widgets import FullscreenPreview
            fs_preview = self.query_one("#fullscreen-preview", FullscreenPreview)
            if fs_preview.has_class("visible") and event.key == "escape":
                fs_preview.hide()
                event.stop()
                return
        except Exception:
            pass

        # Handle Escape to close help overlay (#175)
        try:
            from .tui_widgets import HelpOverlay
            help_overlay = self.query_one("#help-overlay", HelpOverlay)
            if help_overlay.has_class("visible") and event.key == "escape":
                help_overlay.remove_class("visible")
                self._dialog_did_close()
                event.stop()
        except Exception:
            pass

    # Actions incompatible with compact mode (overcode tmux)
    _COMPACT_BLOCKED_ACTIONS = frozenset({
        "toggle_preview",      # m — no preview pane toggle in compact
        "expand_preview",      # f — no fullscreen preview
    })

    def action_quit(self) -> None:
        """Quit the app, or detach tmux client in compact (split) mode."""
        if self.compact:
            # Detach the tmux client — returns user to their previous session
            import subprocess
            subprocess.run(["tmux", "detach-client"], capture_output=True)
        else:
            self.exit()

    def _resize_split(self, delta: int) -> None:
        """Resize the tmux split pane by delta rows (compact mode only)."""
        if not self.compact:
            return
        import subprocess
        subprocess.run(
            ["tmux", "resize-pane", "-t", self._tui_pane_target(),
             "-U" if delta > 0 else "-D", str(abs(delta))],
            capture_output=True,
        )
        # Resize linked session windows to match the new bottom pane size
        linked = self.tmux_sync_target
        if linked:
            result = subprocess.run(
                ["tmux", "list-windows", "-t", linked, "-F", "#{window_id}"],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                for win_id in result.stdout.strip().splitlines():
                    subprocess.run(
                        ["tmux", "resize-window", "-t", win_id, "-A"],
                        capture_output=True,
                    )

    def action_split_grow(self) -> None:
        """Grow the monitor pane (shrink terminal pane)."""
        self._resize_split(3)

    def action_split_shrink(self) -> None:
        """Shrink the monitor pane (grow terminal pane)."""
        self._resize_split(-3)

    def check_action(self, action: str, parameters: tuple) -> bool | None:
        """Check if an action should be allowed (#175).

        When help overlay is visible, only allow help toggle and quit.
        Other actions are blocked - pressing those keys just closes help.
        """
        # Block incompatible actions in compact mode (overcode tmux)
        if self.compact and action in self._COMPACT_BLOCKED_ACTIONS:
            return False

        # Block actions when fullscreen preview is visible
        try:
            from .tui_widgets import FullscreenPreview
            fs_preview = self.query_one("#fullscreen-preview", FullscreenPreview)
            if fs_preview.has_class("visible"):
                if action in ("expand_preview", "quit"):
                    return True
                fs_preview.hide()
                return False
        except Exception:
            pass

        # Only intercept when help is visible
        try:
            from .tui_widgets import HelpOverlay
            help_overlay = self.query_one("#help-overlay", HelpOverlay)
            if help_overlay.has_class("visible"):
                # Allow these actions when help is visible
                if action in ("toggle_help", "quit"):
                    return True
                # Block all other actions - close help instead
                help_overlay.remove_class("visible")
                self._dialog_did_close()
                return False
        except Exception:
            pass

        # Block actions when any modal is visible (generic — covers all .modal widgets)
        if self._any_modal_visible():
            if action == "quit":
                return True
            return False

        # Default: allow the action
        return True

    # ── Event loop heartbeat probe ──────────────────────────────────────

    def _record_heartbeat(self) -> None:
        """Record one heartbeat tick. Runs every 100ms on the event loop."""
        now = time.monotonic()
        if self._heartbeat_last > 0:
            delta_ms = (now - self._heartbeat_last) * 1000.0
            iso_ts = datetime.now().isoformat(timespec="milliseconds")
            self._heartbeat_log.append((iso_ts, f"{delta_ms:.1f}", ""))
        self._heartbeat_last = now

    def _mark_event(self, name: str) -> None:
        """Record a named event marker in the heartbeat log."""
        now = time.monotonic()
        delta_ms = (now - self._heartbeat_last) * 1000.0 if self._heartbeat_last > 0 else 0.0
        iso_ts = datetime.now().isoformat(timespec="milliseconds")
        self._heartbeat_log.append((iso_ts, f"{delta_ms:.1f}", name))
        self._heartbeat_last = now

    def _flush_heartbeat(self) -> None:
        """Write buffered heartbeat data to CSV. Runs every 5s."""
        if not self._heartbeat_log:
            return
        buf = self._heartbeat_log
        self._heartbeat_log = []
        try:
            path = self._heartbeat_csv_path
            path.parent.mkdir(parents=True, exist_ok=True)
            write_header = not path.exists()
            with open(path, "a") as f:
                if write_header:
                    f.write("timestamp,delta_ms,event\n")
                for ts, delta, event in buf:
                    f.write(f"{ts},{delta},{event}\n")
        except OSError:
            pass  # Best effort

    def _log_status_change(self, agent_name: str, old_status: str, new_status: str,
                           source: str, focused: bool, content_changed: bool = False) -> None:
        """Record a status change event for diagnostics."""
        iso_ts = datetime.now().isoformat(timespec="milliseconds")
        self._status_change_log.append(
            (iso_ts, agent_name, old_status, new_status, source, "Y" if focused else "N", "Y" if content_changed else "N")
        )

    def _flush_status_changes(self) -> None:
        """Write buffered status change data to CSV."""
        if not self._status_change_log:
            return
        buf = self._status_change_log
        self._status_change_log = []
        try:
            path = self._status_change_csv_path
            path.parent.mkdir(parents=True, exist_ok=True)
            write_header = not path.exists()
            with open(path, "a") as f:
                if write_header:
                    f.write("timestamp,agent,old_status,new_status,source,focused,content_changed\n")
                for row in buf:
                    f.write(",".join(row) + "\n")
        except OSError:
            pass

    # ── End heartbeat probe ──────────────────────────────────────────

    def on_unmount(self) -> None:
        """Clean up terminal state on exit"""
        import sys
        # Stop the summarizer (release API client resources)
        self._summarizer.stop()

        # Flush remaining diagnostic data
        self._flush_heartbeat()
        if self._prefs.status_change_logging:
            self._flush_status_changes()

        # Ensure mouse tracking is disabled
        sys.stdout.write('\033[?1000l')  # Disable mouse tracking
        sys.stdout.write('\033[?1002l')  # Disable cell motion tracking
        sys.stdout.write('\033[?1003l')  # Disable all motion tracking
        sys.stdout.flush()


def run_tui(
    tmux_session: str = "agents",
    diagnostics: bool = False,
    sync_target: str | None = None,
    initial_jobs_mode: bool = False,
):
    """Run the TUI supervisor.

    Args:
        sync_target: If set, auto-enable tmux_sync and target this session
            for window switching (used by `overcode split`).
    """
    import os
    import sys

    # Ensure we're using a proper terminal
    if not sys.stdout.isatty():
        print("Error: Must run in a TTY terminal", file=sys.stderr)
        sys.exit(1)

    # Force terminal size detection
    os.environ.setdefault('TERM', 'xterm-256color')

    app = SupervisorTUI(tmux_session, diagnostics=diagnostics, initial_jobs_mode=initial_jobs_mode)

    # If a sync target is provided (e.g. from `overcode tmux`), enable compact mode:
    # auto-sync, tree-only, no expand/preview/timeline
    # Sisters ARE enabled — selecting a remote agent auto-zooms the TUI pane
    # and shows the preview pane with polled sister content.
    if sync_target:
        app.tmux_sync_target = sync_target
        app.tmux_sync = True
        app.compact = True
        # preview_visible defaults to False — correct for compact mode.
        # Hide timeline (real estate is precious in the top pane)
        app._prefs.timeline_visible = False

    # Use driver=None to auto-detect, and size will be detected from terminal
    app.run()


if __name__ == "__main__":
    import sys
    tmux_session = sys.argv[1] if len(sys.argv) > 1 else "agents"
    run_tui(tmux_session)
