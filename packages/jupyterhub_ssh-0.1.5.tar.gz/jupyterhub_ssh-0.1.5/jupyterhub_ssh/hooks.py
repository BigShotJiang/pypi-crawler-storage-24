"""
JupyterHub spawner hook — injects SSH sidecar + authorized keys at spawn time.

Usage in jupyterhub_config.py:

    from jupyterhub_ssh.hooks import make_ssh_pre_spawn_hook

    c.KubeSpawner.pre_spawn_hook = make_ssh_pre_spawn_hook(
        sidecar_image="ghcr.io/groundsada/jhub-ssh-sidecar:latest",
        namespace="jupyterhub",
    )
"""

import logging

from jupyterhub_ssh.sidecar_spec import (
    ssh_sidecar_container,
    ssh_shared_volume,
    ssh_shared_volume_mount,
)

log = logging.getLogger(__name__)


def make_ssh_pre_spawn_hook(
    sidecar_image: str = "ghcr.io/groundsada/jhub-ssh-sidecar:latest",
    namespace: str = "jupyterhub",
    ssh_port: int = 2222,
    key_store=None,
    home_pvc_volume_name: str = None,
):
    """
    Factory that returns a pre_spawn_hook coroutine for KubeSpawner.

    Args:
        sidecar_image:       Docker image for the SSH sidecar container.
        namespace:           Kubernetes namespace (for KubernetesSecretKeyStore).
        ssh_port:            Port sshd listens on inside the pod.
        key_store:           SSHKeyStore instance. Defaults to KubernetesSecretKeyStore.
        home_pvc_volume_name: If the user pod already mounts a PVC named this as
                             the home volume, the sidecar will mount the same PVC.
                             If None, an emptyDir shared volume is used.
    """
    if key_store is None:
        from jupyterhub_ssh.keys import KubernetesSecretKeyStore
        key_store = KubernetesSecretKeyStore(namespace=namespace)

    async def pre_spawn_hook(spawner):
        username = spawner.user.name
        log.info("jhub-ssh: pre_spawn_hook for user %s", username)

        # ── 1. Get or create SSH public key for this user ─────────────────────
        try:
            private_key, public_key = await key_store.get_or_create_keypair(username)
            if private_key:
                log.info(
                    "jhub-ssh: Generated new SSH key pair for %s. "
                    "Private key available once via /api/users/%s/ssh-key",
                    username, username,
                )
                # Stash private key temporarily so the API handler can return it once.
                # It is never persisted beyond this spawn lifecycle.
                spawner._jhub_ssh_private_key = private_key
            else:
                log.debug("jhub-ssh: Existing SSH key found for %s", username)
                spawner._jhub_ssh_private_key = None
        except Exception:
            log.exception("jhub-ssh: Failed to get/create SSH key for %s — skipping sidecar", username)
            return

        # ── 2. Determine the home volume name ─────────────────────────────────
        # KubeSpawner creates the home PVC volume under its volumeNameTemplate
        # (e.g. "volume-{escaped_username}"). We need the sidecar to mount
        # that same volume. If spawner exposes pvc_name we can derive it;
        # otherwise fall back to an emptyDir named "home".
        home_vol_name = home_pvc_volume_name
        if home_vol_name is None and hasattr(spawner, "pvc_name") and spawner.pvc_name:
            # KubeSpawner names the volume after the PVC by convention.
            # Check if a volumeNameTemplate is configured; otherwise use pvc_name.
            vol_tpl = getattr(spawner, "storage_pvc_ensure", True)
            if vol_tpl:
                # Derive from spawner.volumes dict which KubeSpawner populates
                # with the rendered volumeNameTemplate before hook runs.
                spawner_volumes = getattr(spawner, "volumes", []) or []
                for vol in spawner_volumes:
                    if isinstance(vol, dict) and "persistentVolumeClaim" in vol:
                        home_vol_name = vol.get("name")
                        break
                if home_vol_name is None:
                    # Fall back: KubeSpawner default is volume name == pvc_name
                    home_vol_name = spawner.pvc_name

        # ── 3. Build sidecar container spec ───────────────────────────────────
        sidecar = ssh_sidecar_container(
            authorized_key=public_key,
            image=sidecar_image,
            ssh_port=ssh_port,
            home_volume_name=home_vol_name or "home",
        )

        # ── 4. Attach sidecar to spawner ──────────────────────────────────────
        existing = list(getattr(spawner, "extra_containers", None) or [])
        if not any(c.get("name") == "ssh-sidecar" for c in existing):
            existing.append(sidecar)
        spawner.extra_containers = existing

        # ── 5. Add home emptyDir only when there's no PVC ─────────────────────
        extra_volumes = list(getattr(spawner, "extra_volumes", None) or [])
        if home_vol_name is None:
            # No PVC — add an emptyDir so containers can share /home/jovyan
            shared_vol = ssh_shared_volume(existing_home_volume_name=None)
            if shared_vol and not any(v.get("name") == "home" for v in extra_volumes):
                extra_volumes.append(shared_vol)
            spawner.extra_volumes = extra_volumes

        # ── 5. Expose SSH port info via environment ────────────────────────────
        env = dict(getattr(spawner, "environment", None) or {})
        env["JHUB_SSH_PORT"] = str(ssh_port)
        spawner.environment = env

        log.info(
            "jhub-ssh: Attached SSH sidecar (port %d) to %s's pod",
            ssh_port, username,
        )

    return pre_spawn_hook
