"""
Kubernetes sidecar container spec for the JupyterHub SSH sidecar.

This module is imported by the spawner hook (jupyterhub-ext/jupyterhub_ssh/hooks.py).
It returns the dict structures that KubeSpawner accepts for:
  - extra_containers
  - extra_volumes
  - extra_volume_mounts
"""

from typing import Optional


def ssh_sidecar_container(
    authorized_key: Optional[str],
    image: str = "ghcr.io/groundsada/jhub-ssh-sidecar:latest",
    ssh_port: int = 2222,
    cpu_limit: str = "100m",
    memory_limit: str = "64Mi",
    cpu_request: str = "10m",
    memory_request: str = "16Mi",
    home_volume_name: str = "home",
) -> dict:
    """
    Return a Kubernetes container spec dict for the SSH sidecar.

    Args:
        authorized_key: The user's SSH public key string (e.g. "ssh-ed25519 AAAA...").
                        Passed as JHUB_SSH_AUTHORIZED_KEY env var.
        image:          Sidecar image reference.
        ssh_port:       Port sshd listens on inside the pod (default 2222).
        *_limit/request: Resource constraints.

    Returns:
        A dict matching the Kubernetes container spec schema, usable directly
        as an element of KubeSpawner.extra_containers.
    """
    env = []
    if authorized_key:
        env.append({
            "name": "JHUB_SSH_AUTHORIZED_KEY",
            "value": authorized_key,
        })

    return {
        "name": "ssh-sidecar",
        "image": image,
        "ports": [
            {
                "name": "ssh",
                "containerPort": ssh_port,
                "protocol": "TCP",
            }
        ],
        "env": env,
        "resources": {
            "limits": {"cpu": cpu_limit, "memory": memory_limit},
            "requests": {"cpu": cpu_request, "memory": memory_request},
        },
        "volumeMounts": [
            {
                # Mount the same home volume as the notebook container so SSH
                # sessions see /home/jovyan. The volume name is passed in from
                # the hook after inspecting KubeSpawner's volume configuration.
                "name": home_volume_name,
                "mountPath": "/home/jovyan",
            }
        ],
        "readinessProbe": {
            "tcpSocket": {"port": ssh_port},
            "initialDelaySeconds": 3,
            "periodSeconds": 10,
            "failureThreshold": 3,
        },
        "livenessProbe": {
            "tcpSocket": {"port": ssh_port},
            "initialDelaySeconds": 10,
            "periodSeconds": 30,
            "failureThreshold": 3,
        },
        # Runs fully non-root as jovyan (UID 1000) with UsePrivilegeSeparation=no.
        # No elevated capabilities needed — compatible with restrictive cluster policies.
        "securityContext": {
            "runAsUser": 1000,
            "runAsGroup": 1000,
            "allowPrivilegeEscalation": False,
            "capabilities": {
                "drop": ["ALL"],
            },
        },
    }


def ssh_shared_volume(existing_home_volume_name: Optional[str] = None) -> Optional[dict]:
    """
    Return an extra volume spec if the notebook container does not already
    provide a 'home' volume.

    If KubeSpawner already mounts a PVC as 'home', pass its name here and
    this returns None (no extra volume needed — sidecar just mounts it too).

    Args:
        existing_home_volume_name: Name of the existing PVC volume, if any.

    Returns:
        A Kubernetes volume dict, or None if not needed.
    """
    if existing_home_volume_name:
        # The PVC volume already exists on the pod; sidecar will mount it.
        return None
    # No persistent home — use an emptyDir shared between containers.
    return {
        "name": "home",
        "emptyDir": {},
    }


def ssh_shared_volume_mount(mount_path: str = "/home/jovyan") -> dict:
    """Return the volumeMount dict for the notebook container's home dir."""
    return {
        "name": "home",
        "mountPath": mount_path,
    }
