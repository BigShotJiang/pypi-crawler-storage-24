"""Parquet-based data cache."""
