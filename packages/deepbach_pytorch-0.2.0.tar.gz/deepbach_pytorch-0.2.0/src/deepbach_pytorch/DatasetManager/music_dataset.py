"""
Abstract base class for music datasets.

Bug fix vs. original:
  - data_loaders(): num_workers was hardcoded to 4 for the training DataLoader,
    which causes WinError 1455 (page-file exhaustion) on Windows multiprocessing.
    It is now a parameter defaulting to 0. Pass num_workers=4 on Linux/macOS
    for faster loading if desired.
  - Added weights_only=False to torch.load for forward compatibility with
    PyTorch >= 2.0 which changed the default to True (breaks TensorDataset load).
"""

from abc import ABC, abstractmethod
import os
import platform
import torch
from torch.utils.data import TensorDataset, DataLoader


# Detect Windows so callers get a safe default without manual configuration
_IS_WINDOWS = platform.system() == 'Windows'
_DEFAULT_WORKERS = 0 if _IS_WINDOWS else 4


class MusicDataset(ABC):
    """
    Abstract Base Class for music datasets.
    """

    def __init__(self, cache_dir):
        self._tensor_dataset = None
        self.cache_dir       = cache_dir

    @abstractmethod
    def iterator_gen(self):
        """Return an iterator over the dataset."""
        pass

    @abstractmethod
    def make_tensor_dataset(self):
        """:return: TensorDataset"""
        pass

    @abstractmethod
    def get_score_tensor(self, score):
        """
        :param score: music21 score object
        :return: torch tensor (score representation)
        """
        pass

    @abstractmethod
    def get_metadata_tensor(self, score):
        """
        :param score: music21 score object
        :return: torch tensor (metadata representation)
        """
        pass

    @abstractmethod
    def transposed_score_and_metadata_tensors(self, score, semi_tone):
        """
        :param score:      music21 score object
        :param semi_tone:  int, semitones to transpose (+12 to -12)
        :return:           transposed score tensor
        """
        pass

    @abstractmethod
    def extract_score_tensor_with_padding(self, tensor_score, start_tick, end_tick):
        """
        :return: tensor_score[:, start_tick:end_tick] with start / end padding
        """
        pass

    @abstractmethod
    def extract_metadata_with_padding(self, tensor_metadata, start_tick, end_tick):
        pass

    @abstractmethod
    def empty_score_tensor(self, score_length):
        """:return: long tensor initialised with START indices"""
        pass

    @abstractmethod
    def random_score_tensor(self, score_length):
        """:return: long tensor initialised with random indices"""
        pass

    @abstractmethod
    def tensor_to_score(self, tensor_score):
        """:return: music21 score object"""
        pass

    # -----------------------------------------------------------------------
    # TensorDataset property with transparent caching
    # -----------------------------------------------------------------------

    @property
    def tensor_dataset(self):
        """
        Lazily loads or computes the TensorDataset.

        On first access (or when the cache does not exist):
          - calls make_tensor_dataset(), which also populates note2index_dicts
          - saves the result to disk
        On subsequent accesses:
          - loads from disk (fast)
          - note2index_dicts must already be populated by dataset_manager.py
            which pickles and restores the full dataset object separately.
        """
        if self._tensor_dataset is None:
            if self.tensor_dataset_is_cached():
                print(f'Loading TensorDataset for {self.__repr__()}')
                # weights_only=False required for TensorDataset objects
                # (PyTorch >= 2.0 changed the default to True)
                self._tensor_dataset = torch.load(
                    self.tensor_dataset_filepath,
                    weights_only=False
                )
            else:
                print(f'Creating {self.__repr__()} TensorDataset'
                      f' since it is not cached')
                self._tensor_dataset = self.make_tensor_dataset()
                torch.save(self._tensor_dataset, self.tensor_dataset_filepath)
                print(f'TensorDataset for {self.__repr__()} '
                      f'saved in {self.tensor_dataset_filepath}')
        return self._tensor_dataset

    @tensor_dataset.setter
    def tensor_dataset(self, value):
        self._tensor_dataset = value

    def tensor_dataset_is_cached(self):
        return os.path.exists(self.tensor_dataset_filepath)

    @property
    def tensor_dataset_filepath(self):
        tensor_datasets_cache_dir = os.path.join(self.cache_dir, 'tensor_datasets')
        if not os.path.exists(tensor_datasets_cache_dir):
            os.mkdir(tensor_datasets_cache_dir)
        return os.path.join(tensor_datasets_cache_dir, self.__repr__())

    @property
    def filepath(self):
        datasets_cache_dir = os.path.join(self.cache_dir, 'datasets')
        if not os.path.exists(datasets_cache_dir):
            os.mkdir(datasets_cache_dir)
        return os.path.join(self.cache_dir, 'datasets', self.__repr__())

    # -----------------------------------------------------------------------
    # DataLoaders
    # -----------------------------------------------------------------------

    def data_loaders(self, batch_size, split=(0.85, 0.10), num_workers=None):
        """
        Return (train, val, test) DataLoaders from self.tensor_dataset.

        :param batch_size:  int
        :param split:       (train_frac, val_frac) — test gets the remainder
        :param num_workers: worker processes for the train DataLoader.
                            Defaults to 0 on Windows, 4 elsewhere.
                            Set to 0 if you encounter multiprocessing errors.
        """
        assert sum(split) < 1, "train + val fractions must sum to less than 1"

        if num_workers is None:
            num_workers = _DEFAULT_WORKERS

        dataset      = self.tensor_dataset
        num_examples = len(dataset)
        a, b         = split

        train_dataset = TensorDataset(*dataset[: int(a * num_examples)])
        val_dataset   = TensorDataset(*dataset[int(a * num_examples):
                                               int((a + b) * num_examples)])
        eval_dataset  = TensorDataset(*dataset[int((a + b) * num_examples):])

        train_dl = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,   # FIX: was hardcoded 4 (crashes on Windows)
            pin_memory=(num_workers > 0),
            drop_last=True,
        )
        val_dl = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
            pin_memory=False,
            drop_last=True,
        )
        eval_dl = DataLoader(
            eval_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
            pin_memory=False,
            drop_last=True,
        )
        return train_dl, val_dl, eval_dl
