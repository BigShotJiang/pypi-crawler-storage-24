# deepbach_pytorch/__init__.py

import os
import sys
import shutil

PACKAGE_ROOT = os.path.dirname(os.path.abspath(__file__))
if PACKAGE_ROOT not in sys.path:
    sys.path.insert(0, PACKAGE_ROOT)

import torch
import music21
from tqdm import tqdm

from .DeepBach.model_manager import DeepBach
from .DatasetManager.dataset_manager import DatasetManager
from .DatasetManager.metadata import FermataMetadata, TickMetadata, KeyMetadata


def _get_default_dataset():
    dataset_manager = DatasetManager()
    metadatas = [
        FermataMetadata(),
        TickMetadata(subdivision=4),
        KeyMetadata()
    ]
    
    dataset = dataset_manager.get_dataset(
        name='bach_chorales',
        voice_ids=[0, 1, 2, 3],
        metadatas=metadatas,
        sequences_size=8,
        subdivision=4
    )
    return dataset


def _get_default_model(dataset=None):
    if dataset is None:
        dataset = _get_default_dataset()
    
    model = DeepBach(
        dataset=dataset,
        note_embedding_dim=20,
        meta_embedding_dim=20,
        num_layers=2,
        lstm_hidden_size=256,
        dropout_lstm=0.5,
        linear_hidden_size=256
    )
    return model


def _ensure_models_dir(models_dir=None):
    if models_dir is None:
        models_dir = os.path.join(PACKAGE_ROOT, 'models')
    else:
        models_dir = os.path.abspath(models_dir)

    if not os.path.exists(models_dir):
        raise FileNotFoundError(
            f"Model directory not found: {models_dir}\n"
            f"Please ensure pretrained weights are downloaded to this directory.\n"
        )
    return models_dir


def _load_pretrained_weights(model, models_dir=None):
    """
    Load pretrained weights with full mismatch handling.

    Handles two sources of shape mismatch between a saved checkpoint and the
    current model:

    1. note_embeddings  — vocab may have grown because make_tensor_dataset()
       added new tokens ('B##3', 'OOR', etc.) into note2index_dicts.
       Strategy: expand the saved weight matrix with zero-rows so it fits the
       current (larger) embedding table; new rows are left as zeros and will
       be learned during fine-tuning.

    2. mlp_predictions (output projection) — its output size equals the main
       voice vocab size, so it must also be resized when the vocab grew.
       Strategy: same zero-padding approach on the weight/bias of the last
       Linear layer.

    For both cases we resize the saved tensor before calling load_state_dict,
    so load_state_dict can run with strict=True (or strict=False as a fallback).
    If the current size is SMALLER than the checkpoint (extremely rare), we
    log a warning and skip that key to avoid index errors later.
    """
    models_dir = _ensure_models_dir(models_dir)

    print(f">>> Loading pretrained weights from {models_dir}...")

    device_map = 'cuda' if torch.cuda.is_available() else 'cpu'

    for i in range(4):
        found = False
        target_suffix = f",{i},20,20,2,256,0.5,256)"

        for fname in os.listdir(models_dir):
            if not fname.endswith(target_suffix):
                continue

            model_path = os.path.join(models_dir, fname)
            print(f"\n  Loading voice {i}...")

            try:
                loaded_state  = torch.load(model_path, map_location=device_map)
                current_state = model.voice_models[i].state_dict()
                had_mismatch  = False

                for key in list(loaded_state.keys()):
                    loaded_tensor  = loaded_state[key]
                    if key not in current_state:
                        continue
                    current_tensor = current_state[key]

                    if loaded_tensor.shape == current_tensor.shape:
                        continue  # perfect match, nothing to do

                    had_mismatch = True
                    print(f"    WARNING: shape mismatch for '{key}'")
                    print(f"      Checkpoint : {loaded_tensor.shape}")
                    print(f"      Model      : {current_tensor.shape}")

                    # ---- note_embeddings: 2-D tensor [vocab, embed_dim] ----
                    if 'note_embeddings' in key and loaded_tensor.dim() == 2:
                        ckpt_vocab, embed_dim = loaded_tensor.shape
                        curr_vocab            = current_tensor.shape[0]

                        if curr_vocab > ckpt_vocab:
                            # Vocab grew: pad checkpoint weight with zeros so
                            # new token rows start at zero and are trained.
                            print(f"      Strategy : pad checkpoint "
                                  f"{ckpt_vocab} -> {curr_vocab} rows (zeros for new tokens)")
                            padded = torch.zeros(curr_vocab, embed_dim,
                                                 dtype=loaded_tensor.dtype)
                            padded[:ckpt_vocab] = loaded_tensor
                            loaded_state[key]   = padded
                        else:
                            # Vocab shrank — keep current model weights untouched.
                            print(f"      Strategy : skip (vocab shrank, "
                                  f"keeping current model weights)")
                            del loaded_state[key]

                    # ---- mlp_predictions last Linear: weight [out, in] ----
                    elif 'mlp_predictions' in key and loaded_tensor.dim() == 2:
                        ckpt_out, in_feat = loaded_tensor.shape
                        curr_out          = current_tensor.shape[0]

                        if curr_out > ckpt_out:
                            print(f"      Strategy : pad output projection weight "
                                  f"{ckpt_out} -> {curr_out} rows")
                            padded = torch.zeros(curr_out, in_feat,
                                                 dtype=loaded_tensor.dtype)
                            padded[:ckpt_out] = loaded_tensor
                            loaded_state[key] = padded
                        else:
                            print(f"      Strategy : skip output projection "
                                  f"(output size shrank)")
                            del loaded_state[key]

                    # ---- mlp_predictions bias: 1-D tensor [out] ----
                    elif 'mlp_predictions' in key and loaded_tensor.dim() == 1:
                        ckpt_out = loaded_tensor.shape[0]
                        curr_out = current_tensor.shape[0]

                        if curr_out > ckpt_out:
                            print(f"      Strategy : pad output projection bias "
                                  f"{ckpt_out} -> {curr_out}")
                            padded = torch.zeros(curr_out, dtype=loaded_tensor.dtype)
                            padded[:ckpt_out] = loaded_tensor
                            loaded_state[key] = padded
                        else:
                            print(f"      Strategy : skip output projection bias "
                                  f"(output size shrank)")
                            del loaded_state[key]

                    else:
                        # Unknown mismatch — skip this key so load_state_dict
                        # does not raise a shape error.
                        print(f"      Strategy : skip (unhandled mismatch type)")
                        del loaded_state[key]

                # strict=False lets us skip keys we deliberately removed above
                model.voice_models[i].load_state_dict(loaded_state, strict=False)

                if had_mismatch:
                    print(f"  OK: Voice {i} weights loaded successfully "
                          f"(mismatch handled via padding)")
                else:
                    print(f"  OK: Voice {i} weights loaded successfully")

                found = True

            except RuntimeError as e:
                print(f"  ERROR: Voice {i} weight loading failed")
                print(f"     Error: {e}")
                import traceback
                traceback.print_exc()
                raise

            break  # matched this voice, move to next

        if not found:
            raise FileNotFoundError(
                f"Weights for voice {i} not found.\n"
                f"Expected file ending with: {target_suffix}\n"
                f"Search directory: {models_dir}"
            )

    print("\nOK: All weights loaded successfully\n")


def _to_cuda_if_available(model):
    if torch.cuda.is_available():
        model.cuda()
        print(f"OK: Model moved to GPU: {torch.cuda.get_device_name(0)}")
    else:
        print("WARNING: GPU not detected, using CPU mode (slower)")
    return model


def harmonize(input_file, output_path="output.xml", num_iterations=500, 
              temperature=1.0, batch_size_per_voice=8, voice_index_range=None, random_init=None,
              melody_voice=0, keep_melody=True, models_dir=None):
    
    print("\n" + "="*70)
    print("DeepBach Harmony Generation")
    print("="*70)
    
    input_file = os.path.abspath(input_file)
    output_path = os.path.abspath(output_path)
    
    print("\n>>> Initializing model...")
    dataset = _get_default_dataset()
    model = _get_default_model(dataset)
    
    _load_pretrained_weights(model, models_dir)
    
    _to_cuda_if_available(model)
    model.eval_phase()
    
    print(f"\n>>> Reading input melody: {input_file}")
    if not os.path.exists(input_file):
        raise FileNotFoundError(f"Input file does not exist: {input_file}")
    
    try:
        user_score = music21.converter.parse(input_file)
    except Exception as e:
        raise ValueError(
            f"Failed to parse input file: {input_file}\n"
            f"Supported formats: .mid, .midi, .xml, .mxl\n"
            f"Error details: {e}"
        )
    
    print(">>> Converting melody to tensor...")
    try:
        score_tensor = dataset.get_score_tensor(
            user_score,
            offsetStart=0.,
            offsetEnd=user_score.flat.highestTime
        )
    except Exception as e:
        raise ValueError(
            f"Failed to convert melody to tensor: {e}\n"
            f"Ensure the input file contains valid note information."
        )
    
    metadata_tensor = dataset.get_metadata_tensor(user_score)
    sequence_length_ticks = score_tensor.shape[1]
    
    print(f"  Melody length: {sequence_length_ticks} ticks "
          f"({sequence_length_ticks / 16:.1f} measures)")
    
    if melody_voice not in [0, 1, 2, 3]:
        raise ValueError(
            f"melody_voice must be an integer between 0-3, received: {melody_voice}"
        )
    
    actual_voice_index_range = voice_index_range
    if actual_voice_index_range is None:
        if keep_melody:
            other_voices = [i for i in range(4) if i != melody_voice]
            actual_voice_index_range = [min(other_voices), max(other_voices) + 1]
        else:
            actual_voice_index_range = [0, 4]
            
    actual_random_init = random_init
    if actual_random_init is None:
        actual_random_init = True
    
    print(f"\n>>> Generation Parameters:")
    print(f"  Iterations: {num_iterations}")
    print(f"  Temperature: {temperature}")
    print(f"  Batch Size: {batch_size_per_voice}")
    print(f"  Keep Melody: {keep_melody} (Voice Index Range: {actual_voice_index_range})")
    print(f"  Random Initialization: {actual_random_init}")
    if keep_melody:
        print(f"  Melody Voice: {melody_voice} (0=Soprano, 1=Alto, 2=Tenor, 3=Bass)")
    
    print(f"\n>>> Generating harmony (this may take a while)...")
    try:
        final_score, _, _ = model.generation(
            num_iterations=num_iterations,
            sequence_length_ticks=sequence_length_ticks,
            tensor_chorale=score_tensor,
            tensor_metadata=metadata_tensor,
            time_index_range_ticks=None,
            voice_index_range=actual_voice_index_range,
            random_init=actual_random_init,
            temperature=temperature,
            batch_size_per_voice=batch_size_per_voice
        )
    except Exception as e:
        raise RuntimeError(f"Error during generation: {e}")
    
    print(f"\n>>> Saving results...")
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
    
    try:
        final_score.write('musicxml', fp=output_path)
    except Exception as e:
        raise RuntimeError(f"Could not save output file: {e}")
    
    print("="*70)
    print(f"OK: Success! File saved to: {output_path}")
    print("="*70 + "\n")
    
    return final_score


def generate_from_scratch(sequence_length_ticks=64, num_iterations=500, 
                          temperature=1.0, batch_size_per_voice=8, 
                          voice_index_range=None, random_init=True, models_dir=None):
    
    print("\n" + "="*70)
    print("DeepBach Free Composition - Generating from scratch")
    print("="*70)
    
    print("\n>>> Initializing model...")
    dataset = _get_default_dataset()
    model = _get_default_model(dataset)
    
    _load_pretrained_weights(model, models_dir)
    _to_cuda_if_available(model)
    model.eval_phase()
    
    actual_voice_index_range = voice_index_range if voice_index_range is not None else [0, 4]
    
    print(f"\n>>> Generation Parameters:")
    print(f"  Length: {sequence_length_ticks} ticks ({sequence_length_ticks / 16:.1f} measures)")
    print(f"  Iterations: {num_iterations}")
    print(f"  Temperature: {temperature}")
    print(f"  Batch Size: {batch_size_per_voice}")
    print(f"  Voice Index Range: {actual_voice_index_range}")
    
    print(f"\n>>> Generating composition...")
    try:
        score, _, _ = model.generation(
            num_iterations=num_iterations,
            sequence_length_ticks=sequence_length_ticks,
            tensor_chorale=None,
            tensor_metadata=None,
            time_index_range_ticks=None,
            voice_index_range=actual_voice_index_range,
            random_init=random_init,
            temperature=temperature,
            batch_size_per_voice=batch_size_per_voice
        )
    except Exception as e:
        raise RuntimeError(f"Error during generation: {e}")
    
    print("="*70)
    print("OK: Generation complete!")
    print("="*70 + "\n")
    
    return score


def train_from_scratch(num_epochs=50, batch_size=32, models_dir=None):
    print("\n" + "="*70)
    print("DeepBach Training from Scratch")
    print("="*70)
    
    if models_dir is None:
        models_dir = os.path.join(os.getcwd(), 'models')
    else:
        models_dir = os.path.abspath(models_dir)
        
    if os.path.exists(models_dir):
        print(f"\n>>> WARNING: Model directory already exists. New training may overwrite weights: {models_dir}")
    os.makedirs(models_dir, exist_ok=True)
    
    print("\n>>> Initializing dataset and model...")
    dataset = _get_default_dataset()
    model = _get_default_model(dataset)
    
    print()
    _to_cuda_if_available(model)
    
    try:
        print(f"\n{'='*70}")
        print("Starting Training")
        print(f"{'='*70}")
        print(f"Epochs: {num_epochs}")
        print(f"Batch Size: {batch_size}")
        print(f"Dataset: Bach Chorales (371 pieces)")
        print(f"Model Save Path: {models_dir}")
        print(f"{'='*70}\n")
        
        model.train(batch_size=batch_size, num_epochs=num_epochs)
        
        print(f"\n{'='*70}")
        print("OK: Training complete!")
        print(f"Models saved to: {models_dir}")
        print(f"{'='*70}\n")
        
        return model
        
    except Exception as e:
        print(f"\n{'='*70}")
        print(f"ERROR: Training failed: {e}")
        print(f"{'='*70}\n")
        raise RuntimeError(f"Error during training: {e}")


def finetune(num_epochs=5, batch_size=32, voice_indices=None, models_dir=None):
    print("\n" + "="*70)
    print("DeepBach Fine-tuning")
    print("="*70)
    
    if models_dir is None:
        models_dir = os.path.join(PACKAGE_ROOT, 'models')
    
    print("\n>>> Initializing model...")
    dataset = _get_default_dataset()
    model = _get_default_model(dataset)
    
    _load_pretrained_weights(model, models_dir)
    
    print()
    _to_cuda_if_available(model)
    
    if voice_indices is None:
        voices_to_finetune = [0, 1, 2, 3]
    else:
        voices_to_finetune = voice_indices
        for idx in voices_to_finetune:
            if idx not in [0, 1, 2, 3]:
                raise ValueError(f"Invalid voice index in voice_indices: {idx}")
    
    try:
        print(f"\n{'='*70}")
        print("Starting Fine-tuning on Pretrained Model")
        print(f"{'='*70}")
        print(f"Epochs: {num_epochs}")
        print(f"Batch Size: {batch_size}")
        print(f"Voices to fine-tune: {voices_to_finetune}")
        print(f"{'='*70}\n")
        
        for voice_idx in voices_to_finetune:
            print(f"\n>>> Fine-tuning voice {voice_idx} ...")
            model.train(
                main_voice_index=voice_idx,
                batch_size=batch_size,
                num_epochs=num_epochs
            )
        
        print(f"\n{'='*70}")
        print("OK: Fine-tuning complete! Weights saved.")
        print(f"Model Save Path: {models_dir}")
        print(f"{'='*70}\n")
        
        return model
        
    except Exception as e:
        print(f"\n{'='*70}")
        print(f"ERROR: Fine-tuning failed: {e}")
        print(f"{'='*70}\n")
        raise RuntimeError(f"Error during fine-tuning: {e}")


def create_model(dataset=None):
    return _get_default_model(dataset)


def load_model(dataset=None, models_dir=None):
    model = _get_default_model(dataset)
    _load_pretrained_weights(model, models_dir)
    return model


def check_pretrained_weights(models_dir=None):
    if models_dir is None:
        models_dir = os.path.join(PACKAGE_ROOT, 'models')
        
    if not os.path.exists(models_dir):
        return {
            'complete': False,
            'models_dir': models_dir,
            'found_weights': 0,
            'required_weights': 4,
            'missing_voices': [0, 1, 2, 3],
            'error': f'Model directory does not exist: {models_dir}'
        }
    
    found_weights = 0
    missing_voices = []
    
    for i in range(4):
        target_suffix = f",{i},20,20,2,256,0.5,256)"
        found = False
        for fname in os.listdir(models_dir):
            if fname.endswith(target_suffix):
                found = True
                found_weights += 1
                break
        if not found:
            missing_voices.append(i)
    
    return {
        'complete': found_weights == 4,
        'models_dir': models_dir,
        'found_weights': found_weights,
        'required_weights': 4,
        'missing_voices': missing_voices
    }


def get_device_info():
    if torch.cuda.is_available():
        return {
            'device_type': 'cuda',
            'device_name': torch.cuda.get_device_name(0),
            'cuda_available': True
        }
    else:
        return {
            'device_type': 'cpu',
            'device_name': 'CPU',
            'cuda_available': False
        }


__all__ = [
    'harmonize',
    'generate_from_scratch',
    'train_from_scratch',
    'finetune',
    'create_model',
    'load_model',
    'check_pretrained_weights',
    'get_device_info',
    'DeepBach',
    'DatasetManager',
    'FermataMetadata',
    'TickMetadata',
    'KeyMetadata',
]


if __name__ == "__main__":
    print(f"DeepBach PyTorch loaded")
    print(f"Package root directory: {PACKAGE_ROOT}")
    device_info = get_device_info()
    print(f"Device: {device_info['device_name']}")
    weights_status = check_pretrained_weights()
    if weights_status['complete']:
        print(f"OK: The pretrained model is complete")
    else:
        print(f"WARNING: The pretrained model is incomplete (Missing voices: {weights_status['missing_voices']})")