"""
@author: Gaetan Hadjeres

Bug fix vs. original:
  - reverse_tensor() and mask_entry(): index tensors are now created directly
    on the same device as the input tensor (using tensor.device) instead of
    being built on CPU and then moved to GPU via cuda_variable().
    This eliminates one CPU → GPU copy per call, which matters inside the
    inner loop of parallel_gibbs (called num_iterations × batch_size times).
"""

import torch


def mask_entry(tensor, entry_index, dim):
    """
    Return `tensor` with the slice at `entry_index` along `dim` removed.

    Equivalent to torch.cat([tensor[..., :entry_index, ...],
                              tensor[..., entry_index+1:, ...]], dim=dim)
    but works for arbitrary `dim`.

    :param tensor:      input tensor (any shape)
    :param entry_index: index to remove
    :param dim:         dimension along which to remove the entry
    :return:            tensor with one fewer element along `dim`
    """
    # FIX: create index directly on tensor.device — avoids CPU→GPU copy
    idx = torch.tensor(
        [i for i in range(tensor.size(dim)) if i != entry_index],
        dtype=torch.long,
        device=tensor.device,
    )
    return tensor.index_select(dim, idx)


def reverse_tensor(tensor, dim):
    """
    Reverse `tensor` along dimension `dim`.

    Equivalent to tensor[:, ..., ::-1, ..., :] along the chosen dim.

    :param tensor: input tensor (any shape)
    :param dim:    dimension along which to reverse
    :return:       reversed tensor (same shape)
    """
    # FIX: use torch.arange directly on tensor.device — avoids CPU→GPU copy
    idx = torch.arange(
        tensor.size(dim) - 1, -1, -1,
        dtype=torch.long,
        device=tensor.device,
    )
    return tensor.index_select(dim, idx)