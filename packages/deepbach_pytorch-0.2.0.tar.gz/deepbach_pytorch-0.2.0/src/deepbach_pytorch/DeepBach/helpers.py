"""
@author: Gaetan Hadjeres (Modified for PyTorch 1.10+)
 
Bug fix vs. original:
  - init_hidden(): uses torch.zeros instead of torch.randn.
    Random hidden-state initialisation injects noise into every training batch,
    slowing convergence and adding variance to loss curves. The standard
    practice is to start from all-zeros.
  NOTE: init_hidden() is no longer called in the Transformer VoiceModel but
  is kept here for any code that still uses it (e.g. ChoraleBeatsDataset or
  external callers).
"""
 
import torch
 
 
def cuda_variable(tensor, volatile=False):
    """Move tensor to GPU if available. `volatile` is ignored (PyTorch legacy)."""
    if torch.cuda.is_available():
        return tensor.cuda()
    return tensor
 
 
def to_numpy(variable):
    """Detach tensor and convert to a NumPy array (CPU)."""
    if torch.cuda.is_available():
        return variable.detach().cpu().numpy()
    return variable.detach().numpy()
 
 
def init_hidden(num_layers, batch_size, lstm_hidden_size, volatile=False):
    """
    Create a zero-initialised LSTM hidden state (h_0, c_0).
 
    Both tensors are placed on the same device as the current CUDA context
    (GPU if available, otherwise CPU).
 
    :param num_layers:       number of LSTM layers
    :param batch_size:       current batch size
    :param lstm_hidden_size: hidden unit count per layer
    :param volatile:         ignored — PyTorch 0.4 legacy parameter
    :return: (h_0, c_0) tuple of shape (num_layers, batch_size, lstm_hidden_size)
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # FIX: was torch.randn — random init adds noise to every batch.
    # Standard LSTM practice is to start from zeros.
    h_0 = torch.zeros(num_layers, batch_size, lstm_hidden_size, device=device)
    c_0 = torch.zeros(num_layers, batch_size, lstm_hidden_size, device=device)
    return h_0, c_0