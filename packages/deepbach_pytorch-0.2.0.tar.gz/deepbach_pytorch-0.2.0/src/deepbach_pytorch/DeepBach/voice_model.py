"""
@author: Gaetan Hadjeres

Transformer migration:
  - lstm_left / lstm_right replaced by TransformerEncoder blocks with
    sinusoidal positional encoding and mean-pool aggregation.
  - All other logic is preserved identically: preprocessing, Gibbs
    sampling interface, embedding resize, loss / accuracy, save / load.
  - __repr__ is kept identical to the LSTM version so that
    _load_pretrained_weights() can still locate checkpoint files by suffix.
    Transformer layer keys that are absent in old checkpoints are silently
    skipped (strict=False); embedding / mlp_center / mlp_predictions weights
    ARE successfully transferred from the pretrained checkpoint.

Bug fixes vs. original:
  - resize_embeddings_to_dataset(): syncs embedding tables after each
    make_tensor_dataset() call to prevent CUDA index-out-of-bounds.
  - loss_and_acc(): clamp per-voice indices as a safety net.
  - train_model(): rebuilds optimizer when embeddings are resized so new
    parameters are included in the update step.
"""

import math
import random

import torch
from DatasetManager.chorale_dataset import ChoraleDataset
from DeepBach.helpers import cuda_variable   # init_hidden removed (not needed)

from torch import nn

from DeepBach.data_utils import reverse_tensor, mask_entry


# ---------------------------------------------------------------------------
# Sinusoidal Positional Encoding
# ---------------------------------------------------------------------------

class PositionalEncoding(nn.Module):
    """
    Standard sinusoidal positional encoding (Vaswani et al., 2017).

    Adds position information to token embeddings before the Transformer
    encoder. Unlike LSTM, a Transformer has no built-in sense of order;
    this module injects that information explicitly.
    """

    def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 512):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe       = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        div_term = torch.exp(
            torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(0))   # (1, max_len, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, d_model)
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)


# ---------------------------------------------------------------------------
# VoiceModel
# ---------------------------------------------------------------------------

class VoiceModel(nn.Module):
    def __init__(self,
                 dataset: ChoraleDataset,
                 main_voice_index: int,
                 note_embedding_dim: int,
                 meta_embedding_dim: int,
                 num_layers: int,
                 lstm_hidden_size: int,   # name kept for __repr__ / checkpoint compat.
                 dropout_lstm: float,     # name kept for __repr__ / checkpoint compat.
                 hidden_size_linear=200
                 ):
        super(VoiceModel, self).__init__()
        self.dataset             = dataset
        self.main_voice_index    = main_voice_index
        self.note_embedding_dim  = note_embedding_dim
        self.meta_embedding_dim  = meta_embedding_dim

        # Read vocabulary sizes from dataset AFTER it has built its dicts
        self.num_notes_per_voice = [len(d) for d in dataset.note2index_dicts]
        self.num_voices          = self.dataset.num_voices
        self.num_metas_per_voice = [
            metadata.num_values for metadata in dataset.metadatas
        ] + [self.num_voices]
        self.num_metas           = len(self.dataset.metadatas) + 1
        self.num_layers          = num_layers
        self.lstm_hidden_size    = lstm_hidden_size   # output size of each context branch
        self.dropout_lstm        = dropout_lstm
        self.hidden_size_linear  = hidden_size_linear

        self.other_voices_indexes = [
            i for i in range(self.num_voices) if i != main_voice_index
        ]

        # ---- Embedding tables ------------------------------------------------
        self.note_embeddings = nn.ModuleList([
            nn.Embedding(num_notes, note_embedding_dim)
            for num_notes in self.num_notes_per_voice
        ])
        self.meta_embeddings = nn.ModuleList([
            nn.Embedding(num_metas, meta_embedding_dim)
            for num_metas in self.num_metas_per_voice
        ])

        # ---- Transformer context encoders ------------------------------------
        # Combined input dimension for left / right context sequences:
        #   (all voices * note_embed_dim) + (all metas * meta_embed_dim)
        context_dim = (note_embedding_dim * self.num_voices
                       + meta_embedding_dim * self.num_metas)

        # Number of attention heads: largest power of 2 dividing context_dim
        num_heads = 1
        for h in [8, 4, 2]:
            if context_dim % h == 0:
                num_heads = h
                break
        self._num_heads = num_heads

        # Feed-forward hidden dim: 2× context_dim, at least lstm_hidden_size
        ff_dim = max(lstm_hidden_size, context_dim * 2)

        # Left context encoder
        self.pos_enc_left    = PositionalEncoding(context_dim, dropout=dropout_lstm)
        self.transformer_left = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(
                d_model=context_dim,
                nhead=num_heads,
                dim_feedforward=ff_dim,
                dropout=dropout_lstm,
                batch_first=True,
            ),
            num_layers=num_layers,
        )
        # Project mean-pooled context vector to lstm_hidden_size so that
        # mlp_predictions can receive the same (3 * lstm_hidden_size) concat.
        self.left_proj = nn.Linear(context_dim, lstm_hidden_size)

        # Right context encoder (receives the time-reversed right sequence)
        self.pos_enc_right    = PositionalEncoding(context_dim, dropout=dropout_lstm)
        self.transformer_right = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(
                d_model=context_dim,
                nhead=num_heads,
                dim_feedforward=ff_dim,
                dropout=dropout_lstm,
                batch_first=True,
            ),
            num_layers=num_layers,
        )
        self.right_proj = nn.Linear(context_dim, lstm_hidden_size)

        # ---- Center MLP (other voices at the central time-step) ---------------
        # Input: (num_voices - 1) voice embeds + all meta embeds
        center_dim = (note_embedding_dim * (self.num_voices - 1)
                      + meta_embedding_dim * self.num_metas)
        self.mlp_center = nn.Sequential(
            nn.Linear(center_dim, hidden_size_linear),
            nn.ReLU(),
            nn.Linear(hidden_size_linear, lstm_hidden_size),
        )

        # ---- Output projection -----------------------------------------------
        # Input: concat(left_branch, center_branch, right_branch)
        # Each branch is projected to lstm_hidden_size → total = 3 * lstm_hidden_size
        self.mlp_predictions = nn.Sequential(
            nn.Linear(self.lstm_hidden_size * 3, hidden_size_linear),
            nn.ReLU(),
            nn.Linear(hidden_size_linear, self.num_notes_per_voice[main_voice_index]),
        )

    # -----------------------------------------------------------------------
    # Dynamic embedding / output-projection resize
    # -----------------------------------------------------------------------

    def resize_embeddings_to_dataset(self) -> bool:
        """
        Sync note_embeddings and mlp_predictions to the current dataset vocab.

        Must be called AFTER data_loaders() / make_tensor_dataset() completes,
        because that is when note2index_dicts may have grown (new enharmonic
        spellings added by transposition augmentation, e.g. 'B##3', 'OOR').

        Strategy per voice:
          - Vocab grew:   expand embedding table, copy existing weights,
                          zero-init new rows (they will be learned in training).
          - Vocab shrank: warn and skip (should not happen).
          - Sizes match:  no-op.

        Also resizes the output Linear of mlp_predictions for the main voice
        so logit dimensions stay consistent with the vocab.

        Returns True if any resize occurred; caller should then rebuild the
        optimizer so new parameters are included in gradient updates.
        """
        changed = False

        for voice_idx in range(self.num_voices):
            actual_vocab = len(self.dataset.note2index_dicts[voice_idx])
            emb          = self.note_embeddings[voice_idx]
            curr_vocab   = emb.num_embeddings
            embed_dim    = emb.embedding_dim

            if actual_vocab == curr_vocab:
                continue

            if actual_vocab < curr_vocab:
                print(f"  [resize] WARNING: voice {voice_idx} vocab shrank "
                      f"{curr_vocab} -> {actual_vocab}. Skipping to avoid "
                      f"corrupting existing weights.")
                continue

            print(f"  [resize] Voice {voice_idx}: expanding embedding "
                  f"{curr_vocab} -> {actual_vocab} "
                  f"(+{actual_vocab - curr_vocab} new tokens, zero-init)")
            new_emb = nn.Embedding(actual_vocab, embed_dim)
            with torch.no_grad():
                new_emb.weight[:curr_vocab] = emb.weight
                # New rows left at zero — nn.Embedding default is uniform random,
                # but we want zero so they start neutral and are trained up.
                new_emb.weight[curr_vocab:].zero_()
            new_emb = new_emb.to(emb.weight.device)
            self.note_embeddings[voice_idx] = new_emb
            self.num_notes_per_voice[voice_idx] = actual_vocab
            changed = True

        # Resize output projection for the main voice if the vocab changed
        main_vocab = len(self.dataset.note2index_dicts[self.main_voice_index])
        out_linear  = self.mlp_predictions[-1]
        if out_linear.out_features != main_vocab:
            print(f"  [resize] Resizing output projection: "
                  f"{out_linear.out_features} -> {main_vocab}")
            new_linear = nn.Linear(out_linear.in_features, main_vocab)
            new_linear = new_linear.to(out_linear.weight.device)
            with torch.no_grad():
                old_n = min(out_linear.out_features, main_vocab)
                new_linear.weight[:old_n] = out_linear.weight[:old_n]
                new_linear.bias[:old_n]   = out_linear.bias[:old_n]
                if main_vocab > old_n:
                    new_linear.weight[old_n:].zero_()
                    new_linear.bias[old_n:].zero_()
            layers = list(self.mlp_predictions.children())
            layers[-1] = new_linear
            self.mlp_predictions = nn.Sequential(*layers)
            changed = True

        if changed:
            print(f"  [resize] Done. Rebuild optimizer to include new parameters.")
        return changed

    # -----------------------------------------------------------------------
    # Forward
    # -----------------------------------------------------------------------

    def forward(self, *input):
        notes, metas = input
        batch_size, num_voices, timesteps_ticks = notes[0].size()

        # Bring the voice / time axes to the right shape for embed()
        ln, cn, rn = notes
        ln = ln.transpose(1, 2)   # (batch, left_ticks,  num_voices)
        rn = rn.transpose(1, 2)   # (batch, right_ticks, num_voices)
        notes = ln, cn, rn

        # Embed notes and metadata into dense vectors
        notes_embedded = self.embed(notes, type='note')
        metas_embedded = self.embed(metas, type='meta')

        # Concatenate note and meta embeddings at each time position
        input_embedded = [
            torch.cat([n, m], dim=2) if n is not None else None
            for n, m in zip(notes_embedded, metas_embedded)
        ]
        left, center, right = input_embedded
        # Shapes:
        #   left  / right : (batch, ticks, context_dim)
        #   center        : (batch, 1,     center_dim)

        # ---- Left context branch (past notes, time order) ----
        left = self.pos_enc_left(left)          # positional encoding
        left = self.transformer_left(left)      # (batch, left_ticks, context_dim)
        left = left.mean(dim=1)                 # mean pool → (batch, context_dim)
        left = self.left_proj(left)             # project  → (batch, lstm_hidden_size)

        # ---- Center branch (other voices at the prediction time-step) ----
        if self.num_voices == 1:
            center = cuda_variable(torch.zeros(batch_size, self.lstm_hidden_size))
        else:
            center = center[:, 0, :]            # (batch, center_dim)
            center = self.mlp_center(center)    # (batch, lstm_hidden_size)

        # ---- Right context branch (future notes, already reversed) ----
        right = self.pos_enc_right(right)
        right = self.transformer_right(right)
        right = right.mean(dim=1)
        right = self.right_proj(right)

        # ---- Predict ----
        # Concat all three branches and project to vocabulary logits
        predictions = torch.cat([left, center, right], dim=1)
        predictions = self.mlp_predictions(predictions)
        return predictions

    # -----------------------------------------------------------------------
    # Embedding helper (unchanged from original)
    # -----------------------------------------------------------------------

    def embed(self, notes_or_metas, type):
        if type == 'note':
            embeddings           = self.note_embeddings
            embedding_dim        = self.note_embedding_dim
            other_voices_indexes = self.other_voices_indexes
        elif type == 'meta':
            embeddings           = self.meta_embeddings
            embedding_dim        = self.meta_embedding_dim
            other_voices_indexes = range(self.num_metas)

        batch_size, timesteps_left_ticks,  num_voices = notes_or_metas[0].size()
        batch_size, timesteps_right_ticks, num_voices = notes_or_metas[2].size()

        left, center, right = notes_or_metas

        left_embedded = torch.cat([
            embeddings[voice_id](left[:, :, voice_id])[:, :, None, :]
            for voice_id in range(num_voices)
        ], dim=2)
        right_embedded = torch.cat([
            embeddings[voice_id](right[:, :, voice_id])[:, :, None, :]
            for voice_id in range(num_voices)
        ], dim=2)

        if self.num_voices == 1 and type == 'note':
            center_embedded = None
        else:
            center_embedded = torch.cat([
                embeddings[voice_id](center[:, k].unsqueeze(1))
                for k, voice_id in enumerate(other_voices_indexes)
            ], dim=1)
            center_embedded = center_embedded.view(
                batch_size, 1, len(other_voices_indexes) * embedding_dim
            )

        left_embedded = left_embedded.view(
            batch_size, timesteps_left_ticks, num_voices * embedding_dim
        )
        right_embedded = right_embedded.view(
            batch_size, timesteps_right_ticks, num_voices * embedding_dim
        )
        return left_embedded, center_embedded, right_embedded

    # -----------------------------------------------------------------------
    # Persistence
    # -----------------------------------------------------------------------

    def save(self):
        torch.save(self.state_dict(), 'models/' + self.__repr__())
        print(f'Model {self.__repr__()} saved')

    def load(self):
        state_dict = torch.load('models/' + self.__repr__(),
                                map_location=lambda storage, loc: storage)
        print(f'Loading {self.__repr__()}')
        self.load_state_dict(state_dict)

    def __repr__(self):
        # Kept identical to the original LSTM version so that
        # _load_pretrained_weights() can still find checkpoints by filename suffix.
        return (f'VoiceModel('
                f'{self.dataset.__repr__()},'
                f'{self.main_voice_index},'
                f'{self.note_embedding_dim},'
                f'{self.meta_embedding_dim},'
                f'{self.num_layers},'
                f'{self.lstm_hidden_size},'
                f'{self.dropout_lstm},'
                f'{self.hidden_size_linear}'
                f')')

    # -----------------------------------------------------------------------
    # Training
    # -----------------------------------------------------------------------

    def train_model(self,
                    batch_size=16,
                    num_epochs=10,
                    optimizer=None):
        for epoch in range(num_epochs):
            print(f'===Epoch {epoch}===')

            (dataloader_train,
             dataloader_val,
             dataloader_test) = self.dataset.data_loaders(batch_size=batch_size)

            # After data_loaders() returns, make_tensor_dataset() may have added
            # new tokens to note2index_dicts. Resize BEFORE the first forward pass
            # so every index in the dataset has a valid embedding row.
            # This is a no-op if sizes already match (typical after epoch 0).
            print("  Checking embedding sizes after dataset build...")
            resized = self.resize_embeddings_to_dataset()
            if resized:
                print("  Embeddings resized — rebuilding optimizer to cover "
                      "new parameters.")
                optimizer = torch.optim.Adam(self.parameters())
            else:
                print("  Embedding sizes OK, no resize needed.")

            loss, acc = self.loss_and_acc(dataloader_train,
                                          optimizer=optimizer,
                                          phase='train')
            print(f'Training loss: {loss:.4f}')
            print(f'Training accuracy: {acc:.2f}%')

            loss, acc = self.loss_and_acc(dataloader_val,
                                          optimizer=None,
                                          phase='test')
            print(f'Validation loss: {loss:.4f}')
            print(f'Validation accuracy: {acc:.2f}%')
            self.save()

    def loss_and_acc(self, dataloader, optimizer=None, phase='train'):
        average_loss = 0.0
        average_acc  = 0.0

        if phase == 'train':
            self.train()
        elif phase in ('eval', 'test'):
            self.eval()
        else:
            raise NotImplementedError(f"Unknown phase: '{phase}'")

        for tensor_chorale, tensor_metadata in dataloader:
            tensor_chorale  = cuda_variable(tensor_chorale).long()
            tensor_metadata = cuda_variable(tensor_metadata).long()

            # SAFETY CLAMP: guard against any stale index that still exceeds
            # the embedding table size (e.g. cached tensor from a prior larger
            # dictionary, or a race between resize and batch loading).
            for v in range(self.num_voices):
                max_valid = self.note_embeddings[v].num_embeddings - 1
                tensor_chorale[:, v, :] = tensor_chorale[:, v, :].clamp(0, max_valid)

            notes, metas, label = self.preprocess_input(tensor_chorale,
                                                        tensor_metadata)
            weights = self.forward(notes, metas)
            loss    = nn.CrossEntropyLoss()(weights, label)

            if phase == 'train':
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            acc = self.accuracy(weights=weights, target=label)
            average_loss += loss.item()
            average_acc  += acc.item()

        average_loss /= len(dataloader)
        average_acc  /= len(dataloader)
        return average_loss, average_acc

    def accuracy(self, weights, target):
        batch_size, = target.size()
        pred = nn.Softmax(dim=1)(weights).max(1)[1].type_as(target)
        return (pred == target).float().sum() / batch_size * 100

    # -----------------------------------------------------------------------
    # Preprocessing (identical to original)
    # -----------------------------------------------------------------------

    def preprocess_input(self, tensor_chorale, tensor_metadata):
        """
        :param tensor_chorale:  (batch, num_voices, chorale_length_ticks)
        :param tensor_metadata: (batch, num_voices, chorale_length_ticks, num_metas)
        :return: (notes, metas, label)
          notes = (left_notes, central_notes, right_notes)
          metas = (left_metas, central_metas, right_metas)
          right_notes / right_metas are REVERSED (right-to-left order)
        """
        _, _, chorale_length_ticks = tensor_chorale.size()
        offset           = random.randint(0, self.dataset.subdivision)
        time_index_ticks = chorale_length_ticks // 2 + offset

        notes, label = self.preprocess_notes(tensor_chorale, time_index_ticks)
        metas        = self.preprocess_metas(tensor_metadata, time_index_ticks)
        return notes, metas, label

    def preprocess_notes(self, tensor_chorale, time_index_ticks):
        """
        :param tensor_chorale:   (batch, num_voices, chorale_length_ticks)
        :param time_index_ticks: central prediction time-step index
        :return: ((left, center, right), label)
        """
        left_notes  = tensor_chorale[:, :, :time_index_ticks]
        right_notes = reverse_tensor(
            tensor_chorale[:, :, time_index_ticks + 1:], dim=2
        )
        if self.num_voices == 1:
            central_notes = None
        else:
            central_notes = mask_entry(
                tensor_chorale[:, :, time_index_ticks],
                entry_index=self.main_voice_index,
                dim=1
            )
        label = tensor_chorale[:, self.main_voice_index, time_index_ticks]
        return (left_notes, central_notes, right_notes), label

    def preprocess_metas(self, tensor_metadata, time_index_ticks):
        """
        :param tensor_metadata:  (batch, num_voices, chorale_length_ticks, num_meta_features)
        :param time_index_ticks: central prediction time-step index
        :return: (left_metas, central_metas, right_metas)
        """
        left_metas    = tensor_metadata[:, self.main_voice_index, :time_index_ticks, :]
        right_metas   = reverse_tensor(
            tensor_metadata[:, self.main_voice_index, time_index_ticks + 1:, :], dim=1
        )
        central_metas = tensor_metadata[:, self.main_voice_index, time_index_ticks, :]
        return left_metas, central_metas, right_metas
