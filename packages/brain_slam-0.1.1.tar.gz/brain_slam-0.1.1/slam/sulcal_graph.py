import os
import pickle
import numpy as np
from slam import geodesics
import networkx as nx
import trimesh
import slam.watershed as swat
import slam.remeshing as sre


def extract_sulcal_graph(mesh,
                         thresh_dist_perc,
                         thresh_ridge,
                         thresh_area_perc,
                         mask=None):
    """
    Main Function that extracts the sulcal graph from a mesh and saves
    it in the given directory.
    Parameters
    ----------
    mesh
    thresh_dist_perc
    thresh_ridge
    thresh_area_perc
    mask

    Returns
    -------
        g : sulcal graph as a networkx graph
    """
    _, dpf, voronoi = swat.compute_mesh_features(mesh)

    basins, ridges, adjacency = (
        swat.watershed(mesh,
                       voronoi,
                       dpf,
                       thresh_dist_perc,
                       thresh_ridge,
                       thresh_area_perc, mask))
    g = get_sulcal_graph(adjacency,
                         basins,
                         ridges)
    get_textures_from_graph(g, mesh)
    return g


def get_sulcal_graph(adjacency, basins, ridges):
    """
    Function that creates a graph from the outputs of the watershed.

    Node and edges attributes are inherited from basins and ridges.
    See slam/watershed.py for more details.
    Parameters
    ----------
    adjacency
    basins
    ridges

    Returns
    -------
        graph : sulcal graph as a networkx graph
    """
    ##############################################################
    # Initialize the graph using adjacency matrix
    ##############################################################
    # np.fill_diagonal(adjacency, 1.)  # ensure systematic self connection
    graph = nx.from_numpy_array(adjacency)  # , nodelist=basins)
    # nodelist not adapted to attribution of labels in plotly_visu.py

    ####################################################################
    # Set graph attributes
    ####################################################################
    # Add node attributes
    node_attributes = {}
    for i, (label, values) in enumerate(basins.items()):
        node_attributes[i] = basins[label]  # add all dictionary values
        node_attributes[i]['basin_label'] = label  # add label value
    nx.set_node_attributes(graph, node_attributes)

    # Add edge attributes
    labels = list(basins.keys())
    edge_attributes = {}
    for pair, values in ridges.items():
        # Get new indices
        i = labels.index(pair[0])
        j = labels.index(pair[1])
        edge_attributes[i, j] = values  # add all dictionary values
        # print(values)
    # for ed in range(len(graph.edges)):
    #     print("Edge "+str(ed)+" attributes:",
    #           graph.edges[list(graph.edges)[ed]].keys())

    nx.set_edge_attributes(graph, edge_attributes)
    # for ed in range(len(graph.edges)):
    #     print("Edge "+str(ed)+" attributes:",
    #           graph.edges[list(graph.edges)[ed]].keys())

    return graph


def save_graph(graph, outdir):
    """
    Save sulcal pits graph in the given directory under the
    name "graph.gpickle"
    Parameters
    ----------
    graph
    outdir

    Returns
    -------

    """

    file_path = os.path.join(outdir, "graph.gpickle")
    with open(file_path, 'wb') as f:
        pickle.dump(graph, f, pickle.HIGHEST_PROTOCOL)
    print("Graph saved in", file_path)
    return 0


def add_node_attribute_from_texture(graph, texture, attribute_name):
    """
    Add a node attribute to the graph using the value of the texture
    at pit positions
    Parameters
    ----------
    graph
    texture
    attribute_name

    Returns
    -------

    """
    node_values = {}
    for basin in graph.nodes:
        # Get pits indices
        pit = graph.nodes[basin]['pit_index']
        # Get the texture values for each pit
        node_values[basin] = texture[pit]

    # Add the attribute to the graph
    nx.set_node_attributes(graph, values=node_values, name=attribute_name)

    return graph


def add_edge_attribute_from_texture(graph, texture, attribute_name):
    """
        Add an edge attribute to the graph using the value of the texture at
    ridge positions
    Parameters
    ----------
    graph
    texture
    attribute_name

    Returns
    -------

    """
    # Get the adjacency matrix with ridge positions
    adjacency = nx.to_numpy_array(graph, weight='ridge_index', dtype=np.int32)
    # Create and fill a new edge dictionary with the texture
    # values at ridge positions
    ridge_dict = {}
    for i, j in graph.edges:
        ridge_dict[(i, j)] = float(texture[adjacency[i][j]])
    # Add the attribute to the graph
    nx.set_edge_attributes(graph, ridge_dict, name=attribute_name)

    return graph


def add_geodesic_distances_to_edges(graph, mesh):
    """
        Add the geodesic distances between ridge and pits to the corresponding
     ridge attributes in the graph:

    - geodesic_distance_btw_ridge_pit_i: geodesic distance between the
    ridge and the first pit
    - geodesic_distance_btw_ridge_pit_j: geodesic distance between the
    ridge and the second pit
    - geodesic_distance_btw_pits: geodesic distance between the two pits
    connected by the ridge (sum of previous values)
    Parameters
    ----------
    graph
    mesh

    Returns
    -------

    """
    # Create and fill a new edge dictionary with the geodesic distances
    geodistances = {}
    for i, j in graph.edges:
        ridge = graph.edges[(i, j)]['ridge_index']
        pit_i = graph.nodes[i]['pit_index']
        pit_j = graph.nodes[j]['pit_index']
        # Compute the geodesic distances between ridge and both pits
        gd_from_ridge = geodesics.compute_gdist(mesh, ridge)
        geodistances[(i, j)] = {}
        geodistances[(i, j)]['geodesic_distance_btw_ridge_pit_i'] = (
            float(gd_from_ridge[pit_i]))
        geodistances[(i, j)]['geodesic_distance_btw_ridge_pit_j'] = (
            float(gd_from_ridge[pit_j]))
        geodistances[(i, j)]['geodesic_distance_btw_pits'] = (
                float(gd_from_ridge[pit_i]) + float(gd_from_ridge[pit_j]))

    # Add the attribute to the graph
    nx.set_edge_attributes(graph, geodistances)

    return graph


def add_mean_value_to_nodes(graph, texture, attribute_name):
    """
        Add the mean value of the texture over the vertices of each basin
    to the graph node attributes
    Parameters
    ----------
    graph
    texture
    attribute_name

    Returns
    -------

    """
    average_values = {}
    for basin in graph.nodes:
        # Get the list of vertices
        vertices = graph.nodes[basin]['basin_vertices']
        # Compute the average value of texture over the vertices
        mean_value = np.mean(texture[vertices])
        average_values[basin] = mean_value

    # Add the attribute to the graph
    nx.set_node_attributes(graph, average_values, name=attribute_name)

    return graph


def get_textures_from_graph(graph, mesh):
    """
    Function that returns the textures from a graph of sulcal pits
    Parameters
    ----------
    graph
    mesh

    Returns
    -------

    """
    vert = np.array(mesh.vertices)

    # texture of labels
    atex_labels = np.full(len(vert), -1, dtype=np.int64)
    for b in graph.nodes:
        atex_labels[graph.nodes[b]['basin_vertices']] = (
            graph.nodes)[b]['basin_label']

    # texture of pits
    atex_pits = np.zeros((len(vert), 1))
    pits_indices = list(nx.get_node_attributes(graph, 'pit_index').values())
    atex_pits[pits_indices] = 1

    # texture of ridges
    atex_ridges = np.zeros((len(vert), 1))
    ridges_indices = (
        list(nx.get_edge_attributes(graph, 'ridge_index').values()))
    atex_ridges[ridges_indices] = 1

    return atex_labels, atex_pits, atex_ridges


def vertex_index_interpolation(graph, target_spherical_mesh,
                               graph_spherical_coords_attribute,
                               interpolated_attribute='interp_vertex_index'
                               ):
    """
    Nearest neighbor interpolation of the nodes spherical coordinates onto the
         template spherical coordinates
    Parameters
    ----------
    graph
    target_spherical_mesh : target Trimesh mesh object
    graph_spherical_coords_attribute : name of the new attribute
    interpolated_attribute

    Returns
    -------
        g : graph with the new node attribute
    """
    nodes_spherical_3D_coords = (
        np.array(list(nx.get_node_attributes(
            graph, graph_spherical_coords_attribute).values())))

    source_mesh = trimesh.Trimesh(
        faces=None,
        vertices=nodes_spherical_3D_coords,
        metadata=None,
        process=False)

    target_vertex_index = sre.spherical_interpolation_nearest_neighbor(
        target_spherical_mesh, source_mesh, normalize_spheres=False)
    node_att = {}
    for node, interp_ind in zip(graph.nodes, target_vertex_index):
        node_att[node] = int(interp_ind)
    nx.set_node_attributes(graph, values=node_att, name=interpolated_attribute)
    return graph


def add_coords_attribute(graph, mesh, attribute_vert_index, new_attribute_key):
    """

    Parameters
    ----------
    graph
    mesh
    attribute_vert_index
    new_attribute_key

    Returns
    -------

    """
    nodes_vert_index =\
        np.array(list(nx.get_node_attributes(
            graph, attribute_vert_index).values()))
    attribute_array = np.array(mesh.vertices[nodes_vert_index, :])
    node_att = {}
    for node, coords in zip(graph.nodes, attribute_array):
        node_att[node] = coords
    nx.set_node_attributes(graph, values=node_att, name=new_attribute_key)
    print(graph.nodes[0])
    return graph
