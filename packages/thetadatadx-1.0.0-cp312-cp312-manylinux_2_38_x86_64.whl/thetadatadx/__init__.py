from .thetadatadx import *

__doc__ = thetadatadx.__doc__
if hasattr(thetadatadx, "__all__"):
    __all__ = thetadatadx.__all__