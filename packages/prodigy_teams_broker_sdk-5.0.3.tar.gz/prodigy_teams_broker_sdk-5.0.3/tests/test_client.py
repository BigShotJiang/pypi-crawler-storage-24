import pytest

from prodigy_teams_broker_sdk import AccessTokenCredential, Client

BASE_URL = "http://localhost:8083"


@pytest.fixture
def client() -> Client:
    cred = AccessTokenCredential(access_token="")
    client = Client(BASE_URL, cred)
    return client


def test_client_init(client: Client):
    assert client.base_url == BASE_URL
