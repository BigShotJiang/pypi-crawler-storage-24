from typing import Any, cast

from pydantic import BaseModel, Field

from ..models import RecipesMeta
from .base import BaseClient


class BuildImageResponse(BaseModel):
    """Response from the build-image endpoint."""

    image_uri: str = Field(..., title="Image Uri")
    meta: list[Any] = Field(..., title="Meta")


class Envs(BaseClient):
    def get_recipes_meta(self, package_name: str, package_version: str) -> RecipesMeta:
        res = self.request(
            "GET",
            endpoint=f"{package_name}/{package_version}/meta",
            return_model=RecipesMeta,
        )
        return cast(RecipesMeta, res)

    async def get_recipes_meta_async(
        self, package_name: str, package_version: str
    ) -> RecipesMeta:
        res = await self.request_async(
            "GET",
            endpoint=f"{package_name}/{package_version}/meta",
            return_model=RecipesMeta,
        )
        return cast(RecipesMeta, res)

    def build_image(
        self,
        package_name: str,
        package_version: str,
        base_image: str,
        tar_data_b64: str,
        meta_json: str,
    ) -> BuildImageResponse:
        """Build an ad-hoc container image for a recipe package."""
        res = self.request(
            "POST",
            endpoint="build-image",
            data={
                "package_name": package_name,
                "package_version": package_version,
                "base_image": base_image,
                "tar_data": tar_data_b64,
                "meta_json": meta_json,
            },
            return_model=BuildImageResponse,
        )
        return cast(BuildImageResponse, res)

    async def build_image_async(
        self,
        package_name: str,
        package_version: str,
        base_image: str,
        tar_data_b64: str,
        meta_json: str,
    ) -> BuildImageResponse:
        """Build an ad-hoc container image for a recipe package (async)."""
        res = await self.request_async(
            "POST",
            endpoint="build-image",
            data={
                "package_name": package_name,
                "package_version": package_version,
                "base_image": base_image,
                "tar_data": tar_data_b64,
                "meta_json": meta_json,
            },
            return_model=BuildImageResponse,
        )
        return cast(BuildImageResponse, res)
