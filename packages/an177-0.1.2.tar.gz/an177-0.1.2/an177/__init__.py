import os, sys, time, hashlib, marshal, lzma, base64, gc, zlib, json

def print_banner():
    banner = [
        "██╗   ██╗██╗   ██╗ █████╗ ████████╗ ██████╗  ██████╗ ██╗     ",
        "██║   ██║██║   ██║██╔══██╗╚══██╔══╝██╔═══██╗██╔═══██╗██║     ",
        "██║   ██║██║   ██║███████║   ██║   ██║   ██║██║   ██║██║     ",
        "╚██╗ ██╔╝╚██╗ ██╔╝██╔══██║   ██║   ██║   ██║██║   ██║██║     ",
        " ╚████╔╝   ╚████╔╝ ██║  ██║   ██║   ╚██████╔╝╚██████╔╝███████╗",
        "  ╚═══╝     ╚═══╝  ╚═╝  ╚═╝   ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝"
    ]
    colors = [(255, 0, 255), (220, 20, 255), (180, 40, 255), (140, 60, 255), (100, 80, 255), (80, 100, 255)]
    print("\n")
    for i, line in enumerate(banner):
        r, g, b = colors[i]
        sys.stdout.write(f"\033[38;2;{r};{g};{b}m{line}\033[0m\n")
    print("\n")

def run_cmd(data, k_enc):
    G, R, W = "\033[92m", "\033[91m", "\033[0m"
    os.system('cls' if os.name == 'nt' else 'clear')
    print_banner()

    try:

        _h_v = hashlib.sha256(b"vinh_an177_secret_key").digest()
        
        _d = "".join(data.split()).strip()
        print(f"{G} Đang giải mã... ", end="", flush=True)

        _k_b = base64.b85decode(k_enc.strip().encode('utf-8'))
        _m_r = bytearray(b ^ _h_v[i % 32] for i, b in enumerate(_k_b))
        _m_d = json.loads(_m_r.decode('utf-8'))
        _rev = {v: k for k, v in _m_d.items()}
        
        _b85_p = "".join(_rev.get(_d[i:i+3], "") for i in range(0, len(_d), 3))
        _raw = base64.b85decode(_b85_p.encode('utf-8'))
        
        # Giải mã Bit-Rotate
        _s1 = bytes([b ^ 0xFF for b in _raw[::-1]])
        _s2 = bytearray()
        for i, b in enumerate(_s1):
            _k = _h_v[i % 32]
            # Rotate ngược
            _unrotated = ((b << 5) | (b >> 3)) & 0xFF
            _s2.append(_unrotated ^ _k)
        
        _dec = lzma.decompress(zlib.decompress(bytes(_s2)))
        print(f"\n{G} Thành công! {W}\n")
        
        del data, _d, _k_b, _m_r, _rev, _b85_p, _raw, _s1, _s2
        gc.collect()
        
        exec(marshal.loads(_dec), globals())

    except Exception:
        print(f"\n{R} Code không hợp lệ {W}")
        sys.exit()

if __name__ == "__main__":
    print_banner()