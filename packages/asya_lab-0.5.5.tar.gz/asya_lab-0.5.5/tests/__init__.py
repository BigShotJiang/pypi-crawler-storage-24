"""Tests for asya-lab."""
