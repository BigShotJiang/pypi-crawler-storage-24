"""
IncusAI — Where signal becomes spec.

Python SDK coming soon. Visit https://incusai.dev
"""

__version__ = "0.0.1"
__author__ = "IncusAI"
__url__ = "https://incusai.dev"


def main():
    print("IncusAI Python SDK is coming soon. Visit https://incusai.dev")
