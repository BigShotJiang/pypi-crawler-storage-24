import sys

sys.path.insert(0, "C:/Users/rsabino/Documents/projecto final/kutanga/tts_package/src")

from kimbundu_speech_ai import TTS
from pathlib import Path
import pytest
import os
import soundfile as sf


@pytest.mark.integration
def test_convert_to_file_creates_valid_wav():
    model_path = Path("./tests/models/tts-model")
    waveglow_model_path = Path("./tests/models/waveglow.pt")

    assert model_path.exists()
    assert waveglow_model_path.exists()

    result = TTS.convert_to_file(
        text="nzambi",
        model_path=model_path,
        waveglow_model_path=waveglow_model_path,
    )

    assert os.path.exists(result)

    audio, sr = sf.read(result)

    assert audio.ndim == 1
    assert audio.size > 0
    assert sr > 0


@pytest.mark.integration
def test_play_default_player_runs(monkeypatch, tmp_path):
    model_path = Path("./tests/models/tts-model")
    waveglow_model_path = Path("./tests/models/waveglow.pt")

    assert model_path.exists()
    assert waveglow_model_path.exists()

    monkeypatch.setattr("kimbundu_speech_ai.tts.os.system", lambda *_: 0)

    TTS.play_default_player(
        text="nzambi",
        model_path=model_path,
        waveglow_model_path=waveglow_model_path,
    )