"""
Performance and Load Tests for Kimbundu Speech AI
Tests scalability, stress handling, and response time analysis
"""
import sys
import pytest
import time
import os
import psutil
import threading
import multiprocessing
from multiprocessing import Process, Manager
import statistics
from pathlib import Path
from unittest.mock import patch, MagicMock
import tempfile
import numpy as np

sys.path.insert(0, "C:/Users/rsabino/Documents/projecto final/kutanga/tts_package/src")

from kimbundu_speech_ai import TTS, STT


class PerformanceMetrics:
    """Helper class to collect and analyze performance metrics."""

    def __init__(self):
        self.response_times = []
        self.memory_usage = []
        self.cpu_usage = []
        self.success_count = 0
        self.error_count = 0
        self.start_time = None
        self.end_time = None

    def record_response_time(self, duration):
        """Record a response time."""
        self.response_times.append(duration)

    def record_memory_usage(self):
        """Record current memory usage."""
        process = psutil.Process()
        memory_mb = process.memory_info().rss / 1024 / 1024
        self.memory_usage.append(memory_mb)

    def record_cpu_usage(self):
        """Record current CPU usage."""
        cpu_percent = psutil.cpu_percent(interval=0.1)
        self.cpu_usage.append(cpu_percent)

    def record_success(self):
        """Record a successful operation."""
        self.success_count += 1

    def record_error(self):
        """Record a failed operation."""
        self.error_count += 1

    def get_statistics(self):
        """Calculate and return statistics."""
        if not self.response_times:
            return None

        duration = self.end_time - self.start_time if self.end_time else 0

        return {
            'response_time': {
                'min': min(self.response_times),
                'max': max(self.response_times),
                'mean': statistics.mean(self.response_times),
                'median': statistics.median(self.response_times),
                'stdev': statistics.stdev(self.response_times) if len(self.response_times) > 1 else 0,
                'p95': statistics.quantiles(self.response_times, n=20)[18] if len(self.response_times) > 1 else 0,
                'p99': statistics.quantiles(self.response_times, n=100)[98] if len(self.response_times) > 1 else 0,
            },
            'memory': {
                'min_mb': min(self.memory_usage) if self.memory_usage else 0,
                'max_mb': max(self.memory_usage) if self.memory_usage else 0,
                'mean_mb': statistics.mean(self.memory_usage) if self.memory_usage else 0,
            },
            'cpu': {
                'min_percent': min(self.cpu_usage) if self.cpu_usage else 0,
                'max_percent': max(self.cpu_usage) if self.cpu_usage else 0,
                'mean_percent': statistics.mean(self.cpu_usage) if self.cpu_usage else 0,
            },
            'throughput': {
                'total_requests': self.success_count + self.error_count,
                'successful_requests': self.success_count,
                'failed_requests': self.error_count,
                'requests_per_second': self.success_count / duration if duration > 0 else 0,
                'success_rate': (self.success_count / (self.success_count + self.error_count) * 100)
                                if (self.success_count + self.error_count) > 0 else 0,
            },
            'duration': {
                'total_seconds': duration,
            }
        }

    def print_report(self, test_name):
        """Print a formatted performance report."""
        stats = self.get_statistics()
        if not stats:
            print(f"\n{test_name}: No data collected")
            return

        print(f"\n{'='*80}")
        print(f"PERFORMANCE REPORT: {test_name}")
        print(f"{'='*80}")

        print(f"\n📊 Response Time Statistics:")
        print(f"  Min:     {stats['response_time']['min']:.4f}s")
        print(f"  Max:     {stats['response_time']['max']:.4f}s")
        print(f"  Mean:    {stats['response_time']['mean']:.4f}s")
        print(f"  Median:  {stats['response_time']['median']:.4f}s")
        print(f"  StdDev:  {stats['response_time']['stdev']:.4f}s")
        print(f"  P95:     {stats['response_time']['p95']:.4f}s")
        print(f"  P99:     {stats['response_time']['p99']:.4f}s")

        print(f"\n💾 Memory Usage:")
        print(f"  Min:     {stats['memory']['min_mb']:.2f} MB")
        print(f"  Max:     {stats['memory']['max_mb']:.2f} MB")
        print(f"  Mean:    {stats['memory']['mean_mb']:.2f} MB")

        print(f"\n⚡ CPU Usage:")
        print(f"  Min:     {stats['cpu']['min_percent']:.2f}%")
        print(f"  Max:     {stats['cpu']['max_percent']:.2f}%")
        print(f"  Mean:    {stats['cpu']['mean_percent']:.2f}%")

        print(f"\n🚀 Throughput:")
        print(f"  Total Requests:      {stats['throughput']['total_requests']}")
        print(f"  Successful:          {stats['throughput']['successful_requests']}")
        print(f"  Failed:              {stats['throughput']['failed_requests']}")
        print(f"  Requests/Second:     {stats['throughput']['requests_per_second']:.2f}")
        print(f"  Success Rate:        {stats['throughput']['success_rate']:.2f}%")

        print(f"\n⏱️  Total Duration:      {stats['duration']['total_seconds']:.2f}s")
        print(f"{'='*80}\n")


def _scalability_worker(request_id, num_concurrent, tmp_path_str, tacotron_path, waveglow_path, shared_dict):
    """
    Worker process for scalability testing.
    Must be at module level for multiprocessing pickle support.
    Pre-loads models once, then times only inference.
    """
    import sys
    import time
    from pathlib import Path
    sys.path.insert(0, "C:/Users/rsabino/Documents/projecto final/kutanga/tts_package/src")
    from kimbundu_speech_ai import TTS
    import psutil

    output_file = Path(tmp_path_str) / f"scalability_{num_concurrent}_{request_id}.wav"

    # PRE-LOAD models (NOT timed) - this simulates a production scenario where models are already loaded
    try:
        # First call loads models (not timed)
        warmup_file = Path(tmp_path_str) / f"warmup_{request_id}.wav"
        TTS.convert_to_file(
            text="warmup",
            model_path=str(tacotron_path),
            waveglow_model_path=str(waveglow_path),
            out_wav=str(warmup_file)
        )
        warmup_file.unlink(missing_ok=True)  # Delete warmup file

        # NOW time the actual inference (models already loaded)
        start = time.time()
        TTS.convert_to_file(
            text=f"ngana nzambi {request_id}",
            model_path=str(tacotron_path),
            waveglow_model_path=str(waveglow_path),
            out_wav=str(output_file)
        )
        duration = time.time() - start

        # Store results in shared dictionary
        shared_dict[f'success_{request_id}'] = True
        shared_dict[f'duration_{request_id}'] = duration
        shared_dict[f'memory_{request_id}'] = psutil.Process().memory_info().rss / 1024 / 1024

    except Exception as e:
        duration = time.time() - start if 'start' in locals() else 0
        shared_dict[f'success_{request_id}'] = False
        shared_dict[f'error_{request_id}'] = str(e)
        shared_dict[f'duration_{request_id}'] = duration


@pytest.mark.performance
class TestRealPerformanceWithModels:
    """Real performance tests using actual models (when available)."""

    @pytest.fixture
    def tts_models(self):
        """Fixture providing TTS model paths."""
        return {
            'tacotron': Path("./tests/models/tts-model"),
            'waveglow': Path("./tests/models/waveglow.pt")
        }

    def test_real_single_request_response_time(self, tts_models, tmp_path):
        """
        Performance Test: REAL Single Request Response Time

        Measures actual TTS performance with real models.
        This test is skipped if models are not available.

        Expected metrics with real models:
        - Response time: 1-5 seconds (depending on hardware)
        - Memory: 200-800 MB
        - CPU: 20-80%
        """
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("Real models not available - run integration test instead")

        metrics = PerformanceMetrics()
        output_file = tmp_path / "real_test.wav"

        print("\n" + "="*80)
        print("🚀 REAL PERFORMANCE TEST - Using actual models")
        print("="*80)

        # Warm-up (loads models into memory)
        print("Warming up (loading models)...")
        TTS.convert_to_file(
            text="test",
            model_path=str(tts_models['tacotron']),
            waveglow_model_path=str(tts_models['waveglow']),
            out_wav=str(output_file)
        )

        # Actual measurement
        print("Measuring performance...")
        metrics.start_time = time.time()
        start = time.time()
        metrics.record_memory_usage()

        TTS.convert_to_file(
            text="ngana nzambi",
            model_path=str(tts_models['tacotron']),
            waveglow_model_path=str(tts_models['waveglow']),
            out_wav=str(output_file)
        )

        duration = time.time() - start
        metrics.record_response_time(duration)
        metrics.record_memory_usage()
        metrics.record_cpu_usage()
        metrics.record_success()
        metrics.end_time = time.time()

        # Assertions for real performance
        assert duration > 0.01, "Response time too fast - are models actually loading?"
        assert duration < 30.0, f"Single request took too long: {duration}s"

        print("\n" + "="*80)
        print("✅ REAL PERFORMANCE METRICS")
        print(f"   Response time: {duration:.4f}s")
        print(f"   This represents ACTUAL TTS processing time")
        print("="*80)

        metrics.print_report("REAL Single Request Response Time")


@pytest.mark.performance
class TestResponseTimeAnalysis:
    """Test response time performance under various conditions."""

    @pytest.fixture
    def mock_tts(self):
        """Mock TTS for performance testing."""
        fake_audio = np.zeros(22050, dtype=np.float32)  # 1 second of audio
        fake_hparams = MagicMock(sampling_rate=22050)

        with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
                   return_value=(fake_audio, fake_hparams)), \
             patch("kimbundu_speech_ai.tts.sf.write"):
            yield

    def test_single_request_response_time(self, mock_tts, tmp_path):
        """
        Performance Test: Single Request Response Time (MOCKED)

        NOTE: This test uses MOCKED TTS functions for fast execution.
        Response times will be near-zero because no real processing occurs.

        Purpose: Verify performance testing infrastructure, not measure real performance.
        For real performance metrics, use integration tests with actual models.
        """
        metrics = PerformanceMetrics()
        output_file = tmp_path / "test.wav"

        # Warm-up
        TTS.convert_to_file("test", "model", "waveglow", str(output_file))

        # Measure
        metrics.start_time = time.time()
        start = time.time()
        metrics.record_memory_usage()

        TTS.convert_to_file(
            text="ngana nzambi",
            model_path="model",
            waveglow_model_path="waveglow",
            out_wav=str(output_file)
        )

        duration = time.time() - start
        metrics.record_response_time(duration)
        metrics.record_memory_usage()
        metrics.record_cpu_usage()
        metrics.record_success()
        metrics.end_time = time.time()

        # Assertions - Very lenient because this is mocked
        assert duration < 5.0, f"Single request took too long: {duration}s"

        print("\n" + "="*80)
        print("⚠️  NOTE: This test uses MOCKED functions")
        print("   Response times near 0.0000s are EXPECTED")
        print("   Real performance metrics require actual models")
        print("="*80)

        metrics.print_report("Single Request Response Time (MOCKED)")

    def test_sequential_requests_response_time(self, mock_tts, tmp_path):
        """
        Performance Test: Sequential Requests Response Time
        Measure response time for multiple sequential requests.
        """
        metrics = PerformanceMetrics()
        num_requests = 10

        metrics.start_time = time.time()

        for i in range(num_requests):
            output_file = tmp_path / f"test_{i}.wav"

            start = time.time()
            metrics.record_memory_usage()

            try:
                TTS.convert_to_file(
                    text=f"test phrase {i}",
                    model_path="model",
                    waveglow_model_path="waveglow",
                    out_wav=str(output_file)
                )
                duration = time.time() - start
                metrics.record_response_time(duration)
                metrics.record_success()
            except Exception:
                metrics.record_error()

            metrics.record_cpu_usage()

        metrics.end_time = time.time()

        # Assertions
        stats = metrics.get_statistics()
        assert stats['response_time']['mean'] < 5.0, "Average response time too high"
        assert stats['throughput']['success_rate'] > 90, "Success rate too low"

        metrics.print_report("Sequential Requests (n=10)")

    def test_varying_input_sizes_response_time(self, mock_tts, tmp_path):
        """
        Performance Test: Response Time vs Input Size
        Analyze how response time scales with input size.
        """
        test_cases = [
            ("short", "test"),
            ("medium", "ngana nzambi kwa moyo"),
            ("long", "ngana nzambi kwa moyo " * 10),
            ("very_long", "ngana nzambi kwa moyo " * 50),
        ]

        results = {}

        for name, text in test_cases:
            metrics = PerformanceMetrics()
            output_file = tmp_path / f"{name}.wav"

            metrics.start_time = time.time()
            start = time.time()

            TTS.convert_to_file(
                text=text,
                model_path="model",
                waveglow_model_path="waveglow",
                out_wav=str(output_file)
            )

            duration = time.time() - start
            metrics.record_response_time(duration)
            metrics.record_memory_usage()
            metrics.record_success()
            metrics.end_time = time.time()

            results[name] = {
                'text_length': len(text),
                'duration': duration
            }

        # Print results
        print(f"\n{'='*80}")
        print("Response Time vs Input Size Analysis")
        print(f"{'='*80}")
        for name, data in results.items():
            print(f"{name:15s} | Length: {data['text_length']:4d} | Time: {data['duration']:.4f}s")
        print(f"{'='*80}\n")

        # Assert scaling is reasonable (not exponential)
        short_time = results['short']['duration']
        long_time = results['long']['duration']
        ratio = long_time / short_time if short_time > 0 else 0

        assert ratio < 50, f"Response time scaling too steep: {ratio}x"


@pytest.mark.performance
@pytest.mark.slow
class TestConcurrentLoadHandling:
    """Test system behavior under concurrent load."""

    @pytest.fixture
    def mock_tts(self):
        """Mock TTS for concurrent testing."""
        fake_audio = np.zeros(22050, dtype=np.float32)
        fake_hparams = MagicMock(sampling_rate=22050)

        with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
                   return_value=(fake_audio, fake_hparams)), \
             patch("kimbundu_speech_ai.tts.sf.write"):
            yield

    def test_concurrent_requests(self, mock_tts, tmp_path):
        """
        Performance Test: Concurrent Request Handling
        Test system behavior with concurrent requests.
        """
        metrics = PerformanceMetrics()
        num_threads = 5
        requests_per_thread = 3
        results = []
        lock = threading.Lock()

        def worker(thread_id):
            """Worker function for concurrent requests."""
            for i in range(requests_per_thread):
                output_file = tmp_path / f"thread_{thread_id}_req_{i}.wav"

                start = time.time()

                try:
                    TTS.convert_to_file(
                        text=f"test {thread_id}-{i}",
                        model_path="model",
                        waveglow_model_path="waveglow",
                        out_wav=str(output_file)
                    )
                    duration = time.time() - start

                    with lock:
                        metrics.record_response_time(duration)
                        metrics.record_success()
                        metrics.record_memory_usage()

                except Exception as e:
                    with lock:
                        metrics.record_error()
                        results.append(('error', str(e)))

        metrics.start_time = time.time()

        # Create and start threads
        threads = []
        for i in range(num_threads):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        metrics.end_time = time.time()

        # Assertions
        stats = metrics.get_statistics()
        assert stats['throughput']['success_rate'] > 80, "Too many failures under concurrent load"

        metrics.print_report(f"Concurrent Load ({num_threads} threads × {requests_per_thread} requests)")

    def test_thread_safety(self, mock_tts, tmp_path):
        """
        Performance Test: Thread Safety
        Verify thread safety under concurrent access.
        """
        num_threads = 10
        errors = []
        lock = threading.Lock()

        def worker(thread_id):
            """Worker that performs operations concurrently."""
            try:
                output_file = tmp_path / f"thread_safety_{thread_id}.wav"
                TTS.convert_to_file(
                    text=f"thread {thread_id}",
                    model_path="model",
                    waveglow_model_path="waveglow",
                    out_wav=str(output_file)
                )
            except Exception as e:
                with lock:
                    errors.append((thread_id, str(e)))

        threads = []
        for i in range(num_threads):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        # Assert no race conditions or crashes
        assert len(errors) == 0, f"Thread safety issues detected: {errors}"


@pytest.mark.performance
@pytest.mark.slow
class TestStressTests:
    """Stress tests to determine system limits using REAL models."""

    @pytest.fixture
    def tts_models(self):
        """Fixture providing REAL TTS model paths."""
        return {
            'tacotron': Path("./tests/models/tts-model"),
            'waveglow': Path("./tests/models/waveglow.pt")
        }

    def test_high_volume_stress(self, tts_models, tmp_path):
        """
        Stress Test: High Volume Processing with REAL Models
        Test system under high volume of requests.
        """
        # Check if real models exist
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("Real TTS models not available for stress testing")

        metrics = PerformanceMetrics()
        num_requests = 5  # Reduced for real models (would be ~10-25 seconds)

        print(f"\n{'='*80}")
        print(f"🚀 REAL HIGH VOLUME STRESS TEST - Using actual models")
        print(f"{'='*80}")
        print(f"🔥 Starting high volume stress test ({num_requests} requests)...")
        print(f"{'='*80}\n")

        metrics.start_time = time.time()

        for i in range(num_requests):
            output_file = tmp_path / f"stress_{i}.wav"

            start = time.time()

            try:
                TTS.convert_to_file(
                    text=f"ngana nzambi {i}",
                    model_path=str(tts_models['tacotron']),
                    waveglow_model_path=str(tts_models['waveglow']),
                    out_wav=str(output_file)
                )
                duration = time.time() - start
                metrics.record_response_time(duration)
                metrics.record_success()

                print(f"  Request {i+1}/{num_requests}: {duration:.4f}s - ✓ Success")

            except Exception as e:
                metrics.record_error()
                print(f"  Request {i+1}/{num_requests}: ✗ Failed - {e}")

            # Record memory and CPU for each request
            metrics.record_memory_usage()
            metrics.record_cpu_usage()

        metrics.end_time = time.time()

        # Assertions
        stats = metrics.get_statistics()
        assert stats['throughput']['success_rate'] > 95, "System failed under high volume"

        print(f"\n{'='*80}")
        metrics.print_report(f"REAL High Volume Stress Test (n={num_requests})")
        print(f"{'='*80}\n")

        print(f"✅ High volume stress test passed")
        print(f"{'='*80}\n")

    def test_extreme_input_stress(self, tts_models, tmp_path):
        """
        Stress Test: Extreme Input Sizes with REAL Models
        Test system with extremely large inputs.
        """
        # Check if real models exist
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("Real TTS models not available for extreme input stress testing")

        metrics = PerformanceMetrics()

        # Very long text (reduced from 500 to 100 for realistic testing)
        extreme_text = "ngana nzambi kwa moyo " * 100

        output_file = tmp_path / "extreme.wav"

        print(f"\n{'='*80}")
        print(f"🚀 REAL EXTREME INPUT STRESS TEST - Using actual models")
        print(f"{'='*80}")
        print(f"📝 Input size: {len(extreme_text)} characters")
        print(f"{'='*80}\n")

        metrics.start_time = time.time()
        start = time.time()

        try:
            TTS.convert_to_file(
                text=extreme_text,
                model_path=str(tts_models['tacotron']),
                waveglow_model_path=str(tts_models['waveglow']),
                out_wav=str(output_file)
            )
            duration = time.time() - start
            metrics.record_response_time(duration)
            metrics.record_memory_usage()
            metrics.record_success()

            print(f"✅ Successfully processed extreme input in {duration:.4f}s")

        except MemoryError:
            # Acceptable - system recognized limit
            metrics.record_error()
            print("✓ System correctly rejected extreme input due to memory limits")

        except Exception as e:
            # Should fail gracefully
            metrics.record_error()
            assert "crash" not in str(e).lower(), "System crashed on extreme input"
            print(f"✓ System handled extreme input gracefully: {type(e).__name__}")

        metrics.end_time = time.time()

        print(f"\n{'='*80}")
        print(f"✓ Extreme input stress test completed")
        print(f"  Input size: {len(extreme_text)} characters")
        print(f"  Result: {'Success' if metrics.success_count > 0 else 'Handled gracefully'}")
        print(f"{'='*80}\n")

    def test_memory_leak_detection(self, tts_models, tmp_path):
        """
        Stress Test: Memory Leak Detection with REAL Models
        Check for memory leaks over many iterations.
        """
        # Check if real models exist
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("Real TTS models not available for memory leak testing")

        metrics = PerformanceMetrics()
        num_iterations = 3  # Reduced for real models (would be ~6-15 seconds)

        print(f"\n{'='*80}")
        print(f"🚀 REAL MEMORY LEAK DETECTION - Using actual models")
        print(f"{'='*80}")
        print(f"🔍 Checking for memory leaks over {num_iterations} iterations...")
        print(f"{'='*80}\n")

        for i in range(num_iterations):
            output_file = tmp_path / f"memleak_{i}.wav"

            print(f"  Iteration {i+1}/{num_iterations}...", end=" ")

            TTS.convert_to_file(
                text="ngana nzambi",
                model_path=str(tts_models['tacotron']),
                waveglow_model_path=str(tts_models['waveglow']),
                out_wav=str(output_file)
            )

            metrics.record_memory_usage()
            print(f"Memory: {metrics.memory_usage[-1]:.2f} MB")

        # Analyze memory trend
        if len(metrics.memory_usage) > 1:
            first_half = metrics.memory_usage[:len(metrics.memory_usage)//2] if len(metrics.memory_usage) > 2 else [metrics.memory_usage[0]]
            second_half = metrics.memory_usage[len(metrics.memory_usage)//2:]

            avg_first = statistics.mean(first_half)
            avg_second = statistics.mean(second_half)

            memory_increase = avg_second - avg_first
            increase_percent = (memory_increase / avg_first * 100) if avg_first > 0 else 0

            print(f"\n{'='*80}")
            print(f"  First half avg:  {avg_first:.2f} MB")
            print(f"  Second half avg: {avg_second:.2f} MB")
            print(f"  Increase:        {memory_increase:.2f} MB ({increase_percent:.2f}%)")

            # Assert no significant memory leak (< 20% increase)
            assert increase_percent < 20, f"Potential memory leak detected: {increase_percent:.2f}% increase"

            print(f"✓ No significant memory leak detected")
            print(f"{'='*80}\n")


@pytest.mark.performance
class TestScalabilityTests:
    """Test system scalability with increasing load using REAL models."""

    @pytest.fixture
    def tts_models(self):
        """Fixture providing REAL TTS model paths."""
        return {
            'tacotron': Path("./tests/models/tts-model"),
            'waveglow': Path("./tests/models/waveglow.pt")
        }

    def test_linear_scalability(self, tts_models, tmp_path):
        """
        Scalability Test: Find Maximum Concurrent Load Capacity with MULTIPROCESSING
        Uses separate processes (not threads) to bypass Python GIL and achieve TRUE parallelism.
        Discovers how many SIMULTANEOUS requests the system can handle.
        """
        # Check if real models exist
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("Real TTS models not available for scalability testing")

        # Test with increasing concurrent loads
        concurrent_loads = [1, 3, 5]  # How many simultaneous requests
        results = []

        print(f"\n{'='*80}")
        print(f"🚀 SCALABILITY TEST: Maximum Concurrent Capacity (MULTIPROCESSING)")
        print(f"{'='*80}")
        print(f"📈 Testing system capacity with concurrent loads: {concurrent_loads}")
        print(f"   Using PROCESSES (not threads) to bypass Python GIL")
        print(f"   Goal: Achieve TRUE parallel execution and find breaking point")
        print(f"{'='*80}\n")

        for num_concurrent in concurrent_loads:
            print(f"\n{'─'*80}")
            print(f"⚡ Load Test: {num_concurrent} SIMULTANEOUS requests (PROCESSES)")
            print(f"{'─'*80}")

            # Use Manager to share data between processes
            manager = Manager()
            shared_dict = manager.dict()

            # Launch ALL requests SIMULTANEOUSLY as PROCESSES
            start_time = time.time()

            processes = []
            for i in range(num_concurrent):
                p = Process(
                    target=_scalability_worker,
                    args=(
                        i,
                        num_concurrent,
                        str(tmp_path),
                        str(tts_models['tacotron']),
                        str(tts_models['waveglow']),
                        shared_dict
                    )
                )
                processes.append(p)

            # Start all processes at once!
            for p in processes:
                p.start()

            # Wait for all processes to finish
            for p in processes:
                p.join()

            end_time = time.time()
            total_time = end_time - start_time

            # Collect results from shared dictionary
            response_times = []
            memory_usage = []
            successful = 0
            failed = 0
            errors = []

            for i in range(num_concurrent):
                duration = shared_dict.get(f'duration_{i}', 0)
                response_times.append(duration)

                if shared_dict.get(f'success_{i}', False):
                    successful += 1
                    memory = shared_dict.get(f'memory_{i}', 0)
                    memory_usage.append(memory)
                    print(f"  ✓ Request {i+1:2d}/{num_concurrent}: {duration:.2f}s")
                else:
                    failed += 1
                    error = shared_dict.get(f'error_{i}', 'Unknown error')
                    errors.append((i, error))
                    print(f"  ✗ Request {i+1:2d}/{num_concurrent}: FAILED after {duration:.2f}s")

            # Calculate statistics
            success_rate = (successful / num_concurrent * 100) if num_concurrent > 0 else 0
            mean_rt = statistics.mean(response_times) if response_times else 0
            max_rt = max(response_times) if response_times else 0
            min_rt = min(response_times) if response_times else 0
            throughput = successful / total_time if total_time > 0 else 0
            memory_peak = max(memory_usage) if memory_usage else 0

            results.append({
                'concurrent_load': num_concurrent,
                'total_requests': num_concurrent,
                'successful': successful,
                'failed': failed,
                'success_rate': success_rate,
                'total_time': total_time,
                'mean_response_time': mean_rt,
                'max_response_time': max_rt,
                'min_response_time': min_rt,
                'memory_peak': memory_peak,
                'throughput': throughput
            })

            print(f"\n  📊 Summary:")
            print(f"     Total time:    {total_time:.2f}s")
            print(f"     Success rate:  {success_rate:.1f}% ({successful}/{num_concurrent})")
            print(f"     Avg response:  {mean_rt:.2f}s")
            print(f"     Max response:  {max_rt:.2f}s")
            print(f"     Throughput:    {throughput:.2f} req/s")

        # Print comprehensive scalability report
        print(f"\n{'='*80}")
        print("📊 SCALABILITY ANALYSIS REPORT (MULTIPROCESSING)")
        print(f"{'='*80}")
        print(f"{'Load':>6s} | {'Success':>7s} | {'Failed':>6s} | {'Total Time':>11s} | {'Avg RT':>8s} | {'Max RT':>8s} | {'Throughput':>11s}")
        print(f"{'-'*80}")

        for r in results:
            print(f"{r['concurrent_load']:6d} | "
                  f"{r['successful']:4d}/{r['total_requests']:2d} | "
                  f"{r['failed']:6d} | "
                  f"{r['total_time']:11.2f}s | "
                  f"{r['mean_response_time']:8.2f}s | "
                  f"{r['max_response_time']:8.2f}s | "
                  f"{r['throughput']:8.2f} r/s")

        print(f"{'='*80}\n")

        # Analyze results to find breaking point
        print(f"🔍 SCALABILITY ANALYSIS:")
        print(f"{'─'*80}")

        breaking_point = None
        for i, r in enumerate(results):
            if r['success_rate'] < 95:
                breaking_point = r['concurrent_load']
                print(f"⚠️  Breaking Point: {breaking_point} concurrent requests")
                print(f"   System starts failing at this load (success rate: {r['success_rate']:.1f}%)")
                break

        if not breaking_point:
            max_tested = results[-1]['concurrent_load']
            print(f"✅ System handled up to {max_tested} concurrent requests successfully!")
            print(f"   No breaking point found in tested range")

        # Response time degradation
        baseline_rt = results[0]['mean_response_time']
        max_rt = results[-1]['mean_response_time']
        rt_increase = ((max_rt - baseline_rt) / baseline_rt * 100) if baseline_rt > 0 else 0

        print(f"\n📈 Response Time Degradation:")
        print(f"   1 concurrent:  {baseline_rt:.2f}s")
        print(f"   {results[-1]['concurrent_load']} concurrent: {max_rt:.2f}s")
        print(f"   Increase: {rt_increase:.1f}%")

        if rt_increase < 100:
            print(f"   ✅ EXCELLENT scalability (< 100% increase)")
            print(f"      TRUE parallel execution achieved!")
        elif rt_increase < 200:
            print(f"   ✅ Good scalability (100-200% increase)")
            print(f"      Significant parallel execution")
        else:
            print(f"   ⚠️  Limited scalability (> 200% increase)")
            print(f"      Some bottleneck still exists")

        # Throughput analysis
        print(f"\n⚡ Throughput Analysis:")
        best_throughput = max(r['throughput'] for r in results)
        best_load = [r for r in results if r['throughput'] == best_throughput][0]
        print(f"   Best throughput: {best_throughput:.2f} req/s at {best_load['concurrent_load']} concurrent")

        # Compare with baseline (should scale linearly if truly parallel)
        baseline_throughput = results[0]['throughput']
        throughput_improvement = (best_throughput / baseline_throughput) if baseline_throughput > 0 else 0
        print(f"   Throughput improvement: {throughput_improvement:.2f}x over single request")

        if throughput_improvement >= 0.8 * best_load['concurrent_load']:
            print(f"   ✅ Near-linear scaling! (achieved {throughput_improvement:.1f}x out of theoretical {best_load['concurrent_load']}x)")
        elif throughput_improvement >= 0.5 * best_load['concurrent_load']:
            print(f"   ✅ Good scaling (achieved {throughput_improvement:.1f}x out of theoretical {best_load['concurrent_load']}x)")
        else:
            print(f"   ⚠️  Limited scaling (achieved {throughput_improvement:.1f}x out of theoretical {best_load['concurrent_load']}x)")

        print(f"\n💡 CONCLUSION:")
        if breaking_point:
            print(f"   System capacity: Up to {breaking_point - 1} concurrent requests")
            print(f"   Recommendation: Limit to {max(1, breaking_point - 2)} concurrent for safety")
        else:
            print(f"   System capacity: > {results[-1]['concurrent_load']} concurrent requests")
            print(f"   With multiprocessing, achieved TRUE parallel execution!")

        print(f"{'='*80}\n")

        # Assert: At least the baseline should work
        assert results[0]['success_rate'] == 100, "System failed even with single request!"

        print(f"✅ Scalability test completed (MULTIPROCESSING)\n")

    def test_sustained_load_scalability(self, tts_models, tmp_path):
        """
        Scalability Test: Sustained Load with REAL Models
        Test system under sustained load over time.
        """
        # Check if real models exist
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("Real TTS models not available for sustained load testing")

        metrics = PerformanceMetrics()
        max_requests = 3  # Limit to 3 requests (will take ~6-15 seconds with real models)
        request_count = 0

        print(f"\n{'='*80}")
        print(f"🚀 SUSTAINED LOAD TEST - Using actual models")
        print(f"{'='*80}")
        print(f"⏱️  Running sustained load test (max {max_requests} requests)...")
        print(f"{'='*80}\n")

        metrics.start_time = time.time()

        for request_count in range(max_requests):
            output_file = tmp_path / f"sustained_{request_count}.wav"

            start = time.time()

            try:
                TTS.convert_to_file(
                    text=f"ngana nzambi {request_count}",
                    model_path=str(tts_models['tacotron']),
                    waveglow_model_path=str(tts_models['waveglow']),
                    out_wav=str(output_file)
                )
                response_time = time.time() - start
                metrics.record_response_time(response_time)
                metrics.record_success()

                print(f"  Request {request_count+1}/{max_requests}: {response_time:.4f}s")

            except Exception as e:
                metrics.record_error()
                print(f"  Request {request_count+1}/{max_requests}: FAILED - {e}")

            # Record resources
            metrics.record_memory_usage()
            metrics.record_cpu_usage()

        metrics.end_time = time.time()

        print(f"\n{'='*80}")
        metrics.print_report(f"Sustained Load Test ({max_requests} requests)")
        print(f"{'='*80}\n")

        # Assert system remained stable
        stats = metrics.get_statistics()
        assert stats['throughput']['success_rate'] > 90, "System unstable under sustained load"

        print(f"✅ Sustained load test passed")
        print(f"{'='*80}\n")


@pytest.mark.performance
class TestPerformanceBenchmarks:
    """Benchmark tests for performance regression detection."""

    @pytest.fixture
    def mock_tts(self):
        """Mock TTS for benchmarking."""
        fake_audio = np.zeros(22050, dtype=np.float32)
        fake_hparams = MagicMock(sampling_rate=22050)

        with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
                   return_value=(fake_audio, fake_hparams)), \
             patch("kimbundu_speech_ai.tts.sf.write"):
            yield

    def test_baseline_benchmark(self, mock_tts, tmp_path, benchmark):
        """
        Benchmark: Baseline Performance
        Establish baseline performance metrics.
        """
        output_file = tmp_path / "benchmark.wav"

        # Benchmark the function
        result = benchmark(
            TTS.convert_to_file,
            text="ngana nzambi",
            model_path="model",
            waveglow_model_path="waveglow",
            out_wav=str(output_file)
        )

        # Benchmark automatically records stats
        print(f"\n✓ Baseline benchmark completed")

    def test_performance_regression_check(self, mock_tts, tmp_path):
        """
        Benchmark: Performance Regression Check
        Ensure performance hasn't regressed.
        """
        # Define acceptable performance thresholds
        thresholds = {
            'max_response_time': 5.0,  # seconds
            'min_success_rate': 95.0,  # percent
        }

        metrics = PerformanceMetrics()
        num_samples = 10

        metrics.start_time = time.time()

        for i in range(num_samples):
            output_file = tmp_path / f"regression_{i}.wav"

            start = time.time()

            try:
                TTS.convert_to_file(
                    text="regression test",
                    model_path="model",
                    waveglow_model_path="waveglow",
                    out_wav=str(output_file)
                )
                duration = time.time() - start
                metrics.record_response_time(duration)
                metrics.record_success()

            except Exception:
                metrics.record_error()

        metrics.end_time = time.time()

        stats = metrics.get_statistics()

        # Check against thresholds
        print(f"\n{'='*80}")
        print("Performance Regression Check")
        print(f"{'='*80}")
        print(f"Max Response Time:  {stats['response_time']['max']:.4f}s (threshold: {thresholds['max_response_time']}s)")
        print(f"Success Rate:       {stats['throughput']['success_rate']:.2f}% (threshold: {thresholds['min_success_rate']}%)")

        assert stats['response_time']['max'] < thresholds['max_response_time'], \
            f"Performance regression: Max response time {stats['response_time']['max']:.4f}s exceeds threshold"

        assert stats['throughput']['success_rate'] >= thresholds['min_success_rate'], \
            f"Performance regression: Success rate {stats['throughput']['success_rate']:.2f}% below threshold"

        print(f"✓ No performance regression detected")
        print(f"{'='*80}\n")
