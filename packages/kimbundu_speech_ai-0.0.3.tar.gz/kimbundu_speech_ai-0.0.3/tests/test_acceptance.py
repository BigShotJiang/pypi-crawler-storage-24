"""
Acceptance tests for Kimbundu Speech AI
Tests complete user workflows and real-world scenarios from an end-user perspective.
"""
import sys
import pytest
import os
import tempfile
from pathlib import Path
import soundfile as sf
import numpy as np

sys.path.insert(0, "C:/Users/rsabino/Documents/projecto final/kutanga/tts_package/src")

from kimbundu_speech_ai import TTS, STT


@pytest.mark.acceptance
class TestTextToSpeechWorkflows:
    """Test complete TTS workflows from user perspective."""

    @pytest.fixture
    def tts_models(self):
        """Fixture providing TTS model paths."""
        return {
            'tacotron': Path("./tests/models/tts-model"),
            'waveglow': Path("./tests/models/waveglow.pt")
        }

    @pytest.fixture
    def temp_output_dir(self):
        """Create a temporary directory for test outputs."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_user_converts_simple_text_to_speech(self, tts_models, temp_output_dir):
        """
        Scenario: User wants to convert a simple Kimbundu phrase to speech
        Given: A simple text phrase "nzambi"
        When: User calls convert_to_file
        Then: A valid WAV file is created with audio content
        """
        # Skip if models don't exist
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("TTS models not available for acceptance testing")

        text = "nzambi"
        output_file = temp_output_dir / "output.wav"

        # User action: Convert text to speech
        result = TTS.convert_to_file(
            text=text,
            model_path=str(tts_models['tacotron']),
            waveglow_model_path=str(tts_models['waveglow']),
            out_wav=str(output_file)
        )

        # Verify: File was created
        assert Path(result).exists(), "Output file should exist"
        assert result == str(output_file), "Returned path should match requested path"

        # Verify: File is a valid WAV file
        audio_data, sample_rate = sf.read(result)
        assert audio_data.size > 0, "Audio file should contain data"
        assert sample_rate == 22050, "Sample rate should be 22050 Hz"
        assert audio_data.ndim == 1, "Audio should be mono"

        # Verify: Audio has reasonable duration (not too short or too long)
        duration_seconds = len(audio_data) / sample_rate
        assert 0.1 < duration_seconds < 10, f"Audio duration should be reasonable, got {duration_seconds}s"

    def test_user_converts_long_sentence_to_speech(self, tts_models, temp_output_dir):
        """
        Scenario: User wants to convert a longer Kimbundu sentence to speech
        Given: A longer text phrase
        When: User calls convert_to_file
        Then: A valid WAV file is created with proportionally longer audio
        """
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("TTS models not available for acceptance testing")

        text = "ngana nzambi mua muene"  # Longer phrase
        output_file = temp_output_dir / "long_output.wav"

        result = TTS.convert_to_file(
            text=text,
            model_path=str(tts_models['tacotron']),
            waveglow_model_path=str(tts_models['waveglow']),
            out_wav=str(output_file)
        )

        # Verify file exists and is valid
        assert Path(result).exists()
        audio_data, sample_rate = sf.read(result)
        assert audio_data.size > 0

        # Verify longer text produces longer audio
        duration_seconds = len(audio_data) / sample_rate
        assert duration_seconds > 0.5, "Longer text should produce longer audio"

    def test_user_generates_multiple_audio_files(self, tts_models, temp_output_dir):
        """
        Scenario: User wants to generate multiple audio files in sequence
        Given: Multiple text phrases
        When: User calls convert_to_file multiple times
        Then: All files are created successfully without interference
        """
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("TTS models not available for acceptance testing")

        phrases = [
            ("nzambi", "phrase1.wav"),
            ("ngana", "phrase2.wav"),
            ("moyo", "phrase3.wav")
        ]

        created_files = []

        for text, filename in phrases:
            output_file = temp_output_dir / filename

            result = TTS.convert_to_file(
                text=text,
                model_path=str(tts_models['tacotron']),
                waveglow_model_path=str(tts_models['waveglow']),
                out_wav=str(output_file)
            )

            created_files.append(result)

            # Verify each file is created
            assert Path(result).exists()
            audio_data, _ = sf.read(result)
            assert audio_data.size > 0

        # Verify all files still exist and are independent
        assert len(created_files) == 3
        for file_path in created_files:
            assert Path(file_path).exists(), f"{file_path} should still exist"

    def test_user_specifies_custom_output_path(self, tts_models, temp_output_dir):
        """
        Scenario: User wants to save audio to a specific location
        Given: A custom output path
        When: User calls convert_to_file with custom path
        Then: Audio is saved to the exact specified location
        """
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("TTS models not available for acceptance testing")

        text = "nzambi"
        custom_path = temp_output_dir / "my_folder" / "custom_name.wav"
        custom_path.parent.mkdir(parents=True, exist_ok=True)

        result = TTS.convert_to_file(
            text=text,
            model_path=str(tts_models['tacotron']),
            waveglow_model_path=str(tts_models['waveglow']),
            out_wav=str(custom_path)
        )

        # Verify file is at exact location
        assert result == str(custom_path)
        assert Path(result).exists()
        assert Path(result).name == "custom_name.wav"


@pytest.mark.acceptance
class TestSpeechToTextWorkflows:
    """Test complete STT workflows from user perspective."""

    @pytest.fixture
    def stt_model(self):
        """Fixture providing STT model path."""
        return Path("./tests/models/stt-model")

    @pytest.fixture
    def sample_audio(self):
        """Fixture providing sample audio file."""
        return Path("./tests/data/sample.wav")

    def test_user_transcribes_audio_file(self, stt_model, sample_audio):
        """
        Scenario: User wants to transcribe a Kimbundu audio recording
        Given: An audio file with Kimbundu speech
        When: User calls convert_to_text
        Then: Text transcription is returned
        """
        if not stt_model.exists() or not sample_audio.exists():
            pytest.skip("STT model or sample audio not available for acceptance testing")

        # User action: Transcribe audio
        transcription = STT.convert_to_text(
            audio_path=str(sample_audio),
            model_path=str(stt_model)
        )

        # Verify: Transcription is returned
        assert isinstance(transcription, str), "Transcription should be a string"
        assert len(transcription) > 0, "Transcription should not be empty"
        assert transcription.strip() == transcription, "Transcription should be trimmed"

    def test_user_transcribes_multiple_files(self, stt_model, sample_audio):
        """
        Scenario: User wants to transcribe multiple audio files
        Given: Multiple audio files
        When: User calls convert_to_text for each
        Then: Each transcription is returned successfully
        """
        if not stt_model.exists() or not sample_audio.exists():
            pytest.skip("STT model or sample audio not available for acceptance testing")

        # Simulate transcribing multiple files (using same file for test)
        transcriptions = []

        for i in range(3):
            transcription = STT.convert_to_text(
                audio_path=str(sample_audio),
                model_path=str(stt_model)
            )
            transcriptions.append(transcription)

        # Verify all transcriptions succeeded
        assert len(transcriptions) == 3
        for transcription in transcriptions:
            assert isinstance(transcription, str)
            assert len(transcription) > 0


@pytest.mark.acceptance
class TestErrorHandlingWorkflows:
    """Test error scenarios from user perspective."""

    def test_user_provides_nonexistent_audio_file(self):
        """
        Scenario: User tries to transcribe a file that doesn't exist
        Given: A non-existent audio file path
        When: User calls convert_to_text
        Then: Clear error is raised
        """
        with pytest.raises(Exception) as exc_info:
            STT.convert_to_text(
                audio_path="nonexistent_file.wav",
                model_path="some_model"
            )

        # Verify error is informative
        assert exc_info.value is not None

    def test_user_provides_nonexistent_model(self):
        """
        Scenario: User tries to use a model that doesn't exist
        Given: A non-existent model path
        When: User calls TTS or STT functions
        Then: Clear error is raised
        """
        # Create a temporary valid audio file
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
            # Create minimal valid WAV
            sample_rate = 16000
            duration = 1
            audio = np.zeros(sample_rate * duration, dtype=np.float32)
            sf.write(tmp.name, audio, sample_rate)
            tmp_path = tmp.name

        try:
            with pytest.raises(Exception) as exc_info:
                STT.convert_to_text(
                    audio_path=tmp_path,
                    model_path="nonexistent_model_path"
                )

            assert exc_info.value is not None
        finally:
            # Cleanup
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

    def test_user_provides_invalid_output_directory(self):
        """
        Scenario: User tries to save audio to an invalid directory
        Given: An invalid/inaccessible output path
        When: User calls convert_to_file
        Then: Clear error is raised or handled gracefully
        """
        # This test verifies that the system handles invalid paths
        # The exact behavior (error vs handling) depends on implementation
        invalid_path = "/invalid/directory/that/does/not/exist/output.wav"

        # We expect this to fail in some way
        # Either during model loading or file writing
        try:
            TTS.convert_to_file(
                text="test",
                model_path="nonexistent",
                waveglow_model_path="nonexistent",
                out_wav=invalid_path
            )
            pytest.fail("Should have raised an exception for invalid path")
        except Exception:
            # Expected - some error should occur
            pass


@pytest.mark.acceptance
class TestEndToEndWorkflows:
    """Test complete end-to-end workflows combining TTS and STT."""

    @pytest.fixture
    def all_models(self):
        """Fixture providing all model paths."""
        return {
            'tts_tacotron': Path("./tests/models/tts-model"),
            'tts_waveglow': Path("./tests/models/waveglow.pt"),
            'stt_model': Path("./tests/models/stt-model")
        }

    def test_text_to_speech_to_text_roundtrip(self, all_models, tmp_path):
        """
        Scenario: User converts text to speech, then back to text
        Given: Original Kimbundu text
        When: User converts text→speech→text
        Then: The roundtrip preserves the general content
        """
        # Skip if models don't exist
        if not all(model.exists() for model in all_models.values()):
            pytest.skip("All models not available for end-to-end testing")

        original_text = "nzambi"
        audio_file = tmp_path / "roundtrip.wav"

        # Step 1: Text to Speech
        TTS.convert_to_file(
            text=original_text,
            model_path=str(all_models['tts_tacotron']),
            waveglow_model_path=str(all_models['tts_waveglow']),
            out_wav=str(audio_file)
        )

        # Verify audio was created
        assert audio_file.exists()

        # Step 2: Speech to Text
        transcription = STT.convert_to_text(
            audio_path=str(audio_file),
            model_path=str(all_models['stt_model'])
        )

        # Verify transcription
        assert isinstance(transcription, str)
        assert len(transcription) > 0

        # Note: Exact match may not be expected due to model limitations
        # But transcription should contain relevant content


@pytest.mark.acceptance
class TestDataQualityWorkflows:
    """Test data quality and validation from user perspective."""

    @pytest.fixture
    def tts_models(self):
        """Fixture providing TTS model paths."""
        return {
            'tacotron': Path("./tests/models/tts-model"),
            'waveglow': Path("./tests/models/waveglow.pt")
        }

    def test_generated_audio_has_correct_format(self, tts_models, tmp_path):
        """
        Scenario: User needs audio in specific format for their application
        Given: Generated audio file
        When: User examines the audio properties
        Then: Audio meets expected specifications (mono, 22050Hz, 16-bit)
        """
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("TTS models not available")

        output_file = tmp_path / "format_test.wav"

        TTS.convert_to_file(
            text="nzambi",
            model_path=str(tts_models['tacotron']),
            waveglow_model_path=str(tts_models['waveglow']),
            out_wav=str(output_file)
        )

        # Load and verify audio properties
        audio_data, sample_rate = sf.read(output_file)

        # Verify format specifications
        assert sample_rate == 22050, "Sample rate should be 22050 Hz"
        assert audio_data.ndim == 1, "Audio should be mono (1 channel)"
        assert audio_data.dtype in [np.float32, np.float64, np.int16], "Valid audio data type"

        # Verify audio is not silent
        assert np.abs(audio_data).max() > 0, "Audio should not be completely silent"

    def test_audio_file_size_is_reasonable(self, tts_models, tmp_path):
        """
        Scenario: User is concerned about file sizes for storage
        Given: Generated audio file
        When: User checks file size
        Then: File size is reasonable for the audio duration
        """
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("TTS models not available")

        output_file = tmp_path / "size_test.wav"

        TTS.convert_to_file(
            text="nzambi",
            model_path=str(tts_models['tacotron']),
            waveglow_model_path=str(tts_models['waveglow']),
            out_wav=str(output_file)
        )

        # Check file size
        file_size_bytes = output_file.stat().st_size

        # WAV file should have reasonable size
        # For a short word, expect between 10KB and 5MB
        assert 10_000 < file_size_bytes < 5_000_000, \
            f"File size {file_size_bytes} bytes seems unreasonable"

        # Calculate expected size based on audio duration
        audio_data, sample_rate = sf.read(output_file)
        duration_seconds = len(audio_data) / sample_rate

        # Rough estimate: 16-bit mono at 22050Hz ≈ 44.1KB per second
        expected_size = duration_seconds * 44100
        tolerance = 0.5  # Allow 50% variance

        assert (1 - tolerance) * expected_size < file_size_bytes < (1 + tolerance) * expected_size * 2, \
            "File size should be proportional to audio duration"


@pytest.mark.acceptance
@pytest.mark.slow
class TestPerformanceWorkflows:
    """Test performance aspects from user perspective."""

    @pytest.fixture
    def tts_models(self):
        """Fixture providing TTS model paths."""
        return {
            'tacotron': Path("./tests/models/tts-model"),
            'waveglow': Path("./tests/models/waveglow.pt")
        }

    def test_batch_processing_performance(self, tts_models, tmp_path):
        """
        Scenario: User needs to process multiple phrases efficiently
        Given: Multiple text phrases
        When: User processes them sequentially
        Then: Each completes in reasonable time
        """
        if not tts_models['tacotron'].exists() or not tts_models['waveglow'].exists():
            pytest.skip("TTS models not available")

        import time

        phrases = ["nzambi", "ngana", "moyo", "kwa", "yandi"]
        processing_times = []

        for i, phrase in enumerate(phrases):
            output_file = tmp_path / f"batch_{i}.wav"

            start_time = time.time()

            TTS.convert_to_file(
                text=phrase,
                model_path=str(tts_models['tacotron']),
                waveglow_model_path=str(tts_models['waveglow']),
                out_wav=str(output_file)
            )

            elapsed = time.time() - start_time
            processing_times.append(elapsed)

            # Each should complete in reasonable time (< 30 seconds)
            assert elapsed < 30, f"Processing took too long: {elapsed}s"

        # Verify all files were created
        assert len(processing_times) == len(phrases)
        for i in range(len(phrases)):
            assert (tmp_path / f"batch_{i}.wav").exists()
