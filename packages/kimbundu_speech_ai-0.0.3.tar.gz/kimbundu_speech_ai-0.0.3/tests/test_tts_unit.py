import sys
import pytest
from unittest.mock import MagicMock, patch, call
import tempfile
import os

sys.path.insert(0, "C:/Users/rsabino/Documents/projecto final/kutanga/tts_package/src")

from kimbundu_speech_ai import TTS
import numpy as np


@pytest.mark.unit
def test_convert_to_file_writes_audio():
    """Test that convert_to_file correctly writes audio data to a WAV file."""
    # Setup test data
    fake_audio = np.zeros(100, dtype=np.float32)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)) as mock_get_audio, \
         patch("kimbundu_speech_ai.tts.sf.write") as mock_write:

        result = TTS.convert_to_file(
            text="nzambi",
            model_path="ckpt",
            waveglow_model_path="wg.pt",
            out_wav="out.wav"
        )

        # Verify get_audio_hparams was called with correct parameters
        mock_get_audio.assert_called_once_with("ckpt", "wg.pt", "nzambi", device='cpu')

        # Verify sf.write was called with correct parameters
        mock_write.assert_called_once_with("out.wav", fake_audio, 22050)

        # Verify return value
        assert result == "out.wav"


@pytest.mark.unit
def test_convert_to_file_returns_path():
    """Test that convert_to_file returns the correct output path."""
    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(np.zeros(10), MagicMock(sampling_rate=22050))), \
         patch("kimbundu_speech_ai.tts.sf.write"):

        result = TTS.convert_to_file(
            text="nzambi",
            model_path="ckpt",
            waveglow_model_path="wg.pt",
            out_wav="audio.wav"
        )

        assert result == "audio.wav"
        assert isinstance(result, str)


@pytest.mark.unit
def test_convert_to_file_with_device():
    """Test that convert_to_file respects the device parameter."""
    fake_audio = np.zeros(100)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)) as mock_get_audio, \
         patch("kimbundu_speech_ai.tts.sf.write"):

        TTS.convert_to_file(
            text="nzambi",
            model_path="ckpt",
            waveglow_model_path="wg.pt",
            out_wav="out.wav",
            device="cuda"
        )

        # Verify device parameter was passed correctly
        mock_get_audio.assert_called_once()
        call_kwargs = mock_get_audio.call_args[1]
        assert call_kwargs['device'] == "cuda"


@pytest.mark.unit
def test_convert_to_file_audio_generation_failed():
    """Test error handling when audio generation fails."""
    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               side_effect=RuntimeError("Model generation failed")):

        with pytest.raises(RuntimeError, match="Model generation failed"):
            TTS.convert_to_file(
                text="nzambi",
                model_path="ckpt",
                waveglow_model_path="wg.pt"
            )


@pytest.mark.unit
def test_convert_to_file_write_failed():
    """Test error handling when file writing fails."""
    fake_audio = np.zeros(100)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)), \
         patch("kimbundu_speech_ai.tts.sf.write",
               side_effect=IOError("Cannot write to file")):

        with pytest.raises(IOError, match="Cannot write to file"):
            TTS.convert_to_file(
                text="nzambi",
                model_path="ckpt",
                waveglow_model_path="wg.pt",
                out_wav="/invalid/path/out.wav"
            )


@pytest.mark.unit
def test_play_default_player_creates_temp_file():
    """Test that play_default_player creates a temporary WAV file."""
    fake_audio = np.zeros(1000)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)), \
         patch("kimbundu_speech_ai.tts.sf.write") as mock_write, \
         patch("kimbundu_speech_ai.tts.os.system") as mock_system, \
         patch("kimbundu_speech_ai.tts.platform.system", return_value="Windows"):

        TTS.play_default_player(
            text="nzambi",
            model_path="ckpt",
            waveglow_model_path="wg.pt"
        )

        # Verify a temporary file was created and written
        assert mock_write.called
        written_path = mock_write.call_args[0][0]
        assert written_path.endswith('.wav')

        # Verify system command was called to play the file
        assert mock_system.called


@pytest.mark.unit
def test_play_default_player_windows():
    """Test that play_default_player uses correct command on Windows."""
    fake_audio = np.zeros(100)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)), \
         patch("kimbundu_speech_ai.tts.sf.write"), \
         patch("kimbundu_speech_ai.tts.os.system") as mock_system, \
         patch("kimbundu_speech_ai.tts.platform.system", return_value="Windows"):

        TTS.play_default_player(
            text="nzambi",
            model_path="ckpt",
            waveglow_model_path="wg.pt"
        )

        # Verify Windows 'start' command was used
        call_args = mock_system.call_args[0][0]
        assert call_args.startswith('start ')


@pytest.mark.unit
def test_play_default_player_macos():
    """Test that play_default_player uses correct command on macOS."""
    fake_audio = np.zeros(100)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)), \
         patch("kimbundu_speech_ai.tts.sf.write"), \
         patch("kimbundu_speech_ai.tts.os.system") as mock_system, \
         patch("kimbundu_speech_ai.tts.platform.system", return_value="Darwin"):

        TTS.play_default_player(
            text="nzambi",
            model_path="ckpt",
            waveglow_model_path="wg.pt"
        )

        # Verify macOS 'afplay' command was used
        call_args = mock_system.call_args[0][0]
        assert 'afplay' in call_args


@pytest.mark.unit
def test_play_default_player_linux():
    """Test that play_default_player uses correct command on Linux."""
    fake_audio = np.zeros(100)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)), \
         patch("kimbundu_speech_ai.tts.sf.write"), \
         patch("kimbundu_speech_ai.tts.os.system") as mock_system, \
         patch("kimbundu_speech_ai.tts.platform.system", return_value="Linux"):

        TTS.play_default_player(
            text="nzambi",
            model_path="ckpt",
            waveglow_model_path="wg.pt"
        )

        # Verify Linux 'aplay' command was used
        call_args = mock_system.call_args[0][0]
        assert 'aplay' in call_args


@pytest.mark.unit
def test_play_default_player_audio_generation_failed():
    """Test error handling when audio generation fails in play_default_player."""
    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               side_effect=RuntimeError("generation failed")):

        with pytest.raises(RuntimeError, match="generation failed"):
            TTS.play_default_player(
                text="nzambi",
                model_path="ckpt",
                waveglow_model_path="wg.pt"
            )


@pytest.mark.unit
def test_convert_to_file_empty_text():
    """Test that empty text is handled correctly."""
    fake_audio = np.zeros(10)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)) as mock_get_audio, \
         patch("kimbundu_speech_ai.tts.sf.write"):

        result = TTS.convert_to_file(
            text="",
            model_path="ckpt",
            waveglow_model_path="wg.pt",
            out_wav="output.wav"
        )

        # Verify empty text was passed to the model
        assert mock_get_audio.call_args[0][2] == ""
        assert result == "output.wav"


@pytest.mark.unit
def test_convert_to_file_long_text():
    """Test that long text is handled correctly."""
    long_text = "nzambi " * 100  # Very long text
    fake_audio = np.zeros(10000)
    fake_hparams = MagicMock(sampling_rate=22050)

    with patch("kimbundu_speech_ai.tts._Internal.get_audio_hparams",
               return_value=(fake_audio, fake_hparams)) as mock_get_audio, \
         patch("kimbundu_speech_ai.tts.sf.write"):

        result = TTS.convert_to_file(
            text=long_text,
            model_path="ckpt",
            waveglow_model_path="wg.pt",
            out_wav="output.wav"
        )

        # Verify long text was passed to the model
        assert mock_get_audio.call_args[0][2] == long_text
        assert result == "output.wav"