import sys
import pytest
from unittest.mock import MagicMock, patch, Mock

sys.path.insert(0, "C:/Users/rsabino/Documents/projecto final/kutanga/tts_package/src")

from kimbundu_speech_ai import STT
import numpy as np
import torch


@pytest.mark.unit
def test_convert_to_text_audio_not_found():
    """Test that FileNotFoundError is raised when audio file is missing."""
    with patch("kimbundu_speech_ai.stt.librosa.load", side_effect=FileNotFoundError("Audio file not found")):
        with pytest.raises(FileNotFoundError):
            STT.convert_to_text("missing.wav", "checkpoint_path")


@pytest.mark.unit
def test_convert_to_text_checkpoint_not_found():
    """Test that FileNotFoundError is raised when model checkpoint is missing."""
    fake_audio = np.zeros(16000)

    with patch("kimbundu_speech_ai.stt.librosa.load",
               return_value=(fake_audio, 16000)), \
         patch("kimbundu_speech_ai.stt.load_model",
               side_effect=FileNotFoundError("Checkpoint path does not exist: missing_checkpoint")):

        with pytest.raises(FileNotFoundError):
            STT.convert_to_text("audio.wav", "missing_checkpoint")


@pytest.mark.unit
def test_convert_to_text_success():
    """Test successful transcription with Wav2Vec2 model."""
    # Setup fake audio data
    fake_audio = np.zeros(16000)
    fake_sample_rate = 16000

    # Setup fake model and processor
    fake_model = MagicMock()
    fake_processor = MagicMock()
    fake_device = "cpu"

    # Mock processor input handling
    fake_inputs = {
        "input_values": torch.randn(1, 16000),
        "attention_mask": torch.ones(1, 16000)
    }
    fake_processor.return_value = fake_inputs

    # Mock model output (CTC logits)
    fake_logits = MagicMock()
    fake_logits.logits = torch.randn(1, 100, 32)  # (batch, time, vocab)
    fake_model.return_value = fake_logits

    # Mock batch_decode to return transcription
    fake_processor.batch_decode.return_value = ["  ngana nzambi  "]

    with patch("kimbundu_speech_ai.stt.librosa.load",
               return_value=(fake_audio, fake_sample_rate)) as mock_load, \
         patch("kimbundu_speech_ai.stt.load_model",
               return_value=(fake_model, fake_processor, fake_device)) as mock_load_model:

        result = STT.convert_to_text(
            audio_path="fake.wav",
            model_path="fake_checkpoint"
        )

    # Verify result
    assert result == "ngana nzambi"
    assert isinstance(result, str)

    # Verify librosa.load was called correctly
    mock_load.assert_called_once_with("fake.wav", sr=16000)

    # Verify load_model was called correctly
    mock_load_model.assert_called_once_with("fake_checkpoint")

    # Verify model was called
    assert fake_model.called


@pytest.mark.unit
def test_convert_to_text_empty_transcription():
    """Test handling of empty transcription output."""
    fake_audio = np.zeros(16000)
    fake_model = MagicMock()
    fake_processor = MagicMock()
    fake_device = "cpu"

    fake_inputs = {
        "input_values": torch.randn(1, 16000),
        "attention_mask": torch.ones(1, 16000)
    }
    fake_processor.return_value = fake_inputs

    fake_logits = MagicMock()
    fake_logits.logits = torch.randn(1, 100, 32)
    fake_model.return_value = fake_logits

    # Return empty transcription
    fake_processor.batch_decode.return_value = ["   "]

    with patch("kimbundu_speech_ai.stt.librosa.load",
               return_value=(fake_audio, 16000)), \
         patch("kimbundu_speech_ai.stt.load_model",
               return_value=(fake_model, fake_processor, fake_device)):

        result = STT.convert_to_text("fake.wav", "fake_checkpoint")

    assert result == ""


@pytest.mark.unit
def test_load_model_with_cuda():
    """Test that model loads correctly and checks for CUDA availability."""
    with patch("kimbundu_speech_ai.stt.os.path.exists", return_value=True), \
         patch("kimbundu_speech_ai.stt.Wav2Vec2Processor.from_pretrained") as mock_processor_class, \
         patch("kimbundu_speech_ai.stt.Wav2Vec2ForCTC.from_pretrained") as mock_model_class, \
         patch("kimbundu_speech_ai.stt.torch.cuda.is_available", return_value=True):

        # Create mock instances
        fake_model = MagicMock()
        fake_processor = MagicMock()

        # Configure model methods to return self (for chaining)
        fake_model.to.return_value = fake_model
        fake_model.eval.return_value = fake_model

        # Set up the mock classes to return our mock instances
        mock_model_class.return_value = fake_model
        mock_processor_class.return_value = fake_processor

        from kimbundu_speech_ai.stt import load_model
        model, processor, device = load_model("fake_model_path")

        # Verify CUDA device was selected
        assert device == "cuda"

        # Verify model.to() was called with correct device
        fake_model.to.assert_called_once_with("cuda")

        # Verify model.eval() was called
        fake_model.eval.assert_called_once()


@pytest.mark.unit
def test_load_model_with_cpu():
    """Test that model falls back to CPU when CUDA is not available."""
    with patch("kimbundu_speech_ai.stt.os.path.exists", return_value=True), \
         patch("kimbundu_speech_ai.stt.Wav2Vec2Processor.from_pretrained") as mock_processor_class, \
         patch("kimbundu_speech_ai.stt.Wav2Vec2ForCTC.from_pretrained") as mock_model_class, \
         patch("kimbundu_speech_ai.stt.torch.cuda.is_available", return_value=False):

        # Create mock instances
        fake_model = MagicMock()
        fake_processor = MagicMock()

        # Configure model methods to return self (for chaining)
        fake_model.to.return_value = fake_model
        fake_model.eval.return_value = fake_model

        # Set up the mock classes to return our mock instances
        mock_model_class.return_value = fake_model
        mock_processor_class.return_value = fake_processor

        from kimbundu_speech_ai.stt import load_model
        model, processor, device = load_model("fake_model_path")

        # Verify CPU device was selected
        assert device == "cpu"

        # Verify model.to() was called with correct device
        fake_model.to.assert_called_once_with("cpu")

        # Verify model.eval() was called
        fake_model.eval.assert_called_once()