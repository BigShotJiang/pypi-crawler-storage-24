import os
import torch
import librosa
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor


def load_model(model_path: str):
    """Carrega o modelo e o processor"""
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Checkpoint path does not exist: {model_path}")

    processor = Wav2Vec2Processor.from_pretrained(model_path)
    model = Wav2Vec2ForCTC.from_pretrained(model_path)

    # Mover para GPU se disponível
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device)
    model.eval()

    return model, processor, device


def convert_to_text(audio_path: str, model_path: str):
    """
    Transcribe speech from an audio file into text using a Wav2Vec2-based model.

    This function loads an audio file, processes it through a fine-tuned speech
    recognition model (Wav2Vec2), and returns the corresponding text transcription.

    Parameters
    ----------
    audio_path : str
        Path to the input audio file.
    model_path : str
        Path to the fine-tuned Kimbundu Wav2Vec2 model.

    Returns
    -------
    str
        The transcribed text from the audio.
    """
    # Carregar áudio
    audio, sr = librosa.load(audio_path, sr=16000)

    # Carregar modelo
    model, processor, device = load_model(model_path)

    # Processar
    inputs = processor(audio, sampling_rate=16000, return_tensors="pt", padding=True)

    # Mover para device
    inputs = {k: v.to(device) for k, v in inputs.items()}

    # Inferência
    with torch.no_grad():
        logits = model(**inputs).logits

    # Decodificar
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = processor.batch_decode(predicted_ids)[0]

    return transcription.strip()
    

__all__ = [
    'convert_to_text'
]