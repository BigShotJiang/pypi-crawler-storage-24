"""
@RAG_CONTEXT
{
  "archivo": "src/rag_indexer/file_parser.py",
  "lineas": 55,
  "tokens_estimados": 482,
  "hash_contenido": "3d2cb17de11f5b4eb66d3d88b13de1a16a32d7f39c0ec96b8dbd8515e1256803",
  "creacion": "2026-03-04",
  "modificacion": "2026-03-19",
  "tags": [
    "json",
    "re",
    "hashlib",
    "COMMENT_SYNTAX",
    ".config"
  ],
  "descripcion_corta": "Parser: hash, extracción e inyección @RAG_CONTEXT + soporte JSON flujos",
  "descripcion_larga": "Módulo de manipulación de archivos fuente. extract_dependencies() detecta imports/require. split_metadata_and_code() separa el bloque @RAG_CONTEXT del código limpio. inject_metadata() reescribe el archivo con metadatos actualizados. Soporte adicional para JSON flujos via _rag_context: split_metadata_and_code_json() extrae el campo _rag_context y hashea el JSON sin él; inject_metadata_json() actualiza _rag_context in-place preservando el orden del resto de campos. calculate_hash() computa SHA256."
}
"""
import re
import json
import hashlib
from .config import COMMENT_SYNTAX, DATA_ONLY_EXTENSIONS


def extract_dependencies(content, ext):
    deps = set()
    if ext in ['.js', '.ts', '.jsx', '.tsx']:
        deps.update(re.findall(r'import\s+.*?\s+from\s+[\'"]([^\'"]+)[\'"]', content))
        deps.update(re.findall(r'require\([\'"]([^\'"]+)[\'"]\)', content))
    elif ext == '.py':
        deps.update(re.findall(r'import\s+([a-zA-Z0-9_]+)', content))
        deps.update(re.findall(r'from\s+([a-zA-Z0-9_\.]+)\s+import', content))
    return list(deps)


def split_metadata_and_code(content, ext):
    syntax = COMMENT_SYNTAX.get(ext)
    if not syntax:
        return None, content

    start_tag = syntax['start']
    end_tag = syntax['end']

    if content.startswith(start_tag):
        end_idx = content.find(end_tag)
        if end_idx != -1:
            try:
                raw_json = content[len(start_tag):end_idx].strip()
                metadata = json.loads(raw_json)
                clean_code = content[end_idx + len(end_tag):].lstrip()
                return metadata, clean_code
            except json.JSONDecodeError:
                pass

    return None, content


def inject_metadata(filepath, original_content, clean_code, metadata, ext):
    # Guardia de seguridad: los archivos de datos puros no admiten texto libre.
    # La descripción queda registrada solo en el índice maestro (rag-indexer.json).
    if ext in DATA_ONLY_EXTENSIONS or ext not in COMMENT_SYNTAX:
        return

    syntax = COMMENT_SYNTAX[ext]
    json_formatted = json.dumps(metadata, indent=2, ensure_ascii=False)
    new_content = f"{syntax['start']}{json_formatted}{syntax['end']}{clean_code}"
    if new_content != original_content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)


def calculate_hash(code_string):
    return hashlib.sha256(code_string.encode('utf-8')).hexdigest()


def split_metadata_and_code_json(content: str):
    """
    Para archivos JSON con campo _rag_context (flujos documentados).
    Extrae _rag_context como metadata.
    El 'código' es el JSON serializado sin ese campo, usado solo para hashing.
    Retorna (metadata_dict | None, code_str).
    """
    try:
        data = json.loads(content)
        if '_rag_context' not in data:
            return None, content
        metadata = dict(data['_rag_context'])
        code_data = {k: v for k, v in data.items() if k != '_rag_context'}
        code_str = json.dumps(code_data, ensure_ascii=False, sort_keys=True)
        return metadata, code_str
    except Exception:
        return None, content


def inject_metadata_json(filepath: str, original_content: str, metadata: dict) -> None:
    """
    Actualiza el campo _rag_context dentro de un archivo JSON flujo.
    Preserva el orden del resto de campos del JSON original.
    Solo escribe si el contenido cambia.
    """
    try:
        data = json.loads(original_content)
        data['_rag_context'] = metadata
        new_content = json.dumps(data, indent=2, ensure_ascii=False) + '\n'
        if new_content != original_content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(new_content)
    except Exception:
        pass
