import torch


def SMO(
    X: torch.Tensor,
    y: torch.Tensor,
    kernel,
    C: float,
    tol: float = 1e-3,
    max_passes: int = 5,
    is_l2: bool = False,
):
    n = X.shape[0]
    device, dtype = X.device, X.dtype

    alphas = torch.zeros(n, device=device, dtype=dtype)
    b = 0.0

    if is_l2:
        C_bound = float("inf")
        l2_shift = 1.0 / (2 * C)
    else:
        C_bound = C
        l2_shift = 0.0

    E = -y.clone().to(dtype)
    passes = 0
    eps = 1e-10

    K_diag = torch.full((n,), float("nan"), device=device, dtype=dtype)

    def get_diag(idx):
        if torch.isnan(K_diag[idx]):
            K_diag[idx] = kernel(X[idx : idx + 1], X[idx : idx + 1])[0, 0]
        return K_diag[idx].item()

    while passes < max_passes:
        num_changed = 0
        for i in range(n):
            E_i = E[i].item()
            y_i = y[i].item()
            alpha_i = alphas[i].item()
            r_i = y_i * E_i

            if (r_i < -tol and alpha_i < C_bound - eps) or (
                r_i > tol and alpha_i > eps
            ):
                j = torch.argmax(torch.abs(E - E_i)).item()
                if i == j:
                    j = (i + 1) % n

                E_j = E[j].item()
                y_j = y[j].item()
                alpha_j = alphas[j].item()

                if y_i != y_j:
                    L = max(0.0, alpha_j - alpha_i)
                    H = (
                        float("inf")
                        if is_l2
                        else min(C_bound, C_bound + alpha_j - alpha_i)
                    )
                else:
                    L = 0.0 if is_l2 else max(0.0, alpha_i + alpha_j - C_bound)
                    H = (
                        float("inf")
                        if is_l2
                        else min(C_bound, alpha_i + alpha_j)
                    )

                if L == H:
                    continue

                K_ii = get_diag(i)
                K_jj = get_diag(j)
                K_ij = kernel(X[i : i + 1], X[j : j + 1])[0, 0].item()

                eta = 2.0 * K_ij - (K_ii + l2_shift) - (K_jj + l2_shift)
                if eta >= 0:
                    continue

                new_alpha_j = alpha_j - (y_j * (E_i - E_j)) / eta
                new_alpha_j = max(L, min(H, new_alpha_j))

                if abs(new_alpha_j - alpha_j) < 1e-5:
                    continue

                new_alpha_i = alpha_i + y_i * y_j * (alpha_j - new_alpha_j)

                K_i_full = kernel(X[i : i + 1], X).squeeze(0)
                K_j_full = kernel(X[j : j + 1], X).squeeze(0)

                delta_alpha_i = new_alpha_i - alpha_i
                delta_alpha_j = new_alpha_j - alpha_j

                b1 = (
                    b
                    - E_i
                    - y_i * delta_alpha_i * (K_ii + l2_shift)
                    - y_j * delta_alpha_j * K_ij
                )
                b2 = (
                    b
                    - E_j
                    - y_i * delta_alpha_i * K_ij
                    - y_j * delta_alpha_j * (K_jj + l2_shift)
                )

                b_old = b
                if 0 < new_alpha_i < C_bound:
                    b = b1
                elif 0 < new_alpha_j < C_bound:
                    b = b2
                else:
                    b = (b1 + b2) / 2.0

                E += (
                    y_i * delta_alpha_i * K_i_full
                    + y_j * delta_alpha_j * K_j_full
                    + (b - b_old)
                )

                if is_l2:
                    E[i] += y_i * delta_alpha_i * l2_shift
                    E[j] += y_j * delta_alpha_j * l2_shift

                alphas[i] = new_alpha_i
                alphas[j] = new_alpha_j
                num_changed += 1

        if num_changed == 0:
            passes += 1
        else:
            passes = 0

    return alphas * y, b
