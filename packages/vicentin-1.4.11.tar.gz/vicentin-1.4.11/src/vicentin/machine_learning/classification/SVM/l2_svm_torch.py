from typing import Optional
from itertools import combinations

import torch

from vicentin.kernels import Kernel, LinearKernel
from vicentin.optimization.problems import QP
from vicentin.machine_learning.classification.SVM import SMO


def _train_binary(X, y, kernel, lambda_, C, smo_threshold, **kwargs):
    n = X.shape[0]
    if C is None:
        C = 1 / (lambda_ * n)

    if n > smo_threshold:
        return SMO(X, y, kernel, C, is_l2=True, **kwargs)

    P = (
        kernel[:, :].clone()
        if isinstance(kernel, torch.Tensor)
        else kernel(X, X)
    )
    P += torch.eye(n, device=X.device, dtype=X.dtype) / (2 * C)
    q = -y

    G = -torch.diag(y)
    h = torch.zeros(n, device=X.device, dtype=X.dtype)

    A = torch.ones((1, n), device=X.device, dtype=X.dtype)
    b_eq = torch.zeros(1, device=X.device, dtype=X.dtype)

    alpha, duals = QP(P, q, G, h, A, b_eq, return_dual=True, **kwargs)
    b = float(duals[1][0].item())

    return alpha, b


def L2_SVM(
    X: torch.Tensor | Kernel,
    y: torch.Tensor,
    lambda_: float = 1,
    C: Optional[float] = None,
    strategy: str = "ovo",
    smo_threshold: int = 10_000,
    **kwargs,
):
    if isinstance(X, Kernel):
        kernel = X
        X_data = torch.as_tensor(kernel.X)
    else:
        kernel = LinearKernel(X)
        X_data = X

    y = y.flatten()
    classes = torch.unique(y)

    if len(classes) == 2:
        mask = torch.ones_like(y, dtype=torch.bool)
        y_bin = torch.where(
            y == classes[0],
            torch.tensor(-1, dtype=y.dtype, device=y.device),
            torch.tensor(1, dtype=y.dtype, device=y.device),
        )

        alpha, b = _train_binary(
            X_data, y_bin, kernel, lambda_, C, smo_threshold, **kwargs
        )

        return {
            "classes": classes,
            "models": [(alpha, b, mask)],
            "strategy": "binary",
        }

    models = []
    classes_list = classes.tolist()

    if strategy == "ovo":
        for c1, c2 in combinations(classes_list, 2):
            mask = (y == c1) | (y == c2)
            y_bin = torch.where(
                y[mask] == c1,
                torch.tensor(-1, dtype=y.dtype, device=y.device),
                torch.tensor(1, dtype=y.dtype, device=y.device),
            )

            alpha, b = _train_binary(
                X_data[mask], y_bin, kernel, lambda_, C, smo_threshold, **kwargs
            )

            models.append((alpha, b, mask))

    elif strategy == "ovr":
        for c in classes_list:
            y_bin = torch.where(
                y == c,
                torch.tensor(1.0, dtype=y.dtype, device=y.device),
                torch.tensor(-1.0, dtype=y.dtype, device=y.device),
            )
            mask = torch.ones_like(y, dtype=torch.bool)

            alpha, b = _train_binary(
                X_data, y_bin, kernel, lambda_, C, smo_threshold, **kwargs
            )

            models.append((alpha, b, mask))

    return {"classes": classes, "models": models, "strategy": strategy}
