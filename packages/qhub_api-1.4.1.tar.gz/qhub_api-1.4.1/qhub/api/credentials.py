import json
import logging
import os
import platform
from abc import ABC, abstractmethod
from json import JSONDecodeError

# Primary token env vars (equal priority)
_SERVICE_EXECUTION_TOKEN_NAME = "KQH_SERVICE_EXECUTION_TOKEN"
_PERSONAL_ACCESS_TOKEN_NAME = "KQH_PERSONAL_ACCESS_TOKEN"

# Backward-compatible token env vars
_PLANQK_SERVICE_EXECUTION_TOKEN_NAME = "PLANQK_SERVICE_EXECUTION_TOKEN"
_PLANQK_SERVICE_EXECUTION_TOKEN_NAME_DEPRECATED = "SERVICE_EXECUTION_TOKEN"
_PLANQK_PERSONAL_ACCESS_TOKEN_NAME = "PLANQK_PERSONAL_ACCESS_TOKEN"

# Config file path env vars
_CONFIG_FILE_PATH = "KQH_CONFIG_FILE_PATH"
_PLANQK_CONFIG_FILE_PATH = "PLANQK_CONFIG_FILE_PATH"

logger = logging.getLogger(__name__)


class CredentialUnavailableError(Exception):
    """
    Exception raised when credentials are unavailable for authentication.
    """

    def __init__(self, message=None):
        if message is None:
            message = (
                "Credentials not found. Please set your personal access token as parameter, "
                "in the environment, or use 'qhubctl login' to authenticate."
            )
        super().__init__(message)


class CredentialProvider(ABC):
    @abstractmethod
    def get_access_token(self) -> str:
        pass


class EnvironmentCredential(CredentialProvider):
    def get_access_token(self) -> str:
        # New primary vars (equal priority, checked first)
        access_token = os.environ.get(_SERVICE_EXECUTION_TOKEN_NAME)
        if not access_token:
            access_token = os.environ.get(_PERSONAL_ACCESS_TOKEN_NAME)
        # Backward compatibility: PLANQK_SERVICE_EXECUTION_TOKEN
        if not access_token:
            access_token = os.environ.get(_PLANQK_SERVICE_EXECUTION_TOKEN_NAME)
        # Backward compatibility: SERVICE_EXECUTION_TOKEN (deprecated)
        if not access_token:
            access_token = os.environ.get(
                _PLANQK_SERVICE_EXECUTION_TOKEN_NAME_DEPRECATED
            )
        # Backward compatibility: PLANQK_PERSONAL_ACCESS_TOKEN
        if not access_token:
            access_token = os.environ.get(_PLANQK_PERSONAL_ACCESS_TOKEN_NAME)

        if not access_token:
            raise CredentialUnavailableError(
                f"None of the environment variables {_SERVICE_EXECUTION_TOKEN_NAME}, "
                f"{_PERSONAL_ACCESS_TOKEN_NAME}, {_PLANQK_SERVICE_EXECUTION_TOKEN_NAME}, "
                f"or {_PLANQK_PERSONAL_ACCESS_TOKEN_NAME} are set"
            )

        return access_token


def get_config_file_path():
    # Primary config file path env var
    config_file_path = os.environ.get(_CONFIG_FILE_PATH, None)
    # Backward compatibility: PLANQK_CONFIG_FILE_PATH
    if not config_file_path:
        config_file_path = os.environ.get(_PLANQK_CONFIG_FILE_PATH, None)
    if not config_file_path:
        if platform.system() == "Windows":
            local_app_data = os.getenv("LOCALAPPDATA") or os.path.expanduser("~")
            # Primary config dir
            config_dir = os.path.join(local_app_data, "qhubctl")
        else:
            home = os.path.expanduser("~")
            # Primary config dir
            config_dir = os.path.join(home, ".config", "qhubctl")
        config_file_path = os.path.join(config_dir, "config.json")
    return config_file_path


def _get_legacy_config_file_path():
    """Return the legacy planqk config file path for backward compatibility."""
    if platform.system() == "Windows":
        local_app_data = os.getenv("LOCALAPPDATA") or os.path.expanduser("~")
        config_dir = os.path.join(local_app_data, "planqk")
    else:
        config_dir = os.path.join(os.path.expanduser("~"), ".config", "planqk")
    return os.path.join(config_dir, "config.json")


class ConfigFileCredential(CredentialProvider):
    def __init__(self):
        self.config_file = get_config_file_path()

    def get_access_token(self) -> str:
        if not self.config_file:
            raise CredentialUnavailableError("Config file location not set")

        # Try primary config file, then fall back to legacy planqk config file
        candidates = [self.config_file]
        legacy = _get_legacy_config_file_path()
        if legacy != self.config_file:
            candidates.append(legacy)

        for path in candidates:
            if not os.path.isfile(path):
                continue
            try:
                return ConfigFileCredential.parse_file(path)
            except JSONDecodeError:
                raise CredentialUnavailableError(
                    "Failed to parse config file: Invalid JSON"
                )
            except KeyError as e:
                raise CredentialUnavailableError(
                    f"Failed to parse config file: Missing expected value - {str(e)}"
                )
            except Exception as e:
                raise CredentialUnavailableError(
                    f"Failed to parse config file: {str(e)}"
                )

        raise CredentialUnavailableError(
            f"Config file at {self.config_file} does not exist"
        )

    @staticmethod
    def parse_file(path) -> str:
        with open(path, "r") as file:
            data = json.load(file)
            return data["auth"]["value"]


class StaticCredential(CredentialProvider):
    def __init__(self, access_token=None):
        self.access_token = access_token

    def get_access_token(self) -> str:
        if not self.access_token:
            raise CredentialUnavailableError("Access token not set")
        return self.access_token


class DefaultCredentialsProvider(CredentialProvider):
    def __init__(self, access_token=None):
        self.credentials = [
            StaticCredential(access_token),
            EnvironmentCredential(),
            ConfigFileCredential(),
        ]

    def get_access_token(self) -> str:
        for credential in self.credentials:
            try:
                access_token = credential.get_access_token()
                logger.debug(
                    "%s acquired an access token from %s",
                    self.__class__.__name__,
                    credential.__class__.__name__,
                )
                return access_token
            except CredentialUnavailableError:
                logger.debug(
                    "%s - %s is unavailable",
                    self.__class__.__name__,
                    credential.__class__.__name__,
                )
            except Exception as e:
                logger.error(
                    '%s.get_access_token() failed: %s raised unexpected error "%s"',
                    self.__class__.__name__,
                    credential.__class__.__name__,
                    e,
                    exc_info=logger.isEnabledFor(logging.DEBUG),
                )

        message = f"{self.__class__.__name__} failed to retrieve an access token"
        logger.warning(message)
        raise CredentialUnavailableError(message)
