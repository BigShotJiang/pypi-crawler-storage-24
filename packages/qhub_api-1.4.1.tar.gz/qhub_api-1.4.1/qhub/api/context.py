import os
from typing import Optional, Union

from pydantic import BaseModel, Field

from qhub.api.credentials import get_config_file_path, _get_legacy_config_file_path

# Primary env var
_ORGANIZATION_ID = "KQH_ORGANIZATION_ID"

# Legacy / deprecated env vars
_PLANQK_ORGANIZATION_ID = "PLANQK_ORGANIZATION_ID"


class Context(BaseModel):
    model_config = {"populate_by_name": True, "extra": "ignore"}

    id: Optional[str] = Field(None, description="Id of the user or organization")
    display_name: Optional[str] = Field(
        None, alias="displayName", description="Name of the user or organization"
    )
    is_organization: Optional[bool] = Field(
        None,
        alias="isOrganization",
        description="True if the context is an organization",
    )
    role: Optional[str] = Field(None, description="Role of the user or organization")
    account_type: Optional[str] = Field(
        None,
        alias="accountType",
        description="Account type of the user or organization",
    )

    def get_organization_id(self) -> Union[str, None]:
        # Primary env var
        organization_id = os.environ.get(_ORGANIZATION_ID, None)
        # Deprecated: PLANQK_ORGANIZATION_ID
        if not organization_id:
            organization_id = os.environ.get(_PLANQK_ORGANIZATION_ID, None)

        if organization_id:
            return organization_id

        if self.is_organization and self.id:
            return self.id
        return None


class Config(BaseModel):
    model_config = {"extra": "ignore"}

    context: Optional[Context] = Field(
        None, description="Context of the user or organization"
    )


class ContextResolver:
    def __init__(self):
        self.config_file = get_config_file_path()

    def get_context(self) -> Union[Context, None]:
        candidates = [self.config_file]
        legacy = _get_legacy_config_file_path()
        if legacy != self.config_file:
            candidates.append(legacy)

        for path in candidates:
            if not os.path.isfile(path):
                continue
            with open(path, "r") as f:
                config = Config.model_validate_json(f.read())
            return config.context

        return None
