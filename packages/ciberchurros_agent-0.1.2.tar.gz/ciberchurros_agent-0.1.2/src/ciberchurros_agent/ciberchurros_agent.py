"""
Agente Local CiberChurros — versión Laravel
=============================================
Comunicación completamente HTTP (sin WebSocket):

  1. Autentica con el token de agente contra el servidor Laravel.
  2. Hace polling a GET /api/agent/command para recibir órdenes.
  3. Ejecuta la herramienta solicitada como subproceso.
  4. Envía cada línea de salida en tiempo real a POST /api/agent/output/{scan_id}.
  5. Marca el escaneo como finalizado con final=true en el último POST.

Servidor: https://ciberchurros.com
Generado: 2026-03-25 17:39:12

Requisitos: pip install requests
"""
import sys
import os
import subprocess
import time
import threading
import json
import argparse
import hashlib
import ipaddress
import re
import platform as py_platform
from collections import deque
from urllib.parse import urlparse

# ── Dependencias opcionales ────────────────────────────────────────────────────

def _ensure_requests():
    try:
        import requests
        return requests
    except ImportError:
        print("\n❌ Falta la librería 'requests'. Instalando...")
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'requests'])
            import importlib
            return importlib.import_module('requests')
        except Exception as e:
            print(f"❌ Error instalando 'requests': {e}")
            sys.exit(1)

requests = _ensure_requests()

# ── Configuración ─────────────────────────────────────────────────────────────

DEFAULT_BASE_URL = "https://ciberchurros.com"

def _agent_state_dir() -> str:
    """Cross-platform directory for persistent agent state."""
    if os.name == 'nt':
        base = os.environ.get('APPDATA') or os.path.expanduser('~')
        return os.path.join(base, 'CiberChurrosAgent')

    # Linux/macOS style config directory
    base = os.environ.get('XDG_CONFIG_HOME')
    if not base:
        base = os.path.join(os.path.expanduser('~'), '.config')
    return os.path.join(base, 'ciberchurros-agent')

STATE_DIR        = _agent_state_dir()
TOKEN_FILE       = os.path.join(STATE_DIR, 'agent_token')
CONFIG_FILE      = os.path.join(STATE_DIR, 'config.json')
LOCK_FILE        = os.path.join(STATE_DIR, 'agent.lock')
POLL_INTERVAL    = 2    # segundos entre polls cuando está idle
POLL_BUSY        = 0.5  # segundos entre polls cuando hay tarea activa
HEARTBEAT_INTERVAL = 10  # segundos entre heartbeats mientras se ejecuta un scan
INITIAL_BACKOFF  = 1
MAX_BACKOFF      = 30
OUTPUT_QUEUE_LIMIT   = 200
AGENT_VERSION        = "2.2"
MAX_PING_COUNT       = 20
MAX_TRACEROUTE_HOPS  = 64

# ── Heartbeat ─────────────────────────────────────────────────────────────────

def _heartbeat_loop_safe(url: str, stop_event: threading.Event, get_token, base_headers: dict):
    """Background thread: pings /api/agent/heartbeat every HEARTBEAT_INTERVAL s.

    Uses its own requests session (do not share Session across threads).
    """
    hb_session = requests.Session()
    hb_session.headers.update(base_headers or {})

    while not stop_event.wait(HEARTBEAT_INTERVAL):
        try:
            token = get_token() if get_token else None
            if token:
                hb_session.headers.update({"Authorization": f"Bearer {token}"})
            else:
                hb_session.headers.pop("Authorization", None)
            hb_session.get(url, params=_agent_health_payload(), timeout=5)
        except Exception:
            pass  # Silent — main loop will handle connectivity issues

def _agent_health_payload():
    return {
        "v": AGENT_VERSION,
        "os": py_platform.system(),
        "release": py_platform.release(),
        "python": py_platform.python_version(),
    }

# ── Persistencia del token ─────────────────────────────────────────────────────

def save_token(token: str):
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(TOKEN_FILE, "w") as f:
            f.write(token)
        # Restrict file permissions to owner-only (rw-------) to protect the token
        if os.name != 'nt':
            os.chmod(TOKEN_FILE, 0o600)
    except Exception as e:
        print(f"⚠️  No se pudo guardar el token: {e}")

def load_token():
    if os.path.exists(TOKEN_FILE):
        try:
            return open(TOKEN_FILE, encoding="utf-8").read().strip() or None
        except Exception:
            pass
    return None

def clear_token():
    try:
        if os.path.exists(TOKEN_FILE):
            os.remove(TOKEN_FILE)
    except Exception:
        pass

def save_config(base_url: str):
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump({"base_url": base_url}, f)
        if os.name != 'nt':
            os.chmod(CONFIG_FILE, 0o600)
    except Exception:
        pass

def load_config_base_url():
    if not os.path.exists(CONFIG_FILE):
        return None

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        value = data.get("base_url")
        if isinstance(value, str) and value.strip():
            return value.strip()
    except Exception:
        pass

    return None

def is_dev_server(url: str) -> bool:
    """Allow server overrides only for local/dev URLs."""
    try:
        host = (urlparse(url).hostname or "").lower()
    except Exception:
        return False

    if host in {"localhost", "127.0.0.1", "::1"}:
        return True

    return host.endswith(".test") or host.endswith(".local")

def _sha256_file(path: str):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None

def _is_pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def acquire_single_instance_lock():
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        if os.path.exists(LOCK_FILE):
            try:
                old_pid = int(open(LOCK_FILE, "r", encoding="utf-8").read().strip())
            except Exception:
                old_pid = 0

            if old_pid and _is_pid_running(old_pid):
                print(f"❌ Ya hay una instancia del agente en ejecución (PID {old_pid}).")
                return False

            try:
                os.remove(LOCK_FILE)
            except Exception:
                pass

        with open(LOCK_FILE, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))

        if os.name != 'nt':
            os.chmod(LOCK_FILE, 0o600)
        return True
    except Exception as e:
        print(f"⚠️  No se pudo crear el lock de instancia: {e}")
        return False

def release_single_instance_lock():
    try:
        if os.path.exists(LOCK_FILE):
            os.remove(LOCK_FILE)
    except Exception:
        pass

def _queue_output(pending_queue: deque, item: tuple):
    if len(pending_queue) >= OUTPUT_QUEUE_LIMIT:
        pending_queue.popleft()
        print("⚠️  Cola offline llena. Se descartó el fragmento más antiguo.")
    pending_queue.append(item)

def _post_scan_output(session, pending_queue: deque, output_url: str, payload: dict):
    """
    Tries to flush queued output first, then sends current payload.
    If network/server fails, queues payload locally in memory.
    Returns HTTP status code or None when queued due to failure.
    """
    # Flush pending chunks first (FIFO)
    while pending_queue:
        q_url, q_payload = pending_queue[0]
        try:
            q_resp = session.post(q_url, json=q_payload, timeout=10)
            # If scan was explicitly aborted remotely, drop and continue.
            if q_resp.status_code == 410:
                pending_queue.popleft()
                continue
            # If scan record is temporarily missing (e.g., server restart / DB lag),
            # keep queued data and retry later.
            if q_resp.status_code == 404:
                break
            if q_resp.status_code >= 500:
                break
            pending_queue.popleft()
        except Exception:
            break

    try:
        resp = session.post(output_url, json=payload, timeout=10)
        if resp.status_code >= 500:
            _queue_output(pending_queue, (output_url, payload))
            return None
        return resp.status_code
    except Exception:
        _queue_output(pending_queue, (output_url, payload))
        return None

def _flush_pending_output(session, pending_queue: deque):
    while pending_queue:
        q_url, q_payload = pending_queue[0]
        try:
            q_resp = session.post(q_url, json=q_payload, timeout=10)
            if q_resp.status_code == 410:
                pending_queue.popleft()
                continue
            if q_resp.status_code == 404:
                break
            if q_resp.status_code >= 500:
                break
            pending_queue.popleft()
        except Exception:
            break

# ── Construcción de comandos ───────────────────────────────────────────────────

_HOSTNAME_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)[A-Za-z0-9_-]{1,63}(?:\.(?!-)[A-Za-z0-9_-]{1,63})*$"
)


def _is_ip_or_network(value: str) -> bool:
    try:
        ipaddress.ip_network(value, strict=False)
        return True
    except Exception:
        return False


def _is_hostname(value: str) -> bool:
    return bool(_HOSTNAME_RE.match(value))


def _validate_target(target: str) -> bool:
    """Conservative validation for scan targets.

    Permite:
      - IPv4/IPv6 (con o sin CIDR), por ejemplo 192.168.1.1, 10.0.0.0/24, 2001:db8::1
      - Hostnames simples o con puntos: localhost, intranet, foo.local
      - host:puerto o ip:puerto (para IPv4/hostnames habituales)
    """
    if not isinstance(target, str):
        return False

    t = target.strip()
    if not t:
        return False

    # No espacios ni caracteres de control
    if any(ch.isspace() for ch in t):
        return False

    # IP o red pura (IPv4/IPv6, opcional CIDR)
    if _is_ip_or_network(t):
        return True

    # host:puerto o ip:puerto (principalmente IPv4/hostname)
    if ":" in t and t.count(":") == 1:
        host, port_str = t.rsplit(":", 1)
        if not host:
            return False
        if not port_str.isdigit():
            return False
        port = int(port_str)
        if not (1 <= port <= 65535):
            return False
        if _is_ip_or_network(host) or _is_hostname(host):
            return True

    # Hostname simple o con puntos
    if _is_hostname(t):
        return True

    return False

def build_command(tool: str, target: str, params: dict):
    is_win = os.name == 'nt'

    # Validación básica de target para evitar que se convierta en un vector de abuso
    if not _validate_target(target):
        return None

    if tool == "ping":
        raw_count = params.get("count", 4)
        try:
            count_int = int(raw_count)
        except (TypeError, ValueError):
            count_int = 4
        count_int = max(1, min(count_int, MAX_PING_COUNT))
        count = str(count_int)
        flag  = "-n" if is_win else "-c"
        return ["ping", flag, count, target]

    if tool == "nmap":
        detect_v   = params.get("detect_version", False)
        aggressive = params.get("aggressive_scan", False)
        os_detect  = params.get("os_detection",   False)
        vuln_s     = params.get("vuln_scan",       False)
        timing     = params.get("timing_profile",  "T4 (Agresivo)")
        mode       = params.get("mode",            "default")
        args = ["nmap"]
        args.append("-T3" if "T3" in timing else "-T5" if "T5" in timing else "-T4")
        if mode == "fast":   args.append("-F")
        elif mode == "full": args.append("-p-")
        if aggressive:
            args.append("-A")
        else:
            if detect_v:  args.append("-sV")
            if os_detect: args.append("-O")
        if vuln_s: args.extend(["--script", "vuln"])
        args.append(target)
        return args

    if tool == "traceroute":
        raw_hops = params.get("max_hops", 30)
        try:
            hops_int = int(raw_hops)
        except (TypeError, ValueError):
            hops_int = 30
        hops_int = max(1, min(hops_int, MAX_TRACEROUTE_HOPS))
        max_hops = str(hops_int)
        if is_win:
            return ["tracert", "-h", max_hops, target]
        return ["traceroute", "-m", max_hops, target]

    if tool == "dig":
        record = params.get("record_type", "A")
        all_types = ["A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA"]

        if record == "ALL":
            if is_win:
                return [["nslookup", f"-type={rt}", target] for rt in all_types]
            return [["dig", "+noauthority", "+noadditional", target, rt] for rt in all_types]

        if is_win:
            return ["nslookup", f"-type={record}", target]
        return ["dig", "+noauthority", "+noadditional", target, record]

    return None

# ── Core del agente ────────────────────────────────────────────────────────────

def run_agent(token: str, base_url: str, token_refresh_callback=None):
    """
    Main loop del agente: polling, ejecución de comandos, envío de output y gestión de reconexión/token.
    """
    session = requests.Session()
    base_headers = {
        "X-Agent-Version": AGENT_VERSION,
        "X-Agent-Platform": py_platform.platform(),
    }
    session.headers.update(base_headers)
    session.headers.update({"Authorization": f"Bearer {token}"})

    # Thread-safe token reference for heartbeat loop
    _token_lock = threading.Lock()
    _token_ref = {"token": token}

    def _get_token():
        with _token_lock:
            return _token_ref.get("token")

    def _set_token(new_token):
        with _token_lock:
            _token_ref["token"] = new_token

    command_url   = f"{base_url}/api/agent/command"
    heartbeat_url = f"{base_url}/api/agent/heartbeat"

    print(f"🔌 Conectando a {base_url} ...")
    print("⏳ Esperando comandos del servidor (Ctrl+C para salir)...\n")

    # Start the background heartbeat thread (own session; reads token safely)
    _hb_stop   = threading.Event()
    _hb_thread = threading.Thread(
        target=_heartbeat_loop_safe,
        kwargs={
            "url": heartbeat_url,
            "stop_event": _hb_stop,
            "get_token": _get_token,
            "base_headers": base_headers,
        },
        daemon=True,
    )
    _hb_thread.start()

    current_process = None
    reconnect_delay = INITIAL_BACKOFF
    pending_output = deque()
    was_offline = False

    try:
        while True:
            try:
                # Best-effort flush of queued output before polling next command.
                _flush_pending_output(session, pending_output)
                resp = session.get(command_url, timeout=10)
                if was_offline:
                    print("✅ Conexión restaurada. Esperando comandos...\n")
                    was_offline = False
                reconnect_delay = INITIAL_BACKOFF

                if resp.status_code == 401:
                    print("❌ Token inválido o revocado. Iniciando rotación de token...")
                    clear_token()
                    _set_token(None)

                    if token_refresh_callback is None:
                        return False

                    new_token = token_refresh_callback(base_url)
                    if not new_token:
                        return False

                    token = new_token
                    _set_token(token)
                    save_token(token)
                    session.headers.update({"Authorization": f"Bearer {token}"})
                    reconnect_delay = INITIAL_BACKOFF
                    was_offline = False
                    print("✅ Nuevo token cargado correctamente. Reconectando...")
                    print("⏳ Esperando comandos del servidor (Ctrl+C para salir)...\n")
                    continue

                if resp.status_code == 403:
                    data = resp.json() if resp.content else {}
                    print(f"🔒 Acceso denegado: {data.get('error', 'Permisos insuficientes.')}")
                    return False

                if resp.status_code == 204 or not resp.content:
                    time.sleep(POLL_INTERVAL)
                    continue

                if resp.status_code != 200:
                    print(f"⚠️  Respuesta inesperada del servidor: {resp.status_code}")
                    if resp.status_code >= 500:
                        print(f"   Reintentando en {reconnect_delay}s...")
                        time.sleep(reconnect_delay)
                        reconnect_delay = min(reconnect_delay * 2, MAX_BACKOFF)
                        continue
                    time.sleep(POLL_INTERVAL)
                    continue

                task = resp.json()

                try:
                    scan_id = task["scan_id"]
                    tool    = task["tool"]
                    target  = task["target"]
                except KeyError as e:
                    print(f"⚠️  Tarea malformada, falta campo: {e}")
                    time.sleep(POLL_INTERVAL)
                    continue

                # Validar scan_id: debe ser string no vacío, solo alfanumérico y guiones
                if not isinstance(scan_id, str) or not scan_id or not re.match(r"^[A-Za-z0-9\-]+$", scan_id):
                    print(f"⚠️  Tarea malformada, scan_id inválido: {scan_id!r}")
                    time.sleep(POLL_INTERVAL)
                    continue

                params = task.get("parameters", {})

                print(f"🛠️  Ejecutando '{tool}' en '{target}' (scan: {scan_id})")

                output_url = f"{base_url}/api/agent/output/{scan_id}"
                cmd        = build_command(tool, target, params)

                if not cmd:
                    _post_scan_output(session, pending_output, output_url, {"text": f"❌ Herramienta o parámetros no soportados para '{tool}'.", "final": True})
                    continue

                # Normalize: build_command may return a list of commands (list of lists)
                # for dig ALL on Windows. Convert single command to list-of-one for uniform handling.
                if isinstance(cmd[0], list):
                    commands = cmd
                else:
                    commands = [cmd]

                print(f"▶  {' '.join(commands[0])}" + (f"  (+{len(commands)-1} más)" if len(commands) > 1 else ""))
                save_token(token)
                save_config(base_url)

                aborted = False
                try:
                    for cmd_idx, single_cmd in enumerate(commands):
                        if aborted:
                            break

                        proc = subprocess.Popen(
                            single_cmd,
                            shell=False,  # ✅ Secure: no shell interpolation
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                        )
                        current_process = proc
                        import locale
                        encoding = locale.getpreferredencoding(False)

                        buffer_salida = ""
                        ultimo_envio  = time.time()

                        for raw_line in proc.stdout:
                            line           = raw_line.decode(encoding, errors='replace')
                            buffer_salida += line

                            # Flush every 1.5 s
                            if time.time() - ultimo_envio > 1.5:
                                if buffer_salida.strip():
                                    status = _post_scan_output(session, pending_output, output_url, {"text": buffer_salida, "final": False})
                                    buffer_salida = ""
                                    ultimo_envio  = time.time()
                                    if status == 410:
                                        print("🛑 Escaneo abortado remotamente. Deteniendo proceso...")
                                        proc.kill()
                                        aborted = True
                                        break

                        # Flush any remaining output from this command
                        if buffer_salida.strip() and not aborted:
                            status = _post_scan_output(session, pending_output, output_url, {"text": buffer_salida, "final": False})
                            if status == 410:
                                aborted = True

                        proc.wait()

                    if not aborted:
                        print(f"✅ Proceso finalizado")

                except Exception as exc:
                    _post_scan_output(session, pending_output, output_url, {"text": f"❌ Error al ejecutar: {exc}", "final": False})

                finally:
                    current_process = None
                    # Only send the final marker if the scan wasn't aborted (404)
                    if not aborted:
                        try:
                            status = _post_scan_output(session, pending_output, output_url, {"text": "🏁 Ejecución completada.", "final": True})
                            if status == 410:
                                print("🛑 Escaneo ya abortado; no se guarda el resultado.")
                        except Exception:
                            pass

            except KeyboardInterrupt:
                print("\n👋 Agente detenido por el usuario.")
                if current_process:
                    current_process.kill()
                return True

            except requests.exceptions.ConnectionError:
                print(f"⚠️  No se puede conectar a {base_url}. Reintentando en {reconnect_delay}s...")
                time.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, MAX_BACKOFF)
                was_offline = True

            except requests.exceptions.Timeout:
                print(f"⚠️  Timeout de red. Reintentando en {reconnect_delay}s...")
                time.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, MAX_BACKOFF)
                was_offline = True

            except Exception as exc:
                print(f"⚠️  Error inesperado: {exc}")
                time.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, MAX_BACKOFF)
                was_offline = True

    finally:
        # Always stop the heartbeat thread when run_agent exits for any reason
        _hb_stop.set()
        _hb_thread.join(timeout=2)


# ── Entry point ───────────────────────────────────────────────────────────────

def parse_cli_args():
    """Parse CLI args with backward compatibility for positional args."""
    parser = argparse.ArgumentParser(
        description="Agente local de CiberChurros (HTTP polling)."
    )
    parser.add_argument("--token", dest="token", help="Token del agente")
    parser.add_argument("--self-hash", action="store_true", help="Muestra el SHA-256 del archivo del agente y sale")
    parser.add_argument("--verify-hash", dest="verify_hash", help="Verifica el SHA-256 esperado del archivo y sale")

    # Compatibilidad con versiones previas:
    # python agente.py <token>
    parser.add_argument("token_pos", nargs="?", help=argparse.SUPPRESS)

    # Solo en DEV: permitir override de servidor
    allow_server_override = is_dev_server(DEFAULT_BASE_URL)
    if allow_server_override:
        parser.add_argument("--server", dest="server", help="URL base del servidor (solo DEV)")
        parser.add_argument("server_pos", nargs="?", help=argparse.SUPPRESS)

    args = parser.parse_args()

    token = args.token if args.token else args.token_pos
    if allow_server_override:
        server = args.server if args.server else args.server_pos
    else:
        server = None

    return token, server, args.self_hash, args.verify_hash

def _prompt_token(base_url: str):
    print(f" 👋 Para conectar este agente a tu cuenta CiberChurros,")
    print(f"    necesitas el Token de Agente del Dashboard.")
    print(f"    Obtenerlo en: {base_url}/dashboard/agents")
    print("-" * 65)
    token = input(" ✨ Pega tu TOKEN aquí y pulsa ENTER: ").strip()
    print("-" * 65)
    return token or None

def main():
    print("""
    ┌──────────────────────────────────────────────────────────┐
    │          🚀 CIBERCHURROS - AGENTE LOCAL v2.0             │
    │                  ✅ Comunicación HTTP                    │
    └──────────────────────────────────────────────────────────┘
    """)
    print(f"    Servidor: {DEFAULT_BASE_URL}\n")

    cli_token, cli_server, cli_self_hash, cli_verify_hash = parse_cli_args()

    script_path = os.path.abspath(sys.argv[0])
    current_hash = _sha256_file(script_path)

    if cli_self_hash:
        if current_hash:
            print(current_hash)
            sys.exit(0)
        print("❌ No se pudo calcular el hash del agente.")
        sys.exit(1)

    if cli_verify_hash:
        if not current_hash:
            print("❌ No se pudo calcular el hash del agente.")
            sys.exit(1)

        expected = cli_verify_hash.strip().lower()
        actual = current_hash.lower()
        if expected == actual:
            print("✅ Hash verificado correctamente.")
            sys.exit(0)
        print("❌ Hash no coincide.")
        print(f"   Esperado: {expected}")
        print(f"   Actual:   {actual}")
        sys.exit(2)

    if current_hash:
        print(f"🔐 SHA-256 agente: {current_hash}")

    if not acquire_single_instance_lock():
        sys.exit(1)

    if is_dev_server(DEFAULT_BASE_URL):
        configured_url = load_config_base_url()
        base_url = os.environ.get("CIBERCHURROS_URL", configured_url or DEFAULT_BASE_URL)
    else:
        # Producción: servidor fijo, sin overrides locales
        base_url = DEFAULT_BASE_URL

    agent_token = load_token()

    if cli_server:
        base_url = cli_server
    if cli_token:
        agent_token = cli_token

    try:
        while True:
            if not agent_token:
                agent_token = _prompt_token(base_url)
                if agent_token:
                    save_token(agent_token)
                    save_config(base_url)

            if not agent_token:
                print(" ❌ No se proporcionó ningún token.")
                sys.exit(1)

            success = run_agent(agent_token, base_url, token_refresh_callback=_prompt_token)
            if success is False:
                agent_token = None
                print("\n🔄 Intentemos de nuevo con un token válido.")
            else:
                break
    finally:
        release_single_instance_lock()

if __name__ == "__main__":
    main()
