
# CiberChurros Agent

Agente local para escaneos de red de CiberChurros SaaS.

## Instalación

1. Requiere Python 3.8 o superior.
2. Instala desde PyPI:

```bash
pip install ciberchurros-agent
```

## Uso

Ejecuta el agente desde la terminal indicando tu token:

```bash
ciberchurros --token TU_TOKEN
```

Puedes obtener tu token personal en el dashboard de CiberChurros:
https://ciberchurros.com/dashboard/agents

## Herramientas externas requeridas

El agente depende de herramientas nativas del sistema para ejecutar las auditorías. Asegúrate de tenerlas instaladas y disponibles en las variables de entorno (PATH) de tu sistema operativo:

- nmap
- ping
- traceroute (Linux/macOS) o tracert (Windows)
- dig (Linux/macOS) o nslookup (Windows)

## Actualización

Para actualizar el agente a la última versión disponible:

```bash
pip install --upgrade ciberchurros-agent
```

## Licencia

MIT

## Soporte

- Web: https://ciberchurros.com
- Email: hi@ciberchurros.com

---

**Nota de Seguridad:** El agente está diseñado para ejecutar comandos del sistema de forma segura (sin shell interpolation). Todos los escaneos se reportan de forma cifrada al servidor central.
