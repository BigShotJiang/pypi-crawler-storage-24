2026-03-24 Version: 9.1.0
- Support API DescribeSuspiciousSecurityEventyStatistics.
- Support API GetAttackEventDashboard.
- Support API GetAttackEventDetail.
- Support API GetClusterCheckSummary.
- Support API GetValidDeductInstances.
- Support API ListAttackEventInfo.
- Support API ListClusterCheckResult.
- Support API ListKspmInstances.
- Update API DescribeImageBaselineStrategy: add response parameters Body.Strategy.ImageVulClean.
- Update API DescribeSnapshots: add response parameters Body.Snapshots.$.ExpireTime.
- Update API GetSupportedModules: add response parameters Body.SupportedModuleResponse.$.SupportedModules.$.ModuleAuth.
- Update API ListPrivateRegistryList: add response parameters Body.ImageRegistryInfos.$.Port.
- Update API ModifyImageRegistry: add request parameters DomainName.
- Update API ModifyImageRegistry: add request parameters Port.
- Update API ModifyImageRegistry: add request parameters RegistryHostIp.
- Update API SaveImageBaselineStrategy: add request parameters ImageVulClean.


2026-03-24 Version: 9.1.0
- Support API DescribeSuspiciousSecurityEventyStatistics.
- Support API GetAttackEventDashboard.
- Support API GetAttackEventDetail.
- Support API GetClusterCheckSummary.
- Support API GetValidDeductInstances.
- Support API ListAttackEventInfo.
- Support API ListClusterCheckResult.
- Support API ListKspmInstances.
- Update API DescribeImageBaselineStrategy: add response parameters Body.Strategy.ImageVulClean.
- Update API DescribeSnapshots: add response parameters Body.Snapshots.$.ExpireTime.
- Update API GetSupportedModules: add response parameters Body.SupportedModuleResponse.$.SupportedModules.$.ModuleAuth.
- Update API ListPrivateRegistryList: add response parameters Body.ImageRegistryInfos.$.Port.
- Update API ModifyImageRegistry: add request parameters DomainName.
- Update API ModifyImageRegistry: add request parameters Port.
- Update API ModifyImageRegistry: add request parameters RegistryHostIp.
- Update API SaveImageBaselineStrategy: add request parameters ImageVulClean.


2026-02-27 Version: 9.0.1
- Update API DescribeSuspEvents: add request parameters DetectSource.
- Update API DescribeSuspEvents: add response parameters Body.SuspEvents.$.DetectSource.


2026-02-26 Version: 9.0.0
- Update API ModifyCreateVulWhitelist: update response parameters Body.VulWhitelistList' type has changed.
- Update API ModifyCreateVulWhitelist: delete response parameters Body.VulWhitelistList.$.


2026-02-10 Version: 8.0.1
- Update API DescribeImageSensitiveFileList: add request parameters SensitiveKeyList.
- Update API DescribePropertyScaDetail: add request parameters SearchCriteriaList.
- Update API DescribeVersionConfig: add response parameters Body.IntelligentAnalysisFlow.
- Update API DescribeVersionConfig: add response parameters Body.OnboardedAssets.
- Update API ExportVul: add request parameters VulEntityList.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.ImageDigest.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.RepoName.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.RepoNamespace.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.Tag.
- Update API GetCheckCountStatistic: add request parameters Lang.
- Update API GetCheckCountStatistic: add response parameters Body.CheckCountStatisticDTO.CheckCountStatisticItems.$.CheckShowName.
- Update API GetCheckCountStatistic: add response parameters Body.CheckCountStatisticDTO.CheckCountStatisticItems.$.VendorShowName.
- Update API ModifyPostPayModuleSwitch: add request parameters PostPayModuleSwitchObj.AiDigital.


2026-02-10 Version: 8.0.0
- Update API DescribeCloudCenterInstances: add response parameters Body.Instances.$.BindFileProtectType.
- Update API DescribeCloudVendorAccountAKList: add request parameters Vendor.
- Update API DescribeImageListByBuildRisk: add request parameters Criteria.
- Update API DescribeImageListByBuildRisk: add request parameters CriteriaType.
- Update API DescribeVersionConfig: update request parameters ResourceDirectoryAccountId' type has changed.
- Update API DescribeVersionConfig: update request parameters ResourceDirectoryAccountId' format has changed.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.Agent.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.Description.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.McpName.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.SkillsName.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.TransportName.
- Update API ListCheckItemWarningMachine: add request parameters ResourceDirectoryAccountId.
- Update API ListCheckItemWarningSummary: add request parameters ResourceDirectoryAccountId.
- Update API ModifyPostPayModuleSwitch: add request parameters PostPaidHostAutoBind.
- Update API ModifyPostPayModuleSwitch: add request parameters PostPaidHostAutoBindVersion.
- Update API ModifyPostPayModuleSwitch: add request parameters PostPayModuleSwitchObj.


2025-12-12 Version: 7.1.2
- Update API DescribePropertyCronDetail: add request parameters NextToken.
- Update API DescribePropertyCronDetail: add request parameters UseNextToken.
- Update API DescribePropertyCronDetail: add response parameters Body.PageInfo.NextToken.
- Update API DescribePropertyPortDetail: add request parameters NextToken.
- Update API DescribePropertyPortDetail: add request parameters UseNextToken.
- Update API DescribePropertyPortDetail: add response parameters Body.PageInfo.NextToken.
- Update API DescribePropertyProcDetail: add request parameters NextToken.
- Update API DescribePropertyProcDetail: add request parameters UseNextToken.
- Update API DescribePropertyProcDetail: add response parameters Body.PageInfo.NextToken.
- Update API DescribePropertyScaDetail: add request parameters NextToken.
- Update API DescribePropertyScaDetail: add request parameters UseNextToken.
- Update API DescribePropertyScaDetail: add response parameters Body.PageInfo.NextToken.
- Update API DescribePropertySoftwareDetail: add request parameters NextToken.
- Update API DescribePropertySoftwareDetail: add request parameters UseNextToken.
- Update API DescribePropertySoftwareDetail: add response parameters Body.PageInfo.NextToken.
- Update API DescribePropertyUserDetail: add request parameters NextToken.
- Update API DescribePropertyUserDetail: add request parameters UseNextToken.
- Update API DescribePropertyUserDetail: add response parameters Body.PageInfo.NextToken.
- Update API GetAssetsPropertyDetail: add request parameters NextToken.
- Update API GetAssetsPropertyDetail: add request parameters UseNextToken.
- Update API GetAssetsPropertyDetail: add response parameters Body.PageInfo.NextToken.


2025-12-09 Version: 7.1.1
- Update API DescribeSecureSuggestion: add response parameters Body.Score.
- Update API ListCloudAssetInstances: add request parameters CloudAssetQueryData.


2025-12-09 Version: 7.1.0
- Support API DescribeCloudVendorProductTemplateConfig.
- Update API DescribeEmgVulItem: add request parameters ResourceDirectoryAccountId.
- Update API ModifyEmgVulSubmit: add request parameters ResourceDirectoryAccountId.


2025-12-05 Version: 7.0.5
- Update API ListAgentlessRegion: add response parameters Body.VendorRegionList.


2025-12-03 Version: 7.0.4
- Update API DescribeExportInfo: add request parameters ResourceDirectoryAccountId.
- Update API DescribeNoticeConfig: add request parameters BizType.
- Update API DescribeNoticeConfig: add response parameters Body.NoticeConfigList.$.Category.
- Update API DescribeSecureSuggestion: add request parameters ResourceDirectoryAccountId.
- Update API ExportRecord: add request parameters ResourceDirectoryAccountId.
- Update API ModifyNoticeConfig: add request parameters BizType.
- Update API UpdateFileProtectEventStatus: add request parameters AlertLevels.
- Update API UpdateFileProtectEventStatus: add request parameters EndTime.
- Update API UpdateFileProtectEventStatus: add request parameters InstanceId.
- Update API UpdateFileProtectEventStatus: add request parameters InstanceName.
- Update API UpdateFileProtectEventStatus: add request parameters InternetIp.
- Update API UpdateFileProtectEventStatus: add request parameters IntranetIp.
- Update API UpdateFileProtectEventStatus: add request parameters Operation.
- Update API UpdateFileProtectEventStatus: add request parameters RuleName.
- Update API UpdateFileProtectEventStatus: add request parameters SelectAllAcrossPages.
- Update API UpdateFileProtectEventStatus: add request parameters StartTime.
- Update API UpdateFileProtectEventStatus: add request parameters Uuid.
- Update API UpdateFileProtectRemark: add request parameters AlertLevels.
- Update API UpdateFileProtectRemark: add request parameters EndTime.
- Update API UpdateFileProtectRemark: add request parameters IdList.
- Update API UpdateFileProtectRemark: add request parameters InstanceId.
- Update API UpdateFileProtectRemark: add request parameters InstanceName.
- Update API UpdateFileProtectRemark: add request parameters InternetIp.
- Update API UpdateFileProtectRemark: add request parameters IntranetIp.
- Update API UpdateFileProtectRemark: add request parameters Operation.
- Update API UpdateFileProtectRemark: add request parameters RuleName.
- Update API UpdateFileProtectRemark: add request parameters SelectAllAcrossPages.
- Update API UpdateFileProtectRemark: add request parameters StartTime.
- Update API UpdateFileProtectRemark: add request parameters Uuid.


2025-12-01 Version: 7.0.3
- Update API AddCheckResultWhiteList: add request parameters InstanceIds.
- Update API RemoveCheckResultWhiteList: add request parameters InstanceIds.
- Update API VerifyCheckInstanceResult: add request parameters CheckIds.
- Update API VerifyCheckResult: add request parameters InstanceIds.


2025-11-27 Version: 7.0.2
- Update API DescribeVulList: add response parameters Body.VulRecords.$.ContainerId.


2025-11-26 Version: 7.0.1
- Update API ChangeCheckConfig: add request parameters ResourceDirectoryAccountId.


2025-11-26 Version: 7.0.1
- Update API ChangeCheckConfig: add request parameters ResourceDirectoryAccountId.


2025-11-25 Version: 7.0.0
- Support API CreateCheckPolicy.
- Support API GetInstanceAuthRange.
- Support API ListCloudAssetMatchOperators.
- Support API ListCloudAssetSchemas.
- Support API ListMultiUserInstances.
- Support API UpdateCheckPolicy.
- Support API UpdateMultiUserInstances.
- Update API DescribeExposedStatisticsDetail: add request parameters ExposureIp.
- Update API DescribeExposedStatisticsDetail: add request parameters InstanceId.
- Update API DescribeVulList: update response parameters Body.VulRecords.$.GroupId' format has changed.


2025-11-13 Version: 6.1.0
- Support API CreateCheckItem.
- Support API DeleteCheckItem.
- Support API DescribeClusterScannerList.
- Support API DescribeCustomizedDict.
- Support API GenerateClusterScannerWebhookYaml.
- Support API GetAgentlessTaskUsedSizeEstimate.
- Support API GetClusterScannerYaml.
- Support API HandleSimilarMaliciousFiles.
- Support API ListCheckItems.
- Support API ListCheckPolicies.
- Support API ListUniBackupRecord.
- Support API UpdateCheckItem.
- Update API DescribeVersionConfig: add response parameters Body.CanTryPostPaidPackage.


2025-11-10 Version: 6.0.6
- Update API DescribeImageRepoList: add request parameters Selected.
- Update API DescribeImageRepoList: add response parameters Body.ImageRepoList.$.ImageCount.


2025-11-10 Version: 6.0.6
- Update API DescribeImageRepoList: add request parameters Selected.
- Update API DescribeImageRepoList: add response parameters Body.ImageRepoList.$.ImageCount.


2025-11-07 Version: 6.0.5
- Update API DescribeCloudCenterInstances: add response parameters Body.Instances.$.Namespace.


2025-11-06 Version: 6.0.4
- Update API DescribeExposedStatisticsDetail: add request parameters Criteria.
- Update API DescribeExposedStatisticsDetail: add request parameters Uuid.
- Update API DescribeExposedStatisticsDetail: add response parameters Body.StatisticsDetails.$.ForwardPort.
- Update API GetAttackPathEventDetail: add request parameters EventSource.
- Update API GetAttackPathEventDetail: add response parameters Body.AttackPathEvent.PathEventNodeList.$.AiAssetFlag.
- Update API ListCheckItemWarningMachine: add response parameters Body.List.$.AssetType.


2025-11-03 Version: 6.0.3
- Update API CreateMaliciousFileWhitelistConfig: add request parameters Remark.
- Update API GetOssBucketScanStatistic: add response parameters Body.Data.PostPayInvokeCount.
- Update API GetOssBucketScanStatistic: add response parameters Body.Data.PrePayAuthCount.
- Update API GetOssBucketScanStatistic: add response parameters Body.Data.PrePayInvokeCount.
- Update API ListMaliciousFileWhitelistConfigs: add request parameters IdList.
- Update API ListMaliciousFileWhitelistConfigs: add response parameters Body.List.$.Remark.
- Update API ListObjectScanEvent: add request parameters BatchType.
- Update API ListObjectScanEvent: add request parameters EventId.
- Update API ListObjectScanEvent: add request parameters Status.
- Update API ListObjectScanEvent: add response parameters Body.Data.$.ErrorMsg.
- Update API ListObjectScanEvent: add response parameters Body.Data.$.MatchedWhiteListRuleI18nStr.
- Update API ListObjectScanEvent: add response parameters Body.Data.$.OperateResult.
- Update API ListObjectScanEvent: add response parameters Body.Data.$.Remark.
- Update API ListObjectScanEvent: add response parameters Body.Data.$.Status.
- Update API UpdateMaliciousFileWhitelistConfig: add request parameters Remark.


2025-10-29 Version: 6.0.2
- Update API GetSwitchRegionDetail: add response parameters Body.Data.NeedNotice.
- Update API GrantSwitchAgreement: add request parameters IsConfirmed.


2025-10-29 Version: 6.0.2
- Update API GetSwitchRegionDetail: add response parameters Body.Data.NeedNotice.
- Update API GrantSwitchAgreement: add request parameters IsConfirmed.


2025-10-28 Version: 6.0.1
- Update API DescribeCheckWarningDetail: add request parameters ContainerName.


2025-10-27 Version: 6.0.0
- Update API DescribeMonitorAccounts: delete response parameters Body.AccountIdInfos.$.IsCloudSiemAccount.
- Update API DescribeMonitorAccounts: delete response parameters Body.AccountIdInfos.$.IsSasAccount.
- Update API DescribeMonitorAccounts: delete response parameters Body.AccountIdInfos.$.aliUid.
- Update API DescribeMonitorAccounts: delete response parameters Body.AccountIdInfos.$.isMarked.
- Update API DescribeVulNumStatistics: add request parameters ResourceDirectoryAccountId.
- Update API GetVulStatistics: add request parameters ResourceDirectoryAccountId.
- Update API ListCheckResult: add request parameters ResourceDirectoryAccountId.


2025-10-09 Version: 5.0.3
- Update API DescribeNsasSuspEventType: add request parameters SupportOperateCodeList.
- Update API DescribeSuspEventDetail: add response parameters Body.AlarmUniqueInfo.
- Update API DescribeSuspEvents: add request parameters SupportOperateCodeList.
- Update API DescribeSuspEvents: add response parameters Body.SuspEvents.$.SupportOperateCode.


2025-09-28 Version: 5.0.2
- Update API DescribeMonitorAccounts: add response parameters Body.AccountIdInfos.
- Update API GetAuthSummary: add response parameters Body.ClusterNodeCheck.
- Update API ListAccountsInResourceDirectory: add response parameters Body.Accounts.$.PostBasicService.


2025-09-26 Version: 5.0.1
- Update API DescribeCloudCenterInstances: add response parameters Body.Instances.$.VendorUid.
- Update API DescribeCloudCenterInstances: add response parameters Body.Instances.$.VendorUserName.
- Update API DescribeCloudVendorAccountAKList: add response parameters Body.CloudVendorAccountAKs.$.VendorUid.
- Update API DescribeCloudVendorAccountAKList: add response parameters Body.CloudVendorAccountAKs.$.VendorUserName.
- Update API GetCloudAssetDetail: add response parameters Body.Instances.$.OriginalAssetInfo.
- Update API GetCloudAssetDetail: add response parameters Body.Instances.$.VendorUid.
- Update API GetCloudAssetDetail: add response parameters Body.Instances.$.VendorUserName.
- Update API ListCheckInstanceResult: add response parameters Body.BasicData.$.VendorUserName.
- Update API ListCloudAssetInstances: add response parameters Body.Instances.$.VendorUid.
- Update API ListCloudAssetInstances: add response parameters Body.Instances.$.VendorUserName.


2025-09-19 Version: 5.0.0
- Support API CreateAttackPathSensitiveAssetConfig.
- Support API CreateAttackPathWhitelist.
- Support API DeleteAttackPathSensitiveAssetConfig.
- Support API DeleteAttackPathWhitelist.
- Support API DeleteCheckPolicy.
- Support API DescribeAIAssetSummary.
- Support API DescribePluginSummary.
- Support API GetAttackPathEventDetail.
- Support API GetAttackPathEventStatistics.
- Support API GetAttackPathSensitiveAssetConfig.
- Support API GetAttackPathWhitelist.
- Support API InstallAegisForLingjun.
- Support API ListAegisForLingjunStatus.
- Support API ListAttackPathEvent.
- Support API ListAttackPathWhitelist.
- Support API ListAvailableAttackPath.
- Support API ListSupportAttackPathAsset.
- Support API UpdateAttackPathSensitiveAssetConfig.
- Support API UpdateAttackPathWhitelist.
- Delete API CheckQuaraFileId.
- Delete API DescribePropertyUsageNewest.
- Delete API ListQueryRaspAppInfo.
- Delete API QueryAssetDetailByUUID.
- Delete API QueryIncidentIconList.
- Delete API QueryIncidentSubNodesCount.
- Delete API QueryIncidentTracingDetail.
- Delete API QueryIncidentTracingJudge.
- Delete API QueryIncidentVertexExtendInfo.
- Delete API QueryIncidentVertexNodes.
- Update API AddCloudVendorAccountAK: add request parameters CtdrCloudUserId.
- Update API AddCloudVendorAccountAK: add request parameters ExtendInfo.
- Update API AddCloudVendorAccountAK: add response parameters Body.Data.CtdrCloudUserId.
- Update API ChangeSecurityScoreRule: add request parameters CalType.
- Update API ChangeSecurityScoreRule: add request parameters SecurityScoreCategoryList.
- Update API CreateCustomizedDict: add request parameters Override.
- Update API CreateOssScanConfig: add request parameters RealTimeIncr.
- Update API CreateVirusScanOnceTask: add request parameters Param.
- Update API DescribeClientProblemType: add request parameters Lang.
- Update API DescribeClientProblemType: add request The number of query or body parameters has changed from zero to many.
- Update API DescribeCloudCenterInstances: add response parameters Body.Instances.$.HasContainer.
- Update API DescribeCloudCenterInstances: add response parameters Body.Instances.$.ServiceId.
- Update API DescribeCloudVendorAccountAKList: add response parameters Body.CloudVendorAccountAKs.$.CtdrCloudUserId.
- Update API DescribeCloudVendorAccountAKList: add response parameters Body.CloudVendorAccountAKs.$.ExtendInfo.
- Update API DescribeCustomizeReportConfigDetail: add response parameters Body.MemberAccountSyncFlag.
- Update API DescribeEmgVulItem: add response parameters Body.GroupedVulItems.$.Description.
- Update API DescribeExposedInstanceList: add request parameters ExposureComponentBizType.
- Update API DescribeExposedInstanceList: add response parameters Body.ExposedInstances.$.ExposureComponentList.
- Update API DescribeFieldStatistics: add response parameters Body.GroupedFields.GoogleInstanceCount.
- Update API DescribeFieldStatistics: add response parameters Body.GroupedFields.VolcengineInstanceCount.
- Update API DescribeGroupedVul: add request parameters ClusterId.
- Update API DescribeGroupedVul: add request parameters ContainerFieldValue.
- Update API DescribeGroupedVul: add request parameters CveId.
- Update API DescribeGroupedVul: add request parameters RaspDefend.
- Update API DescribeImageGroupedVulList: add request parameters RuleTag.
- Update API DescribeImageGroupedVulList: add response parameters Body.GroupedVulItems.$.RuleTag.
- Update API DescribeImageInfoList: add response parameters Body.ImageInfos.$.SourceBizTag.
- Update API DescribeImageInstances: add response parameters Body.ImageInstanceList.$.SourceBizTag.
- Update API DescribeImageRepoDetailList: add response parameters Body.ImageRepoResponses.$.SourceBizTag.
- Update API DescribeImageVulList: add request parameters RuleTag.
- Update API DescribeImageVulList: add response parameters Body.VulRecords.$.RuleTag.
- Update API DescribeInstanceStatistics: add response parameters Body.Data.$.CspmHighRiskNum.
- Update API DescribeInstanceStatistics: add response parameters Body.Data.$.RemindSuspiciousNum.
- Update API DescribeInstanceStatistics: add response parameters Body.Data.$.SeriousSuspiciousNum.
- Update API DescribeInstanceStatistics: add response parameters Body.Data.$.SuspectSuspiciousNum.
- Update API DescribeInstanceStatistics: add response parameters Body.Data.$.SysAsapVulCount.
- Update API DescribePropertyCount: add response parameters Body.AgentlessLlmService.
- Update API DescribePropertyCount: add response parameters Body.AgentlessScaAiComponent.
- Update API DescribePropertyProcDetail: add response parameters Body.Propertys.$.FileHash.
- Update API DescribePropertyScaProcessDetail: add response parameters Body.Propertys.$.Version.
- Update API DescribeScreenScoreThread: add request parameters Source.
- Update API DescribeSecureSuggestion: add request parameters CalType.
- Update API DescribeSecureSuggestion: add request parameters Source.
- Update API DescribeSecureSuggestion: add response parameters Body.CalTime.
- Update API DescribeStrategy: add response parameters Body.Strategies.$.ExecutionType.
- Update API DescribeVersionConfig: add response parameters Body.AntiRansomwareCapacity.
- Update API DescribeVersionConfig: add response parameters Body.InstanceBuyType.
- Update API DescribeVersionConfig: add response parameters Body.MultiVersion.
- Update API DescribeVulList: add request parameters ClusterId.
- Update API DescribeVulList: add request parameters RaspDefend.
- Update API DescribeVulList: add request parameters TargetType.
- Update API DescribeVulList: add response parameters Body.VulRecords.$.Image.
- Update API DescribeVulList: add response parameters Body.VulRecords.$.Namespace.
- Update API DescribeVulList: add response parameters Body.VulRecords.$.RuleTag.
- Update API DescribeWarningMachines: add response parameters Body.WarningMachines.$.AssetType.
- Update API DescribeWarningMachines: add response parameters Body.WarningMachines.$.Online.
- Update API ExecStrategy: add request parameters ExecAction.
- Update API ExportVul: add request parameters RaspDefend.
- Update API GenerateK8sAccessInfo: add request parameters CpuArch.
- Update API GenerateK8sAccessInfo: add response parameters Body.Data.CpuArch.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.EndPoint.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.File.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.InstallationPath.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.MiddlewareName.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.MiddlewareVersion.
- Update API GetAssetsPropertyDetail: add response parameters Body.Propertys.$.ModelName.
- Update API GetAssetsPropertyItem: add response parameters Body.PropertyItems.$.MiddlewareName.
- Update API GetAssetsPropertyItem: add response parameters Body.PropertyItems.$.ModelName.
- Update API GetAuthSummary: add response parameters Body.InvalidBindStatus.
- Update API GetCheckCountStatistic: add request parameters TaskSources.
- Update API GetCheckCountStatistic: add response parameters Body.CheckCountStatisticDTO.CheckCountStatisticItems.$.Cores.
- Update API GetCheckCountStatistic: add response parameters Body.CheckCountStatisticDTO.CheckCountStatisticItems.$.InternetIp.
- Update API GetCheckCountStatistic: add response parameters Body.CheckCountStatisticDTO.CheckCountStatisticItems.$.IntranetIp.
- Update API GetCheckCountStatistic: add response parameters Body.CheckCountStatisticDTO.CheckCountStatisticItems.$.Os.
- Update API GetCheckCountStatistic: add response parameters Body.CheckCountStatisticDTO.CheckCountStatisticItems.$.Uuid.
- Update API GetCheckCountStatistic: add response parameters Body.CheckCountStatisticDTO.CheckCountStatisticItems.$.VpcInstanceId.
- Update API GetCheckStructure: add request parameters TaskSources.
- Update API GetCheckSummary: add request parameters TaskSources.
- Update API GetCloudAssetSummary: add request parameters CloudAssetTypes.
- Update API GetContainerDefenseRuleDetail: add request parameters Lang.
- Update API GetDefenceCount: add response parameters Body.SuspiciousDealtCount.
- Update API GetFileDetectApiInvokeInfo: add response parameters Body.Data.AuthCountInSaleVersion.
- Update API GetFileDetectApiInvokeInfo: add response parameters Body.Data.InvokeCount.
- Update API GetFileDetectApiInvokeInfo: add response parameters Body.Data.InvokeCountInSaleVersion.
- Update API GetFileProtectEvent: add response parameters Body.Data.UserId.
- Update API GetFileProtectEvent: add response parameters Body.Data.UserName.
- Update API GetOssScanConfig: add response parameters Body.Data.RealTimeIncr.
- Update API GetSecurityScoreRule: add request parameters CalType.
- Update API GetSecurityScoreRule: add response parameters Body.SecurityScoreCategoryList.
- Update API GetSwitchRegionDetail: add response parameters Body.Data.NeedSwitch.
- Update API GetVirusScanConfig: add response parameters Body.Data.AdditionType.
- Update API GrantSwitchAgreement: add request parameters IsImmediate.
- Update API IgnoreCheckItems: add request parameters ContainerItems.
- Update API ListAccountsInResourceDirectory: add response parameters Body.Accounts.$.BuySas.
- Update API ListAccountsInResourceDirectory: add response parameters Body.Accounts.$.BuySasNew.
- Update API ListAccountsInResourceDirectory: add response parameters Body.Accounts.$.ChargeType.
- Update API ListAccountsInResourceDirectory: add response parameters Body.Accounts.$.InstanceBuyType.
- Update API ListAccountsInResourceDirectory: add response parameters Body.Accounts.$.PostPayModuleSwitch.
- Update API ListAccountsInResourceDirectory: add response parameters Body.Accounts.$.SaleInstance.
- Update API ListBaselineCheckWhiteRecord: add response parameters Body.List.$.ContainerItems.
- Update API ListCheckItem: add request parameters TaskSources.
- Update API ListCheckItem: add response parameters Body.CheckItems.$.CheckType.
- Update API ListCheckResult: add request parameters CheckTypes.
- Update API ListCheckResult: add request parameters TaskSources.
- Update API ListCheckResult: add response parameters Body.Checks.$.CheckType.
- Update API ListCheckRule: add request parameters TaskSources.
- Update API ListCheckStandard: add request parameters TaskSources.
- Update API ListCloudAssetInstances: add response parameters Body.Instances.$.Tags.
- Update API ListImageRegistryRegion: add request parameters Lang.
- Update API ListImageRegistryRegion: add request The number of query or body parameters has changed from zero to many.
- Update API ListInstanceCatalog: add request parameters OnlyCustom.
- Update API ListInstanceCatalog: add request parameters TaskSources.
- Update API ListInstanceCatalog: add response parameters Body.Vendors.$.Value.
- Update API ListInstanceCatalog: add response parameters Body.Vendors.$.InstanceTypes.$.Value.
- Update API ListInstanceCatalog: add response parameters Body.Vendors.$.InstanceTypes.$.InstanceSubTypes.$.Value.
- Update API ListK8sAccessInfo: add response parameters Body.K8sAccessInfos.$.CpuArch.
- Update API ListOperationProcess: add request parameters TaskSources.
- Update API ListOperationProcess: add response parameters Body.Processes.$.DetailTaskReadyCount.
- Update API ListOperationProcess: add response parameters Body.Processes.$.DetailTaskTotalCount.
- Update API ListOperationProcess: add response parameters Body.Processes.$.TaskSource.
- Update API ListOssScanConfig: add response parameters Body.Data.$.RealTimeIncr.
- Update API ModifyCloudVendorAccountAK: add request parameters CtdrCloudUserId.
- Update API ModifyCloudVendorAccountAK: add request parameters ExtendInfo.
- Update API ModifyCloudVendorAccountAK: add response parameters Body.Data.CtdrCloudUserId.
- Update API SaveCustomizeReportConfig: add request parameters MemberAccountSyncFlag.
- Update API SubmitCheck: add request parameters TaskSource.
- Update API UpdateBaselineCheckWhiteRecord: add request parameters RemoveContainerUuids.
- Update API UpdateOssScanConfig: add request parameters RealTimeIncr.
- Update API UpdatePostPaidBindRel: add request parameters UpdateIfNecessary.
- Update API VerifyCheckCustomConfig: add request parameters CustomCheckConfig.
- Update API VerifyCheckCustomConfig: add request parameters Type.
- Update API VerifyCheckCustomConfig: add response parameters Body.ErrorCheckCustomConfig.
- Update API VerifyCheckInstanceResult: add request parameters TaskSource.
- Update API VerifyCheckResult: add request parameters TaskSource.


2025-03-21 Version: 4.5.3
- Update API CreateCycleTask: update response param.
- Update API DescribeCycleTaskList: add param ConfigId.
- Update API DescribeCycleTaskList: update param TaskType.
- Update API DescribeCycleTaskList: update response param.


2025-03-21 Version: 4.5.3
- Update API CreateCycleTask: update response param.
- Update API DescribeCycleTaskList: add param ConfigId.
- Update API DescribeCycleTaskList: update param TaskType.
- Update API DescribeCycleTaskList: update response param.


2025-03-14 Version: 4.5.2
- Update API CreateAntiBruteForceRule: add param ProtocolType.
- Update API DescribeAntiBruteForceRules: update response param.
- Update API ListCheckItemWarningMachine: update response param.
- Update API ModifyAntiBruteForceRule: add param ProtocolType.


2025-03-12 Version: 4.5.1
- Update API DescribeCustomizedDictUploadInfo: update response param.
- Update API GetHoneyPotUploadPolicyInfo: update response param.


2025-01-14 Version: 4.0.3
- Update API DescribeVulList: update response param.


2025-01-13 Version: 4.0.2
- Update API DescribeVulList: update response param.


2025-01-10 Version: 4.0.1
- Update API DescribeAssetsScaProcessNum: add param BizType.
- Update API DescribePropertyScaProcessDetail: add param BizType.
- Update API DescribePropertyScaProcessDetail: add param Cmdline.


2025-01-07 Version: 4.0.0
- Support API GetBuildRiskDefineRuleConfig.
- Support API GetTenantCheckAvailable.
- Support API ListOperationProcess.
- Support API ListOperationProcessDetail.
- Support API SetBuildRiskDefineRuleConfig.
- Support API SubmitTenantCheck.
- Delete API DescribeAttachRecords.
- Delete API DescribeImageScanAuthorization.
- Delete API DescribeUserLayoutAuthorization.
- Delete API GetClientInstallationStatistic.
- Delete API InstallRaspAttach.
- Delete API UninstallRaspAttach.
- Update API AddCloudVendorAccountAK: add param Lang.
- Update API AddImageEventOperation: add param Note.
- Update API AddImageEventOperation: add param Source.
- Update API AddInstallCode: add param PrivateLinkId.
- Update API CreateAssetSelectionConfig: add param Platform.
- Update API CreateAssetSelectionConfig: update response param.
- Update API CreateOrUpdateAssetGroup: update param GroupName.
- Update API DescribeAgentlessSensitiveFileByKey: update response param.
- Update API DescribeAssetDetailByUuids: update response param.
- Update API DescribeCloudCenterInstances: update response param.
- Update API DescribeExposedInstanceDetail: add param Lang.
- Update API DescribeExposedInstanceDetail: update response param.
- Update API DescribeExposedInstanceList: add param AssetType.
- Update API DescribeExposedInstanceList: add param CspmStatus.
- Update API DescribeExposedInstanceList: update response param.
- Update API DescribeExposedStatistics: update response param.
- Update API DescribeImageEventOperationPage: add param Source.
- Update API DescribeImageEventOperationPage: update response param.
- Update API DescribeImageRepoDetailList: update response param.
- Update API DescribeImageSensitiveFileList: update response param.
- Update API DescribeInstallCodes: update response param.
- Update API DescribeMonitorAccounts: update response param.
- Update API DescribeOnceTask: add param Source.
- Update API DescribeOnceTask: update response param.
- Update API DescribeStrategy: update response param.
- Update API DescribeStrategyExecDetail: update response param.
- Update API DescribeStrategyTarget: update response param.
- Update API DescribeSuspiciousOverallConfig: update response param.
- Update API FixCheckWarnings: add param RetentionDays.
- Update API FixCheckWarnings: add param SnapshotName.
- Update API GetAssetDetailByUuid: update response param.
- Update API GetAssetSelectionConfig: update response param.
- Update API GetCheckRiskStatistics: update response param.
- Update API GetOssBucketScanStatistic: add param Source.
- Update API GetSensitiveDefineRuleConfig: add param Source.
- Update API GetSensitiveDefineRuleConfig: update response param.
- Update API GetSuspiciousStatistics: update response param.
- Update API ListAgentlessRelateMalicious: add param Lang.
- Update API ListAgentlessRelateMalicious: add param Scenario.
- Update API ListAgentlessRelateMalicious: update response param.
- Update API ListCheckItemWarningSummary: add param CheckWarningStatusList.
- Update API ListCheckItemWarningSummary: add param StartTime.
- Update API ListCheckResult: add param OperationTypes.
- Update API ListCheckResult: update response param.
- Update API ListCheckStandard: update response param.
- Update API ListQueryRaspAppInfo: update param Uuids.
- Update API ListSystemClientRules: update response param.
- Update API ModifyCloudVendorAccountAK: add param Lang.
- Update API ModifyUniBackupPolicy: update param AccountPassword.
- Update API SetImageSensitiveFileStatus: add param IdList.
- Update API SetImageSensitiveFileStatus: add param ScanRange.
- Update API SetSensitiveDefineRuleConfig: add param EnableNewRule.
- Update API SetSensitiveDefineRuleConfig: add param Source.
- Update API SubmitCheck: update response param.
- Update API SubmitOperationTask: add param RelationKey.
- Update API SubmitOperationTask: update param DimensionType.
- Update API UpdateImageEventOperation: add param Conditions.
- Update API UpdateImageEventOperation: add param Note.
- Update API UpdateImageEventOperation: add param Source.
- Update API VerifyCheckInstanceResult: update response param.
- Update API VerifyCheckResult: update response param.


2024-10-10 Version: 3.2.0
- Support API GetBuildRiskDefineRuleConfig.
- Support API SetBuildRiskDefineRuleConfig.
- Update API DescribeExposedInstanceDetail: update response param.
- Update API DescribeExposedInstanceList: add param AssetType.
- Update API DescribeExposedInstanceList: add param CspmStatus.
- Update API DescribeExposedInstanceList: update response param.
- Update API DescribeExposedStatistics: update response param.
- Update API DescribeOnceTask: add param Source.
- Update API DescribeOnceTask: update response param.
- Update API ListCheckResult: add param OperationTypes.
- Update API ListCheckResult: update response param.
- Update API ListSystemClientRules: update response param.
- Update API SubmitCheck: update response param.
- Update API SubmitOperationTask: add param RelationKey.
- Update API SubmitOperationTask: update param DimensionType.
- Update API VerifyCheckResult: update response param.


2024-09-24 Version: 3.1.0
- Support API AddPublishBatch.
- Support API BatchCreateMaliciousNote.
- Support API DescribeHybridProxyClusterList.
- Support API DescribeHybridProxyLinkedClientList.
- Support API DescribeHybridProxyList.
- Support API DescribeHybridProxyPolicy.
- Support API GetCurrentVersionPublish.
- Support API ListAssetInfoPublish.
- Support API ListPrivateK8s.
- Support API ListPublishBatch.
- Support API ModifyAttestor.
- Support API SetImageBuildRiskStatus.
- Support API UnBindHybridProxy.
- Update API DescribeSecurityEventOperations: update response param.
- Update API DescribeSuspiciousUUIDConfig: update response param.
- Update API DescribeWebLockBindList: add param Uuid.
- Update API DescribeWebLockBindList: update response param.
- Update API DescribeWebLockConfigList: add param Id.
- Update API DescribeWebLockConfigList: update response param.
- Update API ModifyWebLockCreateConfig: update response param.


2024-09-10 Version: 3.0.0
- Support API AddBaselineCheckWhiteRecord.
- Support API AddCloudVendorAccountAK.
- Support API AddIdcProbe.
- Support API CheckStsTokenAuth.
- Support API CheckTrialFixCount.
- Support API CopyCustomizeReportConfig.
- Support API CreateAttestor.
- Support API CreateBinarySecurityPolicy.
- Support API CreateCustomizedDict.
- Support API CreateDynamicDict.
- Support API CreateJenkinsImageScanTask.
- Support API CreateMonitorAccount.
- Support API CreateOrUpdateAutoTagRule.
- Support API CreateRdDefaultSyncList.
- Support API CreateSasTrial.
- Support API CreateSoarStrategyTask.
- Support API CreateUserSetting.
- Support API DeleteAttestor.
- Support API DeleteAutoTagRules.
- Support API DeleteBackupSnapshot.
- Support API DeleteBaselineCheckWhiteRecord.
- Support API DeleteCloudVendorAccountAK.
- Support API DeleteCustomizeReport.
- Support API DeleteCustomizedDict.
- Support API DeleteDingTalk.
- Support API DeleteHybridProxy.
- Support API DeleteHybridProxyCluster.
- Support API DeleteIdcProbe.
- Support API DeleteMonitorAccount.
- Support API DeleteSearchCondition.
- Support API DeleteSoarStrategyTask.
- Support API DescribeAgentlessSensitiveFileByKey.
- Support API DescribeAllRegionsStatistics.
- Support API DescribeAssetsScaProcessNum.
- Support API DescribeAttestors.
- Support API DescribeBinarySecurityPolicies.
- Support API DescribeCanTrySas.
- Support API DescribeChartData.
- Support API DescribeChartList.
- Support API DescribeCheckResult.
- Support API DescribeCheckWarningCount.
- Support API DescribeClientProblemType.
- Support API DescribeCloudVendorAccountAKList.
- Support API DescribeClusterHostSecuritySummary.
- Support API DescribeClusterImageSecuritySummary.
- Support API DescribeContainerFieldStatistics.
- Support API DescribeContainerGroupedFieldDetail.
- Support API DescribeContainerServiceK8sClusterKritisStatus.
- Support API DescribeContainerServiceK8sClusterNamespaces.
- Support API DescribeContainerServiceK8sClusters.
- Support API DescribeCustomizeReportConfigDetail.
- Support API DescribeCustomizeReportList.
- Support API DescribeCustomizedDictUploadInfo.
- Support API DescribeCustomizedStrategyTargets.
- Support API DescribeDataSource.
- Support API DescribeDefaultKeyInfo.
- Support API DescribeDomainSecureAlarmList.
- Support API DescribeDomainSecureRiskList.
- Support API DescribeDomainSecureScore.
- Support API DescribeDomainSecureStatistics.
- Support API DescribeDomainSecureVulList.
- Support API DescribeDynamicDict.
- Support API DescribeDynamicDictUploadInfo.
- Support API DescribeIdcAssetCriteria.
- Support API DescribeIdcProbeScanResultList.
- Support API DescribeImageBuildRiskByKey.
- Support API DescribeImageBuildRiskList.
- Support API DescribeImageListByBuildRisk.
- Support API DescribeInstanceVulStatistics.
- Support API DescribeNeedAsyncQuery.
- Support API DescribePropertyScaProcessDetail.
- Support API DescribePropertyUsageTop.
- Support API DescribeReportExport.
- Support API DescribeReportRecipientStatus.
- Support API DescribeScreenScoreThread.
- Support API DescribeSoarStrategies.
- Support API DescribeSoarStrategyParam.
- Support API DescribeSoarStrategyTaskDetail.
- Support API DescribeSoarStrategyTasks.
- Support API DescribeSoarSubscribedStrategy.
- Support API DescribeSupervisonInfo.
- Support API DescribeSyncAssetTaskList.
- Support API DescribeSyncAssetTaskLogDetail.
- Support API DescribeUniBackupStatistics.
- Support API DescribeUserSetting.
- Support API DescribeVolDingdingMessage.
- Support API DescribeWhiteListAsset.
- Support API DescribeWhiteListAuthorize.
- Support API DescribeWhiteListEffectiveAssets.
- Support API DescribeWhiteListProcess.
- Support API DescribeWhiteListStrategyList.
- Support API DescribeWhiteListStrategyStatistics.
- Support API DescribeWhiteListStrategyUuidCount.
- Support API DingTalkOnlineTest.
- Support API EnableServiceAccessResourceDirectory.
- Support API ExportCustomizeReport.
- Support API FinishGuidTask.
- Support API GenerateDynamicDict.
- Support API GetAccountLabel.
- Support API GetAegisContainerPluginRule.
- Support API GetAttackTypeList.
- Support API GetAuthSummary.
- Support API GetBackupAutoConfigStatus.
- Support API GetCanTrySas.
- Support API GetCheckStructure.
- Support API GetDataTrend.
- Support API GetDefenceCount.
- Support API GetLocalDefaultRegion.
- Support API GetModuleConfigStatus.
- Support API GetRdTree.
- Support API GetSupportedModules.
- Support API IgnoreIdcProbeScanResult.
- Support API ListAccountsInResourceDirectory.
- Support API ListAutoTagRules.
- Support API ListBaselineCheckWhiteRecord.
- Support API ListLogShipperRegions.
- Support API ListRdDefaultSyncList.
- Support API ModifyCloudVendorAccountAK.
- Support API ModifyDingTalkStatus.
- Support API ModifyIdcProbe.
- Support API ModifyPostPayModuleSwitch.
- Support API ModifyProcessWhiteList.
- Support API ModifySearchCondition.
- Support API ModifySoarStrategySubscribe.
- Support API ModifyWebLockRefresh.
- Support API OpenBackupAutoConfig.
- Support API OperationCustomizeReportChart.
- Support API QueryAssetDetailByUUID.
- Support API QueryGuidTaskList.
- Support API ReceiveFunctionTrialRewardByAliUid.
- Support API RefreshRegistryToken.
- Support API ResetLogShipper.
- Support API SaveCustomizeReportConfig.
- Support API SaveWhiteListStrategy.
- Support API SaveWhiteListStrategyAssets.
- Support API SendCustomizeReport.
- Support API SetSyncRefreshRegion.
- Support API StartIdcProbeScan.
- Support API SubmitOperationTask.
- Support API TriggerCheck.
- Support API UpdateBaselineCheckWhiteRecord.
- Support API UpdateCustomizeReportStatus.
- Support API UpdatePublishAutoUpgrade.
- Support API UpdatePublishBatch.
- Support API UpdatePublishCron.
- Support API UpdatePublishGraySwitch.
- Support API UpdateTargetListByBatch.
- Support API UpdateWhiteListStrategyStatus.
- Support API UpgradeHoneypotNode.
- Support API UpgradeVersionByUuids.
- Delete API DescribeIpTags.
- Delete API ModifyRiskCheckStatus.
- Delete API ModifyRiskSingleResultStatus.
- Update API AddCheckInstanceResultWhiteList: add param InstanceList.
- Update API AddCheckInstanceResultWhiteList: add param Remark.
- Update API AddCheckInstanceResultWhiteList: add param RuleType.
- Update API AddCheckInstanceResultWhiteList: update response param.
- Update API AddCheckResultWhiteList: add param Remark.
- Update API AddCheckResultWhiteList: add param RuleType.
- Update API AddCheckResultWhiteList: update param CheckIds.
- Update API AddCheckResultWhiteList: update response param.
- Update API ChangeCheckConfig: add param SystemConfig.
- Update API CreateAgentlessScanTask: add param AssetSelectionType.
- Update API CreateAgentlessScanTask: update param TargetType.
- Update API CreateAgentlessScanTask: update param UuidList.
- Update API CreateFileProtectRule: add param Platform.
- Update API CreateHybridProxyCluster: update param Ip.
- Update API CreateHybridProxyCluster: update response param.
- Update API CreateOssBucketScanTask: add param DecryptionList.
- Update API CreateOssBucketScanTask: add param LastModifiedStartTime.
- Update API CreateOssScanConfig: add param DecryptionList.
- Update API CreateOssScanConfig: add param LastModifiedStartTime.
- Update API DescribeCheckWarningMachines: add param CurrentPage.
- Update API DescribeCheckWarningMachines: add param FilterUuid.
- Update API DescribeCheckWarningMachines: add param InstanceId.
- Update API DescribeCheckWarningMachines: add param PageSize.
- Update API DescribeCheckWarningMachines: add param Remark.
- Update API DescribeCheckWarningMachines: update response param.
- Update API DescribeCloudCenterInstances: add param Flags.
- Update API DescribeCloudCenterInstances: update response param.
- Update API DescribeEventLevelCount: add param MultiAccountActionType.
- Update API DescribeEventLevelCount: update response param.
- Update API DescribeFieldStatistics: update response param.
- Update API DescribeImageInstances: update response param.
- Update API DescribeLogShipperStatus: update response param.
- Update API DescribeNsasSuspEventType: add param MultiAccountActionType.
- Update API DescribeNsasSuspEventType: update response param.
- Update API DescribeSuspEvents: add param MultiAccountActionType.
- Update API DescribeSuspEvents: add param SourceAliUids.
- Update API DescribeSuspEvents: update response param.
- Update API DescribeVulList: update response param.
- Update API FixCheckWarnings: update param Uuids.
- Update API FixCheckWarnings: update response param.
- Update API GetAgentlessTaskCount: add param Target.
- Update API GetAgentlessTaskCount: add param TargetType.
- Update API GetAgentlessTaskCount: update response param.
- Update API GetCheckProcess: update response param.
- Update API GetFileProtectEvent: update response param.
- Update API GetFileProtectRule: update response param.
- Update API GetOssScanConfig: update response param.
- Update API GetSwitchRegionDetail: add param Type.
- Update API ListAegisContainerPluginRule: update response param.
- Update API ListAgentlessMaliciousFiles: add param ScanRange.
- Update API ListAgentlessRiskUuid: add param InstanceId.
- Update API ListAgentlessRiskUuid: add param InstanceName.
- Update API ListAgentlessRiskUuid: add param TargetType.
- Update API ListAgentlessRiskUuid: update response param.
- Update API ListAgentlessTask: update response param.
- Update API ListCheckResult: add param CheckIds.
- Update API ListCheckResult: update response param.
- Update API ListCheckStandard: update response param.
- Update API ListFileProtectEvent: update response param.
- Update API ListFileProtectPluginStatus: update response param.
- Update API ListFileProtectRule: add param Platform.
- Update API ListFileProtectRule: update response param.
- Update API ListHoneypotAlarmEvents: update param CurrentPage.
- Update API ListHoneypotAlarmEvents: update param Dealed.
- Update API ListHoneypotAlarmEvents: update param DstIp.
- Update API ListHoneypotAlarmEvents: update param PageSize.
- Update API ListHoneypotAlarmEvents: update param RiskLevelList.
- Update API ListHoneypotAlarmEvents: update param SrcIp.
- Update API ListOssScanConfig: update response param.
- Update API RemoveCheckResultWhiteList: add param RuleId.
- Update API RemoveCheckResultWhiteList: update param CheckIds.
- Update API RemoveCheckResultWhiteList: update response param.
- Update API UpdateOssScanConfig: add param DecryptionList.
- Update API UpdateOssScanConfig: add param LastModifiedStartTime.
- Update API ValidateHcWarnings: add param Status.
- Update API ValidateHcWarnings: update param Uuids.
- Update API VerifyCheckResult: update param CheckIds.


2024-07-02 Version: 2.31.0
- Support API CreateHybridProxyCluster.
- Update API DescribeAffectedMaliciousFileImages: update response param.
- Update API DescribeBackupPolicies: update response param.
- Update API DescribeImageInstances: update response param.
- Update API DescribeImageSensitiveFileList: update response param.
- Update API DescribeInstanceStatistics: update response param.
- Update API DescribeSuspEventUserSetting: update response param.


2024-06-21 Version: 2.30.2
- Update API DescribeSuspEvents: update response param.
- Update API GetCheckDetail: update response param.
- Update API ListFileProtectEvent: add param Operation.


2024-06-20 Version: 2.30.1
- Update API DescribeCommonOverallConfigList: update response param.
- Update API ListHoneypotEventFlows: update param CurrentPage.
- Update API ListHoneypotEventFlows: update param Dealed.
- Update API ListHoneypotEventFlows: update param Lang.
- Update API ListHoneypotEventFlows: update param PageSize.
- Update API ListHoneypotEventFlows: update param RequestId.
- Update API ListHoneypotEventFlows: update param SecurityEventId.


2024-06-11 Version: 2.30.0
- Support API DescribeVulDefendCountStatistics.
- Support API DescribeVulMetaCountStatistics.
- Update API DescribeCloudCenterInstances: update param RegionId.
- Update API DescribeFieldStatistics: update response param.
- Update API DescribeGroupedInstances: update response param.
- Update API DescribeUuidsByVulNames: update response param.
- Update API DescribeVulListPage: add param RaspDefend.
- Update API DescribeVulListPage: add param VulType.
- Update API DescribeVulListPage: update response param.
- Update API HandleSecurityEvents: add param ResourceDirectoryAccountId.


2024-05-30 Version: 2.29.4
- Update API DescribeImageListWithBaselineName: update response param.
- Update API DescribeImageSensitiveFileList: update response param.
- Update API DescribeLogMeta: add param ResourceDirectoryAccountId.
- Update API DescribeSecureSuggestion: update response param.
- Update API GetLogMeta: add param ResourceDirectoryAccountId.
- Update API ModifyLogMetaStatus: add param ResourceDirectoryAccountId.
- Update API ModifyOpenLogShipper: add param ResourceDirectoryAccountId.


2024-05-13 Version: 2.29.3
- Update API DescribeSuspEvents: add param StrictMode.


2024-05-10 Version: 2.29.2
- Update API ListCheckResult: update response param.


2024-05-08 Version: 2.29.1
- Update API DescribeAssetDetailByUuid: update response param.
- Update API ListCheckItemWarningSummary: update response param.


2024-04-29 Version: 2.29.0
- Support API ListCompressFileDetectResult.
- Update API AddSasModuleTrial: update response param.
- Update API ChangeCheckCustomConfig: add param RepairConfigs.
- Update API ChangeCheckCustomConfig: update response param.
- Update API CreateFileDetect: add param Decompress.
- Update API CreateFileDetect: add param DecompressMaxFileCount.
- Update API CreateFileDetect: add param DecompressMaxLayer.
- Update API DescribeAccessKeyLeakDetail: add param ResourceDirectoryAccountId.
- Update API DescribeAccesskeyLeakList: add param ResourceDirectoryAccountId.
- Update API DescribeBruteForceRecords: add param InstanceId.
- Update API DescribeBruteForceRecords: add param Remark.
- Update API DescribeBruteForceRecords: update response param.
- Update API DescribeVersionConfig: update response param.
- Update API GetCheckDetail: update response param.
- Update API GetFileDetectResult: update response param.
- Update API GetModuleTrialAuthInfo: update response param.
- Update API ListCheckInstanceResult: update response param.
- Update API ListFileProtectEvent: add param EndTime.
- Update API ListFileProtectEvent: add param InstanceId.
- Update API ListFileProtectEvent: add param InstanceName.
- Update API ListFileProtectEvent: add param InternetIp.
- Update API ListFileProtectEvent: add param IntranetIp.
- Update API ListFileProtectEvent: add param StartTime.
- Update API ListFileProtectEvent: add param Uuid.


2024-04-17 Version: 2.28.0
- Support API ListCompressFileDetectResult.
- Update API AddSasModuleTrial: update response param.
- Update API CreateFileDetect: add param Decompress.
- Update API CreateFileDetect: add param DecompressMaxFileCount.
- Update API CreateFileDetect: add param DecompressMaxLayer.
- Update API DescribeVersionConfig: update response param.
- Update API GetFileDetectResult: update response param.
- Update API GetModuleTrialAuthInfo: update response param.


2024-04-12 Version: 2.27.6
- Update API DescribeVulList: add param Ids.


2024-04-12 Version: 2.27.6
- Update API DescribeVulList: add param Ids.


2024-04-10 Version: 2.27.5
- Update API BindAuthToMachine: add param IsPreBind.
- Update API BindAuthToMachine: add param NtmVersion.
- Update API BindAuthToMachine: add param PreBindOrderId.
- Update API BindAuthToMachine: update param AuthVersion.
- Update API BindAuthToMachine: update response param.
- Update API CreateOssBucketScanTask: add param DecompressMaxFileCount.
- Update API CreateOssBucketScanTask: add param DecompressMaxLayer.
- Update API CreateOssScanConfig: add param DecompressMaxFileCount.
- Update API CreateOssScanConfig: add param DecompressMaxLayer.
- Update API GetOssScanConfig: update response param.
- Update API ListObjectScanEvent: add param ParentEventId.
- Update API ListObjectScanEvent: update response param.
- Update API ListOssBucketScanInfo: update response param.
- Update API ListOssScanConfig: update response param.
- Update API UpdateOssScanConfig: add param DecompressMaxFileCount.
- Update API UpdateOssScanConfig: add param DecompressMaxLayer.


2024-03-27 Version: 2.27.4
- Update API DeleteMaliciousFileWhitelistConfig: update param ConfigId.
- Update API DescribeVulList: update response param.
- Update API ListCheckInstanceResult: update param PageSize.
- Update API ListCheckItem: update response param.
- Update API ListCheckResult: update param PageSize.


2024-03-13 Version: 2.27.3
- Update API AddClientUserDefineRule: add param Domain.
- Update API DescribeExposedInstanceCriteria: add param ResourceDirectoryAccountId.
- Update API DescribeExposedInstanceDetail: add param ResourceDirectoryAccountId.
- Update API DescribeExposedInstanceList: add param ResourceDirectoryAccountId.
- Update API DescribeExposedStatisticsDetail: add param ResourceDirectoryAccountId.
- Update API DescribePropertyScaItem: update param SearchItem.
- Update API DescribePropertyScaItem: update response param.
- Update API DescribeVersionConfig: update response param.
- Update API GetClientUserDefineRule: update response param.
- Update API ModifyClientUserDefineRule: add param Domain.
- Update API ModifyClientUserDefineRule: update response param.


2024-02-28 Version: 2.27.2
- Update API DescribeExposedInstanceCriteria: add param ResourceDirectoryAccountId.
- Update API DescribeExposedInstanceDetail: add param ResourceDirectoryAccountId.
- Update API DescribeExposedInstanceList: add param ResourceDirectoryAccountId.
- Update API DescribeExposedStatisticsDetail: add param ResourceDirectoryAccountId.
- Update API DescribeVersionConfig: update response param.


2024-02-27 Version: 2.27.1
- Update API DescribeVersionConfig: update response param.


2024-01-31 Version: 2.27.0
- Support API DeleteVulAutoRepairConfig.
- Update API DescribeSuspEventDetailupdate Lang param.
- Update API DescribeSuspEventsupdate Lang param.
- Update API ListAgentlessTaskupdate response param.


2024-01-26 Version: 2.26.0
- Support API DeleteVulAutoRepairConfig.
- Update API DescribeSuspEventDetailupdate Lang param.
- Update API DescribeSuspEventsupdate Lang param.


2024-01-23 Version: 2.25.0
- Generated python 2018-12-03 for Sas.

2024-01-23 Version: 2.25.0
- Generated python 2018-12-03 for Sas.

2024-01-22 Version: 2.24.0
- Generated python 2018-12-03 for Sas.

2024-01-19 Version: 2.23.0
- Generated python 2018-12-03 for Sas.

2024-01-18 Version: 2.22.0
- Generated python 2018-12-03 for Sas.

2024-01-11 Version: 2.21.1
- Generated python 2018-12-03 for Sas.

2023-12-22 Version: 2.21.0
- Generated python 2018-12-03 for Sas.

2023-12-21 Version: 2.20.1
- Generated python 2018-12-03 for Sas.

2023-12-19 Version: 2.20.0
- Generated python 2018-12-03 for Sas.

2023-12-08 Version: 2.19.1
- Generated python 2018-12-03 for Sas.

2023-12-06 Version: 2.19.0
- Generated python 2018-12-03 for Sas.

2023-11-28 Version: 2.18.1
- Generated python 2018-12-03 for Sas.

2023-11-25 Version: 2.18.0
- Generated python 2018-12-03 for Sas.

2023-11-23 Version: 2.17.1
- Generated python 2018-12-03 for Sas.

2023-11-22 Version: 2.17.0
- Generated python 2018-12-03 for Sas.

2023-11-20 Version: 2.16.0
- Generated python 2018-12-03 for Sas.

2023-11-17 Version: 2.15.0
- Generated python 2018-12-03 for Sas.

2023-11-16 Version: 2.14.0
- Generated python 2018-12-03 for Sas.

2023-11-14 Version: 2.13.0
- Generated python 2018-12-03 for Sas.

2023-11-09 Version: 2.12.0
- Generated python 2018-12-03 for Sas.

2023-11-08 Version: 2.11.0
- Generated python 2018-12-03 for Sas.

2023-11-07 Version: 2.10.0
- Generated python 2018-12-03 for Sas.

2023-11-06 Version: 2.9.1
- Generated python 2018-12-03 for Sas.

2023-11-03 Version: 2.9.0
- Generated python 2018-12-03 for Sas.

2023-10-26 Version: 2.8.1
- Generated python 2018-12-03 for Sas.

2023-10-24 Version: 2.8.0
- Generated python 2018-12-03 for Sas.

2023-10-17 Version: 2.7.3
- Generated python 2018-12-03 for Sas.

2023-10-16 Version: 2.7.2
- Generated python 2018-12-03 for Sas.

2023-10-16 Version: 2.7.2
- Generated python 2018-12-03 for Sas.

2023-10-16 Version: 2.7.1
- Generated python 2018-12-03 for Sas.

2023-10-12 Version: 2.7.0
- Generated python 2018-12-03 for Sas.

2023-09-26 Version: 2.6.0
- Generated python 2018-12-03 for Sas.

2023-09-22 Version: 2.5.0
- Generated python 2018-12-03 for Sas.

2023-08-19 Version: 2.4.0
- Generated python 2018-12-03 for Sas.

2023-08-11 Version: 2.3.0
- Generated python 2018-12-03 for Sas.

2023-08-09 Version: 2.2.3
- Generated python 2018-12-03 for Sas.

2023-08-05 Version: 2.2.2
- Generated python 2018-12-03 for Sas.

2023-07-29 Version: 2.2.1
- Supported Standard config.

2023-07-22 Version: 2.2.0
- Support ContainerImageScanNew.
- Supported rasp-attach for user.
- Fixed, make SourceIp private.

2023-07-20 Version: 2.1.9
- Support rd sdk.

2023-07-11 Version: 2.1.8
- Change ListAssetSelectionTarget Request.

2023-06-05 Version: 2.1.7
- Change ListAssetSelectionTarget Request.

2023-05-31 Version: 2.1.6
- Change ListAssetSelectionTarget Request.

2023-05-15 Version: 2.1.5
- Change ListAssetSelectionTarget Request.

2023-05-15 Version: 2.1.4
- Change DescribeSoarStrategyTaskDetail Request.

2023-05-08 Version: 2.1.3
- Change DescribeSoarStrategyTaskDetail Request.

2023-03-21 Version: 2.1.2
- Change DescribeLogstoreStorage Response.

2023-02-10 Version: 2.1.1
- Change DescribeLogstoreStorage Response.

2022-12-28 Version: 2.1.0
- Change DescribeLogstoreStorage Response.

2022-12-26 Version: 2.0.0
- Change DescribeLogstoreStorage Response.

2022-12-19 Version: 1.2.2
- Change DescribeLogstoreStorage Response.

2022-12-02 Version: 1.2.1
- Change DescribeLogstoreStorage Response.

2022-11-23 Version: 1.2.0
- Change DescribeLogstoreStorage Response.

2022-11-15 Version: 1.1.35
- Change DescribeLogstoreStorage Response.

2022-11-02 Version: 1.1.34
- Change DescribeLogstoreStorage Response.

2022-09-28 Version: 1.1.33
- Change RefreshAssets Public.

2022-09-19 Version: 1.1.32
- Change RefreshAssets Public.

2022-08-31 Version: 1.1.31
- Change GetFileDetectResult Public.

2022-08-22 Version: 1.1.30
- Change GetFileDetectResult Public.

2022-08-16 Version: 1.1.29
- Change GetFileDetectResult Public.

2022-07-29 Version: 1.1.28
- Change ListCheckInstanceResult Public.

2022-07-26 Version: 1.1.27
- Change ListCheckInstanceResult Public.

2022-07-26 Version: 1.1.26
- Change ListCheckInstanceResult Public.

2022-07-25 Version: 1.1.25
- Change ListCheckInstanceResult GetCheckDetail Public.

2022-07-25 Version: 1.1.24
- Change ListCheckInstanceResult GetCheckDetail Public.

2022-07-20 Version: 1.1.23
- Change getFileDetectResult.

2022-07-19 Version: 1.1.22
- Change cspm ListCheckResult api.

2022-07-15 Version: 1.1.21
- Add cspm ListCheckResult api.

2022-07-15 Version: 1.1.20
- Add open file detect api.

2022-07-14 Version: 1.1.19
- Add open file detect api.

2022-07-08 Version: 1.1.18
- Add open file detect api.

2022-07-04 Version: 1.1.17
- Add open file detect api.

2022-06-23 Version: 1.1.16
- Add open file detect api.

2022-06-20 Version: 1.1.15
- Add EventId when listQuery EventInfo.

2022-05-27 Version: 1.1.14
- Generated python 2018-12-03 for Sas.

2022-05-18 Version: 1.1.13
- Generated python 2018-12-03 for Sas.

2022-05-12 Version: 1.1.12
- Generated python 2018-12-03 for Sas.

2022-05-10 Version: 1.1.11
- Generated python 2018-12-03 for Sas.

2022-04-21 Version: 1.1.10
- Generated python 2018-12-03 for Sas.

2022-04-20 Version: 1.1.9
- Generated python 2018-12-03 for Sas.

2022-04-19 Version: 1.1.8
- Generated python 2018-12-03 for Sas.

2022-04-13 Version: 1.1.7
- Generated python 2018-12-03 for Sas.

2022-04-11 Version: 1.1.6
- Generated python 2018-12-03 for Sas.

2022-04-07 Version: 1.1.5
- Generated python 2018-12-03 for Sas.

2022-04-01 Version: 1.1.4
- Generated python 2018-12-03 for Sas.

2022-03-31 Version: 1.1.3
- Generated python 2018-12-03 for Sas.

2022-03-25 Version: 1.1.2
- Generated python 2018-12-03 for Sas.

2022-03-21 Version: 1.1.1
- Generated python 2018-12-03 for Sas.

2022-03-14 Version: 1.1.0
- Generated python 2018-12-03 for Sas.

2022-02-28 Version: 1.0.15
- Support DescribeSuspEvents, DescribeAlarmEventList API.

2022-02-25 Version: 1.0.14
- Generated python 2018-12-03 for Sas.

2022-02-21 Version: 1.0.13
- Support DescribeImageListWithBaselineName API.

2022-02-09 Version: 1.0.12
- AMP Version Change.

2021-12-27 Version: 1.0.11
- Support DescribeAccessKeyLeakDetail API.

2021-11-12 Version: 1.0.10
- Support ExportVul API.

2021-11-02 Version: 1.0.9
- Support DescribeInstallCodes API.

2021-09-17 Version: 1.0.8
- Support DescribeVulExportInfo API.

2021-09-15 Version: 1.0.7
- Support DescribeWarningMachines API.

2021-08-18 Version: 1.0.6
- Support RefreshAssets API.

2021-06-25 Version: 1.0.5
- Support DescribeSuspEventDetail API.

2021-06-18 Version: 1.0.4
- Generated python 2018-12-03 for Sas.

2021-05-17 Version: 1.0.3
- Generated python 2018-12-03 for Sas.

2021-05-17 Version: 1.0.2
- Generated python 2018-12-03 for Sas.

2021-05-14 Version: 1.0.1
- Generated python 2018-12-03 for Sas.

2020-12-30 Version: 1.0.0
- AMP Version Change.

