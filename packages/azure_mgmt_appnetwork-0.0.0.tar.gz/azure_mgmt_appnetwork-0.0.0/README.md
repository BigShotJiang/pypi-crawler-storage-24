
# This package will be `azure-mgmt-appnetwork`

The `Azure SDK` team is planning to release this package for public usage soon. This is a placeholder on PyPI for planning purposes and do not yet contain any code.

If you have any questions about the future availability of this package, please create an issue on https://github.com/Azure/azure-sdk-for-python/issues or contact the email on this PyPI page.
