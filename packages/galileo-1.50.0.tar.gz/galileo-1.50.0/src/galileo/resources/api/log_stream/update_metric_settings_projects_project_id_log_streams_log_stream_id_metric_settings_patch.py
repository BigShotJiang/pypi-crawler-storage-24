from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from galileo.exceptions import (
    AuthenticationError,
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError,
)
from galileo.utils.headers_data import get_sdk_header
from galileo_core.constants.request_method import RequestMethod
from galileo_core.helpers.api_client import ApiClient

from ... import errors
from ...models.http_validation_error import HTTPValidationError
from ...models.metric_settings_request import MetricSettingsRequest
from ...models.metric_settings_response import MetricSettingsResponse
from ...types import Response


def _get_kwargs(project_id: str, log_stream_id: str, *, body: MetricSettingsRequest) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": RequestMethod.PATCH,
        "return_raw_response": True,
        "path": f"/projects/{project_id}/log_streams/{log_stream_id}/metric_settings",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    headers["X-Galileo-SDK"] = get_sdk_header()

    _kwargs["content_headers"] = headers
    return _kwargs


def _parse_response(
    *, client: ApiClient, response: httpx.Response
) -> Union[HTTPValidationError, MetricSettingsResponse]:
    if response.status_code == 200:
        return MetricSettingsResponse.from_dict(response.json())

    if response.status_code == 422:
        return HTTPValidationError.from_dict(response.json())

    # Handle common HTTP errors with actionable messages
    if response.status_code == 400:
        raise BadRequestError(response.status_code, response.content)
    if response.status_code == 401:
        raise AuthenticationError(response.status_code, response.content)
    if response.status_code == 403:
        raise ForbiddenError(response.status_code, response.content)
    if response.status_code == 404:
        raise NotFoundError(response.status_code, response.content)
    if response.status_code == 409:
        raise ConflictError(response.status_code, response.content)
    if response.status_code == 429:
        raise RateLimitError(response.status_code, response.content)
    if response.status_code >= 500:
        raise ServerError(response.status_code, response.content)
    raise errors.UnexpectedStatus(response.status_code, response.content)


def _build_response(
    *, client: ApiClient, response: httpx.Response
) -> Response[Union[HTTPValidationError, MetricSettingsResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str, log_stream_id: str, *, client: ApiClient, body: MetricSettingsRequest
) -> Response[Union[HTTPValidationError, MetricSettingsResponse]]:
    """Update Metric Settings.

    Args:
        project_id (str):
        log_stream_id (str):
        body (MetricSettingsRequest):

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Response[Union[HTTPValidationError, MetricSettingsResponse]]
    """
    kwargs = _get_kwargs(project_id=project_id, log_stream_id=log_stream_id, body=body)

    response = client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    project_id: str, log_stream_id: str, *, client: ApiClient, body: MetricSettingsRequest
) -> Optional[Union[HTTPValidationError, MetricSettingsResponse]]:
    """Update Metric Settings.

    Args:
        project_id (str):
        log_stream_id (str):
        body (MetricSettingsRequest):

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Union[HTTPValidationError, MetricSettingsResponse]
    """
    return sync_detailed(project_id=project_id, log_stream_id=log_stream_id, client=client, body=body).parsed


async def asyncio_detailed(
    project_id: str, log_stream_id: str, *, client: ApiClient, body: MetricSettingsRequest
) -> Response[Union[HTTPValidationError, MetricSettingsResponse]]:
    """Update Metric Settings.

    Args:
        project_id (str):
        log_stream_id (str):
        body (MetricSettingsRequest):

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Response[Union[HTTPValidationError, MetricSettingsResponse]]
    """
    kwargs = _get_kwargs(project_id=project_id, log_stream_id=log_stream_id, body=body)

    response = await client.arequest(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str, log_stream_id: str, *, client: ApiClient, body: MetricSettingsRequest
) -> Optional[Union[HTTPValidationError, MetricSettingsResponse]]:
    """Update Metric Settings.

    Args:
        project_id (str):
        log_stream_id (str):
        body (MetricSettingsRequest):

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Union[HTTPValidationError, MetricSettingsResponse]
    """
    return (await asyncio_detailed(project_id=project_id, log_stream_id=log_stream_id, client=client, body=body)).parsed
