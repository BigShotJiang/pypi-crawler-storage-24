from datetime import timedelta
from unittest.mock import patch

import pytest
import swapper
from constance import config
from constance.test import override_config
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone

import baseapp_auth.tests.helpers as h
from baseapp_auth.rest_framework.users.tasks import anonymize_and_delete_user_task
from baseapp_auth.tests.factories import PasswordValidationFactory
from baseapp_auth.tests.mixins import ApiMixin
from baseapp_auth.utils.referral_utils import get_user_referral_model
from baseapp_chats.tests.factories import (
    ChatRoomFactory,
    ChatRoomParticipantFactory,
    MessageFactory,
)
from baseapp_comments.tests.factories import CommentFactory
from baseapp_referrals.utils import get_referral_code

User = get_user_model()
UserFactory = h.get_user_factory()

pytestmark = [pytest.mark.django_db, pytest.mark.referrals]

skip_if_no_referrals = pytest.mark.skipif(
    "baseapp_referrals" not in settings.INSTALLED_APPS, reason="No referrals app"
)

skip_if_no_organizations = pytest.mark.skipif(
    "baseapp_organizations" not in settings.INSTALLED_APPS,
    reason="No organizations app",
)

UserReferral = get_user_referral_model()


class TestUsersRetrieve(ApiMixin):
    view_name = "users-detail"

    def test_guest_cant_retrieve(self, client):
        user = UserFactory()
        r = client.get(self.reverse(kwargs={"pk": user.pk}))
        h.responseUnauthorized(r)

    def test_user_can_retrieve(self, user_client):
        user = UserFactory()
        r = user_client.get(self.reverse(kwargs={"pk": user.pk}))
        h.responseOk(r)

    def test_object_keys_for_own_user(self, user_client):
        r = user_client.get(self.reverse(kwargs={"pk": user_client.user.pk}))
        h.responseOk(r)
        expected = {
            "id",
            "profile",
            "email",
            "is_email_verified",
            "email_verification_required",
            "new_email",
            "is_new_email_confirmed",
            "referral_code",
            "phone_number",
            "preferred_language",
        }
        actual = set(r.data.keys())
        assert expected == actual

        profile_expected = {"id", "name", "image", "url_path"}
        profile_actual = set(r.data["profile"].keys())
        assert profile_expected == profile_actual

    def test_object_keys_for_other_user(self, user_client):
        user = UserFactory()
        r = user_client.get(self.reverse(kwargs={"pk": user.pk}))
        h.responseOk(r)
        expected = {"id", "profile", "phone_number"}
        actual = set(r.data.keys())
        assert expected == actual

        profile_expected = {"id", "name", "image", "url_path"}
        profile_actual = set(r.data["profile"].keys())
        assert profile_expected == profile_actual

    @pytest.mark.skipif(
        not hasattr(User, "public_id"),
        reason="User model does not expose public_id; skip until DocumentIdMixin is enabled",
    )
    def test_id_returns_public_id(self, user_client):
        """Ensure the serialized `id` is the public_id when available."""
        from django.contrib.contenttypes.models import ContentType

        from baseapp_core.models import DocumentId

        user = UserFactory()

        content_type = ContentType.objects.get_for_model(user)
        mapping = DocumentId.objects.filter(content_type=content_type, object_id=user.pk).first()
        r = user_client.get(self.reverse(kwargs={"pk": user.pk}))
        h.responseOk(r)
        assert user.pk != r.data["id"]
        assert str(mapping.public_id) == r.data["id"]


class TestUsersUpdate(ApiMixin):
    view_name = "users-detail"

    def test_guest_cant_update(self, client):
        user = UserFactory()
        r = client.patch(self.reverse(kwargs={"pk": user.id}))
        h.responseUnauthorized(r)

    def test_user_can_update_self(self, user_client):
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.id}))
        h.responseOk(r)

    def test_user_cant_update_other_user(self, user_client):
        other_user = UserFactory()
        data = {"email": "test@email.co"}
        r = user_client.patch(self.reverse(kwargs={"pk": other_user.id}), data)
        h.responseForbidden(r)

    def test_user_cant_update_email(self, user_client):
        data = {"email": "test@email.co"}
        user_client.patch(self.reverse(kwargs={"pk": user_client.user.id}), data)
        user_client.user.refresh_from_db()
        assert user_client.user.email != "test@email.co"

    @pytest.mark.skipif(
        not hasattr(User, "public_id"),
        reason="User model does not expose public_id; skip until DocumentIdMixin is enabled",
    )
    def test_can_update_public_fields_using_public_id(self, user_client):
        data = {"preferred_language": "pt"}
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.public_id}), data)
        h.responseOk(r)
        user_client.user.refresh_from_db()
        assert user_client.user.preferred_language == "pt"

    @skip_if_no_referrals
    def test_can_update_referred_by_code_on_the_same_day_user_registered(self, user_client):
        user = UserFactory()
        data = {"referred_by_code": get_referral_code(user)}
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.id}), data)
        h.responseOk(r)
        user_client.user.refresh_from_db()
        assert user_client.user.referred_by.referrer == user

    @skip_if_no_referrals
    def test_cant_update_referred_by_code_with_invalid_code(self, user_client):
        data = {"referred_by_code": "8182"}
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.id}), data)
        h.responseBadRequest(r)
        assert r.data["referred_by_code"] == ["Invalid referral code."]

    @skip_if_no_referrals
    def test_cant_update_referred_by_code_when_user_already_has_a_referrer(self, user_client):
        user = UserFactory()
        UserReferral.objects.create(referee=user_client.user, referrer=user)
        data = {"referred_by_code": get_referral_code(user)}
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.id}), data)
        h.responseBadRequest(r)
        assert r.data["referred_by_code"] == ["You have already been referred by somebody."]

    @skip_if_no_referrals
    def test_cant_update_referred_by_code_to_yourself(self, user_client):
        data = {"referred_by_code": get_referral_code(user_client.user)}
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.id}), data)
        h.responseBadRequest(r)
        assert r.data["referred_by_code"] == ["You cannot refer yourself."]

    @skip_if_no_referrals
    def test_cant_update_referred_by_code_after_the_day_the_user_registered(self, user_client):
        user_client.user.date_joined = timezone.now() - timedelta(days=1, hours=1)
        user_client.user.save()
        user = UserFactory()
        data = {"referred_by_code": get_referral_code(user)}
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.id}), data)
        h.responseBadRequest(r)
        assert r.data["referred_by_code"] == [
            "You are no longer allowed to change who you were referred by."
        ]

    def test_can_upload_avatar(self, user_client, image_base64):
        data = {"avatar": image_base64}
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.pk}), data)
        h.responseOk(r)
        user_client.user.profile.refresh_from_db()
        assert bool(user_client.user.profile.image) is True

    def test_can_clear_avatar(self, user_client, image_djangofile):
        user_client.user.profile.image = image_djangofile
        user_client.user.profile.save()
        data = {"avatar": None}
        r = user_client.patch(self.reverse(kwargs={"pk": user_client.user.pk}), data)
        h.responseOk(r)
        user_client.user.profile.refresh_from_db()
        assert not user_client.user.profile.image


class TestUsersList(ApiMixin):
    view_name = "users-list"

    def test_guest_cant_list(self, client):
        r = client.get(self.reverse())
        h.responseUnauthorized(r)

    def test_user_can_list(self, user_client):
        r = user_client.get(self.reverse())
        h.responseOk(r)

    def test_can_search(self, user_client):
        UserFactory(first_name="John", last_name="Smith")
        UserFactory(first_name="Bobby", last_name="Timbers")
        r = user_client.get(self.reverse(query_params={"q": "John Smith"}))
        h.responseOk(r)
        assert len(r.data["results"]) == 1
        assert r.data["results"][0]["profile"]["name"] == "John Smith"


class TestUsersMe(ApiMixin):
    view_name = "users-me"

    def test_as_anon(self, client):
        r = client.get(self.reverse())
        h.responseUnauthorized(r)

    def test_as_user(self, client):
        user = UserFactory()
        client.force_authenticate(user)
        r = client.get(self.reverse())
        h.responseOk(r)


class TestUsersDeleteAccount(ApiMixin):
    view_name = "users-delete-account"

    def test_as_anon(self, client):
        r = client.get(self.reverse())
        h.responseUnauthorized(r)

    def test_non_admin_can_delete_account(self, user_client):
        user_client.user.is_superuser = False
        user_client.user.save()
        user_id = user_client.user.id
        r = user_client.delete(self.reverse())
        h.responseOk(r)
        assert User.objects.filter(id=user_id).exists() is False

    def test_admin_can_only_deactivate_account(self, user_client):
        user_client.user.is_superuser = True
        user_client.user.save()
        user_id = user_client.user.id
        r = user_client.delete(self.reverse())
        h.responseOk(r)
        assert User.objects.filter(id=user_id, is_active=False).exists() is True

    def test_anonymize_and_delete_is_triggered(self, user_client):
        user_client.user.is_superuser = False
        user_client.user.save()
        user_id = user_client.user.id

        with patch(
            "baseapp_auth.rest_framework.users.tasks.anonymize_and_delete_user_task.apply_async"
        ) as mock_apply_async:
            r = user_client.delete(self.reverse())
            h.responseOk(r)
            mock_apply_async.assert_called_once_with(
                args=[user_id], eta=mock_apply_async.call_args[1]["eta"]
            )

    @skip_if_no_organizations
    def test_owner_of_organization_cannot_delete_account(self, user_client):
        from baseapp_organizations.tests.factories import OrganizationFactory
        from baseapp_profiles.tests.factories import ProfileFactory

        user = user_client.user
        user.is_superuser = False
        user.is_active = True
        user.save()

        profile = ProfileFactory(owner=user)
        OrganizationFactory(profile=profile)

        r = user_client.delete(self.reverse())

        h.responseBadRequest(r)
        assert (
            r.data["detail"]
            == "Account cannot be deleted because you're the owner of an organization. Transfer ownership or delete the organization first."
        )
        user.refresh_from_db()
        assert user.is_active is True

    @override_config(SEND_USER_ANONYMIZE_EMAIL_TO_SUPERUSERS=True)
    def test_anonymize_and_delete_user_task_sends_success_email_to_superusers(self, outbox):
        user = UserFactory()
        user_id = user.id
        superuser = UserFactory(is_superuser=True, email="superuser@example.com")
        anonymize_and_delete_user_task(user_id)
        assert len(outbox) == 2
        assert outbox[0].to == [user.email]
        assert any("successfully" in m.subject.lower() for m in outbox)
        assert any(user.email in m.to for m in outbox)
        assert any(superuser.email in m.to for m in outbox)

    @override_config(SEND_USER_ANONYMIZE_EMAIL_TO_SUPERUSERS=False)
    def test_anonymize_and_delete_user_task_sends_success_email_not_to_superusers(self, outbox):
        user = UserFactory()
        user_id = user.id
        superuser = UserFactory(is_superuser=True, email="superuser@example.com")
        anonymize_and_delete_user_task(user_id)
        assert len(outbox) == 1
        assert outbox[0].to == [user.email]
        assert any("successfully" in m.subject.lower() for m in outbox)
        assert any(user.email in m.to for m in outbox)
        assert not any(superuser.email in m.to for m in outbox)

    def test_anonymize_and_delete_user_task_sends_error_email(self, outbox):
        user = UserFactory()
        user_id = user.id

        with patch(
            "baseapp_auth.rest_framework.users.tasks.anonymize_activitylog",
            side_effect=Exception("fail"),
        ):
            anonymize_and_delete_user_task(user_id)

        assert len(outbox) == 1
        assert any("error" in m.subject.lower() for m in outbox)
        assert any(user.email in m.to for m in outbox)

    def test_send_anonymize_user_success_email_with_superusers(self, outbox):

        config.SEND_USER_ANONYMIZE_EMAIL_TO_SUPERUSERS = True
        user = UserFactory()
        user_id = user.id
        superuser = UserFactory(is_superuser=True, email="superuser@example.com")
        with patch(
            "baseapp_auth.rest_framework.users.tasks.anonymize_activitylog",
        ):
            anonymize_and_delete_user_task(user_id)

        assert len(outbox) == 2
        assert any("successfully" in m.subject.lower() for m in outbox)
        assert any(user.email in m.to for m in outbox)
        assert any(superuser.email in m.to for m in outbox)

    def test_send_anonymize_user_error_email_with_superusers(self, outbox):

        config.SEND_USER_ANONYMIZE_EMAIL_TO_SUPERUSERS = True
        user = UserFactory()
        user_id = user.id
        superuser = UserFactory(is_superuser=True, email="superuser@example.com")
        with patch(
            "baseapp_auth.rest_framework.users.tasks.anonymize_activitylog",
            side_effect=Exception("fail"),
        ):
            anonymize_and_delete_user_task(user_id)

        assert len(outbox) == 2
        assert any("error" in m.subject.lower() for m in outbox)
        assert any(user.email in m.to for m in outbox)
        assert any(superuser.email in m.to for m in outbox)

    def test_anonymize_and_delete_user_task_anonymizes_user_comments(self):
        Comment = swapper.load_model("baseapp_comments", "Comment")

        user = UserFactory()
        user_id = user.pk
        CommentFactory.create_batch(2, user=user)
        assert Comment.objects_visible.filter(user_id=user_id).count() == 2

        anonymize_and_delete_user_task(user_id)
        assert Comment.objects_visible.filter(user_id=user_id).count() == 0
        assert User.objects.all().count() == 0

    def test_anonymize_and_delete_user_task_anonymizes_user_messages(self):
        Message = swapper.load_model("baseapp_chats", "Message")

        user = UserFactory()
        user_id = user.pk
        room = ChatRoomFactory()
        participants_count = 2
        ChatRoomParticipantFactory.create_batch(participants_count, room=room)
        MessageFactory.create_batch(2, user=user, room=room)
        assert Message.objects.filter(user_id=user_id).count() == 2

        anonymize_and_delete_user_task(user_id)
        assert Message.objects.filter(user_id=user_id).count() == 0
        assert User.objects.all().count() == 3


class TestUsersChangePassword(ApiMixin):
    view_name = "users-change-password"

    @pytest.fixture
    def data(self):
        return {"current_password": "1234567890", "new_password": "0987654321"}

    def test_as_anon(self, client):
        r = client.post(self.reverse())
        h.responseUnauthorized(r)

    def test_user_can_change_password(self, client, data):
        user = UserFactory(password=data["current_password"])
        client.force_authenticate(user)
        r = client.post(self.reverse(), data)
        h.responseOk(r)

    def test_password_is_set(self, client, data):
        user = UserFactory(password=data["current_password"])
        client.force_authenticate(user)
        r = client.post(self.reverse(), data)
        h.responseOk(r)
        user.refresh_from_db()
        assert user.check_password(data["new_password"])

    def test_current_password_must_match(self, client, data):
        user = UserFactory(password="not current password")
        client.force_authenticate(user)
        r = client.post(self.reverse(), data)
        h.responseBadRequest(r)
        assert r.data["current_password"] == ["That is not your current password."]

    def test_new_password_must_match_password_validations(self, client, data):
        PasswordValidationFactory()
        user = UserFactory(password=data["current_password"])
        client.force_authenticate(user)
        r = client.post(self.reverse(), data)
        h.responseBadRequest(r)
        assert r.data["new_password"] == [
            "This password must contain at least 1 special characters."
        ]

    def test_fails_nicely_on_invalid_json(self, user_client):
        invalid_json_str = """{
    "current_password": "1234",
    "new_password": "1234
}
"""
        r = user_client.generic(
            "POST",
            self.reverse(),
            data=invalid_json_str,
            content_type="application/json",
        )
        h.responseBadRequest(r)
        # The request should fail to parse the invalid json and pass an empty dict
        # to the endpoint request object. So we should see serializer field errors here
        assert r.data["current_password"] == ["This field is required."]
        assert r.data["new_password"] == ["This field is required."]


class TestUserPermission(ApiMixin):
    view_name = "users-permissions-me"

    def test_can_get_their_permission(self, user_client):
        admin_content_type = ContentType.objects.filter(app_label="admin").first()
        perm = Permission.objects.create(
            codename="test_unique_perm", name="Test", content_type=admin_content_type
        )
        user_client.user.user_permissions.add(perm)
        r = user_client.get(self.reverse())
        h.responseOk(r)

    def test_guest_cannot_get_permission(self, client):
        r = client.get(self.reverse())
        h.responseUnauthorized(r)

    def test_user_can_check_their_permission(self, user_client):
        admin_content_type = ContentType.objects.filter(app_label="admin").first()
        perm = Permission.objects.create(
            codename="test_unique_perm", name="Test", content_type=admin_content_type
        )
        user_client.user.user_permissions.add(perm)
        r = user_client.get(self.reverse(), {"perm": "admin.test_unique_perm"})
        h.responseOk(r)
        assert r.data["permissions"]["admin.test_unique_perm"] is True

    def test_user_get_false_without_permission(self, user_client):
        r = user_client.get(self.reverse(), {"perm": "admin.test_unique_perm"})
        h.responseOk(r)
        assert r.data["permissions"]["admin.test_unique_perm"] is not True


class TestUserPermissionList(ApiMixin):
    view_name = "user-permissions-list"

    def test_guest_cannot_get_user_permissions(self, client):
        content_type = ContentType.objects.all().first()
        perm = Permission.objects.filter(content_type_id=content_type).first()
        user = UserFactory()
        user.user_permissions.add(perm)
        r = client.get(self.reverse(kwargs={"user_pk": user.pk}))
        h.responseUnauthorized(r)

    def test_user_with_perm_can_get_user_permissions(self, user_client):
        content_type = ContentType.objects.all().first()
        perm = Permission.objects.filter(content_type_id=content_type).first()
        user = UserFactory()
        user.user_permissions.add(perm)
        p = Permission.objects.get(codename="change_user")
        p.content_type.app_label = "users"
        p.content_type.save()
        user_client.user.user_permissions.add(p)
        user_client.user.refresh_from_db()
        r = user_client.get(self.reverse(kwargs={"user_pk": user.pk}))
        h.responseOk(r)
