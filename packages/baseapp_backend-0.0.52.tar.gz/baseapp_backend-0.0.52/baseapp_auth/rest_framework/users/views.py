import swapper
from django.apps import apps
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.shortcuts import get_object_or_404
from rest_framework import (
    filters,
    mixins,
    permissions,
    response,
    serializers,
    status,
    viewsets,
)
from rest_framework.exceptions import ValidationError
from rest_framework_nested.viewsets import NestedViewSetMixin

from baseapp_auth.utils.normalize_permission import normalize_permission
from baseapp_core.rest_framework.decorators import action

User = get_user_model()

from django.utils.translation import gettext_lazy as _

from baseapp_core.rest_framework.mixins import PublicIdLookupMixin

from .mixins import PermissionsActionMixin
from .parsers import SafeJSONParser
from .serializers import (
    ChangePasswordSerializer,
    UserManagePermissionSerializer,
    UserPermissionSerializer,
    UserSerializer,
)


class UpdateSelfPermission(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.method in ("PUT", "PATCH"):
            if not request.user.is_authenticated or request.user != obj:
                return False
        return True


class UsersViewSet(
    PublicIdLookupMixin,
    PermissionsActionMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.ListModelMixin,
    viewsets.GenericViewSet,
):
    serializer_class = UserSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        UpdateSelfPermission,
    ]
    filter_backends = (filters.SearchFilter,)
    search_fields = ("first_name", "last_name")

    def get_queryset(self):
        return User.objects.all().order_by("id")

    @action(
        detail=False,
        methods=["GET"],
        permission_classes=[permissions.IsAuthenticated],
    )
    def me(self, request):
        user = request.user
        serializer = self.get_serializer(user)
        return response.Response(serializer.data)

    @action(
        detail=False,
        methods=["POST"],
        permission_classes=[permissions.IsAuthenticated],
        serializer_class=ChangePasswordSerializer,
        parser_classes=[SafeJSONParser],
    )
    def change_password(self, request):
        serializer = ChangePasswordSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response({"detail": "success"})

    @action(
        detail=False,
        methods=["DELETE"],
        permission_classes=[permissions.IsAuthenticated],
    )
    def delete_account(self, request):
        """
        TODO: When implementing full account deletion (not just anonymization), ensure all related data
        (e.g., profile pages, notifications, etc.) are thoroughly reviewed and deleted to avoid missing any user information.
        """
        user = request.user

        if apps.is_installed("baseapp_organizations"):
            Organization = swapper.load_model("baseapp_organizations", "Organization")
            if Organization.objects.filter(profile__owner_id=user.id).exists():
                return response.Response(
                    data={
                        "detail": _(
                            "Account cannot be deleted because you're the owner of an organization. Transfer ownership or delete the organization first."
                        )
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

        user.is_active = False
        user.save()

        if not user.is_superuser:
            user.anonymize_and_delete()
        return response.Response(data={}, status=status.HTTP_200_OK)

    @action(
        detail=False,
        methods=["get", "post"],
        serializer_class=UserPermissionSerializer,
        url_path="me/permissions",
    )
    def permissions_me(self, request):
        user = request.user

        if request.method == "GET":
            perm = request.query_params.get("perm")
        else:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            perm = serializer.validated_data["perm"]

        if perm:
            try:
                perm = normalize_permission(perm, user.__class__)
            except (AttributeError, TypeError) as err:
                raise ValidationError({"perm": _("Invalid permission format.")}) from err

            if "." not in perm:
                raise ValidationError(
                    {"perm": _("Invalid permission format. Expected app_label.codename.")}
                )

            return response.Response({"permissions": {perm: user.has_perm(perm)}})

        raw_perms = user.get_all_permissions()
        permissions_map = {
            normalize_permission(p, user.__class__): user.has_perm(p) for p in sorted(raw_perms)
        }

        return response.Response({"permissions": permissions_map})


class PermissionsViewSet(
    NestedViewSetMixin, viewsets.GenericViewSet, mixins.ListModelMixin, mixins.CreateModelMixin
):
    pagination_class = None
    serializer_class = UserManagePermissionSerializer
    permission_classes = [
        permissions.IsAuthenticated,
    ]
    parent_lookup_kwargs = {"user_pk": "user__id"}

    def get_user(self):
        user_pk = self.kwargs.get("user_pk", None)
        return get_object_or_404(User, pk=user_pk) if user_pk else None

    def get_queryset(self):
        user = self.get_user()
        if user:
            if not self.request.user.has_perm("users.change_user"):
                raise serializers.ValidationError(
                    {"detail": _("You do not have permission to perform this action.")}
                )
            return user.user_permissions.all().select_related("content_type")
        return Permission.objects.all().select_related("content_type")

    def get_serializer_context(self):
        return {**super().get_serializer_context(), "user": self.get_user()}
