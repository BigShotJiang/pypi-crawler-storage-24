import graphene
import swapper
from django.db.models import Case, When
from django.utils.translation import gettext_lazy as _
from graphene_django.filter import DjangoFilterConnectionField

from baseapp_core.graphql import DjangoObjectType
from baseapp_core.graphql import Node as RelayNode
from baseapp_core.graphql import (
    ThumbnailField,
    get_obj_relay_id,
    get_object_type_for_model,
    get_pk_from_relay_id,
)

from .filters import ChatRoomFilter, ChatRoomParticipantFilter

Profile = swapper.load_model("baseapp_profiles", "Profile")
ChatRoom = swapper.load_model("baseapp_chats", "ChatRoom")
ChatRoomParticipant = swapper.load_model("baseapp_chats", "ChatRoomParticipant")
ChatRoomParticipantRoleTypesEnum = graphene.Enum.from_enum(
    ChatRoomParticipant.ChatRoomParticipantRoles
)
UnreadMessageCount = swapper.load_model("baseapp_chats", "UnreadMessageCount")
Message = swapper.load_model("baseapp_chats", "Message")


class BaseChatRoomParticipantObjectType:
    role = graphene.Field(ChatRoomParticipantRoleTypesEnum)

    class Meta:
        interfaces = (RelayNode,)
        model = ChatRoomParticipant
        fields = ("id", "has_archived_room", "profile", "role")
        filterset_class = ChatRoomParticipantFilter


class ChatRoomParticipantObjectType(BaseChatRoomParticipantObjectType, DjangoObjectType):
    class Meta(BaseChatRoomParticipantObjectType.Meta):
        pass


VerbsEnum = graphene.Enum.from_enum(Message.Verbs)
MessageTypeEnum = graphene.Enum.from_enum(Message.MessageType)


class BaseMessageObjectType:
    action_object = graphene.Field(RelayNode)
    verb = graphene.Field(VerbsEnum)
    message_type = graphene.Field(MessageTypeEnum)
    content = graphene.String(required=False, profile_id=graphene.ID(required=False))
    is_read = graphene.Boolean(profile_id=graphene.ID(required=False))

    class Meta:
        interfaces = (RelayNode,)
        model = Message
        fields = (
            "id",
            "verb",
            "content",
            "message_type",
            "user",
            "profile",
            "created",
            "room",
            "action_object",
            "extra_data",
            "in_reply_to",
            "is_read",
            "deleted",
        )
        filter_fields = ("verb",)

    @classmethod
    def get_node(cls, info, id):
        try:
            message = cls._meta.model.objects.get(id=id)
            if not info.context.user.has_perm("baseapp_chats.view_message", message):
                return None
            return message
        except cls._meta.model.DoesNotExist:
            return None

    @staticmethod
    def get_profile_pk(info, profile_id=None):
        if profile_id:
            profile_pk = get_pk_from_relay_id(profile_id)
            if not Profile.objects.get_if_member(pk=profile_pk, user=info.context.user):
                return None
            else:
                return profile_pk
        elif hasattr(info.context.user, "current_profile") and hasattr(
            info.context.user.current_profile, "pk"
        ):
            return info.context.user.current_profile.pk
        elif hasattr(info.context.user, "profile") and hasattr(info.context.user.profile, "pk"):
            return info.context.user.profile.pk
        else:
            return None

    @staticmethod
    def get_replaced_profile_name(profile, profile_pk, replacement_text, include_verb=False):
        if not profile:
            return _("Profile Not Found")
        elif profile.id == profile_pk:
            return replacement_text if not include_verb else replacement_text + " are"
        else:
            return profile.name if not include_verb else profile.name + " is"

    @staticmethod
    def resolve_content(root, info, profile_id=None, **kwargs):
        profile_pk = BaseMessageObjectType.get_profile_pk(info, profile_id)
        if not profile_pk:
            return None
        if root.deleted:
            if profile_pk == root.profile.pk:
                return "You deleted this message"
            return "This message was deleted"
        if root.message_type == Message.MessageType.USER_MESSAGE:
            return root.content

        extra_data = root.extra_data or {}
        include_verb = extra_data.get("include_verb", False)

        linked_capital_name = BaseMessageObjectType.get_replaced_profile_name(
            root.content_linked_profile_actor, profile_pk, "You", include_verb=include_verb
        )
        replacement = "You" if include_verb else "you"
        linked_small_name = BaseMessageObjectType.get_replaced_profile_name(
            root.content_linked_profile_target, profile_pk, replacement, include_verb=include_verb
        )
        return root.content.format(
            content_linked_profile_actor=linked_capital_name,
            content_linked_profile_target=linked_small_name,
        )

    @staticmethod
    def resolve_is_read(root, info, profile_id=None, **kwargs):
        profile_pk = BaseMessageObjectType.get_profile_pk(info, profile_id)
        if not profile_pk:
            return None

        message_status = root.statuses.filter(profile_id=profile_pk).first()
        return message_status and message_status.is_read


class MessageObjectType(BaseMessageObjectType, DjangoObjectType):
    class Meta(BaseMessageObjectType.Meta):
        pass


class BaseChatRoomObjectType:
    all_messages = DjangoFilterConnectionField(get_object_type_for_model(Message))
    participants = DjangoFilterConnectionField(get_object_type_for_model(ChatRoomParticipant))
    unread_messages = graphene.Field(
        get_object_type_for_model(UnreadMessageCount), profile_id=graphene.ID(required=False)
    )
    image = ThumbnailField(required=False)
    is_archived = graphene.Boolean(profile_id=graphene.ID(required=False))
    other_participant = graphene.Field(get_object_type_for_model(ChatRoomParticipant))
    is_sole_admin = graphene.Boolean()
    participant_ids = graphene.List(graphene.ID)

    @classmethod
    def get_node(cls, info, id):
        try:
            room = cls._meta.model.objects.get(id=id)
            if not info.context.user.has_perm("baseapp_chats.view_chatroom", room):
                return None
            return room

        except cls._meta.model.DoesNotExist:
            return None

    @staticmethod
    def get_other_participant(room, info):
        current_profile = (
            info.context.user.current_profile
            if hasattr(info.context.user, "current_profile")
            else (info.context.user.profile if hasattr(info.context.user, "profile") else None)
        )

        if not current_profile:
            return None

        return room.participants.exclude(profile_id=current_profile.pk).first()

    def resolve_all_messages(self, info, **kwargs):
        if self.is_group:
            profile = (
                info.context.user.current_profile
                if hasattr(info.context.user, "current_profile")
                else (
                    info.context.user.profile.pk if hasattr(info.context.user, "profile") else None
                )
            )
            participant = self.participants.filter(profile=profile).first()
            if participant:
                return self.messages.filter(created__gte=participant.accepted_at).order_by(
                    "-created"
                )
        return self.messages.all().order_by("-created")

    def resolve_participants(self, info, **kwargs):
        if self.is_group:
            profile = (
                info.context.user.current_profile
                if hasattr(info.context.user, "current_profile")
                else (info.context.user.profile if hasattr(info.context.user, "profile") else None)
            )
            participant = self.participants.filter(profile=profile).first()
            if participant:
                return self.participants.all().order_by(
                    Case(When(id=participant.id, then=0), default=1),
                    "-role",
                    "profile__name",
                )
        return self.participants.all()

    def resolve_is_archived(self, info, profile_id=None, **kwargs):
        if profile_id:
            profile_pk = get_pk_from_relay_id(profile_id)
            profile = Profile.objects.get_if_member(pk=profile_pk, user=info.context.user)
            if not profile:
                return None
        else:
            profile_pk = (
                info.context.user.current_profile.pk
                if hasattr(info.context.user, "current_profile")
                and hasattr(info.context.user.current_profile, "pk")
                else (
                    info.context.user.profile.pk
                    if hasattr(info.context.user, "profile")
                    and hasattr(info.context.user.profile, "pk")
                    else None
                )
            )
        return self.participants.filter(profile_id=profile_pk, has_archived_room=True).exists()

    def resolve_unread_messages(self, info, profile_id=None, **kwargs):
        if profile_id:
            profile_pk = get_pk_from_relay_id(profile_id)
            profile = Profile.objects.get_if_member(pk=profile_pk, user=info.context.user)
            if not profile:
                return None

        if hasattr(info.context.user, "current_profile"):
            profile_pk = info.context.user.current_profile.pk
        else:
            return None

        unread_messages = UnreadMessageCount.objects.filter(
            room=self,
            profile_id=profile_pk,
        ).first()

        return unread_messages

    def resolve_other_participant(self, info, **kwargs):
        if self.is_group:
            return None

        return BaseChatRoomObjectType.get_other_participant(self, info)

    def resolve_is_sole_admin(self, info, **kwargs):
        if not self.is_group:
            return False

        current_profile = (
            info.context.user.current_profile
            if hasattr(info.context.user, "current_profile")
            else (info.context.user.profile if hasattr(info.context.user, "profile") else None)
        )

        if not current_profile:
            return False

        current_participant = self.participants.filter(profile_id=current_profile.pk).first()
        if (
            not current_participant
            or current_participant.role != ChatRoomParticipant.ChatRoomParticipantRoles.ADMIN
        ):
            return False

        admin_count = self.participants.filter(
            role=ChatRoomParticipant.ChatRoomParticipantRoles.ADMIN
        ).count()

        return admin_count == 1

    def resolve_title(self, info, **kwargs):
        if self.is_group:
            return self.title

        other_participant = BaseChatRoomObjectType.get_other_participant(self, info)
        if other_participant and other_participant.profile:
            return other_participant.profile.name

    def resolve_image(self, info, **kwargs):
        if self.is_group:
            return self.image

        other_participant = BaseChatRoomObjectType.get_other_participant(self, info)
        if other_participant and other_participant.profile:
            return other_participant.profile.image

    def resolve_participant_ids(self, info, **kwargs):

        profiles = Profile.objects.filter(
            id__in=self.participants.values_list("profile_id", flat=True)
        )
        return [get_obj_relay_id(profile) for profile in profiles]

    class Meta:
        interfaces = (RelayNode,)
        model = ChatRoom
        fields = (
            "id",
            "last_message_time",
            "last_message",
            "participants",
            "participants_count",
            "title",
            "image",
            "is_group",
            "other_participant",
            "is_sole_admin",
            "participant_ids",
        )
        filterset_class = ChatRoomFilter


class ChatRoomObjectType(BaseChatRoomObjectType, DjangoObjectType):
    class Meta(BaseChatRoomObjectType.Meta):
        pass


class BaseUnreadMessageObjectType:
    class Meta:
        interfaces = (RelayNode,)
        model = UnreadMessageCount
        fields = ("count", "marked_unread")


class UnreadMessageObjectType(BaseUnreadMessageObjectType, DjangoObjectType):
    class Meta(BaseUnreadMessageObjectType.Meta):
        pass
