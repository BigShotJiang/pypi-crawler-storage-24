class BlocksQueries:
    pass
