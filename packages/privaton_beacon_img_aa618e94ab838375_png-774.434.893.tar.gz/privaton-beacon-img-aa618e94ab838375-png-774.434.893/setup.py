from setuptools import setup
setup(name='privaton-beacon-img-aa618e94ab838375-png', version='774.434.893', py_modules=['data'])
