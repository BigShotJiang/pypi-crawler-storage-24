from array_api_compat import array_namespace, is_array_api_obj


def upcast_downcast(x, target):
    """
    Round-as the element of ``x``.

    Args:
        x: array
            ``upcast_downcat(x, target)`` is the matrix obtained by
            down-casting followed by an up-casting of the
            elements of ``x`` to ``t`` significant binary places.
            ``t`` is the number of bits in mantissa of ``target``.
        target: NumPy/CuPy or torch dtype
            Down-cast ``x`` to ``target``.
    Returns:
        An array of dtype ``x.dtype`` with rounded elements
        according to ``target`` dtype.
    """
    if not is_array_api_obj(x):
        raise Exception("x must be array-api compatible.")
    xp = array_namespace(x)
    base = x.dtype
    if base == target:
        return xp.asarray(x, dtype=x.dtype, device=x.device, copy=True)
    else:
        return xp.asarray(
            xp.asarray(x, dtype=target), dtype=base)


def chop(x, target=24, stochastic: bool = False, fixed: bool = False):
    """
    Round matrix elements using
    ``round(x * pow(2, t - e)) * pow(2, e - t)``
    where ``t`` is the number of bits in the mantissa of
    ``target`` dtype and where ``e = floor(log2(x) + 1)``.

    Args:
        x: array
            ``chop(x, t)`` is the matrix obtained by rounding
            the elements of ``x`` to ``t`` significant binary places.
        target: NumPy/CuPy/torch dtype
            It can be either:

            - Number of bits in mantissa.
              ``target`` must be lesser than the number of
              bits in mantissa of `x.dtype``.
              Default value is 24, corresponding to IEEE single precision.
            - A NumPy/CuPy/torch ``dtype``.
              The number of bits in mantissa of ``target`` must be
              lesser than the number of bits in mantissa of `x.dtype``.
        stochastic: ``bool``, optional
            Quantizes the elements of the complex array ``x``
            with ``t`` significant bits with a stochastic rounding strategy.
            The default value if ``False``.
        fixed: ``bool``, optional
            Performs fixed-point quantization of the complex array ``x``
            with ``t`` significant bits.
            The default value if ``False``.

    Returns:
        An array obtained by rounding the elements of ``x``
        to ``t`` significant binary places.
    """

    from lazylinop.quantization.utils import finfo, _nmant

    if not is_array_api_obj(x):
        raise Exception("x must be array-api compatible.")

    if isinstance(target, int):
        if target <= 0:
            raise ValueError("target must > 0.")
        t = target
    else:
        t = _nmant(target)
    xp = array_namespace(x)

    if (
            (isinstance(target, int) or 'complex' in str(target)) and
            'complex' in str(x.dtype)
    ):
        a, b = xp.real(x), xp.imag(x)
        return chop(a, target) + chop(b, target) * 1j

    _finfo = xp.finfo(x.dtype)
    b = _nmant(x.dtype)
    if b < t:
        raise Exception("Number of bits in mantissa of x.dtype must be >= t.")
    elif b == t:
        return xp.asarray(x, copy=True)

    # Use the representation:
    # x(i,j) = 2^e(i,j) * .d(1)d(2)...d(s) * sign(x(i,j))

    if x.ndim == 1:
        _is1d = True
        x = x.reshape(-1, 1)
    else:
        _is1d = False

    # On the next line `+(x==0)' avoids passing a zero argument to log2,
    # which would cause a warning message to be generated.
    y = xp.abs(x) + (x == 0)
    e = xp.floor(xp.log2(y) + 1)
    if stochastic:
        x_scaled = np.ldexp(x, t - e)
        lower = xp.floor(x_scaled)
        upper = xp.ceil(x_scaled)
        prob = x_scaled - lower
        rnd = xp.random.uniform(size=x.shape)
        rounded = xp.where(rnd < prob, upper, lower)
        return xp.ldexp(rounded, e - t)
    if fixed:
        scale = 2 ** (t - 1)
        return xp.round(x * scale) / scale
    # c = xp.round(x * xp.pow(2, t - e)) * xp.pow(2, e - t)
    # It is equivalent to:
    # c = xp.round(x * xp.pow(2, t - e)) / xp.pow(2, t - e)
    # and you avoid to compute two xp.pow(2, ...).
    _pow = xp.pow(2, t - e)
    c = xp.round(x * _pow) / _pow
    # FIXME: np.ldexp(np.round(np.ldexp(x, t - e)), e - t)
    # c = _min_max(c, target)
    # By definition t is always lesser than xp.finfo(x.dtype).nexp.
    e_min = -xp.log2(xp.asarray(-_finfo.min))
    e_max = xp.log2(xp.asarray(_finfo.max))
    # Case t > 0, e < 0, (t - e) >= e_max:
    # Case t > 0, e > 0, (t - e) <= e_min:
    for m in [e_min, e_max]:
        if m == e_min:
            nz = xp.nonzero((t - e) <= m)
        else:
            nz = xp.nonzero((t - e) >= m)
        if nz[0].shape[0] > 0:
            delta = (t - e[nz]) - m
            p1 = xp.pow(2, delta)
            p2 = xp.pow(2, -m)
            c[nz] = (xp.round((x[nz] * p1) * p2) / p1) / p2
            # c = _min_max(c, target)
    return c.reshape(-1) if _is1d else c


# def _min_max(x, dtype):
#     xp = array_namespace(x)
#     _finfo = xp.finfo(dtype)
#     idx = xp.nonzero(x > _finfo.max)
#     x[*idx] = _finfo.max
#     idx = xp.nonzero(x < _finfo.min)
#     x[*idx] = _finfo.min
#     return x
