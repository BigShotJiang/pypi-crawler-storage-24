import numpy as np
from array_api_compat import (
    array_namespace, is_numpy_array, is_torch_array)
try:
    from shapely.geometry import LineString
    from shapely.affinity import rotate
    from shapely.ops import polygonize, unary_union
except ModuleNotFoundError:
    raise ModuleNotFoundError(
        "Please install shapely to use complex quantization.")


def relu(x):
    return x * (x > 0)


def _c(x, y, x_hat, y_hat, rerr: bool = False):
    r"""
    Computes $||xy^H-\hat{x}\hat{y}^H||_F^2$.

    Args:
        x: ``np.ndarray``
            Left vector of shape ``(m, 1)``.
        y: ``np.ndarray``
            Right vector of shape ``(m, 1)``.
        x_hat: ``np.ndarray``
            Quantized left batch of vectors of shape ``(m, batch)``.
        y_hat: ``np.ndarray``
            Quantized right batch of vectors of shape ``(n, batch)``.

    Returns:
        Batch of $||xy^H-\hat{x}\hat{y}^H||_F^2$ or
        $||xy^H-\hat{x}\hat{y}^H||_F/||xy^H||_F$
        depending on ``rerr`` argument.
    """
    assert x.shape[1] == 1 and y.shape[1] == 1
    assert x_hat.shape[0] == x.shape[0] and y_hat.shape[0] == y.shape[0]
    assert x_hat.ndim == 2 and y_hat.ndim == 2
    xp = array_namespace(x)
    err = relu(
        (xp.linalg.norm(x) * xp.linalg.norm(y)) ** 2 +
        (xp.linalg.norm(x_hat, axis=0) * xp.linalg.norm(y_hat, axis=0)) ** 2 -
        2 * xp.real((x.reshape(1, -1) @ xp.conj(x_hat)) *
                    (xp.conj(y).reshape(1, -1) @ y_hat))
    )
    if rerr:
        return xp.sqrt(err) / (xp.linalg.norm(x) * xp.linalg.norm(y))
    else:
        return err


def _generate_midpoints(t, e_max, e_min):
    r"""
    Generate the midpoints values $\mathbb{M}_t^*$ used for the quantization,
    restricted to ``e_min <= e <= e_max`` for tractability.

    Args:
        t: Number of bits for quantization.
            int
        e_max: Maximum value of e for tractability.
            int
        e_min: Minimum value of e for tractability.
            int
    """
    # betas = []
    # for k in range(2**(t - 1), 2**t):
    #     for e in range(e_min, e_max + 1):
    #         beta = (k + 1 / 2) * 2**(e - t)
    #         betas.append(beta)
    betas = [
        (k + 0.5) * 2 ** (e - t) for k in range(
            2 ** (t - 1), 2 ** t) for e in range(e_min, e_max + 1)]

    return betas


def _generate_directions(x):
    r"""
    Generates the set
    $\mathbb{C}_x:=\{i^lx_j,l\in\{0, 1\},j=1,\cdots,m,x_j\neq 0\}$.

    Args:
        x: 1d array
            Input vector.

    Returns:
        List of directions of $x$.
    """
    xp = array_namespace(x)
    assert x.ndim == 1 or (x.ndim == 2 and x.shape[1] == 1)
    xnz = x[x != 0]
    return xp.concat(((1j) ** 0 * xnz, (1j) ** 1 * xnz), axis=0)


def _normalize_direction_set(direction_set):
    """
    Normalize the given set of directions.

    Args:
        direction_set: array of complex numbers
            The set of directions to normalize.

    Returns:
        List of normalized complex numbers.
    """
    xp = array_namespace(direction_set)
    return direction_set / (
        2 ** xp.floor(xp.log2(xp.abs(direction_set))))


def _from_direction_midpoints_to_breaklines(direction_set, midpoint_set):
    r"""
    Returns the list of breaklines from the sets
    $\mathbb{C}_x$ and $\mathbb{M}_t^*$.

    Each breakline of equation $Re(\lambda z)=\beta$ corresponds
    to the line $\Re(\lambda)=\beta/\lvert z\rvert$
    after a rotation of $\arg(z)$.

    Each list is associated to one accumulation line.

    Args:
        direction_set: ``list[complex]``
            List of directions of $x$.
        midpoint_set: ``list[float]``
            List of midpoints values.

    Returns:
        list of breaklines.
    """
    all_breaklines = []
    xp = array_namespace(direction_set)
    # FIXME: shapely and torch input.
    if not is_numpy_array(direction_set):
        _direction_set = np.from_dlpack(direction_set)
        xp = np
    else:
        _direction_set = direction_set
    _direction_set = _direction_set[_direction_set != 0]
    # rad2deg if torch.
    angles = xp.degrees(xp.angle(_direction_set))
    y_vals = xp.linspace(-100, 100, 2)
    for z, a in zip(_direction_set, angles):
        breaklines = []
        for beta in midpoint_set:
            for s in [-1, 1]:
                base_line = LineString([(s * beta / xp.abs(z), y_vals[0]),
                                        (s * beta / xp.abs(z), y_vals[1])])
                rotated_line = rotate(base_line, -a, origin=(0, 0))
                breaklines.append(rotated_line)
        all_breaklines.append(breaklines)

    return all_breaklines


def _find_e_min(normalized_direction_set, t, border):
    r"""
    Finds the smallest $e$ such that the set of stable regions is empty.

    Args:
        direction_set: ``list[complex]``
            List of directions of $x$.
        t: ``int``
            Number of bits for quantization.
        border: ``TilingDomain``
            Tiling domain.

    Returns:
        The smallest $e$ value.
    """

    def is_covered(e, normalized_direction_set, t, polygon_border):
        r"""
        Checks if the border is covered by the accumulation polygons
        associated to the directions in normalized_direction_set.

        Args:
            normalized_direction_set: ``list[complex]``
                List of normalized directions of $x$.
            t: ``int``
                Number of bits for quantization.
            border: ``TilingDomain``
                Tiling domain.

        Returns:
            ``True`` if the border is covered, ``False`` otherwise.
        """
        accum_polygons = []
        y_vals = np.linspace(-100, 100, 2)
        base_line = LineString([(0, y_vals[0]), (0, y_vals[1])])
        for z in normalized_direction_set:
            if z == 0:
                continue

            accum_line = rotate(
                base_line, -np.degrees(np.angle(z)), origin=(0, 0))

            beta_min = (2 ** t + 1) * 2 ** (e - t - 1)

            if np.imag(z) == 0:
                dist = beta_min / np.real(z)
            else:
                dist = beta_min * np.sin(np.angle(z)) / np.imag(z)

            accum_polygons.append(accum_line.buffer(dist))

        union_accum_polygons = unary_union(accum_polygons)
        # return union_accum_polygons.covers(polygon_border)
        return polygon_border.difference(union_accum_polygons).is_empty

    xp = array_namespace(normalized_direction_set)
    # FIXME: shapely and torch input.
    if not is_numpy_array(normalized_direction_set):
        _normalized_direction_set = np.from_dlpack(
            normalized_direction_set)
        xp = np
    else:
        _normalized_direction_set = normalized_direction_set

    e = 0

    polygon_border = border.border

    covered = is_covered(
        e, _normalized_direction_set, t, polygon_border)

    direction = 1 - 2 * int(covered)

    while True:
        if covered:
            if direction == 1:
                return e
            e -= 1
        else:
            if direction == -1:
                return e + 1
            e += 1
        covered = is_covered(
            e, _normalized_direction_set, t, polygon_border)


# def _find_e_min(direction_set, t, border):
#     r"""
#     Finds the smallest $e$ such that the set of stable regions is empty.

#     Args:
#         direction_set: ``list[complex]``
#             List of directions of $x$.
#         t: ``int``
#             Number of bits for quantization.
#         border: ``TilingDomain``
#             Tiling domain.

#     Returns:
#         The smallest $e$ value.
#     """
#     e = 0

#     midpoint_set = _generate_midpoints(t, e, e)
#     polygons_stable = _get_polygons(direction_set, midpoint_set, border)
#     if len(polygons_stable) > 0:
#         direction = 1
#     else:
#         direction = -1

#     while True:
#         if len(polygons_stable) > 0:
#             if direction == -1:
#                 return e + 1

#             e += 1
#         else:
#             if direction == 1:
#                 return e

#             e -= 1

#         midpoint_set = _generate_midpoints(t, e, e)
#         polygons_stable = _get_polygons(direction_set, midpoint_set, border)


def _find_e_max(direction_set, t, border):
    r"""
    Finds the largest $e$ such that there exists
    at least one breakline in the border.

    Args:
        direction_set: ``list[complex]``
            List of directions of $x$.
        t: ``int``
            Number of bits for quantization.
        border: ``TilingDomain``
            Tiling domain.

    Returns:
        The largest $e$ value.
    """
    e = 0

    midpoint_set = _generate_midpoints(t, e, e)
    breaklines = _from_direction_midpoints_to_breaklines(
        direction_set, midpoint_set)
    breaklines_in_border = sum(border.filter_all_breaklines(breaklines), [])
    if len(breaklines_in_border) == 0:
        direction = -1
    else:
        direction = 1

    while True:
        if len(breaklines_in_border) == 0:
            if direction == 1:
                return e - 1

            e -= 1

        else:
            if direction == -1:
                return e

            e += 1

        midpoint_set = _generate_midpoints(t, e, e)
        breaklines = _from_direction_midpoints_to_breaklines(
            direction_set, midpoint_set)
        breaklines_in_border = sum(
            border.filter_all_breaklines(breaklines), [])


def _get_polygons(normalized_direction_set, midpoint_set, border):
    r"""
    Return the polygons generated by the breaklines of the function
    $\lambda\mapsto\text{round}\(\lambda x\)$.
    Keeps only the polygons which are in the border and not too
    close to the accumulation lines.
    """
    if len(midpoint_set) == 0:
        return []

    xp = array_namespace(normalized_direction_set)
    # FIXME: shapely and torch input.
    if not is_numpy_array(normalized_direction_set):
        _normalized_direction_set = np.from_dlpack(
            normalized_direction_set)
        xp = np
    else:
        _normalized_direction_set = normalized_direction_set

    all_breaklines = _from_direction_midpoints_to_breaklines(
        normalized_direction_set, midpoint_set)
    # Filter the breaklines to only consider the ones
    # that are inside the border.
    all_breaklines = border.filter_all_breaklines(all_breaklines)

    merged_lines = unary_union(sum(all_breaklines, []) + border.lines_border)
    polygons = np.array(polygonize(merged_lines))
    P = len(polygons)
    cs = np.empty((P, 2), dtype='float64')
    for i, p in enumerate(polygons):
        _x, _y = p.centroid.xy
        cs[i, 0] = _x[0]
        cs[i, 1] = _y[0]

    smallest_beta = min(midpoint_set)

    # Remove the polygons that are too close from the accumulation lines
    y_vals = xp.linspace(-100, 100, 2)
    base_line = LineString([(0, y_vals[0]), (0, y_vals[1])])
    for z in _normalized_direction_set:
        if z == 0:
            continue

        _new = True

        if is_torch_array(z):
            accum_line = rotate(
                base_line, -xp.rad2deg(xp.angle(z)), origin=(0, 0))
        else:
            accum_line = rotate(
                base_line, -xp.degrees(xp.angle(z)), origin=(0, 0))

        if xp.imag(z) == 0:
            dist = smallest_beta / xp.real(z)
            if dist < 0:
                _new = False
        else:
            dist = smallest_beta * xp.sin(xp.angle(z)) / xp.imag(z)

        if not _new:
            accum_polygon = accum_line.buffer(dist)
            _indices = [
                i for i, p in enumerate(
                    polygons) if not accum_polygon.contains(p.centroid)
            ]
        else:
            rect = accum_line.buffer(dist, quad_segs=0, cap_style='flat')
            # Is point M inside the rectangle?
            xx, yy = rect.exterior.coords.xy
            A = np.array([xx[0], yy[0]])
            B = np.array([xx[1], yy[1]])
            D = np.array([xx[3], yy[3]])
            AM = cs - A
            AB = B - A
            AD = D - A
            am_ab = np.dot(AM, AB)
            am_ad = np.dot(AM, AD)
            _indices = np.where(
                np.logical_or(
                    np.logical_or(am_ab < 0, am_ab > np.dot(AB, AB)),
                    np.logical_or(am_ad < 0, am_ad > np.dot(AD, AD)),
                )
            )[0]
        cs = cs[_indices, :]
        polygons = polygons[_indices]

    return polygons


def _get_centroids(normalized_direction_set, midpoint_set, border):
    r"""
    Returns the centroids of the polygons generated by the breaklines
    of the function $\lambda\mapsto round(\lambda x)$.
    The breaklines are generated from the set of directions of
    x all_z and the set of midpoints all_beta.

    Args:
        normalized_direction_set: ``list[complex]``
            List of directions of x.
        midpoint_set: ``list[float]``
            List of midpoints of the form $s(k+0.5)2^{e-t}$.
        border: ``TilingDomain``
            Tiling domain.

    Returns:
        List of centroids of the polygons ``list[complex]``.
    """
    polygons = _get_polygons(normalized_direction_set, midpoint_set, border)

    return [p.centroid.x + 1j * p.centroid.y for p in polygons]


def _get_centroids_accum(normalized_direction_set, t, border):
    r"""
    Returns the centroids on the accumulation lines associated
    to the directions stored in all_z.

    Args:
        normalized_direction_set: ``list[complex]``
            List of directions of $x$.
        t: ``int``
            Number of bits for the quantization.
        border: ``TilingDomain``
            Tiling domain.

    Returns:
        List of centroids on the accumulation lines ``list[complex]``.
    """
    def _get_e_values(z1, z2, im_z1_z2, alpha1, t):
        r"""
        For each couple of directions $\(z1,~z2\)$, one associated to
        the accumulation line of equation $\text{Re}\(\lambda z\)=0$
        and one to generate the breaklines of equation
        $\text{Re}\(\lambda z\)=\beta$, where $\beta=s(k + 0.5)2^{e-t}$,
        find the values of $e$ (for each $k$) for which the breaklines
        intersect the accumulation line inside the border.

        To do so, the element of both lines can be written a
        $\lambda=i\bar{z1}\beta/\text{Im}\(z_1\bar{z_2}\)$.
        The value of $e$ is then obtained by solving for $e$ the equation
        $|lambda|\geq\alpha_1$, where $\alpha_1$ is the distance
        from the origin to the intersection of the accumulation line.

        Args:
            z1: ``complex``
                First direction associated to the accumulation line.
            z2: ``complex``
                Second direction associated to the breaklines.
            im_z1_z2: ``float``
                Imaginary part of ``z1 * conjugate(z2)``.
            alpha1: ``float``
                Distance from the origin to the intersection
                of the accumulation line.
            t: ``int``
                Number of bits for the quantization.

        Returns:
            List of valid $e$ values ``list[int]``.
        """
        xp = array_namespace(z1)

        if im_z1_z2 == 0 or z1 == 0 or z2 == 0:
            return []

        ks = xp.arange(2 ** (t - 1), 2 ** t, 1, device="cpu")
        log_value = xp.log2((xp.abs(im_z1_z2) * alpha1) /
                            (xp.abs(z1) * (ks + 0.5)))
        # e_values = (2 - t - xp.asarray(log_value, dtype=xp.int64)).tolist()
        e_values = (t + xp.asarray(log_value, dtype=xp.int64)).tolist()

        return e_values

    def _unique_sort(arr, rtol=1e-05, atol=1e-08):
        xp = array_namespace(arr[0])
        arr = xp.asarray(arr)
        sorted_arr = arr[xp.argsort(xp.abs(arr))]
        mask = xp.concat(
            (
                [True],
                ~xp.isclose(
                    sorted_arr[1:],
                    sorted_arr[:-1],
                    rtol=rtol,
                    atol=atol,
                ),
            )
        )
        return sorted_arr[mask]
        # xp = array_namespace(arr[0])
        # _arr = xp.asarray(arr)
        # uniques = xp.asarray(
        #     [
        #         x for i, x in enumerate(_arr[:-1]) if not xp.any(
        #             xp.isclose(x, _arr[(i + 1):], rtol=rtol, atol=atol)
        #         )
        #     ]
        # )
        # return uniques[xp.argsort(xp.abs(uniques))]

    all_centroids_accum = []
    xp = array_namespace(normalized_direction_set)
    ts = np.arange(
        2**(t - 1), 2**t, dtype=np.int32, device="cpu")  # _z.device)
    hpi = xp.pi / 2
    _dtype = normalized_direction_set.dtype
    passed_z = None

    y_vals = np.linspace(-100, 100, 2)
    base_line = LineString([(0, y_vals[0]), (0, y_vals[1])])

    # FIXME: shapely and torch.
    if not is_numpy_array(normalized_direction_set):
        _normalized_direction_set = np.from_dlpack(normalized_direction_set)
        xp = np
    else:
        _normalized_direction_set = normalized_direction_set

    for z in _normalized_direction_set:

        if passed_z is not None and xp.isclose(
                xp.angle(z) % hpi, xp.angle(passed_z) % hpi).any():
            continue

        u1, v1 = xp.real(z), xp.imag(z)

        if 'torch' in str(xp.__package__):
            acc_line = rotate(
                base_line, -xp.rad2deg(xp.angle(z)), origin=(0, 0))
        else:
            acc_line = rotate(
                base_line, -xp.degrees(xp.angle(z)), origin=(0, 0))

        breakpoint_border = border.get_breakpoint_accum(acc_line)
        if breakpoint_border is None:
            continue
        breakpoint_border = xp.asarray(
            breakpoint_border,
            dtype=xp.complex128,
        )

        if passed_z is None:
            passed_z = xp.asarray([z], copy=True)
        else:
            passed_z = xp.concat((passed_z, xp.asarray([z], copy=True)))

        alpha = xp.abs(breakpoint_border)
        angle_breakpoint = xp.angle(breakpoint_border) % (2 * xp.pi)

        valid_breakpoint = [
            xp.asarray(
                breakpoint_border,
                dtype=xp.complex128,
            ),
            xp.asarray(
                2 * breakpoint_border,
                dtype=xp.complex128,
            ),
        ]

        for _z in _normalized_direction_set:
            if _z == z:
                continue

            im = xp.imag(z * xp.conj(_z))
            if im == 0:
                continue

            e_values = _get_e_values(z, _z, im, alpha, t)

            for s in [-1, 1]:
                for k, e in zip(ts, e_values):
                    beta = s * (k + 0.5) * 2**(e - t)

                    re_breakpoint = (v1 / im) * beta
                    im_breakpoint = (u1 / im) * beta

                    bp = xp.asarray(
                        re_breakpoint + 1j * im_breakpoint,
                        dtype=xp.complex128,
                    )
                    angle_bp = xp.angle(bp) % (2 * xp.pi)
                    if xp.allclose(angle_bp, angle_breakpoint):
                        valid_breakpoint.append(bp)

        # valid_breakpoint = sorted(
        #     _unique_allclose(valid_breakpoint),
        #     key=abs,
        # )
        valid_breakpoint = _unique_sort(valid_breakpoint)
        centroids_accum = [
            (valid_breakpoint[i] + valid_breakpoint[i + 1]) / 2
            for i in range(len(valid_breakpoint) - 1)
        ]
        all_centroids_accum.append(centroids_accum)

    return sum(all_centroids_accum, [])
