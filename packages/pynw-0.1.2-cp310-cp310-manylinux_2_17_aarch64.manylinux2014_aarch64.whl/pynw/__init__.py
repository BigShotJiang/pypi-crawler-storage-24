"""Rust-accelerated Needleman-Wunsch global sequence alignment."""

from importlib.metadata import version

from pynw._api import needleman_wunsch

__all__ = ["needleman_wunsch"]
__version__ = version("pynw")
