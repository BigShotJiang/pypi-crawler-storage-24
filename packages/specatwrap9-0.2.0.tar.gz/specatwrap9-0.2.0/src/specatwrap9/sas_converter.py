"""
SAS to Parquet converter module.

This module provides functionality to convert large SAS7BDAT files to Parquet format
in a memory-efficient way by processing the data in chunks.
"""

import sys
import time
from pathlib import Path
from typing import Optional
import shutil
import click
import pyreadstat
import polars as pl


def convert_sas_to_parquet(
    input_file: Path,
    output_path: Path,
    chunk_size: int = 100000,
    compression: str = "zstd",
    encoding: Optional[str] = None,
    overwrite: bool = False,
    verbose: bool = False,
):
    """
    Convert a SAS7BDAT file to Parquet format in chunks.

    Parameters
    ----------
    input_file : Path
        Path to the SAS file (.sas7bdat)
    output_path : Path
        Path to output directory for Parquet files
    chunk_size : int, optional
        Number of rows to read per chunk (default: 100000)
    compression : str, optional
        Parquet compression algorithm (default: 'zstd')
    encoding : str, optional
        File encoding (default: auto-detect)
    overwrite : bool, optional
        Whether to overwrite existing output directory (default: False)
    verbose : bool, optional
        Enable verbose output (default: False)

    Raises
    ------
    FileNotFoundError
        If the input file does not exist
    ValueError
        If the input file is not a .sas7bdat file or output path is invalid
    PermissionError
        If there are permission issues with files/directories
    MemoryError
        If there's insufficient memory (suggest smaller chunk_size)
    """
    # Validate input file
    if not input_file.exists():
        click.secho(f"✗ Error: Input file not found: {input_file}", fg="red", err=True)
        sys.exit(1)

    if input_file.suffix.lower() != ".sas7bdat":
        click.secho("✗ Error: Input file must be a .sas7bdat file", fg="red", err=True)
        sys.exit(1)

    # Handle output directory
    output_path = Path(output_path)

    if output_path.exists():
        if not output_path.is_dir():
            click.secho(
                f"✗ Error: Output path exists and is not a directory: {output_path}",
                fg="red",
                err=True,
            )
            sys.exit(1)

        if overwrite:
            if verbose:
                click.echo(f"Removing existing directory: {output_path}")
            shutil.rmtree(output_path)
            output_path.mkdir(parents=True, exist_ok=True)
        else:
            # Check if directory has parquet files
            existing_parquet = list(output_path.glob("*.parquet"))
            if existing_parquet:
                click.secho(
                    f"⚠ Warning: Output directory already contains {len(existing_parquet)} .parquet file(s)",
                    fg="yellow",
                )
                if not click.confirm(
                    "Do you want to continue and potentially mix files?"
                ):
                    click.echo("Aborted.")
                    sys.exit(0)
    else:
        output_path.mkdir(parents=True, exist_ok=True)

    # Display processing information
    click.echo(f"Processing: {input_file}")
    click.echo(f"Output directory: {output_path}")
    if verbose:
        click.echo(f"Chunk size: {chunk_size:,} rows")
        click.echo(f"Compression: {compression}")
        click.echo(f"Encoding: {encoding if encoding else 'auto-detect'}")
    click.echo()

    # Process file in chunks
    click.echo("Converting SAS to Parquet...")

    reader = pyreadstat.read_file_in_chunks(
        pyreadstat.read_sas7bdat,
        str(input_file),
        chunksize=chunk_size,
        encoding=encoding,
        output_format="polars",
    )

    chunk_num = 0
    total_rows = 0
    num_columns = 0

    for df_polars, meta in reader:
        # Start timing for this chunk
        chunk_start_time = time.time()

        # Generate chunk filename with zero-padded numbering
        chunk_filename = f"chunk_{chunk_num:04d}.parquet"
        chunk_path = output_path / chunk_filename

        # Write chunk to parquet
        df_polars.write_parquet(chunk_path, compression=compression)

        # Calculate elapsed time
        chunk_elapsed_time = time.time() - chunk_start_time

        # Update statistics
        chunk_rows = len(df_polars)
        total_rows += chunk_rows
        num_columns = len(meta.column_names)
        chunk_num += 1

        if verbose:
            click.echo(
                f"  Wrote chunk {chunk_num}: {chunk_rows:,} rows → {chunk_filename} (took {chunk_elapsed_time:.2f}s)"
            )
        else:
            click.echo(
                f"  Wrote chunk {chunk_num}: {chunk_rows:,} rows → {chunk_filename} (took {chunk_elapsed_time:.2f}s)"
            )

    # Calculate file sizes
    input_size = input_file.stat().st_size / (1024 * 1024)  # MB
    output_files = list(output_path.glob("*.parquet"))
    output_size = sum(f.stat().st_size for f in output_files) / (1024 * 1024)  # MB
    compression_ratio = input_size / output_size if output_size > 0 else 0

    # Display success message
    click.echo()
    click.secho("✓ Conversion completed successfully!", fg="green", bold=True)
    click.echo(f"Input file:      {input_size:.2f} MB ({input_file.name})")
    click.echo(f"Output files:    {output_size:.2f} MB ({len(output_files)} chunks)")
    click.echo(f"Compression:     {compression_ratio:.2f}x")
    click.echo(f"Total rows:      {total_rows:,}")
    click.echo(f"Columns:         {num_columns}")
    click.echo(f"Chunk size:      {chunk_size:,} rows/chunk")
    click.echo()
    click.echo("To read the data:")
    click.echo(f"  import polars as pl")
    click.echo(f"  df = pl.read_parquet('{output_path}/*.parquet')")
