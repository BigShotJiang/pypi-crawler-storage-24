"""
Prep command group for preprocessing healthcare data files.

This module provides commands for filtering and preprocessing parquet files
before converting them to XES format.
"""

import click
from pathlib import Path
import sys

from .io_handler import process_parquet_files


@click.group()
def prep():
    """
    Preprocess and filter healthcare data files.

    Commands in this group help prepare raw data files by filtering,
    cleaning, and transforming them before further processing.
    """
    pass


@prep.command()
@click.option(
    "-i",
    "--input",
    "input_dir",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=Path),
    required=True,
    help="Path to directory containing parquet files to process.",
)
@click.option(
    "-o",
    "--output",
    "output_file",
    type=click.Path(dir_okay=False, file_okay=True, path_type=Path),
    required=True,
    help="Path to output parquet file.",
)
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose output.")
def diagnosis(input_dir, output_file, verbose):
    """
    Filter and preprocess diagnosis parquet files.

    This command lazily reads all parquet files from a directory, applies
    filtering and preprocessing transformations, and writes the results to
    a single output parquet file.

    INPUT: Directory path containing parquet files to process.

    OUTPUT: Path to output parquet file for processed data.

    Example usage:

        specatwrap prep diagnosis -i ./data/parquet_files/ -o ./processed/diagnosis.parquet

        specatwrap prep diagnosis --input ./raw_data/ --output ./clean_data.parquet -v
    """
    try:
        # Display processing information
        click.echo(f"Input directory: {input_dir}")
        click.echo(f"Output file: {output_file}")
        click.echo()

        # Find all parquet files in input directory (for verbose output)
        if verbose:
            parquet_pattern = str(input_dir / "*.parquet")
            click.echo(f"Searching for parquet files: {parquet_pattern}")
            parquet_files = list(input_dir.glob("*.parquet"))
            if parquet_files:
                click.echo(f"Found {len(parquet_files)} parquet file(s):")
                for f in parquet_files:
                    click.echo(f"  - {f.name}")
                click.echo()

        # Process the parquet files using the io_handler
        click.echo("Loading and applying filters...")
        with click.progressbar(
            length=100, label="Processing", show_eta=False, show_percent=True
        ) as bar:
            # Call the generic I/O handler with "diagnosis" filter type
            process_parquet_files(
                input_dir=input_dir,
                output_file=output_file,
                filter_type="diagnosis",
                verbose=verbose,
            )
            bar.update(100)

        # Display success message
        click.secho("✓ Processing completed successfully!", fg="green", bold=True)
        click.echo(f"Output file: {output_file}")

        # Display file statistics
        if output_file.exists():
            size_mb = output_file.stat().st_size / (1024 * 1024)
            click.echo(f"File size: {size_mb:.2f} MB")

    except FileNotFoundError as e:
        click.secho(f"✗ Error: File or directory not found - {e}", fg="red", err=True)
        sys.exit(1)
    except PermissionError as e:
        click.secho(f"✗ Error: Permission denied - {e}", fg="red", err=True)
        sys.exit(1)
    except ValueError as e:
        click.secho(f"✗ Error: Invalid input - {e}", fg="red", err=True)
        sys.exit(1)
    except MemoryError:
        click.secho(
            "✗ Error: Out of memory. Try processing smaller batches.",
            fg="red",
            err=True,
        )
        sys.exit(1)
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg="red", err=True)
        if verbose:
            import traceback

            traceback.print_exc()
        sys.exit(1)
