<div align="center">

# 🚀 Chahuadev Hub

**The official app launcher and distribution hub by Chahuadev.**

Download and manage all Chahuadev apps in one place — including **Chahuadev Framework**, **Emoji Cleaner**, and **Junk Sweeper**.

<p align="center">
  <img src="https://huggingface.co/datasets/chahuadev/chahuadev-framework-binaries/resolve/main/chahuadev_hub.png" width="700" alt="Chahuadev Hub — App Launcher">
</p>

<p align="center">
  <a href="https://huggingface.co/chahuadev"><img src="https://img.shields.io/badge/%20HuggingFace-chahuadev-yellow?style=for-the-badge" alt="HuggingFace"></a>
  <a href="https://pypi.org/project/chahuadev-hub/"><img src="https://img.shields.io/pypi/v/chahuadev-hub?style=for-the-badge&logo=pypi&logoColor=white&color=blue" alt="PyPI"></a>
  <img src="https://img.shields.io/badge/Python-%E2%89%A53.9-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python 3.9+">
  <img src="https://img.shields.io/badge/Platform-Windows%20%7C%20Linux-0078D4?style=for-the-badge" alt="Cross-Platform">
  <img src="https://img.shields.io/badge/License-MIT-green?style=for-the-badge" alt="MIT License">
</p>

</div>

---

## 📦 Installation

Make sure you have Python installed, then run the following command in your terminal:

```bash
pip install chahuadev-hub
```

> **If `pip` is not recognized**, use this instead (works on all systems):
> ```bash
> python -m pip install chahuadev-hub
> ```

To update the Hub to the latest version:

```bash
pip install --upgrade chahuadev-hub
```

> **If `pip` is not recognized** when updating:
> ```bash
> python -m pip install --upgrade chahuadev-hub
> ```

## 🎮 Usage

You can launch the Chahuadev Hub GUI using either of the following methods:

### Method 1: Direct Command (Recommended)

Simply type this in your terminal and press Enter:

```bash
chahuadev-hub
```

### Method 2: Python Module Command (Works on all systems)

If the direct command doesn't work — common on Windows when Python's Scripts folder is not in PATH — use this instead:

```bash
python -m chahuadev_hub
```

> **Note:** A sleek, dark-mode GUI window will appear, automatically fetching the latest tools ready for you to download!

## ✨ Features

- 🌐 **Cloud Sync:** Fetches the latest app list directly from the Chahuadev Hugging Face repository.
- ⬇️ **Smart Download:** Real-time progress bar with file size and integrity verification.
- 🪟🐧 **Cross-Platform:** Beautiful UI that works seamlessly on both Windows and Linux.
- 🔍 **Filtering:** Easily sort and filter available apps by platform (Windows `.exe` / Linux `.AppImage`).

## 🔗 Links

- Developer: [Chahuadev on Hugging Face](https://huggingface.co/chahuadev)
