from chahuadev_hub.main import run_hub

run_hub()
