import customtkinter as ctk
import threading
import urllib.parse
import requests
import json
import os
import time

# ── CONFIG ──────────────────────────────────────────────────────────────────
HF_REPO     = "chahuadev/chahuadev-framework-binaries"
HF_API_URL  = f"https://huggingface.co/api/datasets/{HF_REPO}/tree/main"
HF_CDN_BASE = f"https://huggingface.co/datasets/{HF_REPO}/resolve/main"
DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "Downloads", "ChahuadevHub")

# ── SKIP non-app files ───────────────────────────────────────────────────────
SKIP_FILES = {".gitattributes", "README.md", "chahuadev-framework-binaries.png",
              "emoji-cleaner-app.png"}

# ── APP METADATA (name, icon, description) derived from filename ─────────────
APP_META = {
    "Chahuadev Framework": {
        "icon": "⚙️",
        "desc": "Full-stack development framework by Chahuadev",
    },
    "Emoji Cleaner": {
        "icon": "🌐",
        "desc": "Strip & sanitize emoji from any file type",
    },
    "Junk Sweeper": {
        "icon": "🧹",
        "desc": "Detect and remove junk/temp files automatically",
    },
}

def format_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"

def guess_app_name(path):
    name = path.replace("-win-ia32.exe", "").replace("-win-x64.exe", "")
    name = name.replace("-1.0.0.AppImage", "").replace(".AppImage", "").replace(".exe", "")
    name = name.replace("-", " ").strip()
    return name

def guess_platform(path):
    p = path.lower()
    if "ia32" in p:
        return "Windows  32-bit", "#3b82f6"
    if "x64" in p or ".exe" in p:
        return "Windows  64-bit", "#6366f1"
    if ".appimage" in p:
        return "Linux  AppImage", "#f59e0b"
    return "Unknown", "#6b7280"

# ── THEME ────────────────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

CARD_BG     = "#1a1a2e"
ACCENT      = "#0d6efd"
SUCCESS     = "#10b981"
SIDEBAR_BG  = "#0f0f1a"
HEADER_BG   = "#12122a"


# ════════════════════════════════════════════════════════════════════════════
class AppCard(ctk.CTkFrame):
    """Single file download card."""

    def __init__(self, master, file_info: dict, download_dir: str, status_cb):
        super().__init__(master, fg_color=CARD_BG, corner_radius=10)

        self.file_info    = file_info
        self.download_dir = download_dir
        self.status_cb    = status_cb
        self._thread      = None

        path   = file_info["path"]
        size   = file_info.get("size", 0)
        app_name = guess_app_name(path)
        meta   = APP_META.get(app_name, {"icon": "📦", "desc": path})
        plat, plat_color = guess_platform(path)

        self.columnconfigure(1, weight=1)

        # Icon
        icon_lbl = ctk.CTkLabel(self, text=meta["icon"], font=ctk.CTkFont(size=32))
        icon_lbl.grid(row=0, column=0, rowspan=2, padx=(16, 10), pady=16)

        # App name
        name_lbl = ctk.CTkLabel(self, text=app_name,
                                 font=ctk.CTkFont(size=15, weight="bold"),
                                 anchor="w")
        name_lbl.grid(row=0, column=1, sticky="sw", padx=4, pady=(14, 0))

        # Description + size
        desc_lbl = ctk.CTkLabel(self,
                                 text=f"{meta['desc']}   •   {format_size(size)}",
                                 font=ctk.CTkFont(size=11),
                                 text_color="#9ca3af", anchor="w")
        desc_lbl.grid(row=1, column=1, sticky="nw", padx=4, pady=(0, 14))

        # Platform badge
        badge = ctk.CTkLabel(self, text=plat, fg_color=plat_color,
                              corner_radius=6, font=ctk.CTkFont(size=10, weight="bold"),
                              padx=8, pady=2)
        badge.grid(row=0, column=2, padx=8, pady=(14, 0), sticky="e")

        # Filename label (small)
        fn_lbl = ctk.CTkLabel(self, text=path, font=ctk.CTkFont(size=10),
                               text_color="#6b7280", anchor="e")
        fn_lbl.grid(row=1, column=2, padx=8, pady=(0, 14), sticky="e")

        # Download button
        self.btn = ctk.CTkButton(self, text="⬇  Download", width=130,
                                  command=self._start_download)
        self.btn.grid(row=0, column=3, rowspan=2, padx=16, pady=16)

        # Progress bar (hidden initially)
        self.pbar = ctk.CTkProgressBar(self, width=130)
        self.pbar.set(0)

        # Percent label
        self.pct_lbl = ctk.CTkLabel(self, text="", font=ctk.CTkFont(size=10),
                                     text_color="#9ca3af")

    # ── download logic ────────────────────────────────────────────────────────
    def _start_download(self):
        if self._thread and self._thread.is_alive():
            return
        os.makedirs(self.download_dir, exist_ok=True)
        self.btn.configure(state="disabled", text="Connecting…")
        self.pbar.grid(row=2, column=0, columnspan=4, padx=16, pady=(0, 4), sticky="ew")
        self.pct_lbl.grid(row=3, column=0, columnspan=4, padx=16, pady=(0, 10), sticky="e")
        self._thread = threading.Thread(target=self._download_task, daemon=True)
        self._thread.start()

    def _download_task(self):
        path       = self.file_info["path"]
        total      = self.file_info.get("size", 0)
        url        = f"{HF_CDN_BASE}/{urllib.parse.quote(path)}"
        dest       = os.path.join(self.download_dir, path)
        chunk_size = 65536  # 64 KB

        try:
            self.btn.configure(text="Connecting…")
            with requests.get(url, stream=True, timeout=30) as resp:
                resp.raise_for_status()
                downloaded = 0
                self.btn.configure(text="Downloading…")
                with open(dest, "wb") as fh:
                    for chunk in resp.iter_content(chunk_size=chunk_size):
                        if chunk:
                            fh.write(chunk)
                            downloaded += len(chunk)
                            if total > 0:
                                pct = downloaded / total
                                self.pbar.set(pct)
                                self.pct_lbl.configure(
                                    text=f"{format_size(downloaded)} / {format_size(total)}  ({pct*100:.0f}%)"
                                )

            # ── Verify size ───────────────────────────────────────────────────
            if total > 0 and downloaded != total:
                raise IOError(
                    f"Incomplete download: got {format_size(downloaded)}, expected {format_size(total)}"
                )

            # ── Done ─────────────────────────────────────────────────────────
            self.btn.configure(text="✓  Done", fg_color=SUCCESS, state="normal")
            self.pbar.set(1)
            self.pct_lbl.configure(text=f"Saved → {dest}")
            self.status_cb(f"✓ Downloaded: {path}")

        except Exception as exc:
            self.btn.configure(text="⚠  Retry", state="normal", fg_color="#ef4444")
            self.pct_lbl.configure(text=f"Error: {exc}")
            self.status_cb(f"✗ Failed: {path} — {exc}")
            # Remove incomplete file if it exists
            if os.path.exists(dest):
                try:
                    os.remove(dest)
                except OSError:
                    pass


# ════════════════════════════════════════════════════════════════════════════
class ChahuadevHub(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title("Chahuadev Hub")
        self.geometry("1020x680")
        self.minsize(860, 560)
        self._filter = "All"
        self._cards  = []

        self._build_layout()
        threading.Thread(target=self._fetch_files, daemon=True).start()

    # ── Layout ───────────────────────────────────────────────────────────────
    def _build_layout(self):
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)
        self.grid_columnconfigure(1, weight=1)

        # ── Sidebar ──────────────────────────────────────────────────────────
        self.sidebar = ctk.CTkFrame(self, width=210, corner_radius=0,
                                     fg_color=SIDEBAR_BG)
        self.sidebar.grid(row=0, column=0, rowspan=2, sticky="nsew")
        self.sidebar.grid_propagate(False)
        self.sidebar.grid_rowconfigure(10, weight=1)

        logo = ctk.CTkLabel(self.sidebar, text="CHAHUADEV\nHUB",
                             font=ctk.CTkFont(size=22, weight="bold"),
                             text_color="#7c3aed")
        logo.grid(row=0, column=0, padx=20, pady=(24, 8))

        sub = ctk.CTkLabel(self.sidebar, text="Official App Distribution",
                            font=ctk.CTkFont(size=10), text_color="#6b7280")
        sub.grid(row=1, column=0, padx=20, pady=(0, 24))

        ctk.CTkLabel(self.sidebar, text="FILTER BY PLATFORM",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color="#4b5563").grid(row=2, column=0, padx=20, sticky="w")

        self._filter_btns = {}
        for i, (label, key) in enumerate([
            ("  All Files", "All"),
            ("  Windows", "Windows"),
            ("  Linux", "Linux"),
        ], start=3):
            btn = ctk.CTkButton(
                self.sidebar, text=label, anchor="w",
                fg_color=ACCENT if key == "All" else "transparent",
                hover_color="#1d4ed8",
                command=lambda k=key: self._set_filter(k),
            )
            btn.grid(row=i, column=0, padx=12, pady=4, sticky="ew")
            self._filter_btns[key] = btn

        # Download folder button
        ctk.CTkButton(
            self.sidebar, text="📂  Open Downloads",
            fg_color="transparent", hover_color="#1f2937",
            command=self._open_download_dir,
        ).grid(row=10, column=0, padx=12, pady=(0, 8), sticky="ew")

        ctk.CTkButton(
            self.sidebar, text="🔄  Refresh",
            fg_color="transparent", hover_color="#1f2937",
            command=self._refresh,
        ).grid(row=11, column=0, padx=12, pady=(0, 24), sticky="ew")

        # ── Main area ────────────────────────────────────────────────────────
        main = ctk.CTkFrame(self, fg_color=HEADER_BG, corner_radius=0)
        main.grid(row=0, column=1, sticky="nsew")
        main.grid_rowconfigure(1, weight=1)
        main.grid_columnconfigure(0, weight=1)

        # Header bar
        hdr = ctk.CTkFrame(main, fg_color="#0a0a1a", corner_radius=0, height=64)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_columnconfigure(0, weight=1)
        hdr.grid_propagate(False)

        self.hdr_title = ctk.CTkLabel(
            hdr, text="Available Downloads",
            font=ctk.CTkFont(size=18, weight="bold"), anchor="w"
        )
        self.hdr_title.grid(row=0, column=0, padx=24, pady=18, sticky="w")

        self.hdr_count = ctk.CTkLabel(
            hdr, text="Loading…", font=ctk.CTkFont(size=12),
            text_color="#6b7280", anchor="e"
        )
        self.hdr_count.grid(row=0, column=1, padx=24, pady=18, sticky="e")

        # Scrollable card list
        self.scroll = ctk.CTkScrollableFrame(main, fg_color=HEADER_BG, corner_radius=0)
        self.scroll.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        self.scroll.grid_columnconfigure(0, weight=1)

        # Loading spinner label (replaced by cards once loaded)
        self.loading_lbl = ctk.CTkLabel(
            self.scroll, text="⏳  Fetching file list from Hugging Face…",
            font=ctk.CTkFont(size=14), text_color="#6b7280"
        )
        self.loading_lbl.grid(row=0, column=0, pady=60)

        # ── Status bar ───────────────────────────────────────────────────────
        self.statusbar = ctk.CTkLabel(
            self, text=f"Download folder: {DOWNLOAD_DIR}",
            font=ctk.CTkFont(size=10), text_color="#4b5563",
            fg_color="#09090f", anchor="w", corner_radius=0
        )
        self.statusbar.grid(row=1, column=1, sticky="ew", padx=12, pady=4)

    # ── API fetch ─────────────────────────────────────────────────────────────
    def _fetch_files(self):
        try:
            resp  = requests.get(HF_API_URL, timeout=15)
            resp.raise_for_status()
            files = resp.json()
            # Keep only "blob" type (actual files) and skip metadata files
            blobs = [f for f in files
                     if f.get("type") == "file" and f["path"] not in SKIP_FILES]
            self.after(0, self._populate_cards, blobs)
        except Exception as exc:
            self.after(0, self._show_error, str(exc))

    def _populate_cards(self, files: list):
        self.loading_lbl.destroy()
        self._all_files = files
        self._render_cards(files)

    def _render_cards(self, files: list):
        for card in self._cards:
            card.destroy()
        self._cards.clear()

        for i, f in enumerate(files):
            card = AppCard(self.scroll, f, DOWNLOAD_DIR, self._set_status)
            card.grid(row=i, column=0, padx=20, pady=8, sticky="ew")
            self._cards.append(card)

        count = len(files)
        self.hdr_count.configure(text=f"{count} file{'s' if count != 1 else ''} available")
        self._set_status(f"Loaded {count} files from huggingface.co/{HF_REPO}")

    def _show_error(self, msg: str):
        self.loading_lbl.configure(
            text=f"⚠  Failed to connect to Hugging Face\n{msg}",
            text_color="#ef4444"
        )
        self._set_status(f"✗ Error: {msg}")

    # ── Filter ────────────────────────────────────────────────────────────────
    def _set_filter(self, key: str):
        self._filter = key
        for k, btn in self._filter_btns.items():
            btn.configure(fg_color=ACCENT if k == key else "transparent")

        if not hasattr(self, "_all_files"):
            return

        if key == "All":
            filtered = self._all_files
        elif key == "Windows":
            filtered = [f for f in self._all_files if ".exe" in f["path"].lower()]
        else:  # Linux
            filtered = [f for f in self._all_files if ".appimage" in f["path"].lower()]

        self._render_cards(filtered)

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _set_status(self, msg: str):
        self.statusbar.configure(text=f"  {msg}")

    def _open_download_dir(self):
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        os.startfile(DOWNLOAD_DIR)          # Windows only; harmless on error

    def _refresh(self):
        self._cards_clear()
        self.loading_lbl = ctk.CTkLabel(
            self.scroll, text="⏳  Refreshing…",
            font=ctk.CTkFont(size=14), text_color="#6b7280"
        )
        self.loading_lbl.grid(row=0, column=0, pady=60)
        self.hdr_count.configure(text="Loading…")
        threading.Thread(target=self._fetch_files, daemon=True).start()

    def _cards_clear(self):
        for card in self._cards:
            card.destroy()
        self._cards.clear()


# ════════════════════════════════════════════════════════════════════════════
def run_hub():
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    app = ChahuadevHub()
    app.mainloop()

if __name__ == "__main__":
    run_hub()
