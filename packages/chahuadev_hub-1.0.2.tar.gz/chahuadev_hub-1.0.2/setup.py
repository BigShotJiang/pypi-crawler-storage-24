from setuptools import setup, find_packages

setup(
    name="chahuadev-hub",
    version="1.0.2",
    author="Chahuadev",
    description="The official app launcher and distribution hub by Chahuadev.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://huggingface.co/chahuadev",
    packages=find_packages(),
    install_requires=[
        "customtkinter",
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "chahuadev-hub=chahuadev_hub.main:run_hub",
        ]
    },
    python_requires=">=3.9",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
