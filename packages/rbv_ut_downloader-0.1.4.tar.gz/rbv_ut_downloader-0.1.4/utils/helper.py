import os
import re
import shutil
from pathlib import Path
from typing import Optional, List


def clear_screen():
    """Clear the terminal screen"""
    os.system("cls" if os.name == "nt" else "clear")

def format_login_id(input_val):
    """Automatically append @ecampus if user enters only NIM"""
    input_val = input_val.strip()
    if "@" not in input_val:
        return f"{input_val}@ecampus.ut.ac.id"
    return input_val

def prepare_directories(folder_name: str, temp_suffix: Optional[str] = None):
    """Create output and temp folders, and clean old temp data if it exists"""
    sanitized = sanitize_filename(folder_name)
    base_dir = Path("output") / sanitized
    
    # temp_suffix helps differentiating temp folders if folder_name is shared
    temp_id = temp_suffix if temp_suffix else sanitized
    temp_dir = Path(f"temp_{temp_id}")

    if temp_dir.exists():
        # We no longer delete the temp folder to support resuming.
        # It will be cleaned up by PDFProcessor.cleanup() only after successful compilation.
        pass

    base_dir.mkdir(parents=True, exist_ok=True)
    temp_dir.mkdir(parents=True, exist_ok=True)

    return str(base_dir), str(temp_dir)


def ensure_dir(path: str):
    Path(path).mkdir(parents=True, exist_ok=True)


def sanitize_filename(text: str):
    """
    Removes illegal characters from file names.
    """
    return re.sub(r'[\\/*?:"<>|]', "", text)


def collect_images(folder: str) -> List[str]:
    """
    Take all jpgs from the folder and sort them.
    """
    if not os.path.exists(folder):
        return []

    files = [
        os.path.join(folder, f)
        for f in os.listdir(folder)
        if f.lower().endswith(".jpg")
    ]

    return sorted(files)


def collect_images_recursive(root_folder: str) -> List[str]:
    """
    Extract all images from subfolders.
    Useful for compiling a full PDF book.
    """
    all_images: List[str] = []

    for root, _, files in os.walk(root_folder):
        for f in files:
            if f.lower().endswith(".jpg"):
                all_images.append(os.path.join(root, f))

    return sorted(all_images)