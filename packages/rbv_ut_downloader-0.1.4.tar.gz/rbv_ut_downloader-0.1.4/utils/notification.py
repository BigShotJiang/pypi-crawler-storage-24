from plyer import notification  # type: ignore
import os

def send_notification(title, message, app_name="RBV Downloader"):
    """
    Sends a cross-platform desktop notification using plyer.
    Icon is set if available.
    """
    try:
        # Simple cross-platform notification
        notification.notify(
            title=title,
            message=message,
            app_name=app_name,
            timeout=10 # seconds
        )
    except Exception as e:
        print(f"Failed to send notification: {e}")
