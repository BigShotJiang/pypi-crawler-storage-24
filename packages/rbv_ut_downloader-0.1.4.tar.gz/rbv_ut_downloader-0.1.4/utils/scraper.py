"""
utils/scraper.py — Provider-delegating scraper
No more Playwright here. Parsing logic is handled by respective providers.
"""
import aiohttp
from utils.logger import Logger as log
from providers.base import BaseProvider


class RBVScraper:
    def __init__(self, cookies: dict, provider: BaseProvider):
        self.cookies = cookies
        self.provider = provider

    async def fetch_chapters(self, kode_mk: str) -> list[dict]:
        """
        Fetch the chapter list via the active provider.
        The provider handles all HTTP requests and HTML parsing.
        """
        log.log(f"Scraping chapter list for module: {kode_mk}...", "info")

        # Explicitly build headers here rather than using cookiejar
        cookie_header = "; ".join([f"{k}={v}" for k, v in self.cookies.items() if k and v])
        
        jar = aiohttp.CookieJar(unsafe=True)
        # Populate initial jar
        for k, v in self.cookies.items():
            jar.update_cookies({k: v})

        async with aiohttp.ClientSession(
            cookie_jar=jar,
            timeout=aiohttp.ClientTimeout(total=45),
        ) as session:
            # Force headers to be sent manually just in case
            session._default_headers['Cookie'] = cookie_header
            chapters = await self.provider.fetch_chapters(session, kode_mk)
            
            # Extract any newly set cookies (from redirects like 307)
            from utils.config import save_config
            new_cookies = {}
            for cookie in jar:
                new_cookies[cookie.key] = cookie.value
            
            if new_cookies:
                self.cookies.update(new_cookies)
                save_config(self.cookies)

        if chapters:
            log.log(f"Total {len(chapters)} chapters found.", "success")
        else:
            log.log("No chapters found. Please check the course code or session.", "error")

        return chapters