"""
utils/config.py — Session-based config (replaces direct password storage)
Stores session cookies instead of plaintext passwords.
"""
import json
import os

CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".rbv_config.json")


def load_config() -> dict:
    """Load config from disk. Returns empty dict if not found."""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_config(cookies: dict, extra: dict | None = None):
    """Save session cookies to config. Does not store password."""
    data = load_config()

    data["session_cookies"] = cookies

    # Save extra settings if provided
    if extra:
        data.update(extra)

    # Default settings
    if "concurrency" not in data:
        data["concurrency"] = 10
    if "resolution" not in data:
        data["resolution"] = "800"

    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(data, f, indent=4)
        print(f"[+] Session saved to: {CONFIG_FILE}")
    except Exception as e:
        print(f"[-] Failed to save session: {e}")


def get_session_cookies() -> dict | None:
    """Return saved cookies, or None if not found."""
    data = load_config()
    cookies = data.get("session_cookies")
    if cookies and isinstance(cookies, dict) and len(cookies) > 0:
        return cookies
    return None


def clear_session():
    """Delete saved session (force re-login)."""
    data = load_config()
    data.pop("session_cookies", None)
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(data, f, indent=4)
        print("[*] Session cleared, will log in again.")
    except Exception as e:
        print(f"[-] Failed to clear session: {e}")
