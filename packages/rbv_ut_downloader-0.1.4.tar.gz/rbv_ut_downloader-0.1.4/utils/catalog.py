import json
import os
from pathlib import Path

def get_catalog_data():
    """
    Load the course catalog from catalog.json.
    """
    # Use absolute path relative to this file
    base_dir = Path(__file__).parent.parent
    catalog_path = base_dir / "catalog.json"
    
    if not catalog_path.exists():
        return []
    try:
        with open(catalog_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def get_book_metadata(kode_mk: str):
    """
    Search for book metadata by course code.
    Matches against kode_matkul, cover_image filename, and link_akses.
    """
    data = get_catalog_data()
    target = kode_mk.strip().upper()
    
    for item in data:
        # 1. Direct match in kode_matkul
        if item.get("kode_matkul", "").strip().upper() == target:
            return item
        
        # 2. Match in cover_image filename (e.g. .../DAPU6209.jpg)
        cover_image = item.get("cover_image") or ""
        if target in cover_image.upper():
            return item
            
        # 3. Match in link_akses (e.g. .../dapu6209-studi-...)
        link_akses = item.get("link_akses") or ""
        if target in link_akses.upper():
            return item
            
    return None

def get_book_folder_name(kode_mk: str) -> str:
    """
    Generates a dynamic folder name based on the catalog.
    Format: KODE_MK - TITEL
    """
    meta = get_book_metadata(kode_mk)
    if not meta:
        return kode_mk
    
    judul = meta.get("judul", "").strip()
    if not judul:
        return kode_mk
        
    return f"{kode_mk} - {judul}"
