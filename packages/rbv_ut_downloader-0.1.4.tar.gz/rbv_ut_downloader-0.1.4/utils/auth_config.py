"""
utils/auth_config.py
Management of UT SSO login credentials (Student ID + password).
Stored locally at ~/.rbv_auth.json with permission 600, except for the password which is securely stored in the OS keyring.
"""
import json
import os
import stat
import keyring  # type: ignore
import keyring.errors  # type: ignore

AUTH_FILE = os.path.join(os.path.expanduser("~"), ".rbv_auth.json")
UT_DOMAIN = "@ecampus.ut.ac.id"


def load_auth_config() -> dict:
    """Load credentials from disk. Returns empty dict if not found."""
    if os.path.exists(AUTH_FILE):
        try:
            with open(AUTH_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_auth_config(nim: str, password: str):
    """
    Save Student ID to ~/.rbv_auth.json.
    File is created with permission 600 (owner read/write only).
    The password is saved securely using the OS keyring.
    """
    nim = nim.strip().upper()
    email = nim if nim.endswith(UT_DOMAIN) else f"{nim}{UT_DOMAIN}"

    data = load_auth_config()
    data["nim"] = nim
    data["email"] = email

    # Save password securely via keyring
    try:
        keyring.set_password("rbv-dl", email, password)
    except Exception as e:
        print(f"[-] Failed to save password to keyring: {e}")
        return

    try:
        with open(AUTH_FILE, "w") as f:
            json.dump(data, f, indent=4)
        # Set permission 600 — owner only
        os.chmod(AUTH_FILE, stat.S_IRUSR | stat.S_IWUSR)
        print(f"[+] Credentials saved")
    except Exception as e:
        print(f"[-] Failed to save credentials config: {e}")


def get_credentials() -> tuple[str, str] | tuple[None, None]:
    """
    Return (email, password) if saved, or (None, None) if not.
    Email is already in the format StudentID@ecampus.ut.ac.id.
    """
    data = load_auth_config()
    email = data.get("email")
    if not email:
        return None, None
        
    try:
        password = keyring.get_password("rbv-dl", email)
    except Exception:
        password = None

    if email and password:
        return email, password
    return None, None


def clear_auth_config():
    """Delete saved credentials."""
    data = load_auth_config()
    email = data.get("email")
    if email:
        try:
            keyring.delete_password("rbv-dl", email)
        except keyring.errors.PasswordDeleteError:
            pass  # Password not found in keyring
        except Exception as e:
            print(f"[-] Failed to delete password from keyring: {e}")

    if os.path.exists(AUTH_FILE):
        try:
            os.remove(AUTH_FILE)
            print("[*] Credentials deleted.")
        except Exception as e:
            print(f"[-] Failed to delete credentials: {e}")
    else:
        print("[*] No saved credentials found.")


def has_credentials() -> bool:
    """Check if credentials are saved."""
    email, password = get_credentials()
    return bool(email and password)
