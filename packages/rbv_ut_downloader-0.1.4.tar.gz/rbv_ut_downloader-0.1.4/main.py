"""
main.py — RBV Downloader v0.2.0 (Zero-Browser Engine)
Main orchestrator. Playwright has been completely removed.
"""
import asyncio
import os
from tqdm import tqdm  # type: ignore

from utils import Logger as log, clear_screen, prepare_directories, collect_images_recursive  # type: ignore
from utils.config import get_session_cookies, save_config, load_config  # type: ignore
from utils.auth_config import get_credentials  # type: ignore
from utils.catalog import get_book_metadata, get_book_folder_name  # type: ignore
from core import PDFProcessor, RBVDownloader, ManifestManager  # type: ignore
from core.network import AdaptiveRateLimiter  # type: ignore
from core.auth_bridge import launch_sso_popup  # type: ignore
from providers import get_provider  # type: ignore
from utils.scraper import RBVScraper  # type: ignore
from utils.notification import send_notification  # type: ignore
import cli  # type: ignore


def print_banner():
    clear_screen()
    print("==========================================")
    print("              RBV DOWNLOADER              ")
    print("==========================================")

class RBVEngine:
    def __init__(self):
        self.kode_mk: str = ""
        self.folder_name: str = ""
        self.base_dir: str = ""
        self.temp_dir: str = ""
        self.cookies: dict = {}
        self.chapters: list = []

        cfg = load_config()
        self.concurrency: int = cfg.get("concurrency", 10)
        self.resolution: str = cfg.get("resolution", "800")

    # ------------------------------------------------------------------
    # AUTH
    # ------------------------------------------------------------------

    def _authenticate(self) -> bool:
        """
        Check for a saved session or open the SSO popup.
        Uses saved credentials to auto-fill the Microsoft login.
        Returns True if cookies are successfully obtained.
        """
        # Try saved session first
        saved = get_session_cookies()
        if saved:
            log.log("Saved session found, skipping login popup.", "info")
            self.cookies = saved
            return True

        # Retrieve saved credentials for auto-fill
        credentials = get_credentials()  # (email, password) or (None, None)

        # Open SSO popup — auto-fill if credentials exist
        log.log("Opening SSO login popup...", "info")
        cookies = launch_sso_popup(self.kode_mk, credentials=credentials)

        if not cookies:
            log.log("Login popup closed or timed out. Aborting.", "error")
            return False

        self.cookies = cookies

        # Save cookies for the next session
        save_config(cookies)
        log.log("Session successfully saved.", "success")
        return True

    # ------------------------------------------------------------------
    # DOWNLOAD
    # ------------------------------------------------------------------

    async def _download_chapter(self, session, downloader: RBVDownloader, bab: dict, manifest: ManifestManager):
        """Download a single chapter with concurrent batching and resume support."""
        provider = get_provider()
        doc_id = bab["id"].replace(".pdf", "")
        
        if manifest.is_chapter_completed(doc_id):
            log.log(f"Skipping: {bab['label']} (Already downloaded)", "success")
            return

        subfolder = bab.get("subfolder", f"{self.kode_mk}/")

        log.log(f"Processing: {bab['label']} (ID: {doc_id})", "info")

        chapter_dir = os.path.join(self.temp_dir, doc_id)
        os.makedirs(chapter_dir, exist_ok=True)

        page_num = 1
        total_downloaded = 0
        
        limiter = AdaptiveRateLimiter(initial_concurrency=self.concurrency, max_concurrency=self.concurrency * 2)

        max_successful_page: int = 0
        next_page: int = 1
        max_empty_lookahead: int = max(10, self.concurrency)
        
        pending_tasks: set = set()

        async def fetch_page(p):
            page_url = provider.get_page_url(doc_id, subfolder, p, self.resolution)
            filename = os.path.join(chapter_dir, f"page_{p:03d}.jpg")
            ok = await downloader.download_page(session, page_url, filename, limiter=limiter)
            return p, ok

        with tqdm(desc=f"  {doc_id}", unit=" pg", leave=True) as pbar:
            limiter.pbar = pbar
            while True:
                target_lookahead = max_successful_page + max_empty_lookahead  # type: ignore
                
                while next_page <= target_lookahead and len(pending_tasks) < limiter.max_concurrency * 2:  # type: ignore
                    task = asyncio.create_task(fetch_page(next_page))
                    pending_tasks.add(task)
                    next_page += 1  # type: ignore
                    
                if not pending_tasks:
                    break
                    
                done, pending = await asyncio.wait(pending_tasks, return_when=asyncio.FIRST_COMPLETED)  # type: ignore
                pending_tasks = pending  # type: ignore
                
                for task in done:
                    try:
                        p, ok = task.result()
                        if ok:
                            total_downloaded += 1  # type: ignore
                            pbar.update(1)
                            if p > max_successful_page:
                                max_successful_page = p
                    except Exception as e:
                        pbar.write(f"[!] Error on page {p}: {str(e)}")
                        
                latency = getattr(limiter, 'last_latency', 0.0)
                pbar.set_postfix_str(f"Worker: {limiter.concurrency} | Latency: {latency:.1f}s")


            for task in pending_tasks:
                task.cancel()

        # Mark as completed in manifest
        manifest.mark_chapter_completed(doc_id)

    # ------------------------------------------------------------------
    # MAIN FLOW
    # ------------------------------------------------------------------

    async def start(self):
        print_banner()

        # 1. Input
        res = cli.get_user_input()
        kode_mks: list[str] = res[0]
        _force_relogin: bool = res[1]
        
        total = len(kode_mks)
        for idx, kode_mk in enumerate(kode_mks):
            log.log(f"=== STARTING: {kode_mk} ({idx+1}/{total}) ===", "info")
            await self._process_course(kode_mk)

    async def _process_course(self, kode_mk: str):
        self.kode_mk = kode_mk
        
        # Determine dynamic folder name from catalog
        self.folder_name = get_book_folder_name(self.kode_mk)
        if self.folder_name != self.kode_mk:
            log.log(f"Metadata found: {self.folder_name}", "success")
        else:
            log.log(f"No catalog entry for {self.kode_mk}, using raw code as folder name.", "warn")
        
        self.base_dir, self.temp_dir = prepare_directories(self.folder_name, temp_suffix=self.kode_mk)
        manifest = ManifestManager(self.temp_dir)

        # 1. Auth (popup if necessary)
        # We only need to authenticate once as the cookies are saved in self.cookies
        if not self.cookies:
            if not self._authenticate():
                return

        # 2. Scraping chapter list
        log.log(f"Fetching chapter list for {self.kode_mk}...", "info")
        provider = get_provider()
        scraper = RBVScraper(self.cookies, provider)
        self.chapters = await scraper.fetch_chapters(self.kode_mk)

        # Auto-relogin if no chapters found (session might have expired)
        if not self.chapters:
            log.log(
                f"No chapters found for {self.kode_mk} — session may have expired.",
                "warn"
            )
            log.log("Deleting old session and reopening login...", "info")

            from utils.config import clear_session  # type: ignore
            clear_session()
            self.cookies = {}

            # Automatically open re-login popup
            if not self._authenticate():
                log.log("Re-login failed or cancelled. Skipping this course.", "error")
                return

            # Attempt to scrape again with new cookies
            log.log("Attempting to fetch chapter list with new session...", "info")
            scraper = RBVScraper(self.cookies, provider)
            self.chapters = await scraper.fetch_chapters(self.kode_mk)

            if not self.chapters:
                log.log(
                    f"Still no chapters found for {self.kode_mk} after re-login.\n"
                    "Please check the course code or access rights.",
                    "error"
                )
                return

        log.log(
            f"Found {len(self.chapters)} chapters. Starting download...",
            "success"
        )

        # 3. Download all chapters
        downloader = RBVDownloader(self.cookies)
        downloader.resolution = self.resolution

        async with downloader._make_session() as session:
            # Pre-download cover as 000_cover.jpg if it exists in catalog
            meta = get_book_metadata(self.kode_mk)
            if meta and meta.get("cover_image") and not manifest.cover_downloaded:
                cover_url = meta["cover_image"]
                cover_path = os.path.join(self.temp_dir, "000_cover.jpg")
                log.log(f"Downloading cover: {cover_url}", "info")
                ok = await downloader.download_page(session, cover_url, cover_path)
                if ok:
                    manifest.cover_downloaded = True

            for bab in self.chapters:
                try:
                    await self._download_chapter(session, downloader, bab, manifest)
                except Exception as e:
                    log.log(f"Error on chapter {bab.get('label')}: {e}", "error")
                    continue

        # 4. Compile PDF
        log.log(f"Compiling final PDF for {self.kode_mk}...", "info")
        all_images = collect_images_recursive(self.temp_dir)
        output_pdf = os.path.join(self.base_dir, f"{self.folder_name}.pdf")

        if PDFProcessor.compile_pdf(all_images, output_pdf):
            PDFProcessor.cleanup(self.temp_dir)
            log.log(f"Process complete for {self.kode_mk}!", "success")
            send_notification("Download Complete", f"Successfully downloaded and compiled {self.kode_mk}.")
        else:
            log.log(f"Failed to compile PDF for {self.kode_mk}. No images found?", "error")


def main_entry():
    try:
        engine = RBVEngine()
        asyncio.run(engine.start())
    except KeyboardInterrupt:
        log.log("Download interrupted. .part files saved — can be resumed later.", "info")
    except Exception as e:
        log.log(f"Critical Error: {e}", "error")
        send_notification("Critical Error", str(e))


if __name__ == "__main__":
    main_entry()
