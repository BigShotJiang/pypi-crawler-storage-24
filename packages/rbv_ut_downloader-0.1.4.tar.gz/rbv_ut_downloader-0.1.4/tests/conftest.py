import pytest
import asyncio
import sys
import os

# Ensure the project root is in sys.path for IDEs and subprocesses
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

@pytest.fixture
def event_loop():
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()
