import os
import shutil
import tempfile
from pathlib import Path
from utils.helper import collect_images_recursive

def test_collect_images_recursive():
    # Create a temporary directory structure
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        
        # Create some files
        (tmp_path / "root.jpg").touch()
        (tmp_path / "sub1").mkdir()
        (tmp_path / "sub1" / "image1.jpg").touch()
        (tmp_path / "sub1" / "not_an_image.txt").touch()
        (tmp_path / "sub2").mkdir()
        (tmp_path / "sub2" / "image2.JPG").touch() # uppercase extension
        (tmp_path / "sub2" / "nested").mkdir()
        (tmp_path / "sub2" / "nested" / "image3.jpg").touch()
        
        images = collect_images_recursive(tmp_dir)
        
        # Should find 4 images (root.jpg, image1.jpg, image2.JPG, image3.jpg)
        assert len(images) == 4
        
        # Should be sorted
        basenames = [os.path.basename(f) for f in images]
        assert "root.jpg" in basenames
        assert "image1.jpg" in basenames
        assert "image2.JPG" in basenames
        assert "image3.jpg" in basenames
        
        # Verify sorting (by full path)
        assert images == sorted(images)

def test_collect_images_recursive_empty():
    with tempfile.TemporaryDirectory() as tmp_dir:
        assert collect_images_recursive(tmp_dir) == []

def test_collect_images_recursive_nonexistent():
    assert collect_images_recursive("/nonexistent/path/at/all") == []
