import pytest
from providers.pustaka_ut import PustakaUTProvider

def test_parse_chapters_strategy_1():
    # Strategy 1: Find direct PDF links
    html = """
    <html>
        <body>
            <a href="reader.php?doc=ABC123401.pdf">Chapter 1</a>
            <a href="reader.php?doc=ABC123402.pdf">Chapter 2</a>
        </body>
    </html>
    """
    provider = PustakaUTProvider()
    chapters = provider._parse_chapters(html, "ABC1234")
    
    assert len(chapters) == 2
    assert chapters[0]["label"] == "Chapter 1"
    assert chapters[0]["id"] == "ABC123401"
    assert chapters[0]["subfolder"] == "ABC1234/"
    assert chapters[1]["label"] == "Chapter 2"
    assert chapters[1]["id"] == "ABC123402"

def test_parse_chapters_strategy_2():
    # Strategy 2: Fallback for JSON embedded in script tags
    html = """
    <html>
        <script>
            var data = ["XYZ567801.pdf", "XYZ567802.pdf"];
        </script>
    </html>
    """
    provider = PustakaUTProvider()
    chapters = provider._parse_chapters(html, "XYZ5678")
    
    # Strat 1 should fail (no <a>), so it falls back to Strat 2
    assert len(chapters) == 2
    assert chapters[0]["label"] == "XYZ567801"
    assert chapters[0]["id"] == "XYZ567801"
    assert chapters[1]["label"] == "XYZ567802"
    assert chapters[1]["id"] == "XYZ567802"

def test_parse_chapters_empty():
    html = "<html><body>No links here</body></html>"
    provider = PustakaUTProvider()
    chapters = provider._parse_chapters(html, "ABC1234")
    assert chapters == []

def test_extract_doc_id():
    provider = PustakaUTProvider()
    # Test ?doc=
    assert provider._extract_doc_id("index.php?doc=ABC1.pdf") == "ABC1"
    assert provider._extract_doc_id("index.php?format=jpg&doc=ABC2") == "ABC2"
    # Test path
    assert provider._extract_doc_id("/path/to/ABC3.pdf") == "ABC3"
    # Test none
    assert provider._extract_doc_id("nothing") is None
