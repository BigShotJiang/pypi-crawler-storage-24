import pytest
import asyncio
import unittest.mock as mock
from core.network import AdaptiveRateLimiter

@pytest.mark.asyncio
async def test_limiter_initialization():
    limiter = AdaptiveRateLimiter(initial_concurrency=5, max_concurrency=10, min_concurrency=2)
    assert limiter.concurrency == 5
    assert limiter.max_concurrency == 10
    assert limiter.min_concurrency == 2

@pytest.mark.asyncio
async def test_limiter_acquire_release():
    limiter = AdaptiveRateLimiter(initial_concurrency=1)
    await limiter.acquire()
    assert limiter.active_requests == 1
    
    # Try to acquire again should block, so we use wait_for with a timeout
    try:
        await asyncio.wait_for(limiter.acquire(), timeout=0.1)
        pytest.fail("Should have timed out")
    except asyncio.TimeoutError:
        pass
    
    await limiter.release()
    assert limiter.active_requests == 0
    
    # Now it should be able to acquire
    await asyncio.wait_for(limiter.acquire(), timeout=0.1)
    assert limiter.active_requests == 1
    await limiter.release()

@pytest.mark.asyncio
async def test_limiter_report_fast_responses():
    limiter = AdaptiveRateLimiter(initial_concurrency=2, max_concurrency=10)
    # 5 fast responses should increase concurrency
    for _ in range(5):
        await limiter.report(latency=0.5, status_code=200)
    
    assert limiter.concurrency == 4

@pytest.mark.asyncio
async def test_limiter_report_slow_responses():
    limiter = AdaptiveRateLimiter(initial_concurrency=10, min_concurrency=2)
    # 3 slow responses should decrease concurrency
    for _ in range(3):
        await limiter.report(latency=6.0, status_code=200)
    
    assert limiter.concurrency == 8

@pytest.mark.asyncio
async def test_limiter_report_overload():
    limiter = AdaptiveRateLimiter(initial_concurrency=10, min_concurrency=2)
    # 503 Overload should halve concurrency
    # Mocking sleep to avoid waiting
    import unittest.mock as mock
    with mock.patch("asyncio.sleep", return_value=None):
        await limiter.report(latency=0.5, status_code=503)
    
    assert limiter.concurrency == 5

@pytest.mark.asyncio
async def test_limiter_report_timeout():
    limiter = AdaptiveRateLimiter(initial_concurrency=10, min_concurrency=2)
    # Timeout should halve concurrency
    with mock.patch("asyncio.sleep", return_value=None):
        await limiter.report(latency=0.5, status_code=0, is_timeout=True)
    
    assert limiter.concurrency == 5
