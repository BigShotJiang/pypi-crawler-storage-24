"""
cli.py — Input & setup flow for RBV Downloader.
Handles: course code, relogin flag, and SSO credential setup.
"""
import os
import sys
import getpass
from utils.config import load_config, get_session_cookies, clear_session  # type: ignore
from utils.auth_config import has_credentials, save_auth_config, get_credentials, clear_auth_config, UT_DOMAIN  # type: ignore


def _setup_credentials():
    """
    Prompt for Student ID and password if not saved.
    Called once only — saved permanently afterwards.
    """
    print("\n" + "=" * 42)
    print("  UT SSO CREDENTIALS SETUP (Just once)")
    print("=" * 42)
    print("  These credentials are stored locally in ~/.rbv_auth.json")
    print("  to auto-login when session expires.")
    print("=" * 42)

    while True:
        nim = input("Student ID (ex: 057256579): ").strip()
        if nim:
            break
        print("[-] NIM cannot be empty.")

    email = nim if nim.upper().endswith(UT_DOMAIN) else f"{nim.upper()}{UT_DOMAIN}"
    print(f"[*] Email SSO: {email}")

    while True:
        password = getpass.getpass("UT SSO Password: ")
        if password:
            break
        print("[-] Password cannot be empty.")

    save_auth_config(nim, password)
    print("[+] Setup complete! Proceed to input course code.\n")


def get_user_input() -> tuple[list[str], bool]:
    """
    Get user input. Returns (list_of_kode_mk, force_relogin).
    If credentials do not exist, run the setup wizard first.
    """
    force_relogin = "--relogin" in sys.argv or "-r" in sys.argv
    reset_creds = "--reset-creds" in sys.argv
    
    # Check for file in arguments
    file_path = None
    for i, arg in enumerate(sys.argv):
        if arg in ["-f", "--file"] and i + 1 < len(sys.argv):
            file_path = sys.argv[i + 1]
        elif arg.startswith("--file="):
            file_path = arg.split("=", 1)[1]

    # Reset credentials if requested
    if reset_creds:
        clear_auth_config()
        print("[*] Credentials deleted. You will be prompted to setup again.")

    # Reset session if requested
    if force_relogin:
        clear_session()
        print("[*] Relogin mode: old sessions are deleted.")

    # Setup credentials if they don't exist yet
    if not has_credentials():
        print("[*] SSO credentials are not saved.")
        _setup_credentials()

    # Display saved email
    email, _ = get_credentials()
    if email:
        print(f"[+] Login as: {email}")

    kode_mks = []
    
    if isinstance(file_path, str) and os.path.isfile(file_path):
        print(f"[*] Reading course codes from file: {file_path}")
        with open(file_path, "r") as f:
            content = f.read()
            kode_mks = [c.strip().upper() for c in content.replace(',', ' ').replace('\n', ' ').split() if c.strip()]
    else:
        raw_input = input("Course Code(s) or file path (ex: DAPU6209, list.txt): ").strip()
        
        if os.path.isfile(raw_input):
            print(f"[*] Reading course codes from file: {raw_input}")
            with open(raw_input, "r") as f:
                content = f.read()
                kode_mks = [c.strip().upper() for c in content.replace(',', ' ').replace('\n', ' ').split() if c.strip()]
        else:
            # Support both space and comma separation
            kode_mks = [c.strip().upper() for c in raw_input.replace(',', ' ').split() if c.strip()]

    if not kode_mks:
        print("[-] No course codes entered. Exiting.")
        sys.exit(0)

    has_session = bool(get_session_cookies())
    if not has_session:
        print("[*] There are no saved sessions yet.")
        print("[*] The SSO login window will appear shortly....")
    else:
        print("[+] Saved session found, skip login.")

    return kode_mks, force_relogin
