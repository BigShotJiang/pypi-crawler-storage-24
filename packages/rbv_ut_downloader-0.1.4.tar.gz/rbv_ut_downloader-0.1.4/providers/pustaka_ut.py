"""
providers/pustaka_ut.py
Concrete provider for pustaka.ut.ac.id

If the UT web HTML structure changes, ONLY this file needs to be updated.
Download logic in core/ does not need to be touched.
"""
import re
import aiohttp
from bs4 import BeautifulSoup
from .base import BaseProvider
from utils.logger import Logger as log


class PustakaUTProvider(BaseProvider):
    BASE_URL = "https://pustaka.ut.ac.id"
    READER_URL = "https://pustaka.ut.ac.id/reader/index.php"
    VIEW_URL = "https://pustaka.ut.ac.id/reader/services/view.php"

    HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        ),
        "Referer": "https://pustaka.ut.ac.id/reader/",
    }

    def get_reader_url(self, kode_mk: str) -> str:
        return f"{self.READER_URL}?modul={kode_mk}"

    def get_page_url(self, doc_id: str, subfolder: str, page_num: int, resolution: str) -> str:
        return (
            f"{self.VIEW_URL}"
            f"?doc={doc_id}&format=jpg&subfolder={subfolder}&page={page_num}&resolution={resolution}"
        )

    async def fetch_chapters(self, session: aiohttp.ClientSession, kode_mk: str) -> list[dict]:
        """
        Get chapter list from the reader index.
        Parsing is done via BeautifulSoup — no Playwright/headless browser required.
        """
        url = self.get_reader_url(kode_mk)
        log.log(f"Fetching chapter list from: {url}", "info")
        
        cookie_header = "; ".join([f"{k}={v}" for k, v in session.cookie_jar.filter_cookies(url).items()])
        if not cookie_header and hasattr(session, '_default_headers') and 'Cookie' in session._default_headers:
             cookie_header = session._default_headers['Cookie']

        headers = dict(self.HEADERS)
        if cookie_header:
             headers['Cookie'] = cookie_header

        max_redirects = 5
        redirect_count = 0

        try:
            while redirect_count < max_redirects:
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=30), allow_redirects=False) as resp:
                    if resp.status in (301, 302, 303, 307, 308):
                        url = resp.headers.get('Location')
                        if not url:
                            log.log(f"HTTP {resp.status} but no Location header found", "error")
                            return []
                        
                        # Absorb new cookies manually if set
                        if 'Set-Cookie' in resp.headers:
                             for c in resp.headers.getall('Set-Cookie'):
                                 session.cookie_jar.update_cookies(c)
                        
                        # Rebuild cookie string for the next hop
                        cookie_header = "; ".join([f"{k}={v}" for k, v in session.cookie_jar.filter_cookies(url).items()])
                        if not cookie_header and hasattr(session, '_default_headers') and 'Cookie' in session._default_headers:
                             cookie_header = session._default_headers['Cookie']
                        if cookie_header:
                             headers['Cookie'] = cookie_header
                             
                        redirect_count += 1
                        log.log(f"Manual redirect to {url}", "info")
                        continue

                    if resp.status != 200:
                        log.log(f"HTTP {resp.status} while fetching chapter list", "error")
                        return []

                    html = await resp.text()
                    return self._parse_chapters(html, kode_mk)

            log.log("Too many redirects", "error")
            return []

        except aiohttp.ClientError as e:
            log.log(f"Network error while fetching chapters: {e}", "error")
            return []

    def _parse_chapters(self, html: str, kode_mk: str) -> list[dict]:
        """
        Parse HTML reader index page to get chapter list.
        Strategy 1: BeautifulSoup finds a[href*='.pdf']
        Strategy 2: Regex fallback for JSON embedded in script tags
        """
        soup = BeautifulSoup(html, "html.parser")
        chapters = []
        seen = set()

        # --- Strategy 1: Find direct PDF links ---
        pdf_links = soup.select("a[href*='.pdf']")
        for a in pdf_links:
            href = a.get("href", "")
            label = a.get_text(strip=True)

            # Extract doc_id from URL param or filename
            doc_id = self._extract_doc_id(href)
            if not doc_id or doc_id in seen:
                continue

            seen.add(doc_id)
            chapters.append({
                "label": label or doc_id,
                "id": doc_id,
                "subfolder": f"{kode_mk}/",
            })

        if chapters:
            log.log(f"Found {len(chapters)} chapters via HTML parsing.", "success")
            return chapters

        # --- Strategy 2: Find embedded JSON / JS array in scripts ---
        log.log("PDF links not found via HTML parsing, trying JS/JSON fallback...", "warn")
        chapters = self._parse_from_scripts(html, kode_mk)

        if not chapters:
            log.log("No chapters found. Page might require JavaScript or session has expired.", "error")

        return chapters

    def _extract_doc_id(self, href: str) -> str | None:
        """Extract doc_id from URL parameter or filename."""
        # Try ?doc=XXX
        match = re.search(r"[?&]doc=([^&]+)", href)
        if match:
            return match.group(1).replace(".pdf", "")

        # Try to get PDF filename
        match = re.search(r"/([^/]+\.pdf)", href)
        if match:
            return match.group(1).replace(".pdf", "")

        return None

    def _parse_from_scripts(self, html: str, kode_mk: str) -> list[dict]:
        """Fallback: find doc IDs from JS scripts on the page."""
        pattern = re.compile(r'["\']([A-Z0-9]{4,20}\.pdf)["\']')
        matches = pattern.findall(html)
        chapters = []
        seen = set()
        for m in matches:
            doc_id = m.replace(".pdf", "")
            if doc_id not in seen:
                seen.add(doc_id)
                chapters.append({
                    "label": doc_id,
                    "id": doc_id,
                    "subfolder": f"{kode_mk}/",
                })
        return chapters
