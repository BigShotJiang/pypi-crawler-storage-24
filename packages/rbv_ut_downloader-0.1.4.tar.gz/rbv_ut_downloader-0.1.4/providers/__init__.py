from .base import BaseProvider
from .pustaka_ut import PustakaUTProvider

__all__ = ["BaseProvider", "PustakaUTProvider"]

# Registry: add new providers here
PROVIDERS = {
    "pustaka_ut": PustakaUTProvider,
}

def get_provider(name: str = "pustaka_ut") -> BaseProvider:
    cls = PROVIDERS.get(name)
    if not cls:
        raise ValueError(f"Provider '{name}' not found. Available providers: {list(PROVIDERS.keys())}")
    return cls()
