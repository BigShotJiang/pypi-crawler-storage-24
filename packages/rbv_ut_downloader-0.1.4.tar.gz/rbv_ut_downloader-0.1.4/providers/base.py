"""
providers/base.py
Abstract base class for all scraper providers.
If the UT web changes, only providers/pustaka_ut.py needs to be updated.
"""
from abc import ABC, abstractmethod


class BaseProvider(ABC):
    """Interface that must be implemented by every provider."""

    BASE_URL: str = ""
    READER_URL: str = ""

    @abstractmethod
    async def fetch_chapters(self, session, kode_mk: str) -> list[dict]:
        """
        Fetch module/chapter list from the web.

        Returns:
            List of dicts: [{"label": str, "id": str, "subfolder": str}, ...]
        """
        ...

    @abstractmethod
    def get_page_url(self, doc_id: str, subfolder: str, page_num: int, resolution: str) -> str:
        """
        Build URL to download a single image page.

        Returns:
            Complete URL string ready for GET request
        """
        ...

    @abstractmethod
    def get_reader_url(self, kode_mk: str) -> str:
        """
        Main reader page URL for this module.
        Used by the auth popup to load the login page.
        """
        ...
