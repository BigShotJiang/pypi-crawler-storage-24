"""
core/auth_dialog.py
SSO Login for GUI context.

Runs authentication in a **child process** so Qt WebEngine gets its own
QApplication — completely isolated from the main GUI app.  This avoids
the segfault that occurs when WebEngine's Chromium subprocess tries to
share GPU resources with a pre-existing QApplication (QFluentWidgets).

The public API is unchanged:
    cookies = open_sso_dialog(kode_mk, credentials=(...), parent=widget)
"""
import os
import sys
import json
from utils.logger import Logger as log  # type: ignore


def open_sso_dialog(kode_mk: str,
                    credentials: tuple | None = None,
                    parent=None) -> dict | None:
    """
    Start SSO auth in a subprocess and wait for it to finish.

    Uses QProcess + QEventLoop so the main Qt event loop keeps running
    (UI stays responsive) — same pattern as QDialog.exec().

    Returns cookies dict on success, None on failure/cancel.
    """
    try:
        from PySide6.QtCore import QProcess, QEventLoop, QTimer  # type: ignore
    except ImportError as e:
        log.log(f"PySide6 not installed: {e}", "error")
        return None

    email, password = credentials if credentials else (None, None)
    has_creds = bool(email and password)

    script = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "auth_subprocess.py")
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    args: list[str] = [script, kode_mk]
    if has_creds and email and password:
        args.extend([str(email), str(password)])

    mode = "auto-login" if has_creds else "manual"
    log.log(f"Starting SSO subprocess ({mode})...", "info")

    # ── Result container (closure) ──
    result: list = [None]
    loop = QEventLoop()

    proc = QProcess()
    proc.setWorkingDirectory(project_root)
    proc.setProcessChannelMode(QProcess.ProcessChannelMode.SeparateChannels)

    # ── Read stderr in real-time → forward to GUI log ──
    def _on_stderr():
        raw = proc.readAllStandardError().data().decode("utf-8", errors="replace")
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            # Suppress noisy Qt locale warnings
            if line.startswith("Detected locale"):
                continue
            
            # Subprocess already prefixes logs. Strip it and map to the correct logging type.
            msg_type = "info"
            if line.startswith("[+] "):
                msg_type = "success"
                line = line[4:]
            elif line.startswith("[-] "):
                msg_type = "error"
                line = line[4:]
            elif line.startswith("[!] "):
                msg_type = "warn"
                line = line[4:]
            elif line.startswith("[*] "):
                msg_type = "info"
                line = line[4:]

            log.log(line, msg_type)

    proc.readyReadStandardError.connect(_on_stderr)

    # ── When process finishes → parse JSON cookies from stdout ──
    def _on_finished(exit_code, _status):
        try:
            stdout = proc.readAllStandardOutput().data().decode("utf-8").strip()
            if exit_code == 0 and stdout:
                # JSON is the last non-empty line (everything else went to stderr)
                for line in reversed(stdout.splitlines()):
                    line = line.strip()
                    if line.startswith("{"):
                        result[0] = json.loads(line)
                        break
            else:
                # Drain any remaining stderr
                _on_stderr()
        except Exception as e:
            log.log(f"Error parsing auth result: {e}", "error")
        finally:
            loop.quit()

    proc.finished.connect(_on_finished)

    # ── Launch ──
    proc.start(sys.executable, args)

    if not proc.waitForStarted(10_000):
        log.log("Failed to start auth subprocess.", "error")
        return None

    # 10-minute timeout — kill subprocess if it hangs
    timeout = QTimer()
    timeout.setSingleShot(True)
    timeout.timeout.connect(lambda: (proc.kill(), loop.quit()))
    timeout.start(600_000)

    # Block here but keep processing Qt events (like QDialog.exec)
    loop.exec()
    timeout.stop()

    # ── Return cookies ──
    cookies = result[0]
    if not cookies:
        log.log("Login cancelled or no cookies obtained.", "error")
        return None

    filtered = {k: v for k, v in cookies.items() if k and k.strip()}
    if "PHPSESSID" in filtered:
        log.log(f"PHPSESSID: {filtered['PHPSESSID'][:12]}...", "info")
        log.log(f"Total {len(filtered)} cookies.", "success")
    return filtered if filtered else None
