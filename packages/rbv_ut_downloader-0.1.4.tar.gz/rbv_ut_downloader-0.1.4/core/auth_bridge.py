"""
core/auth_bridge.py
SSO Login via popup — PySide6 QWebEngineView with Microsoft credential auto-fill.

Flow:
1. Open index.php?modul=X → login form appears + "Login SSO" link
2. Inject JS to click SSO link → redirect to Microsoft login
3. Auto-fill email (Student ID@ecampus.ut.ac.id) → click Next
4. Auto-fill password → click Sign In
5. Handle "Stay signed in?" → click No
6. Redirect to UT reader → capture PHPSESSID
7. Polling to detect successful login (login form disappears)

Fallback: if auto-fill fails (HTML structure changed), popup remains open
for manual login. Structure change detection noted for future improvement.
"""
import sys
from utils.logger import Logger as log


# --- JS: Check if user is already authenticated in UT Reader ---
CHECK_AUTH_JS = """
(function() {
    var url = window.location.href;
    var onReaderDomain = url.indexOf('pustaka.ut.ac.id/reader') >= 0;
    var notMicrosoft = url.indexOf('microsoftonline') < 0
                    && url.indexOf('login.live') < 0
                    && url.indexOf('oauth') < 0;
    var loginFormPresent = !!document.querySelector(
        '.login-container, .captcha-group, input[name="username"], ' +
        'input[name="password"], form[action*="login"]'
    );
    return onReaderDomain && notMicrosoft && !loginFormPresent;
})();
"""

# --- JS: Auto-fill Microsoft login form ---
import json

AUTO_LOGIN_JS = """
(function(email, password) {
    try {
        window._sso_last_click = window._sso_last_click || 0;
        
        var url = window.location.href;
        function isVis(e) {
            if (!e) return false;
            var style = window.getComputedStyle(e);
            if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
            var rect = e.getBoundingClientRect();
            if (rect.width <= 1 || rect.height <= 1) return false;
            if (rect.left < -100 || rect.top < -100) return false;
            if (e.classList.contains('moveOffScreen')) return false;
            return true;
        }
        
        function clickThrottled(btn, stateMsg) {
            if (Date.now() - window._sso_last_click > 4000) {
                btn.click();
                window._sso_last_click = Date.now();
                return stateMsg;
            }
            return stateMsg + '_navigating';
        }
        
        if (url.indexOf('pustaka.ut.ac.id/reader') >= 0) {
            var ssoBtn = document.getElementById('microsoft-login') || document.querySelector('.sso-btn');
            if (isVis(ssoBtn)) {
                return clickThrottled(ssoBtn, 'sso_clicked');
            }
            return 'reader_page';
        }
        
        if (url.indexOf('microsoftonline') < 0 && url.indexOf('login.live') < 0) {
            return 'not_microsoft';
        }
        
        var emailInput = document.querySelector('input[type="email"], input[name="loginfmt"], input[name="login"]');
        var passInput = document.querySelector('input[type="password"], input[name="passwd"]');
        var primaryBtn = document.querySelector('input[type="submit"], button[type="submit"], #idSIButton9, [data-testid="primaryButton"]');
        
        var isEmailStep = isVis(emailInput) && !isVis(passInput);
        var isPassStep  = isVis(passInput);
        
        if (isEmailStep) {
            if (!emailInput.value || emailInput.value !== email) {
                var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
                if (setter && setter.set) setter.set.call(emailInput, email);
                emailInput.value = email;
                emailInput.dispatchEvent(new Event('input', { bubbles: true }));
                emailInput.dispatchEvent(new Event('change', { bubbles: true }));
            }
            if (isVis(primaryBtn) && !primaryBtn.disabled) {
                return clickThrottled(primaryBtn, 'email_filled');
            }
            return 'waiting_email_btn';
        }
        
        if (isPassStep) {
            if (!passInput.value || passInput.value !== password) {
                var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
                if (setter && setter.set) setter.set.call(passInput, password);
                passInput.value = password;
                passInput.dispatchEvent(new Event('input', { bubbles: true }));
                passInput.dispatchEvent(new Event('change', { bubbles: true }));
            }
            if (isVis(primaryBtn) && !primaryBtn.disabled) {
                return clickThrottled(primaryBtn, 'password_filled');
            }
            return 'waiting_pass_btn';
        }
        
        var declineBtn = document.querySelector('#declineButton, #idBtn_Back'); 
        if (isVis(declineBtn)) {
            return clickThrottled(declineBtn, 'kmsi_declined');
        }
        
        var yesSelectors = ['#idSIButton9', 'input[value="Yes"]', 'input[value="Ya"]'];
        for (var i = 0; i < yesSelectors.length; i++) {
            var btn = document.querySelector(yesSelectors[i]);
            if (isVis(btn)) {
                return clickThrottled(btn, 'kmsi_accepted');
            }
        }
        
        return 'waiting';
    } catch (e) {
        return 'error: ' + e.message;
    }
})(%s, %s);
"""

def _launch_pyside6(kode_mk: str, credentials: tuple | None = None) -> dict | None:
    """SSO popup implementation using PySide6 + QWebEngineView."""
    from PySide6.QtWidgets import QApplication, QMainWindow
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineCookieStore
    from PySide6.QtCore import QUrl, QTimer, Qt

    target_url = f"https://pustaka.ut.ac.id/reader/index.php?modul={kode_mk}"
    email, password = credentials if credentials else (None, None)
    has_creds = bool(email and password)

    app = QApplication.instance() or QApplication(sys.argv)

    collected_cookies: dict = {}
    result: list = [None]

    profile = QWebEngineProfile(f"rbv_sso_{kode_mk}", None)
    profile.setPersistentCookiesPolicy(
        QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies
    )
    cookie_store: QWebEngineCookieStore = profile.cookieStore()

    def on_cookie_added(cookie):
        try:
            name = bytes(cookie.name()).decode("utf-8", errors="replace")
            value = bytes(cookie.value()).decode("utf-8", errors="replace")
            if name and name.strip():
                collected_cookies[name] = value
        except Exception:
            pass

    cookie_store.cookieAdded.connect(on_cookie_added)

    class SSOWindow(QMainWindow):
        def __init__(self):
            super().__init__()
            mode = "Auto-Login" if has_creds else "Manual Login"
            self.setWindowTitle(f"Login SSO UT — {kode_mk} — {mode}")
            self.resize(960, 720)
            self.setMinimumSize(720, 500)

            if has_creds:
                # IMPORTANT: Do NOT use WA_DontShowOnScreen — it prevents
                # Chromium's GPU subprocess from initializing, causing segfault.
                self.setWindowFlags(
                    Qt.WindowType.Window |
                    Qt.WindowType.FramelessWindowHint |
                    Qt.WindowType.WindowStaysOnBottomHint
                )
                self.setWindowOpacity(0.0)
                self.move(-9999, -9999)

            try:
                screen = QApplication.primaryScreen().geometry()
                self.move(
                    max(0, (screen.width() - 960) // 2),
                    max(0, (screen.height() - 720) // 2),
                )
            except Exception:
                pass

            self._view = QWebEngineView(self)
            self._page = QWebEnginePage(profile, self._view)
            self._view.setPage(self._page)
            self.setCentralWidget(self._view)

            self._view.loadFinished.connect(self._on_load_finished)
            self._view.load(QUrl(target_url))

            # Polling to check if authentication was successful
            self._poll_timer = QTimer(self)
            self._poll_timer.setInterval(2000)
            self._poll_timer.timeout.connect(self._check_auth)
            self._poll_started = False

            # 10 minute timeout
            self._timeout = QTimer(self)
            self._timeout.setSingleShot(True)
            self._timeout.setInterval(600_000)
            self._timeout.timeout.connect(self._on_timeout)
            self._timeout.start()

        def _on_load_finished(self, ok: bool):
            # Start polling after first load
            if not self._poll_started:
                self._poll_started = True
                self._poll_timer.start()
                if has_creds:
                    log.log("Popup ready. Starting auto-login...", "info")
                else:
                    log.log("Popup ready. Please log in with your UT SSO account...", "info")

            # Auto-fill everytime load finishes (if credentials exist)
            if has_creds:
                QTimer.singleShot(1200, self._try_autofill)

        def _try_autofill(self):
            """Try to auto-fill based on the current page."""
            self._page.runJavaScript(
                f"window.location.href", self._route_autofill
            )

        def _route_autofill(self, url: str):
            if not url: return
            js = AUTO_LOGIN_JS % (json.dumps(email), json.dumps(password))
            self._page.runJavaScript(js, self._on_autofill_result)

        def _on_autofill_result(self, result_str: str):
            if result_str == "email_filled":
                log.log(f"Auto-fill email: {email}", "info")
            elif result_str == "password_filled":
                log.log("Auto-fill password: successful.", "info")
            elif result_str == "kmsi_accepted":
                log.log("Stay signed in: accepted.", "info")
            elif result_str == "sso_clicked":
                log.log("Auto-click SSO: successful.", "info")

        def _check_auth(self):
            if has_creds:
                self._try_autofill()
            self._page.runJavaScript(CHECK_AUTH_JS, self._on_result)

        def _on_result(self, authenticated):
            if authenticated:
                self._poll_timer.stop()
                self._timeout.stop()
                log.log("Login successful! Capturing cookies...", "success")
                QTimer.singleShot(1500, self._finish)

        def _finish(self):
            result[0] = dict(collected_cookies)
            self.close()
            app.quit()

        def _on_timeout(self):
            log.log("Login timeout (10 minutes). Popup closed.", "warn")
            self._poll_timer.stop()
            self.close()
            app.quit()

        def closeEvent(self, event):
            self._poll_timer.stop()
            self._timeout.stop()
            app.quit()
            super().closeEvent(event)

    window = SSOWindow()
    window.show()
    app.exec()

    return result[0]


def _launch_pywebview(kode_mk: str, credentials: tuple | None = None) -> dict | None:
    """Fallback: pywebview dengan QT_API=pyside6."""
    import os
    import threading
    import time

    os.environ["QT_API"] = "pyside6"
    import webview

    target_url = f"https://pustaka.ut.ac.id/reader/index.php?modul={kode_mk}"
    email, password = credentials if credentials else (None, None)
    has_creds = bool(email and password)
    result: dict = {"cookies": None, "done": False}
    window_ref: list = [None]
    poll_started = threading.Event()

    def _poll():
        win = window_ref[0]
        if not win:
            return
        poll_started.wait(timeout=5)
        log.log("Popup ready (pywebview). Please log in...", "info")
        while not result["done"]:
            try:
                if has_creds:
                    js = AUTO_LOGIN_JS % (json.dumps(email), json.dumps(password))
                    res = win.evaluate_js(js)
                    if res == "email_filled":
                        log.log(f"Auto-fill email: {email}", "info")
                    elif res == "password_filled":
                        log.log("Auto-fill password: successful.", "info")
                    elif res == "kmsi_accepted":
                        log.log("Stay signed in: accepted.", "info")
                    elif res == "sso_clicked":
                        log.log("Auto-click SSO: successful.", "info")

                ok = win.evaluate_js(CHECK_AUTH_JS)
                if ok:
                    log.log("Login detected! Capturing cookies...", "success")
                    time.sleep(1.5)
                    raw = win.get_cookies() or []
                    cookies: dict = {}
                    for c in raw:
                        try:
                            if hasattr(c, "name"):
                                cookies[c.name] = c.value
                            elif isinstance(c, dict):
                                n = c.get("name") or c.get("key", "")
                                if n:
                                    cookies[n] = c.get("value", "")
                        except Exception:
                            pass
                    result["cookies"] = cookies
                    result["done"] = True
                    win.destroy()
                    return
            except Exception:
                result["done"] = True
                return
            time.sleep(2)

    def _on_closed():
        result["done"] = True

    win = webview.create_window(
        title=f"Login SSO UT — {kode_mk} — RBV Downloader",
        url=target_url,
        width=960,
        height=720,
        min_size=(720, 500),
        hidden=has_creds,
    )
    win.events.closed += _on_closed

    poll_thread = threading.Thread(target=_poll, daemon=True)
    poll_thread.start()

    def _on_loaded():
        poll_started.set()

    win.events.loaded += _on_loaded
    window_ref[0] = win
    webview.start(debug=False)

    return result.get("cookies")


def launch_sso_popup(kode_mk: str, credentials: tuple | None = None) -> dict | None:
    """
    Open UT SSO login popup.
    credentials: (email, password) for auto-fill, or None for manual login.
    Try PySide6 first, fallback to pywebview.
    Returns cookie dict or None.
    """
    # --- Try PySide6 (main priority) ---
    try:
        from PySide6.QtWebEngineWidgets import QWebEngineView  # noqa: F401
        backend = "PySide6 WebEngine"
        if credentials:
            log.log(f"[{backend}] Auto-login as: {credentials[0]}", "info")
        else:
            log.log(f"Using backend: {backend}", "info")
        cookies = _launch_pyside6(kode_mk, credentials)
    except ImportError:
        try:
            import webview  # noqa: F401
            log.log("PySide6 WebEngine not found, falling back to pywebview...", "warn")
            cookies = _launch_pywebview(kode_mk, credentials)
        except ImportError as e:
            log.log(
                f"No GUI backend available (PySide6 WebEngine / pywebview): {e}",
                "error",
            )
            return None

    if not cookies:
        log.log("No cookies captured or login cancelled.", "error")
        return None

    filtered = {k: v for k, v in cookies.items() if k and k.strip()}

    if "PHPSESSID" in filtered:
        log.log(f"PHPSESSID (authenticated): {filtered['PHPSESSID'][:12]}...", "info")
        log.log(f"Total {len(filtered)} cookies saved.", "success")
    else:
        log.log(f"PHPSESSID not found. Cookies: {list(filtered.keys())}", "warn")

    return filtered if filtered else None
