import os
import json
from typing import List, Set
from utils import Logger as log  # type: ignore

MANIFEST_FILENAME = "manifest.json"

class ManifestManager:
    """
    Manages the manifest.json file in the temporary directory to track download progress.
    """
    def __init__(self, temp_dir: str):
        self.temp_dir = temp_dir
        self.manifest_path = os.path.join(temp_dir, MANIFEST_FILENAME)
        self.data = self._load()

    def _load(self) -> dict:
        if os.path.exists(self.manifest_path):
            try:
                with open(self.manifest_path, "r") as f:
                    return json.load(f)
            except Exception as e:
                log.log(f"Warning: Could not load manifest: {e}", "warn")
        
        return {
            "completed_chapters": [],
            "cover_downloaded": False,
            "version": "1.0"
        }

    def _save(self):
        try:
            os.makedirs(self.temp_dir, exist_ok=True)
            with open(self.manifest_path, "w") as f:
                json.dump(self.data, f, indent=4)
        except Exception as e:
            log.log(f"Warning: Could not save manifest: {e}", "warn")

    def is_chapter_completed(self, chapter_id: str) -> bool:
        """Check if a chapter has been fully downloaded and verified."""
        return chapter_id in self.data.get("completed_chapters", [])

    def mark_chapter_completed(self, chapter_id: str):
        """Mark a chapter as completed and save the manifest."""
        if chapter_id not in self.data["completed_chapters"]:
            self.data["completed_chapters"].append(chapter_id)
            self._save()

    @property
    def cover_downloaded(self) -> bool:
        return self.data.get("cover_downloaded", False)

    @cover_downloaded.setter
    def cover_downloaded(self, value: bool):
        self.data["cover_downloaded"] = value
        self._save()
