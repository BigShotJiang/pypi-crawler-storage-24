"""
core/network.py — Zero-Playwright HTTP Downloader
Uses aiohttp with HTTP Range (byte-range) support for resuming downloads.

Resume features:
- Downloads to a .part file initially.
- If a .part file exists, gets its size → sends Range: bytes=N-
- Upon completion → renames the .part file to the final filename.
"""
import asyncio
import os
import time
import aiohttp
from utils.logger import Logger as log


class AdaptiveRateLimiter:
    def __init__(self, initial_concurrency: int = 10, max_concurrency: int = 30, min_concurrency: int = 1):
        self.concurrency = max(min_concurrency, min(initial_concurrency, max_concurrency))
        self.max_concurrency = max_concurrency
        self.min_concurrency = min_concurrency
        
        self.fast_responses = 0
        self.slow_responses = 0
        self.active_requests = 0
        self.cond = asyncio.Condition()
        self.last_latency = 0.0
        self.pbar = None

    async def acquire(self):
        async with self.cond:
            await self.cond.wait_for(lambda: self.active_requests < self.concurrency)
            self.active_requests += 1

    async def release(self):
        async with self.cond:
            self.active_requests -= 1
            self.cond.notify_all()

    async def report(self, latency: float, status_code: int, is_timeout: bool = False):
        async with self.cond:
            self.last_latency = latency
            if is_timeout or status_code in (500, 502, 503, 504, 429):
                self.concurrency = max(self.min_concurrency, self.concurrency // 2)
                self.fast_responses = 0
                msg = f"[!] Server Overload ({status_code if not is_timeout else 'Timeout'}). Pausing 5s..."
                if self.pbar:
                    self.pbar.write(msg)
                await asyncio.sleep(5)
            elif latency > 5.0:
                self.slow_responses += 1
                self.fast_responses = 0
                if self.slow_responses >= 3:
                    self.concurrency = max(self.min_concurrency, self.concurrency - 2)
                    self.slow_responses = 0
            elif latency < 1.0 and status_code in (200, 206):
                self.fast_responses += 1
                self.slow_responses = 0
                if self.fast_responses >= 5:
                    if self.concurrency < self.max_concurrency:
                        self.concurrency = min(self.max_concurrency, self.concurrency + 2)
                    self.fast_responses = 0
            else:
                self.fast_responses = 0
                self.slow_responses = 0
                
            self.cond.notify_all()


CHUNK_SIZE = 65536  # 64 KB per chunk


class RBVDownloader:
    def __init__(self, cookie_dict: dict):
        self.cookies = cookie_dict
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ),
            "Referer": "https://pustaka.ut.ac.id/reader/",
        }
        self.resolution = "800"

    def _make_session(self) -> aiohttp.ClientSession:
        """Creates a single shared ClientSession initialized with cookies & headers."""
        jar = aiohttp.CookieJar(unsafe=True)
        return aiohttp.ClientSession(
            cookies=self.cookies,
            headers=self.headers,
            cookie_jar=jar,
            timeout=aiohttp.ClientTimeout(total=60, connect=15),
        )

    async def download_page(
        self,
        session: aiohttp.ClientSession,
        page_url: str,
        filename: str,
        limiter: 'AdaptiveRateLimiter' = None,
    ) -> bool:
        """
        Downloads a single page. Supports resuming via HTTP Range.
        """
        if limiter:
            await limiter.acquire()

        start_time = time.time()
        status_code = 0
        is_timeout = False

        try:
            part_file = filename + ".part"

            # Check if the final file already exists and is not empty
            if os.path.exists(filename) and os.path.getsize(filename) > 0:
                return True

            # Calculate byte offset for resuming
            start_byte = 0
            if os.path.exists(part_file):
                start_byte = os.path.getsize(part_file)

            request_headers = {}
            if start_byte > 0:
                request_headers["Range"] = f"bytes={start_byte}-"

            try:
                async with session.get(page_url, headers=request_headers) as response:
                    status_code = response.status
                    # 200 OK = fresh download, 206 Partial = resume
                    if response.status not in (200, 206):
                        return False

                    content_type = response.headers.get("Content-Type", "")
                    if "image" not in content_type:
                        return False

                    write_mode = "ab" if start_byte > 0 and response.status == 206 else "wb"

                    with open(part_file, write_mode) as f:
                        async for chunk in response.content.iter_chunked(CHUNK_SIZE):
                            f.write(chunk)

                # Rename .part → final filename
                os.replace(part_file, filename)
                return True

            except asyncio.TimeoutError:
                is_timeout = True
                return False
            except (aiohttp.ClientError, OSError):
                return False

        finally:
            if limiter:
                latency = time.time() - start_time
                if status_code != 0 or is_timeout:
                    await limiter.report(latency, status_code, is_timeout)
                await limiter.release()

    async def probe_page_count(
        self,
        session: aiohttp.ClientSession,
        provider,
        doc_id: str,
        subfolder: str,
        resolution: str,
        probe_limit: int = 5,
    ) -> int:
        """
        Probes for the last page using a simple binary search.
        This is optional — the main engine uses an empty-batch detection strategy.
        """
        # Verify page 1 is accessible
        url1 = provider.get_page_url(doc_id, subfolder, 1, resolution)
        try:
            async with session.get(url1) as resp:
                if resp.status != 200 or "image" not in resp.headers.get("Content-Type", ""):
                    return 0
        except Exception:
            return 0

        return -1  # -1 = use the empty-batch detection strategy in the engine