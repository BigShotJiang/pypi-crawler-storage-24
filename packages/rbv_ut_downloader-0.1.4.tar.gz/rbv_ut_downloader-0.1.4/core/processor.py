import os
import shutil
import img2pdf  # type: ignore
from PIL import Image  # type: ignore
from utils.logger import Logger as log  # type: ignore

class PDFProcessor:
    @staticmethod
    def _normalize_cover(image_list):
        """
        If 000_cover.jpg exists and there's at least one other page,
        resize the cover to match the first content page's dimensions.
        """
        if len(image_list) < 2:
            return image_list
        
        cover_path = image_list[0]
        if "000_cover.jpg" not in os.path.basename(cover_path):
            return image_list
            
        try:
            target_path = image_list[1]
            with Image.open(target_path) as target_img:
                target_size = target_img.size
            
            with Image.open(cover_path) as cover_img:
                if cover_img.size != target_size:
                    log.log(f"Resizing cover from {cover_img.size} to {target_size}...", "info")
                    # Using Resampling.LANCZOS for best quality
                    resized_cover = cover_img.resize(target_size, Image.Resampling.LANCZOS)
                    resized_cover.save(cover_path, quality=95)
        except Exception as e:
            log.log(f"Warning: Could not normalize cover size: {e}", "warn")
            
        return image_list

    @staticmethod
    def compile_pdf(image_list, output_path):
        """Merge all images into one HD PDF."""
        if not image_list:
            log.log("Zonk. No images were downloaded successfully.", "error")
            return False
        
        # Ensure cover size matches the rest
        image_list = PDFProcessor._normalize_cover(image_list)
        
        try:
            log.log(f"Compiling {len(image_list)} images into PDF...", "info")
            with open(output_path, "wb") as f:
                f.write(img2pdf.convert(image_list))
            log.log(f"SUCCESS! File saved to: {output_path}", "success")
            return True
        except Exception as e:
            log.log(f"Failed to create PDF: {e}", "error")
            return False

    @staticmethod
    def cleanup(temp_dir):
        """Clean up the junk in the temp folder."""
        try:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                log.log("Temp directory cleaned up.", "info")
        except Exception as e:
            log.log(f"Cleanup failed: {e}", "error")
