#!/usr/bin/env python
"""
core/auth_subprocess.py
Standalone SSO authentication — runs in its own process/QApplication
to isolate Qt WebEngine from the main GUI app.

Usage:  python core/auth_subprocess.py <kode_mk> [email] [password]
Output: JSON cookies dict on stdout (success) | exit code 1 (failure)
All log output goes to stderr so stdout is clean JSON only.
"""
import sys
import os
import json

# ── WebEngine env — MUST be before any Qt import ──
os.environ["QTWEBENGINE_DISABLE_SANDBOX"] = "1"
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
    "--no-sandbox --disable-gpu --disable-gpu-sandbox "
    "--disable-gpu-compositing --disable-software-rasterizer "
    "--disable-gpu-memory-buffer-video-frames"
)

# Ensure project root is importable
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# Redirect stdout → stderr so print()/log.log() don't pollute JSON output.
# We keep a reference to the real stdout for writing JSON at the end.
_json_out = sys.stdout
sys.stdout = sys.stderr


def main():
    if len(sys.argv) < 2:
        print("Usage: python auth_subprocess.py <kode_mk> [email] [password]",
              file=sys.stderr)
        sys.exit(2)

    kode_mk = sys.argv[1]
    email    = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] else None
    password = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] else None
    credentials = (email, password) if email and password else None

    # Qt attributes — before QApplication
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)

    from core.auth_bridge import launch_sso_popup

    cookies = launch_sso_popup(kode_mk, credentials=credentials)

    if cookies:
        # JSON on the real stdout — the only thing the parent reads
        print(json.dumps(cookies), file=_json_out, flush=True)
        sys.exit(0)
    else:
        print("Auth failed or cancelled.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
