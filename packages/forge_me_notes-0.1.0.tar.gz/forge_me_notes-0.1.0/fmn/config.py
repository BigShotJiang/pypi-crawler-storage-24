"""
fmn.config — vault resolution and shared paths
"""

import os
import sys
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv optional — env vars can be set manually


BASE_DIR = Path(__file__).resolve().parent.parent
INPUT_FILE = BASE_DIR / "input" / "notes.yaml"
CONTEXT_DIR = BASE_DIR / "context"
PROMPTS_DIR = BASE_DIR / "prompts"
SYSTEM_PROMPT_FILE = PROMPTS_DIR / "system_prompt.md"


def resolve_vault(vault_arg: Path | None = None) -> Path:
    """
    Resolve vault path from:
      1. --vault flag (passed as argument)
      2. VAULT_PATH environment variable
      3. Error — one of the above must be set
    """
    if vault_arg:
        vault = Path(vault_arg).expanduser().resolve()
    elif os.environ.get("VAULT_PATH"):
        vault = Path(os.environ["VAULT_PATH"]).expanduser().resolve()
    else:
        print(
            "❌  No vault path found.\n"
            "    Set VAULT_PATH in your .env file, or use --vault /path/to/vault"
        )
        sys.exit(1)

    if not vault.exists():
        print(f"❌  Vault not found: {vault}")
        sys.exit(1)

    return vault


def load_system_prompt() -> str:
    """Load the LLM system prompt from prompts/system_prompt.md"""
    if not SYSTEM_PROMPT_FILE.exists():
        print(f"❌  System prompt not found: {SYSTEM_PROMPT_FILE}")
        sys.exit(1)
    return SYSTEM_PROMPT_FILE.read_text(encoding="utf-8")
