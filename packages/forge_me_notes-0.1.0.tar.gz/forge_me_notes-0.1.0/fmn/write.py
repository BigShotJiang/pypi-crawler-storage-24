"""
fmn.write — read input/notes.yaml and write notes to vault
"""

import sys
import yaml
from pathlib import Path
from fmn.config import INPUT_FILE


def load_template(vault: Path, template_name: str) -> str:
    template_path = vault / "70_Templates" / template_name
    if not template_path.exists():
        print(f"❌  Template not found: {template_path}")
        print(f"    Make sure {template_name} exists in {vault}/70_Templates/")
        sys.exit(1)
    return template_path.read_text(encoding="utf-8")


def render_note(output_path: str, properties: dict, body: str) -> str:
    """
    .base files → pure YAML body, no frontmatter wrapper
    All other files → standard YAML frontmatter + markdown body
    """
    if output_path.endswith(".base"):
        return body.strip() + "\n"

    yaml_block = yaml.safe_dump(properties, sort_keys=False).strip()
    return f"---\n{yaml_block}\n---\n\n{body.strip()}\n"


def write_file(path: Path, content: str, force: bool) -> tuple[bool, str]:
    if path.exists() and not force:
        return False, f"  ⏭️  exists (skip):  {path.name}"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True, f"  ✅ written:        {path.name}"


def dry_run(vault: Path, notes: list, force: bool) -> list:
    """Print planned actions and return list of (target, status) tuples."""
    actions = []
    for note in notes:
        target = vault / note["output_path"]
        if target.exists() and force:
            status = "overwrite"
        elif target.exists():
            status = "skip"
        else:
            status = "create"
        actions.append((target, note, status))

    will_create = sum(1 for _, _, s in actions if s == "create")
    will_overwrite = sum(1 for _, _, s in actions if s == "overwrite")
    will_skip = sum(1 for _, _, s in actions if s == "skip")

    print(f"\n📋 Planned actions ({len(notes)} notes):")
    for target, _, status in actions:
        icon = {"create": "➕", "overwrite": "♻️ ", "skip": "⏭️ "}[status]
        print(f"  {icon} {status:9s}  {target.relative_to(vault)}")

    print(f"\n  ➕ create: {will_create}  ♻️  overwrite: {will_overwrite}  ⏭️  skip: {will_skip}")
    return actions


def run_write(vault: Path, force: bool = False, notes: list | None = None) -> int:
    """
    Write notes to vault. Returns count of notes written.

    If notes is provided (from fmn run), skips loading from INPUT_FILE.
    """
    if notes is None:
        if not INPUT_FILE.exists():
            print(f"❌  No input file found: {INPUT_FILE}")
            print("    Run `fmn generate` first, or place a notes.yaml in input/")
            sys.exit(1)
        with open(INPUT_FILE, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if "notes" not in data:
            print("❌  Input YAML must contain a top-level 'notes:' list")
            sys.exit(1)
        notes = data["notes"]

    written = 0
    for note in notes:
        load_template(vault, note["template"])  # validate template exists
        content = render_note(
            output_path=note["output_path"],
            properties=note["properties"],
            body=note["body"],
        )
        target = vault / note["output_path"]
        ok, msg = write_file(target, content, force)
        print(msg)
        if ok:
            written += 1

    return written
