"""
fmn.cost — estimate API call cost before sending

Uses character-based token approximation (chars / 4) — accurate enough
for cost estimation without requiring tiktoken or an API preflight call.

Pricing is hardcoded from public Anthropic and OpenAI pricing pages.
Update MODEL_PRICING if rates change.
"""

# Pricing per 1M tokens in USD (as of early 2026)
# Format: (input_per_1m, output_per_1m)
MODEL_PRICING: dict[str, tuple[float, float]] = {
    # Anthropic
    "claude-haiku-4-5-20251001":  (0.80,   4.00),
    "claude-sonnet-4-20250514":   (3.00,  15.00),
    "claude-opus-4-20250514":    (15.00,  75.00),
    # OpenAI
    "gpt-4o":                     (2.50,  10.00),
    "gpt-4o-mini":                (0.15,   0.60),
    "gpt-4-turbo":               (10.00,  30.00),
    # Ollama / manual — free
    "ollama":                     (0.00,   0.00),
    "manual":                     (0.00,   0.00),
}

# Rough output token estimate — notes.yaml responses are typically 500–2000 tokens
ESTIMATED_OUTPUT_TOKENS = 1500


def estimate_tokens(text: str) -> int:
    """Rough token count: characters / 4. Good enough for cost estimation."""
    return max(1, len(text) // 4)


def estimate_cost(
    system_prompt: str,
    user_message: str,
    model: str,
    provider: str,
) -> dict:
    """
    Estimate the cost of an API call before sending it.
    Returns a dict with token counts and estimated cost in USD and EUR.
    """
    # Free providers
    if provider in ("ollama", "manual"):
        return {
            "provider": provider,
            "model": model,
            "input_tokens": 0,
            "output_tokens": 0,
            "input_cost_usd": 0.0,
            "output_cost_usd": 0.0,
            "total_cost_usd": 0.0,
            "total_cost_eur": 0.0,
            "free": True,
        }

    input_tokens = estimate_tokens(system_prompt + user_message)
    output_tokens = ESTIMATED_OUTPUT_TOKENS

    # Look up pricing — fall back to a conservative estimate if model unknown
    pricing = MODEL_PRICING.get(model)
    if pricing is None:
        # Unknown model — use Sonnet pricing as conservative estimate
        pricing = MODEL_PRICING["claude-sonnet-4-20250514"]
        unknown_model = True
    else:
        unknown_model = False

    input_per_1m, output_per_1m = pricing

    input_cost = (input_tokens / 1_000_000) * input_per_1m
    output_cost = (output_tokens / 1_000_000) * output_per_1m
    total_usd = input_cost + output_cost
    total_eur = total_usd * 0.92  # approximate — update if needed

    return {
        "provider": provider,
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "input_cost_usd": input_cost,
        "output_cost_usd": output_cost,
        "total_cost_usd": total_usd,
        "total_cost_eur": total_eur,
        "free": False,
        "unknown_model": unknown_model,
    }


def print_cost_estimate(estimate: dict) -> None:
    """Print a human-readable cost estimate."""
    print("\n💰 Estimated API cost:")

    if estimate.get("free"):
        provider = estimate["provider"]
        if provider == "manual":
            print("   Free — manual mode, no API call")
        else:
            print(f"   Free — {provider} runs locally")
        return

    model = estimate["model"]
    input_tok = estimate["input_tokens"]
    output_tok = estimate["output_tokens"]
    total_usd = estimate["total_cost_usd"]
    total_eur = estimate["total_cost_eur"]

    unknown = estimate.get("unknown_model", False)
    note = " (unknown model — using Sonnet pricing as estimate)" if unknown else ""

    print(f"   Model:   {model}{note}")
    print(f"   Input:   ~{input_tok:,} tokens  (context pack + request)")
    print(f"   Output:  ~{output_tok:,} tokens  (estimated notes.yaml)")
    print(f"   Cost:    ~${total_usd:.4f} USD  (~€{total_eur:.4f} EUR)")

    # Contextual guidance based on cost
    if total_usd < 0.01:
        print("   ✅ Very cheap — go for it")
    elif total_usd < 0.05:
        print("   ✅ Cheap — fine for regular use")
    elif total_usd < 0.20:
        print("   ⚠️  Moderate — consider using --provider manual for large batches")
    else:
        print("   ⚠️  Expensive — strongly consider --provider manual or ollama")
        print("      Tip: reduce vault size with a more targeted request")
