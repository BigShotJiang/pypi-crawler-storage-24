"""
fmn.cli — argument parsing and command dispatch
"""

import argparse
import sys
from pathlib import Path
from fmn.config import resolve_vault
from fmn import __version__


def main():
    parser = argparse.ArgumentParser(
        prog="fmn",
        description="forge-me-notes — build Obsidian vaults with LLM assistance",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
commands:
  pack                  Scan vault → export context/all.md
  write                 Write input/notes.yaml → vault notes
  generate "request"    Context pack + request → LLM → input/notes.yaml
  run "request"         Pack + generate + confirm + write in one step

providers:
  --provider anthropic  Claude via Anthropic API  (ANTHROPIC_API_KEY)
  --provider openai     GPT-4o via OpenAI API     (OPENAI_API_KEY)
  --provider ollama     Local model via Ollama     (free, no key needed)
  --provider manual     Print prompt, paste into any LLM yourself (default fallback)

examples:
  fmn pack
  fmn write --force
  fmn generate "Add 3 inspiration notes about Nordic cities" --provider anthropic
  fmn generate "Add 3 inspiration notes about Nordic cities" --provider ollama --model mistral
  fmn generate "Add 3 inspiration notes about Nordic cities" --provider manual
  fmn run "Create a use case for air quality monitoring" --provider openai
  fmn run "Update all use cases to reference my new Vienna datasets" --force
        """,
    )

    parser.add_argument(
        "--version", action="version", version=f"fmn {__version__}"
    )
    parser.add_argument(
        "--vault",
        type=Path,
        default=None,
        help="Path to vault root (overrides VAULT_PATH env var)",
    )

    subparsers = parser.add_subparsers(dest="command")

    # ── pack ──────────────────────────────────────────────────────
    pack_parser = subparsers.add_parser(
        "pack", help="Scan vault → export context pack"
    )
    pack_parser.add_argument(
        "--vault", type=Path, default=None,
        help="Path to vault root (overrides VAULT_PATH env var)",
    )
    pack_parser.add_argument(
        "--notes", action="store_true",
        help="Include full note bodies in context/notes/",
    )

    # ── write ─────────────────────────────────────────────────────
    write_parser = subparsers.add_parser(
        "write", help="Write input/notes.yaml → vault notes"
    )
    write_parser.add_argument(
        "--vault", type=Path, default=None,
        help="Path to vault root (overrides VAULT_PATH env var)",
    )
    write_parser.add_argument(
        "--force", action="store_true",
        help="Overwrite existing notes",
    )

    # ── generate ──────────────────────────────────────────────────
    generate_parser = subparsers.add_parser(
        "generate", help="Context pack + request → LLM → input/notes.yaml"
    )
    generate_parser.add_argument(
        "request", type=str,
        help='Plain English request, e.g. "Add 3 inspiration notes about Helsinki"',
    )
    generate_parser.add_argument(
        "--vault", type=Path, default=None,
        help="Path to vault root (overrides VAULT_PATH env var)",
    )
    generate_parser.add_argument(
        "--provider", type=str, default="anthropic",
        choices=["anthropic", "openai", "ollama", "manual"],
        help="LLM provider to use (default: anthropic). Use 'manual' for any chat interface.",
    )
    generate_parser.add_argument(
        "--model", type=str, default=None,
        help="Model name (default: provider's recommended model)",
    )

    # ── run ───────────────────────────────────────────────────────
    run_parser = subparsers.add_parser(
        "run", help="Pack + generate + confirm + write in one step"
    )
    run_parser.add_argument(
        "request", type=str,
        help='Plain English request, e.g. "Add a user group note for Roma communities"',
    )
    run_parser.add_argument(
        "--vault", type=Path, default=None,
        help="Path to vault root (overrides VAULT_PATH env var)",
    )
    run_parser.add_argument(
        "--force", action="store_true",
        help="Overwrite existing notes without asking",
    )
    run_parser.add_argument(
        "--provider", type=str, default="anthropic",
        choices=["anthropic", "openai", "ollama", "manual"],
        help="LLM provider to use (default: anthropic). Use 'manual' for any chat interface.",
    )
    run_parser.add_argument(
        "--model", type=str, default=None,
        help="Model name (default: provider's recommended model)",
    )

    # ── audit ─────────────────────────────────────────────────────
    audit_parser = subparsers.add_parser(
        "audit", help="Check vault health — broken links, orphans, missing properties"
    )
    audit_parser.add_argument(
        "--vault", type=Path, default=None,
        help="Path to vault root (overrides VAULT_PATH env var)",
    )
    audit_parser.add_argument(
        "--verbose", action="store_true",
        help="Show all issues (default: cap at 5 per category)",
    )
    audit_parser.add_argument(
        "--report", action="store_true",
        help="Save audit report as a timestamped note in the vault",
    )
    audit_parser.add_argument(
        "--fix", action="store_true",
        help="Auto-repair fixable issues (broken links with near-matches)",
    )
    audit_parser.add_argument(
        "--trend", action="store_true",
        help="Show audit history trend from .fmn/history.yaml",
    )

    # ── dispatch ──────────────────────────────────────────────────
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    # Resolve vault — command-level flag beats top-level flag beats env var
    vault_override = getattr(args, "vault", None) or getattr(parser.parse_known_args()[0], "vault", None)
    vault = resolve_vault(vault_override)

    if args.command == "pack":
        from fmn.pack import run_pack
        run_pack(vault=vault, include_notes=args.notes)

    elif args.command == "write":
        from fmn.write import run_write
        run_write(vault=vault, force=args.force)

    elif args.command == "generate":
        from fmn.generate import run_generate
        run_generate(
            vault=vault,
            request=args.request,
            provider=args.provider,
            model=args.model,
        )

    elif args.command == "audit":
        from fmn.audit import run_audit
        run_audit(
            vault=vault,
            verbose=args.verbose,
            write_report=args.report,
            fix=args.fix,
            trend=args.trend,
        )

    elif args.command == "run":
        from fmn.run import run_all
        run_all(
            vault=vault,
            request=args.request,
            force=args.force,
            provider=args.provider,
            model=args.model,
        )
