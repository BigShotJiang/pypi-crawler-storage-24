"""
fmn.audit — vault health analysis

Checks the vault for structural, relational, and property issues.
Produces a human-readable report and optionally writes it to the vault.

Design principle: fast feedback loops (Accelerate, Forsgren et al. 2018)
The faster you know your vault has a problem, the cheaper it is to fix.

Tiers:
  Tier 1 — Structural  (fast, local, no API)
  Tier 2 — Relational  (fast, local, no API)
  Tier 3 — Semantic    (optional, API, --deep flag — future)
"""

import re
import sys
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field

try:
    import frontmatter
    HAS_FRONTMATTER = True
except ImportError:
    HAS_FRONTMATTER = False

from fmn.vault_config import (
    load_config,
    append_history,
    save_audit_report,
    print_trend,
)


# ── Data structures ───────────────────────────────────────────────

@dataclass
class Issue:
    tier: int                    # 1=structural, 2=relational, 3=semantic
    severity: str                # error | warning | info
    note_path: str               # relative path from vault root
    message: str                 # human-readable description
    suggestion: str = ""         # what to do about it
    auto_fixable: bool = False   # can fmn fix this without LLM?
    fix_from: str = ""           # exact string to replace in file
    fix_to: str = ""             # replacement string


@dataclass
class NoteInfo:
    path: Path
    rel_path: str
    title: str
    properties: dict
    body: str
    outbound_links: list[str]    # wikilink targets found in body + properties
    note_type: str               # inferred from is-* properties


@dataclass
class AuditReport:
    vault: Path
    timestamp: str
    notes_checked: int
    issues: list[Issue] = field(default_factory=list)

    @property
    def errors(self):
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self):
        return [i for i in self.issues if i.severity == "warning"]

    @property
    def infos(self):
        return [i for i in self.issues if i.severity == "info"]


# ── Infrastructure skip rules ─────────────────────────────────────

def _is_infrastructure(path: Path, vault: Path) -> bool:
    """
    Return True if this file should be excluded from audit.

    Excluded:
    - Non-.md files (.base, .json, etc)
    - 70_Templates/ — template files, not content
    - .obsidian/ — Obsidian app config
    - Files starting with _ or . — hidden/system files
    - Audit reports — avoid self-referential noise
    """
    # Non-markdown files
    if path.suffix != ".md":
        return True

    rel = str(path.relative_to(vault))

    # Obsidian config
    if ".obsidian" in rel:
        return True

    # Template folder
    if "70_Templates" in rel:
        return True

    # Hidden or system files
    if path.name.startswith(("_", ".")):
        return True

    # Our own audit report output
    if path.stem.startswith("Audit Report"):
        return True

    return False


def _is_infrastructure_by_type(note: "NoteInfo") -> bool:
    """Return True if note is infrastructure based on its content type."""
    return note.properties.get("type", "") in ("template", "base", "audit-report")


# ── Note scanning ─────────────────────────────────────────────────

WIKILINK_RE = re.compile(r'\[\[([^\]|#]+?)(?:\|[^\]]+)?\]\]')


def extract_wikilinks(text: str) -> list[str]:
    """Extract all wikilink targets from a block of text."""
    return [m.strip() for m in WIKILINK_RE.findall(text)]


def infer_note_type(properties: dict) -> str:
    for key, value in properties.items():
        if key.startswith("is-") and value is True:
            return key[3:]
    return "unknown"


def load_note(path: Path, vault: Path) -> "NoteInfo | None":
    rel_path = str(path.relative_to(vault))

    if HAS_FRONTMATTER:
        try:
            post = frontmatter.load(path)
            props = post.metadata
            body = post.content
        except Exception:
            return None
    else:
        import yaml
        raw = path.read_text(encoding="utf-8", errors="ignore")
        props = {}
        body = raw
        if raw.startswith("---"):
            parts = raw.split("---", 2)
            if len(parts) >= 3:
                try:
                    props = yaml.safe_load(parts[1]) or {}
                    body = parts[2]
                except Exception:
                    pass

    title = (
        props.get("title")
        or props.get("dataset-name")
        or props.get("provider-name")
        or props.get("software-name")
        or props.get("format-name")
        or props.get("use-case-name")
        or props.get("group-name")
        or props.get("barrier-name")
        or props.get("inspiration-name")
        or path.stem
    )

    all_text = body + str(props)
    outbound = list(set(extract_wikilinks(all_text)))

    return NoteInfo(
        path=path,
        rel_path=rel_path,
        title=str(title),
        properties=props,
        body=body,
        outbound_links=outbound,
        note_type=infer_note_type(props),
    )


def scan_vault(vault: Path) -> dict[str, NoteInfo]:
    """Load all content notes. Returns dict keyed by title."""
    notes: dict[str, NoteInfo] = {}

    for md_file in sorted(vault.rglob("*.md")):
        if _is_infrastructure(md_file, vault):
            continue
        note = load_note(md_file, vault)
        if not note:
            continue
        if _is_infrastructure_by_type(note):
            continue
        notes[note.title] = note

    return notes


# ── Tier 1: Structural checks ─────────────────────────────────────

def check_broken_links(
    notes: dict[str, NoteInfo],
    suppress: set[str] | None = None,
) -> list[Issue]:
    """Find wikilinks that point to non-existent notes."""
    issues = []
    all_titles = set(notes.keys())
    all_stems = {Path(n.rel_path).stem for n in notes.values()}
    all_valid = all_titles | all_stems

    # Default suppressions — overridden by vault config
    if suppress is None:
        suppress = {
            "wikilinks",
            "Note Title",
            "User Group",
            "Provider Name",
            "Dataset Name",
            "Format Name",
        }

    for title, note in notes.items():
        for link in note.outbound_links:
            link_title = link.split("/")[-1].strip()
            if not link_title:
                continue

            # Skip .base transclusions — valid Obsidian embeds, not broken links
            if link_title.endswith(".base"):
                continue

            if link_title in all_valid:
                continue
            if link_title in suppress:
                continue

            suggestion = _find_near_match(link_title, all_valid)

            # Store the exact original link text for the fixer
            original_link = link.strip()
            fixed_link = suggestion if suggestion else None

            issues.append(Issue(
                tier=1,
                severity="error",
                note_path=note.rel_path,
                message=f"Broken link: [[{link_title}]]",
                suggestion=f"Did you mean [[{suggestion}]]?" if suggestion
                           else "No similar note found — create it or remove the link",
                auto_fixable=bool(suggestion),
                fix_from=f"[[{original_link}]]",
                fix_to=f"[[{suggestion}]]" if suggestion else "",
            ))
    return issues


def _collect_base_implicit_links(vault: Path, notes: dict[str, NoteInfo]) -> dict[str, list[str]]:
    """
    Read .base files and infer implicit links.

    A base with filter: is-inspiration = true implicitly links to every
    inspiration note — so those notes should not be considered orphaned
    just because no markdown note explicitly links to them.

    Returns dict: note_title -> [base_file_names_that_cover_it]
    """
    import yaml as _yaml
    implicit: dict[str, list[str]] = {}

    for base_file in sorted(vault.rglob("*.base")):
        if ".obsidian" in str(base_file):
            continue
        try:
            content = base_file.read_text(encoding="utf-8")
            data = _yaml.safe_load(content)
        except Exception:
            continue

        if not isinstance(data, dict):
            continue

        # Extract all is-* filters from the base views
        base_str = str(data)
        covered_types = set()
        import re as _re
        for match in _re.finditer(r'is-(\w[\w\-]*)', base_str):
            covered_types.add(match.group(1))

        base_name = base_file.stem

        # Any note whose type matches a covered type is implicitly linked
        for title, note in notes.items():
            if note.note_type in covered_types:
                implicit.setdefault(title, []).append(base_name)

    return implicit


def check_orphaned_notes(notes: dict[str, NoteInfo], vault: Path | None = None) -> list[Issue]:
    """Find notes that no other note links to."""
    issues = []
    all_titles = set(notes.keys())

    # Build inbound link map from explicit wikilinks
    inbound: dict[str, list[str]] = {t: [] for t in all_titles}
    for title, note in notes.items():
        for link in note.outbound_links:
            link_title = link.split("/")[-1].strip()
            if link_title in inbound:
                inbound[link_title].append(title)

    # Also count implicit links from .base files
    if vault:
        implicit = _collect_base_implicit_links(vault, notes)
        for title, bases in implicit.items():
            inbound.setdefault(title, []).extend(bases)

    # Skip types that are not expected to be linked to
    skip_types = {"overview", "unknown"}
    skip_titles = {"START HERE", "Contributing", "START_HERE"}

    for title, note in notes.items():
        if note.note_type in skip_types:
            continue
        if title in skip_titles:
            continue
        if not inbound.get(title):
            issues.append(Issue(
                tier=1,
                severity="warning",
                note_path=note.rel_path,
                message="Orphaned note — nothing links here",
                suggestion="Add a wikilink from a related note, or add to a section overview",
            ))

    return issues


def check_missing_properties(
    notes: dict[str, NoteInfo],
    exemptions: dict[str, list[str]] | None = None,
) -> list[Issue]:
    """Check notes missing expected properties based on type."""
    issues = []

    required: dict[str, list[str]] = {
        "use-case":    ["city", "difficulty", "impact", "status", "affected-groups"],
        "user-group":  ["primary-barriers", "use-cases"],
        "barrier":     ["barrier-category", "severity", "affects-groups"],
        "inspiration": ["country", "source-url", "relevant-use-cases"],
        "dataset":     ["license", "download-link", "formats"],
        "provider":    ["website"],
        "software":    ["website", "license"],
    }

    # Properties that are genuinely optional for some notes
    # Defaults here — overridden by vault config exemptions
    if exemptions is None:
        exemptions = {
            "Browser":       ["website"],
            "Samba Client":  ["website"],
        }

    for title, note in notes.items():
        expected = required.get(note.note_type, [])
        note_exemptions = exemptions.get(title, [])

        for prop in expected:
            if prop in note_exemptions:
                continue
            value = note.properties.get(prop)
            if not value or value == [] or value == "":
                issues.append(Issue(
                    tier=1,
                    severity="warning",
                    note_path=note.rel_path,
                    message=f"Missing property: {prop}",
                    suggestion=f"Add '{prop}:' to the frontmatter of this note",
                ))

    return issues


def check_duplicate_titles(notes: dict[str, NoteInfo]) -> list[Issue]:
    """
    Find notes with suspiciously similar titles (possible duplicates).

    Uses a stricter similarity check than before:
    - Ignores numbered overview notes (10 Overview, 20 Overview etc.)
    - Only flags notes of the same type
    - Requires higher similarity threshold
    """
    issues = []
    titles = list(notes.keys())

    # Pattern for numbered section overviews — these are intentionally similar
    numbered_overview = re.compile(r'^\d+ Overview$')

    for i, t1 in enumerate(titles):
        # Skip numbered overviews entirely — they're intentionally similar
        if numbered_overview.match(t1):
            continue

        n1 = notes[t1]

        for t2 in titles[i+1:]:
            if numbered_overview.match(t2):
                continue

            n2 = notes[t2]

            # Only flag notes of the same type — different types can share words
            if n1.note_type != n2.note_type:
                continue

            score = _word_similarity(t1, t2)
            if score > 0.80 and t1 != t2:
                issues.append(Issue(
                    tier=1,
                    severity="warning",
                    note_path=n1.rel_path,
                    message=f"Possible duplicate: '{t1}' ≈ '{t2}'",
                    suggestion="Review both notes — merge or rename to clarify the distinction",
                ))

    return issues


# ── Tier 2: Relational checks ─────────────────────────────────────

def check_relational_gaps(notes: dict[str, NoteInfo]) -> list[Issue]:
    """Check expected relationships between note types."""
    issues = []

    use_cases   = {t: n for t, n in notes.items() if n.note_type == "use-case"}
    user_groups = {t: n for t, n in notes.items() if n.note_type == "user-group"}
    barriers    = {t: n for t, n in notes.items() if n.note_type == "barrier"}
    inspiration = {t: n for t, n in notes.items() if n.note_type == "inspiration"}
    datasets    = {t: n for t, n in notes.items() if n.note_type == "dataset"}

    for title, note in use_cases.items():
        if not note.properties.get("affected-groups"):
            issues.append(Issue(
                tier=2, severity="warning",
                note_path=note.rel_path,
                message="Use case has no affected groups",
                suggestion="Add at least one [[User Group]] to affected-groups:",
            ))
        if not note.properties.get("datasets-needed"):
            issues.append(Issue(
                tier=2, severity="info",
                note_path=note.rel_path,
                message="Use case has no datasets linked",
                suggestion="Add datasets to datasets-needed: or datasets-missing:",
            ))

    for title, note in user_groups.items():
        if not note.properties.get("use-cases"):
            issues.append(Issue(
                tier=2, severity="warning",
                note_path=note.rel_path,
                message="User group has no linked use cases",
                suggestion="Add at least one [[Use Case]] to use-cases:",
            ))

    for title, note in barriers.items():
        if not note.properties.get("use-cases-addressing"):
            issues.append(Issue(
                tier=2, severity="info",
                note_path=note.rel_path,
                message="Barrier has no use cases addressing it",
                suggestion="Add use cases to use-cases-addressing:",
            ))

    for title, note in inspiration.items():
        if not note.properties.get("relevant-use-cases"):
            issues.append(Issue(
                tier=2, severity="info",
                note_path=note.rel_path,
                message="Inspiration note has no linked use cases",
                suggestion="Add relevant-use-cases: to show how this could be replicated",
            ))

    for title, note in datasets.items():
        if not note.properties.get("provider"):
            issues.append(Issue(
                tier=2, severity="warning",
                note_path=note.rel_path,
                message="Dataset has no linked provider",
                suggestion="Add provider: [[Provider Name]] to frontmatter",
            ))

    return issues


# ── Similarity helpers ────────────────────────────────────────────

def _find_near_match(target: str, candidates: set[str]) -> str | None:
    """
    Find the closest matching title for a broken link.
    Uses word-based similarity — handles underscore vs space variants well.

    Priority:
      1. Exact match after normalisation (underscore → space)
      2. Highest word-level Jaccard similarity above threshold
    """
    target_norm = target.replace("_", " ").lower()

    best = None
    best_score = 0.0

    for candidate in candidates:
        candidate_norm = candidate.replace("_", " ").lower()

        # Exact match after normalisation — highest priority, return immediately
        if target_norm == candidate_norm:
            return candidate

        # For numbered notes (e.g. "80_Overview"), require the number to match
        # This prevents "80_Overview" matching "30 Overview"
        target_num = re.match(r'^(\d+)', target_norm)
        candidate_num = re.match(r'^(\d+)', candidate_norm)
        if target_num and candidate_num:
            if target_num.group(1) != candidate_num.group(1):
                continue  # different section numbers — skip

        score = _word_similarity(target_norm, candidate_norm)
        if score > 0.75 and score > best_score:
            best = candidate
            best_score = score

    return best


def _word_similarity(a: str, b: str) -> float:
    """
    Word-level Jaccard similarity.
    More meaningful than character similarity for note titles.
    "Step-Free Route Finder" vs "Step Free Route Finder" → very high
    "10 Overview" vs "20 Overview" → medium (shares "Overview")
    "Financial Dimension" vs "Temporal Disruption" → low
    """
    if not a or not b:
        return 0.0

    # Normalise: lowercase, split on spaces and hyphens
    words_a = set(re.split(r'[\s\-_]+', a.lower()))
    words_b = set(re.split(r'[\s\-_]+', b.lower()))

    # Remove very common single-character or numeric tokens
    noise = {"", "a", "the", "of", "in", "and"}
    words_a -= noise
    words_b -= noise

    if not words_a or not words_b:
        return 0.0

    intersection = words_a & words_b
    union = words_a | words_b

    return len(intersection) / len(union)


# ── Report formatting ─────────────────────────────────────────────

def print_report(report: AuditReport, verbose: bool = False) -> None:
    divider = "─" * 60

    print(f"\n{divider}")
    print(f"  fmn audit — vault health report")
    print(f"  {report.vault}")
    print(f"  {report.timestamp}")
    print(f"{divider}")
    print(f"\n  📊 {report.notes_checked} notes checked")
    print(f"     ❌ {len(report.errors)} errors")
    print(f"     ⚠️  {len(report.warnings)} warnings")
    print(f"     💡 {len(report.infos)} suggestions")

    if not report.issues:
        print(f"\n  ✅ No issues found — vault looks healthy!")
        return

    tiers = {
        1: "Tier 1 — Structural",
        2: "Tier 2 — Relational",
    }

    for tier_num, tier_label in tiers.items():
        tier_issues = [i for i in report.issues if i.tier == tier_num]
        if not tier_issues:
            continue

        print(f"\n  {tier_label} ({len(tier_issues)} issues)")
        print(f"  {'─' * 40}")

        for severity, icon in [("error", "❌"), ("warning", "⚠️ "), ("info", "💡")]:
            severity_issues = [i for i in tier_issues if i.severity == severity]
            if not severity_issues:
                continue

            shown = severity_issues if verbose else severity_issues[:5]
            hidden = len(severity_issues) - len(shown)

            for issue in shown:
                note_name = Path(issue.note_path).stem
                print(f"\n  {icon} {note_name}")
                print(f"     {issue.message}")
                if issue.suggestion:
                    print(f"     → {issue.suggestion}")
                if issue.auto_fixable:
                    print(f"     🔧 auto-fixable with fmn audit --fix")

            if hidden > 0:
                print(f"\n  ... and {hidden} more. Use --verbose to see all.")

    print(f"\n{divider}")
    if report.errors:
        print("  ❌ Fix errors first — broken links degrade the knowledge graph.")
    if report.warnings:
        print("  ⚠️  Warnings reduce vault completeness but don't break anything.")
    if report.infos:
        print("  💡 Suggestions improve connectivity.")
    if any(i.auto_fixable for i in report.issues):
        print("\n  Run `fmn audit --fix` to auto-repair fixable issues.")
    print(f"\n  Run `fmn audit --report` to save this report as a vault note.")
    print(f"{divider}\n")


def _render_report_markdown(report: AuditReport) -> str:
    """Render audit report as a markdown string for saving to .fmn/audit/."""
    date_str = datetime.now().strftime("%Y-%m-%d")

    lines = [
        "---",
        f"title: Audit Report {date_str}",
        "type: audit-report",
        "is-audit-report: true",
        f"generated: {report.timestamp}",
        f"notes-checked: {report.notes_checked}",
        f"errors: {len(report.errors)}",
        f"warnings: {len(report.warnings)}",
        f"suggestions: {len(report.infos)}",
        "tags:",
        "  - audit",
        "  - maintenance",
        "---",
        "",
        f"# Audit Report — {date_str}",
        "",
        f"Generated by `fmn audit` on {report.timestamp}.",
        f"**{report.notes_checked} notes checked** — "
        f"{len(report.errors)} errors, {len(report.warnings)} warnings, "
        f"{len(report.infos)} suggestions.",
        "",
    ]

    tier_labels = {1: "Tier 1 — Structural", 2: "Tier 2 — Relational"}
    for tier_num in [1, 2]:
        tier_issues = [i for i in report.issues if i.tier == tier_num]
        if not tier_issues:
            continue
        lines.append(f"## {tier_labels[tier_num]}")
        lines.append("")
        for severity, label in [("error", "❌ Errors"),
                                  ("warning", "⚠️  Warnings"),
                                  ("info", "💡 Suggestions")]:
            s_issues = [i for i in tier_issues if i.severity == severity]
            if not s_issues:
                continue
            lines.append(f"### {label}")
            lines.append("")
            for issue in s_issues:
                note_name = Path(issue.note_path).stem
                lines.append(f"- **{note_name}** — {issue.message}")
                if issue.suggestion:
                    lines.append(f"  - → {issue.suggestion}")
            lines.append("")

    lines.extend([
        "## Next steps",
        "",
        "- [ ] Fix all errors (broken links)",
        "- [ ] Review warnings and address where possible",
        "- [ ] Run `fmn audit` again after fixes to verify",
        "",
    ])

    return "\n".join(lines)


# ── Auto-fix ──────────────────────────────────────────────────────

def _run_fixes(report: AuditReport, notes: dict, vault: Path) -> None:
    """
    Auto-fix issues marked as auto_fixable.
    Uses fix_from / fix_to fields stored directly on each Issue.
    """
    fixable = [i for i in report.issues if i.auto_fixable and i.fix_from and i.fix_to]
    if not fixable:
        print("  🔧 No auto-fixable issues found.")
        return

    print(f"  🔧 {len(fixable)} auto-fixable issues found:")
    for issue in fixable:
        print(f"     {Path(issue.note_path).stem}: {issue.fix_from} → {issue.fix_to}")

    answer = input("\n  Apply fixes? [y/n]: ").strip().lower()
    if answer not in ("y", "yes"):
        print("  Fixes skipped.")
        return

    # Group fixes by file to avoid reading/writing same file multiple times
    fixes_by_file: dict[str, list[Issue]] = {}
    for issue in fixable:
        fixes_by_file.setdefault(issue.note_path, []).append(issue)

    fixed_files = 0
    fixed_links = 0

    for rel_path, file_issues in fixes_by_file.items():
        note_path = vault / rel_path
        if not note_path.exists():
            print(f"  ⚠️  File not found: {rel_path}")
            continue

        content = note_path.read_text(encoding="utf-8")
        original = content

        for issue in file_issues:
            new_content = content.replace(issue.fix_from, issue.fix_to)
            if new_content != content:
                content = new_content
                fixed_links += 1
                print(f"  ✅ {Path(rel_path).stem}: {issue.fix_from} → {issue.fix_to}")
            else:
                print(f"  ⚠️  Could not find '{issue.fix_from}' in {Path(rel_path).stem}")

        if content != original:
            note_path.write_text(content, encoding="utf-8")
            fixed_files += 1

    print(f"\n  🔧 {fixed_links} links fixed across {fixed_files} files.")
    print(f"     Review with: git -C {vault} diff")


# ── Main entry point ──────────────────────────────────────────────

def run_audit(
    vault: Path,
    verbose: bool = False,
    write_report: bool = False,
    fix: bool = False,
    trend: bool = False,
) -> AuditReport:
    """Run all audit checks. Returns an AuditReport with all issues found."""

    # Show trend and exit if requested
    if trend:
        print_trend(vault)
        return AuditReport(vault=vault, timestamp="", notes_checked=0)

    # Load vault config — initialises .fmn/ on first use
    config = load_config(vault)
    audit_config = config.get("audit", {})
    suppress = set(audit_config.get("suppress_links", []))
    exemptions = audit_config.get("exemptions", {}).get("missing_website", [])
    exemptions_dict = {name: ["website"] for name in exemptions}

    print(f"🔍 Auditing vault: {vault}")
    print(f"   Config: {config.get('vault_name', vault.name)}")

    notes = scan_vault(vault)
    print(f"   Loaded {len(notes)} notes\n")

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    report = AuditReport(
        vault=vault,
        timestamp=timestamp,
        notes_checked=len(notes),
    )

    print("  Tier 1 — structural checks...")
    report.issues.extend(check_broken_links(notes, suppress=suppress))
    report.issues.extend(check_orphaned_notes(notes, vault=vault))
    report.issues.extend(check_missing_properties(notes, exemptions=exemptions_dict))
    report.issues.extend(check_duplicate_titles(notes))

    print("  Tier 2 — relational checks...")
    report.issues.extend(check_relational_gaps(notes))

    print_report(report, verbose=verbose)

    # Always append summary to history
    history_entry = {
        "timestamp": timestamp,
        "notes_checked": report.notes_checked,
        "errors": len(report.errors),
        "warnings": len(report.warnings),
        "suggestions": len(report.infos),
    }
    if report.errors:
        top = report.errors[0]
        history_entry["note"] = top.message[:60]
    append_history(vault, history_entry)

    # Save full report to .fmn/audit/ if requested
    if write_report:
        report_content = _render_report_markdown(report)
        report_path = save_audit_report(vault, report_content, timestamp)
        rel = report_path.relative_to(vault)
        print(f"  📝 Report saved to: {rel}\n")

    if fix:
        _run_fixes(report, notes, vault)

    return report
