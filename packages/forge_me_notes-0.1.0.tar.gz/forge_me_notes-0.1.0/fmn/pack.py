"""
fmn.pack — scan vault and export context pack
"""

import yaml
import frontmatter
from pathlib import Path
from fmn.config import CONTEXT_DIR


def write_yaml(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, sort_keys=False, allow_unicode=True)


def safe_read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return ""


def collect_notes(vault: Path) -> dict:
    """
    Scan vault for all notes with an is-* property set to true.
    Returns a dict keyed by category (the part after "is-").
    """
    notes = {}

    for md_file in sorted(vault.rglob("*.md")):
        try:
            post = frontmatter.load(md_file)
        except Exception:
            continue

        fm = post.metadata

        for key, value in fm.items():
            if key.startswith("is-") and value is True:
                category = key[3:]

                name = (
                    fm.get("dataset-name")
                    or fm.get("provider-name")
                    or fm.get("software-name")
                    or fm.get("format-name")
                    or fm.get("use-case-name")
                    or fm.get("group-name")
                    or fm.get("barrier-name")
                    or fm.get("inspiration-name")
                    or fm.get("title")
                    or md_file.stem
                )

                notes.setdefault(category, []).append({
                    "name": name,
                    "file": str(md_file.relative_to(vault)),
                    "metadata": fm,
                })
                break

    return notes


def export_templates(vault: Path) -> None:
    template_path = vault / "70_Templates"
    out_dir = CONTEXT_DIR / "templates"
    out_dir.mkdir(parents=True, exist_ok=True)

    if not template_path.exists():
        print("  ⚠️  No 70_Templates folder found in vault")
        return

    count = 0
    for tpl in sorted(template_path.glob("*.md")):
        (out_dir / tpl.name).write_text(tpl.read_text(encoding="utf-8"), encoding="utf-8")
        count += 1
    print(f"  📄 {count} templates exported")


def export_note_bodies(notes: dict, vault: Path) -> None:
    out_dir = CONTEXT_DIR / "notes"
    out_dir.mkdir(parents=True, exist_ok=True)
    for items in notes.values():
        for item in items:
            src = vault / item["file"]
            dst = out_dir / src.name
            dst.write_text(safe_read(src), encoding="utf-8")


def export_single_file(notes: dict, vault: Path) -> None:
    combined = []
    for category, items in notes.items():
        combined.append(f"# {category.upper()}\n")
        for item in items:
            src = vault / item["file"]
            combined.append(safe_read(src))
            combined.append("\n\n---\n\n")
    (CONTEXT_DIR / "all.md").write_text("\n".join(combined), encoding="utf-8")


def run_pack(vault: Path, include_notes: bool = False) -> dict:
    print(f"🔍 Scanning vault: {vault}")

    notes = collect_notes(vault)

    print("📦 Exporting metadata...")
    for category, items in notes.items():
        write_yaml(CONTEXT_DIR / "metadata" / f"{category}.yaml", items)

    print("📄 Exporting templates...")
    export_templates(vault)

    if include_notes:
        print("📝 Exporting note bodies...")
        export_note_bodies(notes, vault)

    print("📚 Exporting combined file...")
    export_single_file(notes, vault)

    index = {
        cat: [{"name": i["name"], "file": i["file"]} for i in items]
        for cat, items in notes.items()
    }
    write_yaml(CONTEXT_DIR / "index.yaml", index)

    total = sum(len(v) for v in notes.values())
    print(f"\n📊 {total} notes found across {len(notes)} types:")
    for cat, items in sorted(notes.items()):
        print(f"   {cat}: {len(items)}")

    print(f"\n✅ Context pack ready: {(CONTEXT_DIR / 'all.md').resolve()}")
    return notes
