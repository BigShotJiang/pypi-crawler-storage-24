"""
fmn.generate — send context pack + request to LLM, save output as input/notes.yaml

Supported providers:
  anthropic   Claude via Anthropic API (ANTHROPIC_API_KEY)
  openai      GPT-4o via OpenAI API (OPENAI_API_KEY)
  ollama      Local model via Ollama (free, no key, runs offline)
  manual      Print prompt and wait — paste into any LLM yourself
"""

import os
import sys
import yaml
from pathlib import Path
from fmn.config import CONTEXT_DIR, INPUT_FILE, load_system_prompt
from fmn.cost import estimate_cost, print_cost_estimate

SUPPORTED_PROVIDERS = ("anthropic", "openai", "ollama", "manual")

DEFAULT_MODELS = {
    "anthropic": "claude-haiku-4-5-20251001",
    "openai": "gpt-4o",
    "ollama": "llama3",
}


# ── Context pack ──────────────────────────────────────────────────

def load_context_pack() -> str:
    all_md = CONTEXT_DIR / "all.md"
    if not all_md.exists():
        print("❌  No context pack found.")
        print("    Run `fmn pack` first to generate the context pack.")
        sys.exit(1)
    return all_md.read_text(encoding="utf-8")


def build_user_message(request: str, context: str) -> str:
    return f"""Here is the current state of the OpenMash vault:

<context>
{context}
</context>

Request:
{request}

Return a valid notes.yaml with a top-level 'notes:' list.
Follow all rules in the system prompt exactly."""


# ── Providers ─────────────────────────────────────────────────────

def call_anthropic(system_prompt: str, user_message: str, model: str) -> str:
    try:
        import anthropic
    except ImportError:
        print("❌  anthropic package not installed.")
        print("    Run: pip install anthropic")
        sys.exit(1)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌  ANTHROPIC_API_KEY not set.")
        print("    Add it to your .env file or run: export ANTHROPIC_API_KEY=your_key")
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)
    print(f"🤖 Calling Anthropic Claude ({model})...")
    print("   This may take 30–60 seconds.\n")

    message = client.messages.create(
        model=model,
        max_tokens=8096,
        system=system_prompt,
        messages=[{"role": "user", "content": user_message}],
    )
    return message.content[0].text


def call_openai(system_prompt: str, user_message: str, model: str) -> str:
    try:
        from openai import OpenAI
    except ImportError:
        print("❌  openai package not installed.")
        print("    Run: pip install openai")
        sys.exit(1)

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("❌  OPENAI_API_KEY not set.")
        print("    Add it to your .env file or run: export OPENAI_API_KEY=your_key")
        sys.exit(1)

    client = OpenAI(api_key=api_key)
    print(f"🤖 Calling OpenAI ({model})...")
    print("   This may take 30–60 seconds.\n")

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
        max_tokens=8096,
    )
    return response.choices[0].message.content


def call_ollama(system_prompt: str, user_message: str, model: str) -> str:
    try:
        import requests
    except ImportError:
        print("❌  requests package not installed.")
        print("    Run: pip install requests")
        sys.exit(1)

    ollama_url = os.environ.get("OLLAMA_URL", "http://localhost:11434")

    print(f"🤖 Calling Ollama ({model} at {ollama_url})...")
    print("   Make sure Ollama is running: ollama serve")
    print(f"   And the model is pulled: ollama pull {model}\n")

    try:
        response = requests.post(
            f"{ollama_url}/api/chat",
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message},
                ],
                "stream": False,
            },
            timeout=300,
        )
        response.raise_for_status()
        return response.json()["message"]["content"]

    except requests.exceptions.ConnectionError:
        print(f"❌  Could not connect to Ollama at {ollama_url}")
        print("    Start Ollama with: ollama serve")
        print("    Or set OLLAMA_URL in your .env if running elsewhere")
        sys.exit(1)
    except Exception as e:
        print(f"❌  Ollama error: {e}")
        sys.exit(1)


def call_manual(system_prompt: str, user_message: str) -> str:
    """Print the full prompt for the user to paste into any LLM manually."""
    divider = "─" * 60

    print(f"\n{divider}")
    print("  MANUAL MODE — paste the following into any LLM")
    print(f"{divider}")
    print("\n📋 SYSTEM PROMPT:\n")
    print(system_prompt)
    print(f"\n{divider}")
    print("\n📋 USER MESSAGE:\n")
    print(user_message)
    print(f"\n{divider}")
    print("\nSuggested free LLMs:")
    print("  • Claude.ai    — claude.ai/chat")
    print("  • ChatGPT      — chat.openai.com")
    print("  • Gemini       — gemini.google.com")
    print("  • Mistral      — chat.mistral.ai")
    print()
    print("Instructions:")
    print("  1. Open any LLM chat interface above")
    print("  2. Paste the SYSTEM PROMPT first, then the USER MESSAGE")
    print("  3. Copy the full YAML response")
    print("  4. Paste it below and press Ctrl+D (Linux/Mac) or Ctrl+Z (Windows)")
    print(f"\n{divider}")
    print("Paste YAML response here:\n")

    lines = []
    try:
        while True:
            line = input()
            lines.append(line)
    except EOFError:
        pass

    return "\n".join(lines)


# ── YAML parsing ──────────────────────────────────────────────────

def parse_yaml_response(raw: str) -> list:
    """Parse YAML from LLM response. Strips markdown fences if present."""
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        cleaned = "\n".join(lines[1:-1]).strip()

    try:
        data = yaml.safe_load(cleaned)
    except yaml.YAMLError as e:
        print(f"❌  LLM returned invalid YAML:\n{e}")
        _save_debug(raw)
        sys.exit(1)

    if not isinstance(data, dict) or "notes" not in data:
        print("❌  Response does not contain a top-level 'notes:' list.")
        _save_debug(raw)
        sys.exit(1)

    return data["notes"]


def _save_debug(raw: str) -> None:
    debug_file = CONTEXT_DIR / "last_response.txt"
    CONTEXT_DIR.mkdir(parents=True, exist_ok=True)
    debug_file.write_text(raw, encoding="utf-8")
    print(f"    Raw response saved to: {debug_file}")


def save_notes(notes: list) -> None:
    INPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(INPUT_FILE, "w", encoding="utf-8") as f:
        yaml.dump({"notes": notes}, f, sort_keys=False, allow_unicode=True)


# ── Model picker helpers ─────────────────────────────────────────

PROVIDER_MODELS = {
    "anthropic": [
        ("claude-haiku-4-5-20251001",  "Haiku  — fast, cheap, good for most tasks"),
        ("claude-sonnet-4-20250514",   "Sonnet — better linking and body text, 4x cost"),
        ("claude-opus-4-20250514",     "Opus   — best quality, ~20x cost, rarely needed"),
    ],
    "openai": [
        ("gpt-4o-mini",  "GPT-4o mini — cheapest, decent YAML"),
        ("gpt-4o",       "GPT-4o      — reliable, good quality"),
        ("gpt-4-turbo",  "GPT-4 Turbo — high quality, expensive"),
    ],
}


def _available_models(provider: str) -> list[str]:
    return [m for m, _ in PROVIDER_MODELS.get(provider, [])]


def _print_model_picker(system_prompt: str, user_message: str, provider: str) -> None:
    models = PROVIDER_MODELS.get(provider)
    if not models:
        return  # ollama / manual — no picker needed

    print("\n  Available models for this provider:")
    for model_name, description in models:
        e = estimate_cost(system_prompt, user_message, model_name, provider)
        cost_str = f"~€{e['total_cost_eur']:.4f}"
        print(f"    {model_name:<35}  {cost_str:<12}  {description}")

    print()
    print("  Enter a model name to switch, or just press y to use the current model.")


# ── Main entry point ──────────────────────────────────────────────

def run_generate(
    vault: Path,
    request: str,
    provider: str = "anthropic",
    model: str | None = None,
) -> list:
    """
    Generate notes from a plain English request.
    Returns the list of notes for use by fmn run.
    """
    if provider not in SUPPORTED_PROVIDERS:
        print(f"❌  Unknown provider: {provider}")
        print(f"    Supported: {', '.join(SUPPORTED_PROVIDERS)}")
        sys.exit(1)

    if model is None:
        model = DEFAULT_MODELS.get(provider, "")

    system_prompt = load_system_prompt()
    context = load_context_pack()
    user_message = build_user_message(request, context)

    # Show cost estimate before any API call
    estimate = estimate_cost(system_prompt, user_message, model, provider)
    print_cost_estimate(estimate)

    # Ask confirmation for paid providers — show model picker
    if not estimate.get("free"):
        _print_model_picker(system_prompt, user_message, provider)
        while True:
            answer = input("\n  Choice [y / n / manual / model name]: ").strip().lower()
            if answer in ("y", "yes"):
                break
            elif answer in ("n", "no"):
                print("\n  Aborted. To proceed without cost, run:")
                print(f'  fmn generate "{request}" --provider manual')
                sys.exit(0)
            elif answer == "manual":
                print("\n  Switching to manual mode...")
                provider = "manual"
                break
            elif answer in _available_models(provider):
                model = answer
                new_estimate = estimate_cost(system_prompt, user_message, model, provider)
                print_cost_estimate(new_estimate)
                break
            else:
                print(f"  Unknown input. Enter y, n, manual, or a model name from the list above.")

    if provider == "anthropic":
        raw = call_anthropic(system_prompt, user_message, model)
    elif provider == "openai":
        raw = call_openai(system_prompt, user_message, model)
    elif provider == "ollama":
        raw = call_ollama(system_prompt, user_message, model)
    elif provider == "manual":
        raw = call_manual(system_prompt, user_message)

    _save_debug(raw)
    notes = parse_yaml_response(raw)
    save_notes(notes)

    print(f"\n✅ Generated {len(notes)} notes → saved to {INPUT_FILE}")
    for note in notes:
        print(f"   + {note.get('title', note.get('output_path', '?'))}")

    return notes
