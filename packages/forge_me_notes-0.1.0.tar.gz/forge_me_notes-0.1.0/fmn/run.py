"""
fmn.run — orchestrate pack + generate + dry run confirm + write
"""

import sys
from pathlib import Path
from fmn.pack import run_pack
from fmn.generate import run_generate
from fmn.write import dry_run, run_write


def confirm(prompt: str = "Proceed?") -> bool:
    """Ask for y/n confirmation. Returns True if user confirms."""
    while True:
        answer = input(f"\n{prompt} [y/n]: ").strip().lower()
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no"):
            return False
        print("  Please enter y or n.")


def suggest_commit_message(notes: list, written: int) -> str:
    """
    Generate a conventional commit message from the notes list.
    No API calls — purely derived from note metadata we already have.
    """
    if not notes or written == 0:
        return "chore: no notes written"

    # Count by type
    type_counts: dict[str, int] = {}
    for note in notes:
        t = note.get("type", "note")
        type_counts[t] = type_counts.get(t, 0) + 1

    # Decide prefix
    doc_types = {"overview", "template", "base"}
    content_types = {"user-group", "barrier", "use-case", "inspiration",
                     "workshop", "dataset", "provider", "format", "software"}

    has_content = any(t in content_types for t in type_counts)
    prefix = "feat" if has_content else "docs"

    # Build human-readable summary
    type_labels = {
        "user-group":  "user group",
        "barrier":     "barrier",
        "use-case":    "use case",
        "inspiration": "inspiration",
        "workshop":    "workshop",
        "dataset":     "dataset",
        "provider":    "provider",
        "format":      "format",
        "software":    "software",
        "overview":    "overview",
        "template":    "template",
        "base":        "base view",
        "dimension":   "dimension",
    }

    parts = []
    for t, count in sorted(type_counts.items()):
        label = type_labels.get(t, t)
        if count > 1:
            label = label + "s"
        parts.append(f"{count} {label}")

    summary = ", ".join(parts)

    # If only one or two notes, name them directly — more useful than counts
    if written <= 2:
        titles = [n.get("title", n.get("output_path", "")) for n in notes]
        summary = " + ".join(f'"{t}"' for t in titles if t)

    return f"{prefix}: add {summary}"


def run_all(
    vault: Path,
    request: str,
    force: bool = False,
    provider: str = "anthropic",
    model: str | None = None,
) -> None:
    """
    Full pipeline:
      1. Pack vault → context/all.md
      2. Generate notes → input/notes.yaml
      3. Show dry run summary
      4. Ask for confirmation
      5. Write notes to vault
      6. Print suggested commit message
    """

    # ── Step 1: Pack ──────────────────────────────────────────────
    print("=" * 60)
    print("  Step 1/3 — Packing vault")
    print("=" * 60)
    run_pack(vault=vault, include_notes=False)

    # ── Step 2: Generate ──────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  Step 2/3 — Generating notes")
    print("=" * 60)
    notes = run_generate(vault=vault, request=request, provider=provider, model=model)

    # ── Step 3: Dry run + confirm ─────────────────────────────────
    print("\n" + "=" * 60)
    print("  Step 3/3 — Review and confirm")
    print("=" * 60)
    actions = dry_run(vault=vault, notes=notes, force=force)

    will_act = [a for a in actions if a[2] in ("create", "overwrite")]
    if not will_act:
        print("\n  Nothing to do — all notes already exist. Use --force to overwrite.")
        sys.exit(0)

    if not confirm("Write these notes to the vault?"):
        print("\n  Aborted. input/notes.yaml has been saved — run `fmn write` to apply later.")
        sys.exit(0)

    # ── Write ──────────────────────────────────────────────────────
    print("\nWriting files...")
    written = run_write(vault=vault, force=force, notes=notes)

    # ── Done — suggest commit ──────────────────────────────────────
    commit_msg = suggest_commit_message(notes, written)

    print(f"\n✅ Done — {written} notes written to vault.")
    print(f"\n💬 Suggested commit:")
    print(f"\n   git -C {vault} add .")
    print(f'   git -C {vault} commit -m "{commit_msg}"')
