"""forge-me-notes — fmn package"""
__version__ = "0.1.0"
