"""
fmn.vault_config — manage the .fmn/ directory inside a vault

The .fmn/ directory is vault infrastructure — hidden from Obsidian's
file explorer, not part of the knowledge graph, but essential for
tool configuration and history tracking.

Structure:
  .fmn/
  ├── config.yaml      vault-level configuration (commit this)
  ├── history.yaml     audit trend data (commit this)
  └── audit/           full audit reports per run (optionally gitignore)

Design principle: convention over configuration (Rails, Django)
The directory structure is fixed. No setup required — it creates itself
on first use.
"""

import yaml
from pathlib import Path
from datetime import datetime


# ── Directory paths ───────────────────────────────────────────────

def fmn_dir(vault: Path) -> Path:
    return vault / ".fmn"

def audit_dir(vault: Path) -> Path:
    return fmn_dir(vault) / "audit"

def config_path(vault: Path) -> Path:
    return fmn_dir(vault) / "config.yaml"

def history_path(vault: Path) -> Path:
    return fmn_dir(vault) / "history.yaml"


# ── Initialisation ────────────────────────────────────────────────

def init_fmn_dir(vault: Path) -> None:
    """
    Create the .fmn/ directory structure if it doesn't exist.
    Called automatically on first use — no manual setup needed.
    """
    fmn_dir(vault).mkdir(exist_ok=True)
    audit_dir(vault).mkdir(exist_ok=True)

    # Create default config if missing
    if not config_path(vault).exists():
        _write_default_config(vault)

    # Create empty history if missing
    if not history_path(vault).exists():
        _write_yaml(history_path(vault), {"audit_history": []})

    # Add .gitignore for audit reports if not present
    gitignore = fmn_dir(vault) / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(
            "# Audit reports can be large — uncomment to ignore\n"
            "# audit/\n",
            encoding="utf-8",
        )


def _write_default_config(vault: Path) -> None:
    """Write a default config.yaml with sensible defaults."""
    vault_name = vault.name.replace("-", " ").replace("_", " ").title()

    config = {
        "vault_name": vault_name,
        "vault_type": "unknown",
        "framework": "unknown",
        "fmn_version": _get_fmn_version(),
        "audit": {
            "exemptions": {
                "missing_website": [
                    "Browser",
                    "Samba Client",
                ],
            },
            "suppress_links": [
                "wikilinks",
                "Note Title",
                "User Group",
                "Provider Name",
                "Dataset Name",
                "Format Name",
            ],
        },
    }
    _write_yaml(config_path(vault), config)


def _get_fmn_version() -> str:
    try:
        from fmn import __version__
        return __version__
    except ImportError:
        return "unknown"


# ── Config reading ────────────────────────────────────────────────

def load_config(vault: Path) -> dict:
    """
    Load vault config from .fmn/config.yaml.
    Initialises .fmn/ directory on first use.
    Returns merged config (defaults + vault overrides).
    """
    init_fmn_dir(vault)

    with open(config_path(vault), "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    return _merge_defaults(config)


def _merge_defaults(config: dict) -> dict:
    """Ensure all expected keys exist with sensible defaults."""
    defaults = {
        "vault_name": "My Vault",
        "vault_type": "unknown",
        "framework": "unknown",
        "fmn_version": _get_fmn_version(),
        "audit": {
            "exemptions": {
                "missing_website": ["Browser", "Samba Client"],
            },
            "suppress_links": [
                "wikilinks", "Note Title", "User Group",
                "Provider Name", "Dataset Name", "Format Name",
            ],
        },
    }

    # Deep merge — config overrides defaults, but missing keys get defaults
    merged = {**defaults, **config}
    merged["audit"] = {
        **defaults["audit"],
        **config.get("audit", {}),
    }
    merged["audit"]["exemptions"] = {
        **defaults["audit"]["exemptions"],
        **config.get("audit", {}).get("exemptions", {}),
    }
    merged["audit"]["suppress_links"] = config.get(
        "audit", {}
    ).get("suppress_links", defaults["audit"]["suppress_links"])

    return merged


# ── History tracking ──────────────────────────────────────────────

def load_history(vault: Path) -> list:
    """Load audit history from .fmn/history.yaml."""
    init_fmn_dir(vault)
    with open(history_path(vault), "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return data.get("audit_history", [])


def append_history(vault: Path, entry: dict) -> None:
    """Append an audit result to .fmn/history.yaml."""
    init_fmn_dir(vault)
    history = load_history(vault)
    history.append(entry)
    _write_yaml(history_path(vault), {"audit_history": history})


def save_audit_report(vault: Path, content: str, timestamp: str) -> Path:
    """
    Save a full audit report to .fmn/audit/<timestamp>.md
    Returns the path of the saved report.
    """
    init_fmn_dir(vault)
    # Sanitise timestamp for filename: "2026-03-17 09:04" → "2026-03-17T09-04"
    safe_ts = timestamp.replace(" ", "T").replace(":", "-")
    report_path = audit_dir(vault) / f"{safe_ts}.md"
    report_path.write_text(content, encoding="utf-8")
    return report_path


def print_trend(vault: Path, limit: int = 10) -> None:
    """Print audit history as a trend table."""
    history = load_history(vault)

    if not history:
        print("  No audit history found.")
        print("  Run `fmn audit` to start tracking vault health.")
        return

    # Deduplicate only entries with the EXACT same timestamp (minute precision)
    # This collapses multiple runs within the same minute but preserves all others
    deduped = []
    for entry in history:
        ts = entry.get("timestamp", "")[:16]
        if deduped and deduped[-1].get("timestamp", "")[:16] == ts:
            deduped[-1] = entry  # same minute — keep latest
        else:
            deduped.append(entry)

    recent = deduped[-limit:]

    print(f"\n  📈 Vault health trend (last {len(recent)} audits)\n")
    print(f"  {'Timestamp':<20} {'❌ Errors':>10} {'⚠️  Warnings':>13} {'💡 Info':>8}  Notes")
    print(f"  {'─' * 20} {'─' * 10} {'─' * 13} {'─' * 8}  {'─' * 30}")

    for entry in recent:
        ts       = entry.get("timestamp", "unknown")[:16]
        errors   = entry.get("errors", 0)
        warnings = entry.get("warnings", 0)
        infos    = entry.get("suggestions", 0)
        note     = entry.get("note", "")

        # Trend indicator vs previous entry
        idx = recent.index(entry)
        if idx == 0:
            trend = "baseline"
        else:
            prev = recent[idx - 1]
            prev_total = prev.get("errors", 0) + prev.get("warnings", 0)
            curr_total = errors + warnings
            if curr_total < prev_total:
                diff = prev_total - curr_total
                trend = f"↓ -{diff} issues"
            elif curr_total > prev_total:
                diff = curr_total - prev_total
                trend = f"↑ +{diff} issues"
            else:
                trend = "→ unchanged"

        print(f"  {ts:<20} {errors:>10} {warnings:>13} {infos:>8}  {trend}")
        if note:
            print(f"  {'':20} {'':>10} {'':>13} {'':>8}  {note}")

    # Summary
    if len(recent) >= 2:
        first = recent[0]
        last = recent[-1]
        first_total = first.get("errors", 0) + first.get("warnings", 0)
        last_total = last.get("errors", 0) + last.get("warnings", 0)
        delta = last_total - first_total
        if delta < 0:
            print(f"\n  ✅ Overall trend: {abs(delta)} fewer issues since first audit")
        elif delta > 0:
            print(f"\n  ⚠️  Overall trend: {delta} more issues since first audit")
        else:
            print(f"\n  → Overall trend: unchanged")
    print()


# ── Helpers ───────────────────────────────────────────────────────

def _write_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, sort_keys=False, allow_unicode=True,
                  default_flow_style=False)
