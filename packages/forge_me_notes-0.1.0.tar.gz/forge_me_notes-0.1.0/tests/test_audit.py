"""
tests/test_audit.py — unit and integration tests for fmn.audit

Run with:
  pytest tests/test_audit.py -v
  pytest tests/test_audit.py -v --tb=short   # compact tracebacks
"""

import sys
import unittest
from pathlib import Path
from datetime import datetime

# Allow running from repo root
sys.path.insert(0, str(Path(__file__).parent.parent))

from fmn.audit import (
    extract_wikilinks,
    _find_near_match,
    _word_similarity,
    _is_infrastructure,
    _is_infrastructure_by_type,
    check_broken_links,
    check_orphaned_notes,
    check_missing_properties,
    check_duplicate_titles,
    check_relational_gaps,
    NoteInfo,
    AuditReport,
    Issue,
)


# ── Fixtures ──────────────────────────────────────────────────────

VAULT = Path("/fake/vault")


def make_note(
    title: str,
    note_type: str = "unknown",
    rel_path: str = "",
    properties: dict = None,
    body: str = "",
    outbound_links: list = None,
) -> NoteInfo:
    """Factory for NoteInfo test objects."""
    if not rel_path:
        rel_path = f"Notes/{title}.md"
    return NoteInfo(
        path=VAULT / rel_path,
        rel_path=rel_path,
        title=title,
        properties=properties or {f"is-{note_type}": True},
        body=body,
        outbound_links=outbound_links or [],
        note_type=note_type,
    )


# ── Unit tests: wikilink extraction ──────────────────────────────

class TestExtractWikilinks(unittest.TestCase):
    def test_simple_link(self):
        links = extract_wikilinks("See [[Step-Free Route Finder]] for details.")
        assert "Step-Free Route Finder" in links

    def test_multiple_links(self):
        links = extract_wikilinks("[[Wheelchair Users]] and [[Elderly People]] benefit.")
        assert "Wheelchair Users" in links
        assert "Elderly People" in links

    def test_link_with_alias(self):
        links = extract_wikilinks("See [[Wheelchair Users|wheelchair users]] here.")
        assert "Wheelchair Users" in links

    def test_link_with_path_prefix(self):
        links = extract_wikilinks("See [[10_User_Groups/Wheelchair Users]] here.")
        assert "10_User_Groups/Wheelchair Users" in links

    def test_no_links(self):
        links = extract_wikilinks("No links in this text.")
        assert links == []

    def test_empty_string(self):
        links = extract_wikilinks("")
        assert links == []

    def test_deduplicates(self):
        # extract_wikilinks returns raw matches — dedup happens in load_note via set()
        # The function itself may return duplicates; that is intentional
        links = extract_wikilinks("[[Elderly People]] and [[Elderly People]] again.")
        assert "Elderly People" in links


# ── Unit tests: similarity ────────────────────────────────────────

class TestWordSimilarity(unittest.TestCase):
    def test_identical(self):
        assert _word_similarity("Step-Free Route Finder", "Step-Free Route Finder") == 1.0

    def test_hyphen_vs_space(self):
        score = _word_similarity("Step-Free Route Finder", "Step Free Route Finder")
        assert score > 0.85, f"Expected >0.85, got {score}"

    def test_underscore_vs_space(self):
        score = _word_similarity("61_Getting_Started", "61 Getting Started")
        assert score > 0.85

    def test_numbered_overviews_are_similar(self):
        # "10 Overview" vs "20 Overview": shares "overview", differs on number
        # Jaccard = 1 shared / 3 union = 0.33 — similar enough to be risky
        # This is WHY we explicitly skip numbered overviews in duplicate detection
        score = _word_similarity("10 Overview", "20 Overview")
        assert 0.2 < score < 0.8  # similar but not identical

    def test_unrelated_notes_are_dissimilar(self):
        score = _word_similarity("Financial Dimension", "Temporal Disruption")
        assert score < 0.3, f"Expected <0.3, got {score}"

    def test_empty_strings(self):
        assert _word_similarity("", "anything") == 0.0
        assert _word_similarity("anything", "") == 0.0


class TestFindNearMatch(unittest.TestCase):
    def test_underscore_to_space(self):
        candidates = {"61 Getting Started", "Wheelchair Users", "Elderly People"}
        result = _find_near_match("61_Getting_Started", candidates)
        assert result == "61 Getting Started"

    def test_exact_after_normalisation(self):
        candidates = {"LLM Prompt Guide", "The Workflow"}
        result = _find_near_match("LLM_Prompt_Guide", candidates)
        assert result == "LLM Prompt Guide"

    def test_no_match_returns_none(self):
        candidates = {"Wheelchair Users", "Elderly People"}
        result = _find_near_match("CompletelyUnrelated", candidates)
        assert result is None

    def test_numbered_overview_fix(self):
        candidates = {"10 Overview", "20 Overview", "30 Overview"}
        result = _find_near_match("10_Overview", candidates)
        assert result == "10 Overview"


# ── Unit tests: infrastructure detection ─────────────────────────

class TestIsInfrastructure(unittest.TestCase):
    def test_template_folder(self):
        path = VAULT / "70_Templates/T_Use_Case.md"
        assert _is_infrastructure(path, VAULT) is True

    def test_obsidian_config(self):
        path = VAULT / ".obsidian/workspace.json"
        assert _is_infrastructure(path, VAULT) is True

    def test_base_file(self):
        path = VAULT / "30_Use_Cases/Use Cases.base"
        assert _is_infrastructure(path, VAULT) is True  # suffix != .md

    def test_audit_report(self):
        path = VAULT / "Audit Report 2026-03-17.md"
        assert _is_infrastructure(path, VAULT) is True

    def test_underscore_prefix(self):
        path = VAULT / "00_About/_hidden.md"
        assert _is_infrastructure(path, VAULT) is True

    def test_normal_content_note(self):
        path = VAULT / "10_User_Groups/Wheelchair Users.md"
        assert _is_infrastructure(path, VAULT) is False

    def test_start_here(self):
        path = VAULT / "START HERE.md"
        assert _is_infrastructure(path, VAULT) is False


class TestIsInfrastructureByType(unittest.TestCase):
    def test_template_type(self):
        note = make_note("T_Use_Case", properties={"type": "template"})
        assert _is_infrastructure_by_type(note) is True

    def test_base_type(self):
        note = make_note("Use Cases", properties={"type": "base"})
        assert _is_infrastructure_by_type(note) is True

    def test_content_type(self):
        note = make_note("Wheelchair Users", properties={"type": "user-group", "is-user-group": True})
        assert _is_infrastructure_by_type(note) is False


# ── Unit tests: check_broken_links ───────────────────────────────

class TestCheckBrokenLinks(unittest.TestCase):
    def test_detects_broken_link(self):
        notes = {
            "My Note": make_note(
                "My Note",
                outbound_links=["Nonexistent Note"]
            )
        }
        issues = check_broken_links(notes)
        assert len(issues) == 1
        assert issues[0].severity == "error"
        assert "Nonexistent Note" in issues[0].message

    def test_valid_link_no_issue(self):
        notes = {
            "Note A": make_note("Note A", outbound_links=["Note B"]),
            "Note B": make_note("Note B"),
        }
        issues = check_broken_links(notes)
        assert issues == []

    def test_underscore_link_is_fixable(self):
        notes = {
            "My Note": make_note(
                "My Note",
                outbound_links=["61_Getting_Started"]
            ),
            "61 Getting Started": make_note("61 Getting Started"),
        }
        issues = check_broken_links(notes)
        assert len(issues) == 1
        assert issues[0].auto_fixable is True
        assert issues[0].fix_from == "[[61_Getting_Started]]"
        assert issues[0].fix_to == "[[61 Getting Started]]"

    def test_suppressed_terms_ignored(self):
        notes = {
            "My Note": make_note(
                "My Note",
                outbound_links=["wikilinks", "Note Title"]
            )
        }
        issues = check_broken_links(notes)
        assert issues == []

    def test_base_embed_not_flagged_as_broken(self):
        # ![[User Groups.base]] should never be flagged as a broken link
        notes = {
            "10 Overview": make_note(
                "10 Overview",
                outbound_links=["User Groups.base", "Wheelchair Users"]
            ),
            "Wheelchair Users": make_note("Wheelchair Users", "user-group"),
        }
        issues = check_broken_links(notes)
        # Only flag if the .base suppress is missing — should be 0 issues
        assert all(".base" not in i.message for i in issues), \
            f"Base embed incorrectly flagged: {[i.message for i in issues]}"

    def test_path_prefix_resolved(self):
        # [[10_User_Groups/Wheelchair Users]] should resolve to "Wheelchair Users"
        notes = {
            "My Note": make_note(
                "My Note",
                outbound_links=["10_User_Groups/Wheelchair Users"]
            ),
            "Wheelchair Users": make_note("Wheelchair Users"),
        }
        issues = check_broken_links(notes)
        assert issues == []


# ── Unit tests: check_orphaned_notes ─────────────────────────────

class TestCheckOrphanedNotes(unittest.TestCase):
    def test_detects_orphan(self):
        notes = {
            "Linked Note": make_note("Linked Note", "use-case"),
            "Orphan Note": make_note("Orphan Note", "use-case"),
            "Parent Note": make_note(
                "Parent Note", "overview",
                outbound_links=["Linked Note"]
            ),
        }
        issues = check_orphaned_notes(notes)
        orphan_messages = [i.note_path for i in issues]
        assert any("Orphan Note" in p for p in orphan_messages)

    def test_overview_notes_not_flagged(self):
        # Overview notes are exempt — they're not expected to have inbound links
        notes = {
            "10 Overview": make_note("10 Overview", "overview"),
        }
        issues = check_orphaned_notes(notes)
        assert issues == []

    def test_start_here_not_flagged(self):
        notes = {
            "START HERE": make_note("START HERE", "unknown"),
        }
        issues = check_orphaned_notes(notes)
        assert issues == []


# ── Unit tests: check_missing_properties ─────────────────────────

class TestCheckMissingProperties(unittest.TestCase):
    def test_use_case_missing_city(self):
        notes = {
            "My Use Case": make_note(
                "My Use Case", "use-case",
                properties={
                    "is-use-case": True,
                    "difficulty": 2,
                    "impact": 3,
                    "status": "idea",
                    "affected-groups": ["[[Elderly People]]"],
                    # city is missing
                }
            )
        }
        issues = check_missing_properties(notes)
        assert any("city" in i.message for i in issues)

    def test_browser_exempt_from_website(self):
        notes = {
            "Browser": make_note(
                "Browser", "software",
                properties={"is-software": True, "license": "varies"}
                # website intentionally missing — Browser IS a browser
            )
        }
        issues = check_missing_properties(notes)
        assert not any("website" in i.message for i in issues)

    def test_complete_note_no_issues(self):
        notes = {
            "My Provider": make_note(
                "My Provider", "provider",
                properties={
                    "is-provider": True,
                    "website": "https://example.com",
                }
            )
        }
        issues = check_missing_properties(notes)
        assert issues == []


# ── Unit tests: check_duplicate_titles ───────────────────────────

class TestCheckDuplicateTitles(unittest.TestCase):
    def test_numbered_overviews_not_flagged(self):
        notes = {
            "10 Overview": make_note("10 Overview", "overview"),
            "20 Overview": make_note("20 Overview", "overview"),
            "30 Overview": make_note("30 Overview", "overview"),
        }
        issues = check_duplicate_titles(notes)
        assert issues == []

    def test_genuine_duplicate_flagged(self):
        notes = {
            "Step-Free Route Finder": make_note("Step-Free Route Finder", "use-case"),
            "Step Free Route Finder": make_note("Step Free Route Finder", "use-case"),
        }
        issues = check_duplicate_titles(notes)
        assert len(issues) == 1
        assert "Step" in issues[0].message

    def test_different_types_not_flagged(self):
        # "Mobility" as both a dataset and a dimension — different types
        notes = {
            "Mobility": make_note("Mobility", "dataset"),
            "Mobility Dimension": make_note("Mobility Dimension", "dimension"),
        }
        issues = check_duplicate_titles(notes)
        assert issues == []

    def test_financial_dimension_not_flagged_as_temporal_disruption(self):
        notes = {
            "Financial Dimension": make_note("Financial Dimension", "dimension"),
            "Temporal Disruption": make_note("Temporal Disruption", "barrier"),
        }
        issues = check_duplicate_titles(notes)
        assert issues == []


# ── Unit tests: check_relational_gaps ────────────────────────────

class TestCheckRelationalGaps(unittest.TestCase):
    def test_use_case_no_groups_flagged(self):
        notes = {
            "My Use Case": make_note(
                "My Use Case", "use-case",
                properties={
                    "is-use-case": True,
                    "affected-groups": [],  # empty
                    "datasets-needed": ["[[Some Dataset]]"],
                }
            )
        }
        issues = check_relational_gaps(notes)
        assert any("no affected groups" in i.message for i in issues)

    def test_user_group_no_use_cases_flagged(self):
        notes = {
            "Elderly People": make_note(
                "Elderly People", "user-group",
                properties={
                    "is-user-group": True,
                    "primary-barriers": ["[[Physical Infrastructure]]"],
                    "use-cases": [],  # empty
                }
            )
        }
        issues = check_relational_gaps(notes)
        assert any("no linked use cases" in i.message for i in issues)

    def test_dataset_no_provider_flagged(self):
        notes = {
            "My Dataset": make_note(
                "My Dataset", "dataset",
                properties={
                    "is-dataset": True,
                    "license": "CC-BY",
                    "download-link": "https://example.com",
                    "formats": ["[[CSV]]"],
                    "provider": [],  # empty
                }
            )
        }
        issues = check_relational_gaps(notes)
        assert any("no linked provider" in i.message for i in issues)


# ── Unit tests: AuditReport ───────────────────────────────────────

class TestAuditReport(unittest.TestCase):
    def test_severity_grouping(self):
        report = AuditReport(
            vault=VAULT,
            timestamp="2026-03-17 09:00",
            notes_checked=10,
            issues=[
                Issue(tier=1, severity="error", note_path="a.md", message="err"),
                Issue(tier=1, severity="warning", note_path="b.md", message="warn"),
                Issue(tier=2, severity="info", note_path="c.md", message="info"),
            ]
        )
        assert len(report.errors) == 1
        assert len(report.warnings) == 1
        assert len(report.infos) == 1

    def test_empty_report(self):
        report = AuditReport(
            vault=VAULT,
            timestamp="2026-03-17 09:00",
            notes_checked=0,
        )
        assert report.errors == []
        assert report.warnings == []
        assert report.infos == []


# ── Integration test: fix_from / fix_to on broken link issues ────

class TestFixFields(unittest.TestCase):
    def test_fixable_issue_has_fix_fields(self):
        notes = {
            "My Note": make_note(
                "My Note",
                outbound_links=["10_Overview"]
            ),
            "10 Overview": make_note("10 Overview", "overview"),
        }
        issues = check_broken_links(notes)
        fixable = [i for i in issues if i.auto_fixable]
        assert len(fixable) == 1
        assert fixable[0].fix_from == "[[10_Overview]]"
        assert fixable[0].fix_to == "[[10 Overview]]"

    def test_unfixable_issue_has_empty_fix_fields(self):
        notes = {
            "My Note": make_note(
                "My Note",
                outbound_links=["CompletelyMadeUpNote"]
            )
        }
        issues = check_broken_links(notes)
        assert len(issues) == 1
        assert issues[0].auto_fixable is False
        assert issues[0].fix_from == "[[CompletelyMadeUpNote]]"
        assert issues[0].fix_to == ""


class TestBaseImplicitLinks(unittest.TestCase):
    """Test that .base files are read and count as implicit inbound links."""

    def setUp(self):
        import tempfile
        self.vault_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        import shutil
        shutil.rmtree(self.vault_dir)

    def test_base_file_covers_matching_type(self):
        # Write a .base file that filters is-inspiration = true
        base_content = """views:
  - type: table
    name: Table
    filters:
      and:
        - note["is-inspiration"] == true
"""
        (self.vault_dir / "40_Inspiration").mkdir()
        (self.vault_dir / "40_Inspiration" / "Inspiration.base").write_text(
            base_content, encoding="utf-8"
        )

        from fmn.audit import _collect_base_implicit_links, NoteInfo
        notes = {
            "Helsinki Accessibility Map": NoteInfo(
                path=self.vault_dir / "Helsinki.md",
                rel_path="Helsinki.md",
                title="Helsinki Accessibility Map",
                properties={"is-inspiration": True},
                body="", outbound_links=[], note_type="inspiration",
            ),
            "Wheelchair Users": NoteInfo(
                path=self.vault_dir / "Wheelchair.md",
                rel_path="Wheelchair.md",
                title="Wheelchair Users",
                properties={"is-user-group": True},
                body="", outbound_links=[], note_type="user-group",
            ),
        }

        implicit = _collect_base_implicit_links(self.vault_dir, notes)

        # Inspiration note should be covered by the base
        assert "Helsinki Accessibility Map" in implicit
        # User group should NOT be covered (wrong type)
        assert "Wheelchair Users" not in implicit

    def test_orphan_check_respects_base_coverage(self):
        # A note covered by a base should not be flagged as orphaned
        (self.vault_dir / "40_Inspiration").mkdir()
        (self.vault_dir / "40_Inspiration" / "Inspiration.base").write_text(
            'views:\n  - type: table\n    filters:\n      and:\n        - note["is-inspiration"] == true\n',
            encoding="utf-8"
        )

        from fmn.audit import check_orphaned_notes, NoteInfo
        notes = {
            "Helsinki Accessibility Map": NoteInfo(
                path=self.vault_dir / "Helsinki.md",
                rel_path="Helsinki.md",
                title="Helsinki Accessibility Map",
                properties={"is-inspiration": True},
                body="", outbound_links=[], note_type="inspiration",
            ),
        }

        issues = check_orphaned_notes(notes, vault=self.vault_dir)
        # Should NOT be flagged — covered by the base
        assert len(issues) == 0, f"Expected 0 issues, got: {[i.message for i in issues]}"


if __name__ == "__main__":
    unittest.main()
