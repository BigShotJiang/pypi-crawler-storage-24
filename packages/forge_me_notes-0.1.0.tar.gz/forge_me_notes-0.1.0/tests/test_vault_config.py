"""
tests/test_vault_config.py — unit tests for fmn.vault_config

Run with:
  python3 -m unittest tests.test_vault_config -v
"""

import sys
import unittest
import tempfile
import shutil
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from fmn.vault_config import (
    fmn_dir,
    audit_dir,
    config_path,
    history_path,
    init_fmn_dir,
    load_config,
    load_history,
    append_history,
    save_audit_report,
    _merge_defaults,
)


class TestFmnDirPaths(unittest.TestCase):
    def test_fmn_dir_path(self):
        vault = Path("/fake/vault")
        assert fmn_dir(vault) == Path("/fake/vault/.fmn")

    def test_audit_dir_path(self):
        vault = Path("/fake/vault")
        assert audit_dir(vault) == Path("/fake/vault/.fmn/audit")

    def test_config_path(self):
        vault = Path("/fake/vault")
        assert config_path(vault) == Path("/fake/vault/.fmn/config.yaml")

    def test_history_path(self):
        vault = Path("/fake/vault")
        assert history_path(vault) == Path("/fake/vault/.fmn/history.yaml")


class TestInitFmnDir(unittest.TestCase):
    def setUp(self):
        self.vault = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.vault)

    def test_creates_fmn_dir(self):
        init_fmn_dir(self.vault)
        assert fmn_dir(self.vault).exists()

    def test_creates_audit_subdir(self):
        init_fmn_dir(self.vault)
        assert audit_dir(self.vault).exists()

    def test_creates_config(self):
        init_fmn_dir(self.vault)
        assert config_path(self.vault).exists()

    def test_creates_history(self):
        init_fmn_dir(self.vault)
        assert history_path(self.vault).exists()

    def test_creates_gitignore(self):
        init_fmn_dir(self.vault)
        assert (fmn_dir(self.vault) / ".gitignore").exists()

    def test_idempotent(self):
        # Running twice should not raise or corrupt anything
        init_fmn_dir(self.vault)
        init_fmn_dir(self.vault)
        assert config_path(self.vault).exists()


class TestLoadConfig(unittest.TestCase):
    def setUp(self):
        self.vault = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.vault)

    def test_returns_dict(self):
        config = load_config(self.vault)
        assert isinstance(config, dict)

    def test_has_vault_name(self):
        config = load_config(self.vault)
        assert "vault_name" in config

    def test_vault_name_from_dir(self):
        # Vault name should be derived from directory name
        config = load_config(self.vault)
        assert isinstance(config["vault_name"], str)

    def test_has_audit_section(self):
        config = load_config(self.vault)
        assert "audit" in config

    def test_has_suppress_links(self):
        config = load_config(self.vault)
        assert "suppress_links" in config["audit"]

    def test_suppress_links_is_list(self):
        config = load_config(self.vault)
        assert isinstance(config["audit"]["suppress_links"], list)

    def test_custom_config_respected(self):
        import yaml
        init_fmn_dir(self.vault)
        custom = {
            "vault_name": "My Test Vault",
            "vault_type": "business-plan",
            "audit": {
                "suppress_links": ["My Custom Term"],
            }
        }
        with open(config_path(self.vault), "w") as f:
            yaml.dump(custom, f)

        config = load_config(self.vault)
        assert config["vault_name"] == "My Test Vault"
        assert config["vault_type"] == "business-plan"
        assert "My Custom Term" in config["audit"]["suppress_links"]


class TestMergeDefaults(unittest.TestCase):
    def test_empty_config_gets_defaults(self):
        merged = _merge_defaults({})
        assert "vault_name" in merged
        assert "audit" in merged
        assert "suppress_links" in merged["audit"]

    def test_user_values_override_defaults(self):
        merged = _merge_defaults({"vault_name": "Custom Name"})
        assert merged["vault_name"] == "Custom Name"

    def test_partial_audit_config_merged(self):
        # Only override suppress_links — exemptions should still have defaults
        merged = _merge_defaults({
            "audit": {"suppress_links": ["custom"]}
        })
        assert merged["audit"]["suppress_links"] == ["custom"]
        assert "missing_website" in merged["audit"]["exemptions"]


class TestHistory(unittest.TestCase):
    def setUp(self):
        self.vault = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.vault)

    def test_empty_history(self):
        history = load_history(self.vault)
        assert history == []

    def test_append_entry(self):
        entry = {
            "timestamp": "2026-03-17 09:00",
            "notes_checked": 95,
            "errors": 20,
            "warnings": 25,
            "suggestions": 0,
        }
        append_history(self.vault, entry)
        history = load_history(self.vault)
        assert len(history) == 1
        assert history[0]["errors"] == 20

    def test_multiple_entries_ordered(self):
        for i in range(3):
            append_history(self.vault, {
                "timestamp": f"2026-03-{17+i:02d} 09:00",
                "errors": i,
                "warnings": 0,
                "suggestions": 0,
                "notes_checked": 10,
            })
        history = load_history(self.vault)
        assert len(history) == 3
        assert history[0]["errors"] == 0
        assert history[2]["errors"] == 2

    def test_history_persists_across_calls(self):
        append_history(self.vault, {"timestamp": "t1", "errors": 5,
                                     "warnings": 0, "suggestions": 0,
                                     "notes_checked": 10})
        append_history(self.vault, {"timestamp": "t2", "errors": 2,
                                     "warnings": 0, "suggestions": 0,
                                     "notes_checked": 10})
        # Reload fresh
        history = load_history(self.vault)
        assert len(history) == 2


class TestSaveAuditReport(unittest.TestCase):
    def setUp(self):
        self.vault = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.vault)

    def test_saves_to_audit_dir(self):
        path = save_audit_report(self.vault, "# Test Report", "2026-03-17 09:04")
        assert path.exists()
        assert path.parent == audit_dir(self.vault)

    def test_filename_from_timestamp(self):
        path = save_audit_report(self.vault, "content", "2026-03-17 09:04")
        assert "2026-03-17" in path.name
        assert "09-04" in path.name

    def test_content_written_correctly(self):
        content = "# Audit Report\n\nSome content here."
        path = save_audit_report(self.vault, content, "2026-03-17 09:04")
        assert path.read_text() == content

    def test_spaces_replaced_in_filename(self):
        path = save_audit_report(self.vault, "content", "2026-03-17 09:04")
        assert " " not in path.name


if __name__ == "__main__":
    unittest.main()
