# main.py
def hello():
    print("Hello from Mskim2k!")