from __future__ import annotations


def get_runtime_helper_code() -> str:
    return """from __future__ import annotations

import json
import os
from pathlib import Path


def load_hardware() -> dict:
    path = os.environ.get("EPOCHLER_HARDWARE_PATH", "")
    if not path:
        return {}
    return json.loads(Path(path).read_text())


def choose_device() -> str:
    hardware = load_hardware()
    gpu_type = hardware.get("gpu_type", "")
    if gpu_type == "cuda":
        return "cuda"
    if gpu_type == "mps":
        return "mps"
    return "cpu"


def recommended_num_workers() -> int:
    hardware = load_hardware()
    cpu_count = max(int(hardware.get("cpu_count", 1) or 1), 1)
    return max(min(cpu_count // 2, 8), 0)


def recommended_pin_memory() -> bool:
    return choose_device() == "cuda"


def recommended_thread_count() -> int:
    hardware = load_hardware()
    return max(int(hardware.get("cpu_count", 1) or 1), 1)


def recommended_batch_size(default_cpu: int = 32, default_gpu: int = 128) -> int:
    hardware = load_hardware()
    if choose_device() == "cpu":
        return default_cpu
    vram = hardware.get("gpu_vram_gb") or []
    max_vram = max(vram) if vram else 0
    if max_vram and max_vram < 8:
        return min(default_gpu, 32)
    if max_vram and max_vram < 16:
        return min(default_gpu, 64)
    return default_gpu
"""
