"""Epochler CLI entry point."""

from __future__ import annotations

import os

import uvicorn


def main() -> None:
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    reload = os.environ.get("EPOCHLER_DEV", "").lower() in ("1", "true")

    uvicorn.run(
        "epochler.main:app",
        host=host,
        port=port,
        reload=reload,
        log_level="warning",
    )


if __name__ == "__main__":
    main()
