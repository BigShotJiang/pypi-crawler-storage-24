from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="ai-control-plane",
    version="2.0.1",
    description="AI Control Plane Python SDK — observability, cost tracking, and analytics for LLM applications",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Anil Kumar",
    author_email="akrava32@gmail.com",
    url="https://github.com/Anil175/ai-control-plane",
    project_urls={
        "Homepage": "https://ai-control-plane.in",
        "Source": "https://github.com/Anil175/ai-control-plane",
        "Documentation": "https://ai-control-plane.in/docs",
    },
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=["httpx>=0.27.0", "pydantic>=2.0"],
    extras_require={
        "openai":    ["openai>=1.0.0"],
        "anthropic": ["anthropic>=0.20.0"],
        "all":       ["openai>=1.0.0", "anthropic>=0.20.0"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="ai llm observability openai anthropic telemetry cost-tracking agents",
)
