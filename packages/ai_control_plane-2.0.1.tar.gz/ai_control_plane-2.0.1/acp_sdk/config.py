import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ACPConfig:
    api_key: str = ""
    app: str = "default"
    environment: str = "production"
    ingest_url: str = "http://localhost:8000"
    tags: dict = field(default_factory=dict)
    content_logging: bool = False

    @classmethod
    def from_env(cls) -> "ACPConfig":
        return cls(
            api_key=os.getenv("ACP_API_KEY", ""),
            app=os.getenv("ACP_APP", "default"),
            environment=os.getenv("ACP_ENV", "production"),
            ingest_url=os.getenv("ACP_INGEST_URL", "http://localhost:8000"),
        )

    def validate(self):
        if not self.api_key:
            raise ValueError("ACP api_key is required")
