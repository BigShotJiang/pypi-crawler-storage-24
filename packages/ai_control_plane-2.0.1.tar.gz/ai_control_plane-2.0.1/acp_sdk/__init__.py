"""
ACP Python SDK
==============
2-line integration for OpenAI, Anthropic, and Google LLM clients.

Usage:
    from openai import OpenAI
    from acp_sdk import wrap

    client = wrap(OpenAI(), api_key="acp_live_...", app="my-app")
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Hello!"}],
        _acp_user_id="user_123",
        _acp_session_id="session_abc",
    )
"""
from .client import wrap, ACPClient
from .config import ACPConfig

__all__ = ["wrap", "ACPClient", "ACPConfig"]
__version__ = "2.0.1"
