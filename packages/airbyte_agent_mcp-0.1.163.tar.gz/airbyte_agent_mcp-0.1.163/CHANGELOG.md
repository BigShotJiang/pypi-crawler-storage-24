# Changelog

## [0.1.163] - 2026-03-19
- Updated airbyte-agent-mcp package
- Source commit: b84e133c
- SDK version: 0.1.0

## [0.1.162] - 2026-03-19
- Updated airbyte-agent-mcp package
- Source commit: 4cb58bee
- SDK version: 0.1.0

## [0.1.161] - 2026-03-12
- Updated airbyte-agent-mcp package
- Source commit: b541ca65
- SDK version: 0.1.0

## [0.1.160] - 2026-03-11
- Updated airbyte-agent-mcp package
- Source commit: 44677ecb
- SDK version: 0.1.0

## [0.1.159] - 2026-03-10
- Updated airbyte-agent-mcp package
- Source commit: 45bfa51d
- SDK version: 0.1.0

## [0.1.158] - 2026-03-05
- Updated airbyte-agent-mcp package
- Source commit: e50d6dd2
- SDK version: 0.1.0

## [0.1.157] - 2026-03-04
- Updated airbyte-agent-mcp package
- Source commit: 0989dbaa
- SDK version: 0.1.0

## [0.1.156] - 2026-03-04
- Updated airbyte-agent-mcp package
- Source commit: 6e897235
- SDK version: 0.1.0

## [0.1.155] - 2026-03-03
- Updated airbyte-agent-mcp package
- Source commit: 9808f8a1
- SDK version: 0.1.0

## [0.1.154] - 2026-03-03
- Updated airbyte-agent-mcp package
- Source commit: fc32c408
- SDK version: 0.1.0

## [0.1.153] - 2026-03-03
- Updated airbyte-agent-mcp package
- Source commit: d61ba2f4
- SDK version: 0.1.0

## [0.1.152] - 2026-03-03
- Updated airbyte-agent-mcp package
- Source commit: 258f32e0
- SDK version: 0.1.0

## [0.1.151] - 2026-02-27
- Updated airbyte-agent-mcp package
- Source commit: a735c402
- SDK version: 0.1.0

## [0.1.150] - 2026-02-27
- Updated airbyte-agent-mcp package
- Source commit: 7bd29cad
- SDK version: 0.1.0

## [0.1.149] - 2026-02-27
- Updated airbyte-agent-mcp package
- Source commit: 39690c8e
- SDK version: 0.1.0

## [0.1.148] - 2026-02-26
- Updated airbyte-agent-mcp package
- Source commit: 9072a725
- SDK version: 0.1.0

## [0.1.147] - 2026-02-24
- Updated airbyte-agent-mcp package
- Source commit: 77a555da
- SDK version: 0.1.0

## [0.1.146] - 2026-02-23
- Updated airbyte-agent-mcp package
- Source commit: 62fbfc1f
- SDK version: 0.1.0

## [0.1.145] - 2026-02-20
- Updated airbyte-agent-mcp package
- Source commit: cb4380e7
- SDK version: 0.1.0

## [0.1.144] - 2026-02-19
- Updated airbyte-agent-mcp package
- Source commit: 7cda3ed1
- SDK version: 0.1.0

## [0.1.143] - 2026-02-19
- Updated airbyte-agent-mcp package
- Source commit: 3f4da97b
- SDK version: 0.1.0

## [0.1.142] - 2026-02-19
- Updated airbyte-agent-mcp package
- Source commit: c92c7707
- SDK version: 0.1.0

## [0.1.141] - 2026-02-19
- Updated airbyte-agent-mcp package
- Source commit: 740d582b
- SDK version: 0.1.0

## [0.1.140] - 2026-02-18
- Updated airbyte-agent-mcp package
- Source commit: 2d909dd8
- SDK version: 0.1.0

## [0.1.139] - 2026-02-13
- Updated airbyte-agent-mcp package
- Source commit: 8904217e
- SDK version: 0.1.0

## [0.1.138] - 2026-02-11
- Updated airbyte-agent-mcp package
- Source commit: 8c602f77
- SDK version: 0.1.0

## [0.1.137] - 2026-02-11
- Updated airbyte-agent-mcp package
- Source commit: 114c9599
- SDK version: 0.1.0

## [0.1.136] - 2026-02-11
- Updated airbyte-agent-mcp package
- Source commit: 64ac3a66
- SDK version: 0.1.0

## [0.1.135] - 2026-02-11
- Updated airbyte-agent-mcp package
- Source commit: 7ead0448
- SDK version: 0.1.0

## [0.1.134] - 2026-02-10
- Updated airbyte-agent-mcp package
- Source commit: d6f8bda4
- SDK version: 0.1.0

## [0.1.133] - 2026-02-10
- Updated airbyte-agent-mcp package
- Source commit: c1483418
- SDK version: 0.1.0

## [0.1.132] - 2026-02-10
- Updated airbyte-agent-mcp package
- Source commit: 04691d06
- SDK version: 0.1.0

## [0.1.131] - 2026-02-09
- Updated airbyte-agent-mcp package
- Source commit: 90085fae
- SDK version: 0.1.0

## [0.1.130] - 2026-02-08
- Updated airbyte-agent-mcp package
- Source commit: 2b94a8ea
- SDK version: 0.1.0

## [0.1.129] - 2026-02-06
- Updated airbyte-agent-mcp package
- Source commit: 0441f0ed
- SDK version: 0.1.0

## [0.1.128] - 2026-02-06
- Updated airbyte-agent-mcp package
- Source commit: e4cb32de
- SDK version: 0.1.0

## [0.1.127] - 2026-02-06
- Updated airbyte-agent-mcp package
- Source commit: df1e8094
- SDK version: 0.1.0

## [0.1.126] - 2026-02-06
- Updated airbyte-agent-mcp package
- Source commit: bf1f5dab
- SDK version: 0.1.0

## [0.1.125] - 2026-02-06
- Updated airbyte-agent-mcp package
- Source commit: 883f64f2
- SDK version: 0.1.0

## [0.1.124] - 2026-02-06
- Updated airbyte-agent-mcp package
- Source commit: 70669155
- SDK version: 0.1.0

## [0.1.123] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: e4f3b9c8
- SDK version: 0.1.0

## [0.1.122] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: cddf6b9f
- SDK version: 0.1.0

## [0.1.121] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: 481be654
- SDK version: 0.1.0

## [0.1.120] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: 271d94f6
- SDK version: 0.1.0

## [0.1.119] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: c081aa11
- SDK version: 0.1.0

## [0.1.118] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: 72bd32a3
- SDK version: 0.1.0

## [0.1.117] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: 3e4f6ea0
- SDK version: 0.1.0

## [0.1.116] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: 0c907160
- SDK version: 0.1.0

## [0.1.115] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: c6ee5117
- SDK version: 0.1.0

## [0.1.114] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: aceb0c64
- SDK version: 0.1.0

## [0.1.113] - 2026-02-05
- Updated airbyte-agent-mcp package
- Source commit: def0e484
- SDK version: 0.1.0

## [0.1.112] - 2026-02-04
- Updated airbyte-agent-mcp package
- Source commit: 5c699b63
- SDK version: 0.1.0

## [0.1.111] - 2026-02-04
- Updated airbyte-agent-mcp package
- Source commit: 4a1c1a14
- SDK version: 0.1.0

## [0.1.110] - 2026-02-04
- Updated airbyte-agent-mcp package
- Source commit: 82e0d412
- SDK version: 0.1.0

## [0.1.109] - 2026-02-04
- Updated airbyte-agent-mcp package
- Source commit: b9f0deb6
- SDK version: 0.1.0

## [0.1.108] - 2026-02-04
- Updated airbyte-agent-mcp package
- Source commit: fa7744d9
- SDK version: 0.1.0

## [0.1.107] - 2026-02-04
- Updated airbyte-agent-mcp package
- Source commit: 19dfc2f5
- SDK version: 0.1.0

## [0.1.106] - 2026-02-03
- Updated airbyte-agent-mcp package
- Source commit: 5ad427ae
- SDK version: 0.1.0

## [0.1.105] - 2026-02-03
- Updated airbyte-agent-mcp package
- Source commit: 4b475276
- SDK version: 0.1.0

## [0.1.104] - 2026-02-02
- Updated airbyte-agent-mcp package
- Source commit: 94024675
- SDK version: 0.1.0

## [0.1.103] - 2026-02-02
- Updated airbyte-agent-mcp package
- Source commit: 9d9866b0
- SDK version: 0.1.0

## [0.1.102] - 2026-01-30
- Updated airbyte-agent-mcp package
- Source commit: b184da3e
- SDK version: 0.1.0

## [0.1.101] - 2026-01-30
- Updated airbyte-agent-mcp package
- Source commit: e8781fc2
- SDK version: 0.1.0

## [0.1.100] - 2026-01-30
- Updated airbyte-agent-mcp package
- Source commit: 8fe37e70
- SDK version: 0.1.0

## [0.1.99] - 2026-01-30
- Updated airbyte-agent-mcp package
- Source commit: 5b20f488
- SDK version: 0.1.0

## [0.1.98] - 2026-01-30
- Updated airbyte-agent-mcp package
- Source commit: a3729d85
- SDK version: 0.1.0

## [0.1.97] - 2026-01-29
- Updated airbyte-agent-mcp package
- Source commit: 43200eed
- SDK version: 0.1.0

## [0.1.96] - 2026-01-29
- Updated airbyte-agent-mcp package
- Source commit: c718c683
- SDK version: 0.1.0

## [0.1.95] - 2026-01-29
- Updated airbyte-agent-mcp package
- Source commit: b907dd5d
- SDK version: 0.1.0

## [0.1.94] - 2026-01-28
- Updated airbyte-agent-mcp package
- Source commit: 97007bbd
- SDK version: 0.1.0

## [0.1.93] - 2026-01-28
- Updated airbyte-agent-mcp package
- Source commit: f6c6fca2
- SDK version: 0.1.0

## [0.1.92] - 2026-01-28
- Updated airbyte-agent-mcp package
- Source commit: 7efee372
- SDK version: 0.1.0

## [0.1.91] - 2026-01-28
- Updated airbyte-agent-mcp package
- Source commit: 71f48c10
- SDK version: 0.1.0

## [0.1.90] - 2026-01-27
- Updated airbyte-agent-mcp package
- Source commit: 0f5e1914
- SDK version: 0.1.0

## [0.1.89] - 2026-01-27
- Updated airbyte-agent-mcp package
- Source commit: a01f6b16
- SDK version: 0.1.0

## [0.1.88] - 2026-01-27
- Updated airbyte-agent-mcp package
- Source commit: 77091939
- SDK version: 0.1.0

## [0.1.87] - 2026-01-27
- Updated airbyte-agent-mcp package
- Source commit: 4bded58d
- SDK version: 0.1.0

## [0.1.86] - 2026-01-26
- Updated airbyte-agent-mcp package
- Source commit: 74809153
- SDK version: 0.1.0

## [0.1.85] - 2026-01-26
- Updated airbyte-agent-mcp package
- Source commit: b73c71e0
- SDK version: 0.1.0

## [0.1.84] - 2026-01-24
- Updated airbyte-agent-mcp package
- Source commit: 609c1d86
- SDK version: 0.1.0

## [0.1.83] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: 99d64eb7
- SDK version: 0.1.0

## [0.1.82] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: b32ea5ab
- SDK version: 0.1.0

## [0.1.81] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: 4285ad48
- SDK version: 0.1.0

## [0.1.80] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: 416466da
- SDK version: 0.1.0

## [0.1.79] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: b69b698f
- SDK version: 0.1.0

## [0.1.78] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: f17cdd8c
- SDK version: 0.1.0

## [0.1.77] - 2026-01-22
- Updated airbyte-agent-mcp package
- Source commit: 49e6dfe9
- SDK version: 0.1.0

## [0.1.76] - 2026-01-22
- Updated airbyte-agent-mcp package
- Source commit: b27328e2
- SDK version: 0.1.0

## [0.1.75] - 2026-01-22
- Updated airbyte-agent-mcp package
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.1.74] - 2026-01-22
- Updated airbyte-agent-mcp package
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.1.73] - 2026-01-21
- Updated airbyte-agent-mcp package
- Source commit: cf8d5de5
- SDK version: 0.1.0

## [0.1.72] - 2026-01-21
- Updated airbyte-agent-mcp package
- Source commit: 562cfe18
- SDK version: 0.1.0

## [0.1.71] - 2026-01-21
- Updated airbyte-agent-mcp package
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.1.70] - 2026-01-19
- Updated airbyte-agent-mcp package
- Source commit: 529cebb7
- SDK version: 0.1.0

## [0.1.69] - 2026-01-17
- Updated airbyte-agent-mcp package
- Source commit: 64c27b4c
- SDK version: 0.1.0

## [0.1.68] - 2026-01-16
- Updated airbyte-agent-mcp package
- Source commit: a50c8f71
- SDK version: 0.1.0

## [0.1.67] - 2026-01-16
- Updated airbyte-agent-mcp package
- Source commit: 49673b7b
- SDK version: 0.1.0

## [0.1.66] - 2026-01-16
- Updated airbyte-agent-mcp package
- Source commit: ca5acdda
- SDK version: 0.1.0

## [0.1.65] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: fa9a3b02
- SDK version: 0.1.0

## [0.1.64] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 61a2e822
- SDK version: 0.1.0

## [0.1.63] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 5d66b084
- SDK version: 0.1.0

## [0.1.62] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 4d03b394
- SDK version: 0.1.0

## [0.1.61] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 35211193
- SDK version: 0.1.0

## [0.1.60] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: a6da90fa
- SDK version: 0.1.0

## [0.1.59] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 20b3afd9
- SDK version: 0.1.0

## [0.1.58] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: b7138b41
- SDK version: 0.1.0

## [0.1.57] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 10173eb1
- SDK version: 0.1.0

## [0.1.56] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: c10bf9d7
- SDK version: 0.1.0

## [0.1.55] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: a23d9e7a
- SDK version: 0.1.0

## [0.1.54] - 2026-01-14
- Updated airbyte-agent-mcp package
- Source commit: 7ef09816
- SDK version: 0.1.0

## [0.1.53] - 2026-01-14
- Updated airbyte-agent-mcp package
- Source commit: e6285db5
- SDK version: 0.1.0

## [0.1.52] - 2026-01-14
- Updated airbyte-agent-mcp package
- Source commit: 31de238d
- SDK version: 0.1.0

## [0.1.51] - 2026-01-14
- Updated airbyte-agent-mcp package
- Source commit: 6504630b
- SDK version: 0.1.0

## [0.1.50] - 2026-01-13
- Updated airbyte-agent-mcp package
- Source commit: e80a226e
- SDK version: 0.1.0

## [0.1.49] - 2026-01-13
- Updated airbyte-agent-mcp package
- Source commit: 78b1be67
- SDK version: 0.1.0

## [0.1.48] - 2026-01-11
- Updated airbyte-agent-mcp package
- Source commit: e519b73d
- SDK version: 0.1.0

## [0.1.47] - 2026-01-09
- Updated airbyte-agent-mcp package
- Source commit: 3c7bfdfd
- SDK version: 0.1.0

## [0.1.46] - 2026-01-09
- Updated airbyte-agent-mcp package
- Source commit: 3bcb33e8
- SDK version: 0.1.0

## [0.1.45] - 2026-01-09
- Updated airbyte-agent-mcp package
- Source commit: 9fe9d138
- SDK version: 0.1.0

## [0.1.44] - 2026-01-09
- Updated airbyte-agent-mcp package
- Source commit: da9b741b
- SDK version: 0.1.0

## [0.1.43] - 2026-01-07
- Updated airbyte-agent-mcp package
- Source commit: d023e05f
- SDK version: 0.1.0

## [0.1.42] - 2026-01-06
- Updated airbyte-agent-mcp package
- Source commit: 0580c727
- SDK version: 0.1.0

## [0.1.41] - 2026-01-06
- Updated airbyte-agent-mcp package
- Source commit: 42f65575
- SDK version: 0.1.0

## [0.1.40] - 2026-01-06
- Updated airbyte-agent-mcp package
- Source commit: 0deedc22
- SDK version: 0.1.0

## [0.1.39] - 2026-01-06
- Updated airbyte-agent-mcp package
- Source commit: e0e2f989
- SDK version: 0.1.0

## [0.1.38] - 2026-01-05
- Updated airbyte-agent-mcp package
- Source commit: 3e274293
- SDK version: 0.1.0

## [0.1.37] - 2025-12-19
- Updated airbyte-agent-mcp package
- Source commit: 12f6b994
- SDK version: 0.1.0

## [0.1.36] - 2025-12-19
- Updated airbyte-agent-mcp package
- Source commit: 5d11bfdf
- SDK version: 0.1.0

## [0.1.35] - 2025-12-19
- Updated airbyte-agent-mcp package
- Source commit: e996e848
- SDK version: 0.1.0

## [0.1.34] - 2025-12-18
- Updated airbyte-agent-mcp package
- Source commit: f7c55d3e
- SDK version: 0.1.0

## [0.1.33] - 2025-12-17
- Updated airbyte-agent-mcp package
- Source commit: af456521
- SDK version: 0.1.0

## [0.1.32] - 2025-12-17
- Updated airbyte-agent-mcp package
- Source commit: 6a6c981e
- SDK version: 0.1.0

## [0.1.31] - 2025-12-16
- Updated airbyte-agent-mcp package
- Source commit: 9c0af4ae
- SDK version: 0.1.0

## [0.1.30] - 2025-12-16
- Updated airbyte-agent-mcp package
- Source commit: d8fc544e
- SDK version: 0.1.0

## [0.1.29] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: c4c39c27
- SDK version: 0.1.0

## [0.1.28] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 85f4e6b0
- SDK version: 0.1.0

## [0.1.27] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 77ce3325
- SDK version: 0.1.0

## [0.1.26] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 0bfa6500
- SDK version: 0.1.0

## [0.1.25] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: ea5a02a3
- SDK version: 0.1.0

## [0.1.24] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: f13dee0a
- SDK version: 0.1.0

## [0.1.23] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: d79da1e7
- SDK version: 0.1.0

## [0.1.22] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 0e48ca4e
- SDK version: 0.1.0

## [0.1.21] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 06e7d5c6
- SDK version: 0.1.0

## [0.1.20] - 2025-12-13
- Updated airbyte-agent-mcp package
- Source commit: 1ab72bd8
- SDK version: 0.1.0

## [0.1.19] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: dc79dc8b
- SDK version: 0.1.0

## [0.1.18] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 380e7c20
- SDK version: 0.1.0

## [0.1.17] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 1f622906
- SDK version: 0.1.0

## [0.1.16] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 8cd69753
- SDK version: 0.1.0

## [0.1.15] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 9f7f8a98
- SDK version: 0.1.0

## [0.1.14] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 5cc8eaa0
- SDK version: 0.1.0

## [0.1.13] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: dfe01f50
- SDK version: 0.1.0

## [0.1.12] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: 8c06aa10
- SDK version: 0.1.0

## [0.1.11] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: 11427ac3
- SDK version: 0.1.0

## [0.1.10] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: bdd5df6d
- SDK version: 0.1.0

## [0.1.9] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: ec3dcc78
- SDK version: 0.1.0

## [0.1.8] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 334e113b
- SDK version: 0.1.0

## [0.1.7] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 30c77ce6
- SDK version: 0.1.0

## [0.1.6] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 92482e66
- SDK version: 0.1.0

## [0.1.5] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.4] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.3] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.2] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.1] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.0] - 2025-12-09
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0
