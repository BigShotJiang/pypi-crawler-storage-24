from __future__ import annotations

from dataclasses import dataclass
import hashlib
from pathlib import Path
import re

from .firmware import FirmwareImage, PermanentConfigRecord


PCI_ID_RE = re.compile(r"\[([0-9a-fA-F]{4}):([0-9a-fA-F]{4})\]")


@dataclass(frozen=True)
class PciIdentity:
    vendor_id: int | None
    device_id: int | None
    subsystem_vendor_id: int | None
    subsystem_device_id: int | None


@dataclass(frozen=True)
class ConfigRecordDelta:
    address: int
    before_value: int | None
    after_value: int | None
    before_width: int | None
    after_width: int | None


@dataclass(frozen=True)
class WordTransitionCandidate:
    offset: int
    before_value: int
    after_value: int
    region: str


@dataclass(frozen=True)
class WindowTransitionCandidate:
    offset: int
    window_size: int
    before_hex: str
    after_hex: str


@dataclass(frozen=True)
class DiffCluster:
    start: int
    end: int

    @property
    def size(self) -> int:
        return self.end - self.start + 1


@dataclass(frozen=True)
class RomImageMetadata:
    path: str
    sha256: str
    size: int
    family_tag: str | None
    header_tags: tuple[str, ...]
    device_type: int
    config_length: int
    rom_size: int
    raw_size: int
    config_records: tuple[PermanentConfigRecord, ...]


@dataclass(frozen=True)
class RomDiffReport:
    before: RomImageMetadata
    after: RomImageMetadata
    before_identity: PciIdentity | None
    after_identity: PciIdentity | None
    total_diff_bytes: int
    config_record_deltas: tuple[ConfigRecordDelta, ...]
    primary_word_candidates: tuple[WordTransitionCandidate, ...]
    subsystem_word_candidates: tuple[WordTransitionCandidate, ...]
    vendor_window_candidates: tuple[WindowTransitionCandidate, ...]
    diff_clusters: tuple[DiffCluster, ...]


def parse_lspci_identity(text: str) -> PciIdentity | None:
    primary_match: tuple[int, int] | None = None
    subsystem_match: tuple[int, int] | None = None

    for raw_line in text.splitlines():
        line = raw_line.strip()
        match = PCI_ID_RE.search(line)
        if not match:
            continue
        vendor_id = int(match.group(1), 16)
        device_id = int(match.group(2), 16)
        if "Subsystem:" in line:
            subsystem_match = (vendor_id, device_id)
        elif primary_match is None:
            primary_match = (vendor_id, device_id)

    if primary_match is None and subsystem_match is None:
        return None

    return PciIdentity(
        vendor_id=None if primary_match is None else primary_match[0],
        device_id=None if primary_match is None else primary_match[1],
        subsystem_vendor_id=None if subsystem_match is None else subsystem_match[0],
        subsystem_device_id=None if subsystem_match is None else subsystem_match[1],
    )


def parse_lspci_identity_path(path: str | Path | None) -> PciIdentity | None:
    if path is None:
        return None
    payload = Path(path).read_text(encoding="utf-8")
    return parse_lspci_identity(payload)


def analyze_rom_diff(
    before_path: str | Path,
    after_path: str | Path,
    *,
    before_identity: PciIdentity | None = None,
    after_identity: PciIdentity | None = None,
    max_candidates: int = 16,
    max_clusters: int = 32,
) -> RomDiffReport:
    before_meta, before_data = _load_rom_metadata(before_path)
    after_meta, after_data = _load_rom_metadata(after_path)

    total_diff_bytes = _count_diff_bytes(before_data, after_data)
    config_record_deltas = _diff_config_records(before_meta.config_records, after_meta.config_records)
    diff_clusters = _cluster_differences(before_data, after_data, limit=max_clusters)

    primary_word_candidates: tuple[WordTransitionCandidate, ...] = ()
    subsystem_word_candidates: tuple[WordTransitionCandidate, ...] = ()
    vendor_window_candidates: tuple[WindowTransitionCandidate, ...] = ()

    if (
        before_identity is not None
        and after_identity is not None
        and before_identity.device_id is not None
        and after_identity.device_id is not None
    ):
        primary_word_candidates = _find_word_transition_candidates(
            before_data,
            after_data,
            before_value=before_identity.device_id,
            after_value=after_identity.device_id,
            config_length=max(before_meta.config_length, after_meta.config_length),
            limit=max_candidates,
        )

    if (
        before_identity is not None
        and after_identity is not None
        and before_identity.subsystem_device_id is not None
        and after_identity.subsystem_device_id is not None
    ):
        subsystem_word_candidates = _find_word_transition_candidates(
            before_data,
            after_data,
            before_value=before_identity.subsystem_device_id,
            after_value=after_identity.subsystem_device_id,
            config_length=max(before_meta.config_length, after_meta.config_length),
            limit=max_candidates,
        )

    if (
        before_identity is not None
        and after_identity is not None
        and before_identity.vendor_id is not None
        and after_identity.vendor_id is not None
        and before_identity.device_id is not None
        and after_identity.device_id is not None
    ):
        vendor_window_candidates = _find_vendor_window_candidates(
            before_data,
            after_data,
            before_vendor=before_identity.vendor_id,
            after_vendor=after_identity.vendor_id,
            before_device=before_identity.device_id,
            after_device=after_identity.device_id,
            limit=max_candidates,
        )

    return RomDiffReport(
        before=before_meta,
        after=after_meta,
        before_identity=before_identity,
        after_identity=after_identity,
        total_diff_bytes=total_diff_bytes,
        config_record_deltas=config_record_deltas,
        primary_word_candidates=primary_word_candidates,
        subsystem_word_candidates=subsystem_word_candidates,
        vendor_window_candidates=vendor_window_candidates,
        diff_clusters=diff_clusters,
    )


def _load_rom_metadata(path: str | Path) -> tuple[RomImageMetadata, bytes]:
    rom_path = Path(path)
    data = rom_path.read_bytes()
    image = FirmwareImage.from_bytes(data, source=str(rom_path))
    sections = image._extract_permanent_sections()
    size_width = 2 if sections.device_type in {0, 1} else 4
    rom_size = (
        sections.config_length
        + 1
        + 4
        + size_width
        + sections.raw_size
        + len(sections.fw_signature)
        + 1
        + len(sections.fw_crc)
        + len(sections.fw_extra)
    )
    return (
        RomImageMetadata(
            path=str(rom_path),
            sha256=hashlib.sha256(data).hexdigest(),
            size=len(data),
            family_tag=image.family_tag,
            header_tags=image.header_tags,
            device_type=sections.device_type,
            config_length=sections.config_length,
            rom_size=rom_size,
            raw_size=sections.raw_size,
            config_records=image.extract_config_records(),
        ),
        data,
    )


def _count_diff_bytes(before: bytes, after: bytes) -> int:
    return sum(1 for left, right in zip(before, after) if left != right) + abs(len(before) - len(after))


def _diff_config_records(
    before_records: tuple[PermanentConfigRecord, ...],
    after_records: tuple[PermanentConfigRecord, ...],
) -> tuple[ConfigRecordDelta, ...]:
    before_map = {record.address: record for record in before_records}
    after_map = {record.address: record for record in after_records}
    deltas: list[ConfigRecordDelta] = []
    for address in sorted(set(before_map) | set(after_map)):
        before_record = before_map.get(address)
        after_record = after_map.get(address)
        if before_record == after_record:
            continue
        deltas.append(
            ConfigRecordDelta(
                address=address,
                before_value=None if before_record is None else before_record.value,
                after_value=None if after_record is None else after_record.value,
                before_width=None if before_record is None else before_record.width,
                after_width=None if after_record is None else after_record.width,
            )
        )
    return tuple(deltas)


def _find_word_transition_candidates(
    before: bytes,
    after: bytes,
    *,
    before_value: int,
    after_value: int,
    config_length: int,
    limit: int,
) -> tuple[WordTransitionCandidate, ...]:
    before_word = before_value.to_bytes(2, "little")
    after_word = after_value.to_bytes(2, "little")
    candidates: list[WordTransitionCandidate] = []
    for offset in range(0, min(len(before), len(after)) - 1):
        if before[offset : offset + 2] != before_word:
            continue
        if after[offset : offset + 2] != after_word:
            continue
        region = "config" if offset < config_length else "payload"
        candidates.append(
            WordTransitionCandidate(
                offset=offset,
                before_value=before_value,
                after_value=after_value,
                region=region,
            )
        )
        if len(candidates) >= limit:
            break
    return tuple(candidates)


def _find_vendor_window_candidates(
    before: bytes,
    after: bytes,
    *,
    before_vendor: int,
    after_vendor: int,
    before_device: int,
    after_device: int,
    limit: int,
) -> tuple[WindowTransitionCandidate, ...]:
    before_vendor_bytes = before_vendor.to_bytes(2, "little")
    after_vendor_bytes = after_vendor.to_bytes(2, "little")
    before_device_bytes = before_device.to_bytes(2, "little")
    after_device_bytes = after_device.to_bytes(2, "little")
    candidates: list[WindowTransitionCandidate] = []
    max_size = min(len(before), len(after))
    for window_size in (8, 12, 16):
        offset = 0
        while offset + window_size <= max_size:
            before_window = before[offset : offset + window_size]
            after_window = after[offset : offset + window_size]
            if before_window == after_window:
                offset += 1
                continue
            if before_vendor_bytes not in before_window or after_vendor_bytes not in after_window:
                offset += 1
                continue
            if before_device_bytes not in before_window or after_device_bytes not in after_window:
                offset += 1
                continue
            candidates.append(
                WindowTransitionCandidate(
                    offset=offset,
                    window_size=window_size,
                    before_hex=before_window.hex(),
                    after_hex=after_window.hex(),
                )
            )
            if len(candidates) >= limit:
                return tuple(candidates)
            # Keep the shortlist readable by skipping overlapping windows in the
            # same region once a match is found.
            offset += window_size
        if candidates:
            break
    return tuple(candidates)


def _cluster_differences(before: bytes, after: bytes, *, limit: int) -> tuple[DiffCluster, ...]:
    diff_indexes = [index for index, (left, right) in enumerate(zip(before, after)) if left != right]
    if len(before) != len(after):
        diff_indexes.extend(range(min(len(before), len(after)), max(len(before), len(after))))
    if not diff_indexes:
        return ()

    clusters: list[DiffCluster] = []
    start = end = diff_indexes[0]
    for index in diff_indexes[1:]:
        if index == end + 1:
            end = index
            continue
        clusters.append(DiffCluster(start=start, end=end))
        start = end = index
        if len(clusters) >= limit:
            return tuple(clusters)
    clusters.append(DiffCluster(start=start, end=end))
    return tuple(clusters[:limit])
