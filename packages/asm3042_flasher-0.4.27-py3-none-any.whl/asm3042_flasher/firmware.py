from __future__ import annotations

import binascii
import configparser
from dataclasses import dataclass
import hashlib
from pathlib import Path
import re
import struct


MAX_FIRMWARE_SIZE = 128 * 1024
HEADER_TAG_RE = re.compile(rb"([A-Z0-9]{4,8}_(?:RCFG|FW))")

FAMILY_DEVICE_TYPES: dict[str, int] = {
    "U2104": 0,
    "2104B": 1,
    "2114A": 1,
    "2214A": 2,
    "1343A": 3,
    "3306A": 4,
    "3306B": 4,
    "2324A": 5,
}

CFG_RECORD_ADDRESSES: dict[int, dict[str, int]] = {
    0: {"ssid": 0xF392, "svid": 0xF390},
    1: {"ssid": 0xE262, "svid": 0xE260},
    # The Windows driver passes 32-bit config register constants such as
    # 0x10050/0x10052/0x10063 to CREATE_ROM, but the final 0xCC record stores
    # only the low 16 bits. Keep the serialized addresses here.
    2: {"ssid": 0x52, "svid": 0x50, "pcie_speed": 0x63},
    4: {"ssid": 0x52, "svid": 0x50, "pcie_speed": 0x63},
    5: {"ssid": 0x5A, "svid": 0x58, "pcie_speed": 0xAE},
}

FW_SIGNATURE_SIZE = 8
FW_CHECKSUM_SIZE = 1
FW_CRC_SIZE = 4
FW_EXTRA_SIZE_BY_TYPE = {
    5: 0x41,
}

WINDOWS_BASE_CONFIG_LENGTH_BY_TYPE = {
    2: 0x30,
    4: 0x30,
    5: 0x30,
}

WINDOWS_VALIDATED_DEVICE_TYPES = {2}
WINDOWS_VALIDATED_SUBSYSTEM_VENDOR_IDS = {0x1B21}
WINDOWS_VALIDATED_SUBSYSTEM_DEVICE_IDS = {
    # Reverse-engineered from the Windows MPTool support table for the
    # ASM2142/ASM3142-class (2214A) family.
    2: {0x2142, 0x3042, 0x3142},
}
WINDOWS_VALIDATED_PCIE_SPEEDS = {0x01, 0x02, 0x03, 0x04}


@dataclass(frozen=True)
class ValidatedInternalTargetProfile:
    label: str
    firmware_sha256: str
    target_rom_sha256: str
    device_type: int
    primary_device_id: int
    subsystem_vendor_id: int
    subsystem_device_id: int


VALIDATED_INTERNAL_TARGET_PROFILES = (
    ValidatedInternalTargetProfile(
        label="AQAIC1-USB31-A2/ASMTxHCIMPTool.ini",
        firmware_sha256="eaec85ba26d377f73197f2d246b869f006205daf0c31e048e577da35c4e17a93",
        target_rom_sha256="a3b62f27e0b9c7f6c268767e4a68ade4afb84ad9a34515d260c97d4b2fc60325",
        device_type=2,
        primary_device_id=0x3042,
        subsystem_vendor_id=0x1B21,
        subsystem_device_id=0x3042,
    ),
)


@dataclass(frozen=True)
class PermanentConfigRecord:
    width: int
    address: int
    value: int

    def to_bytes(self) -> bytes:
        if self.width not in {0, 1, 2, 4, 8}:
            raise ValueError(f"unsupported config record width: {self.width}")
        if not 0 <= self.address <= 0xFFFF:
            raise ValueError(f"config record address is out of range: 0x{self.address:x}")
        if not 0 <= self.value <= 0xFFFFFFFF:
            raise ValueError(f"config record value is out of range: 0x{self.value:x}")

        payload = bytearray(8)
        payload[0] = 0xCC
        payload[1] = self.width
        payload[2:4] = struct.pack("<H", self.address)
        if self.width >= 1:
            payload[4] = self.value & 0xFF
        if self.width >= 2:
            payload[5] = (self.value >> 8) & 0xFF
        if self.width >= 4:
            payload[6] = (self.value >> 16) & 0xFF
        if self.width >= 8:
            payload[7] = (self.value >> 24) & 0xFF
        return bytes(payload)


@dataclass(frozen=True)
class MpToolIniConfig:
    source: str
    subsystem_vendor_id: int | None = None
    subsystem_device_id: int | None = None
    pcie_link_speed: int | None = None

    @property
    def has_overrides(self) -> bool:
        return any(
            value is not None
            for value in (
                self.subsystem_vendor_id,
                self.subsystem_device_id,
                self.pcie_link_speed,
            )
        )

    @property
    def override_scope(self) -> str:
        return "subsystem-only"

    def build_records(self, *, device_type: int) -> tuple[PermanentConfigRecord, ...]:
        address_map = CFG_RECORD_ADDRESSES.get(device_type, {})
        records: list[PermanentConfigRecord] = []

        if self.subsystem_vendor_id is not None:
            address = address_map.get("svid")
            if address is None:
                raise ValueError(
                    f"device type {device_type} does not expose a Windows-equivalent SVID config register"
                )
            records.append(
                PermanentConfigRecord(width=2, address=address, value=self.subsystem_vendor_id)
            )

        if self.subsystem_device_id is not None:
            address = address_map.get("ssid")
            if address is None:
                raise ValueError(
                    f"device type {device_type} does not expose a Windows-equivalent SSID config register"
                )
            records.append(
                PermanentConfigRecord(width=2, address=address, value=self.subsystem_device_id)
            )

        if self.pcie_link_speed is not None:
            address = address_map.get("pcie_speed")
            if address is None:
                raise ValueError(
                    f"device type {device_type} does not expose a Windows-equivalent PCIe speed config register"
                )
            records.append(
                PermanentConfigRecord(width=1, address=address, value=self.pcie_link_speed)
            )

        return tuple(records)


@dataclass(frozen=True)
class PermanentFirmwareImage:
    source: str
    family_tag: str
    device_type: int
    config_length: int
    raw_data: bytes
    fw_signature: bytes
    fw_checksum: int
    fw_crc: bytes
    fw_extra: bytes
    rom_data: bytes
    config_records: tuple[PermanentConfigRecord, ...]

    @property
    def raw_size(self) -> int:
        return len(self.raw_data)

    @property
    def rom_size(self) -> int:
        return len(self.rom_data)


@dataclass(frozen=True)
class FirmwareImage:
    source: str
    data: bytes
    header_tags: tuple[str, ...]

    @classmethod
    def from_path(cls, path: str | Path) -> "FirmwareImage":
        firmware_path = Path(path)
        return cls.from_bytes(firmware_path.read_bytes(), source=str(firmware_path))

    @classmethod
    def from_bytes(cls, data: bytes, source: str = "<memory>") -> "FirmwareImage":
        if not data:
            raise ValueError("firmware image is empty")
        if len(data) % 2:
            raise ValueError("firmware image size must be even")
        if len(data) > MAX_FIRMWARE_SIZE:
            raise ValueError(
                f"firmware image is too large ({len(data)} bytes > {MAX_FIRMWARE_SIZE} bytes)"
            )

        tags: list[str] = []
        seen: set[str] = set()
        for match in HEADER_TAG_RE.finditer(data[:512]):
            tag = match.group(1).decode("ascii")
            if tag not in seen:
                tags.append(tag)
                seen.add(tag)

        return cls(source=source, data=data, header_tags=tuple(tags))

    @property
    def size(self) -> int:
        return len(self.data)

    @property
    def word_count(self) -> int:
        return len(self.data) // 2

    @property
    def family_tag(self) -> str | None:
        if not self.header_tags:
            return None
        return self.header_tags[0].split("_", maxsplit=1)[0]

    @property
    def config_length(self) -> int | None:
        if len(self.data) < 6:
            return None
        return int.from_bytes(self.data[4:6], "little")

    def extract_config_records(self) -> tuple[PermanentConfigRecord, ...]:
        config_length = self.config_length
        if config_length is None or config_length <= 0x10:
            return ()

        records: list[PermanentConfigRecord] = []
        offset = 0x10
        while offset + 8 <= config_length:
            if self.data[offset] != 0xCC:
                offset += 1
                continue
            width = self.data[offset + 1]
            if width not in {0, 1, 2, 4, 8}:
                offset += 1
                continue
            address = int.from_bytes(self.data[offset + 2 : offset + 4], "little")
            value = 0
            if width >= 1:
                value |= self.data[offset + 4]
            if width >= 2:
                value |= self.data[offset + 5] << 8
            if width >= 4:
                value |= self.data[offset + 6] << 16
            if width >= 8:
                value |= self.data[offset + 7] << 24
            records.append(PermanentConfigRecord(width=width, address=address, value=value))
            offset += 8
        return tuple(records)

    def build_permanent_image(
        self,
        *,
        config_records: tuple[PermanentConfigRecord, ...] = (),
        config_source: "FirmwareImage | None" = None,
    ) -> PermanentFirmwareImage:
        payload_sections = self._extract_permanent_sections()
        config_image = config_source or self
        config_sections = config_image._extract_permanent_sections()

        if config_sections.family_tag != payload_sections.family_tag:
            raise ValueError(
                "config source and payload source belong to different ASMedia firmware families "
                f"({config_sections.family_tag} != {payload_sections.family_tag})"
            )
        if config_sections.device_type != payload_sections.device_type:
            raise ValueError(
                "config source and payload source belong to different ASMedia device types "
                f"({config_sections.device_type} != {payload_sections.device_type})"
            )

        device_type = payload_sections.device_type
        size_width = 2 if device_type in {0, 1} else 4

        config_blob = bytearray(config_image.data[:0x10])
        canonical_base_length = WINDOWS_BASE_CONFIG_LENGTH_BY_TYPE.get(device_type)
        if canonical_base_length is not None:
            # Match Windows CREATE_ROM for 2142/3142-class images: use the
            # canonical base config block and append new 0xCC records after it.
            config_blob.extend(config_image.data[0x10:canonical_base_length])
            new_config_length = canonical_base_length + len(config_records) * 8
        else:
            config_blob.extend(config_image.data[0x10 : config_sections.config_length])
            new_config_length = config_sections.config_length + len(config_records) * 8
        for record in config_records:
            config_blob.extend(record.to_bytes())
        config_blob[4:6] = struct.pack("<H", new_config_length)

        config_checksum = sum(config_blob[:new_config_length]) & 0xFF
        config_blob.append(config_checksum)
        config_crc = binascii.crc32(config_blob[: new_config_length + 1]) & 0xFFFFFFFF
        config_blob.extend(struct.pack("<I", config_crc))

        rom_data = bytearray(config_blob)
        rom_data.extend(payload_sections.raw_size.to_bytes(size_width, "little"))
        rom_data.extend(payload_sections.raw_data)
        rom_data.extend(payload_sections.fw_signature)
        rom_data.append(payload_sections.fw_checksum)
        rom_data.extend(payload_sections.fw_crc)
        rom_data.extend(payload_sections.fw_extra)

        return PermanentFirmwareImage(
            source=self.source,
            family_tag=payload_sections.family_tag,
            device_type=device_type,
            config_length=new_config_length,
            raw_data=payload_sections.raw_data,
            fw_signature=payload_sections.fw_signature,
            fw_checksum=payload_sections.fw_checksum,
            fw_crc=payload_sections.fw_crc,
            fw_extra=payload_sections.fw_extra,
            rom_data=bytes(rom_data),
            config_records=config_records,
        )

    def iter_sram_writes(self):
        """Yield (SRAM address, 32-bit word) pairs in ASMedia interleaved order."""
        words = self.word_count
        index = 0
        addr = 0

        while index < words:
            data = self._word_at(index)
            upper_index = index | 0x4000
            if upper_index < words:
                data |= self._word_at(upper_index) << 16

            yield addr, data

            index += 1
            if index & 0x4000:
                index += 0x4000
            addr += 2

    def _word_at(self, index: int) -> int:
        offset = index * 2
        return self.data[offset] | (self.data[offset + 1] << 8)

    def _extract_permanent_sections(self) -> "_PermanentSections":
        family_tag = self.family_tag
        if not family_tag or family_tag not in FAMILY_DEVICE_TYPES:
            raise ValueError(
                "internal permanent flashing currently supports only ASMedia images "
                "with known RCFG/FW headers"
            )

        config_length = self.config_length
        if config_length is None:
            raise ValueError("firmware image is truncated before the config size field")
        if config_length < 0x10:
            raise ValueError(f"firmware config length is too small: 0x{config_length:x}")
        if config_length + 5 > len(self.data):
            raise ValueError("firmware image is truncated before the config checksum/CRC fields")

        expected_cfg_checksum = sum(self.data[:config_length]) & 0xFF
        actual_cfg_checksum = self.data[config_length]
        if actual_cfg_checksum != expected_cfg_checksum:
            raise ValueError(
                f"firmware config checksum mismatch: expected 0x{expected_cfg_checksum:02x}, "
                f"got 0x{actual_cfg_checksum:02x}"
            )

        device_type = FAMILY_DEVICE_TYPES[family_tag]
        size_width = 2 if device_type in {0, 1} else 4
        raw_size_offset = config_length + 5
        raw_offset = raw_size_offset + size_width
        raw_size_end = raw_size_offset + size_width
        if raw_size_end > len(self.data):
            raise ValueError("firmware image is truncated before the raw firmware size field")

        raw_size = int.from_bytes(self.data[raw_size_offset:raw_size_end], "little")
        if raw_size <= 0:
            raise ValueError("firmware image raw size is zero")

        raw_end = raw_offset + raw_size
        if raw_end > len(self.data):
            raise ValueError(
                f"firmware image raw payload overruns the file ({raw_end} > {len(self.data)})"
            )

        tail_offset = raw_end
        tail_size = FW_SIGNATURE_SIZE + FW_CHECKSUM_SIZE + FW_CRC_SIZE
        extra_size = FW_EXTRA_SIZE_BY_TYPE.get(device_type, 0)
        tail_end = tail_offset + tail_size + extra_size
        if tail_end > len(self.data):
            raise ValueError("firmware image is truncated before the permanent ROM trailer")

        return _PermanentSections(
            family_tag=family_tag,
            device_type=device_type,
            config_length=config_length,
            customer_info=self.data[0x10:0x30] if device_type > 0 else b"",
            raw_size=raw_size,
            raw_data=self.data[raw_offset:raw_end],
            fw_signature=self.data[tail_offset : tail_offset + FW_SIGNATURE_SIZE],
            fw_checksum=self.data[tail_offset + FW_SIGNATURE_SIZE],
            fw_crc=self.data[
                tail_offset + FW_SIGNATURE_SIZE + FW_CHECKSUM_SIZE : tail_offset + tail_size
            ],
            fw_extra=self.data[tail_offset + tail_size : tail_end],
        )


@dataclass(frozen=True)
class _PermanentSections:
    family_tag: str
    device_type: int
    config_length: int
    customer_info: bytes
    raw_size: int
    raw_data: bytes
    fw_signature: bytes
    fw_checksum: int
    fw_crc: bytes
    fw_extra: bytes


def validate_permanent_image(firmware: PermanentFirmwareImage) -> None:
    roundtrip = FirmwareImage.from_bytes(firmware.rom_data, source=firmware.source)
    sections = roundtrip._extract_permanent_sections()

    if sections.family_tag != firmware.family_tag:
        raise ValueError(
            "rebuilt ROM family tag does not round-trip correctly: "
            f"{sections.family_tag} != {firmware.family_tag}"
        )
    if sections.device_type != firmware.device_type:
        raise ValueError(
            "rebuilt ROM device type does not round-trip correctly: "
            f"{sections.device_type} != {firmware.device_type}"
        )
    if sections.raw_data != firmware.raw_data:
        raise ValueError("rebuilt ROM raw payload does not round-trip correctly")
    if roundtrip.config_length != firmware.config_length:
        raise ValueError(
            "rebuilt ROM config length does not round-trip correctly: "
            f"0x{roundtrip.config_length:x} != 0x{firmware.config_length:x}"
        )
    if sections.fw_signature != firmware.fw_signature:
        raise ValueError("rebuilt ROM firmware signature does not round-trip correctly")
    if sections.fw_checksum != firmware.fw_checksum:
        raise ValueError("rebuilt ROM firmware checksum does not round-trip correctly")
    if sections.fw_crc != firmware.fw_crc:
        raise ValueError("rebuilt ROM firmware CRC does not round-trip correctly")
    if sections.fw_extra != firmware.fw_extra:
        raise ValueError("rebuilt ROM firmware trailer does not round-trip correctly")


def parse_mptool_ini(path: str | Path) -> MpToolIniConfig:
    ini_path = Path(path)
    parser = configparser.ConfigParser()
    parser.optionxform = str.lower
    try:
        with ini_path.open("r", encoding="utf-8-sig") as handle:
            parser.read_file(handle)
    except OSError as exc:
        raise ValueError(f"failed to read MPTool ini file {ini_path}: {exc}") from exc

    config_section = parser["config"] if parser.has_section("config") else {}
    primary_device_keys = ("did", "device", "device_id", "deviceid", "pid")
    present_primary_device_keys = [key for key in primary_device_keys if key in config_section]
    if present_primary_device_keys:
        rendered = ", ".join(present_primary_device_keys)
        raise ValueError(
            f"MPTool ini contains unsupported primary device-id override keys ({rendered}); "
            "asm3042-flasher intentionally blocks primary DID remap in the internal path until it is "
            "validated against the real Windows MPTool behavior on hardware"
        )

    unsupported_primary_id_keys = {"vid", "vendor_id", "vendorid"}
    present_unsupported = sorted(key for key in unsupported_primary_id_keys if key in config_section)
    if present_unsupported:
        rendered = ", ".join(present_unsupported)
        raise ValueError(
            f"MPTool ini contains unsupported vendor-id override keys ({rendered}); "
            "asm3042-flasher currently supports only Windows-validated subsystem SVID/SSID + PCIe speed overrides"
        )
    subsystem_enabled = _ini_bool(config_section.get("subsys_enable", "0"))
    subsystem_vendor_id: int | None = None
    subsystem_device_id: int | None = None
    pcie_link_speed: int | None = None

    if subsystem_enabled:
        if "svid" not in config_section or "ssid" not in config_section:
            raise ValueError("MPTool ini enables subsystem override but is missing svid/ssid")
        subsystem_vendor_id = _parse_ini_int(config_section["svid"], label="svid")
        subsystem_device_id = _parse_ini_int(config_section["ssid"], label="ssid")

    if "pcispeed" in config_section:
        pcie_link_speed = _parse_ini_int(config_section["pcispeed"], label="pcispeed")

    return MpToolIniConfig(
        source=str(ini_path),
        subsystem_vendor_id=subsystem_vendor_id,
        subsystem_device_id=subsystem_device_id,
        pcie_link_speed=pcie_link_speed,
    )


def validate_windows_ini_profile(config: MpToolIniConfig, *, device_type: int) -> None:
    if device_type not in WINDOWS_VALIDATED_DEVICE_TYPES:
        raise ValueError(
            "internal Windows-style ini overrides are only validated for the 2214A/ASM2142/ASM3142-class "
            f"device type, not for type {device_type}"
        )

    if (
        config.subsystem_vendor_id is not None
        and config.subsystem_vendor_id not in WINDOWS_VALIDATED_SUBSYSTEM_VENDOR_IDS
    ):
        rendered = ", ".join(f"0x{value:04x}" for value in sorted(WINDOWS_VALIDATED_SUBSYSTEM_VENDOR_IDS))
        raise ValueError(
            "unsupported subsystem vendor-id override for the validated Windows profile: "
            f"0x{config.subsystem_vendor_id:04x}; expected one of {rendered}"
        )

    if config.subsystem_device_id is not None:
        supported = WINDOWS_VALIDATED_SUBSYSTEM_DEVICE_IDS.get(device_type, set())
        if config.subsystem_device_id not in supported:
            rendered = ", ".join(f"0x{value:04x}" for value in sorted(supported))
            raise ValueError(
                "unsupported subsystem device-id override for the validated Windows profile: "
                f"0x{config.subsystem_device_id:04x}; expected one of {rendered}"
            )

    if (
        config.pcie_link_speed is not None
        and config.pcie_link_speed not in WINDOWS_VALIDATED_PCIE_SPEEDS
    ):
        rendered = ", ".join(f"0x{value:02x}" for value in sorted(WINDOWS_VALIDATED_PCIE_SPEEDS))
        raise ValueError(
            "unsupported PCIe speed override for the validated Windows profile: "
            f"0x{config.pcie_link_speed:02x}; expected one of {rendered}"
        )


def match_validated_internal_target_profile(
    image: FirmwareImage,
    permanent_image: PermanentFirmwareImage,
) -> ValidatedInternalTargetProfile | None:
    if not hasattr(image, "data") or not hasattr(permanent_image, "rom_data"):
        return None

    firmware_sha256 = hashlib.sha256(image.data).hexdigest()
    target_rom_sha256 = hashlib.sha256(permanent_image.rom_data).hexdigest()

    for profile in VALIDATED_INTERNAL_TARGET_PROFILES:
        if profile.device_type != permanent_image.device_type:
            continue
        if profile.firmware_sha256 != firmware_sha256:
            continue
        if profile.target_rom_sha256 != target_rom_sha256:
            continue
        return profile

    return None


def _ini_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_ini_int(value: str, *, label: str) -> int:
    text = value.strip()
    if not text:
        raise ValueError(f"empty integer value for {label}")
    try:
        return int(text, 16 if text.startswith(("0x", "0X")) else 16 if _looks_like_hex(text) else 10)
    except ValueError as exc:
        raise ValueError(f"invalid integer value for {label}: {value!r}") from exc


def _looks_like_hex(value: str) -> bool:
    return all(char in "0123456789abcdefABCDEF" for char in value)
