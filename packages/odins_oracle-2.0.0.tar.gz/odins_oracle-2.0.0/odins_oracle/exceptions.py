"""
Custom exceptions for Odin's Oracle SDK.
"""

from typing import Optional, Dict, Any


class OracleError(Exception):
    """Base exception for Odin's Oracle SDK."""
    
    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_data = response_data


class AuthenticationError(OracleError):
    """Raised when API authentication fails."""
    pass


class RateLimitError(OracleError):
    """Raised when API rate limit is exceeded."""
    pass


class ValidationError(OracleError):
    """Raised when request validation fails."""
    
    def __init__(
        self,
        message: str,
        errors: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        super().__init__(message, **kwargs)
        self.errors = errors


class NotFoundError(OracleError):
    """Raised when a requested resource is not found."""
    pass


class ServerError(OracleError):
    """Raised when the API server returns an error."""
    pass