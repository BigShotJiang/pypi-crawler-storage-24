"""
Odin's Oracle Python SDK

A Python client for the Odin's Oracle API - cosmic intelligence for your applications.

Example:
    >>> from odins_oracle import OracleClient
    >>> client = OracleClient(api_key="your_api_key")
    >>> chart = client.natal_chart(
    ...     birth_date="1990-06-15",
    ...     birth_time="14:30",
    ...     latitude=41.8781,
    ...     longitude=-87.6298
    ... )
    >>> print(chart.sun.sign)
    'Gemini'

Agent Soul Protocol:
    >>> from odins_oracle import AgentSoul
    >>> soul = AgentSoul.register("MyBot")
    >>> print(soul.aso.voice.system_prompt_fragment)

Framework Integrations (optional — install crewai or langchain separately):
    >>> from odins_oracle.integrations.crewai import create_soul_agent
    >>> from odins_oracle.integrations.langchain import soul_system_message
"""

__version__ = "2.0.0"
__author__ = "Odin's Eye Enterprises"

from .client import OracleClient
from .models import (
    NatalChart,
    PlanetPosition,
    HouseCusp,
    Aspect,
    ChartSignature,
    Transit,
)
from .exceptions import (
    OracleError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
)
from .agent_soul import (
    AgentSoul,
    AgentSoulObject,
    Voice,
    Archetypes,
    Harmonic,
    CompatibilityReport,
    DailyGuidance,
)

__all__ = [
    "OracleClient",
    "NatalChart",
    "PlanetPosition",
    "HouseCusp",
    "Aspect",
    "ChartSignature",
    "Transit",
    "OracleError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "AgentSoul",
    "AgentSoulObject",
    "Voice",
    "Archetypes",
    "Harmonic",
    "CompatibilityReport",
    "DailyGuidance",
]