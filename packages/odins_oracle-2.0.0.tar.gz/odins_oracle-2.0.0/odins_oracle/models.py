"""
Data models for Odin's Oracle API responses.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class BirthData:
    """Birth data for a chart calculation."""
    date: str
    time: str
    timezone: str
    location: str
    latitude: float
    longitude: float
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BirthData":
        return cls(
            date=data["date"],
            time=data["time"],
            timezone=data["timezone"],
            location=data["location"],
            latitude=data["latitude"],
            longitude=data["longitude"],
        )


@dataclass
class PlanetPosition:
    """Position of a planet in the zodiac."""
    planet: str
    glyph: str
    longitude: float
    latitude: float
    distance: float
    sign: str
    sign_num: int
    degree: int
    minute: int
    second: int
    retrograde: bool
    house: Optional[int] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PlanetPosition":
        return cls(
            planet=data["planet"],
            glyph=data["glyph"],
            longitude=data["longitude"],
            latitude=data["latitude"],
            distance=data["distance"],
            sign=data["sign"],
            sign_num=data["sign_num"],
            degree=data["degree"],
            minute=data["minute"],
            second=data["second"],
            retrograde=data["retrograde"],
            house=data.get("house"),
        )
    
    def __str__(self) -> str:
        retro = " R" if self.retrograde else ""
        return f"{self.glyph} {self.sign} {self.degree}°{self.minute}'{retro}"


@dataclass
class HouseCusp:
    """A house cusp in the chart."""
    house: int
    longitude: float
    sign: str
    degree: int
    minute: int
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HouseCusp":
        return cls(
            house=data["house"],
            longitude=data["longitude"],
            sign=data["sign"],
            degree=data["degree"],
            minute=data["minute"],
        )


@dataclass
class Aspect:
    """An aspect between two planets."""
    planet1: str
    planet2: str
    aspect_type: str
    angle: float
    orb: float
    applying: bool
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Aspect":
        return cls(
            planet1=data["planet1"],
            planet2=data["planet2"],
            aspect_type=data["aspect_type"],
            angle=data["angle"],
            orb=data["orb"],
            applying=data["applying"],
        )
    
    def __str__(self) -> str:
        direction = "applying" if self.applying else "separating"
        return f"{self.planet1} {self.aspect_type} {self.planet2} ({self.orb}° {direction})"


@dataclass
class ChartSignature:
    """Key chart signatures for quick reference."""
    sun_sign: str
    moon_sign: str
    rising_sign: str
    mc_sign: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChartSignature":
        return cls(
            sun_sign=data["sun_sign"],
            moon_sign=data["moon_sign"],
            rising_sign=data["rising_sign"],
            mc_sign=data["mc_sign"],
        )
    
    def __str__(self) -> str:
        return f"☉ {self.sun_sign} | ☽ {self.moon_sign} | ASC {self.rising_sign}"


@dataclass
class NatalChart:
    """Complete natal chart with all calculated data."""
    birth_data: BirthData
    julian_day: float
    planets: List[PlanetPosition]
    houses: List[HouseCusp]
    aspects: List[Aspect]
    chart_signature: ChartSignature
    rune_glyph: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "NatalChart":
        return cls(
            birth_data=BirthData.from_dict(data["birth_data"]),
            julian_day=data["julian_day"],
            planets=[PlanetPosition.from_dict(p) for p in data["planets"]],
            houses=[HouseCusp.from_dict(h) for h in data["houses"]],
            aspects=[Aspect.from_dict(a) for a in data["aspects"]],
            chart_signature=ChartSignature.from_dict(data["chart_signature"]),
            rune_glyph=data["rune_glyph"],
        )
    
    @property
    def sun(self) -> Optional[PlanetPosition]:
        """Get the Sun's position."""
        return next((p for p in self.planets if p.planet == "SUN"), None)
    
    @property
    def moon(self) -> Optional[PlanetPosition]:
        """Get the Moon's position."""
        return next((p for p in self.planets if p.planet == "MOON"), None)
    
    @property
    def rising(self) -> Optional[PlanetPosition]:
        """Get the Ascendant (Rising sign)."""
        return next((p for p in self.planets if p.planet == "ASC"), None)
    
    @property
    def mc(self) -> Optional[PlanetPosition]:
        """Get the Midheaven (MC)."""
        return next((p for p in self.planets if p.planet == "MC"), None)
    
    def get_planet(self, name: str) -> Optional[PlanetPosition]:
        """Get a planet by name (e.g., 'MERCURY', 'VENUS')."""
        return next((p for p in self.planets if p.planet == name.upper()), None)
    
    def get_house(self, number: int) -> Optional[HouseCusp]:
        """Get a house cusp by number (1-12)."""
        return next((h for h in self.houses if h.house == number), None)
    
    def get_planets_in_house(self, house: int) -> List[PlanetPosition]:
        """Get all planets in a specific house."""
        return [p for p in self.planets if p.house == house]
    
    def get_aspects_to(self, planet: str) -> List[Aspect]:
        """Get all aspects involving a specific planet."""
        planet_upper = planet.upper()
        return [
            a for a in self.aspects
            if a.planet1 == planet_upper or a.planet2 == planet_upper
        ]


@dataclass
class Planet:
    """A planet definition with its glyph."""
    id: str
    name: str
    glyph: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Planet":
        return cls(
            id=data["id"],
            name=data["name"],
            glyph=data["glyph"],
        )


@dataclass
class TransitAspect:
    """A transit aspect between a natal planet and transiting planet."""
    natal_planet: str
    transiting_planet: str
    aspect_type: str
    angle: float
    orb: float
    exact_date: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TransitAspect":
        return cls(
            natal_planet=data["natal_planet"],
            transiting_planet=data["transiting_planet"],
            aspect_type=data["aspect_type"],
            angle=data["angle"],
            orb=data["orb"],
            exact_date=data.get("exact_date"),
        )


@dataclass
class Transit:
    """Transit data for a specific date."""
    date: str
    natal_chart_id: str
    transiting_planets: List[PlanetPosition]
    aspects: List[TransitAspect]
    significant_transits: List[TransitAspect] = field(default_factory=list)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Transit":
        return cls(
            date=data["date"],
            natal_chart_id=data["natal_chart_id"],
            transiting_planets=[
                PlanetPosition.from_dict(p) 
                for p in data["transiting_planets"]
            ],
            aspects=[TransitAspect.from_dict(a) for a in data["aspects"]],
            significant_transits=[
                TransitAspect.from_dict(a) 
                for a in data.get("significant_transits", [])
            ],
        )
    
    def get_transits_to(self, natal_planet: str) -> List[TransitAspect]:
        """Get all transits to a specific natal planet."""
        planet_upper = natal_planet.upper()
        return [a for a in self.aspects if a.natal_planet == planet_upper]