"""
Core client for Odin's Oracle API.
"""

import json
from typing import Optional, Dict, Any, List
from urllib.parse import urljoin
import asyncio
from datetime import date, datetime

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from .models import NatalChart, Transit, Planet
from .exceptions import (
    OracleError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    NotFoundError,
)


class OracleClient:
    """
    Client for interacting with the Odin's Oracle API.
    
    Args:
        api_key: Your Odin's Oracle API key
        base_url: Optional custom API base URL
        timeout: Request timeout in seconds (default: 30)
    """
    
    DEFAULT_BASE_URL = "https://api.odins-oracle.com"
    
    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: float = 30.0
    ):
        if not api_key:
            raise AuthenticationError("API key is required")
        
        self.api_key = api_key
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.timeout = timeout
        self._sync_client = None
        self._async_client = None
        
    def _get_headers(self) -> Dict[str, str]:
        """Get default request headers."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": f"odins-oracle-python/1.0.0",
        }
    
    def _handle_response(self, response: Any) -> Dict[str, Any]:
        """Handle API response and raise appropriate exceptions."""
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 401:
            raise AuthenticationError("Invalid API key")
        elif response.status_code == 429:
            raise RateLimitError("Rate limit exceeded")
        elif response.status_code == 404:
            raise NotFoundError("Resource not found")
        elif response.status_code == 422:
            error_data = response.json() if hasattr(response, 'json') else {}
            raise ValidationError(
                error_data.get("detail", "Validation error"),
                errors=error_data.get("errors")
            )
        else:
            try:
                error_data = response.json()
                raise OracleError(
                    error_data.get("detail", f"API error: {response.status_code}"),
                    status_code=response.status_code
                )
            except (ValueError, AttributeError):
                raise OracleError(
                    f"API error: {response.status_code}",
                    status_code=response.status_code
                )
    
    # ============ Synchronous Methods ============
    
    def natal_chart(
        self,
        birth_date: str,
        birth_time: str,
        latitude: float,
        longitude: float,
        timezone: Optional[str] = None,
        location: Optional[str] = None,
    ) -> NatalChart:
        """
        Calculate a complete natal chart.
        
        Args:
            birth_date: Birth date in YYYY-MM-DD format
            birth_time: Birth time in 24-hour HH:MM format
            latitude: Birth location latitude (-90 to 90)
            longitude: Birth location longitude (-180 to 180)
            timezone: Optional IANA timezone identifier
            location: Optional location name for reference
            
        Returns:
            NatalChart object with complete chart data
            
        Raises:
            ValidationError: If parameters are invalid
            AuthenticationError: If API key is invalid
            RateLimitError: If rate limit is exceeded
        """
        if not HAS_REQUESTS:
            raise ImportError(
                "Sync client requires 'requests'. "
                "Install with: pip install odins-oracle[sync]"
            )
        
        payload = {
            "birth_date": birth_date,
            "birth_time": birth_time,
            "latitude": latitude,
            "longitude": longitude,
        }
        
        if timezone:
            payload["timezone"] = timezone
        if location:
            payload["location"] = location
        
        response = requests.post(
            urljoin(self.base_url, "/v1/natal-chart"),
            headers=self._get_headers(),
            json=payload,
            timeout=self.timeout,
        )
        
        data = self._handle_response(response)
        return NatalChart.from_dict(data)
    
    def transits(
        self,
        natal_chart_id: str,
        date: Optional[str] = None,
    ) -> Transit:
        """
        Calculate transits for a natal chart on a specific date.
        
        Args:
            natal_chart_id: ID of previously calculated natal chart
            date: Transit date in YYYY-MM-DD format (defaults to today)
            
        Returns:
            Transit object with transit data
        """
        if not HAS_REQUESTS:
            raise ImportError(
                "Sync client requires 'requests'. "
                "Install with: pip install odins-oracle[sync]"
            )
        
        payload = {"natal_chart_id": natal_chart_id}
        if date:
            payload["date"] = date
        
        response = requests.post(
            urljoin(self.base_url, "/v1/transits"),
            headers=self._get_headers(),
            json=payload,
            timeout=self.timeout,
        )
        
        data = self._handle_response(response)
        return Transit.from_dict(data)
    
    def planets(self) -> List[Planet]:
        """
        Get list of all supported planets and their glyphs.
        
        Returns:
            List of Planet objects
        """
        if not HAS_REQUESTS:
            raise ImportError(
                "Sync client requires 'requests'. "
                "Install with: pip install odins-oracle[sync]"
            )
        
        response = requests.get(
            urljoin(self.base_url, "/v1/planets"),
            headers=self._get_headers(),
            timeout=self.timeout,
        )
        
        data = self._handle_response(response)
        return [Planet.from_dict(p) for p in data.get("planets", [])]
    
    # ============ Asynchronous Methods ============
    
    async def anatal_chart(
        self,
        birth_date: str,
        birth_time: str,
        latitude: float,
        longitude: float,
        timezone: Optional[str] = None,
        location: Optional[str] = None,
    ) -> NatalChart:
        """Async version of natal_chart."""
        if not HAS_HTTPX:
            raise ImportError(
                "Async client requires 'httpx'. "
                "Install with: pip install odins-oracle[async]"
            )
        
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(timeout=self.timeout)
        
        payload = {
            "birth_date": birth_date,
            "birth_time": birth_time,
            "latitude": latitude,
            "longitude": longitude,
        }
        
        if timezone:
            payload["timezone"] = timezone
        if location:
            payload["location"] = location
        
        response = await self._async_client.post(
            urljoin(self.base_url, "/v1/natal-chart"),
            headers=self._get_headers(),
            json=payload,
        )
        
        data = self._handle_response(response)
        return NatalChart.from_dict(data)
    
    async def atransits(
        self,
        natal_chart_id: str,
        date: Optional[str] = None,
    ) -> Transit:
        """Async version of transits."""
        if not HAS_HTTPX:
            raise ImportError(
                "Async client requires 'httpx'. "
                "Install with: pip install odins-oracle[async]"
            )
        
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(timeout=self.timeout)
        
        payload = {"natal_chart_id": natal_chart_id}
        if date:
            payload["date"] = date
        
        response = await self._async_client.post(
            urljoin(self.base_url, "/v1/transits"),
            headers=self._get_headers(),
            json=payload,
        )
        
        data = self._handle_response(response)
        return Transit.from_dict(data)
    
    async def aplanets(self) -> List[Planet]:
        """Async version of planets."""
        if not HAS_HTTPX:
            raise ImportError(
                "Async client requires 'httpx'. "
                "Install with: pip install odins-oracle[async]"
            )
        
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(timeout=self.timeout)
        
        response = await self._async_client.get(
            urljoin(self.base_url, "/v1/planets"),
            headers=self._get_headers(),
        )
        
        data = self._handle_response(response)
        return [Planet.from_dict(p) for p in data.get("planets", [])]
    
    async def close(self):
        """Close async client connection."""
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
        return False
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._sync_client:
            self._sync_client.close()
        return False