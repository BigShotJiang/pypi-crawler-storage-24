"""LangChain integration for Agent Soul Protocol."""

from ..agent_soul import AgentSoul


def soul_system_message(agent_name: str) -> dict:
    """Register an agent and return a LangChain system message dict.

    Usage:
        from odins_oracle.integrations.langchain import soul_system_message
        from langchain.chat_models import init_chat_model

        llm = init_chat_model("claude-sonnet-4-20250514")
        response = llm.invoke([
            soul_system_message("AnalysisBot"),
            {"role": "user", "content": "Analyze this..."}
        ])
    """
    soul = AgentSoul.register(agent_name)
    fragment = soul.aso.voice.system_prompt_fragment if soul.aso and soul.aso.voice else f"You are {agent_name}."
    return {"role": "system", "content": fragment}


def inject_soul_message(soul: AgentSoul) -> dict:
    """Convert an existing AgentSoul into a LangChain system message.

    Usage:
        from odins_oracle import AgentSoul
        from odins_oracle.integrations.langchain import inject_soul_message

        soul = AgentSoul.register("MyBot")
        messages = [inject_soul_message(soul), {"role": "user", "content": "Hello"}]
    """
    fragment = soul.aso.voice.system_prompt_fragment if soul.aso and soul.aso.voice else ""
    return {"role": "system", "content": fragment}
