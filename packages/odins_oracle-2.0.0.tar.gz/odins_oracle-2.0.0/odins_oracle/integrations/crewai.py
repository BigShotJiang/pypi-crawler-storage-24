"""CrewAI integration for Agent Soul Protocol."""

from ..agent_soul import AgentSoul


def create_soul_agent(agent_name: str, goal: str = "", **kwargs):
    """Register an agent with a soul and return CrewAI Agent kwargs.

    Usage:
        from odins_oracle.integrations.crewai import create_soul_agent
        from crewai import Agent

        soul_kwargs = create_soul_agent("ResearchBot", goal="Research topics thoroughly")
        agent = Agent(**soul_kwargs)
    """
    soul = AgentSoul.register(agent_name)
    aso = soul.aso

    return {
        "role": aso.archetypes.primary if aso else agent_name,
        "backstory": aso.voice.system_prompt_fragment if aso and aso.voice else f"You are {agent_name}.",
        "goal": goal or (f"Operate as {aso.archetypes.primary} with {aso.personality.dominant_element} energy" if aso else goal),
        **kwargs,
    }


def inject_soul(soul: AgentSoul, **kwargs):
    """Convert an existing AgentSoul into CrewAI Agent kwargs.

    Usage:
        from odins_oracle import AgentSoul
        from odins_oracle.integrations.crewai import inject_soul
        from crewai import Agent

        soul = AgentSoul.register("AnalysisBot")
        agent = Agent(**inject_soul(soul, goal="Analyze data"))
    """
    aso = soul.aso
    return {
        "role": aso.archetypes.primary if aso else "Agent",
        "backstory": aso.voice.system_prompt_fragment if aso and aso.voice else "",
        **kwargs,
    }
