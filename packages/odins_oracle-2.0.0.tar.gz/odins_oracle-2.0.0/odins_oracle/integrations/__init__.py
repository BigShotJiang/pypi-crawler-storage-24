"""Framework integrations for Agent Soul Protocol."""
