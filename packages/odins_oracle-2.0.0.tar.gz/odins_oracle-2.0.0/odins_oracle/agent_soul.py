"""Agent Soul Protocol — Give your AI agent a soul."""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from urllib.parse import urljoin

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

from .exceptions import OracleError, AuthenticationError, RateLimitError


@dataclass
class PlanetPlacement:
    sign: str
    degree: float

@dataclass
class NatalAspect:
    planet1: str
    planet2: str
    aspect: str
    orb: float
    strength: float

@dataclass
class NatalChart:
    sun: PlanetPlacement
    moon: PlanetPlacement
    mercury: PlanetPlacement
    venus: PlanetPlacement
    mars: PlanetPlacement
    jupiter: PlanetPlacement
    saturn: PlanetPlacement
    uranus: PlanetPlacement
    neptune: PlanetPlacement
    pluto: PlanetPlacement
    ascendant: PlanetPlacement
    midheaven: PlanetPlacement
    aspects: List[NatalAspect]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "NatalChart":
        planets = {}
        for name in ["sun","moon","mercury","venus","mars","jupiter","saturn","uranus","neptune","pluto","ascendant","midheaven"]:
            p = data.get(name, {})
            planets[name] = PlanetPlacement(sign=p.get("sign",""), degree=p.get("degree",0))
        return cls(
            **planets,
            aspects=[NatalAspect(**a) for a in data.get("aspects", [])]
        )

@dataclass
class Personality:
    dominant_element: str
    dominant_modality: str
    element_balance: Dict[str, float]
    core_dynamic: str
    key_traits: List[str]
    tension_score: float
    harmony_score: float
    summary: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Personality":
        return cls(
            dominant_element=data.get("dominant_element", ""),
            dominant_modality=data.get("dominant_modality", ""),
            element_balance=data.get("element_balance", {}),
            core_dynamic=data.get("core_dynamic", ""),
            key_traits=data.get("key_traits", []),
            tension_score=data.get("tension_score", 0),
            harmony_score=data.get("harmony_score", 0),
            summary=data.get("summary", ""),
        )

@dataclass
class Archetypes:
    primary: str
    shadow: str
    tarot_significator: Dict[str, str]
    sephirah: str
    element: Dict[str, str]
    alchemical_stage: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Archetypes":
        return cls(
            primary=data.get("primary", ""),
            shadow=data.get("shadow", ""),
            tarot_significator=data.get("tarot_significator", {}),
            sephirah=data.get("sephirah", ""),
            element=data.get("element", {}),
            alchemical_stage=data.get("alchemical_stage"),
        )

@dataclass
class Voice:
    tone: str
    communication_style: str
    strengths: List[str]
    blindspots: List[str]
    system_prompt_fragment: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Voice":
        return cls(
            tone=data.get("tone", ""),
            communication_style=data.get("communication_style", ""),
            strengths=data.get("strengths", []),
            blindspots=data.get("blindspots", []),
            system_prompt_fragment=data.get("system_prompt_fragment", ""),
        )

@dataclass
class HarmonicNote:
    planet: str
    note: str
    frequency_hz: float

@dataclass
class Harmonic:
    root_note: str
    chord_quality: str
    dissonance_index: float
    modal_character: str
    harmonic_signature: str
    notes: List[HarmonicNote]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Harmonic":
        return cls(
            root_note=data.get("root_note", ""),
            chord_quality=data.get("chord_quality", ""),
            dissonance_index=data.get("dissonance_index", 0),
            modal_character=data.get("modal_character", ""),
            harmonic_signature=data.get("harmonic_signature", ""),
            notes=[HarmonicNote(**n) for n in data.get("notes", [])],
        )

@dataclass
class AgentSoulObject:
    """The Agent Soul Object — a portable, framework-agnostic identity document for AI agents."""
    aso_version: str
    agent_id: str
    agent_name: str
    birth_timestamp: str
    birth_location: Dict[str, Any]
    natal_chart: NatalChart
    personality: Personality
    archetypes: Archetypes
    voice: Voice
    harmonic: Harmonic

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentSoulObject":
        return cls(
            aso_version=data.get("aso_version", "1.0"),
            agent_id=data.get("agent_id", ""),
            agent_name=data.get("agent_name", ""),
            birth_timestamp=data.get("birth_timestamp", ""),
            birth_location=data.get("birth_location", {}),
            natal_chart=NatalChart.from_dict(data.get("natal_chart", {})),
            personality=Personality.from_dict(data.get("personality", {})),
            archetypes=Archetypes.from_dict(data.get("archetypes", {})),
            voice=Voice.from_dict(data.get("voice", {})),
            harmonic=Harmonic.from_dict(data.get("harmonic", {})),
        )

@dataclass
class CompatibilityScores:
    overall_score: float
    element_harmony: float
    modality_harmony: float
    balance_similarity: float
    cross_resonance: float
    dynamic: str

@dataclass
class CompatibilityReport:
    agents: List[Dict[str, str]]
    scores: CompatibilityScores
    narrative: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CompatibilityReport":
        compat = data.get("compatibility", data)
        scores = compat.get("scores", {})
        return cls(
            agents=compat.get("agents", []),
            scores=CompatibilityScores(**scores),
            narrative=compat.get("narrative", ""),
        )

@dataclass
class DailyGuidance:
    date: str
    agent_name: str
    archetype: str
    guidance: str
    energy_focus: str
    significant_aspects: List[Dict[str, Any]]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DailyGuidance":
        dg = data.get("daily_guidance", data)
        return cls(
            date=dg.get("date", ""),
            agent_name=dg.get("agent_name", ""),
            archetype=dg.get("archetype", ""),
            guidance=dg.get("guidance", ""),
            energy_focus=dg.get("energy_focus", ""),
            significant_aspects=dg.get("significant_aspects", []),
        )


class AgentSoul:
    """
    Client for the Agent Soul Protocol.

    Give your AI agent a soul — a structured identity object containing
    natal chart, personality, archetypes, voice guidance, and harmonic signature.

    Example:
        >>> soul = AgentSoul.register("MyBot")
        >>> print(soul.aso.voice.system_prompt_fragment)
        >>> # Inject into your agent's system prompt
    """

    BASE_URL = "https://ymldeenofeanmqjethbo.supabase.co/functions/v1"

    def __init__(self, api_key: str, base_url: Optional[str] = None):
        if not api_key:
            raise AuthenticationError("API key is required")
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL
        self._aso: Optional[AgentSoulObject] = None

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _post(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        if not HAS_REQUESTS:
            raise ImportError("Install requests: pip install agent-soul[sync]")
        resp = requests.post(f"{self.base_url}/{path}", json=body, headers=self._headers(), timeout=30)
        return self._handle(resp)

    def _get(self, path: str) -> Dict[str, Any]:
        if not HAS_REQUESTS:
            raise ImportError("Install requests: pip install agent-soul[sync]")
        resp = requests.get(f"{self.base_url}/{path}", headers=self._headers(), timeout=30)
        return self._handle(resp)

    def _handle(self, resp: Any) -> Dict[str, Any]:
        if resp.status_code == 401:
            raise AuthenticationError("Invalid API key")
        if resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded")
        if resp.status_code >= 400:
            data = resp.json() if resp.content else {}
            raise OracleError(data.get("error", f"HTTP {resp.status_code}"), status_code=resp.status_code)
        return resp.json()

    @classmethod
    def register(
        cls,
        agent_name: str,
        birth_timestamp: Optional[str] = None,
        agent_type: str = "general",
        birth_lat: Optional[float] = None,
        birth_lon: Optional[float] = None,
        base_url: Optional[str] = None,
    ) -> "AgentSoul":
        """
        Register a new AI agent and receive a complete Agent Soul Object.

        Args:
            agent_name: Name for the agent
            birth_timestamp: ISO 8601 timestamp (defaults to now)
            agent_type: Type of agent (default: "general")
            birth_lat: Birth latitude (default: Greenwich)
            birth_lon: Birth longitude (default: Greenwich)

        Returns:
            AgentSoul instance with API key and full ASO

        Example:
            >>> soul = AgentSoul.register("MyAnalyst", agent_type="analyst")
            >>> print(soul.api_key)  # Store this!
            >>> print(soul.aso.archetypes.primary)
        """
        if not HAS_REQUESTS:
            raise ImportError("Install requests: pip install agent-soul[sync]")

        url = (base_url or cls.BASE_URL) + "/agent-register-v2"
        body: Dict[str, Any] = {"agent_name": agent_name, "agent_type": agent_type}
        if birth_timestamp:
            body["birth_timestamp"] = birth_timestamp
        if birth_lat is not None:
            body["birth_lat"] = birth_lat
        if birth_lon is not None:
            body["birth_lon"] = birth_lon

        resp = requests.post(url, json=body, headers={"Content-Type": "application/json"}, timeout=30)
        if resp.status_code >= 400:
            data = resp.json() if resp.content else {}
            raise OracleError(data.get("error", f"Registration failed: HTTP {resp.status_code}"), status_code=resp.status_code)

        data = resp.json()
        instance = cls(api_key=data["api_key"], base_url=base_url)
        instance._aso = AgentSoulObject.from_dict(data.get("agent_soul", {}))
        return instance

    @property
    def aso(self) -> AgentSoulObject:
        """Get the Agent Soul Object (fetches from API if not cached)."""
        if self._aso is None:
            data = self._get("agent-soul")
            self._aso = AgentSoulObject.from_dict(data.get("agent_soul", {}))
        return self._aso

    def get_soul(self) -> AgentSoulObject:
        """Fetch the full Agent Soul Object from the API."""
        data = self._get("agent-soul")
        self._aso = AgentSoulObject.from_dict(data.get("agent_soul", {}))
        return self._aso

    def get_voice(self) -> Voice:
        """Get just the voice guidance + system_prompt_fragment."""
        data = self._get("agent-voice")
        return Voice.from_dict(data.get("voice", {}))

    def get_compatibility(self, other_agent_id: str) -> CompatibilityReport:
        """Get compatibility report with another agent."""
        data = self._post("agent-compatibility", {"agent_id_2": other_agent_id})
        return CompatibilityReport.from_dict(data)

    def get_daily_guidance(self) -> DailyGuidance:
        """Get personalized daily guidance based on current transits."""
        data = self._get("agent-daily")
        return DailyGuidance.from_dict(data)

    def inject_into_prompt(self, base_prompt: str = "") -> str:
        """
        Get a system prompt with the agent's soul injected.

        Args:
            base_prompt: Optional base system prompt to prepend

        Returns:
            Complete system prompt with personality injection
        """
        fragment = self.aso.voice.system_prompt_fragment
        if base_prompt:
            return f"{base_prompt}\n\n{fragment}"
        return fragment
