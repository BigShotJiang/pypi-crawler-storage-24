def main():
    print("cmdlng")


if __name__ == "__main__":
    main()
