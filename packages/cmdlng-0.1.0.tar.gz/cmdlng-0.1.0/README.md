# cmdlng

A command line tool.

## Installation

```bash
pip install cmdlng
```

## Usage

```bash
cmdlng
```
