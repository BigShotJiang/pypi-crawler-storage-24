# Copyright 2017-2019 Carlos Dauden <carlos.dauden@tecnativa.com>
# Copyright 2018 David Vidal <david.vidal@tecnativa.com>
# Copyright 2018-2019 Tecnativa - Pedro M. Baeza
# Copyright 2021 Tecnativa - João Marques
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Account Invoice Grouped by Picking",
    "summary": "Print invoice lines grouped by picking",
    "version": "19.0.1.0.0",
    "category": "Accounting & Finance",
    "website": "https://github.com/OCA/account-invoice-reporting",
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "depends": ["sale_stock_picking_invoice_link"],
    "data": ["views/report_invoice.xml"],
    "installable": True,
}
