"""
Caprail View Engine.

Jinja2-based template engine.

Templates use standard Jinja2 syntax with a ``.html`` extension and dot-notation
name resolution::

    await ViewEngine.instance().render("welcome", {"name": "Alice"})
    await ViewEngine.instance().render("auth.login", {})   # → auth/login.html

Global helpers available in every template:

    {{ csrf_field() | safe }}           — CSRF hidden input
    {{ method_field('PUT') | safe }}    — method spoofing hidden input
    {{ vite(['resources/js/app.js']) | safe }}
    {{ asset('images/logo.png') }}
    {{ route('home') }}

Global variables always in scope:

    auth_user       — current User object or None
    app_name        — application name from config
    flash_success   — one-time success message or None
    flash_error     — one-time error message or None
    flash_info      — one-time info message or None
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape


_INSTANCE: "ViewEngine | None" = None


class ViewEngine:
    """
    The Caprail view engine.

    Configure once at startup via ``ViewEngine.configure(views_path)``,
    then use ``ViewEngine.instance()`` anywhere.
    """

    def __init__(self, views_path: str | Path, cache_path: str | Path | None = None) -> None:
        self._views_path = Path(views_path)
        self._cache_path = Path(cache_path) if cache_path else None
        self._globals: dict[str, Any] = {}
        self._request_ctx: dict[str, Any] = {}
        self._env = self._build_env()

    @classmethod
    def configure(cls, views_path: str | Path, **kwargs) -> "ViewEngine":
        global _INSTANCE
        _INSTANCE = cls(views_path, **kwargs)
        return _INSTANCE

    @classmethod
    def instance(cls) -> "ViewEngine":
        if _INSTANCE is None:
            raise RuntimeError("ViewEngine not configured. Call ViewEngine.configure() first.")
        return _INSTANCE

    def share(self, key: str, value: Any) -> None:
        """Share a variable with all views (persists across requests)."""
        self._globals[key] = value
        self._env.globals[key] = value

    def set_request_context(self, data: dict[str, Any]) -> None:
        """Inject per-request variables (e.g. auth_user) into every template."""
        self._request_ctx = data

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    async def render(self, template: str, data: dict | None = None) -> str:
        name = self._normalise_name(template)
        tpl = self._env.get_template(name)
        ctx = {**self._globals, **self._request_ctx, **(data or {})}
        return tpl.render(**ctx)

    async def render_response(self, template: str, data: dict | None = None, status: int = 200):
        from caprail.http.response import Response
        html = await self.render(template, data)
        return Response(html, status=status)

    def render_sync(self, template: str, data: dict | None = None) -> str:
        name = self._normalise_name(template)
        tpl = self._env.get_template(name)
        ctx = {**self._globals, **self._request_ctx, **(data or {})}
        return tpl.render(**ctx)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_env(self) -> Environment:
        env = Environment(
            loader=FileSystemLoader(str(self._views_path)),
            autoescape=select_autoescape(["html", "htm"]),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        env.globals.update(self._globals)
        # Helpers available in all templates
        env.globals["csrf_field"] = self._csrf_field
        env.globals["method_field"] = self._method_field
        env.globals["vite"] = self._vite
        env.globals["asset"] = self._asset
        env.globals["route"] = self._route_url
        # Per-request globals with safe defaults
        env.globals["auth_user"] = None
        env.globals["flash_success"] = None
        env.globals["flash_error"] = None
        env.globals["flash_info"] = None
        env.globals["app_name"] = "Caprail"
        return env

    @staticmethod
    def _normalise_name(name: str) -> str:
        """Convert dot notation to path: 'layouts.app' → 'layouts/app.html'"""
        if name.endswith(".html") or name.endswith(".jinja2") or name.endswith(".j2"):
            return name
        return name.replace(".", "/") + ".html"

    # ------------------------------------------------------------------
    # Global helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _csrf_field() -> str:
        return '<input type="hidden" name="_token" value="csrf-placeholder">'

    @staticmethod
    def _method_field(method: str) -> str:
        return f'<input type="hidden" name="_method" value="{method}">'

    @staticmethod
    def _vite(assets: list[str]) -> str:
        tags = []
        for asset in assets:
            if asset.endswith(".css"):
                tags.append(f'<link rel="stylesheet" href="/build/{asset}">')
            else:
                tags.append(f'<script type="module" src="/build/{asset}"></script>')
        return "\n".join(tags)

    @staticmethod
    def _asset(path: str) -> str:
        return f"/public/{path.lstrip('/')}"

    @staticmethod
    def _route_url(name: str, **params) -> str:
        try:
            from caprail.support.helpers import route as route_helper
            return route_helper(name, **params)
        except Exception:
            return f"/{name}"
