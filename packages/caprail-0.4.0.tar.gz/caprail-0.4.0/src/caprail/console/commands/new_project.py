"""caprail new <project-name> — scaffold a new Caprail project."""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


def command(
    name: str = typer.Argument(..., help="Project name / directory (use '.' for current directory)"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing directory"),
) -> None:
    """Create a new Caprail project."""
    if name == ".":
        dest = Path.cwd()
        project_name = dest.name
    else:
        dest = Path.cwd() / name
        project_name = name

    if name != "." and dest.exists():
        if not force:
            console.print(f"[red]Directory already exists:[/] {dest}")
            raise typer.Exit(1)
        shutil.rmtree(dest)

    if name == "." and not force:
        existing = [p for p in dest.iterdir() if not p.name.startswith(".")]
        if existing:
            console.print(f"[red]Current directory is not empty.[/] Use [cyan]--force[/] to scaffold anyway.")
            raise typer.Exit(1)

    console.print(f"\n[bold green]Creating Caprail project:[/] [cyan]{project_name}[/]\n")

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        task = progress.add_task("Scaffolding project structure...", total=None)
        _scaffold(dest, project_name)
        progress.update(task, description="[green]Project structure created")

    console.print(f"\n[bold green]✓ Project created![/] [cyan]{dest}[/]\n")
    console.print("  Next steps:")
    if name != ".":
        console.print(f"    [cyan]cd {project_name}[/]")
    console.print("    [cyan]uv sync[/]")
    console.print("    [cyan]npm install[/]")
    console.print("    [cyan]cp .env.example .env[/]")
    console.print("    [cyan]caprail key:generate[/]")
    console.print("    [cyan]caprail serve[/]\n")


def _scaffold(dest: Path, name: str) -> None:
    dest.mkdir(parents=True, exist_ok=True)

    # ── Directory structure ───────────────────────────────────────────
    dirs = [
        "app/Http/Controllers",
        "app/Http/Controllers/Auth",
        "app/Http/Middleware",
        "app/Http/Requests",
        "app/Models",
        "app/Providers",
        "bootstrap",
        "config",
        "database/migrations",
        "database/seeders",
        "public",
        "resources/css",
        "resources/js",
        "resources/views/layouts",
        "resources/views/auth",
        "routes",
        "storage/app",
        "storage/logs",
        "tests",
    ]
    for d in dirs:
        (dest / d).mkdir(parents=True, exist_ok=True)
        (dest / d / ".gitkeep").touch()

    # ── Files ─────────────────────────────────────────────────────────
    _write(dest / ".env.example", _env_example(name))
    _write(dest / ".gitignore", _gitignore())
    _write(dest / "pyproject.toml", _pyproject(name))
    _write(dest / "README.md", f"# {name}\n\nA Caprail application.\n")

    # Bootstrap
    _write(dest / "bootstrap" / "app.py", _bootstrap_app())

    # Routes
    _write(dest / "routes" / "web.py", _routes_web())
    _write(dest / "routes" / "api.py", _routes_api())

    # Config
    _write(dest / "config" / "app.py", _config_app(name))
    _write(dest / "config" / "database.py", _config_database())
    _write(dest / "config" / "session.py", _config_session())

    # Controllers
    _write(dest / "app" / "Http" / "Controllers" / "HomeController.py", _home_controller())
    _write(dest / "app" / "Http" / "Controllers" / "DashboardController.py", _dashboard_controller())
    _write(dest / "app" / "Http" / "Controllers" / "Auth" / "LoginController.py", _login_controller())
    _write(dest / "app" / "Http" / "Controllers" / "Auth" / "RegisterController.py", _register_controller())
    _write(dest / "app" / "Http" / "Controllers" / "Auth" / "LogoutController.py", _logout_controller())

    # Models
    _write(dest / "app" / "Models" / "User.py", _user_model())

    # Database migrations
    _write(dest / "database" / "migrations" / "0001_create_users_table.py", _users_migration())

    # Providers
    _write(dest / "app" / "Providers" / "AppServiceProvider.py", _app_service_provider())
    _write(dest / "app" / "Providers" / "RouteServiceProvider.py", _route_service_provider())

    # Views
    _write(dest / "resources" / "views" / "layouts" / "app.html", _layout_app())
    _write(dest / "resources" / "views" / "welcome.html", _welcome_view())
    _write(dest / "resources" / "views" / "dashboard.html", _dashboard_view())
    _write(dest / "resources" / "views" / "auth" / "login.html", _login_view())
    _write(dest / "resources" / "views" / "auth" / "register.html", _register_view())

    # Frontend
    _write(dest / "resources" / "css" / "app.css", _app_css())
    _write(dest / "resources" / "js" / "app.js", _app_js())
    _write(dest / "vite.config.js", _vite_config())
    _write(dest / "tailwind.config.js", _tailwind_config())
    _write(dest / "package.json", _package_json(name))

    # Tests
    _write(dest / "tests" / "__init__.py", "")
    _write(dest / "tests" / "test_example.py", _test_example())

    # Public
    _write(dest / "public" / "index.php", "# Caprail serves via ASGI — this file is a placeholder.\n")

    # __init__ files
    for pkg in [
        "app", "app/Http", "app/Http/Controllers", "app/Http/Controllers/Auth",
        "app/Http/Middleware", "app/Http/Requests", "app/Models", "app/Providers",
        "bootstrap", "config", "routes",
    ]:
        p = dest / pkg / "__init__.py"
        if not p.exists():
            p.write_text("")


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


# ── Template strings ───────────────────────────────────────────────────

def _env_example(name: str) -> str:
    slug = name.upper().replace("-", "_")
    return f"""APP_NAME={name}
APP_ENV=local
APP_DEBUG=true
APP_KEY=
APP_URL=http://localhost:8000

DB_CONNECTION=sqlite
DB_DATABASE=database/database.sqlite
# DB_HOST=127.0.0.1
# DB_PORT=5432
# DB_DATABASE={slug.lower()}
# DB_USERNAME=root
# DB_PASSWORD=

SESSION_DRIVER=cookie
SESSION_LIFETIME=120

VITE_APP_NAME=${{APP_NAME}}
"""


def _gitignore() -> str:
    return """.env
__pycache__/
*.pyc
.venv/
venv/
dist/
build/
*.egg-info/
.pytest_cache/
.coverage
htmlcov/
node_modules/
public/build/
storage/logs/*.log
"""


def _pyproject(name: str) -> str:
    return f"""[project]
name = "{name}"
version = "0.1.0"
description = "A Caprail application"
requires-python = ">=3.14"
dependencies = [
    "caprail>=0.1.0",
]

[dependency-groups]
dev = [
    "pytest>=8.3",
    "pytest-asyncio>=0.25",
]

[tool.pytest.ini_options]
asyncio_mode = "auto"
"""


def _bootstrap_app() -> str:
    return '''"""
Bootstrap the Caprail application.
"""
from pathlib import Path

from caprail import Application
from app.Providers.AppServiceProvider import AppServiceProvider
from app.Providers.RouteServiceProvider import RouteServiceProvider

app = Application(base_path=Path(__file__).parent.parent)

app.register_providers([
    AppServiceProvider,
    RouteServiceProvider,
])

# The ASGI callable used by uvicorn / caprail serve
application = app.make_asgi()
'''


def _routes_web() -> str:
    return '''"""
Web routes.

These routes are loaded by the RouteServiceProvider.
"""
from caprail.routing.router import Router
from app.Http.Controllers.HomeController import HomeController
from app.Http.Controllers.DashboardController import DashboardController
from app.Http.Controllers.Auth.LoginController import LoginController
from app.Http.Controllers.Auth.RegisterController import RegisterController
from app.Http.Controllers.Auth.LogoutController import LogoutController


def register(router: Router) -> None:
    router.get("/", HomeController().index).name_as("home")
    router.get("/dashboard", DashboardController().index).name_as("dashboard")

    # Authentication routes
    router.get("/login", LoginController().show).name_as("login")
    router.post("/login", LoginController().store)
    router.get("/register", RegisterController().show).name_as("register")
    router.post("/register", RegisterController().store)
    router.post("/logout", LogoutController().store).name_as("logout")
'''


def _routes_api() -> str:
    return '''"""
API routes.

These routes are automatically prefixed with /api.
"""
from caprail.routing.router import Router


def register(router: Router) -> None:
    router.get("/status", lambda req: {"status": "ok", "caprail": "0.1.0"})
'''


def _config_app(name: str) -> str:
    return f'''"""Application configuration."""
import os

config = {{
    "name": os.environ.get("APP_NAME", "{name}"),
    "env": os.environ.get("APP_ENV", "production"),
    "debug": os.environ.get("APP_DEBUG", "false").lower() in ("true", "1"),
    "url": os.environ.get("APP_URL", "http://localhost:8000"),
    "timezone": "UTC",
    "locale": "en",
    "key": os.environ.get("APP_KEY", ""),
}}
'''


def _config_database() -> str:
    return '''"""Database configuration."""
import os

config = {
    "default": os.environ.get("DB_CONNECTION", "sqlite"),
    "connections": {
        "sqlite": {
            "driver": "sqlite",
            "database": os.environ.get("DB_DATABASE", "database/database.sqlite"),
        },
        "postgresql": {
            "driver": "postgresql+asyncpg",
            "host": os.environ.get("DB_HOST", "127.0.0.1"),
            "port": int(os.environ.get("DB_PORT", "5432")),
            "database": os.environ.get("DB_DATABASE", "caprail"),
            "username": os.environ.get("DB_USERNAME", "root"),
            "password": os.environ.get("DB_PASSWORD", ""),
        },
        "mysql": {
            "driver": "mysql+aiomysql",
            "host": os.environ.get("DB_HOST", "127.0.0.1"),
            "port": int(os.environ.get("DB_PORT", "3306")),
            "database": os.environ.get("DB_DATABASE", "caprail"),
            "username": os.environ.get("DB_USERNAME", "root"),
            "password": os.environ.get("DB_PASSWORD", ""),
        },
    },
}
'''


def _config_session() -> str:
    return '''"""Session configuration."""
import os

config = {
    "driver": os.environ.get("SESSION_DRIVER", "cookie"),
    "lifetime": int(os.environ.get("SESSION_LIFETIME", "120")),
    "encrypt": False,
    "path": "/",
    "domain": None,
    "secure": False,
    "http_only": True,
    "same_site": "Lax",
}
'''


def _home_controller() -> str:
    return '''"""Home controller."""
from __future__ import annotations

from caprail.http.request import Request
from caprail.http.response import Response
from caprail.view.engine import ViewEngine


class HomeController:

    async def index(self, request: Request) -> Response:
        return await ViewEngine.instance().render_response("welcome", {
            "title": "Welcome to Caprail",
        })
'''


def _app_service_provider() -> str:
    return '''"""App service provider."""
from __future__ import annotations

from caprail.foundation.service_provider import ServiceProvider
from caprail.view.engine import ViewEngine
from caprail.orm.model import configure_database
from caprail.auth.auth_manager import Auth


class AppServiceProvider(ServiceProvider):

    def register(self) -> None:
        # Configure the view engine
        views_path = self.app.resources_path("views")
        ViewEngine.configure(views_path)

    def boot(self) -> None:
        # Configure the database
        self._setup_database()
        # Configure authentication
        self._setup_auth()
        # Share global template variables
        self._setup_views()

    def _setup_database(self) -> None:
        import config.database as db_config
        cfg = db_config.config
        connection = cfg["default"]
        conn_cfg = cfg["connections"][connection]

        driver = conn_cfg["driver"]
        if driver == "sqlite":
            db_path = self.app.base_path / conn_cfg["database"]
            db_path.parent.mkdir(parents=True, exist_ok=True)
            url = f"sqlite+aiosqlite:///{db_path}"
        else:
            user = conn_cfg.get("username", "root")
            password = conn_cfg.get("password", "")
            host = conn_cfg.get("host", "localhost")
            port = conn_cfg.get("port", 5432)
            name = conn_cfg.get("database", "caprail")
            url = f"{driver}://{user}:{password}@{host}:{port}/{name}"

        configure_database(url, echo=self.app.is_debug())

    def _setup_auth(self) -> None:
        from app.Models.User import User
        Auth.configure(User)

    def _setup_views(self) -> None:
        import config.app as app_config
        ViewEngine.instance().share("app_name", app_config.config.get("name", "Caprail"))
'''


def _route_service_provider() -> str:
    return '''"""Route service provider."""
from __future__ import annotations

from caprail.foundation.service_provider import ServiceProvider


class RouteServiceProvider(ServiceProvider):

    def boot(self) -> None:
        router = self.app.router

        # Web routes
        try:
            from routes.web import register as web_register
            web_register(router)
        except ImportError:
            pass

        # API routes (prefixed with /api)
        try:
            from routes.api import register as api_register
            router.group({"prefix": "/api"}, lambda: api_register(router))
        except ImportError:
            pass
'''


def _layout_app() -> str:
    return """<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Home{% endblock %} — {{ app_name }}</title>
    <!-- Tailwind CSS — swap for compiled assets once you run: npm install && npm run build -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] }
                }
            }
        }
    </script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: Inter, system-ui, sans-serif; }
    </style>
</head>
<body class="h-full bg-gray-50 text-gray-900 antialiased" x-data>

    <!-- Navigation -->
    <nav class="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">

                <!-- Logo -->
                <div class="flex items-center gap-8">
                    <a href="/" class="flex items-center gap-2.5 group">
                        <div class="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-sm group-hover:bg-indigo-700 transition">
                            <span class="text-white font-bold text-sm">{{ app_name[0] | upper }}</span>
                        </div>
                        <span class="font-semibold text-gray-900">{{ app_name }}</span>
                    </a>
                </div>

                <!-- Right side -->
                <div class="flex items-center gap-2">
                    {% if auth_user %}
                    <!-- User dropdown -->
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open"
                                class="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-900 px-3 py-2 rounded-lg hover:bg-gray-100 transition">
                            <div class="w-7 h-7 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-semibold text-xs">
                                {{ auth_user.name[0] | upper }}
                            </div>
                            <span class="hidden sm:block">{{ auth_user.name }}</span>
                            <svg class="w-4 h-4 text-gray-400 transition-transform" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                            </svg>
                        </button>
                        <div x-show="open" x-cloak @click.outside="open = false"
                             x-transition:enter="transition ease-out duration-100"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-75"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute right-0 mt-1 w-48 bg-white rounded-xl border border-gray-100 shadow-lg py-1 z-50">
                            <a href="/dashboard" class="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition">
                                <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                                </svg>
                                Dashboard
                            </a>
                            <div class="border-t border-gray-100 my-1"></div>
                            <form method="POST" action="/logout">
                                {{ csrf_field() | safe }}
                                <button type="submit"
                                        class="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                                    </svg>
                                    Sign out
                                </button>
                            </form>
                        </div>
                    </div>
                    {% endif %}
                    {% if not auth_user %}
                    <a href="/login"
                       class="text-sm font-medium text-gray-600 hover:text-gray-900 px-3 py-2 rounded-lg hover:bg-gray-100 transition">
                        Sign in
                    </a>
                    <a href="/register"
                       class="text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-lg shadow-sm transition">
                        Get started
                    </a>
                    {% endif %}
                </div>

            </div>
        </div>
    </nav>

    <!-- Flash messages -->
    {% if flash_success %}
    <div class="bg-emerald-50 border-b border-emerald-200 px-4 py-3" role="alert">
        <div class="max-w-7xl mx-auto flex items-center gap-2 text-sm text-emerald-800">
            <svg class="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            {{ flash_success }}
        </div>
    </div>
    {% endif %}
    {% if flash_error %}
    <div class="bg-red-50 border-b border-red-200 px-4 py-3" role="alert">
        <div class="max-w-7xl mx-auto flex items-center gap-2 text-sm text-red-800">
            <svg class="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-1-9a1 1 0 012 0v4a1 1 0 01-2 0V9zm1-5a1 1 0 100 2 1 1 0 000-2z" clip-rule="evenodd"/>
            </svg>
            {{ flash_error }}
        </div>
    </div>
    {% endif %}
    {% if flash_info %}
    <div class="bg-blue-50 border-b border-blue-200 px-4 py-3" role="alert">
        <div class="max-w-7xl mx-auto flex items-center gap-2 text-sm text-blue-800">
            <svg class="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
            </svg>
            {{ flash_info }}
        </div>
    </div>
    {% endif %}

    <!-- Page content -->
    <main>
        {% block content %}{% endblock %}
    </main>

    <!-- Footer -->
    <footer class="border-t border-gray-100 mt-20 py-8">
        <div class="max-w-7xl mx-auto px-4 text-center text-sm text-gray-400">
            Powered by <a href="https://caprail.dev" class="text-indigo-500 hover:underline">Caprail</a>
        </div>
    </footer>

</body>
</html>
"""


def _welcome_view() -> str:
    return """{% extends "layouts/app.html" %}

{% block title %}Welcome{% endblock %}

{% block content %}

<!-- Hero -->
<div class="bg-white border-b border-gray-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <div class="inline-flex items-center gap-2 bg-indigo-50 text-indigo-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-6">
            <span class="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
            Now available — Caprail Framework
        </div>
        <h1 class="text-5xl sm:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Build web apps<br>
            <span class="text-indigo-600">the expressive way</span>
        </h1>
        <p class="text-xl text-gray-500 mb-10 max-w-2xl mx-auto leading-relaxed">
            A full-stack async Python web framework designed for developer happiness.
            Elegant syntax, powerful features, zero friction.
        </p>
        <div class="flex flex-col sm:flex-row items-center justify-center gap-3">
            {% if not auth_user %}
            <a href="/register"
               class="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-sm transition">
                Get started — it's free
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                </svg>
            </a>
            {% endif %}
            {% if auth_user %}
            <a href="/dashboard"
               class="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-sm transition">
                Go to Dashboard
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                </svg>
            </a>
            {% endif %}
            <a href="https://github.com/caprail/caprail"
               class="inline-flex items-center gap-2 px-6 py-3 bg-white hover:bg-gray-50 text-gray-700 font-semibold rounded-xl border border-gray-200 shadow-sm transition">
                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z"/>
                </svg>
                View on GitHub
            </a>
        </div>
    </div>
</div>

<!-- Features -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
    <div class="text-center mb-14">
        <h2 class="text-3xl font-bold text-gray-900 mb-4">Everything you need</h2>
        <p class="text-gray-500 max-w-xl mx-auto">
            Caprail ships with a complete set of tools so you can focus on building your application.
        </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        <div class="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition">
            <div class="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center mb-4">
                <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                </svg>
            </div>
            <h3 class="font-semibold text-gray-900 mb-2">Async by design</h3>
            <p class="text-sm text-gray-500 leading-relaxed">
                Built on ASGI with full async/await support throughout — fast, non-blocking, and scalable.
            </p>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition">
            <div class="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center mb-4">
                <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582 4 8 4m8-4c0-2.21-3.582 4-8 4"/>
                </svg>
            </div>
            <h3 class="font-semibold text-gray-900 mb-2">Active Record ORM</h3>
            <p class="text-sm text-gray-500 leading-relaxed">
                Expressive database models with a fluent query builder, relationships, and async migrations.
            </p>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition">
            <div class="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center mb-4">
                <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"/>
                </svg>
            </div>
            <h3 class="font-semibold text-gray-900 mb-2">Jinja2 templates</h3>
            <p class="text-sm text-gray-500 leading-relaxed">
                Full-power Jinja2 templating with layouts, blocks, includes, and all standard filters and tags.
            </p>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition">
            <div class="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center mb-4">
                <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                </svg>
            </div>
            <h3 class="font-semibold text-gray-900 mb-2">Built-in authentication</h3>
            <p class="text-sm text-gray-500 leading-relaxed">
                Complete email and password auth with secure PBKDF2 hashing, sessions, and middleware guards.
            </p>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition">
            <div class="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center mb-4">
                <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
            </div>
            <h3 class="font-semibold text-gray-900 mb-2">CLI generators</h3>
            <p class="text-sm text-gray-500 leading-relaxed">
                Scaffold controllers, models, migrations, middleware, and more with a single command.
            </p>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition">
            <div class="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center mb-4">
                <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                </svg>
            </div>
            <h3 class="font-semibold text-gray-900 mb-2">Middleware pipeline</h3>
            <p class="text-sm text-gray-500 leading-relaxed">
                Composable request/response middleware with CORS, session, auth, and custom middleware support.
            </p>
        </div>

    </div>
</div>

<!-- CTA -->
<div class="bg-indigo-600 mt-4 mb-20 mx-4 sm:mx-6 lg:mx-8 rounded-2xl max-w-7xl lg:mx-auto">
    <div class="px-8 py-12 text-center">
        <h2 class="text-2xl font-bold text-white mb-3">Ready to build something great?</h2>
        <p class="text-indigo-200 mb-6">Create your account and start building in minutes.</p>
        {% if not auth_user %}
        <a href="/register"
           class="inline-flex items-center gap-2 px-6 py-3 bg-white hover:bg-gray-50 text-indigo-600 font-semibold rounded-xl shadow-sm transition">
            Create your account
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
            </svg>
        </a>
        {% endif %}
        {% if auth_user %}
        <a href="/dashboard"
           class="inline-flex items-center gap-2 px-6 py-3 bg-white hover:bg-gray-50 text-indigo-600 font-semibold rounded-xl shadow-sm transition">
            Go to your dashboard
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
            </svg>
        </a>
        {% endif %}
    </div>
</div>

{% endblock %}
"""


def _dashboard_view() -> str:
    return """{% extends "layouts/app.html" %}

{% block title %}Dashboard{% endblock %}

{% block content %}
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

    <!-- Page header -->
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-900">
            Welcome back, {{ auth_user.name }}
        </h1>
        <p class="text-gray-500 mt-1">Here's what's going on with your application.</p>
    </div>

    <!-- Stats cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">

        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <p class="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Status</p>
            <div class="flex items-center gap-2 mt-1">
                <div class="w-2 h-2 bg-emerald-400 rounded-full"></div>
                <span class="text-sm font-semibold text-gray-900">Running</span>
            </div>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <p class="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Framework</p>
            <p class="text-sm font-semibold text-gray-900">Caprail</p>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <p class="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Database</p>
            <p class="text-sm font-semibold text-gray-900">SQLite</p>
        </div>

        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <p class="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Environment</p>
            <p class="text-sm font-semibold text-gray-900">Local</p>
        </div>

    </div>

    <!-- Quick start -->
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h2 class="font-semibold text-gray-900 mb-4">Quick start</h2>
        <div class="space-y-3">

            <div class="flex items-start gap-3">
                <div class="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span class="text-xs font-bold text-indigo-600">1</span>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-900">Create a controller</p>
                    <code class="text-xs text-gray-500 bg-gray-50 px-2 py-0.5 rounded">caprail make controller PostController</code>
                </div>
            </div>

            <div class="flex items-start gap-3">
                <div class="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span class="text-xs font-bold text-indigo-600">2</span>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-900">Create a model and migration</p>
                    <code class="text-xs text-gray-500 bg-gray-50 px-2 py-0.5 rounded">caprail make model Post --migration</code>
                </div>
            </div>

            <div class="flex items-start gap-3">
                <div class="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span class="text-xs font-bold text-indigo-600">3</span>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-900">Run your migrations</p>
                    <code class="text-xs text-gray-500 bg-gray-50 px-2 py-0.5 rounded">caprail migrate run</code>
                </div>
            </div>

        </div>
    </div>

</div>
{% endblock %}
"""


def _dashboard_controller() -> str:
    return '''"""Dashboard controller."""
from __future__ import annotations

from caprail.http.request import Request
from caprail.http.response import Response
from caprail.auth.auth_manager import Auth
from caprail.view.engine import ViewEngine


class DashboardController:

    async def index(self, request: Request) -> Response:
        """Show the dashboard (authenticated users only)."""
        if not Auth.check(request):
            return Response.redirect("/login")
        return await ViewEngine.instance().render_response("dashboard", {})
'''


def _login_view() -> str:
    return """{% extends "layouts/app.html" %}

{% block title %}Login{% endblock %}

{% block content %}
<div class="max-w-md mx-auto mt-12">
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
        <h2 class="text-2xl font-bold mb-6 text-center">Sign In</h2>

        {% if error %}
        <div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
            {{ error }}
        </div>
        {% endif %}

        <form method="POST" action="/login" class="space-y-4">
            {{ csrf_field() | safe }}

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email"
                       value="{{ old.email if old else '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       placeholder="you@example.com" required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input type="password" name="password"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       required>
            </div>

            <button type="submit"
                    class="w-full py-2 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition">
                Sign In
            </button>
        </form>

        <p class="mt-4 text-center text-sm text-gray-500">
            Don't have an account?
            <a href="/register" class="text-indigo-600 hover:underline">Register</a>
        </p>
    </div>
</div>
{% endblock %}
"""


def _register_view() -> str:
    return """{% extends "layouts/app.html" %}

{% block title %}Register{% endblock %}

{% block content %}
<div class="max-w-md mx-auto mt-12">
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
        <h2 class="text-2xl font-bold mb-6 text-center">Create Account</h2>

        {% if error %}
        <div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
            {{ error }}
        </div>
        {% endif %}

        <form method="POST" action="/register" class="space-y-4">
            {{ csrf_field() | safe }}

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input type="text" name="name"
                       value="{{ old.name if old else '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       placeholder="Your name" required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email"
                       value="{{ old.email if old else '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       placeholder="you@example.com" required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input type="password" name="password"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
                <input type="password" name="password_confirmation"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       required>
            </div>

            <button type="submit"
                    class="w-full py-2 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition">
                Create Account
            </button>
        </form>

        <p class="mt-4 text-center text-sm text-gray-500">
            Already have an account?
            <a href="/login" class="text-indigo-600 hover:underline">Sign in</a>
        </p>
    </div>
</div>
{% endblock %}
"""


def _user_model() -> str:
    return '''"""User model."""
from __future__ import annotations

from caprail.orm.model import Model
from caprail.auth.auth_manager import Auth


class User(Model):
    table = "users"
    fillable = ["name", "email", "password"]
    hidden = ["password"]

    @classmethod
    def create_password(cls, plain: str) -> str:
        return Auth.hash_password(plain)
'''


def _users_migration() -> str:
    return '''"""Create users table."""
from caprail.orm.migrations import Migration, Blueprint


class CreateUsersTable(Migration):

    async def up(self, schema) -> None:
        async with schema.create("users") as table:
            table.id()
            table.string("name")
            table.string("email").unique()
            table.string("password")
            table.string("remember_token", length=100).nullable()
            table.timestamps()

    async def down(self, schema) -> None:
        await schema.drop_if_exists("users")
'''


def _login_controller() -> str:
    return '''"""Login controller."""
from __future__ import annotations

from caprail.http.request import Request
from caprail.http.response import Response
from caprail.auth.auth_manager import Auth
from caprail.view.engine import ViewEngine


class LoginController:

    async def show(self, request: Request) -> Response:
        """Show the login form."""
        return await ViewEngine.instance().render_response("auth.login", {})

    async def store(self, request: Request) -> Response:
        """Handle login form submission."""
        form = await request.form()
        email = form.get("email", "")
        password = form.get("password", "")

        success = await Auth.attempt(request, email=email, password=password)
        if not success:
            return await ViewEngine.instance().render_response("auth.login", {
                "error": "These credentials do not match our records.",
                "old": {"email": email},
            })

        return Response.redirect("/dashboard")
'''


def _register_controller() -> str:
    return '''"""Register controller."""
from __future__ import annotations

from caprail.http.request import Request
from caprail.http.response import Response
from caprail.auth.auth_manager import Auth
from caprail.view.engine import ViewEngine
from app.Models.User import User


class RegisterController:

    async def show(self, request: Request) -> Response:
        """Show the registration form."""
        return await ViewEngine.instance().render_response("auth.register", {})

    async def store(self, request: Request) -> Response:
        """Handle registration form submission."""
        form = await request.form()
        name = form.get("name", "")
        email = form.get("email", "")
        password = form.get("password", "")
        password_confirmation = form.get("password_confirmation", "")

        if password != password_confirmation:
            return await ViewEngine.instance().render_response("auth.register", {
                "error": "Passwords do not match.",
                "old": {"name": name, "email": email},
            })

        if not name or not email or not password:
            return await ViewEngine.instance().render_response("auth.register", {
                "error": "All fields are required.",
                "old": {"name": name, "email": email},
            })

        user = await User.create(
            name=name,
            email=email,
            password=User.create_password(password),
        )

        await Auth.login(request, user)
        return Response.redirect("/dashboard")
'''


def _logout_controller() -> str:
    return '''"""Logout controller."""
from __future__ import annotations

from caprail.http.request import Request
from caprail.http.response import Response
from caprail.auth.auth_manager import Auth


class LogoutController:

    async def store(self, request: Request) -> Response:
        """Log the user out."""
        Auth.logout(request)
        return Response.redirect("/")
'''

def _app_css() -> str:
    return """@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
    html {
        font-family: 'Inter', system-ui, sans-serif;
    }
}

@layer components {
    .btn {
        @apply px-4 py-2 rounded-lg font-medium transition-colors duration-150;
    }
    .btn-primary {
        @apply btn bg-indigo-600 text-white hover:bg-indigo-700;
    }
    .btn-secondary {
        @apply btn bg-gray-100 text-gray-800 hover:bg-gray-200;
    }
}
"""


def _app_js() -> str:
    return """import './bootstrap';
import Alpine from 'alpinejs';

window.Alpine = Alpine;
Alpine.start();
"""


def _vite_config() -> str:
    return """import { defineConfig } from 'vite';
import { resolve } from 'path';

export default defineConfig({
    build: {
        outDir: 'public/build',
        rollupOptions: {
            input: {
                app: resolve(__dirname, 'resources/js/app.js'),
            },
        },
    },
    server: {
        cors: true,
        port: 5173,
    },
});
"""


def _tailwind_config() -> str:
    return """/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './resources/views/**/*.html',
        './resources/js/**/*.js',
    ],
    theme: {
        extend: {
            fontFamily: {
                sans: ['Inter', 'system-ui', 'sans-serif'],
            },
        },
    },
    plugins: [],
};
"""


def _package_json(name: str) -> str:
    return f"""{{
  "name": "{name}",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {{
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  }},
  "dependencies": {{
    "alpinejs": "^3.14.0"
  }},
  "devDependencies": {{
    "@tailwindcss/forms": "^0.5.9",
    "@tailwindcss/typography": "^0.5.15",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.49",
    "tailwindcss": "^3.4.17",
    "vite": "^6.0.5"
  }}
}}
"""


def _test_example() -> str:
    return '''"""Example test."""
import pytest


@pytest.mark.asyncio
async def test_example() -> None:
    assert 1 + 1 == 2
'''
