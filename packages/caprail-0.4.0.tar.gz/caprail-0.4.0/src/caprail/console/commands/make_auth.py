"""caprail make auth — scaffold the built-in email/password auth system."""
from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

console = Console()


def command() -> None:
    """Scaffold the built-in email/password authentication system."""
    base = Path.cwd()

    # Detect we're in a Caprail project
    if not (base / "bootstrap" / "app.py").exists():
        console.print("[red]Error:[/] Run this command from the root of a Caprail project.")
        raise typer.Exit(1)

    _write_if_missing(base / "app" / "Models" / "User.py", _user_model())
    _write_if_missing(base / "database" / "migrations" / "0001_create_users_table.py", _users_migration())
    _ensure_auth_controllers(base)
    _write_if_missing(base / "resources" / "views" / "auth" / "login.html", _login_view())
    _write_if_missing(base / "resources" / "views" / "auth" / "register.html", _register_view())

    console.print("\n[bold green]✓ Auth scaffolding created![/]\n")
    console.print("  Next steps:")
    console.print("    1. Add [cyan]Auth.configure(User)[/] to your [cyan]AppServiceProvider.boot()[/]")
    console.print("    2. Add auth routes to [cyan]routes/web.py[/] (or copy from the snippet below)")
    console.print("    3. Run [cyan]caprail migrate run[/] to create the users table\n")
    console.print("  Auth routes snippet:")
    console.print("[dim]" + _routes_snippet() + "[/]\n")


def _write_if_missing(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        console.print(f"  [yellow]skip[/]   {path.relative_to(Path.cwd())} (already exists)")
        return
    path.write_text(content, encoding="utf-8")
    console.print(f"  [green]create[/] {path.relative_to(Path.cwd())}")


def _ensure_auth_controllers(base: Path) -> None:
    ctrl_dir = base / "app" / "Http" / "Controllers" / "Auth"
    ctrl_dir.mkdir(parents=True, exist_ok=True)
    init = ctrl_dir / "__init__.py"
    if not init.exists():
        init.write_text("")
    _write_if_missing(ctrl_dir / "LoginController.py", _login_controller())
    _write_if_missing(ctrl_dir / "RegisterController.py", _register_controller())
    _write_if_missing(ctrl_dir / "LogoutController.py", _logout_controller())


# ── Templates ──────────────────────────────────────────────────────────

def _user_model() -> str:
    return '''"""User model."""
from __future__ import annotations

from caprail.orm.model import Model
from caprail.auth.auth_manager import Auth


class User(Model):
    table = "users"
    fillable = ["name", "email", "password"]
    hidden = ["password"]

    @classmethod
    def create_password(cls, plain: str) -> str:
        return Auth.hash_password(plain)
'''


def _users_migration() -> str:
    return '''"""Create users table."""
from caprail.orm.migrations import Migration, Blueprint


class CreateUsersTable(Migration):

    async def up(self, schema) -> None:
        async with schema.create("users") as table:
            table.id()
            table.string("name")
            table.string("email").unique()
            table.string("password")
            table.string("remember_token", length=100).nullable()
            table.timestamps()

    async def down(self, schema) -> None:
        await schema.drop_if_exists("users")
'''


def _login_controller() -> str:
    return '''"""Login controller."""
from __future__ import annotations

from caprail.http.request import Request
from caprail.http.response import Response
from caprail.auth.auth_manager import Auth
from caprail.view.engine import ViewEngine


class LoginController:

    async def show(self, request: Request) -> Response:
        """Show the login form."""
        return await ViewEngine.instance().render_response("auth.login", {})

    async def store(self, request: Request) -> Response:
        """Handle login form submission."""
        form = await request.form()
        email = form.get("email", "")
        password = form.get("password", "")

        success = await Auth.attempt(request, email=email, password=password)
        if not success:
            return await ViewEngine.instance().render_response("auth.login", {
                "error": "These credentials do not match our records.",
                "old": {"email": email},
            })

        return Response.redirect("/dashboard")
'''


def _register_controller() -> str:
    return '''"""Register controller."""
from __future__ import annotations

from caprail.http.request import Request
from caprail.http.response import Response
from caprail.auth.auth_manager import Auth
from caprail.view.engine import ViewEngine
from app.Models.User import User


class RegisterController:

    async def show(self, request: Request) -> Response:
        """Show the registration form."""
        return await ViewEngine.instance().render_response("auth.register", {})

    async def store(self, request: Request) -> Response:
        """Handle registration form submission."""
        form = await request.form()
        name = form.get("name", "")
        email = form.get("email", "")
        password = form.get("password", "")
        password_confirmation = form.get("password_confirmation", "")

        if password != password_confirmation:
            return await ViewEngine.instance().render_response("auth.register", {
                "error": "Passwords do not match.",
                "old": {"name": name, "email": email},
            })

        if not name or not email or not password:
            return await ViewEngine.instance().render_response("auth.register", {
                "error": "All fields are required.",
                "old": {"name": name, "email": email},
            })

        user = await User.create(
            name=name,
            email=email,
            password=User.create_password(password),
        )

        await Auth.login(request, user)
        return Response.redirect("/dashboard")
'''


def _logout_controller() -> str:
    return '''"""Logout controller."""
from __future__ import annotations

from caprail.http.request import Request
from caprail.http.response import Response
from caprail.auth.auth_manager import Auth


class LogoutController:

    async def store(self, request: Request) -> Response:
        """Log the user out."""
        Auth.logout(request)
        return Response.redirect("/")
'''


def _login_view() -> str:
    return """{% extends "layouts/app.html" %}

{% block title %}Login{% endblock %}

{% block content %}
<div class="max-w-md mx-auto mt-12">
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
        <h2 class="text-2xl font-bold mb-6 text-center">Sign In</h2>

        {% if error %}
        <div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
            {{ error }}
        </div>
        {% endif %}

        <form method="POST" action="/login" class="space-y-4">
            {{ csrf_field() | safe }}

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email"
                       value="{{ old.email if old else '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       placeholder="you@example.com" required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input type="password" name="password"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       required>
            </div>

            <button type="submit"
                    class="w-full py-2 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition">
                Sign In
            </button>
        </form>

        <p class="mt-4 text-center text-sm text-gray-500">
            Don't have an account?
            <a href="/register" class="text-indigo-600 hover:underline">Register</a>
        </p>
    </div>
</div>
{% endblock %}
"""


def _register_view() -> str:
    return """{% extends "layouts/app.html" %}

{% block title %}Register{% endblock %}

{% block content %}
<div class="max-w-md mx-auto mt-12">
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
        <h2 class="text-2xl font-bold mb-6 text-center">Create Account</h2>

        {% if error %}
        <div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
            {{ error }}
        </div>
        {% endif %}

        <form method="POST" action="/register" class="space-y-4">
            {{ csrf_field() | safe }}

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input type="text" name="name"
                       value="{{ old.name if old else '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       placeholder="Your name" required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email"
                       value="{{ old.email if old else '' }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       placeholder="you@example.com" required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input type="password" name="password"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       required>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
                <input type="password" name="password_confirmation"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       required>
            </div>

            <button type="submit"
                    class="w-full py-2 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition">
                Create Account
            </button>
        </form>

        <p class="mt-4 text-center text-sm text-gray-500">
            Already have an account?
            <a href="/login" class="text-indigo-600 hover:underline">Sign in</a>
        </p>
    </div>
</div>
{% endblock %}
"""


def _routes_snippet() -> str:
    return """
    from app.Http.Controllers.Auth.LoginController import LoginController
    from app.Http.Controllers.Auth.RegisterController import RegisterController
    from app.Http.Controllers.Auth.LogoutController import LogoutController

    # Auth routes (guest only)
    router.get("/login", LoginController().show).name_as("login")
    router.post("/login", LoginController().store)
    router.get("/register", RegisterController().show).name_as("register")
    router.post("/register", RegisterController().store)

    # Logout (authenticated)
    router.post("/logout", LogoutController().store).name_as("logout")
"""
