"""
Caprail Console Kernel — the ``caprail`` CLI entry point.
"""
from __future__ import annotations

import typer
from rich.console import Console

from caprail.console.commands import (
    make_controller,
    make_model,
    make_migration,
    make_middleware,
    make_provider,
    make_request,
    make_auth,
    migrate_cmd,
    migrate_rollback,
    migrate_fresh,
    migrate_status,
    serve_cmd,
    route_list,
    key_generate,
    new_project,
)

app = typer.Typer(
    name="caprail",
    help="[bold green]Caprail[/] — a full-stack async Python web framework.",
    rich_markup_mode="rich",
    no_args_is_help=True,
    add_completion=True,
)

console = Console()

# ── Project scaffold ───────────────────────────────────────────────────
app.command("new")(new_project.command)

# ── make: generators ──────────────────────────────────────────────────
make_app = typer.Typer(help="Generate framework files.", no_args_is_help=True)
app.add_typer(make_app, name="make")

make_app.command("controller")(make_controller.command)
make_app.command("model")(make_model.command)
make_app.command("migration")(make_migration.command)
make_app.command("middleware")(make_middleware.command)
make_app.command("provider")(make_provider.command)
make_app.command("request")(make_request.command)
make_app.command("auth")(make_auth.command)

# ── migrate ────────────────────────────────────────────────────────────
migrate_group = typer.Typer(help="Database migration commands.", no_args_is_help=True)
app.add_typer(migrate_group, name="migrate")

migrate_group.command("run")(migrate_cmd.command)
migrate_group.command("rollback")(migrate_rollback.command)
migrate_group.command("fresh")(migrate_fresh.command)
migrate_group.command("status")(migrate_status.command)

# Top-level ``caprail migrate`` (alias for run)
app.command("db:migrate")(migrate_cmd.command)

# ── Other commands ────────────────────────────────────────────────────
app.command("serve")(serve_cmd.command)
app.command("route:list")(route_list.command)
app.command("key:generate")(key_generate.command)


def main() -> None:
    app()
