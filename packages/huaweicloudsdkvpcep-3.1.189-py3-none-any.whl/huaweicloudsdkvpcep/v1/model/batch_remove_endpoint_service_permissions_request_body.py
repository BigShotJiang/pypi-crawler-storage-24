# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BatchRemoveEndpointServicePermissionsRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'permissions': 'list[EpsRemovePermissionRequest]'
    }

    attribute_map = {
        'permissions': 'permissions'
    }

    def __init__(self, permissions=None):
        r"""BatchRemoveEndpointServicePermissionsRequestBody

        The model defined in huaweicloud sdk

        :param permissions: 终端节点服务白名单
        :type permissions: list[:class:`huaweicloudsdkvpcep.v1.EpsRemovePermissionRequest`]
        """
        
        

        self._permissions = None
        self.discriminator = None

        self.permissions = permissions

    @property
    def permissions(self):
        r"""Gets the permissions of this BatchRemoveEndpointServicePermissionsRequestBody.

        终端节点服务白名单

        :return: The permissions of this BatchRemoveEndpointServicePermissionsRequestBody.
        :rtype: list[:class:`huaweicloudsdkvpcep.v1.EpsRemovePermissionRequest`]
        """
        return self._permissions

    @permissions.setter
    def permissions(self, permissions):
        r"""Sets the permissions of this BatchRemoveEndpointServicePermissionsRequestBody.

        终端节点服务白名单

        :param permissions: The permissions of this BatchRemoveEndpointServicePermissionsRequestBody.
        :type permissions: list[:class:`huaweicloudsdkvpcep.v1.EpsRemovePermissionRequest`]
        """
        self._permissions = permissions

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BatchRemoveEndpointServicePermissionsRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
