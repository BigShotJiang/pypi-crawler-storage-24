# System Architecture Analysis

## Overview

- **Project**: proxy
- **Language**: python
- **Files**: 224
- **Lines**: 59994
- **Functions**: 2174
- **Classes**: 222
- **Avg CC**: 4.6
- **Critical (CC≥10)**: 217

## Architecture

### docs/open-webui-tools/ (1 files, 90L, 9 functions)

- `proxym_tools.py` — 90L, 9 methods, CC↑1

### frontend/ (2 files, 135L, 13 functions)

- `dashboard-sse-service.js` — 129L, 13 methods, CC↑9
- `proxym-dashboard.jsx` — 6L, 0 methods, CC↑0

### htmlcov/ (1 files, 735L, 65 functions)

- `coverage_html_cb_dd2e7eb5.js` — 735L, 65 methods, CC↑21

### root/ (1 files, 21L, 0 functions)

- `project.sh` — 21L, 0 methods, CC↑0

### scripts/ (9 files, 1396L, 26 functions)

- `seed_sprint8.py` — 229L, 1 methods, CC↑10
- `fix_corrupted_db.py` — 68L, 1 methods, CC↑7
- `proxym-voice-chat.py` — 73L, 3 methods, CC↑5
- `check_dashboard.sh` — 126L, 8 methods, CC↑0
- `evaluate_llm_work.sh` — 169L, 2 methods, CC↑0
- _4 more files_

### services/vscode/ (1 files, 369L, 1 functions)

- `entrypoint.sh` — 369L, 1 methods, CC↑0

### src/proxym/ (5 files, 904L, 32 functions)

- `main.py` — 234L, 2 methods, CC↑12
- `ctl.py` — 337L, 20 methods, CC↑7
- `storage.py` — 153L, 7 methods, CC↑6
- `config.py` — 177L, 3 methods, CC↑3
- `__init__.py` — 3L, 0 methods, CC↑0

### src/proxym/accounts/ (1 files, 398L, 20 functions)

- `__init__.py` — 398L, 20 methods, CC↑15

### src/proxym/api/ (18 files, 2683L, 114 functions)

- `_diag_providers.py` — 60L, 1 methods, CC↑19
- `_diag_agent.py` — 230L, 5 methods, CC↑14
- `_diag_vscode.py` — 143L, 2 methods, CC↑14
- `_diag_roo.py` — 121L, 4 methods, CC↑13
- `completions.py` — 262L, 12 methods, CC↑13
- _13 more files_

### src/proxym/cache/ (1 files, 333L, 10 functions)

- `__init__.py` — 333L, 10 methods, CC↑9

### src/proxym/cli/ (16 files, 2183L, 106 functions)

- `smart_defaults.py` — 109L, 4 methods, CC↑13
- `tickets.py` — 351L, 15 methods, CC↑12
- `diagnostics.py` — 148L, 7 methods, CC↑11
- `observability.py` — 147L, 6 methods, CC↑10
- `_client.py` — 47L, 4 methods, CC↑9
- _11 more files_

### src/proxym/cli/_groups/ (13 files, 1494L, 77 functions)

- `do_ctl.py` — 228L, 10 methods, CC↑17
- `projects_ctl.py` — 286L, 11 methods, CC↑10
- `tickets_ctl.py` — 319L, 15 methods, CC↑10
- `tools_ctl.py` — 165L, 6 methods, CC↑10
- `_shared.py` — 84L, 7 methods, CC↑2
- _8 more files_

### src/proxym/cli/utils/ (1 files, 46L, 3 functions)

- `cmd_sessions_list.py` — 46L, 3 methods, CC↑3

### src/proxym/context/ (5 files, 607L, 23 functions)

- `detector.py` — 202L, 8 methods, CC↑9
- `session.py` — 247L, 12 methods, CC↑7
- `tool_selector.py` — 101L, 2 methods, CC↑5
- `_context.py` — 33L, 1 methods, CC↑3
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/dashboard/ (17 files, 3800L, 200 functions)

- `panel.jsx` — 118L, 7 methods, CC↑19
- `_tickets_api.py` — 690L, 25 methods, CC↑18
- `_environments_api.py` — 460L, 33 methods, CC↑13
- `_system.py` — 156L, 4 methods, CC↑13
- `users.py` — 929L, 58 methods, CC↑13
- _12 more files_

### src/proxym/dashboard/components/ (21 files, 10154L, 698 functions)

- `projects.jsx` — 1070L, 72 methods, CC↑129
- `tasks.jsx` — 1697L, 110 methods, CC↑129
- `tickets.jsx` — 1500L, 94 methods, CC↑94
- `tools.jsx` — 1586L, 112 methods, CC↑87
- `human.jsx` — 366L, 18 methods, CC↑65
- _16 more files_

### src/proxym/dashboard/components/diagnostics/ (5 files, 211L, 16 functions)

- `DiagConfig.jsx` — 59L, 4 methods, CC↑29
- `DiagExtensions.jsx` — 51L, 3 methods, CC↑20
- `DiagAgent.jsx` — 51L, 3 methods, CC↑11
- `DiagInfrastructure.jsx` — 28L, 2 methods, CC↑10
- `helpers.jsx` — 22L, 4 methods, CC↑4

### src/proxym/dashboard/components/human/ (7 files, 268L, 19 functions)

- `HumanTaskPanelRefactored.jsx` — 143L, 13 methods, CC↑15
- `HumanTaskBoard.jsx` — 34L, 1 methods, CC↑5
- `HumanTaskTable.jsx` — 17L, 1 methods, CC↑3
- `HumanTaskList.jsx` — 24L, 1 methods, CC↑2
- `HumanJobsList.jsx` — 9L, 1 methods, CC↑1
- _2 more files_

### src/proxym/dashboard/components/shared/ (5 files, 577L, 29 functions)

- `RecentJobsList.jsx` — 82L, 1 methods, CC↑37
- `EditableTicketTable.jsx` — 210L, 9 methods, CC↑29
- `TableExport.jsx` — 134L, 16 methods, CC↑16
- `ViewControls.jsx` — 103L, 3 methods, CC↑12
- `TicketConstants.jsx` — 48L, 0 methods, CC↑0

### src/proxym/dashboard/components/tasks/ (6 files, 228L, 21 functions)

- `TasksPanelRefactored.jsx` — 136L, 16 methods, CC↑39
- `TasksBoard.jsx` — 34L, 1 methods, CC↑5
- `TasksTable.jsx` — 17L, 1 methods, CC↑3
- `TasksList.jsx` — 24L, 1 methods, CC↑2
- `TasksRecentJobs.jsx` — 9L, 1 methods, CC↑1
- _1 more files_

### src/proxym/dashboard/components/tickets/ (5 files, 780L, 47 functions)

- `TicketsPanelRefactored.jsx` — 217L, 23 methods, CC↑31
- `BulkOperations.jsx` — 157L, 7 methods, CC↑20
- `TicketList.jsx` — 209L, 14 methods, CC↑12
- `TicketFilters.jsx` — 151L, 2 methods, CC↑7
- `TicketStats.jsx` — 46L, 1 methods, CC↑2

### src/proxym/dashboard/components/tools/ (17 files, 1223L, 76 functions)

- `ToolsJobQueue.jsx` — 164L, 8 methods, CC↑48
- `ToolHealthPanelRefactored.jsx` — 197L, 16 methods, CC↑40
- `DiagnosticActions.jsx` — 86L, 3 methods, CC↑17
- `TicketStatusBadges.jsx` — 75L, 11 methods, CC↑16
- `BulkAutoFix.jsx` — 62L, 1 methods, CC↑15
- _12 more files_

### src/proxym/dashboard/hooks/ (1 files, 446L, 70 functions)

- `useDashboardData.js` — 446L, 70 methods, CC↑28

### src/proxym/dashboard/tickets/ (4 files, 1059L, 64 functions)

- `_manager.py` — 478L, 34 methods, CC↑22
- `_models.py` — 249L, 4 methods, CC↑12
- `TicketManagerRefactored.py` — 296L, 26 methods, CC↑10
- `__init__.py` — 36L, 0 methods, CC↑0

### src/proxym/dashboard/tickets/utils/ (1 files, 25L, 1 functions)

- `delete_ticket.py` — 25L, 1 methods, CC↑2

### src/proxym/dashboard/tools/ (10 files, 1360L, 50 functions)

- `_dispatch.py` — 217L, 4 methods, CC↑21
- `_health.py` — 217L, 6 methods, CC↑21
- `HealthCheckerRefactored.py` — 257L, 15 methods, CC↑12
- `_autofix.py` — 243L, 5 methods, CC↑12
- `_queue.py` — 205L, 8 methods, CC↑12
- _5 more files_

### src/proxym/dashboard/tools/utils/ (3 files, 56L, 4 functions)

- `_aider_install_fix.py` — 31L, 1 methods, CC↑4
- `start_executor.py` — 24L, 3 methods, CC↑3
- `__init__.py` — 1L, 0 methods, CC↑0

### src/proxym/dashboard/utils/ (6 files, 88L, 18 functions)

- `formatters.js` — 34L, 12 methods, CC↑7
- `delete_ticket.py` — 18L, 2 methods, CC↑3
- `_delete_item.py` — 10L, 1 methods, CC↑2
- `_emit_event.py` — 12L, 1 methods, CC↑2
- `delete_milestone.py` — 13L, 2 methods, CC↑1
- _1 more files_

### src/proxym/domain/ (4 files, 690L, 21 functions)

- `events.py` — 348L, 11 methods, CC↑7
- `bus.py` — 154L, 6 methods, CC↑5
- `setup.py` — 162L, 4 methods, CC↑2
- `__init__.py` — 26L, 0 methods, CC↑0

### src/proxym/domain/commands/ (5 files, 206L, 0 functions)

- `__init__.py` — 39L, 0 methods, CC↑0
- `project_commands.py` — 69L, 0 methods, CC↑0
- `setup_commands.py` — 22L, 0 methods, CC↑0
- `task_commands.py` — 39L, 0 methods, CC↑0
- `user_commands.py` — 37L, 0 methods, CC↑0

### src/proxym/domain/handlers/ (5 files, 844L, 43 functions)

- `project_handler.py` — 362L, 12 methods, CC↑28
- `setup_handler.py` — 172L, 14 methods, CC↑7
- `task_handler.py` — 116L, 5 methods, CC↑5
- `user_handler.py` — 175L, 12 methods, CC↑5
- `__init__.py` — 19L, 0 methods, CC↑0

### src/proxym/domain/queries/ (4 files, 99L, 0 functions)

- `__init__.py` — 25L, 0 methods, CC↑0
- `project_queries.py` — 29L, 0 methods, CC↑0
- `setup_queries.py` — 14L, 0 methods, CC↑0
- `user_queries.py` — 31L, 0 methods, CC↑0

### src/proxym/mcp/ (11 files, 1334L, 47 functions)

- `_tools_vallm.py` — 318L, 10 methods, CC↑7
- `client.py` — 151L, 4 methods, CC↑6
- `router.py` — 95L, 4 methods, CC↑5
- `_tools_tickets.py` — 198L, 5 methods, CC↑4
- `_tools_vm.py` — 194L, 7 methods, CC↑4
- _6 more files_

### src/proxym/middleware/ (1 files, 70L, 4 functions)

- `__init__.py` — 70L, 4 methods, CC↑6

### src/proxym/observability/ (4 files, 953L, 37 functions)

- `repair_agent.py` — 341L, 9 methods, CC↑14
- `__init__.py` — 308L, 8 methods, CC↑9
- `watchdog.py` — 211L, 13 methods, CC↑7
- `health_events.py` — 93L, 7 methods, CC↑6

### src/proxym/projects/ (1 files, 303L, 14 functions)

- `__init__.py` — 303L, 14 methods, CC↑21

### src/proxym/providers/ (1 files, 466L, 9 functions)

- `__init__.py` — 466L, 9 methods, CC↑25

### src/proxym/router/ (2 files, 684L, 32 functions)

- `__init__.py` — 352L, 13 methods, CC↑9
- `strategy.py` — 332L, 19 methods, CC↑9

### src/proxym/tools/ (3 files, 1305L, 44 functions)

- `executor.py` — 438L, 18 methods, CC↑25
- `startup.py` — 221L, 7 methods, CC↑18
- `__init__.py` — 646L, 19 methods, CC↑10

### src/proxym/tools/adapters/ (14 files, 1106L, 27 functions)

- `_llm_fallback.py` — 388L, 5 methods, CC↑18
- `_base.py` — 170L, 5 methods, CC↑8
- `_shell.py` — 102L, 2 methods, CC↑8
- `_vscode.py` — 113L, 3 methods, CC↑7
- `_aider.py` — 48L, 1 methods, CC↑5
- _9 more files_

### src/proxym/utils/ (3 files, 24L, 2 functions)

- `messages.py` — 11L, 1 methods, CC↑4
- `get_settings.py` — 12L, 1 methods, CC↑2
- `__init__.py` — 1L, 0 methods, CC↑0

### src/proxym/virt/ (13 files, 1590L, 70 functions)

- `_config.py` — 94L, 1 methods, CC↑9
- `_vm_config.py` — 220L, 7 methods, CC↑9
- `browser_profiles.py` — 314L, 12 methods, CC↑9
- `_lifecycle.py` — 236L, 12 methods, CC↑7
- `_state.py` — 94L, 5 methods, CC↑7
- _8 more files_

### src/proxym/virt/profiles/ (1 files, 69L, 4 functions)

- `__init__.py` — 69L, 4 methods, CC↑5

### src/proxym/virt/utils/ (1 files, 27L, 3 functions)

- `detect_chrome_profiles.py` — 27L, 3 methods, CC↑1

### src/proxym/watch/ (2 files, 150L, 5 functions)

- `__init__.py` — 146L, 5 methods, CC↑5
- `client.py` — 4L, 0 methods, CC↑0

## Key Exports

- **MultiSelectSection** (function, CC=15) ⚠ split
- **TicketTable** (function, CC=26) ⚠ split
- **hours** (function, CC=19) ⚠ split
- **ProjectCard** (function, CC=28) ⚠ split
- **ProjectFormUnified** (function, CC=129) ⚠ split
- **environmentOptionsSource** (function, CC=17) ⚠ split
- **toolOptionsSource** (function, CC=17) ⚠ split
- **modelOptionsSource** (function, CC=17) ⚠ split
- **userOptionsSource** (function, CC=17) ⚠ split
- **toolOptions** (function, CC=17) ⚠ split
- **modelOptions** (function, CC=23) ⚠ split
- **ProjectsPanel** (function, CC=26) ⚠ split
- **TableExport** (function, CC=16) ⚠ split
- **useTasksData** (function, CC=16) ⚠ split
- **TaskCardMeta** (function, CC=37) ⚠ split
- **TaskJobBadge** (function, CC=25) ⚠ split
- **TicketDispatchButton** (function, CC=24) ⚠ split
- **TaskBulkEditBar** (function, CC=30) ⚠ split
- **TaskTicketCard** (function, CC=18) ⚠ split
- **QuickTaskCreator** (function, CC=31) ⚠ split
- **TasksPanel** (function, CC=129) ⚠ split
- **view** (function, CC=18) ⚠ split
- **setView** (function, CC=18) ⚠ split
- **filterStatus** (function, CC=18) ⚠ split
- **setFilterStatus** (function, CC=18) ⚠ split
- **filterAgent** (function, CC=18) ⚠ split
- **setFilterAgent** (function, CC=18) ⚠ split
- **searchQuery** (function, CC=18) ⚠ split
- **setSearchQuery** (function, CC=18) ⚠ split
- **filtered** (function, CC=18) ⚠ split
- **result** (function, CC=15) ⚠ split
- **TicketCard** (function, CC=42) ⚠ split
- **SprintCard** (function, CC=19) ⚠ split
- **TicketExportMenu** (function, CC=15) ⚠ split
- **TicketHistoryItem** (function, CC=42) ⚠ split
- **result** (function, CC=15) ⚠ split
- **TicketDetailPanel** (function, CC=94) ⚠ split
- **TicketsPanel** (function, CC=91) ⚠ split
- **filtered** (function, CC=35) ⚠ split
- **TableExport** (function, CC=16) ⚠ split
- **ToolCard** (function, CC=26) ⚠ split
- **JobRow** (function, CC=35) ⚠ split
- **JobDetailsPanel** (function, CC=77) ⚠ split
- **TicketDispatchTable** (function, CC=87) ⚠ split
- **renderCurrentTool** (function, CC=20) ⚠ split
- **HealthTrends** (function, CC=15) ⚠ split
- **ToolHealthPanel** (function, CC=76) ⚠ split
- **ToolsPanel** (function, CC=57) ⚠ split
- **useHumanTasks** (function, CC=18) ⚠ split
- **HumanTaskPanel** (function, CC=65) ⚠ split
- **EnvironmentsPanel** (function, CC=59) ⚠ split
- **ToolsJobQueue** (function, CC=48) ⚠ split
- **DiagnosticsPanel** (function, CC=40) ⚠ split
- **ToolHealthPanelRefactored** (function, CC=40) ⚠ split
- **TasksPanelRefactored** (function, CC=39) ⚠ split
- **view** (function, CC=23) ⚠ split
- **setView** (function, CC=23) ⚠ split
- **filterStatus** (function, CC=23) ⚠ split
- **setFilterStatus** (function, CC=23) ⚠ split
- **filterAgent** (function, CC=23) ⚠ split
- **setFilterAgent** (function, CC=23) ⚠ split
- **searchQuery** (function, CC=23) ⚠ split
- **setSearchQuery** (function, CC=23) ⚠ split
- **filtered** (function, CC=23) ⚠ split
- **result** (function, CC=16) ⚠ split
- **RecentJobsList** (function, CC=37) ⚠ split
- **SetupPanel** (function, CC=36) ⚠ split
- **VMsPanel** (function, CC=36) ⚠ split
- **LogPanel** (function, CC=34) ⚠ split
- **useTicketFilters** (function, CC=31) ⚠ split
- **DiagRooConfig** (function, CC=29) ⚠ split
- **EditableTicketTable** (function, CC=29) ⚠ split
- **useDashboardData** (function, CC=28) ⚠ split
- **enrich_project** (function, CC=28) ⚠ split
- **filter_models** (function, CC=25) ⚠ split
- **ToolExecutor** (class, CC̄=5.7)
  - `_sync_ticket_execution` CC=25 ⚠ split
- **UsersPanel** (function, CC=24) ⚠ split
- **VoiceChat** (function, CC=24) ⚠ split
- **TicketManager** (class, CC̄=5.0)
  - `_apply_filters` CC=22 ⚠ split
  - `update_ticket` CC=18 ⚠ split
  - `ticket_context` CC=15 ⚠ split
  - `_load` CC=18 ⚠ split
- **table** (function, CC=21) ⚠ split
- **table_body_rows** (function, CC=21) ⚠ split
- **no_rows** (function, CC=21) ⚠ split
- **footer** (function, CC=21) ⚠ split
- **ratio_columns** (function, CC=21) ⚠ split
- **filter_handler** (function, CC=21) ⚠ split
- **dispatch_dry_run** (function, CC=21) ⚠ split
- **ProjectRegistry** (class, CC̄=5.5)
  - `_enrich_local` CC=21 ⚠ split
- **DiagExtensions** (function, CC=20) ⚠ split
- **BulkOperations** (function, CC=20) ⚠ split
- **check_providers_config** (function, CC=19) ⚠ split
- **useState** (function, CC=19) ⚠ split
- **useEffect** (function, CC=19) ⚠ split
- **useCallback** (function, CC=19) ⚠ split
- **Dashboard** (function, CC=19) ⚠ split
- **create_ticket** (function, CC=18) ⚠ split
- **ToolStartupOrchestrator** (class, CC̄=5.0)
  - `_probe_tool` CC=18 ⚠ split
- **do_cmd** (function, CC=17) ⚠ split
- **DiagnosticActions** (function, CC=17) ⚠ split
- **TableExport** (function, CC=16) ⚠ split
- **TicketStatusBadges** (function, CC=16) ⚠ split
- **AccountCredentials** (class, CC̄=5.0)
- **AccountManager** (class, CC̄=4.4)
  - `_load` CC=15 ⚠ split
- **HumanTaskPanelRefactored** (function, CC=15) ⚠ split
- **BulkAutoFix** (function, CC=15) ⚠ split
- **RepairAgent** (class, CC̄=5.4)
- **Milestone** (class, CC̄=12.0)
- **Ticket** (class, CC̄=7.5)
- **Sprint** (class, CC̄=7.0)
- **InstanceHealthCheck** (class, CC̄=6.7)
- **HealthStatusCalculator** (class, CC̄=12.0)
- **TicketValidator** (class, CC̄=8.5)
- **ToolInstance** (class, CC̄=5.0)
- **ProjectsConfig** (class, CC̄=9.0)
- **ShellAdapter** (class, CC̄=6.0)
- **_StateMixin** (class, CC̄=5.0)
- **_SnapshotMixin** (class, CC̄=5.0)
- **AiderAdapter** (class, CC̄=5.0)

## Hotspots (High Fan-Out)

- **TicketsPanel** — fan-out=56: Orchestrates 56 calls
- **useDashboardData** — fan-out=50: Orchestrates 50 calls
- **TasksPanel** — fan-out=46: Orchestrates 46 calls
- **EnvironmentsPanel** — fan-out=42: Orchestrates 42 calls
- **SetupPanel** — fan-out=36: Orchestrates 36 calls
- **create_ticket** — fan-out=31: Create a new ticket. Accepts 'task' (new) or 'title' (legacy).
- **VoiceChat** — fan-out=31: Orchestrates 31 calls

## Refactoring Priorities

| # | Action | Impact | Effort |
|---|--------|--------|--------|
| 1 | Split ToolExecutor._sync_ticket_execution (CC=25 → target CC<10) | high | low |
| 2 | Split filter_models (CC=25 → target CC<10) | high | low |
| 3 | Split enrich_project (CC=28 → target CC<10) | high | low |
| 4 | Split useDashboardData (CC=28 → target CC<10) | high | low |
| 5 | Split DiagnosticsPanel (CC=40 → target CC<10) | high | low |
| 6 | Split LogPanel (CC=34 → target CC<10) | high | low |
| 7 | Split VMsPanel (CC=36 → target CC<10) | high | low |
| 8 | Split HumanTaskPanel (CC=65 → target CC<10) | high | low |
| 9 | Split _resolveJobEnvironment (CC=25 → target CC<10) | high | low |
| 10 | Split TaskCardMeta (CC=37 → target CC<10) | high | low |

## Context for LLM

When suggesting changes:
1. Start from hotspots and high-CC functions
2. Follow refactoring priorities above
3. Maintain public API surface — keep backward compatibility
4. Prefer minimal, incremental changes

