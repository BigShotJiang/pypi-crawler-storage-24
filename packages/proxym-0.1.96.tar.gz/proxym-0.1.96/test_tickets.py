from proxym.storage import DEFAULT_SQLITE_PATH
from proxym.projects import ProjectRegistry
from proxym.domain.queries.project_queries import GetProjectTicketsQuery
from proxym.domain.handlers.project_handler import ProjectQueryHandler
import asyncio

async def test():
    reg = ProjectRegistry(persist_path=DEFAULT_SQLITE_PATH)
    handler = ProjectQueryHandler(reg)
    query = GetProjectTicketsQuery(project_id="reduplikacja")
    tickets = await handler.handle(query)
    print(f"Tickets for reduplikacja: {len(tickets)}")
    for t in tickets:
        print(f"  {t['id']}: {t.get('title','')}")

asyncio.run(test())
