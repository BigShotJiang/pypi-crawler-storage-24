"""Pydantic request models for the dashboard tickets API."""

from __future__ import annotations

from pydantic import BaseModel


class CreateTicketReq(BaseModel):
    task: str = ""  # "co zrobić" — nowe główne pole
    title: str = ""  # backward compat
    project_id: str | None = None  # powiązanie z projektem
    description: str = ""
    status: str = "todo"
    priority: str = "medium"
    type: str = "task"
    sprint_id: str = ""
    milestone_id: str = ""
    tags: list[str] = []
    files: list[str] = []
    context_files: list[str] = []
    depends_on: list[str] = []
    estimated_hours: float = 0
    tool: str | None = None  # od razu przypisz narzędzie


class UpdateTicketReq(BaseModel):
    task: str | None = None
    title: str | None = None
    project_id: str | None = None
    description: str | None = None
    status: str | None = None
    priority: str | None = None
    type: str | None = None
    sprint_id: str | None = None
    milestone_id: str | None = None
    tags: list[str] | None = None
    files: list[str] | None = None
    context_files: list[str] | None = None
    depends_on: list[str] | None = None
    estimated_hours: float | None = None
    actual_hours: float | None = None


class AssignToolReq(BaseModel):
    tool: str  # vscode, aider, claude-code, windsurf, cursor
    agent_mode: str = ""
    model: str = ""


class AddCommentReq(BaseModel):
    author: str = ""
    content: str


class CreateSprintReq(BaseModel):
    name: str
    goal: str = ""
    milestone_id: str = ""
    start_date: str = ""
    end_date: str = ""


class UpdateSprintReq(BaseModel):
    name: str | None = None
    goal: str | None = None
    milestone_id: str | None = None
    status: str | None = None
    start_date: str | None = None
    end_date: str | None = None


class CreateMilestoneReq(BaseModel):
    name: str
    goal: str = ""
    start_date: str = ""
    end_date: str = ""


class UpdateMilestoneReq(BaseModel):
    name: str | None = None
    goal: str | None = None
    status: str | None = None
    start_date: str | None = None
    end_date: str | None = None


__all__ = [
    "AddCommentReq",
    "AssignToolReq",
    "CreateMilestoneReq",
    "CreateSprintReq",
    "CreateTicketReq",
    "UpdateMilestoneReq",
    "UpdateSprintReq",
    "UpdateTicketReq",
]
