"""Shared helpers for the dashboard tickets API."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import structlog

from proxym.dashboard.tools._helpers import _job_snapshot
from proxym.dashboard.tickets import JobExecution, Ticket, TicketManager, TicketStatus
from proxym.tools.executor import JobStatus, ToolExecutor

logger = structlog.get_logger()


def _prepare_environment_snapshot(
    tool_def: Any,
    instance: str,
    get_tool_environment_snapshot: Callable[[str], dict[str, object] | None],
) -> dict[str, object]:
    environment_snapshot = dict(get_tool_environment_snapshot(tool_def.name) or {})
    if instance:
        environment_snapshot["tool_instance_name"] = instance
        tool_instance = tool_def.get_instance(instance)
        if tool_instance:
            environment_snapshot["tool_instance"] = tool_instance.summary()
    return environment_snapshot


def _resolve_project_dir(
    ticket: Ticket,
    environment_snapshot: dict[str, object] | None,
    project_dir: str,
    default_project_dir: Callable[[str | None], str],
) -> str:
    return (
        project_dir
        or (environment_snapshot.get("path") if environment_snapshot else "")
        or default_project_dir(ticket.project_id)
    )


def build_job_execution(job: Any, environment_snapshot: dict[str, object] | None) -> JobExecution:
    env = environment_snapshot or {}
    raw_tool_instance = env.get("tool_instance")
    tool_instance = raw_tool_instance if isinstance(raw_tool_instance, dict) else {}
    return JobExecution(
        job_id=job.id,
        tool=job.tool_name,
        mode=job.mode,
        model=job.model,
        project_dir=job.project_dir,
        environment_id=str(env.get("id", "")),
        environment_name=str(env.get("name", "")),
        environment_kind=str(env.get("kind", "")),
        environment_target=str(env.get("target", "")),
        environment_tool_instance_name=str(env.get("tool_instance_name", "")),
        environment_tool_instance=tool_instance,
        prompt_excerpt=job.prompt[:400].strip(),
        prompt_length=len(job.prompt),
        status=job.status.value,
        success=None,
        exit_code=None,
    )


def build_ticket_detail(ticket_store: TicketManager, ticket: Ticket, tool_executor_get: Callable[[], ToolExecutor]) -> dict[str, Any]:
    result = ticket_store.ticket_detail(ticket)
    result["job_history"] = [
        _job_snapshot(job) for job in tool_executor_get().get_jobs_for_ticket(ticket.id)
    ]
    return result


def build_ticket_export_rows(
    ticket_store: TicketManager,
    tickets: list[Ticket],
    *,
    detail: bool,
    view: str,
    tool_executor_get: Callable[[], ToolExecutor],
) -> list[dict[str, Any]]:
    rows = []
    for ticket in tickets:
        row = ticket_store.ticket_detail(ticket) if detail else ticket_store.ticket_overview(ticket)
        if detail:
            row["job_history"] = [
                _job_snapshot(job) for job in tool_executor_get().get_jobs_for_ticket(ticket.id)
            ]
        if view == "board":
            row["board_column"] = row.get("status", "")
        rows.append(row)
    return rows


def _ticket_has_active_job(ticket_id: str, tool_executor_get: Callable[[], ToolExecutor]) -> bool:
    active_statuses = {JobStatus.QUEUED, JobStatus.RUNNING}
    return any(
        job.status in active_statuses for job in tool_executor_get().get_jobs_for_ticket(ticket_id)
    )


async def enqueue_ticket_job(
    ticket: Ticket,
    tool_def: Any,
    *,
    mode: str = "",
    model: str = "",
    instance: str = "",
    project_dir: str = "",
    ticket_store: TicketManager,
    tool_executor_get: Callable[[], ToolExecutor],
    get_tool_environment_snapshot: Callable[[str], dict[str, object] | None],
    default_project_dir: Callable[[str | None], str],
) -> tuple[Any, JobExecution]:
    environment_snapshot = _prepare_environment_snapshot(
        tool_def,
        instance,
        get_tool_environment_snapshot,
    )
    resolved_project_dir = _resolve_project_dir(
        ticket,
        environment_snapshot,
        project_dir,
        default_project_dir,
    )

    executor = tool_executor_get()
    await executor.start()
    job = executor.enqueue(
        ticket,
        tool_def,
        resolved_project_dir,
        mode,
        model,
        environment=environment_snapshot,
    )
    execution = build_job_execution(job, environment_snapshot)
    ticket_store.update_ticket(ticket.id, {"last_execution": execution})
    return job, execution


async def maybe_auto_dispatch_ticket(
    ticket_id: str,
    *,
    ticket_store: TicketManager,
    tool_registry_get: Callable[[], Any],
    tool_executor_get: Callable[[], ToolExecutor],
    get_tool_environment_snapshot: Callable[[str], dict[str, object] | None],
    default_project_dir: Callable[[str | None], str],
) -> bool:
    ticket = ticket_store.get_ticket(ticket_id)
    if not ticket or ticket.status != TicketStatus.IN_PROGRESS:
        return False

    assignment = ticket.assigned_tool
    if not assignment or assignment.tool == "human":
        return False

    if _ticket_has_active_job(ticket_id, tool_executor_get):
        return False

    tool_def = tool_registry_get().get_tool(assignment.tool)
    if not tool_def:
        return False

    try:
        await enqueue_ticket_job(
            ticket,
            tool_def,
            mode=assignment.agent_mode or "",
            model=assignment.model or "",
            instance=assignment.instance or "",
            ticket_store=ticket_store,
            tool_executor_get=tool_executor_get,
            get_tool_environment_snapshot=get_tool_environment_snapshot,
            default_project_dir=default_project_dir,
        )
        return True
    except Exception as exc:
        logger.warning("auto_dispatch_failed", ticket=ticket.id, error=str(exc))
        return False
