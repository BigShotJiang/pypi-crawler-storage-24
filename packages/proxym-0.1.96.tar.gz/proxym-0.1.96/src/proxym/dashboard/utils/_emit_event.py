"""Shared domain event emission helper for dashboard API modules."""
from __future__ import annotations


def emit_event(event) -> None:
    """Emit a domain event to the global EventStore (best-effort)."""
    try:
        from proxym.domain.setup import get_event_store

        get_event_store().append(event)
    except Exception:
        pass
