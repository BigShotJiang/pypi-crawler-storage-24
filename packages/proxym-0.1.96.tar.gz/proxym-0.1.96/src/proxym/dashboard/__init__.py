"""Dashboard API: web panel + CLI endpoints for managing accounts, VMs, and costs.

Mounted at /dashboard/ on the main proxy app.
"""
from __future__ import annotations

from fastapi import APIRouter

from proxym.dashboard._accounts import router as accounts_router
from proxym.dashboard._accounts import list_accounts
from proxym.dashboard._environments_api import router as environments_router
from proxym.dashboard._costs import router as costs_router
from proxym.dashboard._costs import cost_summary
from proxym.dashboard._system import router as system_router
from proxym.dashboard._system import get_logs
from proxym.dashboard._projects_api import router as projects_router
from proxym.dashboard._tickets_api import router as tickets_router
from proxym.dashboard.tools import router as tools_router
from proxym.dashboard._users_api import router as users_router
from proxym.dashboard._vms import router as vms_router
from proxym.dashboard._vms import list_vms, start_vm, stop_vm, snapshot_vm
from proxym.dashboard._events_sse import router as events_router
from proxym.dashboard._setup_api import router as setup_router

# Main dashboard router
router = APIRouter(prefix="/dashboard", tags=["dashboard"])

# Include all sub-routers
router.include_router(accounts_router)
router.include_router(environments_router)
router.include_router(vms_router)
router.include_router(costs_router)
router.include_router(projects_router)
router.include_router(tickets_router)
router.include_router(tools_router)
router.include_router(users_router)
router.include_router(system_router)
router.include_router(events_router)
router.include_router(setup_router)
