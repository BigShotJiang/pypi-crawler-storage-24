// TasksRecentJobs - Thin wrapper around shared RecentJobsList
import React from 'react';
import RecentJobsList from '../shared/RecentJobsList';

function TasksRecentJobs({ jobs }) {
  return <RecentJobsList jobs={jobs} title="Recent Jobs" exportFilename="recent_jobs" />;
}

export default TasksRecentJobs;
