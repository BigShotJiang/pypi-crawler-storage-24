// TasksTable - Thin wrapper around shared EditableTicketTable
import React from 'react';

function TasksTable({ filteredTasks, tools, projects, onRefresh }) {
  return (
    <EditableTicketTable
      tickets={filteredTasks}
      tools={tools || []}
      projects={projects || []}
      onRefresh={onRefresh}
      title={`Tasks Table (${filteredTasks.length})`}
      emptyMessage="No tasks found"
    />
  );
}

export default TasksTable;
