// TasksViewControls - Thin wrapper around shared ViewControls
import React from 'react';

function TasksViewControls(props) {
  return <ViewControls {...props} itemLabel="task" />;
}

export default TasksViewControls;
