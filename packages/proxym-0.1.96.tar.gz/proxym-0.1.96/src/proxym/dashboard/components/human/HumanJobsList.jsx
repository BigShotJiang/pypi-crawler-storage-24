// HumanJobsList - Thin wrapper around shared RecentJobsList
import React from 'react';
import RecentJobsList from '../shared/RecentJobsList';

function HumanJobsList({ humanJobs }) {
  return <RecentJobsList jobs={humanJobs} title="Recent Human Jobs" exportFilename="human_jobs" />;
}

export default HumanJobsList;
