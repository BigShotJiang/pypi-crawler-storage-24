// HumanViewControls - Thin wrapper around shared ViewControls
import React from 'react';

function HumanViewControls(props) {
  return <ViewControls {...props} itemLabel="task" />;
}

export default HumanViewControls;
