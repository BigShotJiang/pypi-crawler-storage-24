// HumanTaskTable - Thin wrapper around shared EditableTicketTable
import React from 'react';

function HumanTaskTable({ filteredTasks, tools, projects, onRefresh }) {
  return (
    <EditableTicketTable
      tickets={filteredTasks}
      tools={tools || []}
      projects={projects || []}
      onRefresh={onRefresh}
      title={`Human Tasks Table (${filteredTasks.length})`}
      emptyMessage="No human tasks found"
    />
  );
}

export default HumanTaskTable;
