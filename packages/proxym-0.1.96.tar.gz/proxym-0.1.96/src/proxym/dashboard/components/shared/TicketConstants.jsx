// TicketConstants — shared constants for ticket/task UI across all panels.
// Loaded as a global script; do NOT use import/export.
// Uses "if not defined" guard so legacy files (tasks.jsx, human.jsx) that
// also declare the same names via `const` will just shadow these.

if (typeof TICKET_STATUSES === "undefined") {
  var TICKET_STATUSES = ["backlog", "todo", "in_progress", "in_review", "done", "cancelled"];
}
if (typeof TICKET_PRIORITIES === "undefined") {
  var TICKET_PRIORITIES = ["critical", "high", "medium", "low"];
}
if (typeof TICKET_TYPES === "undefined") {
  var TICKET_TYPES = ["task", "bug", "feature", "refactor", "test", "docs"];
}
if (typeof STATUS_COLORS === "undefined") {
  var STATUS_COLORS = {
    backlog: "bg-gray-100 text-gray-600",
    todo: "bg-blue-100 text-blue-700",
    in_progress: "bg-amber-100 text-amber-700",
    in_review: "bg-purple-100 text-purple-700",
    done: "bg-emerald-100 text-emerald-700",
    cancelled: "bg-red-100 text-red-600",
  };
}
if (typeof PRIORITY_COLORS === "undefined") {
  var PRIORITY_COLORS = {
    critical: "bg-red-200 text-red-800",
    high: "bg-orange-100 text-orange-700",
    medium: "bg-yellow-100 text-yellow-700",
    low: "bg-gray-100 text-gray-600",
  };
}
if (typeof TYPE_ICONS === "undefined") {
  var TYPE_ICONS = {
    task: "📋", bug: "🐛", feature: "✨", refactor: "🔧", test: "🧪", docs: "📄",
    improvement: "⚡", documentation: "📚", research: "🔍", review: "👀",
    testing: "🧪", deployment: "🚀", maintenance: "🔧",
  };
}
if (typeof JOB_STATUS_COLORS === "undefined") {
  var JOB_STATUS_COLORS = {
    queued: "bg-gray-100 text-gray-600",
    running: "bg-amber-100 text-amber-700",
    done: "bg-emerald-100 text-emerald-700",
    failed: "bg-red-100 text-red-600",
    cancelled: "bg-gray-200 text-gray-500",
  };
}
