"""User queries — read-only request objects for user data."""

from __future__ import annotations

from dataclasses import dataclass

from proxym.domain.bus import Query


@dataclass
class ListUsersQuery(Query):
    """List all users, optionally filtered."""
    active_only: bool = False


@dataclass
class GetUserQuery(Query):
    """Get a single user by ID."""
    user_id: str = ""


@dataclass
class GetDefaultUserQuery(Query):
    """Get the default/delegated user."""
    pass


@dataclass
class GetGitSyncStatusQuery(Query):
    """Get the last git sync metadata."""
    pass
