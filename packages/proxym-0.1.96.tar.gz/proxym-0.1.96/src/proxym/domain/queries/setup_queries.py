"""Setup checklist queries — read-only request objects for dashboard state."""

from __future__ import annotations

from dataclasses import dataclass

from proxym.domain.bus import Query


@dataclass
class GetSetupChecklistQuery(Query):
    """Return the current setup checklist snapshot."""

    pass
