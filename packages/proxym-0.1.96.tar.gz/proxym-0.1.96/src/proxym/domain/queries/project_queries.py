"""Project queries — read-only request objects for project data."""

from __future__ import annotations

from dataclasses import dataclass

from proxym.domain.bus import Query


@dataclass
class ListProjectsQuery(Query):
    """List projects with optional filters."""

    status: str | None = None
    source_type: str | None = None


@dataclass
class GetProjectQuery(Query):
    """Get a single project by ID or name."""

    project_id: str = ""


@dataclass
class GetProjectTicketsQuery(Query):
    """Get tickets associated with a project."""

    project_id: str = ""
