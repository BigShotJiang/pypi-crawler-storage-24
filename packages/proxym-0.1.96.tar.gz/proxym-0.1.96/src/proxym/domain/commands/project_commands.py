"""Project commands — intent objects for project write operations.

Each command represents a single user intent.  Both CLI and API create
the same command objects, ensuring identical business logic execution.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from proxym.domain.bus import Command


@dataclass
class AddProjectCommand(Command):
    """Add a project from any source (local path, git URL, SSH, FTP, or name-only).

    The handler determines source_type from the provided fields:
        path     → local
        git_url  → git
        ssh_host → ssh
        ftp_url  → ftp
        name     → local (lightweight label)
    """

    name: str | None = None
    path: str | None = None
    git_url: str | None = None
    clone_to: str | None = None
    ssh_host: str | None = None
    ssh_path: str | None = None
    ssh_user: str = "root"
    ssh_key: str | None = None
    ftp_url: str | None = None
    default_tool: str | None = None
    description: str = ""
    environment_ids: list[str] = field(default_factory=list)
    tool_names: list[str] = field(default_factory=list)
    llm_names: list[str] = field(default_factory=list)
    user_ids: list[str] = field(default_factory=list)


@dataclass
class UpdateProjectCommand(Command):
    """Update an existing project's attributes."""

    project_id: str = ""
    name: str | None = None
    default_tool: str | None = None
    description: str | None = None
    status: str | None = None
    environment_ids: list[str] | None = None
    tool_names: list[str] | None = None
    llm_names: list[str] | None = None
    user_ids: list[str] | None = None


@dataclass
class RemoveProjectCommand(Command):
    """Remove a project from the registry."""

    project_id: str = ""


@dataclass
class ScanDirectoryCommand(Command):
    """Scan a directory for projects and register discovered ones."""

    directory: str = ""
