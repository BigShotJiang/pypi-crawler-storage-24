"""Task/ticket commands — intent objects for task write operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from proxym.domain.bus import Command


@dataclass
class CreateTaskCommand(Command):
    """Create a new task/ticket, optionally linked to a project."""

    task: str = ""
    project_id: str = ""
    priority: str = "medium"
    ticket_type: str = "task"
    tool: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AssignTaskCommand(Command):
    """Assign a task to a tool or human."""

    ticket_id: str = ""
    tool: str = ""
    assignee_type: str = "tool"  # "tool" or "human"


@dataclass
class CompleteTaskCommand(Command):
    """Mark a task as completed (by tool or human)."""

    ticket_id: str = ""
    result: str = ""
    exit_code: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
