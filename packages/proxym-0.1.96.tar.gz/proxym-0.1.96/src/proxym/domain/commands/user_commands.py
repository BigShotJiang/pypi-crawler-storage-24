"""User commands — intent objects for user write operations."""

from __future__ import annotations

from dataclasses import dataclass, field

from proxym.domain.bus import Command


@dataclass
class CreateUserCommand(Command):
    """Create a new user (manual or git-discovered)."""
    name: str = ""
    email: str = ""
    username: str = ""
    role: str = "developer"
    is_default: bool = False
    git_configured: bool = False


@dataclass
class UpdateUserCommand(Command):
    """Update an existing user."""
    user_id: str = ""
    updates: dict = field(default_factory=dict)


@dataclass
class DeleteUserCommand(Command):
    """Delete a user."""
    user_id: str = ""


@dataclass
class SyncGitUsersCommand(Command):
    """Sync users from git commit history into the database."""
    repo_path: str | None = None
