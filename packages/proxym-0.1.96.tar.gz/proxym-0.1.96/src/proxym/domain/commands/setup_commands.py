"""Setup checklist commands — intent objects for checklist state changes."""

from __future__ import annotations

from dataclasses import dataclass

from proxym.domain.bus import Command


@dataclass
class ToggleSetupStepCommand(Command):
    """Toggle or explicitly set a setup checklist step."""

    step_id: str = ""
    completed: bool | None = None


@dataclass
class ResetSetupChecklistCommand(Command):
    """Clear the setup checklist state."""

    pass
