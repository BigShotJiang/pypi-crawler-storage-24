"""Domain commands — intent objects for write operations."""

from proxym.domain.commands.project_commands import (
    AddProjectCommand,
    UpdateProjectCommand,
    RemoveProjectCommand,
    ScanDirectoryCommand,
)
from proxym.domain.commands.setup_commands import (
    ResetSetupChecklistCommand,
    ToggleSetupStepCommand,
)
from proxym.domain.commands.task_commands import (
    CreateTaskCommand,
    AssignTaskCommand,
    CompleteTaskCommand,
)
from proxym.domain.commands.user_commands import (
    CreateUserCommand,
    UpdateUserCommand,
    DeleteUserCommand,
    SyncGitUsersCommand,
)

__all__ = [
    "AddProjectCommand",
    "UpdateProjectCommand",
    "RemoveProjectCommand",
    "ScanDirectoryCommand",
    "ResetSetupChecklistCommand",
    "ToggleSetupStepCommand",
    "CreateTaskCommand",
    "AssignTaskCommand",
    "CompleteTaskCommand",
    "CreateUserCommand",
    "UpdateUserCommand",
    "DeleteUserCommand",
    "SyncGitUsersCommand",
]
