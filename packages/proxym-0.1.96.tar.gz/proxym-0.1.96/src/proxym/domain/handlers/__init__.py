"""Domain handlers — business logic execution for commands and queries."""

from proxym.domain.handlers.project_handler import (
    ProjectCommandHandler,
    ProjectQueryHandler,
)
from proxym.domain.handlers.task_handler import TaskCommandHandler
from proxym.domain.handlers.user_handler import (
    UserCommandHandler,
    UserQueryHandler,
)

__all__ = [
    "ProjectCommandHandler",
    "ProjectQueryHandler",
    "TaskCommandHandler",
    "UserCommandHandler",
    "UserQueryHandler",
]
