"""Domain layer — CQRS + Event Sourcing for proxym.

Provides a unified command/query bus used by both CLI and Web layers.

Architecture:
    Commands  → CommandBus → Handler → Domain Model + EventStore
    Queries   → QueryBus   → Handler → Read Model

Public API:
    CommandBus   — dispatch commands (write operations)
    QueryBus     — dispatch queries (read operations)
    EventStore   — persisted event log for audit/replay
    DomainEvent  — base event class
"""

from __future__ import annotations

from proxym.domain.events import DomainEvent, EventStore
from proxym.domain.bus import CommandBus, QueryBus

__all__ = [
    "DomainEvent",
    "EventStore",
    "CommandBus",
    "QueryBus",
]
