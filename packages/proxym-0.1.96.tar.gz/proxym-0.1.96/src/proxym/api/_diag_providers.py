"""Diagnostic checks: LLM provider configuration and model aliases."""
from __future__ import annotations

from typing import Any

from proxym.config import get_settings


async def check_providers_config() -> dict[str, Any]:
    """Check which LLM providers are configured with API keys."""
    settings = get_settings()
    providers = settings.available_providers()

    provider_details = []
    for name, key in providers.items():
        provider_details.append({
            "name": name,
            "has_key": bool(key) and key != "ollama",
            "is_local": name == "ollama",
            "key_prefix": key[:8] + "..." if key and key != "ollama" and len(key) > 8 else None,
        })

    # Check all registry models against available providers.
    # OpenRouter acts as a universal gateway — if configured, it can serve
    # models from anthropic, google, openai, deepseek, mistral, etc.
    from proxym.providers import MODELS
    has_openrouter = "openrouter" in providers
    model_status = []
    for model_id, spec in MODELS.items():
        # Model is available if its direct provider is configured OR if openrouter
        # is configured (openrouter can proxy anthropic, google, openai, etc.)
        available = spec.provider in providers or (has_openrouter and spec.provider != "ollama")
        model_status.append({
            "model_id": model_id,
            "model": spec.litellm_model,
            "provider": spec.provider,
            "display_name": spec.display_name,
            "params_b": spec.params_b,
            "is_local": spec.is_local,
            "is_free": spec.is_free,
            "input_cost": spec.input_cost,
            "output_cost": spec.output_cost,
            "available": available,
            "via_openrouter": available and spec.provider not in providers and has_openrouter,
        })

    return {
        "service": "providers",
        "total_providers": len(providers),
        "providers": provider_details,
        "models": model_status,
        "default_model": settings.default_model,
        "fallback_model": settings.fallback_model,
        "local_model": settings.local_model,
        "all_models_available": all(m["available"] for m in model_status),
        "details": {},
    }
