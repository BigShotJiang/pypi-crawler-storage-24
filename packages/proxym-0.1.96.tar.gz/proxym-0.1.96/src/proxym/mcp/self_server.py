"""MCP self-server — exposes proxym CLI commands as tools for LLM.

Mounted at ``/mcp/self/tools/*`` on the FastAPI app. Allows an LLM in a chat
session (e.g. Open WebUI) to manage VMs, accounts, costs, and logs by calling
these endpoints as tool functions.

Tool endpoints are split into sub-modules:
  - _tools_vm.py       — VM list/create/start/stop/snapshot/switch
  - _tools_accounts.py — account list/costs/add
  - _tools_tickets.py  — ticket list/create/assign/board, sprint create
  - _tools_system.py   — status/logs/models
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

router = APIRouter(prefix="/mcp/self", tags=["mcp-self"])

# ── Include sub-routers ──────────────────────────────────

from proxym.mcp._tools_vm import router as vm_router          # noqa: E402
from proxym.mcp._tools_accounts import router as acc_router    # noqa: E402
from proxym.mcp._tools_tickets import router as tkt_router     # noqa: E402
from proxym.mcp._tools_system import router as sys_router      # noqa: E402
from proxym.mcp._tools_vallm import router as vallm_router     # noqa: E402

router.include_router(vm_router)
router.include_router(acc_router)
router.include_router(tkt_router)
router.include_router(sys_router)
router.include_router(vallm_router)

# ── Aggregated TOOL_SCHEMA for LLM ──────────────────────

from proxym.mcp._tools_vm import TOOL_SCHEMA_VM                # noqa: E402
from proxym.mcp._tools_accounts import TOOL_SCHEMA_ACCOUNTS    # noqa: E402
from proxym.mcp._tools_tickets import TOOL_SCHEMA_TICKETS      # noqa: E402
from proxym.mcp._tools_system import TOOL_SCHEMA_SYSTEM        # noqa: E402
from proxym.mcp._tools_vallm import TOOL_SCHEMA_VALLM          # noqa: E402

TOOL_SCHEMA: list[dict[str, Any]] = [
    *TOOL_SCHEMA_VM,
    *TOOL_SCHEMA_ACCOUNTS,
    *TOOL_SCHEMA_TICKETS,
    *TOOL_SCHEMA_SYSTEM,
    *TOOL_SCHEMA_VALLM,
]
