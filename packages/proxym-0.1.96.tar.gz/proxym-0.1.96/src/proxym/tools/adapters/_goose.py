"""Goose CLI adapter — autonomous coding assistant."""
from __future__ import annotations

from proxym.tools.adapters._base import BaseAdapter


class GooseAdapter(BaseAdapter):
    """Adapter for Goose CLI (block/goose)."""

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        args = ["goose", "run", "--text", prompt]
        if model:
            args.extend(["--model", model])
        return args
