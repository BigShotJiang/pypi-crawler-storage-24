"""LLM CLI adapter — Simon Willison's universal LLM client."""
from __future__ import annotations

from proxym.tools.adapters._base import BaseAdapter


class LLMCliAdapter(BaseAdapter):
    """Adapter for llm CLI (Simon Willison)."""

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        args = ["llm"]
        if model:
            args.extend(["-m", model])
        args.append(prompt)
        return args
