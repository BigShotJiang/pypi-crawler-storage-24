"""Plandex CLI adapter — multi-file planning and coding agent."""
from __future__ import annotations

from proxym.tools.adapters._base import BaseAdapter


class PlandexAdapter(BaseAdapter):
    """Adapter for Plandex CLI."""

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        args = ["plandex", "tell", prompt]
        return args
