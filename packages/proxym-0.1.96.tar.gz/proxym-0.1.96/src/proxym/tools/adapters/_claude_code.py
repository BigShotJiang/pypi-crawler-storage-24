"""Claude Code CLI adapter.

Claude Code uses the Anthropic API. When running through the LiteLLM proxy,
ANTHROPIC_BASE_URL and ANTHROPIC_API_KEY are injected automatically.
"""
from __future__ import annotations

from proxym.tools.adapters._base import BaseAdapter


class ClaudeCodeAdapter(BaseAdapter):
    """Adapter for claude CLI (Anthropic Claude Code)."""

    # env vars Claude Code recognises
    ENV_KEYS = {
        "ANTHROPIC_API_KEY",
        "ANTHROPIC_BASE_URL",
    }

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        args = ["claude", "--print", "--dangerously-skip-permissions"]
        if model:
            args.extend(["--model", model])
        args.append(prompt)
        return args
