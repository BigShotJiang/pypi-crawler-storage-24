"""Open Interpreter CLI adapter — agent executing code and shell commands."""
from __future__ import annotations

from proxym.tools.adapters._base import BaseAdapter


class InterpreterAdapter(BaseAdapter):
    """Adapter for Open Interpreter CLI."""

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        args = ["interpreter", "--yes"]
        if model:
            args.extend(["--model", model])
        args.extend(["--message", prompt])
        return args
