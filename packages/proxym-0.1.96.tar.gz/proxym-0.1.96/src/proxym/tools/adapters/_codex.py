"""OpenAI Codex CLI adapter — agentive terminal assistant."""
from __future__ import annotations

from proxym.tools.adapters._base import BaseAdapter


class CodexAdapter(BaseAdapter):
    """Adapter for OpenAI Codex CLI."""

    def build_args(
        self, prompt: str, project_dir: str, mode: str = "", model: str = "",
        files: list[str] | None = None,
    ) -> list[str]:
        args = ["codex", "--full-auto"]
        if model:
            args.extend(["--model", model])
        args.append(prompt)
        return args
