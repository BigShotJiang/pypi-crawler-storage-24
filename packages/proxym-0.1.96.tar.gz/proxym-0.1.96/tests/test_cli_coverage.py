"""Test CLI coverage — verify all expected commands are registered."""
import pytest
from click.testing import CliRunner


@pytest.fixture
def runner():
    from proxym.ctl import cli
    return CliRunner(), cli


class TestCLIGroupsRegistered:
    """Verify all CLI groups and commands exist."""

    def test_top_level_commands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["--help"])
        assert result.exit_code == 0
        for cmd in ["serve", "status", "models", "chat", "logs", "providers",
                     "routing-test", "projects"]:
            assert cmd in result.output, f"Missing top-level command: {cmd}"

    def test_groups_registered(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["--help"])
        for group in ["accounts", "vm", "browser", "vscode",
                       "ticket", "sprint", "project", "diagnose", "context", "tests"]:
            assert group in result.output, f"Missing CLI group: {group}"

    def test_ticket_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["ticket", "--help"])
        assert result.exit_code == 0
        for sub in ["list", "create", "show", "update", "delete",
                     "assign", "comment", "board"]:
            assert sub in result.output, f"Missing ticket subcommand: {sub}"

    def test_sprint_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["sprint", "--help"])
        assert result.exit_code == 0
        for sub in ["list", "create", "show", "update", "delete", "board"]:
            assert sub in result.output, f"Missing sprint subcommand: {sub}"

    def test_diagnose_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["diagnose", "--help"])
        assert result.exit_code == 0
        for sub in ["all", "proxy", "vscode", "providers", "agent", "test"]:
            assert sub in result.output, f"Missing diagnose subcommand: {sub}"

    def test_tests_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["tests", "--help"])
        assert result.exit_code == 0
        for sub in ["status", "vscode", "proxy", "providers", "extensions",
                     "agent-setup", "agent"]:
            assert sub in result.output, f"Missing tests subcommand: {sub}"

    def test_context_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["context", "--help"])
        assert result.exit_code == 0
        for sub in ["stats", "sessions", "mcp", "delta", "detect"]:
            assert sub in result.output, f"Missing context subcommand: {sub}"

    def test_accounts_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["accounts", "--help"])
        assert result.exit_code == 0
        for sub in ["list", "add", "costs", "get", "delete", "bind-tool"]:
            assert sub in result.output, f"Missing accounts subcommand: {sub}"

    def test_vm_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["vm", "--help"])
        assert result.exit_code == 0
        for sub in ["list", "create", "start", "stop", "pause", "resume",
                     "snapshot", "switch", "open", "ssh", "logs", "delete",
                     "bulk-delete", "console"]:
            assert sub in result.output, f"Missing vm subcommand: {sub}"

    def test_vscode_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["vscode", "--help"])
        assert result.exit_code == 0
        for sub in ["start", "stop", "open", "logs", "status", "build"]:
            assert sub in result.output, f"Missing vscode subcommand: {sub}"

    def test_browser_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["browser", "--help"])
        assert result.exit_code == 0
        for sub in ["list", "assign", "sync", "snapshot"]:
            assert sub in result.output, f"Missing browser subcommand: {sub}"

    def test_project_subcommands(self, runner):
        r, cli = runner
        result = r.invoke(cli, ["project", "--help"])
        assert result.exit_code == 0
        for sub in ["list", "add", "scan", "show", "update", "remove", "task"]:
            assert sub in result.output, f"Missing project subcommand: {sub}"
