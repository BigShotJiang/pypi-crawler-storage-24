# TODO App (TypeScript CLI)

> This project was automatically generated and built by
> [proxym](https://github.com/wronai/proxy) AI tool orchestration.

## Quick Start

```bash
npm install
npm run build
node dist/index.js add "My first task" --priority high
node dist/index.js list
```

## Commands

| Command | Description |
|---------|-------------|
| `todo add <title>` | Create a new task |
| `todo list` | List all tasks |
| `todo show <id>` | Show task details |
| `todo done <id>` | Mark as complete |
| `todo remove <id>` | Delete a task |
| `todo stats` | Show statistics |

## Development

```bash
npm test          # run tests
npm run build     # compile TypeScript
npm run typecheck # type check without emit
```

## How It Was Built

This project was generated step-by-step using proxym:

1. Project scaffold created on disk
2. Registered in proxym as a managed project
3. Sprint created with implementation tickets
4. Each ticket dispatched to an AI coding tool
5. Results verified automatically after each step
6. Failed steps escalated to human via tickets

See `examples/todo-app-ts/` in the proxym repo for the full orchestration script.
