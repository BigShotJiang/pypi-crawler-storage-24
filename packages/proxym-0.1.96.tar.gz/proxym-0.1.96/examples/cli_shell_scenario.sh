#!/usr/bin/env bash
set -e

echo "=== Proxym CLI Shell Scenario ==="

echo "1. Creating project directory on host..."
mkdir -p examples/todo_list_project

echo "2. Registering project in Proxym..."
proxym project add examples/todo_list_project --name "todo-app" --tool "claude-code"

echo "3. Creating initial setup ticket..."
proxym project task "todo-app" "Initialize a basic Node.js TypeScript testing environment with package.json, jest, and tsconfig.json." -t "claude-code" --priority "high"

echo "4. Creating implementation ticket..."
proxym project task "todo-app" "Implement a simple TodoList class in TypeScript with add, remove, and list methods. Add Jest tests for it." -t "claude-code" --priority "medium"

echo "5. Starting background executor..."
proxym tools start

echo "6. Checking job queue status..."
sleep 2
proxym tools queue
proxym tools jobs

echo "=== Scenario Submitted Successfully ==="
echo "The tools are now executing the tasks in the background."
echo "If any tool fails, a ticket for a 'human' will be automatically created in the dashboard."
