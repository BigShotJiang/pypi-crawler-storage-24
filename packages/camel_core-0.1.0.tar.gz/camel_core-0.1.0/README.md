# CAMEL core

CAMEL core is a set of utilities used by Bioinformatics Platform at the Belgian Public Health institute (Sciensano).

This package is not meant to be used directly, but contains functionality that is shared between various projects.


## Functionality

- Command execution through subprocess
- Input/output (IO) classes for handling tool / input output
- Utility functions for handling common bioinformatics formats such as FASTQ, FASTA, BAM
- HTML reports
- Utility functions for working with Snakemake
- BaseTool class
- Logging
