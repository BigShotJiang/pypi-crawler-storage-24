# Changelog

## 0.1.0 (2026-03-10)

Initial release.

- Sync client (`SaakshyStamp`) and async client (`AsyncSaakshyStamp`)
- `stamp()` — upload, trigger server-side processing, poll, download result
- `verify_file()` — three-layer verification (C2PA + watermark + fingerprint)
- `resolve()` — resolve manifest by watermark ID or fingerprint
- `get_job()` — check stamping job status
- Full exception hierarchy mapping HTTP status codes
- API key via constructor or `SAAKSHY_API_KEY` environment variable
- SGI types: `AI_GENERATED`, `AI_MODIFIED`, `EXEMPT_ENHANCED`
- Label languages: en, hi, ta, te, bn, mr, kn, ml
- PEP 561 typed package (`py.typed`)
