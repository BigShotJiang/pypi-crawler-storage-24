# Saakshy Stamp

AI content provenance infrastructure. C2PA manifest + invisible watermark + perceptual fingerprint in five lines of code.

Embeds C2PA manifest, invisible watermark, visible label, and perceptual fingerprint into videos, images, and audio. All processing happens server-side — no GPU, PyTorch, or FFmpeg required on your end. Compliant with India's IT Rules 2026 (SGI labelling).

[Documentation](https://saakshy.ai/docs) | [Website](https://saakshy.ai) | [IT Rules 2026 Guide](https://saakshy.ai/docs/it-rules-2026)

## Installation

```bash
pip install saakshy-stamp
```

Requires Python 3.10+. Only two dependencies: `httpx` and `pydantic`.

## Quick start

```python
from saakshy_stamp import SaakshyStamp, StampConfig, SGIType

client = SaakshyStamp(api_key="sk_...")

result = client.stamp(
    "ai_video.mp4",
    "stamped_video.mp4",
    StampConfig(
        tool_name="MyAITool",
        tool_version="1.0",
        sgi_type=SGIType.AI_GENERATED,
        language="hi",  # supports: en, hi, ta, te, bn, mr, kn, ml
    ),
)

print(result.content_uuid)
```

## Async usage

```python
from saakshy_stamp import AsyncSaakshyStamp, StampConfig, SGIType

async with AsyncSaakshyStamp(api_key="sk_...") as client:
    result = await client.stamp(
        "ai_video.mp4",
        "stamped_video.mp4",
        StampConfig(
            tool_name="MyAITool",
            tool_version="1.0",
            sgi_type=SGIType.AI_GENERATED,
        ),
    )
```

## Verification

```python
# Verify any media file
result = client.verify_file("suspicious_video.mp4")
print(result.status)      # "verified" | "unverified" | "tampered"
print(result.confidence)   # 0.0 to 1.0

# Resolve manifest by watermark ID
result = client.resolve(watermark_id="abc-123-def")
print(result.matches)
```

## Error handling

```python
from saakshy_stamp import SaakshyStamp, SaakshyError, AuthenticationError, RateLimitError

client = SaakshyStamp(api_key="sk_...")

try:
    result = client.stamp("video.mp4", "out.mp4", config)
except AuthenticationError:
    print("Invalid API key")
except RateLimitError:
    print("Quota exceeded — upgrade your plan")
except SaakshyError as e:
    print(f"SDK error: {e}")
```

## Configuration

The API key can be provided via constructor or environment variable:

```python
# Option 1: Constructor
client = SaakshyStamp(api_key="sk_...")

# Option 2: Environment variable
# export SAAKSHY_API_KEY=sk_...
client = SaakshyStamp()
```

## SGI types

| Type | When to use |
|------|-------------|
| `AI_GENERATED` | Fully synthetic content (must label per IT Rules 2026) |
| `AI_MODIFIED` | Real content with AI alterations (must label) |
| `EXEMPT_ENHANCED` | Routine editing like colour correction (exempt) |

## How it works

1. Your file is uploaded directly to S3 via presigned URL (never touches our API server)
2. Server embeds three layers of provenance:
   - **C2PA v2 manifest** — cryptographic proof of origin
   - **Invisible watermark** — survives platform recompression (WhatsApp, Instagram)
   - **Perceptual fingerprint** — always matchable as fallback
3. You download the stamped file

## API key

Sign up at [saakshy.ai](https://saakshy.ai) to get your API key.

## License

MIT
