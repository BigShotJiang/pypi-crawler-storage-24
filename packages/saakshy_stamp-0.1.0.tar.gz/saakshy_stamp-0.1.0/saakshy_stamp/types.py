"""Public types for the Saakshy SDK."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class SGIType(str, Enum):
    """SGI classification per IT Rules 2026."""

    AI_GENERATED = "ai_generated"
    """Fully synthetic content — must be labelled."""

    AI_MODIFIED = "ai_modified"
    """Real content with AI alterations — must be labelled."""

    EXEMPT_ENHANCED = "exempt_enhanced"
    """Routine editing (colour correction, noise reduction) — exempt."""


class StampConfig(BaseModel):
    """Configuration for a stamping request."""

    tool_name: str
    """Name of the AI tool (e.g. 'DubAI', 'Synthesia')."""

    tool_version: str
    """Version of the AI tool (e.g. '2.3.0')."""

    sgi_type: SGIType
    """SGI classification of the content."""

    language: str = "en"
    """Label language. Supports: en, hi, ta, te, bn, mr, kn, ml."""


class JobStatus(str, Enum):
    """Status of an async stamping job."""

    PENDING = "pending"
    PROCESSING = "processing"
    DONE = "done"
    FAILED = "failed"


class StampJob(BaseModel):
    """Status of a stamping job."""

    job_id: str
    status: JobStatus
    download_url: str | None = None
    content_uuid: str | None = None
    manifest_id: str | None = None
    error: str | None = None


class StampResult(BaseModel):
    """Result of a completed stamping operation."""

    job_id: str
    content_uuid: str
    manifest_id: str


class VerifyResult(BaseModel):
    """Result of a verification request."""

    status: str
    match_type: str | None = None
    confidence: float | None = None
    manifest: dict | None = None


class ResolveMatch(BaseModel):
    """A single match from the resolution API."""

    content_uuid: str
    manifest_hash: str
    match_type: str
    confidence: float


class ResolveResult(BaseModel):
    """Result of a manifest resolution request."""

    matches: list[ResolveMatch]
    query_type: str
    total: int
