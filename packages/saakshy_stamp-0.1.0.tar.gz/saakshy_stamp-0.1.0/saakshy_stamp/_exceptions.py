"""Saakshy SDK exception hierarchy.

Exception
└── SaakshyError
    ├── ConfigurationError        — missing API key, bad config
    ├── APIError
    │   ├── APIConnectionError    — network / DNS failures
    │   │   └── APITimeoutError   — request timed out
    │   └── APIStatusError        — 4xx / 5xx responses
    │       ├── BadRequestError          (400)
    │       ├── AuthenticationError      (401)
    │       ├── NotFoundError            (404)
    │       ├── FileTooLargeError        (413)
    │       ├── RateLimitError           (429)
    │       └── InternalServerError      (5xx)
    └── StampingError             — server-side stamping failed
"""

from __future__ import annotations


class SaakshyError(Exception):
    """Base exception for all Saakshy SDK errors."""


class ConfigurationError(SaakshyError):
    """Missing or invalid SDK configuration (e.g. no API key)."""


class APIError(SaakshyError):
    """Base for all API communication errors."""


class APIConnectionError(APIError):
    """Could not connect to the API (network, DNS, TLS)."""


class APITimeoutError(APIConnectionError):
    """Request timed out."""


class APIStatusError(APIError):
    """API returned a non-2xx HTTP status."""

    status_code: int
    body: str | None

    def __init__(self, message: str, *, status_code: int, body: str | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class BadRequestError(APIStatusError):
    """400 — invalid request parameters."""

    def __init__(self, message: str, body: str | None = None) -> None:
        super().__init__(message, status_code=400, body=body)


class AuthenticationError(APIStatusError):
    """401 — invalid or missing API key."""

    def __init__(self, message: str = "Invalid API key", body: str | None = None) -> None:
        super().__init__(message, status_code=401, body=body)


class NotFoundError(APIStatusError):
    """404 — resource not found."""

    def __init__(self, message: str, body: str | None = None) -> None:
        super().__init__(message, status_code=404, body=body)


class FileTooLargeError(APIStatusError):
    """413 — file exceeds size limit."""

    def __init__(self, message: str = "File exceeds 500MB limit", body: str | None = None) -> None:
        super().__init__(message, status_code=413, body=body)


class RateLimitError(APIStatusError):
    """429 — rate limit exceeded for your API key tier."""

    def __init__(self, message: str = "Rate limit exceeded", body: str | None = None) -> None:
        super().__init__(message, status_code=429, body=body)


class InternalServerError(APIStatusError):
    """5xx — server-side error."""

    def __init__(self, message: str = "Internal server error", body: str | None = None) -> None:
        super().__init__(message, status_code=500, body=body)


class StampingError(SaakshyError):
    """Server-side stamping job failed."""

    job_id: str
    error_detail: str | None

    def __init__(self, message: str, *, job_id: str, error_detail: str | None = None) -> None:
        super().__init__(message)
        self.job_id = job_id
        self.error_detail = error_detail


def _raise_for_status(status_code: int, body: str | None = None) -> None:
    """Map HTTP status codes to typed exceptions."""
    error_map: dict[int, type[APIStatusError]] = {
        400: BadRequestError,
        401: AuthenticationError,
        404: NotFoundError,
        413: FileTooLargeError,
        429: RateLimitError,
    }
    msg = body or f"HTTP {status_code}"
    if status_code in error_map:
        raise error_map[status_code](msg, body=body)
    if status_code >= 500:
        raise InternalServerError(msg, body=body)
    raise APIStatusError(msg, status_code=status_code, body=body)
