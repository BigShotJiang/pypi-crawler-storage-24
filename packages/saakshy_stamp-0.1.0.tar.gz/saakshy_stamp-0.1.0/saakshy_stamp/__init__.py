"""Saakshy Stamp SDK — AI content provenance infrastructure.

Sync usage::

    from saakshy_stamp import SaakshyStamp, StampConfig, SGIType

    client = SaakshyStamp(api_key="sk_...")
    result = client.stamp("video.mp4", "stamped.mp4", StampConfig(
        tool_name="MyAI", tool_version="1.0", sgi_type=SGIType.AI_GENERATED,
    ))

Async usage::

    from saakshy_stamp import AsyncSaakshyStamp, StampConfig, SGIType

    async with AsyncSaakshyStamp(api_key="sk_...") as client:
        result = await client.stamp("video.mp4", "stamped.mp4", StampConfig(
            tool_name="MyAI", tool_version="1.0", sgi_type=SGIType.AI_GENERATED,
        ))
"""

from ._version import __version__
from ._client import SaakshyStamp
from ._async_client import AsyncSaakshyStamp
from ._exceptions import (
    SaakshyError,
    APIError,
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConfigurationError,
    FileTooLargeError,
    InternalServerError,
    NotFoundError,
    RateLimitError,
    StampingError,
)
from .types import (
    SGIType,
    StampConfig,
    StampJob,
    StampResult,
    JobStatus,
    VerifyResult,
    ResolveMatch,
    ResolveResult,
)

__all__ = [
    "__version__",
    # Clients
    "SaakshyStamp",
    "AsyncSaakshyStamp",
    # Types
    "SGIType",
    "StampConfig",
    "StampJob",
    "StampResult",
    "JobStatus",
    "VerifyResult",
    "ResolveMatch",
    "ResolveResult",
    # Exceptions
    "SaakshyError",
    "APIError",
    "APIConnectionError",
    "APIStatusError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ConfigurationError",
    "FileTooLargeError",
    "InternalServerError",
    "NotFoundError",
    "RateLimitError",
    "StampingError",
]
