"""Sync client for Saakshy Stamp API.

Wraps the async client using asyncio.run() for callers
who don't use async/await.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

from ._async_client import AsyncSaakshyStamp
from ._constants import DEFAULT_BASE_URL, DEFAULT_TIMEOUT
from ._exceptions import ConfigurationError
from .types import (
    ResolveResult,
    StampConfig,
    StampJob,
    StampResult,
    VerifyResult,
)


class SaakshyStamp:
    """Sync client for the Saakshy Stamp API.

    Usage::

        client = SaakshyStamp(api_key="sk_...")
        result = client.stamp(
            "video.mp4", "stamped.mp4",
            StampConfig(tool_name="MyAI", tool_version="1.0", sgi_type=SGIType.AI_GENERATED),
        )
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key or os.environ.get("SAAKSHY_API_KEY")
        if not self.api_key:
            raise ConfigurationError(
                "API key required. Pass api_key= or set SAAKSHY_API_KEY environment variable."
            )
        self.base_url = (base_url or os.environ.get("SAAKSHY_API_URL") or DEFAULT_BASE_URL).rstrip("/")
        self._timeout = timeout

    def _run(self, coro: object) -> object:
        """Run an async coroutine synchronously."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(asyncio.run, coro).result()  # type: ignore[arg-type]
        return asyncio.run(coro)  # type: ignore[arg-type]

    async def _do_stamp(
        self, input_path: Path, output_path: Path, config: StampConfig
    ) -> StampResult:
        async with AsyncSaakshyStamp(
            api_key=self.api_key, base_url=self.base_url, timeout=self._timeout
        ) as client:
            return await client.stamp(input_path, output_path, config)

    async def _do_verify(self, file_path: Path) -> VerifyResult:
        async with AsyncSaakshyStamp(
            api_key=self.api_key, base_url=self.base_url, timeout=self._timeout
        ) as client:
            return await client.verify_file(file_path)

    async def _do_resolve(
        self, watermark_id: str | None, fingerprint: str | None
    ) -> ResolveResult:
        async with AsyncSaakshyStamp(
            api_key=self.api_key, base_url=self.base_url, timeout=self._timeout
        ) as client:
            return await client.resolve(watermark_id=watermark_id, fingerprint=fingerprint)

    async def _do_get_job(self, job_id: str) -> StampJob:
        async with AsyncSaakshyStamp(
            api_key=self.api_key, base_url=self.base_url, timeout=self._timeout
        ) as client:
            return await client.get_job(job_id)

    def stamp(
        self,
        input_path: str | Path,
        output_path: str | Path,
        config: StampConfig,
    ) -> StampResult:
        """Stamp a media file. Sync wrapper around the async client.

        See AsyncSaakshyStamp.stamp() for full documentation.
        """
        return self._run(self._do_stamp(Path(input_path), Path(output_path), config))  # type: ignore[return-value]

    def verify_file(self, file_path: str | Path) -> VerifyResult:
        """Upload a file for three-layer verification."""
        return self._run(self._do_verify(Path(file_path)))  # type: ignore[return-value]

    def resolve(
        self,
        *,
        watermark_id: str | None = None,
        fingerprint: str | None = None,
    ) -> ResolveResult:
        """Resolve a C2PA manifest from watermark ID or fingerprint."""
        return self._run(self._do_resolve(watermark_id, fingerprint))  # type: ignore[return-value]

    def get_job(self, job_id: str) -> StampJob:
        """Get the status of a stamping job."""
        return self._run(self._do_get_job(job_id))  # type: ignore[return-value]
