"""Async client for Saakshy Stamp API."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

import httpx

from ._constants import (
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    MAX_FILE_SIZE,
    MAX_POLL_TIME,
    POLL_INTERVAL,
    UPLOAD_TIMEOUT,
)
from ._exceptions import (
    APIConnectionError,
    APITimeoutError,
    ConfigurationError,
    StampingError,
    _raise_for_status,
)
from .types import (
    ResolveResult,
    StampConfig,
    StampJob,
    StampResult,
    VerifyResult,
)


class AsyncSaakshyStamp:
    """Async client for the Saakshy Stamp API.

    Usage::

        async with AsyncSaakshyStamp(api_key="sk_...") as client:
            result = await client.stamp(
                "video.mp4", "stamped.mp4",
                StampConfig(tool_name="MyAI", tool_version="1.0", sgi_type=SGIType.AI_GENERATED),
            )
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key or os.environ.get("SAAKSHY_API_KEY")
        if not self.api_key:
            raise ConfigurationError(
                "API key required. Pass api_key= or set SAAKSHY_API_KEY environment variable."
            )
        self.base_url = (base_url or os.environ.get("SAAKSHY_API_URL") or DEFAULT_BASE_URL).rstrip("/")
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> AsyncSaakshyStamp:
        self._client = httpx.AsyncClient(timeout=self._timeout)
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    @property
    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self._timeout)
        return self._client

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}"}

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs: object,
    ) -> httpx.Response:
        url = f"{self.base_url}{path}"
        try:
            resp = await self._http.request(method, url, headers=self._headers, **kwargs)  # type: ignore[arg-type]
        except httpx.TimeoutException as e:
            raise APITimeoutError(f"Request timed out: {e}") from e
        except httpx.ConnectError as e:
            raise APIConnectionError(f"Connection failed: {e}") from e
        if resp.status_code >= 400:
            _raise_for_status(resp.status_code, resp.text)
        return resp

    # ── Stamp ──────────────────────────────────────────────

    async def stamp(
        self,
        input_path: str | Path,
        output_path: str | Path,
        config: StampConfig,
    ) -> StampResult:
        """Stamp a media file with C2PA manifest, watermark, and visible label.

        1. Gets a presigned S3 upload URL
        2. Uploads the file directly to S3
        3. Triggers server-side stamping
        4. Polls until complete
        5. Downloads the stamped file

        Args:
            input_path: Path to the media file to stamp.
            output_path: Where to save the stamped file.
            config: Stamping configuration.

        Returns:
            StampResult with job_id, content_uuid, and manifest_id.

        Raises:
            ConfigurationError: Missing API key.
            FileTooLargeError: File exceeds 500MB.
            AuthenticationError: Invalid API key.
            RateLimitError: API key quota exceeded.
            StampingError: Server-side processing failed.
            APITimeoutError: Request timed out.
        """
        input_path = Path(input_path)
        output_path = Path(output_path)

        if not input_path.exists():
            raise FileNotFoundError(f"Input file not found: {input_path}")

        file_size = input_path.stat().st_size
        if file_size > MAX_FILE_SIZE:
            from ._exceptions import FileTooLargeError
            raise FileTooLargeError(f"File is {file_size / 1024 / 1024:.0f}MB, limit is 500MB")

        mime_type = _detect_mime(input_path)

        # Step 1: Initiate upload
        resp = await self._request("POST", "/v1/stamp/upload/initiate/", json={
            "filename": input_path.name,
            "content_type": mime_type,
        })
        data = resp.json()
        job_id = data["job_id"]
        upload_url = data["upload_url"]
        input_key = data["input_key"]

        # Step 2: Upload to S3
        file_bytes = input_path.read_bytes()
        try:
            upload_resp = await self._http.put(
                upload_url,
                content=file_bytes,
                headers={"Content-Type": mime_type},
                timeout=UPLOAD_TIMEOUT,
            )
            if upload_resp.status_code >= 400:
                _raise_for_status(upload_resp.status_code, upload_resp.text)
        except httpx.TimeoutException as e:
            raise APITimeoutError(f"Upload timed out: {e}") from e

        # Step 3: Trigger stamping
        await self._request("POST", "/v1/stamp/trigger/", json={
            "job_id": job_id,
            "input_key": input_key,
            "config": {
                "tool_name": config.tool_name,
                "tool_version": config.tool_version,
                "sgi_type": config.sgi_type.value,
                "language": config.language,
            },
        })

        # Step 4: Poll until done
        elapsed = 0.0
        while elapsed < MAX_POLL_TIME:
            await asyncio.sleep(POLL_INTERVAL)
            elapsed += POLL_INTERVAL

            resp = await self._request("GET", f"/v1/stamp/jobs/{job_id}/")
            job = StampJob(**resp.json())

            if job.status.value == "done":
                # Step 5: Download
                if not job.download_url:
                    raise StampingError("Job done but no download URL", job_id=job_id)
                dl_resp = await self._http.get(job.download_url, timeout=UPLOAD_TIMEOUT)
                output_path.write_bytes(dl_resp.content)
                return StampResult(
                    job_id=job_id,
                    content_uuid=job.content_uuid or "",
                    manifest_id=job.manifest_id or "",
                )

            if job.status.value == "failed":
                raise StampingError(
                    f"Stamping failed: {job.error or 'unknown'}",
                    job_id=job_id,
                    error_detail=job.error,
                )

        raise APITimeoutError(f"Job {job_id} did not complete within {MAX_POLL_TIME}s")

    async def get_job(self, job_id: str) -> StampJob:
        """Get the status of a stamping job."""
        resp = await self._request("GET", f"/v1/stamp/jobs/{job_id}/")
        return StampJob(**resp.json())

    # ── Verify ─────────────────────────────────────────────

    async def verify_file(self, file_path: str | Path) -> VerifyResult:
        """Upload a file for three-layer verification."""
        file_path = Path(file_path)
        mime_type = _detect_mime(file_path)
        with open(file_path, "rb") as f:
            resp = await self._request(
                "POST", "/v1/verify/file/",
                files={"file": (file_path.name, f, mime_type)},
            )
        return VerifyResult(**resp.json())

    # ── Resolve ────────────────────────────────────────────

    async def resolve(
        self,
        *,
        watermark_id: str | None = None,
        fingerprint: str | None = None,
    ) -> ResolveResult:
        """Resolve a C2PA manifest from watermark ID or fingerprint."""
        payload: dict[str, str] = {}
        if watermark_id:
            payload["watermark_id"] = watermark_id
        if fingerprint:
            payload["fingerprint"] = fingerprint
        resp = await self._request("POST", "/v1/resolve/", json=payload)
        return ResolveResult(**resp.json())


def _detect_mime(path: Path) -> str:
    """Detect MIME type from file extension."""
    return {
        ".mp4": "video/mp4", ".mov": "video/quicktime", ".avi": "video/x-msvideo",
        ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4",
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".webp": "image/webp",
    }.get(path.suffix.lower(), "application/octet-stream")
