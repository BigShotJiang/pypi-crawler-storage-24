from __future__ import annotations

import argparse
import multiprocessing as mp
import sys
from typing import Any

from rich import box
from rich.console import Console, Group
from rich.panel import Panel
from rich.table import Table

from . import __version__
from .comparer import compare_from_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Compare very large CSV files using streaming and multiprocessing.")
    parser.add_argument("--config", "-c", required=True, help="Path to the YAML configuration file.")
    parser.add_argument("--left-file", help="Override files.left from the config.")
    parser.add_argument("--right-file", help="Override files.right from the config.")
    parser.add_argument("--chunk-size", type=int, help="Override performance.chunk_size.")
    parser.add_argument("--size", "--sample-size", dest="sample_size", type=int, help="Override sampling.size.")
    parser.add_argument("--sample-seed", type=int, help="Override sampling.seed.")
    parser.add_argument("--workers", type=int, help="Override performance.workers.")
    parser.add_argument("--output-dir", help="Override output.directory.")
    parser.add_argument("--output-prefix", help="Override output.prefix.")
    return parser


def build_summary_panel(summary: dict[str, Any]) -> Panel:
    files = summary["files"]
    counts = summary["counts"]
    sampling = summary["sampling"]

    info = Table.grid(expand=True)
    info.add_column(style="bold cyan", ratio=1)
    info.add_column(ratio=4)
    info.add_row("left", str(files["left"]))
    info.add_row("right", str(files["right"]))
    info.add_row("mode", f"{sampling['mode']}  matched={counts['matched']:,}")
    info.add_row("elapsed", f"{summary['elapsed_seconds']:.2f}s")

    results = Table(box=box.SIMPLE_HEAVY, expand=True, header_style="bold cyan")
    results.add_column("Metric", style="bold")
    results.add_column("Left", justify="right")
    results.add_column("Right", justify="right")
    results.add_column("Detail")
    results.add_row("Rows", f"{counts['total_left_rows']:,}", f"{counts['total_right_rows']:,}", "total input rows")
    results.add_row("Unique Keys", f"{counts['left_unique_keys']:,}", f"{counts['right_unique_keys']:,}", "after first-occurrence dedupe")
    results.add_row("Only On Side", f"{counts['only_in_left']:,}", f"{counts['only_in_right']:,}", "left-only / right-only keys")
    results.add_row("Duplicates", f"{counts['duplicate_keys_left']:,}", f"{counts['duplicate_keys_right']:,}", "duplicate rows ignored after first occurrence")
    results.add_row("Differences", f"{counts['different_rows']:,}", f"{counts['different_cells']:,} cells", counts["different_rows_percentage"])

    outputs = Table.grid(expand=True)
    outputs.add_column(style="bold cyan", ratio=1)
    outputs.add_column(ratio=4)
    outputs.add_row("differences", str(summary["outputs"]["differences"]))
    outputs.add_row("summary", str(summary["outputs"]["summary_json"]))

    group_items: list[Any] = [info, results, outputs]
    if summary["warnings"]:
        warnings = Table.grid(expand=True)
        warnings.add_column(style="bold yellow")
        for warning in summary["warnings"]:
            warnings.add_row(f"warning: {warning}")
        group_items.append(warnings)

    return Panel(Group(*group_items), title=f"csv-stream-diff v{__version__}", border_style="cyan")


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    console = Console()
    error_console = Console(stderr=True)

    overrides = {
        "left_file": args.left_file,
        "right_file": args.right_file,
        "chunk_size": args.chunk_size,
        "sample_size": args.sample_size,
        "sample_seed": args.sample_seed,
        "workers": args.workers,
        "output_dir": args.output_dir,
        "output_prefix": args.output_prefix,
    }

    try:
        summary = compare_from_path(args.config, overrides)
    except KeyboardInterrupt:
        error_console.print("[yellow]csv-stream-diff cancelled by user.[/yellow]")
        return 130
    except Exception as exc:
        error_console.print(f"[red]csv-stream-diff failed:[/red] {exc}")
        return 1

    console.print(build_summary_panel(summary))
    return 0


if __name__ == "__main__":
    mp.freeze_support()
    raise SystemExit(main())
