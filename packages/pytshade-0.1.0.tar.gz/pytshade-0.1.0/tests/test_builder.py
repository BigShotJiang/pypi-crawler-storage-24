"""
Unit tests for StratoScriptBuilder.

Tests cover command output, state tracking, flag deduplication,
validation, version-awareness, and high-level helpers.
"""

import datetime
import os
import tempfile
import textwrap
import unittest

# Allow running from project root
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pytshade.builder import StratoScriptBuilder, VALID_FLAGS, VALID_PLANETS
from pytshade.version import NightshadeVersion


class TestBuilderBasics(unittest.TestCase):
    """Core command generation."""

    def setUp(self):
        # Use a non-existent location file so it falls back to defaults
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_comment(self):
        self.b.comment("hello world")
        self.assertIn("# hello world", self.b.build())

    def test_wait(self):
        self.b.wait(3)
        self.assertEqual("wait duration 3", self.b.build())

    def test_wait_negative_raises(self):
        with self.assertRaises(ValueError):
            self.b.wait(-1)

    def test_clear(self):
        self.b.clear()
        self.assertEqual("clear", self.b.build())

    def test_raw_command(self):
        self.b.raw_command("custom stuff")
        self.assertEqual("custom stuff", self.b.build())

    def test_build_returns_string(self):
        self.b.wait(1)
        self.assertIsInstance(self.b.build(), str)

    def test_save_creates_file(self):
        self.b.comment("test")
        with tempfile.NamedTemporaryFile(suffix=".sts", delete=False) as f:
            path = f.name
        try:
            self.b.save(path)
            with open(path) as f:
                self.assertEqual(f.read(), self.b.build())
        finally:
            os.unlink(path)


class TestFlagManagement(unittest.TestCase):
    """flag() validation and shadow-state deduplication."""

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_flag_on_off(self):
        self.b.flag("atmosphere", True)
        self.assertIn("flag atmosphere on", self.b.build())

    def test_flag_dedup(self):
        self.b.flag("atmosphere", True)
        self.b.flag("atmosphere", True)  # should be skipped
        lines = [l for l in self.b.build().splitlines() if l.startswith("flag")]
        self.assertEqual(len(lines), 1)

    def test_flag_force_bypasses_dedup(self):
        self.b.flag("atmosphere", True)
        self.b.flag("atmosphere", True, force=True)
        lines = [l for l in self.b.build().splitlines() if l.startswith("flag")]
        self.assertEqual(len(lines), 2)

    def test_flag_unknown_raises(self):
        with self.assertRaises(ValueError):
            self.b.flag("nonexistent_flag_xyz", True)

    def test_all_valid_flags_accepted(self):
        for name in VALID_FLAGS:
            b = StratoScriptBuilder(location_file="__nonexistent__.json")
            b.flag(name, True)  # should NOT raise


class TestSelection(unittest.TestCase):

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_select_planet(self):
        self.b.select_planet("Mars")
        self.assertIn("select planet Mars pointer off", self.b.build())
        self.assertEqual(self.b.state["selected_object"], "Mars")

    def test_select_planet_with_pointer(self):
        self.b.select_planet("Jupiter", pointer=True)
        self.assertIn("pointer on", self.b.build())

    def test_deselect(self):
        self.b.select_planet("Saturn")
        self.b.deselect()
        self.assertIsNone(self.b.state["selected_object"])
        self.assertIn("deselect", self.b.build())

    def test_select_hp(self):
        self.b.select_hp(11767)
        self.assertIn("select hp 11767", self.b.build())


class TestTimerateAndZoom(unittest.TestCase):

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_timerate(self):
        self.b.timerate(500)
        self.assertIn("timerate rate 500", self.b.build())
        self.assertEqual(self.b.state["timerate"], 500)

    def test_timerate_dedup(self):
        self.b.timerate(1)
        self.b.timerate(1)
        lines = [l for l in self.b.build().splitlines() if "timerate" in l]
        self.assertEqual(len(lines), 1)

    def test_zoom(self):
        self.b.zoom(60, duration=3)
        self.assertIn("zoom fov 60", self.b.build())
        self.assertEqual(self.b.state["fov"], 60)

    def test_zoom_clamped_high(self):
        self.b.zoom(999)
        self.assertIn("zoom fov 180", self.b.build())

    def test_zoom_clamped_low(self):
        self.b.zoom(-5)
        self.assertIn("zoom fov 0.001", self.b.build())


class TestMovement(unittest.TestCase):

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_set_view(self):
        self.b.set_view(90, 30, duration=4)
        self.assertIn("moveto azi 90 alt 30 duration 4", self.b.build())
        self.assertEqual(self.b.state["azimuth"], 90)
        self.assertEqual(self.b.state["altitude"], 30)

    def test_set_location(self):
        self.b.set_location(40.0, -74.0, 50)
        self.assertIn("location lat 40.0 lon -74.0 alt 50", self.b.build())

    def test_set_home_planet(self):
        self.b.set_home_planet("Mars", duration=3)
        self.assertIn('set home_planet "Mars" duration 3', self.b.build())
        self.assertEqual(self.b.state["home_planet"], "Mars")

    def test_flyto(self):
        self.b.flyto("Jupiter")
        self.assertIn("flyto Jupiter", self.b.build())
        self.assertTrue(self.b.state["tracking"])


class TestPanTo(unittest.TestCase):
    """pan_to() waypoint splitting differs by version."""

    def test_short_pan_no_split(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json",
                                version=NightshadeVersion.NG)
        b.state["azimuth"] = 180
        b.pan_to(200, 45, duration=4)
        lines = [l for l in b.build().splitlines() if "moveto" in l]
        self.assertEqual(len(lines), 1)

    def test_long_pan_splits_on_ng(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json",
                                version=NightshadeVersion.NG)
        b.state["azimuth"] = 10
        b.pan_to(350, 45, duration=4)  # 340° via shortest = 20° but raw diff >170
        lines = [l for l in b.build().splitlines() if "moveto" in l]
        # Should NOT split because normalised diff is only -20
        self.assertEqual(len(lines), 1)

    def test_long_pan_splits_needed(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json",
                                version=NightshadeVersion.NG)
        b.state["azimuth"] = 0
        b.pan_to(175, 45, duration=4)  # diff = 175 > 170 threshold
        lines = [l for l in b.build().splitlines() if "moveto" in l]
        self.assertEqual(len(lines), 2)

    def test_legacy_no_split(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json",
                                version=NightshadeVersion.LEGACY)
        b.state["azimuth"] = 0
        b.pan_to(175, 45, duration=4)
        lines = [l for l in b.build().splitlines() if "moveto" in l]
        # Legacy max_pan_angle is 360 — never splits
        self.assertEqual(len(lines), 1)


class TestVersionAwareness(unittest.TestCase):
    """Commands that differ between Legacy and NG."""

    def test_meteor_shower_ng(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json",
                                version=NightshadeVersion.NG)
        b.meteor_shower(rate=100, duration=5, shower_name="Perseids")
        output = b.build()
        self.assertIn("meteors ra 46.0 dec 58.0", output)
        self.assertIn("meteors zhr 100", output)
        self.assertNotIn("meteors rate", output)

    def test_meteor_shower_legacy(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json",
                                version=NightshadeVersion.LEGACY)
        b.meteor_shower(rate=100, duration=5, shower_name="Perseids")
        output = b.build()
        self.assertIn("meteors rate 100", output)
        self.assertNotIn("meteors zhr", output)

    def test_reset_video_stop_ng(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json",
                                version=NightshadeVersion.NG)
        b.reset_to_default()
        self.assertIn("video action stop", b.build())

    def test_reset_video_stop_legacy(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json",
                                version=NightshadeVersion.LEGACY)
        b.reset_to_default()
        self.assertIn("external_viewer action stop", b.build())


class TestResetToDefault(unittest.TestCase):

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_reset_clears_state(self):
        self.b.flag("atmosphere", False)
        self.b.timerate(999)
        self.b.reset_to_default()
        # After reset, state should reflect defaults
        self.assertEqual(self.b.state["timerate"], 1)
        self.assertEqual(self.b.state["fov"], 180)
        self.assertFalse(self.b.state["tracking"])
        self.assertEqual(self.b.state["home_planet"], "Earth")

    def test_reset_emits_required_commands(self):
        self.b.reset_to_default()
        output = self.b.build()
        self.assertIn("image action drop", output)
        self.assertIn("audio action drop", output)
        self.assertIn("deselect", output)
        self.assertIn('set home_planet "Earth"', output)
        self.assertIn("date load current", output)
        self.assertIn("timerate rate 1", output)


class TestInitBlock(unittest.TestCase):

    def test_init_block_contains_reset(self):
        b = StratoScriptBuilder(location_file="__nonexistent__.json")
        b.init_block()
        output = b.build()
        self.assertIn("clear", output)
        self.assertIn("=== Initialization Block ===", output)
        self.assertIn("=== COMPREHENSIVE RESET ===", output)
        self.assertIn("=== End Init ===", output)


class TestDateHandling(unittest.TestCase):

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_set_date_datetime(self):
        dt = datetime.datetime(2024, 4, 8, 12, 0, 0)
        self.b.set_date(dt)
        self.assertIn('date local "2024-04-08T12:00:00"', self.b.build())

    def test_set_date_utc(self):
        dt = datetime.datetime(2024, 4, 8, 18, 0, 0)
        self.b.set_date(dt, use_utc=True)
        self.assertIn('date utc "2024-04-08T18:00:00"', self.b.build())

    def test_set_date_string(self):
        self.b.set_date("2024-04-08T12:00:00")
        self.assertIn('date local "2024-04-08T12:00:00"', self.b.build())


class TestConstellations(unittest.TestCase):

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_constellations_show(self):
        self.b.constellations(show=True, art=True)
        output = self.b.build()
        self.assertIn("flag constellation_lines on", output)
        self.assertIn("flag constellation_names on", output)
        self.assertIn("flag constellation_art on", output)

    def test_constellations_hide(self):
        self.b.constellations(show=False)
        output = self.b.build()
        self.assertIn("flag constellation_lines off", output)
        self.assertIn("flag constellation_art off", output)


class TestMediaCommands(unittest.TestCase):

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_image_load(self):
        self.b.queue_image("slide.png", "my_slide", action="load")
        self.assertIn('image action load filename "slide.png"', self.b.build())
        self.assertIn("my_slide", self.b.state["images_loaded"])

    def test_image_drop(self):
        self.b.state["images_loaded"].add("x")
        self.b.image_drop("x")
        self.assertNotIn("x", self.b.state["images_loaded"])

    def test_drop_all_images(self):
        self.b.state["images_loaded"] = {"a", "b", "c"}
        self.b.drop_all_images()
        self.assertEqual(len(self.b.state["images_loaded"]), 0)

    def test_queue_sound(self):
        self.b.queue_sound("narration.ogg", action="play", volume=0.8)
        self.assertIn('audio action play filename "narration.ogg"', self.b.build())


class TestFadeTransitions(unittest.TestCase):

    def setUp(self):
        self.b = StratoScriptBuilder(location_file="__nonexistent__.json")

    def test_fade_to_and_from_black(self):
        self.b.fade_to_black(duration=1)
        self.b.fade_from_black(duration=1)
        output = self.b.build()
        self.assertIn("black.png", output)
        self.assertIn("alpha 1", output)
        self.assertIn("alpha 0", output)


class TestLocationLoading(unittest.TestCase):

    def test_loads_real_file(self):
        loc_file = os.path.join(os.path.dirname(__file__), "..", "location.json")
        if os.path.exists(loc_file):
            b = StratoScriptBuilder(location_file=loc_file)
            self.assertAlmostEqual(b.location_data["latitude"], 36.53, places=0)

    def test_missing_file_returns_empty(self):
        b = StratoScriptBuilder(location_file="__does_not_exist__.json")
        self.assertEqual(b.location_data, {})


if __name__ == "__main__":
    unittest.main()
