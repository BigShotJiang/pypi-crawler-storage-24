"""
Unit tests for the version compatibility system.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pytshade.version import NightshadeVersion, get_profile, VERSION_PROFILES


class TestNightshadeVersion(unittest.TestCase):

    def test_enum_values(self):
        self.assertEqual(NightshadeVersion.LEGACY.value, "legacy")
        self.assertEqual(NightshadeVersion.NG.value, "ng")

    def test_profiles_exist_for_all_versions(self):
        for v in NightshadeVersion:
            profile = get_profile(v)
            self.assertIsInstance(profile, dict)

    def test_ng_profile_keys(self):
        p = get_profile(NightshadeVersion.NG)
        self.assertEqual(p["meteor_syntax"], "radiant")
        self.assertEqual(p["video_command"], "video")
        self.assertTrue(p["slerp_movement"])
        self.assertEqual(p["max_pan_angle"], 170)

    def test_legacy_profile_keys(self):
        p = get_profile(NightshadeVersion.LEGACY)
        self.assertEqual(p["meteor_syntax"], "rate")
        self.assertEqual(p["video_command"], "external_viewer")
        self.assertFalse(p["slerp_movement"])
        self.assertEqual(p["max_pan_angle"], 360)


if __name__ == "__main__":
    unittest.main()
