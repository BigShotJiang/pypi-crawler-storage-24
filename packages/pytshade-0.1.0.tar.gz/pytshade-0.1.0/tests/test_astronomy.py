"""
Unit tests for AstroHelper.
"""

import datetime
import math
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pytshade.astronomy import AstroHelper, HAS_EPHEM


@unittest.skipUnless(HAS_EPHEM, "pyephem not installed")
class TestAstroHelper(unittest.TestCase):
    """Tests that require the ephem library."""

    def setUp(self):
        # Clarksville, TN
        self.astro = AstroHelper(lat="36.53", lon="-87.35", elevation=155)

    def test_sun_is_visible_during_day(self):
        noon = datetime.datetime(2024, 6, 21, 17, 0, 0)  # ~noon UTC for CDT
        self.assertTrue(self.astro.is_visible("Sun", noon))

    def test_sun_not_visible_at_night(self):
        midnight_utc = datetime.datetime(2024, 6, 22, 5, 0, 0)  # ~midnight CDT
        self.assertFalse(self.astro.is_visible("Sun", midnight_utc))

    def test_get_sun_pos_returns_tuple(self):
        dt = datetime.datetime(2024, 6, 21, 17, 0, 0)
        alt, az = self.astro.get_sun_pos(dt)
        # Should be float-like ephem.Angle values
        self.assertIsNotNone(alt)
        self.assertIsNotNone(az)

    def test_get_moon_phase_range(self):
        dt = datetime.datetime(2024, 1, 15, 12, 0, 0)
        phase = self.astro.get_moon_phase(dt)
        self.assertGreaterEqual(phase, 0.0)
        self.assertLessEqual(phase, 1.0)

    def test_find_good_moon_time_returns_datetime(self):
        start = datetime.datetime(2024, 6, 1, 12, 0, 0)
        result = self.astro.find_good_moon_time(start_date=start, min_phase=0.4)
        self.assertIsInstance(result, datetime.datetime)

    def test_get_eclipse_params_known(self):
        # Should return the 2024 eclipse near Dallas
        near = datetime.datetime(2024, 4, 8, 12, 0, 0)
        dt, lat, lon = self.astro.get_eclipse_params(near, mode="total")
        self.assertEqual(dt.year, 2024)
        self.assertAlmostEqual(lat, 32.77, places=1)

    def test_get_eclipse_params_partial_offset(self):
        near = datetime.datetime(2024, 4, 8, 12, 0, 0)
        dt, lat, lon = self.astro.get_eclipse_params(near, mode="partial")
        # Partial offsets lat by +10
        self.assertAlmostEqual(lat, 42.77, places=1)

    def test_get_body_size_positive(self):
        dt = datetime.datetime(2024, 6, 21, 17, 0, 0)
        size = self.astro.get_body_size("Moon", dt)
        self.assertGreater(size, 0)

    def test_unknown_body_assumed_visible(self):
        dt = datetime.datetime(2024, 6, 21, 17, 0, 0)
        # Unknown body should return True (visible)
        self.assertTrue(self.astro.is_visible("FakeBody", dt))

    def test_is_visible_all_planets(self):
        dt = datetime.datetime(2024, 6, 21, 17, 0, 0)
        for body in ("Sun", "Moon", "Mars", "Jupiter", "Saturn",
                      "Venus", "Mercury", "Uranus", "Neptune"):
            # Should not raise, just return bool
            result = self.astro.is_visible(body, dt)
            self.assertIsInstance(result, bool)


class TestAstroHelperNoEphem(unittest.TestCase):
    """Verify graceful fallbacks when ephem is missing."""

    def test_fallback_phase(self):
        # Even without ephem the class should be importable
        astro = AstroHelper.__new__(AstroHelper)
        astro.observer = None
        # Bypass __init__ to simulate missing ephem
        from pytshade import astronomy
        old = astronomy.HAS_EPHEM
        try:
            astronomy.HAS_EPHEM = False
            p = astro.get_moon_phase(datetime.datetime.now())
            self.assertEqual(p, 0.5)
        finally:
            astronomy.HAS_EPHEM = old


if __name__ == "__main__":
    unittest.main()
