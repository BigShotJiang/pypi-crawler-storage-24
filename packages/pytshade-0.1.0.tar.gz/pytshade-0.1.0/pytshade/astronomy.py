"""True module alias for the public pytshade.astronomy path."""

import sys

from digitalis_scripts import astronomy as _astronomy

sys.modules[__name__] = _astronomy
