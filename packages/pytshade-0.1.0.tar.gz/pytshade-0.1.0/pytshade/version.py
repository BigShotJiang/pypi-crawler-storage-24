"""True module alias for the public pytshade.version path."""

import sys

from digitalis_scripts import version as _version

sys.modules[__name__] = _version
