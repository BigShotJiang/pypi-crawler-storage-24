"""True module alias for the public pytshade.builder path."""

import sys

from digitalis_scripts import builder as _builder

sys.modules[__name__] = _builder
