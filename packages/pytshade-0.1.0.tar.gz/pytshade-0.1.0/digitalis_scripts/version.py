"""
Nightshade version definitions and compatibility profiles.

Defines the command syntax differences between Nightshade versions so that
StratoScriptBuilder can generate correct output for each target platform.
"""

from enum import Enum
from typing import Dict, Any


class NightshadeVersion(Enum):
    """Supported Nightshade versions."""
    LEGACY = "legacy"   # Nightshade Legacy 11.12.1 (Stellarium 0.8.2 fork)
    NG = "ng"           # Nightshade NG (Next Generation) on OP3


# Capability/behavior profiles for each version
VERSION_PROFILES: Dict[NightshadeVersion, Dict[str, Any]] = {
    NightshadeVersion.LEGACY: {
        # Meteor syntax: simple rate-based
        "meteor_syntax": "rate",           # meteors rate <n>
        # Video playback command
        "video_command": "external_viewer", # external_viewer action play ...
        # Movement uses linear interpolation — no shortest-path issues
        "slerp_movement": False,
        # Max safe pan angle before needing waypoints (not needed for Legacy)
        "max_pan_angle": 360,
        # Date command supports same format
        "date_format": "iso",
        # Coordinate systems available for images/video
        "video_coordinate_systems": ["viewport"],
        # Description for documentation
        "description": "Nightshade Legacy 11.12.1 (Stellarium 0.8.2 fork)",
    },
    NightshadeVersion.NG: {
        # Meteor syntax: radiant-based with RA/Dec + ZHR
        "meteor_syntax": "radiant",        # meteors ra <deg> dec <deg> + meteors zhr <n>
        # Video playback command
        "video_command": "video",           # video action play ...
        # Movement uses SLERP shortest path
        "slerp_movement": True,
        # Max safe pan angle before needing waypoints
        "max_pan_angle": 170,
        # Date command format
        "date_format": "iso",
        # Coordinate systems available for images/video
        "video_coordinate_systems": ["viewport", "dome", "j2000"],
        # Description
        "description": "Nightshade NG (Next Generation) on Digitarium OP3",
    },
}


def get_profile(version: NightshadeVersion) -> Dict[str, Any]:
    """Return the capability profile for a given Nightshade version."""
    return VERSION_PROFILES[version]
