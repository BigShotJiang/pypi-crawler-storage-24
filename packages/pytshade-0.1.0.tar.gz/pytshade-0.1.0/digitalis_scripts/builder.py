"""
StratoScriptBuilder — core command generator for Nightshade planetarium scripts.

Maintains shadow state tracking and emits StratoScript (.sts) commands via a
Builder-pattern API.  Call methods to accumulate commands, then ``build()`` or
``save()`` to produce the final script text.
"""

import json
import logging
import os
from typing import Optional, List, Union, Dict, Any
import datetime

from .version import NightshadeVersion, get_profile

# Try to import AstroHelper for type hinting, but don't fail if not present
try:
    from .astronomy import AstroHelper
except ImportError:
    AstroHelper = Any

logger = logging.getLogger(__name__)

# Valid flag names accepted by Nightshade (union of Legacy + NG)
VALID_FLAGS = frozenset({
    "atmosphere", "landscape", "cardinal_points",
    "planet_names", "constellation_lines", "constellation_names",
    "constellation_art", "meteors", "object_trails", "planet_orbits",
    "equatorial_grid", "azimuthal_grid", "ecliptic_line", "milky_way",
    "nebulae", "show_tui_datetime", "show_tui_short_obj_info",
    "track_object", "star_names", "nebula_names",
    "moon_scaled", "sun_scaled", "planets_scaled",
    "constellation_boundaries", "meridian_line",
    "galactic_grid", "stars", "star_twinkle",
    "manual_zoom",
})

# Planets that Nightshade recognises for selection / flyto
VALID_PLANETS = frozenset({
    "Sun", "Mercury", "Venus", "Earth", "Moon", "Mars",
    "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto",
    "Solar System Observer",
})


class StratoScriptBuilder:
    """Generate StratoScript (.sts) files for Nightshade Legacy or NG."""

    def __init__(self, location_file: str = "location.json",
                 version: NightshadeVersion = NightshadeVersion.NG):
        self.commands: List[str] = []
        self.indent_level = 0
        self.version = version
        self.profile = get_profile(version)
        self.location_data = self._load_location(location_file)
        
        # State tracking
        self.state = {
            "flags": {},
            "timerate": None,
            "fov": None,
            "selected_object": None,
            "tracking": False,
            "home_planet": None,
            "azimuth": 180.0,
            "altitude": 0.0,
            "landscape": None,
            "images_loaded": set()
        }

    def _load_location(self, file_path: str) -> Dict[str, Any]:
        """Load observer location from a JSON config file."""
        try:
            if not os.path.exists(file_path):
                if os.path.exists(os.path.join(os.getcwd(), file_path)):
                    file_path = os.path.join(os.getcwd(), file_path)
            
            with open(file_path, 'r') as f:
                data = json.load(f)
            logger.debug("Loaded location from %s", file_path)
            return data
        except Exception as e:
            logger.warning("Could not load %s: %s. Using defaults.", file_path, e)
            return {}

    def _add(self, command: str):
        """Add a raw command to the script."""
        indent = "  " * self.indent_level
        self.commands.append(f"{indent}{command}")

    def comment(self, text: str):
        """Add a comment."""
        self._add(f"# {text}")

    def raw_command(self, command: str):
        """Add a raw command string."""
        self._add(command)

    def build(self) -> str:
        """Return the complete script as a string."""
        return "\n".join(self.commands)

    def save(self, filename: str):
        """Save the script to a file."""
        with open(filename, 'w') as f:
            f.write(self.build())

    # --- Basic Commands ---

    def wait(self, duration: float):
        """Pauses the script for *duration* seconds (must be >= 0)."""
        if duration < 0:
            raise ValueError(f"wait duration must be >= 0, got {duration}")
        self._add(f"wait duration {duration}")

    def clear(self):
        """Clears the script queue (usually used at start)."""
        self._add("clear")

    def flag(self, name: str, status: bool, force: bool = False):
        """Sets a flag on or off.

        Raises ``ValueError`` if *name* is not a recognised Nightshade flag.
        Skips the command when the shadow state already matches unless *force*
        is ``True``.
        """
        if name not in VALID_FLAGS:
            raise ValueError(
                f"Unknown flag '{name}'. Valid flags: "
                + ", ".join(sorted(VALID_FLAGS))
            )

        if not force and self.state["flags"].get(name) == status:
            return  # Skip redundant command
            
        val = "on" if status else "off"
        self._add(f"flag {name} {val}")
        self.state["flags"][name] = status

    def set_home_planet(self, name: str, duration: float = 0):
        """Sets the home planet."""
        # Always set home planet as it might change view even if same planet
        cmd = f"set home_planet \"{name}\""
        if duration > 0:
            cmd += f" duration {duration}"
        self._add(cmd)
        self.state["home_planet"] = name

    def select_planet(self, name: str, pointer: bool = False):
        """Selects a planet.

        Raises ``ValueError`` if *name* is not a recognised planet/body.
        """
        if name not in VALID_PLANETS:
            logger.warning("Selecting unrecognised body '%s' — may fail at runtime.", name)
        ptr = "on" if pointer else "off"
        self._add(f"select planet {name} pointer {ptr}")
        self.state["selected_object"] = name

    def timerate(self, rate: float, force: bool = False):
        """Sets the time flow rate."""
        if not force and self.state["timerate"] == rate:
            return
            
        self._add(f"timerate rate {rate}")
        self.state["timerate"] = rate

    def zoom(self, fov: float, duration: float = 0, force: bool = False):
        """Zooms to a specific Field of View (FOV).

        *fov* is clamped to 0.001 – 180.
        """
        fov = max(0.001, min(180.0, fov))

        if not force and self.state["fov"] == fov:
            return
            
        cmd = f"zoom fov {fov}"
        if duration > 0:
            cmd += f" duration {duration}"
        self._add(cmd)
        self.state["fov"] = fov

    def zoom_auto(self, direction: str = "out"):
        """Zoom auto in/out - lets the engine determine the FOV."""
        self._add(f"zoom auto {direction}")
        self.state["fov"] = None  # Unknown after auto zoom

    # --- Selection ---

    def select(self, object_type: str, name: str, pointer: bool = False):
        """
        Selects an object by type and name.
        Types: planet, nebula, star, constellation
        """
        ptr = "on" if pointer else "off"
        self._add(f"select {object_type} {name} pointer {ptr}")
        self.state["selected_object"] = name

    def select_hp(self, hp_number: int, pointer: bool = False):
        """Selects a star by Hipparcos catalog number."""
        ptr = "on" if pointer else "off"
        self._add(f"select hp {hp_number} pointer {ptr}")
        self.state["selected_object"] = f"HP{hp_number}"

    def deselect(self):
        """Clears the current selection."""
        self._add("deselect")
        self.state["selected_object"] = None

    # --- Movement ---

    def look_at(self, target: str, duration: float = 2):
        """Points the camera at a target."""
        self.select_planet(target, pointer=False)
        self.flag("track_object", True)
        self.state["tracking"] = True
        self.wait(duration)

    def set_view(self, az: float, alt: float, duration: float = 2):
        """Sets the camera view direction (Azimuth/Altitude)."""
        self._add(f"moveto azi {az} alt {alt} duration {duration}")
        self.state["azimuth"] = az
        self.state["altitude"] = alt

    def flyto(self, object_name: str):
        """
        Fly to an object (interplanetary travel).
        Implicitly selects and tracks the object.
        """
        self._add(f"flyto {object_name}")
        self.state["selected_object"] = object_name
        self.state["tracking"] = True

    def set_location(self, lat: float, lon: float, alt: float = 0):
        """Sets the observer's geographic location without animation."""
        self._add(f"location lat {lat} lon {lon} alt {alt}")

    # --- Landscape ---

    def landscape(self, name: str):
        """
        Loads a landscape by name/ID.
        The landscape must exist in the landscapes directory.
        """
        self._add(f'landscape name {name}')
        self.state["landscape"] = name

    # --- Grid Overlays ---

    def equatorial_grid(self, show: bool = True):
        """Toggle the RA/Dec equatorial grid."""
        self.flag("equatorial_grid", show)

    def azimuthal_grid(self, show: bool = True):
        """Toggle the Alt/Az azimuthal grid."""
        self.flag("azimuthal_grid", show)

    def ecliptic_line(self, show: bool = True):
        """Toggle the ecliptic line."""
        self.flag("ecliptic_line", show)

    def meridian_line(self, show: bool = True):
        """Toggle the meridian line."""
        self.flag("meridian_line", show)

    # --- Media (Images/Audio) ---

    def queue_image(self, filename: str, name: str, action: str = "show", x: float = 0, y: float = 0, scale: float = 1.0, duration: float = 0, alpha: float = 1.0, coordinate_system: str = "dome", altitude: float = 90, azimuth: float = 0):
        """
        Queues an image command.
        
        coordinate_system options:
        - 'dome': Fixed to the screen (good for titles/HUDs)
        - 'equatorial': Fixed to the celestial sphere (moves with stars)
        - 'altaz': Fixed to the local horizon (moves with landscape)
        """
        if action == "load":
            cmd = f'image action load filename "{filename}" name "{name}"'
            cmd += f" alpha {alpha} scale {scale} coordinate_system {coordinate_system}"
            if coordinate_system in ("altaz", "dome"):
                cmd += f" altitude {altitude} azimuth {azimuth}"
            self._add(cmd)
            self.state["images_loaded"].add(name)
        elif action == "show":
            cmd = f'image name "{name}" alpha {alpha}'
            if duration > 0:
                cmd += f" duration {duration}"
            self._add(cmd)
        elif action == "hide":
            cmd = f'image name "{name}" alpha 0'
            if duration > 0:
                cmd += f" duration {duration}"
            self._add(cmd)
        elif action == "drop":
            self._add(f'image action drop name "{name}"')
            self.state["images_loaded"].discard(name)

    def image_fade_in(self, name: str, duration: float = 2):
        """Fade an already-loaded image in."""
        self._add(f'image name "{name}" alpha 1 duration {duration}')

    def image_fade_out(self, name: str, duration: float = 2):
        """Fade an image out."""
        self._add(f'image name "{name}" alpha 0 duration {duration}')

    def image_drop(self, name: str):
        """Remove an image from memory."""
        self._add(f'image action drop name "{name}"')
        self.state["images_loaded"].discard(name)

    def drop_all_images(self):
        """Drop all loaded images from memory."""
        for name in list(self.state["images_loaded"]):
            self.image_drop(name)

    def queue_sound(self, filename: str, action: str = "play", volume: float = 1.0):
        """
        Queues a sound command.
        """
        cmd = f'audio action {action} filename "{filename}"'
        if action == "play":
            cmd += f" volume {volume}"
        self._add(cmd)

    def play_video(self, filename: str, name: str, duration: float,
                   coordinate_system: str = "viewport", xpos: float = 0.5, ypos: float = 0.5,
                   scale: float = 1.0, alpha: float = 1.0):
        """Play a video file.

        On **NG** targets this uses the ``video`` command with full
        coordinate-system support.  On **Legacy** targets it falls back to the
        ``external_viewer`` command (viewport-only).
        """
        self.comment(f"Playing video: {filename}")

        video_cmd = self.profile["video_command"]

        if video_cmd == "video":
            # Nightshade NG
            if coordinate_system == "viewport":
                pos_cmd = f"xpos {xpos} ypos {ypos}"
            else:
                pos_cmd = f"azimuth {xpos} altitude {ypos}"
            self._add(f'video action play filename "{filename}" name "{name}" '
                      f'{pos_cmd} scale {scale} alpha {alpha} '
                      f'coordinate_system {coordinate_system}')
        else:
            # Nightshade Legacy — external_viewer
            self._add(f'external_viewer action play filename "{filename}"')

        self.wait(duration)

        if video_cmd == "video":
            self._add(f'video action stop name "{name}"')
        else:
            self._add('external_viewer action stop')

    # --- Advanced Features ---

    def reset_to_default(self):
        """
        Comprehensive reset to default state.
        This should bring the system to a known, clean state regardless of what ran before.
        """
        self.comment("=== COMPREHENSIVE RESET ===")
        
        # Force reset internal state tracking
        self.state = {
            "flags": {},
            "timerate": None,
            "fov": None,
            "selected_object": None,
            "tracking": False,
            "home_planet": None,
            "azimuth": 180.0,
            "altitude": 45.0,
            "landscape": None,
            "images_loaded": set()
        }
        
        lat = self.location_data.get('latitude', 36.53)
        lon = self.location_data.get('longitude', -87.35)
        alt = self.location_data.get('altitude', 155)
        
        # 1. Stop all media first
        self._add("image action drop")  # Drop ALL images
        if self.profile["video_command"] == "video":
            self._add("video action stop")  # NG
        else:
            self._add("external_viewer action stop")  # Legacy
        self._add("audio action drop")  # Stop any audio
        
        # 2. Deselect and stop tracking
        self._add("flag track_object off")
        self._add("deselect")
        self.state["tracking"] = False
        self.state["selected_object"] = None
        
        # 3. Set Home Planet to Earth
        self._add('set home_planet "Earth"')
        self.state["home_planet"] = "Earth"
        self.wait(0.5)  # Wait for planet to load
        
        # 4. Set geographic Location
        self._add(f"moveto lat {lat} lon {lon} alt {alt} duration 2")
        self.wait(2)  # Wait for move to complete
        
        # 5. Reset ALL flags explicitly with force (don't use helper to avoid state check)
        flags_on = ["atmosphere", "landscape", "cardinal_points"]
        flags_off = [
            "planet_names", "constellation_lines", "constellation_names",
            "constellation_art", "meteors", "object_trails", "planet_orbits",
            "equatorial_grid", "azimuthal_grid", "ecliptic_line", "milky_way",
            "nebulae", "show_tui_datetime", "show_tui_short_obj_info"
        ]
        
        for f in flags_on:
            self._add(f"flag {f} on")
            self.state["flags"][f] = True
        for f in flags_off:
            self._add(f"flag {f} off")
            self.state["flags"][f] = False
        
        # 6. Reset view direction (look South at comfortable angle)
        self._add("moveto azi 180 alt 45 duration 2")
        self.state["azimuth"] = 180.0
        self.state["altitude"] = 45.0
        self.wait(2)
        
        # 7. Reset FOV to wide dome view
        self._add("zoom fov 180 duration 2")
        self.state["fov"] = 180
        self.wait(2)
        
        # 8. Reset time to current system time and normal rate
        self._add("date load current")
        self._add("timerate rate 1")
        self.state["timerate"] = 1
        
        self.comment("=== RESET COMPLETE ===")

    def set_date(self, date_obj: Union[datetime.datetime, str], use_utc: bool = False):
        """Sets the date. Defaults to local time unless use_utc is True."""
        if isinstance(date_obj, datetime.datetime):
            # Format: YYYY-MM-DDTHH:MM:SS
            date_str = date_obj.strftime("%Y-%m-%dT%H:%M:%S")
        else:
            date_str = date_obj
            
        mode = "utc" if use_utc else "local"
        self._add(f'date {mode} "{date_str}"')

    def smart_move(self, target_date: datetime.datetime, target_body: Optional[str] = None, duration: float = 2, use_utc: bool = False):
        """
        Moves time first, then angles.
        """
        self.comment(f"Smart move to {target_date} ({'UTC' if use_utc else 'Local'}) looking at {target_body}")
        
        # 1. Stop time
        self.timerate(0)
        
        # 2. Turn off tracking to prevent whip-around
        if self.state["tracking"]:
            self.flag("track_object", False)
            self.state["tracking"] = False
        
        # 3. Move time
        self.set_date(target_date, use_utc=use_utc)
        self.wait(0.5) # Brief pause to let sky settle
        
        # 4. Move view if target provided
        if target_body:
            self.look_at(target_body, duration)
        
        # 4. Resume time (optional, maybe user wants it paused)
        # self.timerate(1) 

    def constellations(self, show: bool = True, art: bool = False):
        """Toggle constellations."""
        self.flag("constellation_lines", show)
        self.flag("constellation_names", show)
        
        if show:
            # Only turn on art if requested
            if art:
                self.flag("constellation_art", True)
        else:
            # Always turn off art when hiding constellations
            self.flag("constellation_art", False)

    def meteor_shower(self, rate: int = 10, duration: float = 10, shower_name: Optional[str] = None):
        """Simulates a meteor shower.

        On **NG** targets, *shower_name* sets an accurate radiant via RA/Dec
        and *rate* maps to ZHR.  On **Legacy** targets the simple ``meteors
        rate`` syntax is used and *shower_name* is ignored.

        Available showers (NG only): Perseids, Geminids, Leonids,
        Quadrantids, Orionids.
        """
        self.comment(f"Meteor shower: rate {rate}")
        
        # Meteor shower radiant data (RA, Dec in degrees)
        showers = {
            "Perseids": (46.0, 58.0),
            "Geminids": (112.0, 33.0),
            "Leonids": (153.0, 22.0),
            "Quadrantids": (230.0, 49.0),
            "Orionids": (95.0, 16.0),
        }
        
        if self.profile["meteor_syntax"] == "radiant":
            # Nightshade NG: radiant-based
            if shower_name and shower_name in showers:
                ra, dec = showers[shower_name]
                self._add(f"meteors ra {ra} dec {dec}")
            self._add(f"meteors zhr {rate}")
        else:
            # Nightshade Legacy: simple rate
            self._add(f"meteors rate {rate}")
        
        self.flag("meteors", True)
        self.wait(duration)
        self.flag("meteors", False)

    def pan_to(self, target_az: float, target_alt: float, duration: float = 5.0):
        """Pan the camera view.

        On NG targets (which use SLERP), pans larger than the version's
        ``max_pan_angle`` (170°) are split into intermediate waypoints to
        force the desired direction.  Legacy targets interpolate linearly so
        no splitting is needed.
        """
        current_az = self.state.get("azimuth", 180.0)
        
        diff = target_az - current_az
        
        # Normalize diff to -180 to 180
        while diff <= -180: diff += 360
        while diff > 180: diff -= 360
        
        max_angle = self.profile["max_pan_angle"]

        if abs(diff) > max_angle:
            mid_az = (current_az + target_az) / 2
            half_dur = duration / 2
            self._add(f"moveto azi {mid_az} alt {target_alt} duration {half_dur}")
            self._add(f"wait duration {half_dur}")
            self._add(f"moveto azi {target_az} alt {target_alt} duration {half_dur}")
        else:
            self._add(f"moveto azi {target_az} alt {target_alt} duration {duration}")
            
        self.state["azimuth"] = target_az
        self.state["altitude"] = target_alt

    def create_analemma(self, start_date: datetime.datetime, interval_days: int = 7, steps: int = 52, astro_helper: Optional[Any] = None):
        """
        Creates an analemma visualization.
        """
        self.comment("Generating Analemma")
        
        # 1. Setup Environment
        self.flag("atmosphere", True, force=True) 
        self.flag("landscape", True, force=True)
        self.flag("cardinal_points", True, force=True)
        self.flag("constellation_lines", False, force=True)
        self.flag("constellation_names", False, force=True)
        self.flag("planet_names", False, force=True)
        
        # 2. Position Camera
        # Calculate Sun position for the EQUINOX (approx center of analemma)
        # This ensures the figure-8 is centered in the view, rather than the start point.
        target_alt = 45.0
        target_az = 180.0
        
        if astro_helper:
            try:
                import math
                # Use March 21st (Equinox) of the same year for centering
                # Handle potential leap year issues if start_date was Feb 29 (unlikely but possible)
                year = start_date.year
                center_date = start_date.replace(year=year, month=3, day=21)
                
                # Estimate Timezone offset from Longitude to convert Local -> UTC for PyEphem
                # PyEphem expects UTC. start_date is Local.
                # Offset = Lon / 15.0 (approx)
                lon = self.location_data.get('longitude', 0)
                offset_hours = lon / 15.0
                center_date_utc = center_date - datetime.timedelta(hours=offset_hours)
                
                # get_sun_pos returns radians (Alt, Az)
                alt_rad, az_rad = astro_helper.get_sun_pos(center_date_utc)
                target_alt = math.degrees(alt_rad)
                target_az = math.degrees(az_rad)
                self.comment(f"Calculated Center Sun Pos (Equinox): Alt {target_alt:.2f}, Az {target_az:.2f} (UTC est: {center_date_utc})")
            except Exception as e:
                self.comment(f"Error calculating sun pos: {e}")

        # Use set_view to look at the target WITHOUT moving the observer location
        self.set_view(az=target_az, alt=target_alt, duration=2)
        
        # Move time to start date
        self.set_date(start_date)
        self.wait(1)

        # Removed zoom to keep wide field of view as requested
        # self.zoom(fov=100, duration=2) 
        
        # 3. Select Sun for trails, but DO NOT TRACK
        self.select_planet("Sun", pointer=False)
        self.flag("track_object", False, force=True)
        self.state["tracking"] = False
        
        # 4. Enable Trails
        self.flag("object_trails", True, force=True) 
        
        # 5. The Loop
        current_date = start_date
        for i in range(steps):
            self.set_date(current_date)
            self.wait(0.2) 
            current_date += datetime.timedelta(days=interval_days)
            
        # 6. Cleanup
        self.flag("object_trails", False, force=True)
        self.zoom(fov=180, duration=2) # Reset Zoom

    # --- Scene Transitions ---

    def fade_to_black(self, duration: float = 2, image_name: str = "_fade_black"):
        """
        Fade the screen to black using a full-dome image overlay.
        Useful for smooth transitions between scenes.
        """
        # Load a black image at zenith covering the dome
        self._add(f'image action load filename "black.png" name "{image_name}" alpha 0 scale 180 coordinate_system dome altitude 90 azimuth 0')
        self.state["images_loaded"].add(image_name)
        self.image_fade_in(image_name, duration)
        self.wait(duration)

    def fade_from_black(self, duration: float = 2, image_name: str = "_fade_black"):
        """
        Fade from black back to the scene.
        """
        self.image_fade_out(image_name, duration)
        self.wait(duration)
        self.image_drop(image_name)

    def scene_transition(self, setup_func, fade_duration: float = 1.5):
        """
        Perform a fade-to-black transition, run setup, then fade back.
        setup_func should be a callable that takes the builder as argument.
        """
        self.fade_to_black(fade_duration)
        setup_func(self)
        self.fade_from_black(fade_duration)

    # --- Deep Sky Objects ---

    def select_nebula(self, name: str, pointer: bool = False):
        """
        Select a nebula/deep sky object by name.
        Examples: "M 42", "M31", "NGC 7000"
        """
        self.select("nebula", name, pointer)

    def select_star(self, name: str, pointer: bool = False):
        """
        Select a star by name.
        Examples: "Polaris", "Sirius", "Betelgeuse"
        """
        self.select("star", name, pointer)

    def select_constellation(self, name: str, pointer: bool = False):
        """
        Select a constellation by name.
        Examples: "Orion", "Ursa Major", "Cassiopeia"
        """
        self.select("constellation", name, pointer)

    # --- Labels and Annotations ---

    def star_names(self, show: bool = True):
        """Toggle star name labels."""
        self.flag("star_names", show)

    def nebula_names(self, show: bool = True):
        """Toggle nebula/DSO name labels."""
        self.flag("nebula_names", show)

    def moon_scaled(self, scaled: bool = True):
        """Toggle scaled moon (makes moon appear larger for visibility)."""
        self.flag("moon_scaled", scaled)

    def sun_scaled(self, scaled: bool = True):
        """Toggle scaled sun."""
        self.flag("sun_scaled", scaled)

    def planets_scaled(self, scaled: bool = True):
        """Toggle scaled planets (makes planets appear larger for visibility)."""
        self.flag("planets_scaled", scaled)

    # --- High-Level Helpers ---

    def init_block(self):
        """Standard initialization block for the start of any standalone script.

        Clears the command queue, waits briefly, then performs a full
        ``reset_to_default()`` to guarantee deterministic state.  Every
        standalone scene should call this first.
        """
        self.comment("=== Initialization Block ===")
        self.clear()
        self.wait(1)
        self.reset_to_default()
        self.wait(2)
        self.comment("=== End Init ===")

    def sunset(self, timerate_multiplier: float = 500, hours: float = 3):
        """Accelerate time to play a sunset animation.

        Jumps local time to 18:00 of the current date, then fast-forwards
        *hours* hours at *timerate_multiplier* speed.
        """
        self.set_date(datetime.datetime.now().replace(hour=18, minute=0, second=0))
        self.wait(1)
        self.timerate(timerate_multiplier)
        real_seconds = (hours * 3600) / timerate_multiplier
        self.wait(real_seconds)
        self.timerate(1)

