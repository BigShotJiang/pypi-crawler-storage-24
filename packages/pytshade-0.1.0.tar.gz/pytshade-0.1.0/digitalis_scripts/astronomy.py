"""
AstroHelper — PyEphem wrapper for astronomical calculations.

Provides visibility checks, sun/moon position queries, eclipse lookups,
and moon-phase scoring used by StratoScriptBuilder to generate
astronomically accurate planetarium scripts.
"""

import datetime
import logging
from typing import Any

logger = logging.getLogger(__name__)

try:
    import ephem
    HAS_EPHEM = True
except ImportError:
    HAS_EPHEM = False
    ephem = None  # type: ignore

class AstroHelper:
    def __init__(self, lat='36.53', lon='-87.35', elevation=155):
        self.observer = None
        if HAS_EPHEM:
            self.observer = ephem.Observer() # type: ignore
            self.observer.lat = str(lat)
            self.observer.lon = str(lon)
            self.observer.elevation = elevation

    def is_visible(self, body_name: str, date: datetime.datetime) -> bool:
        """Checks if a body is above the horizon at a given time."""
        if not HAS_EPHEM:
            logger.warning("pyephem not installed — assuming %s is visible.", body_name)
            return True
        
        assert self.observer is not None
        self.observer.date = date
        
        body = self._get_body(body_name)
        if not body:
            return True # Unknown body, assume visible or let script handle it
            
        body.compute(self.observer)
        return body.alt > 0

    def _get_body(self, name: str):
        if not HAS_EPHEM:
            return None
        assert ephem is not None
        e: Any = ephem
            
        name = name.lower()
        if name == 'sun': return e.Sun()
        if name == 'moon': return e.Moon()
        if name == 'mars': return e.Mars()
        if name == 'jupiter': return e.Jupiter()
        if name == 'saturn': return e.Saturn()
        if name == 'venus': return e.Venus()
        if name == 'mercury': return e.Mercury()
        if name == 'uranus': return e.Uranus()
        if name == 'neptune': return e.Neptune()
        if name == 'pluto': return e.readdb("Pluto,e,17.14175,113.76329,252.90589,238.92881,0.004191,0.000000,0,0,0,0")
        return None

    def get_sun_pos(self, date):
        if not HAS_EPHEM: return (0,0)
        assert ephem is not None
        assert self.observer is not None
        self.observer.date = date
        s = ephem.Sun() # type: ignore
        s.compute(self.observer)
        return (s.alt, s.az)

    def get_eclipse_params(self, near_date: datetime.datetime, mode: str = 'total'):
        """
        Returns (datetime, lat, lon) for an eclipse near the given date.
        Mode can be 'total' or 'partial'.
        
        Note: Calculating the exact path of totality using only PyEphem is complex/expensive.
        This function uses a lookup of known major eclipses or defaults to current location
        if no known eclipse is found nearby.
        """
        # Known eclipses (Date, Lat, Lon of Totality)
        # Dates are UTC
        known_eclipses = [
            (datetime.datetime(2017, 8, 21, 18, 25), 36.97, -87.48), # Hopkinsville, KY
            (datetime.datetime(2024, 4, 8, 18, 40), 32.77, -96.79),  # Dallas, TX
            (datetime.datetime(2045, 8, 12, 17, 0), 39.0, -105.0),   # Colorado (Future)
        ]
        
        target_eclipse = None
        min_diff = datetime.timedelta(days=365)
        
        # Find nearest known eclipse
        for date, lat, lon in known_eclipses:
            diff = abs(date - near_date)
            if diff < min_diff:
                min_diff = diff
                target_eclipse = (date, lat, lon)
        
        if target_eclipse and min_diff < datetime.timedelta(days=30):
            date, lat, lon = target_eclipse
            if mode == 'partial':
                # Offset location to be in penumbra (e.g., +10 deg lat)
                return (date, lat + 10.0, lon)
            return (date, lat, lon)
            
        # If no known eclipse nearby, use PyEphem to find next one (time only)
        # and use current observer location (which might only see partial or nothing)
        if HAS_EPHEM:
            assert ephem is not None
            assert self.observer is not None
            self.observer.date = near_date
            try:
                # next_solar_eclipse is a function in the ephem module, not a method of observer
                # But sometimes it's not exported in types.
                next_date = ephem.next_solar_eclipse(self.observer.date) # type: ignore
                # Convert ephem date to python datetime
                py_date = next_date.datetime()
                
                # We don't know where it is total, so we return current location
                # This might result in no eclipse visible if it's on the other side of the world.
                # Note: observer.lat/lon are in radians in PyEphem
                import math
                lat_deg = math.degrees(self.observer.lat)
                lon_deg = math.degrees(self.observer.lon)
                return (py_date, lat_deg, lon_deg)
            except Exception as e:
                logger.error("Error finding next eclipse: %s", e)
                pass
                
        return (near_date, 0, 0) # Fallback

    def get_moon_phase(self, date: datetime.datetime) -> float:
        """
        Returns moon phase as a fraction (0 = new, 0.5 = first/last quarter, 1.0 = full).
        """
        if not HAS_EPHEM:
            return 0.5
        
        assert ephem is not None
        assert self.observer is not None
        self.observer.date = date
        moon = ephem.Moon()  # type: ignore
        moon.compute(self.observer)
        return moon.phase / 100.0  # phase is 0-100, convert to 0-1

    def find_good_moon_time(self, start_date: 'datetime.datetime | None' = None, min_phase: float = 0.4) -> datetime.datetime:
        """
        Find a date/time when the moon is:
        1. Above the horizon (visible)
        2. Has a good phase (at least min_phase illumination)
        3. Preferably at night
        
        Returns a datetime suitable for moon observation.
        """
        if start_date is None:
            start_date = datetime.datetime.now()
        
        if not HAS_EPHEM:
            # Fallback: just return midnight + 14 days (roughly full moon cycle)
            return start_date.replace(hour=22) + datetime.timedelta(days=14)
        
        assert ephem is not None
        assert self.observer is not None
        
        # Search forward in time for a good viewing opportunity
        # Check every 3 hours for the next 30 days
        best_time = None
        best_score = 0
        
        for days in range(30):
            for hour in [20, 21, 22, 23, 0, 1, 2, 3]:  # Night hours
                check_time = start_date.replace(hour=hour, minute=0, second=0) + datetime.timedelta(days=days)
                self.observer.date = check_time
                
                moon = ephem.Moon()  # type: ignore
                moon.compute(self.observer)
                sun = ephem.Sun()  # type: ignore
                sun.compute(self.observer)
                
                # Score: phase * altitude (if above horizon and sun is down)
                if moon.alt > 0 and sun.alt < -6:  # Moon up, civil twilight or darker
                    phase = moon.phase / 100.0
                    if phase >= min_phase:
                        import math
                        alt_deg = math.degrees(moon.alt)
                        score = phase * (alt_deg / 90.0)  # Higher alt = better
                        if score > best_score:
                            best_score = score
                            best_time = check_time
                            
                            # If we found a really good one (>80% phase, >30 deg alt), use it
                            if phase > 0.8 and alt_deg > 30:
                                return best_time
        
        if best_time:
            return best_time
        
        # Fallback: find next full moon
        self.observer.date = start_date
        next_full = ephem.next_full_moon(self.observer.date)  # type: ignore
        return next_full.datetime().replace(hour=22)

    def get_body_size(self, body_name: str, date: datetime.datetime) -> float:
        """Returns the angular diameter of the body in arcseconds."""
        if not HAS_EPHEM:
            return 0.0
        
        assert self.observer is not None
        self.observer.date = date
        body = self._get_body(body_name)
        if not body:
            return 0.0
            
        body.compute(self.observer)
        # PyEphem 'size' attribute is in arcseconds
        return float(body.size)
