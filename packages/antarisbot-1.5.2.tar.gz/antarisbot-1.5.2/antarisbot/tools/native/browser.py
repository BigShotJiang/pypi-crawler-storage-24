from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Optional

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class BrowserTool(NativeTool):
    def __init__(self, headless: bool = True, workspace_path: str = "/tmp"):
        self.headless = headless
        self.workspace_path = Path(workspace_path)
        self.browser = None
        self.page = None
        self._playwright = None

    @property
    def name(self) -> str:
        return "browser"

    @property
    def description(self) -> str:
        return "Browser automation using Playwright"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Browser action to perform",
                    "enum": ["navigate", "screenshot", "click", "type", "get_text"]
                },
                "url": {
                    "type": "string",
                    "description": "URL to navigate to (required for navigate action)"
                },
                "selector": {
                    "type": "string",
                    "description": "CSS selector (required for click, type, get_text actions)"
                },
                "text": {
                    "type": "string",
                    "description": "Text to type (required for type action)"
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in milliseconds (optional, default 10000)",
                    "default": 10000,
                    "minimum": 1000,
                    "maximum": 60000
                }
            },
            "required": ["action"]
        }

    async def _ensure_browser(self) -> tuple[bool, str]:
        """Ensure browser is initialized. Returns (success, error_message)."""
        if self.browser and self.page:
            return True, ""

        try:
            # Lazy import playwright
            from playwright.async_api import async_playwright
            
            if not self._playwright:
                self._playwright = await async_playwright().__aenter__()
            
            if not self.browser:
                self.browser = await self._playwright.chromium.launch(headless=self.headless)
            
            if not self.page:
                self.page = await self.browser.new_page()
            
            return True, ""

        except ImportError:
            return False, "Browser tool requires playwright. Install with: pip install playwright && playwright install chromium"
        except Exception as e:
            logger.exception("Failed to initialize browser")
            return False, f"Failed to initialize browser: {e}"

    async def _cleanup(self):
        """Clean up browser resources."""
        try:
            if self.page:
                await self.page.close()
                self.page = None
            
            if self.browser:
                await self.browser.close()
                self.browser = None
            
            if self._playwright:
                await self._playwright.__aexit__(None, None, None)
                self._playwright = None
        except Exception as e:
            logger.exception("Error during browser cleanup")

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._cleanup()

    async def execute(self, arguments: dict) -> ToolResult:
        action = arguments.get("action")
        url = arguments.get("url")
        selector = arguments.get("selector")
        text = arguments.get("text")
        timeout = arguments.get("timeout", 10000)

        if not action:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: action",
                is_error=True
            )

        # Ensure browser is initialized
        success, error = await self._ensure_browser()
        if not success:
            return ToolResult(
                success=False,
                content="",
                error=error,
                is_error=True
            )

        try:
            if action == "navigate":
                if not url:
                    return ToolResult(
                        success=False,
                        content="",
                        error="Navigate action requires url parameter",
                        is_error=True
                    )
                return await self._navigate(url, timeout)

            elif action == "screenshot":
                return await self._screenshot()

            elif action == "click":
                if not selector:
                    return ToolResult(
                        success=False,
                        content="",
                        error="Click action requires selector parameter",
                        is_error=True
                    )
                return await self._click(selector, timeout)

            elif action == "type":
                if not selector or text is None:
                    return ToolResult(
                        success=False,
                        content="",
                        error="Type action requires selector and text parameters",
                        is_error=True
                    )
                return await self._type(selector, text, timeout)

            elif action == "get_text":
                if not selector:
                    return ToolResult(
                        success=False,
                        content="",
                        error="get_text action requires selector parameter",
                        is_error=True
                    )
                return await self._get_text(selector, timeout)

            else:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Unknown action: {action}",
                    is_error=True
                )

        except Exception as e:
            logger.exception("Unexpected error in browser action")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )

    async def _navigate(self, url: str, timeout: int) -> ToolResult:
        """Navigate to URL and return page title and text content."""
        try:
            await self.page.goto(url, timeout=timeout)
            title = await self.page.title()
            
            # Get text content (first 5000 chars)
            text_content = await self.page.inner_text('body')
            if len(text_content) > 5000:
                text_content = text_content[:5000] + "\n\n[Content truncated...]"
            
            content = f"Title: {title}\n\nPage content:\n{text_content}"
            
            return ToolResult(
                success=True,
                content=content
            )

        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Navigation failed: {e}",
                is_error=True
            )

    async def _screenshot(self) -> ToolResult:
        """Take a screenshot and save to workspace."""
        try:
            timestamp = int(time.time())
            screenshot_dir = self.workspace_path / "screenshots"
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            screenshot_path = str(screenshot_dir / f"screenshot_{timestamp}.png")
            await self.page.screenshot(path=screenshot_path)
            return ToolResult(success=True, content=f"Screenshot saved to: {screenshot_path}")
        except Exception as e:
            return ToolResult(success=False, content="", error=f"Screenshot failed: {e}", is_error=True)

    async def _click(self, selector: str, timeout: int) -> ToolResult:
        """Click on element by CSS selector."""
        try:
            await self.page.click(selector, timeout=timeout)
            
            return ToolResult(
                success=True,
                content=f"Successfully clicked element: {selector}"
            )

        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Click failed: {e}",
                is_error=True
            )

    async def _type(self, selector: str, text: str, timeout: int) -> ToolResult:
        """Type text into element by CSS selector."""
        try:
            await self.page.fill(selector, text, timeout=timeout)
            
            return ToolResult(
                success=True,
                content=f"Successfully typed text into element: {selector}"
            )

        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Type failed: {e}",
                is_error=True
            )

    async def _get_text(self, selector: str, timeout: int) -> ToolResult:
        """Get text content from element by CSS selector."""
        try:
            element = await self.page.wait_for_selector(selector, timeout=timeout)
            if not element:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Element not found: {selector}",
                    is_error=True
                )
            
            text_content = await element.inner_text()
            
            return ToolResult(
                success=True,
                content=text_content
            )

        except Exception as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Get text failed: {e}",
                is_error=True
            )

    def __del__(self):
        """Cleanup when object is destroyed."""
        # Note: We can't use async cleanup in __del__, so this is best effort
        if self.browser or self.page or self._playwright:
            logger.warning("Browser tool destroyed without proper cleanup. Call _cleanup() before destroying.")