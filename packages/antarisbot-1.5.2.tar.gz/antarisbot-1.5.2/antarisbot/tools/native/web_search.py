from __future__ import annotations

import logging
from typing import Any, Dict, List

import httpx

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class WebSearchTool(NativeTool):
    def __init__(self, api_key: str):
        self.api_key = api_key

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return "Search the web using Brave Search API"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query string"
                },
                "count": {
                    "type": "integer",
                    "description": "Number of results to return (default 5, max 10)",
                    "default": 5,
                    "minimum": 1,
                    "maximum": 10
                }
            },
            "required": ["query"]
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self.api_key:
            return ToolResult(
                success=False,
                content="",
                error="Missing API key for web search",
                is_error=True
            )

        query = arguments.get("query")
        count = arguments.get("count", 5)

        if not query:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: query",
                is_error=True
            )

        # Validate count range
        count = max(1, min(10, count))

        try:
            async with httpx.AsyncClient() as client:
                headers = {
                    "X-Subscription-Token": self.api_key,
                    "Accept": "application/json"
                }
                params = {
                    "q": query,
                    "count": count
                }
                
                response = await client.get(
                    "https://api.search.brave.com/res/v1/web/search",
                    headers=headers,
                    params=params,
                    timeout=30.0
                )
                
                if response.status_code != 200:
                    return ToolResult(
                        success=False,
                        content="",
                        error=f"Search API returned status {response.status_code}: {response.text}",
                        is_error=True
                    )

                data = response.json()
                results = data.get("web", {}).get("results", [])

                if not results:
                    return ToolResult(
                        success=True,
                        content="No search results found for the query."
                    )

                # Format results
                formatted_results = []
                for i, result in enumerate(results[:count], 1):
                    title = result.get("title", "No title")
                    url = result.get("url", "")
                    snippet = result.get("description", "No description")
                    
                    formatted_results.append(f"{i}. **{title}**\n   URL: {url}\n   {snippet}\n")

                content = f"Search Results for '{query}':\n\n" + "\n".join(formatted_results)

                return ToolResult(
                    success=True,
                    content=content
                )

        except httpx.TimeoutException:
            return ToolResult(
                success=False,
                content="",
                error="Search request timed out",
                is_error=True
            )
        except httpx.RequestError as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Network error during search: {e}",
                is_error=True
            )
        except Exception as e:
            logger.exception("Unexpected error in web search")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )