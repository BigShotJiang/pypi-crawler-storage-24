from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import discord

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class DiscordProactiveTool(NativeTool):
    def __init__(self, discord_client: Optional[discord.Client] = None):
        """Initialize DiscordProactiveTool with Discord client."""
        self.discord_client = discord_client

    @property
    def name(self) -> str:
        return "discord_proactive"

    @property
    def description(self) -> str:
        return "Send messages to Discord channels proactively (not as replies)"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "channel_id": {
                    "type": "string",
                    "description": "Discord channel ID to send message to"
                },
                "message": {
                    "type": "string",
                    "description": "Message text to send"
                },
                "reply_to": {
                    "type": "string",
                    "description": "Optional message ID to reply to"
                }
            },
            "required": ["channel_id", "message"]
        }

    def set_discord_client(self, client: discord.Client):
        """Set the Discord client after it's available."""
        self.discord_client = client

    async def execute(self, arguments: dict) -> ToolResult:
        channel_id = arguments.get("channel_id")
        message = arguments.get("message")
        reply_to = arguments.get("reply_to")

        if not channel_id:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: channel_id",
                is_error=True
            )

        if not message:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: message",
                is_error=True
            )

        if not self.discord_client:
            return ToolResult(
                success=False,
                content="",
                error="Discord client not available",
                is_error=True
            )

        try:
            # Get the channel
            channel = self.discord_client.get_channel(int(channel_id))
            if not channel:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Channel not found: {channel_id}",
                    is_error=True
                )

            # Check if it's a text channel we can send to
            if not isinstance(channel, (discord.TextChannel, discord.DMChannel, discord.Thread)):
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Channel {channel_id} is not a text channel",
                    is_error=True
                )

            # Send message
            sent_message = None
            if reply_to:
                try:
                    # Try to get the message to reply to
                    reply_message = await channel.fetch_message(int(reply_to))
                    sent_message = await reply_message.reply(message)
                except discord.NotFound:
                    return ToolResult(
                        success=False,
                        content="",
                        error=f"Reply target message not found: {reply_to}",
                        is_error=True
                    )
                except discord.HTTPException as e:
                    return ToolResult(
                        success=False,
                        content="",
                        error=f"Failed to send reply: {e}",
                        is_error=True
                    )
            else:
                # Send as new message
                try:
                    sent_message = await channel.send(message)
                except discord.HTTPException as e:
                    return ToolResult(
                        success=False,
                        content="",
                        error=f"Failed to send message: {e}",
                        is_error=True
                    )

            # Success
            result_content = f"✅ Message sent to Discord\n"
            result_content += f"Channel: {channel.name if hasattr(channel, 'name') else 'DM'} ({channel_id})\n"
            result_content += f"Message ID: {sent_message.id}\n"
            if reply_to:
                result_content += f"Reply to: {reply_to}\n"
            result_content += f"Content: {message[:100]}..." if len(message) > 100 else f"Content: {message}"

            logger.info("Discord proactive message sent: channel=%s message_id=%s", channel_id, sent_message.id)

            return ToolResult(
                success=True,
                content=result_content
            )

        except ValueError as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Invalid channel ID or message ID: {e}",
                is_error=True
            )
        except discord.Forbidden:
            return ToolResult(
                success=False,
                content="",
                error=f"No permission to send messages in channel {channel_id}",
                is_error=True
            )
        except Exception as e:
            logger.exception("Unexpected error in Discord proactive send")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )