from __future__ import annotations

import asyncio
import http.server
import logging
import socketserver
import threading
import webbrowser
from pathlib import Path
from typing import Any, Dict

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class CanvasTool(NativeTool):
    def __init__(self, default_port: int = 7777):
        """Initialize CanvasTool with default port."""
        self.default_port = default_port
        self.active_servers = {}  # Track active servers by port

    @property
    def name(self) -> str:
        return "canvas"

    @property
    def description(self) -> str:
        return "Serve HTML content on a local HTTP server and open in browser"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "html": {
                    "type": "string",
                    "description": "HTML content to serve"
                },
                "port": {
                    "type": "integer",
                    "description": "HTTP port to serve on (optional, default 7777)",
                    "default": 7777,
                    "minimum": 1024,
                    "maximum": 65535
                },
                "title": {
                    "type": "string",
                    "description": "Page title (optional, added to HTML if not present)",
                    "default": "Canvas"
                }
            },
            "required": ["html"]
        }

    async def execute(self, arguments: dict) -> ToolResult:
        html = arguments.get("html")
        port = arguments.get("port", self.default_port)
        title = arguments.get("title", "Canvas")

        if not html:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: html",
                is_error=True
            )

        # Validate port range
        port = max(1024, min(65535, port))

        try:
            # Ensure HTML has proper structure
            processed_html = self._ensure_html_structure(html, title)

            # Start HTTP server in background
            server_url = await self._start_server(processed_html, port)
            
            # Open in browser
            webbrowser.open(server_url)

            result_content = f"🌐 **Canvas Server Started**\n\n"
            result_content += f"URL: {server_url}\n"
            result_content += f"Port: {port}\n"
            result_content += f"Title: {title}\n"
            result_content += f"Auto-shutdown: 60 seconds\n"
            result_content += f"HTML size: {len(html)} characters\n\n"
            result_content += "✅ Browser should open automatically"

            logger.info("Canvas server started: port=%d url=%s", port, server_url)

            return ToolResult(
                success=True,
                content=result_content
            )

        except OSError as e:
            if "Address already in use" in str(e):
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Port {port} is already in use. Try a different port.",
                    is_error=True
                )
            else:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Failed to start server: {e}",
                    is_error=True
                )
        except Exception as e:
            logger.exception("Unexpected error in canvas tool")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )

    def _ensure_html_structure(self, html: str, title: str) -> str:
        """Ensure HTML has proper document structure."""
        html_lower = html.lower()
        
        # Check if it's already a complete HTML document
        if "<!doctype" in html_lower or "<html" in html_lower:
            return html
        
        # Check if it has head/body structure
        if "<head>" in html_lower and "<body>" in html_lower:
            return f"<!DOCTYPE html>\n<html lang='en'>\n{html}\n</html>"
        
        # Wrap in complete structure
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }}
    </style>
</head>
<body>
{html}
</body>
</html>"""

    async def _start_server(self, html: str, port: int) -> str:
        """Start HTTP server in background thread."""
        
        class CanvasHandler(http.server.BaseHTTPRequestHandler):
            def __init__(self, html_content):
                self.html_content = html_content
                super().__init__()

            def __call__(self, *args, **kwargs):
                # Store HTML content in instance
                handler = type(self)(self.html_content)
                handler.html_content = self.html_content
                super(CanvasHandler, handler).__init__(*args, **kwargs)
                return handler

            def do_GET(self):
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()
                self.wfile.write(self.html_content.encode('utf-8'))

            def log_message(self, format, *args):
                # Suppress default logging
                pass

        # Create handler with HTML content
        handler_factory = CanvasHandler(html)

        # Start server in thread
        def run_server():
            try:
                with socketserver.TCPServer(("localhost", port), handler_factory) as httpd:
                    self.active_servers[port] = httpd
                    
                    # Auto-shutdown timer
                    timer = threading.Timer(60.0, lambda: httpd.shutdown())
                    timer.start()
                    
                    httpd.serve_forever()
            except Exception as e:
                logger.error("Canvas server error on port %d: %s", port, e)
            finally:
                # Clean up
                self.active_servers.pop(port, None)

        # Start server thread
        server_thread = threading.Thread(target=run_server, daemon=True)
        server_thread.start()

        # Give server a moment to start
        await asyncio.sleep(0.5)

        return f"http://localhost:{port}"