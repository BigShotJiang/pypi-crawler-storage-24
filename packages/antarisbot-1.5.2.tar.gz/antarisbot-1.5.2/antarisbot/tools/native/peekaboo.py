from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class PeekabooTool(NativeTool):
    def __init__(self, workspace_path: str = None):
        """Initialize PeekabooTool with workspace path for output files."""
        self.workspace_path = Path(workspace_path) if workspace_path else Path.cwd()

    @property
    def name(self) -> str:
        return "peekaboo"

    @property
    def description(self) -> str:
        return "macOS screenshot and UI automation using Peekaboo CLI"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Peekaboo action to perform",
                    "enum": ["image", "see", "list", "click", "app", "window", "analyze"]
                },
                "target": {
                    "type": "string",
                    "description": "Target for action (app name, coordinates, selector, etc.)"
                },
                "output_path": {
                    "type": "string",
                    "description": "Output file path for screenshots (optional, auto-generated if not provided)"
                },
                "options": {
                    "type": "object",
                    "description": "Additional options specific to the action"
                }
            },
            "required": ["action"]
        }

    async def execute(self, arguments: dict) -> ToolResult:
        action = arguments.get("action")
        target = arguments.get("target")
        output_path = arguments.get("output_path")
        options = arguments.get("options", {})

        if not action:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: action",
                is_error=True
            )

        try:
            # Build peekaboo command
            cmd_args = ["peekaboo"]

            if action == "image":
                # Take screenshot
                cmd_args.append("image")
                
                if not output_path:
                    # Auto-generate output path
                    output_path = str(self.workspace_path / "peekaboo_screenshot.png")
                
                cmd_args.extend(["--output", output_path])
                
                # Add any additional options
                if options.get("window"):
                    cmd_args.extend(["--window", options["window"]])
                if options.get("display"):
                    cmd_args.extend(["--display", str(options["display"])])

            elif action == "see":
                # Analyze screen with vision
                cmd_args.append("see")
                if target:
                    cmd_args.append(target)
                
                # Add JSON output for parsing
                cmd_args.append("--json")

            elif action == "list":
                # List apps, windows, etc.
                cmd_args.append("list")
                list_type = target or "apps"
                cmd_args.append(list_type)
                cmd_args.append("--json")

            elif action == "click":
                # Click on coordinates or UI element
                cmd_args.append("click")
                if target:
                    cmd_args.append(target)
                else:
                    return ToolResult(
                        success=False,
                        content="",
                        error="Click action requires target (coordinates or element)",
                        is_error=True
                    )

            elif action == "app":
                # App control
                cmd_args.append("app")
                app_action = options.get("app_action", "list")
                cmd_args.append(app_action)
                if target:
                    cmd_args.append(target)
                cmd_args.append("--json")

            elif action == "window":
                # Window manipulation
                cmd_args.append("window")
                window_action = options.get("window_action", "list")
                cmd_args.append(window_action)
                if target:
                    cmd_args.append(target)
                cmd_args.append("--json")

            elif action == "analyze":
                # Analyze screen elements
                cmd_args.append("see")
                if target:
                    cmd_args.extend(["--query", target])
                cmd_args.append("--json")

            else:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Unknown action: {action}",
                    is_error=True
                )

            logger.info("Peekaboo executing: %s", " ".join(cmd_args))

            # Execute command
            process = await asyncio.create_subprocess_exec(
                *cmd_args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=30.0
                )
                exit_code = process.returncode
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return ToolResult(
                    success=False,
                    content="",
                    error="Peekaboo command timed out after 30 seconds",
                    is_error=True
                )

            # Process output
            output = stdout.decode('utf-8', errors='replace') if stdout else ""
            error_output = stderr.decode('utf-8', errors='replace') if stderr else ""

            if exit_code != 0:
                error_msg = error_output or f"Exit code: {exit_code}"
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Peekaboo command failed: {error_msg}",
                    is_error=True
                )

            # Format result based on action
            result_content = f"🎯 **Peekaboo - {action.title()}**\n\n"

            if action == "image" and output_path:
                # Screenshot saved
                if Path(output_path).exists():
                    result_content += f"✅ Screenshot saved: {output_path}\n"
                    file_size = Path(output_path).stat().st_size
                    result_content += f"File size: {file_size:,} bytes\n"
                else:
                    result_content += f"⚠️ Screenshot file not found: {output_path}\n"

            # Try to parse JSON output
            if "--json" in cmd_args and output.strip():
                try:
                    json_data = json.loads(output)
                    formatted_json = json.dumps(json_data, indent=2)
                    result_content += f"```json\n{formatted_json}\n```"
                except json.JSONDecodeError:
                    result_content += f"Raw output:\n```\n{output}\n```"
            elif output:
                result_content += f"Output:\n```\n{output}\n```"

            if error_output:
                result_content += f"\nWarnings:\n```\n{error_output}\n```"

            logger.info("Peekaboo completed successfully: action=%s", action)

            return ToolResult(
                success=True,
                content=result_content
            )

        except FileNotFoundError:
            return ToolResult(
                success=False,
                content="",
                error="Peekaboo command not found. Is Peekaboo installed?",
                is_error=True
            )
        except Exception as e:
            logger.exception("Unexpected error in Peekaboo tool")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )