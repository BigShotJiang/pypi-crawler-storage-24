from __future__ import annotations

import ipaddress
import logging
import socket
from urllib.parse import urlparse

import httpx

from .html_utils import html_to_markdown, html_to_text

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)


class WebFetchTool(NativeTool):
    def __init__(self, max_chars: int = 50000):
        self.max_chars = max_chars

    @property
    def name(self) -> str:
        return "web_fetch"

    @property
    def description(self) -> str:
        return "Fetch and extract readable content from a URL"

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL to fetch content from"
                },
                "extract_mode": {
                    "type": "string",
                    "description": "Content extraction mode",
                    "enum": ["markdown", "text"],
                    "default": "markdown"
                }
            },
            "required": ["url"]
        }

    def _html_to_markdown(self, raw_html: str) -> str:
        """Convert HTML to markdown. Delegates to html_utils with full entity decoding."""
        return html_to_markdown(raw_html)

    def _html_to_text(self, raw_html: str) -> str:
        """Extract plain text from HTML. Delegates to html_utils with full entity decoding."""
        return html_to_text(raw_html)

    def _validate_url_security(self, url: str) -> tuple[bool, str]:
        """Validate URL against SSRF attacks."""
        parsed = urlparse(url)
        
        # Only allow http and https
        if parsed.scheme not in ("http", "https"):
            return False, f"Unsupported URL scheme: {parsed.scheme}. Only http:// and https:// are allowed."
        
        if not parsed.netloc:
            return False, "Invalid URL: missing host"
        
        # Extract hostname (strip port)
        hostname = parsed.hostname or ""
        
        # Block localhost and loopback
        if hostname in ("localhost", "127.0.0.1", "::1", "0.0.0.0"):
            return False, "Access to localhost/loopback addresses is blocked"
        
        # Try to resolve and check for private/reserved IPs
        try:
            # Check if it's already an IP address
            addr = ipaddress.ip_address(hostname)
            if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved:
                return False, f"Access to private/reserved IP {hostname} is blocked"
        except ValueError:
            # It's a hostname, not an IP - try resolving
            try:
                resolved = socket.gethostbyname(hostname)
                addr = ipaddress.ip_address(resolved)
                if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved:
                    return False, f"Host {hostname} resolves to private IP {resolved}, access blocked"
            except socket.gaierror:
                pass  # DNS resolution failure will be caught by httpx
        
        # Block cloud metadata endpoints
        metadata_hosts = {"169.254.169.254", "metadata.google.internal", "169.254.170.2"}
        if hostname in metadata_hosts:
            return False, "Access to cloud metadata endpoints is blocked"
        
        return True, ""

    async def _check_redirect(self, response: httpx.Response) -> None:
        """Validate redirect targets against SSRF rules."""
        if response.is_redirect and "location" in response.headers:
            redirect_url = response.headers["location"]
            # Handle relative redirects
            if redirect_url.startswith("/"):
                redirect_url = f"{response.url.scheme}://{response.url.host}{redirect_url}"
            is_safe, error = self._validate_url_security(redirect_url)
            if not is_safe:
                raise httpx.TooManyRedirects(
                    f"Redirect blocked by SSRF protection: {error}",
                    request=response.request,
                )

    async def execute(self, arguments: dict) -> ToolResult:
        url = arguments.get("url")
        extract_mode = arguments.get("extract_mode", "markdown")

        if not url:
            return ToolResult(
                success=False,
                content="",
                error="Missing required parameter: url",
                is_error=True
            )

        # Security validation
        is_safe, security_error = self._validate_url_security(url)
        if not is_safe:
            return ToolResult(success=False, content="", error=security_error, is_error=True)

        try:
            async with httpx.AsyncClient(
                follow_redirects=True,
                max_redirects=5,
                event_hooks={"response": [self._check_redirect]},
            ) as client:
                response = await client.get(
                    url,
                    timeout=30.0,
                    headers={
                        "User-Agent": "AntarisBot/1.0 (Web Fetcher)"
                    }
                )
                
                if response.status_code != 200:
                    return ToolResult(
                        success=False,
                        content="",
                        error=f"HTTP {response.status_code}: Failed to fetch URL",
                        is_error=True
                    )

                content_type = response.headers.get("content-type", "").lower()
                
                # Handle different content types
                if "text/plain" in content_type:
                    content = response.text[:self.max_chars]
                    return ToolResult(
                        success=True,
                        content=content
                    )
                
                elif "text/html" in content_type or "application/xhtml" in content_type:
                    html_content = response.text
                    
                    if extract_mode == "markdown":
                        extracted_content = self._html_to_markdown(html_content)
                    else:
                        extracted_content = self._html_to_text(html_content)
                    
                    # Truncate if too long
                    if len(extracted_content) > self.max_chars:
                        extracted_content = extracted_content[:self.max_chars] + "\n\n[Content truncated...]"
                    
                    return ToolResult(
                        success=True,
                        content=extracted_content
                    )
                
                else:
                    # Binary or unsupported content type
                    return ToolResult(
                        success=False,
                        content="",
                        error=f"Unsupported content type: {content_type}",
                        is_error=True
                    )

        except httpx.TimeoutException:
            return ToolResult(
                success=False,
                content="",
                error="Request timed out",
                is_error=True
            )
        except httpx.RequestError as e:
            return ToolResult(
                success=False,
                content="",
                error=f"Network error: {e}",
                is_error=True
            )
        except Exception as e:
            logger.exception("Unexpected error in web fetch")
            return ToolResult(
                success=False,
                content="",
                error=f"Unexpected error: {e}",
                is_error=True
            )