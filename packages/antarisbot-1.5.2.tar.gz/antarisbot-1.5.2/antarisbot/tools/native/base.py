from __future__ import annotations

# Re-export the base classes from the main tools module
from antarisbot.tools import NativeTool, ToolResult

__all__ = ["NativeTool", "ToolResult"]