"""Pipeline integration for tool usage - handles LLM tool loops."""

from __future__ import annotations

import logging
from typing import List, Dict, Any, Tuple, Optional

from antarisbot.llm.base import LLMProvider, Message, LLMResponse
from antarisbot.tools.tool_registry import ToolRegistry
from antarisbot.tools.models import ToolResult

logger = logging.getLogger(__name__)


async def run_tool_loop(
    llm: LLMProvider,
    messages: List[Message],
    tools: List[Dict[str, Any]],
    tool_registry: ToolRegistry,
    max_iterations: int = 10,
    system: str = "",
    model: Optional[str] = None,
    max_tokens: int = 4096,
    temperature: float = 0.7,
    tool_middleware=None,
) -> Tuple[str, List[Message], Dict[str, Any]]:
    """
    Run LLM with tools until text response is received.
    
    Handles tool use loops where LLM calls tools, receives results,
    and continues until it returns a text response instead of tool calls.
    
    Args:
        llm: LLM provider instance
        messages: Initial message history  
        tools: List of tool definitions for the LLM
        tool_registry: Registry for executing tools
        max_iterations: Maximum tool call iterations to prevent runaway
        system: System prompt
        model: Model to use (optional)
        max_tokens: Max tokens for LLM response
        temperature: LLM temperature
        tool_middleware: Optional middleware for tool security/validation
    
    Returns:
        Tuple of (final_text_response, updated_messages, metadata)
        
        metadata includes:
        - tool_calls_made: List of {name, args, result} for each tool call
        - iterations: Number of iterations performed
        - stopped_by_max_iterations: Whether loop was stopped by hitting max
    """
    working_messages = list(messages)  # Copy to avoid modifying original
    tool_calls_made = []
    iteration = 0
    
    while iteration < max_iterations:
        iteration += 1
        logger.debug("Tool loop iteration %d/%d", iteration, max_iterations)
        
        try:
            # Call LLM with current message history and tools
            llm_response: LLMResponse = await llm.complete(
                messages=working_messages,
                system=system,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                tools=tools
            )
            
            # If LLM returned text content and no tool use, we're done
            if llm_response.content and not llm_response.tool_use:
                logger.debug("Tool loop completed with text response after %d iterations", iteration)
                return llm_response.content, working_messages, {
                    "tool_calls_made": tool_calls_made,
                    "iterations": iteration,
                    "stopped_by_max_iterations": False
                }
            
            # If LLM returned tool use, execute the tools
            if llm_response.tool_use:
                # Add assistant message with tool calls
                assistant_content = []
                
                # Add text content if present
                if llm_response.content:
                    assistant_content.append({
                        "type": "text", 
                        "text": llm_response.content
                    })
                
                # Add tool use blocks
                for tool_call in llm_response.tool_use:
                    assistant_content.append({
                        "type": "tool_use",
                        "id": tool_call["id"],
                        "name": tool_call["name"],
                        "input": tool_call["input"]
                    })
                
                # Add assistant message to conversation
                working_messages.append(Message(
                    role="assistant",
                    content=assistant_content
                ))
                
                # Execute each tool and collect results
                tool_results = []
                for tool_call in llm_response.tool_use:
                    tool_name = tool_call["name"]
                    tool_args = tool_call["input"]
                    tool_id = tool_call["id"]
                    
                    logger.debug("Executing tool: %s with args: %s", tool_name, tool_args)
                    
                    # Execute the tool
                    try:
                        if tool_middleware:
                            result = await tool_middleware.approve_and_run(
                                tool_name, tool_args,
                                tool_registry.execute_tool, tool_name, tool_args,
                            )
                            if result is None:
                                # Tool was rejected by middleware
                                result = ToolResult(
                                    success=False, content="Tool call rejected by security policy",
                                    error="Rejected", is_error=True
                                )
                        else:
                            result = await tool_registry.execute_tool(tool_name, tool_args)
                        
                        # Record the tool call
                        tool_calls_made.append({
                            "name": tool_name,
                            "args": tool_args,
                            "result": result.content,
                            "success": result.success,
                            "error": result.error
                        })
                        
                        # Prepare tool result for LLM
                        # Anthropic requires non-empty content when is_error=True
                        tool_content = result.content
                        if result.is_error and not tool_content:
                            tool_content = result.error or "Tool execution failed"
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tool_id,
                            "content": tool_content,
                            "is_error": result.is_error
                        })
                        
                    except Exception as e:
                        error_msg = f"Tool execution failed: {str(e)}"
                        logger.error("Tool %s execution failed: %s", tool_name, e, exc_info=True)
                        
                        tool_calls_made.append({
                            "name": tool_name,
                            "args": tool_args,
                            "result": error_msg,
                            "success": False,
                            "error": str(e)
                        })
                        
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tool_id,
                            "content": error_msg,
                            "is_error": True
                        })
                
                # Add user message with tool results
                working_messages.append(Message(
                    role="user",
                    content=tool_results
                ))
                
                # Continue the loop to get LLM response to tool results
                continue
            
            # If we reach here, LLM didn't return content or tool use (shouldn't happen)
            logger.warning("LLM returned neither content nor tool use - treating as empty response")
            return "", working_messages, {
                "tool_calls_made": tool_calls_made,
                "iterations": iteration,
                "stopped_by_max_iterations": False
            }
            
        except Exception as e:
            logger.error("Error in tool loop iteration %d: %s", iteration, e, exc_info=True)
            # Return error response
            return f"Error in tool processing: {str(e)}", working_messages, {
                "tool_calls_made": tool_calls_made,
                "iterations": iteration,
                "stopped_by_max_iterations": False,
                "error": str(e)
            }
    
    # Hit max iterations
    logger.warning("Tool loop stopped after %d iterations - max reached", max_iterations)
    return "I've reached the maximum number of tool calls for this conversation. Please try a simpler request.", working_messages, {
        "tool_calls_made": tool_calls_made,
        "iterations": max_iterations,
        "stopped_by_max_iterations": True
    }