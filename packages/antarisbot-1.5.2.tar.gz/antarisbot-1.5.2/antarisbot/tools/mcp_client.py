"""MCP Client for communicating with MCP servers via stdio or HTTP/SSE."""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Dict, Any, Optional, List, Union
from pathlib import Path

import httpx

from .models import ToolDef, ToolResult

logger = logging.getLogger(__name__)


class MCPClient:
    """Client for communicating with MCP servers."""
    
    def __init__(
        self,
        name: str,
        transport: str = "stdio",
        command: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        url: Optional[str] = None,
        timeout: float = 30.0
    ):
        """Initialize MCP client.
        
        Args:
            name: Name of the MCP server
            transport: Transport type ("stdio" or "sse")
            command: Command to spawn MCP server (for stdio)
            env: Environment variables for the command
            url: HTTP URL for SSE transport
            timeout: Operation timeout in seconds
        """
        self.name = name
        self.transport = transport
        self.command = command or []
        self.env = env or {}
        self.url = url
        self.timeout = timeout
        
        # Internal state
        self._process: Optional[asyncio.subprocess.Process] = None
        self._http_client: Optional[httpx.AsyncClient] = None
        self._request_id_counter = 0
        self._connected = False
        self._retry_count = 0
        self._max_retries = 1

    async def connect(self) -> None:
        """Connect to the MCP server."""
        try:
            if self.transport == "stdio":
                await self._connect_stdio()
            elif self.transport == "sse":
                await self._connect_sse()
            else:
                raise ValueError(f"Unsupported transport: {self.transport}")
            
            # Send initialize message
            await self._send_initialize()
            self._connected = True
            self._retry_count = 0
            logger.info("Connected to MCP server: %s", self.name)
            
        except Exception as e:
            logger.error("Failed to connect to MCP server %s: %s", self.name, e)
            await self.disconnect()
            raise

    async def _connect_stdio(self) -> None:
        """Connect via stdio subprocess."""
        if not self.command:
            raise ValueError("Command required for stdio transport")
        
        env = {**os.environ, **(self.env or {})} if self.env else None
        self._process = await asyncio.create_subprocess_exec(
            *self.command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env
        )
        
        # Brief check that process started
        await asyncio.sleep(0.1)
        if self._process.returncode is not None:
            raise RuntimeError(f"MCP server process failed to start: {self.command}")

    async def _connect_sse(self) -> None:
        """Connect via HTTP/SSE."""
        if not self.url:
            raise ValueError("URL required for SSE transport")
        
        self._http_client = httpx.AsyncClient(timeout=self.timeout)
        
        # Test connection with a simple request
        try:
            response = await self._http_client.get(f"{self.url}/health")
            response.raise_for_status()
        except Exception as e:
            await self._http_client.aclose()
            self._http_client = None
            raise RuntimeError(f"Failed to connect to MCP server at {self.url}: {e}")

    async def _send_initialize(self) -> None:
        """Send initialize message to the MCP server."""
        init_message = {
            "jsonrpc": "2.0",
            "id": self._next_request_id(),
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {}
                },
                "clientInfo": {
                    "name": "antarisbot",
                    "version": "1.2.5"
                }
            }
        }
        
        response = await self._send_request(init_message)
        if "error" in response:
            raise RuntimeError(f"MCP initialize failed: {response['error']}")

    async def disconnect(self) -> None:
        """Disconnect from the MCP server."""
        self._connected = False
        
        if self.transport == "stdio" and self._process:
            try:
                # Graceful shutdown with SIGTERM
                self._process.terminate()
                
                # Wait up to 5 seconds for graceful shutdown
                try:
                    await asyncio.wait_for(self._process.wait(), timeout=5)
                except asyncio.TimeoutError:
                    # Force kill if graceful shutdown failed
                    self._process.kill()
                    await self._process.wait()
                    
            except Exception as e:
                logger.warning("Error during MCP process cleanup: %s", e)
            finally:
                self._process = None
        
        elif self.transport == "sse" and self._http_client:
            try:
                await self._http_client.aclose()
            except Exception as e:
                logger.warning("Error closing HTTP client: %s", e)
            finally:
                self._http_client = None
        
        logger.info("Disconnected from MCP server: %s", self.name)

    async def list_tools(self) -> List[ToolDef]:
        """List available tools from the MCP server."""
        if not self._connected:
            raise RuntimeError("Not connected to MCP server")
        
        self._retry_count = 0  # Reset retry count at the start
        
        message = {
            "jsonrpc": "2.0",
            "id": self._next_request_id(),
            "method": "tools/list"
        }
        
        try:
            response = await self._send_request(message)
            if "error" in response:
                raise RuntimeError(f"tools/list failed: {response['error']}")
            
            tools = []
            for tool_data in response.get("result", {}).get("tools", []):
                tools.append(ToolDef(
                    name=tool_data["name"],
                    description=tool_data["description"],
                    input_schema=tool_data.get("inputSchema", {}),
                    source=f"mcp:{self.name}"
                ))
            
            return tools
            
        except Exception as e:
            logger.error("Failed to list tools from %s: %s", self.name, e)
            # Attempt reconnection on failure
            if self._retry_count < self._max_retries:
                self._retry_count += 1
                logger.info("Attempting to reconnect to %s...", self.name)
                await self.disconnect()
                await self.connect()
                return await self.list_tools()
            raise

    async def call_tool(self, name: str, arguments: Dict[str, Any]) -> ToolResult:
        """Call a tool on the MCP server."""
        if not self._connected:
            raise RuntimeError("Not connected to MCP server")
        
        self._retry_count = 0  # Reset retry count at the start
        
        message = {
            "jsonrpc": "2.0",
            "id": self._next_request_id(),
            "method": "tools/call",
            "params": {
                "name": name,
                "arguments": arguments
            }
        }
        
        try:
            response = await self._send_request(message)
            
            if "error" in response:
                return ToolResult(
                    success=False,
                    content="",
                    error=f"Tool call failed: {response['error']}",
                    is_error=True
                )
            
            # Extract result content
            result = response.get("result", {})
            content_items = result.get("content", [])
            
            # Combine all content items
            content_parts = []
            for item in content_items:
                if item.get("type") == "text":
                    content_parts.append(item.get("text", ""))
            
            content = "\n".join(content_parts) if content_parts else str(result)
            
            return ToolResult(
                success=True,
                content=content,
                error=None,
                is_error=False
            )
            
        except Exception as e:
            logger.error("Failed to call tool %s on %s: %s", name, self.name, e)
            # Attempt reconnection on failure
            if self._retry_count < self._max_retries:
                self._retry_count += 1
                logger.info("Attempting to reconnect to %s...", self.name)
                await self.disconnect()
                await self.connect()
                return await self.call_tool(name, arguments)
            
            return ToolResult(
                success=False,
                content="",
                error=str(e),
                is_error=True
            )

    async def healthcheck(self) -> bool:
        """Check if the MCP server is healthy."""
        if not self._connected:
            return False
        
        try:
            # Simple ping to check server responsiveness
            message = {
                "jsonrpc": "2.0",
                "id": self._next_request_id(),
                "method": "ping"
            }
            
            await self._send_request(message)
            return True
            
        except Exception:
            return False

    async def _send_request(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Send a JSON-RPC request and return the response."""
        if self.transport == "stdio":
            return await self._send_request_stdio(message)
        elif self.transport == "sse":
            return await self._send_request_sse(message)
        else:
            raise ValueError(f"Unsupported transport: {self.transport}")

    async def _send_request_stdio(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Send request via stdio."""
        if not self._process or self._process.returncode is not None:
            raise RuntimeError("MCP process is not running")
        
        message_str = json.dumps(message) + "\n"
        self._process.stdin.write(message_str.encode())
        await self._process.stdin.drain()
        
        try:
            line = await asyncio.wait_for(
                self._process.stdout.readline(),
                timeout=self.timeout
            )
        except asyncio.TimeoutError:
            raise asyncio.TimeoutError(f"Request timed out after {self.timeout}s")
        
        if not line:
            if self._process.returncode is not None:
                raise RuntimeError("MCP process died unexpectedly")
            raise RuntimeError("Empty response from MCP server")
        
        return json.loads(line.decode().strip())

    async def _send_request_sse(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Send request via HTTP/SSE."""
        if not self._http_client:
            raise RuntimeError("HTTP client not connected")
        
        try:
            response = await self._http_client.post(
                f"{self.url}/mcp",
                json=message,
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            raise RuntimeError(f"HTTP request failed: {e}")

    def _next_request_id(self) -> int:
        """Get next request ID."""
        self._request_id_counter += 1
        return self._request_id_counter

    def __repr__(self) -> str:
        return f"MCPClient(name={self.name}, transport={self.transport}, connected={self._connected})"