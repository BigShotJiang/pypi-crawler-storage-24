"""JavaScript Tool Bridge for integrating non-MCP JavaScript tools."""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import subprocess
from pathlib import Path
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class JSToolBridge:
    """Bridge for non-MCP JavaScript tools."""
    
    def __init__(self, name: str, script_path: str, node_path: str = "node"):
        """
        Initialize JS tool bridge.
        
        Args:
            name: Tool name
            script_path: Path to the JS wrapper script
            node_path: Path to node binary (default: "node" from PATH)
        """
        self.name = name
        self.script_path = Path(script_path)
        self.node_path = node_path
        self._process: Optional[subprocess.Popen] = None
        self._request_id = 0
    
    @classmethod
    def from_openclaw_extension(cls, extension_path: str) -> Optional["JSToolBridge"]:
        """
        Detect if an OpenClaw extension can be bridged.
        
        Reads package.json to find exported functions.
        Returns None if not bridgeable (e.g., it's a hook-only extension).
        
        Args:
            extension_path: Path to the OpenClaw extension directory
            
        Returns:
            JSToolBridge instance if bridgeable, None otherwise
        """
        ext_path = Path(extension_path)
        package_json_path = ext_path / "package.json"
        
        if not package_json_path.exists():
            logger.debug("No package.json found in %s", extension_path)
            return None
        
        try:
            with open(package_json_path, 'r', encoding='utf-8') as f:
                package_data = json.load(f)
            
            # Check if this extension has main entry point
            main_script = package_data.get("main")
            if not main_script:
                logger.debug("No main script defined in %s", package_json_path)
                return None
            
            main_script_path = ext_path / main_script
            if not main_script_path.exists():
                logger.debug("Main script %s does not exist in %s", main_script, extension_path)
                return None
            
            # Check if it has functions we can call (basic heuristic)
            # Real implementation would parse the JS file or check for specific patterns
            try:
                content = main_script_path.read_text(encoding='utf-8')
                # Look for exports or function definitions
                if ("module.exports" in content or "exports." in content or 
                    "function " in content or "const " in content):
                    
                    # Generate a wrapper script name
                    wrapper_name = f"openclaw_{package_data.get('name', 'extension')}_wrapper.js"
                    wrapper_path = ext_path / wrapper_name
                    
                    # We would generate the wrapper script here
                    # For now, just check if it can be bridged
                    return cls(
                        name=package_data.get('name', 'unknown'),
                        script_path=str(wrapper_path)
                    )
                else:
                    logger.debug("No callable functions found in %s", main_script_path)
                    return None
                    
            except Exception as e:
                logger.debug("Error reading main script %s: %s", main_script_path, e)
                return None
                
        except Exception as e:
            logger.debug("Error reading package.json %s: %s", package_json_path, e)
            return None
    
    def check_node_available(self) -> bool:
        """Check if Node.js is available on PATH."""
        return shutil.which(self.node_path) is not None
    
    # TODO: Migrate to asyncio.create_subprocess_exec for non-blocking I/O
    # (same fix as applied to mcp_client.py). Lower priority since JS bridge
    # is an edge-case migration tool.
    async def _start_process(self) -> None:
        """Start the Node.js subprocess if not already running."""
        if self._process and self._process.poll() is None:
            return  # Already running
        
        if not self.check_node_available():
            raise RuntimeError(f"Node.js not found at {self.node_path}")
        
        if not self.script_path.exists():
            raise RuntimeError(f"Script not found at {self.script_path}")
        
        try:
            self._process = subprocess.Popen(
                [self.node_path, str(self.script_path)],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=0  # Unbuffered for real-time communication
            )
            logger.debug("Started Node.js process for %s (PID: %s)", self.name, self._process.pid)
        except Exception as e:
            raise RuntimeError(f"Failed to start Node.js process: {e}")
    
    async def call(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send JSON-RPC call to the Node subprocess.
        
        Args:
            method: Method name to call
            params: Parameters to pass to the method
            
        Returns:
            Response from the JavaScript tool
            
        Raises:
            RuntimeError: If communication fails
        """
        await self._start_process()
        
        if not self._process:
            raise RuntimeError("Failed to start Node.js process")
        
        self._request_id += 1
        request = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": self._request_id
        }
        
        try:
            # Send request
            request_json = json.dumps(request) + "\n"
            self._process.stdin.write(request_json)
            self._process.stdin.flush()
            
            # Read response (with timeout)
            try:
                response_line = await asyncio.wait_for(
                    asyncio.create_task(self._read_line()),
                    timeout=30.0
                )
            except asyncio.TimeoutError:
                raise RuntimeError("Timeout waiting for response from JavaScript tool")
            
            if not response_line:
                raise RuntimeError("No response from JavaScript tool")
            
            response = json.loads(response_line)
            
            # Check for JSON-RPC error
            if "error" in response:
                error = response["error"]
                raise RuntimeError(f"JavaScript tool error: {error.get('message', error)}")
            
            return response.get("result", {})
            
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Invalid JSON response: {e}")
        except Exception as e:
            # Try to get stderr for debugging
            stderr_data = ""
            if self._process and self._process.stderr:
                try:
                    # Non-blocking: read what's available without waiting
                    import select
                    if select.select([self._process.stderr], [], [], 0)[0]:
                        stderr_data = self._process.stderr.read(4096)  # Read max 4KB
                except Exception:
                    pass
            raise RuntimeError(f"Communication error: {e}. Stderr: {stderr_data}")
    
    async def _read_line(self) -> str:
        """Read a line from the subprocess stdout."""
        if not self._process or not self._process.stdout:
            return ""
        
        # This is a simplified version - in production you'd want proper async I/O
        loop = asyncio.get_event_loop()
        
        def _read():
            if self._process and self._process.stdout:
                return self._process.stdout.readline()
            return ""
        
        line = await loop.run_in_executor(None, _read)
        return line.strip() if line else ""
    
    async def close(self) -> None:
        """Kill the subprocess."""
        if self._process:
            try:
                self._process.terminate()
                # Wait a bit for graceful shutdown
                try:
                    await asyncio.wait_for(
                        asyncio.create_task(self._wait_for_exit()),
                        timeout=5.0
                    )
                except asyncio.TimeoutError:
                    # Force kill if it doesn't exit gracefully
                    self._process.kill()
                    await asyncio.create_task(self._wait_for_exit())
                    
                logger.debug("Closed Node.js process for %s", self.name)
            except Exception as e:
                logger.warning("Error closing Node.js process: %s", e)
            finally:
                self._process = None
    
    async def _wait_for_exit(self) -> None:
        """Wait for process to exit."""
        if self._process:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._process.wait)