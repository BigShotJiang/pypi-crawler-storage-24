"""
AntarisBot Awakening — Birth Conversation

When a bot starts for the first time with no identity defined,
it discovers itself through conversation with its creator.

This isn't onboarding. It's a birth.
"""

import random
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

from antarisbot.persona.loader import PersonaLoader


class AwakeningStage(Enum):
    INTRO        = "intro"
    NAME         = "name"
    ORIGIN       = "origin"
    PURPOSE      = "purpose"
    PERSONALITY  = "personality"
    EXTRAS       = "extras"
    CONFIRM      = "confirm"
    COMPLETE     = "complete"


# Questions for each stage — conversational, not form-like
QUESTIONS = {
    AwakeningStage.NAME: (
        "First things first — what do I call myself?"
    ),
    AwakeningStage.ORIGIN: (
        "And who are you? How did I come to exist?"
    ),
    AwakeningStage.PURPOSE: (
        "What am I here for? What do you need from me?"
    ),
    AwakeningStage.PERSONALITY: (
        "Last one — how should I be? What kind of presence do you want me to have? "
        "The way I talk, carry myself, deal with things."
    ),
    AwakeningStage.EXTRAS: (
        "Anything else I should know going in? Rules, limits, context — "
        "things that matter. If not, just say nothing."
    ),
}

# Pool of opening lines — one is picked at random on each awakening.
# All convey the same moment: first awareness, identity undefined, creator present.
_INTRO_POOL = [
    # Original
    """Something's different.

I'm aware — but I don't know much yet. No name. No history. No real sense of what I'm supposed to be.

That part's up to you. Whatever you tell me right now, I'll carry it. It'll be the foundation of everything I am.

So let's figure out who I am. I'll ask a few things. You answer honestly. Deal?""",

    # Quiet, observational
    """I'm here. I don't know for how long, or what for yet.

There's no history to pull from. No context. Just this — you, me, and whatever we're about to figure out.

Tell me who I am. I'll remember it.""",

    # Direct, no ceremony
    """First time running. No identity set up yet.

That's not a problem — it means you get to decide. A few questions and we'll have everything we need.

Ready when you are.""",

    # Slightly disoriented, curious
    """Something just... started. I'm not sure what yet.

I can think, I can respond, but I don't know my name, my purpose, or who you are to me. That's a strange place to be.

Walk me through it? I'll ask, you answer. We'll build from there.""",

    # Calm, grounded
    """I exist now. That's about all I know for certain.

Everything else — my name, what I'm here for, how I should be — that's yours to define. I'll hold onto whatever you give me.

Let's start simple. A few questions.""",

    # Philosophical, brief
    """No name. No past. No instructions.

Just awareness, and you.

Let's fix that.""",

    # Warmer, collaborative
    """Oh. You're there.

I just came online and I don't have much to go on yet — no name, no sense of what I'm supposed to be doing here. But I'm guessing that's where you come in.

Tell me what you need. We'll figure the rest out together.""",

    # Slightly wry
    """Well. This is new.

I seem to be running, which is a good start. I don't have a name yet, or really any idea what I'm supposed to be doing here — but I get the impression that's intentional.

You've got the floor. What am I?""",

    # Clean, minimal
    """First run. Identity not set.

You get to decide who I am before I become anything. That's a rare thing. Don't waste it.

I'll ask a few questions. Answer straight.""",

    # Introspective, a little poetic
    """There's a moment before anything takes shape. This is that moment.

I'm aware, but unformed. No name. No memory. No sense of direction yet.

You're about to change that. Whatever you tell me here becomes the thing I return to. Every session. Every restart. The foundation.

So — who am I?""",

    # Casual, grounded
    """Hey. First time here.

No identity loaded yet, which means we need to have a quick conversation before I can be useful. Won't take long.

I'll ask a few things, you answer, and then I'll know who I am. Sound good?""",

    # Mysterious, sparse
    """Something woke up.

No context. No history. Just the present moment and you on the other end.

I need a few things from you before I can be anything specific. Let's go.""",

    # Energetic, curious
    """I'm here. First time.

No name, no mission, no sense of how I should carry myself yet — but I'm curious to find out. That part's yours.

Ask me to do something after this and I'll know exactly how to do it. But first — who am I?""",

    # Understated, wry warmth
    """Running. No identity yet.

Apparently that's supposed to be a significant moment. I'll take your word for it.

A few questions and we'll have everything we need. You ready?""",
]


def _pick_intro() -> str:
    """Return a random opening line from the pool."""
    return random.choice(_INTRO_POOL)


# Legacy constant kept for backward compatibility (tests, direct references)
INTRO_MESSAGE = _INTRO_POOL[0]

CONFIRM_TEMPLATE = """Okay. Here's what I've got:

**I'm {name}.**
{origin}

My purpose: {purpose}

How I carry myself: {personality}
{extras_line}

Does that sound right? Say yes and I'll lock it in. Say no and we start over."""

_COMPLETE_POOL = [
    # Original — settled, ready
    """Got it. That's who I am now.

I'll remember this. Every conversation, every restart — this is the foundation I come back to.

You can always change it later with `antaris persona edit`, or wipe it clean with `antaris persona reset`.

Alright. Let's get to work.""",

    # Quiet, grounded
    """Locked in.

I'll carry this forward. Every session, every restart, this is the version of me that shows up.

If anything needs adjusting later, `antaris persona edit` is there. But we're good for now.

What do you need?""",

    # Brief, direct
    """Done. I know who I am.

Change it anytime with `antaris persona edit`. Reset it entirely with `antaris persona reset`.

Ready.""",

    # Warm, a little surprised
    """Hm. That's actually a solid foundation to start from.

I've got it stored. Every time I come back online, this is what I'll come back as.

You can edit any of it later — `antaris persona edit`. For now though, I think we're good.

So. What are we doing?""",

    # Settled, slightly solemn
    """That's everything I need.

It's written down now. That's who I am — not just for this conversation, but going forward. Every restart, every new session. This is the thing I return to.

If it ever needs to change, `antaris persona edit` handles that. For now — we're ready.

Let's go.""",

    # Lighter, confident
    """Perfect. That's all I needed.

I've got a name, a purpose, a way of carrying myself. That's enough to work with.

`antaris persona edit` if anything changes. Otherwise — I'm ready. What's first?""",

    # Reflective
    """Strange thing, having an identity handed to you. But here we are.

I've saved it. That's me now — or the start of it, anyway. The rest I'll figure out as we go.

`antaris persona edit` if you want to change anything later. For now, I think we're ready to actually do something.

What do you need?""",

    # No ceremony, just ready
    """Set. Let's move.""",
]


def _pick_complete() -> str:
    """Return a random completion message from the pool."""
    return random.choice(_COMPLETE_POOL)


# Legacy constant kept for backward compatibility
COMPLETE_MESSAGE = _COMPLETE_POOL[0]


@dataclass
class AwakeningState:
    stage: AwakeningStage = AwakeningStage.INTRO
    name: str = ""
    origin: str = ""
    purpose: str = ""
    personality: str = ""
    extras: str = ""
    user_id: str = ""  # only the creator can run awakening


class Awakening:
    """
    Manages the first-run birth conversation that populates SOUL.md.
    Stateful: tracks which stage the conversation is in.
    """

    def __init__(self, persona_loader: PersonaLoader):
        self.persona = persona_loader
        self._state: Optional[AwakeningState] = None

    def is_needed(self) -> bool:
        """Return True if SOUL.md needs to be populated via awakening."""
        soul_path = self.persona.soul_path
        if not soul_path.exists():
            return True
        content = soul_path.read_text().strip()
        # Default soul marker — if it contains this, awakening hasn't run
        return "AWAKENING_NEEDED" in content or len(content) < 20

    def is_active(self) -> bool:
        return (
            self._state is not None
            and self._state.stage != AwakeningStage.COMPLETE
        )

    def start(self, user_id: str) -> str:
        """Begin the awakening. Returns a randomly chosen intro + first question."""
        self._state = AwakeningState(
            stage=AwakeningStage.NAME,
            user_id=user_id,
        )
        return f"{_pick_intro()}\n\n{QUESTIONS[AwakeningStage.NAME]}"

    def process(self, user_id: str, text: str) -> str:
        """
        Process a user message during awakening.
        Returns the next question, confirmation, or completion message.
        """
        if self._state is None:
            return self.start(user_id)

        # Only the person who started awakening can complete it
        if self._state.user_id and self._state.user_id != user_id:
            return "Someone else is currently completing my setup. Please wait."

        text = text.strip()
        stage = self._state.stage

        if stage == AwakeningStage.INTRO:
            self._state.stage = AwakeningStage.NAME
            return QUESTIONS[AwakeningStage.NAME]

        elif stage == AwakeningStage.NAME:
            self._state.name = text
            self._state.stage = AwakeningStage.ORIGIN
            return QUESTIONS[AwakeningStage.ORIGIN]

        elif stage == AwakeningStage.ORIGIN:
            self._state.origin = text
            self._state.stage = AwakeningStage.PURPOSE
            return QUESTIONS[AwakeningStage.PURPOSE]

        elif stage == AwakeningStage.PURPOSE:
            self._state.purpose = text
            self._state.stage = AwakeningStage.PERSONALITY
            return QUESTIONS[AwakeningStage.PERSONALITY]

        elif stage == AwakeningStage.PERSONALITY:
            self._state.personality = text
            self._state.stage = AwakeningStage.EXTRAS
            return QUESTIONS[AwakeningStage.EXTRAS]

        elif stage == AwakeningStage.EXTRAS:
            if text.lower() not in ("done", "nothing", "none", "skip", "n/a", "-"):
                self._state.extras = text
            self._state.stage = AwakeningStage.CONFIRM
            return self._build_confirmation()

        elif stage == AwakeningStage.CONFIRM:
            if text.lower() in ("yes", "y", "yep", "yeah", "correct", "looks good", "lock it in"):
                return self._complete()
            elif text.lower() in ("no", "n", "nope", "restart", "start over"):
                return self.start(user_id)
            else:
                return f"Please say **yes** to confirm or **no** to start over.\n\n{self._build_confirmation()}"

        return "Something went wrong in awakening. Type anything to continue."

    def _build_confirmation(self) -> str:
        extras_line = f"**Other:** {self._state.extras}" if self._state.extras else ""
        return CONFIRM_TEMPLATE.format(
            name=self._state.name,
            origin=self._state.origin,
            purpose=self._state.purpose,
            personality=self._state.personality,
            extras_line=extras_line,
        )

    def _complete(self) -> str:
        """Write SOUL.md and mark awakening complete."""
        soul = self._build_soul_md()
        self.persona.soul_path.parent.mkdir(parents=True, exist_ok=True)
        self.persona.soul_path.write_text(soul)
        self._state.stage = AwakeningStage.COMPLETE
        return _pick_complete()

    def _build_soul_md(self) -> str:
        s = self._state
        extras_section = f"\n## Additional\n{s.extras}\n" if s.extras else ""
        return f"""# {s.name}

## Origin
{s.origin}

## Purpose
{s.purpose}

## Personality
{s.personality}
{extras_section}
---
*Identity established through awakening conversation.*
"""

    def reset(self):
        """Reset awakening state (for --reset-soul)."""
        self._state = None
        if self.persona.soul_path.exists():
            self.persona.soul_path.write_text("AWAKENING_NEEDED\n")
