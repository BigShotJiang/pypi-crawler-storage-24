"""Entry point for: python -m antaris_guard.mcp_server"""
from antarisbot.suite.guard.mcp_server import main
main()
