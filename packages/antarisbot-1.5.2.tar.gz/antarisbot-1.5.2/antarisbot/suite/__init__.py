"""
antarisbot.suite — Forked antaris-suite packages, bundled into AntarisBot.

This module contains the complete antaris-suite toolkit as internal packages:
- antarisbot.suite.memory  (antaris-memory v5.2.1)
- antarisbot.suite.guard   (antaris-guard v5.0.1)
- antarisbot.suite.router  (antaris-router v5.0.1)
- antarisbot.suite.context (antaris-context v5.0.1)
- antarisbot.suite.pipeline (antaris-pipeline v5.0.1)

Forked 2026-03-12 for single-package distribution.
No external antaris-suite dependencies required.
"""

__version__ = "5.2.1"  # Tracks the highest component version
