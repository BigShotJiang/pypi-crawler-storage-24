from antarisbot.cli import main

main()
