"""
Unix socket IPC system for daemon-CLI communication.

The daemon runs a Unix socket server that CLI commands can connect to for:
- Status queries
- Session management
- Configuration validation
- Security controls
- Tool introspection
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

SOCKET_PATH = Path.home() / ".antarisbot" / "antarisd.sock"


class DaemonIPC:
    """Unix socket server running inside the daemon process."""
    
    def __init__(self):
        self._server: Optional[asyncio.Server] = None
        self._bot: Any = None  # Set when daemon starts
    
    async def start(self, bot) -> None:
        """Start listening on Unix socket. Remove stale socket first."""
        # Remove stale socket file if it exists
        SOCKET_PATH.parent.mkdir(parents=True, exist_ok=True)
        if SOCKET_PATH.exists():
            SOCKET_PATH.unlink()
        
        self._bot = bot
        self._server = await asyncio.start_unix_server(
            self._handle_client, path=str(SOCKET_PATH)
        )
        logger.info("IPC server listening on %s", SOCKET_PATH)
    
    async def stop(self) -> None:
        """Stop the IPC server and clean up socket file."""
        if self._server:
            self._server.close()
            await self._server.wait_closed()
        if SOCKET_PATH.exists():
            SOCKET_PATH.unlink()
        logger.info("IPC server stopped")
    
    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        """Handle a single CLI client connection."""
        try:
            data = await asyncio.wait_for(reader.readline(), timeout=5.0)
            if not data:
                return
            
            request = json.loads(data.decode().strip())
            command = request.get("command", "")
            params = request.get("params", {})
            
            result = await self._dispatch(command, params)
            response = json.dumps(result) + "\n"
            writer.write(response.encode())
            await writer.drain()
        except asyncio.TimeoutError:
            error_resp = json.dumps({"error": "Client request timeout"}) + "\n"
            writer.write(error_resp.encode())
            await writer.drain()
        except json.JSONDecodeError as e:
            error_resp = json.dumps({"error": f"Invalid JSON: {e}"}) + "\n"
            writer.write(error_resp.encode())
            await writer.drain()
        except Exception as e:
            logger.exception("Error handling IPC client")
            error_resp = json.dumps({"error": str(e)}) + "\n"
            writer.write(error_resp.encode())
            await writer.drain()
        finally:
            writer.close()
            await writer.wait_closed()
    
    async def _dispatch(self, command: str, params: dict) -> dict:
        """Route command to appropriate handler."""
        handlers = {
            "status": self._cmd_status,
            "sessions.list": self._cmd_sessions_list,
            "sessions.show": self._cmd_sessions_show,
            "sessions.kill": self._cmd_sessions_kill,
            "sessions.kill_all": self._cmd_sessions_kill_all,
            "sessions.reset": self._cmd_sessions_reset,
            "sessions.compact": self._cmd_sessions_compact,
            "security.status": self._cmd_security_status,
            "security.set": self._cmd_security_set,
            "tools.list": self._cmd_tools_list,
            "tools.status": self._cmd_tools_status,
            "config.get": self._cmd_config_get,
            "config.validate": self._cmd_config_validate,
        }
        
        handler = handlers.get(command)
        if not handler:
            return {"error": f"Unknown command: {command}"}
        
        try:
            return await handler(params)
        except Exception as e:
            logger.exception("Error executing command %s", command)
            return {"error": f"Command failed: {e}"}
    
    async def _cmd_status(self, params: dict) -> dict:
        """Return daemon status."""
        pid = os.getpid()
        uptime = time.time() - getattr(self._bot, '_start_time', time.time())
        session_count = getattr(self._bot.sessions, 'active_count', 0) if hasattr(self._bot, 'sessions') else 0
        
        memory_mb = 0.0
        try:
            import psutil
            memory_mb = psutil.Process(pid).memory_info().rss / (1024 * 1024)
        except (ImportError, Exception):
            pass
        
        return {
            "status": "running",
            "pid": pid,
            "uptime_seconds": round(uptime, 1),
            "sessions": session_count,
            "memory_mb": round(memory_mb, 1),
            "version": "1.2.5",
            "security_level": getattr(self._bot.config, 'security_mode', 'sandboxed'),
        }
    
    async def _cmd_sessions_list(self, params: dict) -> dict:
        """List active sessions."""
        if not hasattr(self._bot, 'sessions'):
            return {"error": "Session manager not available"}
        
        active_only = params.get("active_only", True)
        session_list = await self._bot.sessions.list_sessions(active_only=active_only)
        sessions = []
        for session in session_list:
            sessions.append({
                "id": session.session_id,
                "user_id": session.user_id,
                "channel_id": session.channel_id,
                "platform": session.platform,
                "status": session.status,
                "created_at": session.created_at,
                "last_active": session.last_active,
                "message_count": session.message_count,
                "context_pct": round(session.context_pct, 1),
            })
        
        return {"sessions": sessions}
    
    async def _cmd_sessions_show(self, params: dict) -> dict:
        """Show details of a specific session."""
        session_id = params.get("session_id")
        if not session_id:
            return {"error": "session_id parameter required"}
        
        if not hasattr(self._bot, 'sessions'):
            return {"error": "Session manager not available"}
        
        session = await self._bot.sessions.get_session(session_id)
        if not session:
            return {"error": f"Session {session_id} not found"}
        
        return {
            "id": session_id,
            "user_id": session.user_id,
            "channel_id": session.channel_id,
            "platform": session.platform,
            "status": session.status,
            "created_at": session.created_at,
            "last_active": session.last_active,
            "message_count": session.message_count,
            "history_length": len(session.history),
            "buffer_length": len(session.conversation_buffer),
            "context_pct": round(session.context_pct, 1),
            "max_history": session.max_history,
        }
    
    async def _cmd_sessions_kill(self, params: dict) -> dict:
        """Kill a specific session."""
        session_id = params.get("session_id")
        if not session_id:
            return {"error": "session_id parameter required"}
        
        if not hasattr(self._bot, 'sessions'):
            return {"error": "Session manager not available"}
        
        killed = await self._bot.sessions.kill_session(session_id)
        if killed:
            return {"message": f"Session {session_id} killed"}
        else:
            return {"error": f"Session {session_id} not found"}
    
    async def _cmd_sessions_kill_all(self, params: dict) -> dict:
        """Kill all active sessions."""
        if not hasattr(self._bot, 'sessions'):
            return {"error": "Session manager not available"}
        
        count = await self._bot.sessions.kill_all()
        return {"message": f"Killed {count} sessions"}
    
    async def _cmd_sessions_reset(self, params: dict) -> dict:
        """Reset a session's history but keep it alive."""
        session_id = params.get("session_id")
        if not session_id:
            return {"error": "session_id parameter required"}
        
        if not hasattr(self._bot, 'sessions'):
            return {"error": "Session manager not available"}
        
        reset = await self._bot.sessions.reset_session(session_id)
        if reset:
            return {"message": f"Session {session_id} reset"}
        else:
            return {"error": f"Session {session_id} not found"}
    
    async def _cmd_sessions_compact(self, params: dict) -> dict:
        """Compact a session's history."""
        session_id = params.get("session_id")
        if not session_id:
            return {"error": "session_id parameter required"}
        
        if not hasattr(self._bot, 'sessions'):
            return {"error": "Session manager not available"}
        
        summary = await self._bot.sessions.compact_session(session_id)
        if summary is not None:
            return {"message": f"Session {session_id} compacted", "summary_length": len(summary)}
        else:
            return {"error": f"Session {session_id} not found or compaction failed"}
    
    async def _cmd_security_status(self, params: dict) -> dict:
        """Get current security level and settings."""
        config = self._bot.config
        guard = getattr(self._bot, 'guard', None)
        
        return {
            "security_mode": config.security_mode,
            "guard_mode": config.guard_mode,
            "guard_active": guard is not None,
            "rate_limit_messages": config.rate_limit_messages,
            "rate_limit_window": config.rate_limit_window_seconds,
        }
    
    async def _cmd_security_set(self, params: dict) -> dict:
        """Set security level. Accepts int (0-4) or legacy string mode."""
        level_input = params.get("level", params.get("mode"))
        if level_input is None:
            return {"error": "level parameter required (0-4, or legacy: open/sandboxed/locked)"}
        
        # Map legacy string modes to levels
        legacy_map = {"open": 0, "standard": 1, "sandboxed": 2, "secured": 3, "locked": 4, "encrypted": 4}
        if isinstance(level_input, str):
            if level_input in legacy_map:
                target_level = legacy_map[level_input]
            else:
                try:
                    target_level = int(level_input)
                except ValueError:
                    return {"error": f"Invalid level: {level_input}. Use 0-4 or: open/standard/sandboxed/secured/locked"}
        else:
            target_level = int(level_input)
        
        if target_level < 0 or target_level > 4:
            return {"error": f"Level must be 0-4, got {target_level}"}
        
        # Single import — used for both lock check and level application
        from antarisbot.security.audit_hook import current_level, escalate
        current = current_level()

        # Check security lock if available
        if hasattr(self._bot, 'security_lock') and self._bot.security_lock:
            allowed, msg = self._bot.security_lock.check_downgrade(current, target_level)
            if not allowed:
                passphrase = params.get("passphrase", "")
                pin = params.get("pin", "")
                if passphrase or pin:
                    if self._bot.security_lock.bypass_lock(passphrase=passphrase, pin=pin):
                        pass  # Lock bypassed, proceed
                    else:
                        return {"error": "Wrong credentials. " + msg}
                else:
                    return {"error": msg}
        
        # Apply level change
        level_names = {0: "Open", 1: "Standard", 2: "Sandboxed", 3: "Secured", 4: "Encrypted"}
        
        if target_level > current:
            # Escalation — instant
            escalate(target_level)
            return {
                "message": f"Security escalated: {level_names.get(current)} → {level_names.get(target_level)}",
                "level": target_level,
                "warning": "Downgrading back will require a daemon restart."
            }
        elif target_level < current:
            # Downgrade — requires restart
            return {
                "error": "downgrade_requires_restart",
                "message": f"Downgrading from {level_names.get(current)} to {level_names.get(target_level)} requires a daemon restart.",
                "current_level": current,
                "target_level": target_level,
                "hint": "Run: antarisd restart --security " + str(target_level)
            }
        else:
            return {"message": f"Already at level {target_level} ({level_names.get(target_level)})", "level": target_level}
    
    async def _cmd_tools_list(self, params: dict) -> dict:
        """List available tools."""
        if not hasattr(self._bot, 'tool_registry') or self._bot.tool_registry is None:
            return {"tools": [], "message": "Tool registry not available"}
        
        registry = self._bot.tool_registry
        tools = []
        for name in registry.list_tools():
            tool_def = registry._tool_definitions.get(name)
            tools.append({
                "name": name,
                "source": tool_def.source if tool_def else "unknown",
                "description": tool_def.description if tool_def else "",
            })
        
        return {"tools": tools}
    
    async def _cmd_tools_status(self, params: dict) -> dict:
        """Get tool registry status."""
        if not hasattr(self._bot, 'tool_registry') or self._bot.tool_registry is None:
            return {"available": False, "message": "Tool registry not available"}
        
        registry = self._bot.tool_registry
        tool_names = registry.list_tools()
        native_count = sum(1 for n in tool_names if registry._tool_definitions.get(n) and registry._tool_definitions[n].source == "native")
        mcp_count = len(tool_names) - native_count
        
        # Get MCP server status
        server_status = {}
        try:
            server_status = await registry.get_server_status()
        except Exception:
            pass
        
        return {
            "available": True,
            "total_tools": len(tool_names),
            "native_tools": native_count,
            "mcp_tools": mcp_count,
            "mcp_servers": server_status,
        }
    
    async def _cmd_config_get(self, params: dict) -> dict:
        """Get configuration values."""
        key = params.get("key")
        config = self._bot.config
        
        if key:
            if hasattr(config, key):
                value = getattr(config, key)
                return {"key": key, "value": value}
            else:
                return {"error": f"Unknown config key: {key}"}
        else:
            # Return all non-sensitive config
            safe_config = {}
            sensitive_keys = {"api_key", "discord_token", "telegram_token", "slack_bot_token", "slack_app_token"}
            
            for attr in dir(config):
                if not attr.startswith("_") and attr not in sensitive_keys:
                    value = getattr(config, attr)
                    if not callable(value):
                        safe_config[attr] = value
            
            return {"config": safe_config}
    
    async def _cmd_config_validate(self, params: dict) -> dict:
        """Validate current configuration."""
        config = self._bot.config
        issues = []
        
        # Check API key
        if not config.api_key or config.api_key.strip() == "":
            issues.append("API key not configured")
        
        # Check memory store
        if not Path(config.memory_store).exists():
            issues.append(f"Memory store directory does not exist: {config.memory_store}")
        
        # Check channel configurations
        if config.discord_enabled and not config.discord_token:
            issues.append("Discord enabled but token not configured")
        
        if config.telegram_enabled and not config.telegram_token:
            issues.append("Telegram enabled but token not configured")
        
        if config.slack_enabled and (not config.slack_bot_token or not config.slack_app_token):
            issues.append("Slack enabled but tokens not configured")
        
        # Check security settings (accept both legacy strings and new 5-level)
        valid_security = {"open", "standard", "sandboxed", "secured", "locked", "encrypted",
                          "0", "1", "2", "3", "4"}
        if str(config.security_mode) not in valid_security:
            issues.append(f"Invalid security mode: {config.security_mode}")
        
        valid_guard_modes = ["monitor", "warn", "block"]
        if config.guard_mode not in valid_guard_modes:
            issues.append(f"Invalid guard mode: {config.guard_mode}")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
        }


class DaemonClient:
    """CLI-side client for talking to the daemon via Unix socket."""
    
    @staticmethod
    async def send(command: str, params: dict = None) -> dict:
        """Connect to socket, send command, return response."""
        if not SOCKET_PATH.exists():
            return {"error": "Daemon is not running. Start with: antarisd start"}
        
        try:
            reader, writer = await asyncio.open_unix_connection(str(SOCKET_PATH))
            
            request = json.dumps({"command": command, "params": params or {}}) + "\n"
            writer.write(request.encode())
            await writer.drain()
            
            data = await asyncio.wait_for(reader.readline(), timeout=10.0)
            writer.close()
            await writer.wait_closed()
            
            if data:
                return json.loads(data.decode().strip())
            return {"error": "Empty response from daemon"}
            
        except ConnectionRefusedError:
            return {"error": "Daemon socket exists but connection refused. Try: antarisd restart"}
        except asyncio.TimeoutError:
            return {"error": "Daemon did not respond within 10 seconds"}
        except json.JSONDecodeError as e:
            return {"error": f"Invalid response from daemon: {e}"}
        except Exception as e:
            return {"error": f"IPC error: {e}"}
    
    @staticmethod
    def send_sync(command: str, params: dict = None) -> dict:
        """Synchronous wrapper for CLI use."""
        try:
            return asyncio.run(DaemonClient.send(command, params))
        except Exception as e:
            return {"error": f"Failed to send command: {e}"}