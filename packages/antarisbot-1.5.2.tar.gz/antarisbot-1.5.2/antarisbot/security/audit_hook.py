"""AntarisBot audit hook — filesystem, subprocess, network enforcement via sys.addaudithook()."""
from __future__ import annotations

import site
import sys
from pathlib import Path
from typing import Union

from .levels import LEVEL_OPEN, LEVEL_STANDARD, LEVEL_SANDBOXED, LEVEL_SECURED, LEVEL_ENCRYPTED

# ---------------------------------------------------------------------------
# Module-level state (mutated once by install())
# ---------------------------------------------------------------------------
_LEVEL: int = LEVEL_STANDARD
_WORKSPACE: str = ""
_ALLOWED_PATHS: set[str] = set()
_INSTALLED: bool = False  # Guard against double audit hook installation

# Hosts always permitted in secured/encrypted modes
ALLOWED_HOSTS: set[str] = {
    "api.anthropic.com",
    "api.openai.com",
    "generativelanguage.googleapis.com",
    "localhost",
    "127.0.0.1",
}


def _build_allowed_paths() -> set[str]:
    """Collect Python stdlib and site-packages roots that are always safe."""
    candidates: list[str] = [
        sys.prefix,
        sys.base_prefix,
        sys.exec_prefix,
        getattr(sys, "base_exec_prefix", sys.exec_prefix),
    ]
    # site-packages directories
    try:
        candidates.extend(site.getsitepackages())
    except AttributeError:
        pass
    try:
        candidates.append(site.getusersitepackages())
    except AttributeError:
        pass
    # Standard lib location (CPython)
    try:
        import sysconfig
        stdlib = sysconfig.get_path("stdlib")
        platstdlib = sysconfig.get_path("platstdlib")
        if stdlib:
            candidates.append(stdlib)
        if platstdlib:
            candidates.append(platstdlib)
    except Exception:
        pass

    allowed: set[str] = set()
    for p in candidates:
        if p:
            try:
                allowed.add(str(Path(p).resolve()))
            except Exception:
                pass
    return allowed


def install(level_or_mode: Union[int, str], workspace_path: str) -> None:
    """Register the AntarisBot audit hook for the given security level.

    This calls ``sys.addaudithook`` which is **irremovable** for the lifetime
    of the interpreter — call it exactly once, at bot startup.

    Args:
        level_or_mode: Security level (0-4) or legacy mode string for backward compat.
        workspace_path: Absolute path to the bot's workspace root.
    """
    global _LEVEL, _WORKSPACE, _ALLOWED_PATHS, _INSTALLED

    # Accept both int level and string mode for backward compat
    if isinstance(level_or_mode, str):
        mode_map = {
            "open": LEVEL_OPEN,
            "standard": LEVEL_STANDARD,
            "sandboxed": LEVEL_SANDBOXED,
            "secured": LEVEL_SECURED,
            "encrypted": LEVEL_ENCRYPTED,
            "locked": LEVEL_ENCRYPTED,  # legacy alias
        }
        level = mode_map.get(level_or_mode, LEVEL_STANDARD)
    else:
        level = level_or_mode

    _LEVEL = level
    _WORKSPACE = str(Path(workspace_path).resolve())
    _ALLOWED_PATHS = _build_allowed_paths()

    # Always allow the bot's own package directory (needed to import its own modules)
    _bot_pkg_dir = str(Path(__file__).resolve().parent.parent)
    _ALLOWED_PATHS.add(_bot_pkg_dir)

    # Allow bundled suite module directories
    for _mod_name in ("antarisbot.suite.memory", "antarisbot.suite.guard", "antarisbot.suite.context", "antarisbot.suite.router", "antarisbot.suite.pipeline"):
        try:
            _mod = __import__(_mod_name, fromlist=[_mod_name.split(".")[-1]])
            _mod_dir = str(Path(_mod.__file__).resolve().parent)
            _ALLOWED_PATHS.add(_mod_dir)
        except Exception:
            pass

    # Also allow the workspace path itself
    _ALLOWED_PATHS.add(_WORKSPACE)

    # Level 0 (OPEN) skips audit hook entirely
    # Guard: sys.addaudithook is irremovable — only install once per process
    if level > LEVEL_OPEN and not _INSTALLED:
        sys.addaudithook(_antaris_hook)
        _INSTALLED = True


def escalate(new_level: int) -> bool:
    """Escalate to a higher security level.
    
    Returns:
        False if new_level <= current (can't downgrade), True otherwise.
    """
    global _LEVEL
    if new_level <= _LEVEL:
        return False
    _LEVEL = new_level
    return True


def current_level() -> int:
    """Get the current security level."""
    return _LEVEL


def add_allowed_host(host: str) -> None:
    """Add a host to the network allowlist for SECURED/ENCRYPTED levels."""
    ALLOWED_HOSTS.add(host)


# ---------------------------------------------------------------------------
# The audit hook
# ---------------------------------------------------------------------------

def _antaris_hook(event: str, args: tuple) -> None:  # noqa: C901
    """sys.audit hook — enforces level-based restrictions."""
    try:
        # ------------------------------------------------------------------ #
        # File access
        # ------------------------------------------------------------------ #
        if event == "open":
            # args: (path, mode, flags)
            raw_path = args[0] if args else None
            if raw_path is None:
                return

            try:
                resolved = str(Path(str(raw_path)).resolve())
            except Exception:
                return  # can't resolve → allow (best effort)

            # Level 1 (STANDARD): Allow workspace + home + /tmp + Python paths
            if _LEVEL == LEVEL_STANDARD:
                # Allow anything inside the workspace
                if resolved.startswith(_WORKSPACE):
                    return
                
                # Allow home directory (~/)
                home_dir = str(Path.home().resolve())
                if resolved.startswith(home_dir):
                    return
                
                # Allow /tmp and system temp directories (handle macOS paths)
                if (resolved.startswith("/tmp") or 
                    resolved.startswith("/private/tmp") or 
                    resolved.startswith("/var/folders/") or
                    resolved.startswith("/private/var/folders/")):  # macOS temporary folders
                    return

                # Allow Python's own paths (stdlib, site-packages, venv, …)
                for allowed in _ALLOWED_PATHS:
                    if resolved.startswith(allowed):
                        return

                # Block everything else
                raise PermissionError(
                    f"[AntarisBot/level-{_LEVEL}] File access blocked: {resolved}"
                )

            # Level 2+ (SANDBOXED and above): Strict restrictions
            elif _LEVEL >= LEVEL_SANDBOXED:
                # Allow anything inside the workspace
                if resolved.startswith(_WORKSPACE):
                    return

                # Allow home directory — antaris-memory uses relative shard paths
                # (e.g. numeric filenames like "14") that resolve to CWD/14.
                # Since the bot runs from ~/, these become /Users/<user>/14.
                # Blocking home breaks memory operations. Sandboxed still blocks
                # network, subprocess, and eval — file access within home is safe.
                try:
                    home_dir = str(Path.home().resolve())
                    if resolved.startswith(home_dir):
                        return
                except Exception:
                    pass

                # Allow /tmp and system temp directories (handle macOS paths)
                if (resolved.startswith("/tmp") or 
                    resolved.startswith("/private/tmp") or 
                    resolved.startswith("/var/folders/") or
                    resolved.startswith("/private/var/folders/")):  # macOS temporary folders
                    return

                # Allow Python's own paths (stdlib, site-packages, venv, …)
                for allowed in _ALLOWED_PATHS:
                    if resolved.startswith(allowed):
                        return

                raise PermissionError(
                    f"[AntarisBot/level-{_LEVEL}] File access blocked: {resolved}"
                )

        # ------------------------------------------------------------------ #
        # Subprocess
        # ------------------------------------------------------------------ #
        elif event == "subprocess.Popen":
            if _LEVEL == LEVEL_STANDARD:
                # Level 1: Allow but could log (logging not implemented in audit hook)
                return
            elif _LEVEL >= LEVEL_SANDBOXED:
                # Level 2+: Block subprocess execution
                raise PermissionError(
                    f"[AntarisBot/level-{_LEVEL}] Subprocess execution blocked"
                )

        # ------------------------------------------------------------------ #
        # exec() — ENCRYPTED only
        # ------------------------------------------------------------------ #
        elif event == "exec":
            if _LEVEL >= LEVEL_ENCRYPTED:
                raise PermissionError(
                    f"[AntarisBot/level-{_LEVEL}] Code execution blocked"
                )

        # ------------------------------------------------------------------ #
        # Network — SECURED and ENCRYPTED
        # ------------------------------------------------------------------ #
        elif event == "socket.connect":
            if _LEVEL >= LEVEL_SECURED:
                # args varies by address family; try to extract host
                addr = args[1] if len(args) > 1 else None
                if addr is None:
                    return
                if isinstance(addr, (list, tuple)) and len(addr) >= 1:
                    host = str(addr[0])
                elif isinstance(addr, str):
                    # Unix socket path — allow
                    return
                else:
                    return

                if host not in ALLOWED_HOSTS:
                    raise PermissionError(
                        f"[AntarisBot/level-{_LEVEL}] Network access blocked: {host}"
                    )

    except PermissionError:
        # Always propagate PermissionError — that's how we block things
        raise
    except Exception:
        # Swallow everything else; we must never crash the bot
        pass
