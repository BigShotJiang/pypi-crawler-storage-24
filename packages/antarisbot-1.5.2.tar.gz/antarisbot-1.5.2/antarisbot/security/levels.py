"""Security level constants and utilities."""
from __future__ import annotations

LEVEL_OPEN = 0
LEVEL_STANDARD = 1
LEVEL_SANDBOXED = 2
LEVEL_SECURED = 3
LEVEL_ENCRYPTED = 4

LEVEL_NAMES = {
    0: "Open",
    1: "Standard",
    2: "Sandboxed",
    3: "Secured",
    4: "Encrypted",
}

LEVEL_DESCRIPTIONS = {
    0: "No restrictions. Full access. Developer mode.",
    1: "Light safety net. File ops scoped to workspace + home. Subprocesses logged.",
    2: "Filesystem restricted. Subprocesses blocked. Guard: monitor.",
    3: "Network allowlisted. Tool calls logged. Destructive ops need approval. Guard: warn.",
    4: "All tools need approval. Memory encrypted. Mandatory audit. Guard: block.",
}

DEFAULT_LEVEL = LEVEL_STANDARD

DESTRUCTIVE_TOOL_KEYWORDS = {"write", "delete", "shell", "exec", "remove", "kill"}


def is_destructive_tool(tool_name: str) -> bool:
    """Check if a tool name suggests destructive behavior."""
    name_lower = tool_name.lower()
    return any(kw in name_lower for kw in DESTRUCTIVE_TOOL_KEYWORDS)


def can_escalate(current: int, target: int) -> bool:
    """Check if escalation is allowed (up only, no downgrade)."""
    return target > current


def level_name(level: int) -> str:
    """Get the human-readable name for a security level."""
    return LEVEL_NAMES.get(level, f"Unknown({level})")