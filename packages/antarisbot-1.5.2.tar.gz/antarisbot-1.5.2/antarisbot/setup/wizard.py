"""
AntarisBot Setup Wizard — high-level wrapper around SetupServer.

Usage::

    wizard = SetupWizard()
    if wizard.is_needed():
        config = wizard.run()
"""

import time
from typing import Optional

from antarisbot.core.config import Config, DEFAULT_CONFIG_PATH
from antarisbot.setup.server import SetupServer


class SetupWizard:
    """
    High-level wrapper that manages the full setup flow.

    is_needed()  — returns True if the bot needs to be configured
    run()        — opens browser wizard, waits for completion, returns Config
    """

    def is_needed(self) -> bool:
        """
        Returns True if setup is required (config missing or API key not set).
        """
        cfg = Config.load()
        if cfg is None:
            return True
        if not cfg.api_key:
            return True
        return False

    def run(self, open_browser: bool = True) -> Optional[Config]:
        """
        Start the wizard server, open the browser, wait until the user
        completes setup, then stop the server and return the new Config.

        Polls /api/status every second until configured=True.
        """
        server = SetupServer()

        print("🌐 Opening setup wizard at http://localhost:7474 …")
        print("   (If the browser doesn't open, paste that URL manually)")

        server.start(open_browser=open_browser)

        try:
            self._wait_for_completion(server)
        finally:
            server.stop()

        # Reload config from disk (the server saved it)
        cfg = server.config or Config.load()
        if cfg:
            print(f"✅ Setup complete — {cfg.bot_name} configured.")
        return cfg

    # ── Internal ──────────────────────────────────────────────────────────

    def _wait_for_completion(self, server: SetupServer) -> None:
        """Block until setup_complete is True or KeyboardInterrupt."""
        print("   Waiting for setup to complete … (Ctrl-C to cancel)")
        try:
            while not server.setup_complete:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n⚠️  Setup cancelled.")
