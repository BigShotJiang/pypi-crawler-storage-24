"""
Slack channel adapter using slack-bolt AsyncApp with Socket Mode.
No public URL required — persistent WebSocket connection.
"""

import asyncio
import logging
from typing import Optional

from slack_bolt.async_app import AsyncApp
from slack_bolt.adapter.socket_mode.async_handler import AsyncSocketModeHandler

from .base import ChannelAdapter, InboundMessage, OutboundMessage

logger = logging.getLogger(__name__)

MAX_MESSAGE_LENGTH = 4000  # Slack recommended limit per message chunk


class SlackAdapter(ChannelAdapter):
    """Slack channel adapter using slack-bolt AsyncApp with Socket Mode."""

    def __init__(
        self,
        bot_token: str,
        app_token: str,
        open_channels: Optional[list[str]] = None,
    ):
        """
        Args:
            bot_token: xoxb-... (Bot User OAuth Token)
            app_token: xapp-... (App-Level Token for Socket Mode)
            open_channels: list of Slack channel IDs to respond in;
                           empty list = respond in all channels.
        """
        if not bot_token:
            raise ValueError("Slack bot_token is required")
        if not app_token:
            raise ValueError("Slack app_token is required")
        super().__init__()
        self.bot_token = bot_token
        self.app_token = app_token
        self.open_channels: set[str] = set(open_channels or [])
        self._app: Optional[AsyncApp] = None
        self._socket_handler: Optional[AsyncSocketModeHandler] = None
        self._bot_user_id: Optional[str] = None
        self._stop_event: Optional[asyncio.Event] = None

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def connect(self):
        """Start the Slack bot via Socket Mode. Blocks until disconnect() is called."""
        self._stop_event = asyncio.Event()
        self._app = AsyncApp(token=self.bot_token)

        # Fetch bot user ID for mention detection and self-filtering
        try:
            auth = await self._app.client.auth_test()
            self._bot_user_id = auth.get("user_id")
            logger.info(
                "Slack: Connected as %s (%s)", auth.get("user"), self._bot_user_id
            )
        except Exception as exc:
            logger.warning("Slack: Could not fetch bot user ID: %s", exc)

        if self.open_channels:
            logger.info("Slack: Open channels: %s", ", ".join(self.open_channels))

        # Register event handlers (must be done before starting the handler)
        @self._app.event("message")
        async def handle_message(event, say, client):  # noqa: F811
            await self._route_message(event, say, client)

        @self._app.event("app_mention")
        async def handle_mention(event, say, client):  # noqa: F811
            await self._route_message(event, say, client, is_mention=True)

        self._socket_handler = AsyncSocketModeHandler(self._app, self.app_token)

        _max_connect_retries = 3
        for _attempt in range(_max_connect_retries):
            try:
                await self._socket_handler.start_async()
                logger.info("Slack: Socket Mode connected ✅")
                break
            except Exception as e:
                if _attempt < _max_connect_retries - 1:
                    logger.warning("Slack connect failed (attempt %d/%d): %s", _attempt + 1, _max_connect_retries, e)
                    await asyncio.sleep(5 * (_attempt + 1))
                else:
                    logger.error("Slack connect failed after %d attempts: %s", _max_connect_retries, e)
                    raise

        # Block until disconnect() signals the stop event
        await self._stop_event.wait()
        await self._socket_handler.close_async()

    async def disconnect(self):
        """Stop the Slack bot."""
        if self._stop_event:
            self._stop_event.set()

    async def start(self):
        """Alias for connect()."""
        await self.connect()

    async def stop(self):
        """Alias for disconnect()."""
        await self.disconnect()

    # ── Routing ───────────────────────────────────────────────────────────

    async def _route_message(
        self, event: dict, say, client, is_mention: bool = False
    ):
        """Route an incoming Slack event to the bot pipeline."""
        # Skip subtypes (message edits, channel joins, etc.) and bot messages
        if event.get("subtype") or event.get("bot_id"):
            return

        user_id = event.get("user")
        if not user_id:
            return

        # Ignore messages from ourselves
        if self._bot_user_id and user_id == self._bot_user_id:
            return

        channel_id = event.get("channel", "")
        channel_type = event.get("channel_type", "")

        # DM detection: channel_type "im" = direct message
        is_dm = channel_type == "im"

        # Check if the message text @mentions the bot
        text = event.get("text", "") or ""
        bot_mention = f"<@{self._bot_user_id}>" if self._bot_user_id else None
        text_has_mention = bool(bot_mention and bot_mention in text)

        # Routing logic:
        #   DM                  → always respond
        #   @mention            → always respond
        #   open_channels empty → respond everywhere
        #   open_channels set   → only respond in listed channels
        if is_dm:
            should_respond = True
        elif is_mention or text_has_mention:
            should_respond = True
        elif not self.open_channels:
            should_respond = True
        else:
            should_respond = channel_id in self.open_channels

        if not should_respond:
            return

        # Strip bot @mention from text
        if bot_mention and bot_mention in text:
            text = text.replace(bot_mention, "").strip()

        if not text.strip():
            return

        # Resolve display name
        username = user_id
        try:
            user_info = await client.users_info(user=user_id)
            profile = user_info.get("user", {}).get("profile", {})
            username = (
                profile.get("display_name")
                or profile.get("real_name")
                or user_id
            )
        except Exception as exc:
            logger.debug("Slack: Could not fetch user info for %s: %s", user_id, exc)

        if self._handler:
            ts = event.get("ts", "0")
            inbound = InboundMessage(
                id=ts,
                user_id=user_id,
                user_name=username,
                channel_id=channel_id,
                platform="slack",
                text=text,
                timestamp_ms=int(float(ts) * 1000),
                metadata={
                    "channel_type": channel_type,
                    "is_mention": is_mention or text_has_mention,
                },
            )
            await self._handler(inbound)

    # ── Outbound ──────────────────────────────────────────────────────────

    async def send(self, message: OutboundMessage):
        """Send a message via the Slack API (used by the pipeline)."""
        await self.send_message(message.channel_id, message.text)

    async def send_message(self, channel_id: str, text: str):
        """Send a message to a Slack channel. Split at 4000 chars."""
        if not self._app:
            return

        chunks = self._split_message(text)
        for chunk in chunks:
            try:
                await self._app.client.chat_postMessage(
                    channel=channel_id,
                    text=chunk,
                )
            except Exception as exc:
                logger.error("Slack send_message error: %s", exc)

    def _split_message(self, text: str, limit: int = MAX_MESSAGE_LENGTH) -> list[str]:
        """Split long messages at newlines, respecting the 4000 char limit."""
        if len(text) <= limit:
            return [text]

        chunks = []
        lines = text.split("\n")
        current = ""
        for line in lines:
            if len(current) + len(line) + 1 > limit:
                if current:
                    chunks.append(current.strip())
                current = line
            else:
                current = current + "\n" + line if current else line
        if current:
            chunks.append(current.strip())
        return chunks

    def format_for_surface(self, text: str) -> str:
        return text

    def add_open_channel(self, channel_id: str):
        """Add a channel where bot responds without @mention."""
        self.open_channels.add(channel_id)

    def remove_open_channel(self, channel_id: str):
        self.open_channels.discard(channel_id)
