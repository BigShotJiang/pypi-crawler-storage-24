from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Optional

from .base import BaseMigration, MigrationResult, ScanResult


class LangChainMigration(BaseMigration):
    """
    Migrates from LangChain conversation history to AntarisBot.

    Detection: scan for chat_history.json, *_history.json, message_store.db,
    or any SQLite with a message_store table.

    Memory import:
      - JSON format: read messages array, pair human/AI messages
      - SQLite format: read message_store table, extract content
    """

    def detect(self) -> bool:
        search_path = self.source_path
        if search_path.is_file():
            return self._is_langchain_file(search_path)

        # Scan directory for langchain artifacts
        if not search_path.exists():
            return False

        for pattern in ("chat_history.json", "*_history.json", "message_store.db"):
            if list(search_path.rglob(pattern)):
                return True

        # Check SQLite files for message_store table
        for sqlite_file in search_path.rglob("*.db"):
            if self._has_message_store_table(sqlite_file):
                return True
        for sqlite_file in search_path.rglob("*.sqlite"):
            if self._has_message_store_table(sqlite_file):
                return True

        return False

    def scan(self) -> ScanResult:
        result = ScanResult()
        files = self._find_langchain_files()
        result.memory_count = len(files)
        for f in files:
            result.notes.append(f"Found: {f}")
        return result

    def migrate(self, selections: Optional[list[str]] = None) -> MigrationResult:
        result = MigrationResult(success=True, source="LangChain")
        texts: list[str] = []

        # Handle single-file source
        if self.source_path.is_file():
            file_texts = self._extract_from_file(self.source_path, result)
            texts.extend(file_texts)
        else:
            files = self._find_langchain_files()
            if not files:
                result.success = False
                result.errors.append(
                    "No LangChain chat history files found. "
                    "Expected chat_history.json, *_history.json, or message_store.db."
                )
                return result
            for f in files:
                file_texts = self._extract_from_file(f, result)
                texts.extend(file_texts)

        if not texts:
            result.warnings.append("No conversation content extracted")
            result.items_migrated["memories"] = 0
            return result

        count = self._import_memories(texts, self.user_id, source="langchain-import")
        result.items_migrated["memories"] = count
        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _find_langchain_files(self) -> list[Path]:
        """Find all LangChain history files in source_path."""
        found: list[Path] = []
        search = self.source_path if self.source_path.is_dir() else self.source_path.parent

        for pattern in ("chat_history.json", "*_history.json"):
            found.extend(search.rglob(pattern))

        for pattern in ("message_store.db",):
            found.extend(search.rglob(pattern))

        for sqlite_file in search.rglob("*.db"):
            if sqlite_file not in found and self._has_message_store_table(sqlite_file):
                found.append(sqlite_file)
        for sqlite_file in search.rglob("*.sqlite"):
            if sqlite_file not in found and self._has_message_store_table(sqlite_file):
                found.append(sqlite_file)

        return list(dict.fromkeys(found))  # deduplicate, preserve order

    def _is_langchain_file(self, path: Path) -> bool:
        """Check if a single file is a LangChain history file."""
        suffix = path.suffix.lower()
        if suffix == ".json":
            try:
                import json
                data = json.loads(path.read_text())
                return (
                    isinstance(data, dict) and "messages" in data
                    or isinstance(data, list) and any(
                        isinstance(m, dict) and "type" in m for m in data[:3]
                    )
                )
            except Exception:
                return False
        if suffix in (".db", ".sqlite"):
            return self._has_message_store_table(path)
        return False

    def _has_message_store_table(self, path: Path) -> bool:
        """Check if SQLite file has a message_store table."""
        try:
            conn = sqlite3.connect(str(path))
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            conn.close()
            return "message_store" in tables
        except Exception:
            return False

    def _extract_from_file(self, path: Path, result: MigrationResult) -> list[str]:
        """Extract text from a LangChain file. Returns list of text strings."""
        suffix = path.suffix.lower()
        if suffix == ".json":
            return self._extract_from_json(path, result)
        if suffix in (".db", ".sqlite") or path.stem == "message_store":
            return self._extract_from_sqlite(path, result)
        return []

    def _extract_from_json(self, path: Path, result: MigrationResult) -> list[str]:
        """Extract conversation text from a LangChain JSON file."""
        import json
        try:
            data = json.loads(path.read_text())
        except Exception as e:
            result.warnings.append(f"Could not parse {path.name}: {e}")
            return []

        messages: list[dict] = []
        if isinstance(data, dict) and "messages" in data:
            messages = data["messages"]
        elif isinstance(data, list):
            messages = data

        texts: list[str] = []
        # Pair human/AI messages into conversation turns
        human_msg: Optional[str] = None
        for msg in messages:
            if not isinstance(msg, dict):
                continue
            msg_type = msg.get("type", msg.get("role", "")).lower()
            content = msg.get("content", msg.get("data", {}) if isinstance(msg.get("data"), str) else "")
            if isinstance(content, dict):
                content = content.get("content", "")
            content = str(content).strip()
            if not content:
                continue

            if msg_type in ("human", "user"):
                human_msg = content
            elif msg_type in ("ai", "assistant") and human_msg:
                texts.append(f"User: {human_msg}\nAssistant: {content}")
                human_msg = None
            elif msg_type in ("ai", "assistant"):
                texts.append(f"Assistant: {content}")
            else:
                # Generic message
                if human_msg:
                    texts.append(f"User: {human_msg}\nMessage: {content}")
                    human_msg = None
                else:
                    texts.append(content)

        # Flush any trailing human message
        if human_msg:
            texts.append(f"User: {human_msg}")

        return texts

    def _extract_from_sqlite(self, path: Path, result: MigrationResult) -> list[str]:
        """Extract messages from a SQLite message_store table."""
        try:
            conn = sqlite3.connect(str(path))
            rows = conn.execute(
                "SELECT session_id, message FROM message_store ORDER BY rowid"
            ).fetchall()
            conn.close()
        except Exception as e:
            result.warnings.append(f"Could not read {path.name}: {e}")
            return []

        texts: list[str] = []
        import json as _json
        for session_id, raw_msg in rows:
            try:
                msg = _json.loads(raw_msg) if isinstance(raw_msg, str) else raw_msg
                content = (
                    msg.get("data", {}).get("content", "")
                    if isinstance(msg, dict) else str(msg)
                )
                if content:
                    texts.append(str(content).strip())
            except Exception:
                if raw_msg:
                    texts.append(str(raw_msg).strip())

        return texts
