from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Optional

from .base import BaseMigration, MigrationResult, ScanResult


class CustomMigration(BaseMigration):
    """
    Import from an arbitrary path by sniffing the format.

    Format sniffing rules:
      - .json with messages array      -> LangChain format
      - .json with memories array      -> mem0 export
      - .json with soul/user keys      -> AntarisBot/OpenClaw export
      - .jsonl with content/text       -> generic memory dump
      - .sqlite / .db                  -> check tables for format
      - .md file                       -> identity or daily log
      - dir with shards/ + search_index.json -> native antaris-memory
      - dir with openclaw.json         -> redirect to OpenClawMigration
      - dir with .lance subdirs        -> redirect to LanceDBMigration
    """

    def detect(self) -> bool:
        target = Path(self.source_path)
        if not target.exists():
            return False
        if target.is_file():
            return self._sniff_file(target) is not None
        if target.is_dir():
            return self._sniff_dir(target) is not None
        return False

    def scan(self) -> ScanResult:
        result = ScanResult()
        fmt = self._detect_format()
        if fmt:
            result.notes.append(f"Detected format: {fmt}")
        return result

    def migrate(self, selections: Optional[list[str]] = None) -> MigrationResult:
        fmt = self._detect_format()
        if not fmt:
            return MigrationResult(
                success=False,
                source="custom",
                errors=["Could not detect file format. Supported: JSON, JSONL, SQLite, Markdown, native antaris-memory directory, openclaw directory."],
            )

        # Redirect to specialized migrators when we can
        if fmt == "openclaw_dir":
            from .openclaw import OpenClawMigration
            m = OpenClawMigration(
                str(self.source_path), str(self.dest_path),
                dry_run=self.dry_run, user_id=self.user_id,
            )
            return m.migrate(selections)

        if fmt == "lancedb_dir":
            from .lancedb import LanceDBMigration
            m = LanceDBMigration(
                str(self.source_path), str(self.dest_path),
                dry_run=self.dry_run, user_id=self.user_id,
            )
            return m.migrate(selections)

        if fmt == "langchain_json":
            from .langchain import LangChainMigration
            m = LangChainMigration(
                str(self.source_path), str(self.dest_path),
                dry_run=self.dry_run, user_id=self.user_id,
            )
            return m.migrate(selections)

        if fmt == "mem0_json":
            return self._migrate_mem0_export()

        if fmt == "antaris_json":
            return self._migrate_antaris_export()

        if fmt == "jsonl":
            return self._migrate_jsonl()

        if fmt == "sqlite":
            return self._migrate_sqlite()

        if fmt == "markdown":
            return self._migrate_markdown()

        if fmt == "native_antaris_dir":
            return self._migrate_native_antaris_dir()

        return MigrationResult(
            success=False,
            source="custom",
            errors=[f"No handler for detected format: {fmt}"],
        )

    # ------------------------------------------------------------------
    # Format detection
    # ------------------------------------------------------------------

    def _detect_format(self) -> Optional[str]:
        target = Path(self.source_path)
        if target.is_file():
            return self._sniff_file(target)
        if target.is_dir():
            return self._sniff_dir(target)
        return None

    def _sniff_file(self, path: Path) -> Optional[str]:
        """Return format string for a single file, or None."""
        suffix = path.suffix.lower()

        if suffix == ".json":
            return self._sniff_json_file(path)

        if suffix == ".jsonl":
            return "jsonl"

        if suffix in (".db", ".sqlite"):
            return "sqlite"

        if suffix == ".md":
            return "markdown"

        return None

    def _sniff_json_file(self, path: Path) -> Optional[str]:
        """Determine JSON variant."""
        try:
            data = json.loads(path.read_text())
        except Exception:
            return None

        if isinstance(data, dict):
            if "messages" in data:
                return "langchain_json"
            if "memories" in data and isinstance(data["memories"], list):
                # Could be mem0 export or antaris export
                first = data["memories"][0] if data["memories"] else {}
                if isinstance(first, dict) and ("text" in first or "memory" in first):
                    return "mem0_json"
                return "antaris_json"
            if "soul" in data or "user" in data:
                return "antaris_json"
            if "entries" in data and isinstance(data.get("entries"), list):
                return "antaris_json"

        if isinstance(data, list) and data:
            first = data[0]
            if isinstance(first, dict):
                if "type" in first and first.get("type") in ("human", "ai", "user", "assistant"):
                    return "langchain_json"
                if "text" in first or "content" in first or "memory" in first:
                    return "mem0_json"

        return "antaris_json"  # generic JSON, try as antaris export

    def _sniff_dir(self, path: Path) -> Optional[str]:
        """Return format string for a directory."""
        # native antaris-memory: has shards/ + search_index.json
        if (path / "shards").exists() and (path / "search_index.json").exists():
            return "native_antaris_dir"

        # OpenClaw directory
        if (path / "openclaw.json").exists():
            return "openclaw_dir"
        if (path / "SOUL.md").exists() or (path / "AGENTS.md").exists():
            return "openclaw_dir"

        # LanceDB directory
        if (path / ".lancedb").exists():
            return "lancedb_dir"
        if list(path.glob("*.lance")):
            return "lancedb_dir"

        return None

    # ------------------------------------------------------------------
    # Format handlers
    # ------------------------------------------------------------------

    def _migrate_antaris_export(self) -> MigrationResult:
        """Handle antaris/custom JSON export format."""
        result = MigrationResult(success=True, source="custom")
        try:
            data = json.loads(Path(self.source_path).read_text())
        except Exception as e:
            result.success = False
            result.errors.append(f"Could not parse import file: {e}")
            return result

        dest = self.dest_path

        if "soul" in data:
            self._write(dest / "SOUL.md", data["soul"])
            result.items_migrated["soul"] = True

        if "user" in data:
            self._write(dest / "USER.md", data["user"])
            result.items_migrated["user"] = True

        # memories as list of strings
        memories_raw = data.get("memories", [])
        if memories_raw and isinstance(memories_raw, list):
            texts = [str(m) for m in memories_raw if m]
            count = self._import_memories(texts, self.user_id, source="custom-import")
            result.items_migrated["memories"] = count

        # entries from BotMemory.export_memories() format
        entries = data.get("entries", [])
        if entries and isinstance(entries, list):
            texts = [e.get("content", "") for e in entries if isinstance(e, dict) and e.get("content")]
            if texts:
                count = self._import_memories(texts, self.user_id, source="custom-import")
                result.items_migrated["memories"] = result.items_migrated.get("memories", 0) + count

        return result

    def _migrate_mem0_export(self) -> MigrationResult:
        """Handle mem0 JSON export format."""
        result = MigrationResult(success=True, source="custom (mem0 format)")
        try:
            data = json.loads(Path(self.source_path).read_text())
        except Exception as e:
            result.success = False
            result.errors.append(f"Could not parse import file: {e}")
            return result

        memories = data.get("memories", data if isinstance(data, list) else [])
        texts: list[str] = []
        for item in memories:
            if isinstance(item, dict):
                text = item.get("text") or item.get("memory") or item.get("content") or ""
                if text:
                    texts.append(str(text))
            elif isinstance(item, str):
                texts.append(item)

        if not texts:
            result.warnings.append("No memory text found in mem0 export")
            result.items_migrated["memories"] = 0
            return result

        count = self._import_memories(texts, self.user_id, source="mem0-custom-import")
        result.items_migrated["memories"] = count
        return result

    def _migrate_jsonl(self) -> MigrationResult:
        """Handle .jsonl memory dump."""
        result = MigrationResult(success=True, source="custom (JSONL)")
        try:
            lines = Path(self.source_path).read_text().strip().splitlines()
        except Exception as e:
            result.success = False
            result.errors.append(f"Could not read JSONL file: {e}")
            return result

        texts: list[str] = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                text = (
                    obj.get("content")
                    or obj.get("text")
                    or obj.get("message")
                    or obj.get("data")
                    or ""
                )
                if text:
                    texts.append(str(text))
            except Exception:
                texts.append(line)

        if not texts:
            result.warnings.append("No content found in JSONL file")
            result.items_migrated["memories"] = 0
            return result

        count = self._import_memories(texts, self.user_id, source="jsonl-import")
        result.items_migrated["memories"] = count
        return result

    def _migrate_sqlite(self) -> MigrationResult:
        """Handle SQLite database files."""
        from .langchain import LangChainMigration
        result = MigrationResult(success=True, source="custom (SQLite)")
        try:
            conn = sqlite3.connect(str(self.source_path))
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            conn.close()
        except Exception as e:
            result.success = False
            result.errors.append(f"Could not open SQLite file: {e}")
            return result

        if "message_store" in tables:
            # Delegate to LangChain
            lc = LangChainMigration(
                str(self.source_path), str(self.dest_path),
                dry_run=self.dry_run, user_id=self.user_id,
            )
            return lc.migrate()

        # Generic: read all text-like columns from all tables
        texts: list[str] = []
        try:
            conn = sqlite3.connect(str(self.source_path))
            for table in tables:
                try:
                    rows = conn.execute(f"SELECT * FROM {table} LIMIT 10000").fetchall()
                    desc = conn.execute(f"SELECT * FROM {table} LIMIT 0").description or []
                    col_names = [d[0].lower() for d in desc]
                    text_cols = [i for i, n in enumerate(col_names) if n in ("text", "content", "message", "data", "body")]
                    for row in rows:
                        for ci in text_cols:
                            if ci < len(row) and row[ci] and isinstance(row[ci], str):
                                texts.append(row[ci].strip())
                except Exception:
                    continue
            conn.close()
        except Exception as e:
            result.success = False
            result.errors.append(f"Could not read SQLite tables: {e}")
            return result

        if not texts:
            result.warnings.append("No text content found in SQLite database")
            result.items_migrated["memories"] = 0
            return result

        count = self._import_memories(texts, self.user_id, source="sqlite-import")
        result.items_migrated["memories"] = count
        return result

    def _migrate_markdown(self) -> MigrationResult:
        """Handle a single markdown file (identity or daily log)."""
        result = MigrationResult(success=True, source="custom (Markdown)")
        path = Path(self.source_path)
        name = path.name

        # Identity file by name
        identity_names = {n.lower(): n for n in self.IDENTITY_FILES}
        if name.lower() in identity_names:
            dest = self.dest_path / identity_names[name.lower()]
            self._copy_file(path, dest)
            result.items_migrated[name.lower().replace(".md", "")] = True
            return result

        # Daily log: YYYY-MM-DD.md pattern
        import re
        if re.match(r"^\d{4}-\d{2}-\d{2}\.md$", name):
            dest = self.dest_path / "memory" / name
            self._copy_file(path, dest)
            result.items_migrated["daily_log"] = name
            return result

        # Unknown .md: treat as identity file, write to dest
        dest = self.dest_path / name
        self._copy_file(path, dest)
        result.items_migrated["file"] = name
        return result

    def _migrate_native_antaris_dir(self) -> MigrationResult:
        """Copy native antaris-memory shard directory to dest."""
        import shutil
        result = MigrationResult(success=True, source="custom (native antaris-memory)")
        src = self.source_path
        dest_user = self.dest_path / "memory" / self.user_id

        if self.dry_run:
            files = list(src.rglob("*"))
            count = len([f for f in files if f.is_file()])
            print(f"  [dry-run] would copy {count} shard files from {src}")
            result.items_migrated["memories"] = count
            return result

        dest_user.mkdir(parents=True, exist_ok=True)
        count = 0
        for f in src.rglob("*"):
            if f.is_file():
                rel = f.relative_to(src)
                target = dest_user / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(f), str(target))
                count += 1

        result.items_migrated["memories"] = count
        return result
