from __future__ import annotations

import json
import shutil
import sqlite3
from pathlib import Path
from typing import Optional

from .base import BaseMigration, MigrationResult, ScanResult


# Default context cadence for identity files
DEFAULT_CONTEXT_CADENCE: dict = {
    "SOUL.md": "every",
    "AGENTS.md": "every",
    "MEMORY.md": "startup",
    "TOOLS.md": "startup",
    "USER.md": "manual",
}


class OpenClawMigration(BaseMigration):
    """
    Migrates from OpenClaw to AntarisBot.

    Sources:
      - Identity files: SOUL.md, AGENTS.md, MEMORY.md, TOOLS.md, USER.md,
        HEARTBEAT.md, IDENTITY.md from ~/.openclaw/workspace/
      - Config: ~/.openclaw/openclaw.json (provider, channels, models)
      - Native antaris-memory shards if antaris-suite plugin exists
      - OpenClaw built-in session memory from ~/.openclaw/memory/main.sqlite
      - Daily logs from workspace/memory/*.md

    Detection: checks for openclaw.json OR SOUL.md/AGENTS.md in source_path.
    """

    def __init__(
        self,
        source_path: str,
        dest_path: str,
        dry_run: bool = False,
        user_id: str = "migrated-user",
    ):
        super().__init__(source_path, dest_path, dry_run, user_id)
        # Resolve openclaw.json location
        self._openclaw_json = self._find_openclaw_json()

    def _find_openclaw_json(self) -> Optional[Path]:
        """Try several locations for openclaw.json.

        Looks relative to source_path first, then falls back to the standard
        ~/.openclaw/openclaw.json location (only when source_path is itself
        inside ~/.openclaw/).
        """
        candidates: list[Path] = [
            self.source_path / "openclaw.json",
            self.source_path.parent / "openclaw.json",
        ]
        # Only check the global location if source_path is under ~/.openclaw/
        openclaw_root = Path.home() / ".openclaw"
        try:
            self.source_path.relative_to(openclaw_root)
            candidates.append(openclaw_root / "openclaw.json")
        except ValueError:
            pass  # source_path is NOT under ~/.openclaw/, skip global lookup

        for c in candidates:
            if c.exists():
                return c
        return None

    def detect(self) -> bool:
        """Return True if openclaw.json exists near source_path, or workspace has SOUL/AGENTS."""
        if self._openclaw_json and self._openclaw_json.exists():
            return True
        if not self.source_path.exists():
            return False
        if (self.source_path / "SOUL.md").exists():
            return True
        if (self.source_path / "AGENTS.md").exists():
            return True
        return False

    def scan(self) -> ScanResult:
        result = ScanResult()

        # Identity files present: check both root and workspace/ subdirectory
        workspace_dir = self.source_path / "workspace"
        for name in self.IDENTITY_FILES:
            if (self.source_path / name).exists():
                result.identity_files.append(name)
            elif workspace_dir.exists() and (workspace_dir / name).exists():
                result.identity_files.append(name)

        # Config
        result.has_config = self._openclaw_json is not None

        # Channels
        if self._openclaw_json:
            try:
                cfg = json.loads(self._openclaw_json.read_text())
                channels = cfg.get("channels", {})
                result.has_channels = bool(channels)
            except Exception:
                pass

        # Memory count estimate
        memory_count = 0
        workspace_mem = self.source_path / "memory"
        if workspace_mem.exists():
            memory_count += len(list(workspace_mem.glob("*.md")))

        # antaris-suite shards
        openclaw_root = Path.home() / ".openclaw"
        is_openclaw_src = False
        try:
            self.source_path.relative_to(openclaw_root)
            is_openclaw_src = True
        except ValueError:
            pass

        shard_check_paths: list[Path] = [self.source_path / "antaris_memory_store"]
        if is_openclaw_src:
            shard_check_paths.insert(0, openclaw_root / "extensions" / "antaris-suite")

        for shard_path in shard_check_paths:
            if shard_path.exists():
                memory_count += len(list(shard_path.rglob("*.json")))
                result.notes.append(f"Native antaris-memory shards at {shard_path}")

        # SQLite session memory (only when source is under ~/.openclaw/)
        sqlite_path = openclaw_root / "memory" / "main.sqlite"
        if is_openclaw_src and sqlite_path.exists():
            try:
                conn = sqlite3.connect(str(sqlite_path))
                cur = conn.execute("SELECT COUNT(*) FROM chunks")
                memory_count += cur.fetchone()[0]
                conn.close()
                result.notes.append("OpenClaw SQLite session memory found")
            except Exception:
                pass

        result.memory_count = memory_count
        return result

    def migrate(self, selections: Optional[list[str]] = None) -> MigrationResult:
        result = MigrationResult(success=True, source="OpenClaw")

        # Load openclaw config if available
        openclaw_cfg: dict = {}
        if self._openclaw_json:
            try:
                openclaw_cfg = json.loads(self._openclaw_json.read_text())
            except Exception as e:
                result.warnings.append(f"Could not read openclaw.json: {e}")

        # 1. Identity files
        self._do_identity_files(result, openclaw_cfg)

        # 2. Config translation
        if openclaw_cfg:
            self._do_config_translation(result, openclaw_cfg)

        # 3. OpenClaw Cron Translation
        cron_count = self._migrate_openclaw_crons(self.source_path)
        if cron_count > 0:
            result.items_migrated["cron_jobs"] = cron_count

        # 4. JS Tool Auto-Detection  
        tool_count = self._migrate_openclaw_tools(self.source_path)
        if tool_count > 0:
            result.items_migrated["js_tools"] = tool_count

        # 5. OpenClaw Plugin Config Translation
        if openclaw_cfg:
            self._migrate_plugin_config(result, openclaw_cfg)

        # 6. Memory import
        self._do_memory_import(result, openclaw_cfg)

        return result

    # ------------------------------------------------------------------
    # Step: identity files
    # ------------------------------------------------------------------

    def _resolve_identity_file(self, name: str) -> Optional[Path]:
        """Find an identity file in source_path or source_path/workspace/."""
        direct = self.source_path / name
        if direct.exists():
            return direct
        workspace = self.source_path / "workspace" / name
        if workspace.exists():
            return workspace
        return None

    def _do_identity_files(self, result: MigrationResult, openclaw_cfg: dict):
        """Copy identity markdown files to dest."""
        # SOUL.md (special: merge IDENTITY.md into it)
        soul_src = self._resolve_identity_file("SOUL.md")
        if soul_src:
            content = soul_src.read_text()
            identity_src = self._resolve_identity_file("IDENTITY.md")
            if identity_src:
                content += f"\n\n---\n## Identity\n{identity_src.read_text()}"
            self._write(self.dest_path / "SOUL.md", content)
            result.items_migrated["soul"] = True
        else:
            result.items_migrated["soul"] = False
            result.warnings.append("No SOUL.md found in source")

        # USER.md
        user_src = self._resolve_identity_file("USER.md")
        if user_src:
            self._write(self.dest_path / "USER.md", user_src.read_text())
            result.items_migrated["user"] = True
        else:
            result.items_migrated["user"] = False

        # Other identity files
        for name in ("AGENTS.md", "MEMORY.md", "TOOLS.md", "HEARTBEAT.md"):
            src = self._resolve_identity_file(name)
            if src:
                self._copy_file(src, self.dest_path / name)
                result.items_migrated[name.lower().replace(".md", "")] = True

        # context.json
        context_dest = self.dest_path / "context.json"
        if not context_dest.exists() or self.dry_run:
            self._write(context_dest, json.dumps(DEFAULT_CONTEXT_CADENCE, indent=2))
            result.items_migrated["context_json"] = True

    # ------------------------------------------------------------------
    # Step: config translation
    # ------------------------------------------------------------------

    def _do_config_translation(self, result: MigrationResult, openclaw_cfg: dict):
        """Translate openclaw.json into AntarisBot config.json + router/config.json."""
        antaris_cfg = self._translate_config(openclaw_cfg)

        config_dest = self.dest_path / "config.json"
        if not config_dest.exists() or self.dry_run:
            self._write(config_dest, json.dumps(antaris_cfg, indent=2))
            result.items_migrated["config"] = True
        else:
            result.items_migrated["config"] = False
            result.warnings.append("config.json already exists, skipped (use --all to overwrite)")

        # router/config.json
        router_cfg = self._translate_router_config(openclaw_cfg)
        if router_cfg.get("models"):
            router_dest = self.dest_path / "router" / "config.json"
            if not router_dest.exists() or self.dry_run:
                self._write(router_dest, json.dumps(router_cfg, indent=2))
                result.items_migrated["router_config"] = True

        # Report discord token status
        discord_cfg = antaris_cfg.get("channels", {}).get("discord", {})
        if discord_cfg.get("token"):
            result.items_migrated["discord_token"] = "found"
        else:
            result.items_migrated["discord_token"] = False

    # ------------------------------------------------------------------
    # Step: memory import
    # ------------------------------------------------------------------

    def _do_memory_import(self, result: MigrationResult, openclaw_cfg: dict):
        """Import memories from all available sources."""
        memory_count = 0

        # Resolve user_id: use allowlist from discord config if available
        user_id = self.user_id
        if user_id == "migrated-user" and openclaw_cfg:
            allowlist = (
                openclaw_cfg.get("channels", {})
                .get("discord", {})
                .get("allowlist", [])
            )
            if allowlist:
                user_id = str(allowlist[0])
                result.warnings.append(
                    f"Assigned memories to user_id={user_id} (first Discord allowlist entry). "
                    "Use --user-id to override."
                )

        # 1. Native antaris-memory shards
        # Only check system paths when source_path is itself under ~/.openclaw/
        openclaw_root = Path.home() / ".openclaw"
        is_openclaw_source = False
        try:
            self.source_path.relative_to(openclaw_root)
            is_openclaw_source = True
        except ValueError:
            pass

        shard_candidates: list[Path] = [
            self.source_path / "antaris_memory_store",
            self.source_path / "workspace" / "antaris_memory_store",
        ]
        if is_openclaw_source:
            shard_candidates.insert(0, openclaw_root / "extensions" / "antaris-suite")
            shard_candidates.insert(1, openclaw_root / "workspace" / "antaris_memory_store")
        # Deduplicate by resolved path
        seen: set[str] = set()
        shard_paths: list[Path] = []
        for p in shard_candidates:
            resolved = str(p.resolve())
            if resolved not in seen:
                seen.add(resolved)
                shard_paths.append(p)

        for shard_src in shard_paths:
            if shard_src.exists():
                count = self._import_native_shards(shard_src, user_id)
                if count > 0:
                    memory_count += count
                    result.items_migrated["native_shards"] = count

        # 2. SQLite session memory (only when source is under ~/.openclaw/)
        sqlite_path = Path.home() / ".openclaw" / "memory" / "main.sqlite"
        if is_openclaw_source and sqlite_path.exists():
            count = self._import_sqlite_memory(sqlite_path, user_id)
            if count > 0:
                memory_count += count
                result.items_migrated["sqlite_memories"] = count

        # 3. Daily log markdown files (check both root/memory and workspace/memory)
        daily_log_dirs = [
            self.source_path / "workspace" / "memory",
            self.source_path / "memory",
        ]
        daily_imported = False
        for workspace_mem in daily_log_dirs:
            if workspace_mem.exists() and any(workspace_mem.glob("*.md")):
                count = self._copy_daily_logs(workspace_mem)
                if count > 0:
                    memory_count += count
                    result.items_migrated["daily_logs"] = count
                    daily_imported = True
                    break
        if not daily_imported:
            result.warnings.append("No daily log .md files found in source")

        result.items_migrated["memories"] = memory_count
        if memory_count == 0:
            result.warnings.append("No memories were imported")

    def _import_native_shards(self, shard_src: Path, user_id: str) -> int:
        """Copy native antaris-memory shards directly to dest memory dir."""
        dest_user = self.dest_path / "memory" / user_id
        if self.dry_run:
            files = list(shard_src.rglob("*"))
            count = len([f for f in files if f.is_file()])
            print(f"  [dry-run] would copy {count} shard files from {shard_src}")
            return count
        dest_user.mkdir(parents=True, exist_ok=True)
        count = 0
        for f in shard_src.rglob("*"):
            if f.is_file():
                rel = f.relative_to(shard_src)
                target = dest_user / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(f), str(target))
                count += 1
        return count

    def _import_sqlite_memory(self, sqlite_path: Path, user_id: str) -> int:
        """Read chunks table from OpenClaw SQLite memory, ingest via MemorySystem."""
        try:
            conn = sqlite3.connect(str(sqlite_path))
            rows = conn.execute("SELECT text FROM chunks").fetchall()
            conn.close()
            texts = [r[0] for r in rows if r[0] and r[0].strip()]
            if not texts:
                return 0
            return self._import_memories(texts, user_id, source="openclaw-sqlite")
        except Exception as e:
            print(f"  ⚠️  Could not read SQLite memory: {e}")
            return 0

    def _copy_daily_logs(self, memory_src: Path) -> int:
        """Copy workspace memory/*.md files to dest memory dir."""
        dest_mem = self.dest_path / "memory"
        if self.dry_run:
            files = [f for f in memory_src.glob("*.md") if f.is_file()]
            print(f"  [dry-run] would copy {len(files)} daily log files")
            return len(files)
        dest_mem.mkdir(parents=True, exist_ok=True)
        count = 0
        for f in memory_src.glob("*.md"):
            if f.is_file():
                shutil.copy2(str(f), str(dest_mem / f.name))
                count += 1
        return count

    def _migrate_openclaw_crons(self, openclaw_path: Path) -> int:
        """
        Migrate OpenClaw cron jobs to AntarisBot format.
        
        Reads OpenClaw cron data and translates to Antaris CronJob format:
        - Maps everyMs -> schedule_every_ms
        - Maps at -> schedule_at (ISO timestamp)  
        - Maps cron expressions -> approximate every intervals with preserved original
        - Maps systemEvent.text and agentTurn.message -> payload_text
        - Warns when time-of-day information is lost in cron->every conversion
        
        Returns count of translated jobs.
        """
        from datetime import datetime, timezone
        import time
        import re
        import logging
        
        logger = logging.getLogger(__name__)
        
        # Check for OpenClaw cron data - derive from source_path when provided
        if hasattr(self, 'source_path') and self.source_path:
            base_path = Path(self.source_path)
        else:
            base_path = openclaw_path
            
        cron_candidates = [
            base_path / "cron.json",
            base_path / "data" / "cron.json",
            Path.home() / ".openclaw" / "data" / "cron.json",
        ]
        
        cron_file = None
        for candidate in cron_candidates:
            if candidate.exists():
                cron_file = candidate
                break
                
        if not cron_file:
            return 0
            
        try:
            cron_data = json.loads(cron_file.read_text())
        except Exception:
            return 0
            
        # Extract jobs from OpenClaw format
        jobs = cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data
        if not jobs:
            return 0
            
        # Import CronJob dataclass to ensure we match the expected structure
        try:
            from ..core.cron import CronJob
        except ImportError:
            logger.warning("Could not import CronJob dataclass, using dict format")
            CronJob = None
            
        translated_jobs = []
        
        for job in jobs:
            if not isinstance(job, dict):
                continue
                
            schedule = job.get("schedule", {})
            payload = job.get("payload", {})
            
            # Build job data matching CronJob dataclass fields
            job_data = {
                "id": job.get("id", f"openclaw-{len(translated_jobs)}"),
                "name": job.get("name", "Migrated OpenClaw job"),
                "enabled": job.get("enabled", True),
                "last_run": None,
                "run_count": 0,
                "created_at": time.time(),
                "schedule_kind": "every",  # Default, will be overridden
                "schedule_every_ms": None,
                "schedule_at": None,
                "schedule_cron": None,
                "payload_kind": payload.get("kind", "systemEvent"),
                "payload_text": "",
                "channel_id": None,  # Not available in OpenClaw format
            }
            
            # Handle schedule translation
            schedule_kind = schedule.get("kind", "every")
            
            if schedule_kind == "every":
                every_ms = schedule.get("everyMs", 3600000)  # default 1 hour
                job_data["schedule_kind"] = "every"
                job_data["schedule_every_ms"] = every_ms
                
            elif schedule_kind == "at":
                at_time = schedule.get("at", "")
                job_data["schedule_kind"] = "at" 
                job_data["schedule_at"] = at_time
                
            elif schedule_kind == "cron":
                # Convert cron expression to approximate every interval (best effort)
                cron_expr = schedule.get("expr", "0 * * * *")  # default hourly
                
                # Simple cron-to-interval mapping (best effort)
                interval_ms = 3600000  # default 1 hour
                time_specific = False  # Track if we're losing time-of-day info
                
                # Parse common patterns
                if cron_expr.startswith("*/"):
                    # */N pattern in minutes field
                    match = re.match(r"\*/(\d+) \* \* \* \*", cron_expr)
                    if match:
                        minutes = int(match.group(1))
                        interval_ms = minutes * 60 * 1000
                elif " */" in cron_expr:
                    # Pattern in hours field  
                    match = re.match(r"\* \*/(\d+) \* \* \*", cron_expr)
                    if match:
                        hours = int(match.group(1))
                        interval_ms = hours * 3600 * 1000
                elif re.match(r"\d+ \d+ \* \* \*", cron_expr):
                    # Daily pattern: "minute hour * * *" (e.g., "0 18 * * *")
                    # This loses time-of-day information!
                    interval_ms = 24 * 3600 * 1000
                    time_specific = True
                    match = re.match(r"(\d+) (\d+) \* \* \*", cron_expr)
                    if match:
                        minute, hour = match.groups()
                        logger.warning(
                            f"Cron job '{job_data['name']}' scheduled for {hour}:{minute:0>2} daily. "
                            f"Converting to 24-hour interval starting at bot start time. "
                            f"Original cron: '{cron_expr}'"
                        )
                elif cron_expr == "0 0 * * 0":
                    # Weekly at midnight Sunday - also time-specific
                    interval_ms = 7 * 24 * 3600 * 1000
                    time_specific = True
                    logger.warning(
                        f"Cron job '{job_data['name']}' scheduled for Sunday midnight. "
                        f"Converting to 7-day interval starting at bot start time. "
                        f"Original cron: '{cron_expr}'"
                    )
                
                job_data["schedule_kind"] = "every"  # Convert to every
                job_data["schedule_every_ms"] = interval_ms
                job_data["schedule_cron"] = cron_expr  # Keep original for reference
                
            # Handle payload translation
            payload_kind = job_data["payload_kind"]
            
            if payload_kind == "systemEvent":
                job_data["payload_text"] = payload.get("text", "")
            elif payload_kind == "agentTurn":
                job_data["payload_text"] = payload.get("message", "")
            else:
                job_data["payload_text"] = str(payload)
            
            # Create CronJob instance if available, otherwise use dict
            if CronJob:
                try:
                    cron_job = CronJob(**job_data)
                    translated_jobs.append(cron_job.to_dict())
                except Exception as e:
                    logger.warning(f"Failed to create CronJob instance: {e}, using dict")
                    translated_jobs.append(job_data)
            else:
                translated_jobs.append(job_data)
            
        if not translated_jobs:
            return 0
            
        # Save translated jobs to Antaris location
        antaris_cron_dir = self.dest_path / "cron"
        if not self.dry_run:
            antaris_cron_dir.mkdir(parents=True, exist_ok=True)
            
            jobs_file = antaris_cron_dir / "jobs.json"
            jobs_data = {"jobs": translated_jobs}
            self._write(jobs_file, json.dumps(jobs_data, indent=2))
            
        return len(translated_jobs)

    def _migrate_openclaw_tools(self, openclaw_path: Path) -> int:
        """
        Auto-detect JS tool extensions from OpenClaw.
        
        Scans extensions directory for package.json files and creates
        JS bridge config entries for detected tool extensions.
        
        Returns count of detected tools.
        """
        import re
        
        # Derive extensions directory from source_path when provided
        if hasattr(self, 'source_path') and self.source_path:
            # Try to derive from source_path first
            source_parent = Path(self.source_path).parent
            if (source_parent / "extensions").exists():
                extensions_dir = source_parent / "extensions"
            elif Path(self.source_path).name == "workspace" and (source_parent / "extensions").exists():
                extensions_dir = source_parent / "extensions"
            else:
                # Fall back to standard OpenClaw location
                extensions_dir = Path.home() / ".openclaw" / "extensions"
        else:
            # Default behavior when no source_path
            extensions_dir = Path.home() / ".openclaw" / "extensions"
        
        if not extensions_dir.exists():
            return 0
            
        detected_tools = []
        
        for ext_dir in extensions_dir.iterdir():
            if not ext_dir.is_dir():
                continue
                
            package_json = ext_dir / "package.json"
            if not package_json.exists():
                continue
                
            try:
                package_data = json.loads(package_json.read_text())
            except Exception:
                continue
                
            # Check if extension exports tools (has main field)
            main_file = package_data.get("main", "")
            if not main_file:
                continue
                
            # Skip extensions that are clearly not tools - use word boundary matching
            ext_name = ext_dir.name.lower()
            skip_patterns = [
                r"\bmemory\b", r"\bhook\b", r"\bbridge\b", r"\bauth\b", 
                r"\bmiddleware\b", r"\blistener\b", r"\bwebhook\b"
            ]
            
            # Check for plugin as exact suffix/prefix or standalone word
            plugin_skip_patterns = [
                r"\bplugin\b",           # standalone word "plugin"
                r"^plugin-",             # prefix "plugin-something" 
                r"-plugin$",             # suffix "something-plugin"
                r"^plugin$"              # exact match "plugin"
            ]
            
            skip_this = False
            for pattern in skip_patterns + plugin_skip_patterns:
                if re.search(pattern, ext_name):
                    skip_this = True
                    break
                    
            if skip_this:
                continue
                
            # Build JS bridge config entry
            tool_entry = {
                "name": ext_dir.name,  # Use original case
                "script_path": str(ext_dir / main_file),
                "detected_from": "openclaw",
                "auto_detected": True
            }
            
            detected_tools.append(tool_entry)
            
        if not detected_tools:
            return 0
            
        # Save JS bridge config  
        tools_dir = self.dest_path / "tools"
        if not self.dry_run:
            tools_dir.mkdir(parents=True, exist_ok=True)
            
            bridges_file = tools_dir / "js_bridges.json"
            bridges_data = {"bridges": detected_tools}
            self._write(bridges_file, json.dumps(bridges_data, indent=2))
            
        return len(detected_tools)

    def _migrate_plugin_config(self, result: MigrationResult, openclaw_cfg: dict) -> None:
        """
        Translate OpenClaw plugin configs to Antaris config.
        
        Maps plugin config entries to appropriate Antaris config sections:
        - agentName -> bot.name
        - searchLimit -> memory.searchLimit  
        - minRelevance -> memory.minRelevance
        - guardMode -> security.mode (with corrected mapping)
        - crossSessionRecall -> memory.crossSessionRecall
        - discordChannels -> channels.discord.openChannels
        - autoRecall -> memory.perTurnRecall
        - autoIngest -> memory.autoIngest (default true)
        
        Uses read-modify-write to safely merge with existing config.
        """
        plugins = openclaw_cfg.get("plugins", {}).get("entries", {})
        if not plugins:
            return
            
        # Load existing Antaris config safely
        config_file = self.dest_path / "config.json"
        antaris_cfg = {}
        
        if config_file.exists() and not self.dry_run:
            try:
                antaris_cfg = json.loads(config_file.read_text())
            except Exception as e:
                result.warnings.append(f"Could not read existing config.json: {e}")
                antaris_cfg = {}
            
        config_updated = False
        
        # Process each plugin's config
        for plugin_name, plugin_data in plugins.items():
            plugin_config = plugin_data.get("config", {})
            if not plugin_config:
                continue
                
            # Map agent name
            if "agentName" in plugin_config:
                antaris_cfg.setdefault("bot", {})["name"] = plugin_config["agentName"]
                config_updated = True
                
            # Map memory settings
            if "searchLimit" in plugin_config:
                antaris_cfg.setdefault("memory", {})["searchLimit"] = plugin_config["searchLimit"]
                config_updated = True
                
            if "minRelevance" in plugin_config:
                antaris_cfg.setdefault("memory", {})["minRelevance"] = plugin_config["minRelevance"]
                config_updated = True
                
            if "crossSessionRecall" in plugin_config:
                antaris_cfg.setdefault("memory", {})["crossSessionRecall"] = plugin_config["crossSessionRecall"]
                config_updated = True
                
            if "autoRecall" in plugin_config:
                antaris_cfg.setdefault("memory", {})["perTurnRecall"] = plugin_config["autoRecall"]
                config_updated = True
                
            if "autoIngest" in plugin_config:
                antaris_cfg.setdefault("memory", {})["autoIngest"] = plugin_config["autoIngest"]
                config_updated = True
            else:
                # Default autoIngest to true only if memory section doesn't already have it
                memory_section = antaris_cfg.setdefault("memory", {})
                if "autoIngest" not in memory_section:
                    memory_section["autoIngest"] = True
                    config_updated = True
                
            # Map security settings with corrected mapping
            if "guardMode" in plugin_config:
                guard_mode = plugin_config["guardMode"]
                security_mapping = {
                    "monitor": "standard",    # level 1
                    "warn": "secured",       # level 3
                    "block": "encrypted"     # level 4
                }
                if guard_mode in security_mapping:
                    antaris_cfg.setdefault("security", {})["mode"] = security_mapping[guard_mode]
                    config_updated = True
                    
            # Map Discord channels  
            if "discordChannels" in plugin_config:
                channels = plugin_config["discordChannels"]
                if isinstance(channels, list):
                    discord_section = antaris_cfg.setdefault("channels", {}).setdefault("discord", {})
                    discord_section["openChannels"] = channels
                    config_updated = True
                    
        if config_updated and not self.dry_run:
            self._write(config_file, json.dumps(antaris_cfg, indent=2))
            result.items_migrated["plugin_config"] = True
