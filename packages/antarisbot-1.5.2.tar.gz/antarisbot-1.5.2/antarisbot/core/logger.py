"""
AntarisBot — Structured Logging Setup

Provides:
  setup_logging(config_dir)  — configure root logger with console + rotating file
  get_logger(name)           — get a named logger (thin wrapper over logging.getLogger)
"""

import logging
import logging.handlers
import os
from pathlib import Path

_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"


def setup_logging(config_dir: str, level: str = "INFO") -> None:
    """Configure root logger with:
    - Console handler (StreamHandler) — INFO and above
    - Rotating file handler — DEBUG and above
      - Path: {config_dir}/logs/antarisbot.log
      - maxBytes: 5MB, backupCount: 3
    - Format: "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

    Safe to call multiple times — existing handlers are replaced.
    """
    log_dir = Path(config_dir) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "antarisbot.log"

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)  # capture everything; handlers filter

    fmt = logging.Formatter(_LOG_FORMAT)

    # ── Console handler: INFO and above ─────────────────────────────────────
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, level.upper(), logging.INFO))
    console_handler.setFormatter(fmt)

    # ── Rotating file handler: DEBUG and above ───────────────────────────────
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=5 * 1024 * 1024,  # 5 MB
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(fmt)

    # Replace any existing handlers to avoid duplicates on repeated calls
    root_logger.handlers.clear()
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)


def get_logger(name: str) -> logging.Logger:
    """Returns a named logger.  Call setup_logging() once at startup first."""
    return logging.getLogger(name)
