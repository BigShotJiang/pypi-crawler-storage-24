"""
AntarisBot Cron System — scheduled jobs for periodic tasks.

Job types:
    systemEvent — injects text as a system prompt into the pipeline
    agentTurn   — fires a prompt through the full pipeline as if a user sent it

Persistence: ~/.antarisbot/cron/jobs.json
"""
import asyncio
import json
import logging
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional, Callable, Awaitable

logger = logging.getLogger(__name__)


@dataclass
class CronJob:
    id: str
    name: str
    schedule_kind: str          # "every" | "at" | "cron"
    schedule_every_ms: Optional[int] = None   # for kind=every
    schedule_at: Optional[str] = None         # for kind=at (ISO timestamp)
    schedule_cron: Optional[str] = None       # for kind=cron (cron expression)
    payload_kind: str = "systemEvent"         # "systemEvent" | "agentTurn"
    payload_text: str = ""
    channel_id: Optional[str] = None         # which channel to deliver to
    enabled: bool = True
    last_run: Optional[float] = None         # epoch seconds
    run_count: int = 0
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "CronJob":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class CronScheduler:
    """
    Simple async cron scheduler for AntarisBot.

    Usage:
        scheduler = CronScheduler(jobs_path, on_fire_callback)
        await scheduler.start()          # runs in background
        scheduler.add_job(job)
        scheduler.remove_job(job_id)
        await scheduler.stop()
    """

    TICK_INTERVAL = 10  # check every 10 seconds

    def __init__(
        self,
        jobs_path: str | Path,
        on_fire: Callable[[CronJob], Awaitable[None]],
    ):
        self.jobs_path = Path(jobs_path)
        self.on_fire = on_fire
        self._jobs: dict[str, CronJob] = {}
        self._task: Optional[asyncio.Task] = None
        self._load()

    def _load(self):
        """Load jobs from disk."""
        if self.jobs_path.exists():
            try:
                data = json.loads(self.jobs_path.read_text())
                for job_dict in data.get("jobs", []):
                    job = CronJob.from_dict(job_dict)
                    self._jobs[job.id] = job
                logger.info("CronScheduler: loaded %d jobs", len(self._jobs))
            except Exception as e:
                logger.warning("CronScheduler: failed to load jobs: %s", e)

    def _save(self):
        """Persist jobs to disk."""
        self.jobs_path.parent.mkdir(parents=True, exist_ok=True)
        data = {"jobs": [j.to_dict() for j in self._jobs.values()]}
        self.jobs_path.write_text(json.dumps(data, indent=2))

    def add_job(self, job: CronJob) -> CronJob:
        """Add or replace a job."""
        self._jobs[job.id] = job
        self._save()
        logger.info("CronScheduler: added job %s (%s)", job.id, job.name)
        return job

    def remove_job(self, job_id: str) -> bool:
        """Remove a job by id."""
        if job_id in self._jobs:
            del self._jobs[job_id]
            self._save()
            logger.info("CronScheduler: removed job %s", job_id)
            return True
        return False

    def list_jobs(self) -> list[CronJob]:
        return list(self._jobs.values())

    def get_job(self, job_id: str) -> Optional[CronJob]:
        return self._jobs.get(job_id)

    def _is_due(self, job: CronJob) -> bool:
        """Check if a job is due to run."""
        if not job.enabled:
            return False
        now = time.time()
        if job.schedule_kind == "every":
            if not job.schedule_every_ms:
                return False
            interval_s = job.schedule_every_ms / 1000
            last = job.last_run or (now - interval_s)  # fire immediately if never run
            return (now - last) >= interval_s
        elif job.schedule_kind == "at":
            if not job.schedule_at or job.run_count > 0:
                return False  # one-shot, already fired
            try:
                from datetime import datetime, timezone
                target = datetime.fromisoformat(job.schedule_at.replace("Z", "+00:00"))
                return datetime.now(timezone.utc) >= target
            except Exception:
                return False
        # cron expression support deferred — just return False for now
        return False

    async def _tick(self):
        """Check all jobs and fire due ones."""
        for job in list(self._jobs.values()):
            if self._is_due(job):
                job.last_run = time.time()
                job.run_count += 1
                self._save()
                try:
                    await self.on_fire(job)
                    logger.info("CronScheduler: fired job %s (%s)", job.id, job.name)
                except Exception as e:
                    logger.error("CronScheduler: job %s failed: %s", job.id, e)

    async def _loop(self):
        """Main scheduler loop."""
        logger.info("CronScheduler: started")
        while True:
            try:
                await self._tick()
            except Exception as e:
                logger.error("CronScheduler tick error: %s", e)
            await asyncio.sleep(self.TICK_INTERVAL)

    async def start(self):
        """Start the scheduler in background."""
        self._task = asyncio.create_task(self._loop())

    async def stop(self):
        """Stop the scheduler."""
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("CronScheduler: stopped")

    def run_now(self, job_id: str) -> bool:
        """Trigger a job immediately (resets last_run)."""
        job = self._jobs.get(job_id)
        if not job:
            return False
        job.last_run = None  # force due
        return True
