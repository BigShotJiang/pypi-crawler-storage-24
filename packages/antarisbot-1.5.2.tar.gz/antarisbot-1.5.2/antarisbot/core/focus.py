"""Focus mode - project-aware context budgeting."""
import logging
import time
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class FocusSession:
    topic: str
    user_id: str
    started_at: float
    duration_seconds: float  # 0 = indefinite

    @property
    def is_expired(self) -> bool:
        if self.duration_seconds <= 0:
            return False
        return time.time() - self.started_at >= self.duration_seconds

    @property
    def remaining_minutes(self) -> int:
        if self.duration_seconds <= 0:
            return -1  # indefinite
        remaining = self.duration_seconds - (time.time() - self.started_at)
        return max(0, int(remaining / 60))


class FocusManager:
    """Manages per-user focus sessions."""

    def __init__(self):
        self._sessions: dict[str, FocusSession] = {}

    def start(self, user_id: str, topic: str, duration_minutes: int = 0) -> FocusSession:
        """Start a focus session. duration_minutes=0 means indefinite."""
        session = FocusSession(
            topic=topic,
            user_id=user_id,
            started_at=time.time(),
            duration_seconds=duration_minutes * 60,
        )
        self._sessions[user_id] = session
        logger.info("Focus started: user=%s topic=%s duration=%dm", user_id, topic, duration_minutes)
        return session

    def stop(self, user_id: str) -> bool:
        """Stop focus mode. Returns True if was active."""
        if user_id in self._sessions:
            del self._sessions[user_id]
            return True
        return False

    def get(self, user_id: str) -> Optional[FocusSession]:
        """Get active focus session, auto-expiring if needed."""
        session = self._sessions.get(user_id)
        if session and session.is_expired:
            del self._sessions[user_id]
            logger.info("Focus expired: user=%s topic=%s", user_id, session.topic)
            return None
        return session

    def get_context(self, user_id: str) -> str:
        """Build focus context for system prompt injection."""
        session = self.get(user_id)
        if not session:
            return ""
        remaining = session.remaining_minutes
        time_str = f"{remaining}m remaining" if remaining >= 0 else "no time limit"
        return (
            f"## FOCUS MODE ACTIVE\n"
            f"Currently focused on: **{session.topic}**\n"
            f"Prioritize all responses, memory recall, and context around this topic.\n"
            f"({time_str})"
        )


def parse_duration_minutes(duration_str: str) -> Optional[int]:
    """
    Parse a duration string like '1h', '30m', '2h' into total minutes.

    Returns None if the string cannot be parsed.
    """
    duration_str = duration_str.strip().lower()
    if not duration_str:
        return None

    # Try hours (e.g. '1h', '2h')
    if duration_str.endswith("h"):
        try:
            hours = int(duration_str[:-1])
            return hours * 60
        except ValueError:
            return None

    # Try minutes (e.g. '30m', '90m')
    if duration_str.endswith("m"):
        try:
            return int(duration_str[:-1])
        except ValueError:
            return None

    # Bare integer: treat as minutes
    try:
        return int(duration_str)
    except ValueError:
        return None
