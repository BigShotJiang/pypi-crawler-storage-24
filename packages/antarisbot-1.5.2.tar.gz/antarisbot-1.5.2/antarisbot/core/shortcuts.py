"""Implicit shortcut learning from repeated user behavior patterns."""
import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Minimum times a pattern must repeat before being learned
MIN_REPETITIONS = 3
# Maximum number of learned shortcuts per user
MAX_SHORTCUTS = 50


class ShortcutLearner:
    """Learns implicit shortcuts from repeated user-bot interaction patterns."""

    def __init__(self, store_dir: str | Path):
        self.store_dir = Path(store_dir)
        self.store_dir.mkdir(parents=True, exist_ok=True)

    def observe(self, user_id: str, user_message: str, bot_action: str) -> Optional[str]:
        """Observe a user message and the resulting bot action/response topic.

        Tracks pairs of (short_phrase -> action_taken).
        When a short phrase consistently leads to the same action,
        it becomes a learned shortcut.

        Returns the shortcut description if a new one was just learned, else None.
        """
        # Only track short messages (likely shortcuts)
        if len(user_message.split()) > 8:
            return None

        normalized = user_message.lower().strip()
        if len(normalized) < 3:
            return None

        # Extract action signature (first 100 chars of bot response, normalized)
        action_sig = self._extract_action_sig(bot_action)
        if not action_sig:
            return None

        data = self._load(user_id)
        patterns = data.get("patterns", {})
        shortcuts = data.get("shortcuts", {})

        # Track this pattern
        if normalized not in patterns:
            patterns[normalized] = {}
        if action_sig not in patterns[normalized]:
            patterns[normalized][action_sig] = 0
        patterns[normalized][action_sig] += 1

        # Check if pattern is now learned
        newly_learned = None
        count = patterns[normalized][action_sig]
        if count >= MIN_REPETITIONS and normalized not in shortcuts:
            if len(shortcuts) < MAX_SHORTCUTS:
                shortcuts[normalized] = {
                    "expansion": action_sig,
                    "count": count,
                }
                newly_learned = f'"{normalized}" -> {action_sig}'
                logger.info("Shortcut learned for user=%s: %s", user_id, newly_learned)

        data["patterns"] = patterns
        data["shortcuts"] = shortcuts
        self._save(user_id, data)
        return newly_learned

    def expand(self, user_id: str, text: str) -> Optional[str]:
        """Check if text matches a learned shortcut. Returns expansion or None."""
        normalized = text.lower().strip()
        data = self._load(user_id)
        shortcuts = data.get("shortcuts", {})
        shortcut = shortcuts.get(normalized)
        if shortcut:
            return shortcut["expansion"]
        return None

    def get_context(self, user_id: str, text: str) -> str:
        """Build context for system prompt if text matches a shortcut."""
        expansion = self.expand(user_id, text)
        if not expansion:
            return ""
        return (
            f"## Learned Shortcut\n"
            f"The user often says this when they mean: {expansion}\n"
            f"Interpret their message with this context in mind."
        )

    def list_shortcuts(self, user_id: str) -> list[dict]:
        """List all learned shortcuts for a user."""
        data = self._load(user_id)
        shortcuts = data.get("shortcuts", {})
        return [
            {"phrase": phrase, "expansion": info["expansion"], "count": info["count"]}
            for phrase, info in shortcuts.items()
        ]

    def remove(self, user_id: str, phrase: str) -> bool:
        """Remove a learned shortcut. Returns True if found."""
        data = self._load(user_id)
        shortcuts = data.get("shortcuts", {})
        normalized = phrase.lower().strip()
        if normalized in shortcuts:
            del shortcuts[normalized]
            # Also clear pattern history so it doesn't re-learn immediately
            patterns = data.get("patterns", {})
            patterns.pop(normalized, None)
            data["shortcuts"] = shortcuts
            data["patterns"] = patterns
            self._save(user_id, data)
            return True
        return False

    def _extract_action_sig(self, bot_response: str) -> str:
        """Extract a normalized action signature from a bot response."""
        if not bot_response:
            return ""
        # Use first 100 chars, lowercased, stripped
        sig = bot_response[:100].lower().strip()
        # Remove common filler
        for prefix in ["sure, ", "ok, ", "done! ", "here you go: ", "alright, "]:
            if sig.startswith(prefix):
                sig = sig[len(prefix):]
        return sig[:80] if sig else ""

    def _load(self, user_id: str) -> dict:
        path = self.store_dir / f"{user_id}.json"
        if path.exists():
            try:
                return json.loads(path.read_text())
            except Exception:
                return {"patterns": {}, "shortcuts": {}}
        return {"patterns": {}, "shortcuts": {}}

    def _save(self, user_id: str, data: dict):
        path = self.store_dir / f"{user_id}.json"
        path.write_text(json.dumps(data, indent=2))
