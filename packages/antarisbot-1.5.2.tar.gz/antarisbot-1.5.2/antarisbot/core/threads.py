"""
AntarisBot Conversation Thread Manager.

Tracks per-user conversation threads: detects topic shifts, files turns
into named threads, and supports fuzzy retrieval by topic query.

Thread data is persisted to JSON per user under a configurable directory.
"""
import json
import logging
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Short messages or these exact strings mean "keep going on the same thread"
CONTINUATION_SIGNALS = {
    "yeah", "yes", "no", "ok", "sure", "do it", "go", "nice",
    "cool", "thanks", "right", "exactly", "agreed",
}

# Phrases that signal the user is switching topics
SHIFT_SIGNALS = {
    "anyway", "btw", "by the way", "switching to", "let's talk about",
    "moving on", "different topic", "quick question",
}

STOPWORDS = {
    "the", "a", "an", "is", "are", "was", "were", "i", "you", "we",
    "they", "it", "my", "your", "this", "that", "can", "do", "how",
    "what", "when", "where", "why", "would", "should", "could", "have",
    "has", "had", "will", "be", "been", "to", "for", "of", "in", "on",
    "at", "with", "from", "about", "just", "not", "but", "and", "or",
    "if", "so", "also", "very", "really", "actually", "probably", "maybe",
}


class ThreadManager:
    """
    Per-user conversation thread tracker.

    Each thread is a list of turns: [{role, content, timestamp, topic}].
    The current thread for a user is tracked in memory and updated on
    every call to file_turn(). Threads are persisted to JSON files.
    """

    def __init__(self, threads_dir: Path):
        self.threads_dir = Path(threads_dir)
        self.threads_dir.mkdir(parents=True, exist_ok=True)
        # In-memory: {user_id: {thread_name: [turns]}}
        self._threads: dict[str, dict[str, list[dict]]] = {}
        # Current thread per user: {user_id: thread_name}
        self._current: dict[str, str] = {}

    # ── Topic detection ───────────────────────────────────────────────────

    def detect_topic(self, text: str, current_thread: str = "") -> str:
        """
        Determine which thread this message belongs to.

        Returns the same thread name if the message is a continuation,
        or a new topic name if a shift is detected.
        """
        text_lower = text.lower().strip()

        # Shift signals checked first -- they override short-message continuation
        for signal in SHIFT_SIGNALS:
            if signal in text_lower:
                rest = text_lower.split(signal, 1)[1].strip()
                return rest[:50] if rest else "general"

        # Short messages or known continuation phrases -- stay on current thread
        if len(text_lower.split()) <= 3 or text_lower in CONTINUATION_SIGNALS:
            return current_thread or "general"

        # Extract topic from content: first 1-3 significant words
        words = text.split()
        significant = [
            w for w in words
            if w.lower() not in STOPWORDS and len(w) > 2
        ]
        if significant:
            topic = " ".join(significant[:3]).lower()
            return topic

        return current_thread or "general"

    # ── Thread filing ─────────────────────────────────────────────────────

    def file_turn(self, user_id: str, role: str, content: str) -> str:
        """
        Detect the topic of content and file it into the appropriate thread.

        Returns the thread name the turn was filed into.
        """
        current = self._current.get(user_id, "")

        if role == "user":
            # Only shift threads on user messages
            topic = self.detect_topic(content, current)
            self._current[user_id] = topic
        else:
            # Assistant replies stay on the same thread as the user turn
            topic = self._current.get(user_id, "general")

        # Ensure user thread store is loaded
        if user_id not in self._threads:
            self._threads[user_id] = self._load(user_id)

        thread_turns = self._threads[user_id].setdefault(topic, [])
        thread_turns.append({
            "role": role,
            "content": content,
            "timestamp": time.time(),
            "topic": topic,
        })

        self._save(user_id)
        return topic

    # ── Thread retrieval ──────────────────────────────────────────────────

    def get_thread(self, user_id: str, topic_query: str) -> list[dict]:
        """
        Fuzzy-search thread names and return turns for the best match.

        Returns an empty list if no thread matches.
        """
        if user_id not in self._threads:
            self._threads[user_id] = self._load(user_id)

        threads = self._threads[user_id]
        if not threads:
            return []

        query = topic_query.lower().strip()
        best_name = _fuzzy_match(query, list(threads.keys()))
        if best_name is None:
            return []
        return list(threads[best_name])

    def get_recent_threads(self, user_id: str, limit: int = 5) -> list[dict]:
        """
        Return summaries for the most recently active threads.

        Each summary is: {name, turn_count, last_active}.
        """
        if user_id not in self._threads:
            self._threads[user_id] = self._load(user_id)

        threads = self._threads[user_id]
        summaries = []
        for name, turns in threads.items():
            if not turns:
                continue
            last_ts = max(t["timestamp"] for t in turns)
            summaries.append({
                "name": name,
                "turn_count": len(turns),
                "last_active": last_ts,
            })

        summaries.sort(key=lambda s: s["last_active"], reverse=True)
        return summaries[:limit]

    def list_threads(self, user_id: str) -> list[dict]:
        """
        Return all thread summaries for a user: {name, turn_count, last_active}.
        Sorted by most recent activity first.
        """
        if user_id not in self._threads:
            self._threads[user_id] = self._load(user_id)

        threads = self._threads[user_id]
        summaries = []
        for name, turns in threads.items():
            if not turns:
                continue
            last_ts = max(t["timestamp"] for t in turns)
            summaries.append({
                "name": name,
                "turn_count": len(turns),
                "last_active": last_ts,
            })

        summaries.sort(key=lambda s: s["last_active"], reverse=True)
        return summaries

    # ── Persistence ───────────────────────────────────────────────────────

    def _user_path(self, user_id: str) -> Path:
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in user_id)
        return self.threads_dir / f"{safe}.json"

    def _load(self, user_id: str) -> dict[str, list[dict]]:
        path = self._user_path(user_id)
        if not path.exists():
            return {}
        try:
            with path.open("r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                return data
        except Exception as e:
            logger.warning("Failed to load threads for %s: %s", user_id, e)
        return {}

    def _save(self, user_id: str) -> None:
        path = self._user_path(user_id)
        try:
            with path.open("w", encoding="utf-8") as fh:
                json.dump(self._threads[user_id], fh, indent=2)
        except Exception as e:
            logger.warning("Failed to save threads for %s: %s", user_id, e)


# ── Fuzzy matching helper ─────────────────────────────────────────────────

def _fuzzy_match(query: str, names: list[str]) -> Optional[str]:
    """
    Return the best matching name for query using simple substring/token overlap.

    Returns None if no reasonable match found.
    """
    if not names:
        return None

    # Exact match first
    if query in names:
        return query

    # Substring match
    for name in names:
        if query in name or name in query:
            return name

    # Token overlap scoring
    query_tokens = set(query.split())
    best_name = None
    best_score = 0
    for name in names:
        name_tokens = set(name.split())
        overlap = len(query_tokens & name_tokens)
        if overlap > best_score:
            best_score = overlap
            best_name = name

    if best_score > 0:
        return best_name

    return None
