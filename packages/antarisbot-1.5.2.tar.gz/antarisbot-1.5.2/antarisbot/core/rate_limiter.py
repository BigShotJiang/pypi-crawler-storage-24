"""
AntarisBot — Per-user sliding window rate limiter.
"""
from collections import deque
import time


class RateLimiter:
    """Per-user sliding window rate limiter."""

    def __init__(self, max_messages: int = 20, window_seconds: int = 60):
        self.max_messages = max_messages
        self.window_seconds = window_seconds
        self._windows: dict[str, deque] = {}

    def _prune(self, user_id: str) -> None:
        window = self._windows.get(user_id)
        if not window:
            return
        cutoff = time.time() - self.window_seconds
        while window and window[0] <= cutoff:
            window.popleft()

    def is_allowed(self, user_id: str) -> bool:
        """Returns True (and records this attempt) if user is within rate limit."""
        self._prune(user_id)
        if user_id not in self._windows:
            self._windows[user_id] = deque()
        window = self._windows[user_id]
        if len(window) < self.max_messages:
            window.append(time.time())
            return True
        return False

    def get_wait_seconds(self, user_id: str) -> float:
        """Returns seconds until next message is allowed (0 if allowed now)."""
        self._prune(user_id)
        window = self._windows.get(user_id)
        if not window or len(window) < self.max_messages:
            return 0.0
        oldest = window[0]
        wait = self.window_seconds - (time.time() - oldest)
        return max(0.0, wait)

    def reset(self, user_id: str) -> None:
        """Reset rate limit for a user (admin use)."""
        self._windows.pop(user_id, None)
