"""Per-user teaching store - facts and preferences taught via !teach."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class TeachingStore:
    """Stores user-taught facts/preferences in per-user JSON files."""

    def __init__(self, store_dir: str | Path):
        self.store_dir = Path(store_dir)
        self.store_dir.mkdir(parents=True, exist_ok=True)

    def add(self, user_id: str, teaching: str) -> int:
        """Add a teaching. Returns total count."""
        teachings = self._load(user_id)
        teachings.append({
            "text": teaching,
            "created": datetime.now(timezone.utc).isoformat(),
        })
        self._save(user_id, teachings)
        return len(teachings)

    def list(self, user_id: str) -> list[dict]:
        """List all teachings for a user."""
        return self._load(user_id)

    def remove(self, user_id: str, index: int) -> bool:
        """Remove a teaching by index (1-based). Returns success."""
        teachings = self._load(user_id)
        if 1 <= index <= len(teachings):
            teachings.pop(index - 1)
            self._save(user_id, teachings)
            return True
        return False

    def clear(self, user_id: str) -> int:
        """Remove all teachings for a user. Returns count removed."""
        teachings = self._load(user_id)
        count = len(teachings)
        self._save(user_id, [])
        return count

    def get_context(self, user_id: str) -> str:
        """Build a context string for system prompt injection."""
        teachings = self._load(user_id)
        if not teachings:
            return ""
        lines = ["## User Teachings (remember these):"]
        for t in teachings:
            lines.append(f"- {t['text']}")
        return "\n".join(lines)

    def _load(self, user_id: str) -> list[dict]:
        path = self.store_dir / f"{user_id}.json"
        if path.exists():
            try:
                return json.loads(path.read_text())
            except Exception:
                return []
        return []

    def _save(self, user_id: str, teachings: list[dict]):
        path = self.store_dir / f"{user_id}.json"
        path.write_text(json.dumps(teachings, indent=2))
