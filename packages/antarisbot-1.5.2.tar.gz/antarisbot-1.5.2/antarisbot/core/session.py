"""
AntarisBot Session Management — Multi-Session Support

Provides SessionManager and SessionState for managing independent conversation
sessions per (user_id, channel_id) pair. Each session maintains its own history,
conversation buffer, and state lifecycle.

Usage:
    session_manager = SessionManager(config)
    session = await session_manager.get_or_create(user_id, channel_id, platform)
    session.add_to_history(message)
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class SessionState:
    """
    Per-session state containing conversation history and metadata.
    
    Each session represents a unique (user_id, channel_id) pair and maintains
    independent conversation state, history, and buffer for context management.
    """
    session_id: str               # "{user_id}:{channel_id}" or custom label
    user_id: str
    channel_id: str
    platform: str                 # "discord" | "telegram" | "terminal"
    history: list                 # conversation history (list of Message dicts)
    message_count: int = 0
    compaction_notified: bool = False
    pre_compaction_flushed: bool = False
    conversation_buffer: list = field(default_factory=list)  # (user_id, user_msg, bot_resp) tuples
    created_at: float = 0.0       # time.time()
    last_active: float = 0.0
    status: str = "active"        # active | idle | compacted | closed
    metadata: dict = field(default_factory=dict)
    max_history: int = 20

    def __post_init__(self) -> None:
        """Initialize timestamps if not set."""
        if self.created_at == 0.0:
            self.created_at = time.time()
        if self.last_active == 0.0:
            self.last_active = time.time()

    @property
    def context_pct(self) -> float:
        """Approximate context usage as percentage."""
        total_chars = sum(len(str(m)) for m in self.history)
        estimated_tokens = total_chars // 4
        max_tokens = 200_000
        return min(100.0, (estimated_tokens / max_tokens) * 100)

    def add_to_history(self, message) -> None:
        """Add message to history, trimming if over max."""
        self.history.append(message)
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]
        self.message_count += 1
        self.last_active = time.time()

    def add_to_buffer(self, user_id: str, user_msg: str, bot_resp: str) -> None:
        """Add to conversation buffer (rolling window of 30)."""
        self.conversation_buffer.append((user_id, user_msg, bot_resp))
        if len(self.conversation_buffer) > 30:
            self.conversation_buffer = self.conversation_buffer[-30:]

    def build_summary(self) -> str:
        """Build conversation summary from buffer."""
        if not self.conversation_buffer:
            return "(no conversation data)"
        lines = ["### Recent conversation summary\n"]
        for uid, umsg, bresp in self.conversation_buffer:
            lines.append(f"- User: {umsg[:150]}")
            lines.append(f"  Bot: {bresp[:150]}")
        return "\n".join(lines)


class SessionManager:
    """
    Coroutine-safe session management for AntarisBot (asyncio.Lock).
    
    Manages active sessions, idle timeout, max concurrent limits, and session
    lifecycle operations (create, read, update, delete, compact).
    """

    def __init__(self, config, idle_timeout_minutes: int = 120, max_concurrent: int = 50):
        self._sessions: dict[str, SessionState] = {}
        self._lock: asyncio.Lock = asyncio.Lock()
        self._config = config
        self._idle_timeout = idle_timeout_minutes * 60
        self._max_concurrent = max_concurrent
        logger.info("SessionManager initialized with %d minute timeout, %d max concurrent",
                   idle_timeout_minutes, max_concurrent)

    async def get_or_create(self, user_id: str, channel_id: str, platform: str) -> SessionState:
        """Get existing session or create new one. Coroutine-safe via asyncio.Lock."""
        session_id = self.session_id_for(user_id, channel_id)
        async with self._lock:
            if session_id in self._sessions:
                session = self._sessions[session_id]
                session.last_active = time.time()
                if session.status == "idle":
                    session.status = "active"
                    logger.debug("Reactivated idle session %s", session_id)
                return session
            
            # Check max concurrent limit
            active = sum(1 for s in self._sessions.values() if s.status in ("active", "idle"))
            if active >= self._max_concurrent:
                # Find and close oldest idle session
                idle = sorted(
                    [s for s in self._sessions.values() if s.status == "idle"],
                    key=lambda s: s.last_active
                )
                if idle:
                    oldest_session_id = idle[0].session_id
                    del self._sessions[oldest_session_id]
                    logger.info("Evicted oldest idle session %s to make room", oldest_session_id)

            session = SessionState(
                session_id=session_id,
                user_id=user_id,
                channel_id=channel_id,
                platform=platform,
                history=[],
                created_at=time.time(),
                last_active=time.time(),
                max_history=getattr(self._config, 'max_history_per_session', 20) if self._config else 20,
            )
            self._sessions[session_id] = session
            logger.debug("Created new session %s for platform %s", session_id, platform)
            return session

    async def get_session(self, session_id: str) -> Optional[SessionState]:
        """Get session by ID. Returns None if not found."""
        return self._sessions.get(session_id)

    async def list_sessions(self, active_only: bool = True) -> list[SessionState]:
        """List all sessions, optionally filtering to active/idle/compacted only."""
        if active_only:
            return [s for s in self._sessions.values() if s.status in ("active", "idle", "compacted")]
        return list(self._sessions.values())

    async def kill_session(self, session_id: str) -> bool:
        """Terminate session. Returns True if found and closed."""
        if session_id not in self._sessions:
            return False
        session = self._sessions[session_id]
        session.status = "closed"
        del self._sessions[session_id]
        logger.info("Killed session %s", session_id)
        return True

    async def kill_all(self) -> int:
        """Terminate all sessions. Returns count killed."""
        count = len(self._sessions)
        for session in self._sessions.values():
            session.status = "closed"
        self._sessions.clear()
        if count:
            logger.info("Killed all %d sessions", count)
        return count

    async def reset_session(self, session_id: str) -> bool:
        """Clear history but keep session alive. Returns True if found."""
        if session_id not in self._sessions:
            return False
        session = self._sessions[session_id]
        session.history.clear()
        session.message_count = 0
        session.conversation_buffer.clear()
        session.compaction_notified = False
        session.pre_compaction_flushed = False
        logger.info("Reset session %s history and buffer", session_id)
        return True

    async def cleanup_idle(self) -> int:
        """Close sessions idle longer than timeout. Returns count closed."""
        now = time.time()
        to_close = [
            sid for sid, s in self._sessions.items()
            if s.status == "idle" and (now - s.last_active) > self._idle_timeout
        ]
        for sid in to_close:
            del self._sessions[sid]
        if to_close:
            logger.info("Cleaned up %d idle sessions", len(to_close))
        return len(to_close)

    async def compact_session(self, session_id: str) -> Optional[str]:
        """Compact session: build summary, truncate history. Returns summary or None."""
        session = self._sessions.get(session_id)
        if not session:
            return None
        summary = session.build_summary()
        session.history = session.history[-5:]  # Keep last 5 messages
        session.conversation_buffer.clear()
        session.status = "compacted"
        logger.info("Compacted session %s, kept %d messages", session_id, len(session.history))
        return summary

    def session_id_for(self, user_id: str, channel_id: str) -> str:
        """Generate session ID from user and channel."""
        return f"{user_id}:{channel_id}"

    @property
    def active_count(self) -> int:
        """Count of active, idle, and compacted sessions."""
        return sum(1 for s in self._sessions.values() if s.status in ("active", "idle", "compacted"))

    @property  
    def total_count(self) -> int:
        """Total count of all sessions."""
        return len(self._sessions)

    async def mark_idle(self, session_id: str) -> bool:
        """Mark session as idle. Returns True if found and marked."""
        session = self._sessions.get(session_id)
        if not session or session.status not in ("active", "compacted"):
            return False
        session.status = "idle"
        logger.debug("Marked session %s as idle", session_id)
        return True