"""Daily memory log writer - distills BM25 memories into YYYY-MM-DD.md files."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class DailyLog:
    """Writes daily memory logs to memory/YYYY-MM-DD.md."""

    def __init__(self, memory_dir: str | Path):
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self._last_write_date: Optional[str] = None
        self._entries_since_write: int = 0
        self._write_interval: int = 20  # write after every N new memories
        self._buffer: list[tuple[str, str]] = []  # (user_message, bot_response)

    def record(self, user_id: str, user_message: str, bot_response: str) -> None:
        """Record a conversation turn. Writes to log after write_interval turns."""
        self._entries_since_write += 1
        self._buffer.append((user_message, bot_response))
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        if self._entries_since_write >= self._write_interval or self._last_write_date != today:
            self._flush(today, entries=list(self._buffer))
            self._last_write_date = today
            self._entries_since_write = 0
            self._buffer.clear()

    def _flush(
        self,
        date: str,
        entries: Optional[list[tuple[str, str]]] = None,
    ) -> None:
        """Append a session checkpoint to today's log.

        If entries are provided, writes a distilled summary of key topics
        instead of just a bare timestamp marker.
        """
        log_path = self.memory_dir / f"{date}.md"
        timestamp = datetime.now(timezone.utc).strftime("%H:%M UTC")
        try:
            with open(log_path, "a") as f:
                f.write(f"\n## Session checkpoint - {timestamp}\n")
                f.write(
                    f"_(auto-written by DailyLog after {self._write_interval} conversation turns)_\n"
                )
                if entries:
                    f.write("\n### Conversation summary\n")
                    for user_msg, bot_resp in entries:
                        # Write a compact bullet for each turn (not raw transcript)
                        user_preview = user_msg[:120].replace("\n", " ")
                        bot_preview = bot_resp[:120].replace("\n", " ")
                        f.write(f"- User: {user_preview}\n")
                        f.write(f"  Bot: {bot_preview}\n")
            logger.debug("Daily log written: %s", log_path)
        except Exception as e:
            logger.warning("Failed to write daily log: %s", e)

    def write_session_summary(self, summary_text: str, message_count: int = 0) -> None:
        """Write a structured pre-compaction summary block to today's log.

        Args:
            summary_text: The structured summary to write (topics, decisions, key facts).
            message_count: Current message count at time of flush (for context).
        """
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        log_path = self.memory_dir / f"{today}.md"
        timestamp = datetime.now(timezone.utc).strftime("%H:%M UTC")
        try:
            with open(log_path, "a") as f:
                f.write(f"\n## Pre-compaction summary - {timestamp}\n")
                if message_count:
                    f.write(f"_(saved at message {message_count})_\n\n")
                f.write(summary_text)
                f.write("\n")
            logger.debug("Pre-compaction summary written to: %s", log_path)
        except Exception as e:
            logger.warning("Failed to write session summary: %s", e)

    def write_shutdown_marker(self) -> None:
        """Write a shutdown marker to today's log."""
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        log_path = self.memory_dir / f"{today}.md"
        timestamp = datetime.now(timezone.utc).strftime("%H:%M UTC")
        try:
            with open(log_path, "a") as f:
                f.write(f"\n## Session ended - {timestamp}\n")
        except Exception as e:
            logger.warning("Failed to write shutdown marker: %s", e)
