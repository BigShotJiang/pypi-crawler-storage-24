from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, Union, List, Dict, Any


@dataclass
class Message:
    role: str  # "user" | "assistant" | "system"
    content: Union[str, List[Dict[str, Any]]]  # Support both text and structured content


@dataclass
class LLMResponse:
    content: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    tool_use: Optional[list[dict]] = None  # List of tool use blocks from LLM


class LLMProvider(ABC):
    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model

    @abstractmethod
    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        tools: Optional[list[dict]] = None
    ) -> LLMResponse:
        """Send messages, return response."""
        pass

    @abstractmethod
    def estimate_tokens(self, text: str) -> int:
        """Rough token estimate (chars / 4)."""
        pass
