"""Multi-provider LLM dispatcher — routes to the correct provider based on routing decisions."""

import logging
from typing import Optional, Dict
from .base import LLMProvider, Message, LLMResponse

logger = logging.getLogger(__name__)


class LLMDispatcher:
    """Holds multiple LLM providers and dispatches calls based on provider name.

    Usage:
        dispatcher = LLMDispatcher()
        dispatcher.register("openai", openai_provider)
        dispatcher.register("anthropic", anthropic_provider)
        dispatcher.register("google", google_provider)

        # Route a call to a specific provider + model
        response = await dispatcher.complete(
            provider="openai", model="gpt-5.4",
            messages=[...], system="..."
        )
    """

    def __init__(self):
        self._providers: Dict[str, LLMProvider] = {}

    def register(self, name: str, provider: LLMProvider):
        """Register a provider by name."""
        self._providers[name] = provider
        logger.info("LLMDispatcher: registered provider '%s'", name)

    def get(self, name: str) -> Optional[LLMProvider]:
        """Get a provider by name."""
        return self._providers.get(name)

    @property
    def providers(self) -> Dict[str, LLMProvider]:
        return dict(self._providers)

    async def complete(
        self,
        provider: str,
        model: str,
        messages: list[Message],
        system: str,
        max_tokens: int = 4096,
        temperature: float = 0.7,
    ) -> LLMResponse:
        """Dispatch a completion call to the named provider with the specified model."""
        p = self._providers.get(provider)
        if not p:
            raise ValueError(f"Unknown provider: {provider}. Available: {list(self._providers.keys())}")

        return await p.complete(
            messages=messages,
            system=system,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
        )

    def estimate_tokens(self, text: str) -> int:
        """Use any available provider's token estimator."""
        for p in self._providers.values():
            return p.estimate_tokens(text)
        return max(1, len(text) // 4)
