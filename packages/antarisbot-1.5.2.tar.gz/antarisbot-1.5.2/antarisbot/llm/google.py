"""Google Gemini provider — direct HTTP, no SDK."""

import httpx
from typing import Optional
from .base import LLMProvider, Message, LLMResponse

# Pricing per million tokens (approximate, for cost tracking)
MODEL_PRICING = {
    "gemini-3.1-pro": {"input": 2.50, "output": 10.00},
    "gemini-2.5-flash": {"input": 0.15, "output": 0.60},
    "gemini-2.0-flash": {"input": 0.10, "output": 0.40},
    "gemini-1.5-pro": {"input": 1.25, "output": 5.00},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
}


class GoogleProvider(LLMProvider):
    """Google Gemini provider — direct HTTP to generativelanguage.googleapis.com, no SDK."""

    BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

    MODELS = [
        "gemini-3.1-pro",
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-1.5-pro",
        "gemini-1.5-flash",
    ]

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        tools=None,
    ) -> LLMResponse:
        use_model = model or self.model

        # Build Gemini contents array
        # Gemini uses "user" and "model" roles (not "assistant")
        contents = []
        for m in messages:
            if m.role == "system":
                continue  # system goes in systemInstruction
            role = "model" if m.role == "assistant" else "user"
            contents.append({
                "role": role,
                "parts": [{"text": m.content}],
            })

        payload = {
            "contents": contents,
            "generationConfig": {
                "maxOutputTokens": max_tokens,
                "temperature": temperature,
            },
        }

        # System instruction (Gemini's equivalent of system prompt)
        if system:
            payload["systemInstruction"] = {
                "parts": [{"text": system}],
            }

        url = f"{self.BASE_URL}/models/{use_model}:generateContent"

        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key,
        }

        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                response = await client.post(url, json=payload, headers=headers)

                if response.status_code == 400:
                    body = response.text
                    if "not found" in body.lower():
                        raise ValueError(f"Model not found: {use_model}")
                    raise ValueError(f"Gemini bad request: {body}")
                if response.status_code == 401:
                    raise ValueError("Invalid Google API key")
                if response.status_code == 403:
                    raise ValueError("Google API key does not have Gemini access")
                if response.status_code == 429:
                    retry_after = response.headers.get("retry-after", "5")
                    try:
                        wait = int(float(retry_after))
                    except (ValueError, TypeError):
                        wait = 5
                    raise RuntimeError(f"rate_limit:{wait}")
                if response.status_code in (500, 503):
                    raise RuntimeError(f"server_error:{response.status_code}")

                response.raise_for_status()
                data = response.json()

                # Extract text from response
                candidates = data.get("candidates", [])
                if not candidates:
                    # Check for safety block
                    block_reason = data.get("promptFeedback", {}).get("blockReason")
                    if block_reason:
                        raise RuntimeError(f"Gemini blocked response: {block_reason}")
                    raise RuntimeError("Gemini returned empty candidates")

                parts = candidates[0].get("content", {}).get("parts", [])
                if not parts or not parts[0].get("text"):
                    # Check finish reason
                    finish = candidates[0].get("finishReason", "UNKNOWN")
                    if finish == "SAFETY":
                        raise RuntimeError("Gemini blocked response for safety reasons")
                    raise RuntimeError("Gemini returned empty content")

                content = parts[0]["text"]

                # Extract token usage
                usage = data.get("usageMetadata", {})
                input_tokens = usage.get("promptTokenCount", 0)
                output_tokens = usage.get("candidatesTokenCount", 0)

                # Calculate cost
                pricing = MODEL_PRICING.get(use_model, {"input": 0.15, "output": 0.60})
                cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

                return LLMResponse(
                    content=content,
                    model=use_model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost_usd=cost,
                )

            except (ValueError, RuntimeError):
                raise
            except httpx.TimeoutException:
                raise RuntimeError("Gemini API request timed out")
            except httpx.HTTPStatusError as e:
                raise RuntimeError(
                    f"Gemini API error {e.response.status_code}: {e.response.text}"
                )

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)
