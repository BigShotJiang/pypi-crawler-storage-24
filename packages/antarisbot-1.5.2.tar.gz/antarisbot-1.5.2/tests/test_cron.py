"""Tests for antarisbot.core.cron"""
import asyncio
import json
import time
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path

import pytest

from antarisbot.core.cron import CronJob, CronScheduler


# ── CronJob ───────────────────────────────────────────────────────────────────

class TestCronJob:
    def test_create_basic(self):
        job = CronJob(id="abc123", name="Test Job", schedule_kind="every", schedule_every_ms=60000)
        assert job.id == "abc123"
        assert job.name == "Test Job"
        assert job.schedule_kind == "every"
        assert job.schedule_every_ms == 60000
        assert job.enabled is True
        assert job.run_count == 0
        assert job.payload_kind == "systemEvent"

    def test_serialization_round_trip(self):
        job = CronJob(
            id=str(uuid.uuid4()),
            name="Round Trip",
            schedule_kind="every",
            schedule_every_ms=5000,
            payload_kind="agentTurn",
            payload_text="Hello, world!",
            channel_id="123456",
            enabled=True,
            last_run=None,
            run_count=3,
        )
        d = job.to_dict()
        restored = CronJob.from_dict(d)
        assert restored.id == job.id
        assert restored.name == job.name
        assert restored.schedule_every_ms == job.schedule_every_ms
        assert restored.payload_kind == job.payload_kind
        assert restored.payload_text == job.payload_text
        assert restored.run_count == job.run_count

    def test_from_dict_ignores_extra_keys(self):
        """from_dict should not blow up on extra unknown keys."""
        d = {
            "id": "x",
            "name": "Y",
            "schedule_kind": "every",
            "schedule_every_ms": 1000,
            "unknown_future_key": "ignored",
        }
        # Extra key should be silently dropped
        job = CronJob.from_dict(d)
        assert job.id == "x"

    def test_created_at_auto(self):
        before = time.time()
        job = CronJob(id="t", name="T", schedule_kind="every")
        after = time.time()
        assert before <= job.created_at <= after


# ── CronScheduler ─────────────────────────────────────────────────────────────

@pytest.fixture
def tmp_jobs_path(tmp_path):
    return tmp_path / "cron" / "jobs.json"


async def _noop(job):
    pass


class TestCronSchedulerJobManagement:
    def test_add_job(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="j1", name="Job One", schedule_kind="every", schedule_every_ms=1000)
        scheduler.add_job(job)
        assert scheduler.get_job("j1") is not None
        assert len(scheduler.list_jobs()) == 1

    def test_add_job_persists(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="j2", name="Persist", schedule_kind="every", schedule_every_ms=2000)
        scheduler.add_job(job)
        # Reload from disk
        scheduler2 = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        loaded = scheduler2.get_job("j2")
        assert loaded is not None
        assert loaded.name == "Persist"

    def test_remove_job(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="j3", name="Remove Me", schedule_kind="every", schedule_every_ms=1000)
        scheduler.add_job(job)
        result = scheduler.remove_job("j3")
        assert result is True
        assert scheduler.get_job("j3") is None

    def test_remove_nonexistent(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        result = scheduler.remove_job("nope")
        assert result is False

    def test_list_jobs(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        for i in range(3):
            scheduler.add_job(CronJob(id=f"j{i}", name=f"Job {i}", schedule_kind="every"))
        jobs = scheduler.list_jobs()
        assert len(jobs) == 3

    def test_replace_job(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(id="dup", name="Original", schedule_kind="every")
        scheduler.add_job(job)
        job2 = CronJob(id="dup", name="Replaced", schedule_kind="every")
        scheduler.add_job(job2)
        assert scheduler.get_job("dup").name == "Replaced"
        assert len(scheduler.list_jobs()) == 1


class TestCronSchedulerIsDue:
    def test_every_never_run_is_due_immediately(self, tmp_jobs_path):
        """A job with schedule_kind=every and last_run=None should be due right away."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="e1", name="Every 1s",
            schedule_kind="every",
            schedule_every_ms=1000,
            last_run=None,
        )
        assert scheduler._is_due(job) is True

    def test_every_just_ran_not_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="e2", name="Every 1h",
            schedule_kind="every",
            schedule_every_ms=3_600_000,  # 1 hour
            last_run=time.time(),  # just ran
        )
        assert scheduler._is_due(job) is False

    def test_every_overdue_is_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="e3", name="Every 1s overdue",
            schedule_kind="every",
            schedule_every_ms=1000,
            last_run=time.time() - 5,  # 5 seconds ago, interval is 1s
        )
        assert scheduler._is_due(job) is True

    def test_disabled_never_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="d1", name="Disabled",
            schedule_kind="every",
            schedule_every_ms=1,
            enabled=False,
            last_run=None,
        )
        assert scheduler._is_due(job) is False

    def test_at_future_not_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        job = CronJob(
            id="at1", name="Future At",
            schedule_kind="at",
            schedule_at=future,
            run_count=0,
        )
        assert scheduler._is_due(job) is False

    def test_at_past_is_due(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        job = CronJob(
            id="at2", name="Past At",
            schedule_kind="at",
            schedule_at=past,
            run_count=0,
        )
        assert scheduler._is_due(job) is True

    def test_at_fires_once_then_not_again(self, tmp_jobs_path):
        """After run_count > 0, the 'at' job should never be due again."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        job = CronJob(
            id="at3", name="One-shot",
            schedule_kind="at",
            schedule_at=past,
            run_count=1,  # already fired once
        )
        assert scheduler._is_due(job) is False

    def test_cron_kind_returns_false(self, tmp_jobs_path):
        """cron expression kind is not implemented yet — should return False."""
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="c1", name="Cron expr",
            schedule_kind="cron",
            schedule_cron="* * * * *",
        )
        assert scheduler._is_due(job) is False


class TestCronSchedulerRunNow:
    def test_run_now_resets_last_run(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        job = CronJob(
            id="rn1", name="Run Now",
            schedule_kind="every",
            schedule_every_ms=3_600_000,
            last_run=time.time(),  # just ran — normally not due
        )
        scheduler.add_job(job)
        scheduler.run_now("rn1")
        updated = scheduler.get_job("rn1")
        assert updated.last_run is None

    def test_run_now_nonexistent_returns_false(self, tmp_jobs_path):
        scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
        result = scheduler.run_now("no-such-id")
        assert result is False


class TestCronSchedulerAsync:
    def test_start_stop(self, tmp_jobs_path):
        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_noop)
            await scheduler.start()
            assert scheduler._task is not None
            await scheduler.stop()
            assert scheduler._task.cancelled() or scheduler._task.done()

        asyncio.run(_run())

    def test_tick_fires_due_jobs(self, tmp_jobs_path):
        fired = []

        async def _on_fire(job):
            fired.append(job.id)

        async def _run():
            scheduler = CronScheduler(jobs_path=tmp_jobs_path, on_fire=_on_fire)
            job = CronJob(
                id="fire1", name="Should Fire",
                schedule_kind="every",
                schedule_every_ms=1,  # 1ms — definitely overdue
                last_run=time.time() - 10,
            )
            scheduler.add_job(job)
            await scheduler._tick()
            assert "fire1" in fired

        asyncio.run(_run())
