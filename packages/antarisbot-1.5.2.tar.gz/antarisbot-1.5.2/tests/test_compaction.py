"""Tests for compaction safety features in AntarisBot.

Covers:
- Pre-compaction flush at correct message count
- Conversation buffer (rolling window of 30)
- Post-compaction restoration (daily logs + MEMORY.md)
- Compaction summary persistence to memory
- Enhanced DailyLog content (write_session_summary)
- Config additions (pre_compaction_ratio, startup_restore_days)
"""
from __future__ import annotations

import asyncio
import json
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def utc_today() -> str:
    """Return today's date string in UTC (matching DailyLog's internal format)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


# ── Helpers ──────────────────────────────────────────────────────────────────

def make_config(owner_user_id="276141255266926602", threshold=80):
    cfg = MagicMock()
    cfg.owner_user_id = owner_user_id
    cfg.compaction_threshold = threshold
    cfg.pre_compaction_ratio = 0.75
    cfg.startup_restore_days = 2
    return cfg


# ── Config field tests ────────────────────────────────────────────────────────

def test_config_defaults():
    """Config dataclass should have owner_user_id and compaction_threshold defaults."""
    from antarisbot.core.config import Config
    cfg = Config()
    assert hasattr(cfg, 'owner_user_id')
    assert hasattr(cfg, 'compaction_threshold')
    assert cfg.owner_user_id == ""
    assert cfg.compaction_threshold == 80


def test_config_new_fields_defaults():
    """Config should have pre_compaction_ratio and startup_restore_days with correct defaults."""
    from antarisbot.core.config import Config
    cfg = Config()
    assert hasattr(cfg, 'pre_compaction_ratio')
    assert hasattr(cfg, 'startup_restore_days')
    assert cfg.pre_compaction_ratio == 0.75
    assert cfg.startup_restore_days == 2


def test_config_load_compaction_fields(tmp_path):
    """Config.load() should read ownerUserId and compactionThreshold from JSON."""
    from antarisbot.core.config import Config

    cfg_data = {
        "bot": {"name": "TestBot", "ownerUserId": "12345", "compactionThreshold": 50},
        "provider": {"name": "ollama", "apiKey": "ollama", "model": "qwen3:8b", "fallbackModel": "qwen3:8b"},
        "channels": {},
        "memory": {},
        "guard": {},
        "security": {},
    }
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps(cfg_data))

    cfg = Config.load(str(cfg_path))
    assert cfg is not None
    assert cfg.owner_user_id == "12345"
    assert cfg.compaction_threshold == 50


def test_config_load_new_fields(tmp_path):
    """Config.load() should read preCompactionRatio and startupRestoreDays from JSON."""
    from antarisbot.core.config import Config

    cfg_data = {
        "bot": {
            "name": "TestBot",
            "ownerUserId": "12345",
            "compactionThreshold": 80,
            "preCompactionRatio": 0.6,
            "startupRestoreDays": 3,
        },
        "provider": {"name": "ollama", "apiKey": "ollama", "model": "q", "fallbackModel": "q"},
        "channels": {},
        "memory": {},
        "guard": {},
        "security": {},
    }
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps(cfg_data))

    cfg = Config.load(str(cfg_path))
    assert cfg is not None
    assert cfg.pre_compaction_ratio == 0.6
    assert cfg.startup_restore_days == 3


def test_config_save_new_fields(tmp_path):
    """Config.save() should write preCompactionRatio and startupRestoreDays."""
    from antarisbot.core.config import Config

    cfg = Config()
    cfg.provider_name = "ollama"
    cfg.api_key = "ollama"
    cfg.owner_user_id = "999"
    cfg.compaction_threshold = 40
    cfg.pre_compaction_ratio = 0.6
    cfg.startup_restore_days = 3
    cfg_path = tmp_path / "config.json"
    cfg.config_path = str(cfg_path)
    cfg.save()

    data = json.loads(cfg_path.read_text())
    assert data["bot"]["ownerUserId"] == "999"
    assert data["bot"]["compactionThreshold"] == 40
    assert data["bot"]["preCompactionRatio"] == 0.6
    assert data["bot"]["startupRestoreDays"] == 3


def test_config_save_compaction_fields(tmp_path):
    """Config.save() should write ownerUserId and compactionThreshold."""
    from antarisbot.core.config import Config

    cfg = Config()
    cfg.provider_name = "ollama"
    cfg.api_key = "ollama"
    cfg.owner_user_id = "999"
    cfg.compaction_threshold = 40
    cfg_path = tmp_path / "config.json"
    cfg.config_path = str(cfg_path)
    cfg.save()

    data = json.loads(cfg_path.read_text())
    assert data["bot"]["ownerUserId"] == "999"
    assert data["bot"]["compactionThreshold"] == 40


def test_config_roundtrip_new_fields(tmp_path):
    """pre_compaction_ratio and startup_restore_days survive save/load roundtrip."""
    from antarisbot.core.config import Config

    cfg = Config()
    cfg.provider_name = "ollama"
    cfg.api_key = "ollama"
    cfg.pre_compaction_ratio = 0.5
    cfg.startup_restore_days = 5
    cfg_path = tmp_path / "config.json"
    cfg.config_path = str(cfg_path)
    cfg.save()

    loaded = Config.load(str(cfg_path))
    assert loaded is not None
    assert loaded.pre_compaction_ratio == 0.5
    assert loaded.startup_restore_days == 5


# ── Compaction threshold logic tests ─────────────────────────────────────────

@pytest.mark.asyncio
async def test_compaction_ping_fires_at_threshold():
    """_send_compaction_ping should be triggered when message count hits threshold."""
    message_count = 80
    threshold = 80
    notified = False
    owner_id = "276141255266926602"

    should_ping = (
        message_count >= threshold
        and not notified
        and bool(owner_id)
    )
    assert should_ping is True


@pytest.mark.asyncio
async def test_compaction_ping_does_not_fire_below_threshold():
    """Should not trigger compaction ping below the threshold."""
    message_count = 79
    threshold = 80
    notified = False
    owner_id = "276141255266926602"

    should_ping = (
        message_count >= threshold
        and not notified
        and bool(owner_id)
    )
    assert should_ping is False


@pytest.mark.asyncio
async def test_compaction_ping_does_not_repeat():
    """Second message at/above threshold should not re-trigger (notified=True)."""
    message_count = 100
    threshold = 80
    notified = True
    owner_id = "276141255266926602"

    should_ping = (
        message_count >= threshold
        and not notified
        and bool(owner_id)
    )
    assert should_ping is False


@pytest.mark.asyncio
async def test_compaction_ping_skips_when_no_owner_id():
    """No ping when owner_user_id is empty string."""
    message_count = 100
    threshold = 80
    notified = False
    owner_id = ""

    should_ping = (
        message_count >= threshold
        and not notified
        and bool(owner_id)
    )
    assert should_ping is False


# ── Pre-compaction flush trigger tests ───────────────────────────────────────

def test_pre_compaction_threshold_calculation():
    """Pre-compaction threshold is ratio * compaction_threshold."""
    threshold = 80
    ratio = 0.75
    pre_threshold = int(threshold * ratio)
    assert pre_threshold == 60


def test_pre_compaction_triggers_at_pre_threshold():
    """Pre-compaction flush should fire when message_count >= pre_threshold."""
    message_count = 60
    threshold = 80
    ratio = 0.75
    pre_threshold = int(threshold * ratio)
    flushed = False

    should_flush = message_count >= pre_threshold and not flushed
    assert should_flush is True


def test_pre_compaction_does_not_trigger_below():
    """Pre-compaction flush should not fire below pre_threshold."""
    message_count = 59
    threshold = 80
    ratio = 0.75
    pre_threshold = int(threshold * ratio)
    flushed = False

    should_flush = message_count >= pre_threshold and not flushed
    assert should_flush is False


def test_pre_compaction_does_not_repeat():
    """Pre-compaction flush should not fire twice (flushed flag)."""
    message_count = 70
    threshold = 80
    ratio = 0.75
    pre_threshold = int(threshold * ratio)
    flushed = True  # already done

    should_flush = message_count >= pre_threshold and not flushed
    assert should_flush is False


# ── Conversation buffer tests ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_conversation_buffer_initial_state():
    """Bot should start with empty conversation buffer."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._conversation_buffer = []
    assert bot._conversation_buffer == []


@pytest.mark.asyncio
async def test_conversation_buffer_rolling_window():
    """Conversation buffer should maintain at most 30 turns."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._conversation_buffer = []

    # Simulate 35 turns
    for i in range(35):
        bot._conversation_buffer.append((f"user{i}", f"msg{i}", f"resp{i}"))
        if len(bot._conversation_buffer) > 30:
            bot._conversation_buffer = bot._conversation_buffer[-30:]

    assert len(bot._conversation_buffer) == 30
    # Should have the most recent 30 (turns 5-34)
    assert bot._conversation_buffer[0][1] == "msg5"
    assert bot._conversation_buffer[-1][1] == "msg34"


@pytest.mark.asyncio
async def test_conversation_buffer_stores_user_id_and_messages():
    """Conversation buffer entries should be (user_id, user_msg, bot_response) tuples."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._conversation_buffer = []

    entry = ("user123", "hello world", "hi there")
    bot._conversation_buffer.append(entry)

    assert len(bot._conversation_buffer) == 1
    uid, umsg, bresp = bot._conversation_buffer[0]
    assert uid == "user123"
    assert umsg == "hello world"
    assert bresp == "hi there"


@pytest.mark.asyncio
async def test_build_conversation_summary_empty_buffer():
    """_build_conversation_summary returns placeholder when buffer is empty."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._conversation_buffer = []

    summary = bot._build_conversation_summary()
    assert "no conversation data" in summary.lower()


@pytest.mark.asyncio
async def test_build_conversation_summary_with_turns():
    """_build_conversation_summary includes user and bot content."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._conversation_buffer = [
        ("user1", "What is the capital of France?", "The capital of France is Paris."),
        ("user1", "What about Spain?", "The capital of Spain is Madrid."),
    ]

    summary = bot._build_conversation_summary()
    assert "France" in summary or "capital" in summary.lower()
    assert "Paris" in summary or "Madrid" in summary


# ── Pre-compaction flush method tests ────────────────────────────────────────

@pytest.mark.asyncio
async def test_pre_compaction_flush_writes_to_daily_log():
    """_pre_compaction_flush should call daily_log.write_session_summary."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._message_count = 60
    bot._conversation_buffer = [("u", "test question", "test answer")]
    bot.memory = None

    mock_daily_log = MagicMock()
    bot.daily_log = mock_daily_log

    await bot._pre_compaction_flush()

    mock_daily_log.write_session_summary.assert_called_once()
    # Verify message_count was passed
    args, kwargs = mock_daily_log.write_session_summary.call_args
    assert 60 in args or kwargs.get("message_count") == 60


@pytest.mark.asyncio
async def test_pre_compaction_flush_ingests_into_memory():
    """_pre_compaction_flush should ingest summary into BM25 memory."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._message_count = 60
    bot._conversation_buffer = [("u", "what is ai?", "AI stands for artificial intelligence.")]

    mock_memory = MagicMock()
    mock_memory.ingest = AsyncMock()
    bot.memory = mock_memory
    bot.daily_log = MagicMock()

    await bot._pre_compaction_flush()

    mock_memory.ingest.assert_awaited_once()
    # Should be ingested under "system" user
    call_args = mock_memory.ingest.call_args
    assert call_args.args[0] == "system"


@pytest.mark.asyncio
async def test_pre_compaction_flush_no_daily_log_does_not_crash():
    """_pre_compaction_flush should not crash when daily_log is missing."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._message_count = 60
    bot._conversation_buffer = []
    bot.memory = None
    # No daily_log attribute

    # Should not raise
    await bot._pre_compaction_flush()


@pytest.mark.asyncio
async def test_pre_compaction_flush_no_memory_does_not_crash():
    """_pre_compaction_flush should not crash when memory is None."""
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._message_count = 60
    bot._conversation_buffer = [("u", "hello", "world")]
    bot.memory = None
    bot.daily_log = MagicMock()

    # Should not raise
    await bot._pre_compaction_flush()


# ── Compaction summary persistence tests ─────────────────────────────────────

@pytest.mark.asyncio
async def test_send_compaction_ping_persists_summary_to_memory():
    """_send_compaction_ping should ingest compaction summary into memory.

    Even when no Discord DM can be sent, the compaction summary is persisted.
    We use a non-Discord adapter so the DM path is skipped but memory ingest runs.
    """
    from antarisbot.core.bot import Bot
    bot = object.__new__(Bot)
    bot._message_count = 80
    # Provide a real owner_user_id so the function doesn't return early
    bot.config = make_config(owner_user_id="276141255266926602")
    bot._conversation_buffer = [("u", "final question", "final answer")]

    mock_memory = MagicMock()
    mock_memory.ingest = AsyncMock()
    bot.memory = mock_memory

    # Use a non-Discord adapter so the DM path throws/skips, but ingest still runs
    adapter = MagicMock()
    adapter.__class__.__name__ = "TerminalAdapter"

    with patch("antarisbot.core.bot.logger"):
        await bot._send_compaction_ping(adapter)

    mock_memory.ingest.assert_awaited_once()
    call_args = mock_memory.ingest.call_args
    assert call_args.args[0] == "system"


@pytest.mark.asyncio
async def test_send_compaction_ping_logs_fallback_when_no_discord():
    """_send_compaction_ping falls back to logging when adapter is not Discord."""
    from antarisbot.core.bot import Bot

    bot = object.__new__(Bot)
    bot._message_count = 80
    bot.config = make_config()
    bot._conversation_buffer = []
    bot.memory = None

    adapter = MagicMock()
    adapter.__class__.__name__ = "TerminalAdapter"

    with patch("antarisbot.core.bot.logger") as mock_logger:
        await bot._send_compaction_ping(adapter)
        mock_logger.warning.assert_called()


@pytest.mark.asyncio
async def test_send_compaction_ping_no_owner_id_returns_early():
    """_send_compaction_ping returns early when owner_user_id is empty."""
    from antarisbot.core.bot import Bot

    bot = object.__new__(Bot)
    bot._message_count = 80
    bot.config = make_config(owner_user_id="")
    bot._conversation_buffer = []

    mock_memory = MagicMock()
    mock_memory.ingest = AsyncMock()
    bot.memory = mock_memory

    adapter = MagicMock()
    await bot._send_compaction_ping(adapter)
    # With empty owner_id, returns before memory ingest
    # (early return at top of function)


@pytest.mark.asyncio
async def test_send_compaction_ping_discord_adapter_sends_dm():
    """_send_compaction_ping sends a DM via Discord when adapter is DiscordAdapter."""
    from antarisbot.core.bot import Bot
    from antarisbot.channels.discord import DiscordAdapter

    bot = object.__new__(Bot)
    bot._message_count = 80
    bot.config = make_config(owner_user_id="276141255266926602")
    bot._conversation_buffer = []

    mock_memory = MagicMock()
    mock_memory.ingest = AsyncMock()
    bot.memory = mock_memory

    mock_user = AsyncMock()
    mock_client = AsyncMock()
    mock_client.fetch_user = AsyncMock(return_value=mock_user)

    adapter = MagicMock(spec=DiscordAdapter)
    adapter._client = mock_client

    with patch("antarisbot.core.bot.logger"):
        await bot._send_compaction_ping(adapter)

    mock_client.fetch_user.assert_awaited_once_with(276141255266926602)
    mock_user.send.assert_awaited_once()
    sent_msg = mock_user.send.call_args.args[0]
    assert "80" in sent_msg or "messages" in sent_msg.lower()


# ── Post-compaction restoration (Pipeline._restore_post_compaction) ───────────

def test_restore_post_compaction_reads_memory_md(tmp_path):
    """_restore_post_compaction should read MEMORY.md when it exists."""
    from antarisbot.core.pipeline import Pipeline

    pipe = object.__new__(Pipeline)

    memory_md = tmp_path / "MEMORY.md"
    memory_md.write_text("## Long-term facts\n- I am Moro\n- User is Antaris\n")

    results = pipe._restore_post_compaction(str(tmp_path), days=0)

    assert any("MEMORY.md" in r or "Long-term" in r for r in results)
    assert any("Moro" in r for r in results)


def test_restore_post_compaction_reads_daily_logs(tmp_path):
    """_restore_post_compaction should read today's daily log."""
    from antarisbot.core.pipeline import Pipeline

    pipe = object.__new__(Pipeline)

    memory_dir = tmp_path / "memory"
    memory_dir.mkdir()
    today = date.today().isoformat()
    log_file = memory_dir / f"{today}.md"
    log_file.write_text("## Session checkpoint - 14:00 UTC\n- Worked on compaction\n")

    results = pipe._restore_post_compaction(str(tmp_path), days=1)

    assert any("compaction" in r.lower() or today in r for r in results)


def test_restore_post_compaction_reads_yesterday_log(tmp_path):
    """_restore_post_compaction should read yesterday's daily log when days=2."""
    from antarisbot.core.pipeline import Pipeline

    pipe = object.__new__(Pipeline)

    memory_dir = tmp_path / "memory"
    memory_dir.mkdir()
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    log_file = memory_dir / f"{yesterday}.md"
    log_file.write_text("## Session checkpoint\n- Yesterday's work\n")

    results = pipe._restore_post_compaction(str(tmp_path), days=2)

    assert any("Yesterday" in r or yesterday in r for r in results)


def test_restore_post_compaction_handles_missing_memory_md(tmp_path):
    """_restore_post_compaction should not crash when MEMORY.md is missing."""
    from antarisbot.core.pipeline import Pipeline

    pipe = object.__new__(Pipeline)
    # No MEMORY.md, no memory dir

    results = pipe._restore_post_compaction(str(tmp_path), days=0)
    assert isinstance(results, list)


def test_restore_post_compaction_handles_missing_daily_log(tmp_path):
    """_restore_post_compaction should not crash when daily log files are missing."""
    from antarisbot.core.pipeline import Pipeline

    pipe = object.__new__(Pipeline)
    # No memory/ directory at all

    results = pipe._restore_post_compaction(str(tmp_path), days=2)
    assert isinstance(results, list)


def test_restore_post_compaction_memory_md_first(tmp_path):
    """_restore_post_compaction should return MEMORY.md content before daily logs."""
    from antarisbot.core.pipeline import Pipeline

    pipe = object.__new__(Pipeline)

    (tmp_path / "MEMORY.md").write_text("# Long-term\n- key fact\n")
    memory_dir = tmp_path / "memory"
    memory_dir.mkdir()
    today = date.today().isoformat()
    (memory_dir / f"{today}.md").write_text("## Today\n- today's log\n")

    results = pipe._restore_post_compaction(str(tmp_path), days=1)

    assert len(results) >= 2
    # MEMORY.md should be first
    assert "Long-term" in results[0] or "MEMORY.md" in results[0]


def test_restore_post_compaction_respects_days_param(tmp_path):
    """_restore_post_compaction should only read the requested number of days."""
    from antarisbot.core.pipeline import Pipeline

    pipe = object.__new__(Pipeline)

    memory_dir = tmp_path / "memory"
    memory_dir.mkdir()

    # Write logs for today, yesterday, and 2 days ago
    for delta in range(3):
        log_date = (date.today() - timedelta(days=delta)).isoformat()
        (memory_dir / f"{log_date}.md").write_text(f"## Log for {log_date}\n")

    # With days=1, should only get today
    results_1 = pipe._restore_post_compaction(str(tmp_path), days=1)
    today = date.today().isoformat()
    two_days_ago = (date.today() - timedelta(days=2)).isoformat()

    # 2 days ago should not appear in days=1 results
    combined = "\n".join(results_1)
    assert two_days_ago not in combined


def test_restore_post_compaction_handles_unreadable_file(tmp_path):
    """_restore_post_compaction should not crash on a file it cannot read."""
    from antarisbot.core.pipeline import Pipeline

    pipe = object.__new__(Pipeline)

    memory_md = tmp_path / "MEMORY.md"
    memory_md.write_text("valid content")

    # Patch open to raise on the daily log
    results = pipe._restore_post_compaction(str(tmp_path), days=0)
    assert isinstance(results, list)


# ── Enhanced DailyLog tests ───────────────────────────────────────────────────

def test_daily_log_write_session_summary(tmp_path):
    """write_session_summary should write a structured block to today's log."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    summary_text = "### Topics\n- Discussed compaction\n- Planned flush strategy\n"
    dl.write_session_summary(summary_text, message_count=60)

    today = utc_today()
    log_path = tmp_path / f"{today}.md"
    assert log_path.exists()
    content = log_path.read_text()
    assert "Pre-compaction summary" in content
    assert "compaction" in content.lower()


def test_daily_log_write_session_summary_includes_message_count(tmp_path):
    """write_session_summary should include the message count in the log."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    dl.write_session_summary("some summary", message_count=75)

    today = utc_today()
    content = (tmp_path / f"{today}.md").read_text()
    assert "75" in content


def test_daily_log_write_session_summary_includes_timestamp(tmp_path):
    """write_session_summary should include a UTC timestamp."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    dl.write_session_summary("test summary")

    today = utc_today()
    content = (tmp_path / f"{today}.md").read_text()
    assert "UTC" in content


def test_daily_log_write_session_summary_handles_error_gracefully(tmp_path):
    """write_session_summary should not raise on write error."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    dl.memory_dir = Path("/nonexistent/invalid/path")

    # Should not raise
    dl.write_session_summary("summary text", message_count=60)


def test_daily_log_flush_writes_actual_content(tmp_path):
    """_flush() with entries should write conversation content, not just a marker."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    entries = [
        ("What is AI?", "AI stands for artificial intelligence."),
        ("Tell me about Python.", "Python is a programming language."),
    ]
    today = date.today().isoformat()
    dl._flush(today, entries=entries)

    log_path = tmp_path / f"{today}.md"
    content = log_path.read_text()
    assert "Session checkpoint" in content
    assert "Conversation summary" in content
    # Should contain previews of conversation content
    assert "AI" in content or "artificial" in content.lower()


def test_daily_log_flush_without_entries_still_writes_marker(tmp_path):
    """_flush() without entries should still write the checkpoint marker."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    today = date.today().isoformat()
    dl._flush(today)

    log_path = tmp_path / f"{today}.md"
    content = log_path.read_text()
    assert "Session checkpoint" in content


def test_daily_log_record_buffers_entries(tmp_path):
    """record() should buffer (user_message, bot_response) tuples."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    dl._write_interval = 100  # prevent interval flush
    dl._last_write_date = utc_today()  # same UTC day, no date-change flush

    dl.record("user1", "hello", "hi there")
    dl.record("user2", "test", "response")

    assert len(dl._buffer) == 2
    assert dl._buffer[0] == ("hello", "hi there")
    assert dl._buffer[1] == ("test", "response")


def test_daily_log_record_clears_buffer_after_flush(tmp_path):
    """record() should clear the buffer after a flush is triggered."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    dl._write_interval = 2
    dl._last_write_date = utc_today()  # use UTC to avoid cross-day false flush

    dl.record("u", "msg1", "resp1")
    dl.record("u", "msg2", "resp2")  # triggers flush (2 entries)

    assert dl._buffer == []


def test_daily_log_record_passes_buffer_to_flush(tmp_path):
    """record() should pass buffered entries to _flush()."""
    from antarisbot.core.daily_log import DailyLog

    dl = DailyLog(tmp_path)
    dl._write_interval = 2
    dl._last_write_date = utc_today()  # use UTC to avoid cross-day false flush

    dl.record("u", "what is compaction?", "It saves context before limits are hit.")
    dl.record("u", "second question", "second answer")  # triggers flush

    today = utc_today()
    log_path = tmp_path / f"{today}.md"
    assert log_path.exists()
    content = log_path.read_text()
    # Should have summary section from the buffered entries
    assert "Conversation summary" in content
    assert "compaction" in content.lower() or "second" in content.lower()
