"""Tests for the ThreadManager (conversation threading with memory)."""

import json
import time
import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

from antarisbot.core.threads import (
    ThreadManager,
    CONTINUATION_SIGNALS,
    SHIFT_SIGNALS,
    _fuzzy_match,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def threads_dir(tmp_path):
    return tmp_path / "threads"


@pytest.fixture
def manager(threads_dir):
    return ThreadManager(threads_dir)


# ── Topic detection ───────────────────────────────────────────────────────────

class TestDetectTopic:
    def test_empty_text_returns_general(self, manager):
        assert manager.detect_topic("", "") == "general"

    def test_continuation_signal_stays_on_current(self, manager):
        for signal in ["yeah", "yes", "ok", "sure", "cool", "thanks"]:
            result = manager.detect_topic(signal, "my-thread")
            assert result == "my-thread", f"'{signal}' should be a continuation"

    def test_continuation_signal_no_current_returns_general(self, manager):
        assert manager.detect_topic("yeah", "") == "general"

    def test_short_message_stays_on_current(self, manager):
        # 3 words or fewer => continuation
        assert manager.detect_topic("do it", "deployment") == "deployment"
        assert manager.detect_topic("go ahead", "deployment") == "deployment"

    def test_short_message_no_current_returns_general(self, manager):
        assert manager.detect_topic("sounds good", "") == "general"

    def test_shift_signal_btw(self, manager):
        result = manager.detect_topic("btw what about the website", "deployment")
        assert "website" in result

    def test_shift_signal_anyway(self, manager):
        result = manager.detect_topic("anyway let's talk about payments", "deployment")
        assert "payments" in result or "let" in result

    def test_shift_signal_switching_to(self, manager):
        result = manager.detect_topic("switching to the billing system now", "deployment")
        assert "billing" in result or "system" in result

    def test_shift_signal_empty_rest(self, manager):
        result = manager.detect_topic("btw", "current-thread")
        assert result == "general"

    def test_new_topic_extracted_from_content(self, manager):
        result = manager.detect_topic("How does the deployment pipeline work?", "")
        assert len(result) > 0
        assert result != "general"

    def test_stopwords_filtered_out(self, manager):
        result = manager.detect_topic("What is the best approach?", "")
        # "What", "is", "the" are stopwords, "best" and "approach" survive
        assert "best" in result or "approach" in result

    def test_significant_words_as_topic(self, manager):
        result = manager.detect_topic("Tell me about antarisbot configuration", "")
        assert "antarisbot" in result or "configuration" in result

    def test_long_message_not_treated_as_continuation(self, manager):
        result = manager.detect_topic(
            "I have a question about the authentication system please help", "old-thread"
        )
        assert result != "old-thread"

    def test_shift_signal_topic_truncated_at_50(self, manager):
        long_rest = "a" * 60
        result = manager.detect_topic(f"btw {long_rest}", "thread")
        assert len(result) <= 50


# ── Thread filing ─────────────────────────────────────────────────────────────

class TestFileTurn:
    def test_file_user_turn_returns_topic(self, manager):
        topic = manager.file_turn("user1", "user", "Tell me about the website deployment")
        assert isinstance(topic, str)
        assert len(topic) > 0

    def test_file_assistant_turn_uses_same_topic(self, manager):
        # User sets the thread
        user_topic = manager.file_turn("user1", "user", "Tell me about the website deployment")
        # Assistant reply should land in the same thread
        asst_topic = manager.file_turn("user1", "assistant", "Sure, here is how it works...")
        assert user_topic == asst_topic

    def test_turns_stored_in_correct_thread(self, manager):
        manager.file_turn("user1", "user", "Talk to me about the deployment pipeline")
        manager.file_turn("user1", "assistant", "The pipeline has 10 stages.")
        turns = manager.get_thread("user1", "deployment pipeline")
        assert len(turns) >= 2
        assert any(t["role"] == "user" for t in turns)
        assert any(t["role"] == "assistant" for t in turns)

    def test_continuation_stays_on_thread(self, manager):
        manager.file_turn("user1", "user", "Explain the authentication system")
        manager.file_turn("user1", "assistant", "The auth system uses JWT tokens.")
        t1 = manager.file_turn("user1", "user", "yeah")
        t2 = manager.file_turn("user1", "assistant", "Right, JWT has expiry and refresh.")
        assert t1 == t2  # same thread

    def test_topic_shift_creates_new_thread(self, manager):
        manager.file_turn("user1", "user", "Explain the authentication system in detail please")
        t1 = manager._current.get("user1")
        manager.file_turn("user1", "user", "btw what about the billing payments integration")
        t2 = manager._current.get("user1")
        assert t1 != t2

    def test_turn_structure(self, manager):
        manager.file_turn("user1", "user", "How does the database work?")
        turns = manager.get_recent_threads("user1")
        assert len(turns) >= 1
        # Get actual turns
        thread_name = turns[0]["name"]
        all_turns = manager.get_thread("user1", thread_name)
        assert len(all_turns) == 1
        turn = all_turns[0]
        assert "role" in turn
        assert "content" in turn
        assert "timestamp" in turn
        assert "topic" in turn
        assert turn["role"] == "user"
        assert "database" in turn["content"].lower() or len(turn["content"]) > 0

    def test_multiple_users_isolated(self, manager):
        manager.file_turn("user1", "user", "Tell me about deployment pipelines")
        manager.file_turn("user2", "user", "btw let's talk about billing payments")
        threads_u1 = manager.list_threads("user1")
        threads_u2 = manager.list_threads("user2")
        names_u1 = {t["name"] for t in threads_u1}
        names_u2 = {t["name"] for t in threads_u2}
        # They may share topic names but the turn data is separate
        turns_u1 = manager.get_thread("user1", threads_u1[0]["name"])
        turns_u2 = manager.get_thread("user2", threads_u2[0]["name"])
        assert all(t["role"] == "user" for t in turns_u1)
        assert all(t["role"] == "user" for t in turns_u2)


# ── Thread retrieval ──────────────────────────────────────────────────────────

class TestGetThread:
    def test_get_thread_exact_match(self, manager):
        manager.file_turn("user1", "user", "Tell me about antarisbot deployment")
        thread_name = manager._current.get("user1")
        turns = manager.get_thread("user1", thread_name)
        assert len(turns) == 1

    def test_get_thread_fuzzy_match_substring(self, manager):
        manager.file_turn("user1", "user", "Tell me about the website deployment process")
        turns = manager.get_thread("user1", "website")
        assert len(turns) >= 1

    def test_get_thread_no_match_returns_empty(self, manager):
        manager.file_turn("user1", "user", "Tell me about the website deployment process")
        turns = manager.get_thread("user1", "zzznomatch999xyz")
        assert turns == []

    def test_get_thread_empty_user_returns_empty(self, manager):
        turns = manager.get_thread("new_user_no_history", "anything")
        assert turns == []

    def test_get_thread_token_overlap_match(self, manager):
        manager.file_turn("user1", "user", "How does the authentication system work in detail?")
        thread_name = manager._current.get("user1")
        # Query uses a word from the thread name
        query_word = thread_name.split()[0] if thread_name.split() else thread_name
        turns = manager.get_thread("user1", query_word)
        assert len(turns) >= 1


class TestGetRecentThreads:
    def test_returns_most_recent_first(self, manager):
        manager.file_turn("user1", "user", "Tell me about the deployment pipeline configuration")
        time.sleep(0.01)
        manager.file_turn("user1", "user", "btw what about the website authentication system")
        recents = manager.get_recent_threads("user1", limit=5)
        assert len(recents) >= 1
        # Most recent should be last filed
        if len(recents) >= 2:
            assert recents[0]["last_active"] >= recents[1]["last_active"]

    def test_limit_respected(self, manager):
        for i in range(10):
            manager.file_turn("user1", "user", f"btw topic number {i} explanation details here")
        recents = manager.get_recent_threads("user1", limit=3)
        assert len(recents) <= 3

    def test_empty_user_returns_empty(self, manager):
        recents = manager.get_recent_threads("ghost_user_xyz")
        assert recents == []

    def test_summary_has_required_fields(self, manager):
        manager.file_turn("user1", "user", "Tell me about the authentication configuration")
        recents = manager.get_recent_threads("user1")
        assert len(recents) >= 1
        s = recents[0]
        assert "name" in s
        assert "turn_count" in s
        assert "last_active" in s
        assert s["turn_count"] >= 1


class TestListThreads:
    def test_returns_all_threads(self, manager):
        manager.file_turn("user1", "user", "Tell me about the deployment pipeline process")
        manager.file_turn("user1", "user", "btw what about website authentication systems")
        threads = manager.list_threads("user1")
        assert len(threads) >= 1  # at least 1 (may merge depending on heuristic)

    def test_sorted_by_last_active_desc(self, manager):
        manager.file_turn("user1", "user", "Tell me about the database configuration system")
        time.sleep(0.01)
        manager.file_turn("user1", "user", "btw what about deployment pipeline configuration")
        threads = manager.list_threads("user1")
        if len(threads) >= 2:
            assert threads[0]["last_active"] >= threads[1]["last_active"]

    def test_empty_user_returns_empty(self, manager):
        assert manager.list_threads("nobody_here") == []

    def test_turn_count_accurate(self, manager):
        manager.file_turn("u2", "user", "Tell me about the authentication system configuration")
        manager.file_turn("u2", "assistant", "Sure, here is how it works.")
        manager.file_turn("u2", "user", "yeah")
        manager.file_turn("u2", "assistant", "Great, glad that helps.")
        threads = manager.list_threads("u2")
        total_turns = sum(t["turn_count"] for t in threads)
        assert total_turns == 4


# ── Persistence ───────────────────────────────────────────────────────────────

class TestPersistence:
    def test_save_and_reload(self, threads_dir):
        m1 = ThreadManager(threads_dir)
        m1.file_turn("user1", "user", "Tell me about the deployment pipeline configuration")
        m1.file_turn("user1", "assistant", "Sure, the pipeline has 10 stages.")

        # New manager instance reads from disk
        m2 = ThreadManager(threads_dir)
        threads = m2.list_threads("user1")
        assert len(threads) >= 1
        total = sum(t["turn_count"] for t in threads)
        assert total == 2

    def test_new_user_no_file(self, threads_dir):
        m = ThreadManager(threads_dir)
        # Should not raise; returns empty
        result = m.list_threads("brand_new_user")
        assert result == []

    def test_invalid_json_handled_gracefully(self, threads_dir):
        threads_dir.mkdir(parents=True, exist_ok=True)
        bad_file = threads_dir / "user1.json"
        bad_file.write_text("not valid json!!!")
        m = ThreadManager(threads_dir)
        # Should not raise; falls back to empty
        result = m.list_threads("user1")
        assert result == []

    def test_persisted_file_is_valid_json(self, threads_dir):
        m = ThreadManager(threads_dir)
        m.file_turn("user1", "user", "Tell me about the authentication configuration system")
        user_file = threads_dir / "user1.json"
        assert user_file.exists()
        data = json.loads(user_file.read_text())
        assert isinstance(data, dict)

    def test_user_id_with_special_chars_safe(self, threads_dir):
        m = ThreadManager(threads_dir)
        # Discord user IDs contain numbers; other platforms may have special chars
        user_id = "user@domain.com/path"
        m.file_turn(user_id, "user", "Tell me about the authentication configuration")
        # Should not raise; file path is sanitized
        threads = m.list_threads(user_id)
        assert len(threads) >= 1


# ── Edge cases ────────────────────────────────────────────────────────────────

class TestEdgeCases:
    def test_file_assistant_turn_without_prior_user_turn(self, manager):
        # Should default to "general" thread
        topic = manager.file_turn("user1", "assistant", "Hello, how can I help you?")
        assert topic == "general"

    def test_very_long_content_handled(self, manager):
        long_text = "authentication " * 500
        topic = manager.file_turn("user1", "user", long_text)
        assert isinstance(topic, str)

    def test_unicode_content(self, manager):
        topic = manager.file_turn("user1", "user", "Parlez-moi du systeme d'authentification")
        assert isinstance(topic, str)

    def test_empty_string_content(self, manager):
        topic = manager.file_turn("user1", "user", "")
        assert topic == "general"


# ── Fuzzy match helper ────────────────────────────────────────────────────────

class TestFuzzyMatch:
    def test_exact_match(self):
        assert _fuzzy_match("website", ["website", "deployment"]) == "website"

    def test_substring_match(self):
        result = _fuzzy_match("auth", ["authentication system", "deployment pipeline"])
        assert result == "authentication system"

    def test_token_overlap(self):
        result = _fuzzy_match("website deployment", ["deployment pipeline", "authentication"])
        assert result == "deployment pipeline"

    def test_no_match_returns_none(self):
        result = _fuzzy_match("zzznomatch", ["authentication", "deployment"])
        assert result is None

    def test_empty_names_returns_none(self):
        assert _fuzzy_match("anything", []) is None

    def test_query_contains_name(self):
        result = _fuzzy_match("all about the deployment", ["deployment", "auth"])
        assert result == "deployment"


# ── Pipeline integration (unit-level) ────────────────────────────────────────

@pytest.mark.asyncio
async def test_pipeline_files_threads():
    """Thread filing is called during the pipeline when threads is wired in."""
    from antarisbot.core.pipeline import Pipeline
    from antarisbot.channels.base import InboundMessage
    from antarisbot.llm.base import LLMResponse

    config = MagicMock()
    config.model = "claude-sonnet-4-20250514"
    config.rate_limit_messages = 20
    config.rate_limit_window_seconds = 60

    memory = MagicMock()
    memory.recall = AsyncMock(return_value=[])
    memory.ingest = AsyncMock()

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=(True, ""))
    guard.check_output = AsyncMock(return_value=(True, "Response from bot"))

    persona = MagicMock()
    persona.build_system_prompt = MagicMock(return_value="You are helpful.")
    persona.config_dir = ""

    llm = MagicMock()
    llm.complete = AsyncMock(return_value=LLMResponse(
        content="Response from bot",
        model="claude-sonnet-4-20250514",
        input_tokens=10,
        output_tokens=5,
        cost_usd=0.0,
    ))

    threads = MagicMock()
    threads.file_turn = MagicMock()

    adapter = MagicMock()
    adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

    pipeline = Pipeline(
        config=config,
        memory=memory,
        guard=guard,
        persona=persona,
        llm=llm,
        threads=threads,
    )

    inbound = InboundMessage(
        id="msg-1",
        user_id="user-123",
        user_name="TestUser",
        channel_id="ch-1",
        platform="terminal",
        text="Tell me about the deployment pipeline",
    )

    result = await pipeline.process(inbound, adapter)
    assert result.success is True
    # Both user and assistant turns should be filed
    assert threads.file_turn.call_count == 2
    calls = threads.file_turn.call_args_list
    assert calls[0][0][1] == "user"
    assert calls[1][0][1] == "assistant"


@pytest.mark.asyncio
async def test_pipeline_threads_failure_non_critical():
    """Thread filing failure should not break the pipeline."""
    from antarisbot.core.pipeline import Pipeline
    from antarisbot.channels.base import InboundMessage
    from antarisbot.llm.base import LLMResponse

    config = MagicMock()
    config.model = "claude-sonnet-4-20250514"
    config.rate_limit_messages = 20
    config.rate_limit_window_seconds = 60

    memory = MagicMock()
    memory.recall = AsyncMock(return_value=[])
    memory.ingest = AsyncMock()

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=(True, ""))
    guard.check_output = AsyncMock(return_value=(True, "OK"))

    persona = MagicMock()
    persona.build_system_prompt = MagicMock(return_value="You are helpful.")
    persona.config_dir = ""

    llm = MagicMock()
    llm.complete = AsyncMock(return_value=LLMResponse(
        content="OK",
        model="claude-sonnet-4-20250514",
        input_tokens=5,
        output_tokens=2,
        cost_usd=0.0,
    ))

    threads = MagicMock()
    threads.file_turn = MagicMock(side_effect=RuntimeError("disk full"))

    adapter = MagicMock()
    adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

    pipeline = Pipeline(
        config=config,
        memory=memory,
        guard=guard,
        persona=persona,
        llm=llm,
        threads=threads,
    )

    inbound = InboundMessage(
        id="msg-2",
        user_id="user-456",
        user_name="TestUser2",
        channel_id="ch-1",
        platform="terminal",
        text="Tell me about the deployment pipeline configuration",
    )

    result = await pipeline.process(inbound, adapter)
    # Pipeline should still succeed despite thread failure
    assert result.success is True
    assert "thread_filing" in result.failed_stages
