"""Tests for antarisbot.tools.tool_registry"""

import asyncio
from unittest.mock import Mock, AsyncMock, patch
import pytest

from antarisbot.tools.tool_registry import ToolRegistry
from antarisbot.tools import ToolDef, ToolResult, NativeTool
from antarisbot.tools.mcp_client import MCPClient


class MockNativeTool(NativeTool):
    """Mock native tool for testing."""
    
    def __init__(self, name: str, description: str, input_schema: dict):
        self._name = name
        self._description = description
        self._input_schema = input_schema
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def input_schema(self) -> dict:
        return self._input_schema
    
    async def execute(self, arguments: dict) -> ToolResult:
        return ToolResult(
            success=True,
            content=f"Native tool {self.name} executed with {arguments}",
            error=None,
            is_error=False
        )


class TestToolRegistry:
    """Tests for ToolRegistry class."""

    @pytest.fixture
    def registry(self):
        """Create a fresh ToolRegistry instance."""
        return ToolRegistry()

    @pytest.fixture
    def mock_native_tool(self):
        """Create a mock native tool."""
        return MockNativeTool(
            name="test_native",
            description="A test native tool",
            input_schema={"type": "object", "properties": {"arg": {"type": "string"}}}
        )

    @pytest.mark.asyncio
    async def test_init(self, registry):
        """Test ToolRegistry initialization."""
        assert not registry._initialized
        assert len(registry._native_tools) == 0
        assert len(registry._mcp_clients) == 0
        assert len(registry._tool_definitions) == 0

    @pytest.mark.asyncio
    async def test_initialize_empty_config(self, registry):
        """Test initializing with empty config."""
        await registry.initialize({})
        
        assert registry._initialized
        assert len(registry._native_tools) == 0
        assert len(registry._mcp_clients) == 0

    @pytest.mark.asyncio
    async def test_initialize_already_initialized(self, registry):
        """Test initializing when already initialized."""
        await registry.initialize({})
        
        # Second initialization should not raise error
        await registry.initialize({})
        assert registry._initialized

    @pytest.mark.asyncio
    async def test_initialize_with_mcp_servers(self, registry):
        """Test initializing with MCP servers in config."""
        config = {
            "mcp_servers": [
                {
                    "name": "test-server",
                    "transport": "stdio",
                    "command": ["python", "-m", "test_server"]
                }
            ]
        }
        
        with patch.object(registry, "add_mcp_server", new_callable=AsyncMock) as mock_add:
            await registry.initialize(config)
            
            mock_add.assert_called_once_with(
                name="test-server",
                transport="stdio",
                command=["python", "-m", "test_server"],
                env=None,
                url=None
            )

    @pytest.mark.asyncio
    async def test_register_native_tool(self, registry, mock_native_tool):
        """Test registering a native tool."""
        await registry.register_native("test_tool", mock_native_tool)
        
        assert "test_tool" in registry._native_tools
        assert "test_tool" in registry._tool_definitions
        
        tool_def = registry._tool_definitions["test_tool"]
        assert tool_def.name == "test_tool"
        assert tool_def.description == "A test native tool"
        assert tool_def.source == "native"

    @pytest.mark.asyncio
    async def test_register_native_tool_name_conflict_with_mcp(self, registry, mock_native_tool):
        """Test native tool registration overrides MCP tool with same name."""
        # Add MCP tool first
        mcp_tool_def = ToolDef(
            name="test_tool",
            description="MCP tool",
            input_schema={},
            source="mcp:server1"
        )
        registry._tool_definitions["test_tool"] = mcp_tool_def
        
        # Register native tool (should override)
        await registry.register_native("test_tool", mock_native_tool)
        
        assert "test_tool" in registry._tool_definitions
        tool_def = registry._tool_definitions["test_tool"]
        assert tool_def.source == "native"
        assert tool_def.description == "A test native tool"

    @pytest.mark.asyncio
    async def test_add_mcp_server_success(self, registry):
        """Test successfully adding MCP server."""
        mock_client = AsyncMock(spec=MCPClient)
        mock_client.name = "test-server"
        
        mock_tools = [
            ToolDef(
                name="mcp_tool1",
                description="MCP tool 1",
                input_schema={"type": "object"},
                source="mcp:test-server"
            ),
            ToolDef(
                name="mcp_tool2",
                description="MCP tool 2",
                input_schema={"type": "object"},
                source="mcp:test-server"
            )
        ]
        
        with patch("antarisbot.tools.tool_registry.MCPClient", return_value=mock_client):
            mock_client.connect = AsyncMock()
            mock_client.list_tools = AsyncMock(return_value=mock_tools)
            
            await registry.add_mcp_server(
                name="test-server",
                transport="stdio",
                command=["python", "-m", "test_server"]
            )
            
            assert "test-server" in registry._mcp_clients
            assert "mcp_tool1" in registry._tool_definitions
            assert "mcp_tool2" in registry._tool_definitions
            
            mock_client.connect.assert_called_once()
            mock_client.list_tools.assert_called_once()

    @pytest.mark.asyncio
    async def test_add_mcp_server_name_conflict(self, registry):
        """Test MCP tool name conflict resolution."""
        # Add native tool first
        mock_native_tool = MockNativeTool("conflicted_tool", "Native tool", {})
        await registry.register_native("conflicted_tool", mock_native_tool)
        
        mock_client = AsyncMock(spec=MCPClient)
        mock_client.name = "test-server"
        
        mock_tools = [
            ToolDef(
                name="conflicted_tool",  # Same name as native tool
                description="MCP tool",
                input_schema={"type": "object"},
                source="mcp:test-server"
            )
        ]
        
        with patch("antarisbot.tools.tool_registry.MCPClient", return_value=mock_client):
            mock_client.connect = AsyncMock()
            mock_client.list_tools = AsyncMock(return_value=mock_tools)
            
            await registry.add_mcp_server(
                name="test-server",
                transport="stdio",
                command=["python", "-m", "test_server"]
            )
            
            # Original native tool should still exist
            assert "conflicted_tool" in registry._tool_definitions
            assert registry._tool_definitions["conflicted_tool"].source == "native"
            
            # MCP tool should be prefixed
            assert "test-server.conflicted_tool" in registry._tool_definitions
            assert registry._tool_definitions["test-server.conflicted_tool"].source == "mcp:test-server"

    @pytest.mark.asyncio
    async def test_add_mcp_server_already_exists(self, registry):
        """Test adding MCP server that already exists."""
        mock_client = AsyncMock(spec=MCPClient)
        registry._mcp_clients["test-server"] = mock_client
        
        # Should not add again
        await registry.add_mcp_server(name="test-server")
        
        # Still only one client
        assert len(registry._mcp_clients) == 1

    @pytest.mark.asyncio
    async def test_add_mcp_server_connection_fails(self, registry):
        """Test MCP server connection failure."""
        mock_client = AsyncMock(spec=MCPClient)
        mock_client.connect = AsyncMock(side_effect=RuntimeError("Connection failed"))
        mock_client.disconnect = AsyncMock()
        
        with patch("antarisbot.tools.tool_registry.MCPClient", return_value=mock_client):
            with pytest.raises(RuntimeError, match="Connection failed"):
                await registry.add_mcp_server(
                    name="test-server",
                    transport="stdio",
                    command=["python", "-m", "test_server"]
                )
            
            # Should have attempted cleanup
            mock_client.disconnect.assert_called_once()
            assert "test-server" not in registry._mcp_clients

    @pytest.mark.asyncio
    async def test_remove_mcp_server(self, registry):
        """Test removing MCP server and its tools."""
        # Setup MCP server with tools
        mock_client = AsyncMock(spec=MCPClient)
        mock_client.disconnect = AsyncMock()
        registry._mcp_clients["test-server"] = mock_client
        
        # Add some tools from this server
        tool1 = ToolDef("tool1", "Tool 1", {}, "mcp:test-server")
        tool2 = ToolDef("tool2", "Tool 2", {}, "mcp:test-server")
        tool3 = ToolDef("tool3", "Tool 3", {}, "mcp:other-server")  # Different server
        
        registry._tool_definitions["tool1"] = tool1
        registry._tool_definitions["tool2"] = tool2
        registry._tool_definitions["tool3"] = tool3
        
        await registry.remove_mcp_server("test-server")
        
        assert "test-server" not in registry._mcp_clients
        assert "tool1" not in registry._tool_definitions
        assert "tool2" not in registry._tool_definitions
        assert "tool3" in registry._tool_definitions  # Should remain
        
        mock_client.disconnect.assert_called_once()

    @pytest.mark.asyncio
    async def test_remove_mcp_server_not_found(self, registry):
        """Test removing non-existent MCP server."""
        # Should not raise error
        await registry.remove_mcp_server("nonexistent-server")

    @pytest.mark.asyncio
    async def test_get_tool_definitions(self, registry, mock_native_tool):
        """Test getting tool definitions in Anthropic format."""
        # Add native tool
        await registry.register_native("native_tool", mock_native_tool)
        
        # Add MCP tool definition manually
        mcp_tool = ToolDef(
            name="mcp_tool",
            description="MCP tool",
            input_schema={"type": "object", "properties": {"param": {"type": "number"}}},
            source="mcp:server1"
        )
        registry._tool_definitions["mcp_tool"] = mcp_tool
        
        definitions = await registry.get_tool_definitions()
        
        assert len(definitions) == 2
        
        # Find tools by name
        native_def = next(d for d in definitions if d["name"] == "native_tool")
        mcp_def = next(d for d in definitions if d["name"] == "mcp_tool")
        
        # Check native tool
        assert native_def["description"] == "A test native tool"
        assert native_def["input_schema"]["properties"]["arg"]["type"] == "string"
        
        # Check MCP tool
        assert mcp_def["description"] == "MCP tool"
        assert mcp_def["input_schema"]["properties"]["param"]["type"] == "number"

    @pytest.mark.asyncio
    async def test_execute_tool_native(self, registry, mock_native_tool):
        """Test executing native tool."""
        await registry.register_native("test_tool", mock_native_tool)
        
        result = await registry.execute_tool("test_tool", {"arg": "test_value"})
        
        assert result.success
        assert "Native tool test_native executed with {'arg': 'test_value'}" in result.content

    @pytest.mark.asyncio
    async def test_execute_tool_mcp(self, registry):
        """Test executing MCP tool."""
        # Setup MCP client
        mock_client = AsyncMock(spec=MCPClient)
        mock_result = ToolResult(
            success=True,
            content="MCP tool executed",
            error=None,
            is_error=False
        )
        mock_client.call_tool = AsyncMock(return_value=mock_result)
        registry._mcp_clients["test-server"] = mock_client
        
        # Add MCP tool definition
        tool_def = ToolDef(
            name="mcp_tool",
            description="MCP tool",
            input_schema={},
            source="mcp:test-server"
        )
        registry._tool_definitions["mcp_tool"] = tool_def
        
        result = await registry.execute_tool("mcp_tool", {"param": "value"})
        
        assert result.success
        assert result.content == "MCP tool executed"
        mock_client.call_tool.assert_called_once_with("mcp_tool", {"param": "value"})

    @pytest.mark.asyncio
    async def test_execute_tool_mcp_with_prefix(self, registry):
        """Test executing MCP tool with server prefix in name."""
        # Setup MCP client
        mock_client = AsyncMock(spec=MCPClient)
        mock_result = ToolResult(success=True, content="Tool executed")
        mock_client.call_tool = AsyncMock(return_value=mock_result)
        registry._mcp_clients["test-server"] = mock_client
        
        # Add MCP tool definition with prefixed name
        tool_def = ToolDef(
            name="test-server.mcp_tool",
            description="MCP tool",
            input_schema={},
            source="mcp:test-server"
        )
        registry._tool_definitions["test-server.mcp_tool"] = tool_def
        
        result = await registry.execute_tool("test-server.mcp_tool", {"param": "value"})
        
        assert result.success
        # Should call with original name (without prefix)
        mock_client.call_tool.assert_called_once_with("mcp_tool", {"param": "value"})

    @pytest.mark.asyncio
    async def test_execute_tool_not_found(self, registry):
        """Test executing non-existent tool."""
        result = await registry.execute_tool("nonexistent_tool", {})
        
        assert not result.success
        assert result.is_error
        assert "Unknown tool: nonexistent_tool" in result.error

    @pytest.mark.asyncio
    async def test_execute_tool_unknown_source(self, registry):
        """Test executing tool with unknown source."""
        tool_def = ToolDef(
            name="unknown_tool",
            description="Unknown source",
            input_schema={},
            source="unknown:source"
        )
        registry._tool_definitions["unknown_tool"] = tool_def
        
        result = await registry.execute_tool("unknown_tool", {})
        
        assert not result.success
        assert result.is_error
        assert "Unknown tool source: unknown:source" in result.error

    @pytest.mark.asyncio
    async def test_execute_tool_native_exception(self, registry):
        """Test executing native tool that raises exception."""
        class FailingTool(NativeTool):
            @property
            def name(self) -> str:
                return "failing_tool"
            
            @property
            def description(self) -> str:
                return "A tool that fails"
            
            @property
            def input_schema(self) -> dict:
                return {}
            
            async def execute(self, arguments: dict) -> ToolResult:
                raise RuntimeError("Tool execution failed")
        
        await registry.register_native("failing_tool", FailingTool())
        
        result = await registry.execute_tool("failing_tool", {})
        
        assert not result.success
        assert result.is_error
        assert "Tool execution failed" in result.error

    @pytest.mark.asyncio
    async def test_execute_tool_mcp_server_not_found(self, registry):
        """Test executing MCP tool when server not found."""
        tool_def = ToolDef(
            name="orphaned_tool",
            description="Tool without server",
            input_schema={},
            source="mcp:nonexistent-server"
        )
        registry._tool_definitions["orphaned_tool"] = tool_def
        
        result = await registry.execute_tool("orphaned_tool", {})
        
        assert not result.success
        assert result.is_error
        assert "MCP server 'nonexistent-server' not found" in result.error

    @pytest.mark.asyncio
    async def test_get_server_status(self, registry):
        """Test getting server status."""
        # Setup mock clients
        mock_client1 = AsyncMock(spec=MCPClient)
        mock_client1._connected = True
        mock_client1.transport = "stdio"
        mock_client1.healthcheck = AsyncMock(return_value=True)
        
        mock_client2 = AsyncMock(spec=MCPClient)
        mock_client2._connected = False
        mock_client2.transport = "sse"
        mock_client2.healthcheck = AsyncMock(return_value=False)
        
        registry._mcp_clients["server1"] = mock_client1
        registry._mcp_clients["server2"] = mock_client2
        
        # Add some tools
        registry._tool_definitions["tool1"] = ToolDef("tool1", "", {}, "mcp:server1")
        registry._tool_definitions["tool2"] = ToolDef("tool2", "", {}, "mcp:server1")
        registry._tool_definitions["tool3"] = ToolDef("tool3", "", {}, "mcp:server2")
        
        status = await registry.get_server_status()
        
        assert len(status) == 2
        
        assert status["server1"]["connected"] is True
        assert status["server1"]["healthy"] is True
        assert status["server1"]["transport"] == "stdio"
        assert status["server1"]["tools"] == 2
        
        assert status["server2"]["connected"] is False
        assert status["server2"]["healthy"] is False
        assert status["server2"]["transport"] == "sse"
        assert status["server2"]["tools"] == 1

    @pytest.mark.asyncio
    async def test_shutdown(self, registry, mock_native_tool):
        """Test registry shutdown."""
        # Add some tools and servers
        await registry.register_native("native_tool", mock_native_tool)
        
        mock_client = AsyncMock(spec=MCPClient)
        mock_client.disconnect = AsyncMock()
        registry._mcp_clients["test-server"] = mock_client
        
        tool_def = ToolDef("mcp_tool", "", {}, "mcp:test-server")
        registry._tool_definitions["mcp_tool"] = tool_def
        registry._initialized = True
        
        await registry.shutdown()
        
        assert not registry._initialized
        assert len(registry._native_tools) == 0
        assert len(registry._mcp_clients) == 0
        assert len(registry._tool_definitions) == 0
        
        mock_client.disconnect.assert_called_once()

    @pytest.mark.asyncio
    async def test_thread_safety(self, registry):
        """Test thread safety with concurrent operations."""
        async def add_native_tools():
            for i in range(10):
                tool = MockNativeTool(f"tool_{i}", f"Tool {i}", {})
                await registry.register_native(f"tool_{i}", tool)
        
        async def add_mcp_servers():
            for i in range(10, 20):
                mock_client = AsyncMock(spec=MCPClient)
                mock_client.connect = AsyncMock()
                mock_client.list_tools = AsyncMock(return_value=[])
                
                with patch("antarisbot.tools.tool_registry.MCPClient", return_value=mock_client):
                    await registry.add_mcp_server(name=f"server_{i}")
        
        # Run operations concurrently
        await asyncio.gather(add_native_tools(), add_mcp_servers())
        
        # Verify all tools and servers were added
        assert len(registry._native_tools) == 10
        assert len(registry._mcp_clients) == 10

    def test_repr(self, registry):
        """Test string representation."""
        # Add some tools
        registry._tool_definitions["native1"] = ToolDef("native1", "", {}, "native")
        registry._tool_definitions["native2"] = ToolDef("native2", "", {}, "native")
        registry._tool_definitions["mcp1"] = ToolDef("mcp1", "", {}, "mcp:server1")
        registry._tool_definitions["mcp2"] = ToolDef("mcp2", "", {}, "mcp:server1")
        registry._tool_definitions["mcp3"] = ToolDef("mcp3", "", {}, "mcp:server2")
        
        # Add servers
        registry._mcp_clients["server1"] = Mock()
        registry._mcp_clients["server2"] = Mock()
        
        expected = "ToolRegistry(native_tools=2, mcp_tools=3, servers=2)"
        assert repr(registry) == expected