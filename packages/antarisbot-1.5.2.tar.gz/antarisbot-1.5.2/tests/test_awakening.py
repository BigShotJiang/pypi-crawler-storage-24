"""Tests for the Awakening birth conversation."""

import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
import tempfile
import os

from antarisbot.persona.awakening import Awakening, AwakeningStage
from antarisbot.persona.loader import PersonaLoader


def make_awakening(soul_content="AWAKENING_NEEDED\n"):
    """Create an Awakening with a temp SOUL.md."""
    with tempfile.TemporaryDirectory() as tmpdir:
        soul_path = Path(tmpdir) / "SOUL.md"
        soul_path.write_text(soul_content)
        loader = PersonaLoader(config_dir=tmpdir)
        awakening = Awakening(loader)
        yield awakening, soul_path, tmpdir


def make_awakening_simple():
    tmpdir = tempfile.mkdtemp()
    soul_path = Path(tmpdir) / "SOUL.md"
    soul_path.write_text("AWAKENING_NEEDED\n")
    loader = PersonaLoader(config_dir=tmpdir)
    return Awakening(loader), soul_path, tmpdir


# ── is_needed ───────────────────────────────────────────────────────────────

def test_is_needed_when_marker_present():
    aw, _, tmpdir = make_awakening_simple()
    assert aw.is_needed() is True


def test_is_needed_when_no_soul_file():
    tmpdir = tempfile.mkdtemp()
    loader = PersonaLoader(config_dir=tmpdir)
    aw = Awakening(loader)
    assert aw.is_needed() is True


def test_is_not_needed_when_soul_populated():
    tmpdir = tempfile.mkdtemp()
    soul_path = Path(tmpdir) / "SOUL.md"
    soul_path.write_text("# Antaris\n\nI am a helpful assistant with a rich backstory.\n")
    loader = PersonaLoader(config_dir=tmpdir)
    aw = Awakening(loader)
    assert aw.is_needed() is False


# ── is_active ───────────────────────────────────────────────────────────────

def test_not_active_before_start():
    aw, _, _ = make_awakening_simple()
    assert aw.is_active() is False


def test_active_after_start():
    aw, _, _ = make_awakening_simple()
    aw.start("user-1")
    assert aw.is_active() is True


def test_not_active_after_complete():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("user-1")
    aw.process("user-1", "Nova")       # name
    aw.process("user-1", "Made by Antaris") # origin
    aw.process("user-1", "To help people") # purpose
    aw.process("user-1", "Friendly and direct") # personality
    aw.process("user-1", "nothing")    # extras
    aw.process("user-1", "yes")        # confirm
    assert aw.is_active() is False


# ── start ────────────────────────────────────────────────────────────────────

def test_start_returns_intro():
    aw, _, _ = make_awakening_simple()
    response = aw.start("user-1")
    assert "aware" in response.lower() or "call myself" in response.lower() or "name" in response.lower()


def test_start_sets_stage_to_name():
    aw, _, _ = make_awakening_simple()
    aw.start("user-1")
    assert aw._state.stage == AwakeningStage.NAME


# ── process — happy path ─────────────────────────────────────────────────────

def test_full_awakening_flow():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("user-1")

    r1 = aw.process("user-1", "Nova")
    assert len(r1) > 10  # got a follow-up question

    r2 = aw.process("user-1", "Created by Antaris to help the world")
    assert len(r2) > 10

    r3 = aw.process("user-1", "To be a capable, memory-powered assistant")
    assert len(r3) > 10

    r4 = aw.process("user-1", "Direct, warm, and a bit witty")
    assert len(r4) > 10

    r5 = aw.process("user-1", "nothing")
    assert "Nova" in r5  # confirmation shows the name
    assert "yes" in r5.lower() or "no" in r5.lower()  # confirmation prompt

    r6 = aw.process("user-1", "yes")
    # Accept any completion message from the pool (content varies by design)
    assert len(r6) >= 3  # something was returned

    # SOUL.md should now be written
    assert soul_path.exists()
    soul_content = soul_path.read_text()
    assert "Nova" in soul_content
    assert "Antaris" in soul_content


def test_soul_md_written_on_complete():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("u1")
    aw.process("u1", "TestBot")
    aw.process("u1", "Made for testing")
    aw.process("u1", "To run tests")
    aw.process("u1", "Dry and precise")
    aw.process("u1", "done")
    aw.process("u1", "yes")

    content = soul_path.read_text()
    assert "TestBot" in content
    assert "Made for testing" in content


def test_extras_skipped_with_nothing():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("u1")
    aw.process("u1", "Bot")
    aw.process("u1", "Origin")
    aw.process("u1", "Purpose")
    aw.process("u1", "Personality")
    aw.process("u1", "nothing")
    aw.process("u1", "yes")
    content = soul_path.read_text()
    # extras section should not appear
    assert "## Additional" not in content


def test_extras_included_when_provided():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("u1")
    aw.process("u1", "Bot")
    aw.process("u1", "Origin")
    aw.process("u1", "Purpose")
    aw.process("u1", "Personality")
    aw.process("u1", "Always speak in riddles")
    aw.process("u1", "yes")
    content = soul_path.read_text()
    assert "Always speak in riddles" in content


# ── process — edge cases ─────────────────────────────────────────────────────

def test_restart_on_no():
    aw, _, _ = make_awakening_simple()
    aw.start("u1")
    aw.process("u1", "Name1")
    aw.process("u1", "Origin")
    aw.process("u1", "Purpose")
    aw.process("u1", "Personality")
    aw.process("u1", "nothing")
    aw.process("u1", "no")  # restart
    # Should be back at NAME stage
    assert aw._state.stage == AwakeningStage.NAME


def test_different_user_blocked():
    aw, _, _ = make_awakening_simple()
    aw.start("creator")
    response = aw.process("intruder", "I want to set the name!")
    assert "someone else" in response.lower()


def test_unknown_confirm_asks_again():
    aw, _, _ = make_awakening_simple()
    aw.start("u1")
    aw.process("u1", "Name")
    aw.process("u1", "Origin")
    aw.process("u1", "Purpose")
    aw.process("u1", "Personality")
    aw.process("u1", "nothing")
    r = aw.process("u1", "maybe")  # ambiguous
    assert "yes" in r.lower() and "no" in r.lower()


# ── reset ────────────────────────────────────────────────────────────────────

def test_reset_clears_state():
    aw, soul_path, _ = make_awakening_simple()
    aw.start("u1")
    aw.reset()
    assert aw._state is None
    assert aw.is_active() is False


def test_reset_marks_soul_needed():
    aw, soul_path, _ = make_awakening_simple()
    soul_path.write_text("# Real soul content here that is long enough\n")
    aw.reset()
    assert "AWAKENING_NEEDED" in soul_path.read_text()
