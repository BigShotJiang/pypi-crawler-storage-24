"""Tests for antarisbot.tools.mcp_client"""

import asyncio
import json
from unittest.mock import Mock, patch, AsyncMock, MagicMock
import pytest
import httpx

from antarisbot.tools.mcp_client import MCPClient
from antarisbot.tools import ToolDef, ToolResult


class TestMCPClient:
    """Tests for MCPClient class."""

    def test_init(self):
        """Test MCPClient initialization."""
        client = MCPClient(
            name="test-server",
            transport="stdio",
            command=["python", "-m", "test_server"],
            env={"TEST": "value"},
            timeout=10.0
        )
        
        assert client.name == "test-server"
        assert client.transport == "stdio"
        assert client.command == ["python", "-m", "test_server"]
        assert client.env == {"TEST": "value"}
        assert client.timeout == 10.0
        assert not client._connected

    @pytest.mark.asyncio
    async def test_connect_stdio_success(self):
        """Test successful stdio connection."""
        client = MCPClient(
            name="test-server",
            transport="stdio",
            command=["echo", "test"]
        )
        
        mock_process = Mock()
        mock_process.returncode = None  # Process is still running
        mock_process.stdin = Mock()
        mock_process.stdout = Mock()
        
        # Mock async readline to return JSON response
        async def mock_readline():
            return b'{"jsonrpc": "2.0", "id": 1, "result": {}}\n'
        mock_process.stdout.readline = mock_readline
        
        # Mock async drain method
        async def mock_drain():
            pass
        mock_process.stdin.drain = mock_drain
        
        with patch("asyncio.create_subprocess_exec", new_callable=AsyncMock) as mock_create:
            mock_create.return_value = mock_process
            with patch("asyncio.sleep", new_callable=AsyncMock):
                await client.connect()
                
                assert client._connected
                assert client._process == mock_process

    @pytest.mark.asyncio
    async def test_connect_stdio_process_fails(self):
        """Test stdio connection when process fails to start."""
        client = MCPClient(
            name="test-server",
            transport="stdio",
            command=["nonexistent-command"]
        )
        
        mock_process = Mock()
        mock_process.returncode = 1  # Process already exited
        
        with patch("asyncio.create_subprocess_exec", new_callable=AsyncMock) as mock_create:
            mock_create.return_value = mock_process
            with patch("asyncio.sleep", new_callable=AsyncMock):
                with pytest.raises(RuntimeError, match="MCP server process failed to start"):
                    await client.connect()

    @pytest.mark.asyncio
    async def test_connect_sse_success(self):
        """Test successful SSE connection."""
        client = MCPClient(
            name="test-server",
            transport="sse",
            url="http://localhost:8000"
        )
        
        mock_http_client = AsyncMock()
        mock_response = Mock()
        mock_response.raise_for_status = Mock()
        mock_http_client.get.return_value = mock_response
        
        with patch("httpx.AsyncClient", return_value=mock_http_client):
            with patch.object(client, "_send_initialize", new_callable=AsyncMock):
                await client.connect()
                
                assert client._connected
                assert client._http_client == mock_http_client
                mock_http_client.get.assert_called_once_with("http://localhost:8000/health")

    @pytest.mark.asyncio
    async def test_connect_sse_fails(self):
        """Test SSE connection failure."""
        client = MCPClient(
            name="test-server",
            transport="sse",
            url="http://localhost:8000"
        )
        
        mock_http_client = AsyncMock()
        mock_http_client.get.side_effect = httpx.RequestError("Connection failed")
        
        with patch("httpx.AsyncClient", return_value=mock_http_client):
            with pytest.raises(RuntimeError, match="Failed to connect to MCP server"):
                await client.connect()

    @pytest.mark.asyncio
    async def test_connect_unsupported_transport(self):
        """Test connection with unsupported transport."""
        client = MCPClient(
            name="test-server",
            transport="websocket"  # Unsupported
        )
        
        with pytest.raises(ValueError, match="Unsupported transport: websocket"):
            await client.connect()

    @pytest.mark.asyncio
    async def test_disconnect_stdio(self):
        """Test stdio disconnection."""
        client = MCPClient(
            name="test-server",
            transport="stdio"
        )
        
        mock_process = Mock()
        mock_process.terminate = Mock()
        mock_process.wait = AsyncMock(return_value=0)
        
        client._process = mock_process
        client._connected = True
        
        with patch("asyncio.wait_for", new_callable=AsyncMock) as mock_wait_for:
            mock_wait_for.return_value = 0
            await client.disconnect()
            
            assert not client._connected
            assert client._process is None
            mock_process.terminate.assert_called_once()

    @pytest.mark.asyncio
    async def test_disconnect_stdio_force_kill(self):
        """Test stdio disconnection with force kill."""
        client = MCPClient(
            name="test-server",
            transport="stdio"
        )
        
        mock_process = Mock()
        mock_process.terminate = Mock()
        mock_process.wait = AsyncMock(return_value=0)
        mock_process.kill = Mock()
        client._process = mock_process
        client._connected = True
        
        with patch("asyncio.wait_for", new_callable=AsyncMock) as mock_wait_for:
            mock_wait_for.side_effect = [asyncio.TimeoutError, 0]
            await client.disconnect()
            
            assert not client._connected
            assert client._process is None
            mock_process.terminate.assert_called_once()
            mock_process.kill.assert_called_once()

    @pytest.mark.asyncio
    async def test_disconnect_sse(self):
        """Test SSE disconnection."""
        client = MCPClient(
            name="test-server",
            transport="sse"
        )
        
        mock_http_client = AsyncMock()
        client._http_client = mock_http_client
        client._connected = True
        
        await client.disconnect()
        
        assert not client._connected
        assert client._http_client is None
        mock_http_client.aclose.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_initialize(self):
        """Test sending initialize message."""
        client = MCPClient(name="test-server")
        client._connected = False
        
        mock_response = {"jsonrpc": "2.0", "id": 1, "result": {}}
        
        with patch.object(client, "_send_request", new_callable=AsyncMock, return_value=mock_response) as mock_send:
            await client._send_initialize()
            
            # Verify initialize message was sent
            call_args = mock_send.call_args[0][0]
            assert call_args["method"] == "initialize"
            assert call_args["params"]["clientInfo"]["name"] == "antarisbot"
            assert call_args["params"]["protocolVersion"] == "2024-11-05"

    @pytest.mark.asyncio
    async def test_send_initialize_error(self):
        """Test initialize message error response."""
        client = MCPClient(name="test-server")
        
        mock_response = {"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": "Init failed"}}
        
        with patch.object(client, "_send_request", new_callable=AsyncMock, return_value=mock_response):
            with pytest.raises(RuntimeError, match="MCP initialize failed"):
                await client._send_initialize()

    @pytest.mark.asyncio
    async def test_list_tools_success(self):
        """Test successful tool listing."""
        client = MCPClient(name="test-server")
        client._connected = True
        
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "tools": [
                    {
                        "name": "test_tool",
                        "description": "A test tool",
                        "inputSchema": {"type": "object", "properties": {"arg": {"type": "string"}}}
                    }
                ]
            }
        }
        
        with patch.object(client, "_send_request", new_callable=AsyncMock, return_value=mock_response) as mock_send:
            tools = await client.list_tools()
            
            assert len(tools) == 1
            tool = tools[0]
            assert tool.name == "test_tool"
            assert tool.description == "A test tool"
            assert tool.input_schema == {"type": "object", "properties": {"arg": {"type": "string"}}}
            assert tool.source == "mcp:test-server"
            
            # Verify correct method was called
            call_args = mock_send.call_args[0][0]
            assert call_args["method"] == "tools/list"

    @pytest.mark.asyncio
    async def test_list_tools_not_connected(self):
        """Test tool listing when not connected."""
        client = MCPClient(name="test-server")
        client._connected = False
        
        with pytest.raises(RuntimeError, match="Not connected to MCP server"):
            await client.list_tools()

    @pytest.mark.asyncio
    async def test_list_tools_error_with_retry(self):
        """Test tool listing error with retry mechanism."""
        client = MCPClient(name="test-server")
        client._connected = True
        client._retry_count = 0
        client._max_retries = 1
        
        error_response = {"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": "Server error"}}
        success_response = {
            "jsonrpc": "2.0",
            "id": 2,
            "result": {"tools": []}
        }
        
        with patch.object(client, "_send_request", new_callable=AsyncMock, side_effect=[error_response, success_response]):
            with patch.object(client, "disconnect", new_callable=AsyncMock):
                with patch.object(client, "connect", new_callable=AsyncMock):
                    tools = await client.list_tools()
                    
                    assert len(tools) == 0
                    assert client._retry_count == 0  # Retry count is reset at start of method

    @pytest.mark.asyncio
    async def test_call_tool_success(self):
        """Test successful tool call."""
        client = MCPClient(name="test-server")
        client._connected = True
        
        mock_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "content": [
                    {"type": "text", "text": "Tool executed successfully"}
                ]
            }
        }
        
        with patch.object(client, "_send_request", new_callable=AsyncMock, return_value=mock_response) as mock_send:
            result = await client.call_tool("test_tool", {"arg": "value"})
            
            assert result.success
            assert result.content == "Tool executed successfully"
            assert not result.is_error
            assert result.error is None
            
            # Verify correct method and params
            call_args = mock_send.call_args[0][0]
            assert call_args["method"] == "tools/call"
            assert call_args["params"]["name"] == "test_tool"
            assert call_args["params"]["arguments"] == {"arg": "value"}

    @pytest.mark.asyncio
    async def test_call_tool_error_response(self):
        """Test tool call with error response."""
        client = MCPClient(name="test-server")
        client._connected = True
        
        mock_response = {"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": "Tool not found"}}
        
        with patch.object(client, "_send_request", new_callable=AsyncMock, return_value=mock_response):
            result = await client.call_tool("nonexistent_tool", {})
            
            assert not result.success
            assert result.is_error
            assert "Tool call failed" in result.error
            assert result.content == ""

    @pytest.mark.asyncio
    async def test_call_tool_not_connected(self):
        """Test tool call when not connected."""
        client = MCPClient(name="test-server")
        client._connected = False
        
        with pytest.raises(RuntimeError, match="Not connected to MCP server"):
            await client.call_tool("test_tool", {})

    @pytest.mark.asyncio
    async def test_healthcheck_connected(self):
        """Test healthcheck when connected."""
        client = MCPClient(name="test-server")
        client._connected = True
        
        mock_response = {"jsonrpc": "2.0", "id": 1, "result": {}}
        
        with patch.object(client, "_send_request", new_callable=AsyncMock, return_value=mock_response):
            is_healthy = await client.healthcheck()
            assert is_healthy

    @pytest.mark.asyncio
    async def test_healthcheck_not_connected(self):
        """Test healthcheck when not connected."""
        client = MCPClient(name="test-server")
        client._connected = False
        
        is_healthy = await client.healthcheck()
        assert not is_healthy

    @pytest.mark.asyncio
    async def test_healthcheck_request_fails(self):
        """Test healthcheck when request fails."""
        client = MCPClient(name="test-server")
        client._connected = True
        
        with patch.object(client, "_send_request", new_callable=AsyncMock, side_effect=Exception("Network error")):
            is_healthy = await client.healthcheck()
            assert not is_healthy

    def test_next_request_id(self):
        """Test request ID generation."""
        client = MCPClient(name="test-server")
        
        # Request IDs should increment
        assert client._next_request_id() == 1
        assert client._next_request_id() == 2
        assert client._next_request_id() == 3

    @pytest.mark.asyncio
    async def test_send_request_stdio(self):
        """Test sending request via stdio."""
        client = MCPClient(name="test-server", transport="stdio")
        
        mock_process = Mock()
        mock_process.returncode = None  # Process is running
        mock_process.stdin = Mock()
        mock_process.stdout = Mock()
        
        # Mock async methods
        async def mock_readline():
            return b'{"jsonrpc": "2.0", "id": 1, "result": {}}\n'
        mock_process.stdout.readline = mock_readline
        
        async def mock_drain():
            pass
        mock_process.stdin.drain = mock_drain
        
        client._process = mock_process
        
        message = {"jsonrpc": "2.0", "id": 1, "method": "test"}
        response = await client._send_request_stdio(message)
        
        assert response == {"jsonrpc": "2.0", "id": 1, "result": {}}
        mock_process.stdin.write.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_request_stdio_process_dead(self):
        """Test stdio request when process is dead."""
        client = MCPClient(name="test-server", transport="stdio")
        
        mock_process = Mock()
        mock_process.returncode = 1  # Process exited
        client._process = mock_process
        
        message = {"jsonrpc": "2.0", "id": 1, "method": "test"}
        
        with pytest.raises(RuntimeError, match="MCP process is not running"):
            await client._send_request_stdio(message)

    @pytest.mark.asyncio
    async def test_send_request_sse(self):
        """Test sending request via SSE."""
        client = MCPClient(name="test-server", transport="sse")
        
        mock_http_client = AsyncMock()
        mock_response = Mock()
        mock_response.raise_for_status = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": {}}
        mock_http_client.post.return_value = mock_response
        
        client._http_client = mock_http_client
        client.url = "http://localhost:8000"
        
        message = {"jsonrpc": "2.0", "id": 1, "method": "test"}
        response = await client._send_request_sse(message)
        
        assert response == {"jsonrpc": "2.0", "id": 1, "result": {}}
        mock_http_client.post.assert_called_once_with(
            "http://localhost:8000/mcp",
            json=message,
            timeout=30.0
        )

    @pytest.mark.asyncio
    async def test_send_request_sse_no_client(self):
        """Test SSE request when HTTP client not connected."""
        client = MCPClient(name="test-server", transport="sse")
        client._http_client = None
        
        message = {"jsonrpc": "2.0", "id": 1, "method": "test"}
        
        with pytest.raises(RuntimeError, match="HTTP client not connected"):
            await client._send_request_sse(message)

    def test_repr(self):
        """Test string representation."""
        client = MCPClient(name="test-server", transport="stdio")
        expected = "MCPClient(name=test-server, transport=stdio, connected=False)"
        assert repr(client) == expected