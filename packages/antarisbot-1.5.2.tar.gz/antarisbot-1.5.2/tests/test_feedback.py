"""
Tests for FeedbackTracker — reaction-based implicit training.
"""
import json
import time
import pytest
from pathlib import Path

from antarisbot.core.feedback import (
    FeedbackTracker,
    FeedbackEntry,
    POSITIVE_REACTIONS,
    NEGATIVE_REACTIONS,
    MAX_ENTRIES,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def tracker(tmp_path):
    return FeedbackTracker(store_dir=str(tmp_path / "feedback"))


# ── record_feedback ───────────────────────────────────────────────────────────

def test_record_feedback_stores_entry(tracker):
    result = tracker.record_feedback("user1", "Good morning!", "👍")
    assert result is True
    stats = tracker.get_stats("user1")
    assert stats["total"] == 1
    assert stats["positive"] == 1
    assert stats["negative"] == 0


def test_record_feedback_negative(tracker):
    result = tracker.record_feedback("user1", "Meh response.", "👎")
    assert result is True
    stats = tracker.get_stats("user1")
    assert stats["negative"] == 1
    assert stats["positive"] == 0


def test_record_feedback_unknown_emoji_ignored(tracker):
    result = tracker.record_feedback("user1", "Some message.", "🤔")
    assert result is False
    stats = tracker.get_stats("user1")
    assert stats["total"] == 0


def test_record_feedback_all_positive_reactions(tracker):
    for emoji in POSITIVE_REACTIONS:
        tracker.record_feedback("user_pos", f"msg {emoji}", emoji)
    stats = tracker.get_stats("user_pos")
    assert stats["positive"] == len(POSITIVE_REACTIONS)
    assert stats["negative"] == 0


def test_record_feedback_all_negative_reactions(tracker):
    for emoji in NEGATIVE_REACTIONS:
        tracker.record_feedback("user_neg", f"msg {emoji}", emoji)
    stats = tracker.get_stats("user_neg")
    assert stats["negative"] == len(NEGATIVE_REACTIONS)
    assert stats["positive"] == 0


# ── Positive/negative classification ──────────────────────────────────────────

def test_get_positive_patterns_returns_only_positive(tracker):
    tracker.record_feedback("u", "great msg", "👍")
    tracker.record_feedback("u", "bad msg", "👎")
    tracker.record_feedback("u", "fire msg", "🔥")
    positives = tracker.get_positive_patterns("u")
    assert "great msg" in positives
    assert "fire msg" in positives
    assert "bad msg" not in positives


def test_get_negative_patterns_returns_only_negative(tracker):
    tracker.record_feedback("u", "ok msg", "✅")
    tracker.record_feedback("u", "bad msg", "❌")
    tracker.record_feedback("u", "confused msg", "😕")
    negatives = tracker.get_negative_patterns("u")
    assert "bad msg" in negatives
    assert "confused msg" in negatives
    assert "ok msg" not in negatives


# ── get_context ───────────────────────────────────────────────────────────────

def test_get_context_empty_when_no_feedback(tracker):
    ctx = tracker.get_context("no_user")
    assert ctx == ""


def test_get_context_includes_positive_and_negative(tracker):
    tracker.record_feedback("u", "I liked this response about Python.", "👍")
    tracker.record_feedback("u", "This was too long and verbose.", "👎")
    ctx = tracker.get_context("u")
    assert "positively" in ctx
    assert "negatively" in ctx
    assert "Python" in ctx
    assert "verbose" in ctx
    assert "Adapt your responses accordingly." in ctx


def test_get_context_only_positive(tracker):
    tracker.record_feedback("u", "Nice and concise.", "👍")
    ctx = tracker.get_context("u")
    assert "positively" in ctx
    assert "negatively" not in ctx


def test_get_context_only_negative(tracker):
    tracker.record_feedback("u", "Way too much jargon.", "👎")
    ctx = tracker.get_context("u")
    assert "negatively" in ctx
    assert "positively" not in ctx


def test_get_context_caps_at_five_previews(tracker):
    for i in range(10):
        tracker.record_feedback("u", f"Positive response number {i}", "👍")
    ctx = tracker.get_context("u")
    # Should show at most 5 bullet items in positive block
    # Count occurrences of "  - " prefix lines
    bullet_lines = [line for line in ctx.splitlines() if line.startswith("  - ")]
    assert len(bullet_lines) <= 5


# ── Rolling window ────────────────────────────────────────────────────────────

def test_rolling_window_keeps_last_max_entries(tracker):
    # Add MAX_ENTRIES + 10 entries
    for i in range(MAX_ENTRIES + 10):
        tracker.record_feedback("u", f"msg {i}", "👍")
    stats = tracker.get_stats("u")
    assert stats["total"] == MAX_ENTRIES


def test_rolling_window_discards_oldest(tracker):
    for i in range(MAX_ENTRIES + 5):
        tracker.record_feedback("u", f"msg {i}", "👍")
    positives = tracker.get_positive_patterns("u")
    # The oldest entries (msg 0 through msg 4) should be gone
    assert "msg 0" not in positives
    # Recent entries should still be there
    assert f"msg {MAX_ENTRIES + 4}" in positives


# ── Persistence ───────────────────────────────────────────────────────────────

def test_persistence_roundtrip(tmp_path):
    store_dir = str(tmp_path / "feedback")
    tracker1 = FeedbackTracker(store_dir=store_dir)
    tracker1.record_feedback("user_x", "Hello world!", "👍")
    tracker1.record_feedback("user_x", "Ugh, verbose.", "👎")

    # Create a new instance pointing at the same directory
    tracker2 = FeedbackTracker(store_dir=store_dir)
    stats = tracker2.get_stats("user_x")
    assert stats["positive"] == 1
    assert stats["negative"] == 1
    assert stats["total"] == 2


def test_persistence_json_file_created(tmp_path):
    store_dir = tmp_path / "feedback"
    tracker = FeedbackTracker(store_dir=str(store_dir))
    tracker.record_feedback("abc123", "Test message.", "🔥")

    # File should exist with safe filename
    files = list(store_dir.iterdir())
    assert len(files) == 1
    data = json.loads(files[0].read_text(encoding="utf-8"))
    assert len(data) == 1
    assert data[0]["reaction"] == "🔥"
    assert data[0]["message_preview"] == "Test message."


def test_persistence_preview_truncated_to_200(tmp_path):
    store_dir = str(tmp_path / "feedback")
    tracker = FeedbackTracker(store_dir=store_dir)
    long_text = "x" * 500
    tracker.record_feedback("u", long_text, "👍")
    positives = tracker.get_positive_patterns("u")
    assert len(positives[0]) == 200


# ── clear ─────────────────────────────────────────────────────────────────────

def test_clear_removes_all_entries(tracker):
    tracker.record_feedback("u", "good", "👍")
    tracker.record_feedback("u", "bad", "👎")
    tracker.clear("u")
    stats = tracker.get_stats("u")
    assert stats["total"] == 0


def test_clear_removes_file(tmp_path):
    store_dir = str(tmp_path / "feedback")
    tracker = FeedbackTracker(store_dir=store_dir)
    tracker.record_feedback("u", "msg", "👍")
    feedback_dir = Path(store_dir)
    assert len(list(feedback_dir.iterdir())) == 1
    tracker.clear("u")
    assert len(list(feedback_dir.iterdir())) == 0


def test_clear_nonexistent_user_is_safe(tracker):
    # Should not raise
    tracker.clear("nobody")


# ── FeedbackEntry ─────────────────────────────────────────────────────────────

def test_feedback_entry_roundtrip():
    ts = time.time()
    entry = FeedbackEntry(message_preview="Hello", reaction="👍", timestamp=ts)
    d = entry.to_dict()
    assert d["message_preview"] == "Hello"
    assert d["reaction"] == "👍"
    assert d["timestamp"] == ts

    restored = FeedbackEntry.from_dict(d)
    assert restored.message_preview == "Hello"
    assert restored.reaction == "👍"
    assert restored.timestamp == ts


# ── Per-user isolation ────────────────────────────────────────────────────────

def test_per_user_isolation(tracker):
    tracker.record_feedback("alice", "Alice likes this.", "👍")
    tracker.record_feedback("bob", "Bob dislikes this.", "👎")

    alice_stats = tracker.get_stats("alice")
    bob_stats = tracker.get_stats("bob")

    assert alice_stats["positive"] == 1
    assert alice_stats["negative"] == 0
    assert bob_stats["negative"] == 1
    assert bob_stats["positive"] == 0


# ── Stats ─────────────────────────────────────────────────────────────────────

def test_stats_initial_user(tracker):
    stats = tracker.get_stats("brand_new_user")
    assert stats == {"positive": 0, "negative": 0, "total": 0}


def test_stats_mixed(tracker):
    for emoji in ["👍", "👍", "👎", "🔥", "❌"]:
        tracker.record_feedback("u", "msg", emoji)
    stats = tracker.get_stats("u")
    assert stats["positive"] == 3  # 👍, 👍, 🔥
    assert stats["negative"] == 2  # 👎, ❌
    assert stats["total"] == 5
