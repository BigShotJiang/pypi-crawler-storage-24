"""Tests for TeachingStore and !teach command integration."""
import json
import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from antarisbot.core.teachings import TeachingStore


# ── TeachingStore unit tests ──────────────────────────────────────────────────

class TestTeachingStore:
    def test_add_returns_count(self, tmp_path):
        store = TeachingStore(tmp_path)
        count = store.add("user1", "I prefer concise answers")
        assert count == 1
        count = store.add("user1", "my timezone is PST")
        assert count == 2

    def test_list_empty(self, tmp_path):
        store = TeachingStore(tmp_path)
        assert store.list("user1") == []

    def test_list_returns_stored(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "teaching one")
        store.add("user1", "teaching two")
        items = store.list("user1")
        assert len(items) == 2
        assert items[0]["text"] == "teaching one"
        assert items[1]["text"] == "teaching two"

    def test_list_includes_created_timestamp(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "some fact")
        items = store.list("user1")
        assert "created" in items[0]
        assert items[0]["created"].endswith("+00:00") or "Z" in items[0]["created"] or "T" in items[0]["created"]

    def test_remove_valid_index(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "first")
        store.add("user1", "second")
        store.add("user1", "third")
        result = store.remove("user1", 2)
        assert result is True
        items = store.list("user1")
        assert len(items) == 2
        assert items[0]["text"] == "first"
        assert items[1]["text"] == "third"

    def test_remove_first_item(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "first")
        store.add("user1", "second")
        result = store.remove("user1", 1)
        assert result is True
        items = store.list("user1")
        assert len(items) == 1
        assert items[0]["text"] == "second"

    def test_remove_invalid_index_zero(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "teaching")
        result = store.remove("user1", 0)
        assert result is False

    def test_remove_invalid_index_out_of_range(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "teaching")
        result = store.remove("user1", 99)
        assert result is False

    def test_remove_on_empty_store(self, tmp_path):
        store = TeachingStore(tmp_path)
        result = store.remove("user1", 1)
        assert result is False

    def test_clear_returns_count(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "one")
        store.add("user1", "two")
        count = store.clear("user1")
        assert count == 2
        assert store.list("user1") == []

    def test_clear_empty_returns_zero(self, tmp_path):
        store = TeachingStore(tmp_path)
        count = store.clear("user1")
        assert count == 0

    def test_per_user_isolation(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "user1 fact")
        store.add("user2", "user2 fact")
        assert len(store.list("user1")) == 1
        assert store.list("user1")[0]["text"] == "user1 fact"
        assert len(store.list("user2")) == 1
        assert store.list("user2")[0]["text"] == "user2 fact"

    def test_persists_to_disk(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "persistent fact")
        # Create a new instance pointing to the same dir
        store2 = TeachingStore(tmp_path)
        items = store2.list("user1")
        assert len(items) == 1
        assert items[0]["text"] == "persistent fact"

    def test_get_context_empty(self, tmp_path):
        store = TeachingStore(tmp_path)
        ctx = store.get_context("user1")
        assert ctx == ""

    def test_get_context_with_teachings(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "I prefer concise answers")
        store.add("user1", "my timezone is PST")
        ctx = store.get_context("user1")
        assert "## User Teachings (remember these):" in ctx
        assert "- I prefer concise answers" in ctx
        assert "- my timezone is PST" in ctx

    def test_get_context_format(self, tmp_path):
        store = TeachingStore(tmp_path)
        store.add("user1", "test fact")
        ctx = store.get_context("user1")
        lines = ctx.splitlines()
        assert lines[0] == "## User Teachings (remember these):"
        assert lines[1] == "- test fact"

    def test_store_dir_created(self, tmp_path):
        new_dir = tmp_path / "subdir" / "teachings"
        store = TeachingStore(new_dir)
        assert new_dir.exists()

    def test_corrupted_json_returns_empty(self, tmp_path):
        store = TeachingStore(tmp_path)
        bad_file = tmp_path / "user1.json"
        bad_file.write_text("not valid json {{{")
        assert store.list("user1") == []

    def test_add_after_corrupted_json(self, tmp_path):
        store = TeachingStore(tmp_path)
        bad_file = tmp_path / "user1.json"
        bad_file.write_text("corrupted")
        count = store.add("user1", "new teaching")
        assert count == 1


# ── Pipeline integration test ─────────────────────────────────────────────────

class TestTeachingsInPipeline:
    @pytest.mark.asyncio
    async def test_teachings_injected_into_system_prompt(self, tmp_path):
        """Teachings should appear in the system prompt passed to the LLM."""
        from antarisbot.core.pipeline import Pipeline
        from antarisbot.channels.base import InboundMessage

        # Set up a TeachingStore with a teaching
        teach_store = TeachingStore(tmp_path / "teachings")
        teach_store.add("user42", "I prefer bullet points")

        # Mock all dependencies
        config = MagicMock()
        config.model = "test-model"
        config.rate_limit_messages = 20
        config.rate_limit_window_seconds = 60

        memory = MagicMock()
        memory.recall = AsyncMock(return_value=[])
        memory.ingest = AsyncMock()

        guard = MagicMock()
        guard.check_input = AsyncMock(return_value=(True, ""))
        guard.check_output = AsyncMock(return_value=(True, "hello"))

        persona = MagicMock()
        persona.config_dir = ""
        persona.build_system_prompt = MagicMock(return_value="You are a helpful bot.")
        persona.update_user_context = MagicMock()

        captured_system_prompts = []

        async def mock_complete(messages, system=None, model=None):
            captured_system_prompts.append(system)
            resp = MagicMock()
            resp.content = "hello"
            resp.input_tokens = 10
            resp.output_tokens = 5
            resp.cost_usd = 0.0
            return resp

        llm = MagicMock()
        llm.complete = mock_complete

        adapter = MagicMock()
        adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

        pipeline = Pipeline(
            config=config,
            memory=memory,
            guard=guard,
            persona=persona,
            llm=llm,
            teachings=teach_store,
        )

        inbound = InboundMessage(
            id="msg1",
            user_id="user42",
            user_name="TestUser",
            channel_id="ch1",
            platform="discord",
            text="hello",
        )

        result = await pipeline.process(inbound, adapter)
        assert result.success
        assert len(captured_system_prompts) == 1
        system_prompt = captured_system_prompts[0]
        assert "User Teachings" in system_prompt
        assert "I prefer bullet points" in system_prompt

    @pytest.mark.asyncio
    async def test_no_teachings_no_injection(self, tmp_path):
        """Empty teaching store should not inject anything into system prompt."""
        from antarisbot.core.pipeline import Pipeline
        from antarisbot.channels.base import InboundMessage

        teach_store = TeachingStore(tmp_path / "teachings")
        # No teachings added

        config = MagicMock()
        config.model = "test-model"
        config.rate_limit_messages = 20
        config.rate_limit_window_seconds = 60

        memory = MagicMock()
        memory.recall = AsyncMock(return_value=[])
        memory.ingest = AsyncMock()

        guard = MagicMock()
        guard.check_input = AsyncMock(return_value=(True, ""))
        guard.check_output = AsyncMock(return_value=(True, "hello"))

        persona = MagicMock()
        persona.config_dir = ""
        persona.build_system_prompt = MagicMock(return_value="You are a helpful bot.")
        persona.update_user_context = MagicMock()

        captured_system_prompts = []

        async def mock_complete(messages, system=None, model=None):
            captured_system_prompts.append(system)
            resp = MagicMock()
            resp.content = "hello"
            resp.input_tokens = 10
            resp.output_tokens = 5
            resp.cost_usd = 0.0
            return resp

        llm = MagicMock()
        llm.complete = mock_complete

        adapter = MagicMock()
        adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

        pipeline = Pipeline(
            config=config,
            memory=memory,
            guard=guard,
            persona=persona,
            llm=llm,
            teachings=teach_store,
        )

        inbound = InboundMessage(
            id="msg1",
            user_id="user42",
            user_name="TestUser",
            channel_id="ch1",
            platform="discord",
            text="hello",
        )

        result = await pipeline.process(inbound, adapter)
        assert result.success
        assert len(captured_system_prompts) == 1
        system_prompt = captured_system_prompts[0]
        assert "User Teachings" not in system_prompt


# ── !teach command tests ──────────────────────────────────────────────────────

class TestTeachCommand:
    def _make_dispatcher(self, tmp_path):
        from antarisbot.core.commands import CommandDispatcher
        from antarisbot.core.teachings import TeachingStore

        bot = MagicMock()
        teach_store = TeachingStore(tmp_path / "teachings")
        bot.teachings = teach_store

        dispatcher = CommandDispatcher(bot=bot)
        return dispatcher, teach_store

    def _make_inbound(self, text, user_id="user1"):
        from antarisbot.channels.base import InboundMessage
        return InboundMessage(
            id="msg1",
            user_id=user_id,
            user_name="TestUser",
            channel_id="ch1",
            platform="discord",
            text=text,
        )

    @pytest.mark.asyncio
    async def test_teach_stores_teaching(self, tmp_path):
        dispatcher, store = self._make_dispatcher(tmp_path)
        result = await dispatcher.dispatch(self._make_inbound("!teach I prefer bullet points"))
        assert result.handled
        assert "Got it" in result.response or "stored" in result.response.lower()
        items = store.list("user1")
        assert len(items) == 1
        assert items[0]["text"] == "I prefer bullet points"

    @pytest.mark.asyncio
    async def test_teach_list_empty(self, tmp_path):
        dispatcher, store = self._make_dispatcher(tmp_path)
        result = await dispatcher.dispatch(self._make_inbound("!teach list"))
        assert result.handled
        assert "No teachings" in result.response

    @pytest.mark.asyncio
    async def test_teach_list_shows_numbered(self, tmp_path):
        dispatcher, store = self._make_dispatcher(tmp_path)
        store.add("user1", "teaching one")
        store.add("user1", "teaching two")
        result = await dispatcher.dispatch(self._make_inbound("!teach list"))
        assert result.handled
        assert "1." in result.response
        assert "2." in result.response
        assert "teaching one" in result.response
        assert "teaching two" in result.response

    @pytest.mark.asyncio
    async def test_teach_remove(self, tmp_path):
        dispatcher, store = self._make_dispatcher(tmp_path)
        store.add("user1", "to remove")
        store.add("user1", "to keep")
        result = await dispatcher.dispatch(self._make_inbound("!teach remove 1"))
        assert result.handled
        assert "removed" in result.response.lower() or "Removed" in result.response
        assert len(store.list("user1")) == 1
        assert store.list("user1")[0]["text"] == "to keep"

    @pytest.mark.asyncio
    async def test_teach_remove_invalid(self, tmp_path):
        dispatcher, store = self._make_dispatcher(tmp_path)
        result = await dispatcher.dispatch(self._make_inbound("!teach remove 99"))
        assert result.handled
        assert "No teaching" in result.response or "no teaching" in result.response.lower()

    @pytest.mark.asyncio
    async def test_teach_clear(self, tmp_path):
        dispatcher, store = self._make_dispatcher(tmp_path)
        store.add("user1", "a")
        store.add("user1", "b")
        result = await dispatcher.dispatch(self._make_inbound("!teach clear"))
        assert result.handled
        assert "Cleared" in result.response or "cleared" in result.response.lower()
        assert len(store.list("user1")) == 0

    @pytest.mark.asyncio
    async def test_teach_no_store_returns_error(self, tmp_path):
        from antarisbot.core.commands import CommandDispatcher
        bot = MagicMock()
        bot.teachings = None
        dispatcher = CommandDispatcher(bot=bot)
        result = await dispatcher.dispatch(self._make_inbound("!teach hello"))
        assert result.handled
        assert "not available" in result.response.lower() or "unavailable" in result.response.lower()

    @pytest.mark.asyncio
    async def test_help_includes_teach(self, tmp_path):
        dispatcher, _ = self._make_dispatcher(tmp_path)
        result = await dispatcher.dispatch(self._make_inbound("!help"))
        assert result.handled
        assert "!teach" in result.response
