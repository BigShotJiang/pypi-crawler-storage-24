"""Tests for HTML utility functions."""
from __future__ import annotations

import pytest

from antarisbot.tools.native.html_utils import html_to_markdown, html_to_text


class TestHtmlToMarkdown:
    """Test html_to_markdown function."""

    def test_headers(self):
        """Test header conversion."""
        html = '<h1>Title</h1><h2>Subtitle</h2><h3>Section</h3>'
        expected = '# Title\n## Subtitle\n### Section'
        result = html_to_markdown(html)
        assert result == expected

    def test_links(self):
        """Test link conversion."""
        html = '<a href="https://example.com">Example Link</a>'
        expected = '[Example Link](https://example.com)'
        result = html_to_markdown(html)
        assert result == expected

    def test_bold_and_italic(self):
        """Test bold and italic conversion."""
        html = '<strong>Bold</strong> and <em>italic</em> text'
        expected = '**Bold** and *italic* text'
        result = html_to_markdown(html)
        assert result == expected

    def test_alternative_bold_italic(self):
        """Test alternative bold/italic tags."""
        html = '<b>Bold</b> and <i>italic</i> text'
        expected = '**Bold** and *italic* text'
        result = html_to_markdown(html)
        assert result == expected

    def test_code_blocks(self):
        """Test code block conversion."""
        html = '<pre><code>print("hello")</code></pre>'
        expected = '```\nprint("hello")\n```'
        result = html_to_markdown(html)
        assert result == expected

    def test_inline_code(self):
        """Test inline code conversion."""
        html = 'Use <code>print()</code> function'
        expected = 'Use `print()` function'
        result = html_to_markdown(html)
        assert result == expected

    def test_lists(self):
        """Test list conversion."""
        html = '<ul><li>Item 1</li><li>Item 2</li></ul>'
        expected = '- Item 1\n- Item 2'
        result = html_to_markdown(html)
        assert result == expected

    def test_ordered_lists(self):
        """Test ordered list conversion."""
        html = '<ol><li>First</li><li>Second</li></ol>'
        expected = '- First\n- Second'
        result = html_to_markdown(html)
        assert result == expected

    def test_paragraphs(self):
        """Test paragraph conversion."""
        html = '<p>First paragraph</p><p>Second paragraph</p>'
        expected = 'First paragraph\n\nSecond paragraph'
        result = html_to_markdown(html)
        assert result == expected

    def test_line_breaks(self):
        """Test line break conversion."""
        html = 'Line 1<br>Line 2<br/>Line 3'
        expected = 'Line 1\nLine 2\nLine 3'
        result = html_to_markdown(html)
        assert result == expected

    def test_script_style_removal(self):
        """Test script and style tag removal."""
        html = '''
        <html>
        <head><style>body { color: red; }</style></head>
        <body>
        <script>alert('hello');</script>
        <p>Content</p>
        </body>
        </html>
        '''
        result = html_to_markdown(html)
        assert 'alert' not in result
        assert 'color: red' not in result
        assert 'Content' in result

    def test_html_entity_decoding(self):
        """Test HTML entity decoding."""
        html = 'AT&amp;T &lt;company&gt; &copy; 2024'
        expected = 'AT&T <company> © 2024'
        result = html_to_markdown(html)
        assert result == expected

    def test_complex_html_entities(self):
        """Test complex HTML entities."""
        html = 'Em&mdash;dash &ndash; en&ndash;dash &#8212; numeric &#x27; hex &hellip; ellipsis'
        expected = 'Em—dash – en–dash — numeric \' hex … ellipsis'
        result = html_to_markdown(html)
        assert result == expected

    def test_whitespace_normalization(self):
        """Test whitespace normalization."""
        html = '<p>Text   with     spaces</p>\n\n\n<p>Another paragraph</p>'
        result = html_to_markdown(html)
        # Should normalize multiple spaces and excessive newlines
        assert 'Text with spaces' in result
        assert result.count('\n\n') == 1  # Only one double newline between paragraphs


class TestHtmlToText:
    """Test html_to_text function."""

    def test_basic_text_extraction(self):
        """Test basic text extraction."""
        html = '<p>Hello <strong>world</strong>!</p>'
        expected = 'Hello world!'
        result = html_to_text(html)
        assert result == expected

    def test_div_paragraph_conversion(self):
        """Test div and paragraph to newline conversion."""
        html = '<div>First</div><p>Second</p><h1>Third</h1>'
        result = html_to_text(html)
        lines = result.split('\n')
        assert 'First' in lines
        assert 'Second' in lines
        assert 'Third' in lines

    def test_script_style_removal(self):
        """Test script and style removal in text mode."""
        html = '''
        <script>console.log('remove me');</script>
        <style>body { display: none; }</style>
        <p>Keep this text</p>
        '''
        result = html_to_text(html)
        assert 'console.log' not in result
        assert 'display: none' not in result
        assert 'Keep this text' in result

    def test_html_entity_decoding_text(self):
        """Test HTML entity decoding in text mode."""
        html = '<p>&amp; &lt; &gt; &quot; &apos;</p>'
        expected = '& < > " \''
        result = html_to_text(html)
        assert result == expected

    def test_numeric_entities(self):
        """Test numeric HTML entities."""
        html = '<p>&#65; &#x41; &#8212;</p>'
        expected = 'A A —'
        result = html_to_text(html)
        assert result == expected

    def test_whitespace_normalization_text(self):
        """Test whitespace normalization in text mode."""
        html = '''
        <div>Line    with   spaces</div>
        
        
        <p>Another    line</p>
        '''
        result = html_to_text(html)
        assert 'Line with spaces' in result
        assert 'Another line' in result
        # Should not have excessive blank lines
        assert '\n\n\n' not in result


class TestEdgeCases:
    """Test edge cases for both functions."""

    def test_empty_string(self):
        """Test empty string handling."""
        assert html_to_markdown('') == ''
        assert html_to_text('') == ''

    def test_plain_text(self):
        """Test plain text (no HTML tags)."""
        text = 'Just plain text with &amp; entities'
        expected = 'Just plain text with & entities'
        assert html_to_markdown(text) == expected
        assert html_to_text(text) == expected

    def test_malformed_html(self):
        """Test malformed HTML handling."""
        html = '<p>Unclosed paragraph<div>Mixed tags</p></div>'
        # Should still extract text content
        result_md = html_to_markdown(html)
        result_text = html_to_text(html)
        assert 'Unclosed paragraph' in result_md
        assert 'Mixed tags' in result_md
        assert 'Unclosed paragraph' in result_text
        assert 'Mixed tags' in result_text

    def test_nested_tags(self):
        """Test deeply nested tags."""
        html = '<div><p><strong><em>Deeply nested</em></strong> text</p></div>'
        result_md = html_to_markdown(html)
        result_text = html_to_text(html)
        assert '***Deeply nested*** text' in result_md  # Should have both bold and italic
        assert 'Deeply nested text' in result_text

    def test_attributes_ignored(self):
        """Test that tag attributes are properly ignored."""
        html = '<a href="https://example.com" class="link" id="test">Link</a>'
        result_md = html_to_markdown(html)
        result_text = html_to_text(html)
        assert '[Link](https://example.com)' == result_md
        assert 'Link' == result_text
        assert 'class' not in result_md
        assert 'id' not in result_md

    def test_case_insensitive_tags(self):
        """Test case-insensitive tag handling."""
        html = '<P>Paragraph</P><BR><STRONG>Bold</STRONG>'
        result_md = html_to_markdown(html)
        result_text = html_to_text(html)
        assert 'Paragraph' in result_md
        assert '**Bold**' in result_md
        assert 'Paragraph' in result_text
        assert 'Bold' in result_text