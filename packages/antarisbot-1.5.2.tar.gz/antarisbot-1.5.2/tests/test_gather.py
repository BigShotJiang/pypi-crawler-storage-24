"""Tests for the gather command."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from antarisbot.core.gather import summarize_channel, smart_summarize_channel, gather_and_ingest, VALID_HOURS
from antarisbot.llm.base import LLMResponse, Message


class TestSummarizeChannel:
    def test_empty_messages_returns_empty(self):
        result = summarize_channel({"channel_name": "test", "messages": [], "count": 0})
        assert result == ""

    def test_basic_summary(self):
        data = {
            "channel_name": "general",
            "channel_id": "123",
            "messages": [
                {"author": "Alice", "content": "Hello everyone", "timestamp": "2026-03-10T00:00:00"},
                {"author": "Bob", "content": "Hey Alice!", "timestamp": "2026-03-10T00:01:00"},
            ],
            "count": 2,
        }
        result = summarize_channel(data)
        assert "#general" in result
        assert "Alice" in result
        assert "Bob" in result
        assert "Hello everyone" in result

    def test_caps_at_50_messages(self):
        messages = [{"author": f"user{i}", "content": f"msg {i}", "timestamp": ""} for i in range(100)]
        data = {"channel_name": "busy", "messages": messages, "count": 100}
        result = summarize_channel(data)
        lines = result.strip().split("\n")
        assert len(lines) <= 51  # header + 50 messages


class TestValidHours:
    def test_valid_hours(self):
        assert 3 in VALID_HOURS
        assert 12 in VALID_HOURS
        assert 48 in VALID_HOURS
        assert 7 not in VALID_HOURS


def _make_channel_data(name="general", messages=None):
    if messages is None:
        messages = [
            {"author": "Alice", "content": "We merged the PR.", "timestamp": "2026-03-10T00:00:00"},
            {"author": "Bob", "content": "Looks good to me.", "timestamp": "2026-03-10T00:01:00"},
        ]
    return {
        "channel_name": name,
        "channel_id": "123",
        "messages": messages,
        "count": len(messages),
    }


def _make_llm_response(text: str) -> LLMResponse:
    return LLMResponse(
        content=text,
        model="test-model",
        input_tokens=10,
        output_tokens=20,
        cost_usd=0.0,
    )


class TestSmartSummarizeChannel:
    @pytest.mark.asyncio
    async def test_returns_llm_summary(self):
        """smart_summarize_channel returns the LLM response content."""
        llm = MagicMock()
        llm.complete = AsyncMock(return_value=_make_llm_response("Alice merged the PR; Bob approved it."))

        data = _make_channel_data()
        result = await smart_summarize_channel(data, llm)

        assert result == "Alice merged the PR; Bob approved it."
        llm.complete.assert_called_once()
        call_kwargs = llm.complete.call_args
        # Confirm channel name appears in the user prompt
        user_msg = call_kwargs.kwargs["messages"][0].content
        assert "#general" in user_msg

    @pytest.mark.asyncio
    async def test_falls_back_on_llm_failure(self):
        """smart_summarize_channel falls back to summarize_channel when LLM raises."""
        llm = MagicMock()
        llm.complete = AsyncMock(side_effect=RuntimeError("LLM unavailable"))

        data = _make_channel_data()
        result = await smart_summarize_channel(data, llm)

        # Must fall back to the raw concat format from summarize_channel
        assert "#general" in result
        assert "Alice" in result
        assert "We merged the PR." in result

    @pytest.mark.asyncio
    async def test_empty_channel_returns_empty_without_llm_call(self):
        """smart_summarize_channel skips the LLM for channels with no messages."""
        llm = MagicMock()
        llm.complete = AsyncMock()

        data = _make_channel_data(messages=[])
        result = await smart_summarize_channel(data, llm)

        assert result == ""
        llm.complete.assert_not_called()

    @pytest.mark.asyncio
    async def test_llm_called_with_correct_system_prompt(self):
        """Verify system prompt instructs 2-4 sentences and WHO said WHAT."""
        llm = MagicMock()
        llm.complete = AsyncMock(return_value=_make_llm_response("Summary."))

        await smart_summarize_channel(_make_channel_data(), llm)

        system_arg = llm.complete.call_args.kwargs["system"]
        assert "2-4" in system_arg
        assert "WHO" in system_arg

    @pytest.mark.asyncio
    async def test_llm_response_is_stripped(self):
        """Trailing/leading whitespace is stripped from LLM response."""
        llm = MagicMock()
        llm.complete = AsyncMock(return_value=_make_llm_response("  Summary with spaces.  \n"))

        result = await smart_summarize_channel(_make_channel_data(), llm)
        assert result == "Summary with spaces."


class TestGatherAndIngestWithLLM:
    @pytest.mark.asyncio
    async def test_uses_smart_summarize_when_llm_provided(self):
        """gather_and_ingest calls smart_summarize_channel when llm is not None."""
        channel_data = _make_channel_data()

        mock_client = MagicMock()
        mock_memory = MagicMock()
        mock_memory.ingest = AsyncMock()
        mock_llm = MagicMock()
        mock_llm.complete = AsyncMock(return_value=_make_llm_response("Smart briefing for general."))

        with patch(
            "antarisbot.core.gather.gather_channel_history",
            new=AsyncMock(return_value=[channel_data]),
        ):
            result = await gather_and_ingest(
                client=mock_client,
                memory=mock_memory,
                llm=mock_llm,
                channel_ids=["123"],
                hours=12,
            )

        assert result["channels_synced"] == 1
        assert result["total_messages"] == 2
        assert len(result["channel_summaries"]) == 1
        assert result["channel_summaries"][0]["summary"] == "Smart briefing for general."
        mock_llm.complete.assert_called_once()

    @pytest.mark.asyncio
    async def test_falls_back_to_raw_when_llm_is_none(self):
        """gather_and_ingest uses summarize_channel when llm is None."""
        channel_data = _make_channel_data()

        mock_client = MagicMock()
        mock_memory = MagicMock()
        mock_memory.ingest = AsyncMock()

        with patch(
            "antarisbot.core.gather.gather_channel_history",
            new=AsyncMock(return_value=[channel_data]),
        ):
            result = await gather_and_ingest(
                client=mock_client,
                memory=mock_memory,
                llm=None,
                channel_ids=["123"],
                hours=12,
            )

        assert result["channels_synced"] == 1
        assert len(result["channel_summaries"]) == 1
        # Raw summary contains the channel header format from summarize_channel
        assert "#general" in result["channel_summaries"][0]["summary"]

    @pytest.mark.asyncio
    async def test_channel_summaries_in_result(self):
        """Result dict includes channel_summaries key."""
        mock_client = MagicMock()
        mock_memory = MagicMock()
        mock_memory.ingest = AsyncMock()

        with patch(
            "antarisbot.core.gather.gather_channel_history",
            new=AsyncMock(return_value=[]),
        ):
            result = await gather_and_ingest(
                client=mock_client,
                memory=mock_memory,
                llm=None,
                channel_ids=[],
                hours=12,
            )

        assert "channel_summaries" in result
        assert result["channel_summaries"] == []
