"""Tests for ProactiveMemory — proactive memory surfacing."""
import json
import pytest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

from antarisbot.core.proactive import ProactiveMemory


# ── Unit tests: scan_and_note ─────────────────────────────────────────────────

class TestScanAndNote:
    def test_detects_meeting(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "I have a meeting tomorrow at 3pm")
        assert len(noted) == 1
        assert "event" in noted[0]

    def test_detects_appointment(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "I've got an appointment tonight")
        assert len(noted) == 1
        assert "event" in noted[0]

    def test_detects_task(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "I need to finish the report by Friday")
        assert len(noted) == 1
        assert "task" in noted[0]

    def test_detects_remind_me(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "Remind me to call mom tomorrow")
        assert len(noted) == 1
        assert "task" in noted[0]

    def test_detects_preference(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "I love sushi")
        assert len(noted) == 1
        assert "preference" in noted[0]

    def test_detects_dislike(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "I dislike mornings")
        assert len(noted) == 1
        assert "preference" in noted[0]

    def test_detects_plan(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        # Use a message with no temporal words so the plan pattern fires
        noted = pm.scan_and_note("user1", "I'm going to start a new project soon")
        assert len(noted) == 1
        assert "plan" in noted[0]

    def test_detects_temporal(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "Next week I'll be in Seattle")
        assert len(noted) == 1
        # Any category is fine here (temporal or plan both match)
        assert len(noted[0]) > 0

    def test_ignores_non_notable(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "What is the weather like?")
        assert noted == []

    def test_ignores_casual_chat(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        noted = pm.scan_and_note("user1", "lol that's funny")
        assert noted == []

    def test_one_note_per_message(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        # This could match both 'task' and 'temporal' patterns
        noted = pm.scan_and_note("user1", "I need to finish this tonight")
        assert len(noted) == 1  # only one note per message

    def test_note_stored_to_disk(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        pm.scan_and_note("user1", "I have a deadline tomorrow")
        notes_file = tmp_path / "user1.json"
        assert notes_file.exists()
        data = json.loads(notes_file.read_text())
        assert len(data) == 1
        assert "deadline" in data[0]["text"].lower() or "tomorrow" in data[0]["text"].lower()

    def test_note_text_truncated_at_200(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        long_text = "I need to " + "x" * 300
        pm.scan_and_note("user1", long_text)
        notes_file = tmp_path / "user1.json"
        data = json.loads(notes_file.read_text())
        assert len(data[0]["text"]) <= 200

    def test_note_has_required_fields(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        pm.scan_and_note("user1", "I have a meeting tomorrow")
        notes_file = tmp_path / "user1.json"
        data = json.loads(notes_file.read_text())
        note = data[0]
        assert "text" in note
        assert "category" in note
        assert "created" in note
        assert "surface_after" in note
        assert "surfaced" in note
        assert note["surfaced"] is False

    def test_per_user_isolation(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        pm.scan_and_note("user1", "I have a meeting tomorrow")
        pm.scan_and_note("user2", "I need to call my doctor")
        u1_file = tmp_path / "user1.json"
        u2_file = tmp_path / "user2.json"
        assert u1_file.exists()
        assert u2_file.exists()
        u1_data = json.loads(u1_file.read_text())
        u2_data = json.loads(u2_file.read_text())
        assert len(u1_data) == 1
        assert len(u2_data) == 1


# ── Unit tests: get_surfaces ──────────────────────────────────────────────────

class TestGetSurfaces:
    def _write_note(self, store_dir: Path, user_id: str, text: str,
                    surface_after: str = "", surfaced: bool = False):
        """Helper to directly write a note to disk."""
        path = store_dir / f"{user_id}.json"
        notes = json.loads(path.read_text()) if path.exists() else []
        notes.append({
            "text": text,
            "category": "event",
            "created": datetime.now(timezone.utc).isoformat(),
            "surface_after": surface_after,
            "surfaced": surfaced,
        })
        path.write_text(json.dumps(notes))

    def test_surfaces_on_greeting_hi(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "meeting at 3pm")
        result = pm.get_surfaces("user1", "hi")
        assert "meeting at 3pm" in result

    def test_surfaces_on_good_morning(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "deadline today")
        result = pm.get_surfaces("user1", "good morning")
        assert "deadline today" in result

    def test_surfaces_on_hey(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "call doctor")
        result = pm.get_surfaces("user1", "hey")
        assert "call doctor" in result

    def test_surfaces_on_back_again(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "gym at 6")
        result = pm.get_surfaces("user1", "i'm back")
        assert "gym at 6" in result

    def test_no_surface_on_non_greeting(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "meeting tomorrow")
        result = pm.get_surfaces("user1", "what is the weather?")
        assert result == []

    def test_no_surface_on_random_message(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "some pending note")
        result = pm.get_surfaces("user1", "what is the capital of France?")
        assert result == []

    def test_surfaces_when_text_empty(self, tmp_path):
        """Empty text should surface all pending notes (reconnect scenario)."""
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "call at noon")
        result = pm.get_surfaces("user1", "")
        assert "call at noon" in result

    def test_respects_surface_after_in_future(self, tmp_path):
        """Notes with future surface_after should not be surfaced yet."""
        pm = ProactiveMemory(tmp_path)
        future = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
        self._write_note(tmp_path, "user1", "future note", surface_after=future)
        result = pm.get_surfaces("user1", "good morning")
        assert result == []

    def test_respects_surface_after_in_past(self, tmp_path):
        """Notes with past surface_after should be surfaced."""
        pm = ProactiveMemory(tmp_path)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        self._write_note(tmp_path, "user1", "past note", surface_after=past)
        result = pm.get_surfaces("user1", "good morning")
        assert "past note" in result

    def test_marks_notes_as_surfaced(self, tmp_path):
        """After surfacing, notes should be marked surfaced."""
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "note to surface")
        pm.get_surfaces("user1", "hi")
        notes_file = tmp_path / "user1.json"
        data = json.loads(notes_file.read_text())
        assert data[0]["surfaced"] is True

    def test_no_double_surface(self, tmp_path):
        """Surfaced notes should not be returned again."""
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "one-time note")
        first = pm.get_surfaces("user1", "hello")
        second = pm.get_surfaces("user1", "hello")
        assert len(first) == 1
        assert second == []

    def test_skips_already_surfaced(self, tmp_path):
        """Pre-marked surfaced notes are not returned."""
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "already done", surfaced=True)
        result = pm.get_surfaces("user1", "hi")
        assert result == []

    def test_multiple_notes_all_surfaced(self, tmp_path):
        """Multiple pending notes are all returned on greeting."""
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "meeting at 2")
        self._write_note(tmp_path, "user1", "call dentist")
        result = pm.get_surfaces("user1", "morning")
        assert len(result) == 2
        assert "meeting at 2" in result
        assert "call dentist" in result

    def test_invalid_surface_after_is_ignored(self, tmp_path):
        """Unparseable surface_after should not block surfacing."""
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "note with bad date", surface_after="not-a-date")
        result = pm.get_surfaces("user1", "hi")
        assert "note with bad date" in result


# ── Unit tests: get_context ───────────────────────────────────────────────────

class TestGetContext:
    def _write_note(self, store_dir: Path, user_id: str, text: str):
        path = store_dir / f"{user_id}.json"
        notes = json.loads(path.read_text()) if path.exists() else []
        notes.append({
            "text": text,
            "category": "event",
            "created": datetime.now(timezone.utc).isoformat(),
            "surface_after": "",
            "surfaced": False,
        })
        path.write_text(json.dumps(notes))

    def test_empty_when_no_notes(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        ctx = pm.get_context("user1", "hi")
        assert ctx == ""

    def test_empty_on_non_greeting(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "meeting at 3")
        ctx = pm.get_context("user1", "what time is it?")
        assert ctx == ""

    def test_contains_header(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "meeting at 3")
        ctx = pm.get_context("user1", "good morning")
        assert "## Proactive Reminders" in ctx

    def test_contains_note_text(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "call dentist at noon")
        ctx = pm.get_context("user1", "hey")
        assert "call dentist at noon" in ctx

    def test_note_formatted_as_bullet(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "gym tonight")
        ctx = pm.get_context("user1", "hello")
        assert "- gym tonight" in ctx

    def test_contains_instruction(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "something important")
        ctx = pm.get_context("user1", "morning")
        assert "Mention these naturally" in ctx

    def test_multiple_notes_all_listed(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        self._write_note(tmp_path, "user1", "note one")
        self._write_note(tmp_path, "user1", "note two")
        ctx = pm.get_context("user1", "hi")
        assert "- note one" in ctx
        assert "- note two" in ctx


# ── Unit tests: _extract_temporal ────────────────────────────────────────────

class TestExtractTemporal:
    def test_tomorrow_returns_next_day(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._extract_temporal("i have a meeting tomorrow at 3")
        assert result != ""
        target = datetime.fromisoformat(result)
        now = datetime.now(timezone.utc)
        assert target.date() == (now + timedelta(days=1)).date()

    def test_tomorrow_sets_morning_hour(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._extract_temporal("i need to do this tomorrow")
        target = datetime.fromisoformat(result)
        assert target.hour == 7

    def test_tonight_returns_today(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._extract_temporal("meeting tonight at 8")
        assert result != ""
        target = datetime.fromisoformat(result)
        now = datetime.now(timezone.utc)
        assert target.date() == now.date()

    def test_tonight_sets_evening_hour(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._extract_temporal("dinner tonight")
        target = datetime.fromisoformat(result)
        assert target.hour == 18

    def test_this_evening_same_as_tonight(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._extract_temporal("going out this evening")
        assert result != ""
        target = datetime.fromisoformat(result)
        assert target.hour == 18

    def test_next_week_returns_one_week_out(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._extract_temporal("conference next week")
        assert result != ""
        target = datetime.fromisoformat(result)
        now = datetime.now(timezone.utc)
        diff = (target.date() - now.date()).days
        assert 6 <= diff <= 8

    def test_next_week_sets_morning_hour(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._extract_temporal("trip next week")
        target = datetime.fromisoformat(result)
        assert target.hour == 9

    def test_no_temporal_returns_empty(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._extract_temporal("i need to call my doctor")
        assert result == ""


# ── Unit tests: persistence roundtrip ────────────────────────────────────────

class TestPersistence:
    def test_roundtrip(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        pm.scan_and_note("user1", "I have a meeting tomorrow at 3")
        # Create a new instance pointing to the same dir
        pm2 = ProactiveMemory(tmp_path)
        notes_file = tmp_path / "user1.json"
        assert notes_file.exists()
        data = json.loads(notes_file.read_text())
        assert len(data) == 1

    def test_load_returns_empty_for_missing_file(self, tmp_path):
        pm = ProactiveMemory(tmp_path)
        result = pm._load("nonexistent_user")
        assert result == []

    def test_load_returns_empty_on_corrupted_json(self, tmp_path):
        bad_file = tmp_path / "user1.json"
        bad_file.write_text("not valid json {{{{")
        pm = ProactiveMemory(tmp_path)
        result = pm._load("user1")
        assert result == []

    def test_store_dir_created(self, tmp_path):
        new_dir = tmp_path / "nested" / "proactive"
        pm = ProactiveMemory(new_dir)
        assert new_dir.exists()


# ── Unit tests: 7-day cleanup ─────────────────────────────────────────────────

class TestCleanup:
    def test_old_surfaced_notes_cleaned_on_load(self, tmp_path):
        """Surfaced notes older than 7 days should be dropped on load."""
        pm = ProactiveMemory(tmp_path)
        old_created = (datetime.now(timezone.utc) - timedelta(days=8)).isoformat()
        path = tmp_path / "user1.json"
        path.write_text(json.dumps([{
            "text": "old note",
            "category": "event",
            "created": old_created,
            "surface_after": "",
            "surfaced": True,
        }]))
        notes = pm._load("user1")
        assert notes == []

    def test_recent_surfaced_notes_kept(self, tmp_path):
        """Surfaced notes within 7 days should be kept."""
        pm = ProactiveMemory(tmp_path)
        recent_created = (datetime.now(timezone.utc) - timedelta(days=3)).isoformat()
        path = tmp_path / "user1.json"
        path.write_text(json.dumps([{
            "text": "recent note",
            "category": "event",
            "created": recent_created,
            "surface_after": "",
            "surfaced": True,
        }]))
        notes = pm._load("user1")
        assert len(notes) == 1

    def test_unsurfaced_notes_always_kept(self, tmp_path):
        """Unsurfaced notes are never dropped regardless of age."""
        pm = ProactiveMemory(tmp_path)
        old_created = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
        path = tmp_path / "user1.json"
        path.write_text(json.dumps([{
            "text": "old unsurfaced",
            "category": "event",
            "created": old_created,
            "surface_after": "",
            "surfaced": False,
        }]))
        notes = pm._load("user1")
        assert len(notes) == 1


# ── Pipeline integration tests ────────────────────────────────────────────────

class TestProactiveInPipeline:
    def _make_pipeline(self, proactive=None):
        from antarisbot.core.pipeline import Pipeline

        config = MagicMock()
        config.model = "test-model"
        config.rate_limit_messages = 20
        config.rate_limit_window_seconds = 60

        memory = MagicMock()
        memory.recall = AsyncMock(return_value=[])
        memory.ingest = AsyncMock()

        guard = MagicMock()
        guard.check_input = AsyncMock(return_value=(True, ""))
        guard.check_output = AsyncMock(return_value=(True, "hello"))

        persona = MagicMock()
        persona.config_dir = ""
        persona.build_system_prompt = MagicMock(return_value="You are a helpful bot.")
        persona.update_user_context = MagicMock()

        llm = MagicMock()

        adapter = MagicMock()
        adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

        return Pipeline(
            config=config,
            memory=memory,
            guard=guard,
            persona=persona,
            llm=llm,
            proactive=proactive,
        ), llm, adapter

    def _make_inbound(self, text, user_id="user1"):
        from antarisbot.channels.base import InboundMessage
        return InboundMessage(
            id="msg1",
            user_id=user_id,
            user_name="TestUser",
            channel_id="ch1",
            platform="discord",
            text=text,
        )

    def _mock_llm_response(self, llm, content="ok"):
        from antarisbot.llm.base import LLMResponse
        llm.complete = AsyncMock(return_value=LLMResponse(
            content=content,
            model="test-model",
            input_tokens=10,
            output_tokens=5,
            cost_usd=0.0,
        ))

    @pytest.mark.asyncio
    async def test_proactive_context_injected_on_greeting(self, tmp_path):
        """Proactive reminders should appear in the system prompt on a greeting."""
        pm = ProactiveMemory(tmp_path)
        # Manually write a note that is ready to surface (no surface_after)
        path = tmp_path / "user1.json"
        path.write_text(json.dumps([{
            "text": "meeting at 3pm",
            "category": "event",
            "created": datetime.now(timezone.utc).isoformat(),
            "surface_after": "",
            "surfaced": False,
        }]))

        pipeline, llm, adapter = self._make_pipeline(proactive=pm)
        captured = []

        from antarisbot.llm.base import LLMResponse
        async def mock_complete(messages, system=None, model=None):
            captured.append(system)
            resp = MagicMock()
            resp.content = "good morning!"
            resp.input_tokens = 10
            resp.output_tokens = 5
            resp.cost_usd = 0.0
            return resp

        llm.complete = mock_complete

        inbound = self._make_inbound("good morning", "user1")
        result = await pipeline.process(inbound, adapter)
        assert result.success
        assert len(captured) == 1
        assert "Proactive Reminders" in captured[0]
        assert "meeting at 3pm" in captured[0]

    @pytest.mark.asyncio
    async def test_proactive_not_injected_on_non_greeting(self, tmp_path):
        """Proactive reminders should not appear for non-greeting messages."""
        pm = ProactiveMemory(tmp_path)
        path = tmp_path / "user1.json"
        path.write_text(json.dumps([{
            "text": "meeting at 3pm",
            "category": "event",
            "created": datetime.now(timezone.utc).isoformat(),
            "surface_after": "",
            "surfaced": False,
        }]))

        pipeline, llm, adapter = self._make_pipeline(proactive=pm)
        captured = []

        async def mock_complete(messages, system=None, model=None):
            captured.append(system)
            resp = MagicMock()
            resp.content = "sure"
            resp.input_tokens = 10
            resp.output_tokens = 5
            resp.cost_usd = 0.0
            return resp

        llm.complete = mock_complete

        inbound = self._make_inbound("what time is it?", "user1")
        result = await pipeline.process(inbound, adapter)
        assert result.success
        assert len(captured) == 1
        assert "Proactive Reminders" not in captured[0]

    @pytest.mark.asyncio
    async def test_proactive_scan_called_on_notable_message(self, tmp_path):
        """scan_and_note should be called and store a note for notable messages."""
        pm = ProactiveMemory(tmp_path)
        pipeline, llm, adapter = self._make_pipeline(proactive=pm)
        self._mock_llm_response(llm)

        inbound = self._make_inbound("I have a meeting tomorrow at noon", "user1")
        result = await pipeline.process(inbound, adapter)
        assert result.success

        notes_file = tmp_path / "user1.json"
        assert notes_file.exists()
        data = json.loads(notes_file.read_text())
        assert len(data) >= 1

    @pytest.mark.asyncio
    async def test_pipeline_works_without_proactive(self, tmp_path):
        """Pipeline should work fine with proactive=None (default)."""
        pipeline, llm, adapter = self._make_pipeline(proactive=None)
        self._mock_llm_response(llm)

        inbound = self._make_inbound("hello")
        result = await pipeline.process(inbound, adapter)
        assert result.success
