"""Tests for the identity stack — AGENTS.md, MEMORY.md, HEARTBEAT.md, and context cadence."""

import json
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from antarisbot.persona.context_cadence import ContextCadence


# ── Helpers ─────────────────────────────────────────────────────────────────

ANTARISBOT_DIR = Path.home() / ".antarisbot"


# ── File existence tests ─────────────────────────────────────────────────────

def test_agents_md_exists():
    path = ANTARISBOT_DIR / "AGENTS.md"
    assert path.exists(), f"AGENTS.md not found at {path}"


def test_agents_md_has_content():
    path = ANTARISBOT_DIR / "AGENTS.md"
    content = path.read_text().strip()
    assert len(content) > 0, "AGENTS.md is empty"


def test_agents_md_contains_identity_section():
    path = ANTARISBOT_DIR / "AGENTS.md"
    content = path.read_text()
    assert "NoFace" in content, "AGENTS.md must mention NoFace"
    assert "Antaris" in content, "AGENTS.md must mention Antaris"


def test_memory_md_exists():
    path = ANTARISBOT_DIR / "MEMORY.md"
    assert path.exists(), f"MEMORY.md not found at {path}"


def test_memory_md_has_content():
    path = ANTARISBOT_DIR / "MEMORY.md"
    content = path.read_text().strip()
    assert len(content) > 0, "MEMORY.md is empty"


def test_memory_md_contains_team_section():
    path = ANTARISBOT_DIR / "MEMORY.md"
    content = path.read_text()
    assert "Team" in content, "MEMORY.md must have a Team section"
    assert "Antaris" in content, "MEMORY.md must mention Antaris"


def test_heartbeat_md_exists():
    path = ANTARISBOT_DIR / "HEARTBEAT.md"
    assert path.exists(), f"HEARTBEAT.md not found at {path}"


def test_heartbeat_md_has_content():
    path = ANTARISBOT_DIR / "HEARTBEAT.md"
    content = path.read_text().strip()
    assert len(content) > 0, "HEARTBEAT.md is empty"


# ── context.json tests ───────────────────────────────────────────────────────

def test_context_json_exists():
    path = ANTARISBOT_DIR / "context.json"
    assert path.exists(), f"context.json not found at {path}"


def test_context_json_includes_agents_md_every():
    path = ANTARISBOT_DIR / "context.json"
    data = json.loads(path.read_text())
    assert "AGENTS.md" in data, "context.json must include AGENTS.md"
    assert data["AGENTS.md"] == "every", f"AGENTS.md cadence must be 'every', got: {data['AGENTS.md']}"


def test_context_json_includes_memory_md_startup():
    path = ANTARISBOT_DIR / "context.json"
    data = json.loads(path.read_text())
    assert "MEMORY.md" in data, "context.json must include MEMORY.md"
    assert data["MEMORY.md"] == "startup", f"MEMORY.md cadence must be 'startup', got: {data['MEMORY.md']}"


def test_context_json_preserves_soul_md():
    path = ANTARISBOT_DIR / "context.json"
    data = json.loads(path.read_text())
    assert "SOUL.md" in data, "context.json must still include SOUL.md"
    assert data["SOUL.md"] == "every", "SOUL.md cadence must remain 'every'"


def test_context_json_preserves_tools_md():
    path = ANTARISBOT_DIR / "context.json"
    data = json.loads(path.read_text())
    assert "TOOLS.md" in data, "context.json must still include TOOLS.md"
    assert data["TOOLS.md"] == "startup", "TOOLS.md cadence must remain 'startup'"


# ── ContextCadence integration tests ────────────────────────────────────────

def _make_cadence_dir(files: dict[str, str], context_cfg: dict[str, str]) -> Path:
    """Create a temp dir with the given .md files and context.json, return the path."""
    tmp = Path(tempfile.mkdtemp())
    for name, content in files.items():
        (tmp / name).write_text(content)
    (tmp / "context.json").write_text(json.dumps(context_cfg))
    return tmp


def test_cadence_loads_agents_md_on_every_turn():
    """AGENTS.md with cadence 'every' must appear on every call to get_files_for_turn()."""
    config_dir = _make_cadence_dir(
        files={
            "SOUL.md": "# Soul\nYou are NoFace.",
            "AGENTS.md": "# Agents\nNoFace rules.",
        },
        context_cfg={
            "SOUL.md": "every",
            "AGENTS.md": "every",
        },
    )
    cadence = ContextCadence(config_dir)

    # Turn 1
    turn1 = dict(cadence.get_files_for_turn())
    assert "AGENTS.md" in turn1, "AGENTS.md must appear on turn 1"

    # Turn 2 — every cadence must repeat
    turn2 = dict(cadence.get_files_for_turn())
    assert "AGENTS.md" in turn2, "AGENTS.md must appear on turn 2 (cadence=every)"


def test_cadence_loads_memory_md_on_startup_only():
    """MEMORY.md with cadence 'startup' must appear on first turn only."""
    config_dir = _make_cadence_dir(
        files={
            "SOUL.md": "# Soul\nYou are NoFace.",
            "MEMORY.md": "# Memory\nLong-term memory.",
        },
        context_cfg={
            "SOUL.md": "every",
            "MEMORY.md": "startup",
        },
    )
    cadence = ContextCadence(config_dir)

    # Turn 1 — startup fires
    turn1 = dict(cadence.get_files_for_turn())
    assert "MEMORY.md" in turn1, "MEMORY.md must appear on startup turn"

    # Turn 2 — startup must NOT repeat
    turn2 = dict(cadence.get_files_for_turn())
    assert "MEMORY.md" not in turn2, "MEMORY.md must NOT appear after startup"


def test_cadence_manual_files_never_auto_inject():
    """FILES with cadence 'manual' must never appear in get_files_for_turn()."""
    config_dir = _make_cadence_dir(
        files={
            "SOUL.md": "# Soul",
            "USER.md": "# User\nSome user data.",
        },
        context_cfg={
            "SOUL.md": "every",
            "USER.md": "manual",
        },
    )
    cadence = ContextCadence(config_dir)

    for _ in range(3):
        files = dict(cadence.get_files_for_turn())
        assert "USER.md" not in files, "USER.md (manual) must never auto-inject"


def test_cadence_agents_and_memory_together():
    """Combined test: AGENTS.md every + MEMORY.md startup."""
    config_dir = _make_cadence_dir(
        files={
            "SOUL.md": "# Soul\nYou are NoFace.",
            "AGENTS.md": "# Agents\nRules here.",
            "MEMORY.md": "# Memory\nLong-term context.",
        },
        context_cfg={
            "SOUL.md": "every",
            "AGENTS.md": "every",
            "MEMORY.md": "startup",
        },
    )
    cadence = ContextCadence(config_dir)

    # Turn 1: all three should appear
    turn1 = dict(cadence.get_files_for_turn())
    assert "SOUL.md" in turn1
    assert "AGENTS.md" in turn1
    assert "MEMORY.md" in turn1

    # Turn 2: MEMORY.md must drop off
    turn2 = dict(cadence.get_files_for_turn())
    assert "SOUL.md" in turn2
    assert "AGENTS.md" in turn2
    assert "MEMORY.md" not in turn2

    # Turn 3: same as turn 2
    turn3 = dict(cadence.get_files_for_turn())
    assert "AGENTS.md" in turn3
    assert "MEMORY.md" not in turn3


# ── Bot._message_count / compaction tracking tests ──────────────────────────

def test_bot_has_message_count_attribute():
    """Bot must expose _message_count initialised to 0."""
    from antarisbot.core.bot import Bot
    with MagicMock() as mock_config:
        # Patch Config.load and _init_components to avoid real filesystem ops
        import unittest.mock as mock
        with mock.patch("antarisbot.core.bot.Config.load") as mock_load, \
             mock.patch.object(Bot, "_init_components"):
            mock_load.return_value = MagicMock(
                config_path="/tmp/fake/config.json",
                validate=MagicMock(return_value=[]),
                auto_update=False,
                notify_updates=False,
            )
            bot = Bot.__new__(Bot)
            bot._message_count = 0
            bot._compaction_notified = False
            assert bot._message_count == 0
            assert bot._compaction_notified is False


def test_bot_message_count_increments():
    """_message_count must increment on each pipeline result."""
    # We test this by directly inspecting the handler logic via
    # inspecting the bot source — simpler than wiring up the full stack.
    import inspect
    from antarisbot.core.bot import Bot
    source = inspect.getsource(Bot._make_handler)
    assert "_message_count" in source, "_make_handler must reference _message_count"
    assert "_compaction_notified" in source, "_make_handler must reference _compaction_notified"


def test_bot_compaction_log_at_100_messages():
    """Compaction ping must trigger when threshold is reached."""
    import inspect
    from antarisbot.core.bot import Bot
    source = inspect.getsource(Bot._make_handler)
    assert "compaction_threshold" in source or "_threshold" in source, \
        "_make_handler must check configurable compaction threshold"
    assert "compaction" in source.lower(), \
        "_make_handler must trigger compaction-related logic"
