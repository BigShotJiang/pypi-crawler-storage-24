"""Tests for MoodDetector — adaptive tone matching."""
import pytest
from antarisbot.core.mood import MoodDetector, MoodSignal


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _feed(detector: MoodDetector, user_id: str, messages: list[str]) -> None:
    for msg in messages:
        detector.observe(user_id, msg)


# ---------------------------------------------------------------------------
# MoodSignal analysis — _analyze()
# ---------------------------------------------------------------------------

class TestAnalyze:
    def test_caps_detected_when_high_ratio(self):
        d = MoodDetector()
        sig = d._analyze("THIS IS BROKEN AGAIN")
        assert sig.has_caps is True

    def test_caps_not_detected_when_low_ratio(self):
        d = MoodDetector()
        sig = d._analyze("this is fine")
        assert sig.has_caps is False

    def test_caps_not_detected_on_very_short_text(self):
        # alpha_chars <= 5 should not trigger caps flag
        d = MoodDetector()
        sig = d._analyze("OK!")
        assert sig.has_caps is False

    def test_punctuation_double_exclamation(self):
        d = MoodDetector()
        sig = d._analyze("It failed again!!")
        assert sig.has_punctuation is True

    def test_punctuation_double_question(self):
        d = MoodDetector()
        sig = d._analyze("Why is this broken??")
        assert sig.has_punctuation is True

    def test_punctuation_ellipsis(self):
        d = MoodDetector()
        sig = d._analyze("I just... I don't know...")
        assert sig.has_punctuation is True

    def test_no_punctuation_on_plain_text(self):
        d = MoodDetector()
        sig = d._analyze("This is a normal sentence.")
        assert sig.has_punctuation is False

    def test_is_question_true(self):
        d = MoodDetector()
        sig = d._analyze("How does this work?")
        assert sig.is_question is True

    def test_is_question_false(self):
        d = MoodDetector()
        sig = d._analyze("It does not work.")
        assert sig.is_question is False

    def test_sentiment_negative(self):
        d = MoodDetector()
        sig = d._analyze("This is broken and I hate it")
        assert sig.sentiment_hint == "negative"

    def test_sentiment_positive(self):
        d = MoodDetector()
        sig = d._analyze("This is awesome, thanks!")
        assert sig.sentiment_hint == "positive"

    def test_sentiment_neutral_no_keywords(self):
        d = MoodDetector()
        sig = d._analyze("The server is running on port 8080.")
        assert sig.sentiment_hint == "neutral"

    def test_word_count(self):
        d = MoodDetector()
        sig = d._analyze("one two three four five")
        assert sig.word_count == 5

    def test_msg_length(self):
        d = MoodDetector()
        sig = d._analyze("hello")
        assert sig.msg_length == 5


# ---------------------------------------------------------------------------
# Mood detection: not enough data defaults to neutral
# ---------------------------------------------------------------------------

class TestNotEnoughData:
    def test_no_observations_returns_neutral(self):
        d = MoodDetector()
        assert d.get_mood("alice") == "neutral"

    def test_single_observation_returns_neutral(self):
        d = MoodDetector()
        d.observe("alice", "hello")
        assert d.get_mood("alice") == "neutral"


# ---------------------------------------------------------------------------
# Mood detection: frustrated
# ---------------------------------------------------------------------------

class TestFrustratedMood:
    def _frustrated_msgs(self):
        # short (few words) + caps + negative + double punctuation
        return [
            "THIS IS BROKEN!!",
            "WHY AGAIN??",
            "DAMN IT!!",
            "FIX THIS!!",
            "IT CRASHED AGAIN!!",
        ]

    def test_frustrated_detected(self):
        d = MoodDetector()
        _feed(d, "user1", self._frustrated_msgs())
        assert d.get_mood("user1") == "frustrated"


# ---------------------------------------------------------------------------
# Mood detection: focused
# ---------------------------------------------------------------------------

class TestFocusedMood:
    def _focused_msgs(self):
        # many questions, neutral sentiment
        return [
            "How do I configure the database?",
            "What is the default timeout?",
            "Where does the log file go?",
            "Which endpoint handles auth?",
            "Can I set the port via env var?",
        ]

    def test_focused_detected(self):
        d = MoodDetector()
        _feed(d, "user2", self._focused_msgs())
        assert d.get_mood("user2") == "focused"


# ---------------------------------------------------------------------------
# Mood detection: excited
# ---------------------------------------------------------------------------

class TestExcitedMood:
    def _excited_msgs(self):
        # positive keywords + punctuation or caps
        return [
            "This is AWESOME!!",
            "Great, it works!!",
            "Amazing, love it!!",
            "Wow, fantastic result!!",
            "Perfect, yay!!",
        ]

    def test_excited_detected(self):
        d = MoodDetector()
        _feed(d, "user3", self._excited_msgs())
        assert d.get_mood("user3") == "excited"


# ---------------------------------------------------------------------------
# Mood detection: relaxed
# ---------------------------------------------------------------------------

class TestRelaxedMood:
    def _relaxed_msgs(self):
        # long messages, positive or neutral, low caps, no double-punct
        return [
            "I have been going through the documentation and it all makes sense now.",
            "Thanks for explaining that, everything is working as expected.",
            "The deployment went smoothly and the metrics look great today.",
            "Good progress overall, I am happy with where things are heading.",
            "Nice setup, I think we are in a solid place with the architecture.",
        ]

    def test_relaxed_detected(self):
        d = MoodDetector()
        _feed(d, "user4", self._relaxed_msgs())
        assert d.get_mood("user4") == "relaxed"


# ---------------------------------------------------------------------------
# Mood detection: neutral fallback
# ---------------------------------------------------------------------------

class TestNeutralMood:
    def test_neutral_on_mixed_signals(self):
        d = MoodDetector()
        # Two short neutral messages with no strong signals
        _feed(d, "user5", [
            "hello there",
            "ok sounds good",
        ])
        assert d.get_mood("user5") == "neutral"


# ---------------------------------------------------------------------------
# get_context
# ---------------------------------------------------------------------------

class TestGetContext:
    def test_frustrated_context_not_empty(self):
        d = MoodDetector()
        # Manually force frustrated by feeding the right pattern
        msgs = [
            "THIS IS BROKEN!!",
            "WHY AGAIN??",
            "DAMN IT!!",
            "FIX THIS!!",
            "IT CRASHED AGAIN!!",
        ]
        _feed(d, "u", msgs)
        ctx = d.get_context("u")
        assert ctx != ""
        assert "frustrated" in ctx.lower() or "short" in ctx.lower() or "direct" in ctx.lower()

    def test_focused_context_not_empty(self):
        d = MoodDetector()
        msgs = [
            "How do I configure the database?",
            "What is the default timeout?",
            "Where does the log file go?",
            "Which endpoint handles auth?",
            "Can I set the port via env var?",
        ]
        _feed(d, "u", msgs)
        ctx = d.get_context("u")
        assert ctx != ""

    def test_excited_context_not_empty(self):
        d = MoodDetector()
        msgs = [
            "This is AWESOME!!",
            "Great, it works!!",
            "Amazing, love it!!",
            "Wow, fantastic result!!",
            "Perfect, yay!!",
        ]
        _feed(d, "u", msgs)
        ctx = d.get_context("u")
        assert ctx != ""

    def test_relaxed_context_not_empty(self):
        d = MoodDetector()
        msgs = [
            "I have been going through the documentation and it all makes sense now.",
            "Thanks for explaining that, everything is working as expected.",
            "The deployment went smoothly and the metrics look great today.",
            "Good progress overall, I am happy with where things are heading.",
            "Nice setup, I think we are in a solid place with the architecture.",
        ]
        _feed(d, "u", msgs)
        ctx = d.get_context("u")
        assert ctx != ""

    def test_neutral_context_is_empty(self):
        d = MoodDetector()
        # Only one message — not enough data, mood is neutral
        d.observe("u", "hello")
        ctx = d.get_context("u")
        assert ctx == ""

    def test_neutral_no_data_context_is_empty(self):
        d = MoodDetector()
        ctx = d.get_context("new_user")
        assert ctx == ""


# ---------------------------------------------------------------------------
# Window size enforcement
# ---------------------------------------------------------------------------

class TestWindowSize:
    def test_old_signals_drop_off(self):
        d = MoodDetector(window_size=3)
        user = "win_user"

        # First 3 signals: all frustrated (short + caps + negative + punct)
        d.observe(user, "THIS BROKE!!")
        d.observe(user, "STILL BROKEN!!")
        d.observe(user, "FIX IT!!")

        # Confirm frustrated at this point (need >=2 signals; we have 3)
        # Now add 3 more calm, positive signals to push frustrated ones out
        d.observe(user, "I have been thinking about it and all seems fine now.")
        d.observe(user, "Good progress overall, everything is working as expected.")
        d.observe(user, "Nice, I am happy with where things are heading today.")

        # Window is 3, so only the last 3 (relaxed) remain
        assert d.get_mood(user) != "frustrated"

    def test_window_size_respected(self):
        d = MoodDetector(window_size=4)
        user = "win2"
        for i in range(10):
            d.observe(user, f"message number {i}")
        # Internal deque should never exceed window_size
        assert len(d._signals[user]) == 4


# ---------------------------------------------------------------------------
# Per-user isolation
# ---------------------------------------------------------------------------

class TestPerUserIsolation:
    def test_users_do_not_share_signals(self):
        d = MoodDetector()

        # Feed frustrated signals to alice
        for _ in range(5):
            d.observe("alice", "THIS IS BROKEN!!")

        # bob has no signals yet
        assert d.get_mood("bob") == "neutral"

    def test_separate_moods_per_user(self):
        d = MoodDetector()

        # alice: relaxed long messages
        _feed(d, "alice", [
            "I have been going through the documentation and everything looks fine.",
            "Thanks for the help, it all makes sense now and things work well.",
            "Good progress today, I am very happy with the results so far.",
            "Nice architecture overall, I think we are in a solid place now.",
            "The deployment went smoothly and everything is working as expected.",
        ])

        # bob: frustrated short caps
        _feed(d, "bob", [
            "THIS IS BROKEN!!",
            "WHY AGAIN??",
            "DAMN IT!!",
            "FIX THIS!!",
            "STILL BROKEN!!",
        ])

        assert d.get_mood("alice") == "relaxed"
        assert d.get_mood("bob") == "frustrated"
