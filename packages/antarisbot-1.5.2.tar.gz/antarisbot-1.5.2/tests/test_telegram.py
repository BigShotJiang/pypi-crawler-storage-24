"""
Tests for TelegramAdapter.
Uses unittest.mock — no live Telegram connection required.
"""
import asyncio
import pytest
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch, call

from antarisbot.channels.base import InboundMessage, OutboundMessage
from antarisbot.channels.telegram import TelegramAdapter, MAX_MESSAGE_LENGTH


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_update(
    text="hello",
    chat_id=12345,
    chat_type="private",
    user_id=99,
    user_name="Alice",
    message_id=1,
):
    """Build a minimal mock telegram Update."""
    update = MagicMock()
    update.message.text = text
    update.message.chat.id = chat_id
    update.message.chat.type = chat_type
    update.message.from_user.id = user_id
    update.message.full_name = user_name
    update.message.from_user.full_name = user_name
    update.message.message_id = message_id
    update.message.date = datetime(2026, 1, 1, tzinfo=timezone.utc)
    return update


def _make_context(bot_username="AntarisBot"):
    """Build a minimal mock telegram Context."""
    context = MagicMock()
    context.bot.username = bot_username
    context.bot.send_chat_action = AsyncMock()
    context.bot.send_message = AsyncMock()
    return context


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------

class TestTelegramAdapterInit:
    def test_init_with_token(self):
        adapter = TelegramAdapter(token="abc:123")
        assert adapter.token == "abc:123"
        assert adapter.bot_name == "Antaris"
        assert adapter.open_chats == set()
        assert adapter._app is None

    def test_init_custom_name(self):
        adapter = TelegramAdapter(token="abc:123", bot_name="Shiro")
        assert adapter.bot_name == "Shiro"

    def test_init_open_chats(self):
        adapter = TelegramAdapter(token="abc:123", open_chats=[111, 222])
        assert adapter.open_chats == {"111", "222"}

    def test_token_missing_raises_value_error(self):
        with pytest.raises(ValueError, match="token"):
            TelegramAdapter(token="")

    def test_token_none_raises_value_error(self):
        with pytest.raises(ValueError, match="token"):
            TelegramAdapter(token=None)

    def test_format_for_surface_passthrough(self):
        adapter = TelegramAdapter(token="abc:123")
        assert adapter.format_for_surface("**bold**") == "**bold**"


# ---------------------------------------------------------------------------
# Message splitting
# ---------------------------------------------------------------------------

class TestMessageSplitting:
    def test_short_message_unchanged(self):
        adapter = TelegramAdapter(token="abc:123")
        chunks = adapter._split_message("Hello world")
        assert chunks == ["Hello world"]

    def test_exact_limit_no_split(self):
        adapter = TelegramAdapter(token="abc:123")
        text = "x" * MAX_MESSAGE_LENGTH
        chunks = adapter._split_message(text)
        assert len(chunks) == 1
        assert chunks[0] == text

    def test_over_limit_splits(self):
        adapter = TelegramAdapter(token="abc:123")
        line = "A" * 100
        text = "\n".join([line] * 50)  # 50*100 + 49 newlines = 5049 > 4096
        chunks = adapter._split_message(text)
        assert len(chunks) >= 2
        for chunk in chunks:
            assert len(chunk) <= MAX_MESSAGE_LENGTH

    def test_split_preserves_content(self):
        adapter = TelegramAdapter(token="abc:123")
        line = "B" * 100
        text = "\n".join([line] * 50)
        chunks = adapter._split_message(text)
        joined = "\n".join(chunks)
        assert joined.count("B" * 100) == 50

    def test_single_oversized_line_becomes_own_chunk(self):
        adapter = TelegramAdapter(token="abc:123")
        huge = "Z" * (MAX_MESSAGE_LENGTH + 100)
        chunks = adapter._split_message(huge)
        assert any(huge in chunk for chunk in chunks)


# ---------------------------------------------------------------------------
# Message routing via _on_message
# ---------------------------------------------------------------------------

class TestOnMessage:
    @pytest.mark.asyncio
    async def test_dm_always_responds(self):
        """Private chats always get a response."""
        adapter = TelegramAdapter(token="abc:123")
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(text="hi", chat_type="private", chat_id=42)
        context = _make_context()

        await adapter._on_message(update, context)

        handler.assert_called_once()
        inbound = handler.call_args[0][0]
        assert isinstance(inbound, InboundMessage)
        assert inbound.text == "hi"
        assert inbound.platform == "telegram"
        assert inbound.channel_id == "42"

    @pytest.mark.asyncio
    async def test_mention_in_group_responds(self):
        """@mention in a group triggers a response."""
        adapter = TelegramAdapter(token="abc:123")
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(
            text="@AntarisBot how are you?",
            chat_type="group",
            chat_id=999,
        )
        context = _make_context(bot_username="AntarisBot")

        await adapter._on_message(update, context)

        handler.assert_called_once()
        inbound = handler.call_args[0][0]
        assert "how are you?" in inbound.text
        # @mention stripped
        assert "@AntarisBot" not in inbound.text

    @pytest.mark.asyncio
    async def test_no_open_chats_responds_to_all(self):
        """Without open_chats restriction, all group messages get a response."""
        adapter = TelegramAdapter(token="abc:123", open_chats=[])
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(text="just chatting", chat_type="group", chat_id=777)
        context = _make_context()

        await adapter._on_message(update, context)

        handler.assert_called_once()

    @pytest.mark.asyncio
    async def test_open_chat_gating_allows_configured_chat(self):
        """With open_chats set, configured chats get responses."""
        adapter = TelegramAdapter(token="abc:123", open_chats=[777])
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(text="allowed message", chat_type="group", chat_id=777)
        context = _make_context()

        await adapter._on_message(update, context)

        handler.assert_called_once()

    @pytest.mark.asyncio
    async def test_open_chat_gating_blocks_unconfigured_chat(self):
        """With open_chats set, unconfigured chats get no response."""
        adapter = TelegramAdapter(token="abc:123", open_chats=[777])
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(text="blocked message", chat_type="group", chat_id=888)
        context = _make_context()

        await adapter._on_message(update, context)

        handler.assert_not_called()

    @pytest.mark.asyncio
    async def test_open_chat_gating_dm_always_allowed(self):
        """DMs bypass open_chats restriction."""
        adapter = TelegramAdapter(token="abc:123", open_chats=[777])
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(text="dm message", chat_type="private", chat_id=999)
        context = _make_context()

        await adapter._on_message(update, context)

        handler.assert_called_once()

    @pytest.mark.asyncio
    async def test_mention_bypasses_open_chat_restriction(self):
        """@mentions bypass open_chats restriction in any group."""
        adapter = TelegramAdapter(token="abc:123", open_chats=[111])
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(
            text="@AntarisBot help!",
            chat_type="group",
            chat_id=999,  # not in open_chats
        )
        context = _make_context(bot_username="AntarisBot")

        await adapter._on_message(update, context)

        handler.assert_called_once()

    @pytest.mark.asyncio
    async def test_empty_text_after_mention_strip_skips_handler(self):
        """If only the @mention is in the message, skip handler."""
        adapter = TelegramAdapter(token="abc:123")
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(text="@AntarisBot", chat_type="group", chat_id=42)
        context = _make_context(bot_username="AntarisBot")

        await adapter._on_message(update, context)

        handler.assert_not_called()

    @pytest.mark.asyncio
    async def test_no_handler_registered_does_not_crash(self):
        """If no handler is registered, _on_message should exit cleanly."""
        adapter = TelegramAdapter(token="abc:123")
        # No handler registered

        update = _make_update(text="hi", chat_type="private", chat_id=1)
        context = _make_context()

        # Should not raise
        await adapter._on_message(update, context)

    @pytest.mark.asyncio
    async def test_inbound_message_fields(self):
        """Check all InboundMessage fields are populated correctly."""
        adapter = TelegramAdapter(token="abc:123")
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(
            text="test message",
            chat_id=555,
            chat_type="private",
            user_id=77,
            user_name="Bob",
            message_id=42,
        )
        context = _make_context()

        await adapter._on_message(update, context)

        inbound = handler.call_args[0][0]
        assert inbound.id == "42"
        assert inbound.user_id == "77"
        assert inbound.user_name == "Bob"
        assert inbound.channel_id == "555"
        assert inbound.platform == "telegram"
        assert inbound.text == "test message"
        assert inbound.metadata["chat_type"] == "private"


# ---------------------------------------------------------------------------
# Typing indicator
# ---------------------------------------------------------------------------

class TestTypingAction:
    @pytest.mark.asyncio
    async def test_typing_action_sent_before_handler(self):
        """ChatAction.TYPING must be sent before routing to handler."""
        from telegram.constants import ChatAction

        adapter = TelegramAdapter(token="abc:123")
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(text="query", chat_type="private", chat_id=10)
        context = _make_context()

        call_order = []
        context.bot.send_chat_action = AsyncMock(
            side_effect=lambda **kwargs: call_order.append("typing")
        )
        handler.side_effect = lambda *a, **k: call_order.append("handler")

        await adapter._on_message(update, context)

        assert call_order.index("typing") < call_order.index("handler")
        context.bot.send_chat_action.assert_called_once()
        _, kwargs = context.bot.send_chat_action.call_args
        assert kwargs.get("action") == ChatAction.TYPING

    @pytest.mark.asyncio
    async def test_typing_failure_does_not_block_handler(self):
        """If sending typing action fails, handler should still be called."""
        adapter = TelegramAdapter(token="abc:123")
        handler = AsyncMock()
        adapter.on_message(handler)

        update = _make_update(text="hi", chat_type="private", chat_id=10)
        context = _make_context()
        context.bot.send_chat_action = AsyncMock(side_effect=Exception("timeout"))

        await adapter._on_message(update, context)

        handler.assert_called_once()


# ---------------------------------------------------------------------------
# send() and send_message()
# ---------------------------------------------------------------------------

class TestSend:
    @pytest.mark.asyncio
    async def test_send_no_app_is_noop(self):
        adapter = TelegramAdapter(token="abc:123")
        msg = OutboundMessage(channel_id="123", text="hi")
        # Should not raise
        await adapter.send(msg)

    @pytest.mark.asyncio
    async def test_send_short_message(self):
        adapter = TelegramAdapter(token="abc:123")
        mock_bot = AsyncMock()
        mock_app = MagicMock()
        mock_app.bot = mock_bot
        adapter._app = mock_app

        msg = OutboundMessage(channel_id="42", text="Hello!")
        await adapter.send(msg)

        mock_bot.send_message.assert_called_once_with(chat_id=42, text="Hello!")

    @pytest.mark.asyncio
    async def test_send_splits_long_message(self):
        adapter = TelegramAdapter(token="abc:123")
        mock_bot = AsyncMock()
        mock_app = MagicMock()
        mock_app.bot = mock_bot
        adapter._app = mock_app

        line = "A" * 100
        long_text = "\n".join([line] * 50)  # > 4096 chars
        msg = OutboundMessage(channel_id="42", text=long_text)
        await adapter.send(msg)

        assert mock_bot.send_message.call_count >= 2

    @pytest.mark.asyncio
    async def test_send_error_does_not_raise(self):
        """send() should swallow errors and not crash."""
        adapter = TelegramAdapter(token="abc:123")
        mock_bot = AsyncMock()
        mock_bot.send_message = AsyncMock(side_effect=Exception("network error"))
        mock_app = MagicMock()
        mock_app.bot = mock_bot
        adapter._app = mock_app

        msg = OutboundMessage(channel_id="42", text="hi")
        await adapter.send(msg)  # should not raise

    @pytest.mark.asyncio
    async def test_send_message_helper(self):
        adapter = TelegramAdapter(token="abc:123")
        mock_bot = AsyncMock()
        mock_app = MagicMock()
        mock_app.bot = mock_bot
        adapter._app = mock_app

        await adapter.send_message(chat_id=55, text="direct message")

        mock_bot.send_message.assert_called_once_with(chat_id=55, text="direct message")

    @pytest.mark.asyncio
    async def test_send_message_no_app_is_noop(self):
        adapter = TelegramAdapter(token="abc:123")
        # Should not raise
        await adapter.send_message(chat_id=55, text="hi")


# ---------------------------------------------------------------------------
# connect() / disconnect() lifecycle
# ---------------------------------------------------------------------------

class TestLifecycle:
    @pytest.mark.asyncio
    async def test_connect_start_stop(self):
        """connect() should call Application lifecycle methods and stop cleanly."""
        adapter = TelegramAdapter(token="abc:123")

        mock_updater = AsyncMock()
        mock_app = AsyncMock()
        mock_app.updater = mock_updater
        mock_app.add_handler = MagicMock()

        with patch("antarisbot.channels.telegram.Application") as MockApplication:
            builder = MagicMock()
            builder.token.return_value = builder
            builder.build.return_value = mock_app
            MockApplication.builder.return_value = builder

            # start connect() and immediately signal stop
            async def auto_stop():
                await asyncio.sleep(0)  # yield to let connect() set up
                await adapter.disconnect()

            await asyncio.gather(adapter.connect(), auto_stop())

        mock_app.initialize.assert_called_once()
        mock_app.start.assert_called_once()
        mock_updater.start_polling.assert_called_once()
        mock_updater.stop.assert_called_once()
        mock_app.stop.assert_called_once()
        mock_app.shutdown.assert_called_once()

    @pytest.mark.asyncio
    async def test_start_stop_aliases(self):
        """start() and stop() are aliases for connect() and disconnect()."""
        adapter = TelegramAdapter(token="abc:123")

        mock_updater = AsyncMock()
        mock_app = AsyncMock()
        mock_app.updater = mock_updater
        mock_app.add_handler = MagicMock()

        with patch("antarisbot.channels.telegram.Application") as MockApplication:
            builder = MagicMock()
            builder.token.return_value = builder
            builder.build.return_value = mock_app
            MockApplication.builder.return_value = builder

            async def auto_stop():
                await asyncio.sleep(0)
                await adapter.stop()

            await asyncio.gather(adapter.start(), auto_stop())

        mock_app.initialize.assert_called_once()

    @pytest.mark.asyncio
    async def test_disconnect_before_connect_is_noop(self):
        """disconnect() before connect() should not raise."""
        adapter = TelegramAdapter(token="abc:123")
        await adapter.disconnect()  # should not raise
