"""
Tests for ConversationExporter and the !export command.
"""
import asyncio
import pytest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

from antarisbot.core.exporter import ConversationExporter
from antarisbot.core.commands import CommandDispatcher
from antarisbot.channels.base import InboundMessage


# ── Helpers ──────────────────────────────────────────────────────────────────

def make_inbound(text="!export", user_id="user-export", channel_id="ch-1"):
    return InboundMessage(
        id="msg-export",
        user_id=user_id,
        user_name="ExportUser",
        channel_id=channel_id,
        platform="terminal",
        text=text,
        timestamp_ms=0,
    )


def make_memory(results: list[dict] | None = None):
    """Build a mock BotMemory that returns controllable results."""
    memory = MagicMock()
    if results is None:
        results = [
            {
                "content": "User: hello\nAntaris: hi there",
                "score": 0.9,
                "timestamp": "2024-01-01T12:00:00+00:00",
                "source": "conversation",
            },
            {
                "content": "User: how are you\nAntaris: doing well",
                "score": 0.8,
                "timestamp": "2024-01-01T13:00:00+00:00",
                "source": "conversation",
            },
        ]
    memory.search_memories.return_value = results
    return memory


def make_bot_with_exporter(exporter):
    bot = MagicMock()
    bot.memory.stats.return_value = {"total": 10}
    bot.config.model = "claude-sonnet-4-6"
    bot.config.provider_name = "anthropic"
    bot.config.guard_mode = "strict"
    bot.config.security_mode = "sandboxed"
    bot.dispatcher.providers = {"anthropic": MagicMock()}
    bot.router = None
    bot.exporter = exporter
    return bot


# ── ConversationExporter unit tests ──────────────────────────────────────────

class TestConversationExporter:

    def test_export_dir_created(self, tmp_path):
        export_dir = tmp_path / "exports"
        assert not export_dir.exists()
        exporter = ConversationExporter(make_memory(), export_dir)
        assert export_dir.exists()

    def test_export_dir_accepts_string(self, tmp_path):
        exporter = ConversationExporter(make_memory(), str(tmp_path / "exports"))
        assert exporter.export_dir.exists()

    # ── format_markdown ───────────────────────────────────────────────────

    def test_format_markdown_title(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        md = exporter._format_markdown([], "My Title")
        assert "# My Title" in md

    def test_format_markdown_exported_timestamp(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        md = exporter._format_markdown([], "Test")
        assert "Exported:" in md

    def test_format_markdown_entry_count(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        entries = [{"content": "hi", "score": 0.5, "source": "conv", "timestamp": ""}]
        md = exporter._format_markdown(entries, "Test")
        assert "*Entries: 1*" in md

    def test_format_markdown_zero_entries(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        md = exporter._format_markdown([], "Test")
        assert "*Entries: 0*" in md

    def test_format_markdown_entry_content(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        entries = [{"content": "hello world", "score": 0.7, "source": "conv", "timestamp": ""}]
        md = exporter._format_markdown(entries, "Test")
        assert "hello world" in md

    def test_format_markdown_entry_source(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        entries = [{"content": "x", "score": 0.5, "source": "my_source", "timestamp": ""}]
        md = exporter._format_markdown(entries, "Test")
        assert "my_source" in md

    def test_format_markdown_entry_score(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        entries = [{"content": "x", "score": 0.75, "source": "s", "timestamp": ""}]
        md = exporter._format_markdown(entries, "Test")
        assert "0.75" in md

    def test_format_markdown_with_timestamp(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        entries = [{"content": "x", "score": 0.5, "source": "s", "timestamp": "2024-01-01T10:00:00"}]
        md = exporter._format_markdown(entries, "Test")
        assert "2024-01-01T10:00:00" in md

    def test_format_markdown_without_timestamp(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        entries = [{"content": "x", "score": 0.5, "source": "s", "timestamp": ""}]
        md = exporter._format_markdown(entries, "Test")
        assert "### Entry 1\n" in md

    def test_format_markdown_dividers(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        entries = [{"content": "x", "score": 0.5, "source": "s", "timestamp": ""}]
        md = exporter._format_markdown(entries, "Test")
        assert "---" in md

    def test_format_markdown_multiple_entries(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        entries = [
            {"content": f"entry {i}", "score": 0.5, "source": "s", "timestamp": ""}
            for i in range(3)
        ]
        md = exporter._format_markdown(entries, "Test")
        assert "### Entry 1" in md
        assert "### Entry 2" in md
        assert "### Entry 3" in md

    # ── export_recent ─────────────────────────────────────────────────────

    def test_export_recent_writes_file(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, summary = exporter.export_recent("user1", days=1)
        assert filepath != ""
        assert Path(filepath).exists()

    def test_export_recent_returns_summary(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, summary = exporter.export_recent("user1", days=1)
        assert "Exported" in summary
        assert "entries" in summary

    def test_export_recent_calls_search_memories(self, tmp_path):
        memory = make_memory()
        exporter = ConversationExporter(memory, tmp_path)
        exporter.export_recent("user42", days=1)
        memory.search_memories.assert_called_once()
        call_args = memory.search_memories.call_args
        assert call_args[0][0] == "user42"

    def test_export_recent_today_label(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, _ = exporter.export_recent("user1", days=1)
        content = Path(filepath).read_text()
        assert "today" in content.lower()

    def test_export_recent_week_label(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, _ = exporter.export_recent("user1", days=7)
        content = Path(filepath).read_text()
        assert "7 days" in content.lower()

    def test_export_recent_empty_results(self, tmp_path):
        memory = make_memory(results=[])
        exporter = ConversationExporter(memory, tmp_path)
        filepath, summary = exporter.export_recent("user1", days=1)
        assert filepath == ""
        assert "No conversations found" in summary

    def test_export_recent_filename_contains_user_id(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, _ = exporter.export_recent("myuser", days=1)
        assert "myuser" in Path(filepath).name

    def test_export_recent_filters_old_entries(self, tmp_path):
        # One entry from yesterday (within range), one from 10 days ago (outside)
        now = datetime.now(timezone.utc)
        recent_ts = (now - timedelta(hours=1)).isoformat()
        old_ts = (now - timedelta(days=10)).isoformat()
        results = [
            {"content": "recent entry", "score": 0.9, "source": "conv", "timestamp": recent_ts},
            {"content": "old entry", "score": 0.7, "source": "conv", "timestamp": old_ts},
        ]
        memory = make_memory(results=results)
        exporter = ConversationExporter(memory, tmp_path)
        filepath, summary = exporter.export_recent("user1", days=1)
        content = Path(filepath).read_text()
        assert "recent entry" in content
        assert "old entry" not in content

    def test_export_recent_fallback_when_all_filtered(self, tmp_path):
        # All entries are very old -- should fall back to top 20
        now = datetime.now(timezone.utc)
        old_ts = (now - timedelta(days=30)).isoformat()
        results = [
            {"content": f"old entry {i}", "score": 0.5, "source": "s", "timestamp": old_ts}
            for i in range(5)
        ]
        memory = make_memory(results=results)
        exporter = ConversationExporter(memory, tmp_path)
        filepath, summary = exporter.export_recent("user1", days=1)
        # Fallback kicks in -- file should exist and have entries
        assert filepath != ""
        assert Path(filepath).exists()

    def test_export_recent_no_timestamp_entries_included(self, tmp_path):
        results = [
            {"content": "no-ts entry", "score": 0.9, "source": "conv", "timestamp": None},
        ]
        memory = make_memory(results=results)
        exporter = ConversationExporter(memory, tmp_path)
        filepath, summary = exporter.export_recent("user1", days=1)
        content = Path(filepath).read_text()
        assert "no-ts entry" in content

    # ── export_by_topic ───────────────────────────────────────────────────

    def test_export_by_topic_writes_file(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, summary = exporter.export_by_topic("user1", "deployment")
        assert filepath != ""
        assert Path(filepath).exists()

    def test_export_by_topic_searches_for_topic(self, tmp_path):
        memory = make_memory()
        exporter = ConversationExporter(memory, tmp_path)
        exporter.export_by_topic("user1", "my topic")
        memory.search_memories.assert_called_once()
        call_args = memory.search_memories.call_args
        assert "my topic" in call_args[0]

    def test_export_by_topic_includes_topic_in_title(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, _ = exporter.export_by_topic("user1", "antarisbot")
        content = Path(filepath).read_text()
        assert "antarisbot" in content

    def test_export_by_topic_summary_mentions_topic(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        _, summary = exporter.export_by_topic("user1", "antarisbot")
        assert "antarisbot" in summary.lower()

    def test_export_by_topic_empty_results(self, tmp_path):
        memory = make_memory(results=[])
        exporter = ConversationExporter(memory, tmp_path)
        filepath, summary = exporter.export_by_topic("user1", "missing topic")
        assert filepath == ""
        assert "missing topic" in summary

    def test_export_by_topic_filename_sanitized(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, _ = exporter.export_by_topic("user1", "some topic")
        # Spaces should be replaced with underscores in filename
        assert " " not in Path(filepath).name

    def test_export_by_topic_long_topic_truncated_in_filename(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        long_topic = "a" * 100
        filepath, _ = exporter.export_by_topic("user1", long_topic)
        # Topic portion of filename should be at most 30 chars
        name = Path(filepath).name
        # The full path must be valid (not too long)
        assert len(name) < 200

    # ── export_all ────────────────────────────────────────────────────────

    def test_export_all_writes_file(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, summary = exporter.export_all("user1")
        assert filepath != ""
        assert Path(filepath).exists()

    def test_export_all_calls_search_memories(self, tmp_path):
        memory = make_memory()
        exporter = ConversationExporter(memory, tmp_path)
        exporter.export_all("user99")
        memory.search_memories.assert_called_once()
        call_args = memory.search_memories.call_args
        assert call_args[0][0] == "user99"

    def test_export_all_high_limit(self, tmp_path):
        memory = make_memory()
        exporter = ConversationExporter(memory, tmp_path)
        exporter.export_all("user1")
        call_args = memory.search_memories.call_args
        assert call_args[1].get("limit", call_args[0][2] if len(call_args[0]) > 2 else 0) >= 1000

    def test_export_all_empty_results(self, tmp_path):
        memory = make_memory(results=[])
        exporter = ConversationExporter(memory, tmp_path)
        filepath, summary = exporter.export_all("user1")
        assert filepath == ""
        assert "No conversations found" in summary

    def test_export_all_filename_contains_complete(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        filepath, _ = exporter.export_all("user1")
        assert "complete" in Path(filepath).name

    def test_export_all_summary_has_count(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        _, summary = exporter.export_all("user1")
        assert "2" in summary  # 2 entries in default make_memory()


# ── !export command integration tests ────────────────────────────────────────

class TestExportCommand:

    def _make_dispatcher(self, exporter):
        bot = make_bot_with_exporter(exporter)
        return CommandDispatcher(bot)

    @pytest.mark.asyncio
    async def test_export_no_args_shows_usage(self, tmp_path):
        dispatcher = self._make_dispatcher(ConversationExporter(make_memory(), tmp_path))
        result = await dispatcher.dispatch(make_inbound("!export"))
        assert result.handled is True
        assert "today" in result.response.lower() or "usage" in result.response.lower()

    @pytest.mark.asyncio
    async def test_export_today(self, tmp_path):
        dispatcher = self._make_dispatcher(ConversationExporter(make_memory(), tmp_path))
        result = await dispatcher.dispatch(make_inbound("!export today"))
        assert result.handled is True
        assert "Exported" in result.response or "No conversations" in result.response

    @pytest.mark.asyncio
    async def test_export_week(self, tmp_path):
        dispatcher = self._make_dispatcher(ConversationExporter(make_memory(), tmp_path))
        result = await dispatcher.dispatch(make_inbound("!export week"))
        assert result.handled is True
        assert "Exported" in result.response or "No conversations" in result.response

    @pytest.mark.asyncio
    async def test_export_all(self, tmp_path):
        dispatcher = self._make_dispatcher(ConversationExporter(make_memory(), tmp_path))
        result = await dispatcher.dispatch(make_inbound("!export all"))
        assert result.handled is True
        assert "Exported" in result.response or "No conversations" in result.response

    @pytest.mark.asyncio
    async def test_export_project(self, tmp_path):
        dispatcher = self._make_dispatcher(ConversationExporter(make_memory(), tmp_path))
        result = await dispatcher.dispatch(make_inbound("!export project antarisbot"))
        assert result.handled is True
        assert result.response is not None

    @pytest.mark.asyncio
    async def test_export_project_no_name_shows_usage(self, tmp_path):
        dispatcher = self._make_dispatcher(ConversationExporter(make_memory(), tmp_path))
        result = await dispatcher.dispatch(make_inbound("!export project"))
        assert result.handled is True
        assert "usage" in result.response.lower() or "project <name>" in result.response.lower()

    @pytest.mark.asyncio
    async def test_export_unknown_subcommand(self, tmp_path):
        dispatcher = self._make_dispatcher(ConversationExporter(make_memory(), tmp_path))
        result = await dispatcher.dispatch(make_inbound("!export bogus"))
        assert result.handled is True
        assert "Unknown" in result.response or "today" in result.response.lower()

    @pytest.mark.asyncio
    async def test_export_not_available_when_no_exporter(self):
        bot = MagicMock()
        bot.memory.stats.return_value = {"total": 0}
        bot.config.model = "claude-sonnet-4-6"
        bot.config.provider_name = "anthropic"
        bot.config.guard_mode = "strict"
        bot.config.security_mode = "sandboxed"
        bot.dispatcher.providers = {}
        bot.router = None
        bot.exporter = None
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!export today"))
        assert result.handled is True
        assert "not available" in result.response.lower()

    @pytest.mark.asyncio
    async def test_export_today_creates_file(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        dispatcher = self._make_dispatcher(exporter)
        result = await dispatcher.dispatch(make_inbound("!export today", user_id="myuser"))
        assert result.handled is True
        # A file should have been created in tmp_path
        files = list(tmp_path.glob("export_*.md"))
        assert len(files) == 1

    @pytest.mark.asyncio
    async def test_export_today_empty_memory(self, tmp_path):
        exporter = ConversationExporter(make_memory(results=[]), tmp_path)
        dispatcher = self._make_dispatcher(exporter)
        result = await dispatcher.dispatch(make_inbound("!export today"))
        assert result.handled is True
        assert "No conversations found" in result.response

    @pytest.mark.asyncio
    async def test_export_week_calls_7_days(self, tmp_path):
        memory = make_memory()
        exporter = ConversationExporter(memory, tmp_path)
        dispatcher = self._make_dispatcher(exporter)
        await dispatcher.dispatch(make_inbound("!export week"))
        # search_memories should have been called with limit=100
        memory.search_memories.assert_called_once()

    @pytest.mark.asyncio
    async def test_export_project_multi_word(self, tmp_path):
        exporter = ConversationExporter(make_memory(), tmp_path)
        dispatcher = self._make_dispatcher(exporter)
        result = await dispatcher.dispatch(make_inbound("!export project my cool project"))
        assert result.handled is True
        assert result.response is not None


# ── help includes export ──────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_help_includes_export():
    bot = MagicMock()
    bot.memory.stats.return_value = {"total": 0}
    bot.config.model = "claude-sonnet-4-6"
    bot.config.provider_name = "anthropic"
    bot.config.guard_mode = "strict"
    bot.config.security_mode = "sandboxed"
    bot.dispatcher.providers = {}
    bot.router = None
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!help"))
    assert result.handled is True
    assert "export" in result.response.lower()
