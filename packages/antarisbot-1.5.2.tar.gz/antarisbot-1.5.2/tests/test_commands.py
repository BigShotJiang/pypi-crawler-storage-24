"""
Tests for CommandDispatcher and BotMemory ingest filter.
"""
import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antarisbot.channels.base import InboundMessage
from antarisbot.core.commands import CommandDispatcher, CommandResult
from antarisbot.core.memory import BotMemory


# ── Helpers ─────────────────────────────────────────────────────────────────

def make_inbound(text="Hello", user_id="user-42", channel_id="ch-1", platform="terminal"):
    return InboundMessage(
        id="msg-1",
        user_id=user_id,
        user_name="TestUser",
        channel_id=channel_id,
        platform=platform,
        text=text,
        timestamp_ms=0,
    )


def make_bot():
    """Build a minimal mock Bot for CommandDispatcher."""
    bot = MagicMock()
    bot.memory.stats.return_value = {"total": 42}
    bot.config.model = "claude-sonnet-4-6"
    bot.config.provider_name = "anthropic"
    bot.config.guard_mode = "strict"
    bot.config.security_mode = "sandboxed"
    bot.dispatcher.providers = {"anthropic": MagicMock(), "openai": MagicMock()}
    bot.router = None
    return bot


# ── CommandDispatcher tests ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_status_returns_status_string():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!status"))
    assert result.handled is True
    assert result.response is not None
    # Should contain "Status" or "Memory" somewhere
    assert "Status" in result.response or "Memory" in result.response


@pytest.mark.asyncio
async def test_status_contains_memory_count():
    bot = make_bot()
    bot.memory.stats.return_value = {"total": 1337}
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!status"))
    assert "1,337" in result.response


@pytest.mark.asyncio
async def test_model_opus_sets_override():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!model opus", user_id="user-1"))
    assert result.handled is True
    assert dispatcher.get_model_override("user-1") == "claude-opus-4-6"
    assert "claude-opus-4-6" in result.response


@pytest.mark.asyncio
async def test_model_alias_sonnet():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model sonnet", user_id="u2"))
    assert dispatcher.get_model_override("u2") == "claude-sonnet-4-6"


@pytest.mark.asyncio
async def test_model_auto_clears_override():
    dispatcher = CommandDispatcher(make_bot())
    # Set an override first
    await dispatcher.dispatch(make_inbound("!model opus", user_id="u3"))
    assert dispatcher.get_model_override("u3") == "claude-opus-4-6"
    # Now clear it
    result = await dispatcher.dispatch(make_inbound("!model auto", user_id="u3"))
    assert result.handled is True
    assert dispatcher.get_model_override("u3") is None
    assert "auto" in result.response.lower() or "reset" in result.response.lower()


@pytest.mark.asyncio
async def test_model_no_args_clears_override():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model opus", user_id="u4"))
    result = await dispatcher.dispatch(make_inbound("!model", user_id="u4"))
    assert result.handled is True
    assert dispatcher.get_model_override("u4") is None


@pytest.mark.asyncio
async def test_model_unknown_name_stored_as_is():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model my-custom-model-v2", user_id="u5"))
    assert dispatcher.get_model_override("u5") == "my-custom-model-v2"


@pytest.mark.asyncio
async def test_recap_returns_string():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!recap"))
    assert result.handled is True
    assert isinstance(result.response, str)
    assert len(result.response) > 0


@pytest.mark.asyncio
async def test_recap_with_number():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!recap 25"))
    assert result.handled is True
    assert "25" in result.response


@pytest.mark.asyncio
async def test_recap_clamps_to_50():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!recap 999"))
    assert result.handled is True
    assert "50" in result.response


@pytest.mark.asyncio
async def test_recap_clamps_minimum_to_1():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!recap 0"))
    assert result.handled is True
    assert "1" in result.response


@pytest.mark.asyncio
async def test_non_command_returns_not_handled():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("Hello, how are you?"))
    assert result.handled is False
    assert result.response is None


@pytest.mark.asyncio
async def test_unknown_command_returns_not_handled():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!unknown"))
    assert result.handled is False


@pytest.mark.asyncio
async def test_get_model_override_returns_none_for_unknown_user():
    dispatcher = CommandDispatcher(make_bot())
    assert dispatcher.get_model_override("no-such-user") is None


@pytest.mark.asyncio
async def test_overrides_are_per_user():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model opus", user_id="alice"))
    await dispatcher.dispatch(make_inbound("!model flash", user_id="bob"))
    assert dispatcher.get_model_override("alice") == "claude-opus-4-6"
    assert dispatcher.get_model_override("bob") == "gemini-2.0-flash"


# ── BotMemory ingest filter tests ───────────────────────────────────────────

def make_memory(tmp_path):
    """Create a BotMemory with mocked MemorySystem to avoid real disk I/O."""
    import antarisbot.core.memory as mem_module
    original_available = mem_module._MEMORY_AVAILABLE
    original_system = mem_module.MemorySystem

    # Patch at module level for this test
    mock_store = MagicMock()
    mock_store.search.return_value = []
    mock_store.stats.return_value = {"total": 0}

    mem_module._MEMORY_AVAILABLE = True
    mem_module.MemorySystem = MagicMock(return_value=mock_store)

    memory = BotMemory(store_path=str(tmp_path / "mem"), search_limit=10, min_relevance=0.3)

    # Restore
    mem_module._MEMORY_AVAILABLE = original_available
    mem_module.MemorySystem = original_system

    return memory, mock_store


def test_ingest_filter_skips_context_packet_header(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("## Context Packet\n\nSome content here") is True


def test_ingest_filter_skips_relevant_context_header(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("### Relevant Context\n1. some result") is True


def test_ingest_filter_skips_packet_built_line(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("Some text *Packet built 2026-03-11 at 11:00") is True


def test_ingest_filter_skips_queued_messages_marker(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("[Queued messages while agent was busy]") is True


def test_ingest_filter_skips_context_packet_xml(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("<ContextPacket>...</ContextPacket>") is True


def test_ingest_filter_skips_system_message(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("[System Message]") is True


def test_ingest_filter_skips_short_messages(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("hi") is True
    assert memory._should_skip_ingest("ok") is True
    assert memory._should_skip_ingest("") is True


def test_ingest_filter_skips_empty_and_whitespace(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("   ") is True
    assert memory._should_skip_ingest("\n\n\t") is True


def test_ingest_filter_skips_punctuation_only(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("...!!!???") is True


def test_ingest_filter_allows_normal_message(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("Hello, how are you today?") is False
    assert memory._should_skip_ingest("What is the weather like in San Francisco?") is False


def test_ingest_filter_allows_longer_message(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    # Exactly 20 chars — boundary (len >= 20 is OK)
    assert memory._should_skip_ingest("This is twenty chars") is False


def test_ingest_filter_blocks_19_chars(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    # 19 chars — should be filtered
    assert memory._should_skip_ingest("This is nineteen ch") is True


# ── !gather command tests ───────────────────────────────────────────────────

def make_bot_with_gather():
    """Build a mock Bot with Discord channel and gather support."""
    from unittest.mock import MagicMock, AsyncMock
    from antarisbot.channels.discord import DiscordAdapter

    bot = MagicMock()
    bot.memory.stats.return_value = {"total": 0}
    bot.config.model = "claude-sonnet-4-6"
    bot.config.provider_name = "anthropic"
    bot.config.guard_mode = "monitor"
    bot.config.security_mode = "sandboxed"
    bot.config.discord_open_channels = ["111", "222"]
    bot.dispatcher.providers = {}
    bot.router = None

    # Fake DiscordAdapter with a mock _client
    adapter = MagicMock(spec=DiscordAdapter)
    adapter._client = MagicMock()
    bot._channels = [adapter]

    return bot, adapter


@pytest.mark.asyncio
async def test_gather_defaults_to_12h():
    """!gather with no args defaults to 12 hours."""
    bot, adapter = make_bot_with_gather()
    dispatcher = CommandDispatcher(bot)

    with patch("antarisbot.core.gather.gather_and_ingest", new=AsyncMock(return_value={
        "channels_synced": 2,
        "total_messages": 60,
        "errors": [],
    })) as mock_gather:
        result = await dispatcher.dispatch(make_inbound("!gather"))
        assert result.handled is True
        assert result.response is not None
        # Verify hours=12 was passed
        mock_gather.assert_awaited_once()
        call_kwargs = mock_gather.call_args
        assert call_kwargs.kwargs.get("hours", call_kwargs.args[3] if len(call_kwargs.args) > 3 else 12) == 12 or \
               "12" in str(mock_gather.call_args)


@pytest.mark.asyncio
async def test_gather_with_6_hours():
    """!gather 6 passes 6 hours."""
    bot, adapter = make_bot_with_gather()
    dispatcher = CommandDispatcher(bot)

    with patch("antarisbot.core.gather.gather_and_ingest", new=AsyncMock(return_value={
        "channels_synced": 1,
        "total_messages": 18,
        "errors": [],
    })) as mock_gather:
        result = await dispatcher.dispatch(make_inbound("!gather 6"))
        assert result.handled is True
        mock_gather.assert_awaited_once()
        # Confirm hours=6 in call
        kwargs = mock_gather.call_args.kwargs
        assert kwargs.get("hours") == 6


@pytest.mark.asyncio
async def test_gather_invalid_hours_returns_error():
    """!gather 999 should return an error message listing valid hours."""
    bot, adapter = make_bot_with_gather()
    dispatcher = CommandDispatcher(bot)

    with patch("antarisbot.core.gather.gather_and_ingest", new=AsyncMock()) as mock_gather:
        result = await dispatcher.dispatch(make_inbound("!gather 999"))
        assert result.handled is True
        assert result.response is not None
        # Should mention invalid or valid hours - not call gather_and_ingest
        mock_gather.assert_not_awaited()
        assert "999" in result.response or "valid" in result.response.lower() or "invalid" in result.response.lower()


@pytest.mark.asyncio
async def test_gather_no_discord_client_returns_error():
    """!gather without a Discord channel returns informative error."""
    bot = MagicMock()
    bot.config.discord_open_channels = ["111"]
    bot._channels = []  # no channels
    bot.dispatcher.providers = {}
    bot.router = None

    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!gather"))
    assert result.handled is True
    assert "discord" in result.response.lower() or "client" in result.response.lower()


@pytest.mark.asyncio
async def test_gather_no_open_channels_returns_error():
    """!gather with no open channels returns informative error."""
    from antarisbot.channels.discord import DiscordAdapter

    bot = MagicMock()
    bot.config.discord_open_channels = []  # empty
    adapter = MagicMock(spec=DiscordAdapter)
    adapter._client = MagicMock()
    bot._channels = [adapter]
    bot.dispatcher.providers = {}
    bot.router = None

    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!gather"))
    assert result.handled is True
    assert "channel" in result.response.lower()


@pytest.mark.asyncio
async def test_help_includes_gather():
    """!help output should mention !gather."""
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!help"))
    assert result.handled is True
    assert "!gather" in result.response
