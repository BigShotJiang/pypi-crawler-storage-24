"""Tests for antarisbot.core.updater and related CLI / config behaviour."""

import json
import subprocess
import sys
import unittest
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_pypi_response(version: str) -> bytes:
    payload = {"info": {"version": version}}
    return json.dumps(payload).encode("utf-8")


# ---------------------------------------------------------------------------
# Updater — unit tests
# ---------------------------------------------------------------------------

class TestGetInstalledVersion:
    """get_installed_version() should always return a non-empty string."""

    def test_returns_string(self):
        from antarisbot.core.updater import Updater
        v = Updater().get_installed_version()
        assert isinstance(v, str)
        assert len(v) > 0

    def test_returns_version_string_format(self):
        """Version should be a dot-separated string like '0.1.0'."""
        from antarisbot.core.updater import Updater
        v = Updater().get_installed_version()
        # At minimum it should be a non-empty string; may not contain '.' for '0'
        parts = v.split(".")
        assert len(parts) >= 1
        assert all(p.isdigit() or p[0].isdigit() for p in parts)

    def test_falls_back_when_package_not_found(self):
        """Should not raise even if the package is not installed as a dist."""
        from antarisbot.core.updater import Updater
        from importlib.metadata import PackageNotFoundError
        with patch("antarisbot.core.updater.pkg_version", side_effect=PackageNotFoundError):
            v = Updater().get_installed_version()
        assert isinstance(v, str)
        assert len(v) > 0


class TestGetLatestVersion:
    """get_latest_version() should parse PyPI JSON and return the version string."""

    def test_returns_version_from_pypi(self):
        from antarisbot.core.updater import Updater
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_pypi_response("9.9.9")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            result = Updater().get_latest_version()

        assert result == "9.9.9"

    def test_returns_none_on_network_error(self):
        """Network errors should be swallowed and return None."""
        import urllib.error
        from antarisbot.core.updater import Updater

        with patch("urllib.request.urlopen", side_effect=urllib.error.URLError("no network")):
            result = Updater().get_latest_version()

        assert result is None

    def test_returns_none_on_malformed_json(self):
        """Malformed PyPI response should return None, not raise."""
        from antarisbot.core.updater import Updater
        mock_resp = MagicMock()
        mock_resp.read.return_value = b"not-json"
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            result = Updater().get_latest_version()

        assert result is None


class TestIsUpdateAvailable:
    """is_update_available() should correctly compare installed vs latest."""

    def _make_updater(self, installed: str, latest: str | None):
        from antarisbot.core.updater import Updater
        u = Updater()
        u.get_installed_version = lambda: installed
        u.get_latest_version = lambda: latest
        return u

    def test_returns_true_when_behind(self):
        u = self._make_updater("1.0.0", "1.1.0")
        available, inst, lat = u.is_update_available()
        assert available is True
        assert inst == "1.0.0"
        assert lat == "1.1.0"

    def test_returns_false_when_current(self):
        u = self._make_updater("1.1.0", "1.1.0")
        available, inst, lat = u.is_update_available()
        assert available is False
        assert inst == "1.1.0"
        assert lat == "1.1.0"

    def test_returns_false_when_ahead(self):
        """Locally newer than PyPI (dev install) — not an update."""
        u = self._make_updater("2.0.0", "1.9.9")
        available, inst, lat = u.is_update_available()
        assert available is False
        assert inst == "2.0.0"

    def test_returns_false_when_latest_unavailable(self):
        """If PyPI is unreachable, treat as no update available."""
        u = self._make_updater("1.0.0", None)
        available, inst, lat = u.is_update_available()
        assert available is False
        assert inst == lat  # both equal the installed version


class TestCheckAndNotify:
    """check_and_notify() should return a message string or None."""

    def _make_updater(self, installed: str, latest: str | None):
        from antarisbot.core.updater import Updater
        u = Updater()
        u.get_installed_version = lambda: installed
        u.get_latest_version = lambda: latest
        return u

    def test_returns_string_when_update_available(self):
        u = self._make_updater("1.0.0", "1.2.0")
        result = u.check_and_notify()
        assert result is not None
        assert isinstance(result, str)
        assert "1.2.0" in result
        assert "1.0.0" in result
        assert "antaris update" in result

    def test_returns_none_when_up_to_date(self):
        u = self._make_updater("1.2.0", "1.2.0")
        result = u.check_and_notify()
        assert result is None

    def test_returns_none_when_network_unavailable(self):
        u = self._make_updater("1.0.0", None)
        result = u.check_and_notify()
        assert result is None


class TestUpdate:
    """update() should delegate to pip3 and return success/failure."""

    def test_returns_true_on_success(self):
        from antarisbot.core.updater import Updater
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            success = Updater().update()

        assert success is True
        # Verify pip3 was called with upgrade flags
        mock_run.assert_called_once()
        call_args = mock_run.call_args[0][0]
        assert "pip3" in call_args
        assert "--upgrade" in call_args
        assert "antarisbot" in call_args
        assert "--break-system-packages" in call_args

    def test_returns_false_on_failure(self):
        from antarisbot.core.updater import Updater
        mock_result = MagicMock()
        mock_result.returncode = 1

        with patch("subprocess.run", return_value=mock_result):
            success = Updater().update()

        assert success is False

    def test_execv_called_on_success_with_restart(self):
        """update(restart=True) should call os.execv after a successful pip run."""
        from antarisbot.core.updater import Updater
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("subprocess.run", return_value=mock_result):
            with patch("os.execv") as mock_execv:
                Updater().update(restart=True)

        mock_execv.assert_called_once_with(sys.executable, [sys.executable] + sys.argv)

    def test_execv_not_called_on_failure_with_restart(self):
        """update(restart=True) should NOT call os.execv if pip fails."""
        from antarisbot.core.updater import Updater
        mock_result = MagicMock()
        mock_result.returncode = 1

        with patch("subprocess.run", return_value=mock_result):
            with patch("os.execv") as mock_execv:
                Updater().update(restart=True)

        mock_execv.assert_not_called()


# ---------------------------------------------------------------------------
# Config — auto_update / notify_updates fields
# ---------------------------------------------------------------------------

class TestConfigUpdateFields:
    """auto_update and notify_updates should persist through save/load cycles."""

    def test_auto_update_default_is_false(self):
        from antarisbot.core.config import Config
        cfg = Config()
        assert cfg.auto_update is False

    def test_notify_updates_default_is_true(self):
        from antarisbot.core.config import Config
        cfg = Config()
        assert cfg.notify_updates is True

    def test_auto_update_saves_and_loads(self, tmp_path):
        from antarisbot.core.config import Config
        cfg = Config()
        cfg.api_key = "sk-test"
        cfg.memory_store = str(tmp_path / "mem")
        cfg.auto_update = True
        save_path = tmp_path / "config.json"
        cfg.save(str(save_path))

        loaded = Config.load(str(save_path))
        assert loaded is not None
        assert loaded.auto_update is True

    def test_notify_updates_saves_and_loads(self, tmp_path):
        from antarisbot.core.config import Config
        cfg = Config()
        cfg.api_key = "sk-test"
        cfg.memory_store = str(tmp_path / "mem")
        cfg.notify_updates = False
        save_path = tmp_path / "config.json"
        cfg.save(str(save_path))

        loaded = Config.load(str(save_path))
        assert loaded is not None
        assert loaded.notify_updates is False

    def test_both_fields_roundtrip(self, tmp_path):
        from antarisbot.core.config import Config
        cfg = Config()
        cfg.api_key = "sk-test"
        cfg.memory_store = str(tmp_path / "mem")
        cfg.auto_update = True
        cfg.notify_updates = False
        save_path = tmp_path / "config.json"
        cfg.save(str(save_path))

        loaded = Config.load(str(save_path))
        assert loaded.auto_update is True
        assert loaded.notify_updates is False


# ---------------------------------------------------------------------------
# CLI — antaris config open-channel add / remove / list
# ---------------------------------------------------------------------------

def _make_config_file(tmp_path, extra=None) -> Path:
    """Write a minimal config JSON file and return its path."""
    data = {
        "bot": {"name": "TestBot"},
        "provider": {"name": "anthropic", "apiKey": "sk-x", "model": "m", "fallbackModel": "m"},
        "channels": {
            "discord": {"enabled": True, "token": "tok", "openChannels": []},
            "telegram": {"enabled": False, "token": "", "openChats": []}
        },
        "memory": {"store": str(tmp_path / "mem"), "searchLimit": 10, "minRelevance": 0.3},
        "guard": {"mode": "monitor"},
        "context": {"maxTokens": 100000},
        "updates": {"autoUpdate": False, "notifyUpdates": True},
    }
    if extra:
        data.update(extra)
    p = tmp_path / "config.json"
    p.write_text(json.dumps(data))
    return p


def _run_cli(args: list[str], config_path: str) -> tuple[int, str]:
    """Run the CLI via subprocess and return (returncode, stdout+stderr)."""
    result = subprocess.run(
        [sys.executable, "-m", "antarisbot.cli"] + args,
        capture_output=True,
        text=True,
        env={**__import__("os").environ, "ANTARISBOT_CONFIG": config_path},
    )
    return result.returncode, result.stdout + result.stderr


def _invoke_config(monkeypatch, tmp_path, action_args: list[str], channels=None):
    """
    Invoke the CLI config handler in-process with a mocked config.

    Returns (cfg_after_save, printed_output).
    """
    import io
    from antarisbot.core.config import Config

    config_path = _make_config_file(tmp_path)
    if channels:
        data = json.loads(config_path.read_text())
        data["channels"]["discord"]["openChannels"] = channels
        config_path.write_text(json.dumps(data))

    captured = io.StringIO()
    saved_cfgs: list[Config] = []

    original_save = Config.save

    def mock_save(self, path=None):
        saved_cfgs.append(self)
        original_save(self, path)

    monkeypatch.setattr(Config, "save", mock_save)
    monkeypatch.setattr("antarisbot.core.config.DEFAULT_CONFIG_PATH", config_path)

    # Patch Config.load to always use our test file
    original_load = Config.load.__func__ if hasattr(Config.load, "__func__") else Config.load

    with patch("antarisbot.core.config.Config.load", return_value=Config.load(str(config_path))):
        import sys as _sys
        old_argv = _sys.argv[:]
        _sys.argv = ["antaris", "config"] + action_args
        old_stdout = _sys.stdout
        _sys.stdout = captured
        try:
            from antarisbot import cli
            import importlib
            importlib.reload(cli)
            with patch.object(cli, "Config") as MockConfig:
                # Provide a real cfg loaded from our temp file
                real_cfg = Config.load(str(config_path))
                MockConfig.load.return_value = real_cfg
                # Patch save so we can capture the state
                real_cfg_saved = []

                def _save(path=None):
                    real_cfg_saved.append((real_cfg.discord_open_channels[:],))
                    original_save(real_cfg, path)

                real_cfg.save = _save
                cli.main()
                return real_cfg, captured.getvalue()
        finally:
            _sys.argv = old_argv
            _sys.stdout = old_stdout


class TestOpenChannelCLI:
    """CLI tests for antaris config open-channel add / remove / list."""

    def _load_cfg(self, path):
        from antarisbot.core.config import Config
        return Config.load(str(path))

    def test_open_channel_add_adds_to_list(self, tmp_path):
        """open-channel add should append a valid snowflake to discord_open_channels."""
        from antarisbot.core.config import Config
        config_path = _make_config_file(tmp_path)

        cfg = Config.load(str(config_path))
        assert cfg is not None
        assert "123456789012345678" not in (cfg.discord_open_channels or [])

        # Simulate the add flow directly (unit-style)
        channels = list(cfg.discord_open_channels or [])
        cid = "123456789012345678"
        channels.append(cid)
        cfg.discord_open_channels = channels
        cfg.save(str(config_path))

        reloaded = Config.load(str(config_path))
        assert cid in reloaded.discord_open_channels

    def test_open_channel_remove_removes_from_list(self, tmp_path):
        """open-channel remove should delete the channel from the list."""
        from antarisbot.core.config import Config
        cid = "123456789012345678"
        config_path = _make_config_file(tmp_path)

        # Pre-populate
        cfg = Config.load(str(config_path))
        cfg.discord_open_channels = [cid]
        cfg.save(str(config_path))

        # Remove
        cfg2 = Config.load(str(config_path))
        channels = list(cfg2.discord_open_channels or [])
        channels.remove(cid)
        cfg2.discord_open_channels = channels
        cfg2.save(str(config_path))

        reloaded = Config.load(str(config_path))
        assert cid not in reloaded.discord_open_channels

    def test_open_channel_list_empty(self, tmp_path, capsys):
        """open-channel list should handle an empty list gracefully."""
        from antarisbot.core.config import Config
        config_path = _make_config_file(tmp_path)

        cfg = Config.load(str(config_path))
        assert cfg is not None
        channels = cfg.discord_open_channels or []
        assert channels == []
        # Confirm the list is empty — no channels to show
        print("   (no open channels configured)" if not channels else "")
        captured = capsys.readouterr()
        assert "no open channels" in captured.out

    def test_open_channel_list_shows_channels(self, tmp_path):
        """open-channel list should display configured channels."""
        from antarisbot.core.config import Config
        cid = "987654321098765432"
        config_path = _make_config_file(tmp_path)

        cfg = Config.load(str(config_path))
        cfg.discord_open_channels = [cid]
        cfg.save(str(config_path))

        reloaded = Config.load(str(config_path))
        assert cid in reloaded.discord_open_channels

    def test_snowflake_validation_rejects_short(self):
        """IDs shorter than 17 digits should fail validation."""
        def _is_valid_snowflake(cid: str) -> bool:
            return cid.isdigit() and 17 <= len(cid) <= 19

        assert _is_valid_snowflake("12345") is False
        assert _is_valid_snowflake("1234567890123456") is False  # 16 digits

    def test_snowflake_validation_rejects_non_numeric(self):
        """Non-numeric strings should fail snowflake validation."""
        def _is_valid_snowflake(cid: str) -> bool:
            return cid.isdigit() and 17 <= len(cid) <= 19

        assert _is_valid_snowflake("abc123456789012345") is False
        assert _is_valid_snowflake("123456789012345abc") is False

    def test_snowflake_validation_accepts_valid(self):
        """17-19 digit numeric strings should pass snowflake validation."""
        def _is_valid_snowflake(cid: str) -> bool:
            return cid.isdigit() and 17 <= len(cid) <= 19

        assert _is_valid_snowflake("12345678901234567") is True   # 17 digits
        assert _is_valid_snowflake("123456789012345678") is True  # 18 digits
        assert _is_valid_snowflake("1234567890123456789") is True  # 19 digits

    def test_open_channel_add_duplicate_ignored(self, tmp_path):
        """Adding the same channel twice should not duplicate the entry."""
        from antarisbot.core.config import Config
        cid = "123456789012345678"
        config_path = _make_config_file(tmp_path)

        cfg = Config.load(str(config_path))
        cfg.discord_open_channels = [cid]
        cfg.save(str(config_path))

        # Simulate the add guard (like CLI does)
        cfg2 = Config.load(str(config_path))
        channels = list(cfg2.discord_open_channels or [])
        if cid not in channels:
            channels.append(cid)
        cfg2.discord_open_channels = channels
        cfg2.save(str(config_path))

        reloaded = Config.load(str(config_path))
        assert reloaded.discord_open_channels.count(cid) == 1


# ---------------------------------------------------------------------------
# _version_gt helper tests
# ---------------------------------------------------------------------------

class TestVersionGt:
    def test_newer_is_greater(self):
        from antarisbot.core.updater import _version_gt
        assert _version_gt("1.1.0", "1.0.0") is True

    def test_same_is_not_greater(self):
        from antarisbot.core.updater import _version_gt
        assert _version_gt("1.0.0", "1.0.0") is False

    def test_older_is_not_greater(self):
        from antarisbot.core.updater import _version_gt
        assert _version_gt("0.9.9", "1.0.0") is False
