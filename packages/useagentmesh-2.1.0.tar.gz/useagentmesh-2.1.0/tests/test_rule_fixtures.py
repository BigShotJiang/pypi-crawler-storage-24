"""Auto-discovers rule fixtures and validates scanner accuracy.

For each rule in tests/fixtures/rules/<RULE-ID>/:
  - vulnerable.py MUST trigger the rule
  - safe.py must NOT trigger the rule
"""
import json
import pytest
from pathlib import Path
from agentmesh.cli.scanner import run_scan

FIXTURES_DIR = Path(__file__).parent / "fixtures" / "rules"


def discover_fixtures():
    if not FIXTURES_DIR.exists():
        return []
    results = []
    for rule_dir in sorted(FIXTURES_DIR.iterdir()):
        if not rule_dir.is_dir():
            continue
        meta_path = rule_dir / "rule.meta.json"
        vuln_path = rule_dir / "vulnerable.py"
        safe_path = rule_dir / "safe.py"
        if meta_path.exists() and vuln_path.exists() and safe_path.exists():
            meta = json.loads(meta_path.read_text())
            results.append((meta["id"], str(vuln_path), str(safe_path), meta))
    return results


_fixtures = discover_fixtures()


@pytest.mark.parametrize(
    "rule_id,vuln,safe,meta",
    _fixtures,
    ids=[f[0] for f in _fixtures],
)
def test_vulnerable_triggers_rule(rule_id, vuln, safe, meta):
    """Vulnerable fixture must trigger the expected rule."""
    parent = str(Path(vuln).parent)
    result = run_scan(parent)
    triggered_ids = [f.policy_id for f in result.findings]
    assert rule_id in triggered_ids, (
        f"{rule_id}: vulnerable.py did not trigger rule. "
        f"Triggered: {triggered_ids}"
    )


@pytest.mark.parametrize(
    "rule_id,vuln,safe,meta",
    _fixtures,
    ids=[f[0] for f in _fixtures],
)
def test_safe_does_not_trigger_rule(rule_id, vuln, safe, meta):
    """Safe fixture must NOT trigger the expected rule."""
    parent = str(Path(safe).parent)
    result = run_scan(parent)
    false_positives = [
        f.policy_id for f in result.findings if f.policy_id == rule_id
    ]
    assert not false_positives, (
        f"{rule_id}: safe.py incorrectly triggered rule"
    )
