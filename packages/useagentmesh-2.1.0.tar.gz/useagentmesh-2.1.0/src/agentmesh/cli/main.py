"""AgentMesh CLI — entry point."""

from __future__ import annotations

import click

from agentmesh import __version__


@click.group()
@click.version_option(version=__version__, prog_name="agentmesh")
def cli() -> None:
    """AgentMesh — The Trust Layer for AI Agents."""


# Register sub-commands (lazy imports keep startup fast)
def _register_commands() -> None:
    from agentmesh.cli.init_command import init
    from agentmesh.cli.scan_command import scan
    from agentmesh.cli.serve_command import serve
    from agentmesh.cli.status_command import status
    from agentmesh.cli.verify_command import verify
    from agentmesh.cli.push_command import push
    from agentmesh.cli.history_command import history
    from agentmesh.cli.diff_command import diff
    from agentmesh.cli.rollback_command import rollback
    from agentmesh.cli.fix_command import fix
    from agentmesh.cli.validate_command import validate
    from agentmesh.cli.simulate_command import simulate
    from agentmesh.cli.upgrade_command import upgrade
    from agentmesh.cli.templates_command import templates
    from agentmesh.cli.proxy_command import proxy

    cli.add_command(init)
    cli.add_command(scan)
    cli.add_command(serve)
    cli.add_command(status)
    cli.add_command(verify)
    cli.add_command(push)
    cli.add_command(history)
    cli.add_command(diff)
    cli.add_command(rollback)
    cli.add_command(fix)
    cli.add_command(validate)
    cli.add_command(simulate)
    cli.add_command(upgrade)
    cli.add_command(templates)
    cli.add_command(proxy)


_register_commands()

if __name__ == "__main__":
    cli()
