"""Cortex ingestion pipeline."""
