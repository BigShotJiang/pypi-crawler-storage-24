"""Cortex record types."""
