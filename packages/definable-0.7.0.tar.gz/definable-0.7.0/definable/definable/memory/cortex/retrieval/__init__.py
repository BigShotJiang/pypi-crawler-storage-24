"""Cortex retrieval engine."""
