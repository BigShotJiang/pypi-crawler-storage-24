"""QOP live browser streaming for Python/Selenium tests."""

import os
import json
import base64
import time
import threading
import io
from datetime import datetime
from typing import Optional

try:
    from selenium import webdriver
    from PIL import Image, ImageDraw, ImageFont
    from websocket import WebSocket, create_connection
    HAS_LIVE_VIEW_DEPS = True
except ImportError:
    HAS_LIVE_VIEW_DEPS = False


def _get_cross_platform_font(size: int):
    """Get a cross-platform font."""
    font_paths = [
        "arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/TTF/DejaVuSans.ttf",
        "/usr/share/fonts/dejavu-sans-fonts/DejaVuSans.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
    ]
    for font_path in font_paths:
        try:
            return ImageFont.truetype(font_path, size)
        except (OSError, IOError):
            continue
    return ImageFont.load_default()


class LiveStreamManager:
    """Manages live browser streaming via WebSocket (Python equivalent of CDPScreencastManager)."""

    def __init__(self, driver, run_id: str, ws_url: str = "ws://localhost:4000", test_case_execution_id: Optional[str] = None):
        if not HAS_LIVE_VIEW_DEPS:
            raise ImportError("Live view requires: pip install qop-pytest[live-view]")

        self.driver = driver
        self.run_id = run_id
        self.test_case_execution_id = test_case_execution_id or run_id

        if '/ws/' in ws_url:
            base = ws_url.split('/ws/')[0]
        else:
            base = ws_url.rstrip('/')

        self.ws_url = f"{base}/ws/browser-stream?runId={self.run_id}"
        if self.test_case_execution_id:
            self.ws_url += f"&testCaseExecutionId={self.test_case_execution_id}"

        self.ws: Optional[WebSocket] = None
        self.is_streaming = False
        self.stream_thread: Optional[threading.Thread] = None
        self.frame_count = 0
        self.capture_interval = 0.75

    def start_streaming(self) -> None:
        try:
            print(f"[QOP] Connecting to: {self.ws_url}")
            self.ws = create_connection(self.ws_url, timeout=5)

            if self.ws:
                self.is_streaming = True

                self.ws.send(json.dumps({
                    'type': 'stream_started',
                    'runId': self.run_id,
                    'testCaseExecutionId': self.test_case_execution_id,
                    'timestamp': datetime.now().isoformat(),
                }))

                self.stream_thread = threading.Thread(target=self._streaming_loop, daemon=True)
                self.stream_thread.start()
                print("[QOP] Live browser view started")

        except Exception as e:
            print(f"[QOP] Failed to start live view: {e}")

    def stop_streaming(self) -> None:
        if not self.is_streaming:
            return

        self.is_streaming = False

        if self.stream_thread:
            self.stream_thread.join(timeout=2)

        if self.ws and self.ws.connected:
            try:
                self.ws.send(json.dumps({
                    'type': 'stream_stopped',
                    'runId': self.run_id,
                    'testCaseExecutionId': self.test_case_execution_id,
                    'timestamp': datetime.now().isoformat(),
                }))
            except:
                pass

        if self.ws:
            self.ws.close()
            self.ws = None

        print(f"[QOP] Live view stopped. Frames: {self.frame_count}")

    def update_test_case_execution_id(self, test_id: str) -> None:
        self.test_case_execution_id = test_id

    def _streaming_loop(self) -> None:
        while self.is_streaming:
            try:
                self._capture_and_send_frame()
                time.sleep(self.capture_interval)
            except:
                pass

    def _capture_and_send_frame(self) -> None:
        try:
            self.frame_count += 1
            screenshot_bytes = self.driver.get_screenshot_as_png()

            try:
                current_url = self.driver.current_url
                page_title = self.driver.title
            except:
                current_url = ""
                page_title = ""

            final_bytes = self._add_url_bar(screenshot_bytes, current_url)
            base64_data = base64.b64encode(final_bytes).decode('utf-8')

            if self.ws and self.ws.connected:
                self.ws.send(json.dumps({
                    'type': 'screencast_frame',
                    'runId': self.run_id,
                    'testCaseExecutionId': self.test_case_execution_id,
                    'frameData': base64_data,
                    'timestamp': datetime.now().isoformat(),
                    'url': current_url,
                    'metadata': {
                        'isBrowserWithUrlBar': True,
                        'format': 'jpeg',
                        'pageTitle': page_title,
                    }
                }))

                if self.frame_count % 100 == 0:
                    print(f"[QOP] Sent frame #{self.frame_count}")

        except Exception as e:
            if self.frame_count % 50 == 0:
                print(f"[QOP] Frame error: {e}")

    def _add_url_bar(self, screenshot_bytes: bytes, url: str) -> bytes:
        try:
            img = Image.open(io.BytesIO(screenshot_bytes))
            url_bar_height = 40
            new_width = max(img.width, 800)
            new_height = img.height + url_bar_height

            new_img = Image.new('RGB', (new_width, new_height), color='#f1f3f4')
            draw = ImageDraw.Draw(new_img)

            draw.rectangle([(0, url_bar_height - 1), (new_width, url_bar_height)], fill='#dadce0')

            font_url = _get_cross_platform_font(14)
            font_small = _get_cross_platform_font(12)

            url_text = url if len(url) <= 80 else url[:77] + '...'
            draw.text((50, 14), url_text, fill='#202124', font=font_url)

            timestamp = datetime.now().strftime("%H:%M:%S")
            draw.text((new_width - 70, 14), timestamp, fill='#5f6368', font=font_small)

            new_img.paste(img, (0, url_bar_height))

            buffer = io.BytesIO()
            new_img.save(buffer, format='JPEG', quality=60)
            return buffer.getvalue()
        except:
            return screenshot_bytes


def create_live_stream_manager(driver, run_id: str, enable_live_view: bool = True, ws_url: str = "ws://localhost:4000", **kwargs) -> Optional[LiveStreamManager]:
    """Factory function to create a LiveStreamManager if enabled."""
    if not enable_live_view:
        return None

    if not HAS_LIVE_VIEW_DEPS:
        print("[QOP] Live view requires: pip install qop-pytest[live-view]")
        return None

    try:
        return LiveStreamManager(driver, run_id, ws_url)
    except Exception as e:
        print(f"[QOP] Failed to create live stream manager: {e}")
        return None
