# 🚀 SmartBVB
**Developed by [Mohammad Sadiq](https://www.linkedin.com/in/mohammad-sadiq-676bbb224)**

A fast, beautifully styled terminal application for viewing KLE Tech attendance and results natively from your command line!

## Installation

```bash
pip install smartbvb
```

**That's it!** The browser engine downloads automatically on first launch.

## Usage

Once installed, launch from anywhere:

```bash
smartbvb
```

### Features
- **Global `smartbvb` Command:** Run it from any directory on your computer.
- **Cross-Platform:** Works on Windows, macOS, and Linux.
- **Auto Browser Setup:** Chromium downloads automatically on first run.
- **Credential Caching:** First-time setup asks for your USN and DOB and caches it in `~/.smartbvb_config.json`.
- **Persistent Session Manager:** Uses a single browser session in the background.
- **Dynamic Site Status Check:** Validates server status during loading.

### What's New in v0.9.0
- ✅ Fixed Windows `NotImplementedError` crash
- ✅ Auto-downloads Chromium browser engine on first launch
- ✅ UTF-8 support for emojis on Windows terminals
- ✅ ANSI color support for Windows CMD/PowerShell
