import asyncio
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
import json
import re
import sys
import os
import subprocess
from pathlib import Path
from datetime import datetime
import questionary
from questionary import Choice

# ANSI Color codes
class Colors:
    ORANGE = '\033[38;5;208m'
    AMBER = '\033[38;5;214m'
    WHITE  = '\033[97m'
    GRAY   = '\033[90m'
    RED    = '\033[91m'
    GREEN  = '\033[38;5;46m'
    BOLD   = '\033[1m'
    END    = '\033[0m' # Critical errors only

CONFIG_FILE = Path.home() / ".smartbvb_config.json"

def load_config():
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except:
            return None
    return None

def save_config(usn, dob):
    with open(CONFIG_FILE, 'w') as f:
        json.dump({'usn': usn, 'dob': dob}, f)

def delete_config():
    if CONFIG_FILE.exists():
        try:
            CONFIG_FILE.unlink()
        except:
            pass

class KLEScraper:
    def __init__(self):
        self.base_url = "https://parents.kletech.ac.in/"
        self.usn = None
        self.dob = None
        self.student_name = None
        
        self.playwright = None
        self.browser = None
        self.page = None
        
    async def start_browser(self):
        self.playwright = await async_playwright().start()
        try:
            self.browser = await self.playwright.chromium.launch(
                headless=True,
                args=['--disable-blink-features=AutomationControlled', '--disable-sync']
            )
        except Exception as e:
            error_msg = str(e)
            if 'Executable doesn' in error_msg or 'executable' in error_msg.lower():
                print(f"\n{Colors.AMBER}⚡ First time setup: Downloading browser engine...{Colors.END}")
                print(f"{Colors.GRAY}   This only happens once. Please wait...{Colors.END}\n")
                try:
                    result = subprocess.run(
                        [sys.executable, '-m', 'playwright', 'install', 'chromium'],
                        capture_output=True,
                        text=True,
                        timeout=300
                    )
                    if result.returncode == 0:
                        print(f"{Colors.ORANGE}✓ Browser engine installed successfully!{Colors.END}\n")
                        # Retry launch after install
                        self.browser = await self.playwright.chromium.launch(
                            headless=True,
                            args=['--disable-blink-features=AutomationControlled', '--disable-sync']
                        )
                    else:
                        print(f"{Colors.RED}✗ Auto-install failed.{Colors.END}")
                        print(f"{Colors.AMBER}  Please run manually: {Colors.BOLD}playwright install chromium{Colors.END}\n")
                        await self.playwright.stop()
                        sys.exit(1)
                except subprocess.TimeoutExpired:
                    print(f"{Colors.RED}✗ Download timed out. Check your internet connection.{Colors.END}")
                    await self.playwright.stop()
                    sys.exit(1)
                except Exception:
                    print(f"{Colors.RED}✗ Auto-install failed.{Colors.END}")
                    print(f"{Colors.AMBER}  Please run manually: {Colors.BOLD}playwright install chromium{Colors.END}\n")
                    await self.playwright.stop()
                    sys.exit(1)
            else:
                raise
        self.page = await self.browser.new_page()

    async def close_browser(self):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()

    async def check_site_status(self):
        try:
            response = await self.page.goto(self.base_url, wait_until='load', timeout=5000)
            return response and response.status == 200
        except:
            return False

    async def login(self, usn, dob):
        try:
            await self.page.goto(self.base_url, wait_until='load', timeout=10000)
            
            parts = dob.split('-')
            day, month, year = parts[0], parts[1], parts[2]
            
            await asyncio.gather(
                self.page.fill('#username', usn),
                self.page.select_option('#dd', day),
                self.page.select_option('#mm', month),
            )
            await self.page.select_option('#yyyy', year)
            await self.page.click('.cn-landing-login1')
            
            await self.page.wait_for_function(
                'document.querySelector(".cn-pay-table") !== null',
                timeout=8000
            )
            
            self.usn = usn
            self.dob = dob
            
            html = await self.page.content()
            result = self._parse_attendance(html)
            self.student_name = result.get('name', 'Unknown')
            
            return True
        except Exception as e:
            return False

    async def fetch_attendance(self):
        try:
            await self.page.goto(self.base_url, wait_until='load', timeout=10000)
            
            html = await self.page.content()
            if "cn-pay-table" not in html:
                if not await self.login(self.usn, self.dob):
                    return {'error': 'Session expired. Please try again.'}
                html = await self.page.content()
                
            result = self._parse_attendance(html)
            self.student_name = result.get('name', 'Unknown')
            return result
        except Exception as e:
            return {'error': str(e)}

    async def fetch_results(self):
        try:
            history_url = f"{self.base_url}index.php?option=com_history&task=getResult&usn={self.usn}"
            await self.page.goto(history_url, wait_until='networkidle', timeout=10000)
            
            try:
                await self.page.wait_for_selector('.credits-sec1', timeout=5000)
            except:
                pass
            
            try:
                await self.page.wait_for_selector('.result-table', timeout=5000)
            except:
                pass
            
            await asyncio.sleep(1)
            
            html = await self.page.content()
            result = self._parse_results(html)
            return result
        except Exception as e:
            return {'error': str(e)}

    def _parse_attendance(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        try:
            student_name = soup.find('h3').get_text(strip=True) if soup.find('h3') else "Unknown"
            
            attendance_map = {}
            scripts = soup.find_all('script')
            
            script_count = 0
            for script in scripts:
                content = script.string
                if content and 'bb.generate' in content and 'columns' in content:
                    script_count += 1
                    if 'gauge' in content or script_count == 2:
                        regex = r'\["([A-Z0-9]+)",\s*(\d+)\]'
                        matches = re.findall(regex, content)
                        for code, percentage in matches:
                            attendance_map[code] = int(percentage)
                        break
            
            courses_list = []
            course_table = soup.find('table', {'class': 'cn-pay-table'})
            
            if course_table:
                for row in course_table.find_all('tr')[1:]:
                    cols = row.find_all('td')
                    if len(cols) >= 2:
                        code = cols[0].get_text(strip=True)
                        name = cols[1].get_text(strip=True)
                        attendance = attendance_map.get(code)
                        
                        if code and name and attendance is not None:
                            courses_list.append({
                                'code': code,
                                'name': name,
                                'attendance': attendance
                            })
            
            return {
                'usn': self.usn,
                'name': student_name,
                'courses': courses_list,
                'course_count': len(courses_list)
            }
        except Exception as e:
            return {'error': f'Parse error: {str(e)}'}

    def _parse_results(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        try:
            overall_stats = self._parse_overall_stats(soup)
            semesters = []
            result_tables = soup.find_all('div', class_='result-table')
            
            for table_div in result_tables:
                header = table_div.find('h6')
                if not header:
                    continue
                
                header_text = header.get_text(strip=True)
                sem_match = re.search(r'(.*?)\s*-\s*Semester', header_text)
                sgpa_match = re.search(r'SGPA:\s*([\d.]+)', header_text)
                credits_reg_match = re.search(r'Credits\s+Registered\s*:\s*([\d.]+)', header_text)
                credits_earned_match = re.search(r'Credits\s+Earned\s*:\s*([\d.]+)', header_text)
                
                semester_name = sem_match.group(1).strip() if sem_match else "Unknown"
                sgpa = float(sgpa_match.group(1)) if sgpa_match else 0
                credits_reg = credits_reg_match.group(1) if credits_reg_match else "0"
                credits_earned = credits_earned_match.group(1) if credits_earned_match else "0"
                
                courses = []
                table = table_div.find('table', class_='uk-table')
                if table:
                    for row in table.find_all('tr')[1:]:
                        cols = row.find_all('td')
                        if len(cols) >= 6:
                            course_code = cols[0].get_text(strip=True)
                            course_name = cols[1].get_text(strip=True)
                            credits_reg_course = cols[2].get_text(strip=True)
                            credits_earned_course = cols[3].get_text(strip=True)
                            gpa = cols[4].get_text(strip=True)
                            grade = cols[5].get_text(strip=True)
                            
                            courses.append({
                                'code': course_code,
                                'name': course_name,
                                'credits_reg': credits_reg_course,
                                'credits_earned': credits_earned_course,
                                'gpa': gpa,
                                'grade': grade
                            })
                
                semesters.append({
                    'semester': semester_name,
                    'sgpa': sgpa,
                    'credits_reg': credits_reg,
                    'credits_earned': credits_earned,
                    'courses': courses
                })
            
            return {
                'usn': self.usn,
                'overall_stats': overall_stats,
                'semesters': semesters
            }
        except Exception as e:
            return {'error': f'Parse error: {str(e)}'}

    def _parse_overall_stats(self, soup):
        try:
            stats = {'cgpa': 0, 'credits_earned': 0, 'credits_to_earn': 0}
            cards = soup.find_all('div', class_='credits-sec1')
            
            for card in cards:
                header = card.find('h3')
                value_p = card.find('p')
                
                if header and value_p:
                    header_text = ' '.join(header.get_text(strip=True).lower().split())
                    value_text = value_p.get_text(strip=True)
                    
                    value = re.search(r'[\d.]+', value_text)
                    if value:
                        value_num = float(value.group())
                        if 'earned' in header_text and 'so far' in header_text:
                            stats['credits_earned'] = value_num
                        elif 'to be earned' in header_text:
                            stats['credits_to_earn'] = value_num
                        elif 'cgpa' in header_text:
                            stats['cgpa'] = value_num
            
            if stats['credits_earned'] == 0 and stats['credits_to_earn'] == 0:
                all_text = soup.get_text()
                earned_match = re.search(r'Credits\s+Earned\s+So\s+Far\s*[\s\S]*?(\d+(?:\.\d+)?)', all_text)
                if earned_match: stats['credits_earned'] = float(earned_match.group(1))
                
                to_earn_match = re.search(r'Credits\s+to\s+be\s+Earned\s*[\s\S]*?(\d+(?:\.\d+)?)', all_text)
                if to_earn_match: stats['credits_to_earn'] = float(to_earn_match.group(1))
                
                cgpa_match = re.search(r'CGPA\s*[\s\S]*?(\d+(?:\.\d+)?)', all_text)
                if cgpa_match: stats['cgpa'] = float(cgpa_match.group(1))
            
            return stats
        except Exception as e:
            return {'cgpa': 0, 'credits_earned': 0, 'credits_to_earn': 0, 'error': str(e)}

def get_greeting():
    hour = datetime.now().hour
    if 5 <= hour < 12:
        return "☀️ Good Morning"
    elif 12 <= hour < 17:
        return "🌤️ Good Afternoon"
    else:
        # Evening/Night
        return "✨ Good Evening"

def print_header():
    print("\n" + "─" * 80)
    print(f"{Colors.BOLD}{Colors.ORANGE}┌──────────────────────────────────────────────────────────────────────────────┐{Colors.END}")
    print(f"{Colors.BOLD}{Colors.ORANGE}│                              🚀 {Colors.WHITE}SmartBVB v1.0.9{Colors.ORANGE}                               │{Colors.END}")
    print(f"{Colors.BOLD}{Colors.AMBER}│          UNOFFICIAL EDUCATIONAL TOOL - FAST ATTENDANCE & RESULTS             │{Colors.END}")
    print(f"{Colors.BOLD}{Colors.ORANGE}│                                                                              │{Colors.END}")
    print(f"{Colors.BOLD}{Colors.ORANGE}│                         Developed by: {Colors.WHITE}Mohammad Sadiq{Colors.ORANGE}                         │{Colors.END}")
    print(f"{Colors.BOLD}{Colors.ORANGE}│          🔗 \033]8;;https://www.linkedin.com/in/mohammad-sadiq-676bbb224\033\\{Colors.WHITE}https://www.linkedin.com/in/mohammad-sadiq-676bbb224\033]8;;\033\\{Colors.ORANGE}           │{Colors.END}")
    print(f"{Colors.BOLD}{Colors.ORANGE}└──────────────────────────────────────────────────────────────────────────────┘{Colors.END}")
    
    # Emerald Privacy Box
    print(f"{Colors.BOLD}{Colors.GREEN}       ┌──────────────────────────────────────────────────────────────┐{Colors.END}")
    print(f"{Colors.BOLD}{Colors.GREEN}       │      🔒 {Colors.WHITE}100% Local-First. No data leaves your device.{Colors.GREEN}       │{Colors.END}")
    print(f"{Colors.BOLD}{Colors.GREEN}       └──────────────────────────────────────────────────────────────┘{Colors.END}")
    
    print(f"{Colors.GRAY}  [!] Use ARROW KEYS to navigate. Built for speed.{Colors.END}")
    print("─" * 80)

def print_attendance(result):
    if 'error' in result:
        print(f"\n{Colors.RED}✗ Error: {result['error']}{Colors.END}\n")
        return
    if not result.get('courses'):
        print(f"\n{Colors.RED}✗ No attendance data found{Colors.END}\n")
        return
    
    print(f"\n{Colors.BOLD}{Colors.ORANGE}📋 Attendance Report Overview{Colors.END}\n")
    
    max_name_len = 50
    print(f"{Colors.BOLD}{'CODE':<15} {'COURSE NAME':<{max_name_len}} {'ATT'}{Colors.END}")
    print("-" * 80)
    
    low_count = 0
    for course in result['courses']:
        code = course['code']
        name = course['name'][:max_name_len]
        att = course['attendance']
        
        if att < 75:
            color = Colors.RED + Colors.BOLD
            low_count += 1
        elif att < 85:
            color = Colors.AMBER
        else:
            color = Colors.ORANGE
        
        print(f"{code:<15} {name:<{max_name_len}} {color}{att:>3}%{Colors.END}")
    
    print("-" * 80)
    print(f"{Colors.BOLD}Total Courses: {result['course_count']}{Colors.END}")
    
    if low_count > 0:
        print(f"\n{Colors.AMBER}💡 Pro-Tip: You have {low_count} course(s) slightly below 75%.{Colors.END}")
        print(f"{Colors.GRAY}Focus on attending these classes to keep your streak! Don't miss it!{Colors.END}\n")
    else:
        print(f"\n{Colors.ORANGE}✨ Excellent! All subjects are in the safe zone! Keep it up! ✨{Colors.END}\n")

def print_results(result):
    if 'error' in result:
        print(f"\n{Colors.RED}✗ Error: {result['error']}{Colors.END}\n")
        return
    
    overall_stats = result.get('overall_stats', {})
    semesters = result.get('semesters', [])
    
    if not semesters:
        print(f"\n{Colors.RED}✗ No results found{Colors.END}\n")
        return
    
    print(f"\n{Colors.BOLD}{Colors.ORANGE}✓ Cumulative Academic History{Colors.END}")
    print(f"USN: {Colors.ORANGE}{result['usn']}{Colors.END}\n")
    
    print(f"{Colors.BOLD}{Colors.AMBER}━━━━ OVERALL STATISTICS ━━━━{Colors.END}")
    print(f"  {Colors.BOLD}CGPA:{Colors.END} {Colors.ORANGE}{overall_stats.get('cgpa', 0)}{Colors.END}")
    print(f"  {Colors.BOLD}Credits Earned So Far:{Colors.END} {Colors.ORANGE}{overall_stats.get('credits_earned', 0)}{Colors.END}")
    print(f"  {Colors.BOLD}Credits to be Earned:{Colors.END} {Colors.AMBER}{overall_stats.get('credits_to_earn', 0)}{Colors.END}")
    print(f"{Colors.AMBER}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.END}\n")
    
    for sem in semesters:
        print(f"\n{Colors.BOLD}{Colors.ORANGE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.END}")
        print(f"{Colors.BOLD}{Colors.AMBER}{sem['semester']}{Colors.END}")
        print(f"{Colors.BOLD}SGPA: {Colors.ORANGE}{sem['sgpa']}{Colors.END} | {Colors.BOLD}Credits Reg: {Colors.ORANGE}{sem['credits_reg']}{Colors.END} | {Colors.BOLD}Credits Earned: {Colors.ORANGE}{sem['credits_earned']}{Colors.END}")
        print(f"{Colors.ORANGE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.END}")
        
        courses = sem['courses']
        if not courses:
            print(f"{Colors.GRAY}No courses found for this semester{Colors.END}\n")
            continue
        
        print(f"{'CODE':<12} {'COURSE NAME':<35} {'C.R':<5} {'C.E':<5} {'GPA':<5} {'Grade':<8}")
        print("-" * 80)
        
        for course in courses:
            code = course['code']
            name = course['name'][:33]
            cred_reg = course['credits_reg']
            cred_earned = course['credits_earned']
            gpa = course['gpa']
            grade = course['grade']
            
            grade_color = Colors.ORANGE if grade == 'S' else (Colors.ORANGE if grade in ['A', 'B'] else (Colors.AMBER if grade == 'C' else (Colors.RED if grade == 'D' else Colors.GRAY)))
            print(f"{code:<12} {name:<35} {cred_reg:<5} {cred_earned:<5} {gpa:<5} {grade_color}{grade}{Colors.END}")
        print()

async def async_main():
    print_header()
    
    config = load_config()
    if not config:
        print(f"\n{Colors.BOLD}{Colors.ORANGE}🚀 SmartBVB Registration{Colors.END}")
        usn = input(f"[?] USN: ").strip().upper()
        
        # Shared style for all menus
        menu_style = questionary.Style([
            ('pointer', f'fg:#ffa500 bold'),
            ('highlighted', f'fg:#ffa500 bold'),
            ('selected', f'fg:#ffcc00'),
        ])
        
        day = await questionary.select(
            "Select Birthday - Day:",
            choices=[str(i).zfill(2) for i in range(1, 32)],
            style=menu_style
        ).ask_async()
        
        month = await questionary.select(
            "Select Birthday - Month:",
            choices=[
                Choice("01 (January)", "01"), Choice("02 (February)", "02"),
                Choice("03 (March)", "03"), Choice("04 (April)", "04"),
                Choice("05 (May)", "05"), Choice("06 (June)", "06"),
                Choice("07 (July)", "07"), Choice("08 (August)", "08"),
                Choice("09 (September)", "09"), Choice("10 (October)", "10"),
                Choice("11 (November)", "11"), Choice("12 (December)", "12")
            ],
            style=menu_style
        ).ask_async()
        
        year = await questionary.select(
            "Select Birthday - Year:",
            choices=[str(i) for i in range(2000, 2013)],
            style=menu_style
        ).ask_async()
        
        dob = f"{day}-{month}-{year}"
        
        save_config(usn, dob)
        config = {'usn': usn, 'dob': dob}
        print(f"{Colors.ORANGE}✓ Profile ready! You can now just type 'smartbvb' anytime to log in. Enjoy!{Colors.END}\n")

    scraper = KLEScraper()
    scraper.usn = config['usn']
    scraper.dob = config['dob']
    
    await scraper.start_browser()
    
    site_up = False
    logged_in = False
    
    async def check_and_login():
        nonlocal site_up, logged_in
        for attempt in range(2):
            try:
                response = await scraper.page.goto(scraper.base_url, wait_until='load', timeout=15000)
                if response and response.status == 200:
                    site_up = True
                    if await scraper.login(scraper.usn, scraper.dob):
                        logged_in = True
                        break
                await asyncio.sleep(1)
            except:
                site_up = False

    status_task = asyncio.create_task(check_and_login())
    
    chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    i = 0
    while not status_task.done():
        sys.stdout.write(f"\r{Colors.ORANGE}{chars[i % len(chars)]}{Colors.END}")
        sys.stdout.flush()
        await asyncio.sleep(0.1)
        i += 1
    sys.stdout.write("\r" + " " * 40 + "\r")
    
    if not site_up:
        print(f"{Colors.RED}{Colors.WHITE} ⚠️  PORTAL BUSY {Colors.END}")
        print(f"{Colors.AMBER}Institutional servers are busy. Retrying from menu...{Colors.END}")
    elif not logged_in:
        print(f"{Colors.RED}✗ Login failed! USN or DOB might be incorrect.{Colors.END}")
        delete_config()
        await scraper.close_browser()
        return

    while True:
        if site_up and logged_in:
            greeting = get_greeting()
            name = scraper.student_name.split()[0].title() if scraper.student_name else "Student"
            print(f"\n{Colors.BOLD}{Colors.ORANGE}{greeting}, {name}!{Colors.END}")
            
            action = await questionary.select(
                "How can I help you today?",
                choices=[
                    "📊  Show My Attendance",
                    "📝  Show My Results",
                    "🔐  Logout & Reset Data",
                    "❌  Exit SmartBVB"
                ],
                style=questionary.Style([
                    ('pointer', 'fg:#ff8700 bold'),
                    ('highlighted', 'fg:#ff8700 bold'),
                    ('selected', 'fg:#ffaf00'),
                ])
            ).ask_async()
            
            if not action: break

            if "Attendance" in action:
                print(f"\n{Colors.GRAY}[*] Fetching {Colors.WHITE}Attendance{Colors.GRAY}...{Colors.END}")
                result = await scraper.fetch_attendance()
                print_attendance(result)
            elif "Results" in action:
                print(f"\n{Colors.GRAY}[*] Fetching {Colors.WHITE}Results{Colors.GRAY}...{Colors.END}")
                result = await scraper.fetch_results()
                print_results(result)
            elif "Logout" in action:
                delete_config()
                print(f"\n{Colors.ORANGE}✓ Profile reset successfully.{Colors.END}")
                break
            else:
                print(f"\n{Colors.ORANGE}🚀 SmartBVB: See you soon!{Colors.END}\n")
                break
        else:
            action = await questionary.select(
                "Portal Offline:",
                choices=[
                    "🔄  Retry Connection",
                    "🔐  Logout & Reset Data",
                    "❌  Exit SmartBVB"
                ],
                style=questionary.Style([
                    ('pointer', 'fg:#ff8700 bold'),
                    ('highlighted', 'fg:#ff8700 bold'),
                ])
            ).ask_async()
            
            if not action: break

            if "Retry" in action:
                print(f"\n{Colors.GRAY}[*] Re-establishing link...{Colors.END}")
                if await scraper.login(scraper.usn, scraper.dob):
                    site_up = True
                    logged_in = True
                else:
                    print(f"{Colors.RED}Site still unreachable.{Colors.END}")
            elif "Logout" in action:
                delete_config()
                break
            else:
                break
        
    await scraper.close_browser()

def run():
    # Windows-specific fixes
    if sys.platform == 'win32':
        # Force UTF-8 encoding so emojis & box-drawing chars don't crash
        if hasattr(sys.stdout, 'reconfigure'):
            try:
                sys.stdout.reconfigure(encoding='utf-8')
                sys.stderr.reconfigure(encoding='utf-8')
            except Exception:
                pass

        # Enable ANSI escape codes on Windows 10+ CMD/PowerShell
        try:
            os.system('color')
        except Exception:
            pass

        # DO NOT set WindowsSelectorEventLoopPolicy!
        # Playwright needs ProactorEventLoop (default since Python 3.8)
        # to launch browser subprocesses on Windows.

    try:
        asyncio.run(async_main())
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}SmartBVB Terminated{Colors.END}\n")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.RED}✗ Error: {e}{Colors.END}")
        sys.exit(1)

if __name__ == "__main__":
    run()
