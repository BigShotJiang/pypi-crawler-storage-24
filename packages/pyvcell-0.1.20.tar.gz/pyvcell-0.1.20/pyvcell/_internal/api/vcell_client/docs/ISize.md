# ISize

## Properties

| Name  | Type    | Description | Notes      |
| ----- | ------- | ----------- | ---------- |
| **x** | **int** |             | [optional] |
| **y** | **int** |             | [optional] |
| **z** | **int** |             | [optional] |

## Example

```python
from pyvcell._internal.api.vcell_client.models.i_size import ISize

# TODO update the JSON string below
json = "{}"
# create an instance of ISize from a JSON string
i_size_instance = ISize.from_json(json)
# print the JSON string representation of the object
print(ISize.to_json())

# convert the object into a dict
i_size_dict = i_size_instance.to_dict()
# create an instance of ISize from a dict
i_size_from_dict = ISize.from_dict(i_size_dict)
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
