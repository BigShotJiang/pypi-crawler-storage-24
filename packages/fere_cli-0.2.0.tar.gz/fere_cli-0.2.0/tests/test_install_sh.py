import os
import platform
import stat
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent  # tests/
CLI_DIR = HERE.parent  # cli/
INSTALL_SH = CLI_DIR / "install.sh"
if not INSTALL_SH.exists():
    import pytest

    pytest.skip(
        f"install.sh not found at {INSTALL_SH}", allow_module_level=True
    )


def _make_executable(path: Path, content: str) -> None:
    path.write_text(content)
    mode = path.stat().st_mode
    path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def test_install_fails_without_python(tmp_path: Path) -> None:
    """Installer should fail when no Python is available."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)

    # Symlink essential system utilities but NOT python
    skip = {"python", "python3", "python3.11", "python3.12", "python3.13"}
    for sysdir in ["/usr/bin", "/bin"]:
        p = Path(sysdir)
        if p.is_dir():
            for entry in p.iterdir():
                if (
                    entry.name not in skip
                    and not entry.name.startswith("python")
                    and not (bin_dir / entry.name).exists()
                ):
                    try:
                        (bin_dir / entry.name).symlink_to(entry)
                    except OSError:
                        pass

    env = os.environ.copy()
    env["PATH"] = str(bin_dir)
    env["HOME"] = str(home_dir)

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    assert result.returncode != 0
    out = result.stdout + result.stderr
    assert "Python 3.10+" in out


def test_install_prints_path_guidance_when_fere_missing(tmp_path: Path) -> None:
    """Installer should print PATH guidance when fere is not on PATH."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)
    # Create .local/bin so detect_user_bin finds it via getuserbase
    local_bin = home_dir / ".local" / "bin"
    local_bin.mkdir(parents=True)

    fake_python = bin_dir / "python3"
    _make_executable(
        fake_python,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then\n'
        '  echo "Python 3.11.0"\n'
        "  exit 0\n"
        'elif [ "$1" = "-c" ]; then\n'
        '  case "$2" in\n'
        '    *version_info*) echo "3.11" ;;\n'
        '    *getuserbase*)  printf "%s" "$HOME/.local" ;;\n'
        '    *) echo "3.11" ;;\n'
        "  esac\n"
        "  exit 0\n"
        'elif [ "$1" = "-m" ]; then\n'
        "  exit 0\n"  # simulate successful pip/site invocations
        "fi\n"
        "exit 0\n",
    )

    fake_pipx = bin_dir / "pipx"
    _make_executable(
        fake_pipx,
        "#!/bin/sh\n"
        'if [ "$1" = "ensurepath" ]; then exit 0; fi\n'
        "exit 1\n",
    )

    # Stub brew to prevent real package manager invocations on macOS
    fake_brew = bin_dir / "brew"
    _make_executable(fake_brew, "#!/bin/sh\nexit 1\n")

    env = os.environ.copy()
    env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
    env["HOME"] = str(home_dir)
    env["SHELL"] = "/bin/bash"

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out = result.stdout + result.stderr
    # Installer exits 0 (install succeeded) but warns fere isn't on PATH
    assert result.returncode == 0
    assert "Installation complete, but 'fere' is not in PATH." in out
    # Verify specific PATH guidance (not the generic fallback)
    assert "export PATH=" in out
    expected_rc = (
        ".bash_profile" if platform.system() == "Darwin" else ".bashrc"
    )
    assert expected_rc in out


def test_invalid_version_argument(tmp_path: Path) -> None:
    """Installer should reject invalid version arguments."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)

    env = os.environ.copy()
    env["PATH"] = str(bin_dir)
    env["HOME"] = str(tmp_path / "home")

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH), "not-a-version"],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    assert result.returncode != 0
    out = result.stdout + result.stderr
    assert "Usage:" in out


def test_explicit_version_in_pkg_spec(tmp_path: Path) -> None:
    """Passing X.Y.Z should produce fere-cli==X.Y.Z in output."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)
    local_bin = home_dir / ".local" / "bin"
    local_bin.mkdir(parents=True)

    fake_python = bin_dir / "python3"
    _make_executable(
        fake_python,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then\n'
        '  echo "Python 3.11.0"\n'
        "  exit 0\n"
        'elif [ "$1" = "-c" ]; then\n'
        '  case "$2" in\n'
        '    *version_info*) echo "3.11" ;;\n'
        '    *getuserbase*)  printf "%s" "$HOME/.local" ;;\n'
        '    *) echo "3.11" ;;\n'
        "  esac\n"
        "  exit 0\n"
        'elif [ "$1" = "-m" ]; then\n'
        "  exit 0\n"
        "fi\n"
        "exit 0\n",
    )

    fake_pipx = bin_dir / "pipx"
    _make_executable(
        fake_pipx,
        "#!/bin/sh\n"
        'if [ "$1" = "ensurepath" ]; then exit 0; fi\n'
        "exit 1\n",
    )

    fake_brew = bin_dir / "brew"
    _make_executable(fake_brew, "#!/bin/sh\nexit 1\n")

    env = os.environ.copy()
    env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
    env["HOME"] = str(home_dir)
    env["SHELL"] = "/bin/bash"

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH), "1.2.3"],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out = result.stdout + result.stderr
    assert (
        result.returncode == 0
    ), f"Installer exited {result.returncode}:\n{out}"
    assert "fere-cli==1.2.3" in out


def test_install_succeeds_with_pipx(tmp_path: Path) -> None:
    """Primary pipx install path should succeed end-to-end."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)

    fake_python = bin_dir / "python3"
    _make_executable(
        fake_python,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then\n'
        '  echo "Python 3.11.0"\n'
        "  exit 0\n"
        'elif [ "$1" = "-c" ]; then\n'
        '  case "$2" in\n'
        '    *version_info*) echo "3.11" ;;\n'
        '    *getuserbase*)  printf "%s" "$HOME/.local" ;;\n'
        '    *) echo "3.11" ;;\n'
        "  esac\n"
        "  exit 0\n"
        'elif [ "$1" = "-m" ]; then\n'
        "  exit 0\n"
        "fi\n"
        "exit 0\n",
    )

    # Key difference: fake_pipx exits 0 for install (happy path)
    fake_pipx = bin_dir / "pipx"
    _make_executable(
        fake_pipx,
        "#!/bin/sh\n"
        'if [ "$1" = "install" ]; then exit 0; fi\n'
        'if [ "$1" = "ensurepath" ]; then exit 0; fi\n'
        "exit 1\n",
    )

    # Provide a fake fere binary so post-install check succeeds
    fake_fere = bin_dir / "fere"
    _make_executable(
        fake_fere,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then echo "fere 0.1.0"; fi\n'
        "exit 0\n",
    )

    fake_brew = bin_dir / "brew"
    _make_executable(fake_brew, "#!/bin/sh\nexit 1\n")

    env = os.environ.copy()
    env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
    env["HOME"] = str(home_dir)
    env["SHELL"] = "/bin/bash"

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out = result.stdout + result.stderr
    assert (
        result.returncode == 0
    ), f"Installer exited {result.returncode}:\n{out}"
    assert "Installed fere-cli using: pipx" in out
    assert "FereAI CLI installed successfully!" in out
    assert "falling back to pip" not in out


def test_freshly_installed_pipx_is_found(tmp_path: Path) -> None:
    """After install_pipx, the installer should resolve pipx in user base."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)
    local_bin = home_dir / ".local" / "bin"
    local_bin.mkdir(parents=True)

    fake_python = bin_dir / "python3"
    _make_executable(
        fake_python,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then\n'
        '  echo "Python 3.11.0"\n'
        "  exit 0\n"
        'elif [ "$1" = "-c" ]; then\n'
        '  case "$2" in\n'
        '    *version_info*) echo "3.11" ;;\n'
        '    *getuserbase*)  printf "%s" "$HOME/.local" ;;\n'
        '    *site*) printf "%s" "$HOME/.local" ;;\n'
        '    *) echo "3.11" ;;\n'
        "  esac\n"
        "  exit 0\n"
        'elif [ "$1" = "-m" ]; then\n'
        "  exit 0\n"
        "fi\n"
        "exit 0\n",
    )

    # No pipx on initial PATH — simulates fresh install scenario.
    # Place pipx in ~/.local/bin (where pip --user puts it)
    # so the installer's PATH resolution finds it after install_pipx.
    fake_pipx = local_bin / "pipx"
    _make_executable(
        fake_pipx,
        "#!/bin/sh\n"
        'if [ "$1" = "install" ]; then exit 0; fi\n'
        'if [ "$1" = "ensurepath" ]; then exit 0; fi\n'
        "exit 1\n",
    )

    fake_fere = local_bin / "fere"
    _make_executable(
        fake_fere,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then echo "fere 0.1.0"; fi\n'
        "exit 0\n",
    )

    fake_brew = bin_dir / "brew"
    _make_executable(fake_brew, "#!/bin/sh\nexit 1\n")

    env = os.environ.copy()
    # Only bin_dir on PATH — no local_bin, so pipx not initially found
    env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
    env["HOME"] = str(home_dir)
    env["SHELL"] = "/bin/bash"

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out = result.stdout + result.stderr
    assert (
        result.returncode == 0
    ), f"Installer exited {result.returncode}:\n{out}"
    assert "Installed fere-cli using: pipx" in out
    assert "falling back to pip" not in out


def test_latest_channel_passes_pre_flag(tmp_path: Path) -> None:
    """Passing 'latest' should include --pre in the install invocation."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)
    local_bin = home_dir / ".local" / "bin"
    local_bin.mkdir(parents=True)

    fake_python = bin_dir / "python3"
    _make_executable(
        fake_python,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then\n'
        '  echo "Python 3.11.0"\n'
        "  exit 0\n"
        'elif [ "$1" = "-c" ]; then\n'
        '  case "$2" in\n'
        '    *version_info*) echo "3.11" ;;\n'
        '    *getuserbase*)  printf "%s" "$HOME/.local" ;;\n'
        '    *) echo "3.11" ;;\n'
        "  esac\n"
        "  exit 0\n"
        'elif [ "$1" = "-m" ]; then\n'
        "  exit 0\n"
        "fi\n"
        "exit 0\n",
    )

    # pipx that logs its args so we can verify --pip-args=--pre
    fake_pipx = bin_dir / "pipx"
    _make_executable(
        fake_pipx,
        "#!/bin/sh\n"
        'echo "pipx $*"\n'
        'if [ "$1" = "install" ]; then exit 0; fi\n'
        'if [ "$1" = "ensurepath" ]; then exit 0; fi\n'
        "exit 1\n",
    )

    fake_fere = bin_dir / "fere"
    _make_executable(
        fake_fere,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then echo "fere 0.2.0-pre"; fi\n'
        "exit 0\n",
    )

    fake_brew = bin_dir / "brew"
    _make_executable(fake_brew, "#!/bin/sh\nexit 1\n")

    env = os.environ.copy()
    env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
    env["HOME"] = str(home_dir)
    env["SHELL"] = "/bin/bash"

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH), "latest"],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out = result.stdout + result.stderr
    assert (
        result.returncode == 0
    ), f"Installer exited {result.returncode}:\n{out}"
    assert "--pip-args=--pre" in out


def test_pip_fallback_when_pipx_unavailable(tmp_path: Path) -> None:
    """Freshly-installed pipx not found on PATH falls back to pip."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)
    local_bin = home_dir / ".local" / "bin"
    local_bin.mkdir(parents=True)

    fake_python = bin_dir / "python3"
    _make_executable(
        fake_python,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then\n'
        '  echo "Python 3.11.0"\n'
        "  exit 0\n"
        'elif [ "$1" = "-c" ]; then\n'
        '  case "$2" in\n'
        '    *version_info*) echo "3.11" ;;\n'
        '    *getuserbase*)  printf "%s" "$HOME/.local" ;;\n'
        '    *) echo "3.11" ;;\n'
        "  esac\n"
        "  exit 0\n"
        'elif [ "$1" = "-m" ]; then\n'
        "  exit 0\n"
        "fi\n"
        "exit 0\n",
    )

    # No pipx binary on PATH — install_with_pipx returns 1;
    # install_pipx succeeds (fake python -m exits 0) but the
    # freshly-installed pipx binary is not found at
    # _user_base/bin/pipx, so the inner else falls back to pip.
    fake_brew = bin_dir / "brew"
    _make_executable(fake_brew, "#!/bin/sh\nexit 1\n")

    env = os.environ.copy()
    env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
    env["HOME"] = str(home_dir)
    env["SHELL"] = "/bin/bash"

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out = result.stdout + result.stderr
    assert (
        result.returncode == 0
    ), f"Installer exited {result.returncode}:\n{out}"
    assert "falling back to pip" in out
    assert "Installed fere-cli using: pip" in out


def test_pip_fallback_when_install_pipx_fails(tmp_path: Path) -> None:
    """install_pipx returns 1 → else branch falls back to pip."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)
    local_bin = home_dir / ".local" / "bin"
    local_bin.mkdir(parents=True)

    # Python that fails on -m for pipx/ensurepip
    fake_python = bin_dir / "python3"
    _make_executable(
        fake_python,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then\n'
        '  echo "Python 3.11.0"\n'
        "  exit 0\n"
        'elif [ "$1" = "-c" ]; then\n'
        '  case "$2" in\n'
        '    *version_info*) echo "3.11" ;;\n'
        '    *getuserbase*)  printf "%s" "$HOME/.local" ;;\n'
        '    *) echo "3.11" ;;\n'
        "  esac\n"
        "  exit 0\n"
        'elif [ "$1" = "-m" ]; then\n'
        '  case "$2" in\n'
        "    pip)\n"
        '      case "$3" in\n'
        "        install)\n"
        "          # fail pipx install, allow fere-cli\n"
        '          case "$*" in\n'
        "            *pipx*) exit 1 ;;\n"
        "            *) exit 0 ;;\n"
        "          esac ;;\n"
        "        *) exit 0 ;;\n"
        "      esac ;;\n"
        "    ensurepip) exit 1 ;;\n"
        "    *) exit 0 ;;\n"
        "  esac\n"
        "fi\n"
        "exit 0\n",
    )

    # No pipx on PATH, brew fails — install_pipx will return 1
    fake_brew = bin_dir / "brew"
    _make_executable(fake_brew, "#!/bin/sh\nexit 1\n")

    env = os.environ.copy()
    env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
    env["HOME"] = str(home_dir)
    env["SHELL"] = "/bin/bash"

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH)],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out = result.stdout + result.stderr
    assert (
        result.returncode == 0
    ), f"Installer exited {result.returncode}:\n{out}"
    assert "falling back to pip" in out
    assert "Installed fere-cli using: pip" in out


def test_latest_channel_pip_fallback(tmp_path: Path) -> None:
    """Latest channel via pip fallback should pass --pre flag."""
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir(parents=True)
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True)
    local_bin = home_dir / ".local" / "bin"
    local_bin.mkdir(parents=True)

    # Python that logs pip args so we can verify --pre
    fake_python = bin_dir / "python3"
    _make_executable(
        fake_python,
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then\n'
        '  echo "Python 3.11.0"\n'
        "  exit 0\n"
        'elif [ "$1" = "-c" ]; then\n'
        '  case "$2" in\n'
        '    *version_info*) echo "3.11" ;;\n'
        '    *getuserbase*)  printf "%s" "$HOME/.local" ;;\n'
        '    *) echo "3.11" ;;\n'
        "  esac\n"
        "  exit 0\n"
        'elif [ "$1" = "-m" ]; then\n'
        "  shift\n"
        '  echo "python -m $*"\n'
        "  exit 0\n"
        "fi\n"
        "exit 0\n",
    )

    # No pipx — forces pip fallback
    fake_brew = bin_dir / "brew"
    _make_executable(fake_brew, "#!/bin/sh\nexit 1\n")

    env = os.environ.copy()
    env["PATH"] = f"{bin_dir}{os.pathsep}{env.get('PATH', '')}"
    env["HOME"] = str(home_dir)
    env["SHELL"] = "/bin/bash"

    result = subprocess.run(
        ["/bin/sh", str(INSTALL_SH), "latest"],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out = result.stdout + result.stderr
    assert (
        result.returncode == 0
    ), f"Installer exited {result.returncode}:\n{out}"
    assert "falling back to pip" in out
    assert "--pre" in out
