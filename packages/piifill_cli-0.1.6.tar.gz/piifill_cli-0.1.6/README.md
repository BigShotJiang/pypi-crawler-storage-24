<div align="center">

# PIIFILL CLI v0.1.6

**The Automated, Enterprise-Grade, Strictly Offline PII Sanitization Tool**

[![PyPI version](https://badge.fury.io/py/piifill-cli.svg)](https://badge.fury.io/py/piifill-cli)
[![Python versions](https://img.shields.io/pypi/pyversions/piifill-cli.svg)](https://pypi.org/project/piifill-cli/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

*Built with ❤️ by [Bhavin Sachaniya](https://bhavinsachaniya.in)*

</div>

---

## 🛡️ Total Privacy Meets Hyper-Speed Processing

**PIIFILL** is a high-performance terminal utility meticulously engineered for identifying, analyzing, and masking Personally Identifiable Information (PII) entirely on your local machine.

In a regulatory environment emphasizing data sovereignty (GDPR, HIPAA, CCPA), sending sensitive data to cloud APIs is a massive security liability. PIIFILL solves this by keeping all processing—including Deep Learning OCR—**100% Offline**.

## ⚡ Key Features

- **Privacy-First Architecture**: Zero cloud dependencies. Your data never leaves your environment.
- **Universal Format Parsing**: Natively scans and redacts TXT, PDF, DOCX, PNG, JPG, JSON, JSONL, CSV, XLSX, and SQL files.
- **Enterprise-Grade Analysis**: Detects over 50+ diverse global PII entities (SSN, Aadhaar, Credit Cards, MAC Addresses, etc.).
- **Parallel Processing Engine**: Dynamic core utilization for lightning-fast sanitization of massive data lakes.
- **Visual Terminal UI**: Beautiful, interactive command-line interface featuring rich status reports.

---

## 🚀 Quick Start Guide

### 1. Installation

Install the latest optimized version directly from PyPI:

```bash
pip install piifill-cli==0.1.6
```

### 2. Discover Vulnerabilities (`scan`)

Perform a non-destructive audit of a single file, or recursively traverse an entire directory to locate sensitive data.

```bash
# Scan a specific invoice
piifill scan ./documents/invoice.pdf

# Deep recursive scan of an entire data dump
piifill scan ./data_dump/ --recursive
```

### 3. Sanitize and Protect (`mask`)

Safely redact detected PII. You can overwrite the file or specifically output the sanitized version to a designated secure directory.

```bash
# Mask a single image
piifill mask ./private/id_card.png

# Enterprise Sanitization Pipeline
piifill mask ./docs/ -o ./sanitized_docs/ --mode redact
```

---

## 🛠 Advanced Command Reference

### `piifill scan`
Execute discovery protocols without modifying assets.
- `piifill scan <path>`: Direct audit of a specific file.
- `--recursive`: Enables deep directory traversal.

### `piifill mask`
Execute sanitization protocols to generate compliant datasets.
- `piifill mask <path>`: In-place or localized masking.
- `-o <output_path>, --output <output_path>`: Route sanitized files to a secure destination.
- `--mode <strategy>`: Define the sanitization strategy (e.g., `mask`, `redact`).
- `--local`: Rapid deployment scanning the current working directory.

### `piifill version`
Verify your CLI environment.
```bash
piifill version
# Output: piifill-cli version 0.1.6
```

---

## 📊 Enterprise Security Analysis

Every sanitization run delivers a comprehensive security debrief:
- **Security Grading**: A-F scale calculating exposure risk prior to sanitization.
- **Risk Scoring**: 0-100 technical metric quantifying data protection.
- **Categorical Breakdown**: Granular reporting on exactly what entities were identified (e.g., 4 SSNs, 12 Emails).

---

## 👨‍💻 About the Author

**Bhavin Sachaniya**  
*Lead Developer & Security Enthusiast*

Discover more of my enterprise tools, cybersecurity insights, and professional projects at my portfolio:  
🌐 **[bhavinsachaniya.in](https://bhavinsachaniya.in)**

---

## 📜 License

This project is licensed under the MIT License - see the `LICENSE` file for details.
