import json
import os
import sys
from pathlib import Path
from functools import lru_cache
from typing import Dict, Any, List, Union, Optional
from loguru import logger
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

# --- Initialization ---
console = Console()

# --- Configuration & Logging ---
def setup_logger(log_file: str = "piifill.log", level: str = "INFO"):
    logger.remove()
    logger.add(sys.stderr, level=level, format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>")
    if log_file:
        logger.add(log_file, level=level, format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}", rotation="10 MB")
    return logger

# --- Translation / Localization ---
class Translator:
    _instance = None
    _current_lang = "en"
    _locales: Dict[str, Dict[str, str]] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Translator, cls).__new__(cls)
        return cls._instance

    def set_language(self, lang: str):
        self._current_lang = lang
        self._load_locale(lang)
        if lang != "en":
            self._load_locale("en")

    def _load_locale(self, lang: str):
        if lang in self._locales:
            return
            
        # Robust path discovery for installed packages
        try:
            from importlib import resources
            # This is the modern way to get package data
            locale_path_ctx = resources.files("piifill.shared").joinpath("locales", f"{lang}.json")
            if locale_path_ctx.exists():
                with locale_path_ctx.open("r", encoding="utf-8") as f:
                    self._locales[lang] = json.load(f)
                return
        except Exception as e:
            logger.debug(f"Modern resource loading failed: {e}")

        # Fallback to file-system paths
        base_dir = Path(__file__).parent
        locale_path = base_dir / "locales" / f"{lang}.json"
        
        if locale_path.exists():
            try:
                with open(locale_path, "r", encoding="utf-8") as f:
                    self._locales[lang] = json.load(f)
            except Exception:
                self._locales[lang] = {}
        else:
            self._locales[lang] = {}

    def t(self, key: str, **kwargs) -> str:
        text = self._locales.get(self._current_lang, {}).get(key)
        if text is None:
            text = self._locales.get("en", {}).get(key, key)
        try:
            return text.format(**kwargs)
        except Exception:
            return text

translator = Translator()
t = translator.t

# --- Branding & UI Components ---
BANNER_BASE = r"""
[bold cyan]
  _____  _____ _____ ______ _____ _      _      
 |  __ \|_   _|_   _|  ____|_   _| |    | |     
 | |__) | | |   | | | |__    | | | |    | |     
 |  ___/  | |   | | |  __|   | | | |    | |     
 | |     _| |_ _| |_| |     _| |_| |____| |____ 
 |_|    |_____|_____|_|    |_____|______|______|
[/bold cyan]
[bold white] Automated Enterprise-Grade Local PII Sanitization CLI [/bold white]
[dim white] -------------------------------------------------- [/dim white]
[cyan] Built with ❤️ by [/cyan][bold underline magenta link=https://bhavinsachaniya.in]Bhavin Sachaniya[/bold underline magenta link]
[dim white] -------------------------------------------------- [/dim white]
"""

THEME = {
    "prompt": "cyan",
    "success": "green",
    "warning": "yellow",
    "error": "red",
    "accent": "bold magenta",
    "dim": "dim white",
}

def get_banner():
    return BANNER_BASE

def print_banner():
    console.print(get_banner())

def print_step(msg: str, indent: bool = False):
    symbol = "[dim cyan]⎿[/dim cyan]" if indent else "[bold cyan]>[/bold cyan]"
    console.print(f"{symbol} {msg}")

def print_status(msg: str, status: str = "success"):
    color = THEME.get(status, "white")
    console.print(f"[{color}]●[/{color}] {msg}")

def print_error(msg: str):
    console.print(f"[bold red]{t('error_prefix')}[/bold red] {msg}")

def print_success(msg: str):
    console.print(f"[bold green]{t('success_prefix')}[/bold green] {msg}")

def print_warning(msg: str):
    console.print(f"[bold yellow]{t('warning_prefix')}[/bold yellow] {msg}")

def format_detection_table(entities: List[Dict]) -> Table:
    table = Table(title=t("det_table_title"), box=None, header_style="bold cyan")
    table.add_column(t("report_type"), style="cyan", no_wrap=True)
    table.add_column(t("report_count"), style="magenta", justify="right")
    counts = {}
    for ent in entities:
        type_name = ent.get("entity_type", "UNKNOWN")
        counts[type_name] = counts.get(type_name, 0) + 1
    for type_name, count in counts.items():
        table.add_row(type_name, str(count))
    return table

def format_detection_table_from_breakdown(breakdown: Dict[str, int]) -> Table:
    table = Table(title=t("det_table_title"), box=None, header_style="bold cyan")
    table.add_column(t("report_type"), style="cyan", no_wrap=True)
    table.add_column(t("report_count"), style="magenta", justify="right")
    for type_name, count in breakdown.items():
        table.add_row(type_name, str(count))
    return table

# --- Validation Helpers ---
def validate_asset(path: Union[str, Path], supported_extensions: List[str]) -> bool:
    p = Path(path)
    if not p.exists():
        logger.error(f"Asset not found: {p}")
        print_error(t("error_path_not_found", path=str(p)))
        return False
    if p.is_file():
        ext = p.suffix.lower().replace('.', '')
        if ext not in supported_extensions:
            logger.error(f"Unsupported format: .{ext}")
            print_error(f"Unsupported format: .{ext}")
            return False
    return True
