from typing import List, Any, Optional
import re

from .parsers import IParser
from ..engine.manager import FiltrationManager
from ..engine.filtration import PIIEntity

# Global reader instance for reuse after lazy initialization
_OCR_READER: Any = None

def get_ocr_reader():
    """Lazy initialization of EasyOCR reader."""
    global _OCR_READER
    if _OCR_READER is None:
        import easyocr
        # verbose=False suppresses informative messages about CPU/GPU and models
        _OCR_READER = easyocr.Reader(['en'], gpu=False, verbose=False)
    return _OCR_READER

class ImageParser(IParser):
    """
    Parser for images (PNG, JPG) using EasyOCR for robust visual redaction.
    """
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        import cv2
        import numpy as np
        
        nparr = np.frombuffer(content, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # Optimization: Downscale massive images for faster OCR
        h, w = img.shape[:2]
        max_dim = 1600
        scale = 1.0
        if max(h, w) > max_dim:
            scale = max_dim / max(h, w)
            img = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)

        # Basic preprocessing for better OCR
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        reader = get_ocr_reader()
        results = reader.readtext(gray)
        pii_count = 0
        
        for bbox, text, conf in results:
            if not text.strip():
                continue
            
            x_min = int(min(pt[0] for pt in bbox))
            y_min = int(min(pt[1] for pt in bbox))
            x_max = int(max(pt[0] for pt in bbox))
            y_max = int(max(pt[1] for pt in bbox))
            w = max(1, x_max - x_min)
            text_len = max(1, len(text))
            char_w = w / text_len
            
            val_x_min = x_min
            text_to_scan = text
            
            label_match = re.search(r'^[a-zA-Z\s]+:', text)
            if label_match:
                label_end = label_match.end()
                text_to_scan = text[label_end:]
                val_x_min = x_min + int(label_end * char_w)
            
            local_entities = engine.detect(text_to_scan)
            
            # --- Fallbacks for OCR Quirks ---
            if not local_entities:
                if "@" in text_to_scan and "." in text_to_scan:
                     email_match = engine.detector.registry.get_all_patterns()["EMAIL"].search(text_to_scan)
                     if email_match:
                         local_entities = [PIIEntity(value=email_match.group(), entity_type="EMAIL", start=email_match.start(), end=email_match.end())]
                elif label_match:
                    label_str = text[:label_end].upper()
                    text_clean = text_to_scan.strip()
                    
                    if "PAN" in label_str:
                        pan_match = re.search(r'[A-Za-z0-9]{5}[\s\-]*[A-Za-z0-9]{4}[\s\-]*[A-Za-z0-9]', text_clean)
                        if pan_match:
                            local_entities = [PIIEntity(value=pan_match.group(), entity_type="PAN_IN", start=text_to_scan.find(pan_match.group()), end=text_to_scan.find(pan_match.group()) + len(pan_match.group()))]
                    elif "AADHAAR" in label_str or "ADHAR" in label_str:
                        aadhaar_match = re.search(r'[2-9](?:[\s\-]*\d){11}', text_clean)
                        if aadhaar_match:
                            local_entities = [PIIEntity(value=aadhaar_match.group(), entity_type="AADHAAR", start=text_to_scan.find(aadhaar_match.group()), end=text_to_scan.find(aadhaar_match.group()) + len(aadhaar_match.group()))]
                    elif "PHONE" in label_str or "MOB" in label_str:
                        phone_match = re.search(r'(?:\+?91[\s\-]?)?\d(?:[\s\-]*\d){9}', text_clean)
                        if phone_match:
                            local_entities = [PIIEntity(value=phone_match.group(), entity_type="PHONE_IN", start=text_to_scan.find(phone_match.group()), end=text_to_scan.find(phone_match.group()) + len(phone_match.group()))]

            if not local_entities:
                continue

            for ent in local_entities:
                if mode.upper() == "MASK":
                    masked_val = engine.masker.apply_masking(ent.value, ent.entity_type)
                elif mode.upper() == "TOKENIZE":
                    masked_val = engine.masker.get_token(ent.value, ent.entity_type)
                else: 
                    masked_val = "[REDACTED]"
                
                pii_count += 1
                
                c_start = int(val_x_min + ent.start * char_w)
                c_end = int(val_x_min + ent.end * char_w)
                cv2.rectangle(img, (c_start, y_min), (c_end, y_max), (0, 0, 0), -1)
                
                if mode.upper() in ["MASK", "TOKENIZE"]:
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    font_scale = (y_max - y_min) / 35.0
                    thickness = max(1, int(font_scale * 2))
                    text_size = cv2.getTextSize(masked_val, font, font_scale, thickness)[0]
                    
                    text_x = c_start + (c_end - c_start - text_size[0]) // 2
                    text_y = y_min + (y_max - y_min + text_size[1]) // 2
                    
                    cv2.putText(img, masked_val, (max(c_start, text_x), text_y), font, font_scale, (255, 255, 255), thickness)

        engine.last_detection_count += pii_count
        
        _, buffer = cv2.imencode('.png', img)
        return buffer.tobytes()
