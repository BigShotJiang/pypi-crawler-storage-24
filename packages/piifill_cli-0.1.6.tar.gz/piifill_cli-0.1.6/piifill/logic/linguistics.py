import re
from typing import Dict, List, Optional

class LanguageService:
    """
    Lightweight, heuristic-based language detection service.
    Avoids heavy dependencies like langdetect while providing basic support for 
    EN, DE, ES, FR, HI, etc.
    """
    
    # Common stop words/function words for detection
    _STOP_WORDS = {
        "en": {"the", "and", "is", "in", "it", "you", "that", "was", "for", "on", "are", "with", "as", "be", "at"},
        "de": {"der", "die", "das", "und", "ist", "in", "den", "von", "zu", "mit", "sich", "auf", "für", "eine", "einer", "hier", "über", "dem"},
        "es": {"el", "la", "de", "que", "en", "y", "los", "se", "del", "las", "un", "para", "con", "no", "por"},
        "fr": {"le", "la", "les", "et", "un", "une", "dans", "pour", "est", "des", "se", "en", "au", "par", "ce"},
        "hi": {"के", "है", "में", "और", "से", "हैं", "का", "को", "पर", "हो", "कि", "जो", "कर", "गया", "था"},
    }

    def detect_language(self, text: str) -> str:
        """
        Detects the language of the given text based on stop word frequency.
        Returns the ISO code (e.g., 'en', 'de'). Defaults to 'en'.
        """
        if not text or not text.strip():
            return "en"

        # Tokenize and lowercase (basic approach)
        tokens = re.findall(r'\b\w+\b', text.lower())
        if not tokens:
            return "en"

        counts = {lang: 0 for lang in self._STOP_WORDS}
        
        for token in tokens:
            for lang, words in self._STOP_WORDS.items():
                if token in words:
                    counts[lang] += 1

        # Find the language with the highest count
        best_lang = max(counts, key=counts.get)
        
        # If no clear winner (all 0), default to 'en'
        if counts[best_lang] == 0:
            return "en"
            
        return best_lang

# Global singleton
language_service = LanguageService()
