import re
from typing import Dict, List, Pattern, Optional, Set
from pydantic import BaseModel

class PIIEntity(BaseModel):
    value: str
    entity_type: str
    start: int
    end: int

class PatternRegistry:
    """
    Registry for managing PII patterns across different categories and countries.
    Optimized for memory and lookup speed.
    """
    def __init__(self):
        self._patterns: Dict[str, Dict[str, Pattern]] = {
            "GLOBAL": {},    # Multi-country patterns (Email, IP, etc.)
            "AMERICAS": {},  # North/South America
            "EMEA": {},      # Europe, Middle East, Africa
            "APAC": {},      # Asia Pacific
        }
        self._compiled_cache: Optional[Dict[str, Pattern]] = None

    def register(self, category: str, type_name: str, pattern: str, flags: int = 0):
        """Registers a new PII pattern in a specific category."""
        if category not in self._patterns:
            self._patterns[category] = {}
        # Ensure we don't accidentally use re.IGNORECASE for critical identifiers
        self._patterns[category][type_name] = re.compile(pattern, flags)
        self._compiled_cache = None # Invalidate cache

    def get_all_patterns(self) -> Dict[str, Pattern]:
        """Returns a flattened dictionary of all registered patterns."""
        if self._compiled_cache is not None:
            return self._compiled_cache
        
        all_pats = {}
        for cat_pats in self._patterns.values():
            all_pats.update(cat_pats)
        self._compiled_cache = all_pats
        return all_pats

class PIIDetector:
    """
    Professional-grade PII detection engine using a modular PatternRegistry.
    Adheres to PIIFILL high-performance and type-safety standards.
    """
    
    # Mapping of common language codes to their primary regions
    _LANG_REGION_MAP = {
        "en": ["GLOBAL", "AMERICAS", "EMEA", "APAC"], # English is global
        "de": ["GLOBAL", "EMEA"],
        "es": ["GLOBAL", "EMEA", "AMERICAS"],
        "fr": ["GLOBAL", "EMEA", "AMERICAS"],
        "hi": ["GLOBAL", "APAC"],
        "pt": ["GLOBAL", "AMERICAS", "EMEA"],
        "zh": ["GLOBAL", "APAC"],
        "ja": ["GLOBAL", "APAC"],
    }
    
    def __init__(self):
        self.registry = PatternRegistry()
        self._initialize_core_patterns()

    def _initialize_core_patterns(self):
        g = "GLOBAL"
        ign = re.IGNORECASE

        # --- FINANCIAL & BANKING ---
        self.registry.register(g, "ACCOUNT_NUMBER", r'(?<!\d)\d{8,18}(?!\d)')
        self.registry.register(g, "BANK_ACCOUNT_US", r'(?<!\d)\d{6,12}(?!\d)')
        self.registry.register(g, "BANK_ACCOUNT_IN", r'(?<!\d)\d{9,18}(?!\d)')
        self.registry.register(g, "IBAN", r'\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b')
        self.registry.register(g, "BANK_ACCOUNT_BR", r'\b\d{3,5}-?\d\s?\d{3,5}-?\d\b')
        self.registry.register(g, "BANK_ACCOUNT_CA", r'\b\d{5}-\d{3}-\d{5,12}\b')
        self.registry.register(g, "BANK_ACCOUNT_CN", r'(?<!\d)6\d{15,18}(?!\d)')
        self.registry.register(g, "BANK_ACCOUNT_UK", r'\b\d{2}-\d{2}-\d{2}\s?\d{6,8}\b')
        self.registry.register(g, "CREDIT_CARD", r'(?<!\d)(?:4\d{3}|5[1-5]\d{2}|6(?:011|5\d{2})|3[47]\d{2}|9(?:\d{15}|\d{18}))(?:[\s-]?\d{4}){3}[\s-]?\d{3,4}(?!\d)')
        self.registry.register(g, "CREDIT_CARD_AMEX", r'(?<!\d)3[47]\d{2}[- ]?\d{6}[- ]?\d{5}(?!\d)')
        self.registry.register(g, "CREDIT_CARD_TOKEN", r'\b[0-9a-f]{28,64}\b')
        self.registry.register(g, "LOYALTY_CARD", r'(?<!\d)\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{3,4}(?!\d)')
        self.registry.register(g, "TRANSACTION_ID", r'\bTXN-[A-Z]{3}-\d{8}-\d{4,10}\b')
        self.registry.register(g, "TRANSACTION_ID_SEPA", r'\bSEPA-\d{4}-\d{2}-\d{6,10}\b')
        self.registry.register(g, "TRANSACTION_ID_GENERIC", r'\bTRX-[A-Z]{3}-\d{8}-\d{4,10}\b')
        self.registry.register(g, "ROUTING_NUMBER", r'(?<!\d)\d{9}(?!\d)')
        self.registry.register(g, "UPI_ID", r'\b[\w._\-]{3,50}@[a-z]{3,20}\b', ign)
        self.registry.register(g, "CRYPTO_BTC", r'\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b')
        self.registry.register(g, "CRYPTO_ETH", r'\b0x[0-9a-fA-F]{40}\b')

        # --- GOVERNMENT IDENTIFIERS ---
        self.registry.register(g, "AADHAAR", r'(?<!\d)[2-9]\d{3}[ -]?\d{4}[ -]?\d{4}(?!\d)')
        self.registry.register(g, "SSN_US", r'(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)')
        self.registry.register(g, "NATIONAL_ID_US", r'(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)')
        self.registry.register(g, "PAN_IN", r'\b[A-Za-z]{5}[\s\-]*[0-9OIl]{4}[\s\-]*[A-Za-z]\b', ign)
        self.registry.register(g, "PASSPORT_US_UK", r'(?<!\d)\d{9}(?!\d)')
        self.registry.register(g, "PASSPORT_IN", r'\b[A-Z][0-9]{7}\b')
        self.registry.register(g, "PASSPORT_EU", r'\b[A-Z0-9]{8,9}\b')
        self.registry.register(g, "PASSPORT_JP", r'\b[A-Z]{2}\d{7}\b')
        self.registry.register(g, "PASSPORT_BR", r'\b[A-Z]{2}\d{6}\b')
        self.registry.register(g, "DRIVER_LICENSE_CA", r'\b[A-Z]\d{7}\b')
        self.registry.register(g, "DRIVER_LICENSE_NY", r'\b\d{9}\b')
        self.registry.register(g, "DRIVER_LICENSE_IN", r'\b[A-Z]{2}\d{2}\s?\d{4}\d{7}\b')
        self.registry.register(g, "NATIONAL_ID_BR_CPF", r'\b\d{3}\.\d{3}\.\d{3}-\d{2}\b')
        self.registry.register(g, "NATIONAL_ID_BR_CNPJ", r'\b\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}\b')
        self.registry.register(g, "NATIONAL_ID_MX_CURP", r'\b[A-Z]{4}\d{6}[HM][A-Z]{5}\d{2}\b')
        self.registry.register(g, "NATIONAL_ID_CN", r'(?<!\d)\d{17}[\dX_x](?!\d)')
        self.registry.register(g, "PASSPORT_RU", r'\b\d{4}\s\d{6}\b')
        self.registry.register(g, "NIN_NG", r'(?<!\d)\d{11}(?!\d)')
        self.registry.register(g, "BSN_NL", r'(?<!\d)\d{8,9}(?!\d)')
        self.registry.register(g, "NHS_NUMBER_UK", r'\b\d{3}\s\d{3}\s\d{4}\b')
        self.registry.register(g, "NRIC_SG", r'\b[STFG]\d{7}[A-Z]\b')
        self.registry.register(g, "FEDERAL_TAX_ID_US", r'(?<!\d)\d{2}-\d{7}(?!\d)')
        self.registry.register(g, "VOTER_ID_IN", r'\b[A-Z]{2}/\d{2}/\d{3}/\d{3,6}\b')
        self.registry.register(g, "VOTER_ID_US", r'\bVTR-[A-Z]{2}-\d{4}-\d{3,6}\b')
        self.registry.register(g, "TAX_ID_GENERIC", r'\bTIN-[A-Z]{2}-\d{4}-\d{4,10}\b')
        self.registry.register(g, "TAX_ID_US_ITIN", r'(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)')
        self.registry.register(g, "TAX_ID_EU_VAT", r'\b[A-Z]{2}\d{8,12}\b')
        self.registry.register(g, "VISA_NUMBER_US", r'(?<!\d)\d{13,16}(?!\d)')
        self.registry.register(g, "VISA_NUMBER_SCHENGEN", r'\bVISA-[A-Z]{2}-\d{4}-\d{3,6}\b')
        self.registry.register(g, "GOVERNMENT_ID_GENERIC", r'\bGOV-ID-\d{4}-\d{4,10}\b')

        # --- CONTACT & ADDRESS ---
        self.registry.register(g, "EMAIL", r'(?i)\b[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}\b')
        self.registry.register(g, "EMAIL_IDN", r'[\w._%+\-]+@[\w.\-]+\.[\w]{2,}')
        self.registry.register(g, "PHONE_GLOBAL", r'\+?\d{1,3}[\s-]?\(?\d{1,4}\)?[\s-]?\d{3,4}[\s-]?\d{3,4}')
        self.registry.register(g, "PHONE_IN", r'\+?91[\s-]?\d{5}[\s-]?\d{5}')
        self.registry.register(g, "PHONE_UK", r'\+?44[\s-]?\d{2}[\s-]?\d{4}[\s-]?\d{4}')
        self.registry.register(g, "PHONE_BR", r'\+?55[\s-]?\(?\d{2}\)?[\s-]?\d{4,5}[\s-]?\d{4}')
        self.registry.register(g, "FAX_NUMBER", r'\+?\d{1,3}[\s-]?\(?\d{1,4}\)?[\s-]?\d{3,4}[\s-]?\d{3,4}')
        self.registry.register(g, "PHYSICAL_ADDRESS", r'\b\d{1,5}\s(?:[\w .,\'-]+\s){1,5}(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Lane|Ln|Drive|Dr|Court|Ct|Place|Pl|Square|Sq|Parkway|Pkwy|Circle|Cir|Rue|Calle|Str|شارع)\.?,?\s[\w.,\'\s\-]*\b')
        self.registry.register(g, "ADDRESS_ARABIC", r'(?:\bشارع\b|رقم|مبنى)[\u0600-\u06FF0-9 \-]{6,100}')
        self.registry.register(g, "ADDRESS_LATAM", r'\b(?:Calle|Av|Avenida|No|Número|Nº)\s[\w .,#\-]{5,60}\b', ign)
        self.registry.register(g, "ADDRESS_APAC", r'\b(?:Block|Blk|Lot|No|Street|Jalan|St)\s[\w #,\-]{5,60}\d{5,6}\b')
        self.registry.register(g, "POSTAL_CODE_US", r'\b\d{5}(-\d{4})?\b')
        self.registry.register(g, "POSTAL_CODE_CA", r'\b[A-Z]\d[A-Z]\s?\d[A-Z]\d\b')
        self.registry.register(g, "POSTAL_CODE_UK", r'\b[A-Z]{1,2}\d[A-Z0-9]?\s?\d[A-Z]{2}\b')
        self.registry.register(g, "POSTAL_CODE_IN", r'(?<!\d)\d{6}(?!\d)')
        self.registry.register(g, "POSTAL_CODE_JP", r'\b\d{3}-\d{4}\b')
        self.registry.register(g, "POSTAL_CODE_BR", r'\b\d{5}-\d{3}\b')
        self.registry.register(g, "POSTAL_CODE_AU", r'\b\d{4}\b')

        # --- PERSONAL DETAILS ---
        self.registry.register(g, "DATE_OF_BIRTH", r'\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b')
        self.registry.register(g, "DATE_OF_BIRTH_EU", r'\b\d{1,2}[-/]\d{1,2}[-/]\d{4}\b')
        self.registry.register(g, "YEAR_OF_BIRTH", r'\b(?:19|20)\d{2}\b')
        self.registry.register(g, "AGE", r'\b\d{1,3}\s?(?:years?|yrs?|ans|Jahre|anni|años|anos|歳)\b', ign)
        self.registry.register(g, "BLOOD_GROUP", r'\b(?:A|B|AB|O)[+-]\b')
        self.registry.register(g, "GENDER", r'\b(?:Male|Female|Non-binary|Transgender|Genderqueer|Genderfluid|Agender)\b', ign)
        self.registry.register(g, "MARITAL_STATUS", r'\b(?:Single|Married|Divorced|Widowed|Separated)\b', ign)
        self.registry.register(g, "NATIONALITY", r'\b(?:American|British|Indian|Canadian|Australian|Chinese|Japanese|French|German|Spanish|Italian|Brazilian|Mexican)\b', ign)

        # --- DIGITAL & DEVICE ---
        self.registry.register(g, "IP_ADDRESS", r'\b\d{1,3}(\.\d{1,3}){3}\b')
        self.registry.register(g, "IPV6_ADDRESS", r'\b[0-9a-fA-F]{0,4}(:[0-9a-fA-F]{0,4}){2,7}\b')
        self.registry.register(g, "MAC_ADDRESS", r'\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b')
        self.registry.register(g, "IMEI", r'(?<!\d)\d{15}(?!\d)')
        self.registry.register(g, "DEVICE_SERIAL", r'\bSN[\w]{8,16}\b')
        self.registry.register(g, "AD_ID", r'\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b')
        self.registry.register(g, "COOKIE_ID", r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b')
        self.registry.register(g, "UUID", r'\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b')
        self.registry.register(g, "DEVICE_FINGERPRINT", r'\b[0-9a-fA-F]{16,64}\b')

        # --- ACCOUNTS & ONLINE ---
        self.registry.register(g, "API_KEY", r'\b[a-zA-Z0-9_\-]{20,64}\b')
        self.registry.register(g, "OAUTH_TOKEN", r'\b[a-zA-Z0-9._\-]{20,128}\b')
        self.registry.register(g, "LOGIN_ID", r'\b(?=[a-zA-Z]{2,})(?=[^a-zA-Z]*\d)[\w._\-]{8,32}(?!!==)\b')
        self.registry.register(g, "USERNAME", r'\b(?=[a-zA-Z]{2,})(?=[^a-zA-Z]*\d)[\w._\-]{8,32}(?!!==)\b')
        self.registry.register(g, "ALIAS", r'\b(?=[a-zA-Z]{2,})(?=[^a-zA-Z]*\d)[\w._]{8,32}(?!!==)\b')
        self.registry.register(g, "ONLINE_ACCOUNT_GENERIC", r'\bACC-[A-Z]{2,4}-\d{4}-\d{4,10}\b')

        # --- HEALTH & MEDICAL ---
        self.registry.register(g, "MEDICAL_RECORD", r'\bMRN-\d{4}-\d{4,10}\b')
        self.registry.register(g, "MEDICAL_RECORD_US", r'\b\d{6,8}-\d{1,3}\b')
        self.registry.register(g, "HEALTH_INS_US", r'\bHIN-[A-Z]{2}-\d{6,12}\b')
        self.registry.register(g, "HEALTH_INS_DE", r'(?<!\d)\d{10}(?!\d)')
        self.registry.register(g, "HEALTH_INS_CA", r'\b\d{4}-\d{3}-\d{3}\b')
        self.registry.register(g, "HOSPITAL_PATIENT_ID", r'\bPT-\d{4}-[A-Z0-9]{2,6}-\d{3,6}\b')
        self.registry.register(g, "EMR_NUMBER", r'\bEMR-\d{4}-\d{4,8}\b')
        self.registry.register(g, "DNA_PROFILE_ID", r'\bDNA-\d{4}-[A-Z0-9]{5,10}-\d{4,6}\b')
        self.registry.register(g, "GENETIC_VARIANT_ID", r'\brs\d{3,12}\b')

        # --- VEHICLE & TRANSPORT ---
        self.registry.register(g, "LICENSE_PLATE_US", r'\b[A-Z]{1,3}\s?[A-Z0-9]{3}\d{3}\b')
        self.registry.register(g, "LICENSE_PLATE_EU", r'\b[A-Z]{1,3}\s\d{1,4}\s[A-Z]{1,3}\b')
        self.registry.register(g, "LICENSE_PLATE_IN", r'\b[A-Z]{2}\d{2}\s?[A-Z]{1,3}\s?\d{3,4}\b')
        self.registry.register(g, "VIN", r'\b[0-9A-HJ-NPR-Z]{17}\b')
        self.registry.register(g, "VEHICLE_REG_GENERIC", r'\bREG-[A-Z]{2}-[A-Z]{2}-\d{4,8}\b')
        self.registry.register(g, "VEHICLE_REG_IN", r'\b[A-Z]{2}\d{2}\s\d{4}\s\d{4,8}\b')
        self.registry.register(g, "PNR_AIRLINE", r'\b[A-Z0-9]{5,7}\b')
        self.registry.register(g, "PNR_RAIL", r'\b\d{3}-\d{7,10}\b')

        # --- EMPLOYMENT & EDUCATION ---
        self.registry.register(g, "EMPLOYEE_ID", r'\bEMP-[A-Z]{2}-\d{4}-\d{3,6}\b')
        self.registry.register(g, "EMPLOYEE_ID_JP", r'\b\d{4}-[\w]{1,6}-\d{3,6}\b')
        self.registry.register(g, "STUDENT_ID", r'\bSTU-[A-Z]{2,4}-\d{4}-\d{3,6}\b')
        self.registry.register(g, "STUDENT_ID_IN", r'\b[A-Z]{2}-[A-Z]{3}-\d{4}-\d{3,6}\b')
        self.registry.register(g, "EDU_RECORD_ID", r'\bEDU-[A-Z]{2}-[A-Z]{2}-\d{4}-\d{3,6}\b')

        # --- MISC IDENTIFIERS ---
        self.registry.register(g, "CUSTOMER_ID", r'\bCUST-[A-Z]{2}-\d{4}-\d{3,6}\b')
        self.registry.register(g, "ORDER_ID", r'\bORD-[A-Z]{2}-\d{8}-\d{3,8}\b')
        self.registry.register(g, "ORDER_ID_INV", r'#\d{4}-\d{2}-\d{2}-[A-Z]{3}-\d{3,6}')
        self.registry.register(g, "GPS_COORDINATES", r'\b-?\d{1,3}\.\d+,\s*-?\d{1,3}\.\d+\b')
        self.registry.register(g, "GPS_COORDINATES_DMS", r'\d{1,3}°\d{1,2}\'\d{1,2}(\.\d+)?"\s?[NS]\s\d{1,3}°\d{1,2}\'\d{1,2}(\.\d+)?"\s?[EW]')
        self.registry.register(g, "UTILITY_ACCOUNT", r'\b[A-Z]{3,5}-ACC-\d{6,12}\b')
        self.registry.register(g, "LAND_REGISTRY_ID", r'\b(?:LN|PAR)-[A-Z]{2}-\d{4}-\d{3,8}\b')
        self.registry.register(g, "JUDICIAL_CASE_NUMBER", r'\b\d{1,2}:\d{2}-[a-z]{2}-\d{4,6}-[A-Z]{2,4}\b')
        self.registry.register(g, "PRISON_ID", r'\b(?:INMATE|DET)-[A-Z]{2}-\d{4,8}\b')
        self.registry.register(g, "JURY_ID", r'\bJURY-\d{4}-[A-Z]{2}-\d{3,6}\b')
        self.registry.register(g, "KYC_REFERENCE", r'\bKYC-[A-Z]{2,4}-\d{0,4}-?\d{4,10}\b')
        self.registry.register(g, "BIOMETRIC_DATA", r'\b[0-9a-fA-F]{32,64}\b')
        self.registry.register(g, "ENCRYPTION_FINGERPRINT", r'\bSHA256(:[0-9A-F]{2}){16,32}\b')
        self.registry.register(g, "FACEPRINT_ID", r'\bFACE-[0-9a-f]{16,64}\b')
        self.registry.register(g, "FINGERPRINT_TEMPLATE", r'\bFP-\d{4}-[0-9a-f]{16,64}\b')
        self.registry.register(g, "GAIT_PROFILE_ID", r'\bGAIT-\d{4}-[A-Z0-9]{3,6}-\d{3,6}\b')
        self.registry.register(g, "KEYCARD_ID", r'\bCARD-[A-Z]{2}-\d{1,3}-\d{4,8}\b')
        self.registry.register(g, "ZONING_CODE", r'\b(?:\d{5}-\d{4}\.\d{2}|ZN-[A-Z]{2}-\d{4}-\d{2}-\d{3,6})\b')

    def detect(self, text: str, lang: Optional[str] = None) -> List[PIIEntity]:
        """Scans text and returns isolated PII entities, handling overlaps."""
        entities = []
        
        # Determine which categories to scan based on language
        active_categories = self._LANG_REGION_MAP.get(lang, ["GLOBAL", "AMERICAS", "EMEA", "APAC"])
        if "GLOBAL" not in active_categories:
            active_categories.append("GLOBAL")

        for cat in active_categories:
            cat_patterns = self.registry._patterns.get(cat, {})
            for entity_type, pattern in cat_patterns.items():
                for match in pattern.finditer(text):
                    entities.append(PIIEntity(
                        value=match.group(),
                        entity_type=entity_type,
                        start=match.start(),
                        end=match.end()
                    ))
                
        if not entities:
            return []

        # Hande Overlaps: Prioritize longer matches
        entities.sort(key=lambda x: x.start)
        filtered = []
        
        current = entities[0]
        for next_ent in entities[1:]:
            if next_ent.start < current.end:
                # Overlap detected
                if (next_ent.end - next_ent.start) > (current.end - current.start):
                    current = next_ent # Keep the longer one
            else:
                filtered.append(current)
                current = next_ent
        filtered.append(current)
        
        return filtered
