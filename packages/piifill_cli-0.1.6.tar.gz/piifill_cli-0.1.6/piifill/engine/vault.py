import re
import hashlib
from typing import Dict, List
from pydantic import BaseModel

class PIIMasker:
    """Handles logic for masking, redacting, and tokenizing PII values."""
    
    def __init__(self):
        self._token_map: Dict[str, str] = {}
        
    def reset_session(self):
        self._token_map = {}

    def get_token(self, value: str, entity_type: str = "PII") -> str:
        if value not in self._token_map:
            hash_int = int(hashlib.md5(value.encode()).hexdigest(), 16)
            token_num = str(hash_int)[-5:]
            self._token_map[value] = f"<{entity_type}_{token_num}>"
        return self._token_map[value]

    def apply_masking(self, value: str, entity_type: str) -> str:
        """
        Applies a strict, non-revealing masking format to all detected PII.
        Follows the user's request for complete obfuscation.
        """
        # Ensure the type is uppercase and consistent with the user's mapping if needed
        # However, using the entity_type directly is more flexible as we added many.
        return "[REDACTED]"
