"""
The common module of the nodes that belong to the
main editor library, with code shared in between
all these libraries.
"""
from yta_editor_parameters.specifications.validator import ParameterSpecificationValidator
from yta_validation.parameter import ParameterValidator
from typing import Union


class _Node:
    """
    *For internal use only*
    
    Class to be implemented by the nodes to be able to
    dynamically handle the inputs we are expecting and
    confirming that we have, at least, all the mandatory
    ones.

    This class must be inherited by the specific nodes
    in our `yta-editor-nodes`, `yta-editor-nodes-cpu`
    and `yta-editor-nodes-gpu` libraries.
    """

    mandatory_inputs: list[str] = None
    """
    The name of the inputs that are mandatory to be able
    to use the node.
    """
    optional_inputs: list[str] = None
    """
    The name of the inputs that will be used in the node
    if provided but are not mandatory to make the node
    work properly.
    """
    parameters_specifications: list['ParameterSpecification'] = []
    """
    The parameters that the node needs to be applied,
    including their specification that indicates the
    required and non-required parameters.
    """

    # Make the children validate that the mandatory and
    # optional parameters are defined
    def __init_subclass__(
        cls,
        **kwargs
    ):
        super().__init_subclass__(**kwargs)

        if (
            cls.mandatory_inputs is None or
            cls.optional_inputs is None
        ):
            raise Exception('The mandatory and optional inputs are not defined or maybe only one is defined.')

        ParameterValidator.validate_mandatory_list_of_string('cls.mandatory_inputs', cls.mandatory_inputs)
        ParameterValidator.validate_mandatory_list_of_string('cls.optional_inputs', cls.optional_inputs)
        ParameterValidator.validate_mandatory_list_of_these_instances('cls.parameters_specifications', cls.parameters_specifications, 'ParameterSpecification')

        overlap = set(cls.mandatory_inputs) & set(cls.optional_inputs)
        if overlap:
            raise Exception('Same key is defined twice for both mandatory and optional parameters.')
        
    def _validate_inputs(
        self,
        inputs: dict[str, Union['np.ndarray', 'moderngl.Texture', 'FrameBuffer']],
        type: Union['np.ndarray', 'moderngl.Texture', 'FrameBuffer']
    ) -> None:
        """
        *For internal use only*

        Validate the `inputs` provided and check if all the
        mandatory ones are provided and if the optionals,
        if also provided, are valid. It will also check that
        the `inputs` dict provided is a valid dict with keys
        and values of the `type` type.

        This method will raise an exception if some inputs
        are invalid or missing. An optional input is accepted
        if its key doesn't exist or if the value is None.

        The `type` must be one of the following:
        - `np.ndarray`
        - `moderngl.Texture`
        - `FrameBuffer`
        """
        ParameterValidator.validate_dict_of('inputs', inputs, type)

        # 1. Mandatory exist and are valid
        for name in self.mandatory_inputs:
            if name not in inputs:
                raise Exception(f"The mandatory input '{name}' was not provided.")
            
            ParameterValidator.validate_mandatory_instance_of(name, inputs[name], type)

        # 2. Optional, if existing, are valid or None
        for name in self.optional_inputs:
            if name not in inputs:
                continue

            ParameterValidator.validate_instance_of(name, inputs[name], type)

    def _validate_and_prepare_parameters(
        self,
        parameters: dict[str, any]
    ) -> dict[str, any]:
        """
        Validate and parse the `parameters` provided
        according to the `parameters_specifications` of
        this class.

        This method will return, if valid, the values
        of the parameters once they've been parsed, which
        means that if `None` and required, the default
        value will be obtained.
        """
        return ParameterSpecificationValidator.validate_parameters(
            parameters = parameters,
            parameter_specifications = self.parameters_specifications
        )

