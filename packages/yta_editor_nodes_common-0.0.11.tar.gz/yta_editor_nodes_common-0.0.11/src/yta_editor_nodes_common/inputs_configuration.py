from yta_validation.parameter import ParameterValidator
from typing import Union


"""
TODO: This has been created to replace the
`mandatory_inputs` and `optional_inputs` fields
we have in the `_Node` class to be able to make
it more dynamic by using this configuration
instead.
"""
class NodeInputsConfiguration:
    """
    Class to define the configuration of the
    mandatory and the optional parameters we want
    for a specific node.
    """

    def __init__(
        self,
        mandatory_inputs: list[str] = [],
        optional_inputs: list[str] = []
    ):
        ParameterValidator.validate_mandatory_list_of_string('mandatory_inputs', mandatory_inputs)
        ParameterValidator.validate_mandatory_list_of_string('optional_inputs', optional_inputs)

        self.mandatory_inputs: list[str] = mandatory_inputs
        """
        The inputs that are mandatory to be able to use the
        node.
        """
        self.optional_inputs: list[str] = optional_inputs
        """
        The inputs that will be used in the node if provided
        but are not mandatory to make the node work properly.
        """

    """
    TODO: This `_validate_inputs` method should
    replace the one in the `_Node` class if the
    configuration is received in the constructor.
    """
    def _validate_inputs(
        self,
        inputs: dict[str, Union['np.ndarray', 'moderngl.Texture', 'FrameBuffer']],
        type: Union['np.ndarray', 'moderngl.Texture', 'FrameBuffer']
    ) -> None:
        """
        *For internal use only*

        Validate the `inputs` provided and check if all the
        mandatory ones are provided and if the optionals,
        if also provided, are valid. It will also check that
        the `inputs` dict provided is a valid dict with keys
        and values of the `type` type.

        This method will raise an exception if some inputs
        are invalid or missing. An optional input is accepted
        if its key doesn't exist or if the value is None.

        The `type` must be one of the following:
        - `np.ndarray`
        - `moderngl.Texture`
        - `FrameBuffer`
        """
        ParameterValidator.validate_dict_of('inputs', inputs, type)

        # 1. Mandatory exist and are valid
        for name in self.mandatory_inputs:
            if name not in inputs:
                raise Exception(f"The mandatory input '{name}' was not provided.")
            
            ParameterValidator.validate_mandatory_instance_of(name, inputs[name], type)

        # 2. Optional, if existing, are valid or None
        for name in self.optional_inputs:
            if name not in inputs:
                continue

            ParameterValidator.validate_instance_of(name, inputs[name], type)

BASE_TEXTURE_NODE_INPUTS_CONFIG = NodeInputsConfiguration(
    mandatory_inputs = ['base_input'],
    optional_inputs = []
)
"""
GPU node that uses a single base texture.

The mandatory inputs:
- `base_input`

The optional inputs:
- `None`
"""
BASE_AND_OVERLAY_TEXTURES_NODE_INPUTS_CONFIG = NodeInputsConfiguration(
    mandatory_inputs = ['base_input', 'overlay_input'],
    optional_inputs = []
)
"""
GPU node that uses a base texture and an
overlay texture.

The mandatory inputs:
- `base_input`
- `overlay_input`

The optional inputs:
- `None`
"""
FIRST_AND_SECOND_TEXTURES_NODE_INPUTS_CONFIG = NodeInputsConfiguration(
    mandatory_inputs = ['first_input', 'second_input'],
    optional_inputs = []
)
"""
GPU node that uses a first texture and also
a second texture.

The mandatory inputs:
- `first_input`
- `second_input`

The optional inputs:
- `None`
"""
ORIGINAL_PROCESSED_AND_SELECTION_MASK_TEXTURES_NODE_INPUTS_CONFIG = NodeInputsConfiguration(
    mandatory_inputs = ['original_input', 'processed_input', 'selection_mask_input'],
    optional_inputs = []
)
"""
GPU node that uses an original texture, a
processed texture and one as a selection mask
texture to combine the other 2.

The mandatory inputs:
- `original_input`
- `processed_input`
- `selection_mask_input`

The optional inputs:
- `None`
"""