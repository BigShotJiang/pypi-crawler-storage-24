Asset Caching
Kigo introduces asset caching. What it does is keep things in memory so that if your app needs them it can access that thing much faster. Also I passed
in the exam and am going to class five pray for me plz