{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}
.. autoclass:: {{ fullname }}
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __eq__
