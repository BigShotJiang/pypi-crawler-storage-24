from setuptools import setup, find_packages

setup(
    name='data_pipeline_helper_swathitr',
    version='0.1.3',  # Bump version to force fresh metadata
    author='Swathi',
    author_email='swathikannan11@gmail.com',
    description='A helper library for building and managing data pipelines',
    long_description_content_type='text/markdown',
    url='https://github.com/Swathi1110/Python_Master/tree/main',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    install_requires=[
        'pandas',
        'boto3',
    ],
)