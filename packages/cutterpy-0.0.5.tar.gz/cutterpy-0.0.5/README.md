# short_auto

## Развериывание и использование

1. Скопировать код с помошью git 

~~~
git clone git@github.com:ShapDi/short_auto.git
~~~

2. Добавить файл фильма в папку рядом с шаблоным файлом file_start.py
3. Изменить название фильма в файле file_start.py
4. Запустить