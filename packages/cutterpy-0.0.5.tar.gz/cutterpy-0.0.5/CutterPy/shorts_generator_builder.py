from typing import Self

from CutterPy.core.decorator_interface import DecoratorInterface
from CutterPy.core.frame_editor import EditorInterface, EditorStandard
from CutterPy.core.intervals_generator import DefaultGenerator, GeneratorInterface
from CutterPy.shorts_generator import ShortsGenerator


class ShortsGeneratorBuilder:
    """
    Builder class for creating a reusable short video generator
    """

    def __init__(self) -> None:
        self._interval_generators: GeneratorInterface = DefaultGenerator()
        self._frame_editor: EditorInterface = EditorStandard()
        self._decorators: list[DecoratorInterface] = []

    def with_interval_generator(self, generator: GeneratorInterface) -> Self:
        self._interval_generators = generator
        return self

    def with_frame_editor(self, editor: EditorInterface) -> Self:
        self._frame_editor = editor
        return self

    def with_decorator(self, decorator: DecoratorInterface) -> Self:
        self._decorators.append(decorator)
        return self

    def build(self) -> ShortsGenerator:
        return ShortsGenerator(
            frame_editor=self._frame_editor,
            interval_generators=self._interval_generators,
            decorators=self._decorators,
        )
