from abc import ABC, abstractmethod

from moviepy import VideoClip  # type: ignore


class DecoratorInterface(ABC):
    @abstractmethod
    def __init__(self, priority_index: int = 0) -> None:
        self._priority_index = priority_index

    def get_priority_index(self) -> int:
        return self._priority_index

    @abstractmethod
    def get_processed_fragment(self, edited_fragment: VideoClip) -> VideoClip:
        pass
