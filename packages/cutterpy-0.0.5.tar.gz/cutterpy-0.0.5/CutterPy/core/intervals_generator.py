from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Generator

from moviepy import VideoClip  # type: ignore

from CutterPy.core.constants import MAX_SHORT_DURATION, MIN_SHORT_DURATION


class IntervalGenerator(Enum):
    default_generator = "default_generator"
    predetermined_generator = "predetermined_generator"


@dataclass
class TimeSlotData:
    start: float
    end: float


@dataclass
class SegmentData:
    video_segment: VideoClip
    segment_counter: int


class GeneratorInterface(ABC):
    @staticmethod
    @abstractmethod
    def get_time(time_slot: TimeSlotData) -> Generator[TimeSlotData]:
        pass

    @abstractmethod
    def get_fragment(self, video: VideoClip) -> Generator[SegmentData]:
        pass


class DefaultGenerator(GeneratorInterface):
    @staticmethod
    def get_time(time_slot: TimeSlotData) -> Generator[TimeSlotData]:
        duration = int(time_slot.end)
        current_time = 0

        if duration < MIN_SHORT_DURATION:
            raise RuntimeError("Video is too short. Just like your dick")

        def get_step(current_step: int, delta: int) -> int:
            temporary_step = min(current_step, delta) - 1
            return (
                temporary_step
                if temporary_step <= MAX_SHORT_DURATION
                else MAX_SHORT_DURATION
            )

        step = get_step(MAX_SHORT_DURATION, duration)

        for segment in range(current_time, duration, step):
            if segment == 0:
                continue
            # yield current_time, segment, segment - current_time
            yield TimeSlotData(start=current_time, end=segment)
            current_time = segment
            step = get_step(step, duration - segment)
            if step <= MIN_SHORT_DURATION:
                break

    def get_fragment(self, video: VideoClip) -> Generator[SegmentData]:
        segment_counter = 0
        for segment in self.get_time(TimeSlotData(0, end=float(video.duration))):
            video_segment: VideoClip = video.subclipped(segment.start, segment.end)
            yield SegmentData(
                video_segment=video_segment, segment_counter=segment_counter
            )
            segment_counter += 1


class PredeterminedGenerator(GeneratorInterface):
    """Generates intervals by using predetermined segments.
    Parameters
    ----------
    segments : []
        Array which consists of multiple dicts with 'start' and 'end' fields
    """

    def __init__(self, time_slot: TimeSlotData) -> None:
        self._time_slot = time_slot

    @staticmethod
    def get_time(time_slot: TimeSlotData) -> Generator[TimeSlotData]:
        if time_slot.start > time_slot.end:
            raise ValueError("For some reason 'start' value is greater than 'end'")
        if (
            time_slot.end - time_slot.start < MIN_SHORT_DURATION
            or time_slot.end - time_slot.start > MAX_SHORT_DURATION
        ):
            raise RuntimeError("Duration of fragment is too short or too long. Unlucky")
        yield time_slot

    def get_fragment(self, video: VideoClip) -> Generator[SegmentData]:
        segment_counter = 0
        for segment in self.get_time(self._time_slot):
            video_segment = video.subclipped(segment.start, segment.end)
            yield SegmentData(video_segment, segment_counter)
            segment_counter += 1
