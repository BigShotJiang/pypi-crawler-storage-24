from abc import ABC, abstractmethod
from typing import Union

from moviepy import CompositeVideoClip, VideoClip, ImageClip  # type: ignore

from CutterPy.core.constants import (
    EXPECTED_SHORT_SOURCE_SIZE,
    TARGET_SHORT_SIZE,
    TARGET_SHORT_SIZE_NEW,
)


class EditorInterface(ABC):
    @abstractmethod
    def get_short_video(self, fragment: VideoClip) -> VideoClip:
        pass


class EditorStandard(EditorInterface):
    def get_short_video(self, fragment: VideoClip) -> VideoClip:
        if (
            fragment.size != EXPECTED_SHORT_SOURCE_SIZE
            or fragment.size != TARGET_SHORT_SIZE
        ):
            fragment = fragment.resized(EXPECTED_SHORT_SOURCE_SIZE)
        return fragment.resized(0.5625).with_position(("center", "center"))


class EditorPoint(EditorInterface):
    def __init__(self, coordinates: list[dict[str, int]]) -> None:
        self.coordinates = coordinates

    def get_short_video(self, fragment: VideoClip) -> VideoClip:
        first_section = self.coordinates[0]
        second_section = self.coordinates[1]

        first_subclip = fragment.cropped(
            x1=int(first_section["x1"]),
            y1=int(first_section["y1"]),
            x2=int(first_section["x2"]),
            y2=int(first_section["y2"]),
        )

        second_subclip = fragment.cropped(
            x1=int(second_section["x1"]),
            y1=int(second_section["y1"]),
            x2=int(second_section["x2"]),
            y2=int(second_section["y2"]),
        )

        first_resized = first_subclip.resized(TARGET_SHORT_SIZE_NEW)
        second_resized = second_subclip.resized(TARGET_SHORT_SIZE_NEW)

        final_clip = CompositeVideoClip(
            [
                first_resized.with_position(("center", "top")),
                second_resized.with_position(("center", "bottom")),
            ],
            size=TARGET_SHORT_SIZE,
        )

        return final_clip


class FrameEditor(EditorInterface):
    """
    Editor for processing individual frames (images).
    Takes frame coordinates, crops the area, resizes to target size,
    and places it in the center.
    """

    def __init__(
        self,
        coordinates: dict[str, int],
        target_size: tuple[int, int] = TARGET_SHORT_SIZE,
    ) -> None:
        """
        Args:
            coordinates: Dictionary with frame coordinates {"x1": x1, "y1": y1, "x2": x2, "y2": y2}
            target_size: Target output video size (width, height)
        """
        self.coordinates = coordinates
        self.target_size = target_size

    def get_short_video(self, fragment: Union[VideoClip, ImageClip]) -> VideoClip:
        """
        Process a fragment (video or image), crop according to coordinates,
        resize, and place in the center.

        Args:
            fragment: Input video clip or image

        Returns:
            VideoClip: Processed video clip
        """
        # Extract coordinates
        x1 = int(self.coordinates["x1"])
        y1 = int(self.coordinates["y1"])
        x2 = int(self.coordinates["x2"])
        y2 = int(self.coordinates["y2"])

        # Validate coordinates
        if x2 <= x1 or y2 <= y1:
            raise ValueError(
                f"Invalid coordinates: x1={x1}, x2={x2}, y1={y1}, y2={y2}. x2 must be > x1, y2 > y1"
            )

        # Crop the fragment using coordinates
        cropped_fragment = fragment.cropped(x1=x1, y1=y1, x2=x2, y2=y2)

        # Resize to target size while preserving aspect ratio
        resized_fragment = self._resize_with_padding(cropped_fragment, self.target_size)

        # Place in the center
        final_clip = resized_fragment.with_position(("center", "center"))

        return final_clip

    def _resize_with_padding(
        self, clip: Union[VideoClip, ImageClip], target_size: tuple[int, int]
    ) -> VideoClip:
        """
        Resize clip while preserving aspect ratio and add padding to achieve target size.

        Args:
            clip: Source clip
            target_size: Target size (width, height)

        Returns:
            VideoClip: Clip with resized dimensions and added padding
        """
        target_width, target_height = target_size

        # Get current clip dimensions
        current_width, current_height = clip.size

        # Calculate scaling factor to fit target size
        width_ratio = target_width / current_width
        height_ratio = target_height / current_height

        # Use the smaller ratio to ensure the entire clip fits
        scale_factor = min(width_ratio, height_ratio)

        # New dimensions after scaling
        new_width = int(current_width * scale_factor)
        new_height = int(current_height * scale_factor)

        # Scale the clip
        resized_clip = clip.resized((new_width, new_height))

        # If dimensions don't match target size, add padding
        if new_width != target_width or new_height != target_height:
            # Create black background of target size
            from moviepy import ColorClip

            background = ColorClip(
                size=target_size, color=(0, 0, 0), duration=clip.duration
            )

            # Calculate position for centering
            x_pos = (target_width - new_width) // 2
            y_pos = (target_height - new_height) // 2

            # Composite the clips
            from moviepy import CompositeVideoClip

            final_clip = CompositeVideoClip(
                [background, resized_clip.with_position((x_pos, y_pos))],
                size=target_size,
            )
            return final_clip

        return resized_clip
