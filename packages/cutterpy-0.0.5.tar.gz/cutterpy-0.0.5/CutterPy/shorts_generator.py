import os

from moviepy import CompositeVideoClip, VideoFileClip, VideoClip  # type: ignore

from CutterPy.core.constants import TARGET_SHORT_SIZE
from CutterPy.core.decorator_interface import DecoratorInterface
from CutterPy.core.frame_editor import EditorInterface
from CutterPy.core.intervals_generator import (
    GeneratorInterface,
)


class ShortsGenerator:
    def __init__(
        self,
        frame_editor: EditorInterface,
        interval_generators: GeneratorInterface,
        decorators: list[DecoratorInterface] | None = None,
    ) -> None:
        self._frame_editor = frame_editor
        self._interval_generators = interval_generators

        self._decorators = decorators

    @staticmethod
    def validate_output_dir(title_video: str) -> None:
        if not os.path.isdir(f"output/{title_video}"):
            os.makedirs(f"output/{title_video}")

    def application_decorator(self, edited_fragment: VideoClip) -> list[VideoClip]:
        if not self._decorators:
            return [edited_fragment]

        sorted_decorators = sorted(
            self._decorators, key=lambda d: d.get_priority_index()
        )

        layers = [edited_fragment]

        for decorator in sorted_decorators:
            result = decorator.get_processed_fragment(edited_fragment)
            layers.append(result)

        return layers

    def start(self, import_path: str, output_title: str) -> None:
        self.validate_output_dir(output_title)
        video = VideoFileClip(import_path)
        for segment_data in self._interval_generators.get_fragment(video):
            edited_fragment = self._frame_editor.get_short_video(
                fragment=segment_data.video_segment
            )
            decorated_layers = self.application_decorator(edited_fragment)
            final_video = CompositeVideoClip(decorated_layers, size=TARGET_SHORT_SIZE)
            final_video.write_videofile(
                f"output/{output_title}/{output_title}_segment_{segment_data.segment_counter}.mp4",
                codec="h264_nvenc",
                fps=24,
            )
