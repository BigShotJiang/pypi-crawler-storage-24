from typing import Optional, Tuple, Union
from pathlib import Path

from moviepy import VideoFileClip, VideoClip, ImageClip, vfx  # type: ignore

from CutterPy.core import DecoratorInterface

StickerPositionType = Union[Tuple[int, int], Tuple[str, str], Tuple[str, int], Tuple[int, str], str]


class StickerOverlay(DecoratorInterface):
    """
    A decorator for applying a sticker (image, GIF, or video) to the entire video.

    Args:
            priority_index: Processing priority
            sticker_path: Path to the sticker file (png, jpg, gif, mp4)
            size: Desired size (width, height) in pixels
            position: Position on the screen ("center", "top", "bottom", "left", "right")
            opacity: Transparency (0.0 - 1.0)
            rotation: Angle of rotation in degrees
    """

    def __init__(
        self,
        priority_index: int = 100,
        sticker_path: Optional[Union[str, Path]] = None,
        size: Optional[Tuple[int, int]] = None,
        position: str = "center",
        opacity: float = 1.0,
        rotation: float = 0.0,
    ) -> None:
        super().__init__(priority_index)
        self._sticker_path = str(sticker_path) if sticker_path else ""
        self._size: Optional[Tuple[int, int]] = size
        self._position_str: str = position
        self._opacity: float = opacity
        self._rotation: float = rotation
        self._position_coords: Optional[StickerPositionType] = None

    @staticmethod
    def _parse_position(
        position_str: str, video_size: Tuple[int, int]
    ) -> StickerPositionType:
        """
        Converts a string description of a position to coordinates.

        Args:
            position_str: A row with a position
            video_size: Video size (width, height)

        Returns:
            The coordinates of the position or the line for centering
        """
        positions = {
            "center": ("center", "center"),
            "top": ("center", 50),
            "bottom": ("center", video_size[1] - 150),
            "left": (50, "center"),
            "right": (video_size[0] - 150, "center"),
            "top_left": (50, 50),
            "top_right": (video_size[0] - 150, 50),
            "bottom_left": (50, video_size[1] - 150),
            "bottom_right": (video_size[0] - 150, video_size[1] - 150),
        }

        if position_str in positions:
            return positions[position_str]

        return "center", "center"

    def _resize_sticker(
        self, clip: Union[VideoClip, ImageClip]
    ) -> Union[VideoClip, ImageClip]:
        if self._size:
            return clip.resized(self._size)
        return clip

    def _apply_effects(
        self, clip: Union[VideoClip, ImageClip]
    ) -> Union[VideoClip, ImageClip]:
        if self._opacity < 1.0:
            if hasattr(clip, "with_opacity"):
                clip = clip.with_opacity(self._opacity)
        if self._rotation != 0:
            clip = clip.rotated(self._rotation)

        return clip

    @staticmethod
    def _load_sticker(file_path: str) -> Optional[Union[VideoClip, ImageClip]]:
        """
        Downloads a sticker from a file.

        Args:
            file_path: The path to the file

        Returns:
            Uploaded clip or None if the file is not found
        """
        if not file_path:
            return None

        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"The sticker file was not found:{file_path}")

        ext = path.suffix.lower()

        try:
            if ext in [".gif", ".mp4", ".mov", ".avi"]:
                clip = VideoFileClip(file_path, has_mask=True)
                if hasattr(clip, "with_effects"):
                    clip = clip.with_effects([vfx.Loop()])
            elif ext in [".png", ".jpg", ".jpeg", ".bmp"]:
                clip = ImageClip(file_path)
            else:
                raise ValueError(f"Unsupported file format: {ext}")

            return clip

        except Exception as e:
            raise RuntimeError(f"Sticker loading error {file_path}: {e}")

    def get_priority_index(self) -> int:
        return self._priority_index

    def get_processed_fragment(self, edited_fragment: VideoClip) -> VideoClip:
        """
         Puts a sticker on a video clip.

        Args:
            edited_fragment: The original video fragment

        Returns:
            A video clip with a superimposed sticker
        """
        if not self._sticker_path:
            return edited_fragment

        sticker_clip = self._load_sticker(self._sticker_path)
        if sticker_clip is None:
            return edited_fragment

        video_size = edited_fragment.size
        position = self._parse_position(self._position_str, video_size)

        sticker_clip = self._resize_sticker(sticker_clip)

        sticker_clip = self._apply_effects(sticker_clip)

        if hasattr(sticker_clip, "with_duration"):
            sticker_clip = sticker_clip.with_duration(edited_fragment.duration)

        if hasattr(sticker_clip, "with_position"):
            sticker_clip = sticker_clip.with_position(position)

        try:
            from moviepy import CompositeVideoClip

            final_clip = CompositeVideoClip([edited_fragment, sticker_clip])
            return final_clip
        except (ImportError, AttributeError):
            if hasattr(edited_fragment, "overlay"):
                return edited_fragment.overlay(sticker_clip, position=position)
            else:
                return edited_fragment
