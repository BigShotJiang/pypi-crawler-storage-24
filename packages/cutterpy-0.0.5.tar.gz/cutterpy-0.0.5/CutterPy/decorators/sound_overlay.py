from typing import Optional, Union
from pathlib import Path

from moviepy import VideoClip, AudioClip, AudioFileClip, CompositeAudioClip, afx  # type: ignore

from CutterPy.core import DecoratorInterface


class SoundOverlay(DecoratorInterface):
    """
    A decorator for overlaying audio on a video fragment without modifying the video.

    Args:
        priority_index: Processing priority
        audio_path: Path to the audio file (mp3, wav, etc.)
        start_in_video: Start time in the video (seconds)
        end_in_video: End time in the video (seconds, 0 for full duration)
        segment_audio_start: Start time in the audio file (seconds)
        segment_audio_end: End time in the audio file (seconds, 0 for full duration)
        volume_scale: Volume scaling factor (1.0 = original volume)
        loop_audio: Whether to loop audio if it's shorter than video
    """

    def __init__(
        self,
        priority_index: int = 1,
        audio_path: Optional[Union[str, Path]] = None,
        start_in_video: float = 0.0,
        end_in_video: float = 0.0,
        segment_audio_start: float = 0.0,
        segment_audio_end: float = 0.0,
        volume_scale: float = 1.0,
        loop_audio: bool = True,
    ) -> None:
        super().__init__(priority_index)
        self._audio_path = str(audio_path) if audio_path else ""
        self._start_in_video: float = start_in_video
        self._end_in_video: float = end_in_video
        self._segment_audio_start: float = segment_audio_start
        self._segment_audio_end: float = segment_audio_end
        self._volume_scale: float = volume_scale
        self._loop_audio: bool = loop_audio

    @staticmethod
    def _load_audio(file_path: str) -> Optional[AudioClip]:
        """
        Loads an audio clip from a file.

        Args:
            file_path: Path to the audio file

        Returns:
            Loaded audio clip or None if file not found
        """
        if not file_path:
            return None

        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Audio file not found: {file_path}")

        try:
            return AudioFileClip(file_path)
        except Exception as e:
            raise RuntimeError(f"Audio loading error {file_path}: {e}")

    def _prepare_audio_clip(
        self, audio_clip: AudioClip, video_duration: float
    ) -> AudioClip:
        """
        Prepares the audio clip according to parameters.

        Args:
            audio_clip: Original audio clip
            video_duration: Duration of the video fragment

        Returns:
            Processed audio clip
        """
        if self._segment_audio_end > 0:
            audio_clip = audio_clip.subclipped(
                self._segment_audio_start, self._segment_audio_end
            )
        elif self._segment_audio_start > 0:
            audio_clip = audio_clip.subclipped(self._segment_audio_start)

        target_duration = video_duration
        if self._end_in_video > 0:
            target_duration = min(self._end_in_video, video_duration)

        if audio_clip.duration < target_duration and self._loop_audio:
            audio_clip = audio_clip.with_effects(
                [afx.AudioLoop(duration=target_duration)]
            )
        elif audio_clip.duration > target_duration:
            audio_clip = audio_clip.subclipped(0, target_duration)

        return audio_clip

    def get_priority_index(self) -> int:
        """Returns the priority index of the decorator."""
        return self._priority_index

    def get_processed_fragment(self, edited_fragment: VideoClip) -> VideoClip:
        """
        Overlays audio on the video fragment.

        Args:
            edited_fragment: The original video fragment

        Returns:
            The same video clip with overlaid audio
        """
        if not self._audio_path:
            return edited_fragment

        audio_clip = self._load_audio(self._audio_path)
        if audio_clip is None:
            return edited_fragment

        audio_clip = self._prepare_audio_clip(audio_clip, edited_fragment.duration)

        if self._start_in_video > 0:
            audio_clip = audio_clip.with_start(self._start_in_video)

        original_audio = edited_fragment.audio
        if original_audio and self._volume_scale != 1.0:
            original_audio = original_audio.with_volume_scaled(self._volume_scale)

        if original_audio:
            final_audio = CompositeAudioClip([original_audio, audio_clip])
        else:
            final_audio = audio_clip

        return edited_fragment.with_audio(final_audio)
