from typing import Optional, Callable, cast

from moviepy import VideoClip  # type: ignore
from moviepy.video.fx.HeadBlur import HeadBlur  # type: ignore

from CutterPy.core import DecoratorInterface


class BlurOverlay(DecoratorInterface):
    """
    A decorator for applying a moving blur effect to a video fragment.
    The blur position can change over time.

    Args:
        priority_index: Processing priority.
        fx: Function of time t returning x-coordinate of blur center.
        fy: Function of time t returning y-coordinate of blur center.
        radius: Radius of the blurring area (in pixels).
        intensity: Intensity of the blurring effect (optional).
    """

    def __init__(
        self,
        priority_index: int = 200,
        fx: Optional[Callable[[float], float]] = None,
        fy: Optional[Callable[[float], float]] = None,
        radius: float = 100.0,
        intensity: Optional[float] = None,
    ) -> None:
        super().__init__(priority_index)
        # Default static position functions (center of frame for 1080x1920)
        self._fx: Callable[[float], float] = fx if fx else lambda t: 540.0
        self._fy: Callable[[float], float] = fy if fy else lambda t: 960.0
        self._radius: float = radius
        self._intensity: Optional[float] = intensity

    def get_priority_index(self) -> int:
        return self._priority_index

    def get_processed_fragment(self, edited_fragment: VideoClip) -> VideoClip:
        if self._radius <= 0:
            return edited_fragment

        blur_effect = HeadBlur(
            fx=self._fx, fy=self._fy, radius=self._radius, intensity=self._intensity
        )
        result = blur_effect.apply(edited_fragment)
        return cast(VideoClip, result)
