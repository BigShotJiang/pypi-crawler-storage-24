"""Integration tests against a running local server.

Run: uv run pytest tests/test_integration.py -v

Requires:
  - Server running on localhost (make start_liquidserver)
  - Environment variables: LIQUID_TEST_KEY, LIQUID_TEST_SECRET

Trading tests additionally require a key with trade permissions
and an approved HL agent key. Set LIQUID_TEST_TRADE_KEY and
LIQUID_TEST_TRADE_SECRET for those tests.
"""

from __future__ import annotations

import os

import pytest

from liquidtrading import (
    AuthenticationError,
    Balance,
    LiquidClient,
    Orderbook,
    TpSlResult,
    CloseResult,
    Account,
    Position,
    Ticker,
)

BASE_URL = os.environ.get("LIQUID_TEST_URL", "http://localhost:8001")
API_KEY = os.environ.get("LIQUID_TEST_KEY", "")
API_SECRET = os.environ.get("LIQUID_TEST_SECRET", "")
TRADE_KEY = os.environ.get("LIQUID_TEST_TRADE_KEY", "")
TRADE_SECRET = os.environ.get("LIQUID_TEST_TRADE_SECRET", "")

pytestmark = pytest.mark.integration


@pytest.fixture()
def auth_client():
    if not API_KEY or not API_SECRET:
        pytest.skip("LIQUID_TEST_KEY / LIQUID_TEST_SECRET not set")
    with LiquidClient(api_key=API_KEY, api_secret=API_SECRET, base_url=BASE_URL) as c:
        yield c


@pytest.fixture()
def trade_client():
    if not TRADE_KEY or not TRADE_SECRET:
        pytest.skip("LIQUID_TEST_TRADE_KEY / LIQUID_TEST_TRADE_SECRET not set")
    with LiquidClient(api_key=TRADE_KEY, api_secret=TRADE_SECRET, base_url=BASE_URL) as c:
        yield c


class TestPublicEndpoints:
    def test_get_markets_returns_non_empty(self, auth_client):
        markets = auth_client.get_markets()
        assert len(markets) > 0
        assert isinstance(markets[0], dict)

    def test_get_ticker(self, auth_client):
        ticker = auth_client.get_ticker("BTC-PERP")
        assert isinstance(ticker, Ticker)
        assert ticker.mark_price > 0

    def test_get_orderbook(self, auth_client):
        ob = auth_client.get_orderbook("BTC-PERP")
        assert isinstance(ob, Orderbook)
        assert ob.bids or ob.asks

    def test_get_candles(self, auth_client):
        candles = auth_client.get_candles("BTC-PERP", interval="1h", limit=5)
        assert len(candles) > 0


class TestReadEndpoints:
    def test_get_account(self, auth_client):
        account = auth_client.get_account()
        assert isinstance(account, Account)

    def test_get_balances(self, auth_client):
        balances = auth_client.get_balances()
        assert isinstance(balances, Balance)

    def test_get_positions(self, auth_client):
        positions = auth_client.get_positions()
        assert isinstance(positions, list)


class TestTradingEndpoints:
    """Require a key with trade permissions and HL agent key."""

    def test_order_cancel_round_trip(self, trade_client):
        """Place limit order → verify in open orders → cancel."""
        order = trade_client.place_order(
            "BTC-PERP", "buy", type="limit", size=10.0,
            price=1000.0, leverage=1,
        )
        assert order.status in ("open", "filled")

        if order.status == "open" and order.order_id:
            orders = trade_client.get_open_orders()
            assert any(o.order_id == order.order_id for o in orders)
            assert trade_client.cancel_order(order.order_id) is True

    def test_position_flow(self, trade_client):
        """Place order → check position → set TP/SL → close position."""
        order = trade_client.place_order(
            "BTC-PERP", "buy", type="market", size=10.0, leverage=5,
        )
        assert order.status == "filled"

        positions = trade_client.get_positions()
        btc_positions = [p for p in positions if p.symbol == "BTC-PERP"]
        assert len(btc_positions) > 0
        assert btc_positions[0].side == "long"

        tp_sl = trade_client.set_tp_sl("BTC-PERP", tp=200000.0, sl=10000.0)
        assert isinstance(tp_sl, TpSlResult)

        result = trade_client.close_position("BTC-PERP")
        assert isinstance(result, CloseResult)


class TestAuthErrors:
    def test_invalid_credentials_raises(self):
        with LiquidClient(api_key="lq_invalid", api_secret="sk_invalid", base_url=BASE_URL) as c:
            with pytest.raises(AuthenticationError):
                c.get_account()
