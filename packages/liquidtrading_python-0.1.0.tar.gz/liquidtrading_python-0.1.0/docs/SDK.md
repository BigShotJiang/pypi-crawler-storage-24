# liquidtrading-python SDK

## Overview

`liquidtrading-python` is the official Python SDK for the Liquid Trading REST API. It wraps the public API with:

- typed dataclass models
- automatic HMAC request signing
- response envelope unwrapping
- structured exception mapping
- compatibility imports for both old and improved local naming

The package is designed to be the canonical client used by:

- direct Python integrations
- backend services
- the `liquidtrading-mcp` package

## Package Identity

- PyPI package: `liquidtrading-python`
- Python requirement: `>=3.9`
- main import path: `from liquid import Client`
- compatibility import path: `from liquidtrading import LiquidClient`
- console scripts:
  - `liquidtrading-demo`
  - `liquid-demo`

The package ships both the `liquid` and `liquidtrading` modules so existing users do not need to migrate import paths immediately.

## Installation

### pip

```bash
pip install liquidtrading-python
```

### uv

```bash
uv add liquidtrading-python
```

### Editable Local Install

```bash
cd /Users/raymondcosgrove/Liquid/Public\ Apis/liquidtrading-python
uv sync
uv pip install -e .
```

## Quick Start

### Recommended Import

```python
from liquid import Client

client = Client(
    api_key="lq_...",
    api_secret="sk_...",
    base_url="https://api.liquid.trade",
)

ticker = client.get_ticker("BTC-PERP")
print(ticker.mark_price)
```

### Compatibility Import

```python
from liquidtrading import LiquidClient

client = LiquidClient(
    api_key="lq_...",
    api_secret="sk_...",
    base_url="https://api.liquid.trade",
)
```

### Account Example

```python
from liquid import Client

client = Client(
    api_key="lq_...",
    api_secret="sk_...",
    base_url="https://api.liquid.trade",
)

account = client.get_account()
positions = client.get_positions()

print(account.equity)
print(positions)
```

### Order Example

```python
from liquid import Client

client = Client(
    api_key="lq_...",
    api_secret="sk_...",
    base_url="https://api.liquid.trade",
)

order = client.place_order(
    symbol="BTC-PERP",
    side="buy",
    type="market",
    size=100.0,
    leverage=2,
    tp=72000.0,
    sl=68000.0,
)

print(order.order_id, order.status)
```

## Client Construction

```python
Client(
    api_key: str | None = None,
    api_secret: str | None = None,
    base_url: str = "https://api.liquid.trade",
    timeout: float = 30.0,
    max_retries: int = 0,
)
```

### Parameters

- `api_key`: Liquid API key
- `api_secret`: Liquid API secret
- `base_url`: REST API base URL
- `timeout`: request timeout in seconds
- `max_retries`: retry count for GET requests on `429` and `5xx`

### Retry Behavior

Retries apply only to `GET` requests.

Retry triggers:

- `429`
- `500`
- `502`
- `503`
- `504`

Backoff behavior:

- exponential backoff
- `Retry-After` respected if present
- small random jitter added

## Authentication And Signing

The SDK mirrors the server's HMAC signing algorithm.

For authenticated requests it automatically sends:

- `X-Liquid-Key`
- `X-Liquid-Timestamp`
- `X-Liquid-Nonce`
- `X-Liquid-Signature`

Signing payload format:

```text
{timestamp}
{nonce}
{METHOD}
{canonical_path}
{canonical_query}
{body_hash}
```

Canonicalization behavior:

- paths are lowercased and trailing slash is removed
- query params are sorted and percent-encoded
- JSON bodies are normalized before hashing

You do not need to manually sign requests when using the SDK client.

## Important Compatibility Notes

### Market Data Auth

Some older SDK comments and examples describe market-data methods as public. The current server implementation in `combined` applies read-scope auth to `/v1/markets/*`, so if you are targeting the current deployed Liquid public API you should supply credentials for all SDK calls except `/v1/health`.

### Transfer Routes

The SDK includes transfer methods today:

- `withdraw`
- `get_transfer_history`

Those routes exist in the server code, but the current public API app does not mount the transfers router yet. Against the current deployed public API, transfer methods may fail until that router is enabled.

## Method Reference

## Market Data

### `get_markets() -> list[dict[str, Any]]`

Returns all tradeable markets.

Returned dict keys currently include:

- `symbol`
- `ticker`
- `exchange`
- `max_leverage`
- `sz_decimals`

### `get_ticker(symbol: str) -> Ticker`

Returns:

- `symbol`
- `mark_price`
- `volume_24h`
- `change_24h`
- `funding_rate`

### `get_orderbook(symbol: str, depth: int = 20) -> Orderbook`

Returns:

- `symbol`
- `bids`
- `asks`
- `timestamp`

Each order book level includes:

- `price`
- `size`
- `count`

### `get_candles(symbol: str, interval: str = "1h", limit: int = 100, start: int | None = None, end: int | None = None) -> list[Candle]`

Valid intervals:

- `1m`
- `5m`
- `15m`
- `30m`
- `1h`
- `4h`
- `1d`

Each candle includes:

- `timestamp`
- `open`
- `high`
- `low`
- `close`
- `volume`

## Account

### `get_account() -> Account`

Returns:

- `equity`
- `margin_used`
- `available_balance`
- `account_value`

### `get_balances() -> Balance`

Returns:

- `exchange`
- `equity`
- `available_balance`
- `margin_used`
- `cross_margin`

`cross_margin` may be `None` or a `CrossMargin` object with:

- `account_value`
- `total_margin_used`
- `total_ntl_pos`

### `get_positions() -> list[Position]`

Each position includes:

- `symbol`
- `side`
- `size`
- `entry_price`
- `leverage`
- `unrealized_pnl`
- `mark_price`
- `liquidation_price`
- `margin_used`

## Orders

### `place_order(...) -> Order`

Signature:

```python
place_order(
    symbol: str,
    side: str,
    type: str = "market",
    size: float = 0.0,
    leverage: int = 1,
    price: float | None = None,
    tp: float | None = None,
    sl: float | None = None,
    reduce_only: bool = False,
    time_in_force: str = "gtc",
) -> Order
```

Important behavior:

- `size` is USD notional
- `side` must be `buy` or `sell`
- `type` must be `market` or `limit`
- `price` is required for limit orders
- `leverage` must be `1..200`
- `time_in_force` must be `gtc` or `ioc`

Returned fields:

- `order_id`
- `symbol`
- `side`
- `type`
- `size`
- `price`
- `leverage`
- `status`
- `exchange`
- `tp`
- `sl`
- `reduce_only`
- `created_at`

### `get_open_orders() -> list[OpenOrder]`

Each open order includes:

- `order_id`
- `symbol`
- `side`
- `size`
- `price`
- `timestamp`

### `get_order(order_id: str) -> Order`

Fetch a specific order by ID.

### `cancel_order(order_id: str) -> bool`

Returns `True` on success.

### `cancel_all_orders() -> int`

Returns the number of cancelled orders when the API returns a list response.

## Positions

### `close_position(symbol: str, size: float | None = None) -> CloseResult`

Behavior:

- omit `size` to fully close the position
- provide `size` to partially close

Important:

- partial close `size` is coin units, not USD notional

### `set_tp_sl(symbol: str, tp: float | None = None, sl: float | None = None) -> TpSlResult`

At least one of `tp` or `sl` must be provided.

### `update_leverage(symbol: str, leverage: int, is_cross: bool = False) -> LeverageResult`

Returned fields:

- `symbol`
- `leverage`
- `is_cross`

### `update_margin(symbol: str, amount: float) -> MarginResult`

Returned fields:

- `symbol`
- `margin_adjusted`

## Transfers

### `withdraw(amount: float, destination: str) -> dict[str, Any]`

Rules:

- `amount` must be positive
- `destination` must be a valid Ethereum address

### `get_transfer_history(limit: int = 50, offset: int = 0) -> TransferPage`

Returned fields:

- `transfers`
- `total`
- `offset`
- `limit`

Each transfer contains:

- `id`
- `type`
- `amount`
- `method`
- `destination`
- `transaction_hash`
- `created_at`

## Model Reference

The SDK exports these primary models:

- `Market`
- `Ticker`
- `OrderbookLevel`
- `Orderbook`
- `Candle`
- `Account`
- `Position`
- `Order`
- `OpenOrder`
- `CloseResult`
- `TpSlResult`
- `MarginResult`
- `LeverageResult`
- `WithdrawResult`
- `Transfer`
- `TransferPage`
- `Balance`

### Numeric Conversion

The API often returns numeric fields as strings. The SDK converts these to Python floats in model factories, which means downstream application code can work with native numeric values instead of parsing strings itself.

## Error Handling

All API and transport exceptions inherit from `LiquidError`.

Common exception types:

- `AuthenticationError`
- `InvalidApiKeyError`
- `InvalidSignatureError`
- `ExpiredTimestampError`
- `ReplayedNonceError`
- `ForbiddenError`
- `IpForbiddenError`
- `InsufficientScopeError`
- `NotFoundError`
- `SymbolNotFoundError`
- `ValidationError`
- `InsufficientBalanceError`
- `OrderRejectedError`
- `RateLimitError`
- `ServerError`
- `ExchangeError`
- `GatewayTimeoutError`
- `ServiceUnavailableError`
- `TimeoutError`
- `ConnectionError`

### Example

```python
from liquid import Client
from liquid import InvalidApiKeyError, InsufficientScopeError, RateLimitError

client = Client(
    api_key="lq_...",
    api_secret="sk_...",
    base_url="https://api.liquid.trade",
)

try:
    client.place_order("BTC-PERP", "buy", size=100, leverage=2)
except InvalidApiKeyError:
    print("API key is invalid")
except InsufficientScopeError:
    print("Key does not have trade scope")
except RateLimitError as exc:
    print(exc.retry_after)
```

### Client-Side Validation

The SDK raises `ValueError` before sending the request when obvious client-side issues are detected, including:

- invalid `side`
- invalid `type`
- invalid `time_in_force`
- invalid leverage range
- non-positive order size
- missing limit price
- invalid withdrawal address

## Demo And Smoke Tests

### Console Demo

```bash
liquidtrading-demo \
  --base-url https://api.liquid.trade \
  --api-key lq_... \
  --api-secret sk_...
```

### Repo Smoke Script

```bash
bash scripts/run_smoke_demo.sh \
  --base-url https://api.liquid.trade \
  --api-key lq_... \
  --api-secret sk_...
```

### Example Script

```bash
uv run python examples/smoke_demo.py \
  --base-url https://api.liquid.trade \
  --api-key lq_... \
  --api-secret sk_...
```

## Packaging And Release Notes

This package is intended to be published independently from the server and MCP repos.

Release order:

1. publish `liquidtrading-python`
2. publish `liquidtrading-mcp`

The MCP package depends on this package by version range, so publishing the SDK first avoids broken downstream installs.

## Source Of Truth In Code

Main implementation files:

- [client.py](/Users/raymondcosgrove/Liquid/Public Apis/liquidtrading-python/liquidtrading/client.py)
- [auth.py](/Users/raymondcosgrove/Liquid/Public Apis/liquidtrading-python/liquidtrading/auth.py)
- [http.py](/Users/raymondcosgrove/Liquid/Public Apis/liquidtrading-python/liquidtrading/http.py)
- [models.py](/Users/raymondcosgrove/Liquid/Public Apis/liquidtrading-python/liquidtrading/models.py)
- [errors.py](/Users/raymondcosgrove/Liquid/Public Apis/liquidtrading-python/liquidtrading/errors.py)
- [pyproject.toml](/Users/raymondcosgrove/Liquid/Public Apis/liquidtrading-python/pyproject.toml)

Related docs:

- [PUBLISHING.md](/Users/raymondcosgrove/Liquid/Public Apis/liquidtrading-python/PUBLISHING.md)
- [REST_API.md](/Users/raymondcosgrove/Liquid/Public Apis/combined/docs/REST_API.md)
- [MCP.md](/Users/raymondcosgrove/Liquid/Public Apis/liquidtrading-mcp/docs/MCP.md)
