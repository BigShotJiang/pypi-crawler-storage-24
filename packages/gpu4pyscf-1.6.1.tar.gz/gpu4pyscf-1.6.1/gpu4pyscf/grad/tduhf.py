# Copyright 2021-2025 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from functools import reduce
import cupy as cp
from pyscf import lib
from gpu4pyscf.lib import logger
from gpu4pyscf.grad import rhf as rhf_grad
from gpu4pyscf.grad import tdrhf
from gpu4pyscf.df import int3c2e
from gpu4pyscf.lib.cupy_helper import contract
from gpu4pyscf.scf import ucphf
from pyscf import __config__
from gpu4pyscf.lib import utils
from gpu4pyscf import tdscf
from gpu4pyscf.scf.jk import _VHFOpt


def grad_elec(td_grad, x_y, singlet=True, atmlst=None, verbose=logger.INFO,
              with_solvent=False):
    """
    Electronic part of TDA, TDHF nuclear gradients

    Args:
        td_grad : grad.tduhf.Gradients or grad.tduks.Gradients object.

        x_y : a two-element list of numpy arrays
            TDDFT X and Y amplitudes. If Y is set to 0, this function computes
            TDA energy gradients.

    Kwargs:
        with_solvent :
            Include the response of solvent in the gradients of the electronic
            energy.
    """
    if singlet is not True and singlet is not None:
        raise NotImplementedError("Only for spin-conserving TDHF")
    log = logger.new_logger(td_grad, verbose)
    time0 = logger.init_timer(td_grad)

    mol = td_grad.mol
    mf = td_grad.base._scf
    mo_coeff = cp.asarray(mf.mo_coeff)
    mo_energy = cp.asarray(mf.mo_energy)
    mo_occ = cp.asarray(mf.mo_occ)
    occidxa = cp.where(mo_occ[0] > 0)[0]
    occidxb = cp.where(mo_occ[1] > 0)[0]
    viridxa = cp.where(mo_occ[0] == 0)[0]
    viridxb = cp.where(mo_occ[1] == 0)[0]
    nocca = len(occidxa)
    noccb = len(occidxb)
    nvira = len(viridxa)
    nvirb = len(viridxb)
    orboa = mo_coeff[0][:, occidxa]
    orbob = mo_coeff[1][:, occidxb]
    orbva = mo_coeff[0][:, viridxa]
    orbvb = mo_coeff[1][:, viridxb]
    nao = mo_coeff[0].shape[0]
    nmoa = nocca + nvira
    nmob = noccb + nvirb

    (xa, xb), (ya, yb) = x_y
    xa = cp.asarray(xa)
    xb = cp.asarray(xb)
    ya = cp.asarray(ya)
    yb = cp.asarray(yb)
    xpya = (xa + ya).reshape(nocca, nvira).T
    xpyb = (xb + yb).reshape(noccb, nvirb).T
    xmya = (xa - ya).reshape(nocca, nvira).T
    xmyb = (xb - yb).reshape(noccb, nvirb).T

    dvva =  contract("ai,bi->ab", xpya, xpya) + contract("ai,bi->ab", xmya, xmya)
    dvvb =  contract("ai,bi->ab", xpyb, xpyb) + contract("ai,bi->ab", xmyb, xmyb)
    dooa = -contract("ai,aj->ij", xpya, xpya) - contract("ai,aj->ij", xmya, xmya)
    doob = -contract("ai,aj->ij", xpyb, xpyb) - contract("ai,aj->ij", xmyb, xmyb)
    dmxpya = reduce(cp.dot, (orbva, xpya, orboa.T))
    dmxpyb = reduce(cp.dot, (orbvb, xpyb, orbob.T))
    dmxmya = reduce(cp.dot, (orbva, xmya, orboa.T))
    dmxmyb = reduce(cp.dot, (orbvb, xmyb, orbob.T))
    dmzooa = reduce(cp.dot, (orboa, dooa, orboa.T))
    dmzoob = reduce(cp.dot, (orbob, doob, orbob.T))
    dmzooa += reduce(cp.dot, (orbva, dvva, orbva.T))
    dmzoob += reduce(cp.dot, (orbvb, dvvb, orbvb.T))
    dmxpy = (dmxpya + dmxpyb)*0.5
    if with_solvent:
        td_grad._dmxpy = dmxpy

    vj0, vk0 = mf.get_jk(mol, cp.stack((dmzooa, dmzoob)), hermi=0)
    vj1, vk1 = mf.get_jk(mol, cp.stack((dmxpya + dmxpya.T, dmxpyb + dmxpyb.T)), hermi=0)
    vj2, vk2 = mf.get_jk(mol, cp.stack((dmxmya - dmxmya.T, dmxmyb - dmxmyb.T)), hermi=0)
    vj0 = cp.asarray(vj0)
    vk0 = cp.asarray(vk0)
    vj1 = cp.asarray(vj1)
    vk1 = cp.asarray(vk1)
    vj2 = cp.asarray(vj2)
    vk2 = cp.asarray(vk2)
    vj = cp.stack((vj0, vj1, vj2), axis=1)
    vk = cp.stack((vk0, vk1, vk2), axis=1)
    vj = vj.reshape(2, 3, nao, nao)
    vk = vk.reshape(2, 3, nao, nao)

    veff0doo = vj[0, 0] + vj[1, 0] - vk[:, 0]
    if with_solvent:
        veff0doo += td_grad.solvent_response((dmzooa + dmzoob)*0.5)
    wvoa = reduce(cp.dot, (orbva.T, veff0doo[0], orboa)) * 2
    wvob = reduce(cp.dot, (orbvb.T, veff0doo[1], orbob)) * 2
    veff = vj[0, 1] + vj[1, 1] - vk[:, 1]
    if with_solvent:
        veff += td_grad.solvent_response((dmxpy + dmxpy.T))
    veff0mopa = reduce(cp.dot, (mo_coeff[0].T, veff[0], mo_coeff[0]))
    veff0mopb = reduce(cp.dot, (mo_coeff[1].T, veff[1], mo_coeff[1]))
    wvoa -= contract("ki,ai->ak", veff0mopa[:nocca, :nocca], xpya) * 2
    wvob -= contract("ki,ai->ak", veff0mopb[:noccb, :noccb], xpyb) * 2
    wvoa += contract("ac,ai->ci", veff0mopa[nocca:, nocca:], xpya) * 2
    wvob += contract("ac,ai->ci", veff0mopb[noccb:, noccb:], xpyb) * 2
    veff = -vk[:, 2]
    veff0moma = reduce(cp.dot, (mo_coeff[0].T, veff[0], mo_coeff[0]))
    veff0momb = reduce(cp.dot, (mo_coeff[1].T, veff[1], mo_coeff[1]))
    wvoa -= contract("ki,ai->ak", veff0moma[:nocca, :nocca], xmya) * 2
    wvob -= contract("ki,ai->ak", veff0momb[:noccb, :noccb], xmyb) * 2
    wvoa += contract("ac,ai->ci", veff0moma[nocca:, nocca:], xmya) * 2
    wvob += contract("ac,ai->ci", veff0momb[noccb:, noccb:], xmyb) * 2

    vresp = td_grad.base.gen_response(hermi=1)

    def fvind(x):
        dm1 = cp.empty((2, nao, nao))
        xa = x[0, : nvira * nocca].reshape(nvira, nocca)
        xb = x[0, nvira * nocca :].reshape(nvirb, noccb)
        dma = reduce(cp.dot, (orbva, xa, orboa.T))
        dmb = reduce(cp.dot, (orbvb, xb, orbob.T))
        dm1[0] = dma + dma.T
        dm1[1] = dmb + dmb.T
        v1 = vresp(dm1)
        v1a = reduce(cp.dot, (orbva.T, v1[0], orboa))
        v1b = reduce(cp.dot, (orbvb.T, v1[1], orbob))
        return cp.hstack((v1a.ravel(), v1b.ravel()))

    z1a, z1b = ucphf.solve(
        fvind,
        mo_energy,
        mo_occ,
        (wvoa, wvob),
        max_cycle=td_grad.cphf_max_cycle,
        tol=td_grad.cphf_conv_tol)[0]
    time1 = log.timer('Z-vector using UCPHF solver', *time0)

    z1ao = cp.empty((2, nao, nao))
    z1ao[0] = reduce(cp.dot, (orbva, z1a, orboa.T))
    z1ao[1] = reduce(cp.dot, (orbvb, z1b, orbob.T))
    veff = vresp((z1ao + z1ao.transpose(0, 2, 1)) * 0.5)

    im0a = cp.zeros((nmoa, nmoa))
    im0b = cp.zeros((nmob, nmob))
    im0a[:nocca, :nocca] = reduce(cp.dot, (orboa.T, veff0doo[0] + veff[0], orboa)) * 0.5
    im0b[:noccb, :noccb] = reduce(cp.dot, (orbob.T, veff0doo[1] + veff[1], orbob)) * 0.5
    im0a[:nocca, :nocca] += contract("ak,ai->ki", veff0mopa[nocca:, :nocca], xpya) * 0.5
    im0b[:noccb, :noccb] += contract("ak,ai->ki", veff0mopb[noccb:, :noccb], xpyb) * 0.5
    im0a[:nocca, :nocca] += contract("ak,ai->ki", veff0moma[nocca:, :nocca], xmya) * 0.5
    im0b[:noccb, :noccb] += contract("ak,ai->ki", veff0momb[noccb:, :noccb], xmyb) * 0.5
    im0a[nocca:, nocca:]  = contract("ci,ai->ac", veff0mopa[nocca:, :nocca], xpya) * 0.5
    im0b[noccb:, noccb:]  = contract("ci,ai->ac", veff0mopb[noccb:, :noccb], xpyb) * 0.5
    im0a[nocca:, nocca:] += contract("ci,ai->ac", veff0moma[nocca:, :nocca], xmya) * 0.5
    im0b[noccb:, noccb:] += contract("ci,ai->ac", veff0momb[noccb:, :noccb], xmyb) * 0.5
    im0a[nocca:, :nocca]  = contract("ki,ai->ak", veff0mopa[:nocca, :nocca], xpya)
    im0b[noccb:, :noccb]  = contract("ki,ai->ak", veff0mopb[:noccb, :noccb], xpyb)
    im0a[nocca:, :nocca] += contract("ki,ai->ak", veff0moma[:nocca, :nocca], xmya)
    im0b[noccb:, :noccb] += contract("ki,ai->ak", veff0momb[:noccb, :noccb], xmyb)

    zeta_a = (mo_energy[0][:, None] + mo_energy[0]) * 0.5
    zeta_b = (mo_energy[1][:, None] + mo_energy[1]) * 0.5
    zeta_a[nocca:, :nocca] = mo_energy[0][:nocca]
    zeta_b[noccb:, :noccb] = mo_energy[1][:noccb]
    zeta_a[:nocca, nocca:] = mo_energy[0][nocca:]
    zeta_b[:noccb, noccb:] = mo_energy[1][noccb:]
    dm1a = cp.zeros((nmoa, nmoa))
    dm1b = cp.zeros((nmob, nmob))
    dm1a[:nocca, :nocca] = dooa * 0.5
    dm1b[:noccb, :noccb] = doob * 0.5
    dm1a[nocca:, nocca:] = dvva * 0.5
    dm1b[noccb:, noccb:] = dvvb * 0.5
    dm1a[nocca:, :nocca] = z1a * 0.5
    dm1b[noccb:, :noccb] = z1b * 0.5
    dm1a[:nocca, :nocca] += cp.eye(nocca)  # for ground state
    dm1b[:noccb, :noccb] += cp.eye(noccb)
    im0a = reduce(cp.dot, (mo_coeff[0], im0a + zeta_a * dm1a, mo_coeff[0].T))
    im0b = reduce(cp.dot, (mo_coeff[1], im0b + zeta_b * dm1b, mo_coeff[1].T))
    im0 = im0a + im0b

    dmz1dooa = z1ao[0] + dmzooa
    dmz1doob = z1ao[1] + dmzoob
    if with_solvent:
        td_grad._dmz1doo = (dmz1dooa + dmz1doob)*0.5
    oo0a = reduce(cp.dot, (orboa, orboa.T))
    oo0b = reduce(cp.dot, (orbob, orbob.T))

    # Initialize hcore_deriv with the underlying SCF object because some
    # extensions (e.g. QM/MM, solvent) modifies the SCF object only.
    mf_grad = td_grad.base._scf.nuc_grad_method()
    h1 = cp.asarray(mf_grad.get_hcore(mol))  # without 1/r like terms
    s1 = cp.asarray(mf_grad.get_ovlp(mol))
    dh_ground = rhf_grad.contract_h1e_dm(mol, h1, oo0a + oo0b, hermi=1)
    dh_td = rhf_grad.contract_h1e_dm(mol, h1, dmz1dooa + dmz1doob, hermi=0) * 0.5
    ds = rhf_grad.contract_h1e_dm(mol, s1, im0, hermi=0)

    dh1e_ground = int3c2e.get_dh1e(mol, oo0a + oo0b)  # 1/r like terms
    if len(mol._ecpbas) > 0:
        dh1e_ground += rhf_grad.get_dh1e_ecp(mol, oo0a + oo0b)  # 1/r like terms
    dh1e_td = int3c2e.get_dh1e(mol, (dmz1dooa + dmz1doob) * 0.25 + (dmz1dooa + dmz1doob).T * 0.25)  # 1/r like terms
    if len(mol._ecpbas) > 0:
        dh1e_td += rhf_grad.get_dh1e_ecp(
            mol, (dmz1dooa + dmz1doob) * 0.25 + (dmz1dooa + dmz1doob).T * 0.25
        )  # 1/r like terms

    if mol._pseudo:
        raise NotImplementedError("Pseudopotential gradient not supported for molecular system yet")

    # this term contributes the ground state contribution.
    dvhf = td_grad.get_veff(
        mol, cp.stack((((dmz1dooa + dmz1dooa.T) * 0.25 + oo0a,
                        (dmz1doob + dmz1doob.T) * 0.25 + oo0b))), hermi=1)
    # this term will remove the unused-part from PP density.
    dvhf -= td_grad.get_veff(
        mol, cp.stack((((dmz1dooa + dmz1dooa.T) * 0.25,
                        (dmz1doob + dmz1doob.T) * 0.25))), hermi=1)
    dvhf += 2 * td_grad.get_veff(
        mol, cp.stack((((dmxpya + dmxpya.T) * 0.5,
                        (dmxpyb + dmxpyb.T) * 0.5))), hermi=1)
    dvhf -= 2 * td_grad.get_veff(
        mol, cp.stack((((dmxmya - dmxmya.T) * 0.5,
                        (dmxmyb - dmxmyb.T) * 0.5))), j_factor=0.0, hermi=2)
    time1 = log.timer('2e AO integral derivatives', *time1)

    de = dh_ground + dh_td - ds + 2 * dvhf
    de += cp.asnumpy(dh1e_ground + dh1e_td)
    if atmlst is not None:
        de = de[atmlst]
    log.timer("TDUHF nuclear gradients", *time0)
    return de


class Gradients(rhf_grad.GradientsBase):

    cphf_max_cycle = tdrhf.Gradients.cphf_max_cycle
    cphf_conv_tol = tdrhf.Gradients.cphf_conv_tol

    _keys = tdrhf.Gradients._keys

    to_cpu = utils.to_cpu
    to_gpu = utils.to_gpu
    device = utils.device

    dump_flags = tdrhf.Gradients.dump_flags
    kernel = tdrhf.Gradients.kernel
    grad_nuc = tdrhf.Gradients.grad_nuc
    _finalize = tdrhf.Gradients._finalize
    solvent_response = tdrhf.Gradients.solvent_response
    as_scanner = tdrhf.Gradients.as_scanner
    from_cpu = tdrhf.Gradients.from_cpu

    grad_elec = grad_elec

    def __init__(self, td):
        super().__init__(td)
        self.verbose = td.verbose
        self.stdout = td.stdout
        self.mol = td.mol
        self.base = td
        self.state = 1  # of which the gradients to be computed.
        self.atmlst = None
        self.de = None

    def get_veff(self, mol, dm, j_factor=1.0, k_factor=1.0, omega=0.0,
                 hermi=0, verbose=None):
        """
        Computes the first-order derivatives of the energy contributions from
        Veff per atom.

        NOTE: This function is incompatible to the one implemented in PySCF CPU version.
        In the CPU version, get_veff returns the first order derivatives of Veff matrix.
        """
        if dm is None: dm = self.base.make_rdm1()
        if hermi == 2:
            j_factor = 0
        mf = self.base._scf
        vhfopt = mf._opt_gpu.get(omega)
        if vhfopt is None:
            # For LDA and GGA, only mf._opt_jengine is initialized
            mol = mf.mol
            with mol.with_range_coulomb(omega):
                vhfopt = mf._opt_gpu[omega] = _VHFOpt(
                    mol, mf.direct_scf_tol, tile=1).build()
        return rhf_grad._jk_energy_per_atom(
            vhfopt, dm, j_factor, k_factor, verbose) * .5

    def jk_energy_per_atom(self, dms, j_factor=None, k_factor=None, omega=0,
                           hermi=0, sum_results=True, verbose=None):
        raise NotImplementedError

    def jk_energies_per_atom(self, dm_list, j_factor=None, k_factor=None, omega=0,
                             hermi=0, sum_results=False, verbose=None):
        raise NotImplementedError

Grad = Gradients
