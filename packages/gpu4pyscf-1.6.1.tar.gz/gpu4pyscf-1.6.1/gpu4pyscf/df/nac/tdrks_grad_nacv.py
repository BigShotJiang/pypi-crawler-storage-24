# Copyright 2021-2025 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from gpu4pyscf.nac import tdrks_grad_nacv as tdrks_grad_nacv_nac
from gpu4pyscf.df.grad import tdrks as tdrks_grad_df

class NAC_multistates(tdrks_grad_nacv_nac.NAC_multistates):

    _keys = {'with_df', 'auxbasis_response'}

    auxbasis_response = True

    check_sanity = tdrks_grad_df.Gradients.check_sanity
    jk_energy_per_atom = tdrks_grad_df.Gradients.jk_energy_per_atom
    jk_energies_per_atom = tdrks_grad_df.Gradients.jk_energies_per_atom
