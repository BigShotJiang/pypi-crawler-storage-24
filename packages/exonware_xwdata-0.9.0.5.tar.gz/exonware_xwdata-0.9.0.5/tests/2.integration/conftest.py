#!/usr/bin/env python3
"""
#exonware/xwdata/tests/2.integration/conftest.py
Integration test fixtures.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.3
Generation Date: 26-Oct-2025
"""

import pytest
