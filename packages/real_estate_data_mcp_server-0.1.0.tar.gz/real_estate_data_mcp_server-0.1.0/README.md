# real-estate-data-mcp-server

<!-- mcp-name: real-estate-data-mcp-server -->

MCP server providing US real estate data — housing statistics, demographics, nearby amenities, area comparisons, cost-of-living analysis, and neighborhood search.

All data comes from **free, public APIs** — no API keys required:
- **US Census ACS 5-Year** (2022) for housing and demographic data
- **OpenStreetMap Nominatim** for geocoding
- **Overpass API** for nearby amenities (schools, hospitals, parks, transit)

[![Glama MCP Server](https://glama.ai/mcp/servers/badge)](https://glama.ai/mcp/servers)

## Tools

| Tool | Description |
|------|-------------|
| `get_housing_stats` | Median home value, rent, vacancy rates, owner-occupied % for any US state or county |
| `get_area_demographics` | Population, income, education, employment, age stats from Census ACS |
| `get_nearby_amenities` | Schools, hospitals, parks, transit stops, supermarkets via OpenStreetMap |
| `compare_areas` | Side-by-side comparison of housing metrics for 2-5 locations |
| `get_cost_of_living` | Housing affordability index, cost burden analysis, national comparison |
| `search_neighborhoods` | Find neighborhoods/places in a city with key housing stats |

## Installation

```bash
pip install real-estate-data-mcp-server
```

## Usage with Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "real-estate": {
      "command": "real-estate-server"
    }
  }
}
```

## Usage with Claude Code

```bash
claude mcp add real-estate -- real-estate-server
```

## Example Queries

- "What are the housing stats for California?"
- "Compare housing costs between Texas and New York"
- "Find amenities near downtown San Francisco (37.7749, -122.4194)"
- "What's the cost of living in Colorado?"
- "Search neighborhoods in Austin, TX"
- "Get demographics for Harris County, Texas (county code 201)"

## US State Codes

States can be specified by full name or abbreviation:
- `"California"` or `"CA"`
- `"New York"` or `"NY"`
- `"Texas"` or `"TX"`

Counties require 3-digit FIPS codes (e.g., `"073"` for San Diego County, CA).

## Data Sources

- **US Census Bureau** — American Community Survey 5-Year Estimates (2022)
- **OpenStreetMap** — Nominatim geocoding + Overpass amenity queries
- All APIs are free and require no authentication for basic usage

## License

MIT
