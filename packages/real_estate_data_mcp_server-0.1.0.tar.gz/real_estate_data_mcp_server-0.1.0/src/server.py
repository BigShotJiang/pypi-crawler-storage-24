"""
Real Estate Data MCP Server.
Gibt AI-Agents Zugriff auf US-Immobiliendaten: Housing Stats, Demographics,
Amenities, Area Comparisons, Cost of Living und Neighborhood Search.
"""

from mcp.server.fastmcp import FastMCP
from src.tools.realestate import register_tools

# Server initialisieren
mcp = FastMCP(
    "Real Estate Data MCP Server",
    instructions="""US real estate data server providing housing statistics,
demographics, nearby amenities, area comparisons, cost-of-living analysis,
and neighborhood search. Uses US Census ACS data and OpenStreetMap.

States can be specified by full name (e.g., "California") or abbreviation ("CA").
Counties require 3-digit FIPS codes. Use search_neighborhoods to explore areas.""",
)

# Alle Tools registrieren
register_tools(mcp)


def main():
    """Startet den MCP-Server über stdio-Transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
