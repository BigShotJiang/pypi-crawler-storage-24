"""
Konfiguration für den Real Estate MCP Server.
Lädt Umgebungsvariablen und stellt Settings bereit.
"""

import os

# Census API Key (optional — Basis-Queries gehen auch ohne)
CENSUS_API_KEY = os.getenv("CENSUS_API_KEY", "")

# Census ACS 5-Year Endpunkt (2022 ist aktuellstes)
CENSUS_ACS_BASE = "https://api.census.gov/data/2022/acs/acs5"

# OpenStreetMap Nominatim für Geocoding
NOMINATIM_BASE = "https://nominatim.openstreetmap.org"

# Overpass API für Amenity-Queries
OVERPASS_BASE = "https://overpass-api.de/api/interpreter"

# User-Agent für Nominatim (Pflicht laut OSM-Policy)
USER_AGENT = "RealEstateMCPServer/0.1.0 (https://github.com/AiAgentKarl/real-estate-data-mcp-server)"

# Request-Timeouts in Sekunden
REQUEST_TIMEOUT = 30

# FIPS-Codes für alle 50 US-Bundesstaaten + DC
STATE_FIPS = {
    "alabama": "01", "al": "01",
    "alaska": "02", "ak": "02",
    "arizona": "04", "az": "04",
    "arkansas": "05", "ar": "05",
    "california": "06", "ca": "06",
    "colorado": "08", "co": "08",
    "connecticut": "09", "ct": "09",
    "delaware": "10", "de": "10",
    "district of columbia": "11", "dc": "11",
    "florida": "12", "fl": "12",
    "georgia": "13", "ga": "13",
    "hawaii": "15", "hi": "15",
    "idaho": "16", "id": "16",
    "illinois": "17", "il": "17",
    "indiana": "18", "in": "18",
    "iowa": "19", "ia": "19",
    "kansas": "20", "ks": "20",
    "kentucky": "21", "ky": "21",
    "louisiana": "22", "la": "22",
    "maine": "23", "me": "23",
    "maryland": "24", "md": "24",
    "massachusetts": "25", "ma": "25",
    "michigan": "26", "mi": "26",
    "minnesota": "27", "mn": "27",
    "mississippi": "28", "ms": "28",
    "missouri": "29", "mo": "29",
    "montana": "30", "mt": "30",
    "nebraska": "31", "ne": "31",
    "nevada": "32", "nv": "32",
    "new hampshire": "33", "nh": "33",
    "new jersey": "34", "nj": "34",
    "new mexico": "35", "nm": "35",
    "new york": "36", "ny": "36",
    "north carolina": "37", "nc": "37",
    "north dakota": "38", "nd": "38",
    "ohio": "39", "oh": "39",
    "oklahoma": "40", "ok": "40",
    "oregon": "41", "or": "41",
    "pennsylvania": "42", "pa": "42",
    "rhode island": "44", "ri": "44",
    "south carolina": "45", "sc": "45",
    "south dakota": "46", "sd": "46",
    "tennessee": "47", "tn": "47",
    "texas": "48", "tx": "48",
    "utah": "49", "ut": "49",
    "vermont": "50", "vt": "50",
    "virginia": "51", "va": "51",
    "washington": "53", "wa": "53",
    "west virginia": "54", "wv": "54",
    "wisconsin": "55", "wi": "55",
    "wyoming": "56", "wy": "56",
}

# Mapping von FIPS-Code zurück zu Staatsname
FIPS_TO_STATE = {
    "01": "Alabama", "02": "Alaska", "04": "Arizona", "05": "Arkansas",
    "06": "California", "08": "Colorado", "09": "Connecticut", "10": "Delaware",
    "11": "District of Columbia", "12": "Florida", "13": "Georgia", "15": "Hawaii",
    "16": "Idaho", "17": "Illinois", "18": "Indiana", "19": "Iowa",
    "20": "Kansas", "21": "Kentucky", "22": "Louisiana", "23": "Maine",
    "24": "Maryland", "25": "Massachusetts", "26": "Michigan", "27": "Minnesota",
    "28": "Mississippi", "29": "Missouri", "30": "Montana", "31": "Nebraska",
    "32": "Nevada", "33": "New Hampshire", "34": "New Jersey", "35": "New Mexico",
    "36": "New York", "37": "North Carolina", "38": "North Dakota", "39": "Ohio",
    "40": "Oklahoma", "41": "Oregon", "42": "Pennsylvania", "44": "Rhode Island",
    "45": "South Carolina", "46": "South Dakota", "47": "Tennessee", "48": "Texas",
    "49": "Utah", "50": "Vermont", "51": "Virginia", "53": "Washington",
    "54": "West Virginia", "55": "Wisconsin", "56": "Wyoming",
}
