"""
MCP-Tool-Definitionen für Real Estate Daten.
6 Tools: Housing Stats, Demographics, Amenities, Compare, Cost of Living, Neighborhoods.
"""

from mcp.server.fastmcp import FastMCP
from typing import Optional
from src.config import STATE_FIPS, FIPS_TO_STATE
from src.clients.realestate import (
    fetch_census_data, fetch_census_counties, fetch_census_places,
    geocode_location, fetch_nearby_amenities
)


def _resolve_state_fips(state: str) -> Optional[str]:
    """Löst einen Staatsnamen oder Kürzel in FIPS-Code auf."""
    return STATE_FIPS.get(state.lower().strip())


def _safe_int(value) -> Optional[int]:
    """Konvertiert Census-Wert zu int, None bei fehlenden Daten."""
    try:
        val = int(value)
        return val if val >= 0 else None
    except (ValueError, TypeError):
        return None


def _safe_float(value) -> Optional[float]:
    """Konvertiert Census-Wert zu float, None bei fehlenden Daten."""
    try:
        val = float(value)
        return val if val >= 0 else None
    except (ValueError, TypeError):
        return None


def _format_currency(value: Optional[int]) -> str:
    """Formatiert Zahl als USD-Wert."""
    if value is None:
        return "N/A"
    return f"${value:,}"


def _format_percent(value: Optional[float]) -> str:
    """Formatiert Zahl als Prozent."""
    if value is None:
        return "N/A"
    return f"{value:.1f}%"


def register_tools(mcp: FastMCP):
    """Registriert alle Real-Estate-Tools beim MCP-Server."""

    @mcp.tool()
    async def get_housing_stats(state: str, county: Optional[str] = None) -> str:
        """Get housing statistics for a US state or county.

        Returns median home value, median rent, vacancy rates, and
        owner-occupied percentage from the US Census ACS 5-Year survey.

        Args:
            state: US state name or abbreviation (e.g., "California" or "CA")
            county: Optional 3-digit FIPS county code (e.g., "073" for San Diego)
        """
        fips = _resolve_state_fips(state)
        if not fips:
            return f"Fehler: Bundesstaat '{state}' nicht erkannt. Nutze z.B. 'California' oder 'CA'."

        # Census-Variablen für Housing
        variables = [
            "B25077_001E",  # Median Home Value
            "B25064_001E",  # Median Gross Rent
            "B25002_001E",  # Total Housing Units
            "B25002_003E",  # Vacant Housing Units
            "B25003_001E",  # Total Occupied Units
            "B25003_002E",  # Owner-Occupied Units
            "B25003_003E",  # Renter-Occupied Units
            "B25071_001E",  # Median Gross Rent as % of Income
        ]

        try:
            data = await fetch_census_data(variables, fips, county)
        except Exception as e:
            return f"Fehler beim Abrufen der Census-Daten: {str(e)}"

        if not data or len(data) < 2:
            return "Keine Daten für diesen Bereich gefunden."

        header = data[0]
        row = data[1]

        # Werte zuordnen
        values = {}
        for i, col in enumerate(header):
            values[col] = row[i]

        name = values.get("NAME", "Unbekannt")
        median_home = _safe_int(values.get("B25077_001E"))
        median_rent = _safe_int(values.get("B25064_001E"))
        total_units = _safe_int(values.get("B25002_001E"))
        vacant_units = _safe_int(values.get("B25002_003E"))
        occupied_units = _safe_int(values.get("B25003_001E"))
        owner_units = _safe_int(values.get("B25003_002E"))
        renter_units = _safe_int(values.get("B25003_003E"))
        rent_pct_income = _safe_float(values.get("B25071_001E"))

        # Berechnete Werte
        vacancy_rate = None
        if total_units and vacant_units is not None:
            vacancy_rate = (vacant_units / total_units) * 100

        owner_pct = None
        if occupied_units and owner_units is not None:
            owner_pct = (owner_units / occupied_units) * 100

        renter_pct = None
        if occupied_units and renter_units is not None:
            renter_pct = (renter_units / occupied_units) * 100

        result = f"""🏠 Housing Statistics: {name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💰 Median Home Value:     {_format_currency(median_home)}
🏘️ Median Gross Rent:     {_format_currency(median_rent)}
📊 Rent as % of Income:   {_format_percent(rent_pct_income)}

🏗️ Total Housing Units:   {total_units:,}
   ├─ Occupied:           {occupied_units:,} ({_format_percent(100 - vacancy_rate if vacancy_rate else None)})
   ├─ Vacant:             {vacant_units:,} ({_format_percent(vacancy_rate)})
   ├─ Owner-Occupied:     {owner_units:,} ({_format_percent(owner_pct)})
   └─ Renter-Occupied:    {renter_units:,} ({_format_percent(renter_pct)})

📅 Source: US Census ACS 5-Year (2022)"""

        return result

    @mcp.tool()
    async def get_area_demographics(state: str, county: Optional[str] = None) -> str:
        """Get demographic data for a US state or county.

        Returns population, median income, education levels, employment
        stats, and age distribution from the US Census ACS.

        Args:
            state: US state name or abbreviation (e.g., "Texas" or "TX")
            county: Optional 3-digit FIPS county code (e.g., "201" for Harris County)
        """
        fips = _resolve_state_fips(state)
        if not fips:
            return f"Fehler: Bundesstaat '{state}' nicht erkannt. Nutze z.B. 'Texas' oder 'TX'."

        variables = [
            "B01003_001E",  # Total Population
            "B19013_001E",  # Median Household Income
            "B19301_001E",  # Per Capita Income
            "B15003_022E",  # Bachelor's Degree
            "B15003_023E",  # Master's Degree
            "B15003_025E",  # Doctorate
            "B15003_001E",  # Total Population 25+
            "B23025_003E",  # In Labor Force (Civilian)
            "B23025_005E",  # Unemployed
            "B23025_001E",  # Total 16+ Population
            "B01002_001E",  # Median Age
        ]

        try:
            data = await fetch_census_data(variables, fips, county)
        except Exception as e:
            return f"Fehler beim Abrufen der Census-Daten: {str(e)}"

        if not data or len(data) < 2:
            return "Keine Daten für diesen Bereich gefunden."

        header = data[0]
        row = data[1]
        values = {header[i]: row[i] for i in range(len(header))}

        name = values.get("NAME", "Unbekannt")
        population = _safe_int(values.get("B01003_001E"))
        median_income = _safe_int(values.get("B19013_001E"))
        per_capita = _safe_int(values.get("B19301_001E"))
        bachelors = _safe_int(values.get("B15003_022E"))
        masters = _safe_int(values.get("B15003_023E"))
        doctorate = _safe_int(values.get("B15003_025E"))
        edu_total = _safe_int(values.get("B15003_001E"))
        labor_force = _safe_int(values.get("B23025_003E"))
        unemployed = _safe_int(values.get("B23025_005E"))
        total_16plus = _safe_int(values.get("B23025_001E"))
        median_age = _safe_float(values.get("B01002_001E"))

        # Berechnungen
        college_pct = None
        if edu_total and bachelors is not None and masters is not None and doctorate is not None:
            college_total = bachelors + masters + doctorate
            college_pct = (college_total / edu_total) * 100

        unemployment_rate = None
        if labor_force and unemployed is not None:
            unemployment_rate = (unemployed / labor_force) * 100

        labor_participation = None
        if total_16plus and labor_force is not None:
            labor_participation = (labor_force / total_16plus) * 100

        result = f"""👥 Demographics: {name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 Population:              {population:,}
🎂 Median Age:              {median_age if median_age else 'N/A'}

💵 Median Household Income: {_format_currency(median_income)}
💰 Per Capita Income:       {_format_currency(per_capita)}

🎓 Education (25+ years):
   ├─ College Degree+:      {_format_percent(college_pct)}
   ├─ Bachelor's:           {bachelors:,}
   ├─ Master's:             {masters:,}
   └─ Doctorate:            {doctorate:,}

💼 Employment (16+ years):
   ├─ Labor Participation:  {_format_percent(labor_participation)}
   ├─ Unemployment Rate:    {_format_percent(unemployment_rate)}
   └─ Civilian Labor Force: {labor_force:,}

📅 Source: US Census ACS 5-Year (2022)"""

        return result

    @mcp.tool()
    async def get_nearby_amenities(lat: float, lon: float, radius_m: int = 2000) -> str:
        """Find nearby amenities around a location using OpenStreetMap.

        Returns schools, hospitals, parks, transit stops, supermarkets,
        restaurants, and pharmacies within the specified radius.

        Args:
            lat: Latitude of the location
            lon: Longitude of the location
            radius_m: Search radius in meters (default: 2000, max: 5000)
        """
        if radius_m > 5000:
            radius_m = 5000
        if radius_m < 100:
            radius_m = 100

        try:
            categories = await fetch_nearby_amenities(lat, lon, radius_m)
        except Exception as e:
            return f"Fehler beim Abrufen der Amenities: {str(e)}"

        total = sum(len(v) for v in categories.values())

        result = f"""📍 Nearby Amenities ({lat:.4f}, {lon:.4f}) — {radius_m}m radius
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total: {total} amenities found\n"""

        # Schulen
        schools = categories.get("schools", [])
        result += f"\n🏫 Schools ({len(schools)}):\n"
        if schools:
            for s in schools[:10]:
                result += f"   • {s['name']}\n"
            if len(schools) > 10:
                result += f"   ... und {len(schools) - 10} weitere\n"
        else:
            result += "   Keine gefunden\n"

        # Krankenhäuser
        hospitals = categories.get("hospitals", [])
        result += f"\n🏥 Hospitals & Clinics ({len(hospitals)}):\n"
        if hospitals:
            for h in hospitals[:5]:
                result += f"   • {h['name']}\n"
        else:
            result += "   Keine gefunden\n"

        # Parks
        parks = categories.get("parks", [])
        result += f"\n🌳 Parks ({len(parks)}):\n"
        if parks:
            for p in parks[:10]:
                result += f"   • {p['name']}\n"
            if len(parks) > 10:
                result += f"   ... und {len(parks) - 10} weitere\n"
        else:
            result += "   Keine gefunden\n"

        # ÖPNV
        transit = categories.get("transit_stops", [])
        result += f"\n🚌 Transit Stops ({len(transit)}):\n"
        if transit:
            for t in transit[:10]:
                t_type = t.get("type", "stop")
                result += f"   • {t['name']} ({t_type})\n"
            if len(transit) > 10:
                result += f"   ... und {len(transit) - 10} weitere\n"
        else:
            result += "   Keine gefunden\n"

        # Supermärkte
        supermarkets = categories.get("supermarkets", [])
        result += f"\n🛒 Supermarkets ({len(supermarkets)}):\n"
        if supermarkets:
            for s in supermarkets[:5]:
                result += f"   • {s['name']}\n"
        else:
            result += "   Keine gefunden\n"

        # Restaurants
        restaurants = categories.get("restaurants", [])
        result += f"\n🍽️ Restaurants ({len(restaurants)}):\n"
        if restaurants:
            for r in restaurants[:10]:
                result += f"   • {r['name']}\n"
            if len(restaurants) > 10:
                result += f"   ... und {len(restaurants) - 10} weitere\n"
        else:
            result += "   Keine gefunden\n"

        # Apotheken
        pharmacies = categories.get("pharmacies", [])
        result += f"\n💊 Pharmacies ({len(pharmacies)}):\n"
        if pharmacies:
            for p in pharmacies[:5]:
                result += f"   • {p['name']}\n"
        else:
            result += "   Keine gefunden\n"

        result += "\n📅 Source: OpenStreetMap / Overpass API"
        return result

    @mcp.tool()
    async def compare_areas(locations: list[dict]) -> str:
        """Compare housing metrics for multiple US areas side-by-side.

        Compares median home value, rent, income, population, and
        affordability for 2-5 different locations.

        Args:
            locations: List of location dicts, each with 'state' (required)
                      and optional 'county' FIPS code.
                      Example: [{"state": "CA"}, {"state": "TX", "county": "201"}]
        """
        if len(locations) < 2:
            return "Bitte mindestens 2 Standorte zum Vergleichen angeben."
        if len(locations) > 5:
            return "Maximal 5 Standorte gleichzeitig vergleichbar."

        variables = [
            "B25077_001E",  # Median Home Value
            "B25064_001E",  # Median Gross Rent
            "B19013_001E",  # Median Household Income
            "B01003_001E",  # Total Population
            "B25071_001E",  # Rent as % of Income
        ]

        results = []
        for loc in locations:
            state = loc.get("state", "")
            county = loc.get("county")
            fips = _resolve_state_fips(state)

            if not fips:
                results.append({"name": f"? ({state})", "error": True})
                continue

            try:
                data = await fetch_census_data(variables, fips, county)
                if data and len(data) >= 2:
                    header = data[0]
                    row = data[1]
                    values = {header[i]: row[i] for i in range(len(header))}

                    results.append({
                        "name": values.get("NAME", "Unbekannt"),
                        "home_value": _safe_int(values.get("B25077_001E")),
                        "rent": _safe_int(values.get("B25064_001E")),
                        "income": _safe_int(values.get("B19013_001E")),
                        "population": _safe_int(values.get("B01003_001E")),
                        "rent_pct": _safe_float(values.get("B25071_001E")),
                        "error": False,
                    })
                else:
                    results.append({"name": f"? ({state})", "error": True})
            except Exception:
                results.append({"name": f"? ({state})", "error": True})

        # Vergleichstabelle formatieren
        output = "📊 Area Comparison\n"
        output += "━" * 60 + "\n\n"

        # Header
        names = [r["name"][:25] for r in results]
        output += f"{'Metric':<25}" + "".join(f"{n:<25}" for n in names) + "\n"
        output += "─" * (25 + 25 * len(results)) + "\n"

        # Zeilen
        metrics = [
            ("Median Home Value", "home_value", _format_currency),
            ("Median Rent", "rent", _format_currency),
            ("Median Income", "income", _format_currency),
            ("Population", "population", lambda v: f"{v:,}" if v else "N/A"),
            ("Rent % of Income", "rent_pct", _format_percent),
        ]

        for label, key, fmt_fn in metrics:
            output += f"{label:<25}"
            for r in results:
                if r.get("error"):
                    output += f"{'Fehler':<25}"
                else:
                    output += f"{fmt_fn(r.get(key)):<25}"
            output += "\n"

        # Affordability Score (Einkommen / Hauswert)
        output += f"\n{'Affordability Ratio':<25}"
        for r in results:
            if r.get("error") or not r.get("income") or not r.get("home_value"):
                output += f"{'N/A':<25}"
            else:
                ratio = r["home_value"] / r["income"]
                output += f"{ratio:.1f}x Income{'':<15}"
        output += "\n"

        output += f"\n📅 Source: US Census ACS 5-Year (2022)"
        return output

    @mcp.tool()
    async def get_cost_of_living(state: str) -> str:
        """Get housing affordability and cost-of-living indicators for a US state.

        Returns housing costs relative to income, affordability index,
        housing burden analysis, and cost comparisons.

        Args:
            state: US state name or abbreviation (e.g., "New York" or "NY")
        """
        fips = _resolve_state_fips(state)
        if not fips:
            return f"Fehler: Bundesstaat '{state}' nicht erkannt."

        variables = [
            "B25077_001E",  # Median Home Value
            "B25064_001E",  # Median Gross Rent
            "B19013_001E",  # Median Household Income
            "B25071_001E",  # Median Gross Rent as % of Income
            "B25092_001E",  # Median Owner Costs as % of Income (with mortgage)
            "B25088_001E",  # Median Monthly Owner Costs (with mortgage)
            "B25105_001E",  # Median Monthly Housing Costs
        ]

        # Daten für Staat UND National holen
        try:
            state_data = await fetch_census_data(variables, fips)
        except Exception as e:
            return f"Fehler beim Abrufen der Daten: {str(e)}"

        # Nationale Durchschnittswerte (hart codiert aus Census 2022)
        national = {
            "median_home": 281900,
            "median_rent": 1163,
            "median_income": 74580,
            "rent_pct_income": 31.0,
            "owner_cost_pct": 21.7,
        }

        if not state_data or len(state_data) < 2:
            return "Keine Daten gefunden."

        header = state_data[0]
        row = state_data[1]
        values = {header[i]: row[i] for i in range(len(header))}

        name = values.get("NAME", "Unbekannt")
        median_home = _safe_int(values.get("B25077_001E"))
        median_rent = _safe_int(values.get("B25064_001E"))
        median_income = _safe_int(values.get("B19013_001E"))
        rent_pct = _safe_float(values.get("B25071_001E"))
        owner_cost_pct = _safe_float(values.get("B25092_001E"))
        monthly_owner = _safe_int(values.get("B25088_001E"))
        monthly_housing = _safe_int(values.get("B25105_001E"))

        # Affordability Index (100 = Durchschnitt)
        afford_index = None
        if median_home and median_income:
            national_ratio = national["median_home"] / national["median_income"]
            state_ratio = median_home / median_income
            afford_index = (national_ratio / state_ratio) * 100

        # Housing Burden Einschätzung
        def burden_level(pct):
            if pct is None:
                return "N/A"
            if pct < 25:
                return "Affordable"
            elif pct < 30:
                return "Moderate"
            elif pct < 35:
                return "Burdened"
            else:
                return "Severely Burdened"

        # Vergleich mit National
        def vs_national(value, nat_value, is_inverse=False):
            if value is None:
                return ""
            diff = ((value - nat_value) / nat_value) * 100
            if is_inverse:
                diff = -diff
            sign = "+" if diff > 0 else ""
            return f" ({sign}{diff:.1f}% vs. national)"

        result = f"""💲 Cost of Living: {name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏠 Housing Costs:
   Median Home Value:       {_format_currency(median_home)}{vs_national(median_home, national['median_home'])}
   Median Rent:             {_format_currency(median_rent)}{vs_national(median_rent, national['median_rent'])}
   Monthly Owner Costs:     {_format_currency(monthly_owner)}
   Monthly Housing Costs:   {_format_currency(monthly_housing)}

💰 Income:
   Median Household Income: {_format_currency(median_income)}{vs_national(median_income, national['median_income'])}

📊 Affordability Analysis:
   Affordability Index:     {f'{afford_index:.0f}' if afford_index else 'N/A'} (100 = US avg, higher = more affordable)
   Home Price-to-Income:    {f'{median_home/median_income:.1f}x' if median_home and median_income else 'N/A'}
   Rent Burden:             {_format_percent(rent_pct)} of income → {burden_level(rent_pct)}
   Owner Cost Burden:       {_format_percent(owner_cost_pct)} of income → {burden_level(owner_cost_pct)}

📏 National Comparison:
   US Median Home Value:    {_format_currency(national['median_home'])}
   US Median Rent:          {_format_currency(national['median_rent'])}
   US Median Income:        {_format_currency(national['median_income'])}

📅 Source: US Census ACS 5-Year (2022)"""

        return result

    @mcp.tool()
    async def search_neighborhoods(city: str) -> str:
        """Search for neighborhoods/areas in a city with key housing stats.

        Geocodes the city, finds the state, then returns all counties
        and places in that state with housing and demographic data.

        Args:
            city: City name with state (e.g., "Austin, Texas" or "Miami, FL")
        """
        # Stadt geocodieren um State zu bestimmen
        try:
            geo = await geocode_location(city)
        except Exception as e:
            return f"Fehler beim Geocoding: {str(e)}"

        if not geo:
            return f"Stadt '{city}' nicht gefunden. Bitte Format: 'City, State' nutzen."

        address = geo.get("address", {})
        state_name = address.get("state", "")

        fips = _resolve_state_fips(state_name)
        if not fips:
            return f"Konnte Bundesstaat aus '{city}' nicht ermitteln. Bitte z.B. 'Austin, TX' nutzen."

        # Places (Städte/Gemeinden) für den Staat holen
        try:
            places_data = await fetch_census_places(fips)
        except Exception as e:
            return f"Fehler beim Abrufen der Daten: {str(e)}"

        if not places_data or len(places_data) < 2:
            return "Keine Nachbarschafts-Daten gefunden."

        header = places_data[0]

        # Suchbegriff aus City extrahieren (erster Teil vor Komma)
        search_term = city.split(",")[0].strip().lower()

        # Alle Places durchgehen und nach City filtern
        matching = []
        for row in places_data[1:]:
            values = {header[i]: row[i] for i in range(len(header))}
            name = values.get("NAME", "").lower()

            # Match wenn der Stadtname im Place-Namen vorkommt
            if search_term in name:
                population = _safe_int(values.get("B01003_001E"))
                if population and population > 0:
                    matching.append({
                        "name": values.get("NAME", "Unbekannt"),
                        "home_value": _safe_int(values.get("B25077_001E")),
                        "rent": _safe_int(values.get("B25064_001E")),
                        "income": _safe_int(values.get("B19013_001E")),
                        "population": population,
                    })

        # Wenn kein exakter Match, alle Places im State zeigen (Top 20 nach Population)
        if not matching:
            for row in places_data[1:]:
                values = {header[i]: row[i] for i in range(len(header))}
                population = _safe_int(values.get("B01003_001E"))
                if population and population > 1000:
                    matching.append({
                        "name": values.get("NAME", "Unbekannt"),
                        "home_value": _safe_int(values.get("B25077_001E")),
                        "rent": _safe_int(values.get("B25064_001E")),
                        "income": _safe_int(values.get("B19013_001E")),
                        "population": population,
                    })

        # Nach Population sortieren
        matching.sort(key=lambda x: x.get("population", 0) or 0, reverse=True)
        matching = matching[:20]

        if not matching:
            return "Keine Orte mit ausreichend Daten gefunden."

        result = f"""🏘️ Neighborhoods: {city} ({FIPS_TO_STATE.get(fips, state_name)})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Found {len(matching)} areas:\n\n"""

        result += f"{'Area':<35} {'Population':>12} {'Home Value':>14} {'Rent':>10} {'Income':>14}\n"
        result += "─" * 87 + "\n"

        for place in matching:
            name = place["name"][:33]
            pop = f"{place['population']:,}" if place["population"] else "N/A"
            home = _format_currency(place["home_value"])
            rent = _format_currency(place["rent"])
            income = _format_currency(place["income"])
            result += f"{name:<35} {pop:>12} {home:>14} {rent:>10} {income:>14}\n"

        result += f"\n📅 Source: US Census ACS 5-Year (2022)"
        return result
