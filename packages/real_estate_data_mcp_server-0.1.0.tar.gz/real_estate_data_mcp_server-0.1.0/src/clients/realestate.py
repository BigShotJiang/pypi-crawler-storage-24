"""
Async HTTP-Clients für externe APIs:
- US Census American Community Survey (ACS 5-Year)
- Nominatim Geocoding (OpenStreetMap)
- Overpass API (Amenities/POIs)
"""

import httpx
from typing import Optional
from src.config import (
    CENSUS_ACS_BASE, CENSUS_API_KEY, NOMINATIM_BASE,
    OVERPASS_BASE, USER_AGENT, REQUEST_TIMEOUT
)


# ─── Census ACS Client ───────────────────────────────────────────

async def fetch_census_data(
    variables: list[str],
    state_fips: str,
    county_fips: Optional[str] = None
) -> list[list[str]]:
    """
    Holt Daten vom Census ACS 5-Year Endpunkt.

    Args:
        variables: Liste von Census-Variablen (z.B. ["B25077_001E", "B25064_001E"])
        state_fips: 2-stelliger FIPS-Code des Bundesstaats
        county_fips: Optionaler 3-stelliger County-FIPS-Code

    Returns:
        Liste von Listen (Header + Datenzeilen)
    """
    params = {
        "get": ",".join(["NAME"] + variables),
        "for": f"county:{county_fips}" if county_fips else "state:*",
    }

    # Wenn County abgefragt wird, State als Filter setzen
    if county_fips:
        params["in"] = f"state:{state_fips}"
        params["for"] = f"county:{county_fips}"
    else:
        params["for"] = f"state:{state_fips}"

    # API-Key nur anhängen wenn vorhanden
    if CENSUS_API_KEY:
        params["key"] = CENSUS_API_KEY

    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        response = await client.get(CENSUS_ACS_BASE, params=params)
        response.raise_for_status()
        return response.json()


async def fetch_census_counties(state_fips: str) -> list[list[str]]:
    """
    Holt alle Counties eines Bundesstaats mit Basis-Daten.
    Für search_neighborhoods und compare_areas.
    """
    variables = [
        "B25077_001E",  # Median Home Value
        "B25064_001E",  # Median Gross Rent
        "B01003_001E",  # Total Population
        "B19013_001E",  # Median Household Income
    ]

    params = {
        "get": ",".join(["NAME"] + variables),
        "for": "county:*",
        "in": f"state:{state_fips}",
    }

    if CENSUS_API_KEY:
        params["key"] = CENSUS_API_KEY

    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        response = await client.get(CENSUS_ACS_BASE, params=params)
        response.raise_for_status()
        return response.json()


async def fetch_census_places(state_fips: str) -> list[list[str]]:
    """
    Holt alle Places (Städte/Gemeinden) eines Bundesstaats.
    Für search_neighborhoods.
    """
    variables = [
        "B25077_001E",  # Median Home Value
        "B25064_001E",  # Median Gross Rent
        "B01003_001E",  # Total Population
        "B19013_001E",  # Median Household Income
    ]

    params = {
        "get": ",".join(["NAME"] + variables),
        "for": "place:*",
        "in": f"state:{state_fips}",
    }

    if CENSUS_API_KEY:
        params["key"] = CENSUS_API_KEY

    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        response = await client.get(CENSUS_ACS_BASE, params=params)
        response.raise_for_status()
        return response.json()


# ─── Nominatim Geocoding Client ──────────────────────────────────

async def geocode_location(query: str) -> Optional[dict]:
    """
    Geocodiert eine Adresse/Ortsname über Nominatim.

    Args:
        query: Suchbegriff (z.B. "San Francisco, CA")

    Returns:
        Dict mit lat, lon, display_name oder None
    """
    params = {
        "q": query,
        "format": "json",
        "limit": 1,
        "addressdetails": 1,
    }
    headers = {"User-Agent": USER_AGENT}

    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        response = await client.get(
            f"{NOMINATIM_BASE}/search",
            params=params,
            headers=headers
        )
        response.raise_for_status()
        results = response.json()

        if not results:
            return None

        result = results[0]
        return {
            "lat": float(result["lat"]),
            "lon": float(result["lon"]),
            "display_name": result.get("display_name", ""),
            "address": result.get("address", {}),
        }


async def reverse_geocode(lat: float, lon: float) -> Optional[dict]:
    """
    Reverse Geocoding — Koordinaten zu Adresse.
    """
    params = {
        "lat": lat,
        "lon": lon,
        "format": "json",
        "addressdetails": 1,
    }
    headers = {"User-Agent": USER_AGENT}

    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        response = await client.get(
            f"{NOMINATIM_BASE}/reverse",
            params=params,
            headers=headers
        )
        response.raise_for_status()
        return response.json()


# ─── Overpass API Client ──────────────────────────────────────────

async def fetch_nearby_amenities(
    lat: float,
    lon: float,
    radius_m: int = 2000
) -> dict:
    """
    Findet Amenities in der Nähe über die Overpass API.

    Sucht nach: Schulen, Krankenhäuser, Parks, ÖPNV-Haltestellen,
    Supermärkte, Restaurants, Apotheken.

    Args:
        lat: Breitengrad
        lon: Längengrad
        radius_m: Suchradius in Metern (Standard: 2000)

    Returns:
        Dict mit kategorisierten Amenities
    """
    # Overpass QL Query — sucht verschiedene Amenity-Typen
    query = f"""
    [out:json][timeout:25];
    (
      // Schulen
      node["amenity"="school"](around:{radius_m},{lat},{lon});
      way["amenity"="school"](around:{radius_m},{lat},{lon});
      // Krankenhäuser & Kliniken
      node["amenity"="hospital"](around:{radius_m},{lat},{lon});
      way["amenity"="hospital"](around:{radius_m},{lat},{lon});
      node["amenity"="clinic"](around:{radius_m},{lat},{lon});
      // Parks & Grünflächen
      node["leisure"="park"](around:{radius_m},{lat},{lon});
      way["leisure"="park"](around:{radius_m},{lat},{lon});
      // ÖPNV-Haltestellen
      node["public_transport"="stop_position"](around:{radius_m},{lat},{lon});
      node["highway"="bus_stop"](around:{radius_m},{lat},{lon});
      node["railway"="station"](around:{radius_m},{lat},{lon});
      node["railway"="halt"](around:{radius_m},{lat},{lon});
      // Supermärkte
      node["shop"="supermarket"](around:{radius_m},{lat},{lon});
      way["shop"="supermarket"](around:{radius_m},{lat},{lon});
      // Restaurants
      node["amenity"="restaurant"](around:{radius_m},{lat},{lon});
      // Apotheken
      node["amenity"="pharmacy"](around:{radius_m},{lat},{lon});
    );
    out center body;
    """

    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        response = await client.post(
            OVERPASS_BASE,
            data={"data": query}
        )
        response.raise_for_status()
        data = response.json()

    # Ergebnisse kategorisieren
    categories = {
        "schools": [],
        "hospitals": [],
        "parks": [],
        "transit_stops": [],
        "supermarkets": [],
        "restaurants": [],
        "pharmacies": [],
    }

    for element in data.get("elements", []):
        tags = element.get("tags", {})
        name = tags.get("name", "Unnamed")

        # Koordinaten bestimmen (Node vs Way mit Center)
        if element["type"] == "node":
            e_lat = element.get("lat")
            e_lon = element.get("lon")
        else:
            center = element.get("center", {})
            e_lat = center.get("lat")
            e_lon = center.get("lon")

        entry = {"name": name, "lat": e_lat, "lon": e_lon}

        amenity = tags.get("amenity", "")
        leisure = tags.get("leisure", "")
        shop = tags.get("shop", "")
        public_transport = tags.get("public_transport", "")
        highway = tags.get("highway", "")
        railway = tags.get("railway", "")

        if amenity == "school":
            categories["schools"].append(entry)
        elif amenity in ("hospital", "clinic"):
            categories["hospitals"].append(entry)
        elif amenity == "restaurant":
            categories["restaurants"].append(entry)
        elif amenity == "pharmacy":
            categories["pharmacies"].append(entry)
        elif leisure == "park":
            categories["parks"].append(entry)
        elif public_transport == "stop_position" or highway == "bus_stop" or railway in ("station", "halt"):
            entry["type"] = railway if railway else ("bus_stop" if highway == "bus_stop" else "transit_stop")
            categories["transit_stops"].append(entry)
        elif shop == "supermarket":
            categories["supermarkets"].append(entry)

    return categories
