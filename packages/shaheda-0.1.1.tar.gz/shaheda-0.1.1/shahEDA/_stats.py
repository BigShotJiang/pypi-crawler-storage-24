import pandas as pd

def basic_statistics(df):
    """
    Calculate basic statistics of a DataFrame.
    
    Parameters:
        df (DataFrame): Already loaded dataset from loader.py
    
    Returns:
        dict: Contains mean, median, mode, std, etc.
    """
    mode_df = df.mode()
    stats_dict = {
        "mean":df.mean(numeric_only=True),
        "median":df.median(numeric_only=True),
        "mode": mode_df.iloc[0] if not mode_df.empty else None,
        "std": df.std(numeric_only=True),
        "variance": df.var(numeric_only=True),
        "summary": df.describe()
    }
    return stats_dict