from pathlib import Path
import pandas as pd

def check_format(file_path: str, verbose: bool = False):
    """
    Load a CSV or Excel file into a pandas DataFrame.

    Parameters:
        file_path (str): Path to the CSV or Excel file.
        Verbose (bool): To show the loaded file format (optional)
    Returns:
        pd.DataFrame: Loaded data.

    Raises:
        ValueError: If file format is not supported.
        FileNotFoundError: If the file does not exist.
    """
    file_path_to_check = Path(file_path)
    
    if not file_path_to_check.exists():
        raise FileNotFoundError(f"File does not exist: {file_path}")
    #extension of the file
    extension = file_path_to_check.suffix.lower()
    #checking the extension type
    if extension == '.csv':
        df = pd.read_csv(file_path)
    elif extension == ".xlsx":
        df = pd.read_excel(file_path)
    else:
        raise ValueError(f"Unsupported file format: {extension}")
    #showing the loaded file with format
    if verbose:
        print(f"Loaded file in {extension[1:]} format")
        
    return df