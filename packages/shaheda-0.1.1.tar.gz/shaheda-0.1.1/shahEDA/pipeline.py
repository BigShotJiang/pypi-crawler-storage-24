from ._loader import check_format
from ._eda_engine import basic_info, duplicates, missing_values
from ._stats import basic_statistics
from ._suggestions import generate_suggestions

class AnalyzerEDA:
    def __init__(self, file_path: str, verbose: bool = False, display: bool = False):
        #Load the user_provided dataset
        try:
            self.df = check_format(file_path, verbose=verbose)
            self.display = display
        except Exception as e:
            raise RuntimeError(f"EDA failed: {str(e)}")
        
    def run(self):
        #Run all EDA functions
        self.info = basic_info(self.df)
        self.missing = missing_values(self.df)
        self.dupes = duplicates(self.df)
        
        #Run basic statistics
        self.stats = basic_statistics(self.df)
        
        #get suggestions
        self.suggestions = generate_suggestions(self.df)
        
        #display depending upon the display parameter
        if self.display:
            print("=== BASIC INFO ===")
            print(self.info)
            
            print("=== MISSING VALUES ===")
            print(self.missing)
            
            print("=== DUPLICATES ===")
            print(self.dupes)
            
            print("\n=== STATISTICS ===")
            print(self.stats["summary"])
            
            print("\n=== SUGGESTIONS === ")
            for s in self.suggestions: print("-", s)
    
        #return results in the dictionary form
        return {
            "info":self.info,
            "missing":self.missing,
            "duplicates":self.dupes,
            "stats":self.stats,
            "suggestions":self.suggestions
        }