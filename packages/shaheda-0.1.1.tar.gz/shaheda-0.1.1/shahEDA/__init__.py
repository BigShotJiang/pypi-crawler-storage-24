from .pipeline import AnalyzerEDA

def analyze(file_path: str, verbose: bool = False, display: bool = False):
    eda = AnalyzerEDA(file_path, verbose, display)
    return eda.run()

__all__ = ["analyze", "AnalyzerEDA"]