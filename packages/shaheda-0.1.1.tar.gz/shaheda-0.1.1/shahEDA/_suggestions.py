def generate_suggestions(df):
    suggestions = []
    
    #missing values
    missing = df.isnull().sum()
    for col, val in missing.items():
        if val > 0:
            suggestions.append(f"Column '{col}' has {val} missing values → consider imputation")
            
    # Duplicates
    dup_count = df.duplicated().sum()
    if dup_count > 0:
        suggestions.append(f"Dataset contains {dup_count} duplicate rows → consider removing them")
        
    # Categorical columns
    cat_cols = df.select_dtypes(include='object').columns
    for col in cat_cols:
        suggestions.append(f"Column '{col}' is categorical → consider encoding if using ML")
        
    # High correlation
    corr = df.corr(numeric_only=True)
    if not corr.empty:
        high_corr = (corr.abs() > 0.9).sum().sum()
        if high_corr > len(corr):
            suggestions.append("High correlation detected → consider feature selection")

    return suggestions