def basic_info(df):
    """
    Applies basic data info operations
    
    Parameters:
        df (DataFrame): straight from loader.py
    """
    return {
        'shape': df.shape,
        'columns': df.columns.tolist(),   
        'datatypes': df.dtypes.astype(str)    
    }
    
def missing_values(df):
    return df.isnull().sum()

def duplicates(df):
    return df.duplicated().sum()