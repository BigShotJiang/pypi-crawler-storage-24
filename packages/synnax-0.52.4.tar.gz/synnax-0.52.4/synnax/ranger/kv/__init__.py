#  Copyright 2026 Synnax Labs, Inc.
#
#  Use of this software is governed by the Business Source License included in the file
#  licenses/BSL.txt.
#
#  As of the Change Date specified in that file, in accordance with the Business Source
#  License, use of this software will be governed by the Apache License, Version 2.0,
#  included in the file licenses/APL.txt.

from synnax.ranger.kv.client import Client
from synnax.ranger.kv.payload import Pair

KV = Client
"""Deprecated: Use Client instead."""

KVPair = Pair
"""Deprecated: Use Pair instead."""

__all__ = ["Client", "Pair", "KV", "KVPair"]
