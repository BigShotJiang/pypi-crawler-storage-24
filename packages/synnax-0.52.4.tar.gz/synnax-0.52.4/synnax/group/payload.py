#  Copyright 2026 Synnax Labs, Inc.
#
#  Use of this software is governed by the Business Source License included in the file
#  licenses/BSL.txt.
#
#  As of the Change Date specified in that file, in accordance with the Business Source
#  License, use of this software will be governed by the Apache License, Version 2.0,
#  included in the file licenses/APL.txt.


from uuid import UUID

from pydantic import BaseModel

from synnax import ontology

ONTOLOGY_TYPE = ontology.ID(type="group")


class Group(BaseModel):
    key: UUID
    name: str

    @property
    def ontology_id(self) -> ontology.ID:
        return ontology.ID(key=str(self.key), type=ONTOLOGY_TYPE.type)
