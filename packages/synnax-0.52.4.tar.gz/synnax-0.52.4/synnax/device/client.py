#  Copyright 2026 Synnax Labs, Inc.
#
#  Use of this software is governed by the Business Source License included in the file
#  licenses/BSL.txt.
#
#  As of the Change Date specified in that file, in accordance with the Business Source
#  License, use of this software will be governed by the Apache License, Version 2.0,
#  included in the file licenses/APL.txt.

from typing import Any, Literal, overload

from alamos import NOOP, Instrumentation, trace
from freighter import Empty, UnaryClient, send_required
from pydantic import BaseModel

from synnax.device.payload import Device
from synnax.exceptions import NotFoundError
from synnax.util.normalize import check_for_none, normalize, override


class _CreateRequest(BaseModel):
    devices: list[Device]


_CreateResponse = _CreateRequest


class _DeleteRequest(BaseModel):
    keys: list[str]


class _RetrieveRequest(BaseModel):
    keys: list[str] | None = None
    names: list[str] | None = None
    makes: list[str] | None = None
    models: list[str] | None = None
    locations: list[str] | None = None
    ignore_not_found: bool = False


class _RetrieveResponse(BaseModel):
    devices: list[Device] | None = None


class Client:
    _client: UnaryClient
    instrumentation: Instrumentation = NOOP

    def __init__(
        self,
        client: UnaryClient,
        instrumentation: Instrumentation = NOOP,
    ) -> None:
        self._client = client
        self.instrumentation = instrumentation

    @overload
    def create(
        self,
        *,
        key: str = "",
        location: str = "",
        rack: int = 0,
        name: str = "",
        make: str = "",
        model: str = "",
        configured: bool = False,
        properties: dict[str, Any] | None = None,
    ) -> Device: ...

    @overload
    def create(self, devices: Device) -> Device: ...

    @overload
    def create(self, devices: list[Device]) -> list[Device]: ...

    def create(
        self,
        devices: list[Device] | Device | None = None,
        *,
        key: str = "",
        location: str = "",
        rack: int = 0,
        name: str = "",
        make: str = "",
        model: str = "",
        configured: bool = False,
        properties: dict[str, Any] | None = None,
    ) -> Device | list[Device]:
        is_single = not isinstance(devices, list)
        if devices is None:
            devices = [
                Device(
                    key=key,
                    location=location,
                    rack=rack,
                    name=name,
                    make=make,
                    model=model,
                    configured=configured,
                    properties=properties if properties is not None else {},
                )
            ]
        req = _CreateRequest(devices=normalize(devices))
        res = send_required(
            self._client,
            "/device/create",
            req,
            _CreateResponse,
        )
        return res.devices[0] if is_single else res.devices

    def delete(self, keys: list[str]) -> None:
        req = _DeleteRequest(keys=keys)
        send_required(self._client, "/device/delete", req, Empty)

    @overload
    def retrieve(
        self,
        *,
        key: str | None = None,
        make: str | None = None,
        name: str | None = None,
        model: str | None = None,
        location: str | None = None,
        ignore_not_found: Literal[True],
    ) -> Device | None: ...

    @overload
    def retrieve(
        self,
        *,
        keys: list[str] | None = None,
        makes: list[str] | None = None,
        models: list[str] | None = None,
        names: list[str] | None = None,
        locations: list[str] | None = None,
        ignore_not_found: Literal[True],
    ) -> list[Device]: ...

    @overload
    def retrieve(
        self,
        *,
        key: str | None = None,
        make: str | None = None,
        name: str | None = None,
        model: str | None = None,
        location: str | None = None,
        ignore_not_found: Literal[False] = ...,
    ) -> Device: ...

    @overload
    def retrieve(
        self,
        *,
        keys: list[str] | None = None,
        makes: list[str] | None = None,
        models: list[str] | None = None,
        names: list[str] | None = None,
        locations: list[str] | None = None,
        ignore_not_found: Literal[False] = ...,
    ) -> list[Device]: ...

    def retrieve(
        self,
        *,
        key: str | None = None,
        make: str | None = None,
        model: str | None = None,
        name: str | None = None,
        location: str | None = None,
        keys: list[str] | None = None,
        makes: list[str] | None = None,
        models: list[str] | None = None,
        names: list[str] | None = None,
        locations: list[str] | None = None,
        ignore_not_found: bool = False,
    ) -> list[Device] | Device | None:
        is_single = check_for_none(keys, makes, models, locations, names)
        res = send_required(
            self._client,
            "/device/retrieve",
            _RetrieveRequest(
                keys=override(key, keys),
                makes=override(make, makes),
                models=override(model, models),
                locations=override(location, locations),
                names=override(name, names),
                ignore_not_found=ignore_not_found,
            ),
            _RetrieveResponse,
        )
        if is_single:
            if res.devices is not None and len(res.devices) > 0:
                return res.devices[0]
            if ignore_not_found:
                return None
            raise NotFoundError("Device not found")
        return res.devices if res.devices is not None else []
