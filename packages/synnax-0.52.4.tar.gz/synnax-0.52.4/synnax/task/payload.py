#  Copyright 2026 Synnax Labs, Inc.
#
#  Use of this software is governed by the Business Source License included in the file
#  licenses/BSL.txt.
#
#  As of the Change Date specified in that file, in accordance with the Business Source
#  License, use of this software will be governed by the Apache License, Version 2.0,
#  included in the file licenses/APL.txt.


from typing import Any

from pydantic import BaseModel

from synnax import ontology, status

ONTOLOGY_TYPE = ontology.ID(type="task")


class StatusDetails(BaseModel):
    """
    Details about the status of a task.
    """

    task: int = 0
    """The key of the task."""
    running: bool = False
    """Whether the task is running."""
    data: dict[str, Any] | None = None
    """Arbitrary data about the task."""
    cmd: str | None = None


Status = status.Status[StatusDetails]
"""The status of a task."""


class Payload(BaseModel):
    """A primitive task payload."""

    key: int = 0
    name: str = ""
    type: str = ""
    config: dict[str, Any] = {}
    snapshot: bool = False
    status: Status | None = None


def ontology_id(key: int) -> ontology.ID:
    """Create an ontology ID for a task.

    Args:
        key: The task key.

    Returns:
        An ontology ID dictionary with type "task" and the given key.
    """
    return ontology.ID(type=ONTOLOGY_TYPE.type, key=str(key))


from synnax.util.deprecation import deprecated_getattr

_DEPRECATED = {
    "TASK_ONTOLOGY_TYPE": "ONTOLOGY_TYPE",
    "TaskPayload": "Payload",
    "TaskStatus": "Status",
    "TaskStatusDetails": "StatusDetails",
}

__getattr__ = deprecated_getattr(__name__, _DEPRECATED, globals())
