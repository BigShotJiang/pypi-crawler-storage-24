---
name: search-categories
description: List contents of an Indico category (subcategories and events). Use when the user wants to browse Indico categories, explore the category tree, find subcategories, or see what's inside a category. Triggers on keywords like "list categories", "browse categories", "what's in category", "subcategories", "category tree".
allowed-tools: Bash
---

# Search Indico Categories

List the contents (subcategories and events) of an Indico category.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools search-categories [--category-id ID] [--limit N]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--category-id` | No | Category ID to explore (default: "0" for root) |
| `--limit` | No | Maximum number of results |

## Examples

List root categories:
```bash
uvx indico-cli-tools search-categories
```

List contents of a specific category:
```bash
uvx indico-cli-tools search-categories --category-id 4648 --limit 20
```
