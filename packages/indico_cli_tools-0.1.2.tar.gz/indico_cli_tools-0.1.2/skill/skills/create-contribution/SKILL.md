---
name: create-contribution
description: Create a contribution (talk/presentation) within an Indico event, optionally assigned to a session. Use when the user wants to add a talk, presentation, or contribution to an event. Requires event management permissions. Triggers on keywords like "create contribution", "add talk", "add presentation", "new contribution".
allowed-tools: Bash
---

# Create Contribution in Indico Event

Create a contribution (talk/presentation) within an Indico event, optionally assigned to a session. Requires management permissions on the event.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools create-contribution --event-id <ID> --title "Talk Title" [--description TEXT] [--duration N] [--speakers JSON] [--session-id ID]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | The event ID to add the contribution to |
| `--title` | Yes | Contribution title |
| `--description` | No | Contribution description |
| `--duration` | No | Duration in minutes (default: 20) |
| `--speakers` | No | JSON array of speakers |
| `--session-id` | No | Session ID to assign contribution to |

## Speaker JSON Format

```json
[{"first_name": "John", "last_name": "Doe", "email": "john@example.com", "affiliation": "CERN"}]
```

## Examples

Simple contribution:
```bash
uvx indico-cli-tools create-contribution --event-id 137346 --title "Status Update" --duration 15
```

Contribution with speaker in a session:
```bash
uvx indico-cli-tools create-contribution --event-id 137346 --title "ML Results" --duration 30 --session-id 42 --speakers '[{"first_name": "Alice", "last_name": "Smith", "affiliation": "CERN"}]'
```
