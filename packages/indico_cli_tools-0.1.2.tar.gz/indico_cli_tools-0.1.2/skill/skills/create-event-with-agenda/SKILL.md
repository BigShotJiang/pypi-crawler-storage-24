---
name: create-event-with-agenda
description: Create a new Indico event with a complete agenda (sessions and contributions) in one operation. Use when the user wants to create a meeting or conference with a full agenda, set up an event with multiple talks and sessions, or build a complete event structure at once. Triggers on keywords like "create event with agenda", "set up meeting with talks", "create conference with sessions", "build agenda".
allowed-tools: Bash
---

# Create Event with Full Agenda

Create a new event with a complete agenda (sessions and contributions) in a single operation. Agenda items with a `contributions` key become sessions with nested talks; items without become standalone contributions.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools create-event-with-agenda --title "Title" --category-id <ID> --type <lecture|meeting|conference> --start <ISO> --end <ISO> [--timezone TZ] [--description TEXT] [--location TEXT] [--room TEXT] [--speakers JSON] --agenda-file <path>
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--title` | Yes | Event title |
| `--category-id` | Yes | Category ID |
| `--type` | Yes | Event type: `lecture`, `meeting`, or `conference` |
| `--start` | Yes | Start datetime (ISO format) |
| `--end` | Yes | End datetime (ISO format) |
| `--timezone` | No | Timezone (e.g., Europe/Zurich) |
| `--description` | No | Event description |
| `--location` | No | Venue name |
| `--room` | No | Room name |
| `--speakers` | No | JSON array of event-level speakers |
| `--agenda-file` | Yes | Path to a JSON file containing the agenda |

## Agenda File Format

The agenda file is a JSON array. Items with `contributions` become sessions; items without become standalone contributions.

```json
[
  {
    "title": "Opening Session",
    "contributions": [
      {"title": "Welcome", "duration_minutes": 10, "speakers": [{"first_name": "Jane", "last_name": "Doe"}]},
      {"title": "Overview", "duration_minutes": 20}
    ]
  },
  {
    "title": "Coffee Break",
    "duration_minutes": 30
  },
  {
    "title": "Keynote Talk",
    "duration_minutes": 60,
    "speakers": [{"first_name": "John", "last_name": "Smith", "affiliation": "CERN"}]
  }
]
```

## Examples

```bash
uvx indico-cli-tools create-event-with-agenda \
  --title "Workshop on ML" \
  --category-id 4648 \
  --type meeting \
  --start 2025-06-15T09:00:00 \
  --end 2025-06-15T17:00:00 \
  --timezone Europe/Zurich \
  --location CERN \
  --agenda-file agenda.json
```
