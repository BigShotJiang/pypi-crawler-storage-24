---
name: delete-timetable-entry
description: Remove a timetable entry from an Indico event. Use when the user wants to remove something from the timetable, unschedule an item, or delete a timetable entry. Requires event management permissions. Triggers on keywords like "remove from timetable", "delete timetable entry", "unschedule".
allowed-tools: Bash
---

# Delete Timetable Entry

Remove a timetable entry from an Indico event. Requires management permissions on the event.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools delete-timetable-entry --event-id <ID> --entry-id <ID>
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | The event ID |
| `--entry-id` | Yes | The timetable entry ID to remove |

## Examples

```bash
uvx indico-cli-tools delete-timetable-entry --event-id 137346 --entry-id 42
```
