---
name: create-event
description: Create a new event (lecture, meeting, or conference) in Indico. Use when the user wants to create an event, schedule a meeting, set up a conference, or add a new lecture to Indico. Requires write permissions. Triggers on keywords like "create event", "new meeting", "schedule a lecture", "set up conference", "add event to Indico".
allowed-tools: Bash
---

# Create Indico Event

Create a new event (lecture, meeting, or conference) in an Indico category. Requires write permissions on the target category.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools create-event --title "Title" --category-id <ID> --type <lecture|meeting|conference> [--start ISO] [--end ISO] [--timezone TZ] [--description TEXT] [--location TEXT] [--room TEXT] [--speakers JSON]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--title` | Yes | Event title |
| `--category-id` | Yes | Category ID to create the event in |
| `--type` | Yes | Event type: `lecture`, `meeting`, or `conference` |
| `--start` | No | Start datetime (ISO format, e.g., 2025-06-15T14:00:00) |
| `--end` | No | End datetime (ISO format) |
| `--timezone` | No | Timezone (e.g., Europe/Zurich) |
| `--description` | No | Event description |
| `--location` | No | Venue/location name |
| `--room` | No | Room name |
| `--speakers` | No | JSON array of speakers |

## Speaker JSON Format

```json
[{"first_name": "John", "last_name": "Doe", "email": "john@example.com", "affiliation": "CERN"}]
```

## Examples

Create a simple lecture:
```bash
uvx indico-cli-tools create-event --title "ML in Accelerators" --category-id 4648 --type lecture --start 2025-06-15T14:00:00 --end 2025-06-15T15:00:00 --timezone Europe/Zurich
```

Create a meeting with speakers:
```bash
uvx indico-cli-tools create-event --title "Team Meeting" --category-id 4648 --type meeting --start 2025-06-15T09:00:00 --end 2025-06-15T10:00:00 --location CERN --room "40-S2-A01" --speakers '[{"first_name": "Jane", "last_name": "Smith", "affiliation": "CERN"}]'
```
