---
name: download-attachment
description: Download a single file attachment from Indico using its download URL. Use when the user has a specific file URL from Indico and wants to download it, or needs to fetch a single attachment rather than all event files. Triggers on keywords like "download this file", "download attachment", "fetch file from Indico", "save this attachment".
allowed-tools: Bash
---

# Download Single Attachment

Download a single file attachment from Indico using its download URL.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools download --url "<download-url>" [--filename NAME]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--url` | Yes | The download URL of the attachment |
| `--filename` | No | Custom filename for the saved file |

## Examples

Download a file:
```bash
uvx indico-cli-tools download --url "https://indico.cern.ch/event/123/attachments/456/789/slides.pdf"
```

Download with a custom filename:
```bash
uvx indico-cli-tools download --url "https://indico.cern.ch/event/123/attachments/456/789/slides.pdf" --filename "my-slides.pdf"
```
