---
name: get-contributions
description: Get contributions (talks, presentations) for a specific Indico event, including speakers, timing, tracks, and sessions. Use when the user wants to see the talks or agenda items in an event, list speakers, or find specific contributions. Triggers on keywords like "contributions", "talks", "presentations", "speakers", "agenda items", "what talks are in".
allowed-tools: Bash
---

# Get Event Contributions

List all contributions (talks/presentations) for a specific Indico event with speaker details, timing, and session assignments.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools contributions --event-id <ID> [--subcontributions] [--limit N]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | The Indico event ID |
| `--subcontributions` | No | Flag to include subcontributions |
| `--limit` | No | Maximum number of contributions to display |

## Examples

List all contributions:
```bash
uvx indico-cli-tools contributions --event-id 137346
```

Include subcontributions with a limit:
```bash
uvx indico-cli-tools contributions --event-id 137346 --subcontributions --limit 20
```
