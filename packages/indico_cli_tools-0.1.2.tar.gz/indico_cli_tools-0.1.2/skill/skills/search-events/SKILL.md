---
name: search-events
description: Search for events in an Indico category by date range. Use when the user wants to find events, meetings, or conferences in a specific Indico category, browse upcoming events, or list what's happening in a category. Triggers on keywords like "search events", "find meetings", "what events are in category", "list events", "upcoming events in Indico".
allowed-tools: Bash
---

# Search Events in Indico

Search for events within a specific Indico category, optionally filtered by date range.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools search-events --category-id <ID> [--from-date YYYY-MM-DD] [--to-date YYYY-MM-DD] [--limit N] [--only-public]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--category-id` | Yes | The Indico category ID to search in |
| `--from-date` | No | Start date filter (YYYY-MM-DD) |
| `--to-date` | No | End date filter (YYYY-MM-DD) |
| `--limit` | No | Maximum number of results |
| `--only-public` | No | Flag to only show public events |

## Examples

Search all events in category 4648:
```bash
uvx indico-cli-tools search-events --category-id 4648
```

Search events in a date range with limit:
```bash
uvx indico-cli-tools search-events --category-id 4648 --from-date 2025-01-01 --to-date 2025-12-31 --limit 10
```
