---
name: get-files
description: List and download all files and attachments from an Indico event, including materials from contributions. Use when the user wants to download event materials, get presentation slides, find attached files, or retrieve documents from an event. Triggers on keywords like "download files", "get materials", "event attachments", "slides from event", "download presentations".
allowed-tools: Bash
---

# Get and Download Event Files

List all files attached to an Indico event (event-level materials and contribution attachments) and optionally download them.

## Prerequisites

The Indico CLI must be configured with a base URL and API token. Run `uvx indico-cli-tools user-info` to check. If it fails, use the `/indico-cli:configure` skill to set up credentials first.

## Command

```bash
uvx indico-cli-tools files --event-id <ID> [--download | --no-download] [--download-dir PATH]
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | The Indico event ID |
| `--download/--no-download` | No | Whether to download files (default: download) |
| `--download-dir` | No | Directory to save downloaded files |

## Examples

List and download all files:
```bash
uvx indico-cli-tools files --event-id 137346
```

List files without downloading:
```bash
uvx indico-cli-tools files --event-id 137346 --no-download
```

Download to a specific directory:
```bash
uvx indico-cli-tools files --event-id 137346 --download-dir ./my-files
```

## Download Fallback

If the CLI's built-in download fails (e.g., 403 for protected files), the output includes the `Download URL` for each file. You can download these directly with curl:

```bash
curl -L -H "Authorization: Bearer $INDICO_API_TOKEN" -o filename.pdf "DOWNLOAD_URL"
```

First list files with `--no-download` to get the URLs, then use curl for the ones you need.
