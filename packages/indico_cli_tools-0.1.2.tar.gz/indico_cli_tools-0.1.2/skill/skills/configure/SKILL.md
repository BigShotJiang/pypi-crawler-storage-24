---
name: configure
description: Set up Indico CLI credentials (base URL and API token). Use BEFORE any other Indico skill when the user hasn't configured their connection yet, when authentication fails, or when the user wants to change their Indico instance. This skill MUST be triggered whenever another Indico skill fails with an authentication or connection error, or when INDICO_BASE_URL / INDICO_API_TOKEN are not set. Also use when the user mentions "set up Indico", "configure Indico", "Indico token", "Indico login", or "connect to Indico".
allowed-tools: Bash
user-invocable: true
---

# Configure Indico CLI

This skill guides the user through obtaining an API token and configuring the Indico CLI. Credentials are stored safely in `~/.config/indico-cli/config.json` (not in any repository).

## Step 1: Check if already configured

Run this first to see if credentials are already set:

```bash
uvx indico-cli-tools user-info 2>&1
```

If this returns user info, the CLI is already configured. Tell the user and stop.

If it fails, proceed to Step 2.

## Step 2: Determine the Indico instance

Ask the user which Indico instance they want to connect to. Common options:
- `https://indico.cern.ch` (CERN)
- `https://indico.fnal.gov` (Fermilab)
- Or any other Indico instance URL

## Step 3: Guide the user to create an API token

Tell the user:

> To connect, you need an API token from your Indico instance. Here's how to get one:
>
> 1. Open **`<base_url>/user/preferences/api`** in your browser
>    (e.g., https://indico.cern.ch/user/preferences/api)
> 2. Click **"Create new token"**
> 3. Give it a name (e.g., "indico-cli")
> 4. Select these scopes:
>    - `read:legacy_api` (required for search and read operations)
>    - `write:legacy_api` (required for creating events)
>    - `read:user` (optional, for user info)
> 5. Click **"Create"** and copy the token (it starts with `indp_`)
>
> **Important:** The token is only shown once. Copy it now.

Wait for the user to provide the token before proceeding.

## Step 4: Save the credentials

Once the user provides the token, run:

```bash
uvx indico-cli-tools configure --base-url <BASE_URL> --token <TOKEN>
```

This saves credentials to `~/.config/indico-cli/config.json` so they persist across sessions. The config file is in the user's home directory, never inside a git repository.

## Step 5: Verify the connection

The configure command automatically tests the connection. If it succeeds, tell the user they're ready to go. If it fails, help troubleshoot:

- **403/401**: Token may lack required scopes, or may have expired
- **Connection error**: Check the base URL is correct and the instance is reachable
- **SSL error**: May need to be on the right network (e.g., CERN network for indico.cern.ch)

## Security Notes

- The token is stored in `~/.config/indico-cli/config.json` with file permissions inherited from the user's home directory
- Never commit tokens to git. The project's `.gitignore` excludes `.env` files
- If the user has a `.env` file, remind them to verify it's in `.gitignore`
- Environment variables (`INDICO_BASE_URL`, `INDICO_API_TOKEN`) take precedence over the config file
