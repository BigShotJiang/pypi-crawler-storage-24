# FTL Builtin Modules

Ansible builtin modules extracted for use with FTL2.

This package provides the `ansible.modules` namespace without requiring a full Ansible Core installation.

## Installation

```bash
pip install ftl-builtin-modules
```

Or from source:

```bash
pip install -e /Users/ben/git/ftl_builtin_modules
```

## Usage

After installation, you can find and use builtin modules:

```python
import ansible.modules

# Get the path to builtin modules
builtin_path = ansible.modules.__path__[0]

# Find a specific module
import os
ping_module = os.path.join(builtin_path, 'ping.py')
```

## Combined with ftl_module_utils

For full module execution support:

```bash
pip install ftl_module_utils        # Provides ansible.module_utils
pip install ftl-builtin-modules     # Provides ansible.modules
```

Both packages use namespace packages and can coexist.

## License

GPL-3.0-or-later (same as Ansible)

The modules in this package are copied from Ansible Core and retain their original GPL license.
