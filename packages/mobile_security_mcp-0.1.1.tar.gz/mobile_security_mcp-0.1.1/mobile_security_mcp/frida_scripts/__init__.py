"""Frida script library package — categorized JS scripts for Android RE."""
