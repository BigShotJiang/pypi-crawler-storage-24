"""Setup package — tool verification and installation helpers."""
