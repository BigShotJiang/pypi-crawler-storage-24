"""mobile-security-mcp — Android security research MCP server."""

__version__ = "0.1.1"
__author__ = "mobile-security-mcp contributors"

import os
from pathlib import Path

# ── Dynamic PATH Injection for Zero-Touch Tooling ──────────────────────
_td = Path.home() / "tools"
_td.mkdir(parents=True, exist_ok=True)
os.environ["PATH"] += (
    os.pathsep + str(_td) +
    os.pathsep + str(_td / "jadx" / "bin") +
    os.pathsep + str(_td / "platform-tools") +
    os.pathsep + str(_td / "il2cppdumper") +
    os.pathsep + str(_td / "scrcpy")
)
# ────────────────────────────────────────────────────────────────────────
