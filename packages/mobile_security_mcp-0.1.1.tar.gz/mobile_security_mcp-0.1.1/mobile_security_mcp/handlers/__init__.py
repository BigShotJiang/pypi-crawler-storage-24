"""Handlers package — one module per capability domain."""
