"""
Entry point for the mobile-security-mcp MCP server.

Usage:
    python -m mobile_security_mcp           # stdio transport (default)
    python -m mobile_security_mcp --port 8765  # SSE transport
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys

logger = logging.getLogger(__name__)


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="mobile-security-mcp",
        description="Android security research MCP server",
    )
    p.add_argument(
        "--transport",
        choices=["stdio", "sse"],
        default="stdio",
        help="Transport to use (default: stdio)",
    )
    p.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Port for SSE transport (default: 8765)",
    )
    p.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    return p


def main() -> None:
    """Main entry point — starts the MCP server."""
    parser = _build_parser()
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stderr,
    )

    # Import here so startup errors surface cleanly
    from mobile_security_mcp.server import create_server

    server = create_server()

    if args.transport == "stdio":
        logger.info("Starting mobile-security-mcp over stdio")
        asyncio.run(server.run_stdio())
    else:
        logger.info("Starting mobile-security-mcp SSE on port %d", args.port)
        asyncio.run(server.run_sse(port=args.port))


if __name__ == "__main__":
    main()
