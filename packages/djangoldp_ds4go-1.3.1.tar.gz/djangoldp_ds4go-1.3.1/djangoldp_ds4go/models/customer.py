from django.utils.translation import gettext_lazy as _
from djangoldp import fields
from djangoldp.permissions import AnonymousReadOnly, ReadAndCreate

from djangoldp_ds4go.models.__base_named_model import baseNamedModel


class Customer(baseNamedModel):
    participant_id = fields.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name=_("Paricipant ID"),
    )
    balance = fields.DecimalField(
        max_digits=15,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name=_("Balance"),
    )

    class Meta(baseNamedModel.Meta):
        depth = 1
        verbose_name = _("Customer")
        verbose_name_plural = _("Customers")
        permission_classes = [AnonymousReadOnly, ReadAndCreate]  # Yeah, maybe not.

        rdf_type = "ds4go:Customer"
        serializer_fields = baseNamedModel.Meta.serializer_fields + [
            "participant_id",
            "balance",
        ]

        nested_fields = baseNamedModel.Meta.nested_fields
