"""
LangChain memory adapter for Engram.

Usage:
    from engram.langchain import EngramMemory
    from langchain.chains import ConversationChain
    from langchain.llms import OpenAI

    memory = EngramMemory(session_id="user_123", db_path="./memory.db")
    chain = ConversationChain(llm=OpenAI(), memory=memory)
    chain.predict(input="Hi, I'm Jeff")
    chain.predict(input="What's my name?")  # remembers "Jeff"
"""

from typing import Any, Optional
from .engram import Engram, EngramConfig

try:
    from langchain.memory.chat_memory import BaseChatMemory
    from langchain.schema import HumanMessage, AIMessage, BaseMessage
    from langchain.memory.utils import get_prompt_input_key
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False


if LANGCHAIN_AVAILABLE:
    class EngramMemory(BaseChatMemory):
        """
        LangChain memory backed by Engram.
        Drop-in replacement for ConversationBufferMemory with persistent,
        semantic recall across sessions.

        Example:
            memory = EngramMemory(
                session_id="user_abc",
                db_path="./memory.db",
                recall_limit=5
            )
        """

        session_id: str = "default"
        db_path: str = ":memory:"
        embedding_url: str = "http://localhost:11434"
        embedding_model: str = "nomic-embed-text"
        recall_limit: int = 10
        memory_key: str = "history"
        input_key: Optional[str] = None
        output_key: Optional[str] = None
        return_messages: bool = False

        class Config:
            arbitrary_types_allowed = True

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self._engram = Engram(EngramConfig(
                db_path=self.db_path,
                embedding_url=self.embedding_url,
                embedding_model=self.embedding_model,
            ))

        @property
        def memory_variables(self) -> list[str]:
            return [self.memory_key]

        def load_memory_variables(self, inputs: dict[str, Any]) -> dict[str, Any]:
            """Load relevant memories based on current input."""
            query = None
            if inputs:
                input_key = self.input_key or get_prompt_input_key(inputs, self.memory_variables)
                query = inputs.get(input_key, "")

            entries = self._engram.recall(
                self.session_id,
                query=query,
                limit=self.recall_limit
            )

            if self.return_messages:
                messages: list[BaseMessage] = []
                for entry in reversed(entries):
                    if entry.role == "user":
                        messages.append(HumanMessage(content=entry.content))
                    elif entry.role == "assistant":
                        messages.append(AIMessage(content=entry.content))
                return {self.memory_key: messages}

            # Return as formatted string
            lines = []
            for entry in reversed(entries):
                prefix = "Human" if entry.role == "user" else "AI"
                lines.append(f"{prefix}: {entry.content}")
            return {self.memory_key: "\n".join(lines)}

        def save_context(self, inputs: dict[str, Any], outputs: dict[str, str]) -> None:
            """Store input/output to Engram memory."""
            input_key = self.input_key or get_prompt_input_key(inputs, self.memory_variables)
            output_key = self.output_key or list(outputs.keys())[0]

            human_msg = inputs.get(input_key, "")
            ai_msg = outputs.get(output_key, "")

            if human_msg:
                self._engram.remember(self.session_id, str(human_msg), "user")
            if ai_msg:
                self._engram.remember(self.session_id, str(ai_msg), "assistant")

        def clear(self) -> None:
            """Clear all memories for this session."""
            self._engram.forget(self.session_id)

else:
    class EngramMemory:  # type: ignore
        """Stub — install langchain to use EngramMemory."""
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "LangChain is required for EngramMemory. "
                "Install it with: pip install langchain"
            )
