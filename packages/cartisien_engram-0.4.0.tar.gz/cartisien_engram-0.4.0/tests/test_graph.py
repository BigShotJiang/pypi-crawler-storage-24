"""Tests for v0.3 graph memory."""
import pytest
from engram import Engram, EngramConfig


@pytest.fixture
def graph_memory():
    eng = Engram(EngramConfig(db_path=":memory:", semantic_search=False, graph_memory=False))
    yield eng
    eng.close()


def test_graph_tables_created():
    """Graph tables should be created even if graph_memory=False."""
    with Engram(EngramConfig(db_path=":memory:", semantic_search=False)) as m:
        m._init()
        # Tables exist
        result = m._conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('graph_nodes','graph_edges')"
        ).fetchall()
        assert len(result) == 2


def test_graph_no_extraction_when_disabled(graph_memory):
    """With graph_memory=False, no edges should be stored."""
    graph_memory.remember("s1", "Jeff builds GovScout in React", "user")
    edges = graph_memory._conn.execute(
        "SELECT COUNT(*) FROM graph_edges WHERE session_id = 's1'"
    ).fetchone()[0]
    assert edges == 0


def test_graph_manual_edge_and_query():
    """Store edges manually and verify graph() returns them."""
    with Engram(EngramConfig(db_path=":memory:", semantic_search=False)) as m:
        m._init()
        # Manually insert a memory and edges
        m._conn.execute(
            "INSERT INTO memories (id, session_id, content, role, timestamp, content_hash) VALUES (?, ?, ?, ?, ?, ?)",
            ("mem1", "s1", "GovScout uses React 19", "user", 1000000, "hash1")
        )
        from engram.engram import GraphEdge
        edge = GraphEdge(from_entity="govscout", relation="uses", to_entity="react 19", confidence=0.9)
        m._store_edge("s1", edge, "mem1")
        m._conn.commit()

        result = m.graph("s1", "GovScout")
        assert result.entity == "govscout"
        assert len(result.relationships) == 1
        assert result.relationships[0]["relation"] == "uses"
        assert result.relationships[0]["target"] == "react 19"
        assert result.relationships[0]["type"] == "outgoing"
        assert len(result.related_memories) == 1
        assert result.related_memories[0].content == "GovScout uses React 19"


def test_graph_incoming_edges():
    """Incoming edges should also be returned."""
    with Engram(EngramConfig(db_path=":memory:", semantic_search=False)) as m:
        m._init()
        m._conn.execute(
            "INSERT INTO memories (id, session_id, content, role, timestamp, content_hash) VALUES (?, ?, ?, ?, ?, ?)",
            ("mem1", "s1", "Jeff builds GovScout", "user", 1000000, "hash1")
        )
        from engram.engram import GraphEdge
        edge = GraphEdge(from_entity="jeff", relation="builds", to_entity="govscout", confidence=0.9)
        m._store_edge("s1", edge, "mem1")
        m._conn.commit()

        result = m.graph("s1", "govscout")
        assert len(result.relationships) == 1
        assert result.relationships[0]["type"] == "incoming"
        assert result.relationships[0]["target"] == "jeff"


def test_graph_empty_entity():
    """Unknown entity returns empty result."""
    with Engram(EngramConfig(db_path=":memory:", semantic_search=False)) as m:
        result = m.graph("s1", "unknown_entity")
        assert result.entity == "unknown_entity"
        assert result.relationships == []
        assert result.related_memories == []


def test_stats_includes_graph_counts():
    """stats() should include graph_nodes and graph_edges when graph_memory=True."""
    with Engram(EngramConfig(db_path=":memory:", semantic_search=False, graph_memory=True)) as m:
        m._init()
        m._conn.execute(
            "INSERT INTO memories (id, session_id, content, role, timestamp, content_hash) VALUES (?, ?, ?, ?, ?, ?)",
            ("mem1", "s1", "test", "user", 1000000, "hash1")
        )
        from engram.engram import GraphEdge
        m._store_edge("s1", GraphEdge("a", "rel", "b"), "mem1")
        m._conn.commit()

        stats = m.stats("s1")
        assert "graph_nodes" in stats
        assert "graph_edges" in stats
        assert stats["graph_nodes"] == 2
        assert stats["graph_edges"] == 1


def test_stats_no_graph_counts_when_disabled():
    """stats() should NOT include graph keys when graph_memory=False."""
    with Engram(EngramConfig(db_path=":memory:", semantic_search=False, graph_memory=False)) as m:
        m.remember("s1", "test", "user")
        stats = m.stats("s1")
        assert "graph_nodes" not in stats
        assert "graph_edges" not in stats


@pytest.mark.skipif(
    not __import__("subprocess").run(
        ["curl", "-s", "--max-time", "1", "http://192.168.68.73:11434/api/tags"],
        capture_output=True
    ).returncode == 0,
    reason="Ollama not available"
)
def test_graph_extraction_live():
    """Live test: extract entities from real text via qwen2.5:32b."""
    config = EngramConfig(
        db_path=":memory:",
        embedding_url="http://192.168.68.73:11434",
        semantic_search=True,
        graph_memory=True,
        graph_model="qwen2.5:32b"
    )
    with Engram(config) as m:
        m.remember("s1", "Jeff is building GovScout, a federal contracting app using React 19 and MUI", "user")
        m.remember("s1", "GovScout uses Strapi as the CMS backend", "user")

        stats = m.stats("s1")
        assert stats.get("graph_nodes", 0) > 0
        assert stats.get("graph_edges", 0) > 0

        result = m.graph("s1", "govscout")
        assert len(result.relationships) > 0
        print(f"\nGraph for 'govscout': {result.relationships}")
