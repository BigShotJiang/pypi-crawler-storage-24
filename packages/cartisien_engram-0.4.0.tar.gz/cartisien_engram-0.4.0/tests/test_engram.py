"""Tests for cartisien-engram Python SDK."""
import pytest
from datetime import datetime
from engram import Engram, EngramConfig


@pytest.fixture
def memory():
    """In-memory Engram instance (no Ollama needed)."""
    eng = Engram(EngramConfig(db_path=":memory:", semantic_search=False))
    yield eng
    eng.close()


def test_remember_and_recall(memory):
    entry = memory.remember("test", "User loves Python", "user")
    assert entry.id
    assert entry.content == "User loves Python"
    assert entry.role == "user"
    assert isinstance(entry.timestamp, datetime)


def test_recall_keyword(memory):
    memory.remember("s1", "User prefers TypeScript over JavaScript", "user")
    memory.remember("s1", "User likes dark mode", "user")
    
    results = memory.recall("s1", query="TypeScript")
    assert len(results) == 1
    assert "TypeScript" in results[0].content


def test_recall_no_query_returns_recent(memory):
    memory.remember("s1", "First memory", "user")
    memory.remember("s1", "Second memory", "user")
    
    results = memory.recall("s1", limit=10)
    assert len(results) == 2


def test_history_chronological(memory):
    memory.remember("s1", "First", "user")
    memory.remember("s1", "Second", "assistant")
    memory.remember("s1", "Third", "user")
    
    hist = memory.history("s1")
    assert len(hist) == 3
    assert hist[0].content == "First"
    assert hist[2].content == "Third"


def test_forget_all(memory):
    memory.remember("s1", "Memory 1", "user")
    memory.remember("s1", "Memory 2", "user")
    
    deleted = memory.forget("s1")
    assert deleted == 2
    
    results = memory.recall("s1")
    assert len(results) == 0


def test_forget_by_id(memory):
    entry = memory.remember("s1", "To delete", "user")
    memory.remember("s1", "To keep", "user")
    
    deleted = memory.forget("s1", id=entry.id)
    assert deleted == 1
    
    results = memory.recall("s1")
    assert len(results) == 1
    assert results[0].content == "To keep"


def test_forget_before(memory):
    import time
    memory.remember("s1", "Old memory", "user")
    time.sleep(0.01)
    cutoff = datetime.now()
    time.sleep(0.01)
    memory.remember("s1", "New memory", "user")
    
    deleted = memory.forget("s1", before=cutoff)
    assert deleted == 1
    
    results = memory.recall("s1")
    assert len(results) == 1
    assert results[0].content == "New memory"


def test_stats(memory):
    memory.remember("s1", "User message", "user")
    memory.remember("s1", "Assistant response", "assistant")
    memory.remember("s1", "Another user message", "user")
    
    stats = memory.stats("s1")
    assert stats["total"] == 3
    assert stats["by_role"]["user"] == 2
    assert stats["by_role"]["assistant"] == 1
    assert stats["oldest"] is not None
    assert stats["newest"] is not None


def test_session_isolation(memory):
    memory.remember("session_a", "Secret of A", "user")
    memory.remember("session_b", "Secret of B", "user")
    
    results_a = memory.recall("session_a")
    results_b = memory.recall("session_b")
    
    assert len(results_a) == 1
    assert "Secret of A" in results_a[0].content
    assert len(results_b) == 1
    assert "Secret of B" in results_b[0].content


def test_context_manager():
    with Engram(EngramConfig(db_path=":memory:", semantic_search=False)) as memory:
        memory.remember("s1", "test", "user")
        results = memory.recall("s1")
        assert len(results) == 1


def test_metadata(memory):
    entry = memory.remember("s1", "Content", "user", metadata={"source": "test", "score": 0.9})
    assert entry.metadata == {"source": "test", "score": 0.9}
    
    results = memory.recall("s1")
    assert results[0].metadata == {"source": "test", "score": 0.9}


def test_max_context_length():
    config = EngramConfig(db_path=":memory:", semantic_search=False, max_context_length=10)
    memory = Engram(config)
    entry = memory.remember("s1", "This is a very long content that should be truncated", "user")
    assert len(entry.content) == 10
    memory.close()


@pytest.mark.skipif(
    not __import__("subprocess").run(
        ["curl", "-s", "--max-time", "1", "http://192.168.68.73:11434/api/tags"],
        capture_output=True
    ).returncode == 0,
    reason="Ollama not available"
)
def test_semantic_recall_with_ollama():
    config = EngramConfig(
        db_path=":memory:",
        embedding_url="http://192.168.68.73:11434",
        semantic_search=True
    )
    with Engram(config) as memory:
        memory.remember("s1", "User is building a federal contracting app", "user")
        memory.remember("s1", "User prefers dark mode", "user")
        
        results = memory.recall("s1", query="what project is the user building?", limit=5)
        assert len(results) > 0
        # The contracting app should rank higher
        assert results[0].similarity is not None
        assert "contracting" in results[0].content.lower() or results[0].similarity > 0.3
