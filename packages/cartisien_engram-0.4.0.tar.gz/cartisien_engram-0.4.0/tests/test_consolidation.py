"""Tests for v0.4 memory consolidation."""
import time
import pytest
from engram import Engram, EngramConfig, ConsolidateOptions


@pytest.fixture
def memory():
    eng = Engram(EngramConfig(db_path=":memory:", semantic_search=False))
    yield eng
    eng.close()


def _store_n(memory, session, n, prefix="Memory"):
    for i in range(n):
        memory.remember(session, f"{prefix} {i + 1}: some content about topic {i % 5}", "user")
        time.sleep(0.001)  # ensure distinct timestamps


# ── Schema ──────────────────────────────────────────────────────────────────

def test_tier_column_exists(memory):
    memory._init()
    cols = [
        row[1] for row in
        memory._conn.execute("PRAGMA table_info(memories)").fetchall()
    ]
    assert "tier" in cols
    assert "consolidated_from" in cols


def test_new_memories_are_working_tier(memory):
    memory.remember("s1", "test content", "user")
    row = memory._conn.execute(
        "SELECT tier FROM memories WHERE session_id = 's1'"
    ).fetchone()
    assert row["tier"] == "working"


# ── consolidate() basics ─────────────────────────────────────────────────────

def test_consolidate_empty_session(memory):
    result = memory.consolidate("empty_session")
    assert result.summarized == 0
    assert result.created == 0
    assert result.archived == 0


def test_consolidate_fewer_than_keep(memory):
    """With fewer memories than keep threshold, nothing should be consolidated."""
    _store_n(memory, "s1", 5)
    result = memory.consolidate("s1", ConsolidateOptions(keep=10))
    assert result.summarized == 0
    assert result.created == 0


def test_consolidate_dry_run_no_writes(memory):
    _store_n(memory, "s1", 30)

    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["Summary A about topics 0-4", "Summary B about topics 0-4"]

    m2 = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m2, "s1", 30)

    result = m2.consolidate("s1", ConsolidateOptions(keep=5, dry_run=True))

    assert result.created == 0
    assert result.archived == 0
    assert result.previews is not None
    assert len(result.previews) == 2

    # DB unchanged — all memories still working
    count = m2._conn.execute(
        "SELECT COUNT(*) FROM memories WHERE session_id = 's1' AND tier = 'working'"
    ).fetchone()[0]
    assert count == 30
    m2.close()


def test_consolidate_archives_originals(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["Consolidated: " + " | ".join(e.content[:20] for e in entries[:3])]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m, "s1", 20)

    result = m.consolidate("s1", ConsolidateOptions(batch=10, keep=5))

    assert result.summarized == 10
    assert result.created == 1
    assert result.archived == 10

    working = m._conn.execute(
        "SELECT COUNT(*) FROM memories WHERE session_id = 's1' AND tier = 'working'"
    ).fetchone()[0]
    archived = m._conn.execute(
        "SELECT COUNT(*) FROM memories WHERE session_id = 's1' AND tier = 'archived'"
    ).fetchone()[0]
    long_term = m._conn.execute(
        "SELECT COUNT(*) FROM memories WHERE session_id = 's1' AND tier = 'long_term'"
    ).fetchone()[0]

    assert working == 10   # the 5 kept + 5 that didn't fit in batch
    assert archived == 10
    assert long_term == 1
    m.close()


def test_consolidate_long_term_has_consolidated_from(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["A summary of important facts"]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m, "s1", 15)

    m.consolidate("s1", ConsolidateOptions(batch=10, keep=3))

    lt_row = m._conn.execute(
        "SELECT consolidated_from FROM memories WHERE session_id = 's1' AND tier = 'long_term'"
    ).fetchone()
    assert lt_row is not None
    source_ids = __import__("json").loads(lt_row["consolidated_from"])
    assert isinstance(source_ids, list)
    assert len(source_ids) == 10
    m.close()


def test_consolidate_keeps_most_recent(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["summary"]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    contents = [f"Memory {i}" for i in range(10)]
    for c in contents:
        m.remember("s1", c, "user")
        time.sleep(0.001)

    m.consolidate("s1", ConsolidateOptions(batch=10, keep=3))

    working_rows = m._conn.execute(
        "SELECT content FROM memories WHERE session_id = 's1' AND tier = 'working' ORDER BY timestamp DESC"
    ).fetchall()
    working_contents = [r["content"] for r in working_rows]

    # The 3 most recent should still be working
    assert "Memory 9" in working_contents
    assert "Memory 8" in working_contents
    assert "Memory 7" in working_contents
    assert "Memory 0" not in working_contents
    m.close()


# ── recall() tier filtering ──────────────────────────────────────────────────

def test_recall_excludes_archived_by_default(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["A condensed summary of everything"]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m, "s1", 15)
    m.consolidate("s1", ConsolidateOptions(batch=10, keep=3))

    results = m.recall("s1", limit=100)
    tiers = {r.tier for r in results}
    assert "archived" not in tiers
    assert "working" in tiers or "long_term" in tiers
    m.close()


def test_recall_can_include_archived(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["summary"]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m, "s1", 15)
    m.consolidate("s1", ConsolidateOptions(batch=10, keep=3))

    from engram import RecallOptions
    results = m.recall("s1", limit=100, options=RecallOptions(
        tiers=["working", "long_term", "archived"]
    ))
    tiers = {r.tier for r in results}
    assert "archived" in tiers
    m.close()


def test_recall_long_term_has_consolidated_from(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["important summary"]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m, "s1", 15)
    m.consolidate("s1", ConsolidateOptions(batch=10, keep=3))

    from engram import RecallOptions
    results = m.recall("s1", options=RecallOptions(tiers=["long_term"]))
    assert len(results) >= 1
    lt = results[0]
    assert lt.tier == "long_term"
    assert lt.consolidated_from is not None
    assert isinstance(lt.consolidated_from, list)
    m.close()


# ── stats() ──────────────────────────────────────────────────────────────────

def test_stats_includes_by_tier(memory):
    memory.remember("s1", "a", "user")
    memory.remember("s1", "b", "user")
    stats = memory.stats("s1")
    assert "by_tier" in stats
    assert stats["by_tier"]["working"] == 2
    assert stats["by_tier"]["long_term"] == 0
    assert stats["by_tier"]["archived"] == 0


def test_stats_by_tier_after_consolidation(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["summary one", "summary two"]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m, "s1", 15)
    m.consolidate("s1", ConsolidateOptions(batch=10, keep=3))

    stats = m.stats("s1")
    assert stats["by_tier"]["long_term"] == 2
    assert stats["by_tier"]["archived"] == 10
    assert stats["by_tier"]["working"] == 5  # 3 kept + 2 that didn't fit batch
    # total excludes archived
    assert stats["total"] == stats["by_tier"]["working"] + stats["by_tier"]["long_term"]
    m.close()


# ── forget() ─────────────────────────────────────────────────────────────────

def test_forget_skips_archived_by_default(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["summary"]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m, "s1", 15)
    m.consolidate("s1", ConsolidateOptions(batch=10, keep=3))

    archived_before = m._conn.execute(
        "SELECT COUNT(*) FROM memories WHERE session_id = 's1' AND tier = 'archived'"
    ).fetchone()[0]
    assert archived_before == 10

    m.forget("s1")  # should not delete archived

    archived_after = m._conn.execute(
        "SELECT COUNT(*) FROM memories WHERE session_id = 's1' AND tier = 'archived'"
    ).fetchone()[0]
    assert archived_after == 10
    m.close()


def test_forget_include_long_term_deletes_all(memory):
    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["summary"]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    _store_n(m, "s1", 15)
    m.consolidate("s1", ConsolidateOptions(batch=10, keep=3))

    m.forget("s1", include_long_term=True)

    total = m._conn.execute(
        "SELECT COUNT(*) FROM memories WHERE session_id = 's1'"
    ).fetchone()[0]
    assert total == 0
    m.close()


# ── auto-consolidate ─────────────────────────────────────────────────────────

def test_auto_consolidate_triggers_at_threshold():
    consolidate_called = []

    class MockEngram(Engram):
        def consolidate(self, session_id, options=None):
            consolidate_called.append(session_id)
            return super().consolidate(session_id, options)

        def _summarize_memories(self, entries, model):
            return ["auto-summary"]

    m = MockEngram(EngramConfig(
        db_path=":memory:",
        semantic_search=False,
        auto_consolidate=True,
        consolidate_threshold=5,
        consolidate_keep=2,
        consolidate_batch=10,
    ))

    for i in range(6):
        m.remember("s1", f"memory {i}", "user")
        time.sleep(0.001)

    # Consolidation should have been triggered at least once
    assert len(consolidate_called) >= 1
    m.close()


# ── MemoryEntry fields ────────────────────────────────────────────────────────

def test_memory_entry_has_tier(memory):
    entry = memory.remember("s1", "test", "user")
    assert entry.tier == "working"
    assert entry.consolidated_from is None


def test_recall_entries_have_tier(memory):
    memory.remember("s1", "test", "user")
    results = memory.recall("s1")
    assert results[0].tier == "working"


# ── Live Ollama test (skipped if unavailable) ────────────────────────────────

@pytest.mark.skipif(
    not __import__("subprocess").run(
        ["curl", "-s", "--max-time", "1", "http://192.168.68.73:11434/api/tags"],
        capture_output=True
    ).returncode == 0,
    reason="Ollama not available"
)
def test_consolidation_live():
    """Live test: real LLM summarization via qwen2.5:32b."""
    config = EngramConfig(
        db_path=":memory:",
        embedding_url="http://192.168.68.73:11434",
        semantic_search=True,
        consolidate_model="qwen2.5:32b",
    )
    with Engram(config) as m:
        memories = [
            ("Jeff is building GovScout, a federal contracting app", "user"),
            ("GovScout uses React 19, MUI, and Vite", "user"),
            ("Jeff prefers TypeScript over JavaScript", "user"),
            ("Jeff's goal is $10k/mo recurring revenue", "user"),
            ("GovScout is hosted on DigitalOcean", "user"),
            ("Jeff is also building Motordrome, a motorsports content platform", "user"),
            ("Jeff prefers concise answers without filler", "user"),
            ("Jeff works solo under Cartisien Interactive", "user"),
        ]
        for content, role in memories:
            m.remember("test_live", content, role)
            time.sleep(0.001)

        result = m.consolidate("test_live", ConsolidateOptions(batch=6, keep=2))

        assert result.summarized == 6
        assert result.created >= 1
        assert result.archived == 6
        assert result.previews is None

        stats = m.stats("test_live")
        assert stats["by_tier"]["long_term"] >= 1
        assert stats["by_tier"]["archived"] == 6
        assert stats["by_tier"]["working"] == 2

        # Recall should find long_term summaries
        results = m.recall("test_live", "what is Jeff building?", limit=5)
        assert len(results) > 0
        assert any(r.tier == "long_term" for r in results)

        print(f"\nConsolidation result: {result}")
        print(f"Stats: {stats}")
        print(f"Long-term summaries:")
        for r in results:
            if r.tier == "long_term":
                print(f"  [{r.tier}] {r.content}")
