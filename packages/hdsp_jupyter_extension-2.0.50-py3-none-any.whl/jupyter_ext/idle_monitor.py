"""
Server-side Idle Monitor.

브라우저가 닫혀도 커널/터미널 활동을 감지하여 idle timeout을 서버에서 처리.
Jupyter Server의 커널/터미널 매니저를 통해 마지막 활동 시간을 추적한다.
"""

import asyncio
import logging
import os
import time
from typing import Optional

logger = logging.getLogger(__name__)

# 기본 idle timeout: 60분
DEFAULT_IDLE_TIMEOUT_SECONDS = 60 * 60

# 서버 체크 주기: 30초
CHECK_INTERVAL_SECONDS = 30


class ServerIdleMonitor:
    """서버 사이드 유휴 상태 모니터."""

    def __init__(self, server_app):
        self.server_app = server_app
        self.last_activity_time = time.time()
        self._task: Optional[asyncio.Task] = None
        self._shutdown_triggered = False

        # idle timeout 설정 로드
        self.idle_timeout_seconds = self._load_timeout()

        # 환경변수 (shutdown API용)
        self.hdsp_env = os.environ.get("HDSP_ENV")
        self.project_id = os.environ.get("HDSP_PRJ_ID")
        self.user_id = os.environ.get("JUPYTERHUB_USER")

    def _load_timeout(self) -> int:
        """config에서 idle timeout 로드. 최대 1시간."""
        try:
            from hdsp_agent_core.managers.config_manager import get_config_manager

            cm = get_config_manager()
            config = cm.get_config()
            timeout = config.get("idleTimeout")
            if isinstance(timeout, (int, float)) and timeout > 0:
                return min(int(timeout), DEFAULT_IDLE_TIMEOUT_SECONDS)
        except Exception:
            pass
        return DEFAULT_IDLE_TIMEOUT_SECONDS

    def start(self):
        """모니터링 시작."""
        if self.idle_timeout_seconds <= 0:
            logger.info("[ServerIdleMonitor] Disabled (timeout=0)")
            return

        if not (self.hdsp_env and self.project_id and self.user_id):
            logger.info(
                "[ServerIdleMonitor] Disabled (missing HDSP_ENV/HDSP_PRJ_ID/JUPYTERHUB_USER)"
            )
            return

        self._task = asyncio.ensure_future(self._monitor_loop())
        logger.info(
            "[ServerIdleMonitor] Started. timeout=%ds, check_interval=%ds",
            self.idle_timeout_seconds,
            CHECK_INTERVAL_SECONDS,
        )

    def stop(self):
        """모니터링 중지."""
        if self._task and not self._task.done():
            self._task.cancel()
            logger.info("[ServerIdleMonitor] Stopped")

    def reset(self):
        """활동 감지 시 타이머 리셋 (HTTP 요청 시 호출)."""
        self.last_activity_time = time.time()

    def _check_kernel_activity(self) -> float:
        """커널 매니저에서 마지막 활동 시간 조회. epoch 반환."""
        last = 0.0
        try:
            km = self.server_app.kernel_manager
            for kid in km.list_kernel_ids():
                kernel = km.get_kernel(kid)
                # last_activity는 datetime 객체
                if hasattr(kernel, "last_activity") and kernel.last_activity:
                    ts = kernel.last_activity.timestamp()
                    if ts > last:
                        last = ts
                # execution_state로 busy 체크
                if hasattr(kernel, "execution_state") and kernel.execution_state == "busy":
                    return time.time()  # busy면 지금 활동 중
        except Exception as e:
            logger.debug("[ServerIdleMonitor] Kernel check error: %s", e)
        return last

    def _check_terminal_activity(self) -> float:
        """터미널 매니저에서 마지막 활동 시간 조회."""
        last = 0.0
        try:
            tm = self.server_app.web_app.settings.get("terminal_manager")
            if tm is None:
                return last
            for term_name in tm.list():
                term = tm.get(term_name)
                if hasattr(term, "last_activity") and term.last_activity:
                    ts = term.last_activity.timestamp()
                    if ts > last:
                        last = ts
        except Exception as e:
            logger.debug("[ServerIdleMonitor] Terminal check error: %s", e)
        return last

    async def _monitor_loop(self):
        """주기적으로 idle 상태를 체크."""
        try:
            while True:
                await asyncio.sleep(CHECK_INTERVAL_SECONDS)

                if self._shutdown_triggered:
                    break

                # 커널/터미널에서 마지막 활동 시간 조회
                kernel_last = self._check_kernel_activity()
                terminal_last = self._check_terminal_activity()

                # HTTP 요청 활동, 커널 활동, 터미널 활동 중 가장 최근
                latest_activity = max(
                    self.last_activity_time, kernel_last, terminal_last
                )

                idle_seconds = time.time() - latest_activity

                if idle_seconds >= self.idle_timeout_seconds:
                    logger.info(
                        "[ServerIdleMonitor] Idle timeout reached (%.0fs idle). Triggering shutdown.",
                        idle_seconds,
                    )
                    self._shutdown_triggered = True
                    await self._call_shutdown_api()
                    break

        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error("[ServerIdleMonitor] Monitor loop error: %s", e, exc_info=True)

    async def _call_shutdown_api(self):
        """HDSP shutdown API 호출."""
        import httpx

        if self.hdsp_env == "dev":
            api_base = "https://hdsp-api-dev.hyundaicard.com"
        elif self.hdsp_env == "prod":
            api_base = "https://hdsp-api.hyundaicard.com"
        else:
            logger.warning("[ServerIdleMonitor] Unknown HDSP_ENV: %s", self.hdsp_env)
            return

        api_url = f"{api_base}/k8s/jupyter/{self.project_id}/{self.user_id}"
        logger.info("[ServerIdleMonitor] Calling shutdown API: DELETE %s", api_url)

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.delete(api_url)

            if response.status_code in (200, 204):
                logger.info("[ServerIdleMonitor] Shutdown API success")
            else:
                logger.error(
                    "[ServerIdleMonitor] Shutdown API failed: %s %s",
                    response.status_code,
                    response.text,
                )
        except Exception as e:
            logger.error("[ServerIdleMonitor] Shutdown API error: %s", e)
