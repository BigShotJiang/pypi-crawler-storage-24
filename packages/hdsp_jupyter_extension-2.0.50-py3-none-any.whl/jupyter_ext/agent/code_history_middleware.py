"""CodeHistoryTracker + CodeHistoryMiddleware.

코드 실행 이력을 추적하고, 서브에이전트(python_developer)에 이전 코드 컨텍스트를 주입.

데이터 흐름:
    HITL edit decision (execution_result)
        -> http_handlers.py: track_tool_execution()
        -> CodeHistoryTracker: 이력 저장
        -> Main Agent -> task(python_developer)
        -> CodeHistoryMiddleware.awrap_tool_call: description에 코드 히스토리 append
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Optional

from langchain.agents.middleware.types import AgentMiddleware

logger = logging.getLogger(__name__)

# 토큰 추정: 1 토큰 ~= 4 chars
_CHARS_PER_TOKEN = 4
_MAX_CONTEXT_TOKENS = 50000
_MAX_CONTEXT_CHARS = _MAX_CONTEXT_TOKENS * _CHARS_PER_TOKEN
_RECENT_FULL_COUNT = 3  # 최근 N개는 전체 코드+출력 유지


@dataclass
class CodeHistoryEntry:
    """단일 코드 실행 이력."""

    tool_name: str  # jupyter_cell, file_write
    code: Optional[str] = None
    output: Optional[str] = None
    file_path: Optional[str] = None

    def to_context_string(self) -> str:
        """전체 코드+출력 포맷."""
        parts = [f"[{self.tool_name}]"]
        if self.file_path:
            parts.append(f"File: {self.file_path}")
        if self.code:
            parts.append(f"```python\n{self.code}\n```")
        if self.output:
            parts.append(f"Output:\n{self.output[:2000]}")
        return "\n".join(parts)

    def to_summary_string(self) -> str:
        """한 줄 요약."""
        if self.tool_name == "file_write":
            return f"[file_write] {self.file_path or 'unknown'}"
        code_preview = (self.code or "")[:80].replace("\n", " ")
        output_preview = (self.output or "")[:60].replace("\n", " ")
        return f"[{self.tool_name}] {code_preview} -> {output_preview}"


class CodeHistoryTracker:
    """스레드별 코드 실행 이력 관리."""

    def __init__(self) -> None:
        self._history: list[CodeHistoryEntry] = []

    def add_jupyter_cell(self, code: str, output: Optional[str] = None) -> None:
        self._history.append(
            CodeHistoryEntry(tool_name="jupyter_cell", code=code, output=output)
        )

    def add_write_file(self, file_path: str, content: Optional[str] = None) -> None:
        self._history.append(
            CodeHistoryEntry(tool_name="file_write", code=content, file_path=file_path)
        )

    @property
    def entries(self) -> list[CodeHistoryEntry]:
        return list(self._history)

    def get_context_for_subagent(
        self,
        existing_context: str = "",
        max_tokens: int = _MAX_CONTEXT_TOKENS,
    ) -> str:
        """서브에이전트에 주입할 코드 히스토리 컨텍스트 생성.

        최근 _RECENT_FULL_COUNT개는 전체 코드+출력,
        그 이전은 한 줄 요약으로 토큰 관리.
        """
        if not self._history:
            return existing_context

        max_chars = max_tokens * _CHARS_PER_TOKEN
        existing_chars = len(existing_context)
        budget = max_chars - existing_chars
        if budget <= 200:
            return existing_context

        history_parts: list[str] = []
        total = len(self._history)

        # 오래된 항목: 요약
        if total > _RECENT_FULL_COUNT:
            for entry in self._history[: total - _RECENT_FULL_COUNT]:
                history_parts.append(entry.to_summary_string())

        # 최근 항목: 전체
        recent_start = max(0, total - _RECENT_FULL_COUNT)
        for entry in self._history[recent_start:]:
            history_parts.append(entry.to_context_string())

        history_text = "\n\n".join(history_parts)

        # 예산 초과 시 잘라내기
        if len(history_text) > budget:
            history_text = history_text[-(budget - 50) :]
            history_text = "...(truncated)\n" + history_text

        section = f"\n\n## Previous Code Execution History\n{history_text}\n"

        if existing_context:
            return existing_context + section
        return section.strip()


# ---------------------------------------------------------------------------
# Global tracker registry (per thread_id)
# ---------------------------------------------------------------------------

_code_history_trackers: dict[str, CodeHistoryTracker] = {}


def get_code_history_tracker(thread_id: str) -> CodeHistoryTracker:
    """thread_id별 CodeHistoryTracker 반환 (없으면 새로 생성)."""
    if thread_id not in _code_history_trackers:
        _code_history_trackers[thread_id] = CodeHistoryTracker()
    return _code_history_trackers[thread_id]


def track_tool_execution(
    tool_name: str, args: dict, thread_id: str
) -> None:
    """HITL edit decision에서 호출: 코드 실행 이력 기록."""
    tracker = get_code_history_tracker(thread_id)

    if tool_name == "jupyter_cell":
        code = args.get("code", "")
        exec_result = args.get("execution_result", {})
        output = None
        if isinstance(exec_result, dict):
            output = exec_result.get("output", exec_result.get("text", ""))
        tracker.add_jupyter_cell(code, output)
        logger.debug(
            "CodeHistory: tracked jupyter_cell (code_len=%d, has_output=%s)",
            len(code),
            bool(output),
        )
    elif tool_name == "file_write":
        file_path = args.get("path", "")
        content = args.get("content", "")
        tracker.add_write_file(file_path, content)
        logger.debug("CodeHistory: tracked file_write (path=%s)", file_path)


# ---------------------------------------------------------------------------
# CodeHistoryMiddleware
# ---------------------------------------------------------------------------


class CodeHistoryMiddleware(AgentMiddleware):
    """task 도구 호출 인터셉트하여 python_developer에 코드 히스토리 주입."""

    async def awrap_tool_call(self, request, handler):
        tool_call = request.tool_call
        tool_name = tool_call.get("name", "")

        if tool_name == "task":
            args = tool_call.get("args", {})
            subagent_type = args.get("subagent_type", args.get("agent_name", ""))

            if subagent_type == "python_developer":
                # thread_id 추출 시도
                thread_id = self._extract_thread_id(request)
                if thread_id:
                    tracker = get_code_history_tracker(thread_id)
                    if tracker.entries:
                        description = args.get("description", "")
                        enhanced = tracker.get_context_for_subagent(description)
                        new_args = {**args, "description": enhanced}
                        new_tool_call = {**tool_call, "args": new_args}
                        request = request.override(tool_call=new_tool_call)
                        logger.debug(
                            "CodeHistory: injected %d entries into python_developer task",
                            len(tracker.entries),
                        )

        return await handler(request)

    def _extract_thread_id(self, request: Any) -> str:
        """request에서 thread_id 추출."""
        # runtime config에서 추출 시도
        if hasattr(request, "config"):
            config = request.config
            if isinstance(config, dict):
                return config.get("configurable", {}).get("thread_id", "")
        # state에서 추출 시도
        if hasattr(request, "state"):
            state = request.state
            if isinstance(state, dict):
                return state.get("thread_id", "")
        return ""
