"""
SkillMiddleware

Middleware that provides progressive skill loading for code generation agents.
Based on LangChain Skills pattern for token-efficient context injection.

Key features:
- Injects skill metadata into system prompt (~250 tokens)
- Provides load_skill tool for on-demand full content loading
- Reads skill definitions from markdown files
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from langchain_core.tools import tool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Skills directory path
SKILLS_DIR = Path(__file__).parent / "skills"


def _parse_skill_metadata(file_path: Path) -> Optional[Dict[str, str]]:
    """Parse skill metadata from markdown file's YAML frontmatter.

    Expected format:
    ---
    name: skill-name
    description: Skill description
    ---
    """
    try:
        content = file_path.read_text(encoding="utf-8")

        if not content.startswith("---"):
            logger.warning(f"Skill file missing YAML frontmatter: {file_path}")
            return None

        parts = content.split("---", 2)
        if len(parts) < 3:
            logger.warning(f"Invalid YAML frontmatter format: {file_path}")
            return None

        frontmatter = yaml.safe_load(parts[1])
        if not frontmatter or "name" not in frontmatter:
            logger.warning(f"Missing 'name' in frontmatter: {file_path}")
            return None

        return {
            "name": frontmatter.get("name"),
            "description": frontmatter.get("description", "No description"),
            "path": str(file_path),
        }
    except Exception as e:
        logger.error(f"Failed to parse skill file {file_path}: {e}")
        return None


def _load_all_skills() -> Dict[str, Dict[str, str]]:
    """Load all skill metadata from the skills directory."""
    skills = {}

    if not SKILLS_DIR.exists():
        logger.warning(f"Skills directory not found: {SKILLS_DIR}")
        return skills

    for file_path in SKILLS_DIR.glob("*.md"):
        metadata = _parse_skill_metadata(file_path)
        if metadata:
            skills[metadata["name"]] = metadata
            logger.debug(f"Loaded skill: {metadata['name']}")

    logger.info(f"Loaded {len(skills)} skills from {SKILLS_DIR}")
    return skills


def _get_skill_content(skill_name: str, skills: Dict[str, Dict[str, str]]) -> str:
    """Load full content of a skill file (excluding YAML frontmatter)."""
    if skill_name not in skills:
        available = ", ".join(skills.keys())
        return f"Error: Unknown skill '{skill_name}'. Available skills: {available}"

    try:
        file_path = Path(skills[skill_name]["path"])
        content = file_path.read_text(encoding="utf-8")

        # Remove YAML frontmatter
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                content = parts[2].strip()

        return content
    except Exception as e:
        return f"Error loading skill '{skill_name}': {str(e)}"


def _build_skills_prompt_section(skills: Dict[str, Dict[str, str]]) -> str:
    """Build the Available Skills section for system prompt injection (~250 tokens)."""
    if not skills:
        return ""

    lines = ["## Available Skills"]
    lines.append("")
    lines.append("### Context 리소스 정보")
    lines.append(
        "Main Agent가 task 호출 시 제공하는 Context에는 다음 정보가 포함됩니다:"
    )
    lines.append("- **파일 크기**: `file_size: 200MB`, `total_size: 1.5GB` 등")
    lines.append("- **시스템 메모리**: `available_memory: 16GB`, `gpu_memory: 8GB` 등")
    lines.append("- **데이터 행 수**: `row_count: 10000000` 등")
    lines.append("")
    lines.append("### 스킬 로드 규칙 (MANDATORY)")
    lines.append("**아래 조건에 해당하면 반드시 load_skill_tool()을 먼저 호출하세요:**")
    lines.append("1. 파일 크기 >= 100MB → `load_skill_tool('data_loading')`")
    lines.append("2. DataFrame 행 수 >= 100만 → `load_skill_tool('data_analysis')`")
    lines.append(
        "3. GPU/CUDA 사용 또는 모델 훈련 → `load_skill_tool('model_training')`"
    )
    lines.append("4. 모델 추론 최적화 필요 → `load_skill_tool('inference')`")
    lines.append("5. PySpark/분산처리 → `load_skill_tool('pyspark')`")
    lines.append("")

    for name, metadata in sorted(skills.items()):
        lines.append(f"- **{name}**: {metadata['description']}")

    lines.append("")
    lines.append("### 스킬 미사용 시점")
    lines.append("- 단순 print(), 기본 연산")
    lines.append("- 소형 파일 (< 100MB) 기본 처리")
    lines.append("- DataFrame 행 수 < 100만")
    lines.append("- Context에 리소스 정보가 명시되지 않은 경우")

    return "\n".join(lines)


def _create_load_skill_tool(skills: Dict[str, Dict[str, str]]):
    """Create the load_skill_tool for on-demand skill loading."""
    available_skills = ", ".join(sorted(skills.keys()))

    class LoadSkillInput(BaseModel):
        """Input schema for load_skill_tool"""

        skill_name: str = Field(
            description=f"Name of the skill to load. Available: {available_skills}"
        )

    @tool(args_schema=LoadSkillInput)
    def load_skill_tool(skill_name: str) -> str:
        """
        Load detailed optimization guide for a specific skill.

        Use this tool when you need specific optimization patterns for:
        - data-loading: Large file handling (chunking, dtype, Dask)
        - data-analysis: DataFrame operations (vectorization, groupby)
        - model-training: GPU/memory optimization (fp16, gradient checkpointing)
        - inference: Model serving optimization (batching, quantization, TensorRT)
        - pyspark: Distributed processing (partitioning, caching, broadcast join)

        Args:
            skill_name: Name of the skill to load

        Returns:
            Full optimization guide with code patterns and best practices
        """
        logger.info(f"Loading skill: {skill_name}")
        content = _get_skill_content(skill_name, skills)

        if not content.startswith("Error"):
            logger.info(f"Skill '{skill_name}' loaded: {len(content)} chars")

        return content

    return load_skill_tool


class SkillMiddleware:
    """Middleware that adds skill loading capability to code generation agents.

    This middleware:
    1. Injects Available Skills section into system prompt (~250 tokens)
    2. Adds the `load_skill` tool for on-demand content loading
    3. Enables token-efficient progressive disclosure of optimization guides

    Usage:
        skill_mw = get_skill_middleware()
        skills_section = skill_mw.get_prompt_section()
        tools = skill_mw.get_tools()
    """

    def __init__(self):
        self.skills = _load_all_skills()
        self.prompt_section = _build_skills_prompt_section(self.skills)
        self.load_skill_tool = _create_load_skill_tool(self.skills)

        logger.info(
            f"SkillMiddleware initialized with {len(self.skills)} skills: "
            f"{list(self.skills.keys())}"
        )

    def get_prompt_section(self) -> str:
        """Get the Available Skills section for system prompt."""
        return self.prompt_section

    def get_tools(self) -> List[Any]:
        """Get the tools provided by this middleware."""
        return [self.load_skill_tool]


# Singleton instance
_skill_middleware_instance: Optional[SkillMiddleware] = None


def get_skill_middleware() -> SkillMiddleware:
    """Get the singleton SkillMiddleware instance."""
    global _skill_middleware_instance
    if _skill_middleware_instance is None:
        _skill_middleware_instance = SkillMiddleware()
    return _skill_middleware_instance
