"""
에이전트 서비스 구현

IAgentService의 Embedded 및 Proxy 구현.
"""

import json
import logging
import re
import subprocess
from typing import Any, Dict, List, Optional

import httpx

from hdsp_agent_core.interfaces import IAgentService
from hdsp_agent_core.llm import LLMService
from hdsp_agent_core.managers import get_config_manager
from hdsp_agent_core.models.agent import (
    PlanRequest,
    PlanResponse,
    RefineRequest,
    RefineResponse,
    ReplanRequest,
    ReplanResponse,
)
from hdsp_agent_core.prompts import format_plan_prompt, format_refine_prompt

logger = logging.getLogger(__name__)


class EmbeddedAgentService(IAgentService):
    """
    에이전트 서비스의 Embedded 구현.

    HTTP 호출 없이 인프로세스에서 직접 에이전트 로직을 실행합니다.
    개발 모드(HDSP_AGENT_MODE=embedded)에서 사용됩니다.
    """

    def __init__(self):
        """Embedded 에이전트 서비스 초기화"""
        self._config_manager = get_config_manager()
        logger.info("EmbeddedAgentService 초기화됨")

    def _get_config(self) -> Dict[str, Any]:
        """현재 LLM 설정 반환"""
        return self._config_manager.get_config()

    def _build_llm_config(self, llm_config) -> Dict[str, Any]:
        """클라이언트 제공 설정에서 LLM 설정 딕셔너리 구성"""
        if llm_config is None:
            return self._get_config()

        config = {"provider": llm_config.provider}

        if llm_config.vllm:
            config["vllm"] = {
                "endpoint": llm_config.vllm.endpoint,
                "apiKey": llm_config.vllm.apiKey,
                "model": llm_config.vllm.model,
            }

        return config

    async def _call_llm(self, prompt: str, llm_config=None) -> str:
        """프롬프트로 LLM 호출"""
        config = self._build_llm_config(llm_config)
        llm_service = LLMService(config)
        return await llm_service.generate_response(prompt)

    def _parse_json_response(self, response: str) -> Dict[str, Any]:
        """LLM 응답에서 JSON 추출"""
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            pass

        json_patterns = [
            r"```json\s*([\s\S]*?)\s*```",
            r"```\s*([\s\S]*?)\s*```",
            r"\{[\s\S]*\}",
        ]

        for pattern in json_patterns:
            matches = re.findall(pattern, response)
            for match in matches:
                try:
                    return json.loads(match)
                except json.JSONDecodeError:
                    continue

        return {}

    def _sanitize_tool_calls(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """도구 호출의 code 매개변수에서 마크다운 코드 블록 제거"""

        def clean_code(code: str) -> str:
            if not code:
                return code
            code = re.sub(r"^```(?:python)?\s*\n?", "", code)
            code = re.sub(r"\n?```\s*$", "", code)
            return code.strip()

        if "plan" in data and "steps" in data["plan"]:
            for step in data["plan"]["steps"]:
                for tc in step.get("toolCalls", []):
                    if tc.get("tool") == "jupyter_cell":
                        params = tc.get("parameters", {})
                        if "code" in params:
                            params["code"] = clean_code(params["code"])

        if "toolCalls" in data:
            for tc in data["toolCalls"]:
                if tc.get("tool") == "jupyter_cell":
                    params = tc.get("parameters", {})
                    if "code" in params:
                        params["code"] = clean_code(params["code"])

        return data

    def _detect_required_libraries(
        self, request: str, imported_libraries: List[str]
    ) -> List[str]:
        """결정론적 라이브러리 감지"""
        from hdsp_agent_core.knowledge import get_knowledge_base, get_library_detector

        knowledge_base = get_knowledge_base()
        library_detector = get_library_detector()

        available = knowledge_base.list_available_libraries()
        if not available:
            return []

        return library_detector.detect(
            request=request,
            available_libraries=available,
            imported_libraries=imported_libraries,
        )

    def _get_installed_packages(self) -> List[str]:
        """설치된 Python 패키지 목록 반환"""
        try:
            result = subprocess.run(
                ["pip", "list", "--format=freeze"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            packages = []
            for line in result.stdout.strip().split("\n"):
                if "==" in line:
                    packages.append(line.split("==")[0].lower())
            return packages[:100]
        except Exception:
            return []

    async def generate_plan(self, request: PlanRequest) -> PlanResponse:
        """실행 계획 생성"""
        logger.info(f"[Embedded] 계획 생성: {request.request[:100]}...")

        imported_libs = request.notebookContext.importedLibraries
        detected_libraries = self._detect_required_libraries(
            request.request, imported_libs
        )
        logger.info(f"감지된 라이브러리: {detected_libraries}")

        # 가능한 경우 RAG 컨텍스트 가져오기
        rag_context = None
        try:
            from hdsp_agent_core.factory import get_service_factory

            rag_service = get_service_factory().get_rag_service()
            if rag_service.is_ready():
                rag_context = await rag_service.get_context_for_query(
                    query=request.request, detected_libraries=detected_libraries
                )
        except Exception as e:
            logger.warning(f"RAG 컨텍스트 조회 실패: {e}")

        # 프롬프트 구성
        prompt = format_plan_prompt(
            request=request.request,
            cell_count=request.notebookContext.cellCount,
            imported_libraries=imported_libs,
            defined_variables=request.notebookContext.definedVariables,
            recent_cells=request.notebookContext.recentCells,
            available_libraries=self._get_installed_packages(),
            detected_libraries=detected_libraries,
            rag_context=rag_context,
        )

        # LLM 호출
        response = await self._call_llm(prompt, request.llmConfig)
        logger.info(f"LLM 응답 길이: {len(response)}")

        # 응답 파싱
        plan_data = self._parse_json_response(response)

        if not plan_data or "plan" not in plan_data:
            raise ValueError(f"LLM 응답에서 계획 파싱 실패: {response[:200]}")

        # 정리 및 goal 보장
        plan_data = self._sanitize_tool_calls(plan_data)
        if "goal" not in plan_data["plan"]:
            plan_data["plan"]["goal"] = request.request

        return PlanResponse(
            plan=plan_data["plan"],
            reasoning=plan_data.get("reasoning", ""),
        )

    async def refine_code(self, request: RefineRequest) -> RefineResponse:
        """오류 발생 후 코드 개선"""
        logger.info(f"[Embedded] 코드 개선: 시도 {request.attempt}")

        # 이전 코드 추출
        previous_code = request.previousCode or ""
        if not previous_code and request.step.get("toolCalls"):
            for tc in request.step["toolCalls"]:
                if tc.get("tool") == "jupyter_cell":
                    previous_code = tc.get("parameters", {}).get("code", "")
                    break

        # 트레이스백 처리
        traceback_data = request.error.traceback or []
        traceback_str = (
            "\n".join(traceback_data)
            if isinstance(traceback_data, list)
            else str(traceback_data)
        )

        # 프롬프트 구성
        prompt = format_refine_prompt(
            original_code=previous_code,
            error_type=request.error.type,
            error_message=request.error.message,
            traceback=traceback_str,
            attempt=request.attempt,
            max_attempts=3,
            available_libraries=self._get_installed_packages(),
            defined_variables=[],
        )

        # LLM 호출
        response = await self._call_llm(prompt, request.llmConfig)

        # 응답 파싱
        refine_data = self._parse_json_response(response)

        if not refine_data or "toolCalls" not in refine_data:
            # 코드 직접 추출 시도
            code_match = re.search(r"```(?:python)?\s*([\s\S]*?)\s*```", response)
            if code_match:
                refine_data = {
                    "toolCalls": [
                        {
                            "tool": "jupyter_cell",
                            "parameters": {"code": code_match.group(1).strip()},
                        }
                    ],
                    "reasoning": "",
                }
            else:
                raise ValueError("개선된 코드 생성 실패")

        refine_data = self._sanitize_tool_calls(refine_data)

        return RefineResponse(
            toolCalls=refine_data["toolCalls"],
            reasoning=refine_data.get("reasoning", ""),
        )

    async def replan(self, request: ReplanRequest) -> ReplanResponse:
        """실패한 단계 처리 방법 결정"""
        logger.info(
            f"[Embedded] 단계 {request.currentStepIndex} 재계획 "
            f"(시도: {request.previousAttempts})"
        )

        # 결정론적 분류를 위해 오류 분류기 사용
        try:
            from hdsp_agent_core.managers.error_classifier import get_error_classifier

            classifier = get_error_classifier()
        except ImportError:
            # error_classifier가 아직 마이그레이션되지 않은 경우 폴백
            logger.warning("오류 분류기 사용 불가, 단순 휴리스틱 사용")
            return ReplanResponse(
                decision="refine",
                analysis={
                    "root_cause": "오류 발생",
                    "is_approach_problem": False,
                    "missing_prerequisites": [],
                },
                reasoning="오류 분류기 사용 불가",
                changes={},
                usedLlm=False,
                confidence=0.5,
            )

        traceback_data = request.error.traceback or []
        traceback_str = (
            "\n".join(traceback_data)
            if isinstance(traceback_data, list)
            else str(traceback_data)
        )

        analysis = classifier.classify(
            error_type=request.error.type,
            error_message=request.error.message,
            traceback=traceback_str,
        )

        return ReplanResponse(
            decision=analysis.decision.value,
            analysis=analysis.to_dict()["analysis"],
            reasoning=analysis.reasoning,
            changes=analysis.changes,
            usedLlm=analysis.used_llm,
            confidence=analysis.confidence,
        )

    async def validate_code(
        self, code: str, notebook_context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """실행 전 코드 검증"""
        logger.info(f"[Embedded] 코드 검증: {len(code)} 문자")

        try:
            from hdsp_agent_core.managers.code_validator import CodeValidator

            notebook_ctx = notebook_context or {}
            validator = CodeValidator(notebook_context=notebook_ctx)
            result = validator.full_validation(code)

            return {
                "valid": result.is_valid,
                "issues": [issue.to_dict() for issue in result.issues],
                "dependencies": result.dependencies.to_dict()
                if result.dependencies
                else None,
                "hasErrors": result.has_errors,
                "hasWarnings": result.has_warnings,
                "summary": result.summary,
            }
        except ImportError:
            # code_validator가 아직 마이그레이션되지 않은 경우 폴백
            logger.warning("코드 검증기 사용 불가")
            return {
                "valid": True,
                "issues": [],
                "dependencies": None,
                "hasErrors": False,
                "hasWarnings": False,
                "summary": "검증 건너뜀 (검증기 사용 불가)",
            }


class ProxyAgentService(IAgentService):
    """
    에이전트 서비스의 Proxy 구현.

    HTTP를 통해 외부 에이전트 서버로 요청을 전달합니다.
    프로덕션 모드(HDSP_AGENT_MODE=proxy)에서 사용됩니다.
    """

    def __init__(self, base_url: str, timeout: float = 120.0):
        """Proxy 에이전트 서비스 초기화"""
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        logger.info(f"ProxyAgentService 초기화됨 (서버: {self._base_url})")

    async def _request(
        self, method: str, path: str, data: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """에이전트 서버로 HTTP 요청"""
        url = f"{self._base_url}{path}"

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            if method == "POST":
                response = await client.post(url, json=data)
            elif method == "GET":
                response = await client.get(url)
            else:
                raise ValueError(f"지원되지 않는 메서드: {method}")

            response.raise_for_status()
            return response.json()

    async def generate_plan(self, request: PlanRequest) -> PlanResponse:
        """프록시를 통해 계획 생성"""
        logger.info(f"[Proxy] 계획 생성: {request.request[:100]}...")

        data = request.model_dump(mode="json")
        result = await self._request("POST", "/agent/plan", data)

        return PlanResponse(**result)

    async def refine_code(self, request: RefineRequest) -> RefineResponse:
        """프록시를 통해 코드 개선"""
        logger.info(f"[Proxy] 코드 개선: 시도 {request.attempt}")

        data = request.model_dump(mode="json")
        result = await self._request("POST", "/agent/refine", data)

        return RefineResponse(**result)

    async def replan(self, request: ReplanRequest) -> ReplanResponse:
        """프록시를 통해 재계획"""
        logger.info(f"[Proxy] 단계 {request.currentStepIndex} 재계획")

        data = request.model_dump(mode="json")
        result = await self._request("POST", "/agent/replan", data)

        return ReplanResponse(**result)

    async def validate_code(
        self, code: str, notebook_context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """프록시를 통해 코드 검증"""
        logger.info(f"[Proxy] 코드 검증: {len(code)} 문자")

        data = {
            "code": code,
            "notebookContext": notebook_context,
        }
        return await self._request("POST", "/agent/validate", data)
