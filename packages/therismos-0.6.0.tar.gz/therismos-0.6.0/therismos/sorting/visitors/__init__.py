"""
Visitors for sorting criteria.

This module provides visitor implementations for converting sorting criteria
to various formats (strings, dicts, MongoDB sort specs, Polars sort params,
Pandas sort params, etc.).

Backend-specific converters are available as separate modules:

- :mod:`mongo`: MongoDB sort document converter (requires pymongo or motor)
- :mod:`polars`: Polars PolarsSortSpec converter (requires polars)
- :mod:`pandas`: Pandas PandasSortSpec converter (requires pandas)
"""

from therismos.sorting.visitors._visitors import (
    DictVisitor,
    FieldGathererVisitor,
    StringVisitor,
)

__all__ = [
    "DictVisitor",
    "FieldGathererVisitor",
    "StringVisitor",
]
