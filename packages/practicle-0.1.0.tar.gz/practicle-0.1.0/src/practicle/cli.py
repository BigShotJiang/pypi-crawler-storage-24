import sys
import argparse
import os
from thefuzz import process
from .practicals import practicals

def main():
    parser = argparse.ArgumentParser(description="Practicle: The AI-Powered Lab Assistant")
    parser.add_argument("query", nargs="*", help="The practical question or snippet name")
    parser.add_argument("-t", "--to", help="Target file to write/append the code to")
    
    args = parser.parse_args()


    if not args.query:
        parser.print_help()
        return

    full_query = " ".join(args.query).lower()
    
    # Check Local Library with Fuzzy Matching
    all_names = practicals.list_all()
    # Find the best match
    match, score = process.extractOne(full_query, all_names)
    
    snippet_code = ""
    snippet_name = ""

    if score > 80:
        p = practicals.get(match)
        snippet_code = p.code
        snippet_name = p.name
        print(f"Matched local practical: {match} (Score: {score})")
    else:
        print("No exact match found in local library. Since AI fallback is disabled, please try a different query.")
        return

    # Display to screen
    print("\n--- CODE START ---")
    print(snippet_code)
    print("--- CODE END ---\n")

    # Save to file
    if args.to:
        filename = args.to
        with open(filename, 'a' if os.path.exists(filename) else 'w') as f:
            f.write(f"\n# --- {snippet_name} ---\n")
            f.write(snippet_code)
            f.write("\n")
        print(f"Successfully added to {filename}")
    else:
        # Default file creation if matching a local snippet
        if score > 80:
            default_file = f"{match}.py"
            with open(default_file, 'w') as f:
                f.write(snippet_code)
            print(f"Created {default_file}")

if __name__ == "__main__":
    main()
