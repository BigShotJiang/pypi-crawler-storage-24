import os

class Practical:
    def __init__(self, name, code):
        self.name = name
        self.code = code

    def __str__(self):
        return self.code

    def to(self, filename):
        """Amends the target file with the snippet code."""
        with open(filename, 'a' if os.path.exists(filename) else 'w') as f:
            f.write(f"\n# --- {self.name} ---\n")
            f.write(self.code)
            f.write("\n")
        print(f"Added {self.name} to {filename}")

class PracticalsLibrary:
    def __init__(self):
        self._snippets = {}

    def _register(self, name, code):
        p = Practical(name, code)
        self._snippets[name] = p
        setattr(self, name, p)

    def get(self, name):
        return self._snippets.get(name)

    def list_all(self):
        return list(self._snippets.keys())

practicals = PracticalsLibrary()
