from .practicals import practicals
from . import snippets

__all__ = ["practicals"]
