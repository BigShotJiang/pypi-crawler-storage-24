from ..practicals import practicals

SNIPPETS = {
    # --- Basic ---
    "hello_msbte": 'print("MSBTE")',
    "arithmetic_ops": """a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
print(f"Add: {a+b}, Sub: {a-b}, Mul: {a*b}, Div: {a/b if b != 0 else 'Undefined'}")""",
    "swap_numbers": """a = input("Enter a: ")
b = input("Enter b: ")
a, b = b, a
print(f"After swap: a={a}, b={b}")""",
    "check_sign": """n = float(input("Enter a number: "))
if n > 0:
    print("Positive")
elif n < 0:
    print("Negative")
else:
    print("Zero")""",
    "odd_even": """n = int(input("Enter a number: "))
if n % 2 == 0:
    print("Even")
else:
    print("Odd")""",
    "leap_year": """year = int(input("Enter a year: "))
if (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0):
    print(f"{year} is a Leap Year")
else:
    print(f"{year} is not a Leap Year")""",
    
    # --- Math ---
    "factorial": """def factorial(n):
    return 1 if n == 0 or n == 1 else n * factorial(n-1)

num = int(input("Enter a number: "))
print(f"Factorial of {num} is {factorial(num)}")""",
    "fibonacci": """n_terms = int(input("How many terms? "))
n1, n2 = 0, 1
if n_terms <= 0:
    print("Please enter a positive integer")
elif n_terms == 1:
    print(n1)
else:
    for _ in range(n_terms):
        print(n1)
        n1, n2 = n2, n1 + n2""",
    "prime_check": """num = int(input("Enter a number: "))
if num > 1:
    for i in range(2, int(num**0.5) + 1):
        if (num % i) == 0:
            print(f"{num} is not a prime number")
            break
    else:
        print(f"{num} is a prime number")
else:
    print(f"{num} is not a prime number")""",
    "primes_in_range": """start = int(input("Enter lower bound: "))
end = int(input("Enter upper bound: "))
for num in range(start, end + 1):
    if num > 1:
        for i in range(2, int(num**0.5) + 1):
            if (num % i) == 0:
                break
        else:
            print(num)""",
    "armstrong_number": """num = int(input("Enter a number: "))
sum = 0
temp = num
while temp > 0:
    digit = temp % 10
    sum += digit ** len(str(num))
    temp //= 10
if num == sum:
    print("Armstrong number")
else:
    print("Not an Armstrong number")""",
    "reverse_number": """num = int(input("Enter a number: "))
reversed_num = 0
while num != 0:
    digit = num % 10
    reversed_num = reversed_num * 10 + digit
    num //= 10
print(f"Reversed Number: {reversed_num}")""",
    "gcd_lcm": """import math
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
gcd = math.gcd(a, b)
lcm = abs(a*b) // gcd
print(f"GCD is {gcd}")
print(f"LCM is {lcm}")""",
    "sum_digits": """num = int(input("Enter a number: "))
tot = sum(int(digit) for digit in str(num))
print(f"Sum of digits: {tot}")""",
    
    # --- Strings ---
    "palindrome": """def is_palindrome(s):
    s = s.lower().replace(" ", "")
    return s == s[::-1]

string = input("Enter a string: ")
if is_palindrome(string):
    print("It is a Palindrome")
else:
    print("It is not a Palindrome")""",
    "palindrome_string": """def is_palindrome(s):
    s = s.lower().replace(" ", "")
    return s == s[::-1]

string = input("Enter a string: ")
if is_palindrome(string):
    print("It is a Palindrome")
else:
    print("It is not a Palindrome")""",
    "vowel_count": """string = input("Enter string: ").lower()
vowels = "aeiou"
count = sum(1 for char in string if char in vowels)
print(f"Number of vowels: {count}")""",
    "reverse_string": """string = input("Enter a string: ")
print(f"Reversed: {string[::-1]}")""",
    "anagram_check": """str1 = input("String 1: ").lower().replace(" ", "")
str2 = input("String 2: ").lower().replace(" ", "")
if sorted(str1) == sorted(str2):
    print("Anagrams")
else:
    print("Not Anagrams")""",
    "word_sort": """my_str = input("Enter a string: ")
words = [word.lower() for word in my_str.split()]
words.sort()
print("The sorted words are:")
for word in words:
    print(word)""",

    # --- Lists/Arrays ---
    "list_sum_avg": """nums = [1, 2, 3, 4, 5]
total = sum(nums)
avg = total / len(nums)
print(f"Sum: {total}, Average: {avg}")""",
    "find_max_min": """nums = [5, 2, 9, 1, 7]
print(f"Max: {max(nums)}, Min: {min(nums)}")""",
    "linear_search": """def linear_search(arr, x):
    for i in range(len(arr)):
        if arr[i] == x:
            return i
    return -1

arr = [2, 3, 4, 10, 40]
x = 10
result = linear_search(arr, x)
print(f"Element at index {result}" if result != -1 else "Element not present")""",
    "binary_search": """def binary_search(arr, l, r, x):
    while l <= r:
        mid = l + (r - l) // 2
        if arr[mid] == x: return mid
        elif arr[mid] < x: l = mid + 1
        else: r = mid - 1
    return -1

arr = [2, 3, 4, 10, 40]
x = 10
result = binary_search(arr, 0, len(arr)-1, x)
print(f"Element at index {result}" if result != -1 else "Element not present")""",
    "remove_duplicates": """my_list = [1, 2, 2, 3, 4, 4, 5]
unique_list = list(set(my_list))
print(f"List after removing duplicates: {unique_list}")""",
    "common_items": """list1 = [1, 2, 3, 4, 5]
list2 = [4, 5, 6, 7, 8]
common = list(set(list1).intersection(list2))
print("Common items:", common)""",

    # --- Dictionaries & Sets ---
    "sort_dict_value": """d = {'apple': 10, 'orange': 20, 'banana': 5, 'mango': 15}
sorted_d = dict(sorted(d.items(), key=lambda item: item[1]))
print("Sorted dictionary by value:", sorted_d)""",
    "merge_dicts": """dict1 = {'a': 10, 'b': 8}
dict2 = {'d': 6, 'c': 4}
dict1.update(dict2)
print("Merged dictionary:", dict1)""",
    "set_intersection": """set1 = {1, 2, 3, 4, 5}
set2 = {4, 5, 6, 7, 8}
intersection = set1.intersection(set2)
print("Intersection:", intersection)""",
    "set_union": """set1 = {1, 2, 3, 4, 5}
set2 = {4, 5, 6, 7, 8}
union = set1.union(set2)
print("Union:", union)""",
    "frequency_count": """my_list = [1, 1, 1, 5, 5, 3, 1, 3, 3, 1, 4, 4, 4, 2, 2, 2, 2]
freq = {}
for item in my_list:
    freq[item] = freq.get(item, 0) + 1
print("Frequency count:", freq)""",

    # --- Matrices ---
    "matrix_add": """X = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
Y = [[9, 8, 7], [6, 5, 4], [3, 2, 1]]
result = [[X[i][j] + Y[i][j] for j in range(len(X[0]))] for i in range(len(X))]
for r in result:
    print(r)""",
    "matrix_mul": """X = [[12, 7, 3], [4, 5, 6], [7, 8, 9]]
Y = [[5, 8, 1, 2], [6, 7, 3, 0], [4, 5, 9, 1]]
result = [[sum(a * b for a, b in zip(X_row, Y_col)) for Y_col in zip(*Y)] for X_row in X]
for r in result:
    print(r)""",
    "matrix_transpose": """X = [[12, 7], [4, 5], [3, 8]]
result = [[X[j][i] for j in range(len(X))] for i in range(len(X[0]))]
for r in result:
    print(r)""",

    # --- Algorithms ---
    "bubble_sort": """def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return arr

nums = [64, 34, 25, 12, 22, 11, 90]
print("Sorted array:", bubble_sort(nums))""",
    "selection_sort": """def selection_sort(arr):
    for i in range(len(arr)):
        min_idx = i
        for j in range(i+1, len(arr)):
            if arr[min_idx] > arr[j]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
    return arr

nums = [64, 25, 12, 22, 11]
print("Sorted array:", selection_sort(nums))""",
    "insertion_sort": """def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i-1
        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return arr

nums = [12, 11, 13, 5, 6]
print("Sorted array:", insertion_sort(nums))""",

    # --- File I/O ---
    "read_file": """with open('test.txt', 'r') as file:
    content = file.read()
    print(content)""",
    "write_file": """with open('test.txt', 'w') as file:
    file.write("Hello World!\nThis is a file write operation.")
print("File written successfully")""",
    "copy_file": """with open('source.txt', 'r') as src, open('dest.txt', 'w') as dst:
    dst.write(src.read())
print("File copied successfully")""",
    "file_stats": """import os
stats = os.stat('test.txt')
print(f"Size: {stats.st_size} bytes")""",

    # --- Misc/Logic ---
    "while_to_for": """# Original while loop
# x = 100
# while x > 5:
#     print(x)
#     x -= 1

# Converted to for loop
for x in range(100, 5, -1):
    print(x)""",
    "simple_class": """class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    def greet(self):
        print(f"Hello, my name is {self.name} and I am {self.age} years old.")

p = Person("John", 30)
p.greet()""",
    "func_calculator": """def add(x, y): return x + y
def subtract(x, y): return x - y
def multiply(x, y): return x * y
def divide(x, y): return x / y if y != 0 else "Cannot divide by zero"

print(f"10 + 5 = {add(10, 5)}")"""
}

def register_all():
    for name, code in SNIPPETS.items():
        practicals._register(name, code)
