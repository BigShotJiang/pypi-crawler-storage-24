from .algorithms import register_all

register_all()
