# Practicle: The AI-Powered Lab Assistant

A Python library and CLI tool for instant access to common lab practicals and AI-generated code snippets.

## Features
- **Smart CLI**: Ask natural language questions like `practicle "how to write a palindrome"`
- **Vast Library**: Includes common undergraduate lab practicals (Sorts, Matrix, Math, etc.)
- **AI Fallback**: Uses Gemini AI to answer *any* programming question if not in the library.
- **Auto-Amending**: Easily append code to your existing files with `--to`.

## Installation
```bash
pip install .
```

## Quick Start
```bash
# Print palindrome and create palindrome.py
practicle palindrome

# Append leap year check to lab1.py
practicle "check leap year" --to lab1.py

# Ask AI anything
practicle "how to integrate a database in flask" --to app.py
```
