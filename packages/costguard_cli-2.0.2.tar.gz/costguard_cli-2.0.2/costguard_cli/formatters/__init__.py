"""CostGuard output formatters."""

from costguard_cli.formatters.terminal import TerminalFormatter
from costguard_cli.formatters.markdown import MarkdownFormatter
from costguard_cli.formatters.json_report import JsonFormatter
from costguard_cli.formatters.html_report import HtmlFormatter

FORMATTERS = {
    "terminal": TerminalFormatter,
    "markdown": MarkdownFormatter,
    "json": JsonFormatter,
    "html": HtmlFormatter,
}

__all__ = ["FORMATTERS", "TerminalFormatter", "MarkdownFormatter", "JsonFormatter", "HtmlFormatter"]
