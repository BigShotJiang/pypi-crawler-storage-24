"""JSON formatter — machine-readable passthrough for CostGuard results."""

import json


class JsonFormatter:
    """Renders CostGuard API responses as pretty-printed JSON."""

    def format(self, response: dict) -> str:
        """Return the full API response as formatted JSON.

        Output uses 2-space indentation and sorted keys for
        consistent, diff-friendly machine-readable output.
        """
        return json.dumps(response, indent=2, sort_keys=True, default=str)
