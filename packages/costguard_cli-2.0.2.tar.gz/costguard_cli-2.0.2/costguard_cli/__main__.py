"""Allow running CostGuard CLI via `python -m costguard_cli`."""

from costguard_cli.validate import main

main()
