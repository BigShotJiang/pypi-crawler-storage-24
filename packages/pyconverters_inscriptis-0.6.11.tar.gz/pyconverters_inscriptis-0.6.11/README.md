## Requirements

- Python 3.12+
- uv as the package manager
- Pydantic v2 for the data parts.

## Installation
```
pip install pyconverters-inscriptis
```

## Publish the Python Package to PyPI
- Increment the version of your package in the `src/pyconverters_inscriptis/__init__.py` file:
```python
"""Sherpa HTML inscriptis converter"""

__version__ = 'x.y.z'
```
- Build and publish
```
uv build
uv publish
```

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
