import typer
from typing_extensions import Annotated

app = typer.Typer()


@app.callback()
def callback():
    """
    Awesome Portal Gun
    """


@app.command()
def shoot():
    """
    Shoot the portal gun
    """
    typer.echo("Shooting portal gun")


@app.command()
def load():
    """
    Load the portal gun
    """
    typer.echo("Loading portal gun")

@app.command()
def hello(name: Annotated[str | None, typer.Option("--name", "-n")] = None):
    """
    Say hello to someone
    """
    if name:
        typer.echo(f"Hello, {name}!")
    else:
        typer.echo("Hello!")

if __name__ == "__main__":
    app()