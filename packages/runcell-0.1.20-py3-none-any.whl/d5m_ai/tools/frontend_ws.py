"""
Frontend-interactive tools executed via the local-only WebSocket bridge.

These tools are used by the HTTP/SSE agent v2 loop. They send a request to the
frontend through the proxy WebSocket handler and wait for the corresponding
`*_result` message.
"""

from __future__ import annotations

from typing import Any, Dict

from d5m_ai.agent.config import handler_registry
from d5m_ai.agent.tools.frontend.helpers import (
    send_and_wait,
)
from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds


def _get_handler(args: Dict[str, Any]):
    connection_id = args.get("connection_id")
    if not connection_id:
        raise RuntimeError(
            "Local notebook bridge is disconnected (missing connection_id). "
            "Refresh JupyterLab or reopen a notebook tab, then retry."
        )
    handler = handler_registry.get(connection_id)
    if not handler:
        raise RuntimeError(
            "Local notebook bridge is disconnected "
            f"(stale connection_id: {connection_id}). "
            "Refresh JupyterLab or reopen a notebook tab, then retry."
        )
    return handler


async def execute_edit_cell_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("edit_cell")
    return await send_and_wait(
        handler,
        "edit_cell",
        {
            "cell_index": args.get("cell_index"),
            "code": args.get("code"),
            "file_path": args.get("file_path"),
            "rerun": args.get("rerun", False),
        },
        timeout=timeout,
        error_message="Error: edit_cell timed out waiting for the frontend.",
    )


async def execute_edit_markdown_cell_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("edit_markdown_cell")
    return await send_and_wait(
        handler,
        "edit_markdown_cell",
        {
            "cell_index": args.get("cell_index"),
            "content": args.get("content"),
            "file_path": args.get("file_path"),
            "render": args.get("render", True),
        },
        timeout=timeout,
        error_message="Error: edit_markdown_cell timed out waiting for the frontend.",
    )


async def execute_insert_markdown_cell_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("insert_markdown_cell")
    return await send_and_wait(
        handler,
        "insert_markdown_cell",
        {
            "content": args.get("content"),
            "file_path": args.get("file_path"),
            "insert_position": args.get("insert_position"),
            "render": args.get("render", True),
        },
        timeout=timeout,
        error_message="Error: insert_markdown_cell timed out waiting for the frontend.",
    )


async def execute_insert_cell_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("insert_cell")
    return await send_and_wait(
        handler,
        "insert_cell",
        {
            "code": args.get("code"),
            "file_path": args.get("file_path"),
            "insert_position": args.get("insert_position"),
        },
        timeout=timeout,
        error_message="Error: insert_cell timed out waiting for the frontend.",
    )


async def execute_run_cell_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("run_cell")
    return await send_and_wait(
        handler,
        "run_cell",
        {
            "file_path": args.get("file_path"),
            "cell_index": args.get("cell_index"),
        },
        timeout=timeout,
        error_message="Error: run_cell timed out waiting for the frontend.",
    )


async def execute_delete_cell_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("delete_cell")
    return await send_and_wait(
        handler,
        "delete_cell",
        {
            "file_path": args.get("file_path"),
            "cell_index": args.get("cell_index"),
        },
        timeout=timeout,
        error_message="Error: delete_cell timed out waiting for the frontend.",
    )


async def execute_open_tab_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("open_tab")
    return await send_and_wait(
        handler,
        "open_tab",
        {
            "file_path": args.get("file_path"),
        },
        timeout=timeout,
        error_message="Error: open_tab timed out waiting for the frontend.",
    )


async def execute_read_notebook_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("read_notebook")
    return await send_and_wait(
        handler,
        "read_notebook",
        {
            "file_path": args.get("file_path"),
            "start_cell_index": args.get("start_cell_index"),
            "end_cell_index": args.get("end_cell_index"),
        },
        timeout=timeout,
        error_message="Error: read_notebook timed out waiting for the frontend.",
    )


async def execute_run_long_terminal_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("run_long_terminal")
    return await send_and_wait(
        handler,
        "run_long_terminal",
        {
            "command": args.get("command"),
            "error_detection_window_ms": args.get("error_detection_window_ms"),
        },
        timeout=timeout,
        error_message="Error: run_long_terminal timed out waiting for the frontend.",
    )


async def execute_rerun_all_cells_tool(args: Dict[str, Any]) -> str:
    handler = _get_handler(args)
    timeout = get_tool_timeout_seconds("rerun_all_cells")
    return await send_and_wait(
        handler,
        "rerun_all_cells",
        {
            "file_path": args.get("file_path"),
        },
        timeout=timeout,
        error_message="Error: rerun_all_cells timed out waiting for the frontend.",
    )
