"""Notebook reader with frontend-first execution and direct .ipynb fallback."""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any, Dict

from d5m_ai.tools.frontend_ws import execute_read_notebook_tool as execute_frontend_read_notebook_tool
from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds

DEFAULT_NOTEBOOK_CELL_WINDOW = 20
DEFAULT_MAX_TEXT_LENGTH = 1000
IMAGE_PLACEHOLDER_MIN_LENGTH = 100
NOTEBOOK_TOOL_ERROR_PREFIX = "[NOTEBOOK_TOOL_ERROR]"


def _stringify_source(value: Any) -> str:
    if isinstance(value, list):
        return "".join(str(item) for item in value)
    return str(value or "")


def _coerce_non_negative_int(value: Any, default: int) -> int:
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return default
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return max(0, parsed)


def _truncate_text(text: str, max_text_length: int) -> str:
    if len(text) <= max_text_length:
        return text
    half = max_text_length // 2
    hidden = len(text) - (half * 2)
    return (
        f"{text[:half]}\n"
        f"... [TRUNCATED: {hidden} characters hidden] ...\n"
        f"{text[-half:]}"
    )


def _compress_output_data_bundle(
    data: dict[str, Any],
    max_text_length: int,
) -> dict[str, Any]:
    compressed: dict[str, Any] = {}
    for mime_type, content in data.items():
        if mime_type.startswith("image/"):
            if isinstance(content, str) and len(content) > IMAGE_PLACEHOLDER_MIN_LENGTH:
                compressed[mime_type] = (
                    f"[IMAGE_PLACEHOLDER: {mime_type}, ~{round(len(content) / 1024)}KB]"
                )
            else:
                compressed[mime_type] = content
            continue

        if mime_type in {"text/plain", "text/html"}:
            text_value = _stringify_source(content)
            compressed[mime_type] = _truncate_text(text_value, max_text_length)
            continue

        if mime_type == "application/json":
            try:
                serialized = json.dumps(content)
            except (TypeError, ValueError):
                serialized = _stringify_source(content)

            if len(serialized) > max_text_length:
                if isinstance(content, dict):
                    compressed[mime_type] = (
                        f"[JSON_PLACEHOLDER: {len(content.keys())} keys, "
                        f"~{round(len(serialized) / 1024)}KB]"
                    )
                else:
                    compressed[mime_type] = _truncate_text(serialized, max_text_length)
            else:
                compressed[mime_type] = content
            continue

        if isinstance(content, str) and len(content) > max_text_length:
            compressed[mime_type] = (
                f"[DATA_PLACEHOLDER: {mime_type}, ~{round(len(content) / 1024)}KB]"
            )
            continue

        compressed[mime_type] = content

    return compressed


def _compress_cell_outputs(outputs: list[Any], max_text_length: int) -> list[dict[str, Any]]:
    compressed_outputs: list[dict[str, Any]] = []

    for output in outputs:
        if not isinstance(output, dict):
            continue

        output_type = output.get("output_type")
        if output_type in {"execute_result", "display_data"}:
            data = output.get("data")
            compressed_outputs.append(
                {
                    "type": output_type,
                    "data": _compress_output_data_bundle(
                        data if isinstance(data, dict) else {},
                        max_text_length,
                    ),
                }
            )
            continue

        if output_type == "stream":
            stream_text = _stringify_source(output.get("text"))
            compressed_outputs.append(
                {
                    "type": "stream",
                    "name": output.get("name"),
                    "text": _truncate_text(stream_text, max_text_length),
                }
            )
            continue

        if output_type == "error":
            traceback = output.get("traceback")
            traceback_lines = (
                [str(item) for item in traceback]
                if isinstance(traceback, list)
                else [str(traceback or "")]
            )
            if len("\n".join(traceback_lines)) > max_text_length and len(traceback_lines) > 6:
                traceback_lines = (
                    traceback_lines[:3]
                    + [
                        f"... [TRUNCATED: {len(traceback_lines) - 6} traceback lines hidden] ..."
                    ]
                    + traceback_lines[-3:]
                )
            compressed_outputs.append(
                {
                    "type": "error",
                    "ename": output.get("ename"),
                    "evalue": output.get("evalue"),
                    "traceback": traceback_lines,
                }
            )
            continue

        compressed_outputs.append({"type": str(output_type or "unknown")})

    return compressed_outputs


def _stringify_output_value(value: Any) -> str:
    if isinstance(value, list):
        return "".join(str(item) for item in value)
    return str(value or "")


def _format_cell_result_for_llm(result: list[dict[str, Any]] | None) -> str:
    if not result:
        return ""

    formatted_outputs: list[str] = []
    image_count = 0

    for output in result:
        output_type = output.get("type", "unknown")

        if output_type in {"execute_result", "display_data"}:
            data = output.get("data")
            data = data if isinstance(data, dict) else {}
            image_types = [key for key in data.keys() if key.startswith("image/")]
            if image_types:
                image_count += 1
                formatted_outputs.append(f"[Image output: {', '.join(image_types)}]")
                continue

            if "text/plain" in data:
                formatted_outputs.append(_stringify_output_value(data["text/plain"]))
                continue

            filtered_data = {
                key: value for key, value in data.items() if not key.startswith("image/")
            }
            if filtered_data:
                formatted_outputs.append(json.dumps(filtered_data))
            continue

        if output_type == "stream":
            formatted_outputs.append(str(output.get("text") or ""))
            continue

        if output_type == "error":
            ename = str(output.get("ename") or "Error")
            evalue = str(output.get("evalue") or "")
            traceback = output.get("traceback")
            traceback_text = (
                "\n".join(str(item) for item in traceback)
                if isinstance(traceback, list)
                else str(traceback or "")
            )
            formatted_outputs.append(f"{ename}: {evalue}\n{traceback_text}")
            continue

        formatted_outputs.append(str(output))

    result_text = "\n".join(item for item in formatted_outputs if item)
    if image_count > 0:
        result_text += (
            f"\n\n[Note: {image_count} image output(s) filtered for long base64 encoded data.]"
        )
    return result_text


def _format_notebook_context_for_llm(cells: list[dict[str, Any]]) -> str:
    formatted_cells: list[str] = []
    for cell in cells:
        cell_index = int(cell.get("index", 0))
        cell_type = str(cell.get("type") or "code")
        cell_content = str(cell.get("content") or "")
        cell_result = cell.get("result")

        if cell_type == "code":
            formatted = f"Cell {cell_index} (Code):\n```python\n{cell_content}\n```"
            if cell_result:
                formatted += (
                    f"\nCell {cell_index} Output:\n```\n"
                    f"{_format_cell_result_for_llm(cell_result)}\n```"
                )
            formatted_cells.append(formatted)
            continue

        if cell_type == "markdown":
            formatted_cells.append(
                f"Cell {cell_index} (Markdown):\n```markdown\n{cell_content}\n```"
            )
            continue

        formatted_cells.append(f"Cell {cell_index} ({cell_type}):\n{cell_content}")

    return "\n\n".join(formatted_cells)


def _read_notebook_from_file_sync(args: Dict[str, Any]) -> str:
    file_path = args.get("_local_file_path") or args.get("file_path")
    display_path = args.get("file_path") or file_path
    if not isinstance(file_path, str) or not file_path.strip():
        return (
            "Error reading notebook: file_path is required for direct notebook fallback. "
            "Provide file_path or ensure a frontend-connected notebook is available."
        )

    normalized_file_path = file_path.strip()
    if not normalized_file_path.lower().endswith(".ipynb"):
        return f"Error reading notebook: Notebook file must end with .ipynb: {display_path}"
    if not os.path.exists(normalized_file_path):
        return f"Error reading notebook: Notebook file does not exist: {display_path}"
    if not os.path.isfile(normalized_file_path):
        return f"Error reading notebook: Notebook path is not a file: {display_path}"

    try:
        with open(normalized_file_path, "r", encoding="utf-8") as fh:
            notebook = json.load(fh)
    except json.JSONDecodeError as exc:
        return f"Error reading notebook: Notebook file is not valid JSON: {display_path} ({exc})"
    except Exception as exc:
        return f"Error reading notebook: Failed to open notebook {display_path}: {exc}"

    cells = notebook.get("cells")
    if not isinstance(cells, list):
        return "Error reading notebook: Notebook JSON is missing a valid 'cells' array"

    total_cells = len(cells)
    start_cell_index = _coerce_non_negative_int(args.get("start_cell_index"), 0)
    end_cell_index = _coerce_non_negative_int(
        args.get("end_cell_index"),
        start_cell_index + DEFAULT_NOTEBOOK_CELL_WINDOW - 1,
    )
    end_cell_index = max(start_cell_index, end_cell_index)

    if total_cells == 0 or start_cell_index >= total_cells:
        return (
            "Notebook context (cells and outputs):\n"
            f"Notebook: {display_path}\n"
            f"Cells {start_cell_index}-{end_cell_index} (inclusive) of {max(total_cells - 1, 0)} total indices\n"
            "No cells found in the requested range.\n"
        )

    actual_end = min(end_cell_index, total_cells - 1)
    selected_cells: list[dict[str, Any]] = []
    for index in range(start_cell_index, actual_end + 1):
        cell = cells[index]
        if not isinstance(cell, dict):
            continue
        cell_type = str(cell.get("cell_type") or "code")
        formatted_cell: dict[str, Any] = {
            "index": index,
            "type": cell_type,
            "content": _stringify_source(cell.get("source")),
        }
        if cell_type == "code":
            outputs = cell.get("outputs")
            if isinstance(outputs, list) and outputs:
                formatted_cell["result"] = _compress_cell_outputs(
                    outputs,
                    DEFAULT_MAX_TEXT_LENGTH,
                )
        selected_cells.append(formatted_cell)

    formatted_notebook = _format_notebook_context_for_llm(selected_cells)
    body = formatted_notebook or "No cells found in the requested range."
    return (
        "Notebook context (cells and outputs):\n"
        f"Notebook: {display_path}\n"
        f"Cells {start_cell_index}-{actual_end} (inclusive) of {max(total_cells - 1, 0)} total indices\n"
        f"{body}\n"
    )


def _should_fallback_to_direct_read(frontend_result: str) -> bool:
    if not isinstance(frontend_result, str):
        return False
    normalized = frontend_result.strip()
    if not normalized:
        return False
    lowered = normalized.lower()
    if lowered.startswith("error"):
        return True
    if normalized.startswith(NOTEBOOK_TOOL_ERROR_PREFIX):
        return True
    return False


async def _execute_read_notebook_with_fallback(
    args: Dict[str, Any],
    timeout_seconds: float | None,
) -> str:
    frontend_error: str | None = None
    connection_id = args.get("connection_id")

    if connection_id:
        try:
            frontend_result = await execute_frontend_read_notebook_tool(args)
            if not _should_fallback_to_direct_read(frontend_result):
                return frontend_result
            frontend_error = frontend_result
        except Exception as exc:
            frontend_error = f"Error reading notebook via frontend: {exc}"
            logging.info("[READ-NOTEBOOK] Frontend read failed, falling back to file read: %s", exc)

    local_file_path = args.get("_local_file_path") or args.get("file_path")
    if not local_file_path:
        return frontend_error or (
            "Error reading notebook: no frontend connection is available and file_path "
            "was not provided for direct notebook fallback."
        )

    direct_task = asyncio.to_thread(_read_notebook_from_file_sync, args)
    if timeout_seconds is None:
        direct_result = await direct_task
    else:
        try:
            direct_result = await asyncio.wait_for(direct_task, timeout=timeout_seconds)
        except asyncio.TimeoutError:
            return f"Error: read_notebook timed out after {timeout_seconds:g} seconds"
    return direct_result


async def execute_read_notebook_tool(args: Dict[str, Any]) -> str:
    timeout_seconds = get_tool_timeout_seconds("read_notebook")
    return await _execute_read_notebook_with_fallback(args, timeout_seconds)
