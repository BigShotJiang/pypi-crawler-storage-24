"""Proxy-local interpret_image tool for agent v2."""

from __future__ import annotations

import asyncio
import base64
import binascii
import json
import mimetypes
import os
import re
import ssl
import uuid
from dataclasses import dataclass
from typing import Any, Tuple
from urllib.parse import urlparse

import aiohttp
import certifi

from d5m_ai.agent.config import handler_registry
from d5m_ai.image.utils import IMAGE_MEDIA_TYPE_TO_EXTENSION
from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds
from d5m_ai.utils import build_remote_backend_url

MAX_INTERPRET_IMAGE_BYTES = 10 * 1024 * 1024
DEFAULT_MEDIA_TYPE = "image/png"
MAX_STAGED_VISUAL_REFS = 256
OMITTED_TEXT_TOKENS = frozenset({"__omit__", "[content omitted]"})
NOTEBOOK_IMAGE_MIME_TYPES = (
    "image/png",
    "image/jpeg",
    "image/gif",
    "image/webp",
    "image/svg+xml",
)


@dataclass(frozen=True)
class ResolvedImageSource:
    image_url: str
    visual_ref: str = ""
    media_type: str = DEFAULT_MEDIA_TYPE
    image_base64: str = ""


def _normalize_media_type(media_type: Any) -> str:
    if not isinstance(media_type, str):
        return DEFAULT_MEDIA_TYPE
    normalized = media_type.split(";")[0].strip().lower()
    if "/" not in normalized or not normalized.startswith("image/"):
        return DEFAULT_MEDIA_TYPE
    return normalized


def _extract_data_url_parts(data_url: str) -> Tuple[str, str | None]:
    if not data_url.startswith("data:"):
        return DEFAULT_MEDIA_TYPE, None
    header, sep, payload = data_url.partition(",")
    if not sep or not payload:
        return DEFAULT_MEDIA_TYPE, None
    media_type = header.replace("data:", "").split(";")[0]
    return _normalize_media_type(media_type), payload


def _decode_base64_payload(payload: str) -> bytes:
    normalized_payload = re.sub(r"\s+", "", payload or "")
    try:
        return base64.b64decode(normalized_payload, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("Invalid base64 image payload") from exc


def _validate_image_size(image_bytes: bytes) -> None:
    if len(image_bytes) > MAX_INTERPRET_IMAGE_BYTES:
        raise ValueError(
            f"Image too large: decoded payload exceeds {MAX_INTERPRET_IMAGE_BYTES} bytes"
        )


def _coerce_non_negative_index(value: Any, field_name: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be a non-negative integer")
    try:
        normalized = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be a non-negative integer") from exc
    if normalized < 0:
        raise ValueError(f"{field_name} must be a non-negative integer")
    return normalized


def _normalize_optional_text(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    normalized = value.strip()
    if not normalized:
        return ""
    if normalized.lower() in OMITTED_TEXT_TOKENS:
        return ""
    return normalized


def _normalize_optional_index(value: Any) -> Any | None:
    if value is None:
        return None
    if isinstance(value, str):
        normalized = value.strip()
        if not normalized or normalized.lower() in OMITTED_TEXT_TOKENS:
            return None
        return normalized
    return value


def _normalize_local_path(value: Any, field_name: str) -> str:
    normalized = _normalize_optional_text(value)
    if not normalized:
        raise ValueError(f"{field_name} is required")
    return normalized


def _join_output_value(value: Any) -> str:
    if isinstance(value, list):
        return "".join(str(item) for item in value)
    if isinstance(value, str):
        return value
    raise ValueError("Notebook output image payload must be a string")


def _detect_media_type_from_path(file_path: str) -> str:
    guessed, _ = mimetypes.guess_type(file_path)
    if isinstance(guessed, str):
        normalized = guessed.split(";")[0].strip().lower()
        if normalized in IMAGE_MEDIA_TYPE_TO_EXTENSION:
            return normalized

    extension = os.path.splitext(file_path)[1].lower()
    if extension in {".jpg", ".jpeg"}:
        return "image/jpeg"
    if extension in {".png", ".gif", ".webp", ".svg"}:
        return {
            ".png": "image/png",
            ".gif": "image/gif",
            ".webp": "image/webp",
            ".svg": "image/svg+xml",
        }[extension]

    raise ValueError(
        "Unsupported local image type. Supported extensions are png, jpg, jpeg, gif, webp, and svg."
    )


def _read_local_image_file(image_path: str) -> tuple[bytes, str]:
    if not os.path.exists(image_path):
        raise ValueError(f"Image file does not exist: {image_path}")
    if os.path.isdir(image_path):
        raise ValueError(f"Image path points to a directory, not a file: {image_path}")
    if not os.path.isfile(image_path):
        raise ValueError(f"Image path is not a file: {image_path}")

    media_type = _detect_media_type_from_path(image_path)
    with open(image_path, "rb") as fh:
        image_bytes = fh.read()

    if not image_bytes:
        raise ValueError(f"Image file is empty: {image_path}")
    _validate_image_size(image_bytes)
    return image_bytes, media_type


def _extract_notebook_output_image(file_path: str, cell_index: int, output_index: int) -> tuple[bytes, str]:
    if not file_path.lower().endswith(".ipynb"):
        raise ValueError(f"Notebook file must end with .ipynb: {file_path}")
    if not os.path.exists(file_path):
        raise ValueError(f"Notebook file does not exist: {file_path}")
    if not os.path.isfile(file_path):
        raise ValueError(f"Notebook path is not a file: {file_path}")

    try:
        with open(file_path, "r", encoding="utf-8") as fh:
            notebook = json.load(fh)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Notebook file is not valid JSON: {file_path}") from exc

    cells = notebook.get("cells")
    if not isinstance(cells, list):
        raise ValueError("Notebook JSON is missing a valid 'cells' array")
    if cell_index >= len(cells):
        raise ValueError(f"cell_index {cell_index} is out of range for notebook {file_path}")

    cell = cells[cell_index]
    outputs = cell.get("outputs")
    if not isinstance(outputs, list):
        raise ValueError(
            f"Cell {cell_index} does not contain outputs in notebook {file_path}"
        )
    if output_index >= len(outputs):
        raise ValueError(
            f"output_index {output_index} is out of range for cell {cell_index} in notebook {file_path}"
        )

    output = outputs[output_index]
    output_type = output.get("output_type")
    if output_type not in {"display_data", "execute_result"}:
        raise ValueError(
            f"Notebook output {cell_index}:{output_index} is not a display_data/execute_result output"
        )

    data = output.get("data")
    if not isinstance(data, dict):
        raise ValueError(
            f"Notebook output {cell_index}:{output_index} does not contain a valid data bundle"
        )

    for media_type in NOTEBOOK_IMAGE_MIME_TYPES:
        value = data.get(media_type)
        if value is None:
            continue

        payload = _join_output_value(value).strip()
        if not payload:
            continue

        if media_type == "image/svg+xml":
            if payload.startswith("data:"):
                parsed_media_type, data_url_payload = _extract_data_url_parts(payload)
                if not data_url_payload:
                    raise ValueError(
                        f"Notebook output {cell_index}:{output_index} contains an invalid SVG data URL"
                    )
                image_bytes = _decode_base64_payload(data_url_payload)
                resolved_media_type = parsed_media_type
            else:
                image_bytes = payload.encode("utf-8")
                resolved_media_type = media_type
        else:
            if payload.startswith("data:"):
                parsed_media_type, data_url_payload = _extract_data_url_parts(payload)
                if not data_url_payload:
                    raise ValueError(
                        f"Notebook output {cell_index}:{output_index} contains an invalid image data URL"
                    )
                image_bytes = _decode_base64_payload(data_url_payload)
                resolved_media_type = parsed_media_type
            else:
                image_bytes = _decode_base64_payload(payload)
                resolved_media_type = media_type

        if not image_bytes:
            continue
        _validate_image_size(image_bytes)
        return image_bytes, _normalize_media_type(resolved_media_type)

    raise ValueError(
        f"Notebook output {cell_index}:{output_index} does not contain a supported image mime bundle"
    )


async def _download_image_bytes(image_url: str) -> Tuple[bytes, str]:
    parsed = urlparse(image_url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError(
            "Unsupported image URL scheme. Only data/http/https URLs are allowed."
        )
    if not parsed.netloc:
        raise ValueError("Invalid image URL: missing hostname")

    async with aiohttp.ClientSession() as session:
        async with session.get(image_url, allow_redirects=True) as response:
            if response.status >= 400:
                raise RuntimeError(
                    f"HTTP {response.status} while downloading image: {image_url}"
                )
            image_bytes = await response.read()
            media_type = _normalize_media_type(response.headers.get("Content-Type"))
    return image_bytes, media_type


async def _extract_image_payload(image_url: str) -> Tuple[str, str]:
    if image_url.startswith("data:"):
        media_type, payload = _extract_data_url_parts(image_url)
        if not payload:
            raise ValueError("Invalid data URL format for interpret_image")
        image_bytes = _decode_base64_payload(payload)
        _validate_image_size(image_bytes)
        return media_type, base64.b64encode(image_bytes).decode("utf-8")

    image_bytes, media_type = await _download_image_bytes(image_url)
    if not image_bytes:
        raise ValueError("Downloaded image is empty")
    _validate_image_size(image_bytes)
    return media_type, base64.b64encode(image_bytes).decode("utf-8")


def _normalize_visual_ref(value: Any) -> str:
    normalized = _normalize_optional_text(value)
    if normalized.startswith("visual_ref:"):
        normalized = normalized.split(":", 1)[1].strip()
    if normalized.lower() in OMITTED_TEXT_TOKENS:
        return ""
    return normalized


def _normalize_source_type(value: Any) -> str:
    normalized = _normalize_optional_text(value)
    return normalized.lower()


def normalize_interpret_image_args(args: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(args, dict):
        return {}

    normalized = dict(args)

    for field_name in ("image_url", "visual_ref", "image_path", "file_path"):
        if field_name not in normalized:
            continue
        cleaned = (
            _normalize_visual_ref(normalized.get(field_name))
            if field_name == "visual_ref"
            else _normalize_optional_text(normalized.get(field_name))
        )
        if cleaned:
            normalized[field_name] = cleaned
        else:
            normalized.pop(field_name, None)

    for field_name in ("cell_index", "output_index"):
        if field_name not in normalized:
            continue
        cleaned = _normalize_optional_index(normalized.get(field_name))
        if cleaned is None:
            normalized.pop(field_name, None)
        else:
            normalized[field_name] = cleaned

    source_type = _normalize_source_type(normalized.get("source_type"))
    if source_type:
        normalized["source_type"] = source_type
    else:
        normalized.pop("source_type", None)

    fields_by_source_type = {
        "image_url": {"image_url"},
        "visual_ref": {"visual_ref"},
        "image_path": {"image_path"},
        "notebook_output": {"file_path", "cell_index", "output_index"},
    }
    allowed_fields = fields_by_source_type.get(source_type)
    if allowed_fields is not None:
        for field_name in (
            "image_url",
            "visual_ref",
            "image_path",
            "file_path",
            "cell_index",
            "output_index",
        ):
            if field_name not in allowed_fields:
                normalized.pop(field_name, None)
    elif "file_path" not in normalized:
        normalized.pop("cell_index", None)
        normalized.pop("output_index", None)

    return normalized


def _is_data_image_url(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    normalized = value.strip().lower()
    return normalized.startswith("data:image/") and ";base64," in normalized


def _resolve_visual_ref_image_url(args: dict[str, Any]) -> tuple[str, str]:
    visual_ref = _normalize_visual_ref(args.get("visual_ref"))
    if not visual_ref:
        return "", ""

    connection_id = str(args.get("connection_id") or "").strip()
    if not connection_id:
        raise ValueError("connection_id is required when using visual_ref")

    handler = handler_registry.get(connection_id)
    if not handler:
        raise ValueError(f"No active frontend connection for connection_id {connection_id}")

    ref_store = getattr(handler, "visual_artifact_refs", None)
    if not isinstance(ref_store, dict):
        raise ValueError("No visual artifacts available for this connection")

    payload = ref_store.get(visual_ref)
    if isinstance(payload, str):
        image_url = payload
    elif isinstance(payload, dict):
        image_url = str(payload.get("image_url") or "").strip()
    else:
        image_url = ""

    if not image_url:
        raise ValueError(f"Unknown visual_ref: {visual_ref}")

    return image_url, visual_ref


def _get_handler_for_local_source(args: dict[str, Any]) -> Any:
    connection_id = str(args.get("connection_id") or "").strip()
    if not connection_id:
        raise ValueError(
            "connection_id is required when using image_path or notebook file sources"
        )

    handler = handler_registry.get(connection_id)
    if not handler:
        raise ValueError(f"No active frontend connection for connection_id {connection_id}")
    return handler


async def _stage_local_image_source(
    args: dict[str, Any],
    image_bytes: bytes,
    media_type: str,
    source_type: str,
    source_path: str,
    cell_index: int | None = None,
    output_index: int | None = None,
) -> ResolvedImageSource:
    handler = _get_handler_for_local_source(args)
    processor = getattr(handler, "image_processor", None)
    if processor is None or not hasattr(processor, "save_image_bytes"):
        raise ValueError("No active image processor available for interpret_image staging")

    image_url = await processor.save_image_bytes(image_bytes, media_type)
    if not image_url:
        raise RuntimeError("Failed to stage image for interpret_image")

    ref_store = getattr(handler, "visual_artifact_refs", None)
    if not isinstance(ref_store, dict):
        ref_store = {}
        setattr(handler, "visual_artifact_refs", ref_store)

    visual_ref = f"visual_{uuid.uuid4().hex[:16]}"
    ref_store[visual_ref] = {
        "image_url": image_url,
        "source_type": source_type,
        "mime_type": media_type,
        "source_path": source_path,
    }
    if cell_index is not None:
        ref_store[visual_ref]["cell_index"] = str(cell_index)
    if output_index is not None:
        ref_store[visual_ref]["output_index"] = str(output_index)

    while len(ref_store) > MAX_STAGED_VISUAL_REFS:
        oldest_key = next(iter(ref_store), None)
        if oldest_key is None:
            break
        ref_store.pop(oldest_key, None)

    return ResolvedImageSource(
        image_url=image_url,
        visual_ref=visual_ref,
        media_type=media_type,
        image_base64=base64.b64encode(image_bytes).decode("utf-8"),
    )


def _resolve_source_kind(args: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    normalized_args = normalize_interpret_image_args(args)
    source_type = _normalize_source_type(normalized_args.get("source_type"))
    visual_ref = _normalize_visual_ref(normalized_args.get("visual_ref"))
    image_url = _normalize_optional_text(normalized_args.get("image_url"))
    image_path = _normalize_optional_text(normalized_args.get("image_path"))
    file_path = _normalize_optional_text(normalized_args.get("file_path"))
    has_cell_index = normalized_args.get("cell_index") is not None
    has_output_index = normalized_args.get("output_index") is not None
    notebook_selected = bool(file_path)

    if source_type:
        allowed_source_types = {
            "image_url",
            "visual_ref",
            "image_path",
            "notebook_output",
        }
        if source_type not in allowed_source_types:
            raise ValueError(
                "source_type must be one of: image_url, visual_ref, image_path, notebook_output"
            )

        if source_type == "image_url":
            if not image_url:
                raise ValueError("image_url is required when source_type is image_url")
            return "image_url", {"image_url": image_url}

        if source_type == "visual_ref":
            if not visual_ref:
                raise ValueError("visual_ref is required when source_type is visual_ref")
            return "visual_ref", {"visual_ref": visual_ref}

        if source_type == "image_path":
            if not image_path:
                raise ValueError("image_path is required when source_type is image_path")
            return "image_path", {"image_path": image_path}

        if not file_path or not has_cell_index or not has_output_index:
            raise ValueError(
                "file_path, cell_index, and output_index are required when source_type is notebook_output"
            )
        return (
            "notebook_output",
            {
                "file_path": file_path,
                "cell_index": _coerce_non_negative_index(
                    normalized_args.get("cell_index"), "cell_index"
                ),
                "output_index": _coerce_non_negative_index(
                    normalized_args.get("output_index"), "output_index"
                ),
            },
        )

    modes: list[tuple[str, dict[str, Any]]] = []
    if visual_ref:
        modes.append(("visual_ref", {"visual_ref": visual_ref}))
    if image_url:
        modes.append(("image_url", {"image_url": image_url}))
    if image_path:
        modes.append(("image_path", {"image_path": image_path}))
    if notebook_selected:
        if not file_path or not has_cell_index or not has_output_index:
            raise ValueError(
                "file_path, cell_index, and output_index are required together when selecting a notebook image"
            )
        modes.append(
            (
                "notebook_output",
                {
                    "file_path": file_path,
                    "cell_index": _coerce_non_negative_index(
                        normalized_args.get("cell_index"), "cell_index"
                    ),
                    "output_index": _coerce_non_negative_index(
                        normalized_args.get("output_index"), "output_index"
                    ),
                },
            )
        )

    if len(modes) > 1:
        raise ValueError(
            "interpret_image accepts exactly one image source: visual_ref, image_url, image_path, or file_path+cell_index+output_index"
        )
    if not modes:
        raise ValueError(
            "image_url, visual_ref, image_path, or file_path+cell_index+output_index is required"
        )
    return modes[0]


async def _resolve_image_source(args: dict[str, Any]) -> ResolvedImageSource:
    source_kind, payload = _resolve_source_kind(args)

    if source_kind == "visual_ref":
        image_url, visual_ref = _resolve_visual_ref_image_url({"visual_ref": payload["visual_ref"], **args})
        return ResolvedImageSource(image_url=image_url, visual_ref=visual_ref)

    if source_kind == "image_url":
        return ResolvedImageSource(image_url=payload["image_url"])

    if source_kind == "image_path":
        image_path = _normalize_local_path(payload["image_path"], "image_path")
        image_bytes, media_type = _read_local_image_file(image_path)
        return await _stage_local_image_source(
            args,
            image_bytes=image_bytes,
            media_type=media_type,
            source_type="local_image_file",
            source_path=image_path,
        )

    file_path = _normalize_local_path(payload["file_path"], "file_path")
    cell_index = payload["cell_index"]
    output_index = payload["output_index"]
    image_bytes, media_type = _extract_notebook_output_image(
        file_path, cell_index, output_index
    )
    return await _stage_local_image_source(
        args,
        image_bytes=image_bytes,
        media_type=media_type,
        source_type="notebook_saved_output",
        source_path=file_path,
        cell_index=cell_index,
        output_index=output_index,
    )


def _build_remote_interpret_image_url() -> str:
    remote_base = build_remote_backend_url("chat").removesuffix("/chat")
    return f"{remote_base}/v2/agent/interpret_image"


def _build_ssl_context() -> ssl.SSLContext:
    try:
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


async def _call_remote_interpret_image(
    image_base64: str,
    media_type: str,
    user_token: str,
) -> str:
    remote_url = _build_remote_interpret_image_url()
    ssl_context = _build_ssl_context()
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {user_token}",
    }
    payload = {
        "image_data": image_base64,
        "media_type": _normalize_media_type(media_type),
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(
            remote_url,
            data=json.dumps(payload),
            headers=headers,
            ssl=ssl_context,
        ) as response:
            response_text = await response.text()
            try:
                response_json = json.loads(response_text)
            except json.JSONDecodeError:
                response_json = None

            if response.status != 200:
                error_message = response_text
                if isinstance(response_json, dict):
                    error_message = str(response_json.get("error") or error_message)
                raise RuntimeError(
                    f"interpret_image remote API failed ({response.status}): {error_message}"
                )

            if not isinstance(response_json, dict):
                raise RuntimeError("interpret_image remote API returned invalid JSON")
            analysis = response_json.get("analysis")
            if not isinstance(analysis, str) or not analysis.strip():
                raise RuntimeError("interpret_image remote API returned empty analysis")
            return analysis


async def _execute_interpret_image_tool_impl(args: dict[str, Any]) -> dict[str, str] | str:
    user_token = (args.get("_user_token") or "").strip()
    if not user_token:
        return "Error: Missing authentication token for interpret_image"

    try:
        resolved_source = await _resolve_image_source(args)
        image_url = resolved_source.image_url
        image_base64 = resolved_source.image_base64
        media_type = resolved_source.media_type
        if not image_base64:
            media_type, image_base64 = await _extract_image_payload(image_url)
        analysis = await _call_remote_interpret_image(image_base64, media_type, user_token)
        safe_image_url = image_url if not _is_data_image_url(image_url) else ""
        result_payload: dict[str, str] = {
            "analysis": analysis,
            "image_url": safe_image_url,
        }
        if resolved_source.visual_ref:
            result_payload["visual_ref"] = resolved_source.visual_ref
        return result_payload
    except Exception as exc:
        return f"Error: {exc}"


async def execute_interpret_image_tool(args: dict[str, Any]) -> dict[str, str] | str:
    timeout_seconds = get_tool_timeout_seconds("interpret_image")
    try:
        task = _execute_interpret_image_tool_impl(args)
        if timeout_seconds is None:
            return await task
        return await asyncio.wait_for(task, timeout=timeout_seconds)
    except asyncio.TimeoutError:
        if timeout_seconds is None:
            return "Error: interpret_image timed out"
        return f"Error: interpret_image timed out after {timeout_seconds:g} seconds"
