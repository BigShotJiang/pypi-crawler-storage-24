"""
Shared output-length limits for tool results.

Prevents excessively large tool outputs from exploding the LLM context.
"""

from __future__ import annotations

import os
import re

MAX_TOOL_OUTPUT_CHARS = int(os.environ.get("D5M_MAX_TOOL_RESULT_CHARS", "12000"))

_MARKER_TEMPLATE = "\n\n... [{} characters omitted] ...\n\n"
# Overhead of the marker excluding the variable-length number.
_MARKER_OVERHEAD = len(_MARKER_TEMPLATE.format(""))

_VISUAL_REF_LINE_RE = re.compile(
    r"^visual_(?:ref|image_url):\s+\S+\s*$", re.IGNORECASE
)


def _split_trailing_visual_refs(text: str) -> tuple[str, str]:
    """Split trailing ``visual_ref:`` / ``visual_image_url:`` lines from *text*.

    Returns ``(body, refs_block)`` where *refs_block* is the joined trailing
    ref lines (including a leading newline) or an empty string.
    """
    lines = text.splitlines()
    idx = len(lines) - 1
    while idx >= 0 and _VISUAL_REF_LINE_RE.match(lines[idx]):
        idx -= 1

    if idx == len(lines) - 1:
        # No trailing visual refs.
        return text, ""

    body = "\n".join(lines[: idx + 1])
    refs_block = "\n" + "\n".join(lines[idx + 1 :])
    return body, refs_block


def truncate_tool_output(text: str, *, max_chars: int = 0) -> str:
    """Truncate *text* to roughly *max_chars* characters of body content.

    If *max_chars* is 0 (the default), ``MAX_TOOL_OUTPUT_CHARS`` is used.
    A value <= 0 after resolving the default disables truncation.

    Trailing ``visual_ref:`` / ``visual_image_url:`` lines are preserved
    outside the character budget so the LLM can reference generated
    artifacts (matching V1 proxy behaviour).  The body portion (everything
    before those trailing refs) is guaranteed to stay within the cap.

    When the body is truncated both the head and tail are kept so the LLM
    can still see the end of the output (often the most relevant part,
    e.g. error messages at the end of a build log).
    """
    limit = max_chars if max_chars > 0 else MAX_TOOL_OUTPUT_CHARS
    if limit <= 0 or len(text) <= limit:
        return text

    # Preserve trailing visual refs outside the character budget.
    body, refs_block = _split_trailing_visual_refs(text)

    # If only the refs pushed us over, keep the full text.
    if len(body) <= limit:
        return text

    # Budget available for head + tail after reserving space for the marker.
    # The marker contains a number whose length we don't know yet, so we
    # conservatively reserve space for a 10-digit number (>1 billion chars).
    marker_reserve = _MARKER_OVERHEAD + 10
    usable = limit - marker_reserve
    if usable < 2:
        # Limit is absurdly small; just hard-truncate.
        return body[:limit]

    # Reserve ~20 % for the tail, clamped so both head and tail get >= 1 char.
    tail_budget = min(max(usable // 5, 1), usable - 1)
    head_budget = usable - tail_budget

    head = body[:head_budget]
    tail = body[-tail_budget:] if tail_budget > 0 else ""

    omitted = len(body) - head_budget - tail_budget
    return f"{head}{_MARKER_TEMPLATE.format(omitted)}{tail}{refs_block}"
