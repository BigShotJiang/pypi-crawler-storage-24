"""
Standalone shell execution tool for HTTP tool loops.

This module intentionally does not import the agent package to avoid
WebSocket/agent-SDK coupling and circular imports.
"""

from __future__ import annotations

import os
import shlex
import subprocess
from typing import Any, Dict

from d5m_ai.tools.output_limits import truncate_tool_output
from d5m_ai.tools.tool_timeout_config import get_tool_timeout_seconds

# Maintain a per-process working directory without mutating global cwd.
_CWD = os.getcwd()

def _handle_cd(parts: list[str]) -> str:
    global _CWD
    if len(parts) == 1:
        target = os.path.expanduser("~")
    else:
        target = os.path.expanduser(parts[1])
        if not os.path.isabs(target):
            target = os.path.join(_CWD, target)
    target = os.path.realpath(target)
    if not os.path.isdir(target):
        return f"Error: directory does not exist: {target}"
    _CWD = target
    return f"Changed directory to: {_CWD}"


async def execute_shell_execute_tool(args: Dict[str, Any]) -> str:
    """
    Execute a shell command locally.

    Permission checks are handled by the v2 permission gate wrapper.
    """
    command = (args.get("command") or "").strip()
    if not command:
        return "Error: command is required"

    try:
        parts = shlex.split(command)
    except Exception:
        parts = []

    if parts and parts[0].lower() == "cd":
        return _handle_cd(parts)

    timeout_seconds = get_tool_timeout_seconds("shell_execute")
    run_kwargs = {
        "shell": True,
        "capture_output": True,
        "text": True,
        "cwd": _CWD,
    }
    if timeout_seconds is not None:
        run_kwargs["timeout"] = timeout_seconds

    try:
        result = subprocess.run(command, **run_kwargs)
    except subprocess.TimeoutExpired:
        if timeout_seconds is not None:
            return f"Error: command timed out after {timeout_seconds:g} seconds"
        return "Error: command timed out"
    except Exception as exc:
        return f"Error executing command: {exc}"

    output = ""
    if result.stdout:
        output += f"STDOUT:\n{result.stdout}"
    if result.stderr:
        if output:
            output += f"\n\nSTDERR:\n{result.stderr}"
        else:
            output += f"STDERR:\n{result.stderr}"

    if result.returncode != 0:
        output += f"\n\nReturn code: {result.returncode}"

    if not output.strip():
        output = "Command executed successfully (no output)"

    return truncate_tool_output(output)
