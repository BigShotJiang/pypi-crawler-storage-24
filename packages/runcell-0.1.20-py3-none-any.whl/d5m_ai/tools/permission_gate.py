"""
Permission gating utilities for agent v2 pending tool execution.

This module provides:
- Rule metadata for tools that require explicit user approval.
- In-request policy normalization and decision updates.
- Frontend request/response helpers for pause/resume permission flow.
"""

from __future__ import annotations

import asyncio
import shlex
import uuid
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Dict, Optional

from d5m_ai.agent.config import handler_registry

PERMISSION_SCOPE_TOOL = "tool"
PERMISSION_SCOPE_SHELL_COMMAND = "shell_command"

GLOBAL_MODE_ASK_EVERY_TIME = "ask_every_time"
GLOBAL_MODE_RUN_EVERYTHING = "run_everything"
VALID_GLOBAL_MODES = {GLOBAL_MODE_ASK_EVERY_TIME, GLOBAL_MODE_RUN_EVERYTHING}

DECISION_ALLOW_ONCE = "allow_once"
DECISION_SKIP_ONCE = "skip_once"
DECISION_ALWAYS_ALLOW = "always_allow"
DECISION_ALWAYS_ASK = "always_ask"
VALID_DECISIONS = {
    DECISION_ALLOW_ONCE,
    DECISION_SKIP_ONCE,
    DECISION_ALWAYS_ALLOW,
    DECISION_ALWAYS_ASK,
}

ALLOWED_PRESETS = [
    DECISION_ALLOW_ONCE,
    DECISION_SKIP_ONCE,
    DECISION_ALWAYS_ALLOW,
    DECISION_ALWAYS_ASK,
]
VALID_PERSISTED_PRESETS = {DECISION_ALWAYS_ALLOW, DECISION_ALWAYS_ASK}

PERMISSION_DENIED_OUTPUT = "Tool execution skipped: permission denied by user."
PERMISSION_CHANNEL_ERROR_OUTPUT = (
    "Tool execution skipped: permission channel is unavailable."
)
PERMISSION_INTERRUPTED_OUTPUT = (
    "Tool execution skipped: permission request was interrupted."
)


@dataclass(frozen=True)
class PermissionRule:
    tool_name: str
    scope: str
    shell_command_arg: str = "command"


# Wrapper-ready metadata. Launch scope intentionally starts with risky tools only.
PERMISSION_RULES: Dict[str, PermissionRule] = {
    "shell_execute": PermissionRule(
        tool_name="shell_execute",
        scope=PERMISSION_SCOPE_SHELL_COMMAND,
        shell_command_arg="command",
    ),
    "cell_execute": PermissionRule(
        tool_name="cell_execute",
        scope=PERMISSION_SCOPE_TOOL,
    ),
    "run_cell": PermissionRule(
        tool_name="run_cell",
        scope=PERMISSION_SCOPE_TOOL,
    ),
    "delete_cell": PermissionRule(
        tool_name="delete_cell",
        scope=PERMISSION_SCOPE_TOOL,
    ),
    "rerun_all_cells": PermissionRule(
        tool_name="rerun_all_cells",
        scope=PERMISSION_SCOPE_TOOL,
    ),
}

DEFAULT_PERMISSION_PREFERENCES: Dict[str, Any] = {
    "global_mode": GLOBAL_MODE_ASK_EVERY_TIME,
    "tool_presets": {
        "run_cell": DECISION_ALWAYS_ALLOW,
    },
    "shell_command_presets": {},
}


def get_permission_rule(tool_name: str) -> Optional[PermissionRule]:
    """Return permission rule metadata for a tool if gating is enabled."""
    return PERMISSION_RULES.get(tool_name)


def normalize_shell_command_key(command: Any) -> str:
    """
    Normalize shell command text for exact command-key matching.

    This intentionally keeps matching strict: exact normalized string only.
    """
    if not isinstance(command, str):
        return ""

    trimmed = command.strip()
    if not trimmed:
        return ""

    try:
        tokens = shlex.split(trimmed, posix=True)
        if tokens:
            return shlex.join(tokens)
    except Exception:
        pass

    return " ".join(trimmed.split())


def normalize_permission_preferences(raw_preferences: Any) -> Dict[str, Any]:
    """Normalize permission preference payload into a strict internal shape."""
    normalized = deepcopy(DEFAULT_PERMISSION_PREFERENCES)
    if not isinstance(raw_preferences, dict):
        return normalized

    global_mode = raw_preferences.get("global_mode")
    if global_mode in VALID_GLOBAL_MODES:
        normalized["global_mode"] = global_mode

    tool_presets_raw = raw_preferences.get("tool_presets")
    if isinstance(tool_presets_raw, dict):
        cleaned_tool_presets: Dict[str, str] = {}
        for tool_name, preset in tool_presets_raw.items():
            if isinstance(tool_name, str) and preset in VALID_PERSISTED_PRESETS:
                cleaned_tool_presets[tool_name] = preset
        normalized["tool_presets"] = cleaned_tool_presets

    shell_presets_raw = raw_preferences.get("shell_command_presets")
    if isinstance(shell_presets_raw, dict):
        cleaned_shell_presets: Dict[str, str] = {}
        for command_key, preset in shell_presets_raw.items():
            if not isinstance(command_key, str) or preset not in VALID_PERSISTED_PRESETS:
                continue
            normalized_key = normalize_shell_command_key(command_key)
            if normalized_key:
                cleaned_shell_presets[normalized_key] = preset
        normalized["shell_command_presets"] = cleaned_shell_presets

    return normalized


def get_permission_context(
    tool_name: str,
    tool_args: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    """Build context for permission policy and UI payloads."""
    rule = get_permission_rule(tool_name)
    if not rule:
        return None

    context: Dict[str, Any] = {
        "tool_name": rule.tool_name,
        "permission_scope": rule.scope,
        "shell_command_key": None,
    }

    if rule.scope == PERMISSION_SCOPE_SHELL_COMMAND:
        shell_key = normalize_shell_command_key(tool_args.get(rule.shell_command_arg))
        context["shell_command_key"] = shell_key or None

    return context


def should_auto_allow(
    permission_context: Dict[str, Any],
    permission_preferences: Dict[str, Any],
) -> bool:
    """
    Evaluate policy in this order:
    1) global mode
    2) scoped preset (shell command for shell_execute, per-tool otherwise)
    3) ask (not auto-allow)
    """
    global_mode = permission_preferences.get("global_mode", GLOBAL_MODE_ASK_EVERY_TIME)
    if global_mode == GLOBAL_MODE_RUN_EVERYTHING:
        return True

    scope = permission_context.get("permission_scope")

    if scope == PERMISSION_SCOPE_SHELL_COMMAND:
        shell_key = permission_context.get("shell_command_key")
        shell_presets = permission_preferences.get("shell_command_presets", {})
        if isinstance(shell_presets, dict) and isinstance(shell_key, str):
            shell_preset = shell_presets.get(shell_key)
            if shell_preset == DECISION_ALWAYS_ALLOW:
                return True
            if shell_preset == DECISION_ALWAYS_ASK:
                return False

        tool_name = permission_context.get("tool_name")
        tool_presets = permission_preferences.get("tool_presets", {})
        if isinstance(tool_presets, dict) and isinstance(tool_name, str):
            tool_preset = tool_presets.get(tool_name)
            if tool_preset == DECISION_ALWAYS_ALLOW:
                return True
            if tool_preset == DECISION_ALWAYS_ASK:
                return False

        return False

    tool_name = permission_context.get("tool_name")
    tool_presets = permission_preferences.get("tool_presets", {})
    if isinstance(tool_presets, dict) and isinstance(tool_name, str):
        tool_preset = tool_presets.get(tool_name)
        if tool_preset == DECISION_ALWAYS_ALLOW:
            return True
        if tool_preset == DECISION_ALWAYS_ASK:
            return False

    return False


def normalize_permission_response(raw_response: Any) -> Dict[str, Any]:
    """Normalize runtime permission response payload from frontend."""
    normalized = {
        "decision": DECISION_SKIP_ONCE,
        "global_mode": GLOBAL_MODE_ASK_EVERY_TIME,
    }
    if not isinstance(raw_response, dict):
        return normalized

    decision = raw_response.get("decision")
    if decision in VALID_DECISIONS:
        normalized["decision"] = decision

    global_mode = raw_response.get("global_mode")
    if global_mode in VALID_GLOBAL_MODES:
        normalized["global_mode"] = global_mode

    return normalized


def apply_permission_response(
    permission_preferences: Dict[str, Any],
    permission_context: Dict[str, Any],
    response: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Apply one runtime decision to in-request preference state.

    This ensures later tool calls in the same pending batch use updated policy.
    """
    updated = normalize_permission_preferences(permission_preferences)
    normalized_response = normalize_permission_response(response)

    updated["global_mode"] = normalized_response["global_mode"]
    decision = normalized_response["decision"]

    if decision not in VALID_PERSISTED_PRESETS:
        return updated

    scope = permission_context.get("permission_scope")
    if scope == PERMISSION_SCOPE_SHELL_COMMAND:
        shell_key = permission_context.get("shell_command_key")
        if isinstance(shell_key, str) and shell_key:
            shell_presets = updated.setdefault("shell_command_presets", {})
            if isinstance(shell_presets, dict):
                shell_presets[shell_key] = decision
            return updated

    tool_name = permission_context.get("tool_name")
    if isinstance(tool_name, str) and tool_name:
        tool_presets = updated.setdefault("tool_presets", {})
        if isinstance(tool_presets, dict):
            tool_presets[tool_name] = decision

    return updated


def decision_allows_execution(decision: str) -> bool:
    """Return True when the decision should execute the pending tool call."""
    return decision in {
        DECISION_ALLOW_ONCE,
        DECISION_ALWAYS_ALLOW,
        DECISION_ALWAYS_ASK,
    }


def build_permission_denied_output(tool_name: str, tool_args: Dict[str, Any]) -> str:
    """Deterministic cancellation output used as normal tool_call_output."""
    if tool_name == "shell_execute":
        command = tool_args.get("command")
        if isinstance(command, str) and command.strip():
            return (
                "Tool execution skipped: permission denied by user. "
                f"Command: {command.strip()}"
            )
    return PERMISSION_DENIED_OUTPUT


def build_permission_request_event(
    *,
    call_id: str,
    tool_name: str,
    tool_args: Dict[str, Any],
    permission_context: Dict[str, Any],
    permission_preferences: Dict[str, Any],
    content_index: Optional[int],
) -> Dict[str, Any]:
    """Build SSE payload for inline permission request UI."""
    request_id = str(uuid.uuid4())
    payload: Dict[str, Any] = {
        "type": "tool_permission_request",
        "call_id": call_id,
        "request_id": request_id,
        "tool": tool_name,
        "args": tool_args,
        "permission_scope": permission_context.get("permission_scope"),
        "current_global_mode": permission_preferences.get(
            "global_mode", GLOBAL_MODE_ASK_EVERY_TIME
        ),
        "allowed_presets": ALLOWED_PRESETS,
        "content_index": content_index,
    }
    shell_command_key = permission_context.get("shell_command_key")
    if shell_command_key:
        payload["shell_command_key"] = shell_command_key
    return payload


async def wait_for_permission_response(
    connection_id: Optional[str],
    request_event: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Ask the frontend for permission and wait indefinitely for response.

    Raises:
        RuntimeError: if frontend channel is unavailable.
        asyncio.CancelledError: if frontend disconnects while waiting.
    """
    if not connection_id:
        raise RuntimeError("missing_connection_id")

    handler = handler_registry.get(connection_id)
    if not handler:
        raise RuntimeError("frontend_handler_not_found")

    request_id = request_event.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        raise RuntimeError("invalid_permission_request_id")

    loop = asyncio.get_running_loop()
    future = loop.create_future()
    use_pending_map = hasattr(handler, "pending_requests")

    if use_pending_map:
        handler.pending_requests[request_id] = future
    else:
        if handler.waiter and not handler.waiter.done():
            handler.waiter.cancel()
        handler.waiter = future

    try:
        sent = await handler._safe_write_message(request_event)
        if sent is False:
            raise RuntimeError("frontend_socket_unavailable")
        raw_response = await future
        return normalize_permission_response(raw_response)
    finally:
        if use_pending_map:
            handler.pending_requests.pop(request_id, None)
        elif handler.waiter is future:
            handler.waiter = None
