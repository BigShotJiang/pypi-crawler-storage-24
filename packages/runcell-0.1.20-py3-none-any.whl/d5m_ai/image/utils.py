from __future__ import annotations

import os
import time
import uuid
from typing import Tuple

DEFAULT_IMAGE_MEDIA_TYPE = "image/png"
IMAGE_MEDIA_TYPE_TO_EXTENSION = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif",
    "image/webp": ".webp",
    "image/svg+xml": ".svg",
}


def normalize_image_media_type(media_type: str | None) -> str:
    if not isinstance(media_type, str):
        return DEFAULT_IMAGE_MEDIA_TYPE
    normalized = media_type.split(";")[0].strip().lower()
    if normalized in IMAGE_MEDIA_TYPE_TO_EXTENSION:
        return normalized
    return DEFAULT_IMAGE_MEDIA_TYPE


def image_media_type_to_extension(media_type: str | None) -> str:
    return IMAGE_MEDIA_TYPE_TO_EXTENSION.get(
        normalize_image_media_type(media_type), ".png"
    )


def build_image_storage_location(storage_dir: str, media_type: str | None) -> Tuple[str, str]:
    timestamp = int(time.time())
    image_id = f"{timestamp}_{uuid.uuid4().hex[:8]}"
    extension = image_media_type_to_extension(media_type)
    filename = f"{image_id}{extension}"
    filepath = os.path.join(storage_dir, filename)
    return filename, filepath


def extract_base64_and_media_type(
    image_data: str,
    media_type: str | None = None,
) -> tuple[str, str]:
    effective_media_type = normalize_image_media_type(media_type)
    normalized = image_data
    if isinstance(image_data, str) and image_data.startswith("data:"):
        header, _, payload = image_data.partition(",")
        parsed_media_type = header.replace("data:", "").split(";")[0]
        effective_media_type = normalize_image_media_type(parsed_media_type)
        normalized = payload
    elif isinstance(image_data, str) and "," in image_data:
        normalized = image_data.split(",", 1)[1]
    return normalized, effective_media_type
