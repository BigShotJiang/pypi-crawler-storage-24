from fides.api.api.v1.endpoints import (
    config_endpoints,
    connection_endpoints,
    connection_type_endpoints,
    connector_template_endpoints,
    consent_request_endpoints,
    dataset_config_endpoints,
    drp_endpoints,
    dsr_package_link,
    encryption_endpoints,
    identity_verification_endpoints,
    manual_webhook_endpoints,
    masking_endpoints,
    messaging_endpoints,
    oauth_endpoints,
    partitioning_endpoints,
    policy_endpoints,
    policy_webhook_endpoints,
    pre_approval_webhook_endpoints,
    privacy_request_endpoints,
    privacy_request_redaction_patterns_endpoints,
    registration_endpoints,
    saas_config_endpoints,
    storage_endpoints,
    user_endpoints,
    user_permission_endpoints,
    worker_endpoints,
)
from fides.api.util.api_router import APIRouter
from fides.system_integration_link import (
    routes as system_integration_link_routes,
)

api_router = APIRouter()
api_router.include_router(config_endpoints.router)
api_router.include_router(connection_type_endpoints.router)
api_router.include_router(connection_endpoints.router)
api_router.include_router(connector_template_endpoints.router)
api_router.include_router(consent_request_endpoints.router)
api_router.include_router(dataset_config_endpoints.router)
api_router.include_router(drp_endpoints.router)
api_router.include_router(dsr_package_link.router)
api_router.include_router(encryption_endpoints.router)
api_router.include_router(masking_endpoints.router)
api_router.include_router(oauth_endpoints.router)
api_router.include_router(policy_endpoints.router)
api_router.include_router(policy_webhook_endpoints.router)
api_router.include_router(pre_approval_webhook_endpoints.router)
api_router.include_router(privacy_request_endpoints.router)
api_router.include_router(privacy_request_redaction_patterns_endpoints.router)
api_router.include_router(identity_verification_endpoints.router)
api_router.include_router(storage_endpoints.router)
api_router.include_router(messaging_endpoints.router)
api_router.include_router(saas_config_endpoints.router)
api_router.include_router(partitioning_endpoints.router)
api_router.include_router(user_endpoints.router)
api_router.include_router(user_permission_endpoints.router)
api_router.include_router(manual_webhook_endpoints.router)
api_router.include_router(registration_endpoints.router)
api_router.include_router(worker_endpoints.router)
api_router.include_router(system_integration_link_routes.router)
