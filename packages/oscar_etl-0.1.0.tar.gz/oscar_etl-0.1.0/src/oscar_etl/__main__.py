from oscar_etl.cli import main

if __name__ == "__main__":
    main()
