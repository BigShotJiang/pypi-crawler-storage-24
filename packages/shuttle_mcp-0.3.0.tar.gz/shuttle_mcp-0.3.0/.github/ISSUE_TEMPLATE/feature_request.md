---
name: Feature Request
about: Suggest a new feature or improvement
title: "[Feature] "
labels: enhancement
---

## Problem

What problem does this solve? What's the use case?

## Proposed Solution

How should it work?

## Alternatives Considered

Any other approaches you've considered?
