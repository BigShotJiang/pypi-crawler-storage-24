class OutOfProjectionDomainError(Exception):
    pass
