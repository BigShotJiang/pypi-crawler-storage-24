class FromDataConfigError(Exception):
    pass
