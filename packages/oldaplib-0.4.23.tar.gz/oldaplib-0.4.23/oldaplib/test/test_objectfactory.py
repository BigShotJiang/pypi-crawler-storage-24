import base64
import random
import string
import unittest
from pathlib import Path
from pprint import pprint
from time import sleep
import jwt

from oldaplib.src.cachesingleton import CacheSingletonRedis
from oldaplib.src.datamodel import DataModel
from oldaplib.src.enums.adminpermissions import AdminPermission
from oldaplib.src.objectfactory import ResourceInstanceFactory, SortBy, ResourceInstance, SortDir
from oldaplib.src.connection import Connection
from oldaplib.src.enums.action import Action
from oldaplib.src.enums.datapermissions import DataPermission
from oldaplib.src.enums.language import Language
from oldaplib.src.helpers.attributechange import AttributeChange
from oldaplib.src.helpers.context import Context
from oldaplib.src.helpers.langstring import LangString
from oldaplib.src.helpers.oldaperror import OldapErrorNotFound, OldapErrorValue, OldapErrorNoPermission, \
    OldapErrorInUse, OldapErrorKey
from oldaplib.src.role import Role
from oldaplib.src.project import Project
from oldaplib.src.user import User
from oldaplib.src.xsd.geo_wktLiteral import Geo_wktLiteral
from oldaplib.src.xsd.iri import Iri
from oldaplib.src.xsd.xsd_anyuri import Xsd_anyURI
from oldaplib.src.xsd.xsd_base64binary import Xsd_base64Binary
from oldaplib.src.xsd.xsd_boolean import Xsd_boolean
from oldaplib.src.xsd.xsd_byte import Xsd_byte
from oldaplib.src.xsd.xsd_date import Xsd_date
from oldaplib.src.xsd.xsd_datetime import Xsd_dateTime
from oldaplib.src.xsd.xsd_datetimestamp import Xsd_dateTimeStamp
from oldaplib.src.xsd.xsd_decimal import Xsd_decimal
from oldaplib.src.xsd.xsd_double import Xsd_double
from oldaplib.src.xsd.xsd_duration import Xsd_duration
from oldaplib.src.xsd.xsd_float import Xsd_float
from oldaplib.src.xsd.xsd_gday import Xsd_gDay
from oldaplib.src.xsd.xsd_gmonth import Xsd_gMonth
from oldaplib.src.xsd.xsd_gmonthday import Xsd_gMonthDay
from oldaplib.src.xsd.xsd_gyear import Xsd_gYear
from oldaplib.src.xsd.xsd_gyearmonth import Xsd_gYearMonth
from oldaplib.src.xsd.xsd_hexbinary import Xsd_hexBinary
from oldaplib.src.xsd.xsd_id import Xsd_ID
from oldaplib.src.xsd.xsd_idref import Xsd_IDREF
from oldaplib.src.xsd.xsd_int import Xsd_int
from oldaplib.src.xsd.xsd_integer import Xsd_integer
from oldaplib.src.xsd.xsd_language import Xsd_language
from oldaplib.src.xsd.xsd_long import Xsd_long
from oldaplib.src.xsd.xsd_ncname import Xsd_NCName
from oldaplib.src.xsd.xsd_negativeinteger import Xsd_negativeInteger
from oldaplib.src.xsd.xsd_nmtoken import Xsd_NMTOKEN
from oldaplib.src.xsd.xsd_nonnegativeinteger import Xsd_nonNegativeInteger
from oldaplib.src.xsd.xsd_nonpositiveinteger import Xsd_nonPositiveInteger
from oldaplib.src.xsd.xsd_normalizedstring import Xsd_normalizedString
from oldaplib.src.xsd.xsd_positiveinteger import Xsd_positiveInteger
from oldaplib.src.xsd.xsd_qname import Xsd_QName
from oldaplib.src.xsd.xsd_short import Xsd_short
from oldaplib.src.xsd.xsd_string import Xsd_string
from oldaplib.src.xsd.xsd_time import Xsd_time
from oldaplib.src.xsd.xsd_token import Xsd_token
from oldaplib.src.xsd.xsd_unsignedbyte import Xsd_unsignedByte
from oldaplib.src.xsd.xsd_unsignedint import Xsd_unsignedInt
from oldaplib.src.xsd.xsd_unsignedlong import Xsd_unsignedLong
from oldaplib.src.xsd.xsd_unsignedshort import Xsd_unsignedShort
from redis.commands.search.aggregation import SortDirection

from oldaplib.src.helpers.query_processor import QueryProcessor


def find_project_root(current_path):
    # Climb up the directory hierarchy and check for a marker file
    path = Path(current_path).absolute()
    while not (path / 'pyproject.toml').exists():
        if path.parent == path:
            # Root of the filesystem, file not found
            raise RuntimeError('Project root not found')
        path = path.parent
    return path

class TestObjectFactory(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        project_root = find_project_root(__file__)
        cls._context = Context(name="DEFAULT")

        cls._connection = Connection(userId="rosenth",
                                     credentials="RioGrande",
                                     context_name="DEFAULT")
        cls._unpriv = Connection(userId="unknown",
                                 credentials="RioGrande",
                                 context_name="DEFAULT")
        cls._context['test'] = 'http://oldap.org/test#'
        cls._context.use('test')

        cls._connection.clear_graph(Xsd_QName('test:shacl'))
        cls._connection.clear_graph(Xsd_QName('test:onto'))
        cls._connection.clear_graph(Xsd_QName('test:data'))
        cls._connection.clear_graph(Xsd_QName('oldap:admin'))

        file = project_root / 'oldaplib' / 'ontologies' / 'admin.trig'
        cls._connection.upload_turtle(file)
        #sleep(1)  # upload may take a while...

        file = project_root / 'oldaplib' / 'ontologies' / 'admin-testing.trig'
        cls._connection.upload_turtle(file)
        #sleep(1)  # upload may take a while...

        file = project_root / 'oldaplib' / 'testdata' / 'objectfactory_test.trig'
        cls._connection.upload_turtle(file)

        file = project_root / 'oldaplib' / 'testdata' / 'instances_test.trig'
        cls._connection.upload_turtle(file)

        user = User.read(cls._connection, "rosenth")
        user.hasRole[Xsd_QName('oldap:Unknown')] = DataPermission.DATA_UPDATE
        user.update()

        ps = Role(con=cls._connection,
                  roleId="testNoUpdate",
                  label=LangString("testNoUpdate@en"),
                  comment=LangString("Testing PermissionSet@en"),
                  definedByProject="test")
        ps.create()
        cls._tps = ps.read(con=cls._connection, roleId="testNoUpdate", definedByProject="test")

        user = User(con=cls._connection,
                    userId=Xsd_NCName("factorytestuser"),
                    familyName="FactoryTest",
                    givenName="FactoryTest",
                    email="ft@test.com",
                    credentials="Waseliwas",
                    inProject={'oldap:Test': {}},
                    hasRole={ps.iri.as_qname: DataPermission.DATA_VIEW},
                    isActive=True)
        user.create()
        cls._tuser = User.read(cls._connection, "factorytestuser")

        user = User(con=cls._connection,
                    userId=Xsd_NCName("factorytestuser2"),
                    familyName="FactoryTest2",
                    givenName="FactoryTest2",
                    email="ft2@test.com",
                    credentials="Waseliwas2",
                    inProject={'oldap:Test': {AdminPermission.ADMIN_CREATE}},
                    hasRole={ps.iri.as_qname: DataPermission.DATA_VIEW, Xsd_QName('oldap:Unknown'): DataPermission.DATA_UPDATE},
                    isActive=True)
        user.create()
        cls._tuser2 = User.read(cls._connection, "factorytestuser")

        cls._con_tuser2 = Connection(userId="factorytestuser2",
                                 credentials="Waseliwas2",
                                 context_name="DEFAULT")

        cache = CacheSingletonRedis()
        cache.clear()


    @classmethod
    def tearDownClass(cls):
        #cls._connection.clear_graph(Xsd_QName('oldaplib:admin'))
        #cls._connection.upload_turtle("oldaplib/ontologies/admin.trig")
        #sleep(1)  # upload may take a while...
        pass

    def test_constructor_only(self):
        project = Project.read(con=self._connection, projectIri_SName='test')
        factory = ResourceInstanceFactory(con=self._connection, project=project)
        Book = factory.createObjectInstance('Book')

        b = Book(title="Hitchhiker's Guide to the Galaxy",
                 author=Iri('test:DouglasAdams', validate=False),
                 pubDate="1995-09-27",
                 attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW,
                                 Xsd_QName('hyha:HyperHamletMember'): DataPermission.DATA_PERMISSIONS})
        self.assertEqual(b.title, {Xsd_string("Hitchhiker's Guide to the Galaxy")})
        self.assertEqual(b.author, {Iri('test:DouglasAdams')})
        self.assertEqual(b.pubDate, {Xsd_date("1995-09-27")})
        self.assertIsNotNone(b.creationDate)
        self.assertEqual(b.createdBy, Iri('https://orcid.org/0000-0003-1681-4036', validate=False))
        self.assertIsNotNone(b.lastModificationDate)
        self.assertEqual(b.lastModifiedBy, Iri('https://orcid.org/0000-0003-1681-4036', validate=False))
        self.assertEqual(dict(b.attachedToRole), {Xsd_QName("oldap:Unknown"): DataPermission.DATA_VIEW,
                                                      Xsd_QName("hyha:HyperHamletMember"): DataPermission.DATA_PERMISSIONS})


    def test_constructor_A(self):
        project = Project.read(con=self._connection, projectIri_SName='test')
        factory = ResourceInstanceFactory(con=self._connection, project=project)
        Book = factory.createObjectInstance('Book')

        project = Project.read(con=self._connection, projectIri_SName='test')
        factory = ResourceInstanceFactory(con=self._connection, project=project)
        Book = factory.createObjectInstance('Book')

        b = Book(title="Hitchhiker's Guide to the Galaxy",
                 author=Iri('test:DouglasAdams', validate=False),
                 pubDate="1995-09-27",
                 attachedToRole={Xsd_QName('hyha:HyperHamletMember'): DataPermission.DATA_PERMISSIONS})
        self.assertEqual(b.title, {Xsd_string("Hitchhiker's Guide to the Galaxy")})
        self.assertEqual(b.author, {Iri('test:DouglasAdams')})
        self.assertEqual(b.pubDate, {Xsd_date("1995-09-27")})
        self.assertIsNotNone(b.creationDate)
        self.assertEqual(b.createdBy, Iri('https://orcid.org/0000-0003-1681-4036', validate=False))
        self.assertIsNotNone(b.lastModificationDate)
        self.assertEqual(b.lastModifiedBy, Iri('https://orcid.org/0000-0003-1681-4036', validate=False))
        self.assertEqual(dict(b.attachedToRole), {Xsd_QName('hyha:HyperHamletMember'): DataPermission.DATA_PERMISSIONS})
        b.create()
        b2 = Book.read(con=self._connection,
                       iri=b.iri)
        self.assertEqual(b2.title, b.title)
        self.assertEqual(b2.author, b.author)
        self.assertEqual(b2.pubDate, b.pubDate)
        self.assertEqual(b2.createdBy, b.createdBy)
        self.assertEqual(b2.creationDate, b.creationDate)
        self.assertEqual(b2.lastModifiedBy, b.lastModifiedBy)
        self.assertEqual(b2.lastModificationDate, b.lastModificationDate)
        self.assertEqual(dict(b2.attachedToRole), {Xsd_QName('hyha:HyperHamletMember'): DataPermission.DATA_PERMISSIONS})

        #
        # test unprivileged access. Should return "not found"-Error!
        #
        with self.assertRaises(OldapErrorNotFound):
            b3 = Book.read(con=self._unpriv, iri=b.iri)

        Page = factory.createObjectInstance('Page')
        p1 = Page(pageDesignation="Cover",
                  pageNum=1,
                  pageDescription=LangString("Cover page of book@en", "Vorderseite des Bucheinschlags@de"),
                  pageInBook="test:Hitchhiker",
                  attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW})
        self.assertEqual(p1.pageDesignation, {"Cover"})
        self.assertEqual(p1.pageNum, {1})
        self.assertEqual(p1.pageDescription, LangString("Cover page of book@en", "Vorderseite des Bucheinschlags@de"))
        self.assertEqual(p1.pageInBook, {"test:Hitchhiker"})
        p1.create()
        p2 = Page.read(con=self._connection, iri=p1.iri)
        self.assertEqual(p2.pageDesignation, p1.pageDesignation)
        self.assertEqual(p2.pageNum, p1.pageNum)
        self.assertEqual(p2.pageInBook, p1.pageInBook)
        self.assertEqual(p2.createdBy, p1.createdBy)
        self.assertEqual(p2.creationDate, p1.creationDate)
        self.assertEqual(p2.lastModifiedBy, p1.lastModifiedBy)
        self.assertEqual(p2.lastModificationDate, p1.lastModificationDate)

        b2.delete()
        with self.assertRaises(OldapErrorNotFound):
            tmp = Book.read(con=self._connection, iri=b2.iri)

        p2.delete()
        with self.assertRaises(OldapErrorNotFound):
            tmp = Page.read(con=self._connection, iri=p2.iri)

    def test_constructor_B(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        AllTypes = factory.createObjectInstance('AllTypes')
        at = AllTypes(stringProp=Xsd_string("A String Prop"),
                      langStringProp=LangString("A LangString@en", "Ein Sprachtext@de"),
                      booleanProp=Xsd_boolean(1),
                      decimalProp=Xsd_decimal(1.5),
                      floatProp= Xsd_float(1.5),
                      doubleProp=Xsd_double(1.5),
                      durationProp=Xsd_duration('PT2M10S'),
                      dateTimeProp=Xsd_dateTime('2001-10-26T21:32:52'),
                      dateTimeStampProp=Xsd_dateTimeStamp('2001-10-26T21:32:52Z'),
                      timeProp=Xsd_time('21:32:52+02:00'),
                      dateProp=Xsd_date(2025, 12, 31),
                      gYearMonthProp=Xsd_gYearMonth("2020-03"),
                      gYearProp=Xsd_gYear("2020"),
                      gMonthDayProp=Xsd_gMonthDay("--02-21"),
                      gDayProp=Xsd_gDay("---01"),
                      gMonthProp=Xsd_gMonth("--10"),
                      hexBinaryProp=Xsd_hexBinary("1fab17fa"),
                      base64BinaryProp=Xsd_base64Binary(base64.b64encode(b'Waseliwas soll den das sein?')),
                      anyURIProp=Xsd_anyURI('http://www.org/test'),
                      QNameProp=Xsd_QName('prefix:name'),
                      normalizedStringProp=Xsd_normalizedString("Dies ist ein string mit $onderzeichen\" und anderen Dingen"),
                      tokenProp=Xsd_token("Dies ist ein string mit $onderzeichen und anderen Dingen"),
                      languageProp=Xsd_language("de"),
                      nCNameProp=Xsd_NCName("Xsd_NCName"),
                      nMTOKENProp=Xsd_NMTOKEN(":ein.Test"),
                      iDProp=Xsd_ID("anchor"),
                      iDREFProp=Xsd_IDREF("anchor"),
                      integerProp=Xsd_integer(1),
                      nonPositiveIntegerProp=Xsd_nonPositiveInteger(-22),
                      negativeIntegerProp=Xsd_negativeInteger(-22),
                      longProp=Xsd_long(505_801),
                      intProp=Xsd_int(505_801),
                      shortProp=Xsd_short(-2024),
                      byteProp=Xsd_byte(100),
                      nonNegativeIntegerProp=Xsd_nonNegativeInteger(202_203_204),
                      unsignedLongProp=Xsd_unsignedLong(202_203_204),
                      unsignedIntProp=Xsd_unsignedInt(20200),
                      unsignedShortProp=Xsd_unsignedShort(20200),
                      unsignedByteProp=Xsd_unsignedByte(202),
                      positiveIntegerProp=Xsd_unsignedByte(202),
                      attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW})
        self.assertEqual(at.stringProp, {Xsd_string("A String Prop")})
        self.assertEqual(at.langStringProp, LangString("A LangString@en", "Ein Sprachtext@de"))
        self.assertEqual(at.booleanProp, Xsd_boolean(1))
        self.assertEqual(at.decimalProp, {Xsd_decimal(1.5)})
        self.assertEqual(at.floatProp, {Xsd_float(1.5)})
        self.assertEqual(at.doubleProp, {Xsd_double(1.5)})
        self.assertEqual(at.durationProp, {Xsd_duration('PT2M10S')})
        self.assertEqual(at.dateTimeProp, {Xsd_dateTime('2001-10-26T21:32:52')})
        self.assertEqual(at.dateTimeStampProp, {Xsd_dateTimeStamp('2001-10-26T21:32:52Z')})
        self.assertEqual(at.timeProp, {Xsd_time('21:32:52+02:00')})
        self.assertEqual(at.dateProp, {Xsd_date(2025, 12, 31)})
        self.assertEqual(at.gYearMonthProp, {Xsd_gYearMonth("2020-03")})
        self.assertEqual(at.gYearProp, {Xsd_gYear("2020")})
        self.assertEqual(at.gMonthDayProp, {Xsd_gMonthDay("--02-21")})
        self.assertEqual(at.gDayProp, {Xsd_gDay("---01")})
        self.assertEqual(at.gMonthProp, {Xsd_gMonth("--10")})
        self.assertEqual(at.hexBinaryProp, {Xsd_hexBinary("1fab17fa")})
        self.assertEqual(at.base64BinaryProp, {Xsd_base64Binary(base64.b64encode(b'Waseliwas soll den das sein?'))})
        self.assertEqual(at.anyURIProp, {Xsd_anyURI('http://www.org/test')})
        self.assertEqual(at.QNameProp, {Xsd_QName('prefix:name')})
        self.assertEqual(at.normalizedStringProp,
                         {Xsd_normalizedString("Dies ist ein string mit $onderzeichen\" und anderen Dingen")})
        self.assertEqual(at.tokenProp, {Xsd_token("Dies ist ein string mit $onderzeichen und anderen Dingen")})
        self.assertEqual(at.languageProp, {Xsd_language("de")})
        self.assertEqual(at.nCNameProp, {Xsd_NCName("Xsd_NCName")})
        self.assertEqual(at.nMTOKENProp, {Xsd_NMTOKEN(":ein.Test")})
        self.assertEqual(at.iDProp, {Xsd_ID("anchor")})
        self.assertEqual(at.iDREFProp, {Xsd_IDREF("anchor")})
        self.assertEqual(at.integerProp, {Xsd_integer(1)})
        self.assertEqual(at.nonPositiveIntegerProp, {Xsd_nonPositiveInteger(-22)})
        self.assertEqual(at.negativeIntegerProp, {Xsd_negativeInteger(-22)})
        self.assertEqual(at.longProp, {Xsd_long(505_801)})
        self.assertEqual(at.intProp, {Xsd_int(505_801)})
        self.assertEqual(at.shortProp, {Xsd_short(-2024)})
        self.assertEqual(at.byteProp, {Xsd_byte(100)})
        self.assertEqual(at.nonNegativeIntegerProp, {Xsd_nonNegativeInteger(202_203_204)})
        self.assertEqual(at.negativeIntegerProp, {Xsd_negativeInteger(-22)})
        self.assertEqual(at.longProp, {Xsd_long(505_801)})
        self.assertEqual(at.intProp, {Xsd_int(505_801)})
        self.assertEqual(at.shortProp, {Xsd_short(-2024)})
        self.assertEqual(at.byteProp, {Xsd_byte(100)})
        self.assertEqual(at.unsignedLongProp, {Xsd_unsignedLong(202_203_204)})
        self.assertEqual(at.unsignedIntProp, {Xsd_unsignedInt(20200)})
        self.assertEqual(at.unsignedShortProp, {Xsd_unsignedShort(20200)})
        self.assertEqual(at.unsignedByteProp, {Xsd_unsignedByte(202)})
        self.assertEqual(at.positiveIntegerProp, {Xsd_positiveInteger(202)})
        at.create()
        at2 = AllTypes.read(con=self._connection, iri=at.iri)
        self.assertEqual(at.stringProp, at2.stringProp)
        self.assertEqual(at.langStringProp, at2.langStringProp)
        self.assertEqual(at.booleanProp, at2.booleanProp)
        self.assertEqual(at.decimalProp, at2.decimalProp)
        self.assertEqual(at.floatProp, at2.floatProp)
        self.assertEqual(at.doubleProp, at2.doubleProp)
        self.assertEqual(at.durationProp, at2.durationProp)
        self.assertEqual(at.dateTimeProp, at2.dateTimeProp)
        self.assertEqual(at.dateTimeStampProp, at2.dateTimeStampProp)
        self.assertEqual(at.timeProp, at2.timeProp)
        self.assertEqual(at.dateProp, at2.dateProp)
        self.assertEqual(at.gYearMonthProp, at2.gYearMonthProp)
        self.assertEqual(at.gYearProp, at2.gYearProp)
        self.assertEqual(at.gMonthDayProp, at2.gMonthDayProp)
        self.assertEqual(at.gDayProp, at2.gDayProp)
        self.assertEqual(at.gMonthProp, at2.gMonthProp)
        self.assertEqual(at.hexBinaryProp, at2.hexBinaryProp)
        self.assertEqual(at.base64BinaryProp, at2.base64BinaryProp)
        self.assertEqual(at.anyURIProp, at2.anyURIProp)
        self.assertEqual(at.QNameProp, at2.QNameProp)
        self.assertEqual(at.normalizedStringProp, at2.normalizedStringProp)
        self.assertEqual(at.languageProp, at2.languageProp)
        self.assertEqual(at.nCNameProp, at2.nCNameProp)
        self.assertEqual(at.nMTOKENProp, at2.nMTOKENProp)
        self.assertEqual(at.iDProp, at2.iDProp)
        self.assertEqual(at.iDREFProp, at2.iDREFProp)
        self.assertEqual(at.integerProp, at2.integerProp)
        self.assertEqual(at.nonPositiveIntegerProp, at2.nonPositiveIntegerProp)
        self.assertEqual(at.negativeIntegerProp, at2.negativeIntegerProp)
        self.assertEqual(at.longProp, at2.longProp)
        self.assertEqual(at.intProp, at2.intProp)
        self.assertEqual(at.shortProp, at2.shortProp)
        self.assertEqual(at.byteProp, at2.byteProp)
        self.assertEqual(at.nonNegativeIntegerProp, at2.nonNegativeIntegerProp)
        self.assertEqual(at.negativeIntegerProp, at2.negativeIntegerProp)
        self.assertEqual(at.longProp, at2.longProp)
        self.assertEqual(at.intProp, at2.intProp)
        self.assertEqual(at.shortProp, at2.shortProp)
        self.assertEqual(at.byteProp, at2.byteProp)
        self.assertEqual(at.unsignedLongProp, at2.unsignedLongProp)
        self.assertEqual(at.unsignedIntProp, at2.unsignedIntProp)
        self.assertEqual(at.unsignedShortProp, at2.unsignedShortProp)
        self.assertEqual(at.unsignedByteProp, at2.unsignedByteProp)
        self.assertEqual(at.positiveIntegerProp, at2.positiveIntegerProp)

    def test_constructor_C(self):
        factory = ResourceInstanceFactory(con=self._con_tuser2, project='test')
        context = Context(name=self._con_tuser2.context_name)
        Book = factory.createObjectInstance('Book')

        b = Book(title="History of Time",
                 author=[Iri('test:AlbertEinstein', validate=False), Iri('test:JohnWick', validate=False)],
                 pubDate="1995-09-27")
        b.create()
        self.assertEqual(dict(b.attachedToRole), {Xsd_QName("oldap:Unknown"): DataPermission.DATA_UPDATE,
                                                  Xsd_QName("test:testNoUpdate"): DataPermission.DATA_VIEW})


        b.delete()

    def test_constructor_D(self):
        dm = DataModel.read(con=self._connection, project='test')
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        Cat = factory.createObjectInstance('Cat')

        mycat = Cat(name="Fluffy", subName="Fluffy the Cat")
        mycat.create()

    def test_create_from_shared(self):
        dm = DataModel.read(con=self._connection, project='test')
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        MO = factory.createObjectInstance('shared:MediaObject')
        mo = MO(originalName='Cat.tif',
                type='dcmitype:StillImage',
                originalMimeType='image/tiff',
                serverUrl='http://iiif.oldap.org/iiif/3/',
                assetId='cat.tif',
                path='test',
                protocol='iiif',
                derivativeName='iiif.tif',
                attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW})
        mo.create()
        data = ResourceInstance.read_data(con=self._connection, iri=mo.iri, projectShortName='test')
        self.assertEqual(data[Xsd_QName("oldap:attachedToRole")], {Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW})
        self.assertEqual(data[Xsd_QName("shared:originalName")], ['Cat.tif'])
        self.assertEqual(data[Xsd_QName("shared:originalMimeType")], ['image/tiff'])
        self.assertEqual(data[Xsd_QName("shared:serverUrl")], ['http://iiif.oldap.org/iiif/3/'])
        self.assertEqual(data[Xsd_QName("shared:assetId")], ['cat.tif'])
        self.assertEqual(data[Xsd_QName("shared:derivativeName")], ['iiif.tif'])
        mo.delete()

    def test_read_A(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        Book = factory.createObjectInstance('Book')
        b = Book(title="The Life and Times of Scrooge",
                 author="test:TuomasHolopainen",
                 pubDate="2001-01-01",
                 grantsPermission=Iri('oldap:GenericView'))
        b.create()
        data = ResourceInstance.read_data(con=self._connection, iri=b.iri, projectShortName='test')
        self.assertEqual(data['rdf:type'], ['test:Book'])
        self.assertEqual(data['test:title'], ['The Life and Times of Scrooge'])
        self.assertEqual(data['test:author'], ['test:TuomasHolopainen'])

        b.delete()

    def test_read_B(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        Book = factory.createObjectInstance('Book')
        b = Book(title="The Life and Times of Scrooge",
                 author="test:TuomasHolopainen",
                 pubDate="2001-01-01")
        b.create()
        bb = factory.read(iri=b.iri)
        self.assertEqual(bb.name, "test:Book")
        self.assertEqual(bb.title, {Xsd_string("The Life and Times of Scrooge")})
        self.assertEqual(bb.author, {Iri("test:TuomasHolopainen")})
        jsonobj = bb.toJsonObject()
        self.assertEqual(jsonobj['test:author'], ['test:TuomasHolopainen'])
        self.assertEqual(jsonobj['test:pubDate'], ['2001-01-01'])
        self.assertEqual(jsonobj['test:title'], ['The Life and Times of Scrooge'])

    def test_read_C(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        Book = factory.createObjectInstance('Book')
        b = Book(title="The Life and Times of Scrooge",
                 author="test:TuomasHolopainen",
                 pubDate="2001-01-01",
                 grantsPermission=Iri('oldap:GenericView'))
        b.create()
        bb = Book.read(con=self._connection, iri=b.iri)
        self.assertEqual(bb.name, "test:Book")
        self.assertEqual(bb.title, {Xsd_string("The Life and Times of Scrooge")})
        self.assertEqual(bb.author, {Iri("test:TuomasHolopainen")})
        jsonobj = bb.toJsonObject()
        self.assertEqual(jsonobj['test:author'], ['test:TuomasHolopainen'])
        self.assertEqual(jsonobj['test:pubDate'], ['2001-01-01'])
        self.assertEqual(jsonobj['test:title'], ['The Life and Times of Scrooge'])

        bb.delete()

    def test_read_D(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        b = SetterTester(stringSetter="This is a test string",
                         langStringSetter=["C'est un string de test@fr", "Dies ist eine Testzeichenkette@de"],
                         langStringSetter2=["gagagagag@de"],
                         decimalSetter=Xsd_decimal(3.14),
                         integerSetter={20200, 30300},
                         attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW})
        b.create()
        bb = SetterTester.read(con=self._connection, iri=b.iri)
        self.assertEqual(bb.name, "test:SetterTester")
        self.assertEqual(bb.stringSetter, {Xsd_string("This is a test string")})
        print(type(bb.langStringSetter).__name__)
        print(bb.langStringSetter)
        # self.assertEqual(bb.author, {Iri("test:TuomasHolopainen")})
        # jsonobj = bb.toJsonObject()
        # self.assertEqual(jsonobj['test:author'], ['test:TuomasHolopainen'])
        # self.assertEqual(jsonobj['test:pubDate'], ['2001-01-01'])
        # self.assertEqual(jsonobj['test:title'], ['The Life and Times of Scrooge'])

        bb.delete()

    def test_value_setter(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("This is a test string@de"),
                            langStringSetter2=LangString("This is a test string2@de"),
                            decimalSetter=Xsd_decimal(3.14),
                            integerSetter={20200, 30300},
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj2 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.stringSetter, obj2.stringSetter)
        self.assertEqual(obj1.langStringSetter, obj2.langStringSetter)
        self.assertIsNone(obj2.booleanSetter)
        self.assertEqual(obj1.decimalSetter, obj2.decimalSetter)
        self.assertEqual(obj1.integerSetter, obj2.integerSetter)

        #obj3 = SetterTester.read(con=self._connection, project='test', iri=obj1.iri)
        with self.assertRaises(OldapErrorValue):
            obj2.stringSetter = {"This is not a statement!", "One value too much"}
        with self.assertRaises(OldapErrorValue):
            obj2.langStringSetter = LangString("In Deutsch@de", "In Italiano@it")
        with self.assertRaises(OldapErrorValue):
            obj2.decimalSetter = {Xsd_decimal(3.14159), Xsd_decimal(2.71828), Xsd_decimal(1.61803), Xsd_decimal(1.0)}
        with self.assertRaises(OldapErrorValue):
            obj2.decimalSetter = None

        obj2.stringSetter = "This is not a statement!"
        obj2.langStringSetter = LangString("In Deutsch@de", "En Français@fr")
        obj2.booleanSetter = True
        obj2.decimalSetter = {Xsd_decimal(3.14159), Xsd_decimal(2.71828), Xsd_decimal(1.61803)}
        obj2.integerSetter = None
        self.assertEqual(obj2.stringSetter, {"This is not a statement!"})
        self.assertEqual(obj2.langStringSetter, LangString("In Deutsch@de", "En Français@fr"))
        self.assertTrue(obj2.booleanSetter)
        self.assertEqual(obj2.decimalSetter, {Xsd_decimal(3.14159), Xsd_decimal(2.71828), Xsd_decimal(1.61803)})
        self.assertFalse(obj2.integerSetter)

        expected_cs = {
            Iri("test:stringSetter"): AttributeChange(old_value={Xsd_string("This is a test string")}, action=Action.REPLACE),
            Iri("test:decimalSetter"): AttributeChange(old_value={Xsd_decimal(3.14)}, action=Action.REPLACE),
            Iri("test:langStringSetter"): AttributeChange(old_value=LangString("This is a test string@de"), action=Action.REPLACE),
            Iri("test:booleanSetter"): AttributeChange(old_value=None, action=Action.CREATE),
            Iri("test:integerSetter"): AttributeChange(old_value={20200, 30300}, action=Action.DELETE)}
        self.assertEqual(obj2.changeset, expected_cs)

        obj2.update()
        obj2 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj2.stringSetter, {"This is not a statement!"})
        self.assertEqual(obj2.langStringSetter, LangString("In Deutsch@de", "En Français@fr"))
        self.assertTrue(obj2.booleanSetter)
        self.assertEqual(obj2.decimalSetter, {Xsd_decimal(3.14159), Xsd_decimal(2.71828), Xsd_decimal(1.61803)})
        self.assertFalse(obj2.integerSetter)

        obj2.delete()

    def test_value_modifier_A(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr", "Dies ist eine Test-Zeichenkette@de"),
                            langStringSetter2=LangString("C'est un teste2@fr", "Dies ist eine Test-Zeichenkette2@de"),
                            decimalSetter=Xsd_decimal(3.14),
                            integerSetter={-10, 20},
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        obj1.langStringSetter[Language.FR] = "Qu'est-ce que c'est?"
        obj1.integerSetter.add(42)
        obj1.integerSetter.discard(-10)
        obj1.booleanSetter = False
        with self.assertRaises(OldapErrorValue):
            obj1.stringSetter.pop()
        with self.assertRaises(OldapErrorValue):
            del obj1.stringSetter
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.stringSetter, {"This is a test string"})
        self.assertEqual(obj1.langStringSetter, LangString("Dies ist eine Test-Zeichenkette@de", "Qu'est-ce que c'est?@fr"))
        self.assertEqual(obj1.integerSetter, {Xsd_int(20), Xsd_int(42)})
        self.assertFalse(obj1.booleanSetter)

        obj1.delete()

    def test_value_modifier_B(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr", "Dies ist eine Test-Zeichenkette@de"),
                            langStringSetter2=LangString("C'est un teste2@fr", "Dies ist eine Test-Zeichenkette2@de"),
                            decimalSetter=Xsd_decimal(3.14),
                            integerSetter={-10, 20},
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        obj1[Xsd_QName('test:langStringSetter')][Language.FR] = "Qu'est-ce que c'est?"
        obj1[Xsd_QName('test:integerSetter')].add(42)
        obj1[Xsd_QName('test:integerSetter')].discard(-10)
        obj1[Xsd_QName('test:booleanSetter')] = False
        with self.assertRaises(OldapErrorValue):
            obj1[Xsd_QName('test:stringSetter')].pop()
        with self.assertRaises(OldapErrorValue):
            del obj1[Xsd_QName('test:stringSetter')]
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.stringSetter, {"This is a test string"})
        self.assertEqual(obj1.langStringSetter, LangString("Dies ist eine Test-Zeichenkette@de", "Qu'est-ce que c'est?@fr"))
        self.assertEqual(obj1.integerSetter, {Xsd_int(20), Xsd_int(42)})
        self.assertFalse(obj1.booleanSetter)

        obj1.delete()

    def test_value_modifier_C(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr", "Dies ist eine Test-Zeichenkette@de"),
                            langStringSetter2=LangString("C'est un teste2@fr", "Dies ist eine Test-Zeichenkette2@de"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        obj1[Xsd_QName('test:integerSetter')] = [1]
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.integerSetter, {Xsd_int(1)})

    def test_value_modifier_D(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr"),
                            langStringSetter2=LangString("C'est un teste2@fr"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        obj1[Xsd_QName('test:langStringSetter')][Language.FR] = "Qu'est-ce que c'est?"
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.langStringSetter, LangString("Qu'est-ce que c'est?@fr"))


    def test_value_modifier_add_lang(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr"),
                            langStringSetter2=LangString("C'est un teste2@fr"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        obj1[Xsd_QName('test:langStringSetter')].add("Dies ist eine Test-Zeichenkette@de")
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.langStringSetter, LangString("C'est un teste@fr", "Dies ist eine Test-Zeichenkette@de"))

    def test_value_modifier_remove_lang_A(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("Waseliwas@de", "C'est un teste@fr"),
                            langStringSetter2=LangString("Waseliwas2@de", "C'est un teste2@fr"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        del obj1[Xsd_QName('test:langStringSetter')]['de']
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.langStringSetter, LangString("C'est un teste@fr"))

    def test_value_modifier_remove_lang_B(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("Waseliwas@de", "C'est un teste@fr"),
                            langStringSetter2=LangString("Waseliwas2@de", "C'est un teste2@fr"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        obj1[Xsd_QName('test:langStringSetter')].remove(Language.DE)
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.langStringSetter, LangString("C'est un teste@fr"))

    def test_value_modifier_remove_lang_D(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("Waseliwas@de", "C'est un teste@fr"),
                            langStringSetter2=LangString("Waseliwas2@de", "C'est un teste2@fr"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        obj1[Xsd_QName('test:langStringSetter')].discard(Language.EN)
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.langStringSetter, LangString("Waseliwas@de", "C'est un teste@fr"))

        with self.assertRaises(OldapErrorKey):
            obj1[Xsd_QName('test:langStringSetter')].remove(Language.EN)

    def test_value_modifier_replace(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr"),
                            langStringSetter2=LangString("C'est un teste2@fr"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1[Xsd_QName('test:langStringSetter')] = LangString("FRANCAIS@fr", "DEUTSCH@de")
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertEqual(obj1.langStringSetter, LangString("FRANCAIS@fr", "DEUTSCH@de"))


    def test_value_modifier_delete_A(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr"),
                            langStringSetter2=LangString("C'est un teste2@fr"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            integerSetter={20200, 30300},
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        obj1[Xsd_QName('test:integerSetter')] = None
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertIsNone(obj1.integerSetter)

    def test_value_modifier_delete_B(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr"),
                            langStringSetter2=LangString("C'est un teste2@fr"),
                            decimalSetter=Xsd_decimal(3.14),
                            booleanSetter=True,
                            integerSetter={20200, 30300},
                            grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        obj1.create()
        del obj1[Xsd_QName('test:integerSetter')]
        obj1.update()
        obj1 = SetterTester.read(con=self._connection, iri=obj1.iri)
        self.assertIsNone(obj1.integerSetter)

    def test_value_maxcount_mincount(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        Person = factory.createObjectInstance('Person')
        p = Person(familyName="Müller",
                   givenName="Max",
                   grantsPermission={Iri('oldap:GenericView'), Iri('oldap:GenericUpdate')})
        p.create()

        obj1 = Person.read(con=self._connection,
                           iri=p.iri)
        with self.assertRaises(OldapErrorValue):
            obj1.familyName.add("Meier")
        with self.assertRaises(OldapErrorValue):
            obj1.givenName.discard("Max")
        with self.assertRaises(OldapErrorValue):
            del obj1.familyName

        obj1.delete()

    def test_value_modifier_norights(self):
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj1 = SetterTester(stringSetter="This is a test string",
                            langStringSetter=LangString("C'est un teste@fr", "Dies ist eine Test-Zeichenkette@de"),
                            langStringSetter2=LangString("C'est un teste2@fr", "Dies ist eine Test-Zeichenkette2@de"),
                            decimalSetter={Xsd_decimal(3.14159), Xsd_decimal(2.71828), Xsd_decimal(1.61803)},
                            integerSetter={-10, 20},
                            booleanSetter=True,
                            attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW,
                                            self._tps.iri.as_qname: DataPermission.DATA_VIEW})
        obj1.create()

        unpriv = Connection(userId="factorytestuser",
                            credentials="Waseliwas",
                            context_name="DEFAULT")
        factory = ResourceInstanceFactory(con=unpriv, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj = SetterTester.read(con=unpriv, iri=obj1.iri)
        self.assertEqual(obj.stringSetter, {"This is a test string"})
        self.assertEqual(obj.langStringSetter, LangString("C'est un teste@fr", "Dies ist eine Test-Zeichenkette@de"))
        self.assertTrue(obj.booleanSetter)
        self.assertEqual(obj.decimalSetter, {Xsd_decimal(3.14159), Xsd_decimal(2.71828), Xsd_decimal(1.61803)})
        self.assertEqual(obj.integerSetter, {-10, 20})

        unpriv2 = Connection(userId="factorytestuser2",
                            credentials="Waseliwas2",
                            context_name="DEFAULT")
        factory = ResourceInstanceFactory(con=unpriv2, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj = SetterTester.read(con=unpriv2, iri=obj1.iri)
        obj.decimalSetter.discard(Xsd_decimal(3.14159))
        with self.assertRaises(OldapErrorNoPermission):
            obj.update()

        factory = ResourceInstanceFactory(con=self._connection, project='test')
        SetterTester = factory.createObjectInstance('SetterTester')
        obj = SetterTester.read(con=self._connection, iri=obj1.iri)
        obj.delete()

    def test_delete_resource(self):
        project = Project.read(con=self._connection, projectIri_SName='test')
        factory = ResourceInstanceFactory(con=self._connection, project=project)
        Book = factory.createObjectInstance('Book')
        b = Book(title="Hitchhiker's Guide to the Galaxy",
                 author=Iri('test:DouglasAdams', validate=False),
                 pubDate="1995-09-27",
                 attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW})
        b.create()
        b = Book.read(con=self._connection,
                       iri=b.iri)
        Page = factory.createObjectInstance('Page')
        p1 = Page(pageDesignation="Cover",
                  pageNum=1,
                  pageDescription=LangString("Cover page of book@en", "Vorderseite des Bucheinschlags@de"),
                  pageInBook=b.iri,
                  attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW})
        p1.create()

        with self.assertRaises(OldapErrorInUse):
            b.delete()

        p1.delete()
        with self.assertRaises(OldapErrorNotFound):
            Page.read(con=self._connection,
                    iri=p1.iri)
        b.delete()
        with self.assertRaises(OldapErrorNotFound):
            b = Book.read(con=self._connection,
                          iri=b.iri)

    def test_change_permissions_A(self):
        project = Project.read(con=self._connection, projectIri_SName='test')

        ps = Role(con=self._connection,
                  roleId="testChangePermission",
                  label=LangString("testChangePermission@en"),
                  comment=LangString("Testing PermissionSet@en"),
                  definedByProject="test")
        ps.create()

        factory = ResourceInstanceFactory(con=self._connection, project=project)
        Book = factory.createObjectInstance('Book')

        b = Book(title="Hitchhiker's Guide to the Galaxy",
                 author=Iri('test:DouglasAdams', validate=False),
                 pubDate="1995-09-27",
                 attachedToRole={Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW})
        b.create()
        b = Book.read(con=self._connection,
                      iri=b.iri)
        b.attachedToRole[Xsd_QName('hyha:HyperHamletMember')] = DataPermission.DATA_UPDATE
        b.update()

        b = Book.read(con=self._connection,iri=b.iri)
        self.assertEqual(dict(b.attachedToRole), {Xsd_QName('oldap:Unknown'): DataPermission.DATA_VIEW,
                                            Xsd_QName('hyha:HyperHamletMember'): DataPermission.DATA_UPDATE})

        unpriv = Connection(userId="factorytestuser",
                            credentials="Waseliwas",
                            context_name="DEFAULT")
        factory = ResourceInstanceFactory(con=unpriv, project=project)
        Book = factory.createObjectInstance('Book')
        b = Book.read(con=self._connection,
                      iri=b.iri)
        b.attachedToRole['oldap:Unknown'] = DataPermission.DATA_UPDATE
        with self.assertRaises(OldapErrorNoPermission):
            b.update()

        with self.assertRaises(OldapErrorNoPermission):
            b.delete()

        factory = ResourceInstanceFactory(con=self._connection, project=project)
        Book = factory.createObjectInstance('Book')
        b = Book.read(con=self._connection,
                      iri=b.iri)
        b.delete()

    def test_search_resource_A(self):
        res = ResourceInstance.search_fulltext(con=self._connection,
                                               projectShortName='test',
                                               resClass='test:Book',
                                               searchstr='geschichte',
                                               sortBy=[SortBy('oldap:creationDate', SortDir.desc)])

        self.assertEqual(len(res), 2)
        for x, y in res.items():
            self.assertEqual(y[Xsd_QName("owl:Class")], Xsd_QName('test:Book'))

        res = ResourceInstance.search_fulltext(con=self._connection,
                                               projectShortName='test',
                                               searchstr='spez',
                                               sortBy=[SortBy('oldap:creationDate', SortDir.desc)])

        self.assertEqual(len(res), 5)
        for x, y in res.items():
            self.assertTrue(y[Xsd_QName("owl:Class")] in {Xsd_QName('test:Book'), Xsd_QName('test:Page')})

    def test_search_resource_B(self):
        res = ResourceInstance.all_resources(con=self._connection,
                                             projectShortName='test',
                                             resClass='test:Sort',
                                             includeProperties=[Xsd_QName('test:aString'), Xsd_QName('test:aLangstring')],
                                             sortBy = [SortBy(Xsd_QName('oldap:creationDate'), SortDir.asc)])
        self.assertEqual(len(res), 3)
        self.assertEqual(res[0]['iri'][0], Xsd_QName('test:Item1'))
        self.assertEqual(res[1]['iri'][0], Xsd_QName('test:Item2'))
        self.assertEqual(res[2]['iri'][0], Xsd_QName('test:Item3'))

        for r in res:
            self.assertIsNotNone(r[Xsd_QName('oldap:creationDate')])
            self.assertIsNotNone(r[Xsd_QName('test:aString')])
            self.assertIsNotNone(r[Xsd_QName('test:aLangstring')])

    def test_search_resource_C(self):
        res = ResourceInstance.all_resources(con=self._connection,
                                             projectShortName='test',
                                             resClass='test:Sort',
                                             includeProperties=[Xsd_QName('test:aString'), Xsd_QName('test:aLangstring')],
                                             sortBy = [SortBy(Xsd_QName('test:aString'), SortDir.asc)])
        self.assertEqual(len(res), 3)
        self.assertEqual(res[0]['iri'][0], Xsd_QName('test:Item1'))
        self.assertEqual(res[1]['iri'][0], Xsd_QName('test:Item2'))
        self.assertEqual(res[2]['iri'][0], Xsd_QName('test:Item3'))

    def test_search_resource_D(self):
        res = ResourceInstance.all_resources(con=self._connection,
                                             projectShortName='test',
                                             resClass='test:Sort',
                                             includeProperties=[Xsd_QName('test:aString'), Xsd_QName('test:aLangstring')],
                                             sortBy = [SortBy(Xsd_QName('test:aLangstring'), SortDir.asc)])
        self.assertEqual(len(res), 3)
        self.assertEqual(res[0]['iri'][0], Xsd_QName('test:Item2'))
        self.assertEqual(res[1]['iri'][0], Xsd_QName('test:Item3'))
        self.assertEqual(res[2]['iri'][0], Xsd_QName('test:Item1'))

    def test_search_resource_E(self):
        res = ResourceInstance.all_resources(con=self._connection,
                                             projectShortName='test',
                                             resClass='test:Sort',
                                             sortBy = [SortBy(Xsd_QName('test:anInteger'), SortDir.desc)])
        self.assertEqual(len(res), 3)
        self.assertEqual(res[0]['iri'][0], Xsd_QName('test:Item2'))
        self.assertEqual(res[0][Xsd_QName('test:anInteger')], [Xsd_integer(300)])
        self.assertEqual(res[1]['iri'][0], Xsd_QName('test:Item3'))
        self.assertEqual(res[1][Xsd_QName('test:anInteger')], [Xsd_integer(200)])
        self.assertEqual(res[2]['iri'][0], Xsd_QName('test:Item1'))
        self.assertEqual(res[2][Xsd_QName('test:anInteger')], [Xsd_integer(100)])

    #@unittest.skip('Work in progress')
    def test_read_media_object_by_id_A(self):
        res = ResourceInstance.get_media_object_by_id(con=self._connection, mediaObjectId='x_34db.tif')
        self.assertEqual(res['iri'], Iri("urn:uuid:1b8e3f42-6d7a-4c9b-a3f8-93c2e5d7b901"))
        self.assertEqual(res['permval'], Xsd_integer(2))
        self.assertEqual(res['shared:assetId'], Xsd_string('x_34db.tif'))
        self.assertEqual(res['shared:originalName'], Xsd_string("testfile.tif"))
        self.assertEqual(res['shared:originalMimeType'], Xsd_string("image/tiff"))
        self.assertEqual(res['shared:serverUrl'], Xsd_string("https://iiif.oldap.org"))
        self.assertEqual(res['shared:protocol'], Xsd_string("iiif"))
        self.assertEqual(res['graph'], Xsd_QName("test:data"))
        self.assertEqual(res['shared:path'], Xsd_string("test/subtest"))
        tinfo = jwt.decode(jwt=res['token'], key=self._connection.jwtkey, algorithms="HS256")
        self.assertEqual(tinfo['id'], 'x_34db.tif')
        self.assertEqual(tinfo['path'], 'test/subtest')
        self.assertEqual(tinfo['permval'], 2)
        self.assertEqual(tinfo['assetId'], 'x_34db.tif')

    def test_read_media_object_by_id_B(self):
        res = ResourceInstance.get_media_object_by_id(con=self._connection, mediaObjectId='x_42db.jpg')
        self.assertEqual(res['iri'], Iri("urn:uuid:1b8e3f42-6d7a-4c9b-a3f8-93c2e5d7b999"))
        self.assertEqual(res['permval'], Xsd_integer(2))
        self.assertEqual(res['shared:assetId'], Xsd_string('x_42db.jpg'))
        self.assertEqual(res['shared:originalName'], Xsd_string("testfile.jpg"))
        self.assertEqual(res['shared:originalMimeType'], Xsd_string("image/jpeg"))
        self.assertEqual(res['shared:serverUrl'], Xsd_string("https://iiif.oldap.org"))
        self.assertEqual(res['shared:protocol'], Xsd_string("iiif"))
        self.assertEqual(res['graph'], Xsd_QName("test:data"))
        self.assertEqual(res['test:caption'], [Xsd_string("This is a non-real, non-existing image")])
        self.assertEqual(res['shared:path'], Xsd_string("test/subtest"))
        tinfo = jwt.decode(jwt=res['token'], key=self._connection.jwtkey, algorithms="HS256")
        self.assertEqual(tinfo['id'], 'x_42db.jpg')
        self.assertEqual(tinfo['path'], 'test/subtest')
        self.assertEqual(tinfo['permval'], 2)
        self.assertEqual(tinfo['assetId'], 'x_42db.jpg')

    def test_read_media_object_by_id_C(self):
        with self.assertRaises(OldapErrorNotFound):
            res = ResourceInstance.get_media_object_by_id(con=self._unpriv, mediaObjectId='Hlon4w5TSplO.tif')

    def test_read_media_object_by_iri_A(self):
        res = ResourceInstance.get_media_object_by_iri(con=self._connection, mediaObjectIri='urn:uuid:1b8e3f42-6d7a-4c9b-a3f8-93c2e5d7b901')
        self.assertEqual(res['iri'], Iri("urn:uuid:1b8e3f42-6d7a-4c9b-a3f8-93c2e5d7b901"))
        self.assertEqual(res['permval'], Xsd_integer(2))
        self.assertEqual(res['shared:assetId'], Xsd_string('x_34db.tif'))
        self.assertEqual(res['shared:originalName'], Xsd_string("testfile.tif"))
        self.assertEqual(res['shared:originalMimeType'], Xsd_string("image/tiff"))
        self.assertEqual(res['shared:serverUrl'], Xsd_string("https://iiif.oldap.org"))
        self.assertEqual(res['shared:protocol'], Xsd_string("iiif"))
        self.assertEqual(res['graph'], Xsd_QName("test:data"))
        self.assertEqual(res['shared:path'], Xsd_string("test/subtest"))
        tinfo = jwt.decode(jwt=res['token'], key=self._connection.jwtkey, algorithms="HS256")
        self.assertEqual(tinfo['id'], 'x_34db.tif')
        self.assertEqual(tinfo['path'], 'test/subtest')
        self.assertEqual(tinfo['permval'], 2)
        self.assertEqual(tinfo['assetId'], 'x_34db.tif')

    def test_read_media_object_by_iri_B(self):
        res = ResourceInstance.get_media_object_by_iri(con=self._connection, mediaObjectIri='urn:uuid:1b8e3f42-6d7a-4c9b-a3f8-93c2e5d7b999')
        self.assertEqual(res['iri'], Iri("urn:uuid:1b8e3f42-6d7a-4c9b-a3f8-93c2e5d7b999"))
        self.assertEqual(res['permval'], Xsd_integer(2))
        self.assertEqual(res['shared:assetId'], Xsd_string('x_42db.jpg'))
        self.assertEqual(res['shared:originalName'], Xsd_string("testfile.jpg"))
        self.assertEqual(res['shared:originalMimeType'], Xsd_string("image/jpeg"))
        self.assertEqual(res['shared:serverUrl'], Xsd_string("https://iiif.oldap.org"))
        self.assertEqual(res['shared:protocol'], Xsd_string("iiif"))
        self.assertEqual(res['graph'], Xsd_QName("test:data"))
        self.assertEqual(res['test:caption'], [Xsd_string("This is a non-real, non-existing image")])
        self.assertEqual(res['shared:path'], Xsd_string("test/subtest"))
        tinfo = jwt.decode(jwt=res['token'], key=self._connection.jwtkey, algorithms="HS256")
        self.assertEqual(tinfo['id'], 'x_42db.jpg')
        self.assertEqual(tinfo['path'], 'test/subtest')
        self.assertEqual(tinfo['permval'], 2)
        self.assertEqual(tinfo['assetId'], 'x_42db.jpg')


    def test_create_media_object(self):
        dm = DataModel.read(con=self._connection, project='test')
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        MLE = factory.createObjectInstance('test:MediaLibraryEntry')
        mle = MLE(originalName='MyCarnivalImagetif',
                  type='dcmitype:StillImage',
                  originalMimeType='image/tiff',
                  assetId='x_34dbY4.tif',
                  serverUrl='http://iiif.oldap.org/iiif/3/',
                  path='test/subtest',
                  protocol='iiif',
                  derivativeName='iiif.tif',
                  caption='My Carnival Image of 1968 with the Bohrerhof-Clique',
                  grantsPermission=Iri('oldap:GenericView'))
        mle.create()
        data = ResourceInstance.read_data(con=self._connection, iri=mle.iri, projectShortName='test')
        self.assertEqual(data['shared:originalName'], ["MyCarnivalImagetif"])
        self.assertEqual(data['shared:originalMimeType'], ['image/tiff'])
        self.assertEqual(data['shared:serverUrl'], ['http://iiif.oldap.org/iiif/3/'])
        self.assertEqual(data['shared:assetId'], ['x_34dbY4.tif'])
        self.assertEqual(data['shared:protocol'], ['iiif'])
        self.assertEqual(data['shared:derivativeName'], ['iiif.tif'])
        self.assertEqual(data['shared:path'], ['test/subtest'])
        self.assertEqual(data['test:caption'], ['My Carnival Image of 1968 with the Bohrerhof-Clique'])


        data2 = ResourceInstance.get_media_object_by_id(con=self._connection, mediaObjectId='x_34dbY4.tif')
        self.assertEqual(data2['shared:originalName'], "MyCarnivalImagetif")
        self.assertEqual(data2['shared:originalMimeType'], 'image/tiff')
        self.assertEqual(data2['shared:serverUrl'], 'http://iiif.oldap.org/iiif/3/')
        self.assertEqual(data2['shared:protocol'], 'iiif')
        self.assertEqual(data2['shared:path'], 'test/subtest')
        mle.delete()

    def test_create_location(self):
        dm = DataModel.read(con=self._connection, project='test')
        factory = ResourceInstanceFactory(con=self._connection, project='test')
        Location = factory.createObjectInstance('test:Location')
        loc = Location(loc=Geo_wktLiteral("POLYGON((7.540 47.545, 7.560 47.545, 7.560 47.555, 7.540 47.555, 7.540 47.545))"))
        loc.create()
        iri = loc.iri
        loc2 = Location.read(con=self._connection, iri=iri)
        self.assertEqual(loc2.loc, Geo_wktLiteral("POLYGON((7.540 47.545, 7.560 47.545, 7.560 47.555, 7.540 47.555, 7.540 47.545))"))
        loc.delete()

if __name__ == '__main__':
    unittest.main()
