"""Build metadata written by CI before packaging."""

BUILD_GIT_SHA = "5afb91f42f25210c4eb4ab83a92c1ae6307638aa"
BUILD_DATE = "2026-03-12T23:42:43Z"
