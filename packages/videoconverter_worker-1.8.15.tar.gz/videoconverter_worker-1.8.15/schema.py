# -*- coding: utf-8 -*-
"""任务队列输入格式说明，供对接方参考。可通过 videoconverter --show-schema 查看。"""

INPUT_SCHEMA = r"""# 任务队列输入格式（如何「喂数据」给 Worker）

## 目录结构

- 数据目录（默认 ~/.videoconverter/data，可用 --data-dir 指定）
  - queue/                    必选，存放任务
    - <task_id>.json          每个任务一个文件，文件名=task_id.json
    - <task_id>.lock          运行时抢占锁，勿手动编辑
  - queue_config.json         可选，队列暂停等配置

## 单任务文件 queue/<task_id>.json

根级字段:
  task_id          string   必填，与文件名一致（如 a1b2c3d4-e5f6-7890-abcd-ef1234567890.json）
  task_type        string   必填，取值: SPLIT | DESUBTITLE | MERGE | ONE_CLICK_COMPOSE
  parent_task_id   string   可选
  video_id         string   可选，同一视频/一键合成流程 ID（MERGE 必填）
  input_file       string   必填（MERGE 可为空串），输入视频或 chunk 的绝对路径
  output_dir       string   必填，输出目录（绝对路径）
  config           object   必填，见下
  status           string   必填，新建任务填 PENDING
  progress         number   默认 0
  progress_text    string   可选
  created_time     number   必填，毫秒时间戳
  error_message    string   可选

任务类型说明:
  SPLIT              输入整段视频，按 config.startTime/endTime 切分为 chunk，写入 output_dir 并生成 metadata.json；Worker 会自动创建各 chunk 的 DESUBTITLE 任务。
  DESUBTITLE         输入单个 chunk 文件，去字幕后写入 output_dir/<video_id>/xxx_desub.mp4，并更新 metadata；全部完成后 Worker 会自动创建 MERGE 任务。
  MERGE              依赖 output_dir/<video_id>/metadata.json（由 SPLIT 生成、DESUBTITLE 更新），将已处理的 chunk 合成为最终视频。需填 video_id、output_dir，input_file 可空。
  ONE_CLICK_COMPOSE  与 SPLIT 类似：输入整段视频 + startTime/endTime，切分后自动创建所有 DESUBTITLE 任务（不自动建 SPLIT 子任务名，仅建去字幕任务），后续 MERGE 由 Worker 在全部去字幕后自动创建。

路径: 建议使用本机绝对路径；若队列从别处拷贝而来，启动时用 --path-replace "原前缀=本机前缀" 做替换。

config 对象常用字段:
  targetWidth/targetHeight  默认 1920/1080
  cropTop/cropBottom/cropLeft/cropRight  裁剪（如去字幕 208）
  keepAudio, audioBitrate, videoQuality
  startTime, endTime  截取时间（秒）
  inputPath, outputPath  Worker 会按需填充

## queue_config.json（可选）

{ "queue_paused": "true" }  表示暂停，不取新任务；"false" 表示运行。

## 示例：新建一个去字幕任务

在数据目录下创建 queue/<uuid>.json，例如:

{
  "task_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "task_type": "DESUBTITLE",
  "video_id": "my-video-id",
  "input_file": "/path/to/chunk_001.mp4",
  "output_dir": "/path/to/output",
  "config": {
    "targetWidth": 1920,
    "targetHeight": 1080,
    "cropBottom": 208,
    "cropLeft": 293,
    "cropRight": 293,
    "keepAudio": true,
    "videoQuality": 23
  },
  "status": "PENDING",
  "progress": 0,
  "created_time": 1738828800000
}

然后启动: videoconverter --data-dir /path/to/data

Worker 会按 created_time 顺序抢占 status=PENDING 的任务并执行。

## 示例：切分+去字幕流程（SPLIT 或 ONE_CLICK_COMPOSE）

新建一个 SPLIT 任务（或 ONE_CLICK_COMPOSE），Worker 会先切分再自动创建各 chunk 的去字幕任务，全部去字幕后自动创建 MERGE 并合成:

{
  "task_id": "b2c3d4e5-f6a7-8901-bcde-f23456789012",
  "task_type": "SPLIT",
  "input_file": "/path/to/full_video.mp4",
  "output_dir": "/path/to/output",
  "config": {
    "startTime": 0,
    "endTime": 3600,
    "targetWidth": 1920,
    "targetHeight": 1080,
    "cropBottom": 208,
    "cropLeft": 293,
    "cropRight": 293
  },
  "status": "PENDING",
  "progress": 0,
  "created_time": 1738828800000
}

注意: MERGE 任务一般由 Worker 在「该 video_id 下所有 DESUBTITLE 完成」后自动创建，无需手写；若需手写 MERGE，则 video_id、output_dir 必填，且 output_dir/<video_id>/metadata.json 已存在且所有 chunk 已标记为已处理。
"""
