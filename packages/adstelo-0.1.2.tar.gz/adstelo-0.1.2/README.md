# Adstelo Python SDK

The official Adstelo Python SDK for integrating your Telegram bots with Adstelo.

## Installation

```bash
pip install adstelo
```

## Usage

```python
import adstelo

adstelo.init(bot_token="YOUR_BOT_TOKEN", api_key="YOUR_API_KEY")
```

Supports all major Python Telegram bot frameworks:
- `aiogram`
- `python-telegram-bot`
- `Telethon`
- `telebot` (`pyTelegramBotAPI`)
