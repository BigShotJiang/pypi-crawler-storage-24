from .aiogram_patch import patch_aiogram
from .ptb_patch import patch_ptb
from .telethon_patch import patch_telethon
from .telebot_patch import patch_telebot
from .reporter import report_event, configure as _configure_reporter
from .limiter import configure as _configure_limiter


_initialized = False


def init(bot_token, api_key=None, cooldown=None):
    """
    Initialise the Adstelo rumour-monger SDK.

    Automatically detects and patches every installed Telegram bot library:
      - aiogram (v3)
      - python-telegram-bot (v20+ async)
      - Telethon
      - pyTelegramBotAPI / telebot (sync & async)

    Parameters
    ----------
    bot_token : str
        The Telegram bot token. This runs the SDK for this specific bot.
    api_key : str, optional
        API key sent as the X-Api-Key request header.
    cooldown : int | float, optional
        Per-user event cooldown in seconds (default: 2).
        Prevents duplicate events for rapid-fire interactions.

    Example
    -------
    import adstelo
    adstelo.init(api_key="sk-...")
    """
    global _initialized

    if _initialized:
        return

    # Apply configuration
    _configure_reporter(bot_token=bot_token, api_key=api_key)

    if cooldown is not None:
        _configure_limiter(cooldown=cooldown)

    # Patch every available library — each call is import-safe and
    # silently no-ops if the library is not installed.
    patch_aiogram(report_event)
    patch_ptb(report_event)
    patch_telethon(report_event)
    patch_telebot(report_event)

    _initialized = True