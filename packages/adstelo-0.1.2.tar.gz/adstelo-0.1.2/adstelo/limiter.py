import time

# Key: (user_id, event_type) — each event type has its own cooldown bucket
# per user so that e.g. a recent message doesn't block a callback_query.
_last_seen: dict[tuple[int, str], float] = {}

_cooldown = 2


def configure(cooldown):
    global _cooldown
    _cooldown = cooldown


def allow(user_id, event_type="message"):

    now = time.time()
    key = (user_id, event_type)

    prev = _last_seen.get(key, 0)

    if now - prev < _cooldown:
        return False

    _last_seen[key] = now

    return True