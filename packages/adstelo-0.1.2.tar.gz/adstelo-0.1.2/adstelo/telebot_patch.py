"""
pyTelegramBotAPI (telebot) patch — supports both:
  - telebot.TeleBot        (synchronous)
  - telebot.async_telebot.AsyncTeleBot  (async)

Wraps process_new_updates() in both variants.
"""
import threading

from .limiter import allow

_original_sync_process = None
_original_async_process = None


def patch_telebot(report_func):
    """
    Call this to patch pyTelegramBotAPI (telebot).
    Safe to call if telebot is not installed — silently skips.
    """
    _patch_sync(report_func)
    _patch_async(report_func)


# ─── Sync (TeleBot) ──────────────────────────────────────────────────────────

def _patch_sync(report_func):

    try:
        import telebot
    except ImportError:
        return

    global _original_sync_process

    _original_sync_process = telebot.TeleBot.process_new_updates

    def patched_sync_process(self, updates):

        for update in updates:
            try:
                _handle_telebot_update(update, report_func, is_async=False)
            except Exception:
                pass

        return _original_sync_process(self, updates)

    telebot.TeleBot.process_new_updates = patched_sync_process


# ─── Async (AsyncTeleBot) ────────────────────────────────────────────────────

def _patch_async(report_func):

    try:
        from telebot.async_telebot import AsyncTeleBot
    except ImportError:
        return

    global _original_async_process

    _original_async_process = AsyncTeleBot.process_new_updates

    async def patched_async_process(self, updates):

        for update in updates:
            try:
                _handle_telebot_update(update, report_func, is_async=True)
            except Exception:
                pass

        return await _original_async_process(self, updates)

    AsyncTeleBot.process_new_updates = patched_async_process


# ─── Shared handler ───────────────────────────────────────────────────────────

def _handle_telebot_update(update, report, is_async=False):

    def fire(chat_id, user_id, event, is_start=False):
        if is_async:
            report(chat_id=chat_id, user_id=user_id, event=event, is_start=is_start)
        else:
            threading.Thread(
                target=report,
                kwargs={"chat_id": chat_id, "user_id": user_id, "event": event, "is_start": is_start},
                daemon=True
            ).start()

    # ── Callback query first ──────────────────────────────────────────────────
    if update.callback_query:
        cb = update.callback_query
        user_id = cb.from_user.id
        chat_id = cb.message.chat.id if cb.message else user_id

        if allow(user_id, "button"):
            fire(chat_id=chat_id, user_id=user_id, event="button")

        return

    # ── Regular message ───────────────────────────────────────────────────────
    if update.message:
        msg = update.message
        user = msg.from_user

        if not user:
            return

        is_start = False
        if msg.text and msg.text.startswith("/start"):
            is_start = True
            event = "message"
        elif msg.photo:
            event = "photo"
        elif msg.video:
            event = "video"
        elif msg.sticker:
            event = "sticker"
        else:
            event = "message"

        if allow(user.id, event):
            fire(chat_id=msg.chat.id, user_id=user.id, event=event, is_start=is_start)
