"""
python-telegram-bot v20+ (async) patch.

Wraps Application.process_update to intercept all incoming updates
before they reach the bot's own handlers. Zero impact on existing logic.
"""
from .limiter import allow

_original_process_update = None


def patch_ptb(report_func):
    """
    Call this to patch python-telegram-bot v20+.
    Safe to call even if PTB is not installed — silently skips.
    """
    try:
        from telegram.ext import Application
    except ImportError:
        return

    global _original_process_update

    _original_process_update = Application.process_update

    async def patched_process_update(self, update, *args, **kwargs):

        try:
            _handle_ptb_update(update, report_func)
        except Exception:
            pass

        return await _original_process_update(self, update, *args, **kwargs)

    Application.process_update = patched_process_update


def _handle_ptb_update(update, report):

    # ── Callback query (inline button press) ─────────────────────────────────
    if update.callback_query:
        cb = update.callback_query
        user_id = cb.from_user.id
        chat_id = cb.message.chat_id if cb.message else user_id

        if allow(user_id, "button"):
            report(chat_id=chat_id, user_id=user_id, event="button")

        return

    # ── Regular message ───────────────────────────────────────────────────────
    if update.message:
        msg = update.message
        user = msg.from_user

        if not user:
            return

        is_start = False
        if msg.text and msg.text.startswith("/start"):
            is_start = True
            event = "message"
        elif msg.photo:
            event = "photo"
        elif msg.video:
            event = "video"
        elif msg.sticker:
            event = "sticker"
        else:
            event = "message"

        if allow(user.id, event):
            report(
                chat_id=msg.chat_id, 
                user_id=user.id, 
                event=event, 
                is_start=is_start
            )

        return

    # ── Inline query ──────────────────────────────────────────────────────────
    if update.inline_query:
        iq = update.inline_query
        user_id = iq.from_user.id

        if allow(user_id, "inline_query"):
            report(chat_id=user_id, user_id=user_id, event="inline_query")
