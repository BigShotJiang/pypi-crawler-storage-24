"""
Telethon patch.

Wraps TelegramClient._dispatch_update to intercept incoming events
before they reach any registered Telethon event handlers.
Zero impact on existing logic.
"""
from .limiter import allow

_original_dispatch_update = None


def patch_telethon(report_func):
    """
    Call this to patch Telethon's TelegramClient.
    Safe to call if Telethon is not installed — silently skips.
    """
    try:
        from telethon import TelegramClient
    except ImportError:
        return

    global _original_dispatch_update

    _original_dispatch_update = TelegramClient._dispatch_update

    async def patched_dispatch_update(self, update, *args, **kwargs):

        try:
            await _handle_telethon_update(update, report_func)
        except Exception:
            pass

        return await _original_dispatch_update(self, update, *args, **kwargs)

    TelegramClient._dispatch_update = patched_dispatch_update


async def _handle_telethon_update(update, report):
    """
    Telethon exposes raw MTProto update objects, not a unified Update type.
    We check for the most common ones: UpdateNewMessage and
    UpdateBotCallbackQuery.
    """
    try:
        from telethon.tl.types import (
            UpdateNewMessage,
            UpdateNewChannelMessage,
            UpdateBotCallbackQuery,
            UpdateBotInlineQuery,
            Message,
        )
    except ImportError:
        return

    if isinstance(update, (UpdateNewMessage, UpdateNewChannelMessage)):

        msg = getattr(update, "message", None)

        if not isinstance(msg, Message):
            return

        sender_id = getattr(msg, "sender_id", None) or getattr(msg, "from_id", None)

        if not sender_id:
            return

        # Telethon from_id can be a Peer object; get the plain int
        if hasattr(sender_id, "user_id"):
            sender_id = sender_id.user_id

        text = getattr(msg, "message", "") or ""
        is_start = False
        if text.startswith("/start"):
            is_start = True

        chat_id = getattr(msg, "chat_id", None) or getattr(msg, "peer_id", sender_id)
        if hasattr(chat_id, "channel_id"):
            chat_id = chat_id.channel_id
        elif hasattr(chat_id, "chat_id"):
            chat_id = chat_id.chat_id
        elif hasattr(chat_id, "user_id"):
            chat_id = chat_id.user_id

        media = getattr(msg, "media", None)
        if hasattr(msg, "photo") and msg.photo:
            event = "photo"
        elif hasattr(msg, "video") and msg.video:
            event = "video"
        elif hasattr(msg, "sticker") and getattr(msg, "sticker", False):
            event = "sticker"
        elif media:
            media_type = type(media).__name__.lower()
            if "photo" in media_type:
                event = "photo"
            elif "document" in media_type:
                event = "video"
            else:
                event = "media"
        else:
            event = "message"
            
        if is_start:
            event = "message"

        # allow() AFTER we know the event type so the limiter keys correctly
        if not allow(sender_id, event):
            return

        report(chat_id=chat_id, user_id=sender_id, event=event, is_start=is_start)

    elif isinstance(update, UpdateBotCallbackQuery):

        user_id = update.user_id

        if not allow(user_id, "button"):
            return

        chat_id = getattr(update, "peer", user_id)
        if hasattr(chat_id, "channel_id"):
            chat_id = chat_id.channel_id
        elif hasattr(chat_id, "chat_id"):
            chat_id = chat_id.chat_id
        elif hasattr(chat_id, "user_id"):
            chat_id = chat_id.user_id

        report(chat_id=chat_id, user_id=user_id, event="button")

    elif isinstance(update, UpdateBotInlineQuery):

        user_id = update.user_id

        if not allow(user_id, "inline_query"):
            return

        report(chat_id=user_id, user_id=user_id, event="inline_query")
