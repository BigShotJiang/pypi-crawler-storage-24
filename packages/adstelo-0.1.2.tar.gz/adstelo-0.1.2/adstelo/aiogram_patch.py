from .limiter import allow

_original_feed_update = None


def patch_aiogram(report_func):

    try:
        from aiogram.dispatcher.dispatcher import Dispatcher
    except ImportError:
        return

    global _original_feed_update

    _original_feed_update = Dispatcher.feed_update

    async def patched_feed_update(self, bot, update, *args, **kwargs):

        try:
            handle_update(update, report_func)
        except Exception:
            pass

        return await _original_feed_update(self, bot, update, *args, **kwargs)

    Dispatcher.feed_update = patched_feed_update


def handle_update(update, report):

    # ── Callback query (inline button press) ─────────────────────────────────
    # Checked first — independent of the message branch so it is never masked.
    cb = getattr(update, "callback_query", None)
    if cb:
        user_id = cb.from_user.id
        chat_id = cb.message.chat.id if cb.message else user_id

        if allow(user_id, "button"):
            report(chat_id=chat_id, user_id=user_id, event="button")

        # Return so we don't also try to parse a message from the same update.
        return

    # ── Regular message (text, photo, video, sticker, …) ─────────────────────
    msg = getattr(update, "message", None)
    if msg:
        user = msg.from_user

        if not user:
            return

        is_start = False
        if msg.text and msg.text.startswith("/start"):
            is_start = True
            event = "message"
        elif msg.photo:
            event = "photo"
        elif msg.video:
            event = "video"
        elif msg.sticker:
            event = "sticker"
        else:
            event = "message"

        if allow(user.id, event):
            report(
                chat_id=msg.chat.id, 
                user_id=user.id, 
                event=event, 
                is_start=is_start
            )

        return

    # ── Inline query (user typing @bot …) ─────────────────────────────────────
    iq = getattr(update, "inline_query", None)
    if iq:
        user_id = iq.from_user.id

        if allow(user_id, "inline_query"):
            report(chat_id=user_id, user_id=user_id, event="inline_query")