"""
Identity Overlay Network — crypto-based routing independent of IP.

The overlay sits on top of IPv4/IPv6 and routes based on JIS DIDs,
not IP addresses. This makes CGNAT, NAT traversal, and IP conflicts
irrelevant.
"""

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from .identity import IdentityRegistry, DeviceIdentity, IdentityProof
from .provenance import OverlayProvenance


@dataclass
class OverlayNode:
    """A node in the identity overlay network."""
    did: str
    device_id: str
    endpoint: str  # How to reach this node (may change)
    capabilities: list[str] = field(default_factory=list)
    trust_score: float = 0.5
    connected_since: str = ""
    behind_nat: bool = False

    def to_dict(self) -> dict:
        return {
            "did": self.did,
            "device_id": self.device_id,
            "endpoint": self.endpoint,
            "capabilities": self.capabilities,
            "trust_score": self.trust_score,
            "behind_nat": self.behind_nat,
        }


@dataclass
class RouteResult:
    """Result of routing a message through the overlay."""
    source_did: str
    target_did: str
    resolved: bool
    endpoint: str = ""
    trust_score: float = 0.0
    hops: int = 0
    provenance_token: Optional[dict] = None

    def to_dict(self) -> dict:
        return {
            "source_did": self.source_did,
            "target_did": self.target_did,
            "resolved": self.resolved,
            "endpoint": self.endpoint,
            "trust_score": self.trust_score,
            "hops": self.hops,
        }


class IdentityOverlay:
    """
    Decentralized Identity Overlay Network.

    Routes messages based on cryptographic identity (JIS DID),
    not network address (IP). Makes CGNAT and NAT traversal irrelevant.

    Trust scores are automatically computed via FIR/A
    (Frequency, Integrity, Recency, Anomaly) and stay in sync
    between the registry and overlay nodes.

    Usage::

        overlay = IdentityOverlay()
        identity = overlay.register("sensor-42", capabilities=["mqtt", "coap"])
        verified = overlay.verify("jis:sensor-42")
        route = overlay.resolve("jis:sensor-42")
        print(verified.fira)  # Full FIR/A breakdown
    """

    def __init__(self, actor: str = "tibet-overlay"):
        self.registry = IdentityRegistry()
        self.provenance = OverlayProvenance(actor=actor)
        self.nodes: dict[str, OverlayNode] = {}

        # Auto-sync node trust when registry trust changes
        self.registry.on_trust_change(self._sync_node_trust)

    def _sync_node_trust(self, did: str, old_trust: float, new_trust: float) -> None:
        """Keep overlay node trust in sync with registry."""
        if did in self.nodes:
            self.nodes[did].trust_score = new_trust

    def register(
        self,
        device_id: str,
        endpoint: str = "",
        capabilities: list[str] | None = None,
        ip: str = "",
        port: int = 0,
        behind_nat: bool = False,
    ) -> DeviceIdentity:
        """
        Register a device on the overlay network.

        Identity is crypto-based (JIS DID), not IP-based.
        The IP/port is stored as informational endpoint hint only.
        Trust starts from FIR/A calculation (not a static 0.5).
        """
        identity = self.registry.register(
            device_id=device_id,
            capabilities=capabilities,
        )

        if ip:
            self.registry.update_network(identity.did, ip, port, behind_nat)

        node = OverlayNode(
            did=identity.did,
            device_id=device_id,
            endpoint=endpoint or f"{ip}:{port}" if ip else "",
            capabilities=capabilities or [],
            trust_score=identity.trust_score,
            connected_since=datetime.now(timezone.utc).isoformat(),
            behind_nat=behind_nat,
        )
        self.nodes[identity.did] = node

        # Create TIBET token for registration
        self.provenance.create_token(
            action="register",
            device_id=device_id,
            did=identity.did,
            details={"capabilities": capabilities or [], "behind_nat": behind_nat},
        )

        return identity

    def verify(self, did: str) -> IdentityProof:
        """
        Verify a device identity on the overlay.

        Automatically updates FIR/A trust score. Node trust stays in sync.
        """
        proof = self.registry.verify(did)

        self.provenance.create_token(
            action="verify",
            device_id=did.split(":")[-1] if ":" in did else did,
            did=did,
            details={
                "verified": proof.verified,
                "trust_score": proof.trust_score,
                "fira": proof.fira,
            },
        )

        return proof

    def record_anomaly(self, did: str) -> float:
        """Record an anomaly for a device. Trust auto-recalculates."""
        new_trust = self.registry.record_anomaly(did)
        self.provenance.create_token(
            action="anomaly",
            device_id=did.split(":")[-1] if ":" in did else did,
            did=did,
            details={"new_trust": new_trust},
        )
        return new_trust

    def record_failed_verify(self, did: str) -> float:
        """Record a failed verification. Trust auto-recalculates."""
        new_trust = self.registry.record_failed_verify(did)
        self.provenance.create_token(
            action="failed_verify",
            device_id=did.split(":")[-1] if ":" in did else did,
            did=did,
            details={"new_trust": new_trust},
        )
        return new_trust

    def resolve(self, did: str) -> RouteResult:
        """
        Resolve a DID to a reachable endpoint.

        This is the core of the overlay: find a device by its
        cryptographic identity, regardless of its IP address.
        Records interaction for FIR/A recency scoring.
        """
        if did in self.nodes:
            node = self.nodes[did]
            # Record interaction — keeps recency score fresh
            self.registry.record_interaction(did)
            return RouteResult(
                source_did="self",
                target_did=did,
                resolved=True,
                endpoint=node.endpoint,
                trust_score=node.trust_score,
                hops=0,
            )

        return RouteResult(
            source_did="self",
            target_did=did,
            resolved=False,
        )

    def update_endpoint(self, did: str, endpoint: str, ip: str = "", port: int = 0) -> None:
        """
        Update a device's endpoint.

        This happens when a device's IP changes (e.g., DHCP renewal,
        roaming, CGNAT reassignment). The identity stays the same.
        """
        if did in self.nodes:
            self.nodes[did].endpoint = endpoint
        if ip:
            self.registry.update_network(did, ip, port)

    def connected_nodes(self) -> list[OverlayNode]:
        """List all connected nodes."""
        return list(self.nodes.values())

    def find_by_capability(self, capability: str) -> list[OverlayNode]:
        """Find nodes by capability."""
        return [n for n in self.nodes.values() if capability in n.capabilities]

    def get_fira(self, did: str) -> dict:
        """Get full FIR/A trust breakdown for a device."""
        if did in self.registry.identities:
            return self.registry.identities[did].fira_breakdown()
        return {"score": 0.0, "reason": "unknown_device"}

    def status(self) -> dict:
        """Network status with live FIR/A trust scores."""
        total = len(self.nodes)
        behind_nat = sum(1 for n in self.nodes.values() if n.behind_nat)
        avg_trust = (
            sum(n.trust_score for n in self.nodes.values()) / total
            if total > 0 else 0.0
        )
        capabilities = set()
        for n in self.nodes.values():
            capabilities.update(n.capabilities)

        return {
            "total_nodes": total,
            "behind_nat": behind_nat,
            "nat_percentage": round(behind_nat / total * 100) if total > 0 else 0,
            "average_trust": round(avg_trust, 4),
            "capabilities": sorted(capabilities),
            "tibet_tokens": len(self.provenance.chain()),
        }

    def export_audit(self) -> list[dict]:
        """Export full TIBET audit trail."""
        return self.provenance.chain()
