"""
TIBET provenance for overlay identity events.

Every identity registration, verification, and resolution
is tracked with a TIBET token.
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class OverlayToken:
    token_id: str
    timestamp: str
    action: str
    device_id: str
    did: str
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)
    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": "overlay_identity",
            "action": self.action,
            "device_id": self.device_id,
            "did": self.did,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


class OverlayProvenance:
    def __init__(self, actor: str = "tibet-overlay"):
        self.actor = actor
        self.tokens: list[OverlayToken] = []
        self._last_id: str | None = None

    def create_token(
        self,
        action: str,
        device_id: str,
        did: str,
        details: dict | None = None,
    ) -> OverlayToken:
        now = datetime.now(timezone.utc).isoformat()

        erin = {
            "action": action,
            "device_id": device_id,
            "did": did,
            "details": details or {},
        }
        eraan = {"parent_token": self._last_id}
        eromheen = {
            "node": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
        }
        erachter = {
            "intent": f"Overlay {action} for {did}",
            "protocol": "JIS/DID overlay",
        }

        content = json.dumps({"erin": erin}, sort_keys=True)
        token_id = hashlib.sha256(f"{did}:{action}:{now}".encode()).hexdigest()[:16]
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = OverlayToken(
            token_id=token_id,
            timestamp=now,
            action=action,
            device_id=device_id,
            did=did,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )
        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def chain(self) -> list[dict]:
        return [t.to_dict() for t in self.tokens]
