"""
Device identity layer — cryptographic identity independent of IP address.

A device proves who it is via its JIS DID and TIBET history,
not via its IP address. This makes CGNAT, NAT traversal,
and IP spoofing irrelevant for identity.

Trust scoring follows FIR/A:
  Frequency (20%)  — how often does the device interact?
  Integrity (40%)  — how many verifications passed vs failed?
  Recency   (25%)  — when was the last successful interaction?
  Anomaly   (15%)  — any unusual behavior detected?
"""

import hashlib
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


# FIR/A weights
_W_FREQUENCY = 0.20
_W_INTEGRITY = 0.40
_W_RECENCY = 0.25
_W_ANOMALY = 0.15


@dataclass
class TrustHistory:
    """Behavioral history for FIR/A trust calculation."""
    verify_pass: int = 0
    verify_fail: int = 0
    interactions: int = 0
    anomalies: int = 0
    first_seen: float = 0.0
    last_success: float = 0.0

    def record_verify(self, passed: bool) -> None:
        self.interactions += 1
        now = time.time()
        if not self.first_seen:
            self.first_seen = now
        if passed:
            self.verify_pass += 1
            self.last_success = now
        else:
            self.verify_fail += 1

    def record_interaction(self) -> None:
        self.interactions += 1
        now = time.time()
        if not self.first_seen:
            self.first_seen = now
        self.last_success = now

    def record_anomaly(self) -> None:
        self.anomalies += 1

    def compute_fira(self) -> dict:
        """Compute FIR/A trust score from behavioral history."""
        now = time.time()

        # Frequency: more interactions = higher (capped at 1.0)
        # 20 interactions = full frequency score
        freq = min(1.0, self.interactions / 20.0) if self.interactions > 0 else 0.0

        # Integrity: ratio of passed verifications
        total_verifies = self.verify_pass + self.verify_fail
        integrity = (self.verify_pass / total_verifies) if total_verifies > 0 else 0.5

        # Recency: decays over time since last success
        # Full score within 1 hour, decays to 0.1 after 24 hours
        if self.last_success > 0:
            age_hours = (now - self.last_success) / 3600.0
            recency = max(0.1, 1.0 - (age_hours / 24.0))
        else:
            recency = 0.3  # never interacted successfully

        # Anomaly: each anomaly reduces score
        # 0 anomalies = 1.0, 5+ anomalies = 0.0
        anomaly = max(0.0, 1.0 - (self.anomalies * 0.2))

        score = (
            _W_FREQUENCY * freq
            + _W_INTEGRITY * integrity
            + _W_RECENCY * recency
            + _W_ANOMALY * anomaly
        )

        return {
            "score": round(max(0.0, min(1.0, score)), 4),
            "frequency": round(freq, 4),
            "integrity": round(integrity, 4),
            "recency": round(recency, 4),
            "anomaly": round(anomaly, 4),
            "interactions": self.interactions,
            "verify_pass": self.verify_pass,
            "verify_fail": self.verify_fail,
            "anomalies": self.anomalies,
        }


@dataclass
class DeviceIdentity:
    """
    A cryptographic device identity.

    Independent of network topology (IP address).
    Based on JIS (Jasper Identity Standard) DIDs.
    """
    device_id: str
    did: str  # did:jis:<device_id>
    public_key_hash: str
    capabilities: list[str] = field(default_factory=list)
    created_at: str = ""
    last_seen: str = ""
    trust_score: float = 0.5
    metadata: dict = field(default_factory=dict)
    trust_history: TrustHistory = field(default_factory=TrustHistory)

    # Network info (informational, NOT used for identity)
    last_known_ip: str = ""
    last_known_port: int = 0
    behind_nat: bool = False

    def recalculate_trust(self) -> float:
        """Recalculate trust score from FIR/A behavioral history."""
        fira = self.trust_history.compute_fira()
        self.trust_score = fira["score"]
        return self.trust_score

    def fira_breakdown(self) -> dict:
        """Get full FIR/A breakdown."""
        return self.trust_history.compute_fira()

    def to_dict(self) -> dict:
        fira = self.trust_history.compute_fira()
        return {
            "device_id": self.device_id,
            "did": self.did,
            "public_key_hash": self.public_key_hash,
            "capabilities": self.capabilities,
            "created_at": self.created_at,
            "last_seen": self.last_seen,
            "trust_score": self.trust_score,
            "fira": fira,
            "network": {
                "last_known_ip": self.last_known_ip,
                "last_known_port": self.last_known_port,
                "behind_nat": self.behind_nat,
            },
            "metadata": self.metadata,
        }


@dataclass
class IdentityProof:
    """
    Proof that a device is who it claims to be.

    Contains the JIS DID, a challenge-response hash,
    and the TIBET provenance of previous interactions.
    """
    did: str
    challenge: str
    response_hash: str
    timestamp: str
    verified: bool = False
    trust_score: float = 0.0
    tibet_history_length: int = 0
    fira: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "did": self.did,
            "challenge": self.challenge,
            "response_hash": self.response_hash,
            "timestamp": self.timestamp,
            "verified": self.verified,
            "trust_score": self.trust_score,
            "fira": self.fira,
            "tibet_history_length": self.tibet_history_length,
        }


class IdentityRegistry:
    """
    Registry of known device identities.

    Devices register with their JIS DID and public key.
    Trust scores are computed automatically via FIR/A
    (Frequency, Integrity, Recency, Anomaly).
    """

    def __init__(self):
        self.identities: dict[str, DeviceIdentity] = {}
        self._on_trust_change: list = []

    def on_trust_change(self, callback) -> None:
        """Register a callback for trust score changes: callback(did, old, new)."""
        self._on_trust_change.append(callback)

    def _notify_trust_change(self, did: str, old: float, new: float) -> None:
        for cb in self._on_trust_change:
            cb(did, old, new)

    def register(
        self,
        device_id: str,
        capabilities: list[str] | None = None,
        public_key: bytes | None = None,
        metadata: dict | None = None,
    ) -> DeviceIdentity:
        """Register a new device identity."""
        now = datetime.now(timezone.utc).isoformat()

        # Generate DID
        did = f"jis:{device_id}"

        # Hash the public key (or generate a placeholder)
        if public_key:
            pk_hash = hashlib.sha256(public_key).hexdigest()[:32]
        else:
            pk_hash = hashlib.sha256(
                f"{device_id}:{now}:{os.urandom(16).hex()}".encode()
            ).hexdigest()[:32]

        history = TrustHistory(first_seen=time.time())
        history.record_interaction()  # registration counts as first interaction

        identity = DeviceIdentity(
            device_id=device_id,
            did=did,
            public_key_hash=pk_hash,
            capabilities=capabilities or [],
            created_at=now,
            last_seen=now,
            trust_score=0.5,
            metadata=metadata or {},
            trust_history=history,
        )

        # Compute initial FIR/A trust
        identity.recalculate_trust()

        self.identities[did] = identity
        return identity

    def verify(self, did: str, challenge: str | None = None) -> IdentityProof:
        """
        Verify a device identity.

        Automatically updates FIR/A trust score based on verification result.
        """
        now = datetime.now(timezone.utc).isoformat()
        challenge = challenge or hashlib.sha256(os.urandom(32)).hexdigest()[:16]

        if did not in self.identities:
            return IdentityProof(
                did=did,
                challenge=challenge,
                response_hash="",
                timestamp=now,
                verified=False,
                trust_score=0.0,
                fira={"score": 0.0, "reason": "unknown_device"},
            )

        identity = self.identities[did]
        old_trust = identity.trust_score
        identity.last_seen = now

        # Simulate challenge-response
        response = hashlib.sha256(
            f"{did}:{challenge}:{identity.public_key_hash}".encode()
        ).hexdigest()[:32]

        # Record successful verification in FIR/A history
        identity.trust_history.record_verify(passed=True)
        new_trust = identity.recalculate_trust()

        if abs(old_trust - new_trust) > 0.001:
            self._notify_trust_change(did, old_trust, new_trust)

        return IdentityProof(
            did=did,
            challenge=challenge,
            response_hash=response,
            timestamp=now,
            verified=True,
            trust_score=new_trust,
            fira=identity.fira_breakdown(),
            tibet_history_length=identity.trust_history.interactions,
        )

    def record_failed_verify(self, did: str) -> float:
        """Record a failed verification attempt. Returns new trust score."""
        if did not in self.identities:
            return 0.0
        identity = self.identities[did]
        old_trust = identity.trust_score
        identity.trust_history.record_verify(passed=False)
        new_trust = identity.recalculate_trust()
        if abs(old_trust - new_trust) > 0.001:
            self._notify_trust_change(did, old_trust, new_trust)
        return new_trust

    def record_anomaly(self, did: str) -> float:
        """Record an anomaly for a device. Returns new trust score."""
        if did not in self.identities:
            return 0.0
        identity = self.identities[did]
        old_trust = identity.trust_score
        identity.trust_history.record_anomaly()
        new_trust = identity.recalculate_trust()
        if abs(old_trust - new_trust) > 0.001:
            self._notify_trust_change(did, old_trust, new_trust)
        return new_trust

    def record_interaction(self, did: str) -> float:
        """Record a successful interaction. Returns new trust score."""
        if did not in self.identities:
            return 0.0
        identity = self.identities[did]
        old_trust = identity.trust_score
        identity.trust_history.record_interaction()
        new_trust = identity.recalculate_trust()
        if abs(old_trust - new_trust) > 0.001:
            self._notify_trust_change(did, old_trust, new_trust)
        return new_trust

    def update_trust(self, did: str, delta: float) -> float:
        """Manually adjust trust score (clamped 0.0-1.0)."""
        if did in self.identities:
            identity = self.identities[did]
            old_trust = identity.trust_score
            identity.trust_score = max(0.0, min(1.0, identity.trust_score + delta))
            if abs(old_trust - identity.trust_score) > 0.001:
                self._notify_trust_change(did, old_trust, identity.trust_score)
            return identity.trust_score
        return 0.0

    def update_network(self, did: str, ip: str, port: int, behind_nat: bool = False) -> None:
        """Update network information (informational only, not identity)."""
        if did in self.identities:
            identity = self.identities[did]
            identity.last_known_ip = ip
            identity.last_known_port = port
            identity.behind_nat = behind_nat
            identity.last_seen = datetime.now(timezone.utc).isoformat()

    def by_capability(self, capability: str) -> list[DeviceIdentity]:
        """Find devices with a specific capability."""
        return [
            d for d in self.identities.values()
            if capability in d.capabilities
        ]

    def stats(self) -> dict:
        total = len(self.identities)
        behind_nat = sum(1 for d in self.identities.values() if d.behind_nat)
        avg_trust = (
            sum(d.trust_score for d in self.identities.values()) / total
            if total > 0 else 0.0
        )
        return {
            "total_devices": total,
            "behind_nat": behind_nat,
            "average_trust": round(avg_trust, 3),
        }
