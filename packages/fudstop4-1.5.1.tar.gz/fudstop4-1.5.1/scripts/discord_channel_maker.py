from fudstop4.apis.polygonio.polygon_options import PolygonOptions
db = PolygonOptions()
from fudstop4.apis.discord_.discord_sdk import DiscordSDK
from fudstop4._markets.list_sets.ticker_lists import most_active_tight_spread_tickers
logo_path = r"files\logos"
sdk = DiscordSDK(auth="MTQ1NzA5MDEwNTg5MzE5MTc2MQ.GM0CQz.lmyw8J9JH-C-mN0mCLpXyeQ_sEWNveC-SKYvaE")
guild_id=1457091273243758614
import asyncio
parent_id=1459314980859150450
UNICODE_BOLD = str.maketrans(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
    "𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙"
    "𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗"
)

def ticker_to_unicode(ticker: str) -> str:
    return ticker.translate(UNICODE_BOLD)


async def main():

    await db.connect()

    for ticker in most_active_tight_spread_tickers:

        if ticker in ['AMD', 'AMD', 'TSLA', 'NVDA', 'PLTR', 'GOOGL']:
            continue

        sdk.create_channel(guild_id=guild_id, name=ticker_to_unicode(ticker),with_webhook=True, webhook_name=ticker)


        await asyncio.sleep(45)


asyncio.run(main())