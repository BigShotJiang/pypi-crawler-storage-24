import argparse
import asyncio
import os
import datetime as dt
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

TD_MIN = int(os.getenv("REPLAY_TD_MIN", "8"))
RSI_OVERSOLD = float(os.getenv("REPLAY_RSI_OVERSOLD", "30"))
RSI_OVERBOUGHT = float(os.getenv("REPLAY_RSI_OVERBOUGHT", "70"))


def _parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="Re-score prior combo findings against current candle_analysis data."
    )
    ap.add_argument("--timespan", default="m1")
    ap.add_argument("--bullish-file", default="runs/bullish_combo_findings_big.csv")
    ap.add_argument("--bearish-file", default="runs/bearish_combo_findings_big.csv")
    ap.add_argument("--out-dir", default="runs")
    return ap.parse_args()


def _load_findings(path: str) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        return pd.DataFrame()
    df = pd.read_csv(p)
    if df.empty:
        return df
    for col in ["window_min", "window_max", "lookback_days", "val_days"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def _build_bullish_sql(
    timespan: str,
    lookback_days: int,
    val_days: int,
    window_min: int,
    window_max: int,
) -> str:
    return f"""
WITH
params AS (
    SELECT
        '{timespan}'::text AS timespan,
        interval '{lookback_days} days' AS lookback,
        interval '{val_days} days' AS val_window
),
base_rows AS (
    SELECT
        c.ticker,
        c.ts_utc::timestamptz AS ts_utc,
        c.c,
        c.h,
        c.l,
        c.rsi,
        c.roc,
        c.td_buy_count,
        c.candle_completely_below_lower,
        c.bb_width,
        (c.atr / NULLIF(c.c, 0)) AS atr_pct,
        c.rvol,
        c.mfi,
        c.stoch_k,
        c.williams_r,
        c.volume_confirm,
        c.vwap_dist_pct,
        c.trix,
        c.vwap_cross_up,
        c.ema_stack_bull,
        c.macd_cross_up,
        c.tsi_cross_up,
        c.di_bull,
        c.adx_strong,
        c.trend_regime,
        c.stoch_rsi_k,
        c.bullish_engulfing,
        c.is_hammer,
        c.is_doji,
        c.candle_red,
        c.candle_green
    FROM candle_analysis c
    CROSS JOIN params p
    WHERE c.timespan = p.timespan
      AND c.ts_utc IS NOT NULL
),
max_ts AS (
    SELECT max(ts_utc) AS max_ts
    FROM base_rows
),
bounds AS (
    SELECT
        p.*,
        m.max_ts,
        (m.max_ts - p.lookback)   AS start_ts,
        (m.max_ts - p.val_window) AS cutoff_ts
    FROM params p
    CROSS JOIN max_ts m
),
base AS MATERIALIZED (
    SELECT
        b.*,
        max(b.h) OVER w_fwd AS max_h_fwd,
        min(b.l) OVER w_fwd AS min_l_fwd,
        count(*) OVER w_fwd AS n_fwd
    FROM base_rows b
    CROSS JOIN bounds bo
    WHERE b.ts_utc >= bo.start_ts
      AND b.ts_utc <  bo.max_ts
    WINDOW
      w_fwd AS (
        PARTITION BY b.ticker
        ORDER BY b.ts_utc
        ROWS BETWEEN {window_min} FOLLOWING AND {window_max} FOLLOWING
      )
)
SELECT
    b.ticker,
    b.ts_utc,
    b.rsi,
    b.roc,
    b.td_buy_count,
    b.bb_width,
    b.atr_pct,
    b.rvol,
    b.mfi,
    b.stoch_k,
    b.williams_r,
    b.volume_confirm,
    b.vwap_dist_pct,
    b.trix,
    b.vwap_cross_up,
    b.ema_stack_bull,
    b.macd_cross_up,
    b.tsi_cross_up,
    b.di_bull,
    b.adx_strong,
    b.trend_regime,
    b.stoch_rsi_k,
    b.bullish_engulfing,
    b.is_hammer,
    b.is_doji,
    b.candle_completely_below_lower,
    b.candle_red,
    b.candle_green,
    (b.max_h_fwd / NULLIF(b.c, 0) - 1) AS best_signed_ret,
    (b.ts_utc >= (SELECT cutoff_ts FROM bounds)) AS is_val
FROM base b
WHERE b.n_fwd = ({window_max} - {window_min} + 1)
  AND b.rsi <= {RSI_OVERSOLD}
  AND b.td_buy_count >= {TD_MIN};
"""


def _build_bearish_sql(
    timespan: str,
    lookback_days: int,
    val_days: int,
    window_min: int,
    window_max: int,
) -> str:
    return f"""
WITH
params AS (
    SELECT
        '{timespan}'::text AS timespan,
        interval '{lookback_days} days' AS lookback,
        interval '{val_days} days' AS val_window
),
base_rows AS (
    SELECT
        c.ticker,
        c.ts_utc::timestamptz AS ts_utc,
        c.c,
        c.h,
        c.l,
        c.rsi,
        c.roc,
        c.td_sell_count,
        c.candle_completely_above_upper,
        c.bb_width,
        (c.atr / NULLIF(c.c, 0)) AS atr_pct,
        c.rvol,
        c.mfi,
        c.stoch_k,
        c.williams_r,
        c.volume_confirm,
        c.vwap_dist_pct,
        c.trix,
        c.vwap_cross_dn,
        c.ema_stack_bear,
        c.macd_cross_dn,
        c.tsi_cross_dn,
        c.di_bear,
        c.adx_strong,
        c.trend_regime,
        c.stoch_rsi_k,
        c.bearish_engulfing,
        c.is_shooting_star,
        c.is_doji,
        c.candle_red,
        c.candle_green
    FROM candle_analysis c
    CROSS JOIN params p
    WHERE c.timespan = p.timespan
      AND c.ts_utc IS NOT NULL
),
max_ts AS (
    SELECT max(ts_utc) AS max_ts
    FROM base_rows
),
bounds AS (
    SELECT
        p.*,
        m.max_ts,
        (m.max_ts - p.lookback)   AS start_ts,
        (m.max_ts - p.val_window) AS cutoff_ts
    FROM params p
    CROSS JOIN max_ts m
),
base AS MATERIALIZED (
    SELECT
        b.*,
        max(b.h) OVER w_fwd AS max_h_fwd,
        min(b.l) OVER w_fwd AS min_l_fwd,
        count(*) OVER w_fwd AS n_fwd
    FROM base_rows b
    CROSS JOIN bounds bo
    WHERE b.ts_utc >= bo.start_ts
      AND b.ts_utc <  bo.max_ts
    WINDOW
      w_fwd AS (
        PARTITION BY b.ticker
        ORDER BY b.ts_utc
        ROWS BETWEEN {window_min} FOLLOWING AND {window_max} FOLLOWING
      )
)
SELECT
    b.ticker,
    b.ts_utc,
    b.rsi,
    b.roc,
    b.td_sell_count,
    b.bb_width,
    b.atr_pct,
    b.rvol,
    b.mfi,
    b.stoch_k,
    b.williams_r,
    b.volume_confirm,
    b.vwap_dist_pct,
    b.trix,
    b.vwap_cross_dn,
    b.ema_stack_bear,
    b.macd_cross_dn,
    b.tsi_cross_dn,
    b.di_bear,
    b.adx_strong,
    b.trend_regime,
    b.stoch_rsi_k,
    b.bearish_engulfing,
    b.is_shooting_star,
    b.is_doji,
    b.candle_red,
    b.candle_green,
    (-1) * (b.min_l_fwd / NULLIF(b.c, 0) - 1) AS best_signed_ret,
    (b.ts_utc >= (SELECT cutoff_ts FROM bounds)) AS is_val
FROM base b
WHERE b.n_fwd = ({window_max} - {window_min} + 1)
  AND b.rsi >= {RSI_OVERBOUGHT}
  AND b.td_sell_count >= {TD_MIN};
"""


def _add_time_of_day_flags(df: pd.DataFrame) -> pd.DataFrame:
    ts = pd.to_datetime(df["ts_utc"], utc=True, errors="coerce")
    ny = ts.dt.tz_convert("America/New_York")
    tod = ny.dt.time
    df["tod_open"] = (tod >= dt.time(9, 30)) & (tod < dt.time(10, 30))
    df["tod_mid"] = (tod >= dt.time(10, 30)) & (tod < dt.time(15, 0))
    df["tod_close"] = (tod >= dt.time(15, 0)) & (tod < dt.time(16, 0))
    return df


def _coerce_numeric(df: pd.DataFrame, cols: List[str]) -> None:
    for col in cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")


def _num_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(np.nan, index=df.index)
    return pd.to_numeric(df[col], errors="coerce")


def _bool_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(False, index=df.index)
    return df[col].fillna(False).astype(bool)


def _build_addons_bull(df: pd.DataFrame) -> Dict[str, np.ndarray]:
    return {
        "bb_width>=0.03": (df["bb_width"] >= 0.03).to_numpy(),
        "bb_width>=0.04": (df["bb_width"] >= 0.04).to_numpy(),
        "bb_width>=0.05": (df["bb_width"] >= 0.05).to_numpy(),
        "bb_width>=0.06": (df["bb_width"] >= 0.06).to_numpy(),
        "atr_pct>=0.003": (df["atr_pct"] >= 0.003).to_numpy(),
        "atr_pct>=0.006": (df["atr_pct"] >= 0.006).to_numpy(),
        "atr_pct>=0.009": (df["atr_pct"] >= 0.009).to_numpy(),
        "rvol>=1.5": (df["rvol"] >= 1.5).to_numpy(),
        "rvol>=2.0": (df["rvol"] >= 2.0).to_numpy(),
        "rvol>=2.5": (df["rvol"] >= 2.5).to_numpy(),
        "rvol>=3.0": (df["rvol"] >= 3.0).to_numpy(),
        "mfi<=20": (df["mfi"] <= 20).to_numpy(),
        "mfi<=10": (df["mfi"] <= 10).to_numpy(),
        "stoch_k<=20": (df["stoch_k"] <= 20).to_numpy(),
        "stoch_k<=10": (df["stoch_k"] <= 10).to_numpy(),
        "williams_r<=-80": (df["williams_r"] <= -80).to_numpy(),
        "williams_r<=-90": (df["williams_r"] <= -90).to_numpy(),
        "trix<=-0.1": (_num_series(df, "trix") <= -0.1).to_numpy(),
        "trix<=-0.2": (_num_series(df, "trix") <= -0.2).to_numpy(),
        "roc<=-1": (_num_series(df, "roc") <= -1).to_numpy(),
        "roc<=-2": (_num_series(df, "roc") <= -2).to_numpy(),
        "volume_confirm": df["volume_confirm"].fillna(False).astype(bool).to_numpy(),
        "vwap_dist>=0.00": (df["vwap_dist_pct"] >= 0.0).to_numpy(),
        "vwap_dist<=-0.01": (df["vwap_dist_pct"] <= -0.01).to_numpy(),
        "vwap_dist<=-0.02": (df["vwap_dist_pct"] <= -0.02).to_numpy(),
        "vwap_dist<=-0.03": (df["vwap_dist_pct"] <= -0.03).to_numpy(),
        "vwap_cross_up": df["vwap_cross_up"].fillna(False).astype(bool).to_numpy(),
        "ema_stack_bull": df["ema_stack_bull"].fillna(False).astype(bool).to_numpy(),
        "macd_cross_up": df["macd_cross_up"].fillna(False).astype(bool).to_numpy(),
        "tsi_cross_up": df["tsi_cross_up"].fillna(False).astype(bool).to_numpy(),
        "di_bull": df["di_bull"].fillna(False).astype(bool).to_numpy(),
        "adx_strong": df["adx_strong"].fillna(False).astype(bool).to_numpy(),
        "trend_regime": df["trend_regime"].fillna(False).astype(bool).to_numpy(),
        "stoch_rsi_k<=20": (df["stoch_rsi_k"] <= 20).to_numpy(),
        "stoch_rsi_k<=10": (df["stoch_rsi_k"] <= 10).to_numpy(),
        "rsi<=20": (df["rsi"] <= 20).to_numpy(),
        "rsi<=15": (df["rsi"] <= 15).to_numpy(),
        "td_buy>=13": (df["td_buy_count"] >= 13).to_numpy(),
        "td_buy>=20": (df["td_buy_count"] >= 20).to_numpy(),
        "bullish_engulfing": df["bullish_engulfing"].fillna(False).astype(bool).to_numpy(),
        "is_hammer": df["is_hammer"].fillna(False).astype(bool).to_numpy(),
        "is_doji": df["is_doji"].fillna(False).astype(bool).to_numpy(),
        "candle_green": df["candle_green"].fillna(False).astype(bool).to_numpy(),
        "candle_red": df["candle_red"].fillna(False).astype(bool).to_numpy(),
        "candle_below_band": _bool_series(df, "candle_completely_below_lower").to_numpy(),
        "tod_open": df["tod_open"].fillna(False).astype(bool).to_numpy(),
        "tod_mid": df["tod_mid"].fillna(False).astype(bool).to_numpy(),
        "tod_close": df["tod_close"].fillna(False).astype(bool).to_numpy(),
    }


def _build_addons_bear(df: pd.DataFrame) -> Dict[str, np.ndarray]:
    return {
        "bb_width>=0.03": (df["bb_width"] >= 0.03).to_numpy(),
        "bb_width>=0.04": (df["bb_width"] >= 0.04).to_numpy(),
        "bb_width>=0.05": (df["bb_width"] >= 0.05).to_numpy(),
        "bb_width>=0.06": (df["bb_width"] >= 0.06).to_numpy(),
        "atr_pct>=0.003": (df["atr_pct"] >= 0.003).to_numpy(),
        "atr_pct>=0.006": (df["atr_pct"] >= 0.006).to_numpy(),
        "atr_pct>=0.009": (df["atr_pct"] >= 0.009).to_numpy(),
        "rvol>=1.5": (df["rvol"] >= 1.5).to_numpy(),
        "rvol>=2.0": (df["rvol"] >= 2.0).to_numpy(),
        "rvol>=2.5": (df["rvol"] >= 2.5).to_numpy(),
        "rvol>=3.0": (df["rvol"] >= 3.0).to_numpy(),
        "mfi>=80": (df["mfi"] >= 80).to_numpy(),
        "mfi>=90": (df["mfi"] >= 90).to_numpy(),
        "stoch_k>=80": (df["stoch_k"] >= 80).to_numpy(),
        "stoch_k>=90": (df["stoch_k"] >= 90).to_numpy(),
        "williams_r>=-20": (df["williams_r"] >= -20).to_numpy(),
        "williams_r>=-10": (df["williams_r"] >= -10).to_numpy(),
        "trix>=0.1": (_num_series(df, "trix") >= 0.1).to_numpy(),
        "trix>=0.2": (_num_series(df, "trix") >= 0.2).to_numpy(),
        "roc>=1": (_num_series(df, "roc") >= 1).to_numpy(),
        "roc>=2": (_num_series(df, "roc") >= 2).to_numpy(),
        "volume_confirm": df["volume_confirm"].fillna(False).astype(bool).to_numpy(),
        "vwap_dist<=0.00": (df["vwap_dist_pct"] <= 0.0).to_numpy(),
        "vwap_dist>=0.01": (df["vwap_dist_pct"] >= 0.01).to_numpy(),
        "vwap_dist>=0.02": (df["vwap_dist_pct"] >= 0.02).to_numpy(),
        "vwap_dist>=0.03": (df["vwap_dist_pct"] >= 0.03).to_numpy(),
        "vwap_cross_dn": df["vwap_cross_dn"].fillna(False).astype(bool).to_numpy(),
        "ema_stack_bear": df["ema_stack_bear"].fillna(False).astype(bool).to_numpy(),
        "macd_cross_dn": df["macd_cross_dn"].fillna(False).astype(bool).to_numpy(),
        "tsi_cross_dn": df["tsi_cross_dn"].fillna(False).astype(bool).to_numpy(),
        "di_bear": df["di_bear"].fillna(False).astype(bool).to_numpy(),
        "adx_strong": df["adx_strong"].fillna(False).astype(bool).to_numpy(),
        "trend_regime": df["trend_regime"].fillna(False).astype(bool).to_numpy(),
        "stoch_rsi_k>=80": (df["stoch_rsi_k"] >= 80).to_numpy(),
        "stoch_rsi_k>=90": (df["stoch_rsi_k"] >= 90).to_numpy(),
        "rsi>=80": (df["rsi"] >= 80).to_numpy(),
        "rsi>=85": (df["rsi"] >= 85).to_numpy(),
        "rsi>=90": (df["rsi"] >= 90).to_numpy(),
        "td_sell>=13": (df["td_sell_count"] >= 13).to_numpy(),
        "td_sell>=20": (df["td_sell_count"] >= 20).to_numpy(),
        "bearish_engulfing": df["bearish_engulfing"].fillna(False).astype(bool).to_numpy(),
        "is_shooting_star": df["is_shooting_star"].fillna(False).astype(bool).to_numpy(),
        "is_doji": df["is_doji"].fillna(False).astype(bool).to_numpy(),
        "candle_red": df["candle_red"].fillna(False).astype(bool).to_numpy(),
        "candle_green": df["candle_green"].fillna(False).astype(bool).to_numpy(),
        "tod_open": df["tod_open"].fillna(False).astype(bool).to_numpy(),
        "tod_mid": df["tod_mid"].fillna(False).astype(bool).to_numpy(),
        "tod_close": df["tod_close"].fillna(False).astype(bool).to_numpy(),
    }


def _eval_labels(
    df: pd.DataFrame,
    labels: List[str],
    addons: Dict[str, np.ndarray],
) -> Dict[str, np.ndarray]:
    masks: Dict[str, np.ndarray] = {}
    for label in labels:
        parts = [p.strip() for p in label.split(" AND ") if p.strip()]
        mask = np.ones(len(df), dtype=bool)
        ok = True
        for part in parts:
            m = addons.get(part)
            if m is None:
                ok = False
                break
            mask &= m
        if ok:
            masks[label] = mask
    return masks


def _score(df: pd.DataFrame, mask: np.ndarray) -> Dict[str, float]:
    n = int(mask.sum())
    if n == 0:
        return {
            "n_val": 0,
            "hit_10bp": 0.0,
            "hit_20bp": 0.0,
            "hit_30bp": 0.0,
            "hit_40bp": 0.0,
            "hit_50bp": 0.0,
            "avg_best_move": 0.0,
            "p15_best_move": 0.0,
            "tickers_val": 0,
        }
    hits = df.loc[mask, ["hit_10bp", "hit_20bp", "hit_30bp", "hit_40bp", "hit_50bp"]].mean()
    best = df.loc[mask, "best_signed_ret"].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    p15 = float(np.quantile(best.values, 0.15)) if len(best) else 0.0
    return {
        "n_val": n,
        "hit_10bp": float(hits["hit_10bp"]),
        "hit_20bp": float(hits["hit_20bp"]),
        "hit_30bp": float(hits["hit_30bp"]),
        "hit_40bp": float(hits["hit_40bp"]),
        "hit_50bp": float(hits["hit_50bp"]),
        "avg_best_move": float(best.mean()) if len(best) else 0.0,
        "p15_best_move": p15,
        "tickers_val": int(df.loc[mask, "ticker"].nunique()),
    }


async def _run_side(
    *,
    side: str,
    timespan: str,
    findings: pd.DataFrame,
    out_dir: str,
) -> None:
    if findings.empty:
        print(f"{side}: no findings to replay")
        return

    groups = findings.groupby(["lookback_days", "val_days", "window_min", "window_max"], dropna=True)
    db = PolygonOptions()
    await db.connect()
    try:
        for (lookback_days, val_days, window_min, window_max), g in groups:
            window_min = int(window_min)
            window_max = int(window_max)
            lookback_days = int(lookback_days)
            val_days = int(val_days)

            sql = (
                _build_bullish_sql(timespan, lookback_days, val_days, window_min, window_max)
                if side == "bullish"
                else _build_bearish_sql(timespan, lookback_days, val_days, window_min, window_max)
            )
            rows = await db.fetch(sql)
            if not rows:
                print(f"{side}: no rows for window {window_min}-{window_max}")
                continue

            df = pd.DataFrame([dict(r) for r in rows])
            df["is_val"] = df["is_val"].fillna(False).astype(bool)
            df = df[df["is_val"] == True].copy()
            if df.empty:
                print(f"{side}: no val rows for window {window_min}-{window_max}")
                continue

            _coerce_numeric(
                df,
                [
                    "bb_width",
                    "atr_pct",
                    "rvol",
                    "mfi",
                    "stoch_k",
                    "williams_r",
                    "vwap_dist_pct",
                    "stoch_rsi_k",
                    "trix",
                    "roc",
                    "best_signed_ret",
                    "rsi",
                    "td_buy_count",
                    "td_sell_count",
                ],
            )
            df = _add_time_of_day_flags(df)
            df["hit_10bp"] = df["best_signed_ret"] >= 0.001
            df["hit_20bp"] = df["best_signed_ret"] >= 0.002
            df["hit_30bp"] = df["best_signed_ret"] >= 0.003
            df["hit_40bp"] = df["best_signed_ret"] >= 0.004
            df["hit_50bp"] = df["best_signed_ret"] >= 0.005

            addons = _build_addons_bull(df) if side == "bullish" else _build_addons_bear(df)
            labels = [str(x) for x in g["label"].dropna().tolist()]
            label_masks = _eval_labels(df, labels, addons)

            out_rows = []
            for _, row in g.iterrows():
                label = str(row["label"])
                mask = label_masks.get(label)
                if mask is None:
                    print(f"{side}: missing addon for label '{label}'")
                    continue
                scored = _score(df, mask)
                out_rows.append(
                    {
                        "label": label,
                        "window_min": window_min,
                        "window_max": window_max,
                        "lookback_days": lookback_days,
                        "val_days": val_days,
                        "n_val": scored["n_val"],
                        "tickers_val": scored["tickers_val"],
                        "hit_10bp": scored["hit_10bp"],
                        "hit_20bp": scored["hit_20bp"],
                        "hit_30bp": scored["hit_30bp"],
                        "hit_40bp": scored["hit_40bp"],
                        "hit_50bp": scored["hit_50bp"],
                        "avg_best_move": scored["avg_best_move"],
                        "p15_best_move": scored["p15_best_move"],
                        "prev_hit_10bp": row.get("hit_10bp", np.nan),
                        "prev_hit_20bp": row.get("hit_20bp", np.nan),
                        "prev_avg_best_move": row.get("avg_best_move", np.nan),
                        "prev_p15_best_move": row.get("p15_best_move", np.nan),
                    }
                )

            if not out_rows:
                print(f"{side}: no labels scored for window {window_min}-{window_max}")
                continue

            out_df = pd.DataFrame(out_rows).sort_values(
                ["hit_20bp", "n_val"], ascending=[False, False]
            )
            ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
            out_path = Path(out_dir) / f"replay_{side}_{window_min}_{window_max}_{ts}.csv"
            out_df.to_csv(out_path, index=False)
            print(f"{side}: wrote {len(out_df)} rows to {out_path}")

    finally:
        await db.disconnect()


async def main() -> None:
    args = _parse_args()
    bull = _load_findings(args.bullish_file)
    bear = _load_findings(args.bearish_file)

    if not bull.empty:
        await _run_side(side="bullish", timespan=args.timespan, findings=bull, out_dir=args.out_dir)
    if not bear.empty:
        await _run_side(side="bearish", timespan=args.timespan, findings=bear, out_dir=args.out_dir)


if __name__ == "__main__":
    asyncio.run(main())
