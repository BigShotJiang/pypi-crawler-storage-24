from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

import pandas as pd


MONETIZATION_KEYWORDS = {
    "auth",
    "billing",
    "checkout",
    "customer",
    "invoice",
    "member",
    "oauth",
    "pay",
    "payment",
    "plan",
    "premium",
    "price",
    "pricing",
    "stripe",
    "subscribe",
    "subscription",
    "trial",
    "webhook",
}


def normalize_endpoint_df(df: pd.DataFrame) -> pd.DataFrame:
    required_columns = [
        "methods",
        "full_path",
        "file",
        "line",
        "func",
        "route_var",
        "include_prefix",
        "router_prefix",
        "route_path",
        "params_total",
        "params_required",
        "params_optional",
        "params_path",
        "params_query",
        "params_form",
        "params_body",
        "params_depends",
    ]
    for col in required_columns:
        if col not in df.columns:
            df[col] = "" if col in {"methods", "full_path", "file", "func", "route_var", "include_prefix", "router_prefix", "route_path"} else 0

    numeric_cols = [
        "line",
        "params_total",
        "params_required",
        "params_optional",
        "params_path",
        "params_query",
        "params_form",
        "params_body",
        "params_depends",
    ]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    text_cols = ["methods", "full_path", "file", "func", "route_var", "include_prefix", "router_prefix", "route_path"]
    for col in text_cols:
        df[col] = df[col].fillna("").astype(str)

    return df


def infer_monetization_endpoints(df: pd.DataFrame) -> pd.DataFrame:
    haystack = (
        df["full_path"].str.lower()
        + " "
        + df["func"].str.lower()
        + " "
        + df["file"].str.lower()
    )
    pattern = re.compile(r"\b(" + "|".join(sorted(MONETIZATION_KEYWORDS)) + r")\b")
    return df[haystack.str.contains(pattern, regex=True, na=False)].copy()


def top_path_segment(path: str) -> str:
    if not path or path == "/":
        return "root"
    p = path.strip("/")
    return p.split("/")[0] if p else "root"


def collect_repo_metrics(repo_root: Path) -> dict[str, Any]:
    py_files = list(repo_root.rglob("*.py"))
    py_lines_total = 0

    url_pattern = re.compile(r"https?://([A-Za-z0-9.-]+)")
    table_patterns = [
        re.compile(r"table_name\s*=\s*['\"]([^'\"]+)['\"]"),
        re.compile(r"INSERT\s+INTO\s+([A-Za-z_][A-Za-z0-9_]*)", re.IGNORECASE),
        re.compile(r"UPDATE\s+([A-Za-z_][A-Za-z0-9_]*)\s+SET", re.IGNORECASE),
    ]

    all_domains: set[str] = set()
    table_targets: set[str] = set()
    upsert_calls = 0
    insert_calls = 0

    for path in py_files:
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            try:
                text = path.read_text(encoding="latin-1")
            except Exception:
                continue
        except Exception:
            continue

        py_lines_total += text.count("\n") + 1
        upsert_calls += text.count("batch_upsert_dataframe(")
        insert_calls += text.count("batch_insert_dataframe(")

        for m in url_pattern.finditer(text):
            d = m.group(1).lower().strip(".")
            if d not in {"localhost", "127.0.0.1", "0.0.0.0"}:
                all_domains.add(d)

        for pat in table_patterns:
            for m in pat.finditer(text):
                table_targets.add(m.group(1))

    templates_dir = repo_root / "stock_market_site" / "templates"
    static_dir = repo_root / "stock_market_site" / "app" / "static"

    templates_html_count = len(list(templates_dir.glob("*.html"))) if templates_dir.exists() else 0
    static_js_count = len(list(static_dir.rglob("*.js"))) if static_dir.exists() else 0
    static_css_count = len(list(static_dir.rglob("*.css"))) if static_dir.exists() else 0

    return {
        "python_files": len(py_files),
        "python_lines_total": py_lines_total,
        "api_domains_public_count": len(all_domains),
        "upsert_calls": upsert_calls,
        "insert_calls": insert_calls,
        "unique_table_targets": len(table_targets),
        "templates_html_count": templates_html_count,
        "static_js_count": static_js_count,
        "static_css_count": static_css_count,
        "all_domains": sorted(all_domains),
        "table_targets": sorted(table_targets),
    }


def compute_readiness(snapshot_inputs: dict[str, Any]) -> float:
    monetization_count = snapshot_inputs["endpoint_monetization_count"]
    templates_html_count = snapshot_inputs["templates_html_count"]
    static_js_count = snapshot_inputs["static_js_count"]
    static_css_count = snapshot_inputs["static_css_count"]
    api_domains_public_count = snapshot_inputs["api_domains_public_count"]
    unique_table_targets = snapshot_inputs["unique_table_targets"]
    upsert_calls = snapshot_inputs["upsert_calls"]
    endpoint_count_total = snapshot_inputs["endpoint_count_total"]

    weighted = (
        0.24 * min(monetization_count / 50.0, 1.0)
        + 0.12 * min(templates_html_count / 100.0, 1.0)
        + 0.08 * min(static_js_count / 80.0, 1.0)
        + 0.04 * min(static_css_count / 40.0, 1.0)
        + 0.15 * min(api_domains_public_count / 80.0, 1.0)
        + 0.14 * min(unique_table_targets / 450.0, 1.0)
        + 0.12 * min(upsert_calls / 500.0, 1.0)
        + 0.11 * min(endpoint_count_total / 600.0, 1.0)
    )
    return round(min(0.92, 0.35 + (0.65 * weighted)), 4)


def compute_valuation(snapshot: dict[str, Any]) -> dict[str, Any]:
    endpoint_avg_complexity = float(snapshot["endpoint_avg_complexity"])
    readiness = float(snapshot["readiness_score"])

    backend_hours = snapshot["python_lines_total"] / 80.0
    endpoint_hours = snapshot["endpoint_count_total"] * (1.2 + (0.22 * endpoint_avg_complexity))
    data_hours = (
        snapshot["unique_table_targets"] * 2.1
        + snapshot["upsert_calls"] * 1.1
        + snapshot["api_domains_public_count"] * 6.5
    )
    frontend_hours = (
        snapshot["templates_html_count"] * 3.2
        + snapshot["static_js_count"] * 5.5
        + snapshot["static_css_count"] * 2.0
    )
    ops_hours = 180.0 + (snapshot["endpoint_monetization_count"] * 8.0)

    total_hours = backend_hours + endpoint_hours + data_hours + frontend_hours + ops_hours
    blended_rate_usd = 165.0

    replacement_base_as_is = total_hours * blended_rate_usd
    replacement_range_low = replacement_base_as_is * (0.38 + (0.12 * readiness))
    replacement_range_high = replacement_base_as_is * (1.65 + (0.40 * readiness))
    replacement_mid = (replacement_range_low + replacement_range_high) / 2.0

    commercialized_expected = replacement_base_as_is * (1.9 + (0.85 * readiness))
    option_capture_value = commercialized_expected * (0.24 + (0.07 * readiness))
    strategic_mid = replacement_base_as_is * (0.48 + (0.28 * readiness))

    reconciled_mid = (
        (0.60 * replacement_mid)
        + (0.25 * strategic_mid)
        + (0.15 * option_capture_value)
    )

    final_range_low = reconciled_mid * 0.72
    final_range_high = reconciled_mid * 1.70
    ask_band_low = reconciled_mid * 0.86
    ask_band_high = reconciled_mid * 1.28

    return {
        "model_inputs": {
            "backend_hours": round(backend_hours, 2),
            "endpoint_hours": round(endpoint_hours, 2),
            "data_hours": round(data_hours, 2),
            "frontend_hours": round(frontend_hours, 2),
            "ops_hours": round(ops_hours, 2),
            "total_hours": round(total_hours, 2),
            "blended_rate_usd": blended_rate_usd,
        },
        "replacement_base_as_is": round(replacement_base_as_is, 2),
        "replacement_range_low": round(replacement_range_low, 2),
        "replacement_range_high": round(replacement_range_high, 2),
        "commercialized_expected": round(commercialized_expected, 2),
        "option_capture_value": round(option_capture_value, 2),
        "strategic_mid": round(strategic_mid, 2),
        "reconciled_mid": round(reconciled_mid, 2),
        "final_range_low": round(final_range_low, 2),
        "final_range_high": round(final_range_high, 2),
        "ask_band_low": round(ask_band_low, 2),
        "ask_band_high": round(ask_band_high, 2),
    }


def build_assessment(
    repo_root: Path,
    endpoint_inventory_csv: Path,
    monetization_csv: Path | None,
) -> dict[str, Any]:
    endpoint_df = normalize_endpoint_df(pd.read_csv(endpoint_inventory_csv))

    if monetization_csv and monetization_csv.exists():
        monetization_df = normalize_endpoint_df(pd.read_csv(monetization_csv))
    else:
        monetization_df = infer_monetization_endpoints(endpoint_df)

    endpoint_df["top_segment"] = endpoint_df["full_path"].map(top_path_segment)
    endpoint_df["complexity"] = (
        endpoint_df["params_total"]
        + (2.0 * endpoint_df["params_body"])
        + (1.5 * endpoint_df["params_form"])
        + (1.2 * endpoint_df["params_query"])
        + (1.2 * endpoint_df["params_path"])
        + (2.0 * endpoint_df["params_depends"])
    )

    method_counts = {k: int(v) for k, v in endpoint_df["methods"].value_counts().to_dict().items()}
    top_path_segments = [
        (k, int(v))
        for k, v in endpoint_df["top_segment"].value_counts().head(40).to_dict().items()
    ]
    top_route_files = [
        (k, int(v))
        for k, v in endpoint_df["file"].value_counts().head(40).to_dict().items()
    ]

    repo_metrics = collect_repo_metrics(repo_root)

    endpoint_option_stats = {
        "with_query": int((endpoint_df["params_query"] > 0).sum()),
        "with_path": int((endpoint_df["params_path"] > 0).sum()),
        "with_form": int((endpoint_df["params_form"] > 0).sum()),
        "with_body": int((endpoint_df["params_body"] > 0).sum()),
        "with_depends": int((endpoint_df["params_depends"] > 0).sum()),
        "required_params_total": int(endpoint_df["params_required"].sum()),
        "optional_params_total": int(endpoint_df["params_optional"].sum()),
        "avg_params_per_endpoint": round(float(endpoint_df["params_total"].mean()), 3),
        "p95_complexity": round(float(endpoint_df["complexity"].quantile(0.95)), 3),
        "max_complexity": round(float(endpoint_df["complexity"].max()), 3),
    }

    snapshot = {
        "python_files": repo_metrics["python_files"],
        "python_lines_total": repo_metrics["python_lines_total"],
        "api_domains_public_count": repo_metrics["api_domains_public_count"],
        "upsert_calls": repo_metrics["upsert_calls"],
        "insert_calls": repo_metrics["insert_calls"],
        "unique_table_targets": repo_metrics["unique_table_targets"],
        "templates_html_count": repo_metrics["templates_html_count"],
        "static_js_count": repo_metrics["static_js_count"],
        "static_css_count": repo_metrics["static_css_count"],
        "endpoint_count_total": int(len(endpoint_df)),
        "endpoint_monetization_count": int(len(monetization_df)),
        "endpoint_avg_complexity": round(float(endpoint_df["complexity"].mean()), 3),
        "endpoint_option_stats": endpoint_option_stats,
    }
    snapshot["readiness_score"] = compute_readiness(snapshot)

    top_complex_endpoints = (
        endpoint_df.sort_values("complexity", ascending=False)
        .drop(columns=["top_segment", "complexity"])
        .head(40)
        .to_dict(orient="records")
    )

    valuation = compute_valuation(snapshot)

    return {
        "snapshot": snapshot,
        "endpoint_inventory": endpoint_df.drop(columns=["top_segment", "complexity"]).to_dict(orient="records"),
        "method_counts": method_counts,
        "top_path_segments": top_path_segments,
        "top_route_files": top_route_files,
        "top_complex_endpoints": top_complex_endpoints,
        "valuation": valuation,
        "repo_metadata": {
            "domains": repo_metrics["all_domains"],
            "table_targets": repo_metrics["table_targets"],
        },
    }


def write_outputs(assessment: dict[str, Any], output_json: Path, summary_json: Path) -> None:
    output_json.parent.mkdir(parents=True, exist_ok=True)
    summary_json.parent.mkdir(parents=True, exist_ok=True)

    output_json.write_text(json.dumps(assessment, indent=2), encoding="utf-8")

    summary = {
        "endpoint_total": assessment["snapshot"]["endpoint_count_total"],
        "monetization_endpoint_total": assessment["snapshot"]["endpoint_monetization_count"],
        "method_counts": assessment["method_counts"],
        "top_segments": assessment["top_path_segments"][:25],
        "top_route_files": assessment["top_route_files"][:25],
        "snapshot": assessment["snapshot"],
        "valuation": assessment["valuation"],
    }
    summary_json.write_text(json.dumps(summary, indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate deep repository endpoint + valuation assessment JSON.")
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Repository root path.",
    )
    parser.add_argument(
        "--endpoint-csv",
        type=Path,
        default=Path(r"c:\code\fudstop\output\reports\endpoint_inventory_full.csv"),
        help="Endpoint inventory CSV path.",
    )
    parser.add_argument(
        "--monetization-csv",
        type=Path,
        default=Path(r"c:\code\fudstop\output\reports\endpoint_inventory_monetization.csv"),
        help="Monetization endpoint CSV path.",
    )
    parser.add_argument(
        "--output-json",
        type=Path,
        default=Path(r"c:\code\fudstop\tmp\pdfs\repo_deep_assessment_v2.json"),
        help="Output deep assessment JSON path.",
    )
    parser.add_argument(
        "--summary-json",
        type=Path,
        default=Path(r"c:\code\fudstop\output\reports\endpoint_assessment_summary_v2.json"),
        help="Output summary JSON path.",
    )
    args = parser.parse_args()

    if not args.endpoint_csv.exists():
        raise FileNotFoundError(f"Endpoint inventory CSV not found: {args.endpoint_csv}")

    monetization_csv = args.monetization_csv if args.monetization_csv.exists() else None
    assessment = build_assessment(args.repo_root, args.endpoint_csv, monetization_csv)
    write_outputs(assessment, args.output_json, args.summary_json)
    print(str(args.output_json))
    print(str(args.summary_json))


if __name__ == "__main__":
    main()
