from __future__ import annotations

import argparse
import ast
import json
import re
import warnings
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import pandas as pd

warnings.filterwarnings("ignore", category=SyntaxWarning)


HTTP_DECORATORS = {
    "get": "GET",
    "post": "POST",
    "put": "PUT",
    "patch": "PATCH",
    "delete": "DELETE",
    "options": "OPTIONS",
    "head": "HEAD",
    "websocket": "WEBSOCKET",
    "api_route": "API_ROUTE",
}

MONETIZATION_KEYWORDS = {
    "auth",
    "billing",
    "checkout",
    "customer",
    "invoice",
    "member",
    "oauth",
    "pay",
    "payment",
    "plan",
    "premium",
    "price",
    "pricing",
    "stripe",
    "subscribe",
    "subscription",
    "trial",
    "webhook",
}


def safe_read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            return path.read_text(encoding="latin-1")
        except Exception:
            return ""
    except Exception:
        return ""


def func_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return ""


def to_str(node: ast.AST | None) -> str | None:
    if node is None:
        return None
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def get_path_params(path: str) -> set[str]:
    return set(re.findall(r"{([^}:]+)", path or ""))


def is_required_param(default_node: ast.AST | None, call_name: str) -> bool:
    if default_node is None:
        return True
    if call_name == "Depends":
        return False
    if not isinstance(default_node, ast.Call):
        return False

    default_value_node = None
    if default_node.args:
        default_value_node = default_node.args[0]
    for kw in default_node.keywords:
        if kw.arg == "default":
            default_value_node = kw.value
            break

    if default_value_node is None:
        return True
    if isinstance(default_value_node, ast.Constant) and default_value_node.value is None:
        return False
    if isinstance(default_value_node, ast.Constant) and default_value_node.value is Ellipsis:
        return True
    if isinstance(default_value_node, ast.Name) and default_value_node.id == "Ellipsis":
        return True
    return False


def normalize_path(path: str) -> str:
    if not path:
        return ""
    if path == "/":
        return ""
    x = path.strip()
    if not x.startswith("/"):
        x = "/" + x
    return x.rstrip("/")


def join_paths(*parts: str) -> str:
    normalized = [normalize_path(p) for p in parts if p is not None]
    out = "".join(p for p in normalized if p)
    return out if out else "/"


def infer_segment(path: str) -> str:
    if path == "/":
        return "root"
    p = path.strip("/")
    return p.split("/")[0] if p else "root"


def parse_router_prefixes(tree: ast.AST) -> dict[str, str]:
    prefixes: dict[str, str] = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if not node.targets:
            continue
        if not isinstance(node.targets[0], ast.Name):
            continue
        target_name = node.targets[0].id
        if not isinstance(node.value, ast.Call):
            continue
        if func_name(node.value.func) != "APIRouter":
            continue
        prefix = ""
        for kw in node.value.keywords:
            if kw.arg == "prefix":
                prefix = to_str(kw.value) or ""
                break
        prefixes[target_name] = prefix
    return prefixes


def parse_include_router_prefixes(tree: ast.AST) -> dict[str, list[str]]:
    include_map: dict[str, list[str]] = defaultdict(list)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "include_router":
            continue
        if not node.args:
            continue
        router_arg = node.args[0]
        if isinstance(router_arg, ast.Name):
            router_name = router_arg.id
        elif isinstance(router_arg, ast.Attribute):
            router_name = router_arg.attr
        else:
            continue
        prefix = ""
        for kw in node.keywords:
            if kw.arg == "prefix":
                prefix = to_str(kw.value) or ""
                break
        include_map[router_name].append(prefix)
    return include_map


def analyze_params(func: ast.FunctionDef | ast.AsyncFunctionDef, route_path: str) -> dict[str, int]:
    path_params = get_path_params(route_path)
    counts = {
        "params_total": 0,
        "params_required": 0,
        "params_optional": 0,
        "params_path": 0,
        "params_query": 0,
        "params_form": 0,
        "params_body": 0,
        "params_depends": 0,
    }

    pos_args = list(func.args.posonlyargs) + list(func.args.args)
    pos_defaults = [None] * (len(pos_args) - len(func.args.defaults)) + list(func.args.defaults)
    kw_args = list(func.args.kwonlyargs)
    kw_defaults = list(func.args.kw_defaults)

    pairs: list[tuple[ast.arg, ast.AST | None]] = []
    pairs.extend(zip(pos_args, pos_defaults))
    pairs.extend(zip(kw_args, kw_defaults))

    for index, (arg, default_node) in enumerate(pairs):
        arg_name = arg.arg
        if index == 0 and arg_name in {"self", "cls"}:
            continue
        counts["params_total"] += 1

        call = default_node if isinstance(default_node, ast.Call) else None
        call_name = func_name(call.func) if call else ""

        if arg_name in path_params or call_name == "Path":
            counts["params_path"] += 1
        elif call_name == "Form":
            counts["params_form"] += 1
        elif call_name == "Body":
            counts["params_body"] += 1
        elif call_name == "Depends":
            counts["params_depends"] += 1
        else:
            counts["params_query"] += 1

        required = is_required_param(default_node, call_name)
        if required:
            counts["params_required"] += 1
        else:
            counts["params_optional"] += 1
    return counts


def scan_endpoint_inventory(app_root: Path) -> pd.DataFrame:
    py_files = sorted(app_root.rglob("*.py"))

    router_prefix_by_name: dict[str, str] = {}
    include_prefix_by_name: dict[str, list[str]] = defaultdict(list)
    parsed_trees: list[tuple[Path, ast.AST]] = []

    for path in py_files:
        text = safe_read_text(path)
        if not text:
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        parsed_trees.append((path, tree))
        router_prefix_by_name.update(parse_router_prefixes(tree))
        include_map = parse_include_router_prefixes(tree)
        for k, vals in include_map.items():
            include_prefix_by_name[k].extend(vals)

    rows: list[dict[str, Any]] = []
    for path, tree in parsed_trees:
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for dec in node.decorator_list:
                if not isinstance(dec, ast.Call):
                    continue
                if not isinstance(dec.func, ast.Attribute):
                    continue
                method_key = dec.func.attr
                if method_key not in HTTP_DECORATORS:
                    continue

                route_var = ""
                if isinstance(dec.func.value, ast.Name):
                    route_var = dec.func.value.id
                elif isinstance(dec.func.value, ast.Attribute):
                    route_var = dec.func.value.attr

                route_path = to_str(dec.args[0]) if dec.args else ""
                route_path = route_path or ""
                router_prefix = router_prefix_by_name.get(route_var, "")
                include_prefixes = include_prefix_by_name.get(route_var, [""])
                if not include_prefixes:
                    include_prefixes = [""]

                methods: list[str]
                if method_key == "api_route":
                    methods = []
                    for kw in dec.keywords:
                        if kw.arg == "methods" and isinstance(kw.value, (ast.List, ast.Tuple)):
                            for m in kw.value.elts:
                                if isinstance(m, ast.Constant) and isinstance(m.value, str):
                                    methods.append(m.value.upper())
                    if not methods:
                        methods = ["API_ROUTE"]
                else:
                    methods = [HTTP_DECORATORS[method_key]]

                param_counts = analyze_params(node, route_path)
                for include_prefix in include_prefixes:
                    full_path = join_paths(include_prefix, router_prefix, route_path)
                    for m in methods:
                        rows.append(
                            {
                                "file": str(path.as_posix()),
                                "line": int(node.lineno),
                                "func": node.name,
                                "route_var": route_var,
                                "include_prefix": include_prefix,
                                "router_prefix": router_prefix,
                                "route_path": route_path,
                                "methods": m,
                                "full_path": full_path,
                                **param_counts,
                            }
                        )
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df = df.sort_values(["file", "line", "methods", "full_path"]).reset_index(drop=True)
    return df


def select_monetization_endpoints(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df.copy()
    pattern = re.compile(r"\b(?:" + "|".join(sorted(MONETIZATION_KEYWORDS)) + r")\b")
    haystack = (
        df["full_path"].str.lower()
        + " "
        + df["func"].str.lower()
        + " "
        + df["file"].str.lower()
    )
    mask = haystack.str.contains(pattern, regex=True, na=False)
    return df[mask].copy()


def extract_sql_tables(sql_text: str) -> set[str]:
    out: set[str] = set()
    patterns = [
        re.compile(r"\bINSERT\s+INTO\s+([A-Za-z_][A-Za-z0-9_]*)", re.IGNORECASE),
        re.compile(r"\bUPDATE\s+([A-Za-z_][A-Za-z0-9_]*)\s+SET\b", re.IGNORECASE),
        re.compile(r"\bCREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+([A-Za-z_][A-Za-z0-9_]*)", re.IGNORECASE),
        re.compile(r"\bALTER\s+TABLE\s+([A-Za-z_][A-Za-z0-9_]*)", re.IGNORECASE),
        re.compile(r"\bFROM\s+([A-Za-z_][A-Za-z0-9_]*)", re.IGNORECASE),
    ]
    for pat in patterns:
        for m in pat.finditer(sql_text):
            out.add(m.group(1).lower())
    return out


def extract_literal_table_from_call(call: ast.Call) -> str | None:
    for kw in call.keywords:
        if kw.arg == "table_name":
            return to_str(kw.value)
    if len(call.args) >= 2:
        return to_str(call.args[1])
    return None


def scan_database_integration(repo_root: Path, py_files: list[Path]) -> dict[str, Any]:
    asyncpg_import_files: set[str] = set()
    db_execution_callsites = 0
    raw_sql_execute_callsites = 0
    create_pool_calls = 0
    asyncpg_connect_calls = 0
    info_schema_hits = 0
    sql_keyword_hits = 0
    batch_upsert_calls = 0
    batch_insert_calls = 0
    upsert_tables: list[str] = []
    raw_sql_tables: set[str] = set()

    sql_keywords = re.compile(
        r"\b(SELECT|INSERT|UPDATE|DELETE|CREATE\s+TABLE|ALTER\s+TABLE|DROP\s+TABLE|ON\s+CONFLICT|JOIN)\b",
        re.IGNORECASE,
    )
    url_pattern = re.compile(r"https?://([A-Za-z0-9.-]+)")
    table_name_pattern = re.compile(r"table_name\s*=\s*['\"]([^'\"]+)['\"]")
    public_domains: set[str] = set()

    for path in py_files:
        text = safe_read_text(path)
        if not text:
            continue

        path_str = str(path.as_posix())
        if re.search(r"\bimport\s+asyncpg\b|\bfrom\s+asyncpg\s+import\b", text):
            asyncpg_import_files.add(path_str)
        if "information_schema" in text:
            info_schema_hits += text.count("information_schema")
        sql_keyword_hits += len(sql_keywords.findall(text))
        asyncpg_connect_calls += len(re.findall(r"asyncpg\.connect\(", text))

        for m in table_name_pattern.finditer(text):
            upsert_tables.append(m.group(1).lower())
        for domain_match in url_pattern.finditer(text):
            d = domain_match.group(1).lower().strip(".")
            if d not in {"localhost", "127.0.0.1", "0.0.0.0"}:
                public_domains.add(d)

        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = func_name(node.func)
            if name == "create_pool":
                create_pool_calls += 1
            if name in {"execute", "executemany", "fetch", "fetchrow", "fetchval"}:
                db_execution_callsites += 1
                if node.args:
                    sql = to_str(node.args[0])
                    if sql and re.search(r"\b(SELECT|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP)\b", sql, re.IGNORECASE):
                        raw_sql_execute_callsites += 1
                        raw_sql_tables.update(extract_sql_tables(sql))
            if name == "batch_upsert_dataframe":
                batch_upsert_calls += 1
                table_name = extract_literal_table_from_call(node)
                if table_name:
                    upsert_tables.append(table_name.lower())
            if name == "batch_insert_dataframe":
                batch_insert_calls += 1
                table_name = extract_literal_table_from_call(node)
                if table_name:
                    upsert_tables.append(table_name.lower())

    unique_table_targets = sorted(set(t for t in upsert_tables if t))
    all_db_tables = sorted(set(unique_table_targets).union(raw_sql_tables))

    fragmentation_ratio = asyncpg_connect_calls / max(1, create_pool_calls)
    return {
        "asyncpg_import_files_count": len(asyncpg_import_files),
        "create_pool_calls": create_pool_calls,
        "direct_asyncpg_connect_calls": asyncpg_connect_calls,
        "db_execution_callsites": db_execution_callsites,
        "raw_sql_execute_callsites": raw_sql_execute_callsites,
        "information_schema_hits": info_schema_hits,
        "sql_keyword_hits": sql_keyword_hits,
        "batch_upsert_calls": batch_upsert_calls,
        "batch_insert_calls": batch_insert_calls,
        "unique_table_targets_count": len(unique_table_targets),
        "all_db_tables_count": len(all_db_tables),
        "fragmentation_ratio": round(fragmentation_ratio, 3),
        "top_table_targets": Counter(upsert_tables).most_common(40),
        "public_domains_count": len(public_domains),
        "public_domains": sorted(public_domains),
        "table_targets": unique_table_targets,
        "all_db_tables": all_db_tables,
    }


def scan_confluence_system(repo_root: Path, endpoint_df: pd.DataFrame, db_metrics: dict[str, Any]) -> dict[str, Any]:
    candidate_ext = {".py", ".html", ".js", ".css"}
    matched_files: list[Path] = []
    ext_counter: Counter[str] = Counter()
    line_total = 0

    for path in repo_root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in candidate_ext:
            continue
        p = str(path.as_posix()).lower()
        text = safe_read_text(path)
        if "confluence" in p or "confluence" in text.lower():
            matched_files.append(path)
            ext_counter[path.suffix.lower()] += 1
            line_total += (text.count("\n") + 1) if text else 0

    confluence_endpoints = endpoint_df[
        endpoint_df["full_path"].str.contains("confluence", case=False, na=False)
        | endpoint_df["file"].str.contains("confluence", case=False, na=False)
        | endpoint_df["func"].str.contains("confluence", case=False, na=False)
    ].copy()

    confluence_tables = [
        t for t in db_metrics.get("table_targets", []) if "confluence" in t.lower()
    ]

    score_function_count = 0
    score_functions: list[str] = []
    confluence_impl_files = [
        repo_root / "UTILS" / "confluence.py",
        repo_root / "stock_market_site" / "UTILS" / "confluence.py",
        repo_root / "stock_market_site" / "app" / "UTILS2" / "confluence.py",
    ]
    for cf in confluence_impl_files:
        if not cf.exists():
            continue
        text = safe_read_text(cf)
        if not text:
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name.startswith("score_"):
                score_functions.append(node.name)
                score_function_count += 1

    confluence_templates = []
    for p in (repo_root / "stock_market_site" / "templates").glob("*.html"):
        txt = safe_read_text(p)
        if "confluence" in p.name.lower() or "confluence" in txt.lower():
            confluence_templates.append(
                {"file": str(p.as_posix()), "lines": txt.count("\n") + 1}
            )

    confluence_scripts = []
    for base in [repo_root / "scripts", repo_root / "stock_market_site" / "scripts"]:
        if not base.exists():
            continue
        for p in base.glob("*confluence*.py"):
            txt = safe_read_text(p)
            confluence_scripts.append({"file": str(p.as_posix()), "lines": txt.count("\n") + 1})

    return {
        "files_with_confluence_count": len(matched_files),
        "confluence_lines_total": line_total,
        "confluence_file_ext_counts": dict(ext_counter),
        "confluence_endpoints_count": int(len(confluence_endpoints)),
        "confluence_endpoint_files_top": Counter(confluence_endpoints["file"]).most_common(20),
        "confluence_tables_count": len(confluence_tables),
        "confluence_tables": sorted(confluence_tables),
        "confluence_score_function_count": score_function_count,
        "confluence_score_functions": sorted(set(score_functions)),
        "confluence_templates_count": len(confluence_templates),
        "confluence_templates": confluence_templates,
        "confluence_scripts_count": len(confluence_scripts),
        "confluence_scripts": confluence_scripts,
    }


def scan_model_architecture(repo_root: Path) -> dict[str, Any]:
    model_files = [
        p
        for p in repo_root.rglob("*.py")
        if "/models/" in p.as_posix().replace("\\", "/")
        and p.name != "__init__.py"
    ]
    classes_total = 0
    classes_with_data_dict = 0
    classes_with_as_dataframe = 0
    classes_with_both = 0
    classes_with_df_attr = 0
    total_listcomp_assignments = 0

    class_rows: list[dict[str, Any]] = []
    for path in model_files:
        text = safe_read_text(path)
        if not text:
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        for node in tree.body:
            if not isinstance(node, ast.ClassDef):
                continue
            classes_total += 1
            has_data_dict = False
            has_as_dataframe = False
            has_df_attr = False
            listcomp_assignments = 0

            for sub in ast.walk(node):
                if isinstance(sub, ast.Assign):
                    targets = sub.targets
                elif isinstance(sub, ast.AnnAssign):
                    targets = [sub.target]
                else:
                    continue

                for t in targets:
                    if isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name) and t.value.id == "self":
                        if t.attr == "data_dict":
                            has_data_dict = True
                        if t.attr == "as_dataframe":
                            has_as_dataframe = True
                        if t.attr == "df":
                            has_df_attr = True
                        if isinstance(sub.value, ast.ListComp):
                            listcomp_assignments += 1

            classes_with_data_dict += int(has_data_dict)
            classes_with_as_dataframe += int(has_as_dataframe)
            classes_with_df_attr += int(has_df_attr)
            classes_with_both += int(has_data_dict and has_as_dataframe)
            total_listcomp_assignments += listcomp_assignments

            class_rows.append(
                {
                    "file": str(path.as_posix()),
                    "class": node.name,
                    "has_data_dict": has_data_dict,
                    "has_as_dataframe": has_as_dataframe,
                    "has_df_attr": has_df_attr,
                    "listcomp_assignments": listcomp_assignments,
                }
            )

    compliance_ratio = (classes_with_both / classes_total) if classes_total else 0.0
    as_dataframe_ratio = (classes_with_as_dataframe / classes_total) if classes_total else 0.0
    data_dict_ratio = (classes_with_data_dict / classes_total) if classes_total else 0.0

    return {
        "model_files_count": len(model_files),
        "model_classes_total": classes_total,
        "classes_with_data_dict": classes_with_data_dict,
        "classes_with_as_dataframe": classes_with_as_dataframe,
        "classes_with_both": classes_with_both,
        "classes_with_df_attr": classes_with_df_attr,
        "total_listcomp_assignments": total_listcomp_assignments,
        "avg_listcomp_assignments_per_class": round(
            total_listcomp_assignments / classes_total, 3
        )
        if classes_total
        else 0.0,
        "canonical_model_compliance_ratio": round(compliance_ratio, 4),
        "as_dataframe_coverage_ratio": round(as_dataframe_ratio, 4),
        "data_dict_coverage_ratio": round(data_dict_ratio, 4),
        "sample_classes": class_rows[:80],
    }


def compute_readiness(
    endpoint_df: pd.DataFrame,
    monetization_df: pd.DataFrame,
    db_metrics: dict[str, Any],
    confluence_metrics: dict[str, Any],
    model_metrics: dict[str, Any],
    templates_count: int,
    static_js_count: int,
    static_css_count: int,
) -> dict[str, float]:
    endpoint_total = max(1, len(endpoint_df))
    monetization_count = len(monetization_df)
    stripe_count = int(
        endpoint_df["full_path"].str.contains("stripe", case=False, na=False).sum()
    )
    oauth_count = int(
        endpoint_df["full_path"].str.contains("oauth|auth", case=False, regex=True, na=False).sum()
    )
    webhook_count = int(
        endpoint_df["full_path"].str.contains("webhook", case=False, na=False).sum()
    )
    subscription_count = int(
        endpoint_df["full_path"].str.contains("subscription|subscribe|member", case=False, regex=True, na=False).sum()
    )

    monetization_surface = min(monetization_count / 45.0, 1.0)
    billing_stack = min((stripe_count + webhook_count + subscription_count + oauth_count) / 40.0, 1.0)
    endpoint_depth = min(endpoint_total / 550.0, 1.0)
    endpoint_options = min(float(endpoint_df["params_total"].mean() if not endpoint_df.empty else 0.0) / 2.0, 1.0)
    db_depth = min(db_metrics["unique_table_targets_count"] / 420.0, 1.0)
    db_operations = min(
        (db_metrics["batch_upsert_calls"] + db_metrics["batch_insert_calls"]) / 700.0, 1.0
    )
    confluence_moat = min(
        (
            confluence_metrics["confluence_endpoints_count"]
            + confluence_metrics["confluence_scripts_count"]
            + confluence_metrics["confluence_score_function_count"]
        )
        / 90.0,
        1.0,
    )
    frontend_surface = min(
        (templates_count + static_js_count + static_css_count) / 210.0, 1.0
    )
    model_governance = float(model_metrics["canonical_model_compliance_ratio"])

    weighted = (
        0.17 * monetization_surface
        + 0.10 * billing_stack
        + 0.11 * endpoint_depth
        + 0.07 * endpoint_options
        + 0.13 * db_depth
        + 0.10 * db_operations
        + 0.11 * confluence_moat
        + 0.09 * frontend_surface
        + 0.12 * model_governance
    )
    readiness = round(min(0.94, 0.34 + 0.66 * weighted), 4)
    return {
        "monetization_surface": round(monetization_surface, 4),
        "billing_stack": round(billing_stack, 4),
        "endpoint_depth": round(endpoint_depth, 4),
        "endpoint_options": round(endpoint_options, 4),
        "db_depth": round(db_depth, 4),
        "db_operations": round(db_operations, 4),
        "confluence_moat": round(confluence_moat, 4),
        "frontend_surface": round(frontend_surface, 4),
        "model_governance": round(model_governance, 4),
        "readiness_score": readiness,
    }


def compute_valuation(
    python_lines_total: int,
    endpoint_df: pd.DataFrame,
    db_metrics: dict[str, Any],
    confluence_metrics: dict[str, Any],
    model_metrics: dict[str, Any],
    templates_count: int,
    static_js_count: int,
    static_css_count: int,
    readiness: dict[str, float],
) -> dict[str, Any]:
    endpoint_total = len(endpoint_df)
    avg_complexity = float(endpoint_df["complexity"].mean() if not endpoint_df.empty else 0.0)
    readiness_score = readiness["readiness_score"]

    core_backend_hours = python_lines_total / 72.0
    endpoint_surface_hours = endpoint_total * (1.35 + 0.25 * avg_complexity)
    db_integration_hours = (
        db_metrics["unique_table_targets_count"] * 2.4
        + db_metrics["batch_upsert_calls"] * 1.6
        + db_metrics["batch_insert_calls"] * 1.1
        + db_metrics["raw_sql_execute_callsites"] * 0.9
        + db_metrics["asyncpg_import_files_count"] * 5.0
        + db_metrics["create_pool_calls"] * 1.2
        + db_metrics["information_schema_hits"] * 0.15
    )
    confluence_hours = (
        confluence_metrics["files_with_confluence_count"] * 6.0
        + confluence_metrics["confluence_endpoints_count"] * 8.0
        + confluence_metrics["confluence_score_function_count"] * 5.0
        + (confluence_metrics["confluence_lines_total"] / 300.0)
    )
    model_layer_hours = (
        model_metrics["model_classes_total"] * 3.2
        + model_metrics["total_listcomp_assignments"] * 0.15
        + (1.0 - model_metrics["canonical_model_compliance_ratio"]) * 120.0
    )
    frontend_hours = (
        templates_count * 3.5
        + static_js_count * 6.0
        + static_css_count * 2.4
    )
    integration_hours = (
        db_metrics["public_domains_count"] * 7.0
        + db_metrics["asyncpg_import_files_count"] * 2.5
        + len(select_monetization_endpoints(endpoint_df)) * 4.5
    )
    websocket_endpoints = int((endpoint_df["methods"] == "WEBSOCKET").sum()) if not endpoint_df.empty else 0
    ops_hours = 280.0 + len(select_monetization_endpoints(endpoint_df)) * 10.0 + websocket_endpoints * 18.0

    total_hours = (
        core_backend_hours
        + endpoint_surface_hours
        + db_integration_hours
        + confluence_hours
        + model_layer_hours
        + frontend_hours
        + integration_hours
        + ops_hours
    )

    blended_rate_usd = 172.0
    replacement_base = total_hours * blended_rate_usd

    governance = 0.82 + 0.25 * model_metrics["canonical_model_compliance_ratio"] - 0.05 * min(
        db_metrics["fragmentation_ratio"], 2.0
    )
    governance = max(0.65, min(1.05, governance))

    replacement_low = replacement_base * (0.42 + 0.10 * readiness_score) * governance
    replacement_high = replacement_base * (1.70 + 0.45 * readiness_score) * max(0.9, governance + 0.08)
    replacement_mid = (replacement_low + replacement_high) / 2.0

    strategic_mid = replacement_base * (0.55 + 0.35 * readiness_score) * (
        0.95 + 0.12 * readiness["confluence_moat"]
    )
    commercialized_expected = replacement_base * (2.05 + 0.95 * readiness_score) * (
        0.90 + 0.15 * readiness["monetization_surface"]
    )
    option_capture = commercialized_expected * (0.24 + 0.09 * readiness_score)

    reconciled_mid = (
        0.55 * replacement_mid
        + 0.25 * strategic_mid
        + 0.20 * option_capture
    )
    final_low = reconciled_mid * 0.75
    final_high = reconciled_mid * 1.72
    ask_low = reconciled_mid * 0.88
    ask_high = reconciled_mid * 1.30

    return {
        "model_inputs": {
            "core_backend_hours": round(core_backend_hours, 2),
            "endpoint_surface_hours": round(endpoint_surface_hours, 2),
            "db_integration_hours": round(db_integration_hours, 2),
            "confluence_hours": round(confluence_hours, 2),
            "model_layer_hours": round(model_layer_hours, 2),
            "frontend_hours": round(frontend_hours, 2),
            "integration_hours": round(integration_hours, 2),
            "ops_hours": round(ops_hours, 2),
            "total_hours": round(total_hours, 2),
            "blended_rate_usd": blended_rate_usd,
            "governance_factor": round(governance, 4),
        },
        "replacement_base_as_is": round(replacement_base, 2),
        "replacement_range_low": round(replacement_low, 2),
        "replacement_range_high": round(replacement_high, 2),
        "commercialized_expected": round(commercialized_expected, 2),
        "option_capture_value": round(option_capture, 2),
        "strategic_mid": round(strategic_mid, 2),
        "reconciled_mid": round(reconciled_mid, 2),
        "final_range_low": round(final_low, 2),
        "final_range_high": round(final_high, 2),
        "ask_band_low": round(ask_low, 2),
        "ask_band_high": round(ask_high, 2),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate full-sweep FUDSTOP assessment JSON + CSV artifacts.")
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Repository root path.",
    )
    parser.add_argument(
        "--output-json",
        type=Path,
        default=Path(r"c:\code\fudstop\tmp\pdfs\repo_full_sweep_assessment_v1.json"),
        help="Full output JSON path.",
    )
    parser.add_argument(
        "--summary-json",
        type=Path,
        default=Path(r"c:\code\fudstop\output\reports\repo_full_sweep_summary_v1.json"),
        help="Summary JSON path.",
    )
    parser.add_argument(
        "--endpoint-csv",
        type=Path,
        default=Path(r"c:\code\fudstop\output\reports\endpoint_inventory_full_v2.csv"),
        help="Output endpoint inventory CSV path.",
    )
    parser.add_argument(
        "--monetization-csv",
        type=Path,
        default=Path(r"c:\code\fudstop\output\reports\endpoint_inventory_monetization_v2.csv"),
        help="Output monetization endpoint CSV path.",
    )
    args = parser.parse_args()

    repo_root = args.repo_root.resolve()
    app_root = repo_root / "stock_market_site" / "app"
    py_files = list(repo_root.rglob("*.py"))
    python_lines_total = sum((safe_read_text(p).count("\n") + 1) for p in py_files)

    endpoint_df = scan_endpoint_inventory(app_root)
    if endpoint_df.empty:
        raise RuntimeError("No endpoints discovered in stock_market_site/app.")

    monetization_df = select_monetization_endpoints(endpoint_df)

    endpoint_df["top_segment"] = endpoint_df["full_path"].map(infer_segment)
    endpoint_df["complexity"] = (
        endpoint_df["params_total"]
        + 2.0 * endpoint_df["params_body"]
        + 1.5 * endpoint_df["params_form"]
        + 1.2 * endpoint_df["params_query"]
        + 1.2 * endpoint_df["params_path"]
        + 2.0 * endpoint_df["params_depends"]
    )

    db_metrics = scan_database_integration(repo_root, py_files)
    confluence_metrics = scan_confluence_system(repo_root, endpoint_df, db_metrics)
    model_metrics = scan_model_architecture(repo_root)

    templates_dir = repo_root / "stock_market_site" / "templates"
    static_dir = repo_root / "stock_market_site" / "app" / "static"
    templates_count = len(list(templates_dir.glob("*.html"))) if templates_dir.exists() else 0
    static_js_count = len(list(static_dir.rglob("*.js"))) if static_dir.exists() else 0
    static_css_count = len(list(static_dir.rglob("*.css"))) if static_dir.exists() else 0

    readiness = compute_readiness(
        endpoint_df=endpoint_df,
        monetization_df=monetization_df,
        db_metrics=db_metrics,
        confluence_metrics=confluence_metrics,
        model_metrics=model_metrics,
        templates_count=templates_count,
        static_js_count=static_js_count,
        static_css_count=static_css_count,
    )
    valuation = compute_valuation(
        python_lines_total=python_lines_total,
        endpoint_df=endpoint_df,
        db_metrics=db_metrics,
        confluence_metrics=confluence_metrics,
        model_metrics=model_metrics,
        templates_count=templates_count,
        static_js_count=static_js_count,
        static_css_count=static_css_count,
        readiness=readiness,
    )

    snapshot = {
        "python_files": len(py_files),
        "python_lines_total": python_lines_total,
        "templates_html_count": templates_count,
        "static_js_count": static_js_count,
        "static_css_count": static_css_count,
        "endpoint_count_total": int(len(endpoint_df)),
        "endpoint_monetization_count": int(len(monetization_df)),
        "endpoint_avg_complexity": round(float(endpoint_df["complexity"].mean()), 3),
        "db_unique_table_targets": db_metrics["unique_table_targets_count"],
        "db_all_table_refs": db_metrics["all_db_tables_count"],
        "db_batch_upsert_calls": db_metrics["batch_upsert_calls"],
        "db_batch_insert_calls": db_metrics["batch_insert_calls"],
        "confluence_endpoints_count": confluence_metrics["confluence_endpoints_count"],
        "confluence_files_count": confluence_metrics["files_with_confluence_count"],
        "confluence_score_function_count": confluence_metrics["confluence_score_function_count"],
        "model_classes_total": model_metrics["model_classes_total"],
        "model_compliance_ratio": model_metrics["canonical_model_compliance_ratio"],
        "readiness_score": readiness["readiness_score"],
    }

    method_counts = {k: int(v) for k, v in endpoint_df["methods"].value_counts().to_dict().items()}
    top_segments = [(k, int(v)) for k, v in endpoint_df["top_segment"].value_counts().head(40).items()]
    top_route_files = [(k, int(v)) for k, v in endpoint_df["file"].value_counts().head(40).items()]
    top_complex = (
        endpoint_df.sort_values("complexity", ascending=False)
        .drop(columns=["top_segment", "complexity"])
        .head(50)
        .to_dict(orient="records")
    )

    full_assessment = {
        "snapshot": snapshot,
        "endpoint_option_stats": {
            "with_query": int((endpoint_df["params_query"] > 0).sum()),
            "with_path": int((endpoint_df["params_path"] > 0).sum()),
            "with_form": int((endpoint_df["params_form"] > 0).sum()),
            "with_body": int((endpoint_df["params_body"] > 0).sum()),
            "with_depends": int((endpoint_df["params_depends"] > 0).sum()),
            "required_params_total": int(endpoint_df["params_required"].sum()),
            "optional_params_total": int(endpoint_df["params_optional"].sum()),
            "avg_params_per_endpoint": round(float(endpoint_df["params_total"].mean()), 3),
            "p95_complexity": round(float(endpoint_df["complexity"].quantile(0.95)), 3),
            "max_complexity": round(float(endpoint_df["complexity"].max()), 3),
        },
        "method_counts": method_counts,
        "top_path_segments": top_segments,
        "top_route_files": top_route_files,
        "top_complex_endpoints": top_complex,
        "db_integration": db_metrics,
        "confluence_system": confluence_metrics,
        "model_architecture": model_metrics,
        "readiness_components": readiness,
        "valuation": valuation,
    }

    summary = {
        "snapshot": snapshot,
        "method_counts": method_counts,
        "top_path_segments": top_segments[:25],
        "top_route_files": top_route_files[:25],
        "db_integration": {
            k: v
            for k, v in db_metrics.items()
            if k
            in {
                "asyncpg_import_files_count",
                "create_pool_calls",
                "direct_asyncpg_connect_calls",
                "db_execution_callsites",
                "raw_sql_execute_callsites",
                "information_schema_hits",
                "batch_upsert_calls",
                "batch_insert_calls",
                "unique_table_targets_count",
                "all_db_tables_count",
                "fragmentation_ratio",
            }
        },
        "confluence_system": {
            k: v
            for k, v in confluence_metrics.items()
            if k
            in {
                "files_with_confluence_count",
                "confluence_lines_total",
                "confluence_endpoints_count",
                "confluence_tables_count",
                "confluence_score_function_count",
                "confluence_templates_count",
                "confluence_scripts_count",
            }
        },
        "model_architecture": {
            k: v
            for k, v in model_metrics.items()
            if k
            in {
                "model_files_count",
                "model_classes_total",
                "classes_with_data_dict",
                "classes_with_as_dataframe",
                "classes_with_both",
                "canonical_model_compliance_ratio",
                "as_dataframe_coverage_ratio",
                "data_dict_coverage_ratio",
            }
        },
        "readiness_components": readiness,
        "valuation": valuation,
    }

    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.summary_json.parent.mkdir(parents=True, exist_ok=True)
    args.endpoint_csv.parent.mkdir(parents=True, exist_ok=True)
    args.monetization_csv.parent.mkdir(parents=True, exist_ok=True)

    endpoint_df.drop(columns=["top_segment", "complexity"]).to_csv(args.endpoint_csv, index=False)
    monetization_df.to_csv(args.monetization_csv, index=False)
    args.output_json.write_text(json.dumps(full_assessment, indent=2), encoding="utf-8")
    args.summary_json.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(str(args.output_json))
    print(str(args.summary_json))
    print(str(args.endpoint_csv))
    print(str(args.monetization_csv))


if __name__ == "__main__":
    main()
