from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    HRFlowable,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


@dataclass
class ReplacementScenario:
    name: str
    hours_per_domain: float
    hours_per_table: float
    hours_per_script: float
    core_platform_hours: float
    delivery_multiplier: float
    blended_rate: float
    transfer_discount: float
    frontend_hours: float = 0.0
    raw_hours: float = 0.0
    loaded_hours: float = 0.0
    gross_rebuild_cost: float = 0.0
    as_is_value: float = 0.0


@dataclass
class RevenueScenario:
    name: str
    customers: int
    price_per_month: float
    multiple_low: float
    multiple_high: float
    probability: float
    arr: float = 0.0
    valuation_low: float = 0.0
    valuation_high: float = 0.0
    valuation_mid: float = 0.0


def money(value: float) -> str:
    return f"${value:,.0f}"


def pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def intfmt(value: float) -> str:
    return f"{int(round(value)):,}"


def to_rows(dict_items: list[tuple[str, Any]]) -> list[list[str]]:
    return [[k, str(v)] for k, v in dict_items]


def load_metrics(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def compute_models(metrics: dict[str, Any]) -> dict[str, Any]:
    public_domains = int(metrics.get("api_domains_public_count", 0))
    unique_tables = int(metrics.get("table_name_literal_unique_count", 0))
    scripts_files = int(metrics.get("scripts_python_files", 0))
    templates_count = int(metrics.get("website_templates_html_count", 0))
    static_js_count = int(metrics.get("website_static_js_count", 0))
    static_css_count = int(metrics.get("website_static_css_count", 0))
    route_files = int(metrics.get("website_route_files", 0))
    endpoint_count = int(metrics.get("website_endpoint_decorators_count", 0))
    monetization_hits = int(metrics.get("website_monetization_signal_hits", 0))

    frontend_hours_low = (
        (templates_count * 0.6)
        + (static_js_count * 2.0)
        + (static_css_count * 1.5)
        + (route_files * 2.0)
        + (endpoint_count * 0.08)
        + 120.0
    )
    frontend_hours_base = (
        (templates_count * 0.9)
        + (static_js_count * 3.0)
        + (static_css_count * 2.2)
        + (route_files * 3.0)
        + (endpoint_count * 0.12)
        + 180.0
    )
    frontend_hours_high = (
        (templates_count * 1.3)
        + (static_js_count * 4.0)
        + (static_css_count * 3.0)
        + (route_files * 4.2)
        + (endpoint_count * 0.16)
        + 260.0
    )

    readiness_score = (
        0.35 * min(1.0, endpoint_count / 450.0)
        + 0.25 * min(1.0, monetization_hits / 600.0)
        + 0.20 * min(1.0, templates_count / 80.0)
        + 0.20 * min(1.0, static_js_count / 50.0)
    )

    replacement_scenarios = [
        ReplacementScenario(
            name="Low",
            hours_per_domain=40.0,
            hours_per_table=2.0,
            hours_per_script=3.0,
            core_platform_hours=700.0,
            delivery_multiplier=1.35,
            blended_rate=110.0,
            transfer_discount=0.45,
            frontend_hours=frontend_hours_low,
        ),
        ReplacementScenario(
            name="Base",
            hours_per_domain=65.0,
            hours_per_table=3.2,
            hours_per_script=4.6,
            core_platform_hours=1100.0,
            delivery_multiplier=1.45,
            blended_rate=125.0,
            transfer_discount=0.30,
            frontend_hours=frontend_hours_base,
        ),
        ReplacementScenario(
            name="High",
            hours_per_domain=90.0,
            hours_per_table=4.2,
            hours_per_script=6.5,
            core_platform_hours=1500.0,
            delivery_multiplier=1.55,
            blended_rate=145.0,
            transfer_discount=0.20,
            frontend_hours=frontend_hours_high,
        ),
    ]

    for scenario in replacement_scenarios:
        scenario.raw_hours = (
            (public_domains * scenario.hours_per_domain)
            + (unique_tables * scenario.hours_per_table)
            + (scripts_files * scenario.hours_per_script)
            + scenario.frontend_hours
            + scenario.core_platform_hours
        )
        scenario.loaded_hours = scenario.raw_hours * scenario.delivery_multiplier
        scenario.gross_rebuild_cost = scenario.loaded_hours * scenario.blended_rate
        scenario.as_is_value = scenario.gross_rebuild_cost * (1.0 - scenario.transfer_discount)

    revenue_scenarios = [
        RevenueScenario(
            name="Cautious",
            customers=50,
            price_per_month=149.0,
            multiple_low=2.0,
            multiple_high=3.5,
            probability=0.40,
        ),
        RevenueScenario(
            name="Base",
            customers=120,
            price_per_month=249.0,
            multiple_low=3.0,
            multiple_high=5.0,
            probability=0.40,
        ),
        RevenueScenario(
            name="Upside",
            customers=250,
            price_per_month=349.0,
            multiple_low=3.5,
            multiple_high=6.0,
            probability=0.20,
        ),
    ]

    for scenario in revenue_scenarios:
        scenario.arr = scenario.customers * scenario.price_per_month * 12.0
        scenario.valuation_low = scenario.arr * scenario.multiple_low
        scenario.valuation_high = scenario.arr * scenario.multiple_high
        scenario.valuation_mid = (scenario.valuation_low + scenario.valuation_high) / 2.0

    weighted_commercialized_mid = sum(
        s.valuation_mid * s.probability for s in revenue_scenarios
    )
    weighted_commercialized_low = sum(
        s.valuation_low * s.probability for s in revenue_scenarios
    )
    weighted_commercialized_high = sum(
        s.valuation_high * s.probability for s in revenue_scenarios
    )

    # Option value before monetization: not all commercialized value is captured in an as-is repo sale.
    execution_capture_factor = min(0.30, 0.18 + (0.10 * readiness_score))
    income_option_value = weighted_commercialized_mid * execution_capture_factor

    # Strategic premium model (time-to-market savings for a buyer).
    team_burn_low = 48_000.0
    team_burn_high = 85_000.0
    months_low = 9.0 + (1.5 * readiness_score)
    months_high = 15.0 + (2.0 * readiness_score)
    capture_low = min(0.55, 0.40 + (0.10 * readiness_score))
    capture_high = min(0.80, 0.70 + (0.08 * readiness_score))

    strategic_rebuild_cost_low = team_burn_low * months_low
    strategic_rebuild_cost_high = team_burn_high * months_high
    strategic_premium_low = strategic_rebuild_cost_low * capture_low
    strategic_premium_high = strategic_rebuild_cost_high * capture_high
    strategic_premium_mid = (strategic_premium_low + strategic_premium_high) / 2.0

    replacement_low = replacement_scenarios[0].as_is_value
    replacement_mid = replacement_scenarios[1].as_is_value
    replacement_high = replacement_scenarios[2].as_is_value

    # Reconciliation weights reflect current asset-sale conditions.
    w_replacement = 0.60
    w_strategic = 0.25
    w_income_option = 0.15

    as_is_low = (
        (w_replacement * replacement_low)
        + (w_strategic * strategic_premium_low)
        + (w_income_option * (income_option_value * 0.60))
    )
    as_is_mid = (
        (w_replacement * replacement_mid)
        + (w_strategic * strategic_premium_mid)
        + (w_income_option * income_option_value)
    )
    as_is_high = (
        (w_replacement * replacement_high)
        + (w_strategic * strategic_premium_high)
        + (w_income_option * (income_option_value * 1.40))
    )

    # Negotiation range is narrower than the model spread.
    suggested_ask_low = as_is_mid * 0.85
    suggested_ask_high = as_is_mid * 1.25

    return {
        "replacement_scenarios": replacement_scenarios,
        "revenue_scenarios": revenue_scenarios,
        "weighted_commercialized_low": weighted_commercialized_low,
        "weighted_commercialized_mid": weighted_commercialized_mid,
        "weighted_commercialized_high": weighted_commercialized_high,
        "execution_capture_factor": execution_capture_factor,
        "monetization_readiness_score": readiness_score,
        "income_option_value": income_option_value,
        "frontend_effort": {
            "templates_count": templates_count,
            "static_js_count": static_js_count,
            "static_css_count": static_css_count,
            "route_files": route_files,
            "endpoint_count": endpoint_count,
            "monetization_hits": monetization_hits,
            "low_hours": frontend_hours_low,
            "base_hours": frontend_hours_base,
            "high_hours": frontend_hours_high,
        },
        "strategic": {
            "team_burn_low": team_burn_low,
            "team_burn_high": team_burn_high,
            "months_low": months_low,
            "months_high": months_high,
            "capture_low": capture_low,
            "capture_high": capture_high,
            "rebuild_cost_low": strategic_rebuild_cost_low,
            "rebuild_cost_high": strategic_rebuild_cost_high,
            "premium_low": strategic_premium_low,
            "premium_high": strategic_premium_high,
            "premium_mid": strategic_premium_mid,
        },
        "reconciliation": {
            "w_replacement": w_replacement,
            "w_strategic": w_strategic,
            "w_income_option": w_income_option,
            "as_is_low": as_is_low,
            "as_is_mid": as_is_mid,
            "as_is_high": as_is_high,
            "suggested_ask_low": suggested_ask_low,
            "suggested_ask_high": suggested_ask_high,
        },
    }


def table_style(header_bg: colors.Color = colors.HexColor("#1E2A38")) -> TableStyle:
    return TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), header_bg),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#A7B1BC")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F8FB")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]
    )


def section_banner(text: str) -> Table:
    t = Table([[text]], colWidths=[7.0 * inch], rowHeights=[0.33 * inch])
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#0B3954")),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
                ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 11.2),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return t


def metric_cards(
    as_is_low: float,
    as_is_mid: float,
    as_is_high: float,
    ask_low: float,
    ask_high: float,
    comm_mid: float,
) -> Table:
    card_data = [
        [
            Paragraph("<b>As-is Value Range</b>", getSampleStyleSheet()["BodyText"]),
            Paragraph("<b>Central Estimate</b>", getSampleStyleSheet()["BodyText"]),
            Paragraph("<b>Suggested Ask Band</b>", getSampleStyleSheet()["BodyText"]),
            Paragraph("<b>Commercialized Expected</b>", getSampleStyleSheet()["BodyText"]),
        ],
        [
            Paragraph(f"{money(as_is_low)}<br/>{money(as_is_high)}", getSampleStyleSheet()["BodyText"]),
            Paragraph(f"{money(as_is_mid)}", getSampleStyleSheet()["BodyText"]),
            Paragraph(f"{money(ask_low)}<br/>{money(ask_high)}", getSampleStyleSheet()["BodyText"]),
            Paragraph(f"{money(comm_mid)}", getSampleStyleSheet()["BodyText"]),
        ],
    ]
    t = Table(card_data, colWidths=[1.72 * inch, 1.72 * inch, 1.72 * inch, 1.72 * inch], rowHeights=[0.32 * inch, 0.56 * inch])
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9E2EC")),
                ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#F7FBFF")),
                ("GRID", (0, 0), (-1, -1), 0.7, colors.HexColor("#9FB3C8")),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 9.2),
                ("FONTSIZE", (0, 1), (-1, -1), 10.3),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#102A43")),
            ]
        )
    )
    return t


def build_pdf(
    metrics: dict[str, Any],
    models: dict[str, Any],
    output_path: Path,
    report_date: str,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)

    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="ReportTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=24,
            textColor=colors.HexColor("#102A43"),
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="SectionTitle",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=14,
            textColor=colors.HexColor("#102A43"),
            spaceBefore=10,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="HeroSub",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=10.8,
            leading=14,
            textColor=colors.HexColor("#243B53"),
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Body",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=10.2,
            leading=14,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Small",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8.7,
            leading=12,
            textColor=colors.HexColor("#334E68"),
        )
    )

    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=LETTER,
        leftMargin=0.65 * inch,
        rightMargin=0.65 * inch,
        topMargin=0.72 * inch,
        bottomMargin=0.7 * inch,
        title="FUDSTOP Repository Valuation Report",
        author="Codex",
    )

    def header_footer(canvas, _doc):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#0B3954"))
        canvas.setLineWidth(2)
        canvas.line(0.65 * inch, 10.78 * inch, 7.85 * inch, 10.78 * inch)
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#486581"))
        canvas.drawString(0.65 * inch, 0.45 * inch, "FUDSTOP Repository Valuation Report")
        canvas.drawRightString(7.85 * inch, 0.45 * inch, f"Page {_doc.page}")
        canvas.drawRightString(7.85 * inch, 10.75 * inch, report_date)
        canvas.restoreState()

    recon = models["reconciliation"]
    replacement = models["replacement_scenarios"]
    revenue = models["revenue_scenarios"]
    strategic = models["strategic"]
    frontend = models.get("frontend_effort", {})
    readiness = float(models.get("monetization_readiness_score", 0.0))

    story: list[Any] = []
    hero_table = Table(
        [[Paragraph("<font color='white'><b>FUDSTOP Repository Valuation Report</b></font>", styles["ReportTitle"])]],
        colWidths=[7.0 * inch],
        rowHeights=[0.72 * inch],
    )
    hero_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#102A43")),
                ("LEFTPADDING", (0, 0), (-1, -1), 14),
                ("RIGHTPADDING", (0, 0), (-1, -1), 14),
                ("TOPPADDING", (0, 0), (-1, -1), 12),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    story.append(hero_table)
    story.append(Spacer(1, 8))
    story.append(Paragraph(f"Valuation Date: <b>{report_date}</b>", styles["HeroSub"]))

    summary_text = (
        "This report values your repository with three independent methods and reconciles them into an "
        "as-is sale estimate. Assumptions are explicit and the numbers are traceable to repository evidence, "
        "including the newly added website frontend and monetization routes."
    )
    story.append(Paragraph(summary_text, styles["Body"]))
    story.append(Spacer(1, 6))
    story.append(
        metric_cards(
            as_is_low=recon["as_is_low"],
            as_is_mid=recon["as_is_mid"],
            as_is_high=recon["as_is_high"],
            ask_low=recon["suggested_ask_low"],
            ask_high=recon["suggested_ask_high"],
            comm_mid=models["weighted_commercialized_mid"],
        )
    )
    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", thickness=1.2, color=colors.HexColor("#9FB3C8"), spaceBefore=0, spaceAfter=8))

    story.append(section_banner("1) Evidence Baseline (Repository Snapshot)"))
    story.append(Spacer(1, 6))
    evidence_rows = [
        ("Total files (all types)", intfmt(metrics.get("total_files_all_types", 0))),
        ("Python files", intfmt(metrics.get("python_files", 0))),
        ("Python LOC (all Python files)", intfmt(metrics.get("python_lines_total", 0))),
        ("API domains (public connectors)", intfmt(metrics.get("api_domains_public_count", 0))),
        ("API domains (raw, incl. internal)", intfmt(metrics.get("api_domains_raw_count", 0))),
        ("Unique table targets (table_name=...)", intfmt(metrics.get("table_name_literal_unique_count", 0))),
        ("batch_upsert_dataframe call sites", intfmt(metrics.get("batch_upsert_calls", 0))),
        ("batch_insert_dataframe call sites", intfmt(metrics.get("batch_insert_calls", 0))),
        ("as_dataframe DataFrame assignments", intfmt(metrics.get("as_dataframe_assignments_total", 0))),
        ("API classes", intfmt(metrics.get("api_class_count", 0))),
        ("API async methods", intfmt(metrics.get("api_async_def_count", 0))),
        ("Scripts (.py)", intfmt(metrics.get("scripts_python_files", 0))),
        ("Feeds (.py)", intfmt(metrics.get("feeds_python_files", 0))),
        ("Research assets (.py/.sql/.yaml)", intfmt(metrics.get("research_assets_count", 0))),
        ("Website templates (.html)", intfmt(metrics.get("website_templates_html_count", 0))),
        ("Website static JS files", intfmt(metrics.get("website_static_js_count", 0))),
        ("Website static CSS files", intfmt(metrics.get("website_static_css_count", 0))),
        ("Website route files", intfmt(metrics.get("website_route_files", 0))),
        ("Website endpoint decorators", intfmt(metrics.get("website_endpoint_decorators_count", 0))),
        ("Website monetization signals", intfmt(metrics.get("website_monetization_signal_hits", 0))),
        ("Log files", intfmt(metrics.get("logs_file_count", 0))),
        ("Git tracked files", intfmt(metrics.get("git_tracked_files", 0))),
        ("Git commit count", intfmt(metrics.get("git_commit_count", 0))),
    ]
    evidence_table = Table([["Metric", "Observed Value"], *to_rows(evidence_rows)], colWidths=[3.6 * inch, 2.7 * inch])
    evidence_table.setStyle(table_style())
    story.append(evidence_table)
    story.append(Spacer(1, 8))
    story.append(
        Paragraph(
            "Interpretation: the repository is full-stack and integration-heavy. "
            "Value now comes from both data aggregation depth and productization surface (UI, pages, route volume, and billing-adjacent flows).",
            styles["Body"],
        )
    )

    story.append(PageBreak())
    story.append(section_banner("2) Valuation Methodology"))
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            "The valuation uses three independent lenses and then reconciles them: "
            "(A) replacement cost adjusted for transfer friction, "
            "(B) commercialization upside and option value capture, and "
            "(C) strategic buyer time-to-market premium.",
            styles["Body"],
        )
    )
    story.append(
        Paragraph(
            "This method avoids a pure LOC multiple and instead ties value to deployable integration surface, "
            "schema breadth, ingestion architecture, frontend build effort, and monetization optionality.",
            styles["Body"],
        )
    )

    story.append(Spacer(1, 4))
    story.append(section_banner("3) Model A - Replacement Cost (Primary Anchor)"))
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            "Formula: <b>raw engineering hours</b> = "
            "(public domains x hours/domain) + (table targets x hours/table) + "
            "(scripts x hours/script) + frontend productization hours + core platform hours. "
            "Then: loaded hours = raw hours x delivery multiplier; "
            "gross rebuild cost = loaded hours x blended rate; "
            "as-is value = gross rebuild cost x (1 - transfer discount).",
            styles["Body"],
        )
    )

    repl_table_rows = [[
        "Scenario",
        "Frontend Hrs",
        "Raw Hours",
        "Loaded Hours",
        "Gross Rebuild Cost",
        "Transfer Discount",
        "As-is Value",
    ]]
    for s in replacement:
        repl_table_rows.append(
            [
                s.name,
                intfmt(s.frontend_hours),
                intfmt(s.raw_hours),
                intfmt(s.loaded_hours),
                money(s.gross_rebuild_cost),
                pct(s.transfer_discount),
                money(s.as_is_value),
            ]
        )

    repl_table = Table(
        repl_table_rows,
        colWidths=[0.78 * inch, 0.9 * inch, 0.9 * inch, 0.95 * inch, 1.3 * inch, 1.05 * inch, 1.0 * inch],
    )
    repl_table.setStyle(table_style())
    story.append(repl_table)
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            f"Primary anchor result: {money(replacement[0].as_is_value)} to "
            f"{money(replacement[2].as_is_value)}, with base case {money(replacement[1].as_is_value)}.",
            styles["Body"],
        )
    )
    story.append(
        Paragraph(
            f"Frontend effort contribution (modeled): "
            f"{intfmt(frontend.get('low_hours', 0))} to {intfmt(frontend.get('high_hours', 0))} hours "
            f"(base: {intfmt(frontend.get('base_hours', 0))} hours).",
            styles["Body"],
        )
    )

    story.append(Spacer(1, 6))
    story.append(section_banner("4) Model B - Commercialization Upside"))
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            "Revenue scenarios use conservative SMB-to-pro pricing and software multiples. "
            "This produces expected commercialized value before execution discounting.",
            styles["Body"],
        )
    )

    rev_rows = [[
        "Scenario",
        "Customers",
        "Price / Month",
        "ARR",
        "Value Range",
        "Probability",
    ]]
    for s in revenue:
        rev_rows.append(
            [
                s.name,
                intfmt(s.customers),
                money(s.price_per_month),
                money(s.arr),
                f"{money(s.valuation_low)} - {money(s.valuation_high)}",
                pct(s.probability),
            ]
        )
    rev_table = Table(
        rev_rows,
        colWidths=[0.95 * inch, 0.85 * inch, 1.0 * inch, 1.0 * inch, 1.8 * inch, 0.9 * inch],
    )
    rev_table.setStyle(table_style())
    story.append(rev_table)
    story.append(Spacer(1, 5))
    story.append(
        Paragraph(
            f"Probability-weighted commercialized expectation: "
            f"{money(models['weighted_commercialized_mid'])}. "
            f"As-is option capture factor: {pct(models['execution_capture_factor'])}, "
            f"contributing {money(models['income_option_value'])} to asset value today. "
            f"Monetization readiness score: {pct(readiness)}.",
            styles["Body"],
        )
    )

    story.append(PageBreak())
    story.append(section_banner("5) Model C - Strategic Buyer Premium"))
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            "For acquirers with existing distribution, this repository can compress time-to-market by replacing "
            "months of connector, model, and ingestion work.",
            styles["Body"],
        )
    )
    strategic_rows = [
        ["Input", "Low", "High"],
        ["Monthly team burn", money(strategic["team_burn_low"]), money(strategic["team_burn_high"])],
        ["Months to rebuild", intfmt(strategic["months_low"]), intfmt(strategic["months_high"])],
        ["Rebuild cost", money(strategic["rebuild_cost_low"]), money(strategic["rebuild_cost_high"])],
        ["Capture rate", pct(strategic["capture_low"]), pct(strategic["capture_high"])],
        ["Strategic premium", money(strategic["premium_low"]), money(strategic["premium_high"])],
    ]
    strategic_table = Table(strategic_rows, colWidths=[2.6 * inch, 1.85 * inch, 1.85 * inch])
    strategic_table.setStyle(table_style())
    story.append(strategic_table)
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            f"Strategic mid premium estimate: {money(strategic['premium_mid'])}.",
            styles["Body"],
        )
    )

    story.append(Spacer(1, 6))
    story.append(section_banner("6) Reconciliation to Final As-is Value"))
    story.append(Spacer(1, 6))
    recon_rows = [
        ["Component", "Weight", "Contribution (Mid)"],
        ["Replacement model (as-is)", pct(recon["w_replacement"]), money(recon["w_replacement"] * replacement[1].as_is_value)],
        ["Strategic premium", pct(recon["w_strategic"]), money(recon["w_strategic"] * strategic["premium_mid"])],
        ["Income option value", pct(recon["w_income_option"]), money(recon["w_income_option"] * models["income_option_value"])],
        ["Total reconciled midpoint", "", money(recon["as_is_mid"])],
    ]
    recon_table = Table(recon_rows, colWidths=[2.8 * inch, 1.2 * inch, 2.3 * inch])
    recon_table.setStyle(table_style())
    story.append(recon_table)
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            f"<b>Final as-is valuation range:</b> {money(recon['as_is_low'])} to {money(recon['as_is_high'])}. "
            f"<b>Central estimate:</b> {money(recon['as_is_mid'])}. "
            f"<b>Suggested ask band:</b> {money(recon['suggested_ask_low'])} to {money(recon['suggested_ask_high'])}.",
            styles["Body"],
        )
    )

    story.append(Spacer(1, 6))
    story.append(section_banner("7) Why This Can Be Valued High"))
    story.append(Spacer(1, 6))
    bullets = [
        f"Breadth moat: {intfmt(metrics.get('api_domains_public_count', 0))} public API domains under one repository with a common ingestion pattern.",
        f"Persistence moat: {intfmt(metrics.get('table_name_literal_unique_count', 0))} unique table targets and {intfmt(metrics.get('batch_upsert_calls', 0))} upsert call sites indicate a mature schema surface.",
        f"Full-stack moat: {intfmt(metrics.get('website_templates_html_count', 0))} templates, {intfmt(metrics.get('website_static_js_count', 0))} static JS files, {intfmt(metrics.get('website_static_css_count', 0))} CSS files, and {intfmt(metrics.get('website_endpoint_decorators_count', 0))} endpoint decorators.",
        f"Monetization signal density: {intfmt(metrics.get('website_monetization_signal_hits', 0))} route-level billing/member/webhook/checkout references.",
        "Low marginal COGS potential: BYOK architecture can preserve margin once monetized.",
        "Strategic scarcity: buyers often pay for compressed time-to-market, not just source lines.",
    ]
    for b in bullets:
        story.append(Paragraph(f"- {b}", styles["Body"]))

    story.append(Spacer(1, 6))
    story.append(section_banner("8) Deductions and Constraints"))
    story.append(Spacer(1, 6))
    deductions = [
        "Transferability discount is already applied in Model A through scenario-specific transfer discounts.",
        "No premium is added for customer contracts or active revenue unless independently verified.",
        "No valuation credit is included for exclusive data rights unless legal resale rights are documented.",
        "Documentation and test maturity remain a negotiation lever that can move final price up or down.",
    ]
    for d in deductions:
        story.append(Paragraph(f"- {d}", styles["Body"]))

    story.append(Spacer(1, 6))
    story.append(section_banner("9) Appendix: Top API Domain File Counts"))
    story.append(Spacer(1, 6))
    domain_counts = metrics.get("api_domain_python_file_counts", {})
    top_domains = sorted(domain_counts.items(), key=lambda kv: kv[1], reverse=True)[:15]
    domain_rows = [["Domain", "Python Files"]] + [[name, intfmt(count)] for name, count in top_domains]
    domain_table = Table(domain_rows, colWidths=[4.1 * inch, 2.2 * inch])
    domain_table.setStyle(table_style())
    story.append(domain_table)

    story.append(Spacer(1, 8))
    story.append(
        Paragraph(
            "Prepared from local repository metrics and explicit valuation assumptions. "
            "This is an internal analytical estimate for sale strategy, not legal, tax, or investment advice.",
            styles["Small"],
        )
    )

    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a PDF valuation report for the repository.")
    parser.add_argument(
        "--metrics",
        type=Path,
        default=Path(r"c:\code\fudstop\tmp\pdfs\repo_valuation_metrics_v3.json"),
        help="Path to repo metrics JSON file.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(r"c:\code\fudstop\output\pdf\FUDSTOP_REPO_Valuation_Report_WITH_WEBSITE_2026-03-03.pdf"),
        help="Output PDF path.",
    )
    parser.add_argument(
        "--report-date",
        type=str,
        default=datetime.now().strftime("%B %d, %Y"),
        help="Display date for the report.",
    )
    args = parser.parse_args()

    metrics = load_metrics(args.metrics)
    models = compute_models(metrics)
    build_pdf(metrics, models, args.output, args.report_date)
    print(str(args.output))


if __name__ == "__main__":
    main()
