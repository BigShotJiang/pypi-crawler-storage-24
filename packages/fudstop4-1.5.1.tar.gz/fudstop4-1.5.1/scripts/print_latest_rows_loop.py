#!/usr/bin/env python3
"""
print_latest_rows_loop.py

Continuously prints the latest row per ticker from a table (default: ca_live).

Examples:
  python scripts/print_latest_rows_loop.py
  python scripts/print_latest_rows_loop.py --table ca_live --sleep 3
  python scripts/print_latest_rows_loop.py --once --limit 25
"""

import argparse
import asyncio
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List


def _bootstrap_repo_path() -> Path:
    here = Path(__file__).resolve()
    for candidate in [here.parent, *here.parents]:
        if (candidate / "fudstop4").is_dir():
            root = candidate
            break
    else:
        root = here.parents[1]

    root_str = str(root)
    if root_str in sys.path:
        sys.path.remove(root_str)
    sys.path.insert(0, root_str)
    return root


_REPO_ROOT = _bootstrap_repo_path()

from fudstop4.apis.polygonio.polygon_options import PolygonOptions


IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
PREFERRED_TS_COLS = [
    "insertion_timestamp",
    "updated_at",
    "created_at",
    "timestamp",
    "ts",
]


def _safe_identifier(name: str, label: str) -> str:
    value = (name or "").strip()
    if not IDENTIFIER_RE.fullmatch(value):
        raise ValueError(f"Invalid {label}: {name!r}")
    return value


def _clear_terminal() -> None:
    os.system("cls" if os.name == "nt" else "clear")


async def _detect_timestamp_column(
    db: PolygonOptions,
    table_name: str,
) -> str:
    rows = await db.fetch_new(
        """
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = $1
        """,
        table_name,
    )
    cols = {str(dict(r).get("column_name") or "").strip().lower() for r in rows or []}
    for col in PREFERRED_TS_COLS:
        if col in cols:
            return col
    raise RuntimeError(
        f"No timestamp column found in table '{table_name}'. "
        f"Tried: {', '.join(PREFERRED_TS_COLS)}"
    )


async def _fetch_latest_rows(
    db: PolygonOptions,
    table_name: str,
    ticker_col: str,
    ts_col: str,
    limit: int,
) -> List[Dict[str, Any]]:
    limit_sql = ""
    if limit > 0:
        limit_sql = f"LIMIT {int(limit)}"

    query = f"""
        SELECT *
        FROM (
            SELECT DISTINCT ON ("{ticker_col}") *
            FROM "{table_name}"
            WHERE "{ticker_col}" IS NOT NULL
            ORDER BY "{ticker_col}", "{ts_col}" DESC NULLS LAST
        ) latest
        ORDER BY "{ticker_col}" ASC
        {limit_sql}
    """
    rows = await db.fetch_new(query)
    return [dict(r) for r in rows or []]


async def run_loop(
    *,
    table_name: str,
    ticker_col: str,
    sleep_seconds: float,
    once: bool,
    limit: int,
    clear: bool,
) -> None:
    db = PolygonOptions()
    await db.connect()
    try:
        ts_col = await _detect_timestamp_column(db, table_name)
        cycle = 0
        while True:
            cycle += 1
            rows = await _fetch_latest_rows(
                db=db,
                table_name=table_name,
                ticker_col=ticker_col,
                ts_col=ts_col,
                limit=limit,
            )

            if clear:
                _clear_terminal()

            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(
                f"[{now}] cycle={cycle} table={table_name} "
                f"ticker_col={ticker_col} ts_col={ts_col} rows={len(rows)}"
            )
            print("-" * 120)
            for row in rows:
                print(json.dumps(row, default=str, separators=(",", ":"), ensure_ascii=True))

            if once:
                break
            await asyncio.sleep(max(0.5, float(sleep_seconds)))
    finally:
        await db.disconnect()


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Print latest row for each ticker in a continuous loop.")
    p.add_argument("--table", default="ca_live", help="Table to query (default: ca_live)")
    p.add_argument("--ticker-col", default="ticker", help="Ticker column name (default: ticker)")
    p.add_argument("--sleep", type=float, default=5.0, help="Seconds between refreshes (default: 5)")
    p.add_argument("--limit", type=int, default=0, help="Optional max tickers to print (0 = all)")
    p.add_argument("--once", action="store_true", help="Run one cycle only, then exit")
    p.add_argument("--no-clear", action="store_true", help="Do not clear terminal between cycles")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    table_name = _safe_identifier(args.table, "table")
    ticker_col = _safe_identifier(args.ticker_col, "ticker column")
    asyncio.run(
        run_loop(
            table_name=table_name,
            ticker_col=ticker_col,
            sleep_seconds=float(args.sleep),
            once=bool(args.once),
            limit=int(args.limit),
            clear=not bool(args.no_clear),
        )
    )


if __name__ == "__main__":
    main()

