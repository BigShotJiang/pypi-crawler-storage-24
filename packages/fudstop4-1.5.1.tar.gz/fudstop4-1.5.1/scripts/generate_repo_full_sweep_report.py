from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    HRFlowable,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


def money(value: float) -> str:
    return f"${value:,.0f}"


def pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def intfmt(value: float | int) -> str:
    return f"{int(round(float(value))):,}"


def table_style(header_bg: colors.Color = colors.HexColor("#0B3954")) -> TableStyle:
    return TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), header_bg),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
            ("FONTSIZE", (0, 0), (-1, -1), 8.6),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#A7B1BC")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F8FB")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]
    )


def banner(text: str) -> Table:
    t = Table([[text]], colWidths=[7.0 * inch], rowHeights=[0.32 * inch])
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#0B3954")),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
                ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 11),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return t


def build_report(data: dict[str, Any], output: Path, report_date: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)

    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="TitleLarge",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=23,
            textColor=colors.white,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Body",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=10,
            leading=13.2,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Small",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8.5,
            leading=10.8,
            textColor=colors.HexColor("#334E68"),
        )
    )

    doc = SimpleDocTemplate(
        str(output),
        pagesize=LETTER,
        leftMargin=0.65 * inch,
        rightMargin=0.65 * inch,
        topMargin=0.72 * inch,
        bottomMargin=0.7 * inch,
        title="FUDSTOP Full Sweep Assessment",
        author="Codex",
    )

    def header_footer(canvas, _doc):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#0B3954"))
        canvas.setLineWidth(2)
        canvas.line(0.65 * inch, 10.78 * inch, 7.85 * inch, 10.78 * inch)
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#486581"))
        canvas.drawString(0.65 * inch, 0.45 * inch, "FUDSTOP Full Sweep Assessment (Endpoints + DB + Confluence + Models)")
        canvas.drawRightString(7.85 * inch, 0.45 * inch, f"Page {_doc.page}")
        canvas.drawRightString(7.85 * inch, 10.75 * inch, report_date)
        canvas.restoreState()

    snap = data["snapshot"]
    val = data["valuation"]
    dbm = data["db_integration"]
    conf = data["confluence_system"]
    mm = data["model_architecture"]
    readiness = data["readiness_components"]
    option_stats = data["endpoint_option_stats"]

    story: list[Any] = []
    hero = Table(
        [[Paragraph("<font color='white'><b>FUDSTOP Full Sweep Assessment</b></font>", styles["TitleLarge"])]],
        colWidths=[7.0 * inch],
        rowHeights=[0.72 * inch],
    )
    hero.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#102A43")),
                ("LEFTPADDING", (0, 0), (-1, -1), 14),
                ("TOPPADDING", (0, 0), (-1, -1), 12),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    story.append(hero)
    story.append(Spacer(1, 8))
    story.append(Paragraph(f"Report Date: <b>{report_date}</b>", styles["Body"]))
    story.append(
        Paragraph(
            "This full sweep includes endpoint option depth, database integration footprint, confluence-system coverage, "
            "model architecture compliance, and a recalculated valuation.",
            styles["Body"],
        )
    )
    story.append(HRFlowable(width="100%", thickness=1.0, color=colors.HexColor("#9FB3C8"), spaceBefore=2, spaceAfter=8))

    story.append(banner("1) Executive Valuation"))
    story.append(Spacer(1, 6))
    card = Table(
        [
            ["Final Range", "Central Value", "Suggested Ask Band", "Readiness"],
            [
                f"{money(val['final_range_low'])} - {money(val['final_range_high'])}",
                money(val["reconciled_mid"]),
                f"{money(val['ask_band_low'])} - {money(val['ask_band_high'])}",
                pct(snap["readiness_score"]),
            ],
        ],
        colWidths=[1.9 * inch, 1.4 * inch, 2.1 * inch, 1.6 * inch],
    )
    card.setStyle(table_style(colors.HexColor("#1F7A8C")))
    story.append(card)
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            f"Replacement anchor: {money(val['replacement_range_low'])} to {money(val['replacement_range_high'])}. "
            f"Commercialized expected: {money(val['commercialized_expected'])}. Strategic mid: {money(val['strategic_mid'])}.",
            styles["Body"],
        )
    )

    story.append(banner("2) System Coverage Snapshot"))
    story.append(Spacer(1, 6))
    cov_rows = [
        ["Metric", "Value"],
        ["Python files", intfmt(snap["python_files"])],
        ["Python LOC", intfmt(snap["python_lines_total"])],
        ["Endpoints", intfmt(snap["endpoint_count_total"])],
        ["Monetization endpoints", intfmt(snap["endpoint_monetization_count"])],
        ["Avg endpoint complexity", f"{snap['endpoint_avg_complexity']:.2f}"],
        ["DB unique table targets", intfmt(snap["db_unique_table_targets"])],
        ["DB table refs (all)", intfmt(snap["db_all_table_refs"])],
        ["Confluence endpoints", intfmt(snap["confluence_endpoints_count"])],
        ["Confluence score functions", intfmt(snap["confluence_score_function_count"])],
        ["Model classes", intfmt(snap["model_classes_total"])],
        ["Model compliance ratio", pct(snap["model_compliance_ratio"])],
    ]
    cov_table = Table(cov_rows, colWidths=[3.65 * inch, 2.65 * inch])
    cov_table.setStyle(table_style())
    story.append(cov_table)

    story.append(PageBreak())
    story.append(banner("3) Endpoint Option Sweep"))
    story.append(Spacer(1, 6))
    method_rows = [["Method", "Count"]] + [[k, intfmt(v)] for k, v in data["method_counts"].items()]
    mt = Table(method_rows, colWidths=[1.8 * inch, 1.3 * inch])
    mt.setStyle(table_style())
    story.append(mt)
    story.append(Spacer(1, 8))
    opt_rows = [
        ["Endpoint Option Metric", "Value"],
        ["Endpoints with query options", intfmt(option_stats["with_query"])],
        ["Endpoints with path params", intfmt(option_stats["with_path"])],
        ["Endpoints with form inputs", intfmt(option_stats["with_form"])],
        ["Endpoints with request body", intfmt(option_stats["with_body"])],
        ["Endpoints with dependencies", intfmt(option_stats["with_depends"])],
        ["Required params total", intfmt(option_stats["required_params_total"])],
        ["Optional params total", intfmt(option_stats["optional_params_total"])],
        ["Avg params per endpoint", f"{option_stats['avg_params_per_endpoint']:.2f}"],
        ["P95 complexity", f"{option_stats['p95_complexity']:.2f}"],
        ["Max complexity", f"{option_stats['max_complexity']:.2f}"],
    ]
    ot = Table(opt_rows, colWidths=[3.65 * inch, 2.65 * inch])
    ot.setStyle(table_style(colors.HexColor("#2F855A")))
    story.append(ot)

    story.append(PageBreak())
    story.append(banner("4) Database Integration Sweep"))
    story.append(Spacer(1, 6))
    db_rows = [
        ["DB Metric", "Value"],
        ["Files importing asyncpg", intfmt(dbm["asyncpg_import_files_count"])],
        ["create_pool call sites", intfmt(dbm["create_pool_calls"])],
        ["Direct asyncpg.connect calls", intfmt(dbm["direct_asyncpg_connect_calls"])],
        ["DB execution callsites", intfmt(dbm["db_execution_callsites"])],
        ["Raw SQL execute callsites", intfmt(dbm["raw_sql_execute_callsites"])],
        ["information_schema hits", intfmt(dbm["information_schema_hits"])],
        ["Batch upsert call sites", intfmt(dbm["batch_upsert_calls"])],
        ["Batch insert call sites", intfmt(dbm["batch_insert_calls"])],
        ["Unique upsert table targets", intfmt(dbm["unique_table_targets_count"])],
        ["DB fragmentation ratio", f"{dbm['fragmentation_ratio']:.2f}"],
    ]
    dbt = Table(db_rows, colWidths=[3.65 * inch, 2.65 * inch])
    dbt.setStyle(table_style(colors.HexColor("#7B341E")))
    story.append(dbt)

    story.append(Spacer(1, 8))
    top_tables = [["Top Table Targets", "Frequency"]] + [[t, intfmt(c)] for t, c in dbm.get("top_table_targets", [])[:20]]
    tt = Table(top_tables, colWidths=[4.8 * inch, 1.5 * inch])
    tt.setStyle(table_style())
    story.append(tt)

    story.append(PageBreak())
    story.append(banner("5) Confluence + Model Architecture"))
    story.append(Spacer(1, 6))
    conf_rows = [
        ["Confluence Metric", "Value"],
        ["Files with confluence logic", intfmt(conf["files_with_confluence_count"])],
        ["Confluence code/content lines", intfmt(conf["confluence_lines_total"])],
        ["Confluence endpoints", intfmt(conf["confluence_endpoints_count"])],
        ["Confluence tables", intfmt(conf["confluence_tables_count"])],
        ["Confluence score functions", intfmt(conf["confluence_score_function_count"])],
        ["Confluence templates", intfmt(conf["confluence_templates_count"])],
        ["Confluence scripts", intfmt(conf["confluence_scripts_count"])],
    ]
    ct = Table(conf_rows, colWidths=[3.65 * inch, 2.65 * inch])
    ct.setStyle(table_style(colors.HexColor("#6B46C1")))
    story.append(ct)
    story.append(Spacer(1, 8))

    model_rows = [
        ["Model Architecture Metric", "Value"],
        ["Model files", intfmt(mm["model_files_count"])],
        ["Model classes", intfmt(mm["model_classes_total"])],
        ["Classes with data_dict", intfmt(mm["classes_with_data_dict"])],
        ["Classes with as_dataframe", intfmt(mm["classes_with_as_dataframe"])],
        ["Classes with both", intfmt(mm["classes_with_both"])],
        ["Canonical compliance ratio", pct(mm["canonical_model_compliance_ratio"])],
        ["as_dataframe coverage", pct(mm["as_dataframe_coverage_ratio"])],
    ]
    mt2 = Table(model_rows, colWidths=[3.65 * inch, 2.65 * inch])
    mt2.setStyle(table_style(colors.HexColor("#2B6CB0")))
    story.append(mt2)

    story.append(PageBreak())
    story.append(banner("6) Readiness + Valuation Inputs"))
    story.append(Spacer(1, 6))
    ready_rows = [["Readiness Component", "Score"]] + [
        [k.replace("_", " ").title(), pct(v)]
        for k, v in readiness.items()
        if k != "readiness_score"
    ] + [["Readiness Score", pct(readiness["readiness_score"])]]
    rt = Table(ready_rows, colWidths=[3.65 * inch, 2.65 * inch])
    rt.setStyle(table_style(colors.HexColor("#22543D")))
    story.append(rt)
    story.append(Spacer(1, 8))

    vi = val["model_inputs"]
    val_rows = [
        ["Valuation Input", "Hours"],
        ["Core backend", intfmt(vi["core_backend_hours"])],
        ["Endpoint surface", intfmt(vi["endpoint_surface_hours"])],
        ["DB integration", intfmt(vi["db_integration_hours"])],
        ["Confluence system", intfmt(vi["confluence_hours"])],
        ["Model layer", intfmt(vi["model_layer_hours"])],
        ["Frontend", intfmt(vi["frontend_hours"])],
        ["Integration", intfmt(vi["integration_hours"])],
        ["Ops/launch", intfmt(vi["ops_hours"])],
        ["Total hours", intfmt(vi["total_hours"])],
        ["Blended rate", money(vi["blended_rate_usd"])],
    ]
    vt = Table(val_rows, colWidths=[3.65 * inch, 2.65 * inch])
    vt.setStyle(table_style())
    story.append(vt)

    story.append(Spacer(1, 8))
    story.append(
        Paragraph(
            "Artifacts: "
            r"repo_full_sweep_assessment_v1.json, repo_full_sweep_summary_v1.json, "
            r"endpoint_inventory_full_v2.csv, endpoint_inventory_monetization_v2.csv.",
            styles["Small"],
        )
    )

    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate full-sweep PDF report from full-sweep JSON.")
    parser.add_argument(
        "--input",
        type=Path,
        default=Path(r"c:\code\fudstop\tmp\pdfs\repo_full_sweep_assessment_v1.json"),
        help="Input JSON path.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(r"c:\code\fudstop\output\pdf\FUDSTOP_Full_Sweep_Assessment_2026-03-03.pdf"),
        help="Output PDF path.",
    )
    parser.add_argument(
        "--report-date",
        type=str,
        default=datetime.now().strftime("%B %d, %Y"),
        help="Report date label.",
    )
    args = parser.parse_args()

    data = json.loads(args.input.read_text(encoding="utf-8"))
    build_report(data, args.output, args.report_date)
    print(str(args.output))


if __name__ == "__main__":
    main()
