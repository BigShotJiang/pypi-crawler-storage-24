#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import itertools
import json
import math
from dataclasses import dataclass
from typing import Callable, Iterable, List, Sequence

import numpy as np
import pandas as pd

from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4.apis._ta.ta_sdk import FudstopTA


BASE_TABLE = "public.ca"


@dataclass(frozen=True)
class AddonSpec:
    label: str
    expr: str
    required: Sequence[str]
    fn: Callable[[pd.DataFrame], pd.Series]


def _parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="Auto-mine 90%+ reversal candidates from public.ca using FudstopTA.",
    )
    ap.add_argument("--timespan", default="m1")
    ap.add_argument("--lookback-days", type=int, default=180)
    ap.add_argument("--full-history", action="store_true")
    ap.add_argument("--val-days", type=int, default=60)
    ap.add_argument("--window-min", type=int, default=5)
    ap.add_argument("--window-max", type=int, default=10)
    ap.add_argument("--target-ret", type=float, default=0.003)
    ap.add_argument("--target-hit", type=float, default=0.90)
    ap.add_argument("--min-n", type=int, default=30)
    ap.add_argument("--max-k", type=int, default=2)
    ap.add_argument("--random-combos", type=int, default=0)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--include-tod", action="store_true")
    ap.add_argument(
        "--base-mode",
        default="strict",
        choices=["strict", "cross_or_imminent", "macd_cross", "rsi_td_only", "none"],
    )
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--tickers", default="")
    ap.add_argument("--max-tickers", type=int, default=0)
    ap.add_argument("--out-file", default="runs/ca_reversal_candidates_90.csv")
    ap.add_argument("--out-json", default="runs/ca_reversal_candidates_90.json")
    ap.add_argument("--no-json", action="store_true")
    ap.add_argument("--rsi-oversold", type=float, default=30.0)
    ap.add_argument("--rsi-overbought", type=float, default=70.0)
    ap.add_argument("--td-count-min", type=int, default=8)
    return ap.parse_args()


def _parse_tickers(raw: str) -> List[str]:
    return [t.strip().upper() for t in (raw or "").split(",") if t.strip()]


def _mask_ge(series: pd.Series, threshold: float) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").ge(threshold).fillna(False)


def _mask_le(series: pd.Series, threshold: float) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").le(threshold).fillna(False)


def _mask_bool(series: pd.Series) -> pd.Series:
    return series.fillna(False).astype(bool)


def _prepare_for_ta(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy().reset_index(drop=True)
    df["ts_epoch"] = pd.to_numeric(df["ts"], errors="coerce").astype("int64")
    df["ts_utc"] = pd.to_datetime(df["ts_epoch"], unit="s", utc=True)
    df["ts"] = df["ts_utc"]
    return df


def _add_macd_curvature_features(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "macd_hist" not in df.columns:
        df["macd_curvature_code"] = 0
        df["macd_imminent_bull"] = False
        df["macd_imminent_bear"] = False
        return df

    hist = pd.to_numeric(df["macd_hist"], errors="coerce").astype(float)
    h1 = hist.shift(3)
    h2 = hist.shift(2)
    h3 = hist.shift(1)
    h4 = hist

    d1 = h2 - h1
    d2 = h3 - h2
    d3 = h4 - h3

    avg_hist_vol = (d1.abs() + d2.abs() + d3.abs()) / 3.0 + 1e-9
    strong = avg_hist_vol * 0.8
    small = avg_hist_vol * 0.2
    slope = h4 - h3

    imminent = (h4.abs() < (avg_hist_vol * 0.5)) & (slope.abs() < small)

    code = pd.Series(np.zeros(len(df), dtype=np.int16), index=df.index)
    code = code.mask(imminent & (h4 < 0), 7)
    code = code.mask(imminent & (h4 >= 0), 8)

    pos = (h4 > 0) & (~imminent)
    code = code.mask(pos & (slope > strong), 1)
    code = code.mask(pos & (slope < -strong), 3)
    code = code.mask(pos & (code == 0) & (h4 > 0), 5)

    neg = (h4 < 0) & (~imminent)
    code = code.mask(neg & (slope < -strong), 2)
    code = code.mask(neg & (slope > strong), 4)
    code = code.mask(neg & (code == 0), 6)

    df["macd_curvature_code"] = code.astype("int16")
    df["macd_imminent_bull"] = df["macd_curvature_code"] == 7
    df["macd_imminent_bear"] = df["macd_curvature_code"] == 8
    return df


def _add_reversal_indicators(df: pd.DataFrame, ta: FudstopTA) -> pd.DataFrame:
    df = ta.add_macd(df)
    df = ta.compute_wilders_rsi(df)
    df = ta.add_cmo(df)
    df = ta.add_roc(df)
    df = ta.add_td9_counts(df)
    df = ta.add_ema_pack(df, periods=(9, 21, 50), slope_lookback=3)
    df = ta.add_bollinger_bands(df)
    df = ta.add_band_position_metrics(df)
    df = ta.add_atr(df)
    df = ta.add_keltner_channels(df)
    df = ta.add_choppiness_index(df)
    df = ta.add_trix(df)
    df = ta.add_relative_volume(df)
    df = ta.add_mfi(df)
    df = ta.add_stoch_rsi(df)
    df = ta.add_vwap_features(df, reset_daily=True, tz="US/Eastern")
    df = ta.add_tsi(df)
    df = ta.add_adx_clean(df)
    df = ta.add_momentum_flags(df)
    df = ta.add_candle_shape_metrics(df)
    df = ta.add_sdc_indicator(df)
    df = ta.add_ultimate_oscillator(df)
    df = ta.add_squeeze_flags(df)

    if "atr" in df.columns:
        df["atr_pct"] = df["atr"] / pd.to_numeric(df["c"], errors="coerce").replace(0, np.nan)
    else:
        df["atr_pct"] = np.nan

    if {"keltner_upper", "keltner_lower", "c"}.issubset(df.columns):
        df["keltner_width"] = (df["keltner_upper"] - df["keltner_lower"]) / pd.to_numeric(df["c"], errors="coerce").replace(0, np.nan)
    else:
        df["keltner_width"] = np.nan

    if {"sdc_upper", "sdc_lower", "c"}.issubset(df.columns):
        df["sdc_width"] = (df["sdc_upper"] - df["sdc_lower"]) / pd.to_numeric(df["c"], errors="coerce").replace(0, np.nan)
    else:
        df["sdc_width"] = np.nan

    df = _add_macd_curvature_features(df)
    return df


def _add_forward_returns(df: pd.DataFrame, window_min: int, window_max: int) -> pd.DataFrame:
    window = window_max - window_min + 1
    if window <= 0:
        raise ValueError("window_max must be >= window_min")

    high = pd.to_numeric(df["h"], errors="coerce").astype(float)
    low = pd.to_numeric(df["l"], errors="coerce").astype(float)
    close = pd.to_numeric(df["c"], errors="coerce").astype(float)

    max_h = (
        high.shift(-window_min)
        .rolling(window=window, min_periods=window)
        .max()
        .shift(-(window - 1))
    )
    min_l = (
        low.shift(-window_min)
        .rolling(window=window, min_periods=window)
        .min()
        .shift(-(window - 1))
    )

    denom = close.replace(0, np.nan)
    df["best_up_ret"] = (max_h / denom) - 1.0
    df["best_down_ret"] = (denom / min_l.replace(0, np.nan)) - 1.0
    return df


def _build_addons(side: str, *, include_tod: bool) -> List[AddonSpec]:
    common = [
        AddonSpec("bb_width>=0.03", "bb_width >= 0.03", ("bb_width",), lambda d: _mask_ge(d["bb_width"], 0.03)),
        AddonSpec("bb_width>=0.04", "bb_width >= 0.04", ("bb_width",), lambda d: _mask_ge(d["bb_width"], 0.04)),
        AddonSpec("bb_width<=0.02", "bb_width <= 0.02", ("bb_width",), lambda d: _mask_le(d["bb_width"], 0.02)),
        AddonSpec("atr_pct>=0.003", "atr_pct >= 0.003", ("atr_pct",), lambda d: _mask_ge(d["atr_pct"], 0.003)),
        AddonSpec("atr_pct>=0.006", "atr_pct >= 0.006", ("atr_pct",), lambda d: _mask_ge(d["atr_pct"], 0.006)),
        AddonSpec("keltner_width>=0.01", "keltner_width >= 0.01", ("keltner_width",), lambda d: _mask_ge(d["keltner_width"], 0.01)),
        AddonSpec("keltner_width<=0.01", "keltner_width <= 0.01", ("keltner_width",), lambda d: _mask_le(d["keltner_width"], 0.01)),
        AddonSpec("sdc_width>=0.01", "sdc_width >= 0.01", ("sdc_width",), lambda d: _mask_ge(d["sdc_width"], 0.01)),
        AddonSpec("sdc_width<=0.01", "sdc_width <= 0.01", ("sdc_width",), lambda d: _mask_le(d["sdc_width"], 0.01)),
        AddonSpec("rvol>=1.5", "rvol >= 1.5", ("rvol",), lambda d: _mask_ge(d["rvol"], 1.5)),
        AddonSpec("rvol>=2.0", "rvol >= 2.0", ("rvol",), lambda d: _mask_ge(d["rvol"], 2.0)),
        AddonSpec("volume_confirm", "volume_confirm = true", ("volume_confirm",), lambda d: _mask_bool(d["volume_confirm"])),
        AddonSpec("bb_close_outside_lower", "bb_close_outside_lower = true", ("bb_close_outside_lower",), lambda d: _mask_bool(d["bb_close_outside_lower"])),
        AddonSpec("bb_close_outside_upper", "bb_close_outside_upper = true", ("bb_close_outside_upper",), lambda d: _mask_bool(d["bb_close_outside_upper"])),
        AddonSpec("adx_strong", "adx_strong = true", ("adx_strong",), lambda d: _mask_bool(d["adx_strong"])),
        AddonSpec("adx>=25", "adx >= 25", ("adx",), lambda d: _mask_ge(d["adx"], 25)),
        AddonSpec("trend_regime", "trend_regime = true", ("trend_regime",), lambda d: _mask_bool(d["trend_regime"])),
        AddonSpec("chop<=45", "chop <= 45", ("chop",), lambda d: _mask_le(d["chop"], 45)),
        AddonSpec("chop>=60", "chop >= 60", ("chop",), lambda d: _mask_ge(d["chop"], 60)),
        AddonSpec("squeeze_off", "squeeze_off = true", ("squeeze_off",), lambda d: _mask_bool(d["squeeze_off"])),
    ]
    if include_tod:
        common += [
            AddonSpec("tod_open", "tod_open = true", ("tod_open",), lambda d: _mask_bool(d["tod_open"])),
            AddonSpec("tod_mid", "tod_mid = true", ("tod_mid",), lambda d: _mask_bool(d["tod_mid"])),
            AddonSpec("tod_close", "tod_close = true", ("tod_close",), lambda d: _mask_bool(d["tod_close"])),
        ]

    if side == "bull":
        return common + [
            AddonSpec("cmo<=-40", "cmo <= -40", ("cmo",), lambda d: _mask_le(d["cmo"], -40)),
            AddonSpec("cmo<=-50", "cmo <= -50", ("cmo",), lambda d: _mask_le(d["cmo"], -50)),
            AddonSpec("roc<=-1", "roc <= -1", ("roc",), lambda d: _mask_le(d["roc"], -1)),
            AddonSpec("roc<=-2", "roc <= -2", ("roc",), lambda d: _mask_le(d["roc"], -2)),
            AddonSpec("mfi<=20", "mfi <= 20", ("mfi",), lambda d: _mask_le(d["mfi"], 20)),
            AddonSpec("mfi<=10", "mfi <= 10", ("mfi",), lambda d: _mask_le(d["mfi"], 10)),
            AddonSpec("stoch_rsi_k<=20", "stoch_rsi_k <= 20", ("stoch_rsi_k",), lambda d: _mask_le(d["stoch_rsi_k"], 20)),
            AddonSpec("stoch_rsi_k<=10", "stoch_rsi_k <= 10", ("stoch_rsi_k",), lambda d: _mask_le(d["stoch_rsi_k"], 10)),
            AddonSpec("ultimate_osc<=30", "ultimate_osc <= 30", ("ultimate_osc",), lambda d: _mask_le(d["ultimate_osc"], 30)),
            AddonSpec("trix<=-0.1", "trix <= -0.1", ("trix",), lambda d: _mask_le(d["trix"], -0.1)),
            AddonSpec("trix<=-0.2", "trix <= -0.2", ("trix",), lambda d: _mask_le(d["trix"], -0.2)),
            AddonSpec("vwap_dist<=-0.01", "vwap_dist_pct <= -0.01", ("vwap_dist_pct",), lambda d: _mask_le(d["vwap_dist_pct"], -0.01)),
            AddonSpec("vwap_dist<=-0.02", "vwap_dist_pct <= -0.02", ("vwap_dist_pct",), lambda d: _mask_le(d["vwap_dist_pct"], -0.02)),
            AddonSpec("vwap_cross_up", "vwap_cross_up = true", ("vwap_cross_up",), lambda d: _mask_bool(d["vwap_cross_up"])),
            AddonSpec("ema_stack_bull", "ema_stack_bull = true", ("ema_stack_bull",), lambda d: _mask_bool(d["ema_stack_bull"])),
            AddonSpec("macd_cross_up", "macd_cross_up = true", ("macd_cross_up",), lambda d: _mask_bool(d["macd_cross_up"])),
            AddonSpec("tsi_cross_up", "tsi_cross_up = true", ("tsi_cross_up",), lambda d: _mask_bool(d["tsi_cross_up"])),
            AddonSpec("di_bull", "di_bull = true", ("di_bull",), lambda d: _mask_bool(d["di_bull"])),
            AddonSpec(
                "candle_below_band",
                "candle_completely_below_lower = true",
                ("candle_completely_below_lower",),
                lambda d: _mask_bool(d["candle_completely_below_lower"]),
            ),
            AddonSpec("candle_green", "candle_green = true", ("candle_green",), lambda d: _mask_bool(d["candle_green"])),
        ]

    return common + [
        AddonSpec("cmo>=40", "cmo >= 40", ("cmo",), lambda d: _mask_ge(d["cmo"], 40)),
        AddonSpec("cmo>=50", "cmo >= 50", ("cmo",), lambda d: _mask_ge(d["cmo"], 50)),
        AddonSpec("roc>=1", "roc >= 1", ("roc",), lambda d: _mask_ge(d["roc"], 1)),
        AddonSpec("roc>=2", "roc >= 2", ("roc",), lambda d: _mask_ge(d["roc"], 2)),
        AddonSpec("mfi>=80", "mfi >= 80", ("mfi",), lambda d: _mask_ge(d["mfi"], 80)),
        AddonSpec("mfi>=90", "mfi >= 90", ("mfi",), lambda d: _mask_ge(d["mfi"], 90)),
        AddonSpec("stoch_rsi_k>=80", "stoch_rsi_k >= 80", ("stoch_rsi_k",), lambda d: _mask_ge(d["stoch_rsi_k"], 80)),
        AddonSpec("stoch_rsi_k>=90", "stoch_rsi_k >= 90", ("stoch_rsi_k",), lambda d: _mask_ge(d["stoch_rsi_k"], 90)),
        AddonSpec("ultimate_osc>=70", "ultimate_osc >= 70", ("ultimate_osc",), lambda d: _mask_ge(d["ultimate_osc"], 70)),
        AddonSpec("trix>=0.1", "trix >= 0.1", ("trix",), lambda d: _mask_ge(d["trix"], 0.1)),
        AddonSpec("trix>=0.2", "trix >= 0.2", ("trix",), lambda d: _mask_ge(d["trix"], 0.2)),
        AddonSpec("vwap_dist>=0.01", "vwap_dist_pct >= 0.01", ("vwap_dist_pct",), lambda d: _mask_ge(d["vwap_dist_pct"], 0.01)),
        AddonSpec("vwap_dist>=0.02", "vwap_dist_pct >= 0.02", ("vwap_dist_pct",), lambda d: _mask_ge(d["vwap_dist_pct"], 0.02)),
        AddonSpec("vwap_cross_dn", "vwap_cross_dn = true", ("vwap_cross_dn",), lambda d: _mask_bool(d["vwap_cross_dn"])),
        AddonSpec("ema_stack_bear", "ema_stack_bear = true", ("ema_stack_bear",), lambda d: _mask_bool(d["ema_stack_bear"])),
        AddonSpec("macd_cross_dn", "macd_cross_dn = true", ("macd_cross_dn",), lambda d: _mask_bool(d["macd_cross_dn"])),
        AddonSpec("tsi_cross_dn", "tsi_cross_dn = true", ("tsi_cross_dn",), lambda d: _mask_bool(d["tsi_cross_dn"])),
        AddonSpec("di_bear", "di_bear = true", ("di_bear",), lambda d: _mask_bool(d["di_bear"])),
        AddonSpec(
            "candle_above_band",
            "candle_completely_above_upper = true",
            ("candle_completely_above_upper",),
            lambda d: _mask_bool(d["candle_completely_above_upper"]),
        ),
        AddonSpec("candle_red", "candle_red = true", ("candle_red",), lambda d: _mask_bool(d["candle_red"])),
    ]


def _apply_addons(df: pd.DataFrame, specs: List[AddonSpec]) -> List[tuple[AddonSpec, pd.Series]]:
    out: List[tuple[AddonSpec, pd.Series]] = []
    for spec in specs:
        if not set(spec.required).issubset(df.columns):
            continue
        mask = spec.fn(df)
        if mask is None:
            continue
        out.append((spec, mask.fillna(False).astype(bool)))
    return out


def _scan_side(
    df: pd.DataFrame,
    side: str,
    *,
    base_mask: pd.Series,
    base_mode: str,
    target_ret: float,
    target_hit: float,
    min_n: int,
    max_k: int,
    window_min: int,
    window_max: int,
    random_combos: int,
    rng: np.random.Generator,
    include_tod: bool,
) -> List[dict]:
    if df.empty:
        return []

    ret_col = "best_up_ret" if side == "bull" else "best_down_ret"
    base_df = df[df["is_val"] & base_mask].copy()
    base_df = base_df[np.isfinite(base_df[ret_col])]
    if base_df.empty:
        return []

    base_df["hit_20bp"] = base_df[ret_col] >= float(target_ret)

    ny = base_df["ts_utc"].dt.tz_convert("America/New_York")
    tod = ny.dt.time
    base_df["tod_open"] = (tod >= dt.time(9, 30)) & (tod < dt.time(10, 30))
    base_df["tod_mid"] = (tod >= dt.time(10, 30)) & (tod < dt.time(15, 0))
    base_df["tod_close"] = (tod >= dt.time(15, 0)) & (tod < dt.time(16, 0))

    addons = _apply_addons(base_df, _build_addons(side, include_tod=include_tod))
    results: List[dict] = []

    total_possible = 0
    if addons:
        n_addons = len(addons)
        total_possible = sum(math.comb(n_addons, k) for k in range(1, max_k + 1))

    def _iter_combos() -> Iterable[tuple]:
        if random_combos <= 0 or total_possible <= 0 or random_combos >= total_possible:
            for k in range(1, max_k + 1):
                for combo in itertools.combinations(addons, k):
                    yield combo
            return
        seen = set()
        attempts = 0
        max_attempts = random_combos * 25
        while len(seen) < random_combos and attempts < max_attempts:
            attempts += 1
            k = int(rng.integers(1, max_k + 1))
            idxs = tuple(sorted(rng.choice(len(addons), size=k, replace=False)))
            if idxs in seen:
                continue
            seen.add(idxs)
            yield tuple(addons[i] for i in idxs)

    for combo in _iter_combos():
            specs = [c[0] for c in combo]
            mask = combo[0][1].copy()
            for _, m in combo[1:]:
                mask &= m
            n_val = int(mask.sum())
            if n_val < min_n:
                continue
            hit = float(base_df.loc[mask, "hit_20bp"].mean())
            if hit < target_hit:
                continue
            avg_move = float(base_df.loc[mask, ret_col].mean())
            p15 = float(np.quantile(base_df.loc[mask, ret_col].values, 0.15))
            tickers_val = int(base_df.loc[mask, "ticker"].nunique())
            label = " AND ".join([s.label for s in specs])
            conditions = [s.expr for s in specs]

            results.append(
                {
                    "found_at_utc": dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z"),
                    "side": side,
                    "base_mode": base_mode,
                    "label": label,
                    "conditions": conditions,
                    "n_val": n_val,
                    "tickers_val": tickers_val,
                    "hit_20bp": hit,
                    "avg_best_move": avg_move,
                    "p15_best_move": p15,
                    "window_min": window_min,
                    "window_max": window_max,
                }
            )
    return results


async def _fetch_ca_rows(
    db: PolygonOptions,
    *,
    timespan: str,
    start_ts: int | None,
    tickers: Sequence[str],
) -> List[dict]:
    start_ts_text = str(start_ts) if start_ts is not None else None
    if tickers:
        if start_ts is None:
            sql = f"""
                SELECT ts, o, h, l, c, v, vw, ticker, timespan
                FROM {BASE_TABLE}
                WHERE timespan = $1
                  AND ticker = ANY($2)
            """
            return await db.fetch_new(sql, timespan, list(tickers))
        sql = f"""
            SELECT ts, o, h, l, c, v, vw, ticker, timespan
            FROM {BASE_TABLE}
            WHERE timespan = $1
              AND ts >= $2
              AND ticker = ANY($3)
        """
        return await db.fetch_new(sql, timespan, start_ts_text, list(tickers))
    if start_ts is None:
        sql = f"""
            SELECT ts, o, h, l, c, v, vw, ticker, timespan
            FROM {BASE_TABLE}
            WHERE timespan = $1
        """
        return await db.fetch_new(sql, timespan)
    sql = f"""
        SELECT ts, o, h, l, c, v, vw, ticker, timespan
        FROM {BASE_TABLE}
        WHERE timespan = $1
          AND ts >= $2
    """
    return await db.fetch_new(sql, timespan, start_ts_text)


async def _load_tickers(db: PolygonOptions, timespan: str, max_tickers: int) -> List[str]:
    if max_tickers <= 0:
        return []
    sql = f"""
        SELECT DISTINCT ticker
        FROM {BASE_TABLE}
        WHERE timespan = $1
        ORDER BY ticker
        LIMIT $2
    """
    rows = await db.fetch_new(sql, timespan, max_tickers)
    return [str(r["ticker"]) for r in rows]


async def main() -> None:
    args = _parse_args()
    tickers = _parse_tickers(args.tickers)

    db = PolygonOptions()
    await db.connect()
    try:
        if not tickers and args.max_tickers > 0:
            tickers = await _load_tickers(db, args.timespan, args.max_tickers)
        start_ts = None
        if not args.full_history:
            start_ts = int(dt.datetime.now(dt.timezone.utc).timestamp()) - int(args.lookback_days * 86400)
        rows = await _fetch_ca_rows(db, timespan=args.timespan, start_ts=start_ts, tickers=tickers)
    finally:
        await db.disconnect()

    if not rows:
        print("no_rows")
        return

    df = pd.DataFrame([dict(r) for r in rows])
    for col in ["o", "h", "l", "c", "v", "vw", "ts"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["ts", "ticker"])
    if df.empty:
        print("no_rows")
        return

    ta = FudstopTA()
    frames = []
    for ticker, group in df.groupby("ticker"):
        g = group.sort_values("ts", kind="mergesort").copy()
        g = _prepare_for_ta(g)
        g = _add_reversal_indicators(g, ta)
        g = _add_forward_returns(g, args.window_min, args.window_max)
        frames.append(g)

    full = pd.concat(frames, ignore_index=True, copy=False)
    max_ts = pd.to_numeric(full["ts_epoch"], errors="coerce").max()
    if not np.isfinite(max_ts):
        print("no_valid_ts")
        return

    cutoff = int(max_ts) - int(args.val_days * 86400)
    full["is_val"] = pd.to_numeric(full["ts_epoch"], errors="coerce") >= cutoff

    full["rsi"] = pd.to_numeric(full.get("rsi"), errors="coerce")
    full["td_buy_count"] = pd.to_numeric(full.get("td_buy_count"), errors="coerce")
    full["td_sell_count"] = pd.to_numeric(full.get("td_sell_count"), errors="coerce")

    base_bull = (full["rsi"] <= float(args.rsi_oversold)) & (full["td_buy_count"] >= int(args.td_count_min))
    base_bear = (full["rsi"] >= float(args.rsi_overbought)) & (full["td_sell_count"] >= int(args.td_count_min))
    macd_imminent_bull = full.get("macd_imminent_bull", False).fillna(False)
    macd_imminent_bear = full.get("macd_imminent_bear", False).fillna(False)
    macd_cross_up = full.get("macd_cross_up", False).fillna(False)
    macd_cross_dn = full.get("macd_cross_dn", False).fillna(False)

    if args.base_mode == "strict":
        bull_base = base_bull & macd_imminent_bull
        bear_base = base_bear & macd_imminent_bear
    elif args.base_mode == "macd_cross":
        bull_base = base_bull & macd_cross_up
        bear_base = base_bear & macd_cross_dn
    elif args.base_mode == "cross_or_imminent":
        bull_base = base_bull & (macd_imminent_bull | macd_cross_up)
        bear_base = base_bear & (macd_imminent_bear | macd_cross_dn)
    elif args.base_mode == "none":
        bull_base = pd.Series(True, index=full.index)
        bear_base = pd.Series(True, index=full.index)
    else:
        bull_base = base_bull
        bear_base = base_bear

    if args.debug:
        bull_total = int(bull_base.sum())
        bear_total = int(bear_base.sum())
        bull_val = int((bull_base & full["is_val"]).sum())
        bear_val = int((bear_base & full["is_val"]).sum())
        print(
            f"base_counts mode={args.base_mode} bull_total={bull_total} bear_total={bear_total} "
            f"bull_val={bull_val} bear_val={bear_val}"
        )

    bull_results = _scan_side(
        full,
        "bull",
        base_mask=bull_base,
        base_mode=args.base_mode,
        target_ret=args.target_ret,
        target_hit=args.target_hit,
        min_n=args.min_n,
        max_k=args.max_k,
        window_min=args.window_min,
        window_max=args.window_max,
        random_combos=args.random_combos,
        rng=np.random.default_rng(args.seed),
        include_tod=args.include_tod,
    )
    bear_results = _scan_side(
        full,
        "bear",
        base_mask=bear_base,
        base_mode=args.base_mode,
        target_ret=args.target_ret,
        target_hit=args.target_hit,
        min_n=args.min_n,
        max_k=args.max_k,
        window_min=args.window_min,
        window_max=args.window_max,
        random_combos=args.random_combos,
        rng=np.random.default_rng(args.seed + 1),
        include_tod=args.include_tod,
    )

    all_rows = bull_results + bear_results
    if not all_rows:
        print("no_candidates")
        return

    out_df = pd.DataFrame(all_rows)
    out_df = out_df.sort_values(["hit_20bp", "n_val"], ascending=[False, False])
    out_path = args.out_file
    out_df.to_csv(out_path, index=False)
    print(f"wrote_candidates={out_path}")

    if not args.no_json:
        json_path = args.out_json
        payload = out_df.to_dict(orient="records")
        with open(json_path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        print(f"wrote_candidates_json={json_path}")


if __name__ == "__main__":
    asyncio.run(main())
