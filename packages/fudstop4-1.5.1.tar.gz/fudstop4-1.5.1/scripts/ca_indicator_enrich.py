#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import os
import time
from typing import Iterable, List, Optional

import numpy as np
import pandas as pd

from fudstop4.apis._ta.ta_sdk import FudstopTA
from fudstop4.apis.polygonio.polygon_options import PolygonOptions


def _parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Enrich public.ca with TA indicators for better signals.")
    ap.add_argument("--schema", default=os.getenv("CA_ENRICH_SCHEMA", "public"))
    ap.add_argument("--table", default=os.getenv("CA_ENRICH_TABLE", "ca"))
    ap.add_argument("--timespan", default=os.getenv("CA_ENRICH_TIMESPAN", "m1"))
    ap.add_argument("--pack", choices=["minimal", "core", "full"], default=os.getenv("CA_ENRICH_PACK", "full"))
    ap.add_argument("--lookback-minutes", type=int, default=int(os.getenv("CA_ENRICH_LOOKBACK_MINUTES", "240")))
    ap.add_argument("--warmup-minutes", type=int, default=int(os.getenv("CA_ENRICH_WARMUP_MINUTES", "240")))
    ap.add_argument("--tickers", default=os.getenv("CA_ENRICH_TICKERS", ""))
    ap.add_argument("--max-tickers", type=int, default=int(os.getenv("CA_ENRICH_MAX_TICKERS", "0")))
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--batch-size", type=int, default=int(os.getenv("CA_ENRICH_BATCH_SIZE", "5000")))
    ap.add_argument("--tz", default=os.getenv("CA_ENRICH_TZ", "US/Eastern"))
    return ap.parse_args()


def _parse_tickers(raw: str) -> List[str]:
    return [t.strip().upper() for t in (raw or "").split(",") if t.strip()]


def _normalize_ts(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["ts_epoch"] = pd.to_numeric(d["ts"], errors="coerce")
    d = d.dropna(subset=["ts_epoch"]).copy()
    if d.empty:
        return d
    d["ts_epoch"] = d["ts_epoch"].astype("int64")
    d = d.sort_values("ts_epoch").reset_index(drop=True)
    d["ts_utc"] = pd.to_datetime(d["ts_epoch"], unit="s", utc=True)
    return d


def _add_macd_curvature_features(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "macd_hist" not in df.columns:
        df["macd_curvature_code"] = 0
        df["macd_imminent_bull"] = False
        df["macd_imminent_bear"] = False
        return df

    hist = pd.to_numeric(df["macd_hist"], errors="coerce").astype(float)
    h1 = hist.shift(3)
    h2 = hist.shift(2)
    h3 = hist.shift(1)
    h4 = hist

    d1 = h2 - h1
    d2 = h3 - h2
    d3 = h4 - h3

    avg_hist_vol = (d1.abs() + d2.abs() + d3.abs()) / 3.0 + 1e-9
    strong = avg_hist_vol * 0.8
    small = avg_hist_vol * 0.2
    slope = h4 - h3

    imminent = (h4.abs() < (avg_hist_vol * 0.5)) & (slope.abs() < small)

    code = pd.Series(np.zeros(len(df), dtype=np.int16), index=df.index)
    code = code.mask(imminent & (h4 < 0), 7)
    code = code.mask(imminent & (h4 >= 0), 8)

    pos = (h4 > 0) & (~imminent)
    code = code.mask(pos & (slope > strong), 1)
    code = code.mask(pos & (slope < -strong), 3)
    code = code.mask(pos & (code == 0) & (h4 > 0), 5)

    neg = (h4 < 0) & (~imminent)
    code = code.mask(neg & (slope < -strong), 2)
    code = code.mask(neg & (slope > strong), 4)
    code = code.mask(neg & (code == 0), 6)

    df["macd_curvature_code"] = code.astype("int16")
    df["macd_imminent_bull"] = df["macd_curvature_code"] == 7
    df["macd_imminent_bear"] = df["macd_curvature_code"] == 8
    return df


def _compute_indicators(df: pd.DataFrame, pack: str, tz: str) -> pd.DataFrame:
    d = _normalize_ts(df)
    if d.empty:
        return d

    d = FudstopTA.compute_wilders_rsi(d, window=14)
    d = FudstopTA.add_td9_counts(d)
    d = FudstopTA.add_macd(d, fast_period=12, slow_period=26, signal_period=9)
    d = _add_macd_curvature_features(d)

    if pack == "minimal":
        return d

    d = FudstopTA.add_bollinger_bands(d, window=20, num_std=2.0)
    d = FudstopTA.add_band_position_metrics(d)
    d = FudstopTA.add_candle_shape_metrics(d)
    d = FudstopTA.add_relative_volume(d, window=20)
    d = FudstopTA.add_atr(d, window=14)
    d = FudstopTA.add_choppiness_index(d, window=14)

    ts_raw = d["ts"]
    d["ts"] = d["ts_utc"]
    d = FudstopTA.add_vwap_features(d, reset_daily=True, tz=tz)
    d["ts"] = ts_raw

    d = FudstopTA.add_stoch_rsi(d, rsi_window=14, stoch_window=14, k_smooth=3, d_smooth=3)
    d = FudstopTA.add_mfi(d, window=14)
    d = FudstopTA.add_cmo(d, window=14)
    d = FudstopTA.add_roc(d, window=12)

    if pack == "core":
        return d

    d = FudstopTA.add_ema_pack(d, periods=(9, 21, 50), slope_lookback=3)
    d = FudstopTA.add_keltner_channels(d, window=20, atr_window=10, atr_multiplier=2.0)
    d = FudstopTA.add_trix(d, window=15, signal_period=9)
    d = FudstopTA.add_ultimate_oscillator(d, short=7, medium=14, long=28)
    d = FudstopTA.add_tsi(d, long=25, short=13, signal=7)
    d = FudstopTA.add_adx_clean(d, window=14)
    d = FudstopTA.add_sdc_indicator(d, window=50, dev_up=1.5, dev_dn=1.5)
    d = FudstopTA.add_squeeze_flags(d)
    d = FudstopTA.add_momentum_flags(d)
    return d


def _with_derived_metrics(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    if "atr" in d.columns and "c" in d.columns:
        d["atr_pct"] = pd.to_numeric(d["atr"], errors="coerce") / pd.to_numeric(d["c"], errors="coerce").replace(0, np.nan)
    if {"keltner_upper", "keltner_lower", "c"}.issubset(d.columns):
        d["keltner_width"] = (pd.to_numeric(d["keltner_upper"], errors="coerce") - pd.to_numeric(d["keltner_lower"], errors="coerce")) / pd.to_numeric(d["c"], errors="coerce").replace(0, np.nan)
    if {"sdc_upper", "sdc_lower", "c"}.issubset(d.columns):
        d["sdc_width"] = (pd.to_numeric(d["sdc_upper"], errors="coerce") - pd.to_numeric(d["sdc_lower"], errors="coerce")) / pd.to_numeric(d["c"], errors="coerce").replace(0, np.nan)
    return d


def _indicator_columns() -> List[str]:
    return [
        "rsi",
        "td_buy_count",
        "td_sell_count",
        "macd_line",
        "macd_signal",
        "macd_hist",
        "macd_cross_up",
        "macd_cross_dn",
        "macd_hist_slope",
        "macd_hist_slope3",
        "macd_curvature_code",
        "macd_imminent_bull",
        "macd_imminent_bear",
        "bb_width",
        "bb_close_outside_lower",
        "bb_close_outside_upper",
        "candle_completely_below_lower",
        "candle_completely_above_upper",
        "candle_green",
        "candle_red",
        "rvol",
        "atr",
        "atr_pct",
        "chop",
        "vwap_sess",
        "vwap_dist_pct",
        "vwap_cross_up",
        "vwap_cross_dn",
        "stoch_rsi_k",
        "stoch_rsi_d",
        "mfi",
        "cmo",
        "roc",
        "trix",
        "ultimate_osc",
        "keltner_upper",
        "keltner_lower",
        "keltner_width",
        "sdc_upper",
        "sdc_lower",
        "sdc_width",
        "tsi",
        "tsi_signal",
        "tsi_cross_up",
        "tsi_cross_dn",
        "adx",
        "di_plus",
        "di_minus",
        "adx_strong",
        "di_bull",
        "di_bear",
        "macd_bull",
        "macd_bear",
        "tsi_bull",
        "tsi_bear",
        "trend_regime",
        "volume_confirm",
        "momentum_confirm_bull",
        "momentum_confirm_bear",
        "squeeze_on",
        "squeeze_off",
        "ema_stack_bull",
        "ema_stack_bear",
    ]


def _dtype_to_postgres(dtype: object) -> str:
    if pd.api.types.is_bool_dtype(dtype):
        return "BOOLEAN"
    if pd.api.types.is_integer_dtype(dtype):
        return "INTEGER"
    if pd.api.types.is_float_dtype(dtype):
        return "REAL"
    if pd.api.types.is_datetime64_any_dtype(dtype):
        return "TIMESTAMP"
    return "TEXT"


async def _fetch_candles(
    db: PolygonOptions,
    *,
    schema: str,
    table: str,
    timespan: str,
    ticker: str,
    start_ts: int,
) -> List[dict]:
    sql = f"""
        SELECT ts, o, h, l, c, v, vw, ticker, timespan
        FROM {schema}.{table}
        WHERE timespan = $1
          AND ticker = $2
          AND ts >= $3
        ORDER BY ts ASC
    """
    return await db.fetch_new(sql, timespan, ticker, str(start_ts))


async def _load_tickers(
    db: PolygonOptions,
    *,
    schema: str,
    table: str,
    timespan: str,
    max_tickers: int,
) -> List[str]:
    sql = f"""
        SELECT DISTINCT ticker
        FROM {schema}.{table}
        WHERE timespan = $1
        ORDER BY ticker
        {f"LIMIT {int(max_tickers)}" if max_tickers > 0 else ""}
    """
    rows = await db.fetch_new(sql, timespan)
    return [str(r["ticker"]) for r in rows]


async def main() -> None:
    args = _parse_args()
    tickers = _parse_tickers(args.tickers)

    now_epoch = int(time.time())
    start_ts = now_epoch - int((args.lookback_minutes + args.warmup_minutes) * 60)
    update_ts = now_epoch - int(args.lookback_minutes * 60)

    db = PolygonOptions()
    await db.connect()

    if not tickers:
        tickers = await _load_tickers(
            db,
            schema=args.schema,
            table=args.table,
            timespan=args.timespan,
            max_tickers=args.max_tickers,
        )

    if not tickers:
        print("no_tickers")
        return

    table_name = args.table
    indicators = _indicator_columns()
    existing_cols = {c.lower() for c in (await db.get_table_columns(table_name))}
    ensured_cols: set[str] = set(existing_cols)

    total_rows = 0
    for ticker in tickers:
        rows = await _fetch_candles(
            db,
            schema=args.schema,
            table=args.table,
            timespan=args.timespan,
            ticker=ticker,
            start_ts=start_ts,
        )
        if not rows:
            continue

        df = pd.DataFrame([dict(r) for r in rows])
        df = _compute_indicators(df, args.pack, args.tz)
        df = _with_derived_metrics(df)

        if df.empty:
            continue

        df = df[df["ts_epoch"] >= update_ts].copy()
        if df.empty:
            continue

        keep_cols = ["ticker", "timespan", "ts"] + [c for c in indicators if c in df.columns]
        out = df[keep_cols].copy()
        out = out.dropna(subset=["ticker", "timespan", "ts"])
        if out.empty:
            continue

        total_rows += len(out)
        if not args.write:
            continue

        missing = [c for c in out.columns if c.lower() not in ensured_cols]
        if missing:
            for col in missing:
                await db.add_column_to_table(table_name, col, _dtype_to_postgres(out[col].dtype))
            ensured_cols.update([c.lower() for c in missing])
            db._column_type_cache.pop(table_name, None)

        await db.batch_upsert_dataframe(
            out,
            table_name=table_name,
            unique_columns=["ticker", "timespan", "ts"],
            batch_size=args.batch_size,
        )

    print(f"enrich_done tickers={len(tickers)} rows={total_rows} write={bool(args.write)}")


if __name__ == "__main__":
    asyncio.run(main())
