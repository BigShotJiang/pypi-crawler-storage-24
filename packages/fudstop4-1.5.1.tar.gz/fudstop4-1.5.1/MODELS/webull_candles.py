import warnings
from typing import Any, Iterable, List, Optional

import numpy as np
import pandas as pd


_INVALID = {None, "", "--", "null", "NULL", "nan", "NaN", "NAN", "\u2014"}


def _clean_float(value: Any) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float, np.number)):
        if isinstance(value, float) and np.isnan(value):
            return 0.0
        return float(value)
    s = str(value).strip()
    if s in _INVALID:
        return 0.0
    try:
        return float(s)
    except Exception:
        return 0.0


def _clean_int(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, (int, np.integer)):
        return int(value)
    if isinstance(value, (float, np.floating)):
        if np.isnan(value):
            return 0
        return int(value)
    s = str(value).strip()
    if s in _INVALID:
        return 0
    try:
        return int(float(s))
    except Exception:
        return 0


def _get(parts: List[str], idx: int) -> Optional[str]:
    return parts[idx] if idx < len(parts) else None


class WebullCandles:
    def __init__(
        self,
        data: Iterable[Any],
        *,
        ticker: str,
        ticker_id: int,
        timespan: str,
        fast_parse: bool = False,
    ):
        rows = [r.strip() for r in data if isinstance(r, str) and r.strip()]

        if not rows:
            self.data_dict = {
                "ts": [],
                "o": [],
                "c": [],
                "h": [],
                "l": [],
                "vw": [],
                "v": [],
                "a": [],
                "ticker": [],
                "ticker_id": [],
                "timespan": [],
            }
            self.as_dataframe = pd.DataFrame(self.data_dict)
            return

        if fast_parse:
            try:
                if any(r.count(",") < 7 for r in rows):
                    raise ValueError("unexpected row format")

                blob = ",".join(rows)
                expected = len(rows) * 8

                with warnings.catch_warnings():
                    warnings.filterwarnings("error", category=DeprecationWarning)
                    arr = np.fromstring(blob, sep=",", dtype=np.float64)

                if arr.size != expected:
                    raise ValueError("row parse size mismatch")

                arr = arr.reshape(-1, 8)

                self.ts = [_clean_int(v) for v in arr[:, 0]]
                self.o = [_clean_float(v) for v in arr[:, 1]]
                self.c = [_clean_float(v) for v in arr[:, 2]]
                self.h = [_clean_float(v) for v in arr[:, 3]]
                self.l = [_clean_float(v) for v in arr[:, 4]]
                self.vw = [_clean_float(v) for v in arr[:, 5]]
                self.v = [_clean_float(v) for v in arr[:, 6]]
                self.a = [_clean_float(v) for v in arr[:, 7]]

                n = len(self.ts)
                self.ticker = [str(ticker) for _ in range(n)]
                self.ticker_id = [int(ticker_id) for _ in range(n)]
                self.timespan = [str(timespan) for _ in range(n)]

                self.data_dict = {
                    "ts": self.ts,
                    "o": self.o,
                    "c": self.c,
                    "h": self.h,
                    "l": self.l,
                    "vw": self.vw,
                    "v": self.v,
                    "a": self.a,
                    "ticker": self.ticker,
                    "ticker_id": self.ticker_id,
                    "timespan": self.timespan,
                }
                self.as_dataframe = pd.DataFrame(self.data_dict)
                return
            except Exception:
                pass

        parts_list = [r.split(",") for r in rows]

        self.ts = [_clean_int(_get(parts, 0)) for parts in parts_list]
        self.o = [_clean_float(_get(parts, 1)) for parts in parts_list]
        self.c = [_clean_float(_get(parts, 2)) for parts in parts_list]
        self.h = [_clean_float(_get(parts, 3)) for parts in parts_list]
        self.l = [_clean_float(_get(parts, 4)) for parts in parts_list]
        self.vw = [_clean_float(_get(parts, 5)) for parts in parts_list]
        self.v = [_clean_float(_get(parts, 6)) for parts in parts_list]
        self.a = [_clean_float(_get(parts, 7)) for parts in parts_list]

        n = len(self.ts)
        self.ticker = [str(ticker) for _ in range(n)]
        self.ticker_id = [int(ticker_id) for _ in range(n)]
        self.timespan = [str(timespan) for _ in range(n)]

        self.data_dict = {
            "ts": self.ts,
            "o": self.o,
            "c": self.c,
            "h": self.h,
            "l": self.l,
            "vw": self.vw,
            "v": self.v,
            "a": self.a,
            "ticker": self.ticker,
            "ticker_id": self.ticker_id,
            "timespan": self.timespan,
        }
        self.as_dataframe = pd.DataFrame(self.data_dict)
