import asyncio
import os
from datetime import timedelta

import pandas as pd
from dotenv import load_dotenv
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

load_dotenv()

db = PolygonOptions()

# ---- Feed config ----
HOOK_URL = resolve_webhook_url(
    "SECAPI_BEAR_WEBHOOK",
    "MID_TERM",
    route_id="secapi_bear",
)
LIVE_TABLE = os.getenv("CANDLE_LIVE_TABLE", "ca_live")
TIMESPAN = os.getenv("SECAPI_BEAR_TIMESPAN", "m1")
LOOKBACK_MINUTES = int(os.getenv("SECAPI_BEAR_LOOKBACK_MINUTES", "3"))
COOLDOWN_MINUTES = int(os.getenv("SECAPI_BEAR_COOLDOWN_MINUTES", "20"))
POLL_SECONDS = float(os.getenv("SECAPI_BEAR_POLL_SECONDS", "5"))

# ---- Rule (practice short) ----
RSI_HIGH = 70.0
TD_SELL_MIN = 8
VWAP_DIST_MIN = 0.005
BB_WIDTH_MIN = 0.04

# ---- Backtest stats (entry=next_open, exit=close, window=1-30, cooldown=20) ----
HOLD_MIN = 1
HOLD_MAX = 30
PROB_20BP = 0.8636
PROB_50BP = 0.6364


async def main() -> None:
    await db.connect()
    last_sent = {}

    while True:
        query = f"""
            SELECT
                ticker,
                timespan,
                ts_utc,
                c,
                rsi,
                td_sell_count,
                macd_line,
                macd_signal,
                (atr / NULLIF(c, 0)) AS atr_pct,
                vwap_dist_pct,
                bb_width
            FROM {LIVE_TABLE}
            WHERE
                timespan = '{TIMESPAN}'
                AND ts_utc::timestamptz >= now() - interval '{LOOKBACK_MINUTES} minutes'
                AND rsi >= {RSI_HIGH}
                AND td_sell_count >= {TD_SELL_MIN}
                AND macd_line < macd_signal
                AND vwap_dist_pct >= {VWAP_DIST_MIN}
                AND bb_width >= {BB_WIDTH_MIN}
            ORDER BY ts_utc::timestamptz DESC;
        """

        results = await db.fetch(query)
        if not results:
            await asyncio.sleep(POLL_SECONDS)
            continue

        rows = sorted(results, key=lambda r: r["ts_utc"])
        for r in rows:
            ts_utc = pd.Timestamp(r["ts_utc"])
            if ts_utc.tzinfo is None:
                ts_utc = ts_utc.tz_localize("UTC")
            ts_et = ts_utc.tz_convert("America/New_York")

            key = (r["ticker"], "secapi_bear_t1")
            last_ts = last_sent.get(key)
            if last_ts and ts_utc <= last_ts + timedelta(minutes=COOLDOWN_MINUTES):
                continue
            last_sent[key] = ts_utc

            desc = (
                f"{r['ticker']} @ {ts_et.strftime('%Y-%m-%d %H:%M ET')}\n"
                "Rule: RSI>=70, TD Sell>=8, MACD line<signal, BB width>=0.04, VWAP dist>=0.5%\n"
                "Context: overbought fade with wide bands and positive VWAP displacement.\n"
                f"Probability (>=20bp / >=50bp in {HOLD_MIN}-{HOLD_MAX}m): "
                f"{PROB_20BP:.1%} / {PROB_50BP:.1%}\n"
                f"Hold window: {HOLD_MIN}-{HOLD_MAX} minutes"
            )

            embed = DiscordEmbed(
                title="SECAPI Bear Feed",
                description=desc,
                color="e74c3c",
            )
            embed.add_embed_field(
                name="Now",
                value=(
                    f"c={float(r['c']):.2f} | rsi={float(r['rsi']):.1f} | "
                    f"td={int(r['td_sell_count'])} | bb_width={float(r['bb_width']):.4f} | "
                    f"vwap_dist={float(r['vwap_dist_pct']):.4f}"
                ),
                inline=False,
            )
            embed.set_timestamp()
            embed.set_footer(text="Market Pulse")

            hook = AsyncDiscordWebhook(HOOK_URL)
            hook.add_embed(embed)
            await hook.execute()

        await asyncio.sleep(POLL_SECONDS)


asyncio.run(main())
