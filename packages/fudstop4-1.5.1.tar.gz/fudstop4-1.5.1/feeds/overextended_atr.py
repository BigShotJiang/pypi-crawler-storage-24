import sys
from pathlib import Path
from datetime import datetime, time
import pytz
import aiohttp
import pandas as pd
import os
from more_itertools import chunked  # pip install more-itertools
project_dir = str(Path(__file__).resolve().parents[2])
if project_dir not in sys.path:
    sys.path.append(project_dir)
from datetime import timedelta

try:
    from .imps import *
except ImportError:
    from feeds.imps import *

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

HOOK_URL = resolve_webhook_url(
    "OVEREXTENDED_ATR_WEBHOOK",
    route_id="overextended_atr",
)
TIMESPAN = os.getenv("OVEREXTENDED_ATR_TIMESPAN", "m1")
LOOKBACK_MINUTES = int(os.getenv("OVEREXTENDED_ATR_LOOKBACK_MINUTES", "5"))
COOLDOWN_MINUTES = int(os.getenv("OVEREXTENDED_ATR_COOLDOWN_MINUTES", "10"))
POLL_SECONDS = float(os.getenv("OVEREXTENDED_ATR_POLL_SECONDS", "2"))
EXT_ATR_THRESHOLD = float(os.getenv("OVEREXTENDED_ATR_THRESHOLD", "2.0"))
TICKERS = list(most_active_tight_spread_tickers)
TICKERS_SQL = ", ".join(f"'{t}'" for t in TICKERS)
TICKER_FILTER = f"    AND ticker IN ({TICKERS_SQL})" if TICKERS_SQL else ""

overextended_query = f"""WITH x AS (
  SELECT
    ticker,
    timespan,
    ts_utc::timestamptz AS ts_utc,
    o, h, l, c,
    atr,
    LAG(c) OVER (PARTITION BY ticker, timespan ORDER BY ts_utc::timestamptz) AS prev_c
  FROM ca_live
  WHERE atr IS NOT NULL AND atr > 0
    AND timespan = '{TIMESPAN}'
    AND ts_utc::timestamptz >= now() - interval '{LOOKBACK_MINUTES} minutes'
{TICKER_FILTER}
),
last_bar AS (
  SELECT DISTINCT ON (ticker, timespan)
    *
  FROM x
  WHERE prev_c IS NOT NULL
  ORDER BY ticker, timespan, ts_utc DESC
)
SELECT
  ticker,
  timespan,
  ts_utc,
  c,
  atr,
  (h - prev_c) / atr AS ext_up_atr,
  (prev_c - l) / atr AS ext_dn_atr,
  GREATEST((h - prev_c) / atr, (prev_c - l) / atr) AS ext_max_atr
FROM last_bar
WHERE
  (h - prev_c) / atr >= {EXT_ATR_THRESHOLD}
  OR (prev_c - l) / atr >= {EXT_ATR_THRESHOLD}
ORDER BY ext_max_atr DESC;
"""


async def overextended_atr():
    await db.connect()
    last_sent = {}

    while True:
        results = await db.fetch(overextended_query)
        if not results:
            await asyncio.sleep(POLL_SECONDS)
            continue

        rows = sorted(results, key=lambda r: r["ts_utc"])
        for r in rows:
            ts_utc = pd.Timestamp(r["ts_utc"])
            if ts_utc.tzinfo is None:
                ts_utc = ts_utc.tz_localize("UTC")
            ts_et = ts_utc.tz_convert("America/New_York")

            ext_up = float(r["ext_up_atr"])
            ext_dn = float(r["ext_dn_atr"])

            if ext_up >= ext_dn:
                side = "bearish"
                color = red or "FF0000"
                label = "Overextended Up (mean reversion risk)"
            else:
                side = "bullish"
                color = green or "00FF00"
                label = "Overextended Down (mean reversion risk)"

            key = (r["ticker"], r["timespan"], side)
            last_ts = last_sent.get(key)
            if last_ts and ts_utc <= last_ts + timedelta(minutes=COOLDOWN_MINUTES):
                continue
            last_sent[key] = ts_utc

            embed = DiscordEmbed(
                title=f"Overextended ATR ({side})",
                description=f"{r['ticker']} {r['timespan']} @ {ts_et.strftime('%Y-%m-%d %H:%M ET')}",
                color=color,
            )
            embed.add_embed_field(
                name=label,
                value=(
                    f"Up move: **{ext_up:.2f} ATR**, Down move: **{ext_dn:.2f} ATR**\n"
                    f"Close: **{float(r['c']):.2f}**, ATR: **{float(r['atr']):.4f}**"
                ),
                inline=False,
            )
            embed.set_footer(text=f"Threshold >= {EXT_ATR_THRESHOLD:.2f} ATR")
            embed.set_timestamp()

            webhook = AsyncDiscordWebhook(url=HOOK_URL)
            webhook.add_embed(embed)
            await webhook.execute()

        await asyncio.sleep(POLL_SECONDS)



asyncio.run(overextended_atr())
