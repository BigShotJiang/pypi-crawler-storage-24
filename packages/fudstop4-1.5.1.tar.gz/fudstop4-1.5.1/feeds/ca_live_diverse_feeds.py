import ast
import asyncio
import os
import re
from dataclasses import dataclass
from datetime import time as dt_time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
from dotenv import load_dotenv
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

load_dotenv()

db = PolygonOptions()

BULL_QUICK_HOOK_URL = resolve_webhook_url("QUICK_BULL", route_id="ca_quick_bull")
BEAR_QUICK_HOOK_URL = resolve_webhook_url("QUICK_BEAR", route_id="ca_quick_bear")
SHORT_TERM_HOOK_URL = resolve_webhook_url("SHORT_TERM", route_id="ca_short_term")
MID_TERM_HOOK_URL = resolve_webhook_url("MID_TERM", route_id="ca_mid_term")
LONG_TERM_HOOK_URL = resolve_webhook_url("LONG_TERM", route_id="ca_long_term")
M_240_HOOK_URL = resolve_webhook_url("M_240_FEEDS", route_id="ca_240m")
QUICK_MIN_HIT = float(os.getenv("QUICK_MIN_HIT", "0.85"))
BULL_HOOK_URL = resolve_webhook_url(
    "CA_BULL_WEBHOOK",
    "SECAPI_BULL_WEBHOOK",
    "SHORT_TERM",
    route_id="ca_bull",
)
BEAR_HOOK_URL = resolve_webhook_url(
    "CA_BEAR_WEBHOOK",
    "SECAPI_BEAR_WEBHOOK",
    "MID_TERM",
    route_id="ca_bear",
)

QUICK_TIMESPANS = {"m1"}
SHORT_TIMESPANS = {"m5", "m15"}
MID_TIMESPANS = {"m30", "m60"}
LONG_TIMESPANS = {"m120", "d1", "w1"}
M_240_TIMESPANS = {"m240"}

LIVE_TABLE = os.getenv("CANDLE_LIVE_TABLE", "ca_live")
TIMESPAN = os.getenv("CA_TIMESPAN", os.getenv("CA_LIVE_TIMESPAN", "m1"))
LOOKBACK_MINUTES = int(os.getenv("CA_LOOKBACK_MINUTES", os.getenv("CA_LIVE_LOOKBACK_MINUTES", "5")))
POLL_SECONDS = float(os.getenv("CA_POLL_SECONDS", os.getenv("CA_LIVE_POLL_SECONDS", "5")))
DEFAULT_COOLDOWN = int(os.getenv("CA_COOLDOWN_MINUTES", os.getenv("CA_LIVE_COOLDOWN_MINUTES", "10")))
REQUIRE_LATEST = os.getenv("CA_LIVE_REQUIRE_LATEST", "1").strip().lower() in ("1", "true", "yes", "y", "on")
MAX_STALENESS_MINUTES = int(os.getenv("CA_LIVE_MAX_STALENESS_MINUTES", "3"))
MIN_RULE_HIT20 = float(os.getenv("CA_LIVE_MIN_HIT20", "0.9"))
MIN_RULE_N = int(os.getenv("CA_LIVE_MIN_N", "10"))
MIN_AVG_MOVE = float(os.getenv("CA_LIVE_MIN_AVG_MOVE", "0"))
MIN_P15_MOVE = float(os.getenv("CA_LIVE_MIN_P15_MOVE", "0"))
QUICK_MIN_AVG_MOVE = float(os.getenv("CA_LIVE_QUICK_MIN_AVG_MOVE", os.getenv("CA_UNIFIED_QUICK_MIN_AVG_MOVE", "0")))
QUICK_MIN_P15_MOVE = float(os.getenv("CA_LIVE_QUICK_MIN_P15_MOVE", os.getenv("CA_UNIFIED_QUICK_MIN_P15_MOVE", "0")))
INCLUDE_DIVERSE_RULES = os.getenv("CA_LIVE_INCLUDE_DIVERSE", "1").strip().lower() in ("1", "true", "yes", "y", "on")
IGNORE_TOD = os.getenv("CA_LIVE_IGNORE_TOD", "0").strip().lower() in ("1", "true", "yes", "y", "on")
RSI_OVERSOLD = float(os.getenv("CA_LIVE_RSI_OVERSOLD", "30"))
RSI_OVERBOUGHT = float(os.getenv("CA_LIVE_RSI_OVERBOUGHT", "70"))
TD_COUNT_MIN = int(os.getenv("CA_LIVE_TD_COUNT_MIN", "8"))

CANDIDATES_CSV_RAW = os.getenv("CA_LIVE_CANDIDATES_CSV", os.getenv("CA_UNIFIED_CANDIDATES_CSV", "")).strip()
CANDIDATES_CSV = Path(CANDIDATES_CSV_RAW) if CANDIDATES_CSV_RAW else None
CANDIDATES_CSVS_RAW = os.getenv("CA_LIVE_CANDIDATES_CSVS", os.getenv("CA_UNIFIED_CANDIDATES_CSVS", "")).strip()
CANDIDATES_DIR_RAW = os.getenv("CA_LIVE_CANDIDATES_DIR", os.getenv("CA_UNIFIED_CANDIDATES_DIR", "")).strip()
CANDIDATES_DIR = Path(CANDIDATES_DIR_RAW) if CANDIDATES_DIR_RAW else None
OPEN_ONLY_RULES = os.getenv("CA_OPEN_ONLY_RULES", "0").strip().lower() in ("1", "true", "yes", "y", "on")
OPEN_ONLY_CLAUSE = " AND time_et >= '09:30' AND time_et < '10:30'" if OPEN_ONLY_RULES else ""
OPEN_ONLY_REQ = {"time_et"} if OPEN_ONLY_RULES else set()
OPEN_ONLY_DESC = ", 09:30-10:30 ET" if OPEN_ONLY_RULES else ""


def _format_value(value: object) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, bool):
        return "true" if value else "false"
    try:
        fval = float(value)
    except Exception:
        return str(value)
    abs_val = abs(fval)
    if abs_val >= 1000:
        return f"{fval:.0f}"
    if abs_val >= 100:
        return f"{fval:.1f}"
    if abs_val >= 10:
        return f"{fval:.2f}"
    if abs_val >= 1:
        return f"{fval:.3f}"
    return f"{fval:.4f}"


def _format_metrics(row: dict, fields: list[str]) -> str:
    parts = []
    for field in fields:
        parts.append(f"{field}={_format_value(row.get(field))}")
    return " | ".join(parts)


def _format_stats(rule: "LiveRule") -> str:
    hit = rule.hit_20bp
    hold = rule.hold
    if hit is None and not hold:
        return ""
    parts = []
    if hit is not None:
        parts.append(f"Hit 20bp: {hit:.1%}")
    if hold:
        parts.append(f"Hold: {hold}")
    return " | ".join(parts)


_TOD_COLUMNS = {"tod_open", "tod_mid", "tod_close"}
_ALLOWED_NODES = (
    ast.Expression,
    ast.BoolOp,
    ast.UnaryOp,
    ast.BinOp,
    ast.Compare,
    ast.Name,
    ast.Load,
    ast.Constant,
    ast.Tuple,
    ast.List,
    ast.And,
    ast.Or,
    ast.Not,
    ast.USub,
    ast.UAdd,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.Mod,
    ast.Pow,
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.In,
    ast.NotIn,
)


@dataclass(frozen=True)
class CompiledCondition:
    raw: str
    expr: str
    code: Any
    names: Tuple[str, ...]


@dataclass(frozen=True)
class LiveRule:
    name: str
    side: str
    conditions: Tuple[CompiledCondition, ...]
    raw_conditions: Tuple[str, ...]
    fields: Tuple[str, ...]
    description: str
    hit_20bp: Optional[float] = None
    hold: Optional[str] = None
    cooldown: Optional[int] = None
    timespan: str = ""


def _normalize_expr(expr: str) -> str:
    s = expr.strip()
    s = re.sub(r"\bAND\b", "and", s, flags=re.IGNORECASE)
    s = re.sub(r"\bOR\b", "or", s, flags=re.IGNORECASE)
    s = re.sub(r"\bNOT\b", "not", s, flags=re.IGNORECASE)
    s = re.sub(r"\bTRUE\b", "True", s, flags=re.IGNORECASE)
    s = re.sub(r"\bFALSE\b", "False", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIS\s+TRUE\b", "== True", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIS\s+FALSE\b", "== False", s, flags=re.IGNORECASE)
    s = re.sub(r"\bNOT\s+IN\b", "not in", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIN\b", "in", s, flags=re.IGNORECASE)
    s = s.replace("<>", "!=")
    s = re.sub(r"(?<![<>=!])=(?!=)", "==", s)
    return s


def _validate_ast(tree: ast.AST) -> None:
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise ValueError(f"Disallowed expression node: {type(node).__name__}")
        if isinstance(node, ast.Name) and node.id.startswith("__"):
            raise ValueError("Disallowed name")


def compile_condition(raw: str) -> CompiledCondition:
    expr = _normalize_expr(raw)
    tree = ast.parse(expr, mode="eval")
    _validate_ast(tree)
    names = [node.id for node in ast.walk(tree) if isinstance(node, ast.Name)]
    code = compile(tree, "<condition>", "eval")
    return CompiledCondition(raw=raw, expr=expr, code=code, names=tuple(sorted(set(names))))


def eval_condition(cond: CompiledCondition, row: Dict[str, Any]) -> bool:
    locals_d: Dict[str, Any] = {}
    for name in cond.names:
        if name not in row:
            return False
        locals_d[name] = row[name]
    try:
        return bool(eval(cond.code, {"__builtins__": {}}, locals_d))
    except Exception:
        return False


def _parse_conditions(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw if str(x).strip()]
    try:
        parsed = ast.literal_eval(str(raw))
    except Exception:
        return []
    if isinstance(parsed, list):
        return [str(x) for x in parsed if str(x).strip()]
    return []


def _strip_tod_conditions(conds: Iterable[str]) -> List[str]:
    out: List[str] = []
    for cond in conds:
        lowered = cond.lower()
        if "tod_open" in lowered or "tod_mid" in lowered or "tod_close" in lowered or "time_et" in lowered:
            continue
        out.append(cond)
    return out


def _strip_tod_expr(expr: str) -> str:
    parts = re.split(r"\bAND\b", expr, flags=re.IGNORECASE)
    kept = []
    for part in parts:
        lowered = part.lower()
        if "tod_open" in lowered or "tod_mid" in lowered or "tod_close" in lowered or "time_et" in lowered:
            continue
        kept.append(part.strip())
    return " AND ".join([p for p in kept if p])


def _infer_timespan_from_text(text: str) -> Optional[str]:
    if not text:
        return None
    match = re.search(r"([smhd]\d+)", text.lower())
    if not match:
        return None
    return match.group(1)


def _base_conditions(side: str) -> List[str]:
    if side == "bull":
        return [
            f"rsi <= {RSI_OVERSOLD:g}",
            f"td_buy_count >= {TD_COUNT_MIN}",
        ]
    return [
        f"rsi >= {RSI_OVERBOUGHT:g}",
        f"td_sell_count >= {TD_COUNT_MIN}",
    ]


def _safe_int(value: Any) -> int:
    try:
        return int(float(str(value)))
    except Exception:
        return 0


def _timespan_to_minutes(timespan: str) -> float:
    ts = (timespan or "").strip().lower()
    if not ts:
        return 0.0
    match = re.match(r"^([a-z]+)(\d+)$", ts)
    if match:
        unit = match.group(1)
        qty = int(match.group(2))
    else:
        match = re.match(r"^(\d+)([a-z]+)$", ts)
        if not match:
            return 0.0
        qty = int(match.group(1))
        unit = match.group(2)
    minutes_per_unit = {
        "s": 1.0 / 60.0,
        "sec": 1.0 / 60.0,
        "secs": 1.0 / 60.0,
        "second": 1.0 / 60.0,
        "seconds": 1.0 / 60.0,
        "m": 1.0,
        "min": 1.0,
        "mins": 1.0,
        "minute": 1.0,
        "minutes": 1.0,
        "h": 60.0,
        "hr": 60.0,
        "hrs": 60.0,
        "hour": 60.0,
        "hours": 60.0,
        "d": 1440.0,
        "day": 1440.0,
        "days": 1440.0,
    }
    if unit not in minutes_per_unit:
        return 0.0
    return float(qty) * minutes_per_unit[unit]


def _format_hold_window(window_min: int, window_max: int, timespan: str) -> Optional[str]:
    if window_min <= 0 or window_max <= 0 or window_max < window_min:
        return None
    minutes_per_bar = _timespan_to_minutes(timespan)
    if minutes_per_bar <= 0:
        return None
    hold_min = int(round(window_min * minutes_per_bar))
    hold_max = int(round(window_max * minutes_per_bar))
    return f"{hold_min}-{hold_max}m"


def _candidate_paths() -> List[Path]:
    paths: List[Path] = []
    if CANDIDATES_CSVS_RAW:
        for raw in CANDIDATES_CSVS_RAW.split(","):
            p = raw.strip()
            if p:
                paths.append(Path(p))
    elif CANDIDATES_DIR and CANDIDATES_DIR.exists():
        paths.extend(sorted(CANDIDATES_DIR.glob("*.csv")))
    elif CANDIDATES_CSV:
        paths.append(CANDIDATES_CSV)
    return paths


def _normalize_epoch(value: int) -> int:
    if value > 1_000_000_000_000:
        return int(value / 1000)
    return value


def _row_ts_epoch(row: Dict[str, Any]) -> Optional[int]:
    raw = row.get("ts_epoch") or row.get("ts")
    if raw is None:
        return None
    try:
        ts = int(float(str(raw)))
    except Exception:
        return None
    return _normalize_epoch(ts)


def _row_ts_utc(row: Dict[str, Any]) -> Optional[pd.Timestamp]:
    ts_epoch = _row_ts_epoch(row)
    if not ts_epoch:
        return None
    return pd.to_datetime(ts_epoch, unit="s", utc=True)


def _apply_tod_flags(row: Dict[str, Any]) -> None:
    ts_utc = _row_ts_utc(row)
    if ts_utc is None:
        return
    ts_et = ts_utc.tz_convert("America/New_York")
    tod = ts_et.time()
    row["tod_open"] = (tod >= dt_time(9, 30)) and (tod < dt_time(10, 30))
    row["tod_mid"] = (tod >= dt_time(10, 30)) and (tod < dt_time(15, 0))
    row["tod_close"] = (tod >= dt_time(15, 0)) and (tod < dt_time(16, 0))


def _rule_missing_columns(rule: LiveRule, columns: set[str]) -> List[str]:
    required = {name.lower() for cond in rule.conditions for name in cond.names}
    required.update({c.lower() for c in rule.fields})
    required -= _TOD_COLUMNS
    return sorted({c for c in required if c not in columns})


def _rule_hit(rule: LiveRule, row: Dict[str, Any]) -> bool:
    return all(eval_condition(cond, row) for cond in rule.conditions)


def _load_candidate_rules(candidate_paths: Iterable[Path]) -> List[LiveRule]:
    rules: List[LiveRule] = []
    for path in candidate_paths:
        if not path.exists():
            continue
        if path.stat().st_size == 0:
            print(f"[WARN] candidates CSV is empty: {path}")
            continue
        try:
            df = pd.read_csv(path)
        except pd.errors.EmptyDataError:
            print(f"[WARN] candidates CSV has no columns: {path}")
            continue
        except Exception as exc:
            print(f"[WARN] failed to read candidates CSV {path}: {exc}")
            continue
        if df.empty:
            continue
        required_cols = {"hit_20bp", "n_val", "conditions", "side"}
        missing_cols = required_cols - set(df.columns)
        if missing_cols:
            print(f"[WARN] candidates CSV missing columns {sorted(missing_cols)}: {path}")
            continue

        df = df[df["hit_20bp"] >= MIN_RULE_HIT20]
        df = df[df["n_val"] >= MIN_RULE_N]
        if df.empty:
            continue

        inferred_ts = _infer_timespan_from_text(path.stem)
        for idx, row in df.iterrows():
            side = str(row.get("side", "")).strip().lower()
            if side not in ("bull", "bear"):
                continue
            conds = _parse_conditions(row.get("conditions"))
            if IGNORE_TOD:
                conds = _strip_tod_conditions(conds)
            if not conds:
                continue

            row_ts = str(row.get("timespan", "")).strip().lower()
            timespan = (row_ts or inferred_ts or TIMESPAN).lower()
            if timespan != TIMESPAN:
                continue

            base_mode = str(row.get("base_mode", "")).strip().lower() or "rsi_td_only"
            base = [] if base_mode == "none" else _base_conditions(side)
            raw_conditions = base + conds
            try:
                compiled = tuple(compile_condition(c) for c in raw_conditions)
            except Exception:
                continue

            names = {name for cond in compiled for name in cond.names}
            fields = ["c"] + [n for n in sorted(names) if n != "c"]

            avg_move = float(row.get("avg_best_move", 0.0) or 0.0)
            p15_move = float(row.get("p15_best_move", 0.0) or 0.0)
            if timespan in QUICK_TIMESPANS:
                if QUICK_MIN_AVG_MOVE > 0 and avg_move < QUICK_MIN_AVG_MOVE:
                    continue
                if QUICK_MIN_P15_MOVE > 0 and p15_move < QUICK_MIN_P15_MOVE:
                    continue
            else:
                if MIN_AVG_MOVE > 0 and avg_move < MIN_AVG_MOVE:
                    continue
                if MIN_P15_MOVE > 0 and p15_move < MIN_P15_MOVE:
                    continue

            label = str(row.get("label", "")).strip() or f"candidate_{idx}"
            name = f"cand_{side}_{timespan}_{label}"

            window_min = _safe_int(row.get("window_min"))
            window_max = _safe_int(row.get("window_max"))
            hold = _format_hold_window(window_min, window_max, timespan)

            rules.append(
                LiveRule(
                    name=name,
                    side=side,
                    timespan=timespan,
                    conditions=compiled,
                    raw_conditions=tuple(raw_conditions),
                    fields=tuple(fields),
                    description="Candidate rule (auto-mined)",
                    hit_20bp=float(row.get("hit_20bp", 0.0)),
                    hold=hold,
                )
            )
    return rules


def _load_diverse_rules() -> List[LiveRule]:
    rules: List[LiveRule] = []
    for rule in RULES:
        hit = rule.get("hit_20bp")
        if hit is not None and hit < MIN_RULE_HIT20:
            continue
        where = rule["where"]
        if IGNORE_TOD:
            where = _strip_tod_expr(where)
        if not where.strip():
            continue
        try:
            compiled = (compile_condition(where),)
        except Exception:
            continue
        rules.append(
            LiveRule(
                name=rule["name"],
                side=rule["side"],
                timespan=TIMESPAN,
                conditions=compiled,
                raw_conditions=(where,),
                fields=tuple(rule.get("fields", [])),
                description=rule.get("desc", rule["name"]),
                hit_20bp=rule.get("hit_20bp"),
                hold=rule.get("hold"),
                cooldown=rule.get("cooldown"),
            )
        )
    return rules


def _build_fetch_sql() -> str:
    sql = f"SELECT * FROM {LIVE_TABLE} WHERE timespan = '{TIMESPAN}'"
    if LOOKBACK_MINUTES > 0:
        sql += f" AND ts >= EXTRACT(EPOCH FROM (now() - interval '{LOOKBACK_MINUTES} minutes'))"
    return sql


def _fallback_hook(side: str) -> str:
    return BULL_HOOK_URL if side == "bull" else BEAR_HOOK_URL


def _select_hook(rule: LiveRule) -> str:
    timespan = (rule.timespan or TIMESPAN or "").strip().lower()
    hit = rule.hit_20bp
    if timespan in M_240_TIMESPANS and M_240_HOOK_URL:
        return M_240_HOOK_URL
    if timespan in QUICK_TIMESPANS:
        if hit is not None and hit >= QUICK_MIN_HIT:
            return (BULL_QUICK_HOOK_URL if rule.side == "bull" else BEAR_QUICK_HOOK_URL) or _fallback_hook(rule.side)
        return SHORT_TERM_HOOK_URL or _fallback_hook(rule.side)
    if timespan in SHORT_TIMESPANS:
        return SHORT_TERM_HOOK_URL or _fallback_hook(rule.side)
    if timespan in MID_TIMESPANS:
        return MID_TERM_HOOK_URL or _fallback_hook(rule.side)
    if timespan in LONG_TIMESPANS:
        return LONG_TERM_HOOK_URL or _fallback_hook(rule.side)
    return _fallback_hook(rule.side)


BASE_BULL = "rsi <= 30 AND td_buy_count >= 10 AND candle_completely_below_lower = true"
BASE_BEAR = "rsi >= 70 AND td_sell_count >= 10 AND candle_completely_above_upper = true"
BASE_BEAR_TD13 = "rsi >= 70 AND td_sell_count >= 13 AND candle_completely_above_upper = true"
BASE_BULL_TD8 = "rsi <= 30 AND td_buy_count >= 8"
BASE_BEAR_TD8 = "rsi >= 70 AND td_sell_count >= 8"

REQ_BASE_BULL = {"rsi", "td_buy_count", "candle_completely_below_lower"}
REQ_BASE_BEAR = {"rsi", "td_sell_count", "candle_completely_above_upper"}
REQ_BASE_BEAR_TD13 = {"rsi", "td_sell_count", "candle_completely_above_upper"}
REQ_BASE_BULL_TD8 = {"rsi", "td_buy_count"}
REQ_BASE_BEAR_TD8 = {"rsi", "td_sell_count"}

RULES = [
    {
        "name": "Top Bullish 90%+",
        "side": "bull",
        "where": f"{BASE_BULL} AND bb_width >= 0.03 AND rvol >= 1.5 AND stoch_rsi_k <= 10",
        "fields": ["c", "rsi", "td_buy_count", "bb_width", "rvol", "stoch_rsi_k"],
        "requires": REQ_BASE_BULL | {"bb_width", "rvol", "stoch_rsi_k"},
        "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, BB width>=0.03, rvol>=1.5, Stoch RSI<=10",
        "hit_20bp": 0.96,
        "hold": "1-15m",
    },
    {
        "name": "TD9 BBands + RVOL",
        "side": "bull",
        "where": f"{BASE_BULL} AND bb_width >= 0.03 AND rvol >= 1.5",
        "fields": ["c", "rsi", "td_buy_count", "bb_width", "rvol"],
        "requires": REQ_BASE_BULL | {"bb_width", "rvol"},
        "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, BB width>=0.03, rvol>=1.5",
        "hit_20bp": 0.9,
        "hold": "1-10m",
    },
    {
        "name": "BB Vol Confirm",
        "side": "bull",
        "where": f"{BASE_BULL} AND bb_width >= 0.03 AND volume_confirm = true AND vwap_dist_pct >= 0.0",
        "fields": ["c", "rsi", "td_buy_count", "bb_width", "volume_confirm", "vwap_dist_pct"],
        "requires": REQ_BASE_BULL | {"bb_width", "volume_confirm", "vwap_dist_pct"},
        "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, BB width>=0.03, volume confirm, VWAP dist>=0.0",
        "hit_20bp": 0.9375,
        "hold": "1-15m",
    },
    {
        "name": "BB Vol Confirm + Stoch RSI",
        "side": "bull",
        "where": (
            f"{BASE_BULL} AND bb_width >= 0.03 AND volume_confirm = true "
            "AND vwap_dist_pct >= 0.0 AND stoch_rsi_k <= 20"
        ),
        "fields": ["c", "rsi", "td_buy_count", "bb_width", "volume_confirm", "stoch_rsi_k", "vwap_dist_pct"],
        "requires": REQ_BASE_BULL | {"bb_width", "volume_confirm", "stoch_rsi_k", "vwap_dist_pct"},
        "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, BB width>=0.03, volume confirm, VWAP dist>=0.0, Stoch RSI<=20",
        "hit_20bp": 0.934783,
        "hold": "1-15m",
    },
    {
        "name": "ATR + RVOL",
        "side": "bull",
        "where": f"{BASE_BULL} AND atr_pct >= 0.003 AND rvol >= 1.5 AND vwap_dist_pct >= 0.0",
        "fields": ["c", "rsi", "td_buy_count", "atr_pct", "rvol", "vwap_dist_pct"],
        "requires": REQ_BASE_BULL | {"atr_pct", "rvol", "vwap_dist_pct"},
        "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, ATR%>=0.003, rvol>=1.5, VWAP dist>=0.0",
        "hit_20bp": 0.930233,
        "hold": "1-15m",
    },
    {
        "name": f"ATR + Vol Confirm{' (Open)' if OPEN_ONLY_RULES else ''}",
        "side": "bull",
        "where": (
            f"{BASE_BULL} AND atr_pct >= 0.003 AND volume_confirm = true AND vwap_dist_pct >= 0.0"
            f"{OPEN_ONLY_CLAUSE}"
        ),
        "fields": ["c", "rsi", "td_buy_count", "atr_pct", "volume_confirm", "vwap_dist_pct"],
        "requires": REQ_BASE_BULL | {"atr_pct", "volume_confirm", "vwap_dist_pct"} | OPEN_ONLY_REQ,
        "desc": f"RSI<=30, TD Buy>=10, candle fully below BB lower, ATR%>=0.003, volume confirm, VWAP dist>=0.0{OPEN_ONLY_DESC}",
        "hit_20bp": 0.909091,
        "hold": "1-15m",
    },
    {
        "name": "BB Width + VWAP Dist (TD8)",
        "side": "bull",
        "where": f"{BASE_BULL_TD8} AND bb_width >= 0.04 AND vwap_dist_pct <= -0.02",
        "fields": ["c", "rsi", "td_buy_count", "bb_width", "vwap_dist_pct"],
        "requires": REQ_BASE_BULL_TD8 | {"bb_width", "vwap_dist_pct"},
        "desc": "RSI<=30, TD Buy>=8, BB width>=0.04, VWAP dist<=-0.02",
        "hit_20bp": 0.853659,
        "hold": "5-10m",
    },
    {
        "name": "BB Width + Candle Green",
        "side": "bear",
        "where": f"{BASE_BEAR} AND bb_width >= 0.05 AND candle_green = true",
        "fields": ["c", "rsi", "td_sell_count", "bb_width", "candle_green"],
        "requires": REQ_BASE_BEAR | {"bb_width", "candle_green"},
        "desc": "RSI>=70, TD Sell>=10, candle fully above BB upper, BB width>=0.05, green candle",
        "hit_20bp": 0.906976,
        "hold": "1-20m",
    },
    {
        "name": "BB Width + MFI 90 (TD8)",
        "side": "bear",
        "where": f"{BASE_BEAR_TD8} AND bb_width >= 0.04 AND mfi >= 90",
        "fields": ["c", "rsi", "td_sell_count", "bb_width", "mfi"],
        "requires": REQ_BASE_BEAR_TD8 | {"bb_width", "mfi"},
        "desc": "RSI>=70, TD Sell>=8, BB width>=0.04, MFI>=90",
        "hit_20bp": 0.87037,
        "hold": "5-10m",
    },
    {
        "name": "ATR + MFI TD13",
        "side": "bear",
        "where": f"{BASE_BEAR_TD13} AND atr_pct >= 0.003 AND mfi >= 80 AND vwap_dist_pct <= 0.0",
        "fields": ["c", "rsi", "td_sell_count", "atr_pct", "mfi", "vwap_dist_pct"],
        "requires": REQ_BASE_BEAR_TD13 | {"atr_pct", "mfi", "vwap_dist_pct"},
        "desc": "RSI>=70, TD Sell>=13, candle fully above BB upper, ATR%>=0.003, MFI>=80, VWAP dist<=0.0",
        "hit_20bp": 0.928571,
        "hold": "1-20m",
    },
]



async def main() -> None:
    await db.connect()
    columns = {c.lower() for c in (await db.get_table_columns(LIVE_TABLE))}
    if not columns:
        raise RuntimeError(f"{LIVE_TABLE} returned no columns")

    rules: List[LiveRule] = []
    if INCLUDE_DIVERSE_RULES:
        rules.extend(_load_diverse_rules())
    rules.extend(_load_candidate_rules(_candidate_paths()))
    if not rules:
        raise SystemExit("no rules loaded (check candidates CSV / filters)")

    filtered: List[LiveRule] = []
    dropped: List[str] = []
    for rule in rules:
        missing = _rule_missing_columns(rule, columns)
        if missing:
            dropped.append(f"{rule.side}:{rule.name} -> {missing}")
            continue
        filtered.append(rule)
    if dropped:
        preview = "\n".join(dropped[:10])
        print(f"[WARN] dropped {len(dropped)} rules due to missing columns (showing 10):\n{preview}")
    rules = filtered
    if not rules:
        raise SystemExit("no rules remaining after column validation")

    fetch_sql = _build_fetch_sql()
    last_sent: Dict[Tuple[str, str], int] = {}

    while True:
        results = await db.fetch(fetch_sql)
        if not results:
            await asyncio.sleep(POLL_SECONDS)
            continue

        now_epoch = int(pd.Timestamp.now(tz="UTC").timestamp())
        for raw in results:
            row = {str(k).lower(): v for k, v in dict(raw).items()}
            if not IGNORE_TOD:
                _apply_tod_flags(row)

            ts_epoch = _row_ts_epoch(row)
            if not ts_epoch:
                continue
            if MAX_STALENESS_MINUTES > 0 and now_epoch - ts_epoch > MAX_STALENESS_MINUTES * 60:
                continue

            ts_utc = _row_ts_utc(row)
            if ts_utc is None:
                continue
            ts_et = ts_utc.tz_convert("America/New_York")

            for rule in rules:
                if not _rule_hit(rule, row):
                    continue

                key = (str(row.get("ticker", "")), f"{rule.side}:{rule.name}")
                last_ts = last_sent.get(key)
                cooldown = rule.cooldown or DEFAULT_COOLDOWN
                if last_ts and ts_epoch <= last_ts + int(cooldown * 60):
                    continue
                last_sent[key] = ts_epoch

                metrics = _format_metrics(row, list(rule.fields))
                stats = _format_stats(rule)
                title = f"CA {rule.side.title()}: {rule.name}"
                color = "2ecc71" if rule.side == "bull" else "e74c3c"

                embed = DiscordEmbed(
                    title=title,
                    description=f"{row.get('ticker')} @ {ts_et.strftime('%Y-%m-%d %H:%M ET')}",
                    color=color,
                )
                embed.add_embed_field(name="Setup", value=rule.description, inline=False)
                if stats:
                    embed.add_embed_field(name="Stats", value=stats, inline=False)
                embed.add_embed_field(name="Now", value=metrics, inline=False)
                embed.set_footer(text="CA 90%+ feed")
                embed.set_timestamp()

                hook_url = _select_hook(rule)
                hook = AsyncDiscordWebhook(hook_url)
                hook.add_embed(embed)
                await hook.execute()

        await asyncio.sleep(POLL_SECONDS)


asyncio.run(main())
