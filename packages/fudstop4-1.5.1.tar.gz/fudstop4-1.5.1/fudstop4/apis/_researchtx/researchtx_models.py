import pandas as pd


class ResearchTxCaseEvents:
    def __init__(self, data):
        rows = [
            {
                "filing_id": (event.get("filingID") or event.get("filingId") or ""),
                "filing_code": (event.get("filingCode") or ""),
                "filing_code_description": (event.get("filingCodeDescription") or ""),
                "description": (event.get("description") or ""),
                "submitted": (event.get("submitted") or ""),
                "docketed": (event.get("docketed") or ""),
                "submitter_full_name": (event.get("submitterFullName") or ""),
                "event_type": (event.get("eventType") or ""),
                "jurisdiction": (event.get("jurisdiction") or ""),
                "jurisdiction_key": (event.get("jurisdictionKey") or ""),
                "external_key": (event.get("externalKey") or ""),
                "is_hidden_from_public": bool(event.get("isHiddenFromPublic")),
                "has_manual_security_override": bool(event.get("hasManualSecurityOverride")),
                "has_hidden_document": bool(event.get("hasHiddenDocument")),
                "has_no_document": bool(event.get("hasNoDocument")),
                "has_no_reported_documents": bool(event.get("hasNoReportedDocuments")),
                "document_index_number": (event.get("documentIndexNumber") or ""),
                "timestamp_create": (event.get("timestampCreate") or ""),
                "doc_description": (doc or {}).get("description") or "",
                "doc_category_code": (doc or {}).get("documentCategoryCode") or "",
                "doc_filing_code": (doc or {}).get("filingCode") or "",
                "doc_page_count": (doc or {}).get("pageCount"),
                "doc_text_content": (doc or {}).get("textContent") or "",
            }
            for event in (data or [])
            for doc in ((event.get("documents") or []) or [None])
        ]

        self.filing_id = [i.get("filing_id", "") for i in rows]
        self.filing_code = [i.get("filing_code", "") for i in rows]
        self.filing_code_description = [i.get("filing_code_description", "") for i in rows]
        self.description = [i.get("description", "") for i in rows]
        self.submitted = [i.get("submitted", "") for i in rows]
        self.docketed = [i.get("docketed", "") for i in rows]
        self.submitter_full_name = [i.get("submitter_full_name", "") for i in rows]
        self.event_type = [i.get("event_type", "") for i in rows]
        self.jurisdiction = [i.get("jurisdiction", "") for i in rows]
        self.jurisdiction_key = [i.get("jurisdiction_key", "") for i in rows]
        self.external_key = [i.get("external_key", "") for i in rows]
        self.is_hidden_from_public = [bool(i.get("is_hidden_from_public")) for i in rows]
        self.has_manual_security_override = [bool(i.get("has_manual_security_override")) for i in rows]
        self.has_hidden_document = [bool(i.get("has_hidden_document")) for i in rows]
        self.has_no_document = [bool(i.get("has_no_document")) for i in rows]
        self.has_no_reported_documents = [bool(i.get("has_no_reported_documents")) for i in rows]
        self.document_index_number = [
            float(str(v).strip())
            if (v := i.get("document_index_number")) not in (None, "--", "", "—")
            else 0.0
            for i in rows
        ]

        self.timestamp_create = [i.get("timestamp_create", "") for i in rows]
        self.doc_description = [i.get("doc_description", "") for i in rows]
        self.doc_category_code = [i.get("doc_category_code", "") for i in rows]
        self.doc_filing_code = [i.get("doc_filing_code", "") for i in rows]
        self.doc_page_count = [
            float(str(v).strip())
            if (v := i.get("doc_page_count")) not in (None, "--", "", "—")
            else 0.0
            for i in rows
        ]
        self.doc_text_content = [
            (t.replace("\n", " ") if isinstance(t, str) else "")
            for t in [i.get("doc_text_content", "") for i in rows]
        ]

        self.data_dict = {
            "filing_id": self.filing_id,
            "filing_code": self.filing_code,
            "filing_code_description": self.filing_code_description,
            "description": self.description,
            "submitted": self.submitted,
            "docketed": self.docketed,
            "submitter_full_name": self.submitter_full_name,
            "event_type": self.event_type,
            "jurisdiction": self.jurisdiction,
            "jurisdiction_key": self.jurisdiction_key,
            "external_key": self.external_key,
            "is_hidden_from_public": self.is_hidden_from_public,
            "has_manual_security_override": self.has_manual_security_override,
            "has_hidden_document": self.has_hidden_document,
            "has_no_document": self.has_no_document,
            "has_no_reported_documents": self.has_no_reported_documents,
            "document_index_number": self.document_index_number,
            "timestamp_create": self.timestamp_create,
            "doc_description": self.doc_description,
            "doc_category_code": self.doc_category_code,
            "doc_filing_code": self.doc_filing_code,
            "doc_page_count": self.doc_page_count,
            "doc_text_content": self.doc_text_content,
        }

        self.as_dataframe = pd.DataFrame(self.data_dict)
