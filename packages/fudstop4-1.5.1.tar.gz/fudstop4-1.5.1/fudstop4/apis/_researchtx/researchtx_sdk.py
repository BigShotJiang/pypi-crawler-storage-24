import os
import pandas as pd
from dotenv import load_dotenv
import aiohttp
import asyncio
import random
load_dotenv()
import requests
case_id = os.environ.get('divorce_case_id')
from typing import List, Dict, Any
from fudstop4.apis._researchtx.researchtx_models import ResearchTxCaseEvents

class ResearchTexasSDK:
    def __init__(self, cookie):
        self.cookie=cookie
        self.headers = {'cookie': self.cookie, 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'}


    async def get_filings(self, id: str, page_size: int = 25, search_text: str = '', index=0):
        """Get case filings"""
        url = f"https://research.txcourts.gov/CourtRecordsSearch/case/{id}/events"
        
        r = requests.post(url=url, data={"pageSize": page_size, "pageIndex": index, "sortNewestToOldest": False, 
                                         "searchText": search_text, "isSearchAll": True, "eventType": 0}, 
                                         headers=self.headers)
        
        if r.status_code == 200:
            r = r.json()
            events = r.get('events', [])

            # Extracting data from the events
            filing_code = [i.get('filingCode') for i in events]
            filing_date = [i.get('submitted') for i in events]
            file_size = [i.get('fileSize') for i in events]
            description = [i.get('description') for i in events]
            submitted = [i.get('submitted') for i in events]
            submitter_full_name = [i.get('submitterFullName') for i in events]
            docketed = [i.get('docketed') for i in events]
            filing_id = [i.get('filingId') for i in events]

            # Creating a dictionary
            data_dict = {
                'filing_id': filing_id,
                'filing_code': filing_code,
                'file_size': file_size,
                'description': description,
                'submitted': submitted,
                'submitter_full_name': submitter_full_name,
                'filing_date': filing_date,
                'docketed': docketed,
            }




    async def get_events(self, pageindex: int = 0, case_number: str = '5704137c9160452d95922451c693e3ca', page_size: int = 20):
        """Get case events"""
        url = f"https://research.txcourts.gov/CourtRecordsSearch/case/{case_number}/events"
        events: List[Dict[str, Any]] = []
        page_index = int(pageindex or 0)

        while True:
            payload = {
                "pageSize": int(page_size),
                "pageIndex": page_index,
                "sortNewestToOldest": True,
                "searchText": None,
                "isSearchAll": True,
                "eventType": 0,
            }

            r = requests.post(url, headers=self.headers, json=payload)
            if r.status_code != 200:
                break

            data = r.json()
            batch = data.get("events", []) or []
            if not batch:
                break

            events.extend(batch)
            if len(batch) < int(page_size):
                break
            page_index += 1

        model = ResearchTxCaseEvents(events)
        return model.as_dataframe
    async def get_attorney(self, query_value: str = "24110698", page_size: int = 50) -> pd.DataFrame:
        """
        Paginate ResearchTexas case search until no more hits.
        Robust to transient 500s: retries + saves partial progress on failure.

        Output files:
        - <safe_name>.partial.csv (checkpoint written periodically and on failure)
        - <safe_name>.csv         (final on clean completion)
        """
        import aiohttp
        import asyncio
        import random
        import pandas as pd
        from typing import Any, Dict, List

        url = "https://research.txcourts.gov/CourtRecordsSearch/search?timeZoneOffsetInMinutes=-360"

        def safe_filename(s: str) -> str:
            return "".join(c if c.isalnum() or c in ("-", "_", ".", " ") else "_" for c in s).strip()[:180] or "query"

        base_name = safe_filename(query_value)
        partial_path = f"{base_name}.partial.csv"
        final_path = f"{base_name}.csv"

        def make_payload(page_index: int) -> Dict[str, Any]:
            return {
                "queryString": None,
                "pageSize": page_size,
                "pageIndex": page_index,
                "advancedSearchConditions": {
                    "advancedSearchConditions": [
                        {
                            "conditionOperation": 0,
                            "fieldOption": 17,
                            "value": f"{query_value}",
                            "fromValue": None,
                            "toValue": None,
                            "firstName": None,
                            "lastName": None,
                            "valueSet": [],
                        }
                    ]
                },
                "SearchIndexType": "Cases",
                "sortFieldOrder": "desc",
                "sortFields": "0",
            }

        def summarize_attorneys(att_list):
            att_list = att_list or []
            names, bars, firms = [], [], []

            for a in att_list:
                if not isinstance(a, dict):
                    continue
                if a.get("name"):
                    names.append(a.get("name"))
                if a.get("barNumber"):
                    bars.append(a.get("barNumber"))
                if a.get("firmName"):
                    firms.append(a.get("firmName"))

            return {
                "attorneyNames": "; ".join(dict.fromkeys(names)) or None,
                "attorneyBarNumbers": "; ".join(dict.fromkeys(bars)) or None,
                "attorneyFirmNames": "; ".join(dict.fromkeys(firms)) or None,
            }

        rows: List[Dict[str, Any]] = []
        page_index = 0

        checkpoint_every_pages = 7
        max_retries = 6
        base_backoff_sec = 0.75
        max_backoff_sec = 15.0

        def checkpoint():
            if not rows:
                return
            df_ckpt = pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)
            df_ckpt.to_csv(partial_path, index=False)

        async def post_with_retries(session: aiohttp.ClientSession, payload: Dict[str, Any]) -> Dict[str, Any]:
            last_exc = None
            for attempt in range(max_retries):
                try:
                    async with session.post(url, json=payload) as resp:
                        if resp.status in (429, 500, 502, 503, 504):
                            text = await resp.text()
                            raise aiohttp.ClientResponseError(
                                request_info=resp.request_info,
                                history=resp.history,
                                status=resp.status,
                                message=f"{resp.reason} | body={text[:300]}",
                                headers=resp.headers,
                            )
                        resp.raise_for_status()
                        return await resp.json()
                except (aiohttp.ClientResponseError, aiohttp.ClientConnectionError, asyncio.TimeoutError) as e:
                    last_exc = e
                    sleep_s = min(max_backoff_sec, base_backoff_sec * (2 ** attempt))
                    sleep_s *= (0.7 + 0.6 * random.random())
                    await asyncio.sleep(sleep_s)
            raise last_exc

        try:
            timeout = aiohttp.ClientTimeout(total=60)
            async with aiohttp.ClientSession(headers=self.headers, timeout=timeout) as session:
                while True:
                    payload = make_payload(page_index)
                    data = await post_with_retries(session, payload)

                    result = (data or {}).get("result") or {}
                    search_results = result.get("searchResults") or {}
                    hits = search_results.get("hits") or []

                    if not hits:
                        break

                    for hit in hits:
                        case_row_base = {
                            "caseNumber": hit.get("caseNumber"),
                            "jurisdiction": hit.get("jurisdiction"),
                            "caseCategoryCode": hit.get("caseCategoryCode"),
                            "dateFiled": hit.get("dateFiled"),
                            "status": hit.get("status"),
                            "statusActual": hit.get("statusActual"),
                            "isSealed": hit.get("isSealed"),
                            "caseLastRefreshed": hit.get("caseLastRefreshed"),
                        }

                        parties = hit.get("parties") or []

                        if not parties:
                            rows.append(
                                {
                                    **case_row_base,
                                    "partyTypeCode": None,
                                    "partyName": None,
                                    "partyEmail": None,
                                    "attorneyNames": None,
                                    "attorneyBarNumbers": None,
                                    "attorneyFirmNames": None,
                                }
                            )
                        else:
                            for p in parties:
                                att_summary = summarize_attorneys(p.get("attorneys"))
                                rows.append(
                                    {
                                        **case_row_base,
                                        "partyTypeCode": p.get("partyTypeCode"),
                                        "partyName": p.get("name"),
                                        "email": p.get("email"),   # ✅ THIS IS THE FIELD YOU WANT
                                        **att_summary,
                                    }
                                )

                    if checkpoint_every_pages and (page_index % checkpoint_every_pages == 0):
                        checkpoint()

                    if len(hits) < page_size:
                        break

                    page_index += 1

        except Exception:
            checkpoint()
            raise

        df = pd.DataFrame(rows)
        if not df.empty:
            df = df.drop_duplicates().reset_index(drop=True)

        df.to_csv(final_path, index=False)
        return df
