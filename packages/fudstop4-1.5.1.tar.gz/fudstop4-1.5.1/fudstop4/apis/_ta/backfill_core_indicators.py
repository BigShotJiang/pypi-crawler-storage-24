#!/usr/bin/env python3
import argparse
import asyncio
from typing import List, Optional, Tuple

import asyncpg
import pandas as pd

from ta_sdk import FudstopTA  # make sure ta_sdk.py is in the same folder or PYTHONPATH


FETCH_COLS = ["ticker", "timespan", "ts", "c"]

IND_COLS = [
    "ticker", "timespan", "ts",
    "rsi",
    "td_buy_count", "td_sell_count",
    "macd_line", "macd_signal", "macd_hist",
    "macd_cross_up", "macd_cross_dn",
    "macd_hist_slope", "macd_hist_slope3",
]


def build_indicators(
    df: pd.DataFrame,
    *,
    rsi_window: int,
    macd_fast: int,
    macd_slow: int,
    macd_signal: int,
) -> pd.DataFrame:
    # Must be ASC by ts
    df["c"] = pd.to_numeric(df["c"], errors="coerce").astype(float)

    df = FudstopTA.compute_wilders_rsi(df, window=rsi_window)
    df = FudstopTA.add_td9_counts(df)
    df = FudstopTA.add_macd(df, fast_period=macd_fast, slow_period=macd_slow, signal_period=macd_signal)
    return df


async def fetch_all_tickers(conn: asyncpg.Connection, timespan: str) -> List[Tuple[str, str]]:
    rows = await conn.fetch(
        """
        SELECT DISTINCT ticker, timespan
        FROM public.ca
        WHERE timespan = $1
        ORDER BY ticker;
        """,
        timespan,
    )
    return [(r["ticker"], r["timespan"]) for r in rows]


async def ensure_temp_table(conn: asyncpg.Connection) -> None:
    await conn.execute("""
        CREATE TEMP TABLE IF NOT EXISTS ca_core_stage (
          ticker text,
          timespan text,
          ts text,

          rsi double precision,
          td_buy_count integer,
          td_sell_count integer,

          macd_line double precision,
          macd_signal double precision,
          macd_hist double precision,
          macd_cross_up boolean,
          macd_cross_dn boolean,
          macd_hist_slope double precision,
          macd_hist_slope3 double precision
        ) ON COMMIT DROP;
    """)

async def recreate_temp_table(conn: asyncpg.Connection) -> None:
    await conn.execute("DROP TABLE IF EXISTS ca_core_stage;")
    await conn.execute("""
        CREATE TEMP TABLE ca_core_stage (
          ticker text,
          timespan text,
          ts text,

          rsi double precision,
          td_buy_count integer,
          td_sell_count integer,

          macd_line double precision,
          macd_signal double precision,
          macd_hist double precision,
          macd_cross_up boolean,
          macd_cross_dn boolean,
          macd_hist_slope double precision,
          macd_hist_slope3 double precision
        );
    """)

async def upsert_stage_into_ca(conn: asyncpg.Connection) -> None:
    await conn.execute("""
        UPDATE public.ca AS ca
        SET
          rsi = s.rsi,
          td_buy_count = s.td_buy_count,
          td_sell_count = s.td_sell_count,
          macd_line = s.macd_line,
          macd_signal = s.macd_signal,
          macd_hist = s.macd_hist,
          macd_cross_up = s.macd_cross_up,
          macd_cross_dn = s.macd_cross_dn,
          macd_hist_slope = s.macd_hist_slope,
          macd_hist_slope3 = s.macd_hist_slope3
        FROM ca_core_stage s
        WHERE ca.ticker = s.ticker
          AND ca.timespan = s.timespan
          AND ca.ts = s.ts;
    """)


async def process_ticker(
    conn: asyncpg.Connection,
    *,
    ticker: str,
    timespan: str,
    ts_start: Optional[str],
    ts_end: Optional[str],
    chunk_rows: int,
    warmup_rows: int,
    rsi_window: int,
    macd_fast: int,
    macd_slow: int,
    macd_signal: int,
) -> None:
    # Find max ts for pagination inside this ticker range
    args: List[object] = [ticker, timespan]
    where = ["ticker=$1", "timespan=$2"]
    if ts_start:
        where.append("ts >= $3")
        args.append(ts_start)
        if ts_end:
            where.append("ts <= $4")
            args.append(ts_end)
    elif ts_end:
        where.append("ts <= $3")
        args.append(ts_end)

    max_ts = await conn.fetchval(f"SELECT max(ts) FROM public.ca WHERE {' AND '.join(where)};", *args)
    if not max_ts:
        print(f"    (no rows in range)")
        return

    cursor = max_ts
    wrote_total = 0

    while True:
        sql = f"""
            SELECT {", ".join(FETCH_COLS)}
            FROM public.ca
            WHERE ticker=$1 AND timespan=$2
              AND ts <= $3
              {"AND ts >= $4" if ts_start else ""}
            ORDER BY ts DESC
            LIMIT {chunk_rows + warmup_rows};
        """
        rows = await conn.fetch(sql, *( [ticker, timespan, cursor] + ([ts_start] if ts_start else []) ))
        if not rows:
            break

        df = pd.DataFrame(rows, columns=FETCH_COLS).sort_values("ts").reset_index(drop=True)

        df = build_indicators(
            df,
            rsi_window=rsi_window,
            macd_fast=macd_fast,
            macd_slow=macd_slow,
            macd_signal=macd_signal,
        )

        df_out = df.iloc[-chunk_rows:].copy() if len(df) > chunk_rows else df

        await recreate_temp_table(conn)

        records = []
        for _, r in df_out[IND_COLS].iterrows():
            rec = []
            for col in IND_COLS:
                v = r[col]
                rec.append(None if pd.isna(v) else v)
            records.append(tuple(rec))

        await conn.copy_records_to_table("ca_core_stage", records=records, columns=IND_COLS)
        await upsert_stage_into_ca(conn)

        wrote_total += len(records)

        oldest_ts = df["ts"].iloc[0]
        if oldest_ts == cursor:
            break
        cursor = oldest_ts

        if ts_start and cursor <= ts_start:
            break

    print(f"    wrote ~{wrote_total:,} rows")


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--timespan", default="m1")
    ap.add_argument("--ticker", default=None, help="Optional; if omitted, processes all tickers for the timespan.")
    ap.add_argument("--ts-start", default=None)
    ap.add_argument("--ts-end", default=None)
    ap.add_argument("--chunk-rows", type=int, default=20000)
    ap.add_argument("--warmup-rows", type=int, default=500)
    ap.add_argument("--limit-tickers", type=int, default=0, help="For testing; 0 means no limit.")

    ap.add_argument("--rsi-window", type=int, default=14)
    ap.add_argument("--macd-fast", type=int, default=12)
    ap.add_argument("--macd-slow", type=int, default=26)
    ap.add_argument("--macd-signal", type=int, default=9)

    args = ap.parse_args()

    print("Starting backfill_core_indicators.py")
    print(f"DSN: {args.dsn}")
    print(f"Timespan: {args.timespan}")

    conn = await asyncpg.connect(args.dsn)
    try:
        dbname = await conn.fetchval("SELECT current_database();")
        print(f"Connected. DB = {dbname}")

        total_rows = await conn.fetchval(
            "SELECT COUNT(*) FROM public.ca WHERE timespan=$1;",
            args.timespan
        )
        print(f"Rows in ca for timespan={args.timespan}: {total_rows:,}")

        if args.ticker:
            tickers = [(args.ticker, args.timespan)]
        else:
            tickers = await fetch_all_tickers(conn, args.timespan)

        if args.limit_tickers and args.limit_tickers > 0:
            tickers = tickers[: args.limit_tickers]

        print(f"Found {len(tickers)} (ticker,timespan) pairs to process")

        if not tickers:
            print("Nothing to do. (This would be weird given your counts—check timespan spelling.)")
            return

        for i, (ticker, timespan) in enumerate(tickers, 1):
            print(f"[{i}/{len(tickers)}] {ticker} {timespan}")
            try:
                await process_ticker(
                    conn,
                    ticker=ticker,
                    timespan=timespan,
                    ts_start=args.ts_start,
                    ts_end=args.ts_end,
                    chunk_rows=args.chunk_rows,
                    warmup_rows=args.warmup_rows,
                    rsi_window=args.rsi_window,
                    macd_fast=args.macd_fast,
                    macd_slow=args.macd_slow,
                    macd_signal=args.macd_signal,
                )
            except Exception as e:
                print(f"  ERROR on {ticker}: {e}")

        print("Done.")
    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(main())
