"""
BioPype REST API.

FastAPI backend for the BioPype builder, using pype.core business logic.
"""

from .app import app

__all__ = ["app"]
