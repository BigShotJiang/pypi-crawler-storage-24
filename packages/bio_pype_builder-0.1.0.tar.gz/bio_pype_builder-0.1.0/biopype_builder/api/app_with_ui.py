"""
FastAPI app with React UI static file serving.

This combines the API backend with static file serving for the React frontend.
"""

from pathlib import Path

from fastapi.staticfiles import StaticFiles

from .app import app

# Path to React build directory
REACT_DIST = Path(__file__).parent.parent / "ui_react" / "dist"

# Serve React static files if they exist
if REACT_DIST.exists():
    # Serve static assets (JS, CSS, images)
    app.mount(
        "/assets",
        StaticFiles(directory=REACT_DIST / "assets"),
        name="static-assets",
    )

    # Serve React app for all other routes (SPA fallback)
    # This must be LAST so API routes take precedence
    app.mount(
        "/",
        StaticFiles(directory=REACT_DIST, html=True),
        name="react-ui",
    )
else:
    # React not built yet - add a helpful message
    @app.get("/")
    async def root():
        """Root endpoint when React UI is not built."""
        return {
            "message": "BioPype API is running",
            "docs": "/api/docs",
            "react_ui": "Not built - run: cd pype/ui_react && npm run build",
            "panel_ui": "Use --ui panel flag to run Panel UI instead",
        }
