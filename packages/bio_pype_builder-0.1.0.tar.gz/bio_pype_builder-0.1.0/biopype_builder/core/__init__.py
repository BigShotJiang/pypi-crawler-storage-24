"""
Core business logic for BioPype.

This module contains pure business logic with no UI dependencies.
Can be used by Panel UI, FastAPI backend, CLI tools, etc.
"""

from .loader import SnippetLoader

__all__ = [
    "SnippetLoader",
]
