# BioPype Builder

Interactive web-based builder for creating BioPype pipelines.

## Installation

```bash
pip install bio-pype-builder
```

## Usage

Start the builder:
```bash
bio-pype-builder
```

Or with Python:
```bash
python -m biopype_builder.builder
```

## Development

Install in development mode:
```bash
git clone https://codeberg.org/your-org/bio-pype-builder
cd bio-pype-builder
```

Build React UI:
```bash
cd biopype_builder/ui_react
npm install
npm run build
```

Install the package:
```bash
pip install -e .
```



## Requirements

- bio-pype >= 2.0.0
- Python >= 3.9
