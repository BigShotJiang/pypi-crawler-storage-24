from __future__ import annotations

import httpx

from islo._api.auth import AsyncAuth, Auth
from islo._api.certificate_authority import AsyncCertificateAuthority, CertificateAuthority
from islo._api.integrations import AsyncIntegrations, Integrations
from islo._api.models_ import AsyncModels, Models
from islo._api.sandboxes import AsyncSandboxes, Sandboxes
from islo._api.shares import AsyncShares, Shares
from islo._api.tenants import AsyncTenants, Tenants
from islo._api.usage import AsyncUsage, Usage
from islo._api.users import AsyncUsers, Users

_AUTH_TOKEN_PATH = "/auth/token"


def _resolve_auth(api_key: str, base_url: str, timeout: float) -> str:
    """Exchange an access key for a session JWT, or use a JWT directly."""
    if api_key.startswith("eyJ"):
        return api_key
    resp = httpx.post(
        f"{base_url}{_AUTH_TOKEN_PATH}",
        json={"access_key": api_key},
        timeout=timeout,
    )
    resp.raise_for_status()
    return resp.json()["session_token"]


async def _resolve_auth_async(api_key: str, base_url: str, timeout: float) -> str:
    if api_key.startswith("eyJ"):
        return api_key
    async with httpx.AsyncClient(timeout=timeout) as c:
        resp = await c.post(
            f"{base_url}{_AUTH_TOKEN_PATH}",
            json={"access_key": api_key},
        )
        resp.raise_for_status()
        return resp.json()["session_token"]


class Islo:
    """Synchronous Islo API client.

    Usage::

        from islo import Islo

        client = Islo(api_key="sk-...")
        sandboxes = client.sandboxes.list(limit=20)
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://api.islo.dev",
        timeout: float = 30.0,
    ) -> None:
        token = _resolve_auth(api_key, base_url, timeout)
        self._client = httpx.Client(
            base_url=base_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=timeout,
        )
        self.auth = Auth(self._client)
        self.certificate_authority = CertificateAuthority(self._client)
        self.integrations = Integrations(self._client)
        self.models = Models(self._client)
        self.sandboxes = Sandboxes(self._client)
        self.shares = Shares(self._client)
        self.tenants = Tenants(self._client)
        self.usage = Usage(self._client)
        self.users = Users(self._client)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Islo:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncIslo:
    """Async Islo API client.

    Usage::

        from islo import AsyncIslo

        client = await AsyncIslo.create(api_key="sk-...")
        sandboxes = await client.sandboxes.list(limit=20)
    """

    def __init__(self, *, _client: httpx.AsyncClient) -> None:
        self._client = _client
        self.auth = AsyncAuth(self._client)
        self.certificate_authority = AsyncCertificateAuthority(self._client)
        self.integrations = AsyncIntegrations(self._client)
        self.models = AsyncModels(self._client)
        self.sandboxes = AsyncSandboxes(self._client)
        self.shares = AsyncShares(self._client)
        self.tenants = AsyncTenants(self._client)
        self.usage = AsyncUsage(self._client)
        self.users = AsyncUsers(self._client)

    @classmethod
    async def create(
        cls,
        *,
        api_key: str,
        base_url: str = "https://api.islo.dev",
        timeout: float = 30.0,
    ) -> AsyncIslo:
        token = await _resolve_auth_async(api_key, base_url, timeout)
        client = httpx.AsyncClient(
            base_url=base_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=timeout,
        )
        return cls(_client=client)

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncIslo:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
