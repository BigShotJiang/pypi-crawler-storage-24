from __future__ import annotations

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    TokenRequest,
    TokenResponse,
)


class Auth(SyncAPIResource):
    def exchange_token(self, *, body: TokenRequest) -> TokenResponse:
        """Exchange an access key for a session token."""
        return self._request("POST", "/auth/token", json_body=body, response_model=TokenResponse)


class AsyncAuth(AsyncAPIResource):
    async def exchange_token(self, *, body: TokenRequest) -> TokenResponse:
        """Exchange an access key for a session token."""
        return await self._request("POST", "/auth/token", json_body=body, response_model=TokenResponse)
