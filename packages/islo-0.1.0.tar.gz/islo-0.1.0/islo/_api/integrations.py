from __future__ import annotations

from typing import Any

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    IntegrationDetailResponse,
    IntegrationListResponse,
    IntegrationProvidersResponse,
)


class Integrations(SyncAPIResource):
    def list(self) -> IntegrationListResponse:
        """List User Integrations"""
        return self._request("GET", "/integrations", response_model=IntegrationListResponse)

    def list_providers(self) -> IntegrationProvidersResponse:
        """List Providers"""
        return self._request("GET", "/integrations/providers", response_model=IntegrationProvidersResponse)

    def disconnect(self, provider: str, *, level: str | None = "user") -> Any:
        """Disconnect Integration"""
        return self._request("DELETE", f"/integrations/{provider}", params={"level": level})

    def get_status(self, provider: str) -> IntegrationDetailResponse:
        """Get Integration Status"""
        return self._request("GET", f"/integrations/{provider}", response_model=IntegrationDetailResponse)


class AsyncIntegrations(AsyncAPIResource):
    async def list(self) -> IntegrationListResponse:
        """List User Integrations"""
        return await self._request("GET", "/integrations", response_model=IntegrationListResponse)

    async def list_providers(self) -> IntegrationProvidersResponse:
        """List Providers"""
        return await self._request("GET", "/integrations/providers", response_model=IntegrationProvidersResponse)

    async def disconnect(self, provider: str, *, level: str | None = "user") -> Any:
        """Disconnect Integration"""
        return await self._request("DELETE", f"/integrations/{provider}", params={"level": level})

    async def get_status(self, provider: str) -> IntegrationDetailResponse:
        """Get Integration Status"""
        return await self._request("GET", f"/integrations/{provider}", response_model=IntegrationDetailResponse)
