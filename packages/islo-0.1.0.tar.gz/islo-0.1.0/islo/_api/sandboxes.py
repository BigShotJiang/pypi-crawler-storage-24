from __future__ import annotations

from typing import Any

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    AgentSessionEventResponse,
    AgentSessionResponse,
    ExecLogsResponse,
    ExecRequest,
    ExecResponse,
    ExecSessionResponse,
    PaginatedSandboxResponse,
    SandboxCreate,
    SandboxResponse,
    SyncExecRequest,
    SyncExecResponse,
)


class Sandboxes(SyncAPIResource):
    def list(
        self,
        *,
        search: str | None = None,
        status: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        created_by: str | None = None,
        limit: int | None = 50,
        offset: int | None = 0,
    ) -> PaginatedSandboxResponse:
        """List sandboxes"""
        return self._request(
            "GET",
            "/sandboxes/",
            params={
                "search": search,
                "status": status,
                "date_from": date_from,
                "date_to": date_to,
                "created_by": created_by,
                "limit": limit,
                "offset": offset,
            },
            response_model=PaginatedSandboxResponse,
        )

    def create(self, *, body: SandboxCreate) -> SandboxResponse:
        """Create sandbox"""
        return self._request("POST", "/sandboxes/", json_body=body, response_model=SandboxResponse)

    def list_agent_sessions(
        self, sandbox_id: str, *, since: str | None = None, include_subagents: bool | None = False
    ) -> list[AgentSessionResponse]:
        """List agent sessions"""
        return self._request(
            "GET",
            f"/sandboxes/{sandbox_id}/agent-sessions",
            params={"since": since, "include_subagents": include_subagents},
        )

    def get_agent_session_events(
        self,
        sandbox_id: str,
        session_name: str,
        *,
        session_path: str | None = None,
        include_descendants: bool | None = True,
        limit: int | None = 500,
        offset: int | None = 0,
        since: str | None = None,
    ) -> list[AgentSessionEventResponse]:
        """Get agent session events"""
        return self._request(
            "GET",
            f"/sandboxes/{sandbox_id}/agent-sessions/{session_name}/events",
            params={
                "session_path": session_path,
                "include_descendants": include_descendants,
                "limit": limit,
                "offset": offset,
                "since": since,
            },
        )

    def list_exec_sessions(self, sandbox_id: str, *, since: str | None = None) -> list[ExecSessionResponse]:
        """List exec sessions"""
        return self._request("GET", f"/sandboxes/{sandbox_id}/exec-sessions", params={"since": since})

    def get_exec_session_asciinema(self, sandbox_id: str, exec_id: str, *, limit: int | None = 2000) -> Any:
        """Get exec session as asciinema cast"""
        return self._request(
            "GET", f"/sandboxes/{sandbox_id}/exec-sessions/{exec_id}/asciinema", params={"limit": limit}
        )

    def get_exec_session_logs(
        self, sandbox_id: str, exec_id: str, *, limit: int | None = 2000, since: str | None = None
    ) -> ExecLogsResponse:
        """Get exec session logs"""
        return self._request(
            "GET",
            f"/sandboxes/{sandbox_id}/exec-sessions/{exec_id}/logs",
            params={"limit": limit, "since": since},
            response_model=ExecLogsResponse,
        )

    def delete(self, sandbox_name: str) -> Any:
        """Remove sandbox"""
        return self._request("DELETE", f"/sandboxes/{sandbox_name}")

    def get(self, sandbox_name: str) -> SandboxResponse:
        """Get sandbox"""
        return self._request("GET", f"/sandboxes/{sandbox_name}", response_model=SandboxResponse)

    def exec(self, sandbox_name: str, *, body: ExecRequest) -> ExecResponse:
        """Execute command"""
        return self._request("POST", f"/sandboxes/{sandbox_name}/exec", json_body=body, response_model=ExecResponse)

    def exec_stream(self, sandbox_name: str, *, body: ExecRequest) -> Any:
        """Execute command with streaming"""
        return self._request("POST", f"/sandboxes/{sandbox_name}/exec/stream", json_body=body)

    def promote_cache(self, sandbox_name: str) -> Any:
        """Promote cache"""
        return self._request("POST", f"/sandboxes/{sandbox_name}/promote-cache")

    def stop(self, sandbox_name: str) -> Any:
        """Stop sandbox"""
        return self._request("POST", f"/sandboxes/{sandbox_name}/stop")

    def exec_sync(self, sandbox_name: str, *, body: SyncExecRequest) -> SyncExecResponse:
        """Execute a command synchronously and return stdout/stderr/exit_code."""
        return self._request(
            "POST", f"/sandboxes/{sandbox_name}/exec/sync", json_body=body, response_model=SyncExecResponse
        )


class AsyncSandboxes(AsyncAPIResource):
    async def list(
        self,
        *,
        search: str | None = None,
        status: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        created_by: str | None = None,
        limit: int | None = 50,
        offset: int | None = 0,
    ) -> PaginatedSandboxResponse:
        """List sandboxes"""
        return await self._request(
            "GET",
            "/sandboxes/",
            params={
                "search": search,
                "status": status,
                "date_from": date_from,
                "date_to": date_to,
                "created_by": created_by,
                "limit": limit,
                "offset": offset,
            },
            response_model=PaginatedSandboxResponse,
        )

    async def create(self, *, body: SandboxCreate) -> SandboxResponse:
        """Create sandbox"""
        return await self._request("POST", "/sandboxes/", json_body=body, response_model=SandboxResponse)

    async def list_agent_sessions(
        self, sandbox_id: str, *, since: str | None = None, include_subagents: bool | None = False
    ) -> list[AgentSessionResponse]:
        """List agent sessions"""
        return await self._request(
            "GET",
            f"/sandboxes/{sandbox_id}/agent-sessions",
            params={"since": since, "include_subagents": include_subagents},
        )

    async def get_agent_session_events(
        self,
        sandbox_id: str,
        session_name: str,
        *,
        session_path: str | None = None,
        include_descendants: bool | None = True,
        limit: int | None = 500,
        offset: int | None = 0,
        since: str | None = None,
    ) -> list[AgentSessionEventResponse]:
        """Get agent session events"""
        return await self._request(
            "GET",
            f"/sandboxes/{sandbox_id}/agent-sessions/{session_name}/events",
            params={
                "session_path": session_path,
                "include_descendants": include_descendants,
                "limit": limit,
                "offset": offset,
                "since": since,
            },
        )

    async def list_exec_sessions(self, sandbox_id: str, *, since: str | None = None) -> list[ExecSessionResponse]:
        """List exec sessions"""
        return await self._request("GET", f"/sandboxes/{sandbox_id}/exec-sessions", params={"since": since})

    async def get_exec_session_asciinema(self, sandbox_id: str, exec_id: str, *, limit: int | None = 2000) -> Any:
        """Get exec session as asciinema cast"""
        return await self._request(
            "GET", f"/sandboxes/{sandbox_id}/exec-sessions/{exec_id}/asciinema", params={"limit": limit}
        )

    async def get_exec_session_logs(
        self, sandbox_id: str, exec_id: str, *, limit: int | None = 2000, since: str | None = None
    ) -> ExecLogsResponse:
        """Get exec session logs"""
        return await self._request(
            "GET",
            f"/sandboxes/{sandbox_id}/exec-sessions/{exec_id}/logs",
            params={"limit": limit, "since": since},
            response_model=ExecLogsResponse,
        )

    async def delete(self, sandbox_name: str) -> Any:
        """Remove sandbox"""
        return await self._request("DELETE", f"/sandboxes/{sandbox_name}")

    async def get(self, sandbox_name: str) -> SandboxResponse:
        """Get sandbox"""
        return await self._request("GET", f"/sandboxes/{sandbox_name}", response_model=SandboxResponse)

    async def exec(self, sandbox_name: str, *, body: ExecRequest) -> ExecResponse:
        """Execute command"""
        return await self._request(
            "POST", f"/sandboxes/{sandbox_name}/exec", json_body=body, response_model=ExecResponse
        )

    async def exec_stream(self, sandbox_name: str, *, body: ExecRequest) -> Any:
        """Execute command with streaming"""
        return await self._request("POST", f"/sandboxes/{sandbox_name}/exec/stream", json_body=body)

    async def promote_cache(self, sandbox_name: str) -> Any:
        """Promote cache"""
        return await self._request("POST", f"/sandboxes/{sandbox_name}/promote-cache")

    async def stop(self, sandbox_name: str) -> Any:
        """Stop sandbox"""
        return await self._request("POST", f"/sandboxes/{sandbox_name}/stop")

    async def exec_sync(self, sandbox_name: str, *, body: SyncExecRequest) -> SyncExecResponse:
        """Execute a command synchronously and return stdout/stderr/exit_code."""
        return await self._request(
            "POST", f"/sandboxes/{sandbox_name}/exec/sync", json_body=body, response_model=SyncExecResponse
        )
