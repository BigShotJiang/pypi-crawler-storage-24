from __future__ import annotations

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    SandboxUsageDetail,
    UsageSummary,
)


class Usage(SyncAPIResource):
    def sandbox_usage(self, *, start: str | None = None, end: str | None = None) -> list[SandboxUsageDetail]:
        """Get detailed usage per sandbox for the authenticated tenant"""
        return self._request("GET", "/usage/me/sandboxes", params={"start": start, "end": end})

    def summary(self, *, start: str | None = None, end: str | None = None) -> UsageSummary:
        """Get usage summary for the authenticated tenant"""
        return self._request(
            "GET", "/usage/me/summary", params={"start": start, "end": end}, response_model=UsageSummary
        )


class AsyncUsage(AsyncAPIResource):
    async def sandbox_usage(self, *, start: str | None = None, end: str | None = None) -> list[SandboxUsageDetail]:
        """Get detailed usage per sandbox for the authenticated tenant"""
        return await self._request("GET", "/usage/me/sandboxes", params={"start": start, "end": end})

    async def summary(self, *, start: str | None = None, end: str | None = None) -> UsageSummary:
        """Get usage summary for the authenticated tenant"""
        return await self._request(
            "GET", "/usage/me/summary", params={"start": start, "end": end}, response_model=UsageSummary
        )
