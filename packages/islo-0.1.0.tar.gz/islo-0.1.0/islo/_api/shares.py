from __future__ import annotations

from typing import Any

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    CreateShareRequest,
    ShareResponse,
)


class Shares(SyncAPIResource):
    def list(self, sandbox_name: str) -> list[ShareResponse]:
        """List shares"""
        return self._request("GET", f"/sandboxes/{sandbox_name}/shares")

    def create(self, sandbox_name: str, *, body: CreateShareRequest) -> ShareResponse:
        """Create share"""
        return self._request("POST", f"/sandboxes/{sandbox_name}/shares", json_body=body, response_model=ShareResponse)

    def revoke(self, sandbox_name: str, share_id: str) -> Any:
        """Revoke share"""
        return self._request("DELETE", f"/sandboxes/{sandbox_name}/shares/{share_id}")


class AsyncShares(AsyncAPIResource):
    async def list(self, sandbox_name: str) -> list[ShareResponse]:
        """List shares"""
        return await self._request("GET", f"/sandboxes/{sandbox_name}/shares")

    async def create(self, sandbox_name: str, *, body: CreateShareRequest) -> ShareResponse:
        """Create share"""
        return await self._request(
            "POST", f"/sandboxes/{sandbox_name}/shares", json_body=body, response_model=ShareResponse
        )

    async def revoke(self, sandbox_name: str, share_id: str) -> Any:
        """Revoke share"""
        return await self._request("DELETE", f"/sandboxes/{sandbox_name}/shares/{share_id}")
