from __future__ import annotations

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    ModelPricingResponse,
)


class Models(SyncAPIResource):
    def get_pricing(self) -> ModelPricingResponse:
        """Get model pricing"""
        return self._request("GET", "/models/pricing", response_model=ModelPricingResponse)


class AsyncModels(AsyncAPIResource):
    async def get_pricing(self) -> ModelPricingResponse:
        """Get model pricing"""
        return await self._request("GET", "/models/pricing", response_model=ModelPricingResponse)
