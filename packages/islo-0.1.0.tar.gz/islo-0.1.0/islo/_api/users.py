from __future__ import annotations

from typing import Any

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    InviteUserRequest,
    InviteUserResponse,
    PartialUpdateUser,
)


class Users(SyncAPIResource):
    def authorize(self) -> Any:
        """Authorize"""
        return self._request("POST", "/users/authorize")

    def invite(self, *, body: InviteUserRequest) -> InviteUserResponse:
        """Invite User"""
        return self._request("POST", "/users/invite", json_body=body, response_model=InviteUserResponse)

    def update(self, user_id: str, *, body: PartialUpdateUser) -> Any:
        """Update User"""
        return self._request("PATCH", f"/users/{user_id}", json_body=body)

    def get(self, user: str) -> Any:
        """Get User"""
        return self._request("GET", f"/users/{user}")


class AsyncUsers(AsyncAPIResource):
    async def authorize(self) -> Any:
        """Authorize"""
        return await self._request("POST", "/users/authorize")

    async def invite(self, *, body: InviteUserRequest) -> InviteUserResponse:
        """Invite User"""
        return await self._request("POST", "/users/invite", json_body=body, response_model=InviteUserResponse)

    async def update(self, user_id: str, *, body: PartialUpdateUser) -> Any:
        """Update User"""
        return await self._request("PATCH", f"/users/{user_id}", json_body=body)

    async def get(self, user: str) -> Any:
        """Get User"""
        return await self._request("GET", f"/users/{user}")
