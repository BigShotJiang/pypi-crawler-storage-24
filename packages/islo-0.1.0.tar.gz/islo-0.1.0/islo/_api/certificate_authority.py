from __future__ import annotations

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    CAPublicKeyResponse,
    SSHCertificateRequest,
    SSHCertificateResponse,
)


class CertificateAuthority(SyncAPIResource):
    def create_certificate(self, *, body: SSHCertificateRequest) -> SSHCertificateResponse:
        """Issue SSH certificate"""
        return self._request("POST", "/certificate-authority/", json_body=body, response_model=SSHCertificateResponse)

    def get_public_key(self) -> CAPublicKeyResponse:
        """Get CA public key"""
        return self._request("GET", "/certificate-authority/public-key", response_model=CAPublicKeyResponse)


class AsyncCertificateAuthority(AsyncAPIResource):
    async def create_certificate(self, *, body: SSHCertificateRequest) -> SSHCertificateResponse:
        """Issue SSH certificate"""
        return await self._request(
            "POST", "/certificate-authority/", json_body=body, response_model=SSHCertificateResponse
        )

    async def get_public_key(self) -> CAPublicKeyResponse:
        """Get CA public key"""
        return await self._request("GET", "/certificate-authority/public-key", response_model=CAPublicKeyResponse)
