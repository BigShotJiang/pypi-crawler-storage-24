from __future__ import annotations

from typing import Any

from islo._base import AsyncAPIResource, SyncAPIResource
from islo.models import (
    CreateTenant,
    PublicSubscription,
    PublicTenant,
    TenantSettingsResponse,
    TenantSettingsUpdate,
)


class Tenants(SyncAPIResource):
    def list(self) -> list[PublicTenant]:
        """Get All Tenants"""
        return self._request("GET", "/tenants/")

    def create(self, *, body: CreateTenant) -> Any:
        """Create Tenant"""
        return self._request("POST", "/tenants/", json_body=body)

    def get_settings(self) -> TenantSettingsResponse:
        """Get Settings"""
        return self._request("GET", "/tenants/settings", response_model=TenantSettingsResponse)

    def update_settings(self, *, body: TenantSettingsUpdate) -> TenantSettingsResponse:
        """Update Settings"""
        return self._request("PATCH", "/tenants/settings", json_body=body, response_model=TenantSettingsResponse)

    def get_subscription(self) -> PublicSubscription:
        """Get Subscription"""
        return self._request("GET", "/tenants/subscription", response_model=PublicSubscription)


class AsyncTenants(AsyncAPIResource):
    async def list(self) -> list[PublicTenant]:
        """Get All Tenants"""
        return await self._request("GET", "/tenants/")

    async def create(self, *, body: CreateTenant) -> Any:
        """Create Tenant"""
        return await self._request("POST", "/tenants/", json_body=body)

    async def get_settings(self) -> TenantSettingsResponse:
        """Get Settings"""
        return await self._request("GET", "/tenants/settings", response_model=TenantSettingsResponse)

    async def update_settings(self, *, body: TenantSettingsUpdate) -> TenantSettingsResponse:
        """Update Settings"""
        return await self._request("PATCH", "/tenants/settings", json_body=body, response_model=TenantSettingsResponse)

    async def get_subscription(self) -> PublicSubscription:
        """Get Subscription"""
        return await self._request("GET", "/tenants/subscription", response_model=PublicSubscription)
