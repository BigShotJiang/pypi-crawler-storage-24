from __future__ import annotations

from typing import Any, TypeVar

import httpx
from pydantic import BaseModel

from islo._exceptions import (
    APIStatusError,
    AuthenticationError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)

T = TypeVar("T", bound=BaseModel)


def _raise_for_status(response: httpx.Response) -> None:
    if response.is_success:
        return
    status = response.status_code
    try:
        body = response.json()
        message = body.get("detail", response.text)
    except Exception:
        message = response.text

    error_map: dict[int, type[APIStatusError]] = {
        401: AuthenticationError,
        403: PermissionDeniedError,
        404: NotFoundError,
        422: UnprocessableEntityError,
        429: RateLimitError,
    }
    cls = error_map.get(status, InternalServerError if status >= 500 else APIStatusError)
    raise cls(str(message), status_code=status, response=response)


def _prepare_body(json_body: Any | None) -> Any | None:
    if json_body is None:
        return None
    if isinstance(json_body, BaseModel):
        return json_body.model_dump(mode="json", exclude_unset=True)
    return json_body


def _parse_response(response: httpx.Response, response_model: type[T] | None) -> T | Any:
    _raise_for_status(response)
    if response_model:
        return response_model.model_validate(response.json())
    if response.headers.get("content-type", "").startswith("application/json"):
        return response.json()
    return response.text


class SyncAPIResource:
    _client: httpx.Client

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any | None = None,
        response_model: type[T] | None = None,
    ) -> T | Any:
        filtered_params = {k: v for k, v in (params or {}).items() if v is not None} or None
        response = self._client.request(method, path, params=filtered_params, json=_prepare_body(json_body))
        return _parse_response(response, response_model)


class AsyncAPIResource:
    _client: httpx.AsyncClient

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any | None = None,
        response_model: type[T] | None = None,
    ) -> T | Any:
        filtered_params = {k: v for k, v in (params or {}).items() if v is not None} or None
        response = await self._client.request(method, path, params=filtered_params, json=_prepare_body(json_body))
        return _parse_response(response, response_model)
