from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import httpx


class IsloError(Exception):
    """Base exception for the Islo SDK."""


class APIStatusError(IsloError):
    """Raised when the API returns a non-success status code."""

    status_code: int
    response: httpx.Response

    def __init__(self, message: str, *, status_code: int, response: httpx.Response) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class AuthenticationError(APIStatusError):
    """401 Unauthorized."""


class PermissionDeniedError(APIStatusError):
    """403 Forbidden."""


class NotFoundError(APIStatusError):
    """404 Not Found."""


class UnprocessableEntityError(APIStatusError):
    """422 Validation Error."""


class RateLimitError(APIStatusError):
    """429 Too Many Requests."""


class InternalServerError(APIStatusError):
    """5xx Server Error."""
