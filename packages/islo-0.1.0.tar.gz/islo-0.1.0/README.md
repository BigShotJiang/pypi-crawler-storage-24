# islo

Typed Python SDK for the [Islo](https://islo.dev) API.

## Install

```sh
pip install islo
```

## Usage

```python
from islo import Islo

client = Islo(api_key="sk-...")

# List sandboxes
sandboxes = client.sandboxes.list(limit=20)

# Create a sandbox
from islo.models import SandboxCreate, SandboxSpec

sandbox = client.sandboxes.create(body=SandboxCreate(
    name="my-sandbox",
    spec=SandboxSpec(cpu=2, memory=4096),
))

# Get a sandbox
sandbox = client.sandboxes.get("my-sandbox")

# Execute a command
from islo.models import ExecRequest

result = client.sandboxes.exec("my-sandbox", body=ExecRequest(
    command=["echo", "hello"],
))

# Delete
client.sandboxes.delete("my-sandbox")
```

## Resources

| Resource | Methods |
|---|---|
| `client.sandboxes` | `list`, `create`, `get`, `delete`, `stop`, `exec`, `exec_stream`, `promote_cache`, `list_agent_sessions`, `get_agent_session_events`, `list_exec_sessions`, `get_exec_session_logs` |
| `client.tenants` | `list`, `create`, `get_settings`, `update_settings`, `get_subscription` |
| `client.users` | `get`, `invite`, `update`, `authorize` |
| `client.shares` | `list`, `create`, `revoke` |
| `client.integrations` | `list`, `list_providers`, `get_status`, `disconnect` |
| `client.usage` | `sandbox_usage`, `summary` |
| `client.certificate_authority` | `create_certificate`, `get_public_key` |

## Regenerate

```sh
just sync
```
