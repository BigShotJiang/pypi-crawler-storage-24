from vector_bridge import VectorBridgeClient
from vector_bridge.sync_io.admin.vector_db.state import VectorDBStateAdmin


class VectorDBAdmin:
    """Admin client for VectorDB management endpoints."""

    def __init__(self, client: VectorBridgeClient):
        self.client = client
        self.state = VectorDBStateAdmin(client)
