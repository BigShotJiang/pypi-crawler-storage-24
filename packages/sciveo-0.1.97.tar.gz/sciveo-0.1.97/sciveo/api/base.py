#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2023
#

import os
import json
from urllib import request, parse
from urllib.error import HTTPError

from sciveo.tools.logger import *
from sciveo.tools.configuration import GlobalConfiguration


class APIRemoteClient:
  def __init__(self, base_url=None, ver=1):
    self.config = GlobalConfiguration.get()
    self.auth_token = None
    if base_url is None:
      base_url = self.config["api_base_url"]
    self.base_url = f"{base_url}/api/v{ver}/"
    self.headers = { "Auth-Token": self.config['secret_access_key'] }
    debug(f"base url: {self.base_url}")

  def POST_SCI(self, content_type, data, timeout=30):
    return self.POST(f"sci/{content_type}/", data, timeout)

  def POST(self, url, data, timeout=30):
    url = f"{self.base_url}{url}"
    result = False
    try:
      data = parse.urlencode(data).encode("utf-8")
      # debug("POST", url, data)
      resp = request.urlopen(request.Request(url, data=data, headers=self.headers), timeout=timeout)
      result = json.loads(resp.read())
      # debug("POST result", result)
    except HTTPError as e:
      error(e, url, data)
    except Exception as e:
      error(e, url, data)
    return result

  def GET_URL(self, url, timeout=30):
    result = False
    try:
      # debug("GET", url)
      resp = request.urlopen(request.Request(url, headers=self.headers), timeout=timeout)
      result = json.loads(resp.read())
      # debug("GET", resp.status, result)
    except HTTPError as e:
      error(e, url)
    except Exception as e:
      error(e, url)
    return result

  def GET(self, url, timeout=30):
    url = f"{self.base_url}{url}&auth_token={self.config['secret_access_key']}"
    return self.GET_URL(url, timeout=timeout)


class APIPaginatedClient(APIRemoteClient):
  def __init__(self, base_url, ver=1):
    super().__init__(base_url=base_url, ver=ver)
    self.data = []

  def read(self, endpoint, args={}, limit=20, page=1):
    self.data = []

    endpoint_url = f"{endpoint}?limit={limit}"

    if len(args) > 0:
      endpoint_url += f"&{parse.urlencode(args)}"

    next_page = page
    while(next_page):
      url = f"{endpoint_url}&page={next_page}"
      r = self.GET(url)

      pagination = r.get("pagination", {})
      current_page = pagination.get("page", None)
      total_pages = pagination.get("total_pages", 0)
      total_count = pagination.get("total_count", 0)

      debug("READ", url, current_page, total_pages, total_count)

      data = r.get("data", [])

      if len(data) == 0:
        break

      self.data += data

      next_page += 1

