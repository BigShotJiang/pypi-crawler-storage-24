#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import json
from anthropic import Anthropic
from sciveo.tools.logger import *
from sciveo.agents.base import LLMClientBase


class AnthropicClient(LLMClientBase):
  """
  Anthropic client using Messages API with native tool support.
  Accepts structured tools list, handles tool_use and text blocks.
  """

  def __init__(self, api_key: str, model: str = "claude-sonnet-4-20250514", max_tokens: int = 4096, temperature: float = 0.2):
    """
    Initialize Anthropic Messages API client.
    """
    self.client = Anthropic(api_key=api_key)
    self.model = model
    self.max_tokens = max_tokens
    self.temperature = temperature

  def chat(self, messages: list[dict], tools=None) -> list[dict]:
    """
    Send messages to Claude with optional tools.
    messages: [{"role": "user|assistant", "content": "..."}]
    tools: [{"name": str, "description": str, "input_schema": dict}, ...]
    Returns: list of blocks [{"type": "text|tool_use", ...}, ...]
    """
    try:
      message_tools = []
      for tn, T in tools.items():
        message_tools.append(T.schema)

      resp = self.client.messages.create(
        model=self.model,
        messages=messages,
        tools=message_tools,
        max_tokens=self.max_tokens,
        temperature=self.temperature
      )

      # resp.content is a list of TextBlock or ToolUseBlock
      blocks = []
      for block in resp.content:
        if block.type == "text":
          try:
            json_blocks = json.loads(block.text)
            for json_block in json_blocks:
              blocks.append({
                "type": json_block["type"],
                "name": json_block["name"],
                "input": json_block["input"]
              })
          except Exception:
            blocks.append({"type": "text", "text": block.text})
        elif block.type == "tool_use":
          blocks.append({
            "type": "tool_use",
            "name": block.name,
            "input": block.input
          })
        else:
          # Fallback: treat unknown blocks as text
          blocks.append({"type": "text", "text": str(block)})

      debug("AnthropicClient blocks", blocks)
      return blocks

    except Exception as e:
      return [{"type": "text", "text": f"[Anthropic error] {e}"}]
