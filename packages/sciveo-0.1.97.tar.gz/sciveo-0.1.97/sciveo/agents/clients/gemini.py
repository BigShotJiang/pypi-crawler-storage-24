#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

from google import genai
from google.genai import types
from sciveo.tools.logger import *
from sciveo.agents.base import LLMClientBase


class GeminiClient(LLMClientBase):
  def __init__(
    self,
    api_key: str,
    model: str = "gemini-2.5-flash",
    temperature: float = 0.2,
    max_output_tokens: int = 4096,
  ):
    """
    Uses the new google-genai SDK.
    """
    # Create the unified GenAI client
    self.client = genai.Client(api_key=api_key)
    self.model = model
    self.temperature = temperature
    self.max_output_tokens = max_output_tokens

  def chat(self, messages: list[dict], tools: list[dict] = None) -> str:
    """
    messages: list of {"role": "user"|"assistant", "content": "..."}
    returns: plain text
    """
    try:
      # Build a single prompt from history
      # (GenAI `generate_content` is stateless, so we combine messages manually)
      prompt = ""
      for m in messages:
        # We treat 'assistant' as plain continuation too
        role = m["role"]
        content = m["content"]
        prompt += f"{role}: {content}\n"

      # Call the GenAI text generation
      response = self.client.models.generate_content(
        model=self.model,
        contents=types.Part.from_text(prompt),
        config=types.GenerateContentConfig(
          temperature=self.temperature,
          max_output_tokens=self.max_output_tokens,
        ),
      )

      # `response.text` contains the full generated output
      text_out = response.text.strip()

      debug("GeminiClient", {"model": self.model, "text": text_out})
      return text_out

    except Exception as e:
      return f"[Gemini error] {e}"
