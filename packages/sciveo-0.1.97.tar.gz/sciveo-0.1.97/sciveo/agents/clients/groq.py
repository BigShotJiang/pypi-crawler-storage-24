#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

from groq import Groq
from sciveo.tools.logger import *
from sciveo.agents.base import LLMClientBase


class GroqClient(LLMClientBase):
  def __init__(self, api_key, model="llama-3.3-70b-versatile", temperature=0.2, max_tokens=4096):
    self.client = Groq(api_key=api_key)
    self.model = model
    self.temperature = temperature
    self.max_tokens = max_tokens

  def chat(self, messages: list[dict], tools: list[dict] = None) -> str:
    try:
      completion = self.client.chat.completions.create(
        model=self.model,
        messages=messages,
        temperature=self.temperature,
        max_tokens=self.max_tokens
      )

      return completion.choices[0].message.content.strip()

    except Exception as e:
      return f"[Groq error] {e}"
