#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import json
from sciveo.tools.logger import *


# =========================
# Agent IR (Anthropic-style)
# =========================

class ToolCall:
  def __init__(self, name: str, input: dict):
    self.name = name
    self.input = input


class AgentBlock:
  def __init__(self, block_type: str, content):
    self.type = block_type      # "text" | "tool_use"
    self.content = content


def parse_agent_blocks(raw_result) -> list:
  """
  Strict JSON-only parser.
  Expected format: Anthropic-style block array.
  """
  try:
    if isinstance(raw_result, str):
      raw = json.loads(raw_result)
    elif isinstance(raw_result, list):
      raw = raw_result
    else:
        raise ValueError(f"Invalid type from LLM: {type(raw_result)}")
  except Exception as e:
    raise ValueError(f"Invalid JSON from LLM: {e}")

  if not isinstance(raw, list):
    raise ValueError("Top-level JSON must be a list")

  blocks = []

  for item in raw:
    if not isinstance(item, dict):
      raise ValueError("Each block must be an object")

    block_type = item.get("type")

    if block_type == "text":
      blocks.append(
        AgentBlock("text", item.get("text", ""))
      )

    elif block_type == "tool_use":
      blocks.append(
        AgentBlock(
          "tool_use",
          ToolCall(
            name=item.get("name"),
            input=item.get("input", {})
          )
        )
      )

    else:
      raise ValueError(f"Unknown block type: {block_type}")

  return blocks


# =========================
# Tools
# =========================

class ToolBase:
  name = ""
  description = ""

  def run(self, args: str, agent):
    raise NotImplementedError


class ToolHelp(ToolBase):
  schema = {
    "name": "help",
    "description": "List available tools",
    "input_schema": {
      "type": "object",
      "properties": {},
      "required": [],
    },
  }

  def run(self, args, agent):
    return "\n".join(
      f"{name}: {tool.schema.description}"
      for name, tool in agent.tools.items()
    )


# =========================
# LLM Client Base
# =========================

class LLMClientBase:
  def chat(self, messages: list[dict], tools=None) -> str:
    """
    Must return a STRING containing ONLY valid JSON
    matching the AgentBlock schema.
    """
    raise NotImplementedError


# =========================
# Agent Base
# =========================

class AgentBase:
  def __init__(self, llm: LLMClientBase):
    self.llm = llm
    self.tools = {}
    self.messages = []
    self.system_prompt = "You are a coding assistant. Use tools to help the user. Be concise and careful!"
    # self.system_prompt = self._build_system_prompt()

  def register_tool(self, tool: ToolBase):
    debug("register_tool", tool.schema)
    self.tools[tool.schema["name"]] = tool

  def call_tool(self, name: str, args):
    debug("TOOL", name, "args", args)
    tool = self.tools.get(name)
    if tool is None:
      return f"[Tool error] Unknown tool: {name}"
    return tool.run(args, self)

  def _build_system_prompt(self) -> str:
    tools_list = "\n".join(
      f"- {t.name}: {t.description}"
      for t in self.tools.values()
    )

    return f"""
          You are a cautious code agent.

          You have access to the following tools:
          {tools_list}

          When responding, output ONLY valid JSON.
          The response MUST be a JSON array of blocks.

          Each block must be one of:

          1) Tool call:
          {{
            "type": "tool_use",
            "name": "<tool_name>",
            "input": {{ "args": "<string>" }}
          }}

          2) Text:
          {{
            "type": "text",
            "text": "<string>"
          }}

          Rules:
          - Use double quotes only
          - No markdown
          - No explanations outside JSON
          - JSON must parse with json.loads()
          """.strip()

  def clear(self):
    self.messages = []

  def loop(self, user_input: str, is_clear=True):
    if is_clear:
      self.clear()

    if len(self.messages) == 0:
      # debug("system_prompt", system_prompt)
      self.messages.append({
        "role": "user",
        "content": self.system_prompt
      })

    self.messages.append({
      "role": "user",
      "content": user_input
    })

    while True:

      response = self.llm.chat(self.messages, self.tools)

      self.messages.append({
        "role": "assistant",
        "content": str(response)
      })

      try:
        blocks = parse_agent_blocks(response)
      except Exception as e:
        exception(e)
        return f"[Agent error] {e}"

      tool_used = False
      final_text = ""

      for block in blocks:
        if block.type == "text":
          final_text = block.content

        elif block.type == "tool_use":
          tool_used = True
          result = self.call_tool(
            block.content.name,
            block.content.input.get("command", "")
          )

          debug("TOOL RESULT", result)

          # Tool results are fed back as plain text
          self.messages.append({
            "role": "user",
            "content": str(result)
          })

      # Stop when model stops calling tools
      if not tool_used:
        return final_text
