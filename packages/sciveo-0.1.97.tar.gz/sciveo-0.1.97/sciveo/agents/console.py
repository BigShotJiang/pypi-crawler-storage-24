#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

from sciveo.tools.logger import *
from sciveo.agents.base import *
from sciveo.agents.tools.os import *


class BaseConsole:
  def __init__(self, agent):
    self.agent = agent

  def run(self):
    print("Sciveo Agent Console (type 'exit' to quit)")
    while True:
      try:
        user_input = input("> ").strip()
        if user_input.lower() in ("exit", "quit"):
          break
        if len(user_input) < 2:
          continue

        output = self.agent.loop(user_input)

        if output:
          info(output)
      except KeyboardInterrupt:
        info("exit")
        break


class TestAgent(AgentBase):
  def __init__(self, llm: LLMClientBase):
    super().__init__(llm)

    self.register_tool(ToolReadFile())
    self.register_tool(ToolWriteFile())
    self.register_tool(ToolPathList())
    self.register_tool(ToolBash())
    self.register_tool(ToolHelp())


if __name__ == "__main__":
  from sciveo.agents.clients.gemini import GeminiClient
  from sciveo.agents.clients.groq import GroqClient
  from sciveo.agents.clients.anthropic import AnthropicClient

  def create_code_agent():
    # llm1 = GeminiClient(api_key=os.getenv("API_KEY_GEMINI"), model="models/gemini-2.5-flash")
    # llm2 = GroqClient(api_key=os.getenv("API_KEY_GROQ"), model="llama-3.1-8b-instant")
    # llm2 = GroqClient(api_key=os.getenv("API_KEY_GROQ"), model="llama-3.3-70b-versatile")
    llm3 = AnthropicClient(api_key=os.getenv("API_KEY_ANTHROPIC"), model="claude-sonnet-4-20250514")
    agent = TestAgent(llm3)

    return agent

  agent = create_code_agent()
  BaseConsole(agent).run()