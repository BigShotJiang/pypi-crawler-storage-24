#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2026
#

import os
import subprocess

from sciveo.tools.logger import *
from sciveo.agents.base import ToolBase


class ToolReadFile(ToolBase):
  schema = {
    "name": "read_file",
    "description": "Read contents of a file",
    "input_schema": {
      "type": "object",
      "properties": {
        "path": { "type": "string", "description": "File path to read" },
      },
      "required": ["path"],
    }
  }

  def run(self, args, agent):
    path = args
    if not os.path.exists(path):
      return f"File not found: {path}"
    try:
      with open(path, "r", encoding="utf-8") as f:
        return f.read()
    except Exception as e:
      return f"Error reading file: {e}"
    return f"FAIL: {args}"


class ToolWriteFile(ToolBase):
  schema = {
    "name": "write_file",
    "description": "Write content to a file",
    "input_schema": {
      "type": "object",
      "properties": {
        "path": { "type": "string", "description": "File path to write" },
        "content": { "type": "string", "description": "Content to write" },
      },
      "required": ["path", "content"],
    }
  }

  def run(self, args, agent):
    path, content = args

    try:
      with open(path, "w", encoding="utf-8") as f:
        f.write(content)
      return f"Written: {path}"
    except Exception as e:
      return f"Error writing file: {e}"


class ToolPathList(ToolBase):
  schema = {
    "name": "list_dir",
    "description": "List directory contents",
    "input_schema": {
      "type": "object",
      "properties": {
        "path": { "type": "string", "description": "Directory path" },
      },
      "required": ["path"],
    },
  }

  def run(self, args, agent):
    path = args
    try:
      return "\n".join(os.listdir(path))
    except Exception as e:
      return f"Error listing directory: {e}"


class ToolBash(ToolBase):
  schema = {
    "name": "bash",
    "description": "Run a shell command",
    "input_schema": {
      "type": "object",
      "properties": {
        "command": { "type": "string", "description": "Command to run" },
      },
      "required": ["command"],
    },
  }

  def run(self, args: str, agent):
    try:
      result = subprocess.run(
        args,
        shell=True,
        capture_output=True,
        text=True
      )
      out = result.stdout.strip()
      err = result.stderr.strip()
      return out if out else err if err else "OK"
    except Exception as e:
      return f"Bash error: {e}"
