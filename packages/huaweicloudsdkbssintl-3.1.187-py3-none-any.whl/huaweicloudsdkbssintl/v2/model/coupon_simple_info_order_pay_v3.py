# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CouponSimpleInfoOrderPayV3:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'type': 'int'
    }

    attribute_map = {
        'id': 'id',
        'type': 'type'
    }

    def __init__(self, id=None, type=None):
        r"""CouponSimpleInfoOrderPayV3

        The model defined in huaweicloud sdk

        :param id: 优惠券ID。
        :type id: str
        :param type: 优惠券类型：300:折扣券 301:促销代金券 302:促销现金券 303:促销储值卡
        :type type: int
        """
        
        

        self._id = None
        self._type = None
        self.discriminator = None

        self.id = id
        self.type = type

    @property
    def id(self):
        r"""Gets the id of this CouponSimpleInfoOrderPayV3.

        优惠券ID。

        :return: The id of this CouponSimpleInfoOrderPayV3.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CouponSimpleInfoOrderPayV3.

        优惠券ID。

        :param id: The id of this CouponSimpleInfoOrderPayV3.
        :type id: str
        """
        self._id = id

    @property
    def type(self):
        r"""Gets the type of this CouponSimpleInfoOrderPayV3.

        优惠券类型：300:折扣券 301:促销代金券 302:促销现金券 303:促销储值卡

        :return: The type of this CouponSimpleInfoOrderPayV3.
        :rtype: int
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this CouponSimpleInfoOrderPayV3.

        优惠券类型：300:折扣券 301:促销代金券 302:促销现金券 303:促销储值卡

        :param type: The type of this CouponSimpleInfoOrderPayV3.
        :type type: int
        """
        self._type = type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CouponSimpleInfoOrderPayV3):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
