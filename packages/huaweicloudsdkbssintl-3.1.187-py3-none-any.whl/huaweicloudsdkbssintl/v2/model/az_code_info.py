# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AzCodeInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'az_code': 'str'
    }

    attribute_map = {
        'az_code': 'az_code'
    }

    def __init__(self, az_code=None):
        r"""AzCodeInfo

        The model defined in huaweicloud sdk

        :param az_code: |参数名称：可用区编码| |参数的约束及描述：该参数非必填，且只允许字符串|
        :type az_code: str
        """
        
        

        self._az_code = None
        self.discriminator = None

        if az_code is not None:
            self.az_code = az_code

    @property
    def az_code(self):
        r"""Gets the az_code of this AzCodeInfo.

        |参数名称：可用区编码| |参数的约束及描述：该参数非必填，且只允许字符串|

        :return: The az_code of this AzCodeInfo.
        :rtype: str
        """
        return self._az_code

    @az_code.setter
    def az_code(self, az_code):
        r"""Sets the az_code of this AzCodeInfo.

        |参数名称：可用区编码| |参数的约束及描述：该参数非必填，且只允许字符串|

        :param az_code: The az_code of this AzCodeInfo.
        :type az_code: str
        """
        self._az_code = az_code

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AzCodeInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
