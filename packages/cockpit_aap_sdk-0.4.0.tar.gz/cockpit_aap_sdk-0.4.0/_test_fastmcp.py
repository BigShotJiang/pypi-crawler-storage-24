"""Quick test to verify FastMCP registration API v3."""
from fastmcp import FastMCP
import asyncio

fmcp = FastMCP("test")

@fmcp.tool(name="test_tool", description="A test tool")
def my_tool(x: str) -> str:
    return f"Hello {x}"

@fmcp.prompt(name="test_prompt", description="A test prompt")
def my_prompt(topic: str) -> str:
    return f"Tell me about {topic}"

@fmcp.resource("test://static", name="test_resource", description="Static", mime_type="text/plain")
def my_resource() -> str:
    return "Hello World"

@fmcp.resource("test://item/{item_id}", name="test_template", description="Template")
def my_template(item_id: str) -> str:
    return f"Item: {item_id}"

async def check():
    tools = await fmcp.list_tools()
    print("Tools:", [t.name for t in tools])
    prompts = await fmcp.list_prompts()
    print("Prompts:", [p.name for p in prompts])
    resources = await fmcp.list_resources()
    print("Resources:", [r.name for r in resources])
    templates = await fmcp.list_resource_templates()
    print("Templates:", [t.name for t in templates])

asyncio.run(check())
print("All good!")
