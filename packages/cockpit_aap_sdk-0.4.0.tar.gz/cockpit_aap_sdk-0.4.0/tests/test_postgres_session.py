"""Tests for PostgresSessionStore — in-memory mock (no Docker required).

Port of the TypeScript tests at
``packages/bootstrap/src/__tests__/postgres-session.test.ts``.
"""

from __future__ import annotations

import pytest
import pytest_asyncio

from cockpit_aap.adapters.postgres_session import create_postgres_session
from helpers.mock_pool import create_mock_pool

TEST_SCHEMA = "test_py_session"


@pytest_asyncio.fixture
async def store():
    pool = create_mock_pool()
    s = create_postgres_session(pool, schema=TEST_SCHEMA)
    await s.setup()
    return s


@pytest.mark.asyncio
async def test_setup_idempotente(store):
    """setup() can be called multiple times safely."""
    await store.setup()
    await store.setup()
    version = await store.schema_version()
    assert version >= 1


@pytest.mark.asyncio
async def test_schema_version(store):
    version = await store.schema_version()
    assert version == 1


@pytest.mark.asyncio
async def test_save_load_roundtrip(store):
    await store.save("py-thread-1", {"count": 99, "name": "test"})
    loaded = await store.load("py-thread-1")
    assert loaded["count"] == 99
    assert loaded["name"] == "test"


@pytest.mark.asyncio
async def test_load_returns_none_for_missing(store):
    result = await store.load("nonexistent-thread-xyz")
    assert result is None


@pytest.mark.asyncio
async def test_save_upsert(store):
    await store.save("py-upsert", {"v": 1})
    await store.save("py-upsert", {"v": 2})
    loaded = await store.load("py-upsert")
    assert loaded["v"] == 2


@pytest.mark.asyncio
async def test_delete(store):
    await store.save("py-delete", {"data": True})
    await store.delete("py-delete")
    assert await store.load("py-delete") is None


@pytest.mark.asyncio
async def test_list_with_prefix(store):
    prefix = "list-py-"
    await store.save(f"{prefix}a", {})
    await store.save(f"{prefix}b", {})
    await store.save("other-py", {})
    filtered = await store.list(prefix)
    assert len([x for x in filtered if x.startswith(prefix)]) == 2


@pytest.mark.asyncio
async def test_prune(store):
    await store.save("prune-py", {"data": True})
    count = await store.prune(-1)
    assert count >= 1
    assert await store.load("prune-py") is None


@pytest.mark.asyncio
async def test_complex_json(store):
    state = {
        "messages": [{"role": "user", "content": "hello"}],
        "profile": {"name": "Alice", "tags": ["dev", "po"]},
    }
    await store.save("py-complex", state)
    loaded = await store.load("py-complex")
    assert loaded == state
