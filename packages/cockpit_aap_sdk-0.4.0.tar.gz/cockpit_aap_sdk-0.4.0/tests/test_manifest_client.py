"""Tests for ManifestClient."""
from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from cockpit_aap.client.manifest_client import ManifestClient

MOCK_MANIFEST: dict[str, Any] = {
    "apiVersion": "cockpit.io/v1",
    "kind": "Module",
    "metadata": {"name": "test-module", "displayName": "Test Module", "version": "1.0.0"},
    "spec": {},
}


def _make_mock_response(data: Any, status_code: int = 200) -> MagicMock:
    """Build a mock httpx.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = data
    resp.raise_for_status = MagicMock()
    return resp


@pytest.mark.asyncio
async def test_get_manifest_fetches_from_server() -> None:
    """get_manifest should fetch from server and return the manifest dict."""
    mock_response = _make_mock_response(MOCK_MANIFEST)

    with patch("cockpit_aap.client.manifest_client.httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        MockClient.return_value = instance
        instance.get = AsyncMock(return_value=mock_response)
        instance.aclose = AsyncMock()

        client = ManifestClient(url="http://localhost:9999")
        result = await client.get_manifest("test-module")
        await client.close()

    assert result["metadata"]["name"] == "test-module"
    assert result["kind"] == "Module"
    instance.get.assert_called_once()


@pytest.mark.asyncio
async def test_get_manifest_caches_within_ttl() -> None:
    """With ttl=60, a second call should return cached result without a new GET."""
    mock_response = _make_mock_response(MOCK_MANIFEST)

    with patch("cockpit_aap.client.manifest_client.httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        MockClient.return_value = instance
        instance.get = AsyncMock(return_value=mock_response)
        instance.aclose = AsyncMock()

        client = ManifestClient(url="http://localhost:9999", ttl=60)
        await client.get_manifest("test-module")
        await client.get_manifest("test-module")
        await client.close()

    assert instance.get.call_count == 1


@pytest.mark.asyncio
async def test_get_manifest_refetches_after_ttl() -> None:
    """With ttl=0, every call should result in a fresh GET."""
    mock_response = _make_mock_response(MOCK_MANIFEST)

    with patch("cockpit_aap.client.manifest_client.httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        MockClient.return_value = instance
        instance.get = AsyncMock(return_value=mock_response)
        instance.aclose = AsyncMock()

        client = ManifestClient(url="http://localhost:9999", ttl=0)
        await client.get_manifest("test-module")
        await client.get_manifest("test-module")
        await client.close()

    assert instance.get.call_count == 2


@pytest.mark.asyncio
async def test_push_manifest() -> None:
    """push_manifest should send a POST request to /{module_id}/push."""
    mock_response = _make_mock_response(None, status_code=200)

    with patch("cockpit_aap.client.manifest_client.httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        MockClient.return_value = instance
        instance.post = AsyncMock(return_value=mock_response)
        instance.aclose = AsyncMock()

        client = ManifestClient(url="http://localhost:9999")
        await client.push_manifest("test-module", MOCK_MANIFEST)
        await client.close()

    instance.post.assert_called_once()
    call_kwargs = instance.post.call_args
    # First positional arg is the URL
    called_url = call_kwargs[0][0] if call_kwargs[0] else call_kwargs[1].get("url", "")
    assert "test-module/push" in called_url


@pytest.mark.asyncio
async def test_invalidate_clears_cache() -> None:
    """After invalidate(), the next get_manifest call should re-fetch from server."""
    mock_response = _make_mock_response(MOCK_MANIFEST)

    with patch("cockpit_aap.client.manifest_client.httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        MockClient.return_value = instance
        instance.get = AsyncMock(return_value=mock_response)
        instance.aclose = AsyncMock()

        client = ManifestClient(url="http://localhost:9999", ttl=60)
        await client.get_manifest("test-module")   # first GET
        client.invalidate("test-module")            # clear cache
        await client.get_manifest("test-module")   # second GET
        await client.close()

    assert instance.get.call_count == 2
