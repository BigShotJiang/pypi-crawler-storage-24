"""Extended tests for Manifest directory scanner -- multi-file paths."""
import os
import json
import tempfile
import pytest
from pathlib import Path
from cockpit_aap.manifest.scanner import scan_manifest
from cockpit_aap.manifest.scanner import (
    _is_file_ref,
    _resolve_ref,
    _read_json_file,
    _find_agent_index,
    _parse_hooks_list,
)

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")
FULL_MULTI = os.path.join(FIXTURES, "full-multi")


# ── Full multi-file scanning ────────────────────────────────────────


class TestFullMultiScan:
    """Tests exercising the comprehensive full-multi fixture."""

    @pytest.fixture(autouse=True)
    def _scan(self):
        self.manifest = scan_manifest(FULL_MULTI)

    def test_module_identity(self):
        assert self.manifest.metadata.name == "full-multi-test"
        assert self.manifest.metadata.version == "2.0.0"
        assert self.manifest.metadata.icon == "🧪"
        assert self.manifest.metadata.group == "testing"

    def test_agent_md_resolution(self):
        """Agent instruction from .md file should be inlined."""
        main = next(a for a in self.manifest.spec.agents if a.id == "main-agent")
        assert "main research assistant" in main.instruction

    def test_agent_yaml_addition(self):
        """Agent defined only in agents/*.yaml should be added."""
        extra = next((a for a in self.manifest.spec.agents if a.id == "extra-agent"), None)
        assert extra is not None
        assert extra.name == "Extra Agent"

    def test_inline_agent_preserved(self):
        """Agent with inline instruction should keep it."""
        helper = next(a for a in self.manifest.spec.agents if a.id == "helper-agent")
        assert helper.instruction == "Inline small instruction"

    def test_total_agents(self):
        assert len(self.manifest.spec.agents) == 3

    def test_i18n_resources(self):
        assert self.manifest.spec.i18n is not None
        en = self.manifest.spec.i18n.locales["en"]
        assert en.resources is not None
        assert en.resources["welcome"] == "Welcome to Full Multi Test"

    def test_i18n_content(self):
        en = self.manifest.spec.i18n.locales["en"]
        assert en.content is not None
        assert en.content["article1"] == "Artigo sobre IA"

    def test_i18n_pt_br(self):
        pt = self.manifest.spec.i18n.locales["pt-BR"]
        assert pt.resources is not None
        assert pt.resources["welcome"] == "Bem-vindo ao Full Multi Test"

    def test_personas_loaded(self):
        assert self.manifest.spec.personas is not None
        assert self.manifest.spec.personas.default_persona == "developer"
        ids = [p.persona_id for p in self.manifest.spec.personas.definitions]
        assert "developer" in ids
        assert "po" in ids
        assert "analyst" in ids

    def test_commands_loaded(self):
        assert self.manifest.spec.commands is not None
        assert len(self.manifest.spec.commands) >= 1
        cmd = next(c for c in self.manifest.spec.commands if c.id == "validate")
        assert cmd.name == "Validate"

    def test_skills_loaded(self):
        assert self.manifest.spec.skills is not None
        skill = next(s for s in self.manifest.spec.skills if s.id == "validate")
        assert "validates manifest" in skill.instruction.lower()

    def test_hooks_loaded(self):
        assert self.manifest.spec.hooks is not None
        assert len(self.manifest.spec.hooks) >= 2
        events = [h.event for h in self.manifest.spec.hooks]
        assert "preBootstrap" in events
        assert "postToolCall" in events

    def test_theme_loaded(self):
        assert self.manifest.spec.theme is not None
        assert self.manifest.spec.theme.default == "light"
        assert "light" in self.manifest.spec.theme.presets
        assert "dark" in self.manifest.spec.theme.presets

    def test_artifacts_preserved(self):
        assert len(self.manifest.spec.artifacts) == 2
        keys = [a.key for a in self.manifest.spec.artifacts]
        assert "config.setting1" in keys
        assert "state.counter" in keys


# ── Helper function tests ────────────────────────────────────────────


class TestIsFileRef:
    def test_recognizes_md_ref(self):
        assert _is_file_ref("agents/main.md") is True

    def test_recognizes_yaml_ref(self):
        assert _is_file_ref("config/settings.yaml") is True

    def test_recognizes_json_ref(self):
        assert _is_file_ref("data/config.json") is True

    def test_rejects_plain_string(self):
        assert _is_file_ref("just some text") is False

    def test_rejects_url(self):
        assert _is_file_ref("https://example.com") is False

    def test_rejects_empty(self):
        assert _is_file_ref("") is False

    def test_rejects_single_word_no_ext(self):
        # String without recognized extension = not a file ref
        assert _is_file_ref("justtext") is False


class TestResolveRef:
    def test_resolves_existing_file(self):
        ref = "agents/main-agent.md"
        result = _resolve_ref(ref, FULL_MULTI)
        assert "main research assistant" in result

    def test_returns_original_for_missing(self):
        ref = "missing/file.md"
        result = _resolve_ref(ref, FULL_MULTI)
        assert result == ref


class TestReadJsonFile:
    def test_reads_valid_json(self):
        path = os.path.join(FULL_MULTI, "i18n", "en", "resources.json")
        data = _read_json_file(path)
        assert data is not None
        assert data["welcome"] == "Welcome to Full Multi Test"

    def test_returns_none_for_missing(self):
        data = _read_json_file("/nonexistent/file.json")
        assert data is None


class TestFindAgentIndex:
    def test_finds_existing(self):
        from cockpit_aap.manifest.types import ManifestAgent
        agents = [
            ManifestAgent(id="a1", name="A1", description="d", instruction="x"),
            ManifestAgent(id="a2", name="A2", description="d", instruction="y"),
        ]
        assert _find_agent_index(agents, "a2") == 1

    def test_returns_neg1_for_missing(self):
        from cockpit_aap.manifest.types import ManifestAgent
        agents = [ManifestAgent(id="a1", name="A1", description="d", instruction="x")]
        assert _find_agent_index(agents, "nonexistent") == -1


class TestParseHooksList:
    def test_parses_list(self):
        raw = [{"id": "h1", "event": "preBootstrap"}]
        result = _parse_hooks_list(raw)
        assert len(result) == 1

    def test_parses_dict_with_hooks_key(self):
        raw = {"hooks": [{"id": "h1", "event": "preBootstrap"}]}
        result = _parse_hooks_list(raw)
        assert len(result) == 1

    def test_returns_empty_for_none(self):
        result = _parse_hooks_list(None)
        assert result == []


# ── Edge case: minimal manifest with no optional sections ────────────


class TestMinimalManifest:
    def test_scan_minimal_single_file(self):
        """Single-file manifest with just module section."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_content = """
apiVersion: cockpit.io/v1
kind: Module
metadata:
  name: minimal-test
  displayName: Minimal
  version: "0.1.0"
  description: A minimal test module
spec: {}
"""
            Path(os.path.join(tmpdir, "manifest.yaml")).write_text(manifest_content)
            manifest = scan_manifest(tmpdir)
            assert manifest.metadata.name == "minimal-test"
            assert manifest.spec.agents is None or len(manifest.spec.agents) == 0

    def test_scan_minimal_multi_file_no_subdirs(self):
        """Multi-file manifest with no subdirectories."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_content = """
apiVersion: cockpit.io/v1
kind: Module
metadata:
  name: minimal-multi
  displayName: Minimal Multi
  version: "0.1.0"
  description: Minimal multi-file test
spec: {}
"""
            Path(os.path.join(tmpdir, "manifest.yaml")).write_text(manifest_content)
            manifest = scan_manifest(tmpdir)
            assert manifest.metadata.name == "minimal-multi"


# ── Edge case: theme.yml variant ─────────────────────────────────────


class TestThemeYml:
    def test_loads_theme_yml(self):
        """theme.yml should be loaded as well as theme.yaml."""
        with tempfile.TemporaryDirectory() as tmpdir:
            Path(os.path.join(tmpdir, "manifest.yaml")).write_text("""
apiVersion: cockpit.io/v1
kind: Module
metadata:
  name: theme-yml-test
  displayName: Theme YML
  version: "1.0.0"
  description: Theme YML test
spec: {}
""")
            Path(os.path.join(tmpdir, "theme.yml")).write_text("""
default: ocean
presets:
  ocean:
    label: Ocean
    colors:
      primary: "#0077be"
""")
            manifest = scan_manifest(tmpdir)
            assert manifest.spec.theme is not None
            assert manifest.spec.theme.default == "ocean"
