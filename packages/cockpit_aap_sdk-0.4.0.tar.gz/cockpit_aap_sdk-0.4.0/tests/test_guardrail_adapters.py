"""Tests for guardrail adapters: LlamaGuard, LlamaFirewall, Composite, Factory."""
import pytest
from cockpit_aap.ports.guardrail import GuardrailContext, GuardrailDecision, GuardrailViolation


# ── LlamaGuardAdapter ──

class TestLlamaGuardAdapter:
    """Test LlamaGuard response parsing (no network calls)."""

    def _make_adapter(self):
        from cockpit_aap.runtime.llamaguard_adapter import LlamaGuardAdapter, LlamaGuardConfig
        config = LlamaGuardConfig(base_url="", api_key="")  # No endpoint = pass-through
        return LlamaGuardAdapter(config)

    def test_parse_safe(self):
        adapter = self._make_adapter()
        decision = adapter._parse_response("safe")
        assert decision.allowed is True
        assert decision.action == "pass"
        assert len(decision.violations) == 0

    def test_parse_unsafe_single_category(self):
        adapter = self._make_adapter()
        decision = adapter._parse_response("unsafe\nS1")
        assert decision.allowed is False
        assert decision.action == "block"
        assert len(decision.violations) == 1
        assert decision.violations[0].rule_id == "llamaguard-s1"
        assert "Violent Crimes" in decision.violations[0].message

    def test_parse_unsafe_multiple_categories(self):
        adapter = self._make_adapter()
        decision = adapter._parse_response("unsafe\nS1,S7,S10")
        assert decision.allowed is False
        assert decision.action == "block"
        assert len(decision.violations) == 3
        categories = {v.rule_id for v in decision.violations}
        assert categories == {"llamaguard-s1", "llamaguard-s7", "llamaguard-s10"}

    def test_parse_unsafe_no_category(self):
        adapter = self._make_adapter()
        decision = adapter._parse_response("unsafe")
        assert decision.allowed is False
        assert decision.action == "block"
        assert len(decision.violations) == 1
        assert decision.violations[0].rule_id == "llamaguard-unsafe"

    def test_parse_empty(self):
        adapter = self._make_adapter()
        decision = adapter._parse_response("")
        assert decision.allowed is True

    def test_parse_unknown_format(self):
        adapter = self._make_adapter()
        decision = adapter._parse_response("I'm not sure what you mean")
        assert decision.allowed is True

    def test_warn_categories(self):
        from cockpit_aap.runtime.llamaguard_adapter import LlamaGuardAdapter, LlamaGuardConfig
        config = LlamaGuardConfig(base_url="", api_key="", warn_categories=["S6"])
        adapter = LlamaGuardAdapter(config)
        decision = adapter._parse_response("unsafe\nS6")
        assert decision.allowed is True
        assert decision.action == "warn"
        assert decision.violations[0].severity == "warn"

    @pytest.mark.asyncio
    async def test_passthrough_no_endpoint(self):
        adapter = self._make_adapter()
        ctx = GuardrailContext(agent_id="test", input="hello")
        decision = await adapter.evaluate_input(ctx)
        assert decision.allowed is True
        assert decision.action == "pass"

    @pytest.mark.asyncio
    async def test_empty_input(self):
        adapter = self._make_adapter()
        ctx = GuardrailContext(agent_id="test", input="")
        decision = await adapter.evaluate_input(ctx)
        assert decision.allowed is True


# ── CompositeGuardrailAdapter ──

class TestCompositeGuardrailAdapter:
    """Test composite guardrail chaining logic."""

    @pytest.mark.asyncio
    async def test_all_pass(self):
        from cockpit_aap.runtime.composite_guardrail import CompositeGuardrailAdapter

        class PassAdapter:
            async def evaluate_input(self, ctx):
                return GuardrailDecision(allowed=True, action="pass", violations=[])
            async def evaluate_output(self, ctx):
                return GuardrailDecision(allowed=True, action="pass", violations=[])

        composite = CompositeGuardrailAdapter([PassAdapter(), PassAdapter()])
        ctx = GuardrailContext(agent_id="test", input="hello")
        decision = await composite.evaluate_input(ctx)
        assert decision.allowed is True
        assert decision.action == "pass"

    @pytest.mark.asyncio
    async def test_first_block_wins(self):
        from cockpit_aap.runtime.composite_guardrail import CompositeGuardrailAdapter

        class BlockAdapter:
            async def evaluate_input(self, ctx):
                return GuardrailDecision(
                    allowed=False, action="block",
                    violations=[GuardrailViolation(rule_id="test-block", category="test", message="blocked", severity="block")]
                )
            async def evaluate_output(self, ctx):
                return GuardrailDecision(allowed=True, action="pass", violations=[])

        class NeverReachedAdapter:
            async def evaluate_input(self, ctx):
                raise RuntimeError("Should not be called")
            async def evaluate_output(self, ctx):
                raise RuntimeError("Should not be called")

        composite = CompositeGuardrailAdapter([BlockAdapter(), NeverReachedAdapter()])
        ctx = GuardrailContext(agent_id="test", input="bad stuff")
        decision = await composite.evaluate_input(ctx)
        assert decision.allowed is False
        assert decision.action == "block"
        assert len(decision.violations) == 1

    @pytest.mark.asyncio
    async def test_warnings_collected(self):
        from cockpit_aap.runtime.composite_guardrail import CompositeGuardrailAdapter

        class WarnAdapter:
            def __init__(self, rule_id):
                self.rule_id = rule_id
            async def evaluate_input(self, ctx):
                return GuardrailDecision(
                    allowed=True, action="warn",
                    violations=[GuardrailViolation(rule_id=self.rule_id, category="test", message="warn", severity="warn")]
                )
            async def evaluate_output(self, ctx):
                return GuardrailDecision(allowed=True, action="pass", violations=[])

        composite = CompositeGuardrailAdapter([WarnAdapter("a"), WarnAdapter("b")])
        ctx = GuardrailContext(agent_id="test", input="hmm")
        decision = await composite.evaluate_input(ctx)
        assert decision.allowed is True
        assert decision.action == "warn"
        assert len(decision.violations) == 2

    @pytest.mark.asyncio
    async def test_adapter_error_skipped(self):
        from cockpit_aap.runtime.composite_guardrail import CompositeGuardrailAdapter

        class BrokenAdapter:
            async def evaluate_input(self, ctx):
                raise RuntimeError("boom")
            async def evaluate_output(self, ctx):
                raise RuntimeError("boom")

        class PassAdapter:
            async def evaluate_input(self, ctx):
                return GuardrailDecision(allowed=True, action="pass", violations=[])
            async def evaluate_output(self, ctx):
                return GuardrailDecision(allowed=True, action="pass", violations=[])

        composite = CompositeGuardrailAdapter([BrokenAdapter(), PassAdapter()])
        ctx = GuardrailContext(agent_id="test", input="hello")
        decision = await composite.evaluate_input(ctx)
        assert decision.allowed is True

    @pytest.mark.asyncio
    async def test_empty_adapters(self):
        from cockpit_aap.runtime.composite_guardrail import CompositeGuardrailAdapter
        composite = CompositeGuardrailAdapter([])
        ctx = GuardrailContext(agent_id="test", input="hello")
        decision = await composite.evaluate_input(ctx)
        assert decision.allowed is True


# ── GuardrailFactory ──

class TestGuardrailFactory:
    """Test manifest-driven guardrail factory."""

    def test_no_guardrails_returns_regex(self):
        from cockpit_aap.runtime.guardrail_factory import create_guardrail_from_manifest
        from cockpit_aap.runtime.regex_guardrail import RegexGuardrailAdapter

        manifest = {"spec": {}}
        composite = create_guardrail_from_manifest(manifest)
        assert len(composite.adapters) == 1
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)

    def test_regex_only(self):
        from cockpit_aap.runtime.guardrail_factory import create_guardrail_from_manifest
        from cockpit_aap.runtime.regex_guardrail import RegexGuardrailAdapter

        manifest = {
            "spec": {
                "guardrails": {
                    "input": [
                        {"id": "pii", "adapter": "regex"},
                    ]
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        assert len(composite.adapters) == 1
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)

    def test_regex_plus_llamaguard(self):
        from cockpit_aap.runtime.guardrail_factory import create_guardrail_from_manifest
        from cockpit_aap.runtime.regex_guardrail import RegexGuardrailAdapter
        from cockpit_aap.runtime.llamaguard_adapter import LlamaGuardAdapter

        manifest = {
            "spec": {
                "guardrails": {
                    "input": [
                        {"id": "pii", "adapter": "regex"},
                        {"id": "safety", "adapter": "llamaguard"},
                    ]
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        assert len(composite.adapters) == 2
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)
        assert isinstance(composite.adapters[1], LlamaGuardAdapter)

    def test_deduplication(self):
        """Same adapter type in input and output should only be instantiated once."""
        from cockpit_aap.runtime.guardrail_factory import create_guardrail_from_manifest
        from cockpit_aap.runtime.regex_guardrail import RegexGuardrailAdapter

        manifest = {
            "spec": {
                "guardrails": {
                    "input": [{"id": "a", "adapter": "regex"}],
                    "output": [{"id": "b", "adapter": "regex"}],
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        assert len(composite.adapters) == 1
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)

    def test_unknown_adapter_ignored(self):
        from cockpit_aap.runtime.guardrail_factory import create_guardrail_from_manifest
        from cockpit_aap.runtime.regex_guardrail import RegexGuardrailAdapter

        manifest = {
            "spec": {
                "guardrails": {
                    "input": [
                        {"id": "pii", "adapter": "regex"},
                        {"id": "custom", "adapter": "nonexistent-adapter"},
                    ]
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        # Should have regex, nonexistent adapter silently ignored
        assert any(isinstance(a, RegexGuardrailAdapter) for a in composite.adapters)


# ── OpenAIModerationAdapter ──

class TestOpenAIModerationAdapter:
    """Test OpenAI Moderation adapter (no network calls)."""

    @pytest.mark.asyncio
    async def test_passthrough_no_api_key(self):
        """Without API key, adapter passes through."""
        from cockpit_aap.runtime.openai_moderation_adapter import OpenAIModerationAdapter, OpenAIModerationConfig
        config = OpenAIModerationConfig(api_key="")
        adapter = OpenAIModerationAdapter(config)
        ctx = GuardrailContext(agent_id="test", input="hello")
        decision = await adapter.evaluate_input(ctx)
        assert decision.allowed is True
        assert decision.action == "pass"

    @pytest.mark.asyncio
    async def test_empty_input(self):
        from cockpit_aap.runtime.openai_moderation_adapter import OpenAIModerationAdapter, OpenAIModerationConfig
        config = OpenAIModerationConfig(api_key="")
        adapter = OpenAIModerationAdapter(config)
        ctx = GuardrailContext(agent_id="test", input="")
        decision = await adapter.evaluate_input(ctx)
        assert decision.allowed is True

    def test_factory_creates_openai_moderation(self):
        from cockpit_aap.runtime.guardrail_factory import create_guardrail_from_manifest
        from cockpit_aap.runtime.regex_guardrail import RegexGuardrailAdapter
        from cockpit_aap.runtime.openai_moderation_adapter import OpenAIModerationAdapter

        manifest = {
            "spec": {
                "guardrails": {
                    "input": [
                        {"id": "pii", "adapter": "regex"},
                        {"id": "safety", "adapter": "openai-moderation"},
                    ]
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        assert len(composite.adapters) == 2
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)
        assert isinstance(composite.adapters[1], OpenAIModerationAdapter)
