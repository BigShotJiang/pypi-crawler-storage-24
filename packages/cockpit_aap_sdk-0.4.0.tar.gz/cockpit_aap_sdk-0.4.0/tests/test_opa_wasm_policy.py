"""Tests for OPA WASM policy adapter.

Covers:
- OpaWasmPolicyAdapter instantiation and state
- _extract_violations with various result shapes
- _opa_build failure handling
- Full flow via mocking (since Python _opa_build is missing -e entrypoint)
"""
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyInput, PolicySource

has_opa = shutil.which("opa") is not None


# ---------------------------------------------------------------------------
# _extract_violations (pure function, no OPA needed)
# ---------------------------------------------------------------------------


class TestExtractViolations:
    """Test the _extract_violations helper with various result shapes."""

    def test_empty_list_returns_empty(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        assert _extract_violations([]) == []

    def test_non_list_returns_empty(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        assert _extract_violations(None) == []
        assert _extract_violations("string") == []
        assert _extract_violations(42) == []

    def test_extracts_violations_from_final_violations_key(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [
            {
                "aap.conformance.test": {
                    "final_violations": [
                        {"rule": "name-required", "severity": "error", "message": "name missing"},
                        {"rule": "desc-recommended", "severity": "warning", "message": "desc missing"},
                    ]
                }
            }
        ]
        violations = _extract_violations(result)
        assert len(violations) == 2
        assert violations[0]["rule"] == "name-required"
        assert violations[0]["severity"] == "error"
        assert violations[0]["policy"] == "aap.conformance.test"
        assert violations[1]["rule"] == "desc-recommended"

    def test_extracts_violations_from_violation_key(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [
            {
                "aap.conformance.test": {
                    "violation": [
                        {"rule": "r1", "severity": "error", "message": "fail"},
                    ]
                }
            }
        ]
        violations = _extract_violations(result)
        assert len(violations) == 1
        assert violations[0]["rule"] == "r1"

    def test_handles_multiple_packages(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [
            {
                "pkg_a": {
                    "final_violations": [
                        {"rule": "r1", "severity": "error", "message": "m1"},
                    ]
                },
                "pkg_b": {
                    "final_violations": [
                        {"rule": "r2", "severity": "warning", "message": "m2"},
                    ]
                },
            }
        ]
        violations = _extract_violations(result)
        assert len(violations) == 2
        assert {v["policy"] for v in violations} == {"pkg_a", "pkg_b"}

    def test_skips_non_dict_entries(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = ["not-a-dict", 42, None]
        assert _extract_violations(result) == []

    def test_skips_non_dict_package_data(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [{"pkg": "not-a-dict"}]
        assert _extract_violations(result) == []

    def test_skips_non_dict_violations(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [{"pkg": {"final_violations": ["not-a-dict", 42]}}]
        assert _extract_violations(result) == []

    def test_handles_empty_violations_list(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [{"pkg": {"final_violations": []}}]
        assert _extract_violations(result) == []

    def test_prefers_final_violations_over_violation(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [
            {
                "pkg": {
                    "final_violations": [
                        {"rule": "from-final", "severity": "error", "message": "m"},
                    ],
                    "violation": [
                        {"rule": "from-violation", "severity": "error", "message": "m"},
                    ],
                }
            }
        ]
        violations = _extract_violations(result)
        # final_violations takes precedence due to `or` short-circuit
        assert len(violations) == 1
        assert violations[0]["rule"] == "from-final"

    def test_handles_multiple_entries_in_result_list(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [
            {"pkg_a": {"final_violations": [{"rule": "r1", "severity": "error", "message": "m1"}]}},
            {"pkg_b": {"violation": [{"rule": "r2", "severity": "warning", "message": "m2"}]}},
        ]
        violations = _extract_violations(result)
        assert len(violations) == 2

    def test_adds_policy_field_to_violations(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [{"my_policy": {"final_violations": [{"rule": "r1"}]}}]
        violations = _extract_violations(result)
        assert violations[0]["policy"] == "my_policy"
        # Original fields preserved plus policy added
        assert violations[0]["rule"] == "r1"

    def test_handles_no_violations_keys(self):
        from cockpit_aap.adapters.opa_wasm_policy import _extract_violations
        result = [{"pkg": {"other_data": {"some": "value"}}}]
        assert _extract_violations(result) == []


# ---------------------------------------------------------------------------
# _opa_build
# ---------------------------------------------------------------------------


class TestOpaBuild:
    """Test _opa_build helper."""

    @pytest.mark.skipif(not has_opa, reason="opa CLI not installed")
    def test_raises_without_entrypoint(self, tmp_path):
        """The Python adapter's _opa_build does not pass -e entrypoint,
        so opa build --target wasm always fails. This verifies the error path."""
        from cockpit_aap.adapters.opa_wasm_policy import _opa_build
        rego = "package aap.test\nimport rego.v1\nallow if { true }\n"
        (tmp_path / "test.rego").write_text(rego)
        output = tmp_path / "bundle.tar.gz"
        with pytest.raises(RuntimeError, match="opa build failed"):
            _opa_build(str(tmp_path), str(output))

    @pytest.mark.skipif(not has_opa, reason="opa CLI not installed")
    def test_raises_on_invalid_rego(self, tmp_path):
        from cockpit_aap.adapters.opa_wasm_policy import _opa_build
        (tmp_path / "bad.rego").write_text("this is not valid rego!!!")
        output = tmp_path / "bundle.tar.gz"
        with pytest.raises(RuntimeError, match="opa build failed"):
            _opa_build(str(tmp_path), str(output))

    def test_raises_when_opa_not_found(self, tmp_path):
        """Verify error handling by patching subprocess.run."""
        from cockpit_aap.adapters.opa_wasm_policy import _opa_build

        rego = "package aap.test\nimport rego.v1\nallow if { true }\n"
        (tmp_path / "test.rego").write_text(rego)
        output = tmp_path / "bundle.tar.gz"

        with patch("cockpit_aap.adapters.opa_wasm_policy.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=1, stderr="command not found")
            with pytest.raises(RuntimeError, match="opa build failed"):
                _opa_build(str(tmp_path), str(output))

    def test_success_path_via_mock(self, tmp_path):
        """Verify _opa_build does not raise when returncode is 0."""
        from cockpit_aap.adapters.opa_wasm_policy import _opa_build

        with patch("cockpit_aap.adapters.opa_wasm_policy.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stderr="")
            # Should not raise
            _opa_build(str(tmp_path), str(tmp_path / "out.tar.gz"))
            mock_run.assert_called_once()


# ---------------------------------------------------------------------------
# OpaWasmPolicyAdapter — class-level tests (no OPA needed)
# ---------------------------------------------------------------------------


class TestOpaWasmPolicyAdapterNoOpa:
    """Tests that don't require OPA CLI."""

    def test_init_state(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
        adapter = OpaWasmPolicyAdapter()
        assert adapter.is_ready() is False
        assert adapter._policy is None
        assert adapter._tmp_dir is None

    @pytest.mark.asyncio
    async def test_load_empty_sources_sets_ready(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
        adapter = OpaWasmPolicyAdapter()
        await adapter.load_policies([])
        assert adapter.is_ready() is True

    @pytest.mark.asyncio
    async def test_evaluate_returns_default_when_no_policy(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
        adapter = OpaWasmPolicyAdapter()
        result = await adapter.evaluate(PolicyInput(manifest={"metadata": {"name": "test"}}))
        assert isinstance(result, PolicyDecision)
        assert result.passed is True
        assert result.violations == []

    def test_cleanup_no_tmp_dir(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
        adapter = OpaWasmPolicyAdapter()
        # Should not raise
        adapter.cleanup()
        assert adapter._tmp_dir is None

    def test_cleanup_removes_tmp_dir(self, tmp_path):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
        adapter = OpaWasmPolicyAdapter()
        # Create a temp dir to simulate build output
        test_dir = tmp_path / "opa-tmp"
        test_dir.mkdir()
        adapter._tmp_dir = str(test_dir)
        adapter.cleanup()
        assert adapter._tmp_dir is None
        # The directory should have been cleaned up
        assert not test_dir.exists()

    @pytest.mark.asyncio
    async def test_load_policies_raises_on_opa_wasm_missing(self):
        """Test that load_policies raises when opa-wasm package is not installed."""
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter

        adapter = OpaWasmPolicyAdapter()

        # Mock _opa_build to succeed but opa_wasm import to fail
        with patch("cockpit_aap.adapters.opa_wasm_policy._opa_build"):
            with patch.dict("sys.modules", {"opa_wasm": None}):
                with pytest.raises((RuntimeError, ImportError)):
                    await adapter.load_policies([
                        PolicySource(type="rego", id="test",
                                     content="package aap.test\nimport rego.v1\nallow if { true }\n")
                    ])

    @pytest.mark.asyncio
    async def test_load_policies_cleans_up_on_failure(self):
        """Test that tmp dir is cleaned up when load_policies fails."""
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter

        adapter = OpaWasmPolicyAdapter()

        with patch("cockpit_aap.adapters.opa_wasm_policy._opa_build", side_effect=RuntimeError("build failed")):
            with pytest.raises(RuntimeError):
                await adapter.load_policies([
                    PolicySource(type="rego", id="test",
                                 content="package aap.test\nimport rego.v1\nallow if { true }\n")
                ])
        # tmp_dir should be cleaned up after failure
        assert adapter._tmp_dir is None


# ---------------------------------------------------------------------------
# OpaWasmPolicyAdapter — full flow via mocking
# ---------------------------------------------------------------------------


class TestOpaWasmPolicyAdapterMocked:
    """Integration tests using mocked OPA WASM to avoid dependency on opa-wasm package."""

    @pytest.mark.asyncio
    async def test_full_evaluation_with_violations_mocked(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter

        adapter = OpaWasmPolicyAdapter()

        # Mock the opa build and opa-wasm import
        mock_policy = MagicMock()
        mock_policy.evaluate.return_value = [
            {
                "aap.conformance.test_policy": {
                    "final_violations": [
                        {"rule": "name-required", "severity": "error", "message": "missing name"},
                    ]
                }
            }
        ]

        mock_opa_module = MagicMock()
        mock_opa_module.OpaPolicy.return_value = mock_policy

        with patch("cockpit_aap.adapters.opa_wasm_policy._opa_build"):
            with patch.dict("sys.modules", {"opa_wasm": mock_opa_module}):
                await adapter.load_policies([
                    PolicySource(
                        type="rego", id="test-policy",
                        content="package aap.conformance.test_policy\nimport rego.v1\n"
                    )
                ])

        assert adapter.is_ready()

        result = await adapter.evaluate(PolicyInput(manifest={"metadata": {}}))
        assert result.passed is False
        assert len(result.violations) > 0
        assert result.violations[0].rule == "name-required"

    @pytest.mark.asyncio
    async def test_full_evaluation_no_violations_mocked(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter

        adapter = OpaWasmPolicyAdapter()

        mock_policy = MagicMock()
        mock_policy.evaluate.return_value = [
            {"aap.conformance.test_policy": {"final_violations": []}}
        ]

        mock_opa_module = MagicMock()
        mock_opa_module.OpaPolicy.return_value = mock_policy

        with patch("cockpit_aap.adapters.opa_wasm_policy._opa_build"):
            with patch.dict("sys.modules", {"opa_wasm": mock_opa_module}):
                await adapter.load_policies([
                    PolicySource(
                        type="rego", id="test-policy",
                        content="package aap.conformance.test_policy\nimport rego.v1\n"
                    )
                ])

        result = await adapter.evaluate(
            PolicyInput(manifest={"metadata": {"name": "my-module"}})
        )
        assert result.passed is True
        assert len(result.violations) == 0
        assert result.grade == "A"

    @pytest.mark.asyncio
    async def test_evaluate_passes_context_to_policy(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter

        adapter = OpaWasmPolicyAdapter()

        mock_policy = MagicMock()
        mock_policy.evaluate.return_value = []

        mock_opa_module = MagicMock()
        mock_opa_module.OpaPolicy.return_value = mock_policy

        with patch("cockpit_aap.adapters.opa_wasm_policy._opa_build"):
            with patch.dict("sys.modules", {"opa_wasm": mock_opa_module}):
                await adapter.load_policies([
                    PolicySource(
                        type="rego", id="test",
                        content="package aap.test\nimport rego.v1\n"
                    )
                ])

        await adapter.evaluate(
            PolicyInput(
                manifest={"metadata": {"name": "test"}},
                context={"env": "production"},
            )
        )

        # Verify the policy was called with the correct input
        call_args = mock_policy.evaluate.call_args
        input_str = call_args[0][0]
        input_data = json.loads(input_str)
        assert input_data["manifest"]["metadata"]["name"] == "test"
        assert input_data["context"]["env"] == "production"

    @pytest.mark.asyncio
    async def test_evaluate_with_multiple_severity_violations(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter

        adapter = OpaWasmPolicyAdapter()

        mock_policy = MagicMock()
        mock_policy.evaluate.return_value = [
            {
                "aap.conformance.multi": {
                    "final_violations": [
                        {"rule": "r1", "severity": "error", "message": "error msg"},
                        {"rule": "r2", "severity": "warning", "message": "warning msg"},
                        {"rule": "r3", "severity": "info", "message": "info msg"},
                    ]
                }
            }
        ]

        mock_opa_module = MagicMock()
        mock_opa_module.OpaPolicy.return_value = mock_policy

        with patch("cockpit_aap.adapters.opa_wasm_policy._opa_build"):
            with patch.dict("sys.modules", {"opa_wasm": mock_opa_module}):
                await adapter.load_policies([
                    PolicySource(
                        type="rego", id="multi",
                        content="package aap.conformance.multi\nimport rego.v1\n"
                    )
                ])

        result = await adapter.evaluate(PolicyInput(manifest={"metadata": {}}))
        assert result.passed is False  # has error severity
        assert len(result.violations) == 3
        assert result.max_score > 0
        assert result.percentage == 0  # all violations fired

    @pytest.mark.asyncio
    async def test_evaluate_default_context_is_empty_dict(self):
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter

        adapter = OpaWasmPolicyAdapter()

        mock_policy = MagicMock()
        mock_policy.evaluate.return_value = []

        mock_opa_module = MagicMock()
        mock_opa_module.OpaPolicy.return_value = mock_policy

        with patch("cockpit_aap.adapters.opa_wasm_policy._opa_build"):
            with patch.dict("sys.modules", {"opa_wasm": mock_opa_module}):
                await adapter.load_policies([
                    PolicySource(type="rego", id="t", content="package aap.t\nimport rego.v1\n")
                ])

        await adapter.evaluate(PolicyInput(manifest={"metadata": {}}))

        input_data = json.loads(mock_policy.evaluate.call_args[0][0])
        assert input_data["context"] == {}

    @pytest.mark.asyncio
    async def test_file_naming_sanitization(self):
        """Verify that special characters in policy IDs are sanitized for filenames."""
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter

        adapter = OpaWasmPolicyAdapter()

        mock_opa_module = MagicMock()
        mock_opa_module.OpaPolicy.return_value = MagicMock()

        written_files = []

        def capture_opa_build(input_dir, output_path):
            # Capture written files to verify naming
            import os
            for f in os.listdir(input_dir):
                if f.endswith(".rego"):
                    written_files.append(f)

        with patch("cockpit_aap.adapters.opa_wasm_policy._opa_build", side_effect=capture_opa_build):
            with patch.dict("sys.modules", {"opa_wasm": mock_opa_module}):
                await adapter.load_policies([
                    PolicySource(
                        type="rego",
                        id="my-org/policy.v2",
                        content="package aap.test\nimport rego.v1\n"
                    )
                ])

        assert len(written_files) == 1
        # Special chars should be replaced with _
        assert "/" not in written_files[0]
        assert "." not in written_files[0].replace(".rego", "")
