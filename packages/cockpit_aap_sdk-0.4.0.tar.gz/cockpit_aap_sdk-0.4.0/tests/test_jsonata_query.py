"""Test JSONata CLI adapter — skips if Node.js not available."""
import pytest
import shutil

has_npx = shutil.which("npx") is not None

@pytest.mark.asyncio
@pytest.mark.skipif(not has_npx, reason="npx not available")
async def test_simple_expression():
    from cockpit_aap.adapters.jsonata_query import JsonataCliQueryAdapter
    adapter = JsonataCliQueryAdapter()
    result = await adapter.evaluate("name", {"name": "test"})
    assert result == "test"
