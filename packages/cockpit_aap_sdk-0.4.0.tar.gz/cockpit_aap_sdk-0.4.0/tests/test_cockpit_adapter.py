"""Tests for CockpitAdapter — wraps SDK as ManifestStorePort."""

import pytest
from cockpit_aap.adapters.cockpit_adapter import CockpitAdapter, create_cockpit_adapter


class _FakeNamespace:
    """Simulates a namespace proxy."""

    async def get_artifact(self, **kwargs):
        return {"content": {"artifacts": [{"id": "a1", "key": "k", "value": "v"}]}}

    async def create_artifact(self, **kwargs):
        return {"content": {"id": "a2"}}


class _FakeSdk:
    def __init__(self):
        self.artifacts = _FakeNamespace()
        self.agents = _FakeNamespace()


class TestCockpitAdapter:
    def test_factory(self):
        sdk = _FakeSdk()
        adapter = create_cockpit_adapter(sdk)
        assert isinstance(adapter, CockpitAdapter)

    def test_artifacts_proxy(self):
        sdk = _FakeSdk()
        adapter = create_cockpit_adapter(sdk)
        assert adapter.artifacts is sdk.artifacts

    def test_agents_proxy(self):
        sdk = _FakeSdk()
        adapter = create_cockpit_adapter(sdk)
        assert adapter.agents is sdk.agents

    @pytest.mark.asyncio
    async def test_call_through(self):
        sdk = _FakeSdk()
        adapter = create_cockpit_adapter(sdk)
        result = await adapter.artifacts.get_artifact(key_pattern="^test$")
        assert result["content"]["artifacts"][0]["id"] == "a1"
