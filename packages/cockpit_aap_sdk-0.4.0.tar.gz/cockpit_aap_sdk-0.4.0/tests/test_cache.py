"""Tests for cockpit_aap.cache — BootstrapCache."""

import time
from cockpit_aap.cache import BootstrapCache, global_cache


def test_set_and_get():
    cache = BootstrapCache()
    cache.set("mod-a", {"result": 1})
    assert cache.get("mod-a") == {"result": 1}


def test_get_missing():
    cache = BootstrapCache()
    assert cache.get("nonexistent") is None


def test_has():
    cache = BootstrapCache()
    assert cache.has("x") is False
    cache.set("x", "val")
    assert cache.has("x") is True


def test_invalidate_single():
    cache = BootstrapCache()
    cache.set("a", 1)
    cache.set("b", 2)
    cache.invalidate("a")
    assert cache.get("a") is None
    assert cache.get("b") == 2


def test_invalidate_all():
    cache = BootstrapCache()
    cache.set("a", 1)
    cache.set("b", 2)
    cache.invalidate()
    assert cache.size == 0


def test_ttl_expiration():
    cache = BootstrapCache(default_ttl_ms=1)  # 1ms TTL
    cache.set("fast", "value")
    # Wait just a bit so monotonic clock advances
    time.sleep(0.01)
    assert cache.get("fast") is None


def test_custom_ttl():
    cache = BootstrapCache(default_ttl_ms=1)
    cache.set("long", "val", ttl_ms=60_000)  # Override with 60s
    assert cache.get("long") == "val"


def test_zero_ttl_skips():
    cache = BootstrapCache()
    cache.set("skip", "val", ttl_ms=0)
    assert cache.get("skip") is None


def test_negative_ttl_skips():
    cache = BootstrapCache()
    cache.set("neg", "val", ttl_ms=-1)
    assert cache.get("neg") is None


def test_size():
    cache = BootstrapCache()
    assert cache.size == 0
    cache.set("a", 1)
    cache.set("b", 2)
    assert cache.size == 2


def test_global_cache_is_singleton():
    assert isinstance(global_cache, BootstrapCache)
