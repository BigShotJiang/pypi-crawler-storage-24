"""Tests for per-kind dedicated scanners.

Validates that:
1. All 34 non-Module kinds have a registered scan_fn (not just parse_fn)
2. scan_fn validates apiVersion and kind strictly
3. File ref fields are resolved correctly
4. JSON ref fields are resolved correctly
5. Validators run (e.g., SDLC phases non_empty_array)
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

import pytest
import yaml

from cockpit_aap.manifest.kind_registry import kind_registry
from cockpit_aap.manifest.scanners._definitions import BUILTIN_KIND_DEFINITIONS


# ── Registration tests ────────────────────────────────────────────────────────


class TestKindRegistration:
    """All 34 non-Module kinds should have a dedicated scan_fn."""

    def test_all_kinds_registered(self):
        """Every definition in BUILTIN_KIND_DEFINITIONS should be registered."""
        for defn in BUILTIN_KIND_DEFINITIONS:
            kind_name = defn["kind"]
            assert kind_registry.is_registered(kind_name), f"{kind_name} not registered"

    def test_all_kinds_have_scan_fn(self):
        """Every registered kind should have a scan_fn (not relying on fallback)."""
        for defn in BUILTIN_KIND_DEFINITIONS:
            kind_name = defn["kind"]
            entry = kind_registry._entries.get(kind_name)
            assert entry is not None, f"{kind_name} not in registry"
            assert entry.scan_fn is not None, (
                f"{kind_name} has no scan_fn — should use _make_scan_fn"
            )

    def test_module_kind_registered_separately(self):
        """Module kind is registered by kind_registry.py, not _definitions."""
        assert kind_registry.is_registered("Module")
        entry = kind_registry._entries["Module"]
        assert entry.api_version == "cockpit.io/v1"

    def test_scan_fn_names_follow_convention(self):
        """scan_fn names should follow scan_<kind>_manifest convention."""
        for defn in BUILTIN_KIND_DEFINITIONS:
            kind_name = defn["kind"]
            entry = kind_registry._entries.get(kind_name)
            if entry and entry.scan_fn:
                expected = f"scan_{kind_name.lower()}_manifest"
                assert entry.scan_fn.__name__ == expected, (
                    f"{kind_name}: expected scan_fn name '{expected}', "
                    f"got '{entry.scan_fn.__name__}'"
                )


# ── Helper to create temp manifest dirs ──────────────────────────────────────


def _make_manifest_dir(manifest_data: dict[str, Any], extra_files: dict[str, str] | None = None) -> str:
    """Create a temp directory with manifest.yaml and optional extra files."""
    tmpdir = tempfile.mkdtemp()
    manifest_path = os.path.join(tmpdir, "manifest.yaml")
    with open(manifest_path, "w", encoding="utf-8") as f:
        yaml.dump(manifest_data, f, default_flow_style=False)
    if extra_files:
        for name, content in extra_files.items():
            filepath = os.path.join(tmpdir, name)
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            Path(filepath).write_text(content, encoding="utf-8")
    return tmpdir


# ── apiVersion / kind validation tests ────────────────────────────────────────


class TestApiVersionValidation:
    """scan_fn should strictly validate apiVersion and kind."""

    def test_agent_correct_api_version(self):
        d = _make_manifest_dir({
            "apiVersion": "agents.md/v1",
            "kind": "Agent",
            "metadata": {"name": "test-agent"},
            "spec": {"instruction": "Hello"},
        })
        result = kind_registry.scan(d)
        assert result["kind"] == "Agent"
        assert result["apiVersion"] == "agents.md/v1"

    def test_agent_wrong_api_version_raises(self):
        d = _make_manifest_dir({
            "apiVersion": "WRONG/v1",
            "kind": "Agent",
            "metadata": {"name": "test-agent"},
            "spec": {"instruction": "Hello"},
        })
        with pytest.raises(ValueError, match="apiVersion mismatch"):
            kind_registry.scan(d)

    def test_soul_wrong_kind_raises(self):
        d = _make_manifest_dir({
            "apiVersion": "soul.md/v1",
            "kind": "WrongKind",
            "metadata": {"name": "test"},
            "spec": {},
        })
        with pytest.raises(ValueError):
            kind_registry.scan(d)

    @pytest.mark.parametrize("kind,api_version", [
        ("Agent", "agents.md/v1"),
        ("Soul", "soul.md/v1"),
        ("Skill", "agentskills.io/v1"),
        ("MCPTool", "modelcontextprotocol.io/v1"),
        ("MCPServer", "modelcontextprotocol.io/v1"),
        ("Memory", "mif-spec.dev/v1"),
        ("Persona", "soulspec.org/v1"),
        ("Prompt", "prompty.ai/v1"),
        ("Blueprint", "planning.cockpit.io/v1"),
        ("Lens", "cockpit.io/v1"),
        ("SDLC", "sdlc.io/v1"),
        ("Policy", "governance.cockpit.io/v1"),
        ("Pipeline", "cockpit.io/v1"),
        ("KindDescriptor", "registry.cockpit.io/v1"),
    ])
    def test_kind_accepts_correct_api_version(self, kind: str, api_version: str):
        extra = {}
        if kind == "SDLC":
            extra = {"spec": {"phases": [{"id": "dev"}]}}
        d = _make_manifest_dir({
            "apiVersion": api_version,
            "kind": kind,
            "metadata": {"name": "test"},
            "spec": {"instruction": "test", **extra.get("spec", {})},
        })
        result = kind_registry.scan(d)
        assert result["kind"] == kind


# ── File ref resolution tests ─────────────────────────────────────────────────


class TestFileRefResolution:
    """File ref fields should be resolved by the scan_fn."""

    def test_agent_resolves_instruction(self):
        d = _make_manifest_dir(
            {
                "apiVersion": "agents.md/v1",
                "kind": "Agent",
                "metadata": {"name": "test-agent"},
                "spec": {"instruction": "instructions.md"},
            },
            extra_files={"instructions.md": "# Agent Instructions\nYou are a test agent."},
        )
        result = kind_registry.scan(d)
        assert "# Agent Instructions" in result["spec"]["instruction"]

    def test_soul_resolves_instruction(self):
        d = _make_manifest_dir(
            {
                "apiVersion": "soul.md/v1",
                "kind": "Soul",
                "metadata": {"name": "test-soul"},
                "spec": {"instruction": "soul.md"},
            },
            extra_files={"soul.md": "You have a calm and professional demeanor."},
        )
        result = kind_registry.scan(d)
        assert "calm and professional" in result["spec"]["instruction"]

    def test_persona_resolves_soul_and_identity(self):
        d = _make_manifest_dir(
            {
                "apiVersion": "soulspec.org/v1",
                "kind": "Persona",
                "metadata": {"name": "test-persona"},
                "spec": {
                    "soul": "soul-content.md",
                    "identity": "identity-content.md",
                },
            },
            extra_files={
                "soul-content.md": "Calm and measured.",
                "identity-content.md": "I am a governance analyst.",
            },
        )
        result = kind_registry.scan(d)
        assert "Calm and measured" in result["spec"]["soul"]
        assert "governance analyst" in result["spec"]["identity"]

    def test_lens_resolves_body(self):
        d = _make_manifest_dir(
            {
                "apiVersion": "cockpit.io/v1",
                "kind": "Lens",
                "metadata": {"name": "test-lens"},
                "spec": {"body": "template.html", "mode": "table"},
            },
            extra_files={"template.html": "<table>{{#each items}}<tr><td>{{name}}</td></tr>{{/each}}</table>"},
        )
        result = kind_registry.scan(d)
        assert "{{#each items}}" in result["spec"]["body"]

    def test_blueprint_resolves_planfile(self):
        d = _make_manifest_dir(
            {
                "apiVersion": "planning.cockpit.io/v1",
                "kind": "Blueprint",
                "metadata": {"name": "test-bp"},
                "spec": {"planFile": "plan.md"},
            },
            extra_files={"plan.md": "# Implementation Plan\n1. Phase 1\n2. Phase 2"},
        )
        result = kind_registry.scan(d)
        assert "Implementation Plan" in result["spec"]["planFile"]

    def test_mcp_tool_resolves_instruction(self):
        d = _make_manifest_dir(
            {
                "apiVersion": "modelcontextprotocol.io/v1",
                "kind": "MCPTool",
                "metadata": {"name": "test-tool"},
                "spec": {"instruction": "tool-instruction.md"},
            },
            extra_files={"tool-instruction.md": "This tool validates manifests."},
        )
        result = kind_registry.scan(d)
        assert "validates manifests" in result["spec"]["instruction"]

    def test_nonexistent_file_ref_preserved(self):
        """If a file ref path doesn't exist, the original value is preserved."""
        d = _make_manifest_dir({
            "apiVersion": "agents.md/v1",
            "kind": "Agent",
            "metadata": {"name": "test"},
            "spec": {"instruction": "nonexistent.md"},
        })
        result = kind_registry.scan(d)
        assert result["spec"]["instruction"] == "nonexistent.md"

    def test_inline_instruction_not_resolved(self):
        """Inline text (not a file path) should not be treated as a file ref."""
        d = _make_manifest_dir({
            "apiVersion": "agents.md/v1",
            "kind": "Agent",
            "metadata": {"name": "test"},
            "spec": {"instruction": "You are a helpful assistant.\nBe concise."},
        })
        result = kind_registry.scan(d)
        assert result["spec"]["instruction"] == "You are a helpful assistant.\nBe concise."


# ── JSON ref resolution tests ─────────────────────────────────────────────────


class TestJsonRefResolution:
    """JSON ref fields should be resolved and re-serialised."""

    def test_skill_resolves_evals_file(self):
        evals_data = {"metrics": ["accuracy", "relevance"], "threshold": 0.85}
        d = _make_manifest_dir(
            {
                "apiVersion": "agentskills.io/v1",
                "kind": "Skill",
                "metadata": {"name": "test-skill"},
                "spec": {
                    "instruction": "Test instruction",
                    "evals": {"file": "evals.json"},
                },
            },
            extra_files={"evals.json": json.dumps(evals_data, indent=2)},
        )
        result = kind_registry.scan(d)
        # Should be re-serialised as compact JSON
        resolved = result["spec"]["evals"]["file"]
        parsed = json.loads(resolved)
        assert parsed["metrics"] == ["accuracy", "relevance"]
        assert parsed["threshold"] == 0.85

    def test_skill_resolves_iteration_benchmarks(self):
        benchmark = {"passRate": 0.95, "samples": 100}
        d = _make_manifest_dir(
            {
                "apiVersion": "agentskills.io/v1",
                "kind": "Skill",
                "metadata": {"name": "test-skill"},
                "spec": {
                    "instruction": "inline instruction",
                    "evals": {
                        "iterations": [
                            {"id": "v1", "benchmark": "benchmark-v1.json"},
                            {"id": "v2", "benchmark": "benchmark-v2.json"},
                        ],
                    },
                },
            },
            extra_files={
                "benchmark-v1.json": json.dumps(benchmark),
                "benchmark-v2.json": json.dumps({"passRate": 0.98, "samples": 200}),
            },
        )
        result = kind_registry.scan(d)
        iters = result["spec"]["evals"]["iterations"]
        parsed_v1 = json.loads(iters[0]["benchmark"])
        assert parsed_v1["passRate"] == 0.95
        parsed_v2 = json.loads(iters[1]["benchmark"])
        assert parsed_v2["passRate"] == 0.98

    def test_skill_resolves_example_output_refs(self):
        d = _make_manifest_dir(
            {
                "apiVersion": "agentskills.io/v1",
                "kind": "Skill",
                "metadata": {"name": "test-skill"},
                "spec": {
                    "instruction": "inline",
                    "examples": [
                        {"input": "test input", "outputRef": "output1.md"},
                        {"input": "test input 2", "outputRef": "output2.md"},
                    ],
                },
            },
            extra_files={
                "output1.md": "Expected output 1",
                "output2.md": "Expected output 2",
            },
        )
        result = kind_registry.scan(d)
        examples = result["spec"]["examples"]
        assert examples[0]["outputRef"] == "Expected output 1"
        assert examples[1]["outputRef"] == "Expected output 2"


# ── Validator tests ───────────────────────────────────────────────────────────


class TestValidators:
    """Business-rule validators should reject invalid manifests."""

    def test_sdlc_requires_non_empty_phases(self):
        d = _make_manifest_dir({
            "apiVersion": "sdlc.io/v1",
            "kind": "SDLC",
            "metadata": {"name": "test-sdlc"},
            "spec": {"phases": []},
        })
        with pytest.raises(ValueError, match="non-empty array"):
            kind_registry.scan(d)

    def test_sdlc_missing_phases_raises(self):
        d = _make_manifest_dir({
            "apiVersion": "sdlc.io/v1",
            "kind": "SDLC",
            "metadata": {"name": "test-sdlc"},
            "spec": {},
        })
        with pytest.raises(ValueError, match="non-empty array"):
            kind_registry.scan(d)

    def test_sdlc_valid_phases_passes(self):
        d = _make_manifest_dir({
            "apiVersion": "sdlc.io/v1",
            "kind": "SDLC",
            "metadata": {"name": "test-sdlc"},
            "spec": {
                "phases": [
                    {"id": "design", "displayName": "Design"},
                    {"id": "develop", "displayName": "Develop"},
                ],
            },
        })
        result = kind_registry.scan(d)
        assert len(result["spec"]["phases"]) == 2


# ── parse_fn tests ────────────────────────────────────────────────────────────


class TestParseFn:
    """Kinds with has_parse=True should have a working parse_fn."""

    @pytest.mark.parametrize("kind,api_version", [
        ("AuditTrail", "governance.cockpit.io/v1"),
        ("Blueprint", "planning.cockpit.io/v1"),
        ("Certificate", "governance.cockpit.io/v1"),
        ("CodeQuality", "governance.cockpit.io/v1"),
        ("Compliance", "governance.cockpit.io/v1"),
        ("ConformancePolicy", "governance.cockpit.io/v1"),
        ("DataContract", "datacontract.com/v3.0.0"),
        ("Experiment", "cockpit.io/v1"),
        ("KindDescriptor", "registry.cockpit.io/v1"),
        ("Lifecycle", "lifecycle.io/v1"),
        ("ManifestPolicy", "governance.cockpit.io/v1"),
        ("Metric", "observability.cockpit.io/v1"),
        ("ModelCard", "ml.cockpit.io/v1"),
        ("Package", "code.cockpit.io/v1"),
        ("Policy", "governance.cockpit.io/v1"),
        ("RiskProfile", "governance.cockpit.io/v1"),
        ("SDLC", "sdlc.io/v1"),
        ("SecurityScan", "governance.cockpit.io/v1"),
        ("TelemetryBlueprint", "observability.cockpit.io/v1"),
        ("TestReport", "governance.cockpit.io/v1"),
        ("ValueStream", "governance.cockpit.io/v1"),
    ])
    def test_parse_fn_exists_and_works(self, kind: str, api_version: str):
        entry = kind_registry._entries[kind]
        assert entry.parse_fn is not None, f"{kind} should have parse_fn"

        yaml_content = yaml.dump({
            "apiVersion": api_version,
            "kind": kind,
            "metadata": {"name": f"test-{kind.lower()}"},
            "spec": {},
        })
        result = entry.parse_fn(yaml_content)
        assert result["kind"] == kind
        assert result["apiVersion"] == api_version

    @pytest.mark.parametrize("kind", [
        "Agent", "AgentCard", "Guardrail", "MCPServer", "MCPTool",
        "Memory", "Persona", "Pipeline", "Prompt", "Skill", "Soul", "Task",
    ])
    def test_no_parse_fn_for_scan_only_kinds(self, kind: str):
        entry = kind_registry._entries[kind]
        assert entry.parse_fn is None, f"{kind} should NOT have parse_fn"


# ── Regression: sample manifests should scan successfully ─────────────────────


class TestSampleManifests:
    """Sample data from definitions should pass through scan_fn."""

    @pytest.mark.parametrize("defn", BUILTIN_KIND_DEFINITIONS, ids=[d["kind"] for d in BUILTIN_KIND_DEFINITIONS])
    def test_scan_sample_manifest(self, defn: dict[str, Any]):
        sample = defn.get("sample")
        if sample is None:
            pytest.skip(f"{defn['kind']} has no sample data")

        d = _make_manifest_dir(sample)
        # Some samples may not have file refs — scan should still work
        try:
            result = kind_registry.scan(d)
            assert result["kind"] == defn["kind"]
        except ValueError as e:
            # SDLC sample has phases, should pass. Others might fail on strict validation.
            if "non-empty array" in str(e):
                pytest.fail(f"{defn['kind']} sample failed validation: {e}")
            # apiVersion/kind mismatch in sample data is a data bug
            if "mismatch" in str(e):
                pytest.fail(f"{defn['kind']} sample has data bug: {e}")
            raise


# ── Summary ───────────────────────────────────────────────────────────────────


class TestScannerSummary:
    """Summary stats for visibility."""

    def test_print_summary(self):
        kinds_with_scan = 0
        kinds_with_parse = 0
        kinds_with_file_refs = 0
        kinds_with_json_refs = 0
        kinds_with_validators = 0

        for defn in BUILTIN_KIND_DEFINITIONS:
            entry = kind_registry._entries.get(defn["kind"])
            if entry:
                if entry.scan_fn:
                    kinds_with_scan += 1
                if entry.parse_fn:
                    kinds_with_parse += 1
            if defn.get("file_ref_fields"):
                kinds_with_file_refs += 1
            if defn.get("json_ref_fields"):
                kinds_with_json_refs += 1
            if defn.get("validators"):
                kinds_with_validators += 1

        print(f"\n=== Per-Kind Scanner Summary ===")
        print(f"  Total kinds:         {len(BUILTIN_KIND_DEFINITIONS)}")
        print(f"  With scan_fn:        {kinds_with_scan}")
        print(f"  With parse_fn:       {kinds_with_parse}")
        print(f"  With file_ref_fields: {kinds_with_file_refs}")
        print(f"  With json_ref_fields: {kinds_with_json_refs}")
        print(f"  With validators:     {kinds_with_validators}")
        assert kinds_with_scan == len(BUILTIN_KIND_DEFINITIONS)
