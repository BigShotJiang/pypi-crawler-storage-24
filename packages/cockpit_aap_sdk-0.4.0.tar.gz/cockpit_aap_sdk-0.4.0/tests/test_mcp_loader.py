"""
Tests for cockpit_aap.mcp_loader — Python MCP Loader.

Tests cover:
- Type parsing (MCPServerManifest, tools, prompts, resources)
- Template engine (Jinja2 + simple fallback)
- Handler resolver (convention, explicit, per-language)
- Tool registration (code, template, expression)
- Prompt registration
- Resource registration (static + templates)
- Full load_manifest_server integration
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── Type imports ─────────────────────────────────────────────────────────────

from cockpit_aap.mcp_loader.types import (
    MCPServerManifest,
    MCPServerSpec,
    MCPServerToolDeclaration,
    MCPServerCodeHandler,
    MCPServerTemplateHandler,
    MCPServerExpressionHandler,
    MCPServerPromptDeclaration,
    MCPServerPromptArgument,
    MCPServerResourceDeclaration,
    MCPServerResourceTemplateDeclaration,
    MCPServerJsonSchema,
    MCPServerJsonSchemaProperty,
    LoadOptions,
    LoadResult,
    LoadedToolEntry,
    LoadedPromptEntry,
    LoadedResourceEntry,
    LoadErrorEntry,
)


# ═══════════════════════════════════════════════════════════════════════════════
# 1. TYPE PARSING TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestMCPServerTypes:
    """Tests for MCPServer type dataclasses and from_dict parsing."""

    def test_json_schema_property_from_dict(self) -> None:
        data = {
            "type": "string",
            "description": "A name",
            "enum": ["a", "b"],
            "minLength": 1,
            "maxLength": 100,
        }
        prop = MCPServerJsonSchemaProperty.from_dict(data)
        assert prop.type == "string"
        assert prop.description == "A name"
        assert prop.enum == ["a", "b"]
        assert prop.min_length == 1
        assert prop.max_length == 100

    def test_json_schema_property_nested(self) -> None:
        data = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["name"],
        }
        prop = MCPServerJsonSchemaProperty.from_dict(data)
        assert prop.type == "object"
        assert prop.properties is not None
        assert "name" in prop.properties
        assert prop.properties["tags"].items is not None
        assert prop.properties["tags"].items.type == "string"

    def test_json_schema_from_dict(self) -> None:
        data = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        schema = MCPServerJsonSchema.from_dict(data)
        assert schema.type == "object"
        assert schema.properties is not None
        assert schema.required == ["name"]

    def test_code_handler_from_dict(self) -> None:
        data = {"type": "code", "module": "tools/scan", "py": "tools/scan.py"}
        handler = MCPServerCodeHandler.from_dict(data)
        assert handler.type == "code"
        assert handler.module == "tools/scan"
        assert handler.py == "tools/scan.py"

    def test_template_handler_from_dict(self) -> None:
        data = {"type": "template", "template": "Hello, {{ name }}!"}
        handler = MCPServerTemplateHandler.from_dict(data)
        assert handler.type == "template"
        assert handler.template == "Hello, {{ name }}!"

    def test_expression_handler_from_dict(self) -> None:
        data = {"type": "expression", "expr": "input['a'] + input['b']"}
        handler = MCPServerExpressionHandler.from_dict(data)
        assert handler.type == "expression"
        assert handler.expr == "input['a'] + input['b']"

    def test_tool_declaration_from_dict(self) -> None:
        data = {
            "name": "scan-compliance",
            "description": "Scan for compliance",
            "title": "Compliance Scanner",
            "inputSchema": {
                "type": "object",
                "properties": {"module": {"type": "string"}},
                "required": ["module"],
            },
            "handler": {"type": "code", "py": "scan_compliance.py"},
        }
        decl = MCPServerToolDeclaration.from_dict(data)
        assert decl.name == "scan-compliance"
        assert decl.description == "Scan for compliance"
        assert decl.title == "Compliance Scanner"
        assert decl.input_schema is not None
        assert isinstance(decl.handler, MCPServerCodeHandler)
        assert decl.handler.py == "scan_compliance.py"

    def test_tool_declaration_template_handler(self) -> None:
        data = {
            "name": "greet",
            "description": "Greet user",
            "handler": {"type": "template", "template": "Hi, {{ name }}!"},
        }
        decl = MCPServerToolDeclaration.from_dict(data)
        assert isinstance(decl.handler, MCPServerTemplateHandler)
        assert decl.handler.template == "Hi, {{ name }}!"

    def test_tool_declaration_expression_handler(self) -> None:
        data = {
            "name": "add",
            "description": "Add numbers",
            "handler": {"type": "expression", "expr": "a + b"},
        }
        decl = MCPServerToolDeclaration.from_dict(data)
        assert isinstance(decl.handler, MCPServerExpressionHandler)
        assert decl.handler.expr == "a + b"

    def test_prompt_declaration_from_dict(self) -> None:
        data = {
            "name": "review-code",
            "description": "Review code for issues",
            "arguments": [
                {"name": "code", "description": "The code to review", "required": True},
                {"name": "language", "description": "Programming language"},
            ],
            "template": "Review this {{ language }} code:\n{{ code }}",
        }
        decl = MCPServerPromptDeclaration.from_dict(data)
        assert decl.name == "review-code"
        assert decl.arguments is not None
        assert len(decl.arguments) == 2
        assert decl.arguments[0].required is True
        assert decl.template is not None

    def test_resource_declaration_from_dict(self) -> None:
        data = {
            "name": "compliance-rules",
            "uri": "file:///rules/compliance.json",
            "description": "Compliance rules",
            "mimeType": "application/json",
            "content": '{"rules": []}',
        }
        decl = MCPServerResourceDeclaration.from_dict(data)
        assert decl.name == "compliance-rules"
        assert decl.uri == "file:///rules/compliance.json"
        assert decl.mime_type == "application/json"
        assert decl.content == '{"rules": []}'

    def test_resource_template_declaration_from_dict(self) -> None:
        data = {
            "name": "module-report",
            "uriTemplate": "report:///{module_id}",
            "description": "Module report",
            "mimeType": "text/markdown",
            "template": "# Report for {{ module_id }}",
        }
        decl = MCPServerResourceTemplateDeclaration.from_dict(data)
        assert decl.name == "module-report"
        assert decl.uri_template == "report:///{module_id}"
        assert decl.template == "# Report for {{ module_id }}"

    def test_mcpserver_spec_from_dict(self) -> None:
        data = {
            "transport": "streamable-http",
            "endpoint": "http://localhost:3000",
            "auth": "bearer",
            "tools": [
                {
                    "name": "greet",
                    "description": "Greet",
                    "handler": {"type": "template", "template": "Hello!"},
                }
            ],
            "prompts": [
                {"name": "review", "description": "Review", "template": "Review: {{ code }}"}
            ],
            "resources": [
                {"name": "rules", "uri": "file:///rules.json", "content": "{}"}
            ],
            "resourceTemplates": [
                {
                    "name": "report",
                    "uriTemplate": "report:///{id}",
                    "template": "Report {{ id }}",
                }
            ],
        }
        spec = MCPServerSpec.from_dict(data)
        assert spec.transport == "streamable-http"
        assert spec.tools is not None and len(spec.tools) == 1
        assert spec.prompts is not None and len(spec.prompts) == 1
        assert spec.resources is not None and len(spec.resources) == 1
        assert spec.resource_templates is not None and len(spec.resource_templates) == 1

    def test_mcpserver_manifest_from_dict(self) -> None:
        data = {
            "apiVersion": "modelcontextprotocol.io/v1",
            "kind": "MCPServer",
            "metadata": {
                "name": "my-server",
                "displayName": "My Server",
                "version": "1.0.0",
            },
            "spec": {
                "transport": "streamable-http",
                "endpoint": "http://localhost:3000",
                "auth": "none",
            },
        }
        manifest = MCPServerManifest.from_dict(data)
        assert manifest.api_version == "modelcontextprotocol.io/v1"
        assert manifest.kind == "MCPServer"
        assert manifest.metadata.name == "my-server"
        assert manifest.metadata.display_name == "My Server"
        assert manifest.spec.transport == "streamable-http"


# ═══════════════════════════════════════════════════════════════════════════════
# 2. TEMPLATE ENGINE TESTS
# ═══════════════════════════════════════════════════════════════════════════════


def _jinja2_available() -> bool:
    try:
        import jinja2  # noqa: F401
        return True
    except ImportError:
        return False


_skip_no_jinja2 = pytest.mark.skipif(
    not _jinja2_available(),
    reason="jinja2 not installed (optional mcp extra)",
)


class TestTemplateEngine:
    """Tests for the Jinja2-based template engine."""

    def test_simple_render(self) -> None:
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        engine = create_template_engine()
        compiled = engine.compile("Hello, {{ name }}!")
        result = compiled.render({"name": "World"})
        assert result == "Hello, World!"

    def test_multiple_vars(self) -> None:
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        engine = create_template_engine()
        compiled = engine.compile("{{ greeting }}, {{ name }}!")
        result = compiled.render({"greeting": "Hi", "name": "Alice"})
        assert result == "Hi, Alice!"

    @_skip_no_jinja2
    def test_builtin_filter_json(self) -> None:
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        engine = create_template_engine()
        compiled = engine.compile("{{ data | json }}")
        result = compiled.render({"data": {"key": "value"}})
        parsed = json.loads(result)
        assert parsed == {"key": "value"}

    @_skip_no_jinja2
    def test_builtin_filter_kebab_case(self) -> None:
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        engine = create_template_engine()
        compiled = engine.compile("{{ name | kebab_case }}")
        result = compiled.render({"name": "myToolName"})
        assert result == "my-tool-name"

    @_skip_no_jinja2
    def test_builtin_filter_camel_case(self) -> None:
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        engine = create_template_engine()
        compiled = engine.compile("{{ name | camel_case }}")
        result = compiled.render({"name": "my-tool-name"})
        assert result == "myToolName"

    @_skip_no_jinja2
    def test_custom_helpers(self) -> None:
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        engine = create_template_engine(
            helpers={"shout": lambda v: str(v).upper() + "!!!"}
        )
        compiled = engine.compile("{{ name | shout }}")
        result = compiled.render({"name": "hello"})
        assert result == "HELLO!!!"

    def test_context_providers(self) -> None:
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        engine = create_template_engine(
            context_providers={"user": lambda inp: "admin"}
        )
        compiled = engine.compile("User: {{ user }}")
        result = compiled.render({})
        assert result == "User: admin"

    @_skip_no_jinja2
    def test_now_global(self) -> None:
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        engine = create_template_engine()
        compiled = engine.compile("{{ now() }}")
        result = compiled.render({})
        # Should be an ISO timestamp
        assert "T" in result and len(result) > 10


# ═══════════════════════════════════════════════════════════════════════════════
# 3. HANDLER RESOLVER TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestHandlerResolver:
    """Tests for code handler resolution."""

    def test_convention_resolution(self, tmp_path: Path) -> None:
        """Resolve by convention: tool name → snake_case.py."""
        handler_file = tmp_path / "greet_user.py"
        handler_file.write_text(
            "async def handler(input):\n    return f\"Hello, {input['name']}!\"\n"
        )

        from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

        handler = MCPServerCodeHandler(type="code")
        fn = asyncio.get_event_loop().run_until_complete(
            resolve_code_handler(handler, "greet_user", str(tmp_path))
        )
        assert callable(fn)

    def test_explicit_py_resolution(self, tmp_path: Path) -> None:
        """Resolve by explicit py field."""
        handler_file = tmp_path / "my_handler.py"
        handler_file.write_text("def handler(input):\n    return 'ok'\n")

        from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

        handler = MCPServerCodeHandler(type="code", py="my_handler.py")
        fn = asyncio.get_event_loop().run_until_complete(
            resolve_code_handler(handler, "some-tool", str(tmp_path))
        )
        assert callable(fn)

    def test_explicit_module_resolution(self, tmp_path: Path) -> None:
        """Resolve by explicit module field."""
        handler_file = tmp_path / "custom_module.py"
        handler_file.write_text("def handler(input):\n    return 42\n")

        from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

        handler = MCPServerCodeHandler(type="code", module="custom_module")
        fn = asyncio.get_event_loop().run_until_complete(
            resolve_code_handler(handler, "some-tool", str(tmp_path))
        )
        assert callable(fn)

    def test_kebab_case_resolution(self, tmp_path: Path) -> None:
        """Resolve kebab-case tool name → kebab-case file."""
        handler_file = tmp_path / "scan-compliance.py"
        handler_file.write_text("def handler(input):\n    return 'scanned'\n")

        from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

        handler = MCPServerCodeHandler(type="code")
        fn = asyncio.get_event_loop().run_until_complete(
            resolve_code_handler(handler, "scan-compliance", str(tmp_path))
        )
        assert callable(fn)

    def test_not_found_raises(self, tmp_path: Path) -> None:
        """Should raise FileNotFoundError when no module found."""
        from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

        handler = MCPServerCodeHandler(type="code")
        with pytest.raises(FileNotFoundError, match="Cannot resolve"):
            asyncio.get_event_loop().run_until_complete(
                resolve_code_handler(handler, "nonexistent", str(tmp_path))
            )

    def test_no_handler_export_raises(self, tmp_path: Path) -> None:
        """Should raise AttributeError when module has no handler function."""
        handler_file = tmp_path / "bad_module.py"
        handler_file.write_text("MY_CONSTANT = 42\n")

        from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

        handler = MCPServerCodeHandler(type="code", module="bad_module")
        with pytest.raises(AttributeError, match="does not export a handler"):
            asyncio.get_event_loop().run_until_complete(
                resolve_code_handler(handler, "bad-tool", str(tmp_path))
            )

    def test_default_export(self, tmp_path: Path) -> None:
        """Should resolve 'default' named export."""
        handler_file = tmp_path / "with_default.py"
        handler_file.write_text("def default(input):\n    return 'default!'\n")

        from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

        handler = MCPServerCodeHandler(type="code", module="with_default")
        fn = asyncio.get_event_loop().run_until_complete(
            resolve_code_handler(handler, "some-tool", str(tmp_path))
        )
        assert callable(fn)
        result = fn({})
        assert result == "default!"

    def test_tool_name_export(self, tmp_path: Path) -> None:
        """Should resolve function matching tool name."""
        handler_file = tmp_path / "check_health.py"
        handler_file.write_text("def check_health(input):\n    return 'healthy'\n")

        from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

        handler = MCPServerCodeHandler(type="code")
        fn = asyncio.get_event_loop().run_until_complete(
            resolve_code_handler(handler, "check_health", str(tmp_path))
        )
        assert fn({}) == "healthy"


# ═══════════════════════════════════════════════════════════════════════════════
# 4. TOOL REGISTRATION TESTS (with FastMCP mock)
# ═══════════════════════════════════════════════════════════════════════════════


def _create_mock_fmcp() -> MagicMock:
    """Create a mock FastMCP instance that captures registrations."""
    fmcp = MagicMock()

    # Track tool registrations
    fmcp._registered_tools: Dict[str, Any] = {}
    fmcp._registered_prompts: Dict[str, Any] = {}
    fmcp._registered_resources: Dict[str, Any] = {}

    def _mock_tool(name: str, description: str = "") -> Any:
        def decorator(fn: Any) -> Any:
            fmcp._registered_tools[name] = {"fn": fn, "description": description}
            return fn
        return decorator

    def _mock_prompt(name: str, description: str = "") -> Any:
        def decorator(fn: Any) -> Any:
            fmcp._registered_prompts[name] = {"fn": fn, "description": description}
            return fn
        return decorator

    def _mock_resource(uri: str, name: str = "", description: str = "", mime_type: str = "text/plain") -> Any:
        def decorator(fn: Any) -> Any:
            fmcp._registered_resources[name or uri] = {
                "fn": fn, "uri": uri, "description": description, "mime_type": mime_type,
            }
            return fn
        return decorator

    fmcp.tool = _mock_tool
    fmcp.prompt = _mock_prompt
    fmcp.resource = _mock_resource

    return fmcp


class TestToolLoader:
    """Tests for tool loading on FastMCP."""

    @pytest.mark.asyncio
    async def test_load_template_tool(self) -> None:
        from cockpit_aap.mcp_loader.tool_loader import load_tools
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        tools = [
            MCPServerToolDeclaration(
                name="greet",
                description="Greet user",
                handler=MCPServerTemplateHandler(
                    type="template", template="Hello, {{ name }}!"
                ),
            )
        ]

        result = await load_tools(fmcp, tools, "/tmp", engine)
        assert len(result.loaded) == 1
        assert result.loaded[0].name == "greet"
        assert result.loaded[0].type == "template"
        assert "greet" in fmcp._registered_tools

    @pytest.mark.asyncio
    async def test_load_expression_tool(self) -> None:
        from cockpit_aap.mcp_loader.tool_loader import load_tools
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        tools = [
            MCPServerToolDeclaration(
                name="add",
                description="Add numbers",
                handler=MCPServerExpressionHandler(
                    type="expression", expr="a + b"
                ),
            )
        ]

        result = await load_tools(fmcp, tools, "/tmp", engine)
        assert len(result.loaded) == 1
        assert result.loaded[0].name == "add"
        assert result.loaded[0].type == "expression"

    @pytest.mark.asyncio
    async def test_load_code_tool(self, tmp_path: Path) -> None:
        from cockpit_aap.mcp_loader.tool_loader import load_tools
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        # Create handler file
        handler_file = tmp_path / "greet.py"
        handler_file.write_text(
            "def handler(input):\n    return f\"Hello, {input.get('name', 'World')}!\"\n"
        )

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        tools = [
            MCPServerToolDeclaration(
                name="greet",
                description="Greet user",
                handler=MCPServerCodeHandler(type="code"),
            )
        ]

        result = await load_tools(fmcp, tools, str(tmp_path), engine)
        assert len(result.loaded) == 1
        assert result.loaded[0].type == "code"

    @pytest.mark.asyncio
    async def test_load_tool_error(self) -> None:
        from cockpit_aap.mcp_loader.tool_loader import load_tools
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        tools = [
            MCPServerToolDeclaration(
                name="bad-tool",
                description="Missing handler",
                handler=MCPServerTemplateHandler(
                    type="template", template=None  # Missing template!
                ),
            )
        ]

        result = await load_tools(fmcp, tools, "/tmp", engine)
        assert len(result.errors) == 1
        assert result.errors[0].name == "bad-tool"
        assert result.errors[0].kind == "tool"

    @pytest.mark.asyncio
    async def test_load_tool_callbacks(self) -> None:
        from cockpit_aap.mcp_loader.tool_loader import load_tools
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()
        registered: list[tuple[str, str]] = []

        tools = [
            MCPServerToolDeclaration(
                name="greet",
                description="Greet",
                handler=MCPServerTemplateHandler(
                    type="template", template="Hello!"
                ),
            )
        ]

        result = await load_tools(
            fmcp, tools, "/tmp", engine,
            callbacks={"on_registered": lambda n, t: registered.append((n, t))},
        )
        assert len(registered) == 1
        assert registered[0] == ("greet", "template")

    @pytest.mark.asyncio
    async def test_template_tool_renders_correctly(self) -> None:
        from cockpit_aap.mcp_loader.tool_loader import load_tools
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        tools = [
            MCPServerToolDeclaration(
                name="greet",
                description="Greet user",
                handler=MCPServerTemplateHandler(
                    type="template", template="Hello, {{ name }}!"
                ),
            )
        ]

        await load_tools(fmcp, tools, "/tmp", engine)
        # Call the registered handler and verify output
        tool_fn = fmcp._registered_tools["greet"]["fn"]
        result = await tool_fn(name="Alice")
        assert result == "Hello, Alice!"

    @pytest.mark.asyncio
    async def test_expression_tool_evaluates_correctly(self) -> None:
        from cockpit_aap.mcp_loader.tool_loader import load_tools
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        tools = [
            MCPServerToolDeclaration(
                name="add",
                description="Add",
                handler=MCPServerExpressionHandler(
                    type="expression", expr="a + b"
                ),
            )
        ]

        await load_tools(fmcp, tools, "/tmp", engine)
        tool_fn = fmcp._registered_tools["add"]["fn"]
        result = await tool_fn(a=3, b=5)
        # simpleeval returns number, converted to json string
        assert "8" in str(result)


# ═══════════════════════════════════════════════════════════════════════════════
# 5. PROMPT REGISTRATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestPromptLoader:
    """Tests for prompt loading on FastMCP."""

    def test_load_prompt_with_template(self) -> None:
        from cockpit_aap.mcp_loader.prompt_loader import load_prompts
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        prompts = [
            MCPServerPromptDeclaration(
                name="review-code",
                description="Review code",
                template="Review this {{ language }} code:\n{{ code }}",
                arguments=[
                    MCPServerPromptArgument(name="code", required=True),
                    MCPServerPromptArgument(name="language"),
                ],
            )
        ]

        result = load_prompts(fmcp, prompts, engine)
        assert len(result.loaded) == 1
        assert result.loaded[0].name == "review-code"
        assert "review-code" in fmcp._registered_prompts

    def test_load_prompt_without_template(self) -> None:
        from cockpit_aap.mcp_loader.prompt_loader import load_prompts
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        prompts = [
            MCPServerPromptDeclaration(
                name="simple",
                description="Simple prompt",
            )
        ]

        result = load_prompts(fmcp, prompts, engine)
        assert len(result.loaded) == 1

    @pytest.mark.asyncio
    async def test_prompt_renders_template(self) -> None:
        from cockpit_aap.mcp_loader.prompt_loader import load_prompts
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        prompts = [
            MCPServerPromptDeclaration(
                name="greet",
                description="Greet",
                template="Hello, {{ name }}!",
            )
        ]

        load_prompts(fmcp, prompts, engine)
        prompt_fn = fmcp._registered_prompts["greet"]["fn"]
        result = await prompt_fn(name="World")
        assert result == "Hello, World!"

    @pytest.mark.asyncio
    async def test_prompt_without_template_returns_args(self) -> None:
        from cockpit_aap.mcp_loader.prompt_loader import load_prompts
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        prompts = [
            MCPServerPromptDeclaration(
                name="plain",
                description="Plain",
            )
        ]

        load_prompts(fmcp, prompts, engine)
        prompt_fn = fmcp._registered_prompts["plain"]["fn"]
        result = await prompt_fn(key="value")
        assert "key: value" in result

    def test_prompt_error_collected(self) -> None:
        from cockpit_aap.mcp_loader.prompt_loader import load_prompts
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = MagicMock()
        # Make prompt() raise an exception
        fmcp.prompt = MagicMock(side_effect=RuntimeError("registration failed"))
        engine = create_template_engine()

        prompts = [
            MCPServerPromptDeclaration(name="bad", description="bad")
        ]

        result = load_prompts(fmcp, prompts, engine)
        assert len(result.errors) == 1
        assert result.errors[0].kind == "prompt"


# ═══════════════════════════════════════════════════════════════════════════════
# 6. RESOURCE REGISTRATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestResourceLoader:
    """Tests for resource loading on FastMCP."""

    def test_load_static_resource(self) -> None:
        from cockpit_aap.mcp_loader.resource_loader import load_resources
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        resources = [
            MCPServerResourceDeclaration(
                name="rules",
                uri="file:///rules.json",
                content='{"rules": []}',
                mime_type="application/json",
            )
        ]

        result = load_resources(fmcp, resources, [], engine)
        assert len(result.resources) == 1
        assert result.resources[0].name == "rules"
        assert result.resources[0].uri == "file:///rules.json"

    def test_load_resource_template(self) -> None:
        from cockpit_aap.mcp_loader.resource_loader import load_resources
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        templates = [
            MCPServerResourceTemplateDeclaration(
                name="report",
                uri_template="report:///{module}",
                template="# Report for {{ module }}",
                mime_type="text/markdown",
            )
        ]

        result = load_resources(fmcp, [], templates, engine)
        assert len(result.resource_templates) == 1
        assert result.resource_templates[0].name == "report"

    @pytest.mark.asyncio
    async def test_static_resource_returns_content(self) -> None:
        from cockpit_aap.mcp_loader.resource_loader import load_resources
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        resources = [
            MCPServerResourceDeclaration(
                name="data",
                uri="file:///data.txt",
                content="Hello, World!",
            )
        ]

        load_resources(fmcp, resources, [], engine)
        resource_fn = fmcp._registered_resources["data"]["fn"]
        result = await resource_fn()
        assert result == "Hello, World!"

    @pytest.mark.asyncio
    async def test_resource_template_renders(self) -> None:
        from cockpit_aap.mcp_loader.resource_loader import load_resources
        from cockpit_aap.mcp_loader.template_engine import create_template_engine

        fmcp = _create_mock_fmcp()
        engine = create_template_engine()

        templates = [
            MCPServerResourceTemplateDeclaration(
                name="report",
                uri_template="report:///{module}",
                template="# Report for {{ module }}",
            )
        ]

        load_resources(fmcp, [], templates, engine)
        resource_fn = fmcp._registered_resources["report"]["fn"]
        result = await resource_fn(module="my-module")
        assert result == "# Report for my-module"


# ═══════════════════════════════════════════════════════════════════════════════
# 7. FULL INTEGRATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════


class TestLoadManifestServer:
    """Integration tests for load_manifest_server."""

    @pytest.mark.asyncio
    async def test_full_manifest_loading(self) -> None:
        from cockpit_aap.mcp_loader.loader import load_manifest_server

        fmcp = _create_mock_fmcp()

        manifest_dict = {
            "apiVersion": "modelcontextprotocol.io/v1",
            "kind": "MCPServer",
            "metadata": {"name": "test-server", "version": "1.0.0"},
            "spec": {
                "transport": "streamable-http",
                "endpoint": "http://localhost:3000",
                "auth": "none",
                "tools": [
                    {
                        "name": "greet",
                        "description": "Greet user",
                        "handler": {"type": "template", "template": "Hello, {{ name }}!"},
                    },
                ],
                "prompts": [
                    {
                        "name": "review",
                        "description": "Review code",
                        "template": "Review: {{ code }}",
                    }
                ],
                "resources": [
                    {
                        "name": "rules",
                        "uri": "file:///rules.json",
                        "content": "{}",
                    }
                ],
                "resourceTemplates": [
                    {
                        "name": "report",
                        "uriTemplate": "report:///{id}",
                        "template": "Report {{ id }}",
                    }
                ],
            },
        }

        result = await load_manifest_server(fmcp, manifest_dict)

        assert len(result.tools) == 1
        assert len(result.prompts) == 1
        assert len(result.resources) == 1
        assert len(result.resource_templates) == 1
        assert len(result.errors) == 0

    @pytest.mark.asyncio
    async def test_manifest_with_dataclass(self) -> None:
        from cockpit_aap.mcp_loader.loader import load_manifest_server

        fmcp = _create_mock_fmcp()

        manifest = MCPServerManifest.from_dict({
            "apiVersion": "modelcontextprotocol.io/v1",
            "kind": "MCPServer",
            "metadata": {"name": "test-server"},
            "spec": {
                "transport": "streamable-http",
                "endpoint": "http://localhost",
                "auth": "none",
                "tools": [
                    {
                        "name": "hello",
                        "description": "Say hello",
                        "handler": {"type": "template", "template": "Hello!"},
                    }
                ],
            },
        })

        result = await load_manifest_server(fmcp, manifest)
        assert len(result.tools) == 1
        assert result.tools[0].name == "hello"

    @pytest.mark.asyncio
    async def test_manifest_empty_spec(self) -> None:
        from cockpit_aap.mcp_loader.loader import load_manifest_server

        fmcp = _create_mock_fmcp()

        manifest_dict = {
            "apiVersion": "modelcontextprotocol.io/v1",
            "kind": "MCPServer",
            "metadata": {"name": "empty-server"},
            "spec": {
                "transport": "streamable-http",
                "endpoint": "http://localhost",
                "auth": "none",
            },
        }

        result = await load_manifest_server(fmcp, manifest_dict)
        assert len(result.tools) == 0
        assert len(result.prompts) == 0
        assert len(result.resources) == 0
        assert len(result.resource_templates) == 0
        assert len(result.errors) == 0

    @pytest.mark.asyncio
    async def test_manifest_with_callbacks(self) -> None:
        from cockpit_aap.mcp_loader.loader import load_manifest_server

        fmcp = _create_mock_fmcp()
        tools_registered: list[str] = []
        prompts_registered: list[str] = []
        resources_registered: list[str] = []

        manifest_dict = {
            "apiVersion": "modelcontextprotocol.io/v1",
            "kind": "MCPServer",
            "metadata": {"name": "test"},
            "spec": {
                "transport": "streamable-http",
                "endpoint": "http://localhost",
                "auth": "none",
                "tools": [
                    {
                        "name": "t1",
                        "description": "Tool 1",
                        "handler": {"type": "template", "template": "ok"},
                    }
                ],
                "prompts": [
                    {"name": "p1", "description": "Prompt 1", "template": "text"}
                ],
                "resources": [
                    {"name": "r1", "uri": "file:///r1", "content": "data"}
                ],
            },
        }

        options = LoadOptions(
            on_tool_registered=lambda n, t: tools_registered.append(n),
            on_prompt_registered=lambda n: prompts_registered.append(n),
            on_resource_registered=lambda n, u: resources_registered.append(n),
        )

        result = await load_manifest_server(fmcp, manifest_dict, options)
        assert tools_registered == ["t1"]
        assert prompts_registered == ["p1"]
        assert resources_registered == ["r1"]

    @pytest.mark.asyncio
    async def test_manifest_keyword_shortcut(self) -> None:
        from cockpit_aap.mcp_loader.loader import load_manifest_server

        fmcp = _create_mock_fmcp()

        manifest_dict = {
            "apiVersion": "modelcontextprotocol.io/v1",
            "kind": "MCPServer",
            "metadata": {"name": "test"},
            "spec": {
                "transport": "streamable-http",
                "endpoint": "http://localhost",
                "auth": "none",
                "tools": [
                    {
                        "name": "t1",
                        "description": "Tool 1",
                        "handler": {"type": "template", "template": "ok"},
                    }
                ],
            },
        }

        result = await load_manifest_server(
            fmcp, manifest_dict, handlers_dir="/tmp"
        )
        assert len(result.tools) == 1

    @pytest.mark.asyncio
    async def test_mixed_tools_with_errors(self, tmp_path: Path) -> None:
        from cockpit_aap.mcp_loader.loader import load_manifest_server

        fmcp = _create_mock_fmcp()

        manifest_dict = {
            "apiVersion": "modelcontextprotocol.io/v1",
            "kind": "MCPServer",
            "metadata": {"name": "test"},
            "spec": {
                "transport": "streamable-http",
                "endpoint": "http://localhost",
                "auth": "none",
                "tools": [
                    # This should work
                    {
                        "name": "good-tool",
                        "description": "Good",
                        "handler": {"type": "template", "template": "ok"},
                    },
                    # This should fail (missing template)
                    {
                        "name": "bad-tool",
                        "description": "Bad",
                        "handler": {"type": "template"},
                    },
                ],
            },
        }

        result = await load_manifest_server(fmcp, manifest_dict)
        assert len(result.tools) == 1
        assert result.tools[0].name == "good-tool"
        assert len(result.errors) == 1
        assert result.errors[0].name == "bad-tool"
