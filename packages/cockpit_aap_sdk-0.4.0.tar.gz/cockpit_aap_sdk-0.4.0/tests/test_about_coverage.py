"""Tests for about.py — read_about, write_about, serialization."""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from cockpit_aap.about import (
    AboutPayload,
    META_KEY_SUFFIX,
    _escape_regex,
    _extract_value,
    read_about,
    write_about,
)


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


def test_about_payload_defaults():
    p = AboutPayload(module="m", version="1.0.0", about={}, technical={})
    assert p.artifact_count == 0
    assert p.agent_count == 0


def test_about_payload_full():
    p = AboutPayload(
        module="m",
        version="2.0.0",
        about={"title": "My Module", "summary": "Does stuff"},
        technical={"description": "Built with Python"},
        artifact_count=5,
        agent_count=3,
    )
    assert p.module == "m"
    assert p.about["title"] == "My Module"


def test_meta_key_suffix():
    assert META_KEY_SUFFIX == "._meta.about"


# ---------------------------------------------------------------------------
# _escape_regex / _extract_value
# ---------------------------------------------------------------------------


def test_escape_regex():
    assert _escape_regex("a.b") == r"a\.b"


class TestExtractValue:
    def test_none(self):
        assert _extract_value(None) is None

    def test_non_dict(self):
        assert _extract_value("x") is None

    def test_artifacts_list(self):
        assert _extract_value({"artifacts": [{"value": "v"}]}) == "v"

    def test_artifacts_empty(self):
        assert _extract_value({"artifacts": []}) is None

    def test_direct_value(self):
        assert _extract_value({"value": "val"}) == "val"

    def test_content_key(self):
        assert _extract_value({"content": "cnt"}) == "cnt"

    def test_empty_dict(self):
        assert _extract_value({}) is None


# ---------------------------------------------------------------------------
# read_about
# ---------------------------------------------------------------------------


class TestReadAbout:
    @pytest.mark.asyncio
    async def test_success(self):
        data = {
            "module": "my-mod",
            "version": "1.0.0",
            "about": {"title": "My Module", "summary": "Test"},
            "technical": {"description": "Python app"},
            "artifactCount": 10,
            "agentCount": 2,
        }
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": [{"value": json.dumps(data)}]})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_about(mock_sdk, "ns", "my-mod")
        assert result is not None
        assert result.module == "my-mod"
        assert result.version == "1.0.0"
        assert result.about["title"] == "My Module"
        assert result.artifact_count == 10
        assert result.agent_count == 2

    @pytest.mark.asyncio
    async def test_not_found(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_about(mock_sdk, "ns", "missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_empty_value(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": []})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_about(mock_sdk, "ns", "mod")
        assert result is None

    @pytest.mark.asyncio
    async def test_with_content_attr(self):
        data = {
            "module": "mod",
            "about": {"title": "T"},
            "technical": {"description": "D"},
        }

        class ResultObj:
            content = {"value": json.dumps(data)}

        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value=ResultObj())
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_about(mock_sdk, "ns", "mod")
        assert result is not None
        assert result.version == "0.0.0"  # default

    @pytest.mark.asyncio
    async def test_non_dict_content(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value="not-a-dict")
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_about(mock_sdk, "ns", "mod")
        assert result is None


# ---------------------------------------------------------------------------
# write_about
# ---------------------------------------------------------------------------


class TestWriteAbout:
    @pytest.mark.asyncio
    async def test_write_with_dict_about(self):
        definition = type("D", (), {
            "module": "my-mod",
            "version": "1.0.0",
            "about": {"title": "Title", "summary": "Summary"},
            "technical": {"description": "Tech desc"},
            "artifacts": [1, 2, 3],
            "agents": [1],
        })()

        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_ns.create_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await write_about(mock_sdk, "ns", definition)
        mock_ns.create_artifact.assert_called_once()
        # Verify payload
        call_kwargs = mock_ns.create_artifact.call_args
        value = json.loads(call_kwargs.kwargs.get("value", call_kwargs[1].get("value", "")))
        assert value["module"] == "my-mod"
        assert value["artifactCount"] == 3
        assert value["agentCount"] == 1

    @pytest.mark.asyncio
    async def test_write_with_string_about(self):
        definition = type("D", (), {
            "module": "mod",
            "version": None,
            "about": "Simple title",
            "technical": "Simple tech",
            "artifacts": None,
            "agents": None,
        })()

        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_ns.create_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await write_about(mock_sdk, "ns", definition)
        call_kwargs = mock_ns.create_artifact.call_args
        value = json.loads(call_kwargs.kwargs.get("value", call_kwargs[1].get("value", "")))
        assert value["about"] == {"title": "Simple title"}
        assert value["technical"] == {"description": "Simple tech"}
        assert value["version"] == "0.0.0"

    @pytest.mark.asyncio
    async def test_write_no_about_skips(self):
        definition = type("D", (), {"module": "mod", "about": None})()

        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await write_about(mock_sdk, "ns", definition)
        # No artifact operations should have been called
        mock_ns.get_artifact.assert_not_called()

    @pytest.mark.asyncio
    async def test_write_dict_definition(self):
        """When definition is a dict with 'module' key."""
        definition = type("D", (), {
            "about": {"title": "T"},
        })()
        # module accessed via dict path
        definition.module = "dict-mod"
        definition.version = "1.0.0"
        definition.technical = None
        definition.artifacts = []
        definition.agents = []

        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_ns.create_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await write_about(mock_sdk, "ns", definition)
        mock_ns.create_artifact.assert_called_once()
