"""Tests for Manifest directory scanner."""
import os
import pytest
from cockpit_aap.manifest.scanner import scan_manifest

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def test_scan_single_file():
    """Single-file manifest (manifest.yaml) should be parsed."""
    manifest = scan_manifest(os.path.join(FIXTURES, "single-file"))
    assert manifest.metadata.name == "single-file-test"
    assert manifest.spec.agents[0].instruction == "Inline instruction here"


def test_scan_multi_file_resolves_agent_md():
    """Multi-file manifest should resolve agents/*.md file references."""
    manifest = scan_manifest(os.path.join(FIXTURES, "multi-file"))
    assert manifest.metadata.name == "multi-file-test"
    assert "deep research assistant" in manifest.spec.agents[0].instruction
    assert manifest.spec.agents[0].runtime == "python"


def test_scan_multi_file_loads_i18n():
    """Multi-file manifest should load i18n resources from i18n/{locale}/."""
    manifest = scan_manifest(os.path.join(FIXTURES, "multi-file"))
    assert manifest.spec.i18n is not None
    assert "en" in manifest.spec.i18n.locales
    assert "pt-BR" in manifest.spec.i18n.locales


def test_scan_i18n_resources_content():
    """i18n resources should contain the actual JSON content."""
    manifest = scan_manifest(os.path.join(FIXTURES, "multi-file"))
    en_locale = manifest.spec.i18n.locales["en"]
    assert en_locale.resources is not None
    assert en_locale.resources.get("welcome") == "Welcome to Deep Research"


def test_scan_connections_preserved():
    """Connections should be parsed from manifest."""
    manifest = scan_manifest(os.path.join(FIXTURES, "multi-file"))
    assert len(manifest.spec.connections) == 1
    assert manifest.spec.connections[0].id == "frontend"


def test_scan_nonexistent_dir_raises():
    """Scanning a nonexistent directory should raise."""
    with pytest.raises(FileNotFoundError):
        scan_manifest("/nonexistent/path")


def test_scan_dir_without_manifest_raises():
    """Directory without manifest.yaml or manifest.yaml should raise."""
    with pytest.raises(FileNotFoundError, match="No manifest"):
        scan_manifest(FIXTURES)  # fixtures dir has no manifest.yaml itself
