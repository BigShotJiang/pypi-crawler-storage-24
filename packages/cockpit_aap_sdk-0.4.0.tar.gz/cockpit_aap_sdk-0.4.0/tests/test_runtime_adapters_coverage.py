"""Tests for runtime adapters with low coverage:
- console_telemetry.py
- langchain_callback.py
- otel_telemetry.py
- guardrails_ai_adapter.py (mock-based, no real guardrails-ai)
- llamafirewall_adapter.py (mock-based)
- postgres_cost_tracker.py (mock-based)
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from dataclasses import dataclass

import pytest

from cockpit_aap.ports.agent_telemetry import AgentSpanContext, SpanHandle, AgentEvent, AgentSpanResult
from cockpit_aap.ports.guardrail import GuardrailContext, GuardrailDecision, GuardrailViolation
from cockpit_aap.ports.cost_tracker import CostUsage, CostFilter, CostSummary, BudgetStatus


# ===========================================================================
# ConsoleTelemetryAdapter
# ===========================================================================


class TestConsoleTelemetryAdapter:
    def test_start_agent_span(self, capsys):
        from cockpit_aap.runtime.console_telemetry import ConsoleTelemetryAdapter
        adapter = ConsoleTelemetryAdapter()
        ctx = AgentSpanContext(agent_id="bot", request_id="req-1", model="gpt-4")
        handle = adapter.start_agent_span(ctx)
        assert handle.span_id.startswith("span-")
        assert handle.trace_id == "trace-req-1"
        captured = capsys.readouterr()
        assert "gen_ai.agent.id=bot" in captured.out

    def test_start_agent_span_with_user_and_tenant(self, capsys):
        from cockpit_aap.runtime.console_telemetry import ConsoleTelemetryAdapter
        adapter = ConsoleTelemetryAdapter()
        ctx = AgentSpanContext(agent_id="bot", request_id="req-2", model="gpt-4", user_id="u1", tenant_id="t1")
        handle = adapter.start_agent_span(ctx)
        captured = capsys.readouterr()
        assert "enduser.id=u1" in captured.out
        assert "aap.tenant.id=t1" in captured.out

    def test_record_event(self, capsys):
        from cockpit_aap.runtime.console_telemetry import ConsoleTelemetryAdapter
        adapter = ConsoleTelemetryAdapter()
        handle = SpanHandle(span_id="span-test", trace_id="trace-test")
        event = AgentEvent(name="tool_call", attributes={"tool": "search"})
        adapter.record_event(handle, event)
        captured = capsys.readouterr()
        assert "EVENT span-test tool_call" in captured.out
        assert "tool=search" in captured.out

    def test_end_span(self, capsys):
        from cockpit_aap.runtime.console_telemetry import ConsoleTelemetryAdapter
        adapter = ConsoleTelemetryAdapter()
        handle = SpanHandle(span_id="span-end", trace_id="trace-end")
        result = AgentSpanResult(status="ok", duration_ms=150.5, attributes={"tokens": 100})
        adapter.end_span(handle, result)
        captured = capsys.readouterr()
        assert "END span-end status=ok 150.5ms" in captured.out
        assert "tokens=100" in captured.out

    def test_end_span_no_duration(self, capsys):
        from cockpit_aap.runtime.console_telemetry import ConsoleTelemetryAdapter
        adapter = ConsoleTelemetryAdapter()
        handle = SpanHandle(span_id="span-x", trace_id="trace-x")
        result = AgentSpanResult(status="error")
        adapter.end_span(handle, result)
        captured = capsys.readouterr()
        assert "END span-x status=error" in captured.out


# ===========================================================================
# OtelTelemetryAdapter (without actual otel SDK)
# ===========================================================================


class TestOtelTelemetryAdapterFallback:
    def test_fallback_when_otel_not_available(self, capsys):
        """When opentelemetry is not available, should fallback to console."""
        from cockpit_aap.runtime.otel_telemetry import OtelTelemetryAdapter
        # Create with otel likely unavailable in test env
        adapter = OtelTelemetryAdapter()

        if not adapter._available:
            # Test console fallback path
            ctx = AgentSpanContext(agent_id="bot", request_id="req-1", model="gpt-4")
            handle = adapter.start_agent_span(ctx)
            assert handle.span_id
            assert handle.trace_id.startswith("trace-")

            event = AgentEvent(name="test_event", attributes={"k": "v"})
            adapter.record_event(handle, event)

            result = AgentSpanResult(status="ok", attributes={"tokens": 50})
            adapter.end_span(handle, result)
            captured = capsys.readouterr()
            assert "telemetry" in captured.out.lower() or "END" in captured.out

    def test_console_start(self, capsys):
        from cockpit_aap.runtime.otel_telemetry import OtelTelemetryAdapter
        adapter = OtelTelemetryAdapter()
        adapter._available = False  # Force fallback
        ctx = AgentSpanContext(agent_id="test", request_id="r1", model="m")
        handle = adapter.start_agent_span(ctx)
        assert handle.span_id
        captured = capsys.readouterr()
        assert "START" in captured.out

    def test_console_event(self, capsys):
        from cockpit_aap.runtime.otel_telemetry import OtelTelemetryAdapter
        adapter = OtelTelemetryAdapter()
        adapter._available = False
        handle = SpanHandle(span_id="s1", trace_id="t1")
        adapter.record_event(handle, AgentEvent(name="evt"))
        captured = capsys.readouterr()
        assert "EVENT s1 evt" in captured.out

    def test_console_end(self, capsys):
        from cockpit_aap.runtime.otel_telemetry import OtelTelemetryAdapter
        adapter = OtelTelemetryAdapter()
        adapter._available = False
        handle = SpanHandle(span_id="s1", trace_id="t1")
        adapter.end_span(handle, AgentSpanResult(status="error", attributes={"err": "timeout"}))
        captured = capsys.readouterr()
        assert "END s1 status=error" in captured.out
        assert "err=timeout" in captured.out

    def test_console_end_no_attrs(self, capsys):
        from cockpit_aap.runtime.otel_telemetry import OtelTelemetryAdapter
        adapter = OtelTelemetryAdapter()
        adapter._available = False
        handle = SpanHandle(span_id="s2", trace_id="t2")
        adapter.end_span(handle, AgentSpanResult(status="ok"))
        captured = capsys.readouterr()
        assert "END s2 status=ok" in captured.out


# ===========================================================================
# LangChainCallback
# ===========================================================================


class TestLangChainCallback:
    @pytest.mark.asyncio
    async def test_on_chain_start_allowed(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.before_call = AsyncMock(return_value=GuardrailDecision(allowed=True))
        cb = AAPLangChainCallback(mock_runtime, agent_id="bot", model="gpt-4")
        await cb.on_chain_start({}, {"input": "Hello"}, run_id="run-1")
        mock_runtime.before_call.assert_called_once()
        assert "run-1" in cb._active_spans

    @pytest.mark.asyncio
    async def test_on_chain_start_blocked(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.before_call = AsyncMock(return_value=GuardrailDecision(
            allowed=False, violations=[GuardrailViolation(rule_id="r", category="c", message="blocked")]
        ))
        cb = AAPLangChainCallback(mock_runtime)
        with pytest.raises(RuntimeError, match="Blocked by AAP guardrail"):
            await cb.on_chain_start({}, {"input": "bad"}, run_id="run-2")

    @pytest.mark.asyncio
    async def test_on_chain_start_with_messages(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.before_call = AsyncMock(return_value=GuardrailDecision(allowed=True))
        cb = AAPLangChainCallback(mock_runtime)
        await cb.on_chain_start({}, {"messages": ["msg1", "msg2"]}, run_id="run-3")
        mock_runtime.before_call.assert_called_once()

    @pytest.mark.asyncio
    async def test_on_chain_start_no_run_id(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.before_call = AsyncMock(return_value=GuardrailDecision(allowed=True))
        cb = AAPLangChainCallback(mock_runtime)
        await cb.on_chain_start({}, {"input": "x"}, run_id=None)
        assert len(cb._active_spans) == 1

    @pytest.mark.asyncio
    async def test_on_chain_end(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.before_call = AsyncMock(return_value=GuardrailDecision(allowed=True))
        mock_runtime.after_call = AsyncMock()
        cb = AAPLangChainCallback(mock_runtime)
        await cb.on_chain_start({}, {"input": "hi"}, run_id="run-5")
        await cb.on_chain_end({"output": "bye"}, run_id="run-5")
        mock_runtime.after_call.assert_called_once()
        assert "run-5" not in cb._active_spans

    @pytest.mark.asyncio
    async def test_on_chain_end_no_span(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.after_call = AsyncMock()
        cb = AAPLangChainCallback(mock_runtime)
        # No matching span — should not call after_call
        await cb.on_chain_end({"output": "x"}, run_id="unknown")
        mock_runtime.after_call.assert_not_called()

    @pytest.mark.asyncio
    async def test_on_chain_error(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.before_call = AsyncMock(return_value=GuardrailDecision(allowed=True))
        mock_runtime.on_error = AsyncMock()
        cb = AAPLangChainCallback(mock_runtime)
        await cb.on_chain_start({}, {"input": "x"}, run_id="run-6")
        await cb.on_chain_error(ValueError("test error"), run_id="run-6")
        mock_runtime.on_error.assert_called_once()

    @pytest.mark.asyncio
    async def test_on_chain_error_base_exception(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.before_call = AsyncMock(return_value=GuardrailDecision(allowed=True))
        mock_runtime.on_error = AsyncMock()
        cb = AAPLangChainCallback(mock_runtime)
        await cb.on_chain_start({}, {"input": "x"}, run_id="run-7")
        await cb.on_chain_error(KeyboardInterrupt("stop"), run_id="run-7")
        mock_runtime.on_error.assert_called_once()

    @pytest.mark.asyncio
    async def test_on_chain_error_no_span(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        mock_runtime = MagicMock()
        mock_runtime.on_error = AsyncMock()
        cb = AAPLangChainCallback(mock_runtime)
        await cb.on_chain_error(Exception("x"), run_id="unknown")
        mock_runtime.on_error.assert_not_called()

    @pytest.mark.asyncio
    async def test_on_tool_start_noop(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        cb = AAPLangChainCallback(MagicMock())
        await cb.on_tool_start({}, "input", run_id="run-8")  # Should not raise

    @pytest.mark.asyncio
    async def test_on_llm_end_noop(self):
        from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback
        cb = AAPLangChainCallback(MagicMock())
        await cb.on_llm_end(MagicMock(), run_id="run-9")  # Should not raise


# ===========================================================================
# GuardrailsAIAdapter (mock-based)
# ===========================================================================


class TestGuardrailsAIAdapterMocked:
    def test_evaluate_pass(self):
        from cockpit_aap.runtime.guardrails_ai_adapter import GuardrailsAIAdapter

        mock_guard = MagicMock()
        mock_guard.validate.return_value = MagicMock(validation_passed=True)
        adapter = GuardrailsAIAdapter(mock_guard)

        result = adapter._evaluate("hello")
        assert result.allowed is True
        assert result.action == "pass"

    def test_evaluate_fail(self):
        from cockpit_aap.runtime.guardrails_ai_adapter import GuardrailsAIAdapter

        class FailedValidation:
            id = "pii-check"
            validator_name = "DetectPII"

            def __str__(self):
                return "PII detected"

        mock_result = MagicMock(validation_passed=False, failed_validations=[FailedValidation()])
        mock_guard = MagicMock()
        mock_guard.validate.return_value = mock_result
        adapter = GuardrailsAIAdapter(mock_guard)

        result = adapter._evaluate("My SSN is 123-45-6789")
        assert result.allowed is False
        assert result.action == "block"
        assert len(result.violations) == 1
        assert result.violations[0].rule_id == "pii-check"
        assert result.violations[0].category == "DetectPII"

    def test_evaluate_exception(self):
        from cockpit_aap.runtime.guardrails_ai_adapter import GuardrailsAIAdapter

        mock_guard = MagicMock()
        mock_guard.validate.side_effect = RuntimeError("guard crashed")
        adapter = GuardrailsAIAdapter(mock_guard)

        result = adapter._evaluate("test")
        assert result.allowed is True
        assert result.action == "warn"
        assert result.violations[0].rule_id == "guardrails-ai-error"

    @pytest.mark.asyncio
    async def test_evaluate_input(self):
        from cockpit_aap.runtime.guardrails_ai_adapter import GuardrailsAIAdapter

        mock_guard = MagicMock()
        mock_guard.validate.return_value = MagicMock(validation_passed=True)
        adapter = GuardrailsAIAdapter(mock_guard)

        result = await adapter.evaluate_input(GuardrailContext(agent_id="bot", input="hi"))
        assert result.allowed

    @pytest.mark.asyncio
    async def test_evaluate_output(self):
        from cockpit_aap.runtime.guardrails_ai_adapter import GuardrailsAIAdapter

        mock_guard = MagicMock()
        mock_guard.validate.return_value = MagicMock(validation_passed=True)
        adapter = GuardrailsAIAdapter(mock_guard)

        result = await adapter.evaluate_output(GuardrailContext(agent_id="bot", input="output text"))
        assert result.allowed


# ===========================================================================
# LlamaFirewallAdapter (mock-based)
# ===========================================================================


class TestLlamaFirewallAdapterMocked:
    def test_init_defaults(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        assert adapter._input_scanners == ["PROMPT_GUARD"]
        assert adapter._output_scanners == ["PROMPT_GUARD"]
        assert not adapter._initialized

    def test_init_custom_scanners(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter(
            input_scanners=["PROMPT_GUARD", "ALIGNMENT_CHECK"],
            output_scanners=["CODE_SHIELD"],
        )
        assert adapter._input_scanners == ["PROMPT_GUARD", "ALIGNMENT_CHECK"]

    def test_ensure_init_no_library(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        adapter._ensure_init()
        assert adapter._initialized
        # Without llamafirewall installed, firewall should be None
        assert adapter._firewall is None

    def test_ensure_init_idempotent(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        adapter._ensure_init()
        adapter._ensure_init()  # Second call should be no-op
        assert adapter._initialized

    def test_scan_result_to_decision_none(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        result = adapter._scan_result_to_decision(None)
        assert result.allowed
        assert result.action == "pass"

    def test_scan_result_to_decision_allow(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        mock_result = MagicMock()
        mock_result.decision = "ALLOW"
        mock_result.reason = ""
        mock_result.score = 0.95
        result = adapter._scan_result_to_decision(mock_result)
        assert result.allowed
        assert result.action == "pass"

    def test_scan_result_to_decision_block(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        mock_result = MagicMock()
        mock_result.decision = "BLOCK"
        mock_result.reason = "Jailbreak detected"
        mock_result.score = 0.99
        result = adapter._scan_result_to_decision(mock_result)
        assert not result.allowed
        assert result.action == "block"
        assert len(result.violations) == 1
        assert "Jailbreak detected" in result.violations[0].message

    def test_scan_result_to_decision_block_no_reason(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        mock_result = MagicMock()
        mock_result.decision = "BLOCK"
        mock_result.reason = None
        mock_result.score = None
        result = adapter._scan_result_to_decision(mock_result)
        assert not result.allowed
        assert "LlamaFirewall blocked content" in result.violations[0].message

    @pytest.mark.asyncio
    async def test_evaluate_input_no_firewall(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        adapter._initialized = True
        adapter._firewall = None
        result = await adapter.evaluate_input(GuardrailContext(agent_id="bot", input="test"))
        assert result.allowed

    @pytest.mark.asyncio
    async def test_evaluate_input_no_input(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        adapter._initialized = True
        adapter._firewall = MagicMock()
        result = await adapter.evaluate_input(GuardrailContext(agent_id="bot", input=None))
        assert result.allowed

    @pytest.mark.asyncio
    async def test_evaluate_output_no_firewall(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        adapter._initialized = True
        adapter._firewall = None
        result = await adapter.evaluate_output(GuardrailContext(agent_id="bot", input="test"))
        assert result.allowed

    @pytest.mark.asyncio
    async def test_evaluate_output_no_input(self):
        from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
        adapter = LlamaFirewallAdapter()
        adapter._initialized = True
        adapter._firewall = MagicMock()
        result = await adapter.evaluate_output(GuardrailContext(agent_id="bot", input=None))
        assert result.allowed


# ===========================================================================
# PostgresCostTracker (mock-based)
# ===========================================================================


class TestPostgresCostTracker:
    def test_calculate_cost_no_pricing(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        tracker = PostgresCostTracker(MagicMock())
        usage = CostUsage(agent_id="a", model="unknown", input_tokens=100, output_tokens=50, cost_usd=0.5)
        assert tracker._calculate_cost(usage) == 0.5

    def test_calculate_cost_no_pricing_no_cost(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        tracker = PostgresCostTracker(MagicMock())
        usage = CostUsage(agent_id="a", model="unknown", input_tokens=100, output_tokens=50)
        assert tracker._calculate_cost(usage) == 0

    def test_calculate_cost_with_pricing(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        tracker = PostgresCostTracker(MagicMock(), config={
            "models": {"gpt-4": {"input_per_1k": 0.03, "output_per_1k": 0.06}},
        })
        usage = CostUsage(agent_id="a", model="gpt-4", input_tokens=1000, output_tokens=500)
        cost = tracker._calculate_cost(usage)
        assert cost == pytest.approx(0.03 + 0.03)  # 1k*0.03 + 0.5k*0.06

    def test_init_defaults(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        tracker = PostgresCostTracker(MagicMock())
        assert tracker._table == "aap_cost_usage"
        assert tracker._currency == "USD"

    def test_init_custom_config(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        tracker = PostgresCostTracker(MagicMock(), config={
            "table_name": "my_costs",
            "currency": "EUR",
            "budget": {"daily": 10.0},
        })
        assert tracker._table == "my_costs"
        assert tracker._currency == "EUR"

    @pytest.mark.asyncio
    async def test_record(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        mock_pool = AsyncMock()
        tracker = PostgresCostTracker(mock_pool)
        usage = CostUsage(agent_id="a", model="gpt-4", input_tokens=100, output_tokens=50, cost_usd=0.01, request_id="req-1")
        await tracker.record(usage)
        mock_pool.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_record_calculates_cost(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        mock_pool = AsyncMock()
        tracker = PostgresCostTracker(mock_pool, config={
            "models": {"gpt-4": {"input_per_1k": 0.03, "output_per_1k": 0.06}},
        })
        usage = CostUsage(agent_id="a", model="gpt-4", input_tokens=1000, output_tokens=500)
        await tracker.record(usage)
        mock_pool.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_query_no_filter(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = {"total_cost": 5.0, "total_tokens": 1000}
        tracker = PostgresCostTracker(mock_pool)
        result = await tracker.query(CostFilter())
        assert result.total_cost == 5.0
        assert result.total_tokens == 1000

    @pytest.mark.asyncio
    async def test_query_with_agent_filter(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = {"total_cost": 2.0, "total_tokens": 500}
        tracker = PostgresCostTracker(mock_pool)
        result = await tracker.query(CostFilter(agent_id="bot"))
        assert result.total_cost == 2.0

    @pytest.mark.asyncio
    async def test_check_budget_daily(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = {"total_cost": 5.0}
        tracker = PostgresCostTracker(mock_pool, config={"budget": {"daily": 10.0}})
        status = await tracker.check_budget("bot")
        assert status.within_budget is True
        assert status.spent == 5.0
        assert status.limit == 10.0
        assert status.period == "daily"

    @pytest.mark.asyncio
    async def test_check_budget_exceeded(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = {"total_cost": 15.0}
        tracker = PostgresCostTracker(mock_pool, config={"budget": {"daily": 10.0}})
        status = await tracker.check_budget("bot")
        assert status.within_budget is False

    @pytest.mark.asyncio
    async def test_check_budget_monthly(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = {"total_cost": 50.0}
        tracker = PostgresCostTracker(mock_pool, config={"budget": {"monthly": 100.0}})
        status = await tracker.check_budget("bot")
        assert status.period == "monthly"
        assert status.within_budget is True

    @pytest.mark.asyncio
    async def test_check_budget_no_budget_config(self):
        from cockpit_aap.runtime.postgres_cost_tracker import PostgresCostTracker
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = {"total_cost": 99999.0}
        tracker = PostgresCostTracker(mock_pool)
        status = await tracker.check_budget("bot")
        assert status.within_budget is True  # no limit = inf
