"""Tests for cockpit_aap.conformance — conformance & manifest-policy evaluation engine."""

from __future__ import annotations

import pytest

from cockpit_aap.conformance import (
    ConformanceResult,
    ConformanceViolation,
    HealthCategory,
    HealthResult,
    ManifestPolicyResult,
    ManifestPolicyViolation,
    check_health,
    eval_expression,
    evaluate_conformance,
    evaluate_manifest_policy,
    field_exists,
    get_field_value,
    grade_from_pct,
    grade_to_number,
)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_manifest(
    kind: str = "Module",
    name: str = "test-module",
    version: str = "1.0.0",
    extra_meta: dict | None = None,
    spec: dict | None = None,
) -> dict:
    """Create a test manifest dict."""
    meta = {"name": name, "version": version, "displayName": "Test Module"}
    if extra_meta:
        meta.update(extra_meta)
    return {
        "apiVersion": "cockpit.io/v1",
        "kind": kind,
        "metadata": meta,
        "spec": spec or {},
    }


def _make_conformance_policy(
    name: str = "test-policy",
    applies_to_kind: str = "*",
    requirements: list | None = None,
) -> dict:
    return {
        "apiVersion": "governance.cockpit.io/v1",
        "kind": "ConformancePolicy",
        "metadata": {"name": name},
        "spec": {
            "appliesTo": {"kind": applies_to_kind},
            "requirements": requirements or [],
        },
    }


def _make_manifest_policy(
    name: str = "test-mp",
    applies_to_kind: str = "*",
    when: str | None = None,
    requirements: list | None = None,
) -> dict:
    applies_to: dict = {"kind": applies_to_kind}
    if when:
        applies_to["when"] = when
    return {
        "apiVersion": "governance.cockpit.io/v1",
        "kind": "ManifestPolicy",
        "metadata": {"name": name},
        "spec": {
            "appliesTo": applies_to,
            "requirements": requirements or [],
        },
    }


# ═══════════════════════════════════════════════════════════════════════════════
# eval_expression
# ═══════════════════════════════════════════════════════════════════════════════


class TestEvalExpression:
    def test_simple_equality(self):
        ctx = {"metadata": {"group": "demo"}, "spec": {}}
        assert eval_expression("metadata.group === 'demo'", ctx) is True

    def test_inequality(self):
        ctx = {"metadata": {"group": "framework"}, "spec": {}}
        assert eval_expression("metadata.group === 'demo'", ctx) is False

    def test_not_equal(self):
        ctx = {"metadata": {"group": "framework"}, "spec": {}}
        assert eval_expression("metadata.group !== 'demo'", ctx) is True

    def test_logical_and(self):
        ctx = {"metadata": {"group": "demo"}, "spec": {"agents": [1, 2]}}
        assert eval_expression("metadata.group === 'demo' && spec.agents.length > 0", ctx) is True

    def test_logical_or(self):
        ctx = {"metadata": {"group": "demo"}, "spec": {}}
        assert eval_expression("metadata.group === 'demo' || metadata.group === 'tools'", ctx) is True

    def test_missing_field(self):
        ctx = {"metadata": {}, "spec": {}}
        assert eval_expression("metadata.group === 'demo'", ctx) is False

    def test_error_returns_false(self):
        ctx = {"metadata": {}, "spec": {}}
        assert eval_expression("!@#$%^&invalid()", ctx) is False

    def test_length_property(self):
        ctx = {"metadata": {}, "spec": {"agents": [1, 2, 3]}}
        assert eval_expression("spec.agents.length > 2", ctx) is True


# ═══════════════════════════════════════════════════════════════════════════════
# field_exists / get_field_value
# ═══════════════════════════════════════════════════════════════════════════════


class TestFieldAccess:
    def test_get_nested_value(self):
        obj = {"metadata": {"name": "foo", "annotations": {"tier": "gold"}}}
        assert get_field_value(obj, "metadata.name") == "foo"
        assert get_field_value(obj, "metadata.annotations.tier") == "gold"

    def test_get_missing_value(self):
        assert get_field_value({}, "metadata.name") is None
        assert get_field_value({"metadata": {}}, "metadata.name") is None

    def test_strip_array_brackets(self):
        obj = {"spec": {"agents": [1, 2]}}
        assert get_field_value(obj, "spec.agents[]") == [1, 2]

    def test_field_exists_string(self):
        manifest = {"metadata": {"name": "test"}}
        assert field_exists(manifest, "metadata.name") is True

    def test_field_exists_empty_string(self):
        manifest = {"metadata": {"name": ""}}
        assert field_exists(manifest, "metadata.name") is False

    def test_field_exists_empty_list(self):
        manifest = {"spec": {"agents": []}}
        assert field_exists(manifest, "spec.agents") is False

    def test_field_exists_nonempty_list(self):
        manifest = {"spec": {"agents": [{"id": "a"}]}}
        assert field_exists(manifest, "spec.agents") is True

    def test_field_exists_empty_dict(self):
        manifest = {"spec": {"i18n": {}}}
        assert field_exists(manifest, "spec.i18n") is False

    def test_field_exists_none(self):
        manifest = {"spec": {}}
        assert field_exists(manifest, "spec.agents") is False

    def test_field_exists_boolean(self):
        manifest = {"spec": {"enabled": True}}
        assert field_exists(manifest, "spec.enabled") is True


# ═══════════════════════════════════════════════════════════════════════════════
# grade helpers
# ═══════════════════════════════════════════════════════════════════════════════


class TestGradeHelpers:
    @pytest.mark.parametrize(
        "pct,expected",
        [(100, "A"), (90, "A"), (85, "B"), (75, "B"), (60, "C"), (50, "D"), (40, "D"), (30, "F"), (0, "F")],
    )
    def test_grade_from_pct(self, pct, expected):
        assert grade_from_pct(pct) == expected

    @pytest.mark.parametrize(
        "grade,expected",
        [("A", 5), ("B", 4), ("C", 3), ("D", 2), ("F", 1), ("X", 0)],
    )
    def test_grade_to_number(self, grade, expected):
        assert grade_to_number(grade) == expected


# ═══════════════════════════════════════════════════════════════════════════════
# evaluate_conformance
# ═══════════════════════════════════════════════════════════════════════════════


class TestEvaluateConformance:
    def test_all_fields_present(self):
        policy = _make_conformance_policy(requirements=[
            {"id": "r1", "field": "metadata.name", "severity": "required", "message": "name required"},
            {"id": "r2", "field": "metadata.version", "severity": "required", "message": "version required"},
        ])
        manifest = _make_manifest()
        result = evaluate_conformance(policy, manifest)
        assert isinstance(result, ConformanceResult)
        assert result.percentage == 100
        assert result.grade == "A"
        assert len(result.violations) == 0

    def test_missing_required_field(self):
        policy = _make_conformance_policy(requirements=[
            {"id": "r1", "field": "metadata.name", "severity": "required", "message": "name required"},
            {"id": "r2", "field": "spec.agents", "severity": "required", "message": "agents required"},
        ])
        manifest = _make_manifest()
        result = evaluate_conformance(policy, manifest)
        assert result.percentage < 100
        assert len(result.violations) == 1
        assert result.violations[0].requirement_id == "r2"
        assert result.violations[0].severity == "required"

    def test_recommended_not_blocking(self):
        policy = _make_conformance_policy(requirements=[
            {"id": "r1", "field": "spec.theme", "severity": "recommended", "message": "theme recommended"},
        ])
        manifest = _make_manifest()
        result = evaluate_conformance(policy, manifest)
        assert len(result.violations) == 1
        assert result.violations[0].severity == "recommended"

    def test_forbidden_field(self):
        policy = _make_conformance_policy(requirements=[
            {"id": "r1", "field": "metadata.name", "severity": "forbidden", "message": "name is forbidden"},
        ])
        manifest = _make_manifest()
        result = evaluate_conformance(policy, manifest)
        assert len(result.violations) == 1
        assert result.violations[0].severity == "forbidden"

    def test_info_severity(self):
        policy = _make_conformance_policy(requirements=[
            {"id": "r1", "field": "spec.telemetry", "severity": "info", "message": "telemetry is nice"},
        ])
        manifest = _make_manifest()
        result = evaluate_conformance(policy, manifest)
        assert len(result.violations) == 1
        assert result.violations[0].severity == "info"

    def test_exempt_when(self):
        policy = _make_conformance_policy(requirements=[
            {
                "id": "r1",
                "field": "spec.agents",
                "severity": "required",
                "message": "agents required",
                "exemptWhen": ["metadata.group === 'demo'"],
            },
        ])
        manifest = _make_manifest(extra_meta={"group": "demo"})
        result = evaluate_conformance(policy, manifest)
        assert len(result.violations) == 0
        assert result.exempted_count == 1

    def test_exempt_when_not_matching(self):
        policy = _make_conformance_policy(requirements=[
            {
                "id": "r1",
                "field": "spec.agents",
                "severity": "required",
                "message": "agents required",
                "exemptWhen": ["metadata.group === 'demo'"],
            },
        ])
        manifest = _make_manifest(extra_meta={"group": "production"})
        result = evaluate_conformance(policy, manifest)
        assert len(result.violations) == 1

    def test_custom_weight(self):
        policy = _make_conformance_policy(requirements=[
            {"id": "r1", "field": "metadata.name", "severity": "required", "weight": 10},
            {"id": "r2", "field": "spec.missing", "severity": "required", "weight": 5},
        ])
        manifest = _make_manifest()
        result = evaluate_conformance(policy, manifest)
        assert result.score == 10
        assert result.max_score == 15

    def test_empty_requirements(self):
        policy = _make_conformance_policy(requirements=[])
        manifest = _make_manifest()
        result = evaluate_conformance(policy, manifest)
        assert result.percentage == 100
        assert result.grade == "A"

    def test_policy_name_extracted(self):
        policy = _make_conformance_policy(name="my-policy", requirements=[])
        manifest = _make_manifest()
        result = evaluate_conformance(policy, manifest)
        assert result.policy_name == "my-policy"


# ═══════════════════════════════════════════════════════════════════════════════
# evaluate_manifest_policy
# ═══════════════════════════════════════════════════════════════════════════════


class TestEvaluateManifestPolicy:
    def test_kind_filter_matches(self):
        policy = _make_manifest_policy(
            applies_to_kind="Module",
            requirements=[
                {"id": "r1", "type": "mustHaveAgent", "severity": "required", "message": "need agents"},
            ],
        )
        manifest = _make_manifest(spec={"agents": [{"id": "dev"}]})
        result = evaluate_manifest_policy(policy, manifest)
        assert result.matched is True
        assert len(result.violations) == 0

    def test_kind_filter_does_not_match(self):
        policy = _make_manifest_policy(applies_to_kind="Agent", requirements=[
            {"id": "r1", "type": "mustHaveAgent", "severity": "required", "message": "need agents"},
        ])
        manifest = _make_manifest(kind="Module")
        result = evaluate_manifest_policy(policy, manifest)
        assert result.matched is False
        assert len(result.violations) == 0

    def test_wildcard_kind(self):
        policy = _make_manifest_policy(applies_to_kind="*", requirements=[])
        manifest = _make_manifest(kind="Soul")
        result = evaluate_manifest_policy(policy, manifest)
        assert result.matched is True

    def test_when_expression(self):
        policy = _make_manifest_policy(
            when="metadata.group === 'demo'",
            requirements=[
                {"id": "r1", "type": "mustHaveAgent", "severity": "required", "message": "need agents"},
            ],
        )
        manifest = _make_manifest(extra_meta={"group": "demo"})
        result = evaluate_manifest_policy(policy, manifest)
        assert result.matched is True
        assert len(result.violations) == 1  # no agents in spec

    def test_when_expression_fails(self):
        policy = _make_manifest_policy(
            when="metadata.group === 'production'",
            requirements=[
                {"id": "r1", "type": "mustHaveAgent", "severity": "required", "message": "need agents"},
            ],
        )
        manifest = _make_manifest(extra_meta={"group": "demo"})
        result = evaluate_manifest_policy(policy, manifest)
        assert result.matched is False

    def test_must_have_agent(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "mustHaveAgent", "severity": "required", "message": "need agents"},
        ])
        manifest = _make_manifest(spec={"agents": [{"id": "a1"}, {"id": "a2"}]})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 0

    def test_must_have_agent_min_count(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "mustHaveAgent", "minAgentCount": 3, "severity": "required", "message": "need 3 agents"},
        ])
        manifest = _make_manifest(spec={"agents": [{"id": "a1"}, {"id": "a2"}]})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 1

    def test_must_have_annotation(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "mustHaveAnnotation", "annotationKey": "tier", "severity": "required", "message": "need tier"},
        ])
        manifest = _make_manifest(extra_meta={"annotations": {"tier": "gold"}})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 0

    def test_must_have_annotation_missing(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "mustHaveAnnotation", "annotationKey": "tier", "severity": "required", "message": "need tier"},
        ])
        manifest = _make_manifest()
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 1

    def test_must_have_annotation_allowed_values(self):
        policy = _make_manifest_policy(requirements=[
            {
                "id": "r1",
                "type": "mustHaveAnnotation",
                "annotationKey": "tier",
                "allowedAnnotationValues": ["gold", "silver"],
                "severity": "required",
                "message": "tier must be gold or silver",
            },
        ])
        manifest = _make_manifest(extra_meta={"annotations": {"tier": "bronze"}})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 1

    def test_forbid_annotation(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "forbidAnnotation", "annotationKey": "deprecated", "severity": "required", "message": "no deprecated"},
        ])
        manifest = _make_manifest(extra_meta={"annotations": {"deprecated": "true"}})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 1

    def test_must_have_ref(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "mustHaveRef", "targetKind": "Soul", "severity": "required", "message": "need soul ref"},
        ])
        manifest = _make_manifest(spec={"refs": [{"kind": "Soul", "name": "s1"}]})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 0

    def test_must_have_ref_missing(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "mustHaveRef", "targetKind": "Soul", "severity": "required", "message": "need soul ref"},
        ])
        manifest = _make_manifest(spec={})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 1

    def test_forbid_ref(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "forbidRef", "targetKind": "Deprecated", "severity": "required", "message": "no deprecated refs"},
        ])
        manifest = _make_manifest(spec={"refs": [{"kind": "Deprecated", "name": "d1"}]})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 1

    def test_must_have_artifact(self):
        policy = _make_manifest_policy(requirements=[
            {
                "id": "r1",
                "type": "mustHaveArtifact",
                "artifactPattern": "*.config",
                "severity": "required",
                "message": "need config artifact",
            },
        ])
        manifest = _make_manifest(spec={"artifacts": [{"key": "app.config", "category": "configuration"}]})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 0

    def test_agent_has_tool(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "agentHasTool", "toolId": "validate", "severity": "required", "message": "need validate tool"},
        ])
        manifest = _make_manifest(spec={"agents": [{"id": "dev", "tools": ["validate", "scan"]}]})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 0

    def test_field_expression(self):
        policy = _make_manifest_policy(requirements=[
            {"id": "r1", "type": "fieldExpression", "expression": "metadata.version !== '0.0.0'", "severity": "required", "message": "version not 0.0.0"},
        ])
        manifest = _make_manifest(version="1.0.0")
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 0

    def test_exempt_when_in_requirement(self):
        policy = _make_manifest_policy(requirements=[
            {
                "id": "r1",
                "type": "mustHaveAgent",
                "severity": "required",
                "message": "need agents",
                "exemptWhen": "metadata.group === 'governance'",
            },
        ])
        manifest = _make_manifest(extra_meta={"group": "governance"})
        result = evaluate_manifest_policy(policy, manifest)
        assert len(result.violations) == 0
        assert result.exempted_count == 1


# ═══════════════════════════════════════════════════════════════════════════════
# check_health
# ═══════════════════════════════════════════════════════════════════════════════


class TestCheckHealth:
    def test_empty_module(self):
        manifest = _make_manifest()
        result = check_health(manifest)
        assert isinstance(result, HealthResult)
        assert result.grade in ("A", "B", "C", "D", "F")
        assert result.max_score > 0
        # Identity fields (name, displayName, version) should contribute
        assert result.score > 0

    def test_full_module(self):
        manifest = _make_manifest(
            extra_meta={"description": "A great module"},
            spec={
                "agents": [{"id": "dev"}],
                "artifacts": [{"key": "cfg"}],
                "i18n": {"defaultLocale": "en"},
                "theme": {"default": "light"},
                "lifecycle": {"roadmap": []},
                "rules": [{"id": "r1"}],
                "guardrails": {"maxTokens": 1000},
            },
        )
        result = check_health(manifest)
        assert result.percentage == 100
        assert result.grade == "A"

    def test_categories_present(self):
        manifest = _make_manifest()
        result = check_health(manifest)
        cat_names = [cat.name for cat in result.categories]
        assert "Identity" in cat_names
        assert "Agents" in cat_names
        assert "Artifacts" in cat_names
        assert "i18n" in cat_names
        assert "Theme" in cat_names
        assert "Lifecycle" in cat_names
        assert "Governance" in cat_names

    def test_partial_identity(self):
        manifest = {"kind": "Module", "metadata": {"name": "test"}, "spec": {}}
        result = check_health(manifest)
        identity_cat = next(c for c in result.categories if c.name == "Identity")
        assert identity_cat.score >= 1
        assert identity_cat.score < identity_cat.max_score  # missing some identity fields
