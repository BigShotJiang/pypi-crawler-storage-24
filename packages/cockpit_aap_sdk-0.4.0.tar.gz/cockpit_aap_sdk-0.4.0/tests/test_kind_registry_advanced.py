"""Tests for KindRegistry advanced features — phases 1-3 + 6.

Tests:
  - ResolvedField dataclass
  - content_type and kind_ref on KindFieldSchema
  - resolve_schema() with kindRef expansion
  - scan() universal entry point
  - set_default_template()
  - get_field_content_type() standalone
  - create_kind_registry() factory
  - scan_kind_manifest() standalone
  - _resolve_spec_refs() helper
  - Generic parse_fn (Phase 6)
"""

from __future__ import annotations

import json
import os
import tempfile
from typing import Any

import pytest
import yaml

from cockpit_aap.manifest.kind_registry import (
    KindFieldSchema,
    KindRegistry,
    KindSchemaExport,
    ResolvedField,
    create_kind_registry,
    get_field_content_type,
    scan_kind_manifest,
    _resolve_spec_refs,
    kind_registry,
)


# ── Fixtures ───────────────────────────────────────────────────────────────────


@pytest.fixture
def fresh_registry() -> KindRegistry:
    """A clean registry with no built-in kinds."""
    return create_kind_registry()


@pytest.fixture
def registry_with_agent(fresh_registry: KindRegistry) -> KindRegistry:
    """Registry with a simple Agent kind."""
    fresh_registry.register(
        "Agent",
        api_version="agents.md/v1",
        description="AI agent",
        fields=[
            KindFieldSchema(path="metadata.name", type="string", required=True, description="id"),
            KindFieldSchema(path="spec.instruction", type="string", content_type="text/markdown"),
            KindFieldSchema(path="spec.soul", type="string", kind_ref="Soul"),
        ],
        sample={"apiVersion": "agents.md/v1", "kind": "Agent", "metadata": {"name": "test"}},
    )
    return fresh_registry


@pytest.fixture
def registry_with_refs(registry_with_agent: KindRegistry) -> KindRegistry:
    """Registry with Agent + Soul (for kindRef resolution)."""
    registry_with_agent.register(
        "Soul",
        api_version="soul.md/v1",
        description="AI soul",
        fields=[
            KindFieldSchema(path="metadata.name", type="string", required=True),
            KindFieldSchema(path="spec.identity", type="string", content_type="text/markdown"),
            KindFieldSchema(path="spec.agent", type="string", kind_ref="Agent"),
        ],
    )
    return registry_with_agent


# ── ResolvedField dataclass ────────────────────────────────────────────────────


class TestResolvedField:
    def test_basic_creation(self):
        rf = ResolvedField(path="spec.name", type="string")
        assert rf.path == "spec.name"
        assert rf.resolved_kind is None

    def test_with_resolved_kind(self):
        rf = ResolvedField(
            path="spec.soul",
            type="string",
            kind_ref="Soul",
            resolved_kind={"kind": "Soul", "fields": []},
        )
        assert rf.resolved_kind["kind"] == "Soul"

    def test_all_fields(self):
        rf = ResolvedField(
            path="spec.x",
            type="string",
            description="test",
            required=True,
            enum=["a", "b"],
            content_type="text/markdown",
            kind_ref="Agent",
            resolved_kind=None,
        )
        assert rf.content_type == "text/markdown"
        assert rf.kind_ref == "Agent"


# ── KindFieldSchema extensions ─────────────────────────────────────────────────


class TestKindFieldSchemaExtensions:
    def test_content_type(self):
        f = KindFieldSchema(path="spec.instruction", type="string", content_type="text/markdown")
        assert f.content_type == "text/markdown"

    def test_kind_ref(self):
        f = KindFieldSchema(path="spec.soul", type="string", kind_ref="Soul")
        assert f.kind_ref == "Soul"

    def test_defaults_none(self):
        f = KindFieldSchema(path="spec.name", type="string")
        assert f.content_type is None
        assert f.kind_ref is None


# ── KindSchemaExport extensions ────────────────────────────────────────────────


class TestKindSchemaExportExtensions:
    def test_to_dict_includes_content_type(self):
        export = KindSchemaExport(
            kind="Agent",
            api_version="agents.md/v1",
            fields=[KindFieldSchema(path="spec.instruction", type="string", content_type="text/markdown")],
        )
        d = export.to_dict()
        assert d["fields"][0]["contentType"] == "text/markdown"

    def test_to_dict_includes_kind_ref(self):
        export = KindSchemaExport(
            kind="Agent",
            api_version="agents.md/v1",
            fields=[KindFieldSchema(path="spec.soul", type="string", kind_ref="Soul")],
        )
        d = export.to_dict()
        assert d["fields"][0]["kindRef"] == "Soul"

    def test_to_dict_omits_none_content_type(self):
        export = KindSchemaExport(
            kind="Agent",
            api_version="agents.md/v1",
            fields=[KindFieldSchema(path="spec.name", type="string")],
        )
        d = export.to_dict()
        assert "contentType" not in d["fields"][0]
        assert "kindRef" not in d["fields"][0]

    def test_to_dict_includes_default_template(self):
        export = KindSchemaExport(
            kind="Agent",
            api_version="agents.md/v1",
            fields=[],
            default_template="<div>{{metadata.name}}</div>",
        )
        d = export.to_dict()
        assert d["defaultTemplate"] == "<div>{{metadata.name}}</div>"

    def test_to_dict_omits_none_default_template(self):
        export = KindSchemaExport(kind="Agent", api_version="agents.md/v1", fields=[])
        d = export.to_dict()
        assert "defaultTemplate" not in d

    def test_resolved_fields(self):
        export = KindSchemaExport(
            kind="Agent",
            api_version="agents.md/v1",
            fields=[],
            resolved_fields=[ResolvedField(path="spec.soul", type="string", kind_ref="Soul")],
        )
        assert len(export.resolved_fields) == 1
        assert export.resolved_fields[0].kind_ref == "Soul"


# ── register() with new params ────────────────────────────────────────────────


class TestRegisterExtended:
    def test_register_with_scan_fn(self, fresh_registry: KindRegistry):
        def scan(d: str) -> dict:
            return {"scanned": True}

        fresh_registry.register(
            "Custom",
            description="test",
            fields=[],
            scan_fn=scan,
        )
        assert fresh_registry.is_registered("Custom")

    def test_register_with_default_template(self, fresh_registry: KindRegistry):
        fresh_registry.register(
            "Custom",
            description="test",
            fields=[],
            default_template="<div>{{metadata.name}}</div>",
        )
        schemas = fresh_registry.to_json_list(["Custom"])
        assert schemas[0]["defaultTemplate"] == "<div>{{metadata.name}}</div>"


# ── scan() method ──────────────────────────────────────────────────────────────


class TestScan:
    def test_scan_delegates_to_scan_fn(self, fresh_registry: KindRegistry):
        """When scan_fn is registered, it is called."""
        captured = {}

        def custom_scan(directory: str) -> dict:
            captured["dir"] = directory
            return {"kind": "Custom", "scanned": True}

        fresh_registry.register(
            "Custom",
            api_version="test/v1",
            description="test",
            fields=[],
            scan_fn=custom_scan,
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_path = os.path.join(tmpdir, "manifest.yaml")
            with open(manifest_path, "w") as f:
                yaml.dump({"apiVersion": "test/v1", "kind": "Custom"}, f)

            result = fresh_registry.scan(tmpdir)
            assert result["scanned"] is True
            assert captured["dir"] == os.path.realpath(tmpdir)

    def test_scan_fallback_generic(self, fresh_registry: KindRegistry):
        """When no scan_fn, fallback reads YAML + resolves refs."""
        fresh_registry.register(
            "Simple",
            api_version="test/v1",
            description="test",
            fields=[],
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_path = os.path.join(tmpdir, "manifest.yaml")
            with open(manifest_path, "w") as f:
                yaml.dump({"apiVersion": "test/v1", "kind": "Simple", "spec": {"value": "hello"}}, f)

            result = fresh_registry.scan(tmpdir)
            assert result["kind"] == "Simple"
            assert result["spec"]["value"] == "hello"

    def test_scan_resolves_file_refs(self, fresh_registry: KindRegistry):
        """Fallback scan resolves file references in spec."""
        fresh_registry.register(
            "WithRefs",
            api_version="test/v1",
            description="test",
            fields=[],
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a referenced file
            instructions_dir = os.path.join(tmpdir, "agents")
            os.makedirs(instructions_dir)
            with open(os.path.join(instructions_dir, "analyst.md"), "w") as f:
                f.write("You are an analyst.")

            manifest_path = os.path.join(tmpdir, "manifest.yaml")
            with open(manifest_path, "w") as f:
                yaml.dump({
                    "apiVersion": "test/v1",
                    "kind": "WithRefs",
                    "spec": {"instruction": "agents/analyst.md"},
                }, f)

            result = fresh_registry.scan(tmpdir)
            assert result["spec"]["instruction"] == "You are an analyst."

    def test_scan_no_manifest_file(self, fresh_registry: KindRegistry):
        with tempfile.TemporaryDirectory() as tmpdir:
            with pytest.raises(FileNotFoundError, match="No manifest.yaml"):
                fresh_registry.scan(tmpdir)

    def test_scan_missing_kind_field(self, fresh_registry: KindRegistry):
        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_path = os.path.join(tmpdir, "manifest.yaml")
            with open(manifest_path, "w") as f:
                yaml.dump({"apiVersion": "test/v1"}, f)

            with pytest.raises(ValueError, match="missing the required 'kind' field"):
                fresh_registry.scan(tmpdir)

    def test_scan_unregistered_kind(self, fresh_registry: KindRegistry):
        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_path = os.path.join(tmpdir, "manifest.yaml")
            with open(manifest_path, "w") as f:
                yaml.dump({"apiVersion": "test/v1", "kind": "Unknown"}, f)

            with pytest.raises(ValueError, match='Unknown kind "Unknown"'):
                fresh_registry.scan(tmpdir)


# ── set_default_template() ─────────────────────────────────────────────────────


class TestSetDefaultTemplate:
    def test_set_template(self, registry_with_agent: KindRegistry):
        registry_with_agent.set_default_template("Agent", "<h1>{{metadata.name}}</h1>")
        schemas = registry_with_agent.to_json_list(["Agent"])
        assert schemas[0]["defaultTemplate"] == "<h1>{{metadata.name}}</h1>"

    def test_set_template_nonexistent_kind(self, fresh_registry: KindRegistry):
        """Setting template on non-existent kind is a no-op."""
        fresh_registry.set_default_template("Nonexistent", "<div/>")
        # No exception raised


# ── resolve_schema() ──────────────────────────────────────────────────────────


class TestResolveSchema:
    def test_basic_resolve(self, registry_with_agent: KindRegistry):
        result = registry_with_agent.resolve_schema("Agent")
        assert result.kind == "Agent"
        assert result.resolved_fields is not None
        assert len(result.resolved_fields) == 3

    def test_kindref_expanded(self, registry_with_refs: KindRegistry):
        result = registry_with_refs.resolve_schema("Agent")
        # The spec.soul field should have resolved_kind
        soul_field = [f for f in result.resolved_fields if f.path == "spec.soul"][0]
        assert soul_field.kind_ref == "Soul"
        assert soul_field.resolved_kind is not None
        assert soul_field.resolved_kind["kind"] == "Soul"
        assert soul_field.resolved_kind["apiVersion"] == "soul.md/v1"

    def test_circular_ref_protection(self, registry_with_refs: KindRegistry):
        """Agent → Soul → Agent should not cause infinite recursion."""
        result = registry_with_refs.resolve_schema("Agent", max_depth=5)
        soul_field = [f for f in result.resolved_fields if f.path == "spec.soul"][0]
        assert soul_field.resolved_kind is not None
        # Soul's spec.agent field refers back to Agent — should be resolved at depth-1
        soul_fields = soul_field.resolved_kind["fields"]
        agent_back_ref = [f for f in soul_fields if f.path == "spec.agent"][0]
        # At depth 5, should still eventually stop
        # Either resolved_kind is None (stopped) or it has content
        assert isinstance(agent_back_ref, ResolvedField)

    def test_max_depth_0(self, registry_with_refs: KindRegistry):
        """At max_depth=0, no kindRefs are resolved."""
        result = registry_with_refs.resolve_schema("Agent", max_depth=0)
        soul_field = [f for f in result.resolved_fields if f.path == "spec.soul"][0]
        assert soul_field.resolved_kind is None

    def test_unknown_kind(self, fresh_registry: KindRegistry):
        result = fresh_registry.resolve_schema("NonExistent")
        assert result.kind == "NonExistent"
        assert result.api_version == "unknown"
        assert result.resolved_fields == []


# ── get_field_content_type() ───────────────────────────────────────────────────


class TestGetFieldContentType:
    def test_exact_match(self):
        """Global registry should have Agent with spec.instruction → text/markdown."""
        ct = get_field_content_type("Agent", "spec.instruction")
        assert ct == "text/markdown"

    def test_not_found(self):
        ct = get_field_content_type("Agent", "spec.nonexistent.field")
        assert ct is None

    def test_unknown_kind(self):
        ct = get_field_content_type("UnknownKind12345", "spec.any")
        assert ct is None

    def test_module_instruction(self):
        """Module's agent instruction field doesn't have content_type in global registry by default."""
        # Module fields are defined in _register_builtin_kinds, which uses basic KindFieldSchema
        # without content_type on all fields
        ct = get_field_content_type("Module", "spec.agents[].instruction")
        assert ct is None  # Module doesn't declare content_type on this field


# ── create_kind_registry() ─────────────────────────────────────────────────────


class TestCreateKindRegistry:
    def test_creates_empty_registry(self):
        reg = create_kind_registry()
        assert reg.registered_kinds() == []

    def test_independent_of_global(self):
        reg = create_kind_registry()
        reg.register("Custom", description="test", fields=[])
        assert "Custom" not in kind_registry.registered_kinds() or True  # global may have Custom from other tests
        assert reg.is_registered("Custom")


# ── scan_kind_manifest() ──────────────────────────────────────────────────────


class TestScanKindManifest:
    def test_scans_module(self):
        """Should be able to scan a Module manifest via the global registry."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_path = os.path.join(tmpdir, "manifest.yaml")
            with open(manifest_path, "w") as f:
                yaml.dump({
                    "apiVersion": "cockpit.io/v1",
                    "kind": "Module",
                    "metadata": {"name": "test", "version": "1.0.0", "artifactPrefix": "test."},
                    "spec": {},
                }, f)

            result = scan_kind_manifest(tmpdir)
            assert result["kind"] == "Module"

    def test_scans_agent(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_path = os.path.join(tmpdir, "manifest.yaml")
            with open(manifest_path, "w") as f:
                yaml.dump({
                    "apiVersion": "agents.md/v1",
                    "kind": "Agent",
                    "metadata": {"name": "test-agent"},
                    "spec": {"instruction": "Do something."},
                }, f)

            result = scan_kind_manifest(tmpdir)
            assert result["kind"] == "Agent"


# ── _resolve_spec_refs() ──────────────────────────────────────────────────────


class TestResolveSpecRefs:
    def test_resolves_string_values(self):
        spec = {"instruction": "agents/analyst.md", "other": "plain text"}

        def mock_resolve(value: str, base_dir: str) -> str:
            if value == "agents/analyst.md":
                return "Resolved content"
            return value

        _resolve_spec_refs(spec, "/tmp", mock_resolve)
        assert spec["instruction"] == "Resolved content"
        assert spec["other"] == "plain text"

    def test_resolves_nested_dicts(self):
        spec = {"nested": {"ref": "agents/deep.md"}}

        def mock_resolve(value: str, base_dir: str) -> str:
            if value.endswith(".md"):
                return "Resolved"
            return value

        _resolve_spec_refs(spec, "/tmp", mock_resolve)
        assert spec["nested"]["ref"] == "Resolved"

    def test_resolves_list_items(self):
        spec = {"items": ["agents/a.md", "plain", {"nested": "agents/b.md"}]}

        def mock_resolve(value: str, base_dir: str) -> str:
            if value.endswith(".md"):
                return f"Resolved:{value}"
            return value

        _resolve_spec_refs(spec, "/tmp", mock_resolve)
        assert spec["items"][0] == "Resolved:agents/a.md"
        assert spec["items"][1] == "plain"
        assert spec["items"][2]["nested"] == "Resolved:agents/b.md"


# ── Generic parse_fn (Phase 6) ────────────────────────────────────────────────


class TestGenericParseFn:
    """Tests for the generic parse functions created by the scanners package."""

    def test_parse_agent_kind_not_supported(self):
        """Agent has has_parse=False, so parse_yaml should raise."""
        with pytest.raises(ValueError, match="does not support YAML-string parsing"):
            kind_registry.parse_yaml("kind: Agent\n", "Agent")

    def test_parse_blueprint_yaml(self):
        """Blueprint has has_parse=True, so it should parse successfully."""
        yaml_content = yaml.dump({
            "apiVersion": "planning.cockpit.io/v1",
            "kind": "Blueprint",
            "metadata": {"name": "test-bp"},
            "spec": {"overallProgress": 50, "phases": []},
        })
        result = kind_registry.parse_yaml(yaml_content, "Blueprint")
        assert result["kind"] == "Blueprint"
        assert result["spec"]["overallProgress"] == 50

    def test_parse_wrong_kind_raises(self):
        """Parsing YAML with wrong kind should raise ValueError."""
        yaml_content = yaml.dump({
            "apiVersion": "planning.cockpit.io/v1",
            "kind": "WrongKind",
            "metadata": {"name": "test"},
        })
        with pytest.raises(ValueError, match="Kind mismatch"):
            kind_registry.parse_yaml(yaml_content, "Blueprint")

    def test_parse_wrong_api_version_raises(self):
        yaml_content = yaml.dump({
            "apiVersion": "wrong/v1",
            "kind": "Blueprint",
            "metadata": {"name": "test"},
        })
        with pytest.raises(ValueError, match="apiVersion mismatch"):
            kind_registry.parse_yaml(yaml_content, "Blueprint")

    def test_parse_risk_profile(self):
        yaml_content = yaml.dump({
            "apiVersion": "governance.cockpit.io/v1",
            "kind": "RiskProfile",
            "metadata": {"name": "test-risk"},
            "spec": {"overallRiskLevel": "medium"},
        })
        result = kind_registry.parse_yaml(yaml_content, "RiskProfile")
        assert result["kind"] == "RiskProfile"

    def test_parse_invalid_yaml_type(self):
        with pytest.raises(ValueError, match="Expected YAML mapping"):
            kind_registry.parse_yaml("- list\n- of\n- items", "Blueprint")

    def test_parseable_kinds(self):
        """All kinds with has_parse=True should support parse_yaml."""
        parseable = [
            "AuditTrail", "Blueprint", "Certificate", "CodeQuality", "Compliance",
            "ConformancePolicy", "DataContract", "Experiment", "KindDescriptor",
            "Lens", "Lifecycle", "ManifestPolicy", "Metric", "ModelCard",
            "Package", "Policy", "RiskProfile", "SDLC", "SecurityScan",
            "TelemetryBlueprint", "TestReport", "ValueStream",
        ]
        for kind_name in parseable:
            entry = kind_registry._entries.get(kind_name)
            assert entry is not None, f"{kind_name} not registered"
            assert entry.parse_fn is not None, f"{kind_name} should have parse_fn"

    def test_non_parseable_kinds(self):
        """All kinds with has_parse=False should NOT have parse_fn."""
        non_parseable = [
            "Agent", "AgentCard", "Guardrail", "MCPServer", "MCPTool",
            "Memory", "Persona", "Pipeline", "Prompt", "Skill",
            "Soul", "Task",
        ]
        for kind_name in non_parseable:
            entry = kind_registry._entries.get(kind_name)
            assert entry is not None, f"{kind_name} not registered"
            assert entry.parse_fn is None, f"{kind_name} should NOT have parse_fn"
