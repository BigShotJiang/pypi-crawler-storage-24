"""Extended tests for meta.py — covers build_manifest, analyze_drift, serialization, read/write, upsert."""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from cockpit_aap.meta import (
    BootstrapMeta,
    ConflictInfo,
    DriftInfo,
    MetaAgentEntry,
    MetaArtifactEntry,
    MetaManifest,
    UpgradeStrategy,
    _classify_artifact_upgrade,
    _detect_agent_drift,
    _detect_artifact_drift,
    _escape_regex,
    _extract_manifest_value,
    _meta_agent_entry_to_dict,
    _meta_artifact_entry_to_dict,
    _meta_manifest_to_dict,
    _parse_meta_manifest,
    _preserve_drift_timestamps,
    analyze_drift,
    build_manifest,
    checksum,
    read_meta_manifest,
    resolve_upgrade_action,
    write_meta_manifest,
    _find_artifact_id,
    _create_meta_artifact,
    _upsert_meta_artifact,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_art_entry(drifted=False, category=None, drifted_at=None):
    return MetaArtifactEntry(
        id="art-1",
        source="created",
        default_checksum="sha256:aaa",
        server_checksum="sha256:bbb" if drifted else "sha256:aaa",
        drifted=drifted,
        drifted_at=drifted_at,
        artifact_category=category,
    )


def _make_agent_entry(drifted=False, drifted_at=None):
    return MetaAgentEntry(
        id="agent-1",
        source="created",
        default_checksum="sha256:aaa",
        server_checksum="sha256:bbb" if drifted else "sha256:aaa",
        drifted=drifted,
        drifted_at=drifted_at,
    )


def _make_manifest(artifacts=None, agents=None, module="test", version="1.0.0"):
    return MetaManifest(
        module=module,
        code_version=version,
        bootstrapped_at="2024-01-01T00:00:00Z",
        artifacts=artifacts or {},
        agents=agents or {},
    )


# ---------------------------------------------------------------------------
# _escape_regex
# ---------------------------------------------------------------------------


def test_escape_regex():
    assert _escape_regex("my.module") == r"my\.module"
    assert _escape_regex("test[1]") == r"test\[1\]"


# ---------------------------------------------------------------------------
# _extract_manifest_value
# ---------------------------------------------------------------------------


class TestExtractManifestValue:
    def test_none_input(self):
        assert _extract_manifest_value(None) is None

    def test_non_dict_input(self):
        assert _extract_manifest_value("string") is None

    def test_empty_dict(self):
        assert _extract_manifest_value({}) is None

    def test_artifacts_wrapper(self):
        content = {"artifacts": [{"value": '{"module": "test"}'}]}
        assert _extract_manifest_value(content) == '{"module": "test"}'

    def test_artifacts_empty_list(self):
        assert _extract_manifest_value({"artifacts": []}) is None

    def test_artifacts_no_value(self):
        assert _extract_manifest_value({"artifacts": [{"id": "123"}]}) is None

    def test_direct_value(self):
        assert _extract_manifest_value({"value": "hello"}) == "hello"

    def test_content_key(self):
        assert _extract_manifest_value({"content": "world"}) == "world"

    def test_non_string_value(self):
        assert _extract_manifest_value({"value": 42}) is None


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


class TestSerialization:
    def test_meta_artifact_entry_to_dict_basic(self):
        entry = _make_art_entry()
        d = _meta_artifact_entry_to_dict(entry)
        assert d["id"] == "art-1"
        assert d["source"] == "created"
        assert d["defaultChecksum"] == "sha256:aaa"
        assert d["serverChecksum"] == "sha256:aaa"
        assert d["drifted"] is False
        assert "driftedAt" not in d
        assert "artifactCategory" not in d

    def test_meta_artifact_entry_to_dict_with_drift(self):
        entry = _make_art_entry(drifted=True, drifted_at="2024-01-15T00:00:00Z", category="state")
        d = _meta_artifact_entry_to_dict(entry)
        assert d["drifted"] is True
        assert d["driftedAt"] == "2024-01-15T00:00:00Z"
        assert d["artifactCategory"] == "state"

    def test_meta_agent_entry_to_dict_basic(self):
        entry = _make_agent_entry()
        d = _meta_agent_entry_to_dict(entry)
        assert d["id"] == "agent-1"
        assert "driftedAt" not in d

    def test_meta_agent_entry_to_dict_with_drift(self):
        entry = _make_agent_entry(drifted=True, drifted_at="2024-02-01T00:00:00Z")
        d = _meta_agent_entry_to_dict(entry)
        assert d["driftedAt"] == "2024-02-01T00:00:00Z"

    def test_meta_manifest_to_dict(self):
        m = _make_manifest(
            artifacts={"k1": _make_art_entry()},
            agents={"a1": _make_agent_entry()},
        )
        d = _meta_manifest_to_dict(m)
        assert d["module"] == "test"
        assert d["codeVersion"] == "1.0.0"
        assert "k1" in d["artifacts"]
        assert "a1" in d["agents"]

    def test_parse_meta_manifest_roundtrip(self):
        m = _make_manifest(
            artifacts={"k1": _make_art_entry(drifted=True, drifted_at="2024-01-01", category="configuration")},
            agents={"a1": _make_agent_entry(drifted=True, drifted_at="2024-02-01")},
        )
        d = _meta_manifest_to_dict(m)
        parsed = _parse_meta_manifest(d)
        assert parsed.module == "test"
        assert parsed.artifacts["k1"].drifted is True
        assert parsed.artifacts["k1"].drifted_at == "2024-01-01"
        assert parsed.artifacts["k1"].artifact_category == "configuration"
        assert parsed.agents["a1"].drifted is True
        assert parsed.agents["a1"].drifted_at == "2024-02-01"

    def test_parse_meta_manifest_defaults(self):
        raw = {"module": "m", "bootstrappedAt": "2024-01-01T00:00:00Z"}
        parsed = _parse_meta_manifest(raw)
        assert parsed.code_version == "0.0.0"
        assert parsed.artifacts == {}
        assert parsed.agents == {}


# ---------------------------------------------------------------------------
# build_manifest
# ---------------------------------------------------------------------------


class TestBuildManifest:
    def test_build_from_dicts(self):
        definition = {
            "module": "my-mod",
            "version": "2.0.0",
            "artifacts": [
                {"key": "config.theme", "defaultValue": "dark"},
                {"key": "state.counter", "defaultValue": "0", "artifactCategory": "state"},
            ],
            "agents": [
                {"name": "dev", "defaultInstruction": "You are a developer."},
            ],
        }
        resolved_artifacts = {
            "config.theme": {"id": "uuid-1", "source": "created", "value": "dark"},
            "state.counter": {"id": "uuid-2", "source": "created", "value": "0"},
        }
        resolved_agents = {
            "dev": {"id": "uuid-3", "source": "created", "instruction": "You are a developer."},
        }
        result = build_manifest(
            type("D", (), definition)(),  # Can't use dict directly, build_manifest uses getattr
            resolved_artifacts,
            resolved_agents,
        )
        assert result.module == "my-mod"
        assert result.code_version == "2.0.0"
        assert "config.theme" in result.artifacts
        assert "state.counter" in result.artifacts
        assert result.artifacts["state.counter"].artifact_category == "state"
        assert result.artifacts["state.counter"].drifted is False  # state never drifts
        assert "dev" in result.agents

    def test_build_from_dataclass_like(self):
        @dataclass
        class ArtDef:
            key: str
            default_value: str
            artifact_category: str | None = None

        @dataclass
        class AgentDef:
            name: str
            default_instruction: str

        @dataclass
        class Def:
            module: str
            version: str
            artifacts: list
            agents: list

        definition = Def(
            module="mod2",
            version="1.0.0",
            artifacts=[ArtDef(key="k1", default_value="v1")],
            agents=[AgentDef(name="bot", default_instruction="Be helpful")],
        )
        resolved_artifacts = {"k1": {"id": "id-1", "source": "found", "value": "v1-server"}}
        resolved_agents = {"bot": {"id": "id-2", "source": "created", "instruction": "Be helpful"}}

        result = build_manifest(definition, resolved_artifacts, resolved_agents)
        assert result.module == "mod2"
        assert result.artifacts["k1"].drifted is True  # v1 != v1-server
        assert result.agents["bot"].drifted is False

    def test_build_skips_unresolved(self):
        definition = {
            "module": "m",
            "version": "1.0.0",
            "artifacts": [{"key": "missing", "defaultValue": "x"}],
            "agents": [{"name": "missing-agent", "defaultInstruction": "x"}],
        }
        result = build_manifest(
            type("D", (), definition)(),
            {},  # no resolved
            {},
        )
        assert len(result.artifacts) == 0
        assert len(result.agents) == 0

    def test_build_no_artifacts_or_agents(self):
        definition = {"module": "bare", "version": None}
        result = build_manifest(type("D", (), definition)(), {}, {})
        assert result.module == "bare"
        assert result.code_version == "0.0.0"


# ---------------------------------------------------------------------------
# analyze_drift
# ---------------------------------------------------------------------------


class TestAnalyzeDrift:
    def test_no_old_manifest(self):
        new = _make_manifest(
            artifacts={"k1": _make_art_entry(drifted=True, drifted_at="2024-01-01")},
            agents={"a1": _make_agent_entry(drifted=True, drifted_at="2024-01-01")},
        )
        result = analyze_drift(new, None, "server-wins")
        assert "k1" in result.drifted_artifacts
        assert "agent:a1" in result.drifted_artifacts
        assert result.conflicts == {}
        assert result.upgraded == []

    def test_state_artifacts_not_in_drift(self):
        new = _make_manifest(
            artifacts={"state.x": _make_art_entry(drifted=True, category="state")},
        )
        result = analyze_drift(new, None, "server-wins")
        assert "state.x" not in result.drifted_artifacts

    def test_code_changed_no_server_drift_upgrades(self):
        old = _make_manifest(
            artifacts={"k1": MetaArtifactEntry(
                id="1", source="created",
                default_checksum="sha256:old", server_checksum="sha256:old",
                drifted=False,
            )},
        )
        new = _make_manifest(
            artifacts={"k1": MetaArtifactEntry(
                id="1", source="created",
                default_checksum="sha256:new", server_checksum="sha256:new",
                drifted=False,  # no drift: server matches new default
            )},
        )
        result = analyze_drift(new, old, "server-wins")
        assert "k1" in result.upgraded

    def test_code_changed_server_drifted_conflict(self):
        old = _make_manifest(
            artifacts={"k1": MetaArtifactEntry(
                id="1", source="created",
                default_checksum="sha256:old", server_checksum="sha256:old",
                drifted=True,  # server drifted
            )},
        )
        new = _make_manifest(
            artifacts={"k1": MetaArtifactEntry(
                id="1", source="created",
                default_checksum="sha256:new", server_checksum="sha256:srv",
                drifted=True,
            )},
        )
        result = analyze_drift(new, old, "code-wins")
        assert "k1" in result.conflicts
        assert result.conflicts["k1"].resolution == "code-wins"

    def test_preserve_drift_timestamps(self):
        old = _make_manifest(
            artifacts={"k1": MetaArtifactEntry(
                id="1", source="created",
                default_checksum="sha256:a", server_checksum="sha256:b",
                drifted=True, drifted_at="2024-01-01T00:00:00Z",
            )},
            agents={"a1": MetaAgentEntry(
                id="1", source="created",
                default_checksum="sha256:a", server_checksum="sha256:b",
                drifted=True, drifted_at="2024-02-01T00:00:00Z",
            )},
        )
        new = _make_manifest(
            artifacts={"k1": MetaArtifactEntry(
                id="1", source="created",
                default_checksum="sha256:a", server_checksum="sha256:b",
                drifted=True, drifted_at=None,
            )},
            agents={"a1": MetaAgentEntry(
                id="1", source="created",
                default_checksum="sha256:a", server_checksum="sha256:b",
                drifted=True, drifted_at=None,
            )},
        )
        analyze_drift(new, old, "server-wins")
        assert new.artifacts["k1"].drifted_at == "2024-01-01T00:00:00Z"
        assert new.agents["a1"].drifted_at == "2024-02-01T00:00:00Z"


# ---------------------------------------------------------------------------
# read_meta_manifest / write_meta_manifest
# ---------------------------------------------------------------------------


class TestReadWriteMetaManifest:
    @pytest.mark.asyncio
    async def test_read_meta_manifest_success(self):
        meta_data = {
            "module": "test-mod",
            "codeVersion": "1.0.0",
            "bootstrappedAt": "2024-01-01T00:00:00Z",
            "artifacts": {},
            "agents": {},
        }
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={
            "artifacts": [{"value": json.dumps(meta_data)}]
        })
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_meta_manifest(mock_sdk, "ns", "test-mod")
        assert result is not None
        assert result.module == "test-mod"
        assert result.code_version == "1.0.0"

    @pytest.mark.asyncio
    async def test_read_meta_manifest_not_found(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_meta_manifest(mock_sdk, "ns", "missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_read_meta_manifest_empty_value(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": []})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_meta_manifest(mock_sdk, "ns", "mod")
        assert result is None

    @pytest.mark.asyncio
    async def test_read_meta_manifest_with_content_attr(self):
        """Test when result has .content attribute instead of being a dict directly."""
        meta_data = {
            "module": "attr-mod",
            "codeVersion": "2.0.0",
            "bootstrappedAt": "2024-06-01T00:00:00Z",
            "artifacts": {},
            "agents": {},
        }

        class ResultObj:
            content = {"value": json.dumps(meta_data)}

        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value=ResultObj())
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_meta_manifest(mock_sdk, "ns", "attr-mod")
        assert result is not None
        assert result.module == "attr-mod"

    @pytest.mark.asyncio
    async def test_write_meta_manifest(self):
        meta = _make_manifest()
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        # _find_artifact_id will be called — simulate not found
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_ns.create_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await write_meta_manifest(mock_sdk, "ns", "test", meta)
        mock_ns.create_artifact.assert_called_once()


# ---------------------------------------------------------------------------
# _find_artifact_id
# ---------------------------------------------------------------------------


class TestFindArtifactId:
    @pytest.mark.asyncio
    async def test_find_from_artifacts_list(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={
            "artifacts": [{"id": "uuid-123", "value": "x"}]
        })
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await _find_artifact_id(mock_sdk, "ns", "my.key")
        assert result == "uuid-123"

    @pytest.mark.asyncio
    async def test_find_from_artifact_id_field(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={
            "artifacts": [{"artifact_id": "uuid-456"}]
        })
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await _find_artifact_id(mock_sdk, "ns", "my.key")
        assert result == "uuid-456"

    @pytest.mark.asyncio
    async def test_find_from_direct_id(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"id": "uuid-789"})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await _find_artifact_id(mock_sdk, "ns", "my.key")
        assert result == "uuid-789"

    @pytest.mark.asyncio
    async def test_find_returns_none_on_error(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("fail"))
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await _find_artifact_id(mock_sdk, "ns", "my.key")
        assert result is None

    @pytest.mark.asyncio
    async def test_find_returns_none_on_empty(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await _find_artifact_id(mock_sdk, "ns", "my.key")
        assert result is None

    @pytest.mark.asyncio
    async def test_find_returns_none_on_non_dict(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value="not-a-dict")
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await _find_artifact_id(mock_sdk, "ns", "my.key")
        assert result is None


# ---------------------------------------------------------------------------
# _upsert_meta_artifact
# ---------------------------------------------------------------------------


class TestUpsertMetaArtifact:
    @pytest.mark.asyncio
    async def test_upsert_creates_when_not_found(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_ns.create_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await _upsert_meta_artifact(mock_sdk, "ns", "key", "val", "desc", "mod")
        mock_ns.create_artifact.assert_called_once()

    @pytest.mark.asyncio
    async def test_upsert_updates_when_found(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": [{"id": "uuid-1"}]})
        mock_ns.update_artifact = AsyncMock(return_value={"success": True})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await _upsert_meta_artifact(mock_sdk, "ns", "key", "val", "desc", "mod")
        mock_ns.update_artifact.assert_called_once()

    @pytest.mark.asyncio
    async def test_upsert_falls_back_to_create_on_update_failure(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": [{"id": "uuid-1"}]})
        mock_ns.update_artifact = AsyncMock(side_effect=Exception("update failed"))
        mock_ns.create_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await _upsert_meta_artifact(mock_sdk, "ns", "key", "val", "desc", "mod")
        mock_ns.create_artifact.assert_called_once()

    @pytest.mark.asyncio
    async def test_upsert_falls_back_on_success_false(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": [{"id": "uuid-1"}]})
        mock_ns.update_artifact = AsyncMock(return_value={"success": False})
        mock_ns.create_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await _upsert_meta_artifact(mock_sdk, "ns", "key", "val", "desc", "mod")
        mock_ns.create_artifact.assert_called_once()

    @pytest.mark.asyncio
    async def test_upsert_handles_content_attr_on_update_result(self):
        """When update_result has .content attribute."""
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": [{"id": "uuid-1"}]})

        class UpdateResult:
            content = {"success": True}

        mock_ns.update_artifact = AsyncMock(return_value=UpdateResult())
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await _upsert_meta_artifact(mock_sdk, "ns", "key", "val", "desc", "mod")
        mock_ns.update_artifact.assert_called_once()


# ---------------------------------------------------------------------------
# resolve_upgrade_action — drifted via old_entry.drifted=True
# ---------------------------------------------------------------------------


class TestResolveUpgradeActionExtended:
    def test_code_changed_old_drifted_returns_strategy(self):
        old = _make_manifest(
            artifacts={"k1": MetaArtifactEntry(
                id="1", source="created",
                default_checksum="sha256:old", server_checksum="sha256:old",
                drifted=True,  # marked as drifted
            )},
        )
        result = resolve_upgrade_action(
            key="k1",
            new_default_checksum="sha256:new",
            current_server_checksum="sha256:old",  # same as default
            old_manifest=old,
            strategy="log-warning",
        )
        assert result == "log-warning"
