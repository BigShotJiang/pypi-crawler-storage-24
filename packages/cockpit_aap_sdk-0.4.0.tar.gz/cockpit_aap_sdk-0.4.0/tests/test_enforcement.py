"""Tests for cockpit_aap.enforcement — governance enforcement logic."""

from cockpit_aap.enforcement import (
    GovernanceWarningLight,
    GovernanceEnforcementResult,
    validate_enforcement_mode,
)


def test_advisory_mode_never_blocks():
    warnings = [
        GovernanceWarningLight(kind="telemetry", severity="critical", message="no telemetry"),
        GovernanceWarningLight(kind="lifecycle", severity="high", message="no lifecycle"),
    ]
    result = validate_enforcement_mode(warnings, "advisory")
    assert result.blocked is False
    assert result.block_reason is None
    assert len(result.warnings) == 2


def test_hard_mode_no_critical_not_blocked():
    warnings = [
        GovernanceWarningLight(kind="lifecycle", severity="high", message="high issue"),
        GovernanceWarningLight(kind="theme", severity="low", message="low issue"),
    ]
    result = validate_enforcement_mode(warnings, "hard")
    assert result.blocked is False
    assert result.block_reason is None


def test_hard_mode_with_critical_blocks():
    warnings = [
        GovernanceWarningLight(kind="telemetry", severity="critical", message="missing telemetry"),
        GovernanceWarningLight(kind="access", severity="critical", message="no RBAC"),
        GovernanceWarningLight(kind="lifecycle", severity="medium", message="no lifecycle"),
    ]
    result = validate_enforcement_mode(warnings, "hard")
    assert result.blocked is True
    assert result.block_reason is not None
    assert "2 critical governance gap(s)" in result.block_reason
    assert "telemetry" in result.block_reason
    assert "access" in result.block_reason


def test_hard_mode_empty_warnings():
    result = validate_enforcement_mode([], "hard")
    assert result.blocked is False
    assert result.warnings == []


def test_advisory_mode_empty_warnings():
    result = validate_enforcement_mode([], "advisory")
    assert result.blocked is False
