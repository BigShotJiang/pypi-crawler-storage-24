"""Tests for cockpit_aap.adapters.local_fs_storage — LocalFSStorage."""

import os
import tempfile
import pytest

from cockpit_aap.adapters.local_fs_storage import (
    LocalFSStorage,
    create_local_fs_storage,
)


@pytest.fixture
def storage_dir():
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.mark.asyncio
async def test_write_and_read(storage_dir):
    storage = create_local_fs_storage(storage_dir)
    url = await storage.write("hello.txt", "Hello World")
    assert url.startswith("file://")
    content = await storage.read("hello.txt")
    assert content == b"Hello World"


@pytest.mark.asyncio
async def test_write_bytes(storage_dir):
    storage = LocalFSStorage(storage_dir)
    await storage.write("binary.bin", b"\x00\x01\x02")
    content = await storage.read("binary.bin")
    assert content == b"\x00\x01\x02"


@pytest.mark.asyncio
async def test_exists(storage_dir):
    storage = LocalFSStorage(storage_dir)
    assert await storage.exists("nope.txt") is False
    await storage.write("yes.txt", "data")
    assert await storage.exists("yes.txt") is True


@pytest.mark.asyncio
async def test_delete(storage_dir):
    storage = LocalFSStorage(storage_dir)
    await storage.write("del.txt", "data")
    await storage.delete("del.txt")
    assert await storage.exists("del.txt") is False


@pytest.mark.asyncio
async def test_delete_missing(storage_dir):
    storage = LocalFSStorage(storage_dir)
    await storage.delete("nonexistent.txt")  # should not raise


@pytest.mark.asyncio
async def test_list(storage_dir):
    storage = LocalFSStorage(storage_dir)
    await storage.write("a.txt", "1")
    await storage.write("b.txt", "2")
    entries = await storage.list()
    paths = {e.path for e in entries}
    assert paths == {"a.txt", "b.txt"}


@pytest.mark.asyncio
async def test_list_empty(storage_dir):
    storage = LocalFSStorage(storage_dir)
    assert await storage.list() == []


@pytest.mark.asyncio
async def test_nested_directories(storage_dir):
    storage = LocalFSStorage(storage_dir)
    await storage.write("sub/dir/file.txt", "nested")
    content = await storage.read("sub/dir/file.txt")
    assert content == b"nested"
