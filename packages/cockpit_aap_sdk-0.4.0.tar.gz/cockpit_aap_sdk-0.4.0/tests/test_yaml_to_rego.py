"""Test YAML-to-Rego compiler produces valid Rego."""
from cockpit_aap.adapters.yaml_to_rego import compile_to_rego


def test_required_field():
    rego = compile_to_rego(
        id="mod-conf",
        applies_to="Module",
        requirements=[
            {"id": "must-have-name", "field": "metadata.name", "severity": "required", "message": "Name required"},
        ],
    )
    assert "package aap.conformance.mod_conf" in rego
    assert "not input.manifest.metadata.name" in rego
    assert '"severity": "error"' in rego


def test_forbidden_field():
    rego = compile_to_rego(
        id="no-legacy",
        applies_to="*",
        requirements=[
            {"id": "no-legacy", "field": "spec.legacy", "severity": "forbidden", "message": "Forbidden"},
        ],
    )
    assert "input.manifest.spec.legacy" in rego


def test_exempt_when():
    rego = compile_to_rego(
        id="exempt",
        applies_to="Module",
        requirements=[
            {
                "id": "needs-theme",
                "field": "spec.theme",
                "severity": "recommended",
                "message": "Theme recommended",
                "exemptWhen": ["metadata.group == 'demo'"],
            },
        ],
    )
    assert 'input.manifest.metadata.group != "demo"' in rego


def test_condition_length():
    rego = compile_to_rego(
        id="agents",
        applies_to="Module",
        requirements=[
            {"id": "min-agents", "field": "spec.agents", "severity": "required", "condition": "length >= 1", "message": "Need agents"},
        ],
    )
    assert "count(" in rego
