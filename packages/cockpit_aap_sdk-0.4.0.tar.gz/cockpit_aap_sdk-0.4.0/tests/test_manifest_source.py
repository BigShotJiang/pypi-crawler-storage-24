# packages/py/tests/test_manifest_source.py
"""Integration tests for ManifestSource adapters — uses Testcontainers for Postgres."""

import pytest
import pytest_asyncio
import asyncpg
from pathlib import Path
from testcontainers.postgres import PostgresContainer

from cockpit_aap.adapters.filesystem_manifest_source import create_filesystem_manifest_source
from cockpit_aap.adapters.postgres_manifest_source import create_postgres_manifest_source

TEST_SCHEMA = "test_py_manifest_source"

# Manifest real do repo para testar FileSystemManifestSource
REPO_ROOT = Path(__file__).parent.parent.parent.parent
LAUNCHPAD_AAP_DIR = REPO_ROOT / "apps" / "aap-launchpad" / ".aap"


# ── FileSystem tests ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_filesystem_load_existing_module():
    source = create_filesystem_manifest_source(str(LAUNCHPAD_AAP_DIR))
    manifest = await source.load("aap-launchpad")
    assert manifest.metadata.name == "aap-launchpad"


@pytest.mark.asyncio
async def test_filesystem_load_nonexistent_raises():
    source = create_filesystem_manifest_source(str(LAUNCHPAD_AAP_DIR))
    with pytest.raises(ValueError, match="Manifest not found"):
        await source.load("nonexistent-xyz")


@pytest.mark.asyncio
async def test_filesystem_list():
    source = create_filesystem_manifest_source(str(LAUNCHPAD_AAP_DIR))
    entries = await source.list()
    assert isinstance(entries, list)
    assert len(entries) > 0
    ids = [e.id for e in entries]
    assert "aap-launchpad" in ids
    launchpad = next(e for e in entries if e.id == "aap-launchpad")
    assert launchpad.kind == "Module"
    assert launchpad.source is not None and "filesystem:" in launchpad.source


@pytest.mark.asyncio
async def test_filesystem_list_filters_by_kind():
    source = create_filesystem_manifest_source(str(LAUNCHPAD_AAP_DIR))
    modules = await source.list("Module")
    assert len(modules) > 0
    assert all(e.kind == "Module" for e in modules)


# ── Postgres tests (Testcontainers) ─────────────────────────────────────────

@pytest.fixture(scope="module")
def pg_container():
    with PostgresContainer("postgres:16-alpine") as container:
        yield container


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def pool(pg_container):
    p = await asyncpg.create_pool(dsn=pg_container.get_connection_url().replace(
        "postgresql+psycopg2://", "postgresql://"
    ))
    await p.execute(f"CREATE SCHEMA IF NOT EXISTS {TEST_SCHEMA}")
    yield p
    await p.execute(f"DROP SCHEMA IF EXISTS {TEST_SCHEMA} CASCADE")
    await p.close()


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def pg_source(pool):
    s = create_postgres_manifest_source(pool, schema=TEST_SCHEMA)
    await s.setup()
    return s


SAMPLE_MANIFEST_DICT = {
    "apiVersion": "cockpit.io/v1",
    "kind": "Module",
    "metadata": {"name": "test-module", "displayName": "Test Module", "version": "1.0.0"},
    "spec": {"agents": [], "artifacts": []},
}


@pytest.mark.asyncio(loop_scope="module")
async def test_postgres_setup_idempotente(pg_source):
    await pg_source.setup()
    assert await pg_source.schema_version() == 1


@pytest.mark.asyncio(loop_scope="module")
async def test_postgres_save_load_roundtrip(pg_source):
    await pg_source.save("test-module", "Module", SAMPLE_MANIFEST_DICT)
    loaded = await pg_source.load("test-module", "Module")
    assert loaded.metadata.name == "test-module"
    assert loaded.metadata.version == "1.0.0"


@pytest.mark.asyncio(loop_scope="module")
async def test_postgres_load_not_found(pg_source):
    with pytest.raises(ValueError, match="Manifest not found"):
        await pg_source.load("nonexistent-xyz", "Module")


@pytest.mark.asyncio(loop_scope="module")
async def test_postgres_save_upsert(pg_source):
    updated = {**SAMPLE_MANIFEST_DICT, "metadata": {**SAMPLE_MANIFEST_DICT["metadata"], "version": "2.0.0"}}
    await pg_source.save("test-module", "Module", updated)
    loaded = await pg_source.load("test-module", "Module")
    assert loaded.metadata.version == "2.0.0"


@pytest.mark.asyncio(loop_scope="module")
async def test_postgres_list(pg_source):
    await pg_source.save("module-a", "Module", {**SAMPLE_MANIFEST_DICT, "metadata": {**SAMPLE_MANIFEST_DICT["metadata"], "name": "module-a"}})
    await pg_source.save("module-b", "Module", {**SAMPLE_MANIFEST_DICT, "metadata": {**SAMPLE_MANIFEST_DICT["metadata"], "name": "module-b"}})
    entries = await pg_source.list()
    ids = [e.id for e in entries]
    assert "test-module" in ids
    assert "module-a" in ids
    assert "module-b" in ids
    # Verify ManifestEntry structure
    first = entries[0]
    assert hasattr(first, "id")
    assert hasattr(first, "kind")
    assert hasattr(first, "source")
    assert first.source is not None and "postgres:" in first.source


@pytest.mark.asyncio(loop_scope="module")
async def test_postgres_list_by_kind(pg_source):
    entries = await pg_source.list("Module")
    ids = [e.id for e in entries]
    assert "test-module" in ids
    assert all(e.kind == "Module" for e in entries)
