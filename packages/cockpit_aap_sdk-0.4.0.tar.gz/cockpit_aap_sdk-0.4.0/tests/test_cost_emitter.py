"""Tests for cockpit_aap.cost.emitter — CostEmitter."""
from cockpit_aap.cost.emitter import CostEmitter
from cockpit_aap.cost.policy import CostPolicyReader

SPEC = {
    "models": {"gpt-4o": {"inputPer1k": 0.005, "outputPer1k": 0.015}},
    "budgets": [],
}


def test_emit_calculates_cost():
    emitter = CostEmitter(
        policy=CostPolicyReader(SPEC),
        module_id="test-module",
        agent_id="test-agent",
        tenant_id="test:tenant",
    )
    cost = emitter.emit("gpt-4o", input_tokens=1000, output_tokens=500)
    assert abs(cost - 0.0125) < 0.0001


def test_emit_unknown_model_returns_zero():
    emitter = CostEmitter(
        policy=CostPolicyReader(SPEC),
        module_id="test",
        agent_id="test",
        tenant_id="test",
    )
    cost = emitter.emit("unknown-model", input_tokens=1000, output_tokens=500)
    assert cost == 0.0
