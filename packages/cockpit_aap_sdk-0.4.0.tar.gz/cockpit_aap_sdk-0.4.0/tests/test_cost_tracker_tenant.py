import pytest
import time
from cockpit_aap.adapters.in_memory_cost_tracker import InMemoryCostTracker
from cockpit_aap.ports.cost_tracker import CostUsage, CostFilter


@pytest.mark.asyncio
async def test_record_stores_tenant_id():
    tracker = InMemoryCostTracker(models={"gpt-5.4": {"input_per_1k": 0.005, "output_per_1k": 0.015}})
    await tracker.record(CostUsage(agent_id="a", model="gpt-5.4", input_tokens=100, output_tokens=50, timestamp=time.time()*1000, tenant_id="acme:team-1"))
    result = await tracker.query(CostFilter(tenant_id="acme:team-1"))
    assert len(result.entries) == 1
    assert result.entries[0].tenant_id == "acme:team-1"


@pytest.mark.asyncio
async def test_query_filters_by_tenant():
    tracker = InMemoryCostTracker(models={"gpt-5.4": {"input_per_1k": 0.005, "output_per_1k": 0.015}})
    await tracker.record(CostUsage(agent_id="a", model="gpt-5.4", input_tokens=100, output_tokens=50, timestamp=time.time()*1000, tenant_id="acme:team-1"))
    await tracker.record(CostUsage(agent_id="a", model="gpt-5.4", input_tokens=200, output_tokens=100, timestamp=time.time()*1000, tenant_id="acme:team-2"))
    t1 = await tracker.query(CostFilter(tenant_id="acme:team-1"))
    assert len(t1.entries) == 1
    all_entries = await tracker.query(CostFilter())
    assert len(all_entries.entries) == 2


@pytest.mark.asyncio
async def test_query_timeseries():
    tracker = InMemoryCostTracker(models={"gpt-5.4": {"input_per_1k": 0.005, "output_per_1k": 0.015}})
    now = time.time() * 1000
    await tracker.record(CostUsage(agent_id="a", model="gpt-5.4", input_tokens=100, output_tokens=50, timestamp=now, tenant_id="acme:team-1"))
    ts = await tracker.query_timeseries(CostFilter(tenant_id="acme:team-1"), granularity="hour")
    assert len(ts) >= 1
    assert hasattr(ts[0], "bucket")
    assert hasattr(ts[0], "cost")
    assert hasattr(ts[0], "requests")
