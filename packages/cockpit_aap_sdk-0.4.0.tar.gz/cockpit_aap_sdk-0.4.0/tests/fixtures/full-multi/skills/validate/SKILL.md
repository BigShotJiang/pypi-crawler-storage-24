# Validate Skill

Automatically validates manifest structure on save.
