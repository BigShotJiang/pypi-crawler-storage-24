# Validate Command

Run validation checks on the current module to ensure compliance.
