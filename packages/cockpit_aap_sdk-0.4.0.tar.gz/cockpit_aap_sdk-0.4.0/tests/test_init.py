"""Tests for cockpit_aap.__init__ — package-level imports and optional extras."""

from __future__ import annotations


def test_create_manifest_mcp_server_exported_when_fastmcp_available() -> None:
    """create_manifest_mcp_server must appear in __all__ when fastmcp is installed."""
    import cockpit_aap

    # fastmcp is in dev deps — this import should always succeed in test environments
    assert "create_manifest_mcp_server" in cockpit_aap.__all__
    assert hasattr(cockpit_aap, "create_manifest_mcp_server")


def test_package_exports_all_core_symbols() -> None:
    """All core symbols must be present in __all__ regardless of optional extras."""
    import cockpit_aap

    core_symbols = [
        "AAPGatewayClient",
        "Transport",
        "RestTransport",
        "McpTransport",
        "bootstrap_manifest",
        "ManifestResult",
        "Manifest",
        "scan_manifest",
        "parse_manifest",
    ]
    for sym in core_symbols:
        assert sym in cockpit_aap.__all__, f"{sym} missing from __all__"
        assert hasattr(cockpit_aap, sym), f"{sym} not importable from cockpit_aap"
