"""Tests for MCP transport prompts & resources (JSON-RPC 2.0)."""

from __future__ import annotations

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
from typing import Any

import pytest

from cockpit_aap.mcp_types import PromptSchema, ResourceSchema, ResourceTemplate
from cockpit_aap.transport import TransportContext
from cockpit_aap.transports.mcp import McpTransport

# ---------------------------------------------------------------------------
# Mock data
# ---------------------------------------------------------------------------

MOCK_TOOLS = [
    {"name": "tool1", "description": "A tool", "inputSchema": {}},
]

MOCK_PROMPTS = [
    {
        "name": "summarize",
        "description": "Summarize text",
        "arguments": [
            {"name": "text", "description": "Text to summarize", "required": True},
            {"name": "style", "description": "Summary style"},
        ],
    },
    {
        "name": "translate",
        "description": "Translate text",
        "arguments": [
            {"name": "text", "required": True},
            {"name": "target_lang", "required": True},
        ],
    },
]

MOCK_RESOURCES = [
    {
        "uri": "file:///readme.md",
        "name": "README",
        "description": "Project readme",
        "mimeType": "text/markdown",
    },
    {
        "uri": "db://users",
        "name": "Users",
    },
]

MOCK_RESOURCE_TEMPLATES = [
    {
        "uriTemplate": "file:///{path}",
        "name": "file",
        "description": "Read a file",
        "mimeType": "text/plain",
    },
]

SESSION_ID = "test-prompt-session"


class MockPromptResourceHandler(BaseHTTPRequestHandler):
    """Mock MCP server that supports prompts, resources, tool calls."""

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        # Notification
        if "id" not in body:
            self.send_response(202)
            self.send_header("Mcp-Session-Id", SESSION_ID)
            self.end_headers()
            return

        method = body.get("method", "")
        req_id = body["id"]
        params = body.get("params", {})

        if method == "initialize":
            self._ok(req_id, {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "serverInfo": {"name": "MockPromptResource", "version": "1.0.0"},
            })
        elif method == "tools/list":
            self._ok(req_id, {"tools": MOCK_TOOLS})
        elif method == "prompts/list":
            self._ok(req_id, {"prompts": MOCK_PROMPTS})
        elif method == "prompts/get":
            name = params.get("name", "")
            args = params.get("arguments", {})
            if name == "summarize":
                self._ok(req_id, {
                    "description": "Summary result",
                    "messages": [
                        {
                            "role": "user",
                            "content": {"type": "text", "text": args.get("text", "")},
                        },
                        {
                            "role": "assistant",
                            "content": {"type": "text", "text": "Summary: ..."},
                        },
                    ],
                })
            else:
                self._err(req_id, -32601, f"Unknown prompt: {name}")
        elif method == "resources/list":
            self._ok(req_id, {"resources": MOCK_RESOURCES})
        elif method == "resources/read":
            uri = params.get("uri", "")
            if uri == "file:///readme.md":
                self._ok(req_id, {
                    "contents": [
                        {"uri": uri, "mimeType": "text/markdown", "text": "# Hello"},
                    ],
                })
            else:
                self._ok(req_id, {"contents": []})
        elif method == "resources/templates/list":
            self._ok(req_id, {"resourceTemplates": MOCK_RESOURCE_TEMPLATES})
        else:
            self._err(req_id, -32601, f"Method not found: {method}")

    def _ok(self, req_id: int, result: Any) -> None:
        payload = json.dumps({"jsonrpc": "2.0", "id": req_id, "result": result}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Mcp-Session-Id", SESSION_ID)
        self.end_headers()
        self.wfile.write(payload)

    def _err(self, req_id: int, code: int, message: str) -> None:
        payload = json.dumps({
            "jsonrpc": "2.0", "id": req_id,
            "error": {"code": code, "message": message},
        }).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Mcp-Session-Id", SESSION_ID)
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        pass


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def mock_server():
    server = HTTPServer(("127.0.0.1", 0), MockPromptResourceHandler)
    port = server.server_address[1]
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


def make_ctx(endpoint: str) -> TransportContext:
    async def get_headers() -> dict[str, str]:
        return {"x-api-key": "test-key"}
    return TransportContext(endpoint=endpoint, timeout=10.0, get_headers=get_headers)


# ---------------------------------------------------------------------------
# Tests — Prompts
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_prompts(mock_server: str) -> None:
    transport = McpTransport(default_namespace="test-ns")
    ctx = make_ctx(mock_server)
    await transport.init(ctx)

    prompts = await transport.list_prompts(ctx)
    assert len(prompts) == 2
    assert isinstance(prompts[0], PromptSchema)
    assert prompts[0].name == "summarize"
    assert prompts[0].description == "Summarize text"
    assert prompts[0].namespace == "test-ns"
    assert len(prompts[0].arguments) == 2
    assert prompts[0].arguments[0].name == "text"
    assert prompts[0].arguments[0].required is True
    assert prompts[0].arguments[1].name == "style"
    assert prompts[0].arguments[1].required is None

    await transport.close()


@pytest.mark.asyncio
async def test_get_prompt(mock_server: str) -> None:
    transport = McpTransport(default_namespace="test-ns")
    ctx = make_ctx(mock_server)
    await transport.init(ctx)

    result = await transport.get_prompt(ctx, "test-ns", "summarize", {"text": "Hello world"})
    assert result.description == "Summary result"
    assert len(result.messages) == 2
    assert result.messages[0].role == "user"
    assert result.messages[0].content["text"] == "Hello world"
    assert result.messages[1].role == "assistant"
    assert result.messages[1].content["text"] == "Summary: ..."

    await transport.close()


@pytest.mark.asyncio
async def test_get_prompt_unknown_raises(mock_server: str) -> None:
    transport = McpTransport(default_namespace="test-ns")
    ctx = make_ctx(mock_server)
    await transport.init(ctx)

    with pytest.raises(RuntimeError, match="Unknown prompt"):
        await transport.get_prompt(ctx, "test-ns", "nonexistent")

    await transport.close()


# ---------------------------------------------------------------------------
# Tests — Resources
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_resources(mock_server: str) -> None:
    transport = McpTransport(default_namespace="test-ns")
    ctx = make_ctx(mock_server)
    await transport.init(ctx)

    resources = await transport.list_resources(ctx)
    assert len(resources) == 2
    assert isinstance(resources[0], ResourceSchema)
    assert resources[0].uri == "file:///readme.md"
    assert resources[0].name == "README"
    assert resources[0].mime_type == "text/markdown"
    assert resources[0].namespace == "test-ns"

    await transport.close()


@pytest.mark.asyncio
async def test_read_resource(mock_server: str) -> None:
    transport = McpTransport(default_namespace="test-ns")
    ctx = make_ctx(mock_server)
    await transport.init(ctx)

    contents = await transport.read_resource(ctx, "test-ns", "file:///readme.md")
    assert len(contents) == 1
    assert contents[0].uri == "file:///readme.md"
    assert contents[0].mime_type == "text/markdown"
    assert contents[0].text == "# Hello"

    await transport.close()


@pytest.mark.asyncio
async def test_read_resource_empty(mock_server: str) -> None:
    transport = McpTransport(default_namespace="test-ns")
    ctx = make_ctx(mock_server)
    await transport.init(ctx)

    contents = await transport.read_resource(ctx, "test-ns", "unknown://uri")
    assert contents == []

    await transport.close()


# ---------------------------------------------------------------------------
# Tests — Resource Templates
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_resource_templates(mock_server: str) -> None:
    transport = McpTransport(default_namespace="test-ns")
    ctx = make_ctx(mock_server)
    await transport.init(ctx)

    templates = await transport.list_resource_templates(ctx)
    assert len(templates) == 1
    assert isinstance(templates[0], ResourceTemplate)
    assert templates[0].uri_template == "file:///{path}"
    assert templates[0].name == "file"
    assert templates[0].description == "Read a file"
    assert templates[0].namespace == "test-ns"

    await transport.close()


# ---------------------------------------------------------------------------
# Tests — Transport base class defaults
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_base_transport_prompt_defaults() -> None:
    """Base Transport returns empty lists for prompt/resource methods."""
    from cockpit_aap.transport import TransportContext

    ctx = TransportContext(
        endpoint="unused",
        timeout=1.0,
        get_headers=lambda: {},  # type: ignore[arg-type, return-value]
    )

    # Create a concrete subclass just to test defaults
    from cockpit_aap.transports.rest import RestTransport

    t = RestTransport()
    assert await t.list_prompts(ctx) == []
    assert (await t.get_prompt(ctx, "ns", "name")).messages == []
    assert await t.list_resources(ctx) == []
    assert await t.read_resource(ctx, "ns", "uri") == []
    assert await t.list_resource_templates(ctx) == []
