"""Integration tests against a real MCP server.

Skipped unless MCP_API_KEY env var is set.

Usage:
    MCP_API_KEY="..." MCP_COCKPIT_API_KEY="..." MCP_LICENSE_ID="..." \
    MCP_NAMESPACE_ID="..." MCP_UTILITY_AGENT_ID="..." \
    python3 -m pytest tests/test_integration.py -v
"""

from __future__ import annotations

import os

import pytest

from cockpit_aap.client import AAPGatewayClient

MCP_ENDPOINT = "https://mcp-agent-dev.cockpit.avanade.ai/mcp"
API_KEY = os.environ.get("MCP_API_KEY")
COCKPIT_API_KEY = os.environ.get("MCP_COCKPIT_API_KEY", "")
LICENSE_ID = os.environ.get("MCP_LICENSE_ID", "")
NAMESPACE_ID = os.environ.get("MCP_NAMESPACE_ID", "")
UTILITY_AGENT_ID = os.environ.get("MCP_UTILITY_AGENT_ID", "")

skip = not API_KEY


@pytest.mark.skipif(skip, reason="MCP_API_KEY not set")
@pytest.mark.asyncio
async def test_discover_tools_via_mcp() -> None:
    async with AAPGatewayClient(
        endpoint=MCP_ENDPOINT,
        token="unused",
        transport="mcp",
        default_namespace="cockpit-agent",
        timeout=30.0,
        headers={
            "x-api-key": API_KEY or "",
            "x-cockpit-api-key": COCKPIT_API_KEY,
            "x-cockpit-license-id": LICENSE_ID,
            "x-cockpit-namespace-id": NAMESPACE_ID,
            "x-cockpit-utility-agent-id": UTILITY_AGENT_ID,
        },
    ) as sdk:
        assert "cockpit-agent" in sdk.namespaces
        tools = sdk.get_tools("cockpit-agent")
        assert len(tools) > 0
        tool_names = [t["name"] for t in tools]
        assert "get_agent_card" in tool_names
        assert "execute_agent" in tool_names


@pytest.mark.skipif(skip, reason="MCP_API_KEY not set")
@pytest.mark.asyncio
async def test_call_execute_agent() -> None:
    async with AAPGatewayClient(
        endpoint=MCP_ENDPOINT,
        token="unused",
        transport="mcp",
        default_namespace="cockpit-agent",
        timeout=60.0,
        headers={
            "x-api-key": API_KEY or "",
            "x-cockpit-api-key": COCKPIT_API_KEY,
            "x-cockpit-license-id": LICENSE_ID,
            "x-cockpit-namespace-id": NAMESPACE_ID,
            "x-cockpit-utility-agent-id": UTILITY_AGENT_ID,
        },
    ) as sdk:
        result = await sdk.cockpit_agent.execute_agent(
            user_input="Hello from Python SDK integration test"
        )
        assert result["isError"] is False
        assert result["content"] is not None
