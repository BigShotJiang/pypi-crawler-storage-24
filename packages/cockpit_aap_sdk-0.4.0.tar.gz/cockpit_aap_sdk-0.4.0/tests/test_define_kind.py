"""Tests for the define_kind() factory and domain inference."""

from __future__ import annotations

import os
import tempfile

import pytest
import yaml

from cockpit_aap.kinds._shared.define_kind import define_kind, infer_domain


# ── infer_domain ─────────────────────────────────────────────────────────────


class TestInferDomain:
    def test_prefixed_governance(self):
        assert infer_domain("governance.cockpit.io/v1") == "governance"

    def test_prefixed_observability(self):
        assert infer_domain("observability.cockpit.io/v1") == "observability"

    def test_prefixed_planning(self):
        assert infer_domain("planning.cockpit.io/v1") == "planning"

    def test_core(self):
        assert infer_domain("cockpit.io/v1") == "core"

    def test_external_two_part(self):
        assert infer_domain("agents.md/v1") == "agents"

    def test_external_soul(self):
        assert infer_domain("soul.md/v1") == "soul"

    def test_external_protocol(self):
        assert infer_domain("a2a-protocol.org/v1") == "a2a-protocol"

    def test_three_part_registry(self):
        assert infer_domain("registry.cockpit.io/v1") == "registry"

    def test_three_part_ml(self):
        assert infer_domain("ml.cockpit.io/v1") == "ml"

    def test_three_part_code(self):
        assert infer_domain("code.cockpit.io/v1") == "code"


# ── define_kind ──────────────────────────────────────────────────────────────


class TestDefineKind:
    def test_basic_structure(self):
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="A test kind",
            fields=[],
        )
        assert kind_def["kind"] == "Test"
        assert kind_def["api_version"] == "cockpit.io/v1"
        assert kind_def["domain"] == "core"
        assert kind_def["description"] == "A test kind"
        assert kind_def["fields"] == []
        assert callable(kind_def["scan"])
        assert callable(kind_def["parse"])
        assert kind_def["sample"] is None
        assert kind_def["default_template"] is None

    def test_domain_override(self):
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            domain="custom",
            description="test",
            fields=[],
        )
        assert kind_def["domain"] == "custom"

    def test_domain_inferred_from_api_version(self):
        kind_def = define_kind(
            kind="Metric",
            api_version="observability.cockpit.io/v1",
            description="test",
            fields=[],
        )
        assert kind_def["domain"] == "observability"

    def test_fields_preserved(self):
        fields = [
            {"path": "metadata.name", "type": "string", "required": True},
            {"path": "spec.value", "type": "number"},
        ]
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=fields,
        )
        assert kind_def["fields"] == fields

    def test_sample_preserved(self):
        sample = {"apiVersion": "cockpit.io/v1", "kind": "Test"}
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
            sample=sample,
        )
        assert kind_def["sample"] == sample

    def test_custom_scan_function(self):
        custom_scan = lambda d: {"custom": True}
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
            scan=custom_scan,
        )
        assert kind_def["scan"] is custom_scan

    def test_custom_parse_function(self):
        custom_parse = lambda y: {"parsed": True}
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
            parse=custom_parse,
        )
        assert kind_def["parse"] is custom_parse

    def test_default_template(self):
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
            default_template="<div>{{metadata.name}}</div>",
        )
        assert kind_def["default_template"] == "<div>{{metadata.name}}</div>"


# ── Auto-generated scan function ─────────────────────────────────────────────


class TestDefaultScan:
    def test_scan_valid_manifest(self, tmp_path):
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Test",
            "metadata": {"name": "test"},
        }
        manifest_file = tmp_path / "manifest.yaml"
        manifest_file.write_text(yaml.dump(manifest))

        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
        )
        result = kind_def["scan"](str(tmp_path))
        assert result["kind"] == "Test"
        assert result["metadata"]["name"] == "test"

    def test_scan_missing_file(self, tmp_path):
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
        )
        with pytest.raises(FileNotFoundError):
            kind_def["scan"](str(tmp_path))

    def test_scan_wrong_api_version(self, tmp_path):
        manifest = {"apiVersion": "wrong/v1", "kind": "Test"}
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
        )
        with pytest.raises(ValueError, match='Expected apiVersion "cockpit.io/v1"'):
            kind_def["scan"](str(tmp_path))

    def test_scan_wrong_kind(self, tmp_path):
        manifest = {"apiVersion": "cockpit.io/v1", "kind": "Wrong"}
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
        )
        with pytest.raises(ValueError, match='Expected kind "Test"'):
            kind_def["scan"](str(tmp_path))

    def test_scan_with_after_scan(self, tmp_path):
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Test",
            "metadata": {"name": "test"},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        def after_scan(doc, dir_path):
            doc["_scanned_from"] = dir_path
            return doc

        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
            after_scan=after_scan,
        )
        result = kind_def["scan"](str(tmp_path))
        assert result["_scanned_from"] == str(tmp_path)


# ── Auto-generated parse function ────────────────────────────────────────────


class TestDefaultParse:
    def test_parse_valid_yaml(self):
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
        )
        result = kind_def["parse"]("apiVersion: cockpit.io/v1\nkind: Test\n")
        assert result["kind"] == "Test"

    def test_parse_non_mapping_raises(self):
        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
        )
        with pytest.raises(ValueError, match="Expected YAML mapping"):
            kind_def["parse"]("- item1\n- item2\n")
