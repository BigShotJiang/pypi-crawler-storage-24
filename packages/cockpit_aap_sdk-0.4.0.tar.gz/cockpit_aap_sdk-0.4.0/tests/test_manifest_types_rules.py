"""Tests for ManifestRule and ManifestLifecycle Python types."""
import pytest
from cockpit_aap.manifest.types import (
    ManifestRule,
    ManifestRoadmapItem,
    ManifestIssue,
    ManifestDecision,
    ManifestLifecycle,
    Manifest,
)


def test_manifest_rule_minimal():
    rule = ManifestRule(
        id="r1",
        name="Block high value",
        condition="amount > 100000",
        enforcement="block",
        scope="input",
        evaluation="deterministic",
    )
    assert rule.id == "r1"
    assert rule.enforcement == "block"
    assert rule.scope == "input"


def test_manifest_rule_full():
    rule = ManifestRule(
        id="r1",
        name="Block",
        condition="value > 1000",
        enforcement="block",
        scope="input",
        evaluation="deterministic",
        category="authorization",
        applies_to=["dev-agent"],
        message="Not allowed",
        required_actions=["request_approval"],
        hitl_if_unresolved=True,
        tags=["finance"],
    )
    assert rule.applies_to == ["dev-agent"]
    assert rule.hitl_if_unresolved is True
    assert rule.tags == ["finance"]


def test_manifest_roadmap_item():
    item = ManifestRoadmapItem(
        id="Q1",
        title="Rules Engine",
        status="in-progress",
        priority="critical",
    )
    assert item.status == "in-progress"
    assert item.priority == "critical"


def test_manifest_issue():
    issue = ManifestIssue(
        id="ISS-1",
        title="Bug",
        type="bug",
        status="open",
        severity="high",
    )
    assert issue.severity == "high"


def test_manifest_decision():
    decision = ManifestDecision(
        id="DEC-1",
        title="Use simpleeval",
        context="Need expression parser",
        decision="Use simpleeval",
        status="accepted",
    )
    assert decision.status == "accepted"


def test_manifest_lifecycle():
    lifecycle = ManifestLifecycle(
        roadmap=[ManifestRoadmapItem(id="Q1", title="Phase 1", status="planned", priority="high")],
        issues=[ManifestIssue(id="ISS-1", title="Bug", type="bug", status="open", severity="medium")],
        decisions=[ManifestDecision(id="DEC-1", title="Parser", context="c", decision="d", status="accepted")],
    )
    assert len(lifecycle.roadmap) == 1
    assert len(lifecycle.issues) == 1
    assert len(lifecycle.decisions) == 1


def test_manifest_with_rules_and_lifecycle():
    """Test that Manifest.from_dict correctly parses rules and lifecycle."""
    m = Manifest.from_dict({
        "apiVersion": "cockpit.io/v1",
        "kind": "Module",
        "metadata": {
            "name": "test",
            "displayName": "Test",
            "version": "1.0.0",
            "description": "Test module",
        },
        "spec": {
            "rules": [
                {
                    "id": "r1",
                    "name": "Block",
                    "condition": "value > 1000",
                    "enforcement": "block",
                    "scope": "input",
                    "evaluation": "deterministic",
                    "message": "Too high",
                    "hitlIfUnresolved": True,
                }
            ],
            "lifecycle": {
                "roadmap": [
                    {"id": "Q1", "title": "Phase 1", "status": "planned", "priority": "high"}
                ],
                "issues": [],
                "decisions": [
                    {
                        "id": "DEC-1",
                        "title": "Parser choice",
                        "context": "Need parser",
                        "decision": "simpleeval",
                        "status": "accepted",
                    }
                ],
            },
        },
    })
    assert m.spec.rules is not None
    assert len(m.spec.rules) == 1
    assert m.spec.rules[0].id == "r1"
    assert m.spec.rules[0].hitl_if_unresolved is True
    assert m.spec.lifecycle is not None
    assert len(m.spec.lifecycle.roadmap) == 1
    assert len(m.spec.lifecycle.decisions) == 1
