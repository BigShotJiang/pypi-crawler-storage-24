"""Extended tests for cost_callback.py — covers helper functions and CostCallbackHandler paths."""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest

from cockpit_aap.runtime.cost_callback import (
    _extract_token_counts,
    _extract_from_generation_metadata,
    _resolve_model_from_response,
    _set_span_attributes,
    BudgetExceededError,
    record_rule_violation,
    CostCallbackHandler,
)


# ── _extract_token_counts ────────────────────────────────────────────────────


class TestExtractTokenCounts:
    def test_from_token_usage(self):
        llm_output = {"token_usage": {"prompt_tokens": 100, "completion_tokens": 50}}
        inp, out = _extract_token_counts(llm_output, None)
        assert inp == 100
        assert out == 50

    def test_empty_token_usage_falls_back(self):
        llm_output = {"token_usage": {}}
        # No generation metadata either → (0, 0)
        inp, out = _extract_token_counts(llm_output, None)
        assert inp == 0
        assert out == 0

    def test_missing_token_usage_key(self):
        inp, out = _extract_token_counts({}, None)
        assert inp == 0
        assert out == 0

    def test_fallback_to_generation_metadata(self):
        llm_output = {}
        msg = SimpleNamespace(
            usage_metadata={"input_tokens": 200, "output_tokens": 100}
        )
        gen = SimpleNamespace(message=msg)
        response = SimpleNamespace(generations=[[gen]])
        inp, out = _extract_token_counts(llm_output, response)
        assert inp == 200
        assert out == 100


# ── _extract_from_generation_metadata ────────────────────────────────────────


class TestExtractFromGenerationMetadata:
    def test_dict_usage_metadata(self):
        msg = SimpleNamespace(usage_metadata={"input_tokens": 10, "output_tokens": 5})
        gen = SimpleNamespace(message=msg)
        response = SimpleNamespace(generations=[[gen]])
        assert _extract_from_generation_metadata(response) == (10, 5)

    def test_object_usage_metadata(self):
        meta = SimpleNamespace(input_tokens=30, output_tokens=20)
        msg = SimpleNamespace(usage_metadata=meta)
        gen = SimpleNamespace(message=msg)
        response = SimpleNamespace(generations=[[gen]])
        assert _extract_from_generation_metadata(response) == (30, 20)

    def test_no_generations(self):
        response = SimpleNamespace(generations=None)
        assert _extract_from_generation_metadata(response) == (0, 0)

    def test_empty_generations(self):
        response = SimpleNamespace(generations=[])
        assert _extract_from_generation_metadata(response) == (0, 0)

    def test_empty_first_generation(self):
        response = SimpleNamespace(generations=[[]])
        assert _extract_from_generation_metadata(response) == (0, 0)

    def test_no_message_on_generation(self):
        gen = SimpleNamespace()  # no .message
        response = SimpleNamespace(generations=[[gen]])
        assert _extract_from_generation_metadata(response) == (0, 0)

    def test_no_usage_metadata_on_message(self):
        msg = SimpleNamespace()  # no .usage_metadata
        gen = SimpleNamespace(message=msg)
        response = SimpleNamespace(generations=[[gen]])
        assert _extract_from_generation_metadata(response) == (0, 0)

    def test_no_generations_attr(self):
        response = object()
        assert _extract_from_generation_metadata(response) == (0, 0)


# ── _resolve_model_from_response ─────────────────────────────────────────────


class TestResolveModelFromResponse:
    def test_from_model_name(self):
        msg = SimpleNamespace(response_metadata={"model_name": "gpt-4o"})
        gen = SimpleNamespace(message=msg)
        response = SimpleNamespace(generations=[[gen]])
        assert _resolve_model_from_response(response, "fallback") == "gpt-4o"

    def test_from_model_key(self):
        msg = SimpleNamespace(response_metadata={"model": "claude-3"})
        gen = SimpleNamespace(message=msg)
        response = SimpleNamespace(generations=[[gen]])
        assert _resolve_model_from_response(response, "fallback") == "claude-3"

    def test_returns_fallback_on_error(self):
        response = object()
        assert _resolve_model_from_response(response, "my-fallback") == "my-fallback"

    def test_returns_fallback_when_metadata_empty(self):
        msg = SimpleNamespace(response_metadata={})
        gen = SimpleNamespace(message=msg)
        response = SimpleNamespace(generations=[[gen]])
        assert _resolve_model_from_response(response, "fb") == "fb"

    def test_returns_fallback_when_metadata_none(self):
        msg = SimpleNamespace(response_metadata=None)
        gen = SimpleNamespace(message=msg)
        response = SimpleNamespace(generations=[[gen]])
        assert _resolve_model_from_response(response, "fb") == "fb"


# ── _set_span_attributes ────────────────────────────────────────────────────


class TestSetSpanAttributes:
    def test_sets_attributes_on_span(self):
        attrs = {}
        class MockSpan:
            def set_attribute(self, key, value):
                attrs[key] = value

        _set_span_attributes(MockSpan(), 100, 50, 0.05, "gpt-4o")
        assert attrs["gen_ai.usage.input_tokens"] == 100
        assert attrs["gen_ai.usage.output_tokens"] == 50
        assert attrs["gen_ai.usage.cost"] == 0.05
        assert attrs["gen_ai.response.model"] == "gpt-4o"

    def test_no_op_when_span_is_none(self):
        # Should not raise
        _set_span_attributes(None, 100, 50, 0.05, "gpt-4o")


# ── BudgetExceededError ──────────────────────────────────────────────────────


class TestBudgetExceededError:
    def test_message_from_result(self):
        result = SimpleNamespace(message="Budget exceeded for agent X")
        err = BudgetExceededError(result)
        assert err.user_message == "Budget exceeded for agent X"
        assert str(err) == "Budget exceeded for agent X"
        assert err.result is result

    def test_default_message_when_no_message_attr(self):
        result = {}
        err = BudgetExceededError(result)
        assert err.user_message == "Budget limit reached."

    def test_is_exception(self):
        result = SimpleNamespace(message="over")
        with pytest.raises(BudgetExceededError):
            raise BudgetExceededError(result)


# ── record_rule_violation ────────────────────────────────────────────────────


class TestRecordRuleViolation:
    def test_emits_log(self):
        """record_rule_violation should emit a structured log even without OTEL."""
        import cockpit_aap.runtime.cost_callback as cb_mod
        # Reset the counter to force re-init attempt
        cb_mod._rules_violations_counter = None

        with patch("cockpit_aap.runtime.cost_callback.emit_log") as mock_log:
            record_rule_violation("rule-1", "block", tenant_id="t1", agent_id="a1")
        mock_log.assert_called_once()
        call_kwargs = mock_log.call_args
        assert call_kwargs[0][0] == "warn"
        assert call_kwargs[0][1] == "rule_violation"


# ── CostCallbackHandler ─────────────────────────────────────────────────────


class TestCostCallbackHandlerLegacy:
    def test_legacy_mode_properties(self):
        handler = CostCallbackHandler(agent_id="a1", tenant_id="t1", module_id="mod1")
        assert handler.agent_id == "a1"
        assert handler.tenant_id == "t1"
        assert handler.module_id == "mod1"
        assert handler.database_url is None

    def test_legacy_tenant_id_setter(self):
        handler = CostCallbackHandler(agent_id="a1", tenant_id="t1")
        handler.tenant_id = "t2"
        assert handler.tenant_id == "t2"

    def test_legacy_emit_cost(self):
        handler = CostCallbackHandler(
            agent_id="a1",
            tenant_id="t1",
            cost_models={"gpt": {"input_per_1k": 0.01, "output_per_1k": 0.03}},
        )
        with patch("cockpit_aap.runtime.cost_callback.emit_log"):
            cost = handler._emit_cost("gpt", 1000, 1000)
        expected = (1000 / 1000) * 0.01 + (1000 / 1000) * 0.03
        assert cost == pytest.approx(expected)

    def test_legacy_emit_cost_default_pricing(self):
        """When model not in cost_models, uses default rates."""
        handler = CostCallbackHandler(agent_id="a1", tenant_id="t1")
        with patch("cockpit_aap.runtime.cost_callback.emit_log"):
            cost = handler._emit_cost("unknown", 1000, 1000)
        # Default: 0.005 input, 0.015 output per 1k
        expected = (1000 / 1000) * 0.005 + (1000 / 1000) * 0.015
        assert cost == pytest.approx(expected)


class TestCostCallbackHandlerEmitter:
    def test_emitter_mode_properties(self):
        emitter = SimpleNamespace(agent_id="e-agent", tenant_id="e-tenant", module_id="e-mod")
        handler = CostCallbackHandler(emitter=emitter)
        assert handler.agent_id == "e-agent"
        assert handler.tenant_id == "e-tenant"
        assert handler.module_id == "e-mod"

    def test_emitter_tenant_id_setter(self):
        emitter = SimpleNamespace(agent_id="a", tenant_id="old", module_id="m")
        handler = CostCallbackHandler(emitter=emitter)
        handler.tenant_id = "new"
        assert emitter.tenant_id == "new"

    def test_emit_cost_delegates_to_emitter(self):
        emitter = SimpleNamespace(
            agent_id="a", tenant_id="t", module_id="m",
            emit=lambda model, inp, out: 0.42,
        )
        handler = CostCallbackHandler(emitter=emitter)
        cost = handler._emit_cost("gpt", 100, 50)
        assert cost == 0.42


class TestCostCallbackHandlerOnLlmStart:
    def test_on_llm_start_extracts_model(self):
        handler = CostCallbackHandler(agent_id="a", tenant_id="t")
        handler.on_llm_start({}, [], invocation_params={"model_name": "gpt-4o"})
        assert handler._last_model == "gpt-4o"

    def test_on_llm_start_extracts_model_id(self):
        handler = CostCallbackHandler(agent_id="a", tenant_id="t")
        handler.on_llm_start({}, [], invocation_params={"model_id": "claude-3"})
        assert handler._last_model == "claude-3"

    def test_on_llm_start_empty_invocation(self):
        handler = CostCallbackHandler(agent_id="a", tenant_id="t")
        handler.on_llm_start({}, [], invocation_params={})
        assert handler._last_model == ""


class TestCostCallbackHandlerCheckEnforcer:
    def test_check_enforcer_records_spend(self):
        recorded = []
        checked = []
        class MockEnforcer:
            def record_spend(self, cost, meta):
                recorded.append(cost)
            def check_budget(self, scope):
                checked.append(scope)
                return SimpleNamespace(action="pass", spent=0.5, limit=10.0)

        emitter = SimpleNamespace(agent_id="a", tenant_id="t", module_id="m")
        handler = CostCallbackHandler(emitter=emitter, enforcer=MockEnforcer())
        handler._check_enforcer_budget(0.5)
        assert recorded == [0.5]
        assert checked == ["module"]

    def test_check_enforcer_no_op_when_none(self):
        handler = CostCallbackHandler(agent_id="a", tenant_id="t")
        # Should not raise
        handler._check_enforcer_budget(1.0)

    def test_check_enforcer_emits_warn(self):
        budget_events = []
        class MockEnforcer:
            def record_spend(self, cost, meta):
                pass
            def check_budget(self, scope):
                return SimpleNamespace(action="warn", spent=9.0, limit=10.0)

        emitter = SimpleNamespace(
            agent_id="a", tenant_id="t", module_id="m",
            emit_budget_event=lambda action, spent, limit: budget_events.append((action, spent, limit)),
        )
        handler = CostCallbackHandler(emitter=emitter, enforcer=MockEnforcer())
        handler._check_enforcer_budget(1.0)
        assert len(budget_events) == 1
        assert budget_events[0][0] == "warn"
