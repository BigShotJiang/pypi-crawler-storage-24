from cockpit_aap.runtime.otel_telemetry import OtelTelemetryAdapter
from cockpit_aap.ports.agent_telemetry import AgentSpanContext


def test_console_fallback_uses_genai_names(capsys):
    adapter = OtelTelemetryAdapter()
    if not adapter._available:
        span = adapter.start_agent_span(AgentSpanContext(
            agent_id="test", request_id="r1", model="gpt-5.4",
        ))
        captured = capsys.readouterr()
        assert "gen_ai.agent.id=test" in captured.out
        assert "gen_ai.request.model=gpt-5.4" in captured.out
