"""Test noop adapters satisfy their Protocol interfaces."""
import pytest
from cockpit_aap.ports import QueryPort, LinterPort, PolicyEnginePort, ComposerPort
from cockpit_aap.adapters.noop_query import NoopQueryAdapter
from cockpit_aap.adapters.noop_linter import NoopLinterAdapter
from cockpit_aap.adapters.noop_policy import NoopPolicyAdapter
from cockpit_aap.adapters.noop_composer import NoopComposerAdapter
from cockpit_aap.ports.policy_engine import PolicyInput


@pytest.mark.asyncio
async def test_noop_query_satisfies_protocol():
    adapter = NoopQueryAdapter()
    assert isinstance(adapter, QueryPort)
    result = await adapter.evaluate("$.name", {"name": "test"})
    assert result is None


@pytest.mark.asyncio
async def test_noop_linter_satisfies_protocol():
    adapter = NoopLinterAdapter()
    assert isinstance(adapter, LinterPort)
    result = await adapter.lint({"kind": "Module"})
    assert result.grade == "A"


@pytest.mark.asyncio
async def test_noop_policy_satisfies_protocol():
    adapter = NoopPolicyAdapter()
    assert isinstance(adapter, PolicyEnginePort)
    result = await adapter.evaluate(PolicyInput(manifest={}))
    assert result.passed is True


@pytest.mark.asyncio
async def test_noop_composer_satisfies_protocol():
    adapter = NoopComposerAdapter()
    assert isinstance(adapter, ComposerPort)
    result = await adapter.compose(["a.cue"])
    assert result.sources == ["a.cue"]
