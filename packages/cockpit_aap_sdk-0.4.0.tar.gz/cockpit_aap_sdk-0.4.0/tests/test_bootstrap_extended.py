"""Extended tests for Python bootstrap serialization helpers."""
import pytest
from cockpit_aap.bootstrap import (
    is_newer_version,
    _escape_regex,
    _snake_to_camel,
    _to_camel_case_dict,
    _manifest_to_dict,
    _resolve_agents,
)
from cockpit_aap.manifest.types import Manifest, ManifestMetadata, ManifestAgent, ManifestSpec


class TestSnakeToCamel:
    def test_simple(self):
        assert _snake_to_camel("module_id") == "moduleId"

    def test_schema_no_special_case(self):
        assert _snake_to_camel("schema") == "schema"

    def test_prompt_pills_special_case(self):
        assert _snake_to_camel("prompt_pills") == "prompt-pills"

    def test_single_word(self):
        assert _snake_to_camel("name") == "name"

    def test_multiple_parts(self):
        assert _snake_to_camel("default_locale_name") == "defaultLocaleName"


class TestToCamelCaseDict:
    def test_flat_dict(self):
        result = _to_camel_case_dict({"module_id": "test", "module_name": "Test"})
        assert result == {"moduleId": "test", "moduleName": "Test"}

    def test_nested_dict(self):
        result = _to_camel_case_dict({"outer_key": {"inner_key": "value"}})
        assert result == {"outerKey": {"innerKey": "value"}}

    def test_list_of_dicts(self):
        result = _to_camel_case_dict([{"agent_id": "a1"}, {"agent_id": "a2"}])
        assert result == [{"agentId": "a1"}, {"agentId": "a2"}]

    def test_primitive(self):
        assert _to_camel_case_dict("hello") == "hello"
        assert _to_camel_case_dict(42) == 42

    def test_prompt_pills_key(self):
        result = _to_camel_case_dict({"prompt_pills": [{"label": "hi"}]})
        assert result == {"prompt-pills": [{"label": "hi"}]}


class TestEscapeRegex:
    def test_escapes_special_chars(self):
        result = _escape_regex("module.id[0]")
        assert "\\." in result
        assert "\\[" in result

    def test_plain_string(self):
        assert _escape_regex("hello") == "hello"


class TestManifestToDict:
    def test_converts_basic_manifest(self):
        m = Manifest(
            metadata=ManifestMetadata(name="test", display_name="Test", version="1.0.0", description="A test"),
        )
        d = _manifest_to_dict(m)
        assert d["apiVersion"] == "cockpit.io/v1"
        assert d["kind"] == "Module"
        assert d["metadata"]["name"] == "test"

    def test_preserves_agents(self):
        m = Manifest(
            metadata=ManifestMetadata(name="test", display_name="Test", version="1.0.0", description="A test"),
            spec=ManifestSpec(
                agents=[ManifestAgent(id="a1", name="A1", description="d", instruction="Do stuff")],
            ),
        )
        d = _manifest_to_dict(m)
        assert "spec" in d
        assert len(d["spec"]["agents"]) == 1
        assert d["spec"]["agents"][0]["id"] == "a1"


class TestResolveAgents:
    def test_empty_agents(self):
        m = Manifest(
            metadata=ManifestMetadata(name="test", display_name="Test", version="1.0.0", description="A test"),
        )
        result = _resolve_agents(m)
        assert result == {}

    def test_resolves_agent_names(self):
        m = Manifest(
            metadata=ManifestMetadata(name="test", display_name="Test", version="1.0.0", description="A test"),
            spec=ManifestSpec(
                agents=[
                    ManifestAgent(id="a1", name="Agent One", description="d", instruction="Do this"),
                    ManifestAgent(id="a2", name="Agent Two", description="d", instruction="Do that"),
                ],
            ),
        )
        result = _resolve_agents(m)
        assert len(result) == 2
        assert "Agent One" in result
        assert result["Agent One"].instruction == "Do this"


class TestIsNewerVersionExtended:
    def test_zero_padded(self):
        assert is_newer_version("1.0.1", "1.0.0") is True

    def test_major_newer(self):
        assert is_newer_version("2.0.0", "1.9.9") is True

    def test_not_newer_when_older(self):
        assert is_newer_version("1.0.0", "2.0.0") is False

    def test_equal_extended(self):
        assert is_newer_version("1.0.0.0", "1.0.0") is False
