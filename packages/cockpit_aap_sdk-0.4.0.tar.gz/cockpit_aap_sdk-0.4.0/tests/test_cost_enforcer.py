"""Tests for cockpit_aap.cost.enforcer — CostEnforcer."""
from cockpit_aap.cost.enforcer import CostEnforcer
from cockpit_aap.cost.policy import CostPolicyReader

SPEC = {
    "models": {"gpt-4o": {"inputPer1k": 0.005, "outputPer1k": 0.015}},
    "budgets": [
        {"scope": "module", "daily": 10.0, "onExceeded": "block", "warnAt": 0.8},
    ],
    "enforcement": {"preCall": True, "cacheSeconds": 30, "accumulatorSyncInterval": 60},
    "prometheus": {"endpoint": "http://prometheus:9090"},
}


def test_allows_when_under_limit():
    enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
    result = enforcer.check_budget("module")
    assert result.action == "allow"


def test_warns_at_threshold():
    enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
    enforcer.record_spend(8.5, {"scope": "module"})  # 85% of 10
    result = enforcer.check_budget("module")
    assert result.action == "warn"


def test_blocks_when_exceeded():
    enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
    enforcer.record_spend(10.5, {"scope": "module"})
    result = enforcer.check_budget("module")
    assert result.action == "block"


def test_accumulates():
    enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
    enforcer.record_spend(3.0, {"scope": "module"})
    enforcer.record_spend(2.0, {"scope": "module"})
    result = enforcer.check_budget("module")
    assert result.action == "allow"
    assert result.spent == 5.0


def test_no_budget_defined():
    enforcer = CostEnforcer(policy=CostPolicyReader({"budgets": []}))
    result = enforcer.check_budget("module")
    assert result.action == "allow"
    assert result.message == "No budget defined"
