"""Tests for cockpit_aap.adapters.local_artifact_store — LocalArtifactStore."""

import os
import tempfile
import pytest

from cockpit_aap.adapters.local_artifact_store import (
    LocalArtifactStore,
    create_local_artifact_store,
)


@pytest.fixture
def store_dir():
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.mark.asyncio
async def test_write_and_read(store_dir):
    store = create_local_artifact_store(store_dir)
    await store.write("config.theme", "dark")
    val = await store.read("config.theme")
    assert val == "dark"


@pytest.mark.asyncio
async def test_read_missing(store_dir):
    store = LocalArtifactStore(store_dir)
    assert await store.read("missing") is None


@pytest.mark.asyncio
async def test_delete(store_dir):
    store = LocalArtifactStore(store_dir)
    await store.write("key", "val")
    await store.delete("key")
    assert await store.read("key") is None


@pytest.mark.asyncio
async def test_delete_missing_is_noop(store_dir):
    store = LocalArtifactStore(store_dir)
    await store.delete("nonexistent")  # should not raise


@pytest.mark.asyncio
async def test_list(store_dir):
    store = LocalArtifactStore(store_dir)
    await store.write("a", "1")
    await store.write("b", "2")
    keys = await store.list()
    assert set(keys) == {"a", "b"}


@pytest.mark.asyncio
async def test_list_empty(store_dir):
    store = LocalArtifactStore(store_dir)
    assert await store.list() == []


@pytest.mark.asyncio
async def test_overwrite(store_dir):
    store = LocalArtifactStore(store_dir)
    await store.write("key", "v1")
    await store.write("key", "v2")
    assert await store.read("key") == "v2"


@pytest.mark.asyncio
async def test_persists_to_disk(store_dir):
    store1 = LocalArtifactStore(store_dir)
    await store1.write("persist", "yes")

    # Create new instance pointing at same dir
    store2 = LocalArtifactStore(store_dir)
    assert await store2.read("persist") == "yes"
