"""Tests for AAPGatewayClient."""

from __future__ import annotations

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
from typing import Any

import pytest

from cockpit_aap.client import AAPGatewayClient, _NamespaceProxy

MOCK_TOOLS = [
    {
        "name": "createWorkItem",
        "description": "Create a work item",
        "namespace": "azuredevops",
        "inputSchema": {"type": "object", "required": ["project"]},
    },
    {
        "name": "getStatus",
        "description": "Get compliance status",
        "namespace": "saidot",
        "inputSchema": {"type": "object"},
    },
]


class MockHandler(BaseHTTPRequestHandler):
    """Minimal mock MetaMCP HTTP handler."""

    def do_GET(self) -> None:
        if self.path == "/api/tools":
            self._json_response(200, MOCK_TOOLS)
        else:
            self._json_response(404, {"error": "not found"})

    def do_POST(self) -> None:
        if self.path.startswith("/api/tools/"):
            parts = self.path.split("/")
            ns, tool = parts[3], parts[4]
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length)) if length else {}
            self._json_response(200, {
                "content": {"ns": ns, "tool": tool, "args": body.get("arguments", {})},
                "isError": False,
            })
        else:
            self._json_response(404, {"error": "not found"})

    def _json_response(self, status: int, data: Any) -> None:
        payload = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        pass  # Silence request logs during tests


@pytest.fixture(scope="module")
def mock_server():
    """Start a mock HTTP server in a background thread."""
    server = HTTPServer(("127.0.0.1", 0), MockHandler)
    port = server.server_address[1]
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest.mark.asyncio
async def test_init_loads_schemas(mock_server: str) -> None:
    client = AAPGatewayClient(endpoint=mock_server, token="test")
    await client.init()
    assert "azuredevops" in client.namespaces or len(client.namespaces) > 0


@pytest.mark.asyncio
async def test_context_manager(mock_server: str) -> None:
    async with AAPGatewayClient(endpoint=mock_server, token="test") as sdk:
        assert sdk is not None


@pytest.mark.asyncio
async def test_call_tool(mock_server: str) -> None:
    async with AAPGatewayClient(endpoint=mock_server, token="test") as sdk:
        result = await sdk.call_tool("azuredevops", "createWorkItem", {"project": "Cockpit"})
        assert result["isError"] is False
        assert result["content"]["ns"] == "azuredevops"
        assert result["content"]["tool"] == "createWorkItem"


@pytest.mark.asyncio
async def test_namespace_proxy(mock_server: str) -> None:
    async with AAPGatewayClient(endpoint=mock_server, token="test") as sdk:
        result = await sdk.azuredevops.createWorkItem(project="Cockpit")
        assert result["content"]["ns"] == "azuredevops"
        assert result["content"]["tool"] == "createWorkItem"


@pytest.mark.asyncio
async def test_tenant_header(mock_server: str) -> None:
    """Client should send X-Tenant-ID when configured."""
    async with AAPGatewayClient(
        endpoint=mock_server, token="test", tenant_id="acme"
    ) as sdk:
        # If server doesn't reject it, the header was sent successfully
        result = await sdk.call_tool("saidot", "getStatus", {})
        assert result["isError"] is False


@pytest.mark.asyncio
async def test_callable_token(mock_server: str) -> None:
    """Token can be an async callable."""
    async def get_token() -> str:
        return "dynamic-token"

    async with AAPGatewayClient(endpoint=mock_server, token=get_token) as sdk:
        result = await sdk.call_tool("saidot", "getStatus", {})
        assert result["isError"] is False


def test_private_attrs_raise() -> None:
    """Accessing _private attributes should raise AttributeError."""
    client = AAPGatewayClient(endpoint="http://localhost", token="t")
    with pytest.raises(AttributeError):
        _ = client._nonexistent  # type: ignore[attr-defined]


# ---- MCP Transport Mode ----

MCP_TOOLS_RAW = [
    {
        "name": "get_agent_card",
        "description": "Get the agent card",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "execute_agent",
        "description": "Execute an agent",
        "inputSchema": {
            "type": "object",
            "required": ["user_input"],
            "properties": {"user_input": {"type": "string"}},
        },
    },
]


class MockMCPHandler(BaseHTTPRequestHandler):
    """Mock JSON-RPC 2.0 MCP server for client-level tests."""

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        # Notification
        if "id" not in body:
            self.send_response(202)
            self.send_header("Mcp-Session-Id", "sess-mcp")
            self.end_headers()
            return

        method = body.get("method", "")
        req_id = body["id"]

        if method == "initialize":
            result = {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "serverInfo": {"name": "Test", "version": "1.0"},
            }
        elif method == "tools/list":
            result = {"tools": MCP_TOOLS_RAW}
        elif method == "tools/call":
            tool_name = body.get("params", {}).get("name", "")
            args = body.get("params", {}).get("arguments", {})
            result = {
                "content": [{"type": "text", "text": json.dumps({"tool": tool_name, "args": args})}],
                "isError": False,
            }
        else:
            payload = json.dumps({
                "jsonrpc": "2.0", "id": req_id,
                "error": {"code": -32601, "message": "Not found"},
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        payload = json.dumps({"jsonrpc": "2.0", "id": req_id, "result": result}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Mcp-Session-Id", "sess-mcp")
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        pass


@pytest.fixture(scope="module")
def mock_mcp_server():
    """Start a mock MCP server."""
    server = HTTPServer(("127.0.0.1", 0), MockMCPHandler)
    port = server.server_address[1]
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest.mark.asyncio
async def test_mcp_init_loads_schemas(mock_mcp_server: str) -> None:
    async with AAPGatewayClient(
        endpoint=mock_mcp_server,
        token="test",
        transport="mcp",
        default_namespace="agent",
    ) as sdk:
        assert "agent" in sdk.namespaces
        tools = sdk.get_tools("agent")
        assert len(tools) == 2


@pytest.mark.asyncio
async def test_mcp_call_tool(mock_mcp_server: str) -> None:
    async with AAPGatewayClient(
        endpoint=mock_mcp_server,
        token="test",
        transport="mcp",
        default_namespace="agent",
    ) as sdk:
        result = await sdk.call_tool("agent", "execute_agent", {"user_input": "Hi"})
        assert result["isError"] is False
        assert result["content"]["tool"] == "execute_agent"


@pytest.mark.asyncio
async def test_mcp_namespace_proxy(mock_mcp_server: str) -> None:
    async with AAPGatewayClient(
        endpoint=mock_mcp_server,
        token="test",
        transport="mcp",
        default_namespace="agent",
    ) as sdk:
        result = await sdk.agent.get_agent_card()
        assert result["isError"] is False
        assert result["content"]["tool"] == "get_agent_card"


@pytest.mark.asyncio
async def test_mcp_custom_headers(mock_mcp_server: str) -> None:
    """Client should pass custom headers in MCP mode."""
    async with AAPGatewayClient(
        endpoint=mock_mcp_server,
        token="test",
        transport="mcp",
        default_namespace="agent",
        headers={"x-api-key": "my-key"},
    ) as sdk:
        result = await sdk.call_tool("agent", "get_agent_card", {})
        assert result["isError"] is False
