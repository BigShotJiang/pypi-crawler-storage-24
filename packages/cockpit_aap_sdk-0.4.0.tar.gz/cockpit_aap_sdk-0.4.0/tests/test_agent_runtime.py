"""Tests for create_agent_runtime() — framework-agnostic enforcement orchestrator."""
import pytest

from cockpit_aap.runtime import create_agent_runtime, RegexGuardrailAdapter, RuntimeContext, RuntimeResult


def _make_manifest(*, guardrails=None, telemetry=None, cost=None):
    """Create a minimal manifest-like object for testing."""

    class _Spec:
        pass

    class _Manifest:
        pass

    spec = _Spec()
    spec.guardrails = guardrails
    spec.telemetry = telemetry
    spec.cost = cost
    m = _Manifest()
    m.spec = spec
    return m


@pytest.mark.asyncio
async def test_before_call_blocks_pii():
    manifest = _make_manifest(
        guardrails={"input": [{"id": "pii"}], "output": []},
    )
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})
    decision = await runtime.before_call(
        RuntimeContext(agent_id="test", request_id="r1", input="Email: a@b.com", model="gpt")
    )
    assert not decision.allowed
    assert decision.action == "block"


@pytest.mark.asyncio
async def test_before_call_passes_clean():
    manifest = _make_manifest(
        guardrails={"input": [{"id": "pii"}], "output": []},
    )
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})
    decision = await runtime.before_call(
        RuntimeContext(agent_id="test", request_id="r1", input="Hello world", model="gpt")
    )
    assert decision.allowed
    assert decision.action == "pass"


@pytest.mark.asyncio
async def test_works_with_zero_adapters():
    manifest = _make_manifest(
        guardrails={"input": [{"id": "pii"}], "output": []},
    )
    runtime = create_agent_runtime(manifest, {})
    decision = await runtime.before_call(
        RuntimeContext(agent_id="test", request_id="r1", input="PII: john@example.com", model="gpt")
    )
    # noop guardrail passes everything
    assert decision.allowed


@pytest.mark.asyncio
async def test_after_call_records_cost():
    from cockpit_aap.runtime import InMemoryCostTracker

    manifest = _make_manifest(
        cost={"budget": {"daily": 100}, "models": {"gpt": {"input_per_1k": 0.005, "output_per_1k": 0.015}}},
    )
    tracker = InMemoryCostTracker(models={"gpt": {"input_per_1k": 0.005, "output_per_1k": 0.015}}, budget={"daily": 100})
    runtime = create_agent_runtime(manifest, {"cost_tracker": tracker})
    ctx = RuntimeContext(agent_id="test", request_id="r1", input="hello", model="gpt")
    await runtime.after_call(ctx, RuntimeResult(output="world", usage={"input_tokens": 100, "output_tokens": 50}))
    status = await runtime.get_budget_status("test")
    assert status.spent > 0


@pytest.mark.asyncio
async def test_on_tool_call_passes():
    from cockpit_aap.runtime import ToolCallInfo

    manifest = _make_manifest()
    runtime = create_agent_runtime(manifest)
    ctx = RuntimeContext(agent_id="test", request_id="r1", input="hello", model="gpt")
    decision = await runtime.on_tool_call(ctx, ToolCallInfo(name="my_tool"))
    assert decision.allowed


@pytest.mark.asyncio
async def test_on_error_does_not_throw():
    manifest = _make_manifest()
    runtime = create_agent_runtime(manifest)
    ctx = RuntimeContext(agent_id="test", request_id="r1", input="hello", model="gpt")
    # Should not raise
    await runtime.on_error(ctx, ValueError("test error"))
