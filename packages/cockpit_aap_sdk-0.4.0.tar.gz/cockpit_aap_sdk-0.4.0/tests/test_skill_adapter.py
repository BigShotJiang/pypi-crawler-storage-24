"""Tests for ManifestSkillAdapter — trigger detection + system prompt injection."""

import pytest
from cockpit_aap.skill_adapter import create_manifest_skill_adapter
from cockpit_aap.manifest.types import ManifestSkill, ManifestSkillAutoInvoke


def _make_skill(
    name: str,
    instruction: str,
    triggers: list[str] | None = None,
    skill_id: str = "s1",
) -> ManifestSkill:
    auto = ManifestSkillAutoInvoke(triggers=triggers or []) if triggers else None
    return ManifestSkill(
        id=skill_id,
        name=name,
        description=f"Skill {name}",
        instruction=instruction,
        auto_invoke=auto,
    )


class TestDetectTriggers:
    def test_empty_skills(self):
        adapter = create_manifest_skill_adapter([])
        assert adapter.detect_triggers("hello world") == []

    def test_single_trigger_match(self):
        skills = [_make_skill("Security", "Do security review", ["security", "review"])]
        adapter = create_manifest_skill_adapter(skills)
        result = adapter.detect_triggers("Please do a security check")
        assert len(result) == 1
        assert result[0].name == "Security"

    def test_case_insensitive(self):
        skills = [_make_skill("Deploy", "Deploy module", ["deploy"])]
        adapter = create_manifest_skill_adapter(skills)
        assert len(adapter.detect_triggers("DEPLOY NOW")) == 1

    def test_no_match(self):
        skills = [_make_skill("Security", "Review", ["security"])]
        adapter = create_manifest_skill_adapter(skills)
        assert adapter.detect_triggers("hello world") == []

    def test_multiple_skills_match(self):
        skills = [
            _make_skill("Security", "Security review", ["security"], "s1"),
            _make_skill("Deploy", "Deploy module", ["deploy"], "s2"),
        ]
        adapter = create_manifest_skill_adapter(skills)
        result = adapter.detect_triggers("security deploy pipeline")
        assert len(result) == 2

    def test_skill_without_triggers(self):
        skill = ManifestSkill(
            id="s1", name="Manual", description="", instruction="manual only"
        )
        adapter = create_manifest_skill_adapter([skill])
        assert adapter.detect_triggers("anything") == []


class TestResolveInstruction:
    def test_string_instruction(self):
        skill = _make_skill("Test", "Do the thing")
        adapter = create_manifest_skill_adapter([])
        assert adapter.resolve_instruction(skill) == "Do the thing"

    def test_empty_instruction(self):
        skill = _make_skill("Test", "")
        adapter = create_manifest_skill_adapter([])
        assert adapter.resolve_instruction(skill) == ""


class TestBuildSkillSystemPrompt:
    def test_no_match_returns_base(self):
        skills = [_make_skill("Security", "Review", ["security"])]
        adapter = create_manifest_skill_adapter(skills)
        result = adapter.build_skill_system_prompt("hello", "Base prompt")
        assert result == "Base prompt"

    def test_match_appends_skill_section(self):
        skills = [_make_skill("Security", "Do security review", ["security"])]
        adapter = create_manifest_skill_adapter(skills)
        result = adapter.build_skill_system_prompt("security check", "Base prompt")
        assert "## Active Skills" in result
        assert "## Skill: Security" in result
        assert "Do security review" in result
        assert result.startswith("Base prompt")

    def test_multiple_matches_appended(self):
        skills = [
            _make_skill("Security", "Security review", ["security"], "s1"),
            _make_skill("Deploy", "Deploy module", ["deploy"], "s2"),
        ]
        adapter = create_manifest_skill_adapter(skills)
        result = adapter.build_skill_system_prompt("security deploy", "Base")
        assert "## Skill: Security" in result
        assert "## Skill: Deploy" in result
