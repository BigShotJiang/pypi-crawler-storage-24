"""Extended tests for structured logger — covers _emit_text_log branches and _build_json_entry."""
from __future__ import annotations

import json
import os
from io import StringIO
from unittest.mock import patch

import pytest

from cockpit_aap.logging.structured import (
    emit_log,
    _emit_text_log,
    _build_json_entry,
    _get_otel_context,
)


class TestEmitTextLog:
    def test_basic_text_output(self):
        with patch("builtins.print") as mock_print:
            _emit_text_log("info", "my-svc", "hello", "", "", 0, 0.0)
        output = mock_print.call_args[0][0]
        assert "[info]" in output
        assert "[my-svc]" in output
        assert "hello" in output

    def test_text_with_tenant_and_agent(self):
        with patch("builtins.print") as mock_print:
            _emit_text_log("warn", "svc", "msg", "tenant-1", "agent-1", 0, 0.0)
        output = mock_print.call_args[0][0]
        assert "tenant=tenant-1" in output
        assert "agent=agent-1" in output

    def test_text_with_tokens_and_cost(self):
        with patch("builtins.print") as mock_print:
            _emit_text_log("info", "svc", "msg", "", "", 500, 0.0123)
        output = mock_print.call_args[0][0]
        assert "tokens=500" in output
        assert "cost=$0.0123" in output

    def test_text_omits_empty_optional_fields(self):
        with patch("builtins.print") as mock_print:
            _emit_text_log("info", "svc", "msg", "", "", 0, 0.0)
        output = mock_print.call_args[0][0]
        assert "tenant=" not in output
        assert "agent=" not in output
        assert "tokens=" not in output
        assert "cost=" not in output


class TestBuildJsonEntry:
    def test_minimal_entry(self):
        entry = _build_json_entry(
            level="info", message="test", service="svc", module="mod",
            trace_id="", span_id="", tenant_id="", agent_id="",
            kind="", model="", request_id="", user_id="",
            token_count=0, cost_usd=0.0, error="", duration_ms=0.0,
            extra={},
        )
        assert entry["level"] == "info"
        assert entry["message"] == "test"
        assert entry["service"] == "svc"
        assert entry["module"] == "mod"
        assert "ts" in entry
        # Empty fields should not appear
        assert "traceId" not in entry
        assert "tenantId" not in entry
        assert "tokenCount" not in entry
        assert "costUsd" not in entry
        assert "error" not in entry
        assert "durationMs" not in entry

    def test_all_fields_populated(self):
        entry = _build_json_entry(
            level="error", message="fail", service="agent", module="mymod",
            trace_id="abc123", span_id="def456",
            tenant_id="t1", agent_id="a1",
            kind="Module", model="gpt-4o",
            request_id="req1", user_id="u1",
            token_count=1000, cost_usd=0.05,
            error="something broke", duration_ms=1500.5,
            extra={"custom": "value"},
        )
        assert entry["traceId"] == "abc123"
        assert entry["spanId"] == "def456"
        assert entry["tenantId"] == "t1"
        assert entry["agentId"] == "a1"
        assert entry["kind"] == "Module"
        assert entry["model"] == "gpt-4o"
        assert entry["requestId"] == "req1"
        assert entry["userId"] == "u1"
        assert entry["tokenCount"] == 1000
        assert entry["costUsd"] == 0.05
        assert entry["error"] == "something broke"
        assert entry["durationMs"] == 1500.5
        assert entry["custom"] == "value"

    def test_zero_cost_excluded(self):
        entry = _build_json_entry(
            level="info", message="x", service="s", module="m",
            trace_id="", span_id="", tenant_id="", agent_id="",
            kind="", model="", request_id="", user_id="",
            token_count=0, cost_usd=0.0, error="", duration_ms=0.0,
            extra={},
        )
        assert "costUsd" not in entry

    def test_extra_fields_merged(self):
        entry = _build_json_entry(
            level="info", message="x", service="s", module="m",
            trace_id="", span_id="", tenant_id="", agent_id="",
            kind="", model="", request_id="", user_id="",
            token_count=0, cost_usd=0.0, error="", duration_ms=0.0,
            extra={"key1": "val1", "key2": 42},
        )
        assert entry["key1"] == "val1"
        assert entry["key2"] == 42


class TestGetOtelContext:
    def test_returns_empty_when_otel_not_available(self):
        """When opentelemetry is not imported or no active span, returns empty strings."""
        # This may or may not have OTEL installed — either way it should not crash
        trace_id, span_id = _get_otel_context()
        # Either empty (no active span) or valid hex strings
        assert isinstance(trace_id, str)
        assert isinstance(span_id, str)


class TestEmitLogWithErrorField:
    def test_error_field_appears_in_json(self):
        with patch("sys.stdout", new_callable=StringIO) as mock_out:
            emit_log("error", "boom", service="svc", module="m", error="stack trace here")
        parsed = json.loads(mock_out.getvalue().strip())
        assert parsed["error"] == "stack trace here"
        assert parsed["level"] == "error"


class TestEmitLogWithTraceIds:
    def test_explicit_trace_and_span_ids(self):
        with patch("sys.stdout", new_callable=StringIO) as mock_out:
            emit_log(
                "info", "traced",
                service="svc", module="m",
                trace_id="aabbcc", span_id="ddeeff",
            )
        parsed = json.loads(mock_out.getvalue().strip())
        assert parsed["traceId"] == "aabbcc"
        assert parsed["spanId"] == "ddeeff"


class TestEmitLogWithRequestAndUser:
    def test_request_id_and_user_id(self):
        with patch("sys.stdout", new_callable=StringIO) as mock_out:
            emit_log(
                "info", "req",
                service="svc", module="m",
                request_id="req-123", user_id="user-456",
            )
        parsed = json.loads(mock_out.getvalue().strip())
        assert parsed["requestId"] == "req-123"
        assert parsed["userId"] == "user-456"


class TestEmitTextModeAllFields:
    def test_text_mode_with_all_fields(self):
        """Text mode includes tenant, agent, tokens, cost when present."""
        with patch.dict(os.environ, {"AAP_LOG_FORMAT": "text"}):
            with patch("builtins.print") as mock_print:
                _emit_text_log("info", "svc", "msg", "t1", "a1", 100, 0.5)
        output = mock_print.call_args[0][0]
        assert "tenant=t1" in output
        assert "agent=a1" in output
        assert "tokens=100" in output
        assert "cost=$0.5000" in output
