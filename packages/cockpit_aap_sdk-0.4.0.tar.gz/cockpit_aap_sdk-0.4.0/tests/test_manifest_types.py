"""Tests for Manifest Python dataclass types."""

from __future__ import annotations

import pytest

from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAccess,
    ManifestAgent,
    ManifestAIEcosystem,
    ManifestArtifact,
    ManifestRecognition,
    ManifestRecognitionBadge,
    ManifestRecognitionReward,
    ManifestChangelog,
    ManifestChangelogNote,
    ManifestCommand,
    ManifestCommandArg,
    ManifestConnection,
    ManifestFeatures,
    ManifestHelp,
    ManifestHook,
    ManifestI18n,
    ManifestLabels,
    ManifestLocale,
    ManifestLocaleOverrides,
    ManifestMetadata,
    ManifestOnboarding,
    ManifestOnboardingStep,
    ManifestPersonas,
    ManifestPersonaConfig,
    ManifestSkill,
    ManifestSkillAutoInvoke,
    ManifestSpec,
    ManifestTheme,
    ManifestThemeColors,
    ManifestThemePreset,
    ManifestTutorial,
)


def test_minimal_manifest() -> None:
    """A manifest with only the required fields should construct successfully."""
    manifest = Manifest(
        api_version="cockpit.io/v1",
        kind="Module",
        metadata=ManifestMetadata(
            name="my-module",
            display_name="My Module",
            version="1.0.0",
            description="A test module",
        ),
    )
    assert manifest.api_version == "cockpit.io/v1"
    assert manifest.kind == "Module"
    assert manifest.metadata.name == "my-module"
    assert manifest.metadata.version == "1.0.0"
    # All optional spec fields default to None
    assert manifest.spec.access is None
    assert manifest.spec.personas is None
    assert manifest.spec.features is None
    assert manifest.spec.agents is None
    assert manifest.spec.artifacts is None
    assert manifest.spec.recognition is None
    assert manifest.spec.ai_ecosystem is None
    assert manifest.spec.onboarding is None
    assert manifest.spec.help is None
    assert manifest.spec.changelog is None
    assert manifest.spec.i18n is None
    assert manifest.spec.commands is None
    assert manifest.spec.skills is None
    assert manifest.spec.hooks is None
    assert manifest.spec.connections is None
    assert manifest.spec.theme is None


def test_agent_with_runtime() -> None:
    """Agent can specify a runtime value explicitly."""
    agent = ManifestAgent(
        id="agent-1",
        name="Test Agent",
        description="Agent for testing",
        instruction="Do things",
        runtime="python",
    )
    assert agent.runtime == "python"
    assert agent.tools is None
    assert agent.model is None


def test_agent_runtime_defaults_to_any() -> None:
    """Agent runtime should default to 'any' when not specified."""
    agent = ManifestAgent(
        id="agent-2",
        name="Default Runtime Agent",
        description="Agent with default runtime",
        instruction="Do stuff",
    )
    assert agent.runtime == "any"


def test_connection() -> None:
    """Connection should store id, url, transport, and optional fields."""
    conn = ManifestConnection(
        id="mcp-server",
        url="http://localhost:3007/mcp",
        transport="streamable-http",
        headers={"Authorization": "Bearer xyz"},
        description="Local MCP server",
    )
    assert conn.id == "mcp-server"
    assert conn.url == "http://localhost:3007/mcp"
    assert conn.transport == "streamable-http"
    assert conn.headers == {"Authorization": "Bearer xyz"}
    assert conn.description == "Local MCP server"


def test_artifact_with_category() -> None:
    """Artifact should support category and tags."""
    artifact = ManifestArtifact(
        key="my-config",
        default_value='{"setting": true}',
        description="A JSON config artifact",
        artifact_type="JSON",
        accessibility="Namespace",
        category="configuration",
        tags=["config", "settings"],
        persona="admin",
    )
    assert artifact.key == "my-config"
    assert artifact.default_value == '{"setting": true}'
    assert artifact.artifact_type == "JSON"
    assert artifact.accessibility == "Namespace"
    assert artifact.category == "configuration"
    assert artifact.tags == ["config", "settings"]
    assert artifact.persona == "admin"


def test_manifest_with_all_sections() -> None:
    """A manifest with all sections populated should construct successfully."""
    manifest = Manifest(
        metadata=ManifestMetadata(
            name="full-module",
            display_name="Full Module",
            version="2.0.0",
            description="Module with all sections",
            icon="rocket",
            group="platform",
            route="/full",
            artifact_prefix="full",
        ),
        spec=ManifestSpec(
            access=ManifestAccess(roles=["admin"], permissions=["read", "write"]),
            personas=ManifestPersonas(
                default_persona="analyst",
                definitions=[
                    ManifestPersonaConfig(
                        persona_id="analyst",
                        display_name="Analyst",
                        description="Data analyst persona",
                        enabled=True,
                        icon="chart",
                        ui={"default_view": "dashboard", "show_advanced_options": True},
                        ai={"tone": "professional", "detail_level": "high"},
                    ),
                ],
            ),
            features=ManifestFeatures(flags={"beta": True, "experimental": False}),
            agents=[
                ManifestAgent(
                    id="main-agent",
                    name="Main Agent",
                    description="Primary agent",
                    instruction="You are helpful",
                    objective="Help users",
                    persona="analyst",
                    tools=["search", "create"],
                    type_id="type-uuid",
                    model="gpt-4o",
                    runtime="typescript",
                ),
            ],
            artifacts=[
                ManifestArtifact(
                    key="state",
                    default_value="{}",
                    category="state",
                ),
            ],
            recognition=ManifestRecognition(
                badges=[
                    ManifestRecognitionBadge(
                        id="first-use",
                        name="First Use",
                        description="Used the module for the first time",
                        icon="star",
                        criteria="usage_count >= 1",
                    ),
                ],
                rewards=[
                    ManifestRecognitionReward(
                        id="complete-task",
                        name="Complete Task",
                        description="Complete a task",
                        xp=5,
                    ),
                ],
            ),
            ai_ecosystem=ManifestAIEcosystem(
                value_category="productivity",
                estimated_hours_saved=2.5,
                observation_types=["usage", "feedback"],
            ),
            onboarding=ManifestOnboarding(
                welcome_message="Welcome!",
                steps=[
                    ManifestOnboardingStep(
                        title="Step 1",
                        description="First step",
                        action="navigate:/start",
                    ),
                ],
            ),
            help=ManifestHelp(
                documentation="https://docs.example.com",
                support="support@example.com",
                tutorials=[
                    ManifestTutorial(
                        title="Getting Started",
                        url="https://docs.example.com/start",
                        description="Learn the basics",
                    ),
                ],
            ),
            changelog=[
                ManifestChangelog(
                    version="2.0.0",
                    date="2026-01-15",
                    notes=[
                        ManifestChangelogNote(
                            type="new",
                            summary="Initial release",
                            key="INIT-001",
                        ),
                    ],
                ),
            ],
            labels=ManifestLabels(
                tags=["platform", "core"],
                custom={"team": "engineering"},
            ),
            i18n=ManifestI18n(
                default_locale="en",
                locales={
                    "en": ManifestLocale(
                        prompt_pills=[{"label": "Help", "prompt": "How can I help?"}],
                        welcome={"greeting": "Hello!", "tagline": "Your AI assistant"},
                    ),
                },
            ),
            commands=[
                ManifestCommand(
                    id="deploy",
                    name="Deploy",
                    description="Deploy the module",
                    script="scripts/deploy.ts",
                    args=[
                        ManifestCommandArg(
                            name="env",
                            type="string",
                            required=True,
                            description="Target environment",
                            default="staging",
                        ),
                    ],
                    allowed_tools=["deploy-tool"],
                    persona="admin",
                ),
            ],
            skills=[
                ManifestSkill(
                    id="analyze",
                    name="Analyze",
                    description="Analyze data",
                    instruction="Analyze the input data",
                    auto_invoke=ManifestSkillAutoInvoke(triggers=["analyze*"]),
                    persona="analyst",
                    references=["refs/analysis.md"],
                    examples=["examples/sample.md"],
                ),
            ],
            hooks=[
                ManifestHook(
                    event="preToolCall",
                    matcher="deploy*",
                    type="validate",
                    script="hooks/validate-deploy.ts",
                    artifact="deploy-config",
                    description="Validate before deploy",
                ),
            ],
            connections=[
                ManifestConnection(
                    id="backend",
                    url="http://localhost:3007/mcp",
                    transport="streamable-http",
                ),
            ],
            theme=ManifestTheme(
                default="light",
                presets={
                    "light": ManifestThemePreset(
                        label="Light",
                        colors=ManifestThemeColors(
                            primary="#000",
                            background="#fff",
                        ),
                        copilot_kit={"font-size": "14px"},
                        fonts={"body": "Inter"},
                        logo="/logo.svg",
                        color_scheme="light",
                    ),
                },
            ),
        ),
    )

    assert manifest.metadata.name == "full-module"
    assert manifest.spec.access is not None
    assert manifest.spec.access.roles == ["admin"]
    assert manifest.spec.personas is not None
    assert manifest.spec.personas.default_persona == "analyst"
    assert len(manifest.spec.personas.definitions) == 1
    assert manifest.spec.features is not None
    assert manifest.spec.features.flags == {"beta": True, "experimental": False}
    assert manifest.spec.agents is not None
    assert len(manifest.spec.agents) == 1
    assert manifest.spec.agents[0].runtime == "typescript"
    assert manifest.spec.artifacts is not None
    assert manifest.spec.recognition is not None
    assert manifest.spec.recognition.badges is not None
    assert len(manifest.spec.recognition.badges) == 1
    assert manifest.spec.ai_ecosystem is not None
    assert manifest.spec.ai_ecosystem.estimated_hours_saved == 2.5
    assert manifest.spec.onboarding is not None
    assert manifest.spec.help is not None
    assert manifest.spec.help.tutorials is not None
    assert len(manifest.spec.help.tutorials) == 1
    assert manifest.spec.changelog is not None
    assert len(manifest.spec.changelog) == 1
    assert manifest.spec.labels is not None
    assert manifest.spec.i18n is not None
    assert manifest.spec.i18n.default_locale == "en"
    assert manifest.spec.commands is not None
    assert len(manifest.spec.commands) == 1
    assert manifest.spec.commands[0].args is not None
    assert len(manifest.spec.commands[0].args) == 1
    assert manifest.spec.skills is not None
    assert manifest.spec.skills[0].auto_invoke is not None
    assert manifest.spec.skills[0].auto_invoke.triggers == ["analyze*"]
    assert manifest.spec.hooks is not None
    assert manifest.spec.hooks[0].event == "preToolCall"
    assert manifest.spec.connections is not None
    assert manifest.spec.theme is not None
    assert manifest.spec.theme.default == "light"
    assert "light" in manifest.spec.theme.presets
    assert manifest.spec.theme.presets["light"].color_scheme == "light"


def test_manifest_from_dict() -> None:
    """Manifest.from_dict should parse a raw dict with camelCase keys (new format)."""
    raw = {
        "apiVersion": "cockpit.io/v1",
        "kind": "Module",
        "metadata": {
            "name": "from-dict-mod",
            "displayName": "From Dict",
            "version": "1.0.0",
            "description": "Parsed from dict",
            "artifactPrefix": "fd",
        },
        "spec": {
            "access": {
                "roles": ["user"],
                "permissions": ["read"],
            },
            "agents": [
                {
                    "id": "a1",
                    "name": "Agent One",
                    "description": "First agent",
                    "instruction": "Be helpful",
                    "typeId": "uuid-type",
                    "runtime": "python",
                    "tools": ["tool1"],
                },
            ],
            "artifacts": [
                {
                    "key": "cfg",
                    "defaultValue": "{}",
                    "artifactType": "JSON",
                    "accessibility": "Namespace_User",
                    "category": "configuration",
                    "tags": ["cfg"],
                },
            ],
            "recognition": {
                "badges": [
                    {
                        "id": "b1",
                        "name": "Badge",
                        "description": "A badge",
                        "criteria": "x > 1",
                    },
                ],
                "rewards": [
                    {"id": "act", "name": "Act", "xp": 5},
                ],
            },
            "aiEcosystem": {
                "valueCategory": "efficiency",
                "estimatedHoursSaved": 3.0,
                "observationTypes": ["metric"],
            },
            "onboarding": {
                "welcomeMessage": "Hi!",
                "steps": [
                    {"title": "S1", "description": "Step one", "action": "go"},
                ],
            },
            "help": {
                "documentation": "https://docs.example.com",
                "tutorials": [
                    {"title": "Tut", "url": "https://tut.example.com"},
                ],
            },
            "changelog": [
                {
                    "version": "1.0.0",
                    "date": "2026-01-01",
                    "notes": [
                        {"type": "new", "summary": "Initial"},
                    ],
                },
            ],
            "labels": {
                "tags": ["test"],
                "custom": {"env": "dev"},
            },
            "i18n": {
                "defaultLocale": "en",
                "locales": {
                    "en": {
                        "prompt-pills": [{"label": "Ask", "prompt": "Ask me"}],
                        "welcome": {"greeting": "Hi", "tagline": "Hello"},
                    },
                },
            },
            "commands": [
                {
                    "id": "cmd1",
                    "name": "Cmd",
                    "description": "A command",
                    "script": "run.ts",
                    "args": [
                        {"name": "arg1", "type": "string", "required": True},
                    ],
                    "allowedTools": ["t1"],
                },
            ],
            "skills": [
                {
                    "id": "sk1",
                    "name": "Skill",
                    "description": "A skill",
                    "instruction": "Do it",
                    "autoInvoke": {"triggers": ["trigger*"]},
                    "references": ["ref.md"],
                    "examples": ["ex.md"],
                },
            ],
            "hooks": [
                {
                    "event": "onBootstrap",
                    "type": "script",
                    "script": "bootstrap.ts",
                    "description": "Run on bootstrap",
                },
            ],
            "connections": [
                {
                    "id": "conn1",
                    "url": "http://localhost:3007/mcp",
                    "transport": "streamable-http",
                    "headers": {"X-Key": "val"},
                    "description": "MCP server",
                },
            ],
            "personas": {
                "defaultPersona": "default",
                "definitions": [
                    {
                        "personaId": "default",
                        "displayName": "Default",
                        "description": "Default persona",
                        "enabled": True,
                        "ui": {"defaultView": "main", "showAdvancedOptions": False},
                        "ai": {"tone": "casual", "detailLevel": "medium"},
                    },
                ],
            },
            "features": {"flags": {"beta": True}},
            "theme": {
                "default": "dark",
                "presets": {
                    "dark": {
                        "label": "Dark",
                        "colors": {
                            "primary": "#fff",
                            "primary-foreground": "#000",
                            "sidebar-accent": "#333",
                        },
                        "copilotKit": {"size": "lg"},
                        "fonts": {"heading": "Roboto"},
                        "logo": "/dark-logo.svg",
                        "colorScheme": "dark",
                    },
                },
            },
        },
    }

    manifest = Manifest.from_dict(raw)

    # Metadata
    assert manifest.metadata.name == "from-dict-mod"
    assert manifest.metadata.artifact_prefix == "fd"
    assert manifest.metadata.display_name == "From Dict"

    # Access
    assert manifest.spec.access is not None
    assert manifest.spec.access.roles == ["user"]

    # Agents
    assert manifest.spec.agents is not None
    assert len(manifest.spec.agents) == 1
    assert manifest.spec.agents[0].type_id == "uuid-type"
    assert manifest.spec.agents[0].runtime == "python"

    # Artifacts
    assert manifest.spec.artifacts is not None
    assert manifest.spec.artifacts[0].default_value == "{}"
    assert manifest.spec.artifacts[0].artifact_type == "JSON"
    assert manifest.spec.artifacts[0].accessibility == "Namespace_User"

    # Recognition
    assert manifest.spec.recognition is not None
    assert manifest.spec.recognition.badges is not None
    assert len(manifest.spec.recognition.badges) == 1
    assert manifest.spec.recognition.rewards is not None
    assert manifest.spec.recognition.rewards[0].id == "act"

    # AI Ecosystem
    assert manifest.spec.ai_ecosystem is not None
    assert manifest.spec.ai_ecosystem.value_category == "efficiency"
    assert manifest.spec.ai_ecosystem.estimated_hours_saved == 3.0

    # Onboarding
    assert manifest.spec.onboarding is not None
    assert manifest.spec.onboarding.welcome_message == "Hi!"
    assert manifest.spec.onboarding.steps is not None
    assert manifest.spec.onboarding.steps[0].title == "S1"

    # Help
    assert manifest.spec.help is not None
    assert manifest.spec.help.tutorials is not None
    assert manifest.spec.help.tutorials[0].title == "Tut"

    # Changelog
    assert manifest.spec.changelog is not None
    assert manifest.spec.changelog[0].notes[0].type == "new"

    # Labels
    assert manifest.spec.labels is not None
    assert manifest.spec.labels.tags == ["test"]
    assert manifest.spec.labels.custom == {"env": "dev"}

    # I18n
    assert manifest.spec.i18n is not None
    assert manifest.spec.i18n.default_locale == "en"
    assert "en" in manifest.spec.i18n.locales
    locale = manifest.spec.i18n.locales["en"]
    assert locale.prompt_pills is not None
    assert locale.prompt_pills[0]["label"] == "Ask"
    assert locale.welcome is not None
    assert locale.welcome["greeting"] == "Hi"

    # Commands
    assert manifest.spec.commands is not None
    assert manifest.spec.commands[0].args is not None
    assert manifest.spec.commands[0].args[0].name == "arg1"
    assert manifest.spec.commands[0].allowed_tools == ["t1"]

    # Skills
    assert manifest.spec.skills is not None
    assert manifest.spec.skills[0].auto_invoke is not None
    assert manifest.spec.skills[0].auto_invoke.triggers == ["trigger*"]
    assert manifest.spec.skills[0].references == ["ref.md"]

    # Hooks
    assert manifest.spec.hooks is not None
    assert manifest.spec.hooks[0].event == "onBootstrap"
    assert manifest.spec.hooks[0].type == "script"

    # Connections
    assert manifest.spec.connections is not None
    assert manifest.spec.connections[0].transport == "streamable-http"
    assert manifest.spec.connections[0].headers == {"X-Key": "val"}

    # Personas
    assert manifest.spec.personas is not None
    assert manifest.spec.personas.default_persona == "default"
    persona = manifest.spec.personas.definitions[0]
    assert persona.persona_id == "default"
    assert persona.display_name == "Default"
    assert persona.ui == {"default_view": "main", "show_advanced_options": False}
    assert persona.ai == {"tone": "casual", "detail_level": "medium"}

    # Features
    assert manifest.spec.features is not None
    assert manifest.spec.features.flags == {"beta": True}

    # Theme
    assert manifest.spec.theme is not None
    assert manifest.spec.theme.default == "dark"
    preset = manifest.spec.theme.presets["dark"]
    assert preset.label == "Dark"
    assert preset.colors.primary == "#fff"
    assert preset.colors.primary_foreground == "#000"
    assert preset.colors.sidebar_accent == "#333"
    assert preset.copilot_kit == {"size": "lg"}
    assert preset.fonts == {"heading": "Roboto"}
    assert preset.logo == "/dark-logo.svg"
    assert preset.color_scheme == "dark"


def test_locale_overrides_structure() -> None:
    """ManifestLocaleOverrides should accept nested override dicts."""
    overrides = ManifestLocaleOverrides(
        module={"name": "Localized Name"},
        agents={"agent-1": {"name": "Agente Um", "instruction": "Ajude"}},
        personas={"analyst": {"display_name": "Analista"}},
        onboarding={"welcome_message": "Bem-vindo!"},
        recognition={"badges": {"b1": {"name": "Distintivo"}}},
        commands={"cmd1": {"name": "Comando"}},
        skills={"sk1": {"name": "Habilidade"}},
        hooks={"preToolCall": {"description": "Antes da chamada"}},
        connections={"conn1": {"description": "Conexao"}},
    )
    assert overrides.module == {"name": "Localized Name"}
    assert overrides.agents is not None
    assert overrides.agents["agent-1"]["name"] == "Agente Um"


def test_theme_colors_extra_keys() -> None:
    """ManifestThemeColors should accept extra CSS custom property keys."""
    colors = ManifestThemeColors(
        primary="#000",
        extra={"custom-color": "#abc"},
    )
    assert colors.primary == "#000"
    assert colors.extra == {"custom-color": "#abc"}
