import pytest
from cockpit_aap.testing import mock_manifest, assert_guardrail_blocks, assert_guardrail_passes, BuiltInEval
from cockpit_aap.runtime import create_agent_runtime, RegexGuardrailAdapter


@pytest.mark.asyncio
async def test_assert_guardrail_blocks_pii():
    manifest = mock_manifest()
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})
    await assert_guardrail_blocks(runtime, "Email: john@test.com", "pii")


@pytest.mark.asyncio
async def test_assert_guardrail_passes_clean():
    manifest = mock_manifest()
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})
    await assert_guardrail_passes(runtime, "What is the weather?")


@pytest.mark.asyncio
async def test_built_in_eval_passes_block():
    manifest = mock_manifest()
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})
    eval_ = BuiltInEval(runtime)
    result = await eval_.run({"id": "t1", "input": "Email: a@b.com", "mode": "mock", "expectedAction": "block"})
    assert result["passed"] is True


@pytest.mark.asyncio
async def test_built_in_eval_passes_clean():
    manifest = mock_manifest()
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})
    eval_ = BuiltInEval(runtime)
    result = await eval_.run({"id": "t2", "input": "Hello world", "mode": "mock", "expectedAction": "pass"})
    assert result["passed"] is True


@pytest.mark.asyncio
async def test_built_in_eval_fails_mismatch():
    manifest = mock_manifest()
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})
    eval_ = BuiltInEval(runtime)
    result = await eval_.run({"id": "t3", "input": "Hello", "mode": "mock", "expectedAction": "block"})
    assert result["passed"] is False
    assert "Expected action" in result["error"]


@pytest.mark.asyncio
async def test_built_in_eval_live_unsupported():
    manifest = mock_manifest()
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})
    eval_ = BuiltInEval(runtime)
    result = await eval_.run({"id": "t4", "input": "test", "mode": "live"})
    assert result["passed"] is False
    assert "external adapter" in result["error"]
