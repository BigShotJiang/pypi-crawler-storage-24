"""Tests for telemetry adapters:
- telemetry/otel_adapter.py (OtelObservabilityAdapter)
- telemetry/provider.py (init_telemetry, shutdown_telemetry, TelemetryConfig)
"""
from __future__ import annotations

import json
from unittest.mock import MagicMock, AsyncMock, patch

import pytest


# ===========================================================================
# OtelObservabilityAdapter
# ===========================================================================


class TestOtelObservabilityAdapter:
    def test_init_with_tracer(self):
        from cockpit_aap.telemetry.otel_adapter import OtelObservabilityAdapter
        mock_tracer = MagicMock()
        adapter = OtelObservabilityAdapter(tracer=mock_tracer)
        assert adapter._tracer is mock_tracer

    def test_init_without_tracer(self):
        from cockpit_aap.telemetry.otel_adapter import OtelObservabilityAdapter
        adapter = OtelObservabilityAdapter()
        # Either gets real tracer or None depending on if otel is installed
        assert adapter is not None

    def test_start_span(self):
        from cockpit_aap.telemetry.otel_adapter import OtelObservabilityAdapter, _OtelSpan
        mock_tracer = MagicMock()
        mock_inner_span = MagicMock()
        mock_tracer.start_span.return_value = mock_inner_span
        adapter = OtelObservabilityAdapter(tracer=mock_tracer)

        span = adapter.start_span("test-span", attributes={"key": "val"})
        mock_tracer.start_span.assert_called_once_with("test-span", attributes={"key": "val"})
        assert isinstance(span, _OtelSpan)

    def test_record_metric(self, capsys):
        from cockpit_aap.telemetry.otel_adapter import OtelObservabilityAdapter
        adapter = OtelObservabilityAdapter(tracer=MagicMock())
        adapter.record_metric("req.count", 5, metric_type="count", unit="1", attributes={"agent": "bot"})
        captured = capsys.readouterr()
        data = json.loads(captured.out.strip())
        assert data["metric"] == "req.count"
        assert data["value"] == 5
        assert data["type"] == "count"
        assert data["agent"] == "bot"

    def test_record_metric_no_attrs(self, capsys):
        from cockpit_aap.telemetry.otel_adapter import OtelObservabilityAdapter
        adapter = OtelObservabilityAdapter(tracer=MagicMock())
        adapter.record_metric("m", 1.0)
        captured = capsys.readouterr()
        data = json.loads(captured.out.strip())
        assert data["metric"] == "m"

    def test_log_event(self, capsys):
        from cockpit_aap.telemetry.otel_adapter import OtelObservabilityAdapter
        adapter = OtelObservabilityAdapter(tracer=MagicMock())
        adapter.log_event("user_login", {"user": "alice"})
        captured = capsys.readouterr()
        data = json.loads(captured.out.strip())
        assert data["event"] == "user_login"
        assert data["user"] == "alice"
        assert "ts" in data

    def test_factory_function(self):
        from cockpit_aap.telemetry.otel_adapter import create_otel_observability
        adapter = create_otel_observability(tracer=MagicMock(), scope="test")
        assert adapter is not None


class TestOtelSpan:
    def test_span_id(self):
        from cockpit_aap.telemetry.otel_adapter import _OtelSpan
        mock_inner = MagicMock()
        span = _OtelSpan(mock_inner)
        assert span.span_id  # UUID string

    def test_set_attribute(self):
        from cockpit_aap.telemetry.otel_adapter import _OtelSpan
        mock_inner = MagicMock()
        span = _OtelSpan(mock_inner)
        span.set_attribute("key", "val")
        mock_inner.set_attribute.assert_called_once_with("key", "val")

    def test_record_exception(self):
        from cockpit_aap.telemetry.otel_adapter import _OtelSpan
        mock_inner = MagicMock()
        span = _OtelSpan(mock_inner)
        exc = ValueError("test")
        span.record_exception(exc)
        mock_inner.record_exception.assert_called_once_with(exc)

    def test_context_manager(self):
        from cockpit_aap.telemetry.otel_adapter import _OtelSpan
        mock_inner = MagicMock()
        span = _OtelSpan(mock_inner)
        with span as s:
            assert s is span
        mock_inner.end.assert_called_once()

    def test_set_status_ok(self):
        from cockpit_aap.telemetry.otel_adapter import _OtelSpan
        mock_inner = MagicMock()
        span = _OtelSpan(mock_inner)
        # This may or may not work depending on otel being installed
        try:
            span.set_status("ok")
            mock_inner.set_status.assert_called_once()
        except ImportError:
            pass  # otel not installed

    def test_set_status_error(self):
        from cockpit_aap.telemetry.otel_adapter import _OtelSpan
        mock_inner = MagicMock()
        span = _OtelSpan(mock_inner)
        try:
            span.set_status("error", "something went wrong")
            mock_inner.set_status.assert_called_once()
        except ImportError:
            pass

    def test_set_status_unset(self):
        from cockpit_aap.telemetry.otel_adapter import _OtelSpan
        mock_inner = MagicMock()
        span = _OtelSpan(mock_inner)
        try:
            span.set_status("other")
            mock_inner.set_status.assert_called_once()
        except ImportError:
            pass


# ===========================================================================
# TelemetryConfig
# ===========================================================================


class TestTelemetryConfig:
    def test_defaults(self):
        from cockpit_aap.telemetry.provider import TelemetryConfig
        cfg = TelemetryConfig()
        assert cfg.service_name == "cockpit-aap"
        assert cfg.service_version is None
        assert cfg.otlp_endpoint is None
        assert cfg.enabled is True

    def test_custom(self):
        from cockpit_aap.telemetry.provider import TelemetryConfig
        cfg = TelemetryConfig(
            service_name="my-app",
            service_version="2.0.0",
            otlp_endpoint="http://localhost:4318",
            enabled=False,
        )
        assert cfg.service_name == "my-app"
        assert not cfg.enabled


# ===========================================================================
# init_telemetry / shutdown_telemetry
# ===========================================================================


class TestInitTelemetry:
    def setup_method(self):
        # Reset global state before each test
        import cockpit_aap.telemetry.provider as prov
        prov._sdk_instance = None

    def test_disabled(self):
        from cockpit_aap.telemetry.provider import init_telemetry, TelemetryConfig, _sdk_instance
        init_telemetry(TelemetryConfig(enabled=False))
        import cockpit_aap.telemetry.provider as prov
        assert prov._sdk_instance is None

    def test_default_config(self):
        from cockpit_aap.telemetry.provider import init_telemetry
        # Will either init otel or silently no-op if not installed
        init_telemetry()

    def test_idempotent(self):
        import cockpit_aap.telemetry.provider as prov
        prov._sdk_instance = MagicMock()  # Pretend already init'd
        from cockpit_aap.telemetry.provider import init_telemetry
        init_telemetry()
        # Should not replace existing instance
        assert prov._sdk_instance is not None

    @pytest.mark.asyncio
    async def test_shutdown_when_none(self):
        import cockpit_aap.telemetry.provider as prov
        prov._sdk_instance = None
        from cockpit_aap.telemetry.provider import shutdown_telemetry
        await shutdown_telemetry()
        assert prov._sdk_instance is None

    @pytest.mark.asyncio
    async def test_shutdown_calls_shutdown(self):
        import cockpit_aap.telemetry.provider as prov
        mock_sdk = MagicMock()
        prov._sdk_instance = mock_sdk
        from cockpit_aap.telemetry.provider import shutdown_telemetry
        await shutdown_telemetry()
        mock_sdk.shutdown.assert_called_once()
        assert prov._sdk_instance is None

    @pytest.mark.asyncio
    async def test_shutdown_swallows_exception(self):
        import cockpit_aap.telemetry.provider as prov
        mock_sdk = MagicMock()
        mock_sdk.shutdown.side_effect = Exception("shutdown failed")
        prov._sdk_instance = mock_sdk
        from cockpit_aap.telemetry.provider import shutdown_telemetry
        await shutdown_telemetry()  # Should not raise
        assert prov._sdk_instance is None
