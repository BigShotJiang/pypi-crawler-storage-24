"""Tests for the policy engine factory."""
import pytest
from unittest.mock import patch

from cockpit_aap.adapters.policy_factory import create_policy_engine
from cockpit_aap.adapters.noop_policy import NoopPolicyAdapter
from cockpit_aap.ports.policy_engine import PolicyInput


@pytest.mark.asyncio
async def test_creates_engine():
    """Factory returns a valid engine with a known type string."""
    engine, engine_type = await create_policy_engine()
    assert engine_type in ("wasm", "cli", "noop")
    assert hasattr(engine, "evaluate")
    assert hasattr(engine, "load_policies")
    assert hasattr(engine, "is_ready")


@pytest.mark.asyncio
async def test_forces_noop():
    """Passing preferred='noop' always returns NoopPolicyAdapter."""
    engine, engine_type = await create_policy_engine("noop")
    assert engine_type == "noop"
    assert isinstance(engine, NoopPolicyAdapter)
    assert engine.is_ready()
    result = await engine.evaluate(PolicyInput(manifest={}))
    assert result.passed is True
    assert result.grade == "A"


@pytest.mark.asyncio
async def test_noop_policy_shape():
    """NoopPolicyAdapter returns a fully-populated PolicyDecision."""
    engine = NoopPolicyAdapter()
    assert engine.is_ready() is True
    result = await engine.evaluate(PolicyInput(manifest={}))
    assert result.passed is True
    assert result.grade == "A"
    assert result.violations == []
    assert result.breakdown == {}
    assert result.percentage == 100


@pytest.mark.asyncio
async def test_auto_detect_falls_back_to_noop_when_opa_absent():
    """When OPA CLI is unavailable and opa-wasm is not installed, fallback is noop."""
    with patch("cockpit_aap.adapters.opa_cli_policy.is_opa_available", return_value=False):
        # Also ensure opa-wasm import fails
        import sys
        saved = sys.modules.get("opa_wasm")
        sys.modules["opa_wasm"] = None  # type: ignore[assignment]
        try:
            import warnings
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                engine, engine_type = await create_policy_engine()
            assert engine_type == "noop"
            assert len(w) == 1
            assert "OPA not available" in str(w[0].message)
        finally:
            if saved is None:
                sys.modules.pop("opa_wasm", None)
            else:
                sys.modules["opa_wasm"] = saved


@pytest.mark.asyncio
async def test_forces_cli_when_opa_present():
    """Passing preferred='cli' returns OpaCliPolicyAdapter regardless."""
    from cockpit_aap.adapters.opa_cli_policy import OpaCliPolicyAdapter
    engine, engine_type = await create_policy_engine("cli")
    assert engine_type == "cli"
    assert isinstance(engine, OpaCliPolicyAdapter)


@pytest.mark.asyncio
async def test_forces_wasm():
    """Passing preferred='wasm' returns OpaWasmPolicyAdapter."""
    from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
    engine, engine_type = await create_policy_engine("wasm")
    assert engine_type == "wasm"
    assert isinstance(engine, OpaWasmPolicyAdapter)
