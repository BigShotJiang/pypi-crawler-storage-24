"""Extended tests for bootstrap_kind() — covers local-wins, remote-wins, error strategy, policy engine, and save."""
from __future__ import annotations

from dataclasses import dataclass, field

import pytest

from cockpit_aap.bootstrap_kind import bootstrap_kind, BootstrapKindResult
from cockpit_aap.manifest.kind_registry import kind_registry


class FakeSource:
    """In-memory ManifestSourceProtocol for testing."""

    def __init__(self, store: dict | None = None):
        self._store = store or {}

    async def load(self, id: str, kind: str = "Module"):
        key = f"{kind}:{id}"
        if key not in self._store:
            raise KeyError(f"Not found: {key}")
        return self._store[key]

    async def save(self, id: str, kind: str, manifest):
        self._store[f"{kind}:{id}"] = manifest

    async def list(self, kind: str = "Module"):
        return [k.split(":")[1] for k in self._store if k.startswith(f"{kind}:")]


class FakeSourceNoSave:
    """Source without save method."""

    def __init__(self, store: dict | None = None):
        self._store = store or {}

    async def load(self, id: str, kind: str = "Module"):
        key = f"{kind}:{id}"
        if key not in self._store:
            raise KeyError(f"Not found: {key}")
        return self._store[key]


# ── Strategy: local-wins (with both local + remote) ──

@pytest.mark.asyncio
async def test_local_wins_strategy(tmp_path):
    """When both local and remote exist, local-wins saves local to source."""
    # Create a local manifest directory with a manifest.yaml
    manifest_dir = tmp_path / ".aap" / "my-mod"
    manifest_dir.mkdir(parents=True)
    (manifest_dir / "manifest.yaml").write_text(
        "apiVersion: cockpit.io/v1\nkind: Module\nmetadata:\n  name: my-mod\nspec: {}"
    )

    remote_manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "my-mod"}, "spec": {"old": True}}
    source = FakeSource({"Module:my-mod": remote_manifest})

    result = await bootstrap_kind(
        source=source, kind="Module", id="my-mod",
        manifest_dir=str(manifest_dir), strategy="local-wins",
    )

    assert result.action == "updated"
    assert result.source == "local"
    # Local manifest should have been saved to source
    assert "Module:my-mod" in source._store


@pytest.mark.asyncio
async def test_remote_wins_strategy(tmp_path):
    """When both local and remote exist, remote-wins preserves remote."""
    manifest_dir = tmp_path / ".aap" / "my-mod"
    manifest_dir.mkdir(parents=True)
    (manifest_dir / "manifest.yaml").write_text(
        "apiVersion: cockpit.io/v1\nkind: Module\nmetadata:\n  name: my-mod\nspec: {}"
    )

    remote_manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "my-mod"}, "spec": {"remote": True}}
    source = FakeSource({"Module:my-mod": remote_manifest})

    result = await bootstrap_kind(
        source=source, kind="Module", id="my-mod",
        manifest_dir=str(manifest_dir), strategy="remote-wins",
    )

    assert result.action == "preserved"
    assert result.source == "remote"
    assert result.manifest == remote_manifest


@pytest.mark.asyncio
async def test_error_strategy_raises(tmp_path):
    """When both local and remote exist and strategy is 'error', raise RuntimeError."""
    manifest_dir = tmp_path / ".aap" / "my-mod"
    manifest_dir.mkdir(parents=True)
    (manifest_dir / "manifest.yaml").write_text(
        "apiVersion: cockpit.io/v1\nkind: Module\nmetadata:\n  name: my-mod\nspec: {}"
    )

    remote_manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "my-mod"}, "spec": {}}
    source = FakeSource({"Module:my-mod": remote_manifest})

    with pytest.raises(RuntimeError, match="Both local and remote"):
        await bootstrap_kind(
            source=source, kind="Module", id="my-mod",
            manifest_dir=str(manifest_dir), strategy="error",
        )


# ── Local only (no remote) ──

@pytest.mark.asyncio
async def test_local_only_creates(tmp_path):
    """When only local manifest exists, action is 'created' and it is saved."""
    manifest_dir = tmp_path / ".aap" / "new-mod"
    manifest_dir.mkdir(parents=True)
    (manifest_dir / "manifest.yaml").write_text(
        "apiVersion: cockpit.io/v1\nkind: Module\nmetadata:\n  name: new-mod\nspec: {}"
    )

    source = FakeSource()  # Empty — no remote

    result = await bootstrap_kind(
        source=source, kind="Module", id="new-mod",
        manifest_dir=str(manifest_dir),
    )

    assert result.action == "created"
    assert result.source == "local"
    assert "Module:new-mod" in source._store


# ── Dry run with local manifest ──

@pytest.mark.asyncio
async def test_dry_run_uses_local_if_available(tmp_path):
    """Dry run prefers local manifest and does not save."""
    manifest_dir = tmp_path / ".aap" / "dry-mod"
    manifest_dir.mkdir(parents=True)
    (manifest_dir / "manifest.yaml").write_text(
        "apiVersion: cockpit.io/v1\nkind: Module\nmetadata:\n  name: dry-mod\nspec: {}"
    )

    source = FakeSource()

    result = await bootstrap_kind(
        source=source, kind="Module", id="dry-mod",
        manifest_dir=str(manifest_dir), dry_run=True,
    )

    assert result.action == "validated-only"
    assert result.source == "local"
    # Should NOT have saved
    assert "Module:dry-mod" not in source._store


@pytest.mark.asyncio
async def test_dry_run_no_manifest_raises():
    """Dry run with no local or remote raises RuntimeError."""
    source = FakeSource()

    with pytest.raises(RuntimeError, match="No manifest found"):
        await bootstrap_kind(source=source, kind="Module", id="gone", dry_run=True)


# ── Policy engine integration ──

@pytest.mark.asyncio
async def test_policy_engine_passing():
    """Policy engine that passes should include decision in result."""
    from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyViolation, PolicyInput

    class PassingPolicyEngine:
        async def evaluate(self, input: PolicyInput) -> PolicyDecision:
            return PolicyDecision(passed=True, grade="A", violations=[])

    manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "t"}, "spec": {}}
    source = FakeSource({"Module:t": manifest})

    result = await bootstrap_kind(
        source=source, kind="Module", id="t",
        policy_engine=PassingPolicyEngine(),
    )

    assert result.policy_decision is not None
    assert result.policy_decision["passed"] is True
    assert result.policy_decision["grade"] == "A"


@pytest.mark.asyncio
async def test_policy_engine_fails_with_critical():
    """Policy engine with critical violations blocks bootstrap."""
    from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyViolation, PolicyInput

    class FailingPolicyEngine:
        async def evaluate(self, input: PolicyInput) -> PolicyDecision:
            return PolicyDecision(
                passed=False, grade="F",
                violations=[
                    PolicyViolation(policy="test-policy", rule="must-have-desc",
                                    message="Missing description", severity="error"),
                ],
            )

    manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "t"}, "spec": {}}
    source = FakeSource({"Module:t": manifest})

    with pytest.raises(RuntimeError, match="Policy evaluation failed"):
        await bootstrap_kind(
            source=source, kind="Module", id="t",
            policy_engine=FailingPolicyEngine(),
        )


@pytest.mark.asyncio
async def test_policy_engine_warning_only_does_not_block():
    """Policy engine with only warning violations does not block."""
    from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyViolation, PolicyInput

    class WarnPolicyEngine:
        async def evaluate(self, input: PolicyInput) -> PolicyDecision:
            return PolicyDecision(
                passed=False, grade="C",
                violations=[
                    PolicyViolation(policy="test-policy", rule="should-have-desc",
                                    message="Missing description", severity="warning"),
                ],
            )

    manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "t"}, "spec": {}}
    source = FakeSource({"Module:t": manifest})

    result = await bootstrap_kind(
        source=source, kind="Module", id="t",
        policy_engine=WarnPolicyEngine(),
    )

    assert result.policy_decision is not None
    assert result.policy_decision["passed"] is False
    assert len(result.policy_decision["violations"]) == 1


@pytest.mark.asyncio
async def test_policy_engine_dry_run_does_not_block():
    """Dry run does not block even with critical policy violations."""
    from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyViolation, PolicyInput

    class CriticalPolicyEngine:
        async def evaluate(self, input: PolicyInput) -> PolicyDecision:
            return PolicyDecision(
                passed=False, grade="F",
                violations=[
                    PolicyViolation(policy="p", rule="r", message="critical", severity="error"),
                ],
            )

    manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "t"}, "spec": {}}
    source = FakeSource({"Module:t": manifest})

    result = await bootstrap_kind(
        source=source, kind="Module", id="t",
        policy_engine=CriticalPolicyEngine(), dry_run=True,
    )

    assert result.action == "validated-only"
    assert result.policy_decision["passed"] is False


# ── Source without save ──

@pytest.mark.asyncio
async def test_source_without_save(tmp_path):
    """Source without save method should still work (skip save step)."""
    manifest_dir = tmp_path / ".aap" / "nosave"
    manifest_dir.mkdir(parents=True)
    (manifest_dir / "manifest.yaml").write_text(
        "apiVersion: cockpit.io/v1\nkind: Module\nmetadata:\n  name: nosave\nspec: {}"
    )

    source = FakeSourceNoSave()

    result = await bootstrap_kind(
        source=source, kind="Module", id="nosave",
        manifest_dir=str(manifest_dir),
    )

    assert result.action == "created"
    assert result.source == "local"


# ── Verbose logging ──

@pytest.mark.asyncio
async def test_verbose_logging(capsys):
    """Verbose mode prints progress messages."""
    manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "v"}, "spec": {}}
    source = FakeSource({"Module:v": manifest})

    await bootstrap_kind(
        source=source, kind="Module", id="v", verbose=True,
    )

    captured = capsys.readouterr()
    assert "[bootstrapKind:Module]" in captured.out


# ── Scan failure fallback ──

@pytest.mark.asyncio
async def test_scan_failure_falls_to_remote(tmp_path):
    """If local scan fails, fall back to remote manifest."""
    manifest_dir = tmp_path / ".aap" / "bad-scan"
    manifest_dir.mkdir(parents=True)
    # Write invalid YAML that will cause scan to fail
    (manifest_dir / "manifest.yaml").write_text("this is not: valid: yaml: {{{{")

    remote_manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "bad-scan"}, "spec": {}}
    source = FakeSource({"Module:bad-scan": remote_manifest})

    result = await bootstrap_kind(
        source=source, kind="Module", id="bad-scan",
        manifest_dir=str(manifest_dir),
    )

    assert result.source == "remote"
    assert result.action == "preserved"
