"""Shared fixtures and path setup for tests."""

import sys
from pathlib import Path

# Ensure the tests directory itself is importable (for helpers sub-package)
_tests_dir = Path(__file__).parent
if str(_tests_dir) not in sys.path:
    sys.path.insert(0, str(_tests_dir))
