import pytest
from cockpit_aap.adapters.noop_knowledge_adapter import create_noop_knowledge_adapter
from cockpit_aap.adapters.filesystem_knowledge_adapter import create_filesystem_knowledge_adapter
from cockpit_aap.ports import KnowledgeDocument


@pytest.mark.asyncio
async def test_noop_search_empty():
    a = create_noop_knowledge_adapter()
    assert await a.search("anything") == []


@pytest.mark.asyncio
async def test_noop_ingest_ids():
    a = create_noop_knowledge_adapter()
    ids = await a.ingest([KnowledgeDocument(id="d1", content="Hello"), KnowledgeDocument(id="d2", content="World")])
    assert ids == ["d1", "d2"]


@pytest.mark.asyncio
async def test_noop_count():
    assert await create_noop_knowledge_adapter().count() == 0


@pytest.fixture
def knowledge_dir(tmp_path):
    (tmp_path / "overview.md").write_text("# AAP SDK Overview\nThe AAP SDK is a composition framework for agentic systems.")
    (tmp_path / "manifest.md").write_text("# Manifest Guide\nA manifest is a YAML file with apiVersion cockpit.io/v1 and kind Module.")
    return tmp_path


@pytest.mark.asyncio
async def test_fs_ingest_count(knowledge_dir):
    a = create_filesystem_knowledge_adapter()
    await a.ingest([
        KnowledgeDocument(id="overview", content="", metadata={"path": str(knowledge_dir / "overview.md")}),
        KnowledgeDocument(id="manifest", content="", metadata={"path": str(knowledge_dir / "manifest.md")}),
    ])
    assert await a.count() > 0


@pytest.mark.asyncio
async def test_fs_search_relevant(knowledge_dir):
    a = create_filesystem_knowledge_adapter()
    await a.ingest([
        KnowledgeDocument(id="overview", content="", metadata={"path": str(knowledge_dir / "overview.md")}),
        KnowledgeDocument(id="manifest", content="", metadata={"path": str(knowledge_dir / "manifest.md")}),
    ])
    results = await a.search("manifest YAML")
    assert len(results) > 0
    assert "manifest" in results[0].content.lower()


@pytest.mark.asyncio
async def test_fs_search_no_match(knowledge_dir):
    a = create_filesystem_knowledge_adapter()
    await a.ingest([KnowledgeDocument(id="overview", content="", metadata={"path": str(knowledge_dir / "overview.md")})])
    assert await a.search("xyznonexistent") == []
