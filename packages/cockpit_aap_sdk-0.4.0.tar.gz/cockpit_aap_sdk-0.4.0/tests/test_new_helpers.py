"""Tests for new manifest helper functions added in Phase 4.8+ parity.

Covers: get_agent_execution_mode, get_agents_by_execution_mode, get_local_agents,
get_platform_agents, get_azure_foundry_agents, get_manifest_knowledge,
get_manifest_knowledge_by_kind, get_manifest_hitl_tools, get_manifest_hitl_tool,
get_manifest_health_checks, get_manifest_ui_*, get_manifest_network,
get_manifest_journey_stages, get_manifest_input_context_skills.
"""

from __future__ import annotations

import pytest

from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAgent,
    ManifestHealthCheck,
    ManifestHITLTool,
    ManifestJourney,
    ManifestJourneyStage,
    ManifestKnowledge,
    ManifestMetadata,
    ManifestNetwork,
    ManifestSkill,
    ManifestSkillAutoInvoke,
    ManifestSpec,
    ManifestUI,
    ManifestUIAgentMode,
    ManifestUIInputMode,
    ManifestUISection,
)
from cockpit_aap.manifest.helpers import (
    get_agent_execution_mode,
    get_agents_by_execution_mode,
    get_azure_foundry_agents,
    get_local_agents,
    get_manifest_health_checks,
    get_manifest_hitl_tool,
    get_manifest_hitl_tools,
    get_manifest_input_context_skills,
    get_manifest_journey_stages,
    get_manifest_knowledge,
    get_manifest_knowledge_by_kind,
    get_manifest_network,
    get_manifest_ui_agent_modes,
    get_manifest_ui_input_modes,
    get_manifest_ui_sections,
    get_platform_agents,
)


def _make_manifest(**spec_kwargs) -> Manifest:
    return Manifest(
        api_version="cockpit.io/v1",
        kind="Module",
        metadata=ManifestMetadata(name="test"),
        spec=ManifestSpec(**spec_kwargs),
    )


# ---------------------------------------------------------------------------
# Agent execution helpers
# ---------------------------------------------------------------------------


class TestAgentExecution:
    def test_default_mode_is_local(self):
        agent = ManifestAgent(id="a1", name="A1", instruction="do stuff")
        assert get_agent_execution_mode(agent) == "local"

    def test_platform_mode(self):
        agent = ManifestAgent(
            id="a2", name="A2", instruction="do stuff",
            execution={"mode": "platform"},
        )
        assert get_agent_execution_mode(agent) == "platform"

    def test_get_local_agents(self):
        agents = [
            ManifestAgent(id="a1", name="A1", instruction="x"),
            ManifestAgent(id="a2", name="A2", instruction="x", execution={"mode": "platform"}),
            ManifestAgent(id="a3", name="A3", instruction="x"),
        ]
        m = _make_manifest(agents=agents)
        result = get_local_agents(m)
        assert len(result) == 2
        assert all(a.id in ("a1", "a3") for a in result)

    def test_get_platform_agents(self):
        agents = [
            ManifestAgent(id="a1", name="A1", instruction="x"),
            ManifestAgent(id="a2", name="A2", instruction="x", execution={"mode": "platform"}),
        ]
        m = _make_manifest(agents=agents)
        assert len(get_platform_agents(m)) == 1
        assert get_platform_agents(m)[0].id == "a2"

    def test_get_azure_foundry_agents(self):
        agents = [
            ManifestAgent(id="a1", name="A1", instruction="x", execution={"mode": "azure-foundry"}),
        ]
        m = _make_manifest(agents=agents)
        assert len(get_azure_foundry_agents(m)) == 1


# ---------------------------------------------------------------------------
# Knowledge helpers
# ---------------------------------------------------------------------------


class TestKnowledge:
    def test_get_knowledge_empty(self):
        m = _make_manifest()
        assert get_manifest_knowledge(m) == []

    def test_get_knowledge(self):
        knowledge = [
            ManifestKnowledge(kind="config", key_pattern="module.config.*", description="Configs"),
            ManifestKnowledge(kind="state", key_pattern="module.state.*", description="States"),
        ]
        m = _make_manifest(knowledge=knowledge)
        result = get_manifest_knowledge(m)
        assert len(result) == 2

    def test_get_knowledge_by_kind(self):
        knowledge = [
            ManifestKnowledge(kind="config", key_pattern="module.config.*", description="Configs"),
            ManifestKnowledge(kind="state", key_pattern="module.state.*", description="States"),
        ]
        m = _make_manifest(knowledge=knowledge)
        found = get_manifest_knowledge_by_kind(m, "config")
        assert found is not None
        assert found.description == "Configs"
        assert get_manifest_knowledge_by_kind(m, "missing") is None


# ---------------------------------------------------------------------------
# HITL helpers
# ---------------------------------------------------------------------------


class TestHITL:
    def test_empty_hitl(self):
        m = _make_manifest()
        assert get_manifest_hitl_tools(m) == []

    def test_hitl_tools_from_dict(self):
        m = _make_manifest(hitl={
            "tools": [
                {"name": "approve", "title": "Approve", "description": "Approve action"},
                {"name": "reject", "title": "Reject", "description": "Reject action"},
            ],
        })
        tools = get_manifest_hitl_tools(m)
        assert len(tools) == 2
        assert tools[0].name == "approve"

    def test_hitl_tool_by_name(self):
        m = _make_manifest(hitl={
            "tools": [
                {"name": "approve", "title": "Approve", "description": "Approve action"},
            ],
        })
        tool = get_manifest_hitl_tool(m, "approve")
        assert tool is not None
        assert tool.title == "Approve"
        assert get_manifest_hitl_tool(m, "nonexistent") is None


# ---------------------------------------------------------------------------
# Health check helpers
# ---------------------------------------------------------------------------


class TestHealthChecks:
    def test_empty(self):
        m = _make_manifest()
        assert get_manifest_health_checks(m) == []

    def test_with_checks(self):
        m = _make_manifest(health={
            "checks": [
                {"id": "hc1", "label": "Check 1", "severity": "error"},
                {"id": "hc2", "label": "Check 2"},
            ],
        })
        checks = get_manifest_health_checks(m)
        assert len(checks) == 2
        assert checks[0].severity == "error"


# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------


class TestUI:
    def test_empty_ui(self):
        m = _make_manifest()
        assert get_manifest_ui_agent_modes(m) == []
        assert get_manifest_ui_input_modes(m) == []
        assert get_manifest_ui_sections(m) == []

    def test_with_ui(self):
        ui = ManifestUI(
            agent_modes=[ManifestUIAgentMode(id="auto", label="Auto", description="Auto mode")],
            input_modes=[ManifestUIInputMode(id="chat", icon="💬")],
            sections=[ManifestUISection(id="config", icon="⚙️")],
        )
        m = _make_manifest(ui=ui)
        assert len(get_manifest_ui_agent_modes(m)) == 1
        assert len(get_manifest_ui_input_modes(m)) == 1
        assert len(get_manifest_ui_sections(m)) == 1


# ---------------------------------------------------------------------------
# Ports helpers
# ---------------------------------------------------------------------------


class TestNetwork:
    def test_no_network(self):
        m = _make_manifest()
        assert get_manifest_network(m) is None

    def test_with_network(self):
        m = _make_manifest(network=ManifestNetwork(app=3000, mcp=3001))
        p = get_manifest_network(m)
        assert p is not None
        assert p.app == 3000


# ---------------------------------------------------------------------------
# Journey helpers
# ---------------------------------------------------------------------------


class TestJourney:
    def test_no_journey(self):
        m = _make_manifest()
        assert get_manifest_journey_stages(m) == []

    def test_with_journey(self):
        m = _make_manifest(journey=ManifestJourney(
            stages=[ManifestJourneyStage(id="intro"), ManifestJourneyStage(id="advanced")],
        ))
        stages = get_manifest_journey_stages(m)
        assert len(stages) == 2
        assert stages[0].id == "intro"


# ---------------------------------------------------------------------------
# Input context skills helpers
# ---------------------------------------------------------------------------


class TestInputContextSkills:
    def test_no_skills(self):
        m = _make_manifest()
        assert get_manifest_input_context_skills(m) == []

    def test_filter_by_trigger(self):
        skills = [
            ManifestSkill(id="s1", name="S1", description="d", instruction="i",
                          auto_invoke=ManifestSkillAutoInvoke(triggers=["input_context"])),
            ManifestSkill(id="s2", name="S2", description="d", instruction="i",
                          auto_invoke=ManifestSkillAutoInvoke(triggers=["other"])),
            ManifestSkill(id="s3", name="S3", description="d", instruction="i",
                          auto_invoke=ManifestSkillAutoInvoke(triggers=["input_context"]), stage="ideation"),
        ]
        m = _make_manifest(skills=skills)
        result = get_manifest_input_context_skills(m)
        assert len(result) == 2  # s1 and s3

    def test_filter_by_stage(self):
        skills = [
            ManifestSkill(id="s1", name="S1", description="d", instruction="i",
                          auto_invoke=ManifestSkillAutoInvoke(triggers=["input_context"])),
            ManifestSkill(id="s2", name="S2", description="d", instruction="i",
                          auto_invoke=ManifestSkillAutoInvoke(triggers=["input_context"]), stage="ideation"),
            ManifestSkill(id="s3", name="S3", description="d", instruction="i",
                          auto_invoke=ManifestSkillAutoInvoke(triggers=["input_context"]), stage="design"),
        ]
        m = _make_manifest(skills=skills)
        result = get_manifest_input_context_skills(m, stage="ideation")
        # s1 (no stage = global) + s2 (ideation match)
        assert len(result) == 2
        ids = {s.id for s in result}
        assert ids == {"s1", "s2"}
