"""Tests for cockpit_aap.kinds._shared.register — register_kind() and register_kinds()."""
from __future__ import annotations

import pytest

from cockpit_aap.manifest.kind_registry import KindRegistry, KindFieldSchema, create_kind_registry
from cockpit_aap.kinds._shared.register import register_kind, register_kinds


def _make_kind_def(kind: str = "TestKind", api_version: str = "test.io/v1") -> dict:
    """Create a minimal kind definition dict like define_kind() produces."""
    return {
        "kind": kind,
        "api_version": api_version,
        "description": f"A test {kind}",
        "fields": [
            {"path": "metadata.name", "type": "string", "required": True, "description": "Name"},
            {"path": "spec.value", "type": "number"},
        ],
        "scan": lambda d: {},
        "parse": lambda y: {},
        "sample": {"apiVersion": api_version, "kind": kind},
        "default_template": "<div>{{metadata.name}}</div>",
    }


class TestRegisterKind:
    def test_registers_new_kind(self):
        registry = create_kind_registry()
        kind_def = _make_kind_def("Alpha")
        register_kind(registry, kind_def)
        assert registry.is_registered("Alpha")

    def test_schema_has_correct_api_version(self):
        registry = create_kind_registry()
        kind_def = _make_kind_def("Beta", "custom.io/v2")
        register_kind(registry, kind_def)
        schema = registry.resolve_schema("Beta")
        assert schema.api_version == "custom.io/v2"

    def test_schema_has_correct_description(self):
        registry = create_kind_registry()
        kind_def = _make_kind_def("Gamma")
        register_kind(registry, kind_def)
        schema = registry.resolve_schema("Gamma")
        assert schema.description == "A test Gamma"

    def test_fields_are_registered_as_KindFieldSchema(self):
        registry = create_kind_registry()
        kind_def = _make_kind_def("Delta")
        register_kind(registry, kind_def)
        schema = registry.resolve_schema("Delta")
        assert len(schema.fields) == 2
        assert schema.fields[0].path == "metadata.name"
        assert schema.fields[0].type == "string"
        assert schema.fields[0].required is True
        assert schema.fields[0].description == "Name"
        assert schema.fields[1].path == "spec.value"
        assert schema.fields[1].type == "number"
        assert schema.fields[1].required is False

    def test_idempotent_skips_if_already_registered(self):
        registry = create_kind_registry()
        kind_def = _make_kind_def("Epsilon", "original/v1")
        register_kind(registry, kind_def)

        # Second call with different api_version should be skipped
        kind_def2 = _make_kind_def("Epsilon", "different/v1")
        register_kind(registry, kind_def2)

        schema = registry.resolve_schema("Epsilon")
        assert schema.api_version == "original/v1"

    def test_sample_is_passed_through(self):
        registry = create_kind_registry()
        kind_def = _make_kind_def("Zeta")
        register_kind(registry, kind_def)
        schema = registry.resolve_schema("Zeta")
        assert schema.sample is not None
        assert schema.sample["kind"] == "Zeta"

    def test_default_template_is_passed_through(self):
        registry = create_kind_registry()
        kind_def = _make_kind_def("Eta")
        register_kind(registry, kind_def)
        schema = registry.resolve_schema("Eta")
        assert schema.default_template == "<div>{{metadata.name}}</div>"

    def test_optional_field_attributes(self):
        registry = create_kind_registry()
        kind_def = {
            "kind": "Theta",
            "api_version": "test.io/v1",
            "description": "Test",
            "fields": [
                {
                    "path": "spec.format",
                    "type": "string",
                    "enum": ["json", "yaml"],
                    "content_type": "application/json",
                    "kind_ref": "Module",
                },
            ],
        }
        register_kind(registry, kind_def)
        schema = registry.resolve_schema("Theta")
        f = schema.fields[0]
        assert f.enum == ["json", "yaml"]
        assert f.content_type == "application/json"
        assert f.kind_ref == "Module"

    def test_fields_without_optional_keys(self):
        """Fields dict can omit optional keys — they default correctly."""
        registry = create_kind_registry()
        kind_def = {
            "kind": "Iota",
            "api_version": "test.io/v1",
            "description": "Test",
            "fields": [{"path": "metadata.name", "type": "string"}],
        }
        register_kind(registry, kind_def)
        schema = registry.resolve_schema("Iota")
        f = schema.fields[0]
        assert f.required is False
        assert f.description is None
        assert f.enum is None
        assert f.content_type is None
        assert f.kind_ref is None


class TestRegisterKinds:
    def test_registers_multiple_kinds(self):
        registry = create_kind_registry()
        defs = [_make_kind_def("A1"), _make_kind_def("A2"), _make_kind_def("A3")]
        register_kinds(registry, *defs)
        assert registry.is_registered("A1")
        assert registry.is_registered("A2")
        assert registry.is_registered("A3")

    def test_registers_zero_kinds(self):
        registry = create_kind_registry()
        # Should not raise
        register_kinds(registry)
        assert len(registry.registered_kinds()) == 0

    def test_idempotent_with_duplicates(self):
        registry = create_kind_registry()
        d = _make_kind_def("Dup")
        register_kinds(registry, d, d, d)
        assert registry.is_registered("Dup")
        assert len(registry.registered_kinds()) == 1
