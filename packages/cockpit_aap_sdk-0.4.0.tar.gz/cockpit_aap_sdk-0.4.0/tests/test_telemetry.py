"""Tests for cockpit_aap.telemetry — console, otel, attributes, provider."""

import asyncio
import io
import sys
from unittest.mock import MagicMock, patch

import pytest

from cockpit_aap.telemetry.attributes import AapAttributes
from cockpit_aap.telemetry.console_adapter import ConsoleObservabilityAdapter
from cockpit_aap.telemetry.provider import TelemetryConfig


# =========================================================================
# AapAttributes
# =========================================================================


class TestAapAttributes:
    def test_tool_namespace(self):
        assert AapAttributes.TOOL_NAMESPACE == "aap.tool.namespace"

    def test_tool_name(self):
        assert AapAttributes.TOOL_NAME == "aap.tool.name"

    def test_transport_type(self):
        assert AapAttributes.TRANSPORT_TYPE == "aap.transport.type"

    def test_mcp_session_id(self):
        assert AapAttributes.MCP_SESSION_ID == "aap.mcp.session_id"

    def test_module_id(self):
        assert AapAttributes.MODULE_ID == "aap.module.id"

    def test_module_version(self):
        assert AapAttributes.MODULE_VERSION == "aap.module.version"

    def test_artifact_key(self):
        assert AapAttributes.ARTIFACT_KEY == "aap.artifact.key"

    def test_drift_detected(self):
        assert AapAttributes.DRIFT_DETECTED == "aap.drift.detected"

    def test_bootstrap_source(self):
        assert AapAttributes.BOOTSTRAP_SOURCE == "aap.bootstrap.source"

    def test_all_attributes_are_strings(self):
        for attr in dir(AapAttributes):
            if not attr.startswith("_"):
                assert isinstance(getattr(AapAttributes, attr), str)


# =========================================================================
# ConsoleObservabilityAdapter
# =========================================================================


class TestConsoleObservabilityAdapter:
    def test_create_adapter(self):
        adapter = ConsoleObservabilityAdapter()
        assert adapter is not None

    def test_create_span(self):
        adapter = ConsoleObservabilityAdapter()
        span = adapter.start_span("test-op")
        assert span is not None

    def test_span_context_manager(self, capsys):
        adapter = ConsoleObservabilityAdapter()
        with adapter.start_span("my-operation") as span:
            span.set_attribute("key", "value")
            span.set_status("ok")
        captured = capsys.readouterr()
        assert "my-operation" in captured.out
        assert "key" in captured.out

    def test_span_record_exception(self, capsys):
        adapter = ConsoleObservabilityAdapter()
        with adapter.start_span("op") as span:
            span.record_exception(ValueError("test-error"))
        captured = capsys.readouterr()
        assert "test-error" in captured.out

    def test_record_metric_counter(self, capsys):
        adapter = ConsoleObservabilityAdapter()
        adapter.record_metric("my.counter", 1, metric_type="count", attributes={"env": "test"})
        captured = capsys.readouterr()
        assert "my.counter" in captured.out

    def test_record_metric_gauge(self, capsys):
        adapter = ConsoleObservabilityAdapter()
        adapter.record_metric("my.gauge", 42.5, metric_type="gauge", attributes={"region": "us"})
        captured = capsys.readouterr()
        assert "my.gauge" in captured.out
        assert "42.5" in captured.out

    def test_log_event(self, capsys):
        adapter = ConsoleObservabilityAdapter()
        adapter.log_event("my.event", {"detail": "something"})
        captured = capsys.readouterr()
        assert "my.event" in captured.out


# =========================================================================
# TelemetryConfig
# =========================================================================


class TestTelemetryConfig:
    def test_defaults(self):
        cfg = TelemetryConfig()
        assert cfg.service_name == "cockpit-aap"
        assert cfg.service_version is None
        assert cfg.otlp_endpoint is None
        assert cfg.enabled is True

    def test_custom(self):
        cfg = TelemetryConfig(
            service_name="my-svc",
            service_version="2.0.0",
            otlp_endpoint="http://localhost:4317",
            enabled=False,
        )
        assert cfg.service_name == "my-svc"
        assert cfg.enabled is False
