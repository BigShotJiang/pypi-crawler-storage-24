"""Tests for InMemoryCostTracker — covers record, query, timeseries, budget, and factory."""
from __future__ import annotations

import time

import pytest

from cockpit_aap.adapters.in_memory_cost_tracker import (
    InMemoryCostTracker,
    create_in_memory_cost_tracker,
)
from cockpit_aap.ports.cost_tracker import CostUsage, CostFilter, BudgetStatus


def _now_ms() -> float:
    return time.time() * 1000


def _usage(
    agent_id: str = "agent1",
    model: str = "gpt-4o",
    input_tokens: int = 100,
    output_tokens: int = 50,
    cost_usd: float | None = None,
    tenant_id: str | None = None,
) -> CostUsage:
    return CostUsage(
        agent_id=agent_id,
        model=model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cost_usd=cost_usd,
        timestamp=_now_ms(),
        tenant_id=tenant_id,
    )


class TestCreateFactory:
    def test_factory_returns_tracker(self):
        tracker = create_in_memory_cost_tracker()
        assert isinstance(tracker, InMemoryCostTracker)

    def test_factory_with_models_and_budget(self):
        tracker = create_in_memory_cost_tracker(
            models={"gpt-4o": {"input_per_1k": 0.01, "output_per_1k": 0.03}},
            budget={"daily": 50},
            currency="EUR",
        )
        assert tracker._currency == "EUR"
        assert "gpt-4o" in tracker._models


class TestRecord:
    @pytest.mark.asyncio
    async def test_record_stores_entry(self):
        tracker = InMemoryCostTracker()
        await tracker.record(_usage())
        assert len(tracker._entries) == 1

    @pytest.mark.asyncio
    async def test_record_calculates_cost_from_model_pricing(self):
        tracker = InMemoryCostTracker(
            models={"gpt-4o": {"input_per_1k": 0.01, "output_per_1k": 0.03}},
        )
        await tracker.record(_usage(model="gpt-4o", input_tokens=1000, output_tokens=1000))
        entry = tracker._entries[0]
        expected_cost = (1000 / 1000) * 0.01 + (1000 / 1000) * 0.03
        assert entry.cost_usd == pytest.approx(expected_cost)

    @pytest.mark.asyncio
    async def test_record_uses_explicit_cost_usd(self):
        tracker = InMemoryCostTracker(
            models={"gpt-4o": {"input_per_1k": 0.01, "output_per_1k": 0.03}},
        )
        await tracker.record(_usage(model="gpt-4o", cost_usd=0.99))
        assert tracker._entries[0].cost_usd == 0.99

    @pytest.mark.asyncio
    async def test_record_unknown_model_zero_cost(self):
        tracker = InMemoryCostTracker()
        await tracker.record(_usage(model="unknown-model"))
        assert tracker._entries[0].cost_usd == 0.0


class TestQuery:
    @pytest.mark.asyncio
    async def test_query_all(self):
        tracker = InMemoryCostTracker(
            models={"m": {"input_per_1k": 0.01, "output_per_1k": 0.03}},
        )
        await tracker.record(_usage(model="m"))
        await tracker.record(_usage(model="m"))
        result = await tracker.query(CostFilter())
        assert result.total_tokens == 300  # (100+50)*2
        assert len(result.entries) == 2

    @pytest.mark.asyncio
    async def test_query_filter_by_agent_id(self):
        tracker = InMemoryCostTracker()
        await tracker.record(_usage(agent_id="a1"))
        await tracker.record(_usage(agent_id="a2"))
        result = await tracker.query(CostFilter(agent_id="a1"))
        assert len(result.entries) == 1
        assert result.entries[0].agent_id == "a1"

    @pytest.mark.asyncio
    async def test_query_filter_by_model(self):
        tracker = InMemoryCostTracker()
        await tracker.record(_usage(model="gpt-4o"))
        await tracker.record(_usage(model="claude"))
        result = await tracker.query(CostFilter(model="claude"))
        assert len(result.entries) == 1

    @pytest.mark.asyncio
    async def test_query_filter_by_time_range(self):
        tracker = InMemoryCostTracker()
        now = _now_ms()
        old = CostUsage(agent_id="a", model="m", input_tokens=10, output_tokens=5, timestamp=now - 100_000)
        new = CostUsage(agent_id="a", model="m", input_tokens=10, output_tokens=5, timestamp=now)
        await tracker.record(old)
        await tracker.record(new)
        result = await tracker.query(CostFilter(since=now - 50_000))
        assert len(result.entries) == 1

    @pytest.mark.asyncio
    async def test_query_filter_by_until(self):
        tracker = InMemoryCostTracker()
        now = _now_ms()
        old = CostUsage(agent_id="a", model="m", input_tokens=10, output_tokens=5, timestamp=now - 100_000)
        new = CostUsage(agent_id="a", model="m", input_tokens=10, output_tokens=5, timestamp=now)
        await tracker.record(old)
        await tracker.record(new)
        result = await tracker.query(CostFilter(until=now - 50_000))
        assert len(result.entries) == 1

    @pytest.mark.asyncio
    async def test_query_total_cost_sum(self):
        tracker = InMemoryCostTracker()
        await tracker.record(_usage(cost_usd=1.5))
        await tracker.record(_usage(cost_usd=2.5))
        result = await tracker.query(CostFilter())
        assert result.total_cost == pytest.approx(4.0)


class TestQueryTimeseries:
    @pytest.mark.asyncio
    async def test_timeseries_hour_granularity(self):
        tracker = InMemoryCostTracker()
        now = _now_ms()
        await tracker.record(CostUsage(agent_id="a", model="m", input_tokens=10, output_tokens=5, cost_usd=1.0, timestamp=now))
        await tracker.record(CostUsage(agent_id="a", model="m", input_tokens=10, output_tokens=5, cost_usd=2.0, timestamp=now))
        ts = await tracker.query_timeseries(CostFilter(), granularity="hour")
        assert len(ts) >= 1
        total = sum(e.cost for e in ts)
        assert total == pytest.approx(3.0)

    @pytest.mark.asyncio
    async def test_timeseries_day_granularity(self):
        tracker = InMemoryCostTracker()
        now = _now_ms()
        await tracker.record(CostUsage(agent_id="a", model="m", input_tokens=10, output_tokens=5, cost_usd=1.0, timestamp=now))
        ts = await tracker.query_timeseries(CostFilter(), granularity="day")
        assert len(ts) == 1
        assert ts[0].requests == 1

    @pytest.mark.asyncio
    async def test_timeseries_empty(self):
        tracker = InMemoryCostTracker()
        ts = await tracker.query_timeseries(CostFilter())
        assert ts == []


class TestCheckBudget:
    @pytest.mark.asyncio
    async def test_within_daily_budget(self):
        tracker = InMemoryCostTracker(budget={"daily": 10.0})
        await tracker.record(_usage(cost_usd=1.0))
        status = await tracker.check_budget("agent1")
        assert status.within_budget is True
        assert status.spent == pytest.approx(1.0)
        assert status.limit == 10.0
        assert status.period == "daily"

    @pytest.mark.asyncio
    async def test_exceeds_daily_budget(self):
        tracker = InMemoryCostTracker(budget={"daily": 1.0})
        await tracker.record(_usage(cost_usd=5.0))
        status = await tracker.check_budget("agent1")
        assert status.within_budget is False
        assert status.spent == pytest.approx(5.0)

    @pytest.mark.asyncio
    async def test_monthly_budget_period(self):
        tracker = InMemoryCostTracker(budget={"monthly": 100.0})
        status = await tracker.check_budget("agent1")
        assert status.period == "monthly"
        assert status.limit == 100.0

    @pytest.mark.asyncio
    async def test_total_budget_period(self):
        tracker = InMemoryCostTracker(budget={"total": 500.0})
        status = await tracker.check_budget("agent1")
        assert status.period == "total"
        assert status.limit == 500.0

    @pytest.mark.asyncio
    async def test_no_budget_infinite_limit(self):
        tracker = InMemoryCostTracker()
        status = await tracker.check_budget("agent1")
        assert status.within_budget is True
        assert status.limit == float("inf")

    @pytest.mark.asyncio
    async def test_budget_filters_by_agent_id(self):
        tracker = InMemoryCostTracker(budget={"daily": 5.0})
        await tracker.record(_usage(agent_id="a1", cost_usd=3.0))
        await tracker.record(_usage(agent_id="a2", cost_usd=10.0))
        status = await tracker.check_budget("a1")
        assert status.spent == pytest.approx(3.0)
        assert status.within_budget is True

    @pytest.mark.asyncio
    async def test_budget_filters_by_tenant_id(self):
        tracker = InMemoryCostTracker(budget={"daily": 5.0})
        await tracker.record(_usage(agent_id="a1", tenant_id="t1", cost_usd=2.0))
        await tracker.record(_usage(agent_id="a1", tenant_id="t2", cost_usd=10.0))
        status = await tracker.check_budget("a1", tenant_id="t1")
        assert status.spent == pytest.approx(2.0)
        assert status.within_budget is True

    @pytest.mark.asyncio
    async def test_currency_propagated(self):
        tracker = InMemoryCostTracker(currency="EUR")
        status = await tracker.check_budget("agent1")
        assert status.currency == "EUR"
