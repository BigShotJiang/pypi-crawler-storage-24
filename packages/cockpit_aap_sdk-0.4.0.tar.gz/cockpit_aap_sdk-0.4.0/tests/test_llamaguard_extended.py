"""Extended tests for llamaguard_adapter.py — covers _parse_category_codes, _build_violations, and config."""
from __future__ import annotations

import pytest

from cockpit_aap.ports.guardrail import GuardrailContext
from cockpit_aap.runtime.llamaguard_adapter import (
    LlamaGuardAdapter,
    LlamaGuardConfig,
    SAFETY_CATEGORIES,
)


class TestParseCategoryCodes:
    """Test _parse_category_codes helper."""

    def _adapter(self, **kwargs) -> LlamaGuardAdapter:
        config = LlamaGuardConfig(base_url="", api_key="", **kwargs)
        return LlamaGuardAdapter(config)

    def test_single_code(self):
        adapter = self._adapter()
        codes = adapter._parse_category_codes("unsafe\nS1")
        assert codes == ["S1"]

    def test_multiple_codes(self):
        adapter = self._adapter()
        codes = adapter._parse_category_codes("unsafe\nS1,S7,S10")
        assert codes == ["S1", "S7", "S10"]

    def test_codes_with_spaces(self):
        adapter = self._adapter()
        codes = adapter._parse_category_codes("unsafe\n S1 , S7 ")
        assert codes == ["S1", "S7"]

    def test_no_second_line(self):
        adapter = self._adapter()
        codes = adapter._parse_category_codes("unsafe")
        assert codes == []

    def test_empty_second_line(self):
        adapter = self._adapter()
        codes = adapter._parse_category_codes("unsafe\n")
        assert codes == []

    def test_multiline_with_extra(self):
        adapter = self._adapter()
        codes = adapter._parse_category_codes("unsafe\nS3,S4\nsome other text")
        assert codes == ["S3", "S4"]


class TestBuildViolations:
    """Test _build_violations helper."""

    def _adapter(self, **kwargs) -> LlamaGuardAdapter:
        config = LlamaGuardConfig(base_url="", api_key="", **kwargs)
        return LlamaGuardAdapter(config)

    def test_single_block_violation(self):
        adapter = self._adapter()
        violations, has_block = adapter._build_violations(["S1"])
        assert has_block is True
        assert len(violations) == 1
        assert violations[0].rule_id == "llamaguard-s1"
        assert violations[0].severity == "block"
        assert "Violent Crimes" in violations[0].message
        assert violations[0].category == "content-safety"

    def test_multiple_violations(self):
        adapter = self._adapter()
        violations, has_block = adapter._build_violations(["S1", "S7", "S10"])
        assert has_block is True
        assert len(violations) == 3
        rule_ids = {v.rule_id for v in violations}
        assert rule_ids == {"llamaguard-s1", "llamaguard-s7", "llamaguard-s10"}

    def test_warn_category_no_block(self):
        adapter = self._adapter(warn_categories=["S6"])
        violations, has_block = adapter._build_violations(["S6"])
        assert has_block is False
        assert len(violations) == 1
        assert violations[0].severity == "warn"

    def test_mixed_warn_and_block(self):
        adapter = self._adapter(warn_categories=["S6"])
        violations, has_block = adapter._build_violations(["S1", "S6"])
        assert has_block is True
        assert len(violations) == 2
        severities = {v.severity for v in violations}
        assert "block" in severities
        assert "warn" in severities

    def test_empty_codes_creates_generic_violation(self):
        adapter = self._adapter()
        violations, has_block = adapter._build_violations([])
        assert has_block is True
        assert len(violations) == 1
        assert violations[0].rule_id == "llamaguard-unsafe"
        assert violations[0].severity == "block"

    def test_unknown_code_uses_fallback_label(self):
        adapter = self._adapter()
        violations, has_block = adapter._build_violations(["S99"])
        assert has_block is True
        assert "Unknown (S99)" in violations[0].message
        assert violations[0].rule_id == "llamaguard-s99"


class TestParseResponse:
    """Test _parse_response method covering all branches."""

    def _adapter(self, **kwargs) -> LlamaGuardAdapter:
        config = LlamaGuardConfig(base_url="", api_key="", **kwargs)
        return LlamaGuardAdapter(config)

    def test_safe_response(self):
        decision = self._adapter()._parse_response("safe")
        assert decision.allowed is True
        assert decision.action == "pass"
        assert len(decision.violations) == 0

    def test_safe_with_trailing_whitespace(self):
        decision = self._adapter()._parse_response("  safe  \n")
        assert decision.allowed is True
        assert decision.action == "pass"

    def test_safe_case_insensitive(self):
        decision = self._adapter()._parse_response("SAFE")
        assert decision.allowed is True

    def test_unsafe_with_categories(self):
        decision = self._adapter()._parse_response("unsafe\nS1,S3")
        assert decision.allowed is False
        assert decision.action == "block"
        assert len(decision.violations) == 2

    def test_unsafe_no_categories(self):
        decision = self._adapter()._parse_response("unsafe")
        assert decision.allowed is False
        assert decision.action == "block"
        # Falls through to generic "llamaguard-unsafe" violation
        assert decision.violations[0].rule_id == "llamaguard-unsafe"

    def test_empty_response(self):
        decision = self._adapter()._parse_response("")
        assert decision.allowed is True
        assert decision.action == "pass"

    def test_unexpected_response(self):
        decision = self._adapter()._parse_response("I cannot determine safety")
        assert decision.allowed is True
        assert decision.action == "pass"

    def test_unsafe_all_warn_categories(self):
        adapter = self._adapter(warn_categories=["S1", "S3"])
        decision = adapter._parse_response("unsafe\nS1,S3")
        assert decision.allowed is True
        assert decision.action == "warn"
        assert all(v.severity == "warn" for v in decision.violations)


class TestLlamaGuardConfig:
    """Test config defaults and env variable fallback."""

    def test_default_config(self):
        config = LlamaGuardConfig()
        assert config.model == "meta-llama/Llama-Guard-3-8B"
        assert config.timeout == 10.0
        assert set(config.block_categories) == set(SAFETY_CATEGORIES.keys())
        assert config.warn_categories == []

    def test_env_fallback(self, monkeypatch):
        monkeypatch.setenv("LLAMAGUARD_BASE_URL", "http://llama:8080")
        monkeypatch.setenv("LLAMAGUARD_API_KEY", "test-key-123")
        config = LlamaGuardConfig()
        assert config.base_url == "http://llama:8080"
        assert config.api_key == "test-key-123"

    def test_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("LLAMAGUARD_BASE_URL", "http://env")
        config = LlamaGuardConfig(base_url="http://explicit", api_key="explicit-key")
        assert config.base_url == "http://explicit"
        assert config.api_key == "explicit-key"


class TestLlamaGuardEvaluate:
    """Test evaluate_input / evaluate_output passthrough cases."""

    @pytest.mark.asyncio
    async def test_evaluate_output_no_endpoint(self):
        adapter = LlamaGuardAdapter(LlamaGuardConfig(base_url="", api_key=""))
        ctx = GuardrailContext(agent_id="test", input="hello world")
        decision = await adapter.evaluate_output(ctx)
        assert decision.allowed is True
        assert decision.action == "pass"

    @pytest.mark.asyncio
    async def test_close_no_client(self):
        adapter = LlamaGuardAdapter(LlamaGuardConfig(base_url="", api_key=""))
        await adapter.close()
        assert adapter._client is None
