import pytest
from cockpit_aap.runtime import create_agent_runtime, RegexGuardrailAdapter, RuntimeContext
from cockpit_aap.runtime.agno_hook import wrap_agno_agent


@pytest.mark.asyncio
async def test_wrap_agno_agent_passes_clean():
    manifest = type("M", (), {"spec": type("S", (), {"guardrails": type("G", (), {"input": [{"id": "pii"}], "output": []})(), "telemetry": None, "cost": None})()})()
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})

    async def fake_agent(input_text):
        return f"Echo: {input_text}"

    wrapped = wrap_agno_agent(fake_agent, runtime, agent_id="test", model="gpt")
    result = await wrapped("Hello world")
    assert result == "Echo: Hello world"


@pytest.mark.asyncio
async def test_wrap_agno_agent_blocks_pii():
    manifest = type("M", (), {"spec": type("S", (), {"guardrails": type("G", (), {"input": [{"id": "pii"}], "output": []})(), "telemetry": None, "cost": None})()})()
    runtime = create_agent_runtime(manifest, {"guardrail": RegexGuardrailAdapter()})

    async def fake_agent(input_text):
        return f"Echo: {input_text}"

    wrapped = wrap_agno_agent(fake_agent, runtime, agent_id="test", model="gpt")
    with pytest.raises(RuntimeError, match="Blocked"):
        await wrapped("My email is john@example.com")
