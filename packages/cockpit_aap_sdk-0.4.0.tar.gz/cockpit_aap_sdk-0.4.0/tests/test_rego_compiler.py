"""Tests for cockpit_aap.governance.rego_compiler — Python Rego compiler."""

import pytest

from cockpit_aap.governance.rego_compiler import (
    compile_all_policies,
    compile_conformance_policy,
    compile_manifest_policy,
    compile_policy_to_rego,
)


# ---------------------------------------------------------------------------
# ConformancePolicy
# ---------------------------------------------------------------------------


class TestCompileConformancePolicy:
    def test_generates_violation_for_required_field(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "test-policy"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-name",
                        "field": "metadata.name",
                        "severity": "required",
                        "weight": 6,
                        "message": "metadata.name is required",
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "package aap.conformance.test_policy" in rego
        assert "not input.manifest.metadata.name" in rego
        assert '"severity": "error"' in rego
        assert '"weight": 6' in rego

    def test_generates_condition_check(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "test-condition"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-agents",
                        "field": "spec.agents",
                        "severity": "recommended",
                        "weight": 2,
                        "condition": "length >= 1",
                        "message": "Should have agents",
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "count(" in rego

    def test_generates_array_path_pattern(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "test-pattern"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "agent-id",
                        "field": "spec.agents[].id",
                        "severity": "recommended",
                        "weight": 2,
                        "pattern": "^[a-z]+$",
                        "message": "bad pattern",
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "some item in input.manifest.spec.agents" in rego
        assert 'regex.match("^[a-z]+$"' in rego

    def test_generates_exempt_rules(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "test-exempt"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-theme",
                        "field": "spec.theme",
                        "severity": "recommended",
                        "weight": 2,
                        "message": "Theme recommended",
                        "exemptWhen": [
                            "metadata.group == 'demo'",
                            "metadata.group == 'showcase'",
                        ],
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "exempt_has_theme if" in rego
        assert '"demo"' in rego
        assert '"showcase"' in rego
        assert "not exempt_has_theme" in rego

    def test_forbidden_severity(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "test-forbidden"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "no-x",
                        "field": "spec.x",
                        "severity": "forbidden",
                        "weight": 4,
                        "message": "x is forbidden",
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "input.manifest.spec.x" in rego
        # forbidden = field exists = violation, so NO "not" prefix
        lines = [line.strip() for line in rego.split("\n")]
        assert any(
            "input.manifest.spec.x" in line and not line.startswith("not")
            for line in lines
        )

    def test_generates_package_and_import(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "my-conf"},
            "spec": {
                "appliesTo": {"kind": "Agent"},
                "requirements": [],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "package aap.conformance.my_conf" in rego
        assert "import rego.v1" in rego
        assert '# Applies to: Agent' in rego
        assert 'target_kind := "Agent"' in rego

    def test_default_weight_for_required(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "w"},
            "spec": {
                "requirements": [
                    {
                        "id": "r1",
                        "field": "metadata.name",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert '"weight": 4' in rego

    def test_default_weight_for_recommended(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "w"},
            "spec": {
                "requirements": [
                    {
                        "id": "r1",
                        "field": "metadata.name",
                        "severity": "recommended",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert '"weight": 2' in rego

    def test_skips_requirement_without_field(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "skip"},
            "spec": {
                "requirements": [
                    {"id": "nf", "severity": "required", "message": "no field"},
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "violation" not in rego

    def test_condition_inversion_operators(self):
        for op, expected in [(">=", "<"), (">", "<="), ("<=", ">"), ("<", ">="), ("==", "!=")]:
            policy = {
                "kind": "ConformancePolicy",
                "metadata": {"name": f"op-{op.replace('=', 'eq').replace('<', 'lt').replace('>', 'gt')}"},
                "spec": {
                    "requirements": [
                        {
                            "id": "r",
                            "field": "spec.items",
                            "severity": "required",
                            "condition": f"length {op} 2",
                            "message": "m",
                        },
                    ],
                },
            }
            rego = compile_conformance_policy(policy)
            assert f"count(items) {expected} 2" in rego

    def test_pattern_on_non_array_field(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "pat"},
            "spec": {
                "requirements": [
                    {
                        "id": "ver",
                        "field": "metadata.version",
                        "severity": "required",
                        "pattern": r"^\d+\.\d+\.\d+$",
                        "message": "semver",
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "val := input.manifest.metadata.version" in rego
        assert r'regex.match("^\d+\.\d+\.\d+$", val)' in rego

    def test_array_path_without_pattern(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "arr"},
            "spec": {
                "requirements": [
                    {
                        "id": "aid",
                        "field": "spec.agents[].id",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "some item in input.manifest.spec.agents" in rego
        assert "not item.id" in rego

    def test_exempt_neq_pattern(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "neq"},
            "spec": {
                "requirements": [
                    {
                        "id": "r1",
                        "field": "spec.x",
                        "severity": "required",
                        "message": "m",
                        "exemptWhen": ["metadata.group != 'core'"],
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert 'input.manifest.metadata.group != "core"' in rego

    def test_exempt_undefined_pattern(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "undef"},
            "spec": {
                "requirements": [
                    {
                        "id": "r1",
                        "field": "spec.x",
                        "severity": "required",
                        "message": "m",
                        "exemptWhen": ["metadata.group == undefined"],
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert "not input.manifest.metadata.group" in rego

    def test_message_escapes_double_quotes(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "esc"},
            "spec": {
                "requirements": [
                    {
                        "id": "r1",
                        "field": "spec.x",
                        "severity": "required",
                        "message": 'must have "x" field',
                    },
                ],
            },
        }
        rego = compile_conformance_policy(policy)
        assert r'must have \"x\" field' in rego


# ---------------------------------------------------------------------------
# ManifestPolicy
# ---------------------------------------------------------------------------


class TestCompileManifestPolicy:
    def test_must_have_ref(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "prod-policy"},
            "spec": {
                "appliesTo": {"kind": "Module", "when": "metadata.group == 'product'"},
                "requirements": [
                    {
                        "id": "has-tel-ref",
                        "type": "mustHaveRef",
                        "targetKind": "TelemetryBlueprint",
                        "severity": "required",
                        "message": "Must ref TelemetryBlueprint",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "package aap.policy.prod_policy" in rego
        assert "default applies := false" in rego
        assert '"product"' in rego
        assert "final_violations" in rego

    def test_must_have_annotation(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "ann-policy"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-tier",
                        "type": "mustHaveAnnotation",
                        "annotationKey": "tier",
                        "allowedAnnotationValues": ["standard", "premium"],
                        "severity": "required",
                        "message": "Must have tier",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "annotations" in rego
        assert '"standard"' in rego
        assert '"premium"' in rego

    def test_field_expression(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "expr-policy"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "cost-budget",
                        "type": "fieldExpression",
                        "expression": "spec.cost.budget.daily > 0",
                        "severity": "recommended",
                        "message": "Should set budget",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "input.manifest.spec.cost.budget.daily" in rego

    def test_forbid_annotation(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "forbid-policy"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "no-deprecated",
                        "type": "forbidAnnotation",
                        "annotationKey": "deprecated",
                        "severity": "required",
                        "message": "deprecated forbidden",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert 'annotations["deprecated"]' in rego

    def test_must_have_agent(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "agent-policy"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "min-agents",
                        "type": "mustHaveAgent",
                        "minAgentCount": 2,
                        "severity": "required",
                        "message": "Need 2 agents",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "count(agents) < 2" in rego

    def test_forbid_ref(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "forbid-ref"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "no-legacy",
                        "type": "forbidRef",
                        "targetKind": "LegacyTool",
                        "severity": "required",
                        "message": "No legacy tools",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert '"LegacyTool"' in rego
        assert "> 0" in rego

    def test_must_have_artifact_with_pattern(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "artifact-policy"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-config",
                        "type": "mustHaveArtifact",
                        "artifactPattern": "*.config.*",
                        "severity": "required",
                        "message": "Need config artifact",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert 'glob.match("*.config.*"' in rego

    def test_must_have_artifact_without_pattern(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "any-artifact"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-any",
                        "type": "mustHaveArtifact",
                        "severity": "required",
                        "message": "Need any artifact",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "count(artifacts) == 0" in rego

    def test_agent_has_tool(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "tool-policy"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-tools",
                        "type": "agentHasTool",
                        "severity": "required",
                        "message": "Agents must have tools",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "some agent in agents" in rego
        assert "count(tools) == 0" in rego

    def test_when_or_conditions(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "or-policy"},
            "spec": {
                "appliesTo": {
                    "kind": "Module",
                    "when": "metadata.group == 'product' || metadata.group == 'core'",
                },
                "requirements": [
                    {
                        "id": "r1",
                        "type": "mustHaveRef",
                        "targetKind": "X",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert '"product"' in rego
        assert '"core"' in rego
        assert rego.count("applies if {") == 2

    def test_no_when_uses_final_violations_direct(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "direct"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "r1",
                        "type": "mustHaveRef",
                        "targetKind": "X",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "final_violations := violation" in rego
        assert "default applies" not in rego

    def test_unsupported_requirement_type(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "unsup"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "r1",
                        "type": "unknownType",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "# Unsupported requirement type: unknownType" in rego

    def test_must_have_annotation_without_allowed_values(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "ann-simple"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-owner",
                        "type": "mustHaveAnnotation",
                        "annotationKey": "owner",
                        "severity": "required",
                        "message": "Must have owner",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert 'object.get(annotations, "owner", "")' in rego

    def test_field_expression_null_and_length(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "fe"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "r1",
                        "type": "fieldExpression",
                        "expression": "spec.agents != null && spec.agents.length > 0",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "val := input.manifest.spec.agents" in rego
        assert "count(val) <= 0" in rego

    def test_field_expression_simple_null_check(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "fe2"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "r1",
                        "type": "fieldExpression",
                        "expression": "spec.theme != null",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "not input.manifest.spec.theme" in rego

    def test_field_expression_complex_js(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "fe3"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "r1",
                        "type": "fieldExpression",
                        "expression": "spec.agents.every(a => a.id)",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "# Complex JS expression" in rego
        assert "false  # TODO" in rego

    def test_manifest_requirement_exempt_when(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "exempt-manifest"},
            "spec": {
                "appliesTo": {"kind": "Module"},
                "requirements": [
                    {
                        "id": "has-ref",
                        "type": "mustHaveRef",
                        "targetKind": "X",
                        "severity": "required",
                        "message": "m",
                        "exemptWhen": ["metadata.group == 'demo'"],
                    },
                ],
            },
        }
        rego = compile_manifest_policy(policy)
        assert "exempt_has_ref if" in rego
        assert '"demo"' in rego


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------


class TestCompilePolicyToRego:
    def test_routes_conformance(self):
        policy = {
            "kind": "ConformancePolicy",
            "metadata": {"name": "test"},
            "spec": {
                "requirements": [
                    {
                        "id": "r1",
                        "field": "metadata.name",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_policy_to_rego(policy)
        assert "aap.conformance" in rego

    def test_routes_manifest(self):
        policy = {
            "kind": "ManifestPolicy",
            "metadata": {"name": "test"},
            "spec": {
                "requirements": [
                    {
                        "id": "r1",
                        "type": "mustHaveRef",
                        "targetKind": "X",
                        "severity": "required",
                        "message": "m",
                    },
                ],
            },
        }
        rego = compile_policy_to_rego(policy)
        assert "aap.policy" in rego

    def test_raises_on_unsupported(self):
        with pytest.raises(ValueError):
            compile_policy_to_rego(
                {
                    "kind": "CostPolicy",
                    "metadata": {"name": "x"},
                    "spec": {"requirements": []},
                }
            )


# ---------------------------------------------------------------------------
# Batch
# ---------------------------------------------------------------------------


class TestCompileAllPolicies:
    def test_skips_unsupported_kinds(self):
        policies = [
            {
                "kind": "ConformancePolicy",
                "metadata": {"name": "c1"},
                "spec": {
                    "requirements": [
                        {
                            "id": "r1",
                            "field": "metadata.name",
                            "severity": "required",
                            "message": "m",
                        },
                    ],
                },
            },
            {
                "kind": "CostPolicy",
                "metadata": {"name": "cost"},
                "spec": {"requirements": []},
            },
        ]
        result = compile_all_policies(policies)
        assert len(result) == 1
        assert result[0]["kind"] == "ConformancePolicy"

    def test_compiles_both_kinds(self):
        policies = [
            {
                "kind": "ConformancePolicy",
                "metadata": {"name": "c1"},
                "spec": {
                    "requirements": [
                        {
                            "id": "r1",
                            "field": "metadata.name",
                            "severity": "required",
                            "message": "m",
                        },
                    ],
                },
            },
            {
                "kind": "ManifestPolicy",
                "metadata": {"name": "m1"},
                "spec": {
                    "requirements": [
                        {
                            "id": "r1",
                            "type": "mustHaveRef",
                            "targetKind": "X",
                            "severity": "required",
                            "message": "m",
                        },
                    ],
                },
            },
        ]
        result = compile_all_policies(policies)
        assert len(result) == 2
        assert result[0]["id"] == "c1"
        assert result[1]["id"] == "m1"

    def test_empty_input(self):
        assert compile_all_policies([]) == []
