"""Extended tests for cockpit_aap.cost.enforcer — covers edge cases, scope keys, and Prometheus sync."""
from __future__ import annotations

import time
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from cockpit_aap.cost.enforcer import CostEnforcer, EnforcementResult
from cockpit_aap.cost.policy import CostPolicyReader


SPEC = {
    "models": {"gpt-4o": {"inputPer1k": 0.005, "outputPer1k": 0.015}},
    "budgets": [
        {"scope": "module", "daily": 10.0, "onExceeded": "block", "warnAt": 0.8},
        {"scope": "agent", "agentId": "dev-agent", "daily": 5.0, "onExceeded": "warn", "warnAt": 0.9},
    ],
    "enforcement": {"preCall": True, "cacheSeconds": 30, "accumulatorSyncInterval": 60},
    "prometheus": {"endpoint": "http://prometheus:9090"},
}

SPEC_NO_BUDGET = {"budgets": []}


class TestScopeKey:
    def test_module_scope(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        key = enforcer._scope_key("module")
        assert key == "module"

    def test_scope_with_kwargs(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        key = enforcer._scope_key("agent", agent_id="dev", tenant_id="t1")
        assert "agent" in key
        assert "agent_id=dev" in key
        assert "tenant_id=t1" in key

    def test_scope_empty_kwargs_excluded(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        key = enforcer._scope_key("agent", agent_id="dev", tenant_id="")
        assert "tenant_id" not in key

    def test_scope_sorted_keys(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        key = enforcer._scope_key("agent", z_key="z", a_key="a")
        # Keys should be sorted alphabetically
        parts = key.split("|")
        assert parts[1].startswith("a_key=")
        assert parts[2].startswith("z_key=")


class TestRecordSpend:
    def test_accumulates_across_calls(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer.record_spend(3.0, {"scope": "module"})
        enforcer.record_spend(2.0, {"scope": "module"})
        enforcer.record_spend(1.0, {"scope": "module"})
        result = enforcer.check_budget("module")
        assert result.spent == 6.0

    def test_separate_scopes_independent(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer.record_spend(5.0, {"scope": "module"})
        enforcer.record_spend(2.0, {"scope": "agent", "agent_id": "dev-agent"})

        module_result = enforcer.check_budget("module")
        assert module_result.spent == 5.0

    def test_default_scope_is_module(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer.record_spend(1.0, {})  # No scope key -> defaults to "module"
        result = enforcer.check_budget("module")
        assert result.spent == 1.0


class TestCheckBudget:
    def test_no_budget_returns_allow(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC_NO_BUDGET))
        result = enforcer.check_budget("module")
        assert result.action == "allow"
        assert result.message == "No budget defined"

    def test_zero_limit_returns_allow(self):
        spec = {"budgets": [{"scope": "module", "daily": 0}]}
        enforcer = CostEnforcer(policy=CostPolicyReader(spec))
        result = enforcer.check_budget("module")
        assert result.action == "allow"
        assert result.message == "No daily limit"

    def test_under_limit_allows(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer.record_spend(5.0, {"scope": "module"})
        result = enforcer.check_budget("module")
        assert result.action == "allow"
        assert result.spent == 5.0
        assert result.limit == 10.0

    def test_at_warn_threshold(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer.record_spend(8.0, {"scope": "module"})  # 80% of 10 = warnAt
        result = enforcer.check_budget("module")
        assert result.action == "warn"
        assert "warn" in result.message.lower() or "$" in result.message

    def test_above_limit_blocks(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer.record_spend(10.5, {"scope": "module"})
        result = enforcer.check_budget("module")
        assert result.action == "block"

    def test_on_exceeded_warn_instead_of_block(self):
        spec = {
            "budgets": [{"scope": "module", "daily": 10.0, "onExceeded": "warn", "warnAt": 0.8}],
        }
        enforcer = CostEnforcer(policy=CostPolicyReader(spec))
        enforcer.record_spend(11.0, {"scope": "module"})
        result = enforcer.check_budget("module")
        assert result.action == "warn"

    def test_on_exceeded_invalid_defaults_to_warn(self):
        spec = {
            "budgets": [{"scope": "module", "daily": 10.0, "onExceeded": "invalid-action", "warnAt": 0.8}],
        }
        enforcer = CostEnforcer(policy=CostPolicyReader(spec))
        enforcer.record_spend(11.0, {"scope": "module"})
        result = enforcer.check_budget("module")
        assert result.action == "warn"

    def test_agent_scope_budget(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer.record_spend(4.5, {"scope": "agent", "agent_id": "dev-agent"})
        result = enforcer.check_budget("agent", agent_id="dev-agent")
        assert result.action == "warn"  # 4.5 >= 5.0 * 0.9 = 4.5

    def test_agent_scope_no_matching_budget(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        result = enforcer.check_budget("agent", agent_id="unknown-agent")
        assert result.action == "allow"
        assert result.message == "No budget defined"

    def test_locale_in_message(self):
        spec = {
            "budgets": [{"scope": "module", "daily": 10.0, "onExceeded": "block", "warnAt": 0.8}],
            "messages": {
                "block": {"en": "Budget exceeded: ${spent} of ${limit}"},
                "warn": {"en": "Warning: ${spent} of ${limit} ({percent}%)"},
            },
        }
        enforcer = CostEnforcer(policy=CostPolicyReader(spec))
        enforcer.record_spend(11.0, {"scope": "module"})
        result = enforcer.check_budget("module", locale="en")
        assert "$11.00" in result.message
        assert "$10.00" in result.message


class TestPrometheusSyncSkip:
    @pytest.mark.asyncio
    async def test_sync_skipped_within_interval(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer._last_sync = time.time()  # Just synced

        await enforcer.sync_from_prometheus()
        # Should return immediately without making any HTTP call

    @pytest.mark.asyncio
    async def test_sync_failure_keeps_accumulators(self):
        enforcer = CostEnforcer(policy=CostPolicyReader(SPEC))
        enforcer._last_sync = 0  # Force sync attempt
        enforcer._accumulators["module"] = 5.0

        # httpx.AsyncClient will fail because endpoint is unreachable
        await enforcer.sync_from_prometheus()

        # Accumulators should be preserved on failure
        assert enforcer._accumulators["module"] == 5.0


class TestEnforcementResult:
    def test_dataclass_fields(self):
        result = EnforcementResult(action="allow", spent=5.0, limit=10.0, message="ok")
        assert result.action == "allow"
        assert result.spent == 5.0
        assert result.limit == 10.0
        assert result.message == "ok"

    def test_default_message(self):
        result = EnforcementResult(action="allow", spent=0, limit=0)
        assert result.message == ""
