"""Tests for structured JSON logger."""
import json
import os
from io import StringIO
from unittest.mock import patch

import pytest


def test_emit_log_outputs_json_to_stdout():
    from cockpit_aap.logging.structured import emit_log

    with patch("sys.stdout", new_callable=StringIO) as mock_out:
        emit_log("info", "test message", service="agent", module="test-mod")
    line = mock_out.getvalue().strip()
    parsed = json.loads(line)
    assert parsed["level"] == "info"
    assert parsed["message"] == "test message"
    assert parsed["service"] == "agent"
    assert parsed["module"] == "test-mod"
    assert "ts" in parsed


def test_emit_log_omits_empty_fields():
    from cockpit_aap.logging.structured import emit_log

    with patch("sys.stdout", new_callable=StringIO) as mock_out:
        emit_log("info", "hello", service="agent", module="m")
    parsed = json.loads(mock_out.getvalue().strip())
    assert "traceId" not in parsed
    assert "costUsd" not in parsed
    assert "error" not in parsed
    assert "tokenCount" not in parsed


def test_emit_log_includes_nonzero_fields():
    from cockpit_aap.logging.structured import emit_log

    with patch("sys.stdout", new_callable=StringIO) as mock_out:
        emit_log(
            "info", "llm_complete",
            service="agent", module="m",
            tenant_id="t1", agent_id="a1", kind="Module",
            model="gpt-4o", token_count=500, cost_usd=0.005,
            duration_ms=1200,
        )
    parsed = json.loads(mock_out.getvalue().strip())
    assert parsed["tenantId"] == "t1"
    assert parsed["agentId"] == "a1"
    assert parsed["kind"] == "Module"
    assert parsed["model"] == "gpt-4o"
    assert parsed["tokenCount"] == 500
    assert parsed["costUsd"] == 0.005
    assert parsed["durationMs"] == 1200


def test_emit_log_text_mode_fallback():
    from cockpit_aap.logging.structured import emit_log

    with patch.dict(os.environ, {"AAP_LOG_FORMAT": "text"}):
        with patch("sys.stdout", new_callable=StringIO) as mock_out:
            emit_log("info", "hello", service="agent", module="m")
        line = mock_out.getvalue().strip()
        with pytest.raises(json.JSONDecodeError):
            json.loads(line)
        assert "hello" in line


def test_emit_log_extra_fields():
    from cockpit_aap.logging.structured import emit_log

    with patch("sys.stdout", new_callable=StringIO) as mock_out:
        emit_log("info", "custom", service="agent", module="m", custom_field="val")
    parsed = json.loads(mock_out.getvalue().strip())
    assert parsed["custom_field"] == "val"


def test_emit_log_auto_extracts_otel_context():
    """When OTEL is available and a span is active, traceId/spanId are auto-extracted."""
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
    except ImportError:
        pytest.skip("opentelemetry not installed")

    provider = TracerProvider()
    trace.set_tracer_provider(provider)
    tracer = trace.get_tracer("test")

    from cockpit_aap.logging.structured import emit_log

    with tracer.start_as_current_span("test-span"):
        with patch("sys.stdout", new_callable=StringIO) as mock_out:
            emit_log("info", "within span", service="agent", module="m")
        parsed = json.loads(mock_out.getvalue().strip())
        assert "traceId" in parsed
        assert len(parsed["traceId"]) == 32
        assert "spanId" in parsed
        assert len(parsed["spanId"]) == 16
