"""Tests for cockpit_aap.pull — pull_manifest, read_manifest_artifact, scaffold_from_server."""

import os
import tempfile
import pytest
import pytest_asyncio

from cockpit_aap.pull import pull_manifest, read_manifest_artifact, scaffold_from_server

# ---------------------------------------------------------------------------
# Mock SDK
# ---------------------------------------------------------------------------

SAMPLE_MANIFEST_YAML = """\
apiVersion: cockpit.io/v1
kind: Module
metadata:
  name: pulled-mod
  displayName: Pulled Module
  version: "2.0.0"
spec:
  agents:
    - id: dev
      name: Dev Agent
      instruction: Help with development
  artifacts:
    - key: config.theme
      defaultValue: dark
      description: Theme setting
"""


class MockSDK:
    """Mock SDK that returns a manifest artifact."""

    def __init__(self, yaml_content: str | None = None):
        self._yaml = yaml_content

    async def call_tool(self, namespace: str, tool: str, args: dict):
        if tool == "get_artifact" and self._yaml:
            return {
                "content": {
                    "artifacts": [{"value": self._yaml, "id": "uuid-1"}]
                }
            }
        return {"content": None, "isError": True}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_read_manifest_artifact_found():
    sdk = MockSDK(SAMPLE_MANIFEST_YAML)
    result = await read_manifest_artifact(sdk, "artifacts", "mod._meta.manifest")
    assert result is not None
    assert "pulled-mod" in result


@pytest.mark.asyncio
async def test_read_manifest_artifact_not_found():
    sdk = MockSDK(None)
    result = await read_manifest_artifact(sdk, "artifacts", "missing._meta.manifest")
    assert result is None


@pytest.mark.asyncio
async def test_pull_manifest():
    sdk = MockSDK(SAMPLE_MANIFEST_YAML)
    with tempfile.TemporaryDirectory() as tmpdir:
        result = await pull_manifest(sdk, "pulled-mod", tmpdir)
        assert result.version == "2.0.0"
        assert result.manifest.metadata.name == "pulled-mod"
        assert len(result.files_written) > 0
        # Verify manifest.yaml was written
        assert os.path.isfile(os.path.join(tmpdir, "manifest.yaml"))


@pytest.mark.asyncio
async def test_pull_manifest_not_found():
    sdk = MockSDK(None)
    with tempfile.TemporaryDirectory() as tmpdir:
        with pytest.raises(RuntimeError, match="Manifest not found"):
            await pull_manifest(sdk, "missing-mod", tmpdir)


@pytest.mark.asyncio
async def test_scaffold_from_server():
    sdk = MockSDK(SAMPLE_MANIFEST_YAML)
    with tempfile.TemporaryDirectory() as tmpdir:
        result = await scaffold_from_server(sdk, "pulled-mod", tmpdir)
        assert result.version == "2.0.0"
        # Check generated Python files
        init_path = os.path.join(tmpdir, "init.py")
        def_path = os.path.join(tmpdir, "definition.py")
        assert os.path.isfile(init_path)
        assert os.path.isfile(def_path)

        with open(def_path) as f:
            content = f.read()
        assert 'MODULE_ID = "pulled-mod"' in content
        assert 'MODULE_VERSION = "2.0.0"' in content


@pytest.mark.asyncio
async def test_scaffold_skip_generation():
    sdk = MockSDK(SAMPLE_MANIFEST_YAML)
    with tempfile.TemporaryDirectory() as tmpdir:
        result = await scaffold_from_server(
            sdk, "pulled-mod", tmpdir, generate_init=False, generate_definition=False
        )
        assert not os.path.isfile(os.path.join(tmpdir, "init.py"))
        assert not os.path.isfile(os.path.join(tmpdir, "definition.py"))
