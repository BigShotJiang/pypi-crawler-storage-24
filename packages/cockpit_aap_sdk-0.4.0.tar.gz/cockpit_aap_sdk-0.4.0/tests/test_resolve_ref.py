"""Tests for resolve_ref module — public file-reference resolution."""

from __future__ import annotations

import json
import os
import tempfile

import pytest

from cockpit_aap.manifest.resolve_ref import is_file_ref, resolve_ref, resolve_json_ref


# ── is_file_ref ────────────────────────────────────────────────────────────────


class TestIsFileRef:
    """Tests for is_file_ref — detects file-reference strings."""

    def test_markdown_file(self):
        assert is_file_ref("agents/risk-analyst.md") is True

    def test_yaml_file(self):
        assert is_file_ref("config/settings.yaml") is True

    def test_yml_file(self):
        assert is_file_ref("config/settings.yml") is True

    def test_json_file(self):
        assert is_file_ref("data/schema.json") is True

    def test_txt_file(self):
        assert is_file_ref("docs/readme.txt") is True

    def test_xml_file(self):
        assert is_file_ref("config/app.xml") is True

    def test_html_file(self):
        assert is_file_ref("templates/card.html") is True

    def test_plain_string(self):
        assert is_file_ref("You are a helpful assistant.") is False

    def test_multiline_string(self):
        assert is_file_ref("line1\nline2.md") is False

    def test_empty_string(self):
        assert is_file_ref("") is False

    def test_no_slash(self):
        """A bare filename without a slash is still a valid file ref."""
        assert is_file_ref("README.md") is True

    def test_unknown_extension(self):
        assert is_file_ref("file.py") is False

    def test_long_string(self):
        """Strings > 260 chars are not file refs."""
        assert is_file_ref("a" * 260 + "/file.md") is False

    def test_url_is_not_file_ref(self):
        """URLs with known extensions should still match if no newlines."""
        # This is debatable; the TS implementation treats paths with / and known ext as refs
        assert is_file_ref("https://example.com/file.md") is True

    def test_path_with_spaces(self):
        assert is_file_ref("agents/my agent.md") is True


# ── resolve_ref ────────────────────────────────────────────────────────────────


class TestResolveRef:
    """Tests for resolve_ref — resolves file references, leaves non-refs untouched."""

    def test_non_file_ref_passthrough(self):
        """Non-file-ref strings are returned as-is."""
        result = resolve_ref("You are a helpful assistant.", "/tmp")
        assert result == "You are a helpful assistant."

    def test_resolve_existing_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            agent_dir = os.path.join(tmpdir, "agents")
            os.makedirs(agent_dir)
            filepath = os.path.join(agent_dir, "analyst.md")
            with open(filepath, "w") as f:
                f.write("# Analyst Instructions\nDo analysis.")

            result = resolve_ref("agents/analyst.md", tmpdir)
            assert result == "# Analyst Instructions\nDo analysis."

    def test_missing_file_returns_original(self):
        """If the file doesn't exist, return the original string."""
        result = resolve_ref("agents/nonexistent.md", "/tmp")
        assert result == "agents/nonexistent.md"

    def test_path_traversal_protection(self):
        """Paths that escape the base directory raise ValueError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with pytest.raises(ValueError, match="Path traversal detected"):
                resolve_ref("../../etc/passwd.txt", tmpdir)

    def test_preserves_file_content(self):
        """resolve_ref reads file content as-is (no stripping)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = os.path.join(tmpdir, "note.md")
            with open(filepath, "w") as f:
                f.write("content\n")

            result = resolve_ref("note.md", tmpdir)
            assert result == "content\n"


# ── resolve_json_ref ───────────────────────────────────────────────────────────


class TestResolveJsonRef:
    """Tests for resolve_json_ref — resolves file refs, parses as JSON."""

    def test_json_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = os.path.join(tmpdir, "data.json")
            data = {"key": "value", "number": 42}
            with open(filepath, "w") as f:
                json.dump(data, f)

            result = resolve_json_ref("data.json", tmpdir)
            # Should be re-serialized as compact JSON
            parsed = json.loads(result)
            assert parsed == data

    def test_non_file_ref_passthrough(self):
        result = resolve_json_ref("just a string", "/tmp")
        assert result == "just a string"

    def test_non_json_file_returns_raw(self):
        """If the file isn't valid JSON, return the raw content."""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = os.path.join(tmpdir, "bad.json")
            with open(filepath, "w") as f:
                f.write("not valid json")

            result = resolve_json_ref("bad.json", tmpdir)
            assert result == "not valid json"

    def test_yaml_file_passthrough(self):
        """YAML files are resolved by resolve_ref, not parsed as JSON."""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = os.path.join(tmpdir, "config.yaml")
            with open(filepath, "w") as f:
                f.write("key: value")

            result = resolve_json_ref("config.yaml", tmpdir)
            assert result == "key: value"
