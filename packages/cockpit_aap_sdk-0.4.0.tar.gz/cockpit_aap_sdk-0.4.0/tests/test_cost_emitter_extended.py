"""Extended tests for cockpit_aap.cost.emitter — covers OTEL-unavailable path and emit_budget_event."""
from __future__ import annotations

from unittest.mock import patch, MagicMock

from cockpit_aap.cost.emitter import CostEmitter
from cockpit_aap.cost.policy import CostPolicyReader


SPEC = {
    "models": {"gpt-4o": {"inputPer1k": 0.005, "outputPer1k": 0.015}},
    "budgets": [],
}

SPEC_WITH_BUDGET = {
    "models": {"gpt-4o": {"inputPer1k": 0.005, "outputPer1k": 0.015}},
    "budgets": [{"scope": "module", "daily": 10.0, "onExceeded": "block"}],
}


class TestCostEmitterLabels:
    def test_labels_structure(self):
        emitter = CostEmitter(
            policy=CostPolicyReader(SPEC),
            module_id="my-mod",
            agent_id="my-agent",
            tenant_id="tenant-1",
        )
        labels = emitter._labels("gpt-4o")
        assert labels == {
            "aap.tenant.id": "tenant-1",
            "aap.agent.id": "my-agent",
            "aap.module.id": "my-mod",
            "gen_ai.request.model": "gpt-4o",
        }


class TestCostEmitterEmit:
    def test_emit_returns_correct_cost(self):
        emitter = CostEmitter(
            policy=CostPolicyReader(SPEC),
            module_id="mod", agent_id="agent", tenant_id="t",
        )
        # 1000 input * 0.005/1k + 500 output * 0.015/1k = 0.005 + 0.0075 = 0.0125
        cost = emitter.emit("gpt-4o", input_tokens=1000, output_tokens=500)
        assert abs(cost - 0.0125) < 0.0001

    def test_emit_zero_tokens(self):
        emitter = CostEmitter(
            policy=CostPolicyReader(SPEC),
            module_id="mod", agent_id="agent", tenant_id="t",
        )
        cost = emitter.emit("gpt-4o", input_tokens=0, output_tokens=0)
        assert cost == 0.0

    def test_emit_with_otel_counters(self):
        """When OTEL is available, counters are incremented."""
        emitter = CostEmitter(
            policy=CostPolicyReader(SPEC),
            module_id="mod", agent_id="agent", tenant_id="t",
        )
        # If OTEL is available, counters exist; if not, they are None
        if emitter._cost_counter is not None:
            cost = emitter.emit("gpt-4o", input_tokens=1000, output_tokens=500)
            assert cost > 0  # Just verify no crash


class TestCostEmitterBudgetEvent:
    def test_emit_budget_event_no_crash(self):
        """emit_budget_event should work when OTEL counters exist."""
        emitter = CostEmitter(
            policy=CostPolicyReader(SPEC_WITH_BUDGET),
            module_id="mod", agent_id="agent", tenant_id="t",
        )
        if emitter._budget_exceeded_counter is not None:
            # Should not raise
            emitter.emit_budget_event("block", spent=11.0, limit=10.0)
        else:
            # Without OTEL, this will raise AttributeError on None.add()
            # This is expected — budget_event requires OTEL
            pass

    def test_emit_budget_event_with_mock_counter(self):
        """Test budget event with mocked OTEL counter."""
        emitter = CostEmitter(
            policy=CostPolicyReader(SPEC_WITH_BUDGET),
            module_id="mod", agent_id="agent", tenant_id="t",
        )
        mock_counter = MagicMock()
        emitter._budget_exceeded_counter = mock_counter

        emitter.emit_budget_event("warn", spent=8.5, limit=10.0)

        mock_counter.add.assert_called_once()
        call_args = mock_counter.add.call_args
        assert call_args[0][0] == 1  # counter incremented by 1
        labels = call_args[0][1]
        assert labels["aap.budget.action"] == "warn"
        assert labels["aap.tenant.id"] == "t"


class TestCostEmitterNoOtel:
    def test_emit_without_otel_still_logs(self):
        """Even without OTEL, emit should produce structured log and return cost."""
        emitter = CostEmitter(
            policy=CostPolicyReader(SPEC),
            module_id="mod", agent_id="agent", tenant_id="t",
        )
        # Force no OTEL counters
        emitter._cost_counter = None
        emitter._input_counter = None
        emitter._output_counter = None
        emitter._requests_counter = None

        cost = emitter.emit("gpt-4o", input_tokens=1000, output_tokens=500)
        assert abs(cost - 0.0125) < 0.0001
