"""Tests for cockpit_aap.manifest.merge — merge_manifests."""

from cockpit_aap.manifest.merge import merge_manifests
from cockpit_aap.manifest.types import (
    Manifest,
    ManifestMetadata,
    ManifestSpec,
    ManifestAgent,
    ManifestArtifact,
    ManifestCommand,
)


def _make_manifest(**kwargs) -> Manifest:
    """Create a minimal manifest with overrides."""
    defaults = dict(
        api_version="cockpit.io/v1",
        kind="Module",
        metadata=ManifestMetadata(name="test", display_name="Test", version="1.0.0"),
        spec=ManifestSpec(),
    )
    defaults.update(kwargs)
    return Manifest(**defaults)


def test_merge_metadata_override_wins():
    base = _make_manifest(metadata=ManifestMetadata(name="base", display_name="Base", version="1.0.0"))
    override = _make_manifest(metadata=ManifestMetadata(name="base", display_name="Override", version="2.0.0"))
    result = merge_manifests(base, override)
    assert result.metadata.display_name == "Override"
    assert result.metadata.version == "2.0.0"


def test_merge_metadata_none_keeps_base():
    base = _make_manifest(
        metadata=ManifestMetadata(name="base", display_name="Base", version="1.0.0", description="desc")
    )
    override = _make_manifest(metadata=ManifestMetadata(name="base", display_name="Base", version="1.0.0"))
    result = merge_manifests(base, override)
    assert result.metadata.description == "desc"


def test_merge_scalar_spec_override():
    base = _make_manifest()
    base.spec.access = {"roles": ["reader"]}
    override = _make_manifest()
    override.spec.access = {"roles": ["admin"]}
    result = merge_manifests(base, override)
    assert result.spec.access == {"roles": ["admin"]}


def test_merge_agents_by_id():
    agent_a = ManifestAgent(id="a", name="Agent A", instruction="base-a")
    agent_b = ManifestAgent(id="b", name="Agent B", instruction="base-b")
    base = _make_manifest()
    base.spec.agents = [agent_a, agent_b]

    override_a = ManifestAgent(id="a", name="Agent A Override", instruction="override-a")
    override = _make_manifest()
    override.spec.agents = [override_a]

    result = merge_manifests(base, override)
    assert len(result.spec.agents) == 2
    # Agent "a" was overridden
    agent_a_result = next(a for a in result.spec.agents if a.id == "a")
    assert agent_a_result.instruction == "override-a"
    # Agent "b" was kept from base
    agent_b_result = next(a for a in result.spec.agents if a.id == "b")
    assert agent_b_result.instruction == "base-b"


def test_merge_agents_new_added():
    agent_a = ManifestAgent(id="a", name="Agent A", instruction="inst-a")
    base = _make_manifest()
    base.spec.agents = [agent_a]

    agent_c = ManifestAgent(id="c", name="Agent C", instruction="inst-c")
    override = _make_manifest()
    override.spec.agents = [agent_c]

    result = merge_manifests(base, override)
    assert len(result.spec.agents) == 2
    ids = {a.id for a in result.spec.agents}
    assert ids == {"a", "c"}


def test_merge_does_not_mutate_originals():
    base = _make_manifest()
    base.spec.agents = [ManifestAgent(id="x", name="X", instruction="orig")]
    override = _make_manifest()
    override.spec.agents = [ManifestAgent(id="x", name="X", instruction="new")]

    result = merge_manifests(base, override)
    # Base should be untouched
    assert base.spec.agents[0].instruction == "orig"
    assert result.spec.agents[0].instruction == "new"


def test_merge_none_spec_field_keeps_base():
    base = _make_manifest()
    base.spec.agents = [ManifestAgent(id="a", name="A", instruction="inst")]
    override = _make_manifest()
    # override.spec.agents is None (default)

    result = merge_manifests(base, override)
    assert len(result.spec.agents) == 1
