"""Tests for MultiAAPClient / create_multi_aap_client."""

from __future__ import annotations

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
from typing import Any

import pytest

from cockpit_aap.mcp_types import AAPServerConfig, MultiAAPClientConfig
from cockpit_aap.multi_client import MultiAAPClient, create_multi_aap_client


# ---------------------------------------------------------------------------
# Two mock MCP servers with different namespaces / tools
# ---------------------------------------------------------------------------

SESSION_ID = "multi-session"


def _make_handler(tools: list[dict[str, Any]], server_name: str):
    """Factory for a mock MCP handler with specific tools."""

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length)) if length else {}

            if "id" not in body:
                self.send_response(202)
                self.send_header("Mcp-Session-Id", SESSION_ID)
                self.end_headers()
                return

            method = body.get("method", "")
            req_id = body["id"]
            params = body.get("params", {})

            if method == "initialize":
                self._ok(req_id, {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "serverInfo": {"name": server_name, "version": "1.0.0"},
                })
            elif method == "tools/list":
                self._ok(req_id, {"tools": tools})
            elif method == "tools/call":
                tool_name = params.get("name", "")
                args = params.get("arguments", {})
                self._ok(req_id, {
                    "content": [{"type": "text", "text": json.dumps({
                        "server": server_name,
                        "tool": tool_name,
                        "args": args,
                    })}],
                    "isError": False,
                })
            elif method == "prompts/list":
                self._ok(req_id, {"prompts": []})
            elif method == "resources/list":
                self._ok(req_id, {"resources": []})
            elif method == "resources/templates/list":
                self._ok(req_id, {"resourceTemplates": []})
            else:
                self._ok(req_id, {})

        def _ok(self, req_id: int, result: Any) -> None:
            payload = json.dumps({"jsonrpc": "2.0", "id": req_id, "result": result}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Mcp-Session-Id", SESSION_ID)
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
            pass

    return Handler


ARTIFACTS_TOOLS = [
    {"name": "search_artifacts", "description": "Search artifacts", "inputSchema": {}},
    {"name": "create_artifact", "description": "Create artifact", "inputSchema": {}},
]

AGENTS_TOOLS = [
    {"name": "list_agent_types", "description": "List agent types", "inputSchema": {}},
    {"name": "create_utility_agent", "description": "Create agent", "inputSchema": {}},
]


@pytest.fixture(scope="module")
def artifacts_server():
    handler = _make_handler(ARTIFACTS_TOOLS, "artifacts-server")
    server = HTTPServer(("127.0.0.1", 0), handler)
    port = server.server_address[1]
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest.fixture(scope="module")
def agents_server():
    handler = _make_handler(AGENTS_TOOLS, "agents-server")
    server = HTTPServer(("127.0.0.1", 0), handler)
    port = server.server_address[1]
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_multi_client(artifacts_server: str, agents_server: str) -> None:
    config = MultiAAPClientConfig(
        servers={
            "artifacts": AAPServerConfig(endpoint=artifacts_server),
            "agents": AAPServerConfig(endpoint=agents_server),
        },
        timeout=10.0,
    )

    sdk = await create_multi_aap_client(config)

    assert sorted(sdk.namespaces) == ["agents", "artifacts"]

    # Verify tools were discovered
    art_tools = sdk.get_tools("artifacts")
    assert len(art_tools) == 2
    assert art_tools[0]["name"] == "search_artifacts"

    agent_tools = sdk.get_tools("agents")
    assert len(agent_tools) == 2
    assert agent_tools[0]["name"] == "list_agent_types"

    await sdk.close()


@pytest.mark.asyncio
async def test_multi_client_tool_call(artifacts_server: str, agents_server: str) -> None:
    config = MultiAAPClientConfig(
        servers={
            "artifacts": AAPServerConfig(endpoint=artifacts_server),
            "agents": AAPServerConfig(endpoint=agents_server),
        },
    )

    sdk = await create_multi_aap_client(config)

    # Call tool on artifacts namespace
    result = await sdk.artifacts.search_artifacts(query="module.*")
    assert result["isError"] is False
    content = result["content"]
    assert content["server"] == "artifacts-server"
    assert content["tool"] == "search_artifacts"

    # Call tool on agents namespace
    result = await sdk.agents.list_agent_types()
    assert result["isError"] is False
    content = result["content"]
    assert content["server"] == "agents-server"
    assert content["tool"] == "list_agent_types"

    await sdk.close()


@pytest.mark.asyncio
async def test_multi_client_unknown_namespace(artifacts_server: str, agents_server: str) -> None:
    config = MultiAAPClientConfig(
        servers={
            "artifacts": AAPServerConfig(endpoint=artifacts_server),
        },
    )

    sdk = await create_multi_aap_client(config)

    # Accessing unknown namespace should raise
    with pytest.raises(AttributeError, match="Unknown namespace"):
        _ = sdk.unknown_ns

    # get_client should raise ValueError
    with pytest.raises(ValueError, match="Unknown namespace"):
        sdk.get_client("unknown_ns")

    await sdk.close()


@pytest.mark.asyncio
async def test_multi_client_context_manager(artifacts_server: str, agents_server: str) -> None:
    config = MultiAAPClientConfig(
        servers={
            "artifacts": AAPServerConfig(endpoint=artifacts_server),
            "agents": AAPServerConfig(endpoint=agents_server),
        },
    )

    sdk = await create_multi_aap_client(config)

    async with sdk:
        assert len(sdk.namespaces) == 2

    # After context manager, underlying transports should be closed
    # (no assertion needed — just verifying no error on close)


@pytest.mark.asyncio
async def test_multi_client_private_attr_raises() -> None:
    sdk = MultiAAPClient({})
    with pytest.raises(AttributeError):
        _ = sdk._private


def test_multi_client_importable_from_init() -> None:
    """Verify multi-client is exported from the package root."""
    from cockpit_aap import MultiAAPClient, create_multi_aap_client  # noqa: F401
