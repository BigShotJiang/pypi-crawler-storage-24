import pytest
from cockpit_aap.manifest.kind_registry import kind_registry
from cockpit_aap.manifest.front_matter import parse_front_matter


def test_utility_agent_registered():
    assert kind_registry.is_registered("UtilityAgent")


def test_parse_front_matter_with_yaml():
    content = "---\nmodel: gpt-4o\ntemperature: 0.7\n---\n\nYou are a helpful assistant."
    result = parse_front_matter(content)
    assert result["has_front_matter"] is True
    assert result["metadata"]["model"] == "gpt-4o"
    assert result["instruction"] == "You are a helpful assistant."


def test_parse_front_matter_without():
    result = parse_front_matter("Just an instruction.")
    assert result["has_front_matter"] is False
    assert result["instruction"] == "Just an instruction."


def test_parse_front_matter_invalid():
    content = "---\ninvalid: [unclosed\n---\n\nThe instruction."
    result = parse_front_matter(content)
    assert result["has_front_matter"] is False
