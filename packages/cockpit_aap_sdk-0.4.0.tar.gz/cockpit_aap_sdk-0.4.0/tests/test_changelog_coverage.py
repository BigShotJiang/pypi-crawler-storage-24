"""Tests for changelog.py — covers build_changelog_entry, merge, serialization, read/write."""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from cockpit_aap.changelog import (
    ChangelogEntry,
    ChangelogNote,
    ChangelogPreservedEntry,
    ModuleChangelog,
    _changelog_entry_to_dict,
    _escape_regex,
    _extract_value,
    _module_changelog_to_dict,
    _parse_module_changelog,
    build_changelog_entry,
    merge_changelog,
    read_changelog,
    write_changelog,
)


# ---------------------------------------------------------------------------
# _escape_regex / _extract_value
# ---------------------------------------------------------------------------


def test_escape_regex():
    assert _escape_regex("mod.name") == r"mod\.name"


class TestExtractValue:
    def test_none(self):
        assert _extract_value(None) is None

    def test_non_dict(self):
        assert _extract_value("str") is None

    def test_artifacts_list(self):
        assert _extract_value({"artifacts": [{"value": "hello"}]}) == "hello"

    def test_artifacts_empty(self):
        assert _extract_value({"artifacts": []}) is None

    def test_direct_value(self):
        assert _extract_value({"value": "val"}) == "val"

    def test_content_key(self):
        assert _extract_value({"content": "cnt"}) == "cnt"

    def test_empty_dict(self):
        assert _extract_value({}) is None

    def test_non_string_value(self):
        assert _extract_value({"value": 123}) is None


# ---------------------------------------------------------------------------
# Serialization / Parsing
# ---------------------------------------------------------------------------


class TestSerialization:
    def test_changelog_entry_to_dict(self):
        entry = ChangelogEntry(
            version="1.0.0",
            date="2024-01-01",
            type="release",
            title="Initial release",
            notes=[
                ChangelogNote(type="added", summary="First feature", key="k1"),
                ChangelogNote(type="fixed", summary="Bug fix"),
            ],
            artifacts={"created": ["k1"], "upgraded": []},
            agents={"created": ["bot"], "upgraded": [], "removed": []},
            feedback_addressed=["fb-1"],
        )
        d = _changelog_entry_to_dict(entry)
        assert d["version"] == "1.0.0"
        assert d["type"] == "release"
        assert len(d["notes"]) == 2
        assert d["notes"][0]["key"] == "k1"
        assert "key" not in d["notes"][1]
        assert d["feedbackAddressed"] == ["fb-1"]

    def test_module_changelog_to_dict(self):
        cl = ModuleChangelog(
            module="mod",
            entries=[
                ChangelogEntry(version="1.0.0", date="2024-01-01", type="release", title="Init"),
            ],
        )
        d = _module_changelog_to_dict(cl)
        assert d["module"] == "mod"
        assert len(d["entries"]) == 1

    def test_parse_module_changelog(self):
        raw = {
            "module": "parsed-mod",
            "entries": [
                {
                    "version": "2.0.0",
                    "date": "2024-06-01",
                    "type": "upgrade",
                    "title": "Major upgrade",
                    "notes": [{"type": "changed", "summary": "Updated API", "key": "api"}],
                    "artifacts": {"created": [], "upgraded": ["api"]},
                    "agents": {},
                    "feedbackAddressed": ["fb-2"],
                },
            ],
        }
        parsed = _parse_module_changelog(raw)
        assert parsed.module == "parsed-mod"
        assert len(parsed.entries) == 1
        assert parsed.entries[0].version == "2.0.0"
        assert parsed.entries[0].notes[0].key == "api"
        assert parsed.entries[0].feedback_addressed == ["fb-2"]

    def test_parse_empty_entries(self):
        raw = {"module": "m", "entries": []}
        parsed = _parse_module_changelog(raw)
        assert parsed.entries == []

    def test_roundtrip(self):
        cl = ModuleChangelog(
            module="rt",
            entries=[
                ChangelogEntry(
                    version="1.0.0", date="2024-01-01", type="release", title="Init",
                    notes=[ChangelogNote(type="added", summary="x")],
                ),
            ],
        )
        d = _module_changelog_to_dict(cl)
        parsed = _parse_module_changelog(d)
        assert parsed.module == cl.module
        assert parsed.entries[0].title == cl.entries[0].title


# ---------------------------------------------------------------------------
# build_changelog_entry
# ---------------------------------------------------------------------------


class TestBuildChangelogEntry:
    def test_initial_release(self):
        definition = type("D", (), {
            "version": "1.0.0",
            "changelog": [],
        })()
        resolved_artifacts = {
            "config.theme": {"source": "created"},
            "state._meta.config": {"source": "created"},  # meta, should be skipped
        }
        resolved_agents = {"dev": {"source": "created"}}
        summary = {"artifactsFromServer": 0, "artifactsUpgraded": 0}

        entry = build_changelog_entry(definition, resolved_artifacts, resolved_agents, None, summary)
        assert entry.type == "release"
        assert entry.title == "Initial release"
        assert "config.theme" in entry.artifacts["created"]
        assert "dev" in entry.agents["created"]

    def test_upgrade_with_notes(self):
        @dataclass
        class Note:
            type: str
            summary: str
            key: str | None = None

        @dataclass
        class CL:
            version: str
            notes: list

        definition = type("D", (), {
            "version": "2.0.0",
            "changelog": [CL(version="2.0.0", notes=[Note(type="changed", summary="Updated theme")])],
        })()
        resolved_artifacts = {"config.theme": {"source": "upgraded"}}
        resolved_agents = {}
        summary = type("S", (), {"artifacts_from_server": 3, "artifacts_upgraded": 1})()

        entry = build_changelog_entry(definition, resolved_artifacts, resolved_agents, None, summary)
        assert entry.type == "upgrade"
        assert entry.title == "Updated theme"
        assert "config.theme" in entry.artifacts["upgraded"]

    def test_upgrade_no_notes_default_title(self):
        definition = type("D", (), {"version": "3.0.0", "changelog": []})()
        summary = {"artifactsFromServer": 1, "artifactsUpgraded": 0}
        entry = build_changelog_entry(definition, {}, {}, None, summary)
        assert entry.title == "Upgrade to v3.0.0"

    def test_with_conflicts_preserved(self):
        definition = type("D", (), {"version": "1.0.0", "changelog": []})()
        meta = {
            "conflicts": {
                "k1": {"resolution": "server-wins"},
                "k2": {"resolution": "log-warning"},
            }
        }
        summary = {"artifactsFromServer": 1, "artifactsUpgraded": 0}
        entry = build_changelog_entry(definition, {}, {}, meta, summary)
        assert len(entry.artifacts["preserved"]) == 2
        assert entry.artifacts["preserved"][0]["reason"] == "conflict:server-wins"
        assert entry.artifacts["preserved"][1]["reason"] == "conflict:log-warning"

    def test_with_dataclass_conflicts(self):
        @dataclass
        class Conflict:
            resolution: str

        definition = type("D", (), {"version": "1.0.0", "changelog": []})()
        meta = type("M", (), {"conflicts": {"k1": Conflict(resolution="server-wins")}})()
        summary = {"artifactsFromServer": 1, "artifactsUpgraded": 0}
        entry = build_changelog_entry(definition, {}, {}, meta, summary)
        assert len(entry.artifacts["preserved"]) == 1

    def test_feedback_addressed(self):
        definition = type("D", (), {"version": "1.0.0", "changelog": []})()
        summary = {"artifactsFromServer": 0, "artifactsUpgraded": 0}
        entry = build_changelog_entry(definition, {}, {}, None, summary, feedback_addressed=["fb-1", "fb-2"])
        assert entry.feedback_addressed == ["fb-1", "fb-2"]

    def test_no_version(self):
        definition = type("D", (), {"changelog": []})()  # no version attr
        summary = {"artifactsFromServer": 0, "artifactsUpgraded": 0}
        entry = build_changelog_entry(definition, {}, {}, None, summary)
        assert entry.version == "0.0.0"

    def test_changelog_with_dict_notes(self):
        """When changelog entries are plain dicts (not dataclass)."""
        definition = type("D", (), {
            "version": "1.0.0",
            "changelog": [
                {"version": "1.0.0", "notes": [{"type": "added", "summary": "New feature", "key": "feat"}]},
                {"version": "0.9.0", "notes": [{"type": "fixed", "summary": "Old fix"}]},
            ],
        })()
        summary = {"artifactsFromServer": 0, "artifactsUpgraded": 0}
        entry = build_changelog_entry(definition, {}, {}, None, summary)
        assert len(entry.notes) == 1
        assert entry.notes[0].summary == "New feature"


# ---------------------------------------------------------------------------
# merge_changelog
# ---------------------------------------------------------------------------


class TestMergeChangelog:
    def test_merge_into_none(self):
        entry = ChangelogEntry(version="1.0.0", date="2024-01-01", type="release", title="Init")
        result = merge_changelog(None, "mod", entry)
        assert result.module == "mod"
        assert len(result.entries) == 1

    def test_merge_prepends_new_version(self):
        existing = ModuleChangelog(
            module="mod",
            entries=[ChangelogEntry(version="1.0.0", date="2024-01-01", type="release", title="Init")],
        )
        new_entry = ChangelogEntry(version="2.0.0", date="2024-06-01", type="upgrade", title="V2")
        result = merge_changelog(existing, "mod", new_entry)
        assert len(result.entries) == 2
        assert result.entries[0].version == "2.0.0"

    def test_merge_replaces_same_version(self):
        existing = ModuleChangelog(
            module="mod",
            entries=[
                ChangelogEntry(version="1.0.0", date="2024-01-01", type="release", title="Old title"),
            ],
        )
        new_entry = ChangelogEntry(version="1.0.0", date="2024-01-02", type="release", title="New title")
        result = merge_changelog(existing, "mod", new_entry)
        assert len(result.entries) == 1
        assert result.entries[0].title == "New title"


# ---------------------------------------------------------------------------
# read_changelog / write_changelog
# ---------------------------------------------------------------------------


class TestReadWriteChangelog:
    @pytest.mark.asyncio
    async def test_read_changelog_success(self):
        data = {
            "module": "test-mod",
            "entries": [
                {
                    "version": "1.0.0",
                    "date": "2024-01-01",
                    "type": "release",
                    "title": "Init",
                    "notes": [],
                    "artifacts": {},
                    "agents": {},
                    "feedbackAddressed": [],
                },
            ],
        }
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": [{"value": json.dumps(data)}]})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_changelog(mock_sdk, "ns", "test-mod")
        assert result is not None
        assert result.module == "test-mod"

    @pytest.mark.asyncio
    async def test_read_changelog_not_found(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_changelog(mock_sdk, "ns", "missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_read_changelog_empty_value(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"artifacts": []})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_changelog(mock_sdk, "ns", "mod")
        assert result is None

    @pytest.mark.asyncio
    async def test_write_changelog(self):
        cl = ModuleChangelog(module="mod", entries=[])
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_ns.create_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await write_changelog(mock_sdk, "ns", "mod", cl)
        mock_ns.create_artifact.assert_called_once()
