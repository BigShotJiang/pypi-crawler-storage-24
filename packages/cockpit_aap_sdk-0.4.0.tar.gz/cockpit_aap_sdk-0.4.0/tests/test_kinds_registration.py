"""Tests for the kinds/ domain registration system."""

from __future__ import annotations

import pytest
import yaml

from cockpit_aap.manifest.kind_registry import KindRegistry, create_kind_registry
from cockpit_aap.kinds import register_all_kinds


@pytest.fixture
def fresh_registry() -> KindRegistry:
    """Create a fresh registry and register all kinds."""
    registry = create_kind_registry()
    register_all_kinds(registry)
    return registry


class TestRegisterAllKinds:
    def test_all_36_kinds_registered(self, fresh_registry: KindRegistry):
        kinds = fresh_registry.registered_kinds()
        assert len(kinds) == 36

    def test_core_kinds_present(self, fresh_registry: KindRegistry):
        for kind in ["Module", "Agent", "Soul", "Persona", "Skill"]:
            assert fresh_registry.is_registered(kind), f"{kind} not registered"

    def test_governance_kinds_present(self, fresh_registry: KindRegistry):
        for kind in ["Policy", "ConformancePolicy", "ManifestPolicy", "RiskProfile", "Guardrail", "CostPolicy"]:
            assert fresh_registry.is_registered(kind), f"{kind} not registered"

    def test_mcp_kinds_present(self, fresh_registry: KindRegistry):
        for kind in ["MCPServer", "MCPTool", "Memory", "Prompt"]:
            assert fresh_registry.is_registered(kind), f"{kind} not registered"

    def test_cards_kinds_present(self, fresh_registry: KindRegistry):
        assert fresh_registry.is_registered("AgentCard")

    def test_observability_kinds_present(self, fresh_registry: KindRegistry):
        for kind in ["DataContract", "Experiment", "Metric", "ModelCard", "TelemetryBlueprint", "ValueStream"]:
            assert fresh_registry.is_registered(kind), f"{kind} not registered"

    def test_engineering_kinds_present(self, fresh_registry: KindRegistry):
        for kind in ["Blueprint", "Package", "Pipeline", "Task"]:
            assert fresh_registry.is_registered(kind), f"{kind} not registered"

    def test_quality_kinds_present(self, fresh_registry: KindRegistry):
        for kind in ["CodeQuality", "SecurityScan", "TestReport"]:
            assert fresh_registry.is_registered(kind), f"{kind} not registered"

    def test_compliance_kinds_present(self, fresh_registry: KindRegistry):
        for kind in ["AuditTrail", "Certificate", "Compliance"]:
            assert fresh_registry.is_registered(kind), f"{kind} not registered"

    def test_lifecycle_kinds_present(self, fresh_registry: KindRegistry):
        for kind in ["Lifecycle", "SDLC", "KindDescriptor", "Lens"]:
            assert fresh_registry.is_registered(kind), f"{kind} not registered"


class TestKindDefinitionStructure:
    def test_module_kind_has_scan(self):
        from cockpit_aap.kinds.core.module import ModuleKind
        assert callable(ModuleKind["scan"])

    def test_module_kind_has_fields(self):
        from cockpit_aap.kinds.core.module import ModuleKind
        assert len(ModuleKind["fields"]) > 0

    def test_module_kind_domain_is_core(self):
        from cockpit_aap.kinds.core.module import ModuleKind
        assert ModuleKind["domain"] == "core"

    def test_agent_kind_api_version(self):
        from cockpit_aap.kinds.core.agent import AgentKind
        assert AgentKind["api_version"] == "agents.md/v1"

    def test_metric_kind_domain_is_observability(self):
        from cockpit_aap.kinds.observability.metric import MetricKind
        assert MetricKind["domain"] == "observability"

    def test_policy_kind_domain_is_governance(self):
        from cockpit_aap.kinds.governance.policy import PolicyKind
        assert PolicyKind["domain"] == "governance"

    def test_mcp_server_kind_domain(self):
        from cockpit_aap.kinds.mcp.mcp_server import MCPServerKind
        assert MCPServerKind["domain"] == "mcp"


class TestDefaultScanParseFunctions:
    def test_simple_kind_scan(self, tmp_path):
        from cockpit_aap.kinds.observability.metric import MetricKind
        manifest = {
            "apiVersion": "observability.cockpit.io/v1",
            "kind": "Metric",
            "metadata": {"name": "test-metric"},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))
        result = MetricKind["scan"](str(tmp_path))
        assert result["kind"] == "Metric"
        assert result["metadata"]["name"] == "test-metric"

    def test_simple_kind_parse(self):
        from cockpit_aap.kinds.governance.policy import PolicyKind
        yaml_str = "apiVersion: governance.cockpit.io/v1\nkind: Policy\nmetadata:\n  name: test\n"
        result = PolicyKind["parse"](yaml_str)
        assert result["kind"] == "Policy"

    def test_scan_wrong_kind_raises(self, tmp_path):
        from cockpit_aap.kinds.observability.metric import MetricKind
        manifest = {
            "apiVersion": "observability.cockpit.io/v1",
            "kind": "Wrong",
            "metadata": {"name": "test"},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))
        with pytest.raises(ValueError, match='Expected kind "Metric"'):
            MetricKind["scan"](str(tmp_path))

    def test_scan_wrong_api_version_raises(self, tmp_path):
        from cockpit_aap.kinds.observability.metric import MetricKind
        manifest = {
            "apiVersion": "wrong/v1",
            "kind": "Metric",
            "metadata": {"name": "test"},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))
        with pytest.raises(ValueError, match='Expected apiVersion "observability.cockpit.io/v1"'):
            MetricKind["scan"](str(tmp_path))


class TestIdempotentRegistration:
    def test_registering_twice_is_safe(self):
        registry = create_kind_registry()
        register_all_kinds(registry)
        count_first = len(registry.registered_kinds())
        register_all_kinds(registry)
        count_second = len(registry.registered_kinds())
        assert count_first == count_second

    def test_does_not_overwrite_existing(self):
        """If a kind is already registered, register_all_kinds should skip it."""
        from cockpit_aap.manifest.kind_registry import KindFieldSchema
        registry = create_kind_registry()
        registry.register(
            "Metric",
            api_version="custom/v1",
            description="Custom metric",
            fields=[KindFieldSchema(path="custom", type="string")],
        )
        register_all_kinds(registry)
        # The custom registration should be preserved
        schema = registry.resolve_schema("Metric")
        assert schema.api_version == "custom/v1"
