"""Tests for decay_engine.py — Python parity with TypeScript."""

import math
import pytest

from cockpit_aap.manifest.decay_engine import (
    compute_decay,
    apply_recall_boost,
    tick_episode,
    apply_decay_cycle,
    evaluate_promotion,
    DEFAULT_DECAY_RATES,
    DECAY_FLOOR,
    RECALL_BOOST_FACTOR,
    PROMOTION_THRESHOLDS,
    EpisodeMemory,
)


def make_episode(**kwargs) -> EpisodeMemory:
    defaults = {
        "session": "2026-03-09T10:00:00Z",
        "actions": ["test action"],
        "importance": 0.5,
        "tier": "buffer",
        "decay_epoch": 0,
        "access_count": 0,
    }
    defaults.update(kwargs)
    return EpisodeMemory(**defaults)


# ── compute_decay ─────────────────────────────────────────────────────────────


class TestComputeDecay:
    def test_epoch_zero_no_decay(self):
        assert compute_decay(1.0, 0, 35) == 1.0

    def test_one_half_life(self):
        result = compute_decay(1.0, 35, 35)
        assert abs(result - math.exp(-1)) < 0.001

    def test_two_half_lives(self):
        result = compute_decay(1.0, 70, 35)
        assert abs(result - math.exp(-2)) < 0.001

    def test_extreme_decay_floors(self):
        result = compute_decay(1.0, 1000, 35)
        assert result == DECAY_FLOOR

    def test_scaled_by_initial_importance(self):
        result = compute_decay(0.5, 35, 35)
        assert abs(result - 0.5 * math.exp(-1)) < 0.001

    def test_negative_epoch_no_decay(self):
        assert compute_decay(0.8, -5, 35) == 0.8

    def test_different_half_lives(self):
        episodic = compute_decay(1.0, 50, DEFAULT_DECAY_RATES["episodic"])
        semantic = compute_decay(1.0, 50, DEFAULT_DECAY_RATES["semantic"])
        procedural = compute_decay(1.0, 50, DEFAULT_DECAY_RATES["procedural"])
        assert episodic < semantic < procedural


# ── apply_recall_boost ────────────────────────────────────────────────────────


class TestApplyRecallBoost:
    def test_boost_from_0_3(self):
        result = apply_recall_boost(0.3)
        expected = 0.3 + RECALL_BOOST_FACTOR * 0.7
        assert abs(result - expected) < 1e-5

    def test_already_max(self):
        assert apply_recall_boost(1.0) == 1.0

    def test_from_zero(self):
        assert abs(apply_recall_boost(0.0) - RECALL_BOOST_FACTOR) < 1e-5

    def test_near_max_caps(self):
        assert apply_recall_boost(0.95) <= 1.0


# ── tick_episode ──────────────────────────────────────────────────────────────


class TestTickEpisode:
    def test_increments_decay_epoch(self):
        ep = make_episode(decay_epoch=3)
        ticked = tick_episode(ep, 35)
        assert ticked.decay_epoch == 4

    def test_importance_decays(self):
        ep = make_episode(importance=0.8, decay_epoch=0)
        ticked = tick_episode(ep, 35)
        assert ticked.importance < 0.8
        assert ticked.importance > 0

    def test_core_tier_respects_core_floor(self):
        ep = make_episode(importance=0.6, tier="core", decay_epoch=100)
        ticked = tick_episode(ep, 35)
        assert ticked.importance >= PROMOTION_THRESHOLDS["core_floor"]

    def test_non_core_uses_decay_floor(self):
        ep = make_episode(importance=0.1, tier="buffer", decay_epoch=500)
        ticked = tick_episode(ep, 35)
        assert ticked.importance >= DECAY_FLOOR

    def test_preserves_original_fields(self):
        ep = make_episode(
            session="2026-01-01T00:00:00Z",
            actions=["original"],
            tags=["original-tag"],
        )
        ticked = tick_episode(ep, 35)
        assert ticked.session == "2026-01-01T00:00:00Z"
        assert ticked.actions == ["original"]
        assert ticked.tags == ["original-tag"]


# ── apply_decay_cycle ─────────────────────────────────────────────────────────


class TestApplyDecayCycle:
    def test_retains_high_importance(self):
        episodes = [
            make_episode(importance=0.9, decay_epoch=0),
            make_episode(importance=0.8, decay_epoch=0),
        ]
        result = apply_decay_cycle(episodes)
        assert len(result.retained) == 2
        assert len(result.archived) == 0

    def test_archives_low_importance(self):
        episodes = [make_episode(importance=0.02, decay_epoch=500)]
        result = apply_decay_cycle(episodes)
        assert len(result.archived) == 1
        assert len(result.retained) == 0

    def test_core_never_archived(self):
        episodes = [make_episode(importance=0.6, tier="core", decay_epoch=1000)]
        result = apply_decay_cycle(episodes)
        assert len(result.retained) == 1
        assert len(result.archived) == 0

    def test_custom_rates(self):
        ep = make_episode(importance=0.5, decay_epoch=0)
        fast = apply_decay_cycle([ep], {"episodic": 5})
        slow = apply_decay_cycle([ep], {"episodic": 500})
        fast_imp = fast.retained[0].importance if fast.retained else 0
        slow_imp = slow.retained[0].importance if slow.retained else 0
        assert fast_imp < slow_imp

    def test_empty_episodes(self):
        result = apply_decay_cycle([])
        assert len(result.retained) == 0
        assert len(result.archived) == 0


# ── evaluate_promotion ────────────────────────────────────────────────────────


class TestEvaluatePromotion:
    def test_buffer_to_working(self):
        ep = make_episode(tier="buffer", importance=0.5, access_count=3)
        assert evaluate_promotion(ep) == "working"

    def test_buffer_stays_low_importance(self):
        ep = make_episode(tier="buffer", importance=0.1, access_count=5)
        assert evaluate_promotion(ep) is None

    def test_buffer_stays_low_access(self):
        ep = make_episode(tier="buffer", importance=0.5, access_count=1)
        assert evaluate_promotion(ep) is None

    def test_working_to_core(self):
        ep = make_episode(tier="working", importance=0.8, access_count=6)
        assert evaluate_promotion(ep) == "core"

    def test_working_demotion(self):
        ep = make_episode(tier="working", importance=0.1, access_count=0)
        assert evaluate_promotion(ep) == "buffer"

    def test_core_never_demoted(self):
        ep = make_episode(tier="core", importance=0.01, access_count=0)
        assert evaluate_promotion(ep) is None

    def test_working_stays_moderate(self):
        ep = make_episode(tier="working", importance=0.5, access_count=3)
        assert evaluate_promotion(ep) is None


# ── constants ─────────────────────────────────────────────────────────────────


class TestConstants:
    def test_default_rates(self):
        assert DEFAULT_DECAY_RATES["episodic"] == 35
        assert DEFAULT_DECAY_RATES["semantic"] == 58
        assert DEFAULT_DECAY_RATES["procedural"] == 173

    def test_decay_floor(self):
        assert DECAY_FLOOR == 0.01

    def test_recall_boost_factor(self):
        assert RECALL_BOOST_FACTOR == 0.3
