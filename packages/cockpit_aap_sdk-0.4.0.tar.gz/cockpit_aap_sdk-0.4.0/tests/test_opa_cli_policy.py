"""Test OPA CLI adapter — skips if opa not installed."""
import pytest
import shutil

has_opa = shutil.which("opa") is not None

@pytest.mark.asyncio
@pytest.mark.skipif(not has_opa, reason="opa CLI not installed")
async def test_evaluate_with_violation():
    from cockpit_aap.adapters.opa_cli_policy import OpaCliPolicyAdapter
    from cockpit_aap.ports.policy_engine import PolicyInput, PolicySource

    adapter = OpaCliPolicyAdapter()
    await adapter.load_policies([PolicySource(
        type="rego", id="test",
        content='package aap.conformance.test\nimport rego.v1\nviolations contains v if {\n    not input.manifest.metadata.name\n    v := {"rule": "name", "severity": "error", "message": "missing"}\n}\n',
    )])
    result = await adapter.evaluate(PolicyInput(manifest={"metadata": {}}))
    assert result.passed is False
    assert len(result.violations) > 0
