"""Tests for rule + lifecycle helper functions."""
import pytest
from cockpit_aap.manifest.types import (
    Manifest, ManifestMetadata, ManifestSpec, ManifestRule, ManifestLifecycle,
    ManifestRoadmapItem, ManifestIssue, ManifestDecision,
)
from cockpit_aap.manifest.helpers import (
    get_manifest_rules,
    get_manifest_rules_by_scope,
    get_manifest_rules_by_enforcement,
    get_manifest_rules_for_agent,
    get_manifest_rules_for_agent_and_scope,
    get_manifest_roadmap,
    get_manifest_roadmap_by_status,
    get_manifest_issues,
    get_manifest_open_issues,
    get_manifest_issues_by_severity,
    get_manifest_decisions,
    build_rules_instruction_snippet,
)


def _make_manifest():
    return Manifest(
        metadata=ManifestMetadata(name="test", version="1.0.0", display_name="Test"),
        spec=ManifestSpec(
            rules=[
                ManifestRule(id="r1", name="Block", condition="v > 1000", enforcement="block",
                             scope="input", evaluation="deterministic", applies_to=["dev-agent"],
                             message="Too high"),
                ManifestRule(id="r2", name="Mask CPF", condition="True", enforcement="mask",
                             scope="output", evaluation="deterministic"),
                ManifestRule(id="r3", name="Warn draft", condition="status == 'draft'",
                             enforcement="warn", scope="both", evaluation="deterministic"),
            ],
            lifecycle=ManifestLifecycle(
                roadmap=[
                    ManifestRoadmapItem(id="Q1", title="Rules", status="in-progress", priority="critical"),
                    ManifestRoadmapItem(id="Q2", title="Telemetry", status="planned", priority="medium"),
                ],
                issues=[
                    ManifestIssue(id="I1", title="Bug A", type="bug", status="open", severity="high"),
                    ManifestIssue(id="I2", title="Bug B", type="bug", status="resolved", severity="low"),
                ],
                decisions=[
                    ManifestDecision(id="D1", title="Parser", context="c", decision="simpleeval", status="accepted"),
                ],
            ),
        ),
    )


def test_get_manifest_rules():
    m = _make_manifest()
    assert len(get_manifest_rules(m)) == 3


def test_get_manifest_rules_empty():
    m = Manifest(metadata=ManifestMetadata(name="t", version="1.0.0", display_name="T"))
    assert get_manifest_rules(m) == []


def test_get_manifest_rules_by_scope():
    m = _make_manifest()
    assert len(get_manifest_rules_by_scope(m, "input")) == 1
    assert get_manifest_rules_by_scope(m, "input")[0].id == "r1"
    assert len(get_manifest_rules_by_scope(m, "output")) == 1
    assert len(get_manifest_rules_by_scope(m, "both")) == 1


def test_get_manifest_rules_by_enforcement():
    m = _make_manifest()
    assert len(get_manifest_rules_by_enforcement(m, "block")) == 1
    assert len(get_manifest_rules_by_enforcement(m, "mask")) == 1


def test_get_manifest_rules_for_agent():
    m = _make_manifest()
    # r1 has applies_to=["dev-agent"], r2 and r3 have no applies_to (global)
    dev_result = get_manifest_rules_for_agent(m, "dev-agent")
    assert "r1" in [r.id for r in dev_result]
    assert "r2" in [r.id for r in dev_result]  # global
    assert "r3" in [r.id for r in dev_result]  # global

    po_result = get_manifest_rules_for_agent(m, "po-agent")
    assert "r1" not in [r.id for r in po_result]  # scoped to dev-agent
    assert "r2" in [r.id for r in po_result]  # global


def test_get_manifest_rules_for_agent_and_scope():
    m = _make_manifest()
    # dev-agent, input scope: r1 (scope:input) + r3 (scope:both)
    result = get_manifest_rules_for_agent_and_scope(m, "dev-agent", "input")
    ids = [r.id for r in result]
    assert "r1" in ids   # scope:input, applies to dev-agent
    assert "r3" in ids   # scope:both, global
    assert "r2" not in ids  # scope:output


def test_build_rules_instruction_snippet_has_blocking_rules():
    m = _make_manifest()
    snippet = build_rules_instruction_snippet(m, "dev-agent")
    assert "Business Rules" in snippet
    assert "Block" in snippet
    assert "BLOCK" in snippet


def test_build_rules_instruction_snippet_empty_when_no_blocking_rules():
    """Agent with only warn rules should get empty snippet."""
    m = Manifest(
        metadata=ManifestMetadata(name="t", version="1.0.0", display_name="T"),
        spec=ManifestSpec(rules=[
            ManifestRule(id="warn-only", name="Warn", condition="True",
                         enforcement="warn", scope="input", evaluation="deterministic")
        ]),
    )
    assert build_rules_instruction_snippet(m, "any-agent") == ""


def test_get_manifest_roadmap():
    m = _make_manifest()
    assert len(get_manifest_roadmap(m)) == 2


def test_get_manifest_roadmap_by_status():
    m = _make_manifest()
    result = get_manifest_roadmap_by_status(m, "in-progress")
    assert len(result) == 1
    assert result[0].id == "Q1"


def test_get_manifest_issues():
    m = _make_manifest()
    assert len(get_manifest_issues(m)) == 2


def test_get_manifest_open_issues():
    m = _make_manifest()
    result = get_manifest_open_issues(m)
    assert len(result) == 1
    assert result[0].id == "I1"


def test_get_manifest_issues_by_severity():
    m = _make_manifest()
    result = get_manifest_issues_by_severity(m, "high")
    assert len(result) == 1


def test_get_manifest_decisions():
    m = _make_manifest()
    assert len(get_manifest_decisions(m)) == 1


def test_empty_lifecycle():
    m = Manifest(metadata=ManifestMetadata(name="t", version="1.0.0", display_name="T"))
    assert get_manifest_roadmap(m) == []
    assert get_manifest_issues(m) == []
    assert get_manifest_decisions(m) == []
