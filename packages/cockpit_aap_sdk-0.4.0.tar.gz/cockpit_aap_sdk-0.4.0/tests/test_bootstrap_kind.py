"""Tests for bootstrap_kind() — generic bootstrap for any registered kind."""
import pytest
from cockpit_aap.bootstrap_kind import bootstrap_kind, BootstrapKindResult
from cockpit_aap.manifest.kind_registry import kind_registry


class FakeSource:
    """In-memory ManifestSourceProtocol for testing."""

    def __init__(self, store: dict | None = None):
        self._store = store or {}

    async def load(self, id: str, kind: str = "Module"):
        key = f"{kind}:{id}"
        if key not in self._store:
            raise KeyError(f"Not found: {key}")
        return self._store[key]

    async def save(self, id: str, kind: str, manifest):
        self._store[f"{kind}:{id}"] = manifest

    async def list(self, kind: str = "Module"):
        return [k.split(":")[1] for k in self._store if k.startswith(f"{kind}:")]


@pytest.mark.asyncio
async def test_bootstrap_kind_from_remote():
    """Bootstrap a kind that exists only in remote source."""
    manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "test"}, "spec": {}}
    source = FakeSource({"Module:test": manifest})

    result = await bootstrap_kind(source=source, kind="Module", id="test")

    assert isinstance(result, BootstrapKindResult)
    assert result.kind == "Module"
    assert result.id == "test"
    assert result.action == "preserved"
    assert result.source == "remote"
    assert result.manifest == manifest


@pytest.mark.asyncio
async def test_bootstrap_kind_not_found_raises():
    """Bootstrap with no local or remote raises RuntimeError."""
    source = FakeSource()

    with pytest.raises(RuntimeError, match="No manifest found"):
        await bootstrap_kind(source=source, kind="Module", id="missing")


@pytest.mark.asyncio
async def test_bootstrap_kind_unregistered_raises():
    """Bootstrap with unregistered kind raises ValueError."""
    source = FakeSource()

    with pytest.raises(ValueError, match="not registered"):
        await bootstrap_kind(source=source, kind="UnknownKind123", id="test")


@pytest.mark.asyncio
async def test_bootstrap_kind_dry_run():
    """Dry run validates but doesn't save."""
    manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "test"}, "spec": {}}
    source = FakeSource({"Module:test": manifest})

    result = await bootstrap_kind(source=source, kind="Module", id="test", dry_run=True)

    assert result.action == "validated-only"
    # Source should not have been modified
    assert "Module:new-entry" not in source._store


@pytest.mark.asyncio
async def test_bootstrap_kind_duration_ms():
    """Result includes duration_ms."""
    manifest = {"apiVersion": "cockpit.io/v1", "kind": "Module", "metadata": {"name": "test"}, "spec": {}}
    source = FakeSource({"Module:test": manifest})

    result = await bootstrap_kind(source=source, kind="Module", id="test")

    assert result.duration_ms >= 0
