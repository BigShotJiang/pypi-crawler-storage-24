"""Tests for PostgresManifestStore — in-memory mock (no Docker required).

Port of the TypeScript tests at
``packages/bootstrap/src/__tests__/postgres-manifest-store.test.ts``.
"""

from __future__ import annotations

import pytest
import pytest_asyncio

from cockpit_aap.adapters.postgres_manifest_store import create_postgres_manifest_store
from helpers.mock_pool import create_mock_pool

TEST_SCHEMA = "test_py_manifest"
STANDARD_AGENT_TYPE_ID = "54f6d2dd-f745-4f75-b58e-a5eaeac32370"


@pytest_asyncio.fixture
async def store():
    pool = create_mock_pool()
    s = create_postgres_manifest_store(pool, schema=TEST_SCHEMA)
    await s.setup()
    return s


@pytest.mark.asyncio
async def test_setup_idempotente(store):
    await store.setup()
    await store.setup()
    assert await store.schema_version() == 1


@pytest.mark.asyncio
async def test_create_artifact_get_artifact_roundtrip(store):
    await store.artifacts.create_artifact(key="test.config", value="hello")
    result = await store.artifacts.get_artifact(key_pattern=r"^test\.config$")
    assert len(result["content"]["artifacts"]) == 1
    assert result["content"]["artifacts"][0]["value"] == "hello"


@pytest.mark.asyncio
async def test_create_artifact_skip_preserva_existente(store):
    await store.artifacts.create_artifact(key="skip.key", value="original")
    await store.artifacts.create_artifact(key="skip.key", value="new", conflict_strategy="SKIP")
    result = await store.artifacts.get_artifact(key_pattern=r"^skip\.key$")
    assert result["content"]["artifacts"][0]["value"] == "original"


@pytest.mark.asyncio
async def test_create_artifact_overwrite(store):
    await store.artifacts.create_artifact(key="overwrite.key", value="v1")
    await store.artifacts.create_artifact(key="overwrite.key", value="v2", conflict_strategy="OVERWRITE")
    result = await store.artifacts.get_artifact(key_pattern=r"^overwrite\.key$")
    assert result["content"]["artifacts"][0]["value"] == "v2"


@pytest.mark.asyncio
async def test_update_artifact(store):
    created = await store.artifacts.create_artifact(key="update.key", value="v1")
    await store.artifacts.update_artifact(id=created["content"]["id"], value="v2")
    result = await store.artifacts.get_artifact(key_pattern=r"^update\.key$")
    assert result["content"]["artifacts"][0]["value"] == "v2"


@pytest.mark.asyncio
async def test_get_artifact_vazio(store):
    result = await store.artifacts.get_artifact(key_pattern=r"^nonexistent\.xyz$")
    assert result["content"]["artifacts"] == []


@pytest.mark.asyncio
async def test_list_agent_types_standard_agent(store):
    result = await store.agents.list_agent_types()
    standard = next(
        (t for t in result["content"]["agent_types"] if t["name"] == "Standard Agent"),
        None,
    )
    assert standard is not None
    assert standard["id"] == STANDARD_AGENT_TYPE_ID


@pytest.mark.asyncio
async def test_create_agent_search_roundtrip(store):
    await store.agents.create_utility_agent(
        name="My Python Agent",
        instructions="Do Python stuff",
        agent_type_id=STANDARD_AGENT_TYPE_ID,
    )
    result = await store.agents.search_utility_agents(query="My Python Agent")
    assert len(result["content"]["utility_agents"]) == 1
    assert result["content"]["utility_agents"][0]["name"] == "My Python Agent"


@pytest.mark.asyncio
async def test_get_full_agent(store):
    await store.agents.create_utility_agent(
        name="Full Agent",
        instructions="Do stuff",
        agent_type_id=STANDARD_AGENT_TYPE_ID,
    )
    searched = await store.agents.search_utility_agents(query="Full Agent")
    agent_id = searched["content"]["utility_agents"][0]["id"]
    full = await store.agents.get_full_utility_agent(agent_id=agent_id)
    assert full["content"]["instructions"] == "Do stuff"
    assert full["content"]["agent_type_id"] == STANDARD_AGENT_TYPE_ID


@pytest.mark.asyncio
async def test_get_full_agent_not_found(store):
    with pytest.raises(ValueError, match="Agent not found"):
        await store.agents.get_full_utility_agent(
            agent_id="00000000-0000-0000-0000-000000000000"
        )


@pytest.mark.asyncio
async def test_search_agent_vazio(store):
    result = await store.agents.search_utility_agents(query="zzz-nonexistent")
    assert result["content"]["utility_agents"] == []
