"""Tests for FilesystemSession — JSON-file-backed SessionStorePort."""

import os
import time
import pytest
from cockpit_aap.adapters.filesystem_session import FilesystemSession, create_filesystem_session


@pytest.fixture
def session_dir(tmp_path):
    return str(tmp_path / "sessions")


@pytest.fixture
def session(session_dir):
    return create_filesystem_session(session_dir)


class TestFilesystemSession:
    @pytest.mark.asyncio
    async def test_save_and_load(self, session):
        await session.save("thread-1", {"messages": ["hello"]})
        state = await session.load("thread-1")
        assert state == {"messages": ["hello"]}

    @pytest.mark.asyncio
    async def test_load_missing(self, session):
        result = await session.load("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_overwrite(self, session):
        await session.save("t1", {"v": 1})
        await session.save("t1", {"v": 2})
        state = await session.load("t1")
        assert state == {"v": 2}

    @pytest.mark.asyncio
    async def test_delete(self, session):
        await session.save("t1", {"v": 1})
        await session.delete("t1")
        assert await session.load("t1") is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, session):
        # Should not raise
        await session.delete("nope")

    @pytest.mark.asyncio
    async def test_list(self, session):
        await session.save("alpha", {"a": 1})
        await session.save("beta", {"b": 2})
        ids = await session.list()
        assert sorted(ids) == ["alpha", "beta"]

    @pytest.mark.asyncio
    async def test_list_with_prefix(self, session):
        await session.save("user/1", {"a": 1})
        await session.save("user/2", {"b": 2})
        await session.save("admin/1", {"c": 3})
        ids = await session.list("user/")
        assert sorted(ids) == ["user/1", "user/2"]

    @pytest.mark.asyncio
    async def test_list_empty(self, session):
        ids = await session.list()
        assert ids == []

    @pytest.mark.asyncio
    async def test_prune(self, session, session_dir):
        await session.save("old", {"v": 1})
        # Manually backdate the file
        encoded = session._encode("old")
        fpath = os.path.join(session_dir, encoded + ".json")
        old_time = time.time() - 7200  # 2 hours ago
        os.utime(fpath, (old_time, old_time))

        await session.save("new", {"v": 2})

        removed = await session.prune(ttl_ms=3_600_000)  # 1 hour
        assert removed == 1
        assert await session.load("old") is None
        assert await session.load("new") is not None

    @pytest.mark.asyncio
    async def test_special_chars_in_thread_id(self, session):
        """Thread IDs with special chars are safely encoded to filenames."""
        tid = "user/thread:123?foo=bar"
        await session.save(tid, {"ok": True})
        state = await session.load(tid)
        assert state == {"ok": True}
        ids = await session.list()
        assert tid in ids

    def test_encoding_roundtrip(self):
        """base64url encoding is reversible."""
        s = FilesystemSession("/tmp/test")
        for tid in ["simple", "with/slash", "with spaces", "emoji-🎉", "a" * 200]:
            assert s._decode(s._encode(tid)) == tid
