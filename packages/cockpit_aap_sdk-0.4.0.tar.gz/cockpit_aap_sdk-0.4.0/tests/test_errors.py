"""Tests for cockpit_aap.errors — BootstrapError."""

from cockpit_aap.errors import BootstrapError


def test_bootstrap_error_attributes():
    err = BootstrapError("failed", item="config.key", phase="artifact")
    assert str(err) == "failed"
    assert err.item == "config.key"
    assert err.phase == "artifact"
    assert err.__cause__ is None


def test_bootstrap_error_with_cause():
    cause = ValueError("bad value")
    err = BootstrapError("wrapped", item="agent-x", phase="agent", cause=cause)
    assert err.phase == "agent"
    assert err.__cause__ is cause


def test_bootstrap_error_is_exception():
    err = BootstrapError("test", item="x", phase="artifact")
    assert isinstance(err, Exception)
    try:
        raise err
    except BootstrapError as e:
        assert e.item == "x"
