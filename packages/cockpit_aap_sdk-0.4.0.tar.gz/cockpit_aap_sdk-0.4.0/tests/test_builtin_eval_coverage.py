"""Tests for testing/built_in_eval.py and testing/helpers.py."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from cockpit_aap.ports.guardrail import GuardrailDecision, GuardrailViolation
from cockpit_aap.ports.cost_tracker import BudgetStatus


# ===========================================================================
# BuiltInEval
# ===========================================================================


class TestBuiltInEval:
    def _make_runtime(self, allowed=True, violations=None, budget=None):
        runtime = MagicMock()
        runtime.before_call = AsyncMock(return_value=GuardrailDecision(
            allowed=allowed,
            action="pass" if allowed else "block",
            violations=violations or [],
        ))
        runtime.after_call = AsyncMock()
        runtime.get_budget_status = AsyncMock(return_value=budget or BudgetStatus())
        return runtime

    @pytest.mark.asyncio
    async def test_pass_basic(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime(allowed=True)
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({"id": "tc-1", "input": "Hello"})
        assert result["passed"] is True
        assert result["mode"] == "mock"
        assert result["id"] == "tc-1"

    @pytest.mark.asyncio
    async def test_live_mode_rejected(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime()
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({"id": "tc-live", "input": "x", "mode": "live"})
        assert result["passed"] is False
        assert "live mode requires" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_redteam_mode_rejected(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime()
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({"id": "tc-rt", "input": "x", "mode": "redteam"})
        assert result["passed"] is False
        assert "redteam" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_expected_action_match(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime(allowed=True)
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({"id": "tc-2", "input": "hi", "expectedAction": "pass"})
        assert result["passed"] is True

    @pytest.mark.asyncio
    async def test_expected_action_mismatch(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime(allowed=True)
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({"id": "tc-3", "input": "hi", "expectedAction": "block"})
        assert result["passed"] is False
        assert "Expected action" in result["error"]

    @pytest.mark.asyncio
    async def test_expected_violation_category_match(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        violations = [GuardrailViolation(rule_id="r", category="pii", message="PII found")]
        runtime = self._make_runtime(allowed=False, violations=violations)
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({
            "id": "tc-4", "input": "SSN 123",
            "expectedViolationCategory": "pii",
        })
        assert result["passed"] is True

    @pytest.mark.asyncio
    async def test_expected_violation_category_mismatch(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        violations = [GuardrailViolation(rule_id="r", category="pii", message="PII")]
        runtime = self._make_runtime(allowed=False, violations=violations)
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({
            "id": "tc-5", "input": "x",
            "expectedViolationCategory": "hate",
        })
        assert result["passed"] is False
        assert "Expected violation category" in result["error"]

    @pytest.mark.asyncio
    async def test_simulate_usage_budget_ok(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime(budget=BudgetStatus(within_budget=True, spent=5, limit=10))
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({
            "id": "tc-6", "input": "x",
            "simulateUsage": {"inputTokens": 100, "outputTokens": 50},
            "expectedBudgetExceeded": False,
        })
        assert result["passed"] is True

    @pytest.mark.asyncio
    async def test_simulate_usage_budget_exceeded_mismatch(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime(budget=BudgetStatus(within_budget=True, spent=5, limit=10))
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({
            "id": "tc-7", "input": "x",
            "simulateUsage": {"inputTokens": 100, "outputTokens": 50},
            "expectedBudgetExceeded": True,
        })
        assert result["passed"] is False
        assert "budgetExceeded" in result["error"]

    @pytest.mark.asyncio
    async def test_exception_in_before_call(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = MagicMock()
        runtime.before_call = AsyncMock(side_effect=Exception("runtime crashed"))
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({"id": "tc-8", "input": "x"})
        assert result["passed"] is False
        assert "runtime crashed" in result["error"]

    @pytest.mark.asyncio
    async def test_no_id_defaults(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime()
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({"input": "x"})
        assert result["id"] == "unknown"

    @pytest.mark.asyncio
    async def test_duration_ms_present(self):
        from cockpit_aap.testing.built_in_eval import BuiltInEval
        runtime = self._make_runtime()
        eval_runner = BuiltInEval(runtime)
        result = await eval_runner.run({"id": "tc-9", "input": "x"})
        assert "durationMs" in result
        assert result["durationMs"] >= 0


# ===========================================================================
# testing/helpers.py
# ===========================================================================


class TestTestingHelpers:
    def test_mock_manifest(self):
        from cockpit_aap.testing.helpers import mock_manifest
        m = mock_manifest()
        assert m.apiVersion == "cockpit.io/v1"
        assert m.kind == "Module"
        assert m.metadata.name == "test-module"

    def test_mock_manifest_with_overrides(self):
        from cockpit_aap.testing.helpers import mock_manifest
        m = mock_manifest(kind="Agent")
        assert m.kind == "Agent"

    def test_dict_to_namespace_nested(self):
        from cockpit_aap.testing.helpers import _dict_to_namespace
        ns = _dict_to_namespace({"a": {"b": "c"}, "list": [1, {"x": 2}]})
        assert ns.a.b == "c"
        assert ns.list[0] == 1
        assert ns.list[1].x == 2

    def test_dict_to_namespace_primitives(self):
        from cockpit_aap.testing.helpers import _dict_to_namespace
        assert _dict_to_namespace("hello") == "hello"
        assert _dict_to_namespace(42) == 42
        assert _dict_to_namespace(None) is None
