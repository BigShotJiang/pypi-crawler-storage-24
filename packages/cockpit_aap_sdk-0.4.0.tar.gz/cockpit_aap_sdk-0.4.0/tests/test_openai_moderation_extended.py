"""Extended tests for openai_moderation_adapter.py — covers _parse_moderation_result and evaluate_* methods."""
from __future__ import annotations

import pytest

from cockpit_aap.ports.guardrail import GuardrailContext
from cockpit_aap.runtime.openai_moderation_adapter import (
    OpenAIModerationAdapter,
    OpenAIModerationConfig,
    CATEGORY_LABELS,
)


class TestParseModeration:
    """Test _parse_moderation_result helper directly."""

    def _adapter(self, **kwargs) -> OpenAIModerationAdapter:
        config = OpenAIModerationConfig(api_key="test-key", **kwargs)
        return OpenAIModerationAdapter(config)

    def test_no_flagged_categories_returns_pass(self):
        adapter = self._adapter()
        result = {
            "categories": {"harassment": False, "hate": False, "violence": False},
            "category_scores": {"harassment": 0.01, "hate": 0.02, "violence": 0.0},
        }
        decision = adapter._parse_moderation_result(result)
        assert decision.allowed is True
        assert decision.action == "pass"
        assert len(decision.violations) == 0

    def test_single_block_category(self):
        adapter = self._adapter()
        result = {
            "categories": {"violence": True, "harassment": False},
            "category_scores": {"violence": 0.95, "harassment": 0.01},
        }
        decision = adapter._parse_moderation_result(result)
        assert decision.allowed is False
        assert decision.action == "block"
        assert len(decision.violations) == 1
        v = decision.violations[0]
        assert v.rule_id == "openai-mod-violence"
        assert v.category == "content-safety"
        assert v.severity == "block"
        assert "Violence" in v.message
        assert "0.95" in v.message

    def test_warn_category_does_not_block(self):
        adapter = self._adapter(warn_categories=["harassment"])
        result = {
            "categories": {"harassment": True},
            "category_scores": {"harassment": 0.8},
        }
        decision = adapter._parse_moderation_result(result)
        assert decision.allowed is True
        assert decision.action == "warn"
        assert len(decision.violations) == 1
        assert decision.violations[0].severity == "warn"

    def test_mixed_warn_and_block(self):
        adapter = self._adapter(warn_categories=["harassment"])
        result = {
            "categories": {"harassment": True, "violence": True},
            "category_scores": {"harassment": 0.7, "violence": 0.9},
        }
        decision = adapter._parse_moderation_result(result)
        assert decision.allowed is False
        assert decision.action == "block"
        assert len(decision.violations) == 2
        severities = {v.severity for v in decision.violations}
        assert "warn" in severities
        assert "block" in severities

    def test_multiple_flagged_all_block(self):
        adapter = self._adapter()
        result = {
            "categories": {"hate": True, "violence": True, "sexual": True},
            "category_scores": {"hate": 0.9, "violence": 0.8, "sexual": 0.7},
        }
        decision = adapter._parse_moderation_result(result)
        assert decision.allowed is False
        assert decision.action == "block"
        assert len(decision.violations) == 3

    def test_subcategory_slash_replaced_in_rule_id(self):
        adapter = self._adapter()
        result = {
            "categories": {"hate/threatening": True},
            "category_scores": {"hate/threatening": 0.85},
        }
        decision = adapter._parse_moderation_result(result)
        assert decision.violations[0].rule_id == "openai-mod-hate-threatening"
        assert "Hate Speech / Threatening" in decision.violations[0].message

    def test_unknown_category_uses_raw_name(self):
        adapter = self._adapter()
        result = {
            "categories": {"new-future-category": True},
            "category_scores": {"new-future-category": 0.75},
        }
        decision = adapter._parse_moderation_result(result)
        assert decision.violations[0].rule_id == "openai-mod-new-future-category"
        # Unknown category label falls back to raw category name
        assert "new-future-category" in decision.violations[0].message

    def test_empty_categories_returns_pass(self):
        adapter = self._adapter()
        result = {"categories": {}, "category_scores": {}}
        decision = adapter._parse_moderation_result(result)
        assert decision.allowed is True
        assert decision.action == "pass"

    def test_missing_score_defaults_to_zero(self):
        adapter = self._adapter()
        result = {
            "categories": {"violence": True},
            "category_scores": {},  # no scores provided
        }
        decision = adapter._parse_moderation_result(result)
        assert "0.00" in decision.violations[0].message

    def test_multiple_warn_categories(self):
        adapter = self._adapter(warn_categories=["harassment", "hate"])
        result = {
            "categories": {"harassment": True, "hate": True},
            "category_scores": {"harassment": 0.6, "hate": 0.7},
        }
        decision = adapter._parse_moderation_result(result)
        assert decision.allowed is True
        assert decision.action == "warn"
        assert len(decision.violations) == 2
        assert all(v.severity == "warn" for v in decision.violations)


class TestModerationEvaluate:
    """Test evaluate_input/evaluate_output async methods."""

    @pytest.mark.asyncio
    async def test_evaluate_input_empty_string(self):
        config = OpenAIModerationConfig(api_key="test-key")
        adapter = OpenAIModerationAdapter(config)
        ctx = GuardrailContext(agent_id="test", input="")
        decision = await adapter.evaluate_input(ctx)
        assert decision.allowed is True
        assert decision.action == "pass"

    @pytest.mark.asyncio
    async def test_evaluate_input_whitespace_only(self):
        config = OpenAIModerationConfig(api_key="test-key")
        adapter = OpenAIModerationAdapter(config)
        ctx = GuardrailContext(agent_id="test", input="   ")
        decision = await adapter.evaluate_input(ctx)
        assert decision.allowed is True
        assert decision.action == "pass"

    @pytest.mark.asyncio
    async def test_evaluate_output_empty_string(self):
        config = OpenAIModerationConfig(api_key="test-key")
        adapter = OpenAIModerationAdapter(config)
        ctx = GuardrailContext(agent_id="test", input="")
        decision = await adapter.evaluate_output(ctx)
        assert decision.allowed is True
        assert decision.action == "pass"

    @pytest.mark.asyncio
    async def test_evaluate_input_no_api_key(self):
        config = OpenAIModerationConfig(api_key="")
        adapter = OpenAIModerationAdapter(config)
        ctx = GuardrailContext(agent_id="test", input="some content")
        decision = await adapter.evaluate_input(ctx)
        assert decision.allowed is True
        assert decision.action == "pass"

    @pytest.mark.asyncio
    async def test_close_no_client(self):
        adapter = OpenAIModerationAdapter(OpenAIModerationConfig(api_key=""))
        # close without ever creating a client should not raise
        await adapter.close()
        assert adapter._client is None


class TestOpenAIModerationConfig:
    """Test config defaults and post_init."""

    def test_default_config(self):
        config = OpenAIModerationConfig()
        assert config.model == "omni-moderation-latest"
        assert config.score_threshold == 0.5
        assert config.block_categories == []
        assert config.warn_categories == ["harassment"]

    def test_api_key_from_env(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test-env-key")
        config = OpenAIModerationConfig()
        assert config.api_key == "sk-test-env-key"

    def test_explicit_api_key_overrides_env(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-from-env")
        config = OpenAIModerationConfig(api_key="sk-explicit")
        assert config.api_key == "sk-explicit"
