# packages/py/tests/test_tenant_postgres_source.py
"""Tests for TenantPostgresManifestSource — tenant-aware manifest storage."""
from __future__ import annotations

import pytest
import pytest_asyncio

from cockpit_aap.adapters.tenant_postgres_manifest_source import (
    TenantPostgresManifestSource,
    create_tenant_postgres_source,
    _GLOBAL,
)
from cockpit_aap.ports.tenant_resolver import TenantContext
from tests.helpers.mock_pool import create_mock_pool


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture
async def source() -> TenantPostgresManifestSource:
    pool = create_mock_pool()
    src = create_tenant_postgres_source(pool)
    await src.setup()
    return src


def _simple_manifest(name: str = "my-module") -> dict:
    return {
        "apiVersion": "cockpit.io/v1",
        "kind": "Module",
        "metadata": {"name": name, "version": "1.0.0"},
        "spec": {},
    }


# ---------------------------------------------------------------------------
# Test: save / load with explicit tenant
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_save_load_with_tenant(source: TenantPostgresManifestSource) -> None:
    tenant = TenantContext(license_id="acme", namespace_id="prod")
    manifest = _simple_manifest("acme-module")

    await source.save("acme-module", "Module", manifest, tenant=tenant)
    loaded = await source.load("acme-module", "Module", tenant=tenant)

    # parse_yaml returns a Manifest dataclass
    assert loaded.metadata.name == "acme-module"


@pytest.mark.asyncio
async def test_save_overwrite_with_tenant(source: TenantPostgresManifestSource) -> None:
    tenant = TenantContext(license_id="acme", namespace_id="prod")
    manifest_v1 = _simple_manifest("mod")
    manifest_v2 = {**_simple_manifest("mod"), "metadata": {"name": "mod", "version": "2.0.0"}}

    await source.save("mod", "Module", manifest_v1, tenant=tenant)
    await source.save("mod", "Module", manifest_v2, tenant=tenant)
    loaded = await source.load("mod", "Module", tenant=tenant)

    assert loaded.metadata.version == "2.0.0"


# ---------------------------------------------------------------------------
# Test: save / load without tenant (global slot)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_save_load_global(source: TenantPostgresManifestSource) -> None:
    manifest = _simple_manifest("global-module")

    await source.save("global-module", "Module", manifest)
    loaded = await source.load("global-module", "Module")

    assert loaded.metadata.name == "global-module"


@pytest.mark.asyncio
async def test_save_load_with_explicit_global_tenant(source: TenantPostgresManifestSource) -> None:
    manifest = _simple_manifest("shared")

    await source.save("shared", "Module", manifest, tenant=_GLOBAL)
    loaded = await source.load("shared", "Module", tenant=_GLOBAL)

    assert loaded.metadata.name == "shared"


# ---------------------------------------------------------------------------
# Test: 3-level fallback chain
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_fallback_chain_level1_exact_tenant(source: TenantPostgresManifestSource) -> None:
    """Exact tenant match is returned first even if global also exists."""
    tenant = TenantContext(license_id="acme", namespace_id="prod")
    global_manifest = _simple_manifest("mod")
    tenant_manifest = {**_simple_manifest("mod"), "metadata": {"name": "mod", "version": "tenant"}}

    await source.save("mod", "Module", global_manifest)              # global
    await source.save("mod", "Module", tenant_manifest, tenant=tenant)  # tenant-specific
    loaded = await source.load("mod", "Module", tenant=tenant)

    assert loaded.metadata.version == "tenant"


@pytest.mark.asyncio
async def test_fallback_chain_level2_license_default(source: TenantPostgresManifestSource) -> None:
    """Falls back to license-level default when namespace-specific is missing."""
    license_default_tenant = TenantContext(license_id="acme", namespace_id="_global")
    specific_tenant = TenantContext(license_id="acme", namespace_id="staging")

    license_manifest = {**_simple_manifest("mod"), "metadata": {"name": "mod", "version": "license-default"}}
    await source.save("mod", "Module", license_manifest, tenant=license_default_tenant)

    # No staging-specific manifest — should fall back to license default
    loaded = await source.load("mod", "Module", tenant=specific_tenant)

    assert loaded.metadata.version == "license-default"


@pytest.mark.asyncio
async def test_fallback_chain_level3_global(source: TenantPostgresManifestSource) -> None:
    """Falls back to global when neither tenant-specific nor license default exists."""
    tenant = TenantContext(license_id="acme", namespace_id="prod")
    global_manifest = {**_simple_manifest("mod"), "metadata": {"name": "mod", "version": "global"}}

    await source.save("mod", "Module", global_manifest)  # global slot only
    loaded = await source.load("mod", "Module", tenant=tenant)

    assert loaded.metadata.version == "global"


@pytest.mark.asyncio
async def test_fallback_chain_license_wins_over_global(source: TenantPostgresManifestSource) -> None:
    """License default beats global when both exist."""
    tenant = TenantContext(license_id="acme", namespace_id="prod")
    license_default = TenantContext(license_id="acme", namespace_id="_global")

    global_manifest = {**_simple_manifest("mod"), "metadata": {"name": "mod", "version": "global"}}
    license_manifest = {**_simple_manifest("mod"), "metadata": {"name": "mod", "version": "license"}}

    await source.save("mod", "Module", global_manifest)
    await source.save("mod", "Module", license_manifest, tenant=license_default)

    loaded = await source.load("mod", "Module", tenant=tenant)
    assert loaded.metadata.version == "license"


@pytest.mark.asyncio
async def test_fallback_chain_not_found_raises(source: TenantPostgresManifestSource) -> None:
    tenant = TenantContext(license_id="acme", namespace_id="prod")
    with pytest.raises(ValueError, match="Manifest not found"):
        await source.load("nonexistent", "Module", tenant=tenant)


# ---------------------------------------------------------------------------
# Test: tenant isolation (cross-tenant reads must not leak)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tenant_isolation(source: TenantPostgresManifestSource) -> None:
    """A tenant cannot read another tenant's manifest via exact-match load."""
    tenant_a = TenantContext(license_id="acme", namespace_id="prod")
    tenant_b = TenantContext(license_id="other", namespace_id="prod")

    manifest_a = {**_simple_manifest("mod"), "metadata": {"name": "mod", "version": "tenant-a"}}
    # Save only for tenant_a — no global fallback
    source_no_fallback = create_tenant_postgres_source(
        source._pool, fallback_chain=False  # type: ignore[arg-type]
    )
    await source_no_fallback.save("mod", "Module", manifest_a, tenant=tenant_a)

    with pytest.raises(ValueError, match="Manifest not found"):
        await source_no_fallback.load("mod", "Module", tenant=tenant_b)


# ---------------------------------------------------------------------------
# Test: list
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_with_tenant(source: TenantPostgresManifestSource) -> None:
    tenant = TenantContext(license_id="acme", namespace_id="prod")
    other_tenant = TenantContext(license_id="other", namespace_id="prod")

    await source.save("module-a", "Module", _simple_manifest("module-a"), tenant=tenant)
    await source.save("module-b", "Module", _simple_manifest("module-b"), tenant=tenant)
    await source.save("module-c", "Module", _simple_manifest("module-c"), tenant=other_tenant)

    entries = await source.list("Module", tenant=tenant)
    ids = [e.id for e in entries]
    assert "module-a" in ids
    assert "module-b" in ids
    assert "module-c" not in ids
    # Verify ManifestEntry structure
    assert all(hasattr(e, "kind") for e in entries)
    assert all(hasattr(e, "source") for e in entries)
    assert all("postgres:" in (e.source or "") for e in entries)


@pytest.mark.asyncio
async def test_list_global_without_tenant(source: TenantPostgresManifestSource) -> None:
    await source.save("global-a", "Module", _simple_manifest("global-a"))
    await source.save("global-b", "Module", _simple_manifest("global-b"))

    entries = await source.list("Module")
    ids = [e.id for e in entries]
    assert "global-a" in ids
    assert "global-b" in ids


@pytest.mark.asyncio
async def test_list_without_kind_filter(source: TenantPostgresManifestSource) -> None:
    tenant = TenantContext(license_id="acme", namespace_id="prod")
    await source.save("mod-1", "Module", _simple_manifest("mod-1"), tenant=tenant)
    await source.save("agent-1", "Agent", {"id": "agent-1"}, tenant=tenant)

    entries = await source.list(tenant=tenant)
    ids = [e.id for e in entries]
    assert "mod-1" in ids
    assert "agent-1" in ids


# ---------------------------------------------------------------------------
# Test: fallback_chain=False disables fallback
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_fallback_chain_raises_immediately() -> None:
    pool = create_mock_pool()
    src = create_tenant_postgres_source(pool, fallback_chain=False)
    await src.setup()

    tenant = TenantContext(license_id="acme", namespace_id="prod")

    # Save only at global — with fallback disabled, tenant-specific load must fail
    await src.save("mod", "Module", _simple_manifest("mod"))

    with pytest.raises(ValueError, match="Manifest not found"):
        await src.load("mod", "Module", tenant=tenant)


# ---------------------------------------------------------------------------
# Test: schema_version
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schema_version_after_setup() -> None:
    pool = create_mock_pool()
    src = create_tenant_postgres_source(pool)
    await src.setup()
    version = await src.schema_version()
    assert version == 2


@pytest.mark.asyncio
async def test_schema_version_before_setup_returns_zero() -> None:
    pool = create_mock_pool()
    src = create_tenant_postgres_source(pool)
    version = await src.schema_version()
    assert version == 0


# ---------------------------------------------------------------------------
# Test: factory function
# ---------------------------------------------------------------------------


def test_create_factory_returns_correct_type() -> None:
    pool = create_mock_pool()
    src = create_tenant_postgres_source(pool, schema="myschema", fallback_chain=False)
    assert isinstance(src, TenantPostgresManifestSource)
    assert src._schema == "myschema"
    assert src._fallback_chain is False
