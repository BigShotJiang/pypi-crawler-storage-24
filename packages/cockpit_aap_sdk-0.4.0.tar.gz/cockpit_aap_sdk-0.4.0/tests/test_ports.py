"""Tests for Python port adapters."""

import asyncio
import time

import pytest

from cockpit_aap.adapters import (
    create_in_memory_adapter,
    create_in_memory_session,
    create_in_memory_storage,
    create_noop_auth,
    create_noop_embedding,
    create_noop_llm,
    create_noop_observability,
)
from cockpit_aap.context import AAPContext, create_aap_context
from cockpit_aap.ports import LLMMessage


# ---------------------------------------------------------------------------
# InMemoryManifestStore
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_in_memory_adapter_create_get_artifact():
    store = create_in_memory_adapter()
    await store.artifacts.create_artifact(key="my.config", value="hello")
    result = await store.artifacts.get_artifact(key_pattern=r"^my\.config$")
    artifacts = result["content"]["artifacts"]
    assert len(artifacts) == 1
    assert artifacts[0]["key"] == "my.config"
    assert artifacts[0]["value"] == "hello"


@pytest.mark.asyncio
async def test_in_memory_adapter_create_skip():
    store = create_in_memory_adapter()
    r1 = await store.artifacts.create_artifact(key="k", value="v1", conflict_strategy="SKIP")
    r2 = await store.artifacts.create_artifact(key="k", value="v2", conflict_strategy="SKIP")
    # Second call should return original value unchanged
    assert r2["content"]["value"] == "v1"


@pytest.mark.asyncio
async def test_in_memory_adapter_update_artifact():
    store = create_in_memory_adapter()
    create_resp = await store.artifacts.create_artifact(key="k", value="old")
    artifact_id = create_resp["content"]["id"]
    await store.artifacts.update_artifact(id=artifact_id, value="new")
    get_resp = await store.artifacts.get_artifact(key_pattern=r"^k$")
    assert get_resp["content"]["artifacts"][0]["value"] == "new"


@pytest.mark.asyncio
async def test_in_memory_adapter_agents_round_trip():
    store = create_in_memory_adapter()
    types_resp = await store.agents.list_agent_types()
    type_id = types_resp["content"]["agent_types"][0]["id"]

    await store.agents.create_utility_agent(
        name="Test Agent", instructions="You are helpful.", agent_type_id=type_id
    )
    search_resp = await store.agents.search_utility_agents(query="Test")
    assert len(search_resp["content"]["utility_agents"]) == 1
    agent_id = search_resp["content"]["utility_agents"][0]["id"]

    full_resp = await store.agents.get_full_utility_agent(agent_id=agent_id)
    assert full_resp["content"]["instructions"] == "You are helpful."


# ---------------------------------------------------------------------------
# NoopAdapters
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_noop_auth():
    auth = create_noop_auth()
    assert await auth.get_session() is None
    assert await auth.get_access_token() is None
    assert await auth.has_role("admin") is False


def test_noop_observability():
    obs = create_noop_observability()
    with obs.start_span("test-span") as span:
        span.set_attribute("key", "value")
        span.set_status("ok")
    obs.record_metric("requests", 1.0)
    obs.log_event("user_action", {"type": "click"})


@pytest.mark.asyncio
async def test_noop_llm():
    llm = create_noop_llm("hello world")
    response = await llm.complete([LLMMessage(role="user", content="hi")])
    assert response.content == "hello world"
    assert response.model == "noop"


@pytest.mark.asyncio
async def test_noop_embedding():
    emb = create_noop_embedding()
    assert emb.dimensions == 1536
    vectors = await emb.embed(["text1", "text2"])
    assert len(vectors) == 2
    assert all(v == 0.0 for v in vectors[0])


# ---------------------------------------------------------------------------
# InMemorySession
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_in_memory_session_save_load():
    session = create_in_memory_session()
    await session.save("thread-1", {"count": 42})
    loaded = await session.load("thread-1")
    assert loaded["count"] == 42


@pytest.mark.asyncio
async def test_in_memory_session_load_missing():
    session = create_in_memory_session()
    assert await session.load("nope") is None


@pytest.mark.asyncio
async def test_in_memory_session_delete():
    session = create_in_memory_session()
    await session.save("t1", {})
    await session.delete("t1")
    assert await session.load("t1") is None


@pytest.mark.asyncio
async def test_in_memory_session_list_prefix():
    session = create_in_memory_session()
    await session.save("a-1", {})
    await session.save("a-2", {})
    await session.save("b-1", {})
    all_keys = await session.list()
    assert len(all_keys) == 3
    a_keys = await session.list("a-")
    assert len(a_keys) == 2


@pytest.mark.asyncio
async def test_in_memory_session_prune():
    session = create_in_memory_session()
    await session.save("old", {})
    pruned = await session.prune(ttl_ms=-1)  # ttl=-1ms → cutoff 1ms in future
    assert pruned >= 1
    assert await session.load("old") is None


# ---------------------------------------------------------------------------
# InMemoryStorage
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_in_memory_storage_write_read():
    storage = create_in_memory_storage()
    url = await storage.write("docs/readme.md", "# Hello")
    assert url == "memory://docs/readme.md"
    content = await storage.read("docs/readme.md")
    assert content == b"# Hello"


@pytest.mark.asyncio
async def test_in_memory_storage_exists_delete():
    storage = create_in_memory_storage()
    await storage.write("file.txt", b"data")
    assert await storage.exists("file.txt") is True
    await storage.delete("file.txt")
    assert await storage.exists("file.txt") is False


@pytest.mark.asyncio
async def test_in_memory_storage_read_missing():
    storage = create_in_memory_storage()
    with pytest.raises(FileNotFoundError):
        await storage.read("missing.txt")


@pytest.mark.asyncio
async def test_in_memory_storage_list():
    storage = create_in_memory_storage()
    await storage.write("a/1.txt", b"x")
    await storage.write("a/2.txt", b"y")
    await storage.write("b/1.txt", b"z")
    all_files = await storage.list()
    assert len(all_files) == 3
    a_files = await storage.list("a/")
    assert len(a_files) == 2


# ---------------------------------------------------------------------------
# AAPContext
# ---------------------------------------------------------------------------


def test_aap_context_factory():
    store = create_in_memory_adapter()
    ctx = create_aap_context(
        store=store,
        llm=create_noop_llm(),
        session=create_in_memory_session(),
    )
    assert ctx.store is store
    assert ctx.llm is not None
    assert ctx.session is not None
    assert ctx.auth is None
    assert ctx.observability is None
    assert ctx.files is None
    assert ctx.embeddings is None
