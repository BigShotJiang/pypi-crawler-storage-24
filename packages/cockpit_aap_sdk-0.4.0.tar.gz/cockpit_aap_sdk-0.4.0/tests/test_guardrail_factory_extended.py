"""Extended tests for guardrail_factory.py — covers _get_guardrails_spec, _create_adapter, and factory edge cases."""
from __future__ import annotations

from unittest.mock import patch

import pytest

from cockpit_aap.runtime.guardrail_factory import (
    create_guardrail_from_manifest,
    _get_guardrails_spec,
    _create_adapter,
)
from cockpit_aap.runtime.regex_guardrail import RegexGuardrailAdapter


# ── _get_guardrails_spec ──

class TestGetGuardrailsSpec:
    """Test extraction of spec.guardrails from various manifest shapes."""

    def test_dict_manifest_with_guardrails(self):
        manifest = {"spec": {"guardrails": {"input": [{"id": "pii", "adapter": "regex"}]}}}
        result = _get_guardrails_spec(manifest)
        assert result == {"input": [{"id": "pii", "adapter": "regex"}]}

    def test_dict_manifest_no_guardrails(self):
        manifest = {"spec": {"agents": []}}
        result = _get_guardrails_spec(manifest)
        assert result is None

    def test_dict_manifest_empty_spec(self):
        manifest = {"spec": {}}
        result = _get_guardrails_spec(manifest)
        assert result is None

    def test_dict_manifest_no_spec(self):
        manifest = {}
        result = _get_guardrails_spec(manifest)
        assert result is None

    def test_object_manifest_with_spec_dict(self):
        """Manifest object with spec as a plain dict."""
        class Manifest:
            spec = {"guardrails": {"input": [{"id": "x"}]}}
        result = _get_guardrails_spec(Manifest())
        assert result == {"input": [{"id": "x"}]}

    def test_object_manifest_with_spec_object(self):
        """Manifest object with spec as an object with guardrails attr."""
        class Spec:
            guardrails = {"input": [{"id": "y", "adapter": "regex"}]}
        class Manifest:
            spec = Spec()
        result = _get_guardrails_spec(Manifest())
        assert result == {"input": [{"id": "y", "adapter": "regex"}]}

    def test_object_manifest_spec_none(self):
        class Manifest:
            spec = None
        result = _get_guardrails_spec(Manifest())
        assert result is None

    def test_object_manifest_no_spec_attr(self):
        class Manifest:
            pass
        result = _get_guardrails_spec(Manifest())
        assert result is None

    def test_object_manifest_spec_object_no_guardrails(self):
        class Spec:
            agents = []
        class Manifest:
            spec = Spec()
        result = _get_guardrails_spec(Manifest())
        assert result is None


# ── _create_adapter ──

class TestCreateAdapter:
    """Test _create_adapter for each adapter type."""

    def test_llamaguard_created(self):
        adapter = _create_adapter("llamaguard")
        from cockpit_aap.runtime.llamaguard_adapter import LlamaGuardAdapter
        assert isinstance(adapter, LlamaGuardAdapter)

    def test_openai_moderation_created(self):
        adapter = _create_adapter("openai-moderation")
        from cockpit_aap.runtime.openai_moderation_adapter import OpenAIModerationAdapter
        assert isinstance(adapter, OpenAIModerationAdapter)

    def test_unknown_adapter_returns_none(self):
        adapter = _create_adapter("nonexistent-adapter-xyz")
        assert adapter is None

    def test_llamafirewall_unavailable_returns_none(self):
        """llamafirewall requires external dep; if import fails, returns None."""
        adapter = _create_adapter("llamafirewall")
        # Either returns the adapter (if installed) or None
        if adapter is None:
            assert True  # Expected if dependency not available
        else:
            from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
            assert isinstance(adapter, LlamaFirewallAdapter)

    def test_guardrails_ai_unavailable_returns_none(self):
        """guardrails-ai requires external dep; if import fails, returns None."""
        adapter = _create_adapter("guardrails-ai")
        # Either returns the adapter (if installed) or None
        # In test env, guardrails-ai is typically not installed
        assert adapter is None or adapter is not None  # no crash


# ── create_guardrail_from_manifest edge cases ──

class TestCreateGuardrailFromManifestExtended:
    """Additional factory tests covering uncovered branches."""

    def test_output_rules_adapter_types_collected(self):
        """Output rules should also be scanned for adapter types."""
        manifest = {
            "spec": {
                "guardrails": {
                    "input": [],
                    "output": [{"id": "safety", "adapter": "regex"}],
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        assert any(isinstance(a, RegexGuardrailAdapter) for a in composite.adapters)

    def test_only_output_llamaguard(self):
        """When only output rules have llamaguard, it should still be created."""
        from cockpit_aap.runtime.llamaguard_adapter import LlamaGuardAdapter
        manifest = {
            "spec": {
                "guardrails": {
                    "input": [],
                    "output": [{"id": "safety", "adapter": "llamaguard"}],
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        assert any(isinstance(a, LlamaGuardAdapter) for a in composite.adapters)

    def test_no_adapter_field_defaults_to_regex(self):
        """Rules without explicit adapter field default to 'regex'."""
        manifest = {
            "spec": {
                "guardrails": {
                    "input": [{"id": "pii"}],  # No "adapter" key
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        assert len(composite.adapters) == 1
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)

    def test_empty_guardrails_spec_returns_regex(self):
        """Empty guardrails with no input/output rules still returns regex fallback."""
        manifest = {
            "spec": {
                "guardrails": {}
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        # No input or output rules -> no adapter_types_seen -> fallback regex
        assert len(composite.adapters) == 1
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)

    def test_object_rules_with_getattr(self):
        """Rules can be objects with adapter as attribute instead of dict."""
        class Rule:
            def __init__(self, adapter):
                self.adapter = adapter
                self.id = "test"

        class GuardrailsSpec:
            input = [Rule("regex")]
            output = []

        class Spec:
            guardrails = GuardrailsSpec()

        class Manifest:
            spec = Spec()

        composite = create_guardrail_from_manifest(Manifest())
        assert len(composite.adapters) == 1
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)

    def test_mixed_adapters_sorted_after_regex(self):
        """Non-regex adapters are sorted alphabetically after regex."""
        from cockpit_aap.runtime.llamaguard_adapter import LlamaGuardAdapter
        from cockpit_aap.runtime.openai_moderation_adapter import OpenAIModerationAdapter
        manifest = {
            "spec": {
                "guardrails": {
                    "input": [
                        {"id": "a", "adapter": "openai-moderation"},
                        {"id": "b", "adapter": "regex"},
                        {"id": "c", "adapter": "llamaguard"},
                    ]
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        # regex first, then alphabetically: llamaguard, openai-moderation
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)
        assert isinstance(composite.adapters[1], LlamaGuardAdapter)
        assert isinstance(composite.adapters[2], OpenAIModerationAdapter)

    def test_all_unknown_adapters_fallback_to_regex(self):
        """If all adapters fail to create, we still get regex fallback."""
        manifest = {
            "spec": {
                "guardrails": {
                    "input": [
                        {"id": "a", "adapter": "nonexistent1"},
                        {"id": "b", "adapter": "nonexistent2"},
                    ]
                }
            }
        }
        composite = create_guardrail_from_manifest(manifest)
        assert len(composite.adapters) == 1
        assert isinstance(composite.adapters[0], RegexGuardrailAdapter)
