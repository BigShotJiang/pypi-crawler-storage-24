"""Tests for governance scoring module — feature parity with TS scoring.ts."""
import pytest

from cockpit_aap.governance.scoring import merge_decisions, score_from_violations
from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyViolation


class TestScoreFromViolations:
    def test_no_violations_grade_a(self):
        result = score_from_violations([])
        assert result.grade == "A"
        assert result.passed is True
        assert result.percentage == 100
        assert result.violations == []
        assert result.breakdown == {}

    def test_error_violations_fail(self):
        result = score_from_violations([
            {"id": "r1", "severity": "error", "weight": 4, "message": "fail", "policy": "test"}
        ])
        assert result.passed is False
        assert result.grade in ("D", "E", "F")

    def test_warning_violations_pass(self):
        result = score_from_violations([
            {"id": "r1", "severity": "warning", "weight": 2, "message": "warn", "policy": "test"}
        ])
        assert result.passed is True

    def test_info_violations_pass(self):
        result = score_from_violations([
            {"id": "r1", "severity": "info", "weight": 1, "message": "note", "policy": "test"}
        ])
        assert result.passed is True

    def test_breakdown_by_policy(self):
        result = score_from_violations([
            {"id": "r1", "severity": "warning", "weight": 2, "message": "m1", "policy": "p1"},
            {"id": "r2", "severity": "info", "weight": 1, "message": "m2", "policy": "p2"},
        ])
        assert "p1" in result.breakdown
        assert "p2" in result.breakdown
        assert len(result.breakdown["p1"]["violations"]) == 1
        assert len(result.breakdown["p2"]["violations"]) == 1

    def test_severity_normalization_required_to_error(self):
        result = score_from_violations([
            {"id": "r1", "severity": "required", "message": "fail", "policy": "test"}
        ])
        assert result.passed is False
        assert result.violations[0].severity == "error"

    def test_severity_normalization_forbidden_to_error(self):
        result = score_from_violations([
            {"id": "r1", "severity": "forbidden", "message": "fail", "policy": "test"}
        ])
        assert result.passed is False
        assert result.violations[0].severity == "error"

    def test_severity_normalization_recommended_to_warning(self):
        result = score_from_violations([
            {"id": "r1", "severity": "recommended", "message": "warn", "policy": "test"}
        ])
        assert result.passed is True
        assert result.violations[0].severity == "warning"

    def test_unknown_severity_defaults_to_info(self):
        result = score_from_violations([
            {"id": "r1", "severity": "unknown-level", "message": "note", "policy": "test"}
        ])
        assert result.violations[0].severity == "info"

    def test_policy_id_fallback(self):
        """When violation has no policy field, use policy_id param."""
        result = score_from_violations(
            [{"id": "r1", "severity": "warning", "message": "warn"}],
            policy_id="my-policy",
        )
        assert result.violations[0].policy == "my-policy"
        assert "my-policy" in result.breakdown

    def test_rule_fallback_to_id_field(self):
        result = score_from_violations([
            {"id": "rule-id", "severity": "warning", "message": "msg", "policy": "p1"}
        ])
        assert result.violations[0].rule == "rule-id"

    def test_rule_fallback_to_rule_field(self):
        result = score_from_violations([
            {"rule": "rule-name", "severity": "warning", "message": "msg", "policy": "p1"}
        ])
        assert result.violations[0].rule == "rule-name"

    def test_multiple_errors_all_fail(self):
        result = score_from_violations([
            {"id": "r1", "severity": "error", "message": "e1", "policy": "p1"},
            {"id": "r2", "severity": "error", "message": "e2", "policy": "p1"},
        ])
        assert result.passed is False
        assert len(result.violations) == 2

    def test_default_weight_used_when_not_provided(self):
        result = score_from_violations([
            {"id": "r1", "severity": "error", "message": "fail", "policy": "p1"},
        ])
        # Default weight for error is 4 → max_score=4, score=0
        assert result.max_score == 4
        assert result.score == 0

    def test_percentage_is_zero_for_all_violations(self):
        """When all violations fire, score=0 → percentage=0."""
        result = score_from_violations([
            {"id": "r1", "severity": "warning", "weight": 2, "message": "w", "policy": "p"},
        ])
        assert result.percentage == 0

    def test_returns_policy_decision_instance(self):
        result = score_from_violations([])
        assert isinstance(result, PolicyDecision)


class TestMergeDecisions:
    def test_empty_returns_grade_a(self):
        result = merge_decisions([])
        assert result.grade == "A"
        assert result.passed is True
        assert result.percentage == 100

    def test_merges_violations(self):
        d1 = score_from_violations([
            {"id": "r1", "severity": "warning", "weight": 2, "message": "w1", "policy": "p1"}
        ])
        d2 = score_from_violations([
            {"id": "r2", "severity": "info", "weight": 1, "message": "i1", "policy": "p2"}
        ])
        merged = merge_decisions([d1, d2])
        assert len(merged.violations) == 2

    def test_merges_breakdown_keys(self):
        d1 = score_from_violations([
            {"id": "r1", "severity": "warning", "weight": 2, "message": "w1", "policy": "p1"}
        ])
        d2 = score_from_violations([
            {"id": "r2", "severity": "info", "weight": 1, "message": "i1", "policy": "p2"}
        ])
        merged = merge_decisions([d1, d2])
        assert "p1" in merged.breakdown
        assert "p2" in merged.breakdown

    def test_error_in_any_decision_fails_merged(self):
        d1 = score_from_violations([
            {"id": "r1", "severity": "warning", "message": "warn", "policy": "p1"}
        ])
        d2 = score_from_violations([
            {"id": "r2", "severity": "error", "message": "fail", "policy": "p2"}
        ])
        merged = merge_decisions([d1, d2])
        assert merged.passed is False

    def test_single_decision_preserved(self):
        d = score_from_violations([
            {"id": "r1", "severity": "warning", "weight": 2, "message": "warn", "policy": "p1"}
        ])
        merged = merge_decisions([d])
        assert merged.score == d.score
        assert merged.max_score == d.max_score
        assert merged.grade == d.grade

    def test_returns_policy_decision_instance(self):
        result = merge_decisions([])
        assert isinstance(result, PolicyDecision)
