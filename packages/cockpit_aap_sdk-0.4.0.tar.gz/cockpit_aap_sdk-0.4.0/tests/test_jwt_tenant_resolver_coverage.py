"""Tests for JwtTenantResolver adapter."""
from __future__ import annotations

import importlib
from unittest.mock import MagicMock

import pytest

has_jwt = importlib.util.find_spec("jwt") is not None


class FakeHeaders:
    def __init__(self, data: dict[str, str]) -> None:
        self._data = data
    def get(self, name: str, default=None):
        return self._data.get(name, default)


class FakeRequest:
    def __init__(self, headers: dict[str, str] | None = None) -> None:
        self.headers = FakeHeaders(headers or {})


@pytest.mark.skipif(not has_jwt, reason="PyJWT not installed")
class TestJwtTenantResolver:
    def test_create_resolver(self):
        from cockpit_aap.adapters.jwt_tenant_resolver import create_jwt_tenant_resolver
        resolver = create_jwt_tenant_resolver(secret_or_public_key="secret")
        assert resolver is not None

    def test_create_with_custom_claims(self):
        from cockpit_aap.adapters.jwt_tenant_resolver import create_jwt_tenant_resolver
        resolver = create_jwt_tenant_resolver(
            secret_or_public_key="secret",
            license_claim="lic",
            namespace_claim="ns",
            user_claim="user",
            roles_claim="perms",
            algorithms=["HS512"],
            options={"verify_exp": False},
        )
        assert resolver._license_claim == "lic"
        assert resolver._namespace_claim == "ns"
        assert resolver._algorithms == ["HS512"]

    @pytest.mark.asyncio
    async def test_resolve_valid_token(self):
        import jwt as pyjwt
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver

        secret = "test-secret-key"
        payload = {
            "x-cockpit-license-id": "lic-123",
            "x-cockpit-namespace-id": "ns-456",
            "sub": "user-789",
            "roles": ["admin", "viewer"],
        }
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        resolver = JwtTenantResolver(secret_or_public_key=secret)
        request = FakeRequest(headers={"authorization": f"Bearer {token}"})
        ctx = await resolver.resolve(request)

        assert ctx.license_id == "lic-123"
        assert ctx.namespace_id == "ns-456"
        assert ctx.user_id == "user-789"
        assert ctx.roles == ["admin", "viewer"]

    @pytest.mark.asyncio
    async def test_resolve_missing_auth_header(self):
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver
        resolver = JwtTenantResolver(secret_or_public_key="secret")
        request = FakeRequest(headers={})
        with pytest.raises(ValueError, match="Missing tenant header: authorization"):
            await resolver.resolve(request)

    @pytest.mark.asyncio
    async def test_resolve_invalid_auth_format(self):
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver
        resolver = JwtTenantResolver(secret_or_public_key="secret")
        request = FakeRequest(headers={"authorization": "Basic abc123"})
        with pytest.raises(ValueError, match="Invalid Authorization header"):
            await resolver.resolve(request)

    @pytest.mark.asyncio
    async def test_resolve_single_word_auth(self):
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver
        resolver = JwtTenantResolver(secret_or_public_key="secret")
        request = FakeRequest(headers={"authorization": "tokenonly"})
        with pytest.raises(ValueError, match="Invalid Authorization header"):
            await resolver.resolve(request)

    @pytest.mark.asyncio
    async def test_resolve_invalid_token(self):
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver
        resolver = JwtTenantResolver(secret_or_public_key="secret")
        request = FakeRequest(headers={"authorization": "Bearer invalid.token.here"})
        with pytest.raises(ValueError, match="JWT verification failed"):
            await resolver.resolve(request)

    @pytest.mark.asyncio
    async def test_resolve_missing_license_claim(self):
        import jwt as pyjwt
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver

        secret = "secret"
        payload = {"x-cockpit-namespace-id": "ns-1", "sub": "u"}
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        resolver = JwtTenantResolver(secret_or_public_key=secret)
        request = FakeRequest(headers={"authorization": f"Bearer {token}"})
        with pytest.raises(ValueError, match="Missing tenant claim.*license"):
            await resolver.resolve(request)

    @pytest.mark.asyncio
    async def test_resolve_missing_namespace_claim(self):
        import jwt as pyjwt
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver

        secret = "secret"
        payload = {"x-cockpit-license-id": "lic-1"}
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        resolver = JwtTenantResolver(secret_or_public_key=secret)
        request = FakeRequest(headers={"authorization": f"Bearer {token}"})
        with pytest.raises(ValueError, match="Missing tenant claim.*namespace"):
            await resolver.resolve(request)

    @pytest.mark.asyncio
    async def test_resolve_no_user_id(self):
        import jwt as pyjwt
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver

        secret = "secret"
        payload = {
            "x-cockpit-license-id": "lic-1",
            "x-cockpit-namespace-id": "ns-1",
        }
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        resolver = JwtTenantResolver(secret_or_public_key=secret)
        request = FakeRequest(headers={"authorization": f"Bearer {token}"})
        ctx = await resolver.resolve(request)
        assert ctx.user_id is None
        assert ctx.roles == []

    @pytest.mark.asyncio
    async def test_resolve_roles_as_comma_string(self):
        import jwt as pyjwt
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver

        secret = "secret"
        payload = {
            "x-cockpit-license-id": "lic-1",
            "x-cockpit-namespace-id": "ns-1",
            "roles": "admin, editor, viewer",
        }
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        resolver = JwtTenantResolver(secret_or_public_key=secret)
        request = FakeRequest(headers={"authorization": f"Bearer {token}"})
        ctx = await resolver.resolve(request)
        assert ctx.roles == ["admin", "editor", "viewer"]

    @pytest.mark.asyncio
    async def test_resolve_authorization_case_insensitive(self):
        """Test that 'Authorization' header is found via capital A."""
        import jwt as pyjwt
        from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver

        secret = "secret"
        payload = {
            "x-cockpit-license-id": "lic-1",
            "x-cockpit-namespace-id": "ns-1",
        }
        token = pyjwt.encode(payload, secret, algorithm="HS256")

        resolver = JwtTenantResolver(secret_or_public_key=secret)
        request = FakeRequest(headers={"Authorization": f"Bearer {token}"})
        ctx = await resolver.resolve(request)
        assert ctx.license_id == "lic-1"


@pytest.mark.skipif(has_jwt, reason="Only runs when PyJWT is NOT installed")
def test_jwt_resolver_raises_import_error():
    """If PyJWT is not installed, constructor should raise ImportError."""
    # This test will only run in envs without PyJWT
    from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver
    with pytest.raises(ImportError, match="PyJWT"):
        JwtTenantResolver(secret_or_public_key="secret")
