"""Tests for new manifest types added in Phase 4.8+ parity (types.py additions).

Covers: ManifestRef, ManifestOwnerRef, ManifestJourneyStage, ManifestJourney,
ManifestTelemetry, ManifestTelemetryInstrument, ManifestNetwork, ManifestSDLC,
ManifestSDLCPhaseState, ManifestKnowledge, ManifestHITLParameter, ManifestHITLField,
ManifestHITLTool, ManifestHealthCheck, ManifestUI*, ManifestAudit,
ManifestSkillSuggestion, and updated ManifestSpec fields.
"""

from __future__ import annotations

import pytest

from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAudit,
    ManifestHealthCheck,
    ManifestHITLField,
    ManifestHITLParameter,
    ManifestHITLTool,
    ManifestJourney,
    ManifestJourneyStage,
    ManifestKnowledge,
    ManifestMetadata,
    ManifestOwnerRef,
    ManifestNetwork,
    ManifestRef,
    ManifestSDLC,
    ManifestSDLCPhaseState,
    ManifestSkillSuggestion,
    ManifestSpec,
    ManifestTelemetry,
    ManifestTelemetryInstrument,
    ManifestUI,
    ManifestUIAgentMode,
    ManifestUIInputMode,
    ManifestUISection,
)


# ---------------------------------------------------------------------------
# Dataclass instantiation
# ---------------------------------------------------------------------------

class TestNewDataclasses:
    def test_manifest_ref(self):
        ref = ManifestRef(kind="Module", name="foo", relation="dependsOn", description="dep")
        assert ref.kind == "Module"
        assert ref.relation == "dependsOn"
        assert ref.description == "dep"

    def test_manifest_owner_ref(self):
        owner = ManifestOwnerRef(kind="Module", name="parent")
        assert owner.kind == "Module"
        assert owner.name == "parent"

    def test_manifest_journey(self):
        stages = [ManifestJourneyStage(id="s1", reward_id="badge1", icon="🚀")]
        j = ManifestJourney(stages=stages)
        assert len(j.stages) == 1
        assert j.stages[0].reward_id == "badge1"

    def test_manifest_telemetry(self):
        inst = ManifestTelemetryInstrument(agents=True, tools=False)
        t = ManifestTelemetry(enabled=True, service_name="my-svc", instrument=inst)
        assert t.enabled is True
        assert t.instrument.agents is True
        assert t.instrument.tools is False

    def test_manifest_network(self):
        p = ManifestNetwork(app=3000, mcp=3001, extra={"debug": 9229})
        assert p.app == 3000
        assert p.extra["debug"] == 9229

    def test_manifest_sdlc(self):
        phase = ManifestSDLCPhaseState(completed_at="2024-01-01", approved_by=["alice"])
        sdlc = ManifestSDLC(policy="standard", current_phase="dev", phases={"dev": phase})
        assert sdlc.phases["dev"].approved_by == ["alice"]

    def test_manifest_knowledge(self):
        k = ManifestKnowledge(kind="config", key_pattern="module.config.*", description="desc")
        assert k.key_pattern == "module.config.*"

    def test_manifest_hitl_tool(self):
        param = ManifestHITLParameter(name="name", type="string", description="desc")
        fld = ManifestHITLField(name="notes", label="Notes", type="textarea")
        tool = ManifestHITLTool(
            name="approve",
            title="Approve",
            description="Approval tool",
            parameters=[param],
            ui={"fields": [fld]},
        )
        assert tool.name == "approve"
        assert len(tool.parameters) == 1
        assert tool.ui["fields"][0].label == "Notes"

    def test_manifest_health_check(self):
        hc = ManifestHealthCheck(id="hc1", label="Check 1", severity="error")
        assert hc.severity == "error"

    def test_manifest_ui(self):
        am = ManifestUIAgentMode(id="auto", label="Auto", description="Auto mode")
        im = ManifestUIInputMode(id="chat", icon="💬")
        sec = ManifestUISection(id="config", icon="⚙️")
        ui = ManifestUI(agent_modes=[am], input_modes=[im], sections=[sec])
        assert len(ui.agent_modes) == 1
        assert ui.input_modes[0].id == "chat"

    def test_manifest_audit(self):
        a = ManifestAudit(
            collected_at="2024-06-01",
            unique_users=42,
            sessions=100,
            period_days=30,
        )
        assert a.unique_users == 42

    def test_manifest_skill_suggestion(self):
        s = ManifestSkillSuggestion(label="Quick start", prompt="Show me how to get started")
        assert s.prompt.startswith("Show")


# ---------------------------------------------------------------------------
# Parsing spec with new fields
# ---------------------------------------------------------------------------


class TestParseNewSpecFields:
    def test_parse_spec_with_telemetry(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "telemetry": {
                    "enabled": True,
                    "serviceName": "my-service",
                    "instrument": {
                        "agents": True,
                        "hooks": False,
                    },
                },
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.telemetry is not None
        assert m.spec.telemetry.enabled is True
        assert m.spec.telemetry.service_name == "my-service"
        assert m.spec.telemetry.instrument.agents is True

    def test_parse_spec_with_network(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "network": {"app": 3000, "mcp": 3001},
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.network is not None
        assert m.spec.network.app == 3000

    def test_parse_spec_with_refs(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "refs": [
                    {"kind": "Module", "name": "other", "relation": "dependsOn"},
                ],
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.refs is not None
        assert len(m.spec.refs) == 1
        assert m.spec.refs[0].name == "other"

    def test_parse_spec_with_journey(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "journey": {
                    "stages": [
                        {"id": "intro", "rewardId": "badge-intro"},
                    ],
                },
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.journey is not None
        assert len(m.spec.journey.stages) == 1
        assert m.spec.journey.stages[0].reward_id == "badge-intro"

    def test_parse_spec_with_sdlc(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "sdlc": {
                    "policy": "standard",
                    "currentPhase": "development",
                    "phases": {
                        "development": {
                            "completedAt": "2024-01-15",
                            "approvedBy": ["alice", "bob"],
                        },
                    },
                },
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.sdlc is not None
        assert m.spec.sdlc.current_phase == "development"
        assert "alice" in m.spec.sdlc.phases["development"].approved_by

    def test_parse_spec_with_knowledge(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "knowledge": [
                    {"kind": "config", "keyPattern": "module.config.*", "description": "Config items"},
                ],
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.knowledge is not None
        assert len(m.spec.knowledge) == 1
        assert m.spec.knowledge[0].key_pattern == "module.config.*"

    def test_parse_spec_with_ui(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "ui": {
                    "agentModes": [
                        {"id": "auto", "label": "Auto", "description": "Automatic"},
                    ],
                    "inputModes": [
                        {"id": "chat", "icon": "💬"},
                    ],
                    "sections": [
                        {"id": "config"},
                    ],
                },
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.ui is not None
        assert len(m.spec.ui.agent_modes) == 1
        assert m.spec.ui.agent_modes[0].id == "auto"
        assert m.spec.ui.input_modes[0].icon == "💬"
        assert len(m.spec.ui.sections) == 1

    def test_parse_spec_with_audit(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "audit": {
                    "collectedAt": "2024-06-01",
                    "uniqueUsers": 42,
                    "sessions": 100,
                    "periodDays": 30,
                },
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.audit is not None
        assert m.spec.audit.unique_users == 42
        assert m.spec.audit.period_days == 30

    def test_parse_skill_with_new_fields(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "skills": [
                    {
                        "id": "quick-start",
                        "name": "Quick Start",
                        "description": "Get started",
                        "instruction": "Do the thing",
                        "trigger": "input_context",
                        "stage": "ideation",
                        "suggestions": [
                            {"label": "Go", "prompt": "Let's go"},
                        ],
                        "ghostTriggers": {"keyword": "start"},
                        "placeholder": "Type here...",
                    },
                ],
            },
        }
        m = Manifest.from_dict(raw)
        skill = m.spec.skills[0]
        assert skill.trigger == "input_context"
        assert skill.stage == "ideation"
        assert len(skill.suggestions) == 1
        assert skill.suggestions[0].label == "Go"
        assert skill.ghost_triggers == {"keyword": "start"}
        assert skill.placeholder == "Type here..."

    def test_parse_metadata_with_owner_ref(self):
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {
                "name": "child",
                "ownerRef": {"kind": "Module", "name": "parent"},
                "contentTypeHints": {"text": "markdown"},
            },
            "spec": {},
        }
        m = Manifest.from_dict(raw)
        assert m.metadata.owner_ref is not None
        assert m.metadata.owner_ref.kind == "Module"
        assert m.metadata.owner_ref.name == "parent"
        assert m.metadata.content_type_hints == {"text": "markdown"}

    def test_parse_passthrough_fields(self):
        """Fields stored as raw dict (recognition, classification, etc.) pass through."""
        raw = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "recognition": {"badges": [{"id": "b1", "name": "B1"}]},
                "classification": {"category": "tools"},
                "guardrails": {"maxTokens": 4096},
                "governance": {"owner": "team-a"},
                "memory": {"type": "postgres"},
            },
        }
        m = Manifest.from_dict(raw)
        assert m.spec.recognition is not None
        assert m.spec.recognition.badges is not None
        assert len(m.spec.recognition.badges) == 1
        assert m.spec.recognition.badges[0].id == "b1"
        assert m.spec.classification == {"category": "tools"}
        assert m.spec.guardrails == {"maxTokens": 4096}
        assert m.spec.governance == {"owner": "team-a"}
        assert m.spec.memory == {"type": "postgres"}
